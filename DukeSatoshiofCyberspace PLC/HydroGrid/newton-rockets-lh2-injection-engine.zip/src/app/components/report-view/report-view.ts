import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-report-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let test = twinService.activeTest();
    @let uncert = test?.overallUncertainty;

    @if (test && uncert) {
      <div class="space-y-6 max-w-5xl mx-auto">
        <!-- Top Action Bar (No Print) -->
        <div class="no-print bg-[#0b111c] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
              Formal Engineering Analysis Dossier
            </h3>
            <p class="text-xs text-slate-400">
              Comprehensive experimental data reduction and reduced-order digital-twin report.
            </p>
          </div>

          <div class="flex items-center gap-3">
            <button
              type="button"
              (click)="exportJson()"
              class="px-3 py-1.5 text-xs font-mono rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <mat-icon class="text-[16px] !w-4 !h-4">download</mat-icon>
              <span>Export JSON</span>
            </button>

            <button
              type="button"
              (click)="printReport()"
              class="px-3.5 py-1.5 text-xs font-mono font-semibold rounded bg-cyan-600 hover:bg-cyan-500 text-white flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            >
              <mat-icon class="text-[16px] !w-4 !h-4">print</mat-icon>
              <span>Print Dossier / PDF</span>
            </button>
          </div>
        </div>

        <!-- Printable Formal Dossier Container -->
        <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-8 space-y-8 print:border-none print:p-0 print:bg-white print:text-black">
          <!-- Official Report Header -->
          <div class="border-b-2 border-slate-700 pb-6 print:border-black">
            <div class="flex flex-col md:flex-row md:items-start justify-between gap-4">
              <div>
                <div class="text-xs font-mono tracking-widest text-slate-400 uppercase print:text-slate-600">Newton Rockets Ltd.</div>
                <h1 class="text-2xl font-bold tracking-tight text-white font-tech uppercase mt-0.5 print:text-black">
                  LH₂ Injection Engine
                </h1>
                <div class="text-sm font-semibold text-cyan-400 font-mono mt-1 print:text-cyan-800">
                  Cryogenic Fluid State & Digital-Twin Test Analysis Dossier
                </div>
              </div>

              <!-- Mandatory Engineering Notice -->
              <div class="p-3 bg-slate-900 border border-amber-600/80 rounded-lg text-right print:bg-slate-100 print:border-amber-700">
                <div class="text-[11px] font-mono font-bold text-amber-300 print:text-amber-800 uppercase tracking-wider">
                  RESEARCH / ENGINEERING ANALYSIS — NOT CERTIFICATION
                </div>
                <div class="text-[10px] font-mono text-slate-400 print:text-slate-600 mt-0.5">
                  Doc Ref: NR-ENG-LH2-{{ test.testId }} · Rev 2026.04
                </div>
              </div>
            </div>
          </div>

          <!-- Section 1: Test Identification & Metadata -->
          <div class="space-y-3 text-xs font-mono">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-200 border-b border-slate-800 pb-1.5 print:text-black print:border-slate-300">
              1. Test Identification & Hardware Configuration
            </h3>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 p-3 bg-slate-900/60 rounded-lg print:bg-slate-50">
              <div><span class="text-slate-500">Test ID:</span> <strong class="text-white print:text-black block">{{ test.testId }}</strong></div>
              <div><span class="text-slate-500">Campaign:</span> <strong class="text-white print:text-black block">{{ test.campaignId }}</strong></div>
              <div><span class="text-slate-500">Timestamp:</span> <strong class="text-white print:text-black block">{{ test.testDate }}</strong></div>
              <div><span class="text-slate-500">Operator:</span> <strong class="text-white print:text-black block">{{ test.operator }}</strong></div>
              <div><span class="text-slate-500">Hardware Rev:</span> <strong class="text-cyan-300 print:text-cyan-900 block">{{ test.metadata.hardwareRevision }}</strong></div>
              <div><span class="text-slate-500">Instrumentation Rev:</span> <strong class="text-white print:text-black block">{{ test.metadata.instrumentationRevision }}</strong></div>
              <div><span class="text-slate-500">Manifold Material:</span> <strong class="text-white print:text-black block">{{ test.metadata.manifoldMaterial }}</strong></div>
              <div><span class="text-slate-500">Validation Level:</span> <strong class="text-emerald-400 print:text-emerald-800 block">LEVEL {{ test.validationLevel }}</strong></div>
            </div>
          </div>

          <!-- Section 2: Cryogenic Fluid State & Thermodynamic Properties -->
          <div class="space-y-3 text-xs font-mono">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-200 border-b border-slate-800 pb-1.5 print:text-black print:border-slate-300">
              2. Cryogenic State Estimation (NIST / Leachman Para-Hydrogen EOS)
            </h3>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 p-3 bg-slate-900/60 rounded-lg print:bg-slate-50">
              <div><span class="text-slate-500">Fluid Temp (Steady):</span> <strong class="text-white print:text-black block">{{ uncert.fluidTemp.nominal.toFixed(2) }} K (±{{ uncert.fluidTemp.expandedUncertainty95.toFixed(2) }} K)</strong></div>
              <div><span class="text-slate-500">Inlet Pressure:</span> <strong class="text-white print:text-black block">{{ uncert.upstreamPressure.nominal.toFixed(2) }} bar (±{{ uncert.upstreamPressure.expandedUncertainty95.toFixed(2) }} bar)</strong></div>
              <div><span class="text-slate-500">Subcooling Margin:</span> <strong class="text-cyan-300 print:text-cyan-900 block">2.34 K</strong></div>
              <div><span class="text-slate-500">Liquid Density:</span> <strong class="text-white print:text-black block">{{ uncert.density.nominal.toFixed(2) }} kg/m³</strong></div>
              <div><span class="text-slate-500">Speed of Sound:</span> <strong class="text-white print:text-black block">1,120 m/s</strong></div>
              <div><span class="text-slate-500">Phase Classification:</span> <strong class="text-emerald-400 print:text-emerald-800 block">SUBCOOLED LIQUID</strong></div>
              <div><span class="text-slate-500">EOS Source:</span> <strong class="text-white print:text-black block">NIST SRD 23</strong></div>
              <div><span class="text-slate-500">Model Validity:</span> <strong class="text-emerald-400 print:text-emerald-800 block">VALID (No Extrapolation)</strong></div>
            </div>
          </div>

          <!-- Section 3: Injection Transient Figures of Merit -->
          <div class="space-y-3 text-xs font-mono">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-200 border-b border-slate-800 pb-1.5 print:text-black print:border-slate-300">
              3. Injection Transient Figures of Merit
            </h3>
            <div class="grid grid-cols-2 md:grid-cols-3 gap-4 p-3 bg-slate-900/60 rounded-lg print:bg-slate-50">
              <div><span class="text-slate-500">Rise Time (10% to 90%):</span> <strong class="text-white print:text-black block">{{ (test.transientMetrics.riseTime10To90 * 1000).toFixed(1) }} ms</strong></div>
              <div><span class="text-slate-500">Settling Time (±2% band):</span> <strong class="text-white print:text-black block">{{ (test.transientMetrics.settlingTime2Pct * 1000).toFixed(1) }} ms</strong></div>
              <div><span class="text-slate-500">Peak Pressure Surge:</span> <strong class="text-amber-300 print:text-amber-800 block">+{{ test.transientMetrics.peakPressureOvershootPct.toFixed(1) }}%</strong></div>
              <div><span class="text-slate-500">Steady Mass Flow:</span> <strong class="text-white print:text-black block">{{ test.transientMetrics.steadyStateMeanFlow.toFixed(4) }} kg/s</strong></div>
              <div><span class="text-slate-500">Flow Variability (CV):</span> <strong class="text-white print:text-black block">{{ test.transientMetrics.steadyStateFlowCV.toFixed(2) }}%</strong></div>
              <div><span class="text-slate-500">Acoustic Line Delay:</span> <strong class="text-white print:text-black block">{{ test.transientMetrics.acousticTransitDelayMs.toFixed(2) }} ms</strong></div>
            </div>
          </div>

          <!-- Section 4: Dynamic Stability & Spectral Analysis -->
          <div class="space-y-3 text-xs font-mono">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-200 border-b border-slate-800 pb-1.5 print:text-black print:border-slate-300">
              4. Dynamic Stability & Power Spectral Density
            </h3>
            <div class="p-3 bg-slate-900/60 rounded-lg space-y-2 print:bg-slate-50">
              <div class="grid grid-cols-3 gap-4">
                <div><span class="text-slate-500">Dominant Mode (f₀):</span> <strong class="text-white print:text-black block">{{ test.stability.dominantFrequencyHz.toFixed(1) }} Hz</strong></div>
                <div><span class="text-slate-500">Peak Amplitude:</span> <strong class="text-white print:text-black block">{{ test.stability.peakAmplitudeBar.toFixed(3) }} bar</strong></div>
                <div><span class="text-slate-500">Damping Ratio (ζ):</span> <strong class="text-white print:text-black block">{{ test.stability.dampingRatio.toFixed(3) }}</strong></div>
              </div>
              <div class="pt-2 border-t border-slate-800/80 print:border-slate-300">
                <span class="text-slate-500">Observed Signal:</span>
                <p class="text-slate-200 print:text-black mt-0.5">{{ test.stability.observedSignalDescription }}</p>
              </div>
              <div>
                <span class="text-slate-500">Engineering Interpretation:</span>
                <p class="text-slate-200 print:text-black mt-0.5">{{ test.stability.engineeringInterpretation }}</p>
              </div>
            </div>
          </div>

          <!-- Section 5: Uncertainty Budget & Parameter Calibration -->
          <div class="space-y-3 text-xs font-mono">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-200 border-b border-slate-800 pb-1.5 print:text-black print:border-slate-300">
              5. Parameter Calibration & Monte Carlo Uncertainty Budget (P5/P50/P95)
            </h3>
            <div class="overflow-x-auto">
              <table class="w-full text-left text-[11px] font-mono">
                <thead>
                  <tr class="border-b border-slate-800 text-slate-400 print:border-slate-300 print:text-slate-700">
                    <th class="py-1 px-2">Parameter</th>
                    <th class="py-1 px-2">Symbol</th>
                    <th class="py-1 px-2">Nominal</th>
                    <th class="py-1 px-2">P5</th>
                    <th class="py-1 px-2">P50</th>
                    <th class="py-1 px-2">P95</th>
                    <th class="py-1 px-2">Expanded U_95</th>
                    <th class="py-1 px-2">Classification</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/50 text-slate-300 print:divide-slate-200 print:text-black">
                  <tr>
                    <td class="py-1 px-2 font-semibold">Mass Flow Rate</td>
                    <td class="py-1 px-2 text-cyan-400 print:text-cyan-800">ṁ</td>
                    <td class="py-1 px-2">{{ uncert.massFlow.nominal.toFixed(4) }}</td>
                    <td class="py-1 px-2">{{ uncert.massFlow.p5.toFixed(4) }}</td>
                    <td class="py-1 px-2">{{ uncert.massFlow.p50.toFixed(4) }}</td>
                    <td class="py-1 px-2">{{ uncert.massFlow.p95.toFixed(4) }}</td>
                    <td class="py-1 px-2 text-cyan-400 print:text-cyan-800">±{{ uncert.massFlow.expandedUncertainty95.toFixed(4) }} kg/s</td>
                    <td class="py-1 px-2">MEASURED</td>
                  </tr>
                  <tr>
                    <td class="py-1 px-2 font-semibold">Fluid Temperature</td>
                    <td class="py-1 px-2 text-cyan-400 print:text-cyan-800">T_f</td>
                    <td class="py-1 px-2">{{ uncert.fluidTemp.nominal.toFixed(2) }}</td>
                    <td class="py-1 px-2">{{ uncert.fluidTemp.p5.toFixed(2) }}</td>
                    <td class="py-1 px-2">{{ uncert.fluidTemp.p50.toFixed(2) }}</td>
                    <td class="py-1 px-2">{{ uncert.fluidTemp.p95.toFixed(2) }}</td>
                    <td class="py-1 px-2 text-cyan-400 print:text-cyan-800">±{{ uncert.fluidTemp.expandedUncertainty95.toFixed(2) }} K</td>
                    <td class="py-1 px-2">MEASURED</td>
                  </tr>
                  <tr>
                    <td class="py-1 px-2 font-semibold">Discharge Coeff.</td>
                    <td class="py-1 px-2 text-cyan-400 print:text-cyan-800">C_d</td>
                    <td class="py-1 px-2">0.722</td>
                    <td class="py-1 px-2">0.708</td>
                    <td class="py-1 px-2">0.722</td>
                    <td class="py-1 px-2">0.736</td>
                    <td class="py-1 px-2 text-cyan-400 print:text-cyan-800">±0.014</td>
                    <td class="py-1 px-2 text-purple-400 print:text-purple-800 font-bold">CALIBRATED</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <!-- Section 6: Provenance & Cryptographic Audit Trail -->
          <div class="border-t-2 border-slate-700 pt-6 space-y-2 text-xs font-mono print:border-black">
            <div class="flex flex-col md:flex-row md:items-center justify-between text-slate-400 print:text-slate-600 gap-2">
              <div>
                <span>SHA-256 Provenance Digest:</span>
                <strong class="text-cyan-300 print:text-cyan-900 block font-mono">{{ test.provenanceHash }}</strong>
              </div>
              <div class="text-right">
                <span>Certified Analysis Run Timestamp:</span>
                <strong class="text-slate-200 print:text-black block">{{ test.testDate }}</strong>
              </div>
            </div>
            <div class="text-[10px] text-slate-500 print:text-slate-600 italic">
              Data reduction executed using Newton Rockets LH2 Injection Engine v2026.04. All raw telemetry preserved without in-place modification.
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class ReportViewComponent {
  public readonly twinService = inject(DigitalTwinService);

  public printReport(): void {
    window.print();
  }

  public exportJson(): void {
    const test = this.twinService.activeTest();
    if (!test) return;
    const blob = new Blob([JSON.stringify(test, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `newton-lh2-analysis-${test.testId}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
