import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';
import { TelemetryFrame } from '../../core/models/lh2-types';

@Component({
  selector: 'app-flow-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let test = twinService.activeTest();
    @let currentTime = twinService.playbackTimeSec();

    @if (test) {
      <div class="space-y-6">
        <!-- Top Controls & Channel Legend -->
        <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div class="flex items-center gap-4 flex-wrap text-xs font-mono">
            <span class="text-slate-400">SYNCHRONIZED TELEMETRY CHANNELS:</span>
            <div class="flex items-center gap-1.5 text-cyan-400">
              <span class="w-2.5 h-0.5 bg-cyan-400"></span>
              <span>P_upstream (PT-01)</span>
            </div>
            <div class="flex items-center gap-1.5 text-blue-400">
              <span class="w-2.5 h-0.5 bg-blue-400"></span>
              <span>P_downstream (PT-02)</span>
            </div>
            <div class="flex items-center gap-1.5 text-emerald-400">
              <span class="w-2.5 h-0.5 bg-emerald-400"></span>
              <span>T_fluid (RTD-01)</span>
            </div>
            <div class="flex items-center gap-1.5 text-amber-400">
              <span class="w-2.5 h-0.5 bg-amber-400"></span>
              <span>T_wall (TC-01)</span>
            </div>
            <div class="flex items-center gap-1.5 text-purple-400">
              <span class="w-2.5 h-0.5 bg-purple-400"></span>
              <span>Mass Flow ṁ</span>
            </div>
          </div>

          <div class="flex items-center gap-3">
            <button
              type="button"
              (click)="toggleMarkers()"
              class="px-2.5 py-1 text-xs font-mono rounded border transition-colors cursor-pointer"
              [class.bg-cyan-500_20]="showMarkers()"
              [class.text-cyan-300]="showMarkers()"
              [class.border-cyan-500_40]="showMarkers()"
              [class.bg-slate-900]="!showMarkers()"
              [class.text-slate-400]="!showMarkers()"
              [class.border-slate-800]="!showMarkers()"
            >
              EVENT MARKERS: {{ showMarkers() ? 'ON' : 'OFF' }}
            </button>

            <button
              type="button"
              (click)="resetTimeCursor()"
              class="px-2.5 py-1 text-xs font-mono rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors cursor-pointer"
            >
              RESET CURSOR
            </button>
          </div>
        </div>

        <!-- Synchronized SVG Multi-Panel Canvas -->
        <div class="space-y-4">
          <!-- Chart 1: Upstream & Downstream Pressure vs Time -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4">
            <div class="flex items-center justify-between mb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-cyan-400 text-[16px]">speed</mat-icon>
                <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
                  Pressure History (Upstream P1 vs Downstream P2)
                </h4>
              </div>
              <span class="text-xs font-mono text-cyan-300 tabular-nums">
                P1: {{ getValAtCurrentTime('upstreamPressure')?.toFixed(2) }} bar · P2: {{ getValAtCurrentTime('downstreamPressure')?.toFixed(2) }} bar · ΔP: {{ getDeltaPAtCurrentTime()?.toFixed(2) }} bar
              </span>
            </div>

            <div class="relative w-full h-48 cursor-crosshair" (mousemove)="onChartMouseMove($event)" (click)="onChartClick($event)">
              <svg class="w-full h-full" viewBox="0 0 1000 180" preserveAspectRatio="none">
                <!-- Grid Lines -->
                <line x1="0" y1="45" x2="1000" y2="45" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="90" x2="1000" y2="90" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="135" x2="1000" y2="135" stroke="#1e293b" stroke-dasharray="4" />

                <!-- Event Markers -->
                @if (showMarkers()) {
                  <line [attr.x1]="timeToX(test.transientMetrics.transientOnset)" y1="0" [attr.x2]="timeToX(test.transientMetrics.transientOnset)" y2="180" stroke="#f59e0b" stroke-width="1.5" stroke-dasharray="2" />
                  <line [attr.x1]="timeToX(test.transientMetrics.peakResponseTime)" y1="0" [attr.x2]="timeToX(test.transientMetrics.peakResponseTime)" y2="180" stroke="#06b6d4" stroke-width="1.5" stroke-dasharray="2" />
                  <rect [attr.x]="timeToX(test.transientMetrics.settlingIntervalStart)" y="0" [attr.width]="timeToX(test.transientMetrics.settlingIntervalEnd) - timeToX(test.transientMetrics.settlingIntervalStart)" height="180" fill="#06b6d4" fill-opacity="0.04" />
                }

                <!-- Curve 1: Upstream Pressure (Cyan) -->
                <path [attr.d]="pressureUpstreamPath()" fill="none" stroke="#06b6d4" stroke-width="2" />

                <!-- Curve 2: Downstream Pressure (Blue) -->
                <path [attr.d]="pressureDownstreamPath()" fill="none" stroke="#3b82f6" stroke-width="1.5" stroke-dasharray="4 2" />

                <!-- Synchronized Time Cursor -->
                <line [attr.x1]="timeToX(currentTime)" y1="0" [attr.x2]="timeToX(currentTime)" y2="180" stroke="#ffffff" stroke-width="1.5" />
                <circle [attr.cx]="timeToX(currentTime)" [attr.cy]="pressureUpstreamYAtCursor()" r="4" fill="#06b6d4" stroke="#ffffff" stroke-width="1.5" />
              </svg>

              <!-- Y-axis Labels -->
              <div class="absolute left-2 top-2 text-[10px] font-mono text-slate-500">60 bar</div>
              <div class="absolute left-2 top-1/2 -translate-y-1/2 text-[10px] font-mono text-slate-500">30 bar</div>
              <div class="absolute left-2 bottom-2 text-[10px] font-mono text-slate-500">0 bar</div>
            </div>
          </div>

          <!-- Chart 2: Mass Flow Rate & Mass Flux vs Time -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4">
            <div class="flex items-center justify-between mb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-purple-400 text-[16px]">waves</mat-icon>
                <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
                  Mass Flow History ṁ(t) & Dynamic Mass Flux
                </h4>
              </div>
              <span class="text-xs font-mono text-purple-300 tabular-nums">
                ṁ: {{ getValAtCurrentTime('massFlow')?.toFixed(4) }} kg/s · Flux: {{ ((getValAtCurrentTime('massFlow') || 0) / 1.963e-5).toFixed(0) }} kg/(m²·s)
              </span>
            </div>

            <div class="relative w-full h-44 cursor-crosshair" (mousemove)="onChartMouseMove($event)" (click)="onChartClick($event)">
              <svg class="w-full h-full" viewBox="0 0 1000 160" preserveAspectRatio="none">
                <!-- Grid Lines -->
                <line x1="0" y1="40" x2="1000" y2="40" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="80" x2="1000" y2="80" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="120" x2="1000" y2="120" stroke="#1e293b" stroke-dasharray="4" />

                <!-- Curve: Mass Flow -->
                <path [attr.d]="massFlowAreaPath()" fill="url(#flowGradient)" opacity="0.2" />
                <path [attr.d]="massFlowPath()" fill="none" stroke="#a855f7" stroke-width="2" />

                <!-- Gradient Def -->
                <defs>
                  <linearGradient id="flowGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#a855f7" />
                    <stop offset="100%" stop-color="#a855f7" stop-opacity="0" />
                  </linearGradient>
                </defs>

                <!-- Synchronized Time Cursor -->
                <line [attr.x1]="timeToX(currentTime)" y1="0" [attr.x2]="timeToX(currentTime)" y2="160" stroke="#ffffff" stroke-width="1.5" />
                <circle [attr.cx]="timeToX(currentTime)" [attr.cy]="massFlowYAtCursor()" r="4" fill="#a855f7" stroke="#ffffff" stroke-width="1.5" />
              </svg>

              <!-- Y-axis Labels -->
              <div class="absolute left-2 top-2 text-[10px] font-mono text-slate-500">0.40 kg/s</div>
              <div class="absolute left-2 top-1/2 -translate-y-1/2 text-[10px] font-mono text-slate-500">0.20 kg/s</div>
              <div class="absolute left-2 bottom-2 text-[10px] font-mono text-slate-500">0.00 kg/s</div>
            </div>
          </div>

          <!-- Chart 3: Fluid Temperature & Wall Temperature vs Time -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4">
            <div class="flex items-center justify-between mb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-emerald-400 text-[16px]">thermostat</mat-icon>
                <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
                  Cryogenic Thermal Cooldown History (T_fluid vs T_wall)
                </h4>
              </div>
              <span class="text-xs font-mono text-emerald-300 tabular-nums">
                T_fluid: {{ getValAtCurrentTime('fluidTemperature')?.toFixed(2) }} K · T_wall: {{ getValAtCurrentTime('wallTemperature')?.toFixed(2) }} K
              </span>
            </div>

            <div class="relative w-full h-44 cursor-crosshair" (mousemove)="onChartMouseMove($event)" (click)="onChartClick($event)">
              <svg class="w-full h-full" viewBox="0 0 1000 160" preserveAspectRatio="none">
                <!-- Grid Lines -->
                <line x1="0" y1="40" x2="1000" y2="40" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="80" x2="1000" y2="80" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="120" x2="1000" y2="120" stroke="#1e293b" stroke-dasharray="4" />

                <!-- Normal Boiling Point Reference Line (20.28 K) -->
                <line x1="0" [attr.y1]="tempToY(20.28)" x2="1000" [attr.y2]="tempToY(20.28)" stroke="#10b981" stroke-width="1" stroke-dasharray="3 3" opacity="0.6" />

                <!-- Curve 1: Wall Temp (Amber) -->
                <path [attr.d]="wallTempPath()" fill="none" stroke="#f59e0b" stroke-width="1.5" />

                <!-- Curve 2: Fluid Temp (Emerald) -->
                <path [attr.d]="fluidTempPath()" fill="none" stroke="#10b981" stroke-width="2" />

                <!-- Synchronized Time Cursor -->
                <line [attr.x1]="timeToX(currentTime)" y1="0" [attr.x2]="timeToX(currentTime)" y2="160" stroke="#ffffff" stroke-width="1.5" />
                <circle [attr.cx]="timeToX(currentTime)" [attr.cy]="fluidTempYAtCursor()" r="4" fill="#10b981" stroke="#ffffff" stroke-width="1.5" />
              </svg>

              <!-- Y-axis Labels -->
              <div class="absolute left-2 top-2 text-[10px] font-mono text-slate-500">200 K</div>
              <div class="absolute left-2 top-1/2 -translate-y-1/2 text-[10px] font-mono text-slate-500">100 K</div>
              <div class="absolute left-2 bottom-2 text-[10px] font-mono text-slate-500">20 K (NBP)</div>
            </div>
          </div>

          <!-- Chart 4: Void Fraction & Density Dynamics -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4">
            <div class="flex items-center justify-between mb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-cyan-400 text-[16px]">grain</mat-icon>
                <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
                  Two-Phase Homogeneous Void Fraction α & Saturated Density ρ
                </h4>
              </div>
              <span class="text-xs font-mono text-cyan-300 tabular-nums">
                Void Fraction: {{ ((getFrameAtCurrentTime()?.derivedState?.voidFraction || 0) * 100).toFixed(1) }}% · Density: {{ getFrameAtCurrentTime()?.derivedState?.density?.toFixed(2) }} kg/m³
              </span>
            </div>

            <div class="relative w-full h-36 cursor-crosshair" (mousemove)="onChartMouseMove($event)" (click)="onChartClick($event)">
              <svg class="w-full h-full" viewBox="0 0 1000 130" preserveAspectRatio="none">
                <!-- Grid Lines -->
                <line x1="0" y1="32" x2="1000" y2="32" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="65" x2="1000" y2="65" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="98" x2="1000" y2="98" stroke="#1e293b" stroke-dasharray="4" />

                <!-- Curve: Density (Cyan) -->
                <path [attr.d]="densityPath()" fill="none" stroke="#06b6d4" stroke-width="2" />

                <!-- Curve: Void Fraction (Amber dashed) -->
                <path [attr.d]="voidFractionPath()" fill="none" stroke="#f59e0b" stroke-width="1.5" stroke-dasharray="3 2" />

                <!-- Synchronized Time Cursor -->
                <line [attr.x1]="timeToX(currentTime)" y1="0" [attr.x2]="timeToX(currentTime)" y2="130" stroke="#ffffff" stroke-width="1.5" />
              </svg>

              <!-- Y-axis Labels -->
              <div class="absolute left-2 top-2 text-[10px] font-mono text-slate-500">ρ: 80 kg/m³ · α: 100%</div>
              <div class="absolute left-2 bottom-2 text-[10px] font-mono text-slate-500">ρ: 0 kg/m³ · α: 0%</div>
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class FlowViewComponent {
  public readonly twinService = inject(DigitalTwinService);
  public readonly showMarkers = signal<boolean>(true);

  public toggleMarkers(): void {
    this.showMarkers.set(!this.showMarkers());
  }

  public resetTimeCursor(): void {
    this.twinService.setPlaybackTime(1.5);
  }

  public getFrameAtCurrentTime(): TelemetryFrame | undefined {
    return this.twinService.activeFrame();
  }

  public getValAtCurrentTime(
    channel: 'upstreamPressure' | 'downstreamPressure' | 'fluidTemperature' | 'wallTemperature' | 'massFlow'
  ): number | undefined {
    const f = this.twinService.activeFrame();
    if (!f) return undefined;
    return f[channel].value;
  }

  public getDeltaPAtCurrentTime(): number | undefined {
    const f = this.twinService.activeFrame();
    if (!f) return undefined;
    return f.derivedState.pressureDrop;
  }

  public timeToX(tSec: number): number {
    const test = this.twinService.activeTest();
    if (!test || !test.telemetry.length) return 0;
    const maxT = test.telemetry[test.telemetry.length - 1].timestamp;
    return (tSec / Math.max(0.1, maxT)) * 1000;
  }

  public tempToY(tK: number): number {
    // 20 K -> 140 (bottom), 200 K -> 20 (top)
    const normalized = (tK - 20) / (200 - 20);
    return 140 - normalized * 120;
  }

  public onChartMouseMove(event: MouseEvent): void {
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    const x = event.clientX - rect.left;
    const pct = Math.max(0, Math.min(1, x / rect.width));
    const test = this.twinService.activeTest();
    if (test && test.telemetry.length) {
      const maxT = test.telemetry[test.telemetry.length - 1].timestamp;
      this.twinService.setPlaybackTime(pct * maxT);
    }
  }

  public onChartClick(event: MouseEvent): void {
    this.onChartMouseMove(event);
  }

  public pressureUpstreamPath = computed(() => {
    const test = this.twinService.activeTest();
    if (!test || !test.telemetry.length) return '';
    return this.generatePath(test.telemetry, (f) => f.upstreamPressure.value, 0, 70, 180);
  });

  public pressureDownstreamPath = computed(() => {
    const test = this.twinService.activeTest();
    if (!test || !test.telemetry.length) return '';
    return this.generatePath(test.telemetry, (f) => f.downstreamPressure.value, 0, 70, 180);
  });

  public pressureUpstreamYAtCursor = computed(() => {
    const f = this.twinService.activeFrame();
    if (!f) return 90;
    const norm = f.upstreamPressure.value / 70.0;
    return 170 - norm * 150;
  });

  public massFlowPath = computed(() => {
    const test = this.twinService.activeTest();
    if (!test || !test.telemetry.length) return '';
    return this.generatePath(test.telemetry, (f) => f.massFlow.value, 0, 0.45, 160);
  });

  public massFlowAreaPath = computed(() => {
    const test = this.twinService.activeTest();
    if (!test || !test.telemetry.length) return '';
    const line = this.generatePath(test.telemetry, (f) => f.massFlow.value, 0, 0.45, 160);
    return `${line} L 1000 160 L 0 160 Z`;
  });

  public massFlowYAtCursor = computed(() => {
    const f = this.twinService.activeFrame();
    if (!f) return 80;
    const norm = f.massFlow.value / 0.45;
    return 150 - norm * 130;
  });

  public fluidTempPath = computed(() => {
    const test = this.twinService.activeTest();
    if (!test || !test.telemetry.length) return '';
    return this.generatePath(test.telemetry, (f) => f.fluidTemperature.value, 15, 200, 160);
  });

  public wallTempPath = computed(() => {
    const test = this.twinService.activeTest();
    if (!test || !test.telemetry.length) return '';
    return this.generatePath(test.telemetry, (f) => f.wallTemperature.value, 15, 200, 160);
  });

  public fluidTempYAtCursor = computed(() => {
    const f = this.twinService.activeFrame();
    if (!f) return 80;
    const norm = (f.fluidTemperature.value - 15) / (200 - 15);
    return 150 - norm * 130;
  });

  public densityPath = computed(() => {
    const test = this.twinService.activeTest();
    if (!test || !test.telemetry.length) return '';
    return this.generatePath(test.telemetry, (f) => f.derivedState.density, 0, 80, 130);
  });

  public voidFractionPath = computed(() => {
    const test = this.twinService.activeTest();
    if (!test || !test.telemetry.length) return '';
    return this.generatePath(test.telemetry, (f) => f.derivedState.voidFraction, 0, 1.0, 130);
  });

  private generatePath(
    frames: TelemetryFrame[],
    accessor: (f: TelemetryFrame) => number,
    minVal: number,
    maxVal: number,
    heightPx: number
  ): string {
    const maxT = frames[frames.length - 1].timestamp;
    const range = maxVal - minVal;
    let path = '';

    for (let i = 0; i < frames.length; i++) {
      const f = frames[i];
      const x = (f.timestamp / maxT) * 1000;
      const y = (heightPx - 10) - ((accessor(f) - minVal) / range) * (heightPx - 20);
      path += (i === 0 ? 'M ' : 'L ') + `${x.toFixed(1)} ${y.toFixed(1)} `;
    }
    return path;
  }
}
