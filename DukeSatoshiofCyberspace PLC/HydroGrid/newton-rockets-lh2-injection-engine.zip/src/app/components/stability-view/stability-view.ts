import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-stability-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let test = twinService.activeTest();
    @let stab = test?.stability;

    @if (test && stab) {
      <div class="space-y-6">
        <!-- Top Metrics Ribbon -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4">
            <span class="text-xs font-mono text-slate-400 uppercase">Dominant Frequency (f₀)</span>
            <div class="text-2xl font-bold font-mono text-cyan-300 mt-1 tabular-nums">
              {{ stab.dominantFrequencyHz.toFixed(1) }}
              <span class="text-xs text-slate-400 font-normal">Hz</span>
            </div>
            <div class="text-[11px] font-mono text-slate-500 mt-1">
              Peak: {{ stab.peakAmplitudeBar.toFixed(3) }} bar
            </div>
          </div>

          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4">
            <span class="text-xs font-mono text-slate-400 uppercase">Secondary Mode (f₁)</span>
            <div class="text-2xl font-bold font-mono text-slate-200 mt-1 tabular-nums">
              {{ stab.secondaryFrequencyHz.toFixed(1) }}
              <span class="text-xs text-slate-400 font-normal">Hz</span>
            </div>
            <div class="text-[11px] font-mono text-slate-500 mt-1">Harmonic coupling</div>
          </div>

          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4">
            <span class="text-xs font-mono text-slate-400 uppercase">Damping Ratio (ζ)</span>
            <div class="text-2xl font-bold font-mono text-emerald-300 mt-1 tabular-nums">
              {{ stab.dampingRatio.toFixed(3) }}
            </div>
            <div class="text-[11px] font-mono text-slate-500 mt-1">Half-power bandwidth</div>
          </div>

          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-4">
            <span class="text-xs font-mono text-slate-400 uppercase">Hydrodynamic Risk</span>
            <div class="text-xl font-bold font-mono mt-1" [class.text-emerald-300]="stab.instabilityRiskRating === 'LOW'" [class.text-amber-300]="stab.instabilityRiskRating !== 'LOW'">
              ● {{ stab.instabilityRiskRating }} RISK
            </div>
            <div class="text-[11px] font-mono text-slate-500 mt-1">Sample Rate: {{ stab.sampleRateHz }} Hz</div>
          </div>
        </div>

        <!-- 2 Spectral Charts -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <!-- Chart 1: FFT Magnitude Spectrum -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-3">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <mat-icon class="text-cyan-400 text-[18px]">equalizer</mat-icon>
                <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
                  Discrete Fourier Transform Amplitude (0 to 300 Hz)
                </h4>
              </div>
              <span class="text-xs font-mono text-cyan-300">|X(f)| (bar)</span>
            </div>

            <div class="relative w-full h-60">
              <svg class="w-full h-full" viewBox="0 0 500 200" preserveAspectRatio="none">
                <!-- Grid -->
                <line x1="0" y1="50" x2="500" y2="50" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="100" x2="500" y2="100" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="150" x2="500" y2="150" stroke="#1e293b" stroke-dasharray="4" />

                <!-- Spectral Bars / Line -->
                <path [attr.d]="fftAreaPath()" fill="#06b6d4" fill-opacity="0.15" />
                <path [attr.d]="fftLinePath()" fill="none" stroke="#06b6d4" stroke-width="2" />

                <!-- Dominant Peak Marker -->
                <circle [attr.cx]="freqToX(stab.dominantFrequencyHz)" [attr.cy]="ampToY(stab.peakAmplitudeBar)" r="5" fill="#06b6d4" stroke="#ffffff" stroke-width="1.5" />
              </svg>

              <!-- Axis labels -->
              <div class="absolute left-2 top-2 text-[10px] font-mono text-slate-500">0.20 bar</div>
              <div class="absolute right-2 bottom-1 text-[10px] font-mono text-slate-500">300 Hz</div>
              <div class="absolute left-2 bottom-1 text-[10px] font-mono text-slate-500">0 Hz</div>
            </div>
          </div>

          <!-- Chart 2: Power Spectral Density (PSD) -->
          <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-3">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <mat-icon class="text-purple-400 text-[18px]">show_chart</mat-icon>
                <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
                  Power Spectral Density (PSD)
                </h4>
              </div>
              <span class="text-xs font-mono text-purple-300">bar²/Hz</span>
            </div>

            <div class="relative w-full h-60">
              <svg class="w-full h-full" viewBox="0 0 500 200" preserveAspectRatio="none">
                <!-- Grid -->
                <line x1="0" y1="50" x2="500" y2="50" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="100" x2="500" y2="100" stroke="#1e293b" stroke-dasharray="4" />
                <line x1="0" y1="150" x2="500" y2="150" stroke="#1e293b" stroke-dasharray="4" />

                <!-- PSD Line -->
                <path [attr.d]="psdAreaPath()" fill="#a855f7" fill-opacity="0.15" />
                <path [attr.d]="psdLinePath()" fill="none" stroke="#a855f7" stroke-width="2" />
              </svg>

              <!-- Axis labels -->
              <div class="absolute left-2 top-2 text-[10px] font-mono text-slate-500">0.10 bar²/Hz</div>
              <div class="absolute right-2 bottom-1 text-[10px] font-mono text-slate-500">300 Hz</div>
              <div class="absolute left-2 bottom-1 text-[10px] font-mono text-slate-500">0 Hz</div>
            </div>
          </div>
        </div>

        <!-- Rigorous Epistemic Boundary: OBSERVED SIGNAL vs ENGINEERING INTERPRETATION -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <!-- Box 1: Observed Signal -->
          <div class="bg-[#0b111c] border border-cyan-800/60 rounded-xl p-5 space-y-3">
            <div class="flex items-center gap-2 text-cyan-400 border-b border-slate-800 pb-2.5">
              <mat-icon class="text-[18px]">sensors</mat-icon>
              <h4 class="text-xs font-mono font-bold uppercase tracking-wider">
                1. Observed Signal (Empirical Measurement)
              </h4>
            </div>
            <p class="text-xs text-slate-200 leading-relaxed font-mono">
              {{ stab.observedSignalDescription }}
            </p>
            <div class="text-[11px] text-slate-400 font-mono pt-2 border-t border-slate-800/80">
              Direct telemetry from sensor Kulite CT-190 (PT-DYNA-01) sampled at {{ stab.sampleRateHz }} Hz.
            </div>
          </div>

          <!-- Box 2: Engineering Interpretation -->
          <div class="bg-[#0b111c] border border-amber-800/60 rounded-xl p-5 space-y-3">
            <div class="flex items-center gap-2 text-amber-400 border-b border-slate-800 pb-2.5">
              <mat-icon class="text-[18px]">psychology</mat-icon>
              <h4 class="text-xs font-mono font-bold uppercase tracking-wider">
                2. Engineering Interpretation (Physical Model Hypothesis)
              </h4>
            </div>
            <p class="text-xs text-slate-200 leading-relaxed font-mono">
              {{ stab.engineeringInterpretation }}
            </p>
            <div class="text-[11px] text-amber-300/80 font-mono pt-2 border-t border-slate-800/80">
              * NOTICE: Hydraulic acoustic resonance must not be conflated with chamber combustion instabilities.
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class StabilityViewComponent {
  public readonly twinService = inject(DigitalTwinService);

  public freqToX(freqHz: number): number {
    return Math.max(0, Math.min(500, (freqHz / 300.0) * 500));
  }

  public ampToY(ampBar: number): number {
    const norm = Math.max(0, Math.min(1, ampBar / 0.20));
    return 190 - norm * 170;
  }

  public psdToY(psdVal: number): number {
    const norm = Math.max(0, Math.min(1, psdVal / 0.10));
    return 190 - norm * 170;
  }

  public fftLinePath = computed(() => {
    const test = this.twinService.activeTest();
    if (!test) return '';
    const { frequencies, fftAmplitudes } = test.stability.spectralData;
    let path = '';
    for (let i = 0; i < frequencies.length; i++) {
      const x = this.freqToX(frequencies[i]);
      const y = this.ampToY(fftAmplitudes[i]);
      path += (i === 0 ? 'M ' : 'L ') + `${x.toFixed(1)} ${y.toFixed(1)} `;
    }
    return path;
  });

  public fftAreaPath = computed(() => {
    const line = this.fftLinePath();
    return line ? `${line} L 500 200 L 0 200 Z` : '';
  });

  public psdLinePath = computed(() => {
    const test = this.twinService.activeTest();
    if (!test) return '';
    const { frequencies, psdValues } = test.stability.spectralData;
    let path = '';
    for (let i = 0; i < frequencies.length; i++) {
      const x = this.freqToX(frequencies[i]);
      const y = this.psdToY(psdValues[i]);
      path += (i === 0 ? 'M ' : 'L ') + `${x.toFixed(1)} ${y.toFixed(1)} `;
    }
    return path;
  });

  public psdAreaPath = computed(() => {
    const line = this.psdLinePath();
    return line ? `${line} L 500 200 L 0 200 Z` : '';
  });
}
