import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-uncertainty-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let test = twinService.activeTest();
    @let uncert = test?.overallUncertainty;
    @let params = test?.calibratedParameters;

    @if (test && uncert && params) {
      <div class="space-y-6">
        <!-- Monte Carlo Uncertainty Metrics Strip (Nominal, P5, P50, P95) -->
        <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 class="text-sm font-semibold text-white font-tech uppercase tracking-wide">
                Monte Carlo Uncertainty Quantification (GUM Type A & B Propagation)
              </h3>
              <p class="text-xs text-slate-400 mt-0.5">
                N = 1,000 draws propagating RTD, piezoelectric pressure transducer, and Coriolis sensor calibration covariances.
              </p>
            </div>
            <span class="text-xs font-mono text-cyan-400">
              Coverage Factor: k = 2.0 (95% CI)
            </span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            <!-- Metric 1: Mass Flow Rate -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 space-y-2 font-mono text-xs">
              <div class="text-slate-400 uppercase font-semibold">Mass Flow (ṁ)</div>
              <div class="text-lg font-bold text-white tabular-nums">
                {{ uncert.massFlow.nominal.toFixed(4) }}
                <span class="text-[11px] text-slate-400 font-normal">{{ uncert.massFlow.unit }}</span>
              </div>
              <div class="space-y-1 text-[11px] text-slate-300 border-t border-slate-800/80 pt-1.5">
                <div class="flex justify-between"><span>P5:</span><span class="tabular-nums">{{ uncert.massFlow.p5.toFixed(4) }}</span></div>
                <div class="flex justify-between"><span>P50:</span><span class="tabular-nums">{{ uncert.massFlow.p50.toFixed(4) }}</span></div>
                <div class="flex justify-between"><span>P95:</span><span class="tabular-nums">{{ uncert.massFlow.p95.toFixed(4) }}</span></div>
                <div class="flex justify-between text-cyan-400 font-semibold"><span>U_95:</span><span class="tabular-nums">±{{ uncert.massFlow.expandedUncertainty95.toFixed(4) }}</span></div>
              </div>
            </div>

            <!-- Metric 2: Fluid Temperature -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 space-y-2 font-mono text-xs">
              <div class="text-slate-400 uppercase font-semibold">Fluid Temp (T_f)</div>
              <div class="text-lg font-bold text-white tabular-nums">
                {{ uncert.fluidTemp.nominal.toFixed(2) }}
                <span class="text-[11px] text-slate-400 font-normal">{{ uncert.fluidTemp.unit }}</span>
              </div>
              <div class="space-y-1 text-[11px] text-slate-300 border-t border-slate-800/80 pt-1.5">
                <div class="flex justify-between"><span>P5:</span><span class="tabular-nums">{{ uncert.fluidTemp.p5.toFixed(2) }}</span></div>
                <div class="flex justify-between"><span>P50:</span><span class="tabular-nums">{{ uncert.fluidTemp.p50.toFixed(2) }}</span></div>
                <div class="flex justify-between"><span>P95:</span><span class="tabular-nums">{{ uncert.fluidTemp.p95.toFixed(2) }}</span></div>
                <div class="flex justify-between text-cyan-400 font-semibold"><span>U_95:</span><span class="tabular-nums">±{{ uncert.fluidTemp.expandedUncertainty95.toFixed(2) }}</span></div>
              </div>
            </div>

            <!-- Metric 3: Inlet Pressure -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 space-y-2 font-mono text-xs">
              <div class="text-slate-400 uppercase font-semibold">Inlet Pressure (P1)</div>
              <div class="text-lg font-bold text-white tabular-nums">
                {{ uncert.upstreamPressure.nominal.toFixed(2) }}
                <span class="text-[11px] text-slate-400 font-normal">{{ uncert.upstreamPressure.unit }}</span>
              </div>
              <div class="space-y-1 text-[11px] text-slate-300 border-t border-slate-800/80 pt-1.5">
                <div class="flex justify-between"><span>P5:</span><span class="tabular-nums">{{ uncert.upstreamPressure.p5.toFixed(2) }}</span></div>
                <div class="flex justify-between"><span>P50:</span><span class="tabular-nums">{{ uncert.upstreamPressure.p50.toFixed(2) }}</span></div>
                <div class="flex justify-between"><span>P95:</span><span class="tabular-nums">{{ uncert.upstreamPressure.p95.toFixed(2) }}</span></div>
                <div class="flex justify-between text-cyan-400 font-semibold"><span>U_95:</span><span class="tabular-nums">±{{ uncert.upstreamPressure.expandedUncertainty95.toFixed(2) }}</span></div>
              </div>
            </div>

            <!-- Metric 4: Pressure Drop -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 space-y-2 font-mono text-xs">
              <div class="text-slate-400 uppercase font-semibold">Pressure Drop (ΔP)</div>
              <div class="text-lg font-bold text-white tabular-nums">
                {{ uncert.pressureDrop.nominal.toFixed(2) }}
                <span class="text-[11px] text-slate-400 font-normal">{{ uncert.pressureDrop.unit }}</span>
              </div>
              <div class="space-y-1 text-[11px] text-slate-300 border-t border-slate-800/80 pt-1.5">
                <div class="flex justify-between"><span>P5:</span><span class="tabular-nums">{{ uncert.pressureDrop.p5.toFixed(2) }}</span></div>
                <div class="flex justify-between"><span>P50:</span><span class="tabular-nums">{{ uncert.pressureDrop.p50.toFixed(2) }}</span></div>
                <div class="flex justify-between"><span>P95:</span><span class="tabular-nums">{{ uncert.pressureDrop.p95.toFixed(2) }}</span></div>
                <div class="flex justify-between text-cyan-400 font-semibold"><span>U_95:</span><span class="tabular-nums">±{{ uncert.pressureDrop.expandedUncertainty95.toFixed(2) }}</span></div>
              </div>
            </div>

            <!-- Metric 5: Fluid Density -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 space-y-2 font-mono text-xs">
              <div class="text-slate-400 uppercase font-semibold">Fluid Density (ρ)</div>
              <div class="text-lg font-bold text-white tabular-nums">
                {{ uncert.density.nominal.toFixed(2) }}
                <span class="text-[11px] text-slate-400 font-normal">{{ uncert.density.unit }}</span>
              </div>
              <div class="space-y-1 text-[11px] text-slate-300 border-t border-slate-800/80 pt-1.5">
                <div class="flex justify-between"><span>P5:</span><span class="tabular-nums">{{ uncert.density.p5.toFixed(2) }}</span></div>
                <div class="flex justify-between"><span>P50:</span><span class="tabular-nums">{{ uncert.density.p50.toFixed(2) }}</span></div>
                <div class="flex justify-between"><span>P95:</span><span class="tabular-nums">{{ uncert.density.p95.toFixed(2) }}</span></div>
                <div class="flex justify-between text-cyan-400 font-semibold"><span>U_95:</span><span class="tabular-nums">±{{ uncert.density.expandedUncertainty95.toFixed(2) }}</span></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Section 2: Model Parameter Calibration Table -->
        <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h4 class="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
                Reduced-Order Model Parameter Calibration (Nonlinear Bootstrap Regression)
              </h4>
              <p class="text-[11px] text-slate-400 mt-0.5">
                Separating: THEORETICAL · ASSUMED · CALIBRATED · MEASURED · VALIDATED.
              </p>
            </div>
            <span class="text-[11px] font-mono text-amber-400">
              * Non-Independent Validation Rule Enforced
            </span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs font-mono">
              <thead>
                <tr class="border-b border-slate-800 text-slate-400">
                  <th class="py-2.5 px-3">Parameter Name</th>
                  <th class="py-2.5 px-3">Symbol</th>
                  <th class="py-2.5 px-3">Nominal Prior</th>
                  <th class="py-2.5 px-3">Calibrated Value</th>
                  <th class="py-2.5 px-3">95% Confidence Interval</th>
                  <th class="py-2.5 px-3">Unit</th>
                  <th class="py-2.5 px-3">Fit R²</th>
                  <th class="py-2.5 px-3">Classification</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/50 text-slate-300">
                @for (p of params; track p.symbol) {
                  <tr>
                    <td class="py-2.5 px-3 font-semibold text-white">{{ p.name }}</td>
                    <td class="py-2.5 px-3 text-cyan-400 font-bold">{{ p.symbol }}</td>
                    <td class="py-2.5 px-3 tabular-nums">{{ p.nominalValue }}</td>
                    <td class="py-2.5 px-3 tabular-nums font-semibold text-cyan-300">{{ p.calibratedValue }}</td>
                    <td class="py-2.5 px-3 tabular-nums text-slate-400">[{{ p.confidenceInterval95[0] }}, {{ p.confidenceInterval95[1] }}]</td>
                    <td class="py-2.5 px-3 text-slate-400">{{ p.unit }}</td>
                    <td class="py-2.5 px-3 tabular-nums text-emerald-400">{{ p.fitR2.toFixed(3) }}</td>
                    <td class="py-2.5 px-3">
                      <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                        [class.bg-purple-500_20]="p.classification === 'CALIBRATED'"
                        [class.text-purple-300]="p.classification === 'CALIBRATED'"
                        [class.bg-blue-500_20]="p.classification === 'THEORETICAL'"
                        [class.text-blue-300]="p.classification === 'THEORETICAL'"
                        [class.bg-slate-800]="p.classification === 'ASSUMED'"
                        [class.text-slate-400]="p.classification === 'ASSUMED'">
                        {{ p.classification }}
                      </span>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>

          <div class="bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs font-mono text-slate-400 leading-relaxed">
            <strong class="text-amber-400 font-bold">MANDATORY EPISTEMIC PRINCIPLE:</strong>
            A calibrated model parameter represents optimal fitting against the current experimental dataset. It must NEVER be described as independently validated without blind testing on an uncoupled test campaign.
          </div>
        </div>
      </div>
    }
  `,
})
export class UncertaintyViewComponent {
  public readonly twinService = inject(DigitalTwinService);
}
