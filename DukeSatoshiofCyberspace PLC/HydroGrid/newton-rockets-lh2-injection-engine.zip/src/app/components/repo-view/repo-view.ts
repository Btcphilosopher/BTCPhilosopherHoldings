import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CliAndRepoService, CliCommandResult, RepoFileNode } from '../../core/services/cli-and-repo.service';

@Component({
  selector: 'app-repo-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Top Overview Header -->
      <div class="bg-[#0b111c] border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h3 class="text-sm font-semibold text-white font-tech uppercase tracking-wide">
            newton-lh2-injection · Python Package & Interactive CLI
          </h3>
          <p class="text-xs text-slate-400 mt-0.5">
            R/Python-compatible scientific package architecture and embedded shell console.
          </p>
        </div>

        <!-- Quick Action Buttons -->
        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="runCommand('newton-lh2-injection test-suite')"
            class="px-3 py-1.5 text-xs font-mono rounded bg-emerald-700 hover:bg-emerald-600 text-white flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <mat-icon class="text-[16px] !w-4 !h-4">play_arrow</mat-icon>
            <span>Run PyTest Suite (Level 0-2)</span>
          </button>
        </div>
      </div>

      <!-- 2-Column Split: Left Code Explorer & Right Interactive CLI Terminal -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <!-- Col 1: Repository Tree & Code Viewer (5 cols) -->
        <div class="lg:col-span-5 bg-[#0b111c] border border-slate-800 rounded-xl overflow-hidden flex flex-col h-[560px]">
          <!-- Tree Header -->
          <div class="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <div class="flex items-center gap-2 text-xs font-mono text-slate-300">
              <mat-icon class="text-[16px] text-cyan-400">folder</mat-icon>
              <span>newton-lh2-injection/</span>
            </div>
            <span class="text-[10px] font-mono text-slate-500">Python 3.12+</span>
          </div>

          <!-- Tree List -->
          <div class="p-3 overflow-y-auto max-h-48 border-b border-slate-800 text-xs font-mono space-y-1">
            @for (item of repoService.repoTree; track item.path) {
              <div>
                <div class="text-slate-400 flex items-center gap-1">
                  <mat-icon class="text-[14px] text-amber-400">folder_open</mat-icon>
                  <span>{{ item.name }}/</span>
                </div>
                @if (item.children) {
                  <div class="pl-4 space-y-1">
                    @for (sub of item.children; track sub.path) {
                      <div>
                        <div class="text-slate-400 flex items-center gap-1">
                          <mat-icon class="text-[14px] text-amber-400">folder</mat-icon>
                          <span>{{ sub.name }}/</span>
                        </div>
                        @if (sub.children) {
                          <div class="pl-4 space-y-0.5">
                            @for (f of sub.children; track f.path) {
                              <button
                                type="button"
                                (click)="selectFile(f)"
                                class="w-full text-left py-0.5 px-1.5 rounded hover:bg-slate-800 flex items-center gap-1.5 cursor-pointer"
                                [class.text-cyan-300]="selectedFile()?.path === f.path"
                                [class.text-slate-400]="selectedFile()?.path !== f.path"
                              >
                                <mat-icon class="text-[12px] text-slate-500">code</mat-icon>
                                <span>{{ f.name }}</span>
                              </button>
                            }
                          </div>
                        }
                      </div>
                    }
                  </div>
                }
              </div>
            }
          </div>

          <!-- File Code Preview -->
          <div class="flex-1 p-3 bg-[#070b12] overflow-y-auto text-[11px] font-mono text-slate-300">
            <div class="text-[10px] text-slate-500 pb-1.5 mb-2 border-b border-slate-800 flex justify-between">
              <span>{{ selectedFile()?.path || 'src/newton_lh2_injection/fluids/state.py' }}</span>
              <span class="text-cyan-400 uppercase">{{ selectedFile()?.language || 'python' }}</span>
            </div>
            <pre class="whitespace-pre-wrap leading-relaxed text-slate-300"><code>{{ selectedFile()?.content || defaultContent }}</code></pre>
          </div>
        </div>

        <!-- Col 2: Interactive Newton Rockets CLI Terminal (7 cols) -->
        <div class="lg:col-span-7 bg-[#070b12] border border-slate-800 rounded-xl overflow-hidden flex flex-col h-[560px]">
          <!-- Terminal Header -->
          <div class="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <div class="flex items-center gap-2 text-xs font-mono text-slate-200">
              <span class="w-2.5 h-2.5 rounded-full bg-rose-500/80"></span>
              <span class="w-2.5 h-2.5 rounded-full bg-amber-500/80"></span>
              <span class="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></span>
              <span class="ml-2 text-slate-400">newton-cli-session (bash)</span>
            </div>
            <button
              type="button"
              (click)="clearHistory()"
              class="text-[10px] font-mono text-slate-500 hover:text-slate-300 cursor-pointer"
            >
              Clear
            </button>
          </div>

          <!-- Quick Command Shortcuts Bar -->
          <div class="px-3 py-2 bg-[#0b111c] border-b border-slate-800 flex items-center gap-1.5 flex-wrap overflow-x-auto text-[11px] font-mono">
            <span class="text-slate-500 mr-1">RUN:</span>
            <button
              type="button"
              (click)="runCommand('newton-lh2-injection analyse')"
              class="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 transition-colors cursor-pointer"
            >
              analyse
            </button>
            <button
              type="button"
              (click)="runCommand('newton-lh2-injection thermal')"
              class="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 transition-colors cursor-pointer"
            >
              thermal
            </button>
            <button
              type="button"
              (click)="runCommand('newton-lh2-injection flow')"
              class="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 transition-colors cursor-pointer"
            >
              flow
            </button>
            <button
              type="button"
              (click)="runCommand('newton-lh2-injection transient')"
              class="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 transition-colors cursor-pointer"
            >
              transient
            </button>
            <button
              type="button"
              (click)="runCommand('newton-lh2-injection stability')"
              class="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 transition-colors cursor-pointer"
            >
              stability
            </button>
            <button
              type="button"
              (click)="runCommand('newton-lh2-injection calibrate')"
              class="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 transition-colors cursor-pointer"
            >
              calibrate
            </button>
            <button
              type="button"
              (click)="runCommand('newton-lh2-injection validate')"
              class="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 transition-colors cursor-pointer"
            >
              validate
            </button>
            <button
              type="button"
              (click)="runCommand('newton-lh2-injection test-suite')"
              class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 transition-colors cursor-pointer"
            >
              test-suite
            </button>
          </div>

          <!-- Terminal Output Scroll Area -->
          <div class="flex-1 p-4 overflow-y-auto text-xs font-mono space-y-4">
            @for (res of commandHistory(); track res.timestamp) {
              <div class="space-y-1">
                <div class="text-cyan-400 flex items-center gap-2">
                  <span class="text-slate-500">$</span>
                  <strong class="text-white">{{ res.command }}</strong>
                </div>
                @if (res.stdout) {
                  <pre class="whitespace-pre-wrap text-slate-300 leading-relaxed pl-3 border-l-2 border-slate-800">{{ res.stdout }}</pre>
                }
                @if (res.stderr) {
                  <pre class="whitespace-pre-wrap text-rose-400 leading-relaxed pl-3 border-l-2 border-rose-800">{{ res.stderr }}</pre>
                }
              </div>
            }
          </div>

          <!-- Terminal Command Input Bar -->
          <form (submit)="onSubmit($event)" class="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2">
            <span class="text-cyan-400 font-mono text-xs">$</span>
            <input
              type="text"
              #cmdInput
              [value]="currentInput()"
              (input)="currentInput.set(cmdInput.value)"
              placeholder="Type 'newton-lh2-injection help' or command..."
              class="w-full bg-transparent text-xs font-mono text-white outline-none placeholder-slate-600"
            />
            <button
              type="submit"
              class="px-3 py-1 text-xs font-mono bg-cyan-600 hover:bg-cyan-500 text-white rounded transition-colors cursor-pointer"
            >
              Exec
            </button>
          </form>
        </div>
      </div>
    </div>
  `,
})
export class RepoViewComponent {
  public readonly repoService = inject(CliAndRepoService);
  public readonly selectedFile = signal<RepoFileNode | null>(null);
  public readonly currentInput = signal<string>('newton-lh2-injection test-suite');

  public readonly defaultContent = `"""Newton Rockets LH2 Injection Engine - Fluids State Module."""
from dataclasses import dataclass
from enum import Enum

class PhaseState(str, Enum):
    SUBCOOLED_LIQUID = "SUBCOOLED_LIQUID"
    TWO_PHASE = "TWO_PHASE"
    SUPERCRITICAL = "SUPERCRITICAL"
`;

  public readonly commandHistory = signal<CliCommandResult[]>([
    {
      command: 'newton-lh2-injection help',
      stdout: `NEWTON ROCKETS LTD.
LH2 INJECTION ENGINE — CRYOGENIC DIGITAL-TWIN CLI (v2026.04)

USAGE:
  newton-lh2-injection <command> [arguments]

COMMANDS:
  import <file>          Import external CSV/JSON test telemetry into digital twin
  validate-data [id]     Execute Level-0/1 telemetry data quality and boundary audits
  analyse [id]           Run comprehensive cryogenic state and flow estimation
  thermal [id]           Analyse cooldown rate, thermal lag, and conjugate wall heat flux
  flow [id]              Calculate mass-flow, mass-flux, and HEM void fraction
  transient [id]         Calculate rise time (10-90%), settling time, and peak overshoot
  stability [id]         Execute FFT, Power Spectral Density (PSD), and mode detection
  compare [campaign]     Cross-compare test runs across hardware revisions and subcooling
  calibrate [id]         Run bootstrap nonlinear parameter calibration (Cd, HTC, Kloss)
  validate [id]          Display Validation Hierarchy Level 0-5 status and evidence
  report [id]            Generate Newton Rockets engineering analysis dossier
  test-suite             Run full automated test verification suite (Level 0-2)
`,
      exitCode: 0,
      timestamp: '2026-09-29 03:00:00',
    },
  ]);

  public selectFile(f: RepoFileNode): void {
    this.selectedFile.set(f);
  }

  public runCommand(cmdStr: string): void {
    const result = this.repoService.executeCliCommand(cmdStr);
    this.commandHistory.update((hist) => [...hist, result]);
  }

  public onSubmit(event: Event): void {
    event.preventDefault();
    const cmd = this.currentInput().trim();
    if (!cmd) return;
    this.runCommand(cmd);
    this.currentInput.set('');
  }

  public clearHistory(): void {
    this.commandHistory.set([]);
  }
}
