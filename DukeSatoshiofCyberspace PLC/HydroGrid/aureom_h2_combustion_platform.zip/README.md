# Aureom H2-Combustion Platform

A production-grade Python simulation platform for hydrogen combustion
propulsion and power systems: piston hydrogen ICEs, hydrogen gas turbines,
and hybrid combustion-electric drivetrains, for mobility (cars, trucks,
trains) and stationary generation.

Every subsystem is a genuine reduced-order physics/engineering model with
documented, checkable equations and constants (see "Methodology &
references" below) — there is no placeholder or dummy combustion logic.
Simulations are deterministic: identical inputs always produce identical
outputs (verified in `tests/test_simulation.py`).

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Reference example from the spec:
python aureom_h2_combustion/main.py \
    --engine-type hydrogen_ice --displacement 2.0 \
    --hydrogen-flow-rate 0.8e-3 --rpm 4500 --load 0.75 \
    --simulation-time 120 --plot

# Hydrogen turbine:
python aureom_h2_combustion/main.py \
    --engine-type hydrogen_turbine --load 0.85 --simulation-time 30 --plot
```

Or from Python:

```python
from aureom_h2_combustion.core.simulation import run_engine_simulation

logger, financials = run_engine_simulation(
    engine_type="hydrogen_ice",
    displacement=2.0,
    hydrogen_flow_rate=0.8e-3,
    rpm=4500,
    load=0.75,
    simulation_time=120,
)
df = logger.to_dataframe()
```

Run the test suite: `pytest aureom_h2_combustion/tests -q` (39 tests).

Runnable, plotting demos live in `aureom_h2_combustion/examples/`:

- `run_ice_example.py` — ICE test-cell run (see `sample_outputs/ice_summary.png`)
- `run_turbine_example.py` — turbine throttle transient (`sample_outputs/turbine_summary.png`)
- `run_vehicle_example.py` — full vehicle+drivetrain 0-100 km/h acceleration run (`sample_outputs/vehicle_acceleration.png`)
- `run_hybrid_example.py` — hybrid power-split & regen braking over a drive cycle (`sample_outputs/hybrid_drive_cycle.png`)

## Architecture

```
aureom_h2_combustion/
├── core/           simulation.py (orchestrator), engine_loop.py (per-timestep loop)
├── combustion/      hydrogen_combustion.py, flame_model.py, mixture_ratio.py
├── engines/         ice_engine.py (piston), turbine_engine.py (Brayton)
├── mechanical/       drivetrain.py, crankshaft.py, compressor.py
├── thermal/          heat_model.py, cooling_system.py
├── fuel_system/       hydrogen_injection.py, air_intake.py
├── vehicles/          car.py, truck.py, train.py
├── emissions/         nox_model.py, water_vapour.py
├── control/            ecu.py
├── hybrid/             hybrid_system.py
├── financials/          cost_model.py
├── utils/                constants.py, logging.py
├── examples/              runnable demo scripts + plotting.py
├── tests/                 pytest suite (39 tests)
└── main.py                 CLI entry point
```

`core.simulation.run_engine_simulation(...)` is the top-level entry point
matching the spec's reference call signature. It runs the deterministic
per-timestep loop:

```
for each timestep:
    compute fuel-air mixture        (control.ecu + combustion.mixture_ratio)
    simulate combustion event       (combustion.hydrogen_combustion)
    update pressure + temperature   (engines.ice_engine's Wiebe/Woschni ODE, or
                                      engines.turbine_engine's Brayton cycle)
    compute mechanical output       (mechanical.crankshaft / compressor)
    update drivetrain response      (mechanical.drivetrain, vehicles.*)
    apply thermal losses            (thermal.heat_model, thermal.cooling_system)
    update emissions                (emissions.nox_model, emissions.water_vapour)
    apply wear/degradation          (mechanical.crankshaft Archard wear model)
    log system state                (utils.logging.SimulationLogger)
```

## Methodology & references

Every non-trivial coefficient is traceable to a documented physical
source or a clearly-labelled calibrated engineering correlation:

- **Combustion thermochemistry**: exact stoichiometry (2 H2 + O2 -> 2 H2O),
  hydrogen LHV/HHV, energy-balance adiabatic flame temperature with a
  dissociation correction anchored to the well-documented ~2380 K
  stoichiometric H2-air flame temperature at STP.
- **Flame propagation**: Metghalchi-Keck-style laminar flame speed
  correlation, Damkohler turbulent augmentation.
- **ICE cycle**: single-zone, zero-dimensional closed-cycle model
  (Ferguson & Kirkpatrick, *Internal Combustion Engines: Applied
  Thermosciences*) — slider-crank geometry, Wiebe heat release, Woschni
  (1967) in-cylinder convective heat transfer, solved as an ODE in crank
  angle via `scipy.integrate.solve_ivp`. Torque is the exact virtual-work
  result T(θ) = (P - P₀)·dV/dθ.
- **Turbine cycle**: Brayton cycle (Saravanamuttoo, Rogers & Cohen, *Gas
  Turbine Theory*) with isentropic compressor/turbine relations and a
  primary-zone / dilution-zone combustor split for realistic NOx.
- **Thermal NOx**: extended Zeldovich mechanism, rate-limiting step
  (Turns, *An Introduction to Combustion*), with the atomic-oxygen
  partial-equilibrium concentration derived from the actual O2 <-> 2O
  dissociation equilibrium constant (anchored to the ~498 kJ/mol O2 bond
  energy) rather than a from-memory empirical fit.
- **Vehicle dynamics**: standard longitudinal dynamics (aero drag +
  rolling resistance + grade); rail resistance uses the classical Davis
  equation structure (A + Bv + Cv²).
- **Wear**: Archard's wear law for the crankshaft/bearing friction interface.
- **Economics**: standard levelised-cost-of-energy and break-even
  methodology.

### Known simplifications (documented, not hidden)

This is a systems-level / reduced-order simulator, not a CFD or full
chemical-kinetics (Cantera-class) solver:

- Combustion products use effective/blended specific heats rather than a
  full multi-species equilibrium solve; dissociation is captured via a
  calibrated correction rather than a Gibbs-minimisation.
- The ICE model is single-zone (no distinct burned/unburned zone
  temperature split) and simulates one representative cylinder per
  operating point (a standard "mean value" approach for systems-level
  sweeps), not a crank-resolved multi-cylinder torque-ripple model.
- Knock risk and combustion-efficiency/quenching curves are bounded
  [0,1] engineering heuristics, not a Livengood-Wu ignition-delay
  integral or detailed chemical-kinetics quenching model.
- H2 ICE load control is modelled as unthrottled, mixture-quality-based
  (lean-burn), matching common modern H2-ICE practice; a full
  throttle+quality blended strategy is not modelled.

## License

Provided as-is for engineering/research use.
