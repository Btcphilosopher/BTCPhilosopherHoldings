"""
Air intake system: volumetric efficiency model for naturally-aspirated
breathing, ideal-gas air density, and turbocharged boost integration via
the shared Compressor model.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from aureom_h2_combustion.mechanical.compressor import Compressor
from aureom_h2_combustion.utils.constants import AIR_GAS_CONSTANT


def air_density_kg_m3(pressure_pa: float, temperature_k: float) -> float:
    """Ideal gas law: rho = P / (R_specific * T)."""
    return pressure_pa / (AIR_GAS_CONSTANT * max(temperature_k, 1.0))


def volumetric_efficiency(rpm: float, wide_open_throttle: bool = True) -> float:
    """
    Naturally-aspirated volumetric efficiency vs. engine speed. Modelled as
    a bell curve peaking near the intake-runway resonant speed (~4500 RPM
    for a typical passenger-car length runner), tapering off at low RPM
    (poor cylinder filling time) and high RPM (flow/valve-timing losses).
    Representative of measured NA VE curves (typically 75-95%).
    """
    peak_rpm = 4500.0
    peak_ve = 0.94
    width = 3200.0
    ve = peak_ve * math.exp(-((rpm - peak_rpm) ** 2) / (2 * width ** 2))
    ve = max(ve, 0.45)
    if not wide_open_throttle:
        ve *= 0.55  # part-throttle pumping losses reduce effective filling
    return ve


@dataclass
class AirIntakeSystem:
    turbocharged: bool = False
    compressor: Compressor | None = None
    ambient_pressure_pa: float = 101_325.0
    ambient_temperature_k: float = 298.15
    intercooler_effectiveness: float = 0.7

    def manifold_conditions(self, mass_flow_kg_s: float, boost_pressure_ratio: float) -> tuple[float, float]:
        """Returns (manifold_pressure_pa, manifold_temperature_k)."""
        if not self.turbocharged or self.compressor is None or boost_pressure_ratio <= 1.0:
            return self.ambient_pressure_pa, self.ambient_temperature_k

        result = self.compressor.compress(
            self.ambient_temperature_k, self.ambient_pressure_pa, boost_pressure_ratio, mass_flow_kg_s
        )
        manifold_pressure = self.ambient_pressure_pa * result.pressure_ratio
        # Intercooler removes a fraction of the compression heat.
        t_cooled = result.exit_temperature_k - self.intercooler_effectiveness * (
            result.exit_temperature_k - self.ambient_temperature_k
        )
        return manifold_pressure, t_cooled

    def air_mass_per_cycle_kg(
        self,
        displacement_m3: float,
        rpm: float,
        boost_pressure_ratio: float = 1.0,
        wide_open_throttle: bool = True,
    ) -> float:
        """
        Air mass ingested per intake event = VE * V_displacement * rho.
        """
        manifold_p, manifold_t = self.manifold_conditions(0.0, boost_pressure_ratio)
        rho = air_density_kg_m3(manifold_p, manifold_t)
        ve = volumetric_efficiency(rpm, wide_open_throttle)
        return ve * displacement_m3 * rho
