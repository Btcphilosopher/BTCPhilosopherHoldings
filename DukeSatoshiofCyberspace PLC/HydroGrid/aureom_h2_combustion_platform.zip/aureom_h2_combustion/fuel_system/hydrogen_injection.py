"""
Hydrogen injector modelled as compressible (isentropic) nozzle flow through
a converging orifice -- the standard gas-dynamics treatment for direct or
port gaseous-hydrogen injection (see Anderson, "Modern Compressible Flow",
ch.3; used broadly in H2-ICE injector sizing literature).

Also models fuel-rail pressure dynamics (a finite-volume rail fed by a
regulator and drained by injection events), which is what produces
"fuel starvation" and "pressure instability" as emergent, deterministic
behaviour rather than as separate placeholder effects.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from aureom_h2_combustion.utils.constants import H2_GAS_CONSTANT

_GAMMA_H2 = 1.41
_CRITICAL_PRESSURE_RATIO = (2.0 / (_GAMMA_H2 + 1.0)) ** (_GAMMA_H2 / (_GAMMA_H2 - 1.0))


def injector_mass_flow_kg_s(
    discharge_coefficient: float,
    orifice_area_m2: float,
    upstream_pressure_pa: float,
    upstream_temperature_k: float,
    downstream_pressure_pa: float,
) -> float:
    """
    Mass flow rate of hydrogen through a converging injector orifice,
    handling both choked (sonic) and unchoked (subsonic) regimes.
    """
    if upstream_pressure_pa <= downstream_pressure_pa or upstream_pressure_pa <= 0:
        return 0.0

    pr = downstream_pressure_pa / upstream_pressure_pa
    rt = H2_GAS_CONSTANT * max(upstream_temperature_k, 1.0)

    if pr <= _CRITICAL_PRESSURE_RATIO:
        # Choked flow: throat velocity fixed at local sonic speed.
        flow_fn = math.sqrt(
            _GAMMA_H2 * (2.0 / (_GAMMA_H2 + 1.0)) ** ((_GAMMA_H2 + 1.0) / (_GAMMA_H2 - 1.0))
        )
    else:
        term = (pr ** (2.0 / _GAMMA_H2)) - (pr ** ((_GAMMA_H2 + 1.0) / _GAMMA_H2))
        term = max(term, 0.0)
        flow_fn = math.sqrt((2.0 * _GAMMA_H2 / (_GAMMA_H2 - 1.0)) * term)

    mdot = discharge_coefficient * orifice_area_m2 * upstream_pressure_pa / math.sqrt(rt) * flow_fn
    return max(mdot, 0.0)


@dataclass
class InjectorGeometry:
    discharge_coefficient: float = 0.85
    orifice_area_m2: float = 4.0e-6   # ~2.25 mm equivalent diameter
    max_duty_cycle: float = 0.92      # mechanical limit on injector open time fraction


@dataclass
class FuelRail:
    """
    Finite fuel-rail volume fed by a pressure regulator from the tank and
    drained by injection events. This is what makes fuel starvation and
    rail pressure instability genuine emergent dynamics: if injector
    demand outpaces regulator supply capacity, rail pressure sags and
    delivered flow drops below the commanded value.
    """

    volume_m3: float = 3.0e-4
    target_pressure_pa: float = 1.0e7   # 100 bar regulated rail pressure
    regulator_max_mass_flow_kg_s: float = 0.02
    pressure_pa: float = 1.0e7
    temperature_k: float = 298.15

    def regulator_supply_kg_s(self) -> float:
        """Regulator throttles supply proportionally to the rail pressure
        deficit, saturating at its maximum flow capacity."""
        deficit = max(self.target_pressure_pa - self.pressure_pa, 0.0)
        gain = 5.0e-9  # kg/s per Pa of deficit
        return min(deficit * gain, self.regulator_max_mass_flow_kg_s)

    def step(self, injector: InjectorGeometry, injector_open_fraction: float, downstream_pressure_pa: float, dt_s: float) -> float:
        """
        Advance rail pressure by dt_s and return the actual mass of
        hydrogen delivered to the cylinder this step (kg), which can fall
        short of demand under starvation conditions.
        """
        injector_open_fraction = max(0.0, min(injector_open_fraction, injector.max_duty_cycle))

        supply_kg_s = self.regulator_supply_kg_s()
        demand_mdot = injector_mass_flow_kg_s(
            injector.discharge_coefficient,
            injector.orifice_area_m2,
            self.pressure_pa,
            self.temperature_k,
            downstream_pressure_pa,
        )
        delivered_mdot = demand_mdot * injector_open_fraction
        delivered_kg = delivered_mdot * dt_s

        # Ideal-gas rail pressure update from net mass change (dP/dt = mdot*R*T/V).
        net_mdot = supply_kg_s - delivered_mdot
        d_pressure = net_mdot * H2_GAS_CONSTANT * self.temperature_k / self.volume_m3 * dt_s
        self.pressure_pa = max(self.pressure_pa + d_pressure, 1.0)

        return delivered_kg

    @property
    def is_starved(self) -> bool:
        return self.pressure_pa < 0.6 * self.target_pressure_pa
