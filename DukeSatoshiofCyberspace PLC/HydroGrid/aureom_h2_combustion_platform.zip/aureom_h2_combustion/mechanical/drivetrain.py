"""
Drivetrain: gearbox ratio selection, torque/speed conversion from engine
shaft to wheels, and driveline efficiency losses (gear mesh + final drive).
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Gearbox:
    gear_ratios: list[float] = field(default_factory=lambda: [4.23, 2.52, 1.66, 1.22, 1.0, 0.82])
    final_drive_ratio: float = 3.7
    mesh_efficiency_per_stage: float = 0.97
    current_gear_index: int = 0

    def overall_ratio(self, gear_index: int | None = None) -> float:
        idx = self.current_gear_index if gear_index is None else gear_index
        idx = max(0, min(idx, len(self.gear_ratios) - 1))
        return self.gear_ratios[idx] * self.final_drive_ratio

    def efficiency(self) -> float:
        # Two meshing stages (gearbox + final drive) in series.
        return self.mesh_efficiency_per_stage ** 2

    def wheel_torque_nm(self, engine_torque_nm: float, gear_index: int | None = None) -> float:
        return engine_torque_nm * self.overall_ratio(gear_index) * self.efficiency()

    def engine_speed_rad_s(self, wheel_speed_rad_s: float, gear_index: int | None = None) -> float:
        return wheel_speed_rad_s * self.overall_ratio(gear_index)

    def wheel_speed_rad_s(self, engine_speed_rad_s: float, gear_index: int | None = None) -> float:
        ratio = self.overall_ratio(gear_index)
        return engine_speed_rad_s / ratio if ratio > 0 else 0.0

    def select_gear_for_rpm_target(
        self, vehicle_speed_ms: float, wheel_radius_m: float, target_rpm_range: tuple[float, float]
    ) -> int:
        """
        Simple rule-based automatic-transmission logic: choose the highest
        gear that keeps engine RPM within the target band for the current
        road speed, falling back to the lowest gear at very low speed.
        """
        import math

        if vehicle_speed_ms <= 0.5:
            return 0
        wheel_omega = vehicle_speed_ms / wheel_radius_m
        best_gear = 0
        for idx in range(len(self.gear_ratios)):
            ratio = self.gear_ratios[idx] * self.final_drive_ratio
            engine_omega = wheel_omega * ratio
            engine_rpm = engine_omega * 60.0 / (2.0 * math.pi)
            if target_rpm_range[0] <= engine_rpm <= target_rpm_range[1]:
                best_gear = idx
        return best_gear


@dataclass(frozen=True)
class Wheel:
    radius_m: float
    rolling_resistance_coefficient: float = 0.011

    def drive_force_n(self, wheel_torque_nm: float) -> float:
        return wheel_torque_nm / self.radius_m

    def angular_speed_rad_s(self, linear_speed_ms: float) -> float:
        return linear_speed_ms / self.radius_m
