"""
Compressor stage model (shared by the turbocharger in the ICE fuel-air
system and the compressor stage of the gas-turbine engine).

Uses standard isentropic compression relations with an isentropic
efficiency correction (Cengel & Boles, "Thermodynamics: An Engineering
Approach"), plus a simplified surge-margin check against a linearised
compressor map.
"""
from __future__ import annotations

from dataclasses import dataclass

from aureom_h2_combustion.utils.constants import CP_AIR, GAMMA_AIR


@dataclass(frozen=True)
class CompressorResult:
    pressure_ratio: float
    exit_temperature_k: float
    ideal_exit_temperature_k: float
    specific_work_j_per_kg: float
    isentropic_efficiency: float
    surge_margin: float


def isentropic_exit_temperature_k(inlet_temperature_k: float, pressure_ratio: float) -> float:
    """T2s = T1 * PR^((gamma-1)/gamma) for an ideal (isentropic) compression."""
    return inlet_temperature_k * pressure_ratio ** ((GAMMA_AIR - 1.0) / GAMMA_AIR)


@dataclass
class Compressor:
    design_pressure_ratio: float = 2.2
    isentropic_efficiency: float = 0.78
    choke_mass_flow_kg_s: float = 0.5
    # Surge boundary expressed relative to the design pressure ratio: real
    # compressor maps show the surge line's pressure-ratio ceiling rising
    # with corrected flow (surge is triggered by high PR at LOW flow, not
    # the reverse), from a low fraction of design PR near zero flow up to
    # a margin above design PR at rated flow.
    surge_margin_at_rated_flow_ratio: float = 1.25
    surge_floor_fraction: float = 0.15

    def compress(self, inlet_temperature_k: float, inlet_pressure_pa: float, pressure_ratio: float, mass_flow_kg_s: float) -> CompressorResult:
        pressure_ratio = max(pressure_ratio, 1.0)
        t2s = isentropic_exit_temperature_k(inlet_temperature_k, pressure_ratio)
        ideal_work = CP_AIR * (t2s - inlet_temperature_k)
        actual_work = ideal_work / max(self.isentropic_efficiency, 1e-3)
        t2_actual = inlet_temperature_k + actual_work / CP_AIR

        # Linearised surge line (see field docs above); surge_margin > 0
        # means the operating point sits safely below the surge boundary.
        flow_fraction = min(mass_flow_kg_s / max(self.choke_mass_flow_kg_s, 1e-6), 1.0)
        surge_limit_pr = self.design_pressure_ratio * (
            self.surge_floor_fraction + (self.surge_margin_at_rated_flow_ratio - self.surge_floor_fraction) * flow_fraction
        )
        surge_margin = surge_limit_pr - pressure_ratio

        return CompressorResult(
            pressure_ratio=pressure_ratio,
            exit_temperature_k=t2_actual,
            ideal_exit_temperature_k=t2s,
            specific_work_j_per_kg=actual_work,
            isentropic_efficiency=self.isentropic_efficiency,
            surge_margin=surge_margin,
        )

    def shaft_power_w(self, result: CompressorResult, mass_flow_kg_s: float) -> float:
        return result.specific_work_j_per_kg * mass_flow_kg_s
