"""
Slider-crank geometry, in-cylinder torque via the virtual-work principle,
rotational shaft dynamics, mechanical friction and Archard wear modelling
for the piston/crankshaft assembly.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from aureom_h2_combustion.utils.constants import ARCHARD_WEAR_COEFFICIENT, STEEL_YIELD_STRENGTH


@dataclass(frozen=True)
class CrankGeometry:
    bore_m: float
    stroke_m: float
    conrod_length_m: float
    compression_ratio: float

    @property
    def crank_radius_m(self) -> float:
        return self.stroke_m / 2.0

    @property
    def piston_area_m2(self) -> float:
        return math.pi * (self.bore_m ** 2) / 4.0

    @property
    def displacement_volume_m3(self) -> float:
        return self.piston_area_m2 * self.stroke_m

    @property
    def clearance_volume_m3(self) -> float:
        # Vc = Vd / (CR - 1)
        return self.displacement_volume_m3 / (self.compression_ratio - 1.0)

    @property
    def rod_to_crank_ratio(self) -> float:
        return self.conrod_length_m / self.crank_radius_m

    def cylinder_volume_m3(self, theta_rad: float) -> float:
        """
        Instantaneous cylinder volume from slider-crank kinematics
        (Heywood eq. 2.3):
        V(theta) = Vc + (Vd/2) * (R + 1 - cos(theta) - sqrt(R^2 - sin^2(theta)))
        """
        r = self.rod_to_crank_ratio
        cos_t = math.cos(theta_rad)
        sin_t = math.sin(theta_rad)
        geom = r + 1.0 - cos_t - math.sqrt(max(r ** 2 - sin_t ** 2, 0.0))
        return self.clearance_volume_m3 + (self.displacement_volume_m3 / 2.0) * geom

    def dV_dtheta_m3_per_rad(self, theta_rad: float) -> float:
        """Analytic derivative of the slider-crank volume relation."""
        r = self.rod_to_crank_ratio
        sin_t = math.sin(theta_rad)
        cos_t = math.cos(theta_rad)
        denom = math.sqrt(max(r ** 2 - sin_t ** 2, 1e-9))
        return (self.displacement_volume_m3 / 2.0) * (sin_t + (sin_t * cos_t) / denom)


def instantaneous_gas_torque_nm(
    cylinder_pressure_pa: float,
    ambient_pressure_pa: float,
    dv_dtheta_m3_per_rad: float,
) -> float:
    """
    Torque delivered to the crankshaft by combustion-gas pressure, via the
    virtual-work principle: dW = (P - P0) dV = T dtheta, hence
    T(theta) = (P - P0) * dV/dtheta. Neglects piston/rod inertia reaction
    torque, which is handled separately by the rotational dynamics model.
    """
    return (cylinder_pressure_pa - ambient_pressure_pa) * dv_dtheta_m3_per_rad


@dataclass
class CrankshaftDynamics:
    """
    Lumped rotational-inertia model of crankshaft + flywheel + reciprocating
    assembly, including Coulomb + viscous + windage friction losses and
    Archard-law wear accumulation on the bearing/piston-ring interfaces.
    """

    rotational_inertia_kg_m2: float
    coulomb_friction_nm: float = 6.0
    viscous_friction_nm_per_rad_s: float = 0.012
    windage_coefficient_nm_per_rad2_s2: float = 4.0e-5

    omega_rad_s: float = 0.0
    cumulative_wear_fraction: float = 0.0
    operating_hours: float = 0.0

    def friction_torque_nm(self) -> float:
        omega = self.omega_rad_s
        coulomb = self.coulomb_friction_nm * math.copysign(1.0, omega) if omega != 0 else 0.0
        viscous = self.viscous_friction_nm_per_rad_s * omega
        windage = self.windage_coefficient_nm_per_rad2_s2 * omega * abs(omega)
        wear_penalty = 1.0 + 2.0 * self.cumulative_wear_fraction  # wear raises friction
        return (coulomb + viscous + windage) * wear_penalty

    def step(self, gas_torque_nm: float, load_torque_nm: float, dt_s: float, mean_contact_load_n: float = 0.0) -> None:
        """
        Integrate I * domega/dt = T_gas - T_load - T_friction, and accrue
        Archard-law wear: dW/dt = k * F_contact * sliding_velocity / hardness.
        """
        friction = self.friction_torque_nm()
        net_torque = gas_torque_nm - load_torque_nm - friction
        domega = net_torque / self.rotational_inertia_kg_m2 * dt_s
        self.omega_rad_s = max(self.omega_rad_s + domega, 0.0)

        sliding_velocity = abs(self.omega_rad_s) * 0.02  # ~journal radius (m)
        hardness_pa = STEEL_YIELD_STRENGTH * 3.0  # Vickers hardness proxy
        wear_rate = (
            ARCHARD_WEAR_COEFFICIENT * max(mean_contact_load_n, 0.0) * sliding_velocity / hardness_pa
        )
        self.cumulative_wear_fraction = min(self.cumulative_wear_fraction + wear_rate * dt_s, 1.0)
        self.operating_hours += dt_s / 3600.0

    @property
    def rpm(self) -> float:
        return self.omega_rad_s * 60.0 / (2.0 * math.pi)

    @property
    def mechanical_efficiency(self) -> float:
        """Degrades with accumulated wear."""
        return max(0.0, 1.0 - 0.35 * self.cumulative_wear_fraction)


def rpm_to_omega(rpm: float) -> float:
    return rpm * 2.0 * math.pi / 60.0


def omega_to_rpm(omega_rad_s: float) -> float:
    return omega_rad_s * 60.0 / (2.0 * math.pi)
