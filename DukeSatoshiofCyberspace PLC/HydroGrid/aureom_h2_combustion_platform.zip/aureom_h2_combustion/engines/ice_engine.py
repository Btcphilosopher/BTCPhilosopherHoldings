"""
Hydrogen-fuelled piston internal combustion engine: a zero-dimensional,
single-zone closed-cycle model (Ferguson & Kirkpatrick, "Internal
Combustion Engines: Applied Thermosciences", ch.4-9) coupling:

  * slider-crank geometry (mechanical.crankshaft)
  * Wiebe-function heat release, sized from the flame-propagation model
  * Woschni in-cylinder convective heat transfer (thermal.heat_model)
  * the hydrogen combustion event model (combustion.hydrogen_combustion)

for one representative thermodynamic cycle per operating point (RPM,
load), which the outer simulation loop calls once per timestep to obtain
instantaneous torque/power/thermal/emissions state -- a standard "mean
value" approach for systems-level engine simulation.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
from scipy.integrate import solve_ivp

from aureom_h2_combustion.combustion.flame_model import flame_propagation
from aureom_h2_combustion.combustion.hydrogen_combustion import CombustionResult, simulate_combustion_event
from aureom_h2_combustion.combustion.mixture_ratio import MixtureState
from aureom_h2_combustion.emissions.nox_model import nox_from_combustion_event
from aureom_h2_combustion.emissions.water_vapour import water_vapour_mass_kg
from aureom_h2_combustion.fuel_system.air_intake import AirIntakeSystem
from aureom_h2_combustion.mechanical.crankshaft import CrankGeometry, instantaneous_gas_torque_nm, rpm_to_omega
from aureom_h2_combustion.thermal.heat_model import woschni_heat_transfer_coefficient
from aureom_h2_combustion.utils.constants import (
    ATM_PRESSURE,
    ATM_TEMPERATURE,
    GAMMA_AIR,
)

_GAMMA_BURNED_PRODUCTS = 1.30   # hot H2O/N2-rich combustion products
_WIEBE_A = 5.0                  # standard Wiebe efficiency parameter
_WIEBE_M = 2.0                  # shape factor (SI engine, typical 2-3)


@dataclass(frozen=True)
class ICEConfig:
    displacement_l: float = 2.0
    num_cylinders: int = 4
    bore_stroke_ratio: float = 1.0
    compression_ratio: float = 12.0     # H2 ICE typically runs higher CR than gasoline
    conrod_to_crank_ratio: float = 3.5
    ignition_timing_btdc_deg: float = 18.0
    target_lambda: float = 1.4          # lambda at rated (high) load
    light_load_lambda: float = 2.2      # lambda at light load -- H2 ICEs commonly use
                                         # unthrottled, mixture-quality ("lean-burn") load
                                         # control instead of airflow throttling, since H2's
                                         # wide flammability range makes this practical and
                                         # avoids pumping losses.
    turbocharged: bool = False
    boost_pressure_ratio: float = 1.0

    def lambda_for_load(self, load: float) -> float:
        load = max(0.0, min(load, 1.0))
        return self.light_load_lambda - (self.light_load_lambda - self.target_lambda) * load

    def geometry(self) -> CrankGeometry:
        vd_cyl = (self.displacement_l * 1e-3) / self.num_cylinders
        # Solve bore from Vd = (pi/4) B^2 * S, S = bore_stroke_ratio * B
        bore = (4.0 * vd_cyl / (math.pi * self.bore_stroke_ratio)) ** (1.0 / 3.0)
        stroke = self.bore_stroke_ratio * bore
        crank_radius = stroke / 2.0
        conrod = self.conrod_to_crank_ratio * crank_radius
        return CrankGeometry(bore, stroke, conrod, self.compression_ratio)


@dataclass(frozen=True)
class ICECycleResult:
    rpm: float
    load: float
    imep_pa: float
    indicated_torque_nm: float
    indicated_power_w: float
    peak_pressure_pa: float
    peak_temperature_k: float
    combustion: CombustionResult
    mixture: MixtureState
    heat_rejected_to_walls_j: float
    nox_ppm: float
    water_vapour_kg: float
    knock_risk: float  # 0..1 heuristic knock likelihood this cycle
    theta_deg: np.ndarray = field(repr=False)
    pressure_pa: np.ndarray = field(repr=False)


class ICEEngine:
    def __init__(self, config: ICEConfig, air_intake: AirIntakeSystem | None = None):
        self.config = config
        self.geometry = config.geometry()
        self.air_intake = air_intake or AirIntakeSystem(turbocharged=config.turbocharged)

    # ------------------------------------------------------------------
    def _wiebe_xb(self, theta: np.ndarray, theta_start: float, duration: float) -> np.ndarray:
        x = np.clip((theta - theta_start) / max(duration, 1e-6), 0.0, None)
        xb = 1.0 - np.exp(-_WIEBE_A * x ** (_WIEBE_M + 1.0))
        xb = np.where(theta < theta_start, 0.0, xb)
        return np.clip(xb, 0.0, 1.0)

    def _wiebe_dxb_dtheta(self, theta: np.ndarray, theta_start: float, duration: float) -> np.ndarray:
        x = (theta - theta_start) / max(duration, 1e-6)
        x = np.clip(x, 0.0, None)
        dxb = (
            _WIEBE_A * (_WIEBE_M + 1.0) / max(duration, 1e-6)
            * x ** _WIEBE_M
            * np.exp(-_WIEBE_A * x ** (_WIEBE_M + 1.0))
        )
        dxb = np.where((theta < theta_start), 0.0, dxb)
        return dxb

    # ------------------------------------------------------------------
    def run_cycle(
        self,
        rpm: float,
        load: float,
        wall_temperature_k: float = 373.15,
        ambient_pressure_pa: float = ATM_PRESSURE,
        ambient_temperature_k: float = ATM_TEMPERATURE,
        mixing_quality: float = 1.0,
        lambda_override: float | None = None,
        ignition_timing_btdc_override: float | None = None,
    ) -> ICECycleResult:
        """
        Simulate one closed-cycle (IVC -> EVO, i.e. -180 to +180 crank
        degrees about combustion TDC) thermodynamic cycle for a single
        cylinder at the given operating point, and scale results to the
        full engine.
        """
        load = max(0.0, min(load, 1.0))
        rpm = max(rpm, 50.0)
        omega = rpm_to_omega(rpm)

        # --- Charge: air per cylinder per cycle, then fuel from target lambda.
        # H2 ICEs are commonly run unthrottled (air charge set by breathing/
        # boost, not a throttle plate), with load instead controlled by
        # mixture quality (lambda) -- this keeps the intake state (P, T)
        # physically consistent regardless of commanded load, which a
        # naive post-hoc air-mass scale-down would break (it would leave
        # the initial cylinder pressure inconsistent with the reduced
        # charge mass at fixed volume, via the ideal gas law).
        boost_pr = 1.0 + (self.config.boost_pressure_ratio - 1.0) * load if self.config.turbocharged else 1.0
        air_mass = self.air_intake.air_mass_per_cycle_kg(
            self.geometry.displacement_volume_m3, rpm, boost_pr, wide_open_throttle=True
        )

        target_lambda = lambda_override if lambda_override is not None else self.config.lambda_for_load(load)
        fuel_mass = air_mass / (target_lambda * self._stoich_afr())
        mixture = MixtureState(air_mass_kg=air_mass, fuel_mass_kg=fuel_mass)

        manifold_p, manifold_t = self.air_intake.manifold_conditions(0.0, boost_pr)

        # Unburned-gas state at the point of ignition (post-compression),
        # via the isentropic compression relation T2 = T1 * CR^(gamma-1) --
        # this, not the raw intake-manifold temperature, is the actual
        # thermodynamic starting point for the combustion event and is
        # what determines a realistic in-cylinder adiabatic flame
        # temperature (and hence NOx).
        t_at_ignition = manifold_t * self.config.compression_ratio ** (GAMMA_AIR - 1.0)
        p_at_ignition = manifold_p * self.config.compression_ratio ** GAMMA_AIR

        combustion = simulate_combustion_event(mixture, t_at_ignition, mixing_quality)

        # --- Flame propagation -> Wiebe combustion duration.
        prop = flame_propagation(
            mixture.equivalence_ratio,
            t_at_ignition,
            p_at_ignition,
            characteristic_length_m=self.geometry.bore_m / 2.0,
            turbulence_intensity_ms=omega * self.geometry.crank_radius_m * 0.3,
        )
        duration_rad = max(omega * prop.burn_duration_s, math.radians(15.0))
        duration_rad = min(duration_rad, math.radians(90.0))

        ignition_btdc = (
            ignition_timing_btdc_override if ignition_timing_btdc_override is not None
            else self.config.ignition_timing_btdc_deg
        )
        theta_ign = -math.radians(ignition_btdc)

        q_total = combustion.heat_released_j
        wall_area_head_piston = 2.0 * self.geometry.piston_area_m2

        gas_const_eff = 300.0  # J/(kg.K), blended air/H2O/N2 effective specific gas constant

        def rhs(theta, y):
            p, _q_comb_so_far, _q_wall_so_far = y
            v = self.geometry.cylinder_volume_m3(theta)
            dv = self.geometry.dV_dtheta_m3_per_rad(theta)
            xb = float(self._wiebe_xb(np.array([theta]), theta_ign, duration_rad)[0])
            dxb = float(self._wiebe_dxb_dtheta(np.array([theta]), theta_ign, duration_rad)[0])
            gamma = GAMMA_AIR * (1.0 - xb) + _GAMMA_BURNED_PRODUCTS * xb

            dq_comb_dtheta = q_total * dxb

            # Wall heat loss via Woschni correlation.
            gas_temp = max(p * v / (mixture.total_mass_kg * gas_const_eff), 200.0)
            mean_piston_speed = 2.0 * self.geometry.stroke_m * rpm / 60.0
            h = woschni_heat_transfer_coefficient(
                self.geometry.bore_m,
                p,
                ambient_pressure_pa * (v / self.geometry.cylinder_volume_m3(theta_ign)) ** -GAMMA_AIR,
                gas_temp,
                mean_piston_speed,
                self.geometry.displacement_volume_m3,
                ambient_pressure_pa,
                ambient_temperature_k,
                self.geometry.cylinder_volume_m3(0.0),
            )
            liner_height = max((v - self.geometry.clearance_volume_m3) / self.geometry.piston_area_m2, 0.0)
            wall_area = wall_area_head_piston + math.pi * self.geometry.bore_m * liner_height
            q_wall_dot = h * wall_area * (gas_temp - wall_temperature_k)
            dq_wall_dtheta = q_wall_dot / omega

            dp_dtheta = (
                -gamma * p / v * dv
                + (gamma - 1.0) / v * (dq_comb_dtheta - dq_wall_dtheta)
            )
            return [dp_dtheta, dq_comb_dtheta, dq_wall_dtheta]

        theta0 = -math.pi
        p0 = manifold_p
        sol = solve_ivp(
            rhs,
            (theta0, math.pi),
            y0=[p0, 0.0, 0.0],
            max_step=math.radians(1.0),
            method="RK45",
            dense_output=False,
        )

        theta = sol.t
        pressure = np.maximum(sol.y[0], 1000.0)
        heat_wall_cumulative_j = max(float(sol.y[2][-1]), 0.0)

        volume = np.array([self.geometry.cylinder_volume_m3(th) for th in theta])
        dv = np.array([self.geometry.dV_dtheta_m3_per_rad(th) for th in theta])

        # Net indicated work per cycle: W = ∮ P dV = ∫ P dV/dtheta dtheta
        work_j = float(np.trapezoid(pressure * dv, theta))
        imep_pa = work_j / self.geometry.displacement_volume_m3

        gas_torque = instantaneous_gas_torque_nm(pressure, ambient_pressure_pa, dv)
        # 4-stroke: one power stroke per 2 crankshaft revolutions (4*pi rad
        # total); this closed-cycle window only spans compression+expansion
        # (2*pi rad), so the work done is averaged over the full 4*pi cycle
        # (the intake/exhaust strokes contribute ~zero net indicated work).
        indicated_torque_percyl = float(np.trapezoid(gas_torque, theta) / (4.0 * math.pi))

        indicated_torque_total = indicated_torque_percyl * self.config.num_cylinders
        indicated_power_w = indicated_torque_total * omega

        peak_pressure = float(np.max(pressure))
        peak_temp = float(np.max(pressure * volume / (mixture.total_mass_kg * gas_const_eff)))

        # Knock heuristic: end-gas autoignition risk rises with unburned-gas
        # temperature ahead of the flame (proxied by the post-compression
        # temperature) and with peak cylinder pressure (which shortens
        # autoignition delay), and falls as the mixture leans out (H2's
        # knock resistance improves markedly lean of stoichiometric due to
        # lower flame/end-gas temperature). This is a bounded [0,1]
        # engineering proxy, not a Livengood-Wu ignition-delay integral.
        from aureom_h2_combustion.utils.constants import H2_AUTOIGNITION_TEMPERATURE

        lean_margin = max(mixture.lambda_ - 1.0, 0.0)
        effective_threshold_k = 0.80 * H2_AUTOIGNITION_TEMPERATURE * (1.0 + 0.12 * lean_margin)
        span_k = 0.20 * H2_AUTOIGNITION_TEMPERATURE
        base_risk = (t_at_ignition - effective_threshold_k) / span_k
        pressure_factor = min(max(peak_pressure / 50e5, 0.3), 2.0)
        knock_risk = max(0.0, min(base_risk * pressure_factor, 1.0))

        nox_ppm = nox_from_combustion_event(combustion, mixture, peak_pressure)
        water_kg = water_vapour_mass_kg(combustion.fuel_burned_kg) * self.config.num_cylinders

        return ICECycleResult(
            rpm=rpm,
            load=load,
            imep_pa=imep_pa,
            indicated_torque_nm=indicated_torque_total,
            indicated_power_w=indicated_power_w,
            peak_pressure_pa=peak_pressure,
            peak_temperature_k=peak_temp,
            combustion=combustion,
            mixture=mixture,
            heat_rejected_to_walls_j=heat_wall_cumulative_j * self.config.num_cylinders,
            nox_ppm=nox_ppm,
            water_vapour_kg=water_kg,
            knock_risk=knock_risk,
            theta_deg=np.degrees(theta),
            pressure_pa=pressure,
        )

    def _stoich_afr(self) -> float:
        from aureom_h2_combustion.utils.constants import STOICHIOMETRIC_AFR_MASS

        return STOICHIOMETRIC_AFR_MASS

    def cycles_per_second(self, rpm: float) -> float:
        """4-stroke: one thermodynamic cycle per 2 crankshaft revolutions."""
        return (rpm / 60.0) / 2.0
