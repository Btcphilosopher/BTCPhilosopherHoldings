"""
Hydrogen-fuelled gas turbine (Brayton-cycle) engine.

Single-shaft simple-cycle model: ambient air is compressed, hydrogen is
injected and burned in the combustor to reach a (material-limited) turbine
inlet temperature, and the hot gas expands through the turbine -- part of
whose work drives the compressor, with the remainder delivered as net
shaft power (or, for a two-shaft "free turbine" configuration, delivered
entirely to an independent power turbine downstream of the gas generator).

    Power = mass_flow_rate * enthalpy_drop      (turbine work extraction)

Reference: Saravanamuttoo, Rogers & Cohen, "Gas Turbine Theory".
"""
from __future__ import annotations

from dataclasses import dataclass

from aureom_h2_combustion.combustion.hydrogen_combustion import combustion_efficiency
from aureom_h2_combustion.combustion.mixture_ratio import MixtureState
from aureom_h2_combustion.emissions.nox_model import burned_gas_composition, nox_concentration_ppm
from aureom_h2_combustion.emissions.water_vapour import water_vapour_mass_kg
from aureom_h2_combustion.mechanical.compressor import Compressor
from aureom_h2_combustion.utils.constants import ATM_PRESSURE, ATM_TEMPERATURE, H2_LHV

_GAMMA_HOT_GAS = 1.33   # combustion products (N2 + H2O rich), lower than cold air
_CP_HOT_GAS = 1150.0    # J/(kg.K), effective specific heat of hot gas path


@dataclass(frozen=True)
class TurbineConfig:
    design_pressure_ratio: float = 14.0
    compressor_isentropic_efficiency: float = 0.85
    turbine_isentropic_efficiency: float = 0.88
    max_turbine_inlet_temperature_k: float = 1650.0   # material limit (with cooling)
    air_mass_flow_kg_s: float = 20.0
    mechanical_efficiency: float = 0.985
    two_shaft: bool = True   # free-power-turbine configuration
    combustor_pressure_loss_fraction: float = 0.04
    primary_zone_equivalence_ratio: float = 0.65   # lean-premixed primary flame
                                                    # zone (H2's wide flammability
                                                    # range makes ultra-lean premixed
                                                    # "dry low-NOx" combustion
                                                    # practical, unlike diffusion
                                                    # flames run near phi=1); only
                                                    # this fraction of the total
                                                    # airflow passes through the hot
                                                    # flame core before dilution air
                                                    # brings the bulk flow down to T3.


def turbine_isentropic_exit_temperature_k(inlet_temperature_k: float, pressure_ratio_drop: float) -> float:
    return inlet_temperature_k * pressure_ratio_drop ** ((_GAMMA_HOT_GAS - 1.0) / _GAMMA_HOT_GAS)


@dataclass(frozen=True)
class TurbineCycleResult:
    shaft_power_w: float
    gas_generator_power_w: float
    compressor_work_w: float
    combustor_work_w: float
    fuel_flow_kg_s: float
    turbine_inlet_temperature_k: float
    exhaust_temperature_k: float
    thermal_efficiency: float
    nox_ppm: float
    water_vapour_kg_s: float
    combustion_efficiency: float
    surge_margin: float


class TurbineEngine:
    def __init__(self, config: TurbineConfig, compressor: Compressor | None = None):
        self.config = config
        self.compressor = compressor or Compressor(
            design_pressure_ratio=config.design_pressure_ratio,
            isentropic_efficiency=config.compressor_isentropic_efficiency,
            # Choke flow sized to this engine's actual rated airflow (the
            # Compressor class default is tuned for a small automotive
            # turbocharger -- a few hundred g/s -- not a multi-kg/s
            # turbine spool).
            choke_mass_flow_kg_s=config.air_mass_flow_kg_s * 1.15,
        )

    @staticmethod
    def _stoich_afr() -> float:
        from aureom_h2_combustion.utils.constants import STOICHIOMETRIC_AFR_MASS

        return STOICHIOMETRIC_AFR_MASS

    def run(
        self,
        throttle: float,
        ambient_pressure_pa: float = ATM_PRESSURE,
        ambient_temperature_k: float = ATM_TEMPERATURE,
        mixing_quality: float = 1.0,
    ) -> TurbineCycleResult:
        throttle = max(0.02, min(throttle, 1.0))
        mdot_air = self.config.air_mass_flow_kg_s * (0.55 + 0.45 * throttle)

        pressure_ratio = 1.0 + (self.config.design_pressure_ratio - 1.0) * throttle
        comp_result = self.compressor.compress(ambient_temperature_k, ambient_pressure_pa, pressure_ratio, mdot_air)
        compressor_work_w = self.compressor.shaft_power_w(comp_result, mdot_air)

        t3_target = ambient_temperature_k + (self.config.max_turbine_inlet_temperature_k - ambient_temperature_k) * throttle
        t3_target = min(t3_target, self.config.max_turbine_inlet_temperature_k)

        t2 = comp_result.exit_temperature_k
        delta_t_required = max(t3_target - t2, 0.0)

        # Combustion completeness is governed by conditions in the hot
        # primary flame zone (a near-design lean-premixed equivalence
        # ratio), not by the fully-diluted bulk mixture -- the bulk
        # air:fuel ratio in a gas turbine combustor is always very lean
        # (most of the compressor air bypasses the flame as dilution/
        # cooling air), so using it here would (incorrectly) predict
        # near-total combustion failure at every operating point.
        eta_comb = combustion_efficiency(self.config.primary_zone_equivalence_ratio, mixing_quality)

        # Energy balance across the combustor: mdot_fuel*LHV*eta = (mdot_air+mdot_fuel)*cp*(T3-T2)
        # solved for mdot_fuel (fuel mass addition to flow included for fidelity).
        if delta_t_required <= 0 or eta_comb <= 0:
            mdot_fuel = 0.0
        else:
            numerator = mdot_air * _CP_HOT_GAS * delta_t_required
            denominator = H2_LHV * eta_comb - _CP_HOT_GAS * delta_t_required
            mdot_fuel = numerator / max(denominator, 1e-6)
            mdot_fuel = max(mdot_fuel, 0.0)

        mdot_total = mdot_air + mdot_fuel
        combustor_work_w = mdot_fuel * H2_LHV * eta_comb

        p3 = ambient_pressure_pa * pressure_ratio * (1.0 - self.config.combustor_pressure_loss_fraction)

        if self.config.two_shaft:
            # Gas-generator turbine expands just enough to supply compressor
            # work (its extracted specific work equals the compressor's
            # specific work demand); the resulting temperature drop fixes
            # its exit state, which becomes the free power-turbine's inlet.
            gg_specific_work_needed = compressor_work_w / max(mdot_total, 1e-9)
            t4_gg = t3_target - gg_specific_work_needed / _CP_HOT_GAS

            # Remaining pressure available drives the free power turbine.
            p4_gg = p3 * (t4_gg / t3_target) ** (_GAMMA_HOT_GAS / (_GAMMA_HOT_GAS - 1.0)) \
                if t3_target > 0 else p3
            p_exit = ambient_pressure_pa
            pr_power_turbine = max(p4_gg / p_exit, 1.0)
            t5s = turbine_isentropic_exit_temperature_k(t4_gg, 1.0 / pr_power_turbine)
            ideal_pt_work_per_kg = _CP_HOT_GAS * (t4_gg - t5s)
            actual_pt_work_per_kg = ideal_pt_work_per_kg * self.config.turbine_isentropic_efficiency
            shaft_power_w = actual_pt_work_per_kg * mdot_total * self.config.mechanical_efficiency
            exhaust_temp = t4_gg - actual_pt_work_per_kg / _CP_HOT_GAS
            gas_generator_power_w = compressor_work_w
        else:
            pr_total = pressure_ratio
            t4s = turbine_isentropic_exit_temperature_k(t3_target, 1.0 / pr_total)
            ideal_work_per_kg = _CP_HOT_GAS * (t3_target - t4s)
            actual_work_per_kg = ideal_work_per_kg * self.config.turbine_isentropic_efficiency
            turbine_work_w = actual_work_per_kg * mdot_total
            shaft_power_w = max(turbine_work_w - compressor_work_w, 0.0) * self.config.mechanical_efficiency
            exhaust_temp = t3_target - actual_work_per_kg / _CP_HOT_GAS
            gas_generator_power_w = compressor_work_w

        fuel_energy_w = mdot_fuel * H2_LHV
        thermal_efficiency = shaft_power_w / fuel_energy_w if fuel_energy_w > 0 else 0.0

        # NOx forms in the hot primary flame zone, not in the fully-diluted
        # bulk flow at T3 -- only a fraction of the total compressor air
        # passes through the flame core (the rest is dilution/cooling air
        # added downstream), so the flame-zone mixture is much closer to
        # the design primary-zone equivalence ratio than mdot_air:mdot_fuel
        # would suggest.
        primary_zone_air_kg = mdot_fuel * self._stoich_afr() / max(self.config.primary_zone_equivalence_ratio, 1e-3)
        primary_zone_air_kg = min(primary_zone_air_kg, mdot_air)
        primary_mixture = MixtureState(air_mass_kg=primary_zone_air_kg, fuel_mass_kg=max(mdot_fuel, 1e-9))
        from aureom_h2_combustion.combustion.hydrogen_combustion import simulate_combustion_event

        combustion_result = simulate_combustion_event(primary_mixture, t2, mixing_quality)
        comp_gas = burned_gas_composition(combustion_result, primary_mixture)
        nox_ppm = nox_concentration_ppm(
            combustion_result.adiabatic_flame_temperature_k,
            comp_gas.o2_mole_fraction,
            comp_gas.n2_mole_fraction,
            p3,
        )
        water_kg_s = water_vapour_mass_kg(mdot_fuel)

        return TurbineCycleResult(
            shaft_power_w=shaft_power_w,
            gas_generator_power_w=gas_generator_power_w,
            compressor_work_w=compressor_work_w,
            combustor_work_w=combustor_work_w,
            fuel_flow_kg_s=mdot_fuel,
            turbine_inlet_temperature_k=t3_target,
            exhaust_temperature_k=exhaust_temp,
            thermal_efficiency=max(0.0, min(thermal_efficiency, 0.6)),
            nox_ppm=nox_ppm,
            water_vapour_kg_s=water_kg_s,
            combustion_efficiency=eta_comb,
            surge_margin=comp_result.surge_margin,
        )
