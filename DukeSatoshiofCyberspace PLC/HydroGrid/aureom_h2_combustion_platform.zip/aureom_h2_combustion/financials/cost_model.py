"""
Economic & operations model: fuel cost, levelised cost of energy,
maintenance scheduling, wear-driven degradation cost, fleet-level
aggregation, and break-even analysis against a fossil-fuel baseline.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class FuelEconomics:
    hydrogen_price_per_kg: float = 6.5     # USD/kg (representative 2020s dispensed price)
    diesel_price_per_l: float = 1.45       # USD/L
    diesel_energy_density_j_per_l: float = 35.8e6
    grid_electricity_price_per_kwh: float = 0.15  # USD/kWh, for hybrid battery charging


@dataclass(frozen=True)
class MaintenanceSchedule:
    service_interval_hours: float = 500.0
    service_cost_usd: float = 350.0
    major_overhaul_interval_hours: float = 8000.0
    major_overhaul_cost_usd: float = 12_000.0
    capital_cost_usd: float = 45_000.0     # engine + fuel system + tanks
    design_life_hours: float = 20_000.0

    def maintenance_cost_over(self, operating_hours: float) -> float:
        n_services = operating_hours // self.service_interval_hours
        n_overhauls = operating_hours // self.major_overhaul_interval_hours
        return n_services * self.service_cost_usd + n_overhauls * self.major_overhaul_cost_usd

    def amortised_capital_cost_per_hour(self) -> float:
        return self.capital_cost_usd / max(self.design_life_hours, 1e-6)

    def degradation_cost_per_hour(self, wear_fraction: float) -> float:
        """
        Cost of consumed engine life attributable to accumulated
        mechanical wear (Archard-law wear fraction from the crankshaft
        model), amortising replacement cost against fractional life used.
        """
        return wear_fraction * self.capital_cost_usd / max(self.design_life_hours, 1e-6)


def hydrogen_fuel_cost(fuel_mass_kg: float, economics: FuelEconomics) -> float:
    return fuel_mass_kg * economics.hydrogen_price_per_kg


def diesel_equivalent_cost(energy_j: float, economics: FuelEconomics, engine_efficiency: float = 0.38) -> float:
    """Cost of delivering the same useful (shaft) energy via a diesel
    engine of the given brake thermal efficiency."""
    fuel_energy_required_j = energy_j / max(engine_efficiency, 1e-6)
    litres = fuel_energy_required_j / economics.diesel_energy_density_j_per_l
    return litres * economics.diesel_price_per_l


@dataclass(frozen=True)
class OperatingCostBreakdown:
    fuel_cost_usd: float
    maintenance_cost_usd: float
    degradation_cost_usd: float
    capital_amortisation_usd: float
    total_cost_usd: float
    energy_delivered_kwh: float
    cost_per_kwh: float


def cost_per_kwh(
    fuel_mass_kg: float,
    operating_hours: float,
    wear_fraction: float,
    energy_delivered_j: float,
    economics: FuelEconomics,
    maintenance: MaintenanceSchedule,
) -> OperatingCostBreakdown:
    fuel_cost = hydrogen_fuel_cost(fuel_mass_kg, economics)
    maint_cost = maintenance.maintenance_cost_over(operating_hours)
    degradation_cost = maintenance.degradation_cost_per_hour(wear_fraction) * operating_hours
    capital_cost = maintenance.amortised_capital_cost_per_hour() * operating_hours

    total = fuel_cost + maint_cost + degradation_cost + capital_cost
    energy_kwh = energy_delivered_j / 3.6e6
    per_kwh = total / energy_kwh if energy_kwh > 1e-9 else float("inf")

    return OperatingCostBreakdown(
        fuel_cost_usd=fuel_cost,
        maintenance_cost_usd=maint_cost,
        degradation_cost_usd=degradation_cost,
        capital_amortisation_usd=capital_cost,
        total_cost_usd=total,
        energy_delivered_kwh=energy_kwh,
        cost_per_kwh=per_kwh,
    )


@dataclass(frozen=True)
class BreakEvenResult:
    breakeven_hours: float | None
    breakeven_energy_kwh: float | None
    h2_total_cost_per_hour: float
    diesel_total_cost_per_hour: float
    upfront_cost_delta_usd: float


def breakeven_vs_diesel(
    h2_maintenance: MaintenanceSchedule,
    diesel_capital_cost_usd: float,
    diesel_maintenance_cost_per_hour: float,
    average_power_w: float,
    economics: FuelEconomics,
    h2_engine_efficiency: float = 0.42,
    diesel_engine_efficiency: float = 0.38,
) -> BreakEvenResult:
    """
    Solve for the operating-hours crossover at which cumulative hydrogen
    system cost (higher upfront capital, cheaper-per-unit maintenance,
    variable fuel cost) equals cumulative diesel system cost.
    """
    fuel_energy_required_w = average_power_w / max(h2_engine_efficiency, 1e-6)
    from aureom_h2_combustion.utils.constants import H2_LHV

    h2_mass_flow_kg_s = fuel_energy_required_w / H2_LHV
    h2_fuel_cost_per_hour = h2_mass_flow_kg_s * 3600.0 * economics.hydrogen_price_per_kg
    h2_capital_amortised_per_hour = h2_maintenance.amortised_capital_cost_per_hour()
    h2_maintenance_per_hour = h2_maintenance.service_cost_usd / h2_maintenance.service_interval_hours
    h2_total_per_hour = h2_fuel_cost_per_hour + h2_capital_amortised_per_hour + h2_maintenance_per_hour

    diesel_energy_required_w = average_power_w / max(diesel_engine_efficiency, 1e-6)
    diesel_litres_per_hour = diesel_energy_required_w * 3600.0 / economics.diesel_energy_density_j_per_l
    diesel_fuel_cost_per_hour = diesel_litres_per_hour * economics.diesel_price_per_l
    diesel_capital_amortised_per_hour = diesel_capital_cost_usd / max(h2_maintenance.design_life_hours, 1e-6)
    diesel_total_per_hour = diesel_fuel_cost_per_hour + diesel_capital_amortised_per_hour + diesel_maintenance_cost_per_hour

    upfront_delta = h2_maintenance.capital_cost_usd - diesel_capital_cost_usd
    running_cost_delta_per_hour = diesel_total_per_hour - h2_total_per_hour  # savings/hour from switching to H2

    if running_cost_delta_per_hour <= 0 or upfront_delta <= 0:
        breakeven_hours = None if upfront_delta > 0 else 0.0
    else:
        breakeven_hours = upfront_delta / running_cost_delta_per_hour

    breakeven_energy_kwh = (
        breakeven_hours * average_power_w / 1000.0 if breakeven_hours is not None else None
    )

    return BreakEvenResult(
        breakeven_hours=breakeven_hours,
        breakeven_energy_kwh=breakeven_energy_kwh,
        h2_total_cost_per_hour=h2_total_per_hour,
        diesel_total_cost_per_hour=diesel_total_per_hour,
        upfront_cost_delta_usd=upfront_delta,
    )


@dataclass
class FleetVehicle:
    name: str
    annual_operating_hours: float
    average_power_w: float


@dataclass
class FleetOptimizer:
    """Fleet-level cost/energy aggregation across multiple vehicles or
    generator units sharing common fuel and maintenance economics."""

    vehicles: list[FleetVehicle] = field(default_factory=list)
    economics: FuelEconomics = field(default_factory=FuelEconomics)
    maintenance: MaintenanceSchedule = field(default_factory=MaintenanceSchedule)
    engine_efficiency: float = 0.42

    def annual_fleet_cost(self) -> dict:
        from aureom_h2_combustion.utils.constants import H2_LHV

        total_fuel_cost = 0.0
        total_maintenance_cost = 0.0
        total_energy_kwh = 0.0
        per_vehicle = []

        for v in self.vehicles:
            energy_j = v.average_power_w * v.annual_operating_hours * 3600.0
            fuel_energy_j = energy_j / self.engine_efficiency
            fuel_mass_kg = fuel_energy_j / H2_LHV
            fuel_cost = hydrogen_fuel_cost(fuel_mass_kg, self.economics)
            maint_cost = self.maintenance.maintenance_cost_over(v.annual_operating_hours)

            total_fuel_cost += fuel_cost
            total_maintenance_cost += maint_cost
            total_energy_kwh += energy_j / 3.6e6

            per_vehicle.append(
                {
                    "name": v.name,
                    "fuel_cost_usd": fuel_cost,
                    "maintenance_cost_usd": maint_cost,
                    "energy_kwh": energy_j / 3.6e6,
                }
            )

        return {
            "total_fuel_cost_usd": total_fuel_cost,
            "total_maintenance_cost_usd": total_maintenance_cost,
            "total_energy_kwh": total_energy_kwh,
            "fleet_avg_cost_per_kwh": (
                (total_fuel_cost + total_maintenance_cost) / total_energy_kwh if total_energy_kwh > 0 else float("inf")
            ),
            "per_vehicle": per_vehicle,
        }


def infrastructure_scaling_cost(
    num_refuelling_stations: int,
    station_capital_cost_usd: float = 2_500_000.0,
    pipeline_cost_per_km_usd: float = 1_200_000.0,
    pipeline_km: float = 0.0,
) -> float:
    """Simple linear infrastructure capital scaling model for fleet-level
    hydrogen refuelling/energy infrastructure buildout."""
    return num_refuelling_stations * station_capital_cost_usd + pipeline_km * pipeline_cost_per_km_usd
