"""
Hybrid combustion-electric integration: battery pack model (with internal
resistance), electric motor/generator, regenerative braking energy
recovery, and a rule-based power-split controller that blends the
hydrogen engine (ICE or turbine) with the electric path.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class BatteryPack:
    capacity_wh: float = 5000.0
    nominal_voltage_v: float = 350.0
    internal_resistance_ohm: float = 0.06
    soc: float = 0.6                     # 0..1 state of charge
    min_soc: float = 0.15
    max_soc: float = 0.95
    max_charge_power_w: float = 40_000.0
    max_discharge_power_w: float = 80_000.0

    def available_discharge_power_w(self) -> float:
        if self.soc <= self.min_soc:
            return 0.0
        # Voltage sag under load via internal resistance (simple Thevenin model)
        return self.max_discharge_power_w * min((self.soc - self.min_soc) / 0.2, 1.0)

    def available_charge_power_w(self) -> float:
        if self.soc >= self.max_soc:
            return 0.0
        return self.max_charge_power_w * min((self.max_soc - self.soc) / 0.2, 1.0)

    def discharge(self, power_w: float, dt_s: float) -> float:
        """Draw power_w from the pack for dt_s; returns power actually
        delivered (capped by availability), accounting for I^2R losses."""
        available = self.available_discharge_power_w()
        delivered = min(max(power_w, 0.0), available)
        # I^2R loss reduces net energy removed from stored chemical energy
        # by more than what's delivered to the bus.
        current_a = delivered / max(self.nominal_voltage_v, 1.0)
        loss_w = current_a ** 2 * self.internal_resistance_ohm
        energy_removed_wh = (delivered + loss_w) * dt_s / 3600.0
        self.soc -= energy_removed_wh / self.capacity_wh
        self.soc = max(self.soc, 0.0)
        return delivered

    def charge(self, power_w: float, dt_s: float) -> float:
        """Deliver regenerative/generator power_w into the pack for dt_s;
        returns power actually accepted (capped by availability)."""
        available = self.available_charge_power_w()
        accepted = min(max(power_w, 0.0), available)
        current_a = accepted / max(self.nominal_voltage_v, 1.0)
        loss_w = current_a ** 2 * self.internal_resistance_ohm
        energy_stored_wh = max(accepted - loss_w, 0.0) * dt_s / 3600.0
        self.soc += energy_stored_wh / self.capacity_wh
        self.soc = min(self.soc, 1.0)
        return accepted


@dataclass
class ElectricMachine:
    peak_power_w: float = 60_000.0
    peak_efficiency: float = 0.94

    def efficiency(self, power_fraction: float) -> float:
        """Efficiency curve peaking near 50-70% load, falling off at very
        low load (fixed losses dominate) and near peak (copper losses)."""
        pf = max(0.0, min(abs(power_fraction), 1.0))
        return self.peak_efficiency * (1.0 - 0.35 * (pf - 0.6) ** 2)

    def motor_electrical_power_w(self, mechanical_power_w: float) -> float:
        pf = mechanical_power_w / max(self.peak_power_w, 1e-6)
        eta = self.efficiency(pf)
        return mechanical_power_w / max(eta, 1e-3)

    def generator_electrical_power_w(self, mechanical_power_w: float) -> float:
        pf = mechanical_power_w / max(self.peak_power_w, 1e-6)
        eta = self.efficiency(pf)
        return mechanical_power_w * eta


@dataclass
class HybridController:
    """
    Rule-based power-split / load-balancing controller for a combustion
    engine (ICE or turbine) + battery/electric-machine hybrid drivetrain,
    plus regenerative braking energy recovery.
    """

    battery: BatteryPack
    motor: ElectricMachine
    ice_min_efficient_load: float = 0.35   # below this, prefer electric-only
    regen_efficiency: float = 0.65         # brake energy -> electrical energy

    def split_power_demand(self, demanded_power_w: float, engine_rated_power_w: float) -> tuple[float, float]:
        """
        Decide the (engine_power_w, electric_power_w) split for a given
        total demanded power. Electric assist is used to keep the engine
        out of its inefficient low-load region and to cap peak engine
        power (load levelling / "power smoothing").
        """
        if demanded_power_w <= 0:
            return 0.0, 0.0

        load_fraction = demanded_power_w / max(engine_rated_power_w, 1e-6)

        if load_fraction < self.ice_min_efficient_load:
            # Light load: prefer battery if it has charge, keep engine idle-efficient.
            electric_available = self.battery.available_discharge_power_w()
            if electric_available >= demanded_power_w:
                return 0.0, demanded_power_w
            return demanded_power_w - electric_available, electric_available

        # Cap engine at its efficient rated ceiling; cover any excess with
        # electric assist (load levelling / peak shaving).
        engine_ceiling = engine_rated_power_w * 0.85
        engine_power = min(demanded_power_w, engine_ceiling)
        electric_power = max(demanded_power_w - engine_power, 0.0)
        electric_available = self.battery.available_discharge_power_w()
        electric_power = min(electric_power, electric_available)
        engine_power = demanded_power_w - electric_power
        return engine_power, electric_power

    def regenerative_braking(self, braking_power_w: float, dt_s: float) -> float:
        """
        Recover a fraction of braking (kinetic-energy dissipation) power
        into the battery via the generator, capped by both motor and
        battery charge-acceptance limits. Returns electrical power
        actually recovered (W).
        """
        if braking_power_w <= 0:
            return 0.0
        mechanical_recoverable = min(braking_power_w, self.motor.peak_power_w)
        electrical_gross = self.motor.generator_electrical_power_w(mechanical_recoverable) * self.regen_efficiency
        return self.battery.charge(electrical_gross, dt_s)
