"""
Physical, chemical and engineering constants used throughout the Aureom
H2-Combustion platform.

All values are SI unless explicitly noted, and are drawn from standard
combustion / thermodynamics references (Turns - "An Introduction to
Combustion", Heywood - "Internal Combustion Engine Fundamentals",
Ferguson & Kirkpatrick - "Internal Combustion Engines: Applied
Thermosciences", NIST-JANAF thermochemical tables, Cengel - "Thermodynamics:
An Engineering Approach").
"""
from __future__ import annotations

import math

# ----------------------------------------------------------------------------
# Universal constants
# ----------------------------------------------------------------------------
R_UNIVERSAL = 8.314462618          # J/(mol.K)
STANDARD_GRAVITY = 9.80665         # m/s^2
STEFAN_BOLTZMANN = 5.670374419e-8  # W/(m^2.K^4)
ATM_PRESSURE = 101_325.0           # Pa
ATM_TEMPERATURE = 298.15           # K (25 C reference)
KELVIN_OFFSET = 273.15

# ----------------------------------------------------------------------------
# Hydrogen fuel properties
# ----------------------------------------------------------------------------
H2_MOLAR_MASS = 2.01588e-3         # kg/mol
O2_MOLAR_MASS = 31.9988e-3         # kg/mol
N2_MOLAR_MASS = 28.0134e-3         # kg/mol
H2O_MOLAR_MASS = 18.01528e-3       # kg/mol
AIR_MOLAR_MASS = 28.9647e-3        # kg/mol

H2_LHV = 119.96e6                  # J/kg  (Lower Heating Value of hydrogen)
H2_HHV = 141.80e6                  # J/kg  (Higher Heating Value of hydrogen)

H2_GAS_CONSTANT = R_UNIVERSAL / H2_MOLAR_MASS      # J/(kg.K) ~ 4124
AIR_GAS_CONSTANT = R_UNIVERSAL / AIR_MOLAR_MASS    # J/(kg.K) ~ 287

# Ideal-gas specific heats (approx, mid-temperature, J/(kg.K))
CP_AIR = 1005.0
CV_AIR = CP_AIR - AIR_GAS_CONSTANT
GAMMA_AIR = CP_AIR / CV_AIR                        # ~1.4

CP_H2 = 14_310.0
CP_H2O_VAPOUR = 1996.0
CP_N2 = 1040.0          # mid-temperature (~1500 K) specific heat, J/(kg.K)
CP_O2 = 960.0           # mid-temperature (~1500 K) specific heat, J/(kg.K)
CP_COMBUSTION_PRODUCTS_REF = 1200.0   # effective cp of hot H2-air combustion
                                       # products near stoichiometric (accounts
                                       # for excess N2 + H2O + dissociation)

# Mass fraction composition of dry air
O2_MASS_FRACTION_AIR = 0.2320
N2_MASS_FRACTION_AIR = 0.7680
O2_MOLE_FRACTION_AIR = 0.2095
N2_MOLE_FRACTION_AIR = 0.7809

# Stoichiometric reaction: 2 H2 + O2 -> 2 H2O
# Stoichiometric air-fuel mass ratio for hydrogen in air.
STOICHIOMETRIC_O2_PER_H2_MASS = O2_MOLAR_MASS / (2.0 * H2_MOLAR_MASS)  # ~7.94
STOICHIOMETRIC_AFR_MASS = STOICHIOMETRIC_O2_PER_H2_MASS / O2_MASS_FRACTION_AIR
# -> approximately 34.3 kg air / kg H2, matches published hydrogen literature.

# Water produced per kg of hydrogen burned completely (mass stoichiometry)
WATER_YIELD_PER_KG_H2 = (2.0 * H2O_MOLAR_MASS) / (2.0 * H2_MOLAR_MASS)  # ~8.94

# Laminar flame speed of stoichiometric H2-air mixture at standard conditions
H2_AIR_LAMINAR_FLAME_SPEED_STOICH = 2.0  # m/s (well documented ~1.9-2.3 m/s)

# Adiabatic flame temperature of stoichiometric H2-air flame at STP (K),
# accounting for dissociation losses relative to the naive (non-dissociated)
# energy balance value (~2900 K). Used as a calibration anchor.
H2_AIR_ADIABATIC_FLAME_T_STOICH = 2380.0

# Auto-ignition temperature / flammability limits (mole fraction in air)
H2_AUTOIGNITION_TEMPERATURE = 858.0   # K
H2_LFL_MOLE_FRACTION = 0.04
H2_UFL_MOLE_FRACTION = 0.75

# ----------------------------------------------------------------------------
# Emissions
# ----------------------------------------------------------------------------
# Extended Zeldovich (thermal NOx) rate constants (Turns "An Introduction
# to Combustion", Ch.5 form). Published in cgs units (concentrations in
# mol/cm^3); the emissions.nox_model module performs the SI<->cgs
# conversion locally and keeps this constant in its native published form
# so it remains directly checkable against the reference.
# k1: N2 + O -> NO + N          (rate-limiting forward step)
ZELDOVICH_K1_A = 1.8e14      # cm^3/(mol.s)
ZELDOVICH_K1_EA_OVER_R = 38_370.0  # K

# Atomic-oxygen partial-equilibrium concentration is obtained here from
# the actual O2 <-> 2O dissociation equilibrium constant Kp(T) (van't Hoff
# form), rather than from a from-memory empirical curve fit -- this is
# anchored to the well-known O2 bond dissociation energy (~498 kJ/mol)
# and a literature-typical Kp(3000 K) ~ 1.3e-3 (atm-based partial-pressure
# equilibrium constant for O2 <-> 2O), which together fully determine the
# van't Hoff pre-exponential constant below. See nox_model.o_atom_equilibrium
# for the derivation and usage.
O2_DISSOCIATION_BOND_ENERGY_J_PER_MOL = 498_000.0
O2_DISSOCIATION_KP_REFERENCE = 1.3e-3     # Kp at the reference temperature (atm units)
O2_DISSOCIATION_KP_REFERENCE_T = 3000.0   # K

NOX_REFERENCE_RESIDENCE_TIME = 2.0e-3  # s, characteristic combustion-zone
                                        # residence time used to convert a
                                        # formation rate into a concentration.

# ----------------------------------------------------------------------------
# Mechanical / materials
# ----------------------------------------------------------------------------
STEEL_YOUNGS_MODULUS = 200e9        # Pa
STEEL_YIELD_STRENGTH = 250e6        # Pa (mild alloy steel, conservative)
ARCHARD_WEAR_COEFFICIENT = 3.0e-13  # dimensionless-ish wear coefficient
                                     # (typical boundary-lubrication steel-steel)

def celsius_to_kelvin(t_c: float) -> float:
    return t_c + KELVIN_OFFSET


def kelvin_to_celsius(t_k: float) -> float:
    return t_k - KELVIN_OFFSET


def deg_to_rad(deg: float) -> float:
    return deg * math.pi / 180.0


def rad_to_deg(rad: float) -> float:
    return rad * 180.0 / math.pi
