"""
Deterministic structured state logger for the simulation loop.

Every subsystem reports a flat dict of named scalar values at each timestep;
the logger accumulates these into a tabular time series (pandas DataFrame)
that can be exported to CSV or plotted.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pandas as pd


@dataclass
class SimulationLogger:
    """Accumulates per-timestep state dicts into a tidy time series."""

    records: list[dict[str, Any]] = field(default_factory=list)

    def log(self, timestep: int, t: float, **values: Any) -> None:
        row = {"step": timestep, "time_s": t}
        row.update(values)
        self.records.append(row)

    def to_dataframe(self) -> pd.DataFrame:
        if not self.records:
            return pd.DataFrame()
        return pd.DataFrame.from_records(self.records).set_index("step")

    def to_csv(self, path: str) -> None:
        self.to_dataframe().to_csv(path)

    def summary(self) -> dict[str, Any]:
        df = self.to_dataframe()
        if df.empty:
            return {}
        numeric = df.select_dtypes(include="number")
        return {
            "steps": len(df),
            "duration_s": float(df["time_s"].iloc[-1]) if "time_s" in df else None,
            "mean": numeric.mean().to_dict(),
            "max": numeric.max().to_dict(),
            "min": numeric.min().to_dict(),
        }

    def clear(self) -> None:
        self.records.clear()
