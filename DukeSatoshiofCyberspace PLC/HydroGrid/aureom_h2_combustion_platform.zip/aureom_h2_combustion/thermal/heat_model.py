"""
In-cylinder / combustor convective heat transfer and engine thermal mass.

Implements the Woschni (1967) in-cylinder convective heat-transfer
correlation (the standard empirical correlation used in single-zone ICE
simulation, see Heywood ch. 12) and a lumped-capacitance thermal model of
the engine block/head used to track bulk metal temperature, thermal
throttling and material stress degradation.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from aureom_h2_combustion.utils.constants import STEEL_YIELD_STRENGTH


# Woschni correlation coefficients (combustion period), SI form:
#   h = 3.26 * B^-0.2 * p^0.8 * T^-0.55 * w^0.8
# with B in m, p in kPa, T in K, w in m/s, giving h in W/(m^2.K).
_WOSCHNI_C = 3.26
_WOSCHNI_B_EXP = -0.2
_WOSCHNI_P_EXP = 0.8
_WOSCHNI_T_EXP = -0.55
_WOSCHNI_W_EXP = 0.8

# Woschni characteristic-velocity weighting constants for the combustion
# and expansion period (C1 on mean piston speed, C2 on combustion-induced
# swirl/pressure-rise term).
_WOSCHNI_C1_COMBUSTION = 2.28
_WOSCHNI_C2_COMBUSTION = 3.24e-3


def woschni_heat_transfer_coefficient(
    bore_m: float,
    cylinder_pressure_pa: float,
    cylinder_pressure_motored_pa: float,
    gas_temperature_k: float,
    mean_piston_speed_ms: float,
    displacement_per_cyl_m3: float,
    reference_pressure_pa: float,
    reference_temperature_k: float,
    reference_volume_m3: float,
) -> float:
    """
    Instantaneous in-cylinder convective heat transfer coefficient
    (W/m^2.K) via the Woschni correlation.

    `cylinder_pressure_motored_pa` is the pressure that would exist at the
    same crank angle under motored (no combustion) conditions -- its
    difference from the fired pressure drives the combustion-induced
    velocity term.
    """
    p_kpa = max(cylinder_pressure_pa, 1.0) / 1000.0

    delta_p_kpa = max(cylinder_pressure_pa - cylinder_pressure_motored_pa, 0.0) / 1000.0
    w = (
        _WOSCHNI_C1_COMBUSTION * mean_piston_speed_ms
        + _WOSCHNI_C2_COMBUSTION
        * (displacement_per_cyl_m3 * reference_temperature_k)
        / (reference_pressure_pa * reference_volume_m3 + 1e-9)
        * delta_p_kpa
        * 1000.0
    )
    w = max(w, 0.1)

    h = (
        _WOSCHNI_C
        * bore_m ** _WOSCHNI_B_EXP
        * p_kpa ** _WOSCHNI_P_EXP
        * max(gas_temperature_k, 1.0) ** _WOSCHNI_T_EXP
        * w ** _WOSCHNI_W_EXP
    )
    return max(h, 0.0)


def wall_heat_flux_w(h_coeff: float, gas_temperature_k: float, wall_temperature_k: float, area_m2: float) -> float:
    """Newton's law of cooling applied to the combustion-chamber wall."""
    return h_coeff * area_m2 * (gas_temperature_k - wall_temperature_k)


@dataclass
class EngineThermalMass:
    """Lumped-capacitance thermal model of the engine block + head metal."""

    mass_kg: float
    specific_heat_j_per_kgk: float = 460.0  # cast iron / steel alloy
    temperature_k: float = 298.15

    max_safe_temperature_k: float = 393.15   # ~120 C typical coolant-side limit
    critical_temperature_k: float = 453.15   # ~180 C -- damage onset
    _cumulative_thermal_damage: float = 0.0

    def step(self, heat_in_w: float, heat_rejected_w: float, dt_s: float) -> None:
        net_w = heat_in_w - heat_rejected_w
        d_temp = net_w * dt_s / (self.mass_kg * self.specific_heat_j_per_kgk)
        self.temperature_k += d_temp
        self._accumulate_thermal_damage(dt_s)

    def _accumulate_thermal_damage(self, dt_s: float) -> None:
        """
        Arrhenius-type accelerated material degradation above the safe
        temperature threshold: damage accrues exponentially with the
        temperature excess, consistent with thermally-activated creep /
        fatigue mechanisms in engine alloys.
        """
        if self.temperature_k <= self.max_safe_temperature_k:
            return
        excess = self.temperature_k - self.max_safe_temperature_k
        rate = 1.0e-7 * math.exp(excess / 15.0)  # 1/s, calibrated so hours
        # above the critical threshold produce measurable (percent-level)
        # cumulative damage rather than instantaneous failure.
        self._cumulative_thermal_damage += rate * dt_s

    @property
    def thermal_damage_fraction(self) -> float:
        """Cumulative fraction of yield-strength margin consumed by thermal
        overstress (0 = pristine, 1 = failure)."""
        return min(self._cumulative_thermal_damage, 1.0)

    @property
    def derated_yield_strength_pa(self) -> float:
        return STEEL_YIELD_STRENGTH * (1.0 - 0.5 * self.thermal_damage_fraction)

    @property
    def is_overheating(self) -> bool:
        return self.temperature_k > self.max_safe_temperature_k

    @property
    def is_critical(self) -> bool:
        return self.temperature_k > self.critical_temperature_k

    def thermal_throttle_factor(self) -> float:
        """
        Fraction (0-1) by which commanded power should be derated to
        protect the engine once temperature exceeds the safe threshold,
        ramping linearly to full throttle (0 -> no power) at the critical
        temperature.
        """
        if self.temperature_k <= self.max_safe_temperature_k:
            return 1.0
        span = self.critical_temperature_k - self.max_safe_temperature_k
        over = self.temperature_k - self.max_safe_temperature_k
        derate = min(over / span, 1.0)
        return max(1.0 - derate, 0.0)
