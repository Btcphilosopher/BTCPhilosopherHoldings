"""
Liquid cooling loop: coolant thermal mass, radiator heat rejection via an
effectiveness-NTU heat exchanger model, and thermostat flow control.
"""
from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class CoolingSystem:
    coolant_mass_kg: float = 8.0
    coolant_specific_heat_j_per_kgk: float = 3800.0  # 50/50 water-glycol
    coolant_temperature_k: float = 298.15

    radiator_ua_w_per_k: float = 450.0     # overall heat-transfer conductance
    ambient_temperature_k: float = 298.15
    pump_flow_kg_s: float = 0.4
    thermostat_open_temp_k: float = 355.15   # ~82 C
    thermostat_full_open_temp_k: float = 368.15  # ~95 C

    def thermostat_bypass_fraction(self) -> float:
        """Fraction of coolant flow routed through the radiator (0 = fully
        bypassed / warm-up, 1 = fully through radiator)."""
        if self.coolant_temperature_k <= self.thermostat_open_temp_k:
            return 0.05  # small bleed flow even when "closed"
        if self.coolant_temperature_k >= self.thermostat_full_open_temp_k:
            return 1.0
        span = self.thermostat_full_open_temp_k - self.thermostat_open_temp_k
        return 0.05 + 0.95 * (self.coolant_temperature_k - self.thermostat_open_temp_k) / span

    def radiator_heat_rejected_w(self) -> float:
        """
        Effectiveness-NTU model of the radiator as a cross-flow heat
        exchanger rejecting heat to ambient air.
        """
        flow = self.pump_flow_kg_s * self.thermostat_bypass_fraction()
        if flow <= 0:
            return 0.0
        c_min = flow * self.coolant_specific_heat_j_per_kgk
        ntu = self.radiator_ua_w_per_k / max(c_min, 1e-6)
        effectiveness = 1.0 - math.exp(-ntu)
        q_max = c_min * (self.coolant_temperature_k - self.ambient_temperature_k)
        return max(effectiveness * q_max, 0.0)

    def step(self, heat_from_engine_w: float, dt_s: float) -> float:
        """
        Advance coolant temperature by dt_s given heat rejected from the
        engine block into the coolant. Returns heat rejected to ambient
        (W) this step.
        """
        q_rejected = self.radiator_heat_rejected_w()
        net_w = heat_from_engine_w - q_rejected
        d_temp = net_w * dt_s / (self.coolant_mass_kg * self.coolant_specific_heat_j_per_kgk)
        self.coolant_temperature_k += d_temp
        self.coolant_temperature_k = max(self.coolant_temperature_k, self.ambient_temperature_k)
        return q_rejected
