"""
Example: hydrogen ICE test-cell simulation matching the platform
specification's reference call, with plots and a printed summary.

Run with:  python -m aureom_h2_combustion.examples.run_ice_example
"""
from __future__ import annotations

from aureom_h2_combustion.core.simulation import run_engine_simulation
from aureom_h2_combustion.examples.plotting import plot_summary


def main() -> None:
    logger, financials = run_engine_simulation(
        engine_type="hydrogen_ice",
        displacement=2.0,
        hydrogen_flow_rate=0.0008,   # kg/s
        rpm=4500,
        load=0.75,
        simulation_time=120,
        dt_s=0.1,
    )
    df = logger.to_dataframe()
    print(df.tail(10).to_string())
    print("\nFinancial summary:")
    for k, v in financials.items():
        print(f"  {k}: {v}")

    plot_summary(df, "hydrogen_ice", out_dir=".")
    print("\nWrote ice_summary.png")


if __name__ == "__main__":
    main()
