"""Matplotlib summary plots for a simulation log DataFrame."""
from __future__ import annotations

import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


def plot_summary(df: pd.DataFrame, engine_type: str, out_dir: str = ".") -> list[str]:
    os.makedirs(out_dir, exist_ok=True)
    paths = []

    if engine_type == "hydrogen_ice":
        fig, axes = plt.subplots(3, 2, figsize=(12, 10), sharex=True)
        axes[0, 0].plot(df["time_s"], df["brake_power_kw"], color="tab:blue")
        axes[0, 0].set_ylabel("Brake power (kW)")

        axes[0, 1].plot(df["time_s"], df["brake_torque_nm"], color="tab:orange")
        axes[0, 1].set_ylabel("Brake torque (N.m)")

        axes[1, 0].plot(df["time_s"], df["peak_pressure_bar"], color="tab:red")
        axes[1, 0].set_ylabel("Peak cyl. pressure (bar)")

        axes[1, 1].plot(df["time_s"], df["peak_temperature_k"], color="tab:red")
        axes[1, 1].set_ylabel("Peak cyl. temperature (K)")

        axes[2, 0].plot(df["time_s"], df["block_temperature_c"], label="block")
        axes[2, 0].plot(df["time_s"], df["coolant_temperature_c"], label="coolant")
        axes[2, 0].set_ylabel("Temperature (C)")
        axes[2, 0].legend(fontsize=8)
        axes[2, 0].set_xlabel("Time (s)")

        axes[2, 1].plot(df["time_s"], df["nox_ppm"], color="tab:green")
        axes[2, 1].set_ylabel("NOx (ppm)")
        axes[2, 1].set_xlabel("Time (s)")

        fig.suptitle("Hydrogen ICE simulation")
        fig.tight_layout()
        path = os.path.join(out_dir, "ice_summary.png")
        fig.savefig(path, dpi=130)
        plt.close(fig)
        paths.append(path)
    else:
        fig, axes = plt.subplots(2, 2, figsize=(11, 7), sharex=True)
        axes[0, 0].plot(df["time_s"], df["shaft_power_kw"], color="tab:blue")
        axes[0, 0].set_ylabel("Shaft power (kW)")

        axes[0, 1].plot(df["time_s"], df["thermal_efficiency"], color="tab:orange")
        axes[0, 1].set_ylabel("Thermal efficiency")

        axes[1, 0].plot(df["time_s"], df["turbine_inlet_temperature_k"], label="TIT")
        axes[1, 0].plot(df["time_s"], df["exhaust_temperature_k"], label="exhaust")
        axes[1, 0].set_ylabel("Temperature (K)")
        axes[1, 0].legend(fontsize=8)
        axes[1, 0].set_xlabel("Time (s)")

        axes[1, 1].plot(df["time_s"], df["nox_ppm"], color="tab:green")
        axes[1, 1].set_ylabel("NOx (ppm)")
        axes[1, 1].set_xlabel("Time (s)")

        fig.suptitle("Hydrogen turbine simulation")
        fig.tight_layout()
        path = os.path.join(out_dir, "turbine_summary.png")
        fig.savefig(path, dpi=130)
        plt.close(fig)
        paths.append(path)

    return paths


def plot_pv_diagram(theta_deg, pressure_pa, out_path: str) -> str:
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(theta_deg, pressure_pa / 1e5)
    ax.set_xlabel("Crank angle (deg ATDC)")
    ax.set_ylabel("Cylinder pressure (bar)")
    ax.set_title("In-cylinder pressure trace")
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)
    return out_path
