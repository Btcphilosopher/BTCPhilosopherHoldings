"""
Example: full vehicle integration -- a hydrogen-ICE Car accelerating from
a standing start under wide-open throttle, with the ECU controlling
mixture/timing, an automatic gearbox shifting on an RPM band, and the
engine's crankshaft dynamics coupled through the drivetrain to the wheels.

This exercises the vehicle-coupling path directly (as opposed to the
core.simulation dynamometer/test-cell mode), matching the platform
specification's "acceleration curves" requirement.

Run with:  python -m aureom_h2_combustion.examples.run_vehicle_example
"""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from aureom_h2_combustion.control.ecu import ECU
from aureom_h2_combustion.engines.ice_engine import ICEConfig, ICEEngine
from aureom_h2_combustion.mechanical.crankshaft import omega_to_rpm, rpm_to_omega
from aureom_h2_combustion.vehicles.car import Car


def main() -> None:
    engine = ICEEngine(ICEConfig(displacement_l=2.0, num_cylinders=4, compression_ratio=12.0, target_lambda=1.2))
    ecu = ECU()
    car = Car()

    dt = 0.05
    t = 0.0
    duration = 25.0

    log_t, log_speed_kmh, log_rpm, log_gear = [], [], [], []

    engine_rpm = 1000.0
    load = 1.0  # wide-open throttle standing-start acceleration test

    while t < duration:
        gear = car.params.gearbox.select_gear_for_rpm_target(
            car.state.speed_ms, car.params.wheel.radius_m, target_rpm_range=(2500.0, 6500.0)
        )
        car.params.gearbox.current_gear_index = gear

        lam = ecu.target_lambda(load)
        ignition = ecu.ignition_timing_deg(engine_rpm, load, 0.0)
        cycle = engine.run_cycle(engine_rpm, load, lambda_override=lam, ignition_timing_btdc_override=ignition)

        car.step(cycle.indicated_torque_nm, dt, gear_index=gear)

        wheel_omega = car.state.speed_ms / car.params.wheel.radius_m
        engine_omega = wheel_omega * car.params.gearbox.overall_ratio(gear)
        engine_rpm = max(omega_to_rpm(engine_omega), 900.0)  # idle floor

        log_t.append(t)
        log_speed_kmh.append(car.state.speed_ms * 3.6)
        log_rpm.append(engine_rpm)
        log_gear.append(gear + 1)
        t += dt

    time_to_100 = next((tt for tt, v in zip(log_t, log_speed_kmh) if v >= 100.0), None)
    print(f"0-100 km/h time: {time_to_100} s" if time_to_100 else "Did not reach 100 km/h in the simulated window")
    print(f"Final speed: {log_speed_kmh[-1]:.1f} km/h at t={log_t[-1]:.1f}s")

    fig, axes = plt.subplots(3, 1, figsize=(8, 8), sharex=True)
    axes[0].plot(log_t, log_speed_kmh)
    axes[0].set_ylabel("Speed (km/h)")
    axes[1].plot(log_t, log_rpm, color="tab:orange")
    axes[1].set_ylabel("Engine RPM")
    axes[2].plot(log_t, log_gear, color="tab:green", drawstyle="steps-post")
    axes[2].set_ylabel("Gear")
    axes[2].set_xlabel("Time (s)")
    fig.suptitle("Hydrogen ICE car: standing-start acceleration")
    fig.tight_layout()
    fig.savefig("vehicle_acceleration.png", dpi=130)
    print("Wrote vehicle_acceleration.png")


if __name__ == "__main__":
    main()
