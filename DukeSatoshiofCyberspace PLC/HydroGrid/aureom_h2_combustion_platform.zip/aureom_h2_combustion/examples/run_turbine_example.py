"""
Example: hydrogen gas-turbine (generator / turboshaft) simulation across a
throttle sweep, with plots.

Run with:  python -m aureom_h2_combustion.examples.run_turbine_example
"""
from __future__ import annotations

from aureom_h2_combustion.core.simulation import run_engine_simulation
from aureom_h2_combustion.examples.plotting import plot_summary


def main() -> None:
    logger, financials = run_engine_simulation(
        engine_type="hydrogen_turbine",
        rpm=0,          # unused for the turbine path; kept for signature parity
        load=0.85,
        simulation_time=30,
        dt_s=0.25,
    )
    df = logger.to_dataframe()
    print(df.tail(10).to_string())
    print("\nFinancial summary:")
    for k, v in financials.items():
        print(f"  {k}: {v}")

    plot_summary(df, "hydrogen_turbine", out_dir=".")
    print("\nWrote turbine_summary.png")


if __name__ == "__main__":
    main()
