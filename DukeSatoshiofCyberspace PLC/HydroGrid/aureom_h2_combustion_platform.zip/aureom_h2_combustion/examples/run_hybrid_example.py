"""
Example: hybrid hydrogen-ICE + battery-electric drivetrain over a simple
drive cycle (accelerate -> cruise -> brake), demonstrating power-split
load levelling and regenerative-braking energy recovery.

Run with:  python -m aureom_h2_combustion.examples.run_hybrid_example
"""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from aureom_h2_combustion.hybrid.hybrid_system import BatteryPack, ElectricMachine, HybridController


def demand_power_w(t: float) -> float:
    """A simple synthetic drive-cycle power demand (W): ramp up, cruise,
    then regenerative braking (negative demand)."""
    if t < 10:
        return 60_000.0 * (t / 10.0)         # accelerate
    if t < 30:
        return 25_000.0                       # cruise
    if t < 40:
        return -40_000.0                      # braking
    return 5_000.0                            # light cruise


def main() -> None:
    battery = BatteryPack(capacity_wh=6000.0, soc=0.55)
    motor = ElectricMachine(peak_power_w=50_000.0)
    controller = HybridController(battery=battery, motor=motor)

    engine_rated_power_w = 90_000.0
    dt = 0.5
    t = 0.0
    duration = 50.0

    ts, engine_p, electric_p, soc_trace, demand_trace = [], [], [], [], []

    while t < duration:
        demand = demand_power_w(t)
        if demand >= 0:
            eng_p, elec_p = controller.split_power_demand(demand, engine_rated_power_w)
            battery.discharge(elec_p, dt)
        else:
            recovered = controller.regenerative_braking(-demand, dt)
            eng_p, elec_p = 0.0, -recovered  # negative = power flowing into the battery

        ts.append(t)
        engine_p.append(eng_p / 1000.0)
        electric_p.append(elec_p / 1000.0)
        soc_trace.append(battery.soc)
        demand_trace.append(demand / 1000.0)
        t += dt

    fig, axes = plt.subplots(2, 1, figsize=(8, 6), sharex=True)
    axes[0].plot(ts, demand_trace, label="demand", color="black", linestyle="--")
    axes[0].plot(ts, engine_p, label="engine")
    axes[0].plot(ts, electric_p, label="electric")
    axes[0].set_ylabel("Power (kW)")
    axes[0].legend(fontsize=8)

    axes[1].plot(ts, soc_trace, color="tab:green")
    axes[1].set_ylabel("Battery SOC")
    axes[1].set_xlabel("Time (s)")

    fig.suptitle("Hybrid H2-ICE + battery: power split & regen braking")
    fig.tight_layout()
    fig.savefig("hybrid_drive_cycle.png", dpi=130)
    print("Wrote hybrid_drive_cycle.png")
    print(f"Final SOC: {battery.soc:.3f}")


if __name__ == "__main__":
    main()
