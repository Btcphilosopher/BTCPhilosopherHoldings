"""
Rule-based Engine Control Unit (ECU) simulation.

Implements the control-loop functions a real hydrogen-ICE ECU performs:
  * closed-loop throttle control (PID) to track a commanded speed/torque
  * ignition-timing scheduling (MBT-seeking, retarded near knock onset)
  * fuel-mixture (lambda) optimisation trading efficiency against NOx
  * knock prevention via closed-loop timing retard
  * a lightweight adaptive trim that nudges the mixture map based on
    observed knock/efficiency history (a simple discrete learning
    controller, optional "adaptive" mode)
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class PIDController:
    kp: float
    ki: float
    kd: float
    output_min: float = 0.0
    output_max: float = 1.0

    _integral: float = 0.0
    _prev_error: float | None = field(default=None, repr=False)

    def reset(self) -> None:
        self._integral = 0.0
        self._prev_error = None

    def step(self, setpoint: float, measured: float, dt_s: float) -> float:
        error = setpoint - measured
        self._integral += error * dt_s
        derivative = 0.0 if self._prev_error is None else (error - self._prev_error) / max(dt_s, 1e-9)
        self._prev_error = error
        output = self.kp * error + self.ki * self._integral + self.kd * derivative
        clamped = max(self.output_min, min(output, self.output_max))
        # Anti-windup: back off the integral term if saturated.
        if output != clamped and self.ki != 0:
            self._integral -= error * dt_s
        return clamped


@dataclass
class ECUConfig:
    base_ignition_btdc_deg: float = 18.0
    min_ignition_btdc_deg: float = 4.0
    max_ignition_btdc_deg: float = 32.0
    knock_retard_gain_deg: float = 20.0   # degrees retarded per unit knock_risk

    lean_lambda_cruise: float = 1.6       # efficiency/NOx-optimised light load
    stoich_ish_lambda_high_load: float = 1.1  # richer near WOT for max torque
    min_lambda: float = 1.0               # never run at or below stoichiometric (knock/NOx risk)
    max_lambda: float = 2.2               # lean-misfire limit


@dataclass
class ECU:
    config: ECUConfig = field(default_factory=ECUConfig)
    throttle_pid: PIDController = field(
        default_factory=lambda: PIDController(kp=0.6, ki=0.15, kd=0.02, output_min=0.0, output_max=1.0)
    )
    adaptive: bool = False
    _adaptive_lambda_trim: float = 0.0

    def throttle_command(self, target_rpm: float, current_rpm: float, dt_s: float) -> float:
        """Closed-loop throttle position (0-1) to track a target engine speed."""
        return self.throttle_pid.step(target_rpm, current_rpm, dt_s)

    def target_lambda(self, load: float) -> float:
        """
        Fuel-mixture optimisation: run lean at light/cruise load for best
        efficiency and lowest NOx (thermal-NOx falls off sharply as lean
        dilution drops flame temperature), enrich progressively toward
        stoichiometric-ish as load approaches WOT to recover peak torque.
        """
        load = max(0.0, min(load, 1.0))
        lam = self.config.lean_lambda_cruise - (self.config.lean_lambda_cruise - self.config.stoich_ish_lambda_high_load) * load
        lam = max(self.config.min_lambda, min(lam, self.config.max_lambda))
        if self.adaptive:
            lam += self._adaptive_lambda_trim
            lam = max(self.config.min_lambda, min(lam, self.config.max_lambda))
        return lam

    def ignition_timing_deg(self, rpm: float, load: float, knock_risk: float) -> float:
        """
        MBT-seeking base schedule (more advance at low load/moderate RPM
        where burn is slower and knock risk is lower), retarded in closed
        loop whenever the knock-risk heuristic from the combustion model
        indicates autoignition danger.
        """
        load = max(0.0, min(load, 1.0))
        # Base schedule: more advance at light load (dilute, slow-burning
        # mixtures need more lead time), less at high load (fast burn).
        base = self.config.base_ignition_btdc_deg * (1.15 - 0.3 * load)

        retard = self.config.knock_retard_gain_deg * max(knock_risk, 0.0)
        timing = base - retard
        return max(self.config.min_ignition_btdc_deg, min(timing, self.config.max_ignition_btdc_deg))

    def knock_prevention_active(self, knock_risk: float, threshold: float = 0.35) -> bool:
        return knock_risk > threshold

    def update_adaptive_trim(self, knock_risk: float, combustion_efficiency: float) -> None:
        """
        Simple discrete learning controller: if repeated knock risk is
        observed, permanently enrich the adaptive trim (which counters
        knock by increasing burn rate/lowering unburned-gas residence
        time); if efficiency is high with no knock margin used, lean the
        trim slightly to claw back fuel economy. Bounded to a small
        authority so it augments, not replaces, the base schedule.
        """
        if not self.adaptive:
            return
        step = 0.01
        if knock_risk > 0.3:
            self._adaptive_lambda_trim = max(self._adaptive_lambda_trim - step, -0.3)
        elif knock_risk < 0.05 and combustion_efficiency > 0.9:
            self._adaptive_lambda_trim = min(self._adaptive_lambda_trim + step * 0.3, 0.2)

    def efficiency_emissions_tradeoff_lambda(self, load: float, nox_weight: float = 0.5) -> float:
        """
        Predictive tuning: sweep candidate lambdas and pick the one that
        minimises a weighted cost of (1 - combustion efficiency) and a
        NOx proxy (peaks near stoichiometric, falls off leaning out),
        letting the operator bias the setpoint toward economy or
        emissions via `nox_weight` in [0, 1].
        """
        import numpy as np

        from aureom_h2_combustion.combustion.hydrogen_combustion import combustion_efficiency as eta_fn

        candidates = np.linspace(self.config.min_lambda, self.config.max_lambda, 40)
        best_lambda = candidates[0]
        best_cost = float("inf")
        for lam in candidates:
            phi = 1.0 / lam
            eta = eta_fn(phi)
            # NOx proxy: thermal-NOx formation is strongly peaked just lean
            # of stoichiometric and collapses as mixtures dilute further.
            nox_proxy = max(0.0, 1.0 - abs(lam - 1.05) / 0.6)
            cost = (1.0 - nox_weight) * (1.0 - eta) + nox_weight * nox_proxy
            if cost < best_cost:
                best_cost = cost
                best_lambda = lam
        return float(best_lambda)
