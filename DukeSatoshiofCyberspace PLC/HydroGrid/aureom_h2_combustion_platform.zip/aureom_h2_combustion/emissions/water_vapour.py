"""
Water vapour output and overall emissions/environmental scoring.

Water vapour mass is exact reaction stoichiometry (2 H2 + O2 -> 2 H2O);
the environmental impact score is a simple weighted trade-off between
completed combustion (water vapour, benign) and NOx (harmful), used for
efficiency-vs-emissions optimisation studies.
"""
from __future__ import annotations

from dataclasses import dataclass

from aureom_h2_combustion.utils.constants import WATER_YIELD_PER_KG_H2

# EPA/WHO-informed relative harm weighting: NOx is treated as materially
# more environmentally damaging per unit mass than water vapour (which is
# not a criteria pollutant at tailpipe scale), consistent with regulatory
# treatment (NOx is a regulated criteria pollutant; H2O is not).
_NOX_HARM_WEIGHT = 1.0
_WATER_VAPOUR_HARM_WEIGHT = 0.0005


def water_vapour_mass_kg(fuel_burned_kg: float) -> float:
    """Exact stoichiometric water yield from hydrogen combusted."""
    return fuel_burned_kg * WATER_YIELD_PER_KG_H2


@dataclass(frozen=True)
class EmissionsSnapshot:
    water_vapour_kg: float
    nox_ppm: float
    nox_mass_kg: float
    environmental_impact_score: float  # 0 (no impact) .. 100 (severe)


def nox_ppm_to_mass_kg(nox_ppm: float, exhaust_mass_kg: float, exhaust_molar_mass_kg_per_mol: float = 0.0288) -> float:
    """Convert a NO mole-fraction (ppm) reading to a mass of NO (as NO2
    equivalent mass is commonly reported; here we report as NO)."""
    from aureom_h2_combustion.utils.constants import R_UNIVERSAL

    no_molar_mass = 0.030006  # kg/mol (NO)
    exhaust_moles = exhaust_mass_kg / exhaust_molar_mass_kg_per_mol
    no_moles = exhaust_moles * (nox_ppm * 1e-6)
    return no_moles * no_molar_mass


# Reference NOx intensity used to normalise the score: broadly in line
# with stringent NOx emissions regulations expressed per unit of engine
# work (e.g. Euro/EPA heavy-duty limits sit in the ~40-400 mg NOx per MJ
# range depending on standard and cycle); a plant emitting at this
# intensity scores 50/100 under the saturating map below.
_NOX_REFERENCE_INTENSITY_MG_PER_MJ = 200.0
_WATER_REFERENCE_INTENSITY_G_PER_MJ = 300.0  # benign baseline, low weight


def environmental_impact_score(nox_mass_kg: float, water_vapour_kg: float, energy_output_j: float) -> float:
    """
    A bounded 0-100 environmental impact score, normalised per unit of
    useful energy delivered (pollutant mass per MJ) against reference
    intensities so realistic engine operating points spread across the
    scale rather than saturating at the extremes. Lower is better.
    """
    energy_mj = max(energy_output_j / 1.0e6, 1e-9)
    nox_intensity_mg_per_mj = (nox_mass_kg * 1.0e6) / energy_mj
    water_intensity_g_per_mj = (water_vapour_kg * 1.0e3) / energy_mj

    raw_score = (
        _NOX_HARM_WEIGHT * nox_intensity_mg_per_mj / _NOX_REFERENCE_INTENSITY_MG_PER_MJ
        + _WATER_VAPOUR_HARM_WEIGHT * water_intensity_g_per_mj / _WATER_REFERENCE_INTENSITY_G_PER_MJ
    )
    # Saturating map onto 0-100 (soft clip, well-conditioned for optimisation);
    # raw_score == 1 (i.e. emitting at the reference intensity) scores 50.
    return 100.0 * (raw_score / (1.0 + raw_score))


def emissions_snapshot(
    fuel_burned_kg: float,
    nox_ppm: float,
    exhaust_mass_kg: float,
    energy_output_j: float,
) -> EmissionsSnapshot:
    water_kg = water_vapour_mass_kg(fuel_burned_kg)
    nox_kg = nox_ppm_to_mass_kg(nox_ppm, exhaust_mass_kg)
    score = environmental_impact_score(nox_kg, water_kg, energy_output_j)
    return EmissionsSnapshot(
        water_vapour_kg=water_kg,
        nox_ppm=nox_ppm,
        nox_mass_kg=nox_kg,
        environmental_impact_score=score,
    )
