"""
Thermal NOx formation via the extended Zeldovich mechanism (Turns, "An
Introduction to Combustion", Ch. 5) -- the standard reduced thermal-NOx
model used across engine and gas-turbine combustion simulation.

Mechanism:
    N2 + O <-> NO + N        (rate-limiting, k1)
    N + O2 <-> NO + O
    N + OH <-> NO + H

The rate-limiting step k1 combined with a partial-equilibrium estimate of
atomic-oxygen concentration [O] gives a closed-form NO formation rate:

    d[NO]/dt = 2 * k1 * [O] * [N2]

[O] is obtained from the actual O2 <-> 2O dissociation equilibrium
constant Kp(T) (van't Hoff form, anchored to the O2 bond dissociation
energy) rather than a from-memory empirical curve fit -- see
`o_atom_equilibrium_concentration` below.

The Zeldovich rate expression is published in cgs units (mol/cm^3, s);
this module performs the unit handling and exposes SI-in/SI-out functions.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from aureom_h2_combustion.combustion.hydrogen_combustion import CombustionResult
from aureom_h2_combustion.combustion.mixture_ratio import MixtureState
from aureom_h2_combustion.utils.constants import (
    ATM_PRESSURE,
    H2O_MOLAR_MASS,
    H2_MOLAR_MASS,
    N2_MOLAR_MASS,
    NOX_REFERENCE_RESIDENCE_TIME,
    O2_DISSOCIATION_BOND_ENERGY_J_PER_MOL,
    O2_DISSOCIATION_KP_REFERENCE,
    O2_DISSOCIATION_KP_REFERENCE_T,
    O2_MOLAR_MASS,
    R_UNIVERSAL,
    ZELDOVICH_K1_A,
    ZELDOVICH_K1_EA_OVER_R,
)

_CM3_PER_M3 = 1.0e6

# van't Hoff pre-exponential constant for ln(Kp) = -Ea/(R*T) + C, solved so
# that Kp(O2_DISSOCIATION_KP_REFERENCE_T) == O2_DISSOCIATION_KP_REFERENCE.
_VANT_HOFF_C = (
    math.log(O2_DISSOCIATION_KP_REFERENCE)
    + O2_DISSOCIATION_BOND_ENERGY_J_PER_MOL / (R_UNIVERSAL * O2_DISSOCIATION_KP_REFERENCE_T)
)


def o2_dissociation_kp(temperature_k: float) -> float:
    """Equilibrium constant (atm-based partial pressures) for O2 <-> 2O."""
    t = max(temperature_k, 300.0)
    return math.exp(-O2_DISSOCIATION_BOND_ENERGY_J_PER_MOL / (R_UNIVERSAL * t) + _VANT_HOFF_C)


def o_atom_equilibrium_concentration_mol_per_m3(temperature_k: float, o2_partial_pressure_pa: float) -> float:
    """
    Partial-equilibrium atomic-oxygen concentration (mol/m^3) from
    Kp = (p_O)^2 / p_O2 (atm-based partial pressures):
        p_O = sqrt(Kp * p_O2)
        [O] = p_O / (R * T)     (ideal gas, p_O converted back to Pa)
    """
    t = max(temperature_k, 300.0)
    kp = o2_dissociation_kp(t)
    p_o2_atm = max(o2_partial_pressure_pa, 0.0) / ATM_PRESSURE
    p_o_atm = math.sqrt(kp * p_o2_atm)
    p_o_pa = p_o_atm * ATM_PRESSURE
    return p_o_pa / (R_UNIVERSAL * t)


@dataclass(frozen=True)
class BurnedGasComposition:
    o2_mole_fraction: float
    n2_mole_fraction: float
    h2o_mole_fraction: float
    h2_mole_fraction: float


def burned_gas_composition(result: CombustionResult, mixture: MixtureState) -> BurnedGasComposition:
    """Derive burned-gas mole fractions from the combustion mass balance."""
    from aureom_h2_combustion.utils.constants import N2_MASS_FRACTION_AIR, O2_MASS_FRACTION_AIR, STOICHIOMETRIC_O2_PER_H2_MASS

    o2_consumed_kg = result.fuel_burned_kg * STOICHIOMETRIC_O2_PER_H2_MASS
    o2_total_kg = mixture.air_mass_kg * O2_MASS_FRACTION_AIR
    o2_excess_kg = max(0.0, o2_total_kg - o2_consumed_kg)
    n2_kg = mixture.air_mass_kg * N2_MASS_FRACTION_AIR
    h2o_kg = result.water_produced_kg
    h2_excess_kg = max(0.0, mixture.fuel_mass_kg - result.fuel_burned_kg)

    moles = {
        "o2": o2_excess_kg / O2_MOLAR_MASS,
        "n2": n2_kg / N2_MOLAR_MASS,
        "h2o": h2o_kg / H2O_MOLAR_MASS,
        "h2": h2_excess_kg / H2_MOLAR_MASS,
    }
    total = sum(moles.values())
    if total <= 0:
        return BurnedGasComposition(0.0, 0.0, 0.0, 0.0)
    return BurnedGasComposition(
        o2_mole_fraction=moles["o2"] / total,
        n2_mole_fraction=moles["n2"] / total,
        h2o_mole_fraction=moles["h2o"] / total,
        h2_mole_fraction=moles["h2"] / total,
    )


def nox_formation_rate_mol_per_m3_s(
    flame_temperature_k: float,
    o2_mole_fraction: float,
    n2_mole_fraction: float,
    pressure_pa: float,
) -> float:
    """Instantaneous thermal-NO formation rate (mol/(m^3.s)) via the
    rate-limiting extended-Zeldovich step, evaluated at the local flame
    temperature and post-flame composition."""
    t = max(flame_temperature_k, 300.0)

    total_molar_conc_si = pressure_pa / (R_UNIVERSAL * t)   # mol/m^3
    total_molar_conc_cgs = total_molar_conc_si / _CM3_PER_M3  # mol/cm^3

    n2_cgs = total_molar_conc_cgs * max(n2_mole_fraction, 0.0)

    o2_partial_pressure_pa = pressure_pa * max(o2_mole_fraction, 0.0)
    o_atom_si = o_atom_equilibrium_concentration_mol_per_m3(t, o2_partial_pressure_pa)  # mol/m^3
    o_atom_cgs = o_atom_si / _CM3_PER_M3

    k1 = ZELDOVICH_K1_A * math.exp(-ZELDOVICH_K1_EA_OVER_R / t)

    rate_cgs = 2.0 * k1 * o_atom_cgs * n2_cgs  # mol/(cm^3.s)
    return rate_cgs * _CM3_PER_M3               # mol/(m^3.s)


def nox_concentration_ppm(
    flame_temperature_k: float,
    o2_mole_fraction: float,
    n2_mole_fraction: float,
    pressure_pa: float,
    residence_time_s: float = NOX_REFERENCE_RESIDENCE_TIME,
) -> float:
    """
    Integrate the formation rate over the flame-zone residence time
    (assumed quasi-steady over that short interval) to get a NO
    concentration, expressed in ppm (mole-fraction basis) of the local
    burned-gas mixture.
    """
    rate = nox_formation_rate_mol_per_m3_s(flame_temperature_k, o2_mole_fraction, n2_mole_fraction, pressure_pa)
    no_moles_per_m3 = rate * residence_time_s

    total_molar_conc_si = pressure_pa / (R_UNIVERSAL * max(flame_temperature_k, 300.0))
    if total_molar_conc_si <= 0:
        return 0.0
    mole_fraction_no = no_moles_per_m3 / total_molar_conc_si

    # Physical saturation: the quasi-steady rate integration above assumes
    # negligible N2 depletion (valid at realistic ppm-level NO formation);
    # it is not a full reacting-species ODE, so at extreme temperature /
    # pressure / residence-time combinations far outside normal engine
    # conditions it can run away. Cap NO at the N2 available to form it --
    # a hard conservation bound that can never be physically violated.
    max_mole_fraction_no = max(n2_mole_fraction, 0.0)
    mole_fraction_no = min(mole_fraction_no, max_mole_fraction_no)
    return mole_fraction_no * 1.0e6


def nox_from_combustion_event(
    result: CombustionResult,
    mixture: MixtureState,
    pressure_pa: float,
    residence_time_s: float = NOX_REFERENCE_RESIDENCE_TIME,
) -> float:
    """Convenience wrapper: NOx (ppm) directly from a CombustionResult."""
    comp = burned_gas_composition(result, mixture)
    return nox_concentration_ppm(
        result.adiabatic_flame_temperature_k,
        comp.o2_mole_fraction,
        comp.n2_mole_fraction,
        pressure_pa,
        residence_time_s,
    )
