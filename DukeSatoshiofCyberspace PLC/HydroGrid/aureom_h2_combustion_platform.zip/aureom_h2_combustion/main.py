"""
Aureom H2-Combustion Platform -- command-line entry point.

Examples
--------
Run the reference example from the platform specification:

    python main.py --engine-type hydrogen_ice --displacement 2.0 \\
        --hydrogen-flow-rate 0.8 --rpm 4500 --load 0.75 --simulation-time 120

Run a hydrogen turbine:

    python main.py --engine-type hydrogen_turbine --rpm 0 --load 0.8 \\
        --simulation-time 30

Results are written as a CSV time-series log and printed as a summary,
plus (optionally) plots of the key traces.
"""
from __future__ import annotations

import argparse
import sys

from aureom_h2_combustion.core.simulation import run_engine_simulation


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Aureom hydrogen combustion engine simulator")
    p.add_argument("--engine-type", choices=["hydrogen_ice", "hydrogen_turbine"], default="hydrogen_ice")
    p.add_argument("--displacement", type=float, default=2.0, help="ICE displacement, litres")
    p.add_argument("--hydrogen-flow-rate", type=float, default=None, help="kg/s, overrides ECU lambda targeting")
    p.add_argument("--rpm", type=float, default=4500.0)
    p.add_argument("--load", type=float, default=0.75, help="0..1 throttle/load fraction")
    p.add_argument("--simulation-time", type=float, default=120.0, help="seconds")
    p.add_argument("--dt", type=float, default=0.05, help="timestep, seconds")
    p.add_argument("--turbocharged", action="store_true")
    p.add_argument("--adaptive-ecu", action="store_true")
    p.add_argument("--out-csv", type=str, default="simulation_log.csv")
    p.add_argument("--plot", action="store_true", help="also render summary plots (PNG)")
    p.add_argument("--plot-dir", type=str, default=".")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)

    logger, financials = run_engine_simulation(
        engine_type=args.engine_type,
        displacement=args.displacement,
        hydrogen_flow_rate=args.hydrogen_flow_rate,
        rpm=args.rpm,
        load=args.load,
        simulation_time=args.simulation_time,
        dt_s=args.dt,
        turbocharged=args.turbocharged,
        adaptive_ecu=args.adaptive_ecu,
    )

    df = logger.to_dataframe()
    df.to_csv(args.out_csv)
    print(f"Wrote {len(df)} timesteps to {args.out_csv}")

    print("\n=== Simulation summary ===")
    summary = logger.summary()
    for key in ("steps", "duration_s"):
        print(f"{key}: {summary.get(key)}")

    print("\n--- Mean values ---")
    for k, v in summary.get("mean", {}).items():
        print(f"  {k}: {v:.4g}")

    print("\n--- Financials ---")
    for k, v in financials.items():
        print(f"  {k}: {v:.4g}" if isinstance(v, (int, float)) else f"  {k}: {v}")

    if args.plot:
        from aureom_h2_combustion.examples.plotting import plot_summary

        plot_summary(df, args.engine_type, args.plot_dir)
        print(f"\nPlots written to {args.plot_dir}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
