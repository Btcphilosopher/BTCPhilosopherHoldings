"""
Simplified hydrogen-air flame propagation model.

Implements a Metghalchi-Keck style laminar flame speed correlation
(S_L = S_L0(phi) * (Tu/T0)^alpha * (P/P0)^beta), a Damkohler-type turbulent
flame speed augmentation, and the resulting flame propagation / combustion
duration used to parameterise the Wiebe heat-release function in the ICE
model.

Reference data points (well documented in hydrogen combustion literature):
  * peak laminar flame speed of H2-air occurs near phi ~= 1.6-1.8, S_L,max
    ~= 2.9-3.5 m/s at standard conditions.
  * stoichiometric (phi = 1) laminar flame speed ~= 2.0-2.3 m/s.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from aureom_h2_combustion.utils.constants import (
    ATM_PRESSURE,
    ATM_TEMPERATURE,
    H2_AIR_LAMINAR_FLAME_SPEED_STOICH,
)

# Calibration for the phi-dependence Gaussian fit of laminar flame speed.
_PHI_PEAK = 1.7
_S_L_MAX = 3.1          # m/s, peak laminar flame speed at STP
_GAUSSIAN_WIDTH = 0.85  # controls fall-off away from phi_peak

# Metghalchi-Keck temperature / pressure exponents for hydrogen-air flames.
_ALPHA_T_EXP = 1.55
_BETA_P_EXP = -0.22

# Damkohler additive turbulence augmentation coefficient.
_TURBULENCE_GAIN = 1.0


def laminar_flame_speed(
    phi: float,
    unburned_temperature_k: float,
    pressure_pa: float,
    reference_temperature_k: float = ATM_TEMPERATURE,
    reference_pressure_pa: float = ATM_PRESSURE,
) -> float:
    """
    Laminar flame speed (m/s) of a hydrogen-air mixture.

    S_L(phi) is modelled as a Gaussian centred on the empirically observed
    peak-speed equivalence ratio, anchored so that phi=1 reproduces the
    well-documented stoichiometric laminar flame speed constant, then
    corrected to actual unburned-gas temperature and pressure via the
    Metghalchi-Keck power-law form.
    """
    if phi <= 0:
        return 0.0

    # Gaussian phi-shape, re-normalised so S_L(phi=1) == the stoichiometric
    # reference speed (anchoring the shape to a known measured point).
    shape_at_1 = math.exp(-((1.0 - _PHI_PEAK) ** 2) / (2 * _GAUSSIAN_WIDTH ** 2))
    shape_at_phi = math.exp(-((phi - _PHI_PEAK) ** 2) / (2 * _GAUSSIAN_WIDTH ** 2))
    s_l0 = H2_AIR_LAMINAR_FLAME_SPEED_STOICH * (shape_at_phi / shape_at_1)

    # Guard against flame speed outside flammability range.
    if phi < 0.35 or phi > 6.5:
        return 0.0

    t_ratio = max(unburned_temperature_k, 1.0) / reference_temperature_k
    p_ratio = max(pressure_pa, 1.0) / reference_pressure_pa

    s_l = s_l0 * (t_ratio ** _ALPHA_T_EXP) * (p_ratio ** _BETA_P_EXP)
    return max(s_l, 0.0)


def turbulent_flame_speed(laminar_speed_ms: float, turbulence_intensity_ms: float) -> float:
    """
    Damkohler-type additive turbulent flame speed:
        S_T = S_L + C * u'
    where u' is the turbulence intensity (approximated from mean piston
    speed / swirl in the ICE model).
    """
    return laminar_speed_ms + _TURBULENCE_GAIN * max(turbulence_intensity_ms, 0.0)


@dataclass(frozen=True)
class FlamePropagation:
    flame_speed_ms: float
    characteristic_length_m: float
    burn_duration_s: float


def flame_propagation(
    phi: float,
    unburned_temperature_k: float,
    pressure_pa: float,
    characteristic_length_m: float,
    turbulence_intensity_ms: float = 0.0,
) -> FlamePropagation:
    """
    Estimate the time for a flame kernel to traverse a characteristic
    combustion-chamber length (e.g. bore radius for an ICE, annulus depth
    for a can combustor), used to size Wiebe-function combustion duration.
    """
    s_l = laminar_flame_speed(phi, unburned_temperature_k, pressure_pa)
    s_t = turbulent_flame_speed(s_l, turbulence_intensity_ms)
    s_t = max(s_t, 1e-6)
    duration = characteristic_length_m / s_t
    return FlamePropagation(
        flame_speed_ms=s_t,
        characteristic_length_m=characteristic_length_m,
        burn_duration_s=duration,
    )
