"""
Hydrogen-air mixture ratio calculations.

Defines equivalence ratio, air-fuel ratio and lambda conversions used
throughout the combustion, fuel-system and ECU modules.
"""
from __future__ import annotations

from dataclasses import dataclass

from aureom_h2_combustion.utils.constants import STOICHIOMETRIC_AFR_MASS


@dataclass(frozen=True)
class MixtureState:
    """Instantaneous fuel-air mixture description for one combustion event."""

    air_mass_kg: float
    fuel_mass_kg: float

    @property
    def afr(self) -> float:
        """Actual air-fuel mass ratio."""
        if self.fuel_mass_kg <= 0:
            return float("inf")
        return self.air_mass_kg / self.fuel_mass_kg

    @property
    def lambda_(self) -> float:
        """Lambda (excess-air factor): 1.0 = stoichiometric, >1 lean, <1 rich."""
        return self.afr / STOICHIOMETRIC_AFR_MASS

    @property
    def equivalence_ratio(self) -> float:
        """Phi = (F/A)_actual / (F/A)_stoich = 1 / lambda."""
        lam = self.lambda_
        if lam <= 0:
            return float("inf")
        return 1.0 / lam

    @property
    def is_lean(self) -> bool:
        return self.lambda_ > 1.0 + 1e-9

    @property
    def is_rich(self) -> bool:
        return self.lambda_ < 1.0 - 1e-9

    @property
    def total_mass_kg(self) -> float:
        return self.air_mass_kg + self.fuel_mass_kg


def mixture_from_equivalence_ratio(phi: float, fuel_mass_kg: float) -> MixtureState:
    """Build a MixtureState from a target equivalence ratio and fuel mass."""
    if phi <= 0:
        raise ValueError("equivalence ratio must be positive")
    afr = STOICHIOMETRIC_AFR_MASS / phi
    air_mass_kg = afr * fuel_mass_kg
    return MixtureState(air_mass_kg=air_mass_kg, fuel_mass_kg=fuel_mass_kg)


def mixture_from_lambda(lambda_value: float, fuel_mass_kg: float) -> MixtureState:
    """Build a MixtureState from a target lambda and fuel mass."""
    if lambda_value <= 0:
        raise ValueError("lambda must be positive")
    afr = STOICHIOMETRIC_AFR_MASS * lambda_value
    air_mass_kg = afr * fuel_mass_kg
    return MixtureState(air_mass_kg=air_mass_kg, fuel_mass_kg=fuel_mass_kg)


def stoichiometric_fuel_mass(air_mass_kg: float) -> float:
    """Fuel mass (kg) that exactly consumes the available air mass."""
    return air_mass_kg / STOICHIOMETRIC_AFR_MASS


def combustible_fuel_mass(air_mass_kg: float, fuel_mass_kg: float) -> float:
    """
    Mass of fuel that actually reacts given available air (kg).

    Hydrogen combustion is air-limited when rich (lambda < 1): only the
    fuel that has an oxidiser partner burns, the rest passes through
    unburned. When lean (lambda >= 1) all fuel is consumed.
    """
    max_burnable = stoichiometric_fuel_mass(air_mass_kg)
    return min(fuel_mass_kg, max_burnable)
