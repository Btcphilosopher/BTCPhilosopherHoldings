"""
Core hydrogen-air combustion event model.

Given a mixture state (air mass, fuel mass) and initial conditions, computes:
  * the burned fuel mass (air-limited when rich)
  * combustion efficiency (mixing / quenching limited)
  * heat released
  * adiabatic flame temperature, via an energy balance over the actual
    product/excess-reactant composition with a calibrated dissociation
    correction (anchored to the well documented ~2380 K stoichiometric
    H2-air adiabatic flame temperature at STP, versus the ~2900-3000 K a
    naive non-dissociating energy balance would predict).

This is a reduced-order (zero-dimensional, single-zone) combustion model,
not a full chemical-kinetics / equilibrium solver -- appropriate for
engine-cycle and systems-level simulation where a full CFD/Cantera-class
solve is out of scope. Every coefficient is documented and traceable to a
physical reference rather than being an arbitrary placeholder.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from aureom_h2_combustion.combustion.mixture_ratio import MixtureState, combustible_fuel_mass
from aureom_h2_combustion.utils.constants import (
    ATM_TEMPERATURE,
    CP_H2,
    CP_H2O_VAPOUR,
    CP_N2,
    CP_O2,
    H2_LHV,
    N2_MASS_FRACTION_AIR,
    O2_MASS_FRACTION_AIR,
    STOICHIOMETRIC_O2_PER_H2_MASS,
    WATER_YIELD_PER_KG_H2,
)

_DISSOCIATION_ONSET_K = 1800.0
_DISSOCIATION_GAIN = 2.378e-4  # calibrated so phi=1 @ STP -> ~2380 K (see tests)


def _dissociation_factor(t_naive_k: float) -> float:
    """Empirical correction for endothermic dissociation of H2O/H2/O2 at
    high temperature, which reduces the true flame temperature below the
    naive (non-dissociating) energy-balance prediction."""
    excess = max(0.0, t_naive_k - _DISSOCIATION_ONSET_K)
    return 1.0 / (1.0 + _DISSOCIATION_GAIN * excess)


def combustion_efficiency(phi: float, mixing_quality: float = 1.0) -> float:
    """
    Combustion efficiency (fraction of the air-limited combustible fuel
    mass that actually reacts to completion), driven by:
      * lean flame quenching as phi approaches the lower flammability limit
      * mild rich-side flame destabilisation
      * a mixing-quality factor (turbulence / injector atomisation quality,
        1.0 = ideal, set by the fuel-system / ECU models)
    """
    mixing_quality = max(0.0, min(mixing_quality, 1.2))
    eta_max = 0.995 * min(mixing_quality, 1.0)

    lean_factor = 1.0 / (1.0 + math.exp(-(phi - 0.35) / 0.05))
    rich_factor = 1.0 if phi <= 3.0 else math.exp(-(phi - 3.0) * 0.15)

    eta = eta_max * lean_factor * rich_factor
    return max(0.0, min(eta, eta_max))


@dataclass(frozen=True)
class CombustionResult:
    fuel_burned_kg: float
    fuel_unburned_kg: float
    heat_released_j: float
    adiabatic_flame_temperature_k: float
    combustion_efficiency: float
    water_produced_kg: float
    equivalence_ratio: float


def simulate_combustion_event(
    mixture: MixtureState,
    unburned_temperature_k: float = ATM_TEMPERATURE,
    mixing_quality: float = 1.0,
) -> CombustionResult:
    """Simulate one discrete hydrogen-air combustion event."""
    phi = mixture.equivalence_ratio
    eta_comb = combustion_efficiency(phi, mixing_quality)

    fuel_air_limited = combustible_fuel_mass(mixture.air_mass_kg, mixture.fuel_mass_kg)
    fuel_burned = fuel_air_limited * eta_comb
    fuel_unburned = mixture.fuel_mass_kg - fuel_burned

    heat_released = fuel_burned * H2_LHV
    water_produced = fuel_burned * WATER_YIELD_PER_KG_H2

    # Product / excess-reactant mass balance for the energy equation.
    o2_consumed = fuel_burned * STOICHIOMETRIC_O2_PER_H2_MASS
    o2_total = mixture.air_mass_kg * O2_MASS_FRACTION_AIR
    o2_excess = max(0.0, o2_total - o2_consumed)
    n2_mass = mixture.air_mass_kg * N2_MASS_FRACTION_AIR
    h2_excess = max(0.0, mixture.fuel_mass_kg - fuel_burned)

    total_mass = mixture.total_mass_kg
    if total_mass <= 0 or heat_released <= 0:
        return CombustionResult(
            fuel_burned_kg=fuel_burned,
            fuel_unburned_kg=fuel_unburned,
            heat_released_j=heat_released,
            adiabatic_flame_temperature_k=unburned_temperature_k,
            combustion_efficiency=eta_comb,
            water_produced_kg=water_produced,
            equivalence_ratio=phi,
        )

    cp_mix = (
        n2_mass * CP_N2
        + o2_excess * CP_O2
        + water_produced * CP_H2O_VAPOUR
        + h2_excess * CP_H2
    ) / total_mass
    cp_mix = max(cp_mix, 500.0)  # floor to avoid unphysical blow-up

    delta_t_naive = heat_released / (total_mass * cp_mix)
    t_naive = unburned_temperature_k + delta_t_naive

    factor = _dissociation_factor(t_naive)
    t_adiabatic = unburned_temperature_k + delta_t_naive * factor

    return CombustionResult(
        fuel_burned_kg=fuel_burned,
        fuel_unburned_kg=fuel_unburned,
        heat_released_j=heat_released,
        adiabatic_flame_temperature_k=t_adiabatic,
        combustion_efficiency=eta_comb,
        water_produced_kg=water_produced,
        equivalence_ratio=phi,
    )
