"""
Heavy-duty hydrogen ICE truck: high-torque, high-mass specialisation with
a variable cargo load and correspondingly higher rolling resistance /
lower gearing (numerically higher final drive ratio for low-speed torque
multiplication).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from aureom_h2_combustion.mechanical.drivetrain import Gearbox, Wheel
from aureom_h2_combustion.vehicles.car import Vehicle, VehicleParams


@dataclass
class TruckParams(VehicleParams):
    mass_kg: float = 9500.0            # tare mass
    drag_coefficient: float = 0.55
    frontal_area_m2: float = 7.5
    wheel: Wheel = field(default_factory=lambda: Wheel(radius_m=0.51, rolling_resistance_coefficient=0.0065))
    gearbox: Gearbox = field(
        default_factory=lambda: Gearbox(
            gear_ratios=[9.5, 6.6, 4.9, 3.6, 2.7, 2.0, 1.5, 1.0], final_drive_ratio=4.1
        )
    )
    max_cargo_kg: float = 12_000.0


class Truck(Vehicle):
    def __init__(self, params: TruckParams | None = None, cargo_kg: float = 0.0):
        p = params or TruckParams()
        self._base_mass_kg = p.mass_kg
        p.mass_kg = p.mass_kg + min(max(cargo_kg, 0.0), p.max_cargo_kg if isinstance(p, TruckParams) else cargo_kg)
        super().__init__(p)
        self.cargo_kg = cargo_kg

    def set_cargo(self, cargo_kg: float) -> None:
        max_cargo = getattr(self.params, "max_cargo_kg", cargo_kg)
        self.cargo_kg = min(max(cargo_kg, 0.0), max_cargo)
        self.params.mass_kg = self._base_mass_kg + self.cargo_kg
