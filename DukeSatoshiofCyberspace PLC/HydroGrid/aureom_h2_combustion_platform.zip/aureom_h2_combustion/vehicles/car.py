"""
Vehicle longitudinal dynamics base model and the Car specialisation.

Newton's second law along the direction of travel:
    m dv/dt = F_drive - F_aero - F_rolling - F_grade - F_brake

with:
    F_aero    = 0.5 * rho_air * Cd * A * v^2
    F_rolling = Crr * m * g * cos(slope)
    F_grade   = m * g * sin(slope)
    F_drive   = wheel_torque / wheel_radius   (from the coupled drivetrain)
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from aureom_h2_combustion.mechanical.drivetrain import Gearbox, Wheel
from aureom_h2_combustion.utils.constants import STANDARD_GRAVITY

_AIR_DENSITY_SEA_LEVEL = 1.2041  # kg/m^3 at 20 C


@dataclass
class VehicleParams:
    mass_kg: float = 1550.0
    drag_coefficient: float = 0.29
    frontal_area_m2: float = 2.3
    wheel: Wheel = field(default_factory=lambda: Wheel(radius_m=0.32, rolling_resistance_coefficient=0.011))
    gearbox: Gearbox = field(default_factory=Gearbox)


@dataclass
class VehicleState:
    speed_ms: float = 0.0
    position_m: float = 0.0
    acceleration_ms2: float = 0.0


class Vehicle:
    """Generic longitudinal-dynamics vehicle; specialised by Car/Truck/Train."""

    def __init__(self, params: VehicleParams):
        self.params = params
        self.state = VehicleState()

    def resistive_forces_n(self, speed_ms: float, slope_rad: float = 0.0) -> dict:
        aero = 0.5 * _AIR_DENSITY_SEA_LEVEL * self.params.drag_coefficient * self.params.frontal_area_m2 * speed_ms ** 2
        rolling = (
            self.params.wheel.rolling_resistance_coefficient
            * self.params.mass_kg
            * STANDARD_GRAVITY
            * math.cos(slope_rad)
        )
        grade = self.params.mass_kg * STANDARD_GRAVITY * math.sin(slope_rad)
        return {"aero_n": aero, "rolling_n": rolling, "grade_n": grade}

    def step(
        self,
        engine_torque_nm: float,
        dt_s: float,
        slope_rad: float = 0.0,
        brake_force_n: float = 0.0,
        gear_index: int | None = None,
    ) -> VehicleState:
        wheel_torque = self.params.gearbox.wheel_torque_nm(engine_torque_nm, gear_index)
        drive_force = self.params.wheel.drive_force_n(wheel_torque)

        resist = self.resistive_forces_n(self.state.speed_ms, slope_rad)
        net_force = drive_force - resist["aero_n"] - resist["rolling_n"] - resist["grade_n"] - brake_force_n

        accel = net_force / self.params.mass_kg
        new_speed = max(self.state.speed_ms + accel * dt_s, 0.0)
        # Prevent driving backward from over-braking within one timestep.
        if self.state.speed_ms > 0 and new_speed <= 0:
            accel = -self.state.speed_ms / dt_s
            new_speed = 0.0

        self.state.acceleration_ms2 = accel
        self.state.position_m += self.state.speed_ms * dt_s + 0.5 * accel * dt_s ** 2
        self.state.speed_ms = new_speed
        return self.state

    def required_wheel_torque_for_power(self, power_w: float, speed_ms: float) -> float:
        omega = self.params.wheel.angular_speed_rad_s(max(speed_ms, 0.1))
        return power_w / omega


class Car(Vehicle):
    """Passenger hydrogen-ICE car: light, low rolling resistance, high gearing."""

    def __init__(self, params: VehicleParams | None = None):
        super().__init__(params or VehicleParams())
