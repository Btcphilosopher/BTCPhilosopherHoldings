"""
Multi-engine distributed hydrogen-traction train consist.

Train running resistance uses the classic Davis-equation structure
(Davis, 1926; still the standard form used in modern rail traction
studies): R = A + B*v + C*v^2, where each term has a distinct physical
origin:
    A  ->  journal/bearing (per-axle) friction, ~speed-independent
    B*v -> mechanical (flange/track) resistance, linear in speed
    C*v^2 -> aerodynamic drag of the consist

Traction is distributed across multiple powered locomotive units (e.g. a
consist of hydrogen-ICE or hydrogen-turbine locomotives), each
contributing tractive effort at the rail independently -- modelling
realistic distributed-power freight/passenger consists.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from aureom_h2_combustion.mechanical.drivetrain import Gearbox, Wheel
from aureom_h2_combustion.utils.constants import STANDARD_GRAVITY

_AIR_DENSITY_SEA_LEVEL = 1.2041  # kg/m^3


@dataclass
class LocomotiveUnit:
    """One powered traction unit within the consist."""

    name: str
    rated_power_w: float
    wheel: Wheel = field(default_factory=lambda: Wheel(radius_m=0.51, rolling_resistance_coefficient=0.0015))
    gearbox: Gearbox = field(default_factory=lambda: Gearbox(gear_ratios=[1.0], final_drive_ratio=4.5))

    def tractive_force_n(self, engine_torque_nm: float, gear_index: int | None = None) -> float:
        wheel_torque = self.gearbox.wheel_torque_nm(engine_torque_nm, gear_index)
        return self.wheel.drive_force_n(wheel_torque)


@dataclass
class TrainParams:
    locomotive_mass_kg: float = 130_000.0     # per powered locomotive unit
    railcar_mass_kg: float = 80_000.0         # per hauled car
    num_railcars: int = 20
    axles_per_locomotive: int = 6
    axles_per_railcar: int = 4
    frontal_area_m2: float = 11.0
    drag_coefficient: float = 0.9

    # Davis-equation empirical coefficients (SI, per the physical
    # decomposition documented in the module docstring).
    journal_resistance_n_per_axle: float = 45.0
    mechanical_resistance_n_per_kg_per_ms: float = 0.00012


class TrainConsist:
    def __init__(self, locomotives: list[LocomotiveUnit], params: TrainParams | None = None):
        self.locomotives = locomotives
        self.params = params or TrainParams()
        self.speed_ms = 0.0
        self.position_m = 0.0
        self.acceleration_ms2 = 0.0

    @property
    def total_mass_kg(self) -> float:
        return (
            len(self.locomotives) * self.params.locomotive_mass_kg
            + self.params.num_railcars * self.params.railcar_mass_kg
        )

    @property
    def total_axles(self) -> int:
        return (
            len(self.locomotives) * self.params.axles_per_locomotive
            + self.params.num_railcars * self.params.axles_per_railcar
        )

    def davis_resistance_n(self, speed_ms: float, slope_rad: float = 0.0) -> float:
        mass = self.total_mass_kg
        a_term = self.params.journal_resistance_n_per_axle * self.total_axles
        b_term = self.params.mechanical_resistance_n_per_kg_per_ms * mass * speed_ms
        c_term = 0.5 * _AIR_DENSITY_SEA_LEVEL * self.params.drag_coefficient * self.params.frontal_area_m2 * speed_ms ** 2
        grade_term = mass * STANDARD_GRAVITY * slope_rad  # small-angle grade force
        return a_term + b_term + c_term + grade_term

    def step(self, locomotive_torques_nm: list[float], dt_s: float, slope_rad: float = 0.0, brake_force_n: float = 0.0) -> float:
        """Advance the consist by dt_s given each locomotive's commanded
        engine torque this step; returns the new consist speed (m/s)."""
        if len(locomotive_torques_nm) != len(self.locomotives):
            raise ValueError("must supply one torque command per locomotive unit")

        total_tractive_force = sum(
            loco.tractive_force_n(t) for loco, t in zip(self.locomotives, locomotive_torques_nm)
        )
        resistance = self.davis_resistance_n(self.speed_ms, slope_rad)
        net_force = total_tractive_force - resistance - brake_force_n

        accel = net_force / self.total_mass_kg
        new_speed = max(self.speed_ms + accel * dt_s, 0.0)
        if self.speed_ms > 0 and new_speed <= 0:
            accel = -self.speed_ms / dt_s
            new_speed = 0.0

        self.acceleration_ms2 = accel
        self.position_m += self.speed_ms * dt_s + 0.5 * accel * dt_s ** 2
        self.speed_ms = new_speed
        return self.speed_ms

    def total_rated_power_w(self) -> float:
        return sum(loco.rated_power_w for loco in self.locomotives)
