"""
Per-timestep engine loop: the exact sequence described in the platform
specification --

    for each timestep:
        compute fuel-air mixture
        simulate combustion event
        update pressure + temperature
        compute mechanical output (torque/power)
        update drivetrain response
        apply thermal losses
        update emissions
        apply wear/degradation
        log system state

implemented here for both the hydrogen ICE and hydrogen turbine engine
types, returning a flat dict of results consumed by core.simulation.
"""
from __future__ import annotations

from dataclasses import dataclass

from aureom_h2_combustion.control.ecu import ECU
from aureom_h2_combustion.engines.ice_engine import ICECycleResult, ICEEngine
from aureom_h2_combustion.engines.turbine_engine import TurbineCycleResult, TurbineEngine
from aureom_h2_combustion.mechanical.crankshaft import CrankshaftDynamics, rpm_to_omega
from aureom_h2_combustion.thermal.cooling_system import CoolingSystem
from aureom_h2_combustion.thermal.heat_model import EngineThermalMass

_BLOCK_TO_COOLANT_UA_W_PER_K = 900.0


@dataclass
class ICEStepResult:
    cycle: ICECycleResult
    ignition_timing_btdc_deg: float
    lambda_commanded: float
    thermal_throttle_factor: float
    block_temperature_k: float
    coolant_temperature_k: float
    brake_torque_nm: float
    brake_power_w: float
    crank_rpm: float
    mechanical_efficiency: float
    wear_fraction: float


def step_ice_engine(
    engine: ICEEngine,
    ecu: ECU,
    crank: CrankshaftDynamics,
    thermal: EngineThermalMass,
    cooling: CoolingSystem,
    rpm_command: float,
    load: float,
    dt_s: float,
    load_torque_nm: float,
    last_knock_risk: float = 0.0,
    lambda_override: float | None = None,
) -> ICEStepResult:
    """Advance the hydrogen-ICE subsystem stack by one timestep."""
    # 1. ECU computes fuel-air mixture (lambda) and ignition timing commands
    #    (unless the caller supplies a direct fuel-flow-derived lambda target).
    lam = lambda_override if lambda_override is not None else ecu.target_lambda(load)
    ignition = ecu.ignition_timing_deg(rpm_command, load, last_knock_risk)

    # 2-3. Simulate the combustion event and resulting in-cylinder pressure/temperature trace.
    cycle = engine.run_cycle(
        rpm=rpm_command,
        load=load,
        wall_temperature_k=thermal.temperature_k,
        lambda_override=lam,
        ignition_timing_btdc_override=ignition,
    )
    ecu.update_adaptive_trim(cycle.knock_risk, cycle.combustion.combustion_efficiency)

    # 4. Thermal throttling derates commanded output if overheating.
    throttle_factor = thermal.thermal_throttle_factor()
    effective_indicated_torque = cycle.indicated_torque_nm * throttle_factor

    # 5. Mechanical output: crankshaft rotational dynamics (friction, wear, inertia).
    mean_contact_load_n = cycle.peak_pressure_pa * engine.geometry.piston_area_m2
    crank.step(effective_indicated_torque, load_torque_nm, dt_s, mean_contact_load_n)
    brake_torque = effective_indicated_torque * crank.mechanical_efficiency - crank.friction_torque_nm()
    brake_torque = max(brake_torque, 0.0)
    brake_power = brake_torque * crank.omega_rad_s

    # 6. Thermal losses: wall heat -> block -> coolant -> ambient.
    cycles_per_s = engine.cycles_per_second(rpm_command)
    heat_to_block_w = cycle.heat_rejected_to_walls_j * cycles_per_s
    heat_block_to_coolant_w = _BLOCK_TO_COOLANT_UA_W_PER_K * max(thermal.temperature_k - cooling.coolant_temperature_k, 0.0)
    thermal.step(heat_to_block_w, heat_block_to_coolant_w, dt_s)
    cooling.step(heat_block_to_coolant_w, dt_s)

    # 7 & 8. Emissions and wear/degradation already updated by cycle/crank steps above; logging is the caller's job.
    return ICEStepResult(
        cycle=cycle,
        ignition_timing_btdc_deg=ignition,
        lambda_commanded=lam,
        thermal_throttle_factor=throttle_factor,
        block_temperature_k=thermal.temperature_k,
        coolant_temperature_k=cooling.coolant_temperature_k,
        brake_torque_nm=brake_torque,
        brake_power_w=brake_power,
        crank_rpm=crank.rpm,
        mechanical_efficiency=crank.mechanical_efficiency,
        wear_fraction=crank.cumulative_wear_fraction,
    )


@dataclass
class TurbineStepResult:
    cycle: TurbineCycleResult
    net_shaft_power_w: float


def step_turbine_engine(engine: TurbineEngine, throttle: float) -> TurbineStepResult:
    """Advance the hydrogen-turbine subsystem by one timestep (the turbine
    model is quasi-steady per throttle setting; no crank-angle-resolved
    integration is needed since there is no reciprocating motion)."""
    cycle = engine.run(throttle)
    return TurbineStepResult(cycle=cycle, net_shaft_power_w=cycle.shaft_power_w)
