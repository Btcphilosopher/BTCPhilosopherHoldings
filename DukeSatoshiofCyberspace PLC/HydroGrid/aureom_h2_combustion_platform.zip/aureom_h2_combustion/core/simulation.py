"""
Top-level deterministic simulation orchestrator.

Implements the timestep loop from the platform specification:

    for each timestep:
        compute fuel-air mixture
        simulate combustion event
        update pressure + temperature
        compute mechanical output (torque/power)
        update drivetrain response
        apply thermal losses
        update emissions
        apply wear/degradation
        log system state

Two engine types are supported end-to-end: "hydrogen_ice" (piston ICE,
via core.engine_loop.step_ice_engine) and "hydrogen_turbine" (gas
turbine, via core.engine_loop.step_turbine_engine). The default run mode
is an engine-test-cell / dynamometer style simulation at a commanded
(rpm, load) operating point, tracking the genuine transient thermal,
wear and control-loop dynamics over the simulated duration -- this is
what the reference `run_engine_simulation(...)` example exercises.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from aureom_h2_combustion.control.ecu import ECU, ECUConfig
from aureom_h2_combustion.core.engine_loop import step_ice_engine, step_turbine_engine
from aureom_h2_combustion.emissions.water_vapour import emissions_snapshot
from aureom_h2_combustion.engines.ice_engine import ICEConfig, ICEEngine
from aureom_h2_combustion.engines.turbine_engine import TurbineConfig, TurbineEngine
from aureom_h2_combustion.financials.cost_model import (
    FuelEconomics,
    MaintenanceSchedule,
    cost_per_kwh,
)
from aureom_h2_combustion.fuel_system.air_intake import AirIntakeSystem
from aureom_h2_combustion.mechanical.crankshaft import CrankshaftDynamics, rpm_to_omega
from aureom_h2_combustion.thermal.cooling_system import CoolingSystem
from aureom_h2_combustion.thermal.heat_model import EngineThermalMass
from aureom_h2_combustion.utils.constants import ATM_PRESSURE, ATM_TEMPERATURE
from aureom_h2_combustion.utils.logging import SimulationLogger


@dataclass
class SimulationConfig:
    engine_type: str = "hydrogen_ice"          # "hydrogen_ice" | "hydrogen_turbine"
    displacement_l: float = 2.0
    num_cylinders: int = 4
    compression_ratio: float = 12.0
    turbocharged: bool = False
    boost_pressure_ratio: float = 1.6

    hydrogen_flow_rate_kg_s: float | None = None  # if set, overrides ECU lambda targeting
    rpm: float = 4500.0
    load: float = 0.75
    simulation_time_s: float = 120.0
    dt_s: float = 0.05

    ambient_temperature_k: float = ATM_TEMPERATURE
    ambient_pressure_pa: float = ATM_PRESSURE
    adaptive_ecu: bool = False

    turbine_config: TurbineConfig = field(default_factory=TurbineConfig)
    fuel_economics: FuelEconomics = field(default_factory=FuelEconomics)
    maintenance: MaintenanceSchedule = field(default_factory=MaintenanceSchedule)


class Simulation:
    def __init__(self, config: SimulationConfig):
        self.config = config
        self.logger = SimulationLogger()

        if config.engine_type == "hydrogen_ice":
            self.ice_config = ICEConfig(
                displacement_l=config.displacement_l,
                num_cylinders=config.num_cylinders,
                compression_ratio=config.compression_ratio,
                turbocharged=config.turbocharged,
                boost_pressure_ratio=config.boost_pressure_ratio,
            )
            self.engine = ICEEngine(self.ice_config, AirIntakeSystem(turbocharged=config.turbocharged))
            self.ecu = ECU(config=ECUConfig(), adaptive=config.adaptive_ecu)
            flywheel_inertia = 0.15 + 0.02 * config.num_cylinders
            self.crank = CrankshaftDynamics(rotational_inertia_kg_m2=flywheel_inertia)
            self.crank.omega_rad_s = rpm_to_omega(config.rpm)
            self.thermal = EngineThermalMass(mass_kg=45.0 + 8.0 * config.num_cylinders)
            self.thermal.temperature_k = config.ambient_temperature_k
            self.cooling = CoolingSystem()
            self.cooling.coolant_temperature_k = config.ambient_temperature_k
            self.cooling.ambient_temperature_k = config.ambient_temperature_k
            self._last_knock_risk = 0.0
        elif config.engine_type == "hydrogen_turbine":
            self.turbine = TurbineEngine(config.turbine_config)
        else:
            raise ValueError(f"unknown engine_type: {config.engine_type!r}")

        self._cumulative_fuel_kg = 0.0
        self._cumulative_energy_j = 0.0
        self._cumulative_water_kg = 0.0

    # ------------------------------------------------------------------
    def _dynamometer_torque_estimate(self) -> float:
        """One-off characterisation run at (rpm, load=1.0) used to size the
        dynamometer's resisting torque for the requested `load` fraction."""
        probe = self.engine.run_cycle(self.config.rpm, 1.0)
        return probe.indicated_torque_nm

    def _lambda_override_for_flow(self, rpm: float) -> float | None:
        if self.config.hydrogen_flow_rate_kg_s is None:
            return None
        cycles_per_s = self.engine.cycles_per_second(rpm)
        fuel_mass_per_cycle = self.config.hydrogen_flow_rate_kg_s / max(cycles_per_s, 1e-6) / self.config.num_cylinders
        boost_pr = 1.0 + (self.config.boost_pressure_ratio - 1.0) * self.config.load if self.config.turbocharged else 1.0
        air_mass = self.engine.air_intake.air_mass_per_cycle_kg(
            self.engine.geometry.displacement_volume_m3, rpm, boost_pr, self.config.load > 0.95
        ) * max(self.config.load, 0.12)
        from aureom_h2_combustion.utils.constants import STOICHIOMETRIC_AFR_MASS

        stoich_afr = STOICHIOMETRIC_AFR_MASS
        if fuel_mass_per_cycle <= 0:
            return self.ecu.config.max_lambda
        lam = air_mass / (fuel_mass_per_cycle * stoich_afr)
        return max(self.ecu.config.min_lambda, min(lam, self.ecu.config.max_lambda))

    def run(self) -> SimulationLogger:
        if self.config.engine_type == "hydrogen_ice":
            self._run_ice()
        else:
            self._run_turbine()
        return self.logger

    # ------------------------------------------------------------------
    def _run_ice(self) -> None:
        rated_torque = self._dynamometer_torque_estimate()
        n_steps = max(int(self.config.simulation_time_s / self.config.dt_s), 1)

        for i in range(n_steps):
            t = i * self.config.dt_s
            load_torque = self.config.load * rated_torque * 0.9  # dyno holds slightly under rated to allow governing

            lam_override = self._lambda_override_for_flow(self.crank.rpm)

            result = step_ice_engine(
                self.engine,
                self.ecu,
                self.crank,
                self.thermal,
                self.cooling,
                rpm_command=max(self.crank.rpm, 50.0),
                load=self.config.load,
                dt_s=self.config.dt_s,
                load_torque_nm=load_torque,
                last_knock_risk=self._last_knock_risk,
                lambda_override=lam_override,
            )
            self._last_knock_risk = result.cycle.knock_risk

            self._cumulative_fuel_kg += result.cycle.combustion.fuel_burned_kg * self.config.num_cylinders
            self._cumulative_energy_j += result.brake_power_w * self.config.dt_s
            self._cumulative_water_kg += result.cycle.water_vapour_kg

            exhaust_mass_kg = (result.cycle.mixture.total_mass_kg) * self.config.num_cylinders
            emissions = emissions_snapshot(
                result.cycle.combustion.fuel_burned_kg * self.config.num_cylinders,
                result.cycle.nox_ppm,
                exhaust_mass_kg,
                max(result.brake_power_w * self.config.dt_s, 1e-9),
            )

            self.logger.log(
                i,
                t,
                rpm=result.crank_rpm,
                load=self.config.load,
                lambda_commanded=result.lambda_commanded,
                equivalence_ratio=result.cycle.mixture.equivalence_ratio,
                ignition_timing_btdc_deg=result.ignition_timing_btdc_deg,
                imep_kpa=result.cycle.imep_pa / 1000.0,
                indicated_torque_nm=result.cycle.indicated_torque_nm,
                brake_torque_nm=result.brake_torque_nm,
                brake_power_kw=result.brake_power_w / 1000.0,
                peak_pressure_bar=result.cycle.peak_pressure_pa / 1e5,
                peak_temperature_k=result.cycle.peak_temperature_k,
                combustion_efficiency=result.cycle.combustion.combustion_efficiency,
                knock_risk=result.cycle.knock_risk,
                block_temperature_c=result.block_temperature_k - 273.15,
                coolant_temperature_c=result.coolant_temperature_k - 273.15,
                thermal_throttle_factor=result.thermal_throttle_factor,
                mechanical_efficiency=result.mechanical_efficiency,
                wear_fraction=result.wear_fraction,
                nox_ppm=result.cycle.nox_ppm,
                water_vapour_kg_s=result.cycle.water_vapour_kg / self.config.dt_s,
                environmental_impact_score=emissions.environmental_impact_score,
                cumulative_fuel_kg=self._cumulative_fuel_kg,
                cumulative_energy_kwh=self._cumulative_energy_j / 3.6e6,
            )

    # ------------------------------------------------------------------
    def _run_turbine(self) -> None:
        n_steps = max(int(self.config.simulation_time_s / self.config.dt_s), 1)
        throttle = self.config.load

        for i in range(n_steps):
            t = i * self.config.dt_s
            result = step_turbine_engine(self.turbine, throttle)
            cycle = result.cycle

            self._cumulative_fuel_kg += cycle.fuel_flow_kg_s * self.config.dt_s
            self._cumulative_energy_j += result.net_shaft_power_w * self.config.dt_s
            self._cumulative_water_kg += cycle.water_vapour_kg_s * self.config.dt_s

            exhaust_mass_kg_s = self.turbine.config.air_mass_flow_kg_s + cycle.fuel_flow_kg_s
            emissions = emissions_snapshot(
                cycle.fuel_flow_kg_s * self.config.dt_s,
                cycle.nox_ppm,
                exhaust_mass_kg_s * self.config.dt_s,
                max(result.net_shaft_power_w * self.config.dt_s, 1e-9),
            )

            self.logger.log(
                i,
                t,
                throttle=throttle,
                shaft_power_kw=result.net_shaft_power_w / 1000.0,
                compressor_work_kw=cycle.compressor_work_w / 1000.0,
                fuel_flow_kg_s=cycle.fuel_flow_kg_s,
                turbine_inlet_temperature_k=cycle.turbine_inlet_temperature_k,
                exhaust_temperature_k=cycle.exhaust_temperature_k,
                thermal_efficiency=cycle.thermal_efficiency,
                combustion_efficiency=cycle.combustion_efficiency,
                surge_margin=cycle.surge_margin,
                nox_ppm=cycle.nox_ppm,
                water_vapour_kg_s=cycle.water_vapour_kg_s,
                environmental_impact_score=emissions.environmental_impact_score,
                cumulative_fuel_kg=self._cumulative_fuel_kg,
                cumulative_energy_kwh=self._cumulative_energy_j / 3.6e6,
            )

    # ------------------------------------------------------------------
    def financial_summary(self) -> dict:
        operating_hours = self.config.simulation_time_s / 3600.0
        wear_fraction = 0.0
        if self.config.engine_type == "hydrogen_ice":
            wear_fraction = self.crank.cumulative_wear_fraction
        breakdown = cost_per_kwh(
            self._cumulative_fuel_kg,
            operating_hours,
            wear_fraction,
            self._cumulative_energy_j,
            self.config.fuel_economics,
            self.config.maintenance,
        )
        return {
            "fuel_cost_usd": breakdown.fuel_cost_usd,
            "maintenance_cost_usd": breakdown.maintenance_cost_usd,
            "degradation_cost_usd": breakdown.degradation_cost_usd,
            "capital_amortisation_usd": breakdown.capital_amortisation_usd,
            "total_cost_usd": breakdown.total_cost_usd,
            "energy_delivered_kwh": breakdown.energy_delivered_kwh,
            "cost_per_kwh_usd": breakdown.cost_per_kwh,
            "cumulative_hydrogen_kg": self._cumulative_fuel_kg,
            "cumulative_water_vapour_kg": self._cumulative_water_kg,
        }


def run_engine_simulation(
    engine_type: str = "hydrogen_ice",
    displacement: float = 2.0,
    hydrogen_flow_rate: float | None = 0.8,
    rpm: float = 4500,
    load: float = 0.75,
    simulation_time: float = 120,
    **kwargs,
) -> tuple[SimulationLogger, dict]:
    """
    Convenience entry point matching the platform specification's example
    call signature. Returns (logger, financial_summary).
    """
    config = SimulationConfig(
        engine_type=engine_type,
        displacement_l=displacement,
        hydrogen_flow_rate_kg_s=hydrogen_flow_rate,
        rpm=rpm,
        load=load,
        simulation_time_s=simulation_time,
        **kwargs,
    )
    sim = Simulation(config)
    logger = sim.run()
    return logger, sim.financial_summary()
