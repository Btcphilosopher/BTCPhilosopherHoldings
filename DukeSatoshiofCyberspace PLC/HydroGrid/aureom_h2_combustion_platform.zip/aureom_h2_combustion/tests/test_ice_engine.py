import pytest

from aureom_h2_combustion.engines.ice_engine import ICEConfig, ICEEngine


@pytest.fixture
def engine():
    return ICEEngine(ICEConfig(displacement_l=2.0, num_cylinders=4, compression_ratio=12.0, target_lambda=1.4))


def test_geometry_reconstructs_displacement(engine):
    vd = engine.geometry.displacement_volume_m3 * engine.config.num_cylinders
    assert vd == pytest.approx(2.0e-3, rel=1e-6)


def test_run_cycle_produces_positive_torque_at_moderate_load(engine):
    result = engine.run_cycle(rpm=4500, load=0.75)
    assert result.indicated_torque_nm > 0
    assert result.indicated_power_w > 0
    assert result.peak_pressure_pa > 101_325.0
    assert result.combustion.fuel_burned_kg > 0


def test_torque_increases_monotonically_with_load(engine):
    torques = [engine.run_cycle(rpm=3000, load=load).indicated_torque_nm for load in (0.2, 0.5, 0.8, 1.0)]
    assert all(torques[i] < torques[i + 1] for i in range(len(torques) - 1))


def test_nox_increases_as_mixture_approaches_stoichiometric(engine):
    lean_result = engine.run_cycle(rpm=3000, load=0.5, lambda_override=2.0)
    rich_result = engine.run_cycle(rpm=3000, load=0.5, lambda_override=1.05)
    assert lean_result.nox_ppm < rich_result.nox_ppm


def test_wall_heat_loss_is_positive_and_scales_with_load(engine):
    low = engine.run_cycle(rpm=3000, load=0.3)
    high = engine.run_cycle(rpm=3000, load=0.9)
    assert low.heat_rejected_to_walls_j > 0
    assert high.heat_rejected_to_walls_j > low.heat_rejected_to_walls_j


def test_knock_risk_is_bounded(engine):
    result = engine.run_cycle(rpm=4500, load=1.0)
    assert 0.0 <= result.knock_risk <= 1.0


def test_cycles_per_second_matches_four_stroke_relation(engine):
    assert engine.cycles_per_second(3000) == pytest.approx(25.0, rel=1e-6)
