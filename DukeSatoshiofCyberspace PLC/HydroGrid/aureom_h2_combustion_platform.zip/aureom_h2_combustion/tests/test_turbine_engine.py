import pytest

from aureom_h2_combustion.engines.turbine_engine import TurbineConfig, TurbineEngine


@pytest.fixture
def engine():
    return TurbineEngine(TurbineConfig())


def test_shaft_power_increases_with_throttle(engine):
    powers = [engine.run(t).shaft_power_w for t in (0.2, 0.5, 0.8, 1.0)]
    assert all(powers[i] < powers[i + 1] for i in range(len(powers) - 1))


def test_fuel_flow_increases_monotonically_with_throttle(engine):
    flows = [engine.run(t).fuel_flow_kg_s for t in (0.2, 0.5, 0.8, 1.0)]
    assert all(flows[i] < flows[i + 1] for i in range(len(flows) - 1))


def test_thermal_efficiency_is_physically_bounded(engine):
    for t in (0.1, 0.4, 0.7, 1.0):
        eta = engine.run(t).thermal_efficiency
        assert 0.0 <= eta <= 0.6


def test_turbine_inlet_temperature_respects_material_limit(engine):
    result = engine.run(1.0)
    assert result.turbine_inlet_temperature_k <= engine.config.max_turbine_inlet_temperature_k + 1e-6


def test_compressor_surge_margin_is_finite(engine):
    result = engine.run(0.6)
    assert -50 < result.surge_margin < 50


def test_water_vapour_output_scales_with_fuel_flow(engine):
    low = engine.run(0.3)
    high = engine.run(0.9)
    assert high.water_vapour_kg_s > low.water_vapour_kg_s
