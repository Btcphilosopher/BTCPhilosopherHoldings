import pytest

from aureom_h2_combustion.financials.cost_model import (
    FuelEconomics,
    MaintenanceSchedule,
    breakeven_vs_diesel,
    cost_per_kwh,
    hydrogen_fuel_cost,
    infrastructure_scaling_cost,
)


def test_hydrogen_fuel_cost_scales_linearly():
    econ = FuelEconomics(hydrogen_price_per_kg=6.0)
    assert hydrogen_fuel_cost(2.0, econ) == pytest.approx(12.0)


def test_cost_per_kwh_is_positive_and_finite():
    econ = FuelEconomics()
    maint = MaintenanceSchedule()
    breakdown = cost_per_kwh(
        fuel_mass_kg=10.0,
        operating_hours=20.0,
        wear_fraction=0.01,
        energy_delivered_j=1.0e9,
        economics=econ,
        maintenance=maint,
    )
    assert breakdown.total_cost_usd > 0
    assert breakdown.cost_per_kwh > 0
    assert breakdown.energy_delivered_kwh == pytest.approx(1.0e9 / 3.6e6)


def test_breakeven_returns_none_when_hydrogen_never_cheaper():
    econ = FuelEconomics(hydrogen_price_per_kg=50.0)  # deliberately uneconomic
    maint = MaintenanceSchedule()
    result = breakeven_vs_diesel(maint, 25_000.0, 5.0, 80_000.0, econ)
    assert result.breakeven_hours is None


def test_infrastructure_cost_scales_with_stations_and_pipeline():
    base = infrastructure_scaling_cost(1)
    more_stations = infrastructure_scaling_cost(2)
    with_pipeline = infrastructure_scaling_cost(1, pipeline_km=10.0)
    assert more_stations > base
    assert with_pipeline > base
