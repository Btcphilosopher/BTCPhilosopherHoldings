import pytest

from aureom_h2_combustion.core.simulation import run_engine_simulation


def test_ice_simulation_runs_end_to_end_and_is_deterministic():
    logger1, fin1 = run_engine_simulation(
        engine_type="hydrogen_ice", displacement=2.0, hydrogen_flow_rate=0.0008,
        rpm=4500, load=0.75, simulation_time=1.0, dt_s=0.1,
    )
    logger2, fin2 = run_engine_simulation(
        engine_type="hydrogen_ice", displacement=2.0, hydrogen_flow_rate=0.0008,
        rpm=4500, load=0.75, simulation_time=1.0, dt_s=0.1,
    )
    df1 = logger1.to_dataframe()
    df2 = logger2.to_dataframe()
    assert len(df1) == len(df2) == 10
    assert (df1["brake_power_kw"].values == df2["brake_power_kw"].values).all()
    assert fin1["cumulative_hydrogen_kg"] == pytest.approx(fin2["cumulative_hydrogen_kg"])


def test_ice_simulation_produces_sane_physical_ranges():
    logger, fin = run_engine_simulation(
        engine_type="hydrogen_ice", displacement=2.0, hydrogen_flow_rate=None,
        rpm=4500, load=0.75, simulation_time=2.0, dt_s=0.1,
    )
    df = logger.to_dataframe()
    assert (df["brake_power_kw"] >= 0).all()
    assert (df["peak_pressure_bar"] > 1.0).all()
    assert (df["block_temperature_c"] > -50).all()
    assert (df["combustion_efficiency"] <= 1.0).all()
    assert fin["cumulative_hydrogen_kg"] > 0


def test_turbine_simulation_runs_end_to_end():
    logger, fin = run_engine_simulation(
        engine_type="hydrogen_turbine", rpm=0, load=0.7, simulation_time=1.0, dt_s=0.2,
    )
    df = logger.to_dataframe()
    assert len(df) == 5
    assert (df["shaft_power_kw"] > 0).all()
    assert fin["cumulative_hydrogen_kg"] > 0


def test_unknown_engine_type_raises():
    with pytest.raises(ValueError):
        run_engine_simulation(engine_type="not_a_real_engine", simulation_time=0.1)
