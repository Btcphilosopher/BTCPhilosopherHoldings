import math

import pytest

from aureom_h2_combustion.combustion.hydrogen_combustion import combustion_efficiency, simulate_combustion_event
from aureom_h2_combustion.combustion.mixture_ratio import (
    MixtureState,
    mixture_from_equivalence_ratio,
    mixture_from_lambda,
)
from aureom_h2_combustion.utils.constants import STOICHIOMETRIC_AFR_MASS, WATER_YIELD_PER_KG_H2


def test_stoichiometric_afr_matches_known_value():
    # Widely documented value for hydrogen in air, mass basis.
    assert STOICHIOMETRIC_AFR_MASS == pytest.approx(34.3, rel=0.02)


def test_mixture_ratio_roundtrip():
    m = mixture_from_lambda(1.5, fuel_mass_kg=1.0)
    assert m.lambda_ == pytest.approx(1.5, rel=1e-6)
    assert m.equivalence_ratio == pytest.approx(1.0 / 1.5, rel=1e-6)

    m2 = mixture_from_equivalence_ratio(0.7, fuel_mass_kg=1.0)
    assert m2.equivalence_ratio == pytest.approx(0.7, rel=1e-6)


def test_water_yield_stoichiometry():
    m = MixtureState(air_mass_kg=STOICHIOMETRIC_AFR_MASS, fuel_mass_kg=1.0)
    result = simulate_combustion_event(m)
    expected_water = result.fuel_burned_kg * WATER_YIELD_PER_KG_H2
    assert result.water_produced_kg == pytest.approx(expected_water, rel=1e-9)
    # ~9 kg water per kg H2 burned (2 H2 + O2 -> 2 H2O stoichiometry).
    assert 8.5 < WATER_YIELD_PER_KG_H2 < 9.5


def test_stoichiometric_adiabatic_flame_temperature_matches_reference():
    """Anchor check: stoichiometric H2-air adiabatic flame temperature at
    STP is well documented at ~2380 K (post-dissociation)."""
    m = MixtureState(air_mass_kg=STOICHIOMETRIC_AFR_MASS, fuel_mass_kg=1.0)
    result = simulate_combustion_event(m, unburned_temperature_k=298.15)
    assert result.adiabatic_flame_temperature_k == pytest.approx(2380.0, rel=0.06)


def test_lean_mixture_has_lower_flame_temperature_than_stoichiometric():
    stoich = MixtureState(air_mass_kg=STOICHIOMETRIC_AFR_MASS, fuel_mass_kg=1.0)
    lean = MixtureState(air_mass_kg=STOICHIOMETRIC_AFR_MASS * 1.6, fuel_mass_kg=1.0)
    t_stoich = simulate_combustion_event(stoich).adiabatic_flame_temperature_k
    t_lean = simulate_combustion_event(lean).adiabatic_flame_temperature_k
    assert t_lean < t_stoich


def test_rich_mixture_leaves_unburned_fuel():
    rich = MixtureState(air_mass_kg=STOICHIOMETRIC_AFR_MASS * 0.5, fuel_mass_kg=1.0)
    result = simulate_combustion_event(rich)
    assert result.fuel_unburned_kg > 0
    assert result.fuel_burned_kg < 1.0


def test_combustion_efficiency_bounded_and_peaks_near_moderate_phi():
    etas = [combustion_efficiency(phi) for phi in [0.05, 0.5, 1.0, 2.0, 5.0]]
    assert all(0.0 <= e <= 1.0 for e in etas)
    # Very lean (near quenching) should be much worse than a healthy mixture.
    assert etas[0] < etas[2]
