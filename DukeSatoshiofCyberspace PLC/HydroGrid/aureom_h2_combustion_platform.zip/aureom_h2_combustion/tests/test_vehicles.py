import pytest

from aureom_h2_combustion.vehicles.car import Car
from aureom_h2_combustion.vehicles.train import LocomotiveUnit, TrainConsist
from aureom_h2_combustion.vehicles.truck import Truck


def test_car_accelerates_under_positive_net_torque():
    car = Car()
    for _ in range(50):
        car.step(engine_torque_nm=150.0, dt_s=0.1, gear_index=2)
    assert car.state.speed_ms > 0
    assert car.state.position_m > 0


def test_car_approaches_terminal_speed_where_drag_balances_drive_force():
    car = Car()
    for _ in range(6000):
        car.step(engine_torque_nm=120.0, dt_s=0.05, gear_index=4)
    # Near terminal velocity, net force (and hence acceleration) should
    # have decayed to a small fraction of its initial (standing-start) value.
    assert abs(car.state.acceleration_ms2) < 0.05


def test_truck_cargo_increases_effective_mass():
    empty = Truck(cargo_kg=0.0)
    loaded = Truck(cargo_kg=10_000.0)
    assert loaded.params.mass_kg > empty.params.mass_kg


def test_truck_set_cargo_updates_mass():
    truck = Truck(cargo_kg=0.0)
    base_mass = truck.params.mass_kg
    truck.set_cargo(5000.0)
    assert truck.params.mass_kg == pytest.approx(base_mass + 5000.0)


def test_train_consist_tractive_effort_moves_the_train():
    locos = [LocomotiveUnit("L1", rated_power_w=2.0e6), LocomotiveUnit("L2", rated_power_w=2.0e6)]
    train = TrainConsist(locos)
    for _ in range(100):
        train.step([20000.0, 20000.0], dt_s=0.2)
    assert train.speed_ms > 0


def test_train_resistance_grows_with_speed():
    locos = [LocomotiveUnit("L1", rated_power_w=2.0e6)]
    train = TrainConsist(locos)
    r_low = train.davis_resistance_n(1.0)
    r_high = train.davis_resistance_n(30.0)
    assert r_high > r_low
