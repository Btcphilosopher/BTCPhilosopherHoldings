import pytest

from aureom_h2_combustion.emissions.nox_model import nox_concentration_ppm, o2_dissociation_kp


def test_o2_dissociation_kp_increases_with_temperature():
    kps = [o2_dissociation_kp(t) for t in (1800, 2200, 2600, 3000)]
    assert all(kps[i] < kps[i + 1] for i in range(len(kps) - 1))


def test_o2_dissociation_kp_matches_reference_anchor():
    kp3000 = o2_dissociation_kp(3000.0)
    assert kp3000 == pytest.approx(1.3e-3, rel=1e-6)


def test_nox_increases_sharply_with_temperature():
    ppm_values = [
        nox_concentration_ppm(t, o2_mole_fraction=0.05, n2_mole_fraction=0.7, pressure_pa=20e5)
        for t in (2000, 2200, 2400, 2600, 2800)
    ]
    assert all(ppm_values[i] < ppm_values[i + 1] for i in range(len(ppm_values) - 1))


def test_nox_is_physically_bounded():
    """NO concentration should never exceed the total local gas concentration
    (i.e. mole fraction can't exceed ~1e6 ppm) even at high temperature."""
    ppm = nox_concentration_ppm(3200.0, o2_mole_fraction=0.1, n2_mole_fraction=0.75, pressure_pa=50e5)
    assert 0 <= ppm < 1.0e6


def test_nox_realistic_order_of_magnitude_for_lean_engine_conditions():
    """At typical lean-burn H2-ICE flame conditions (~2400 K, few tens of
    bar), NOx should land in the hundreds-to-low-thousands ppm range that
    is characteristic of real hydrogen engine emissions data, not the
    percent-level values an incorrectly calibrated kinetic model would
    produce."""
    ppm = nox_concentration_ppm(2400.0, o2_mole_fraction=0.05, n2_mole_fraction=0.7, pressure_pa=25e5)
    assert 10.0 < ppm < 5000.0
