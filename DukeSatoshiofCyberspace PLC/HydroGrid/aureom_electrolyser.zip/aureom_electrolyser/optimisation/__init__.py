"""Load scheduling and operating-point optimisation."""
