"""
Optimisation engine.

Three optimisation problems are implemented:

  1. ``find_max_efficiency_operating_point`` - scalar minimisation
     (scipy.optimize.minimize_scalar) of specific energy consumption
     (kWh/kg H2) over current density, for a given stack model and
     temperature. Because voltage rises monotonically with current density
     while Faradaic efficiency also varies, the true efficiency optimum is
     found numerically rather than assumed.

  2. ``optimise_load_schedule`` - a linear program (scipy.optimize.linprog)
     that schedules electrolyser power draw across a time-varying
     electricity price curve to minimise total electricity cost while
     meeting a required total hydrogen production target and respecting
     per-timestep power bounds and a ramp-rate constraint.

  3. ``minimise_cost_per_kg`` - given a stack model, finds the current
     density that minimises $/kg H2 for a given electricity price,
     balancing higher throughput (better CAPEX amortisation) against lower
     per-unit electrical efficiency at high current density.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
from scipy.optimize import linprog, minimize_scalar

from electrolysis.efficiency import specific_energy_kwh_per_kg


@dataclass
class OptimalOperatingPoint:
    current_density_A_cm2: float
    specific_energy_kwh_per_kg: float
    stack_power_kW: float
    hydrogen_kg_s: float


def find_max_efficiency_operating_point(
    stack_model, temperature_c: float, i_min: float = 0.05, i_max: Optional[float] = None
) -> OptimalOperatingPoint:
    i_max = i_max or stack_model.rated_current_density()

    def objective(i: float) -> float:
        state = stack_model.evaluate(i, temperature_c)
        return state.specific_energy_kwh_per_kg

    result = minimize_scalar(objective, bounds=(i_min, i_max), method="bounded")
    best_i = float(result.x)
    state = stack_model.evaluate(best_i, temperature_c)
    return OptimalOperatingPoint(
        current_density_A_cm2=best_i,
        specific_energy_kwh_per_kg=state.specific_energy_kwh_per_kg,
        stack_power_kW=state.stack_power_kW,
        hydrogen_kg_s=state.hydrogen_kg_s,
    )


def minimise_cost_per_kg(
    stack_model,
    temperature_c: float,
    electricity_price_usd_per_kwh: float,
    fixed_cost_usd_per_hour: float,
    i_min: float = 0.05,
    i_max: Optional[float] = None,
) -> OptimalOperatingPoint:
    """
    Minimise total $/kg H2 = (energy cost + amortised fixed cost) / kg H2,
    trading off electrical efficiency against fixed-cost amortisation
    (running harder produces more kg/h, diluting the fixed cost term even
    though electrical efficiency worsens at high current density).
    """
    i_max = i_max or stack_model.rated_current_density()

    def objective(i: float) -> float:
        state = stack_model.evaluate(i, temperature_c)
        if state.hydrogen_kg_s <= 1e-12:
            return 1e9
        h2_kg_per_hr = state.hydrogen_kg_s * 3600.0
        energy_cost_per_hr = state.stack_power_kW * electricity_price_usd_per_kwh
        total_cost_per_hr = energy_cost_per_hr + fixed_cost_usd_per_hour
        return total_cost_per_hr / h2_kg_per_hr

    result = minimize_scalar(objective, bounds=(i_min, i_max), method="bounded")
    best_i = float(result.x)
    state = stack_model.evaluate(best_i, temperature_c)
    return OptimalOperatingPoint(
        current_density_A_cm2=best_i,
        specific_energy_kwh_per_kg=state.specific_energy_kwh_per_kg,
        stack_power_kW=state.stack_power_kW,
        hydrogen_kg_s=state.hydrogen_kg_s,
    )


@dataclass
class LoadSchedule:
    power_kw_by_period: np.ndarray
    total_electricity_cost_usd: float
    total_energy_kwh: float
    feasible: bool


def optimise_load_schedule(
    price_usd_per_kwh: np.ndarray,
    period_hours: float,
    min_power_kw: float,
    max_power_kw: float,
    required_total_energy_kwh: float,
    max_ramp_kw_per_period: Optional[float] = None,
) -> LoadSchedule:
    """
    Linear program: minimise sum(price_t * power_t * period_hours) subject to
        sum(power_t * period_hours) >= required_total_energy_kwh
        min_power_kw <= power_t <= max_power_kw   (or 0, if turndown allows shutdown)
        |power_t - power_{t-1}| <= max_ramp_kw_per_period   (optional)

    This schedules electrolyser operation into the cheapest electricity
    periods first while still meeting the production target, which is the
    core "buy power when it's cheap" optimisation used for renewable /
    spot-price-driven hydrogen plants.
    """
    n = len(price_usd_per_kwh)
    c = price_usd_per_kwh * period_hours  # cost per unit power in each period

    # Total energy constraint: -sum(power_t * period_hours) <= -required_total_energy_kwh
    A_ub = [[-period_hours] * n]
    b_ub = [-required_total_energy_kwh]

    if max_ramp_kw_per_period is not None and n > 1:
        for t in range(n - 1):
            row_up = [0.0] * n
            row_up[t] = -1.0
            row_up[t + 1] = 1.0
            A_ub.append(row_up)
            b_ub.append(max_ramp_kw_per_period)

            row_down = [0.0] * n
            row_down[t] = 1.0
            row_down[t + 1] = -1.0
            A_ub.append(row_down)
            b_ub.append(max_ramp_kw_per_period)

    bounds = [(min_power_kw, max_power_kw) for _ in range(n)]

    result = linprog(c=c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")

    if not result.success:
        return LoadSchedule(
            power_kw_by_period=np.zeros(n),
            total_electricity_cost_usd=float("nan"),
            total_energy_kwh=0.0,
            feasible=False,
        )

    power_schedule = result.x
    total_cost = float(np.dot(c, power_schedule))
    total_energy = float(np.sum(power_schedule) * period_hours)

    return LoadSchedule(
        power_kw_by_period=power_schedule,
        total_electricity_cost_usd=total_cost,
        total_energy_kwh=total_energy,
        feasible=True,
    )
