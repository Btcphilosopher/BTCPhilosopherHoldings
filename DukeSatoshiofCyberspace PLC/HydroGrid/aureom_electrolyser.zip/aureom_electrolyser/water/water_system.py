"""
Feedwater balance and conditioning system.

Combines the stoichiometric water demand implied by the electrochemical
mass balance (from ``BaseStackModel.evaluate``) with recirculation losses
and the purity model's real-time water-quality state.
"""

from __future__ import annotations

from dataclasses import dataclass

from water.purity_model import PurityModel, WaterQualityState


@dataclass
class WaterSystemState:
    net_consumption_kg_s: float
    gross_intake_kg_s: float
    quality: WaterQualityState


class WaterSystem:
    def __init__(self, water_config):
        self.cfg = water_config
        self.purity_model = PurityModel(water_config)

    def step(self, stoichiometric_water_kg_s: float, dt_s: float, is_running: bool) -> WaterSystemState:
        quality = self.purity_model.step(dt_s, is_running)

        # Net consumption = stoichiometric demand grossed up for filtration
        # rejection losses (RO reject stream, etc.) captured by filtration_efficiency.
        gross_intake = stoichiometric_water_kg_s / max(self.cfg.filtration_efficiency, 1e-6)

        return WaterSystemState(
            net_consumption_kg_s=stoichiometric_water_kg_s,
            gross_intake_kg_s=gross_intake,
            quality=quality,
        )
