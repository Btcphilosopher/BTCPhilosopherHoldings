"""
Feedwater purity model.

PEM electrolysers in particular require ultra-pure water (conductivity
< 1 uS/cm) because ionic contaminants poison the membrane and catalyst
layers. This module tracks:

  * the achieved feed conductivity after filtration/conditioning
  * the resulting membrane/catalyst degradation multiplier
  * long-term scaling/fouling accumulation, which raises differential
    pressure and reduces heat-exchanger + flow-field performance
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class WaterQualityState:
    feed_conductivity_us_cm: float
    within_spec: bool
    degradation_multiplier: float
    fouling_fraction: float
    efficiency_penalty: float


class PurityModel:
    """
    Converts raw source-water conductivity through the filtration train and
    tracks cumulative fouling as a function of operating hours.
    """

    # A typical raw industrial/municipal feed before treatment (uS/cm).
    RAW_SOURCE_CONDUCTIVITY_US_CM = 400.0

    def __init__(self, water_config):
        self.cfg = water_config
        self.cumulative_operating_hours = 0.0
        self.fouling_fraction = 0.0

    def step(self, dt_s: float, is_running: bool) -> WaterQualityState:
        treated_conductivity = self.RAW_SOURCE_CONDUCTIVITY_US_CM * (1.0 - self.cfg.filtration_efficiency)
        within_spec = treated_conductivity <= self.cfg.max_conductivity_us_cm

        if is_running:
            self.cumulative_operating_hours += dt_s / 3600.0

            # Fouling accumulates monotonically with operating hours (it is a
            # flow-driven scaling process, so it does not progress while the
            # plant is offline and no water is circulating); higher
            # conductivity (worse purity) accelerates scale formation.
            purity_penalty_factor = max(1.0, treated_conductivity / self.cfg.max_conductivity_us_cm)
            self.fouling_fraction = min(
                0.50,
                self.fouling_fraction
                + self.cfg.fouling_rate_per_khr * purity_penalty_factor * (dt_s / 3600.0) / 1000.0,
            )

        # Ionic contamination directly accelerates membrane/catalyst wear.
        degradation_multiplier = 1.0 if within_spec else 1.0 + 4.0 * (
            (treated_conductivity - self.cfg.max_conductivity_us_cm) / self.cfg.max_conductivity_us_cm
        )

        efficiency_penalty = self.fouling_fraction  # fractional efficiency loss from scale/fouling

        return WaterQualityState(
            feed_conductivity_us_cm=treated_conductivity,
            within_spec=within_spec,
            degradation_multiplier=degradation_multiplier,
            fouling_fraction=self.fouling_fraction,
            efficiency_penalty=efficiency_penalty,
        )
