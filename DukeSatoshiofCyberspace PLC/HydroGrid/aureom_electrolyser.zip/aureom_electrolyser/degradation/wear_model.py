"""
Stack degradation and lifetime model.

Two coupled mechanisms are tracked, consistent with published PEM/Alkaline
durability studies:

  1. Voltage (membrane/ohmic) degradation: a steady per-hour voltage rise
     (uV/h), accelerated by load cycling and by out-of-spec feedwater.
  2. Catalyst activity loss: the exchange current density used by the
     electrochemical model decays over operating hours, which independently
     raises the activation overpotential (captured automatically because
     the stack model reads ``exchange_current_density_A_cm2`` live).

End-of-life is declared once the cumulative voltage rise exceeds the
configured percentage above beginning-of-life voltage, at the stack's
rated operating point. From the degradation rate this directly yields a
projected stack lifetime in hours.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class DegradationState:
    operating_hours: float
    voltage_offset_V: float
    voltage_rise_pct: float
    exchange_current_density_A_cm2: float
    catalyst_activity_fraction: float
    is_end_of_life: bool
    projected_lifetime_hours: float


class WearModel:
    def __init__(self, degradation_config, stack_model, bol_voltage_at_rated_V: float):
        self.cfg = degradation_config
        self.stack_model = stack_model
        self.bol_voltage_at_rated_V = bol_voltage_at_rated_V
        self.bol_i0 = stack_model.exchange_current_density_A_cm2

        self.operating_hours = 0.0
        self.cumulative_load_change_fraction = 0.0
        self._previous_load_fraction: float = 0.0

    def step(self, dt_s: float, is_running: bool, load_fraction: float, water_degradation_multiplier: float) -> DegradationState:
        dt_hr = dt_s / 3600.0

        if is_running:
            self.operating_hours += dt_hr

            load_change = abs(load_fraction - self._previous_load_fraction)
            cyclic_factor = 1.0 + (self.cfg.cyclic_degradation_multiplier - 1.0) * min(1.0, load_change * 5.0)

            # Voltage degradation: steady-state rate x cyclic acceleration x water-quality penalty.
            d_voltage_uv = (
                self.cfg.voltage_degradation_uv_per_hour * cyclic_factor * water_degradation_multiplier * dt_hr
            )
            self.stack_model.degradation_voltage_offset_V += d_voltage_uv * 1.0e-6

            # Catalyst activity decay (fractional loss per 1000 operating hours).
            activity_loss = self.cfg.catalyst_activity_loss_per_khr * (dt_hr / 1000.0) * water_degradation_multiplier
            new_i0 = self.stack_model.exchange_current_density_A_cm2 * (1.0 - activity_loss)
            self.stack_model.exchange_current_density_A_cm2 = max(new_i0, self.bol_i0 * 0.05)

        self._previous_load_fraction = load_fraction

        voltage_offset = self.stack_model.degradation_voltage_offset_V
        voltage_rise_pct = 100.0 * voltage_offset * self.stack_model.num_cells / max(self.bol_voltage_at_rated_V, 1e-9)
        is_eol = voltage_rise_pct >= self.cfg.end_of_life_voltage_increase_pct

        # Linear projection of remaining life from the current degradation rate.
        if self.operating_hours > 0 and voltage_offset > 0:
            rate_v_per_hr = voltage_offset / self.operating_hours
            eol_offset_v = (self.cfg.end_of_life_voltage_increase_pct / 100.0) * self.bol_voltage_at_rated_V / self.stack_model.num_cells
            projected_lifetime_hours = eol_offset_v / rate_v_per_hr if rate_v_per_hr > 0 else float("inf")
        else:
            projected_lifetime_hours = float("inf")

        activity_fraction = self.stack_model.exchange_current_density_A_cm2 / self.bol_i0

        return DegradationState(
            operating_hours=self.operating_hours,
            voltage_offset_V=voltage_offset,
            voltage_rise_pct=voltage_rise_pct,
            exchange_current_density_A_cm2=self.stack_model.exchange_current_density_A_cm2,
            catalyst_activity_fraction=activity_fraction,
            is_end_of_life=is_eol,
            projected_lifetime_hours=projected_lifetime_hours,
        )
