"""Long-term wear, degradation and lifetime modelling."""
