"""
Alkaline (liquid KOH electrolyte) electrolyser stack model.

Differences from PEM that are physically modelled here:

  * Non-noble Ni-based electrodes -> much lower exchange current densities
    (both electrodes are more kinetically sluggish than Pt/IrO2 in acid).
  * Ionic conduction is through a bulk KOH electrolyte + porous separator
    (e.g. Zirfon) rather than a solid polymer membrane. Electrolyte
    conductivity follows the Gilliam et al. (2007) correlation for aqueous
    KOH as a function of molality and temperature.
  * Gas bubbles nucleating between the electrodes reduce the effective
    ionic conductivity (voidage effect, modelled with a Bruggeman-type
    correction that grows with current density).
  * Lower practical current density ceiling (bubble-limited mass transport)
    than PEM, and higher sensitivity to turndown (gas crossover through the
    diaphragm at low current raises the purity/safety-critical H2-in-O2
    fraction) - reflected in the Faradaic efficiency model.
"""

from __future__ import annotations

import math

from electrolysis.base_model import BaseStackModel
from utils.constants import DE0_DT, GAS_CONSTANT, STANDARD_REVERSIBLE_VOLTAGE


class AlkalineStackModel(BaseStackModel):
    technology = "ALKALINE"
    max_current_density_A_cm2 = 2.5

    # Apparent (roughness-included) exchange current densities for
    # Raney-Ni-type electrodes, calibrated so the resulting polarization
    # curve matches published industrial alkaline stack voltages
    # (~1.7-1.8 V at 0.1 A/cm2, ~1.9-2.1 V at 0.4-0.5 A/cm2 rated).
    I0_ANODE_A_CM2 = 1.0e-5      # Ni-based OER catalyst, alkaline media
    I0_CATHODE_A_CM2 = 1.0e-4    # Ni-based HER catalyst, alkaline media
    ALPHA_ANODE = 1.0
    ALPHA_CATHODE = 1.0
    LIMITING_CURRENT_DENSITY_A_CM2 = 2.2
    ELECTRODE_GAP_CM = 0.20      # zero-gap to finite-gap conventional design
    SEPARATOR_ASR_OHM_CM2 = 0.22  # Zirfon-type diaphragm baseline
    KOH_MOLALITY_MOL_PER_KG = 8.0  # ~30-32 wt% KOH, standard industrial concentration
    CROSSOVER_BASE_CURRENT_DENSITY_A_CM2 = 0.006  # higher diaphragm crossover than PEM

    def __init__(self, stack_config, thermal_config):
        super().__init__(stack_config, thermal_config)
        self.exchange_current_density_A_cm2 = self.I0_CATHODE_A_CM2

    # ------------------------------------------------------------------
    def reversible_voltage(self, temperature_c: float) -> float:
        return STANDARD_REVERSIBLE_VOLTAGE + DE0_DT * (temperature_c - 25.0)

    def _electrolyte_conductivity_S_cm(self, temperature_c: float) -> float:
        """Gilliam, R.J. et al. (2007) correlation for aqueous KOH conductivity."""
        m = self.KOH_MOLALITY_MOL_PER_KG
        t_k = temperature_c + 273.15
        sigma = (
            -2.041 * m
            - 0.0028 * m ** 2
            + 0.005332 * m * t_k
            + 207.2 * m / t_k
            + 0.001043 * m ** 3
            - 0.0000003 * m ** 2 * t_k ** 2
        )
        return max(sigma, 0.05)

    def _bubble_voidage_correction(self, current_density_A_cm2: float) -> float:
        """Bruggeman-type correction: effective conductivity falls as bubble voidage grows with i."""
        void_fraction = min(0.35, 0.12 * math.sqrt(max(current_density_A_cm2, 0.0)))
        return (1.0 - void_fraction) ** 1.5

    def _area_specific_resistance(self, temperature_c: float, current_density_A_cm2: float) -> float:
        sigma = self._electrolyte_conductivity_S_cm(temperature_c)
        bruggeman = self._bubble_voidage_correction(current_density_A_cm2)
        electrolyte_asr = self.ELECTRODE_GAP_CM / (sigma * bruggeman)
        separator_asr = max(self.SEPARATOR_ASR_OHM_CM2, self.area_specific_resistance_ohm_cm2)
        return electrolyte_asr + separator_asr

    def _activation_overpotential(
        self, current_density_A_cm2: float, temperature_c: float, i0: float, alpha: float
    ) -> float:
        if current_density_A_cm2 <= 0.0:
            return 0.0
        t_k = temperature_c + 273.15
        term = current_density_A_cm2 / (2.0 * i0)
        return (GAS_CONSTANT * t_k) / (alpha * 96485.33212) * math.asinh(term)

    def _concentration_overpotential(self, current_density_A_cm2: float, temperature_c: float) -> float:
        i_lim = self.LIMITING_CURRENT_DENSITY_A_CM2
        if current_density_A_cm2 <= 0.0:
            return 0.0
        ratio = min(current_density_A_cm2 / i_lim, 0.999)
        t_k = temperature_c + 273.15
        return (GAS_CONSTANT * t_k) / (2.0 * 96485.33212) * math.log(1.0 / (1.0 - ratio))

    def cell_voltage(self, current_density_A_cm2: float, temperature_c: float) -> float:
        if current_density_A_cm2 <= 0.0:
            return self.reversible_voltage(temperature_c)

        e_rev = self.reversible_voltage(temperature_c)
        degradation_factor = self.exchange_current_density_A_cm2 / self.I0_CATHODE_A_CM2
        i0_anode = self.I0_ANODE_A_CM2 * degradation_factor
        i0_cathode = self.exchange_current_density_A_cm2

        eta_act_a = self._activation_overpotential(current_density_A_cm2, temperature_c, i0_anode, self.ALPHA_ANODE)
        eta_act_c = self._activation_overpotential(current_density_A_cm2, temperature_c, i0_cathode, self.ALPHA_CATHODE)
        eta_ohm = current_density_A_cm2 * self._area_specific_resistance(temperature_c, current_density_A_cm2)
        eta_conc = self._concentration_overpotential(current_density_A_cm2, temperature_c)

        return e_rev + eta_act_a + eta_act_c + eta_ohm + eta_conc

    def faradaic_efficiency(self, current_density_A_cm2: float, temperature_c: float) -> float:
        if current_density_A_cm2 <= 0.0:
            return 0.0
        loss_fraction = self.CROSSOVER_BASE_CURRENT_DENSITY_A_CM2 / current_density_A_cm2
        return max(0.90, 1.0 - loss_fraction)
