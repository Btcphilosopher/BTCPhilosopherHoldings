"""
Shared efficiency metrics used across the platform.

These are pure functions (no state) so they can be unit-tested in isolation
and reused by the electrical, thermal and financial subsystems without
circular imports back into the stack models.
"""

from __future__ import annotations

from utils.constants import (
    HHV_H2_KWH_PER_KG,
    LHV_H2_KWH_PER_KG,
    THERMONEUTRAL_VOLTAGE,
)


def specific_energy_kwh_per_kg(power_kW: float, hydrogen_kg_s: float) -> float:
    """Electrical energy consumed per kg of hydrogen produced."""
    if hydrogen_kg_s <= 0.0:
        return float("inf")
    return power_kW / (hydrogen_kg_s * 3600.0)


def system_efficiency_hhv(specific_energy: float) -> float:
    """System efficiency referenced to the higher heating value of hydrogen."""
    if specific_energy <= 0.0 or specific_energy == float("inf"):
        return 0.0
    return HHV_H2_KWH_PER_KG / specific_energy


def system_efficiency_lhv(specific_energy: float) -> float:
    """System efficiency referenced to the lower heating value of hydrogen."""
    if specific_energy <= 0.0 or specific_energy == float("inf"):
        return 0.0
    return LHV_H2_KWH_PER_KG / specific_energy


def voltage_efficiency(cell_voltage_V: float) -> float:
    """Voltage efficiency = thermoneutral voltage / actual cell voltage."""
    if cell_voltage_V <= 0.0:
        return 0.0
    return THERMONEUTRAL_VOLTAGE / cell_voltage_V


def part_load_efficiency_multiplier(load_fraction: float, technology: str = "PEM") -> float:
    """
    Empirical part-load efficiency correction.

    Electrolysers are generally *more* voltage-efficient at low current
    density (lower ohmic/activation losses per unit current) but suffer
    parasitic-load and Faradaic-efficiency penalties (gas crossover becomes
    proportionally larger) at very low loads. This returns a multiplier
    applied to the nominal Faradaic efficiency.
    """
    load_fraction = max(0.0, min(1.0, load_fraction))
    if technology.upper() == "PEM":
        # Crossover losses dominate below ~15% load.
        if load_fraction < 0.15:
            return 0.90 + 0.10 * (load_fraction / 0.15) * 0.5
        return min(1.0, 0.97 + 0.03 * load_fraction)
    if technology.upper() == "ALKALINE":
        # Alkaline is more sensitive to turndown (gas crossover through diaphragm).
        if load_fraction < 0.25:
            return 0.80 + 0.20 * (load_fraction / 0.25)
        return min(1.0, 0.96 + 0.04 * load_fraction)
    # SOEC: thermal management dominates; assume mild penalty at low load.
    if load_fraction < 0.20:
        return 0.85 + 0.15 * (load_fraction / 0.20)
    return min(1.0, 0.97 + 0.03 * load_fraction)
