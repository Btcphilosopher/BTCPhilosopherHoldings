"""
Solid Oxide Electrolysis Cell (SOEC) stack model.

SOEC operates on *steam* (not liquid water) at 700-900 C using a dense
ceramic (yttria-stabilised zirconia, YSZ) oxygen-ion-conducting electrolyte.
This changes the underlying thermodynamics and transport physics
substantially relative to PEM/Alkaline:

  * The reversible voltage for steam electrolysis is *lower* than for liquid
    water and falls further with increasing temperature (ASR of Gibbs free
    energy for H2O(g) -> H2 + 1/2 O2 decreases with T), because a large part
    of the energy demand is supplied thermally rather than electrically.
  * Electrode kinetics are fast at these temperatures (thermally activated),
    so activation overpotential is small.
  * Ohmic loss is dominated by ionic conduction through the solid YSZ
    electrolyte, which follows an Arrhenius-type temperature dependence.
  * Because the electrolyte is a dense ceramic, gas crossover is
    essentially negligible -> very high Faradaic efficiency.
"""

from __future__ import annotations

import math

from electrolysis.base_model import BaseStackModel
from utils.constants import GAS_CONSTANT

# Reference points for the linearised steam-electrolysis reversible voltage,
# consistent with published Nernst curves for H2O(g) -> H2 + 1/2 O2.
_T_REF_LOW_K = 1000.0    # 726.85 C
_E_REF_LOW_V = 0.990
_T_REF_HIGH_K = 1273.0   # 999.85 C
_E_REF_HIGH_V = 0.910
_DE_DT_STEAM = (_E_REF_HIGH_V - _E_REF_LOW_V) / (_T_REF_HIGH_K - _T_REF_LOW_K)  # V/K, negative

_STEAM_THERMONEUTRAL_VOLTAGE_V = 1.287  # delta H for the electrolysis step fed with steam


class SOECStackModel(BaseStackModel):
    technology = "SOEC"
    max_current_density_A_cm2 = 3.0

    I0_REF_A_CM2 = 0.30          # fast kinetics at high T, referenced at 1023 K
    I0_ACTIVATION_ENERGY_J_MOL = 110000.0
    ALPHA = 0.5
    LIMITING_CURRENT_DENSITY_A_CM2 = 2.8
    ELECTROLYTE_CONDUCTIVITY_PREFACTOR = 3.6e5   # S*K/cm
    ELECTROLYTE_ACTIVATION_ENERGY_J_MOL = 80000.0
    ELECTRODE_ASR_OHM_CM2 = 0.15  # lumped electrode + contact ASR at reference T
    CROSSOVER_CURRENT_DENSITY_A_CM2 = 0.0002   # dense ceramic: near-zero crossover

    def __init__(self, stack_config, thermal_config):
        super().__init__(stack_config, thermal_config)
        self.exchange_current_density_A_cm2 = self.I0_REF_A_CM2
        # For SOEC, "membrane_thickness" config field represents the electrolyte thickness.
        self.electrolyte_thickness_cm = stack_config.membrane_thickness_um * 1.0e-4

    # ------------------------------------------------------------------
    def reversible_voltage(self, temperature_c: float) -> float:
        t_k = temperature_c + 273.15
        return _E_REF_LOW_V + _DE_DT_STEAM * (t_k - _T_REF_LOW_K)

    def _thermoneutral_voltage(self) -> float:
        return _STEAM_THERMONEUTRAL_VOLTAGE_V

    def _exchange_current_density(self, temperature_c: float) -> float:
        t_k = temperature_c + 273.15
        ref_t_k = 1023.15
        arrhenius = math.exp(
            -self.I0_ACTIVATION_ENERGY_J_MOL / GAS_CONSTANT * (1.0 / t_k - 1.0 / ref_t_k)
        )
        # exchange_current_density_A_cm2 tracks BOL/degraded reference i0 at ref_t_k
        i0_ref_effective = self.exchange_current_density_A_cm2
        return i0_ref_effective * arrhenius

    def _activation_overpotential(self, current_density_A_cm2: float, temperature_c: float) -> float:
        if current_density_A_cm2 <= 0.0:
            return 0.0
        i0 = self._exchange_current_density(temperature_c)
        t_k = temperature_c + 273.15
        term = current_density_A_cm2 / (2.0 * i0)
        return (GAS_CONSTANT * t_k) / (self.ALPHA * 96485.33212) * math.asinh(term)

    def _electrolyte_conductivity_S_cm(self, temperature_c: float) -> float:
        t_k = temperature_c + 273.15
        sigma = (self.ELECTROLYTE_CONDUCTIVITY_PREFACTOR / t_k) * math.exp(
            -self.ELECTROLYTE_ACTIVATION_ENERGY_J_MOL / (GAS_CONSTANT * t_k)
        )
        return max(sigma, 1.0e-4)

    def _area_specific_resistance(self, temperature_c: float) -> float:
        sigma = self._electrolyte_conductivity_S_cm(temperature_c)
        electrolyte_asr = self.electrolyte_thickness_cm / sigma
        electrode_asr = max(self.ELECTRODE_ASR_OHM_CM2, self.area_specific_resistance_ohm_cm2)
        return electrolyte_asr + electrode_asr

    def _concentration_overpotential(self, current_density_A_cm2: float, temperature_c: float) -> float:
        i_lim = self.LIMITING_CURRENT_DENSITY_A_CM2
        if current_density_A_cm2 <= 0.0:
            return 0.0
        ratio = min(current_density_A_cm2 / i_lim, 0.999)
        t_k = temperature_c + 273.15
        return (GAS_CONSTANT * t_k) / (2.0 * 96485.33212) * math.log(1.0 / (1.0 - ratio))

    def cell_voltage(self, current_density_A_cm2: float, temperature_c: float) -> float:
        if current_density_A_cm2 <= 0.0:
            return self.reversible_voltage(temperature_c)

        e_rev = self.reversible_voltage(temperature_c)
        eta_act = self._activation_overpotential(current_density_A_cm2, temperature_c)
        eta_ohm = current_density_A_cm2 * self._area_specific_resistance(temperature_c)
        eta_conc = self._concentration_overpotential(current_density_A_cm2, temperature_c)

        return e_rev + eta_act + eta_ohm + eta_conc

    def faradaic_efficiency(self, current_density_A_cm2: float, temperature_c: float) -> float:
        if current_density_A_cm2 <= 0.0:
            return 0.0
        loss_fraction = self.CROSSOVER_CURRENT_DENSITY_A_CM2 / current_density_A_cm2
        return max(0.97, 1.0 - loss_fraction)

    def heat_demand_kW(self, current_density_A_cm2: float, temperature_c: float) -> float:
        """
        Positive when the cell operates *below* the thermoneutral voltage and
        therefore requires external process heat (endothermic regime, typical
        of efficient SOEC operation); negative means the stack is exothermic
        (Joule heating exceeds the reaction's heat demand) and must be cooled.
        """
        if current_density_A_cm2 <= 0.0:
            return 0.0
        cell_v = self.cell_voltage(current_density_A_cm2, temperature_c) + self.degradation_voltage_offset_V
        current_A = current_density_A_cm2 * self.active_area_cm2
        delta_v = self._thermoneutral_voltage() - cell_v
        return self.num_cells * self.num_stacks * delta_v * current_A / 1000.0
