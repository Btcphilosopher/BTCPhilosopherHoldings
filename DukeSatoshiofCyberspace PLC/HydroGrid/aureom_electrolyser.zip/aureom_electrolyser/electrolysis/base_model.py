"""
Abstract base class for electrochemical stack models.

Every concrete technology (PEM, Alkaline, SOEC) must provide a polarization
curve ``cell_voltage(current_density, temperature_c)`` and an
``exchange_current_density`` that degradation can erode over time. The base
class then supplies shared, technology-independent machinery:

    * solving current density from a requested DC power (root finding on the
      real polarization curve, not a lookup table)
    * Faraday's law based hydrogen / oxygen / water mass balance
    * energy accounting (kWh/kg H2, efficiency vs HHV/LHV)

This keeps every subsystem physically consistent: the electrical, thermal
and financial subsystems only ever see current density and cell voltage
that came out of a real electrochemical solve.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional

from scipy.optimize import brentq

from utils.constants import (
    ELECTRONS_PER_H2,
    FARADAY_CONSTANT,
    HHV_H2_KWH_PER_KG,
    LHV_H2_KWH_PER_KG,
    MOLAR_MASS_H2,
    MOLAR_MASS_O2,
    OXYGEN_PER_KG_H2,
    WATER_PER_KG_H2,
)


@dataclass
class ElectrochemicalState:
    """Snapshot of the stack's electrochemical operating point at a timestep."""

    current_density_A_cm2: float
    current_A: float
    cell_voltage_V: float
    stack_voltage_V: float
    stack_power_kW: float
    hydrogen_kg_s: float
    oxygen_kg_s: float
    water_consumed_kg_s: float
    faradaic_efficiency: float
    voltage_efficiency: float
    system_efficiency_hhv: float
    specific_energy_kwh_per_kg: float


class BaseStackModel(ABC):
    """Shared electrochemical machinery for all electrolyser technologies."""

    technology: str = "BASE"
    #: absolute current-density ceiling used as the upper bracket for root finding
    max_current_density_A_cm2: float = 10.0

    def __init__(self, stack_config, thermal_config):
        self.stack_config = stack_config
        self.thermal_config = thermal_config
        self.num_cells = stack_config.num_cells
        self.num_stacks = stack_config.num_stacks
        self.active_area_cm2 = stack_config.active_area_cm2

        # Mutable, degradation-erodable electrochemical parameters.
        # Concrete models seed real BOL (beginning-of-life) values.
        self.exchange_current_density_A_cm2: float = 1.0e-3
        self.area_specific_resistance_ohm_cm2: float = 0.15
        # Extra voltage added on top of the polarization curve by degradation (V/cell)
        self.degradation_voltage_offset_V: float = 0.0

    # ------------------------------------------------------------------
    # Technology-specific physics — implemented by subclasses
    # ------------------------------------------------------------------
    @abstractmethod
    def reversible_voltage(self, temperature_c: float) -> float:
        """Nernstian reversible (open-circuit) cell voltage at given temperature."""

    @abstractmethod
    def cell_voltage(self, current_density_A_cm2: float, temperature_c: float) -> float:
        """Full polarization curve: reversible + activation + ohmic + concentration."""

    @abstractmethod
    def faradaic_efficiency(self, current_density_A_cm2: float, temperature_c: float) -> float:
        """Current (Faradaic) efficiency, accounting for gas crossover / parasitic currents."""

    # ------------------------------------------------------------------
    # Shared machinery
    # ------------------------------------------------------------------
    def stack_voltage(self, current_density_A_cm2: float, temperature_c: float) -> float:
        return self.num_cells * (
            self.cell_voltage(current_density_A_cm2, temperature_c)
            + self.degradation_voltage_offset_V
        )

    def stack_power_kW(self, current_density_A_cm2: float, temperature_c: float) -> float:
        current_A = current_density_A_cm2 * self.active_area_cm2
        voltage = self.stack_voltage(current_density_A_cm2, temperature_c)
        return self.num_stacks * voltage * current_A / 1000.0

    def solve_current_density_for_power(
        self, power_kW: float, temperature_c: float, previous_guess: Optional[float] = None
    ) -> float:
        """
        Invert the polarization curve: given a requested DC power (kW) delivered
        to the *entire* stack array, solve for the operating current density
        (A/cm^2) using bisection on the monotonically increasing P(i) curve.
        """
        if power_kW <= 0.0:
            return 0.0

        def residual(i: float) -> float:
            return self.stack_power_kW(i, temperature_c) - power_kW

        lo = 1.0e-6
        hi = self.max_current_density_A_cm2

        # Expand upper bracket if a very large power is requested (large plant).
        while residual(hi) < 0.0 and hi < 1.0e4:
            hi *= 2.0

        if residual(lo) > 0.0:
            # Requested power below the minimum resolvable point -> near-zero current.
            return 0.0

        try:
            return brentq(residual, lo, hi, xtol=1e-8, maxiter=200)
        except ValueError:
            return 0.0

    def evaluate(
        self, current_density_A_cm2: float, temperature_c: float
    ) -> ElectrochemicalState:
        """Compute the full electrochemical + mass-balance state at a given operating point."""
        current_A_per_cell = current_density_A_cm2 * self.active_area_cm2
        total_current_A = current_A_per_cell * self.num_stacks

        cell_v = self.cell_voltage(current_density_A_cm2, temperature_c) + self.degradation_voltage_offset_V
        stack_v = self.num_cells * cell_v
        power_kW = stack_v * current_A_per_cell * self.num_stacks / 1000.0

        f_eff = self.faradaic_efficiency(current_density_A_cm2, temperature_c)

        # Faraday's law: mol H2 / s per cell = F_eff * I / (n * F)
        mol_h2_per_s_per_cell = f_eff * current_A_per_cell / (ELECTRONS_PER_H2 * FARADAY_CONSTANT)
        mol_h2_per_s_total = mol_h2_per_s_per_cell * self.num_cells * self.num_stacks

        h2_kg_s = mol_h2_per_s_total * MOLAR_MASS_H2
        o2_kg_s = mol_h2_per_s_total * MOLAR_MASS_O2 / 2.0  # 1 O2 per 2 H2
        water_kg_s = h2_kg_s * WATER_PER_KG_H2

        specific_energy = (power_kW / (h2_kg_s * 3600.0)) if h2_kg_s > 1e-12 else float("inf")
        voltage_eff = self._thermoneutral_voltage() / cell_v if cell_v > 0 else 0.0
        system_eff_hhv = HHV_H2_KWH_PER_KG / specific_energy if specific_energy > 0 else 0.0

        return ElectrochemicalState(
            current_density_A_cm2=current_density_A_cm2,
            current_A=total_current_A,
            cell_voltage_V=cell_v,
            stack_voltage_V=stack_v,
            stack_power_kW=power_kW,
            hydrogen_kg_s=h2_kg_s,
            oxygen_kg_s=o2_kg_s,
            water_consumed_kg_s=water_kg_s,
            faradaic_efficiency=f_eff,
            voltage_efficiency=max(0.0, min(1.0, voltage_eff)),
            system_efficiency_hhv=max(0.0, min(1.0, system_eff_hhv)),
            specific_energy_kwh_per_kg=specific_energy,
        )

    def _thermoneutral_voltage(self) -> float:
        from utils.constants import THERMONEUTRAL_VOLTAGE
        return THERMONEUTRAL_VOLTAGE

    def rated_current_density(self) -> float:
        return self.stack_config.rated_current_density_A_cm2
