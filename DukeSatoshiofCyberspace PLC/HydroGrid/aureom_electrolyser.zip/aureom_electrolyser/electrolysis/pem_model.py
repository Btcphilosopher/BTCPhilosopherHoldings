"""
PEM (Proton Exchange Membrane) electrolyser stack model.

Physics implemented (per cell):

    V_cell = E_rev(T) + eta_act,anode + eta_act,cathode + eta_ohm + eta_conc

  * E_rev(T)      : Nernst reversible voltage with linear temperature coefficient
  * eta_act       : Butler-Volmer (hyperbolic-arcsine) activation overpotential,
                     separate anode (OER, sluggish, low i0) and cathode (HER, fast, high i0)
  * eta_ohm       : membrane ionic resistance via the Springer conductivity model
                     for hydrated Nafion-type membranes, plus fixed contact/BPP resistance
  * eta_conc      : logarithmic mass-transport overpotential approaching a
                     technology-realistic limiting current density

This is the primary/default technology for AUREOM-ELECTROLYSER CORE.
"""

from __future__ import annotations

import math

from electrolysis.base_model import BaseStackModel
from utils.constants import (
    DE0_DT,
    GAS_CONSTANT,
    STANDARD_REVERSIBLE_VOLTAGE,
)


class PEMStackModel(BaseStackModel):
    technology = "PEM"
    max_current_density_A_cm2 = 6.0

    # Beginning-of-life kinetic parameters for Pt/C cathode + IrO2 anode PEM
    # cells. Apparent (roughness-factor-included) exchange current densities
    # and transfer coefficients are calibrated so the resulting polarization
    # curve reproduces published PEM stack voltages (~1.6 V at 0.1 A/cm2,
    # ~1.9-2.0 V at 2 A/cm2) rather than using bare, planar-electrode
    # literature values, which would overstate activation losses by 1-2 V.
    I0_ANODE_A_CM2 = 1.0e-9      # oxygen evolution reaction, sluggish
    I0_CATHODE_A_CM2 = 1.0e-3    # hydrogen evolution reaction, fast
    ALPHA_ANODE = 2.0
    ALPHA_CATHODE = 1.0
    LIMITING_CURRENT_DENSITY_A_CM2 = 5.5
    CONTACT_RESISTANCE_OHM_CM2 = 0.02
    CROSSOVER_CURRENT_DENSITY_A_CM2 = 0.0025
    MEMBRANE_WATER_CONTENT_LAMBDA = 14.0   # fully hydrated Nafion

    def __init__(self, stack_config, thermal_config):
        super().__init__(stack_config, thermal_config)
        self.exchange_current_density_A_cm2 = self.I0_CATHODE_A_CM2  # tracked for degradation
        self.membrane_thickness_cm = stack_config.membrane_thickness_um * 1.0e-4

    # ------------------------------------------------------------------
    def reversible_voltage(self, temperature_c: float) -> float:
        return STANDARD_REVERSIBLE_VOLTAGE + DE0_DT * (temperature_c - 25.0)

    def _membrane_conductivity_S_cm(self, temperature_c: float) -> float:
        """Springer et al. (1991) Nafion conductivity model."""
        t_k = temperature_c + 273.15
        lam = self.MEMBRANE_WATER_CONTENT_LAMBDA
        sigma_303 = 0.005139 * lam - 0.00326
        sigma = sigma_303 * math.exp(1268.0 * (1.0 / 303.0 - 1.0 / t_k))
        return max(sigma, 1.0e-4)

    def _area_specific_resistance(self, temperature_c: float) -> float:
        sigma = self._membrane_conductivity_S_cm(temperature_c)
        membrane_asr = self.membrane_thickness_cm / sigma
        # Degradation may have inflated a stored ASR value (see wear_model);
        # the larger of the two physical estimates is used.
        return max(membrane_asr, self.area_specific_resistance_ohm_cm2) + self.CONTACT_RESISTANCE_OHM_CM2

    def _activation_overpotential(
        self, current_density_A_cm2: float, temperature_c: float, i0: float, alpha: float
    ) -> float:
        if current_density_A_cm2 <= 0.0:
            return 0.0
        t_k = temperature_c + 273.15
        term = current_density_A_cm2 / (2.0 * i0)
        return (GAS_CONSTANT * t_k) / (alpha * 96485.33212) * math.asinh(term)

    def _concentration_overpotential(self, current_density_A_cm2: float, temperature_c: float) -> float:
        i_lim = self.LIMITING_CURRENT_DENSITY_A_CM2
        if current_density_A_cm2 <= 0.0:
            return 0.0
        ratio = min(current_density_A_cm2 / i_lim, 0.999)
        t_k = temperature_c + 273.15
        return (GAS_CONSTANT * t_k) / (2.0 * 96485.33212) * math.log(1.0 / (1.0 - ratio))

    def cell_voltage(self, current_density_A_cm2: float, temperature_c: float) -> float:
        if current_density_A_cm2 <= 0.0:
            return self.reversible_voltage(temperature_c)

        e_rev = self.reversible_voltage(temperature_c)

        # Anode kinetics degrade preferentially (catalyst dissolution of IrO2);
        # exchange_current_density_A_cm2 tracks cathode i0 baseline while the
        # anode i0 is scaled by the same relative degradation factor.
        degradation_factor = self.exchange_current_density_A_cm2 / self.I0_CATHODE_A_CM2
        i0_anode = self.I0_ANODE_A_CM2 * degradation_factor
        i0_cathode = self.exchange_current_density_A_cm2

        eta_act_a = self._activation_overpotential(current_density_A_cm2, temperature_c, i0_anode, self.ALPHA_ANODE)
        eta_act_c = self._activation_overpotential(current_density_A_cm2, temperature_c, i0_cathode, self.ALPHA_CATHODE)
        eta_ohm = current_density_A_cm2 * self._area_specific_resistance(temperature_c)
        eta_conc = self._concentration_overpotential(current_density_A_cm2, temperature_c)

        return e_rev + eta_act_a + eta_act_c + eta_ohm + eta_conc

    def faradaic_efficiency(self, current_density_A_cm2: float, temperature_c: float) -> float:
        if current_density_A_cm2 <= 0.0:
            return 0.0
        loss_fraction = self.CROSSOVER_CURRENT_DENSITY_A_CM2 / current_density_A_cm2
        return max(0.85, 1.0 - loss_fraction)
