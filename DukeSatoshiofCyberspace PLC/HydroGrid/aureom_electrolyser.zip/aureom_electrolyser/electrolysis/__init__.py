"""Electrochemical stack models: PEM, Alkaline and SOEC."""

from electrolysis.pem_model import PEMStackModel
from electrolysis.alkaline_model import AlkalineStackModel
from electrolysis.soec_model import SOECStackModel

__all__ = ["PEMStackModel", "AlkalineStackModel", "SOECStackModel", "build_stack_model"]


def build_stack_model(technology: str, stack_config, thermal_config):
    """Factory returning the correct stack model for a given technology string."""
    technology = technology.upper()
    if technology == "PEM":
        return PEMStackModel(stack_config, thermal_config)
    if technology == "ALKALINE":
        return AlkalineStackModel(stack_config, thermal_config)
    if technology == "SOEC":
        return SOECStackModel(stack_config, thermal_config)
    raise ValueError(f"Unsupported electrolyser technology: {technology}")
