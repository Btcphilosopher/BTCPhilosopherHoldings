"""
AUREOM-ELECTROLYSER CORE
Autonomous Unified Reactor for Electrochemical Hydrogen Production

A production-grade, physics-based simulation, design and optimisation
platform for industrial water electrolysis systems (PEM, Alkaline, SOEC).
"""

__version__ = "1.0.0"
