import pytest

from thermal.cooling_system import CoolingSystem
from thermal.heat_model import ThermalModel


def test_liquid_cooling_rejects_more_heat_with_larger_delta_t(pem_config):
    cooling = CoolingSystem(pem_config.thermal)
    q_small_dt = cooling.heat_rejected_kW(40.0, 20.0)
    q_large_dt = cooling.heat_rejected_kW(80.0, 20.0)
    assert q_large_dt > q_small_dt


def test_cooling_rejects_nothing_when_at_or_below_ambient(pem_config):
    cooling = CoolingSystem(pem_config.thermal)
    assert cooling.heat_rejected_kW(20.0, 20.0) == 0.0
    assert cooling.heat_rejected_kW(15.0, 20.0) == 0.0


def test_air_cooling_less_effective_than_liquid_at_equal_flow(pem_config):
    pem_config.thermal.cooling_type = "liquid"
    liquid_cooling = CoolingSystem(pem_config.thermal)
    pem_config.thermal.cooling_type = "air"
    air_cooling = CoolingSystem(pem_config.thermal)

    q_liquid = liquid_cooling.heat_rejected_kW(80.0, 20.0)
    q_air = air_cooling.heat_rejected_kW(80.0, 20.0)
    assert q_liquid > q_air


def test_stack_temperature_rises_under_net_heat_generation(pem_config):
    model = ThermalModel(pem_config.thermal, max_operating_temperature_c=90.0)
    initial_temp = model.temperature_c
    # Large current, high cell voltage above thermoneutral -> strong exothermic heat.
    for _ in range(200):
        model.step(
            thermoneutral_voltage_V=1.482,
            cell_voltage_V=2.0,
            current_A=3000.0,
            num_cells=200,
            num_stacks=1,
            dt_s=5.0,
            ambient_temperature_c=20.0,
        )
    assert model.temperature_c > initial_temp


def test_thermal_runaway_flag_trips_above_margin(pem_config):
    model = ThermalModel(pem_config.thermal, max_operating_temperature_c=90.0)
    result = None
    for _ in range(2000):
        result = model.step(
            thermoneutral_voltage_V=1.482,
            cell_voltage_V=2.5,
            current_A=5000.0,
            num_cells=200,
            num_stacks=1,
            dt_s=5.0,
            ambient_temperature_c=20.0,
        )
        if result.is_thermal_runaway:
            break
    assert result.is_thermal_runaway is True
    assert result.temperature_c >= 90.0


def test_efficiency_derate_is_full_below_target_temperature(pem_config):
    model = ThermalModel(pem_config.thermal, max_operating_temperature_c=90.0)
    model.temperature_c = pem_config.thermal.target_operating_temperature_c - 5.0
    assert model.efficiency_derate_factor() == 1.0


def test_efficiency_derate_falls_above_target_temperature(pem_config):
    model = ThermalModel(pem_config.thermal, max_operating_temperature_c=90.0)
    model.temperature_c = pem_config.thermal.target_operating_temperature_c + 10.0
    assert model.efficiency_derate_factor() < 1.0
