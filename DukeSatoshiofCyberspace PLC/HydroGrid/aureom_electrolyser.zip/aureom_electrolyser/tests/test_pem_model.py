import math

import pytest

from electrolysis.pem_model import PEMStackModel
from utils.constants import ELECTRONS_PER_H2, FARADAY_CONSTANT, MOLAR_MASS_H2, STANDARD_REVERSIBLE_VOLTAGE


def make_model(cfg):
    return PEMStackModel(cfg.stack, cfg.thermal)


def test_reversible_voltage_at_25c_matches_standard_value(pem_config):
    model = make_model(pem_config)
    assert model.reversible_voltage(25.0) == pytest.approx(STANDARD_REVERSIBLE_VOLTAGE, abs=1e-6)


def test_reversible_voltage_decreases_with_temperature(pem_config):
    model = make_model(pem_config)
    assert model.reversible_voltage(80.0) < model.reversible_voltage(25.0)


def test_cell_voltage_monotonically_increases_with_current_density(pem_config):
    model = make_model(pem_config)
    voltages = [model.cell_voltage(i, 65.0) for i in (0.1, 0.5, 1.0, 2.0, 3.0)]
    assert all(v2 > v1 for v1, v2 in zip(voltages, voltages[1:]))


def test_cell_voltage_at_zero_current_equals_reversible_voltage(pem_config):
    model = make_model(pem_config)
    assert model.cell_voltage(0.0, 65.0) == pytest.approx(model.reversible_voltage(65.0))


def test_faradays_law_mass_balance(pem_config):
    """Hydrogen mass rate from evaluate() must match Faraday's law computed independently."""
    model = make_model(pem_config)
    i = 1.5
    state = model.evaluate(i, 65.0)

    current_A_per_cell = i * model.active_area_cm2
    f_eff = model.faradaic_efficiency(i, 65.0)
    expected_mol_h2_per_s = f_eff * current_A_per_cell / (ELECTRONS_PER_H2 * FARADAY_CONSTANT) * model.num_cells * model.num_stacks
    expected_kg_h2_per_s = expected_mol_h2_per_s * MOLAR_MASS_H2

    assert state.hydrogen_kg_s == pytest.approx(expected_kg_h2_per_s, rel=1e-9)


def test_water_consumption_matches_stoichiometry(pem_config):
    model = make_model(pem_config)
    state = model.evaluate(1.0, 65.0)
    ratio = state.water_consumed_kg_s / state.hydrogen_kg_s
    assert ratio == pytest.approx(8.9366, rel=1e-3)


def test_power_current_inversion_round_trip(pem_config):
    """Solving current density from a target power must reproduce that power."""
    model = make_model(pem_config)
    target_power_kw = 500.0
    i = model.solve_current_density_for_power(target_power_kw, 65.0)
    recovered_power = model.stack_power_kW(i, 65.0)
    assert recovered_power == pytest.approx(target_power_kw, rel=1e-4)


def test_zero_power_gives_zero_current(pem_config):
    model = make_model(pem_config)
    assert model.solve_current_density_for_power(0.0, 65.0) == 0.0


def test_faradaic_efficiency_bounded(pem_config):
    model = make_model(pem_config)
    for i in (0.01, 0.1, 1.0, 4.0):
        eff = model.faradaic_efficiency(i, 65.0)
        assert 0.0 <= eff <= 1.0


def test_faradaic_efficiency_improves_with_current_density(pem_config):
    """Crossover loss is a fixed current, so its fractional impact shrinks as i grows."""
    model = make_model(pem_config)
    assert model.faradaic_efficiency(0.1, 65.0) < model.faradaic_efficiency(2.0, 65.0)


def test_degradation_offset_raises_cell_voltage(pem_config):
    model = make_model(pem_config)
    v_before = model.cell_voltage(1.0, 65.0)
    model.degradation_voltage_offset_V = 0.05
    v_after = model.cell_voltage(1.0, 65.0) + model.degradation_voltage_offset_V
    assert v_after > v_before
