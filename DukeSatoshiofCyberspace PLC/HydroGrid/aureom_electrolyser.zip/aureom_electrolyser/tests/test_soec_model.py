import pytest

from electrolysis.soec_model import SOECStackModel


def make_model(cfg):
    return SOECStackModel(cfg.stack, cfg.thermal)


def test_reversible_voltage_decreases_with_temperature(soec_config):
    model = make_model(soec_config)
    assert model.reversible_voltage(1000.0) < model.reversible_voltage(700.0)


def test_reversible_voltage_lower_than_liquid_water_pem_value(soec_config):
    """Steam electrolysis at high T has a markedly lower reversible voltage than liquid water at 25C."""
    model = make_model(soec_config)
    assert model.reversible_voltage(800.0) < 1.0


def test_cell_voltage_increases_with_current_density(soec_config):
    model = make_model(soec_config)
    voltages = [model.cell_voltage(i, 800.0) for i in (0.05, 0.2, 0.5, 0.8, 1.2)]
    assert all(v2 > v1 for v1, v2 in zip(voltages, voltages[1:]))


def test_soec_operates_near_thermoneutral_voltage(soec_config):
    """At its rated point, a well-designed SOEC should sit close to (below or near) E_tn."""
    model = make_model(soec_config)
    v_cell = model.cell_voltage(0.8, 800.0)
    assert 0.9 < v_cell < model._thermoneutral_voltage() + 0.3


def test_heat_demand_is_endothermic_below_thermoneutral(soec_config):
    model = make_model(soec_config)
    v_cell = model.cell_voltage(0.8, 800.0)
    heat_demand = model.heat_demand_kW(0.8, 800.0)
    if v_cell < model._thermoneutral_voltage():
        assert heat_demand > 0.0
    else:
        assert heat_demand <= 0.0


def test_faradaic_efficiency_very_high_for_dense_ceramic(soec_config):
    model = make_model(soec_config)
    assert model.faradaic_efficiency(0.5, 800.0) > 0.97


def test_exchange_current_density_increases_with_temperature(soec_config):
    """Arrhenius kinetics: higher T -> faster reaction -> higher effective i0."""
    model = make_model(soec_config)
    assert model._exchange_current_density(900.0) > model._exchange_current_density(700.0)
