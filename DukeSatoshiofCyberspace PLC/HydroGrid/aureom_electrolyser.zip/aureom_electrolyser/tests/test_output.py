import pytest

from output.compression import HydrogenCompressor
from output.hydrogen_flow import HydrogenFlowMeter


def test_compression_power_positive_for_valid_pressure_rise():
    compressor = HydrogenCompressor(inlet_pressure_bar=30.0, outlet_pressure_bar=200.0)
    result = compressor.compress(mass_flow_kg_s=0.01)
    assert result.compression_power_kW > 0.0
    assert result.num_stages >= 1


def test_compression_zero_when_no_pressure_rise():
    compressor = HydrogenCompressor(inlet_pressure_bar=200.0, outlet_pressure_bar=200.0)
    result = compressor.compress(mass_flow_kg_s=0.01)
    assert result.compression_power_kW == 0.0
    assert result.num_stages == 0


def test_more_stages_needed_for_larger_pressure_ratio():
    low_ratio = HydrogenCompressor(inlet_pressure_bar=30.0, outlet_pressure_bar=60.0).compress(0.01)
    high_ratio = HydrogenCompressor(inlet_pressure_bar=30.0, outlet_pressure_bar=900.0).compress(0.01)
    assert high_ratio.num_stages >= low_ratio.num_stages


def test_compression_power_scales_with_mass_flow():
    compressor = HydrogenCompressor(inlet_pressure_bar=30.0, outlet_pressure_bar=200.0)
    low_flow = compressor.compress(mass_flow_kg_s=0.01)
    high_flow = compressor.compress(mass_flow_kg_s=0.02)
    assert high_flow.compression_power_kW == pytest.approx(2.0 * low_flow.compression_power_kW, rel=1e-6)


def test_discharge_temperature_above_inlet_temperature():
    compressor = HydrogenCompressor(inlet_pressure_bar=30.0, outlet_pressure_bar=200.0, inlet_temperature_c=40.0)
    result = compressor.compress(mass_flow_kg_s=0.01)
    assert result.discharge_temperature_c > 40.0


def test_hydrogen_flow_meter_accumulates_production():
    meter = HydrogenFlowMeter("PEM")
    meter.step(mass_flow_kg_s=0.01, faradaic_efficiency=0.99, dt_s=3600.0)
    state = meter.step(mass_flow_kg_s=0.01, faradaic_efficiency=0.99, dt_s=3600.0)
    assert state.cumulative_production_kg == pytest.approx(0.01 * 3600.0 * 2, rel=1e-9)


def test_hydrogen_purity_degrades_with_lower_faradaic_efficiency():
    meter = HydrogenFlowMeter("PEM")
    high_eff_state = meter.step(mass_flow_kg_s=0.01, faradaic_efficiency=0.999, dt_s=1.0)
    low_eff_state = meter.step(mass_flow_kg_s=0.01, faradaic_efficiency=0.85, dt_s=1.0)
    assert low_eff_state.purity_pct < high_eff_state.purity_pct


def test_volumetric_flow_positive_and_consistent_with_mass_flow():
    meter = HydrogenFlowMeter("ALKALINE")
    state = meter.step(mass_flow_kg_s=0.05, faradaic_efficiency=0.95, dt_s=1.0)
    assert state.volumetric_flow_nm3_hr > 0.0
    assert state.mass_flow_kg_hr == pytest.approx(0.05 * 3600.0)
