"""Shared pytest fixtures: default configuration objects for each technology."""

import sys
from pathlib import Path

import pytest

# Ensure the project root (this file's parent's parent) is importable as
# top-level packages (core, electrolysis, ...) regardless of the directory
# pytest is invoked from.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from utils.config import StackConfig, ThermalConfig, SystemConfig


@pytest.fixture
def pem_config() -> SystemConfig:
    return SystemConfig()  # defaults are PEM, 1 MW


@pytest.fixture
def alkaline_config() -> SystemConfig:
    cfg = SystemConfig()
    cfg.stack = StackConfig(technology="ALKALINE", num_cells=150, active_area_cm2=25000.0,
                             membrane_thickness_um=500.0, num_stacks=1, rated_current_density_A_cm2=0.45)
    cfg.thermal = ThermalConfig(target_operating_temperature_c=80.0)
    return cfg


@pytest.fixture
def soec_config() -> SystemConfig:
    cfg = SystemConfig()
    cfg.stack = StackConfig(technology="SOEC", num_cells=100, active_area_cm2=200.0,
                             membrane_thickness_um=15.0, num_stacks=1, rated_current_density_A_cm2=0.8)
    cfg.thermal = ThermalConfig(
        target_operating_temperature_c=800.0,
        max_operating_temperature_c=900.0,
        initial_stack_temperature_c=800.0,
        cooling_type="air",
    )
    return cfg
