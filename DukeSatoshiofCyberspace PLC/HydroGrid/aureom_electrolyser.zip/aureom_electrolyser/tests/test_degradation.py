import pytest

from degradation.wear_model import WearModel
from electrolysis.pem_model import PEMStackModel


def make_stack_and_wear(cfg):
    stack = PEMStackModel(cfg.stack, cfg.thermal)
    bol_state = stack.evaluate(cfg.stack.rated_current_density_A_cm2, cfg.thermal.target_operating_temperature_c)
    wear = WearModel(cfg.degradation, stack, bol_state.stack_voltage_V)
    return stack, wear


def test_operating_hours_accumulate_only_while_running(pem_config):
    stack, wear = make_stack_and_wear(pem_config)
    wear.step(dt_s=3600.0, is_running=True, load_fraction=1.0, water_degradation_multiplier=1.0)
    wear.step(dt_s=3600.0, is_running=False, load_fraction=0.0, water_degradation_multiplier=1.0)
    assert wear.operating_hours == pytest.approx(1.0)


def test_voltage_offset_increases_monotonically_with_operating_hours(pem_config):
    stack, wear = make_stack_and_wear(pem_config)
    offsets = []
    for _ in range(50):
        state = wear.step(dt_s=3600.0, is_running=True, load_fraction=1.0, water_degradation_multiplier=1.0)
        offsets.append(state.voltage_offset_V)
    assert all(o2 >= o1 for o1, o2 in zip(offsets, offsets[1:]))
    assert offsets[-1] > 0.0


def test_catalyst_activity_decays_and_is_floored(pem_config):
    stack, wear = make_stack_and_wear(pem_config)
    bol_i0 = stack.exchange_current_density_A_cm2
    for _ in range(200):
        wear.step(dt_s=3600.0 * 100, is_running=True, load_fraction=1.0, water_degradation_multiplier=1.0)
    assert stack.exchange_current_density_A_cm2 < bol_i0
    assert stack.exchange_current_density_A_cm2 >= bol_i0 * 0.05 - 1e-15


def test_cyclic_loading_accelerates_degradation_vs_steady_load(pem_config):
    stack_a, wear_a = make_stack_and_wear(pem_config)
    stack_b, wear_b = make_stack_and_wear(pem_config)

    # Steady full load for A.
    for _ in range(20):
        wear_a.step(dt_s=3600.0, is_running=True, load_fraction=1.0, water_degradation_multiplier=1.0)

    # Alternating high/low load ("cycling") for B, same cumulative hours.
    for i in range(20):
        load = 1.0 if i % 2 == 0 else 0.15
        wear_b.step(dt_s=3600.0, is_running=True, load_fraction=load, water_degradation_multiplier=1.0)

    assert wear_b.stack_model.degradation_voltage_offset_V > wear_a.stack_model.degradation_voltage_offset_V


def test_poor_water_quality_accelerates_degradation(pem_config):
    stack_good, wear_good = make_stack_and_wear(pem_config)
    stack_bad, wear_bad = make_stack_and_wear(pem_config)

    for _ in range(20):
        wear_good.step(dt_s=3600.0, is_running=True, load_fraction=1.0, water_degradation_multiplier=1.0)
        wear_bad.step(dt_s=3600.0, is_running=True, load_fraction=1.0, water_degradation_multiplier=3.0)

    assert wear_bad.stack_model.degradation_voltage_offset_V > wear_good.stack_model.degradation_voltage_offset_V


def test_end_of_life_declared_when_threshold_exceeded(pem_config):
    pem_config.degradation.voltage_degradation_uv_per_hour = 50000.0  # accelerated for test speed
    stack, wear = make_stack_and_wear(pem_config)
    state = None
    for _ in range(500):
        state = wear.step(dt_s=3600.0, is_running=True, load_fraction=1.0, water_degradation_multiplier=1.0)
        if state.is_end_of_life:
            break
    assert state.is_end_of_life is True
    assert state.voltage_rise_pct >= pem_config.degradation.end_of_life_voltage_increase_pct
