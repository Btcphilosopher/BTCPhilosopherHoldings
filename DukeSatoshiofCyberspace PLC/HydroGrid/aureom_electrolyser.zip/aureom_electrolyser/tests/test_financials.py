import pytest

from financials.cost_model import compute_annual_opex, compute_capex
from financials.lcoh import (
    breakeven_electricity_price,
    capital_recovery_factor,
    compute_lcoh,
    net_present_value,
    roi_scenarios,
    sensitivity_analysis,
)


def test_capex_breakdown_sums_correctly(pem_config):
    capex = compute_capex(pem_config.financial, pem_config.electrical.rated_power_kw)
    assert capex.stack_cost_usd == pytest.approx(400.0 * 1000.0)
    assert capex.balance_of_plant_cost_usd == pytest.approx(350.0 * 1000.0)
    equipment = capex.stack_cost_usd + capex.balance_of_plant_cost_usd
    assert capex.installation_cost_usd == pytest.approx(0.20 * equipment)
    assert capex.total_capex_usd == pytest.approx(equipment + capex.installation_cost_usd)


def test_capital_recovery_factor_zero_discount_rate_equals_inverse_lifetime():
    assert capital_recovery_factor(0.0, 20) == pytest.approx(1.0 / 20.0)


def test_capital_recovery_factor_positive_and_less_than_one():
    crf = capital_recovery_factor(0.08, 20)
    assert 0.0 < crf < 1.0


def test_lcoh_decreases_with_more_annual_production(pem_config):
    capex = compute_capex(pem_config.financial, pem_config.electrical.rated_power_kw)
    opex = compute_annual_opex(pem_config.financial, capex, annual_energy_kwh=5_000_000, annual_water_m3=500, annual_h2_kg=100_000)

    lcoh_low_output = compute_lcoh(capex, opex, 50_000, pem_config.financial.discount_rate, pem_config.financial.project_lifetime_years)
    lcoh_high_output = compute_lcoh(capex, opex, 200_000, pem_config.financial.discount_rate, pem_config.financial.project_lifetime_years)

    assert lcoh_high_output.lcoh_usd_per_kg < lcoh_low_output.lcoh_usd_per_kg


def test_lcoh_is_positive_for_realistic_inputs(pem_config):
    capex = compute_capex(pem_config.financial, pem_config.electrical.rated_power_kw)
    opex = compute_annual_opex(pem_config.financial, capex, annual_energy_kwh=5_000_000, annual_water_m3=500, annual_h2_kg=100_000)
    lcoh = compute_lcoh(capex, opex, 100_000, pem_config.financial.discount_rate, pem_config.financial.project_lifetime_years)
    assert lcoh.lcoh_usd_per_kg > 0.0


def test_sensitivity_analysis_returns_all_parameters_sorted_by_impact():
    def fake_lcoh(a, b):
        return a * 1.0 + b * 10.0  # b has 10x the leverage of a

    results = sensitivity_analysis(fake_lcoh, {"a": 100.0, "b": 100.0}, variation_pct=0.1)
    names = [r[0] for r in results]
    assert set(names) == {"a", "b"}
    assert names[0] == "b"  # larger swing must be listed first


def test_breakeven_electricity_price_recovers_target_lcoh(pem_config):
    capex = compute_capex(pem_config.financial, pem_config.electrical.rated_power_kw)
    annual_h2 = 100_000.0
    annual_energy = 5_000_000.0
    non_electricity_opex = 50_000.0

    price = breakeven_electricity_price(
        capex, non_electricity_opex, annual_energy, annual_h2, target_lcoh_usd_per_kg=3.0,
        discount_rate=pem_config.financial.discount_rate, project_lifetime_years=pem_config.financial.project_lifetime_years,
    )

    crf = capital_recovery_factor(pem_config.financial.discount_rate, pem_config.financial.project_lifetime_years)
    implied_lcoh = (capex.total_capex_usd * crf + non_electricity_opex + price * annual_energy) / annual_h2
    assert implied_lcoh == pytest.approx(3.0, rel=1e-6)


def test_npv_negative_for_unprofitable_project():
    import numpy as np

    npv = net_present_value(1_000_000.0, np.full(10, 10_000.0), 0.08)
    assert npv < 0.0


def test_roi_scenarios_profitable_project_has_positive_npv(pem_config):
    capex = compute_capex(pem_config.financial, pem_config.electrical.rated_power_kw)
    result = roi_scenarios(capex, annual_revenue_usd=2_000_000.0, annual_opex_usd=500_000.0, discount_rate=0.08, project_lifetime_years=20)
    assert result["npv_usd"] > 0.0
    assert result["simple_payback_years"] > 0.0
