import pytest

from electrolysis.alkaline_model import AlkalineStackModel
from electrolysis.pem_model import PEMStackModel
from utils.constants import ELECTRONS_PER_H2, FARADAY_CONSTANT, MOLAR_MASS_H2


def make_model(cfg):
    return AlkalineStackModel(cfg.stack, cfg.thermal)


def test_cell_voltage_increases_with_current_density(alkaline_config):
    model = make_model(alkaline_config)
    voltages = [model.cell_voltage(i, 80.0) for i in (0.02, 0.1, 0.3, 0.6, 1.0)]
    assert all(v2 > v1 for v1, v2 in zip(voltages, voltages[1:]))


def test_alkaline_has_higher_overpotential_than_pem_at_low_current(alkaline_config, pem_config):
    """Ni-based alkaline electrodes are more kinetically sluggish than Pt/IrO2 PEM."""
    alk = make_model(alkaline_config)
    pem = PEMStackModel(pem_config.stack, pem_config.thermal)
    i = 0.1
    assert alk.cell_voltage(i, 80.0) > pem.cell_voltage(i, 65.0)


def test_bubble_voidage_increases_resistance_with_current(alkaline_config):
    model = make_model(alkaline_config)
    asr_low = model._area_specific_resistance(80.0, 0.05)
    asr_high = model._area_specific_resistance(80.0, 1.5)
    assert asr_high > asr_low


def test_electrolyte_conductivity_increases_with_temperature(alkaline_config):
    model = make_model(alkaline_config)
    sigma_cold = model._electrolyte_conductivity_S_cm(40.0)
    sigma_hot = model._electrolyte_conductivity_S_cm(90.0)
    assert sigma_hot > sigma_cold


def test_faradays_law_mass_balance(alkaline_config):
    model = make_model(alkaline_config)
    i = 0.3
    state = model.evaluate(i, 80.0)

    current_A_per_cell = i * model.active_area_cm2
    f_eff = model.faradaic_efficiency(i, 80.0)
    expected_mol_h2_per_s = f_eff * current_A_per_cell / (ELECTRONS_PER_H2 * FARADAY_CONSTANT) * model.num_cells * model.num_stacks
    expected_kg_h2_per_s = expected_mol_h2_per_s * MOLAR_MASS_H2

    assert state.hydrogen_kg_s == pytest.approx(expected_kg_h2_per_s, rel=1e-9)


def test_power_current_inversion_round_trip(alkaline_config):
    model = make_model(alkaline_config)
    target_power_kw = 3000.0
    i = model.solve_current_density_for_power(target_power_kw, 80.0)
    recovered_power = model.stack_power_kW(i, 80.0)
    assert recovered_power == pytest.approx(target_power_kw, rel=1e-4)
