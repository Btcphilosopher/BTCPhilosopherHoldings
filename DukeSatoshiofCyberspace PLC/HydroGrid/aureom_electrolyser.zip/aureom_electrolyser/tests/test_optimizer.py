import numpy as np
import pytest

from electrolysis.pem_model import PEMStackModel
from optimisation.optimizer import find_max_efficiency_operating_point, minimise_cost_per_kg, optimise_load_schedule


def test_max_efficiency_point_within_bounds(pem_config):
    model = PEMStackModel(pem_config.stack, pem_config.thermal)
    result = find_max_efficiency_operating_point(model, 65.0, i_min=0.05, i_max=2.0)
    assert 0.05 <= result.current_density_A_cm2 <= 2.0
    assert result.specific_energy_kwh_per_kg > 0.0


def test_max_efficiency_point_beats_random_points(pem_config):
    model = PEMStackModel(pem_config.stack, pem_config.thermal)
    result = find_max_efficiency_operating_point(model, 65.0, i_min=0.05, i_max=2.0)
    for i in (0.05, 0.5, 1.0, 1.5, 2.0):
        candidate = model.evaluate(i, 65.0).specific_energy_kwh_per_kg
        assert result.specific_energy_kwh_per_kg <= candidate + 1e-6


def test_cost_minimising_point_shifts_toward_higher_current_with_large_fixed_cost(pem_config):
    model = PEMStackModel(pem_config.stack, pem_config.thermal)
    low_fixed_cost = minimise_cost_per_kg(model, 65.0, electricity_price_usd_per_kwh=0.05, fixed_cost_usd_per_hour=1.0)
    high_fixed_cost = minimise_cost_per_kg(model, 65.0, electricity_price_usd_per_kwh=0.05, fixed_cost_usd_per_hour=5000.0)
    # A large fixed cost per hour rewards running the stack harder to dilute it across more kg.
    assert high_fixed_cost.current_density_A_cm2 >= low_fixed_cost.current_density_A_cm2


def test_load_schedule_meets_energy_requirement_and_prefers_cheap_periods():
    price = np.array([0.10, 0.02, 0.10, 0.02, 0.10])  # cheap at odd indices
    schedule = optimise_load_schedule(
        price_usd_per_kwh=price,
        period_hours=1.0,
        min_power_kw=0.0,
        max_power_kw=1000.0,
        required_total_energy_kwh=2000.0,
    )
    assert schedule.feasible is True
    assert schedule.total_energy_kwh >= 2000.0 - 1e-6
    # Cheap periods (index 1, 3) should be loaded harder than expensive ones (index 0, 2, 4).
    assert schedule.power_kw_by_period[1] >= schedule.power_kw_by_period[0]
    assert schedule.power_kw_by_period[3] >= schedule.power_kw_by_period[2]


def test_load_schedule_respects_ramp_limit():
    price = np.array([0.10, 0.01, 0.10, 0.01])
    schedule = optimise_load_schedule(
        price_usd_per_kwh=price,
        period_hours=1.0,
        min_power_kw=0.0,
        max_power_kw=1000.0,
        required_total_energy_kwh=1000.0,
        max_ramp_kw_per_period=100.0,
    )
    assert schedule.feasible is True
    deltas = np.abs(np.diff(schedule.power_kw_by_period))
    assert np.all(deltas <= 100.0 + 1e-6)


def test_load_schedule_infeasible_when_target_unreachable():
    price = np.array([0.05, 0.05])
    schedule = optimise_load_schedule(
        price_usd_per_kwh=price,
        period_hours=1.0,
        min_power_kw=0.0,
        max_power_kw=10.0,
        required_total_energy_kwh=1_000_000.0,  # impossible given the bounds
    )
    assert schedule.feasible is False
