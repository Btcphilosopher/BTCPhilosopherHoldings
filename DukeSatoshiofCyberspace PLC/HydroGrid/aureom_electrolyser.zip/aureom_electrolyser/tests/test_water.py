import pytest

from utils.constants import WATER_PER_KG_H2
from water.purity_model import PurityModel
from water.water_system import WaterSystem


def test_water_per_kg_h2_stoichiometric_constant():
    assert WATER_PER_KG_H2 == pytest.approx(8.9366, rel=1e-3)


def test_gross_intake_exceeds_net_consumption(pem_config):
    system = WaterSystem(pem_config.water)
    state = system.step(stoichiometric_water_kg_s=0.01, dt_s=1.0, is_running=True)
    assert state.gross_intake_kg_s >= state.net_consumption_kg_s


def test_purity_model_flags_out_of_spec_when_filtration_insufficient(pem_config):
    pem_config.water.filtration_efficiency = 0.5  # deliberately poor filtration
    model = PurityModel(pem_config.water)
    state = model.step(dt_s=1.0, is_running=True)
    assert state.within_spec is False
    assert state.degradation_multiplier > 1.0


def test_purity_model_in_spec_with_good_filtration(pem_config):
    model = PurityModel(pem_config.water)  # default filtration_efficiency = 0.999
    state = model.step(dt_s=1.0, is_running=True)
    assert state.within_spec is True
    assert state.degradation_multiplier == pytest.approx(1.0)


def test_fouling_accumulates_monotonically_over_operating_hours(pem_config):
    model = PurityModel(pem_config.water)
    fouling_values = []
    for _ in range(500):
        state = model.step(dt_s=3600.0, is_running=True)
        fouling_values.append(state.fouling_fraction)
    assert all(f2 >= f1 for f1, f2 in zip(fouling_values, fouling_values[1:]))
    assert fouling_values[-1] > fouling_values[0]


def test_fouling_does_not_accumulate_while_offline(pem_config):
    model = PurityModel(pem_config.water)
    state_off = model.step(dt_s=3600.0, is_running=False)
    assert state_off.fouling_fraction == 0.0
    assert model.cumulative_operating_hours == 0.0
