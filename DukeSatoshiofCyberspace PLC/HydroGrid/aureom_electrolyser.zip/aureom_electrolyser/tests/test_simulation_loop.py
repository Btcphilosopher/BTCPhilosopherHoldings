import os

import pytest

from core.engine import ElectrolyserSystem
from core.simulation_loop import run_simulation


def test_engine_step_produces_hydrogen_at_rated_power(pem_config, tmp_path):
    system = ElectrolyserSystem(pem_config)
    result = None
    for _ in range(120):
        result = system.step(available_power_kw=pem_config.electrical.rated_power_kw, dt_s=1.0)
    assert result.is_running is True
    assert result.electrochemical.hydrogen_kg_s > 0.0
    assert result.tripped is False


def test_engine_shuts_down_below_minimum_turndown(pem_config):
    system = ElectrolyserSystem(pem_config)
    below_min_power = 0.01 * pem_config.electrical.rated_power_kw
    result = system.step(available_power_kw=below_min_power, dt_s=1.0)
    assert result.is_running is False
    assert result.delivered_power_kW == 0.0


def test_full_simulation_run_produces_expected_log_columns(pem_config, tmp_path):
    pem_config.simulation.duration_s = 60.0
    pem_config.simulation.timestep_s = 2.0
    pem_config.simulation.log_path = str(tmp_path / "log.csv")

    result = run_simulation(pem_config, verbose=False)

    expected_columns = {
        "time_s", "available_power_kW", "delivered_power_kW", "hydrogen_kg_s",
        "cell_voltage_V", "stack_temperature_c", "system_efficiency_hhv",
        "voltage_rise_pct", "hydrogen_purity_pct",
    }
    assert expected_columns.issubset(set(result.log.columns))
    assert os.path.exists(pem_config.simulation.log_path)
    assert result.total_hydrogen_kg > 0.0
    assert result.lcoh.lcoh_usd_per_kg > 0.0
    assert 0.0 < result.average_efficiency_hhv < 1.0


def test_simulation_deterministic_given_same_seed(pem_config, tmp_path):
    pem_config.simulation.duration_s = 20.0
    pem_config.simulation.timestep_s = 2.0
    pem_config.simulation.random_seed = 123

    pem_config.simulation.log_path = str(tmp_path / "log_a.csv")
    result_a = run_simulation(pem_config, verbose=False)

    pem_config.simulation.log_path = str(tmp_path / "log_b.csv")
    result_b = run_simulation(pem_config, verbose=False)

    assert result_a.total_hydrogen_kg == pytest.approx(result_b.total_hydrogen_kg, rel=1e-9)
