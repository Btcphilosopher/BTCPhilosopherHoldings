"""
Physical, chemical and engineering constants used throughout AUREOM-ELECTROLYSER CORE.

All values are SI unless explicitly named otherwise (e.g. *_KWH_PER_KG).
"""

# ---------------------------------------------------------------------------
# Universal physical constants
# ---------------------------------------------------------------------------
FARADAY_CONSTANT = 96485.33212          # C / mol  (charge of one mole of electrons)
GAS_CONSTANT = 8.314462618              # J / (mol K)
STANDARD_TEMPERATURE = 298.15           # K  (25 C)
STANDARD_PRESSURE = 101325.0            # Pa (1 atm)
MOLAR_VOLUME_STP = 22.414               # L / mol at STP (0 C, 1 atm)
MOLAR_VOLUME_NTP = 24.055               # L / mol at NTP (20 C, 1 atm)

# ---------------------------------------------------------------------------
# Molar masses (kg/mol)
# ---------------------------------------------------------------------------
MOLAR_MASS_H2 = 0.0020159
MOLAR_MASS_O2 = 0.0319988
MOLAR_MASS_H2O = 0.0180153

# Electrons transferred per molecule of H2 produced (2 H+ + 2 e- -> H2)
ELECTRONS_PER_H2 = 2

# Stoichiometric water consumption per kg of H2 produced (2 H2O -> 2 H2 + O2)
# mass ratio = 2 * M_H2O / (2 * M_H2)
WATER_PER_KG_H2 = (2 * MOLAR_MASS_H2O) / (2 * MOLAR_MASS_H2)   # ~8.94 kg water / kg H2
OXYGEN_PER_KG_H2 = MOLAR_MASS_O2 / (2 * MOLAR_MASS_H2)          # ~7.94 kg O2 / kg H2

# ---------------------------------------------------------------------------
# Thermodynamics of water splitting (liquid water, 25 C, 1 atm reference)
# ---------------------------------------------------------------------------
STANDARD_REVERSIBLE_VOLTAGE = 1.229     # V, E0 (25 C, 1 atm) - reversible (Gibbs) cell voltage
THERMONEUTRAL_VOLTAGE = 1.482           # V, E_tn - enthalpy driven voltage (delta H / nF)
DE0_DT = -0.0009                        # V/K, empirical temperature coefficient of E0 (liquid feed)

# Higher / lower heating values of hydrogen
HHV_H2_MJ_PER_KG = 141.8
LHV_H2_MJ_PER_KG = 119.96
HHV_H2_KWH_PER_KG = HHV_H2_MJ_PER_KG / 3.6      # ~39.4 kWh/kg
LHV_H2_KWH_PER_KG = LHV_H2_MJ_PER_KG / 3.6      # ~33.3 kWh/kg

# Specific heat capacities (J / kg K)
CP_WATER = 4186.0
CP_KOH_ELECTROLYTE = 3500.0
CP_STACK_STRUCTURE = 900.0              # approximate metal/composite stack thermal mass

# ---------------------------------------------------------------------------
# Time conversions
# ---------------------------------------------------------------------------
SECONDS_PER_HOUR = 3600.0
HOURS_PER_YEAR = 8760.0

# ---------------------------------------------------------------------------
# Safety / operating limits (defaults, overridable per-model)
# ---------------------------------------------------------------------------
DEFAULT_MAX_STACK_TEMPERATURE_C = {
    "PEM": 90.0,
    "ALKALINE": 90.0,
    "SOEC": 900.0,
}
DEFAULT_THERMAL_RUNAWAY_MARGIN_C = 15.0  # degrees above max before hard trip
