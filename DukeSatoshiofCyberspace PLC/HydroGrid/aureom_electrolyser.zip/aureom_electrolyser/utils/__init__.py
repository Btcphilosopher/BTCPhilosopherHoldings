"""Utility subsystem: configuration, logging and shared constants."""
