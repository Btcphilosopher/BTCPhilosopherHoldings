"""
Centralised logging configuration for AUREOM-ELECTROLYSER CORE.

Provides a single entry point (``get_logger``) so every subsystem produces
consistent, timestamped, leveled log output, both to stdout and to a
rotating log file under ``logs/``.
"""

from __future__ import annotations

import logging
import os
import sys
from logging.handlers import RotatingFileHandler

_LOG_DIR = os.environ.get("AUREOM_LOG_DIR", "logs")
_LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)-28s | %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

_configured = False


def _configure_root(level: int = logging.INFO) -> None:
    global _configured
    if _configured:
        return

    os.makedirs(_LOG_DIR, exist_ok=True)

    root = logging.getLogger("aureom")
    root.setLevel(level)
    root.propagate = False

    formatter = logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT)

    stream_handler = logging.StreamHandler(stream=sys.stdout)
    stream_handler.setFormatter(formatter)
    root.addHandler(stream_handler)

    file_path = os.path.join(_LOG_DIR, "aureom_electrolyser.log")
    file_handler = RotatingFileHandler(
        file_path, maxBytes=5 * 1024 * 1024, backupCount=5
    )
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)

    _configured = True


def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """Return a namespaced logger under the ``aureom`` root logger."""
    _configure_root(level)
    logger = logging.getLogger(f"aureom.{name}")
    logger.setLevel(level)
    return logger
