"""
Typed configuration objects for AUREOM-ELECTROLYSER CORE.

Configuration can be built programmatically (dataclasses with sane
engineering defaults) or loaded from a YAML file via ``SystemConfig.from_yaml``.
No placeholder values: every default corresponds to a realistic, published
industrial parameter for the relevant electrolyser technology.
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

import yaml


@dataclass
class StackConfig:
    """Electrochemical stack design parameters."""

    technology: str = "PEM"                # "PEM", "ALKALINE", "SOEC"
    num_cells: int = 200                    # cells in series per stack
    active_area_cm2: float = 1500.0         # active cell area (cm^2)
    membrane_thickness_um: float = 150.0    # membrane / diaphragm thickness (micrometres)
    num_stacks: int = 1                     # number of stacks operated in parallel (plant scaling)
    rated_current_density_A_cm2: float = 2.0  # PEM: ~1.5-2.5, Alkaline: ~0.2-0.6, SOEC: ~0.5-1.0

    def __post_init__(self) -> None:
        self.technology = self.technology.upper()
        if self.technology not in ("PEM", "ALKALINE", "SOEC"):
            raise ValueError(f"Unsupported electrolyser technology: {self.technology}")


@dataclass
class ElectricalConfig:
    """Electrical supply / power-electronics parameters."""

    rated_power_kw: float = 1000.0          # nameplate DC power delivered to the stack array
    min_turndown_ratio: float = 0.10        # minimum stable load as a fraction of rated power
    max_ramp_rate_pct_per_s: float = 5.0    # % of rated power per second
    startup_energy_kwh: float = 2.0         # fixed energy penalty per cold start
    rectifier_efficiency: float = 0.97      # AC/DC conversion efficiency (grid-fed systems)
    source: str = "grid"                    # "grid", "solar", "wind", "mixed"


@dataclass
class ThermalConfig:
    """Thermal management parameters."""

    ambient_temperature_c: float = 20.0
    initial_stack_temperature_c: float = 20.0
    target_operating_temperature_c: float = 65.0   # PEM/Alkaline nominal; overridden for SOEC
    max_operating_temperature_c: Optional[float] = None  # None -> technology default
    cooling_type: str = "liquid"            # "liquid" or "air"
    coolant_flow_rate_kg_s: float = 2.0
    coolant_specific_heat_j_kgk: float = 3800.0   # water/glycol mixture
    heat_exchanger_ntu: float = 2.5         # effectiveness-NTU sizing parameter
    stack_thermal_mass_j_per_k: float = 5.0e6  # lumped thermal capacitance of stack + electrolyte


@dataclass
class WaterConfig:
    """Feedwater system parameters."""

    feed_resistivity_mohm_cm: float = 15.0   # ultra-pure water target (PEM), MOhm*cm
    recirculation_ratio: float = 20.0        # litres circulated per litre consumed
    filtration_efficiency: float = 0.999
    max_conductivity_us_cm: float = 1.0      # PEM feed spec
    fouling_rate_per_khr: float = 0.0008     # fractional efficiency loss per 1000 h from scaling


@dataclass
class DegradationConfig:
    """Long-term wear and degradation parameters."""

    voltage_degradation_uv_per_hour: float = 3.0     # steady-state PEM degradation, µV/cell/h
    cyclic_degradation_multiplier: float = 1.8        # extra wear factor from load cycling
    catalyst_activity_loss_per_khr: float = 0.004     # fractional loss in i0 per 1000 operating h
    end_of_life_voltage_increase_pct: float = 10.0    # % voltage rise defining stack EOL
    stack_replacement_cost_fraction: float = 0.45     # fraction of CAPEX to re-stack at EOL


@dataclass
class FinancialConfig:
    """CAPEX/OPEX/LCOH parameters."""

    stack_capex_usd_per_kw: float = 400.0
    balance_of_plant_capex_usd_per_kw: float = 350.0
    installation_capex_fraction: float = 0.20   # fraction of (stack+BoP) capex
    electricity_price_usd_per_kwh: float = 0.05
    water_price_usd_per_m3: float = 1.5
    fixed_om_pct_of_capex_per_year: float = 0.02
    variable_om_usd_per_kg_h2: float = 0.05
    discount_rate: float = 0.08
    project_lifetime_years: int = 20
    capacity_factor: float = 0.90


@dataclass
class SimulationConfig:
    """Simulation-loop control parameters."""

    timestep_s: float = 1.0
    duration_s: float = 3600.0
    random_seed: int = 42
    log_path: str = "output/simulation_log.csv"


@dataclass
class SystemConfig:
    """Top-level configuration bundle for a full plant simulation."""

    name: str = "AUREOM-DEFAULT-PLANT"
    stack: StackConfig = field(default_factory=StackConfig)
    electrical: ElectricalConfig = field(default_factory=ElectricalConfig)
    thermal: ThermalConfig = field(default_factory=ThermalConfig)
    water: WaterConfig = field(default_factory=WaterConfig)
    degradation: DegradationConfig = field(default_factory=DegradationConfig)
    financial: FinancialConfig = field(default_factory=FinancialConfig)
    simulation: SimulationConfig = field(default_factory=SimulationConfig)

    # ------------------------------------------------------------------
    @classmethod
    def from_yaml(cls, path: str) -> "SystemConfig":
        with open(path, "r", encoding="utf-8") as fh:
            raw: Dict[str, Any] = yaml.safe_load(fh) or {}
        return cls.from_dict(raw)

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "SystemConfig":
        kwargs: Dict[str, Any] = {}
        if "name" in raw:
            kwargs["name"] = raw["name"]

        section_map = {
            "stack": StackConfig,
            "electrical": ElectricalConfig,
            "thermal": ThermalConfig,
            "water": WaterConfig,
            "degradation": DegradationConfig,
            "financial": FinancialConfig,
            "simulation": SimulationConfig,
        }
        for section_name, section_cls in section_map.items():
            if section_name in raw and raw[section_name] is not None:
                kwargs[section_name] = section_cls(**raw[section_name])
        return cls(**kwargs)

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)

    def save_yaml(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as fh:
            yaml.safe_dump(self.to_dict(), fh, sort_keys=False)

    def max_operating_temperature(self) -> float:
        if self.thermal.max_operating_temperature_c is not None:
            return self.thermal.max_operating_temperature_c
        from utils.constants import DEFAULT_MAX_STACK_TEMPERATURE_C
        return DEFAULT_MAX_STACK_TEMPERATURE_C[self.stack.technology]
