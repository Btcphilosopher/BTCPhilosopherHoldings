"""Thermal generation and cooling subsystem."""
