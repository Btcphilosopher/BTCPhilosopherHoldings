"""
Cooling system models.

Two cooling architectures are supported:

  * Liquid cooling: a coolant loop (water/glycol) rejecting heat via an
    effectiveness-NTU heat exchanger to ambient.
  * Air cooling: forced-convection finned heat sink, heat rejection scales
    with (T_stack - T_ambient) and fan airflow.
"""

from __future__ import annotations

import math


class CoolingSystem:
    def __init__(self, thermal_config):
        self.cfg = thermal_config
        self.cooling_type = thermal_config.cooling_type.lower()

    def heat_rejected_kW(self, stack_temperature_c: float, ambient_temperature_c: float) -> float:
        if self.cooling_type == "liquid":
            return self._liquid_cooling_kW(stack_temperature_c, ambient_temperature_c)
        if self.cooling_type == "air":
            return self._air_cooling_kW(stack_temperature_c, ambient_temperature_c)
        raise ValueError(f"Unknown cooling type: {self.cooling_type}")

    # ------------------------------------------------------------------
    def _liquid_cooling_kW(self, t_stack_c: float, t_ambient_c: float) -> float:
        """
        Effectiveness-NTU heat exchanger model.

        effectiveness = 1 - exp(-NTU)   (single-stream limit: coolant is the
        minimum-capacitance fluid rejecting heat to a large ambient sink)
        Q = effectiveness * C_min * (T_hot_in - T_cold_in)
        """
        if t_stack_c <= t_ambient_c:
            return 0.0
        c_min_kw_per_k = (self.cfg.coolant_flow_rate_kg_s * self.cfg.coolant_specific_heat_j_kgk) / 1000.0
        effectiveness = 1.0 - math.exp(-self.cfg.heat_exchanger_ntu)
        q_kw = effectiveness * c_min_kw_per_k * (t_stack_c - t_ambient_c)
        return max(0.0, q_kw)

    def _air_cooling_kW(self, t_stack_c: float, t_ambient_c: float) -> float:
        """
        Forced convection: Q = h * A * dT, lumped into an overall UA (kW/K)
        derived from the configured coolant/air flow rate as a proxy for fan
        airflow (kg/s of air, cp_air ~ 1005 J/kgK) via the same NTU concept
        but with air's lower heat capacity -> larger required flow, weaker
        rejection per unit dT than liquid cooling at equal flow rate.
        """
        if t_stack_c <= t_ambient_c:
            return 0.0
        cp_air = 1005.0
        c_min_kw_per_k = (self.cfg.coolant_flow_rate_kg_s * cp_air) / 1000.0
        # Air-side heat exchangers are typically less effective than liquid loops.
        effectiveness = 1.0 - math.exp(-0.6 * self.cfg.heat_exchanger_ntu)
        q_kw = effectiveness * c_min_kw_per_k * (t_stack_c - t_ambient_c)
        return max(0.0, q_kw)
