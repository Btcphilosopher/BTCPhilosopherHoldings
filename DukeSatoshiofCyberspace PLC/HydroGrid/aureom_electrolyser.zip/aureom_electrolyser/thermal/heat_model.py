"""
Lumped-capacitance thermal model of the electrolyser stack.

Heat balance:

    C_thermal * dT/dt = Q_generated - Q_rejected(cooling) - Q_ambient_loss

Q_generated is the irreversible ("Joule") heat released by operating above
the thermoneutral voltage:  Q_gen = (V_cell - E_tn) * I * N_cells  (positive
= exothermic, typical of PEM/Alkaline at practical current densities).
For SOEC, operation can be endothermic (V_cell < E_tn), in which case
Q_generated is negative and process heat must be *supplied*, not rejected;
the cooling system then idles and a separate heater duty is reported.
"""

from __future__ import annotations

from dataclasses import dataclass

from thermal.cooling_system import CoolingSystem
from utils.constants import DEFAULT_THERMAL_RUNAWAY_MARGIN_C


@dataclass
class ThermalState:
    temperature_c: float
    heat_generated_kW: float
    heat_rejected_kW: float
    heater_duty_kW: float
    is_thermal_runaway: bool
    is_over_target: bool


class ThermalModel:
    def __init__(self, thermal_config, max_operating_temperature_c: float):
        self.cfg = thermal_config
        self.cooling = CoolingSystem(thermal_config)
        self.max_operating_temperature_c = max_operating_temperature_c
        self.temperature_c = thermal_config.initial_stack_temperature_c
        self.thermal_mass_j_per_k = thermal_config.stack_thermal_mass_j_per_k

        # Small fixed conductance representing passive heat loss to ambient
        # through stack casing/piping, independent of the active cooling loop.
        self.ambient_loss_UA_kw_per_k = 0.01 * (self.thermal_mass_j_per_k / 5.0e6)

    def step(
        self,
        thermoneutral_voltage_V: float,
        cell_voltage_V: float,
        current_A: float,
        num_cells: int,
        num_stacks: int,
        dt_s: float,
        ambient_temperature_c: float,
        soec_heat_demand_kW: float = 0.0,
    ) -> ThermalState:
        # Irreversible heat generation (positive: exothermic).
        heat_generated_kW = ((cell_voltage_V - thermoneutral_voltage_V) * current_A * num_cells * num_stacks) / 1000.0
        # SOEC endothermic operating points draw process heat instead.
        heat_generated_kW -= soec_heat_demand_kW

        ambient_loss_kW = self.ambient_loss_UA_kw_per_k * max(0.0, self.temperature_c - ambient_temperature_c)

        heater_duty_kW = 0.0
        heat_rejected_kW = 0.0

        if heat_generated_kW >= 0.0:
            heat_rejected_kW = self.cooling.heat_rejected_kW(self.temperature_c, ambient_temperature_c)
            net_heat_kW = heat_generated_kW - heat_rejected_kW - ambient_loss_kW
        else:
            # Net endothermic: an auxiliary heater must supply the shortfall
            # to hold the target operating temperature (typical SOEC BoP).
            heater_duty_kW = -heat_generated_kW
            net_heat_kW = heat_generated_kW + heater_duty_kW - ambient_loss_kW

        d_temp = (net_heat_kW * 1000.0 * dt_s) / self.thermal_mass_j_per_k
        self.temperature_c += d_temp

        runaway_threshold = self.max_operating_temperature_c + DEFAULT_THERMAL_RUNAWAY_MARGIN_C
        is_runaway = self.temperature_c >= runaway_threshold
        is_over_target = self.temperature_c > self.max_operating_temperature_c

        return ThermalState(
            temperature_c=self.temperature_c,
            heat_generated_kW=heat_generated_kW,
            heat_rejected_kW=heat_rejected_kW,
            heater_duty_kW=heater_duty_kW,
            is_thermal_runaway=is_runaway,
            is_over_target=is_over_target,
        )

    def efficiency_derate_factor(self) -> float:
        """
        Efficiency penalty applied as the stack runs hotter than its target
        operating temperature (accelerated side reactions, reduced membrane
        integrity margin). Below target, no penalty; above target, a mild
        linear derate; beyond the runaway threshold this becomes severe
        (handled by the caller tripping the stack offline).
        """
        target = self.cfg.target_operating_temperature_c
        if self.temperature_c <= target:
            return 1.0
        overshoot = self.temperature_c - target
        span = max(self.max_operating_temperature_c - target, 1.0)
        derate = max(0.0, 1.0 - 0.15 * (overshoot / span))
        return derate
