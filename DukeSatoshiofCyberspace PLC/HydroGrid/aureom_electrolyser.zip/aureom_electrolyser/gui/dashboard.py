"""
AUREOM-ELECTROLYSER CORE — industrial control dashboard.

A dark, data-dense, engineering-grade Dash application that visualises a
completed (or periodically refreshed) simulation log: hydrogen production
rate, system efficiency, thermal load, power balance, cost per kg H2 and
degradation status. No decorative chrome - every element on the page
carries a number or a trend.

Run (from the project root):
    python -m gui.dashboard --log results/simulation_log.csv
"""

from __future__ import annotations

import argparse

import pandas as pd
import plotly.graph_objects as go
from dash import Dash, dcc, html
from dash.dependencies import Input, Output

# ---------------------------------------------------------------------------
# Anglo-futuristic industrial palette: near-black ground, cold cyan/amber
# accents, no gradients, no shadows, no rounded decoration beyond function.
# ---------------------------------------------------------------------------
COLORS = {
    "background": "#0a0d10",
    "panel": "#12171c",
    "grid": "#1f2830",
    "text": "#d7e0e6",
    "muted": "#5b6b76",
    "accent_cyan": "#2ee6d6",
    "accent_amber": "#ffb020",
    "accent_red": "#ff3b3b",
    "accent_green": "#3ddc84",
}

PLOT_FONT = dict(family="Roboto Mono, Consolas, monospace", size=12, color=COLORS["text"])


def _base_figure_layout(title: str) -> dict:
    return dict(
        title=dict(text=title, font=dict(size=13, color=COLORS["muted"]), x=0.01),
        paper_bgcolor=COLORS["panel"],
        plot_bgcolor=COLORS["panel"],
        font=PLOT_FONT,
        margin=dict(l=50, r=20, t=36, b=36),
        xaxis=dict(gridcolor=COLORS["grid"], zeroline=False, title="time (s)"),
        yaxis=dict(gridcolor=COLORS["grid"], zeroline=False),
        legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(size=10)),
    )


def _kpi_card(label: str, value: str, unit: str, accent: str) -> html.Div:
    return html.Div(
        className="kpi-card",
        style={
            "backgroundColor": COLORS["panel"],
            "border": f"1px solid {COLORS['grid']}",
            "borderLeft": f"3px solid {accent}",
            "padding": "14px 18px",
            "minWidth": "180px",
        },
        children=[
            html.Div(label.upper(), style={"color": COLORS["muted"], "fontSize": "11px", "letterSpacing": "1px"}),
            html.Div(
                [
                    html.Span(value, style={"fontSize": "26px", "color": COLORS["text"], "fontWeight": "600"}),
                    html.Span(f" {unit}", style={"fontSize": "12px", "color": COLORS["muted"], "marginLeft": "4px"}),
                ]
            ),
        ],
    )


def load_log(path: str) -> pd.DataFrame:
    return pd.read_csv(path)


def build_app(log_path: str) -> Dash:
    app = Dash(__name__, title="AUREOM-ELECTROLYSER CORE")

    app.layout = html.Div(
        style={
            "backgroundColor": COLORS["background"],
            "minHeight": "100vh",
            "fontFamily": "Roboto Mono, Consolas, monospace",
            "padding": "20px 28px",
        },
        children=[
            html.Div(
                style={
                    "display": "flex",
                    "justifyContent": "space-between",
                    "alignItems": "baseline",
                    "borderBottom": f"1px solid {COLORS['grid']}",
                    "paddingBottom": "12px",
                    "marginBottom": "18px",
                },
                children=[
                    html.Div(
                        [
                            html.Span("AUREOM", style={"color": COLORS["accent_cyan"], "fontWeight": "700", "fontSize": "20px"}),
                            html.Span("-ELECTROLYSER CORE", style={"color": COLORS["text"], "fontSize": "20px"}),
                        ]
                    ),
                    html.Div("HYDROGEN PRODUCTION CONTROL SYSTEM", style={"color": COLORS["muted"], "fontSize": "12px", "letterSpacing": "2px"}),
                ],
            ),
            html.Div(id="kpi-row", style={"display": "flex", "gap": "12px", "flexWrap": "wrap", "marginBottom": "18px"}),
            html.Div(
                style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "14px"},
                children=[
                    dcc.Graph(id="graph-h2-rate", config={"displayModeBar": False}),
                    dcc.Graph(id="graph-efficiency", config={"displayModeBar": False}),
                    dcc.Graph(id="graph-thermal", config={"displayModeBar": False}),
                    dcc.Graph(id="graph-power", config={"displayModeBar": False}),
                    dcc.Graph(id="graph-degradation", config={"displayModeBar": False}),
                    dcc.Graph(id="graph-purity", config={"displayModeBar": False}),
                ],
            ),
            dcc.Interval(id="refresh-interval", interval=5000, n_intervals=0),
            dcc.Store(id="log-path-store", data=log_path),
        ],
    )

    @app.callback(
        Output("kpi-row", "children"),
        Output("graph-h2-rate", "figure"),
        Output("graph-efficiency", "figure"),
        Output("graph-thermal", "figure"),
        Output("graph-power", "figure"),
        Output("graph-degradation", "figure"),
        Output("graph-purity", "figure"),
        Input("refresh-interval", "n_intervals"),
        Input("log-path-store", "data"),
    )
    def refresh(_n_intervals, path):
        df = load_log(path)
        latest = df.iloc[-1]

        kpis = [
            _kpi_card("H2 Production", f"{latest['hydrogen_kg_s'] * 3600:.2f}", "kg/hr", COLORS["accent_cyan"]),
            _kpi_card("System Efficiency", f"{latest['system_efficiency_hhv'] * 100:.1f}", "% HHV", COLORS["accent_green"]),
            _kpi_card("Stack Temp", f"{latest['stack_temperature_c']:.1f}", "C", COLORS["accent_amber"]),
            _kpi_card("Power Draw", f"{latest['delivered_power_kW']:.0f}", "kW", COLORS["accent_cyan"]),
            _kpi_card("Specific Energy", f"{latest['specific_energy_kwh_per_kg']:.2f}", "kWh/kg", COLORS["accent_amber"]),
            _kpi_card(
                "Degradation",
                f"{latest['voltage_rise_pct']:.2f}",
                "% voltage rise",
                COLORS["accent_red"] if bool(latest["is_end_of_life"]) else COLORS["accent_green"],
            ),
        ]

        fig_h2 = go.Figure(layout=_base_figure_layout("HYDROGEN PRODUCTION RATE"))
        fig_h2.add_trace(go.Scatter(x=df["time_s"], y=df["hydrogen_kg_s"] * 3600, line=dict(color=COLORS["accent_cyan"]), name="kg/hr"))

        fig_eff = go.Figure(layout=_base_figure_layout("SYSTEM EFFICIENCY (HHV)"))
        fig_eff.add_trace(go.Scatter(x=df["time_s"], y=df["system_efficiency_hhv"] * 100, line=dict(color=COLORS["accent_green"]), name="%"))

        fig_thermal = go.Figure(layout=_base_figure_layout("STACK TEMPERATURE"))
        fig_thermal.add_trace(go.Scatter(x=df["time_s"], y=df["stack_temperature_c"], line=dict(color=COLORS["accent_amber"]), name="C"))

        fig_power = go.Figure(layout=_base_figure_layout("POWER INPUT vs OUTPUT"))
        fig_power.add_trace(go.Scatter(x=df["time_s"], y=df["available_power_kW"], line=dict(color=COLORS["muted"], dash="dot"), name="available kW"))
        fig_power.add_trace(go.Scatter(x=df["time_s"], y=df["delivered_power_kW"], line=dict(color=COLORS["accent_cyan"]), name="delivered kW"))

        fig_degradation = go.Figure(layout=_base_figure_layout("DEGRADATION — VOLTAGE RISE"))
        fig_degradation.add_trace(go.Scatter(x=df["time_s"], y=df["voltage_rise_pct"], line=dict(color=COLORS["accent_red"]), name="% rise"))

        fig_purity = go.Figure(layout=_base_figure_layout("HYDROGEN PURITY"))
        fig_purity.add_trace(go.Scatter(x=df["time_s"], y=df["hydrogen_purity_pct"], line=dict(color=COLORS["accent_cyan"]), name="%"))

        return kpis, fig_h2, fig_eff, fig_thermal, fig_power, fig_degradation, fig_purity

    return app


def main() -> None:
    parser = argparse.ArgumentParser(description="AUREOM-ELECTROLYSER CORE dashboard")
    parser.add_argument("--log", default="results/simulation_log.csv", help="Path to simulation log CSV")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8050)
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    app = build_app(args.log)
    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
