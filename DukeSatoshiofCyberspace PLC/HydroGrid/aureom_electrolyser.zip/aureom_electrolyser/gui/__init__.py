"""Industrial control-room dashboard (Dash / Plotly)."""
