"""
CAPEX and OPEX cost modelling for an electrolysis plant.

CAPEX is broken into:
  * electrolyser stack cost ($/kW of rated DC power)
  * balance-of-plant cost (power electronics, water treatment, cooling,
    compression, gas handling, controls) ($/kW)
  * installation / EPC uplift (fraction of equipment CAPEX)

OPEX is broken into:
  * electricity cost (the dominant term for most electrolysis economics)
  * water cost
  * fixed O&M (percentage of CAPEX per year: routine maintenance, staffing)
  * variable O&M (per kg H2: consumables, minor parts)
  * amortised stack replacement at end-of-life
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CapexBreakdown:
    stack_cost_usd: float
    balance_of_plant_cost_usd: float
    installation_cost_usd: float
    total_capex_usd: float


@dataclass
class OpexBreakdown:
    electricity_cost_usd: float
    water_cost_usd: float
    fixed_om_cost_usd: float
    variable_om_cost_usd: float
    stack_replacement_cost_usd: float
    total_opex_usd: float


def compute_capex(financial_config, rated_power_kw: float) -> CapexBreakdown:
    stack_cost = financial_config.stack_capex_usd_per_kw * rated_power_kw
    bop_cost = financial_config.balance_of_plant_capex_usd_per_kw * rated_power_kw
    equipment_cost = stack_cost + bop_cost
    installation_cost = financial_config.installation_capex_fraction * equipment_cost
    total = equipment_cost + installation_cost
    return CapexBreakdown(
        stack_cost_usd=stack_cost,
        balance_of_plant_cost_usd=bop_cost,
        installation_cost_usd=installation_cost,
        total_capex_usd=total,
    )


def compute_annual_opex(
    financial_config,
    capex: CapexBreakdown,
    annual_energy_kwh: float,
    annual_water_m3: float,
    annual_h2_kg: float,
    stack_replacement_cost_fraction: float = 0.0,
    stack_replacements_per_year: float = 0.0,
) -> OpexBreakdown:
    electricity_cost = annual_energy_kwh * financial_config.electricity_price_usd_per_kwh
    water_cost = annual_water_m3 * financial_config.water_price_usd_per_m3
    fixed_om = financial_config.fixed_om_pct_of_capex_per_year * capex.total_capex_usd
    variable_om = financial_config.variable_om_usd_per_kg_h2 * annual_h2_kg
    stack_replacement_cost = (
        stack_replacements_per_year * stack_replacement_cost_fraction * capex.total_capex_usd
    )
    total = electricity_cost + water_cost + fixed_om + variable_om + stack_replacement_cost
    return OpexBreakdown(
        electricity_cost_usd=electricity_cost,
        water_cost_usd=water_cost,
        fixed_om_cost_usd=fixed_om,
        variable_om_cost_usd=variable_om,
        stack_replacement_cost_usd=stack_replacement_cost,
        total_opex_usd=total,
    )
