"""
Levelized Cost of Hydrogen (LCOH) engine.

LCOH is computed with the standard capital-recovery-factor formulation:

    CRF = r(1+r)^n / ((1+r)^n - 1)
    LCOH = (CAPEX * CRF + annual OPEX) / annual H2 production (kg)

Also provided:
  * sensitivity analysis (tornado-style) of LCOH to key input variables
  * break-even electricity price for a target LCOH / grey-hydrogen benchmark
  * NPV and simple payback / ROI for a project cash-flow scenario
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np

from financials.cost_model import CapexBreakdown, OpexBreakdown


@dataclass
class LCOHResult:
    capital_recovery_factor: float
    annualised_capex_usd: float
    annual_opex_usd: float
    annual_h2_kg: float
    lcoh_usd_per_kg: float


def capital_recovery_factor(discount_rate: float, project_lifetime_years: int) -> float:
    r = discount_rate
    n = project_lifetime_years
    if r == 0:
        return 1.0 / n
    return (r * (1.0 + r) ** n) / ((1.0 + r) ** n - 1.0)


def compute_lcoh(
    capex: CapexBreakdown,
    opex: OpexBreakdown,
    annual_h2_kg: float,
    discount_rate: float,
    project_lifetime_years: int,
) -> LCOHResult:
    crf = capital_recovery_factor(discount_rate, project_lifetime_years)
    annualised_capex = capex.total_capex_usd * crf
    lcoh = (annualised_capex + opex.total_opex_usd) / annual_h2_kg if annual_h2_kg > 0 else float("inf")
    return LCOHResult(
        capital_recovery_factor=crf,
        annualised_capex_usd=annualised_capex,
        annual_opex_usd=opex.total_opex_usd,
        annual_h2_kg=annual_h2_kg,
        lcoh_usd_per_kg=lcoh,
    )


def sensitivity_analysis(
    base_lcoh_fn,
    base_values: Dict[str, float],
    variation_pct: float = 0.20,
) -> List[Tuple[str, float, float, float]]:
    """
    Generic tornado-chart sensitivity analysis.

    ``base_lcoh_fn`` must accept **kwargs matching the keys of
    ``base_values`` and return a scalar LCOH ($/kg). Each parameter is
    varied independently by +/- ``variation_pct`` while holding all others
    at their base value.

    Returns a list of (parameter_name, lcoh_at_low, lcoh_at_base, lcoh_at_high)
    sorted by descending impact (|high - low|).
    """
    base_lcoh = base_lcoh_fn(**base_values)
    results = []
    for key, base_value in base_values.items():
        low_kwargs = dict(base_values)
        high_kwargs = dict(base_values)
        low_kwargs[key] = base_value * (1.0 - variation_pct)
        high_kwargs[key] = base_value * (1.0 + variation_pct)
        lcoh_low = base_lcoh_fn(**low_kwargs)
        lcoh_high = base_lcoh_fn(**high_kwargs)
        results.append((key, lcoh_low, base_lcoh, lcoh_high))

    results.sort(key=lambda row: abs(row[3] - row[1]), reverse=True)
    return results


def breakeven_electricity_price(
    capex: CapexBreakdown,
    non_electricity_opex_usd: float,
    annual_energy_kwh: float,
    annual_h2_kg: float,
    target_lcoh_usd_per_kg: float,
    discount_rate: float,
    project_lifetime_years: int,
) -> float:
    """
    Solve algebraically for the electricity price ($/kWh) at which the LCOH
    equals a target benchmark (e.g. parity with grey/SMR hydrogen).

    target_lcoh * annual_h2_kg = annualised_capex + non_electricity_opex + price * annual_energy_kwh
    => price = (target_lcoh * annual_h2_kg - annualised_capex - non_electricity_opex) / annual_energy_kwh
    """
    crf = capital_recovery_factor(discount_rate, project_lifetime_years)
    annualised_capex = capex.total_capex_usd * crf
    numerator = target_lcoh_usd_per_kg * annual_h2_kg - annualised_capex - non_electricity_opex_usd
    if annual_energy_kwh <= 0:
        return float("nan")
    return numerator / annual_energy_kwh


def net_present_value(
    initial_capex_usd: float,
    annual_net_cash_flows_usd: np.ndarray,
    discount_rate: float,
) -> float:
    years = np.arange(1, len(annual_net_cash_flows_usd) + 1)
    discounted = annual_net_cash_flows_usd / (1.0 + discount_rate) ** years
    return -initial_capex_usd + float(np.sum(discounted))


def simple_payback_years(initial_capex_usd: float, annual_net_cash_flow_usd: float) -> float:
    if annual_net_cash_flow_usd <= 0:
        return float("inf")
    return initial_capex_usd / annual_net_cash_flow_usd


def roi_scenarios(
    capex: CapexBreakdown,
    annual_revenue_usd: float,
    annual_opex_usd: float,
    discount_rate: float,
    project_lifetime_years: int,
) -> Dict[str, float]:
    annual_net_cash_flow = annual_revenue_usd - annual_opex_usd
    cash_flows = np.full(project_lifetime_years, annual_net_cash_flow)
    npv = net_present_value(capex.total_capex_usd, cash_flows, discount_rate)
    payback = simple_payback_years(capex.total_capex_usd, annual_net_cash_flow)
    total_net_profit = annual_net_cash_flow * project_lifetime_years - capex.total_capex_usd
    roi_pct = 100.0 * total_net_profit / capex.total_capex_usd if capex.total_capex_usd > 0 else float("nan")
    return {
        "annual_net_cash_flow_usd": annual_net_cash_flow,
        "npv_usd": npv,
        "simple_payback_years": payback,
        "lifetime_roi_pct": roi_pct,
    }
