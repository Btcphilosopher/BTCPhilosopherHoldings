"""
Deterministic timestep simulation loop.

Drives an ``ElectrolyserSystem`` through a full scenario, logging every
subsystem's state at each timestep to a pandas DataFrame (and CSV), then
rolls the simulated period up into annualised financial metrics (CAPEX,
OPEX, LCOH) via the ``financials`` package.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd

from core.engine import ElectrolyserSystem
from electrical.power_input import PowerInputProfile
from financials.cost_model import compute_annual_opex, compute_capex
from financials.lcoh import compute_lcoh, LCOHResult
from utils.config import SystemConfig
from utils.constants import HOURS_PER_YEAR, SECONDS_PER_HOUR
from utils.logging import get_logger

logger = get_logger("core.simulation_loop")


@dataclass
class SimulationResult:
    log: pd.DataFrame
    total_hydrogen_kg: float
    total_energy_kwh: float
    total_water_m3: float
    duration_hours: float
    average_efficiency_hhv: float
    lcoh: LCOHResult


def run_simulation(config: SystemConfig, verbose: bool = True) -> SimulationResult:
    system = ElectrolyserSystem(config)

    dt_s = config.simulation.timestep_s
    duration_s = config.simulation.duration_s
    n_steps = int(round(duration_s / dt_s))
    timestamps_s = np.arange(n_steps) * dt_s

    power_profile = PowerInputProfile(
        rated_power_kw=config.electrical.rated_power_kw,
        source=config.electrical.source,
        random_seed=config.simulation.random_seed,
    )
    available_power = power_profile.generate(timestamps_s)

    records = []
    for step_index in range(n_steps):
        result = system.step(available_power[step_index], dt_s)
        records.append(_flatten_step_result(result))

        if verbose and step_index % max(1, n_steps // 10) == 0:
            pct = 100.0 * step_index / n_steps
            logger.info(f"Simulation progress: {pct:5.1f}% | t={result.time_s:8.1f}s")

    log_df = pd.DataFrame.from_records(records)

    log_path = config.simulation.log_path
    os.makedirs(os.path.dirname(log_path), exist_ok=True) if os.path.dirname(log_path) else None
    log_df.to_csv(log_path, index=False)
    logger.info(f"Simulation log written to {log_path}")

    duration_hours = duration_s / SECONDS_PER_HOUR
    total_h2_kg = float(log_df["hydrogen_kg_s"].fillna(0.0).sum() * dt_s)
    total_energy_kwh = float(log_df["delivered_power_kW"].fillna(0.0).sum() * dt_s / SECONDS_PER_HOUR)
    total_water_kg = float(log_df["water_consumed_kg_s"].fillna(0.0).sum() * dt_s)
    total_water_m3 = total_water_kg / 1000.0

    avg_efficiency = float(log_df["system_efficiency_hhv"].replace(0.0, np.nan).mean())
    avg_efficiency = 0.0 if np.isnan(avg_efficiency) else avg_efficiency

    # Scale the simulated window up to a full operating year using the
    # configured plant capacity factor, then compute LCOH on that basis.
    scale_to_year = HOURS_PER_YEAR * config.financial.capacity_factor / max(duration_hours, 1e-9)
    annual_h2_kg = total_h2_kg * scale_to_year
    annual_energy_kwh = total_energy_kwh * scale_to_year
    annual_water_m3 = total_water_m3 * scale_to_year

    capex = compute_capex(config.financial, config.electrical.rated_power_kw)

    # Expected stack replacements per year, derived from projected lifetime.
    last_valid_lifetime = log_df["projected_lifetime_hours"].replace([np.inf, -np.inf], np.nan).dropna()
    projected_lifetime_hours = float(last_valid_lifetime.iloc[-1]) if len(last_valid_lifetime) else float("inf")
    replacements_per_year = (HOURS_PER_YEAR * config.financial.capacity_factor / projected_lifetime_hours) if np.isfinite(projected_lifetime_hours) and projected_lifetime_hours > 0 else 0.0

    opex = compute_annual_opex(
        config.financial,
        capex,
        annual_energy_kwh,
        annual_water_m3,
        annual_h2_kg,
        stack_replacement_cost_fraction=config.degradation.stack_replacement_cost_fraction,
        stack_replacements_per_year=replacements_per_year,
    )

    lcoh = compute_lcoh(
        capex, opex, annual_h2_kg, config.financial.discount_rate, config.financial.project_lifetime_years
    )

    logger.info(
        f"Run complete: {total_h2_kg:.3f} kg H2 produced in {duration_hours:.2f} h "
        f"| avg efficiency (HHV) {avg_efficiency*100:.1f}% | LCOH ${lcoh.lcoh_usd_per_kg:.2f}/kg"
    )

    return SimulationResult(
        log=log_df,
        total_hydrogen_kg=total_h2_kg,
        total_energy_kwh=total_energy_kwh,
        total_water_m3=total_water_m3,
        duration_hours=duration_hours,
        average_efficiency_hhv=avg_efficiency,
        lcoh=lcoh,
    )


def _flatten_step_result(result) -> dict:
    row = {
        "time_s": result.time_s,
        "available_power_kW": result.available_power_kW,
        "delivered_power_kW": result.delivered_power_kW,
        "load_fraction": result.load_fraction,
        "is_running": result.is_running,
        "is_starting_up": result.is_starting_up,
        "tripped": result.tripped,
    }

    if result.electrochemical is not None:
        e = result.electrochemical
        row.update(
            {
                "current_density_A_cm2": e.current_density_A_cm2,
                "cell_voltage_V": e.cell_voltage_V,
                "stack_voltage_V": e.stack_voltage_V,
                "hydrogen_kg_s": e.hydrogen_kg_s,
                "oxygen_kg_s": e.oxygen_kg_s,
                "water_consumed_kg_s": e.water_consumed_kg_s,
                "faradaic_efficiency": e.faradaic_efficiency,
                "voltage_efficiency": e.voltage_efficiency,
                "system_efficiency_hhv": e.system_efficiency_hhv,
                "specific_energy_kwh_per_kg": e.specific_energy_kwh_per_kg,
            }
        )
    else:
        row.update(
            {
                "current_density_A_cm2": 0.0,
                "cell_voltage_V": 0.0,
                "stack_voltage_V": 0.0,
                "hydrogen_kg_s": 0.0,
                "oxygen_kg_s": 0.0,
                "water_consumed_kg_s": 0.0,
                "faradaic_efficiency": 0.0,
                "voltage_efficiency": 0.0,
                "system_efficiency_hhv": 0.0,
                "specific_energy_kwh_per_kg": 0.0,
            }
        )

    row["stack_temperature_c"] = result.thermal.temperature_c
    row["heat_generated_kW"] = result.thermal.heat_generated_kW
    row["heat_rejected_kW"] = result.thermal.heat_rejected_kW
    row["heater_duty_kW"] = result.thermal.heater_duty_kW
    row["is_thermal_runaway"] = result.thermal.is_thermal_runaway

    if result.hydrogen is not None:
        row["hydrogen_purity_pct"] = result.hydrogen.purity_pct
        row["cumulative_production_kg"] = result.hydrogen.cumulative_production_kg
        row["volumetric_flow_nm3_hr"] = result.hydrogen.volumetric_flow_nm3_hr
    else:
        row["hydrogen_purity_pct"] = 0.0
        row["cumulative_production_kg"] = 0.0
        row["volumetric_flow_nm3_hr"] = 0.0

    if result.compression is not None:
        row["compression_power_kW"] = result.compression.compression_power_kW
    else:
        row["compression_power_kW"] = 0.0

    d = result.degradation
    row["operating_hours"] = d.operating_hours
    row["voltage_rise_pct"] = d.voltage_rise_pct
    row["catalyst_activity_fraction"] = d.catalyst_activity_fraction
    row["is_end_of_life"] = d.is_end_of_life
    row["projected_lifetime_hours"] = d.projected_lifetime_hours

    return row
