"""Core simulation engine tying together every AUREOM subsystem."""
