"""
AUREOM electrolyser system engine.

``ElectrolyserSystem`` composes every subsystem (electrochemical stack,
electrical load response, thermal management, water supply, hydrogen
output/compression and long-term degradation) into a single stateful object
with one ``step(available_power_kw, dt_s)`` method per simulation timestep,
matching the deterministic loop specified for the platform:

    for each timestep:
        calculate power input
        compute electrolysis reaction
        generate hydrogen output
        update temperature
        apply efficiency losses
        update degradation
        compute costs
        log system state
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from degradation.wear_model import DegradationState, WearModel
from electrical.load_response import LoadResponseController, LoadResponseState
from electrolysis import build_stack_model
from electrolysis.base_model import ElectrochemicalState
from output.compression import CompressionResult, HydrogenCompressor
from output.hydrogen_flow import HydrogenFlowMeter, HydrogenFlowState
from thermal.heat_model import ThermalModel, ThermalState
from utils.config import SystemConfig
from utils.logging import get_logger
from water.water_system import WaterSystem, WaterSystemState

logger = get_logger("core.engine")


@dataclass
class SystemStepResult:
    time_s: float
    available_power_kW: float
    delivered_power_kW: float
    load_fraction: float
    is_running: bool
    is_starting_up: bool
    electrochemical: Optional[ElectrochemicalState]
    thermal: ThermalState
    water: Optional[WaterSystemState]
    hydrogen: Optional[HydrogenFlowState]
    compression: Optional[CompressionResult]
    degradation: DegradationState
    tripped: bool
    trip_reason: str = ""


class ElectrolyserSystem:
    """The full, single-plant electrolyser simulation object."""

    def __init__(self, config: SystemConfig):
        self.config = config
        self.stack_model = build_stack_model(config.stack.technology, config.stack, config.thermal)

        self.rated_power_kw = config.electrical.rated_power_kw
        self.max_operating_temperature_c = config.max_operating_temperature()

        self.load_response = LoadResponseController(config.electrical, self.rated_power_kw)
        self.thermal_model = ThermalModel(config.thermal, self.max_operating_temperature_c)
        self.water_system = WaterSystem(config.water)
        self.hydrogen_meter = HydrogenFlowMeter(config.stack.technology)
        self.compressor = HydrogenCompressor()

        # Beginning-of-life voltage at the rated operating point, used as the
        # degradation reference for end-of-life determination.
        bol_state = self.stack_model.evaluate(
            config.stack.rated_current_density_A_cm2, config.thermal.target_operating_temperature_c
        )
        self.wear_model = WearModel(config.degradation, self.stack_model, bol_state.stack_voltage_V)

        self.time_s: float = 0.0
        self.tripped: bool = False
        self.trip_reason: str = ""

    # ------------------------------------------------------------------
    def step(self, available_power_kw: float, dt_s: float) -> SystemStepResult:
        self.time_s += dt_s

        if self.tripped:
            # A tripped plant stays offline (safety shutdown on thermal runaway)
            # until externally reset; it still cools passively.
            thermal_state = self.thermal_model.step(
                thermoneutral_voltage_V=self.stack_model._thermoneutral_voltage(),
                cell_voltage_V=0.0,
                current_A=0.0,
                num_cells=self.stack_model.num_cells,
                num_stacks=self.stack_model.num_stacks,
                dt_s=dt_s,
                ambient_temperature_c=self.config.thermal.ambient_temperature_c,
            )
            water_state = self.water_system.step(0.0, dt_s, is_running=False)
            degradation_state = self.wear_model.step(dt_s, False, 0.0, water_state.quality.degradation_multiplier)
            return SystemStepResult(
                time_s=self.time_s,
                available_power_kW=available_power_kw,
                delivered_power_kW=0.0,
                load_fraction=0.0,
                is_running=False,
                is_starting_up=False,
                electrochemical=None,
                thermal=thermal_state,
                water=water_state,
                hydrogen=None,
                compression=None,
                degradation=degradation_state,
                tripped=True,
                trip_reason=self.trip_reason,
            )

        load_state: LoadResponseState = self.load_response.step(available_power_kw, dt_s)

        if not load_state.is_running:
            thermal_state = self.thermal_model.step(
                thermoneutral_voltage_V=self.stack_model._thermoneutral_voltage(),
                cell_voltage_V=0.0,
                current_A=0.0,
                num_cells=self.stack_model.num_cells,
                num_stacks=self.stack_model.num_stacks,
                dt_s=dt_s,
                ambient_temperature_c=self.config.thermal.ambient_temperature_c,
            )
            water_state = self.water_system.step(0.0, dt_s, is_running=False)
            degradation_state = self.wear_model.step(dt_s, False, 0.0, water_state.quality.degradation_multiplier)
            return SystemStepResult(
                time_s=self.time_s,
                available_power_kW=available_power_kw,
                delivered_power_kW=0.0,
                load_fraction=0.0,
                is_running=False,
                is_starting_up=False,
                electrochemical=None,
                thermal=thermal_state,
                water=water_state,
                hydrogen=None,
                compression=None,
                degradation=degradation_state,
                tripped=False,
            )

        # Thermal derate: an overheated stack is backed off before the hard trip.
        derate = self.thermal_model.efficiency_derate_factor()
        effective_power_kw = load_state.delivered_dc_power_kW * derate

        current_density = self.stack_model.solve_current_density_for_power(
            effective_power_kw, self.thermal_model.temperature_c
        )
        echem_state = self.stack_model.evaluate(current_density, self.thermal_model.temperature_c)

        soec_heat_demand_kw = 0.0
        if hasattr(self.stack_model, "heat_demand_kW"):
            soec_heat_demand_kw = self.stack_model.heat_demand_kW(current_density, self.thermal_model.temperature_c)

        thermal_state = self.thermal_model.step(
            thermoneutral_voltage_V=self.stack_model._thermoneutral_voltage(),
            cell_voltage_V=echem_state.cell_voltage_V,
            current_A=current_density * self.stack_model.active_area_cm2,
            num_cells=self.stack_model.num_cells,
            num_stacks=self.stack_model.num_stacks,
            dt_s=dt_s,
            ambient_temperature_c=self.config.thermal.ambient_temperature_c,
            soec_heat_demand_kW=soec_heat_demand_kw,
        )

        if thermal_state.is_thermal_runaway:
            self.tripped = True
            self.trip_reason = (
                f"Thermal runaway: stack temperature {thermal_state.temperature_c:.1f} C exceeded "
                f"safety threshold ({self.max_operating_temperature_c:.1f} C + margin)."
            )
            logger.error(self.trip_reason)

        water_state = self.water_system.step(echem_state.water_consumed_kg_s, dt_s, is_running=True)

        # Feedwater fouling manifests as extra area-specific resistance on the stack.
        if hasattr(self.stack_model, "area_specific_resistance_ohm_cm2"):
            baseline_asr = getattr(self.stack_model, "_baseline_asr_ohm_cm2", None)
            if baseline_asr is None:
                baseline_asr = self.stack_model.area_specific_resistance_ohm_cm2
                self.stack_model._baseline_asr_ohm_cm2 = baseline_asr
            self.stack_model.area_specific_resistance_ohm_cm2 = baseline_asr * (
                1.0 + water_state.quality.fouling_fraction
            )

        hydrogen_state = self.hydrogen_meter.step(echem_state.hydrogen_kg_s, echem_state.faradaic_efficiency, dt_s)
        compression_result = self.compressor.compress(echem_state.hydrogen_kg_s)

        load_fraction = load_state.delivered_dc_power_kW / self.rated_power_kw if self.rated_power_kw > 0 else 0.0
        degradation_state = self.wear_model.step(
            dt_s, True, load_fraction, water_state.quality.degradation_multiplier
        )

        return SystemStepResult(
            time_s=self.time_s,
            available_power_kW=available_power_kw,
            delivered_power_kW=load_state.delivered_dc_power_kW,
            load_fraction=load_fraction,
            is_running=True,
            is_starting_up=load_state.is_starting_up,
            electrochemical=echem_state,
            thermal=thermal_state,
            water=water_state,
            hydrogen=hydrogen_state,
            compression=compression_result,
            degradation=degradation_state,
            tripped=False,
        )

    def reset_trip(self) -> None:
        """Operator action: clear a thermal-runaway trip once the root cause is addressed."""
        self.tripped = False
        self.trip_reason = ""
