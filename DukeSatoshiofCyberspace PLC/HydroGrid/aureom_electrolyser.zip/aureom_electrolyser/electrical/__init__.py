"""Electrical supply and load-response subsystem."""
