"""
Load response and power-electronics behaviour.

Converts a *requested/available* power signal into the power actually
deliverable to the stack DC bus, subject to:

  * minimum turndown ratio (below which the stack must shut down rather
    than run unstably)
  * maximum ramp rate (electrolysers cannot track arbitrarily fast steps -
    power electronics and gas-side safety systems rate-limit the ramp)
  * cold-start energy penalty and a start-up transient during which the
    stack is brought from standby up to the requested operating point
  * AC/DC rectifier conversion efficiency (for grid-fed systems)
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class LoadResponseState:
    delivered_dc_power_kW: float
    is_running: bool
    is_starting_up: bool
    startup_energy_this_step_kWh: float


class LoadResponseController:
    """Stateful controller applied once per simulation timestep."""

    def __init__(self, electrical_config, rated_power_kw: float):
        self.cfg = electrical_config
        self.rated_power_kw = rated_power_kw
        self.min_power_kw = electrical_config.min_turndown_ratio * rated_power_kw
        self.max_ramp_kw_per_s = (electrical_config.max_ramp_rate_pct_per_s / 100.0) * rated_power_kw

        self._current_power_kw: float = 0.0
        self._is_running: bool = False
        self._startup_timer_s: float = 0.0
        self._startup_duration_s: float = 60.0  # nominal cold-start ramp time

    def step(self, requested_ac_power_kw: float, dt_s: float) -> LoadResponseState:
        requested_dc_power_kw = requested_ac_power_kw * self.cfg.rectifier_efficiency
        startup_energy_kwh = 0.0
        is_starting_up = False

        if requested_dc_power_kw < self.min_power_kw:
            # Below minimum stable turndown -> shut down.
            if self._is_running:
                self._is_running = False
            self._current_power_kw = 0.0
            return LoadResponseState(0.0, False, False, 0.0)

        if not self._is_running:
            # Cold start sequence begins.
            self._is_running = True
            self._startup_timer_s = 0.0
            startup_energy_kwh = self.cfg.startup_energy_kwh

        if self._startup_timer_s < self._startup_duration_s:
            is_starting_up = True
            self._startup_timer_s += dt_s
            ramp_fraction = min(1.0, self._startup_timer_s / self._startup_duration_s)
            target = self.min_power_kw + ramp_fraction * (requested_dc_power_kw - self.min_power_kw)
        else:
            target = requested_dc_power_kw

        # Apply ramp-rate limiting relative to the previous delivered power.
        max_delta = self.max_ramp_kw_per_s * dt_s
        delta = target - self._current_power_kw
        delta = max(-max_delta, min(max_delta, delta))
        self._current_power_kw = max(0.0, self._current_power_kw + delta)

        return LoadResponseState(
            delivered_dc_power_kW=self._current_power_kw,
            is_running=self._is_running,
            is_starting_up=is_starting_up,
            startup_energy_this_step_kWh=startup_energy_kwh,
        )

    @property
    def load_fraction(self) -> float:
        if self.rated_power_kw <= 0:
            return 0.0
        return self._current_power_kw / self.rated_power_kw
