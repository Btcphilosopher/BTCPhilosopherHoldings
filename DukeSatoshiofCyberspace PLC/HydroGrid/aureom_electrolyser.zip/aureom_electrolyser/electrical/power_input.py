"""
Power input profile generation.

Produces deterministic (seeded) time series of available DC power for the
electrolyser array, representing grid, solar, wind or a hybrid/mixed source.
Deterministic given a fixed random seed, so simulations are reproducible.
"""

from __future__ import annotations

import numpy as np


class PowerInputProfile:
    """Generates a power-availability profile (kW) for a given source type."""

    def __init__(self, rated_power_kw: float, source: str = "grid", random_seed: int = 42):
        self.rated_power_kw = rated_power_kw
        self.source = source.lower()
        self.rng = np.random.default_rng(random_seed)

    def generate(self, timestamps_s: np.ndarray) -> np.ndarray:
        """Return an array of available power (kW) aligned with ``timestamps_s``."""
        if self.source == "grid":
            return self._grid_profile(timestamps_s)
        if self.source == "solar":
            return self._solar_profile(timestamps_s)
        if self.source == "wind":
            return self._wind_profile(timestamps_s)
        if self.source == "mixed":
            return 0.5 * self._solar_profile(timestamps_s) + 0.5 * self._wind_profile(timestamps_s)
        raise ValueError(f"Unknown power source: {self.source}")

    # ------------------------------------------------------------------
    def _grid_profile(self, t: np.ndarray) -> np.ndarray:
        """Firm grid supply: near-constant at rated power with small measurement noise."""
        noise = self.rng.normal(0.0, 0.005 * self.rated_power_kw, size=t.shape)
        return np.clip(self.rated_power_kw + noise, 0.0, self.rated_power_kw)

    def _solar_profile(self, t: np.ndarray) -> np.ndarray:
        """Diurnal solar irradiance approximated as a clipped sinusoid + cloud noise."""
        hours = (t / 3600.0) % 24.0
        # Sunrise 06:00, sunset 18:00 -> half-sine profile
        base = np.sin(np.clip((hours - 6.0) / 12.0, 0.0, 1.0) * np.pi)
        base = np.where((hours < 6.0) | (hours > 18.0), 0.0, base)
        cloud_noise = self.rng.normal(1.0, 0.08, size=t.shape)
        power = self.rated_power_kw * base * np.clip(cloud_noise, 0.0, 1.2)
        return np.clip(power, 0.0, self.rated_power_kw)

    def _wind_profile(self, t: np.ndarray) -> np.ndarray:
        """Wind power via a cubic wind-speed-to-power relationship with an AR(1) speed process."""
        n = t.shape[0]
        mean_speed = 8.0    # m/s
        rated_speed = 12.0  # m/s -> rated power
        cut_in = 3.0
        cut_out = 25.0

        speed = np.zeros(n)
        speed[0] = mean_speed
        phi = 0.98
        for i in range(1, n):
            speed[i] = mean_speed + phi * (speed[i - 1] - mean_speed) + self.rng.normal(0.0, 0.6)
        speed = np.clip(speed, 0.0, 30.0)

        power_fraction = np.clip((speed - cut_in) / (rated_speed - cut_in), 0.0, 1.0) ** 3
        power_fraction = np.clip(power_fraction, 0.0, 1.0)
        power_fraction = np.where((speed < cut_in) | (speed > cut_out), 0.0, power_fraction)
        return self.rated_power_kw * power_fraction
