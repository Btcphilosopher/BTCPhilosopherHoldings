"""
Multi-stage hydrogen compression model.

Hydrogen's low molecular weight and high specific heat ratio make
single-stage compression to storage/pipeline pressure impractical (very
high discharge temperatures). This module sizes the number of compression
stages needed to respect a maximum per-stage pressure ratio, assumes
intercooling back to inlet temperature between stages, and computes the
polytropic compression work per stage from first principles.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from utils.constants import GAS_CONSTANT, MOLAR_MASS_H2

_SPECIFIC_GAS_CONSTANT_H2 = GAS_CONSTANT / MOLAR_MASS_H2  # J/(kg K), ~4124


@dataclass
class CompressionResult:
    num_stages: int
    stage_pressure_ratio: float
    specific_work_kJ_per_kg: float
    compression_power_kW: float
    discharge_temperature_c: float


class HydrogenCompressor:
    def __init__(
        self,
        inlet_pressure_bar: float = 30.0,
        outlet_pressure_bar: float = 200.0,
        polytropic_index: float = 1.4,
        isentropic_efficiency: float = 0.75,
        max_stage_pressure_ratio: float = 2.8,
        inlet_temperature_c: float = 40.0,
    ):
        self.inlet_pressure_bar = inlet_pressure_bar
        self.outlet_pressure_bar = outlet_pressure_bar
        self.n = polytropic_index
        self.eta_isentropic = isentropic_efficiency
        self.max_stage_ratio = max_stage_pressure_ratio
        self.inlet_temperature_c = inlet_temperature_c

    def compress(self, mass_flow_kg_s: float) -> CompressionResult:
        overall_ratio = self.outlet_pressure_bar / self.inlet_pressure_bar
        if overall_ratio <= 1.0:
            return CompressionResult(0, 1.0, 0.0, 0.0, self.inlet_temperature_c)

        num_stages = max(1, math.ceil(math.log(overall_ratio) / math.log(self.max_stage_ratio)))
        stage_ratio = overall_ratio ** (1.0 / num_stages)

        t1_k = self.inlet_temperature_c + 273.15
        exponent = (self.n - 1.0) / self.n

        # Specific work per stage (ideal, polytropic), J/kg -> summed over stages
        # with intercooling returning gas to inlet temperature before each stage.
        specific_work_per_stage = (
            (self.n / (self.n - 1.0)) * _SPECIFIC_GAS_CONSTANT_H2 * t1_k * (stage_ratio ** exponent - 1.0)
        )
        total_specific_work_J_per_kg = num_stages * specific_work_per_stage / self.eta_isentropic

        compression_power_kW = mass_flow_kg_s * total_specific_work_J_per_kg / 1000.0

        # Discharge temperature of the final stage (no intercooling after last stage).
        discharge_temperature_k = t1_k * stage_ratio ** exponent
        discharge_temperature_c = discharge_temperature_k - 273.15

        return CompressionResult(
            num_stages=num_stages,
            stage_pressure_ratio=stage_ratio,
            specific_work_kJ_per_kg=total_specific_work_J_per_kg / 1000.0,
            compression_power_kW=compression_power_kW,
            discharge_temperature_c=discharge_temperature_c,
        )
