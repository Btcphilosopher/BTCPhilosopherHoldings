"""Hydrogen output handling: flow metering, purity and compression."""
