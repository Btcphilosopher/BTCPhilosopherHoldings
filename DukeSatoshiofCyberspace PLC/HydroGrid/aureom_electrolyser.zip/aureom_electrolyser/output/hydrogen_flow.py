"""
Hydrogen output flow metering.

Converts the mass production rate coming out of the electrochemical model
into the engineering units used downstream (Nm3/h, purity), and tracks
cumulative production for lifetime/financial accounting.
"""

from __future__ import annotations

from dataclasses import dataclass

from utils.constants import MOLAR_MASS_H2, MOLAR_VOLUME_NTP, SECONDS_PER_HOUR


@dataclass
class HydrogenFlowState:
    mass_flow_kg_s: float
    mass_flow_kg_hr: float
    volumetric_flow_nm3_hr: float
    purity_pct: float
    cumulative_production_kg: float


class HydrogenFlowMeter:
    def __init__(self, technology: str):
        self.technology = technology.upper()
        self.cumulative_production_kg = 0.0

    def _base_purity_pct(self) -> float:
        return {
            "PEM": 99.999,
            "ALKALINE": 99.90,
            "SOEC": 99.995,
        }.get(self.technology, 99.9)

    def step(self, mass_flow_kg_s: float, faradaic_efficiency: float, dt_s: float) -> HydrogenFlowState:
        self.cumulative_production_kg += mass_flow_kg_s * dt_s

        mass_flow_kg_hr = mass_flow_kg_s * SECONDS_PER_HOUR
        mol_per_s = mass_flow_kg_s / MOLAR_MASS_H2
        volumetric_flow_nm3_hr = mol_per_s * (MOLAR_VOLUME_NTP / 1000.0) * SECONDS_PER_HOUR

        # Lower Faradaic efficiency correlates with more crossover gas
        # contamination, so purity degrades slightly as f_eff falls.
        base_purity = self._base_purity_pct()
        purity_pct = base_purity - (1.0 - faradaic_efficiency) * 15.0
        purity_pct = max(95.0, min(base_purity, purity_pct))

        return HydrogenFlowState(
            mass_flow_kg_s=mass_flow_kg_s,
            mass_flow_kg_hr=mass_flow_kg_hr,
            volumetric_flow_nm3_hr=volumetric_flow_nm3_hr,
            purity_pct=purity_pct,
            cumulative_production_kg=self.cumulative_production_kg,
        )
