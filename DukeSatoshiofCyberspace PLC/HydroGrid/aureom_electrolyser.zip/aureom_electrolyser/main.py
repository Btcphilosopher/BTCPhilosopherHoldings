#!/usr/bin/env python3
"""
AUREOM-ELECTROLYSER CORE — command line entry point.

Design -> Simulate -> Optimise -> Evaluate a hydrogen electrolysis plant.

Examples
--------
Run the default 1 MW PEM plant for one simulated hour on grid power:

    python main.py simulate --config config/default_config.yaml

Run a scenario and immediately launch the dashboard on the resulting log:

    python main.py simulate --config config/pem_1mw.yaml --dashboard

Run the optimiser to find the efficiency-maximising operating point:

    python main.py optimise --config config/default_config.yaml
"""

from __future__ import annotations

import argparse
import sys

from core.simulation_loop import run_simulation
from electrolysis import build_stack_model
from financials.cost_model import compute_annual_opex, compute_capex
from financials.lcoh import compute_lcoh, sensitivity_analysis
from optimisation.optimizer import find_max_efficiency_operating_point, minimise_cost_per_kg
from utils.config import SystemConfig
from utils.logging import get_logger

logger = get_logger("main")


def _load_config(path: str) -> SystemConfig:
    if path:
        return SystemConfig.from_yaml(path)
    return SystemConfig()


def cmd_simulate(args: argparse.Namespace) -> None:
    config = _load_config(args.config)
    result = run_simulation(config, verbose=not args.quiet)

    print("\n=== AUREOM-ELECTROLYSER CORE — SIMULATION SUMMARY ===")
    print(f"Plant:                  {config.name} ({config.stack.technology})")
    print(f"Duration simulated:     {result.duration_hours:.3f} h")
    print(f"Total H2 produced:      {result.total_hydrogen_kg:.4f} kg")
    print(f"Total energy consumed:  {result.total_energy_kwh:.2f} kWh")
    print(f"Total water consumed:   {result.total_water_m3:.4f} m3")
    print(f"Average efficiency:     {result.average_efficiency_hhv * 100:.2f} % (HHV)")
    print(f"Annualised LCOH:        ${result.lcoh.lcoh_usd_per_kg:.3f} / kg H2")
    print(f"Simulation log:         {config.simulation.log_path}")

    if args.dashboard:
        from gui.dashboard import build_app

        app = build_app(config.simulation.log_path)
        print(f"\nLaunching dashboard at http://127.0.0.1:{args.port} ...")
        app.run(host="127.0.0.1", port=args.port, debug=False)


def cmd_optimise(args: argparse.Namespace) -> None:
    config = _load_config(args.config)
    stack_model = build_stack_model(config.stack.technology, config.stack, config.thermal)

    temperature_c = config.thermal.target_operating_temperature_c

    best_efficiency = find_max_efficiency_operating_point(stack_model, temperature_c)
    print("\n=== EFFICIENCY-MAXIMISING OPERATING POINT ===")
    print(f"Current density:        {best_efficiency.current_density_A_cm2:.4f} A/cm2")
    print(f"Specific energy:        {best_efficiency.specific_energy_kwh_per_kg:.3f} kWh/kg")
    print(f"Stack power:            {best_efficiency.stack_power_kW:.2f} kW")
    print(f"H2 production rate:     {best_efficiency.hydrogen_kg_s * 3600:.4f} kg/hr")

    capex = compute_capex(config.financial, config.electrical.rated_power_kw)
    fixed_cost_per_hour = (config.financial.fixed_om_pct_of_capex_per_year * capex.total_capex_usd) / 8760.0

    best_cost = minimise_cost_per_kg(
        stack_model, temperature_c, config.financial.electricity_price_usd_per_kwh, fixed_cost_per_hour
    )
    print("\n=== COST-MINIMISING OPERATING POINT ===")
    print(f"Current density:        {best_cost.current_density_A_cm2:.4f} A/cm2")
    print(f"Specific energy:        {best_cost.specific_energy_kwh_per_kg:.3f} kWh/kg")
    print(f"H2 production rate:     {best_cost.hydrogen_kg_s * 3600:.4f} kg/hr")


def cmd_financials(args: argparse.Namespace) -> None:
    config = _load_config(args.config)
    result = run_simulation(config, verbose=False)

    capex = compute_capex(config.financial, config.electrical.rated_power_kw)
    print("\n=== CAPEX ===")
    print(f"Stack cost:             ${capex.stack_cost_usd:,.0f}")
    print(f"Balance of plant:       ${capex.balance_of_plant_cost_usd:,.0f}")
    print(f"Installation:           ${capex.installation_cost_usd:,.0f}")
    print(f"TOTAL CAPEX:            ${capex.total_capex_usd:,.0f}")

    print("\n=== LCOH ===")
    print(f"LCOH:                   ${result.lcoh.lcoh_usd_per_kg:.3f} / kg H2")

    from utils.constants import HOURS_PER_YEAR
    import numpy as _np

    last_valid_lifetime = result.log["projected_lifetime_hours"].replace([_np.inf, -_np.inf], _np.nan).dropna()
    base_projected_lifetime_hours = float(last_valid_lifetime.iloc[-1]) if len(last_valid_lifetime) else float("inf")

    def lcoh_fn(electricity_price_usd_per_kwh, stack_capex_usd_per_kw, capacity_factor):
        scaled_capex = compute_capex(
            type(config.financial)(
                **{**config.financial.__dict__, "stack_capex_usd_per_kw": stack_capex_usd_per_kw}
            ),
            config.electrical.rated_power_kw,
        )
        scale_to_year = HOURS_PER_YEAR * capacity_factor / max(result.duration_hours, 1e-9)
        annual_h2 = result.total_hydrogen_kg * scale_to_year
        annual_energy = result.total_energy_kwh * scale_to_year
        annual_water = result.total_water_m3 * scale_to_year

        replacements_per_year = (
            HOURS_PER_YEAR * capacity_factor / base_projected_lifetime_hours
            if _np.isfinite(base_projected_lifetime_hours) and base_projected_lifetime_hours > 0
            else 0.0
        )

        modified_financial = type(config.financial)(**{**config.financial.__dict__, "electricity_price_usd_per_kwh": electricity_price_usd_per_kwh})
        opex = compute_annual_opex(
            modified_financial, scaled_capex, annual_energy, annual_water, annual_h2,
            stack_replacement_cost_fraction=config.degradation.stack_replacement_cost_fraction,
            stack_replacements_per_year=replacements_per_year,
        )
        lcoh_result = compute_lcoh(scaled_capex, opex, annual_h2, config.financial.discount_rate, config.financial.project_lifetime_years)
        return lcoh_result.lcoh_usd_per_kg

    base_values = {
        "electricity_price_usd_per_kwh": config.financial.electricity_price_usd_per_kwh,
        "stack_capex_usd_per_kw": config.financial.stack_capex_usd_per_kw,
        "capacity_factor": config.financial.capacity_factor,
    }
    print("\n=== SENSITIVITY ANALYSIS (+/-20%) ===")
    for name, low, base, high in sensitivity_analysis(lcoh_fn, base_values):
        print(f"{name:35s} low=${low:.3f}  base=${base:.3f}  high=${high:.3f}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="aureom-electrolyser", description="AUREOM-ELECTROLYSER CORE")
    subparsers = parser.add_subparsers(dest="command", required=True)

    sim_parser = subparsers.add_parser("simulate", help="Run a deterministic plant simulation")
    sim_parser.add_argument("--config", default="config/default_config.yaml")
    sim_parser.add_argument("--dashboard", action="store_true", help="Launch the dashboard after the run")
    sim_parser.add_argument("--port", type=int, default=8050)
    sim_parser.add_argument("--quiet", action="store_true")
    sim_parser.set_defaults(func=cmd_simulate)

    opt_parser = subparsers.add_parser("optimise", help="Find optimal operating points")
    opt_parser.add_argument("--config", default="config/default_config.yaml")
    opt_parser.set_defaults(func=cmd_optimise)

    fin_parser = subparsers.add_parser("financials", help="Run the financial model and sensitivity analysis")
    fin_parser.add_argument("--config", default="config/default_config.yaml")
    fin_parser.set_defaults(func=cmd_financials)

    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
