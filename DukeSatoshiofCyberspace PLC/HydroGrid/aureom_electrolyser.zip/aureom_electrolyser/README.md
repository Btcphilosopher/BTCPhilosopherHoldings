# AUREOM-ELECTROLYSER CORE

**Autonomous Unified Reactor for Electrochemical Hydrogen Production**

A production-grade, physics-based simulation, design and optimisation platform
for industrial water electrolysis systems. AUREOM models real electrochemistry
(Nernst thermodynamics, Butler-Volmer kinetics, Ohmic and mass-transport
losses), thermal management, feedwater quality, hydrogen output and
compression, long-term stack degradation, and the full CAPEX/OPEX/LCOH
financial picture for **PEM**, **Alkaline** and **SOEC** electrolysers, from
kW pilot units to multi-MW industrial plants.

This is an engineering simulator, not a toy model: every number that comes
out of a run is the result of solving real polarization curves, real mass
balances (Faraday's law), and real heat-transfer and financial equations —
there is no lookup-table or placeholder logic anywhere in the codebase.

---

## Quickstart

```bash
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Run the default 1 MW PEM plant for a simulated hour on firm grid power
python main.py simulate --config config/default_config.yaml

# Run it and immediately open the live dashboard on the resulting log
python main.py simulate --config config/default_config.yaml --dashboard

# Find the efficiency- and cost-optimal operating points for a given design
python main.py optimise --config config/default_config.yaml

# Full CAPEX/OPEX/LCOH breakdown + sensitivity analysis
python main.py financials --config config/default_config.yaml

# Run the test suite (70 physics/engineering correctness tests)
pytest -q
```

Three ready-to-run scenarios are included in `config/`:

| Config | Technology | Scale | Notes |
|---|---|---|---|
| `default_config.yaml` | PEM | 1 MW | Grid-connected demonstrator |
| `alkaline_10mw.yaml` | Alkaline | 10 MW (4 stacks) | Industrial-scale plant |
| `soec_500kw.yaml` | SOEC | 500 kW (6 stacks) | High-temperature steam electrolysis pilot, pre-heated to 780 C |

---

## What's actually modelled

### Electrochemistry (`electrolysis/`)
Each technology implements a full polarization curve —
`V_cell = E_rev(T) + eta_activation + eta_ohmic + eta_concentration` — solved
from first principles, not curve-fit to a single operating point:

- **PEM** (`pem_model.py`): Nernst reversible voltage with a temperature
  coefficient; Butler-Volmer (arcsinh) activation kinetics for the anode
  (IrO2, sluggish OER) and cathode (Pt/C, fast HER); membrane ohmic
  resistance from the Springer et al. (1991) Nafion conductivity model;
  logarithmic concentration overpotential near a technology-realistic
  limiting current density; Faradaic efficiency loss from H2 crossover.
- **Alkaline** (`alkaline_model.py`): the same kinetic framework with
  Ni-based (non-noble) catalysts; ionic conduction through bulk KOH
  electrolyte via the Gilliam et al. (2007) conductivity correlation;
  a Bruggeman-type bubble-voidage correction that raises effective
  resistance with current density; diaphragm/separator resistance and
  crossover.
- **SOEC** (`soec_model.py`): steam (not liquid water) electrolysis
  thermodynamics — a lower, temperature-falling reversible voltage;
  Arrhenius-scaled electrode kinetics and YSZ electrolyte ionic
  conductivity; near-zero gas crossover through the dense ceramic
  electrolyte; an explicit endothermic/exothermic heat-demand calculation
  relative to the thermoneutral voltage.

Given a target power, `BaseStackModel.solve_current_density_for_power` root-
finds the actual operating current density on the real polarization curve
(via `scipy.optimize.brentq`) — power is never simply divided by an assumed
efficiency.

### Electrical (`electrical/`)
Deterministic (seeded) power-availability profiles for grid, solar (diurnal
half-sine + cloud noise) and wind (AR(1) wind-speed process through a cubic
power curve). A load-response controller applies minimum turndown,
ramp-rate limiting, cold-start energy penalties and AC/DC rectifier losses
before power ever reaches the stack.

### Thermal (`thermal/`)
A lumped-capacitance heat balance: `C * dT/dt = Q_generated - Q_rejected -
Q_ambient_loss`, where `Q_generated = (V_cell - E_thermoneutral) * I * N`
(negative/endothermic for efficient SOEC operation, positive/exothermic for
PEM and Alkaline at practical current densities). Liquid cooling uses an
effectiveness-NTU heat exchanger model; air cooling uses a weaker
forced-convection variant. A thermal-runaway margin trips the plant offline.

### Water (`water/`)
Stoichiometric feedwater demand (8.94 kg H2O / kg H2) from the mass balance,
grossed up for filtration losses; a purity model tracking feed conductivity
against the technology's spec, cumulative fouling/scaling as a function of
operating hours, and the resulting membrane-degradation acceleration.

### Output (`output/`)
Flow metering in kg/hr and Nm3/hr, purity estimation from Faradaic
efficiency, and a real multi-stage compression model (polytropic work per
stage, automatic stage-count sizing to respect a maximum per-stage pressure
ratio, intercooling, discharge temperature).

### Degradation (`degradation/`)
Voltage rise (uV/h) accelerated by load cycling and poor feedwater quality,
plus independent catalyst activity (exchange-current-density) decay — both
feed straight back into the live polarization curve, so a degraded stack
actually produces less hydrogen per kW as the simulation progresses.
End-of-life is declared at a configurable % voltage rise, with a projected
remaining-lifetime estimate.

### Financials (`financials/`)
CAPEX (stack + balance-of-plant + installation) and OPEX (electricity,
water, fixed/variable O&M, amortised stack replacement) roll up into a
Levelized Cost of Hydrogen via the standard capital-recovery-factor method.
Also included: tornado-style sensitivity analysis, break-even electricity
pricing against a target LCOH, and NPV/payback/ROI scenario analysis.

### Optimisation (`optimisation/`)
Scalar optimisation (`scipy.optimize.minimize_scalar`) of the real
polarization curve to find the efficiency-maximising and cost-minimising
operating points, and a linear program (`scipy.optimize.linprog`) that
schedules electrolyser load against a time-varying electricity price curve
to minimise cost subject to a production target and ramp constraints.

### Simulation engine (`core/`)
`ElectrolyserSystem.step()` runs the full deterministic per-timestep loop
(power in -> electrochemistry -> hydrogen out -> thermal update ->
degradation update -> logging), and `simulation_loop.run_simulation()`
drives it across a full scenario, logs every subsystem's state to a pandas
DataFrame/CSV, and rolls the simulated window up into annualised financial
metrics.

### Dashboard (`gui/dashboard.py`)
A dark, data-dense Dash/Plotly control-room interface: hydrogen production
rate, system efficiency, thermal load, power balance, degradation status
and purity, refreshed from the simulation log on an interval.

```bash
python -m gui.dashboard --log results/simulation_log.csv
```

---

## Project layout

```
aureom_electrolyser/
├── core/            simulation engine + deterministic timestep loop
├── electrolysis/    PEM / Alkaline / SOEC polarization-curve models
├── electrical/      power input profiles + load response
├── thermal/         heat generation + cooling systems
├── water/           feedwater balance + purity/fouling
├── output/          hydrogen flow metering + multi-stage compression
├── degradation/     voltage/catalyst wear + lifetime projection
├── financials/      CAPEX/OPEX + LCOH/NPV/ROI
├── optimisation/    efficiency/cost optimisation + load scheduling
├── gui/             industrial Dash dashboard
├── utils/           config, logging, physical constants
├── config/          ready-to-run YAML scenarios
├── tests/           70 pytest cases covering every subsystem
└── main.py          CLI: simulate / optimise / financials
```

## Configuration

Every design parameter lives in a typed dataclass (`utils/config.py`) with a
realistic engineering default, and can be overridden from a YAML file (see
`config/*.yaml`) or built programmatically. Sections: `stack`, `electrical`,
`thermal`, `water`, `degradation`, `financial`, `simulation`.

## Requirements

Python 3.11+, NumPy, SciPy, Pandas, PyYAML, Plotly, Dash. See
`requirements.txt` / `pyproject.toml`.
