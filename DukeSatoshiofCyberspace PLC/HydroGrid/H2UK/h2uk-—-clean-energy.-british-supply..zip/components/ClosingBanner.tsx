import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';

export default function ClosingBanner() {
  return (
    <section className="relative w-full overflow-hidden bg-[#0A1628] py-16 sm:py-20">
      {/* Background with British Coastal Wind Turbines */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/banner_clean_energy.jpg"
          alt="British coastal green hills and renewable wind turbines"
          fill
          sizes="100vw"
          className="object-cover object-center"
          referrerPolicy="no-referrer"
        />
        {/* Deep navy tint overlay ensuring contrast */}
        <div className="absolute inset-0 bg-[#071322]/85" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#071322]/95 via-[#0A182B]/85 to-[#071322]/75" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
          {/* Left Block */}
          <div className="max-w-xl space-y-3">
            <span className="text-xs sm:text-sm font-bold tracking-[0.2em] text-cyan-400 uppercase">
              A Cleaner, Brighter Future
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
              Let&apos;s power change — together.
            </h2>
          </div>

          {/* Right Block */}
          <div className="max-w-md space-y-5 lg:text-left">
            <p className="text-sm sm:text-base text-slate-200 leading-relaxed">
              Whether you&apos;re a homeowner, business or industrial partner, we&apos;re here to help you switch to cleaner, greener energy.
            </p>

            <div className="flex flex-wrap items-center gap-3">
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-[#0099FF] hover:bg-[#0088EE] active:bg-[#0077DD] rounded-full shadow-lg shadow-sky-500/25 transition-all duration-150 hover:shadow-sky-500/40 hover:-translate-y-0.5 whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300"
              >
                <span>Get in touch</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/quote"
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-white/10 hover:bg-white/20 border border-white/30 rounded-full transition-all duration-150 hover:-translate-y-0.5 whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
              >
                <span>Request Quotation</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
