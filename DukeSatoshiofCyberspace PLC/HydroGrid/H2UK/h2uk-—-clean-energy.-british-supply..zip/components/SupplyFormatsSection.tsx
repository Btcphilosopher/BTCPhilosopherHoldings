'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { ArrowRight, Check, AlertCircle, Wind, Snowflake, Layers, Gauge, Truck, ShieldCheck } from 'lucide-react';

export default function SupplyFormatsSection() {
  const [activeTab, setActiveTab] = useState<'both' | 'gaseous' | 'liquid'>('both');
  const [selectedApplication, setSelectedApplication] = useState<string>('fleet');

  const recommendation = selectedApplication === 'fleet'
    ? {
        format: 'Liquid Hydrogen (LH2) or High-Pressure Gaseous (350/700 bar)',
        reason: 'For 10+ heavy HGVs or high-duty bus fleets, liquid bunkering with high-throughput boil-off management maximizes depot energy density, while gaseous tube trailers suit fleets under 8 vehicles.',
        href: '/quote?sector=transport',
      }
    : selectedApplication === 'furnace'
    ? {
        format: 'Gaseous Hydrogen (GH2) via Tube Trailer or Pipeline',
        reason: 'Continuous high-temperature combustion processes require constant pressure manifold regulation (30–200 bar), making high-capacity gaseous tube trailers the standard engineering choice.',
        href: '/quote?sector=industry',
      }
    : selectedApplication === 'commercial'
    ? {
        format: 'Gaseous Hydrogen (GH2) Cylinder Pallet or Skid',
        reason: 'Commercial CHP and backup power installations require low-to-medium volumes with strict simplicity and passive safety, avoiding complex cryogenic boil-off vent lines.',
        href: '/quote?sector=business',
      }
    : {
        format: 'Domestic Pilot / Gaseous Micro-Distribution Only',
        reason: 'Liquid hydrogen is strictly prohibited for residential dwellings due to cryogenic boil-off and safety venting regulations. Only certified low-pressure gaseous blends or micro-bottles are considered in approved pilot zones.',
        href: '/for-homes',
      };

  return (
    <section className="w-full bg-white py-16 sm:py-24 border-b border-slate-200" id="supply-formats">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2">
            <span className="text-xs font-bold tracking-[0.2em] text-[#0099FF] uppercase">
              Engineering Specifications
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            Gaseous & Liquid Hydrogen Supply
          </h2>
          <p className="text-base text-slate-600 leading-relaxed">
            The appropriate hydrogen delivery format depends on purity requirements, pressure ratings, total volume demand, logistical footprint, and on-site infrastructure readiness.
          </p>
        </div>

        {/* Side-by-Side Comparison Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-12">
          {/* Card 1: Gaseous Hydrogen */}
          <div className="rounded-2xl border border-slate-200 bg-slate-50/60 p-6 sm:p-8 flex flex-col justify-between relative hover:border-sky-300 transition-colors shadow-sm">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-sky-100 flex items-center justify-center text-sky-600">
                    <Wind className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">Gaseous Hydrogen (GH<sub className="font-semibold">2</sub>)</h3>
                    <p className="text-xs font-semibold text-sky-600 uppercase tracking-wider">Compressed Gas · 200 to 500 Bar</p>
                  </div>
                </div>
              </div>

              {/* Attributes */}
              <div className="mt-6 space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-sky-100 flex items-center justify-center text-sky-700 shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <strong className="text-sm font-semibold text-slate-900">Optimal Use Cases:</strong>
                    <p className="text-xs sm:text-sm text-slate-600">
                      Industrial process heat, glass and metal processing, commercial backup generators, depot fleet refuelling (&lt;10 vehicles), and pilot district trials.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-sky-100 flex items-center justify-center text-sky-700 shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <strong className="text-sm font-semibold text-slate-900">Delivery & Logistics:</strong>
                    <p className="text-xs sm:text-sm text-slate-600">
                      Supplied via high-capacity road tube trailers (up to 1,100 kg payload at 300 bar), multi-cylinder pallet packs (MCPs), or bespoke pipeline manifolds.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-sky-100 flex items-center justify-center text-sky-700 shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <strong className="text-sm font-semibold text-slate-900">Site Infrastructure & Clearance:</strong>
                    <p className="text-xs sm:text-sm text-slate-600">
                      Requires designated DSEAR hazardous area clearance, concrete trailer hardstanding, earth bonding, pressure-reduction skid, and telemetry monitoring.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-6 mt-6 border-t border-slate-200 flex items-center justify-between">
              <span className="text-xs text-slate-500 font-medium">Standard Purity: 99.999% (Grade 5.0)</span>
              <Link
                href="/quote?format=gaseous"
                className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-[#0099FF] hover:text-sky-700"
              >
                <span>Enquire about gaseous supply</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          {/* Card 2: Liquid Hydrogen */}
          <div className="rounded-2xl border border-slate-200 bg-slate-50/60 p-6 sm:p-8 flex flex-col justify-between relative hover:border-cyan-300 transition-colors shadow-sm">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-cyan-100 flex items-center justify-center text-cyan-600">
                    <Snowflake className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">Liquid Hydrogen (LH<sub className="font-semibold">2</sub>)</h3>
                    <p className="text-xs font-semibold text-cyan-600 uppercase tracking-wider">Cryogenic · Minus 253°C</p>
                  </div>
                </div>
              </div>

              {/* Attributes */}
              <div className="mt-6 space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-cyan-100 flex items-center justify-center text-cyan-700 shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <strong className="text-sm font-semibold text-slate-900">Optimal Use Cases:</strong>
                    <p className="text-xs sm:text-sm text-slate-600">
                      Large-scale transport hubs, heavy freight corridors (30+ HGVs), aerospace, high-volume chemical feedstock, and bulk industrial off-grid bunkering.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-cyan-100 flex items-center justify-center text-cyan-700 shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <strong className="text-sm font-semibold text-slate-900">Delivery & Logistics:</strong>
                    <p className="text-xs sm:text-sm text-slate-600">
                      Vacuum super-insulated cryogenic road tankers (typically 3,500–4,200 kg per delivery load) offering 3x higher volumetric energy density than gas.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-amber-100 flex items-center justify-center text-amber-700 shrink-0 mt-0.5">
                    <AlertCircle className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <strong className="text-sm font-semibold text-slate-900">Cryogenic Site Requirements:</strong>
                    <p className="text-xs sm:text-sm text-slate-600">
                      Strict exclusion zone, perlite vacuum storage tanks, controlled boil-off gas (BOG) capture/recompression systems. <em>Not appropriate for ordinary domestic premises.</em>
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-6 mt-6 border-t border-slate-200 flex items-center justify-between">
              <span className="text-xs text-slate-500 font-medium">Volumetric Density: 71 kg/m³</span>
              <Link
                href="/quote?format=liquid"
                className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-cyan-600 hover:text-cyan-800"
              >
                <span>Enquire about liquid supply</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>

        {/* Interactive Supply Sizer / Feasibility Guide */}
        <div className="mt-12 p-6 sm:p-8 bg-[#0B192C] text-white rounded-2xl shadow-xl border border-slate-800">
          <div className="max-w-2xl">
            <span className="text-xs font-bold tracking-widest text-cyan-400 uppercase">Interactive Format Selector</span>
            <h3 className="text-xl sm:text-2xl font-bold mt-1 text-white">Which format fits your operational requirement?</h3>
            <p className="text-xs sm:text-sm text-slate-300 mt-2">
              Select your intended operational application to see H2UK technical supply recommendations:
            </p>
          </div>

          <div className="flex flex-wrap gap-2 mt-5">
            {[
              { id: 'fleet', label: 'Commercial Fleet / Freight Depot' },
              { id: 'furnace', label: 'High-Temperature Industrial Furnace' },
              { id: 'commercial', label: 'Commercial Building CHP / Backup' },
              { id: 'domestic', label: 'Domestic Heating Pilot' },
            ].map(btn => (
              <button
                key={btn.id}
                onClick={() => setSelectedApplication(btn.id)}
                className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                  selectedApplication === btn.id
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white'
                }`}
              >
                {btn.label}
              </button>
            ))}
          </div>

          <div className="mt-6 p-4 sm:p-5 bg-slate-900/90 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-xs font-semibold text-cyan-400 uppercase tracking-wide">
                Engineering Recommendation
              </div>
              <div className="text-base font-bold text-white">
                {recommendation.format}
              </div>
              <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
                {recommendation.reason}
              </p>
            </div>
            <Link
              href={recommendation.href}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-semibold bg-[#0099FF] hover:bg-[#0088EE] text-white rounded-full shrink-0 shadow-md transition-transform hover:-translate-y-0.5"
            >
              <span>Get Feasibility Assessment</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
