'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Search, X, ArrowRight, FileText, Building2, Home, Truck, Factory, Shield, Sparkles } from 'lucide-react';

interface SearchItem {
  id: string;
  title: string;
  category: 'Sector' | 'Supply' | 'Safety' | 'Commercial' | 'Article';
  description: string;
  href: string;
}

const SEARCH_DATABASE: SearchItem[] = [
  {
    id: 's-1',
    title: 'Hydrogen for Homes & Domestic Heating',
    category: 'Sector',
    description: 'Domestic suitability, appliance readiness, microgrid backup, and UK DESNZ trial zones.',
    href: '/for-homes',
  },
  {
    id: 's-2',
    title: 'Commercial Business Supply',
    category: 'Sector',
    description: 'Commercial procurement, CHP units, backup power generation, and scheduled deliveries.',
    href: '/for-businesses',
  },
  {
    id: 's-3',
    title: 'Heavy Industry & High-Temperature Process Heat',
    category: 'Sector',
    description: 'High-volume Grade 5.0 hydrogen, glass/steel furnaces, chemical feedstock, and pipeline delivery.',
    href: '/industry',
  },
  {
    id: 's-4',
    title: 'Transport Fleets & Logistics Refuelling',
    category: 'Sector',
    description: 'Fuel cell HGVs, bus depots, 350 bar & 700 bar dispensing, and cryogenic bunkering.',
    href: '/transport',
  },
  {
    id: 's-5',
    title: 'Gaseous Hydrogen (GH2) Specifications',
    category: 'Supply',
    description: '200, 300, and 500 bar high-pressure tube trailers and manifold cylinder pallets.',
    href: '/our-supply#gaseous',
  },
  {
    id: 's-6',
    title: 'Liquid Hydrogen (LH2) Cryogenics',
    category: 'Supply',
    description: '-253°C vacuum-insulated road tankers, high-density bulk storage and rapid vaporization.',
    href: '/our-supply#liquid',
  },
  {
    id: 's-7',
    title: 'Safety Governance, DSEAR & ATEX Standards',
    category: 'Safety',
    description: 'HSE compliance, zone 0/1/2 hazardous area zoning, ventilation clearances, and IGEM guidelines.',
    href: '/safety',
  },
  {
    id: 's-8',
    title: 'Low Carbon Hydrogen Standard (LCHS) & Carbon Accounting',
    category: 'Safety',
    description: 'UK emissions threshold (<20g CO2e/MJ LHV), electrolytic green certification, and traceability.',
    href: '/sustainability',
  },
  {
    id: 's-9',
    title: 'Online Quotation Request System',
    category: 'Commercial',
    description: 'Submit technical specifications, estimated volume and site postcode for tailored pricing.',
    href: '/quote',
  },
  {
    id: 's-10',
    title: 'UK Hydrogen Allocation Round (HAR3) Insights',
    category: 'Article',
    description: 'Government funding frameworks, commercial subsidies, and production ramp-up across the UK.',
    href: '/news',
  },
];

export default function SearchModal({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => inputRef.current?.focus(), 50);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  const handleClose = () => {
    setQuery('');
    setSelectedIndex(0);
    onClose();
  };

  const filtered = query.trim() === ''
    ? SEARCH_DATABASE.slice(0, 5)
    : SEARCH_DATABASE.filter(item =>
        item.title.toLowerCase().includes(query.toLowerCase()) ||
        item.description.toLowerCase().includes(query.toLowerCase()) ||
        item.category.toLowerCase().includes(query.toLowerCase())
      );

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev + 1) % Math.max(1, filtered.length));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev - 1 + filtered.length) % Math.max(1, filtered.length));
    } else if (e.key === 'Enter' && filtered[selectedIndex]) {
      e.preventDefault();
      router.push(filtered[selectedIndex].href);
      handleClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={handleClose}
    >
      <div
        className="w-full max-w-2xl bg-[#0F223A] border border-slate-700 rounded-2xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150"
        onClick={e => e.stopPropagation()}
        onKeyDown={handleKeyDown}
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-800 gap-3">
          <Search className="w-5 h-5 text-cyan-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={e => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            placeholder="Search supply formats, sectors, safety standards, quote..."
            className="w-full bg-transparent text-white placeholder-slate-400 text-sm focus:outline-none"
            aria-label="Search"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-white rounded"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <kbd className="hidden sm:inline-block px-2 py-0.5 text-[11px] font-mono text-slate-400 bg-slate-800/80 rounded border border-slate-700">
            ESC
          </kbd>
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-2 space-y-1">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-slate-400">
              <p className="text-sm">No matching specifications or pages found for &ldquo;{query}&rdquo;</p>
              <p className="text-xs text-slate-500 mt-1">Try searching for &ldquo;gaseous&rdquo;, &ldquo;liquid&rdquo;, &ldquo;transport&rdquo;, or &ldquo;quote&rdquo;.</p>
            </div>
          ) : (
            filtered.map((item, idx) => {
              const isSelected = idx === selectedIndex;
              return (
                <Link
                  key={item.id}
                  href={item.href}
                  onClick={handleClose}
                  className={`flex items-start justify-between gap-3 p-3 rounded-xl transition-colors ${
                    isSelected ? 'bg-cyan-500/15 border border-cyan-500/30 text-white' : 'hover:bg-slate-800/50 text-slate-200'
                  }`}
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-semibold tracking-wider uppercase text-cyan-400">
                        {item.category}
                      </span>
                      <span className="text-xs text-slate-500">·</span>
                      <h4 className="text-sm font-semibold text-white truncate">
                        {item.title}
                      </h4>
                    </div>
                    <p className="text-xs text-slate-400 line-clamp-1">
                      {item.description}
                    </p>
                  </div>
                  <ArrowRight className={`w-4 h-4 mt-1 shrink-0 transition-transform ${isSelected ? 'text-cyan-300 translate-x-0.5' : 'text-slate-500'}`} />
                </Link>
              );
            })
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-4 py-2.5 bg-[#0A1628] border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center gap-3">
            <span>↑↓ Navigate</span>
            <span>↵ Select</span>
            <span>ESC Close</span>
          </div>
          <span>H2UK Technical Registry</span>
        </div>
      </div>
    </div>
  );
}
