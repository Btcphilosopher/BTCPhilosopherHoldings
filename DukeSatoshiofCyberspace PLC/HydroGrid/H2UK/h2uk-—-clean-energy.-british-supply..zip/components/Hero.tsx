import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-[580px] lg:min-h-[660px] w-full flex items-center overflow-hidden bg-[#0A1628]">
      {/* Background Hero Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/hero_hydrogen_facility.jpg"
          alt="H2UK coastal hydrogen storage and distribution facility in Great Britain"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center lg:object-[center_right]"
          referrerPolicy="no-referrer"
        />
        {/* Cinematic gradient overlay to guarantee WCAG AA contrast on text while preserving the coastal facility visibility */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#071322]/95 via-[#0A182B]/85 to-transparent lg:w-[68%]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A1628] via-transparent to-black/30" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28 w-full">
        <div className="max-w-2xl lg:max-w-xl space-y-6">
          {/* Eyebrow */}
          <div className="inline-flex items-center gap-2">
            <span className="text-xs sm:text-sm font-bold tracking-[0.2em] text-cyan-400 uppercase">
              Britain&apos;s Hydrogen Supply Partner
            </span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-[3.5rem] font-black text-white tracking-tight leading-[1.08] font-sans">
            Clean energy for <br />
            a stronger, <span className="text-[#00C2CB] drop-shadow-sm">greener</span> UK.
          </h1>

          {/* Supporting Copy */}
          <p className="text-base sm:text-lg text-slate-200 leading-relaxed font-normal max-w-xl">
            We supply high-purity hydrogen — in liquid or gas form — to homes, businesses and industry across the UK. Reliable, flexible and built for a cleaner tomorrow.
          </p>

          {/* Call-to-Action Buttons */}
          <div className="flex flex-wrap items-center gap-4 pt-3">
            {/* Primary CTA: For Homes */}
            <Link
              href="/for-homes"
              className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 text-sm font-semibold text-white bg-[#0099FF] hover:bg-[#0088EE] active:bg-[#0077DD] rounded-full shadow-lg shadow-sky-500/30 transition-all duration-150 hover:shadow-sky-500/50 hover:-translate-y-0.5 whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300"
            >
              <span>For Homes</span>
              <ArrowRight className="w-4 h-4" />
            </Link>

            {/* Secondary CTA: For Businesses */}
            <Link
              href="/for-businesses"
              className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 text-sm font-semibold text-white bg-[#0B192C]/80 hover:bg-[#0B192C] active:bg-[#081220] border border-white/40 hover:border-white rounded-full backdrop-blur-sm transition-all duration-150 hover:-translate-y-0.5 whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              <span>For Businesses</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
