import React from 'react';

export default function TrustStrip() {
  return (
    <section className="w-full bg-white border-b border-slate-200 shadow-sm" aria-label="Key Commitments">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-6">
          {/* 1. Low Carbon */}
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-full flex items-center justify-center shrink-0 border border-emerald-500/20 bg-emerald-50/50">
              <svg className="w-6 h-6 text-emerald-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z" />
                <path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12" />
              </svg>
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-snug">Low Carbon</h3>
              <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-relaxed">
                Helps reduce emissions across every sector.
              </p>
            </div>
          </div>

          {/* 2. Reliable Supply */}
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-full flex items-center justify-center shrink-0 border border-cyan-500/20 bg-cyan-50/50">
              <svg className="w-6 h-6 text-cyan-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                <path d="m9 12 2 2 4-4" />
              </svg>
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-snug">Reliable Supply</h3>
              <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-relaxed">
                UK-based, secure and future-ready.
              </p>
            </div>
          </div>

          {/* 3. Flexible Solutions */}
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-full flex items-center justify-center shrink-0 border border-sky-500/20 bg-sky-50/50">
              <svg className="w-6 h-6 text-sky-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z" />
              </svg>
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-snug">Flexible Solutions</h3>
              <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-relaxed">
                Liquid or gas, tailored to your needs.
              </p>
            </div>
          </div>

          {/* 4. British Owned */}
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-full overflow-hidden shrink-0 border border-slate-200 bg-sky-900 flex items-center justify-center shadow-inner">
              {/* Circular Union Jack emblem */}
              <svg className="w-8 h-8" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect width="60" height="60" fill="#012169" />
                {/* White diagonals */}
                <path d="M0 0L60 60M60 0L0 60" stroke="#FFFFFF" strokeWidth="10" />
                {/* Red diagonals */}
                <path d="M0 0L60 60M60 0L0 60" stroke="#C8102E" strokeWidth="4" />
                {/* White cross */}
                <path d="M30 0V60M0 30H60" stroke="#FFFFFF" strokeWidth="14" />
                {/* Red cross */}
                <path d="M30 0V60M0 30H60" stroke="#C8102E" strokeWidth="8" />
              </svg>
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-snug">British Owned</h3>
              <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-relaxed">
                Supporting UK jobs and a cleaner economy.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
