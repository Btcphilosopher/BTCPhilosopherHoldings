import React from 'react';
import Link from 'next/link';
import { ShieldCheck, Compass, GitMerge, FileCheck, Headphones, ArrowRight } from 'lucide-react';

export default function WhyH2UKSection() {
  const pillars = [
    {
      title: 'Strategic Supply Planning',
      description: 'Aligning off-take demand with British production hubs along the Humber, Teesside, Mersey, and Scottish coastal corridors to minimize transport mileage and freight costs.',
      icon: <Compass className="w-5 h-5 text-cyan-600" />,
    },
    {
      title: 'Engineering-Led Technical Support',
      description: 'Direct collaboration between qualified hazardous-process engineers and your operations team, navigating DSEAR zoning, pressure manifolds, and vaporization requirements.',
      icon: <ShieldCheck className="w-5 h-5 text-sky-600" />,
    },
    {
      title: 'Sourcing Transparency',
      description: 'Rigorous carbon intensity accounting aligned with the UK Low Carbon Hydrogen Standard (LCHS), providing clear provenance between electrolytic green and low-carbon pathways.',
      icon: <FileCheck className="w-5 h-5 text-emerald-600" />,
    },
    {
      title: 'Responsive Customer Desk',
      description: 'Dedicated UK-based account managers who monitor tank telemetry levels in real-time, coordinating timely top-ups before low-pressure thresholds are reached.',
      icon: <Headphones className="w-5 h-5 text-cyan-600" />,
    },
  ];

  return (
    <section className="w-full bg-white py-16 sm:py-24 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-5 space-y-5">
            <span className="text-xs font-bold tracking-[0.2em] text-[#0099FF] uppercase">
              Commercial & Engineering Foundation
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight leading-tight">
              Why Choose H2UK as Your Supply Partner
            </h2>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              As the UK accelerates towards industrial net-zero and clean power targets, securing reliable, verified hydrogen requires more than just marketing claims. We build practical commercial supply routes tailored to actual British operational realities.
            </p>
            <div className="pt-2">
              <Link
                href="/about"
                className="inline-flex items-center gap-2 text-sm font-bold text-[#0099FF] hover:text-[#0077CC]"
              >
                <span>Read about our British supply roadmap</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-5">
            {pillars.map((pillar) => (
              <div
                key={pillar.title}
                className="p-6 rounded-2xl bg-slate-50 border border-slate-200/90 shadow-sm space-y-3 hover:border-sky-300 transition-colors"
              >
                <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center shadow-xs">
                  {pillar.icon}
                </div>
                <h3 className="text-base font-bold text-slate-900">
                  {pillar.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {pillar.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
