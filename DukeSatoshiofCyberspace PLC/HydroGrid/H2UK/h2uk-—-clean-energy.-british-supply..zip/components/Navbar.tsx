'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Search, ChevronDown, Menu, X, ArrowRight, ShieldCheck, Flame, Building2, Truck, Factory, Sparkles } from 'lucide-react';
import SearchModal from './SearchModal';

export default function Navbar() {
  const pathname = usePathname();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Keyboard shortcut Cmd+K or Ctrl+K for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <>
      <header
        className={`sticky top-0 z-40 w-full transition-all duration-200 ${
          scrolled
            ? 'bg-[#0B192C]/95 backdrop-blur-md border-b border-slate-800 shadow-lg'
            : 'bg-[#0B192C] border-b border-white/10'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20 gap-8">
            {/* Zone 1: Brand Wordmark & Tagline Lockup */}
            <Link
              href="/"
              className="flex items-center gap-3.5 group shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 rounded-md"
              aria-label="H2UK Home"
            >
              {/* Custom SVG H2UK Leaf & Droplet Mark */}
              <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 via-sky-500 to-emerald-500 p-0.5 shadow-md shadow-cyan-500/20 group-hover:scale-105 transition-transform">
                <div className="w-full h-full bg-[#0B192C] rounded-[10px] flex items-center justify-center">
                  <svg
                    className="w-6 h-6 text-cyan-400"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 2.5C12 2.5 5.5 10 5.5 14.5C5.5 18.0899 8.41015 21 12 21C15.5899 21 18.5 18.0899 18.5 14.5C18.5 10 12 2.5 12 2.5Z"
                      fill="url(#h2uk-grad)"
                    />
                    <path
                      d="M12 7V16M9 12H15"
                      stroke="#FFFFFF"
                      strokeWidth="2"
                      strokeLinecap="round"
                    />
                    <defs>
                      <linearGradient id="h2uk-grad" x1="5.5" y1="2.5" x2="18.5" y2="21" gradientUnits="userSpaceOnUse">
                        <stop stopColor="#00C2CB" />
                        <stop offset="0.6" stopColor="#0099FF" />
                        <stop offset="1" stopColor="#10B981" />
                      </linearGradient>
                    </defs>
                  </svg>
                </div>
              </div>

              {/* Text Lockup */}
              <div className="flex items-center gap-3">
                <span className="text-2xl font-black tracking-tight text-white font-sans flex items-baseline">
                  H<span className="text-cyan-400">2</span>UK
                </span>
                <span className="hidden sm:inline-block h-5 w-[1.5px] bg-slate-600" aria-hidden="true" />
                <span className="hidden sm:inline-flex flex-col text-[10px] font-bold tracking-widest text-slate-300 uppercase leading-tight">
                  <span>CLEAN ENERGY.</span>
                  <span className="text-cyan-400">BRITISH SUPPLY.</span>
                </span>
              </div>
            </Link>

            {/* Zone 2: Navigation Links with Accessible Dropdowns */}
            <nav className="hidden lg:flex items-center gap-1 text-sm font-medium text-slate-200">
              {/* Home */}
              <Link
                href="/"
                className={`relative px-3.5 py-2 rounded-lg transition-colors hover:text-white whitespace-nowrap shrink-0 ${
                  pathname === '/' ? 'text-white font-semibold' : 'text-slate-300'
                }`}
              >
                Home
                {pathname === '/' && (
                  <span className="absolute bottom-0 left-3 right-3 h-0.5 bg-cyan-400 rounded-full" />
                )}
              </Link>

              {/* For Homes */}
              <div
                className="relative"
                onMouseEnter={() => setActiveDropdown('homes')}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <Link
                  href="/for-homes"
                  className={`flex items-center gap-1 px-3.5 py-2 rounded-lg transition-colors hover:text-white whitespace-nowrap shrink-0 ${
                    pathname.startsWith('/for-homes') ? 'text-cyan-400 font-semibold' : 'text-slate-300'
                  }`}
                >
                  For Homes
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${activeDropdown === 'homes' ? 'rotate-180' : ''}`} />
                </Link>

                {activeDropdown === 'homes' && (
                  <div className="absolute top-full left-0 w-72 bg-[#0F223A] border border-slate-700/80 rounded-xl shadow-2xl p-2.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                    <Link
                      href="/for-homes"
                      className="block p-2.5 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white">Domestic Overview</div>
                      <div className="text-xs text-slate-400 mt-0.5">Realistic applications, heating & backup power</div>
                    </Link>
                    <Link
                      href="/for-homes#suitability"
                      className="block p-2.5 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white">Suitability Assessment</div>
                      <div className="text-xs text-slate-400 mt-0.5">Appliance compatibility & regional trials</div>
                    </Link>
                    <Link
                      href="/quote?sector=household"
                      className="block p-2.5 rounded-lg bg-cyan-500/10 border border-cyan-500/20 hover:bg-cyan-500/20 transition-colors mt-1"
                    >
                      <div className="text-xs font-semibold text-cyan-300 flex items-center justify-between">
                        <span>Check Domestic Pilot Eligibility</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    </Link>
                  </div>
                )}
              </div>

              {/* For Businesses */}
              <div
                className="relative"
                onMouseEnter={() => setActiveDropdown('businesses')}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <Link
                  href="/for-businesses"
                  className={`flex items-center gap-1 px-3.5 py-2 rounded-lg transition-colors hover:text-white whitespace-nowrap shrink-0 ${
                    pathname.startsWith('/for-businesses') ? 'text-cyan-400 font-semibold' : 'text-slate-300'
                  }`}
                >
                  For Businesses
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${activeDropdown === 'businesses' ? 'rotate-180' : ''}`} />
                </Link>

                {activeDropdown === 'businesses' && (
                  <div className="absolute top-full left-0 w-80 bg-[#0F223A] border border-slate-700/80 rounded-xl shadow-2xl p-2.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                    <Link
                      href="/for-businesses"
                      className="block p-2.5 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white">Commercial Energy Supply</div>
                      <div className="text-xs text-slate-400 mt-0.5">Commercial heating, backup generators & CHP</div>
                    </Link>
                    <Link
                      href="/transport"
                      className="block p-2.5 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white">Transport & Logistics Fleet</div>
                      <div className="text-xs text-slate-400 mt-0.5">Heavy transport, HGVs & depot bunkering</div>
                    </Link>
                    <Link
                      href="/industry"
                      className="block p-2.5 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white">Heavy Industry & Feedstock</div>
                      <div className="text-xs text-slate-400 mt-0.5">High-temperature process heat & chemicals</div>
                    </Link>
                  </div>
                )}
              </div>

              {/* Our Supply */}
              <div
                className="relative"
                onMouseEnter={() => setActiveDropdown('supply')}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <Link
                  href="/our-supply"
                  className={`flex items-center gap-1 px-3.5 py-2 rounded-lg transition-colors hover:text-white whitespace-nowrap shrink-0 ${
                    pathname.startsWith('/our-supply') ? 'text-cyan-400 font-semibold' : 'text-slate-300'
                  }`}
                >
                  Our Supply
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${activeDropdown === 'supply' ? 'rotate-180' : ''}`} />
                </Link>

                {activeDropdown === 'supply' && (
                  <div className="absolute top-full left-0 w-80 bg-[#0F223A] border border-slate-700/80 rounded-xl shadow-2xl p-2.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                    <Link
                      href="/our-supply#gaseous"
                      className="block p-2.5 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white">Gaseous Hydrogen (GH2)</div>
                      <div className="text-xs text-slate-400 mt-0.5">200–500 bar tube trailers and cylinder packs</div>
                    </Link>
                    <Link
                      href="/our-supply#liquid"
                      className="block p-2.5 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white">Liquid Hydrogen (LH2)</div>
                      <div className="text-xs text-slate-400 mt-0.5">Cryogenic -253°C bulk storage & high-volume supply</div>
                    </Link>
                    <Link
                      href="/sustainability"
                      className="block p-2.5 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white">Carbon Intensity & LCHS</div>
                      <div className="text-xs text-slate-400 mt-0.5">UK Low Carbon Hydrogen Standard compliance</div>
                    </Link>
                  </div>
                )}
              </div>

              {/* About Us */}
              <div
                className="relative"
                onMouseEnter={() => setActiveDropdown('about')}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <Link
                  href="/about"
                  className={`flex items-center gap-1 px-3.5 py-2 rounded-lg transition-colors hover:text-white whitespace-nowrap shrink-0 ${
                    pathname.startsWith('/about') ? 'text-cyan-400 font-semibold' : 'text-slate-300'
                  }`}
                >
                  About Us
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${activeDropdown === 'about' ? 'rotate-180' : ''}`} />
                </Link>

                {activeDropdown === 'about' && (
                  <div className="absolute top-full left-0 w-72 bg-[#0F223A] border border-slate-700/80 rounded-xl shadow-2xl p-2.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                    <Link
                      href="/about"
                      className="block p-2.5 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white">The H2UK Vision</div>
                      <div className="text-xs text-slate-400 mt-0.5">British sovereign clean energy supply</div>
                    </Link>
                    <Link
                      href="/safety"
                      className="block p-2.5 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white">Safety & Technical Standards</div>
                      <div className="text-xs text-slate-400 mt-0.5">DSEAR, ATEX, HSE & IGEM compliance</div>
                    </Link>
                    <Link
                      href="/contact"
                      className="block p-2.5 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="text-sm font-semibold text-white">Contact & UK Offices</div>
                      <div className="text-xs text-slate-400 mt-0.5">Commercial enquiry desk & support</div>
                    </Link>
                  </div>
                )}
              </div>

              {/* News & Insights */}
              <Link
                href="/news"
                className={`px-3.5 py-2 rounded-lg transition-colors hover:text-white whitespace-nowrap shrink-0 ${
                  pathname.startsWith('/news') ? 'text-white font-semibold' : 'text-slate-300'
                }`}
              >
                News & Insights
              </Link>
            </nav>

            {/* Zone 3: Search & Primary Action */}
            <div className="flex items-center gap-3 shrink-0">
              {/* Search Button */}
              <button
                onClick={() => setIsSearchOpen(true)}
                className="p-2.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
                aria-label="Search H2UK site"
                title="Search site (Cmd+K)"
              >
                <Search className="w-5 h-5" />
              </button>

              {/* Primary CTA Button: Get a Quote */}
              <Link
                href="/quote"
                className="hidden sm:inline-flex items-center justify-center px-5 py-2.5 text-sm font-semibold text-white bg-[#0099FF] hover:bg-[#0088EE] active:bg-[#0077DD] rounded-full shadow-md shadow-sky-500/25 transition-all duration-150 hover:shadow-sky-500/40 hover:-translate-y-0.5 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300"
              >
                Get a Quote
              </Link>

              {/* Admin Portal quick link */}
              <Link
                href="/admin"
                className="hidden xl:inline-flex items-center px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white border border-slate-700/80 hover:border-slate-500 rounded-lg transition-colors whitespace-nowrap shrink-0"
                title="Internal Commercial Lead Management"
              >
                Portal
              </Link>

              {/* Mobile Menu Toggle */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 text-slate-300 hover:text-white rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
                aria-label="Toggle Navigation Menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#0A1628] border-b border-slate-800 px-4 pt-3 pb-6 space-y-3">
            <div className="grid grid-cols-2 gap-2 pb-3 border-b border-slate-800">
              <Link
                href="/"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 text-sm font-medium text-white hover:bg-white/5 rounded-lg"
              >
                Home
              </Link>
              <Link
                href="/for-homes"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 text-sm font-medium text-slate-300 hover:bg-white/5 rounded-lg"
              >
                For Homes
              </Link>
              <Link
                href="/for-businesses"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 text-sm font-medium text-slate-300 hover:bg-white/5 rounded-lg"
              >
                For Businesses
              </Link>
              <Link
                href="/industry"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 text-sm font-medium text-slate-300 hover:bg-white/5 rounded-lg"
              >
                Heavy Industry
              </Link>
              <Link
                href="/transport"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 text-sm font-medium text-slate-300 hover:bg-white/5 rounded-lg"
              >
                Transport & Fleets
              </Link>
              <Link
                href="/our-supply"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 text-sm font-medium text-slate-300 hover:bg-white/5 rounded-lg"
              >
                Our Supply
              </Link>
              <Link
                href="/about"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 text-sm font-medium text-slate-300 hover:bg-white/5 rounded-lg"
              >
                About Us
              </Link>
              <Link
                href="/news"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 text-sm font-medium text-slate-300 hover:bg-white/5 rounded-lg"
              >
                News & Insights
              </Link>
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <Link
                href="/quote"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full text-center py-3 text-sm font-semibold text-white bg-[#0099FF] rounded-full shadow-md"
              >
                Get a Quote
              </Link>
              <div className="flex gap-2">
                <Link
                  href="/admin"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex-1 text-center py-2 text-xs font-medium text-slate-300 border border-slate-700 rounded-lg"
                >
                  Commercial Admin
                </Link>
                <Link
                  href="/contact"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex-1 text-center py-2 text-xs font-medium text-slate-300 border border-slate-700 rounded-lg"
                >
                  Contact Desk
                </Link>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Global Interactive Search Modal */}
      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
    </>
  );
}
