import React from 'react';
import Link from 'next/link';
import { ArrowUpRight } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="w-full bg-[#081220] border-t border-slate-800 text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-8 pb-12 border-b border-slate-800/80">
          {/* Col 1: Brand & Mission */}
          <div className="lg:col-span-2 space-y-4">
            <Link href="/" className="inline-flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-400 via-sky-500 to-emerald-500 p-0.5">
                <div className="w-full h-full bg-[#0B192C] rounded-[10px] flex items-center justify-center">
                  <span className="text-cyan-400 font-bold text-sm">H₂</span>
                </div>
              </div>
              <span className="text-2xl font-black text-white tracking-tight font-sans">
                H<span className="text-cyan-400">2</span>UK
              </span>
            </Link>

            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm">
              Britain&apos;s hydrogen supply partner. Delivering high-purity gaseous and liquid hydrogen for transport operators, commercial businesses, industry, and suitable domestic pilots.
            </p>

            <div className="pt-2 text-xs text-slate-400 space-y-1">
              <div><strong className="text-slate-300">Commercial Enquiries:</strong> enquiries@h2uk.energy</div>
              <div><strong className="text-slate-300">Technical Dispatch:</strong> 0800 422 4228 (UK Commercial Desk)</div>
            </div>
          </div>

          {/* Col 2: Sectors */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Sectors</h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <Link href="/for-homes" className="hover:text-cyan-400 transition-colors">
                  For Homes
                </Link>
              </li>
              <li>
                <Link href="/for-businesses" className="hover:text-cyan-400 transition-colors">
                  For Businesses
                </Link>
              </li>
              <li>
                <Link href="/transport" className="hover:text-cyan-400 transition-colors">
                  Transport Fleets
                </Link>
              </li>
              <li>
                <Link href="/industry" className="hover:text-cyan-400 transition-colors">
                  Heavy Industry
                </Link>
              </li>
              <li>
                <Link href="/quote" className="text-cyan-400 font-semibold hover:text-cyan-300 transition-colors">
                  Request a Quote →
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Supply & Safety */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Supply & Standards</h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <Link href="/our-supply#gaseous" className="hover:text-cyan-400 transition-colors">
                  Gaseous Hydrogen (GH2)
                </Link>
              </li>
              <li>
                <Link href="/our-supply#liquid" className="hover:text-cyan-400 transition-colors">
                  Liquid Hydrogen (LH2)
                </Link>
              </li>
              <li>
                <Link href="/safety" className="hover:text-cyan-400 transition-colors">
                  Safety & DSEAR Regulations
                </Link>
              </li>
              <li>
                <Link href="/sustainability" className="hover:text-cyan-400 transition-colors">
                  Low Carbon Standard (LCHS)
                </Link>
              </li>
              <li>
                <Link href="/faqs" className="hover:text-cyan-400 transition-colors">
                  Frequently Asked Questions
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 4: Corporate & Portal */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Company</h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <Link href="/about" className="hover:text-cyan-400 transition-colors">
                  About H2UK
                </Link>
              </li>
              <li>
                <Link href="/news" className="hover:text-cyan-400 transition-colors">
                  News & Market Insights
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-cyan-400 transition-colors">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/admin" className="text-slate-400 hover:text-white transition-colors inline-flex items-center gap-1">
                  <span>Commercial Lead Portal</span>
                  <ArrowUpRight className="w-3 h-3" />
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Regulatory Disclaimer */}
        <div className="py-6 border-b border-slate-800 text-[11px] sm:text-xs text-slate-400 leading-relaxed">
          <p>
            <strong>Regulatory & Siting Disclosure:</strong> Hydrogen supply is subject to regional distribution corridor availability, verified site hazardous zoning (DSEAR 2002), ATEX ratings, and appliance suitability checks. Hydrogen heating for ordinary domestic properties is subject to ongoing UK Government (DESNZ) trial timelines and local distribution trials. Quotations provided through this platform constitute preliminary commercial planning figures and do not bind H2UK to supply until formal engineering review and site hazard assessments are executed.
          </p>
        </div>

        {/* Bottom Bar: Copyright & Legal */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            © {currentYear} H2UK Energy Solutions. All rights reserved. Registered in the United Kingdom.
          </div>

          <div className="flex flex-wrap items-center gap-6">
            <Link href="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link>
            <Link href="/cookies" className="hover:text-white transition-colors">Cookie Policy</Link>
            <Link href="/terms" className="hover:text-white transition-colors">Terms & Conditions</Link>
            <Link href="/accessibility" className="hover:text-white transition-colors">Accessibility Statement</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
