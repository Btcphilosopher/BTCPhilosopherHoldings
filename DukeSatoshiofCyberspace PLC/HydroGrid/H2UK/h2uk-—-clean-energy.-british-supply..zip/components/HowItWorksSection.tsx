import React from 'react';
import Link from 'next/link';
import { ClipboardList, Cpu, Calculator, ShieldCheck, ArrowRight, AlertCircle } from 'lucide-react';

const STEPS = [
  {
    step: '01',
    title: 'Tell us about your requirements',
    description: 'Submit your expected demand volume, operating frequency, required purity specifications, and facility postcode via our structured quotation engine.',
    icon: <ClipboardList className="w-6 h-6 text-cyan-600" />,
  },
  {
    step: '02',
    title: 'Discuss technical and supply feasibility',
    description: 'An H2UK commercial engineer evaluates offloading access, pressure reduction, ATEX/DSEAR zoning requirements, and regional distribution corridor availability.',
    icon: <Cpu className="w-6 h-6 text-sky-600" />,
  },
  {
    step: '03',
    title: 'Receive a tailored quotation',
    description: 'Get transparent commercial pricing encompassing production pathway, cryogenic or tube trailer logistics, telemetry monitoring, and standing facility arrangements.',
    icon: <Calculator className="w-6 h-6 text-emerald-600" />,
  },
  {
    step: '04',
    title: 'Agree an approved supply arrangement',
    description: 'Finalize approved supply schedules, dispatch protocols, and telemetry linkages with verified low-carbon compliance documentation.',
    icon: <ShieldCheck className="w-6 h-6 text-cyan-600" />,
  },
];

export default function HowItWorksSection() {
  return (
    <section className="w-full bg-[#F8FAFC] py-16 sm:py-24 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-xs font-bold tracking-[0.2em] text-[#0099FF] uppercase">
            Transparent Commercial Process
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            How H2UK Supply Works
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            From preliminary technical sizing to regular scheduled deliveries, we maintain complete transparency across every stage of the supply chain.
          </p>
        </div>

        {/* 4-Step Process Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-14">
          {STEPS.map((step) => (
            <div
              key={step.step}
              className="bg-white rounded-2xl p-6 sm:p-7 border border-slate-200 shadow-sm relative flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-5">
                  <div className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center">
                    {step.icon}
                  </div>
                  <span className="text-3xl font-black text-slate-300 font-mono">
                    {step.step}
                  </span>
                </div>

                <h3 className="text-base sm:text-lg font-bold text-slate-900 mb-2 leading-snug">
                  {step.title}
                </h3>

                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {step.description}
                </p>
              </div>

              <div className="pt-4 mt-6 border-t border-slate-100">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Phase {step.step}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Regulatory Governance Note */}
        <div className="mt-10 p-4 sm:p-5 bg-sky-50/70 border border-sky-200/80 rounded-xl flex items-start gap-3 max-w-4xl mx-auto">
          <AlertCircle className="w-5 h-5 text-sky-700 shrink-0 mt-0.5" />
          <div className="text-xs sm:text-sm text-sky-900 leading-relaxed">
            <strong>Supply & Feasibility Notice:</strong> Submitting an enquiry does not guarantee supply or confirm technical suitability. All commercial supply arrangements require formal hazard reviews, site accessibility approval, and regional hydrogen allocation compliance.
          </div>
        </div>

        <div className="text-center mt-8">
          <Link
            href="/quote"
            className="inline-flex items-center gap-2 px-7 py-3 text-sm font-semibold text-white bg-[#0099FF] hover:bg-[#0088EE] rounded-full shadow-md shadow-sky-500/25 transition-transform hover:-translate-y-0.5"
          >
            <span>Start Your Quotation Assessment</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
