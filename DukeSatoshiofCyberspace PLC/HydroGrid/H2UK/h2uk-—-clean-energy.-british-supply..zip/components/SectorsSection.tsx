import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight, Home, Building2, Truck, Factory } from 'lucide-react';

interface SectorCardProps {
  title: string;
  tagline: string;
  imageSrc: string;
  href: string;
  icon: React.ReactNode;
}

const SECTORS: SectorCardProps[] = [
  {
    title: 'Homes',
    tagline: 'Heating, cooking and cleaner living.',
    imageSrc: '/images/sector_homes.jpg',
    href: '/for-homes',
    icon: <Home className="w-5 h-5 text-white" />,
  },
  {
    title: 'Businesses',
    tagline: 'Reliable energy for growth and efficiency.',
    imageSrc: '/images/sector_business.jpg',
    href: '/for-businesses',
    icon: <Building2 className="w-5 h-5 text-white" />,
  },
  {
    title: 'Transport',
    tagline: 'Fuel for a cleaner, stronger future.',
    imageSrc: '/images/sector_transport.jpg',
    href: '/transport',
    icon: <Truck className="w-5 h-5 text-white" />,
  },
  {
    title: 'Industry',
    tagline: 'Powering UK industry with clean hydrogen.',
    imageSrc: '/images/sector_industry.jpg',
    href: '/industry',
    icon: <Factory className="w-5 h-5 text-white" />,
  },
];

export default function SectorsSection() {
  return (
    <section className="w-full bg-[#F8FAFC] py-16 sm:py-24 border-b border-slate-200" id="solutions">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* Left Column: Heading and Narrative */}
          <div className="lg:col-span-4 space-y-5 lg:sticky lg:top-28">
            <div className="inline-flex items-center gap-2">
              <span className="text-xs font-bold tracking-[0.2em] text-[#0099FF] uppercase">
                Our Solutions
              </span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-[2.65rem] font-black text-slate-900 tracking-tight leading-[1.12]">
              Hydrogen for <br className="hidden sm:inline" />
              every sector
            </h2>

            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              From homes to heavy industry, we deliver clean, flexible hydrogen solutions that power your needs — today and tomorrow.
            </p>

            <div className="pt-2">
              <Link
                href="/our-supply"
                className="inline-flex items-center gap-2 px-6 py-2.5 text-sm font-semibold text-[#0099FF] hover:text-[#0088EE] border border-[#0099FF] hover:border-[#0088EE] bg-white hover:bg-sky-50 rounded-full transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400"
              >
                <span>Explore all sectors</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          {/* Right Column: 4-Card Sector Grid */}
          <div className="lg:col-span-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {SECTORS.map((sector) => (
                <div
                  key={sector.title}
                  className="group bg-white rounded-2xl overflow-hidden border border-slate-200/90 shadow-sm hover:shadow-xl transition-all duration-200 flex flex-col hover:-translate-y-1"
                >
                  {/* Card Image */}
                  <div className="relative aspect-[4/3] w-full bg-slate-100 overflow-hidden">
                    <Image
                      src={sector.imageSrc}
                      alt={`H2UK supply for ${sector.title}`}
                      fill
                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  {/* Card Body */}
                  <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Icon & Title */}
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 rounded-lg bg-[#0099FF] flex items-center justify-center shrink-0 shadow-sm">
                          {sector.icon}
                        </div>
                        <h3 className="text-lg font-bold text-slate-900 group-hover:text-[#0099FF] transition-colors">
                          {sector.title}
                        </h3>
                      </div>

                      {/* Tagline */}
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-4">
                        {sector.tagline}
                      </p>
                    </div>

                    {/* Working Action Link */}
                    <Link
                      href={sector.href}
                      className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-[#0099FF] hover:text-sky-700 transition-colors pt-2 border-t border-slate-100 mt-auto group-hover:translate-x-0.5"
                    >
                      <span>Find out more</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
