import { QuotationEnquiry, EmailLogEntry } from '../db/types';
import { logEmail } from '../db/store';

export interface EmailDispatchResult {
  success: boolean;
  mode: 'demo_simulation' | 'smtp_live';
  customerEmailId?: string;
  internalEmailId?: string;
  error?: string;
}

/**
 * Transactional Email Adapter for H2UK
 * Dispatches formal customer confirmation & internal commercial alerts.
 * In development / demo environments without production SMTP credentials,
 * it safely records and logs structured emails into the database for admin inspection.
 */
export async function sendEnquiryEmails(enquiry: QuotationEnquiry): Promise<EmailDispatchResult> {
  const isProductionSmtpConfigured = Boolean(process.env.SMTP_HOST && process.env.SMTP_USER);

  const customerHtml = `
    <!DOCTYPE html>
    <html>
    <head><meta charset="utf-8"><title>H2UK Enquiry Confirmation</title></head>
    <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #0F172A; max-width: 600px; margin: 0 auto; padding: 24px;">
      <div style="border-bottom: 2px solid #0099FF; padding-bottom: 16px; margin-bottom: 24px;">
        <h1 style="color: #0B192C; margin: 0; font-size: 24px; font-weight: 700;">H2UK</h1>
        <p style="color: #0099FF; font-size: 13px; margin: 4px 0 0 0; text-transform: uppercase; letter-spacing: 1px;">Clean Energy. British Supply.</p>
      </div>

      <p>Dear ${enquiry.contact.fullName},</p>
      <p>Thank you for submitting your hydrogen supply enquiry. We have logged your request under reference <strong>${enquiry.referenceNumber}</strong>.</p>

      <div style="background-color: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 16px; margin: 20px 0;">
        <h3 style="margin-top: 0; font-size: 15px; color: #0B192C;">Enquiry Summary</h3>
        <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
          <tr><td style="padding: 4px 0; color: #64748B;">Reference:</td><td style="font-weight: 600;">${enquiry.referenceNumber}</td></tr>
          <tr><td style="padding: 4px 0; color: #64748B;">Sector:</td><td style="text-transform: capitalize;">${enquiry.customerType}</td></tr>
          <tr><td style="padding: 4px 0; color: #64748B;">Format:</td><td style="text-transform: capitalize;">${enquiry.supplyFormat} Hydrogen</td></tr>
          <tr><td style="padding: 4px 0; color: #64748B;">Estimated Demand:</td><td>${enquiry.estimatedVolume} ${enquiry.volumeUnit}</td></tr>
          <tr><td style="padding: 4px 0; color: #64748B;">Location:</td><td>Postcode ${enquiry.postcode}</td></tr>
          <tr><td style="padding: 4px 0; color: #64748B;">Current Status:</td><td style="color: #0284C7; font-weight: 600;">Received (Technical Review)</td></tr>
        </table>
      </div>

      <p style="font-size: 13px; color: #475569;">
        <em>Regulatory note:</em> Quotations are subject to site hazard verification (DSEAR/ATEX) and regional logistics scheduling. An enquiry does not constitute an operational guarantee of supply.
      </p>

      <p>An H2UK commercial engineer will review your site and specification details within 1–2 business days.</p>

      <p style="margin-top: 32px; font-size: 13px; color: #64748B; border-top: 1px solid #E2E8F0; padding-top: 16px;">
        H2UK Hydrogen Commercial Services<br/>
        Clean Energy. British Supply.
      </p>
    </body>
    </html>
  `;

  const internalHtml = `
    <!DOCTYPE html>
    <html>
    <head><meta charset="utf-8"><title>New H2UK Commercial Lead</title></head>
    <body style="font-family: -apple-system, sans-serif; color: #0F172A; max-width: 600px; padding: 24px;">
      <h2 style="color: #0B192C; margin-top: 0;">⚡ New Hydrogen Supply Lead</h2>
      <p><strong>Ref:</strong> ${enquiry.referenceNumber} | <strong>Sector:</strong> ${enquiry.customerType.toUpperCase()}</p>
      <p><strong>Contact:</strong> ${enquiry.contact.fullName} (${enquiry.contact.companyName || 'Private'}) &lt;${enquiry.contact.email}&gt; | ${enquiry.contact.phone}</p>
      <p><strong>Format & Demand:</strong> ${enquiry.supplyFormat.toUpperCase()} — ${enquiry.estimatedVolume} ${enquiry.volumeUnit} (${enquiry.frequency})</p>
      <p><strong>Location Postcode:</strong> ${enquiry.postcode}</p>
      <p><strong>Application:</strong> ${enquiry.application}</p>
      <hr style="border: 0; border-top: 1px solid #E2E8F0; margin: 16px 0;" />
      <p><a href="/admin" style="background-color: #0099FF; color: white; padding: 8px 16px; text-decoration: none; border-radius: 6px; display: inline-block;">Open in H2UK Admin Portal</a></p>
    </body>
    </html>
  `;

  // Always log into persistent store for full auditability
  const customerLog = logEmail({
    enquiryRef: enquiry.referenceNumber,
    recipient: enquiry.contact.email,
    type: 'customer_confirmation',
    subject: `H2UK Supply Quotation Enquiry Confirmed — [Ref: ${enquiry.referenceNumber}]`,
    status: isProductionSmtpConfigured ? 'delivered_live' : 'delivered_mock',
    htmlPreview: customerHtml,
  });

  const internalLog = logEmail({
    enquiryRef: enquiry.referenceNumber,
    recipient: 'commercial-desk@h2uk.energy',
    type: 'internal_notification',
    subject: `[LEAD: ${enquiry.customerType.toUpperCase()}] ${enquiry.contact.companyName || enquiry.contact.fullName} — ${enquiry.referenceNumber}`,
    status: isProductionSmtpConfigured ? 'delivered_live' : 'delivered_mock',
    htmlPreview: internalHtml,
  });

  return {
    success: true,
    mode: isProductionSmtpConfigured ? 'smtp_live' : 'demo_simulation',
    customerEmailId: customerLog.id,
    internalEmailId: internalLog.id,
  };
}
