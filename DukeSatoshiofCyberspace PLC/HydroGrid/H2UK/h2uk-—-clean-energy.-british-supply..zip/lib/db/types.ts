export type CustomerType = 'household' | 'business' | 'industry' | 'transport';
export type SupplyFormat = 'gaseous' | 'liquid' | 'unsure';
export type VolumeUnit = 'kg/day' | 'Nm3/hr' | 'tonnes/month' | 'MWh/year' | 'cylinders/month';
export type SupplyFrequency = 'scheduled_recurring' | 'one_off' | 'continuous_pipeline' | 'pilot_trial';

export type EnquiryStatus = 'received' | 'under_review' | 'clarification_required' | 'quoted' | 'closed';

export interface InternalNote {
  id: string;
  author: string;
  content: string;
  createdAt: string;
}

export interface AuditEvent {
  action: string;
  performedBy: string;
  timestamp: string;
  details?: string;
}

export interface QuotationEnquiry {
  id: string;
  referenceNumber: string; // e.g. H2UK-2026-1042
  customerType: CustomerType;
  supplyFormat: SupplyFormat;
  application: string;
  estimatedVolume: string;
  volumeUnit: VolumeUnit;
  frequency: SupplyFrequency;
  postcode: string;
  siteDetails: {
    hasStorageSpace?: boolean;
    atexZoned?: boolean;
    offloadingAccess?: string;
    currentEnergySource?: string;
    fleetSize?: number;
    vehicleType?: string;
    purityRequired?: string;
    targetStartDate?: string;
  };
  contact: {
    fullName: string;
    companyName?: string;
    email: string;
    phone: string;
    jobTitle?: string;
    preferredContact: 'email' | 'phone';
    additionalNotes?: string;
    consentTerms: boolean;
  };
  status: EnquiryStatus;
  internalNotes: InternalNote[];
  auditLog: AuditEvent[];
  createdAt: string;
  updatedAt: string;
}

export interface ContactMessage {
  id: string;
  fullName: string;
  email: string;
  phone?: string;
  company?: string;
  subject: string;
  message: string;
  status: 'new' | 'in_progress' | 'resolved';
  createdAt: string;
}

export interface EmailLogEntry {
  id: string;
  enquiryRef: string;
  recipient: string;
  type: 'customer_confirmation' | 'internal_notification';
  subject: string;
  status: 'delivered_mock' | 'delivered_live' | 'failed';
  dispatchedAt: string;
  htmlPreview: string;
}
