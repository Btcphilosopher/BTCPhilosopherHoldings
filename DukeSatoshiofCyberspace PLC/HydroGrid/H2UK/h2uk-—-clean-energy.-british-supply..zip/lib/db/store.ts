import fs from 'fs';
import path from 'path';
import { QuotationEnquiry, ContactMessage, EmailLogEntry, EnquiryStatus, InternalNote } from './types';

// Pre-seeded synthetic records representing realistic UK enquiries
const INITIAL_ENQUIRIES: QuotationEnquiry[] = [
  {
    id: 'enq-001',
    referenceNumber: 'H2UK-2026-8041',
    customerType: 'industry',
    supplyFormat: 'gaseous',
    application: 'High-temperature glass annealing furnaces and oxygen-hydrogen combustion burner conversion',
    estimatedVolume: '1450',
    volumeUnit: 'kg/day',
    frequency: 'scheduled_recurring',
    postcode: 'S9 1XH', // Sheffield, Industrial District
    siteDetails: {
      hasStorageSpace: true,
      atexZoned: true,
      offloadingAccess: 'Designated hazardous goods bay with dual-articulated trailer turning circle',
      purityRequired: 'Grade 5.0 (99.999% purity) with <1ppm moisture',
      currentEnergySource: 'Mains Natural Gas with high CO2 emissions',
      targetStartDate: 'Q3 2026',
    },
    contact: {
      fullName: 'Dr. Alistair Finch',
      companyName: 'Pennine Glass & Ceramics Ltd',
      jobTitle: 'Head of Decarbonisation & Plant Engineering',
      email: 'a.finch@pennineglass.co.uk',
      phone: '+44 114 290 8400',
      preferredContact: 'email',
      additionalNotes: 'Require technical feasibility consultation regarding tube-trailer manifold pressures and DSEAR site boundary clearances.',
      consentTerms: true,
    },
    status: 'under_review',
    internalNotes: [
      {
        id: 'note-01',
        author: 'Marcus Vance (Commercial Director)',
        content: 'Site survey scheduled for Sheffield facility next Tuesday. Evaluated against Humber corridor supply route.',
        createdAt: '2026-10-10T09:30:00Z',
      },
    ],
    auditLog: [
      {
        action: 'ENQUIRY_CREATED',
        performedBy: 'Customer Portal',
        timestamp: '2026-10-09T14:22:15Z',
      },
      {
        action: 'STATUS_UPDATED',
        performedBy: 'Marcus Vance',
        timestamp: '2026-10-10T09:30:00Z',
        details: 'Status changed from received to under_review',
      },
    ],
    createdAt: '2026-10-09T14:22:15Z',
    updatedAt: '2026-10-10T09:30:00Z',
  },
  {
    id: 'enq-002',
    referenceNumber: 'H2UK-2026-8042',
    customerType: 'transport',
    supplyFormat: 'liquid',
    application: 'Depot refuelling for 32 fuel-cell articulated heavy goods vehicles (HGVs)',
    estimatedVolume: '2200',
    volumeUnit: 'kg/day',
    frequency: 'scheduled_recurring',
    postcode: 'CV3 4PW', // Coventry, Midlands Freight Hub
    siteDetails: {
      hasStorageSpace: true,
      atexZoned: false,
      offloadingAccess: 'Concrete pad available, require cryogenic vacuum vessel installation',
      fleetSize: 32,
      vehicleType: '44-tonne Articulated HGVs (350/700 bar onboard storage)',
      targetStartDate: 'Q4 2026',
    },
    contact: {
      fullName: 'Sarah Jenkins CMILT',
      companyName: 'Mercia Logistics Network',
      jobTitle: 'Fleet Transition Director',
      email: 's.jenkins@mercialogistics.co.uk',
      phone: '+44 24 7689 3100',
      preferredContact: 'phone',
      additionalNotes: 'Interested in turnkey liquid bunkering solution with vaporization to 700 bar dispensing.',
      consentTerms: true,
    },
    status: 'quoted',
    internalNotes: [
      {
        id: 'note-02',
        author: 'Eleanor Brooks (Logistics Solutions Lead)',
        content: 'Issued preliminary supply agreement draft covering weekly LH2 deliveries from Teesside terminal.',
        createdAt: '2026-10-11T16:15:00Z',
      },
    ],
    auditLog: [
      {
        action: 'ENQUIRY_CREATED',
        performedBy: 'Customer Portal',
        timestamp: '2026-10-08T11:05:00Z',
      },
      {
        action: 'STATUS_UPDATED',
        performedBy: 'Eleanor Brooks',
        timestamp: '2026-10-11T16:15:00Z',
        details: 'Status changed from under_review to quoted',
      },
    ],
    createdAt: '2026-10-08T11:05:00Z',
    updatedAt: '2026-10-11T16:15:00Z',
  },
  {
    id: 'enq-003',
    referenceNumber: 'H2UK-2026-8043',
    customerType: 'business',
    supplyFormat: 'gaseous',
    application: 'Commercial greenhouse heating and CO2 enrichment combined heat and power system',
    estimatedVolume: '380',
    volumeUnit: 'kg/day',
    frequency: 'scheduled_recurring',
    postcode: 'PE11 3AB', // Lincolnshire Agritech
    siteDetails: {
      hasStorageSpace: true,
      atexZoned: true,
      offloadingAccess: 'Farm track widened to accept 40-foot flatbed tube trailers',
      currentEnergySource: 'LPG bulk tanks',
      targetStartDate: 'Q1 2027',
    },
    contact: {
      fullName: 'Gareth Edwards',
      companyName: 'Fenland Horticultural Holdings',
      jobTitle: 'Operations Manager',
      email: 'g.edwards@fenlandhort.co.uk',
      phone: '+44 1775 820 440',
      preferredContact: 'email',
      additionalNotes: 'Seeking to phase out fossil LPG before 2027 DEFRA agricultural compliance milestone.',
      consentTerms: true,
    },
    status: 'clarification_required',
    internalNotes: [
      {
        id: 'note-03',
        author: 'Marcus Vance',
        content: 'Awaiting local district network operator gas line proximity check.',
        createdAt: '2026-10-12T10:00:00Z',
      },
    ],
    auditLog: [
      {
        action: 'ENQUIRY_CREATED',
        performedBy: 'Customer Portal',
        timestamp: '2026-10-11T09:12:00Z',
      },
      {
        action: 'STATUS_UPDATED',
        performedBy: 'Marcus Vance',
        timestamp: '2026-10-12T10:00:00Z',
        details: 'Clarification requested regarding compressor feed requirements',
      },
    ],
    createdAt: '2026-10-11T09:12:00Z',
    updatedAt: '2026-10-12T10:00:00Z',
  },
  {
    id: 'enq-004',
    referenceNumber: 'H2UK-2026-8044',
    customerType: 'household',
    supplyFormat: 'gaseous',
    application: 'Off-grid residential estate microgrid backup power and hybrid hydrogen heating pilot',
    estimatedVolume: '15',
    volumeUnit: 'kg/day',
    frequency: 'pilot_trial',
    postcode: 'EH42 1XF', // East Lothian Coastal Community
    siteDetails: {
      hasStorageSpace: true,
      atexZoned: false,
      offloadingAccess: 'Private lane access for 7.5 tonne delivery vehicle',
      currentEnergySource: 'Heating Oil (Kerosene)',
      targetStartDate: 'Mid 2027',
    },
    contact: {
      fullName: 'Morag MacIntyre',
      email: 'm.macintyre@highlandborder.org',
      phone: '+44 1368 860 192',
      preferredContact: 'email',
      additionalNotes: 'Enquiring on behalf of 6 rural dwellings participating in community net-zero demonstration.',
      consentTerms: true,
    },
    status: 'received',
    internalNotes: [],
    auditLog: [
      {
        action: 'ENQUIRY_CREATED',
        performedBy: 'Customer Portal',
        timestamp: '2026-10-12T15:40:00Z',
      },
    ],
    createdAt: '2026-10-12T15:40:00Z',
    updatedAt: '2026-10-12T15:40:00Z',
  },
];

const INITIAL_MESSAGES: ContactMessage[] = [
  {
    id: 'msg-01',
    fullName: 'Robert Henderson',
    email: 'r.henderson@solway-marine.co.uk',
    company: 'Solway Maritime Services',
    phone: '+44 1387 770 210',
    subject: 'Hydrogen bunkering for coastal workboats',
    message: 'We are retrofitting two harbour tugs to hydrogen dual-fuel engines. We would like to discuss bunkering options in the Solway Firth area.',
    status: 'in_progress',
    createdAt: '2026-10-11T14:10:00Z',
  },
];

const INITIAL_EMAIL_LOGS: EmailLogEntry[] = [
  {
    id: 'eml-01',
    enquiryRef: 'H2UK-2026-8041',
    recipient: 'a.finch@pennineglass.co.uk',
    type: 'customer_confirmation',
    subject: 'H2UK Enquiry Confirmation — Ref: H2UK-2026-8041',
    status: 'delivered_mock',
    dispatchedAt: '2026-10-09T14:22:16Z',
    htmlPreview: '<p>Thank you Dr. Finch. Your hydrogen supply enquiry has been received by H2UK Engineering team.</p>',
  },
  {
    id: 'eml-02',
    enquiryRef: 'H2UK-2026-8041',
    recipient: 'commercial-leads@h2uk-energy.co.uk',
    type: 'internal_notification',
    subject: '[NEW LEAD - INDUSTRY] Pennine Glass & Ceramics Ltd — 1450 kg/day',
    status: 'delivered_mock',
    dispatchedAt: '2026-10-09T14:22:16Z',
    htmlPreview: '<p>New industrial hydrogen lead received from Sheffield (S9 1XH).</p>',
  },
];

// Persistent state singleton
interface DbState {
  enquiries: QuotationEnquiry[];
  messages: ContactMessage[];
  emailLogs: EmailLogEntry[];
}

const DATA_DIR = path.join(process.cwd(), '.data');
const DATA_FILE = path.join(DATA_DIR, 'h2uk_store.json');

function loadState(): DbState {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.enquiries)) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Could not read persistent file, fallback to initial state', err);
  }

  return {
    enquiries: [...INITIAL_ENQUIRIES],
    messages: [...INITIAL_MESSAGES],
    emailLogs: [...INITIAL_EMAIL_LOGS],
  };
}

function saveState(state: DbState) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(state, null, 2), 'utf-8');
  } catch (err) {
    console.warn('Could not write persistent file', err);
  }
}

// In-memory reference initialized once per server lifecycle
let globalState: DbState = loadState();

export function getEnquiries(): QuotationEnquiry[] {
  return [...globalState.enquiries].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export function getEnquiryByRef(ref: string): QuotationEnquiry | undefined {
  return globalState.enquiries.find(e => e.referenceNumber.toLowerCase() === ref.toLowerCase() || e.id === ref);
}

export function createEnquiry(payload: Omit<QuotationEnquiry, 'id' | 'referenceNumber' | 'status' | 'internalNotes' | 'auditLog' | 'createdAt' | 'updatedAt'>): QuotationEnquiry {
  const now = new Date().toISOString();
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const year = new Date().getFullYear();
  const referenceNumber = `H2UK-${year}-${randomSuffix}`;
  const id = `enq-${Date.now()}`;

  const newEnquiry: QuotationEnquiry = {
    ...payload,
    id,
    referenceNumber,
    status: 'received',
    internalNotes: [],
    auditLog: [
      {
        action: 'ENQUIRY_CREATED',
        performedBy: payload.contact.fullName,
        timestamp: now,
        details: `Created online quotation request for ${payload.customerType} supply (${payload.supplyFormat})`,
      },
    ],
    createdAt: now,
    updatedAt: now,
  };

  globalState.enquiries.unshift(newEnquiry);
  saveState(globalState);
  return newEnquiry;
}

export function updateEnquiryStatus(idOrRef: string, newStatus: EnquiryStatus, author: string, note?: string): QuotationEnquiry | null {
  const enquiry = globalState.enquiries.find(e => e.id === idOrRef || e.referenceNumber === idOrRef);
  if (!enquiry) return null;

  const prevStatus = enquiry.status;
  enquiry.status = newStatus;
  enquiry.updatedAt = new Date().toISOString();

  enquiry.auditLog.push({
    action: 'STATUS_UPDATED',
    performedBy: author,
    timestamp: enquiry.updatedAt,
    details: `Status updated from ${prevStatus} to ${newStatus}${note ? `: ${note}` : ''}`,
  });

  if (note) {
    enquiry.internalNotes.push({
      id: `note-${Date.now()}`,
      author,
      content: note,
      createdAt: enquiry.updatedAt,
    });
  }

  saveState(globalState);
  return enquiry;
}

export function addEnquiryNote(idOrRef: string, author: string, content: string): QuotationEnquiry | null {
  const enquiry = globalState.enquiries.find(e => e.id === idOrRef || e.referenceNumber === idOrRef);
  if (!enquiry) return null;

  const now = new Date().toISOString();
  enquiry.internalNotes.push({
    id: `note-${Date.now()}`,
    author,
    content,
    createdAt: now,
  });

  enquiry.auditLog.push({
    action: 'NOTE_ADDED',
    performedBy: author,
    timestamp: now,
  });

  enquiry.updatedAt = now;
  saveState(globalState);
  return enquiry;
}

export function createContactMessage(payload: Omit<ContactMessage, 'id' | 'status' | 'createdAt'>): ContactMessage {
  const msg: ContactMessage = {
    ...payload,
    id: `msg-${Date.now()}`,
    status: 'new',
    createdAt: new Date().toISOString(),
  };

  globalState.messages.unshift(msg);
  saveState(globalState);
  return msg;
}

export function getContactMessages(): ContactMessage[] {
  return [...globalState.messages].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export function logEmail(entry: Omit<EmailLogEntry, 'id' | 'dispatchedAt'>): EmailLogEntry {
  const fullEntry: EmailLogEntry = {
    ...entry,
    id: `eml-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    dispatchedAt: new Date().toISOString(),
  };

  globalState.emailLogs.unshift(fullEntry);
  saveState(globalState);
  return fullEntry;
}

export function getEmailLogs(): EmailLogEntry[] {
  return [...globalState.emailLogs].sort((a, b) => new Date(b.dispatchedAt).getTime() - new Date(a.dispatchedAt).getTime());
}
