import React from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function AccessibilityPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />
      <main className="flex-1 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <span className="text-xs font-bold uppercase tracking-wider text-[#0099FF]">Standards Compliance</span>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-900">Accessibility Statement</h1>
          <div className="prose prose-slate text-xs sm:text-sm leading-relaxed space-y-4 text-slate-700">
            <p>
              H2UK is committed to ensuring digital accessibility for people with disabilities. We continually improve the user experience for everyone, applying relevant Web Content Accessibility Guidelines (WCAG) 2.2 AA standards.
            </p>
            <h3 className="text-base font-bold text-slate-900 mt-4">Measures Taken</h3>
            <ul className="list-disc pl-5 space-y-2">
              <li>High-contrast text and interactive elements meeting WCAG AA contrast thresholds (≥ 4.5:1).</li>
              <li>Full keyboard navigation across menus, forms, and dialog windows with visible focus rings.</li>
              <li>Descriptive labels and error notifications on all quotation input controls.</li>
              <li>Semantic HTML landmarks (`header`, `nav`, `main`, `footer`, `section`, `article`).</li>
              <li>Support for `prefers-reduced-motion` settings.</li>
            </ul>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
