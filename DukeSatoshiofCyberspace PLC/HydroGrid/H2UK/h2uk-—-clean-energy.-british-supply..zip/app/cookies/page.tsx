import React from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function CookiesPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />
      <main className="flex-1 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <span className="text-xs font-bold uppercase tracking-wider text-[#0099FF]">Cookie Policy</span>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-900">Cookie Policy</h1>
          <div className="prose prose-slate text-xs sm:text-sm leading-relaxed space-y-4 text-slate-700">
            <p>
              This website uses essential session cookies to support navigation, maintain state within our multi-step quotation system, and secure administrative review portals.
            </p>
            <h3 className="text-base font-bold text-slate-900 mt-4">Essential Cookies Only</h3>
            <p>
              We do not deploy intrusive third-party behavioural advertising trackers or non-essential telemetry cookies.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
