import React from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ClosingBanner from '@/components/ClosingBanner';
import { Leaf, CheckCircle2, ArrowRight, ShieldCheck, AlertCircle } from 'lucide-react';

export default function SustainabilityPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />

      <main className="flex-1">
        <section className="bg-[#0A1628] py-16 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl space-y-3">
              <span className="text-xs font-bold tracking-[0.2em] text-cyan-400 uppercase">
                Carbon Accounting & Provenance
              </span>
              <h1 className="text-4xl font-black tracking-tight text-white">
                Sustainability & Carbon Intensity Standards
              </h1>
              <p className="text-base text-slate-300 leading-relaxed">
                Objective carbon intensity methodology adhering to the UK Low Carbon Hydrogen Standard (LCHS) and statutory lifecycle emissions rules.
              </p>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white border-b border-slate-200">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
            <div className="space-y-4">
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
                Accurate Environmental Accounting
              </h2>
              <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
                Hydrogen is an energy carrier, not a primary energy source. Its ultimate environmental impact depends strictly on how it is produced, transported, and utilized. H2UK adheres to rigorous carbon accounting principles: we never describe hydrogen as universally &ldquo;zero-carbon&rdquo; without verifying its end-to-end production pathway.
              </p>
            </div>

            {/* UK LCHS Benchmark Card */}
            <div className="p-8 bg-slate-50 border border-slate-200 rounded-3xl space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-600">
                  <Leaf className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">The UK Low Carbon Hydrogen Standard (LCHS)</h3>
                  <span className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">Mandatory UK Statutory Benchmark</span>
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Under DESNZ regulations, hydrogen qualifies as &ldquo;Low Carbon&rdquo; in Great Britain only if its point-of-production greenhouse gas emissions do not exceed <strong>20.0 grams of CO₂ equivalent per megajoule of hydrogen (LHV basis)</strong> (gCO₂e/MJ LHV).
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-4 bg-white rounded-xl border border-slate-200">
                  <strong className="text-slate-900 block text-sm">Electrolytic Green Pathway:</strong>
                  <span className="text-xs text-slate-600 block mt-1">
                    Powered by dedicated UK offshore wind farms and solar installations with Renewable Energy Guarantees of Origin (REGOs). Typically delivers &lt;10 gCO₂e/MJ LHV.
                  </span>
                </div>

                <div className="p-4 bg-white rounded-xl border border-slate-200">
                  <strong className="text-slate-900 block text-sm">Low-Carbon Reforming with CCS:</strong>
                  <span className="text-xs text-slate-600 block mt-1">
                    Natural gas reforming paired with 95%+ permanent carbon capture and offshore geologic storage in the North Sea. Certified below 18 gCO₂e/MJ LHV.
                  </span>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-sky-50 border border-sky-200 text-xs sm:text-sm text-sky-950 leading-relaxed space-y-2">
              <strong className="block font-bold text-sky-900">Certificate of Origin Guarantee:</strong>
              <p>
                Every commercial dispatch from H2UK is accompanied by a serialised Certificate of Origin detailing the batch production facility, electricity source, calculated carbon intensity, and audit trail for your corporate GHG Protocol Scope 1 and Scope 2 disclosures.
              </p>
            </div>
          </div>
        </section>

        <ClosingBanner />
      </main>

      <Footer />
    </div>
  );
}
