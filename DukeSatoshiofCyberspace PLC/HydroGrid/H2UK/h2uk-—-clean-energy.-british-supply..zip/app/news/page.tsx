import React from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ClosingBanner from '@/components/ClosingBanner';
import { ArrowRight, Calendar, User, Clock, Tag } from 'lucide-react';

interface Article {
  slug: string;
  title: string;
  category: string;
  excerpt: string;
  date: string;
  readTime: string;
  author: string;
}

const ARTICLES: Article[] = [
  {
    slug: 'uk-hydrogen-allocation-round-3-analysis',
    title: 'UK Hydrogen Allocation Round (HAR3): Key Commercial Implications for Off-Takers',
    category: 'Market Policy',
    excerpt: 'An analysis of the Department for Energy Security and Net Zero’s revenue support mechanisms and what the latest funding allocations mean for British commercial and industrial fuel contracts.',
    date: '10 October 2026',
    readTime: '6 min read',
    author: 'Marcus Vance, Commercial Director',
  },
  {
    slug: 'liquid-vs-gaseous-hydrogen-logistics-deep-dive',
    title: 'Liquid vs Gaseous Hydrogen: The Physics, Economics and Site Reality for Fleets',
    category: 'Technical Engineering',
    excerpt: 'When does cryogenic liquid bunkering outperform 350-bar tube trailers? A direct comparison of payload density, boil-off mitigation, and capital expenditure for depot operators.',
    date: '28 September 2026',
    readTime: '8 min read',
    author: 'Dr. Eleanor Brooks, Logistics Solutions Lead',
  },
  {
    slug: 'low-carbon-hydrogen-standard-emissions-accounting',
    title: 'Navigating the UK Low Carbon Hydrogen Standard (LCHS): Verifying True Carbon Intensity',
    category: 'Sustainability',
    excerpt: 'Understanding the 20g CO2e/MJ threshold, scope 1-3 lifecycle boundary conditions, and how certified certificates of origin safeguard industrial corporate ESG reporting.',
    date: '14 September 2026',
    readTime: '5 min read',
    author: 'H2UK Environmental Compliance Desk',
  },
  {
    slug: 'dsear-atex-compliance-hydrogen-storage',
    title: 'DSEAR 2002 and ATEX Zoning for On-Site Hydrogen Tube Trailers: An Engineer’s Checklist',
    category: 'Safety & Regulations',
    excerpt: 'A practical guide for plant managers preparing for hydrogen delivery skids: boundary setback distances, emergency shut-off valves, earth bonding, and ventilation geometry.',
    date: '22 August 2026',
    readTime: '7 min read',
    author: 'Technical Safety Working Group',
  },
];

export default function NewsPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />

      <main className="flex-1">
        {/* Header */}
        <section className="bg-[#0A1628] py-16 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl space-y-3">
              <span className="text-xs font-bold tracking-[0.2em] text-cyan-400 uppercase">
                Industry Intelligence
              </span>
              <h1 className="text-4xl font-black tracking-tight text-white">
                H2UK News & Insights
              </h1>
              <p className="text-base text-slate-300 leading-relaxed">
                Engineering whitepapers, regulatory updates, and commercial analysis from Britain&apos;s hydrogen frontier.
              </p>
            </div>
          </div>
        </section>

        {/* Articles List */}
        <section className="py-16 bg-slate-50 border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {ARTICLES.map((art) => (
                <article
                  key={art.slug}
                  className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm hover:shadow-lg transition-all flex flex-col justify-between hover:-translate-y-0.5"
                >
                  <div className="space-y-4">
                    {/* Metadata following Zero-Pill discipline from frontend-design */}
                    <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
                      <span className="text-cyan-600 font-semibold uppercase tracking-wider">{art.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{art.date}</span>
                      <span aria-hidden="true">·</span>
                      <span>{art.readTime}</span>
                    </div>

                    <h2 className="text-xl sm:text-2xl font-bold text-slate-900 leading-snug hover:text-[#0099FF] transition-colors">
                      {art.title}
                    </h2>

                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                      {art.excerpt}
                    </p>
                  </div>

                  <div className="pt-6 mt-6 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <span>By {art.author}</span>
                    <Link
                      href={`/quote?article=${encodeURIComponent(art.title)}`}
                      className="font-semibold text-[#0099FF] hover:text-sky-700 inline-flex items-center gap-1"
                    >
                      <span>Discuss topic with an engineer</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <ClosingBanner />
      </main>

      <Footer />
    </div>
  );
}
