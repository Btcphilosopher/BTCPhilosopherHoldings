import type { Metadata, Viewport } from 'next';
import { Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css';

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '800'],
  display: 'swap',
  variable: '--font-sans',
});

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#0B192C',
};

export const metadata: Metadata = {
  title: 'H2UK — Clean Energy. British Supply.',
  description: "Britain's hydrogen supply partner delivering gaseous and liquid hydrogen for homes, commercial businesses, transport fleets, and industrial users across the UK.",
  keywords: [
    'hydrogen supply UK',
    'green hydrogen',
    'liquid hydrogen',
    'gaseous hydrogen',
    'tube trailer hydrogen',
    'hydrogen for transport',
    'industrial hydrogen decarbonisation',
    'H2UK',
  ],
  authors: [{ name: 'H2UK Energy Solutions' }],
  metadataBase: new URL('https://ais-dev-mhwvaysk7kov3ir2lb4snt-870496719167.europe-west2.run.app'),
  openGraph: {
    title: 'H2UK — Clean Energy. British Supply.',
    description: "Britain's hydrogen supply partner delivering gaseous and liquid hydrogen for homes, commercial businesses, transport fleets, and industrial users across the UK.",
    type: 'website',
    locale: 'en_GB',
    siteName: 'H2UK Energy',
    images: [
      {
        url: '/images/hero_hydrogen_facility.jpg',
        width: 1200,
        height: 675,
        alt: 'H2UK British coastal hydrogen storage and supply facility',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'H2UK — Clean Energy. British Supply.',
    description: "Britain's hydrogen supply partner delivering gaseous and liquid hydrogen for homes, commercial businesses, transport fleets, and industrial users across the UK.",
    images: ['/images/hero_hydrogen_facility.jpg'],
  },
  icons: {
    icon: '/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en-GB" className={`${plusJakartaSans.variable} font-sans scroll-smooth`}>
      <head>
        <link rel="canonical" href="https://ais-dev-mhwvaysk7kov3ir2lb4snt-870496719167.europe-west2.run.app" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'EnergySupplier',
              name: 'H2UK',
              legalName: 'H2UK Energy Solutions',
              url: 'https://ais-dev-mhwvaysk7kov3ir2lb4snt-870496719167.europe-west2.run.app',
              logo: 'https://ais-dev-mhwvaysk7kov3ir2lb4snt-870496719167.europe-west2.run.app/images/hero_hydrogen_facility.jpg',
              description: "Britain's hydrogen supply partner delivering gaseous and liquid hydrogen for homes, commercial businesses, transport fleets, and industrial users.",
              areaServed: {
                '@type': 'Country',
                name: 'United Kingdom',
              },
              knowsAbout: [
                'Gaseous Hydrogen (GH2)',
                'Liquid Hydrogen (LH2)',
                'Low Carbon Hydrogen Standard (LCHS)',
                'Heavy Transport Hydrogen Refuelling',
                'Industrial Process Heat Decarbonisation',
              ],
            }),
          }}
        />
      </head>
      <body className="min-h-screen bg-white text-slate-900 antialiased font-sans selection:bg-cyan-200 selection:text-slate-900" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
