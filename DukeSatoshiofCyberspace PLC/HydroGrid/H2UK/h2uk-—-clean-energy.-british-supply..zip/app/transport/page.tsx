import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ClosingBanner from '@/components/ClosingBanner';
import { Truck, ArrowRight, CheckCircle2, ShieldCheck, Zap, Gauge, MapPin, Fuel } from 'lucide-react';

export default function TransportPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />

      <main className="flex-1">
        {/* Hero */}
        <section className="relative bg-[#0A1628] py-20 text-white overflow-hidden">
          <div className="absolute inset-0 z-0 opacity-25">
            <Image
              src="/images/sector_transport.jpg"
              alt="Hydrogen fuel cell heavy freight lorry on British motorway"
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl space-y-4">
              <span className="text-xs font-bold tracking-[0.2em] text-cyan-400 uppercase">
                Zero-Emission Commercial Mobility
              </span>
              <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-white">
                Hydrogen Fuel for Heavy Fleets & Logistics Depots
              </h1>
              <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
                Reliable hydrogen refuelling infrastructure and bulk fuel supply for 44-tonne HGVs, municipal bus depots, harbour vessels, and commercial transport operators.
              </p>
              <div className="pt-2">
                <Link
                  href="/quote?sector=transport"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-[#0099FF] hover:bg-[#0088EE] text-white font-semibold text-sm rounded-full shadow-lg"
                >
                  <span>Request Fleet Refuelling Proposal</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Mobility Stats */}
        <section className="bg-slate-900 py-6 text-white border-b border-slate-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center text-xs sm:text-sm">
              <div>
                <span className="text-cyan-400 font-bold block text-base font-mono">350 & 700 Bar</span>
                <span className="text-slate-400">SAE J2601 Dispensing Standards</span>
              </div>
              <div>
                <span className="text-cyan-400 font-bold block text-base font-mono">10–15 Mins</span>
                <span className="text-slate-400">Full 44t HGV Refuel Duration</span>
              </div>
              <div>
                <span className="text-cyan-400 font-bold block text-base font-mono">500+ Miles</span>
                <span className="text-slate-400">Operational Daily Range</span>
              </div>
              <div>
                <span className="text-cyan-400 font-bold block text-base font-mono">Zero CO₂ / NOx</span>
                <span className="text-slate-400">Tailpipe Exhaust Emissions</span>
              </div>
            </div>
          </div>
        </section>

        {/* Transport Pillars */}
        <section className="py-16 bg-slate-50 border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto space-y-2 mb-12">
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
                Turnkey Fleet Solutions
              </h2>
              <p className="text-sm text-slate-600">
                Overcoming heavy payload, turnaround time, and grid connection limitations with hydrogen.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <div className="w-10 h-10 rounded-xl bg-sky-100 flex items-center justify-center text-sky-600 font-bold">
                  <Truck className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">44-Tonne Long-Haul HGVs</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Unlike battery-electric trucks that lose 4–6 tonnes of payload to battery packs, hydrogen fuel cell lorries preserve maximum legal freight payload with 15-minute turnaround times matching traditional diesel.
                </p>
              </div>

              <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-100 flex items-center justify-center text-cyan-600 font-bold">
                  <Fuel className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Depot Bunkering Stations</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  On-site mobile refuellers and containerised hydrogen stations (HRS) with buffer storage and cascade compression, enabling back-to-base overnight or inter-shift refuelling without costly local substation grid upgrades.
                </p>
              </div>

              <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-600 font-bold">
                  <Zap className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Buses, Municipal & Marine</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Heavy passenger transit, waste collection vehicles, airport ground support equipment, and coastal workboats requiring continuous multi-shift operation in demanding UK weather conditions.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Refuelling Infrastructure Sizing */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-4">
                <span className="text-xs font-bold uppercase tracking-wider text-[#0099FF]">Depot Engineering</span>
                <h2 className="text-3xl font-black text-slate-900">Containerised Station Deployment</h2>
                <p className="text-sm text-slate-600 leading-relaxed">
                  We supply both gaseous tube trailers (at 350/500 bar) and bulk liquid hydrogen bunkering for high-throughput depots. Our modular hydrogen refuelling stations (HRS) include pre-cooling (-40°C protocol), calibrated metering compliant with Weights & Measures regulations, and real-time remote telemetry.
                </p>

                <div className="space-y-3 pt-2">
                  <div className="flex items-center gap-3 text-xs sm:text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Compliant with ISO 19880-1 (Gaseous Hydrogen Fuelling Stations)</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs sm:text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Fast 350-bar and 700-bar dual dispensing nozzles with infrared vehicle communication</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs sm:text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Guaranteed fuel purity adhering strictly to ISO 14687 Grade D fuel cell grade</span>
                  </div>
                </div>

                <div className="pt-4">
                  <Link
                    href="/quote?sector=transport"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-[#0099FF] hover:bg-[#0088EE] text-white text-sm font-semibold rounded-full shadow-md"
                  >
                    <span>Request Fleet Feasibility Sizing</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>

              <div className="p-8 bg-slate-50 border border-slate-200 rounded-3xl space-y-4">
                <h3 className="text-lg font-bold text-slate-900">Fleet Fuel Demand Benchmark</h3>
                <div className="space-y-3 text-xs sm:text-sm text-slate-600">
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <strong className="text-slate-900 block">5 to 10 HGVs (~350–700 kg/day):</strong>
                    <span>Supplied via rotating 300-bar gaseous tube trailers with on-site booster compression.</span>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <strong className="text-slate-900 block">25 to 50 HGVs (~1,800–3,500 kg/day):</strong>
                    <span>Permanent on-site cryogenic liquid hydrogen tank with high-throughput vaporisation to 700 bar.</span>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <strong className="text-slate-900 block">Bus Depot (30–60 Single/Double Deckers):</strong>
                    <span>Dedicated 350-bar cascade refuelling bank with scheduled nocturnal multi-vehicle dispensing.</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ClosingBanner />
      </main>

      <Footer />
    </div>
  );
}
