'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ClosingBanner from '@/components/ClosingBanner';
import { ChevronDown, ArrowRight, HelpCircle } from 'lucide-react';

interface FAQ {
  q: string;
  a: string;
  category: string;
}

const FAQS: FAQ[] = [
  {
    category: 'Homes & Domestic',
    q: 'Can I switch my home boiler to hydrogen today?',
    a: 'Not via ordinary mains natural gas supply today. 100% hydrogen for domestic heating is currently restricted to government-approved trial areas and rural microgrid pilot demonstration projects under DESNZ supervision. Ordinary national grid networks do not yet deliver pure hydrogen to households. However, modern "hydrogen-ready" boilers can be installed today to burn standard natural gas with the ability to be converted if your local grid transitions in future.',
  },
  {
    category: 'Homes & Domestic',
    q: 'Can I store liquid hydrogen at my home?',
    a: 'No. Liquid hydrogen is stored cryogenically at minus 253°C and produces continuous boil-off gas requiring specialist industrial venting, flare stacks, or recompression systems. Liquid hydrogen is strictly unsuitable and prohibited for domestic residential storage.',
  },
  {
    category: 'Commercial & Supply',
    q: 'How is hydrogen delivered to commercial premises?',
    a: 'For gaseous hydrogen, delivery occurs via high-pressure tube trailers (200 to 500 bar) or multi-cylinder pallet packs (MCPs). A tractor unit drops a full trailer on your concrete hardstanding and connects it to your pressure reduction skid, retrieving the empty trailer on rotation. For high-volume sites, bulk cryogenic road tankers discharge liquid hydrogen into on-site vacuum-insulated tanks.',
  },
  {
    category: 'Commercial & Supply',
    q: 'How does H2UK price hydrogen supply?',
    a: 'Hydrogen supply pricing is tailored based on volume (kg or tonnes per month), delivery frequency, transport distance from the nearest British production terminal (Humber, Teesside, Mersey, or Scotland), required purity grade (e.g. Grade 5.0 vs fuel-cell grade), and on-site equipment leasing. We provide transparent index-linked commercial proposals upon review of your site survey.',
  },
  {
    category: 'Transport & Fleets',
    q: 'How long does it take to refuel a 44-tonne hydrogen HGV?',
    a: 'A 44-tonne articulated lorry carrying 30–40 kg of hydrogen refuels in approximately 10 to 15 minutes at standard 350-bar or 700-bar dispensing pressures, matching traditional diesel turnaround speeds.',
  },
  {
    category: 'Safety & Regulations',
    q: 'What site clearances are required for a hydrogen tube trailer?',
    a: 'Under UK DSEAR 2002 regulations and EIGA guidelines, a dedicated outdoor concrete hardstanding with designated exclusion setback zones (typically 5 to 15 metres depending on pressure relief valve orientations) is required. Storage must be separated from occupied buildings, property boundaries, and potential ignition sources, with appropriate ATEX zoning and earth bonding.',
  },
];

export default function FaqsPage() {
  const [openIdx, setOpenIdx] = useState<number | null>(0);
  const [selectedCat, setSelectedCat] = useState<string>('all');

  const filtered = selectedCat === 'all'
    ? FAQS
    : FAQS.filter(f => f.category === selectedCat);

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />

      <main className="flex-1">
        <section className="bg-[#0A1628] py-16 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl space-y-3">
              <span className="text-xs font-bold tracking-[0.2em] text-cyan-400 uppercase">
                Knowledge Base
              </span>
              <h1 className="text-4xl font-black tracking-tight text-white">
                Frequently Asked Questions
              </h1>
              <p className="text-base text-slate-300 leading-relaxed">
                Objective answers on domestic suitability, commercial procurement, delivery logistics, and safety standards.
              </p>
            </div>
          </div>
        </section>

        <section className="py-16 bg-slate-50 border-b border-slate-200">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
            {/* Category Filter Tabs */}
            <div className="flex flex-wrap gap-2">
              {['all', 'Homes & Domestic', 'Commercial & Supply', 'Transport & Fleets', 'Safety & Regulations'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => { setSelectedCat(cat); setOpenIdx(null); }}
                  className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                    selectedCat === cat
                      ? 'bg-[#0099FF] text-white shadow-sm'
                      : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  {cat === 'all' ? 'All Questions' : cat}
                </button>
              ))}
            </div>

            {/* Accordion List */}
            <div className="space-y-3">
              {filtered.map((faq, i) => {
                const isOpen = openIdx === i;
                return (
                  <div
                    key={faq.q}
                    className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs transition-colors"
                  >
                    <button
                      onClick={() => setOpenIdx(isOpen ? null : i)}
                      className="w-full p-5 text-left flex items-center justify-between gap-4 focus:outline-none"
                    >
                      <span className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                        {faq.q}
                      </span>
                      <ChevronDown className={`w-5 h-5 text-slate-400 shrink-0 transition-transform ${isOpen ? 'rotate-180 text-cyan-600' : ''}`} />
                    </button>
                    {isOpen && (
                      <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100">
                        {faq.a}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="p-6 bg-white rounded-2xl border border-slate-200 text-center space-y-2 mt-8">
              <h3 className="text-base font-bold text-slate-900">Have a specific technical question?</h3>
              <p className="text-xs sm:text-sm text-slate-600">
                Our commercial engineering team is available to review site layout constraints and project specifications.
              </p>
              <div className="pt-2">
                <Link
                  href="/contact"
                  className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#0099FF] text-white text-xs sm:text-sm font-semibold rounded-full shadow-sm hover:bg-[#0088EE]"
                >
                  <span>Contact Technical Desk</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </section>

        <ClosingBanner />
      </main>

      <Footer />
    </div>
  );
}
