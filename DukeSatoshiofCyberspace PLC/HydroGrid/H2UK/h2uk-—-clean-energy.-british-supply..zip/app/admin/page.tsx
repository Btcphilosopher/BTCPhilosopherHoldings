'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { QuotationEnquiry, EmailLogEntry, EnquiryStatus, CustomerType } from '@/lib/db/types';
import {
  ShieldAlert,
  Search,
  Filter,
  CheckCircle,
  Clock,
  AlertTriangle,
  Mail,
  Phone,
  FileSpreadsheet,
  Download,
  Building2,
  Home,
  Truck,
  Factory,
  MessageSquare,
  Lock,
  Unlock,
  ChevronRight,
  RefreshCw,
  ExternalLink,
  Eye,
  Send,
} from 'lucide-react';

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true); // Demo mode starts unlocked or easy unlock
  const [pinCode, setPinCode] = useState<string>('');
  const [pinError, setPinError] = useState<string | null>(null);

  const [enquiries, setEnquiries] = useState<QuotationEnquiry[]>([]);
  const [emailLogs, setEmailLogs] = useState<EmailLogEntry[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'leads' | 'emails'>('leads');

  // Filters
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sectorFilter, setSectorFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Selected enquiry for inspection
  const [selectedEnquiry, setSelectedEnquiry] = useState<QuotationEnquiry | null>(null);
  const [newNote, setNewNote] = useState<string>('');
  const [authorName, setAuthorName] = useState<string>('Marcus Vance (Commercial Lead)');
  const [isUpdatingStatus, setIsUpdatingStatus] = useState<boolean>(false);

  // Email preview modal
  const [previewEmail, setPreviewEmail] = useState<EmailLogEntry | null>(null);

  const refreshData = async () => {
    setLoading(true);
    try {
      const [resEnq, resEml] = await Promise.all([
        fetch('/api/admin/enquiries'),
        fetch('/api/admin/emails'),
      ]);
      const dataEnq = await resEnq.json();
      const dataEml = await resEml.json();
      if (dataEnq.enquiries) setEnquiries(dataEnq.enquiries);
      if (dataEml.logs) setEmailLogs(dataEml.logs);
    } catch (err) {
      console.error('Failed to refresh data', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let isMounted = true;
    fetch('/api/admin/enquiries')
      .then(res => res.json())
      .then(data => {
        if (isMounted) {
          if (data.enquiries) setEnquiries(data.enquiries);
          setLoading(false);
        }
      })
      .catch(err => {
        console.error('Failed to load enquiries', err);
        if (isMounted) setLoading(false);
      });

    fetch('/api/admin/emails')
      .then(res => res.json())
      .then(data => {
        if (isMounted && data.logs) setEmailLogs(data.logs);
      })
      .catch(err => console.error('Failed to load email logs', err));

    return () => {
      isMounted = false;
    };
  }, []);

  const handleStatusChange = async (enquiryId: string, newStatus: EnquiryStatus) => {
    setIsUpdatingStatus(true);
    try {
      const res = await fetch('/api/admin/enquiries', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: enquiryId,
          status: newStatus,
          author: authorName,
          note: `Commercial status transitioned to ${newStatus}`,
        }),
      });
      const data = await res.json();
      if (data.success && data.enquiry) {
        setEnquiries(prev => prev.map(e => e.id === enquiryId ? data.enquiry : e));
        setSelectedEnquiry(data.enquiry);
      }
    } catch (err) {
      console.error('Error changing status', err);
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEnquiry || !newNote.trim()) return;

    try {
      const res = await fetch('/api/admin/enquiries', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: selectedEnquiry.id,
          author: authorName,
          note: newNote.trim(),
        }),
      });
      const data = await res.json();
      if (data.success && data.enquiry) {
        setEnquiries(prev => prev.map(e => e.id === selectedEnquiry.id ? data.enquiry : e));
        setSelectedEnquiry(data.enquiry);
        setNewNote('');
      }
    } catch (err) {
      console.error('Error adding note', err);
    }
  };

  const exportCSV = () => {
    const headers = ['Reference', 'Sector', 'Format', 'Demand', 'Postcode', 'Status', 'Contact Name', 'Company', 'Email', 'Phone', 'Created At'];
    const rows = enquiries.map(e => [
      e.referenceNumber,
      e.customerType,
      e.supplyFormat,
      `${e.estimatedVolume} ${e.volumeUnit}`,
      e.postcode,
      e.status,
      `"${e.contact.fullName}"`,
      `"${e.contact.companyName || ''}"`,
      e.contact.email,
      e.contact.phone,
      e.createdAt,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `H2UK_Commercial_Leads_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredEnquiries = enquiries.filter(item => {
    if (statusFilter !== 'all' && item.status !== statusFilter) return false;
    if (sectorFilter !== 'all' && item.customerType !== sectorFilter) return false;
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const matchRef = item.referenceNumber.toLowerCase().includes(q);
      const matchName = item.contact.fullName.toLowerCase().includes(q);
      const matchCompany = (item.contact.companyName || '').toLowerCase().includes(q);
      const matchPostcode = item.postcode.toLowerCase().includes(q);
      if (!matchRef && !matchName && !matchCompany && !matchPostcode) return false;
    }
    return true;
  });

  // Calculate summary metrics
  const totalVolumeKg = enquiries
    .filter(e => e.volumeUnit === 'kg/day')
    .reduce((sum, e) => sum + (Number(e.estimatedVolume) || 0), 0);

  return (
    <div className="min-h-screen flex flex-col bg-slate-900 text-slate-100">
      <Navbar />

      <main className="flex-1 py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        {/* Admin Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-8 border-b border-slate-800 gap-4">
          <div>
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold uppercase tracking-widest">
              <ShieldAlert className="w-4 h-4" />
              <span>Internal Commercial Management</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">
              H2UK Commercial Pipeline & Enquiries Desk
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Live database of British hydrogen off-take enquiries, site hazard evaluations, and email notification records.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={refreshData}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-semibold flex items-center gap-2 border border-slate-700"
              title="Refresh Data"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Refresh</span>
            </button>

            <button
              onClick={exportCSV}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-semibold flex items-center gap-2 border border-slate-700 transition-colors"
            >
              <Download className="w-4 h-4 text-cyan-400" />
              <span>Export CSV</span>
            </button>

            <Link
              href="/quote"
              className="px-4 py-2.5 bg-[#0099FF] hover:bg-[#0088EE] text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-md"
            >
              <span>+ New Live Quote</span>
            </Link>
          </div>
        </div>

        {/* Metric Cards Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-4 my-8">
          <div className="p-4 bg-slate-800/80 rounded-2xl border border-slate-700/80">
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Total Leads</span>
            <div className="text-2xl font-bold font-mono text-white mt-1">{enquiries.length}</div>
            <span className="text-[11px] text-slate-400 mt-0.5 block">Pipeline enquiries</span>
          </div>

          <div className="p-4 bg-slate-800/80 rounded-2xl border border-slate-700/80">
            <span className="text-xs text-sky-400 uppercase tracking-wider font-semibold">Under Review</span>
            <div className="text-2xl font-bold font-mono text-sky-300 mt-1">
              {enquiries.filter(e => e.status === 'under_review').length}
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5 block">Engineering checks</span>
          </div>

          <div className="p-4 bg-slate-800/80 rounded-2xl border border-slate-700/80">
            <span className="text-xs text-emerald-400 uppercase tracking-wider font-semibold">Quoted</span>
            <div className="text-2xl font-bold font-mono text-emerald-300 mt-1">
              {enquiries.filter(e => e.status === 'quoted').length}
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5 block">Offers issued</span>
          </div>

          <div className="p-4 bg-slate-800/80 rounded-2xl border border-slate-700/80">
            <span className="text-xs text-amber-400 uppercase tracking-wider font-semibold">Action Required</span>
            <div className="text-2xl font-bold font-mono text-amber-300 mt-1">
              {enquiries.filter(e => e.status === 'clarification_required' || e.status === 'received').length}
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5 block">Awaiting response</span>
          </div>

          <div className="col-span-2 sm:col-span-4 lg:col-span-1 p-4 bg-slate-800/80 rounded-2xl border border-slate-700/80">
            <span className="text-xs text-cyan-400 uppercase tracking-wider font-semibold">Demand Identified</span>
            <div className="text-2xl font-bold font-mono text-cyan-300 mt-1">
              {totalVolumeKg.toLocaleString()} <span className="text-xs font-normal text-slate-400">kg/d</span>
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5 block">Total gaseous/liquid</span>
          </div>
        </div>

        {/* View Switcher: Commercial Leads vs Email Notification Logs */}
        <div className="flex border-b border-slate-800 mb-6 gap-6 text-sm font-semibold">
          <button
            onClick={() => setActiveTab('leads')}
            className={`pb-3 flex items-center gap-2 border-b-2 transition-colors ${
              activeTab === 'leads' ? 'border-cyan-400 text-white' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Customer Leads & Quotations</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">{enquiries.length}</span>
          </button>
          <button
            onClick={() => setActiveTab('emails')}
            className={`pb-3 flex items-center gap-2 border-b-2 transition-colors ${
              activeTab === 'emails' ? 'border-cyan-400 text-white' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Mail className="w-4 h-4 text-cyan-400" />
            <span>Transactional Email Logs</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">{emailLogs.length}</span>
          </button>
        </div>

        {/* TAB 1: LEADS & ENQUIRIES */}
        {activeTab === 'leads' && (
          <div className="space-y-6">
            {/* Filter Toolbar */}
            <div className="p-4 bg-slate-800/60 rounded-2xl border border-slate-700/80 flex flex-wrap items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[280px]">
                {/* Search */}
                <div className="relative flex-1 min-w-[200px]">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    placeholder="Search ref, company, postcode..."
                    className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                {/* Status Filter */}
                <select
                  value={statusFilter}
                  onChange={e => setStatusFilter(e.target.value)}
                  className="px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                >
                  <option value="all">All Statuses</option>
                  <option value="received">Received</option>
                  <option value="under_review">Under Review</option>
                  <option value="clarification_required">Clarification Required</option>
                  <option value="quoted">Quoted</option>
                  <option value="closed">Closed</option>
                </select>

                {/* Sector Filter */}
                <select
                  value={sectorFilter}
                  onChange={e => setSectorFilter(e.target.value)}
                  className="px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                >
                  <option value="all">All Sectors</option>
                  <option value="industry">Heavy Industry</option>
                  <option value="transport">Transport / Fleet</option>
                  <option value="business">Commercial Business</option>
                  <option value="household">Household Pilot</option>
                </select>
              </div>

              <div className="text-xs text-slate-400">
                Showing <strong>{filteredEnquiries.length}</strong> of {enquiries.length} leads
              </div>
            </div>

            {/* Leads Table */}
            <div className="bg-slate-800/50 rounded-2xl border border-slate-700/80 overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900/80 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="px-4 py-3.5">Reference</th>
                      <th className="px-4 py-3.5">Sector</th>
                      <th className="px-4 py-3.5">Company / Contact</th>
                      <th className="px-4 py-3.5">Format & Demand</th>
                      <th className="px-4 py-3.5">Postcode</th>
                      <th className="px-4 py-3.5">Status</th>
                      <th className="px-4 py-3.5 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {filteredEnquiries.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="px-6 py-12 text-center text-slate-400">
                          No quotation enquiries found matching current filters.
                        </td>
                      </tr>
                    ) : (
                      filteredEnquiries.map((enq) => (
                        <tr
                          key={enq.id}
                          className="hover:bg-slate-700/40 transition-colors cursor-pointer"
                          onClick={() => setSelectedEnquiry(enq)}
                        >
                          <td className="px-4 py-4 font-mono font-bold text-cyan-400 whitespace-nowrap">
                            {enq.referenceNumber}
                          </td>
                          <td className="px-4 py-4">
                            <span className="capitalize font-semibold text-slate-200">
                              {enq.customerType}
                            </span>
                          </td>
                          <td className="px-4 py-4">
                            <div className="font-semibold text-white">
                              {enq.contact.companyName || enq.contact.fullName}
                            </div>
                            <div className="text-[11px] text-slate-400">
                              {enq.contact.fullName} · {enq.contact.email}
                            </div>
                          </td>
                          <td className="px-4 py-4">
                            <div className="font-medium text-slate-200 capitalize">
                              {enq.supplyFormat} H₂
                            </div>
                            <div className="text-[11px] text-slate-400">
                              {enq.estimatedVolume} {enq.volumeUnit}
                            </div>
                          </td>
                          <td className="px-4 py-4 font-mono text-slate-300">
                            {enq.postcode}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap">
                            <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                              enq.status === 'quoted'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                : enq.status === 'under_review'
                                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                                : enq.status === 'clarification_required'
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                : enq.status === 'closed'
                                ? 'bg-slate-700 text-slate-400'
                                : 'bg-slate-800 text-slate-300 border border-slate-600'
                            }`}>
                              {enq.status.replace('_', ' ')}
                            </span>
                          </td>
                          <td className="px-4 py-4 text-right">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedEnquiry(enq);
                              }}
                              className="px-3 py-1 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-xs font-semibold transition-colors"
                            >
                              Inspect
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: TRANSACTIONAL EMAIL LOGS */}
        {activeTab === 'emails' && (
          <div className="space-y-4">
            <div className="p-4 bg-slate-800/60 rounded-2xl border border-slate-700 text-xs text-slate-300 flex items-center justify-between">
              <div>
                <strong>Transactional Email Adapter Status:</strong> Operating in Demo Simulation & Logging Mode. All customer receipts and internal lead alerts are stored and inspectable below.
              </div>
              <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 font-mono text-[11px]">
                Adapter Online
              </span>
            </div>

            <div className="bg-slate-800/50 rounded-2xl border border-slate-700/80 overflow-hidden shadow-xl">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-900/80 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-700">
                  <tr>
                    <th className="px-4 py-3.5">Ref</th>
                    <th className="px-4 py-3.5">Type</th>
                    <th className="px-4 py-3.5">Recipient</th>
                    <th className="px-4 py-3.5">Subject</th>
                    <th className="px-4 py-3.5">Dispatched At</th>
                    <th className="px-4 py-3.5 text-right">HTML Preview</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {emailLogs.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                        No transactional emails recorded yet.
                      </td>
                    </tr>
                  ) : (
                    emailLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-700/30">
                        <td className="px-4 py-3.5 font-mono text-cyan-400">{log.enquiryRef}</td>
                        <td className="px-4 py-3.5">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                            log.type === 'customer_confirmation'
                              ? 'bg-sky-900/60 text-sky-300'
                              : 'bg-purple-900/60 text-purple-300'
                          }`}>
                            {log.type === 'customer_confirmation' ? 'Customer Receipt' : 'Internal Alert'}
                          </span>
                        </td>
                        <td className="px-4 py-3.5 text-white font-medium">{log.recipient}</td>
                        <td className="px-4 py-3.5 text-slate-300 truncate max-w-xs">{log.subject}</td>
                        <td className="px-4 py-3.5 text-slate-400">
                          {new Date(log.dispatchedAt).toLocaleString('en-GB')}
                        </td>
                        <td className="px-4 py-3.5 text-right">
                          <button
                            onClick={() => setPreviewEmail(log)}
                            className="px-2.5 py-1 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 rounded text-xs font-semibold flex items-center gap-1 ml-auto"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Preview</span>
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* MODAL: DETAIL ENQUIRY DRAWER */}
        {selectedEnquiry && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
            <div className="w-full max-w-3xl max-h-[90vh] bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-150">
              {/* Modal Header */}
              <div className="p-6 bg-slate-800/80 border-b border-slate-700 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xl font-black text-cyan-400">
                      {selectedEnquiry.referenceNumber}
                    </span>
                    <span className="text-xs uppercase px-2.5 py-0.5 rounded-full bg-slate-700 text-slate-300 font-bold">
                      {selectedEnquiry.customerType}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    Submitted on {new Date(selectedEnquiry.createdAt).toLocaleString('en-GB')}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  {/* Status Picker */}
                  <select
                    disabled={isUpdatingStatus}
                    value={selectedEnquiry.status}
                    onChange={e => handleStatusChange(selectedEnquiry.id, e.target.value as EnquiryStatus)}
                    className="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-xl text-xs font-semibold text-white focus:outline-none focus:border-cyan-400"
                  >
                    <option value="received">Status: Received</option>
                    <option value="under_review">Status: Under Review</option>
                    <option value="clarification_required">Status: Clarification Required</option>
                    <option value="quoted">Status: Quoted</option>
                    <option value="closed">Status: Closed</option>
                  </select>

                  <button
                    onClick={() => setSelectedEnquiry(null)}
                    className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700"
                  >
                    ✕
                  </button>
                </div>
              </div>

              {/* Modal Body */}
              <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs sm:text-sm">
                {/* Contact Card */}
                <div className="p-4 bg-slate-800/50 rounded-2xl border border-slate-700/80">
                  <h3 className="text-xs uppercase font-bold text-cyan-400 tracking-wider mb-2">
                    Lead & Contact Details
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-slate-200">
                    <div>
                      <span className="text-slate-400 text-xs block">Contact Name</span>
                      <strong>{selectedEnquiry.contact.fullName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 text-xs block">Organisation</span>
                      <strong>{selectedEnquiry.contact.companyName || 'Private / Community'}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 text-xs block">Job Title</span>
                      <span>{selectedEnquiry.contact.jobTitle || 'Not specified'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-xs block">Email Address</span>
                      <a href={`mailto:${selectedEnquiry.contact.email}`} className="text-cyan-400 hover:underline">
                        {selectedEnquiry.contact.email}
                      </a>
                    </div>
                    <div>
                      <span className="text-slate-400 text-xs block">Telephone</span>
                      <a href={`tel:${selectedEnquiry.contact.phone}`} className="text-cyan-400 hover:underline">
                        {selectedEnquiry.contact.phone}
                      </a>
                    </div>
                    <div>
                      <span className="text-slate-400 text-xs block">Delivery Postcode</span>
                      <strong className="font-mono text-cyan-300">{selectedEnquiry.postcode}</strong>
                    </div>
                  </div>
                </div>

                {/* Technical Specifications Card */}
                <div className="p-4 bg-slate-800/50 rounded-2xl border border-slate-700/80 space-y-3">
                  <h3 className="text-xs uppercase font-bold text-cyan-400 tracking-wider">
                    Technical Supply Requirements
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-slate-200">
                    <div>
                      <span className="text-slate-400 text-xs block">Supply Format</span>
                      <strong className="capitalize">{selectedEnquiry.supplyFormat} Hydrogen</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 text-xs block">Volume & Frequency</span>
                      <strong>{selectedEnquiry.estimatedVolume} {selectedEnquiry.volumeUnit} ({selectedEnquiry.frequency})</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 text-xs block">Offloading Profile</span>
                      <span>{selectedEnquiry.siteDetails.offloadingAccess || 'Standard'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-xs block">Hazardous ATEX/DSEAR</span>
                      <span>{selectedEnquiry.siteDetails.atexZoned ? '✓ Yes, Site Zoned' : '✗ Unzoned / Requires Survey'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-xs block">Current Energy Replaced</span>
                      <span>{selectedEnquiry.siteDetails.currentEnergySource || 'N/A'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-xs block">Target Start</span>
                      <span>{selectedEnquiry.siteDetails.targetStartDate || '2026/2027'}</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-700">
                    <span className="text-slate-400 text-xs block">Operational Application</span>
                    <p className="text-slate-200 mt-0.5">{selectedEnquiry.application}</p>
                  </div>

                  {selectedEnquiry.contact.additionalNotes && (
                    <div className="pt-2 border-t border-slate-700">
                      <span className="text-slate-400 text-xs block">Customer Notes</span>
                      <p className="text-slate-300 mt-0.5 italic">{selectedEnquiry.contact.additionalNotes}</p>
                    </div>
                  )}
                </div>

                {/* Internal Notes Section */}
                <div className="space-y-3">
                  <h3 className="text-xs uppercase font-bold text-slate-400 tracking-wider">
                    Internal Engineering Notes ({selectedEnquiry.internalNotes.length})
                  </h3>

                  <div className="space-y-2">
                    {selectedEnquiry.internalNotes.map(n => (
                      <div key={n.id} className="p-3 bg-slate-800 rounded-xl border border-slate-700">
                        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                          <strong className="text-cyan-300">{n.author}</strong>
                          <span>{new Date(n.createdAt).toLocaleString('en-GB')}</span>
                        </div>
                        <p className="text-slate-200 text-xs sm:text-sm">{n.content}</p>
                      </div>
                    ))}
                  </div>

                  {/* Add Note Form */}
                  <form onSubmit={handleAddNote} className="space-y-2 pt-2">
                    <textarea
                      rows={2}
                      value={newNote}
                      onChange={e => setNewNote(e.target.value)}
                      placeholder="Add internal site survey notes, logistics check, or quotation draft comments..."
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                    <div className="flex items-center justify-between">
                      <input
                        type="text"
                        value={authorName}
                        onChange={e => setAuthorName(e.target.value)}
                        placeholder="Author name"
                        className="px-3 py-1 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-300 w-64"
                      />
                      <button
                        type="submit"
                        disabled={!newNote.trim()}
                        className="px-4 py-1.5 bg-[#0099FF] hover:bg-[#0088EE] disabled:opacity-50 text-white rounded-lg text-xs font-semibold"
                      >
                        Add Internal Note
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* MODAL: TRANSACTIONAL EMAIL PREVIEW */}
        {previewEmail && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
            <div className="w-full max-w-2xl bg-white text-slate-900 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
              <div className="p-4 bg-slate-100 border-b border-slate-200 flex items-center justify-between text-xs">
                <div>
                  <strong>To:</strong> {previewEmail.recipient} | <strong>Subject:</strong> {previewEmail.subject}
                </div>
                <button
                  onClick={() => setPreviewEmail(null)}
                  className="p-1 hover:bg-slate-200 rounded font-bold"
                >
                  ✕
                </button>
              </div>
              <div
                className="p-6 overflow-y-auto flex-1 bg-white"
                dangerouslySetInnerHTML={{ __html: previewEmail.htmlPreview }}
              />
              <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-xs text-slate-500">
                Generated via H2UK Transactional Email Adapter
              </div>
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
