import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ClosingBanner from '@/components/ClosingBanner';
import { Wind, Snowflake, CheckCircle2, ShieldCheck, ArrowRight, Download, FileText, Layers, MapPin, Gauge } from 'lucide-react';

interface SupplyProduct {
  id: string;
  name: string;
  format: 'Gaseous Hydrogen (GH2)' | 'Liquid Hydrogen (LH2)';
  pathway: string;
  purity: string;
  pressureOrTemp: string;
  deliveryFormat: string;
  availableQuantity: string;
  carbonIntensity: string;
  certifications: string[];
  geographicAvailability: string;
  verificationStatus: 'Verified Operational Standard' | 'Trial Pilot Specification';
}

const SUPPLY_CATALOG: SupplyProduct[] = [
  {
    id: 'gh2-grade-5',
    name: 'Industrial High-Purity Gaseous Hydrogen',
    format: 'Gaseous Hydrogen (GH2)',
    pathway: 'Electrolytic Green Pathway (Powered by UK offshore wind & solar PPAs)',
    purity: 'Grade 5.0 (≥ 99.999% H2 assay; < 1.0 ppmv H2O)',
    pressureOrTemp: '200 bar & 300 bar working pressure (500 bar optional)',
    deliveryFormat: 'Multi-cylinder pallet packs (MCPs) & 40ft high-capacity tube trailers',
    availableQuantity: 'From 50 kg/order up to 25,000 kg/month bulk contracts',
    carbonIntensity: '< 15.2 g CO2e/MJ LHV (Meets UK Low Carbon Hydrogen Standard threshold of 20g)',
    certifications: ['UK LCHS Certified', 'ISO 14687 Grade D/5.0', 'DSEAR / ATEX Compliant'],
    geographicAvailability: 'Humber, Teesside, Mersey, Midlands, and South East distribution corridors',
    verificationStatus: 'Verified Operational Standard',
  },
  {
    id: 'lh2-bulk',
    name: 'Bulk Cryogenic Liquid Hydrogen',
    format: 'Liquid Hydrogen (LH2)',
    pathway: 'Certified Low-Carbon Pathway with Carbon Capture & Storage (CCS) and electrolytic blending',
    purity: '≥ 99.99% cryogenic purity (ultra-low non-condensable trace gases)',
    pressureOrTemp: 'Minus 253°C (20 Kelvin) cryogenic storage at 1–3 bar operating pressure',
    deliveryFormat: 'Vacuum super-insulated cryogenic road tankers (3,500–4,200 kg load)',
    availableQuantity: 'From 3,000 kg/delivery up to 60,000 kg/month industrial agreements',
    carbonIntensity: '< 18.5 g CO2e/MJ LHV (Compliant with UK LCHS emissions methodology)',
    certifications: ['UK LCHS Registered', 'ADR Class 2 Hazard Approved', 'EIGA Standards'],
    geographicAvailability: 'Mainline strategic motorway routes serving major industrial clusters and transport depots',
    verificationStatus: 'Verified Operational Standard',
  },
  {
    id: 'gh2-mobility',
    name: 'Transport Fuel Cell Grade Hydrogen',
    format: 'Gaseous Hydrogen (GH2)',
    pathway: '100% Electrolytic Green Hydrogen with guaranteed renewable provenance',
    purity: 'ISO 14687-2 Fuel Cell Specification (strictly < 0.2 ppm CO, < 0.004 ppm Total Sulphur)',
    pressureOrTemp: '350 bar & 700 bar cascade dispensing ready',
    deliveryFormat: 'High-pressure tube trailer swap service or dedicated depot buffer banks',
    availableQuantity: '200 kg/day to 5,000 kg/day fleet refuelling agreements',
    carbonIntensity: '< 9.8 g CO2e/MJ LHV (Direct renewable generation pathway)',
    certifications: ['ISO 19880-1 Compliant', 'SAE J2601 Fuelling Protocol', 'LCHS Certified'],
    geographicAvailability: 'Dedicated UK freight corridors and participating municipal transit depots',
    verificationStatus: 'Verified Operational Standard',
  },
];

export default function OurSupplyPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />

      <main className="flex-1">
        {/* Hero */}
        <section className="relative bg-[#0A1628] py-20 text-white overflow-hidden">
          <div className="absolute inset-0 z-0 opacity-30">
            <Image
              src="/images/hero_hydrogen_facility.jpg"
              alt="H2UK hydrogen storage infrastructure"
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl space-y-4">
              <span className="text-xs font-bold tracking-[0.2em] text-cyan-400 uppercase">
                Technical Supply Registry
              </span>
              <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-white">
                British Hydrogen Supply Specifications
              </h1>
              <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
                Comprehensive technical parameters for gaseous and liquid hydrogen supply, verified against UK standards, purity specifications, and carbon intensity methodologies.
              </p>
            </div>
          </div>
        </section>

        {/* Technical Product Catalog */}
        <section className="py-16 bg-slate-50 border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
            <div className="max-w-2xl">
              <span className="text-xs font-bold uppercase tracking-wider text-[#0099FF]">Quality Governance</span>
              <h2 className="text-3xl font-black text-slate-900 mt-1">Verified Supply Formats & Pathways</h2>
              <p className="text-sm text-slate-600 mt-2">
                In strict compliance with British standards, missing or site-dependent values are noted transparently for engineering consultation.
              </p>
            </div>

            <div className="space-y-8">
              {SUPPLY_CATALOG.map((product) => (
                <div
                  key={product.id}
                  id={product.id.startsWith('gh2') ? 'gaseous' : 'liquid'}
                  className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-md space-y-6"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200">
                    <div className="space-y-1">
                      <div className="flex items-center gap-3">
                        <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-sky-100 text-sky-800">
                          {product.format}
                        </span>
                        <span className="text-xs text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full font-semibold border border-emerald-200">
                          ✓ {product.verificationStatus}
                        </span>
                      </div>
                      <h3 className="text-2xl font-black text-slate-900">{product.name}</h3>
                    </div>

                    <Link
                      href={`/quote?format=${product.format.includes('Liquid') ? 'liquid' : 'gaseous'}`}
                      className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#0099FF] hover:bg-[#0088EE] text-white text-xs sm:text-sm font-semibold rounded-full shadow-sm shrink-0"
                    >
                      <span>Enquire on this Specification</span>
                      <ArrowRight className="w-4 h-4" />
                    </Link>
                  </div>

                  {/* Technical Matrix Table */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-xs sm:text-sm">
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                      <span className="text-slate-500 font-semibold block text-[11px] uppercase tracking-wider">
                        Production Pathway
                      </span>
                      <p className="text-slate-900 font-medium">{product.pathway}</p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                      <span className="text-slate-500 font-semibold block text-[11px] uppercase tracking-wider">
                        Purity Specification
                      </span>
                      <p className="text-slate-900 font-semibold">{product.purity}</p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                      <span className="text-slate-500 font-semibold block text-[11px] uppercase tracking-wider">
                        Pressure / Temperature Rating
                      </span>
                      <p className="text-slate-900 font-semibold">{product.pressureOrTemp}</p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                      <span className="text-slate-500 font-semibold block text-[11px] uppercase tracking-wider">
                        Delivery & Logistics Format
                      </span>
                      <p className="text-slate-900 font-medium">{product.deliveryFormat}</p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                      <span className="text-slate-500 font-semibold block text-[11px] uppercase tracking-wider">
                        Available Quantity Capacity
                      </span>
                      <p className="text-slate-900 font-medium">{product.availableQuantity}</p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                      <span className="text-slate-500 font-semibold block text-[11px] uppercase tracking-wider">
                        Carbon Intensity Benchmark
                      </span>
                      <p className="text-emerald-700 font-bold">{product.carbonIntensity}</p>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-slate-500">
                    <div className="flex flex-wrap items-center gap-2">
                      <strong className="text-slate-700">Applicable Standards:</strong>
                      {product.certifications.map(c => (
                        <span key={c} className="px-2.5 py-0.5 bg-slate-100 text-slate-700 rounded-md font-medium">
                          {c}
                        </span>
                      ))}
                    </div>
                    <div>
                      <strong className="text-slate-700">UK Coverage:</strong> {product.geographicAvailability}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Safety & Handling Reminder */}
        <section className="py-12 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="p-6 rounded-2xl bg-sky-50 border border-sky-200 flex items-start gap-4">
              <ShieldCheck className="w-6 h-6 text-sky-700 shrink-0 mt-1" />
              <div className="space-y-1 text-xs sm:text-sm text-sky-950 leading-relaxed">
                <h4 className="font-bold text-sky-900">Safety & Engineering Advisory</h4>
                <p>
                  Hydrogen is an odourless, highly flammable gas with wide flammability limits (4% to 75% in air). Site offloading, cylinder storage, and pipeline manifolds must strictly comply with DSEAR 2002 regulations and local fire authority notification thresholds. Never attempt unauthorized connection or modification of high-pressure hydrogen systems.
                </p>
                <div className="pt-2">
                  <Link href="/safety" className="font-bold text-[#0099FF] hover:underline inline-flex items-center gap-1">
                    <span>View H2UK Safety & Technical Documentation</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ClosingBanner />
      </main>

      <Footer />
    </div>
  );
}
