import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { createEnquiry, getEnquiryByRef } from '@/lib/db/store';
import { sendEnquiryEmails } from '@/lib/email/adapter';

const enquirySchema = z.object({
  customerType: z.enum(['household', 'business', 'industry', 'transport']),
  supplyFormat: z.enum(['gaseous', 'liquid', 'unsure']),
  application: z.string().min(5, 'Please provide more details on intended use'),
  estimatedVolume: z.string().min(1, 'Volume is required'),
  volumeUnit: z.enum(['kg/day', 'Nm3/hr', 'tonnes/month', 'MWh/year', 'cylinders/month']),
  frequency: z.enum(['scheduled_recurring', 'one_off', 'continuous_pipeline', 'pilot_trial']),
  postcode: z.string().min(3, 'Valid UK postcode is required').regex(/^[A-Za-z0-9\s]{3,8}$/, 'Invalid UK postcode format'),
  siteDetails: z.object({
    hasStorageSpace: z.boolean().optional(),
    atexZoned: z.boolean().optional(),
    offloadingAccess: z.string().optional(),
    currentEnergySource: z.string().optional(),
    fleetSize: z.number().optional(),
    vehicleType: z.string().optional(),
    purityRequired: z.string().optional(),
    targetStartDate: z.string().optional(),
  }).default({}),
  contact: z.object({
    fullName: z.string().min(2, 'Full name is required'),
    companyName: z.string().optional(),
    email: z.string().email('Valid email address is required'),
    phone: z.string().min(6, 'Valid contact phone number is required'),
    jobTitle: z.string().optional(),
    preferredContact: z.enum(['email', 'phone']).default('email'),
    additionalNotes: z.string().optional(),
    consentTerms: z.boolean().refine(val => val === true, 'You must accept the terms to proceed'),
  }),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const validated = enquirySchema.parse(body);

    const enquiry = createEnquiry(validated);
    const emailResult = await sendEnquiryEmails(enquiry);

    return NextResponse.json({
      success: true,
      referenceNumber: enquiry.referenceNumber,
      status: enquiry.status,
      createdAt: enquiry.createdAt,
      emailStatus: emailResult.mode,
      message: 'Your enquiry has been received and logged in the H2UK commercial pipeline.',
    }, { status: 201 });
  } catch (err: unknown) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({
        success: false,
        error: 'Validation failed',
        details: err.issues.map(e => ({ path: e.path.join('.'), message: e.message })),
      }, { status: 400 });
    }

    console.error('Error creating enquiry:', err);
    return NextResponse.json({
      success: false,
      error: 'An unexpected server error occurred while processing your enquiry.',
    }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const ref = searchParams.get('ref');

  if (!ref) {
    return NextResponse.json({ error: 'Reference parameter is required' }, { status: 400 });
  }

  const found = getEnquiryByRef(ref);
  if (!found) {
    return NextResponse.json({ error: 'Enquiry not found' }, { status: 404 });
  }

  // Return public tracking safe subset (no private billing/credentials)
  return NextResponse.json({
    referenceNumber: found.referenceNumber,
    customerType: found.customerType,
    supplyFormat: found.supplyFormat,
    status: found.status,
    createdAt: found.createdAt,
    updatedAt: found.updatedAt,
    notesCount: found.internalNotes.length,
    auditHistory: found.auditLog.map(a => ({
      action: a.action,
      timestamp: a.timestamp,
      details: a.details,
    })),
  });
}
