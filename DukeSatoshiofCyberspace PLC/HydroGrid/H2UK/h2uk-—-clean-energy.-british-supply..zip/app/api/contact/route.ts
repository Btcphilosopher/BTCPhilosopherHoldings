import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { createContactMessage } from '@/lib/db/store';

const contactSchema = z.object({
  fullName: z.string().min(2, 'Full name is required'),
  email: z.string().email('Valid email is required'),
  phone: z.string().optional(),
  company: z.string().optional(),
  subject: z.string().min(3, 'Subject is required'),
  message: z.string().min(10, 'Message must be at least 10 characters long'),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const validated = contactSchema.parse(body);
    const msg = createContactMessage(validated);

    return NextResponse.json({
      success: true,
      messageId: msg.id,
      message: 'Thank you for reaching out. An H2UK advisor will respond promptly.',
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({
        success: false,
        error: 'Validation failed',
        details: err.issues.map(e => e.message),
      }, { status: 400 });
    }
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 });
  }
}
