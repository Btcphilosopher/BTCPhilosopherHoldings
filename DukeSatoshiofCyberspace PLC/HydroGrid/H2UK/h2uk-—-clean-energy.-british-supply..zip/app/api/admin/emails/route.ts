import { NextResponse } from 'next/server';
import { getEmailLogs } from '@/lib/db/store';

export async function GET() {
  const logs = getEmailLogs();
  return NextResponse.json({ logs });
}
