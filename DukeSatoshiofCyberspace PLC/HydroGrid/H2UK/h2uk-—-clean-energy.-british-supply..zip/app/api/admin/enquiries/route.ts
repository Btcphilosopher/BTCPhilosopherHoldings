import { NextRequest, NextResponse } from 'next/server';
import { getEnquiries, updateEnquiryStatus, addEnquiryNote } from '@/lib/db/store';
import { EnquiryStatus } from '@/lib/db/types';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const status = searchParams.get('status') as EnquiryStatus | null;
  const sector = searchParams.get('sector');

  let list = getEnquiries();

  if (status) {
    list = list.filter(e => e.status === status);
  }
  if (sector && sector !== 'all') {
    list = list.filter(e => e.customerType === sector);
  }

  return NextResponse.json({
    total: list.length,
    enquiries: list,
  });
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, status, author = 'Commercial Admin', note } = body;

    if (!id) {
      return NextResponse.json({ error: 'Missing enquiry id' }, { status: 400 });
    }

    if (status) {
      const updated = updateEnquiryStatus(id, status, author, note);
      if (!updated) {
        return NextResponse.json({ error: 'Enquiry not found' }, { status: 404 });
      }
      return NextResponse.json({ success: true, enquiry: updated });
    } else if (note) {
      const updated = addEnquiryNote(id, author, note);
      if (!updated) {
        return NextResponse.json({ error: 'Enquiry not found' }, { status: 404 });
      }
      return NextResponse.json({ success: true, enquiry: updated });
    }

    return NextResponse.json({ error: 'No update action specified' }, { status: 400 });
  } catch (err) {
    console.error('Error updating enquiry in admin:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
