import { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/admin', '/api/admin/'],
      },
    ],
    sitemap: 'https://ais-dev-mhwvaysk7kov3ir2lb4snt-870496719167.europe-west2.run.app/sitemap.xml',
  };
}
