import React from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function TermsPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />
      <main className="flex-1 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <span className="text-xs font-bold uppercase tracking-wider text-[#0099FF]">Commercial Conditions</span>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-900">Terms & Conditions</h1>
          <div className="prose prose-slate text-xs sm:text-sm leading-relaxed space-y-4 text-slate-700">
            <p>
              These Terms and Conditions govern use of the H2UK commercial quotation engine and marketing website.
            </p>
            <h3 className="text-base font-bold text-slate-900 mt-4">1. Non-Binding Nature of Online Enquiries</h3>
            <p>
              Submission of a quotation request or completion of a suitability assessment does not constitute a binding contract or operational guarantee of hydrogen delivery. Supply agreements are subject to formal site hazard reviews, DSEAR 2002 verification, logistics scheduling, and mutual execution of approved supply contracts.
            </p>
            <h3 className="text-base font-bold text-slate-900 mt-4">2. Intellectual Property</h3>
            <p>
              All trademarks, wordmarks, technical specifications, calculators, and content published on this website are the property of H2UK Energy Solutions.
            </p>
            <h3 className="text-base font-bold text-slate-900 mt-4">3. Governing Law</h3>
            <p>
              These terms are governed by and construed in accordance with the laws of England and Wales.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
