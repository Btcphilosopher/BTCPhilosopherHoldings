import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ClosingBanner from '@/components/ClosingBanner';
import { Building2, ArrowRight, CheckCircle2, ShieldCheck, Zap, Factory, Flame, HelpCircle } from 'lucide-react';

export default function ForBusinessesPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-[#0A1628] py-20 text-white overflow-hidden">
          <div className="absolute inset-0 z-0 opacity-25">
            <Image
              src="/images/sector_business.jpg"
              alt="British corporate commercial office park"
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl space-y-4">
              <span className="text-xs font-bold tracking-[0.2em] text-cyan-400 uppercase">
                Commercial Energy Supply
              </span>
              <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-white">
                Hydrogen Energy for UK Businesses & Commercial Operations
              </h1>
              <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
                Reliable gaseous and liquid hydrogen supply for commercial heating, backup resilience, CHP generation, and logistics hubs.
              </p>
              <div className="pt-2">
                <Link
                  href="/quote?sector=business"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-[#0099FF] hover:bg-[#0088EE] text-white font-semibold text-sm rounded-full shadow-lg"
                >
                  <span>Request Commercial Quotation</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Commercial Applications Grid */}
        <section className="py-16 bg-slate-50 border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto space-y-2 mb-12">
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
                Key Commercial Applications
              </h2>
              <p className="text-sm text-slate-600">
                Tailored delivery schedules from small pallet packs to high-capacity tube trailers.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <div className="w-10 h-10 rounded-xl bg-sky-100 flex items-center justify-center text-sky-600 font-bold">
                  <Zap className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Zero-Emission Backup Power</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Replace noisy, high-emission diesel generators in data centres, hospitals, and critical infrastructure with hydrogen fuel cells offering immediate cold-start capability and zero local air pollutants.
                </p>
              </div>

              <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-100 flex items-center justify-center text-cyan-600 font-bold">
                  <Flame className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Commercial Space & Process Heating</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Decarbonise large-volume warehouses, commercial greenhouses, food manufacturing facilities, and campus boiler rooms where electrical heat pump retrofits face grid connection constraints.
                </p>
              </div>

              <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-600 font-bold">
                  <Building2 className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Combined Heat & Power (CHP)</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  On-site high-efficiency CHP systems running on clean hydrogen to produce both baseline electricity and recovered thermal heat with exceptional overall thermodynamic efficiency.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Commercial Supply Formats & Procurement */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-4">
                <span className="text-xs font-bold uppercase tracking-wider text-[#0099FF]">Flexible Contracts</span>
                <h2 className="text-3xl font-black text-slate-900">Scheduled Recurring & One-Off Deliveries</h2>
                <p className="text-sm text-slate-600 leading-relaxed">
                  We supply commercial operations through rotating swap-trailer agreements or modular manifold cylinder packs (MCPs). With automatic telemetry monitoring, our British dispatch centre tracks your storage pressure and schedules seamless swaps before operational thresholds are reached.
                </p>

                <div className="space-y-3 pt-2">
                  <div className="flex items-center gap-3 text-xs sm:text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Fixed-term commercial pricing with indexed fuel stability</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs sm:text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Comprehensive DSEAR and ATEX hazard layout review</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs sm:text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Full Low Carbon Hydrogen Standard (LCHS) certificate of origin</span>
                  </div>
                </div>

                <div className="pt-4">
                  <Link
                    href="/quote?sector=business"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-[#0099FF] hover:bg-[#0088EE] text-white text-sm font-semibold rounded-full shadow-md"
                  >
                    <span>Request Business Supply Assessment</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>

              <div className="p-8 bg-slate-50 border border-slate-200 rounded-3xl space-y-4">
                <h3 className="text-lg font-bold text-slate-900">Commercial Sizing Guide</h3>
                <div className="space-y-3 text-xs sm:text-sm text-slate-600">
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <strong className="text-slate-900 block">Small Commercial (50–200 kg/month):</strong>
                    <span>MCP bundles (16-cylinder pallet skids at 300 bar) suitable for backup power.</span>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <strong className="text-slate-900 block">Medium Commercial (500–2,000 kg/month):</strong>
                    <span>Rotating 20ft tube trailer swap on designated hardstanding.</span>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200">
                    <strong className="text-slate-900 block">Large Commercial / Campus (2,000+ kg/month):</strong>
                    <span>High-capacity 40ft tube trailers or on-site stationary bulk manifold storage.</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ClosingBanner />
      </main>

      <Footer />
    </div>
  );
}
