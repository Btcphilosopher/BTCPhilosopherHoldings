'use client';

import React, { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { CustomerType, SupplyFormat, VolumeUnit, SupplyFrequency } from '@/lib/db/types';
import {
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Building2,
  Home,
  Truck,
  Factory,
  Wind,
  Snowflake,
  HelpCircle,
  ShieldCheck,
  AlertCircle,
  FileText,
  Search,
  Mail,
  Phone,
  MapPin,
  Clock,
  Sparkles,
} from 'lucide-react';

function QuoteForm() {
  const searchParams = useSearchParams();
  const initialSector = (searchParams.get('sector') as CustomerType) || 'business';
  const initialFormat = (searchParams.get('format') as SupplyFormat) || 'gaseous';

  // Tracking vs New Quotation mode
  const [activeTab, setActiveTab] = useState<'new_quote' | 'track_quote'>('new_quote');

  // Multi-step state: 1 to 6
  const [step, setStep] = useState<number>(1);

  // Form state
  const [customerType, setCustomerType] = useState<CustomerType>(initialSector);
  const [supplyFormat, setSupplyFormat] = useState<SupplyFormat>(initialFormat);
  const [application, setApplication] = useState<string>('');
  const [estimatedVolume, setEstimatedVolume] = useState<string>('500');
  const [volumeUnit, setVolumeUnit] = useState<VolumeUnit>('kg/day');
  const [frequency, setFrequency] = useState<SupplyFrequency>('scheduled_recurring');
  const [postcode, setPostcode] = useState<string>('');
  const [hasStorageSpace, setHasStorageSpace] = useState<boolean>(true);
  const [atexZoned, setAtexZoned] = useState<boolean>(false);
  const [offloadingAccess, setOffloadingAccess] = useState<string>('HGV access available');
  const [currentEnergySource, setCurrentEnergySource] = useState<string>('Natural Gas');
  const [fleetSize, setFleetSize] = useState<number>(10);
  const [vehicleType, setVehicleType] = useState<string>('Articulated HGVs');
  const [targetStartDate, setTargetStartDate] = useState<string>('Q4 2026');

  // Contact State
  const [fullName, setFullName] = useState<string>('');
  const [companyName, setCompanyName] = useState<string>('');
  const [jobTitle, setJobTitle] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [preferredContact, setPreferredContact] = useState<'email' | 'phone'>('email');
  const [additionalNotes, setAdditionalNotes] = useState<string>('');
  const [consentTerms, setConsentTerms] = useState<boolean>(false);

  // Submission State
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [submittedData, setSubmittedData] = useState<{
    referenceNumber: string;
    createdAt: string;
    emailStatus: string;
  } | null>(null);

  // Tracking enquiry state
  const [trackRef, setTrackRef] = useState<string>('');
  const [isTracking, setIsTracking] = useState<boolean>(false);
  const [trackResult, setTrackResult] = useState<any>(null);
  const [trackError, setTrackError] = useState<string | null>(null);

  const handleSelectCustomerType = (type: CustomerType) => {
    setCustomerType(type);
    if (type === 'household') {
      setEstimatedVolume('12');
      setVolumeUnit('kg/day');
      setFrequency('pilot_trial');
      setApplication('Residential heating & backup power microgrid assessment');
      setCurrentEnergySource('Mains Gas or Heating Oil');
      if (supplyFormat === 'liquid') {
        setSupplyFormat('gaseous');
      }
    } else if (type === 'transport') {
      setEstimatedVolume('1500');
      setVolumeUnit('kg/day');
      setFrequency('scheduled_recurring');
      setApplication('Depot bunkering for heavy transport fleet');
    } else if (type === 'industry') {
      setEstimatedVolume('3000');
      setVolumeUnit('kg/day');
      setFrequency('continuous_pipeline');
      setApplication('Industrial furnace process heat & metallurgical feedstock');
    } else {
      setEstimatedVolume('450');
      setVolumeUnit('kg/day');
      setFrequency('scheduled_recurring');
      setApplication('Commercial premises combined heat and power (CHP)');
    }
  };

  const handleNextStep = () => {
    setErrorMsg(null);
    if (step === 3 && application.trim().length < 5) {
      setErrorMsg('Please provide a brief description of your intended use.');
      return;
    }
    if (step === 4 && (!estimatedVolume || isNaN(Number(estimatedVolume)))) {
      setErrorMsg('Please specify a valid numeric estimated volume.');
      return;
    }
    if (step === 5) {
      const cleanPostcode = postcode.trim();
      if (cleanPostcode.length < 3) {
        setErrorMsg('Please enter a valid UK postcode (e.g. S9 1XH, CV3 4PW).');
        return;
      }
    }
    setStep(prev => Math.min(6, prev + 1));
  };

  const handlePrevStep = () => {
    setErrorMsg(null);
    setStep(prev => Math.max(1, prev - 1));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!fullName.trim()) {
      setErrorMsg('Please enter your full name.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }
    if (!phone.trim()) {
      setErrorMsg('Please enter a telephone number for engineering queries.');
      return;
    }
    if (!consentTerms) {
      setErrorMsg('Please confirm you accept the commercial feasibility terms.');
      return;
    }

    setIsSubmitting(true);

    try {
      const payload = {
        customerType,
        supplyFormat,
        application,
        estimatedVolume,
        volumeUnit,
        frequency,
        postcode: postcode.trim().toUpperCase(),
        siteDetails: {
          hasStorageSpace,
          atexZoned,
          offloadingAccess,
          currentEnergySource,
          fleetSize: customerType === 'transport' ? Number(fleetSize) : undefined,
          vehicleType: customerType === 'transport' ? vehicleType : undefined,
          targetStartDate,
        },
        contact: {
          fullName,
          companyName: companyName || undefined,
          jobTitle: jobTitle || undefined,
          email,
          phone,
          preferredContact,
          additionalNotes: additionalNotes || undefined,
          consentTerms,
        },
      };

      const res = await fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to submit enquiry');
      }

      setSubmittedData({
        referenceNumber: data.referenceNumber,
        createdAt: data.createdAt,
        emailStatus: data.emailStatus,
      });
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'An error occurred while submitting your quotation request.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleTrackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setTrackError(null);
    setTrackResult(null);

    if (!trackRef.trim()) {
      setTrackError('Please enter an H2UK reference number (e.g. H2UK-2026-8041)');
      return;
    }

    setIsTracking(true);
    try {
      const res = await fetch(`/api/enquiries?ref=${encodeURIComponent(trackRef.trim())}`);
      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'Reference number not found');
      }
      setTrackResult(data);
    } catch (err: any) {
      setTrackError(err.message || 'Unable to find enquiry record with this reference number.');
    } finally {
      setIsTracking(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />

      <main className="flex-1 py-12 sm:py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header Title & Mode Toggle */}
          <div className="text-center space-y-3 mb-10">
            <span className="text-xs font-bold tracking-[0.2em] text-[#0099FF] uppercase">
              Commercial Quotation Engine
            </span>
            <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
              Hydrogen Supply Feasibility & Quotation
            </h1>
            <p className="text-sm sm:text-base text-slate-600 max-w-2xl mx-auto">
              Tell us about your expected demand, site infrastructure, and operating location. Our engineering desk will evaluate feasibility and provide transparent commercial terms.
            </p>

            {/* Mode Switcher: New Enquiry vs Track Existing */}
            <div className="inline-flex p-1 bg-slate-200/80 rounded-xl mt-4">
              <button
                onClick={() => { setActiveTab('new_quote'); setErrorMsg(null); }}
                className={`px-5 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all ${
                  activeTab === 'new_quote' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                New Supply Enquiry
              </button>
              <button
                onClick={() => { setActiveTab('track_quote'); setErrorMsg(null); }}
                className={`px-5 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all ${
                  activeTab === 'track_quote' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Track Existing Quotation
              </button>
            </div>
          </div>

          {/* TAB 1: NEW QUOTATION FORM */}
          {activeTab === 'new_quote' && (
            <>
              {submittedData ? (
                /* SUCCESS CONFIRMATION VIEW */
                <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200 shadow-xl text-center space-y-6 animate-in fade-in zoom-in-95 duration-200">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>

                  <div className="space-y-2">
                    <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
                      Quotation Request Received
                    </h2>
                    <p className="text-sm text-slate-600 max-w-lg mx-auto">
                      Your technical supply request has been logged in the H2UK commercial engineering pipeline.
                    </p>
                  </div>

                  {/* Reference Number Box */}
                  <div className="p-5 bg-slate-50 border border-slate-200 rounded-2xl max-w-md mx-auto">
                    <div className="text-xs uppercase font-bold tracking-wider text-slate-500 mb-1">
                      Your Official Reference Number
                    </div>
                    <div className="text-2xl sm:text-3xl font-mono font-black text-[#0099FF] tracking-wider select-all">
                      {submittedData.referenceNumber}
                    </div>
                    <div className="text-xs text-slate-500 mt-2">
                      Please retain this reference for tracking and communications with our technical team.
                    </div>
                  </div>

                  {/* Email Dispatch Notice */}
                  <div className="p-4 bg-sky-50 border border-sky-100 rounded-xl max-w-md mx-auto text-left flex items-start gap-3">
                    <Mail className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
                    <div className="text-xs text-sky-900 leading-relaxed">
                      <strong>Transactional Confirmation Dispatched:</strong> A formal receipt with technical summary has been sent to <strong>{email}</strong>. Our commercial team will respond within 1–2 working days.
                    </div>
                  </div>

                  <div className="pt-4 flex flex-wrap justify-center gap-3">
                    <button
                      onClick={() => {
                        setSubmittedData(null);
                        setStep(1);
                        setFullName('');
                        setEmail('');
                        setPhone('');
                      }}
                      className="px-6 py-2.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-full transition-colors"
                    >
                      Submit Another Enquiry
                    </button>
                    <Link
                      href={`/quote?ref=${submittedData.referenceNumber}`}
                      onClick={() => {
                        setTrackRef(submittedData.referenceNumber);
                        setActiveTab('track_quote');
                        setSubmittedData(null);
                      }}
                      className="px-6 py-2.5 text-sm font-semibold text-white bg-[#0099FF] hover:bg-[#0088EE] rounded-full shadow-md"
                    >
                      Track This Status
                    </Link>
                  </div>
                </div>
              ) : (
                /* MULTI-STEP FORM CONTAINER */
                <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xl overflow-hidden">
                  {/* Step Progress Bar */}
                  <div className="bg-[#0B192C] px-6 sm:px-8 py-5 text-white">
                    <div className="flex items-center justify-between text-xs sm:text-sm font-semibold text-slate-300 mb-3">
                      <span>Step {step} of 6</span>
                      <span className="text-cyan-400">
                        {step === 1 && 'Customer Sector'}
                        {step === 2 && 'Supply Format'}
                        {step === 3 && 'Intended Application'}
                        {step === 4 && 'Volume & Frequency'}
                        {step === 5 && 'Location & Site Readiness'}
                        {step === 6 && 'Contact & Submission'}
                      </span>
                    </div>

                    {/* Progress Track */}
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-cyan-400 to-[#0099FF] h-full transition-all duration-300"
                        style={{ width: `${(step / 6) * 100}%` }}
                      />
                    </div>
                  </div>

                  {/* Form Content */}
                  <form onSubmit={handleSubmit} className="p-6 sm:p-10 space-y-8">
                    {/* STEP 1: Customer Type */}
                    {step === 1 && (
                      <div className="space-y-6">
                        <div className="space-y-1">
                          <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                            Select your customer sector
                          </h2>
                          <p className="text-xs sm:text-sm text-slate-600">
                            Each sector has distinct regulatory constraints, delivery requirements, and safety protocols.
                          </p>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {[
                            {
                              id: 'business' as CustomerType,
                              title: 'Commercial Business',
                              desc: 'Offices, retail, heating, backup power & CHP',
                              icon: <Building2 className="w-6 h-6 text-sky-600" />,
                            },
                            {
                              id: 'industry' as CustomerType,
                              title: 'Heavy Industry',
                              desc: 'High-temperature process heat, metallurgy & chemical feedstock',
                              icon: <Factory className="w-6 h-6 text-indigo-600" />,
                            },
                            {
                              id: 'transport' as CustomerType,
                              title: 'Transport & Fleet',
                              desc: 'Commercial HGVs, bus operators, refuelling depots & mobility',
                              icon: <Truck className="w-6 h-6 text-emerald-600" />,
                            },
                            {
                              id: 'household' as CustomerType,
                              title: 'Household / Domestic',
                              desc: 'Specialist heating trials, microgrids & off-grid backup',
                              icon: <Home className="w-6 h-6 text-amber-600" />,
                            },
                          ].map(item => (
                            <button
                              key={item.id}
                              type="button"
                              onClick={() => handleSelectCustomerType(item.id)}
                              className={`p-5 rounded-2xl border text-left transition-all flex items-start gap-4 ${
                                customerType === item.id
                                  ? 'border-[#0099FF] bg-sky-50/50 shadow-md ring-2 ring-sky-500/20'
                                  : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                              }`}
                            >
                              <div className="p-2.5 rounded-xl bg-white border border-slate-200 shadow-xs shrink-0">
                                {item.icon}
                              </div>
                              <div className="space-y-1">
                                <div className="text-base font-bold text-slate-900">{item.title}</div>
                                <div className="text-xs text-slate-600 leading-relaxed">{item.desc}</div>
                              </div>
                            </button>
                          ))}
                        </div>

                        {customerType === 'household' && (
                          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start gap-3">
                            <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                            <div>
                              <strong>Domestic Suitability Notice:</strong> Hydrogen heating is not currently available for ordinary mains-gas household connection. Inquiries for domestic properties are evaluated strictly for approved UK DESNZ trial zones, off-grid microgrids, or research demonstration projects.
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* STEP 2: Supply Format */}
                    {step === 2 && (
                      <div className="space-y-6">
                        <div className="space-y-1">
                          <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                            Required supply format
                          </h2>
                          <p className="text-xs sm:text-sm text-slate-600">
                            Choose between compressed gaseous delivery, bulk cryogenic liquid, or request engineering advisory.
                          </p>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                          {[
                            {
                              id: 'gaseous' as SupplyFormat,
                              title: 'Gaseous Hydrogen (GH2)',
                              desc: 'High-pressure tube trailers (200–500 bar) and manifold cylinder packs.',
                              icon: <Wind className="w-6 h-6 text-sky-600" />,
                              disabled: false,
                            },
                            {
                              id: 'liquid' as SupplyFormat,
                              title: 'Liquid Hydrogen (LH2)',
                              desc: 'Cryogenic -253°C bulk storage. Strictly for high-volume commercial or industrial sites.',
                              icon: <Snowflake className="w-6 h-6 text-cyan-600" />,
                              disabled: customerType === 'household',
                            },
                            {
                              id: 'unsure' as SupplyFormat,
                              title: 'Unsure / Consult H2UK',
                              desc: 'Our engineers will model your pressure, volume, and footprint to recommend the best option.',
                              icon: <HelpCircle className="w-6 h-6 text-slate-600" />,
                              disabled: false,
                            },
                          ].map(item => (
                            <button
                              key={item.id}
                              type="button"
                              disabled={item.disabled}
                              onClick={() => !item.disabled && setSupplyFormat(item.id)}
                              className={`p-5 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                                item.disabled
                                  ? 'opacity-40 cursor-not-allowed bg-slate-100 border-slate-200'
                                  : supplyFormat === item.id
                                  ? 'border-[#0099FF] bg-sky-50/50 shadow-md ring-2 ring-sky-500/20'
                                  : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                              }`}
                            >
                              <div className="p-2.5 rounded-xl bg-white border border-slate-200 shadow-xs shrink-0 w-fit mb-4">
                                {item.icon}
                              </div>
                              <div className="space-y-1">
                                <div className="text-base font-bold text-slate-900">{item.title}</div>
                                <div className="text-xs text-slate-600 leading-relaxed">{item.desc}</div>
                              </div>
                              {item.disabled && (
                                <span className="text-[11px] text-red-600 mt-2 font-medium">Not permitted for household</span>
                              )}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* STEP 3: Intended Application */}
                    {step === 3 && (
                      <div className="space-y-6">
                        <div className="space-y-1">
                          <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                            Application & Intended Use
                          </h2>
                          <p className="text-xs sm:text-sm text-slate-600">
                            Tell us what appliances, equipment, or thermal processes will be powered.
                          </p>
                        </div>

                        <div className="space-y-4">
                          <div>
                            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                              Intended Use Description <span className="text-red-500">*</span>
                            </label>
                            <textarea
                              rows={3}
                              value={application}
                              onChange={e => setApplication(e.target.value)}
                              placeholder="e.g. Glass furnace annealing line; 44t HGV fleet refuelling; CHP generator; domestic pilot microgrid"
                              className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-[#0099FF] focus:ring-2 focus:ring-sky-500/20 text-sm text-slate-900 placeholder-slate-400 outline-none"
                            />
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                                Current Energy Source Being Replaced
                              </label>
                              <select
                                value={currentEnergySource}
                                onChange={e => setCurrentEnergySource(e.target.value)}
                                className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-[#0099FF] text-sm text-slate-900 bg-white"
                              >
                                <option value="Natural Gas">Mains Natural Gas</option>
                                <option value="Diesel / Gas Oil">Diesel / Gas Oil</option>
                                <option value="LPG Bulk">LPG (Liquefied Petroleum Gas)</option>
                                <option value="Heavy Fuel Oil">Heavy Fuel Oil (HFO)</option>
                                <option value="Grid Electricity">Grid Electricity</option>
                                <option value="New Green Installation">New Zero-Emission Facility</option>
                              </select>
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                                Target Deployment Date
                              </label>
                              <select
                                value={targetStartDate}
                                onChange={e => setTargetStartDate(e.target.value)}
                                className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-[#0099FF] text-sm text-slate-900 bg-white"
                              >
                                <option value="Q3 2026">Q3 2026 (Immediate feasibility)</option>
                                <option value="Q4 2026">Q4 2026</option>
                                <option value="Q1 2027">Q1 2027</option>
                                <option value="Q2-Q4 2027">2027 Strategic Roadmap</option>
                                <option value="2028+">2028+ Long-term Planning</option>
                              </select>
                            </div>
                          </div>

                          {customerType === 'transport' && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-sky-50/60 rounded-xl border border-sky-100">
                              <div>
                                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                                  Fleet Size (Vehicles)
                                </label>
                                <input
                                  type="number"
                                  min="1"
                                  value={fleetSize}
                                  onChange={e => setFleetSize(Number(e.target.value))}
                                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                                />
                              </div>
                              <div>
                                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                                  Vehicle / Dispensing Type
                                </label>
                                <input
                                  type="text"
                                  value={vehicleType}
                                  onChange={e => setVehicleType(e.target.value)}
                                  placeholder="e.g. 44t HGVs (350 bar) or Hydrogen Buses"
                                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                                />
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* STEP 4: Volume & Frequency */}
                    {step === 4 && (
                      <div className="space-y-6">
                        <div className="space-y-1">
                          <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                            Estimated Volume & Supply Frequency
                          </h2>
                          <p className="text-xs sm:text-sm text-slate-600">
                            Volume sizing determines logistics method (tube trailer, cryogenic tanker, or cylinder bundles).
                          </p>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                              Estimated Quantity <span className="text-red-500">*</span>
                            </label>
                            <input
                              type="number"
                              min="1"
                              step="any"
                              value={estimatedVolume}
                              onChange={e => setEstimatedVolume(e.target.value)}
                              className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-[#0099FF] text-base font-semibold text-slate-900"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                              Measurement Unit
                            </label>
                            <select
                              value={volumeUnit}
                              onChange={e => setVolumeUnit(e.target.value as VolumeUnit)}
                              className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-[#0099FF] text-sm text-slate-900 bg-white"
                            >
                              <option value="kg/day">Kilograms per Day (kg/day)</option>
                              <option value="Nm3/hr">Normal Cubic Metres / Hour (Nm³/hr)</option>
                              <option value="tonnes/month">Tonnes per Month</option>
                              <option value="MWh/year">Megawatt-hours per Year (MWh/year)</option>
                              <option value="cylinders/month">Cylinder Packs / Month</option>
                            </select>
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                            Required Supply Frequency
                          </label>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            {[
                              { id: 'scheduled_recurring', label: 'Regular Scheduled Deliveries (Weekly / Bi-weekly)' },
                              { id: 'continuous_pipeline', label: 'Continuous High-Volume Offtake' },
                              { id: 'one_off', label: 'One-off Supply / Seasonal Peak' },
                              { id: 'pilot_trial', label: 'Trial Demonstration / Feasibility Pilot' },
                            ].map(freq => (
                              <button
                                key={freq.id}
                                type="button"
                                onClick={() => setFrequency(freq.id as SupplyFrequency)}
                                className={`p-3.5 rounded-xl border text-left text-xs sm:text-sm font-medium transition-all ${
                                  frequency === freq.id
                                    ? 'border-[#0099FF] bg-sky-50/60 font-semibold text-slate-900'
                                    : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                                }`}
                              >
                                {freq.label}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* STEP 5: Delivery Postcode & Site Requirements */}
                    {step === 5 && (
                      <div className="space-y-6">
                        <div className="space-y-1">
                          <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                            Location & Site Infrastructure
                          </h2>
                          <p className="text-xs sm:text-sm text-slate-600">
                            UK distribution distances and hazardous goods site clearance directly impact feasibility.
                          </p>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                              UK Delivery Postcode <span className="text-red-500">*</span>
                            </label>
                            <div className="relative">
                              <MapPin className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
                              <input
                                type="text"
                                value={postcode}
                                onChange={e => setPostcode(e.target.value)}
                                placeholder="e.g. S9 1XH, CV3 4PW"
                                className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-300 focus:border-[#0099FF] text-base font-semibold text-slate-900 uppercase"
                              />
                            </div>
                            <span className="text-[11px] text-slate-500 mt-1 block">
                              Used to calculate logistics distance to nearest UK production hub.
                            </span>
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                              Offloading Access Profile
                            </label>
                            <select
                              value={offloadingAccess}
                              onChange={e => setOffloadingAccess(e.target.value)}
                              className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-[#0099FF] text-sm text-slate-900 bg-white"
                            >
                              <option value="Dedicated 40ft HGV Turning Circle">Dedicated 40ft HGV Turning Circle</option>
                              <option value="Rigid Lorry Access (Up to 18t)">Rigid Lorry Access (Up to 18t)</option>
                              <option value="Light Commercial Vehicle (7.5t)">Light Commercial Vehicle (7.5t)</option>
                              <option value="Need Site Survey Assessment">Need Site Survey Assessment</option>
                            </select>
                          </div>
                        </div>

                        {/* Site Infrastructure Checkboxes */}
                        <div className="space-y-3 pt-2">
                          <label className="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={hasStorageSpace}
                              onChange={e => setHasStorageSpace(e.target.checked)}
                              className="w-4 h-4 text-[#0099FF] rounded mt-1 border-slate-300"
                            />
                            <div className="text-xs sm:text-sm">
                              <span className="font-semibold text-slate-900 block">External Storage Hardstanding Available</span>
                              <span className="text-slate-500">Site has secure, ventilated outdoor space for tube trailer parking or tank installation.</span>
                            </div>
                          </label>

                          <label className="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={atexZoned}
                              onChange={e => setAtexZoned(e.target.checked)}
                              className="w-4 h-4 text-[#0099FF] rounded mt-1 border-slate-300"
                            />
                            <div className="text-xs sm:text-sm">
                              <span className="font-semibold text-slate-900 block">Existing DSEAR / ATEX Hazardous Area Zoning</span>
                              <span className="text-slate-500">Site already handles flammable gases or has formal explosion-protection zone drawings.</span>
                            </div>
                          </label>
                        </div>
                      </div>
                    )}

                    {/* STEP 6: Contact Details & Consent */}
                    {step === 6 && (
                      <div className="space-y-6">
                        <div className="space-y-1">
                          <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                            Contact Information & Formal Consent
                          </h2>
                          <p className="text-xs sm:text-sm text-slate-600">
                            We will send your formal receipt reference and connect your enquiry with a sector lead.
                          </p>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                              Full Name <span className="text-red-500">*</span>
                            </label>
                            <input
                              type="text"
                              value={fullName}
                              onChange={e => setFullName(e.target.value)}
                              placeholder="e.g. Dr. Alistair Finch"
                              className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-[#0099FF] text-sm text-slate-900"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                              Company / Organisation {customerType !== 'household' && <span className="text-red-500">*</span>}
                            </label>
                            <input
                              type="text"
                              value={companyName}
                              onChange={e => setCompanyName(e.target.value)}
                              placeholder="e.g. Pennine Glass Ltd"
                              className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-[#0099FF] text-sm text-slate-900"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                              Email Address <span className="text-red-500">*</span>
                            </label>
                            <input
                              type="email"
                              value={email}
                              onChange={e => setEmail(e.target.value)}
                              placeholder="name@company.co.uk"
                              className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-[#0099FF] text-sm text-slate-900"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                              Telephone Number <span className="text-red-500">*</span>
                            </label>
                            <input
                              type="tel"
                              value={phone}
                              onChange={e => setPhone(e.target.value)}
                              placeholder="+44 7123 456789"
                              className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-[#0099FF] text-sm text-slate-900"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                            Additional Technical Notes or Requirements
                          </label>
                          <textarea
                            rows={2}
                            value={additionalNotes}
                            onChange={e => setAdditionalNotes(e.target.value)}
                            placeholder="Any specific delivery pressure, purity standards (e.g. Grade 5.0), or site access constraints."
                            className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900"
                          />
                        </div>

                        {/* Summary Box */}
                        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs text-slate-600">
                          <div className="font-bold text-slate-900 uppercase tracking-wider">Review Summary</div>
                          <div className="grid grid-cols-2 gap-2">
                            <div><strong className="text-slate-800">Sector:</strong> {customerType.toUpperCase()}</div>
                            <div><strong className="text-slate-800">Format:</strong> {supplyFormat.toUpperCase()}</div>
                            <div><strong className="text-slate-800">Volume:</strong> {estimatedVolume} {volumeUnit}</div>
                            <div><strong className="text-slate-800">Postcode:</strong> {postcode.toUpperCase()}</div>
                          </div>
                        </div>

                        {/* Consent Checkbox */}
                        <label className="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 bg-sky-50/30 hover:bg-sky-50/60 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={consentTerms}
                            onChange={e => setConsentTerms(e.target.checked)}
                            className="w-4 h-4 text-[#0099FF] rounded mt-0.5 border-slate-300"
                          />
                          <div className="text-xs text-slate-700 leading-relaxed">
                            I confirm that the details provided are accurate for commercial review. I understand that submitting this enquiry does not constitute an agreement or binding guarantee of hydrogen supply, and that final terms depend on engineering hazard reviews and logistical scheduling.
                          </div>
                        </label>
                      </div>
                    )}

                    {/* Error Notice */}
                    {errorMsg && (
                      <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-xs sm:text-sm text-red-700 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                        <span>{errorMsg}</span>
                      </div>
                    )}

                    {/* Navigation Buttons */}
                    <div className="flex items-center justify-between pt-6 border-t border-slate-200">
                      {step > 1 ? (
                        <button
                          type="button"
                          onClick={handlePrevStep}
                          className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-full transition-colors"
                        >
                          <ArrowLeft className="w-4 h-4" />
                          <span>Back</span>
                        </button>
                      ) : (
                        <div />
                      )}

                      {step < 6 ? (
                        <button
                          type="button"
                          onClick={handleNextStep}
                          className="inline-flex items-center gap-2 px-7 py-3 text-sm font-semibold text-white bg-[#0099FF] hover:bg-[#0088EE] rounded-full shadow-md transition-all hover:-translate-y-0.5"
                        >
                          <span>Continue</span>
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      ) : (
                        <button
                          type="submit"
                          disabled={isSubmitting}
                          className="inline-flex items-center gap-2 px-8 py-3.5 text-sm font-bold text-white bg-[#0099FF] hover:bg-[#0088EE] active:bg-[#0077DD] disabled:opacity-50 rounded-full shadow-lg shadow-sky-500/30 transition-all hover:-translate-y-0.5"
                        >
                          {isSubmitting ? (
                            <span>Logging Enquiry...</span>
                          ) : (
                            <>
                              <span>Submit Quotation Request</span>
                              <CheckCircle2 className="w-4 h-4" />
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  </form>
                </div>
              )}
            </>
          )}

          {/* TAB 2: TRACK EXISTING ENQUIRY */}
          {activeTab === 'track_quote' && (
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-6 sm:p-10 space-y-8 animate-in fade-in duration-150">
              <div className="space-y-2 text-center max-w-md mx-auto">
                <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                  Track Your Quotation Status
                </h2>
                <p className="text-xs sm:text-sm text-slate-600">
                  Enter your H2UK Reference Number to view real-time pipeline status and engineering progress.
                </p>
              </div>

              {/* Input Form */}
              <form onSubmit={handleTrackSubmit} className="max-w-md mx-auto flex gap-2">
                <input
                  type="text"
                  value={trackRef}
                  onChange={e => setTrackRef(e.target.value)}
                  placeholder="e.g. H2UK-2026-8041"
                  className="flex-1 px-4 py-3 rounded-xl border border-slate-300 focus:border-[#0099FF] text-sm font-mono uppercase font-semibold text-slate-900"
                />
                <button
                  type="submit"
                  disabled={isTracking}
                  className="px-6 py-3 bg-[#0099FF] hover:bg-[#0088EE] text-white font-semibold text-sm rounded-xl transition-colors shrink-0"
                >
                  {isTracking ? 'Searching...' : 'Check Status'}
                </button>
              </form>

              {/* Sample Quick Try */}
              <div className="text-center text-xs text-slate-500">
                <span>Try sample references: </span>
                <button
                  onClick={() => setTrackRef('H2UK-2026-8041')}
                  className="text-[#0099FF] font-mono hover:underline mr-2"
                >
                  H2UK-2026-8041
                </button>
                <button
                  onClick={() => setTrackRef('H2UK-2026-8042')}
                  className="text-[#0099FF] font-mono hover:underline"
                >
                  H2UK-2026-8042
                </button>
              </div>

              {trackError && (
                <div className="max-w-md mx-auto p-3.5 rounded-xl bg-red-50 border border-red-200 text-xs sm:text-sm text-red-700 text-center">
                  {trackError}
                </div>
              )}

              {/* Results View */}
              {trackResult && (
                <div className="max-w-xl mx-auto bg-slate-50 border border-slate-200 rounded-2xl p-6 space-y-5 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-4">
                    <div>
                      <span className="text-xs uppercase tracking-wider text-slate-500 font-bold">Reference</span>
                      <div className="text-lg font-mono font-bold text-slate-900">{trackResult.referenceNumber}</div>
                    </div>
                    <div>
                      <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                        trackResult.status === 'quoted'
                          ? 'bg-emerald-100 text-emerald-800'
                          : trackResult.status === 'under_review'
                          ? 'bg-sky-100 text-sky-800'
                          : trackResult.status === 'clarification_required'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-200 text-slate-700'
                      }`}>
                        {trackResult.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs sm:text-sm text-slate-700">
                    <div>
                      <span className="text-slate-500 block">Sector</span>
                      <strong className="capitalize">{trackResult.customerType}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Format</span>
                      <strong className="capitalize">{trackResult.supplyFormat} Hydrogen</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Submitted At</span>
                      <span>{new Date(trackResult.createdAt).toLocaleDateString('en-GB')}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Last Activity</span>
                      <span>{new Date(trackResult.updatedAt).toLocaleDateString('en-GB')}</span>
                    </div>
                  </div>

                  {/* Audit History */}
                  <div className="pt-3 border-t border-slate-200">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                      Pipeline Activity Log
                    </span>
                    <div className="space-y-2">
                      {trackResult.auditHistory.map((item: any, i: number) => (
                        <div key={i} className="text-xs text-slate-600 flex items-start gap-2">
                          <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                          <div>
                            <span className="font-semibold text-slate-800">{item.action.replace('_', ' ')}</span>
                            {item.details && <span className="text-slate-500"> — {item.details}</span>}
                            <div className="text-[10px] text-slate-400">
                              {new Date(item.timestamp).toLocaleString('en-GB')}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default function QuotePage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex flex-col bg-slate-50">
          <Navbar />
          <main className="flex-1 flex items-center justify-center p-12">
            <div className="text-center space-y-3">
              <div className="w-10 h-10 border-4 border-sky-200 border-t-[#0099FF] rounded-full animate-spin mx-auto" />
              <p className="text-sm font-semibold text-slate-600">Loading H2UK Quotation Engine...</p>
            </div>
          </main>
          <Footer />
        </div>
      }
    >
      <QuoteForm />
    </Suspense>
  );
}
