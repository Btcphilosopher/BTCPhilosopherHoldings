'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Mail, Phone, MapPin, CheckCircle2, AlertCircle, Send, ArrowRight } from 'lucide-react';

export default function ContactPage() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [company, setCompany] = useState('');
  const [subject, setSubject] = useState('Commercial Hydrogen Supply Enquiry');
  const [message, setMessage] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!fullName || !email || !message) {
      setErrorMsg('Please complete all required fields.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName,
          email,
          phone: phone || undefined,
          company: company || undefined,
          subject,
          message,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to submit message');
      }

      setSubmitted(true);
    } catch (err: any) {
      setErrorMsg(err.message || 'An error occurred while sending your message.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />

      <main className="flex-1">
        <section className="bg-[#0A1628] py-16 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl space-y-3">
              <span className="text-xs font-bold tracking-[0.2em] text-cyan-400 uppercase">
                Commercial & Engineering Enquiries
              </span>
              <h1 className="text-4xl font-black tracking-tight text-white">
                Contact H2UK
              </h1>
              <p className="text-base text-slate-300 leading-relaxed">
                Connect with our commercial engineering team to discuss off-take requirements, regional distribution feasibility, or site hazard assessments.
              </p>
            </div>
          </div>
        </section>

        <section className="py-16 bg-slate-50 border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
              {/* Contact Information & Channels */}
              <div className="lg:col-span-5 space-y-6">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-[#0099FF]">British Supply Desk</span>
                  <h2 className="text-2xl font-bold text-slate-900 mt-1">Get in Touch with our Team</h2>
                  <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                    Our technical desk reviews enquiries across household pilot schemes, commercial logistics, and high-volume industrial contracts.
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-sky-50 flex items-center justify-center text-sky-600 shrink-0">
                      <Mail className="w-5 h-5" />
                    </div>
                    <div>
                      <strong className="text-xs font-bold text-slate-900 uppercase tracking-wider block">Commercial Inquiries</strong>
                      <a href="mailto:enquiries@h2uk.energy" className="text-sm text-[#0099FF] hover:underline font-medium">
                        enquiries@h2uk.energy
                      </a>
                      <span className="text-xs text-slate-500 block mt-0.5">Average response: within 1 business day</span>
                    </div>
                  </div>

                  <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-cyan-50 flex items-center justify-center text-cyan-600 shrink-0">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <strong className="text-xs font-bold text-slate-900 uppercase tracking-wider block">Technical Desk & Helpline</strong>
                      <span className="text-sm text-slate-800 font-medium">0800 422 4228</span>
                      <span className="text-xs text-slate-500 block mt-0.5">Monday to Friday: 08:30 – 17:30 UK Time</span>
                    </div>
                  </div>

                  <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600 shrink-0">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                      <strong className="text-xs font-bold text-slate-900 uppercase tracking-wider block">UK Production & Corridors</strong>
                      <span className="text-sm text-slate-800">Humber, Teesside, Mersey & Scottish Clusters</span>
                      <span className="text-xs text-slate-500 block mt-0.5">Strategic British supply network</span>
                    </div>
                  </div>
                </div>

                <div className="p-5 bg-sky-50/70 border border-sky-200/80 rounded-2xl text-xs text-sky-900 space-y-1">
                  <strong>Looking for a Formal Supply Quotation?</strong>
                  <p>For detailed volume, pressure, and delivery postcode modeling, use our multi-step quotation engine.</p>
                  <div className="pt-2">
                    <Link href="/quote" className="font-bold text-[#0099FF] hover:underline inline-flex items-center gap-1">
                      <span>Open Quotation Engine</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
              </div>

              {/* Message Submission Form */}
              <div className="lg:col-span-7">
                <div className="bg-white rounded-3xl border border-slate-200 shadow-lg p-6 sm:p-10">
                  {submitted ? (
                    <div className="text-center py-12 space-y-4 animate-in fade-in">
                      <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                        <CheckCircle2 className="w-10 h-10" />
                      </div>
                      <h3 className="text-2xl font-black text-slate-900">Message Received</h3>
                      <p className="text-sm text-slate-600 max-w-md mx-auto">
                        Thank you for contacting H2UK. An engineer from our commercial supply desk will review your inquiry and follow up shortly.
                      </p>
                      <button
                        onClick={() => {
                          setSubmitted(false);
                          setMessage('');
                        }}
                        className="mt-4 px-6 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-full"
                      >
                        Send Another Message
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-5">
                      <h3 className="text-xl font-bold text-slate-900">Send an Enquiry</h3>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                            Full Name <span className="text-red-500">*</span>
                          </label>
                          <input
                            type="text"
                            required
                            value={fullName}
                            onChange={e => setFullName(e.target.value)}
                            placeholder="e.g. Robert Henderson"
                            className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:border-[#0099FF] outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                            Email Address <span className="text-red-500">*</span>
                          </label>
                          <input
                            type="email"
                            required
                            value={email}
                            onChange={e => setEmail(e.target.value)}
                            placeholder="name@company.co.uk"
                            className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:border-[#0099FF] outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                            Telephone Number
                          </label>
                          <input
                            type="tel"
                            value={phone}
                            onChange={e => setPhone(e.target.value)}
                            placeholder="+44 7123 456789"
                            className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:border-[#0099FF] outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                            Company / Organisation
                          </label>
                          <input
                            type="text"
                            value={company}
                            onChange={e => setCompany(e.target.value)}
                            placeholder="e.g. Solway Maritime"
                            className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:border-[#0099FF] outline-none"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                          Enquiry Subject
                        </label>
                        <select
                          value={subject}
                          onChange={e => setSubject(e.target.value)}
                          className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                        >
                          <option value="Commercial Hydrogen Supply Enquiry">Commercial Hydrogen Supply Enquiry</option>
                          <option value="Industrial Process Heat Consultation">Industrial Process Heat Consultation</option>
                          <option value="Fleet / Transport Refuelling Project">Fleet / Transport Refuelling Project</option>
                          <option value="Domestic Pilot Demonstration Inquiry">Domestic Pilot Demonstration Inquiry</option>
                          <option value="Technical Safety & DSEAR Compliance">Technical Safety & DSEAR Compliance</option>
                          <option value="Media & Commercial Partnerships">Media & Commercial Partnerships</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                          Message <span className="text-red-500">*</span>
                        </label>
                        <textarea
                          rows={4}
                          required
                          value={message}
                          onChange={e => setMessage(e.target.value)}
                          placeholder="Provide details about your operational requirements, location, or technical questions..."
                          className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:border-[#0099FF] outline-none"
                        />
                      </div>

                      {errorMsg && (
                        <div className="p-3 bg-red-50 border border-red-200 text-xs text-red-700 rounded-xl flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 shrink-0" />
                          <span>{errorMsg}</span>
                        </div>
                      )}

                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className="px-7 py-3 bg-[#0099FF] hover:bg-[#0088EE] text-white text-sm font-semibold rounded-full shadow-md transition-all disabled:opacity-50 inline-flex items-center gap-2"
                      >
                        {isSubmitting ? 'Sending...' : 'Send Message'}
                        <Send className="w-4 h-4" />
                      </button>
                    </form>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
