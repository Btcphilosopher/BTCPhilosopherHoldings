import React from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import TrustStrip from '@/components/TrustStrip';
import SectorsSection from '@/components/SectorsSection';
import SupplyFormatsSection from '@/components/SupplyFormatsSection';
import HowItWorksSection from '@/components/HowItWorksSection';
import WhyH2UKSection from '@/components/WhyH2UKSection';
import ClosingBanner from '@/components/ClosingBanner';
import Footer from '@/components/Footer';

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900 selection:bg-cyan-200 selection:text-slate-900">
      {/* 3A. Navigation Bar with 3-Zone Contract & Dropdowns */}
      <Navbar />

      <main className="flex-1">
        {/* 3B. Hero Section Matching Reference Mockup */}
        <Hero />

        {/* 3C. Four-Point Trust Strip */}
        <TrustStrip />

        {/* 3D. Hydrogen for Every Sector Grid */}
        <SectorsSection />

        {/* 3E. Supply Formats: Gaseous vs Liquid Comparison & Interactive Sizer */}
        <SupplyFormatsSection />

        {/* 3F. Transparent 4-Step Commercial & Feasibility Process */}
        <HowItWorksSection />

        {/* 3G. Why H2UK: Strategic Supply, Engineering & Sourcing Provenance */}
        <WhyH2UKSection />

        {/* 3H. Closing CTA Banner with British Landscape Backdrop */}
        <ClosingBanner />
      </main>

      {/* Comprehensive British Energy Footer */}
      <Footer />
    </div>
  );
}
