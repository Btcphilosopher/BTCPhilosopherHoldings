import { MetadataRoute } from 'next';

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = 'https://ais-dev-mhwvaysk7kov3ir2lb4snt-870496719167.europe-west2.run.app';
  const routes = [
    '',
    '/for-homes',
    '/for-businesses',
    '/industry',
    '/transport',
    '/our-supply',
    '/quote',
    '/about',
    '/news',
    '/safety',
    '/sustainability',
    '/faqs',
    '/contact',
    '/privacy',
    '/terms',
    '/cookies',
    '/accessibility',
  ];

  return routes.map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: route === '' ? 'daily' : 'weekly',
    priority: route === '' ? 1.0 : route === '/quote' ? 0.9 : 0.8,
  }));
}
