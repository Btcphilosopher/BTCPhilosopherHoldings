import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ClosingBanner from '@/components/ClosingBanner';
import { Factory, ArrowRight, CheckCircle2, ShieldCheck, Flame, Layers, Gauge, Cpu } from 'lucide-react';

export default function IndustryPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />

      <main className="flex-1">
        {/* Hero */}
        <section className="relative bg-[#0A1628] py-20 text-white overflow-hidden">
          <div className="absolute inset-0 z-0 opacity-25">
            <Image
              src="/images/sector_industry.jpg"
              alt="Heavy British industrial hydrogen processing plant"
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl space-y-4">
              <span className="text-xs font-bold tracking-[0.2em] text-cyan-400 uppercase">
                Heavy Industry & Decarbonisation
              </span>
              <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-white">
                Bulk Industrial Hydrogen & Process Heat
              </h1>
              <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
                High-volume Grade 5.0 hydrogen supply for chemical synthesis, metallurgical furnaces, glass manufacturing, and heavy engineering across Great Britain.
              </p>
              <div className="pt-2">
                <Link
                  href="/quote?sector=industry"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-[#0099FF] hover:bg-[#0088EE] text-white font-semibold text-sm rounded-full shadow-lg"
                >
                  <span>Request Engineering Consultation</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Industrial Standards Strip */}
        <section className="bg-slate-900 py-6 text-white border-b border-slate-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center text-xs sm:text-sm">
              <div>
                <span className="text-cyan-400 font-bold block text-base font-mono">99.999%</span>
                <span className="text-slate-400">Grade 5.0 High Purity</span>
              </div>
              <div>
                <span className="text-cyan-400 font-bold block text-base font-mono">&lt; 1 ppm</span>
                <span className="text-slate-400">Moisture Content</span>
              </div>
              <div>
                <span className="text-cyan-400 font-bold block text-base font-mono">200–500 Bar</span>
                <span className="text-slate-400">Tube Trailer Pressure</span>
              </div>
              <div>
                <span className="text-cyan-400 font-bold block text-base font-mono">ISO 14687</span>
                <span className="text-slate-400">Quality Specification</span>
              </div>
            </div>
          </div>
        </section>

        {/* Core Industrial Sectors */}
        <section className="py-16 bg-slate-50 border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto space-y-2 mb-12">
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
                Industrial Applications Supported
              </h2>
              <p className="text-sm text-slate-600">
                Engineered off-take arrangements designed around hazardous process integration.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <div className="w-10 h-10 rounded-xl bg-sky-100 flex items-center justify-center text-sky-600 font-bold">
                  <Flame className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">High-Temperature Thermal Heat</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Glass annealing, ceramic kilns, and metal smelting requiring temperatures exceeding 1,000°C where electrification is physically or commercially unviable.
                </p>
              </div>

              <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-100 flex items-center justify-center text-cyan-600 font-bold">
                  <Layers className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Chemical Synthesis & Refining</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Direct feedstock supply for ammonia production, polymers, hydrogenation, and refinery desulfurisation under certified low-carbon standards.
                </p>
              </div>

              <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-600 font-bold">
                  <Cpu className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Steel & Metallurgical Annealing</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Inert and reducing atmosphere gas shielding for precision heat treatment of specialty alloys, wire rod annealing, and direct reduction of iron ore (DRI).
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Industrial Engineering Logistics */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-4">
                <span className="text-xs font-bold uppercase tracking-wider text-[#0099FF]">Engineering Rigour</span>
                <h2 className="text-3xl font-black text-slate-900">Turnkey Offloading & Manifold Skid Integration</h2>
                <p className="text-sm text-slate-600 leading-relaxed">
                  High-volume industrial supply demands precise pressure regulation, automated changeover manifolds, and strict adherence to DSEAR (Dangerous Substances and Explosive Atmospheres Regulations 2002). Our engineering team assists with:
                </p>

                <div className="space-y-3 pt-2">
                  <div className="flex items-center gap-3 text-xs sm:text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Dual-bay tube trailer offloading skids with auto-switching</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs sm:text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Emergency shutdown (ESD) telemetry integrated with plant SCADA</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs sm:text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Hazardous area classification (ATEX Zones 0, 1, and 2) drawing reviews</span>
                  </div>
                </div>

                <div className="pt-4">
                  <Link
                    href="/quote?sector=industry"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-[#0099FF] hover:bg-[#0088EE] text-white text-sm font-semibold rounded-full shadow-md"
                  >
                    <span>Submit Industrial Specification Enquiry</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>

              <div className="p-8 bg-slate-900 text-white rounded-3xl border border-slate-800 space-y-4">
                <h3 className="text-lg font-bold text-cyan-400">Purity Guarantee</h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  Every delivery is accompanied by an analytical certificate of analysis (COA) confirming gas chromatography testing for oxygen, nitrogen, carbon monoxide, carbon dioxide, and total hydrocarbons.
                </p>
                <div className="p-4 bg-slate-800/80 rounded-xl border border-slate-700 text-xs font-mono space-y-1">
                  <div>H2 Assay: ≥ 99.999%</div>
                  <div>H2O: ≤ 1.0 ppmv</div>
                  <div>O2: ≤ 1.0 ppmv</div>
                  <div>Total Hydrocarbons: ≤ 0.5 ppmv</div>
                  <div>CO / CO2: ≤ 0.2 ppmv</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ClosingBanner />
      </main>

      <Footer />
    </div>
  );
}
