import React from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function PrivacyPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />
      <main className="flex-1 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <span className="text-xs font-bold uppercase tracking-wider text-[#0099FF]">Legal & Data Protection</span>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-900">Privacy Policy</h1>
          <div className="prose prose-slate text-xs sm:text-sm leading-relaxed space-y-4 text-slate-700">
            <p>
              H2UK is committed to safeguarding personal information collected through our quotation engine and digital platforms, in compliance with the UK General Data Protection Regulation (UK GDPR) and the Data Protection Act 2018.
            </p>
            <h3 className="text-base font-bold text-slate-900 mt-4">1. Data We Collect</h3>
            <p>
              When you submit a quotation inquiry or contact request, we collect contact details (name, email address, telephone number, job title, and organisation) alongside technical site parameters (postcode, energy consumption, and infrastructure characteristics) strictly necessary for assessing supply feasibility.
            </p>
            <h3 className="text-base font-bold text-slate-900 mt-4">2. Purpose of Processing</h3>
            <p>
              We process your data to model distribution distance, calculate technical pressure and volume requirements, issue preliminary commercial quotations, and communicate feasibility findings.
            </p>
            <h3 className="text-base font-bold text-slate-900 mt-4">3. Data Retention & Security</h3>
            <p>
              Commercial quotation records and site hazard data are retained securely for a period appropriate to industrial procurement cycles. We do not sell or transfer customer data to third-party marketing entities.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
