'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ClosingBanner from '@/components/ClosingBanner';
import { Home, AlertTriangle, CheckCircle2, Flame, ArrowRight, ShieldCheck, HelpCircle, FileText } from 'lucide-react';

export default function ForHomesPage() {
  const [propertyType, setPropertyType] = useState('detached');
  const [heatingSystem, setHeatingSystem] = useState('gas_boiler');
  const [postcode, setPostcode] = useState('');
  const [suitabilityResult, setSuitabilityResult] = useState<string | null>(null);

  const checkSuitability = (e: React.FormEvent) => {
    e.preventDefault();
    if (!postcode) return;
    const cleanPostcode = postcode.trim().toUpperCase();

    // Educational assessment based on UK DESNZ policy realities
    if (heatingSystem === 'heat_pump') {
      setSuitabilityResult('Heat pump already installed. Hydrogen heating conversion is generally not cost-effective for properties already electrified with high-efficiency heat pumps.');
    } else {
      setSuitabilityResult(`Suitability assessed for postcode ${cleanPostcode}. Hydrogen heating is currently restricted to government-approved trial areas and rural microgrid pilot projects. Ordinary mains gas networks do not currently supply 100% hydrogen to domestic households. You may register for local pilot notifications.`);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-[#0A1628] py-20 text-white overflow-hidden">
          <div className="absolute inset-0 z-0 opacity-25">
            <Image
              src="/images/sector_homes.jpg"
              alt="Modern British residential home with solar panels"
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl space-y-4">
              <span className="text-xs font-bold tracking-[0.2em] text-cyan-400 uppercase">
                Domestic Energy Evaluation
              </span>
              <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-white">
                Hydrogen for Homes: Facts, Trials & Future Heating
              </h1>
              <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
                Clear, transparent guidance on domestic hydrogen applications, appliance compatibility, UK Government trial zones, and off-grid microgrids.
              </p>
            </div>
          </div>
        </section>

        {/* Regulatory Truth Banner */}
        <section className="bg-amber-50 border-b border-amber-200 py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
              <div className="text-xs sm:text-sm text-amber-900 leading-relaxed">
                <strong>Important Consumer Disclosure:</strong> 100% hydrogen heating is not universally available for British homes today. Sponsoring trials by the UK Department for Energy Security and Net Zero (DESNZ) and Gas Distribution Networks (GDNs) are currently testing safety and feasibility. We do not promise domestic mains supply unless your property is part of an approved trial scheme.
              </div>
            </div>
          </div>
        </section>

        {/* Key Domestic Pillars */}
        <section className="py-16 bg-slate-50 border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto space-y-2 mb-12">
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
                Where Can Hydrogen Fit in the Home?
              </h2>
              <p className="text-sm text-slate-600">
                Understanding realistic technical applications versus regulatory boundaries.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <div className="w-10 h-10 rounded-xl bg-sky-100 flex items-center justify-center text-sky-600 font-bold">
                  01
                </div>
                <h3 className="text-lg font-bold text-slate-900">Off-Grid Rural Microgrids</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  For isolated rural estates not connected to the national gas grid currently reliant on costly heating oil or bottled LPG, localized hydrogen storage combined with fuel cells offers clean seasonal energy storage.
                </p>
              </div>

              <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-100 flex items-center justify-center text-cyan-600 font-bold">
                  02
                </div>
                <h3 className="text-lg font-bold text-slate-900">Hydrogen-Ready Boilers</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Leading British heating manufacturers have developed appliances capable of operating on standard natural gas today, with the ability to be converted to 100% hydrogen via a simple technician visit if the local grid transitions.
                </p>
              </div>

              <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-600 font-bold">
                  03
                </div>
                <h3 className="text-lg font-bold text-slate-900">20% Hydrogen Blending</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Ongoing network trials test blending up to 20% hydrogen by volume into the national transmission system, reducing emissions without requiring any modifications to existing household boilers or hobs.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Domestic Suitability Interactive Checker */}
        <section className="py-16 bg-white" id="suitability">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-slate-50 border border-slate-200 rounded-3xl p-6 sm:p-10 shadow-lg">
              <div className="max-w-xl space-y-2 mb-6">
                <span className="text-xs font-bold uppercase tracking-wider text-[#0099FF]">Eligibility Tool</span>
                <h2 className="text-2xl font-bold text-slate-900">Check Your Domestic Pilot Readiness</h2>
                <p className="text-xs sm:text-sm text-slate-600">
                  Assess whether your property could participate in off-grid pilot demonstrations or community trial zones.
                </p>
              </div>

              <form onSubmit={checkSuitability} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                      Property Type
                    </label>
                    <select
                      value={propertyType}
                      onChange={e => setPropertyType(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm"
                    >
                      <option value="detached">Detached House (with outdoor garden/land)</option>
                      <option value="semi">Semi-Detached House</option>
                      <option value="terraced">Terraced Property</option>
                      <option value="flat">Apartment / Flat</option>
                      <option value="rural">Rural Smallholding / Farmhouse</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                      Current Heating System
                    </label>
                    <select
                      value={heatingSystem}
                      onChange={e => setHeatingSystem(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm"
                    >
                      <option value="gas_boiler">Mains Natural Gas Boiler</option>
                      <option value="oil">Heating Oil Tank (Kerosene)</option>
                      <option value="lpg">LPG Tank or Bottles</option>
                      <option value="heat_pump">Air/Ground Source Heat Pump</option>
                      <option value="direct_electric">Electric Storage Heaters</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    UK Postcode
                  </label>
                  <input
                    type="text"
                    value={postcode}
                    onChange={e => setPostcode(e.target.value)}
                    placeholder="e.g. EH42 1XF or OX1 1AB"
                    className="w-full sm:w-1/2 px-3.5 py-2.5 rounded-xl border border-slate-300 uppercase font-semibold text-xs sm:text-sm"
                  />
                </div>

                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#0099FF] hover:bg-[#0088EE] text-white text-xs sm:text-sm font-semibold rounded-full shadow-sm"
                >
                  Evaluate Domestic Suitability
                </button>
              </form>

              {suitabilityResult && (
                <div className="mt-6 p-4 rounded-2xl bg-white border border-slate-200 text-xs sm:text-sm text-slate-700 leading-relaxed animate-in fade-in">
                  <div className="font-bold text-slate-900 mb-1">Assessment Outcome:</div>
                  <p>{suitabilityResult}</p>
                  <div className="mt-3">
                    <Link
                      href="/quote?sector=household"
                      className="text-xs font-bold text-[#0099FF] hover:underline inline-flex items-center gap-1"
                    >
                      <span>Submit a domestic demonstration enquiry</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>

        <ClosingBanner />
      </main>

      <Footer />
    </div>
  );
}
