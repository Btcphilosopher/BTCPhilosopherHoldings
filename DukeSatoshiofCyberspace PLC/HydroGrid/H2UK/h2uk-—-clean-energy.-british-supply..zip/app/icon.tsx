import { ImageResponse } from 'next/og';

export const size = {
  width: 32,
  height: 32,
};
export const contentType = 'image/png';

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          fontSize: 16,
          background: '#0B192C',
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          borderRadius: 8,
          fontWeight: 800,
          color: '#00C2CB',
          border: '1px solid #0099FF',
        }}
      >
        H₂
      </div>
    ),
    {
      ...size,
    }
  );
}
