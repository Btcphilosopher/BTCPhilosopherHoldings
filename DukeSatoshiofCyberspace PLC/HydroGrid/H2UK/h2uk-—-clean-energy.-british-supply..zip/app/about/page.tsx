import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ClosingBanner from '@/components/ClosingBanner';
import { Compass, ShieldCheck, Flag, Users, ArrowRight, FileText } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />

      <main className="flex-1">
        {/* Hero */}
        <section className="relative bg-[#0A1628] py-20 text-white overflow-hidden">
          <div className="absolute inset-0 z-0 opacity-25">
            <Image
              src="/images/banner_clean_energy.jpg"
              alt="British coastal hills with renewable wind energy"
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl space-y-4">
              <span className="text-xs font-bold tracking-[0.2em] text-cyan-400 uppercase">
                Clean Energy. British Supply.
              </span>
              <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-white">
                About H2UK: Britain&apos;s Hydrogen Supply Partner
              </h1>
              <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
                Dedicated to establishing secure, transparent, and practical hydrogen supply channels for British industry, transport, and commercial energy users.
              </p>
            </div>
          </div>
        </section>

        {/* Brand Mission Statement */}
        <section className="py-16 bg-white border-b border-slate-200">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
            <div className="space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-[#0099FF]">Our Mission</span>
              <h2 className="text-3xl font-black text-slate-900 leading-tight">
                Accelerating the UK&apos;s Practical Clean Energy Transition
              </h2>
              <p className="text-base text-slate-700 leading-relaxed">
                The UK has world-leading offshore wind resources and ambitious statutory commitments to achieve Net Zero greenhouse gas emissions by 2050. However, critical sectors of the British economy — heavy road freight, high-temperature industrial kilns, glass annealing, and seasonal backup power — cannot be decarbonised by electrification alone.
              </p>
              <p className="text-base text-slate-700 leading-relaxed">
                H2UK was conceived to bridge the gap between regional hydrogen producers and forward-thinking energy consumers. By offering flexible gaseous tube trailers and bulk cryogenic liquid deliveries with verified provenance, we provide commercial operators with a pragmatic pathway away from fossil natural gas and diesel.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6">
              <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="w-10 h-10 rounded-xl bg-sky-100 flex items-center justify-center text-sky-600 mb-2">
                  <Compass className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900">Sovereign Supply</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Focusing on British domestic production hubs to support national energy resilience and create high-value engineering jobs across industrial clusters.
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="w-10 h-10 rounded-xl bg-cyan-100 flex items-center justify-center text-cyan-600 mb-2">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900">Technical Competence</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Led by hazardous-process chemical engineers and logistics specialists with deep understanding of DSEAR, ATEX, and pressure system safety.
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-600 mb-2">
                  <FileText className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900">Carbon Provenance</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Complete carbon lifecycle reporting compliant with the UK Low Carbon Hydrogen Standard (LCHS), avoiding greenwashing clichés.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Commercial Pipeline Transparency */}
        <section className="py-16 bg-slate-50 border-b border-slate-200">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
            <span className="text-xs font-bold uppercase tracking-wider text-[#0099FF]">Transparency & Governance</span>
            <h2 className="text-3xl font-black text-slate-900">
              Aligning with the UK Hydrogen Strategy
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed">
              H2UK is actively developing commercial off-take partnerships across major UK industrial clusters, including the Humber, Teesside, Mersey, and Scottish ports. In accordance with honest commercial practice, our commercial roadmap targets scalable production allocation rounds (HAR) and private industrial supply agreements.
            </p>

            <div className="p-6 bg-white rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-700 leading-relaxed space-y-3">
              <p>
                <strong>Operational Status & Drafting Notice:</strong> The information provided on this platform represents H2UK commercial planning proposals and feasibility services. H2UK does not fabricate registered company credentials, unverified accreditations, or fictitious operating histories. All supply contracts are executed following full site hazard and DSEAR survey execution.
              </p>
            </div>
          </div>
        </section>

        <ClosingBanner />
      </main>

      <Footer />
    </div>
  );
}
