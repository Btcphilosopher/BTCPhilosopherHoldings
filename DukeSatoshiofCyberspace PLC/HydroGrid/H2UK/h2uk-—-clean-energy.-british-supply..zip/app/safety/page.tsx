import React from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ClosingBanner from '@/components/ClosingBanner';
import { ShieldCheck, AlertTriangle, CheckCircle2, ArrowRight, FileText, Lock } from 'lucide-react';

export default function SafetyPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />

      <main className="flex-1">
        <section className="bg-[#0A1628] py-16 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl space-y-3">
              <span className="text-xs font-bold tracking-[0.2em] text-cyan-400 uppercase">
                Hazardous Process Governance
              </span>
              <h1 className="text-4xl font-black tracking-tight text-white">
                Hydrogen Safety & Technical Standards
              </h1>
              <p className="text-base text-slate-300 leading-relaxed">
                Health and Safety Executive (HSE) compliance, DSEAR zoning, emergency shutdown systems, and UK pressure equipment safety regulations.
              </p>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white border-b border-slate-200">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
            <div className="space-y-4">
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
                Understanding Hydrogen Safety Characteristics
              </h2>
              <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
                Hydrogen has been safely manufactured, transported, and utilized across British heavy chemical and petrochemical industries for over seven decades. While hydrogen is highly buoyant and rapidly disperses outdoors into the upper atmosphere, its wide flammability range (4% to 75% in air) and low ignition energy demand rigorous engineering standards for containment and ventilation.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center gap-2 text-cyan-600 font-bold text-sm">
                  <ShieldCheck className="w-5 h-5" />
                  <span>DSEAR 2002 Compliance</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Every permanent or semi-permanent commercial installation must have a Dangerous Substances and Explosive Atmospheres Regulations (DSEAR) risk assessment defining ATEX Zone 0 (continuous hazard), Zone 1 (occasional hazard during normal operation), and Zone 2 (abnormal release hazard).
                </p>
              </div>

              <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center gap-2 text-sky-600 font-bold text-sm">
                  <Lock className="w-5 h-5" />
                  <span>Emergency Shutdown & Venting</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  All H2UK tube trailers and skid manifolds feature fail-safe pneumatic emergency shutdown valves (ESD), thermal pressure relief devices (PRD), and atmospheric vertical vent stacks designed in accordance with EIGA Doc 15 / IGEM standards.
                </p>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-amber-50 border border-amber-200 text-xs sm:text-sm text-amber-900 leading-relaxed space-y-2">
              <strong className="block text-amber-950 font-bold">Important Handling Warning:</strong>
              <p>
                Hydrogen gas must never be stored in enclosed, unventilated indoor spaces or handled with uncertified brass or plastic fittings not rated for hydrogen embrittlement. Only competent Gas Safe (hydrogen-registered) or CompEx-certified personnel may commission hydrogen manifold connections.
              </p>
            </div>
          </div>
        </section>

        <ClosingBanner />
      </main>

      <Footer />
    </div>
  );
}
