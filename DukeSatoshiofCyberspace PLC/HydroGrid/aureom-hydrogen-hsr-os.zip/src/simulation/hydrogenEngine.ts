/**
 * AUREOM HYDROGEN HSR OS
 * Hydrogen & Fuel Cell Thermodynamic System
 *
 * Synthetic Engineering Parameters:
 * - H2 Lower Heating Value (LHV) = 120.0 MJ/kg (33.333 kWh/kg)
 * - Faraday Constant F = 96485.33 C/mol
 * - Molar Mass H2 = 2.016 g/mol
 * - Type IV 700-bar Carbon-Composite Cylinders
 * - High-Power Heavy-Duty PEM Fuel Cell Stacks (Proton Exchange Membrane)
 */

import { FuelCellTelemetry, HydrogenTankTelemetry, HydrogenSafetyState } from '../types/railway';

export const H2_LHV_KWH_PER_KG = 33.333; // kWh per kg of H2
export const H2_MOLAR_MASS_G_MOL = 2.016;
export const FARADAY_CONSTANT = 96485.33;

export interface HydrogenStepResult {
  tanks: HydrogenTankTelemetry[];
  stacks: FuelCellTelemetry[];
  totalH2MassFlowKgPerHour: number;
  totalH2ConsumedDeltaKg: number;
  fuelCellGeneratedPowerKw: number;
  fuelCellWasteHeatKw: number;
  overallStackEfficiency: number;
}

/**
 * Fuel Cell Stack Polarization Curve
 * V_cell = E_nernst - eta_activation - eta_ohmic - eta_concentration
 */
export function calculateStackCellVoltage(
  currentDensityAcm2: number,
  tempCelsius: number,
  healthScorePercent: number
): { cellVoltageV: number; efficiency: number } {
  const tempKelvin = tempCelsius + 273.15;
  const degradationFactor = healthScorePercent / 100; // 0.8 to 1.0

  // Thermodynamic Nernst Potential
  const eNernst = 1.229 - 0.00085 * (tempKelvin - 298.15);

  if (currentDensityAcm2 <= 0.01) {
    return { cellVoltageV: eNernst * degradationFactor, efficiency: 0.72 * degradationFactor };
  }

  // Activation Losses (Tafel equation)
  const a = 0.045; // Tafel slope coefficient
  const i0 = 0.00015 * Math.exp((tempKelvin - 298.15) / 40); // Exchange current density
  const etaAct = a * Math.log(Math.max(1e-5, currentDensityAcm2 / i0));

  // Ohmic Overpotential (Membrane resistance)
  const rOhmic = 0.12 * (1.0 + (1 - degradationFactor) * 0.4); // cm2
  const etaOhm = currentDensityAcm2 * rOhmic;

  // Mass Transport / Concentration Losses
  const iMax = 2.2; // Maximum limiting current density A/cm2
  const mCoeff = 0.00008;
  const nCoeff = 8.5;
  const etaConc = mCoeff * Math.exp(Math.min(20, nCoeff * (currentDensityAcm2 / iMax)));

  // Net cell voltage
  let cellVoltage = (eNernst - etaAct - etaOhm - etaConc) * degradationFactor;
  cellVoltage = Math.max(0.45, Math.min(1.15, cellVoltage));

  // Thermodynamic efficiency = V_cell / 1.254 (E_thermo from LHV)
  const efficiency = Math.max(0.38, Math.min(0.68, (cellVoltage / 1.254) * degradationFactor));

  return { cellVoltageV: cellVoltage, efficiency };
}

export function stepHydrogenSystem(
  tanks: HydrogenTankTelemetry[],
  stacks: FuelCellTelemetry[],
  requiredStackPowerKw: number,
  deltaSec: number,
  ambientTempCelsius: number
): HydrogenStepResult {
  const activeStacksCount = stacks.filter(s => s.state !== 'SHUTDOWN').length || 1;
  const targetPowerPerStackKw = requiredStackPowerKw / activeStacksCount;

  let totalH2MassFlowGramsSec = 0;
  let totalStackPowerKw = 0;
  let totalThermalWasteKw = 0;
  let weightedEffSum = 0;

  // 1. Compute Stack Performance
  const updatedStacks: FuelCellTelemetry[] = stacks.map((stack, idx) => {
    if (stack.state === 'SHUTDOWN') {
      return {
        ...stack,
        powerKw: 0,
        currentA: 0,
        voltageV: 450,
        efficiency: 0,
        h2MassFlowGramsPerSec: 0,
        tempCelsius: Math.max(ambientTempCelsius, stack.tempCelsius - 0.05 * deltaSec),
      };
    }

    const ratedPower = 500; // kW per stack
    const targetKw = Math.min(ratedPower, Math.max(0, targetPowerPerStackKw));
    
    // Active area ~ 800 cm2, 450 cells per stack
    const cellCount = 450;
    const activeArea = 800; // cm2

    // Estimate current for this power: P = V * I = (cellCount * V_cell) * (i_density * activeArea)
    // Approximate current density
    const estPowerFraction = targetKw / ratedPower;
    const currentDensityAcm2 = Math.min(1.8, Math.max(0.02, estPowerFraction * 1.5));
    
    const { cellVoltageV, efficiency } = calculateStackCellVoltage(
      currentDensityAcm2, 
      stack.tempCelsius, 
      stack.healthScore
    );

    const stackVoltageV = cellCount * cellVoltageV;
    const currentA = currentDensityAcm2 * activeArea;
    const actualPowerKw = (stackVoltageV * currentA) / 1000;

    // Hydrogen consumption: Faraday's Law
    // m_dot (g/s) = (cellCount * currentA * M_H2) / (2 * F) * lambda_anode
    const lambdaAnode = 1.05; // 5% stoichiometric excess for recirculation
    const h2MassFlowGramsSec = ((cellCount * currentA * H2_MOLAR_MASS_G_MOL) / (2 * FARADAY_CONSTANT)) * lambdaAnode;

    // Thermal balance: Heat = Power_chemical - Power_electric
    const chemicalPowerKw = actualPowerKw / efficiency;
    const thermalWasteKw = chemicalPowerKw - actualPowerKw;
    
    // Stack temperature evolution with cooling radiator loop
    const targetTempCelsius = 72; // optimal PEM operating temp
    const coolingPowerKw = thermalWasteKw * 0.98;
    const netHeatKw = thermalWasteKw - coolingPowerKw;
    const thermalMass = 80; // kJ/K
    const newTempCelsius = Math.min(88, Math.max(ambientTempCelsius, stack.tempCelsius + (netHeatKw / thermalMass) * deltaSec));

    // Degradation update
    const hoursDelta = deltaSec / 3600;
    const loadCyclingWear = estPowerFraction > 0.85 ? 0.00015 : 0.00005;
    const newOperatingHours = stack.operatingHours + hoursDelta;
    const healthLoss = (hoursDelta * (stack.degradationRate / 1000)) * (1 + loadCyclingWear * 10);
    const newHealthScore = Math.max(50, stack.healthScore - healthLoss);
    const newRUL = Math.max(0, (newHealthScore - 50) * 150); // hours to 50% health

    totalH2MassFlowGramsSec += h2MassFlowGramsSec;
    totalStackPowerKw += actualPowerKw;
    totalThermalWasteKw += thermalWasteKw;
    weightedEffSum += efficiency * actualPowerKw;

    let newState = stack.state;
    if (newTempCelsius > 84) newState = 'THERMAL_THROTTLE';
    else if (newHealthScore < 65) newState = 'DEGRADED';
    else if (targetKw > 0) newState = 'LOAD_FOLLOWING';
    else newState = 'OPTIMAL';

    return {
      ...stack,
      powerKw: actualPowerKw,
      voltageV: stackVoltageV,
      currentA: currentA,
      efficiency: efficiency,
      tempCelsius: newTempCelsius,
      inletPressureBar: 3.2, // regulated fuel cell inlet
      h2MassFlowGramsPerSec: h2MassFlowGramsSec,
      healthScore: newHealthScore,
      operatingHours: newOperatingHours,
      remainingUsefulLifeHours: newRUL,
      state: newState,
    };
  });

  const totalH2ConsumedDeltaKg = (totalH2MassFlowGramsSec * deltaSec) / 1000;
  const totalH2MassFlowKgPerHour = (totalH2MassFlowGramsSec * 3600) / 1000;

  // 2. Deplete Hydrogen Tanks Proportionately
  const activeTanks = tanks.filter(t => t.valveState !== 'ISOLATED' && t.currentMassKg > 0.1);
  const massToDrawPerTankKg = activeTanks.length > 0 ? totalH2ConsumedDeltaKg / activeTanks.length : 0;

  const updatedTanks: HydrogenTankTelemetry[] = tanks.map(tank => {
    if (tank.valveState === 'ISOLATED' || tank.currentMassKg <= 0.1) {
      return tank;
    }

    const newMassKg = Math.max(0, tank.currentMassKg - massToDrawPerTankKg);
    const fillPercent = (newMassKg / tank.capacityKg) * 100;
    
    // Real Gas Equation of State (approx 700 bar tank depressurization)
    // P = P_rated * (mass / capacity) * compressibility
    const zCompressibility = 1.0 + 0.0006 * (700 * (fillPercent / 100));
    const newPressureBar = Math.max(2, (700 * (fillPercent / 100) * zCompressibility) / 1.42);
    
    // Joule-Thomson expansion causes subtle cooling during rapid discharge
    const expansionCooling = totalH2MassFlowKgPerHour > 40 ? 0.02 * deltaSec : 0;
    const newTempKelvin = Math.max(260, tank.temperatureKelvin - expansionCooling);

    let safetyState: HydrogenSafetyState = 'NORMAL';
    if (tank.leakRatePpm > 200) safetyState = 'LEAK_SUSPECTED';
    else if (newPressureBar > 730) safetyState = 'HIGH_PRESSURE';
    else if (newTempKelvin > 350) safetyState = 'HIGH_TEMPERATURE';
    else if (fillPercent < 10) safetyState = 'WARNING';

    return {
      ...tank,
      currentMassKg: newMassKg,
      fillPercentage: fillPercent,
      pressureBar: newPressureBar,
      temperatureKelvin: newTempKelvin,
      safetyState,
    };
  });

  const overallEfficiency = totalStackPowerKw > 0 ? weightedEffSum / totalStackPowerKw : 0.58;

  return {
    tanks: updatedTanks,
    stacks: updatedStacks,
    totalH2MassFlowKgPerHour,
    totalH2ConsumedDeltaKg,
    fuelCellGeneratedPowerKw: totalStackPowerKw,
    fuelCellWasteHeatKw: totalThermalWasteKw,
    overallStackEfficiency: overallEfficiency,
  };
}
