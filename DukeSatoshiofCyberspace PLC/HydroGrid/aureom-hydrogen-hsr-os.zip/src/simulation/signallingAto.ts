/**
 * AUREOM HYDROGEN HSR OS
 * Signalling (ERTMS/ETCS Level 2/3) & Automatic Train Operation (ATO) Loop
 *
 * Braking Supervision Curves:
 * - EBD: Emergency Braking Deceleration curve
 * - SBD: Service Braking Deceleration curve (Intervention curve)
 * - WBD: Warning curve (driver/ATO audible alert)
 * - PBD: Permitted Speed curve
 * - IND: Indication curve (optimal coasting / deceleration start)
 */

import { TrainModel, TrackSegment, ETCSMovementAuthority, AtomAutonomyMode } from '../types/railway';

export interface ATORunResult {
  targetSpeedKmh: number;
  tractionRequestPercent: number;
  brakeRequestPercent: number;
  updatedAuthority: ETCSMovementAuthority;
  atoPhase: 'ACCEL_ECO' | 'CRUISE_OPTIMAL' | 'COAST_ENERGY_SAVE' | 'BRAKE_APPROACH' | 'PRECISION_DWELL' | 'MANUAL_OVERRIDE';
}

export function computeBrakingCurves(
  currentSpeedMs: number,
  distanceToTargetMeters: number,
  targetSpeedMs: number,
  gradientPercent: number,
  trainMassTonnes: number,
  serviceBrakeDecelMs2: number
): {
  permittedSpeedKmh: number;
  warningSpeedKmh: number;
  interventionSpeedKmh: number;
  ebdDistanceMeters: number;
} {
  // Gradient deceleration modification: downhill decreases brake deceleration
  const gravityComponent = 9.81 * (gradientPercent / 100);
  const effectiveServiceDecel = Math.max(0.4, serviceBrakeDecelMs2 + gravityComponent * 0.5);
  const emergencyDecel = 1.35 + gravityComponent * 0.5;

  // v^2 = u^2 - 2 * a * s  =>  s = (v_current^2 - v_target^2) / (2 * a)
  const speedDeltaSq = Math.max(0, Math.pow(currentSpeedMs, 2) - Math.pow(targetSpeedMs, 2));
  
  // Safe stopping distance under emergency brake
  const ebdDistanceMeters = speedDeltaSq / (2 * emergencyDecel) + currentSpeedMs * 1.5; // with 1.5s reaction margin

  // Permitted speed at current distance: v_perm = sqrt(v_target^2 + 2 * a_eff * distance)
  const safeSpeedSq = Math.pow(targetSpeedMs, 2) + 2 * effectiveServiceDecel * Math.max(0, distanceToTargetMeters - 50);
  const safeSpeedKmh = Math.sqrt(Math.max(0, safeSpeedSq)) * 3.6;

  const permittedSpeedKmh = safeSpeedKmh;
  const warningSpeedKmh = permittedSpeedKmh + 5.0;
  const interventionSpeedKmh = permittedSpeedKmh + 10.0;

  return {
    permittedSpeedKmh,
    warningSpeedKmh,
    interventionSpeedKmh,
    ebdDistanceMeters,
  };
}

export function executeATOControlLoop(
  train: TrainModel,
  segment: TrackSegment,
  nextSegment: TrackSegment | undefined,
  targetStationDistanceMeters: number,
  ecoDrivingEnabled: boolean
): ATORunResult {
  const currentSpeedKmh = train.dynamics.speedKmh;
  const currentSpeedMs = train.dynamics.speedMs;
  const authority = train.movementAuthority;

  const distanceToEndOfAuthorityMeters = Math.max(0, (authority.endOfAuthorityKm - train.dynamics.positionKm) * 1000);

  // 1. Compute dynamic speed limit
  const segmentSpeedLimit = segment.maxAllowedSpeedKmh;
  const nextSegmentLimit = nextSegment ? nextSegment.maxAllowedSpeedKmh : segmentSpeedLimit;
  
  // High-speed Eco-driving speed calculation:
  // Operating at ~92% of top speed reduces aerodynamic drag by ~15% while adding <2 minutes over 300km
  const cruiseSpeedKmh = ecoDrivingEnabled 
    ? Math.min(train.maxSpeedKmh * 0.92, segmentSpeedLimit * 0.95)
    : Math.min(train.maxSpeedKmh, segmentSpeedLimit);

  // 2. Compute braking curves to end of movement authority or upcoming speed restriction
  const curves = computeBrakingCurves(
    currentSpeedMs,
    distanceToEndOfAuthorityMeters,
    0, // Target speed at end of authority is 0 km/h (buffer/signal)
    segment.gradientPercent,
    train.massEmptyTonnes,
    train.maxDecelerationMs2
  );

  // If approaching a station stop (< 2500m)
  const stationApproaching = targetStationDistanceMeters < 2500 && targetStationDistanceMeters > 0;
  let stationCurves = curves;
  if (stationApproaching) {
    stationCurves = computeBrakingCurves(
      currentSpeedMs,
      targetStationDistanceMeters,
      0, // Stop at platform
      segment.gradientPercent,
      train.massEmptyTonnes,
      train.maxDecelerationMs2
    );
  }

  const effectivePermittedSpeedKmh = Math.min(
    segmentSpeedLimit,
    curves.permittedSpeedKmh,
    stationApproaching ? stationCurves.permittedSpeedKmh : 999
  );

  let targetSpeedKmh = Math.min(cruiseSpeedKmh, effectivePermittedSpeedKmh);
  let tractionPercent = 0;
  let brakePercent = 0;
  let atoPhase: ATORunResult['atoPhase'] = 'CRUISE_OPTIMAL';

  if (train.autonomyMode === 'MANUAL') {
    return {
      targetSpeedKmh: effectivePermittedSpeedKmh,
      tractionRequestPercent: train.cabTractionHandlePercent,
      brakeRequestPercent: train.cabBrakeHandlePercent,
      updatedAuthority: {
        ...authority,
        targetDistanceMeters: distanceToEndOfAuthorityMeters,
        permittedSpeedKmh: effectivePermittedSpeedKmh,
        warningSpeedKmh: effectivePermittedSpeedKmh + 5,
        interventionSpeedKmh: effectivePermittedSpeedKmh + 10,
        emergencyBrakeDistanceMeters: curves.ebdDistanceMeters,
      },
      atoPhase: 'MANUAL_OVERRIDE',
    };
  }

  // ATO Supervised / Automatic Logic:
  if (stationApproaching && targetStationDistanceMeters <= 20) {
    // Precise station dwell stop
    targetSpeedKmh = 0;
    brakePercent = 60;
    tractionPercent = 0;
    atoPhase = 'PRECISION_DWELL';
  } else if (currentSpeedKmh > effectivePermittedSpeedKmh) {
    // Over permitted speed -> apply service brake
    const overspeedDelta = currentSpeedKmh - effectivePermittedSpeedKmh;
    brakePercent = Math.min(100, 20 + overspeedDelta * 8);
    tractionPercent = 0;
    atoPhase = 'BRAKE_APPROACH';
  } else if (stationApproaching && distanceToEndOfAuthorityMeters < 1500) {
    // Approaching station platform
    const brakeFraction = Math.min(1.0, Math.max(0.2, (currentSpeedKmh - 30) / 100));
    brakePercent = brakeFraction * 50;
    tractionPercent = 0;
    atoPhase = 'BRAKE_APPROACH';
  } else if (currentSpeedKmh < targetSpeedKmh - 3) {
    // Accelerate
    const speedGap = targetSpeedKmh - currentSpeedKmh;
    // Eco acceleration ramps gently to avoid fuel-cell peak spikes
    tractionPercent = ecoDrivingEnabled ? Math.min(75, 25 + speedGap * 1.5) : Math.min(100, 40 + speedGap * 2.0);
    brakePercent = 0;
    atoPhase = 'ACCEL_ECO';
  } else if (currentSpeedKmh >= targetSpeedKmh - 3 && currentSpeedKmh <= targetSpeedKmh + 2) {
    // Coasting / gentle cruise
    if (segment.gradientPercent < -0.5) {
      // Downhill coasting (natural gravity momentum saves energy)
      tractionPercent = 0;
      brakePercent = 0;
      atoPhase = 'COAST_ENERGY_SAVE';
    } else {
      tractionPercent = Math.min(35, Math.max(10, segment.gradientPercent * 10 + 15));
      brakePercent = 0;
      atoPhase = 'CRUISE_OPTIMAL';
    }
  } else {
    // Slight overspeed -> coast
    tractionPercent = 0;
    brakePercent = currentSpeedKmh > targetSpeedKmh + 5 ? 15 : 0;
    atoPhase = 'COAST_ENERGY_SAVE';
  }

  const updatedAuthority: ETCSMovementAuthority = {
    ...authority,
    targetDistanceMeters: distanceToEndOfAuthorityMeters,
    permittedSpeedKmh: effectivePermittedSpeedKmh,
    warningSpeedKmh: effectivePermittedSpeedKmh + 5,
    interventionSpeedKmh: effectivePermittedSpeedKmh + 10,
    emergencyBrakeDistanceMeters: curves.ebdDistanceMeters,
  };

  return {
    targetSpeedKmh,
    tractionRequestPercent: tractionPercent,
    brakeRequestPercent: brakePercent,
    updatedAuthority,
    atoPhase,
  };
}
