/**
 * AUREOM HYDROGEN HSR OS
 * Energy Management System (EMS) & Power Distribution Controller
 *
 * Architecture:
 * [Hydrogen Storage] -> [Fuel Cell Stacks] -> [HV DC Bus (750V / 1500V)] <-> [Battery Buffer] -> [Inverters / Traction Motors]
 *                                                                                 |
 *                                                                        [Auxiliary Loads / HVAC]
 */

import { BatteryTelemetry, TrainEnergyState } from '../types/railway';
import { H2_LHV_KWH_PER_KG } from './hydrogenEngine';

export interface EMSDispatchResult {
  fuelCellPowerRequestKw: number;
  batteryPowerKw: number; // positive = discharge, negative = charge
  updatedBattery: BatteryTelemetry;
  updatedEnergy: TrainEnergyState;
  auxiliaryPowerKw: number;
  dcBusVoltageV: number;
}

export function computeEMSDispatch(
  tractionPowerKw: number,
  regenerativePowerKw: number,
  battery: BatteryTelemetry,
  fuelCellMaxPowerKw: number,
  deltaSec: number,
  currentEnergy: TrainEnergyState,
  h2DeltaKg: number,
  stackGeneratedKw: number
): EMSDispatchResult {
  // 1. Auxiliary Hotel Loads (HVAC, compressors, passenger power, control avionics)
  const auxiliaryPowerKw = 160.0; // 160 kW baseline hotel load

  // Net electrical demand on the DC Bus
  // Net Demand = Traction + Aux - Regenerative
  const netDemandKw = tractionPowerKw + auxiliaryPowerKw - regenerativePowerKw;

  let fuelCellPowerRequestKw = 0;
  let batteryPowerKw = 0;

  // EMS Control Policy:
  // - If netDemandKw > 0:
  //    * Base load handled by Fuel Cell (run in high-efficiency sweet spot ~40-70% rated power)
  //    * High acceleration transients buffered by Battery
  //    * If SOC < 40%, Fuel Cell ramps up to supply traction + recharge battery
  //    * If SOC > 85%, Battery supplies higher fraction to prevent overcharge
  // - If netDemandKw < 0 (Braking):
  //    * Fuel Cell idles at minimum auxiliary level (~50 kW)
  //    * Regenerative energy charges Battery up to maximum charge C-rate
  
  if (netDemandKw > 0) {
    if (battery.socPercent < 35) {
      // Emergency recharge mode: Maximize Fuel Cell
      fuelCellPowerRequestKw = Math.min(fuelCellMaxPowerKw, netDemandKw + 200); // 200kW battery charge
      batteryPowerKw = netDemandKw - fuelCellPowerRequestKw;
    } else if (battery.socPercent > 80) {
      // High SOC mode: Fuel cell runs at eco level, battery discharges heavily
      fuelCellPowerRequestKw = Math.min(fuelCellMaxPowerKw * 0.55, netDemandKw);
      batteryPowerKw = netDemandKw - fuelCellPowerRequestKw;
    } else {
      // Nominal hybrid load-following mode
      const fcTarget = Math.min(fuelCellMaxPowerKw * 0.85, netDemandKw * 0.75);
      fuelCellPowerRequestKw = Math.max(50, fcTarget);
      batteryPowerKw = netDemandKw - fuelCellPowerRequestKw;
    }
  } else {
    // Regenerative braking charging mode
    fuelCellPowerRequestKw = 30; // Idle fuel cell
    const maxBatteryChargeKw = battery.capacityKwh * 3.5; // 3.5C peak regen charge
    batteryPowerKw = Math.max(-maxBatteryChargeKw, netDemandKw);
  }

  // 2. Battery Dynamics Integration
  const hours = deltaSec / 3600;
  // Energy delta: Power (kW) * hours (h) = kWh
  // Discharging: battery loses energy. Charging (negative power): battery gains energy
  const batteryEfficiency = batteryPowerKw > 0 ? 0.96 : 0.92; // Coulombic / round-trip loss
  const effectivePowerKw = batteryPowerKw > 0 ? batteryPowerKw / batteryEfficiency : batteryPowerKw * batteryEfficiency;
  const energyDeltaKwh = effectivePowerKw * hours;

  let newChargeKwh = Math.max(0, Math.min(battery.capacityKwh, battery.currentChargeKwh - energyDeltaKwh));
  const newSocPercent = (newChargeKwh / battery.capacityKwh) * 100;

  // DC Bus Voltage (nominal 750V with OCV-SOC curve)
  const ocv = 700 + (newSocPercent / 100) * 80;
  const internalResistance = 0.04; // ohms
  const batteryCurrentA = (batteryPowerKw * 1000) / ocv;
  const dcBusVoltageV = ocv - batteryCurrentA * internalResistance;

  // Thermal update
  const cellHeatKw = Math.abs(batteryCurrentA * batteryCurrentA * internalResistance) / 1000;
  const coolingKw = battery.temperatureCelsius > 28 ? 8.0 : 0.5;
  const newTempC = Math.max(18, Math.min(55, battery.temperatureCelsius + ((cellHeatKw - coolingKw) / 30) * deltaSec));

  const updatedBattery: BatteryTelemetry = {
    ...battery,
    currentChargeKwh: newChargeKwh,
    socPercent: newSocPercent,
    voltageV: dcBusVoltageV,
    currentA: batteryCurrentA,
    powerKw: batteryPowerKw,
    temperatureCelsius: newTempC,
    cRate: Math.abs(batteryPowerKw) / battery.capacityKwh,
    thermalState: newTempC > 45 ? 'THERMAL_LIMIT' : newTempC > 35 ? 'COOLING_ACTIVE' : 'NORMAL',
  };

  // 3. Cumulative Energy & Carbon Lifecycle
  const energyUsedDeltaKwh = (tractionPowerKw + auxiliaryPowerKw) * hours;
  const energyRegenDeltaKwh = regenerativePowerKw * hours;
  
  // Diesel HSR baseline equivalent ~ 3.2 kg CO2 / km vs Zero direct emission H2
  // Avoided CO2 ~ 0.85 kg CO2 per kWh traction energy equivalent
  const avoidedCo2DeltaKg = energyUsedDeltaKwh * 0.85;

  const totalH2InputEnergyKwh = (currentEnergy.cumulativeH2ConsumedKg + h2DeltaKg) * H2_LHV_KWH_PER_KG;
  const totalElectricalProducedKwh = currentEnergy.cumulativeEnergyUsedKwh + energyUsedDeltaKwh;
  const overallEfficiency = totalH2InputEnergyKwh > 0 ? Math.min(0.65, totalElectricalProducedKwh / totalH2InputEnergyKwh) : 0.58;

  const updatedEnergy: TrainEnergyState = {
    tractionPowerKw,
    auxiliaryPowerKw,
    fuelCellPowerKw: stackGeneratedKw,
    batteryPowerKw,
    regenerativePowerKw,
    h2MassFlowKgPerHour: (h2DeltaKg / deltaSec) * 3600,
    cumulativeH2ConsumedKg: currentEnergy.cumulativeH2ConsumedKg + h2DeltaKg,
    cumulativeEnergyUsedKwh: currentEnergy.cumulativeEnergyUsedKwh + energyUsedDeltaKwh,
    cumulativeEnergyRegeneratedKwh: currentEnergy.cumulativeEnergyRegeneratedKwh + energyRegenDeltaKwh,
    overallEfficiency,
    carbonAvoidedKgCo2: currentEnergy.carbonAvoidedKgCo2 + avoidedCo2DeltaKg,
  };

  return {
    fuelCellPowerRequestKw,
    batteryPowerKw,
    updatedBattery,
    updatedEnergy,
    auxiliaryPowerKw,
    dcBusVoltageV,
  };
}
