/**
 * AUREOM HYDROGEN HSR OS
 * Train Physics Engine (Deterministic Longitudinal Dynamics)
 *
 * Physical Model:
 * m * dv/dt = F_traction - F_resistance - F_gradient - F_curve - F_brake
 *
 * Resistance = Davis Formula (A + B*v + C*v^2)
 * Aerodynamic Drag = 0.5 * rho * Cd * A * v_rel^2
 * Gradient Force = m * g * sin(theta) ~ m * g * (gradient_percent / 100)
 * Curve Force = 650 * m * g / (R - 55) [von Röckl formula]
 */

import { TrainModel, TrackSegment, WeatherCondition } from '../types/railway';

const GRAVITY = 9.80665; // m/s^2

export interface PhysicsStepResult {
  newPositionKm: number;
  newSpeedKmh: number;
  newSpeedMs: number;
  accelerationMs2: number;
  tractiveForceKn: number;
  brakingForceKn: number;
  gradientForceKn: number;
  aeroDragKn: number;
  rollingResistKn: number;
  curveResistKn: number;
  netForceKn: number;
  tractionPowerKw: number;
  regenerativePowerKw: number;
  kineticEnergyMwh: number;
}

export function computeTrackForces(
  train: TrainModel,
  segment: TrackSegment,
  weather: WeatherCondition,
  speedMs: number
): {
  gradientForceKn: number;
  aeroDragKn: number;
  rollingResistKn: number;
  curveResistKn: number;
} {
  const totalMassKg = (train.massEmptyTonnes + train.dynamics.cargoLoadTonnes + (train.passengerCapacity * (train.dynamics.passengerOccupancyPercent / 100) * 0.08)) * 1000;
  
  // 1. Gradient Force: F_grad = m * g * (gradient% / 100)
  // Positive gradient (uphill) opposes motion (positive resistance force)
  const gradientForceKn = (totalMassKg * GRAVITY * (segment.gradientPercent / 100)) / 1000;

  // 2. Relative Wind Aerodynamics
  // Wind direction relative to train heading (assume track heading ~ 0)
  const windAngleRad = (weather.windDirectionDegrees * Math.PI) / 180;
  const windSpeedMs = weather.windSpeedKmh / 3.6;
  const headwindComponentMs = windSpeedMs * Math.cos(windAngleRad);
  const relativeAirSpeedMs = Math.max(0, speedMs + headwindComponentMs);
  
  // Aerodynamic Drag Force = 0.5 * rho * Cd * A * v_rel^2
  const aeroDragN = 0.5 * weather.airDensityKgM3 * train.dragCoefficientCd * train.frontalAreaM2 * Math.pow(relativeAirSpeedMs, 2);
  const aeroDragKn = aeroDragN / 1000;

  // 3. Rolling & Mechanical Resistance (Davis A + B*v)
  // A is mechanical resistance (bearing/track friction), B is flange/momentum drag
  const massTonnes = totalMassKg / 1000;
  const davisA = train.rollingResistanceCoeffA * massTonnes; // kN
  const davisB = train.rollingResistanceCoeffB * massTonnes * (speedMs * 3.6); // kN
  const rollingResistKn = davisA + davisB;

  // 4. Curve Resistance (von Röckl formula for high-speed track)
  let curveResistKn = 0;
  if (segment.curveRadiusMeters > 0) {
    const r = Math.max(segment.curveRadiusMeters, 200);
    // Formula: R_c = (650 / (R - 55)) * totalMassTonnes * 9.81 / 1000
    curveResistKn = ((650 / (r - 55)) * massTonnes * GRAVITY) / 1000;
  }

  return {
    gradientForceKn,
    aeroDragKn,
    rollingResistKn,
    curveResistKn,
  };
}

export function stepTrainDynamics(
  train: TrainModel,
  segment: TrackSegment,
  weather: WeatherCondition,
  deltaSec: number,
  targetSpeedKmh: number,
  tractionDemandPercent: number, // 0 - 100%
  brakeDemandPercent: number // 0 - 100%
): PhysicsStepResult {
  const currentSpeedMs = train.dynamics.speedMs;
  const totalMassTonnes = train.massEmptyTonnes + train.dynamics.cargoLoadTonnes + 
    (train.passengerCapacity * (train.dynamics.passengerOccupancyPercent / 100) * 0.08);
  const totalMassKg = totalMassTonnes * 1000;

  // Track forces
  const { gradientForceKn, aeroDragKn, rollingResistKn, curveResistKn } = 
    computeTrackForces(train, segment, weather, currentSpeedMs);

  const totalPassiveResistanceKn = aeroDragKn + rollingResistKn + curveResistKn + gradientForceKn;

  // Maximum tractive force based on installed motor power and wheel adhesion limit
  // Max adhesion limit = adhesion_coeff * normal_force
  const adhesionLimitKn = (totalMassKg * GRAVITY * weather.railAdhesionCoefficient) / 1000;
  
  // Power-limited tractive effort: F = P / v
  let maxTractionKn = 320; // Nominal high-speed starting tractive force
  if (currentSpeedMs > 1) {
    maxTractionKn = Math.min(350, (train.totalMotorPowerKw) / currentSpeedMs);
  }
  maxTractionKn = Math.min(maxTractionKn, adhesionLimitKn);

  let tractiveForceKn = 0;
  let brakingForceKn = 0;
  let regenerativePowerKw = 0;
  let tractionPowerKw = 0;

  if (train.emergencyBrakeEngaged || train.safetyLevel === 'EMERGENCY_BRAKE' || train.safetyLevel === 'STOP') {
    // Maximum emergency brake deceleration
    const maxBrakeDecel = train.maxEmergencyBrakeMs2;
    brakingForceKn = Math.min(totalMassTonnes * maxBrakeDecel, adhesionLimitKn * 1.2); // with magnetic track brake
  } else if (brakeDemandPercent > 0) {
    // Service blended brake
    const brakeFraction = brakeDemandPercent / 100;
    const maxServiceKn = totalMassTonnes * train.maxDecelerationMs2;
    brakingForceKn = maxServiceKn * brakeFraction;

    // Blended regenerative braking (motors act as generators up to battery/DC bus acceptance)
    if (currentSpeedMs > 2) {
      const grossKineticPowerKw = brakingForceKn * currentSpeedMs;
      // 85% regeneration recovery efficiency
      regenerativePowerKw = Math.min(grossKineticPowerKw * 0.85, train.battery.capacityKwh * 3.0); // 3C charge rate limit
    }
  } else if (tractionDemandPercent > 0 && currentSpeedMs < (segment.maxAllowedSpeedKmh / 3.6)) {
    // Traction applied
    const tractionFraction = tractionDemandPercent / 100;
    tractiveForceKn = maxTractionKn * tractionFraction;
    tractionPowerKw = tractiveForceKn * currentSpeedMs;
  }

  // Net force: F_net = F_traction - F_brake - F_passive_resistance
  let netForceKn = tractiveForceKn - brakingForceKn - totalPassiveResistanceKn;

  // At zero speed, passive resistance shouldn't make the train roll backwards if stopped with brake
  if (currentSpeedMs <= 0.05 && netForceKn < 0 && tractiveForceKn === 0) {
    netForceKn = 0;
  }

  // Acceleration a = F_net / m
  const accelerationMs2 = (netForceKn * 1000) / totalMassKg;

  // Numerical Integration (Euler / Verlet)
  let newSpeedMs = Math.max(0, currentSpeedMs + accelerationMs2 * deltaSec);
  
  // Cap at structural max speed
  const maxTrainSpeedMs = train.maxSpeedKmh / 3.6;
  if (newSpeedMs > maxTrainSpeedMs) {
    newSpeedMs = maxTrainSpeedMs;
  }

  // Distance covered: ds = v_avg * dt
  const avgSpeedMs = (currentSpeedMs + newSpeedMs) / 2;
  const deltaDistanceMeters = avgSpeedMs * deltaSec;
  const newPositionKm = train.dynamics.positionKm + (deltaDistanceMeters / 1000);

  const newSpeedKmh = newSpeedMs * 3.6;
  const kineticEnergyMwh = (0.5 * totalMassKg * Math.pow(newSpeedMs, 2)) / (3.6 * 1e9);

  return {
    newPositionKm,
    newSpeedKmh,
    newSpeedMs,
    accelerationMs2,
    tractiveForceKn,
    brakingForceKn,
    gradientForceKn,
    aeroDragKn,
    rollingResistKn,
    curveResistKn,
    netForceKn,
    tractionPowerKw,
    regenerativePowerKw,
    kineticEnergyMwh,
  };
}
