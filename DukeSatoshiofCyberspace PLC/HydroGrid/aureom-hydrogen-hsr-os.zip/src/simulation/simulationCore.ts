/**
 * AUREOM HYDROGEN HSR OS
 * Central Deterministic Simulation Engine & Digital Twin Time Machine
 */

import { 
  TrainModel, 
  TrackSegment, 
  Station, 
  HydrogenHub, 
  WeatherCondition, 
  EventLogEntry, 
  IncidentRecord,
  SimulationScenario 
} from '../types/railway';
import { STATIONS, HYDROGEN_HUBS, TRACK_SEGMENTS, INITIAL_TRAINS, SCENARIOS } from './masterNetwork';
import { stepTrainDynamics } from './physicsEngine';
import { stepHydrogenSystem } from './hydrogenEngine';
import { computeEMSDispatch } from './energyManagement';
import { executeATOControlLoop } from './signallingAto';
import { evaluateSafetySupervisor } from './safetySupervisor';

export interface SimulationState {
  simTimeSec: number;
  timeSpeedMultiplier: number; // 1, 5, 10, 50, 100
  isRunning: boolean;
  ecoDrivingActive: boolean;
  activeScenarioId: string;
  weather: WeatherCondition;
  trains: TrainModel[];
  selectedTrainId: string;
  stations: Station[];
  hubs: HydrogenHub[];
  segments: TrackSegment[];
  incidents: IncidentRecord[];
  eventLog: EventLogEntry[];
  totalNetworkH2ConsumedKg: number;
  totalNetworkEnergyUsedMwh: number;
  totalNetworkCarbonAvoidedTonnes: number;
}

export class SimulationKernel {
  private state: SimulationState;
  private historySnapshots: SimulationState[] = [];
  private maxHistory: number = 300;

  constructor() {
    this.state = {
      simTimeSec: 28800, // 08:00:00 UTC
      timeSpeedMultiplier: 1,
      isRunning: true,
      ecoDrivingActive: true,
      activeScenarioId: 'SCN-01',
      weather: {
        temperatureCelsius: 18,
        windSpeedKmh: 14,
        windDirectionDegrees: 15,
        airDensityKgM3: 1.205,
        humidityPercent: 55,
        precipitation: 'CLEAR',
        railAdhesionCoefficient: 0.35,
      },
      trains: JSON.parse(JSON.stringify(INITIAL_TRAINS)),
      selectedTrainId: 'TR-001',
      stations: JSON.parse(JSON.stringify(STATIONS)),
      hubs: JSON.parse(JSON.stringify(HYDROGEN_HUBS)),
      segments: JSON.parse(JSON.stringify(TRACK_SEGMENTS)),
      incidents: [
        {
          id: 'INC-2026-0814',
          timestamp: '08:14:22',
          trainId: 'TR-001',
          trackKm: 184.2,
          severity: 'INFORMATION',
          title: 'ETCS Level 3 Moving Block Supervision Active',
          description: 'Radio Infill balise transmission confirmed nominal. Supervised dynamic braking curve initialized.',
          status: 'RESOLVED',
          suggestedAction: 'Maintain ATO nominal cruise profile.',
          auditExplanation: 'Automated European Train Control System handshake succeeded with zero packet drop.',
        }
      ],
      eventLog: [
        {
          id: 'EVT-001',
          simTimeSec: 28800,
          timestamp: '08:00:00',
          eventType: 'SystemBoot',
          sourceSubsystem: 'ETCS_ATO',
          entityId: 'CORE-OS',
          summary: 'Aureom Hydrogen HSR OS computational kernel initialized.',
          parameters: { activeTrains: 12, networkLengthKm: 860, etcsLevel: 3 },
        }
      ],
      totalNetworkH2ConsumedKg: 2139.5,
      totalNetworkEnergyUsedMwh: 43.8,
      totalNetworkCarbonAvoidedTonnes: 37.2,
    };
  }

  public getState(): SimulationState {
    return this.state;
  }

  public setSelectedTrain(trainId: string) {
    this.state.selectedTrainId = trainId;
  }

  public setTimeSpeed(multiplier: number) {
    this.state.timeSpeedMultiplier = multiplier;
  }

  public toggleRunning(run?: boolean) {
    this.state.isRunning = run !== undefined ? run : !this.state.isRunning;
  }

  public toggleEcoDriving() {
    this.state.ecoDrivingActive = !this.state.ecoDrivingActive;
  }

  public loadScenario(scenarioId: string) {
    const scn = SCENARIOS.find(s => s.id === scenarioId);
    if (!scn) return;

    this.state.activeScenarioId = scenarioId;
    if (scn.initialConditions.weather) {
      this.state.weather = {
        ...this.state.weather,
        ...scn.initialConditions.weather,
      };
    }

    if (scenarioId === 'SCN-04') {
      // Degrade Fuel Cell Stack Beta on Train 001
      const tr = this.state.trains.find(t => t.id === 'TR-001');
      if (tr) {
        tr.fuelCellStacks[1].healthScore = 58.0;
        tr.fuelCellStacks[1].state = 'DEGRADED';
        tr.fuelCellStacks[1].tempCelsius = 84.5;
        this.addIncident({
          trainId: 'TR-001',
          severity: 'MAJOR',
          title: 'Fuel Cell Stack Beta Membrane Degradation',
          description: 'Stack Beta health decreased to 58.0%. Automated degraded operation activated.',
          suggestedAction: 'Limit stack peak current to 400A and schedule depot inspection at Frankfurt Gateway.',
          auditExplanation: 'Catalytic voltage polarization detected elevated ohmic resistance in cell group 3.',
        });
      }
    } else if (scenarioId === 'SCN-05') {
      // Hydrogen shortage in Rhine-Main hub
      const hub = this.state.hubs.find(h => h.id === 'HUB-RHINE');
      if (hub) {
        hub.currentStorageKg = 8900;
        hub.deliveryPipelineStatus = 'REDUCED_FLOW';
        this.addIncident({
          severity: 'MAJOR',
          title: 'Rhine-Main Hydrogen Terminal Low Inventory',
          description: 'Storage dropped to 13.7% capacity. Upstream pipeline maintenance throttling flow.',
          suggestedAction: 'Dispatch fleet refuellings to Stuttgart and Bavaria Electrolyzer Hubs.',
          auditExplanation: 'Electrolysis buffer storage depleted due to regional grid demand response dispatch.',
        });
      }
    }

    this.addEvent('ScenarioLoaded', 'DISPATCH', scenarioId, `Loaded simulation scenario: ${scn.title}`, {
      scenarioCode: scn.scenarioCode,
    });
  }

  public injectFailure(failureType: string, trainId?: string) {
    const targetTrain = this.state.trains.find(t => t.id === (trainId || this.state.selectedTrainId)) || this.state.trains[0];

    switch (failureType) {
      case 'H2_LEAK_MINOR': {
        targetTrain.hydrogenTanks[0].leakRatePpm = 240;
        targetTrain.hydrogenTanks[0].safetyState = 'LEAK_SUSPECTED';
        this.addIncident({
          trainId: targetTrain.id,
          trackKm: targetTrain.dynamics.positionKm,
          severity: 'CRITICAL',
          title: `Hydrogen Leak Detected on ${targetTrain.id} Tank 01`,
          description: 'Aero-roof manifold sensor registered 240 ppm H2 concentration.',
          suggestedAction: 'Safety Supervisor isolating Tank 01 valves immediately. Continue on remaining 3 tanks.',
          auditExplanation: 'Automatic galvanic sensor threshold (150 ppm) exceeded. Dual solenoid shutoff verified.',
        });
        break;
      }
      case 'STACK_OVERHEAT': {
        targetTrain.fuelCellStacks[0].tempCelsius = 88.2;
        targetTrain.fuelCellStacks[0].state = 'THERMAL_THROTTLE';
        this.addIncident({
          trainId: targetTrain.id,
          trackKm: targetTrain.dynamics.positionKm,
          severity: 'MAJOR',
          title: `Fuel Cell Stack Alpha High Temperature (${targetTrain.id})`,
          description: 'Coolant loop delta-T exceeded 14K. Stack temperature at 88.2°C.',
          suggestedAction: 'Derate stack output to 40% and engage auxiliary radiator fans at 100%.',
          auditExplanation: 'Coolant pump flow sensor reported minor cavitation at high ambient temperature.',
        });
        break;
      }
      case 'SIGNAL_RESTRICTION': {
        targetTrain.movementAuthority.permittedSpeedKmh = 160;
        targetTrain.movementAuthority.supervisionLimitSpeedKmh = 170;
        this.addIncident({
          trainId: targetTrain.id,
          trackKm: targetTrain.dynamics.positionKm,
          severity: 'MINOR',
          title: `Temporary Speed Restriction (TSR) Track Km ${targetTrain.dynamics.positionKm.toFixed(0)}`,
          description: 'Track maintenance buffer ahead. ETCS movement authority restricted to 160 km/h.',
          suggestedAction: 'ATO automatically adapting braking profile.',
          auditExplanation: 'Radio Block Centre (RBC) transmitted updated TSR balise telegram #492.',
        });
        break;
      }
      case 'BRAKE_BLENDING_FAULT': {
        targetTrain.maxDecelerationMs2 = 0.65;
        this.addIncident({
          trainId: targetTrain.id,
          trackKm: targetTrain.dynamics.positionKm,
          severity: 'MAJOR',
          title: `Electro-Pneumatic Blended Brake Degradation (${targetTrain.id})`,
          description: 'Bogie 3 friction caliper actuator pressure drop detected.',
          suggestedAction: 'Increase regenerative braking bias and extend supervised braking curve.',
          auditExplanation: 'Pneumatic line pressure transducer 3B dropped from 5.0 bar to 3.8 bar.',
        });
        break;
      }
      case 'EMERGENCY_STOP_COMMAND': {
        targetTrain.emergencyBrakeEngaged = true;
        targetTrain.safetyLevel = 'EMERGENCY_BRAKE';
        this.addIncident({
          trainId: targetTrain.id,
          trackKm: targetTrain.dynamics.positionKm,
          severity: 'EMERGENCY',
          title: `Emergency Brake Commanded for ${targetTrain.id}`,
          description: 'Emergency stop circuit de-energized. Maximum magnetic track brake applied.',
          suggestedAction: 'Maintain emergency deceleration until train reaches complete standstill (0 km/h).',
          auditExplanation: 'Driver / Dispatch Emergency brake hardwire loop opened.',
        });
        break;
      }
    }
  }

  public setTrainCabControls(
    trainId: string,
    tractionPercent: number,
    brakePercent: number,
    mode?: TrainModel['autonomyMode'],
    emergencyBrake?: boolean
  ) {
    const tr = this.state.trains.find(t => t.id === trainId);
    if (!tr) return;

    tr.cabTractionHandlePercent = Math.max(0, Math.min(100, tractionPercent));
    tr.cabBrakeHandlePercent = Math.max(0, Math.min(100, brakePercent));
    if (mode) tr.autonomyMode = mode;
    if (emergencyBrake !== undefined) {
      tr.emergencyBrakeEngaged = emergencyBrake;
      if (!emergencyBrake && tr.safetyLevel === 'EMERGENCY_BRAKE') {
        tr.safetyLevel = 'ALLOW';
      }
    }
  }

  public step(deltaSeconds: number = 0.5) {
    if (!this.state.isRunning) return;

    const effectiveDelta = deltaSeconds * this.state.timeSpeedMultiplier;
    this.state.simTimeSec += effectiveDelta;

    // Save history snapshot every 3 seconds of real time
    if (Math.floor(this.state.simTimeSec) % 3 === 0) {
      this.saveSnapshot();
    }

    let networkH2Delta = 0;
    let networkEnergyDelta = 0;

    // Step each train in the corridor
    this.state.trains = this.state.trains.map(train => {
      // 1. Determine Current Track Segment
      const currentSegment = this.state.segments.find(
        s => train.dynamics.positionKm >= s.startKm && train.dynamics.positionKm <= s.endKm
      ) || this.state.segments[0];

      const nextSegment = this.state.segments.find(s => s.startKm === currentSegment.endKm);

      // Distance to next station
      const nextStation = this.state.stations.find(s => s.id === train.nextStationId) || this.state.stations[0];
      const targetStationDistanceMeters = (nextStation.trackPositionKm - train.dynamics.positionKm) * 1000;

      // 2. Run ATO / Signalling Control Loop
      const atoResult = executeATOControlLoop(
        train,
        currentSegment,
        nextSegment,
        targetStationDistanceMeters,
        this.state.ecoDrivingActive
      );

      // 3. Safety Supervisor Evaluation
      const safetyDecision = evaluateSafetySupervisor(train, currentSegment);

      let finalTractionPercent = atoResult.tractionRequestPercent;
      let finalBrakePercent = atoResult.brakeRequestPercent;

      if (safetyDecision.emergencyBrakeRequired || train.emergencyBrakeEngaged) {
        finalTractionPercent = 0;
        finalBrakePercent = 100;
        train.safetyLevel = 'EMERGENCY_BRAKE';
      } else if (safetyDecision.tractionCutoffRequired) {
        finalTractionPercent = 0;
        if (safetyDecision.level === 'BRAKE') {
          finalBrakePercent = Math.max(finalBrakePercent, 50);
        }
        train.safetyLevel = safetyDecision.level;
      } else {
        train.safetyLevel = safetyDecision.level;
      }

      train.safetyReason = safetyDecision.reason;

      // 4. Longitudinal Dynamics Physics Step
      const physResult = stepTrainDynamics(
        train,
        currentSegment,
        this.state.weather,
        effectiveDelta,
        atoResult.targetSpeedKmh,
        finalTractionPercent,
        finalBrakePercent
      );

      // 5. Energy Management System (EMS) Dispatch
      const emsResult = computeEMSDispatch(
        physResult.tractionPowerKw,
        physResult.regenerativePowerKw,
        train.battery,
        train.fuelCellStacks.reduce((acc, s) => acc + (s.state === 'SHUTDOWN' ? 0 : 500), 0),
        effectiveDelta,
        train.energy,
        train.energy.h2MassFlowKgPerHour * (effectiveDelta / 3600),
        train.energy.fuelCellPowerKw
      );

      // 6. Hydrogen & Fuel Cell Thermodynamics Step
      const h2Result = stepHydrogenSystem(
        train.hydrogenTanks,
        train.fuelCellStacks,
        emsResult.fuelCellPowerRequestKw,
        effectiveDelta,
        this.state.weather.temperatureCelsius
      );

      networkH2Delta += h2Result.totalH2ConsumedDeltaKg;
      networkEnergyDelta += (physResult.tractionPowerKw + emsResult.auxiliaryPowerKw) * (effectiveDelta / 3600);

      // 7. Update Operational State
      let opState: TrainModel['operationalState'] = 'CRUISING';
      if (physResult.newSpeedKmh < 1.0) {
        if (train.operationalState === 'REFUELLING') opState = 'REFUELLING';
        else if (train.operationalState === 'DEPOT_STANDBY') opState = 'DEPOT_STANDBY';
        else opState = 'STATION_DWELL';
      } else if (physResult.brakingForceKn > 10) {
        opState = physResult.regenerativePowerKw > 50 ? 'REGENERATIVE_BRAKING' : 'DEGRADED_OPERATION';
      } else if (physResult.accelerationMs2 > 0.15) {
        opState = 'ACCELERATING';
      } else if (physResult.tractiveForceKn === 0 && physResult.newSpeedKmh > 50) {
        opState = 'COASTING';
      }

      // Check station arrival / pass
      let currentPos = physResult.newPositionKm;
      if (currentPos >= 860.0) {
        currentPos = 0.0; // Reset corridor loop for continuous research simulation
      }

      return {
        ...train,
        operationalState: opState,
        dynamics: {
          ...train.dynamics,
          positionKm: currentPos,
          trackSegmentId: currentSegment.id,
          speedKmh: physResult.newSpeedKmh,
          speedMs: physResult.newSpeedMs,
          targetSpeedKmh: atoResult.targetSpeedKmh,
          accelerationMs2: physResult.accelerationMs2,
          tractiveForceKn: physResult.tractiveForceKn,
          brakingForceKn: physResult.brakingForceKn,
          gradientForceKn: physResult.gradientForceKn,
          aeroDragKn: physResult.aeroDragKn,
          rollingResistKn: physResult.rollingResistKn,
          curveResistKn: physResult.curveResistKn,
          netForceKn: physResult.netForceKn,
          kineticEnergyMwh: physResult.kineticEnergyMwh,
        },
        movementAuthority: atoResult.updatedAuthority,
        battery: emsResult.updatedBattery,
        hydrogenTanks: h2Result.tanks,
        fuelCellStacks: h2Result.stacks,
        energy: {
          ...emsResult.updatedEnergy,
          fuelCellPowerKw: h2Result.fuelCellGeneratedPowerKw,
        },
      };
    });

    this.state.totalNetworkH2ConsumedKg += networkH2Delta;
    this.state.totalNetworkEnergyUsedMwh += networkEnergyDelta / 1000;
    this.state.totalNetworkCarbonAvoidedTonnes += (networkEnergyDelta * 0.85) / 1000;
  }

  private saveSnapshot() {
    if (this.historySnapshots.length >= this.maxHistory) {
      this.historySnapshots.shift();
    }
    // Deep clone minimal telemetry
    this.historySnapshots.push(JSON.parse(JSON.stringify(this.state)));
  }

  public rewind(seconds: number = 30) {
    if (this.historySnapshots.length > 5) {
      const idx = Math.max(0, this.historySnapshots.length - Math.floor(seconds / 3));
      const targetState = this.historySnapshots[idx];
      if (targetState) {
        this.state = JSON.parse(JSON.stringify(targetState));
        this.addEvent('TimeMachineRewind', 'DISPATCH', 'TIME-TRAVEL', `Simulation rewound by ${seconds}s`, {
          restoredTimeSec: this.state.simTimeSec,
        });
      }
    }
  }

  public addIncident(incident: Omit<IncidentRecord, 'id' | 'timestamp' | 'status'>) {
    const timeStr = new Date(this.state.simTimeSec * 1000).toISOString().substring(11, 19);
    const newInc: IncidentRecord = {
      id: `INC-${Date.now().toString().slice(-4)}`,
      timestamp: timeStr,
      status: 'DETECTED',
      ...incident,
    };
    this.state.incidents.unshift(newInc);
    this.addEvent('IncidentTriggered', 'SAFETY_SUPERVISOR', newInc.id, newInc.title, {
      severity: newInc.severity,
      trainId: newInc.trainId || 'NETWORK',
    });
  }

  public addEvent(
    eventType: string,
    sourceSubsystem: EventLogEntry['sourceSubsystem'],
    entityId: string,
    summary: string,
    parameters: Record<string, string | number | boolean> = {}
  ) {
    const timeStr = new Date(this.state.simTimeSec * 1000).toISOString().substring(11, 19);
    const entry: EventLogEntry = {
      id: `EVT-${Date.now().toString().slice(-5)}`,
      simTimeSec: this.state.simTimeSec,
      timestamp: timeStr,
      eventType,
      sourceSubsystem,
      entityId,
      summary,
      parameters,
    };
    this.state.eventLog.unshift(entry);
    if (this.state.eventLog.length > 80) {
      this.state.eventLog.pop();
    }
  }
}

// Global Singleton Simulator Kernel
export const globalKernel = new SimulationKernel();
