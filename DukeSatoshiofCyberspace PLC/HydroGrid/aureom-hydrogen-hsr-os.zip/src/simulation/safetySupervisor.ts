/**
 * AUREOM HYDROGEN HSR OS
 * Independent Railway Safety Supervisor
 *
 * Safety Boundary Directive:
 * - This layer is independent of ATO, Energy Optimisers, and AI Analytics.
 * - Enforces fail-safe railway principles (SIL-4 simulation equivalent).
 * - Immediate safety overrides if limits or movement authority are breached.
 */

import { TrainModel, TrackSegment, SafetySupervisionLevel } from '../types/railway';

export interface SafetySupervisorDecision {
  level: SafetySupervisionLevel;
  reason?: string;
  emergencyBrakeRequired: boolean;
  tankIsolationRequired: boolean;
  tractionCutoffRequired: boolean;
}

export function evaluateSafetySupervisor(
  train: TrainModel,
  currentSegment: TrackSegment
): SafetySupervisorDecision {
  // 1. Check Movement Authority Overrun
  const distBeyondAuthorityKm = train.dynamics.positionKm - train.movementAuthority.endOfAuthorityKm;
  if (distBeyondAuthorityKm > 0.05) { // 50m past buffer
    return {
      level: 'EMERGENCY_BRAKE',
      reason: `MOVEMENT AUTHORITY BREACH: Train exceeded authorized track limit by ${(distBeyondAuthorityKm * 1000).toFixed(0)}m`,
      emergencyBrakeRequired: true,
      tankIsolationRequired: false,
      tractionCutoffRequired: true,
    };
  }

  // 2. Check Severe Overspeed (> 15 km/h over ETCS permitted speed)
  const overspeedKmh = train.dynamics.speedKmh - train.movementAuthority.permittedSpeedKmh;
  if (overspeedKmh > 18.0) {
    return {
      level: 'EMERGENCY_BRAKE',
      reason: `CRITICAL OVERSPEED INTERVENTION: Current speed ${train.dynamics.speedKmh.toFixed(1)} km/h exceeds permitted ${train.movementAuthority.permittedSpeedKmh.toFixed(1)} km/h by >18 km/h`,
      emergencyBrakeRequired: true,
      tankIsolationRequired: false,
      tractionCutoffRequired: true,
    };
  } else if (overspeedKmh > 8.0) {
    return {
      level: 'BRAKE',
      reason: `SPEED SUPERVISION WARNING: Speed ${train.dynamics.speedKmh.toFixed(1)} km/h exceeds permitted limit. Automated service brake intervention.`,
      emergencyBrakeRequired: false,
      tankIsolationRequired: false,
      tractionCutoffRequired: true,
    };
  }

  // 3. Hydrogen Safety Checks
  const leakingTank = train.hydrogenTanks.find(t => t.leakRatePpm > 150 || t.safetyState === 'LEAK_SUSPECTED');
  if (leakingTank) {
    return {
      level: 'ISOLATE',
      reason: `HYDROGEN SAFETY INTERLOCK: Tank ${leakingTank.tankId} detected H2 concentration ${leakingTank.leakRatePpm.toFixed(0)} ppm (Threshold 150 ppm). Tank valves isolated.`,
      emergencyBrakeRequired: false,
      tankIsolationRequired: true,
      tractionCutoffRequired: false,
    };
  }

  const overpressureTank = train.hydrogenTanks.find(t => t.pressureBar > 740 || t.safetyState === 'HIGH_PRESSURE');
  if (overpressureTank) {
    return {
      level: 'LIMIT',
      reason: `HYDROGEN OVERPRESSURE ALERT: Tank ${overpressureTank.tankId} pressure reached ${overpressureTank.pressureBar.toFixed(1)} bar. Pressure relief sequence active.`,
      emergencyBrakeRequired: false,
      tankIsolationRequired: false,
      tractionCutoffRequired: false,
    };
  }

  // 4. Fuel Cell Thermal Safety
  const overheatingStack = train.fuelCellStacks.find(s => s.tempCelsius > 86);
  if (overheatingStack) {
    return {
      level: 'LIMIT',
      reason: `FUEL CELL THERMAL SAFETY: Stack ${overheatingStack.stackId} temp reached ${overheatingStack.tempCelsius.toFixed(1)}°C. Power derated 50%.`,
      emergencyBrakeRequired: false,
      tankIsolationRequired: false,
      tractionCutoffRequired: false,
    };
  }

  // 5. Battery Thermal Runaway Risk
  if (train.battery.temperatureCelsius > 52) {
    return {
      level: 'LIMIT',
      reason: `BATTERY THERMAL SUPERVISION: Cell temp ${train.battery.temperatureCelsius.toFixed(1)}°C exceeds safe operating boundary. Regenerative charging inhibited.`,
      emergencyBrakeRequired: false,
      tankIsolationRequired: false,
      tractionCutoffRequired: false,
    };
  }

  // 6. Track Speed Restriction
  if (train.dynamics.speedKmh > currentSegment.maxAllowedSpeedKmh + 5) {
    return {
      level: 'LIMIT',
      reason: `TRACK PROFILE ENFORCEMENT: Speed restricted to ${currentSegment.maxAllowedSpeedKmh} km/h for track segment ${currentSegment.id}.`,
      emergencyBrakeRequired: false,
      tankIsolationRequired: false,
      tractionCutoffRequired: true,
    };
  }

  return {
    level: 'ALLOW',
    reason: 'ALL SAFETY INTEGRITY ENVELOPES NOMINAL',
    emergencyBrakeRequired: false,
    tankIsolationRequired: false,
    tractionCutoffRequired: false,
  };
}
