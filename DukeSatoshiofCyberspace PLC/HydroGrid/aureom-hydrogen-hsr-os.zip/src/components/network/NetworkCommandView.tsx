/**
 * AUREOM HYDROGEN HSR OS
 * Network Command Centre & Live Corridor Operating Dispatch
 */

import React, { useState } from 'react';
import { 
  TrainModel, 
  Station, 
  HydrogenHub, 
  TrackSegment 
} from '../../types/railway';
import { 
  Flame, 
  Zap, 
  ShieldCheck, 
  AlertTriangle, 
  MapPin, 
  Wind, 
  ArrowUpRight, 
  Radio, 
  Activity,
  Layers,
  Clock,
  Compass
} from 'lucide-react';

interface NetworkCommandViewProps {
  trains: TrainModel[];
  stations: Station[];
  hubs: HydrogenHub[];
  segments: TrackSegment[];
  selectedTrainId: string;
  onSelectTrain: (trainId: string) => void;
  onOpenCab: (trainId: string) => void;
  onOpenDigitalTwin: (trainId: string) => void;
}

export const NetworkCommandView: React.FC<NetworkCommandViewProps> = ({
  trains,
  stations,
  hubs,
  segments,
  selectedTrainId,
  onSelectTrain,
  onOpenCab,
  onOpenDigitalTwin,
}) => {
  const [filterClass, setFilterClass] = useState<string>('ALL');
  const [zoomKmRange, setZoomKmRange] = useState<[number, number]>([0, 860]);

  const selectedTrain = trains.find(t => t.id === selectedTrainId) || trains[0];
  const totalCorridorKm = 860.0;

  const filteredTrains = trains.filter(t => {
    if (filterClass === 'ALL') return true;
    return t.fleetClass === filterClass;
  });

  return (
    <div className="flex-1 flex flex-col lg:flex-row h-full overflow-hidden bg-[#090b0e]">
      {/* Left / Main: Corridor Track Graph & Live Visualizer */}
      <div className="flex-1 flex flex-col border-r border-[#1e2633] overflow-y-auto">
        {/* Corridor Controls & Live Stats Bar */}
        <div className="p-3 bg-[#0d1117] border-b border-[#1e2633] flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-3">
            <div className="text-xs font-mono-num font-bold text-white uppercase flex items-center space-x-1.5">
              <Compass className="w-4 h-4 text-[#00e5ff]" />
              <span>TRANS-EUROPEAN HYDROGEN SPINE (860 KM)</span>
            </div>
            <div className="flex items-center space-x-1 bg-[#151c27] rounded border border-[#1e2633] p-0.5 text-[10px] font-mono-num">
              {['ALL', 'AUREOM-HSR-350', 'AUREOM-HSR-380-VELVET', 'AUREOM-CARGO-H2'].map((cls) => (
                <button
                  key={cls}
                  onClick={() => setFilterClass(cls)}
                  className={`px-2 py-0.5 rounded transition ${
                    filterClass === cls
                      ? 'bg-[#00e5ff] text-black font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {cls === 'ALL' ? 'ALL FORMATIONS' : cls.replace('AUREOM-', '')}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center space-x-4 text-xs font-mono-num text-slate-300">
            <div className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>ACTIVE IN TRANSIT: <strong className="text-white">{trains.filter(t => t.dynamics.speedKmh > 10).length}</strong></span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full bg-[#00e5ff]" />
              <span>REFUELLING/DWELL: <strong className="text-white">{trains.filter(t => t.dynamics.speedKmh <= 10).length}</strong></span>
            </div>
          </div>
        </div>

        {/* Dynamic Topological Track Map */}
        <div className="p-4 flex-1 flex flex-col space-y-6">
          {/* Schematic Track Diagram */}
          <div className="bg-[#0f141d] border border-[#1e2633] rounded-lg p-4 shadow-xl">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs font-mono-num text-slate-400 font-medium">
                TOPOLOGICAL TRACK LINE & LIVE MOVING TRAIN POSITIONS (ETCS L3 MOVING BLOCK)
              </div>
              <div className="text-[10px] font-mono-num text-slate-500">
                SCALE: 1 px ≈ 0.85 km
              </div>
            </div>

            {/* Track Line Container */}
            <div className="relative h-28 bg-[#090b0e] border border-[#1e2633] rounded p-2 overflow-hidden">
              {/* Distance Tick Marks */}
              <div className="absolute inset-x-4 top-2 h-3 flex justify-between text-[9px] font-mono-num text-slate-600">
                {[0, 100, 200, 300, 400, 500, 600, 700, 800, 860].map((km) => (
                  <span key={km}>{km}km</span>
                ))}
              </div>

              {/* Main Rail Tracks (Double Track High-Speed Line) */}
              <div className="absolute inset-x-4 top-10 h-1 bg-[#1e2633] rounded">
                <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/20 via-[#00e5ff]/30 to-amber-500/20" />
              </div>
              <div className="absolute inset-x-4 top-14 h-1 bg-[#1e2633] rounded" />

              {/* Stations Markers */}
              {stations.map((station) => {
                const leftPercent = (station.trackPositionKm / totalCorridorKm) * 100;
                return (
                  <div
                    key={station.id}
                    style={{ left: `calc(${leftPercent}% + 16px - (${leftPercent * 0.32}px))` }}
                    className="absolute top-6 -translate-x-1/2 flex flex-col items-center group cursor-pointer"
                  >
                    <div className="w-3 h-3 rounded-full bg-slate-800 border-2 border-slate-400 group-hover:border-[#00e5ff] transition" />
                    <span className="text-[8px] font-mono-num text-slate-400 group-hover:text-white mt-1 whitespace-nowrap">
                      {station.code}
                    </span>
                    {station.hasHydrogenHub && (
                      <span className="text-[7px] text-[#00e5ff] font-mono-num font-bold">H2</span>
                    )}
                  </div>
                );
              })}

              {/* Hydrogen Hub Markers */}
              {hubs.map((hub) => {
                const leftPercent = (hub.trackPositionKm / totalCorridorKm) * 100;
                return (
                  <div
                    key={hub.id}
                    style={{ left: `calc(${leftPercent}% + 16px - (${leftPercent * 0.32}px))` }}
                    className="absolute top-16 -translate-x-1/2 flex flex-col items-center cursor-pointer"
                    title={`${hub.name} (${hub.currentStorageKg} kg H2)`}
                  >
                    <div className="w-2.5 h-2.5 rotate-45 bg-[#00e5ff]/20 border border-[#00e5ff] animate-pulse" />
                  </div>
                );
              })}

              {/* Moving Train Icons */}
              {filteredTrains.map((train) => {
                const leftPercent = (train.dynamics.positionKm / totalCorridorKm) * 100;
                const isSelected = train.id === selectedTrainId;
                const isWarning = train.safetyLevel !== 'ALLOW';
                const isCargo = train.fleetClass === 'AUREOM-CARGO-H2';

                return (
                  <div
                    key={train.id}
                    onClick={() => onSelectTrain(train.id)}
                    style={{ left: `calc(${leftPercent}% + 16px - (${leftPercent * 0.32}px))` }}
                    className={`absolute top-8 -translate-x-1/2 cursor-pointer z-10 transition-all duration-300 ${
                      isSelected ? 'scale-125 z-20' : 'hover:scale-110'
                    }`}
                  >
                    {/* Train Pod */}
                    <div
                      className={`px-1.5 py-0.5 rounded flex items-center space-x-1 text-[9px] font-mono-num font-bold shadow-lg border ${
                        isSelected
                          ? 'bg-[#00e5ff] text-black border-white ring-2 ring-[#00e5ff]/50'
                          : isWarning
                          ? 'bg-red-600 text-white border-red-300'
                          : isCargo
                          ? 'bg-amber-600/90 text-white border-amber-400'
                          : 'bg-[#152332] text-[#00e5ff] border-[#00e5ff]/50'
                      }`}
                    >
                      <span>{train.id.replace('TR-', '#')}</span>
                      <span className="text-[8px] opacity-90">{train.dynamics.speedKmh.toFixed(0)}k</span>
                    </div>

                    {/* Speed Vector Tail */}
                    {train.dynamics.speedKmh > 50 && (
                      <div className="w-1.5 h-0.5 bg-[#00e5ff]/60 mx-auto mt-0.5" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Elevation Profile & Gradient Cross-Section */}
          <div className="bg-[#0f141d] border border-[#1e2633] rounded-lg p-4 shadow-xl">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs font-mono-num text-slate-400 font-medium flex items-center space-x-2">
                <ArrowUpRight className="w-3.5 h-3.5 text-[#00e5ff]" />
                <span>CORRIDOR ELEVATION PROFILE & GRADIENT DYNAMICS (0m to 1,200m ALTITUDE)</span>
              </div>
              <div className="text-[10px] font-mono-num text-slate-500">
                MAX GRADIENT: +3.2% (ALPINE CLIMB)
              </div>
            </div>

            {/* SVG Elevation Path */}
            <div className="h-32 bg-[#090b0e] border border-[#1e2633] rounded relative overflow-hidden">
              <svg className="w-full h-full" viewBox="0 0 860 120" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="elevationGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#00e5ff" stopOpacity="0.3" />
                    <stop offset="100%" stopColor="#00e5ff" stopOpacity="0.02" />
                  </linearGradient>
                </defs>

                {/* Grid Lines */}
                <line x1="0" y1="30" x2="860" y2="30" stroke="#1e2633" strokeDasharray="3 3" />
                <line x1="0" y1="60" x2="860" y2="60" stroke="#1e2633" strokeDasharray="3 3" />
                <line x1="0" y1="90" x2="860" y2="90" stroke="#1e2633" strokeDasharray="3 3" />

                {/* Elevation Polygon Area */}
                {/* Elevation approx: Hamburg(12m)->Hannover(55m)->Kassel(165m)->Frankfurt(102m)->Stuttgart(245m)->München(520m)->Salzburg(436m)->Innsbruck(582m) */}
                <path
                  d="M 0 115 L 0 110 Q 70 108 145 102 Q 220 90 295 85 Q 365 95 435 98 Q 505 85 575 72 Q 640 45 710 40 Q 755 52 795 48 Q 830 30 860 22 L 860 120 L 0 120 Z"
                  fill="url(#elevationGrad)"
                />
                <path
                  d="M 0 110 Q 70 108 145 102 Q 220 90 295 85 Q 365 95 435 98 Q 505 85 575 72 Q 640 45 710 40 Q 755 52 795 48 Q 830 30 860 22"
                  fill="none"
                  stroke="#00e5ff"
                  strokeWidth="2"
                />

                {/* Active Train Positions Projected on Elevation */}
                {filteredTrains.map((t) => {
                  const x = t.dynamics.positionKm;
                  // Approximate y height on line
                  const isSelected = t.id === selectedTrainId;
                  return (
                    <g key={t.id}>
                      <line x1={x} y1="0" x2={x} y2="120" stroke={isSelected ? '#00e5ff' : '#334155'} strokeWidth={isSelected ? '1.5' : '0.5'} strokeDasharray={isSelected ? 'none' : '2 2'} />
                      <circle cx={x} cy={110 - (x / 860) * 85} r={isSelected ? 4.5 : 2.5} fill={isSelected ? '#ffffff' : '#00e5ff'} stroke="#000000" strokeWidth="1" />
                    </g>
                  );
                })}
              </svg>

              {/* Station Labels on Elevation */}
              <div className="absolute inset-x-2 bottom-1 flex justify-between text-[8px] font-mono-num text-slate-500">
                <span>Hamburg (12m)</span>
                <span>Hannover (55m)</span>
                <span>Frankfurt (102m)</span>
                <span>Stuttgart (245m)</span>
                <span>München (520m)</span>
                <span>Innsbruck (582m)</span>
              </div>
            </div>
          </div>

          {/* Quick Active Trains Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredTrains.map((train) => {
              const isSelected = train.id === selectedTrainId;
              const h2Percent = train.hydrogenTanks[0]?.fillPercentage || 0;
              const batteryPercent = train.battery.socPercent;

              return (
                <div
                  key={train.id}
                  onClick={() => onSelectTrain(train.id)}
                  className={`p-3 rounded-lg border transition cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-[#151f2c] border-[#00e5ff] shadow-[0_0_15px_rgba(0,229,255,0.15)]'
                      : 'bg-[#0e1218] border-[#1e2633] hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono-num font-bold text-sm text-white">{train.id}</span>
                      <span className="text-[10px] font-mono-num px-1 rounded bg-[#1e2633] text-slate-300">
                        {train.serviceCode}
                      </span>
                    </div>
                    <span className={`text-[10px] font-mono-num font-semibold px-1.5 py-0.5 rounded ${
                      train.operationalState === 'CRUISING'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : train.operationalState === 'ACCELERATING'
                        ? 'bg-[#00e5ff]/20 text-[#00e5ff]'
                        : train.operationalState === 'REGENERATIVE_BRAKING'
                        ? 'bg-purple-500/20 text-purple-300'
                        : 'bg-amber-500/20 text-amber-300'
                    }`}>
                      {train.operationalState.replace('_', ' ')}
                    </span>
                  </div>

                  {/* Dynamic Metrics */}
                  <div className="grid grid-cols-3 gap-2 my-2 text-[11px] font-mono-num">
                    <div>
                      <div className="text-[9px] text-slate-500">SPEED / TGT</div>
                      <div className="text-white font-bold">
                        {train.dynamics.speedKmh.toFixed(0)} <span className="text-[9px] text-slate-400">/ {train.dynamics.targetSpeedKmh.toFixed(0)} km/h</span>
                      </div>
                    </div>
                    <div>
                      <div className="text-[9px] text-slate-500">POSITION</div>
                      <div className="text-white font-medium">
                        Km {train.dynamics.positionKm.toFixed(1)}
                      </div>
                    </div>
                    <div>
                      <div className="text-[9px] text-slate-500">DELAY</div>
                      <div className={train.delaySeconds > 30 ? 'text-amber-400 font-bold' : 'text-emerald-400'}>
                        {train.delaySeconds <= 0 ? 'ON TIME' : `+${train.delaySeconds}s`}
                      </div>
                    </div>
                  </div>

                  {/* Fuel & Battery Status Bars */}
                  <div className="space-y-1 pt-1 border-t border-[#1e2633]/60">
                    <div className="flex items-center justify-between text-[9px] font-mono-num text-slate-400">
                      <span className="flex items-center space-x-1 text-[#00e5ff]">
                        <Flame className="w-2.5 h-2.5" />
                        <span>H2 STORAGE: {h2Percent.toFixed(0)}%</span>
                      </span>
                      <span className="flex items-center space-x-1 text-emerald-400">
                        <Zap className="w-2.5 h-2.5" />
                        <span>BATTERY SOC: {batteryPercent.toFixed(0)}%</span>
                      </span>
                    </div>
                    <div className="h-1 bg-[#1e2633] rounded overflow-hidden flex">
                      <div style={{ width: `${h2Percent}%` }} className="bg-[#00e5ff] h-full" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Right Sidebar: Selected Train Deep Telemetry & Actuation Terminal */}
      <div className="w-full lg:w-96 bg-[#0c0f14] p-4 flex flex-col justify-between overflow-y-auto space-y-4">
        <div>
          {/* Selected Train Header */}
          <div className="border-b border-[#1e2633] pb-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono-num font-bold text-[#00e5ff] tracking-wider">
                SELECTED TRAIN TELEMETRY PROBE
              </span>
              <span className="text-[10px] font-mono-num px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                {selectedTrain.autonomyMode}
              </span>
            </div>
            <h2 className="text-lg font-display font-bold text-white mt-1">
              {selectedTrain.name}
            </h2>
            <p className="text-[11px] font-mono-num text-slate-400">
              {selectedTrain.formation}
            </p>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-2 my-3">
            <button
              onClick={() => onOpenCab(selectedTrain.id)}
              className="py-2 px-3 rounded bg-[#152332] border border-[#00e5ff]/50 hover:bg-[#00e5ff]/20 text-[#00e5ff] text-xs font-mono-num font-bold transition flex items-center justify-center space-x-1.5"
            >
              <span>ENTER CAB & DMI</span>
            </button>
            <button
              onClick={() => onOpenDigitalTwin(selectedTrain.id)}
              className="py-2 px-3 rounded bg-[#181d26] border border-slate-700 hover:border-[#00e5ff] text-white text-xs font-mono-num font-bold transition flex items-center justify-center space-x-1.5"
            >
              <span>INSPECT 3D TWIN</span>
            </button>
          </div>

          {/* Physical Dynamics Stack */}
          <div className="space-y-3">
            <div className="bg-[#090b0e] border border-[#1e2633] rounded p-3 space-y-2">
              <div className="text-[10px] font-mono-num text-slate-400 uppercase font-semibold flex items-center justify-between">
                <span>LONGITUDINAL DYNAMICS</span>
                <span className="text-white">SI UNITS</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono-num">
                <div>
                  <div className="text-[9px] text-slate-500">SPEED (v)</div>
                  <div className="text-white font-bold text-base">
                    {selectedTrain.dynamics.speedKmh.toFixed(1)} <span className="text-[10px] font-normal text-slate-400">km/h</span>
                  </div>
                </div>
                <div>
                  <div className="text-[9px] text-slate-500">ACCELERATION (dv/dt)</div>
                  <div className="text-white font-bold text-base">
                    {selectedTrain.dynamics.accelerationMs2.toFixed(3)} <span className="text-[10px] font-normal text-slate-400">m/s²</span>
                  </div>
                </div>
                <div>
                  <div className="text-[9px] text-slate-500">TRACTIVE FORCE (F_tr)</div>
                  <div className="text-emerald-400 font-bold">
                    {selectedTrain.dynamics.tractiveForceKn.toFixed(1)} kN
                  </div>
                </div>
                <div>
                  <div className="text-[9px] text-slate-500">BRAKING FORCE (F_brk)</div>
                  <div className="text-purple-400 font-bold">
                    {selectedTrain.dynamics.brakingForceKn.toFixed(1)} kN
                  </div>
                </div>
                <div>
                  <div className="text-[9px] text-slate-500">AERO DRAG (F_aero)</div>
                  <div className="text-slate-300 font-medium">
                    {selectedTrain.dynamics.aeroDragKn.toFixed(1)} kN
                  </div>
                </div>
                <div>
                  <div className="text-[9px] text-slate-500">GRADIENT FORCE (F_grad)</div>
                  <div className="text-slate-300 font-medium">
                    {selectedTrain.dynamics.gradientForceKn.toFixed(1)} kN
                  </div>
                </div>
              </div>
            </div>

            {/* Hydrogen System Deep Probe */}
            <div className="bg-[#090b0e] border border-[#1e2633] rounded p-3 space-y-2">
              <div className="text-[10px] font-mono-num text-[#00e5ff] uppercase font-semibold flex items-center justify-between">
                <span>HYDROGEN THERMODYNAMICS</span>
                <span>4x 700-BAR TANKS</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono-num">
                <div>
                  <div className="text-[9px] text-slate-500">H2 MASS FLOW</div>
                  <div className="text-white font-bold">
                    {selectedTrain.energy.h2MassFlowKgPerHour.toFixed(1)} <span className="text-[10px] font-normal text-slate-400">kg/h</span>
                  </div>
                </div>
                <div>
                  <div className="text-[9px] text-slate-500">TANK PRESSURE</div>
                  <div className="text-white font-bold">
                    {selectedTrain.hydrogenTanks[0]?.pressureBar.toFixed(1)} <span className="text-[10px] font-normal text-slate-400">bar</span>
                  </div>
                </div>
                <div>
                  <div className="text-[9px] text-slate-500">STACK POWER (FC)</div>
                  <div className="text-[#00e5ff] font-bold">
                    {selectedTrain.energy.fuelCellPowerKw.toFixed(0)} kW
                  </div>
                </div>
                <div>
                  <div className="text-[9px] text-slate-500">STACK EFFICIENCY</div>
                  <div className="text-[#00e5ff] font-bold">
                    {(selectedTrain.fuelCellStacks[0]?.efficiency * 100 || 60).toFixed(1)}%
                  </div>
                </div>
              </div>
            </div>

            {/* Safety Supervisor State */}
            <div className="bg-[#090b0e] border border-[#1e2633] rounded p-3">
              <div className="flex items-center justify-between text-[10px] font-mono-num text-slate-400 font-semibold mb-1">
                <span>SAFETY SUPERVISOR (SIL-4)</span>
                <span className={`px-1 rounded ${
                  selectedTrain.safetyLevel === 'ALLOW' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                }`}>
                  {selectedTrain.safetyLevel}
                </span>
              </div>
              <p className="text-[11px] font-mono-num text-slate-300">
                {selectedTrain.safetyReason || 'All physical, thermal, and ETCS safety envelopes nominal.'}
              </p>
            </div>
          </div>
        </div>

        {/* Train Path & Upcoming Station */}
        <div className="bg-[#090b0e] border border-[#1e2633] rounded p-3 text-xs font-mono-num text-slate-300 space-y-1">
          <div className="flex justify-between">
            <span className="text-slate-500">ORIGIN:</span>
            <span className="text-white font-medium">{selectedTrain.originStationId} (Hamburg)</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">NEXT STOP:</span>
            <span className="text-[#00e5ff] font-bold">{selectedTrain.nextStationId}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">DESTINATION:</span>
            <span className="text-white font-medium">{selectedTrain.destinationStationId} (Innsbruck)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
