/**
 * AUREOM HYDROGEN HSR OS
 * Master System Header & Time Machine Controls
 */

import React from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  FastForward, 
  ShieldAlert, 
  Radio, 
  Zap, 
  Flame, 
  Activity, 
  Clock,
  Layers,
  Sparkles
} from 'lucide-react';
import { SimulationState } from '../../simulation/simulationCore';
import { SCENARIOS } from '../../simulation/masterNetwork';

interface HeaderProps {
  state: SimulationState;
  onTogglePlay: () => void;
  onSetSpeed: (speed: number) => void;
  onRewind: () => void;
  onSelectScenario: (id: string) => void;
  onToggleEco: () => void;
  onOpenFailureModal: () => void;
  onOpenAiModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  state,
  onTogglePlay,
  onSetSpeed,
  onRewind,
  onSelectScenario,
  onToggleEco,
  onOpenFailureModal,
  onOpenAiModal,
}) => {
  // Format UTC simulation time
  const simDate = new Date(state.simTimeSec * 1000);
  const timeFormatted = simDate.toISOString().substring(11, 19);

  const activeAlarmsCount = state.incidents.filter(i => i.severity === 'CRITICAL' || i.severity === 'EMERGENCY').length;
  const warningsCount = state.incidents.filter(i => i.severity === 'MAJOR' || i.severity === 'MINOR').length;

  return (
    <header className="h-14 border-b border-[#1e2633] bg-[#090b0e]/95 backdrop-blur px-4 flex items-center justify-between select-none z-30 shrink-0">
      {/* Brand & Subsystem Identity */}
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded border border-[#00e5ff]/40 bg-[#00e5ff]/10 flex items-center justify-center text-[#00e5ff] font-bold text-sm tracking-tighter">
            <Flame className="w-4 h-4 text-[#00e5ff]" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-display font-bold text-sm tracking-wider text-white">AUREOM</span>
              <span className="text-[10px] font-mono-num px-1.5 py-0.5 rounded bg-[#00e5ff]/15 text-[#00e5ff] font-semibold border border-[#00e5ff]/30">
                H2-HSR OS v4.2
              </span>
              <span className="text-[10px] font-mono-num text-slate-400 border border-slate-700/60 px-1 rounded">
                SIMULATION-FIRST / HARDWARE-ISOLATED
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono-num leading-none mt-0.5">
              TRANS-EUROPEAN HYDROGEN HIGH-SPEED RAILWAY PLATFORM
            </p>
          </div>
        </div>

        {/* Global Safety Enclosure State */}
        <div className="hidden lg:flex items-center space-x-2 pl-4 border-l border-[#1e2633]">
          <div className="flex items-center space-x-1.5 text-[11px] font-mono-num">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-slate-300">ETCS L3 SUPERVISED</span>
          </div>
          <span className="text-slate-600">|</span>
          <div className="text-[11px] font-mono-num text-slate-400">
            CORRIDOR: <span className="text-white font-medium">860 km</span>
          </div>
        </div>
      </div>

      {/* Center: Digital Twin Time Machine Controls */}
      <div className="flex items-center space-x-3">
        {/* Scenario Switcher */}
        <div className="hidden md:flex items-center space-x-1.5 bg-[#121720] border border-[#1e2633] rounded px-2 py-1">
          <Layers className="w-3.5 h-3.5 text-slate-400" />
          <select 
            value={state.activeScenarioId} 
            onChange={(e) => onSelectScenario(e.target.value)}
            className="bg-transparent text-[11px] font-mono-num text-slate-200 outline-none cursor-pointer pr-1"
          >
            {SCENARIOS.map(s => (
              <option key={s.id} value={s.id} className="bg-[#121720] text-slate-200">
                {s.title}
              </option>
            ))}
          </select>
        </div>

        {/* Time Display & Playback Controls */}
        <div className="flex items-center bg-[#121720] border border-[#1e2633] rounded p-0.5">
          <button
            onClick={onRewind}
            title="Rewind 30s"
            className="p-1.5 hover:bg-[#1e2633] rounded text-slate-300 hover:text-white transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onTogglePlay}
            title={state.isRunning ? 'Pause Simulation' : 'Resume Simulation'}
            className={`px-2.5 py-1 rounded flex items-center space-x-1.5 text-xs font-mono-num font-medium transition ${
              state.isRunning 
                ? 'bg-[#00e5ff]/20 text-[#00e5ff] border border-[#00e5ff]/40' 
                : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
            }`}
          >
            {state.isRunning ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>PAUSE</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>RUN</span>
              </>
            )}
          </button>

          {/* Speed Multipliers */}
          <div className="flex items-center space-x-0.5 ml-1 border-l border-[#1e2633] pl-1">
            {[1, 5, 10, 50, 100].map(speed => (
              <button
                key={speed}
                onClick={() => onSetSpeed(speed)}
                className={`px-1.5 py-0.5 text-[10px] font-mono-num rounded transition ${
                  state.timeSpeedMultiplier === speed
                    ? 'bg-[#00e5ff] text-black font-bold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#1e2633]'
                }`}
              >
                {speed}x
              </button>
            ))}
          </div>

          {/* Mission Time */}
          <div className="flex items-center space-x-1.5 px-3 border-l border-[#1e2633] ml-1 text-xs font-mono-num">
            <Clock className="w-3.5 h-3.5 text-[#00e5ff]" />
            <span className="text-white font-bold tracking-wider">{timeFormatted}</span>
            <span className="text-[9px] text-slate-500">UTC</span>
          </div>
        </div>

        {/* Eco Driving Toggle */}
        <button
          onClick={onToggleEco}
          className={`hidden sm:flex items-center space-x-1.5 px-2.5 py-1 rounded border text-[11px] font-mono-num transition ${
            state.ecoDrivingActive 
              ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300' 
              : 'bg-[#121720] border-[#1e2633] text-slate-400 hover:text-slate-200'
          }`}
        >
          <Zap className="w-3 h-3 text-emerald-400" />
          <span>ECO-H2 {state.ecoDrivingActive ? 'ON' : 'OFF'}</span>
        </button>
      </div>

      {/* Right: Alarms, Failure Injector & AI Intelligence */}
      <div className="flex items-center space-x-2">
        {/* Failure Injection Trigger */}
        <button
          onClick={onOpenFailureModal}
          className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-[#1f1519] border border-red-500/40 hover:bg-red-950/40 text-red-300 text-xs font-mono-num transition"
        >
          <ShieldAlert className="w-3.5 h-3.5 text-red-400 animate-pulse" />
          <span className="hidden sm:inline">FAILURE INJECTOR</span>
        </button>

        {/* AI Assistant */}
        <button
          onClick={onOpenAiModal}
          className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-[#121e29] border border-[#00e5ff]/40 hover:bg-[#00e5ff]/20 text-[#00e5ff] text-xs font-mono-num transition"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#00e5ff]" />
          <span className="hidden sm:inline">RAIL AI INTELLIGENCE</span>
        </button>

        {/* Status Badges */}
        <div className="flex items-center space-x-1">
          {activeAlarmsCount > 0 ? (
            <span className="px-1.5 py-0.5 rounded bg-red-500/20 border border-red-500 text-red-400 font-mono-num text-[10px] font-bold">
              {activeAlarmsCount} ALARM
            </span>
          ) : (
            <span className="px-1.5 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 font-mono-num text-[10px]">
              ALL SIL-4 NOMINAL
            </span>
          )}
        </div>
      </div>
    </header>
  );
};
