/**
 * AUREOM HYDROGEN HSR OS
 * Primary Architectural Navigation Bar
 */

import React from 'react';
import { 
  Network, 
  Box, 
  Gauge, 
  Flame, 
  Zap, 
  Radio, 
  Wrench, 
  Sparkles, 
  Cpu 
} from 'lucide-react';

export type ViewTab = 
  | 'NETWORK_COMMAND'
  | 'DIGITAL_TWIN_3D'
  | 'DRIVER_CAB_DMI'
  | 'HYDROGEN_INFRASTRUCTURE'
  | 'ENERGY_EMS'
  | 'ATO_SIGNALLING'
  | 'FLEET_MAINTENANCE'
  | 'AI_INTELLIGENCE'
  | 'ENGINEERING_LAB';

interface NavigationProps {
  activeTab: ViewTab;
  onSelectTab: (tab: ViewTab) => void;
  trainCount: number;
  activeIncidentsCount: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  trainCount,
  activeIncidentsCount,
}) => {
  const navItems = [
    {
      id: 'NETWORK_COMMAND' as ViewTab,
      label: 'NETWORK COMMAND',
      subtext: 'Corridor & Live Dispatch',
      icon: Network,
      badge: `${trainCount} Trains`,
    },
    {
      id: 'DIGITAL_TWIN_3D' as ViewTab,
      label: '3D DIGITAL TWIN',
      subtext: 'Train Anatomy & Flows',
      icon: Box,
    },
    {
      id: 'DRIVER_CAB_DMI' as ViewTab,
      label: 'DRIVER CAB & DMI',
      subtext: 'ETCS & Master Controller',
      icon: Gauge,
    },
    {
      id: 'HYDROGEN_INFRASTRUCTURE' as ViewTab,
      label: 'HYDROGEN GRID',
      subtext: 'Hubs, Storage & Refuelling',
      icon: Flame,
    },
    {
      id: 'ENERGY_EMS' as ViewTab,
      label: 'ENERGY & EMS',
      subtext: 'Fuel Cell, Battery & Balance',
      icon: Zap,
    },
    {
      id: 'ATO_SIGNALLING' as ViewTab,
      label: 'ETCS / ATO',
      subtext: 'Movement Authority & Curves',
      icon: Radio,
    },
    {
      id: 'FLEET_MAINTENANCE' as ViewTab,
      label: 'FLEET & ASSETS',
      subtext: 'Predictive Health & RUL',
      icon: Wrench,
    },
    {
      id: 'AI_INTELLIGENCE' as ViewTab,
      label: 'RAIL INTELLIGENCE',
      subtext: 'Grounded AI Analytics',
      icon: Sparkles,
      badge: activeIncidentsCount > 0 ? `${activeIncidentsCount} Alerts` : undefined,
    },
    {
      id: 'ENGINEERING_LAB' as ViewTab,
      label: 'ENGINEERING LAB',
      subtext: 'Physics & Equations',
      icon: Cpu,
    },
  ];

  return (
    <nav className="h-12 border-b border-[#1e2633] bg-[#0c0f14] px-3 flex items-center space-x-1 overflow-x-auto select-none shrink-0 scrollbar-none">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onSelectTab(item.id)}
            className={`h-9 px-3 rounded flex items-center space-x-2 text-xs font-mono-num transition whitespace-nowrap ${
              isActive
                ? 'bg-[#151d28] text-[#00e5ff] border border-[#00e5ff]/40 shadow-[0_0_12px_rgba(0,229,255,0.12)]'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#121720] border border-transparent'
            }`}
          >
            <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#00e5ff]' : 'text-slate-400'}`} />
            <span className={`font-semibold tracking-wide ${isActive ? 'text-white' : 'text-slate-300'}`}>
              {item.label}
            </span>
            {item.badge && (
              <span className={`text-[9px] px-1.5 py-0.2 rounded font-mono-num font-bold ${
                isActive 
                  ? 'bg-[#00e5ff]/20 text-[#00e5ff] border border-[#00e5ff]/30' 
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}>
                {item.badge}
              </span>
            )}
          </button>
        );
      })}
    </nav>
  );
};
