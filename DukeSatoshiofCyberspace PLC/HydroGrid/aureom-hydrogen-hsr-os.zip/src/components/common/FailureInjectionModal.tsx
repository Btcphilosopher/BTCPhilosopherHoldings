/**
 * AUREOM HYDROGEN HSR OS
 * Failure Injection & Safety Supervisor Stress-Testing Modal
 */

import React from 'react';
import { 
  ShieldAlert, 
  X, 
  Flame, 
  Thermometer, 
  Radio, 
  AlertOctagon, 
  Activity,
  ArrowRight
} from 'lucide-react';
import { TrainModel } from '../../types/railway';

interface FailureInjectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  trains: TrainModel[];
  selectedTrainId: string;
  onInject: (failureType: string, trainId: string) => void;
}

export const FailureInjectionModal: React.FC<FailureInjectionModalProps> = ({
  isOpen,
  onClose,
  trains,
  selectedTrainId,
  onInject,
}) => {
  if (!isOpen) return null;

  const failureScenarios = [
    {
      id: 'H2_LEAK_MINOR',
      title: 'Roof Tank 01 Hydrogen Leak (240 ppm)',
      description: 'Tests automated galvanic sensor detection, solenoid valve isolation, and SIL-4 containment.',
      severity: 'CRITICAL',
      icon: Flame,
      color: '#00e5ff',
    },
    {
      id: 'STACK_OVERHEAT',
      title: 'Fuel Cell Stack Alpha Thermal Excursion (88.2°C)',
      description: 'Simulates coolant loop flow restriction and triggers automated EMS stack derating.',
      severity: 'MAJOR',
      icon: Thermometer,
      color: '#f59e0b',
    },
    {
      id: 'SIGNAL_RESTRICTION',
      title: 'Temporary Speed Restriction (TSR 160 km/h)',
      description: 'Injects radio block telegram speed restriction to verify ATO dynamic braking curve adaptation.',
      severity: 'MINOR',
      icon: Radio,
      color: '#38bdf8',
    },
    {
      id: 'BRAKE_BLENDING_FAULT',
      title: 'Friction Brake Caliper Pressure Loss',
      description: 'Degrades pneumatic brake line pressure to verify electro-dynamic regenerative compensation.',
      severity: 'MAJOR',
      icon: Activity,
      color: '#a855f7',
    },
    {
      id: 'EMERGENCY_STOP_COMMAND',
      title: 'Hardwire Emergency Stop Trip (EBD)',
      description: 'Commands immediate traction cutoff and maximum magnetic track emergency deceleration.',
      severity: 'EMERGENCY',
      icon: AlertOctagon,
      color: '#ef4444',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0c1017] border border-[#1e2633] rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden select-none">
        {/* Modal Header */}
        <div className="p-4 border-b border-[#1e2633] flex items-center justify-between bg-[#0e141f]">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-display font-bold text-white uppercase tracking-wider">
                SAFETY SUPERVISOR FAILURE INJECTOR
              </h3>
              <p className="text-[10px] font-mono-num text-slate-400">
                Stress-test real-time SIL-4 automated protection envelopes.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-[#1e2633] transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Train Target Selector */}
        <div className="p-4 bg-[#090b0e] border-b border-[#1e2633] flex items-center justify-between text-xs font-mono-num">
          <span className="text-slate-400">TARGET TRAIN:</span>
          <span className="text-white font-bold bg-[#152332] px-2 py-1 rounded border border-[#00e5ff]/40">
            {selectedTrainId}
          </span>
        </div>

        {/* Fault Triggers List */}
        <div className="p-4 space-y-2.5 max-h-96 overflow-y-auto">
          {failureScenarios.map((f) => {
            const Icon = f.icon;
            return (
              <div
                key={f.id}
                className="p-3 rounded-xl bg-[#090b0e] border border-[#1e2633] hover:border-slate-600 transition flex items-center justify-between group"
              >
                <div className="flex items-start space-x-3 pr-3">
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                    style={{ backgroundColor: `${f.color}15`, border: `1px solid ${f.color}40` }}
                  >
                    <Icon className="w-4 h-4" style={{ color: f.color }} />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h4 className="text-xs font-display font-bold text-white group-hover:text-[#00e5ff] transition">
                        {f.title}
                      </h4>
                      <span className="text-[9px] font-mono-num font-bold px-1.5 rounded bg-red-500/20 text-red-400 border border-red-500/30">
                        {f.severity}
                      </span>
                    </div>
                    <p className="text-[10px] font-mono-num text-slate-400 mt-1 leading-relaxed">
                      {f.description}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => {
                    onInject(f.id, selectedTrainId);
                    onClose();
                  }}
                  className="px-3 py-1.5 rounded bg-red-950/40 hover:bg-red-900 border border-red-500/50 text-red-200 font-mono-num font-bold text-xs transition shrink-0 flex items-center space-x-1"
                >
                  <span>INJECT</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
