/**
 * AUREOM HYDROGEN HSR OS
 * ETCS / ERTMS Signalling & Automatic Train Operation (ATO)
 */

import React from 'react';
import { TrainModel, TrackSegment } from '../../types/railway';
import { 
  Radio, 
  ShieldCheck, 
  Activity, 
  GitCommit, 
  Compass, 
  Clock,
  Layers,
  ArrowRight
} from 'lucide-react';

interface AtoSignallingViewProps {
  train: TrainModel;
  segments: TrackSegment[];
  allTrains: TrainModel[];
}

export const AtoSignallingView: React.FC<AtoSignallingViewProps> = ({
  train,
  segments,
  allTrains,
}) => {
  const ma = train.movementAuthority;
  const currentSpeed = train.dynamics.speedKmh;

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto bg-[#07090c] p-4 space-y-4 select-none">
      {/* Top ETCS Movement Authority Banner */}
      <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4">
        <div className="flex items-center justify-between border-b border-[#1e2633] pb-3 mb-3">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono-num font-bold text-[#00e5ff]">RADIO BLOCK CENTRE (RBC) LINK</span>
              <span className="text-[10px] font-mono-num px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                ETCS LEVEL 3 (MOVING BLOCK)
              </span>
            </div>
            <h2 className="text-lg font-display font-bold text-white mt-0.5">
              Movement Authority Envelope — {train.id} ({ma.authorityId})
            </h2>
          </div>

          <div className="flex items-center space-x-2 text-xs font-mono-num">
            <span className="text-slate-400">SUPERVISED DISTANCE:</span>
            <span className="text-xl font-bold text-white">
              {(ma.targetDistanceMeters / 1000).toFixed(1)} <span className="text-xs text-slate-400">km</span>
            </span>
          </div>
        </div>

        {/* Dynamic Braking Supervision Profiles (Indication, Permitted, Warning, Emergency) */}
        <div className="bg-[#090b0e] border border-[#1e2633] rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between text-xs font-mono-num">
            <span className="text-slate-400 font-bold uppercase">
              ERA SUBSET-026 DYNAMIC BRAKING CURVES SUPERVISION
            </span>
            <span className="text-[#00e5ff]">
              EOA @ Km {ma.endOfAuthorityKm.toFixed(1)}
            </span>
          </div>

          {/* SVG Braking Curves Diagram */}
          <div className="h-56 bg-[#07090c] border border-[#1e2633] rounded p-2 relative overflow-hidden">
            <svg className="w-full h-full" viewBox="0 0 500 160">
              {/* Grid Lines */}
              <line x1="40" y1="20" x2="480" y2="20" stroke="#1e2633" strokeDasharray="3 3" />
              <line x1="40" y1="60" x2="480" y2="60" stroke="#1e2633" strokeDasharray="3 3" />
              <line x1="40" y1="100" x2="480" y2="100" stroke="#1e2633" strokeDasharray="3 3" />
              <line x1="40" y1="140" x2="480" y2="140" stroke="#334155" />
              <line x1="40" y1="10" x2="40" y2="140" stroke="#334155" />

              {/* Emergency Braking Intervention Curve (EBI) */}
              <path
                d="M 40 25 L 320 25 Q 400 30 460 140"
                fill="none"
                stroke="#ef4444"
                strokeWidth="2.5"
              />

              {/* Warning Curve (W) */}
              <path
                d="M 40 35 L 300 35 Q 380 40 440 140"
                fill="none"
                stroke="#f59e0b"
                strokeWidth="2"
                strokeDasharray="4 2"
              />

              {/* Permitted Speed Curve (P) */}
              <path
                d="M 40 45 L 280 45 Q 360 50 420 140"
                fill="none"
                stroke="#00e5ff"
                strokeWidth="2"
              />

              {/* Indication Curve (I) */}
              <path
                d="M 40 55 L 260 55 Q 340 60 400 140"
                fill="none"
                stroke="#10b981"
                strokeWidth="1.5"
                strokeDasharray="2 2"
              />

              {/* Current Train Speed & Location */}
              <circle cx="160" cy="45" r="6" fill="#ffffff" stroke="#00e5ff" strokeWidth="2" />
              <line x1="160" y1="10" x2="160" y2="140" stroke="#ffffff" strokeWidth="1" strokeDasharray="3 3" />
            </svg>

            {/* Legend Overlay */}
            <div className="absolute top-3 right-3 text-[9px] font-mono-num space-y-1 bg-[#0c1017]/90 p-2 rounded border border-[#1e2633]">
              <div className="flex items-center space-x-1.5 text-red-400">
                <span className="w-2.5 h-0.5 bg-red-400" />
                <span>EBI: Emergency Intervention ({ma.interventionSpeedKmh} km/h)</span>
              </div>
              <div className="flex items-center space-x-1.5 text-amber-400">
                <span className="w-2.5 h-0.5 bg-amber-400" />
                <span>W: Warning Curve ({ma.warningSpeedKmh} km/h)</span>
              </div>
              <div className="flex items-center space-x-1.5 text-[#00e5ff]">
                <span className="w-2.5 h-0.5 bg-[#00e5ff]" />
                <span>P: Permitted Speed ({ma.permittedSpeedKmh} km/h)</span>
              </div>
              <div className="flex items-center space-x-1.5 text-emerald-400">
                <span className="w-2.5 h-0.5 bg-emerald-400" />
                <span>I: Indication Curve (Driver Brake Alert)</span>
              </div>
            </div>
          </div>

          {/* Real-Time Braking Parameters */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono-num pt-1">
            <div className="bg-[#0c1017] p-2.5 rounded border border-[#1e2633]">
              <div className="text-[9px] text-slate-500">CURRENT SPEED</div>
              <div className="text-white font-bold text-sm">{currentSpeed.toFixed(1)} km/h</div>
            </div>
            <div className="bg-[#0c1017] p-2.5 rounded border border-[#1e2633]">
              <div className="text-[9px] text-slate-500">PERMITTED SPEED (V_perm)</div>
              <div className="text-[#00e5ff] font-bold text-sm">{ma.permittedSpeedKmh} km/h</div>
            </div>
            <div className="bg-[#0c1017] p-2.5 rounded border border-[#1e2633]">
              <div className="text-[9px] text-slate-500">SUPERVISION MARGIN</div>
              <div className="text-emerald-400 font-bold text-sm">
                +{(ma.permittedSpeedKmh - currentSpeed).toFixed(1)} km/h
              </div>
            </div>
            <div className="bg-[#0c1017] p-2.5 rounded border border-[#1e2633]">
              <div className="text-[9px] text-slate-500">EMERGENCY BRAKE DIST</div>
              <div className="text-purple-400 font-bold text-sm">{ma.emergencyBrakeDistanceMeters} m</div>
            </div>
          </div>
        </div>
      </div>

      {/* Balises Telegram Inspector & Moving Block Headway Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Balises Telegram Packet Stream */}
        <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e2633] pb-2">
            <div className="text-xs font-mono-num font-bold text-white uppercase flex items-center space-x-2">
              <Radio className="w-4 h-4 text-[#00e5ff]" />
              <span>TRACKSIDE EUROBALISE TELEGRAM DECODER</span>
            </div>
            <span className="text-[10px] font-mono-num text-emerald-400 font-bold">LIVE TELEGRAM 44/58</span>
          </div>

          <div className="space-y-2 text-xs font-mono-num">
            <div className="p-2.5 bg-[#090b0e] border border-[#1e2633] rounded space-y-1">
              <div className="flex justify-between text-[#00e5ff] font-bold text-[11px]">
                <span>PACKET 58: Movement Authority Parameters</span>
                <span>Seq #84920</span>
              </div>
              <div className="text-slate-300 text-[10px]">
                NID_BG: 412 | D_REF: 184200m | M_VERSION: 3.0 | V_MAIN: 350 km/h | T_EMA: 3600s
              </div>
            </div>

            <div className="p-2.5 bg-[#090b0e] border border-[#1e2633] rounded space-y-1">
              <div className="flex justify-between text-amber-400 font-bold text-[11px]">
                <span>PACKET 65: Temporary Speed Restriction (TSR)</span>
                <span>Active</span>
              </div>
              <div className="text-slate-300 text-[10px]">
                NID_TSR: 12 | D_TSR: 45000m | L_TSR: 8000m | V_TSR: 280 km/h
              </div>
            </div>

            <div className="p-2.5 bg-[#090b0e] border border-[#1e2633] rounded space-y-1">
              <div className="flex justify-between text-emerald-400 font-bold text-[11px]">
                <span>PACKET 44: Hydrogen Infrastructure Balise</span>
                <span>Verified</span>
              </div>
              <div className="text-slate-300 text-[10px]">
                NID_H2_HUB: 04 (FRA-GATEWAY) | CAPACITY_OK | GANTRIES: 8/8 READY
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Headway & Train Following Distances */}
        <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e2633] pb-2">
            <div className="text-xs font-mono-num font-bold text-white uppercase flex items-center space-x-2">
              <Clock className="w-4 h-4 text-[#00e5ff]" />
              <span>DYNAMIC MOVING BLOCK HEADWAYS (ETCS L3)</span>
            </div>
            <span className="text-[10px] font-mono-num text-slate-400">90s MINIMUM HEADWAY</span>
          </div>

          <div className="space-y-2 text-xs font-mono-num">
            {allTrains.slice(0, 4).map((t, idx) => (
              <div key={t.id} className="p-2.5 bg-[#090b0e] border border-[#1e2633] rounded flex items-center justify-between">
                <div>
                  <div className="font-bold text-white">{t.id} - {t.name}</div>
                  <div className="text-[10px] text-slate-400">
                    Pos: Km {t.dynamics.positionKm.toFixed(1)} | Spd: {t.dynamics.speedKmh.toFixed(0)} km/h
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[#00e5ff] font-bold">
                    {idx === 0 ? 'LEADER' : `${((allTrains[idx - 1].dynamics.positionKm - t.dynamics.positionKm) || 45).toFixed(1)} km separation`}
                  </div>
                  <div className="text-[10px] text-emerald-400 font-semibold">
                    {idx === 0 ? 'CLEAR TRACK' : 'HEADWAY NOMINAL'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
