/**
 * AUREOM HYDROGEN HSR OS
 * Engineering Physics Laboratory & Mathematical Formula Sandbox
 */

import React, { useState } from 'react';
import { Cpu, Activity, Play, RefreshCw, Layers } from 'lucide-react';

export const EngineeringLabView: React.FC = () => {
  // Sandbox Parameters
  const [speedKmh, setSpeedKmh] = useState<number>(350);
  const [gradientPercent, setGradientPercent] = useState<number>(1.5);
  const [dragCd, setDragCd] = useState<number>(0.142);
  const [frontalArea, setFrontalArea] = useState<number>(10.4);
  const [airDensity, setAirDensity] = useState<number>(1.205);
  const [trainMassTonnes, setTrainMassTonnes] = useState<number>(410);

  // Live Physics Calculations
  const speedMs = speedKmh / 3.6;
  const massKg = trainMassTonnes * 1000;
  const g = 9.80665;

  // 1. Aerodynamic Drag Force: F_aero = 0.5 * rho * Cd * A * v^2
  const aeroDragN = 0.5 * airDensity * dragCd * frontalArea * Math.pow(speedMs, 2);
  const aeroDragKn = aeroDragN / 1000;

  // 2. Rolling Resistance: F_roll = A + B * v
  const rollResistKn = (0.009 * massKg * g + 0.00015 * massKg * g * speedMs) / 1000;

  // 3. Gradient Force: F_grad = m * g * sin(theta) ~ m * g * (gradientPercent / 100)
  const gradForceKn = (massKg * g * (gradientPercent / 100)) / 1000;

  // Total Resisting Force
  const totalResistanceKn = aeroDragKn + rollResistKn + gradForceKn;

  // Required Wheel Traction Power: P = F * v
  const requiredPowerKw = totalResistanceKn * speedMs;

  // Hydrogen Mass Flow Rate (assuming 60% stack efficiency, LHV H2 = 120 MJ/kg)
  const lhvJoulesPerKg = 120e6;
  const stackEfficiency = 0.60;
  const h2MassFlowKgPerSec = (requiredPowerKw * 1000) / (lhvJoulesPerKg * stackEfficiency);
  const h2MassFlowKgPerHour = h2MassFlowKgPerSec * 3600;

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto bg-[#07090c] p-4 space-y-4 select-none">
      {/* Top Banner */}
      <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4 flex items-center justify-between">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono-num font-bold text-[#00e5ff]">RESEARCH LAB</span>
            <span className="text-[10px] font-mono-num px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-bold">
              FIRST-PRINCIPLES MATHEMATICAL DERIVATION
            </span>
          </div>
          <h2 className="text-lg font-display font-bold text-white mt-0.5">
            Aerodynamic, Thermodynamic & Kinematic Differential Equations
          </h2>
        </div>
      </div>

      {/* Equations Cards Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 1. Longitudinal Dynamics Equation */}
        <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4 space-y-2">
          <div className="text-xs font-mono-num font-bold text-[#00e5ff]">
            1. LONGITUDINAL TRAIN DYNAMICS (EULER-LAGRANGE)
          </div>
          <div className="p-3 bg-[#090b0e] border border-[#1e2633] rounded text-center text-sm font-mono-num text-white">
            m · (dv/dt) = F_traction - F_brake - F_davis - F_gradient - F_curve
          </div>
          <p className="text-[11px] font-mono-num text-slate-400">
            Governs continuous velocity integration along the 860km corridor with variable track geometries.
          </p>
        </div>

        {/* 2. Modified High-Speed Davis Formula */}
        <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4 space-y-2">
          <div className="text-xs font-mono-num font-bold text-emerald-400">
            2. MODIFIED HIGH-SPEED DAVIS RESISTANCE
          </div>
          <div className="p-3 bg-[#090b0e] border border-[#1e2633] rounded text-center text-sm font-mono-num text-white">
            R(v) = A + B·v + 0.5 · ρ · C_d · A_f · v²
          </div>
          <p className="text-[11px] font-mono-num text-slate-400">
            Combines mechanical rolling resistance (A), flange friction (B), and quadratic aerodynamic drag (C).
          </p>
        </div>

        {/* 3. Butler-Volmer Polarization Curve */}
        <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4 space-y-2">
          <div className="text-xs font-mono-num font-bold text-amber-400">
            3. FUEL CELL NERNST & OVERPOTENTIAL VOLTAGE
          </div>
          <div className="p-3 bg-[#090b0e] border border-[#1e2633] rounded text-center text-xs font-mono-num text-white">
            V_cell = E_nernst - (RT/αF)·ln(i/i_0) - i·R_membrane - (RT/nF)·ln(1 - i/i_limit)
          </div>
          <p className="text-[11px] font-mono-num text-slate-400">
            Models electrochemical activation, ohmic conduction, and mass-transport concentration losses.
          </p>
        </div>

        {/* 4. Aerodynamic Power Equation */}
        <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4 space-y-2">
          <div className="text-xs font-mono-num font-bold text-purple-400">
            4. CUBIC VELOCITY POWER RELATIONSHIP
          </div>
          <div className="p-3 bg-[#090b0e] border border-[#1e2633] rounded text-center text-sm font-mono-num text-white">
            P_aero = 0.5 · ρ · C_d · A_f · v³
          </div>
          <p className="text-[11px] font-mono-num text-slate-400">
            Demonstrates why high-speed rail power demands scale with the cube of velocity ($v^3$).
          </p>
        </div>
      </div>

      {/* Interactive Parameter Sandbox & Live Derivation Solver */}
      <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4 space-y-4">
        <div className="border-b border-[#1e2633] pb-2">
          <div className="text-xs font-mono-num font-bold text-white uppercase flex items-center space-x-2">
            <Cpu className="w-4 h-4 text-[#00e5ff]" />
            <span>INTERACTIVE FIRST-PRINCIPLES PARAMETER SOLVER</span>
          </div>
          <p className="text-[11px] font-mono-num text-slate-400 mt-0.5">
            Adjust physical variables to evaluate instant aerodynamic drag, required wheel traction power, and hydrogen burn rate.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Sliders Column 1 */}
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs font-mono-num text-slate-300 mb-1">
                <span>CRUISE SPEED (v):</span>
                <strong className="text-white">{speedKmh} km/h ({(speedMs).toFixed(1)} m/s)</strong>
              </div>
              <input
                type="range"
                min="100"
                max="380"
                step="5"
                value={speedKmh}
                onChange={(e) => setSpeedKmh(Number(e.target.value))}
                className="w-full h-2 bg-[#151d28] rounded accent-[#00e5ff]"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono-num text-slate-300 mb-1">
                <span>TRACK GRADIENT:</span>
                <strong className="text-white">{gradientPercent > 0 ? `+${gradientPercent}%` : `${gradientPercent}%`}</strong>
              </div>
              <input
                type="range"
                min="-3.0"
                max="3.5"
                step="0.1"
                value={gradientPercent}
                onChange={(e) => setGradientPercent(Number(e.target.value))}
                className="w-full h-2 bg-[#151d28] rounded accent-emerald-400"
              />
            </div>
          </div>

          {/* Sliders Column 2 */}
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs font-mono-num text-slate-300 mb-1">
                <span>DRAG COEFFICIENT (C_d):</span>
                <strong className="text-white">{dragCd.toFixed(3)}</strong>
              </div>
              <input
                type="range"
                min="0.10"
                max="0.25"
                step="0.005"
                value={dragCd}
                onChange={(e) => setDragCd(Number(e.target.value))}
                className="w-full h-2 bg-[#151d28] rounded accent-purple-400"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono-num text-slate-300 mb-1">
                <span>TRAIN TOTAL MASS (m):</span>
                <strong className="text-white">{trainMassTonnes} Tonnes</strong>
              </div>
              <input
                type="range"
                min="350"
                max="600"
                step="10"
                value={trainMassTonnes}
                onChange={(e) => setTrainMassTonnes(Number(e.target.value))}
                className="w-full h-2 bg-[#151d28] rounded accent-amber-400"
              />
            </div>
          </div>

          {/* Real-Time Solved Outputs */}
          <div className="bg-[#090b0e] border border-[#1e2633] rounded-lg p-3 space-y-2 text-xs font-mono-num">
            <div className="text-[10px] font-bold text-[#00e5ff] uppercase border-b border-[#1e2633] pb-1">
              DERIVED POWER & HYDROGEN REQUIREMENTS
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">AERO DRAG FORCE (F_aero):</span>
              <strong className="text-white">{aeroDragKn.toFixed(1)} kN</strong>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">GRADIENT FORCE (F_grad):</span>
              <strong className="text-white">{gradForceKn.toFixed(1)} kN</strong>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">TOTAL RESISTANCE:</span>
              <strong className="text-white">{totalResistanceKn.toFixed(1)} kN</strong>
            </div>

            <div className="flex justify-between border-t border-[#1e2633] pt-1">
              <span className="text-[#00e5ff] font-bold">REQUIRED TRACTION POWER:</span>
              <strong className="text-white text-sm">{Math.max(0, requiredPowerKw).toFixed(0)} kW</strong>
            </div>

            <div className="flex justify-between">
              <span className="text-emerald-400 font-bold">H2 MASS FLOW RATE:</span>
              <strong className="text-emerald-400 text-sm">{Math.max(0, h2MassFlowKgPerHour).toFixed(1)} kg/h</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
