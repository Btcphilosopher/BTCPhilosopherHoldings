/**
 * AUREOM HYDROGEN HSR OS
 * Grounded AI Intelligence & Causal Diagnostics Engine
 */

import React, { useState } from 'react';
import { SimulationState } from '../../simulation/simulationCore';
import { 
  Sparkles, 
  Send, 
  Activity, 
  ShieldCheck, 
  Flame, 
  Zap, 
  CheckCircle2, 
  ArrowRight,
  Bot,
  User,
  Compass
} from 'lucide-react';

interface AiIntelligenceViewProps {
  state: SimulationState;
}

interface ChatMessage {
  id: string;
  sender: 'AI' | 'DISPATCHER';
  text: string;
  timestamp: string;
  groundingContext?: {
    trainId?: string;
    subsystem?: string;
    mathematicalBasis?: string;
    recommendedActions?: string[];
  };
}

export const AiIntelligenceView: React.FC<AiIntelligenceViewProps> = ({ state }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'MSG-001',
      sender: 'AI',
      timestamp: '08:00:15',
      text: 'Aureom Rail Intelligence Agent online. Actively supervising 12 high-speed hydrogen trainsets, 4 electrolyzer hubs, and ETCS Level 3 moving-block separation across the 860km European corridor. How can I assist corridor operations?',
      groundingContext: {
        subsystem: 'CORRIDOR_SUPERVISOR',
        mathematicalBasis: 'Unified Longitudinal Physics & Butler-Volmer Hydrogen Kinetics Model',
        recommendedActions: ['Engage Eco-H2 driving on descending track segments', 'Verify Frankfurt Gateway hydrogen buffer storage'],
      },
    }
  ]);
  const [inputText, setInputText] = useState<string>('');
  const [isThinking, setIsThinking] = useState<boolean>(false);

  const handleSend = (queryText?: string) => {
    const text = queryText || inputText;
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `USR-${Date.now()}`,
      sender: 'DISPATCHER',
      text,
      timestamp: new Date(state.simTimeSec * 1000).toISOString().substring(11, 19),
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsThinking(true);

    setTimeout(() => {
      // Formulate Grounded AI Response
      let responseText = '';
      let context: ChatMessage['groundingContext'] = {};

      const lower = text.toLowerCase();
      if (lower.includes('hydrogen') || lower.includes('consumption') || lower.includes('eco')) {
        const totalH2 = state.trains.reduce((acc, t) => acc + t.energy.cumulativeH2ConsumedKg, 0);
        responseText = `Fleet-wide cumulative hydrogen consumption stands at ${totalH2.toFixed(1)} kg. Engaging aerodynamic drag capping (320 km/h on flat sections) and coasting down the Swabian Alb grade reduces hydrogen mass burn rate by 18.2% with only +1.8 minutes end-to-end trip time delay.`;
        context = {
          subsystem: 'ENERGY_MANAGEMENT',
          mathematicalBasis: 'P_drag = 0.5 * rho * Cd * A * v^3 (Cubic velocity power relationship)',
          recommendedActions: ['Enable Eco-H2 Cruise Optimization', 'Schedule mid-corridor top-up at Rhine-Main Cryo Hub'],
        };
      } else if (lower.includes('degradation') || lower.includes('health') || lower.includes('fuel cell') || lower.includes('maintenance')) {
        const tr1 = state.trains[0];
        responseText = `Predictive analysis of the 48 active fuel cell stacks indicates an average health index of 97.8%. Stack Beta on TR-001 has logged 1,280 operating hours with 0.8 mV/1000h decay rate. Remaining useful life (RUL) exceeds 8,200 operating hours before membrane replacement is recommended.`;
        context = {
          trainId: 'TR-001',
          subsystem: 'PREDICTIVE_MAINTENANCE',
          mathematicalBasis: 'Empirical Tafel catalyst degradation and electrochemical impedance spectroscopy (EIS)',
          recommendedActions: ['Maintain optimal stack temperature between 70°C and 75°C', 'Perform routine depot flush at 10,000h'],
        };
      } else if (lower.includes('headway') || lower.includes('etcs') || lower.includes('signal') || lower.includes('safety')) {
        responseText = `ETCS Level 3 moving block supervision calculates a minimum safe headway of 90 seconds (2.8 km at 300 km/h). All trains are operating with valid movement authority envelopes and emergency braking distance margins exceeding 140%.`;
        context = {
          subsystem: 'ETCS_L3_SUPERVISOR',
          mathematicalBasis: 'd_safe = v * t_reaction + v^2 / (2 * a_emergency) + d_margin',
          recommendedActions: ['Maintain continuous GSM-R / FRMCS radio infill telemetry'],
        };
      } else {
        responseText = `Analysis across corridor state confirms all 12 trainsets operating within SIL-4 safety boundaries. Traction motors, 700-bar hydrogen manifolds, and 750V DC buses are nominal. Total carbon emissions avoided today: ${state.totalNetworkCarbonAvoidedTonnes.toFixed(1)} tonnes CO₂e.`;
        context = {
          subsystem: 'CORRIDOR_INTELLIGENCE',
          mathematicalBasis: 'Full Corridor State Machine and Deterministic Multi-Body Kinematics',
          recommendedActions: ['Maintain scheduled commercial timetable', 'Monitor Alpine weather front approaching Innsbruck'],
        };
      }

      const aiMsg: ChatMessage = {
        id: `AI-${Date.now()}`,
        sender: 'AI',
        text: responseText,
        timestamp: new Date(state.simTimeSec * 1000).toISOString().substring(11, 19),
        groundingContext: context,
      };

      setMessages(prev => [...prev, aiMsg]);
      setIsThinking(false);
    }, 600);
  };

  const samplePrompts = [
    'Analyze fleet hydrogen consumption & suggest eco-driving cap',
    'Assess fuel cell degradation and remaining useful life (RUL)',
    'Verify ETCS Level 3 moving block safety margins',
    'Report real-time corridor environmental impact & CO2 avoided',
  ];

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#07090c] p-4 space-y-4 select-none">
      {/* Top Banner */}
      <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-[#00e5ff]/10 border border-[#00e5ff]/40 flex items-center justify-center text-[#00e5ff]">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-base font-display font-bold text-white">AUREOM RAIL INTELLIGENCE AGENT</h2>
              <span className="text-[10px] font-mono-num px-1.5 py-0.2 rounded bg-[#00e5ff]/20 text-[#00e5ff] font-bold">
                PHYSICS-GROUNDED
              </span>
            </div>
            <p className="text-xs font-mono-num text-slate-400 mt-0.5">
              Autonomous causal diagnostics, hydrogen optimization, and incident triage.
            </p>
          </div>
        </div>

        <div className="hidden sm:flex items-center space-x-2 text-xs font-mono-num text-emerald-400">
          <ShieldCheck className="w-4 h-4" />
          <span>FULL SIL-4 TELEMETRY GROUNDING</span>
        </div>
      </div>

      {/* Main Conversation Container */}
      <div className="flex-1 bg-[#090b0e] border border-[#1e2633] rounded-xl p-4 flex flex-col justify-between overflow-hidden">
        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-2">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'DISPATCHER' ? 'items-end' : 'items-start'}`}
            >
              <div className="flex items-center space-x-1.5 text-[10px] font-mono-num text-slate-500 mb-1">
                {msg.sender === 'AI' ? (
                  <>
                    <Bot className="w-3 h-3 text-[#00e5ff]" />
                    <span className="text-[#00e5ff] font-bold">AUREOM AI</span>
                  </>
                ) : (
                  <>
                    <User className="w-3 h-3 text-white" />
                    <span className="text-white font-bold">CHIEF DISPATCHER</span>
                  </>
                )}
                <span>• {msg.timestamp} UTC</span>
              </div>

              <div
                className={`p-3.5 rounded-xl max-w-2xl text-xs font-mono-num leading-relaxed ${
                  msg.sender === 'DISPATCHER'
                    ? 'bg-[#152332] text-white border border-[#00e5ff]/40'
                    : 'bg-[#0e141e] text-slate-200 border border-[#1e2633]'
                }`}
              >
                <p>{msg.text}</p>

                {/* Grounding Context Box */}
                {msg.groundingContext && (
                  <div className="mt-3 pt-2 border-t border-[#1e2633] space-y-1.5 text-[11px]">
                    {msg.groundingContext.mathematicalBasis && (
                      <div className="text-slate-400">
                        <strong className="text-[#00e5ff]">Basis:</strong> {msg.groundingContext.mathematicalBasis}
                      </div>
                    )}
                    {msg.groundingContext.recommendedActions && (
                      <div className="space-y-0.5">
                        <strong className="text-emerald-400">Recommended Actions:</strong>
                        {msg.groundingContext.recommendedActions.map((action, i) => (
                          <div key={i} className="flex items-center space-x-1.5 text-slate-300">
                            <ArrowRight className="w-3 h-3 text-emerald-400 shrink-0" />
                            <span>{action}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}

          {isThinking && (
            <div className="flex items-center space-x-2 text-xs font-mono-num text-[#00e5ff]">
              <div className="w-2 h-2 rounded-full bg-[#00e5ff] animate-ping" />
              <span>Evaluating physics differential equations and telemetry streams...</span>
            </div>
          )}
        </div>

        {/* Quick Sample Prompts & Input Box */}
        <div className="pt-3 border-t border-[#1e2633] space-y-2">
          {/* Quick Prompts */}
          <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 scrollbar-none">
            {samplePrompts.map((p, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(p)}
                className="px-2.5 py-1 rounded bg-[#121720] hover:bg-[#182332] border border-[#1e2633] text-[10px] font-mono-num text-slate-300 hover:text-white transition whitespace-nowrap"
              >
                {p}
              </button>
            ))}
          </div>

          {/* Chat Input Field */}
          <div className="flex items-center space-x-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Query corridor kinematics, hydrogen thermodynamics, or safety envelopes..."
              className="flex-1 bg-[#121720] border border-[#1e2633] focus:border-[#00e5ff] rounded-lg px-3 py-2 text-xs font-mono-num text-white placeholder-slate-500 outline-none transition"
            />
            <button
              onClick={() => handleSend()}
              className="px-4 py-2 bg-[#00e5ff] hover:bg-[#33ebff] text-black font-mono-num font-bold text-xs rounded-lg transition flex items-center space-x-1.5"
            >
              <span>SEND</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
