/**
 * AUREOM HYDROGEN HSR OS
 * High-Speed Driver Cab & ETCS Driver-Machine Interface (DMI)
 */

import React, { useState } from 'react';
import { TrainModel } from '../../types/railway';
import { 
  Gauge, 
  ShieldAlert, 
  Flame, 
  Zap, 
  Radio, 
  Volume2, 
  Lock, 
  Unlock, 
  Power, 
  Sliders,
  CheckCircle,
  AlertOctagon,
  ArrowRight
} from 'lucide-react';

interface DriverCabViewProps {
  train: TrainModel;
  onSetControls: (
    trainId: string,
    tractionPercent: number,
    brakePercent: number,
    mode?: TrainModel['autonomyMode'],
    emergencyBrake?: boolean
  ) => void;
}

export const DriverCabView: React.FC<DriverCabViewProps> = ({ train, onSetControls }) => {
  const [tractionHandle, setTractionHandle] = useState<number>(train.cabTractionHandlePercent);
  const [brakeHandle, setBrakeHandle] = useState<number>(train.cabBrakeHandlePercent);
  const [radioAck, setRadioAck] = useState<boolean>(true);

  const speed = train.dynamics.speedKmh;
  const maxSpeed = 400; // gauge max
  const permittedSpeed = train.movementAuthority.permittedSpeedKmh;
  const targetSpeed = train.dynamics.targetSpeedKmh;
  const interventionSpeed = train.movementAuthority.interventionSpeedKmh;

  // Handle notch changes
  const updateTraction = (val: number) => {
    setTractionHandle(val);
    setBrakeHandle(0);
    onSetControls(train.id, val, 0);
  };

  const updateBrake = (val: number) => {
    setBrakeHandle(val);
    setTractionHandle(0);
    onSetControls(train.id, 0, val);
  };

  const triggerEmergencyStop = () => {
    setTractionHandle(0);
    setBrakeHandle(100);
    onSetControls(train.id, 0, 100, undefined, true);
  };

  const resetEmergencyStop = () => {
    onSetControls(train.id, 0, 0, undefined, false);
  };

  // Speedometer Angle Calculation (-135 deg to +135 deg)
  const speedAngle = -135 + (Math.min(speed, maxSpeed) / maxSpeed) * 270;
  const permAngle = -135 + (Math.min(permittedSpeed, maxSpeed) / maxSpeed) * 270;

  return (
    <div className="flex-1 flex flex-col xl:flex-row h-full overflow-y-auto bg-[#07090c] p-4 gap-4 select-none">
      {/* Left: Main ETCS Driver-Machine Interface (DMI) */}
      <div className="flex-1 bg-[#0a0e14] border border-[#1e2633] rounded-xl p-5 shadow-2xl flex flex-col justify-between">
        {/* DMI Top Status Header */}
        <div className="flex items-center justify-between border-b border-[#1e2633] pb-3 text-xs font-mono-num">
          <div className="flex items-center space-x-3">
            <div className="px-2 py-1 rounded bg-[#00e5ff]/20 text-[#00e5ff] font-bold border border-[#00e5ff]/40">
              ETCS LEVEL 3
            </div>
            <div className="text-white font-semibold">
              TRAIN {train.id} - {train.serviceCode}
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-slate-400">AUTONOMY:</span>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
              {train.autonomyMode}
            </span>
          </div>
        </div>

        {/* Center DMI Speedometer & Movement Authority Vector */}
        <div className="my-6 flex flex-col md:flex-row items-center justify-around gap-8">
          {/* Circular ERA / ETCS Speedometer */}
          <div className="relative w-72 h-72 flex items-center justify-center">
            {/* SVG Speedometer Dial */}
            <svg className="w-full h-full" viewBox="0 0 240 240">
              {/* Outer Gauge Track */}
              <circle
                cx="120"
                cy="120"
                r="95"
                fill="none"
                stroke="#151d28"
                strokeWidth="16"
                strokeDasharray="447"
                strokeDashoffset="111"
                transform="rotate(135 120 120)"
              />

              {/* Permitted Speed Band (Yellow / Blue) */}
              <circle
                cx="120"
                cy="120"
                r="95"
                fill="none"
                stroke="#00e5ff"
                strokeWidth="16"
                strokeDasharray="447"
                strokeDashoffset={447 - (permittedSpeed / maxSpeed) * 335}
                transform="rotate(135 120 120)"
                opacity="0.3"
              />

              {/* Current Speed Arc */}
              <circle
                cx="120"
                cy="120"
                r="95"
                fill="none"
                stroke={speed > permittedSpeed ? '#ef4444' : '#00e5ff'}
                strokeWidth="16"
                strokeDasharray="447"
                strokeDashoffset={447 - (speed / maxSpeed) * 335}
                transform="rotate(135 120 120)"
              />

              {/* Speed Ticks (0, 50, 100, 150, 200, 250, 300, 350, 400) */}
              {[0, 50, 100, 150, 200, 250, 300, 350, 400].map((tick) => {
                const angle = -135 + (tick / maxSpeed) * 270;
                const rad = (angle * Math.PI) / 180;
                const x1 = 120 + Math.cos(rad) * 80;
                const y1 = 120 + Math.sin(rad) * 80;
                const x2 = 120 + Math.cos(rad) * 72;
                const y2 = 120 + Math.sin(rad) * 72;
                const tx = 120 + Math.cos(rad) * 60;
                const ty = 120 + Math.sin(rad) * 60;

                return (
                  <g key={tick}>
                    <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="#475569" strokeWidth="2" />
                    <text
                      x={tx}
                      y={ty + 3}
                      fill="#94a3b8"
                      fontSize="9"
                      fontFamily="monospace"
                      textAnchor="middle"
                    >
                      {tick}
                    </text>
                  </g>
                );
              })}

              {/* Needle Indicator */}
              <g transform={`rotate(${speedAngle} 120 120)`}>
                <line x1="120" y1="120" x2="120" y2="35" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" />
                <circle cx="120" cy="120" r="8" fill="#00e5ff" stroke="#ffffff" strokeWidth="2" />
              </g>
            </svg>

            {/* Speed Digital Readout in Center */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none mt-16">
              <span className="text-4xl font-mono-num font-bold text-white tracking-tight">
                {speed.toFixed(0)}
              </span>
              <span className="text-[10px] font-mono-num text-[#00e5ff] font-semibold tracking-wider">
                KM / H
              </span>
              <span className="text-[9px] font-mono-num text-slate-400 mt-1">
                PERM: {permittedSpeed} | TGT: {targetSpeed.toFixed(0)}
              </span>
            </div>
          </div>

          {/* Movement Authority & Target Distance Column */}
          <div className="bg-[#0e141e] border border-[#1e2633] rounded-lg p-4 w-64 space-y-3">
            <div className="text-[11px] font-mono-num text-[#00e5ff] font-bold uppercase flex items-center justify-between">
              <span>MOVEMENT AUTHORITY</span>
              <span>ETCS L3</span>
            </div>

            <div className="space-y-1 text-xs font-mono-num">
              <div className="flex justify-between text-slate-400">
                <span>TARGET DISTANCE:</span>
                <span className="text-white font-bold">
                  {(train.movementAuthority.targetDistanceMeters / 1000).toFixed(2)} km
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>EOA LOCATION:</span>
                <span className="text-white font-bold">
                  Km {train.movementAuthority.endOfAuthorityKm.toFixed(1)}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>EMERGENCY BRAKE DIST:</span>
                <span className="text-purple-400 font-bold">
                  {train.movementAuthority.emergencyBrakeDistanceMeters.toFixed(0)} m
                </span>
              </div>
            </div>

            {/* Distance Countdown Bar */}
            <div className="space-y-1 pt-2 border-t border-[#1e2633]">
              <div className="flex justify-between text-[10px] font-mono-num text-slate-400">
                <span>BRAKING MARGIN</span>
                <span className="text-emerald-400">NOMINAL (98.4%)</span>
              </div>
              <div className="h-2 bg-[#151d28] rounded overflow-hidden">
                <div className="h-full bg-gradient-to-r from-emerald-500 to-[#00e5ff] w-[98%]" />
              </div>
            </div>
          </div>
        </div>

        {/* DMI Bottom Subsystem Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-[#1e2633] text-xs font-mono-num">
          <div className="bg-[#0e141e] border border-[#1e2633] rounded p-2.5">
            <div className="text-[9px] text-[#00e5ff] font-bold flex items-center space-x-1">
              <Flame className="w-3 h-3" />
              <span>H2 MANIFOLD</span>
            </div>
            <div className="text-white font-bold text-sm mt-0.5">
              {train.hydrogenTanks[0]?.pressureBar.toFixed(1)} <span className="text-[10px] text-slate-400">bar</span>
            </div>
            <div className="text-[9px] text-slate-400">Tanks: 4/4 Open</div>
          </div>

          <div className="bg-[#0e141e] border border-[#1e2633] rounded p-2.5">
            <div className="text-[9px] text-emerald-400 font-bold flex items-center space-x-1">
              <Zap className="w-3 h-3" />
              <span>BATTERY BUFFER</span>
            </div>
            <div className="text-white font-bold text-sm mt-0.5">
              {train.battery.socPercent.toFixed(1)}% <span className="text-[10px] text-slate-400">SOC</span>
            </div>
            <div className="text-[9px] text-slate-400">{train.battery.voltageV.toFixed(0)} V | {train.battery.temperatureCelsius.toFixed(0)}°C</div>
          </div>

          <div className="bg-[#0e141e] border border-[#1e2633] rounded p-2.5">
            <div className="text-[9px] text-purple-400 font-bold flex items-center space-x-1">
              <Gauge className="w-3 h-3" />
              <span>TRACTION MOTORS</span>
            </div>
            <div className="text-white font-bold text-sm mt-0.5">
              {train.energy.tractionPowerKw.toFixed(0)} <span className="text-[10px] text-slate-400">kW</span>
            </div>
            <div className="text-[9px] text-slate-400">16x PMSM Active</div>
          </div>

          <div className="bg-[#0e141e] border border-[#1e2633] rounded p-2.5">
            <div className="text-[9px] text-amber-400 font-bold flex items-center space-x-1">
              <Radio className="w-3 h-3" />
              <span>RADIO INFILL</span>
            </div>
            <div className="text-white font-bold text-sm mt-0.5">
              GSM-R / FRMCS
            </div>
            <div className="text-[9px] text-emerald-400">Locked to Track Balise</div>
          </div>
        </div>
      </div>

      {/* Right: Master Physical Driver Desk & Notch Controllers */}
      <div className="w-full xl:w-96 bg-[#0a0e14] border border-[#1e2633] rounded-xl p-5 flex flex-col justify-between space-y-4">
        <div>
          <div className="border-b border-[#1e2633] pb-3">
            <div className="text-xs font-mono-num font-bold text-white uppercase flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-[#00e5ff]" />
              <span>CABINET CONTROLLER & DESK</span>
            </div>
            <p className="text-[10px] font-mono-num text-slate-400 mt-0.5">
              Direct traction/dynamic brake notch control and safety interlocks.
            </p>
          </div>

          {/* Autonomy Mode Switcher */}
          <div className="my-4">
            <label className="text-[10px] font-mono-num text-slate-400 uppercase font-semibold">
              ATO / DRIVER SUPERVISION MODE
            </label>
            <div className="grid grid-cols-2 gap-1.5 mt-1.5 text-xs font-mono-num">
              {(['ATO_SUPERVISED', 'MANUAL', 'AUTOMATIC', 'REMOTE_TELEOPERATION'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => onSetControls(train.id, tractionHandle, brakeHandle, mode)}
                  className={`py-1.5 px-2 rounded border transition text-[11px] font-bold ${
                    train.autonomyMode === mode
                      ? 'bg-[#00e5ff] text-black border-white'
                      : 'bg-[#121720] border-[#1e2633] text-slate-400 hover:text-white'
                  }`}
                >
                  {mode.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          {/* Combined Master Throttle / Brake Notch Sliders */}
          <div className="space-y-4 my-4">
            {/* Traction Handle */}
            <div className="bg-[#0e141e] border border-[#1e2633] rounded-lg p-3">
              <div className="flex justify-between text-xs font-mono-num mb-1">
                <span className="text-[#00e5ff] font-bold">TRACTION NOTCH</span>
                <span className="text-white font-bold">{tractionHandle}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={tractionHandle}
                onChange={(e) => updateTraction(Number(e.target.value))}
                className="w-full h-2 bg-[#151d28] rounded-lg appearance-none cursor-pointer accent-[#00e5ff]"
              />
              <div className="flex justify-between text-[9px] font-mono-num text-slate-500 mt-1">
                <span>0% COAST</span>
                <span>50%</span>
                <span>100% MAX ACCEL</span>
              </div>
            </div>

            {/* Service & Regenerative Brake Handle */}
            <div className="bg-[#0e141e] border border-[#1e2633] rounded-lg p-3">
              <div className="flex justify-between text-xs font-mono-num mb-1">
                <span className="text-purple-400 font-bold">DYNAMIC SERVICE BRAKE</span>
                <span className="text-white font-bold">{brakeHandle}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={brakeHandle}
                onChange={(e) => updateBrake(Number(e.target.value))}
                className="w-full h-2 bg-[#151d28] rounded-lg appearance-none cursor-pointer accent-purple-500"
              />
              <div className="flex justify-between text-[9px] font-mono-num text-slate-500 mt-1">
                <span>0% RELEASE</span>
                <span>50% REGEN</span>
                <span>100% FULL SERVICE</span>
              </div>
            </div>
          </div>

          {/* Secondary Cab Switchboard */}
          <div className="grid grid-cols-2 gap-2 text-xs font-mono-num">
            <button
              onClick={() => setRadioAck(!radioAck)}
              className={`p-2 rounded border flex items-center space-x-1.5 justify-center ${
                radioAck ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300' : 'bg-[#121720] border-[#1e2633] text-slate-400'
              }`}
            >
              <CheckCircle className="w-3.5 h-3.5" />
              <span>RADIO ACK</span>
            </button>

            <button
              className="p-2 rounded border bg-[#121720] border-[#1e2633] text-slate-300 hover:text-white flex items-center space-x-1.5 justify-center"
              onClick={() => alert(`Acoustic Horn Sounded: Train ${train.id}`)}
            >
              <Volume2 className="w-3.5 h-3.5 text-amber-400" />
              <span>HORN (120dB)</span>
            </button>
          </div>
        </div>

        {/* Big Red Emergency Stop Button */}
        <div className="pt-2 border-t border-[#1e2633]">
          {train.emergencyBrakeEngaged ? (
            <button
              onClick={resetEmergencyStop}
              className="w-full py-3 rounded-lg bg-amber-600 hover:bg-amber-500 text-black font-mono-num font-bold text-sm tracking-wider uppercase transition shadow-lg flex items-center justify-center space-x-2"
            >
              <AlertOctagon className="w-5 h-5" />
              <span>RESET EMERGENCY INTERLOCK</span>
            </button>
          ) : (
            <button
              onClick={triggerEmergencyStop}
              className="w-full py-3.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-mono-num font-bold text-sm tracking-wider uppercase transition shadow-[0_0_20px_rgba(239,68,68,0.4)] flex items-center justify-center space-x-2"
            >
              <AlertOctagon className="w-5 h-5 fill-current" />
              <span>EMERGENCY BRAKE (EBD)</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
