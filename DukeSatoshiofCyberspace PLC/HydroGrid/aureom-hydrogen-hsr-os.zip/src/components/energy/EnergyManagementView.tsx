/**
 * AUREOM HYDROGEN HSR OS
 * Energy Management System (EMS) & Fuel Cell Thermodynamics
 */

import React from 'react';
import { TrainModel } from '../../types/railway';
import { 
  Zap, 
  Flame, 
  Activity, 
  BatteryCharging, 
  ShieldCheck, 
  Cpu,
  ArrowRight,
  TrendingUp,
  Thermometer
} from 'lucide-react';

interface EnergyManagementViewProps {
  train: TrainModel;
  totalNetworkEnergyMwh: number;
  totalCarbonAvoidedTonnes: number;
}

export const EnergyManagementView: React.FC<EnergyManagementViewProps> = ({
  train,
  totalNetworkEnergyMwh,
  totalCarbonAvoidedTonnes,
}) => {
  const tractionPower = train.energy.tractionPowerKw;
  const fcPower = train.energy.fuelCellPowerKw;
  const batteryPower = train.battery.powerKw;
  const regenPower = train.energy.regenerativePowerKw;
  const auxPower = train.energy.auxiliaryPowerKw;

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto bg-[#07090c] p-4 space-y-4 select-none">
      {/* Top EMS Power Balance Bar */}
      <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4">
        <div className="flex items-center justify-between border-b border-[#1e2633] pb-3 mb-3">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono-num font-bold text-[#00e5ff]">HYBRID TRACTION DC BUS (750V)</span>
              <span className="text-[10px] font-mono-num px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                EMS SUPERVISOR ACTIVE
              </span>
            </div>
            <h2 className="text-lg font-display font-bold text-white mt-0.5">
              {train.name} — Real-Time Power Flow Balance
            </h2>
          </div>

          <div className="text-right text-xs font-mono-num">
            <div className="text-slate-400">TOTAL GENERATED TRACTION POWER</div>
            <div className="text-xl font-bold text-white">
              {(fcPower + batteryPower).toFixed(0)} <span className="text-xs text-slate-400">kW</span>
            </div>
          </div>
        </div>

        {/* Dynamic Visual Power Flow Diagram */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center bg-[#090b0e] border border-[#1e2633] rounded-lg p-4">
          {/* Generation Sources */}
          <div className="space-y-3">
            {/* Fuel Cell Array */}
            <div className="bg-[#121924] border border-[#00e5ff]/40 rounded p-3">
              <div className="flex items-center justify-between text-xs font-mono-num">
                <span className="text-[#00e5ff] font-bold flex items-center space-x-1">
                  <Flame className="w-3.5 h-3.5" />
                  <span>4x PEM FUEL CELL ARRAY</span>
                </span>
                <span className="text-white font-bold">{fcPower.toFixed(0)} kW</span>
              </div>
              <div className="text-[10px] font-mono-num text-slate-400 mt-1">
                Efficiency: {(train.fuelCellStacks[0]?.efficiency * 100 || 60).toFixed(1)}% | H2 Flow: {train.energy.h2MassFlowKgPerHour.toFixed(1)} kg/h
              </div>
            </div>

            {/* Battery Buffer */}
            <div className="bg-[#1a1710] border border-amber-500/40 rounded p-3">
              <div className="flex items-center justify-between text-xs font-mono-num">
                <span className="text-amber-400 font-bold flex items-center space-x-1">
                  <BatteryCharging className="w-3.5 h-3.5" />
                  <span>650 kWh LITHIUM-TITANATE</span>
                </span>
                <span className="text-white font-bold">{batteryPower.toFixed(0)} kW</span>
              </div>
              <div className="text-[10px] font-mono-num text-slate-400 mt-1">
                SOC: {train.battery.socPercent.toFixed(1)}% | C-Rate: {train.battery.cRate.toFixed(1)}C | {train.battery.voltageV.toFixed(0)}V
              </div>
            </div>
          </div>

          {/* Central 750V DC Bus Node */}
          <div className="flex flex-col items-center justify-center p-4 bg-[#111722] border-2 border-[#00e5ff]/50 rounded-xl shadow-[0_0_20px_rgba(0,229,255,0.15)] text-center">
            <Zap className="w-6 h-6 text-[#00e5ff] animate-pulse mb-1" />
            <span className="text-xs font-mono-num font-bold text-white">
              750V ISOLATED DC BUS
            </span>
            <span className="text-[10px] font-mono-num text-[#00e5ff] mt-0.5">
              POWER DISTRIBUTOR
            </span>
            <div className="mt-2 text-xs font-mono-num text-slate-300">
              NET FLOW: <strong className="text-white">{(fcPower + batteryPower - auxPower).toFixed(0)} kW</strong>
            </div>
          </div>

          {/* Loads & Regenerative Infeed */}
          <div className="space-y-3">
            {/* Traction Motors */}
            <div className="bg-[#161224] border border-purple-500/40 rounded p-3">
              <div className="flex items-center justify-between text-xs font-mono-num">
                <span className="text-purple-400 font-bold">16x PMSM TRACTION MOTORS</span>
                <span className="text-white font-bold">{tractionPower.toFixed(0)} kW</span>
              </div>
              <div className="text-[10px] font-mono-num text-slate-400 mt-1">
                Motor Current: 5,470 A | Tractive Force: {train.dynamics.tractiveForceKn.toFixed(1)} kN
              </div>
            </div>

            {/* Auxiliaries & HVAC */}
            <div className="bg-[#121720] border border-slate-700 rounded p-3">
              <div className="flex items-center justify-between text-xs font-mono-num">
                <span className="text-slate-300 font-bold">AUXILIARY & COMPRESSORS</span>
                <span className="text-white font-bold">{auxPower.toFixed(0)} kW</span>
              </div>
              <div className="text-[10px] font-mono-num text-slate-400 mt-1">
                HVAC, H2 Circulators, Control Computer & Sensors
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Fuel Cell Polarization & Battery Thermal Diagnostics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* PEM Fuel Cell Polarization Curve */}
        <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e2633] pb-2">
            <div className="text-xs font-mono-num font-bold text-white uppercase flex items-center space-x-2">
              <Activity className="w-4 h-4 text-[#00e5ff]" />
              <span>PEM FUEL CELL POLARIZATION CURVE (V-I)</span>
            </div>
            <span className="text-[10px] font-mono-num text-[#00e5ff]">
              TAFEL ACTIVATION + OHMIC + CONCENTRATION
            </span>
          </div>

          {/* SVG Polarization Chart */}
          <div className="h-48 bg-[#090b0e] border border-[#1e2633] rounded p-2 relative overflow-hidden">
            <svg className="w-full h-full" viewBox="0 0 300 150">
              {/* Grid Lines */}
              <line x1="30" y1="20" x2="290" y2="20" stroke="#1e2633" strokeDasharray="3 3" />
              <line x1="30" y1="60" x2="290" y2="60" stroke="#1e2633" strokeDasharray="3 3" />
              <line x1="30" y1="100" x2="290" y2="100" stroke="#1e2633" strokeDasharray="3 3" />
              <line x1="30" y1="130" x2="290" y2="130" stroke="#334155" />
              <line x1="30" y1="10" x2="30" y2="130" stroke="#334155" />

              {/* Theoretical Polarization Curve */}
              <path
                d="M 30 25 Q 70 50 140 70 T 260 115 Q 280 135 290 145"
                fill="none"
                stroke="#00e5ff"
                strokeWidth="2.5"
              />

              {/* Power Density Curve */}
              <path
                d="M 30 130 Q 150 20 280 120"
                fill="none"
                stroke="#10b981"
                strokeWidth="2"
                strokeDasharray="4 2"
              />

              {/* Current Operating Point */}
              <circle cx="150" cy="72" r="5" fill="#ffffff" stroke="#00e5ff" strokeWidth="2" />
              <line x1="150" y1="10" x2="150" y2="130" stroke="#ffffff" strokeWidth="0.8" strokeDasharray="2 2" />
            </svg>

            <div className="absolute top-3 right-3 text-[9px] font-mono-num space-y-0.5 bg-[#0c1017]/80 p-1.5 rounded border border-[#1e2633]">
              <div className="text-[#00e5ff] flex items-center space-x-1">
                <span className="w-2 h-0.5 bg-[#00e5ff] inline-block" />
                <span>Cell Voltage (V_cell = 0.68V)</span>
              </div>
              <div className="text-emerald-400 flex items-center space-x-1">
                <span className="w-2 h-0.5 bg-emerald-400 inline-block" />
                <span>Power Density (0.85 W/cm²)</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-xs font-mono-num text-slate-300">
            <div>
              <div className="text-[9px] text-slate-500">OPEN CIRCUIT (E_nernst)</div>
              <div className="text-white font-bold">1.229 V</div>
            </div>
            <div>
              <div className="text-[9px] text-slate-500">ACTIVATION LOSS (Tafel)</div>
              <div className="text-amber-400 font-bold">0.145 V</div>
            </div>
            <div>
              <div className="text-[9px] text-slate-500">OHMIC LOSS (R_membrane)</div>
              <div className="text-emerald-400 font-bold">0.210 V</div>
            </div>
          </div>
        </div>

        {/* 4 Fuel Cell Stacks Detailed Matrix */}
        <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e2633] pb-2">
            <div className="text-xs font-mono-num font-bold text-white uppercase flex items-center space-x-2">
              <Cpu className="w-4 h-4 text-[#00e5ff]" />
              <span>4x INDIVIDUAL PEM STACK HEALTH & THERMAL STATUS</span>
            </div>
            <span className="text-[10px] font-mono-num text-emerald-400">
              4/4 ONLINE
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {train.fuelCellStacks.map((stack) => (
              <div key={stack.stackId} className="bg-[#090b0e] border border-[#1e2633] rounded p-3 space-y-1.5">
                <div className="flex items-center justify-between text-xs font-mono-num">
                  <span className="font-bold text-white">{stack.stackId.replace('FC-STACK-', 'STACK ')}</span>
                  <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                    stack.state === 'OPTIMAL' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                  }`}>
                    {stack.state}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-1 text-[11px] font-mono-num">
                  <div className="text-slate-400">Power: <strong className="text-white">{stack.powerKw} kW</strong></div>
                  <div className="text-slate-400">Temp: <strong className="text-emerald-400">{stack.tempCelsius.toFixed(1)}°C</strong></div>
                  <div className="text-slate-400">Health: <strong className="text-[#00e5ff]">{stack.healthScore.toFixed(1)}%</strong></div>
                  <div className="text-slate-400">RUL: <strong className="text-white">{stack.remainingUsefulLifeHours}h</strong></div>
                </div>

                <div className="h-1 bg-[#151d28] rounded overflow-hidden">
                  <div style={{ width: `${stack.healthScore}%` }} className="bg-[#00e5ff] h-full" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
