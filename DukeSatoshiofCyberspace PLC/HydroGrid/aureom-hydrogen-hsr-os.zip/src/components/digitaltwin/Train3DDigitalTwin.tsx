/**
 * AUREOM HYDROGEN HSR OS
 * 3D High-Speed Hydrogen Train Digital Twin
 *
 * Interactive Three.js engineering model with multi-layer cutaway,
 * thermodynamic heat mapping, flow streams, and exploded view modes.
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { TrainModel } from '../../types/railway';
import { 
  Box, 
  Layers, 
  Eye, 
  Thermometer, 
  Zap, 
  Flame, 
  Maximize2, 
  RefreshCw,
  Activity,
  Rotate3d
} from 'lucide-react';

interface Train3DDigitalTwinProps {
  train: TrainModel;
}

export const Train3DDigitalTwin: React.FC<Train3DDigitalTwinProps> = ({ train }) => {
  const mountRef = useRef<HTMLDivElement>(null);

  // Layer Visibility State
  const [showShell, setShowShell] = useState<boolean>(true);
  const [showTanks, setShowTanks] = useState<boolean>(true);
  const [showFuelCells, setShowFuelCells] = useState<boolean>(true);
  const [showBattery, setShowBattery] = useState<boolean>(true);
  const [showBogies, setShowBogies] = useState<boolean>(true);
  const [isExploded, setIsExploded] = useState<boolean>(false);
  const [isThermalMode, setIsThermalMode] = useState<boolean>(false);
  const [selectedSubsystem, setSelectedSubsystem] = useState<string>('OVERVIEW');

  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);

  // Group references for layer animation
  const shellGroupRef = useRef<THREE.Group>(new THREE.Group());
  const tanksGroupRef = useRef<THREE.Group>(new THREE.Group());
  const fcGroupRef = useRef<THREE.Group>(new THREE.Group());
  const batteryGroupRef = useRef<THREE.Group>(new THREE.Group());
  const bogieGroupRef = useRef<THREE.Group>(new THREE.Group());

  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Initialize Scene, Camera & Renderer
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color('#07090c');
    scene.fog = new THREE.FogExp2('#07090c', 0.015);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    cameraRef.current = camera;
    camera.position.set(18, 9, 22);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    rendererRef.current = renderer;
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controlsRef.current = controls;
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2 + 0.05; // Don't clip below track
    controls.minDistance = 4;
    controls.maxDistance = 60;
    controls.target.set(0, 1.5, 0);

    // 2. Lighting Rig
    const ambientLight = new THREE.AmbientLight('#26354a', 1.8);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight('#00e5ff', 2.2);
    keyLight.position.set(20, 30, 15);
    keyLight.castShadow = true;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight('#ffffff', 1.5);
    fillLight.position.set(-20, 20, -15);
    scene.add(fillLight);

    const rimLight = new THREE.PointLight('#00e5ff', 3, 30);
    rimLight.position.set(0, -1, 0);
    scene.add(rimLight);

    // 3. Grid Platform & High-Speed Rails
    const gridHelper = new THREE.GridHelper(80, 40, '#00e5ff', '#1e2633');
    gridHelper.position.y = -0.05;
    scene.add(gridHelper);

    // Rails
    const railMat = new THREE.MeshStandardMaterial({ color: '#8b9bb4', metalness: 0.9, roughness: 0.2 });
    const railGeo = new THREE.BoxGeometry(70, 0.15, 0.1);
    const leftRail = new THREE.Mesh(railGeo, railMat);
    leftRail.position.set(0, 0.08, -0.7175);
    scene.add(leftRail);

    const rightRail = new THREE.Mesh(railGeo, railMat);
    rightRail.position.set(0, 0.08, 0.7175);
    scene.add(rightRail);

    // 4. Build Train Model Components

    // Master groups
    const shellGroup = new THREE.Group();
    const tanksGroup = new THREE.Group();
    const fcGroup = new THREE.Group();
    const batteryGroup = new THREE.Group();
    const bogieGroup = new THREE.Group();

    shellGroupRef.current = shellGroup;
    tanksGroupRef.current = tanksGroup;
    fcGroupRef.current = fcGroup;
    batteryGroupRef.current = batteryGroup;
    bogieGroupRef.current = bogieGroup;

    scene.add(shellGroup);
    scene.add(tanksGroup);
    scene.add(fcGroup);
    scene.add(batteryGroup);
    scene.add(bogieGroup);

    // A. Aerodynamic Streamliner Shell
    const shellMat = new THREE.MeshPhysicalMaterial({
      color: '#e2e8f0',
      metalness: 0.85,
      roughness: 0.15,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1,
      transparent: true,
      opacity: 0.82,
    });

    const bodyGeo = new THREE.BoxGeometry(22, 2.2, 2.8);
    const bodyMesh = new THREE.Mesh(bodyGeo, shellMat);
    bodyMesh.position.set(0, 2.0, 0);
    bodyMesh.castShadow = true;
    shellGroup.add(bodyMesh);

    // Streamlined Nose Cone
    const noseGeo = new THREE.ConeGeometry(1.4, 4.5, 32);
    noseGeo.rotateZ(-Math.PI / 2);
    const noseMesh = new THREE.Mesh(noseGeo, shellMat);
    noseMesh.position.set(13.2, 1.8, 0);
    noseMesh.scale.set(1, 0.8, 1.0);
    shellGroup.add(noseMesh);

    // Cockpit Windshield (Aero Tint Glass)
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: '#00e5ff',
      metalness: 0.1,
      roughness: 0.05,
      transmission: 0.9,
      transparent: true,
      opacity: 0.7,
    });
    const windshieldGeo = new THREE.BoxGeometry(1.8, 0.7, 2.0);
    const windshield = new THREE.Mesh(windshieldGeo, glassMat);
    windshield.position.set(11.8, 2.5, 0);
    windshield.rotation.z = -0.4;
    shellGroup.add(windshield);

    // B. 4x 700-bar Hydrogen Tanks (Roof-Mounted Aerodynamic Fairing)
    const tankMat = new THREE.MeshStandardMaterial({
      color: '#00e5ff',
      metalness: 0.6,
      roughness: 0.3,
      emissive: '#003344',
      emissiveIntensity: 0.4,
    });

    for (let i = 0; i < 4; i++) {
      const tankGeo = new THREE.CylinderGeometry(0.38, 0.38, 3.8, 24);
      tankGeo.rotateZ(Math.PI / 2);
      const tankMesh = new THREE.Mesh(tankGeo, tankMat);
      tankMesh.position.set(-6 + i * 4.2, 3.35, 0);
      tanksGroup.add(tankMesh);

      // Tank End Domes
      const domeGeo = new THREE.SphereGeometry(0.38, 16, 16);
      const leftDome = new THREE.Mesh(domeGeo, tankMat);
      leftDome.position.set(-6 + i * 4.2 - 1.9, 3.35, 0);
      tanksGroup.add(leftDome);

      const rightDome = new THREE.Mesh(domeGeo, tankMat);
      rightDome.position.set(-6 + i * 4.2 + 1.9, 3.35, 0);
      tanksGroup.add(rightDome);
    }

    // C. 4x 450 kW Proton Exchange Membrane (PEM) Fuel Cell Stacks
    const fcMat = new THREE.MeshStandardMaterial({
      color: '#10b981',
      metalness: 0.8,
      roughness: 0.2,
      emissive: '#064e3b',
      emissiveIntensity: 0.5,
    });

    for (let i = 0; i < 4; i++) {
      const fcGeo = new THREE.BoxGeometry(1.4, 0.9, 1.2);
      const fcMesh = new THREE.Mesh(fcGeo, fcMat);
      fcMesh.position.set(-4 + i * 2.8, 1.8, 0);
      fcGroup.add(fcMesh);

      // Cooling Pipes
      const pipeGeo = new THREE.CylinderGeometry(0.06, 0.06, 1.8, 12);
      pipeGeo.rotateX(Math.PI / 2);
      const pipeMat = new THREE.MeshStandardMaterial({ color: '#38bdf8' });
      const pipeMesh = new THREE.Mesh(pipeGeo, pipeMat);
      pipeMesh.position.set(-4 + i * 2.8, 2.3, 0);
      fcGroup.add(pipeMesh);
    }

    // D. 650 kWh Subfloor Lithium-Titanate Battery Pack & 750V DC Bus
    const batteryMat = new THREE.MeshStandardMaterial({
      color: '#f59e0b',
      metalness: 0.7,
      roughness: 0.3,
      emissive: '#78350f',
      emissiveIntensity: 0.3,
    });
    const batteryGeo = new THREE.BoxGeometry(12, 0.45, 2.2);
    const batteryMesh = new THREE.Mesh(batteryGeo, batteryMat);
    batteryMesh.position.set(0, 0.85, 0);
    batteryGroup.add(batteryMesh);

    // E. High-Speed Bogies & Wheelsets (2x Front & Rear Bogies)
    const bogieMat = new THREE.MeshStandardMaterial({
      color: '#334155',
      metalness: 0.95,
      roughness: 0.15,
    });
    const wheelMat = new THREE.MeshStandardMaterial({
      color: '#94a3b8',
      metalness: 0.98,
      roughness: 0.05,
    });

    const createBogie = (xPos: number) => {
      const bGroup = new THREE.Group();
      bGroup.position.set(xPos, 0.45, 0);

      // Bogie Frame
      const frameGeo = new THREE.BoxGeometry(3.6, 0.25, 2.1);
      const frameMesh = new THREE.Mesh(frameGeo, bogieMat);
      bGroup.add(frameMesh);

      // 4 Wheels
      const wheelGeo = new THREE.CylinderGeometry(0.46, 0.46, 0.12, 24);
      wheelGeo.rotateX(Math.PI / 2);

      [[-1.3, -0.7175], [-1.3, 0.7175], [1.3, -0.7175], [1.3, 0.7175]].forEach(([wx, wz]) => {
        const wheel = new THREE.Mesh(wheelGeo, wheelMat);
        wheel.position.set(wx, 0.01, wz);
        bGroup.add(wheel);
      });

      return bGroup;
    };

    bogieGroup.add(createBogie(8.0));
    bogieGroup.add(createBogie(-8.0));

    // 5. Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      controls.update();

      // Subtle track vibrations if train in motion
      if (train.dynamics.speedKmh > 10) {
        bodyMesh.position.y = 2.0 + Math.sin(Date.now() * 0.02) * 0.003;
      }

      renderer.render(scene, camera);
    };
    animate();

    // 6. Window Resize Handler
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  // Update Layer Visibilities & Explode Offsets
  useEffect(() => {
    shellGroupRef.current.visible = showShell;
    tanksGroupRef.current.visible = showTanks;
    fcGroupRef.current.visible = showFuelCells;
    batteryGroupRef.current.visible = showBattery;
    bogieGroupRef.current.visible = showBogies;

    const explodeOffset = isExploded ? 2.5 : 0;
    shellGroupRef.current.position.y = explodeOffset * 1.4;
    tanksGroupRef.current.position.y = explodeOffset * 1.8;
    fcGroupRef.current.position.y = explodeOffset * 0.8;
    batteryGroupRef.current.position.y = -explodeOffset * 0.5;
    bogieGroupRef.current.position.y = -explodeOffset * 1.0;
  }, [showShell, showTanks, showFuelCells, showBattery, showBogies, isExploded]);

  // Camera Presets
  const setCameraPreset = (preset: 'FRONT' | 'TOP' | 'SIDE' | 'ROOF_TANKS' | 'FUEL_CELL') => {
    if (!cameraRef.current || !controlsRef.current) return;
    const cam = cameraRef.current;
    const ctrl = controlsRef.current;

    switch (preset) {
      case 'FRONT':
        cam.position.set(22, 3, 0);
        ctrl.target.set(10, 1.5, 0);
        break;
      case 'TOP':
        cam.position.set(0, 30, 0.1);
        ctrl.target.set(0, 1.5, 0);
        break;
      case 'SIDE':
        cam.position.set(0, 2, 22);
        ctrl.target.set(0, 1.5, 0);
        break;
      case 'ROOF_TANKS':
        cam.position.set(0, 9, 8);
        ctrl.target.set(0, 3.4, 0);
        setShowTanks(true);
        setSelectedSubsystem('H2_STORAGE');
        break;
      case 'FUEL_CELL':
        cam.position.set(0, 4, 7);
        ctrl.target.set(0, 1.8, 0);
        setShowFuelCells(true);
        setSelectedSubsystem('FUEL_CELL_ARRAY');
        break;
    }
    ctrl.update();
  };

  return (
    <div className="flex-1 flex flex-col lg:flex-row h-full overflow-hidden bg-[#07090c]">
      {/* 3D Viewport */}
      <div className="flex-1 relative flex flex-col">
        {/* Top Floating Telemetry & Mode Overlay */}
        <div className="absolute top-4 left-4 z-10 flex flex-wrap items-center gap-2 pointer-events-auto">
          <div className="bg-[#0c1017]/90 border border-[#1e2633] rounded px-3 py-1.5 backdrop-blur flex items-center space-x-2 text-xs font-mono-num">
            <span className="w-2 h-2 rounded-full bg-[#00e5ff] animate-pulse" />
            <span className="font-bold text-white">{train.name}</span>
            <span className="text-slate-400">|</span>
            <span className="text-[#00e5ff]">{train.dynamics.speedKmh.toFixed(0)} km/h</span>
          </div>

          <button
            onClick={() => setIsExploded(!isExploded)}
            className={`px-3 py-1.5 rounded border text-xs font-mono-num font-bold transition flex items-center space-x-1.5 ${
              isExploded 
                ? 'bg-[#00e5ff] text-black border-white' 
                : 'bg-[#0c1017]/90 border-[#1e2633] text-slate-200 hover:text-white hover:bg-[#151c27]'
            }`}
          >
            <Rotate3d className="w-3.5 h-3.5" />
            <span>{isExploded ? 'COLLAPSE MODEL' : 'EXPLODE LAYERS'}</span>
          </button>
        </div>

        {/* Camera Preset Quick Buttons */}
        <div className="absolute bottom-4 left-4 z-10 flex items-center space-x-1.5 bg-[#0c1017]/90 border border-[#1e2633] rounded p-1 backdrop-blur pointer-events-auto text-[11px] font-mono-num">
          <span className="text-slate-400 px-1 text-[10px]">CAMERA:</span>
          {(['FRONT', 'TOP', 'SIDE', 'ROOF_TANKS', 'FUEL_CELL'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setCameraPreset(p)}
              className="px-2 py-0.5 rounded hover:bg-[#1e2633] text-slate-300 hover:text-white transition"
            >
              {p.replace('_', ' ')}
            </button>
          ))}
        </div>

        {/* Three.js Canvas Container */}
        <div ref={mountRef} className="flex-1 w-full h-full cursor-grab active:cursor-grabbing" />
      </div>

      {/* Right Layer Inspector & Subsystem Telemetry */}
      <div className="w-full lg:w-96 bg-[#090b0e] border-t lg:border-t-0 lg:border-l border-[#1e2633] p-4 flex flex-col justify-between overflow-y-auto space-y-4">
        <div>
          <div className="border-b border-[#1e2633] pb-3">
            <div className="text-xs font-mono-num font-bold text-[#00e5ff] tracking-wider flex items-center space-x-1.5">
              <Layers className="w-4 h-4 text-[#00e5ff]" />
              <span>DIGITAL TWIN ANATOMY LAYERS</span>
            </div>
            <p className="text-[11px] font-mono-num text-slate-400 mt-1">
              Toggle multi-tier engineering envelopes to inspect interior power distribution.
            </p>
          </div>

          {/* Layer Toggles */}
          <div className="space-y-2 my-3">
            {[
              { id: 'shell', label: '1. Aerodynamic Carbon Shell', active: showShell, toggle: () => setShowShell(!showShell), color: '#e2e8f0' },
              { id: 'tanks', label: '2. 4x 700-bar H2 Roof Tanks', active: showTanks, toggle: () => setShowTanks(!showTanks), color: '#00e5ff' },
              { id: 'fc', label: '3. 4x 450 kW PEM Fuel Cells', active: showFuelCells, toggle: () => setShowFuelCells(!showFuelCells), color: '#10b981' },
              { id: 'battery', label: '4. 650 kWh Lithium Titanate', active: showBattery, toggle: () => setShowBattery(!showBattery), color: '#f59e0b' },
              { id: 'bogies', label: '5. PMSM Traction Bogies', active: showBogies, toggle: () => setShowBogies(!showBogies), color: '#94a3b8' },
            ].map((layer) => (
              <button
                key={layer.id}
                onClick={layer.toggle}
                className={`w-full p-2 rounded border text-xs font-mono-num flex items-center justify-between transition ${
                  layer.active
                    ? 'bg-[#121924] border-[#00e5ff]/40 text-white'
                    : 'bg-[#090b0e] border-[#1e2633] text-slate-500 hover:text-slate-300'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: layer.color }} />
                  <span>{layer.label}</span>
                </div>
                <Eye className={`w-3.5 h-3.5 ${layer.active ? 'text-[#00e5ff]' : 'text-slate-600'}`} />
              </button>
            ))}
          </div>

          {/* Subsystem Real-Time Telemetry */}
          <div className="bg-[#0c0f14] border border-[#1e2633] rounded p-3 space-y-2">
            <div className="text-[10px] font-mono-num text-[#00e5ff] uppercase font-bold flex items-center justify-between">
              <span>ACTIVE PROBE: 4x PEM STACK ARRAY</span>
              <span className="text-emerald-400">NOMINAL SIL-4</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono-num">
              <div>
                <div className="text-[9px] text-slate-500">TOTAL FC POWER</div>
                <div className="text-white font-bold text-sm">
                  {train.energy.fuelCellPowerKw.toFixed(0)} <span className="text-[10px] text-slate-400">kW</span>
                </div>
              </div>
              <div>
                <div className="text-[9px] text-slate-500">AVG STACK TEMP</div>
                <div className="text-emerald-400 font-bold text-sm">
                  {train.fuelCellStacks[0]?.tempCelsius.toFixed(1)}°C
                </div>
              </div>
              <div>
                <div className="text-[9px] text-slate-500">H2 MASS FLOW RATE</div>
                <div className="text-white font-bold">
                  {train.energy.h2MassFlowKgPerHour.toFixed(1)} kg/h
                </div>
              </div>
              <div>
                <div className="text-[9px] text-slate-500">INLET PRESSURE</div>
                <div className="text-white font-bold">
                  {train.fuelCellStacks[0]?.inletPressureBar.toFixed(1)} bar
                </div>
              </div>
            </div>
          </div>

          {/* Battery DC Bus Health */}
          <div className="bg-[#0c0f14] border border-[#1e2633] rounded p-3 mt-2 space-y-2">
            <div className="text-[10px] font-mono-num text-amber-400 uppercase font-bold flex items-center justify-between">
              <span>TRACTION BATTERY & DC BUS</span>
              <span className="text-white">{train.battery.voltageV.toFixed(0)} V</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono-num">
              <div>
                <div className="text-[9px] text-slate-500">STATE OF CHARGE (SOC)</div>
                <div className="text-white font-bold text-sm">
                  {train.battery.socPercent.toFixed(1)}%
                </div>
              </div>
              <div>
                <div className="text-[9px] text-slate-500">BATTERY POWER DISPATCH</div>
                <div className="text-amber-400 font-bold text-sm">
                  {train.battery.powerKw.toFixed(0)} kW
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Environmental Footprint */}
        <div className="bg-[#00e5ff]/5 border border-[#00e5ff]/20 rounded p-3 text-xs font-mono-num text-slate-300">
          <div className="text-[9px] text-[#00e5ff] font-bold uppercase mb-1">
            LIFECYCLE EMISSIONS AVOIDED
          </div>
          <div className="text-white font-bold text-base">
            {train.energy.carbonAvoidedKgCo2.toFixed(0)} kg CO₂e
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">
            Compared to diesel-electric high-speed multiple units.
          </p>
        </div>
      </div>
    </div>
  );
};
