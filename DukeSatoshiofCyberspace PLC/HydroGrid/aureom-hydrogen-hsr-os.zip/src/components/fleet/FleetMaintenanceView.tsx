/**
 * AUREOM HYDROGEN HSR OS
 * Fleet Management, Predictive Health & Maintenance Depot
 */

import React, { useState } from 'react';
import { TrainModel } from '../../types/railway';
import { 
  Wrench, 
  ShieldCheck, 
  Activity, 
  AlertTriangle, 
  CheckCircle2, 
  Clock,
  Cpu,
  Flame,
  Plus
} from 'lucide-react';

interface FleetMaintenanceViewProps {
  trains: TrainModel[];
  onSelectTrain: (trainId: string) => void;
}

export const FleetMaintenanceView: React.FC<FleetMaintenanceViewProps> = ({ trains, onSelectTrain }) => {
  const [selectedFleetTrain, setSelectedFleetTrain] = useState<string>(trains[0]?.id || 'TR-001');
  const activeTrain = trains.find(t => t.id === selectedFleetTrain) || trains[0];

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto bg-[#07090c] p-4 space-y-4 select-none">
      {/* Top Fleet Availability Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#0c1017] border border-[#1e2633] rounded-lg p-3">
          <div className="text-[10px] font-mono-num text-[#00e5ff] font-bold flex items-center space-x-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>FLEET AVAILABILITY RATE</span>
          </div>
          <div className="text-xl font-mono-num font-bold text-white mt-1">
            91.7% <span className="text-xs text-emerald-400 font-normal">(11/12 In Revenue)</span>
          </div>
          <p className="text-[10px] font-mono-num text-slate-400 mt-1">1 Testbed / Standby Depot.</p>
        </div>

        <div className="bg-[#0c1017] border border-[#1e2633] rounded-lg p-3">
          <div className="text-[10px] font-mono-num text-emerald-400 font-bold flex items-center space-x-1">
            <Activity className="w-3.5 h-3.5" />
            <span>AVG FUEL CELL STACK HEALTH</span>
          </div>
          <div className="text-xl font-mono-num font-bold text-white mt-1">
            97.8%
          </div>
          <p className="text-[10px] font-mono-num text-slate-400 mt-1">Nominal membrane hydration & catalyst.</p>
        </div>

        <div className="bg-[#0c1017] border border-[#1e2633] rounded-lg p-3">
          <div className="text-[10px] font-mono-num text-purple-400 font-bold flex items-center space-x-1">
            <Clock className="w-3.5 h-3.5" />
            <span>MEAN TIME BETWEEN SERVICE</span>
          </div>
          <div className="text-xl font-mono-num font-bold text-white mt-1">
            8,400 <span className="text-xs text-slate-400">hours</span>
          </div>
          <p className="text-[10px] font-mono-num text-slate-400 mt-1">Next depot overhaul in 42 days.</p>
        </div>

        <div className="bg-[#0c1017] border border-[#1e2633] rounded-lg p-3">
          <div className="text-[10px] font-mono-num text-amber-400 font-bold flex items-center space-x-1">
            <Wrench className="w-3.5 h-3.5" />
            <span>OPEN WORK ORDERS</span>
          </div>
          <div className="text-xl font-mono-num font-bold text-white mt-1">
            2 Routine
          </div>
          <p className="text-[10px] font-mono-num text-slate-400 mt-1">Zero safety-critical blockers.</p>
        </div>
      </div>

      {/* Fleet Table & Selected Asset Deep Inspection */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Fleet Matrix (2 cols on large screens) */}
        <div className="xl:col-span-2 bg-[#0c1017] border border-[#1e2633] rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-[#1e2633] pb-2">
            <div className="text-xs font-mono-num font-bold text-white uppercase flex items-center space-x-2">
              <Wrench className="w-4 h-4 text-[#00e5ff]" />
              <span>12-TRAIN ACTIVE ASSET HEALTH MATRIX</span>
            </div>
            <span className="text-[10px] font-mono-num text-slate-400">CLICK ROW TO INSPECT</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono-num">
              <thead>
                <tr className="border-b border-[#1e2633] text-slate-400 text-[10px]">
                  <th className="py-2">TRAIN ID</th>
                  <th className="py-2">FORMATION</th>
                  <th className="py-2">FC HEALTH</th>
                  <th className="py-2">BATTERY SOH</th>
                  <th className="py-2">H2 SEALS</th>
                  <th className="py-2">OP STATE</th>
                  <th className="py-2">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e2633]/60 text-slate-300">
                {trains.map((t) => {
                  const isSelected = t.id === selectedFleetTrain;
                  const avgFcHealth = t.fuelCellStacks.reduce((acc, s) => acc + s.healthScore, 0) / t.fuelCellStacks.length;
                  const batterySoh = t.battery.sohPercent;

                  return (
                    <tr
                      key={t.id}
                      onClick={() => {
                        setSelectedFleetTrain(t.id);
                        onSelectTrain(t.id);
                      }}
                      className={`cursor-pointer transition ${
                        isSelected ? 'bg-[#152332] text-white' : 'hover:bg-[#121720]'
                      }`}
                    >
                      <td className="py-2.5 font-bold text-white">{t.id}</td>
                      <td className="py-2.5 text-slate-400">{t.fleetClass.replace('AUREOM-', '')}</td>
                      <td className="py-2.5">
                        <span className={`font-bold ${avgFcHealth < 70 ? 'text-red-400' : avgFcHealth < 90 ? 'text-amber-400' : 'text-emerald-400'}`}>
                          {avgFcHealth.toFixed(1)}%
                        </span>
                      </td>
                      <td className="py-2.5 text-white font-medium">{batterySoh.toFixed(1)}%</td>
                      <td className="py-2.5 text-emerald-400">0.02 ppm (OK)</td>
                      <td className="py-2.5 text-slate-300">{t.operationalState}</td>
                      <td className="py-2.5">
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300">
                          NOMINAL
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Selected Asset RUL & Predictive Analytics Card */}
        <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4 space-y-3">
          <div className="border-b border-[#1e2633] pb-2">
            <div className="text-xs font-mono-num font-bold text-[#00e5ff]">
              PREDICTIVE ASSET DIAGNOSTIC: {activeTrain.id}
            </div>
            <div className="text-base font-display font-bold text-white mt-0.5">
              {activeTrain.name}
            </div>
          </div>

          <div className="space-y-3 text-xs font-mono-num">
            {/* RUL Fuel Cell Stacks */}
            <div className="bg-[#090b0e] border border-[#1e2633] rounded p-3 space-y-1.5">
              <div className="text-[10px] font-bold text-[#00e5ff] flex justify-between">
                <span>REMAINING USEFUL LIFE (RUL)</span>
                <span>8,400h Remaining</span>
              </div>
              <p className="text-[11px] text-slate-300">
                Catalyst degradation model projects 0.8 mV/1000h voltage decay rate.
              </p>
              <div className="h-1.5 bg-[#151d28] rounded overflow-hidden">
                <div style={{ width: '84%' }} className="bg-[#00e5ff] h-full" />
              </div>
            </div>

            {/* Subfloor Battery Health */}
            <div className="bg-[#090b0e] border border-[#1e2633] rounded p-3 space-y-1.5">
              <div className="text-[10px] font-bold text-amber-400 flex justify-between">
                <span>LITHIUM-TITANATE (LTO) SOH</span>
                <span>{activeTrain.battery.sohPercent.toFixed(1)}% SOH</span>
              </div>
              <p className="text-[11px] text-slate-300">
                Zero dendrite formation at high C-rate (8C charge/discharge).
              </p>
            </div>

            {/* Quick Work Order Action */}
            <button
              onClick={() => alert(`Routine Depot Work Order Scheduled for ${activeTrain.id} at Frankfurt Maintenance Facility.`)}
              className="w-full py-2 rounded bg-[#182332] border border-[#00e5ff]/50 hover:bg-[#00e5ff]/20 text-[#00e5ff] font-bold text-xs transition flex items-center justify-center space-x-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>SCHEDULE DEPOT SERVICE</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
