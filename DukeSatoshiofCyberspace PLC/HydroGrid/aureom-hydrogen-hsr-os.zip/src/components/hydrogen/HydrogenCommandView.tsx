/**
 * AUREOM HYDROGEN HSR OS
 * Hydrogen Infrastructure Grid & Refuelling Command
 */

import React from 'react';
import { HydrogenHub, TrainModel } from '../../types/railway';
import { 
  Flame, 
  Layers, 
  Activity, 
  TrendingUp, 
  Droplet, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle,
  Truck,
  ShieldCheck
} from 'lucide-react';

interface HydrogenCommandViewProps {
  hubs: HydrogenHub[];
  trains: TrainModel[];
  onRefuelTrain?: (trainId: string, hubId: string) => void;
}

export const HydrogenCommandView: React.FC<HydrogenCommandViewProps> = ({ hubs, trains }) => {
  const totalStorageCapacityKg = hubs.reduce((sum, h) => sum + h.totalCapacityKg, 0);
  const totalCurrentStorageKg = hubs.reduce((sum, h) => sum + h.currentStorageKg, 0);
  const totalProductionRateKgH = hubs.reduce((sum, h) => sum + h.productionRateKgPerHour, 0);
  const totalDailyThroughputKg = hubs.reduce((sum, h) => sum + h.dailyThroughputKg, 0);

  const storagePercentage = (totalCurrentStorageKg / totalStorageCapacityKg) * 100;

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto bg-[#07090c] p-4 space-y-4 select-none">
      {/* Top Hydrogen Grid KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#0c1017] border border-[#1e2633] rounded-lg p-3">
          <div className="flex items-center justify-between text-[10px] font-mono-num text-[#00e5ff] font-bold">
            <span className="flex items-center space-x-1">
              <Flame className="w-3.5 h-3.5" />
              <span>TOTAL NETWORK H2 STORAGE</span>
            </span>
            <span>{storagePercentage.toFixed(1)}%</span>
          </div>
          <div className="text-xl font-mono-num font-bold text-white mt-1">
            {totalCurrentStorageKg.toLocaleString()} <span className="text-xs text-slate-400">/ {totalStorageCapacityKg.toLocaleString()} kg</span>
          </div>
          <div className="h-1.5 bg-[#151d28] rounded mt-2 overflow-hidden">
            <div style={{ width: `${storagePercentage}%` }} className="bg-[#00e5ff] h-full" />
          </div>
        </div>

        <div className="bg-[#0c1017] border border-[#1e2633] rounded-lg p-3">
          <div className="text-[10px] font-mono-num text-emerald-400 font-bold flex items-center space-x-1">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>GREEN ELECTROLYSIS PRODUCTION</span>
          </div>
          <div className="text-xl font-mono-num font-bold text-white mt-1">
            {totalProductionRateKgH.toLocaleString()} <span className="text-xs text-slate-400">kg/h</span>
          </div>
          <p className="text-[10px] font-mono-num text-slate-400 mt-1">
            Powered by offshore & Alpine renewables.
          </p>
        </div>

        <div className="bg-[#0c1017] border border-[#1e2633] rounded-lg p-3">
          <div className="text-[10px] font-mono-num text-purple-400 font-bold flex items-center space-x-1">
            <Droplet className="w-3.5 h-3.5" />
            <span>CRYOGENIC LIQUID BUFFER</span>
          </div>
          <div className="text-xl font-mono-num font-bold text-white mt-1">
            {hubs.reduce((acc, h) => acc + h.cryogenicStorageKg, 0).toLocaleString()} <span className="text-xs text-slate-400">kg LH2</span>
          </div>
          <p className="text-[10px] font-mono-num text-slate-400 mt-1">
            Sub-cooled at 20 K (-253°C) for rapid gantry dispensing.
          </p>
        </div>

        <div className="bg-[#0c1017] border border-[#1e2633] rounded-lg p-3">
          <div className="text-[10px] font-mono-num text-amber-400 font-bold flex items-center space-x-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>AVERAGE HYDROGEN COST</span>
          </div>
          <div className="text-xl font-mono-num font-bold text-white mt-1">
            €5.05 <span className="text-xs text-slate-400">/ kg H2</span>
          </div>
          <p className="text-[10px] font-mono-num text-emerald-400 mt-1">
            Levelized cost beating fossil diesel parity.
          </p>
        </div>
      </div>

      {/* 4 Major Hub Terminals Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {hubs.map((hub) => {
          const fillRate = (hub.currentStorageKg / hub.totalCapacityKg) * 100;
          return (
            <div key={hub.id} className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-[#1e2633] pb-2">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-mono-num font-bold text-[#00e5ff]">{hub.id}</span>
                    <span className="text-[10px] font-mono-num px-1.5 py-0.2 rounded bg-[#1e2633] text-slate-300">
                      Km {hub.trackPositionKm}
                    </span>
                  </div>
                  <h3 className="text-base font-display font-bold text-white mt-0.5">
                    {hub.name}
                  </h3>
                </div>

                <span className={`text-[10px] font-mono-num font-bold px-2 py-0.5 rounded ${
                  hub.deliveryPipelineStatus === 'NOMINAL'
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : 'bg-amber-500/20 text-amber-400'
                }`}>
                  {hub.deliveryPipelineStatus}
                </span>
              </div>

              {/* Hub Metrics Grid */}
              <div className="grid grid-cols-3 gap-2 text-xs font-mono-num">
                <div>
                  <div className="text-[9px] text-slate-500">CURRENT STORAGE</div>
                  <div className="text-white font-bold">{hub.currentStorageKg.toLocaleString()} kg</div>
                  <div className="text-[9px] text-slate-400">{fillRate.toFixed(1)}% Capacity</div>
                </div>
                <div>
                  <div className="text-[9px] text-slate-500">PRESSURE RATING</div>
                  <div className="text-[#00e5ff] font-bold">{hub.storagePressureBar} bar</div>
                  <div className="text-[9px] text-slate-400">Type IV Composite</div>
                </div>
                <div>
                  <div className="text-[9px] text-slate-500">PRODUCTION RATE</div>
                  <div className="text-emerald-400 font-bold">{hub.productionRateKgPerHour} kg/h</div>
                  <div className="text-[9px] text-slate-400">{hub.sourceType}</div>
                </div>
              </div>

              {/* Capacity Bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] font-mono-num text-slate-400">
                  <span>STORAGE FILL LEVEL</span>
                  <span className="text-white font-semibold">{fillRate.toFixed(1)}%</span>
                </div>
                <div className="h-2 bg-[#151d28] rounded overflow-hidden">
                  <div
                    style={{ width: `${fillRate}%` }}
                    className={`h-full ${fillRate < 20 ? 'bg-red-500' : fillRate < 40 ? 'bg-amber-500' : 'bg-[#00e5ff]'}`}
                  />
                </div>
              </div>

              {/* Refuelling Bays State */}
              <div className="pt-2 border-t border-[#1e2633] flex items-center justify-between text-xs font-mono-num">
                <div className="flex items-center space-x-1 text-slate-400">
                  <Truck className="w-3.5 h-3.5 text-[#00e5ff]" />
                  <span>REFUELLING GANTRIES:</span>
                </div>
                <span className="text-white font-bold">
                  {hub.activeRefuellings} Active / {hub.refuellingBayCount} Total Bays
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Fleet Hydrogen Refuelling Schedule & Status */}
      <div className="bg-[#0c1017] border border-[#1e2633] rounded-xl p-4">
        <div className="flex items-center justify-between mb-3 border-b border-[#1e2633] pb-2">
          <div className="text-xs font-mono-num font-bold text-white uppercase flex items-center space-x-2">
            <Flame className="w-4 h-4 text-[#00e5ff]" />
            <span>FLEET HYDROGEN TANK STATUS & AUTONOMOUS REFUELLING DISPATCH</span>
          </div>
          <span className="text-[10px] font-mono-num text-slate-400">
            DISPENSING FLOW: 3.6 kg/min (700 BAR FAST GANTRIES)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono-num">
            <thead>
              <tr className="border-b border-[#1e2633] text-slate-400 text-[10px]">
                <th className="py-2">TRAIN</th>
                <th className="py-2">FORMATION</th>
                <th className="py-2">H2 LEVEL (%)</th>
                <th className="py-2">CURRENT PRESSURE</th>
                <th className="py-2">BURN RATE</th>
                <th className="py-2">NEXT REFUELLING HUB</th>
                <th className="py-2">DISPATCH STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e2633]/60 text-slate-300">
              {trains.map((train) => {
                const fillPercent = train.hydrogenTanks[0]?.fillPercentage || 0;
                const pressure = train.hydrogenTanks[0]?.pressureBar || 0;
                const burnRate = train.energy.h2MassFlowKgPerHour;

                return (
                  <tr key={train.id} className="hover:bg-[#121720]">
                    <td className="py-2 font-bold text-white">{train.id}</td>
                    <td className="py-2 text-slate-400">{train.fleetClass.replace('AUREOM-', '')}</td>
                    <td className="py-2">
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-white">{fillPercent.toFixed(0)}%</span>
                        <div className="w-16 h-1.5 bg-[#1e2633] rounded overflow-hidden">
                          <div
                            style={{ width: `${fillPercent}%` }}
                            className={`h-full ${fillPercent < 25 ? 'bg-red-500' : 'bg-[#00e5ff]'}`}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="py-2 font-bold text-white">{pressure.toFixed(0)} bar</td>
                    <td className="py-2 text-[#00e5ff]">{burnRate.toFixed(1)} kg/h</td>
                    <td className="py-2 text-slate-300">
                      {fillPercent < 45 ? 'HUB-RHINE (Frankfurt)' : 'Nominal Cruise Range'}
                    </td>
                    <td className="py-2">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        train.operationalState === 'REFUELLING'
                          ? 'bg-purple-500/20 text-purple-300'
                          : fillPercent < 30
                          ? 'bg-amber-500/20 text-amber-300'
                          : 'bg-emerald-500/20 text-emerald-300'
                      }`}>
                        {train.operationalState === 'REFUELLING' ? 'DISPENSING' : fillPercent < 30 ? 'DISPATCH REQUIRED' : 'EN ROUTE'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
