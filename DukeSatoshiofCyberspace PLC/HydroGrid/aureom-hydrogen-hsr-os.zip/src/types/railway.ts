/**
 * AUREOM HYDROGEN HSR OS
 * Canonical Railway Domain Model & Types
 */

export type SimulationMode = 'SIMULATION' | 'SHADOW_MODE' | 'HIL_INTERFACE';

export type AtomAutonomyMode = 
  | 'MANUAL' 
  | 'ASSISTED' 
  | 'ATO_SUPERVISED' 
  | 'AUTOMATIC' 
  | 'DEGRADED' 
  | 'EMERGENCY';

export type SafetySupervisionLevel = 
  | 'ALLOW' 
  | 'LIMIT' 
  | 'BRAKE' 
  | 'EMERGENCY_BRAKE' 
  | 'STOP' 
  | 'ISOLATE';

export type HydrogenSafetyState = 
  | 'NORMAL' 
  | 'WARNING' 
  | 'HIGH_PRESSURE' 
  | 'HIGH_TEMPERATURE' 
  | 'LEAK_SUSPECTED' 
  | 'ISOLATED' 
  | 'EMERGENCY';

export type TrainOperationalState = 
  | 'IN_SERVICE_RUNNING' 
  | 'ACCELERATING' 
  | 'CRUISING' 
  | 'COASTING' 
  | 'REGENERATIVE_BRAKING' 
  | 'STATION_DWELL' 
  | 'REFUELLING' 
  | 'DEPOT_STANDBY' 
  | 'MAINTENANCE' 
  | 'DEGRADED_OPERATION' 
  | 'EMERGENCY_STOPPED';

export type RefuellingBayState = 
  | 'SCHEDULED' 
  | 'ARRIVING' 
  | 'CONNECTED' 
  | 'CHECKING' 
  | 'REFUELLING' 
  | 'VERIFYING' 
  | 'COMPLETE' 
  | 'FAILED' 
  | 'ISOLATED';

export interface GeoCoordinate {
  lat: number;
  lng: number;
  altitudeMeters: number;
}

export interface Station {
  id: string;
  name: string;
  code: string;
  location: GeoCoordinate;
  trackPositionKm: number;
  platformCount: number;
  hasHydrogenHub: boolean;
  dailyPassengerVolume: number;
  turnaroundTimeMinutes: number;
}

export interface HydrogenHub {
  id: string;
  name: string;
  stationId: string;
  trackPositionKm: number;
  totalCapacityKg: number;
  currentStorageKg: number;
  storagePressureBar: number;
  productionRateKgPerHour: number;
  cryogenicStorageKg: number;
  refuellingBayCount: number;
  activeRefuellings: number;
  deliveryPipelineStatus: 'NOMINAL' | 'HIGH_DEMAND' | 'REDUCED_FLOW' | 'OFFLINE';
  sourceType: 'GREEN_ELECTROLYSIS' | 'CRYOGENIC_IMPORT' | 'GRID_HYBRID';
  dailyThroughputKg: number;
  costPerKgEur: number;
}

export interface TrackSegment {
  id: string;
  startKm: number;
  endKm: number;
  lengthMeters: number;
  gradientPercent: number; // e.g. +1.8% or -2.4%
  curveRadiusMeters: number; // 0 for straight, >0 for curve
  maxAllowedSpeedKmh: number;
  cantMm: number;
  tunnel: boolean;
  tunnelName?: string;
  bridge: boolean;
  bridgeName?: string;
  etcsLevel: 2 | 3;
  balisesCount: number;
  trackCondition: 'NOMINAL' | 'SLIGHT_WEAR' | 'WEATHER_AFFECTED' | 'RESTRICTED';
  startCoord: GeoCoordinate;
  endCoord: GeoCoordinate;
}

export interface FuelCellStackConfig {
  id: string;
  ratedPowerKw: number; // e.g. 500kW per stack (4 stacks = 2000kW)
  openCircuitVoltageV: number;
  nominalCurrentA: number;
  nominalVoltageV: number;
  peakEfficiency: number; // e.g. 0.62 (62%)
  operatingTempCelsius: number;
  cellCount: number;
  activeAreaCm2: number;
}

export interface FuelCellTelemetry {
  stackId: string;
  powerKw: number;
  voltageV: number;
  currentA: number;
  efficiency: number;
  tempCelsius: number;
  inletPressureBar: number;
  h2MassFlowGramsPerSec: number;
  healthScore: number; // 0 - 100%
  operatingHours: number;
  remainingUsefulLifeHours: number;
  degradationRate: number; // % per 1000h
  state: 'OPTIMAL' | 'LOAD_FOLLOWING' | 'THERMAL_THROTTLE' | 'DEGRADED' | 'SHUTDOWN';
}

export interface HydrogenTankTelemetry {
  tankId: string;
  capacityKg: number;
  currentMassKg: number;
  fillPercentage: number;
  pressureBar: number;
  temperatureKelvin: number;
  leakRatePpm: number;
  valveState: 'OPEN' | 'REGULATING' | 'ISOLATED' | 'EMERGENCY_VENT';
  safetyState: HydrogenSafetyState;
}

export interface BatteryTelemetry {
  capacityKwh: number;
  currentChargeKwh: number;
  socPercent: number; // State of Charge
  sohPercent: number; // State of Health
  voltageV: number;
  currentA: number; // positive = discharging, negative = charging
  powerKw: number;
  temperatureCelsius: number;
  thermalState: 'NORMAL' | 'WARMING' | 'COOLING_ACTIVE' | 'THERMAL_LIMIT';
  cRate: number;
}

export interface TrainDynamics {
  positionKm: number;
  trackSegmentId: string;
  speedKmh: number;
  speedMs: number;
  targetSpeedKmh: number;
  accelerationMs2: number;
  tractiveForceKn: number;
  brakingForceKn: number;
  gradientForceKn: number;
  aerodynamicDragKn?: number;
  aeroDragKn: number;
  rollingResistanceKn?: number;
  rollingResistKn: number;
  curveResistanceKn?: number;
  curveResistKn: number;
  netForceKn: number;
  kineticEnergyMwh: number;
  totalMassTonnes: number;
  passengerOccupancyPercent: number;
  cargoLoadTonnes: number;
}

export interface ETCSMovementAuthority {
  authorityId: string;
  trainId: string;
  startKm: number;
  endKm: number;
  endOfAuthorityKm: number;
  supervisionLimitSpeedKmh: number;
  releaseSpeedKmh: number;
  validUntilSec: number;
  status: 'ACTIVE' | 'SUPERVISED' | 'EXTENDED' | 'RESTRICTED' | 'REVOKED';
  targetDistanceMeters: number;
  permittedSpeedKmh: number;
  warningSpeedKmh: number;
  interventionSpeedKmh: number;
  emergencyBrakeDistanceMeters: number;
}

export interface TrainEnergyState {
  tractionPowerKw: number;
  auxiliaryPowerKw: number; // HVAC, avionics, compressors
  fuelCellPowerKw: number;
  batteryPowerKw: number; // + discharge, - charge
  regenerativePowerKw: number;
  h2MassFlowKgPerHour: number;
  cumulativeH2ConsumedKg: number;
  cumulativeEnergyUsedKwh: number;
  cumulativeEnergyRegeneratedKwh: number;
  overallEfficiency: number;
  carbonAvoidedKgCo2: number;
}

export interface TrainModel {
  id: string;
  name: string;
  fleetClass: 'AUREOM-HSR-350' | 'AUREOM-HSR-380-VELVET' | 'AUREOM-CARGO-H2';
  formation: string; // e.g. "8-Car Streamliner (2x Power Cars, 6x Passenger Cores)"
  lengthMeters: number;
  massEmptyTonnes: number;
  maxSpeedKmh: number;
  maxAccelerationMs2: number;
  maxDecelerationMs2: number;
  maxEmergencyBrakeMs2: number;
  dragCoefficientCd: number;
  frontalAreaM2: number;
  rollingResistanceCoeffA: number; // Davis A
  rollingResistanceCoeffB: number; // Davis B
  tractionMotorsCount: number;
  totalMotorPowerKw: number;
  passengerCapacity: number;
  cargoCapacityTonnes: number;
  
  // Real-time state
  operationalState: TrainOperationalState;
  autonomyMode: AtomAutonomyMode;
  safetyLevel: SafetySupervisionLevel;
  safetyReason?: string;
  dynamics: TrainDynamics;
  movementAuthority: ETCSMovementAuthority;
  energy: TrainEnergyState;
  hydrogenTanks: HydrogenTankTelemetry[];
  fuelCellStacks: FuelCellTelemetry[];
  battery: BatteryTelemetry;
  
  // Route / Schedule
  originStationId: string;
  destinationStationId: string;
  nextStationId: string;
  scheduledArrivalSec: number;
  estimatedArrivalSec: number;
  delaySeconds: number;
  serviceCode: string;
  
  // Master Controller / Cab Handles
  cabTractionHandlePercent: number; // 0 - 100%
  cabBrakeHandlePercent: number; // 0 - 100%
  pantographState: 'LOWERED' | 'ISOLATED'; // H2 trains operate off-grid
  doorsClosed: boolean;
  emergencyBrakeEngaged: boolean;
  hornActive: boolean;
}

export interface WeatherCondition {
  temperatureCelsius: number;
  windSpeedKmh: number;
  windDirectionDegrees: number;
  airDensityKgM3: number;
  humidityPercent: number;
  precipitation: 'CLEAR' | 'LIGHT_RAIN' | 'HEAVY_RAIN' | 'SNOW' | 'DENSE_FOG';
  railAdhesionCoefficient: number; // 0.08 (ice) - 0.35 (dry clean rail)
}

export interface IncidentRecord {
  id: string;
  timestamp: string;
  trainId?: string;
  trackKm?: number;
  severity: 'INFORMATION' | 'MINOR' | 'MAJOR' | 'CRITICAL' | 'EMERGENCY';
  title: string;
  description: string;
  status: 'DETECTED' | 'ACKNOWLEDGED' | 'INVESTIGATING' | 'MITIGATING' | 'RESOLVED';
  suggestedAction: string;
  auditExplanation: string;
}

export interface EventLogEntry {
  id: string;
  simTimeSec: number;
  timestamp: string;
  eventType: string;
  sourceSubsystem: 'TRAIN_PHYSICS' | 'HYDROGEN_SYS' | 'FUEL_CELL' | 'BATTERY' | 'ETCS_ATO' | 'SAFETY_SUPERVISOR' | 'DISPATCH' | 'DEPOT';
  entityId: string;
  summary: string;
  parameters: Record<string, string | number | boolean>;
}

export interface SimulationScenario {
  id: string;
  scenarioCode: string;
  title: string;
  description: string;
  focusArea: 'EFFICIENCY' | 'SAFETY' | 'WEATHER' | 'DEGRADATION' | 'LOGISTICS' | 'DISRUPTION';
  initialConditions: {
    weather: Partial<WeatherCondition>;
    trainOverrides?: Record<string, Partial<TrainModel>>;
    activeFailures?: string[];
  };
}
