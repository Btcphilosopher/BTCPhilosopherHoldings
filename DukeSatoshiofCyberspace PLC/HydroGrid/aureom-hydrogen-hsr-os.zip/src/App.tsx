/**
 * AUREOM HYDROGEN HSR OS
 * Master Operating System Shell & Central Application Runtime
 */

import React, { useState, useEffect, useRef } from 'react';
import { globalKernel, SimulationState } from './simulation/simulationCore';
import { Header } from './components/layout/Header';
import { Navigation, ViewTab } from './components/layout/Navigation';
import { NetworkCommandView } from './components/network/NetworkCommandView';
import { Train3DDigitalTwin } from './components/digitaltwin/Train3DDigitalTwin';
import { DriverCabView } from './components/cab/DriverCabView';
import { HydrogenCommandView } from './components/hydrogen/HydrogenCommandView';
import { EnergyManagementView } from './components/energy/EnergyManagementView';
import { AtoSignallingView } from './components/signalling/AtoSignallingView';
import { FleetMaintenanceView } from './components/fleet/FleetMaintenanceView';
import { AiIntelligenceView } from './components/ai/AiIntelligenceView';
import { EngineeringLabView } from './components/engineering/EngineeringLabView';
import { FailureInjectionModal } from './components/common/FailureInjectionModal';

export default function App() {
  const [simState, setSimState] = useState<SimulationState>(globalKernel.getState());
  const [activeTab, setActiveTab] = useState<ViewTab>('NETWORK_COMMAND');
  const [isFailureModalOpen, setIsFailureModalOpen] = useState<boolean>(false);

  // Simulation Clock Tick Loop
  const lastTimeRef = useRef<number>(performance.now());

  useEffect(() => {
    let animationFrameId: number;

    const tick = (currentTime: number) => {
      const elapsedSeconds = Math.min((currentTime - lastTimeRef.current) / 1000, 0.1);
      lastTimeRef.current = currentTime;

      // Step simulation kernel
      globalKernel.step(elapsedSeconds);
      setSimState({ ...globalKernel.getState() });

      animationFrameId = requestAnimationFrame(tick);
    };

    animationFrameId = requestAnimationFrame(tick);

    return () => cancelAnimationFrame(animationFrameId);
  }, []);

  const selectedTrain = simState.trains.find(t => t.id === simState.selectedTrainId) || simState.trains[0];

  return (
    <div className="w-full h-screen flex flex-col bg-[#07090c] text-slate-100 overflow-hidden font-sans select-none antialiased">
      {/* Top Header */}
      <Header
        state={simState}
        onTogglePlay={() => {
          globalKernel.toggleRunning();
          setSimState({ ...globalKernel.getState() });
        }}
        onSetSpeed={(speed) => {
          globalKernel.setTimeSpeed(speed);
          setSimState({ ...globalKernel.getState() });
        }}
        onRewind={() => {
          globalKernel.rewind(30);
          setSimState({ ...globalKernel.getState() });
        }}
        onSelectScenario={(id) => {
          globalKernel.loadScenario(id);
          setSimState({ ...globalKernel.getState() });
        }}
        onToggleEco={() => {
          globalKernel.toggleEcoDriving();
          setSimState({ ...globalKernel.getState() });
        }}
        onOpenFailureModal={() => setIsFailureModalOpen(true)}
        onOpenAiModal={() => setActiveTab('AI_INTELLIGENCE')}
      />

      {/* Navigation Subsystem Tabs */}
      <Navigation
        activeTab={activeTab}
        onSelectTab={(tab) => setActiveTab(tab)}
        trainCount={simState.trains.length}
        activeIncidentsCount={simState.incidents.filter(i => i.status === 'DETECTED').length}
      />

      {/* Primary Operating View Area */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {activeTab === 'NETWORK_COMMAND' && (
          <NetworkCommandView
            trains={simState.trains}
            stations={simState.stations}
            hubs={simState.hubs}
            segments={simState.segments}
            selectedTrainId={simState.selectedTrainId}
            onSelectTrain={(trainId) => {
              globalKernel.setSelectedTrain(trainId);
              setSimState({ ...globalKernel.getState() });
            }}
            onOpenCab={(trainId) => {
              globalKernel.setSelectedTrain(trainId);
              setActiveTab('DRIVER_CAB_DMI');
            }}
            onOpenDigitalTwin={(trainId) => {
              globalKernel.setSelectedTrain(trainId);
              setActiveTab('DIGITAL_TWIN_3D');
            }}
          />
        )}

        {activeTab === 'DIGITAL_TWIN_3D' && (
          <Train3DDigitalTwin train={selectedTrain} />
        )}

        {activeTab === 'DRIVER_CAB_DMI' && (
          <DriverCabView
            train={selectedTrain}
            onSetControls={(trainId, trac, brk, mode, emg) => {
              globalKernel.setTrainCabControls(trainId, trac, brk, mode, emg);
              setSimState({ ...globalKernel.getState() });
            }}
          />
        )}

        {activeTab === 'HYDROGEN_INFRASTRUCTURE' && (
          <HydrogenCommandView hubs={simState.hubs} trains={simState.trains} />
        )}

        {activeTab === 'ENERGY_EMS' && (
          <EnergyManagementView
            train={selectedTrain}
            totalNetworkEnergyMwh={simState.totalNetworkEnergyUsedMwh}
            totalCarbonAvoidedTonnes={simState.totalNetworkCarbonAvoidedTonnes}
          />
        )}

        {activeTab === 'ATO_SIGNALLING' && (
          <AtoSignallingView
            train={selectedTrain}
            segments={simState.segments}
            allTrains={simState.trains}
          />
        )}

        {activeTab === 'FLEET_MAINTENANCE' && (
          <FleetMaintenanceView
            trains={simState.trains}
            onSelectTrain={(trainId) => {
              globalKernel.setSelectedTrain(trainId);
              setSimState({ ...globalKernel.getState() });
            }}
          />
        )}

        {activeTab === 'AI_INTELLIGENCE' && (
          <AiIntelligenceView state={simState} />
        )}

        {activeTab === 'ENGINEERING_LAB' && (
          <EngineeringLabView />
        )}
      </main>

      {/* Failure Injection Modal */}
      <FailureInjectionModal
        isOpen={isFailureModalOpen}
        onClose={() => setIsFailureModalOpen(false)}
        trains={simState.trains}
        selectedTrainId={simState.selectedTrainId}
        onInject={(failureType, trainId) => {
          globalKernel.injectFailure(failureType, trainId);
          setSimState({ ...globalKernel.getState() });
        }}
      />
    </div>
  );
}
