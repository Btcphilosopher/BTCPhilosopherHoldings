import { ChangeDetectionStrategy, Component, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { OperatorConsole } from './components/workspaces/operator-console.component';
import { WebBuilder } from './components/workspaces/web-builder.component';
import { WorkloadsView } from './components/workspaces/workloads-view.component';
import { PouwEngine } from './components/workspaces/pouw-engine.component';
import { TokenLedger } from './components/workspaces/token-ledger.component';
import { CommerceHub } from './components/workspaces/commerce-hub.component';
import { NetworkExplorer } from './components/workspaces/network-explorer.component';
import { TestSuite } from './components/workspaces/test-suite.component';
import { ArchitectureDocs } from './components/workspaces/architecture-docs.component';
import { NetworkService } from './services/network.service';
import { LedgerService } from './services/ledger.service';
import { TestRunnerService } from './services/test-runner.service';

export type WorkspaceId =
  | 'operator'
  | 'web-builder'
  | 'workloads'
  | 'pouw'
  | 'ledger'
  | 'commerce'
  | 'explorer'
  | 'tests'
  | 'docs';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    MatIconModule,
    OperatorConsole,
    WebBuilder,
    WorkloadsView,
    PouwEngine,
    TokenLedger,
    CommerceHub,
    NetworkExplorer,
    TestSuite,
    ArchitectureDocs,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly network = inject(NetworkService);
  readonly ledger = inject(LedgerService);
  readonly testRunner = inject(TestRunnerService);

  readonly activeWorkspace = signal<WorkspaceId>('operator');

  setWorkspace(id: WorkspaceId) {
    this.activeWorkspace.set(id);
  }

  runAllTestsQuick() {
    this.activeWorkspace.set('tests');
    this.testRunner.runAllSuites();
  }
}
