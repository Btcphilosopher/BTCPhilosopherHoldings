import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { PouwEngineService } from '../../services/pouw-engine.service';
import { NetworkService } from '../../services/network.service';
import { WorkClass } from '../../models/dscs.types';

@Component({
  selector: 'app-pouw-engine',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-6 space-y-6">
      <!-- Top Title Bar -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-xl font-bold tracking-tight text-white">Proof-of-Useful-Work (PoUW) Engine</h1>
            <span class="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono">
              Protocol pouw_v1.2.0 · Multi-Validator Quorum
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Converting independently verified infrastructure delivery into cryptographically authenticated token reward claims.
          </p>
        </div>

        <div class="flex items-center gap-3">
          <button
            (click)="showCreateClaimModal.set(true)"
            class="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 shadow-sm transition-colors"
          >
            <mat-icon class="text-xs">bolt</mat-icon>
            <span>Dispatch & Verify Workload</span>
          </button>
        </div>
      </div>

      <!-- 5 Eligible Work Classes Cards -->
      <div>
        <div class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
          Eligible Infrastructure Work Classes & Verification Protocols
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3">
          @for (rate of workClassesList; track rate.workClass) {
            <div class="p-3.5 rounded-xl border border-slate-800 bg-slate-900/60 flex flex-col justify-between space-y-2">
              <div>
                <div class="text-[11px] font-mono text-emerald-400 font-semibold">{{ rate.title }}</div>
                <div class="text-lg font-bold text-white font-mono mt-1">
                  {{ rate.baseRatePerUnit }} <span class="text-xs font-normal text-slate-400">DSCS / unit</span>
                </div>
                <div class="text-[10px] text-slate-400 mt-0.5 font-mono">Unit: {{ rate.unitName }}</div>
              </div>
              <p class="text-[11px] text-slate-400 leading-tight pt-2 border-t border-slate-800/80">
                {{ rate.verificationStrategy }}
              </p>
            </div>
          }
        </div>
      </div>

      <!-- Main Layout: Submitted Claims & 14-Step Verification Inspector -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Claims List (5 columns) -->
        <div class="lg:col-span-5 space-y-3">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>PoUW Claims Audited ({{ pouw.claims().length }})</span>
            <span class="font-mono text-emerald-400">Deterministic Math</span>
          </div>

          <div class="space-y-2.5">
            @for (claim of pouw.claims(); track claim.id) {
              <button
                type="button"
                (click)="selectedClaimId.set(claim.id)"
                [class.border-emerald-500]="selectedClaimId() === claim.id"
                [class.bg-slate-900]="selectedClaimId() === claim.id"
                class="text-left w-full p-4 rounded-xl border border-slate-800 bg-slate-900/50 hover:border-slate-700 cursor-pointer transition-all space-y-2"
              >
                <div class="flex items-start justify-between">
                  <div>
                    <div class="text-xs font-mono font-semibold text-white">{{ claim.id }}</div>
                    <div class="text-[11px] text-slate-400">Node: {{ claim.nodeId }}</div>
                  </div>
                  <span
                    [class.bg-emerald-950]="claim.status === 'SETTLED' || claim.status === 'ACCEPTED'"
                    [class.text-emerald-400]="claim.status === 'SETTLED' || claim.status === 'ACCEPTED'"
                    [class.border-emerald-800]="claim.status === 'SETTLED' || claim.status === 'ACCEPTED'"
                    [class.bg-rose-950]="claim.status === 'REJECTED'"
                    [class.text-rose-400]="claim.status === 'REJECTED'"
                    [class.border-rose-800]="claim.status === 'REJECTED'"
                    [class.bg-amber-950]="claim.status === 'PENDING' || claim.status === 'VERIFYING'"
                    [class.text-amber-400]="claim.status === 'PENDING' || claim.status === 'VERIFYING'"
                    [class.border-amber-800]="claim.status === 'PENDING' || claim.status === 'VERIFYING'"
                    class="text-[10px] px-2 py-0.5 rounded border font-mono font-bold"
                  >
                    {{ claim.status }}
                  </span>
                </div>

                <div class="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-slate-800/80">
                  <div>
                    <span class="text-slate-500">Work Class:</span>
                    <span class="text-slate-300 font-mono block">{{ claim.workClass }}</span>
                  </div>
                  <div>
                    <span class="text-slate-500">Calculated Reward:</span>
                    <span class="text-emerald-400 font-mono font-bold block">{{ claim.calculatedReward }} DSCS</span>
                  </div>
                </div>

                @if (claim.rejectionReason) {
                  <div class="text-[11px] text-rose-400 bg-rose-950/40 border border-rose-900/60 p-2 rounded">
                    Rejection: {{ claim.rejectionReason }}
                  </div>
                }
              </button>
            }
          </div>
        </div>

        <!-- 14-Step Audit Details (7 columns) -->
        <div class="lg:col-span-7">
          @if (currentClaim(); as claim) {
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <div class="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h3 class="text-sm font-semibold text-white">14-Step PoUW Validator Audit Trail</h3>
                  <div class="text-xs text-slate-400 font-mono">Claim ID: {{ claim.id }}</div>
                </div>
                <div class="text-right">
                  <div class="text-xs font-mono font-bold text-emerald-400">{{ claim.calculatedReward }} DSCS</div>
                  <div class="text-[10px] text-slate-500">Reward Output</div>
                </div>
              </div>

              <!-- Evidence Hashes Strip -->
              <div class="p-3 bg-slate-950 rounded-lg border border-slate-800 text-[11px] space-y-1.5 font-mono">
                <div class="flex justify-between">
                  <span class="text-slate-500">Output Hash / Commitment:</span>
                  <span class="text-slate-300">{{ claim.evidence.outputHash.slice(0, 28) }}...</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-500">Node Signature (Ed25519):</span>
                  <span class="text-slate-300">{{ claim.evidence.signature.slice(0, 28) }}...</span>
                </div>
                @if (claim.settledTxId) {
                  <div class="flex justify-between text-emerald-400">
                    <span>Ledger Settlement Tx:</span>
                    <span>{{ claim.settledTxId }}</span>
                  </div>
                }
              </div>

              <!-- 14 Verification Steps Sequence -->
              <div class="space-y-2">
                <div class="text-xs font-semibold text-slate-300">Validator Sequence Steps:</div>
                <div class="space-y-1.5">
                  @for (log of claim.verificationAudit; track log.step) {
                    <div
                      class="p-2.5 rounded border text-xs flex items-start gap-3"
                      [class.bg-slate-950]="log.passed"
                      [class.border-slate-800]="log.passed"
                      [class.bg-rose-950/20]="!log.passed"
                      [class.border-rose-900/60]="!log.passed"
                    >
                      <div class="mt-0.5">
                        @if (log.passed) {
                          <mat-icon class="text-emerald-400 text-sm">check_circle</mat-icon>
                        } @else {
                          <mat-icon class="text-rose-400 text-sm">cancel</mat-icon>
                        }
                      </div>
                      <div class="flex-1">
                        <div class="flex items-center justify-between">
                          <span class="font-medium text-white">Step {{ log.step }}: {{ log.name }}</span>
                          <span class="text-[10px] text-slate-500 font-mono">Verified</span>
                        </div>
                        <p class="text-[11px] text-slate-400 mt-0.5">{{ log.details }}</p>
                      </div>
                    </div>
                  } @empty {
                    <div class="p-6 text-center text-slate-500 text-xs">
                      Claim is currently in queue awaiting validator worker pipeline execution.
                    </div>
                  }
                </div>
              </div>

              <!-- Validator Quorum Signatures -->
              @if (claim.validatorSignatures.length > 0) {
                <div class="pt-3 border-t border-slate-800">
                  <div class="text-xs font-semibold text-slate-400 mb-2">Validator Multi-Sig Consensus Votes:</div>
                  <div class="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    @for (v of claim.validatorSignatures; track v.validatorId) {
                      <div class="p-2 rounded bg-slate-950 border border-slate-800 text-[10px] font-mono">
                        <div class="flex items-center justify-between">
                          <span class="text-slate-300">{{ v.validatorId }}</span>
                          <span class="text-emerald-400 font-bold">{{ v.vote }}</span>
                        </div>
                        <div class="text-slate-500 truncate mt-1">{{ v.signature }}</div>
                      </div>
                    }
                  </div>
                </div>
              }
            </div>
          }
        </div>
      </div>

      <!-- Dispatch & Verify Workload Modal -->
      @if (showCreateClaimModal()) {
        <div class="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-6">
          <div class="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl flex flex-col">
            <div class="h-12 border-b border-slate-800 px-4 flex items-center justify-between bg-slate-950">
              <span class="text-sm font-semibold text-white">Dispatch PoUW Workload & Run Validator</span>
              <button (click)="showCreateClaimModal.set(false)" class="text-slate-400 hover:text-white">
                <mat-icon class="text-sm">close</mat-icon>
              </button>
            </div>
            <div class="p-5 space-y-4 text-xs">
              <div>
                <label for="workClassSelect" class="block text-slate-400 mb-1">Work Class</label>
                <select
                  id="workClassSelect"
                  [(ngModel)]="newClaimClass"
                  class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="CLASS_A_HOSTING">Class A — Hosting Delivery (Real HTTP probes & traffic receipts)</option>
                  <option value="CLASS_B_COMPUTE">Class B — Compute Execution (Deterministic recomputation)</option>
                  <option value="CLASS_C_STORAGE">Class C — Storage Retention (Randomized Merkle challenges)</option>
                  <option value="CLASS_D_NETWORK">Class D — Network Delivery (Egress bandwidth verification)</option>
                  <option value="CLASS_E_CAPACITY">Class E — Reserved Capacity (Standby availability)</option>
                </select>
              </div>

              <div>
                <label for="assignNodeSelect" class="block text-slate-400 mb-1">Assign Node</label>
                <select
                  id="assignNodeSelect"
                  [(ngModel)]="newClaimNodeId"
                  class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                >
                  @for (n of network.nodes(); track n.id) {
                    <option [value]="n.id">{{ n.name }} ({{ n.region }})</option>
                  }
                </select>
              </div>

              <!-- Adversarial Simulation Toggle -->
              <div class="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-2">
                <div class="text-slate-300 font-medium flex items-center gap-1.5">
                  <mat-icon class="text-xs text-amber-400">security</mat-icon>
                  <span>Adversarial Testing Simulation:</span>
                </div>
                <div class="flex items-center gap-2 cursor-pointer text-slate-400 hover:text-white">
                  <input
                    id="tamperingInputCheckbox"
                    type="checkbox"
                    [(ngModel)]="simulateTampering"
                    class="rounded border-slate-700 text-emerald-500"
                  />
                  <label for="tamperingInputCheckbox">Simulate malicious output tampering (tests validator fraud detection)</label>
                </div>
              </div>
            </div>
            <div class="p-4 border-t border-slate-800 bg-slate-950 flex justify-end gap-2">
              <button (click)="showCreateClaimModal.set(false)" class="px-3 py-1.5 rounded text-slate-400 hover:text-white">Cancel</button>
              <button (click)="dispatchAndVerify()" class="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-medium">
                Dispatch Workload
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class PouwEngine {
  readonly pouw = inject(PouwEngineService);
  readonly network = inject(NetworkService);

  readonly workClassesList = Object.values(this.pouw.workRates);
  readonly selectedClaimId = signal<string>(this.pouw.claims()[0]?.id || '');
  readonly showCreateClaimModal = signal<boolean>(false);

  newClaimClass: WorkClass = 'CLASS_B_COMPUTE';
  newClaimNodeId = 'node-alpha-berlin';
  simulateTampering = false;

  currentClaim() {
    return this.pouw.claims().find((c) => c.id === this.selectedClaimId()) || this.pouw.claims()[0];
  }

  async dispatchAndVerify() {
    this.showCreateClaimModal.set(false);
    const spec = await this.pouw.createWorkSpecification(
      this.newClaimClass,
      `Operator Manual Job (${this.newClaimClass})`,
      this.newClaimNodeId,
      {},
      35.0
    );

    const evidence = await this.pouw.generateNodeEvidence(spec, {
      corruptOutput: this.simulateTampering,
    });

    const claim = await this.pouw.submitClaim(spec, evidence);
    this.selectedClaimId.set(claim.id);

    // Execute 14-step verification
    await this.pouw.executeVerificationPipeline(claim.id);
  }
}
