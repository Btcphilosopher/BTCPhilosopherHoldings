import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { NetworkService } from '../../services/network.service';
import { PouwEngineService } from '../../services/pouw-engine.service';
import { LedgerService } from '../../services/ledger.service';

@Component({
  selector: 'app-network-explorer',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-6 space-y-6">
      <!-- Title Bar -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-xl font-bold tracking-tight text-white">DSCS Internal Network Explorer</h1>
            <span class="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono">
              Consensus Epoch #{{ ledger.currentEpoch().epochNumber }}
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Auditable distributed ledger, registered node public keys, capacity inventory, and verification certificates.
          </p>
        </div>

        <div class="flex items-center gap-3">
          <span class="text-xs text-slate-400 font-mono">
            Cluster Capacity: <span class="text-white font-bold">{{ totalClusterCores() }} vCPUs</span> · <span class="text-white font-bold">{{ totalClusterRam() }} GB RAM</span>
          </span>
        </div>
      </div>

      <!-- Quick Network Stats -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60">
          <div class="text-xs text-slate-400">Total Registered Nodes</div>
          <div class="text-2xl font-bold text-white font-mono mt-1">{{ network.nodes().length }}</div>
          <div class="text-[11px] text-emerald-400 mt-0.5">5 Global Regions</div>
        </div>
        <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60">
          <div class="text-xs text-slate-400">Total Active Workloads</div>
          <div class="text-2xl font-bold text-white font-mono mt-1">{{ network.workloads().length }}</div>
          <div class="text-[11px] text-blue-400 mt-0.5">Zero outage SLA</div>
        </div>
        <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60">
          <div class="text-xs text-slate-400">Settled PoUW Claims</div>
          <div class="text-2xl font-bold text-white font-mono mt-1">{{ pouw.claims().length }}</div>
          <div class="text-[11px] text-purple-400 mt-0.5">14-Step Verified</div>
        </div>
        <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60">
          <div class="text-xs text-slate-400">Total Issued DSCS</div>
          <div class="text-2xl font-bold text-emerald-400 font-mono mt-1">
            {{ ledger.totalCirculatingSupply().toLocaleString('en-US', { maximumFractionDigits: 1 }) }}
          </div>
          <div class="text-[11px] text-slate-500 mt-0.5">Cap: 21,000,000 DSCS</div>
        </div>
      </div>

      <!-- Distributed Nodes Directory -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div class="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <h3 class="text-sm font-semibold text-white">Registered Node Topology & Capability Declaration</h3>
          <span class="text-xs text-slate-400 font-mono">Ed25519 Authenticated</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead class="bg-slate-950/80 text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[11px]">
              <tr>
                <th class="px-5 py-3">Node & Identity</th>
                <th class="px-5 py-3">Region & IP</th>
                <th class="px-5 py-3">Hardware & TEE</th>
                <th class="px-5 py-3">Reputation</th>
                <th class="px-5 py-3">Claims Accepted</th>
                <th class="px-5 py-3">Tokens Earned</th>
                <th class="px-5 py-3">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800">
              @for (node of network.nodes(); track node.id) {
                <tr class="hover:bg-slate-800/50 transition-colors">
                  <td class="px-5 py-3">
                    <div class="font-medium text-white">{{ node.name }}</div>
                    <div class="font-mono text-[10px] text-slate-500">{{ node.publicKey.slice(0, 24) }}...</div>
                  </td>
                  <td class="px-5 py-3">
                    <div class="font-mono text-slate-300">{{ node.region }}</div>
                    <div class="font-mono text-[10px] text-slate-500">{{ node.ipAddress }}</div>
                  </td>
                  <td class="px-5 py-3">
                    <div class="text-slate-300 font-mono">{{ node.hardware.cpuCores }} Cores · {{ node.hardware.ramGb }}GB RAM</div>
                    <div class="text-[10px] text-slate-500">{{ node.hardware.storageGb }}GB {{ node.hardware.storageType }}</div>
                  </td>
                  <td class="px-5 py-3 font-mono font-bold text-white tabular-nums">
                    {{ node.reputationScore.toFixed(1) }} / 100
                  </td>
                  <td class="px-5 py-3 font-mono tabular-nums text-slate-300">
                    {{ node.totalClaimsAccepted }}
                  </td>
                  <td class="px-5 py-3 font-mono font-bold text-emerald-400 tabular-nums">
                    {{ node.totalTokensEarned.toFixed(1) }} DSCS
                  </td>
                  <td class="px-5 py-3">
                    <span class="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-400 font-mono text-[10px]">
                      {{ node.status }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Recent Verified Proof Claims Activity -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div class="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <h3 class="text-sm font-semibold text-white">PoUW Proof Verification Stream</h3>
          <span class="text-xs text-slate-400 font-mono">Consensus Verified</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead class="bg-slate-950/80 text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[11px]">
              <tr>
                <th class="px-5 py-3">Claim Identifier</th>
                <th class="px-5 py-3">Work Class</th>
                <th class="px-5 py-3">Node</th>
                <th class="px-5 py-3">Output Commitment (CID/Hash)</th>
                <th class="px-5 py-3 text-right">Eligible Units</th>
                <th class="px-5 py-3 text-right">Settled Reward</th>
                <th class="px-5 py-3">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800">
              @for (c of pouw.claims(); track c.id) {
                <tr class="hover:bg-slate-800/50 transition-colors">
                  <td class="px-5 py-3 font-mono text-white text-[11px]">{{ c.id }}</td>
                  <td class="px-5 py-3 font-mono text-slate-300">{{ c.workClass }}</td>
                  <td class="px-5 py-3 text-slate-400 font-mono">{{ c.nodeId }}</td>
                  <td class="px-5 py-3 font-mono text-slate-500 text-[10px]">{{ c.evidence.outputHash.slice(0, 24) }}...</td>
                  <td class="px-5 py-3 font-mono tabular-nums text-right text-slate-300">{{ c.verifiedUnits.toFixed(2) }}</td>
                  <td class="px-5 py-3 font-mono tabular-nums text-right font-bold text-emerald-400">+{{ c.calculatedReward }} DSCS</td>
                  <td class="px-5 py-3">
                    <span
                      [class.text-emerald-400]="c.status === 'SETTLED' || c.status === 'ACCEPTED'"
                      [class.text-rose-400]="c.status === 'REJECTED'"
                      [class.text-amber-400]="c.status === 'PENDING'"
                      class="font-mono text-[10px] font-bold"
                    >
                      {{ c.status }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class NetworkExplorer {
  readonly network = inject(NetworkService);
  readonly pouw = inject(PouwEngineService);
  readonly ledger = inject(LedgerService);

  totalClusterCores() {
    return this.network.nodes().reduce((sum, n) => sum + n.hardware.cpuCores, 0);
  }

  totalClusterRam() {
    return this.network.nodes().reduce((sum, n) => sum + n.hardware.ramGb, 0);
  }
}
