import { ChangeDetectionStrategy, Component, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { NetworkService } from '../../services/network.service';
import { DeployedWorkload } from '../../models/dscs.types';

export interface BuilderSection {
  id: string;
  type: 'HERO' | 'FEATURES' | 'PRODUCTS' | 'STATS' | 'CONTACT' | 'CTA';
  title: string;
  subtitle: string;
  content: string;
  buttonText?: string;
  theme: 'dark' | 'slate' | 'emerald';
  columns?: number;
}

@Component({
  selector: 'app-web-builder',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100">
      <!-- Builder Toolbar -->
      <div class="h-14 border-b border-slate-800 bg-slate-900/90 px-4 flex items-center justify-between gap-4 shrink-0">
        <div class="flex items-center gap-3">
          <div class="flex items-center gap-2">
            <mat-icon class="text-emerald-400 text-lg">web</mat-icon>
            <span class="text-sm font-semibold tracking-tight text-white">Visual Web & App Studio</span>
          </div>
          <span class="text-slate-600">|</span>
          <div class="flex items-center gap-1 bg-slate-950 rounded-lg p-1 border border-slate-800 text-xs">
            <button
              (click)="setDevice('desktop')"
              [class.bg-slate-800]="deviceMode() === 'desktop'"
              [class.text-white]="deviceMode() === 'desktop'"
              class="px-2.5 py-1 rounded text-slate-400 hover:text-white flex items-center gap-1 transition-colors"
              title="Desktop (1440px)"
            >
              <mat-icon class="text-xs">desktop_windows</mat-icon>
              <span>Desktop</span>
            </button>
            <button
              (click)="setDevice('tablet')"
              [class.bg-slate-800]="deviceMode() === 'tablet'"
              [class.text-white]="deviceMode() === 'tablet'"
              class="px-2.5 py-1 rounded text-slate-400 hover:text-white flex items-center gap-1 transition-colors"
              title="Tablet (768px)"
            >
              <mat-icon class="text-xs">tablet_mac</mat-icon>
              <span>Tablet</span>
            </button>
            <button
              (click)="setDevice('mobile')"
              [class.bg-slate-800]="deviceMode() === 'mobile'"
              [class.text-white]="deviceMode() === 'mobile'"
              class="px-2.5 py-1 rounded text-slate-400 hover:text-white flex items-center gap-1 transition-colors"
              title="Mobile (375px)"
            >
              <mat-icon class="text-xs">smartphone</mat-icon>
              <span>Mobile</span>
            </button>
          </div>
        </div>

        <div class="flex items-center gap-3">
          <!-- Site Name Input -->
          <div class="flex items-center gap-2">
            <label for="siteTitleInput" class="text-xs text-slate-400">Site:</label>
            <input
              id="siteTitleInput"
              type="text"
              [(ngModel)]="siteTitle"
              class="bg-slate-950 border border-slate-750 px-2.5 py-1 rounded text-xs text-white focus:outline-none focus:border-emerald-500 w-44"
              placeholder="Project Name"
            />
          </div>

          <!-- Target Node Selector -->
          <div class="flex items-center gap-2">
            <label for="nodeTargetSelect" class="text-xs text-slate-400">Node Target:</label>
            <select
              id="nodeTargetSelect"
              [(ngModel)]="selectedNodeTarget"
              class="bg-slate-950 border border-slate-750 px-2 py-1 rounded text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
            >
              <option value="AUTO_SCHEDULER">Auto-Schedule (Optimal Latency)</option>
              @for (node of network.nodes(); track node.id) {
                <option [value]="node.id">{{ node.name }} ({{ node.region }})</option>
              }
            </select>
          </div>

          <button
            (click)="showCodeModal.set(true)"
            class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <mat-icon class="text-xs">code</mat-icon>
            <span>View HTML/CSS</span>
          </button>

          <button
            (click)="deploySite()"
            [disabled]="isDeploying()"
            class="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-medium flex items-center gap-1.5 shadow-sm transition-colors disabled:opacity-50"
          >
            <mat-icon class="text-xs">cloud_upload</mat-icon>
            <span>{{ isDeploying() ? 'Packaging & Deploying...' : 'Deploy to DSCS Network' }}</span>
          </button>
        </div>
      </div>

      <!-- Main Workspace Split: Components Palette | Canvas Preview | Property Inspector -->
      <div class="flex-1 flex overflow-hidden">
        <!-- Left: Component Palette -->
        <div class="w-64 border-r border-slate-800 bg-slate-900/60 p-4 flex flex-col gap-4 overflow-y-auto shrink-0">
          <div>
            <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">Add Blocks</h3>
            <p class="text-xs text-slate-500 mb-3">Click to append sections to layout</p>
            <div class="grid grid-cols-1 gap-2">
              <button
                (click)="addSection('HERO')"
                class="w-full text-left p-2.5 rounded-lg border border-slate-800 bg-slate-950/80 hover:border-emerald-500/50 hover:bg-slate-900 transition-all flex items-center gap-3 text-xs"
              >
                <div class="w-8 h-8 rounded bg-emerald-950/60 border border-emerald-800/40 flex items-center justify-center text-emerald-400 shrink-0">
                  <mat-icon class="text-sm">view_headline</mat-icon>
                </div>
                <div>
                  <div class="font-medium text-white">Hero Showcase</div>
                  <div class="text-[11px] text-slate-400">Headline, subhead & CTA</div>
                </div>
              </button>

              <button
                (click)="addSection('FEATURES')"
                class="w-full text-left p-2.5 rounded-lg border border-slate-800 bg-slate-950/80 hover:border-emerald-500/50 hover:bg-slate-900 transition-all flex items-center gap-3 text-xs"
              >
                <div class="w-8 h-8 rounded bg-blue-950/60 border border-blue-800/40 flex items-center justify-center text-blue-400 shrink-0">
                  <mat-icon class="text-sm">grid_view</mat-icon>
                </div>
                <div>
                  <div class="font-medium text-white">Feature Grid</div>
                  <div class="text-[11px] text-slate-400">3-column capabilities</div>
                </div>
              </button>

              <button
                (click)="addSection('PRODUCTS')"
                class="w-full text-left p-2.5 rounded-lg border border-slate-800 bg-slate-950/80 hover:border-emerald-500/50 hover:bg-slate-900 transition-all flex items-center gap-3 text-xs"
              >
                <div class="w-8 h-8 rounded bg-amber-950/60 border border-amber-800/40 flex items-center justify-center text-amber-400 shrink-0">
                  <mat-icon class="text-sm">shopping_bag</mat-icon>
                </div>
                <div>
                  <div class="font-medium text-white">Commerce Catalog</div>
                  <div class="text-[11px] text-slate-400">Hardware & digital goods</div>
                </div>
              </button>

              <button
                (click)="addSection('STATS')"
                class="w-full text-left p-2.5 rounded-lg border border-slate-800 bg-slate-950/80 hover:border-emerald-500/50 hover:bg-slate-900 transition-all flex items-center gap-3 text-xs"
              >
                <div class="w-8 h-8 rounded bg-purple-950/60 border border-purple-800/40 flex items-center justify-center text-purple-400 shrink-0">
                  <mat-icon class="text-sm">query_stats</mat-icon>
                </div>
                <div>
                  <div class="font-medium text-white">Network Metrics</div>
                  <div class="text-[11px] text-slate-400">Verified SLA & telemetry</div>
                </div>
              </button>

              <button
                (click)="addSection('CONTACT')"
                class="w-full text-left p-2.5 rounded-lg border border-slate-800 bg-slate-950/80 hover:border-emerald-500/50 hover:bg-slate-900 transition-all flex items-center gap-3 text-xs"
              >
                <div class="w-8 h-8 rounded bg-cyan-950/60 border border-cyan-800/40 flex items-center justify-center text-cyan-400 shrink-0">
                  <mat-icon class="text-sm">mail_outline</mat-icon>
                </div>
                <div>
                  <div class="font-medium text-white">Inquiry Form</div>
                  <div class="text-[11px] text-slate-400">Lead capture & contact</div>
                </div>
              </button>
            </div>
          </div>

          <div class="pt-4 border-t border-slate-800">
            <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Sections Order</h3>
            <div class="space-y-1.5">
              @for (sec of sections(); track sec.id; let idx = $index) {
                <div
                  class="px-2.5 py-2 rounded border border-slate-800 bg-slate-950 flex items-center justify-between text-xs hover:border-slate-700 transition-colors"
                  [class.border-emerald-500]="selectedSectionId() === sec.id"
                  [class.bg-slate-800]="selectedSectionId() === sec.id"
                >
                  <button
                    type="button"
                    (click)="selectedSectionId.set(sec.id)"
                    class="truncate text-slate-200 text-left flex-1"
                  >
                    {{ idx + 1 }}. {{ sec.title || sec.type }}
                  </button>
                  <div class="flex items-center gap-1 text-slate-400">
                    <button
                      type="button"
                      (click)="removeSection(sec.id)"
                      class="hover:text-rose-400 p-0.5 rounded"
                      title="Delete section"
                    >
                      <mat-icon class="text-xs">delete</mat-icon>
                    </button>
                  </div>
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Center: Interactive Preview Canvas -->
        <div class="flex-1 bg-slate-950 p-6 overflow-y-auto flex justify-center">
          <div
            [style.max-width]="canvasMaxWidth()"
            class="w-full bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden transition-all duration-200 min-h-[600px] flex flex-col"
          >
            <!-- Browser Chrome Simulation Header -->
            <div class="h-9 bg-slate-950 border-b border-slate-800 px-3 flex items-center justify-between text-xs text-slate-400 select-none">
              <div class="flex items-center gap-1.5">
                <div class="w-2.5 h-2.5 rounded-full bg-slate-700"></div>
                <div class="w-2.5 h-2.5 rounded-full bg-slate-700"></div>
                <div class="w-2.5 h-2.5 rounded-full bg-slate-700"></div>
              </div>
              <div class="bg-slate-900 border border-slate-800 rounded px-4 py-0.5 text-[11px] text-slate-300 font-mono flex items-center gap-1.5">
                <mat-icon class="text-emerald-400 text-xs">lock</mat-icon>
                <span>https://{{ siteSlug() }}.dscs.cloud</span>
              </div>
              <span class="text-[11px] text-emerald-400/90 font-mono">PoUW Verified</span>
            </div>

            <!-- Canvas Rendered Blocks -->
            <div class="flex-1 flex flex-col divide-y divide-slate-800/80">
              <!-- Site Topbar Preview -->
              <header class="px-6 py-4 flex items-center justify-between border-b border-slate-800 bg-slate-900">
                <span class="text-base font-bold tracking-tight text-white">{{ siteTitle }}</span>
                <nav class="flex items-center gap-6 text-xs text-slate-300">
                  <span class="hover:text-white cursor-pointer">Solutions</span>
                  <span class="hover:text-white cursor-pointer">Infrastructure</span>
                  <span class="hover:text-white cursor-pointer">Documentation</span>
                </nav>
                <button class="px-3 py-1 bg-white text-slate-900 text-xs font-medium rounded hover:bg-slate-100 transition-colors">
                  Contact
                </button>
              </header>

              @for (sec of sections(); track sec.id) {
                <div
                  tabindex="0"
                  role="button"
                  aria-label="Select section block to edit"
                  (click)="selectedSectionId.set(sec.id)"
                  (keydown.enter)="selectedSectionId.set(sec.id)"
                  [class.ring-2]="selectedSectionId() === sec.id"
                  [class.ring-emerald-500]="selectedSectionId() === sec.id"
                  class="relative group cursor-pointer transition-all focus:outline-none"
                >
                  <!-- Quick Edit Label -->
                  <div class="absolute top-2 right-2 opacity-0 group-hover:opacity-100 bg-slate-950/80 border border-slate-700 rounded px-2 py-0.5 text-[10px] text-slate-300 pointer-events-none">
                    Click to edit block
                  </div>

                  @switch (sec.type) {
                    @case ('HERO') {
                      <section class="px-8 py-14 text-center bg-gradient-to-b from-slate-900 to-slate-950">
                        <div class="max-w-2xl mx-auto space-y-4">
                          <h1 class="text-3xl font-bold tracking-tight text-white">{{ sec.title }}</h1>
                          <p class="text-sm text-slate-400 leading-relaxed">{{ sec.subtitle }}</p>
                          <div class="pt-2 flex items-center justify-center gap-3">
                            <button class="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md">
                              {{ sec.buttonText || 'Get Started' }}
                            </button>
                            <button class="px-5 py-2 rounded-lg border border-slate-700 hover:bg-slate-800 text-slate-300 text-xs font-medium">
                              Explore Architecture
                            </button>
                          </div>
                        </div>
                      </section>
                    }
                    @case ('FEATURES') {
                      <section class="px-8 py-12 bg-slate-900">
                        <div class="text-center max-w-xl mx-auto mb-8 space-y-2">
                          <h2 class="text-xl font-bold text-white">{{ sec.title }}</h2>
                          <p class="text-xs text-slate-400">{{ sec.subtitle }}</p>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div class="p-4 rounded-xl border border-slate-800 bg-slate-950/60 space-y-2">
                            <div class="w-8 h-8 rounded bg-emerald-950 border border-emerald-800/40 flex items-center justify-center text-emerald-400">
                              <mat-icon class="text-sm">verified</mat-icon>
                            </div>
                            <h3 class="text-sm font-semibold text-white">PoUW Consensus</h3>
                            <p class="text-xs text-slate-400">Tokens minted solely against independently verified CPU/bandwidth delivery.</p>
                          </div>
                          <div class="p-4 rounded-xl border border-slate-800 bg-slate-950/60 space-y-2">
                            <div class="w-8 h-8 rounded bg-blue-950 border border-blue-800/40 flex items-center justify-center text-blue-400">
                              <mat-icon class="text-sm">security</mat-icon>
                            </div>
                            <h3 class="text-sm font-semibold text-white">Hardware TEE Enclaves</h3>
                            <p class="text-xs text-slate-400">Cryptographically isolated customer workloads with zero validator data leakage.</p>
                          </div>
                          <div class="p-4 rounded-xl border border-slate-800 bg-slate-950/60 space-y-2">
                            <div class="w-8 h-8 rounded bg-purple-950 border border-purple-800/40 flex items-center justify-center text-purple-400">
                              <mat-icon class="text-sm">speed</mat-icon>
                            </div>
                            <h3 class="text-sm font-semibold text-white">Global Edge Ingress</h3>
                            <p class="text-xs text-slate-400">Sub-10ms latency routing across distributed Linux server nodes worldwide.</p>
                          </div>
                        </div>
                      </section>
                    }
                    @case ('PRODUCTS') {
                      <section class="px-8 py-12 bg-slate-950">
                        <div class="text-center max-w-xl mx-auto mb-8 space-y-2">
                          <h2 class="text-xl font-bold text-white">{{ sec.title }}</h2>
                          <p class="text-xs text-slate-400">{{ sec.subtitle }}</p>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/90 flex items-center justify-between">
                            <div>
                              <div class="text-xs text-emerald-400 font-mono mb-1">HW-BLADE-1U</div>
                              <h4 class="text-sm font-semibold text-white">DSCS Micro-Server Blade</h4>
                              <p class="text-xs text-slate-400">64-Core AMD EPYC, 256GB RAM</p>
                              <div class="text-sm font-mono font-bold text-white mt-2">$1,850.00 USD</div>
                            </div>
                            <button class="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium">
                              Order Now
                            </button>
                          </div>
                          <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/90 flex items-center justify-between">
                            <div>
                              <div class="text-xs text-blue-400 font-mono mb-1">SEC-HSM-PRO</div>
                              <h4 class="text-sm font-semibold text-white">Hardware Key Module</h4>
                              <p class="text-xs text-slate-400">FIPS 140-3 Level 3 HSM</p>
                              <div class="text-sm font-mono font-bold text-white mt-2">$145.00 USD</div>
                            </div>
                            <button class="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium">
                              Order Now
                            </button>
                          </div>
                        </div>
                      </section>
                    }
                    @case ('STATS') {
                      <section class="px-8 py-8 bg-slate-900 border-y border-slate-800">
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                          <div>
                            <div class="text-xl font-bold text-white font-mono tabular-nums">99.98%</div>
                            <div class="text-[11px] text-slate-400">Network Uptime SLA</div>
                          </div>
                          <div>
                            <div class="text-xl font-bold text-emerald-400 font-mono tabular-nums">4.8ms</div>
                            <div class="text-[11px] text-slate-400">Mean Probe Latency</div>
                          </div>
                          <div>
                            <div class="text-xl font-bold text-white font-mono tabular-nums">1.4M</div>
                            <div class="text-[11px] text-slate-400">Requests Served</div>
                          </div>
                          <div>
                            <div class="text-xl font-bold text-amber-400 font-mono tabular-nums">0</div>
                            <div class="text-[11px] text-slate-400">Double-Issuance Replays</div>
                          </div>
                        </div>
                      </section>
                    }
                    @case ('CONTACT') {
                      <section class="px-8 py-12 bg-slate-950">
                        <div class="max-w-md mx-auto space-y-4">
                          <div class="text-center space-y-1">
                            <h2 class="text-lg font-bold text-white">{{ sec.title }}</h2>
                            <p class="text-xs text-slate-400">{{ sec.subtitle }}</p>
                          </div>
                          <div class="space-y-3">
                            <div>
                              <label for="contactEmailInput" class="block text-[11px] text-slate-400 mb-1">Your Email</label>
                              <input id="contactEmailInput" type="text" class="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white" placeholder="you@company.com" />
                            </div>
                            <div>
                              <label for="contactMessageTextarea" class="block text-[11px] text-slate-400 mb-1">Message</label>
                              <textarea id="contactMessageTextarea" class="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white h-20" placeholder="Deploy with DSCS"></textarea>
                            </div>
                            <button class="w-full py-2 bg-emerald-600 hover:bg-emerald-500 rounded text-xs font-semibold text-white">
                              Send Inquiry
                            </button>
                          </div>
                        </div>
                      </section>
                    }
                  }
                </div>
              }
            </div>

            <!-- Footer Preview -->
            <footer class="px-6 py-6 border-t border-slate-800 bg-slate-950 text-center text-xs text-slate-500">
              <p>Powered by DSCS Compute Network · Verifiable Distributed Hosting</p>
            </footer>
          </div>
        </div>

        <!-- Right: Section Property Inspector -->
        @if (activeSection(); as selectedSec) {
          <div class="w-72 border-l border-slate-800 bg-slate-900/60 p-4 flex flex-col gap-4 overflow-y-auto shrink-0">
            <div class="flex items-center justify-between">
              <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Block Properties</span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">{{ selectedSec.type }}</span>
            </div>

            <div class="space-y-3">
              <div>
                <label for="blockHeadlineInput" class="block text-[11px] text-slate-400 mb-1">Headline Title</label>
                <input
                  id="blockHeadlineInput"
                  type="text"
                  [value]="selectedSec.title"
                  (input)="onPropertyInput(selectedSec.id, 'title', $event)"
                  class="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label for="blockSubtitleTextarea" class="block text-[11px] text-slate-400 mb-1">Subtitle / Description</label>
                <textarea
                  id="blockSubtitleTextarea"
                  [value]="selectedSec.subtitle"
                  (input)="onPropertyInput(selectedSec.id, 'subtitle', $event)"
                  class="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500 h-20"
                ></textarea>
              </div>

              @if (selectedSec.buttonText !== undefined) {
                <div>
                  <label for="blockButtonInput" class="block text-[11px] text-slate-400 mb-1">Button Call To Action</label>
                  <input
                    id="blockButtonInput"
                    type="text"
                    [value]="selectedSec.buttonText"
                    (input)="onPropertyInput(selectedSec.id, 'buttonText', $event)"
                    class="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              }
            </div>

            <div class="pt-4 border-t border-slate-800">
              <div class="text-[11px] text-slate-400 mb-2">PoUW Hosting Deployment Notes</div>
              <p class="text-[11px] text-slate-500 leading-relaxed">
                When published, this design is compiled into an immutable HTML5/CSS artifact. The SHA-256 hash forms the workload CID, ensuring honest nodes serve exact content without tampering.
              </p>
            </div>
          </div>
        }
      </div>

      <!-- Generated HTML Code Modal -->
      @if (showCodeModal()) {
        <div class="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-6">
          <div class="w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
            <div class="h-12 border-b border-slate-800 px-4 flex items-center justify-between bg-slate-950">
              <span class="text-sm font-semibold text-white">Compiled Deployable Artifact (HTML5 / Tailwind)</span>
              <button (click)="showCodeModal.set(false)" class="text-slate-400 hover:text-white">
                <mat-icon class="text-sm">close</mat-icon>
              </button>
            </div>
            <div class="p-4 bg-slate-950 overflow-y-auto flex-1 font-mono text-xs text-slate-300">
              <pre><code>{{ generateCleanHtml() }}</code></pre>
            </div>
            <div class="p-3 border-t border-slate-800 bg-slate-900 flex justify-end">
              <button (click)="showCodeModal.set(false)" class="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded text-xs font-medium">
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      }

      <!-- Deployment Success Notification / Modal -->
      @if (lastDeploymentResult(); as res) {
        <div class="fixed bottom-6 right-6 z-40 bg-slate-900 border border-emerald-500/80 rounded-xl p-4 shadow-2xl max-w-md animate-fade-in">
          <div class="flex items-start justify-between gap-3">
            <div class="flex items-center gap-2 text-emerald-400">
              <mat-icon>check_circle</mat-icon>
              <span class="text-sm font-bold text-white">Site Published to DSCS Node!</span>
            </div>
            <button (click)="lastDeploymentResult.set(null)" class="text-slate-400 hover:text-white">
              <mat-icon class="text-xs">close</mat-icon>
            </button>
          </div>
          <div class="mt-2 space-y-1.5 text-xs text-slate-300">
            <div><span class="text-slate-500">Ingress:</span> <a [href]="res.ingressUrl" target="_blank" class="text-emerald-400 underline font-mono">{{ res.ingressUrl }}</a></div>
            <div><span class="text-slate-500">Node:</span> {{ res.assignedNodeId }}</div>
            <div><span class="text-slate-500">Content CID:</span> <span class="font-mono text-slate-400">{{ res.contentHash.slice(0, 24) }}...</span></div>
          </div>
        </div>
      }
    </div>
  `,
})
export class WebBuilder {
  readonly network = inject(NetworkService);

  siteTitle = 'NextGen Distributed Cloud';
  selectedNodeTarget = 'AUTO_SCHEDULER';
  deviceMode = signal<'desktop' | 'tablet' | 'mobile'>('desktop');
  selectedSectionId = signal<string>('sec_hero');
  showCodeModal = signal<boolean>(false);
  isDeploying = signal<boolean>(false);
  lastDeploymentResult = signal<DeployedWorkload | null>(null);

  readonly sections = signal<BuilderSection[]>([
    {
      id: 'sec_hero',
      type: 'HERO',
      title: 'Verifiable Cloud Infrastructure for the Sovereign Web',
      subtitle: 'Deploy containers, high-availability websites, and APIs across independently operated Linux nodes. Earn and transact with compute-backed tokens.',
      content: '',
      buttonText: 'Deploy Workload',
      theme: 'emerald',
    },
    {
      id: 'sec_features',
      type: 'FEATURES',
      title: 'Engineered for Performance & Useful Work',
      subtitle: 'Zero artificial mining. Real websites, database storage, and CPU computation verified by multi-validator consensus.',
      content: '',
      theme: 'slate',
    },
    {
      id: 'sec_products',
      type: 'PRODUCTS',
      title: 'Featured Hardware & Services',
      subtitle: 'Order authenticated server hardware with built-in DSCS node agent firmware.',
      content: '',
      theme: 'dark',
    },
    {
      id: 'sec_stats',
      type: 'STATS',
      title: 'Real-time Network Uptime',
      subtitle: 'Audited in real-time across 5 geographical regions',
      content: '',
      theme: 'slate',
    },
  ]);

  siteSlug() {
    return this.siteTitle.toLowerCase().replace(/[^a-z0-9]/g, '-').slice(0, 24);
  }

  setDevice(mode: 'desktop' | 'tablet' | 'mobile') {
    this.deviceMode.set(mode);
  }

  canvasMaxWidth() {
    switch (this.deviceMode()) {
      case 'desktop': return '100%';
      case 'tablet': return '768px';
      case 'mobile': return '375px';
    }
  }

  activeSection() {
    return this.sections().find((s) => s.id === this.selectedSectionId());
  }

  addSection(type: BuilderSection['type']) {
    const id = `sec_${type.toLowerCase()}_${Date.now().toString(36)}`;
    const newSec: BuilderSection = {
      id,
      type,
      title: type === 'HERO' ? 'New Hero Headline' : type === 'FEATURES' ? 'Platform Capabilities' : type === 'PRODUCTS' ? 'Storefront Products' : type === 'STATS' ? 'Telemetry' : 'Contact Us',
      subtitle: 'Customizable section description text.',
      content: '',
      buttonText: type === 'HERO' ? 'Get Started' : undefined,
      theme: 'dark',
    };
    this.sections.update((prev) => [...prev, newSec]);
    this.selectedSectionId.set(id);
  }

  removeSection(id: string) {
    this.sections.update((prev) => prev.filter((s) => s.id !== id));
    if (this.selectedSectionId() === id && this.sections().length > 0) {
      this.selectedSectionId.set(this.sections()[0].id);
    }
  }

  onPropertyInput(id: string, prop: keyof BuilderSection, event: Event) {
    const target = event.target as HTMLInputElement | HTMLTextAreaElement | null;
    if (target) {
      this.updateSectionProperty(id, prop, target.value);
    }
  }

  updateSectionProperty(id: string, prop: keyof BuilderSection, value: string) {
    this.sections.update((prev) =>
      prev.map((s) => (s.id === id ? { ...s, [prop]: value } : s))
    );
  }

  generateCleanHtml(): string {
    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>${this.siteTitle} | Hosted on DSCS</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen">
  <header class="px-6 py-4 flex items-center justify-between border-b border-slate-800">
    <div class="text-lg font-bold">${this.siteTitle}</div>
    <div class="text-xs text-emerald-400 font-mono">DSCS PoUW Verified Node</div>
  </header>
  <main class="space-y-12">
    ${this.sections().map((s) => `<!-- Section: ${s.type} -->
    <section class="py-12 px-6 max-w-4xl mx-auto text-center">
      <h1 class="text-3xl font-bold">${s.title}</h1>
      <p class="text-slate-400 mt-2">${s.subtitle}</p>
      ${s.buttonText ? `<div class="mt-4"><button class="px-4 py-2 bg-emerald-600 rounded font-semibold text-white">${s.buttonText}</button></div>` : ''}
    </section>`).join('\n    ')}
  </main>
  <footer class="py-8 border-t border-slate-900 text-center text-xs text-slate-500">
    Deployed via DSCS Distributed Hosting Engine
  </footer>
</body>
</html>`;
  }

  async deploySite() {
    this.isDeploying.set(true);
    try {
      const html = this.generateCleanHtml();
      const targetNode = this.selectedNodeTarget === 'AUTO_SCHEDULER' ? undefined : this.selectedNodeTarget;
      const res = await this.network.deployWorkload(this.siteTitle, 'WEBSITE', html, targetNode);
      this.lastDeploymentResult.set(res);
    } finally {
      this.isDeploying.set(false);
    }
  }
}
