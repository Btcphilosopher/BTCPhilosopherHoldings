import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { LedgerService } from '../../services/ledger.service';

@Component({
  selector: 'app-token-ledger',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-6 space-y-6">
      <!-- Top Title Bar -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-xl font-bold tracking-tight text-white">Double-Entry Token Ledger & Treasury</h1>
            <span class="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono">
              Auditable Journal · Capped Supply
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Every token is minted exclusively against verified PoUW infrastructure work. Strict mathematical balance.
          </p>
        </div>

        <div class="flex items-center gap-3">
          <button
            (click)="runReconciliation()"
            class="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <mat-icon class="text-xs">balance</mat-icon>
            <span>Run Ledger Reconciliation</span>
          </button>
        </div>
      </div>

      <!-- Macro Economics Strip -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>Circulating DSCS Supply</span>
            <mat-icon class="text-emerald-400 text-sm">monetization_on</mat-icon>
          </div>
          <div class="mt-2">
            <div class="text-2xl font-bold text-white font-mono tabular-nums">
              {{ ledger.totalCirculatingSupply().toLocaleString('en-US', { maximumFractionDigits: 2 }) }}
            </div>
            <div class="text-[11px] text-slate-500 mt-0.5">
              Hard Ceiling: 21,000,000.00 DSCS ({{ ((ledger.totalCirculatingSupply() / 21000000) * 100).toFixed(2) }}%)
            </div>
          </div>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>Active Epoch</span>
            <mat-icon class="text-blue-400 text-sm">schedule</mat-icon>
          </div>
          <div class="mt-2">
            <div class="text-2xl font-bold text-white font-mono tabular-nums">
              #{{ ledger.currentEpoch().epochNumber }}
            </div>
            <div class="text-[11px] text-emerald-400 mt-0.5">
              Status: {{ ledger.currentEpoch().status }} ({{ ledger.currentEpoch().claimsProcessed }} claims settled)
            </div>
          </div>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>Epoch Emission Budget</span>
            <mat-icon class="text-purple-400 text-sm">pie_chart</mat-icon>
          </div>
          <div class="mt-2">
            <div class="text-2xl font-bold text-white font-mono tabular-nums">
              {{ ledger.currentEpoch().totalRewardBudget.toFixed(0) }} <span class="text-sm font-normal text-slate-400">DSCS</span>
            </div>
            <div class="text-[11px] text-slate-500 mt-0.5">
              Hosting: {{ ledger.currentEpoch().distributedHostingTokens.toFixed(1) }} · Compute: {{ ledger.currentEpoch().distributedComputeTokens.toFixed(1) }}
            </div>
          </div>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>Double-Entry Equilibrium</span>
            <mat-icon class="text-emerald-400 text-sm">verified_user</mat-icon>
          </div>
          <div class="mt-2">
            <div class="text-2xl font-bold text-emerald-400 flex items-center gap-1.5">
              <mat-icon class="text-emerald-400 text-base">check_circle</mat-icon>
              <span>BALANCED</span>
            </div>
            <div class="text-[11px] text-slate-500 mt-0.5 font-mono">
              Sum(Debits) === Sum(Credits)
            </div>
          </div>
        </div>
      </div>

      <!-- Reconciliation Alert Banner -->
      @if (reconciliationResult(); as res) {
        <div class="p-4 rounded-xl bg-slate-900 border border-emerald-500/80 space-y-2">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
              <mat-icon class="text-sm">verified</mat-icon>
              <span>Double-Entry Ledger Audit Passed</span>
            </div>
            <button (click)="reconciliationResult.set(null)" class="text-slate-400 hover:text-white">
              <mat-icon class="text-xs">close</mat-icon>
            </button>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-slate-300">
            @for (detail of res.auditDetails; track detail) {
              <div class="flex items-center gap-1.5">
                <mat-icon class="text-emerald-400 text-xs">done</mat-icon>
                <span>{{ detail }}</span>
              </div>
            }
          </div>
        </div>
      }

      <!-- Chart / Account Balances Grid -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 class="text-sm font-semibold text-white">Audited Network Balance Sheet</h3>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          @for (acc of accountsList(); track acc.accountId) {
            <div class="p-3.5 rounded-lg border border-slate-800 bg-slate-950 flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between text-xs">
                  <span class="font-medium text-white">{{ acc.accountId }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">{{ acc.accountType }}</span>
                </div>
                <div class="text-xl font-bold font-mono text-emerald-400 mt-2">
                  {{ acc.balance.toLocaleString('en-US', { maximumFractionDigits: 2 }) }} <span class="text-xs text-slate-400">DSCS</span>
                </div>
              </div>
              <div class="text-[11px] text-slate-500 pt-2 border-t border-slate-900 mt-2 flex justify-between">
                <span>Escrow: {{ acc.heldInEscrow }} DSCS</span>
                <span>Active</span>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Immutable Transaction Journal Table -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div class="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <h3 class="text-sm font-semibold text-white">Immutable Double-Entry Transaction Journal</h3>
          <span class="text-xs text-slate-400 font-mono">{{ ledger.transactions().length }} Entries Recorded</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead class="bg-slate-950/80 text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[11px]">
              <tr>
                <th class="px-5 py-3">Tx Hash & Reference</th>
                <th class="px-5 py-3">Epoch</th>
                <th class="px-5 py-3">Debit (Source)</th>
                <th class="px-5 py-3">Credit (Destination)</th>
                <th class="px-5 py-3 text-right">Amount</th>
                <th class="px-5 py-3">Description</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800">
              @for (tx of ledger.transactions(); track tx.id) {
                <tr class="hover:bg-slate-800/50 transition-colors">
                  <td class="px-5 py-3">
                    <div class="font-mono text-white text-[11px]">{{ tx.id }}</div>
                    <div class="font-mono text-[10px] text-slate-500">{{ tx.txHash.slice(0, 24) }}...</div>
                  </td>
                  <td class="px-5 py-3 font-mono text-slate-300">#{{ tx.epoch }}</td>
                  <td class="px-5 py-3 font-mono text-rose-400">{{ tx.debitAccount }}</td>
                  <td class="px-5 py-3 font-mono text-emerald-400">{{ tx.creditAccount }}</td>
                  <td class="px-5 py-3 font-mono tabular-nums text-right font-bold text-white">
                    +{{ tx.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 }) }} DSCS
                  </td>
                  <td class="px-5 py-3 text-slate-400">{{ tx.description }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class TokenLedger {
  readonly ledger = inject(LedgerService);

  readonly reconciliationResult = signal<ReturnType<LedgerService['reconcileLedger']> | null>(null);

  accountsList() {
    return Array.from(this.ledger.accounts().values());
  }

  runReconciliation() {
    const res = this.ledger.reconcileLedger();
    this.reconciliationResult.set(res);
  }
}
