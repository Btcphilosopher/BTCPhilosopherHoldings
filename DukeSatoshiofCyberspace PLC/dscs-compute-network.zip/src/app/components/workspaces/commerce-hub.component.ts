import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { CommerceService } from '../../services/commerce.service';

@Component({
  selector: 'app-commerce-hub',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-6 space-y-6">
      <!-- Title Bar -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-xl font-bold tracking-tight text-white">E-Commerce & Merchant Operations</h1>
            <span class="text-xs px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800 font-mono">
              Privacy Isolated · Zero Validator PII Leakage
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Decoupled merchant commerce hosted on DSCS nodes. Customer identities and payments are cryptographically partitioned from the proof layer.
          </p>
        </div>

        <div class="flex items-center gap-3">
          <div class="text-xs px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 font-mono">
            Cart Items: <span class="font-bold text-emerald-400">{{ totalCartCount() }}</span>
          </div>
        </div>
      </div>

      <!-- Main Layout: Product Catalog (Left) & Cart / Checkout & Webhook Monitor (Right) -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Products Grid (7 Cols) -->
        <div class="lg:col-span-7 space-y-4">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>Hardware & Digital Merchant Products</span>
            <span>Real-time stock reservation</span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            @for (prod of commerce.products(); track prod.id) {
              <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60 flex flex-col justify-between space-y-3">
                <div class="space-y-1">
                  <div class="flex items-center justify-between text-[11px]">
                    <span class="text-amber-400 font-mono">{{ prod.sku }}</span>
                    <span class="text-slate-500 font-mono">
                      {{ prod.stockCount - prod.reservedStock }} in stock
                      @if (prod.reservedStock > 0) {
                        <span class="text-blue-400">({{ prod.reservedStock }} reserved)</span>
                      }
                    </span>
                  </div>
                  <h3 class="text-sm font-semibold text-white">{{ prod.title }}</h3>
                  <p class="text-xs text-slate-400 leading-relaxed">{{ prod.description }}</p>
                </div>

                <div class="pt-3 border-t border-slate-800 flex items-center justify-between">
                  <div>
                    <div class="text-base font-bold text-white font-mono">$ {{ prod.priceUsd.toFixed(2) }}</div>
                    <div class="text-[10px] text-emerald-400 font-mono">or {{ prod.priceDscs }} DSCS</div>
                  </div>

                  <button
                    (click)="commerce.addToCart(prod, 1)"
                    [disabled]="prod.stockCount - prod.reservedStock <= 0"
                    class="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors disabled:opacity-40"
                  >
                    <mat-icon class="text-xs">add_shopping_cart</mat-icon>
                    <span>Add to Cart</span>
                  </button>
                </div>
              </div>
            }
          </div>

          <!-- Merchant Privacy Architecture Note -->
          <div class="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-xs">
            <div class="flex items-center gap-2 text-slate-300 font-semibold">
              <mat-icon class="text-blue-400 text-sm">lock</mat-icon>
              <span>Protocol Decoupling Invariant</span>
            </div>
            <p class="text-slate-400 leading-relaxed text-[11px]">
              Customer checkout data, credit card tokens, and delivery addresses are processed within secure enclaves and never visible to the PoUW validator network. The hosting node earns tokens solely from serving traffic and compute cycles, completely independent of merchandise sales price.
            </p>
          </div>
        </div>

        <!-- Cart, Checkout Simulator & Webhooks (5 Cols) -->
        <div class="lg:col-span-5 space-y-5">
          <!-- Active Cart & Checkout -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 class="text-sm font-semibold text-white">Active Order Checkout</h3>
              @if (commerce.cart().length > 0) {
                <button (click)="commerce.clearCart()" class="text-xs text-slate-500 hover:text-rose-400">Clear</button>
              }
            </div>

            @if (commerce.cart().length > 0) {
              <div class="space-y-2">
                @for (item of commerce.cart(); track item.productId) {
                  <div class="flex items-center justify-between text-xs p-2 rounded bg-slate-950 border border-slate-800/80">
                    <div>
                      <div class="font-medium text-white">{{ item.title }}</div>
                      <div class="text-[11px] text-slate-400">Qty: {{ item.quantity }} × $ {{ item.unitPriceUsd }}</div>
                    </div>
                    <div class="flex items-center gap-2">
                      <span class="font-mono text-emerald-400 font-bold">$ {{ (item.quantity * item.unitPriceUsd).toFixed(2) }}</span>
                      <button (click)="commerce.removeFromCart(item.productId)" class="text-slate-500 hover:text-rose-400">
                        <mat-icon class="text-xs">delete</mat-icon>
                      </button>
                    </div>
                  </div>
                }

                <div class="pt-3 border-t border-slate-800 flex justify-between text-sm font-bold text-white font-mono">
                  <span>Total Amount:</span>
                  <span class="text-emerald-400">$ {{ cartTotal().toFixed(2) }} USD</span>
                </div>

                <!-- Customer Email Input -->
                <div class="pt-2">
                  <label for="checkoutEmailInput" class="block text-[11px] text-slate-400 mb-1">Customer Identifier (Encrypted in transit)</label>
                  <input
                    id="checkoutEmailInput"
                    type="email"
                    [(ngModel)]="checkoutEmail"
                    class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                    placeholder="customer.satoshi@example.com"
                  />
                </div>

                <div class="pt-2 flex gap-2">
                  <button
                    (click)="submitCheckout('STRIPE_WEBHOOK')"
                    [disabled]="isProcessingCheckout()"
                    class="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 shadow transition-colors disabled:opacity-50"
                  >
                    <mat-icon class="text-xs">payment</mat-icon>
                    <span>Simulate Payment Webhook</span>
                  </button>
                </div>
              </div>
            } @else {
              <div class="p-6 text-center text-slate-500 text-xs space-y-1">
                <mat-icon class="text-slate-700 text-2xl">shopping_cart</mat-icon>
                <div>Shopping cart is empty</div>
                <p class="text-[11px] text-slate-600">Select products from the catalog to test stock reservation and payment fulfillment.</p>
              </div>
            }
          </div>

          <!-- Webhook Logs & Privacy Monitor -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 class="text-sm font-semibold text-white">Payment Webhook Logs & PII Audit</h3>
              <span class="text-[10px] text-emerald-400 font-mono">HMAC Verified</span>
            </div>

            <div class="p-3 bg-slate-950 border border-slate-800 rounded-lg font-mono text-[11px] text-slate-300 h-56 overflow-y-auto space-y-1.5 select-text">
              @for (log of commerce.webhookLogs(); track log) {
                <div class="leading-relaxed hover:bg-slate-900/50 p-0.5 rounded">{{ log }}</div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class CommerceHub {
  readonly commerce = inject(CommerceService);

  checkoutEmail = 'customer.alice@securemail.org';
  isProcessingCheckout = signal<boolean>(false);

  totalCartCount() {
    return this.commerce.cart().reduce((acc, i) => acc + i.quantity, 0);
  }

  cartTotal() {
    return this.commerce.cart().reduce((acc, i) => acc + i.unitPriceUsd * i.quantity, 0);
  }

  async submitCheckout(method: 'STRIPE_WEBHOOK' | 'DSCS_NATIVE') {
    this.isProcessingCheckout.set(true);
    try {
      await this.commerce.processCheckout(this.checkoutEmail, method);
    } finally {
      this.isProcessingCheckout.set(false);
    }
  }
}
