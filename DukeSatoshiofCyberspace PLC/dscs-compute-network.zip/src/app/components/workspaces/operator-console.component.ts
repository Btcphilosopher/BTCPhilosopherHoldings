import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { NetworkService } from '../../services/network.service';
import { LedgerService } from '../../services/ledger.service';
import { PouwEngineService } from '../../services/pouw-engine.service';
import { ServerNode } from '../../models/dscs.types';

@Component({
  selector: 'app-operator-console',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-6 space-y-6">
      <!-- Top Title & Node Selector Bar -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-xl font-bold tracking-tight text-white">Server Operator Workspace</h1>
            <span class="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono">
              daemon: dscs-node v0.9.4
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Independent infrastructure node telemetry, cryptographic identities, and verified settlement records.
          </p>
        </div>

        <div class="flex items-center gap-3">
          <label for="selectManagedNode" class="text-xs text-slate-400 font-medium">Select Managed Node:</label>
          <select
            id="selectManagedNode"
            [ngModel]="selectedNodeId()"
            (ngModelChange)="selectedNodeId.set($event)"
            class="bg-slate-900 border border-slate-750 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
          >
            @for (n of network.nodes(); track n.id) {
              <option [value]="n.id">{{ n.name }} ({{ n.region }})</option>
            }
          </select>

          <button
            (click)="showRegisterModal.set(true)"
            class="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <mat-icon class="text-xs">add_circle</mat-icon>
            <span>Register New Node</span>
          </button>
        </div>
      </div>

      @if (currentNode(); as node) {
        <!-- Key Metrics Strip -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <!-- Balance & Earnings -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs text-slate-400">
              <span>Settled Node Balance</span>
              <mat-icon class="text-emerald-400 text-sm">account_balance_wallet</mat-icon>
            </div>
            <div class="mt-2">
              <div class="text-2xl font-bold text-white font-mono tabular-nums">
                {{ nodeBalance().toFixed(2) }} <span class="text-sm font-normal text-emerald-400">DSCS</span>
              </div>
              <div class="text-[11px] text-slate-500 mt-0.5">
                Lifetime: {{ node.totalTokensEarned.toFixed(1) }} DSCS earned
              </div>
            </div>
          </div>

          <!-- Reputation & SLA -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs text-slate-400">
              <span>Reputation & Reliability</span>
              <mat-icon class="text-blue-400 text-sm">verified</mat-icon>
            </div>
            <div class="mt-2">
              <div class="text-2xl font-bold text-white font-mono tabular-nums">
                {{ node.reputationScore.toFixed(1) }}<span class="text-sm font-normal text-slate-400">/100</span>
              </div>
              <div class="text-[11px] text-emerald-400 mt-0.5">
                {{ node.totalClaimsAccepted }} verified PoUW claims accepted
              </div>
            </div>
          </div>

          <!-- Workload Utilization -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs text-slate-400">
              <span>Capacity & Allocation</span>
              <mat-icon class="text-purple-400 text-sm">memory</mat-icon>
            </div>
            <div class="mt-2">
              <div class="text-2xl font-bold text-white font-mono tabular-nums">
                {{ nodeWorkloads().length }} <span class="text-sm font-normal text-slate-400">Active Workloads</span>
              </div>
              <div class="text-[11px] text-slate-500 mt-0.5">
                {{ node.hardware.cpuCores }} vCPUs · {{ node.hardware.ramGb }} GB RAM
              </div>
            </div>
          </div>

          <!-- Daemon & Security Status -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs text-slate-400">
              <span>Node State & Attestation</span>
              <mat-icon [class.text-emerald-400]="node.status === 'ONLINE'" [class.text-amber-400]="node.status === 'MAINTENANCE'" class="text-sm">
                {{ node.status === 'ONLINE' ? 'check_circle' : 'build' }}
              </mat-icon>
            </div>
            <div class="mt-2">
              <div class="text-lg font-bold text-white flex items-center gap-2">
                <span>{{ node.status }}</span>
                @if (node.hardware.teeAttestation) {
                  <span class="text-[10px] px-1.5 py-0.5 bg-blue-950 text-blue-300 border border-blue-800 rounded font-mono">TEE</span>
                }
              </div>
              <div class="text-[11px] text-slate-500 mt-0.5 font-mono">
                IP: {{ node.ipAddress }}
              </div>
            </div>
          </div>
        </div>

        <!-- Node Hardware & Resource Telemetry Meters -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <!-- Hardware Specs Card -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 class="text-sm font-semibold text-white">Hardware Declaration</h3>
              <span class="text-xs text-slate-400 font-mono">{{ node.region }}</span>
            </div>

            <div class="space-y-3 text-xs">
              <div class="flex items-center justify-between">
                <span class="text-slate-400">CPU Architecture:</span>
                <span class="font-medium text-slate-200 text-right">{{ node.hardware.cpuModel }}</span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">Cores / Threads:</span>
                <span class="font-mono text-slate-200">{{ node.hardware.cpuCores }} Cores</span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">System Memory:</span>
                <span class="font-mono text-slate-200">{{ node.hardware.ramGb }} GB ECC Registered</span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">Local Storage:</span>
                <span class="font-mono text-slate-200">{{ node.hardware.storageGb }} GB {{ node.hardware.storageType }}</span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">Uplink Throughput:</span>
                <span class="font-mono text-slate-200">{{ node.hardware.bandwidthMbps }} Mbps</span>
              </div>
              @if (node.hardware.gpuModel) {
                <div class="flex items-center justify-between">
                  <span class="text-slate-400">Compute Accelerator:</span>
                  <span class="font-mono text-purple-300">{{ node.hardware.gpuModel }}</span>
                </div>
              }
              <div class="flex items-center justify-between">
                <span class="text-slate-400">Hardware Attestation:</span>
                <span class="text-emerald-400 flex items-center gap-1">
                  <mat-icon class="text-xs">shield</mat-icon>
                  {{ node.hardware.teeAttestation ? 'Verified TEE Enclave' : 'Standard Linux Kernel' }}
                </span>
              </div>
            </div>

            <!-- Cryptographic Identity & Public Key -->
            <div class="pt-3 border-t border-slate-800">
              <div class="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
                <span>Ed25519 Public Key:</span>
                <button (click)="rotateKey()" class="text-emerald-400 hover:underline text-[10px]">Rotate Key</button>
              </div>
              <div class="p-2 rounded bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300 break-all select-all">
                {{ node.publicKey }}
              </div>
            </div>

            <!-- Operator Action Controls -->
            <div class="pt-2 flex items-center gap-2">
              <button
                (click)="toggleMaintenance()"
                class="flex-1 py-1.5 px-3 rounded-lg border text-xs font-medium transition-colors"
                [class.border-amber-500]="node.status === 'ONLINE'"
                [class.text-amber-400]="node.status === 'ONLINE'"
                [class.hover:bg-amber-950]="node.status === 'ONLINE'"
                [class.border-emerald-500]="node.status === 'MAINTENANCE'"
                [class.text-emerald-400]="node.status === 'MAINTENANCE'"
                [class.hover:bg-emerald-950]="node.status === 'MAINTENANCE'"
              >
                {{ node.status === 'ONLINE' ? 'Enter Maintenance' : 'Resume Online' }}
              </button>
            </div>
          </div>

          <!-- Live Telemetry Meters -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 lg:col-span-2">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 class="text-sm font-semibold text-white">Live Resource Telemetry</h3>
              <span class="text-xs text-slate-400 font-mono">Last heartbeat: 1.2s ago</span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <!-- CPU Meter -->
              <div class="p-4 rounded-xl border border-slate-800 bg-slate-950 space-y-2">
                <div class="flex items-center justify-between text-xs">
                  <span class="text-slate-400">CPU Core Utilization</span>
                  <span class="font-mono font-bold text-white">{{ node.telemetry.cpuUsagePct }}%</span>
                </div>
                <div class="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                  <div class="bg-emerald-500 h-full rounded-full transition-all duration-500" [style.width.%]="node.telemetry.cpuUsagePct"></div>
                </div>
                <div class="text-[11px] text-slate-500 flex justify-between">
                  <span>Frequency: 3.2 GHz</span>
                  <span>Temp: {{ node.telemetry.temperatureC }}°C</span>
                </div>
              </div>

              <!-- RAM Meter -->
              <div class="p-4 rounded-xl border border-slate-800 bg-slate-950 space-y-2">
                <div class="flex items-center justify-between text-xs">
                  <span class="text-slate-400">RAM Allocated</span>
                  <span class="font-mono font-bold text-white">{{ node.telemetry.ramUsagePct }}%</span>
                </div>
                <div class="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                  <div class="bg-blue-500 h-full rounded-full transition-all duration-500" [style.width.%]="node.telemetry.ramUsagePct"></div>
                </div>
                <div class="text-[11px] text-slate-500 flex justify-between">
                  <span>Used: {{ ((node.hardware.ramGb * node.telemetry.ramUsagePct) / 100).toFixed(0) }} GB</span>
                  <span>Total: {{ node.hardware.ramGb }} GB</span>
                </div>
              </div>

              <!-- Storage NVMe Meter -->
              <div class="p-4 rounded-xl border border-slate-800 bg-slate-950 space-y-2">
                <div class="flex items-center justify-between text-xs">
                  <span class="text-slate-400">NVMe Capacity Retained</span>
                  <span class="font-mono font-bold text-white">{{ ((node.telemetry.storageUsedGb / node.hardware.storageGb) * 100).toFixed(1) }}%</span>
                </div>
                <div class="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                  <div class="bg-purple-500 h-full rounded-full transition-all duration-500" [style.width.%]="(node.telemetry.storageUsedGb / node.hardware.storageGb) * 100"></div>
                </div>
                <div class="text-[11px] text-slate-500 flex justify-between">
                  <span>Retained: {{ node.telemetry.storageUsedGb }} GB</span>
                  <span>Total: {{ node.hardware.storageGb }} GB</span>
                </div>
              </div>

              <!-- Network Egress Meter -->
              <div class="p-4 rounded-xl border border-slate-800 bg-slate-950 space-y-2">
                <div class="flex items-center justify-between text-xs">
                  <span class="text-slate-400">Network Bandwidth Egress</span>
                  <span class="font-mono font-bold text-white">{{ node.telemetry.networkEgressMbps }} Mbps</span>
                </div>
                <div class="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                  <div class="bg-amber-500 h-full rounded-full transition-all duration-500" [style.width.%]="(node.telemetry.networkEgressMbps / node.hardware.bandwidthMbps) * 100"></div>
                </div>
                <div class="text-[11px] text-slate-500 flex justify-between">
                  <span>Capacity: {{ node.hardware.bandwidthMbps }} Mbps</span>
                  <span>SLA Delivery: 99.98%</span>
                </div>
              </div>
            </div>

            <!-- Supported Work Classes -->
            <div class="pt-3 border-t border-slate-800">
              <span class="text-xs text-slate-400 font-medium block mb-2">Supported PoUW Work Classes:</span>
              <div class="flex flex-wrap gap-2 text-xs">
                @for (c of node.supportedClasses; track c) {
                  <span class="px-2 py-1 rounded bg-slate-800 text-slate-300 font-mono text-[11px] border border-slate-700">
                    {{ c }}
                  </span>
                }
              </div>
            </div>
          </div>
        </div>

        <!-- Assigned Workloads Table -->
        <div class="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          <div class="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
            <h3 class="text-sm font-semibold text-white">Workloads Hosted on this Node</h3>
            <span class="text-xs text-slate-400 font-mono">{{ nodeWorkloads().length }} Containers Running</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-950/80 text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[11px]">
                <tr>
                  <th class="px-5 py-3">Workload Name</th>
                  <th class="px-5 py-3">Type</th>
                  <th class="px-5 py-3">Ingress Endpoint</th>
                  <th class="px-5 py-3">Total Requests</th>
                  <th class="px-5 py-3">P95 Latency</th>
                  <th class="px-5 py-3">Traffic Served</th>
                  <th class="px-5 py-3">Status</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800">
                @for (wl of nodeWorkloads(); track wl.id) {
                  <tr class="hover:bg-slate-800/50 transition-colors">
                    <td class="px-5 py-3 font-medium text-white">{{ wl.name }}</td>
                    <td class="px-5 py-3">
                      <span class="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[10px]">{{ wl.type }}</span>
                    </td>
                    <td class="px-5 py-3 font-mono text-emerald-400">
                      <a [href]="wl.ingressUrl" target="_blank" class="hover:underline">{{ wl.ingressUrl }}</a>
                    </td>
                    <td class="px-5 py-3 font-mono tabular-nums text-slate-300">{{ wl.metrics.requestsTotal.toLocaleString() }}</td>
                    <td class="px-5 py-3 font-mono tabular-nums text-emerald-400">{{ wl.metrics.p95LatencyMs }}ms</td>
                    <td class="px-5 py-3 font-mono tabular-nums text-slate-400">{{ (wl.metrics.bytesServedTotal / 1048576).toFixed(1) }} MB</td>
                    <td class="px-5 py-3">
                      <span class="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-400 font-mono text-[10px]">
                        {{ wl.status }}
                      </span>
                    </td>
                  </tr>
                } @empty {
                  <tr>
                    <td colspan="7" class="px-5 py-8 text-center text-slate-500">
                      No active workloads scheduled on this node yet.
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }

      <!-- Register Node Modal -->
      @if (showRegisterModal()) {
        <div class="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-6">
          <div class="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl flex flex-col">
            <div class="h-12 border-b border-slate-800 px-4 flex items-center justify-between bg-slate-950">
              <span class="text-sm font-semibold text-white">Register Autonomous Server Node</span>
              <button (click)="showRegisterModal.set(false)" class="text-slate-400 hover:text-white">
                <mat-icon class="text-sm">close</mat-icon>
              </button>
            </div>
            <div class="p-5 space-y-4 text-xs">
              <div>
                <label for="newNodeNameInput" class="block text-slate-400 mb-1">Node Identifier / Friendly Name</label>
                <input
                  id="newNodeNameInput"
                  type="text"
                  [(ngModel)]="newNodeName"
                  class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  placeholder="e.g. Amsterdam Bare-Metal Cluster #4"
                />
              </div>

              <div>
                <label for="newNodeRegionSelect" class="block text-slate-400 mb-1">Geographical Cloud Region</label>
                <select
                  id="newNodeRegionSelect"
                  [(ngModel)]="newNodeRegion"
                  class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="eu-west-1">eu-west-1 (Europe / Frankfurt & Berlin)</option>
                  <option value="us-east-1">us-east-1 (US East / Virginia)</option>
                  <option value="ap-southeast-1">ap-southeast-1 (Asia / Singapore)</option>
                  <option value="us-west-2">us-west-2 (US West / Oregon)</option>
                  <option value="sa-east-1">sa-east-1 (South America / São Paulo)</option>
                </select>
              </div>

              <div class="grid grid-cols-2 gap-3">
                <div>
                  <label for="newNodeCoresInput" class="block text-slate-400 mb-1">vCPUs Allocated</label>
                  <input
                    id="newNodeCoresInput"
                    type="number"
                    [(ngModel)]="newNodeCores"
                    class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label for="newNodeRamInput" class="block text-slate-400 mb-1">RAM (GB)</label>
                  <input
                    id="newNodeRamInput"
                    type="number"
                    [(ngModel)]="newNodeRam"
                    class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <p class="text-[11px] text-slate-500">
                A unique Ed25519 cryptographic keypair will be created for this node daemon to sign PoUW contribution evidence and challenge proofs.
              </p>
            </div>
            <div class="p-4 border-t border-slate-800 bg-slate-950 flex justify-end gap-2">
              <button (click)="showRegisterModal.set(false)" class="px-3 py-1.5 rounded text-slate-400 hover:text-white">
                Cancel
              </button>
              <button (click)="registerNode()" class="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-medium">
                Complete Registration
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class OperatorConsole {
  readonly network = inject(NetworkService);
  readonly ledger = inject(LedgerService);
  readonly pouw = inject(PouwEngineService);

  readonly selectedNodeId = signal<string>('node-alpha-berlin');
  readonly showRegisterModal = signal<boolean>(false);

  newNodeName = 'Amsterdam High-Throughput Node';
  newNodeRegion = 'eu-west-1';
  newNodeCores = 32;
  newNodeRam = 128;

  readonly currentNode = computed(() => {
    return this.network.nodes().find((n) => n.id === this.selectedNodeId()) || this.network.nodes()[0];
  });

  readonly nodeBalance = computed(() => {
    const node = this.currentNode();
    return node ? this.ledger.getNodeBalance(node.id) : 0;
  });

  readonly nodeWorkloads = computed(() => {
    const node = this.currentNode();
    if (!node) return [];
    return this.network.workloads().filter((w) => w.assignedNodeId === node.id);
  });

  toggleMaintenance() {
    const node = this.currentNode();
    if (node) this.network.toggleNodeMaintenance(node.id);
  }

  rotateKey() {
    const node = this.currentNode();
    if (node) this.network.rotateNodeKey(node.id);
  }

  registerNode() {
    if (!this.newNodeName) return;
    const n = this.network.registerNewNode({
      name: this.newNodeName,
      region: this.newNodeRegion as ServerNode['region'],
      hardware: {
        cpuCores: this.newNodeCores,
        cpuModel: 'AMD EPYC 9004 Series',
        ramGb: this.newNodeRam,
        storageGb: 2000,
        storageType: 'NVMe',
        bandwidthMbps: 5000,
        teeAttestation: true,
      },
    });
    this.selectedNodeId.set(n.id);
    this.showRegisterModal.set(false);
  }
}
