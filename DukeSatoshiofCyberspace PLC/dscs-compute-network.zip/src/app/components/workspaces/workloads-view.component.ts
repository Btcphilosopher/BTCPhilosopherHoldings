import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { NetworkService } from '../../services/network.service';
import { DeployedWorkload } from '../../models/dscs.types';

@Component({
  selector: 'app-workloads-view',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-6 space-y-6">
      <!-- Title & Actions Bar -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-xl font-bold tracking-tight text-white">Distributed Workload Runtime</h1>
            <span class="text-xs px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-800 font-mono">
              OCI Containers · TLS Ingress
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Running customer applications, microservices, and static websites with active SLA probes.
          </p>
        </div>

        <div class="flex items-center gap-3">
          <button
            (click)="showDeployModal.set(true)"
            class="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 shadow-sm transition-colors"
          >
            <mat-icon class="text-xs">rocket_launch</mat-icon>
            <span>Deploy Workload Template</span>
          </button>
        </div>
      </div>

      <!-- Main Layout: Workloads List & Probe Interactive Inspector -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Workloads Grid (2 Columns on large screens) -->
        <div class="lg:col-span-2 space-y-4">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>{{ network.workloads().length }} Active Deployments</span>
            <span>All healthy (0 degradation)</span>
          </div>

          <div class="space-y-3">
            @for (wl of network.workloads(); track wl.id) {
              <button
                type="button"
                (click)="selectedWorkload.set(wl)"
                [class.border-emerald-500]="selectedWorkload()?.id === wl.id"
                [class.bg-slate-900]="selectedWorkload()?.id === wl.id"
                class="text-left w-full p-4 rounded-xl border border-slate-800 bg-slate-900/60 hover:border-slate-700 cursor-pointer transition-all space-y-3"
              >
                <div class="flex items-start justify-between">
                  <div class="space-y-1">
                    <div class="flex items-center gap-2">
                      <h3 class="text-sm font-semibold text-white">{{ wl.name }}</h3>
                      <span class="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">{{ wl.type }}</span>
                    </div>
                    <div class="text-xs font-mono text-emerald-400 flex items-center gap-1">
                      <mat-icon class="text-xs">link</mat-icon>
                      <a [href]="wl.ingressUrl" target="_blank" class="hover:underline">{{ wl.ingressUrl }}</a>
                    </div>
                  </div>

                  <div class="text-right space-y-1">
                    <span class="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-400 font-mono">
                      <mat-icon class="text-xs">check_circle</mat-icon>
                      {{ wl.status }}
                    </span>
                    <div class="text-[10px] text-slate-400 font-mono">Node: {{ wl.assignedNodeId }}</div>
                  </div>
                </div>

                <!-- Performance Metrics Bar -->
                <div class="grid grid-cols-4 gap-2 pt-2 border-t border-slate-800/80 text-center">
                  <div class="bg-slate-950/80 p-2 rounded border border-slate-800/60">
                    <div class="text-[10px] text-slate-500">Requests</div>
                    <div class="text-xs font-bold text-white font-mono tabular-nums">{{ wl.metrics.requestsTotal.toLocaleString() }}</div>
                  </div>
                  <div class="bg-slate-950/80 p-2 rounded border border-slate-800/60">
                    <div class="text-[10px] text-slate-500">P95 Latency</div>
                    <div class="text-xs font-bold text-emerald-400 font-mono tabular-nums">{{ wl.metrics.p95LatencyMs }}ms</div>
                  </div>
                  <div class="bg-slate-950/80 p-2 rounded border border-slate-800/60">
                    <div class="text-[10px] text-slate-500">Error Rate</div>
                    <div class="text-xs font-bold text-white font-mono tabular-nums">{{ wl.metrics.errorRatePct }}%</div>
                  </div>
                  <div class="bg-slate-950/80 p-2 rounded border border-slate-800/60">
                    <div class="text-[10px] text-slate-500">Traffic</div>
                    <div class="text-xs font-bold text-slate-300 font-mono tabular-nums">{{ (wl.metrics.bytesServedTotal / 1048576).toFixed(1) }} MB</div>
                  </div>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- Right Side: Interactive Probe Tester & Container Logs -->
        <div class="space-y-6">
          @if (selectedWorkload(); as wl) {
            <!-- Interactive Probe Request Tester -->
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <div class="flex items-center justify-between border-b border-slate-800 pb-3">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-amber-400 text-sm">network_ping</mat-icon>
                  <h3 class="text-sm font-semibold text-white">Live Request Probe Tester</h3>
                </div>
                <span class="text-[10px] text-slate-400 font-mono">Class A / D Prober</span>
              </div>

              <p class="text-xs text-slate-400">
                Dispatch an authenticated probe request to verify availability, latency, and generate PoUW delivery evidence.
              </p>

              <div class="flex items-center gap-2">
                <span class="text-xs font-mono text-emerald-400 px-2 py-1 bg-slate-950 border border-slate-800 rounded">GET</span>
                <input
                  type="text"
                  [value]="wl.ingressUrl + '/'"
                  readonly
                  class="flex-1 bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs font-mono text-slate-300 select-all"
                />
              </div>

              <button
                (click)="sendTestProbe(wl.id)"
                [disabled]="isProbing()"
                class="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-medium flex items-center justify-center gap-2 shadow transition-colors disabled:opacity-50"
              >
                <mat-icon class="text-xs">send</mat-icon>
                <span>{{ isProbing() ? 'Executing Probe...' : 'Send SLA Probe Request' }}</span>
              </button>

              @if (lastProbeResult(); as probe) {
                <div class="p-3 bg-slate-950 border border-emerald-900/50 rounded-lg space-y-2 text-xs">
                  <div class="flex items-center justify-between">
                    <span class="text-emerald-400 font-bold flex items-center gap-1">
                      <mat-icon class="text-xs">check_circle</mat-icon>
                      HTTP {{ probe.statusCode }} OK
                    </span>
                    <span class="font-mono text-slate-400">{{ probe.latencyMs }}ms</span>
                  </div>
                  <div class="text-[11px] text-slate-500 font-mono break-all">
                    Proof Receipt: {{ probe.receiptHash }}
                  </div>
                </div>
              }
            </div>

            <!-- Live Container Log Tail -->
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <div class="flex items-center justify-between border-b border-slate-800 pb-2">
                <h3 class="text-sm font-semibold text-white">Container Stdout Logs</h3>
                <span class="text-[10px] text-slate-400 font-mono">tail -n 20</span>
              </div>

              <div class="p-3 bg-slate-950 border border-slate-800 rounded-lg font-mono text-[11px] text-slate-300 h-64 overflow-y-auto space-y-1.5 select-text">
                @for (log of wl.logs; track log) {
                  <div class="leading-relaxed hover:bg-slate-900/60 p-0.5 rounded">{{ log }}</div>
                }
              </div>
            </div>
          } @else {
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400 space-y-2">
              <mat-icon class="text-slate-600 text-3xl">touch_app</mat-icon>
              <div class="text-sm font-medium">Select a Workload</div>
              <p class="text-xs text-slate-500">Click on any running deployment to run probes and stream container logs.</p>
            </div>
          }
        </div>
      </div>

      <!-- Deploy Template Modal -->
      @if (showDeployModal()) {
        <div class="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-6">
          <div class="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl flex flex-col">
            <div class="h-12 border-b border-slate-800 px-4 flex items-center justify-between bg-slate-950">
              <span class="text-sm font-semibold text-white">Deploy Workload to Network</span>
              <button (click)="showDeployModal.set(false)" class="text-slate-400 hover:text-white">
                <mat-icon class="text-sm">close</mat-icon>
              </button>
            </div>
            <div class="p-5 space-y-4 text-xs">
              <div>
                <label for="workloadNameInput" class="block text-slate-400 mb-1">Workload Name</label>
                <input
                  id="workloadNameInput"
                  type="text"
                  [(ngModel)]="newWorkloadName"
                  class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  placeholder="e.g. Distributed Auth Service"
                />
              </div>

              <div>
                <label for="workloadTypeSelect" class="block text-slate-400 mb-1">Runtime Environment</label>
                <select
                  id="workloadTypeSelect"
                  [(ngModel)]="newWorkloadType"
                  class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="RUST_MICROSERVICE">Rust Actix / Axum Native Service (Class B)</option>
                  <option value="PYTHON_API">Python FastAPI / Inference Worker</option>
                  <option value="WEBSITE">Static Web Bundle / Astro / Hugo (Class A)</option>
                  <option value="CONTAINER">OCI Container Image (Docker/Podman)</option>
                </select>
              </div>

              <div>
                <label for="workloadTargetSelect" class="block text-slate-400 mb-1">Scheduling Target</label>
                <select
                  id="workloadTargetSelect"
                  [(ngModel)]="deployTargetNode"
                  class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="AUTO">DSCS Capacity Scheduler (Auto-balance)</option>
                  @for (n of network.nodes(); track n.id) {
                    <option [value]="n.id">{{ n.name }} ({{ n.region }})</option>
                  }
                </select>
              </div>
            </div>
            <div class="p-4 border-t border-slate-800 bg-slate-950 flex justify-end gap-2">
              <button (click)="showDeployModal.set(false)" class="px-3 py-1.5 rounded text-slate-400 hover:text-white">Cancel</button>
              <button (click)="deployTemplate()" class="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-medium">
                Provision & Launch
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class WorkloadsView {
  readonly network = inject(NetworkService);

  readonly selectedWorkload = signal<DeployedWorkload | null>(this.network.workloads()[0] || null);
  readonly isProbing = signal<boolean>(false);
  readonly lastProbeResult = signal<Awaited<ReturnType<NetworkService['sendProbeRequest']>> | null>(null);
  readonly showDeployModal = signal<boolean>(false);

  newWorkloadName = 'Rust High-Concurrency RPC Service';
  newWorkloadType: DeployedWorkload['type'] = 'RUST_MICROSERVICE';
  deployTargetNode = 'AUTO';

  async sendTestProbe(workloadId: string) {
    this.isProbing.set(true);
    try {
      const res = await this.network.sendProbeRequest(workloadId);
      this.lastProbeResult.set(res);
      // refresh selected workload to pick up new logs
      const updated = this.network.workloads().find((w) => w.id === workloadId);
      if (updated) this.selectedWorkload.set(updated);
    } finally {
      this.isProbing.set(false);
    }
  }

  async deployTemplate() {
    if (!this.newWorkloadName) return;
    const target = this.deployTargetNode === 'AUTO' ? undefined : this.deployTargetNode;
    const wl = await this.network.deployWorkload(this.newWorkloadName, this.newWorkloadType, undefined, target);
    this.selectedWorkload.set(wl);
    this.showDeployModal.set(false);
  }
}
