import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-architecture-docs',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-6 space-y-6">
      <!-- Title Bar -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-xl font-bold tracking-tight text-white">System Architecture & Protocol Specification</h1>
            <span class="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
              RFC-001 · Duke Satoshi of Cyberspace (DSCS)
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Modular crate layout, CLI toolchain, Byzantine threat model, and verifiable PoUW tokenomics.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="activeTab.set('crates')"
            [class.bg-emerald-600]="activeTab() === 'crates'"
            [class.text-white]="activeTab() === 'crates'"
            [class.bg-slate-900]="activeTab() !== 'crates'"
            class="px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-800 transition-colors"
          >
            Rust Crates
          </button>
          <button
            (click)="activeTab.set('cli')"
            [class.bg-emerald-600]="activeTab() === 'cli'"
            [class.text-white]="activeTab() === 'cli'"
            [class.bg-slate-900]="activeTab() !== 'cli'"
            class="px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-800 transition-colors"
          >
            CLI Reference
          </button>
          <button
            (click)="activeTab.set('threat')"
            [class.bg-emerald-600]="activeTab() === 'threat'"
            [class.text-white]="activeTab() === 'threat'"
            [class.bg-slate-900]="activeTab() !== 'threat'"
            class="px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-800 transition-colors"
          >
            Threat Model
          </button>
          <button
            (click)="activeTab.set('tokenomics')"
            [class.bg-emerald-600]="activeTab() === 'tokenomics'"
            [class.text-white]="activeTab() === 'tokenomics'"
            [class.bg-slate-900]="activeTab() !== 'tokenomics'"
            class="px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-800 transition-colors"
          >
            Tokenomics
          </button>
        </div>
      </div>

      <!-- Tab 1: Rust Crates Architecture -->
      @if (activeTab() === 'crates') {
        <div class="space-y-4">
          <div class="text-xs text-slate-400">
            DSCS is architected into 11 decoupled Rust crates adhering to strict separation between the control plane, workload execution plane, verification plane, and settlement plane.
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-2">
              <div class="text-emerald-400 font-mono text-xs font-bold">crates/server-agent</div>
              <h4 class="text-sm font-semibold text-white">Node Daemon & Attestation</h4>
              <p class="text-xs text-slate-400 leading-relaxed">
                Registers cryptographic Ed25519 identity, captures cgroup hardware telemetry, manages OCI namespaces, and signs execution evidence.
              </p>
            </div>

            <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-2">
              <div class="text-emerald-400 font-mono text-xs font-bold">crates/proof-engine</div>
              <h4 class="text-sm font-semibold text-white">PoUW Core Verifier</h4>
              <p class="text-xs text-slate-400 leading-relaxed">
                Executes the 14-step verification pipeline: deterministic recomputation (Class B), Merkle possession challenges (Class C), and TLS probe validation (Class A).
              </p>
            </div>

            <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-2">
              <div class="text-emerald-400 font-mono text-xs font-bold">crates/token-ledger</div>
              <h4 class="text-sm font-semibold text-white">Double-Entry Accounting</h4>
              <p class="text-xs text-slate-400 leading-relaxed">
                Immutable journal with balanced debit/credit invariants, atomic settlement, anti-replay nonce tracking, and treasury reserve management.
              </p>
            </div>

            <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-2">
              <div class="text-emerald-400 font-mono text-xs font-bold">crates/scheduler</div>
              <h4 class="text-sm font-semibold text-white">Capacity & Latency Matcher</h4>
              <p class="text-xs text-slate-400 leading-relaxed">
                Matches incoming customer workloads and PoUW tasks to eligible cluster nodes based on geographical affinity, RAM quotas, and reputation score.
              </p>
            </div>

            <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-2">
              <div class="text-emerald-400 font-mono text-xs font-bold">crates/validator</div>
              <h4 class="text-sm font-semibold text-white">Consensus & Quorum Engine</h4>
              <p class="text-xs text-slate-400 leading-relaxed">
                Aggregates independent validator audits, enforces 2/3 Byzantine supermajority voting, and signs consensus certificates prior to ledger payout.
              </p>
            </div>

            <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-2">
              <div class="text-emerald-400 font-mono text-xs font-bold">crates/commerce</div>
              <h4 class="text-sm font-semibold text-white">Merchant & Privacy Isolation</h4>
              <p class="text-xs text-slate-400 leading-relaxed">
                Manages product catalogs, stock reservation, and payment webhooks while ensuring customer PII is strictly encrypted away from node operators.
              </p>
            </div>
          </div>
        </div>
      }

      <!-- Tab 2: CLI Reference -->
      @if (activeTab() === 'cli') {
        <div class="space-y-4">
          <div class="text-xs text-slate-400">
            Operators and validators interact with the network via native Linux binaries: <code>dscs-node</code>, <code>dscs-validator</code>, and <code>dscs-cli</code>.
          </div>

          <div class="space-y-3 font-mono text-xs">
            <div class="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
              <div class="text-slate-400">// Register an independent server node with hardware attestation</div>
              <div class="text-emerald-400">$ dscs-node register --name "Frankfurt-Node-1" --region eu-west-1 --tee-enclave true</div>
              <div class="text-slate-500 text-[11px]">Output: Generated Ed25519 identity ed25519_pk_node_frankfurt_... (Status: REGISTERED)</div>
            </div>

            <div class="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
              <div class="text-slate-400">// Launch daemon with supported work classes</div>
              <div class="text-emerald-400">$ dscs-node run --classes CLASS_A,CLASS_B,CLASS_C --max-cores 32 --max-ram-gb 128</div>
              <div class="text-slate-500 text-[11px]">Output: Listening on 0.0.0.0:4892. Subscribed to epoch scheduler. Heartbeat interval: 5s.</div>
            </div>

            <div class="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
              <div class="text-slate-400">// Inspect and independently audit a PoUW proof claim</div>
              <div class="text-emerald-400">$ dscs-validator verify --claim-id claim_comp_prime_481 --recompute true</div>
              <div class="text-slate-500 text-[11px]">Output: 14/14 steps passed. Recomputation hash matched. Signed vote: APPROVE.</div>
            </div>

            <div class="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
              <div class="text-slate-400">// Query double-entry ledger balances and reconciliation audit</div>
              <div class="text-emerald-400">$ dscs-cli ledger balance-sheet --verify-invariants</div>
              <div class="text-slate-500 text-[11px]">Output: Total Assets = Total Liabilities. Reconciled 1,420 transactions. Zero discrepancies.</div>
            </div>
          </div>
        </div>
      }

      <!-- Tab 3: Threat Model & Countermeasures -->
      @if (activeTab() === 'threat') {
        <div class="space-y-4 text-xs">
          <div class="text-slate-400">
            The DSCS security framework models adversarial server operators, colluding validators, and fabricated hosting traffic.
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-2">
              <h4 class="text-sm font-semibold text-rose-400 flex items-center gap-1.5">
                <mat-icon class="text-sm">warning</mat-icon>
                <span>Threat: Self-Generated Fake Traffic</span>
              </h4>
              <p class="text-slate-400 leading-relaxed text-[11px]">
                A node operator sends thousands of self-issued HTTP requests to their own hosted site to inflate Class A hosting units.
              </p>
              <div class="pt-2 border-t border-slate-800 text-emerald-400 text-[11px]">
                <strong>Defense:</strong> Independent external probe cluster cross-verifies ingress traffic with randomized distributed probe IP endpoints. Self-issued loopback traffic is filtered out at Step 6 of the verification pipeline.
              </div>
            </div>

            <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-2">
              <h4 class="text-sm font-semibold text-rose-400 flex items-center gap-1.5">
                <mat-icon class="text-sm">warning</mat-icon>
                <span>Threat: Claim Replay & Double Payout</span>
              </h4>
              <p class="text-slate-400 leading-relaxed text-[11px]">
                An attacker captures a previously settled valid claim and re-submits it across subsequent epochs to extract unearned rewards.
              </p>
              <div class="pt-2 border-t border-slate-800 text-emerald-400 text-[11px]">
                <strong>Defense:</strong> Atomic anti-replay defense cache. Both the claim identifier and evidence commitment hash are recorded in an append-only index. Any replayed attempt immediately aborts with <code>REPLAY_REJECTED</code>.
              </div>
            </div>

            <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-2">
              <h4 class="text-sm font-semibold text-rose-400 flex items-center gap-1.5">
                <mat-icon class="text-sm">warning</mat-icon>
                <span>Threat: Tampered Compute Output</span>
              </h4>
              <p class="text-slate-400 leading-relaxed text-[11px]">
                A node fakes execution of a compute job by returning a random or zeroed byte array rather than performing actual matrix multiplication.
              </p>
              <div class="pt-2 border-t border-slate-800 text-emerald-400 text-[11px]">
                <strong>Defense:</strong> Deterministic recomputation (Class B). Validators re-evaluate the input specification and compare ground-truth SHA-256 hashes. Fraudulent claims receive 0 tokens and reputation slashing.
              </div>
            </div>

            <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-2">
              <h4 class="text-sm font-semibold text-rose-400 flex items-center gap-1.5">
                <mat-icon class="text-sm">warning</mat-icon>
                <span>Threat: Byzantine Validator Collusion</span>
              </h4>
              <p class="text-slate-400 leading-relaxed text-[11px]">
                A rogue validator node attempts to unilaterally approve invalid claims submitted by an accomplice server.
              </p>
              <div class="pt-2 border-t border-slate-800 text-emerald-400 text-[11px]">
                <strong>Defense:</strong> 2/3 Byzantine Fault Tolerant supermajority quorum. Individual rogue signatures are discarded; settlement requires multi-signature consensus certificates from independent validator nodes.
              </div>
            </div>
          </div>
        </div>
      }

      <!-- Tab 4: Tokenomics Whitepaper -->
      @if (activeTab() === 'tokenomics') {
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-5 text-xs">
          <div>
            <h3 class="text-base font-bold text-white">Duke Satoshi of Cyberspace (DSCS) Monetary Model</h3>
            <p class="text-slate-400 mt-1">
              A strictly compute-backed token governed by deterministic issuance rules, a hard cap of 21,000,000 DSCS, and epoch reward budgets.
            </p>
          </div>

          <div class="p-4 bg-slate-950 border border-slate-800 rounded-lg space-y-3 font-mono">
            <div class="text-emerald-400 font-bold">// Deterministic Reward Formula (pouw_v1.2.0)</div>
            <div class="text-slate-200">EligibleUnits = VerifiedUnits × QualityFactor × ReliabilityFactor</div>
            <div class="text-slate-200">NodeReward = min(EligibleUnits × WorkClassRate × NetworkAdjustment, MaxEligibleReward)</div>
            <p class="text-slate-400 text-[11px] font-sans">
              All variables are mathematically bounded. A node cannot inflate its reward by submitting duplicate records or fabricating CPU counters.
            </p>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
            <div class="p-3.5 rounded-lg border border-slate-800 bg-slate-950 space-y-1">
              <div class="text-[11px] text-slate-500 uppercase">Fixed Hard Cap</div>
              <div class="text-lg font-bold text-white font-mono">21,000,000 DSCS</div>
              <div class="text-[11px] text-slate-400">Strictly enforced in token-ledger minting constraints.</div>
            </div>
            <div class="p-3.5 rounded-lg border border-slate-800 bg-slate-950 space-y-1">
              <div class="text-[11px] text-slate-500 uppercase">Epoch Budget</div>
              <div class="text-lg font-bold text-emerald-400 font-mono">2,500 DSCS / Epoch</div>
              <div class="text-[11px] text-slate-400">Target 60-second epochs with anti-inflationary adjustment.</div>
            </div>
            <div class="p-3.5 rounded-lg border border-slate-800 bg-slate-950 space-y-1">
              <div class="text-[11px] text-slate-500 uppercase">Ecosystem Partitioning</div>
              <div class="text-lg font-bold text-blue-400 font-mono">70% Nodes / 15% Validators</div>
              <div class="text-[11px] text-slate-400">15% protocol reserve treasury for network bounties.</div>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class ArchitectureDocs {
  activeTab = signal<'crates' | 'cli' | 'threat' | 'tokenomics'>('crates');
}
