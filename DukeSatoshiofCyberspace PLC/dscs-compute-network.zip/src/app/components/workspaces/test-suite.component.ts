import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TestRunnerService } from '../../services/test-runner.service';
import { AcceptanceTestSuite } from '../../models/dscs.types';

@Component({
  selector: 'app-test-suite',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-6 space-y-6">
      <!-- Title Bar -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-xl font-bold tracking-tight text-white">Automated Protocol Acceptance Test Suite</h1>
            <span class="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono">
              Section 14 Specification Criteria (Tests A – F)
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Interactive, end-to-end verification of useful hosting, deterministic compute, Merkle storage, Byzantine validators, and double-entry ledger invariants.
          </p>
        </div>

        <div class="flex items-center gap-3">
          <button
            (click)="testRunner.runAllSuites()"
            [disabled]="testRunner.isRunningAny()"
            class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-md transition-colors disabled:opacity-50"
          >
            <mat-icon class="text-xs">{{ testRunner.isRunningAny() ? 'sync' : 'play_arrow' }}</mat-icon>
            <span>{{ testRunner.isRunningAny() ? 'Running Automated Verification...' : 'Run All Acceptance Tests (A - F)' }}</span>
          </button>
        </div>
      </div>

      <!-- Test Status Summary Cards -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        @for (suite of testRunner.suites(); track suite.id) {
          <button
            type="button"
            (click)="selectedSuiteId.set(suite.id)"
            [class.ring-2]="selectedSuiteId() === suite.id"
            [class.ring-emerald-500]="selectedSuiteId() === suite.id"
            class="text-left w-full p-3.5 rounded-xl border border-slate-800 bg-slate-900/70 hover:border-slate-700 cursor-pointer transition-all flex flex-col justify-between"
          >
            <div>
              <div class="flex items-center justify-between mb-1">
                <span class="text-xs font-mono font-bold text-white">{{ suite.code }}</span>
                <span
                  [class.text-emerald-400]="suite.status === 'PASSED'"
                  [class.text-blue-400]="suite.status === 'RUNNING'"
                  [class.text-rose-400]="suite.status === 'FAILED'"
                  [class.text-slate-500]="suite.status === 'IDLE'"
                  class="text-[10px] font-mono font-bold"
                >
                  {{ suite.status }}
                </span>
              </div>
              <div class="text-[11px] text-slate-300 font-medium leading-snug line-clamp-2">
                {{ suite.title }}
              </div>
            </div>

            <div class="pt-2 border-t border-slate-800/80 mt-2 flex items-center justify-between text-[10px] text-slate-500 w-full">
              <span>{{ suite.steps.length }} assertions</span>
              @if (suite.status === 'PASSED') {
                <mat-icon class="text-emerald-400 text-xs">check_circle</mat-icon>
              }
            </div>
          </button>
        }
      </div>

      <!-- Active Selected Test Inspection View -->
      @if (currentSuite(); as suite) {
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-6">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <div class="flex items-center gap-2">
                <span class="text-sm px-2 py-0.5 rounded bg-slate-800 text-emerald-400 font-mono font-bold">{{ suite.code }}</span>
                <h2 class="text-lg font-bold text-white">{{ suite.title }}</h2>
              </div>
              <p class="text-xs text-slate-400 mt-1">{{ suite.description }}</p>
            </div>

            <div class="flex items-center gap-3">
              <button
                (click)="testRunner.runSuite(suite.id)"
                [disabled]="testRunner.isRunningAny()"
                class="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 shadow transition-colors disabled:opacity-50"
              >
                <mat-icon class="text-xs">play_arrow</mat-icon>
                <span>Run {{ suite.code }} Standalone</span>
              </button>
            </div>
          </div>

          <!-- Step Assertions Progression -->
          <div class="space-y-3">
            <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-400">Step Verification Criteria & Assertions</h3>
            <div class="space-y-2">
              @for (st of suite.steps; track st.stepNumber) {
                <div
                  class="p-3.5 rounded-lg border text-xs flex items-start gap-3 transition-all"
                  [class.bg-slate-950]="st.status === 'PENDING'"
                  [class.border-slate-800]="st.status === 'PENDING'"
                  [class.bg-blue-950/20]="st.status === 'RUNNING'"
                  [class.border-blue-800]="st.status === 'RUNNING'"
                  [class.bg-emerald-950/20]="st.status === 'PASSED'"
                  [class.border-emerald-800/80]="st.status === 'PASSED'"
                  [class.bg-rose-950/20]="st.status === 'FAILED'"
                  [class.border-rose-800/80]="st.status === 'FAILED'"
                >
                  <div class="mt-0.5 shrink-0">
                    @switch (st.status) {
                      @case ('PASSED') {
                        <mat-icon class="text-emerald-400 text-base">check_circle</mat-icon>
                      }
                      @case ('RUNNING') {
                        <mat-icon class="text-blue-400 text-base animate-spin">sync</mat-icon>
                      }
                      @case ('FAILED') {
                        <mat-icon class="text-rose-400 text-base">cancel</mat-icon>
                      }
                      @default {
                        <div class="w-4 h-4 rounded-full border border-slate-700 flex items-center justify-center text-[10px] text-slate-500 font-mono">
                          {{ st.stepNumber }}
                        </div>
                      }
                    }
                  </div>

                  <div class="flex-1 space-y-1">
                    <div class="flex items-center justify-between">
                      <span class="font-semibold text-white">Step {{ st.stepNumber }}: {{ st.title }}</span>
                      <span
                        [class.text-emerald-400]="st.status === 'PASSED'"
                        [class.text-blue-400]="st.status === 'RUNNING'"
                        [class.text-slate-500]="st.status === 'PENDING'"
                        class="text-[10px] font-mono font-bold"
                      >
                        {{ st.status }}
                      </span>
                    </div>
                    <p class="text-slate-400 text-[11px]">{{ st.description }}</p>

                    @if (st.outputLog) {
                      <div class="p-2 rounded bg-slate-900 border border-slate-800 font-mono text-[11px] text-emerald-300 mt-1 select-all">
                        {{ st.outputLog }}
                      </div>
                    }
                  </div>
                </div>
              }
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class TestSuite {
  readonly testRunner = inject(TestRunnerService);
  readonly selectedSuiteId = signal<AcceptanceTestSuite['id']>('TEST_A');

  currentSuite() {
    return this.testRunner.suites().find((s) => s.id === this.selectedSuiteId()) || this.testRunner.suites()[0];
  }
}
