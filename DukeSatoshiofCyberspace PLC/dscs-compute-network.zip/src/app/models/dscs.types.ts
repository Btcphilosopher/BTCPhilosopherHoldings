export type WorkClass = 'CLASS_A_HOSTING' | 'CLASS_B_COMPUTE' | 'CLASS_C_STORAGE' | 'CLASS_D_NETWORK' | 'CLASS_E_CAPACITY';

export interface NodeHardware {
  cpuCores: number;
  cpuModel: string;
  ramGb: number;
  storageGb: number;
  storageType: 'NVMe' | 'SATA SSD' | 'Enterprise HDD';
  bandwidthMbps: number;
  teeAttestation: boolean;
  gpuModel?: string;
}

export interface NodeTelemetry {
  cpuUsagePct: number;
  ramUsagePct: number;
  storageUsedGb: number;
  networkEgressMbps: number;
  temperatureC: number;
  uptimeSeconds: number;
  lastHeartbeat: number;
}

export interface ServerNode {
  id: string;
  name: string;
  publicKey: string;
  ipAddress: string;
  region: 'eu-west-1' | 'us-east-1' | 'ap-southeast-1' | 'us-west-2' | 'sa-east-1';
  hardware: NodeHardware;
  telemetry: NodeTelemetry;
  status: 'ONLINE' | 'BUSY' | 'MAINTENANCE' | 'OFFLINE';
  daemonVersion: string;
  reputationScore: number; // 0 - 100
  registeredAt: number;
  totalClaimsAccepted: number;
  totalTokensEarned: number;
  reservedCapacity: boolean;
  supportedClasses: WorkClass[];
}

export interface WorkSpecification {
  id: string;
  workClass: WorkClass;
  title: string;
  assignedNodeId: string;
  deadline: number;
  requiredResources: {
    cores: number;
    ramMb: number;
    storageMb: number;
  };
  inputHash: string;
  expectedOutputHash?: string;
  maxEligibleReward: number;
  policyVersion: string;
  issuedAt: number;
  params: Record<string, unknown>;
}

export interface ClaimEvidence {
  workloadId: string;
  timestamp: number;
  executionDurationMs: number;
  resourceUsage: {
    cpuSeconds: number;
    peakRamMb: number;
    egressBytes: number;
  };
  outputHash: string;
  outputPayload?: string;
  receiptCount?: number;
  probesVerified?: number;
  storageChallengeNonce?: string;
  storageProofMerkleRoot?: string;
  signature: string;
}

export type ClaimStatus = 'PENDING' | 'VERIFYING' | 'ACCEPTED' | 'REJECTED' | 'DISPUTED' | 'SETTLED';

export interface VerificationLog {
  step: number;
  name: string;
  passed: boolean;
  details: string;
  timestamp: number;
}

export interface WorkClaim {
  id: string;
  specId: string;
  nodeId: string;
  workClass: WorkClass;
  evidence: ClaimEvidence;
  submittedAt: number;
  status: ClaimStatus;
  rejectionReason?: string;
  verifiedUnits: number;
  qualityFactor: number; // 0.0 - 1.0
  reliabilityFactor: number; // 0.0 - 1.0
  calculatedReward: number;
  settledTxId?: string;
  settledAt?: number;
  verificationAudit: VerificationLog[];
  validatorSignatures: { validatorId: string; vote: 'APPROVE' | 'REJECT'; signature: string }[];
}

export interface DeployedWorkload {
  id: string;
  name: string;
  type: 'WEBSITE' | 'RUST_MICROSERVICE' | 'PYTHON_API' | 'ECOMMERCE_APP' | 'CONTAINER';
  assignedNodeId: string;
  ingressUrl: string;
  port: number;
  status: 'RUNNING' | 'BUILDING' | 'STOPPED' | 'FAILED';
  createdAt: number;
  resourceQuotas: {
    cpuLimitCores: number;
    memoryLimitMb: number;
    storageLimitMb: number;
  };
  metrics: {
    requestsTotal: number;
    p95LatencyMs: number;
    errorRatePct: number;
    bytesServedTotal: number;
  };
  contentHash: string;
  htmlContent?: string;
  logs: string[];
}

export interface LedgerEntry {
  id: string;
  txHash: string;
  epoch: number;
  timestamp: number;
  debitAccount: string;
  creditAccount: string;
  amount: number;
  description: string;
  workClaimRef?: string;
  signature: string;
}

export interface AccountBalance {
  accountId: string;
  accountType: 'TREASURY' | 'VALIDATOR_POOL' | 'NODE_REWARD' | 'MERCHANT' | 'BURN';
  balance: number;
  heldInEscrow: number;
  lastUpdated: number;
}

export interface EpochInfo {
  epochNumber: number;
  startedAt: number;
  durationSeconds: number;
  totalRewardBudget: number;
  distributedHostingTokens: number;
  distributedComputeTokens: number;
  distributedValidatorTokens: number;
  claimsProcessed: number;
  status: 'ACTIVE' | 'SETTLING' | 'FINALIZED';
}

export interface ProductItem {
  id: string;
  title: string;
  sku: string;
  priceUsd: number;
  priceDscs: number;
  stockCount: number;
  reservedStock: number;
  category: string;
  description: string;
  imageUrl?: string;
}

export interface OrderItem {
  productId: string;
  title: string;
  quantity: number;
  unitPriceUsd: number;
}

export interface MerchantOrder {
  id: string;
  customerRefEncrypted: string; // Customer identity encrypted, never given to validators
  items: OrderItem[];
  totalAmountUsd: number;
  paymentMethod: 'STRIPE_WEBHOOK' | 'DSCS_NATIVE';
  paymentStatus: 'AWAITING_PAYMENT' | 'PAID' | 'FAILED' | 'REFUNDED';
  fulfillmentStatus: 'UNFULFILLED' | 'PROCESSING' | 'SHIPPED';
  createdAt: number;
  paymentTxRef?: string;
  webhookEventId?: string;
}

export interface AcceptanceTestStep {
  stepNumber: number;
  title: string;
  description: string;
  status: 'PENDING' | 'RUNNING' | 'PASSED' | 'FAILED';
  outputLog?: string;
  durationMs?: number;
}

export interface AcceptanceTestSuite {
  id: 'TEST_A' | 'TEST_B' | 'TEST_C' | 'TEST_D' | 'TEST_E' | 'TEST_F';
  code: string;
  title: string;
  category: string;
  description: string;
  status: 'IDLE' | 'RUNNING' | 'PASSED' | 'FAILED';
  steps: AcceptanceTestStep[];
  startedAt?: number;
  completedAt?: number;
  error?: string;
}
