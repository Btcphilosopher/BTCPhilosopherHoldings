import { Injectable, signal, inject } from '@angular/core';
import { ProductItem, MerchantOrder, OrderItem } from '../models/dscs.types';
import { CryptoService } from './crypto.service';

@Injectable({
  providedIn: 'root',
})
export class CommerceService {
  readonly products = signal<ProductItem[]>([
    {
      id: 'prod_server_rack_mount',
      title: 'DSCS 1U Micro-Server Blade',
      sku: 'HW-BLADE-1U-EPYC',
      priceUsd: 1850.0,
      priceDscs: 740.0,
      stockCount: 14,
      reservedStock: 2,
      category: 'Hardware & Enclaves',
      description: 'Custom AMD EPYC low-power blade engineered for autonomous DSCS node hosting with hardware TEE attestation.',
      imageUrl: '/favicon.ico',
    },
    {
      id: 'prod_hsm_key_module',
      title: 'Cryptographic Security Key Module',
      sku: 'SEC-HSM-USB-PRO',
      priceUsd: 145.0,
      priceDscs: 58.0,
      stockCount: 85,
      reservedStock: 5,
      category: 'Security & Keys',
      description: 'FIPS 140-3 Level 3 hardware security module for storing node agent and validator root signing keys.',
    },
    {
      id: 'prod_nvme_drive_pack',
      title: 'Enterprise 4TB NVMe PoUW Storage Pack',
      sku: 'STR-NVME-4TB-DC',
      priceUsd: 420.0,
      priceDscs: 168.0,
      stockCount: 30,
      reservedStock: 0,
      category: 'Storage Media',
      description: 'High-endurance PCIe Gen5 enterprise solid-state drive certified for high-frequency Merkle possession challenges.',
    },
    {
      id: 'prod_edge_router',
      title: '10GbE Low-Latency SDN Edge Gateway',
      sku: 'NET-10G-ROUTER',
      priceUsd: 890.0,
      priceDscs: 356.0,
      stockCount: 18,
      reservedStock: 1,
      category: 'Networking',
      description: 'High-throughput dual-port SFP+ gateway with automated BGP peering for Class D Network delivery nodes.',
    },
  ]);

  readonly orders = signal<MerchantOrder[]>([
    {
      id: 'ord_demo_98124',
      customerRefEncrypted: 'enc_cust_aes256_9f81a20b7c3',
      items: [
        {
          productId: 'prod_server_rack_mount',
          title: 'DSCS 1U Micro-Server Blade',
          quantity: 1,
          unitPriceUsd: 1850.0,
        },
      ],
      totalAmountUsd: 1850.0,
      paymentMethod: 'STRIPE_WEBHOOK',
      paymentStatus: 'PAID',
      fulfillmentStatus: 'PROCESSING',
      createdAt: Date.now() - 3600000 * 3,
      paymentTxRef: 'ch_stripe_3N9xKl2eZvKYlo2C',
      webhookEventId: 'evt_stripe_9812391024',
    },
  ]);

  readonly cart = signal<OrderItem[]>([]);
  readonly webhookLogs = signal<string[]>([
    `[${new Date(Date.now() - 3600000 * 3).toLocaleTimeString()}] Verified Stripe Webhook evt_stripe_9812391024 (HMAC-SHA256 signature verified)`,
    `[${new Date(Date.now() - 3600000 * 3).toLocaleTimeString()}] Inventory reserved -> Order ord_demo_98124 created -> Stock decremented`,
    `[${new Date(Date.now() - 3600000 * 3).toLocaleTimeString()}] Data isolation: PII encrypted (validator access strictly blocked)`,
  ]);

  private crypto = inject(CryptoService);

  addToCart(product: ProductItem, quantity = 1) {
    if (product.stockCount - product.reservedStock < quantity) {
      throw new Error(`Insufficient available stock for ${product.title}`);
    }

    const currentCart = [...this.cart()];
    const existing = currentCart.find((i) => i.productId === product.id);
    if (existing) {
      existing.quantity += quantity;
    } else {
      currentCart.push({
        productId: product.id,
        title: product.title,
        quantity,
        unitPriceUsd: product.priceUsd,
      });
    }

    // Reserve stock immediately to prevent overselling
    this.products.update((all) =>
      all.map((p) => (p.id === product.id ? { ...p, reservedStock: p.reservedStock + quantity } : p))
    );

    this.cart.set(currentCart);
  }

  removeFromCart(productId: string) {
    const item = this.cart().find((i) => i.productId === productId);
    if (item) {
      this.products.update((all) =>
        all.map((p) => (p.id === productId ? { ...p, reservedStock: Math.max(0, p.reservedStock - item.quantity) } : p))
      );
      this.cart.set(this.cart().filter((i) => i.productId !== productId));
    }
  }

  clearCart() {
    for (const item of this.cart()) {
      this.products.update((all) =>
        all.map((p) => (p.id === item.productId ? { ...p, reservedStock: Math.max(0, p.reservedStock - item.quantity) } : p))
      );
    }
    this.cart.set([]);
  }

  /**
   * Processes test checkout with simulated payment webhook and strict PII isolation.
   */
  async processCheckout(
    customerEmail: string,
    paymentMethod: 'STRIPE_WEBHOOK' | 'DSCS_NATIVE'
  ): Promise<MerchantOrder> {
    const cartItems = this.cart();
    if (cartItems.length === 0) {
      throw new Error('Shopping cart is empty');
    }

    const totalUsd = cartItems.reduce((acc, item) => acc + item.unitPriceUsd * item.quantity, 0);

    // Cryptographically encrypt/hash customer PII so validators NEVER see raw customer email or details
    const customerRefEncrypted = 'enc_pii_' + (await this.crypto.sha256(`SECRET_SALT:${customerEmail}:${Date.now()}`)).slice(0, 24);

    const orderId = `ord_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
    const webhookEventId = `evt_pay_${Date.now().toString(36)}`;
    const paymentTxRef = `tx_provider_${Date.now().toString(36)}`;

    // Finalize stock decrement: permanently deduct from stockCount, release reservedStock
    this.products.update((all) =>
      all.map((p) => {
        const item = cartItems.find((ci) => ci.productId === p.id);
        if (item) {
          return {
            ...p,
            stockCount: p.stockCount - item.quantity,
            reservedStock: Math.max(0, p.reservedStock - item.quantity),
          };
        }
        return p;
      })
    );

    const newOrder: MerchantOrder = {
      id: orderId,
      customerRefEncrypted,
      items: [...cartItems],
      totalAmountUsd: totalUsd,
      paymentMethod,
      paymentStatus: 'PAID',
      fulfillmentStatus: 'PROCESSING',
      createdAt: Date.now(),
      paymentTxRef,
      webhookEventId,
    };

    this.orders.update((list) => [newOrder, ...list]);
    this.cart.set([]);

    this.webhookLogs.update((prev) => [
      `[${new Date().toLocaleTimeString()}] Inbound payment webhook: ${webhookEventId} (Method: ${paymentMethod})`,
      `[${new Date().toLocaleTimeString()}] Order ${orderId} confirmed: $${totalUsd.toFixed(2)} USD paid. Stock finalized.`,
      `[${new Date().toLocaleTimeString()}] PRIVACY AUDIT: Customer identity isolated (${customerRefEncrypted}). Zero validator exposure.`,
      ...prev.slice(0, 25),
    ]);

    return newOrder;
  }
}
