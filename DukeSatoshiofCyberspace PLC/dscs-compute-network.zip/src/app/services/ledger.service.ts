import { Injectable, signal, computed, inject } from '@angular/core';
import { LedgerEntry, AccountBalance, EpochInfo } from '../models/dscs.types';
import { CryptoService } from './crypto.service';

export const TREASURY_ACCOUNT = 'TREASURY_RESERVE';
export const VALIDATOR_POOL_ACCOUNT = 'VALIDATOR_INCENTIVE_POOL';
export const EMISSION_REWARD_ACCOUNT = 'PROTOCOL_EMISSION_MINT';
export const BURN_ACCOUNT = 'PROTOCOL_BURN';

@Injectable({
  providedIn: 'root',
})
export class LedgerService {
  private readonly MAX_SUPPLY = 21000000; // 21 Million DSCS hard cap
  private readonly EPOCH_DURATION_SEC = 60;
  private readonly BASE_EPOCH_BUDGET = 2500; // Max DSCS per epoch

  // Settled claim IDs & evidence hashes to guarantee idempotent settlement & replay prevention
  private settledClaimIds = new Set<string>();
  private settledEvidenceHashes = new Set<string>();

  // State Signals
  readonly transactions = signal<LedgerEntry[]>([]);
  readonly accounts = signal<Map<string, AccountBalance>>(new Map());
  readonly currentEpoch = signal<EpochInfo>({
    epochNumber: 142,
    startedAt: Date.now() - 25000,
    durationSeconds: this.EPOCH_DURATION_SEC,
    totalRewardBudget: this.BASE_EPOCH_BUDGET,
    distributedHostingTokens: 340.5,
    distributedComputeTokens: 520.0,
    distributedValidatorTokens: 86.05,
    claimsProcessed: 18,
    status: 'ACTIVE',
  });

  // Derived signals
  readonly totalCirculatingSupply = computed(() => {
    let sum = 0;
    for (const [accId, acc] of this.accounts().entries()) {
      if (accId !== EMISSION_REWARD_ACCOUNT && accId !== BURN_ACCOUNT) {
        sum += acc.balance;
      }
    }
    return sum;
  });

  readonly isDoubleEntryBalanced = computed(() => {
    let totalDebit = 0;
    let totalCredit = 0;
    for (const tx of this.transactions()) {
      totalDebit += tx.amount;
      totalCredit += tx.amount;
    }
    return totalDebit === totalCredit;
  });

  private crypto = inject(CryptoService);

  constructor() {
    this.initializeGenesisState();
  }

  private initializeGenesisState() {
    const accMap = new Map<string, AccountBalance>();
    const now = Date.now();

    // Protocol Treasury
    accMap.set(TREASURY_ACCOUNT, {
      accountId: TREASURY_ACCOUNT,
      accountType: 'TREASURY',
      balance: 4500000,
      heldInEscrow: 250000,
      lastUpdated: now,
    });

    // Validator Pool
    accMap.set(VALIDATOR_POOL_ACCOUNT, {
      accountId: VALIDATOR_POOL_ACCOUNT,
      accountType: 'VALIDATOR_POOL',
      balance: 150000,
      heldInEscrow: 0,
      lastUpdated: now,
    });

    // Pre-registered Nodes
    const initialNodes = ['node-alpha-berlin', 'node-bravo-frankfurt', 'node-charlie-singapore', 'node-delta-virginia', 'node-echo-sao-paulo'];
    for (const nId of initialNodes) {
      accMap.set(`NODE_${nId}`, {
        accountId: `NODE_${nId}`,
        accountType: 'NODE_REWARD',
        balance: Math.floor(1250 + Math.random() * 800),
        heldInEscrow: 0,
        lastUpdated: now,
      });
    }

    this.accounts.set(accMap);

    // Initial genesis journal entry
    const genesisTx: LedgerEntry = {
      id: 'tx_genesis_000001',
      txHash: '0x9fa8e204c891bdc37e91823901bcefa1948203b9f182c4019a82c4019482910a',
      epoch: 1,
      timestamp: now - 3600000,
      debitAccount: EMISSION_REWARD_ACCOUNT,
      creditAccount: TREASURY_ACCOUNT,
      amount: 4500000,
      description: 'Genesis allocation to protocol reserve treasury',
      signature: 'sig_ed25519_genesis_protocol_authority',
    };

    this.transactions.set([genesisTx]);
  }

  /**
   * Settles a verified PoUW Claim into node and validator rewards.
   * Throws error if already settled (Replay attack prevention).
   */
  async settleClaim(
    claimId: string,
    evidenceHash: string,
    nodeId: string,
    tokenAmount: number,
    workClass: string,
    validatorId?: string
  ): Promise<{ txId: string; txHash: string }> {
    // 1. Anti-Replay Guard: Check if claim was already settled
    if (this.settledClaimIds.has(claimId)) {
      throw new Error(`REPLAY_REJECTED: Claim ${claimId} was already settled in epoch. Double settlement prohibited.`);
    }
    if (this.settledEvidenceHashes.has(evidenceHash)) {
      throw new Error(`REPLAY_REJECTED: Evidence hash ${evidenceHash.slice(0, 16)} was previously settled. Duplicate claim payload.`);
    }

    // 2. Supply Cap Check
    const currentSupply = this.totalCirculatingSupply();
    if (currentSupply + tokenAmount > this.MAX_SUPPLY) {
      throw new Error(`SUPPLY_CAP_EXCEEDED: Cannot issue ${tokenAmount} DSCS. Hard cap of ${this.MAX_SUPPLY} reached.`);
    }

    const now = Date.now();
    const epoch = this.currentEpoch().epochNumber;
    const nodeAccount = `NODE_${nodeId}`;
    const txId = `tx_${epoch}_${claimId.slice(0, 8)}_${now.toString(36)}`;

    // Generate cryptographic transaction hash
    const rawTx = `${txId}|${epoch}|${EMISSION_REWARD_ACCOUNT}|${nodeAccount}|${tokenAmount}|${claimId}|${now}`;
    const txHash = '0x' + (await this.crypto.sha256(rawTx));
    const signature = await this.crypto.signPayload(rawTx, 'settlement_coordinator');

    // 3. Double-entry transaction: Debit protocol emission, credit node reward account
    const txEntry: LedgerEntry = {
      id: txId,
      txHash,
      epoch,
      timestamp: now,
      debitAccount: EMISSION_REWARD_ACCOUNT,
      creditAccount: nodeAccount,
      amount: tokenAmount,
      description: `PoUW ${workClass} Verified Work Reward for ${nodeId}${validatorId ? ` (Auditor: ${validatorId})` : ''}`,
      workClaimRef: claimId,
      signature,
    };

    // Update balances
    const map = new Map(this.accounts());
    const existingNodeAcc = map.get(nodeAccount) || {
      accountId: nodeAccount,
      accountType: 'NODE_REWARD',
      balance: 0,
      heldInEscrow: 0,
      lastUpdated: now,
    };

    map.set(nodeAccount, {
      ...existingNodeAcc,
      balance: Number((existingNodeAcc.balance + tokenAmount).toFixed(4)),
      lastUpdated: now,
    });

    this.accounts.set(map);
    this.transactions.update((prev) => [txEntry, ...prev]);

    // Record in replay defense sets
    this.settledClaimIds.add(claimId);
    this.settledEvidenceHashes.add(evidenceHash);

    // Update epoch metrics
    this.currentEpoch.update((ep) => ({
      ...ep,
      claimsProcessed: ep.claimsProcessed + 1,
      distributedHostingTokens: workClass === 'CLASS_A_HOSTING'
        ? ep.distributedHostingTokens + tokenAmount
        : ep.distributedHostingTokens,
      distributedComputeTokens: workClass === 'CLASS_B_COMPUTE'
        ? ep.distributedComputeTokens + tokenAmount
        : ep.distributedComputeTokens,
    }));

    return { txId, txHash };
  }

  isClaimSettled(claimId: string): boolean {
    return this.settledClaimIds.has(claimId);
  }

  /**
   * Reconciles total ledger transactions and verifies mathematical consistency.
   */
  reconcileLedger(): {
    isConsistent: boolean;
    totalTransactions: number;
    totalIssuance: number;
    circulatingSupply: number;
    settledClaimsCount: number;
    auditDetails: string[];
  } {
    const txs = this.transactions();
    let totalIssuance = 0;
    const auditDetails: string[] = [];

    for (const tx of txs) {
      if (tx.debitAccount === EMISSION_REWARD_ACCOUNT) {
        totalIssuance += tx.amount;
      }
    }

    auditDetails.push(`Total Transactions verified: ${txs.length}`);
    auditDetails.push(`Settled Claims Registered: ${this.settledClaimIds.size}`);
    auditDetails.push(`Double-Entry Balance Check: Debit = Credit = ${totalIssuance.toFixed(2)} DSCS`);
    auditDetails.push(`Max Supply Cap Invariant: ${this.totalCirculatingSupply().toFixed(2)} / ${this.MAX_SUPPLY} DSCS`);

    return {
      isConsistent: this.isDoubleEntryBalanced(),
      totalTransactions: txs.length,
      totalIssuance: Number(totalIssuance.toFixed(4)),
      circulatingSupply: Number(this.totalCirculatingSupply().toFixed(4)),
      settledClaimsCount: this.settledClaimIds.size,
      auditDetails,
    };
  }

  getNodeBalance(nodeId: string): number {
    const acc = this.accounts().get(`NODE_${nodeId}`);
    return acc ? acc.balance : 0;
  }
}
