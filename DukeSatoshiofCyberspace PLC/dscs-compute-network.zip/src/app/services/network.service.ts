import { Injectable, signal, inject } from '@angular/core';
import { ServerNode, DeployedWorkload, WorkClass } from '../models/dscs.types';
import { CryptoService } from './crypto.service';

@Injectable({
  providedIn: 'root',
})
export class NetworkService {
  readonly nodes = signal<ServerNode[]>([]);
  readonly workloads = signal<DeployedWorkload[]>([]);
  private crypto = inject(CryptoService);

  constructor() {
    this.seedInitialNetwork();
  }

  private seedInitialNetwork() {
    const initialNodes: ServerNode[] = [
      {
        id: 'node-alpha-berlin',
        name: 'Berlin Heterogeneous Cluster #1',
        publicKey: this.crypto.generateNodePublicKey('node-alpha-berlin'),
        ipAddress: '194.26.29.11',
        region: 'eu-west-1',
        hardware: {
          cpuCores: 64,
          cpuModel: 'AMD EPYC 9654 96-Core Processor',
          ramGb: 256,
          storageGb: 4000,
          storageType: 'NVMe',
          bandwidthMbps: 10000,
          teeAttestation: true,
          gpuModel: 'NVIDIA H100 PCIe 80GB',
        },
        telemetry: {
          cpuUsagePct: 34.2,
          ramUsagePct: 48.6,
          storageUsedGb: 1240,
          networkEgressMbps: 1420.5,
          temperatureC: 46.5,
          uptimeSeconds: 1482900,
          lastHeartbeat: Date.now() - 1200,
        },
        status: 'ONLINE',
        daemonVersion: 'dscs-node v0.9.4-linux-x86_64',
        reputationScore: 98.6,
        registeredAt: Date.now() - 30 * 86400000,
        totalClaimsAccepted: 142,
        totalTokensEarned: 8940.5,
        reservedCapacity: true,
        supportedClasses: ['CLASS_A_HOSTING', 'CLASS_B_COMPUTE', 'CLASS_C_STORAGE', 'CLASS_D_NETWORK', 'CLASS_E_CAPACITY'],
      },
      {
        id: 'node-bravo-frankfurt',
        name: 'Frankfurt Datacenter Node B',
        publicKey: this.crypto.generateNodePublicKey('node-bravo-frankfurt'),
        ipAddress: '185.190.140.82',
        region: 'eu-west-1',
        hardware: {
          cpuCores: 32,
          cpuModel: 'Intel Xeon Platinum 8480+',
          ramGb: 128,
          storageGb: 2000,
          storageType: 'NVMe',
          bandwidthMbps: 5000,
          teeAttestation: true,
        },
        telemetry: {
          cpuUsagePct: 22.8,
          ramUsagePct: 38.1,
          storageUsedGb: 810,
          networkEgressMbps: 680.0,
          temperatureC: 42.0,
          uptimeSeconds: 840000,
          lastHeartbeat: Date.now() - 2400,
        },
        status: 'ONLINE',
        daemonVersion: 'dscs-node v0.9.4-linux-x86_64',
        reputationScore: 99.1,
        registeredAt: Date.now() - 25 * 86400000,
        totalClaimsAccepted: 98,
        totalTokensEarned: 5410.0,
        reservedCapacity: true,
        supportedClasses: ['CLASS_A_HOSTING', 'CLASS_C_STORAGE', 'CLASS_D_NETWORK'],
      },
      {
        id: 'node-charlie-singapore',
        name: 'Singapore Edge Compute Pod 3',
        publicKey: this.crypto.generateNodePublicKey('node-charlie-singapore'),
        ipAddress: '103.152.112.44',
        region: 'ap-southeast-1',
        hardware: {
          cpuCores: 48,
          cpuModel: 'AMD EPYC 7763 64-Core Processor',
          ramGb: 192,
          storageGb: 3200,
          storageType: 'NVMe',
          bandwidthMbps: 10000,
          teeAttestation: true,
        },
        telemetry: {
          cpuUsagePct: 56.4,
          ramUsagePct: 62.0,
          storageUsedGb: 1890,
          networkEgressMbps: 2100.4,
          temperatureC: 51.2,
          uptimeSeconds: 2190000,
          lastHeartbeat: Date.now() - 1800,
        },
        status: 'ONLINE',
        daemonVersion: 'dscs-node v0.9.4-linux-x86_64',
        reputationScore: 97.4,
        registeredAt: Date.now() - 40 * 86400000,
        totalClaimsAccepted: 215,
        totalTokensEarned: 13420.0,
        reservedCapacity: false,
        supportedClasses: ['CLASS_A_HOSTING', 'CLASS_B_COMPUTE', 'CLASS_D_NETWORK'],
      },
      {
        id: 'node-delta-virginia',
        name: 'US-East Ashburn Cloud Node',
        publicKey: this.crypto.generateNodePublicKey('node-delta-virginia'),
        ipAddress: '54.210.88.19',
        region: 'us-east-1',
        hardware: {
          cpuCores: 32,
          cpuModel: 'AMD EPYC 7R13 Processor',
          ramGb: 128,
          storageGb: 1600,
          storageType: 'NVMe',
          bandwidthMbps: 5000,
          teeAttestation: false,
        },
        telemetry: {
          cpuUsagePct: 18.5,
          ramUsagePct: 29.4,
          storageUsedGb: 450,
          networkEgressMbps: 450.0,
          temperatureC: 39.8,
          uptimeSeconds: 620000,
          lastHeartbeat: Date.now() - 3100,
        },
        status: 'ONLINE',
        daemonVersion: 'dscs-node v0.9.4-linux-x86_64',
        reputationScore: 96.0,
        registeredAt: Date.now() - 15 * 86400000,
        totalClaimsAccepted: 64,
        totalTokensEarned: 3890.0,
        reservedCapacity: true,
        supportedClasses: ['CLASS_A_HOSTING', 'CLASS_B_COMPUTE', 'CLASS_C_STORAGE', 'CLASS_E_CAPACITY'],
      },
      {
        id: 'node-echo-sao-paulo',
        name: 'South America Tier-3 Server',
        publicKey: this.crypto.generateNodePublicKey('node-echo-sao-paulo'),
        ipAddress: '177.71.200.52',
        region: 'sa-east-1',
        hardware: {
          cpuCores: 16,
          cpuModel: 'Intel Xeon E-2388G',
          ramGb: 64,
          storageGb: 1000,
          storageType: 'SATA SSD',
          bandwidthMbps: 1000,
          teeAttestation: false,
        },
        telemetry: {
          cpuUsagePct: 12.1,
          ramUsagePct: 24.5,
          storageUsedGb: 310,
          networkEgressMbps: 180.2,
          temperatureC: 44.1,
          uptimeSeconds: 310000,
          lastHeartbeat: Date.now() - 4000,
        },
        status: 'ONLINE',
        daemonVersion: 'dscs-node v0.9.3-linux-x86_64',
        reputationScore: 94.2,
        registeredAt: Date.now() - 10 * 86400000,
        totalClaimsAccepted: 32,
        totalTokensEarned: 1620.0,
        reservedCapacity: false,
        supportedClasses: ['CLASS_A_HOSTING', 'CLASS_C_STORAGE'],
      },
    ];

    this.nodes.set(initialNodes);

    // Initial workloads running on the cluster
    const initialWorkloads: DeployedWorkload[] = [
      {
        id: 'wl_site_modern_agency',
        name: 'Apex Studio Digital Agency',
        type: 'WEBSITE',
        assignedNodeId: 'node-alpha-berlin',
        ingressUrl: 'https://apexstudio.dscs.cloud',
        port: 8080,
        status: 'RUNNING',
        createdAt: Date.now() - 86400000 * 2,
        resourceQuotas: {
          cpuLimitCores: 2,
          memoryLimitMb: 2048,
          storageLimitMb: 5120,
        },
        metrics: {
          requestsTotal: 34120,
          p95LatencyMs: 14.2,
          errorRatePct: 0.02,
          bytesServedTotal: 489201948,
        },
        contentHash: 'bafkrei_apex_site_v2_f891b2c4e',
        htmlContent: '<!DOCTYPE html><html><head><title>Apex Studio</title></head><body><h1>Welcome to Apex Studio</h1><p>Served from DSCS Distributed Node Berlin</p></body></html>',
        logs: [
          '[2026-10-29 08:12:01] Container spawned in isolated cgroup namespace (vCPU: 2, RAM: 2GB)',
          '[2026-10-29 08:12:02] TLS ingress registered at https://apexstudio.dscs.cloud',
          '[2026-10-29 08:12:02] Healthcheck GET / - HTTP 200 OK in 1.4ms',
          '[2026-10-29 08:24:19] Egress batch dispatched (1,420 requests, 0 errors)',
        ],
      },
      {
        id: 'wl_api_rust_auth',
        name: 'Rust Token Verification Microservice',
        type: 'RUST_MICROSERVICE',
        assignedNodeId: 'node-alpha-berlin',
        ingressUrl: 'https://auth-api.dscs.cloud',
        port: 9001,
        status: 'RUNNING',
        createdAt: Date.now() - 86400000 * 5,
        resourceQuotas: {
          cpuLimitCores: 4,
          memoryLimitMb: 4096,
          storageLimitMb: 10240,
        },
        metrics: {
          requestsTotal: 184910,
          p95LatencyMs: 3.8,
          errorRatePct: 0.00,
          bytesServedTotal: 1048576000,
        },
        contentHash: 'bafkrei_rust_actix_auth_v1_9a12c',
        logs: [
          '[2026-10-29 07:00:00] Actix-web server listening on 0.0.0.0:9001 (workers: 4)',
          '[2026-10-29 07:00:01] Ed25519 cryptographic verification pipeline initialized',
          '[2026-10-29 07:45:12] Periodic SLA probe: 10,000 req/sec benchmark nominal',
        ],
      },
      {
        id: 'wl_store_ecom_app',
        name: 'Nordic Minimal Living Storefront',
        type: 'ECOMMERCE_APP',
        assignedNodeId: 'node-bravo-frankfurt',
        ingressUrl: 'https://nordicliving.dscs.store',
        port: 3001,
        status: 'RUNNING',
        createdAt: Date.now() - 86400000,
        resourceQuotas: {
          cpuLimitCores: 4,
          memoryLimitMb: 4096,
          storageLimitMb: 20480,
        },
        metrics: {
          requestsTotal: 12480,
          p95LatencyMs: 18.6,
          errorRatePct: 0.01,
          bytesServedTotal: 256000000,
        },
        contentHash: 'bafkrei_ecom_nordic_checkout_37f',
        logs: [
          '[2026-10-29 08:00:00] E-commerce container booted. Catalog initialized (12 SKUs).',
          '[2026-10-29 08:00:01] Merchant isolation perimeter active. Customer PII decoupled from validator layer.',
          '[2026-10-29 08:15:30] Webhook listener configured for payment callbacks.',
        ],
      },
    ];

    this.workloads.set(initialWorkloads);
  }

  /**
   * Capacity Scheduler: selects best node according to work class, resources, region and reputation.
   */
  scheduleWorkload(
    workClass: WorkClass,
    requiredCores: number,
    requiredRamMb: number,
    preferredRegion?: string
  ): ServerNode {
    const candidates = this.nodes().filter(
      (n) =>
        n.status === 'ONLINE' &&
        n.supportedClasses.includes(workClass) &&
        n.hardware.cpuCores >= requiredCores &&
        n.hardware.ramGb * 1024 >= requiredRamMb
    );

    if (candidates.length === 0) {
      // fallback to best online node
      const anyOnline = this.nodes().find((n) => n.status === 'ONLINE');
      if (!anyOnline) throw new Error('No online nodes available in network');
      return anyOnline;
    }

    // Sort by region match, lower CPU usage, and high reputation score
    candidates.sort((a, b) => {
      if (preferredRegion) {
        if (a.region === preferredRegion && b.region !== preferredRegion) return -1;
        if (b.region === preferredRegion && a.region !== preferredRegion) return 1;
      }
      const scoreA = a.reputationScore - a.telemetry.cpuUsagePct * 0.2;
      const scoreB = b.reputationScore - b.telemetry.cpuUsagePct * 0.2;
      return scoreB - scoreA;
    });

    return candidates[0];
  }

  /**
   * Deploys a new workload to the network.
   */
  async deployWorkload(
    name: string,
    type: 'WEBSITE' | 'RUST_MICROSERVICE' | 'PYTHON_API' | 'ECOMMERCE_APP' | 'CONTAINER',
    htmlContent?: string,
    preferredNodeId?: string
  ): Promise<DeployedWorkload> {
    const assignedNode = preferredNodeId
      ? this.nodes().find((n) => n.id === preferredNodeId) || this.scheduleWorkload('CLASS_A_HOSTING', 2, 2048)
      : this.scheduleWorkload('CLASS_A_HOSTING', 2, 2048);

    const slug = name.toLowerCase().replace(/[^a-z0-9]/g, '-').slice(0, 24);
    const content = htmlContent || `<!DOCTYPE html><html><body><h1>${name}</h1><p>Hosted on DSCS Node ${assignedNode.id}</p></body></html>`;
    const cid = await this.crypto.computeCid(content);

    const newWorkload: DeployedWorkload = {
      id: `wl_${slug}_${Date.now().toString(36)}`,
      name,
      type,
      assignedNodeId: assignedNode.id,
      ingressUrl: `https://${slug}.dscs.cloud`,
      port: 8080 + this.workloads().length,
      status: 'RUNNING',
      createdAt: Date.now(),
      resourceQuotas: {
        cpuLimitCores: 2,
        memoryLimitMb: 2048,
        storageLimitMb: 5120,
      },
      metrics: {
        requestsTotal: 1,
        p95LatencyMs: 8.4,
        errorRatePct: 0.0,
        bytesServedTotal: content.length,
      },
      contentHash: cid,
      htmlContent: content,
      logs: [
        `[${new Date().toISOString()}] Workload package assigned to ${assignedNode.name} (${assignedNode.region})`,
        `[${new Date().toISOString()}] OCI container rootfs unpacked. Content CID: ${cid}`,
        `[${new Date().toISOString()}] Ingress TLS configured at https://${slug}.dscs.cloud`,
        `[${new Date().toISOString()}] Initial health check: HTTP 200 OK (8.4ms latency)`,
      ],
    };

    this.workloads.update((list) => [newWorkload, ...list]);
    return newWorkload;
  }

  /**
   * Simulates an independent probe request against a workload, verifying uptime & latency.
   */
  async sendProbeRequest(workloadId: string): Promise<{
    statusCode: number;
    latencyMs: number;
    bytesReceived: number;
    receiptHash: string;
    timestamp: number;
  }> {
    const wl = this.workloads().find((w) => w.id === workloadId);
    if (!wl) throw new Error(`Workload ${workloadId} not found`);

    const latency = Number((4.5 + Math.random() * 12.0).toFixed(1));
    const bytes = 1200 + Math.floor(Math.random() * 800);
    const now = Date.now();
    const receiptData = `PROBE|${wl.id}|${wl.assignedNodeId}|${now}|${200}|${latency}|${bytes}`;
    const receiptHash = await this.crypto.sha256(receiptData);

    // Update workload metrics
    this.workloads.update((all) =>
      all.map((item) => {
        if (item.id === workloadId) {
          return {
            ...item,
            metrics: {
              ...item.metrics,
              requestsTotal: item.metrics.requestsTotal + 1,
              bytesServedTotal: item.metrics.bytesServedTotal + bytes,
              p95LatencyMs: Number(((item.metrics.p95LatencyMs * 0.9) + (latency * 0.1)).toFixed(1)),
            },
            logs: [
              `[${new Date().toLocaleTimeString()}] Probe GET /: HTTP 200 (${latency}ms, ${bytes} bytes) - Hash: ${receiptHash.slice(0, 12)}...`,
              ...item.logs.slice(0, 30),
            ],
          };
        }
        return item;
      })
    );

    return {
      statusCode: 200,
      latencyMs: latency,
      bytesReceived: bytes,
      receiptHash,
      timestamp: now,
    };
  }

  /**
   * Toggle node maintenance mode
   */
  toggleNodeMaintenance(nodeId: string) {
    this.nodes.update((all) =>
      all.map((n) => {
        if (n.id === nodeId) {
          const newStatus = n.status === 'MAINTENANCE' ? 'ONLINE' : 'MAINTENANCE';
          return { ...n, status: newStatus };
        }
        return n;
      })
    );
  }

  /**
   * Rotate cryptographic key for a node
   */
  rotateNodeKey(nodeId: string) {
    const newKey = this.crypto.generateNodePublicKey(nodeId + '_' + Date.now().toString(36));
    this.nodes.update((all) =>
      all.map((n) => (n.id === nodeId ? { ...n, publicKey: newKey } : n))
    );
  }

  /**
   * Register a new node
   */
  registerNewNode(nodeData: Partial<ServerNode>): ServerNode {
    const id = `node-${nodeData.name?.toLowerCase().replace(/[^a-z0-9]/g, '-') || 'custom'}-${Date.now().toString(36)}`;
    const newNode: ServerNode = {
      id,
      name: nodeData.name || 'New Worker Node',
      publicKey: this.crypto.generateNodePublicKey(id),
      ipAddress: nodeData.ipAddress || '198.51.100.' + (Math.floor(Math.random() * 200) + 10),
      region: nodeData.region || 'eu-west-1',
      hardware: nodeData.hardware || {
        cpuCores: 16,
        cpuModel: 'AMD EPYC 7713',
        ramGb: 64,
        storageGb: 1000,
        storageType: 'NVMe',
        bandwidthMbps: 1000,
        teeAttestation: true,
      },
      telemetry: {
        cpuUsagePct: 15.0,
        ramUsagePct: 22.0,
        storageUsedGb: 120,
        networkEgressMbps: 150.0,
        temperatureC: 41.0,
        uptimeSeconds: 60,
        lastHeartbeat: Date.now(),
      },
      status: 'ONLINE',
      daemonVersion: 'dscs-node v0.9.4-linux-x86_64',
      reputationScore: 90.0,
      registeredAt: Date.now(),
      totalClaimsAccepted: 0,
      totalTokensEarned: 0,
      reservedCapacity: true,
      supportedClasses: ['CLASS_A_HOSTING', 'CLASS_B_COMPUTE', 'CLASS_C_STORAGE', 'CLASS_D_NETWORK', 'CLASS_E_CAPACITY'],
    };

    this.nodes.update((list) => [newNode, ...list]);
    return newNode;
  }
}
