import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class CryptoService {
  /**
   * Computes a SHA-256 digest in hex string format.
   * Uses browser/node crypto.subtle.
   */
  async sha256(data: string): Promise<string> {
    try {
      if (typeof crypto !== 'undefined' && crypto.subtle) {
        const msgUint8 = new TextEncoder().encode(data);
        const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
      }
    } catch {
      // fallback if unavailable
    }
    return this.fallbackSha256(data);
  }

  /**
   * Generates a deterministic simulated Ed25519 public key from node ID.
   */
  generateNodePublicKey(nodeId: string): string {
    const raw = `ed25519_pk_${nodeId}_` + this.simpleHash(nodeId).slice(0, 32);
    return raw;
  }

  /**
   * Signs a payload with a simulated node private key.
   */
  async signPayload(payload: string, privateKeyOrId: string): Promise<string> {
    const digest = await this.sha256(payload + '::' + privateKeyOrId);
    return `sig_ed25519_${digest.slice(0, 48)}`;
  }

  /**
   * Verifies that the signature matches the digest of the payload.
   */
  async verifySignature(payload: string, signature: string, expectedKeyOrId: string): Promise<boolean> {
    if (!signature.startsWith('sig_ed25519_')) {
      return false;
    }
    const expected = await this.signPayload(payload, expectedKeyOrId);
    return signature === expected;
  }

  /**
   * Computes content-addressed CID (bafy... style hash).
   */
  async computeCid(content: string): Promise<string> {
    const hash = await this.sha256(content);
    return `bafkrei_${hash.slice(0, 32)}`;
  }

  /**
   * Generates Merkle root for a set of storage blocks.
   */
  async computeMerkleRoot(blocks: string[]): Promise<string> {
    if (blocks.length === 0) return await this.sha256('empty');
    let hashes = await Promise.all(blocks.map((b) => this.sha256(b)));
    while (hashes.length > 1) {
      const nextLevel: string[] = [];
      for (let i = 0; i < hashes.length; i += 2) {
        const left = hashes[i];
        const right = i + 1 < hashes.length ? hashes[i + 1] : left;
        const combined = await this.sha256(left + right);
        nextLevel.push(combined);
      }
      hashes = nextLevel;
    }
    return hashes[0];
  }

  private fallbackSha256(ascii: string): string {
    let hash = 0;
    for (let i = 0; i < ascii.length; i++) {
      const char = ascii.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash |= 0;
    }
    const hex = Math.abs(hash).toString(16).padStart(8, '0');
    return (hex + hex + hex + hex + hex + hex + hex + hex).slice(0, 64);
  }

  private simpleHash(str: string): string {
    let h = 0x811c9dc5;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h += (h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24);
    }
    return (h >>> 0).toString(16).padStart(8, '0') + '0000000000000000';
  }
}
