package com.voltworks.backend.workers

import com.voltworks.backend.persistence.VoltworksEngine
import kotlinx.coroutines.*
import org.slf4j.LoggerFactory

/**
 * Periodic reconciliation worker expiring stale inventory reservations and workshop seat holds.
 */
class BackgroundWorkers(private val engine: VoltworksEngine) {
    private val logger = LoggerFactory.getLogger(BackgroundWorkers::class.java)
    private var job: Job? = null

    fun start(scope: CoroutineScope, intervalMs: Long = 30_000L) {
        job?.cancel()
        job = scope.launch(Dispatchers.Default) {
            while (isActive) {
                val swept = engine.runReconciliationSweep()
                if (swept > 0) {
                    logger.info("Reconciliation sweep released {} expired holds/reservations", swept)
                }
                delay(intervalMs)
            }
        }
    }

    fun stop() {
        job?.cancel()
    }
}
