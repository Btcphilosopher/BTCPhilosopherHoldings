package com.voltworks.backend.domain

import kotlinx.serialization.Serializable

@Serializable
enum class StaffRole {
    CUSTOMER, RETAIL_STAFF, TECHNICIAN, WORKSHOP_ORGANISER, MANAGER, FINANCE, ADMIN
}

@Serializable
enum class FulfilmentMode { DELIVERY, CLICK_AND_COLLECT }

@Serializable
enum class OrderStatus { DRAFT, PAYMENT_PENDING, ACCEPTED, COMPLETED, CANCELLED, NEEDS_RECONCILIATION }

@Serializable
enum class PaymentStatus { PENDING, SUCCEEDED, TIMED_OUT, FAILED, REFUNDED }

@Serializable
enum class ReservationStatus { HELD, CONFIRMED, EXPIRED, RELEASED }

@Serializable
enum class FulfilmentStatus {
    ORDER_ACCEPTED, PICKING, READY_FOR_COLLECTION, COLLECTED, DISPATCHED, DELIVERED, FULFILMENT_ERROR, CANCELLED
}

@Serializable
enum class RepairCategory { LAPTOP_PC, PHONE_TABLET, CONSOLE_CONTROLLER, OTHER_EQUIPMENT }

@Serializable
enum class RepairStatus {
    BOOKED, RECEIVED, DIAGNOSING, AWAITING_APPROVAL, AWAITING_PARTS,
    REPAIRING, TESTING, READY, COLLECTED, DECLINED_QUOTE, UNECONOMIC, CANCELLED, WARRANTY_RETURN
}

@Serializable
enum class PartsGrade { OEM_ORIGINAL, MANUFACTURER_CERTIFIED, COMPATIBLE_GRADE_A }

@Serializable
enum class QuoteDecision { PENDING, APPROVED, DECLINED, SUPERSEDED }

@Serializable
enum class WarrantyOutcome {
    PENDING_ASSESSMENT, WARRANTY_ASSESSMENT, UNRELATED_FAULT, ACCIDENTAL_DAMAGE, REPEAT_WORK, REFUND
}

@Serializable
enum class WorkshopBookingStatus { HELD, CONFIRMED, WAITLISTED, CANCELLED, EXPIRED, REFUNDED, ATTENDED }

@Serializable
enum class NotificationDeliveryStatus { QUEUED, SENT, FAILED, DELIVERED }

@Serializable
data class StoreDto(
    val id: String,
    val name: String,
    val addressLine: String,
    val city: String,
    val postcode: String,
    val phone: String,
    val email: String,
    val openingHours: Map<String, String>,
    val facilities: List<String>,
    val collectionInstructions: String,
    val supportsRepairs: Boolean,
    val supportsWorkshops: Boolean,
    val supportsTradeDesk: Boolean,
    val collectionLeadMinutes: Int,
    val collectionCapPerHour: Int,
    val version: Int = 1
)

@Serializable
data class StoreInventoryDto(
    val storeId: String,
    val sku: String,
    val physicalQty: Int,
    val reservedQty: Int,
    val quarantinedQty: Int,
    val inboundTransferQty: Int,
    val expectedDeliveryIso: String?,
    val version: Int = 1
) {
    val availableToPromise: Int
        get() = (physicalQty - reservedQty - quarantinedQty).coerceAtLeast(0)
}

@Serializable
data class QuantityTierDto(val minPacks: Int, val packPricePence: Long)

@Serializable
data class CompatibilityRuleDto(
    val targetSku: String,
    val targetTitle: String,
    val relationshipType: String,
    val ruleBasis: String,
    val manufacturerRef: String
)

@Serializable
data class ProductVariantDto(
    val sku: String,
    val productId: String,
    val variantLabel: String,
    val packQuantity: Int,
    val minPackQuantity: Int,
    val unitPricePence: Long,
    val packPricePence: Long,
    val vatRateBps: Int,
    val dimensionsMm: String?,
    val interfaceType: String?,
    val operatingVoltage: String?,
    val supportedPlatforms: List<String>,
    val specs: Map<String, String>,
    val tiers: List<QuantityTierDto> = emptyList(),
    val version: Int = 1
)

@Serializable
data class ProductDto(
    val id: String,
    val familyName: String,
    val category: String,
    val manufacturer: String,
    val shortSummary: String,
    val description: String,
    val warrantyMonths: Int,
    val includedContents: List<String>,
    val documentation: List<Map<String, String>>,
    val imageKeys: List<String>,
    val featured: Boolean,
    val variants: List<ProductVariantDto>,
    val compatibility: List<CompatibilityRuleDto> = emptyList(),
    val version: Int = 1
)

@Serializable
data class BasketLineRequest(val sku: String, val packCount: Int)

@Serializable
data class PriceBreakdownDto(
    val subtotalExVatPence: Long,
    val vatPence: Long,
    val deliveryFeePence: Long,
    val discountPence: Long,
    val totalPence: Long,
    val lines: List<PricedLineDto>
)

@Serializable
data class PricedLineDto(
    val sku: String,
    val title: String,
    val packCount: Int,
    val unitsPerPack: Int,
    val effectivePackPricePence: Long,
    val effectiveUnitPricePence: Long,
    val lineTotalPence: Long
)

@Serializable
data class ReserveRequest(
    val basketId: String,
    val storeId: String,
    val items: List<BasketLineRequest>,
    val idempotencyKey: String
)

@Serializable
data class ReservationDto(
    val id: String,
    val basketId: String,
    val storeId: String,
    val sku: String,
    val quantity: Int,
    val status: ReservationStatus,
    val expiresAtIso: String
)

@Serializable
data class CheckoutPayRequest(
    val basketId: String,
    val storeId: String,
    val fulfilmentMode: FulfilmentMode,
    val reservationIds: List<String>,
    val items: List<BasketLineRequest>,
    val customerEmail: String,
    val deliveryAddress: String? = null,
    val purchaseOrderRef: String? = null,
    val simulateTimeout: Boolean = false,
    val simulateFulfilmentError: Boolean = false,
    val idempotencyKey: String
)

@Serializable
data class OrderDto(
    val id: String,
    val storeId: String,
    val customerEmail: String,
    val fulfilmentMode: FulfilmentMode,
    val orderStatus: OrderStatus,
    val paymentStatus: PaymentStatus,
    val fulfilmentStatus: FulfilmentStatus,
    val collectionReference: String?,
    val estimatedReadyIso: String?,
    val subtotalExVatPence: Long,
    val vatPence: Long,
    val deliveryFeePence: Long,
    val totalPence: Long,
    val items: List<PricedLineDto>,
    val handoverVerifiedBy: String? = null,
    val version: Int = 1,
    val createdAtIso: String
)

@Serializable
data class RepairBookRequest(
    val customerName: String,
    val customerContact: String,
    val storeId: String,
    val category: RepairCategory,
    val deviceModel: String,
    val serialNumber: String?,
    val reportedFault: String,
    val appointmentSlotIso: String,
    val controlledAccessMode: String,
    val dataConsentAccepted: Boolean,
    val idempotencyKey: String
)

@Serializable
data class RepairQuoteDto(
    val id: String,
    val repairJobId: String,
    val quoteVersion: Int,
    val totalPence: Long,
    val diagnosticCreditPence: Long,
    val remainingPence: Long,
    val partsGrade: PartsGrade,
    val partsLimitations: String,
    val scopeSummary: String,
    val materialChange: Boolean,
    val customerDecision: QuoteDecision,
    val createdAtIso: String
)

@Serializable
data class RepairJobDto(
    val id: String,
    val customerName: String,
    val customerContact: String,
    val storeId: String,
    val category: RepairCategory,
    val deviceModel: String,
    val serialNumber: String?,
    val reportedFault: String,
    val appointmentSlotIso: String,
    val status: RepairStatus,
    val diagnosticFeePence: Long,
    val diagnosticPaid: Boolean,
    val diagnosticCredited: Boolean,
    val approvedQuoteVersion: Int?,
    val approvedRemainingPence: Long?,
    val controlledAccessMode: String,
    val dataConsentAccepted: Boolean,
    val intakeConditionNotes: String?,
    val suppliedAccessories: String?,
    val finalTestRecord: String?,
    val collectionReceiptRef: String?,
    val warrantyMonths: Int,
    val quotes: List<RepairQuoteDto> = emptyList(),
    val progressNotes: List<String> = emptyList(),
    val version: Int = 1
)

@Serializable
data class CreateQuoteRequest(
    val totalPence: Long,
    val partsGrade: PartsGrade,
    val partsLimitations: String,
    val scopeSummary: String,
    val materialChange: Boolean,
    val expectedVersion: Int
)

@Serializable
data class QuoteDecisionRequest(
    val quoteVersion: Int,
    val approve: Boolean,
    val expectedVersion: Int,
    val idempotencyKey: String
)

@Serializable
data class WarrantyReturnRequest(
    val reportedRecurringFault: String,
    val idempotencyKey: String
)

@Serializable
data class WarrantyReturnDto(
    val id: String,
    val originalJobId: String,
    val reportedRecurringFault: String,
    val outcome: WarrantyOutcome,
    val freshDiagnosticCharged: Boolean,
    val resolutionNotes: String,
    val createdAtIso: String
)

@Serializable
data class WorkshopEventDto(
    val id: String,
    val workshopId: String,
    val title: String,
    val description: String,
    val prerequisites: String,
    val equipmentProvided: String,
    val agePolicy: String,
    val cancellationTerms: String,
    val storeId: String,
    val instructorName: String,
    val venueRoom: String,
    val startsAtUtcIso: String,
    val startsAtLondonFormatted: String,
    val durationMinutes: Int,
    val pricePence: Long,
    val capacity: Int,
    val heldSeats: Int,
    val confirmedSeats: Int,
    val version: Int = 1
) {
    val availableSeats: Int get() = (capacity - heldSeats - confirmedSeats).coerceAtLeast(0)
}

@Serializable
data class WorkshopHoldRequest(
    val attendeeName: String,
    val attendeeEmail: String,
    val idempotencyKey: String
)

@Serializable
data class WorkshopBookingDto(
    val id: String,
    val eventId: String,
    val attendeeName: String,
    val attendeeEmail: String,
    val status: WorkshopBookingStatus,
    val holdExpiresAtIso: String?,
    val attended: Boolean
)

@Serializable
data class TradeAccountRequest(
    val organisationName: String,
    val companyRegNo: String,
    val vatNumber: String?
)

@Serializable
data class TradeAccountDto(
    val id: String,
    val organisationName: String,
    val companyRegNo: String,
    val vatNumber: String?,
    val creditApproved: Boolean,
    val creditLimitPence: Long,
    val paymentTermsDays: Int
)

@Serializable
data class BuildingCentreEnquiryRequest(
    val organisationName: String,
    val contactEmail: String,
    val serviceScope: String,
    val specificationSummary: String
)

@Serializable
data class NotificationDto(
    val id: String,
    val channel: String,
    val previewTitle: String,
    val body: String,
    val deliveryStatus: NotificationDeliveryStatus,
    val createdAtIso: String
)

@Serializable
data class AuditLogDto(
    val id: Long,
    val actorId: String,
    val actorRole: StaffRole,
    val action: String,
    val entityType: String,
    val entityId: String,
    val reason: String,
    val createdAtIso: String
)
