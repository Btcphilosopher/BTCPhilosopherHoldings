package com.voltworks.backend.domain

import kotlin.math.roundToLong

/**
 * Pure server-side monetary calculator operating strictly in integer GBP minor units (pence).
 * Never uses IEEE-754 floating point for currency totals.
 */
object MonetaryCalculator {
    const val STANDARD_DELIVERY_FEE_PENCE: Long = 399L
    const val FREE_DELIVERY_THRESHOLD_PENCE: Long = 7500L
    const val DIAGNOSTIC_ASSESSMENT_FEE_PENCE: Long = 2900L

    fun effectivePackPricePence(variant: ProductVariantDto, packCount: Int): Long {
        require(packCount >= variant.minPackQuantity) {
            "Minimum pack quantity for ${variant.sku} is ${variant.minPackQuantity}"
        }
        val tier = variant.tiers
            .filter { packCount >= it.minPacks }
            .maxByOrNull { it.minPacks }
        return tier?.packPricePence ?: variant.packPricePence
    }

    fun computeBasket(
        lines: List<Pair<ProductVariantDto, Int>>,
        productTitles: Map<String, String>,
        mode: FulfilmentMode,
        discountPence: Long = 0L
    ): PriceBreakdownDto {
        val pricedLines = lines.map { (variant, packCount) ->
            val packPrice = effectivePackPricePence(variant, packCount)
            val lineTotal = packPrice * packCount
            val unitEffective = if (variant.packQuantity > 0) packPrice / variant.packQuantity else packPrice
            PricedLineDto(
                sku = variant.sku,
                title = productTitles[variant.productId] ?: variant.variantLabel,
                packCount = packCount,
                unitsPerPack = variant.packQuantity,
                effectivePackPricePence = packPrice,
                effectiveUnitPricePence = unitEffective,
                lineTotalPence = lineTotal
            )
        }
        val grossGoodsPence = pricedLines.sumOf { it.lineTotalPence }
        val cappedDiscount = discountPence.coerceIn(0L, grossGoodsPence)
        val netGoodsIncVat = grossGoodsPence - cappedDiscount
        val deliveryFee = when {
            mode == FulfilmentMode.CLICK_AND_COLLECT -> 0L
            netGoodsIncVat >= FREE_DELIVERY_THRESHOLD_PENCE || netGoodsIncVat == 0L -> 0L
            else -> STANDARD_DELIVERY_FEE_PENCE
        }
        val totalPence = netGoodsIncVat + deliveryFee
        // UK prices are VAT-inclusive at 20% (1/6 of gross = 20 / 120)
        val vatPence = ((netGoodsIncVat.toDouble() * 2000.0) / 12000.0).roundToLong()
        val subtotalExVatPence = netGoodsIncVat - vatPence
        return PriceBreakdownDto(
            subtotalExVatPence = subtotalExVatPence,
            vatPence = vatPence,
            deliveryFeePence = deliveryFee,
            discountPence = cappedDiscount,
            totalPence = totalPence,
            lines = pricedLines
        )
    }

    /**
     * Applies diagnostic credit at most once. Prevents duplicate credits.
     * Example: £149 (14900p) - £29 (2900p) = £120 (12000p) remaining.
     */
    fun calculateRepairQuoteCredit(
        quoteTotalPence: Long,
        diagnosticPaid: Boolean,
        diagnosticAlreadyCredited: Boolean,
        diagnosticFeePence: Long = DIAGNOSTIC_ASSESSMENT_FEE_PENCE
    ): Pair<Long, Long> {
        require(quoteTotalPence >= 0L) { "Quote total cannot be negative" }
        val credit = if (diagnosticPaid && !diagnosticAlreadyCredited) {
            minOf(diagnosticFeePence, quoteTotalPence)
        } else {
            0L
        }
        val remaining = quoteTotalPence - credit
        return credit to remaining
    }
}
