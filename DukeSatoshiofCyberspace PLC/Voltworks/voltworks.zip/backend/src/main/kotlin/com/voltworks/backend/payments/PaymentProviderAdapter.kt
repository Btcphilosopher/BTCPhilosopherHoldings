package com.voltworks.backend.payments

import java.util.concurrent.ConcurrentHashMap

data class PaymentRequest(
    val idempotencyKey: String,
    val amountPence: Long,
    val currency: String = "GBP",
    val simulateTimeout: Boolean = false
)

sealed interface PaymentResult {
    data class Succeeded(val providerReference: String) : PaymentResult
    data class TimedOut(val reason: String) : PaymentResult
    data class Failed(val reason: String) : PaymentResult
}

interface PaymentProviderAdapter {
    val adapterName: String
    fun charge(request: PaymentRequest): PaymentResult
    fun queryStatus(providerReference: String): PaymentResult
}

/**
 * Simulated payment adapter supporting deterministic timeouts and idempotent retries.
 * Replaceable with a real PSP adapter (Stripe UK / Adyen / Worldpay) via PaymentProviderAdapter.
 */
class SimulatedPaymentAdapter : PaymentProviderAdapter {
    override val adapterName: String = "SimulatedBritishPayments"
    private val settledByKey = ConcurrentHashMap<String, PaymentResult.Succeeded>()

    override fun charge(request: PaymentRequest): PaymentResult {
        settledByKey[request.idempotencyKey]?.let { return it }
        if (request.amountPence <= 0L) {
            return PaymentResult.Failed("Amount must be positive")
        }
        if (request.simulateTimeout) {
            return PaymentResult.TimedOut("Payment gateway timed out awaiting 3DS confirmation. Safe to retry with the same idempotency key.")
        }
        val ref = "SIM-PAY-${request.idempotencyKey.take(8).uppercase()}-${System.nanoTime().toString().takeLast(4)}"
        val success = PaymentResult.Succeeded(ref)
        settledByKey[request.idempotencyKey] = success
        return success
    }

    override fun queryStatus(providerReference: String): PaymentResult {
        return PaymentResult.Succeeded(providerReference)
    }
}
