package com.voltworks.backend

import com.voltworks.backend.domain.*
import com.voltworks.backend.persistence.ConflictException
import com.voltworks.backend.persistence.ForbiddenException
import com.voltworks.backend.persistence.NotFoundException
import com.voltworks.backend.persistence.VoltworksEngine
import com.voltworks.backend.storage.ObjectStorageService
import com.voltworks.backend.storage.UploadIntentRequest
import com.voltworks.backend.workers.BackgroundWorkers
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.calllogging.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.plugins.cors.routing.*
import io.ktor.server.plugins.ratelimit.*
import io.ktor.server.plugins.statuspages.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlin.time.Duration.Companion.minutes

@Serializable
data class ApiError(val code: String, val message: String)

@Serializable
data class CollectOrderRequest(val collectionReference: String, val expectedVersion: Int)

@Serializable
data class StockAdjustRequest(val sku: String, val physicalDelta: Int, val expectedVersion: Int, val reason: String)

fun main() {
    val port = System.getenv("PORT")?.toIntOrNull() ?: 8080
    embeddedServer(Netty, port = port, host = "0.0.0.0") {
        voltworksModule()
    }.start(wait = true)
}

fun Application.voltworksModule(engine: VoltworksEngine = VoltworksEngine()) {
    val storage = ObjectStorageService()
    val workers = BackgroundWorkers(engine)
    workers.start(this)

    install(ContentNegotiation) {
        json(Json { ignoreUnknownKeys = true; encodeDefaults = true })
    }
    install(CallLogging)
    install(CORS) {
        allowMethod(HttpMethod.Options)
        allowMethod(HttpMethod.Get)
        allowMethod(HttpMethod.Post)
        allowMethod(HttpMethod.Put)
        allowHeader(HttpHeaders.ContentType)
        allowHeader("X-Voltworks-Actor-Id")
        allowHeader("X-Voltworks-Role")
        allowHeader("Idempotency-Key")
        anyHost()
    }
    install(RateLimit) {
        register(RateLimitName("checkout")) {
            rateLimiter(limit = 30, refillPeriod = 1.minutes)
        }
    }
    install(StatusPages) {
        exception<ConflictException> { call, cause ->
            call.respond(HttpStatusCode.Conflict, ApiError("CONFLICT", cause.message ?: "Conflict"))
        }
        exception<ForbiddenException> { call, cause ->
            call.respond(HttpStatusCode.Forbidden, ApiError("FORBIDDEN", cause.message ?: "Forbidden"))
        }
        exception<NotFoundException> { call, cause ->
            call.respond(HttpStatusCode.NotFound, ApiError("NOT_FOUND", cause.message ?: "Not found"))
        }
        exception<IllegalArgumentException> { call, cause ->
            call.respond(HttpStatusCode.BadRequest, ApiError("BAD_REQUEST", cause.message ?: "Invalid request"))
        }
    }

    routing {
        route("/api/v1") {
            get("/health") {
                call.respond(mapOf("status" to "OK", "service" to "voltworks-backend"))
            }
            get("/stores") {
                call.respond(engine.listStores())
            }
            get("/stores/{storeId}/inventory") {
                val storeId = call.parameters["storeId"]!!
                call.respond(engine.getStoreInventory(storeId, call.request.queryParameters["sku"]))
            }
            get("/catalog/products") {
                val p = call.request.queryParameters
                call.respond(
                    engine.listProducts(
                        category = p["category"],
                        query = p["q"],
                        manufacturer = p["manufacturer"],
                        maxPricePence = p["maxPricePence"]?.toLongOrNull(),
                        inStockStoreId = p["inStockStoreId"]
                    )
                )
            }
            get("/catalog/products/{productId}") {
                call.respond(engine.getProduct(call.parameters["productId"]!!))
            }

            rateLimit(RateLimitName("checkout")) {
                post("/checkout/reserve") {
                    val req = call.receive<ReserveRequest>()
                    call.respond(HttpStatusCode.Created, engine.reserveInventory(req))
                }
                post("/checkout/pay") {
                    val req = call.receive<CheckoutPayRequest>()
                    call.respond(HttpStatusCode.Created, engine.checkoutAndPay(req))
                }
            }

            get("/orders") { call.respond(engine.listOrders()) }
            post("/orders/{orderId}/collect") {
                val orderId = call.parameters["orderId"]!!
                val req = call.receive<CollectOrderRequest>()
                val actorId = call.request.header("X-Voltworks-Actor-Id") ?: "staff-1"
                val role = parseRole(call.request.header("X-Voltworks-Role"))
                call.respond(
                    engine.advanceOrderFulfilment(
                        orderId = orderId,
                        targetStatus = FulfilmentStatus.COLLECTED,
                        expectedVersion = req.expectedVersion,
                        actorId = actorId,
                        actorRole = role,
                        collectionRefConfirmation = req.collectionReference
                    )
                )
            }

            get("/repairs") { call.respond(engine.listRepairs()) }
            post("/repairs") {
                val req = call.receive<RepairBookRequest>()
                call.respond(HttpStatusCode.Created, engine.bookRepair(req))
            }
            post("/repairs/{jobId}/quotes") {
                val jobId = call.parameters["jobId"]!!
                val req = call.receive<CreateQuoteRequest>()
                val actorId = call.request.header("X-Voltworks-Actor-Id") ?: "tech-1"
                val role = parseRole(call.request.header("X-Voltworks-Role"))
                call.respond(engine.issueRepairQuote(jobId, req, actorId, role))
            }
            post("/repairs/{jobId}/decision") {
                val jobId = call.parameters["jobId"]!!
                val req = call.receive<QuoteDecisionRequest>()
                call.respond(engine.decideRepairQuote(jobId, req))
            }
            post("/repairs/{jobId}/warranty-return") {
                val jobId = call.parameters["jobId"]!!
                val req = call.receive<WarrantyReturnRequest>()
                call.respond(HttpStatusCode.Created, engine.openWarrantyReturn(jobId, req))
            }

            get("/workshops") { call.respond(engine.listWorkshops()) }
            post("/workshops/{eventId}/hold") {
                val eventId = call.parameters["eventId"]!!
                val req = call.receive<WorkshopHoldRequest>()
                call.respond(HttpStatusCode.Created, engine.holdWorkshopSeat(eventId, req))
            }
            post("/workshops/bookings/{bookingId}/confirm") {
                call.respond(engine.confirmWorkshopBooking(call.parameters["bookingId"]!!))
            }

            post("/trade/accounts") {
                call.respond(HttpStatusCode.Created, engine.createTradeAccount(call.receive()))
            }

            get("/notifications") { call.respond(engine.listNotifications()) }
            get("/admin/audit-logs") {
                val role = parseRole(call.request.header("X-Voltworks-Role"))
                if (role !in setOf(StaffRole.MANAGER, StaffRole.FINANCE, StaffRole.ADMIN)) {
                    throw ForbiddenException("Insufficient permissions to view audit logs")
                }
                call.respond(engine.listAuditLogs())
            }
            post("/admin/stores/{storeId}/inventory/adjust") {
                val storeId = call.parameters["storeId"]!!
                val req = call.receive<StockAdjustRequest>()
                val actorId = call.request.header("X-Voltworks-Actor-Id") ?: "staff-1"
                val role = parseRole(call.request.header("X-Voltworks-Role"))
                call.respond(engine.adjustInventory(storeId, req.sku, req.physicalDelta, req.expectedVersion, req.reason, actorId, role))
            }
            post("/media/upload-intent") {
                val req = call.receive<UploadIntentRequest>()
                call.respond(storage.createValidatedUploadIntent(req))
            }
        }
    }
}

private fun parseRole(raw: String?): StaffRole =
    raw?.let { runCatching { StaffRole.valueOf(it.uppercase()) }.getOrNull() } ?: StaffRole.CUSTOMER
