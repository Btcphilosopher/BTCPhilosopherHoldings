package com.voltworks.backend.persistence

import com.voltworks.backend.domain.*
import com.voltworks.backend.payments.PaymentProviderAdapter
import com.voltworks.backend.payments.PaymentRequest
import com.voltworks.backend.payments.PaymentResult
import com.voltworks.backend.payments.SimulatedPaymentAdapter
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

class ConflictException(message: String) : RuntimeException(message)
class ForbiddenException(message: String) : RuntimeException(message)
class NotFoundException(message: String) : RuntimeException(message)

/**
 * Authoritative transactional store enforcing inventory concurrency locks, optimistic version checks,
 * idempotency keys, diagnostic credit non-duplication, BST timezone formatting, RBAC, and audit logging.
 */
class VoltworksEngine(
    private val paymentAdapter: PaymentProviderAdapter = SimulatedPaymentAdapter()
) {
    private val londonZone = ZoneId.of("Europe/London")
    private val londonFormatter = DateTimeFormatter.ofPattern("EEE d MMM yyyy, HH:mm z").withZone(londonZone)

    private val stores = ConcurrentHashMap<String, StoreDto>()
    private val products = ConcurrentHashMap<String, ProductDto>()
    private val inventory = ConcurrentHashMap<Pair<String, String>, StoreInventoryDto>()
    private val reservations = ConcurrentHashMap<String, ReservationDto>()
    private val orders = ConcurrentHashMap<String, OrderDto>()
    private val repairJobs = ConcurrentHashMap<String, RepairJobDto>()
    private val warrantyReturns = ConcurrentHashMap<String, WarrantyReturnDto>()
    private val workshopEvents = ConcurrentHashMap<String, WorkshopEventDto>()
    private val workshopBookings = ConcurrentHashMap<String, WorkshopBookingDto>()
    private val tradeAccounts = ConcurrentHashMap<String, TradeAccountDto>()
    private val notifications = mutableListOf<NotificationDto>()
    private val auditLogs = mutableListOf<AuditLogDto>()
    private val idempotencyResponses = ConcurrentHashMap<String, Any>()
    private val auditSeq = AtomicLong(1L)

    private val txLock = Any()

    init {
        seedInitialData()
    }

    fun formatLondonTime(utcIso: String): String =
        londonFormatter.format(Instant.parse(utcIso))

    fun listStores(): List<StoreDto> = stores.values.sortedBy { it.name }

    fun listProducts(
        category: String? = null,
        query: String? = null,
        manufacturer: String? = null,
        maxPricePence: Long? = null,
        inStockStoreId: String? = null
    ): List<ProductDto> {
        return products.values.filter { product ->
            val catOk = category.isNullOrBlank() || product.category.equals(category, ignoreCase = true)
            val mfgOk = manufacturer.isNullOrBlank() || product.manufacturer.equals(manufacturer, ignoreCase = true)
            val qOk = query.isNullOrBlank() ||
                product.familyName.contains(query, ignoreCase = true) ||
                product.shortSummary.contains(query, ignoreCase = true) ||
                product.variants.any { it.sku.contains(query, ignoreCase = true) }
            val priceOk = maxPricePence == null || product.variants.any { it.packPricePence <= maxPricePence }
            val stockOk = inStockStoreId.isNullOrBlank() || product.variants.any {
                (inventory[inStockStoreId to it.sku]?.availableToPromise ?: 0) > 0
            }
            catOk && mfgOk && qOk && priceOk && stockOk
        }.sortedByDescending { it.featured }
    }

    fun getProduct(productId: String): ProductDto =
        products[productId] ?: throw NotFoundException("Product $productId not found")

    fun getStoreInventory(storeId: String, sku: String? = null): List<StoreInventoryDto> =
        inventory.values.filter { it.storeId == storeId && (sku == null || it.sku == sku) }

    fun validateBasket(mode: FulfilmentMode, items: List<BasketLineRequest>): PriceBreakdownDto {
        val pairs = items.map { line ->
            val variant = findVariant(line.sku)
            variant to line.packCount
        }
        val titles = products.values.associate { it.id to it.familyName }
        return MonetaryCalculator.computeBasket(pairs, titles, mode)
    }

    fun reserveInventory(req: ReserveRequest, now: Instant = Instant.now()): List<ReservationDto> = synchronized(txLock) {
        val cacheKey = "reserve:${req.idempotencyKey}"
        @Suppress("UNCHECKED_CAST")
        (idempotencyResponses[cacheKey] as? List<ReservationDto>)?.let { return it }

        expireStaleReservationsInternal(now)

        // Verify all SKUs have sufficient ATP before mutating any row (atomic all-or-nothing)
        req.items.forEach { line ->
            val variant = findVariant(line.sku)
            require(line.packCount >= variant.minPackQuantity) {
                "Minimum pack quantity for ${line.sku} is ${variant.minPackQuantity}"
            }
            val stock = inventory[req.storeId to line.sku]
                ?: throw NotFoundException("SKU ${line.sku} is not stocked at ${req.storeId}")
            if (stock.availableToPromise < line.packCount) {
                throw ConflictException(
                    "Insufficient available-to-promise stock for ${line.sku} at ${req.storeId}: requested ${line.packCount}, available ${stock.availableToPromise}"
                )
            }
        }

        val created = req.items.map { line ->
            val key = req.storeId to line.sku
            val current = inventory.getValue(key)
            inventory[key] = current.copy(
                reservedQty = current.reservedQty + line.packCount,
                version = current.version + 1
            )
            val res = ReservationDto(
                id = "res-${UUID.randomUUID().toString().take(8)}",
                basketId = req.basketId,
                storeId = req.storeId,
                sku = line.sku,
                quantity = line.packCount,
                status = ReservationStatus.HELD,
                expiresAtIso = now.plusSeconds(900).toString()
            )
            reservations[res.id] = res
            res
        }
        idempotencyResponses[cacheKey] = created
        created
    }

    fun checkoutAndPay(req: CheckoutPayRequest, now: Instant = Instant.now()): OrderDto = synchronized(txLock) {
        val cacheKey = "pay:${req.idempotencyKey}"
        (idempotencyResponses[cacheKey] as? OrderDto)?.let { return it }

        expireStaleReservationsInternal(now)

        // Validate reservations are active and not expired
        val activeRes = req.reservationIds.map { id ->
            val r = reservations[id] ?: throw NotFoundException("Reservation $id not found")
            if (r.status == ReservationStatus.EXPIRED || Instant.parse(r.expiresAtIso).isBefore(now)) {
                throw ConflictException("Inventory reservation $id has expired. Please re-reserve stock before paying.")
            }
            if (r.status != ReservationStatus.HELD) {
                throw ConflictException("Reservation $id is in status ${r.status}")
            }
            r
        }

        val breakdown = validateBasket(req.fulfilmentMode, req.items)
        val payResult = paymentAdapter.charge(
            PaymentRequest(
                idempotencyKey = req.idempotencyKey,
                amountPence = breakdown.totalPence,
                simulateTimeout = req.simulateTimeout
            )
        )

        when (payResult) {
            is PaymentResult.TimedOut -> {
                throw ConflictException("PAYMENT_TIMEOUT: ${payResult.reason}")
            }
            is PaymentResult.Failed -> {
                throw IllegalArgumentException("PAYMENT_FAILED: ${payResult.reason}")
            }
            is PaymentResult.Succeeded -> {
                val orderId = "ORD-${UUID.randomUUID().toString().take(8).uppercase()}"
                val store = stores[req.storeId] ?: throw NotFoundException("Store ${req.storeId} not found")
                val fulfilmentStatus = if (req.simulateFulfilmentError) {
                    FulfilmentStatus.FULFILMENT_ERROR
                } else {
                    FulfilmentStatus.ORDER_ACCEPTED
                }
                val orderStatus = if (req.simulateFulfilmentError) {
                    OrderStatus.NEEDS_RECONCILIATION
                } else {
                    OrderStatus.ACCEPTED
                }

                // Confirm reservations & deduct physical stock on handover (keep reserved until collected/dispatched)
                activeRes.forEach { res ->
                    reservations[res.id] = res.copy(status = ReservationStatus.CONFIRMED)
                }

                val collectionRef = if (req.fulfilmentMode == FulfilmentMode.CLICK_AND_COLLECT) {
                    "VW-${orderId.takeLast(6)}"
                } else null

                val order = OrderDto(
                    id = orderId,
                    storeId = req.storeId,
                    customerEmail = req.customerEmail,
                    fulfilmentMode = req.fulfilmentMode,
                    orderStatus = orderStatus,
                    paymentStatus = PaymentStatus.SUCCEEDED,
                    fulfilmentStatus = fulfilmentStatus,
                    collectionReference = collectionRef,
                    estimatedReadyIso = now.plusSeconds(store.collectionLeadMinutes * 60L).toString(),
                    subtotalExVatPence = breakdown.subtotalExVatPence,
                    vatPence = breakdown.vatPence,
                    deliveryFeePence = breakdown.deliveryFeePence,
                    totalPence = breakdown.totalPence,
                    items = breakdown.lines,
                    createdAtIso = now.toString()
                )
                orders[order.id] = order
                idempotencyResponses[cacheKey] = order
                emitNotification(
                    previewTitle = "Order update",
                    body = if (orderStatus == OrderStatus.NEEDS_RECONCILIATION)
                        "Payment confirmed for $orderId; fulfilment queued for store reconciliation."
                    else
                        "Order $orderId accepted. Preparing at ${store.name}."
                )
                order
            }
        }
    }

    fun advanceOrderFulfilment(
        orderId: String,
        targetStatus: FulfilmentStatus,
        expectedVersion: Int,
        actorId: String,
        actorRole: StaffRole,
        collectionRefConfirmation: String? = null
    ): OrderDto = synchronized(txLock) {
        requireRole(actorRole, setOf(StaffRole.RETAIL_STAFF, StaffRole.MANAGER, StaffRole.ADMIN))
        val order = orders[orderId] ?: throw NotFoundException("Order $orderId not found")
        if (order.version != expectedVersion) {
            throw ConflictException("Order $orderId modified concurrently (expected v$expectedVersion, actual v${order.version})")
        }
        if (targetStatus == FulfilmentStatus.COLLECTED) {
            require(order.fulfilmentStatus == FulfilmentStatus.READY_FOR_COLLECTION) {
                "Order must be READY_FOR_COLLECTION before handover"
            }
            require(collectionRefConfirmation != null && collectionRefConfirmation.equals(order.collectionReference, ignoreCase = true)) {
                "Verified collection reference mismatch"
            }
            // Deduct physical & reserved stock on actual handover
            order.items.forEach { line ->
                val key = order.storeId to line.sku
                val stock = inventory[key]
                if (stock != null) {
                    inventory[key] = stock.copy(
                        physicalQty = (stock.physicalQty - line.packCount).coerceAtLeast(0),
                        reservedQty = (stock.reservedQty - line.packCount).coerceAtLeast(0),
                        version = stock.version + 1
                    )
                }
            }
        }
        val updated = order.copy(
            fulfilmentStatus = targetStatus,
            orderStatus = if (targetStatus == FulfilmentStatus.COLLECTED || targetStatus == FulfilmentStatus.DELIVERED) OrderStatus.COMPLETED else order.orderStatus,
            handoverVerifiedBy = if (targetStatus == FulfilmentStatus.COLLECTED) actorId else order.handoverVerifiedBy,
            version = order.version + 1
        )
        orders[orderId] = updated
        recordAudit(actorId, actorRole, "FULFILMENT_${targetStatus.name}", "ORDER", orderId, "Staff fulfilment update")
        emitNotification(
            previewTitle = "Collection update",
            body = "Order $orderId status updated to ${targetStatus.name.replace('_', ' ').lowercase()}."
        )
        updated
    }

    fun bookRepair(req: RepairBookRequest): RepairJobDto = synchronized(txLock) {
        val cacheKey = "repair:${req.idempotencyKey}"
        (idempotencyResponses[cacheKey] as? RepairJobDto)?.let { return it }
        require(req.dataConsentAccepted) { "Customer consent for specified data operations is required." }

        val job = RepairJobDto(
            id = "REP-${UUID.randomUUID().toString().take(6).uppercase()}",
            customerName = req.customerName,
            customerContact = req.customerContact,
            storeId = req.storeId,
            category = req.category,
            deviceModel = req.deviceModel,
            serialNumber = req.serialNumber,
            reportedFault = req.reportedFault,
            appointmentSlotIso = req.appointmentSlotIso,
            status = RepairStatus.BOOKED,
            diagnosticFeePence = MonetaryCalculator.DIAGNOSTIC_ASSESSMENT_FEE_PENCE,
            diagnosticPaid = true,
            diagnosticCredited = false,
            approvedQuoteVersion = null,
            approvedRemainingPence = null,
            controlledAccessMode = req.controlledAccessMode,
            dataConsentAccepted = true,
            intakeConditionNotes = null,
            suppliedAccessories = null,
            finalTestRecord = null,
            collectionReceiptRef = null,
            warrantyMonths = 6,
            progressNotes = listOf("Intake slot reserved; £29.00 diagnostic assessment paid.")
        )
        repairJobs[job.id] = job
        idempotencyResponses[cacheKey] = job
        emitNotification("Repair update", "Repair intake slot booked (${job.id}).")
        job
    }

    fun issueRepairQuote(
        jobId: String,
        req: CreateQuoteRequest,
        actorId: String,
        actorRole: StaffRole
    ): RepairJobDto = synchronized(txLock) {
        requireRole(actorRole, setOf(StaffRole.TECHNICIAN, StaffRole.MANAGER, StaffRole.ADMIN))
        val job = repairJobs[jobId] ?: throw NotFoundException("Repair job $jobId not found")
        if (job.version != req.expectedVersion) {
            throw ConflictException("Repair job $jobId version conflict (expected ${req.expectedVersion}, actual ${job.version})")
        }
        val nextVersion = (job.quotes.maxOfOrNull { it.quoteVersion } ?: 0) + 1
        val (credit, remaining) = MonetaryCalculator.calculateRepairQuoteCredit(
            quoteTotalPence = req.totalPence,
            diagnosticPaid = job.diagnosticPaid,
            diagnosticAlreadyCredited = job.diagnosticCredited,
            diagnosticFeePence = job.diagnosticFeePence
        )
        val supersededQuotes = job.quotes.map {
            if (it.customerDecision == QuoteDecision.PENDING || (req.materialChange && it.customerDecision == QuoteDecision.APPROVED)) {
                it.copy(customerDecision = QuoteDecision.SUPERSEDED)
            } else it
        }
        val newQuote = RepairQuoteDto(
            id = "QT-${UUID.randomUUID().toString().take(6).uppercase()}",
            repairJobId = jobId,
            quoteVersion = nextVersion,
            totalPence = req.totalPence,
            diagnosticCreditPence = credit,
            remainingPence = remaining,
            partsGrade = req.partsGrade,
            partsLimitations = req.partsLimitations,
            scopeSummary = req.scopeSummary,
            materialChange = req.materialChange,
            customerDecision = QuoteDecision.PENDING,
            createdAtIso = Instant.now().toString()
        )
        val updated = job.copy(
            status = RepairStatus.AWAITING_APPROVAL,
            // Material change invalidates prior approval and requires renewed customer approval
            approvedQuoteVersion = if (req.materialChange) null else job.approvedQuoteVersion,
            approvedRemainingPence = if (req.materialChange) null else job.approvedRemainingPence,
            quotes = supersededQuotes + newQuote,
            progressNotes = job.progressNotes + "Quote v$nextVersion issued (£${req.totalPence / 100}.${(req.totalPence % 100).toString().padStart(2, '0')}).",
            version = job.version + 1
        )
        repairJobs[jobId] = updated
        recordAudit(actorId, actorRole, "ISSUE_QUOTE_V$nextVersion", "REPAIR_JOB", jobId, req.scopeSummary)
        emitNotification("Repair quote ready", "A repair quote update is ready for your review.")
        updated
    }

    fun decideRepairQuote(jobId: String, req: QuoteDecisionRequest): RepairJobDto = synchronized(txLock) {
        val cacheKey = "quote-decide:$jobId:${req.idempotencyKey}"
        (idempotencyResponses[cacheKey] as? RepairJobDto)?.let { return it }

        val job = repairJobs[jobId] ?: throw NotFoundException("Repair job $jobId not found")
        if (job.version != req.expectedVersion) {
            throw ConflictException("Version mismatch on $jobId")
        }
        val quote = job.quotes.firstOrNull { it.quoteVersion == req.quoteVersion }
            ?: throw NotFoundException("Quote v${req.quoteVersion} not found")
        require(quote.customerDecision == QuoteDecision.PENDING) {
            "Quote v${req.quoteVersion} is already ${quote.customerDecision}"
        }

        val updatedQuotes = job.quotes.map {
            if (it.quoteVersion == req.quoteVersion) {
                it.copy(customerDecision = if (req.approve) QuoteDecision.APPROVED else QuoteDecision.DECLINED)
            } else it
        }
        val updated = if (req.approve) {
            val (credit, remaining) = MonetaryCalculator.calculateRepairQuoteCredit(
                quoteTotalPence = quote.totalPence,
                diagnosticPaid = job.diagnosticPaid,
                diagnosticAlreadyCredited = job.diagnosticCredited,
                diagnosticFeePence = job.diagnosticFeePence
            )
            job.copy(
                status = RepairStatus.REPAIRING,
                diagnosticCredited = job.diagnosticCredited || credit > 0L,
                approvedQuoteVersion = quote.quoteVersion,
                approvedRemainingPence = remaining,
                quotes = updatedQuotes,
                progressNotes = job.progressNotes + "Customer approved quote v${quote.quoteVersion}. Remaining balance £${remaining / 100}.${(remaining % 100).toString().padStart(2, '0')}.",
                version = job.version + 1
            )
        } else {
            job.copy(
                status = RepairStatus.DECLINED_QUOTE,
                quotes = updatedQuotes,
                progressNotes = job.progressNotes + "Customer declined quote v${quote.quoteVersion}. Diagnostic-only fee retained.",
                version = job.version + 1
            )
        }
        repairJobs[jobId] = updated
        idempotencyResponses[cacheKey] = updated
        recordAudit("customer", StaffRole.CUSTOMER, if (req.approve) "QUOTE_APPROVED" else "QUOTE_DECLINED", "REPAIR_JOB", jobId, "Quote v${req.quoteVersion}")
        updated
    }

    fun openWarrantyReturn(jobId: String, req: WarrantyReturnRequest): WarrantyReturnDto = synchronized(txLock) {
        val cacheKey = "warranty:$jobId:${req.idempotencyKey}"
        (idempotencyResponses[cacheKey] as? WarrantyReturnDto)?.let { return it }

        val job = repairJobs[jobId] ?: throw NotFoundException("Repair job $jobId not found")
        repairJobs[jobId] = job.copy(
            status = RepairStatus.WARRANTY_RETURN,
            progressNotes = job.progressNotes + "Warranty return routed for bench assessment (no automatic diagnostic charge).",
            version = job.version + 1
        )
        val wr = WarrantyReturnDto(
            id = "WR-${UUID.randomUUID().toString().take(6).uppercase()}",
            originalJobId = jobId,
            reportedRecurringFault = req.reportedRecurringFault,
            outcome = WarrantyOutcome.WARRANTY_ASSESSMENT,
            freshDiagnosticCharged = false, // Never auto-charge on potentially covered return
            resolutionNotes = "Routed to technician for parts & workmanship guarantee check (${job.warrantyMonths} months; supplements statutory rights).",
            createdAtIso = Instant.now().toString()
        )
        warrantyReturns[wr.id] = wr
        idempotencyResponses[cacheKey] = wr
        wr
    }

    fun listWorkshops(): List<WorkshopEventDto> = workshopEvents.values.sortedBy { it.startsAtUtcIso }

    fun holdWorkshopSeat(
        eventId: String,
        req: WorkshopHoldRequest,
        now: Instant = Instant.now(),
        holdTtlSeconds: Long = 600L
    ): WorkshopBookingDto = synchronized(txLock) {
        val cacheKey = "ws-hold:${req.idempotencyKey}"
        (idempotencyResponses[cacheKey] as? WorkshopBookingDto)?.let { return it }

        expireStaleWorkshopHoldsInternal(now)

        val evt = workshopEvents[eventId] ?: throw NotFoundException("Workshop event $eventId not found")
        val booking = if (evt.availableSeats > 0) {
            workshopEvents[eventId] = evt.copy(heldSeats = evt.heldSeats + 1, version = evt.version + 1)
            WorkshopBookingDto(
                id = "WB-${UUID.randomUUID().toString().take(6).uppercase()}",
                eventId = eventId,
                attendeeName = req.attendeeName,
                attendeeEmail = req.attendeeEmail,
                status = WorkshopBookingStatus.HELD,
                holdExpiresAtIso = now.plusSeconds(holdTtlSeconds).toString(),
                attended = false
            )
        } else {
            WorkshopBookingDto(
                id = "WB-${UUID.randomUUID().toString().take(6).uppercase()}",
                eventId = eventId,
                attendeeName = req.attendeeName,
                attendeeEmail = req.attendeeEmail,
                status = WorkshopBookingStatus.WAITLISTED,
                holdExpiresAtIso = null,
                attended = false
            )
        }
        workshopBookings[booking.id] = booking
        idempotencyResponses[cacheKey] = booking
        booking
    }

    fun confirmWorkshopBooking(bookingId: String, now: Instant = Instant.now()): WorkshopBookingDto = synchronized(txLock) {
        expireStaleWorkshopHoldsInternal(now)
        val booking = workshopBookings[bookingId] ?: throw NotFoundException("Booking $bookingId not found")
        if (booking.status == WorkshopBookingStatus.EXPIRED) {
            throw ConflictException("Seat hold $bookingId has expired.")
        }
        if (booking.status != WorkshopBookingStatus.HELD) {
            throw ConflictException("Booking $bookingId cannot be confirmed from status ${booking.status}")
        }
        val evt = workshopEvents.getValue(booking.eventId)
        workshopEvents[evt.id] = evt.copy(
            heldSeats = (evt.heldSeats - 1).coerceAtLeast(0),
            confirmedSeats = evt.confirmedSeats + 1,
            version = evt.version + 1
        )
        val confirmed = booking.copy(status = WorkshopBookingStatus.CONFIRMED, holdExpiresAtIso = null)
        workshopBookings[bookingId] = confirmed
        confirmed
    }

    fun createTradeAccount(req: TradeAccountRequest): TradeAccountDto = synchronized(txLock) {
        val acc = TradeAccountDto(
            id = "TRD-${UUID.randomUUID().toString().take(6).uppercase()}",
            organisationName = req.organisationName,
            companyRegNo = req.companyRegNo,
            vatNumber = req.vatNumber,
            creditApproved = false, // Trade account creation NEVER automatically grants credit
            creditLimitPence = 0L,
            paymentTermsDays = 0
        )
        tradeAccounts[acc.id] = acc
        acc
    }

    fun adjustInventory(
        storeId: String,
        sku: String,
        physicalDelta: Int,
        expectedVersion: Int,
        reason: String,
        actorId: String,
        actorRole: StaffRole
    ): StoreInventoryDto = synchronized(txLock) {
        requireRole(actorRole, setOf(StaffRole.RETAIL_STAFF, StaffRole.MANAGER, StaffRole.ADMIN))
        val key = storeId to sku
        val current = inventory[key] ?: throw NotFoundException("Inventory record $storeId / $sku not found")
        if (current.version != expectedVersion) {
            throw ConflictException("Inventory version conflict for $sku at $storeId")
        }
        val newPhysical = current.physicalQty + physicalDelta
        require(newPhysical >= current.reservedQty + current.quarantinedQty) {
            "Physical quantity cannot drop below reserved + quarantined"
        }
        val updated = current.copy(physicalQty = newPhysical, version = current.version + 1)
        inventory[key] = updated
        recordAudit(actorId, actorRole, "STOCK_ADJUSTMENT", "STORE_INVENTORY", "$storeId:$sku", reason)
        updated
    }

    fun runReconciliationSweep(now: Instant = Instant.now()): Int = synchronized(txLock) {
        expireStaleReservationsInternal(now) + expireStaleWorkshopHoldsInternal(now)
    }

    fun listNotifications(): List<NotificationDto> = synchronized(txLock) { notifications.toList() }
    fun listAuditLogs(): List<AuditLogDto> = synchronized(txLock) { auditLogs.toList() }
    fun listOrders(): List<OrderDto> = orders.values.toList()
    fun listRepairs(): List<RepairJobDto> = repairJobs.values.toList()

    private fun expireStaleReservationsInternal(now: Instant): Int {
        var expired = 0
        reservations.values.filter {
            it.status == ReservationStatus.HELD && Instant.parse(it.expiresAtIso).isBefore(now)
        }.forEach { res ->
            reservations[res.id] = res.copy(status = ReservationStatus.EXPIRED)
            val key = res.storeId to res.sku
            inventory[key]?.let { stock ->
                inventory[key] = stock.copy(
                    reservedQty = (stock.reservedQty - res.quantity).coerceAtLeast(0),
                    version = stock.version + 1
                )
            }
            expired++
        }
        return expired
    }

    private fun expireStaleWorkshopHoldsInternal(now: Instant): Int {
        var expired = 0
        workshopBookings.values.filter {
            it.status == WorkshopBookingStatus.HELD &&
                it.holdExpiresAtIso != null &&
                Instant.parse(it.holdExpiresAtIso).isBefore(now)
        }.forEach { b ->
            workshopBookings[b.id] = b.copy(status = WorkshopBookingStatus.EXPIRED)
            workshopEvents[b.eventId]?.let { evt ->
                workshopEvents[evt.id] = evt.copy(
                    heldSeats = (evt.heldSeats - 1).coerceAtLeast(0),
                    version = evt.version + 1
                )
            }
            expired++
        }
        return expired
    }

    private fun findVariant(sku: String): ProductVariantDto =
        products.values.flatMap { it.variants }.firstOrNull { it.sku == sku }
            ?: throw NotFoundException("SKU $sku not found")

    private fun requireRole(actorRole: StaffRole, allowed: Set<StaffRole>) {
        if (actorRole !in allowed) {
            throw ForbiddenException("Role $actorRole is not authorised for this operation")
        }
    }

    private fun emitNotification(previewTitle: String, body: String) {
        notifications.add(
            0,
            NotificationDto(
                id = "notif-${UUID.randomUUID().toString().take(8)}",
                channel = "IN_APP",
                previewTitle = previewTitle,
                body = body,
                deliveryStatus = NotificationDeliveryStatus.DELIVERED,
                createdAtIso = Instant.now().toString()
            )
        )
    }

    private fun recordAudit(actorId: String, actorRole: StaffRole, action: String, entityType: String, entityId: String, reason: String) {
        auditLogs.add(
            0,
            AuditLogDto(
                id = auditSeq.getAndIncrement(),
                actorId = actorId,
                actorRole = actorRole,
                action = action,
                entityType = entityType,
                entityId = entityId,
                reason = reason,
                createdAtIso = Instant.now().toString()
            )
        )
    }

    private fun seedInitialData() {
        listOf(
            StoreDto("store-sheffield", "Sheffield flagship", "Unit 1, Meadowhall Way", "Sheffield", "S9 1EP", "0114 555 0140", "sheffield@voltworks.co.uk", mapOf("Mon–Fri" to "08:30–19:00", "Sat" to "09:00–18:00", "Sun" to "10:30–16:30"), listOf("1-Hour Click & Collect", "ESD Repair Bench", "Maker Workshop Studio", "Building Centre Trade Counter"), "Present your 8-character collection reference at the Click & Collect desk.", true, true, true, 60, 30),
            StoreDto("store-manchester", "Manchester Northern Quarter", "42 Oldham Street", "Manchester", "M4 1LE", "0161 555 0192", "manchester@voltworks.co.uk", mapOf("Mon–Fri" to "09:00–18:30", "Sat" to "09:30–18:00", "Sun" to "11:00–16:30"), listOf("1-Hour Click & Collect", "ESD Repair Bench", "Soldering Bar"), "Report to the Ground Floor Pickup Counter.", true, true, false, 60, 20),
            StoreDto("store-bristol", "Bristol Harbourside", "18 Anchor Road", "Bristol", "BS1 5TT", "0117 555 0118", "bristol@voltworks.co.uk", mapOf("Mon–Fri" to "09:00–18:00", "Sat" to "09:00–17:30", "Sun" to "11:00–16:00"), listOf("2-Hour Click & Collect", "Robotics Workshop Lab", "Repair Intake Desk"), "Collect from Mezzanine Workshop Reception.", true, true, true, 90, 15),
            StoreDto("store-london", "London Clerkenwell", "75 St John Street", "London", "EC1M 4AN", "020 7946 0821", "clerkenwell@voltworks.co.uk", mapOf("Mon–Fri" to "08:00–19:30", "Sat" to "09:30–18:00", "Sun" to "Closed"), listOf("1-Hour Click & Collect", "Trade & Prototyping Desk"), "Use the Express Trade & Collect bay.", true, false, true, 45, 35)
        ).forEach { stores[it.id] = it }

        val p1 = ProductDto(
            id = "prod-soldering-station",
            familyName = "Precision Soldering Station",
            category = "Tools & Repair",
            manufacturer = "Voltworks Pro",
            shortSummary = "60 W digital ESD-safe soldering station with 50–480 °C closed-loop control.",
            description = "Engineered for clean lead-free bench work with OLED readout, brass cleaner, and BS 1363 UK mains lead.",
            warrantyMonths = 24,
            includedContents = listOf("60 W digital control unit", "ESD-safe 24 V iron", "Weighted stand with brass wool", "1.5 m UK BS 1363 lead"),
            documentation = listOf(mapOf("title" to "User Manual (PDF)", "url" to "https://docs.voltworks.example/vw-s60.pdf")),
            imageKeys = listOf("img_prod_soldering"),
            featured = true,
            variants = listOf(
                ProductVariantDto("VW-SOL-060-UK", "prod-soldering-station", "60 W Station (UK Plug)", 1, 1, 12999, 12999, 2000, "145 x 110 x 92 mm", "230V AC / 24V Iron", "230 V AC", listOf("Lead-free SAC305", "T18 Tips"), mapOf("Power" to "60 W", "Temp Range" to "50–480 °C", "Stability" to "±2 °C")),
                ProductVariantDto("VW-SOL-TIP-5PK", "prod-soldering-station", "T18 Tip 5-Pack", 5, 1, 450, 2250, 2000, "42 x 6.5 mm", "T18 Sleeve", "Passive", listOf("VW-SOL-060-UK"), mapOf("Pack Size" to "5 tips", "Unit Price" to "£4.50 / tip"))
            ),
            compatibility = listOf(CompatibilityRuleDto("VW-SOL-TIP-5PK", "T18 Tip 5-Pack", "CONSUMABLE", "T18 sleeve OD 6.5 mm matches VW-SOL-060-UK handpiece.", "Voltworks Pro Datasheet v2.1 §4"))
        )
        val p2 = ProductDto(
            id = "prod-mcu-starter",
            familyName = "Microcontroller Starter Kit",
            category = "Components",
            manufacturer = "Northbridge Silicon",
            shortSummary = "RP2350 dual-core dev board with breadboard, OLED, and jumper set.",
            description = "3.3 V ARM/RISC-V prototyping kit with USB-C, 400-tie breadboard, OLED, and BME280 sensor.",
            warrantyMonths = 12,
            includedContents = listOf("RP2350 Dev Board", "400-tie breadboard", "65x jumper wires", "0.96 in OLED"),
            documentation = listOf(mapOf("title" to "Pinout Schematic", "url" to "https://docs.voltworks.example/mcu.pdf")),
            imageKeys = listOf("img_hero_makers"),
            featured = true,
            variants = listOf(ProductVariantDto("VW-MCU-RP2350", "prod-mcu-starter", "Starter Kit (USB-C)", 1, 1, 3999, 3999, 2000, "180 x 120 x 45 mm", "USB-C / I2C / SPI", "3.3 V Logic", listOf("MicroPython", "C/C++ SDK"), mapOf("CPU" to "Dual Cortex-M33 @ 150 MHz", "Flash" to "4 MB"), tiers = listOf(QuantityTierDto(5, 3699)))),
            compatibility = listOf(CompatibilityRuleDto("VW-RES-10K-10PK", "Metal Film Resistor 10kΩ (10-Pack)", "ACCESSORY", "0.6 mm axial leads fit the 400-tie breadboard; 10 kΩ matches 3.3 V GPIO pull-up spec.", "Northbridge AppNote AN-04"))
        )
        val p3 = ProductDto(
            id = "prod-multimeter",
            familyName = "Digital Multimeter",
            category = "Tools & Repair",
            manufacturer = "CalibrateUK",
            shortSummary = "True-RMS 6000-count CAT III 600 V bench & field multimeter.",
            description = "Auto-ranging AC/DC voltage, capacitance, continuity buzzer, diode test, and silicone test leads.",
            warrantyMonths = 36,
            includedContents = listOf("6000-count DMM", "CAT III 600 V probe leads", "Type-K thermocouple"),
            documentation = listOf(mapOf("title" to "CAT III Safety Sheet", "url" to "https://docs.voltworks.example/dmm.pdf")),
            imageKeys = listOf("img_prod_multimeter"),
            featured = true,
            variants = listOf(ProductVariantDto("VW-DMM-6000", "prod-multimeter", "CAT III 600 V Meter", 1, 1, 5999, 5999, 2000, "175 x 81 x 48 mm", "4 mm Shrouded Banana", "3 V DC (2x AA)", listOf("True-RMS"), mapOf("Counts" to "6000", "Max Voltage" to "600 V")))
        )
        val p4 = ProductDto(
            id = "prod-robotics-kit",
            familyName = "Robotics Explorer Kit",
            category = "Robotics",
            manufacturer = "Albion Robotics",
            shortSummary = "4-DOF articulated robotic arm kit with metal-gear servos and PWM driver.",
            description = "Precision 4-axis desktop robotic arm with PCA9685 I2C driver and 5 V 4 A UK PSU.",
            warrantyMonths = 12,
            includedContents = listOf("Anodised frame", "4x MG996R servos", "PCA9685 I2C driver", "5 V 4 A UK PSU"),
            documentation = listOf(mapOf("title" to "I2C Manual", "url" to "https://docs.voltworks.example/arm.pdf")),
            imageKeys = listOf("img_hero_makers"),
            featured = true,
            variants = listOf(ProductVariantDto("VW-ROB-ARM4", "prod-robotics-kit", "4-DOF Desktop Arm Kit", 1, 1, 14999, 14999, 2000, "240 x 180 x 310 mm", "I2C (PCA9685)", "5 V DC", listOf("Raspberry Pi", "RP2350"), mapOf("Axes" to "4-DOF", "Payload" to "180 g"))),
            compatibility = listOf(CompatibilityRuleDto("VW-MCU-RP2350", "Microcontroller Starter Kit", "PLATFORM_MATCH", "PCA9685 accepts 3.3 V I2C levels directly from RP2350 GPIO.", "Albion Robotics Spec §2.3"))
        )
        val p5 = ProductDto(
            id = "prod-resistor-pack",
            familyName = "Metal Film Resistor 10kΩ Pack",
            category = "Components",
            manufacturer = "Yageo Europe",
            shortSummary = "10-piece 0.25 W 1% tolerance 10 kΩ axial resistor pack (£0.15/pc).",
            description = "Low-noise 1% precision axial resistors for breadboard pull-ups and dividers.",
            warrantyMonths = 12,
            includedContents = listOf("10x 10 kΩ 0.25 W 1% axial resistors"),
            documentation = listOf(mapOf("title" to "MFR-25 Datasheet", "url" to "https://docs.voltworks.example/mfr25.pdf")),
            imageKeys = listOf("img_hero_makers"),
            featured = false,
            variants = listOf(ProductVariantDto("VW-RES-10K-10PK", "prod-resistor-pack", "10-Piece Pack (10 kΩ)", 10, 1, 15, 150, 2000, "6.3 x 2.3 mm", "Through-Hole Axial", "Max 250 V", listOf("Breadboard", "PCB"), mapOf("Pack Quantity" to "10 pcs", "Unit Price" to "£0.15"), tiers = listOf(QuantityTierDto(5, 125), QuantityTierDto(20, 100))))
        )
        listOf(p1, p2, p3, p4, p5).forEach { products[it.id] = it }

        listOf(
            StoreInventoryDto("store-sheffield", "VW-SOL-060-UK", 6, 1, 0, 4, Instant.now().plusSeconds(172800).toString()),
            StoreInventoryDto("store-sheffield", "VW-SOL-TIP-5PK", 18, 0, 1, 0, null),
            StoreInventoryDto("store-sheffield", "VW-MCU-RP2350", 14, 2, 0, 10, Instant.now().plusSeconds(259200).toString()),
            StoreInventoryDto("store-sheffield", "VW-DMM-6000", 8, 0, 0, 0, null),
            StoreInventoryDto("store-sheffield", "VW-ROB-ARM4", 1, 0, 0, 3, Instant.now().plusSeconds(345600).toString()),
            StoreInventoryDto("store-sheffield", "VW-RES-10K-10PK", 45, 0, 0, 0, null),
            StoreInventoryDto("store-manchester", "VW-SOL-060-UK", 4, 0, 0, 0, null),
            StoreInventoryDto("store-bristol", "VW-ROB-ARM4", 2, 0, 0, 0, null)
        ).forEach { inventory[it.storeId to it.sku] = it }

        val evt1Utc = "2027-06-12T10:00:00Z" // BST (11:00 BST)
        val evt2Utc = "2027-06-19T13:00:00Z" // BST (14:00 BST) - 1 seat left
        val evt3Utc = "2027-01-30T18:00:00Z" // GMT (18:00 GMT)
        workshopEvents["evt-soldering-shef-1"] = WorkshopEventDto("evt-soldering-shef-1", "ws-soldering", "Soldering basics", "Hands-on through-hole & SMD soldering.", "None", "ESD mat, VW-SOL-060 station, solder supplied", "Ages 14+", "Full refund up to 48h prior", "store-sheffield", "Hannah Patel", "Maker Studio A", evt1Utc, formatLondonTime(evt1Utc), 120, 3500, 8, 0, 5)
        workshopEvents["evt-robot-bris-1"] = WorkshopEventDto("evt-robot-bris-1", "ws-robot", "Build your first robot", "Assemble and program a 4-DOF/rover robot.", "Basic laptop use", "Robot kit & bench tools supplied", "Ages 12+", "Full refund up to 48h prior", "store-bristol", "Callum Reid", "Robotics Lab", evt2Utc, formatLondonTime(evt2Utc), 180, 5500, 6, 0, 5)
        workshopEvents["evt-mcu-manc-1"] = WorkshopEventDto("evt-mcu-manc-1", "ws-mcu", "Microcontroller projects", "I2C sensors & MicroPython displays.", "Laptop with USB-C", "RP2350 starter kit provided", "Ages 16+", "Full refund up to 48h prior", "store-manchester", "Priya Nair", "NQ Workshop Room", evt3Utc, formatLondonTime(evt3Utc), 150, 4000, 10, 0, 4)
    }
}
