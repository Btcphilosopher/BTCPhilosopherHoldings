package com.voltworks.backend.storage

import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class UploadIntentRequest(
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val linkedEntityType: String,
    val linkedEntityId: String
)

@Serializable
data class UploadIntentResponse(
    val attachmentId: String,
    val objectKey: String,
    val signedUploadUrl: String,
    val maxBytes: Long
)

class ObjectStorageService(
    private val endpoint: String = System.getenv("OBJECT_STORAGE_ENDPOINT") ?: "http://localhost:9000",
    private val bucket: String = System.getenv("OBJECT_STORAGE_BUCKET") ?: "voltworks-media"
) {
    private val allowedMimeTypes = setOf("image/jpeg", "image/png", "image/webp", "application/pdf")
    private val maxUploadBytes = 10L * 1024L * 1024L // 10 MiB

    fun createValidatedUploadIntent(req: UploadIntentRequest): UploadIntentResponse {
        require(req.mimeType in allowedMimeTypes) {
            "Unsupported media type: ${req.mimeType}. Allowed: $allowedMimeTypes"
        }
        require(req.sizeBytes in 1..maxUploadBytes) {
            "File size ${req.sizeBytes} outside allowed 1B..10MiB range"
        }
        val sanitizedName = req.fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(80)
        val attachmentId = "att-${UUID.randomUUID().toString().take(8)}"
        val objectKey = "protected/${req.linkedEntityType.lowercase()}/${req.linkedEntityId}/$attachmentId-$sanitizedName"
        val signedUrl = "$endpoint/$bucket/$objectKey?X-Voltworks-Policy=private-presigned&maxBytes=$maxUploadBytes"
        return UploadIntentResponse(
            attachmentId = attachmentId,
            objectKey = objectKey,
            signedUploadUrl = signedUrl,
            maxBytes = maxUploadBytes
        )
    }
}
