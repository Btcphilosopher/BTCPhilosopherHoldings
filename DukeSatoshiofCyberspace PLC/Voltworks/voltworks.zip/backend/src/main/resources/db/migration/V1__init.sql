-- Voltworks Authoritative PostgreSQL Schema (V1)
-- All monetary columns are integer minor units (GBP pence).
-- Timestamps use TIMESTAMPTZ (UTC stored; Europe/London BST/GMT handled in application layer).

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE stores (
    id                      VARCHAR(64) PRIMARY KEY,
    name                    VARCHAR(160) NOT NULL,
    address_line            VARCHAR(255) NOT NULL,
    city                    VARCHAR(100) NOT NULL,
    postcode                VARCHAR(20) NOT NULL,
    phone                   VARCHAR(40) NOT NULL,
    email                   VARCHAR(160) NOT NULL,
    opening_hours_json      JSONB NOT NULL,
    facilities_json         JSONB NOT NULL,
    collection_instructions TEXT NOT NULL,
    supports_repairs        BOOLEAN NOT NULL DEFAULT TRUE,
    supports_workshops      BOOLEAN NOT NULL DEFAULT TRUE,
    supports_trade_desk     BOOLEAN NOT NULL DEFAULT FALSE,
    collection_lead_minutes INT NOT NULL DEFAULT 60,
    collection_cap_per_hour INT NOT NULL DEFAULT 25,
    version                 INT NOT NULL DEFAULT 1,
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE users (
    id                      VARCHAR(64) PRIMARY KEY,
    email                   VARCHAR(200) UNIQUE NOT NULL,
    full_name               VARCHAR(160) NOT NULL,
    phone                   VARCHAR(40),
    password_hash           TEXT NOT NULL,
    role                    VARCHAR(40) NOT NULL DEFAULT 'CUSTOMER',
    -- CUSTOMER, RETAIL_STAFF, TECHNICIAN, WORKSHOP_ORGANISER, MANAGER, FINANCE, ADMIN
    preferred_store_id      VARCHAR(64) REFERENCES stores(id),
    biometric_enabled       BOOLEAN NOT NULL DEFAULT FALSE,
    push_opt_in             BOOLEAN NOT NULL DEFAULT TRUE,
    email_opt_in            BOOLEAN NOT NULL DEFAULT TRUE,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE products (
    id                      VARCHAR(64) PRIMARY KEY,
    family_name             VARCHAR(180) NOT NULL,
    category                VARCHAR(60) NOT NULL,
    manufacturer            VARCHAR(120) NOT NULL,
    short_summary           TEXT NOT NULL,
    description             TEXT NOT NULL,
    warranty_months         INT NOT NULL DEFAULT 12,
    included_contents_json  JSONB NOT NULL,
    documentation_json      JSONB NOT NULL,
    image_keys_json         JSONB NOT NULL,
    featured                BOOLEAN NOT NULL DEFAULT FALSE,
    version                 INT NOT NULL DEFAULT 1,
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE product_variants (
    sku                     VARCHAR(64) PRIMARY KEY,
    product_id              VARCHAR(64) NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    variant_label           VARCHAR(140) NOT NULL,
    pack_quantity           INT NOT NULL DEFAULT 1,
    min_pack_quantity       INT NOT NULL DEFAULT 1,
    unit_price_pence        BIGINT NOT NULL CHECK (unit_price_pence >= 0),
    pack_price_pence        BIGINT NOT NULL CHECK (pack_price_pence >= 0),
    vat_rate_bps            INT NOT NULL DEFAULT 2000, -- 20.00% UK standard VAT
    dimensions_mm           VARCHAR(100),
    interface_type          VARCHAR(100),
    operating_voltage       VARCHAR(80),
    supported_platforms_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    specs_json              JSONB NOT NULL,
    active                  BOOLEAN NOT NULL DEFAULT TRUE,
    version                 INT NOT NULL DEFAULT 1
);

CREATE TABLE quantity_pricing_tiers (
    id                      SERIAL PRIMARY KEY,
    sku                     VARCHAR(64) NOT NULL REFERENCES product_variants(sku) ON DELETE CASCADE,
    min_packs               INT NOT NULL CHECK (min_packs >= 1),
    pack_price_pence        BIGINT NOT NULL CHECK (pack_price_pence >= 0),
    UNIQUE (sku, min_packs)
);

CREATE TABLE compatibility_rules (
    id                      SERIAL PRIMARY KEY,
    source_sku              VARCHAR(64) NOT NULL REFERENCES product_variants(sku) ON DELETE CASCADE,
    target_sku              VARCHAR(64) NOT NULL REFERENCES product_variants(sku) ON DELETE CASCADE,
    relationship_type       VARCHAR(60) NOT NULL, -- ACCESSORY, CONSUMABLE, PLATFORM_MATCH, POWER_SUPPLY
    rule_basis              TEXT NOT NULL,
    manufacturer_ref        VARCHAR(160) NOT NULL,
    UNIQUE (source_sku, target_sku)
);

CREATE TABLE store_inventory (
    store_id                VARCHAR(64) NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    sku                     VARCHAR(64) NOT NULL REFERENCES product_variants(sku) ON DELETE CASCADE,
    physical_qty            INT NOT NULL DEFAULT 0 CHECK (physical_qty >= 0),
    reserved_qty            INT NOT NULL DEFAULT 0 CHECK (reserved_qty >= 0),
    quarantined_qty         INT NOT NULL DEFAULT 0 CHECK (quarantined_qty >= 0),
    inbound_transfer_qty    INT NOT NULL DEFAULT 0 CHECK (inbound_transfer_qty >= 0),
    expected_delivery_at    TIMESTAMPTZ,
    version                 INT NOT NULL DEFAULT 1,
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (store_id, sku)
);

CREATE TABLE inventory_reservations (
    id                      VARCHAR(64) PRIMARY KEY,
    basket_id               VARCHAR(64) NOT NULL,
    order_id                VARCHAR(64),
    store_id                VARCHAR(64) NOT NULL REFERENCES stores(id),
    sku                     VARCHAR(64) NOT NULL REFERENCES product_variants(sku),
    quantity                INT NOT NULL CHECK (quantity > 0),
    status                  VARCHAR(32) NOT NULL, -- HELD, CONFIRMED, EXPIRED, RELEASED
    idempotency_key         VARCHAR(128) UNIQUE NOT NULL,
    expires_at              TIMESTAMPTZ NOT NULL,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE orders (
    id                      VARCHAR(64) PRIMARY KEY,
    user_id                 VARCHAR(64) REFERENCES users(id),
    guest_email             VARCHAR(200),
    store_id                VARCHAR(64) NOT NULL REFERENCES stores(id),
    fulfilment_mode         VARCHAR(32) NOT NULL, -- DELIVERY, CLICK_AND_COLLECT
    order_status            VARCHAR(40) NOT NULL, -- DRAFT, PAYMENT_PENDING, ACCEPTED, COMPLETED, CANCELLED, NEEDS_RECONCILIATION
    subtotal_ex_vat_pence   BIGINT NOT NULL,
    vat_pence               BIGINT NOT NULL,
    delivery_fee_pence      BIGINT NOT NULL,
    discount_pence          BIGINT NOT NULL DEFAULT 0,
    total_pence             BIGINT NOT NULL,
    delivery_address_json   JSONB,
    purchase_order_ref      VARCHAR(80),
    idempotency_key         VARCHAR(128) UNIQUE NOT NULL,
    version                 INT NOT NULL DEFAULT 1,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE order_items (
    id                      SERIAL PRIMARY KEY,
    order_id                VARCHAR(64) NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    sku                     VARCHAR(64) NOT NULL REFERENCES product_variants(sku),
    product_title           VARCHAR(180) NOT NULL,
    pack_count              INT NOT NULL CHECK (pack_count > 0),
    units_per_pack          INT NOT NULL CHECK (units_per_pack > 0),
    unit_pack_price_pence   BIGINT NOT NULL,
    line_total_pence        BIGINT NOT NULL
);

CREATE TABLE payments (
    id                      VARCHAR(64) PRIMARY KEY,
    order_id                VARCHAR(64) REFERENCES orders(id),
    repair_job_id           VARCHAR(64),
    workshop_booking_id     VARCHAR(64),
    amount_pence            BIGINT NOT NULL,
    currency                CHAR(3) NOT NULL DEFAULT 'GBP',
    status                  VARCHAR(32) NOT NULL, -- PENDING, SUCCEEDED, TIMED_OUT, FAILED, REFUNDED
    provider_adapter        VARCHAR(60) NOT NULL,
    provider_reference      VARCHAR(128),
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE payment_attempts (
    id                      VARCHAR(64) PRIMARY KEY,
    payment_id              VARCHAR(64) NOT NULL REFERENCES payments(id) ON DELETE CASCADE,
    idempotency_key         VARCHAR(128) UNIQUE NOT NULL,
    status                  VARCHAR(32) NOT NULL, -- PENDING, SUCCEEDED, TIMED_OUT, FAILED
    failure_reason          TEXT,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE fulfilments (
    id                      VARCHAR(64) PRIMARY KEY,
    order_id                VARCHAR(64) UNIQUE NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    store_id                VARCHAR(64) NOT NULL REFERENCES stores(id),
    mode                    VARCHAR(32) NOT NULL, -- DELIVERY, CLICK_AND_COLLECT
    status                  VARCHAR(40) NOT NULL, -- ORDER_ACCEPTED, PICKING, READY_FOR_COLLECTION, COLLECTED, DISPATCHED, DELIVERED, FULFILMENT_ERROR, CANCELLED
    collection_reference    VARCHAR(24) UNIQUE,
    estimated_ready_at      TIMESTAMPTZ,
    handover_verified_by    VARCHAR(64) REFERENCES users(id),
    handover_at             TIMESTAMPTZ,
    version                 INT NOT NULL DEFAULT 1,
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE repair_jobs (
    id                      VARCHAR(64) PRIMARY KEY,
    user_id                 VARCHAR(64) REFERENCES users(id),
    customer_name           VARCHAR(160) NOT NULL,
    customer_contact        VARCHAR(160) NOT NULL,
    store_id                VARCHAR(64) NOT NULL REFERENCES stores(id),
    service_category        VARCHAR(60) NOT NULL, -- LAPTOP_PC, PHONE_TABLET, CONSOLE_CONTROLLER, OTHER_EQUIPMENT
    device_model            VARCHAR(180) NOT NULL,
    serial_number           VARCHAR(120),
    reported_fault          TEXT NOT NULL,
    appointment_slot_at     TIMESTAMPTZ NOT NULL,
    status                  VARCHAR(40) NOT NULL,
    -- BOOKED, RECEIVED, DIAGNOSING, AWAITING_APPROVAL, AWAITING_PARTS, REPAIRING, TESTING, READY, COLLECTED, DECLINED_QUOTE, UNECONOMIC, CANCELLED, WARRANTY_RETURN
    diagnostic_fee_pence    BIGINT NOT NULL DEFAULT 2900,
    diagnostic_paid         BOOLEAN NOT NULL DEFAULT FALSE,
    diagnostic_credited     BOOLEAN NOT NULL DEFAULT FALSE,
    approved_quote_version  INT,
    approved_remaining_pence BIGINT,
    controlled_access_mode  VARCHAR(60) NOT NULL DEFAULT 'GUEST_PROFILE_AT_BENCH',
    data_consent_accepted   BOOLEAN NOT NULL DEFAULT FALSE,
    final_test_record       TEXT,
    collection_receipt_ref  VARCHAR(32),
    warranty_months         INT NOT NULL DEFAULT 6,
    version                 INT NOT NULL DEFAULT 1,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE repair_intake_records (
    id                      VARCHAR(64) PRIMARY KEY,
    repair_job_id           VARCHAR(64) UNIQUE NOT NULL REFERENCES repair_jobs(id) ON DELETE CASCADE,
    condition_notes         TEXT NOT NULL,
    supplied_accessories    TEXT NOT NULL,
    technician_id           VARCHAR(64) REFERENCES users(id),
    recorded_at             TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE repair_quotes (
    id                      VARCHAR(64) PRIMARY KEY,
    repair_job_id           VARCHAR(64) NOT NULL REFERENCES repair_jobs(id) ON DELETE CASCADE,
    quote_version           INT NOT NULL,
    total_pence             BIGINT NOT NULL CHECK (total_pence >= 0),
    diagnostic_credit_pence BIGINT NOT NULL DEFAULT 0,
    remaining_pence         BIGINT NOT NULL CHECK (remaining_pence >= 0),
    parts_grade             VARCHAR(60) NOT NULL, -- OEM_ORIGINAL, MANUFACTURER_CERTIFIED, COMPATIBLE_GRADE_A
    parts_limitations       TEXT NOT NULL,
    scope_summary           TEXT NOT NULL,
    material_change         BOOLEAN NOT NULL DEFAULT FALSE,
    customer_decision       VARCHAR(32) NOT NULL DEFAULT 'PENDING', -- PENDING, APPROVED, DECLINED, SUPERSEDED
    decided_at              TIMESTAMPTZ,
    created_by              VARCHAR(64) REFERENCES users(id),
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (repair_job_id, quote_version)
);

CREATE TABLE repair_warranty_returns (
    id                      VARCHAR(64) PRIMARY KEY,
    original_job_id         VARCHAR(64) NOT NULL REFERENCES repair_jobs(id),
    reported_recurring_fault TEXT NOT NULL,
    outcome                 VARCHAR(40) NOT NULL,
    -- PENDING_ASSESSMENT, WARRANTY_ASSESSMENT, UNRELATED_FAULT, ACCIDENTAL_DAMAGE, REPEAT_WORK, REFUND
    fresh_diagnostic_charged BOOLEAN NOT NULL DEFAULT FALSE,
    resolution_notes        TEXT,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE workshops (
    id                      VARCHAR(64) PRIMARY KEY,
    title                   VARCHAR(180) NOT NULL,
    description             TEXT NOT NULL,
    prerequisites           TEXT NOT NULL,
    equipment_provided      TEXT NOT NULL,
    age_policy              VARCHAR(140) NOT NULL,
    cancellation_terms      TEXT NOT NULL,
    price_pence             BIGINT NOT NULL CHECK (price_pence >= 0),
    duration_minutes        INT NOT NULL
);

CREATE TABLE workshop_events (
    id                      VARCHAR(64) PRIMARY KEY,
    workshop_id             VARCHAR(64) NOT NULL REFERENCES workshops(id) ON DELETE CASCADE,
    store_id                VARCHAR(64) NOT NULL REFERENCES stores(id),
    instructor_name         VARCHAR(140) NOT NULL,
    venue_room              VARCHAR(140) NOT NULL,
    starts_at_utc           TIMESTAMPTZ NOT NULL,
    capacity                INT NOT NULL CHECK (capacity > 0),
    held_seats              INT NOT NULL DEFAULT 0 CHECK (held_seats >= 0),
    confirmed_seats         INT NOT NULL DEFAULT 0 CHECK (confirmed_seats >= 0),
    version                 INT NOT NULL DEFAULT 1
);

CREATE TABLE workshop_bookings (
    id                      VARCHAR(64) PRIMARY KEY,
    event_id                VARCHAR(64) NOT NULL REFERENCES workshop_events(id) ON DELETE CASCADE,
    user_id                 VARCHAR(64) REFERENCES users(id),
    attendee_name           VARCHAR(160) NOT NULL,
    attendee_email          VARCHAR(200) NOT NULL,
    status                  VARCHAR(32) NOT NULL, -- HELD, CONFIRMED, WAITLISTED, CANCELLED, EXPIRED, REFUNDED, ATTENDED
    idempotency_key         VARCHAR(128) UNIQUE NOT NULL,
    hold_expires_at         TIMESTAMPTZ,
    attended                BOOLEAN NOT NULL DEFAULT FALSE,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE trade_accounts (
    id                      VARCHAR(64) PRIMARY KEY,
    organisation_name       VARCHAR(180) NOT NULL,
    company_reg_no          VARCHAR(60) NOT NULL,
    vat_number              VARCHAR(60),
    credit_approved         BOOLEAN NOT NULL DEFAULT FALSE,
    credit_limit_pence      BIGINT NOT NULL DEFAULT 0,
    payment_terms_days      INT NOT NULL DEFAULT 0,
    version                 INT NOT NULL DEFAULT 1,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE trade_quotes (
    id                      VARCHAR(64) PRIMARY KEY,
    trade_account_id        VARCHAR(64) NOT NULL REFERENCES trade_accounts(id),
    po_reference            VARCHAR(80) NOT NULL,
    notes                   TEXT NOT NULL,
    total_pence             BIGINT NOT NULL DEFAULT 0,
    status                  VARCHAR(32) NOT NULL DEFAULT 'SUBMITTED',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE building_centre_enquiries (
    id                      VARCHAR(64) PRIMARY KEY,
    organisation_name       VARCHAR(180) NOT NULL,
    contact_email           VARCHAR(200) NOT NULL,
    service_scope           VARCHAR(80) NOT NULL, -- ELECTRICAL_SUPPLIES, ASSEMBLY, PROTOTYPING
    specification_summary   TEXT NOT NULL,
    status                  VARCHAR(32) NOT NULL DEFAULT 'OPEN',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE notifications (
    id                      VARCHAR(64) PRIMARY KEY,
    user_id                 VARCHAR(64) REFERENCES users(id),
    channel                 VARCHAR(32) NOT NULL, -- IN_APP, PUSH
    preview_title           VARCHAR(140) NOT NULL, -- Non-PII generic preview
    body                    TEXT NOT NULL,
    delivery_status         VARCHAR(32) NOT NULL, -- QUEUED, SENT, FAILED, DELIVERED
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE media_attachments (
    id                      VARCHAR(64) PRIMARY KEY,
    object_key              VARCHAR(255) UNIQUE NOT NULL,
    mime_type               VARCHAR(100) NOT NULL,
    size_bytes              BIGINT NOT NULL CHECK (size_bytes > 0 AND size_bytes <= 10485760),
    uploaded_by             VARCHAR(64) REFERENCES users(id),
    linked_entity_type      VARCHAR(40) NOT NULL,
    linked_entity_id        VARCHAR(64) NOT NULL,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE audit_logs (
    id                      BIGSERIAL PRIMARY KEY,
    actor_id                VARCHAR(64) NOT NULL,
    actor_role              VARCHAR(40) NOT NULL,
    action                  VARCHAR(80) NOT NULL,
    entity_type             VARCHAR(60) NOT NULL,
    entity_id               VARCHAR(64) NOT NULL,
    reason                  TEXT NOT NULL,
    old_value_json          JSONB,
    new_value_json          JSONB,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
