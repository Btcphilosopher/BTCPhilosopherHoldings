-- Voltworks Demonstration Seed Data (V2)
-- All addresses, stock levels, prices, and schedules are demonstration records configurable via Staff Admin.

INSERT INTO stores (
    id, name, address_line, city, postcode, phone, email,
    opening_hours_json, facilities_json, collection_instructions,
    supports_repairs, supports_workshops, supports_trade_desk,
    collection_lead_minutes, collection_cap_per_hour
) VALUES
(
    'store-sheffield',
    'Sheffield flagship',
    'Unit 1, Meadowhall Way',
    'Sheffield',
    'S9 1EP',
    '0114 555 0140',
    'sheffield@voltworks.co.uk',
    '{"mon_fri":"08:30–19:00","sat":"09:00–18:00","sun":"10:30–16:30"}'::jsonb,
    '["1-Hour Click & Collect","ESD Repair Bench","Maker Workshop Studio","Building Centre Trade Counter"]'::jsonb,
    'Present your 8-character collection reference and photo ID at the orange Click & Collect desk inside the main entrance.',
    TRUE, TRUE, TRUE, 60, 30
),
(
    'store-manchester',
    'Manchester Northern Quarter',
    '42 Oldham Street',
    'Manchester',
    'M4 1LE',
    '0161 555 0192',
    'manchester@voltworks.co.uk',
    '{"mon_fri":"09:00–18:30","sat":"09:30–18:00","sun":"11:00–16:30"}'::jsonb,
    '["1-Hour Click & Collect","ESD Repair Bench","Soldering Bar"]'::jsonb,
    'Report to the Ground Floor Pickup Counter with your collection reference.',
    TRUE, TRUE, FALSE, 60, 20
),
(
    'store-bristol',
    'Bristol Harbourside',
    '18 Anchor Road',
    'Bristol',
    'BS1 5TT',
    '0117 555 0118',
    'bristol@voltworks.co.uk',
    '{"mon_fri":"09:00–18:00","sat":"09:00–17:30","sun":"11:00–16:00"}'::jsonb,
    '["2-Hour Click & Collect","Robotics Workshop Lab","Repair Intake Desk"]'::jsonb,
    'Collect from the Workshop Reception desk on the mezzanine level.',
    TRUE, TRUE, TRUE, 90, 15
),
(
    'store-london',
    'London Clerkenwell',
    '75 St John Street',
    'London',
    'EC1M 4AN',
    '020 7946 0821',
    'clerkenwell@voltworks.co.uk',
    '{"mon_fri":"08:00–19:30","sat":"09:30–18:00","sun":"Closed"}'::jsonb,
    '["1-Hour Click & Collect","Trade & Prototyping Desk","Component Pick Wall"]'::jsonb,
    'Use the Express Trade & Collect bay on St John Street.',
    TRUE, FALSE, TRUE, 45, 35
);

INSERT INTO products (
    id, family_name, category, manufacturer, short_summary, description,
    warranty_months, included_contents_json, documentation_json, image_keys_json, featured
) VALUES
(
    'prod-soldering-station',
    'Precision Soldering Station',
    'Tools & Repair',
    'Voltworks Pro',
    '60 W digital ESD-safe soldering station with 50–480 °C closed-loop control.',
    'Engineered for clean lead-free bench work. Features rapid PID thermal recovery, bright OLED temperature readout, weighted iron cradle with brass wool cleaner, and UK BS 1363 fused mains lead.',
    24,
    '["60 W digital control unit","ESD-safe 24 V soldering iron (T18-D24 chisel tip fitted)","Weighted stand with brass wool & sponge","1.5 m UK BS 1363 mains cable","Calibration & safety certificate"]'::jsonb,
    '[{"title":"User Manual & Calibration Guide (PDF)","url":"https://docs.voltworks.example/vw-s60-manual.pdf"},{"title":"RoHS & UKCA Declaration","url":"https://docs.voltworks.example/vw-s60-ukca.pdf"}]'::jsonb,
    '["img_prod_soldering"]'::jsonb,
    TRUE
),
(
    'prod-mcu-starter',
    'Microcontroller Starter Kit',
    'Components',
    'Northbridge Silicon',
    'RP2350 dual-core development board with 400-point breadboard, sensors and jumper set.',
    'Complete prototyping kit built around a 3.3 V ARM/RISC-V microcontroller with USB-C programming, 40-pin colour-coded jumpers, OLED display, I2C temperature sensor, and illustrated UK curriculum guide.',
    12,
    '["RP2350 Dev Board (USB-C)","400-tie solderless breadboard","65x jumper wires","0.96 in I2C OLED module","BME280 environmental sensor","Project booklet"]'::jsonb,
    '[{"title":"Pinout & Quickstart Schematic","url":"https://docs.voltworks.example/mcu-starter-pinout.pdf"}]'::jsonb,
    '["img_hero_makers"]'::jsonb,
    TRUE
),
(
    'prod-multimeter',
    'Digital Multimeter',
    'Tools & Repair',
    'CalibrateUK',
    'True-RMS 6000-count CAT III 600 V bench & field multimeter with silicone test leads.',
    'Reliable workshop diagnostics with auto-ranging AC/DC voltage, resistance, capacitance, continuity buzzer, diode test, and backlit high-contrast LCD.',
    36,
    '["True-RMS 6000-count meter","Silicone CAT III 600 V probe leads","Type-K thermocouple","2x AA alkaline cells"]'::jsonb,
    '[{"title":"CAT III Safety & Calibration Sheet","url":"https://docs.voltworks.example/dmm-6000-safety.pdf"}]'::jsonb,
    '["img_prod_multimeter"]'::jsonb,
    TRUE
),
(
    'prod-robotics-kit',
    'Robotics Explorer Kit',
    'Robotics',
    'Albion Robotics',
    '4-DOF articulated desktop robotic arm kit with metal-gear servos and PWM driver.',
    'Build, wire, and program a precision 4-axis desktop manipulator. Includes anodised aluminium brackets, 4x MG996R servos, 16-channel I2C PCA9685 driver board, and 5 V 4 A UK PSU.',
    12,
    '["Anodised frame kit & fasteners","4x metal-gear servos","16-ch I2C PWM controller","5 V 4 A UK power supply","Hex key set"]'::jsonb,
    '[{"title":"Assembly & I2C Addressing Manual","url":"https://docs.voltworks.example/robotics-explorer.pdf"}]'::jsonb,
    '["img_hero_makers"]'::jsonb,
    TRUE
),
(
    'prod-resistor-pack',
    'Metal Film Resistor 10kΩ Pack',
    'Components',
    'Yageo Europe',
    '10-piece 0.25 W 1% tolerance 10 kΩ axial metal film resistor pack.',
    'Low-noise precision 1% tolerance axial resistors suitable for breadboard pull-ups, voltage dividers, and microcontroller I/O.',
    12,
    '["10x 10 kΩ 0.25 W 1% axial resistors (tape-packed)"]'::jsonb,
    '[{"title":"Series Datasheet (MFR-25)","url":"https://docs.voltworks.example/mfr25-datasheet.pdf"}]'::jsonb,
    '["img_hero_makers"]'::jsonb,
    FALSE
),
(
    'prod-usb-nvme-dock',
    'USB4 NVMe Bench Enclosure',
    'Computing',
    'Kestrel Compute',
    'Tool-free 40 Gbps CNC aluminium M.2 NVMe enclosure for repair imaging & backups.',
    'CNC-milled thermal chassis supporting M.2 2230/2242/2280 NVMe SSDs over USB4 / Thunderbolt 4 with braided USB-C cable.',
    24,
    '["CNC NVMe enclosure","Thermal pad","0.5 m 40 Gbps USB-C cable"]'::jsonb,
    '[{"title":"Compatibility & Thermal Pad Guide","url":"https://docs.voltworks.example/nvme-dock.pdf"}]'::jsonb,
    '["img_hero_repair"]'::jsonb,
    FALSE
),
(
    'prod-matter-relay',
    'Matter Thread Smart Relay',
    'Smart Home',
    'Pennine Controls',
    'DIN/back-box 16 A Matter-over-Thread switch module with energy metering.',
    'Compact UK back-box compatible smart relay with zero-cross switching, active power telemetry, and local Thread mesh control.',
    24,
    '["16 A Matter-over-Thread module","Wiring ferrule kit","BS 7671 installation leaflet"]'::jsonb,
    '[{"title":"Electrical Wiring Diagram","url":"https://docs.voltworks.example/matter-relay-wiring.pdf"}]'::jsonb,
    '["img_hero_makers"]'::jsonb,
    FALSE
);

INSERT INTO product_variants (
    sku, product_id, variant_label, pack_quantity, min_pack_quantity,
    unit_price_pence, pack_price_pence, dimensions_mm, interface_type,
    operating_voltage, supported_platforms_json, specs_json
) VALUES
('VW-SOL-060-UK', 'prod-soldering-station', '60 W Station (UK Plug)', 1, 1, 12999, 12999, '145 x 110 x 92 mm', '230V AC / 24V Iron', '230 V AC (50 Hz)', '["Lead-free SAC305","Sn63/Pb37","T18 Tips"]'::jsonb, '{"Power":"60 W","Temp Range":"50–480 °C","Stability":"±2 °C","Tip-to-Ground":"< 2 Ω"}'::jsonb),
('VW-SOL-TIP-5PK', 'prod-soldering-station', 'T18 Tip Assortment (5-Pack)', 5, 1, 450, 2250, '42 x 6.5 mm (each)', 'T18 Sleeve', 'Passive', '["VW-SOL-060-UK"]'::jsonb, '{"Pack Size":"5 tips","Unit Price":"£4.50 / tip","Plating":"Iron-clad copper"}'::jsonb),
('VW-MCU-RP2350', 'prod-mcu-starter', 'Starter Kit (USB-C)', 1, 1, 3999, 3999, '180 x 120 x 45 mm', 'USB-C / I2C / SPI / UART', '3.3 V Logic (5 V USB)', '["MicroPython","C/C++ SDK","Arduino"]'::jsonb, '{"CPU":"Dual Cortex-M33 @ 150 MHz","Flash":"4 MB QSPI","Logic Level":"3.3 V"}'::jsonb),
('VW-DMM-6000', 'prod-multimeter', 'CAT III 600 V Meter', 1, 1, 5999, 5999, '175 x 81 x 48 mm', '4 mm Shrouded Banana', '9 V / 2x AA (3 V DC)', '["CAT III 600 V","True-RMS"]'::jsonb, '{"Counts":"6000","Max Voltage":"600 V AC/DC","Max Current":"10 A fused"}'::jsonb),
('VW-ROB-ARM4', 'prod-robotics-kit', '4-DOF Desktop Arm Kit', 1, 1, 14999, 14999, '240 x 180 x 310 mm', 'I2C (PCA9685)', '5 V DC (4 A PSU)', '["Raspberry Pi","RP2350","Arduino"]'::jsonb, '{"Axes":"4-DOF + Gripper","Reach":"285 mm","Payload":"180 g"}'::jsonb),
('VW-RES-10K-10PK', 'prod-resistor-pack', '10-Piece Resistor Pack (10 kΩ)', 10, 1, 15, 150, '6.3 x 2.3 mm body', 'Through-Hole Axial', 'Max 250 V', '["Breadboard","Perfboard","Through-hole PCB"]'::jsonb, '{"Resistance":"10 kΩ","Tolerance":"±1%","Power Rating":"0.25 W","Pack Quantity":"10 pcs (£0.15/ea)"}'::jsonb),
('VW-CMP-NVME40', 'prod-usb-nvme-dock', 'USB4 40 Gbps Enclosure', 1, 1, 4499, 4499, '106 x 42 x 14 mm', 'USB4 / M.2 M-Key', '5 V USB-C Bus', '["Linux","macOS","Windows 11"]'::jsonb, '{"Bandwidth":"40 Gbps","Form Factors":"2230 / 2242 / 2280"}'::jsonb),
('VW-SMT-MAT16A', 'prod-matter-relay', '16 A Matter Switch Module', 1, 1, 2799, 2799, '42 x 39 x 18 mm', 'Thread / Matter 1.3', '230 V AC (50 Hz)', '["Apple Home","Google Home","Home Assistant"]'::jsonb, '{"Max Load":"16 A resistive","Protocol":"IEEE 802.15.4 Thread"}'::jsonb);

INSERT INTO quantity_pricing_tiers (sku, min_packs, pack_price_pence) VALUES
('VW-RES-10K-10PK', 5, 125),
('VW-RES-10K-10PK', 20, 100),
('VW-MCU-RP2350', 5, 3699);

INSERT INTO compatibility_rules (source_sku, target_sku, relationship_type, rule_basis, manufacturer_ref) VALUES
('VW-SOL-060-UK', 'VW-SOL-TIP-5PK', 'CONSUMABLE', 'Manufacturer T18 sleeve diameter (6.5 mm OD) and heater core length match Voltworks Pro VW-SOL-060-UK handpiece.', 'Voltworks Pro Datasheet v2.1 §4'),
('VW-MCU-RP2350', 'VW-RES-10K-10PK', 'ACCESSORY', '0.6 mm axial leads fit the 400-tie breadboard included in VW-MCU-RP2350; 10 kΩ value matches 3.3 V GPIO pull-up spec.', 'Northbridge Silicon AppNote AN-04'),
('VW-ROB-ARM4', 'VW-MCU-RP2350', 'PLATFORM_MATCH', 'PCA9685 PWM controller on VW-ROB-ARM4 accepts 3.3 V I2C SDA/SCL levels directly from RP2350 GPIO.', 'Albion Robotics Interface Spec §2.3');

INSERT INTO store_inventory (store_id, sku, physical_qty, reserved_qty, quarantined_qty, inbound_transfer_qty, expected_delivery_at) VALUES
('store-sheffield', 'VW-SOL-060-UK', 6, 1, 0, 4, NOW() + INTERVAL '2 days'),
('store-sheffield', 'VW-SOL-TIP-5PK', 18, 0, 1, 0, NULL),
('store-sheffield', 'VW-MCU-RP2350', 14, 2, 0, 10, NOW() + INTERVAL '3 days'),
('store-sheffield', 'VW-DMM-6000', 8, 0, 0, 0, NULL),
('store-sheffield', 'VW-ROB-ARM4', 1, 0, 0, 3, NOW() + INTERVAL '4 days'), -- Last 1 item for concurrency demo!
('store-sheffield', 'VW-RES-10K-10PK', 45, 0, 0, 0, NULL),
('store-sheffield', 'VW-CMP-NVME40', 5, 0, 0, 0, NULL),
('store-sheffield', 'VW-SMT-MAT16A', 9, 1, 0, 0, NULL),
('store-manchester', 'VW-SOL-060-UK', 4, 0, 0, 0, NULL),
('store-manchester', 'VW-MCU-RP2350', 7, 0, 0, 0, NULL),
('store-manchester', 'VW-DMM-6000', 5, 1, 0, 0, NULL),
('store-manchester', 'VW-RES-10K-10PK', 30, 0, 0, 0, NULL),
('store-bristol', 'VW-SOL-060-UK', 3, 0, 0, 2, NOW() + INTERVAL '1 day'),
('store-bristol', 'VW-ROB-ARM4', 2, 0, 0, 0, NULL),
('store-london', 'VW-CMP-NVME40', 11, 1, 0, 0, NULL),
('store-london', 'VW-RES-10K-10PK', 80, 0, 0, 0, NULL);

INSERT INTO workshops (id, title, description, prerequisites, equipment_provided, age_policy, cancellation_terms, price_pence, duration_minutes) VALUES
('ws-soldering', 'Soldering basics', 'Hands-on through-hole and SMD soldering fundamentals on temperature-controlled stations.', 'No prior soldering experience required.', 'ESD mat, VW-SOL-060 station, lead-free solder, practice PCB kit included to keep.', 'Ages 14+ (under-16s must be accompanied by a ticketed adult).', 'Full refund up to 48 hours before start; 50% credit within 24–48 hours.', 3500, 120),
('ws-robot', 'Build your first robot', 'Assemble, calibrate, and code an obstacle-avoiding rover using RP2350 & ultrasonic sensors.', 'Basic familiarity with laptops or block/Python code.', 'Chassis kit, microcontroller, battery pack, and bench tools provided for session.', 'Ages 12+ (under-16s accompanied).', 'Full refund up to 48 hours before start.', 5500, 180),
('ws-mcu', 'Microcontroller projects', 'Interface I2C OLED displays, environmental sensors, and PWM outputs using MicroPython.', 'Bring a laptop with USB-C/A or borrow a store Chromebook.', 'RP2350 kit and breadboard pack supplied for use.', 'Ages 16+.', 'Full refund up to 48 hours before start.', 4000, 150),
('ws-pc-build', 'PC building', 'Learn airflow planning, ESD-safe CPU/NVMe installation, cabling, and UEFI firmware setup.', 'None — ideal for first-time builders.', 'Demonstration test benches, torque drivers, and ESD straps provided.', 'Ages 14+.', 'Full refund up to 48 hours before start.', 4500, 150),
('ws-smart-home', 'Smart-home setup', 'Design reliable local Matter & Thread automations with zero cloud lock-in.', 'Basic home Wi-Fi familiarity.', 'Thread border router and Matter relay demo rigs on bench.', 'Ages 18+.', 'Full refund up to 48 hours before start.', 3000, 120);

INSERT INTO workshop_events (id, workshop_id, store_id, instructor_name, venue_room, starts_at_utc, capacity, held_seats, confirmed_seats) VALUES
('evt-soldering-shef-1', 'ws-soldering', 'store-sheffield', 'Hannah Patel (Lead Bench Eng)', 'Maker Studio A', '2027-06-12T10:00:00Z', 8, 0, 5), -- BST (UTC+1 -> 11:00 BST)
('evt-robot-bris-1', 'ws-robot', 'store-bristol', 'Callum Reid', 'Robotics Lab', '2027-06-19T13:00:00Z', 6, 0, 5), -- Last 1 seat!
('evt-mcu-manc-1', 'ws-mcu', 'store-manchester', 'Priya Nair', 'NQ Workshop Room', '2027-01-30T18:00:00Z', 10, 0, 4), -- GMT (UTC+0 -> 18:00 GMT)
('evt-pc-shef-1', 'ws-pc-build', 'store-sheffield', 'Owen Davies', 'Maker Studio B', '2027-02-06T10:30:00Z', 8, 0, 3),
('evt-smart-lon-1', 'ws-smart-home', 'store-sheffield', 'Claire Hughes', 'Maker Studio A', '2027-07-03T17:30:00Z', 8, 0, 2); -- BST (18:30 BST)
