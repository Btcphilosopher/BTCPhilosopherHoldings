package com.voltworks.backend

import com.voltworks.backend.domain.*
import com.voltworks.backend.persistence.ConflictException
import com.voltworks.backend.persistence.ForbiddenException
import com.voltworks.backend.persistence.VoltworksEngine
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant
import java.util.concurrent.Callable
import java.util.concurrent.Executors

class VoltworksBackendTests {

    @Test
    fun `monetary calculator handles pack prices, VAT, and delivery threshold accurately`() {
        val engine = VoltworksEngine()
        val breakdown = engine.validateBasket(
            mode = FulfilmentMode.DELIVERY,
            items = listOf(BasketLineRequest("VW-RES-10K-10PK", 5)) // tier 5+ packs = 125p/pack * 5 = 625p + 399p delivery = 1024p
        )
        assertEquals(625L + 399L, breakdown.totalPence)
        assertEquals(399L, breakdown.deliveryFeePence)
        assertEquals(125L, breakdown.lines.first().effectivePackPricePence)
        assertEquals(12L, breakdown.lines.first().effectiveUnitPricePence)
        assertEquals(625L, breakdown.subtotalExVatPence + breakdown.vatPence)
    }

    @Test
    fun `competing purchases of the last item only allow one reservation`() {
        val engine = VoltworksEngine()
        // VW-ROB-ARM4 has physical=1, reserved=0 at store-sheffield
        val pool = Executors.newFixedThreadPool(4)
        val tasks = (1..4).map { idx ->
            Callable {
                runCatching {
                    engine.reserveInventory(
                        ReserveRequest(
                            basketId = "basket-$idx",
                            storeId = "store-sheffield",
                            items = listOf(BasketLineRequest("VW-ROB-ARM4", 1)),
                            idempotencyKey = "idem-race-$idx"
                        )
                    )
                }
            }
        }
        val results = pool.invokeAll(tasks).map { it.get() }
        pool.shutdown()

        assertEquals(1, results.count { it.isSuccess })
        assertEquals(3, results.count { it.exceptionOrNull() is ConflictException })
    }

    @Test
    fun `payment timeout followed by idempotent retry succeeds without double charge`() {
        val engine = VoltworksEngine()
        val res = engine.reserveInventory(
            ReserveRequest("b1", "store-sheffield", listOf(BasketLineRequest("VW-DMM-6000", 1)), "res-key-1")
        )
        val payKey = "pay-idem-timeout-1"
        val timedOut = runCatching {
            engine.checkoutAndPay(
                CheckoutPayRequest(
                    basketId = "b1",
                    storeId = "store-sheffield",
                    fulfilmentMode = FulfilmentMode.CLICK_AND_COLLECT,
                    reservationIds = res.map { it.id },
                    items = listOf(BasketLineRequest("VW-DMM-6000", 1)),
                    customerEmail = "maker@voltworks.co.uk",
                    simulateTimeout = true,
                    idempotencyKey = payKey
                )
            )
        }
        assertTrue(timedOut.exceptionOrNull() is ConflictException)

        // Retry with same idempotencyKey and simulateTimeout = false
        val order1 = engine.checkoutAndPay(
            CheckoutPayRequest(
                basketId = "b1",
                storeId = "store-sheffield",
                fulfilmentMode = FulfilmentMode.CLICK_AND_COLLECT,
                reservationIds = res.map { it.id },
                items = listOf(BasketLineRequest("VW-DMM-6000", 1)),
                customerEmail = "maker@voltworks.co.uk",
                simulateTimeout = false,
                idempotencyKey = payKey
            )
        )
        val order2 = engine.checkoutAndPay(
            CheckoutPayRequest(
                basketId = "b1",
                storeId = "store-sheffield",
                fulfilmentMode = FulfilmentMode.CLICK_AND_COLLECT,
                reservationIds = res.map { it.id },
                items = listOf(BasketLineRequest("VW-DMM-6000", 1)),
                customerEmail = "maker@voltworks.co.uk",
                simulateTimeout = false,
                idempotencyKey = payKey
            )
        )
        assertEquals(order1.id, order2.id)
        assertEquals(PaymentStatus.SUCCEEDED, order1.paymentStatus)
        assertEquals(FulfilmentStatus.ORDER_ACCEPTED, order1.fulfilmentStatus)
    }

    @Test
    fun `repair diagnostic credit applies 149 - 29 = 120 once and revised quote requires renewed approval`() {
        val engine = VoltworksEngine()
        val booked = engine.bookRepair(
            RepairBookRequest(
                customerName = "Alex Turner",
                customerContact = "alex@example.co.uk",
                storeId = "store-sheffield",
                category = RepairCategory.LAPTOP_PC,
                deviceModel = "ThinkPad X1 Carbon",
                serialNumber = "SN-9921",
                reportedFault = "USB-C PD port no longer charging",
                appointmentSlotIso = "2027-01-29T10:30:00Z",
                controlledAccessMode = "GUEST_PROFILE_AT_BENCH",
                dataConsentAccepted = true,
                idempotencyKey = "rep-book-1"
            )
        )

        val quoted = engine.issueRepairQuote(
            jobId = booked.id,
            req = CreateQuoteRequest(14900, PartsGrade.OEM_ORIGINAL, "90-day part warranty", "Replace USB-C PD controller & port", false, booked.version),
            actorId = "tech-1",
            actorRole = StaffRole.TECHNICIAN
        )
        val firstQuote = quoted.quotes.last()
        assertEquals(2900L, firstQuote.diagnosticCreditPence)
        assertEquals(12000L, firstQuote.remainingPence)

        val approved = engine.decideRepairQuote(
            booked.id,
            QuoteDecisionRequest(firstQuote.quoteVersion, approve = true, expectedVersion = quoted.version, idempotencyKey = "dec-1")
        )
        assertEquals(12000L, approved.approvedRemainingPence)
        assertTrue(approved.diagnosticCredited)

        // Material quote revision must clear previous approval and NOT apply a duplicate £29 credit
        val revised = engine.issueRepairQuote(
            jobId = booked.id,
            req = CreateQuoteRequest(17900, PartsGrade.OEM_ORIGINAL, "Full board rework", "Additional damaged MOSFET discovered", true, approved.version),
            actorId = "tech-1",
            actorRole = StaffRole.TECHNICIAN
        )
        assertEquals(RepairStatus.AWAITING_APPROVAL, revised.status)
        assertNull(revised.approvedQuoteVersion)
        val secondQuote = revised.quotes.last()
        assertEquals(0L, secondQuote.diagnosticCreditPence)
        assertEquals(17900L, secondQuote.remainingPence)
    }

    @Test
    fun `workshop capacity, expired hold release, and BST time formatting work correctly`() {
        val engine = VoltworksEngine()
        val events = engine.listWorkshops()
        val bstEvent = events.first { it.id == "evt-robot-bris-1" } // 1 seat available, June UTC -> BST
        assertTrue(bstEvent.startsAtLondonFormatted.contains("BST"))
        assertEquals(1, bstEvent.availableSeats)

        val t0 = Instant.parse("2027-06-01T10:00:00Z")
        val hold1 = engine.holdWorkshopSeat("evt-robot-bris-1", WorkshopHoldRequest("Sam", "sam@test.uk", "h1"), now = t0, holdTtlSeconds = 60)
        assertEquals(WorkshopBookingStatus.HELD, hold1.status)

        // Second person gets waitlisted while hold1 is active
        val hold2 = engine.holdWorkshopSeat("evt-robot-bris-1", WorkshopHoldRequest("Jo", "jo@test.uk", "h2"), now = t0.plusSeconds(10), holdTtlSeconds = 60)
        assertEquals(WorkshopBookingStatus.WAITLISTED, hold2.status)

        // After expiry at t0 + 90s, a new buyer can claim the released seat
        val hold3 = engine.holdWorkshopSeat("evt-robot-bris-1", WorkshopHoldRequest("Mia", "mia@test.uk", "h3"), now = t0.plusSeconds(90), holdTtlSeconds = 60)
        assertEquals(WorkshopBookingStatus.HELD, hold3.status)
    }

    @Test
    fun `staff permissions block customer from adjusting inventory or reading audit logs`() {
        val engine = VoltworksEngine()
        assertThrows(ForbiddenException::class.java) {
            engine.adjustInventory("store-sheffield", "VW-DMM-6000", -1, 1, "Attempt", "cust-1", StaffRole.CUSTOMER)
        }
    }

    @Test
    fun `trade account creation never automatically grants credit and warranty return skips diagnostic fee`() {
        val engine = VoltworksEngine()
        val trade = engine.createTradeAccount(TradeAccountRequest("Pennine Makers Ltd", "12345678", "GB123456789"))
        assertFalse(trade.creditApproved)
        assertEquals(0L, trade.creditLimitPence)

        val job = engine.bookRepair(
            RepairBookRequest("Lee", "lee@test.uk", "store-sheffield", RepairCategory.CONSOLE_CONTROLLER, "PS5", "SN1", "HDMI port loose", "2027-01-29T12:00:00Z", "PIN_AT_COUNTER", true, "r-w-1")
        )
        val wr = engine.openWarrantyReturn(job.id, WarrantyReturnRequest("Intermittent signal drop returns", "wr-1"))
        assertFalse(wr.freshDiagnosticCharged)
        assertEquals(WarrantyOutcome.WARRANTY_ASSESSMENT, wr.outcome)
    }
}
