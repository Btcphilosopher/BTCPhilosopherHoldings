package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `app name and home screen match Voltworks branding and navigation`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Voltworks", context.getString(R.string.app_name))

        composeRule.waitForIdle()
        composeRule.onNodeWithText("VOLTWORKS").assertIsDisplayed()
        composeRule.onNodeWithText("POWER").assertIsDisplayed()
        composeRule.onNodeWithText("IDEA.").assertIsDisplayed()

        // Navigate to Services tab and verify Repair. Learn. Build.
        composeRule.onNodeWithTag("bottom_nav_services").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Book a repair").assertIsDisplayed()
        composeRule.onNodeWithText("Diagnostic assessment").assertIsDisplayed()
        composeRule.onNodeWithText("£29").assertIsDisplayed()
    }
}
