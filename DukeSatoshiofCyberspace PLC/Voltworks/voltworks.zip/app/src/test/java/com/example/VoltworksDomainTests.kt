package com.example

import com.example.data.engine.ApiConflictException
import com.example.data.engine.ApiForbiddenException
import com.example.data.engine.VoltworksSandboxServer
import com.example.data.model.*
import com.example.data.remote.CreateQuoteApiRequest
import com.example.data.remote.VoltworksApiClient
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.Callable
import java.util.concurrent.Executors

class VoltworksDomainTests {

    @Test
    fun `ten-piece resistor pack calculates unit price, tier price, VAT, and delivery accurately`() {
        val server = VoltworksSandboxServer()
        val breakdown = server.computeBreakdown(
            mode = FulfilmentMode.DELIVERY,
            items = listOf(BasketLineRequest("VW-RES-10K-10PK", 5))
        )
        // 5+ pack tier = 125p/pack * 5 = 625p goods + 399p delivery = 1024p
        assertEquals(1024L, breakdown.totalPence)
        assertEquals(399L, breakdown.deliveryFeePence)
        assertEquals(125L, breakdown.lines.first().effectivePackPricePence)
        assertEquals(12L, breakdown.lines.first().effectiveUnitPricePence)
        assertEquals(625L, breakdown.subtotalExVatPence + breakdown.vatPence)
    }

    @Test
    fun `competing purchases of last Robotics Explorer Kit allow only one reservation`() {
        val server = VoltworksSandboxServer()
        val pool = Executors.newFixedThreadPool(4)
        val tasks = (1..4).map { idx ->
            Callable {
                runCatching {
                    server.reserveInventory(
                        ReserveRequest(
                            basketId = "basket-$idx",
                            storeId = "store-sheffield",
                            items = listOf(BasketLineRequest("VW-ROB-ARM4", 1)),
                            idempotencyKey = "race-$idx"
                        )
                    )
                }
            }
        }
        val results = pool.invokeAll(tasks).map { it.get() }
        pool.shutdown()

        assertEquals(1, results.count { it.isSuccess })
        assertEquals(3, results.count { it.exceptionOrNull() is ApiConflictException })
    }

    @Test
    fun `payment timeout followed by Ktor retry succeeds with same idempotency key`() = runTest {
        val api = VoltworksApiClient()
        val res = api.reserveStock(
            ReserveRequest("b1", "store-sheffield", listOf(BasketLineRequest("VW-DMM-6000", 1)), "res-dmm-1")
        )
        val idem = "pay-retry-key-1"

        val timeoutErr = runCatching {
            api.payOrder(
                CheckoutPayRequest(
                    basketId = "b1",
                    storeId = "store-sheffield",
                    fulfilmentMode = FulfilmentMode.CLICK_AND_COLLECT,
                    reservationIds = res.map { it.id },
                    items = listOf(BasketLineRequest("VW-DMM-6000", 1)),
                    customerEmail = "maker@voltworks.co.uk",
                    simulateTimeout = true,
                    idempotencyKey = idem
                )
            )
        }
        assertTrue(timeoutErr.exceptionOrNull() is ApiConflictException)

        val order = api.payOrder(
            CheckoutPayRequest(
                basketId = "b1",
                storeId = "store-sheffield",
                fulfilmentMode = FulfilmentMode.CLICK_AND_COLLECT,
                reservationIds = res.map { it.id },
                items = listOf(BasketLineRequest("VW-DMM-6000", 1)),
                customerEmail = "maker@voltworks.co.uk",
                simulateTimeout = false,
                idempotencyKey = idem
            )
        )
        assertEquals(FulfilmentStatus.ORDER_ACCEPTED, order.fulfilmentStatus)
        assertEquals(PaymentStatus.SUCCEEDED, order.paymentStatus)
        assertNotNull(order.collectionReference)

        // Mark ready & verify handover
        val ready = api.markOrderReadyForCollection(order.id, order.version)
        assertEquals(FulfilmentStatus.READY_FOR_COLLECTION, ready.fulfilmentStatus)
        val collected = api.collectOrder(ready.id, com.example.data.remote.CollectOrderApiRequest(ready.collectionReference!!, ready.version))
        assertEquals(FulfilmentStatus.COLLECTED, collected.fulfilmentStatus)
    }

    @Test
    fun `repair quote applies 149 - 29 = 120 credit once and revised quote requires renewed approval`() = runTest {
        val api = VoltworksApiClient()
        val booked = api.bookRepair(
            RepairBookRequest(
                customerName = "Samira Patel",
                customerContact = "samira@example.co.uk",
                storeId = "store-sheffield",
                category = RepairCategory.LAPTOP_PC,
                deviceModel = "Framework 13",
                serialNumber = "FW-101",
                reportedFault = "USB-C dead",
                appointmentSlotLabel = "Wed 29 Jan · 10:30",
                controlledAccessMode = "GUEST_PROFILE_AT_BENCH",
                dataConsentAccepted = true,
                idempotencyKey = "rep-1"
            )
        )
        val quoted = api.issueRepairQuote(
            booked.id,
            CreateQuoteApiRequest(14900L, PartsGrade.OEM_ORIGINAL, "6-month warranty", "Replace USB-C PD", false, booked.version)
        )
        val q1 = quoted.quotes.last()
        assertEquals(2900L, q1.diagnosticCreditPence)
        assertEquals(12000L, q1.remainingPence)

        val approved = api.decideRepairQuote(booked.id, QuoteDecisionRequest(q1.quoteVersion, true, quoted.version, "dec-q1"))
        assertEquals(12000L, approved.approvedRemainingPence)

        val revised = api.issueRepairQuote(
            booked.id,
            CreateQuoteApiRequest(17900L, PartsGrade.OEM_ORIGINAL, "Full board rework", "MOSFET failure found", true, approved.version)
        )
        assertEquals(RepairStatus.AWAITING_APPROVAL, revised.status)
        assertNull(revised.approvedQuoteVersion)
        assertEquals(0L, revised.quotes.last().diagnosticCreditPence)
        assertEquals(17900L, revised.quotes.last().remainingPence)
    }

    @Test
    fun `workshop capacity, expired hold release, BST formatting, and staff permissions`() {
        val server = VoltworksSandboxServer()
        val bristolEvent = server.listWorkshops().first { it.id == "evt-robot-bris-1" }
        assertTrue(bristolEvent.startsAtLondonFormatted.contains("BST"))
        assertEquals(1, bristolEvent.availableSeats)

        val hold1 = server.holdWorkshopSeat("evt-robot-bris-1", WorkshopHoldRequest("Jo", "jo@uk", "wh-1"))
        assertEquals(WorkshopBookingStatus.HELD, hold1.status)
        val waitlisted = server.holdWorkshopSeat("evt-robot-bris-1", WorkshopHoldRequest("Max", "max@uk", "wh-2"))
        assertEquals(WorkshopBookingStatus.WAITLISTED, waitlisted.status)

        server.expireWorkshopHoldNow(hold1.id)
        val hold2 = server.holdWorkshopSeat("evt-robot-bris-1", WorkshopHoldRequest("Ava", "ava@uk", "wh-3"))
        assertEquals(WorkshopBookingStatus.HELD, hold2.status)

        assertThrows(ApiForbiddenException::class.java) {
            server.advanceRepairStatus("REP-40912", RepairStatus.READY, actorRole = StaffRole.CUSTOMER)
        }
    }
}
