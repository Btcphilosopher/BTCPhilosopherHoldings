package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.BasketDraftEntity
import com.example.data.local.SyncMetadataEntity
import com.example.data.model.*
import com.example.data.repo.VoltworksRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

data class ShopFilters(
    val category: String = "All",
    val query: String = "",
    val manufacturer: String = "All",
    val maxPricePence: Long? = null,
    val onlyInSelectedStore: Boolean = false,
    val interfaceFilter: String = "All",
    val voltageFilter: String = "All",
    val platformFilter: String = "All"
)

data class CheckoutSessionState(
    val fulfilmentMode: FulfilmentMode = FulfilmentMode.CLICK_AND_COLLECT,
    val customerEmail: String = "alex.maker@voltworks.co.uk",
    val deliveryAddress: String = "14 Ecclesall Road, Sheffield, S11 8PR",
    val purchaseOrderRef: String = "",
    val activeReservations: List<ReservationDto> = emptyList(),
    val pendingPaymentIdempotencyKey: String? = null,
    val simulateTimeout: Boolean = false,
    val simulateFulfilmentError: Boolean = false,
    val paymentTimedOutMessage: String? = null,
    val completedOrder: OrderDto? = null
)

data class VoltworksUiState(
    val isLoading: Boolean = true,
    val stores: List<StoreDto> = emptyList(),
    val selectedStoreId: String = "store-sheffield",
    val allProducts: List<ProductDto> = emptyList(),
    val filteredProducts: List<ProductDto> = emptyList(),
    val filters: ShopFilters = ShopFilters(),
    val selectedStoreInventory: Map<String, StoreInventoryDto> = emptyMap(),
    val basketItems: List<BasketDraftEntity> = emptyList(),
    val checkout: CheckoutSessionState = CheckoutSessionState(),
    val orders: List<OrderDto> = emptyList(),
    val repairs: List<RepairJobDto> = emptyList(),
    val workshops: List<WorkshopEventDto> = emptyList(),
    val workshopBookings: List<WorkshopBookingDto> = emptyList(),
    val tradeAccounts: List<TradeAccountDto> = emptyList(),
    val tradeQuotes: List<TradeQuoteDto> = emptyList(),
    val buildingEnquiries: List<BuildingCentreEnquiryDto> = emptyList(),
    val notifications: List<NotificationDto> = emptyList(),
    val auditLogs: List<AuditLogDto> = emptyList(),
    val signedInEmail: String? = null,
    val biometricLockEnabled: Boolean = false,
    val biometricUnlocked: Boolean = true,
    val reducedMotion: Boolean = false,
    val pushEnabled: Boolean = true,
    val offlineMode: Boolean = false,
    val syncMeta: SyncMetadataEntity? = null,
    val savedAddresses: List<CustomerAddressDto> = listOf(
        CustomerAddressDto("addr-1", "Home Workshop", "14 Ecclesall Road", "Sheffield", "S11 8PR"),
        CustomerAddressDto("addr-2", "Studio Unit", "22 Arundel Lane", "Sheffield", "S1 2NU")
    ),
    val savedLists: List<String> = listOf("Bench Calibration Kit (3 SKUs)", "RP2350 Classroom Pack"),
    val bannerMessage: String? = null,
    val errorMessage: String? = null
) {
    val selectedStore: StoreDto?
        get() = stores.firstOrNull { it.id == selectedStoreId } ?: stores.firstOrNull()

    val basketTotalCount: Int
        get() = basketItems.sumOf { it.packCount }

    val basketGoodsPence: Long
        get() = basketItems.sumOf { it.packPricePence * it.packCount }
}

class VoltworksViewModel(
    private val repository: VoltworksRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(VoltworksUiState())
    val uiState: StateFlow<VoltworksUiState> = _uiState.asStateFlow()

    init {
        observeLocalFlows()
        refreshAll()
    }

    private fun observeLocalFlows() {
        viewModelScope.launch {
            repository.basketDrafts.collect { items ->
                _uiState.update { it.copy(basketItems = items) }
            }
        }
        viewModelScope.launch {
            repository.offlineMode.collect { offline ->
                _uiState.update { it.copy(offlineMode = offline) }
            }
        }
        viewModelScope.launch {
            repository.syncFreshness.collect { meta ->
                _uiState.update { it.copy(syncMeta = meta) }
            }
        }
        viewModelScope.launch {
            combine(
                repository.cachedProducts,
                repository.cachedOrders,
                repository.cachedRepairs
            ) { prods, ords, reps -> Triple(prods, ords, reps) }
                .collect { (prods, ords, reps) ->
                    if (_uiState.value.offlineMode && prods.isNotEmpty()) {
                        _uiState.update {
                            it.copy(
                                allProducts = prods,
                                filteredProducts = applyClientFilters(prods, it.filters, it.selectedStoreInventory),
                                orders = ords,
                                repairs = reps
                            )
                        }
                    }
                }
        }
    }

    fun refreshAll() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            runCatching {
                val api = repository.apiClient
                repository.refreshFromServer()
                val stores = api.getStores()
                val selectedStoreId = _uiState.value.selectedStoreId
                val stockMap = api.getStoreInventory(selectedStoreId).associateBy { it.sku }
                val products = api.getProducts()
                val orders = api.getOrders()
                val repairs = api.getRepairs()
                val workshops = api.getWorkshops()
                val bookings = api.getWorkshopBookings()
                val tradeAccounts = api.getTradeAccounts()
                val tradeQuotes = api.getTradeQuotes()
                val enquiries = api.getBuildingEnquiries()
                val notifications = api.getNotifications()
                val audits = api.getAuditLogs()

                _uiState.update { state ->
                    state.copy(
                        isLoading = false,
                        stores = stores,
                        selectedStoreInventory = stockMap,
                        allProducts = products,
                        filteredProducts = applyClientFilters(products, state.filters, stockMap),
                        orders = orders,
                        repairs = repairs,
                        workshops = workshops,
                        workshopBookings = bookings,
                        tradeAccounts = tradeAccounts,
                        tradeQuotes = tradeQuotes,
                        buildingEnquiries = enquiries,
                        notifications = notifications,
                        auditLogs = audits
                    )
                }
            }.onFailure { err ->
                _uiState.update { it.copy(isLoading = false, errorMessage = err.message) }
            }
        }
    }

    fun selectStore(storeId: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(selectedStoreId = storeId) }
            runCatching {
                val stockMap = repository.apiClient.getStoreInventory(storeId).associateBy { it.sku }
                _uiState.update { state ->
                    state.copy(
                        selectedStoreInventory = stockMap,
                        filteredProducts = applyClientFilters(state.allProducts, state.filters, stockMap),
                        checkout = state.checkout.copy(activeReservations = emptyList(), paymentTimedOutMessage = null)
                    )
                }
            }
        }
    }

    fun updateFilters(transform: (ShopFilters) -> ShopFilters) {
        _uiState.update { state ->
            val nextFilters = transform(state.filters)
            state.copy(
                filters = nextFilters,
                filteredProducts = applyClientFilters(state.allProducts, nextFilters, state.selectedStoreInventory)
            )
        }
    }

    private fun applyClientFilters(
        products: List<ProductDto>,
        filters: ShopFilters,
        stockMap: Map<String, StoreInventoryDto>
    ): List<ProductDto> {
        return products.filter { p ->
            val catOk = filters.category == "All" || p.category.equals(filters.category, ignoreCase = true)
            val mfgOk = filters.manufacturer == "All" || p.manufacturer.equals(filters.manufacturer, ignoreCase = true)
            val qOk = filters.query.isBlank() ||
                p.familyName.contains(filters.query, ignoreCase = true) ||
                p.shortSummary.contains(filters.query, ignoreCase = true) ||
                p.category.contains(filters.query, ignoreCase = true) ||
                p.variants.any { it.sku.contains(filters.query, ignoreCase = true) }
            val priceOk = filters.maxPricePence == null || p.variants.any { it.packPricePence <= filters.maxPricePence }
            val stockOk = !filters.onlyInSelectedStore || p.variants.any { (stockMap[it.sku]?.availableToPromise ?: 0) > 0 }
            val ifaceOk = filters.interfaceFilter == "All" || p.variants.any {
                it.interfaceType?.contains(filters.interfaceFilter, ignoreCase = true) == true
            }
            val voltOk = filters.voltageFilter == "All" || p.variants.any {
                it.operatingVoltage?.contains(filters.voltageFilter, ignoreCase = true) == true
            }
            val platOk = filters.platformFilter == "All" || p.variants.any { v ->
                v.supportedPlatforms.any { it.contains(filters.platformFilter, ignoreCase = true) }
            }
            catOk && mfgOk && qOk && priceOk && stockOk && ifaceOk && voltOk && platOk
        }
    }

    suspend fun loadSkuStockAcrossStores(sku: String): List<StoreInventoryDto> =
        runCatching { repository.apiClient.getSkuStockAcrossStores(sku) }.getOrDefault(emptyList())

    fun addToBasket(product: ProductDto, variant: ProductVariantDto, packCount: Int = 1) {
        viewModelScope.launch {
            repository.addToBasket(product, variant, packCount)
            _uiState.update {
                it.copy(
                    bannerMessage = "Added ${packCount}× ${variant.variantLabel} to basket.",
                    checkout = it.checkout.copy(activeReservations = emptyList(), completedOrder = null)
                )
            }
        }
    }

    fun updateBasketItemQty(sku: String, newPackCount: Int) {
        viewModelScope.launch {
            val variant = _uiState.value.allProducts.flatMap { it.variants }.firstOrNull { it.sku == sku }
            repository.updateBasketQuantity(sku, newPackCount, variant)
            _uiState.update { it.copy(checkout = it.checkout.copy(activeReservations = emptyList())) }
        }
    }

    fun setFulfilmentMode(mode: FulfilmentMode) {
        _uiState.update { it.copy(checkout = it.checkout.copy(fulfilmentMode = mode)) }
    }

    fun updateCheckoutDetails(
        email: String = _uiState.value.checkout.customerEmail,
        address: String = _uiState.value.checkout.deliveryAddress,
        poRef: String = _uiState.value.checkout.purchaseOrderRef,
        simulateTimeout: Boolean = _uiState.value.checkout.simulateTimeout,
        simulateFulfilmentError: Boolean = _uiState.value.checkout.simulateFulfilmentError
    ) {
        _uiState.update {
            it.copy(
                checkout = it.checkout.copy(
                    customerEmail = email,
                    deliveryAddress = address,
                    purchaseOrderRef = poRef,
                    simulateTimeout = simulateTimeout,
                    simulateFulfilmentError = simulateFulfilmentError
                )
            )
        }
    }

    fun reserveBasketStock() {
        viewModelScope.launch {
            val state = _uiState.value
            if (state.basketItems.isEmpty()) return@launch
            runCatching {
                val res = repository.reserveStock(
                    ReserveRequest(
                        basketId = "basket-local",
                        storeId = state.selectedStoreId,
                        items = state.basketItems.map { BasketLineRequest(it.sku, it.packCount) },
                        idempotencyKey = "res-${UUID.randomUUID()}"
                    )
                )
                _uiState.update {
                    it.copy(
                        checkout = it.checkout.copy(
                            activeReservations = res,
                            pendingPaymentIdempotencyKey = "pay-${UUID.randomUUID()}",
                            paymentTimedOutMessage = null,
                            completedOrder = null
                        ),
                        bannerMessage = "Stock reserved at ${state.selectedStore?.name ?: state.selectedStoreId} (15-min hold)."
                    )
                }
                refreshAll()
            }.onFailure { err ->
                _uiState.update { it.copy(errorMessage = err.message ?: "Unable to reserve stock") }
            }
        }
    }

    fun payAndPlaceOrder(retryExistingKey: Boolean = false) {
        viewModelScope.launch {
            val state = _uiState.value
            val checkout = state.checkout
            if (state.basketItems.isEmpty() || checkout.activeReservations.isEmpty()) {
                _uiState.update { it.copy(errorMessage = "Reserve inventory before completing payment.") }
                return@launch
            }
            val idemKey = if (retryExistingKey && checkout.pendingPaymentIdempotencyKey != null) {
                checkout.pendingPaymentIdempotencyKey
            } else {
                checkout.pendingPaymentIdempotencyKey ?: "pay-${UUID.randomUUID()}"
            }
            runCatching {
                val order = repository.payOrder(
                    CheckoutPayRequest(
                        basketId = "basket-local",
                        storeId = state.selectedStoreId,
                        fulfilmentMode = checkout.fulfilmentMode,
                        reservationIds = checkout.activeReservations.map { it.id },
                        items = state.basketItems.map { BasketLineRequest(it.sku, it.packCount) },
                        customerEmail = checkout.customerEmail,
                        deliveryAddress = if (checkout.fulfilmentMode == FulfilmentMode.DELIVERY) checkout.deliveryAddress else null,
                        purchaseOrderRef = checkout.purchaseOrderRef.ifBlank { null },
                        simulateTimeout = if (retryExistingKey) false else checkout.simulateTimeout,
                        simulateFulfilmentError = checkout.simulateFulfilmentError,
                        idempotencyKey = idemKey
                    )
                )
                _uiState.update {
                    it.copy(
                        checkout = CheckoutSessionState(
                            fulfilmentMode = checkout.fulfilmentMode,
                            customerEmail = checkout.customerEmail,
                            deliveryAddress = checkout.deliveryAddress,
                            completedOrder = order
                        ),
                        bannerMessage = "Order ${order.id} confirmed (${order.fulfilmentStatus.name.replace('_', ' ')})."
                    )
                }
                refreshAll()
            }.onFailure { err ->
                val msg = err.message ?: "Payment failed"
                if (msg.contains("PAYMENT_TIMEOUT")) {
                    _uiState.update {
                        it.copy(
                            checkout = it.checkout.copy(
                                pendingPaymentIdempotencyKey = idemKey,
                                simulateTimeout = false,
                                paymentTimedOutMessage = msg
                            ),
                            errorMessage = msg
                        )
                    }
                } else {
                    _uiState.update { it.copy(errorMessage = msg) }
                }
            }
        }
    }

    fun markOrderReadyForCollection(order: OrderDto) {
        viewModelScope.launch {
            runCatching {
                val updated = repository.markOrderReady(order.id, order.version)
                _uiState.update {
                    it.copy(
                        checkout = it.checkout.copy(
                            completedOrder = if (it.checkout.completedOrder?.id == order.id) updated else it.checkout.completedOrder
                        ),
                        bannerMessage = "Staff marked ${order.id} ready for collection (${updated.collectionReference})."
                    )
                }
                refreshAll()
            }.onFailure { e -> _uiState.update { it.copy(errorMessage = e.message) } }
        }
    }

    fun collectOrder(order: OrderDto, enteredRef: String) {
        viewModelScope.launch {
            runCatching {
                val updated = repository.collectOrder(order.id, enteredRef.trim(), order.version)
                _uiState.update {
                    it.copy(
                        checkout = it.checkout.copy(
                            completedOrder = if (it.checkout.completedOrder?.id == order.id) updated else it.checkout.completedOrder
                        ),
                        bannerMessage = "Order ${order.id} collected with verified handover."
                    )
                }
                refreshAll()
            }.onFailure { e -> _uiState.update { it.copy(errorMessage = e.message) } }
        }
    }

    fun bookRepair(req: RepairBookRequest, onBooked: (RepairJobDto) -> Unit = {}) {
        viewModelScope.launch {
            runCatching {
                val job = repository.bookRepair(req)
                _uiState.update { it.copy(bannerMessage = "Repair ${job.id} booked (£29.00 diagnostic assessment paid).") }
                refreshAll()
                onBooked(job)
            }.onFailure { e -> _uiState.update { it.copy(errorMessage = e.message) } }
        }
    }

    fun simulateIssueRepairQuote(job: RepairJobDto, totalPence: Long, materialChange: Boolean, scopeSummary: String) {
        viewModelScope.launch {
            runCatching {
                repository.issueRepairQuote(
                    jobId = job.id,
                    totalPence = totalPence,
                    partsGrade = PartsGrade.OEM_ORIGINAL,
                    partsLimitations = "Includes 6-month parts & workmanship guarantee; liquid corrosion excluded.",
                    scopeSummary = scopeSummary,
                    materialChange = materialChange,
                    expectedVersion = job.version
                )
                _uiState.update { it.copy(bannerMessage = "Quote issued for ${job.id} (${MoneyFormat.gbp(totalPence)}).") }
                refreshAll()
            }.onFailure { e -> _uiState.update { it.copy(errorMessage = e.message) } }
        }
    }

    fun advanceRepairProgress(job: RepairJobDto, targetStatus: RepairStatus) {
        viewModelScope.launch {
            runCatching {
                repository.advanceRepair(job.id, targetStatus)
                _uiState.update { it.copy(bannerMessage = "Repair ${job.id} updated to ${targetStatus.label}.") }
                refreshAll()
            }.onFailure { e -> _uiState.update { it.copy(errorMessage = e.message) } }
        }
    }

    fun decideRepairQuote(job: RepairJobDto, quoteVersion: Int, approve: Boolean) {
        viewModelScope.launch {
            runCatching {
                val updated = repository.decideRepairQuote(
                    job.id,
                    QuoteDecisionRequest(quoteVersion, approve, job.version, "dec-${job.id}-v$quoteVersion-$approve")
                )
                _uiState.update {
                    it.copy(
                        bannerMessage = if (approve)
                            "Quote v$quoteVersion approved. Balance after £29 credit: ${MoneyFormat.gbp(updated.approvedRemainingPence ?: 0L)}."
                        else
                            "Quote v$quoteVersion declined. Diagnostic-only fee retained."
                    )
                }
                refreshAll()
            }.onFailure { e -> _uiState.update { it.copy(errorMessage = e.message) } }
        }
    }

    fun submitWarrantyReturn(jobId: String, recurringFault: String) {
        viewModelScope.launch {
            runCatching {
                repository.openWarrantyReturn(jobId, WarrantyReturnRequest(recurringFault, "wr-$jobId-${UUID.randomUUID()}"))
                _uiState.update {
                    it.copy(bannerMessage = "Warranty return routed for bench assessment. No fresh diagnostic fee charged.")
                }
                refreshAll()
            }.onFailure { e -> _uiState.update { it.copy(errorMessage = e.message) } }
        }
    }

    fun holdWorkshopSeat(eventId: String, attendeeName: String, attendeeEmail: String) {
        viewModelScope.launch {
            runCatching {
                val booking = repository.holdWorkshopSeat(
                    eventId,
                    WorkshopHoldRequest(attendeeName, attendeeEmail, "ws-${eventId}-${UUID.randomUUID()}")
                )
                _uiState.update {
                    it.copy(
                        bannerMessage = if (booking.status == WorkshopBookingStatus.HELD)
                            "10-minute seat hold created (${booking.id}). Confirm to lock your place."
                        else
                            "Workshop full — added to waitlist (${booking.id})."
                    )
                }
                refreshAll()
            }.onFailure { e -> _uiState.update { it.copy(errorMessage = e.message) } }
        }
    }

    fun confirmWorkshopBooking(bookingId: String) {
        viewModelScope.launch {
            runCatching {
                repository.confirmWorkshopBooking(bookingId)
                _uiState.update { it.copy(bannerMessage = "Workshop booking $bookingId confirmed!") }
                refreshAll()
            }.onFailure { e -> _uiState.update { it.copy(errorMessage = e.message) } }
        }
    }

    fun cancelWorkshopBooking(bookingId: String) {
        viewModelScope.launch {
            runCatching {
                repository.cancelWorkshopBooking(bookingId)
                _uiState.update { it.copy(bannerMessage = "Workshop booking $bookingId cancelled and refunded.") }
                refreshAll()
            }.onFailure { e -> _uiState.update { it.copy(errorMessage = e.message) } }
        }
    }

    fun simulateExpireWorkshopHold(bookingId: String) {
        viewModelScope.launch {
            runCatching {
                repository.expireWorkshopHold(bookingId)
                _uiState.update { it.copy(bannerMessage = "Simulated hold expiry for $bookingId — seat released back to capacity.") }
                refreshAll()
            }.onFailure { e -> _uiState.update { it.copy(errorMessage = e.message) } }
        }
    }

    fun simulateCompetingPurchaseOfLastRoboticsKit() {
        viewModelScope.launch {
            runCatching {
                val res = repository.apiClient.reserveStock(
                    ReserveRequest(
                        basketId = "rival-buyer-basket",
                        storeId = "store-sheffield",
                        items = listOf(BasketLineRequest("VW-ROB-ARM4", 1)),
                        idempotencyKey = "rival-${UUID.randomUUID()}"
                    )
                )
                _uiState.update {
                    it.copy(
                        bannerMessage = "Competing customer reserved the last Robotics Explorer Kit (${res.first().id}) at Sheffield! Trying to reserve it now will be safely blocked."
                    )
                }
                refreshAll()
            }.onFailure { e ->
                _uiState.update { it.copy(errorMessage = "Last Robotics Kit already reserved/unavailable: ${e.message}") }
            }
        }
    }

    fun registerTradeAccount(org: String, regNo: String, vat: String?) {
        viewModelScope.launch {
            runCatching {
                val acc = repository.apiClient.createTradeAccount(TradeAccountRequest(org, regNo, vat?.ifBlank { null }))
                _uiState.update {
                    it.copy(bannerMessage = "Trade account ${acc.id} created for ${acc.organisationName}. Credit terms require Finance approval (Credit Approved: No).")
                }
                refreshAll()
            }.onFailure { e -> _uiState.update { it.copy(errorMessage = e.message) } }
        }
    }

    fun submitTradeQuote(accountId: String, poRef: String, notes: String) {
        viewModelScope.launch {
            runCatching {
                val lines = _uiState.value.basketItems.ifEmpty {
                    listOf(BasketDraftEntity("VW-RES-10K-10PK", "prod-resistor-pack", "Resistor Pack", "10-Piece", 10, 10, 125, 12))
                }.map { BasketLineRequest(it.sku, it.packCount) }
                val q = repository.apiClient.submitTradeQuote(TradeQuoteRequest(accountId, poRef, notes, lines))
                _uiState.update { it.copy(bannerMessage = "Trade quote ${q.id} submitted (${MoneyFormat.gbp(q.totalPence)}).") }
                refreshAll()
            }.onFailure { e -> _uiState.update { it.copy(errorMessage = e.message) } }
        }
    }

    fun submitBuildingCentreEnquiry(org: String, email: String, scope: String, summary: String) {
        viewModelScope.launch {
            runCatching {
                val enq = repository.apiClient.submitBuildingCentreEnquiry(BuildingCentreEnquiryRequest(org, email, scope, summary))
                _uiState.update { it.copy(bannerMessage = "Building Centre enquiry ${enq.id} assigned to engineering desk.") }
                refreshAll()
            }.onFailure { e -> _uiState.update { it.copy(errorMessage = e.message) } }
        }
    }

    fun toggleOfflineMode(enabled: Boolean) {
        repository.setOfflineMode(enabled)
        _uiState.update {
            it.copy(
                offlineMode = enabled,
                bannerMessage = if (enabled) "Offline Mode enabled: showing cached catalogue, receipts & repairs." else "Back online: live server validation active."
            )
        }
        if (!enabled) refreshAll()
    }

    fun signIn(email: String) {
        _uiState.update { it.copy(signedInEmail = email.trim(), bannerMessage = "Signed in as ${email.trim()}") }
    }

    fun signOut() {
        _uiState.update { it.copy(signedInEmail = null, biometricLockEnabled = false, biometricUnlocked = true, bannerMessage = "Signed out (guest checkout active).") }
    }

    fun setBiometricLock(enabled: Boolean) {
        _uiState.update { it.copy(biometricLockEnabled = enabled, biometricUnlocked = !enabled || it.biometricUnlocked) }
    }

    fun setBiometricUnlocked(unlocked: Boolean) {
        _uiState.update { it.copy(biometricUnlocked = unlocked) }
    }

    fun setReducedMotion(enabled: Boolean) {
        _uiState.update { it.copy(reducedMotion = enabled) }
    }

    fun setPushEnabled(enabled: Boolean) {
        _uiState.update { it.copy(pushEnabled = enabled) }
    }

    fun clearMessages() {
        _uiState.update { it.copy(bannerMessage = null, errorMessage = null) }
    }

    class Factory(private val repository: VoltworksRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = VoltworksViewModel(repository) as T
    }
}
