package com.example.data.local

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "basket_drafts")
data class BasketDraftEntity(
    @PrimaryKey val sku: String,
    val productId: String,
    val title: String,
    val variantLabel: String,
    val packCount: Int,
    val unitsPerPack: Int,
    val packPricePence: Long,
    val unitPricePence: Long,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_products")
data class CachedProductEntity(
    @PrimaryKey val productId: String,
    val jsonPayload: String,
    val cachedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_orders")
data class CachedOrderEntity(
    @PrimaryKey val orderId: String,
    val jsonPayload: String,
    val cachedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_repairs")
data class CachedRepairEntity(
    @PrimaryKey val repairJobId: String,
    val jsonPayload: String,
    val cachedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "sync_metadata")
data class SyncMetadataEntity(
    @PrimaryKey val key: String,
    val lastSyncedMillis: Long,
    val statusNote: String
)

@Dao
interface BasketDraftDao {
    @Query("SELECT * FROM basket_drafts ORDER BY updatedAtMillis DESC")
    fun observeBasket(): Flow<List<BasketDraftEntity>>

    @Query("SELECT * FROM basket_drafts")
    suspend fun getBasketOnce(): List<BasketDraftEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertItem(item: BasketDraftEntity)

    @Query("DELETE FROM basket_drafts WHERE sku = :sku")
    suspend fun deleteBySku(sku: String)

    @Query("DELETE FROM basket_drafts")
    suspend fun clearBasket()
}

@Dao
interface CacheDao {
    @Query("SELECT * FROM cached_products")
    fun observeCachedProducts(): Flow<List<CachedProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProducts(items: List<CachedProductEntity>)

    @Query("SELECT * FROM cached_orders ORDER BY cachedAtMillis DESC")
    fun observeCachedOrders(): Flow<List<CachedOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOrders(items: List<CachedOrderEntity>)

    @Query("SELECT * FROM cached_repairs ORDER BY cachedAtMillis DESC")
    fun observeCachedRepairs(): Flow<List<CachedRepairEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRepairs(items: List<CachedRepairEntity>)

    @Query("SELECT * FROM sync_metadata WHERE key = :key LIMIT 1")
    fun observeSyncMeta(key: String): Flow<SyncMetadataEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSyncMeta(meta: SyncMetadataEntity)
}

@Database(
    entities = [
        BasketDraftEntity::class,
        CachedProductEntity::class,
        CachedOrderEntity::class,
        CachedRepairEntity::class,
        SyncMetadataEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class VoltworksDatabase : RoomDatabase() {
    abstract fun basketDraftDao(): BasketDraftDao
    abstract fun cacheDao(): CacheDao

    companion object {
        @Volatile
        private var INSTANCE: VoltworksDatabase? = null

        fun getInstance(context: Context): VoltworksDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    VoltworksDatabase::class.java,
                    "voltworks_local.db"
                ).fallbackToDestructiveMigration(dropAllTables = true).build().also { INSTANCE = it }
            }
        }
    }
}
