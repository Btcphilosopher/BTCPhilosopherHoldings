package com.example.data.repo

import com.example.data.local.*
import com.example.data.model.*
import com.example.data.remote.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.json.Json

class OfflineBlockedException(message: String) : RuntimeException(message)

/**
 * Unified repository bridging Ktor Client API calls and Room local persistence (basket drafts + offline cache).
 * Enforces that offline mode can inspect cached products/receipts/repairs with freshness metadata,
 * while checkout, stock reservation, repair approval, and workshop seat holds require server validation.
 */
class VoltworksRepository(
    val apiClient: VoltworksApiClient,
    private val database: VoltworksDatabase
) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val basketDao = database.basketDraftDao()
    private val cacheDao = database.cacheDao()

    private val _offlineMode = MutableStateFlow(false)
    val offlineMode: StateFlow<Boolean> = _offlineMode.asStateFlow()

    val basketDrafts: Flow<List<BasketDraftEntity>> = basketDao.observeBasket()

    val cachedProducts: Flow<List<ProductDto>> = cacheDao.observeCachedProducts().map { rows ->
        rows.mapNotNull { runCatching { json.decodeFromString<ProductDto>(it.jsonPayload) }.getOrNull() }
    }

    val cachedOrders: Flow<List<OrderDto>> = cacheDao.observeCachedOrders().map { rows ->
        rows.mapNotNull { runCatching { json.decodeFromString<OrderDto>(it.jsonPayload) }.getOrNull() }
    }

    val cachedRepairs: Flow<List<RepairJobDto>> = cacheDao.observeCachedRepairs().map { rows ->
        rows.mapNotNull { runCatching { json.decodeFromString<RepairJobDto>(it.jsonPayload) }.getOrNull() }
    }

    val syncFreshness: Flow<SyncMetadataEntity?> = cacheDao.observeSyncMeta("catalog_sync")

    fun setOfflineMode(offline: Boolean) {
        _offlineMode.value = offline
    }

    private fun requireOnline(actionLabel: String) {
        if (_offlineMode.value) {
            throw OfflineBlockedException("$actionLabel requires live server validation. Disable Offline Mode to continue.")
        }
    }

    suspend fun refreshFromServer() {
        if (_offlineMode.value) return
        val products = apiClient.getProducts()
        val orders = apiClient.getOrders()
        val repairs = apiClient.getRepairs()
        val now = System.currentTimeMillis()
        cacheDao.upsertProducts(products.map { CachedProductEntity(it.id, json.encodeToString(it), now) })
        cacheDao.upsertOrders(orders.map { CachedOrderEntity(it.id, json.encodeToString(it), now) })
        cacheDao.upsertRepairs(repairs.map { CachedRepairEntity(it.id, json.encodeToString(it), now) })
        cacheDao.upsertSyncMeta(SyncMetadataEntity("catalog_sync", now, "Live synced"))
    }

    suspend fun addToBasket(product: ProductDto, variant: ProductVariantDto, packCountDelta: Int) {
        val current = basketDao.getBasketOnce().firstOrNull { it.sku == variant.sku }
        val nextCount = ((current?.packCount ?: 0) + packCountDelta).coerceAtLeast(variant.minPackQuantity)
        val tierPrice = variant.tiers.filter { nextCount >= it.minPacks }.maxByOrNull { it.minPacks }?.packPricePence
            ?: variant.packPricePence
        val unitEffective = if (variant.packQuantity > 0) tierPrice / variant.packQuantity else tierPrice
        basketDao.upsertItem(
            BasketDraftEntity(
                sku = variant.sku,
                productId = product.id,
                title = product.familyName,
                variantLabel = variant.variantLabel,
                packCount = nextCount,
                unitsPerPack = variant.packQuantity,
                packPricePence = tierPrice,
                unitPricePence = unitEffective
            )
        )
    }

    suspend fun updateBasketQuantity(sku: String, packCount: Int, variant: ProductVariantDto?) {
        if (packCount <= 0) {
            basketDao.deleteBySku(sku)
            return
        }
        val current = basketDao.getBasketOnce().firstOrNull { it.sku == sku } ?: return
        val minPack = variant?.minPackQuantity ?: 1
        val clamped = packCount.coerceAtLeast(minPack)
        val tierPrice = variant?.tiers?.filter { clamped >= it.minPacks }?.maxByOrNull { it.minPacks }?.packPricePence
            ?: current.packPricePence
        val unitEffective = if (current.unitsPerPack > 0) tierPrice / current.unitsPerPack else tierPrice
        basketDao.upsertItem(
            current.copy(
                packCount = clamped,
                packPricePence = tierPrice,
                unitPricePence = unitEffective,
                updatedAtMillis = System.currentTimeMillis()
            )
        )
    }

    suspend fun clearBasket() = basketDao.clearBasket()

    suspend fun reserveStock(req: ReserveRequest): List<ReservationDto> {
        requireOnline("Inventory reservation")
        return apiClient.reserveStock(req)
    }

    suspend fun payOrder(req: CheckoutPayRequest): OrderDto {
        requireOnline("Checkout payment")
        val order = apiClient.payOrder(req)
        basketDao.clearBasket()
        refreshFromServer()
        return order
    }

    suspend fun markOrderReady(orderId: String, expectedVersion: Int): OrderDto {
        requireOnline("Order readiness update")
        val updated = apiClient.markOrderReadyForCollection(orderId, expectedVersion)
        refreshFromServer()
        return updated
    }

    suspend fun collectOrder(orderId: String, collectionRef: String, expectedVersion: Int): OrderDto {
        requireOnline("Order collection handover")
        val updated = apiClient.collectOrder(orderId, CollectOrderApiRequest(collectionRef, expectedVersion))
        refreshFromServer()
        return updated
    }

    suspend fun bookRepair(req: RepairBookRequest): RepairJobDto {
        requireOnline("Repair booking")
        val job = apiClient.bookRepair(req)
        refreshFromServer()
        return job
    }

    suspend fun advanceRepair(jobId: String, target: RepairStatus): RepairJobDto {
        requireOnline("Repair status update")
        val updated = apiClient.advanceRepair(jobId, AdvanceRepairApiRequest(target))
        refreshFromServer()
        return updated
    }

    suspend fun issueRepairQuote(
        jobId: String,
        totalPence: Long,
        partsGrade: PartsGrade,
        partsLimitations: String,
        scopeSummary: String,
        materialChange: Boolean,
        expectedVersion: Int
    ): RepairJobDto {
        requireOnline("Quote issuance")
        val updated = apiClient.issueRepairQuote(
            jobId,
            CreateQuoteApiRequest(totalPence, partsGrade, partsLimitations, scopeSummary, materialChange, expectedVersion)
        )
        refreshFromServer()
        return updated
    }

    suspend fun decideRepairQuote(jobId: String, req: QuoteDecisionRequest): RepairJobDto {
        requireOnline("Repair quote approval")
        val updated = apiClient.decideRepairQuote(jobId, req)
        refreshFromServer()
        return updated
    }

    suspend fun openWarrantyReturn(jobId: String, req: WarrantyReturnRequest): RepairJobDto {
        requireOnline("Warranty return submission")
        val updated = apiClient.openWarrantyReturn(jobId, req)
        refreshFromServer()
        return updated
    }

    suspend fun holdWorkshopSeat(eventId: String, req: WorkshopHoldRequest): WorkshopBookingDto {
        requireOnline("Workshop seat hold")
        return apiClient.holdWorkshopSeat(eventId, req)
    }

    suspend fun confirmWorkshopBooking(bookingId: String): WorkshopBookingDto {
        requireOnline("Workshop confirmation")
        return apiClient.confirmWorkshopBooking(bookingId)
    }

    suspend fun cancelWorkshopBooking(bookingId: String): WorkshopBookingDto {
        requireOnline("Workshop cancellation")
        return apiClient.cancelWorkshopBooking(bookingId)
    }

    suspend fun expireWorkshopHold(bookingId: String): WorkshopBookingDto {
        requireOnline("Workshop hold simulation")
        return apiClient.expireWorkshopHold(bookingId)
    }
}
