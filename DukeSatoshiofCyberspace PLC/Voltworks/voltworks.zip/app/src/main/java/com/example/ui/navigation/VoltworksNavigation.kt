package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
sealed interface VoltworksRoute {
    @Serializable data object Home : VoltworksRoute
    @Serializable data class Shop(val initialCategory: String = "All", val initialQuery: String = "") : VoltworksRoute
    @Serializable data class ProductDetail(val productId: String) : VoltworksRoute
    @Serializable data object Basket : VoltworksRoute
    @Serializable data class Services(val initialTab: Int = 0) : VoltworksRoute
    @Serializable data class RepairTracker(val jobId: String? = null) : VoltworksRoute
    @Serializable data object Stores : VoltworksRoute
    @Serializable data object Account : VoltworksRoute
}

enum class TopTab(val label: String) {
    HOME("Home"),
    SHOP("Shop"),
    SERVICES("Services"),
    STORES("Stores"),
    ACCOUNT("Account")
}
