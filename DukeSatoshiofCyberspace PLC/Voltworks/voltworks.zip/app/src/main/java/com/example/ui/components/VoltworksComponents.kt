package com.example.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.MoneyFormat
import com.example.data.model.ProductDto
import com.example.ui.theme.*

@DrawableRes
fun resolveVoltworksDrawable(key: String?): Int = when (key) {
    "img_prod_soldering" -> R.drawable.img_prod_soldering
    "img_prod_multimeter" -> R.drawable.img_prod_multimeter
    "img_hero_repair" -> R.drawable.img_hero_repair
    else -> R.drawable.img_hero_makers
}

/**
 * Angular interlocking V/W Voltworks emblem drawn cleanly on Canvas matching the brand reference.
 */
@Composable
fun VoltworksEmblem(
    modifier: Modifier = Modifier,
    size: Dp = 30.dp
) {
    val logoCd = stringResource(R.string.cd_brand_logo)
    Canvas(
        modifier = modifier
            .size(width = size * 1.35f, height = size)
            .semantics { contentDescription = logoCd }
    ) {
        val w = this.size.width
        val h = this.size.height
        val stroke = Stroke(width = h * 0.16f, cap = StrokeCap.Butt, join = StrokeJoin.Miter)

        // Left white angular V
        val whitePath = Path().apply {
            moveTo(w * 0.04f, h * 0.18f)
            lineTo(w * 0.24f, h * 0.18f)
            lineTo(w * 0.42f, h * 0.82f)
            lineTo(w * 0.56f, h * 0.30f)
        }
        drawPath(whitePath, color = Color.White, style = stroke)

        // Interlocking electric orange angular W/lightning peak
        val orangePath = Path().apply {
            moveTo(w * 0.46f, h * 0.62f)
            lineTo(w * 0.58f, h * 0.82f)
            lineTo(w * 0.78f, h * 0.18f)
            lineTo(w * 0.96f, h * 0.18f)
        }
        drawPath(orangePath, color = VoltworksOrange, style = stroke)
    }
}

@Composable
fun VoltworksTopHeader(
    basketCount: Int,
    onBasketClick: () -> Unit,
    showBackButton: Boolean = false,
    onBackClick: () -> Unit = {},
    searchQuery: String? = null,
    onSearchQueryChange: ((String) -> Unit)? = null,
    onSearchSubmit: (() -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(VoltworksNavy)
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            if (showBackButton) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("top_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.cd_back),
                        tint = Color.White
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    VoltworksEmblem(size = 22.dp)
                    Text(
                        text = stringResource(R.string.brand_wordmark),
                        color = Color.White,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp
                        )
                    )
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    VoltworksEmblem(size = 24.dp)
                    Text(
                        text = stringResource(R.string.brand_wordmark),
                        color = Color.White,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp
                        )
                    )
                }
            }

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onBasketClick)
                    .testTag("top_basket_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.ShoppingBag,
                    contentDescription = stringResource(R.string.cd_basket),
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
                if (basketCount > 0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 6.dp, end = 4.dp)
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(VoltworksOrange),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (basketCount > 9) "9+" else basketCount.toString(),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        if (searchQuery != null && onSearchQueryChange != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(VoltworksIvory)
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = stringResource(R.string.cd_search),
                    tint = VoltworksInk,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (searchQuery.isEmpty()) {
                        Text(
                            text = stringResource(R.string.search_placeholder),
                            color = VoltworksSlate,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChange,
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = VoltworksInk),
                        cursorBrush = SolidColor(VoltworksOrange),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { onSearchSubmit?.invoke() }),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_search_input")
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
        }
    }
}

@Composable
fun VoltworksProductCard(
    product: ProductDto,
    stockCount: Int?,
    onOpenProduct: () -> Unit,
    onQuickAdd: () -> Unit,
    modifier: Modifier = Modifier
) {
    val leadVariant = product.variants.first()
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenProduct)
            .testTag("product_card_${product.id}"),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Image(
                painter = painterResource(id = resolveVoltworksDrawable(product.imageKeys.firstOrNull())),
                contentDescription = product.familyName,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(4f / 3f)
                    .clip(RoundedCornerShape(10.dp))
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = product.familyName,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                minLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (leadVariant.packQuantity > 1) {
                Text(
                    text = "${leadVariant.packQuantity}-pack (${MoneyFormat.gbp(leadVariant.unitPricePence)}/ea)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else if (stockCount != null) {
                Text(
                    text = if (stockCount > 0) "$stockCount ready to collect" else "Delivery / check other stores",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (stockCount > 0) VoltworksSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = MoneyFormat.gbp(leadVariant.packPricePence),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(onClick = onQuickAdd)
                        .testTag("quick_add_${product.id}"),
                    contentAlignment = Alignment.CenterEnd
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(VoltworksOrange),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ShoppingCart,
                            contentDescription = "Add ${product.familyName} to basket",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VoltworksSectionPill(
    label: String,
    containerColor: Color,
    contentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(999.dp),
        color = containerColor
    ) {
        Text(
            text = label,
            color = contentColor,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun OfflineFreshnessBanner(
    offlineMode: Boolean,
    lastSyncedMillis: Long?,
    onGoOnline: () -> Unit
) {
    if (!offlineMode) return
    val ageText = if (lastSyncedMillis == null) "Cached locally" else {
        val mins = ((System.currentTimeMillis() - lastSyncedMillis) / 60_000L).coerceAtLeast(0L)
        if (mins == 0L) "Synced <1m ago" else "Synced ${mins}m ago"
    }
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(12.dp),
        color = VoltworksWarningTint,
        border = BorderStroke(1.dp, VoltworksWarning.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Offline mode ($ageText)",
                    style = MaterialTheme.typography.titleSmall,
                    color = VoltworksWarning
                )
                Text(
                    text = "Cached catalogue, receipts & repairs are readable. Checkout, stock holds & approvals require live connection.",
                    style = MaterialTheme.typography.bodySmall,
                    color = VoltworksInk
                )
            }
            TextButton(onClick = onGoOnline) {
                Text("Go online", color = VoltworksOrange, fontWeight = FontWeight.Bold)
            }
        }
    }
}
