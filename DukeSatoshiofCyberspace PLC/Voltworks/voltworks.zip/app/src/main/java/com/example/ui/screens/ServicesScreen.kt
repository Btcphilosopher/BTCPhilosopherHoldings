package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.ui.components.VoltworksSectionPill
import com.example.ui.components.VoltworksTopHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.VoltworksUiState
import java.util.UUID

@Composable
fun ServicesScreen(
    state: VoltworksUiState,
    initialTab: Int,
    onOpenBasket: () -> Unit,
    onSelectStore: (String) -> Unit,
    onBookRepair: (RepairBookRequest, (RepairJobDto) -> Unit) -> Unit,
    onOpenRepairTracker: (String?) -> Unit,
    onHoldWorkshopSeat: (String, String, String) -> Unit,
    onConfirmWorkshopBooking: (String) -> Unit,
    onCancelWorkshopBooking: (String) -> Unit,
    onExpireWorkshopHold: (String) -> Unit
) {
    var activeTab by remember(initialTab) { mutableIntStateOf(initialTab) }
    var selectedCategory by remember { mutableStateOf(RepairCategory.LAPTOP_PC) }
    var selectedDateIdx by remember { mutableIntStateOf(1) }
    var showStoreDialog by remember { mutableStateOf(false) }
    var showBookingModal by remember { mutableStateOf(false) }
    var showWorkshopHoldDialog by remember { mutableStateOf<WorkshopEventDto?>(null) }

    val dates = listOf("Tue" to "28 Jan", "Wed" to "29 Jan", "Thu" to "30 Jan", "Fri" to "31 Jan", "Sat" to "1 Feb")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        VoltworksTopHeader(
            basketCount = state.basketTotalCount,
            onBasketClick = onOpenBasket
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Hero Banner matching right phone mockup: Repair. Learn. Build.
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 190.dp, max = 225.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_hero_repair),
                        contentDescription = "Voltworks technician repairing laptop motherboard",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        VoltworksNavy.copy(alpha = 0.88f),
                                        VoltworksNavy.copy(alpha = 0.45f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(horizontal = 20.dp, vertical = 16.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.services_headline_1),
                            color = Color.White,
                            style = MaterialTheme.typography.displayLarge.copy(fontSize = 31.sp, lineHeight = 33.sp)
                        )
                        Text(
                            text = stringResource(R.string.services_headline_2),
                            color = Color.White,
                            style = MaterialTheme.typography.displayLarge.copy(fontSize = 31.sp, lineHeight = 33.sp)
                        )
                        Text(
                            text = stringResource(R.string.services_headline_3),
                            color = VoltworksOrange,
                            style = MaterialTheme.typography.displayLarge.copy(fontSize = 31.sp, lineHeight = 33.sp)
                        )
                    }
                }
            }

            // Segmented switch between Repairs & Practical Workshops
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = activeTab == 0,
                        onClick = { activeTab = 0 },
                        label = { Text("Book a repair") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("services_tab_repairs"),
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = VoltworksOrangeTint, selectedLabelColor = VoltworksOrangeDark)
                    )
                    FilterChip(
                        selected = activeTab == 1,
                        onClick = { activeTab = 1 },
                        label = { Text("Workshops (${state.workshops.size})") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("services_tab_workshops"),
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = VoltworksOrangeTint, selectedLabelColor = VoltworksOrangeDark)
                    )
                }
            }

            if (activeTab == 0) {
                item {
                    Column(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.book_repair_title),
                            style = MaterialTheme.typography.headlineLarge
                        )
                        Text(
                            text = stringResource(R.string.book_repair_subtitle),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        // 3 main cards matching mockup + 4th "Other equipment" chip
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            RepairCategoryTile(
                                label = "Laptop &\nPC",
                                icon = Icons.Outlined.LaptopMac,
                                selected = selectedCategory == RepairCategory.LAPTOP_PC,
                                onClick = { selectedCategory = RepairCategory.LAPTOP_PC },
                                modifier = Modifier.weight(1f)
                            )
                            RepairCategoryTile(
                                label = "Phone &\nTablet",
                                icon = Icons.Outlined.Smartphone,
                                selected = selectedCategory == RepairCategory.PHONE_TABLET,
                                onClick = { selectedCategory = RepairCategory.PHONE_TABLET },
                                modifier = Modifier.weight(1f)
                            )
                            RepairCategoryTile(
                                label = "Console &\nController",
                                icon = Icons.Outlined.SportsEsports,
                                selected = selectedCategory == RepairCategory.CONSOLE_CONTROLLER,
                                onClick = { selectedCategory = RepairCategory.CONSOLE_CONTROLLER },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        FilterChip(
                            selected = selectedCategory == RepairCategory.OTHER_EQUIPMENT,
                            onClick = { selectedCategory = RepairCategory.OTHER_EQUIPMENT },
                            label = { Text("Other supported electronics / bench equipment") }
                        )

                        // Diagnostic assessment radio card (£29 credited towards approved repair)
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            color = VoltworksOrangeTint,
                            border = BorderStroke(1.5.dp, VoltworksOrange)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                        .padding(4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape)
                                            .background(VoltworksOrange)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(stringResource(R.string.diagnostic_title), style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        stringResource(R.string.diagnostic_subtitle),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text("£29", style = MaterialTheme.typography.titleLarge, color = VoltworksInk)
                            }
                        }

                        Text("Choose a date", style = MaterialTheme.typography.titleMedium)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            dates.forEachIndexed { idx, (day, date) ->
                                val isSel = idx == selectedDateIdx
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = 56.dp)
                                        .clickable { selectedDateIdx = idx },
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isSel) VoltworksOrangeTint else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(if (isSel) 1.5.dp else 1.dp, if (isSel) VoltworksOrange else MaterialTheme.colorScheme.outline)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Text(
                                            text = day,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (isSel) VoltworksOrangeDark else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = date,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSel) VoltworksOrangeDark else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }

                        Text("Choose a store", style = MaterialTheme.typography.titleMedium)
                        val store = state.selectedStore
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showStoreDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Outlined.LocationOn, contentDescription = null, tint = VoltworksNavy)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(store?.name ?: "Sheffield flagship", style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "${store?.addressLine ?: "Unit 1, Meadowhall Way"}, ${store?.postcode ?: "S9 1EP"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Select store")
                            }
                        }

                        Button(
                            onClick = { showBookingModal = true },
                            enabled = !state.offlineMode,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 52.dp)
                                .testTag("services_choose_appointment_btn")
                        ) {
                            Icon(Icons.Outlined.Event, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(stringResource(R.string.choose_appointment), style = MaterialTheme.typography.titleMedium)
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onOpenRepairTracker(state.repairs.firstOrNull()?.id) }
                                .padding(vertical = 10.dp)
                                .testTag("services_track_repair_link"),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.Handyman, contentDescription = null, tint = VoltworksOrange, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.track_existing_repair),
                                color = VoltworksOrange,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = VoltworksOrange, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            } else {
                // Practical Workshops & Learning (BST timezone-aware, seat holds, waitlist, cancellation/refund)
                if (state.workshopBookings.isNotEmpty()) {
                    item {
                        Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Your Workshop Seat Holds & Bookings", style = MaterialTheme.typography.titleLarge)
                            state.workshopBookings.forEach { booking ->
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, VoltworksOrange.copy(alpha = 0.5f))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("${booking.eventTitle} (${booking.id})", style = MaterialTheme.typography.titleSmall)
                                            VoltworksSectionPill(
                                                label = booking.status.name,
                                                containerColor = if (booking.status == WorkshopBookingStatus.CONFIRMED) VoltworksSuccessTint else VoltworksOrangeTint,
                                                contentColor = if (booking.status == WorkshopBookingStatus.CONFIRMED) VoltworksSuccess else VoltworksOrangeDark
                                            )
                                        }
                                        Text("${booking.startsAtLondonFormatted} · ${booking.attendeeName}", style = MaterialTheme.typography.bodySmall)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            if (booking.status == WorkshopBookingStatus.HELD) {
                                                Button(
                                                    onClick = { onConfirmWorkshopBooking(booking.id) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange),
                                                    modifier = Modifier.testTag("ws_confirm_${booking.id}")
                                                ) { Text("Confirm & Pay") }
                                                OutlinedButton(
                                                    onClick = { onExpireWorkshopHold(booking.id) },
                                                    modifier = Modifier.testTag("ws_expire_${booking.id}")
                                                ) { Text("Demo: Expire Hold") }
                                            } else if (booking.status == WorkshopBookingStatus.CONFIRMED) {
                                                OutlinedButton(onClick = { onCancelWorkshopBooking(booking.id) }) {
                                                    Text("Cancel & Refund")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                items(state.workshops, key = { it.id }) { ws ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(ws.title, style = MaterialTheme.typography.titleLarge)
                                Text(MoneyFormat.gbp(ws.pricePence), style = MaterialTheme.typography.titleLarge, color = VoltworksOrangeDark)
                            }
                            Text("${ws.storeName} (${ws.venueRoom}) · Instructor: ${ws.instructorName}", style = MaterialTheme.typography.titleSmall)
                            Text("Starts: ${ws.startsAtLondonFormatted} (${ws.durationMinutes} mins)", style = MaterialTheme.typography.bodySmall, color = VoltworksNavy, fontWeight = FontWeight.SemiBold)
                            Text(ws.description, style = MaterialTheme.typography.bodySmall)
                            Text("Prerequisites: ${ws.prerequisites}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Equipment: ${ws.equipmentProvided}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Age policy: ${ws.agePolicy} · ${ws.cancellationTerms}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                VoltworksSectionPill(
                                    label = if (ws.availableSeats > 0) "${ws.availableSeats} of ${ws.capacity} seats left" else "Full — Waitlist open",
                                    containerColor = if (ws.availableSeats > 0) VoltworksSuccessTint else VoltworksWarningTint,
                                    contentColor = if (ws.availableSeats > 0) VoltworksSuccess else VoltworksWarning
                                )
                                Button(
                                    onClick = { showWorkshopHoldDialog = ws },
                                    enabled = !state.offlineMode,
                                    colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange),
                                    modifier = Modifier.testTag("ws_hold_btn_${ws.id}")
                                ) {
                                    Text(if (ws.availableSeats > 0) "Hold seat" else "Join waitlist")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showStoreDialog) {
        AlertDialog(
            onDismissRequest = { showStoreDialog = false },
            title = { Text("Choose repair store") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.stores.filter { it.supportsRepairs }.forEach { st ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectStore(st.id)
                                    showStoreDialog = false
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = if (st.id == state.selectedStoreId) VoltworksOrangeTint else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, if (st.id == state.selectedStoreId) VoltworksOrange else MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(st.name, style = MaterialTheme.typography.titleSmall)
                                Text("${st.addressLine}, ${st.postcode}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showStoreDialog = false }) { Text("Close") } }
        )
    }

    if (showBookingModal) {
        var deviceModel by remember { mutableStateOf("ThinkPad X1 Carbon Gen 11") }
        var serialNo by remember { mutableStateOf("PF-49201-UK") }
        var fault by remember { mutableStateOf("USB-C charging port intermittent and battery not charging") }
        var customerName by remember { mutableStateOf("Alex Maker") }
        var customerContact by remember { mutableStateOf(state.checkout.customerEmail) }
        var selectedTimeSlot by remember { mutableStateOf("10:30 Intake") }
        var accessMode by remember { mutableStateOf("GUEST_PROFILE_AT_BENCH") }
        var consentChecked by remember { mutableStateOf(true) }

        val datePair = dates[selectedDateIdx]
        AlertDialog(
            onDismissRequest = { showBookingModal = false },
            title = { Text("Confirm Intake Appointment (£29)") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 420.dp)) {
                    item {
                        Text(
                            "Reserves an intake slot at ${state.selectedStore?.name} on ${datePair.first} ${datePair.second}. Completion time is confirmed after bench inspection.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("10:30 Intake", "14:00 Intake").forEach { slot ->
                                FilterChip(selected = selectedTimeSlot == slot, onClick = { selectedTimeSlot = slot }, label = { Text(slot) })
                            }
                        }
                    }
                    item { OutlinedTextField(value = deviceModel, onValueChange = { deviceModel = it }, label = { Text("Device model") }, modifier = Modifier.fillMaxWidth()) }
                    item { OutlinedTextField(value = serialNo, onValueChange = { serialNo = it }, label = { Text("Serial number (optional)") }, modifier = Modifier.fillMaxWidth()) }
                    item { OutlinedTextField(value = fault, onValueChange = { fault = it }, label = { Text("Reported fault") }, modifier = Modifier.fillMaxWidth()) }
                    item { OutlinedTextField(value = customerName, onValueChange = { customerName = it }, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth()) }
                    item { OutlinedTextField(value = customerContact, onValueChange = { customerContact = it }, label = { Text("Contact email / phone") }, modifier = Modifier.fillMaxWidth()) }
                    item {
                        Text("Device access procedure (never enter passwords here):", style = MaterialTheme.typography.labelMedium)
                        Column {
                            listOf(
                                "GUEST_PROFILE_AT_BENCH" to "Separate repair/guest profile (no password stored)",
                                "IN_PERSON_UNLOCK_AT_INTAKE" to "Customer unlocks device in person at bench"
                            ).forEach { (mode, desc) ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.clickable { accessMode = mode }
                                ) {
                                    RadioButton(selected = accessMode == mode, onClick = { accessMode = mode })
                                    Text(desc, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = consentChecked, onCheckedChange = { consentChecked = it })
                            Text("I consent to bench diagnostics & ESD testing (no wipe without approval).", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = consentChecked && deviceModel.isNotBlank() && fault.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange),
                    onClick = {
                        showBookingModal = false
                        onBookRepair(
                            RepairBookRequest(
                                customerName = customerName,
                                customerContact = customerContact,
                                storeId = state.selectedStoreId,
                                category = selectedCategory,
                                deviceModel = deviceModel,
                                serialNumber = serialNo.ifBlank { null },
                                reportedFault = fault,
                                appointmentSlotLabel = "${datePair.first} ${datePair.second} · $selectedTimeSlot",
                                controlledAccessMode = accessMode,
                                dataConsentAccepted = consentChecked,
                                idempotencyKey = "rep-${UUID.randomUUID()}"
                            )
                        ) { booked ->
                            onOpenRepairTracker(booked.id)
                        }
                    },
                    modifier = Modifier.testTag("repair_confirm_pay_29_btn")
                ) {
                    Text("Pay £29 & Book Slot")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBookingModal = false }) { Text("Cancel") }
            }
        )
    }

    showWorkshopHoldDialog?.let { ws ->
        var attendeeName by remember { mutableStateOf("Alex Maker") }
        var attendeeEmail by remember { mutableStateOf(state.checkout.customerEmail) }
        AlertDialog(
            onDismissRequest = { showWorkshopHoldDialog = null },
            title = { Text("Reserve seat: ${ws.title}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${ws.startsAtLondonFormatted} · ${MoneyFormat.gbp(ws.pricePence)}", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(value = attendeeName, onValueChange = { attendeeName = it }, label = { Text("Attendee name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = attendeeEmail, onValueChange = { attendeeEmail = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange),
                    onClick = {
                        onHoldWorkshopSeat(ws.id, attendeeName, attendeeEmail)
                        showWorkshopHoldDialog = null
                    }
                ) {
                    Text(if (ws.availableSeats > 0) "Hold seat (10 min)" else "Join waitlist")
                }
            },
            dismissButton = { TextButton(onClick = { showWorkshopHoldDialog = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun RepairCategoryTile(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .heightIn(min = 90.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (selected) VoltworksOrangeTint else MaterialTheme.colorScheme.surface,
        border = BorderStroke(if (selected) 1.5.dp else 1.dp, if (selected) VoltworksOrange else MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label.replace("\n", " "),
                tint = VoltworksNavy,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
