package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.ui.components.OfflineFreshnessBanner
import com.example.ui.components.VoltworksSectionPill
import com.example.ui.components.VoltworksTopHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.VoltworksUiState

@Composable
fun RepairTrackerScreen(
    state: VoltworksUiState,
    initialJobId: String?,
    onBack: () -> Unit,
    onOpenBasket: () -> Unit,
    onIssueDemoQuote: (RepairJobDto, Long, Boolean, String) -> Unit,
    onAdvanceStatus: (RepairJobDto, RepairStatus) -> Unit,
    onDecideQuote: (RepairJobDto, Int, Boolean) -> Unit,
    onOpenWarrantyReturn: (String, String) -> Unit,
    onDisableOffline: () -> Unit
) {
    var selectedJobId by remember(initialJobId, state.repairs) {
        mutableStateOf(initialJobId ?: state.repairs.firstOrNull()?.id)
    }
    val job = state.repairs.firstOrNull { it.id == selectedJobId } ?: state.repairs.firstOrNull()
    var showWarrantyDialog by remember { mutableStateOf(false) }

    val workflowSteps = listOf(
        RepairStatus.BOOKED,
        RepairStatus.RECEIVED,
        RepairStatus.DIAGNOSING,
        RepairStatus.AWAITING_APPROVAL,
        RepairStatus.AWAITING_PARTS,
        RepairStatus.REPAIRING,
        RepairStatus.TESTING,
        RepairStatus.READY,
        RepairStatus.COLLECTED
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        VoltworksTopHeader(
            basketCount = state.basketTotalCount,
            onBasketClick = onOpenBasket,
            showBackButton = true,
            onBackClick = onBack
        )

        OfflineFreshnessBanner(
            offlineMode = state.offlineMode,
            lastSyncedMillis = state.syncMeta?.lastSyncedMillis,
            onGoOnline = onDisableOffline
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("Repair Tracker & Quotes", style = MaterialTheme.typography.headlineLarge)
                if (state.repairs.size > 1) {
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(state.repairs) { r ->
                            FilterChip(
                                selected = r.id == job?.id,
                                onClick = { selectedJobId = r.id },
                                label = { Text("${r.id} · ${r.deviceModel.take(16)}") }
                            )
                        }
                    }
                }
            }

            if (job == null) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Text("No active repair jobs yet. Book an intake slot from Services.", modifier = Modifier.padding(20.dp))
                    }
                }
            } else {
                // Job Summary + 9-step pipeline
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${job.id} · ${job.deviceModel}", style = MaterialTheme.typography.titleLarge)
                                    Text("${job.storeName} · ${job.appointmentSlotLabel}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                VoltworksSectionPill(
                                    label = job.status.label,
                                    containerColor = VoltworksOrangeTint,
                                    contentColor = VoltworksOrangeDark
                                )
                            }
                            Text("Reported fault: ${job.reportedFault}", style = MaterialTheme.typography.bodySmall)
                            Text("Serial: ${job.serialNumber ?: "Not provided"} · Access: ${job.controlledAccessMode}", style = MaterialTheme.typography.labelSmall)
                            Text("Intake condition: ${job.intakeConditionNotes ?: "Pending check-in"}", style = MaterialTheme.typography.bodySmall)
                            Text("Supplied accessories: ${job.suppliedAccessories ?: "Pending check-in"}", style = MaterialTheme.typography.bodySmall)
                            Text(
                                "Diagnostic fee (£29.00): ${if (job.diagnosticPaid) "Paid" else "Unpaid"} · ${if (job.diagnosticCredited) "Credited towards approved repair" else "Available to credit once"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = VoltworksSuccess,
                                fontWeight = FontWeight.SemiBold
                            )

                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Workshop Progress", style = MaterialTheme.typography.titleSmall)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(workflowSteps) { step ->
                                    val reached = job.status.stepIndex >= step.stepIndex && job.status.stepIndex >= 0
                                    val isCurrent = job.status == step
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = when {
                                            isCurrent -> VoltworksOrange
                                            reached -> VoltworksSuccessTint
                                            else -> VoltworksIvorySubtle
                                        }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(7.dp)
                                                    .clip(CircleShape)
                                                    .background(if (isCurrent) Color.White else if (reached) VoltworksSuccess else VoltworksSlate)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = step.label,
                                                style = MaterialTheme.typography.labelMedium,
                                                color = if (isCurrent) Color.White else if (reached) VoltworksSuccess else VoltworksSlate
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Quotes & Approvals
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Estimates & Customer Approvals", style = MaterialTheme.typography.titleMedium)
                            if (job.quotes.isEmpty()) {
                                Text("Technician inspection in progress — no quote issued yet.", style = MaterialTheme.typography.bodySmall)
                            } else {
                                job.quotes.forEach { quote ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (quote.customerDecision == QuoteDecision.PENDING) VoltworksOrangeTint else VoltworksIvorySubtle,
                                        border = BorderStroke(1.dp, if (quote.customerDecision == QuoteDecision.PENDING) VoltworksOrange else MaterialTheme.colorScheme.outline)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Quote v${quote.quoteVersion}${if (quote.materialChange) " (Material revision)" else ""}", style = MaterialTheme.typography.titleSmall)
                                                Text(quote.customerDecision.name, style = MaterialTheme.typography.labelMedium, color = VoltworksOrangeDark)
                                            }
                                            Text("Scope: ${quote.scopeSummary}", style = MaterialTheme.typography.bodySmall)
                                            Text("Parts grade: ${quote.partsGrade.label} · ${quote.partsLimitations}", style = MaterialTheme.typography.bodySmall)
                                            Text(
                                                "Repair total ${MoneyFormat.gbp(quote.totalPence)} − diagnostic credit ${MoneyFormat.gbp(quote.diagnosticCreditPence)} = ${MoneyFormat.gbp(quote.remainingPence)} remaining",
                                                style = MaterialTheme.typography.titleSmall,
                                                color = VoltworksInk
                                            )
                                            if (quote.customerDecision == QuoteDecision.PENDING) {
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    Button(
                                                        onClick = { onDecideQuote(job, quote.quoteVersion, true) },
                                                        enabled = !state.offlineMode,
                                                        colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange),
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .testTag("repair_approve_quote_${quote.quoteVersion}")
                                                    ) {
                                                        Text("Approve (${MoneyFormat.gbp(quote.remainingPence)} due)")
                                                    }
                                                    OutlinedButton(
                                                        onClick = { onDecideQuote(job, quote.quoteVersion, false) },
                                                        enabled = !state.offlineMode,
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        Text("Decline")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Staff / Demo Bench Controls to walk through all scenarios
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                            Text("Workshop Bench Controls (Demo)", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(
                                    onClick = {
                                        onIssueDemoQuote(job, 14900L, false, "Replace USB-C PD controller IC and ultrasonic board clean")
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("demo_issue_149_quote")
                                ) {
                                    Text("Issue £149 Quote")
                                }
                                OutlinedButton(
                                    onClick = {
                                        onIssueDemoQuote(job, 17900L, true, "Material scope change: replace damaged MOSFET power stage + PD controller")
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("demo_issue_revised_quote")
                                ) {
                                    Text("Revise £179 Quote")
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(
                                    onClick = { onAdvanceStatus(job, RepairStatus.TESTING) },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Move to Testing") }
                                OutlinedButton(
                                    onClick = { onAdvanceStatus(job, RepairStatus.COLLECTED) },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Mark Collected") }
                            }
                        }
                    }
                }

                // Final Test, Collection Receipt, Progress Log & Warranty Return
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Bench Log, Final Test & Warranty Guarantee", style = MaterialTheme.typography.titleMedium)
                            job.finalTestRecord?.let {
                                Text("Final test record: $it", style = MaterialTheme.typography.bodySmall, color = VoltworksSuccess)
                            }
                            job.collectionReceiptRef?.let {
                                Text("Collection receipt: $it", style = MaterialTheme.typography.labelSmall)
                            }
                            job.progressNotes.forEach { note ->
                                Text("• $note", style = MaterialTheme.typography.bodySmall)
                            }
                            job.warrantyReturns.forEach { wr ->
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = VoltworksWarningTint
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("${wr.id}: ${wr.outcome.label}", style = MaterialTheme.typography.titleSmall, color = VoltworksWarning)
                                        Text("Fault: ${wr.reportedRecurringFault}", style = MaterialTheme.typography.bodySmall)
                                        Text(wr.resolutionNotes, style = MaterialTheme.typography.bodySmall)
                                        Text("Fresh diagnostic fee charged: ${if (wr.freshDiagnosticCharged) "Yes" else "No (£0.00)"}", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedButton(
                                onClick = { showWarrantyDialog = true },
                                enabled = !state.offlineMode,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("repair_open_warranty_btn")
                            ) {
                                Text("Report recurring fault / Warranty return (${job.warrantyMonths}-mo guarantee)")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showWarrantyDialog && job != null) {
        var recurringFault by remember { mutableStateOf("USB-C port intermittently drops power again under load") }
        AlertDialog(
            onDismissRequest = { showWarrantyDialog = false },
            title = { Text("Open Warranty Return (${job.id})") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Links directly to ${job.id}. Potentially covered returns are routed for assessment with NO automatic fresh diagnostic charge. Outcome options (warranty assessment, unrelated fault, accidental damage, repeat work, refund) remain distinct.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = recurringFault,
                        onValueChange = { recurringFault = it },
                        label = { Text("Describe recurring fault") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange),
                    onClick = {
                        onOpenWarrantyReturn(job.id, recurringFault)
                        showWarrantyDialog = false
                    },
                    modifier = Modifier.testTag("warranty_submit_btn")
                ) { Text("Route for assessment") }
            },
            dismissButton = { TextButton(onClick = { showWarrantyDialog = false }) { Text("Cancel") } }
        )
    }
}
