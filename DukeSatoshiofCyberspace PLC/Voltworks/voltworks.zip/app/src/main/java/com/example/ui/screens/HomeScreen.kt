package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.ProductDto
import com.example.ui.components.OfflineFreshnessBanner
import com.example.ui.components.VoltworksProductCard
import com.example.ui.components.VoltworksTopHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.VoltworksUiState

private data class HomeCategoryTile(
    val label: String,
    val icon: ImageVector,
    val isWorkshop: Boolean = false
)

@Composable
fun HomeScreen(
    state: VoltworksUiState,
    onSearchSubmit: (String) -> Unit,
    onSelectCategory: (String) -> Unit,
    onOpenWorkshops: () -> Unit,
    onOpenProduct: (String) -> Unit,
    onQuickAdd: (ProductDto) -> Unit,
    onOpenBasket: () -> Unit,
    onOpenStores: () -> Unit,
    onOpenRepairs: () -> Unit,
    onSelectStore: (String) -> Unit,
    onDisableOffline: () -> Unit
) {
    var searchDraft by remember { mutableStateOf("") }
    var showStorePicker by remember { mutableStateOf(false) }

    val primaryCategories = listOf(
        HomeCategoryTile("Components", Icons.Outlined.Memory),
        HomeCategoryTile("Computing", Icons.Outlined.LaptopMac),
        HomeCategoryTile("Robotics", Icons.Outlined.PrecisionManufacturing),
        HomeCategoryTile("Smart Home", Icons.Outlined.Home)
    )
    val secondaryCategories = listOf(
        HomeCategoryTile("Tools & Repair", Icons.Outlined.Build),
        HomeCategoryTile("Workshops", Icons.Outlined.School, isWorkshop = true)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        VoltworksTopHeader(
            basketCount = state.basketTotalCount,
            onBasketClick = onOpenBasket,
            searchQuery = searchDraft,
            onSearchQueryChange = { searchDraft = it },
            onSearchSubmit = { onSearchSubmit(searchDraft) }
        )

        OfflineFreshnessBanner(
            offlineMode = state.offlineMode,
            lastSyncedMillis = state.syncMeta?.lastSyncedMillis,
            onGoOnline = onDisableOffline
        )

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val gridColumns = if (maxWidth >= 700.dp) 3 else 2
            val featured = state.allProducts.filter { it.featured }.ifEmpty { state.allProducts.take(4) }
            val rows = featured.chunked(gridColumns)

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Hero Banner matching reference mockup
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 210.dp, max = 250.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_makers),
                            contentDescription = "Voltworks maker workshop bench",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            VoltworksNavy.copy(alpha = 0.92f),
                                            VoltworksNavy.copy(alpha = 0.60f),
                                            Color.Transparent
                                        )
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .padding(horizontal = 20.dp, vertical = 16.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.home_headline_1),
                                color = Color.White,
                                style = MaterialTheme.typography.displayLarge.copy(fontSize = 30.sp, lineHeight = 31.sp)
                            )
                            Text(
                                text = stringResource(R.string.home_headline_2),
                                color = Color.White,
                                style = MaterialTheme.typography.displayLarge.copy(fontSize = 30.sp, lineHeight = 31.sp)
                            )
                            Text(
                                text = stringResource(R.string.home_headline_3),
                                color = Color.White,
                                style = MaterialTheme.typography.displayLarge.copy(fontSize = 30.sp, lineHeight = 31.sp)
                            )
                            Text(
                                text = stringResource(R.string.home_headline_4),
                                color = VoltworksOrange,
                                style = MaterialTheme.typography.displayLarge.copy(fontSize = 30.sp, lineHeight = 31.sp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { onSelectCategory("All") },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("home_shop_electronics_cta")
                            ) {
                                Text(
                                    text = stringResource(R.string.home_cta_shop),
                                    style = MaterialTheme.typography.labelLarge
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                // 4 primary category tiles matching mockup
                item {
                    Column(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            primaryCategories.forEach { cat ->
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = 84.dp)
                                        .clickable { onSelectCategory(cat.label) }
                                        .testTag("home_cat_${cat.label.lowercase().replace(" ", "_")}"),
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = cat.icon,
                                            contentDescription = cat.label,
                                            tint = VoltworksNavy,
                                            modifier = Modifier.size(26.dp)
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = cat.label,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            textAlign = TextAlign.Center,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }

                        // Tools & Repair + Workshops quick category row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            secondaryCategories.forEach { cat ->
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = 48.dp)
                                        .clickable {
                                            if (cat.isWorkshop) onOpenWorkshops() else onSelectCategory(cat.label)
                                        }
                                        .testTag("home_cat_${cat.label.lowercase().replace(" ", "_")}"),
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(cat.icon, contentDescription = null, tint = VoltworksOrange, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(cat.label, style = MaterialTheme.typography.titleSmall)
                                    }
                                }
                            }
                        }
                    }
                }

                // Selected Local Store & Active Orders/Repairs summary
                item {
                    Column(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val store = state.selectedStore
                        val readySkus = state.selectedStoreInventory.values.count { it.availableToPromise > 0 }
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showStorePicker = true }
                                .testTag("home_selected_store_card"),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Outlined.LocationOn, contentDescription = null, tint = VoltworksOrange)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Local store: ${store?.name ?: "Sheffield flagship"}",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = "$readySkus SKUs ready for ${store?.collectionLeadMinutes ?: 60}-min collection",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = VoltworksSuccess
                                    )
                                }
                                Text("Change", color = VoltworksOrange, style = MaterialTheme.typography.labelLarge)
                            }
                        }

                        if (state.orders.isNotEmpty() || state.repairs.isNotEmpty()) {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(state.orders.take(3), key = { it.id }) { ord ->
                                    Surface(
                                        modifier = Modifier
                                            .widthIn(min = 230.dp)
                                            .clickable(onClick = onOpenBasket),
                                        shape = RoundedCornerShape(12.dp),
                                        color = VoltworksOrangeTint,
                                        border = BorderStroke(1.dp, VoltworksOrange.copy(alpha = 0.45f))
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Text("Order ${ord.id}", style = MaterialTheme.typography.titleSmall, color = VoltworksInk)
                                            Text(
                                                text = ord.fulfilmentStatus.name.replace('_', ' '),
                                                style = MaterialTheme.typography.bodySmall,
                                                color = VoltworksOrangeDark,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                                items(state.repairs.take(3), key = { it.id }) { rep ->
                                    Surface(
                                        modifier = Modifier
                                            .widthIn(min = 230.dp)
                                            .clickable(onClick = onOpenRepairs),
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surface,
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Text("Repair ${rep.id} · ${rep.deviceModel}", style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(
                                                text = "Status: ${rep.status.label}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = VoltworksOrange
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Popular with makers header
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(R.string.popular_with_makers),
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onSelectCategory("All") }
                                .padding(horizontal = 6.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.view_all),
                                color = VoltworksOrange,
                                style = MaterialTheme.typography.labelLarge
                            )
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = null,
                                tint = VoltworksOrange,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Product grid rows
                items(rows) { rowProducts ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        rowProducts.forEach { product ->
                            val sku = product.variants.first().sku
                            val atp = state.selectedStoreInventory[sku]?.availableToPromise
                            VoltworksProductCard(
                                product = product,
                                stockCount = atp,
                                onOpenProduct = { onOpenProduct(product.id) },
                                onQuickAdd = { onQuickAdd(product) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (rowProducts.size < gridColumns) {
                            repeat(gridColumns - rowProducts.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }

                // Collect from your local store banner matching mockup bottom card
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .clickable(onClick = onOpenStores),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Storefront,
                                contentDescription = null,
                                tint = VoltworksNavy,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            HorizontalDivider(
                                modifier = Modifier
                                    .height(34.dp)
                                    .width(1.dp),
                                color = MaterialTheme.colorScheme.outline
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.collect_banner_title),
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = stringResource(R.string.collect_banner_subtitle),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = null,
                                tint = VoltworksOrange
                            )
                        }
                    }
                }
            }
        }
    }

    if (showStorePicker) {
        AlertDialog(
            onDismissRequest = { showStorePicker = false },
            title = { Text("Choose local Voltworks store") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.stores.forEach { st ->
                        val selected = st.id == state.selectedStoreId
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectStore(st.id)
                                    showStorePicker = false
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = if (selected) VoltworksOrangeTint else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, if (selected) VoltworksOrange else MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(st.name, style = MaterialTheme.typography.titleSmall)
                                Text("${st.addressLine}, ${st.postcode}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showStorePicker = false }) { Text("Close") }
            }
        )
    }
}
