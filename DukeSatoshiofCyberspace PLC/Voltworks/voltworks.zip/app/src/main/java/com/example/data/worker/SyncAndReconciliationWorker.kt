package com.example.data.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.VoltworksApp
import com.example.data.local.SyncMetadataEntity

/**
 * WorkManager worker performing deferred cache synchronization and expired hold/reservation sweep.
 */
class SyncAndReconciliationWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val container = (applicationContext as? VoltworksApp)?.container ?: return Result.success()
        return runCatching {
            container.apiClient.sandboxServer.sweepExpiredInternal()
            container.repository.refreshFromServer()
            container.database.cacheDao().upsertSyncMeta(
                SyncMetadataEntity(
                    key = "catalog_sync",
                    lastSyncedMillis = System.currentTimeMillis(),
                    statusNote = "Synced via WorkManager"
                )
            )
            Result.success()
        }.getOrElse {
            Result.retry()
        }
    }
}
