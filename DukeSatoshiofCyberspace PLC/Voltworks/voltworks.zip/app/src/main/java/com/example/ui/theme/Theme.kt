package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val VoltworksLightColors = lightColorScheme(
    primary = VoltworksOrange,
    onPrimary = Color.White,
    primaryContainer = VoltworksOrangeTint,
    onPrimaryContainer = VoltworksOrangeDark,
    secondary = VoltworksNavy,
    onSecondary = Color.White,
    secondaryContainer = VoltworksIvorySubtle,
    onSecondaryContainer = VoltworksInk,
    tertiary = VoltworksSuccess,
    onTertiary = Color.White,
    tertiaryContainer = VoltworksSuccessTint,
    onTertiaryContainer = VoltworksSuccess,
    background = VoltworksIvory,
    onBackground = VoltworksInk,
    surface = VoltworksIvorySurface,
    onSurface = VoltworksInk,
    surfaceVariant = VoltworksIvorySubtle,
    onSurfaceVariant = VoltworksSlate,
    outline = VoltworksBorder,
    outlineVariant = VoltworksBorder,
    error = VoltworksError,
    onError = Color.White,
    errorContainer = VoltworksErrorTint,
    onErrorContainer = VoltworksError
)

private val VoltworksDarkColors = darkColorScheme(
    primary = VoltworksOrange,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF3A1A06),
    onPrimaryContainer = Color(0xFFFFB68B),
    secondary = VoltworksNavyElevated,
    onSecondary = Color.White,
    secondaryContainer = VoltworksDarkSurfaceVariant,
    onSecondaryContainer = VoltworksDarkText,
    tertiary = Color(0xFF47C98F),
    onTertiary = VoltworksNavy,
    tertiaryContainer = Color(0xFF0E3826),
    onTertiaryContainer = Color(0xFF8BE5BC),
    background = VoltworksDarkBg,
    onBackground = VoltworksDarkText,
    surface = VoltworksDarkSurface,
    onSurface = VoltworksDarkText,
    surfaceVariant = VoltworksDarkSurfaceVariant,
    onSurfaceVariant = VoltworksDarkMuted,
    outline = VoltworksDarkBorder,
    outlineVariant = VoltworksDarkBorder,
    error = Color(0xFFFF8A80),
    onError = Color(0xFF4B0904)
)

val VoltworksShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

val LocalReducedMotion = staticCompositionLocalOf { false }

@Composable
fun VoltworksTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    reducedMotion: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) VoltworksDarkColors else VoltworksLightColors
    CompositionLocalProvider(LocalReducedMotion provides reducedMotion) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = VoltworksTypography,
            shapes = VoltworksShapes,
            content = content
        )
    }
}
