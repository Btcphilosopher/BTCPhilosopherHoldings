package com.example

import android.app.Application
import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.data.local.VoltworksDatabase
import com.example.data.remote.VoltworksApiClient
import com.example.data.repo.VoltworksRepository
import com.example.data.worker.SyncAndReconciliationWorker
import java.util.concurrent.TimeUnit

class AppContainer(context: Context) {
    val database: VoltworksDatabase = VoltworksDatabase.getInstance(context)
    val apiClient: VoltworksApiClient = VoltworksApiClient()
    val repository: VoltworksRepository = VoltworksRepository(apiClient, database)
}

class VoltworksApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        scheduleBackgroundSync()
    }

    private fun scheduleBackgroundSync() {
        val request = PeriodicWorkRequestBuilder<SyncAndReconciliationWorker>(
            15, TimeUnit.MINUTES
        ).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "voltworks_reconciliation_sync",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}
