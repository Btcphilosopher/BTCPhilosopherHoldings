package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.MoneyFormat
import com.example.ui.components.VoltworksSectionPill
import com.example.ui.components.VoltworksTopHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.VoltworksUiState

@Composable
fun StoresAndTradeScreen(
    state: VoltworksUiState,
    onOpenBasket: () -> Unit,
    onSelectStore: (String) -> Unit,
    onRegisterTradeAccount: (String, String, String?) -> Unit,
    onSubmitTradeQuote: (String, String, String) -> Unit,
    onSubmitBuildingEnquiry: (String, String, String, String) -> Unit
) {
    var activeTab by remember { mutableIntStateOf(0) }
    var storeSearch by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        VoltworksTopHeader(
            basketCount = state.basketTotalCount,
            onBasketClick = onOpenBasket
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                label = { Text("UK Stores & Stock") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("stores_tab_locations"),
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = VoltworksOrangeTint, selectedLabelColor = VoltworksOrangeDark)
            )
            FilterChip(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                label = { Text("Trade & Building Centre") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("stores_tab_trade"),
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = VoltworksOrangeTint, selectedLabelColor = VoltworksOrangeDark)
            )
        }

        if (activeTab == 0) {
            val matchingStores = state.stores.filter {
                storeSearch.isBlank() ||
                    it.name.contains(storeSearch, ignoreCase = true) ||
                    it.city.contains(storeSearch, ignoreCase = true) ||
                    it.postcode.contains(storeSearch, ignoreCase = true)
            }
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = storeSearch,
                        onValueChange = { storeSearch = it },
                        leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                        label = { Text("Search store by city or postcode") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                items(matchingStores, key = { it.id }) { store ->
                    val isSelected = store.id == state.selectedStoreId
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, if (isSelected) VoltworksOrange else MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(store.name, style = MaterialTheme.typography.titleLarge)
                                if (isSelected) {
                                    VoltworksSectionPill("Selected store", VoltworksOrangeTint, VoltworksOrangeDark)
                                }
                            }
                            Text("${store.addressLine}, ${store.city} ${store.postcode}", style = MaterialTheme.typography.bodyMedium)
                            Text("Tel: ${store.phone} · ${store.email}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                "Hours: " + store.openingHours.entries.joinToString(" | ") { "${it.key} ${it.value}" },
                                style = MaterialTheme.typography.labelSmall
                            )
                            Text("Facilities: ${store.facilities.joinToString(" · ")}", style = MaterialTheme.typography.bodySmall)
                            Text(
                                "Services: ${if (store.supportsRepairs) "Repairs " else ""}${if (store.supportsWorkshops) "· Workshops " else ""}${if (store.supportsTradeDesk) "· Trade Desk" else ""}",
                                style = MaterialTheme.typography.bodySmall,
                                color = VoltworksSuccess,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text("Collection: ${store.collectionInstructions}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                            if (!isSelected) {
                                Button(
                                    onClick = { onSelectStore(store.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange)
                                ) {
                                    Text("Set as my store")
                                }
                            } else if (state.selectedStoreInventory.isNotEmpty()) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                                Text("Live Inventory Ledger (Physical / Reserved / ATP / Quarantined / Inbound)", style = MaterialTheme.typography.labelMedium)
                                state.selectedStoreInventory.values.forEach { inv ->
                                    Text(
                                        "${inv.sku}: ATP ${inv.availableToPromise} | Phys ${inv.physicalQty} | Res ${inv.reservedQty} | Quar ${inv.quarantinedQty} | Transfer ${inv.inboundTransferQty}",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            var orgName by remember { mutableStateOf("Peak Valley Prototyping Ltd") }
            var regNo by remember { mutableStateOf("11842910") }
            var vatNo by remember { mutableStateOf("GB391847201") }
            var poRef by remember { mutableStateOf("PO-2026-441") }
            var quoteNotes by remember { mutableStateOf("Bulk resistor packs and 5x RP2350 kits for lab fit-out") }
            var bcScope by remember { mutableStateOf("PROTOTYPING") }
            var bcSummary by remember { mutableStateOf("DIN-rail enclosure wiring harness & custom 24 V bench busbar assembly (25 units)") }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Voltworks Trade Account", style = MaterialTheme.typography.titleLarge)
                            Text(
                                "Manage organisation members, saved project lists, bulk quantities, PO references, and contract pricing. Credit terms are configurable and subject to Finance approval.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(value = orgName, onValueChange = { orgName = it }, label = { Text("Organisation name") }, modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(value = regNo, onValueChange = { regNo = it }, label = { Text("Company Reg") }, modifier = Modifier.weight(1f))
                                OutlinedTextField(value = vatNo, onValueChange = { vatNo = it }, label = { Text("VAT No.") }, modifier = Modifier.weight(1f))
                            }
                            Button(
                                onClick = { onRegisterTradeAccount(orgName, regNo, vatNo) },
                                colors = ButtonDefaults.buttonColors(containerColor = VoltworksNavy),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("trade_register_btn")
                            ) {
                                Text("Create Trade Account (No auto-credit)")
                            }
                        }
                    }
                }

                items(state.tradeAccounts, key = { it.id }) { acc ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, VoltworksOrange.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${acc.organisationName} (${acc.id})", style = MaterialTheme.typography.titleMedium)
                                VoltworksSectionPill(
                                    label = if (acc.creditApproved) "Credit Approved" else "Credit: Pending Review",
                                    containerColor = if (acc.creditApproved) VoltworksSuccessTint else VoltworksWarningTint,
                                    contentColor = if (acc.creditApproved) VoltworksSuccess else VoltworksWarning
                                )
                            }
                            Text("Members: ${acc.members.joinToString()}", style = MaterialTheme.typography.bodySmall)
                            Text("Saved lists: ${acc.savedProjectLists.joinToString()}", style = MaterialTheme.typography.bodySmall)
                            OutlinedTextField(value = poRef, onValueChange = { poRef = it }, label = { Text("Purchase Order (PO) Reference") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(value = quoteNotes, onValueChange = { quoteNotes = it }, label = { Text("Bulk quote notes") }, modifier = Modifier.fillMaxWidth())
                            Button(
                                onClick = { onSubmitTradeQuote(acc.id, poRef, quoteNotes) },
                                colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Request Quote with PO Reference")
                            }
                        }
                    }
                }

                items(state.tradeQuotes, key = { it.id }) { tq ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = VoltworksOrangeTint
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Trade Quote ${tq.id} · PO ${tq.poReference}", style = MaterialTheme.typography.titleSmall)
                            Text("${MoneyFormat.gbp(tq.totalPence)} · ${tq.status}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Building Centre Enquiry", style = MaterialTheme.typography.titleLarge)
                            Text("Electrical construction supplies, custom sub-assemblies, and rapid prototyping desk.", style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("ELECTRICAL_SUPPLIES", "ASSEMBLY", "PROTOTYPING").forEach { sc ->
                                    FilterChip(selected = bcScope == sc, onClick = { bcScope = sc }, label = { Text(sc.replace('_', ' ')) })
                                }
                            }
                            OutlinedTextField(
                                value = bcSummary,
                                onValueChange = { bcSummary = it },
                                label = { Text("Project & technical specification") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(
                                onClick = { onSubmitBuildingEnquiry(orgName, state.checkout.customerEmail, bcScope, bcSummary) },
                                colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("building_centre_submit_btn")
                            ) {
                                Text("Submit Building Centre Enquiry")
                            }
                        }
                    }
                }

                items(state.buildingEnquiries, key = { it.id }) { enq ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("${enq.id} · ${enq.serviceScope} (${enq.status})", style = MaterialTheme.typography.titleSmall)
                            Text(enq.specificationSummary, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
