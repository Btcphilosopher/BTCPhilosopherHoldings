package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val VoltworksNavy = Color(0xFF0B1628)
val VoltworksNavyElevated = Color(0xFF14243D)
val VoltworksOrange = Color(0xFFF25C05)
val VoltworksOrangeDark = Color(0xFFD24B00)
val VoltworksOrangeTint = Color(0xFFFFF2EA)
val VoltworksIvory = Color(0xFFF7F4EE)
val VoltworksIvorySurface = Color(0xFFFFFFFF)
val VoltworksIvorySubtle = Color(0xFFF0ECE3)
val VoltworksBorder = Color(0xFFE2DDD2)
val VoltworksInk = Color(0xFF101926)
val VoltworksSlate = Color(0xFF5A6475)
val VoltworksSuccess = Color(0xFF16794F)
val VoltworksSuccessTint = Color(0xFFE7F5EE)
val VoltworksWarning = Color(0xFFB54708)
val VoltworksWarningTint = Color(0xFFFFF4E5)
val VoltworksError = Color(0xFFB42318)
val VoltworksErrorTint = Color(0xFFFEECEB)

// Dark theme counterparts preserving Midnight Navy + Electric Orange brand
val VoltworksDarkBg = Color(0xFF08101D)
val VoltworksDarkSurface = Color(0xFF111D30)
val VoltworksDarkSurfaceVariant = Color(0xFF1B2B44)
val VoltworksDarkBorder = Color(0xFF283A57)
val VoltworksDarkText = Color(0xFFF4F1EA)
val VoltworksDarkMuted = Color(0xFFAAB4C3)
