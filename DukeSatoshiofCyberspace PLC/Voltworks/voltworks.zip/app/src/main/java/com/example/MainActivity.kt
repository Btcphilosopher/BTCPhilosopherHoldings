package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.ui.navigation.TopTab
import com.example.ui.navigation.VoltworksRoute
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.VoltworksViewModel

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as VoltworksApp
        setContent {
            val viewModel: VoltworksViewModel = viewModel(
                factory = VoltworksViewModel.Factory(app.container.repository)
            )
            val state by viewModel.uiState.collectAsStateWithLifecycle()

            VoltworksTheme(reducedMotion = state.reducedMotion) {
                VoltworksRootShell(
                    state = state,
                    viewModel = viewModel,
                    onRequestBiometricUnlock = {
                        promptBiometricUnlock { unlocked ->
                            viewModel.setBiometricUnlocked(unlocked)
                        }
                    }
                )
            }
        }
    }

    private fun promptBiometricUnlock(onResult: (Boolean) -> Unit) {
        val manager = BiometricManager.from(this)
        val canAuth = manager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            onResult(true)
            return
        }
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(
            this,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onResult(true)
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onResult(false)
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Voltworks Account")
            .setSubtitle("Verify your identity to access orders and addresses")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()
        prompt.authenticate(info)
    }
}

@Composable
fun VoltworksRootShell(
    state: com.example.ui.viewmodel.VoltworksUiState,
    viewModel: VoltworksViewModel,
    onRequestBiometricUnlock: () -> Unit
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = backStackEntry?.destination
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.bannerMessage, state.errorMessage) {
        val msg = state.errorMessage ?: state.bannerMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Short)
            viewModel.clearMessages()
        }
    }

    val selectedTab = when {
        currentDest?.hasRoute<VoltworksRoute.Home>() == true -> TopTab.HOME
        currentDest?.hasRoute<VoltworksRoute.Shop>() == true ||
            currentDest?.hasRoute<VoltworksRoute.ProductDetail>() == true ||
            currentDest?.hasRoute<VoltworksRoute.Basket>() == true -> TopTab.SHOP
        currentDest?.hasRoute<VoltworksRoute.Services>() == true ||
            currentDest?.hasRoute<VoltworksRoute.RepairTracker>() == true -> TopTab.SERVICES
        currentDest?.hasRoute<VoltworksRoute.Stores>() == true -> TopTab.STORES
        currentDest?.hasRoute<VoltworksRoute.Account>() == true -> TopTab.ACCOUNT
        else -> TopTab.HOME
    }

    val navigateTopTab: (TopTab) -> Unit = { tab ->
        val dest: VoltworksRoute = when (tab) {
            TopTab.HOME -> VoltworksRoute.Home
            TopTab.SHOP -> VoltworksRoute.Shop()
            TopTab.SERVICES -> VoltworksRoute.Services()
            TopTab.STORES -> VoltworksRoute.Stores
            TopTab.ACCOUNT -> VoltworksRoute.Account
        }
        navController.navigate(dest) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 700.dp

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 0.dp,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        TopTab.entries.forEach { tab ->
                            val isSelected = selectedTab == tab
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { navigateTopTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = tabIcon(tab, isSelected),
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = VoltworksOrange,
                                    selectedTextColor = VoltworksOrange,
                                    indicatorColor = VoltworksOrangeTint,
                                    unselectedIconColor = VoltworksNavy,
                                    unselectedTextColor = VoltworksSlate
                                ),
                                modifier = Modifier.testTag("bottom_nav_${tab.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        TopTab.entries.forEach { tab ->
                            val isSelected = selectedTab == tab
                            NavigationRailItem(
                                selected = isSelected,
                                onClick = { navigateTopTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = tabIcon(tab, isSelected),
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = VoltworksOrange,
                                    selectedTextColor = VoltworksOrange,
                                    indicatorColor = VoltworksOrangeTint
                                )
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = VoltworksRoute.Home,
                    modifier = Modifier.weight(1f)
                ) {
                    composable<VoltworksRoute.Home> {
                        HomeScreen(
                            state = state,
                            onSearchSubmit = { q ->
                                viewModel.updateFilters { it.copy(query = q, category = "All") }
                                navController.navigate(VoltworksRoute.Shop(initialQuery = q))
                            },
                            onSelectCategory = { cat ->
                                viewModel.updateFilters { it.copy(category = cat, query = "") }
                                navController.navigate(VoltworksRoute.Shop(initialCategory = cat))
                            },
                            onOpenWorkshops = { navController.navigate(VoltworksRoute.Services(initialTab = 1)) },
                            onOpenProduct = { pid -> navController.navigate(VoltworksRoute.ProductDetail(pid)) },
                            onQuickAdd = { prod -> viewModel.addToBasket(prod, prod.variants.first(), 1) },
                            onOpenBasket = { navController.navigate(VoltworksRoute.Basket) },
                            onOpenStores = { navigateTopTab(TopTab.STORES) },
                            onOpenRepairs = { navController.navigate(VoltworksRoute.RepairTracker()) },
                            onSelectStore = { viewModel.selectStore(it) },
                            onDisableOffline = { viewModel.toggleOfflineMode(false) }
                        )
                    }

                    composable<VoltworksRoute.Shop> { entry ->
                        val route = entry.toRoute<VoltworksRoute.Shop>()
                        LaunchedEffect(route.initialCategory, route.initialQuery) {
                            if (route.initialCategory != "All" || route.initialQuery.isNotBlank()) {
                                viewModel.updateFilters {
                                    it.copy(category = route.initialCategory, query = route.initialQuery)
                                }
                            }
                        }
                        ShopScreen(
                            state = state,
                            onUpdateFilters = viewModel::updateFilters,
                            onOpenProduct = { pid -> navController.navigate(VoltworksRoute.ProductDetail(pid)) },
                            onQuickAdd = { prod -> viewModel.addToBasket(prod, prod.variants.first(), 1) },
                            onOpenBasket = { navController.navigate(VoltworksRoute.Basket) },
                            onOpenWorkshops = { navController.navigate(VoltworksRoute.Services(initialTab = 1)) },
                            onDisableOffline = { viewModel.toggleOfflineMode(false) }
                        )
                    }

                    composable<VoltworksRoute.ProductDetail> { entry ->
                        val route = entry.toRoute<VoltworksRoute.ProductDetail>()
                        val prod = state.allProducts.firstOrNull { it.id == route.productId }
                        if (prod != null) {
                            ProductDetailScreen(
                                product = prod,
                                state = state,
                                onBack = { navController.popBackStack() },
                                onOpenBasket = { navController.navigate(VoltworksRoute.Basket) },
                                onSelectStore = viewModel::selectStore,
                                onSetFulfilmentMode = viewModel::setFulfilmentMode,
                                onAddToBasket = viewModel::addToBasket,
                                onOpenCompatibleProduct = { targetId ->
                                    navController.navigate(VoltworksRoute.ProductDetail(targetId))
                                },
                                loadSkuStockAcrossStores = viewModel::loadSkuStockAcrossStores
                            )
                        }
                    }

                    composable<VoltworksRoute.Basket> {
                        BasketCheckoutScreen(
                            state = state,
                            onBack = { navController.popBackStack() },
                            onUpdateQty = viewModel::updateBasketItemQty,
                            onSetFulfilmentMode = viewModel::setFulfilmentMode,
                            onUpdateCheckoutDetails = viewModel::updateCheckoutDetails,
                            onReserveStock = viewModel::reserveBasketStock,
                            onPayOrder = viewModel::payAndPlaceOrder,
                            onMarkOrderReady = viewModel::markOrderReadyForCollection,
                            onCollectOrder = viewModel::collectOrder,
                            onDisableOffline = { viewModel.toggleOfflineMode(false) },
                            onBrowseShop = { navigateTopTab(TopTab.SHOP) }
                        )
                    }

                    composable<VoltworksRoute.Services> { entry ->
                        val route = entry.toRoute<VoltworksRoute.Services>()
                        ServicesScreen(
                            state = state,
                            initialTab = route.initialTab,
                            onOpenBasket = { navController.navigate(VoltworksRoute.Basket) },
                            onSelectStore = viewModel::selectStore,
                            onBookRepair = viewModel::bookRepair,
                            onOpenRepairTracker = { jid -> navController.navigate(VoltworksRoute.RepairTracker(jid)) },
                            onHoldWorkshopSeat = viewModel::holdWorkshopSeat,
                            onConfirmWorkshopBooking = viewModel::confirmWorkshopBooking,
                            onCancelWorkshopBooking = viewModel::cancelWorkshopBooking,
                            onExpireWorkshopHold = viewModel::simulateExpireWorkshopHold
                        )
                    }

                    composable<VoltworksRoute.RepairTracker> { entry ->
                        val route = entry.toRoute<VoltworksRoute.RepairTracker>()
                        RepairTrackerScreen(
                            state = state,
                            initialJobId = route.jobId,
                            onBack = { navController.popBackStack() },
                            onOpenBasket = { navController.navigate(VoltworksRoute.Basket) },
                            onIssueDemoQuote = viewModel::simulateIssueRepairQuote,
                            onAdvanceStatus = viewModel::advanceRepairProgress,
                            onDecideQuote = viewModel::decideRepairQuote,
                            onOpenWarrantyReturn = viewModel::submitWarrantyReturn,
                            onDisableOffline = { viewModel.toggleOfflineMode(false) }
                        )
                    }

                    composable<VoltworksRoute.Stores> {
                        StoresAndTradeScreen(
                            state = state,
                            onOpenBasket = { navController.navigate(VoltworksRoute.Basket) },
                            onSelectStore = viewModel::selectStore,
                            onRegisterTradeAccount = viewModel::registerTradeAccount,
                            onSubmitTradeQuote = viewModel::submitTradeQuote,
                            onSubmitBuildingEnquiry = viewModel::submitBuildingCentreEnquiry
                        )
                    }

                    composable<VoltworksRoute.Account> {
                        AccountScreen(
                            state = state,
                            onOpenBasket = { navController.navigate(VoltworksRoute.Basket) },
                            onSignIn = viewModel::signIn,
                            onSignOut = viewModel::signOut,
                            onToggleBiometric = viewModel::setBiometricLock,
                            onRequestBiometricUnlock = onRequestBiometricUnlock,
                            onToggleReducedMotion = viewModel::setReducedMotion,
                            onTogglePush = viewModel::setPushEnabled,
                            onToggleOfflineMode = viewModel::toggleOfflineMode,
                            onSimulateLastItemRace = viewModel::simulateCompetingPurchaseOfLastRoboticsKit,
                            onOpenRepairTracker = { jid -> navController.navigate(VoltworksRoute.RepairTracker(jid)) }
                        )
                    }
                }
            }
        }
    }
}

private fun tabIcon(tab: TopTab, selected: Boolean) = when (tab) {
    TopTab.HOME -> if (selected) Icons.Filled.Home else Icons.Outlined.Home
    TopTab.SHOP -> if (selected) Icons.Filled.Sell else Icons.Outlined.Sell
    TopTab.SERVICES -> if (selected) Icons.Filled.Build else Icons.Outlined.Build
    TopTab.STORES -> if (selected) Icons.Filled.LocationOn else Icons.Outlined.LocationOn
    TopTab.ACCOUNT -> if (selected) Icons.Filled.Person else Icons.Outlined.Person
}
