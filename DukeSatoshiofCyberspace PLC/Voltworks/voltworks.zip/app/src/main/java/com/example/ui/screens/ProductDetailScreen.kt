package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.ui.components.VoltworksTopHeader
import com.example.ui.components.resolveVoltworksDrawable
import com.example.ui.theme.*
import com.example.ui.viewmodel.VoltworksUiState

@Composable
fun ProductDetailScreen(
    product: ProductDto,
    state: VoltworksUiState,
    onBack: () -> Unit,
    onOpenBasket: () -> Unit,
    onSelectStore: (String) -> Unit,
    onSetFulfilmentMode: (FulfilmentMode) -> Unit,
    onAddToBasket: (ProductDto, ProductVariantDto, Int) -> Unit,
    onOpenCompatibleProduct: (String) -> Unit,
    loadSkuStockAcrossStores: suspend (String) -> List<StoreInventoryDto>
) {
    var selectedVariantIndex by remember(product.id) { mutableIntStateOf(0) }
    val variant = product.variants[selectedVariantIndex.coerceIn(product.variants.indices)]
    var packCount by remember(variant.sku) { mutableIntStateOf(variant.minPackQuantity) }
    var detailsExpanded by remember { mutableStateOf(true) }
    var specsExpanded by remember { mutableStateOf(false) }
    var compatExpanded by remember { mutableStateOf(true) }
    var showStoreDialog by remember { mutableStateOf(false) }
    var skuStoreStocks by remember(variant.sku) { mutableStateOf<List<StoreInventoryDto>>(emptyList()) }

    LaunchedEffect(variant.sku) {
        skuStoreStocks = loadSkuStockAcrossStores(variant.sku)
    }

    val selectedStore = state.selectedStore
    val storeStock = state.selectedStoreInventory[variant.sku]
        ?: skuStoreStocks.firstOrNull { it.storeId == state.selectedStoreId }
    val atp = storeStock?.availableToPromise ?: 0
    val effectivePackPrice = variant.tiers
        .filter { packCount >= it.minPacks }
        .maxByOrNull { it.minPacks }?.packPricePence ?: variant.packPricePence
    val effectiveUnitPrice = if (variant.packQuantity > 0) effectivePackPrice / variant.packQuantity else effectivePackPrice

    val images = product.imageKeys.ifEmpty { listOf("img_hero_makers") }
    val pagerState = rememberPagerState(pageCount = { images.size })

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        VoltworksTopHeader(
            basketCount = state.basketTotalCount,
            onBasketClick = onOpenBasket,
            showBackButton = true,
            onBackClick = onBack
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            // Carousel matching middle mockup
            item {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 210.dp, max = 250.dp)
                    ) { page ->
                        Image(
                            painter = painterResource(id = resolveVoltworksDrawable(images[page])),
                            contentDescription = "${product.familyName} view ${page + 1}",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        repeat(images.size) { index ->
                            val active = pagerState.currentPage == index
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (active) VoltworksOrange else VoltworksBorder)
                            )
                        }
                    }
                }
            }

            // Title, Variant selector, Price & VAT, 3 Spec Highlights
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Text(
                        text = product.familyName,
                        style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${product.manufacturer} · SKU ${variant.sku}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = MoneyFormat.gbp(effectivePackPrice),
                            style = MaterialTheme.typography.headlineLarge.copy(fontSize = 28.sp),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Inc. 20% VAT (${MoneyFormat.gbp(MoneyFormat.exVatFromGross(effectivePackPrice))} ex VAT)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }

                    if (variant.packQuantity > 1) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = VoltworksOrangeTint
                        ) {
                            Text(
                                text = "Pack of ${variant.packQuantity} pieces · ${MoneyFormat.gbp(effectiveUnitPrice)} per piece (min ${variant.minPackQuantity} pack)",
                                style = MaterialTheme.typography.labelMedium,
                                color = VoltworksOrangeDark,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }

                    if (variant.tiers.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(variant.tiers) { tier ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Text(
                                        text = "${tier.minPacks}+ packs: ${MoneyFormat.gbp(tier.packPricePence)}/pack",
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }
                    }

                    if (product.variants.size > 1) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Variant / Pack", style = MaterialTheme.typography.titleSmall)
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(product.variants.size) { idx ->
                                val v = product.variants[idx]
                                val isSel = idx == selectedVariantIndex
                                FilterChip(
                                    selected = isSel,
                                    onClick = { selectedVariantIndex = idx },
                                    label = { Text(v.variantLabel) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = VoltworksOrangeTint,
                                        selectedLabelColor = VoltworksOrangeDark
                                    )
                                )
                            }
                        }
                    }

                    // 3 Key Highlights Strip matching middle phone mockup
                    if (product.highlights.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            product.highlights.take(3).forEachIndexed { idx, (text, iconType) ->
                                if (idx > 0) {
                                    HorizontalDivider(
                                        modifier = Modifier
                                            .height(38.dp)
                                            .width(1.dp),
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                                Row(
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(horizontal = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = when (iconType) {
                                            "bolt" -> Icons.Outlined.Bolt
                                            "thermostat" -> Icons.Outlined.Thermostat
                                            "speed" -> Icons.Outlined.Speed
                                            "memory" -> Icons.Outlined.Memory
                                            else -> Icons.Outlined.Build
                                        },
                                        contentDescription = null,
                                        tint = VoltworksNavy,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = text,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Delivery vs Collect in store selector cards
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val isDelivery = state.checkout.fulfilmentMode == FulfilmentMode.DELIVERY
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 64.dp)
                                .clickable { onSetFulfilmentMode(FulfilmentMode.DELIVERY) }
                                .testTag("pdp_fulfilment_delivery"),
                            shape = RoundedCornerShape(12.dp),
                            color = if (isDelivery) VoltworksOrangeTint else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(if (isDelivery) 1.5.dp else 1.dp, if (isDelivery) VoltworksOrange else MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Outlined.LocalShipping, contentDescription = null, tint = VoltworksNavy)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text("Delivery", style = MaterialTheme.typography.titleSmall)
                                        Text("From £3.99", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                if (isDelivery) {
                                    Icon(Icons.Filled.CheckCircle, contentDescription = "Selected", tint = VoltworksOrange, modifier = Modifier.size(20.dp))
                                }
                            }
                        }

                        val isCollect = state.checkout.fulfilmentMode == FulfilmentMode.CLICK_AND_COLLECT
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 64.dp)
                                .clickable { onSetFulfilmentMode(FulfilmentMode.CLICK_AND_COLLECT) }
                                .testTag("pdp_fulfilment_collect"),
                            shape = RoundedCornerShape(12.dp),
                            color = if (isCollect) VoltworksOrangeTint else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(if (isCollect) 1.5.dp else 1.dp, if (isCollect) VoltworksOrange else MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Outlined.Storefront, contentDescription = null, tint = VoltworksOrange)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text("Collect in store", style = MaterialTheme.typography.titleSmall)
                                        Text("From ${selectedStore?.collectionLeadMinutes ?: 60} mins", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                if (isCollect) {
                                    Icon(Icons.Filled.CheckCircle, contentDescription = "Selected", tint = VoltworksOrange, modifier = Modifier.size(20.dp))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Store picker card
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showStoreDialog = true }
                            .testTag("pdp_store_selector"),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.LocationOn, contentDescription = null, tint = VoltworksNavy)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(selectedStore?.name ?: "Sheffield flagship", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${selectedStore?.addressLine ?: "Unit 1, Meadowhall Way"}, ${selectedStore?.postcode ?: "S9 1EP"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Change store")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (atp > 0) Icons.Filled.CheckCircle else Icons.Outlined.Info,
                            contentDescription = null,
                            tint = if (atp > 0) VoltworksSuccess else VoltworksWarning,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (atp > 0)
                                "Available for collection ($atp ATP · Est. ${selectedStore?.collectionLeadMinutes ?: 60} min prep)"
                            else
                                "Out of stock at ${selectedStore?.name ?: "this store"} (select another store or delivery)",
                            style = MaterialTheme.typography.titleSmall,
                            color = if (atp > 0) VoltworksSuccess else VoltworksWarning
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Quantity stepper + Add to basket CTA matching mockup
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.heightIn(min = 50.dp)
                            ) {
                                IconButton(
                                    onClick = { packCount = (packCount - 1).coerceAtLeast(variant.minPackQuantity) },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Outlined.Remove, contentDescription = "Decrease quantity")
                                }
                                Text(
                                    text = packCount.toString(),
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                                IconButton(
                                    onClick = { packCount += 1 },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Outlined.Add, contentDescription = "Increase quantity")
                                }
                            }
                        }

                        Button(
                            onClick = { onAddToBasket(product, variant, packCount) },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 52.dp)
                                .testTag("pdp_add_to_basket")
                        ) {
                            Icon(Icons.Outlined.ShoppingCart, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.add_to_basket),
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }
                }
            }

            // Expandable Accordions: Details, Specifications, Compatibility, Store Stock
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    AccordionRow(
                        title = "Details & Warranty",
                        icon = Icons.Outlined.Info,
                        expanded = detailsExpanded,
                        onToggle = { detailsExpanded = !detailsExpanded }
                    ) {
                        Text(product.description, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Included contents:", style = MaterialTheme.typography.titleSmall)
                        product.includedContents.forEach { item ->
                            Text("• $item", style = MaterialTheme.typography.bodySmall)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Warranty: ${product.warrantyMonths} months Voltworks UK guarantee (supplements statutory rights).", style = MaterialTheme.typography.bodySmall, color = VoltworksSuccess)
                        if (product.documentation.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Documentation: ${product.documentation.mapNotNull { it["title"] }.joinToString(" · ")}", style = MaterialTheme.typography.bodySmall, color = VoltworksOrangeDark)
                        }
                    }

                    AccordionRow(
                        title = "Structured Specifications",
                        icon = Icons.Outlined.Tune,
                        expanded = specsExpanded,
                        onToggle = { specsExpanded = !specsExpanded }
                    ) {
                        SpecRow("Dimensions", variant.dimensionsMm ?: "Not specified")
                        SpecRow("Interface", variant.interfaceType ?: "Not specified")
                        SpecRow("Operating Voltage", variant.operatingVoltage ?: "Not specified")
                        SpecRow("Platforms", if (variant.supportedPlatforms.isEmpty()) "Unknown" else variant.supportedPlatforms.joinToString(", "))
                        variant.specs.forEach { (k, v) -> SpecRow(k, v) }
                        if (skuStoreStocks.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Store Stock Breakdown (ATP = Physical − Reserved − Quarantined)", style = MaterialTheme.typography.titleSmall)
                            skuStoreStocks.forEach { st ->
                                val storeName = state.stores.firstOrNull { it.id == st.storeId }?.name ?: st.storeId
                                Text(
                                    "$storeName: ${st.availableToPromise} ATP (Phys ${st.physicalQty}, Res ${st.reservedQty}, Quar ${st.quarantinedQty}, Inbound ${st.inboundTransferQty})",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }

                    AccordionRow(
                        title = "Compatibility",
                        icon = Icons.Outlined.Extension,
                        expanded = compatExpanded,
                        onToggle = { compatExpanded = !compatExpanded }
                    ) {
                        if (product.compatibility.isEmpty()) {
                            Text(
                                "No documented compatibility rules recorded for this SKU. Missing compatibility remains unknown rather than inferred by name.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            product.compatibility.forEach { rule ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clickable { onOpenCompatibleProduct(rule.targetProductId) },
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("${rule.targetTitle} (${rule.targetSku})", style = MaterialTheme.typography.titleSmall, color = VoltworksOrangeDark)
                                        Text("Basis (${rule.relationshipType}): ${rule.ruleBasis}", style = MaterialTheme.typography.bodySmall)
                                        Text("Ref: ${rule.manufacturerRef}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showStoreDialog) {
        AlertDialog(
            onDismissRequest = { showStoreDialog = false },
            title = { Text("Select collection store") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.stores.forEach { st ->
                        val stStock = skuStoreStocks.firstOrNull { it.storeId == st.id }
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectStore(st.id)
                                    showStoreDialog = false
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = if (st.id == state.selectedStoreId) VoltworksOrangeTint else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, if (st.id == state.selectedStoreId) VoltworksOrange else MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(st.name, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "ATP: ${stStock?.availableToPromise ?: 0} · Inbound: ${stStock?.inboundTransferQty ?: 0}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if ((stStock?.availableToPromise ?: 0) > 0) VoltworksSuccess else VoltworksSlate
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showStoreDialog = false }) { Text("Done") } }
        )
    }
}

@Composable
private fun AccordionRow(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    expanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 52.dp)
                .clickable(onClick = onToggle)
                .padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = VoltworksNavy, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Icon(
                imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                contentDescription = if (expanded) "Collapse $title" else "Expand $title"
            )
        }
        if (expanded) {
            Column(modifier = Modifier.padding(bottom = 14.dp), content = content)
        }
    }
}

@Composable
private fun SpecRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
    }
}
