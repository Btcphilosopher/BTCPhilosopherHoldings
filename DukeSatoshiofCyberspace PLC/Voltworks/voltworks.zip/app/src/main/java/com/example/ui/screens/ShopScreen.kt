package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ProductDto
import com.example.ui.components.OfflineFreshnessBanner
import com.example.ui.components.VoltworksProductCard
import com.example.ui.components.VoltworksTopHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.ShopFilters
import com.example.ui.viewmodel.VoltworksUiState

@Composable
fun ShopScreen(
    state: VoltworksUiState,
    onUpdateFilters: ((ShopFilters) -> ShopFilters) -> Unit,
    onOpenProduct: (String) -> Unit,
    onQuickAdd: (ProductDto) -> Unit,
    onOpenBasket: () -> Unit,
    onOpenWorkshops: () -> Unit,
    onDisableOffline: () -> Unit
) {
    var showFilterPanel by remember { mutableStateOf(false) }

    val categories = listOf("All", "Components", "Computing", "Robotics", "Tools & Repair", "Smart Home", "Workshops")
    val manufacturers = remember(state.allProducts) {
        listOf("All") + state.allProducts.map { it.manufacturer }.distinct().sorted()
    }
    val interfaces = listOf("All", "USB-C", "USB4", "I2C", "Thread", "Axial", "230V")
    val voltages = listOf("All", "3.3 V", "5 V", "230 V")
    val platforms = listOf("All", "RP2350", "Raspberry Pi", "Arduino", "Matter", "Linux")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        VoltworksTopHeader(
            basketCount = state.basketTotalCount,
            onBasketClick = onOpenBasket,
            searchQuery = state.filters.query,
            onSearchQueryChange = { q -> onUpdateFilters { it.copy(query = q) } },
            onSearchSubmit = {}
        )

        OfflineFreshnessBanner(
            offlineMode = state.offlineMode,
            lastSyncedMillis = state.syncMeta?.lastSyncedMillis,
            onGoOnline = onDisableOffline
        )

        // Category strip + Filter toggle
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { cat ->
                val selected = state.filters.category.equals(cat, ignoreCase = true)
                FilterChip(
                    selected = selected,
                    onClick = {
                        if (cat == "Workshops") {
                            onOpenWorkshops()
                        } else {
                            onUpdateFilters { it.copy(category = cat) }
                        }
                    },
                    label = { Text(cat) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = VoltworksOrangeTint,
                        selectedLabelColor = VoltworksOrangeDark
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = selected,
                        borderColor = VoltworksBorder,
                        selectedBorderColor = VoltworksOrange
                    ),
                    modifier = Modifier.testTag("shop_cat_${cat.lowercase().replace(" ", "_")}")
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "${state.filteredProducts.size} products · ${state.selectedStore?.name ?: "All stores"}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(
                onClick = { showFilterPanel = !showFilterPanel },
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (showFilterPanel) VoltworksOrange else MaterialTheme.colorScheme.outline),
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("shop_toggle_filters")
            ) {
                Icon(Icons.Outlined.FilterList, contentDescription = null, tint = VoltworksOrange, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (showFilterPanel) "Hide filters" else "Specs & filters", color = MaterialTheme.colorScheme.onSurface)
            }
        }

        if (showFilterPanel) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("In stock at ${state.selectedStore?.name ?: "store"}", style = MaterialTheme.typography.titleSmall)
                        Switch(
                            checked = state.filters.onlyInSelectedStore,
                            onCheckedChange = { checked -> onUpdateFilters { it.copy(onlyInSelectedStore = checked) } }
                        )
                    }

                    FilterChipGroup("Manufacturer", manufacturers, state.filters.manufacturer) { m ->
                        onUpdateFilters { it.copy(manufacturer = m) }
                    }
                    FilterChipGroup("Max Price", listOf("Any", "£50", "£100", "£150"),
                        when (state.filters.maxPricePence) {
                            5000L -> "£50"
                            10000L -> "£100"
                            15000L -> "£150"
                            else -> "Any"
                        }
                    ) { p ->
                        val maxPence = when (p) {
                            "£50" -> 5000L
                            "£100" -> 10000L
                            "£150" -> 15000L
                            else -> null
                        }
                        onUpdateFilters { it.copy(maxPricePence = maxPence) }
                    }
                    FilterChipGroup("Interface", interfaces, state.filters.interfaceFilter) { i ->
                        onUpdateFilters { it.copy(interfaceFilter = i) }
                    }
                    FilterChipGroup("Operating Voltage", voltages, state.filters.voltageFilter) { v ->
                        onUpdateFilters { it.copy(voltageFilter = v) }
                    }
                    FilterChipGroup("Supported Platform", platforms, state.filters.platformFilter) { pl ->
                        onUpdateFilters { it.copy(platformFilter = pl) }
                    }
                    TextButton(onClick = { onUpdateFilters { ShopFilters() } }) {
                        Text("Reset all filters", color = VoltworksOrange)
                    }
                }
            }
        }

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val cols = if (maxWidth >= 700.dp) 3 else 2
            val rows = state.filteredProducts.chunked(cols)
            if (rows.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                        Text("No matching products", style = MaterialTheme.typography.titleLarge)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Try clearing technical filters or searching another SKU.", style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = { onUpdateFilters { ShopFilters() } }) {
                            Text("Clear filters")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(rows) { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            rowItems.forEach { prod ->
                                val sku = prod.variants.first().sku
                                val atp = state.selectedStoreInventory[sku]?.availableToPromise
                                VoltworksProductCard(
                                    product = prod,
                                    stockCount = atp,
                                    onOpenProduct = { onOpenProduct(prod.id) },
                                    onQuickAdd = { onQuickAdd(prod) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (rowItems.size < cols) {
                                repeat(cols - rowItems.size) { Spacer(modifier = Modifier.weight(1f)) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterChipGroup(
    label: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(options) { opt ->
                val isSel = opt == selected
                FilterChip(
                    selected = isSel,
                    onClick = { onSelect(opt) },
                    label = { Text(opt, style = MaterialTheme.typography.bodySmall) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = VoltworksOrangeTint,
                        selectedLabelColor = VoltworksOrangeDark
                    )
                )
            }
        }
    }
}
