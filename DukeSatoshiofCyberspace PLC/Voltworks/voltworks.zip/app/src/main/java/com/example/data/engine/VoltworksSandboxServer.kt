package com.example.data.engine

import com.example.data.model.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.roundToLong

class ApiConflictException(message: String) : RuntimeException(message)
class ApiForbiddenException(message: String) : RuntimeException(message)
class ApiNotFoundException(message: String) : RuntimeException(message)

/**
 * Authoritative transactional backend engine mirroring the Ktor Server + PostgreSQL logic.
 * Used behind Ktor Client's MockEngine when no external backend URL is configured, ensuring
 * real HTTP serialization, concurrency locks, idempotency, and server-calculated totals in GBP pence.
 */
class VoltworksSandboxServer {
    private val stores = ConcurrentHashMap<String, StoreDto>()
    private val products = ConcurrentHashMap<String, ProductDto>()
    private val inventory = ConcurrentHashMap<Pair<String, String>, StoreInventoryDto>()
    private val reservations = ConcurrentHashMap<String, ReservationDto>()
    private val orders = ConcurrentHashMap<String, OrderDto>()
    private val repairJobs = ConcurrentHashMap<String, RepairJobDto>()
    private val workshopEvents = ConcurrentHashMap<String, WorkshopEventDto>()
    private val workshopBookings = ConcurrentHashMap<String, WorkshopBookingDto>()
    private val tradeAccounts = ConcurrentHashMap<String, TradeAccountDto>()
    private val tradeQuotes = mutableListOf<TradeQuoteDto>()
    private val buildingEnquiries = mutableListOf<BuildingCentreEnquiryDto>()
    private val notifications = mutableListOf<NotificationDto>()
    private val auditLogs = mutableListOf<AuditLogDto>()
    private val idempotencyCache = ConcurrentHashMap<String, Any>()
    private val settledPayments = ConcurrentHashMap<String, String>()
    private val auditSeq = AtomicLong(1L)
    private val txLock = Any()

    init {
        seedDemoData()
    }

    fun listStores(): List<StoreDto> = stores.values.sortedBy {
        when (it.id) {
            "store-sheffield" -> 0
            "store-manchester" -> 1
            "store-bristol" -> 2
            else -> 3
        }
    }

    fun listProducts(
        category: String? = null,
        query: String? = null,
        manufacturer: String? = null,
        maxPricePence: Long? = null,
        inStockStoreId: String? = null,
        interfaceFilter: String? = null,
        voltageFilter: String? = null,
        platformFilter: String? = null
    ): List<ProductDto> {
        return products.values.filter { product ->
            val catOk = category.isNullOrBlank() || category == "All" || product.category.equals(category, ignoreCase = true)
            val mfgOk = manufacturer.isNullOrBlank() || manufacturer == "All" || product.manufacturer.equals(manufacturer, ignoreCase = true)
            val qOk = query.isNullOrBlank() ||
                product.familyName.contains(query, ignoreCase = true) ||
                product.shortSummary.contains(query, ignoreCase = true) ||
                product.category.contains(query, ignoreCase = true) ||
                product.variants.any { it.sku.contains(query, ignoreCase = true) || it.variantLabel.contains(query, ignoreCase = true) }
            val priceOk = maxPricePence == null || product.variants.any { it.packPricePence <= maxPricePence }
            val stockOk = inStockStoreId.isNullOrBlank() || product.variants.any {
                (inventory[inStockStoreId to it.sku]?.availableToPromise ?: 0) > 0
            }
            val ifaceOk = interfaceFilter.isNullOrBlank() || interfaceFilter == "All" ||
                product.variants.any { it.interfaceType?.contains(interfaceFilter, ignoreCase = true) == true }
            val voltOk = voltageFilter.isNullOrBlank() || voltageFilter == "All" ||
                product.variants.any { it.operatingVoltage?.contains(voltageFilter, ignoreCase = true) == true }
            val platOk = platformFilter.isNullOrBlank() || platformFilter == "All" ||
                product.variants.any { v -> v.supportedPlatforms.any { it.contains(platformFilter, ignoreCase = true) } }
            catOk && mfgOk && qOk && priceOk && stockOk && ifaceOk && voltOk && platOk
        }.sortedByDescending { it.featured }
    }

    fun getProduct(productId: String): ProductDto =
        products[productId] ?: throw ApiNotFoundException("Product $productId not found")

    fun getStoreInventory(storeId: String, sku: String? = null): List<StoreInventoryDto> =
        inventory.values.filter { it.storeId == storeId && (sku == null || it.sku == sku) }
            .sortedBy { it.sku }

    fun getSkuStockAcrossStores(sku: String): List<StoreInventoryDto> =
        inventory.values.filter { it.sku == sku }.sortedByDescending { it.availableToPromise }

    fun computeBreakdown(mode: FulfilmentMode, items: List<BasketLineRequest>, discountPence: Long = 0L): PriceBreakdownDto {
        val pricedLines = items.map { req ->
            val (product, variant) = findVariant(req.sku)
            require(req.packCount >= variant.minPackQuantity) {
                "Minimum pack quantity for ${variant.sku} is ${variant.minPackQuantity}"
            }
            val tierPrice = variant.tiers
                .filter { req.packCount >= it.minPacks }
                .maxByOrNull { it.minPacks }?.packPricePence ?: variant.packPricePence
            val effectiveUnit = if (variant.packQuantity > 0) tierPrice / variant.packQuantity else tierPrice
            PricedLineDto(
                sku = variant.sku,
                productId = product.id,
                title = product.familyName,
                variantLabel = variant.variantLabel,
                packCount = req.packCount,
                unitsPerPack = variant.packQuantity,
                effectivePackPricePence = tierPrice,
                effectiveUnitPricePence = effectiveUnit,
                lineTotalPence = tierPrice * req.packCount
            )
        }
        val gross = pricedLines.sumOf { it.lineTotalPence }
        val cappedDiscount = discountPence.coerceIn(0L, gross)
        val netIncVat = gross - cappedDiscount
        val deliveryFee = when {
            mode == FulfilmentMode.CLICK_AND_COLLECT -> 0L
            netIncVat >= 7500L || netIncVat == 0L -> 0L
            else -> 399L
        }
        val total = netIncVat + deliveryFee
        val vat = ((netIncVat.toDouble() * 2000.0) / 12000.0).roundToLong()
        val exVat = netIncVat - vat
        return PriceBreakdownDto(
            subtotalExVatPence = exVat,
            vatPence = vat,
            deliveryFeePence = deliveryFee,
            discountPence = cappedDiscount,
            totalPence = total,
            lines = pricedLines
        )
    }

    fun reserveInventory(req: ReserveRequest, nowMillis: Long = System.currentTimeMillis()): List<ReservationDto> = synchronized(txLock) {
        val cacheKey = "reserve:${req.idempotencyKey}"
        @Suppress("UNCHECKED_CAST")
        (idempotencyCache[cacheKey] as? List<ReservationDto>)?.let { return it }

        sweepExpiredInternal(nowMillis)

        req.items.forEach { line ->
            val (_, variant) = findVariant(line.sku)
            require(line.packCount >= variant.minPackQuantity) {
                "Minimum pack quantity for ${line.sku} is ${variant.minPackQuantity}"
            }
            val stock = inventory[req.storeId to line.sku]
                ?: throw ApiNotFoundException("SKU ${line.sku} is not stocked at ${req.storeId}")
            if (stock.availableToPromise < line.packCount) {
                throw ApiConflictException(
                    "Insufficient available-to-promise stock for ${line.sku}: requested ${line.packCount}, available ${stock.availableToPromise}"
                )
            }
        }

        val expiryIso = isoUtc(nowMillis + 15 * 60 * 1000L)
        val created = req.items.map { line ->
            val key = req.storeId to line.sku
            val current = inventory.getValue(key)
            inventory[key] = current.copy(
                reservedQty = current.reservedQty + line.packCount,
                version = current.version + 1
            )
            val res = ReservationDto(
                id = "RES-${UUID.randomUUID().toString().take(6).uppercase()}",
                basketId = req.basketId,
                storeId = req.storeId,
                sku = line.sku,
                quantity = line.packCount,
                status = ReservationStatus.HELD,
                expiresAtIso = expiryIso
            )
            reservations[res.id] = res
            res
        }
        idempotencyCache[cacheKey] = created
        created
    }

    fun checkoutAndPay(req: CheckoutPayRequest, nowMillis: Long = System.currentTimeMillis()): OrderDto = synchronized(txLock) {
        val cacheKey = "pay:${req.idempotencyKey}"
        (idempotencyCache[cacheKey] as? OrderDto)?.let { return it }

        sweepExpiredInternal(nowMillis)

        val activeRes = req.reservationIds.map { id ->
            val r = reservations[id] ?: throw ApiNotFoundException("Reservation $id not found")
            if (r.status == ReservationStatus.EXPIRED || parseIsoMillis(r.expiresAtIso) < nowMillis) {
                throw ApiConflictException("Reservation $id expired before payment. Please re-reserve stock.")
            }
            if (r.status != ReservationStatus.HELD) {
                throw ApiConflictException("Reservation $id is ${r.status}")
            }
            r
        }

        val breakdown = computeBreakdown(req.fulfilmentMode, req.items)
        if (req.simulateTimeout && !settledPayments.containsKey(req.idempotencyKey)) {
            throw ApiConflictException("PAYMENT_TIMEOUT: Simulated gateway timeout. Retry safely with the same idempotency key (${req.idempotencyKey.take(10)}).")
        }

        settledPayments.putIfAbsent(req.idempotencyKey, "SIM-UK-${UUID.randomUUID().toString().take(8).uppercase()}")
        activeRes.forEach { r -> reservations[r.id] = r.copy(status = ReservationStatus.CONFIRMED) }

        val store = stores[req.storeId] ?: throw ApiNotFoundException("Store ${req.storeId} not found")
        val orderId = "ORD-${UUID.randomUUID().toString().take(6).uppercase()}"
        val collectionRef = if (req.fulfilmentMode == FulfilmentMode.CLICK_AND_COLLECT) "VW-${orderId.takeLast(6)}" else null
        val fulfilmentStatus = if (req.simulateFulfilmentError) FulfilmentStatus.FULFILMENT_ERROR else FulfilmentStatus.ORDER_ACCEPTED
        val orderStatus = if (req.simulateFulfilmentError) OrderStatus.NEEDS_RECONCILIATION else OrderStatus.ACCEPTED

        val order = OrderDto(
            id = orderId,
            storeId = req.storeId,
            storeName = store.name,
            customerEmail = req.customerEmail,
            fulfilmentMode = req.fulfilmentMode,
            orderStatus = orderStatus,
            paymentStatus = PaymentStatus.SUCCEEDED,
            fulfilmentStatus = fulfilmentStatus,
            collectionReference = collectionRef,
            estimatedReadyIso = isoUtc(nowMillis + store.collectionLeadMinutes * 60_000L),
            subtotalExVatPence = breakdown.subtotalExVatPence,
            vatPence = breakdown.vatPence,
            deliveryFeePence = breakdown.deliveryFeePence,
            totalPence = breakdown.totalPence,
            items = breakdown.lines,
            createdAtIso = isoUtc(nowMillis)
        )
        orders[order.id] = order
        idempotencyCache[cacheKey] = order
        emitNotification(
            previewTitle = "Voltworks order update",
            body = if (orderStatus == OrderStatus.NEEDS_RECONCILIATION)
                "Payment confirmed for $orderId; store fulfilment queued for reconciliation."
            else
                "Order $orderId accepted at ${store.name}. Status: Order accepted."
        )
        order
    }

    fun advanceOrderFulfilment(
        orderId: String,
        targetStatus: FulfilmentStatus,
        expectedVersion: Int,
        actorId: String,
        actorRole: StaffRole,
        collectionRefConfirmation: String? = null
    ): OrderDto = synchronized(txLock) {
        requireRole(actorRole, setOf(StaffRole.RETAIL_STAFF, StaffRole.MANAGER, StaffRole.ADMIN))
        val order = orders[orderId] ?: throw ApiNotFoundException("Order $orderId not found")
        if (order.version != expectedVersion) {
            throw ApiConflictException("Concurrent modification on $orderId (expected v$expectedVersion, actual v${order.version})")
        }
        if (targetStatus == FulfilmentStatus.COLLECTED) {
            require(order.fulfilmentStatus == FulfilmentStatus.READY_FOR_COLLECTION) {
                "Order must be READY_FOR_COLLECTION before handover"
            }
            require(collectionRefConfirmation != null && collectionRefConfirmation.equals(order.collectionReference, ignoreCase = true)) {
                "Collection reference verification failed"
            }
            order.items.forEach { line ->
                val key = order.storeId to line.sku
                inventory[key]?.let { stock ->
                    inventory[key] = stock.copy(
                        physicalQty = (stock.physicalQty - line.packCount).coerceAtLeast(0),
                        reservedQty = (stock.reservedQty - line.packCount).coerceAtLeast(0),
                        version = stock.version + 1
                    )
                }
            }
        }
        val updated = order.copy(
            fulfilmentStatus = targetStatus,
            orderStatus = if (targetStatus == FulfilmentStatus.COLLECTED || targetStatus == FulfilmentStatus.DELIVERED) OrderStatus.COMPLETED else order.orderStatus,
            handoverVerifiedBy = if (targetStatus == FulfilmentStatus.COLLECTED) actorId else order.handoverVerifiedBy,
            version = order.version + 1
        )
        orders[orderId] = updated
        recordAudit(actorId, actorRole, "FULFILMENT_${targetStatus.name}", "ORDER", orderId, "Staff verified status transition")
        emitNotification("Collection update", "Order $orderId is now ${targetStatus.name.replace('_', ' ').lowercase()}.")
        updated
    }

    fun bookRepair(req: RepairBookRequest): RepairJobDto = synchronized(txLock) {
        val cacheKey = "repair:${req.idempotencyKey}"
        (idempotencyCache[cacheKey] as? RepairJobDto)?.let { return it }
        require(req.dataConsentAccepted) { "Data operation consent is required before booking." }
        val store = stores[req.storeId] ?: throw ApiNotFoundException("Store ${req.storeId} not found")
        val job = RepairJobDto(
            id = "REP-${UUID.randomUUID().toString().take(5).uppercase()}",
            customerName = req.customerName,
            customerContact = req.customerContact,
            storeId = req.storeId,
            storeName = store.name,
            category = req.category,
            deviceModel = req.deviceModel,
            serialNumber = req.serialNumber,
            reportedFault = req.reportedFault,
            appointmentSlotLabel = req.appointmentSlotLabel,
            status = RepairStatus.BOOKED,
            diagnosticFeePence = 2900L,
            diagnosticPaid = true,
            diagnosticCredited = false,
            approvedQuoteVersion = null,
            approvedRemainingPence = null,
            controlledAccessMode = req.controlledAccessMode,
            dataConsentAccepted = true,
            intakeConditionNotes = null,
            suppliedAccessories = null,
            finalTestRecord = null,
            collectionReceiptRef = null,
            warrantyMonths = 6,
            progressNotes = listOf("Intake slot reserved (${req.appointmentSlotLabel}). £29.00 diagnostic assessment paid.")
        )
        repairJobs[job.id] = job
        idempotencyCache[cacheKey] = job
        emitNotification("Repair appointment", "Repair intake booked (${job.id}).")
        job
    }

    fun advanceRepairStatus(
        jobId: String,
        targetStatus: RepairStatus,
        intakeNotes: String? = null,
        accessories: String? = null,
        finalTestRecord: String? = null,
        actorId: String = "tech-hannah",
        actorRole: StaffRole = StaffRole.TECHNICIAN
    ): RepairJobDto = synchronized(txLock) {
        requireRole(actorRole, setOf(StaffRole.TECHNICIAN, StaffRole.MANAGER, StaffRole.ADMIN))
        val job = repairJobs[jobId] ?: throw ApiNotFoundException("Repair $jobId not found")
        val receipt = if (targetStatus == RepairStatus.COLLECTED) "RCP-${jobId.takeLast(4)}" else job.collectionReceiptRef
        val updated = job.copy(
            status = targetStatus,
            intakeConditionNotes = intakeNotes ?: job.intakeConditionNotes ?: "Light bench wear, screen intact, ESD check passed.",
            suppliedAccessories = accessories ?: job.suppliedAccessories ?: "Device unit + protective sleeve",
            finalTestRecord = finalTestRecord ?: if (targetStatus == RepairStatus.READY || targetStatus == RepairStatus.COLLECTED) "24-hour thermal & port load soak passed" else job.finalTestRecord,
            collectionReceiptRef = receipt,
            progressNotes = job.progressNotes + "Status moved to ${targetStatus.label}.",
            version = job.version + 1
        )
        repairJobs[jobId] = updated
        recordAudit(actorId, actorRole, "REPAIR_STATUS_${targetStatus.name}", "REPAIR_JOB", jobId, "Bench progression")
        emitNotification("Repair status", "A repair job update is available in your tracker.")
        updated
    }

    fun issueRepairQuote(
        jobId: String,
        totalPence: Long,
        partsGrade: PartsGrade,
        partsLimitations: String,
        scopeSummary: String,
        materialChange: Boolean,
        expectedVersion: Int,
        actorId: String = "tech-hannah",
        actorRole: StaffRole = StaffRole.TECHNICIAN
    ): RepairJobDto = synchronized(txLock) {
        requireRole(actorRole, setOf(StaffRole.TECHNICIAN, StaffRole.MANAGER, StaffRole.ADMIN))
        val job = repairJobs[jobId] ?: throw ApiNotFoundException("Repair $jobId not found")
        if (job.version != expectedVersion) {
            throw ApiConflictException("Version conflict on $jobId")
        }
        val nextVersion = (job.quotes.maxOfOrNull { it.quoteVersion } ?: 0) + 1
        val (credit, remaining) = calculateDiagnosticCredit(totalPence, job.diagnosticPaid, job.diagnosticCredited, job.diagnosticFeePence)
        val superseded = job.quotes.map {
            if (it.customerDecision == QuoteDecision.PENDING || (materialChange && it.customerDecision == QuoteDecision.APPROVED)) {
                it.copy(customerDecision = QuoteDecision.SUPERSEDED)
            } else it
        }
        val newQuote = RepairQuoteDto(
            id = "QT-${UUID.randomUUID().toString().take(6).uppercase()}",
            repairJobId = jobId,
            quoteVersion = nextVersion,
            totalPence = totalPence,
            diagnosticCreditPence = credit,
            remainingPence = remaining,
            partsGrade = partsGrade,
            partsLimitations = partsLimitations,
            scopeSummary = scopeSummary,
            materialChange = materialChange,
            customerDecision = QuoteDecision.PENDING,
            createdAtIso = isoUtc(System.currentTimeMillis())
        )
        val updated = job.copy(
            status = RepairStatus.AWAITING_APPROVAL,
            approvedQuoteVersion = if (materialChange) null else job.approvedQuoteVersion,
            approvedRemainingPence = if (materialChange) null else job.approvedRemainingPence,
            quotes = superseded + newQuote,
            progressNotes = job.progressNotes + "Quote v$nextVersion issued (${MoneyFormat.gbp(totalPence)}; credit ${MoneyFormat.gbp(credit)} -> ${MoneyFormat.gbp(remaining)} due).",
            version = job.version + 1
        )
        repairJobs[jobId] = updated
        recordAudit(actorId, actorRole, "ISSUE_QUOTE_V$nextVersion", "REPAIR_JOB", jobId, scopeSummary)
        emitNotification("Repair quote ready", "Quote v$nextVersion is awaiting your approval.")
        updated
    }

    fun decideRepairQuote(jobId: String, req: QuoteDecisionRequest): RepairJobDto = synchronized(txLock) {
        val cacheKey = "quote-dec:$jobId:${req.idempotencyKey}"
        (idempotencyCache[cacheKey] as? RepairJobDto)?.let { return it }

        val job = repairJobs[jobId] ?: throw ApiNotFoundException("Repair $jobId not found")
        if (job.version != req.expectedVersion) {
            throw ApiConflictException("Quote decision version mismatch on $jobId")
        }
        val quote = job.quotes.firstOrNull { it.quoteVersion == req.quoteVersion }
            ?: throw ApiNotFoundException("Quote v${req.quoteVersion} not found")
        require(quote.customerDecision == QuoteDecision.PENDING) {
            "Quote v${req.quoteVersion} is already ${quote.customerDecision}"
        }
        val updatedQuotes = job.quotes.map {
            if (it.quoteVersion == req.quoteVersion) {
                it.copy(customerDecision = if (req.approve) QuoteDecision.APPROVED else QuoteDecision.DECLINED)
            } else it
        }
        val updated = if (req.approve) {
            val (credit, remaining) = calculateDiagnosticCredit(quote.totalPence, job.diagnosticPaid, job.diagnosticCredited, job.diagnosticFeePence)
            job.copy(
                status = RepairStatus.REPAIRING,
                diagnosticCredited = job.diagnosticCredited || credit > 0L,
                approvedQuoteVersion = quote.quoteVersion,
                approvedRemainingPence = remaining,
                quotes = updatedQuotes,
                progressNotes = job.progressNotes + "Quote v${quote.quoteVersion} approved. Remaining balance: ${MoneyFormat.gbp(remaining)}.",
                version = job.version + 1
            )
        } else {
            job.copy(
                status = RepairStatus.DECLINED_QUOTE,
                quotes = updatedQuotes,
                progressNotes = job.progressNotes + "Quote v${quote.quoteVersion} declined. Diagnostic-only assessment retained.",
                version = job.version + 1
            )
        }
        repairJobs[jobId] = updated
        idempotencyCache[cacheKey] = updated
        updated
    }

    fun openWarrantyReturn(jobId: String, req: WarrantyReturnRequest): RepairJobDto = synchronized(txLock) {
        val cacheKey = "wr:$jobId:${req.idempotencyKey}"
        (idempotencyCache[cacheKey] as? RepairJobDto)?.let { return it }

        val job = repairJobs[jobId] ?: throw ApiNotFoundException("Repair $jobId not found")
        val wr = WarrantyReturnDto(
            id = "WR-${UUID.randomUUID().toString().take(5).uppercase()}",
            originalJobId = jobId,
            reportedRecurringFault = req.reportedRecurringFault,
            outcome = WarrantyOutcome.WARRANTY_ASSESSMENT,
            freshDiagnosticCharged = false,
            resolutionNotes = "Routed to bench under ${job.warrantyMonths}-month parts & workmanship guarantee (supplements statutory rights). No fresh diagnostic fee charged.",
            createdAtIso = isoUtc(System.currentTimeMillis())
        )
        val updated = job.copy(
            status = RepairStatus.WARRANTY_RETURN,
            warrantyReturns = job.warrantyReturns + wr,
            progressNotes = job.progressNotes + "Warranty return ${wr.id} opened for assessment (no new diagnostic charge).",
            version = job.version + 1
        )
        repairJobs[jobId] = updated
        idempotencyCache[cacheKey] = updated
        emitNotification("Warranty assessment", "Warranty return ${wr.id} routed for bench inspection.")
        updated
    }

    fun listWorkshops(): List<WorkshopEventDto> = workshopEvents.values.sortedBy { it.startsAtUtcIso }
    fun listWorkshopBookings(): List<WorkshopBookingDto> = workshopBookings.values.toList()

    fun holdWorkshopSeat(
        eventId: String,
        req: WorkshopHoldRequest,
        nowMillis: Long = System.currentTimeMillis(),
        holdTtlMillis: Long = 600_000L
    ): WorkshopBookingDto = synchronized(txLock) {
        val cacheKey = "ws-hold:${req.idempotencyKey}"
        (idempotencyCache[cacheKey] as? WorkshopBookingDto)?.let { return it }

        sweepExpiredInternal(nowMillis)
        val evt = workshopEvents[eventId] ?: throw ApiNotFoundException("Workshop event $eventId not found")
        val booking = if (evt.availableSeats > 0) {
            workshopEvents[eventId] = evt.copy(heldSeats = evt.heldSeats + 1, version = evt.version + 1)
            WorkshopBookingDto(
                id = "WB-${UUID.randomUUID().toString().take(5).uppercase()}",
                eventId = eventId,
                eventTitle = evt.title,
                startsAtLondonFormatted = evt.startsAtLondonFormatted,
                attendeeName = req.attendeeName,
                attendeeEmail = req.attendeeEmail,
                status = WorkshopBookingStatus.HELD,
                holdExpiresAtIso = isoUtc(nowMillis + holdTtlMillis),
                attended = false
            )
        } else {
            WorkshopBookingDto(
                id = "WB-${UUID.randomUUID().toString().take(5).uppercase()}",
                eventId = eventId,
                eventTitle = evt.title,
                startsAtLondonFormatted = evt.startsAtLondonFormatted,
                attendeeName = req.attendeeName,
                attendeeEmail = req.attendeeEmail,
                status = WorkshopBookingStatus.WAITLISTED,
                holdExpiresAtIso = null,
                attended = false
            )
        }
        workshopBookings[booking.id] = booking
        idempotencyCache[cacheKey] = booking
        booking
    }

    fun confirmWorkshopBooking(bookingId: String, nowMillis: Long = System.currentTimeMillis()): WorkshopBookingDto = synchronized(txLock) {
        sweepExpiredInternal(nowMillis)
        val booking = workshopBookings[bookingId] ?: throw ApiNotFoundException("Booking $bookingId not found")
        if (booking.status == WorkshopBookingStatus.EXPIRED) {
            throw ApiConflictException("Workshop seat hold $bookingId has expired. Please request a fresh seat hold.")
        }
        if (booking.status != WorkshopBookingStatus.HELD) {
            throw ApiConflictException("Cannot confirm workshop booking from status ${booking.status}")
        }
        val evt = workshopEvents.getValue(booking.eventId)
        workshopEvents[evt.id] = evt.copy(
            heldSeats = (evt.heldSeats - 1).coerceAtLeast(0),
            confirmedSeats = evt.confirmedSeats + 1,
            version = evt.version + 1
        )
        val confirmed = booking.copy(status = WorkshopBookingStatus.CONFIRMED, holdExpiresAtIso = null)
        workshopBookings[bookingId] = confirmed
        emitNotification("Workshop booked", "Place confirmed for ${evt.title} (${evt.startsAtLondonFormatted}).")
        confirmed
    }

    fun cancelWorkshopBooking(bookingId: String): WorkshopBookingDto = synchronized(txLock) {
        val booking = workshopBookings[bookingId] ?: throw ApiNotFoundException("Booking $bookingId not found")
        val evt = workshopEvents.getValue(booking.eventId)
        if (booking.status == WorkshopBookingStatus.CONFIRMED) {
            workshopEvents[evt.id] = evt.copy(confirmedSeats = (evt.confirmedSeats - 1).coerceAtLeast(0), version = evt.version + 1)
        } else if (booking.status == WorkshopBookingStatus.HELD) {
            workshopEvents[evt.id] = evt.copy(heldSeats = (evt.heldSeats - 1).coerceAtLeast(0), version = evt.version + 1)
        }
        val refunded = booking.copy(status = WorkshopBookingStatus.REFUNDED, holdExpiresAtIso = null)
        workshopBookings[bookingId] = refunded
        emitNotification("Workshop refund", "Booking $bookingId cancelled and refunded under 48-hour terms.")
        refunded
    }

    fun expireWorkshopHoldNow(bookingId: String): WorkshopBookingDto = synchronized(txLock) {
        val booking = workshopBookings[bookingId] ?: throw ApiNotFoundException("Booking $bookingId not found")
        if (booking.status == WorkshopBookingStatus.HELD) {
            val evt = workshopEvents.getValue(booking.eventId)
            workshopEvents[evt.id] = evt.copy(heldSeats = (evt.heldSeats - 1).coerceAtLeast(0), version = evt.version + 1)
            val exp = booking.copy(status = WorkshopBookingStatus.EXPIRED)
            workshopBookings[bookingId] = exp
            return exp
        }
        booking
    }

    fun createTradeAccount(req: TradeAccountRequest): TradeAccountDto = synchronized(txLock) {
        val acc = TradeAccountDto(
            id = "TRD-${UUID.randomUUID().toString().take(5).uppercase()}",
            organisationName = req.organisationName,
            companyRegNo = req.companyRegNo,
            vatNumber = req.vatNumber,
            creditApproved = false, // Never grant automatic credit
            creditLimitPence = 0L,
            paymentTermsDays = 0
        )
        tradeAccounts[acc.id] = acc
        acc
    }

    fun submitTradeQuote(req: TradeQuoteRequest): TradeQuoteDto = synchronized(txLock) {
        val breakdown = computeBreakdown(FulfilmentMode.DELIVERY, req.items)
        val q = TradeQuoteDto(
            id = "TQ-${UUID.randomUUID().toString().take(5).uppercase()}",
            tradeAccountId = req.tradeAccountId,
            poReference = req.poReference,
            notes = req.notes,
            totalPence = breakdown.totalPence,
            status = "UNDER_REVIEW",
            createdAtIso = isoUtc(System.currentTimeMillis())
        )
        tradeQuotes.add(0, q)
        q
    }

    fun submitBuildingCentreEnquiry(req: BuildingCentreEnquiryRequest): BuildingCentreEnquiryDto = synchronized(txLock) {
        val enq = BuildingCentreEnquiryDto(
            id = "BC-${UUID.randomUUID().toString().take(5).uppercase()}",
            organisationName = req.organisationName,
            contactEmail = req.contactEmail,
            serviceScope = req.serviceScope,
            specificationSummary = req.specificationSummary,
            status = "ASSIGNED_TO_ENGINEERING",
            createdAtIso = isoUtc(System.currentTimeMillis())
        )
        buildingEnquiries.add(0, enq)
        emitNotification("Building Centre enquiry", "Enquiry ${enq.id} logged for ${req.serviceScope}.")
        enq
    }

    fun sweepExpiredInternal(nowMillis: Long = System.currentTimeMillis()): Int = synchronized(txLock) {
        var count = 0
        reservations.values.filter { it.status == ReservationStatus.HELD && parseIsoMillis(it.expiresAtIso) < nowMillis }.forEach { r ->
            reservations[r.id] = r.copy(status = ReservationStatus.EXPIRED)
            inventory[r.storeId to r.sku]?.let { stock ->
                inventory[r.storeId to r.sku] = stock.copy(
                    reservedQty = (stock.reservedQty - r.quantity).coerceAtLeast(0),
                    version = stock.version + 1
                )
            }
            count++
        }
        workshopBookings.values.filter {
            it.status == WorkshopBookingStatus.HELD && it.holdExpiresAtIso != null && parseIsoMillis(it.holdExpiresAtIso) < nowMillis
        }.forEach { b ->
            workshopBookings[b.id] = b.copy(status = WorkshopBookingStatus.EXPIRED)
            workshopEvents[b.eventId]?.let { evt ->
                workshopEvents[evt.id] = evt.copy(heldSeats = (evt.heldSeats - 1).coerceAtLeast(0), version = evt.version + 1)
            }
            count++
        }
        count
    }

    fun listOrders(): List<OrderDto> = orders.values.sortedByDescending { it.createdAtIso }
    fun listRepairs(): List<RepairJobDto> = repairJobs.values.sortedByDescending { it.id }
    fun listTradeAccounts(): List<TradeAccountDto> = tradeAccounts.values.toList()
    fun listTradeQuotes(): List<TradeQuoteDto> = tradeQuotes.toList()
    fun listBuildingEnquiries(): List<BuildingCentreEnquiryDto> = buildingEnquiries.toList()
    fun listNotifications(): List<NotificationDto> = notifications.toList()
    fun listAuditLogs(): List<AuditLogDto> = auditLogs.toList()

    fun calculateDiagnosticCredit(
        quoteTotalPence: Long,
        diagnosticPaid: Boolean,
        alreadyCredited: Boolean,
        diagnosticFeePence: Long = 2900L
    ): Pair<Long, Long> {
        val credit = if (diagnosticPaid && !alreadyCredited) minOf(diagnosticFeePence, quoteTotalPence) else 0L
        return credit to (quoteTotalPence - credit)
    }

    private fun findVariant(sku: String): Pair<ProductDto, ProductVariantDto> {
        products.values.forEach { p ->
            p.variants.firstOrNull { it.sku == sku }?.let { return p to it }
        }
        throw ApiNotFoundException("SKU $sku not found")
    }

    private fun requireRole(role: StaffRole, allowed: Set<StaffRole>) {
        if (role !in allowed) throw ApiForbiddenException("Role $role is not authorised")
    }

    private fun emitNotification(previewTitle: String, body: String) {
        notifications.add(
            0,
            NotificationDto(
                id = "NTF-${UUID.randomUUID().toString().take(6).uppercase()}",
                channel = "IN_APP",
                previewTitle = previewTitle,
                body = body,
                deliveryStatus = NotificationDeliveryStatus.DELIVERED,
                createdAtIso = isoUtc(System.currentTimeMillis())
            )
        )
    }

    private fun recordAudit(actorId: String, role: StaffRole, action: String, entityType: String, entityId: String, reason: String) {
        auditLogs.add(
            0,
            AuditLogDto(
                id = auditSeq.getAndIncrement(),
                actorId = actorId,
                actorRole = role,
                action = action,
                entityType = entityType,
                entityId = entityId,
                reason = reason,
                createdAtIso = isoUtc(System.currentTimeMillis())
            )
        )
    }

    private fun isoUtc(millis: Long): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.UK)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date(millis))
    }

    private fun parseIsoMillis(iso: String): Long {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.UK)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return runCatching { sdf.parse(iso)?.time ?: 0L }.getOrDefault(0L)
    }

    private fun formatLondonTime(utcIso: String): String {
        val millis = parseIsoMillis(utcIso)
        val tz = TimeZone.getTimeZone("Europe/London")
        val sdf = SimpleDateFormat("EEE d MMM yyyy, HH:mm z", Locale.UK)
        sdf.timeZone = tz
        return sdf.format(Date(millis))
    }

    private fun seedDemoData() {
        listOf(
            StoreDto("store-sheffield", "Sheffield flagship", "Unit 1, Meadowhall Way", "Sheffield", "S9 1EP", "0114 555 0140", "sheffield@voltworks.co.uk", mapOf("Mon–Fri" to "08:30–19:00", "Sat" to "09:00–18:00", "Sun" to "10:30–16:30"), listOf("1-Hour Click & Collect", "ESD Repair Bench", "Maker Workshop Studio", "Building Centre Trade Counter"), "Present your 8-character collection reference at the orange Click & Collect desk.", true, true, true, 60, 30),
            StoreDto("store-manchester", "Manchester Northern Quarter", "42 Oldham Street", "Manchester", "M4 1LE", "0161 555 0192", "manchester@voltworks.co.uk", mapOf("Mon–Fri" to "09:00–18:30", "Sat" to "09:30–18:00", "Sun" to "11:00–16:30"), listOf("1-Hour Click & Collect", "ESD Repair Bench", "Soldering Bar"), "Report to the Ground Floor Pickup Counter.", true, true, false, 60, 20),
            StoreDto("store-bristol", "Bristol Harbourside", "18 Anchor Road", "Bristol", "BS1 5TT", "0117 555 0118", "bristol@voltworks.co.uk", mapOf("Mon–Fri" to "09:00–18:00", "Sat" to "09:00–17:30", "Sun" to "11:00–16:00"), listOf("2-Hour Click & Collect", "Robotics Workshop Lab", "Repair Intake Desk"), "Collect from Mezzanine Workshop Reception.", true, true, true, 90, 15),
            StoreDto("store-london", "London Clerkenwell", "75 St John Street", "London", "EC1M 4AN", "020 7946 0821", "clerkenwell@voltworks.co.uk", mapOf("Mon–Fri" to "08:00–19:30", "Sat" to "09:30–18:00", "Sun" to "Closed"), listOf("1-Hour Click & Collect", "Trade & Prototyping Desk"), "Use the Express Trade & Collect bay on St John Street.", true, false, true, 45, 35)
        ).forEach { stores[it.id] = it }

        val pSoldering = ProductDto(
            id = "prod-soldering-station",
            familyName = "Precision Soldering Station",
            category = "Tools & Repair",
            manufacturer = "Voltworks Pro",
            shortSummary = "60 W digital ESD-safe soldering station with 50–480 °C closed-loop control.",
            description = "Engineered for clean lead-free bench work. Features rapid PID thermal recovery, bright OLED temperature readout, weighted iron cradle with brass wool cleaner, and UK BS 1363 fused mains lead.",
            warrantyMonths = 24,
            includedContents = listOf("60 W digital control unit", "ESD-safe 24 V soldering iron (T18-D24 fitted)", "Weighted stand with brass wool & sponge", "1.5 m UK BS 1363 mains cable", "Calibration certificate"),
            documentation = listOf(mapOf("title" to "User Manual & Calibration Guide (PDF)", "url" to "VW-S60-Manual.pdf"), mapOf("title" to "UKCA & RoHS Declaration", "url" to "VW-S60-UKCA.pdf")),
            imageKeys = listOf("img_prod_soldering", "img_hero_repair", "img_hero_makers"),
            featured = true,
            highlights = listOf("60 W power" to "bolt", "Temperature control\n(50–480 °C)" to "thermostat", "Iron and stand\nincluded" to "build"),
            variants = listOf(
                ProductVariantDto("VW-SOL-060-UK", "prod-soldering-station", "60 W Station (UK Plug)", 1, 1, 12999, 12999, 2000, "145 x 110 x 92 mm", "230V AC / 24V Iron", "230 V AC (50 Hz)", listOf("Lead-free SAC305", "T18 Tips"), mapOf("Power" to "60 W", "Temp Range" to "50–480 °C", "Stability" to "±2 °C", "Tip-to-Ground" to "< 2 Ω")),
                ProductVariantDto("VW-SOL-TIP-5PK", "prod-soldering-station", "T18 Tip Assortment (5-Pack)", 5, 1, 450, 2250, 2000, "42 x 6.5 mm", "T18 Sleeve", "Passive", listOf("VW-SOL-060-UK"), mapOf("Pack Quantity" to "5 tips", "Unit Price" to "£4.50 / tip", "Plating" to "Iron-clad copper"))
            ),
            compatibility = listOf(
                CompatibilityRuleDto("prod-soldering-station", "VW-SOL-TIP-5PK", "T18 Tip Assortment (5-Pack)", "CONSUMABLE", "T18 sleeve outer diameter (6.5 mm) and heater core length match the Voltworks Pro VW-SOL-060-UK handpiece.", "Voltworks Pro Datasheet v2.1 §4")
            )
        )

        val pMcu = ProductDto(
            id = "prod-mcu-starter",
            familyName = "Microcontroller Starter Kit",
            category = "Components",
            manufacturer = "Northbridge Silicon",
            shortSummary = "RP2350 dual-core dev board with 400-tie breadboard, OLED, and sensor pack.",
            description = "Complete prototyping kit built around a 3.3 V ARM/RISC-V microcontroller with USB-C programming, 40-pin colour-coded jumpers, OLED display, and illustrated UK curriculum booklet.",
            warrantyMonths = 12,
            includedContents = listOf("RP2350 Dev Board (USB-C)", "400-tie solderless breadboard", "65x jumper wires", "0.96 in I2C OLED module", "BME280 temperature sensor"),
            documentation = listOf(mapOf("title" to "Pinout & Quickstart Schematic", "url" to "MCU-Starter-Pinout.pdf")),
            imageKeys = listOf("img_hero_makers", "img_prod_multimeter"),
            featured = true,
            highlights = listOf("3.3 V logic" to "bolt", "USB-C / I2C / SPI" to "memory", "Breadboard\nincluded" to "build"),
            variants = listOf(
                ProductVariantDto("VW-MCU-RP2350", "prod-mcu-starter", "Starter Kit (USB-C)", 1, 1, 3999, 3999, 2000, "180 x 120 x 45 mm", "USB-C / I2C / SPI", "3.3 V Logic", listOf("MicroPython", "C/C++ SDK", "Arduino"), mapOf("CPU" to "Dual Cortex-M33 @ 150 MHz", "Flash" to "4 MB QSPI", "Logic Voltage" to "3.3 V"), tiers = listOf(QuantityTierDto(5, 3699)))
            ),
            compatibility = listOf(
                CompatibilityRuleDto("prod-resistor-pack", "VW-RES-10K-10PK", "Metal Film Resistor 10kΩ (10-Pack)", "ACCESSORY", "0.6 mm axial leads fit the 400-tie breadboard; 10 kΩ matches 3.3 V GPIO pull-up specification.", "Northbridge AppNote AN-04"),
                CompatibilityRuleDto("prod-robotics-kit", "VW-ROB-ARM4", "Robotics Explorer Kit", "PLATFORM_MATCH", "RP2350 3.3 V I2C pins drive the PCA9685 PWM controller natively without level shifting.", "Albion Robotics Spec §2.3")
            )
        )

        val pMultimeter = ProductDto(
            id = "prod-multimeter",
            familyName = "Digital Multimeter",
            category = "Tools & Repair",
            manufacturer = "CalibrateUK",
            shortSummary = "True-RMS 6000-count CAT III 600 V bench & field multimeter with silicone probes.",
            description = "Reliable workshop diagnostics with auto-ranging AC/DC voltage, resistance, capacitance, continuity buzzer, diode test, and high-contrast backlit LCD.",
            warrantyMonths = 36,
            includedContents = listOf("6000-count True-RMS DMM", "CAT III 600 V silicone leads", "Type-K thermocouple", "2x AA alkaline cells"),
            documentation = listOf(mapOf("title" to "CAT III Safety & Calibration Sheet", "url" to "DMM-6000-Safety.pdf")),
            imageKeys = listOf("img_prod_multimeter", "img_hero_repair"),
            featured = true,
            highlights = listOf("CAT III 600 V" to "bolt", "True-RMS\n6000 counts" to "speed", "Silicone probes\nincluded" to "build"),
            variants = listOf(
                ProductVariantDto("VW-DMM-6000", "prod-multimeter", "CAT III 600 V Meter", 1, 1, 5999, 5999, 2000, "175 x 81 x 48 mm", "4 mm Shrouded Banana", "3 V DC (2x AA)", listOf("True-RMS", "Auto-ranging"), mapOf("Counts" to "6000", "Max Voltage" to "600 V AC/DC", "Max Current" to "10 A fused"))
            )
        )

        val pRobotics = ProductDto(
            id = "prod-robotics-kit",
            familyName = "Robotics Explorer Kit",
            category = "Robotics",
            manufacturer = "Albion Robotics",
            shortSummary = "4-DOF articulated desktop robotic arm kit with metal-gear servos and PWM driver.",
            description = "Build, wire, and program a precision 4-axis desktop manipulator. Includes anodised aluminium brackets, 4x MG996R servos, 16-channel I2C PCA9685 driver board, and 5 V 4 A UK PSU.",
            warrantyMonths = 12,
            includedContents = listOf("Anodised aluminium frame", "4x MG996R metal-gear servos", "16-ch PCA9685 PWM board", "5 V 4 A UK PSU", "Hex key set"),
            documentation = listOf(mapOf("title" to "Assembly & I2C Addressing Manual", "url" to "Robotics-Explorer.pdf")),
            imageKeys = listOf("img_hero_makers"),
            featured = true,
            highlights = listOf("5 V DC (4 A)" to "bolt", "4-DOF + Gripper" to "precision", "I2C PCA9685" to "memory"),
            variants = listOf(
                ProductVariantDto("VW-ROB-ARM4", "prod-robotics-kit", "4-DOF Desktop Arm Kit", 1, 1, 14999, 14999, 2000, "240 x 180 x 310 mm", "I2C (PCA9685)", "5 V DC", listOf("Raspberry Pi", "RP2350", "Arduino"), mapOf("Axes" to "4-DOF + Gripper", "Reach" to "285 mm", "Max Payload" to "180 g"))
            ),
            compatibility = listOf(
                CompatibilityRuleDto("prod-mcu-starter", "VW-MCU-RP2350", "Microcontroller Starter Kit", "PLATFORM_MATCH", "PCA9685 PWM controller on VW-ROB-ARM4 accepts 3.3 V I2C SDA/SCL directly from RP2350 GPIO.", "Albion Robotics Spec §2.3")
            )
        )

        val pResistorPack = ProductDto(
            id = "prod-resistor-pack",
            familyName = "Metal Film Resistor 10kΩ Pack",
            category = "Components",
            manufacturer = "Yageo Europe",
            shortSummary = "10-piece 0.25 W 1% tolerance 10 kΩ axial resistor pack (£0.15 / resistor).",
            description = "Low-noise precision 1% tolerance axial resistors suitable for breadboard pull-ups, voltage dividers, and microcontroller I/O. Sold strictly in 10-piece tape packs.",
            warrantyMonths = 12,
            includedContents = listOf("10x 10 kΩ 0.25 W ±1% axial resistors (tape-packed)"),
            documentation = listOf(mapOf("title" to "MFR-25 Series Datasheet", "url" to "MFR25-Datasheet.pdf")),
            imageKeys = listOf("img_hero_makers"),
            featured = false,
            highlights = listOf("10 pcs / pack" to "memory", "£0.15 per piece" to "bolt", "±1% tolerance" to "precision"),
            variants = listOf(
                ProductVariantDto("VW-RES-10K-10PK", "prod-resistor-pack", "10-Piece Pack (10 kΩ)", 10, 1, 15, 150, 2000, "6.3 x 2.3 mm body", "Through-Hole Axial", "Max 250 V", listOf("Breadboard", "Perfboard", "Through-hole PCB"), mapOf("Pack Quantity" to "10 pieces", "Unit Price" to "£0.15 / pc", "Pack Price" to "£1.50", "Tolerance" to "±1%"), tiers = listOf(QuantityTierDto(5, 125), QuantityTierDto(20, 100)))
            ),
            compatibility = listOf(
                CompatibilityRuleDto("prod-mcu-starter", "VW-MCU-RP2350", "Microcontroller Starter Kit", "ACCESSORY", "0.6 mm axial leads match standard 2.54 mm breadboard sockets included in VW-MCU-RP2350.", "Northbridge AppNote AN-04")
            )
        )

        val pNvme = ProductDto(
            id = "prod-usb-nvme-dock",
            familyName = "USB4 NVMe Bench Enclosure",
            category = "Computing",
            manufacturer = "Kestrel Compute",
            shortSummary = "Tool-free 40 Gbps CNC aluminium M.2 NVMe enclosure for imaging & backups.",
            description = "CNC-milled thermal chassis supporting M.2 2230/2242/2280 NVMe SSDs over USB4 / Thunderbolt 4 with braided USB-C cable.",
            warrantyMonths = 24,
            includedContents = listOf("CNC NVMe enclosure", "Silicone thermal pad", "0.5 m 40 Gbps USB-C cable"),
            documentation = listOf(mapOf("title" to "Thermal Pad & Host Guide", "url" to "NVMe-Dock.pdf")),
            imageKeys = listOf("img_hero_repair"),
            featured = false,
            highlights = listOf("40 Gbps USB4" to "speed", "M.2 2230–2280" to "memory", "CNC heatsink" to "build"),
            variants = listOf(
                ProductVariantDto("VW-CMP-NVME40", "prod-usb-nvme-dock", "USB4 40 Gbps Enclosure", 1, 1, 4499, 4499, 2000, "106 x 42 x 14 mm", "USB4 / M.2 M-Key", "5 V USB-C Bus", listOf("Linux", "macOS", "Windows 11"), mapOf("Bandwidth" to "40 Gbps", "Form Factors" to "2230 / 2242 / 2280"))
            )
        )

        val pMatter = ProductDto(
            id = "prod-matter-relay",
            familyName = "Matter Thread Smart Relay",
            category = "Smart Home",
            manufacturer = "Pennine Controls",
            shortSummary = "UK back-box 16 A Matter-over-Thread switch module with power metering.",
            description = "Compact UK back-box compatible smart relay with zero-cross switching, active power telemetry, and local Thread mesh control.",
            warrantyMonths = 24,
            includedContents = listOf("16 A Matter-over-Thread module", "Bootlace ferrule kit", "BS 7671 wiring leaflet"),
            documentation = listOf(mapOf("title" to "UK Back-Box Wiring Diagram", "url" to "Matter-Relay-Wiring.pdf")),
            imageKeys = listOf("img_hero_makers"),
            featured = false,
            highlights = listOf("230 V AC / 16 A" to "bolt", "Matter 1.3 Thread" to "memory", "Zero-cross relay" to "precision"),
            variants = listOf(
                ProductVariantDto("VW-SMT-MAT16A", "prod-matter-relay", "16 A Matter Switch Module", 1, 1, 2799, 2799, 2000, "42 x 39 x 18 mm", "Thread / Matter 1.3", "230 V AC (50 Hz)", listOf("Apple Home", "Google Home", "Home Assistant"), mapOf("Max Load" to "16 A resistive", "Protocol" to "IEEE 802.15.4 Thread"))
            )
        )

        listOf(pSoldering, pMcu, pMultimeter, pRobotics, pResistorPack, pNvme, pMatter).forEach { products[it.id] = it }

        val future2d = isoUtc(System.currentTimeMillis() + 2 * 86_400_000L)
        val future4d = isoUtc(System.currentTimeMillis() + 4 * 86_400_000L)
        listOf(
            StoreInventoryDto("store-sheffield", "VW-SOL-060-UK", 6, 1, 0, 4, future2d),
            StoreInventoryDto("store-sheffield", "VW-SOL-TIP-5PK", 18, 0, 1, 0, null),
            StoreInventoryDto("store-sheffield", "VW-MCU-RP2350", 14, 2, 0, 10, future2d),
            StoreInventoryDto("store-sheffield", "VW-DMM-6000", 8, 0, 0, 0, null),
            StoreInventoryDto("store-sheffield", "VW-ROB-ARM4", 1, 0, 0, 3, future4d), // Last 1 item for concurrency test
            StoreInventoryDto("store-sheffield", "VW-RES-10K-10PK", 45, 0, 0, 0, null),
            StoreInventoryDto("store-sheffield", "VW-CMP-NVME40", 5, 0, 0, 0, null),
            StoreInventoryDto("store-sheffield", "VW-SMT-MAT16A", 9, 1, 0, 0, null),
            StoreInventoryDto("store-manchester", "VW-SOL-060-UK", 4, 0, 0, 0, null),
            StoreInventoryDto("store-manchester", "VW-MCU-RP2350", 7, 0, 0, 0, null),
            StoreInventoryDto("store-manchester", "VW-DMM-6000", 5, 1, 0, 0, null),
            StoreInventoryDto("store-manchester", "VW-RES-10K-10PK", 30, 0, 0, 0, null),
            StoreInventoryDto("store-bristol", "VW-SOL-060-UK", 3, 0, 0, 2, future2d),
            StoreInventoryDto("store-bristol", "VW-ROB-ARM4", 2, 0, 0, 0, null),
            StoreInventoryDto("store-london", "VW-CMP-NVME40", 11, 1, 0, 0, null),
            StoreInventoryDto("store-london", "VW-RES-10K-10PK", 80, 0, 0, 0, null)
        ).forEach { inventory[it.storeId to it.sku] = it }

        val evt1 = "2027-06-12T10:00:00Z"
        val evt2 = "2027-06-19T13:00:00Z"
        val evt3 = "2027-01-30T18:00:00Z"
        val evt4 = "2027-02-06T10:30:00Z"
        val evt5 = "2027-07-03T17:30:00Z"
        listOf(
            WorkshopEventDto("evt-soldering-shef-1", "ws-soldering", "Soldering basics", "Hands-on through-hole and SMD soldering fundamentals on temperature-controlled stations.", "No prior soldering experience required.", "ESD mat, VW-SOL-060 station, lead-free solder, practice PCB kit included.", "Ages 14+ (under-16s accompanied).", "Full refund up to 48 hours prior; 50% credit within 24–48 hours.", "store-sheffield", "Sheffield flagship", "Hannah Patel", "Maker Studio A", evt1, formatLondonTime(evt1), 120, 3500, 8, 0, 5),
            WorkshopEventDto("evt-robot-bris-1", "ws-robot", "Build your first robot", "Assemble, calibrate, and code an obstacle-avoiding rover using RP2350 & sensors.", "Basic laptop familiarity.", "Chassis kit, RP2350, battery pack, bench tools supplied.", "Ages 12+ (under-16s accompanied).", "Full refund up to 48 hours prior.", "store-bristol", "Bristol Harbourside", "Callum Reid", "Robotics Lab", evt2, formatLondonTime(evt2), 180, 5500, 6, 0, 5),
            WorkshopEventDto("evt-mcu-manc-1", "ws-mcu", "Microcontroller projects", "Interface I2C OLED displays, environmental sensors, and PWM outputs in MicroPython.", "Bring a laptop with USB-C/A.", "RP2350 kit and breadboard pack supplied for use.", "Ages 16+.", "Full refund up to 48 hours prior.", "store-manchester", "Manchester Northern Quarter", "Priya Nair", "NQ Workshop Room", evt3, formatLondonTime(evt3), 150, 4000, 10, 0, 4),
            WorkshopEventDto("evt-pc-shef-1", "ws-pc-build", "PC building", "Airflow planning, ESD-safe CPU/NVMe assembly, cabling, and UEFI firmware setup.", "None — ideal for first-time builders.", "Test benches, torque drivers, ESD straps provided.", "Ages 14+.", "Full refund up to 48 hours prior.", "store-sheffield", "Sheffield flagship", "Owen Davies", "Maker Studio B", evt4, formatLondonTime(evt4), 150, 4500, 8, 0, 3),
            WorkshopEventDto("evt-smart-shef-1", "ws-smart-home", "Smart-home setup", "Design reliable local Matter & Thread automations with zero cloud lock-in.", "Basic home Wi-Fi familiarity.", "Thread border router and Matter relay rigs on bench.", "Ages 18+.", "Full refund up to 48 hours prior.", "store-sheffield", "Sheffield flagship", "Claire Hughes", "Maker Studio A", evt5, formatLondonTime(evt5), 120, 3000, 8, 0, 2)
        ).forEach { workshopEvents[it.id] = it }

        // Seed 1 active repair job ready for inspection & 1 demo order for immediate Home visibility
        val seededRepair = RepairJobDto(
            id = "REP-40912",
            customerName = "Samira Patel",
            customerContact = "samira.patel@example.co.uk",
            storeId = "store-sheffield",
            storeName = "Sheffield flagship",
            category = RepairCategory.LAPTOP_PC,
            deviceModel = "Framework Laptop 13 (AMD)",
            serialNumber = "FRMWK-88241-UK",
            reportedFault = "Primary USB-C charging port intermittent under load",
            appointmentSlotLabel = "Wed 29 Jan · 10:30",
            status = RepairStatus.DIAGNOSING,
            diagnosticFeePence = 2900L,
            diagnosticPaid = true,
            diagnosticCredited = false,
            approvedQuoteVersion = null,
            approvedRemainingPence = null,
            controlledAccessMode = "GUEST_PROFILE_AT_BENCH",
            dataConsentAccepted = true,
            intakeConditionNotes = "Clean aluminium chassis; minor trackpad shine; battery 89% health.",
            suppliedAccessories = "Laptop + 60 W USB-C charger",
            finalTestRecord = null,
            collectionReceiptRef = null,
            warrantyMonths = 6,
            progressNotes = listOf(
                "Intake slot reserved; £29.00 diagnostic assessment paid.",
                "Device checked in at Sheffield flagship ESD bench.",
                "Technician inspecting USB-C PD controller rail."
            ),
            version = 1
        )
        repairJobs[seededRepair.id] = seededRepair

        emitNotification(
            previewTitle = "Welcome to Voltworks",
            body = "Notifications show queued, sent, failed, and delivered states without exposing personal or device-access details."
        )
    }
}
