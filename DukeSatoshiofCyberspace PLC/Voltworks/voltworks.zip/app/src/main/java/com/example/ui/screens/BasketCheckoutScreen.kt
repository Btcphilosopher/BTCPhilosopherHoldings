package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.ui.components.OfflineFreshnessBanner
import com.example.ui.components.VoltworksSectionPill
import com.example.ui.components.VoltworksTopHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.VoltworksUiState

@Composable
fun BasketCheckoutScreen(
    state: VoltworksUiState,
    onBack: () -> Unit,
    onUpdateQty: (String, Int) -> Unit,
    onSetFulfilmentMode: (FulfilmentMode) -> Unit,
    onUpdateCheckoutDetails: (String, String, String, Boolean, Boolean) -> Unit,
    onReserveStock: () -> Unit,
    onPayOrder: (Boolean) -> Unit,
    onMarkOrderReady: (OrderDto) -> Unit,
    onCollectOrder: (OrderDto, String) -> Unit,
    onDisableOffline: () -> Unit,
    onBrowseShop: () -> Unit
) {
    val checkout = state.checkout
    val deliveryFee = when {
        checkout.fulfilmentMode == FulfilmentMode.CLICK_AND_COLLECT -> 0L
        state.basketGoodsPence >= 7500L || state.basketGoodsPence == 0L -> 0L
        else -> 399L
    }
    val totalIncVat = state.basketGoodsPence + deliveryFee
    val exVat = MoneyFormat.exVatFromGross(state.basketGoodsPence)
    val vat = state.basketGoodsPence - exVat

    var handoverCodeInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        VoltworksTopHeader(
            basketCount = state.basketTotalCount,
            onBasketClick = {},
            showBackButton = true,
            onBackClick = onBack
        )

        OfflineFreshnessBanner(
            offlineMode = state.offlineMode,
            lastSyncedMillis = state.syncMeta?.lastSyncedMillis,
            onGoOnline = onDisableOffline
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("Basket & Checkout", style = MaterialTheme.typography.headlineLarge)
                Text(
                    "Basket → Reserve inventory → Fulfilment → Payment → Order confirmation",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (state.basketItems.isEmpty() && checkout.completedOrder == null) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Outlined.ShoppingBag, contentDescription = null, tint = VoltworksOrange, modifier = Modifier.size(38.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Your basket is empty", style = MaterialTheme.typography.titleLarge)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Drafts are saved locally in Room even when offline.", style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = onBrowseShop,
                                colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange)
                            ) {
                                Text("Browse electronics")
                            }
                        }
                    }
                }
            }

            items(state.basketItems, key = { it.sku }) { item ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.title, style = MaterialTheme.typography.titleSmall)
                            Text("${item.variantLabel} · ${item.sku}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (item.unitsPerPack > 1) {
                                Text(
                                    "${item.packCount} pack(s) × ${item.unitsPerPack} pcs (${MoneyFormat.gbp(item.unitPricePence)}/pc)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = VoltworksOrangeDark
                                )
                            }
                            Text(
                                MoneyFormat.gbp(item.packPricePence * item.packCount),
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { onUpdateQty(item.sku, item.packCount - 1) }, modifier = Modifier.size(48.dp)) {
                                Icon(Icons.Outlined.Remove, contentDescription = "Remove one")
                            }
                            Text("${item.packCount}", style = MaterialTheme.typography.titleSmall)
                            IconButton(onClick = { onUpdateQty(item.sku, item.packCount + 1) }, modifier = Modifier.size(48.dp)) {
                                Icon(Icons.Outlined.Add, contentDescription = "Add one")
                            }
                        }
                    }
                }
            }

            if (state.basketItems.isNotEmpty()) {
                // Step 1: Fulfilment & Details
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("1. Fulfilment & Contact", style = MaterialTheme.typography.titleMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                FilterChip(
                                    selected = checkout.fulfilmentMode == FulfilmentMode.CLICK_AND_COLLECT,
                                    onClick = { onSetFulfilmentMode(FulfilmentMode.CLICK_AND_COLLECT) },
                                    label = { Text("Click & Collect (Free)") },
                                    modifier = Modifier.weight(1f)
                                )
                                FilterChip(
                                    selected = checkout.fulfilmentMode == FulfilmentMode.DELIVERY,
                                    onClick = { onSetFulfilmentMode(FulfilmentMode.DELIVERY) },
                                    label = { Text("UK Delivery") },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Text(
                                text = if (checkout.fulfilmentMode == FulfilmentMode.CLICK_AND_COLLECT)
                                    "Collection store: ${state.selectedStore?.name ?: "Sheffield flagship"} (Est. ${state.selectedStore?.collectionLeadMinutes ?: 60} min prep after acceptance)"
                                else
                                    "Standard UK delivery £3.99 (Free over £75.00)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(
                                value = checkout.customerEmail,
                                onValueChange = { onUpdateCheckoutDetails(it, checkout.deliveryAddress, checkout.purchaseOrderRef, checkout.simulateTimeout, checkout.simulateFulfilmentError) },
                                label = { Text("Receipt email") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            if (checkout.fulfilmentMode == FulfilmentMode.DELIVERY) {
                                OutlinedTextField(
                                    value = checkout.deliveryAddress,
                                    onValueChange = { onUpdateCheckoutDetails(checkout.customerEmail, it, checkout.purchaseOrderRef, checkout.simulateTimeout, checkout.simulateFulfilmentError) },
                                    label = { Text("UK Delivery Address") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }

                // Step 2: Server Price Breakdown & Reservation
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("2. Server Monetary Summary & Stock Hold", style = MaterialTheme.typography.titleMedium)
                            SummaryLine("Goods ex VAT", MoneyFormat.gbp(exVat))
                            SummaryLine("UK VAT (20%)", MoneyFormat.gbp(vat))
                            SummaryLine("Delivery", if (deliveryFee == 0L) "Free" else MoneyFormat.gbp(deliveryFee))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                            SummaryLine("Total (GBP)", MoneyFormat.gbp(totalIncVat), bold = true)

                            if (checkout.activeReservations.isNotEmpty()) {
                                VoltworksSectionPill(
                                    label = "Reserved ${checkout.activeReservations.size} SKU(s) · 15-min ATP hold active",
                                    containerColor = VoltworksSuccessTint,
                                    contentColor = VoltworksSuccess
                                )
                            }

                            Button(
                                onClick = onReserveStock,
                                enabled = !state.offlineMode,
                                colors = ButtonDefaults.buttonColors(containerColor = VoltworksNavy),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .testTag("checkout_reserve_btn")
                            ) {
                                Text(if (checkout.activeReservations.isEmpty()) "Reserve inventory at store" else "Re-check reservation")
                            }
                        }
                    }
                }

                // Step 3: Payment Simulator + Retry on Timeout
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("3. Simulated Payment Provider Adapter", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Uses SimulatedBritishPayments adapter with idempotency keys. Raw card numbers are never stored.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Demo: simulate gateway timeout", style = MaterialTheme.typography.bodySmall)
                                Switch(
                                    checked = checkout.simulateTimeout,
                                    onCheckedChange = {
                                        onUpdateCheckoutDetails(checkout.customerEmail, checkout.deliveryAddress, checkout.purchaseOrderRef, it, checkout.simulateFulfilmentError)
                                    }
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Demo: payment succeeds, fulfilment errors", style = MaterialTheme.typography.bodySmall)
                                Switch(
                                    checked = checkout.simulateFulfilmentError,
                                    onCheckedChange = {
                                        onUpdateCheckoutDetails(checkout.customerEmail, checkout.deliveryAddress, checkout.purchaseOrderRef, checkout.simulateTimeout, it)
                                    }
                                )
                            }

                            if (checkout.paymentTimedOutMessage != null) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = VoltworksWarningTint,
                                    border = BorderStroke(1.dp, VoltworksWarning)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("Payment timed out (safe to retry)", style = MaterialTheme.typography.titleSmall, color = VoltworksWarning)
                                        Text(checkout.paymentTimedOutMessage, style = MaterialTheme.typography.bodySmall)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Button(
                                            onClick = { onPayOrder(true) },
                                            colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange),
                                            modifier = Modifier.testTag("checkout_retry_payment_btn")
                                        ) {
                                            Text("Retry safely (same idempotency key)")
                                        }
                                    }
                                }
                            } else {
                                Button(
                                    onClick = { onPayOrder(false) },
                                    enabled = !state.offlineMode && checkout.activeReservations.isNotEmpty(),
                                    colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 50.dp)
                                        .testTag("checkout_pay_btn")
                                ) {
                                    Text("Pay ${MoneyFormat.gbp(totalIncVat)} (Simulated)")
                                }
                            }
                        }
                    }
                }
            }

            // Recent / Active Orders & Click-and-Collect Handover Simulator
            if (state.orders.isNotEmpty()) {
                item {
                    Text("Orders & Click-and-Collect Handover", style = MaterialTheme.typography.titleLarge)
                }
                items(state.orders, key = { it.id }) { order ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(order.id, style = MaterialTheme.typography.titleMedium)
                                Text(MoneyFormat.gbp(order.totalPence), style = MaterialTheme.typography.titleMedium, color = VoltworksOrangeDark)
                            }
                            Text(
                                "Order: ${order.orderStatus} · Payment: ${order.paymentStatus} · Fulfilment: ${order.fulfilmentStatus}",
                                style = MaterialTheme.typography.labelSmall,
                                color = VoltworksNavy
                            )
                            if (order.collectionReference != null) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = VoltworksOrangeTint
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            "Collection Reference: ${order.collectionReference}",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = VoltworksOrangeDark
                                        )
                                        Text(
                                            when (order.fulfilmentStatus) {
                                                FulfilmentStatus.ORDER_ACCEPTED -> "Order accepted — NOT ready yet. Waiting for store picking."
                                                FulfilmentStatus.PICKING -> "Picking at ${order.storeName}."
                                                FulfilmentStatus.READY_FOR_COLLECTION -> "Ready for collection at ${order.storeName}."
                                                FulfilmentStatus.COLLECTED -> "Collected & verified by ${order.handoverVerifiedBy ?: "staff"}."
                                                else -> "Status: ${order.fulfilmentStatus}"
                                            },
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }

                            if (order.fulfilmentStatus == FulfilmentStatus.ORDER_ACCEPTED || order.fulfilmentStatus == FulfilmentStatus.PICKING) {
                                OutlinedButton(
                                    onClick = { onMarkOrderReady(order) },
                                    modifier = Modifier.testTag("demo_mark_ready_${order.id}")
                                ) {
                                    Text("Staff Demo: Pick & Mark Ready for Collection")
                                }
                            } else if (order.fulfilmentStatus == FulfilmentStatus.READY_FOR_COLLECTION) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedTextField(
                                        value = handoverCodeInput,
                                        onValueChange = { handoverCodeInput = it },
                                        label = { Text("Enter ${order.collectionReference}") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Button(
                                        onClick = { onCollectOrder(order, handoverCodeInput.ifBlank { order.collectionReference ?: "" }) },
                                        colors = ButtonDefaults.buttonColors(containerColor = VoltworksSuccess),
                                        modifier = Modifier.testTag("demo_collect_${order.id}")
                                    ) {
                                        Text("Handover")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryLine(label: String, value: String, bold: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = if (bold) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium)
        Text(value, style = if (bold) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
    }
}
