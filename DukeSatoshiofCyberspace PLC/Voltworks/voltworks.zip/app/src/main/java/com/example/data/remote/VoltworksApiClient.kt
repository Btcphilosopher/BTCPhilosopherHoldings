package com.example.data.remote

import com.example.BuildConfig
import com.example.data.engine.ApiConflictException
import com.example.data.engine.ApiForbiddenException
import com.example.data.engine.ApiNotFoundException
import com.example.data.engine.VoltworksSandboxServer
import com.example.data.model.*
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.mock.*
import io.ktor.client.engine.okhttp.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class CreateQuoteApiRequest(
    val totalPence: Long,
    val partsGrade: PartsGrade,
    val partsLimitations: String,
    val scopeSummary: String,
    val materialChange: Boolean,
    val expectedVersion: Int
)

@Serializable
data class AdvanceRepairApiRequest(
    val targetStatus: RepairStatus,
    val intakeNotes: String? = null,
    val accessories: String? = null,
    val finalTestRecord: String? = null
)

@Serializable
data class CollectOrderApiRequest(
    val collectionReference: String,
    val expectedVersion: Int
)

/**
 * Real Ktor HttpClient wrapper.
 * Routes via OkHttp to BuildConfig.VOLTWORKS_API_BASE_URL when configured, or through Ktor MockEngine
 * backed by VoltworksSandboxServer for full offline-capable emulator execution.
 */
class VoltworksApiClient(
    val sandboxServer: VoltworksSandboxServer = VoltworksSandboxServer(),
    baseUrlOverride: String? = null
) {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val configuredBaseUrl = (baseUrlOverride ?: BuildConfig.VOLTWORKS_API_BASE_URL).trim()
    val isUsingEmbeddedEngine: Boolean = configuredBaseUrl.isBlank()
    private val baseUrl = configuredBaseUrl.ifBlank { "https://sandbox.voltworks.local" }

    val client: HttpClient = if (isUsingEmbeddedEngine) {
        HttpClient(MockEngine) {
            install(ContentNegotiation) { json(json) }
            engine {
                addHandler { request ->
                    handleSandboxHttp(request)
                }
            }
        }
    } else {
        HttpClient(OkHttp) {
            install(ContentNegotiation) { json(json) }
        }
    }

    private suspend fun MockRequestHandleScope.handleSandboxHttp(request: HttpRequestData): HttpResponseData {
        val path = request.url.encodedPath
        val params = request.url.parameters
        val bodyText = (request.body as? io.ktor.http.content.TextContent)?.text ?: ""

        return try {
            val payload: String = when {
                request.method == HttpMethod.Get && path == "/api/v1/stores" ->
                    json.encodeToString(sandboxServer.listStores())

                request.method == HttpMethod.Get && path.startsWith("/api/v1/stores/") && path.endsWith("/inventory") -> {
                    val storeId = path.removePrefix("/api/v1/stores/").removeSuffix("/inventory")
                    json.encodeToString(sandboxServer.getStoreInventory(storeId, params["sku"]))
                }

                request.method == HttpMethod.Get && path == "/api/v1/inventory/by-sku" ->
                    json.encodeToString(sandboxServer.getSkuStockAcrossStores(params["sku"] ?: ""))

                request.method == HttpMethod.Get && path == "/api/v1/catalog/products" ->
                    json.encodeToString(
                        sandboxServer.listProducts(
                            category = params["category"],
                            query = params["q"],
                            manufacturer = params["manufacturer"],
                            maxPricePence = params["maxPricePence"]?.toLongOrNull(),
                            inStockStoreId = params["inStockStoreId"],
                            interfaceFilter = params["interface"],
                            voltageFilter = params["voltage"],
                            platformFilter = params["platform"]
                        )
                    )

                request.method == HttpMethod.Get && path.startsWith("/api/v1/catalog/products/") -> {
                    val productId = path.removePrefix("/api/v1/catalog/products/")
                    json.encodeToString(sandboxServer.getProduct(productId))
                }

                request.method == HttpMethod.Post && path == "/api/v1/checkout/reserve" -> {
                    val req = json.decodeFromString<ReserveRequest>(bodyText)
                    json.encodeToString(sandboxServer.reserveInventory(req))
                }

                request.method == HttpMethod.Post && path == "/api/v1/checkout/pay" -> {
                    val req = json.decodeFromString<CheckoutPayRequest>(bodyText)
                    json.encodeToString(sandboxServer.checkoutAndPay(req))
                }

                request.method == HttpMethod.Get && path == "/api/v1/orders" ->
                    json.encodeToString(sandboxServer.listOrders())

                request.method == HttpMethod.Post && path.startsWith("/api/v1/orders/") && path.endsWith("/ready") -> {
                    val orderId = path.removePrefix("/api/v1/orders/").removeSuffix("/ready")
                    val expectedVersion = params["expectedVersion"]?.toIntOrNull() ?: 1
                    val picked = sandboxServer.advanceOrderFulfilment(orderId, FulfilmentStatus.PICKING, expectedVersion, "staff-shef-1", StaffRole.RETAIL_STAFF)
                    val ready = sandboxServer.advanceOrderFulfilment(orderId, FulfilmentStatus.READY_FOR_COLLECTION, picked.version, "staff-shef-1", StaffRole.RETAIL_STAFF)
                    json.encodeToString(ready)
                }

                request.method == HttpMethod.Post && path.startsWith("/api/v1/orders/") && path.endsWith("/collect") -> {
                    val orderId = path.removePrefix("/api/v1/orders/").removeSuffix("/collect")
                    val req = json.decodeFromString<CollectOrderApiRequest>(bodyText)
                    json.encodeToString(
                        sandboxServer.advanceOrderFulfilment(
                            orderId = orderId,
                            targetStatus = FulfilmentStatus.COLLECTED,
                            expectedVersion = req.expectedVersion,
                            actorId = "staff-shef-1",
                            actorRole = StaffRole.RETAIL_STAFF,
                            collectionRefConfirmation = req.collectionReference
                        )
                    )
                }

                request.method == HttpMethod.Get && path == "/api/v1/repairs" ->
                    json.encodeToString(sandboxServer.listRepairs())

                request.method == HttpMethod.Post && path == "/api/v1/repairs" -> {
                    val req = json.decodeFromString<RepairBookRequest>(bodyText)
                    json.encodeToString(sandboxServer.bookRepair(req))
                }

                request.method == HttpMethod.Post && path.startsWith("/api/v1/repairs/") && path.endsWith("/advance") -> {
                    val jobId = path.removePrefix("/api/v1/repairs/").removeSuffix("/advance")
                    val req = json.decodeFromString<AdvanceRepairApiRequest>(bodyText)
                    json.encodeToString(sandboxServer.advanceRepairStatus(jobId, req.targetStatus, req.intakeNotes, req.accessories, req.finalTestRecord))
                }

                request.method == HttpMethod.Post && path.startsWith("/api/v1/repairs/") && path.endsWith("/quotes") -> {
                    val jobId = path.removePrefix("/api/v1/repairs/").removeSuffix("/quotes")
                    val req = json.decodeFromString<CreateQuoteApiRequest>(bodyText)
                    json.encodeToString(
                        sandboxServer.issueRepairQuote(
                            jobId, req.totalPence, req.partsGrade, req.partsLimitations, req.scopeSummary, req.materialChange, req.expectedVersion
                        )
                    )
                }

                request.method == HttpMethod.Post && path.startsWith("/api/v1/repairs/") && path.endsWith("/decision") -> {
                    val jobId = path.removePrefix("/api/v1/repairs/").removeSuffix("/decision")
                    val req = json.decodeFromString<QuoteDecisionRequest>(bodyText)
                    json.encodeToString(sandboxServer.decideRepairQuote(jobId, req))
                }

                request.method == HttpMethod.Post && path.startsWith("/api/v1/repairs/") && path.endsWith("/warranty-return") -> {
                    val jobId = path.removePrefix("/api/v1/repairs/").removeSuffix("/warranty-return")
                    val req = json.decodeFromString<WarrantyReturnRequest>(bodyText)
                    json.encodeToString(sandboxServer.openWarrantyReturn(jobId, req))
                }

                request.method == HttpMethod.Get && path == "/api/v1/workshops" ->
                    json.encodeToString(sandboxServer.listWorkshops())

                request.method == HttpMethod.Get && path == "/api/v1/workshops/bookings" ->
                    json.encodeToString(sandboxServer.listWorkshopBookings())

                request.method == HttpMethod.Post && path.startsWith("/api/v1/workshops/") && path.endsWith("/hold") -> {
                    val eventId = path.removePrefix("/api/v1/workshops/").removeSuffix("/hold")
                    val req = json.decodeFromString<WorkshopHoldRequest>(bodyText)
                    json.encodeToString(sandboxServer.holdWorkshopSeat(eventId, req))
                }

                request.method == HttpMethod.Post && path.startsWith("/api/v1/workshops/bookings/") && path.endsWith("/confirm") -> {
                    val bookingId = path.removePrefix("/api/v1/workshops/bookings/").removeSuffix("/confirm")
                    json.encodeToString(sandboxServer.confirmWorkshopBooking(bookingId))
                }

                request.method == HttpMethod.Post && path.startsWith("/api/v1/workshops/bookings/") && path.endsWith("/cancel") -> {
                    val bookingId = path.removePrefix("/api/v1/workshops/bookings/").removeSuffix("/cancel")
                    json.encodeToString(sandboxServer.cancelWorkshopBooking(bookingId))
                }

                request.method == HttpMethod.Post && path.startsWith("/api/v1/workshops/bookings/") && path.endsWith("/expire") -> {
                    val bookingId = path.removePrefix("/api/v1/workshops/bookings/").removeSuffix("/expire")
                    json.encodeToString(sandboxServer.expireWorkshopHoldNow(bookingId))
                }

                request.method == HttpMethod.Post && path == "/api/v1/trade/accounts" ->
                    json.encodeToString(sandboxServer.createTradeAccount(json.decodeFromString<TradeAccountRequest>(bodyText)))

                request.method == HttpMethod.Get && path == "/api/v1/trade/accounts" ->
                    json.encodeToString(sandboxServer.listTradeAccounts())

                request.method == HttpMethod.Post && path == "/api/v1/trade/quotes" ->
                    json.encodeToString(sandboxServer.submitTradeQuote(json.decodeFromString<TradeQuoteRequest>(bodyText)))

                request.method == HttpMethod.Get && path == "/api/v1/trade/quotes" ->
                    json.encodeToString(sandboxServer.listTradeQuotes())

                request.method == HttpMethod.Post && path == "/api/v1/trade/building-centre" ->
                    json.encodeToString(sandboxServer.submitBuildingCentreEnquiry(json.decodeFromString<BuildingCentreEnquiryRequest>(bodyText)))

                request.method == HttpMethod.Get && path == "/api/v1/trade/building-centre" ->
                    json.encodeToString(sandboxServer.listBuildingEnquiries())

                request.method == HttpMethod.Get && path == "/api/v1/notifications" ->
                    json.encodeToString(sandboxServer.listNotifications())

                request.method == HttpMethod.Get && path == "/api/v1/admin/audit-logs" ->
                    json.encodeToString(sandboxServer.listAuditLogs())

                else -> throw ApiNotFoundException("Unhandled endpoint: ${request.method.value} $path")
            }

            respond(
                content = payload,
                status = HttpStatusCode.OK,
                headers = headersOf(HttpHeaders.ContentType, ContentType.Application.Json.toString())
            )
        } catch (e: ApiConflictException) {
            respond(e.message ?: "Conflict", HttpStatusCode.Conflict)
        } catch (e: ApiForbiddenException) {
            respond(e.message ?: "Forbidden", HttpStatusCode.Forbidden)
        } catch (e: ApiNotFoundException) {
            respond(e.message ?: "Not found", HttpStatusCode.NotFound)
        } catch (e: IllegalArgumentException) {
            respond(e.message ?: "Bad request", HttpStatusCode.BadRequest)
        }
    }

    suspend fun getStores(): List<StoreDto> = client.get("$baseUrl/api/v1/stores").body()
    suspend fun getStoreInventory(storeId: String): List<StoreInventoryDto> = client.get("$baseUrl/api/v1/stores/$storeId/inventory").body()
    suspend fun getSkuStockAcrossStores(sku: String): List<StoreInventoryDto> =
        client.get("$baseUrl/api/v1/inventory/by-sku") { parameter("sku", sku) }.body()

    suspend fun getProducts(
        category: String? = null,
        query: String? = null,
        manufacturer: String? = null,
        maxPricePence: Long? = null,
        inStockStoreId: String? = null,
        interfaceFilter: String? = null,
        voltageFilter: String? = null,
        platformFilter: String? = null
    ): List<ProductDto> = client.get("$baseUrl/api/v1/catalog/products") {
        category?.let { parameter("category", it) }
        query?.let { parameter("q", it) }
        manufacturer?.let { parameter("manufacturer", it) }
        maxPricePence?.let { parameter("maxPricePence", it) }
        inStockStoreId?.let { parameter("inStockStoreId", it) }
        interfaceFilter?.let { parameter("interface", it) }
        voltageFilter?.let { parameter("voltage", it) }
        platformFilter?.let { parameter("platform", it) }
    }.body()

    suspend fun reserveStock(req: ReserveRequest): List<ReservationDto> =
        postWithErrorHandling("$baseUrl/api/v1/checkout/reserve", req)

    suspend fun payOrder(req: CheckoutPayRequest): OrderDto =
        postWithErrorHandling("$baseUrl/api/v1/checkout/pay", req)

    suspend fun getOrders(): List<OrderDto> = client.get("$baseUrl/api/v1/orders").body()

    suspend fun markOrderReadyForCollection(orderId: String, expectedVersion: Int): OrderDto =
        postWithErrorHandling("$baseUrl/api/v1/orders/$orderId/ready?expectedVersion=$expectedVersion", mapOf<String, String>())

    suspend fun collectOrder(orderId: String, req: CollectOrderApiRequest): OrderDto =
        postWithErrorHandling("$baseUrl/api/v1/orders/$orderId/collect", req)

    suspend fun getRepairs(): List<RepairJobDto> = client.get("$baseUrl/api/v1/repairs").body()

    suspend fun bookRepair(req: RepairBookRequest): RepairJobDto =
        postWithErrorHandling("$baseUrl/api/v1/repairs", req)

    suspend fun advanceRepair(jobId: String, req: AdvanceRepairApiRequest): RepairJobDto =
        postWithErrorHandling("$baseUrl/api/v1/repairs/$jobId/advance", req)

    suspend fun issueRepairQuote(jobId: String, req: CreateQuoteApiRequest): RepairJobDto =
        postWithErrorHandling("$baseUrl/api/v1/repairs/$jobId/quotes", req)

    suspend fun decideRepairQuote(jobId: String, req: QuoteDecisionRequest): RepairJobDto =
        postWithErrorHandling("$baseUrl/api/v1/repairs/$jobId/decision", req)

    suspend fun openWarrantyReturn(jobId: String, req: WarrantyReturnRequest): RepairJobDto =
        postWithErrorHandling("$baseUrl/api/v1/repairs/$jobId/warranty-return", req)

    suspend fun getWorkshops(): List<WorkshopEventDto> = client.get("$baseUrl/api/v1/workshops").body()
    suspend fun getWorkshopBookings(): List<WorkshopBookingDto> = client.get("$baseUrl/api/v1/workshops/bookings").body()

    suspend fun holdWorkshopSeat(eventId: String, req: WorkshopHoldRequest): WorkshopBookingDto =
        postWithErrorHandling("$baseUrl/api/v1/workshops/$eventId/hold", req)

    suspend fun confirmWorkshopBooking(bookingId: String): WorkshopBookingDto =
        postWithErrorHandling("$baseUrl/api/v1/workshops/bookings/$bookingId/confirm", mapOf<String, String>())

    suspend fun cancelWorkshopBooking(bookingId: String): WorkshopBookingDto =
        postWithErrorHandling("$baseUrl/api/v1/workshops/bookings/$bookingId/cancel", mapOf<String, String>())

    suspend fun expireWorkshopHold(bookingId: String): WorkshopBookingDto =
        postWithErrorHandling("$baseUrl/api/v1/workshops/bookings/$bookingId/expire", mapOf<String, String>())

    suspend fun createTradeAccount(req: TradeAccountRequest): TradeAccountDto =
        postWithErrorHandling("$baseUrl/api/v1/trade/accounts", req)

    suspend fun getTradeAccounts(): List<TradeAccountDto> = client.get("$baseUrl/api/v1/trade/accounts").body()
    suspend fun submitTradeQuote(req: TradeQuoteRequest): TradeQuoteDto =
        postWithErrorHandling("$baseUrl/api/v1/trade/quotes", req)

    suspend fun getTradeQuotes(): List<TradeQuoteDto> = client.get("$baseUrl/api/v1/trade/quotes").body()
    suspend fun submitBuildingCentreEnquiry(req: BuildingCentreEnquiryRequest): BuildingCentreEnquiryDto =
        postWithErrorHandling("$baseUrl/api/v1/trade/building-centre", req)

    suspend fun getBuildingEnquiries(): List<BuildingCentreEnquiryDto> = client.get("$baseUrl/api/v1/trade/building-centre").body()
    suspend fun getNotifications(): List<NotificationDto> = client.get("$baseUrl/api/v1/notifications").body()
    suspend fun getAuditLogs(): List<AuditLogDto> = client.get("$baseUrl/api/v1/admin/audit-logs").body()

    private suspend inline fun <reified Req, reified Res> postWithErrorHandling(url: String, bodyPayload: Req): Res {
        val response = client.post(url) {
            contentType(ContentType.Application.Json)
            setBody(bodyPayload)
        }
        if (!response.status.isSuccess()) {
            val msg: String = response.body()
            throw when (response.status) {
                HttpStatusCode.Conflict -> ApiConflictException(msg)
                HttpStatusCode.Forbidden -> ApiForbiddenException(msg)
                HttpStatusCode.NotFound -> ApiNotFoundException(msg)
                else -> IllegalArgumentException(msg)
            }
        }
        return response.body()
    }
}
