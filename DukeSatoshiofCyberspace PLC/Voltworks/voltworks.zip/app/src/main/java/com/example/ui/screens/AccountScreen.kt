package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.MoneyFormat
import com.example.data.model.NotificationDeliveryStatus
import com.example.ui.components.OfflineFreshnessBanner
import com.example.ui.components.VoltworksSectionPill
import com.example.ui.components.VoltworksTopHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.VoltworksUiState

@Composable
fun AccountScreen(
    state: VoltworksUiState,
    onOpenBasket: () -> Unit,
    onSignIn: (String) -> Unit,
    onSignOut: () -> Unit,
    onToggleBiometric: (Boolean) -> Unit,
    onRequestBiometricUnlock: () -> Unit,
    onToggleReducedMotion: (Boolean) -> Unit,
    onTogglePush: (Boolean) -> Unit,
    onToggleOfflineMode: (Boolean) -> Unit,
    onSimulateLastItemRace: () -> Unit,
    onOpenRepairTracker: (String?) -> Unit
) {
    var emailInput by remember { mutableStateOf(state.signedInEmail ?: "alex.maker@voltworks.co.uk") }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        onTogglePush(granted)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        VoltworksTopHeader(
            basketCount = state.basketTotalCount,
            onBasketClick = onOpenBasket
        )

        OfflineFreshnessBanner(
            offlineMode = state.offlineMode,
            lastSyncedMillis = state.syncMeta?.lastSyncedMillis,
            onGoOnline = { onToggleOfflineMode(false) }
        )

        if (state.biometricLockEnabled && !state.biometricUnlocked) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Surface(
                    modifier = Modifier.padding(24.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Outlined.Fingerprint, contentDescription = null, tint = VoltworksOrange, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Session locked", style = MaterialTheme.typography.headlineMedium)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Use Android Biometric authentication to unlock saved orders, addresses & trade receipts.", style = MaterialTheme.typography.bodySmall)
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = onRequestBiometricUnlock,
                            colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange)
                        ) {
                            Text("Unlock with biometrics")
                        }
                    }
                }
            }
            return
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("Account, Orders & Preferences", style = MaterialTheme.typography.headlineLarge)
            }

            // Sign-in / Guest Checkout & Biometric session unlock
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = if (state.signedInEmail != null) "Signed in: ${state.signedInEmail}" else "Guest session active (registered sign-in optional)",
                            style = MaterialTheme.typography.titleMedium
                        )
                        if (state.signedInEmail == null) {
                            OutlinedTextField(
                                value = emailInput,
                                onValueChange = { emailInput = it },
                                label = { Text("Account email") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(
                                onClick = { onSignIn(emailInput) },
                                colors = ButtonDefaults.buttonColors(containerColor = VoltworksNavy),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Sign in to Voltworks account")
                            }
                        } else {
                            OutlinedButton(onClick = onSignOut) { Text("Switch to guest mode") }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Biometric session unlock", style = MaterialTheme.typography.titleSmall)
                                Text("Uses Android BiometricPrompt / device credential", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = state.biometricLockEnabled, onCheckedChange = onToggleBiometric)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Offline cache mode", style = MaterialTheme.typography.titleSmall)
                                Text("Read Room-cached products, receipts & repairs; blocks checkout/approvals", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(
                                checked = state.offlineMode,
                                onCheckedChange = onToggleOfflineMode,
                                modifier = Modifier.testTag("account_offline_switch")
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Reduced motion", style = MaterialTheme.typography.titleSmall)
                                Text("Disables non-essential transitions", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = state.reducedMotion, onCheckedChange = onToggleReducedMotion)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Generic push alerts (no PII)", style = MaterialTheme.typography.titleSmall)
                                Text("Never exposes device passwords or personal details in lockscreen previews", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(
                                checked = state.pushEnabled,
                                onCheckedChange = { enabled ->
                                    if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    } else {
                                        onTogglePush(enabled)
                                    }
                                }
                            )
                        }
                    }
                }
            }

            // Demonstration Lab (1-tap verification of all Section 15 scenarios)
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = VoltworksOrangeTint,
                    border = BorderStroke(1.dp, VoltworksOrange)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Demonstration Lab (Concurrency & Edge Cases)", style = MaterialTheme.typography.titleMedium, color = VoltworksOrangeDark)
                        Text(
                            "Test competing purchase of the last Robotics Explorer Kit (Sheffield ATP = 1), or inspect active repairs and audited staff actions.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = onSimulateLastItemRace,
                                colors = ButtonDefaults.buttonColors(containerColor = VoltworksOrange),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("demo_last_item_race_btn")
                            ) {
                                Text("Simulate rival buyer on last Robotics Kit")
                            }
                        }
                        if (state.repairs.isNotEmpty()) {
                            OutlinedButton(
                                onClick = { onOpenRepairTracker(state.repairs.first().id) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Open Repair Tracker (${state.repairs.first().id})")
                            }
                        }
                    }
                }
            }

            // Saved Lists & Addresses
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Saved Project Lists & Addresses", style = MaterialTheme.typography.titleMedium)
                        state.savedLists.forEach { listName ->
                            Text("• Project list: $listName", style = MaterialTheme.typography.bodySmall)
                        }
                        state.savedAddresses.forEach { addr ->
                            Text("• ${addr.label}: ${addr.line1}, ${addr.city} ${addr.postcode}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            // Orders & Receipts summary
            item {
                Text("Receipts & Collection References (${state.orders.size})", style = MaterialTheme.typography.titleLarge)
            }
            items(state.orders, key = { it.id }) { ord ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${ord.id} · ${ord.storeName}", style = MaterialTheme.typography.titleSmall)
                            Text(MoneyFormat.gbp(ord.totalPence), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                        Text(
                            "Fulfilment: ${ord.fulfilmentStatus} ${ord.collectionReference?.let { "· Ref: $it" } ?: ""}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            // Notification Inbox showing QUEUED / SENT / FAILED / DELIVERED states
            item {
                Text("In-App Notification Inbox (${state.notifications.size})", style = MaterialTheme.typography.titleLarge)
            }
            items(state.notifications, key = { it.id }) { n ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(n.previewTitle, style = MaterialTheme.typography.titleSmall)
                            VoltworksSectionPill(
                                label = n.deliveryStatus.name,
                                containerColor = if (n.deliveryStatus == NotificationDeliveryStatus.DELIVERED) VoltworksSuccessTint else VoltworksWarningTint,
                                contentColor = if (n.deliveryStatus == NotificationDeliveryStatus.DELIVERED) VoltworksSuccess else VoltworksWarning
                            )
                        }
                        Text(n.body, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            if (state.auditLogs.isNotEmpty()) {
                item {
                    Text("Staff Audit Log (${state.auditLogs.size})", style = MaterialTheme.typography.titleLarge)
                }
                items(state.auditLogs.take(8), key = { it.id }) { log ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Text(
                            "#${log.id} [${log.actorRole}] ${log.action} on ${log.entityType}:${log.entityId} — ${log.reason}",
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }
    }
}
