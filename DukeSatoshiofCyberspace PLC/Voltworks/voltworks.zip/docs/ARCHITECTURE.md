# Voltworks Architecture, Screen Map, Schema & API Contracts

## 1. Repository Structure
```text
.
├── app/                              # Native Android app (Kotlin, Jetpack Compose, Material 3, Room, Ktor Client, WorkManager)
│   └── src/
│       ├── main/java/com/example/
│       │   ├── VoltworksApp.kt       # Application root, dependency container, WorkManager scheduling
│       │   ├── MainActivity.kt       # Edge-to-edge FragmentActivity + Biometric unlock hook + Adaptive shell
│       │   ├── data/
│       │   │   ├── model/            # @Serializable domain & API DTOs (MoneyPence, Product, Inventory, Order, Repair, Workshop, Trade)
│       │   │   ├── local/            # Room Database, DAOs, Cached Entities, Basket Drafts, Offline Freshness
│       │   │   ├── remote/           # Ktor HttpClient + VoltworksApiClient + Embedded Ktor MockEngine (for offline/demo sandbox)
│       │   │   ├── engine/           # Authoritative transactional core (concurrency locks, idempotency, payment sim, repair state machine)
│       │   │   ├── worker/           # WorkManager deferred sync, reservation/hold reconciliation & notification polling
│       │   │   └── repo/             # Repository layer unifying Ktor API & Room cache
│       │   └── ui/
│       │       ├── theme/            # Voltworks ColorScheme (Midnight Navy, Electric Orange, Warm Ivory), Space Grotesk & Plus Jakarta Sans
│       │       ├── components/       # Angular V/W Brand Emblem, TopBar, BottomNav/NavRail, Oak Studio Product Cards, Badges
│       │       ├── navigation/       # Type-safe @Serializable Navigation Compose routes & adaptive shell
│       │       ├── viewmodel/        # StateFlow ViewModels for Shop, Checkout, Repairs, Workshops, Stores, Account & Demo Lab
│       │       └── screens/          # Home, Shop & Filters, Product Detail, Basket & Checkout, Services/Repair Booking,
│       │                             # Repair Tracker & Quotes, Warranty Returns, Workshops, Stores, Trade & Building Centre, Account
│       └── test/java/com/example/    # Unit & Robolectric tests (monetary math, concurrency, payment retries, diagnostic credits, RBAC, UI)
├── backend/                          # Kotlin + Ktor Server + PostgreSQL + Exposed + Flyway + Workers
│   ├── src/main/kotlin/com/voltworks/backend/
│   │   ├── Application.kt            # Ktor Server entrypoint, plugins, auth, rate limiting, routing
│   │   ├── domain/                   # Pure monetary calculator, state machines, compatibility & validation rules
│   │   ├── persistence/              # PostgreSQL tables, Flyway runner, transactional repositories (SELECT FOR UPDATE / version checks)
│   │   ├── payments/                 # PaymentProviderAdapter interface + SimulatedPaymentAdapter + webhook/reconciliation
│   │   ├── storage/                  # Protected Object Storage (MinIO/S3 signed URLs + upload validation)
│   │   ├── workers/                  # Coroutine background workers (reservation expiry, notification dispatch, payment reconciliation)
│   │   └── routes/                   # REST endpoints for customer app & staff administration console
│   ├── src/main/resources/db/migration/
│   │   ├── V1__init.sql              # Authoritative PostgreSQL DDL
│   │   └── V2__seed.sql              # Fictional UK stores, products, component packs, compatibility rules, workshops & staff
│   └── src/test/kotlin/              # Backend JUnit tests (concurrency, idempotency, credits, permissions, version conflicts)
├── admin-console/                    # Staff Administration Console (React 19 + TypeScript + Vite)
│   └── src/                          # Role-based console (Products, Inventory, Orders/Handover, Repairs, Workshops, Returns, Trade, Audit)
├── docs/ARCHITECTURE.md              # Screen map, schema, API contracts, setup & APK build instructions
└── docker-compose.yml                # Local deployment: PostgreSQL 16, MinIO, Ktor Backend, React Staff Console
```

## 2. Android Screen Map & Navigation Graph
Bottom Navigation (Compact) / Navigation Rail (Medium & Expanded):
1. **Home (`HomeRoute`)** — Midnight-navy header with V/W emblem + `"What will you build?"` search, `"POWER YOUR NEXT IDEA."` hero banner, 6 categories (`Components`, `Computing`, `Robotics`, `Tools & Repair`, `Smart Home`, `Workshops`), selected local store chip & collection availability, active orders & repair updates summary, featured maker products (`Microcontroller Starter Kit`, `Digital Multimeter`, `Precision Soldering Station`, `Robotics Explorer Kit`), and local collection banner.
2. **Shop (`ShopRoute(category?, query?)`)** — Category chips, category-aware structured filters (manufacturer, price range, in-stock/collection availability, dimensions, interface, operating voltage, supported platform), product & pack cards showing unit + pack pricing.
   - **Product Detail (`ProductDetailRoute(productId)`)** — Oak workshop image carousel, variant & SKU selector, ex-VAT / inc-VAT (20% UK VAT) price display, quantity-tier pricing & minimum pack quantity rules, structured specs with explicit units, included contents, documentation links, warranty info, delivery vs click-and-collect store availability & ATP estimate, and rule-based compatibility recommendations with explicit rationale.
   - **Basket & Checkout (`BasketRoute`)** — Draft persisted in Room; step-by-step server flow: Validate Price & Stock -> Reserve Inventory (transactional ATP hold with TTL countdown) -> Select Fulfilment (Delivery / Click & Collect) -> Simulated Payment (with timeout simulation & idempotent retry) -> Order Confirmation (strictly `Order accepted`, distinct from `Ready for collection`).
3. **Services (`ServicesRoute`)** — `"Repair. Learn. Build."` hero banner, segmented switcher between **Repair Booking** (`Laptop & PC`, `Phone & Tablet`, `Console & Controller`, `Other equipment`, £29 diagnostic assessment credited towards approved repair, date pills, store selector), **Repair Tracker** (`Booked -> received -> diagnosing -> awaiting approval -> awaiting parts -> repairing -> testing -> ready -> collected`, quote approval/decline with £29 credit subtraction, material revision re-approval, controlled access procedure, warranty return request), and **Workshops** (`Soldering basics`, `Build your first robot`, `Microcontroller projects`, `PC building`, `Smart-home setup` with BST/GMT `Europe/London` timestamps, transactional seat holds, waitlist, cancellation & refund).
4. **Stores (`StoresRoute`)** — UK store directory (Sheffield Flagship, Manchester Northern Quarter, Bristol Harbourside, London Clerkenwell), search, opening hours, facilities, workshop/repair capability, collection instructions, live SKU stock lookup (`Physical`, `Reserved`, `ATP`, `Quarantined`, `Inbound Transfer`, `Expected Delivery`), plus **Voltworks Trade & Building Centre** portal (organisation members, saved project lists, bulk quote requests, PO references, non-automatic credit status, electrical construction & prototyping enquiries).
5. **Account (`AccountRoute`)** — Guest vs registered sign-in, optional OS Biometric session unlock, Orders & Receipts & Verified Collection References, Active Repairs, Workshop Bookings, Saved Project Lists, Addresses, Notification Preferences & In-App Inbox (showing `QUEUED`, `SENT`, `FAILED`, `DELIVERED` without PII in push previews), Offline Freshness banner, and **Demonstration Lab** (compete on last item, payment timeout & retry, expired workshop hold, revised repair quote, staff handover simulation).

## 3. Authoritative PostgreSQL Schema Summary
Implemented in `backend/src/main/resources/db/migration/V1__init.sql`:
- `stores`: store metadata, JSONB opening hours & facilities, `collection_capacity_per_hour`, `collection_lead_minutes`, `version`.
- `products`, `product_variants`, `product_packs`, `quantity_pricing_tiers`: keeps product families, variants, purchasable packs, and individual piece counts distinct; stores all monetary amounts in `BIGINT` pence (`unit_price_pence`, `pack_price_pence`, `vat_rate_bps`).
- `compatibility_rules`: explicit documented compatibility pairs with `rule_basis` and `manufacturer_ref` (never inferred by name).
- `store_inventory`: `(store_id, sku)` primary key, `physical_qty`, `reserved_qty`, `quarantined_qty`, `inbound_transfer_qty`, `expected_delivery_at`, `version`; ATP = `physical_qty - reserved_qty - quarantined_qty`.
- `inventory_reservations`: transactional holds with `expires_at`, `status` (`HELD`, `CONFIRMED`, `EXPIRED`, `RELEASED`), `idempotency_key`.
- `orders`, `order_items`, `payments`, `payment_attempts`, `fulfilments`: strictly separated state machines, idempotency keys, `collection_reference`, `handover_verified_by`, `version`.
- `repair_jobs`, `repair_intake_records`, `repair_quotes`, `repair_warranty_returns`: full 9-step repair lifecycle + terminal states (`DECLINED_QUOTE`, `UNECONOMIC`, `CANCELLED`, `WARRANTY_RETURN`), quote versioning requiring renewed approval on material change, single-use diagnostic credit guard (`diagnostic_credited_to_job_id` / `credit_applied_pence`), no raw password columns (only `controlled_access_procedure_ref`).
- `workshops`, `workshop_events`, `workshop_bookings`: `TIMESTAMPTZ` stored in UTC and formatted in `Europe/London` (handling GMT/BST transitions), `seat_hold_expires_at`, waitlist, attendance & refund state.
- `trade_accounts`, `trade_members`, `trade_project_lists`, `trade_quotes`, `building_centre_enquiries`: `credit_approved` defaults to `FALSE`.
- `users`, `notifications`, `audit_logs`, `media_attachments`.

## 4. Core REST API Contracts (`/api/v1`)
All mutating endpoints accept `Idempotency-Key` and optimistic concurrency `version` where applicable. Monetary fields use integer `pence` (GBP).

- `GET /api/v1/health` — Backend & DB readiness check.
- `GET /api/v1/catalog/products?category=&q=&manufacturer=&maxPricePence=&inStockStoreId=&interface=&voltage=&platform=` — Filtered product catalogue.
- `GET /api/v1/catalog/products/{productId}` — Product detail, variants, packs, quantity tiers, documented compatibility rules, store ATP.
- `GET /api/v1/stores` — All stores with opening hours, facilities, capacities.
- `GET /api/v1/stores/{storeId}/inventory?sku=` — Detailed stock breakdown (`physical`, `reserved`, `atp`, `quarantined`, `inboundTransfer`, `expectedDeliveryAt`).
- `POST /api/v1/checkout/validate` — Validates basket prices, pack multiples, and stock.
- `POST /api/v1/checkout/reserve` — Transactionally locks `store_inventory` rows (`FOR UPDATE`), creates `HELD` reservations with TTL. Returns `409 Conflict` if ATP insufficient.
- `POST /api/v1/checkout/pay` — Runs `PaymentProviderAdapter` with `Idempotency-Key`; records `payment_attempts`; supports simulated timeout and safe idempotent retry; creates order (`ORDER_ACCEPTED`), payment (`SUCCEEDED`), and fulfilment (`ORDER_ACCEPTED`).
- `GET /api/v1/orders/{orderId}` & `POST /api/v1/orders/{orderId}/collect` — Order tracking & staff-verified click-and-collect handover.
- `POST /api/v1/repairs` — Books intake appointment slot, records intake/consent/controlled access mode, charges/simulates £29 diagnostic assessment.
- `POST /api/v1/repairs/{jobId}/quotes` — Staff creates or revises quote version; marks material changes as requiring renewed customer approval.
- `POST /api/v1/repairs/{jobId}/decision` — Customer approves or declines latest quote; atomically credits £29 diagnostic payment once (`total - £29 = remaining`).
- `POST /api/v1/repairs/{jobId}/warranty-return` — Links recurring fault to original job; routes to assessment without auto-charging diagnostic fee.
- `GET /api/v1/workshops` & `POST /api/v1/workshops/{eventId}/hold` & `POST /api/v1/workshops/bookings/{bookingId}/confirm` & `POST /api/v1/workshops/bookings/{bookingId}/cancel` — Transactional seat holds, confirmation, waitlists, cancellation & refund.
- `POST /api/v1/trade/accounts`, `POST /api/v1/trade/quotes`, `POST /api/v1/trade/building-centre` — Trade registration (credit unapproved by default), bulk quotes, Building Centre enquiries.
- `GET /api/v1/notifications` — In-app notification inbox with delivery statuses (`QUEUED`, `SENT`, `FAILED`, `DELIVERED`).
- `POST /api/v1/media/upload-intent` — Validated object-storage upload ticket (MIME/size checks, no public bucket exposure).
- `GET /api/v1/admin/*` & `POST /api/v1/admin/*` — RBAC-guarded (`RETAIL_STAFF`, `TECHNICIAN`, `WORKSHOP_ORGANISER`, `MANAGER`, `FINANCE`, `ADMIN`) endpoints writing immutable `audit_logs`.

## 5. Implementation Milestones
1. **Milestone 1**: Core Theme, Navigation, Home -> Catalogue -> Product Detail -> Basket -> Simulated Payment -> Click-and-Collect.
2. **Milestone 2**: Repair Booking (£29 Diagnostic Fee), 9-Stage Repair Tracker, Quote Approval (£149 - £29 = £120), Revised Quotes, Warranty Returns.
3. **Milestone 3**: Practical Workshops (BST timezone-aware, seat holds, waitlist, cancellation/refund), Stores Stock Breakdown, Voltworks Trade & Building Centre, Notifications & Biometric Unlock.
4. **Milestone 4**: Ktor Server + PostgreSQL + Flyway + Workers + Docker Compose + React/TypeScript Staff Administration Console + Unit & Robolectric Tests.

## 6. Setup Commands & APK Build Instructions
### Local Backend & Staff Console (Docker Compose)
```bash
docker compose up --build
# PostgreSQL: localhost:5432 | MinIO: localhost:9000 (console :9001)
# Ktor API: http://localhost:8080/api/v1/health
# Staff Admin Console: http://localhost:5173
```
### Backend Tests (Gradle)
```bash
cd backend && gradle test
```
### Staff Admin Console Build
```bash
cd admin-console && npm install && npm run build
```
### Android APK Build & Tests
```bash
gradle :app:testDebugUnitTest
gradle :app:assembleDebug
# Output APK: app/build/outputs/apk/debug/app-debug.apk
```
To point the Android app at a live local Ktor Server instead of the built-in Ktor MockEngine sandbox, set `VOLTWORKS_API_BASE_URL=http://10.0.2.2:8080` in `.env` (or toggle Live Server URL in the Account screen).

## 7. Simulated Integrations & Production Handoff Notes
- **Payment Provider**: Implemented behind `PaymentProviderAdapter` with `SimulatedPaymentAdapter` (supports deterministic success, timeout simulation, and idempotent retry). Replace with Stripe UK / Adyen / Worldpay SDK + server webhook signature verification for production.
- **Push Notifications**: Generic non-PII push dispatcher (`NotificationDispatchWorker`) tracks `QUEUED`, `SENT`, `FAILED`, and `DELIVERED` states locally/in PostgreSQL; connect Firebase Cloud Messaging (FCM) server credentials via environment secrets for device push.
- **Object Storage**: Configured for S3-compatible MinIO in Docker Compose with signed upload validation (`ObjectStorageService`); point to AWS S3 / GCS in production.
- **Android Standalone Sandbox**: When `VOLTWORKS_API_BASE_URL` is blank (default for offline emulator evaluation), the Android Ktor `HttpClient` uses a Ktor `MockEngine` wired to an authoritative in-app `VoltworksServerCore` implementing the exact HTTP routes, concurrency mutexes, idempotency store, and Room persistence.
