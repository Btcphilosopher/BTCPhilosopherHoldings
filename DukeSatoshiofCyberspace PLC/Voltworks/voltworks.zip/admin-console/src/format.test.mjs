import test from 'node:test';
import assert from 'node:assert/strict';

test('staff console GBP formatting from pence', () => {
  const formatGbp = (pence) => `£${(pence / 100).toFixed(2)}`;
  assert.equal(formatGbp(12999), '£129.99');
  assert.equal(formatGbp(14900 - 2900), '£120.00');
  assert.equal(formatGbp(150), '£1.50');
});
