export type StaffRole =
  | 'RETAIL_STAFF'
  | 'TECHNICIAN'
  | 'WORKSHOP_ORGANISER'
  | 'MANAGER'
  | 'FINANCE'
  | 'ADMIN';

export interface InventoryRow {
  storeId: string;
  sku: string;
  physicalQty: number;
  reservedQty: number;
  quarantinedQty: number;
  inboundTransferQty: number;
  version: number;
}

export interface OrderRow {
  id: string;
  storeId: string;
  customerEmail: string;
  fulfilmentMode: 'DELIVERY' | 'CLICK_AND_COLLECT';
  fulfilmentStatus: 'ORDER_ACCEPTED' | 'PICKING' | 'READY_FOR_COLLECTION' | 'COLLECTED';
  collectionReference: string | null;
  totalPence: number;
  version: number;
}

export interface RepairRow {
  id: string;
  customerName: string;
  deviceModel: string;
  storeId: string;
  status: string;
  diagnosticPaid: boolean;
  latestQuotePence: number | null;
  remainingPence: number | null;
  version: number;
}

export interface WorkshopRow {
  id: string;
  title: string;
  storeId: string;
  instructorName: string;
  startsAtLondonFormatted: string;
  capacity: number;
  heldSeats: number;
  confirmedSeats: number;
}

export interface AuditRow {
  id: number;
  actorId: string;
  actorRole: StaffRole;
  action: string;
  entityType: string;
  entityId: string;
  reason: string;
  createdAtIso: string;
}

export const formatGbp = (pence: number): string =>
  `£${(pence / 100).toFixed(2)}`;
