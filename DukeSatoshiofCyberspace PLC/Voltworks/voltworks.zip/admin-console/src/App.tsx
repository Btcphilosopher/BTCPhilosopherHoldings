import { useState } from 'react';
import {
  AuditRow,
  formatGbp,
  InventoryRow,
  OrderRow,
  RepairRow,
  StaffRole,
  WorkshopRow,
} from './types';

type Section = 'overview' | 'inventory' | 'orders' | 'repairs' | 'workshops' | 'trade' | 'audit';

const ROLE_PERMISSIONS: Record<StaffRole, Set<Section>> = {
  RETAIL_STAFF: new Set(['overview', 'inventory', 'orders']),
  TECHNICIAN: new Set(['overview', 'repairs']),
  WORKSHOP_ORGANISER: new Set(['overview', 'workshops']),
  MANAGER: new Set(['overview', 'inventory', 'orders', 'repairs', 'workshops', 'trade', 'audit']),
  FINANCE: new Set(['overview', 'orders', 'trade', 'audit']),
  ADMIN: new Set(['overview', 'inventory', 'orders', 'repairs', 'workshops', 'trade', 'audit']),
};

export default function App() {
  const [role, setRole] = useState<StaffRole>('MANAGER');
  const [section, setSection] = useState<Section>('overview');
  const [apiBase] = useState<string>(import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080/api/v1');

  const [inventory, setInventory] = useState<InventoryRow[]>([
    { storeId: 'store-sheffield', sku: 'VW-SOL-060-UK', physicalQty: 6, reservedQty: 1, quarantinedQty: 0, inboundTransferQty: 4, version: 1 },
    { storeId: 'store-sheffield', sku: 'VW-MCU-RP2350', physicalQty: 14, reservedQty: 2, quarantinedQty: 0, inboundTransferQty: 10, version: 1 },
    { storeId: 'store-sheffield', sku: 'VW-DMM-6000', physicalQty: 8, reservedQty: 0, quarantinedQty: 0, inboundTransferQty: 0, version: 1 },
    { storeId: 'store-sheffield', sku: 'VW-ROB-ARM4', physicalQty: 1, reservedQty: 0, quarantinedQty: 0, inboundTransferQty: 3, version: 1 },
    { storeId: 'store-sheffield', sku: 'VW-RES-10K-10PK', physicalQty: 45, reservedQty: 0, quarantinedQty: 0, inboundTransferQty: 0, version: 1 },
  ]);

  const [orders, setOrders] = useState<OrderRow[]>([
    { id: 'ORD-4821A', storeId: 'store-sheffield', customerEmail: 'maker@example.co.uk', fulfilmentMode: 'CLICK_AND_COLLECT', fulfilmentStatus: 'PICKING', collectionReference: 'VW-4821A', totalPence: 13149, version: 1 },
    { id: 'ORD-4822B', storeId: 'store-manchester', customerEmail: 'studio@example.co.uk', fulfilmentMode: 'DELIVERY', fulfilmentStatus: 'ORDER_ACCEPTED', collectionReference: null, totalPence: 6398, version: 1 },
  ]);

  const [repairs, setRepairs] = useState<RepairRow[]>([
    { id: 'REP-9012', customerName: 'Alex Turner', deviceModel: 'ThinkPad X1 Carbon', storeId: 'store-sheffield', status: 'DIAGNOSING', diagnosticPaid: true, latestQuotePence: null, remainingPence: null, version: 1 },
    { id: 'REP-9015', customerName: 'Priya Shah', deviceModel: 'DualSense Edge Controller', storeId: 'store-sheffield', status: 'AWAITING_APPROVAL', diagnosticPaid: true, latestQuotePence: 14900, remainingPence: 12000, version: 2 },
  ]);

  const [workshops] = useState<WorkshopRow[]>([
    { id: 'evt-soldering-shef-1', title: 'Soldering basics', storeId: 'store-sheffield', instructorName: 'Hannah Patel', startsAtLondonFormatted: 'Sat 12 Jun 2027, 11:00 BST', capacity: 8, heldSeats: 0, confirmedSeats: 5 },
    { id: 'evt-robot-bris-1', title: 'Build your first robot', storeId: 'store-bristol', instructorName: 'Callum Reid', startsAtLondonFormatted: 'Sat 19 Jun 2027, 14:00 BST', capacity: 6, heldSeats: 0, confirmedSeats: 5 },
    { id: 'evt-mcu-manc-1', title: 'Microcontroller projects', storeId: 'store-manchester', instructorName: 'Priya Nair', startsAtLondonFormatted: 'Sat 30 Jan 2027, 18:00 GMT', capacity: 10, heldSeats: 0, confirmedSeats: 4 },
  ]);

  const [auditLogs, setAuditLogs] = useState<AuditRow[]>([
    { id: 1, actorId: 'staff-hannah', actorRole: 'MANAGER', action: 'SEED_VERIFIED', entityType: 'STORE', entityId: 'store-sheffield', reason: 'Initial Sheffield flagship opening stock check', createdAtIso: '2026-11-25T09:00:00Z' },
  ]);

  const [collectionInput, setCollectionInput] = useState<Record<string, string>>({});
  const [quoteInput, setQuoteInput] = useState<Record<string, string>>({});
  const [statusMessage, setStatusMessage] = useState<string>('');

  const allowedSections = ROLE_PERMISSIONS[role];

  const appendAudit = (action: string, entityType: string, entityId: string, reason: string) => {
    setAuditLogs((prev) => [
      {
        id: prev.length + 1,
        actorId: `staff-${role.toLowerCase()}`,
        actorRole: role,
        action,
        entityType,
        entityId,
        reason,
        createdAtIso: new Date().toISOString(),
      },
      ...prev,
    ]);
  };

  const adjustStock = (sku: string, delta: number) => {
    if (!allowedSections.has('inventory')) return;
    setInventory((prev) =>
      prev.map((row) => {
        if (row.sku !== sku) return row;
        const nextPhysical = Math.max(row.reservedQty + row.quarantinedQty, row.physicalQty + delta);
        return { ...row, physicalQty: nextPhysical, version: row.version + 1 };
      })
    );
    appendAudit('STOCK_ADJUSTMENT', 'STORE_INVENTORY', `store-sheffield:${sku}`, `Physical delta ${delta >= 0 ? '+' : ''}${delta}`);
    setStatusMessage(`Updated physical stock for ${sku} (audited).`);
  };

  const advanceOrder = (order: OrderRow) => {
    if (order.fulfilmentStatus === 'ORDER_ACCEPTED') {
      setOrders((prev) => prev.map((o) => (o.id === order.id ? { ...o, fulfilmentStatus: 'PICKING', version: o.version + 1 } : o)));
      appendAudit('ORDER_PICKING', 'ORDER', order.id, 'Started picking at shelf');
    } else if (order.fulfilmentStatus === 'PICKING') {
      setOrders((prev) => prev.map((o) => (o.id === order.id ? { ...o, fulfilmentStatus: 'READY_FOR_COLLECTION', version: o.version + 1 } : o)));
      appendAudit('ORDER_READY_FOR_COLLECTION', 'ORDER', order.id, 'Staged at Click & Collect desk');
    } else if (order.fulfilmentStatus === 'READY_FOR_COLLECTION') {
      const entered = (collectionInput[order.id] || '').trim().toUpperCase();
      if (entered !== order.collectionReference) {
        setStatusMessage(`Handover blocked: enter exact collection reference ${order.collectionReference}.`);
        return;
      }
      setOrders((prev) => prev.map((o) => (o.id === order.id ? { ...o, fulfilmentStatus: 'COLLECTED', version: o.version + 1 } : o)));
      appendAudit('ORDER_HANDOVER_COLLECTED', 'ORDER', order.id, `Verified reference ${entered}`);
      setStatusMessage(`Order ${order.id} collected and verified.`);
    }
  };

  const issueQuote = (repair: RepairRow) => {
    const pounds = Number(quoteInput[repair.id] || '149');
    if (Number.isNaN(pounds) || pounds <= 0) return;
    const totalPence = Math.round(pounds * 100);
    const credit = repair.diagnosticPaid ? Math.min(2900, totalPence) : 0;
    const remaining = totalPence - credit;
    setRepairs((prev) =>
      prev.map((r) =>
        r.id === repair.id
          ? { ...r, status: 'AWAITING_APPROVAL', latestQuotePence: totalPence, remainingPence: remaining, version: r.version + 1 }
          : r
      )
    );
    appendAudit('ISSUE_REPAIR_QUOTE', 'REPAIR_JOB', repair.id, `Quoted ${formatGbp(totalPence)} (credit ${formatGbp(credit)}, due ${formatGbp(remaining)})`);
    setStatusMessage(`Quote issued for ${repair.id}: ${formatGbp(remaining)} remaining after £29 diagnostic credit.`);
  };

  return (
    <div>
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">VW</span>
          <div>
            <div>VOLTWORKS STAFF CONSOLE</div>
            <div style={{ fontSize: 11, opacity: 0.75, fontWeight: 500 }}>Connected API: {apiBase}</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <label htmlFor="role-select" style={{ fontSize: 13 }}>Active Role:</label>
          <select
            id="role-select"
            value={role}
            onChange={(e) => {
              const nextRole = e.target.value as StaffRole;
              setRole(nextRole);
              if (!ROLE_PERMISSIONS[nextRole].has(section)) setSection('overview');
            }}
          >
            <option value="RETAIL_STAFF">Retail Staff</option>
            <option value="TECHNICIAN">Technician</option>
            <option value="WORKSHOP_ORGANISER">Workshop Organiser</option>
            <option value="MANAGER">Manager</option>
            <option value="FINANCE">Finance</option>
            <option value="ADMIN">Administrator</option>
          </select>
        </div>
      </header>

      <div className="shell">
        <nav className="sidebar" aria-label="Admin sections">
          {([
            ['overview', 'Overview'],
            ['inventory', 'Store Inventory & SKUs'],
            ['orders', 'Orders & Handover'],
            ['repairs', 'Repairs & Quotes'],
            ['workshops', 'Workshops & BST'],
            ['trade', 'Stores & Trade'],
            ['audit', 'Audit Log'],
          ] as [Section, string][]).map(([key, label]) => (
            <button
              key={key}
              className={`nav-btn ${section === key ? 'active' : ''}`}
              disabled={!allowedSections.has(key)}
              onClick={() => setSection(key)}
            >
              {label} {!allowedSections.has(key) ? '(Locked)' : ''}
            </button>
          ))}
        </nav>

        <main className="main">
          {statusMessage && (
            <div className="card" style={{ borderColor: 'var(--orange)', background: '#FFF8F3' }}>
              <strong>Notice:</strong> {statusMessage}
            </div>
          )}

          {section === 'overview' && (
            <div>
              <h2>Operations Overview</h2>
              <div className="grid-3">
                <div className="card">
                  <div>Tracked SKUs (Sheffield)</div>
                  <div className="kpi-val">{inventory.length}</div>
                </div>
                <div className="card">
                  <div>Active Collection Orders</div>
                  <div className="kpi-val">{orders.filter((o) => o.fulfilmentStatus !== 'COLLECTED').length}</div>
                </div>
                <div className="card">
                  <div>Open Repair Jobs</div>
                  <div className="kpi-val">{repairs.length}</div>
                </div>
              </div>
              <div className="card">
                <h3>Role-Based Access Control</h3>
                <p>Switch roles in the header to verify permissions: Retail Staff cannot edit repair quotes, Technicians cannot view financial audit logs, and all stock adjustments, quote changes, and handovers append immutable audit records.</p>
              </div>
            </div>
          )}

          {section === 'inventory' && (
            <div className="card">
              <h2>Store Inventory & ATP (Sheffield flagship)</h2>
              <table>
                <thead>
                  <tr><th>SKU</th><th>Physical</th><th>Reserved</th><th>Quarantined</th><th>ATP</th><th>Inbound</th><th>Ver</th><th>Actions</th></tr>
                </thead>
                <tbody>
                  {inventory.map((row) => {
                    const atp = row.physicalQty - row.reservedQty - row.quarantinedQty;
                    return (
                      <tr key={row.sku}>
                        <td><strong>{row.sku}</strong></td>
                        <td>{row.physicalQty}</td>
                        <td>{row.reservedQty}</td>
                        <td>{row.quarantinedQty}</td>
                        <td><span className={`badge ${atp <= 1 ? 'badge-warn' : 'badge-ok'}`}>{atp}</span></td>
                        <td>{row.inboundTransferQty}</td>
                        <td>v{row.version}</td>
                        <td style={{ display: 'flex', gap: 6 }}>
                          <button className="btn btn-outline" onClick={() => adjustStock(row.sku, 1)}>+1</button>
                          <button className="btn btn-outline" onClick={() => adjustStock(row.sku, -1)}>-1</button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {section === 'orders' && (
            <div className="card">
              <h2>Orders, Picking & Audited Handover</h2>
              <table>
                <thead>
                  <tr><th>Order</th><th>Fulfilment</th><th>Status</th><th>Collection Ref</th><th>Total</th><th>Action</th></tr>
                </thead>
                <tbody>
                  {orders.map((o) => (
                    <tr key={o.id}>
                      <td><strong>{o.id}</strong><br /><small>{o.customerEmail}</small></td>
                      <td>{o.fulfilmentMode}</td>
                      <td><span className="badge badge-warn">{o.fulfilmentStatus}</span></td>
                      <td>{o.collectionReference || '—'}</td>
                      <td>{formatGbp(o.totalPence)}</td>
                      <td>
                        {o.fulfilmentStatus === 'READY_FOR_COLLECTION' && (
                          <input
                            placeholder="Verify ref"
                            value={collectionInput[o.id] || ''}
                            onChange={(e) => setCollectionInput({ ...collectionInput, [o.id]: e.target.value })}
                            style={{ width: 110, marginRight: 8 }}
                          />
                        )}
                        {o.fulfilmentStatus !== 'COLLECTED' && (
                          <button className="btn" onClick={() => advanceOrder(o)}>
                            {o.fulfilmentStatus === 'ORDER_ACCEPTED' ? 'Start Picking' : o.fulfilmentStatus === 'PICKING' ? 'Mark Ready' : 'Verify & Handover'}
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {section === 'repairs' && (
            <div className="card">
              <h2>Repair Bench & Quote Management</h2>
              <table>
                <thead>
                  <tr><th>Job</th><th>Device</th><th>Status</th><th>£29 Paid</th><th>Quote / Remaining</th><th>Issue Quote (£)</th></tr>
                </thead>
                <tbody>
                  {repairs.map((r) => (
                    <tr key={r.id}>
                      <td><strong>{r.id}</strong><br /><small>{r.customerName}</small></td>
                      <td>{r.deviceModel}</td>
                      <td><span className="badge">{r.status}</span></td>
                      <td>{r.diagnosticPaid ? 'Yes (£29 credit)' : 'No'}</td>
                      <td>{r.latestQuotePence ? `${formatGbp(r.latestQuotePence)} (Due ${formatGbp(r.remainingPence || 0)})` : 'Pending diagnosis'}</td>
                      <td>
                        <input
                          type="number"
                          placeholder="149"
                          value={quoteInput[r.id] || ''}
                          onChange={(e) => setQuoteInput({ ...quoteInput, [r.id]: e.target.value })}
                          style={{ width: 80, marginRight: 8 }}
                        />
                        <button className="btn" onClick={() => issueQuote(r)}>Issue Quote</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {section === 'workshops' && (
            <div className="card">
              <h2>Practical Workshops (Europe/London GMT & BST)</h2>
              <table>
                <thead><tr><th>Workshop</th><th>Store</th><th>Instructor</th><th>Start Time</th><th>Confirmed / Cap</th></tr></thead>
                <tbody>
                  {workshops.map((w) => (
                    <tr key={w.id}>
                      <td><strong>{w.title}</strong></td>
                      <td>{w.storeId}</td>
                      <td>{w.instructorName}</td>
                      <td>{w.startsAtLondonFormatted}</td>
                      <td>{w.confirmedSeats} / {w.capacity}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {section === 'trade' && (
            <div className="card">
              <h2>Stores & Trade Credit Reviews</h2>
              <p>New Voltworks Trade accounts start with <strong>Credit Approved = No</strong> until Finance review completes. Building Centre enquiries for electrical supplies, assembly, and prototyping appear here for engineering sign-off.</p>
            </div>
          )}

          {section === 'audit' && (
            <div className="card">
              <h2>Immutable Audit Trail</h2>
              <table>
                <thead><tr><th>#</th><th>Actor</th><th>Role</th><th>Action</th><th>Entity</th><th>Reason</th></tr></thead>
                <tbody>
                  {auditLogs.map((log) => (
                    <tr key={log.id}>
                      <td>{log.id}</td>
                      <td>{log.actorId}</td>
                      <td><span className="badge">{log.actorRole}</span></td>
                      <td><strong>{log.action}</strong></td>
                      <td>{log.entityType}:{log.entityId}</td>
                      <td>{log.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
