import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { DigitalTwinStateService } from '../../core/services/digital-twin-state.service';
import { IngredientDatabaseService } from '../../core/services/ingredient-database.service';
import { ColorFromLabPipe } from '../../core/pipes/color-from-lab.pipe';

@Component({
  selector: 'app-twin-quick-formulation',
  standalone: true,
  imports: [CommonModule, MatIconModule, FormsModule, ColorFromLabPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950/70 border-r border-slate-800/80 p-4 overflow-y-auto">
      
      <!-- Panel Header -->
      <div class="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-4">
        <div>
          <span class="text-[11px] font-mono tracking-wider uppercase text-slate-400">ACTIVE FORMULA</span>
          <h2 class="text-sm font-semibold text-slate-100 flex items-center gap-1.5">
            <span>{{ state.formulation().productCategory | titlecase }}</span>
            <span class="text-xs font-mono text-cyan-400">#{{ state.formulation().id }}</span>
          </h2>
        </div>
        <button 
          (click)="state.setTab('formulation')"
          class="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          title="Open Full Formula Studio">
          <mat-icon class="text-base">open_in_new</mat-icon>
        </button>
      </div>

      <!-- Quick Target Swatch & Mass Balance -->
      <div class="p-3 rounded-xl bg-slate-900 border border-slate-800 mb-4 flex items-center justify-between">
        <div class="flex items-center gap-2.5">
          <div 
            class="w-8 h-8 rounded-lg border border-white/20 shadow-inner"
            [style.background-color]="state.formulation().targetCIELAB | colorFromLab"></div>
          <div>
            <div class="text-[10px] font-mono text-slate-400 uppercase">TARGET COLOUR</div>
            <div class="text-xs font-mono font-bold text-slate-200">
              L:{{ state.formulation().targetCIELAB.L.toFixed(1) }} a:{{ state.formulation().targetCIELAB.a.toFixed(1) }} b:{{ state.formulation().targetCIELAB.b.toFixed(1) }}
            </div>
          </div>
        </div>

        <div class="text-right">
          <div class="text-[10px] font-mono text-slate-400 uppercase">MASS %</div>
          <div class="text-xs font-mono font-bold" [ngClass]="isBalanced() ? 'text-emerald-400' : 'text-amber-400'">
            {{ state.totalConcentrationPercent().toFixed(1) }}%
          </div>
        </div>
      </div>

      <!-- Pigment Grind Controls (Phase C) -->
      <div class="mb-4 space-y-2">
        <div class="flex items-center justify-between text-xs font-mono">
          <span class="text-slate-400 uppercase tracking-wider text-[10px]">PIGMENT CONCENTRATIONS</span>
          <button 
            (click)="state.optimizeShadeToTarget()"
            class="text-[10px] text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1">
            <mat-icon class="text-xs">auto_fix_high</mat-icon>
            <span>Align ΔE</span>
          </button>
        </div>

        <div class="space-y-1.5 text-xs font-mono">
          @for (item of pigmentItems(); track item.ingredientId) {
            <div class="p-2 rounded-lg bg-slate-900/60 border border-slate-800/80 flex items-center justify-between">
              <div class="flex items-center gap-2">
                <div 
                  class="w-3 h-3 rounded-full border border-white/20 shrink-0"
                  [style.background-color]="getPigmentColor(item.ingredientId)"></div>
                <span class="text-slate-300 text-[11px] truncate max-w-[110px]">{{ getPigmentName(item.ingredientId) }}</span>
              </div>
              <div class="flex items-center gap-1.5">
                <input 
                  type="range" min="0" max="25" step="0.1"
                  [ngModel]="item.concentrationPercent"
                  (ngModelChange)="state.updateItemConcentration(item.ingredientId, $event)"
                  class="w-16 accent-cyan-400 h-1 bg-slate-800 rounded cursor-pointer" />
                <span class="w-10 text-right text-slate-200 text-[11px]">{{ item.concentrationPercent.toFixed(1) }}%</span>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Phase Composition Breakdown -->
      <div class="p-3 rounded-xl bg-slate-900/40 border border-slate-800 mb-4 space-y-2 text-xs font-mono">
        <span class="text-[10px] text-slate-400 uppercase tracking-wider block">PHASE FRACTIONS</span>
        <div class="space-y-1.5">
          <div class="flex items-center justify-between">
            <span class="text-cyan-400 font-medium">Phase A (Aqueous / Polyols):</span>
            <span class="text-slate-200">{{ phasePercent('A') }}%</span>
          </div>
          <div class="flex items-center justify-between">
            <span class="text-amber-400 font-medium">Phase B (Lipids / Emulsifier):</span>
            <span class="text-slate-200">{{ phasePercent('B') }}%</span>
          </div>
          <div class="flex items-center justify-between">
            <span class="text-rose-400 font-medium">Phase C (Pigment Grind):</span>
            <span class="text-slate-200">{{ phasePercent('C') }}%</span>
          </div>
          <div class="flex items-center justify-between">
            <span class="text-emerald-400 font-medium">Phase D (Preservative / Active):</span>
            <span class="text-slate-200">{{ phasePercent('D') }}%</span>
          </div>
        </div>
      </div>

      <!-- Compatibility & Stability Safeguards -->
      <div class="mt-auto pt-3 border-t border-slate-800 text-xs font-mono text-slate-400 space-y-2">
        <div class="flex items-center justify-between">
          <span>Batch Cost:</span>
          <span class="text-slate-200 font-bold">\${{ state.batchCostUSD().toFixed(2) }}</span>
        </div>
        <div class="flex items-center justify-between">
          <span>Target Batch Mass:</span>
          <span class="text-slate-200 font-bold">{{ state.formulation().batchSizeKg }} kg</span>
        </div>

        @if (state.regulatoryWarnings().length > 0) {
          <div class="p-2 rounded bg-amber-950/40 border border-amber-500/30 text-amber-300 text-[10px]">
            {{ state.regulatoryWarnings().length }} Regulatory Notice(s) Detected
          </div>
        }
      </div>

    </div>
  `
})
export class TwinQuickFormulation {
  readonly state = inject(DigitalTwinStateService);
  readonly db = inject(IngredientDatabaseService);

  isBalanced(): boolean {
    return Math.abs(this.state.totalConcentrationPercent() - 100.0) < 0.05;
  }

  pigmentItems() {
    return this.state.formulation().items.filter(i => i.phase === 'C');
  }

  phasePercent(phase: string): string {
    const sum = this.state.formulation().items
      .filter(i => i.phase === phase)
      .reduce((s, i) => s + i.concentrationPercent, 0);
    return sum.toFixed(1);
  }

  getPigmentName(id: string): string {
    switch (id) {
      case 'ing_tio2_rutile': return 'TiO2 Rutile';
      case 'ing_fe_yellow': return 'Yellow Iron Ox';
      case 'ing_fe_red': return 'Red Iron Ox';
      case 'ing_fe_black': return 'Black Iron Ox';
      case 'ing_ultramarine_blue': return 'Ultramarine Blue';
      case 'ing_red_7_lake': return 'Red 7 Lake';
      case 'ing_mica_sericite': return 'Sericite Mica';
      default: return id;
    }
  }

  getPigmentColor(id: string): string {
    switch (id) {
      case 'ing_tio2_rutile': return '#FFFFFF';
      case 'ing_fe_yellow': return '#E2A93B';
      case 'ing_fe_red': return '#A8322D';
      case 'ing_fe_black': return '#222326';
      case 'ing_ultramarine_blue': return '#2E4C9D';
      case 'ing_red_7_lake': return '#C91D3E';
      case 'ing_mica_sericite': return '#F6F6F4';
      default: return '#CCCCCC';
    }
  }
}
