import { 
  AfterViewInit, 
  ChangeDetectionStrategy, 
  Component, 
  ElementRef, 
  OnDestroy, 
  ViewChild, 
  effect, 
  inject, 
  signal 
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { DigitalTwinStateService } from '../../core/services/digital-twin-state.service';
import { ImpellerType } from '../../core/models/mixing-physics.model';

@Component({
  selector: 'app-twin-viewport',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full min-h-[500px] overflow-hidden bg-[#07090e] select-none flex flex-col">
      <!-- 3D Canvas Mount Point -->
      <div #canvasMount class="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Top Overlay: Equipment Status & Mode Badge -->
      <div class="relative z-10 flex items-center justify-between p-4 pointer-events-none">
        <div class="flex items-center gap-3 bg-slate-900/80 backdrop-blur-md border border-slate-800 rounded-xl px-3.5 py-2 pointer-events-auto shadow-lg">
          <div class="w-2.5 h-2.5 rounded-full" [ngClass]="state.isSimulating() ? 'bg-emerald-500' : 'bg-amber-500'"></div>
          <div>
            <div class="text-[11px] font-mono tracking-wider uppercase text-slate-400">DIGITAL TWIN VESSEL</div>
            <div class="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <span>{{ state.activeVessel().name }}</span>
              <span class="text-xs font-mono text-slate-400">·</span>
              <span class="text-xs font-mono text-cyan-400">{{ state.impellerType() | titlecase }}</span>
            </div>
          </div>
        </div>

        <!-- Visual Mode Selector -->
        <div class="flex items-center gap-1 bg-slate-900/85 backdrop-blur-md border border-slate-800 p-1 rounded-xl pointer-events-auto shadow-lg text-xs">
          <button 
            (click)="state.viewportMode.set('photorealistic')"
            class="px-2.5 py-1.5 rounded-lg font-medium transition-colors"
            [ngClass]="state.viewportMode() === 'photorealistic' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'">
            Photorealistic
          </button>
          <button 
            (click)="state.viewportMode.set('concentration')"
            class="px-2.5 py-1.5 rounded-lg font-medium transition-colors"
            [ngClass]="state.viewportMode() === 'concentration' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'">
            Dispersion
          </button>
          <button 
            (click)="state.viewportMode.set('temperature')"
            class="px-2.5 py-1.5 rounded-lg font-medium transition-colors"
            [ngClass]="state.viewportMode() === 'temperature' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400 hover:text-slate-200'">
            Thermal Field
          </button>
        </div>
      </div>

      <!-- Quick Injection Particle Burst Flash Notification -->
      @if (injectionNotif()) {
        <div class="absolute top-20 left-1/2 -translate-x-1/2 z-20 bg-cyan-950/90 border border-cyan-500/50 text-cyan-200 text-xs px-4 py-1.5 rounded-full font-mono flex items-center gap-2 animate-bounce">
          <mat-icon class="text-xs text-cyan-400">science</mat-icon>
          <span>PIGMENT PHASE CHARGED INTO ROTOR-STATOR VORTEX</span>
        </div>
      }

      <div class="flex-1"></div>

      <!-- Collapsible Bottom Dock (Zero Viewport Occlusion Discipline) -->
      <div class="relative z-10 px-4 pb-4 flex justify-center pointer-events-none">
        <div class="pointer-events-auto bg-slate-900/90 backdrop-blur-md border border-slate-800/80 rounded-2xl shadow-2xl p-3 flex flex-wrap items-center gap-4 max-w-4xl w-full justify-between">
          
          <!-- Play / Pause / Reset & Speed -->
          <div class="flex items-center gap-2">
            <button 
              (click)="state.toggleSimulation()"
              class="w-9 h-9 rounded-xl flex items-center justify-center transition-colors"
              [ngClass]="state.isSimulating() ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40 hover:bg-amber-500/30' : 'bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400'"
              [title]="state.isSimulating() ? 'Pause Simulation' : 'Run Simulation'">
              <mat-icon class="text-lg">{{ state.isSimulating() ? 'pause' : 'play_arrow' }}</mat-icon>
            </button>

            <button 
              (click)="state.resetSimulation()"
              class="w-9 h-9 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 flex items-center justify-center transition-colors"
              title="Reset Timeline">
              <mat-icon class="text-base">restart_alt</mat-icon>
            </button>

            <div class="h-6 w-px bg-slate-800 mx-1"></div>

            <!-- Inject Pigment Grind Action -->
            <button 
              (click)="triggerPigmentDrop()"
              class="px-3 py-1.5 rounded-xl bg-gradient-to-r from-rose-900/40 to-amber-900/40 border border-rose-500/30 text-rose-200 hover:text-white hover:border-rose-400 text-xs font-medium flex items-center gap-1.5 transition-all shadow-sm">
              <mat-icon class="text-sm text-rose-400">opacity</mat-icon>
              <span>Charge Pigment</span>
            </button>
          </div>

          <!-- RPM Scrubber -->
          <div class="flex items-center gap-3 min-w-[220px]">
            <span class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">RPM</span>
            <input 
              type="range" 
              min="0" 
              max="3500" 
              step="25"
              [value]="state.rpm()" 
              (input)="onRpmSliderChange($event)"
              class="w-28 accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer" />
            <span class="text-xs font-mono font-bold text-cyan-300 w-12 text-right">{{ state.rpm() }}</span>
          </div>

          <!-- Camera Angles -->
          <div class="flex items-center gap-1.5 text-xs text-slate-400">
            <span class="text-[10px] font-mono uppercase tracking-wider text-slate-500 mr-1">CAMERA:</span>
            <button 
              (click)="setCameraPreset('isometric')"
              class="px-2 py-1 rounded-lg hover:bg-slate-800 transition-colors"
              [ngClass]="activeCamera() === 'isometric' ? 'bg-slate-800 text-cyan-300' : 'text-slate-400'">
              Iso
            </button>
            <button 
              (click)="setCameraPreset('top')"
              class="px-2 py-1 rounded-lg hover:bg-slate-800 transition-colors"
              [ngClass]="activeCamera() === 'top' ? 'bg-slate-800 text-cyan-300' : 'text-slate-400'">
              Top Vortex
            </button>
            <button 
              (click)="setCameraPreset('impeller')"
              class="px-2 py-1 rounded-lg hover:bg-slate-800 transition-colors"
              [ngClass]="activeCamera() === 'impeller' ? 'bg-slate-800 text-cyan-300' : 'text-slate-400'">
              Impeller
            </button>
          </div>

          <!-- Transparency Toggle -->
          <div class="flex items-center gap-2">
            <span class="text-[11px] font-mono text-slate-400 uppercase">SHELL:</span>
            <button 
              (click)="toggleVesselGlass()"
              class="text-xs px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800">
              {{ isSolidVessel() ? 'Stainless Steel' : 'Borosilicate Glass' }}
            </button>
          </div>

        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `]
})
export class TwinViewport implements AfterViewInit, OnDestroy {
  @ViewChild('canvasMount', { static: true }) canvasMount!: ElementRef<HTMLDivElement>;

  readonly state = inject(DigitalTwinStateService);

  readonly activeCamera = signal<'isometric' | 'top' | 'impeller'>('isometric');
  readonly isSolidVessel = signal<boolean>(false);
  readonly injectionNotif = signal<boolean>(false);

  // Three.js instances
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private animationFrameId = 0;
  private isDestroyed = false;

  // Scene object references
  private vesselGlassMesh!: THREE.Mesh;
  private vesselFluidMesh!: THREE.Mesh;
  private shaftGroup = new THREE.Group();
  private impellerMeshGroup = new THREE.Group();
  private particleCloud!: THREE.Points;
  private particlePositions!: Float32Array;
  private particleSpeeds!: Float32Array;
  private particleAngles!: Float32Array;
  private particleRadii!: Float32Array;
  private particleYPos!: Float32Array;

  // Materials for dynamic tuning
  private fluidMaterial!: THREE.MeshPhysicalMaterial;
  private glassMaterial!: THREE.MeshPhysicalMaterial;
  private thermalMaterial!: THREE.MeshBasicMaterial;

  // Camera orbit interaction state
  private isDragging = false;
  private prevMouseX = 0;
  private prevMouseY = 0;
  private spherical = { radius: 3.2, theta: 0.6, phi: 1.15 };
  private targetSpherical = { radius: 3.2, theta: 0.6, phi: 1.15 };

  constructor() {
    // Reactive sync: When formula color or dispersion changes, update fluid material
    effect(() => {
      const hex = this.state.transientMixtureColorHex();
      const mode = this.state.viewportMode();
      const tempC = this.state.batchTempC();
      this.updateFluidAppearance(hex, mode, tempC);
    });

    // Reactive sync: When impeller type changes, rebuild 3D impeller geometry
    effect(() => {
      const type = this.state.impellerType();
      this.rebuildImpellerGeometry(type);
    });
  }

  ngAfterViewInit(): void {
    if (typeof window === 'undefined') return;
    this.initThree();
    this.initPointerControls();
    this.startRenderLoop();
  }

  ngOnDestroy(): void {
    this.isDestroyed = true;
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private initThree() {
    const container = this.canvasMount.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    // Detect software WebGL for performance pacing per Three.js skill
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0c12);
    this.scene.fog = new THREE.FogExp2(0x0a0c12, 0.12);

    this.camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 50);
    this.updateCameraPosition();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance'
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.2;
    this.renderer.shadowMap.enabled = !isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // Studio Environment lighting using RoomEnvironment
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Key Light (Warm)
    const keyLight = new THREE.DirectionalLight(0xfff5ea, 2.5);
    keyLight.position.set(3, 4, 3);
    keyLight.castShadow = !isSoftwareGl;
    this.scene.add(keyLight);

    // Fill Light (Cool slate)
    const fillLight = new THREE.DirectionalLight(0xd4e2ff, 1.2);
    fillLight.position.set(-3, 2, -2);
    this.scene.add(fillLight);

    // Rim / Backlight (Precision blue accent)
    const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.8);
    rimLight.position.set(0, 4, -4);
    this.scene.add(rimLight);

    // Ambient / Hemisphere
    const hemiLight = new THREE.HemisphereLight(0xffffff, 0x1e293b, 0.8);
    this.scene.add(hemiLight);

    // Build the 3D Vessel, Drive Shaft, Fluid and Impeller
    this.buildLabScene();

    // Resize observer
    window.addEventListener('resize', this.onWindowResize);
  }

  private buildLabScene() {
    const vesselRadius = 0.8;
    const vesselHeight = 1.8;

    // 1. Ground Contact Shadow Plane
    const shadowGeo = new THREE.PlaneGeometry(4.5, 4.5);
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 128;
    shadowCanvas.height = 128;
    const ctx = shadowCanvas.getContext('2d')!;
    const grad = ctx.createRadialGradient(64, 64, 10, 64, 64, 60);
    grad.addColorStop(0, 'rgba(0,0,0,0.7)');
    grad.addColorStop(0.5, 'rgba(0,0,0,0.3)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 128, 128);
    const shadowTex = new THREE.CanvasTexture(shadowCanvas);

    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = -0.01;
    this.scene.add(shadowMesh);

    // 2. Base Metal Mounting Flange
    const basePlateGeo = new THREE.CylinderGeometry(vesselRadius * 1.15, vesselRadius * 1.2, 0.08, 36);
    const metalMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      metalness: 0.9,
      roughness: 0.25
    });
    const basePlate = new THREE.Mesh(basePlateGeo, metalMat);
    basePlate.position.y = 0.04;
    this.scene.add(basePlate);

    // 3. Borosilicate Glass Cylinder Vessel with hemispherical/rounded bottom
    const vesselGeo = new THREE.CylinderGeometry(vesselRadius, vesselRadius, vesselHeight, 36, 1, true);
    this.glassMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      metalness: 0.05,
      roughness: 0.08,
      transmission: 0.92,
      ior: 1.52,
      thickness: 0.2,
      transparent: true,
      opacity: 0.35,
      depthWrite: false,
      side: THREE.DoubleSide
    });
    this.vesselGlassMesh = new THREE.Mesh(vesselGeo, this.glassMaterial);
    this.vesselGlassMesh.position.y = vesselHeight / 2 + 0.05;
    this.scene.add(this.vesselGlassMesh);

    // Vessel volume graduation rings
    for (let i = 1; i <= 4; i++) {
      const ringGeo = new THREE.RingGeometry(vesselRadius * 0.995, vesselRadius * 1.002, 36);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0x64748b, side: THREE.DoubleSide, transparent: true, opacity: 0.5 });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = 0.3 + (i * 0.32);
      this.scene.add(ring);
    }

    // 4. Baffles (4 vertical stainless plates along inner vessel wall)
    const baffleGeo = new THREE.BoxGeometry(0.015, vesselHeight * 0.85, vesselRadius * 0.16);
    for (let i = 0; i < 4; i++) {
      const baffle = new THREE.Mesh(baffleGeo, metalMat);
      const angle = (i * Math.PI) / 2;
      baffle.position.x = Math.cos(angle) * (vesselRadius - 0.08);
      baffle.position.z = Math.sin(angle) * (vesselRadius - 0.08);
      baffle.position.y = vesselHeight * 0.5;
      baffle.rotation.y = -angle;
      this.scene.add(baffle);
    }

    // 5. Cosmetic Fluid Core
    const fluidRadius = vesselRadius * 0.96;
    const fluidHeight = vesselHeight * 0.72;
    const fluidGeo = new THREE.CylinderGeometry(fluidRadius, fluidRadius, fluidHeight, 36);
    
    this.fluidMaterial = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(this.state.transientMixtureColorHex()),
      roughness: 0.25,
      metalness: 0.05,
      clearcoat: 0.8,
      clearcoatRoughness: 0.15,
      transmission: 0.05,
      ior: 1.45
    });

    this.vesselFluidMesh = new THREE.Mesh(fluidGeo, this.fluidMaterial);
    this.vesselFluidMesh.position.y = fluidHeight / 2 + 0.06;
    this.scene.add(this.vesselFluidMesh);

    // 6. Central Drive Shaft & Motor Top Assembly
    const shaftGeo = new THREE.CylinderGeometry(0.02, 0.02, vesselHeight * 1.05, 18);
    const shaftMesh = new THREE.Mesh(shaftGeo, metalMat);
    shaftMesh.position.y = vesselHeight * 0.55;
    this.shaftGroup.add(shaftMesh);

    // Motor head above vessel
    const motorHeadGeo = new THREE.CylinderGeometry(0.18, 0.22, 0.35, 24);
    const motorMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.7, roughness: 0.3 });
    const motorHead = new THREE.Mesh(motorHeadGeo, motorMat);
    motorHead.position.y = vesselHeight + 0.25;
    this.scene.add(motorHead);

    // Top mounting bridge
    const bridgeGeo = new THREE.BoxGeometry(vesselRadius * 2.3, 0.06, 0.25);
    const bridge = new THREE.Mesh(bridgeGeo, metalMat);
    bridge.position.y = vesselHeight + 0.08;
    this.scene.add(bridge);

    // 7. Assemble Impeller Group
    this.impellerMeshGroup.position.y = 0.35; // clearance from bottom
    this.shaftGroup.add(this.impellerMeshGroup);
    this.scene.add(this.shaftGroup);

    this.rebuildImpellerGeometry(this.state.impellerType());

    // 8. Particle Transport Cloud (500 dynamic particles showing fluid flow lines & pigment dispersion)
    this.initParticleCloud(fluidRadius, fluidHeight);
  }

  private initParticleCloud(radius: number, height: number) {
    const particleCount = 650;
    const geometry = new THREE.BufferGeometry();
    this.particlePositions = new Float32Array(particleCount * 3);
    this.particleSpeeds = new Float32Array(particleCount);
    this.particleAngles = new Float32Array(particleCount);
    this.particleRadii = new Float32Array(particleCount);
    this.particleYPos = new Float32Array(particleCount);

    for (let i = 0; i < particleCount; i++) {
      const r = 0.08 + Math.random() * (radius - 0.12);
      const theta = Math.random() * Math.PI * 2;
      const y = 0.1 + Math.random() * (height - 0.15);

      this.particleRadii[i] = r;
      this.particleAngles[i] = theta;
      this.particleYPos[i] = y;
      this.particleSpeeds[i] = 0.5 + Math.random() * 1.5;

      this.particlePositions[i * 3] = Math.cos(theta) * r;
      this.particlePositions[i * 3 + 1] = y;
      this.particlePositions[i * 3 + 2] = Math.sin(theta) * r;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(this.particlePositions, 3));

    const particleMat = new THREE.PointsMaterial({
      color: 0x38bdf8,
      size: 0.025,
      transparent: true,
      opacity: 0.65,
      blending: THREE.AdditiveBlending
    });

    this.particleCloud = new THREE.Points(geometry, particleMat);
    this.scene.add(this.particleCloud);
  }

  private rebuildImpellerGeometry(type: ImpellerType) {
    // Clear existing impeller parts
    while (this.impellerMeshGroup.children.length > 0) {
      const obj = this.impellerMeshGroup.children[0];
      this.impellerMeshGroup.remove(obj);
    }

    const steel = new THREE.MeshStandardMaterial({
      color: 0xcbd5e1,
      metalness: 0.95,
      roughness: 0.15
    });

    // Central collar
    const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.08, 16), steel);
    this.impellerMeshGroup.add(collar);

    switch (type) {
      case 'rushton-turbine': {
        // Central disc with 6 vertical radial blades
        const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.015, 24), steel);
        this.impellerMeshGroup.add(disc);
        for (let i = 0; i < 6; i++) {
          const blade = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.10, 0.01), steel);
          const ang = (i * Math.PI) / 3;
          blade.position.x = Math.cos(ang) * 0.22;
          blade.position.z = Math.sin(ang) * 0.22;
          blade.rotation.y = -ang;
          this.impellerMeshGroup.add(blade);
        }
        break;
      }

      case 'pitched-blade': {
        // 4 blades angled at 45 degrees
        for (let i = 0; i < 4; i++) {
          const blade = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.08, 0.012), steel);
          const ang = (i * Math.PI) / 2;
          blade.position.x = Math.cos(ang) * 0.14;
          blade.position.z = Math.sin(ang) * 0.14;
          blade.rotation.y = -ang;
          blade.rotation.z = Math.PI / 4; // 45 degree pitch
          this.impellerMeshGroup.add(blade);
        }
        break;
      }

      case 'marine-propeller': {
        // 3 curved hydrofoil blades
        for (let i = 0; i < 3; i++) {
          const blade = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.18, 0.22, 12), steel);
          const ang = (i * Math.PI * 2) / 3;
          blade.position.x = Math.cos(ang) * 0.12;
          blade.position.z = Math.sin(ang) * 0.12;
          blade.rotation.z = Math.PI / 2.5;
          blade.rotation.y = -ang;
          this.impellerMeshGroup.add(blade);
        }
        break;
      }

      case 'anchor': {
        // Large U-shaped anchor conforming to vessel wall
        const bottomBar = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.04, 0.03), steel);
        this.impellerMeshGroup.add(bottomBar);
        // Two vertical scrapers
        const leftWing = new THREE.Mesh(new THREE.BoxGeometry(0.04, 1.1, 0.03), steel);
        leftWing.position.set(-0.68, 0.55, 0);
        this.impellerMeshGroup.add(leftWing);
        const rightWing = new THREE.Mesh(new THREE.BoxGeometry(0.04, 1.1, 0.03), steel);
        rightWing.position.set(0.68, 0.55, 0);
        this.impellerMeshGroup.add(rightWing);
        break;
      }

      case 'high-shear-rotor-stator': {
        // High shear slotted head
        const rotor = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.12, 16), steel);
        this.impellerMeshGroup.add(rotor);
        // Slotted stator ring around rotor
        const stator = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.025, 12, 24), steel);
        this.impellerMeshGroup.add(stator);
        break;
      }

      default: {
        // Default dual paddle
        const paddle = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.12, 0.015), steel);
        this.impellerMeshGroup.add(paddle);
        break;
      }
    }
  }

  private updateFluidAppearance(hexColor: string, mode: string, tempC: number) {
    if (!this.fluidMaterial) return;

    if (mode === 'photorealistic') {
      this.fluidMaterial.color.set(hexColor);
      this.fluidMaterial.roughness = 0.22;
      this.fluidMaterial.metalness = 0.05;
      if (this.particleCloud) {
        (this.particleCloud.material as THREE.PointsMaterial).color.set(0x38bdf8);
        (this.particleCloud.material as THREE.PointsMaterial).opacity = 0.45;
      }
    } else if (mode === 'concentration') {
      // Color-coded pigment concentration gradient (deep magenta to cyan)
      this.fluidMaterial.color.set(0x0f766e);
      this.fluidMaterial.roughness = 0.4;
      if (this.particleCloud) {
        (this.particleCloud.material as THREE.PointsMaterial).color.set(0xf43f5e);
        (this.particleCloud.material as THREE.PointsMaterial).opacity = 0.9;
      }
    } else if (mode === 'temperature') {
      // Thermal heatmap: blue (20C) -> green (30C) -> amber (50C) -> red (80C)
      const tNorm = Math.min(1.0, Math.max(0.0, (tempC - 20) / 60));
      const thermalColor = new THREE.Color();
      if (tNorm < 0.33) {
        thermalColor.setRGB(0.1, 0.5 + tNorm * 1.5, 0.9);
      } else if (tNorm < 0.66) {
        thermalColor.setRGB(0.9, 0.7 - (tNorm - 0.33), 0.1);
      } else {
        thermalColor.setRGB(0.95, 0.2, 0.1);
      }
      this.fluidMaterial.color.copy(thermalColor);
      if (this.particleCloud) {
        (this.particleCloud.material as THREE.PointsMaterial).color.copy(thermalColor);
        (this.particleCloud.material as THREE.PointsMaterial).opacity = 0.75;
      }
    }
  }

  private startRenderLoop() {
    let lastTime = performance.now();

    const animate = (currentTime: number) => {
      if (this.isDestroyed) return;
      this.animationFrameId = requestAnimationFrame(animate);

      const delta = (currentTime - lastTime) / 1000.0;
      lastTime = currentTime;

      // 1. Smoothly interpolate camera position using spherical dampening
      this.spherical.theta += (this.targetSpherical.theta - this.spherical.theta) * 0.08;
      this.spherical.phi += (this.targetSpherical.phi - this.spherical.phi) * 0.08;
      this.spherical.radius += (this.targetSpherical.radius - this.spherical.radius) * 0.08;
      this.updateCameraPosition();

      // 2. Rotate drive shaft and impeller based on real simulated RPM
      if (this.state.isSimulating()) {
        const rpm = this.state.rpm();
        const radPerSec = (rpm / 60.0) * Math.PI * 2;
        this.shaftGroup.rotation.y += radPerSec * delta;

        // 3. Update particle transport simulation inside fluid vortex
        this.updateParticlePhysics(radPerSec, delta);
      }

      this.renderer.render(this.scene, this.camera);
    };

    this.animationFrameId = requestAnimationFrame(animate);
  }

  private updateParticlePhysics(radPerSec: number, delta: number) {
    if (!this.particlePositions) return;

    const count = this.particleSpeeds.length;
    const swirlFactor = Math.min(25.0, radPerSec * 0.65);

    for (let i = 0; i < count; i++) {
      // Angular velocity decreases with radius (vortex conservation)
      const r = this.particleRadii[i];
      const omega = (swirlFactor / Math.max(0.1, r * 2.0)) * this.particleSpeeds[i];
      this.particleAngles[i] += omega * delta;

      // Vertical axial circulation loop
      this.particleYPos[i] += Math.sin(this.particleAngles[i] * 2) * 0.005 * radPerSec * delta;
      if (this.particleYPos[i] > 1.3) this.particleYPos[i] = 0.15;
      if (this.particleYPos[i] < 0.15) this.particleYPos[i] = 1.3;

      const theta = this.particleAngles[i];
      const y = this.particleYPos[i];

      this.particlePositions[i * 3] = Math.cos(theta) * r;
      this.particlePositions[i * 3 + 1] = y;
      this.particlePositions[i * 3 + 2] = Math.sin(theta) * r;
    }

    this.particleCloud.geometry.attributes['position'].needsUpdate = true;
  }

  private initPointerControls() {
    const el = this.canvasMount.nativeElement;

    el.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.prevMouseX = e.clientX;
      this.prevMouseY = e.clientY;
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;
      const dx = e.clientX - this.prevMouseX;
      const dy = e.clientY - this.prevMouseY;

      this.targetSpherical.theta -= dx * 0.006;
      this.targetSpherical.phi = Math.max(0.2, Math.min(Math.PI / 2 - 0.05, this.targetSpherical.phi - dy * 0.006));

      this.prevMouseX = e.clientX;
      this.prevMouseY = e.clientY;
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    el.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.targetSpherical.radius = Math.max(1.5, Math.min(6.0, this.targetSpherical.radius + e.deltaY * 0.003));
    }, { passive: false });
  }

  private updateCameraPosition() {
    const { radius, theta, phi } = this.spherical;
    const x = radius * Math.sin(phi) * Math.sin(theta);
    const y = radius * Math.cos(phi) + 0.8; // look slightly above vessel bottom
    const z = radius * Math.sin(phi) * Math.cos(theta);

    this.camera.position.set(x, y, z);
    this.camera.lookAt(0, 0.85, 0);
  }

  private onWindowResize = () => {
    if (!this.canvasMount || !this.renderer || !this.camera) return;
    const container = this.canvasMount.nativeElement;
    const width = container.clientWidth;
    const height = container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  // UI Handlers
  setCameraPreset(preset: 'isometric' | 'top' | 'impeller') {
    this.activeCamera.set(preset);
    if (preset === 'isometric') {
      this.targetSpherical = { radius: 3.2, theta: 0.65, phi: 1.15 };
    } else if (preset === 'top') {
      this.targetSpherical = { radius: 2.8, theta: 0.0, phi: 0.25 };
    } else if (preset === 'impeller') {
      this.targetSpherical = { radius: 1.8, theta: 0.4, phi: 1.35 };
    }
  }

  toggleVesselGlass() {
    this.isSolidVessel.update(v => !v);
    if (this.vesselGlassMesh) {
      if (this.isSolidVessel()) {
        this.glassMaterial.transmission = 0.0;
        this.glassMaterial.opacity = 1.0;
        this.glassMaterial.metalness = 0.95;
        this.glassMaterial.roughness = 0.2;
        this.glassMaterial.color.set(0x94a3b8);
      } else {
        this.glassMaterial.transmission = 0.92;
        this.glassMaterial.opacity = 0.35;
        this.glassMaterial.metalness = 0.05;
        this.glassMaterial.roughness = 0.08;
        this.glassMaterial.color.set(0xffffff);
      }
    }
  }

  onRpmSliderChange(event: Event) {
    const target = event.target as HTMLInputElement;
    this.state.updateRpm(parseFloat(target.value));
  }

  triggerPigmentDrop() {
    this.injectionNotif.set(true);
    // Temporarily increase particles around center shaft
    if (this.particlePositions) {
      for (let i = 0; i < 150; i++) {
        this.particleRadii[i] = 0.02 + Math.random() * 0.15;
        this.particleYPos[i] = 1.35;
      }
    }
    setTimeout(() => {
      this.injectionNotif.set(false);
    }, 2800);
  }
}
