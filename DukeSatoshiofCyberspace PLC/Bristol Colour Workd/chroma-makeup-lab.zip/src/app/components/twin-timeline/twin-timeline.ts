import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinStateService } from '../../core/services/digital-twin-state.service';

interface TimelineEvent {
  timeSec: number;
  label: string;
  phase: string;
  rpm: number;
  action: string;
  icon: string;
}

@Component({
  selector: 'app-twin-timeline',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-24 bg-slate-950/95 border-t border-slate-800/80 px-4 py-2 flex flex-col justify-between shrink-0 select-none">
      
      <!-- Timeline Header -->
      <div class="flex items-center justify-between text-[11px] font-mono text-slate-400">
        <div class="flex items-center gap-2">
          <mat-icon class="text-xs text-cyan-400">schedule</mat-icon>
          <span class="font-bold text-slate-200">PROCESS TIMELINE</span>
          <span class="text-slate-600">·</span>
          <span>Time: <strong class="text-cyan-300">{{ state.simulationTimeSec().toFixed(1) }}s</strong></span>
        </div>

        <div class="flex items-center gap-4 text-[10px]">
          <span class="flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-cyan-400"></span> Phase A/B Base
          </span>
          <span class="flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-rose-400"></span> Phase C Pigments
          </span>
          <span class="flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-emerald-400"></span> Phase D QC
          </span>
        </div>
      </div>

      <!-- Scrubber Bar & Event Markers -->
      <div class="relative w-full h-8 flex items-center">
        <!-- Progress Bar Background -->
        <div class="w-full h-1.5 bg-slate-800 rounded-full relative overflow-hidden">
          <div 
            class="h-full bg-gradient-to-r from-cyan-400 via-amber-300 to-rose-400 transition-all duration-300 rounded-full"
            [style.width.%]="progressPercent()"></div>
        </div>

        <!-- Event Nodes -->
        @for (ev of events; track ev.timeSec) {
          @let leftPct = (ev.timeSec / maxTimeSec) * 100;
          <button 
            type="button"
            class="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center group cursor-pointer bg-transparent border-none p-0 focus:outline-none"
            [style.left.%]="leftPct"
            (click)="jumpToEvent(ev)">
            <div 
              class="w-5 h-5 rounded-full border flex items-center justify-center transition-all shadow-md"
              [ngClass]="state.simulationTimeSec() >= ev.timeSec ? 'bg-slate-900 border-cyan-400 text-cyan-300 scale-110' : 'bg-slate-950 border-slate-700 text-slate-500 hover:border-slate-500'">
              <mat-icon class="text-[11px]">{{ ev.icon }}</mat-icon>
            </div>
            
            <!-- Tooltip on hover -->
            <div class="absolute bottom-6 hidden group-hover:flex flex-col items-center bg-slate-900 border border-slate-700 p-1.5 rounded-lg text-[9px] font-mono text-slate-200 whitespace-nowrap z-30 shadow-xl pointer-events-none">
              <span class="font-bold text-cyan-300">{{ ev.label }}</span>
              <span class="text-slate-400">{{ ev.timeSec }}s · {{ ev.rpm }} RPM</span>
            </div>
          </button>
        }
      </div>

      <!-- Timeline Step Indicator Bar -->
      <div class="flex justify-between text-[9px] font-mono text-slate-500 pt-0.5">
        <span>0s (Start Agitation)</span>
        <span>15s (Organoclay Activation)</span>
        <span>30s (Pigment Grind Injection)</span>
        <span>45s (Emulsion Drop Inverted)</span>
        <span>60s (Final De-aeration & Release)</span>
      </div>

    </div>
  `
})
export class TwinTimeline {
  readonly state = inject(DigitalTwinStateService);

  readonly maxTimeSec = 60.0;

  readonly events: TimelineEvent[] = [
    { timeSec: 0, label: 'Charge Phase B Silicones', phase: 'B', rpm: 150, action: 'Charge', icon: 'opacity' },
    { timeSec: 15, label: 'Bentone Shear Activation', phase: 'B', rpm: 1200, action: 'Homogenize', icon: 'speed' },
    { timeSec: 30, label: 'Pigment Dispersion Grind', phase: 'C', rpm: 2500, action: 'Pigment-Grind', icon: 'palette' },
    { timeSec: 45, label: 'Aqueous Phase A Titration', phase: 'A', rpm: 450, action: 'Agitate', icon: 'water_drop' },
    { timeSec: 60, label: 'Preservative & QC Sample Release', phase: 'D', rpm: 200, action: 'Sample-QC', icon: 'verified' }
  ];

  progressPercent(): number {
    return Math.min(100, (this.state.simulationTimeSec() / this.maxTimeSec) * 100);
  }

  jumpToEvent(ev: TimelineEvent) {
    this.state.simulationTimeSec.set(ev.timeSec);
    this.state.updateRpm(ev.rpm);
  }
}
