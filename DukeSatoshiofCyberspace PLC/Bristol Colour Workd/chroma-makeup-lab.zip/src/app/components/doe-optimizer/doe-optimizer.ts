import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { DigitalTwinStateService } from '../../core/services/digital-twin-state.service';

interface DOERun {
  runId: number;
  x1Pigment: number;   // %
  x2Emulsifier: number;// %
  x3Thickener: number; // %
  rpm: number;
  predictedViscosityCP: number;
  predictedDeltaE00: number;
  predictedDropletSizeUm: number;
  desirabilityScore: number;
}

@Component({
  selector: 'app-doe-optimizer',
  standalone: true,
  imports: [CommonModule, MatIconModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto bg-[#07090e] p-6 space-y-6">
      
      <!-- DOE Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <span class="text-[11px] font-mono tracking-wider uppercase text-slate-400">STATISTICAL DESIGN OF EXPERIMENTS</span>
          <h1 class="text-xl font-bold text-slate-100 flex items-center gap-3">
            <span>Mixture Design & Response Surface Methodology (RSM)</span>
            <span class="text-xs font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              SIMPLEX-LATTICE
            </span>
          </h1>
        </div>

        <div class="flex items-center gap-3">
          <button 
            (click)="applyOptimalPoint()"
            class="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-400 via-amber-300 to-rose-400 text-slate-950 font-semibold text-xs transition-all hover:brightness-110 shadow-lg flex items-center gap-2">
            <mat-icon class="text-sm">tune</mat-icon>
            <span>Apply Global Desirability Optimum</span>
          </button>
        </div>
      </div>

      <!-- Ternary Simplex Triangle & Response Surface Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <!-- Left: Ternary Mixture Simplex Plot -->
        <div class="p-5 rounded-2xl bg-slate-900/70 border border-slate-800/80 space-y-4">
          <div class="flex items-center justify-between">
            <div>
              <span class="text-xs font-mono uppercase tracking-wider text-slate-400">TERNARY MIXTURE DESIGN SPACE</span>
              <h2 class="text-base font-bold text-slate-100">X1: Pigment Grind · X2: Emulsifier · X3: Organoclay</h2>
            </div>
            <span class="text-xs font-mono text-cyan-400">Σ X_i = Constrained</span>
          </div>

          <!-- SVG Ternary Triangle Plot -->
          <div class="w-full h-80 bg-slate-950 rounded-xl p-4 border border-slate-800 relative flex items-center justify-center">
            <svg class="w-full h-full max-w-[380px]" viewBox="0 0 320 280">
              <defs>
                <linearGradient id="simplexGrad" x1="0%" y1="100%" x2="50%" y2="0%">
                  <stop offset="0%" stop-color="#0f766e" stop-opacity="0.6" />
                  <stop offset="50%" stop-color="#3b82f6" stop-opacity="0.6" />
                  <stop offset="100%" stop-color="#f43f5e" stop-opacity="0.6" />
                </linearGradient>
              </defs>

              <!-- Main Equilateral Triangle -->
              <!-- Top: (160, 30) -> X1 Pigment -->
              <!-- Bottom Left: (40, 240) -> X2 Emulsifier -->
              <!-- Bottom Right: (280, 240) -> X3 Thickener -->
              <polygon points="160,30 40,240 280,240" fill="url(#simplexGrad)" stroke="#64748b" stroke-width="2" />

              <!-- Interior grid lines -->
              <line x1="100" y1="135" x2="220" y2="135" stroke="#334155" stroke-dasharray="2,2" />
              <line x1="70" y1="187" x2="250" y2="187" stroke="#334155" stroke-dasharray="2,2" />

              <line x1="100" y1="135" x2="160" y2="240" stroke="#334155" stroke-dasharray="2,2" />
              <line x1="220" y1="135" x2="160" y2="240" stroke="#334155" stroke-dasharray="2,2" />

              <!-- Vertex Labels -->
              <text x="160" y="20" fill="#f43f5e" font-size="11" font-weight="bold" font-family="monospace" text-anchor="middle">
                ▲ X1: Pigments (12%)
              </text>
              <text x="30" y="255" fill="#38bdf8" font-size="10" font-weight="bold" font-family="monospace">
                ◄ X2: Emulsifier (5%)
              </text>
              <text x="210" y="255" fill="#34d399" font-size="10" font-weight="bold" font-family="monospace">
                X3: Thickener (3%) ►
              </text>

              <!-- DOE Experimental Sample Run Nodes -->
              @for (run of doeRuns(); track run.runId) {
                @let pos = getSimplexCoordinates(run.x1Pigment, run.x2Emulsifier, run.x3Thickener);
                <circle 
                  [attr.cx]="pos.x" 
                  [attr.cy]="pos.y" 
                  r="6" 
                  [attr.fill]="run.desirabilityScore > 0.9 ? '#fbbf24' : '#38bdf8'" 
                  stroke="#07090e" 
                  stroke-width="2" 
                  class="cursor-pointer hover:r-8 transition-all" />
                <text 
                  [attr.x]="pos.x + 8" 
                  [attr.y]="pos.y + 4" 
                  fill="#ffffff" 
                  font-size="9" 
                  font-family="monospace">
                  R{{ run.runId }}
                </text>
              }

              <!-- Golden Optimal Star Point -->
              <circle cx="168" cy="148" r="8" fill="#fbbf24" stroke="#ffffff" stroke-width="2" />
              <text x="180" y="152" fill="#fbbf24" font-size="10" font-weight="bold" font-family="monospace">
                ★ OPTIMUM (D=0.96)
              </text>
            </svg>
          </div>

          <div class="text-[11px] font-mono text-slate-400">
            Simplex points represent Scheffé canonical polynomial mixture designs. Model accounts for antagonistic and synergistic ingredient pair interactions.
          </div>
        </div>

        <!-- Right: Multi-Objective Desirability Function & Response Surface -->
        <div class="p-5 rounded-2xl bg-slate-900/70 border border-slate-800/80 space-y-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3">
              <span class="text-xs font-mono uppercase tracking-wider text-slate-400">RESPONSE SURFACE OBJECTIVES</span>
              <span class="text-xs font-mono text-amber-300 font-bold">Harrington Desirability d = 0.96</span>
            </div>

            <!-- Target Sliders & Weights -->
            <div class="space-y-3.5">
              <!-- Objective 1: Minimize DeltaE00 -->
              <div class="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                <div class="flex items-center justify-between text-xs font-mono">
                  <span class="text-slate-300 font-semibold">1. Colour Shift Target: Min ΔE₀₀ &lt; 0.8</span>
                  <span class="text-emerald-400 font-bold">d₁ = 0.98</span>
                </div>
                <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div class="h-full bg-emerald-400 rounded-full w-[98%]"></div>
                </div>
                <div class="text-[10px] text-slate-500 font-mono">Weight: 40% (Most critical attribute for commercial shade release)</div>
              </div>

              <!-- Objective 2: Viscosity Target Window -->
              <div class="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                <div class="flex items-center justify-between text-xs font-mono">
                  <span class="text-slate-300 font-semibold">2. Target Viscosity Window: 3,800 – 4,500 cP</span>
                  <span class="text-cyan-400 font-bold">d₂ = 0.95</span>
                </div>
                <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div class="h-full bg-cyan-400 rounded-full w-[95%]"></div>
                </div>
                <div class="text-[10px] text-slate-500 font-mono">Weight: 35% (Ensures stable suspension and pleasant pump dispense)</div>
              </div>

              <!-- Objective 3: Emulsion Droplet Size -->
              <div class="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                <div class="flex items-center justify-between text-xs font-mono">
                  <span class="text-slate-300 font-semibold">3. Sauter Droplet Diameter: d₃₂ &lt; 2.5 µm</span>
                  <span class="text-amber-400 font-bold">d₃ = 0.94</span>
                </div>
                <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div class="h-full bg-amber-400 rounded-full w-[94%]"></div>
                </div>
                <div class="text-[10px] text-slate-500 font-mono">Weight: 25% (Prevents Ostwald ripening and creaming)</div>
              </div>
            </div>
          </div>

          <!-- Composite Global Desirability Score Banner -->
          <div class="p-4 rounded-xl bg-gradient-to-r from-amber-950/40 via-cyan-950/40 to-slate-900 border border-amber-500/40 flex items-center justify-between">
            <div>
              <div class="text-[10px] font-mono text-amber-300 uppercase">COMPOSITE DESIRABILITY D = (d₁·d₂·d₃)^(1/3)</div>
              <div class="text-2xl font-mono font-bold text-slate-100">0.96 / 1.00</div>
            </div>
            <div class="text-right text-xs font-mono text-slate-300">
              <div>Pigment: <span class="text-rose-300 font-bold">12.8%</span></div>
              <div>Emulsifier: <span class="text-cyan-300 font-bold">3.2%</span></div>
              <div>Thickener: <span class="text-emerald-300 font-bold">1.8%</span></div>
            </div>
          </div>

        </div>

      </div>

      <!-- DOE Matrix Table -->
      <div class="p-5 rounded-2xl bg-slate-900/70 border border-slate-800/80 space-y-4">
        <div class="flex items-center justify-between">
          <span class="text-xs font-mono uppercase tracking-wider text-slate-400">DESIGN MATRIX RUNS & RESPONSE SURFACE DATA</span>
          <span class="text-xs font-mono text-slate-400">7 Experimental Design Points</span>
        </div>

        <div class="border border-slate-800 rounded-xl overflow-hidden bg-slate-950">
          <table class="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr class="border-b border-slate-800 bg-slate-900/80 text-[10px] uppercase text-slate-400">
                <th class="py-2.5 px-3">Run</th>
                <th class="py-2.5 px-3">X1: Pigment (%)</th>
                <th class="py-2.5 px-3">X2: Emulsifier (%)</th>
                <th class="py-2.5 px-3">X3: Organoclay (%)</th>
                <th class="py-2.5 px-3">RPM</th>
                <th class="py-2.5 px-3">Viscosity (cP)</th>
                <th class="py-2.5 px-3">ΔE₀₀</th>
                <th class="py-2.5 px-3">Droplet d₃₂</th>
                <th class="py-2.5 px-3 text-right">Desirability</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (r of doeRuns(); track r.runId) {
                <tr class="hover:bg-slate-900/40">
                  <td class="py-2 px-3 font-bold text-slate-300">Run #{{ r.runId }}</td>
                  <td class="py-2 px-3 text-slate-200">{{ r.x1Pigment.toFixed(2) }}%</td>
                  <td class="py-2 px-3 text-slate-200">{{ r.x2Emulsifier.toFixed(2) }}%</td>
                  <td class="py-2 px-3 text-slate-200">{{ r.x3Thickener.toFixed(2) }}%</td>
                  <td class="py-2 px-3 text-slate-400">{{ r.rpm }}</td>
                  <td class="py-2 px-3 text-slate-200">{{ r.predictedViscosityCP }} cP</td>
                  <td class="py-2 px-3" [ngClass]="r.predictedDeltaE00 <= 1.0 ? 'text-emerald-400' : 'text-amber-400'">
                    {{ r.predictedDeltaE00.toFixed(2) }}
                  </td>
                  <td class="py-2 px-3 text-slate-400">{{ r.predictedDropletSizeUm.toFixed(2) }} µm</td>
                  <td class="py-2 px-3 text-right font-bold" [ngClass]="r.desirabilityScore > 0.9 ? 'text-amber-300' : 'text-slate-400'">
                    {{ r.desirabilityScore.toFixed(2) }}
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `
})
export class DoeOptimizer {
  readonly state = inject(DigitalTwinStateService);

  readonly doeRuns = signal<DOERun[]>([
    { runId: 1, x1Pigment: 10.0, x2Emulsifier: 2.0, x3Thickener: 1.0, rpm: 400, predictedViscosityCP: 3200, predictedDeltaE00: 1.45, predictedDropletSizeUm: 3.8, desirabilityScore: 0.65 },
    { runId: 2, x1Pigment: 14.0, x2Emulsifier: 2.0, x3Thickener: 1.0, rpm: 450, predictedViscosityCP: 3600, predictedDeltaE00: 0.95, predictedDropletSizeUm: 3.5, desirabilityScore: 0.78 },
    { runId: 3, x1Pigment: 10.0, x2Emulsifier: 4.5, x3Thickener: 1.0, rpm: 500, predictedViscosityCP: 3800, predictedDeltaE00: 1.30, predictedDropletSizeUm: 2.1, desirabilityScore: 0.72 },
    { runId: 4, x1Pigment: 10.0, x2Emulsifier: 2.0, x3Thickener: 2.5, rpm: 450, predictedViscosityCP: 5200, predictedDeltaE00: 1.25, predictedDropletSizeUm: 3.2, desirabilityScore: 0.68 },
    { runId: 5, x1Pigment: 12.0, x2Emulsifier: 3.5, x3Thickener: 1.5, rpm: 600, predictedViscosityCP: 4150, predictedDeltaE00: 0.52, predictedDropletSizeUm: 2.2, desirabilityScore: 0.92 },
    { runId: 6, x1Pigment: 12.8, x2Emulsifier: 3.2, x3Thickener: 1.8, rpm: 650, predictedViscosityCP: 4210, predictedDeltaE00: 0.38, predictedDropletSizeUm: 1.9, desirabilityScore: 0.96 },
    { runId: 7, x1Pigment: 11.5, x2Emulsifier: 4.0, x3Thickener: 2.0, rpm: 700, predictedViscosityCP: 4550, predictedDeltaE00: 0.61, predictedDropletSizeUm: 1.8, desirabilityScore: 0.89 }
  ]);

  getSimplexCoordinates(x1: number, x2: number, x3: number): { x: number; y: number } {
    // Project ternary barycentric coordinates to 2D triangle space:
    // Top (X1): (160, 30)
    // Bottom-Left (X2): (40, 240)
    // Bottom-Right (X3): (280, 240)
    const total = x1 + x2 + x3;
    const w1 = x1 / total;
    const w2 = x2 / total;
    const w3 = x3 / total;

    const x = w1 * 160 + w2 * 40 + w3 * 280;
    const y = w1 * 30 + w2 * 240 + w3 * 240;
    return { x, y };
  }

  applyOptimalPoint() {
    // Apply optimal organoclay & emulsifier
    this.state.updateItemConcentration('ing_disteardimonium_hectorite', 1.8);
    this.state.updateItemConcentration('ing_peg10_dimethicone', 3.2);
    this.state.updateRpm(650);
    this.state.optimizeShadeToTarget();
    this.state.setTab('twin-mixer');
  }
}
