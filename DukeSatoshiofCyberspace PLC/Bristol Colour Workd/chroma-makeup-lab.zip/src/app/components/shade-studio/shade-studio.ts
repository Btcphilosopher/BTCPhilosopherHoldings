import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { DigitalTwinStateService } from '../../core/services/digital-twin-state.service';
import { ColorScienceService } from '../../core/services/color-science.service';
import { StandardIlluminant } from '../../core/models/color-science.model';
import { ColorFromLabPipe } from '../../core/pipes/color-from-lab.pipe';

@Component({
  selector: 'app-shade-studio',
  standalone: true,
  imports: [CommonModule, MatIconModule, FormsModule, ColorFromLabPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto bg-[#07090e] p-6 space-y-6">
      
      <!-- Studio Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <span class="text-[11px] font-mono tracking-wider uppercase text-slate-400">OPTICAL SCIENCE WORKSPACE</span>
          <h1 class="text-xl font-bold text-slate-100 flex items-center gap-3">
            <span>Digital Shade Development & Colorimetry</span>
            <span class="text-xs font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              KUBELKA-MUNK 2-FLUX
            </span>
          </h1>
        </div>

        <div class="flex items-center gap-3">
          <button 
            (click)="runAutoOptimization()"
            [disabled]="isOptimizing()"
            class="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-amber-300 text-slate-950 font-semibold text-xs transition-all hover:brightness-110 shadow-lg flex items-center gap-2">
            <mat-icon class="text-sm">{{ isOptimizing() ? 'sync' : 'auto_fix_high' }}</mat-icon>
            <span>{{ isOptimizing() ? 'Solving Optima...' : 'Auto-Optimize Pigment Loading' }}</span>
          </button>
        </div>
      </div>

      <!-- Main Visual Comparison Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Column 1: Colorimetry & CIEDE2000 Evaluation Card -->
        <div class="p-5 rounded-2xl bg-slate-900/70 border border-slate-800/80 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-4">
              <span class="text-xs font-mono uppercase tracking-wider text-slate-400">CIELAB TRISTIMULUS TARGET</span>
              <span 
                class="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full"
                [ngClass]="state.colorDifferenceDeltaE00().isCommercialMatch ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'">
                {{ state.colorDifferenceDeltaE00().isCommercialMatch ? 'MATCH APPROVED' : 'NEEDS SHIFT' }}
              </span>
            </div>

            <!-- Side-by-side Swatch Compare -->
            <div class="grid grid-cols-2 gap-4 mb-4">
              <!-- Target Swatch Box -->
              <div class="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col items-center text-center">
                <div 
                  class="w-16 h-16 rounded-xl border border-white/20 shadow-lg mb-2"
                  [style.background-color]="state.formulation().targetCIELAB | colorFromLab"></div>
                <div class="text-[11px] font-mono text-slate-400 uppercase">TARGET SHADE</div>
                <div class="text-xs font-mono font-bold text-slate-200 mt-0.5">
                  L*:{{ state.formulation().targetCIELAB.L.toFixed(1) }}
                </div>
                <div class="text-[10px] font-mono text-slate-400">
                  a*:{{ state.formulation().targetCIELAB.a.toFixed(1) }} · b*:{{ state.formulation().targetCIELAB.b.toFixed(1) }}
                </div>
              </div>

              <!-- Predicted Formulation Swatch Box -->
              <div class="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col items-center text-center">
                <div 
                  class="w-16 h-16 rounded-xl border border-white/20 shadow-lg mb-2"
                  [style.background-color]="state.predictedColorHex()"></div>
                <div class="text-[11px] font-mono text-slate-400 uppercase">PREDICTED BULK</div>
                <div class="text-xs font-mono font-bold text-slate-200 mt-0.5">
                  L*:{{ state.predictedCIELAB().L.toFixed(1) }}
                </div>
                <div class="text-[10px] font-mono text-slate-400">
                  a*:{{ state.predictedCIELAB().a.toFixed(1) }} · b*:{{ state.predictedCIELAB().b.toFixed(1) }}
                </div>
              </div>
            </div>

            <!-- CIEDE2000 Numerical Breakdown -->
            <div class="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs font-mono">
              <div class="flex items-center justify-between text-slate-300">
                <span>CIEDE2000 ΔE₀₀ Total:</span>
                <span class="text-lg font-bold" [ngClass]="state.colorDifferenceDeltaE00().deltaE00 <= 1.0 ? 'text-emerald-400' : 'text-amber-400'">
                  {{ state.colorDifferenceDeltaE00().deltaE00.toFixed(2) }}
                </span>
              </div>
              <div class="flex items-center justify-between text-slate-400 text-[11px] pt-1 border-t border-slate-800/80">
                <span>Lightness Shift (ΔL'):</span>
                <span class="text-slate-200 font-bold">{{ state.colorDifferenceDeltaE00().deltaLPrime > 0 ? '+' : '' }}{{ state.colorDifferenceDeltaE00().deltaLPrime.toFixed(2) }}</span>
              </div>
              <div class="flex items-center justify-between text-slate-400 text-[11px]">
                <span>Chroma Shift (ΔC'):</span>
                <span class="text-slate-200 font-bold">{{ state.colorDifferenceDeltaE00().deltaCPrime > 0 ? '+' : '' }}{{ state.colorDifferenceDeltaE00().deltaCPrime.toFixed(2) }}</span>
              </div>
              <div class="flex items-center justify-between text-slate-400 text-[11px]">
                <span>Hue Shift (ΔH'):</span>
                <span class="text-slate-200 font-bold">{{ state.colorDifferenceDeltaE00().deltaHPrime > 0 ? '+' : '' }}{{ state.colorDifferenceDeltaE00().deltaHPrime.toFixed(2) }}</span>
              </div>
            </div>
          </div>

          <!-- Target Slider Controls -->
          <div class="mt-4 pt-3 border-t border-slate-800/80 space-y-2.5">
            <span class="text-[10px] font-mono uppercase text-slate-400 block">MANUAL TARGET ADJUSTMENT</span>
            
            <div class="flex items-center gap-3 text-xs">
              <span class="w-6 font-mono text-slate-400">L*</span>
              <input 
                type="range" min="20" max="95" step="0.5"
                [ngModel]="state.formulation().targetCIELAB.L"
                (ngModelChange)="updateTargetL($event)"
                class="flex-1 accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer" />
              <span class="w-10 font-mono text-slate-200 text-right">{{ state.formulation().targetCIELAB.L.toFixed(1) }}</span>
            </div>

            <div class="flex items-center gap-3 text-xs">
              <span class="w-6 font-mono text-slate-400">a*</span>
              <input 
                type="range" min="-10" max="60" step="0.5"
                [ngModel]="state.formulation().targetCIELAB.a"
                (ngModelChange)="updateTargetA($event)"
                class="flex-1 accent-rose-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer" />
              <span class="w-10 font-mono text-slate-200 text-right">{{ state.formulation().targetCIELAB.a.toFixed(1) }}</span>
            </div>

            <div class="flex items-center gap-3 text-xs">
              <span class="w-6 font-mono text-slate-400">b*</span>
              <input 
                type="range" min="-10" max="60" step="0.5"
                [ngModel]="state.formulation().targetCIELAB.b"
                (ngModelChange)="updateTargetB($event)"
                class="flex-1 accent-amber-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer" />
              <span class="w-10 font-mono text-slate-200 text-right">{{ state.formulation().targetCIELAB.b.toFixed(1) }}</span>
            </div>
          </div>
        </div>

        <!-- Column 2: Spectral Reflectance Curve (400 - 700 nm) -->
        <div class="p-5 rounded-2xl bg-slate-900/70 border border-slate-800/80 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3">
              <span class="text-xs font-mono uppercase tracking-wider text-slate-400">SPECTRAL REFLECTANCE SPECTRUM</span>
              <span class="text-xs font-mono text-slate-400">400 – 700 nm (20nm step)</span>
            </div>

            <!-- SVG Spectral Graph -->
            <div class="relative w-full h-56 bg-slate-950 rounded-xl p-3 border border-slate-800 flex flex-col justify-between">
              <!-- Y-axis labels -->
              <div class="absolute left-2 top-2 text-[10px] font-mono text-slate-500">100%</div>
              <div class="absolute left-2 top-1/2 -translate-y-1/2 text-[10px] font-mono text-slate-500">50%</div>
              <div class="absolute left-2 bottom-6 text-[10px] font-mono text-slate-500">0%</div>

              <svg class="w-full h-44 overflow-visible" viewBox="0 0 300 150" preserveAspectRatio="none">
                <!-- Grid Lines -->
                <line x1="25" y1="15" x2="295" y2="15" stroke="#1e293b" stroke-dasharray="2,2" />
                <line x1="25" y1="75" x2="295" y2="75" stroke="#1e293b" stroke-dasharray="2,2" />
                <line x1="25" y1="135" x2="295" y2="135" stroke="#334155" />

                <!-- Visible Light Spectrum Rainbow Bar at bottom -->
                <defs>
                  <linearGradient id="spectrumGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stop-color="#4c1d95" />
                    <stop offset="20%" stop-color="#2563eb" />
                    <stop offset="40%" stop-color="#059669" />
                    <stop offset="60%" stop-color="#eab308" />
                    <stop offset="80%" stop-color="#ea580c" />
                    <stop offset="100%" stop-color="#dc2626" />
                  </linearGradient>
                </defs>
                <rect x="25" y="138" width="270" height="4" fill="url(#spectrumGradient)" rx="2" />

                <!-- Formula Reflectance Curve (Cyan) -->
                <path 
                  [attr.d]="svgReflectancePath()" 
                  fill="none" 
                  stroke="#38bdf8" 
                  stroke-width="2.5" />
                
                <!-- Data Nodes -->
                @for (pt of spectrumPoints(); track pt.w) {
                  <circle 
                    [attr.cx]="pt.x" 
                    [attr.cy]="pt.y" 
                    r="3" 
                    fill="#38bdf8" 
                    stroke="#07090e" 
                    stroke-width="1.5" />
                }
              </svg>

              <!-- X-axis wavelength ticks -->
              <div class="flex justify-between pl-6 pr-2 text-[9px] font-mono text-slate-500">
                <span>400nm</span>
                <span>460nm</span>
                <span>520nm</span>
                <span>580nm</span>
                <span>640nm</span>
                <span>700nm</span>
              </div>
            </div>

            <!-- Optical Physics Notation Box -->
            <div class="mt-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] font-mono text-slate-400 space-y-1">
              <div class="text-cyan-300 font-semibold">Kubelka-Munk Infinite Layer Equation:</div>
              <div>R_∞(λ) = 1 + (K/S) - √[(K/S)² + 2(K/S)]</div>
              <div class="text-slate-500 text-[10px]">where K = Σ c_i K_i (absorption) and S = Σ c_i S_i (scattering)</div>
            </div>
          </div>

          <!-- Illuminant Multi-Source Preview -->
          <div class="mt-4 pt-3 border-t border-slate-800/80">
            <span class="text-[10px] font-mono uppercase text-slate-400 block mb-2">METAMERISM ILLUMINANT PREVIEW</span>
            <div class="grid grid-cols-4 gap-2">
              @for (illum of colorScience.illuminants; track illum.id) {
                <button 
                  (click)="state.activeIlluminant.set(illum.id)"
                  class="p-2 rounded-xl text-center transition-all border flex flex-col items-center"
                  [ngClass]="state.activeIlluminant() === illum.id ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-200' : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'">
                  <div 
                    class="w-6 h-6 rounded-md border border-white/20 mb-1"
                    [style.background-color]="getIlluminantPreviewHex(illum.id)"></div>
                  <div class="text-[10px] font-bold font-mono">{{ illum.id }}</div>
                  <div class="text-[8px] text-slate-500">{{ illum.colorTemperatureK }}K</div>
                </button>
              }
            </div>
          </div>
        </div>

        <!-- Column 3: Skin Substrate Film & Fitzpatrick Undertone -->
        <div class="p-5 rounded-2xl bg-slate-900/70 border border-slate-800/80 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3">
              <span class="text-xs font-mono uppercase tracking-wider text-slate-400">SUBSTRATE FILM APPEARANCE</span>
              <span class="text-xs font-mono text-cyan-400">Fitzpatrick Scale</span>
            </div>

            <!-- Applied Film Swatch Over Skin Tone -->
            <div class="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center mb-4">
              <div class="relative w-48 h-32 rounded-xl overflow-hidden border border-white/10 shadow-xl">
                <!-- Left half: Bare Skin Substrate -->
                <div 
                  class="absolute inset-y-0 left-0 w-1/2 flex items-end p-2"
                  [style.background-color]="activeSkinTone().hex">
                  <span class="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-black/60 text-white">Bare Skin</span>
                </div>
                <!-- Right half: Applied Cosmetic Film (Beer-Lambert + K/S blend) -->
                <div 
                  class="absolute inset-y-0 right-0 w-1/2 flex items-end p-2"
                  [style.background-color]="state.skinPreview().hex">
                  <span class="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-black/60 text-white">Applied Film</span>
                </div>
                <!-- Center Divider Line -->
                <div class="absolute inset-y-0 left-1/2 w-0.5 bg-white/40 shadow-sm"></div>
              </div>
            </div>

            <!-- Fitzpatrick Type Selector Grid -->
            <div class="space-y-2 mb-4">
              <span class="text-[10px] font-mono uppercase text-slate-400 block">SELECT SUBSTRATE (FITZPATRICK I - VI):</span>
              <div class="grid grid-cols-6 gap-1.5">
                @for (skin of colorScience.fitzpatrickSkinTones; track skin.type) {
                  <button 
                    (click)="state.selectedSkinToneType.set(skin.type)"
                    class="p-1 rounded-lg border text-center transition-all flex flex-col items-center"
                    [ngClass]="state.selectedSkinToneType() === skin.type ? 'border-cyan-400 bg-cyan-950/40 ring-1 ring-cyan-400' : 'border-slate-800 bg-slate-950 hover:border-slate-700'">
                    <div 
                      class="w-5 h-5 rounded border border-black/20 mb-1"
                      [style.background-color]="skin.hex"></div>
                    <span class="text-[10px] font-mono font-bold text-slate-300">{{ skin.type }}</span>
                  </button>
                }
              </div>
              <div class="text-[10px] text-slate-400 font-mono mt-1">
                {{ activeSkinTone().description }} (ITA = {{ activeSkinTone().itaAngleDeg.toFixed(1) }}°)
              </div>
            </div>

            <!-- Film Thickness Slider -->
            <div class="space-y-1.5">
              <div class="flex items-center justify-between text-xs font-mono">
                <span class="text-slate-400">APPLIED FILM THICKNESS</span>
                <span class="font-bold text-slate-200">{{ state.filmThicknessUm() }} µm</span>
              </div>
              <input 
                type="range" min="5" max="50" step="1"
                [ngModel]="state.filmThicknessUm()"
                (ngModelChange)="state.filmThicknessUm.set($event)"
                class="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer" />
              <div class="flex justify-between text-[9px] font-mono text-slate-500">
                <span>Sheer (5µm)</span>
                <span>Standard (25µm)</span>
                <span>Full Mask (50µm)</span>
              </div>
            </div>
          </div>

          <!-- Pigment Fine-Tuning Deck -->
          <div class="mt-4 pt-3 border-t border-slate-800/80 space-y-2">
            <span class="text-[10px] font-mono uppercase text-slate-400 block">PIGMENT CONCENTRATIONS IN FORMULA</span>
            <div class="space-y-1.5 text-xs font-mono">
              @for (item of pigmentItems(); track item.ingredientId) {
                <div class="flex items-center justify-between bg-slate-950 p-2 rounded-lg border border-slate-800/80">
                  <div class="flex items-center gap-2">
                    <div 
                      class="w-3 h-3 rounded-full border border-white/20"
                      [style.background-color]="getPigmentHex(item.ingredientId)"></div>
                    <span class="text-slate-200 text-[11px]">{{ getPigmentName(item.ingredientId) }}</span>
                  </div>
                  <div class="flex items-center gap-1.5">
                    <input 
                      type="number" step="0.05" min="0" max="30"
                      [ngModel]="item.concentrationPercent"
                      (ngModelChange)="state.updateItemConcentration(item.ingredientId, $event)"
                      class="w-14 bg-slate-900 border border-slate-700 text-slate-100 rounded px-1.5 py-0.5 text-right text-xs" />
                    <span class="text-slate-500">%</span>
                  </div>
                </div>
              }
            </div>
          </div>

        </div>

      </div>

    </div>
  `
})
export class ShadeStudio {
  readonly state = inject(DigitalTwinStateService);
  readonly colorScience = inject(ColorScienceService);

  readonly isOptimizing = signal<boolean>(false);

  readonly activeSkinTone = computed(() => {
    return this.colorScience.fitzpatrickSkinTones.find(s => s.type === this.state.selectedSkinToneType()) || this.colorScience.fitzpatrickSkinTones[2];
  });

  readonly pigmentItems = computed(() => {
    return this.state.formulation().items.filter(i => i.phase === 'C');
  });

  readonly spectrumPoints = computed(() => {
    const reflectance = this.state.spectralReflectance().reflectance;
    const wavelengths = this.state.spectralReflectance().wavelengths;
    const points: { w: number; r: number; x: number; y: number }[] = [];

    const xStart = 25;
    const xEnd = 295;
    const yBottom = 135;
    const yTop = 15;

    for (let i = 0; i < wavelengths.length; i++) {
      const w = wavelengths[i];
      const r = reflectance[i];
      const x = xStart + (i / (wavelengths.length - 1)) * (xEnd - xStart);
      const y = yBottom - r * (yBottom - yTop);
      points.push({ w, r, x, y });
    }
    return points;
  });

  readonly svgReflectancePath = computed<string>(() => {
    const pts = this.spectrumPoints();
    if (pts.length === 0) return '';
    let d = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 1; i < pts.length; i++) {
      d += ` L ${pts[i].x} ${pts[i].y}`;
    }
    return d;
  });

  updateTargetL(val: number) {
    this.state.formulation.update(f => ({
      ...f,
      targetCIELAB: { ...f.targetCIELAB, L: val }
    }));
  }

  updateTargetA(val: number) {
    this.state.formulation.update(f => ({
      ...f,
      targetCIELAB: { ...f.targetCIELAB, a: val }
    }));
  }

  updateTargetB(val: number) {
    this.state.formulation.update(f => ({
      ...f,
      targetCIELAB: { ...f.targetCIELAB, b: val }
    }));
  }

  getIlluminantPreviewHex(illum: StandardIlluminant): string {
    const spec = this.state.spectralReflectance();
    const xyz = this.colorScience.spectralToXYZ(spec.reflectance, illum);
    const lab = this.colorScience.xyzToLab(xyz, illum);
    return this.colorScience.labToHex(lab);
  }

  getPigmentName(id: string): string {
    switch (id) {
      case 'ing_tio2_rutile': return 'Titanium Dioxide';
      case 'ing_fe_yellow': return 'Yellow Iron Oxide';
      case 'ing_fe_red': return 'Red Iron Oxide';
      case 'ing_fe_black': return 'Black Iron Oxide';
      case 'ing_ultramarine_blue': return 'Ultramarine Blue';
      case 'ing_red_7_lake': return 'Red 7 Calcium Lake';
      case 'ing_mica_sericite': return 'Sericite Mica';
      default: return id;
    }
  }

  getPigmentHex(id: string): string {
    switch (id) {
      case 'ing_tio2_rutile': return '#FFFFFF';
      case 'ing_fe_yellow': return '#E2A93B';
      case 'ing_fe_red': return '#A8322D';
      case 'ing_fe_black': return '#222326';
      case 'ing_ultramarine_blue': return '#2E4C9D';
      case 'ing_red_7_lake': return '#C91D3E';
      case 'ing_mica_sericite': return '#F6F6F4';
      default: return '#CCCCCC';
    }
  }

  runAutoOptimization() {
    this.isOptimizing.set(true);
    setTimeout(() => {
      this.state.optimizeShadeToTarget();
      this.isOptimizing.set(false);
    }, 600);
  }
}
