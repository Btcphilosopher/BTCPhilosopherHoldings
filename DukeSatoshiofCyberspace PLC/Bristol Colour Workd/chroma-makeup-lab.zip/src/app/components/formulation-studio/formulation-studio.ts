import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { DigitalTwinStateService } from '../../core/services/digital-twin-state.service';
import { IngredientDatabaseService } from '../../core/services/ingredient-database.service';
import { Ingredient, IngredientPhase } from '../../core/models/formulation.model';

@Component({
  selector: 'app-formulation-studio',
  standalone: true,
  imports: [CommonModule, MatIconModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col lg:flex-row bg-[#080a10] overflow-hidden">
      
      <!-- Left Panel: Raw Material Inventory Palette (340px) -->
      <div class="w-full lg:w-[340px] border-r border-slate-800/80 bg-slate-950/80 flex flex-col shrink-0">
        <!-- Palette Header & Search -->
        <div class="p-3.5 border-b border-slate-800/80 space-y-2.5">
          <div class="flex items-center justify-between">
            <span class="text-[11px] font-mono tracking-wider uppercase text-slate-400">INGREDIENT INVENTORY</span>
            <span class="text-xs font-mono text-cyan-400">{{ filteredIngredients().length }} Available</span>
          </div>

          <div class="relative">
            <mat-icon class="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm">search</mat-icon>
            <input 
              type="text" 
              placeholder="Search INCI, pigment, wax, polymer..."
              [ngModel]="searchQuery()" 
              (ngModelChange)="searchQuery.set($event)"
              class="w-full pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 font-sans outline-none focus:ring-1 focus:ring-cyan-500" />
          </div>

          <!-- Category Filter Pills -->
          <div class="flex items-center gap-1 overflow-x-auto pb-1 text-[11px] font-mono">
            <button 
              (click)="selectedCategoryFilter.set('all')"
              class="px-2 py-0.5 rounded-md transition-colors shrink-0"
              [ngClass]="selectedCategoryFilter() === 'all' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200 bg-slate-900'">
              All
            </button>
            <button 
              (click)="selectedCategoryFilter.set('pigment')"
              class="px-2 py-0.5 rounded-md transition-colors shrink-0"
              [ngClass]="selectedCategoryFilter() === 'pigment' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' : 'text-slate-400 hover:text-slate-200 bg-slate-900'">
              Pigments
            </button>
            <button 
              (click)="selectedCategoryFilter.set('emollient')"
              class="px-2 py-0.5 rounded-md transition-colors shrink-0"
              [ngClass]="selectedCategoryFilter() === 'emollient' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400 hover:text-slate-200 bg-slate-900'">
              Oils/Esters
            </button>
            <button 
              (click)="selectedCategoryFilter.set('wax')"
              class="px-2 py-0.5 rounded-md transition-colors shrink-0"
              [ngClass]="selectedCategoryFilter() === 'wax' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400 hover:text-slate-200 bg-slate-900'">
              Waxes
            </button>
            <button 
              (click)="selectedCategoryFilter.set('thickener')"
              class="px-2 py-0.5 rounded-md transition-colors shrink-0"
              [ngClass]="selectedCategoryFilter() === 'thickener' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'text-slate-400 hover:text-slate-200 bg-slate-900'">
              Thickeners
            </button>
          </div>
        </div>

        <!-- Inventory List -->
        <div class="flex-1 overflow-y-auto p-2.5 space-y-2">
          @for (ing of filteredIngredients(); track ing.id) {
            <div class="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition-all flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between mb-1">
                  <span class="text-[10px] font-mono font-semibold px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                    Phase {{ ing.defaultPhase }}
                  </span>
                  <span class="text-[10px] font-mono text-slate-400">
                    \${{ ing.costPerKgUSD.toFixed(2) }}/kg
                  </span>
                </div>
                <div class="text-xs font-semibold text-slate-200 leading-snug">{{ ing.inciName }}</div>
                <div class="text-[10px] text-slate-400 font-mono">{{ ing.tradeName }} · {{ ing.supplier }}</div>
                
                @if (ing.opticalData) {
                  <div class="flex items-center gap-1.5 mt-1.5">
                    <div 
                      class="w-3.5 h-3.5 rounded-full border border-white/20 shrink-0" 
                      [style.background-color]="ing.opticalData.baseColorHex"></div>
                    <span class="text-[10px] text-slate-400 font-mono">
                      n={{ ing.opticalData.refractiveIndex }} · {{ ing.opticalData.primaryParticleSizeNm }}nm
                    </span>
                  </div>
                }
              </div>

              <div class="mt-2.5 pt-2 border-t border-slate-800/60 flex items-center justify-between">
                <span class="text-[10px] font-mono text-slate-500">{{ ing.sustainabilityOrigin }}</span>
                <button 
                  (click)="state.addIngredientToFormulation(ing.id)"
                  [disabled]="isAlreadyInFormula(ing.id)"
                  class="px-2.5 py-1 text-[11px] font-medium rounded-lg transition-colors flex items-center gap-1"
                  [ngClass]="isAlreadyInFormula(ing.id) ? 'bg-slate-800 text-slate-500 cursor-not-allowed' : 'bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/30'">
                  <mat-icon class="text-xs">{{ isAlreadyInFormula(ing.id) ? 'done' : 'add' }}</mat-icon>
                  <span>{{ isAlreadyInFormula(ing.id) ? 'Added' : 'Add to Recipe' }}</span>
                </button>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Main Panel: Recipe Formula Table & Batch Metrics -->
      <div class="flex-1 flex flex-col overflow-hidden">
        
        <!-- Recipe Header Bar -->
        <div class="p-4 border-b border-slate-800/80 bg-slate-950/60 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div class="flex items-center gap-2">
              <h1 class="text-lg font-bold text-slate-100">{{ state.formulation().name }}</h1>
              <span class="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                v{{ state.formulation().version }}
              </span>
              <span class="text-xs font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {{ state.formulation().status }}
              </span>
            </div>
            <p class="text-xs text-slate-400 mt-0.5 max-w-2xl">{{ state.formulation().description }}</p>
          </div>

          <!-- Batch Size & Total Mass % -->
          <div class="flex items-center gap-4">
            <div class="text-right">
              <span class="text-[10px] font-mono uppercase text-slate-400">BATCH SIZE</span>
              <div class="text-sm font-mono font-bold text-slate-200">
                {{ state.formulation().batchSizeKg.toFixed(2) }} kg
              </div>
            </div>

            <div class="text-right">
              <span class="text-[10px] font-mono uppercase text-slate-400">MASS BALANCE</span>
              <div 
                class="text-base font-mono font-bold flex items-center gap-1 justify-end"
                [ngClass]="isBalanced() ? 'text-emerald-400' : 'text-amber-400'">
                <span>{{ state.totalConcentrationPercent().toFixed(2) }}%</span>
                @if (isBalanced()) {
                  <mat-icon class="text-sm text-emerald-400">check_circle</mat-icon>
                }
              </div>
            </div>

            @if (!isBalanced()) {
              <button 
                (click)="state.normalizeFormulationTo100()"
                class="px-3 py-1.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 text-xs font-mono font-medium flex items-center gap-1.5 shadow-sm">
                <mat-icon class="text-sm">balance</mat-icon>
                <span>Normalize 100%</span>
              </button>
            }
          </div>
        </div>

        <!-- Recipe Items Table -->
        <div class="flex-1 overflow-y-auto p-4">
          <div class="border border-slate-800 rounded-xl overflow-hidden bg-slate-900/50">
            <table class="w-full text-left border-collapse">
              <thead>
                <tr class="border-b border-slate-800 bg-slate-950/80 text-[10px] font-mono uppercase text-slate-400">
                  <th class="py-2.5 px-3">Phase</th>
                  <th class="py-2.5 px-3">Ingredient INCI</th>
                  <th class="py-2.5 px-3">Trade Name & Function</th>
                  <th class="py-2.5 px-4 w-64">Concentration (% w/w)</th>
                  <th class="py-2.5 px-3">Batch Mass</th>
                  <th class="py-2.5 px-3">Cost ($)</th>
                  <th class="py-2.5 px-2 text-right"></th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60 text-xs">
                @for (item of state.formulation().items; track item.ingredientId) {
                  @let ing = getIngredient(item.ingredientId);
                  <tr class="hover:bg-slate-800/30 transition-colors">
                    <!-- Phase Badge -->
                    <td class="py-2.5 px-3 font-mono font-bold" [ngClass]="getPhaseColor(item.phase)">
                      Phase {{ item.phase }}
                    </td>

                    <!-- INCI Name -->
                    <td class="py-2.5 px-3">
                      <div class="font-semibold text-slate-200">{{ ing?.inciName }}</div>
                      <div class="text-[10px] font-mono text-slate-400">{{ ing?.lotNumber }}</div>
                    </td>

                    <!-- Trade Name & Function -->
                    <td class="py-2.5 px-3 text-slate-300">
                      <div>{{ ing?.tradeName }}</div>
                      <div class="text-[10px] font-mono text-cyan-400 uppercase">{{ ing?.category }}</div>
                    </td>

                    <!-- Concentration Slider + Numeric Input -->
                    <td class="py-2.5 px-4">
                      <div class="flex items-center gap-2">
                        <input 
                          type="range" 
                          min="0" 
                          max="60" 
                          step="0.05"
                          [ngModel]="item.concentrationPercent" 
                          (ngModelChange)="state.updateItemConcentration(item.ingredientId, $event)"
                          class="flex-1 accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer" />
                        <input 
                          type="number" 
                          step="0.05"
                          min="0"
                          max="100"
                          [ngModel]="item.concentrationPercent" 
                          (ngModelChange)="state.updateItemConcentration(item.ingredientId, $event)"
                          class="w-16 bg-slate-950 border border-slate-700 text-slate-100 rounded px-1.5 py-0.5 font-mono text-xs text-right outline-none focus:border-cyan-500" />
                        <span class="text-slate-400 font-mono text-[10px]">%</span>
                      </div>
                    </td>

                    <!-- Batch Mass (g/kg) -->
                    <td class="py-2.5 px-3 font-mono text-slate-300">
                      {{ ((state.formulation().batchSizeKg * item.concentrationPercent) / 100 * 1000).toFixed(1) }} g
                    </td>

                    <!-- Cost Contribution -->
                    <td class="py-2.5 px-3 font-mono text-slate-300">
                      \${{ (((state.formulation().batchSizeKg * item.concentrationPercent) / 100) * (ing?.costPerKgUSD || 0)).toFixed(2) }}
                    </td>

                    <!-- Remove -->
                    <td class="py-2.5 px-2 text-right">
                      <button 
                        (click)="state.removeIngredientFromFormulation(item.ingredientId)"
                        class="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                        title="Remove Ingredient">
                        <mat-icon class="text-base">close</mat-icon>
                      </button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>

          <!-- Regulatory Warnings Panel -->
          @if (state.regulatoryWarnings().length > 0) {
            <div class="mt-4 p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/40 text-amber-200">
              <div class="flex items-center gap-2 mb-2 font-mono text-xs font-semibold text-amber-300">
                <mat-icon class="text-sm">gavel</mat-icon>
                <span>REGULATORY COMPLIANCE NOTIFICATIONS (EU 1223/2009 & FDA)</span>
              </div>
              <div class="space-y-1.5">
                @for (warn of state.regulatoryWarnings(); track warn.ingredientName) {
                  <div class="text-xs flex items-baseline gap-2">
                    <span class="font-bold text-amber-100">{{ warn.ingredientName }}:</span>
                    <span>{{ warn.issue }}</span>
                    <span class="text-[10px] font-mono text-amber-400 ml-auto">{{ warn.rule }}</span>
                  </div>
                }
              </div>
            </div>
          }
        </div>

        <!-- Recipe Footer Summary Strip -->
        <div class="p-3 border-t border-slate-800/80 bg-slate-950 flex items-center justify-between text-xs font-mono text-slate-400">
          <div class="flex items-center gap-6">
            <div>
              <span>BATCH COST:</span>
              <span class="text-slate-100 font-bold ml-1.5">\${{ state.batchCostUSD().toFixed(2) }}</span>
            </div>
            <div>
              <span>COST / KG:</span>
              <span class="text-slate-100 font-bold ml-1.5">\${{ state.costPerKgUSD().toFixed(2) }}/kg</span>
            </div>
            <div>
              <span>EST. RETAIL UNIT (30ml):</span>
              <span class="text-cyan-300 font-bold ml-1.5">\${{ (state.costPerKgUSD() * 0.030).toFixed(2) }} bulk</span>
            </div>
          </div>

          <div class="flex items-center gap-3">
            <button 
              (click)="state.setTab('shade-studio')"
              class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors flex items-center gap-1.5">
              <mat-icon class="text-sm text-cyan-400">palette</mat-icon>
              <span>Shade Matching Studio &rarr;</span>
            </button>
          </div>
        </div>

      </div>

    </div>
  `
})
export class FormulationStudio {
  readonly state = inject(DigitalTwinStateService);
  readonly db = inject(IngredientDatabaseService);

  readonly searchQuery = signal<string>('');
  readonly selectedCategoryFilter = signal<string>('all');

  readonly filteredIngredients = computed(() => {
    let list = this.db.getAllIngredients();
    const cat = this.selectedCategoryFilter();
    if (cat !== 'all') {
      list = list.filter(i => i.category === cat);
    }
    const q = this.searchQuery().toLowerCase().trim();
    if (q) {
      list = list.filter(i => 
        i.inciName.toLowerCase().includes(q) ||
        i.tradeName.toLowerCase().includes(q) ||
        i.supplier.toLowerCase().includes(q)
      );
    }
    return list;
  });

  isAlreadyInFormula(ingId: string): boolean {
    return this.state.formulation().items.some(i => i.ingredientId === ingId);
  }

  isBalanced(): boolean {
    return Math.abs(this.state.totalConcentrationPercent() - 100.0) < 0.05;
  }

  getIngredient(id: string): Ingredient | undefined {
    return this.db.getIngredientById(id);
  }

  getPhaseColor(phase: IngredientPhase): string {
    switch (phase) {
      case 'A': return 'text-cyan-400';
      case 'B': return 'text-amber-400';
      case 'C': return 'text-rose-400';
      case 'D': return 'text-emerald-400';
    }
  }
}
