import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinStateService } from '../../core/services/digital-twin-state.service';
import { MixingPhysicsService } from '../../core/services/mixing-physics.service';
import { ImpellerType } from '../../core/models/mixing-physics.model';
import { ColorFromLabPipe } from '../../core/pipes/color-from-lab.pipe';

@Component({
  selector: 'app-telemetry-hud',
  standalone: true,
  imports: [CommonModule, MatIconModule, ColorFromLabPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950/70 border-l border-slate-800/80 p-4 overflow-y-auto">
      
      <!-- Panel Header -->
      <div class="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-4">
        <div>
          <span class="text-[11px] font-mono tracking-wider uppercase text-slate-400">TELEMETRY STREAM</span>
          <h2 class="text-base font-semibold text-slate-100 flex items-center gap-2">
            <span>Dynamic Process Physics</span>
            <span class="text-xs font-mono text-cyan-400 font-normal">TIER-1</span>
          </h2>
        </div>
        <div class="text-right">
          <span class="text-[10px] font-mono uppercase text-slate-500">CONFIDENCE</span>
          <div class="text-xs font-mono font-bold text-emerald-400">
            {{ state.telemetry().simulationConfidencePercent.toFixed(1) }}%
          </div>
        </div>
      </div>

      <!-- Color Match & CIEDE2000 Spotlight -->
      <div class="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 mb-4">
        <div class="flex items-center justify-between mb-2">
          <span class="text-[10px] font-mono uppercase tracking-wider text-slate-400">COLOUR MATCH STATUS</span>
          <span 
            class="text-[11px] font-mono px-2 py-0.5 rounded-md font-semibold"
            [ngClass]="state.colorDifferenceDeltaE00().isCommercialMatch ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'">
            {{ state.colorDifferenceDeltaE00().isCommercialMatch ? 'PASS (ΔE₀₀ < 1.0)' : 'IN PROGRESS' }}
          </span>
        </div>

        <div class="grid grid-cols-2 gap-2 mb-2">
          <!-- Target Swatch -->
          <div class="p-2 rounded-lg bg-slate-950 border border-slate-800 flex items-center gap-2.5">
            <div 
              class="w-7 h-7 rounded-md border border-white/20 shadow-inner shrink-0"
              [style.background-color]="state.formulation().targetCIELAB | json | colorFromLab"></div>
            <div>
              <div class="text-[10px] text-slate-400 font-mono">TARGET SHADE</div>
              <div class="text-xs font-mono font-medium text-slate-200">
                L:{{ state.formulation().targetCIELAB.L.toFixed(1) }} a:{{ state.formulation().targetCIELAB.a.toFixed(1) }} b:{{ state.formulation().targetCIELAB.b.toFixed(1) }}
              </div>
            </div>
          </div>

          <!-- Current Batch Swatch -->
          <div class="p-2 rounded-lg bg-slate-950 border border-slate-800 flex items-center gap-2.5">
            <div 
              class="w-7 h-7 rounded-md border border-white/20 shadow-inner shrink-0"
              [style.background-color]="state.transientMixtureColorHex()"></div>
            <div>
              <div class="text-[10px] text-slate-400 font-mono">BATCH MIX</div>
              <div class="text-xs font-mono font-medium text-slate-200">
                L:{{ state.predictedCIELAB().L.toFixed(1) }} a:{{ state.predictedCIELAB().a.toFixed(1) }} b:{{ state.predictedCIELAB().b.toFixed(1) }}
              </div>
            </div>
          </div>
        </div>

        <div class="flex items-center justify-between pt-1 border-t border-slate-800/80 text-xs font-mono">
          <span class="text-slate-400">CIEDE2000 ΔE₀₀:</span>
          <span class="font-bold text-base" [ngClass]="state.colorDifferenceDeltaE00().deltaE00 <= 1.0 ? 'text-emerald-400' : 'text-amber-400'">
            {{ state.colorDifferenceDeltaE00().deltaE00.toFixed(2) }}
          </span>
        </div>
      </div>

      <!-- Key Hydrodynamic & Mixing Telemetry Grid -->
      <div class="grid grid-cols-2 gap-2.5 mb-4">
        <!-- Power W -->
        <div class="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400">SHAFT POWER</div>
          <div class="text-xl font-mono font-bold text-slate-100 flex items-baseline">
            <span>{{ state.telemetry().mixingPowerWatts.toFixed(1) }}</span>
            <span class="text-[10px] font-mono text-slate-400 uppercase ml-1">W</span>
          </div>
          <div class="text-[10px] font-mono text-slate-500">P = Np·ρ·N³·D⁵</div>
        </div>

        <!-- Torque N·m -->
        <div class="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400">SHAFT TORQUE</div>
          <div class="text-xl font-mono font-bold text-slate-100 flex items-baseline">
            <span>{{ state.telemetry().torqueNewtonMeters.toFixed(2) }}</span>
            <span class="text-[10px] font-mono text-slate-400 uppercase ml-1">N·m</span>
          </div>
          <div class="text-[10px] font-mono text-slate-500">T = P / (2πN)</div>
        </div>

        <!-- Reynolds Number Re -->
        <div class="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400">REYNOLDS RE</div>
          <div class="text-xl font-mono font-bold flex items-baseline" [ngClass]="state.telemetry().reynoldsNumber > 4000 ? 'text-cyan-300' : (state.telemetry().reynoldsNumber < 20 ? 'text-amber-400' : 'text-slate-100')">
            <span>{{ state.telemetry().reynoldsNumber }}</span>
          </div>
          <div class="text-[10px] font-mono uppercase" [ngClass]="state.telemetry().reynoldsNumber > 4000 ? 'text-cyan-400' : (state.telemetry().reynoldsNumber < 20 ? 'text-amber-400' : 'text-slate-400')">
            {{ state.telemetry().flowRegime }}
          </div>
        </div>

        <!-- Tip Speed -->
        <div class="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400">TIP SPEED v_tip</div>
          <div class="text-xl font-mono font-bold text-slate-100 flex items-baseline">
            <span>{{ state.telemetry().tipSpeedMPerS.toFixed(2) }}</span>
            <span class="text-[10px] font-mono text-slate-400 uppercase ml-1">m/s</span>
          </div>
          <div class="text-[10px] font-mono text-slate-500">π·N·D</div>
        </div>

        <!-- Apparent Viscosity -->
        <div class="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400">APPARENT VISCOSITY</div>
          <div class="text-xl font-mono font-bold text-slate-100 flex items-baseline">
            <span>{{ state.telemetry().apparentViscosityCP.toLocaleString() }}</span>
            <span class="text-[10px] font-mono text-slate-400 uppercase ml-1">cP</span>
          </div>
          <div class="text-[10px] font-mono text-slate-500">at {{ state.telemetry().shearRatePerS.toFixed(1) }} s⁻¹</div>
        </div>

        <!-- Batch Temperature -->
        <div class="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400">BATCH TEMP</div>
          <div class="text-xl font-mono font-bold text-amber-300 flex items-baseline">
            <span>{{ state.telemetry().batchTemperatureC.toFixed(1) }}</span>
            <span class="text-[10px] font-mono text-amber-400 uppercase ml-1">°C</span>
          </div>
          <div class="text-[10px] font-mono text-slate-400">
            Jacket: {{ state.jacketTempC() }}°C
          </div>
        </div>
      </div>

      <!-- Dispersion & Homogeneity Progress Bars -->
      <div class="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 mb-4 space-y-3">
        <!-- Homogeneity Index -->
        <div>
          <div class="flex items-center justify-between text-xs font-mono mb-1">
            <span class="text-slate-400">HOMOGENEITY INDEX</span>
            <span class="font-bold text-cyan-300">{{ state.telemetry().homogeneityIndexPercent.toFixed(1) }}%</span>
          </div>
          <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div 
              class="h-full bg-cyan-400 transition-all duration-300 rounded-full"
              [style.width.%]="state.telemetry().homogeneityIndexPercent"></div>
          </div>
          <div class="text-[10px] text-slate-500 font-mono mt-1">
            θ₉₅ Theoretical: {{ state.telemetry().theoreticalMixingTime95Sec }}s
          </div>
        </div>

        <!-- Pigment Dispersion -->
        <div>
          <div class="flex items-center justify-between text-xs font-mono mb-1">
            <span class="text-slate-400">PIGMENT DISPERSION</span>
            <span class="font-bold text-rose-300">{{ state.telemetry().pigmentDispersionPercent.toFixed(1) }}%</span>
          </div>
          <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div 
              class="h-full bg-gradient-to-r from-amber-400 to-rose-400 transition-all duration-300 rounded-full"
              [style.width.%]="state.telemetry().pigmentDispersionPercent"></div>
          </div>
          <div class="text-[10px] text-slate-500 font-mono mt-1">
            Shear Rate: {{ state.telemetry().shearRatePerS.toFixed(0) }} s⁻¹ (Metzner-Otto k_s={{ mixingPhysics.getMetznerOttoConstant(state.impellerType()) }})
          </div>
        </div>
      </div>

      <!-- Equipment Quick Tuning Controls -->
      <div class="p-3 rounded-xl bg-slate-900/40 border border-slate-800 text-xs space-y-3 mt-auto">
        <span class="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">VESSEL & IMPELLER SETUP</span>
        
        <!-- Impeller Select -->
        <div>
          <span class="text-[11px] text-slate-400 block mb-1">Agitation Tooling</span>
          <select 
            [value]="state.impellerType()" 
            (change)="onImpellerChange($event)"
            class="w-full bg-slate-800 border border-slate-700 text-slate-200 rounded-lg p-1.5 font-mono text-xs focus:ring-1 focus:ring-cyan-500 outline-none">
            <option value="rushton-turbine">Rushton Disc Turbine (High Shear)</option>
            <option value="pitched-blade">45° Pitched Blade Turbine (Circulation)</option>
            <option value="marine-propeller">Marine Propeller (Axial Pumping)</option>
            <option value="anchor">Anchor Impeller with Wall Scrapers</option>
            <option value="high-shear-rotor-stator">Rotor-Stator Homogenizer</option>
            <option value="powder-tumble">V-Blender Powder Tumble</option>
          </select>
        </div>

        <!-- Jacket Temperature Stepper -->
        <div>
          <div class="flex items-center justify-between mb-1">
            <span class="text-[11px] text-slate-400">Heating/Cooling Jacket</span>
            <span class="font-mono text-amber-300">{{ state.jacketTempC() }} °C</span>
          </div>
          <div class="flex items-center gap-2">
            <button 
              (click)="state.setJacketTemperature(state.jacketTempC() - 5)"
              class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md font-mono">-5°</button>
            <input 
              type="range" 
              min="15" 
              max="90" 
              [value]="state.jacketTempC()"
              (input)="onJacketSlider($event)"
              class="flex-1 accent-amber-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer" />
            <button 
              (click)="state.setJacketTemperature(state.jacketTempC() + 5)"
              class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md font-mono">+5°</button>
          </div>
        </div>

      </div>

    </div>
  `
})
export class TelemetryHud {
  readonly state = inject(DigitalTwinStateService);
  readonly mixingPhysics = inject(MixingPhysicsService);

  onImpellerChange(e: Event) {
    const val = (e.target as HTMLSelectElement).value as ImpellerType;
    this.state.setImpeller(val);
  }

  onJacketSlider(e: Event) {
    const val = parseFloat((e.target as HTMLInputElement).value);
    this.state.setJacketTemperature(val);
  }
}
