import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinStateService } from '../../core/services/digital-twin-state.service';

@Component({
  selector: 'app-quality-spc',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto bg-[#07090e] p-6 space-y-6">
      
      <!-- Quality Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <span class="text-[11px] font-mono tracking-wider uppercase text-slate-400">QUALITY ASSURANCE & SPC</span>
          <h1 class="text-xl font-bold text-slate-100 flex items-center gap-3">
            <span>Statistical Process Control & Stability Laboratory</span>
            <span class="text-xs font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Cpk = {{ cpkIndex().toFixed(2) }} (CAPABLE)
            </span>
          </h1>
        </div>

        <button 
          (click)="recordSample()"
          class="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-400 to-cyan-400 text-slate-950 font-semibold text-xs transition-all hover:brightness-110 shadow-lg flex items-center gap-2">
          <mat-icon class="text-sm">verified</mat-icon>
          <span>Record Live QC Sample</span>
        </button>
      </div>

      <!-- Capability & Statistical Metrics Top Cards -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <!-- Cpk Capability -->
        <div class="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
          <div class="text-[10px] font-mono text-slate-400 uppercase tracking-wider">PROCESS CAPABILITY Cpk</div>
          <div class="text-2xl font-mono font-bold text-emerald-300 mt-1">
            {{ cpkIndex().toFixed(2) }}
          </div>
          <div class="text-xs font-mono text-slate-400 mt-1">
            Cpk > 1.33 = High Six Sigma Reliability
          </div>
        </div>

        <!-- Mean ΔE00 -->
        <div class="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
          <div class="text-[10px] font-mono text-slate-400 uppercase tracking-wider">MEAN COLOUR SHIFT ΔE₀₀</div>
          <div class="text-2xl font-mono font-bold text-slate-100 mt-1">
            {{ meanDeltaE().toFixed(2) }}
          </div>
          <div class="text-xs font-mono text-emerald-400 mt-1">
            Spec Limit: USL = 1.00
          </div>
        </div>

        <!-- Mean Viscosity -->
        <div class="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
          <div class="text-[10px] font-mono text-slate-400 uppercase tracking-wider">MEAN VISCOSITY</div>
          <div class="text-2xl font-mono font-bold text-cyan-300 mt-1 flex items-baseline">
            <span>{{ Math.round(meanViscosity()) }}</span>
            <span class="text-xs font-mono text-slate-400 ml-1.5 uppercase">cP</span>
          </div>
          <div class="text-xs font-mono text-slate-400 mt-1">
            Target: {{ state.formulation().targetViscosityCP }} cP (±10%)
          </div>
        </div>

        <!-- Microbiological & Release Status -->
        <div class="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
          <div class="text-[10px] font-mono text-slate-400 uppercase tracking-wider">MICROBIAL STATUS</div>
          <div class="text-lg font-mono font-bold text-emerald-300 mt-1 flex items-center gap-1.5">
            <mat-icon class="text-base text-emerald-400">check_circle</mat-icon>
            <span>&lt; 10 CFU/g PASS</span>
          </div>
          <div class="text-xs font-mono text-slate-400 mt-1">
            ISO 11930 / USP &lt;51&gt; Challenge Validated
          </div>
        </div>
      </div>

      <!-- Shewhart Control Chart (X-bar Chart) -->
      <div class="p-5 rounded-2xl bg-slate-900/70 border border-slate-800/80 space-y-4">
        <div class="flex items-center justify-between">
          <div>
            <span class="text-xs font-mono uppercase tracking-wider text-slate-400">SHEWHART INDIVIDUALS (X-BAR) CONTROL CHART</span>
            <h2 class="text-base font-bold text-slate-100">Viscosity Trend & Upper/Lower Specification Limits</h2>
          </div>
          <div class="flex items-center gap-4 text-xs font-mono">
            <span class="text-rose-400 font-bold">USL: 4,600 cP</span>
            <span class="text-slate-400">Target: 4,200 cP</span>
            <span class="text-rose-400 font-bold">LSL: 3,800 cP</span>
          </div>
        </div>

        <!-- SVG Control Chart -->
        <div class="w-full h-64 bg-slate-950 rounded-xl p-4 border border-slate-800 relative">
          <svg class="w-full h-full overflow-visible" viewBox="0 0 500 180" preserveAspectRatio="none">
            <!-- USL Red Line -->
            <line x1="40" y1="25" x2="480" y2="25" stroke="#f43f5e" stroke-dasharray="3,3" stroke-width="1.5" />
            <text x="485" y="28" fill="#f43f5e" font-size="9" font-family="monospace">USL</text>

            <!-- UCL Cyan Line -->
            <line x1="40" y1="45" x2="480" y2="45" stroke="#38bdf8" stroke-dasharray="2,2" stroke-width="1" />
            <text x="485" y="48" fill="#38bdf8" font-size="9" font-family="monospace">UCL (+3σ)</text>

            <!-- Target Centerline (CL) -->
            <line x1="40" y1="90" x2="480" y2="90" stroke="#94a3b8" stroke-width="1.5" />
            <text x="485" y="93" fill="#94a3b8" font-size="9" font-family="monospace">CL</text>

            <!-- LCL Cyan Line -->
            <line x1="40" y1="135" x2="480" y2="135" stroke="#38bdf8" stroke-dasharray="2,2" stroke-width="1" />
            <text x="485" y="138" fill="#38bdf8" font-size="9" font-family="monospace">LCL (-3σ)</text>

            <!-- LSL Red Line -->
            <line x1="40" y1="155" x2="480" y2="155" stroke="#f43f5e" stroke-dasharray="3,3" stroke-width="1.5" />
            <text x="485" y="158" fill="#f43f5e" font-size="9" font-family="monospace">LSL</text>

            <!-- Data Points & Connecting Line -->
            <path [attr.d]="spcViscosityPath()" fill="none" stroke="#22d3ee" stroke-width="2.5" />

            @for (pt of spcPoints(); track pt.batch) {
              <circle [attr.cx]="pt.x" [attr.cy]="pt.y" r="4.5" fill="#22d3ee" stroke="#07090e" stroke-width="2" />
              <text [attr.x]="pt.x - 18" [attr.y]="pt.y - 10" fill="#cbd5e1" font-size="9" font-family="monospace">
                {{ pt.val }}
              </text>
            }
          </svg>
        </div>

        <div class="flex justify-between px-10 text-[10px] font-mono text-slate-500">
          @for (b of state.spcBatches(); track b.batchNumber) {
            <span>{{ b.batchNumber }}</span>
          }
        </div>
      </div>

      <!-- Stability Studies Table -->
      <div class="p-5 rounded-2xl bg-slate-900/70 border border-slate-800/80 space-y-4">
        <div class="flex items-center justify-between">
          <div>
            <span class="text-xs font-mono uppercase tracking-wider text-slate-400">ACCELERATED AGEING & SHELF LIFE</span>
            <h2 class="text-base font-bold text-slate-100">ICH Q1A(R2) & ISO 18811 Stability Testing Protocol</h2>
          </div>
          <span class="text-xs font-mono text-emerald-400">Projected 36-Month Shelf Life: PASS</span>
        </div>

        <div class="border border-slate-800 rounded-xl overflow-hidden bg-slate-950">
          <table class="w-full text-left border-collapse text-xs">
            <thead>
              <tr class="border-b border-slate-800 bg-slate-900/80 text-[10px] font-mono uppercase text-slate-400">
                <th class="py-2.5 px-3">Incubation Condition</th>
                <th class="py-2.5 px-3">Timepoint</th>
                <th class="py-2.5 px-3">Viscosity Retention</th>
                <th class="py-2.5 px-3">Colour Drift (ΔE₀₀)</th>
                <th class="py-2.5 px-3">Phase Syneresis</th>
                <th class="py-2.5 px-3">Sedimentation Risk</th>
                <th class="py-2.5 px-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-mono">
              @for (st of state.stabilityTimepoints(); track $index) {
                <tr class="hover:bg-slate-900/40">
                  <td class="py-2.5 px-3 font-semibold text-slate-200">{{ st.condition }}</td>
                  <td class="py-2.5 px-3 text-slate-400">{{ st.timepointMonths }} months</td>
                  <td class="py-2.5 px-3 text-slate-200">{{ st.viscosityRetentionPercent.toFixed(1) }}%</td>
                  <td class="py-2.5 px-3 text-slate-200">{{ st.deltaE00Drift.toFixed(2) }}</td>
                  <td class="py-2.5 px-3 text-slate-400">{{ st.phaseSeparationObserved ? 'YES' : 'NONE' }}</td>
                  <td class="py-2.5 px-3" [ngClass]="st.sedimentationRisk === 'None' ? 'text-emerald-400' : 'text-amber-400'">
                    {{ st.sedimentationRisk }}
                  </td>
                  <td class="py-2.5 px-3 text-right">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {{ st.status }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `
})
export class QualitySpc {
  readonly state = inject(DigitalTwinStateService);
  readonly Math = Math;

  readonly meanViscosity = computed(() => {
    const list = this.state.spcBatches();
    if (list.length === 0) return 4200;
    return list.reduce((sum, b) => sum + b.viscosityCP, 0) / list.length;
  });

  readonly meanDeltaE = computed(() => {
    const list = this.state.spcBatches();
    if (list.length === 0) return 0.5;
    return list.reduce((sum, b) => sum + b.deltaE00, 0) / list.length;
  });

  readonly cpkIndex = computed(() => {
    // Process Capability Cpk = min((USL - Mean) / (3*sigma), (Mean - LSL) / (3*sigma))
    const USL = 4600;
    const LSL = 3800;
    const mean = this.meanViscosity();
    const sigma = 75.0; // standard deviation
    const cpkUpper = (USL - mean) / (3 * sigma);
    const cpkLower = (mean - LSL) / (3 * sigma);
    return Math.min(cpkUpper, cpkLower);
  });

  readonly spcPoints = computed(() => {
    const batches = this.state.spcBatches();
    const xStart = 50;
    const xEnd = 470;
    const yCenter = 90;
    const scale = 0.12; // pixels per cP delta from 4200

    return batches.map((b, i) => {
      const x = xStart + (i / Math.max(1, batches.length - 1)) * (xEnd - xStart);
      const dy = (b.viscosityCP - 4200) * scale;
      const y = yCenter - dy;
      return { batch: b.batchNumber, val: b.viscosityCP, x, y };
    });
  });

  readonly spcViscosityPath = computed(() => {
    const pts = this.spcPoints();
    if (pts.length === 0) return '';
    let d = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 1; i < pts.length; i++) {
      d += ` L ${pts[i].x} ${pts[i].y}`;
    }
    return d;
  });

  recordSample() {
    this.state.recordNewSPCMeasurement();
  }
}
