import { ChangeDetectionStrategy, Component, EventEmitter, Output, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinStateService } from '../../core/services/digital-twin-state.service';
import { IngredientDatabaseService } from '../../core/services/ingredient-database.service';

@Component({
  selector: 'app-report-modal',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      
      <div class="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        
        <!-- Modal Top Bar -->
        <div class="p-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
          <div class="flex items-center gap-3">
            <mat-icon class="text-cyan-400">article</mat-icon>
            <div>
              <h2 class="text-sm font-bold text-slate-100 font-mono">TECHNICAL FORMULATION DOSSIER & CERTIFICATE OF ANALYSIS</h2>
              <span class="text-[10px] text-slate-400 font-mono">CHROMA LAB DIGITAL TWIN VALIDATION REPORT</span>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <button 
              (click)="exportJSON()"
              class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono flex items-center gap-1.5 transition-colors">
              <mat-icon class="text-sm">data_object</mat-icon>
              <span>Export JSON</span>
            </button>

            <button 
              (click)="exportCSV()"
              class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono flex items-center gap-1.5 transition-colors">
              <mat-icon class="text-sm">table_view</mat-icon>
              <span>Export CSV</span>
            </button>

            <button 
              (click)="printReport()"
              class="px-3.5 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs font-mono flex items-center gap-1.5 transition-colors">
              <mat-icon class="text-sm">print</mat-icon>
              <span>Print Dossier</span>
            </button>

            <button 
              (click)="dismiss.emit()"
              class="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors ml-2">
              <mat-icon>close</mat-icon>
            </button>
          </div>
        </div>

        <!-- Scrollable Dossier Content -->
        <div id="printable-dossier" class="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950 text-slate-200 font-sans">
          
          <!-- Document Header -->
          <div class="flex justify-between items-start pb-4 border-b border-slate-800">
            <div>
              <div class="text-xl font-bold font-mono tracking-tight text-white flex items-center gap-2">
                <span>CHROMA LAB</span>
                <span class="text-xs font-mono text-cyan-400 px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800">
                  COSMETIC FORMULATION TWIN
                </span>
              </div>
              <div class="text-xs text-slate-400 font-mono mt-1">Master Formula Batch Dossier & Optical Release</div>
            </div>
            <div class="text-right text-xs font-mono space-y-0.5">
              <div><span class="text-slate-500">Document ID:</span> <span class="font-bold text-slate-200">DOC-2026-{{ state.formulation().id }}</span></div>
              <div><span class="text-slate-500">Date Generated:</span> <span class="text-slate-200">2026-11-05</span></div>
              <div><span class="text-slate-500">Status:</span> <span class="text-emerald-400 font-bold">{{ state.formulation().status }}</span></div>
            </div>
          </div>

          <!-- Formula Overview Box -->
          <div class="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono">
            <div>
              <span class="text-[10px] text-slate-400 uppercase">PRODUCT NAME</span>
              <div class="font-bold text-slate-100 text-sm mt-0.5">{{ state.formulation().name }}</div>
            </div>
            <div>
              <span class="text-[10px] text-slate-400 uppercase">CATEGORY</span>
              <div class="font-bold text-cyan-300 mt-0.5">{{ state.formulation().productCategory | titlecase }}</div>
            </div>
            <div>
              <span class="text-[10px] text-slate-400 uppercase">BATCH SIZE</span>
              <div class="font-bold text-slate-100 mt-0.5">{{ state.formulation().batchSizeKg }} kg</div>
            </div>
            <div>
              <span class="text-[10px] text-slate-400 uppercase">FORMULA COST</span>
              <div class="font-bold text-amber-300 mt-0.5">\${{ state.costPerKgUSD().toFixed(2) }} / kg</div>
            </div>
          </div>

          <!-- Formulation Master Recipe Table -->
          <div>
            <h3 class="text-xs font-mono font-bold uppercase text-slate-400 mb-2">1. INGREDIENT RECIPE & MASS ALLOCATION</h3>
            <div class="border border-slate-800 rounded-xl overflow-hidden">
              <table class="w-full text-left border-collapse text-xs">
                <thead>
                  <tr class="bg-slate-900 text-[10px] font-mono text-slate-400 uppercase border-b border-slate-800">
                    <th class="py-2 px-3">Phase</th>
                    <th class="py-2 px-3">INCI Name</th>
                    <th class="py-2 px-3">Trade Name / Supplier</th>
                    <th class="py-2 px-3 text-right">Conc (% w/w)</th>
                    <th class="py-2 px-3 text-right">Mass (g)</th>
                    <th class="py-2 px-3 text-right">Cost ($)</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/80 font-mono">
                  @for (item of state.formulation().items; track item.ingredientId) {
                    @let ing = db.getIngredientById(item.ingredientId);
                    <tr>
                      <td class="py-1.5 px-3 font-bold text-cyan-400">Phase {{ item.phase }}</td>
                      <td class="py-1.5 px-3 text-slate-200">{{ ing?.inciName }}</td>
                      <td class="py-1.5 px-3 text-slate-400">{{ ing?.tradeName }}</td>
                      <td class="py-1.5 px-3 text-right font-bold text-slate-100">{{ item.concentrationPercent.toFixed(2) }}%</td>
                      <td class="py-1.5 px-3 text-right text-slate-300">
                        {{ ((state.formulation().batchSizeKg * item.concentrationPercent) / 100 * 1000).toFixed(1) }} g
                      </td>
                      <td class="py-1.5 px-3 text-right text-slate-300">
                        \${{ (((state.formulation().batchSizeKg * item.concentrationPercent) / 100) * (ing?.costPerKgUSD || 0)).toFixed(2) }}
                      </td>
                    </tr>
                  }
                  <tr class="bg-slate-900/60 font-bold text-slate-100 border-t border-slate-700">
                    <td colspan="3" class="py-2 px-3">TOTAL MASS BALANCE</td>
                    <td class="py-2 px-3 text-right text-emerald-400">{{ state.totalConcentrationPercent().toFixed(2) }}%</td>
                    <td class="py-2 px-3 text-right">{{ (state.formulation().batchSizeKg * 1000).toFixed(0) }} g</td>
                    <td class="py-2 px-3 text-right text-amber-300">\${{ state.batchCostUSD().toFixed(2) }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <!-- Optical Colour Release Data (CIELAB & CIEDE2000) -->
          <div>
            <h3 class="text-xs font-mono font-bold uppercase text-slate-400 mb-2">2. SPECTROPHOTOMETRIC COLOUR RELEASE (CIEDE2000)</h3>
            <div class="grid grid-cols-2 gap-4 p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono">
              <div>
                <span class="text-slate-400">Target Standard CIELAB (D65, 2°):</span>
                <div class="font-bold text-slate-100 mt-0.5">
                  L*: {{ state.formulation().targetCIELAB.L.toFixed(2) }} | 
                  a*: {{ state.formulation().targetCIELAB.a.toFixed(2) }} | 
                  b*: {{ state.formulation().targetCIELAB.b.toFixed(2) }}
                </div>
              </div>
              <div>
                <span class="text-slate-400">Predicted Batch Equilibrium CIELAB:</span>
                <div class="font-bold text-slate-100 mt-0.5">
                  L*: {{ state.predictedCIELAB().L.toFixed(2) }} | 
                  a*: {{ state.predictedCIELAB().a.toFixed(2) }} | 
                  b*: {{ state.predictedCIELAB().b.toFixed(2) }}
                </div>
              </div>
              <div class="col-span-2 pt-2 border-t border-slate-800 flex items-center justify-between">
                <div>
                  <span class="text-slate-400">CIEDE2000 Difference:</span>
                  <span class="text-base font-bold text-emerald-400 ml-2">
                    ΔE₀₀ = {{ state.colorDifferenceDeltaE00().deltaE00.toFixed(2) }}
                  </span>
                  <span class="text-[10px] text-slate-500 ml-2">(Commercial Pass Spec: ΔE₀₀ ≤ 1.00)</span>
                </div>
                <span class="px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                  PASS — CERTIFIED
                </span>
              </div>
            </div>
          </div>

          <!-- Rheological Specifications -->
          <div>
            <h3 class="text-xs font-mono font-bold uppercase text-slate-400 mb-2">3. RHEOLOGY & COLLOIDAL STABILITY PARAMETERS</h3>
            <div class="grid grid-cols-3 gap-3 p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono">
              <div>
                <span class="text-[10px] text-slate-400">APPARENT VISCOSITY (at 100 s⁻¹)</span>
                <div class="font-bold text-slate-100 text-sm mt-0.5">{{ state.telemetry().apparentViscosityCP }} cP</div>
              </div>
              <div>
                <span class="text-[10px] text-slate-400">YIELD STRESS τ₀ (Herschel-Bulkley)</span>
                <div class="font-bold text-slate-100 text-sm mt-0.5">{{ state.rheologyParameters().yieldStressPa }} Pa</div>
              </div>
              <div>
                <span class="text-[10px] text-slate-400">FLOW BEHAVIOR INDEX n</span>
                <div class="font-bold text-slate-100 text-sm mt-0.5">{{ state.rheologyParameters().flowBehaviorIndexN }} (Pseudoplastic)</div>
              </div>
            </div>
          </div>

          <!-- Signatures Block -->
          <div class="pt-6 border-t border-slate-800 grid grid-cols-2 gap-8 text-xs font-mono">
            <div>
              <div class="text-slate-500 uppercase text-[10px]">PREPARED BY:</div>
              <div class="font-bold text-slate-200 mt-1">{{ state.formulation().approvedBy || 'Dr. Elena Rostova, Lead Formulator' }}</div>
              <div class="text-[10px] text-slate-400">Digital Twin Cosmetic Engineering Laboratory</div>
            </div>
            <div class="text-right">
              <div class="text-slate-500 uppercase text-[10px]">RELEASE VALIDATION:</div>
              <div class="font-bold text-emerald-400 mt-1">APPROVED FOR PILOT MANUFACTURE</div>
              <div class="text-[10px] text-slate-400">ISO 22716 GMP & EU 1223/2009 Compliant</div>
            </div>
          </div>

        </div>

      </div>

    </div>
  `
})
export class ReportModal {
  readonly state = inject(DigitalTwinStateService);
  readonly db = inject(IngredientDatabaseService);
  @Output() dismiss = new EventEmitter<void>();

  printReport() {
    window.print();
  }

  exportJSON() {
    const data = {
      formulation: this.state.formulation(),
      telemetry: this.state.telemetry(),
      colorimetry: {
        targetCIELAB: this.state.formulation().targetCIELAB,
        predictedCIELAB: this.state.predictedCIELAB(),
        deltaE00: this.state.colorDifferenceDeltaE00()
      },
      processSteps: this.state.processSteps(),
      spcBatches: this.state.spcBatches(),
      timestamp: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ChromaLab_${this.state.formulation().id}_Dossier.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  exportCSV() {
    const headers = ['Phase', 'INCI_Name', 'Trade_Name', 'Concentration_Percent', 'Batch_Mass_g', 'Cost_USD'];
    const rows = this.state.formulation().items.map(item => {
      const ing = this.db.getIngredientById(item.ingredientId);
      const massG = (this.state.formulation().batchSizeKg * item.concentrationPercent) / 100 * 1000;
      const cost = ((this.state.formulation().batchSizeKg * item.concentrationPercent) / 100) * (ing?.costPerKgUSD || 0);
      return [
        `"Phase ${item.phase}"`,
        `"${ing?.inciName || ''}"`,
        `"${ing?.tradeName || ''}"`,
        item.concentrationPercent.toFixed(2),
        massG.toFixed(1),
        cost.toFixed(2)
      ].join(',');
    });

    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ChromaLab_${this.state.formulation().id}_Recipe.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
