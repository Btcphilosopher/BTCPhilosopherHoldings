import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { DigitalTwinStateService } from '../../core/services/digital-twin-state.service';
import { RheologyService } from '../../core/services/rheology.service';
import { FlowCurvePoint, RheologyModelType, RheologyParameters } from '../../core/models/rheology.model';

@Component({
  selector: 'app-rheology-lab',
  standalone: true,
  imports: [CommonModule, MatIconModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto bg-[#07090e] p-6 space-y-6">
      
      <!-- Rheology Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <span class="text-[11px] font-mono tracking-wider uppercase text-slate-400">COLLOID & RHEOLOGY LABORATORY</span>
          <h1 class="text-xl font-bold text-slate-100 flex items-center gap-3">
            <span>Viscoelastic Flow Curves & Yield Stress Analysis</span>
            <span class="text-xs font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              {{ activeModelType() | uppercase }}
            </span>
          </h1>
        </div>

        <!-- Model Selector Tabs -->
        <div class="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-xl text-xs font-mono">
          <button 
            (click)="selectModel('herschel-bulkley')"
            class="px-2.5 py-1 rounded-lg transition-colors"
            [ngClass]="activeModelType() === 'herschel-bulkley' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'">
            Herschel-Bulkley
          </button>
          <button 
            (click)="selectModel('power-law')"
            class="px-2.5 py-1 rounded-lg transition-colors"
            [ngClass]="activeModelType() === 'power-law' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'">
            Power-Law
          </button>
          <button 
            (click)="selectModel('carreau-yasuda')"
            class="px-2.5 py-1 rounded-lg transition-colors"
            [ngClass]="activeModelType() === 'carreau-yasuda' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'">
            Carreau-Yasuda
          </button>
          <button 
            (click)="selectModel('bingham')"
            class="px-2.5 py-1 rounded-lg transition-colors"
            [ngClass]="activeModelType() === 'bingham' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'">
            Bingham Plastic
          </button>
        </div>
      </div>

      <!-- Main Layout: SVG Graph (Left) + Rheometer Parameters (Right) -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Flow Curve & Viscosity Curves (2 cols) -->
        <div class="lg:col-span-2 p-5 rounded-2xl bg-slate-900/70 border border-slate-800/80 space-y-4">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-4">
              <span class="text-xs font-mono uppercase tracking-wider text-slate-400">RHEOLOGICAL FLOW CURVES</span>
              <div class="flex items-center gap-2 text-xs">
                <button 
                  (click)="curveMode.set('shear-stress')"
                  class="px-2 py-0.5 rounded font-mono text-[11px]"
                  [ngClass]="curveMode() === 'shear-stress' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400'">
                  Shear Stress τ (Pa)
                </button>
                <button 
                  (click)="curveMode.set('viscosity')"
                  class="px-2 py-0.5 rounded font-mono text-[11px]"
                  [ngClass]="curveMode() === 'viscosity' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400'">
                  Viscosity η (cP)
                </button>
              </div>
            </div>

            <div class="text-xs font-mono text-slate-400">
              Temperature: <span class="text-amber-300 font-bold">{{ testTempC() }} °C</span>
            </div>
          </div>

          <!-- SVG Rheology Chart Viewport -->
          <div class="w-full h-80 bg-slate-950 rounded-xl p-4 border border-slate-800 relative flex flex-col justify-between">
            <!-- Y Axis Label -->
            <div class="absolute left-3 top-3 text-[10px] font-mono text-slate-400">
              {{ curveMode() === 'shear-stress' ? 'Shear Stress τ (Pa)' : 'Apparent Viscosity η (cP)' }}
            </div>

            <svg class="w-full h-64 overflow-visible" viewBox="0 0 500 200" preserveAspectRatio="none">
              <!-- Grid lines -->
              <line x1="45" y1="20" x2="480" y2="20" stroke="#1e293b" stroke-dasharray="2,2" />
              <line x1="45" y1="65" x2="480" y2="65" stroke="#1e293b" stroke-dasharray="2,2" />
              <line x1="45" y1="110" x2="480" y2="110" stroke="#1e293b" stroke-dasharray="2,2" />
              <line x1="45" y1="155" x2="480" y2="155" stroke="#1e293b" stroke-dasharray="2,2" />
              <line x1="45" y1="190" x2="480" y2="190" stroke="#334155" />
              <line x1="45" y1="10" x2="45" y2="190" stroke="#334155" />

              <!-- Forward Sweep Primary Curve -->
              <path 
                [attr.d]="svgPrimaryPath()" 
                fill="none" 
                [attr.stroke]="curveMode() === 'shear-stress' ? '#38bdf8' : '#f59e0b'" 
                stroke-width="3" />

              <!-- Downward Sweep (Thixotropy Hysteresis Loop) -->
              @if (curveMode() === 'shear-stress') {
                <path 
                  [attr.d]="svgDownSweepPath()" 
                  fill="none" 
                  stroke="#ec4899" 
                  stroke-dasharray="4,3" 
                  stroke-width="2" />
              }

              <!-- Highlighted Cosmetic Regimes Overlay Ticks -->
              <text x="50" y="15" fill="#64748b" font-size="8" font-family="monospace">Storage / Settling (0.01 s⁻¹)</text>
              <text x="210" y="15" fill="#64748b" font-size="8" font-family="monospace">Skin Spreading (100-500 s⁻¹)</text>
              <text x="360" y="15" fill="#64748b" font-size="8" font-family="monospace">Impeller Shear (5000 s⁻¹)</text>
            </svg>

            <!-- X Axis Shear Rate Ticks -->
            <div class="flex justify-between pl-10 pr-4 text-[9px] font-mono text-slate-500">
              <span>0.01 s⁻¹</span>
              <span>0.1 s⁻¹</span>
              <span>1 s⁻¹</span>
              <span>10 s⁻¹</span>
              <span>100 s⁻¹</span>
              <span>1,000 s⁻¹</span>
              <span>10,000 s⁻¹</span>
            </div>
          </div>

          <!-- Curve Legend & Thixotropic Loop Note -->
          <div class="flex flex-wrap items-center justify-between text-xs font-mono text-slate-400 pt-2">
            <div class="flex items-center gap-4">
              <div class="flex items-center gap-1.5">
                <span class="w-3 h-0.5 bg-cyan-400"></span>
                <span>Ascending Shear Sweep (0.01 &rarr; 10,000 s⁻¹)</span>
              </div>
              <div class="flex items-center gap-1.5">
                <span class="w-3 h-0.5 bg-pink-500 border-dashed"></span>
                <span>Descending Recovery Loop (Thixotropic breakdown)</span>
              </div>
            </div>
            <div class="text-pink-400 font-bold">
              ΔA Area: {{ customParams().thixotropicBreakdownAreaPaPerS || 185 }} Pa/s
            </div>
          </div>
        </div>

        <!-- Colloid & Yield Stress Suspension Audit (1 col) -->
        <div class="p-5 rounded-2xl bg-slate-900/70 border border-slate-800/80 flex flex-col justify-between space-y-4">
          <div>
            <div class="flex items-center justify-between mb-3">
              <span class="text-xs font-mono uppercase tracking-wider text-slate-400">PHYSICAL MODEL PARAMETERS</span>
              <span class="text-[10px] font-mono text-emerald-400">R² = 0.9982</span>
            </div>

            <!-- Herschel-Bulkley Parameters -->
            <div class="space-y-3">
              <!-- Yield Stress tau_0 -->
              <div class="space-y-1">
                <div class="flex items-center justify-between text-xs font-mono">
                  <span class="text-slate-300 font-bold">Yield Stress τ₀</span>
                  <span class="text-cyan-300 font-bold">{{ customParams().yieldStressPa.toFixed(1) }} Pa</span>
                </div>
                <input 
                  type="range" min="0" max="60" step="0.2"
                  [ngModel]="customParams().yieldStressPa"
                  (ngModelChange)="updateYieldStress($event)"
                  class="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer" />
                <div class="text-[10px] font-mono text-slate-500">Minimum stress required to initiate macroscopic flow</div>
              </div>

              <!-- Consistency Index K -->
              <div class="space-y-1">
                <div class="flex items-center justify-between text-xs font-mono">
                  <span class="text-slate-300 font-bold">Consistency Index K</span>
                  <span class="text-amber-300 font-bold">{{ customParams().consistencyIndexK.toFixed(1) }} Pa·sⁿ</span>
                </div>
                <input 
                  type="range" min="1" max="100" step="0.5"
                  [ngModel]="customParams().consistencyIndexK"
                  (ngModelChange)="updateConsistencyK($event)"
                  class="w-full accent-amber-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer" />
                <div class="text-[10px] font-mono text-slate-500">Proportional to overall internal viscous structure</div>
              </div>

              <!-- Flow Behavior Index n -->
              <div class="space-y-1">
                <div class="flex items-center justify-between text-xs font-mono">
                  <span class="text-slate-300 font-bold">Flow Behavior Index n</span>
                  <span class="text-emerald-300 font-bold">{{ customParams().flowBehaviorIndexN.toFixed(2) }}</span>
                </div>
                <input 
                  type="range" min="0.10" max="1.0" step="0.01"
                  [ngModel]="customParams().flowBehaviorIndexN"
                  (ngModelChange)="updateFlowIndexN($event)"
                  class="w-full accent-emerald-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer" />
                <div class="text-[10px] font-mono text-slate-500">
                  {{ customParams().flowBehaviorIndexN < 1 ? 'Pseudoplastic (Shear-Thinning)' : 'Newtonian' }}
                </div>
              </div>

              <!-- Temperature Sensitivity -->
              <div class="space-y-1 pt-2 border-t border-slate-800">
                <div class="flex items-center justify-between text-xs font-mono">
                  <span class="text-slate-300">Test Temperature</span>
                  <span class="text-amber-300 font-bold">{{ testTempC() }} °C</span>
                </div>
                <input 
                  type="range" min="10" max="65" step="1"
                  [ngModel]="testTempC()"
                  (ngModelChange)="testTempC.set($event)"
                  class="w-full accent-amber-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer" />
                <div class="text-[10px] font-mono text-slate-500">Arrhenius activation energy Ea = 22.0 kJ/mol</div>
              </div>
            </div>
          </div>

          <!-- Stokes Law Pigment Suspension Audit Box -->
          <div class="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div class="flex items-center gap-2">
              <mat-icon class="text-sm" [ngClass]="suspensionCheck().isSuspendedIndefinitely ? 'text-emerald-400' : 'text-amber-400'">
                {{ suspensionCheck().isSuspendedIndefinitely ? 'verified_user' : 'warning' }}
              </mat-icon>
              <span class="text-xs font-mono font-bold" [ngClass]="suspensionCheck().isSuspendedIndefinitely ? 'text-emerald-300' : 'text-amber-300'">
                COLLOIDAL SUSPENSION AUDIT
              </span>
            </div>

            <p class="text-[11px] text-slate-300 leading-relaxed font-sans">
              {{ suspensionCheck().explanation }}
            </p>

            <div class="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-1 border-t border-slate-800">
              <span>Safety Margin:</span>
              <span class="font-bold text-slate-100">{{ suspensionCheck().yieldStressMarginRatio }}× over critical gravity threshold</span>
            </div>
          </div>

        </div>

      </div>

    </div>
  `
})
export class RheologyLab {
  readonly state = inject(DigitalTwinStateService);
  readonly rheologyService = inject(RheologyService);

  readonly curveMode = signal<'shear-stress' | 'viscosity'>('shear-stress');
  readonly testTempC = signal<number>(25.0);
  readonly activeModelType = signal<RheologyModelType>('herschel-bulkley');

  readonly customParams = signal<RheologyParameters>({
    modelType: 'herschel-bulkley',
    yieldStressPa: 4.8,
    consistencyIndexK: 12.5,
    flowBehaviorIndexN: 0.28,
    zeroShearViscosityPaS: 450.0,
    infiniteShearViscosityPaS: 0.08,
    temperatureSensitivityEaKJ: 22.0,
    thixotropicBreakdownAreaPaPerS: 185.0
  });

  readonly flowCurve = computed<FlowCurvePoint[]>(() => {
    return this.rheologyService.generateFlowCurve(this.customParams(), this.testTempC());
  });

  readonly suspensionCheck = computed(() => {
    return this.rheologyService.checkPigmentSuspensionStability(this.customParams().yieldStressPa, 4.23, 240);
  });

  readonly svgPrimaryPath = computed<string>(() => {
    const pts = this.flowCurve();
    if (pts.length === 0) return '';
    const mode = this.curveMode();

    const xStart = 45;
    const xEnd = 480;
    const yBottom = 190;
    const yTop = 20;

    let maxVal = 1;
    for (const p of pts) {
      const v = mode === 'shear-stress' ? p.shearStressPa : p.apparentViscosityCP;
      if (v > maxVal) maxVal = v;
    }

    let d = '';
    for (let i = 0; i < pts.length; i++) {
      const val = mode === 'shear-stress' ? pts[i].shearStressPa : pts[i].apparentViscosityCP;
      const x = xStart + (i / (pts.length - 1)) * (xEnd - xStart);
      const y = yBottom - (val / maxVal) * (yBottom - yTop);
      d += i === 0 ? `M ${x} ${y}` : ` L ${x} ${y}`;
    }
    return d;
  });

  readonly svgDownSweepPath = computed<string>(() => {
    const pts = this.flowCurve();
    if (pts.length === 0) return '';
    const xStart = 45;
    const xEnd = 480;
    const yBottom = 190;
    const yTop = 20;

    let maxVal = 1;
    for (const p of pts) {
      if (p.shearStressPa > maxVal) maxVal = p.shearStressPa;
    }

    let d = '';
    for (let i = 0; i < pts.length; i++) {
      const val = pts[i].downSweepStressPa || pts[i].shearStressPa;
      const x = xStart + (i / (pts.length - 1)) * (xEnd - xStart);
      const y = yBottom - (val / maxVal) * (yBottom - yTop);
      d += i === 0 ? `M ${x} ${y}` : ` L ${x} ${y}`;
    }
    return d;
  });

  selectModel(model: RheologyModelType) {
    this.activeModelType.set(model);
    this.customParams.update(p => ({ ...p, modelType: model }));
  }

  updateYieldStress(v: number) {
    this.customParams.update(p => ({ ...p, yieldStressPa: v }));
  }

  updateConsistencyK(v: number) {
    this.customParams.update(p => ({ ...p, consistencyIndexK: v }));
  }

  updateFlowIndexN(v: number) {
    this.customParams.update(p => ({ ...p, flowBehaviorIndexN: v }));
  }
}
