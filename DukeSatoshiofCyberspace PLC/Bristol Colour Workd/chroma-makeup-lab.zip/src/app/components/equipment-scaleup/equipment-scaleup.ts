import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { DigitalTwinStateService } from '../../core/services/digital-twin-state.service';
import { MixingPhysicsService } from '../../core/services/mixing-physics.service';
import { ManufacturingScale } from '../../core/models/manufacturing.model';

@Component({
  selector: 'app-equipment-scaleup',
  standalone: true,
  imports: [CommonModule, MatIconModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto bg-[#07090e] p-6 space-y-6">
      
      <!-- Scale-Up Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <span class="text-[11px] font-mono tracking-wider uppercase text-slate-400">INDUSTRIAL SCALE-UP DIGITAL TWIN</span>
          <h1 class="text-xl font-bold text-slate-100 flex items-center gap-3">
            <span>Plant Batch Scale-Up & Process Recipe Timeline</span>
            <span class="text-xs font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              MASS & HEAT BALANCE
            </span>
          </h1>
        </div>

        <!-- Scale Tier Selector -->
        <div class="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-xl text-xs font-mono">
          <button 
            (click)="selectedScale.set('bench-100g')"
            class="px-2.5 py-1 rounded-lg transition-colors"
            [ngClass]="selectedScale() === 'bench-100g' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'">
            Bench 100g
          </button>
          <button 
            (click)="selectedScale.set('pilot-10kg')"
            class="px-2.5 py-1 rounded-lg transition-colors"
            [ngClass]="selectedScale() === 'pilot-10kg' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'">
            Pilot 10kg
          </button>
          <button 
            (click)="selectedScale.set('production-100kg')"
            class="px-2.5 py-1 rounded-lg transition-colors"
            [ngClass]="selectedScale() === 'production-100kg' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'">
            Production 100kg
          </button>
          <button 
            (click)="selectedScale.set('plant-1000kg')"
            class="px-2.5 py-1 rounded-lg transition-colors"
            [ngClass]="selectedScale() === 'plant-1000kg' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'">
            Plant 1,000kg
          </button>
        </div>
      </div>

      <!-- Scale-Up Analysis Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- Mass & Yield Card -->
        <div class="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
          <div class="text-[10px] font-mono text-slate-400 uppercase tracking-wider">TARGET BATCH MASS</div>
          <div class="text-2xl font-mono font-bold text-slate-100 mt-1 flex items-baseline">
            <span>{{ targetMassKg() }}</span>
            <span class="text-xs font-mono text-slate-400 ml-1.5 uppercase">kg</span>
          </div>
          <div class="text-xs font-mono text-slate-400 mt-1">
            Working Volume: {{ (targetMassKg() / 1.02).toFixed(1) }} L
          </div>
          <div class="text-[10px] font-mono text-emerald-400 mt-1.5 pt-1.5 border-t border-slate-800">
            Yield Target: 98.5% (1.5% wall holdup)
          </div>
        </div>

        <!-- Calculated Target RPM -->
        <div class="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
          <div class="text-[10px] font-mono text-slate-400 uppercase tracking-wider">SCALE-UP AGITATION</div>
          <div class="text-2xl font-mono font-bold text-cyan-300 mt-1 flex items-baseline">
            <span>{{ scaleUpResult().targetRpm }}</span>
            <span class="text-xs font-mono text-cyan-400 ml-1.5 uppercase">RPM</span>
          </div>
          <div class="text-xs font-mono text-slate-400 mt-1">
            Tip Speed: {{ scaleUpResult().tipSpeedMPerS.toFixed(1) }} m/s
          </div>
          <div class="text-[10px] font-mono text-slate-400 mt-1.5 pt-1.5 border-t border-slate-800">
            Geometric Scaling λ = {{ scaleUpResult().scaleFactorGeometric }}×
          </div>
        </div>

        <!-- Power Draw (kW) -->
        <div class="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
          <div class="text-[10px] font-mono text-slate-400 uppercase tracking-wider">MOTOR POWER DRAW</div>
          <div class="text-2xl font-mono font-bold text-amber-300 mt-1 flex items-baseline">
            <span>{{ (scaleUpResult().targetPowerWatts / 1000).toFixed(2) }}</span>
            <span class="text-xs font-mono text-amber-400 ml-1.5 uppercase">kW</span>
          </div>
          <div class="text-xs font-mono text-slate-400 mt-1">
            P = Np·ρ·N³·D⁵
          </div>
          <div class="text-[10px] font-mono text-slate-400 mt-1.5 pt-1.5 border-t border-slate-800">
            Motor Rating: {{ getMotorRating(targetMassKg()) }} kW Required
          </div>
        </div>

        <!-- Cycle & Thermal Scale -->
        <div class="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
          <div class="text-[10px] font-mono text-slate-400 uppercase tracking-wider">HEAT TRANSFER RATIO</div>
          <div class="text-2xl font-mono font-bold text-rose-300 mt-1 flex items-baseline">
            <span>+{{ ((scaleUpResult().coolingTimeIncreaseRatio - 1) * 100).toFixed(0) }}</span>
            <span class="text-xs font-mono text-rose-400 ml-1.5 uppercase">% cooling time</span>
          </div>
          <div class="text-xs font-mono text-slate-400 mt-1">
            Area/Volume scales as 1/λ
          </div>
          <div class="text-[10px] font-mono text-rose-400 mt-1.5 pt-1.5 border-t border-slate-800">
            Requires chilled glycol jacket
          </div>
        </div>
      </div>

      <!-- Feasibility Warnings Panel -->
      @if (scaleUpResult().warnings.length > 0) {
        <div class="p-4 rounded-xl bg-amber-950/30 border border-amber-500/40 text-amber-200">
          <div class="flex items-center gap-2 mb-2 font-mono text-xs font-semibold text-amber-300">
            <mat-icon class="text-sm">warning</mat-icon>
            <span>ENGINEERING SCALE-UP FEASIBILITY ADVISORY</span>
          </div>
          <ul class="space-y-1.5 list-disc list-inside text-xs">
            @for (warn of scaleUpResult().warnings; track warn) {
              <li>{{ warn }}</li>
            }
          </ul>
        </div>
      }

      <!-- Master Batch Process Recipe Timeline -->
      <div class="p-5 rounded-2xl bg-slate-900/70 border border-slate-800/80 space-y-4">
        <div class="flex items-center justify-between">
          <div>
            <span class="text-xs font-mono uppercase tracking-wider text-slate-400">MASTER BATCH RECORD (MBR)</span>
            <h2 class="text-base font-bold text-slate-100">Process Manufacturing Recipe & Phase Sequence</h2>
          </div>
          <div class="text-xs font-mono text-slate-400">
            Total Cycle Time: <span class="text-cyan-300 font-bold">{{ totalDurationMinutes() }} mins</span>
          </div>
        </div>

        <!-- Recipe Steps Timeline List -->
        <div class="space-y-3">
          @for (step of state.processSteps(); track step.stepNumber) {
            <div class="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div class="flex items-start gap-3">
                <div class="w-8 h-8 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center font-mono font-bold text-cyan-300 text-xs shrink-0">
                  {{ step.stepNumber }}
                </div>
                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-xs font-bold text-slate-100 font-mono">{{ step.action }}</span>
                    <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">{{ step.phaseId }}</span>
                    <span class="text-[10px] font-mono text-cyan-400">{{ step.impeller }}</span>
                  </div>
                  <p class="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">{{ step.description }}</p>
                </div>
              </div>

              <!-- Step Targets & Critical Quality Attribute -->
              <div class="flex items-center gap-4 text-xs font-mono text-slate-300 shrink-0 border-t md:border-t-0 md:border-l border-slate-800 pt-2 md:pt-0 md:pl-4">
                <div class="text-right">
                  <div class="text-[10px] text-slate-500 uppercase">TARGET SETTINGS</div>
                  <div class="font-bold text-slate-200">{{ step.targetTempC }}°C · {{ step.targetRpm }} RPM</div>
                  <div class="text-[10px] text-slate-400">{{ step.durationMinutes }} mins</div>
                </div>

                <div class="text-right pl-3 border-l border-slate-800">
                  <div class="text-[10px] text-slate-500 uppercase">CRITICAL QUALITY ATTRIBUTE</div>
                  <div class="text-emerald-400 font-medium text-[11px] max-w-[160px]">{{ step.criticalQualityAttribute }}</div>
                </div>
              </div>
            </div>
          }
        </div>
      </div>

    </div>
  `
})
export class EquipmentScaleup {
  readonly state = inject(DigitalTwinStateService);
  readonly mixingPhysics = inject(MixingPhysicsService);

  readonly selectedScale = signal<ManufacturingScale>('pilot-10kg');

  readonly targetMassKg = computed<number>(() => {
    switch (this.selectedScale()) {
      case 'bench-100g': return 0.10;
      case 'dev-1kg': return 1.0;
      case 'pilot-10kg': return 10.0;
      case 'production-100kg': return 100.0;
      case 'plant-1000kg': return 1000.0;
      default: return 10.0;
    }
  });

  readonly scaleUpResult = computed(() => {
    return this.mixingPhysics.performScaleUpComparison(
      this.state.formulation().batchSizeKg,
      this.targetMassKg(),
      this.state.rpm(),
      this.state.impellerType(),
      'constant-P_over_V'
    );
  });

  readonly totalDurationMinutes = computed(() => {
    return this.state.processSteps().reduce((sum, s) => sum + s.durationMinutes, 0);
  });

  getMotorRating(massKg: number): number {
    if (massKg <= 1) return 0.75;
    if (massKg <= 10) return 2.2;
    if (massKg <= 100) return 7.5;
    return 30.0;
  }
}
