import { ChangeDetectionStrategy, Component, EventEmitter, Output, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinStateService } from '../../core/services/digital-twin-state.service';
import { ProductCategory } from '../../core/models/formulation.model';

@Component({
  selector: 'app-top-bar',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="h-14 bg-slate-950/95 border-b border-slate-800/80 px-6 flex items-center justify-between gap-8 z-30 select-none shrink-0">
      
      <!-- Zone 1: Single element brand wordmark -->
      <div class="flex items-center gap-3 shrink-0">
        <div class="w-7 h-7 rounded-lg bg-gradient-to-br from-rose-400 via-amber-300 to-cyan-400 p-[1.5px] shadow-sm">
          <div class="w-full h-full bg-slate-950 rounded-[6.5px] flex items-center justify-center">
            <span class="text-xs font-bold font-mono text-cyan-300">CL</span>
          </div>
        </div>
        <a href="/" class="text-base font-bold tracking-tight text-slate-100 whitespace-nowrap shrink-0 hover:text-white transition-colors">
          CHROMA LAB
        </a>
        <span class="hidden xl:inline text-xs font-mono text-slate-500 border-l border-slate-800 pl-3">Digital Twin Workstation</span>
      </div>

      <!-- Zone 2: Navigation Links (Single line, whitespace-nowrap) -->
      <nav class="hidden md:flex items-center gap-1.5 lg:gap-3 text-xs font-medium text-slate-400">
        <button 
          (click)="state.setTab('twin-mixer')"
          class="px-2.5 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
          [ngClass]="state.activeTab() === 'twin-mixer' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'hover:text-slate-200 hover:bg-slate-900'">
          <mat-icon class="text-base">view_in_ar</mat-icon>
          <span>3D Twin</span>
        </button>

        <button 
          (click)="state.setTab('formulation')"
          class="px-2.5 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
          [ngClass]="state.activeTab() === 'formulation' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'hover:text-slate-200 hover:bg-slate-900'">
          <mat-icon class="text-base">science</mat-icon>
          <span>Formulation</span>
        </button>

        <button 
          (click)="state.setTab('shade-studio')"
          class="px-2.5 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
          [ngClass]="state.activeTab() === 'shade-studio' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'hover:text-slate-200 hover:bg-slate-900'">
          <mat-icon class="text-base">palette</mat-icon>
          <span>Shade Studio</span>
        </button>

        <button 
          (click)="state.setTab('rheology')"
          class="px-2.5 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
          [ngClass]="state.activeTab() === 'rheology' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'hover:text-slate-200 hover:bg-slate-900'">
          <mat-icon class="text-base">waves</mat-icon>
          <span>Rheology</span>
        </button>

        <button 
          (click)="state.setTab('manufacturing')"
          class="px-2.5 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
          [ngClass]="state.activeTab() === 'manufacturing' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'hover:text-slate-200 hover:bg-slate-900'">
          <mat-icon class="text-base">precision_manufacturing</mat-icon>
          <span>Scale-Up</span>
        </button>

        <button 
          (click)="state.setTab('quality-spc')"
          class="px-2.5 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
          [ngClass]="state.activeTab() === 'quality-spc' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'hover:text-slate-200 hover:bg-slate-900'">
          <mat-icon class="text-base">insights</mat-icon>
          <span>SPC & Quality</span>
        </button>

        <button 
          (click)="state.setTab('doe-optimizer')"
          class="px-2.5 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
          [ngClass]="state.activeTab() === 'doe-optimizer' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'hover:text-slate-200 hover:bg-slate-900'">
          <mat-icon class="text-base">tune</mat-icon>
          <span>DOE Simplex</span>
        </button>
      </nav>

      <!-- Zone 3: Primary Action & Preset Quick Dropdown -->
      <div class="flex items-center gap-3 shrink-0">
        <!-- Preset Selector -->
        <div class="hidden sm:flex items-center gap-1.5">
          <span class="text-[11px] font-mono text-slate-500 uppercase">PRESET:</span>
          <select 
            [value]="state.formulation().productCategory" 
            (change)="onCategoryChange($event)"
            class="bg-slate-900 border border-slate-800 text-slate-200 rounded-lg px-2.5 py-1 font-mono text-xs focus:ring-1 focus:ring-cyan-500 outline-none">
            <option value="liquid-foundation">Liquid Foundation</option>
            <option value="concealer">High-Cover Concealer</option>
            <option value="lipstick">Matte Velvet Lipstick</option>
            <option value="powder-blush">Mineral Powder Blush</option>
            <option value="emulsion-cream">Lamellar Barrier Cream</option>
          </select>
        </div>

        <button 
          (click)="openReport.emit()"
          class="px-3.5 py-1.5 text-xs font-medium text-slate-950 bg-gradient-to-r from-amber-300 via-rose-300 to-cyan-300 hover:brightness-110 rounded-xl transition-all shadow-sm flex items-center gap-1.5 whitespace-nowrap shrink-0 font-semibold">
          <mat-icon class="text-sm">description</mat-icon>
          <span>Export Dossier</span>
        </button>
      </div>

    </header>
  `
})
export class TopBar {
  readonly state = inject(DigitalTwinStateService);
  @Output() openReport = new EventEmitter<void>();

  onCategoryChange(e: Event) {
    const val = (e.target as HTMLSelectElement).value as ProductCategory;
    this.state.loadPreset(val);
  }
}
