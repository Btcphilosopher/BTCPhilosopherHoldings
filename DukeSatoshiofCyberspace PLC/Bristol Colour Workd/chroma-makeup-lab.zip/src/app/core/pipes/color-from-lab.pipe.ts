import { Pipe, PipeTransform, inject } from '@angular/core';
import { ColorScienceService } from '../services/color-science.service';
import { ColorCIELAB } from '../models/color-science.model';

@Pipe({
  name: 'colorFromLab',
  standalone: true
})
export class ColorFromLabPipe implements PipeTransform {
  private readonly colorScience = inject(ColorScienceService);

  transform(value: ColorCIELAB | string | null | undefined): string {
    if (!value) return '#CCCCCC';
    if (typeof value === 'string') {
      try {
        const parsed = JSON.parse(value) as ColorCIELAB;
        return this.colorScience.labToHex(parsed);
      } catch {
        return '#CCCCCC';
      }
    }
    return this.colorScience.labToHex(value);
  }
}
