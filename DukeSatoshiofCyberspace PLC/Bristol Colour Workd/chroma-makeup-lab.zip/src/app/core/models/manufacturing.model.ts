import { ImpellerType } from './mixing-physics.model';

export type ManufacturingScale = 'bench-100g' | 'dev-1kg' | 'pilot-10kg' | 'production-100kg' | 'plant-1000kg';

export interface BatchScaleDefinition {
  id: ManufacturingScale;
  name: string;
  batchMassKg: number;
  vesselDiameterMeters: number;
  vesselHeightMeters: number;
  impellerDiameterMeters: number;
  maxMotorPowerKW: number;
  maxRpm: number;
  jacketAreaM2: number;
}

export interface ScaleUpComparison {
  scale: ManufacturingScale;
  batchMassKg: number;
  calculatedRpm: number;
  tipSpeedMPerS: number;
  powerDrawWatts: number;
  powerPerVolumeWPerM3: number;
  reynoldsNumber: number;
  estimatedMixingTimeSec: number;
  jacketHeatFluxKW: number;
  coolingTimeMinutes: number;
  feasibilityWarnings: string[];
}

export interface ProcessRecipeStep {
  stepNumber: number;
  phaseId: string;
  action: 'Charge' | 'Agitate' | 'Heat' | 'Cool' | 'Homogenize' | 'Pigment-Grind' | 'Hold' | 'Sample-QC';
  description: string;
  targetTempC: number;
  targetRpm: number;
  impeller: ImpellerType;
  durationMinutes: number;
  criticalQualityAttribute: string;
}

export interface QualitySpec {
  parameter: 'viscosity' | 'deltaE00' | 'pH' | 'density' | 'dropletSizeD32' | 'microbialCount';
  name: string;
  unit: string;
  lowerSpecLimit: number; // LSL
  targetValue: number;
  upperSpecLimit: number; // USL
}

export interface SPCBatchMeasurement {
  batchNumber: string;
  timestamp: string;
  viscosityCP: number;
  deltaE00: number;
  pH: number;
  densityGPerCm3: number;
  homogeneityPercent: number;
  status: 'In-Spec' | 'Warning' | 'Out-of-Spec';
}

export interface StabilityTimepoint {
  condition: '25C / 60% RH' | '40C / 75% RH' | '45C Stress' | 'Freeze-Thaw (3 cycles)';
  timepointMonths: number;
  viscosityRetentionPercent: number;
  deltaE00Drift: number;
  phaseSeparationObserved: boolean;
  sedimentationRisk: 'None' | 'Slight' | 'Severe';
  status: 'Pass' | 'Investigate' | 'Fail';
}
