export type ImpellerType = 
  | 'rushton-turbine' 
  | 'pitched-blade' 
  | 'marine-propeller' 
  | 'anchor' 
  | 'high-shear-rotor-stator' 
  | 'planetary-double' 
  | 'powder-tumble';

export interface ImpellerConfig {
  type: ImpellerType;
  name: string;
  description: string;
  diameterRatioD_over_T: number; // Impeller diameter / Vessel diameter (typical 0.3 - 0.95 for anchor)
  powerNumberTurbulentNp: number; // Np in turbulent regime (e.g. 5.0 for Rushton, 1.27 for PBT, 0.35 for Propeller, 0.5-1.0 for Anchor, 3.5 for rotor-stator)
  laminarConstantKl: number; // Np = Kl / Re in laminar regime (e.g. 70 for Rushton, 45 for PBT, 400 for anchor)
  shearIntensityProxy: number; // 1 to 10
  pumpingNumberNq: number; // flow number
}

export interface VesselConfig {
  id: string;
  name: string;
  diameterMeters: number; // T
  heightMeters: number;   // H
  maxWorkingVolumeLiters: number;
  hasBaffles: boolean;
  baffleCount: number;
  jacketHeatTransferAreaM2: number;
  heatTransferCoefficientU: number; // W / (m² · K)
  material: 'Borosilicate-Glass' | '316L-Stainless-Steel' | 'Hastelloy';
}

export interface MixingTelemetry {
  rpm: number;
  revolutionsPerSec: number;
  tipSpeedMPerS: number; // v_tip = π * N * D
  reynoldsNumber: number; // Re = ρ * N * D² / μ
  flowRegime: 'Laminar' | 'Transitional' | 'Turbulent';
  powerNumberNp: number;
  mixingPowerWatts: number; // P = Np * ρ * N³ * D⁵
  torqueNewtonMeters: number; // T = P / (2πN)
  apparentViscosityCP: number;
  shearRatePerS: number; // average shear rate k_s * N
  batchTemperatureC: number;
  jacketTemperatureC: number;
  coolingHeatingRateCDegPerMin: number;
  homogeneityIndexPercent: number; // 0 to 100%
  pigmentDispersionPercent: number; // 0 to 100%
  mixingTimeSeconds: number;
  theoreticalMixingTime95Sec: number; // θ_95
  energyConsumedKWh: number;
  simulationConfidencePercent: number;
}
