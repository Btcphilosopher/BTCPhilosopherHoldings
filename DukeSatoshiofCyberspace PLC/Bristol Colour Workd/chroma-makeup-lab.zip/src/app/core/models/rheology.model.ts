export type RheologyModelType = 'herschel-bulkley' | 'power-law' | 'bingham' | 'carreau-yasuda' | 'newtonian';

export interface RheologyParameters {
  modelType: RheologyModelType;
  yieldStressPa: number; // tau_0 (Pa)
  consistencyIndexK: number; // K (Pa·s^n)
  flowBehaviorIndexN: number; // n (dimensionless, <1 = shear-thinning/pseudoplastic, >1 = dilatant, 1 = newtonian)
  zeroShearViscosityPaS?: number; // eta_0
  infiniteShearViscosityPaS?: number; // eta_inf
  relaxationTimeS?: number; // lambda (s)
  yasudaParameterA?: number; // a
  temperatureSensitivityEaKJ?: number; // Arrhenius activation energy kJ/mol
  thixotropicBreakdownAreaPaPerS?: number; // Hysteresis loop area (Pa/s)
}

export interface FlowCurvePoint {
  shearRatePerS: number; // gamma_dot (s^-1)
  shearStressPa: number; // tau (Pa)
  apparentViscosityPaS: number; // eta (Pa·s)
  apparentViscosityCP: number;  // cP = mPa·s
  downSweepStressPa?: number;   // for thixotropy loop
}

export interface RheologyFitResult {
  modelType: RheologyModelType;
  parameters: RheologyParameters;
  rSquared: number;
  standardError: number;
}
