export type ProductCategory = 
  | 'liquid-foundation' 
  | 'concealer' 
  | 'lipstick' 
  | 'lip-gloss' 
  | 'powder-blush' 
  | 'emulsion-cream';

export type IngredientPhase = 'A' | 'B' | 'C' | 'D'; // A: Water/Base, B: Oil/Waxes, C: Pigments, D: Actives/Preservatives

export type FunctionalCategory = 
  | 'pigment'
  | 'dye'
  | 'filler'
  | 'emollient'
  | 'oil'
  | 'wax'
  | 'emulsifier'
  | 'surfactant'
  | 'thickener'
  | 'film-former'
  | 'preservative'
  | 'humectant'
  | 'fragrance'
  | 'antioxidant'
  | 'solvent'
  | 'pearlescent';

export type RegulatoryJurisdiction = 'EU' | 'US' | 'UK';

export interface RegulatoryRestriction {
  jurisdiction: RegulatoryJurisdiction;
  maxConcentrationPercent: number; // e.g. 25% for TiO2, 0.5% for phenoxyethanol
  allowedCategories: ProductCategory[];
  prohibitedAreas?: string[]; // e.g. "not for eye area", "lip use restricted"
  regulationReference: string; // e.g. "EU Annex IV/143", "FDA 21 CFR 73.2575"
  effectiveDate: string;
}

export interface PigmentOpticalData {
  // Absorption (K) and Scattering (S) coefficients across visible wavelengths (400 - 700 nm, 16 sample points)
  wavelengths: number[]; // [400, 420, 440, ..., 700]
  K: number[]; // absorption coefficients (cm^-1 or dimensionless normalized)
  S: number[]; // scattering coefficients (cm^-1 or dimensionless normalized)
  refractiveIndex: number; // e.g., 2.74 for TiO2 (anatase), 3.0 for rutile, 2.4 for Fe2O3
  primaryParticleSizeNm: number; // e.g. 250 nm for TiO2, 100 nm for iron oxides
  baseColorHex: string; // approximate preview color
}

export interface Ingredient {
  id: string;
  inciName: string;
  tradeName: string;
  supplier: string;
  category: FunctionalCategory;
  defaultPhase: IngredientPhase;
  densityGPerCm3: number; // g/cm³ (kg/L)
  viscosityCPAt25C?: number; // cP = mPa·s if liquid
  meltingPointC?: number; // °C if solid/wax
  refractiveIndex?: number;
  costPerKgUSD: number;
  lotNumber: string;
  opticalData?: PigmentOpticalData;
  regulatoryRestrictions: RegulatoryRestriction[];
  safetyNotes: string;
  sustainabilityOrigin: 'Synthetic' | 'Mineral' | 'Plant-derived' | 'Biotech';
}

export interface FormulationItem {
  ingredientId: string;
  concentrationPercent: number; // 0 - 100%
  phase: IngredientPhase;
  additionOrder: number;
  targetTempC?: number;
}

export interface Formulation {
  id: string;
  name: string;
  version: string;
  productCategory: ProductCategory;
  description: string;
  batchSizeKg: number;
  items: FormulationItem[];
  targetCIELAB: {
    L: number;
    a: number;
    b: number;
  };
  targetViscosityCP: number;
  targetPH?: number;
  createdAt: string;
  status: 'Draft' | 'Pilot-Testing' | 'Approved' | 'Locked';
  approvedBy?: string;
}
