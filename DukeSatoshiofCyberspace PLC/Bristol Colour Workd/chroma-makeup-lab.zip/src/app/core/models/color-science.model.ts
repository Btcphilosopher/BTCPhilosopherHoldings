export interface ColorXYZ {
  X: number;
  Y: number;
  Z: number;
}

export interface ColorCIELAB {
  L: number; // 0 to 100
  a: number; // -128 to +127 (green to red)
  b: number; // -128 to +127 (blue to yellow)
}

export interface ColorCIELCh {
  L: number;
  C: number; // Chroma = sqrt(a² + b²)
  h: number; // Hue angle 0-360 deg
}

export type StandardIlluminant = 'D65' | 'A' | 'F2' | 'D50';

export interface IlluminantDefinition {
  id: StandardIlluminant;
  name: string;
  description: string;
  colorTemperatureK: number;
  whitePoint: ColorXYZ;
}

export interface FitzpatrickSkinTone {
  type: 'I' | 'II' | 'III' | 'IV' | 'V' | 'VI';
  description: string;
  lab: ColorCIELAB;
  hex: string;
  itaAngleDeg: number; // Individual Typology Angle: ITA = arctan((L - 50)/b) * 180 / π
}

export interface SpectralReflectance {
  wavelengths: number[]; // 400 - 700 nm
  reflectance: number[]; // 0.0 to 1.0 (R_inf)
  K_over_S: number[];    // (1 - R)² / (2R)
}

export interface ColorDifferenceDeltaE2000 {
  deltaE00: number;
  deltaLPrime: number;
  deltaCPrime: number;
  deltaHPrime: number;
  metamerismIndex: number; // Difference under Illuminant A vs D65
  isCommercialMatch: boolean; // DeltaE00 < 1.0 is standard cosmetic pass
}
