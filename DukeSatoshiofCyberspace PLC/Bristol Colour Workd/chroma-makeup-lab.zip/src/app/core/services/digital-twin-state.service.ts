import { Injectable, computed, inject, signal } from '@angular/core';
import { Formulation, FormulationItem, ProductCategory } from '../models/formulation.model';
import { ImpellerType, MixingTelemetry, VesselConfig } from '../models/mixing-physics.model';
import { ColorScienceService } from './color-science.service';
import { MixingPhysicsService } from './mixing-physics.service';
import { RheologyService } from './rheology.service';
import { IngredientDatabaseService } from './ingredient-database.service';
import { ColorCIELAB, StandardIlluminant } from '../models/color-science.model';
import { ProcessRecipeStep, SPCBatchMeasurement, StabilityTimepoint } from '../models/manufacturing.model';

export type LabTab = 
  | 'twin-mixer' 
  | 'formulation' 
  | 'shade-studio' 
  | 'rheology' 
  | 'manufacturing' 
  | 'quality-spc' 
  | 'doe-optimizer';

@Injectable({
  providedIn: 'root'
})
export class DigitalTwinStateService {
  private readonly colorScience = inject(ColorScienceService);
  private readonly mixingPhysics = inject(MixingPhysicsService);
  private readonly rheologyService = inject(RheologyService);
  private readonly db = inject(IngredientDatabaseService);

  // Active Navigation
  readonly activeTab = signal<LabTab>('twin-mixer');

  // Simulation controls
  readonly isSimulating = signal<boolean>(true);
  readonly simulationSpeedMultiplier = signal<number>(1.0);
  readonly simulationTimeSec = signal<number>(45.0);

  // Active Mixer parameters
  readonly rpm = signal<number>(450);
  readonly impellerType = signal<ImpellerType>('pitched-blade');
  readonly selectedVesselId = signal<string>('bench-5L');
  readonly jacketTempC = signal<number>(25.0);
  readonly batchTempC = signal<number>(26.2);

  // Optical & Substrate settings
  readonly activeIlluminant = signal<StandardIlluminant>('D65');
  readonly selectedSkinToneType = signal<'I' | 'II' | 'III' | 'IV' | 'V' | 'VI'>('III');
  readonly filmThicknessUm = signal<number>(25.0);

  // 3D Viewport modes
  readonly viewportMode = signal<'photorealistic' | 'concentration' | 'temperature' | 'velocity' | 'uniformity'>('photorealistic');
  readonly vesselTransparency = signal<number>(0.85);

  // Active Formulation
  readonly formulation = signal<Formulation>({
    id: 'FORM-FND-001',
    name: 'SkinLuxe Satin Foundation — Warm Bisque #25',
    version: '1.4.0',
    productCategory: 'liquid-foundation',
    description: 'High-spreadability water-in-silicone foundation with biomimetic pigment dispersion and Herschel-Bulkley stability matrix.',
    batchSizeKg: 2.5,
    createdAt: '2026-11-05',
    status: 'Approved',
    approvedBy: 'Dr. Elena Rostova, Lead Formulator',
    targetCIELAB: {
      L: 68.5,
      a: 13.2,
      b: 22.8
    },
    targetViscosityCP: 4200,
    targetPH: 6.8,
    items: [
      // Phase A - Aqueous & Humectants
      { ingredientId: 'ing_water_purified', concentrationPercent: 44.20, phase: 'A', additionOrder: 1 },
      { ingredientId: 'ing_glycerin', concentrationPercent: 4.50, phase: 'A', additionOrder: 2 },
      { ingredientId: 'ing_butylene_glycol', concentrationPercent: 3.50, phase: 'A', additionOrder: 3 },
      { ingredientId: 'ing_sodium_chloride', concentrationPercent: 0.80, phase: 'A', additionOrder: 4 },
      // Phase B - Silicones, Esters, Emulsifiers & Organoclay
      { ingredientId: 'ing_cyclopentasiloxane', concentrationPercent: 18.50, phase: 'B', additionOrder: 5 },
      { ingredientId: 'ing_dimethicone_5cs', concentrationPercent: 5.00, phase: 'B', additionOrder: 6 },
      { ingredientId: 'ing_caprylic_triglyceride', concentrationPercent: 4.50, phase: 'B', additionOrder: 7 },
      { ingredientId: 'ing_peg10_dimethicone', concentrationPercent: 3.20, phase: 'B', additionOrder: 8 },
      { ingredientId: 'ing_disteardimonium_hectorite', concentrationPercent: 1.80, phase: 'B', additionOrder: 9 },
      // Phase C - Color Grind (Titanium Dioxide & Iron Oxides)
      { ingredientId: 'ing_tio2_rutile', concentrationPercent: 9.80, phase: 'C', additionOrder: 10 },
      { ingredientId: 'ing_fe_yellow', concentrationPercent: 2.10, phase: 'C', additionOrder: 11 },
      { ingredientId: 'ing_fe_red', concentrationPercent: 0.72, phase: 'C', additionOrder: 12 },
      { ingredientId: 'ing_fe_black', concentrationPercent: 0.18, phase: 'C', additionOrder: 13 },
      // Phase D - Preservation & Antioxidants
      { ingredientId: 'ing_phenoxyethanol_blend', concentrationPercent: 1.00, phase: 'D', additionOrder: 14 },
      { ingredientId: 'ing_tocopherol', concentrationPercent: 0.20, phase: 'D', additionOrder: 15 }
    ]
  });

  // Master Process Recipe Steps
  readonly processSteps = signal<ProcessRecipeStep[]>([
    {
      stepNumber: 1,
      phaseId: 'Phase B',
      action: 'Charge',
      description: 'Charge silicones (D5, Dimethicone), emollients, and PEG-10 Dimethicone into main jacketed reactor.',
      targetTempC: 25,
      targetRpm: 150,
      impeller: 'pitched-blade',
      durationMinutes: 5,
      criticalQualityAttribute: 'Continuous phase uniformity'
    },
    {
      stepNumber: 2,
      phaseId: 'Phase B',
      action: 'Homogenize',
      description: 'Add Bentone Gel organoclay. Activate with high shear to establish Herschel-Bulkley yield stress network.',
      targetTempC: 28,
      targetRpm: 2500,
      impeller: 'high-shear-rotor-stator',
      durationMinutes: 10,
      criticalQualityAttribute: 'Yield stress τ₀ > 4.5 Pa'
    },
    {
      stepNumber: 3,
      phaseId: 'Phase C',
      action: 'Pigment-Grind',
      description: 'Disperse surface-treated pigments (TiO2, Yellow, Red, Black FeOx) under rotor-stator shear until Hegman gauge < 10 µm.',
      targetTempC: 32,
      targetRpm: 3200,
      impeller: 'high-shear-rotor-stator',
      durationMinutes: 20,
      criticalQualityAttribute: 'No agglomerates; Hegman gauge > 7'
    },
    {
      stepNumber: 4,
      phaseId: 'Phase A',
      action: 'Agitate',
      description: 'Slowly titrate premixed Phase A (Water + Polyols + NaCl) over 25 minutes to form tight W/Si emulsion droplets.',
      targetTempC: 26,
      targetRpm: 450,
      impeller: 'pitched-blade',
      durationMinutes: 25,
      criticalQualityAttribute: 'Droplet size d₃₂ < 2.5 µm'
    },
    {
      stepNumber: 5,
      phaseId: 'Phase D',
      action: 'Hold',
      description: 'Add phenoxyethanol preservative and tocopherol antioxidant. De-aerate under 0.8 bar vacuum.',
      targetTempC: 25,
      targetRpm: 200,
      impeller: 'anchor',
      durationMinutes: 15,
      criticalQualityAttribute: 'Air entrainment removed, density 1.02 g/cm³'
    },
    {
      stepNumber: 6,
      phaseId: 'Final QC',
      action: 'Sample-QC',
      description: 'Aseptically draw 100g sample for spectral colour measurement (ΔE₀₀ < 0.8), viscosity, and microbial validation.',
      targetTempC: 25,
      targetRpm: 0,
      impeller: 'pitched-blade',
      durationMinutes: 5,
      criticalQualityAttribute: 'Commercial release sign-off'
    }
  ]);

  // SPC Historical Batches
  readonly spcBatches = signal<SPCBatchMeasurement[]>([
    { batchNumber: 'LOT-2026-F01', timestamp: '2026-10-18', viscosityCP: 4180, deltaE00: 0.42, pH: 6.82, densityGPerCm3: 1.021, homogeneityPercent: 99.2, status: 'In-Spec' },
    { batchNumber: 'LOT-2026-F02', timestamp: '2026-10-21', viscosityCP: 4230, deltaE00: 0.61, pH: 6.80, densityGPerCm3: 1.022, homogeneityPercent: 98.9, status: 'In-Spec' },
    { batchNumber: 'LOT-2026-F03', timestamp: '2026-10-25', viscosityCP: 4110, deltaE00: 0.55, pH: 6.85, densityGPerCm3: 1.019, homogeneityPercent: 99.4, status: 'In-Spec' },
    { batchNumber: 'LOT-2026-F04', timestamp: '2026-10-29', viscosityCP: 4350, deltaE00: 0.78, pH: 6.78, densityGPerCm3: 1.023, homogeneityPercent: 98.5, status: 'In-Spec' },
    { batchNumber: 'LOT-2026-F05', timestamp: '2026-11-02', viscosityCP: 4210, deltaE00: 0.38, pH: 6.81, densityGPerCm3: 1.020, homogeneityPercent: 99.6, status: 'In-Spec' },
    { batchNumber: 'LOT-2026-F06', timestamp: '2026-11-05', viscosityCP: 4195, deltaE00: 0.49, pH: 6.82, densityGPerCm3: 1.021, homogeneityPercent: 99.1, status: 'In-Spec' }
  ]);

  // Accelerated Stability Tracking
  readonly stabilityTimepoints = signal<StabilityTimepoint[]>([
    { condition: '25C / 60% RH', timepointMonths: 1, viscosityRetentionPercent: 99.4, deltaE00Drift: 0.12, phaseSeparationObserved: false, sedimentationRisk: 'None', status: 'Pass' },
    { condition: '25C / 60% RH', timepointMonths: 3, viscosityRetentionPercent: 98.8, deltaE00Drift: 0.21, phaseSeparationObserved: false, sedimentationRisk: 'None', status: 'Pass' },
    { condition: '40C / 75% RH', timepointMonths: 1, viscosityRetentionPercent: 96.2, deltaE00Drift: 0.35, phaseSeparationObserved: false, sedimentationRisk: 'None', status: 'Pass' },
    { condition: '40C / 75% RH', timepointMonths: 3, viscosityRetentionPercent: 94.5, deltaE00Drift: 0.62, phaseSeparationObserved: false, sedimentationRisk: 'None', status: 'Pass' },
    { condition: '45C Stress', timepointMonths: 1, viscosityRetentionPercent: 91.8, deltaE00Drift: 0.85, phaseSeparationObserved: false, sedimentationRisk: 'Slight', status: 'Pass' },
    { condition: 'Freeze-Thaw (3 cycles)', timepointMonths: 0.5, viscosityRetentionPercent: 97.1, deltaE00Drift: 0.28, phaseSeparationObserved: false, sedimentationRisk: 'None', status: 'Pass' }
  ]);

  // ---------------- COMPUTED SIGNALS ----------------

  // Total concentration percentage check
  readonly totalConcentrationPercent = computed(() => {
    return Math.round(this.formulation().items.reduce((sum, item) => sum + item.concentrationPercent, 0) * 100) / 100;
  });

  // Total batch ingredient cost ($ USD)
  readonly batchCostUSD = computed(() => {
    const batchKg = this.formulation().batchSizeKg;
    let cost = 0;
    for (const item of this.formulation().items) {
      const ing = this.db.getIngredientById(item.ingredientId);
      if (ing) {
        const itemKg = batchKg * (item.concentrationPercent / 100.0);
        cost += itemKg * ing.costPerKgUSD;
      }
    }
    return Math.round(cost * 100) / 100;
  });

  readonly costPerKgUSD = computed(() => {
    const batchKg = this.formulation().batchSizeKg;
    return batchKg > 0 ? Math.round((this.batchCostUSD() / batchKg) * 100) / 100 : 0;
  });

  // Predicted Spectral Reflectance via Kubelka-Munk
  readonly spectralReflectance = computed(() => {
    return this.colorScience.calculateSpectralReflectance(this.formulation().items);
  });

  // Predicted Equilibrium CIELAB & Hex under active illuminant
  readonly predictedCIELAB = computed<ColorCIELAB>(() => {
    const spec = this.spectralReflectance();
    const xyz = this.colorScience.spectralToXYZ(spec.reflectance, this.activeIlluminant());
    return this.colorScience.xyzToLab(xyz, this.activeIlluminant());
  });

  readonly predictedColorHex = computed<string>(() => {
    return this.colorScience.labToHex(this.predictedCIELAB());
  });

  // CIEDE2000 ΔE00 against target shade
  readonly colorDifferenceDeltaE00 = computed(() => {
    return this.colorScience.calculateCIEDE2000(this.formulation().targetCIELAB, this.predictedCIELAB());
  });

  // Transient mixture color (taking into account partial pigment dispersion and homogeneity)
  readonly transientMixtureColorHex = computed<string>(() => {
    const telem = this.telemetry();
    const finalHex = this.predictedColorHex();
    const disp = telem.pigmentDispersionPercent / 100.0;
    const homo = telem.homogeneityIndexPercent / 100.0;

    // Early stage is whiter/unwetted base before full color development
    if (disp < 0.98 || homo < 0.98) {
      const targetLab = this.predictedCIELAB();
      // Un-dispersed pigment: higher lightness, lower chroma
      const transientLab: ColorCIELAB = {
        L: Math.min(95, targetLab.L + (1.0 - disp) * 18.0),
        a: targetLab.a * (0.3 + 0.7 * disp),
        b: targetLab.b * (0.3 + 0.7 * disp)
      };
      return this.colorScience.labToHex(transientLab);
    }
    return finalHex;
  });

  // Skin substrate film preview
  readonly skinPreview = computed(() => {
    const skinTone = this.colorScience.fitzpatrickSkinTones.find(s => s.type === this.selectedSkinToneType()) || this.colorScience.fitzpatrickSkinTones[2];
    return this.colorScience.blendFilmOverSkin(this.spectralReflectance().reflectance, skinTone, this.filmThicknessUm());
  });

  // Active vessel configuration
  readonly activeVessel = computed<VesselConfig>(() => {
    return this.mixingPhysics.defaultVessels[this.selectedVesselId()] || this.mixingPhysics.defaultVessels['bench-5L'];
  });

  // Active Rheology parameters
  readonly rheologyParameters = computed(() => {
    return this.rheologyService.getDefaultParametersForCategory(this.formulation().productCategory);
  });

  // Live Engineering Telemetry
  readonly telemetry = computed<MixingTelemetry>(() => {
    return this.mixingPhysics.calculateTelemetry(
      this.rpm(),
      this.impellerType(),
      this.activeVessel(),
      this.formulation().batchSizeKg,
      this.rheologyParameters(),
      this.batchTempC(),
      this.jacketTempC(),
      this.simulationTimeSec()
    );
  });

  // Regulatory Compliance Audit
  readonly regulatoryWarnings = computed(() => {
    const warnings: { ingredientName: string; issue: string; rule: string }[] = [];
    for (const item of this.formulation().items) {
      const ing = this.db.getIngredientById(item.ingredientId);
      if (!ing) continue;

      for (const reg of ing.regulatoryRestrictions) {
        if (item.concentrationPercent > reg.maxConcentrationPercent) {
          warnings.push({
            ingredientName: ing.inciName,
            issue: `Concentration (${item.concentrationPercent.toFixed(2)}%) exceeds ${reg.jurisdiction} maximum limit of ${reg.maxConcentrationPercent.toFixed(2)}%`,
            rule: reg.regulationReference
          });
        }
        if (reg.prohibitedAreas && reg.prohibitedAreas.length > 0) {
          warnings.push({
            ingredientName: ing.inciName,
            issue: reg.prohibitedAreas.join('; '),
            rule: reg.regulationReference
          });
        }
      }
    }
    return warnings;
  });

  // Simulation timer loop
  private timerHandle: number | null = null;

  constructor() {
    this.startSimulationClock();
  }

  private startSimulationClock() {
    if (typeof window !== 'undefined') {
      this.timerHandle = window.setInterval(() => {
        if (this.isSimulating()) {
          const dt = 0.5 * this.simulationSpeedMultiplier();
          this.simulationTimeSec.update(t => t + dt);

          // Update batch temperature slightly due to thermal jacket & viscous dissipation
          const telem = this.telemetry();
          const dT = (telem.coolingHeatingRateCDegPerMin / 60.0) * dt;
          this.batchTempC.update(cur => Math.max(15, Math.min(85, cur + dT)));
        }
      }, 500);
    }
  }

  // Action methods
  setTab(tab: LabTab) {
    this.activeTab.set(tab);
  }

  toggleSimulation() {
    this.isSimulating.update(v => !v);
  }

  resetSimulation() {
    this.simulationTimeSec.set(0);
    this.batchTempC.set(25.0);
  }

  setSimulationSpeed(speed: number) {
    this.simulationSpeedMultiplier.set(speed);
  }

  updateRpm(newRpm: number) {
    this.rpm.set(Math.max(0, Math.min(6000, newRpm)));
  }

  setImpeller(type: ImpellerType) {
    this.impellerType.set(type);
  }

  setJacketTemperature(tempC: number) {
    this.jacketTempC.set(tempC);
  }

  updateItemConcentration(ingredientId: string, percent: number) {
    this.formulation.update(form => {
      const items = form.items.map(item => {
        if (item.ingredientId === ingredientId) {
          return { ...item, concentrationPercent: Math.max(0, Math.min(100, Math.round(percent * 100) / 100)) };
        }
        return item;
      });
      return { ...form, items };
    });
  }

  addIngredientToFormulation(ingredientId: string) {
    const ing = this.db.getIngredientById(ingredientId);
    if (!ing) return;
    this.formulation.update(form => {
      if (form.items.some(i => i.ingredientId === ingredientId)) return form;
      const newItem: FormulationItem = {
        ingredientId,
        concentrationPercent: 1.0,
        phase: ing.defaultPhase,
        additionOrder: form.items.length + 1
      };
      return { ...form, items: [...form.items, newItem] };
    });
  }

  removeIngredientFromFormulation(ingredientId: string) {
    this.formulation.update(form => ({
      ...form,
      items: form.items.filter(i => i.ingredientId !== ingredientId)
    }));
  }

  normalizeFormulationTo100() {
    const total = this.totalConcentrationPercent();
    if (total <= 0) return;
    this.formulation.update(form => {
      const factor = 100.0 / total;
      const items = form.items.map(item => ({
        ...item,
        concentrationPercent: Math.round(item.concentrationPercent * factor * 100) / 100
      }));
      return { ...form, items };
    });
  }

  loadPreset(category: ProductCategory) {
    this.resetSimulation();
    switch (category) {
      case 'liquid-foundation':
        this.formulation.set({
          id: 'FORM-FND-001',
          name: 'SkinLuxe Satin Foundation — Warm Bisque #25',
          version: '1.4.0',
          productCategory: 'liquid-foundation',
          description: 'High-spreadability water-in-silicone foundation with biomimetic pigment dispersion and Herschel-Bulkley stability matrix.',
          batchSizeKg: 2.5,
          createdAt: '2026-11-05',
          status: 'Approved',
          approvedBy: 'Dr. Elena Rostova',
          targetCIELAB: { L: 68.5, a: 13.2, b: 22.8 },
          targetViscosityCP: 4200,
          items: [
            { ingredientId: 'ing_water_purified', concentrationPercent: 44.20, phase: 'A', additionOrder: 1 },
            { ingredientId: 'ing_glycerin', concentrationPercent: 4.50, phase: 'A', additionOrder: 2 },
            { ingredientId: 'ing_butylene_glycol', concentrationPercent: 3.50, phase: 'A', additionOrder: 3 },
            { ingredientId: 'ing_sodium_chloride', concentrationPercent: 0.80, phase: 'A', additionOrder: 4 },
            { ingredientId: 'ing_cyclopentasiloxane', concentrationPercent: 18.50, phase: 'B', additionOrder: 5 },
            { ingredientId: 'ing_dimethicone_5cs', concentrationPercent: 5.00, phase: 'B', additionOrder: 6 },
            { ingredientId: 'ing_caprylic_triglyceride', concentrationPercent: 4.50, phase: 'B', additionOrder: 7 },
            { ingredientId: 'ing_peg10_dimethicone', concentrationPercent: 3.20, phase: 'B', additionOrder: 8 },
            { ingredientId: 'ing_disteardimonium_hectorite', concentrationPercent: 1.80, phase: 'B', additionOrder: 9 },
            { ingredientId: 'ing_tio2_rutile', concentrationPercent: 9.80, phase: 'C', additionOrder: 10 },
            { ingredientId: 'ing_fe_yellow', concentrationPercent: 2.10, phase: 'C', additionOrder: 11 },
            { ingredientId: 'ing_fe_red', concentrationPercent: 0.72, phase: 'C', additionOrder: 12 },
            { ingredientId: 'ing_fe_black', concentrationPercent: 0.18, phase: 'C', additionOrder: 13 },
            { ingredientId: 'ing_phenoxyethanol_blend', concentrationPercent: 1.00, phase: 'D', additionOrder: 14 },
            { ingredientId: 'ing_tocopherol', concentrationPercent: 0.20, phase: 'D', additionOrder: 15 }
          ]
        });
        this.rpm.set(450);
        this.impellerType.set('pitched-blade');
        break;

      case 'concealer':
        this.formulation.set({
          id: 'FORM-CNC-002',
          name: 'Pro-Cover High Opacity Camouflage Concealer',
          version: '1.1.0',
          productCategory: 'concealer',
          description: 'High pigment loading (24%) with optical soft-focus sericite mica for extreme imperceptible coverage.',
          batchSizeKg: 1.0,
          createdAt: '2026-11-05',
          status: 'Pilot-Testing',
          targetCIELAB: { L: 66.0, a: 14.5, b: 24.2 },
          targetViscosityCP: 12500,
          items: [
            { ingredientId: 'ing_water_purified', concentrationPercent: 32.0, phase: 'A', additionOrder: 1 },
            { ingredientId: 'ing_glycerin', concentrationPercent: 5.0, phase: 'A', additionOrder: 2 },
            { ingredientId: 'ing_cyclopentasiloxane', concentrationPercent: 16.0, phase: 'B', additionOrder: 3 },
            { ingredientId: 'ing_caprylic_triglyceride', concentrationPercent: 8.5, phase: 'B', additionOrder: 4 },
            { ingredientId: 'ing_peg10_dimethicone', concentrationPercent: 4.5, phase: 'B', additionOrder: 5 },
            { ingredientId: 'ing_disteardimonium_hectorite', concentrationPercent: 2.5, phase: 'B', additionOrder: 6 },
            { ingredientId: 'ing_tio2_rutile', concentrationPercent: 17.5, phase: 'C', additionOrder: 7 },
            { ingredientId: 'ing_fe_yellow', concentrationPercent: 4.2, phase: 'C', additionOrder: 8 },
            { ingredientId: 'ing_fe_red', concentrationPercent: 1.6, phase: 'C', additionOrder: 9 },
            { ingredientId: 'ing_fe_black', concentrationPercent: 0.4, phase: 'C', additionOrder: 10 },
            { ingredientId: 'ing_mica_sericite', concentrationPercent: 6.6, phase: 'C', additionOrder: 11 },
            { ingredientId: 'ing_phenoxyethanol_blend', concentrationPercent: 1.0, phase: 'D', additionOrder: 12 },
            { ingredientId: 'ing_tocopherol', concentrationPercent: 0.2, phase: 'D', additionOrder: 13 }
          ]
        });
        this.rpm.set(1200);
        this.impellerType.set('high-shear-rotor-stator');
        break;

      case 'lipstick':
        this.formulation.set({
          id: 'FORM-LIP-003',
          name: 'Velvet Rouge Anhydrous Lipstick — Crimson Petal',
          version: '2.0.0',
          productCategory: 'lipstick',
          description: 'Structured microcrystalline carnauba & candelilla wax matrix with D&C Red 7 calcium lake.',
          batchSizeKg: 1.5,
          createdAt: '2026-11-05',
          status: 'Approved',
          targetCIELAB: { L: 42.0, a: 52.0, b: 24.0 },
          targetViscosityCP: 35000,
          items: [
            { ingredientId: 'ing_caprylic_triglyceride', concentrationPercent: 32.0, phase: 'B', additionOrder: 1 },
            { ingredientId: 'ing_jojoba_oil', concentrationPercent: 24.5, phase: 'B', additionOrder: 2 },
            { ingredientId: 'ing_carnauba_wax', concentrationPercent: 10.5, phase: 'B', additionOrder: 3 },
            { ingredientId: 'ing_candelilla_wax', concentrationPercent: 8.5, phase: 'B', additionOrder: 4 },
            { ingredientId: 'ing_beeswax', concentrationPercent: 6.0, phase: 'B', additionOrder: 5 },
            { ingredientId: 'ing_red_7_lake', concentrationPercent: 8.5, phase: 'C', additionOrder: 6 },
            { ingredientId: 'ing_fe_red', concentrationPercent: 3.2, phase: 'C', additionOrder: 7 },
            { ingredientId: 'ing_tio2_rutile', concentrationPercent: 4.5, phase: 'C', additionOrder: 8 },
            { ingredientId: 'ing_fe_black', concentrationPercent: 0.3, phase: 'C', additionOrder: 9 },
            { ingredientId: 'ing_mica_sericite', concentrationPercent: 1.5, phase: 'C', additionOrder: 10 },
            { ingredientId: 'ing_tocopherol', concentrationPercent: 0.5, phase: 'D', additionOrder: 11 }
          ]
        });
        this.rpm.set(180);
        this.impellerType.set('anchor');
        this.jacketTempC.set(82.0); // Melt temperature
        this.batchTempC.set(78.5);
        break;

      case 'powder-blush':
        this.formulation.set({
          id: 'FORM-BLS-004',
          name: 'Silken Mineral Powder Blush — Terracotta Rose',
          version: '1.0.0',
          productCategory: 'powder-blush',
          description: 'Dry pressed powder blend with surface-treated sericite mica platelets and iron oxides.',
          batchSizeKg: 5.0,
          createdAt: '2026-11-05',
          status: 'Approved',
          targetCIELAB: { L: 56.5, a: 28.2, b: 21.0 },
          targetViscosityCP: 100,
          items: [
            { ingredientId: 'ing_mica_sericite', concentrationPercent: 68.0, phase: 'C', additionOrder: 1 },
            { ingredientId: 'ing_tio2_rutile', concentrationPercent: 12.0, phase: 'C', additionOrder: 2 },
            { ingredientId: 'ing_fe_red', concentrationPercent: 6.5, phase: 'C', additionOrder: 3 },
            { ingredientId: 'ing_fe_yellow', concentrationPercent: 4.8, phase: 'C', additionOrder: 4 },
            { ingredientId: 'ing_red_7_lake', concentrationPercent: 2.2, phase: 'C', additionOrder: 5 },
            { ingredientId: 'ing_jojoba_oil', concentrationPercent: 5.0, phase: 'B', additionOrder: 6 }, // Liquid binder
            { ingredientId: 'ing_phenoxyethanol_blend', concentrationPercent: 1.0, phase: 'D', additionOrder: 7 },
            { ingredientId: 'ing_tocopherol', concentrationPercent: 0.5, phase: 'D', additionOrder: 8 }
          ]
        });
        this.rpm.set(85);
        this.impellerType.set('powder-tumble');
        break;

      case 'emulsion-cream':
      default:
        this.formulation.set({
          id: 'FORM-CRM-005',
          name: 'Ceramide Barrier Lamellar Cream O/W',
          version: '1.2.0',
          productCategory: 'emulsion-cream',
          description: 'Biomimetic liquid crystalline olivem emulsion with intense moisturizing polyols and skin-identical lipids.',
          batchSizeKg: 10.0,
          createdAt: '2026-11-05',
          status: 'Approved',
          targetCIELAB: { L: 94.0, a: -0.5, b: 2.5 },
          targetViscosityCP: 18500,
          items: [
            { ingredientId: 'ing_water_purified', concentrationPercent: 66.8, phase: 'A', additionOrder: 1 },
            { ingredientId: 'ing_glycerin', concentrationPercent: 6.0, phase: 'A', additionOrder: 2 },
            { ingredientId: 'ing_butylene_glycol', concentrationPercent: 4.0, phase: 'A', additionOrder: 3 },
            { ingredientId: 'ing_xanthan_gum', concentrationPercent: 0.4, phase: 'A', additionOrder: 4 },
            { ingredientId: 'ing_cetearyl_olivate', concentrationPercent: 4.5, phase: 'B', additionOrder: 5 },
            { ingredientId: 'ing_jojoba_oil', concentrationPercent: 8.0, phase: 'B', additionOrder: 6 },
            { ingredientId: 'ing_caprylic_triglyceride', concentrationPercent: 7.5, phase: 'B', additionOrder: 7 },
            { ingredientId: 'ing_beeswax', concentrationPercent: 1.5, phase: 'B', additionOrder: 8 },
            { ingredientId: 'ing_phenoxyethanol_blend', concentrationPercent: 1.0, phase: 'D', additionOrder: 9 },
            { ingredientId: 'ing_tocopherol', concentrationPercent: 0.3, phase: 'D', additionOrder: 10 }
          ]
        });
        this.rpm.set(650);
        this.impellerType.set('pitched-blade');
        break;
    }
  }

  optimizeShadeToTarget() {
    const opt = this.colorScience.optimizePigmentsForTargetShade(this.formulation().targetCIELAB);
    this.formulation.update(form => {
      const items = form.items.map(item => {
        if (item.ingredientId === 'ing_tio2_rutile') return { ...item, concentrationPercent: opt.tio2Percent };
        if (item.ingredientId === 'ing_fe_yellow') return { ...item, concentrationPercent: opt.yellowPercent };
        if (item.ingredientId === 'ing_fe_red') return { ...item, concentrationPercent: opt.redPercent };
        if (item.ingredientId === 'ing_fe_black') return { ...item, concentrationPercent: opt.blackPercent };
        return item;
      });
      return { ...form, items };
    });
    this.normalizeFormulationTo100();
  }

  recordNewSPCMeasurement(): SPCBatchMeasurement {
    const batchNum = `LOT-2026-F${(this.spcBatches().length + 1).toString().padStart(2, '0')}`;
    const curLab = this.predictedCIELAB();
    const de = this.colorScience.calculateCIEDE2000(this.formulation().targetCIELAB, curLab).deltaE00;
    const telem = this.telemetry();

    const newRecord: SPCBatchMeasurement = {
      batchNumber: batchNum,
      timestamp: new Date().toISOString().split('T')[0],
      viscosityCP: telem.apparentViscosityCP,
      deltaE00: de,
      pH: this.formulation().targetPH || 6.8,
      densityGPerCm3: 1.021,
      homogeneityPercent: telem.homogeneityIndexPercent,
      status: de <= 1.0 ? 'In-Spec' : 'Warning'
    };

    this.spcBatches.update(list => [...list, newRecord]);
    return newRecord;
  }
}
