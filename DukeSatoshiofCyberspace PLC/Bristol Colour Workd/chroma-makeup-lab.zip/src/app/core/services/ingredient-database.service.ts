import { Injectable } from '@angular/core';
import { Ingredient } from '../models/formulation.model';

@Injectable({
  providedIn: 'root'
})
export class IngredientDatabaseService {
  // Standard wavelengths for visible spectrum optical modelling (400 to 700 nm)
  readonly standardWavelengths = [400, 420, 440, 460, 480, 500, 520, 540, 560, 580, 600, 620, 640, 660, 680, 700];

  private readonly ingredients: Ingredient[] = [
    // ---------------- PIGMENTS (with calibrated Kubelka-Munk K and S spectral coefficients) ----------------
    {
      id: 'ing_tio2_rutile',
      inciName: 'Titanium Dioxide (CI 77891)',
      tradeName: 'Kobo Titan White R-902',
      supplier: 'Kobo Products',
      category: 'pigment',
      defaultPhase: 'C',
      densityGPerCm3: 4.23,
      refractiveIndex: 2.74,
      costPerKgUSD: 14.50,
      lotNumber: 'LOT-TiO2-2026-A1',
      sustainabilityOrigin: 'Mineral',
      safetyNotes: 'EU non-nano compliance documented. Inhalation risk mitigated via liquid dispersion.',
      opticalData: {
        wavelengths: this.standardWavelengths,
        // Extremely high scattering in visible, low absorption (absorbs in UV <410nm)
        K: [0.35, 0.15, 0.05, 0.02, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01],
        S: [2.10, 2.30, 2.45, 2.50, 2.45, 2.40, 2.30, 2.20, 2.10, 2.00, 1.90, 1.80, 1.70, 1.60, 1.50, 1.40],
        refractiveIndex: 2.74,
        primaryParticleSizeNm: 240,
        baseColorHex: '#FFFFFF'
      },
      regulatoryRestrictions: [
        {
          jurisdiction: 'EU',
          maxConcentrationPercent: 25.0,
          allowedCategories: ['liquid-foundation', 'concealer', 'lipstick', 'lip-gloss', 'powder-blush', 'emulsion-cream'],
          regulationReference: 'Regulation (EC) No 1223/2009 Annex IV/143',
          effectiveDate: '2024-01-01'
        },
        {
          jurisdiction: 'US',
          maxConcentrationPercent: 25.0,
          allowedCategories: ['liquid-foundation', 'concealer', 'lipstick', 'lip-gloss', 'powder-blush', 'emulsion-cream'],
          regulationReference: 'FDA 21 CFR 73.2575',
          effectiveDate: '2024-01-01'
        }
      ]
    },
    {
      id: 'ing_fe_yellow',
      inciName: 'Iron Oxide Yellow (CI 77492)',
      tradeName: 'Cosmetic Yellow Ox Y-50',
      supplier: 'Sensient Beauty',
      category: 'pigment',
      defaultPhase: 'C',
      densityGPerCm3: 4.05,
      refractiveIndex: 2.35,
      costPerKgUSD: 28.00,
      lotNumber: 'LOT-YEL-2026-08',
      sustainabilityOrigin: 'Mineral',
      safetyNotes: 'Synthetic high-purity iron oxide. Heavy metals tested below EU/FDA cosmetic limits.',
      opticalData: {
        wavelengths: this.standardWavelengths,
        // Absorbs strongly in blue/violet (400-500nm), scatters/reflects in yellow/red (>550nm)
        K: [2.80, 2.60, 2.30, 1.85, 1.20, 0.60, 0.25, 0.12, 0.08, 0.06, 0.05, 0.04, 0.04, 0.03, 0.03, 0.03],
        S: [0.40, 0.45, 0.50, 0.60, 0.75, 0.90, 1.05, 1.15, 1.20, 1.22, 1.20, 1.18, 1.15, 1.10, 1.05, 1.00],
        refractiveIndex: 2.35,
        primaryParticleSizeNm: 150,
        baseColorHex: '#E2A93B'
      },
      regulatoryRestrictions: [
        {
          jurisdiction: 'EU',
          maxConcentrationPercent: 15.0,
          allowedCategories: ['liquid-foundation', 'concealer', 'lipstick', 'lip-gloss', 'powder-blush', 'emulsion-cream'],
          regulationReference: 'Annex IV/140',
          effectiveDate: '2024-01-01'
        }
      ]
    },
    {
      id: 'ing_fe_red',
      inciName: 'Iron Oxide Red (CI 77491)',
      tradeName: 'Unipure Red LC381',
      supplier: 'Sensient Beauty',
      category: 'pigment',
      defaultPhase: 'C',
      densityGPerCm3: 5.24,
      refractiveIndex: 2.95,
      costPerKgUSD: 32.50,
      lotNumber: 'LOT-RED-2026-11',
      sustainabilityOrigin: 'Mineral',
      safetyNotes: 'Compliant with purity criteria directive. Dispersible in ester and oil phase.',
      opticalData: {
        wavelengths: this.standardWavelengths,
        // Absorbs blue and green (<580nm), transmits/reflects red (>600nm)
        K: [2.90, 2.85, 2.75, 2.65, 2.50, 2.35, 2.10, 1.70, 0.95, 0.45, 0.20, 0.10, 0.08, 0.06, 0.05, 0.05],
        S: [0.35, 0.38, 0.42, 0.48, 0.55, 0.65, 0.78, 0.95, 1.10, 1.25, 1.30, 1.28, 1.25, 1.20, 1.15, 1.10],
        refractiveIndex: 2.95,
        primaryParticleSizeNm: 120,
        baseColorHex: '#A8322D'
      },
      regulatoryRestrictions: [
        {
          jurisdiction: 'EU',
          maxConcentrationPercent: 15.0,
          allowedCategories: ['liquid-foundation', 'concealer', 'lipstick', 'lip-gloss', 'powder-blush', 'emulsion-cream'],
          regulationReference: 'Annex IV/141',
          effectiveDate: '2024-01-01'
        }
      ]
    },
    {
      id: 'ing_fe_black',
      inciName: 'Iron Oxide Black (CI 77499)',
      tradeName: 'Cosmetic Black Ox B-99',
      supplier: 'Sun Chemical',
      category: 'pigment',
      defaultPhase: 'C',
      densityGPerCm3: 4.95,
      refractiveIndex: 2.42,
      costPerKgUSD: 36.00,
      lotNumber: 'LOT-BLK-2026-03',
      sustainabilityOrigin: 'Mineral',
      safetyNotes: 'High tinting strength Fe3O4. Pre-milled pigment paste recommended to prevent streaking.',
      opticalData: {
        wavelengths: this.standardWavelengths,
        // Uniform high absorption across entire visible spectrum
        K: [3.40, 3.35, 3.30, 3.25, 3.20, 3.15, 3.10, 3.05, 3.00, 2.95, 2.90, 2.85, 2.80, 2.75, 2.70, 2.65],
        S: [0.15, 0.15, 0.15, 0.15, 0.14, 0.14, 0.14, 0.13, 0.13, 0.12, 0.12, 0.11, 0.11, 0.10, 0.10, 0.10],
        refractiveIndex: 2.42,
        primaryParticleSizeNm: 90,
        baseColorHex: '#222326'
      },
      regulatoryRestrictions: [
        {
          jurisdiction: 'EU',
          maxConcentrationPercent: 15.0,
          allowedCategories: ['liquid-foundation', 'concealer', 'lipstick', 'lip-gloss', 'powder-blush', 'emulsion-cream'],
          regulationReference: 'Annex IV/142',
          effectiveDate: '2024-01-01'
        }
      ]
    },
    {
      id: 'ing_ultramarine_blue',
      inciName: 'Ultramarines (CI 77007)',
      tradeName: 'Ultramarine Blue U-71',
      supplier: 'Nubiola / Ferro',
      category: 'pigment',
      defaultPhase: 'C',
      densityGPerCm3: 2.35,
      refractiveIndex: 1.51,
      costPerKgUSD: 45.00,
      lotNumber: 'LOT-UMB-2026-02',
      sustainabilityOrigin: 'Mineral',
      safetyNotes: 'Not stable in acidic media (pH < 6.0 generates H2S). Foundation pH must be buffered >= 6.5.',
      opticalData: {
        wavelengths: this.standardWavelengths,
        // High reflectance/scattering in blue (420-480nm), strong absorption in yellow/red (>560nm)
        K: [0.45, 0.20, 0.10, 0.25, 0.85, 1.65, 2.40, 2.80, 2.95, 3.10, 3.15, 3.10, 2.90, 2.50, 2.10, 1.70],
        S: [1.10, 1.15, 1.20, 1.15, 1.05, 0.90, 0.75, 0.65, 0.55, 0.50, 0.45, 0.42, 0.40, 0.38, 0.35, 0.35],
        refractiveIndex: 1.51,
        primaryParticleSizeNm: 300,
        baseColorHex: '#2E4C9D'
      },
      regulatoryRestrictions: [
        {
          jurisdiction: 'US',
          maxConcentrationPercent: 10.0,
          allowedCategories: ['liquid-foundation', 'concealer', 'powder-blush', 'emulsion-cream'],
          prohibitedAreas: ['Not permitted in lip products in the US (FDA 21 CFR 73.2725)'],
          regulationReference: 'FDA 21 CFR 73.2725',
          effectiveDate: '2024-01-01'
        },
        {
          jurisdiction: 'EU',
          maxConcentrationPercent: 15.0,
          allowedCategories: ['liquid-foundation', 'concealer', 'lipstick', 'lip-gloss', 'powder-blush', 'emulsion-cream'],
          regulationReference: 'Annex IV/144',
          effectiveDate: '2024-01-01'
        }
      ]
    },
    {
      id: 'ing_red_7_lake',
      inciName: 'Red 7 Lake (CI 15850:1)',
      tradeName: 'D&C Red No. 7 Calcium Lake',
      supplier: 'Sun Chemical',
      category: 'pigment',
      defaultPhase: 'C',
      densityGPerCm3: 1.80,
      refractiveIndex: 1.65,
      costPerKgUSD: 68.00,
      lotNumber: 'LOT-R7-2026-05',
      sustainabilityOrigin: 'Synthetic',
      safetyNotes: 'Vibrant blue-undertone organic red lake. Approved for lips and face.',
      opticalData: {
        wavelengths: this.standardWavelengths,
        K: [2.50, 2.60, 2.70, 2.75, 2.80, 2.85, 2.90, 2.60, 1.80, 0.80, 0.25, 0.08, 0.05, 0.04, 0.04, 0.04],
        S: [0.20, 0.22, 0.25, 0.28, 0.32, 0.38, 0.45, 0.55, 0.70, 0.85, 0.95, 0.98, 0.95, 0.90, 0.88, 0.85],
        refractiveIndex: 1.65,
        primaryParticleSizeNm: 80,
        baseColorHex: '#C91D3E'
      },
      regulatoryRestrictions: [
        {
          jurisdiction: 'EU',
          maxConcentrationPercent: 8.0,
          allowedCategories: ['lipstick', 'lip-gloss', 'powder-blush', 'liquid-foundation'],
          regulationReference: 'Annex IV/84',
          effectiveDate: '2024-01-01'
        }
      ]
    },
    {
      id: 'ing_mica_sericite',
      inciName: 'Mica (and) Triethoxycaprylylsilane',
      tradeName: 'Sericite FSE Silane Treated',
      supplier: 'Kobo Products',
      category: 'filler',
      defaultPhase: 'C',
      densityGPerCm3: 2.82,
      refractiveIndex: 1.58,
      costPerKgUSD: 22.00,
      lotNumber: 'LOT-MIC-2026-04',
      sustainabilityOrigin: 'Mineral',
      safetyNotes: 'Hydrophobic silane coating ensures wetting in silicone/oil continuous phase.',
      opticalData: {
        wavelengths: this.standardWavelengths,
        K: [0.05, 0.04, 0.03, 0.03, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02],
        S: [0.85, 0.82, 0.80, 0.78, 0.75, 0.72, 0.70, 0.68, 0.65, 0.62, 0.60, 0.58, 0.55, 0.52, 0.50, 0.48],
        refractiveIndex: 1.58,
        primaryParticleSizeNm: 8500, // 8.5 um platelet
        baseColorHex: '#F6F6F4'
      },
      regulatoryRestrictions: []
    },

    // ---------------- BASE LIQUIDS, SOLVENTS & WATER PHASE ----------------
    {
      id: 'ing_water_purified',
      inciName: 'Aqua (Purified Deionized Water)',
      tradeName: 'USP Purified Water',
      supplier: 'In-House Pharmaceutical Osmosis',
      category: 'solvent',
      defaultPhase: 'A',
      densityGPerCm3: 1.00,
      viscosityCPAt25C: 1.0,
      refractiveIndex: 1.333,
      costPerKgUSD: 0.15,
      lotNumber: 'LOT-WTR-2026-DAILY',
      sustainabilityOrigin: 'Mineral',
      safetyNotes: 'Conductivity < 1.3 uS/cm. Bioburden < 10 CFU/100 mL.',
      regulatoryRestrictions: []
    },
    {
      id: 'ing_glycerin',
      inciName: 'Glycerin',
      tradeName: 'Pricerine 9091 Vegetable Glycerin 99.7%',
      supplier: 'Croda Beauty',
      category: 'humectant',
      defaultPhase: 'A',
      densityGPerCm3: 1.26,
      viscosityCPAt25C: 1412.0,
      refractiveIndex: 1.474,
      costPerKgUSD: 3.20,
      lotNumber: 'LOT-GLY-2026-10',
      sustainabilityOrigin: 'Plant-derived',
      safetyNotes: 'USP grade humectant. Maintains skin hydration and continuous phase plasticization.',
      regulatoryRestrictions: []
    },
    {
      id: 'ing_butylene_glycol',
      inciName: 'Butylene Glycol',
      tradeName: '1,3-Butylene Glycol Cosmetic Grade',
      supplier: 'Daicel Corporation',
      category: 'humectant',
      defaultPhase: 'A',
      densityGPerCm3: 1.005,
      viscosityCPAt25C: 103.0,
      refractiveIndex: 1.440,
      costPerKgUSD: 5.50,
      lotNumber: 'LOT-BG-2026-07',
      sustainabilityOrigin: 'Biotech',
      safetyNotes: 'Skin conditioning and freeze-thaw stability agent for emulsions.',
      regulatoryRestrictions: []
    },

    // ---------------- EMOLLIENTS, SILICONES & OILS (PHASE B) ----------------
    {
      id: 'ing_cyclopentasiloxane',
      inciName: 'Cyclopentasiloxane (D5)',
      tradeName: 'Xiameter PMX-0245 Cyclosiloxane',
      supplier: 'Dow Chemical',
      category: 'emollient',
      defaultPhase: 'B',
      densityGPerCm3: 0.96,
      viscosityCPAt25C: 4.0,
      refractiveIndex: 1.396,
      costPerKgUSD: 8.50,
      lotNumber: 'LOT-D5-2026-01',
      sustainabilityOrigin: 'Synthetic',
      safetyNotes: 'EU Regulation 2018/35 restricts wash-off to <0.1%. Permitted in leave-on foundations.',
      regulatoryRestrictions: [
        {
          jurisdiction: 'EU',
          maxConcentrationPercent: 70.0,
          allowedCategories: ['liquid-foundation', 'concealer', 'lipstick', 'lip-gloss', 'emulsion-cream'],
          regulationReference: 'REACH Annex XVII Entry 70 (Leave-on cosmetic allowed)',
          effectiveDate: '2020-01-31'
        }
      ]
    },
    {
      id: 'ing_dimethicone_5cs',
      inciName: 'Dimethicone (5 cSt)',
      tradeName: 'Belsil DM 5 Fluid',
      supplier: 'Wacker Chemie',
      category: 'emollient',
      defaultPhase: 'B',
      densityGPerCm3: 0.915,
      viscosityCPAt25C: 5.0,
      refractiveIndex: 1.397,
      costPerKgUSD: 9.80,
      lotNumber: 'LOT-DM5-2026-09',
      sustainabilityOrigin: 'Synthetic',
      safetyNotes: 'Linear volatile silicone replacement for smooth non-greasy cushion spread.',
      regulatoryRestrictions: []
    },
    {
      id: 'ing_caprylic_triglyceride',
      inciName: 'Caprylic/Capric Triglyceride',
      tradeName: 'Tegosoft CT',
      supplier: 'Evonik Industries',
      category: 'emollient',
      defaultPhase: 'B',
      densityGPerCm3: 0.945,
      viscosityCPAt25C: 28.0,
      refractiveIndex: 1.449,
      costPerKgUSD: 7.20,
      lotNumber: 'LOT-CCT-2026-06',
      sustainabilityOrigin: 'Plant-derived',
      safetyNotes: 'Medium spreading polar ester oil. Excellent pigment wetting agent.',
      regulatoryRestrictions: []
    },
    {
      id: 'ing_isononyl_isononanoate',
      inciName: 'Isononyl Isononanoate',
      tradeName: 'DUB ININ',
      supplier: 'Stearinerie Dubois',
      category: 'emollient',
      defaultPhase: 'B',
      densityGPerCm3: 0.855,
      viscosityCPAt25C: 5.5,
      refractiveIndex: 1.436,
      costPerKgUSD: 11.20,
      lotNumber: 'LOT-ININ-2026-03',
      sustainabilityOrigin: 'Synthetic',
      safetyNotes: 'Dry-touch featherlight ester, enhances glide without greasy residual film.',
      regulatoryRestrictions: []
    },
    {
      id: 'ing_jojoba_oil',
      inciName: 'Simmondsia Chinensis (Jojoba) Seed Oil',
      tradeName: 'Desert Whale Golden Jojoba Oil',
      supplier: 'Vantage Specialty',
      category: 'oil',
      defaultPhase: 'B',
      densityGPerCm3: 0.865,
      viscosityCPAt25C: 35.0,
      refractiveIndex: 1.465,
      costPerKgUSD: 24.00,
      lotNumber: 'LOT-JOB-2026-02',
      sustainabilityOrigin: 'Plant-derived',
      safetyNotes: 'Liquid wax ester, biomimetic to human sebum. Highly oxidative stable.',
      regulatoryRestrictions: []
    },

    // ---------------- WAXES & SOLID STRUCTURANTS (FOR LIPSTICKS & BALMS) ----------------
    {
      id: 'ing_carnauba_wax',
      inciName: 'Copernicia Cerifera (Carnauba) Wax',
      tradeName: 'Carnauba T1 Pure Prime Yellow',
      supplier: 'Koster Keunen',
      category: 'wax',
      defaultPhase: 'B',
      densityGPerCm3: 0.99,
      meltingPointC: 84.0,
      costPerKgUSD: 34.00,
      lotNumber: 'LOT-CAR-2026-05',
      sustainabilityOrigin: 'Plant-derived',
      safetyNotes: 'High melting point structurant, provides stick rigidity, thermal stability and high gloss.',
      regulatoryRestrictions: []
    },
    {
      id: 'ing_candelilla_wax',
      inciName: 'Euphorbia Cerifera (Candelilla) Wax',
      tradeName: 'Refined Candelilla Wax SP-75',
      supplier: 'Strahl & Pitsch',
      category: 'wax',
      defaultPhase: 'B',
      densityGPerCm3: 0.98,
      meltingPointC: 70.0,
      costPerKgUSD: 26.50,
      lotNumber: 'LOT-CAN-2026-08',
      sustainabilityOrigin: 'Plant-derived',
      safetyNotes: 'Prevents sweating and syneresis in molded anhydrous sticks.',
      regulatoryRestrictions: []
    },
    {
      id: 'ing_beeswax',
      inciName: 'Cera Alba (Beeswax)',
      tradeName: 'White Pure Beeswax Pellets',
      supplier: 'Koster Keunen',
      category: 'wax',
      defaultPhase: 'B',
      densityGPerCm3: 0.96,
      meltingPointC: 63.5,
      costPerKgUSD: 21.00,
      lotNumber: 'LOT-BEES-2026-04',
      sustainabilityOrigin: 'Plant-derived',
      safetyNotes: 'Plasticizing wax with branched hydrocarbons, ensures smooth mold release.',
      regulatoryRestrictions: []
    },

    // ---------------- EMULSIFIERS & DISPERSANTS ----------------
    {
      id: 'ing_peg10_dimethicone',
      inciName: 'PEG-10 Dimethicone',
      tradeName: 'KF-6017 Polyether-Modified Silicone',
      supplier: 'Shin-Etsu Silicones',
      category: 'emulsifier',
      defaultPhase: 'B',
      densityGPerCm3: 1.01,
      viscosityCPAt25C: 650.0,
      refractiveIndex: 1.412,
      costPerKgUSD: 38.00,
      lotNumber: 'LOT-KF6017-2026',
      sustainabilityOrigin: 'Synthetic',
      safetyNotes: 'W/Si (Water-in-Silicone) primary emulsifier. HLB ~ 4.5. Provides exceptional emulsion stability.',
      regulatoryRestrictions: []
    },
    {
      id: 'ing_cetearyl_olivate',
      inciName: 'Cetearyl Olivate (and) Sorbitan Olivate',
      tradeName: 'Olivem 1000 Crystal Emulsifier',
      supplier: 'Hallstar Beauty',
      category: 'emulsifier',
      defaultPhase: 'B',
      densityGPerCm3: 0.95,
      meltingPointC: 68.0,
      costPerKgUSD: 29.50,
      lotNumber: 'LOT-OLIV-2026-07',
      sustainabilityOrigin: 'Plant-derived',
      safetyNotes: 'Forms biomimetic liquid crystalline lamellar gel networks in O/W emulsions.',
      regulatoryRestrictions: []
    },
    {
      id: 'ing_polyglyceryl4_isostearate',
      inciName: 'Polyglyceryl-4 Isostearate',
      tradeName: 'Isolan GI 34',
      supplier: 'Evonik Industries',
      category: 'emulsifier',
      defaultPhase: 'B',
      densityGPerCm3: 0.98,
      viscosityCPAt25C: 1100.0,
      refractiveIndex: 1.470,
      costPerKgUSD: 31.00,
      lotNumber: 'LOT-P4I-2026-01',
      sustainabilityOrigin: 'Plant-derived',
      safetyNotes: 'Non-PEG W/O high-performance emulsifier. Excellent cold-flow and freeze-thaw resistance.',
      regulatoryRestrictions: []
    },

    // ---------------- THICKENERS & RHEOLOGY MODIFIERS ----------------
    {
      id: 'ing_disteardimonium_hectorite',
      inciName: 'Disteardimonium Hectorite (and) Propylene Carbonate',
      tradeName: 'Bentone Gel ISD V Organoclay',
      supplier: 'Elementis Specialties',
      category: 'thickener',
      defaultPhase: 'B',
      densityGPerCm3: 1.02,
      viscosityCPAt25C: 85000.0,
      costPerKgUSD: 44.00,
      lotNumber: 'LOT-BEN-2026-10',
      sustainabilityOrigin: 'Mineral',
      safetyNotes: 'Organoclay gel provides Herschel-Bulkley high yield stress (tau_0 > 15 Pa) preventing pigment settling.',
      regulatoryRestrictions: []
    },
    {
      id: 'ing_xanthan_gum',
      inciName: 'Xanthan Gum',
      tradeName: 'Keltrol CG-SFT Soft Xanthan',
      supplier: 'CP Kelco',
      category: 'thickener',
      defaultPhase: 'A',
      densityGPerCm3: 1.50,
      costPerKgUSD: 18.00,
      lotNumber: 'LOT-XAN-2026-04',
      sustainabilityOrigin: 'Biotech',
      safetyNotes: 'Pseudoplastic natural polysaccharide with strong shear-thinning (n ~ 0.20). Hydrate in water with high shear.',
      regulatoryRestrictions: []
    },
    {
      id: 'ing_carbomer',
      inciName: 'Carbomer (crosslinked polyacrylate)',
      tradeName: 'Carbopol Ultrez 30 Polymer',
      supplier: 'Lubrizol Advanced Materials',
      category: 'thickener',
      defaultPhase: 'A',
      densityGPerCm3: 1.40,
      costPerKgUSD: 24.50,
      lotNumber: 'LOT-CARB-2026-08',
      sustainabilityOrigin: 'Synthetic',
      safetyNotes: 'Requires neutralization with Triethanolamine or NaOH to pH 6.0-7.0 to uncoil polymer chains.',
      regulatoryRestrictions: []
    },

    // ---------------- PRESERVATIVES, ANTIOXIDANTS & ACTIVES (PHASE D) ----------------
    {
      id: 'ing_phenoxyethanol_blend',
      inciName: 'Phenoxyethanol (and) Ethylhexylglycerin',
      tradeName: 'Euxyl PE 9010 Broad Spectrum',
      supplier: 'Schülke & Mayr',
      category: 'preservative',
      defaultPhase: 'D',
      densityGPerCm3: 1.079,
      viscosityCPAt25C: 25.0,
      costPerKgUSD: 22.00,
      lotNumber: 'LOT-PE9010-2026',
      sustainabilityOrigin: 'Synthetic',
      safetyNotes: 'EU Regulation 1223/2009 Annex V: Max 1.0% Phenoxyethanol. Broad spectrum against bacteria and fungi.',
      regulatoryRestrictions: [
        {
          jurisdiction: 'EU',
          maxConcentrationPercent: 1.1, // yields max 1.0% phenoxyethanol
          allowedCategories: ['liquid-foundation', 'concealer', 'lipstick', 'lip-gloss', 'powder-blush', 'emulsion-cream'],
          regulationReference: 'Regulation (EC) No 1223/2009 Annex V/29',
          effectiveDate: '2024-01-01'
        },
        {
          jurisdiction: 'US',
          maxConcentrationPercent: 1.1,
          allowedCategories: ['liquid-foundation', 'concealer', 'lipstick', 'lip-gloss', 'powder-blush', 'emulsion-cream'],
          regulationReference: 'CIR Safety Assessment 2021',
          effectiveDate: '2024-01-01'
        }
      ]
    },
    {
      id: 'ing_tocopherol',
      inciName: 'Tocopherol (Natural Vitamin E)',
      tradeName: 'Covi-ox T-70 EU Mixed Tocopherols',
      supplier: 'BASF Care Creations',
      category: 'antioxidant',
      defaultPhase: 'D',
      densityGPerCm3: 0.95,
      viscosityCPAt25C: 4500.0,
      costPerKgUSD: 52.00,
      lotNumber: 'LOT-TOC-2026-02',
      sustainabilityOrigin: 'Plant-derived',
      safetyNotes: 'Lipophilic antioxidant prevents rancidity and oxidation of unsaturated fatty acids and esters.',
      regulatoryRestrictions: []
    },
    {
      id: 'ing_sodium_chloride',
      inciName: 'Sodium Chloride (Electrolyte)',
      tradeName: 'High Purity Vacuum Salt USP',
      supplier: 'AkzoNobel / Nouryon',
      category: 'preservative',
      defaultPhase: 'A',
      densityGPerCm3: 2.16,
      costPerKgUSD: 0.85,
      lotNumber: 'LOT-NACL-2026',
      sustainabilityOrigin: 'Mineral',
      safetyNotes: 'Essential electrolyte in W/Si and W/O emulsions (0.5 - 1.0%) to prevent osmotic swelling and coalescence.',
      regulatoryRestrictions: []
    }
  ];

  getAllIngredients(): Ingredient[] {
    return [...this.ingredients];
  }

  getIngredientById(id: string): Ingredient | undefined {
    return this.ingredients.find(i => i.id === id);
  }

  getPigments(): Ingredient[] {
    return this.ingredients.filter(i => i.category === 'pigment');
  }

  getIngredientsByCategory(category: string): Ingredient[] {
    return this.ingredients.filter(i => i.category === category);
  }
}
