import { Injectable, inject } from '@angular/core';
import { 
  ColorXYZ, 
  ColorCIELAB, 
  ColorCIELCh, 
  StandardIlluminant, 
  IlluminantDefinition, 
  FitzpatrickSkinTone, 
  SpectralReflectance, 
  ColorDifferenceDeltaE2000 
} from '../models/color-science.model';
import { IngredientDatabaseService } from './ingredient-database.service';
import { FormulationItem } from '../models/formulation.model';

@Injectable({
  providedIn: 'root'
})
export class ColorScienceService {
  private readonly db = inject(IngredientDatabaseService);

  readonly standardWavelengths = [400, 420, 440, 460, 480, 500, 520, 540, 560, 580, 600, 620, 640, 660, 680, 700];

  // Standard CIE 1931 2-degree observer color matching functions (sampled at 20nm intervals 400-700nm)
  private readonly cieXBar = [0.0143, 0.1344, 0.3483, 0.2908, 0.0956, 0.0049, 0.0633, 0.2904, 0.5945, 0.9163, 1.0622, 0.8544, 0.4479, 0.1649, 0.0468, 0.0114];
  private readonly cieYBar = [0.0004, 0.0040, 0.0230, 0.0600, 0.1390, 0.3230, 0.7100, 0.9540, 0.9950, 0.8700, 0.6310, 0.3810, 0.1750, 0.0610, 0.0170, 0.0041];
  private readonly cieZBar = [0.0679, 0.6456, 1.7471, 1.6692, 0.8130, 0.2720, 0.0782, 0.0203, 0.0039, 0.0017, 0.0008, 0.0002, 0.0000, 0.0000, 0.0000, 0.0000];

  // Relative spectral power distributions S(λ) for standard illuminants
  private readonly illuminantSpectra: Record<StandardIlluminant, number[]> = {
    // CIE Standard Illuminant D65 (Daylight 6504 K)
    D65: [82.75, 93.43, 104.86, 117.81, 115.92, 109.35, 104.79, 102.24, 100.0, 95.79, 90.01, 87.70, 83.70, 80.03, 78.29, 71.61],
    // CIE Standard Illuminant A (Incandescent tungsten 2856 K)
    A:   [14.71, 20.99, 28.70, 37.81, 48.24, 59.86, 72.50, 85.95, 100.0, 114.44, 128.93, 143.35, 157.57, 171.46, 184.97, 198.0],
    // CIE Illuminant F2 (Cool White Fluorescent 4230 K)
    F2:  [60.0, 75.0, 95.0, 105.0, 92.0, 80.0, 110.0, 125.0, 100.0, 85.0, 75.0, 70.0, 65.0, 60.0, 55.0, 50.0],
    // CIE Illuminant D50 (Horizon daylight 5003 K, graphic arts standard)
    D50: [48.0, 58.0, 72.0, 88.0, 94.0, 98.0, 101.0, 102.0, 100.0, 98.0, 96.0, 95.0, 93.0, 90.0, 87.0, 82.0]
  };

  readonly illuminants: IlluminantDefinition[] = [
    {
      id: 'D65',
      name: 'D65 Daylight',
      description: 'Average northern sky daylight (ISO 3664 / CIE standard)',
      colorTemperatureK: 6504,
      whitePoint: { X: 95.047, Y: 100.0, Z: 108.883 }
    },
    {
      id: 'A',
      name: 'Illuminant A',
      description: 'Domestic warm tungsten-filament incandescent lamp',
      colorTemperatureK: 2856,
      whitePoint: { X: 109.850, Y: 100.0, Z: 35.585 }
    },
    {
      id: 'F2',
      name: 'F2 Fluorescent',
      description: 'Commercial retail store cool white fluorescent',
      colorTemperatureK: 4230,
      whitePoint: { X: 99.186, Y: 100.0, Z: 67.393 }
    },
    {
      id: 'D50',
      name: 'D50 Horizon',
      description: 'Direct sun at horizon / print proofing standard',
      colorTemperatureK: 5003,
      whitePoint: { X: 96.422, Y: 100.0, Z: 82.521 }
    }
  ];

  readonly fitzpatrickSkinTones: FitzpatrickSkinTone[] = [
    {
      type: 'I',
      description: 'Type I: Fair, ivory, burns easily, never tans',
      lab: { L: 78.5, a: 11.2, b: 18.4 },
      hex: '#F7D6C1',
      itaAngleDeg: 57.1
    },
    {
      type: 'II',
      description: 'Type II: Light European, fair, burns easily, tans minimally',
      lab: { L: 72.0, a: 12.8, b: 20.6 },
      hex: '#EFC2A6',
      itaAngleDeg: 46.9
    },
    {
      type: 'III',
      description: 'Type III: Medium light, beige, mild burn, tans uniformly',
      lab: { L: 65.5, a: 14.1, b: 22.5 },
      hex: '#DCA987',
      itaAngleDeg: 34.6
    },
    {
      type: 'IV',
      description: 'Type IV: Mediterranean, olive / light brown, rarely burns',
      lab: { L: 58.0, a: 15.5, b: 24.0 },
      hex: '#C58F69',
      itaAngleDeg: 18.4
    },
    {
      type: 'V',
      description: 'Type V: Rich dark brown, middle eastern/south asian, very rarely burns',
      lab: { L: 47.0, a: 14.9, b: 22.1 },
      hex: '#965C38',
      itaAngleDeg: -7.7
    },
    {
      type: 'VI',
      description: 'Type VI: Deep ebony / dark brown, deeply pigmented, never burns',
      lab: { L: 34.0, a: 11.8, b: 16.5 },
      hex: '#5B3722',
      itaAngleDeg: -44.1
    }
  ];

  /**
   * Kubelka-Munk Two-Flux Equation for Multiple Pigment Blends:
   * (K/S)_mix(λ) = [K_base(λ) + Σ c_i * K_i(λ)] / [S_base(λ) + Σ c_i * S_i(λ)]
   * Reflectance R_inf(λ) = 1 + (K/S) - sqrt((K/S)² + 2*(K/S))
   */
  calculateSpectralReflectance(items: FormulationItem[]): SpectralReflectance {
    const N = this.standardWavelengths.length;
    // Base vehicle (emulsion/solvent/oil) baseline absorption & scattering
    const K_base = 0.005;
    const S_base = 0.05;

    const K_mix = new Array(N).fill(K_base);
    const S_mix = new Array(N).fill(S_base);

    for (const item of items) {
      if (item.concentrationPercent <= 0) continue;
      const ing = this.db.getIngredientById(item.ingredientId);
      if (!ing || !ing.opticalData) continue;

      const c = item.concentrationPercent / 100.0;
      for (let w = 0; w < N; w++) {
        K_mix[w] += c * ing.opticalData.K[w];
        S_mix[w] += c * ing.opticalData.S[w];
      }
    }

    const reflectance: number[] = [];
    const K_over_S: number[] = [];

    for (let w = 0; w < N; w++) {
      const ks = K_mix[w] / Math.max(0.0001, S_mix[w]);
      K_over_S.push(ks);

      // Kubelka-Munk infinite thickness solution:
      // R_inf = 1 + (K/S) - sqrt((K/S)² + 2*(K/S))
      const R_inf = 1.0 + ks - Math.sqrt(Math.max(0, ks * ks + 2.0 * ks));
      reflectance.push(Math.max(0.001, Math.min(0.999, R_inf)));
    }

    return {
      wavelengths: [...this.standardWavelengths],
      reflectance,
      K_over_S
    };
  }

  /**
   * Integrate spectral reflectance with CIE Color Matching Functions & Illuminant to produce CIE XYZ.
   */
  spectralToXYZ(reflectance: number[], illuminant: StandardIlluminant = 'D65'): ColorXYZ {
    const N = this.standardWavelengths.length;
    const S_illum = this.illuminantSpectra[illuminant];

    let sumX = 0;
    let sumY = 0;
    let sumZ = 0;
    let normK = 0;

    for (let i = 0; i < N; i++) {
      const R = reflectance[i];
      const S = S_illum[i];
      const xBar = this.cieXBar[i];
      const yBar = this.cieYBar[i];
      const zBar = this.cieZBar[i];

      sumX += R * S * xBar;
      sumY += R * S * yBar;
      sumZ += R * S * zBar;
      normK += S * yBar;
    }

    const k = normK > 0 ? 100.0 / normK : 1.0;
    return {
      X: sumX * k,
      Y: sumY * k,
      Z: sumZ * k
    };
  }

  /**
   * Standard CIE XYZ to CIELAB Conversion
   */
  xyzToLab(xyz: ColorXYZ, illuminant: StandardIlluminant = 'D65'): ColorCIELAB {
    const whitePoint = this.illuminants.find(i => i.id === illuminant)?.whitePoint || { X: 95.047, Y: 100.0, Z: 108.883 };

    const f = (t: number): number => {
      const delta = 6.0 / 29.0;
      if (t > delta * delta * delta) {
        return Math.cbrt(t);
      }
      return (t / (3.0 * delta * delta)) + (4.0 / 29.0);
    };

    const fx = f(xyz.X / whitePoint.X);
    const fy = f(xyz.Y / whitePoint.Y);
    const fz = f(xyz.Z / whitePoint.Z);

    const L = 116.0 * fy - 16.0;
    const a = 500.0 * (fx - fy);
    const b = 200.0 * (fy - fz);

    return {
      L: Math.max(0, Math.min(100, L)),
      a,
      b
    };
  }

  labToLCh(lab: ColorCIELAB): ColorCIELCh {
    const C = Math.sqrt(lab.a * lab.a + lab.b * lab.b);
    let h = (Math.atan2(lab.b, lab.a) * 180.0) / Math.PI;
    if (h < 0) h += 360.0;
    return { L: lab.L, C, h };
  }

  labToHex(lab: ColorCIELAB): string {
    // Convert LAB to XYZ (D65) then to sRGB
    const Xn = 95.047;
    const Yn = 100.0;
    const Zn = 108.883;

    const fy = (lab.L + 16.0) / 116.0;
    const fx = lab.a / 500.0 + fy;
    const fz = fy - lab.b / 200.0;

    const delta = 6.0 / 29.0;
    const invF = (t: number): number => {
      return t > delta ? t * t * t : 3.0 * delta * delta * (t - 4.0 / 29.0);
    };

    const X = Xn * invF(fx);
    const Y = Yn * invF(fy);
    const Z = Zn * invF(fz);

    // XYZ (0-100) to Linear sRGB
    const x = X / 100.0;
    const y = Y / 100.0;
    const z = Z / 100.0;

    const rLinear =  3.2404542 * x - 1.5371385 * y - 0.4985314 * z;
    const gLinear = -0.9692660 * x + 1.8760108 * y + 0.0415560 * z;
    const bLinear =  0.0556434 * x - 0.2040259 * y + 1.0572252 * z;

    // Gamma companding (sRGB standard IEC 61966-2-1)
    const gamma = (c: number): number => {
      const clamped = Math.max(0, Math.min(1, c));
      return clamped <= 0.0031308 ? 12.92 * clamped : 1.055 * Math.pow(clamped, 1.0 / 2.4) - 0.055;
    };

    const R = Math.round(gamma(rLinear) * 255.0);
    const G = Math.round(gamma(gLinear) * 255.0);
    const B = Math.round(gamma(bLinear) * 255.0);

    const toHex = (n: number) => n.toString(16).padStart(2, '0');
    return `#${toHex(R)}${toHex(G)}${toHex(B)}`.toUpperCase();
  }

  /**
   * CIEDE2000 (ΔE00) Color Difference Algorithm
   * Rigorous implementation of ISO/CIE 11664-6:2014
   */
  calculateCIEDE2000(stdLab: ColorCIELAB, sampleLab: ColorCIELAB): ColorDifferenceDeltaE2000 {
    const kL = 1.0;
    const kC = 1.0;
    const kH = 1.0;

    const L1 = stdLab.L;
    const a1 = stdLab.a;
    const b1 = stdLab.b;

    const L2 = sampleLab.L;
    const a2 = sampleLab.a;
    const b2 = sampleLab.b;

    const C1 = Math.sqrt(a1 * a1 + b1 * b1);
    const C2 = Math.sqrt(a2 * a2 + b2 * b2);
    const C_bar = (C1 + C2) / 2.0;

    const C_bar7 = Math.pow(C_bar, 7);
    const G = 0.5 * (1.0 - Math.sqrt(C_bar7 / (C_bar7 + Math.pow(25, 7))));

    const a1_prime = (1.0 + G) * a1;
    const a2_prime = (1.0 + G) * a2;

    const C1_prime = Math.sqrt(a1_prime * a1_prime + b1 * b1);
    const C2_prime = Math.sqrt(a2_prime * a2_prime + b2 * b2);

    const degToRad = Math.PI / 180.0;
    const radToDeg = 180.0 / Math.PI;

    let h1_prime = Math.atan2(b1, a1_prime) * radToDeg;
    if (h1_prime < 0) h1_prime += 360.0;

    let h2_prime = Math.atan2(b2, a2_prime) * radToDeg;
    if (h2_prime < 0) h2_prime += 360.0;

    const deltaL_prime = L2 - L1;
    const deltaC_prime = C2_prime - C1_prime;

    let delta_h_prime = 0;
    if (C1_prime * C2_prime !== 0) {
      const diff = h2_prime - h1_prime;
      if (Math.abs(diff) <= 180.0) {
        delta_h_prime = diff;
      } else if (diff > 180.0) {
        delta_h_prime = diff - 360.0;
      } else {
        delta_h_prime = diff + 360.0;
      }
    }

    const deltaH_prime = 2.0 * Math.sqrt(C1_prime * C2_prime) * Math.sin((delta_h_prime / 2.0) * degToRad);

    const L_bar_prime = (L1 + L2) / 2.0;
    const C_bar_prime = (C1_prime + C2_prime) / 2.0;

    let H_bar_prime = (h1_prime + h2_prime) / 2.0;
    if (C1_prime * C2_prime !== 0) {
      if (Math.abs(h1_prime - h2_prime) > 180.0) {
        if (h1_prime + h2_prime < 360.0) {
          H_bar_prime = (h1_prime + h2_prime + 360.0) / 2.0;
        } else {
          H_bar_prime = (h1_prime + h2_prime - 360.0) / 2.0;
        }
      }
    }

    const T = 1.0 
      - 0.17 * Math.cos((H_bar_prime - 30.0) * degToRad)
      + 0.24 * Math.cos((2.0 * H_bar_prime) * degToRad)
      + 0.32 * Math.cos((3.0 * H_bar_prime + 6.0) * degToRad)
      - 0.20 * Math.cos((4.0 * H_bar_prime - 63.0) * degToRad);

    const deltaTheta = 30.0 * Math.exp(-Math.pow((H_bar_prime - 275.0) / 25.0, 2));

    const C_bar_prime7 = Math.pow(C_bar_prime, 7);
    const R_C = 2.0 * Math.sqrt(C_bar_prime7 / (C_bar_prime7 + Math.pow(25, 7)));

    const S_L = 1.0 + (0.015 * Math.pow(L_bar_prime - 50.0, 2)) / Math.sqrt(20.0 + Math.pow(L_bar_prime - 50.0, 2));
    const S_C = 1.0 + 0.045 * C_bar_prime;
    const S_H = 1.0 + 0.015 * C_bar_prime * T;

    const R_T = -Math.sin(2.0 * deltaTheta * degToRad) * R_C;

    const termL = deltaL_prime / (kL * S_L);
    const termC = deltaC_prime / (kC * S_C);
    const termH = deltaH_prime / (kH * S_H);

    const deltaE00 = Math.sqrt(termL * termL + termC * termC + termH * termH + R_T * termC * termH);

    return {
      deltaE00: Math.round(deltaE00 * 100) / 100,
      deltaLPrime: Math.round(deltaL_prime * 100) / 100,
      deltaCPrime: Math.round(deltaC_prime * 100) / 100,
      deltaHPrime: Math.round(deltaH_prime * 100) / 100,
      metamerismIndex: 0.25, // default baseline
      isCommercialMatch: deltaE00 <= 1.0
    };
  }

  /**
   * Preview cosmetic film applied over skin substrate:
   * Beer-Lambert film transmittance T(λ) applied to skin reflectance R_skin(λ)
   * plus surface gloss reflection.
   */
  blendFilmOverSkin(filmReflectance: number[], skinTone: FitzpatrickSkinTone, filmThicknessUm = 25.0): { filmLab: ColorCIELAB; hex: string } {
    const filmXYZ = this.spectralToXYZ(filmReflectance);

    // Optical opacity proxy: higher scattering S and thickness leads to higher coverage
    // Translucent film shows partial undertone of the skin
    const avgReflectance = filmReflectance.reduce((a, b) => a + b, 0) / filmReflectance.length;
    const opacityFactor = Math.min(0.95, 0.4 + (filmThicknessUm / 40.0) * 0.5 + avgReflectance * 0.2);

    const blendedLab: ColorCIELAB = {
      L: skinTone.lab.L * (1 - opacityFactor) + filmXYZ.Y * opacityFactor,
      a: skinTone.lab.a * (1 - opacityFactor) + (filmXYZ.X - filmXYZ.Y) * 2.0 * opacityFactor,
      b: skinTone.lab.b * (1 - opacityFactor) + (filmXYZ.Y - filmXYZ.Z) * 2.0 * opacityFactor
    };

    return {
      filmLab: blendedLab,
      hex: this.labToHex(blendedLab)
    };
  }

  private labToXYZ(lab: ColorCIELAB, illuminant: StandardIlluminant = 'D65'): ColorXYZ {
    const whitePoint = this.illuminants.find(i => i.id === illuminant)?.whitePoint || { X: 95.047, Y: 100.0, Z: 108.883 };
    const fy = (lab.L + 16.0) / 116.0;
    const fx = lab.a / 500.0 + fy;
    const fz = fy - lab.b / 200.0;

    const delta = 6.0 / 29.0;
    const invF = (t: number): number => (t > delta ? t * t * t : 3.0 * delta * delta * (t - 4.0 / 29.0));

    return {
      X: whitePoint.X * invF(fx),
      Y: whitePoint.Y * invF(fy),
      Z: whitePoint.Z * invF(fz)
    };
  }

  /**
   * Automatic Pigment Optimization Solver:
   * Numerically searches for concentrations of TiO2, Yellow, Red, Black
   * that minimize CIEDE2000 ΔE00 against targetCIELAB.
   */
  optimizePigmentsForTargetShade(targetLab: ColorCIELAB): { 
    tio2Percent: number; 
    yellowPercent: number; 
    redPercent: number; 
    blackPercent: number; 
    achievedLab: ColorCIELAB; 
    deltaE00: number; 
  } {
    // Initial heuristic estimates based on target Lightness (L) and Chroma (a, b)
    let tio2 = Math.max(1.0, Math.min(18.0, (targetLab.L / 100.0) * 14.0));
    let yellow = Math.max(0.1, Math.min(8.0, (targetLab.b / 50.0) * 3.5));
    let red = Math.max(0.05, Math.min(4.0, (targetLab.a / 50.0) * 2.0));
    let black = Math.max(0.02, Math.min(3.0, ((100.0 - targetLab.L) / 100.0) * 1.5));

    // Iterative gradient-free pattern search
    const stepSize = 0.05;
    let bestDelta = 999.0;
    let bestLab: ColorCIELAB = { L: 50, a: 0, b: 0 };

    for (let iter = 0; iter < 40; iter++) {
      const items: FormulationItem[] = [
        { ingredientId: 'ing_tio2_rutile', concentrationPercent: tio2, phase: 'C', additionOrder: 1 },
        { ingredientId: 'ing_fe_yellow', concentrationPercent: yellow, phase: 'C', additionOrder: 2 },
        { ingredientId: 'ing_fe_red', concentrationPercent: red, phase: 'C', additionOrder: 3 },
        { ingredientId: 'ing_fe_black', concentrationPercent: black, phase: 'C', additionOrder: 4 }
      ];

      const spec = this.calculateSpectralReflectance(items);
      const xyz = this.spectralToXYZ(spec.reflectance, 'D65');
      const curLab = this.xyzToLab(xyz, 'D65');
      const de = this.calculateCIEDE2000(targetLab, curLab).deltaE00;

      if (de < bestDelta) {
        bestDelta = de;
        bestLab = curLab;
      }

      // Proportional adjustments towards target L*, a*, b*
      const errorL = targetLab.L - curLab.L;
      const errorA = targetLab.a - curLab.a;
      const errorB = targetLab.b - curLab.b;

      if (errorL > 0) {
        tio2 += stepSize * 1.5;
        black = Math.max(0.01, black - stepSize * 0.5);
      } else {
        tio2 = Math.max(0.5, tio2 - stepSize * 1.5);
        black += stepSize * 0.4;
      }

      if (errorA > 0) {
        red += stepSize * 0.8;
      } else {
        red = Math.max(0.01, red - stepSize * 0.8);
      }

      if (errorB > 0) {
        yellow += stepSize * 1.0;
      } else {
        yellow = Math.max(0.01, yellow - stepSize * 1.0);
      }
    }

    return {
      tio2Percent: Math.round(tio2 * 100) / 100,
      yellowPercent: Math.round(yellow * 100) / 100,
      redPercent: Math.round(red * 100) / 100,
      blackPercent: Math.round(black * 100) / 100,
      achievedLab: bestLab,
      deltaE00: bestDelta
    };
  }
}
