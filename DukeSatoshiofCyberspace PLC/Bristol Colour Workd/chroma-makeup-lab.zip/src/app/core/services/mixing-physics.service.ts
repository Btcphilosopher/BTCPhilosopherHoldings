import { Injectable, inject } from '@angular/core';
import { ImpellerConfig, ImpellerType, MixingTelemetry, VesselConfig } from '../models/mixing-physics.model';
import { RheologyService } from './rheology.service';
import { RheologyParameters } from '../models/rheology.model';

@Injectable({
  providedIn: 'root'
})
export class MixingPhysicsService {
  private readonly rheologyService = inject(RheologyService);

  readonly impellers: Record<ImpellerType, ImpellerConfig> = {
    'rushton-turbine': {
      type: 'rushton-turbine',
      name: 'Rushton Disc Turbine (6-Blade)',
      description: 'Standard radial flow turbine. High shear dispersion, excellent for gas-liquid and initial pigment breakdown.',
      diameterRatioD_over_T: 0.35,
      powerNumberTurbulentNp: 5.2,
      laminarConstantKl: 70.0,
      shearIntensityProxy: 8.5,
      pumpingNumberNq: 0.75
    },
    'pitched-blade': {
      type: 'pitched-blade',
      name: '45° Pitched Blade Turbine (PBT-4)',
      description: 'Axial/radial mixed flow. Excellent bulk circulation and solids suspension with moderate power draw.',
      diameterRatioD_over_T: 0.40,
      powerNumberTurbulentNp: 1.30,
      laminarConstantKl: 45.0,
      shearIntensityProxy: 4.8,
      pumpingNumberNq: 0.85
    },
    'marine-propeller': {
      type: 'marine-propeller',
      name: 'Marine Propeller (3-Blade)',
      description: 'High axial pumping efficiency, low shear. Best for rapid bulk circulation of low to medium viscosity fluids.',
      diameterRatioD_over_T: 0.30,
      powerNumberTurbulentNp: 0.38,
      laminarConstantKl: 32.0,
      shearIntensityProxy: 2.5,
      pumpingNumberNq: 0.65
    },
    'anchor': {
      type: 'anchor',
      name: 'Anchor Impeller with Wall Scrapers',
      description: 'Close-clearance laminar impeller. Prevents wall boundary layer stagnation and enhances jacket heat transfer in viscous lotions.',
      diameterRatioD_over_T: 0.92,
      powerNumberTurbulentNp: 0.85,
      laminarConstantKl: 420.0,
      shearIntensityProxy: 3.2,
      pumpingNumberNq: 0.40
    },
    'high-shear-rotor-stator': {
      type: 'high-shear-rotor-stator',
      name: 'Rotor-Stator High Shear Homogenizer',
      description: 'Ultra-high shear gap (0.25mm) generating 20,000-100,000 s^-1. Sub-micron droplet breakup and rapid pigment deagglomeration.',
      diameterRatioD_over_T: 0.25,
      powerNumberTurbulentNp: 3.8,
      laminarConstantKl: 120.0,
      shearIntensityProxy: 10.0,
      pumpingNumberNq: 0.45
    },
    'planetary-double': {
      type: 'planetary-double',
      name: 'Double Planetary Blade',
      description: 'Dual orbiting helical blades for high-viscosity pastes, lipsticks, and heavy concealers without dead zones.',
      diameterRatioD_over_T: 0.80,
      powerNumberTurbulentNp: 2.1,
      laminarConstantKl: 350.0,
      shearIntensityProxy: 6.5,
      pumpingNumberNq: 0.60
    },
    'powder-tumble': {
      type: 'powder-tumble',
      name: 'V-Blender / Tumble Powder Mixer',
      description: 'Low-shear gentle tumble blender for dry powder blush and pearlescent mica formulations without particle fracturing.',
      diameterRatioD_over_T: 0.50,
      powerNumberTurbulentNp: 0.5,
      laminarConstantKl: 50.0,
      shearIntensityProxy: 2.0,
      pumpingNumberNq: 0.30
    }
  };

  readonly defaultVessels: Record<string, VesselConfig> = {
    'bench-5L': {
      id: 'bench-5L',
      name: 'Laboratory 5L Borosilicate Glass Reactor',
      diameterMeters: 0.16, // 16 cm
      heightMeters: 0.28,   // 28 cm
      maxWorkingVolumeLiters: 4.0,
      hasBaffles: true,
      baffleCount: 4,
      jacketHeatTransferAreaM2: 0.12,
      heatTransferCoefficientU: 180.0, // W/(m²·K) glass
      material: 'Borosilicate-Glass'
    },
    'pilot-50L': {
      id: 'pilot-50L',
      name: 'Pilot 50L 316L Stainless Steel Bioreactor',
      diameterMeters: 0.38,
      heightMeters: 0.65,
      maxWorkingVolumeLiters: 45.0,
      hasBaffles: true,
      baffleCount: 4,
      jacketHeatTransferAreaM2: 0.75,
      heatTransferCoefficientU: 450.0, // W/(m²·K) polished SS
      material: '316L-Stainless-Steel'
    },
    'plant-1000L': {
      id: 'plant-1000L',
      name: 'Industrial 1,000L Vacuum Processing Plant',
      diameterMeters: 1.10,
      heightMeters: 1.55,
      maxWorkingVolumeLiters: 900.0,
      hasBaffles: true,
      baffleCount: 4,
      jacketHeatTransferAreaM2: 4.80,
      heatTransferCoefficientU: 520.0,
      material: '316L-Stainless-Steel'
    }
  };

  /**
   * Metzner-Otto constant k_s for impeller type:
   * Average shear rate in vessel: γ̇_avg = k_s * N
   */
  getMetznerOttoConstant(impellerType: ImpellerType): number {
    switch (impellerType) {
      case 'rushton-turbine': return 11.5;
      case 'pitched-blade': return 10.0;
      case 'marine-propeller': return 9.0;
      case 'anchor': return 24.5;
      case 'high-shear-rotor-stator': return 55.0;
      case 'planetary-double': return 30.0;
      case 'powder-tumble': return 6.0;
    }
  }

  /**
   * Calculate complete engineering telemetry step
   */
  calculateTelemetry(
    rpm: number,
    impellerType: ImpellerType,
    vessel: VesselConfig,
    batchMassKg: number,
    rheologyParams: RheologyParameters,
    currentTempC: number,
    jacketTempC: number,
    elapsedTimeSec: number
  ): MixingTelemetry {
    const impeller = this.impellers[impellerType];
    const N = Math.max(0.01, rpm / 60.0); // rev / s
    const T = vessel.diameterMeters;
    const D = T * impeller.diameterRatioD_over_T; // Impeller diameter (m)

    // Metzner-Otto shear rate
    const ks = this.getMetznerOttoConstant(impellerType);
    const shearRate = ks * N; // s^-1

    // Apparent viscosity at vessel shear rate & temperature
    const apparentViscosityCP = this.rheologyService.calculateApparentViscosityCP(shearRate, rheologyParams, currentTempC);
    const muPaS = Math.max(0.0005, apparentViscosityCP / 1000.0); // Pa·s

    // Formulation density (average cosmetic emulsion ~ 1020 kg/m³)
    const rho = 1020.0;

    // Reynolds Number: Re = ρ * N * D² / μ
    const reynoldsNumber = (rho * N * D * D) / muPaS;

    let flowRegime: 'Laminar' | 'Transitional' | 'Turbulent' = 'Transitional';
    if (reynoldsNumber < 20) {
      flowRegime = 'Laminar';
    } else if (reynoldsNumber > 4000) {
      flowRegime = 'Turbulent';
    }

    // Power Number Np Calculation across flow regimes
    let Np: number;
    if (reynoldsNumber < 10) {
      // Pure laminar: Np = Kl / Re
      Np = impeller.laminarConstantKl / Math.max(0.1, reynoldsNumber);
    } else if (reynoldsNumber > 10000) {
      // Fully turbulent
      Np = impeller.powerNumberTurbulentNp;
    } else {
      // Transitional regime logarithmic interpolation
      const logRe = Math.log10(reynoldsNumber);
      const frac = (logRe - 1.0) / 3.0; // 0 at Re=10, 1 at Re=10000
      const Np_lam = impeller.laminarConstantKl / reynoldsNumber;
      const Np_turb = impeller.powerNumberTurbulentNp;
      Np = Math.max(Np_turb, Np_lam * (1 - frac) + Np_turb * frac);
    }

    // Mixing Power (P = Np * ρ * N³ * D⁵)
    const mixingPowerWatts = Np * rho * Math.pow(N, 3) * Math.pow(D, 5);

    // Tip Speed (v_tip = π * N * D)
    const tipSpeedMPerS = Math.PI * N * D;

    // Torque (T = P / (2πN))
    const torqueNewtonMeters = mixingPowerWatts / (2.0 * Math.PI * N);

    // Theoretical 95% Mixing Time correlation (θ_95)
    // For turbulent baffled tank: N * θ_95 ≈ 5.9 * (T/D)² * (H/D)^0.5
    const H = vessel.heightMeters;
    const geomFactor = 5.9 * Math.pow(T / D, 2) * Math.sqrt(H / D);
    const lamFactor = flowRegime === 'Laminar' ? 12.0 : (flowRegime === 'Transitional' ? 3.0 : 1.0);
    const theoreticalMixingTime95Sec = Math.max(5.0, (geomFactor * lamFactor) / N);

    // Thermal balance: viscous dissipation heating + jacket convective transfer
    // dQ/dt = P + U * A * (T_jacket - T_batch)
    // dT/dt = dQ/dt / (m * c_p)
    const cp = 3400.0; // J/(kg·K) cosmetic emulsion specific heat
    const Q_dissipation = mixingPowerWatts * 0.95; // 95% converted to fluid heat
    const Q_jacket = vessel.jacketHeatTransferAreaM2 * vessel.heatTransferCoefficientU * (jacketTempC - currentTempC);
    const totalQWatts = Q_dissipation + Q_jacket;
    const dTdtDegCPerSec = totalQWatts / (batchMassKg * cp);
    const coolingHeatingRateCDegPerMin = dTdtDegCPerSec * 60.0;

    // Progressive Homogeneity kinetics (exponential approach to 100%)
    const tauMix = theoreticalMixingTime95Sec / 3.0;
    const homogeneityIndexPercent = Math.min(100.0, (1.0 - Math.exp(-elapsedTimeSec / Math.max(1.0, tauMix))) * 100.0);

    // Progressive Pigment Dispersion kinetics
    // Driven by localized blade tip shear stress: τ_max = μ * (π * N * D / gap)
    const shearIntensity = impeller.shearIntensityProxy;
    const kDisp = 0.008 * (shearIntensity / 5.0) * Math.sqrt(N / 5.0);
    const pigmentDispersionPercent = Math.min(100.0, (1.0 - Math.exp(-kDisp * elapsedTimeSec)) * 100.0);

    // Cumulative energy consumed (kWh)
    const energyConsumedKWh = (mixingPowerWatts * (elapsedTimeSec / 3600.0)) / 1000.0;

    return {
      rpm,
      revolutionsPerSec: Math.round(N * 100) / 100,
      tipSpeedMPerS: Math.round(tipSpeedMPerS * 100) / 100,
      reynoldsNumber: Math.round(reynoldsNumber),
      flowRegime,
      powerNumberNp: Math.round(Np * 100) / 100,
      mixingPowerWatts: Math.round(mixingPowerWatts * 10) / 10,
      torqueNewtonMeters: Math.round(torqueNewtonMeters * 100) / 100,
      apparentViscosityCP: Math.round(apparentViscosityCP),
      shearRatePerS: Math.round(shearRate * 10) / 10,
      batchTemperatureC: Math.round(currentTempC * 10) / 10,
      jacketTemperatureC: Math.round(jacketTempC * 10) / 10,
      coolingHeatingRateCDegPerMin: Math.round(coolingHeatingRateCDegPerMin * 100) / 100,
      homogeneityIndexPercent: Math.round(homogeneityIndexPercent * 10) / 10,
      pigmentDispersionPercent: Math.round(pigmentDispersionPercent * 10) / 10,
      mixingTimeSeconds: Math.round(elapsedTimeSec),
      theoreticalMixingTime95Sec: Math.round(theoreticalMixingTime95Sec),
      energyConsumedKWh: Math.round(energyConsumedKWh * 1000) / 1000,
      simulationConfidencePercent: flowRegime === 'Turbulent' ? 96.5 : (flowRegime === 'Transitional' ? 88.0 : 82.5)
    };
  }

  /**
   * Scale-Up analysis from laboratory bench to manufacturing plant:
   * Evaluates Constant Power per Unit Volume (P/V) vs Constant Tip Speed (v_tip)
   */
  performScaleUpComparison(
    benchMassKg: number,
    targetMassKg: number,
    benchRpm: number,
    impellerType: ImpellerType,
    scaleCriterion: 'constant-P_over_V' | 'constant-tip-speed' = 'constant-P_over_V'
  ): {
    scaleFactorGeometric: number;
    targetRpm: number;
    benchPowerWatts: number;
    targetPowerWatts: number;
    tipSpeedMPerS: number;
    mixingTimeIncreaseRatio: number;
    coolingTimeIncreaseRatio: number;
    warnings: string[];
  } {
    const scaleFactorMass = targetMassKg / benchMassKg;
    // Geometric linear scale factor λ = (M_2 / M_1)^(1/3)
    const lambda = Math.cbrt(scaleFactorMass);

    let targetRpm: number;
    if (scaleCriterion === 'constant-P_over_V') {
      // In turbulent regime, P/V ∝ N³ * D² = const
      // => N_2 = N_1 * (D_1 / D_2)^(2/3) = N_1 * λ^(-2/3)
      targetRpm = benchRpm * Math.pow(lambda, -2.0 / 3.0);
    } else {
      // Constant Tip Speed: v_tip = π * N * D = const
      // => N_2 = N_1 * (D_1 / D_2) = N_1 * λ^(-1)
      targetRpm = benchRpm / lambda;
    }

    const D1 = 0.06; // bench impeller 60 mm
    const D2 = D1 * lambda;
    const N1 = benchRpm / 60.0;
    const N2 = targetRpm / 60.0;

    const Np = this.impellers[impellerType].powerNumberTurbulentNp;
    const rho = 1020.0;

    const benchPowerWatts = Np * rho * Math.pow(N1, 3) * Math.pow(D1, 5);
    const targetPowerWatts = Np * rho * Math.pow(N2, 3) * Math.pow(D2, 5);

    const tipSpeedMPerS = Math.PI * N2 * D2;

    // Mixing time ratio: θ_95 ∝ 1/N => θ_2 / θ_1 = N_1 / N_2
    const mixingTimeRatio = N1 / N2;

    // Heat transfer surface area per unit volume scales as 1/λ (decreases drastically!)
    // Cooling time scales approximately as λ
    const coolingTimeRatio = lambda;

    const warnings: string[] = [];
    if (coolingTimeRatio > 2.5) {
      warnings.push(`Heat transfer area per unit volume drops by ${(1/lambda * 100).toFixed(0)}%. External plate exchanger or chilled jacket required.`);
    }
    if (tipSpeedMPerS > 12.0) {
      warnings.push(`High impeller tip speed (${tipSpeedMPerS.toFixed(1)} m/s) may cause shear-induced emulsion inversion or foam entrapment.`);
    }
    if (mixingTimeRatio > 3.0) {
      warnings.push(`Scale-up mixing time increases by ${mixingTimeRatio.toFixed(1)}×. Process step cycle time must be extended in Master Batch Record.`);
    }

    return {
      scaleFactorGeometric: Math.round(lambda * 100) / 100,
      targetRpm: Math.round(targetRpm),
      benchPowerWatts: Math.round(benchPowerWatts * 10) / 10,
      targetPowerWatts: Math.round(targetPowerWatts),
      tipSpeedMPerS: Math.round(tipSpeedMPerS * 10) / 10,
      mixingTimeIncreaseRatio: Math.round(mixingTimeRatio * 10) / 10,
      coolingTimeIncreaseRatio: Math.round(coolingTimeRatio * 10) / 10,
      warnings
    };
  }
}
