import { Injectable } from '@angular/core';
import { FlowCurvePoint, RheologyParameters } from '../models/rheology.model';

@Injectable({
  providedIn: 'root'
})
export class RheologyService {

  // Preset parameter profiles for different cosmetic product categories
  getDefaultParametersForCategory(category: string): RheologyParameters {
    switch (category) {
      case 'liquid-foundation':
        // Classic shear-thinning pseudoplastic with yield stress to prevent pigment settling
        return {
          modelType: 'herschel-bulkley',
          yieldStressPa: 4.8, // Yield stress tau_0 (suspends pigment)
          consistencyIndexK: 12.5, // Pa·s^n
          flowBehaviorIndexN: 0.28, // Strong shear-thinning
          zeroShearViscosityPaS: 450.0,
          infiniteShearViscosityPaS: 0.08,
          relaxationTimeS: 0.45,
          temperatureSensitivityEaKJ: 22.0,
          thixotropicBreakdownAreaPaPerS: 185.0
        };

      case 'concealer':
        // High pigment loading, higher yield stress and consistency
        return {
          modelType: 'herschel-bulkley',
          yieldStressPa: 16.2,
          consistencyIndexK: 35.0,
          flowBehaviorIndexN: 0.22,
          zeroShearViscosityPaS: 1200.0,
          infiniteShearViscosityPaS: 0.15,
          relaxationTimeS: 0.85,
          temperatureSensitivityEaKJ: 25.0,
          thixotropicBreakdownAreaPaPerS: 320.0
        };

      case 'lipstick':
        // Anhydrous wax-oil matrix: high yield stress at room temp, melts at elevated temp
        return {
          modelType: 'herschel-bulkley',
          yieldStressPa: 85.0,
          consistencyIndexK: 95.0,
          flowBehaviorIndexN: 0.18,
          zeroShearViscosityPaS: 8500.0,
          infiniteShearViscosityPaS: 0.40,
          relaxationTimeS: 2.5,
          temperatureSensitivityEaKJ: 48.0,
          thixotropicBreakdownAreaPaPerS: 640.0
        };

      case 'lip-gloss':
        // High zero-shear viscosity, viscous drag, moderate shear thinning
        return {
          modelType: 'carreau-yasuda',
          yieldStressPa: 1.5,
          consistencyIndexK: 48.0,
          flowBehaviorIndexN: 0.42,
          zeroShearViscosityPaS: 85.0,
          infiniteShearViscosityPaS: 0.65,
          relaxationTimeS: 1.2,
          yasudaParameterA: 1.8,
          temperatureSensitivityEaKJ: 30.0,
          thixotropicBreakdownAreaPaPerS: 90.0
        };

      case 'emulsion-cream':
      default:
        // Rich cream with lamellar gel network
        return {
          modelType: 'herschel-bulkley',
          yieldStressPa: 12.0,
          consistencyIndexK: 24.0,
          flowBehaviorIndexN: 0.25,
          zeroShearViscosityPaS: 680.0,
          infiniteShearViscosityPaS: 0.12,
          relaxationTimeS: 0.6,
          temperatureSensitivityEaKJ: 26.0,
          thixotropicBreakdownAreaPaPerS: 240.0
        };
    }
  }

  /**
   * Calculate shear stress tau (Pa) given shear rate gamma_dot (s^-1)
   */
  calculateShearStress(shearRate: number, params: RheologyParameters, tempC = 25.0): number {
    const gamma = Math.max(0.0001, shearRate);
    // Arrhenius temperature correction: η(T) = η_ref * exp(Ea/R * (1/T - 1/T_ref))
    const T_ref = 298.15; // 25°C
    const T_cur = 273.15 + tempC;
    const R_gas = 8.314e-3; // kJ / (mol · K)
    const Ea = params.temperatureSensitivityEaKJ || 22.0;
    const tempFactor = Math.exp((Ea / R_gas) * (1.0 / T_cur - 1.0 / T_ref));

    switch (params.modelType) {
      case 'herschel-bulkley': {
        const tau0 = params.yieldStressPa * tempFactor;
        const K = params.consistencyIndexK * tempFactor;
        const n = params.flowBehaviorIndexN;
        return tau0 + K * Math.pow(gamma, n);
      }

      case 'power-law': {
        const K = params.consistencyIndexK * tempFactor;
        const n = params.flowBehaviorIndexN;
        return K * Math.pow(gamma, n);
      }

      case 'bingham': {
        const tau0 = params.yieldStressPa * tempFactor;
        const muP = (params.consistencyIndexK * 0.1) * tempFactor;
        return tau0 + muP * gamma;
      }

      case 'carreau-yasuda': {
        const eta0 = (params.zeroShearViscosityPaS || 50.0) * tempFactor;
        const etaInf = (params.infiniteShearViscosityPaS || 0.05) * tempFactor;
        const lambda = params.relaxationTimeS || 0.5;
        const a = params.yasudaParameterA || 2.0;
        const n = params.flowBehaviorIndexN;

        const bracket = 1.0 + Math.pow(lambda * gamma, a);
        const eta = etaInf + (eta0 - etaInf) * Math.pow(bracket, (n - 1.0) / a);
        return eta * gamma;
      }

      case 'newtonian':
      default: {
        const mu = (params.consistencyIndexK * 0.5) * tempFactor;
        return mu * gamma;
      }
    }
  }

  /**
   * Calculate apparent viscosity in cP (mPa·s) at a specified shear rate
   */
  calculateApparentViscosityCP(shearRate: number, params: RheologyParameters, tempC = 25.0): number {
    const gamma = Math.max(0.0001, shearRate);
    const tau = this.calculateShearStress(gamma, params, tempC);
    const etaPaS = tau / gamma;
    return etaPaS * 1000.0; // 1 Pa·s = 1000 cP (mPa·s)
  }

  /**
   * Generate full flow curve sweep across relevant cosmetic shear regimes:
   * 0.01 s^-1 (storage / settling)
   * 0.1 - 10 s^-1 (pumping / dipping / leveling)
   * 100 - 1000 s^-1 (skin rubbing / foundation application)
   * 1000 - 10000 s^-1 (high-shear mixer blade passage)
   */
  generateFlowCurve(params: RheologyParameters, tempC = 25.0): FlowCurvePoint[] {
    const shearRates = [
      0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 5.0, 10.0, 
      20.0, 50.0, 100.0, 200.0, 500.0, 1000.0, 2500.0, 5000.0, 10000.0
    ];

    return shearRates.map(gamma => {
      const tau = this.calculateShearStress(gamma, params, tempC);
      const etaPaS = tau / gamma;
      const etaCP = etaPaS * 1000.0;

      // Downward sweep hysteresis for thixotropy demonstration
      // Structural breakdown under shear: tau_down = tau * (1 - breakdownRatio)
      const breakdownRatio = (params.thixotropicBreakdownAreaPaPerS || 150.0) / 1000.0;
      const tauDown = Math.max(0.001, tau * (1.0 - breakdownRatio * (1.0 - Math.exp(-gamma / 200.0))));

      return {
        shearRatePerS: gamma,
        shearStressPa: Math.round(tau * 100) / 100,
        apparentViscosityPaS: Math.round(etaPaS * 1000) / 1000,
        apparentViscosityCP: Math.round(etaCP),
        downSweepStressPa: Math.round(tauDown * 100) / 100
      };
    });
  }

  /**
   * Assess suspension stability (Stokes Law + Yield Stress criteria):
   * Ensures pigment particles will not settle during 24-month shelf life.
   */
  checkPigmentSuspensionStability(yieldStressPa: number, particleDensityGPerCm3 = 4.23, particleRadiusNm = 250): {
    isSuspendedIndefinitely: boolean;
    yieldStressMarginRatio: number;
    explanation: string;
  } {
    // Critical yield stress required to suspend spherical particle:
    // tau_c = (3/8) * r * (rho_p - rho_fluid) * g
    const r = particleRadiusNm * 1e-9; // m
    const rhoP = particleDensityGPerCm3 * 1000.0; // kg/m³
    const rhoF = 1000.0; // kg/m³ (water/base)
    const g = 9.81;

    const criticalYieldStressPa = (3.0 / 8.0) * r * (rhoP - rhoF) * g;
    const margin = yieldStressPa / Math.max(1e-6, criticalYieldStressPa);

    return {
      isSuspendedIndefinitely: margin >= 1.0,
      yieldStressMarginRatio: Math.round(margin * 10) / 10,
      explanation: margin >= 1.0 
        ? `Rheological yield stress (τ₀ = ${yieldStressPa.toFixed(1)} Pa) exceeds critical yield stress (${(criticalYieldStressPa * 1000).toFixed(3)} mPa) by ${margin.toFixed(0)}×. Pigments are kinetically immobilized against gravitational settling.`
        : `Warning: Yield stress is insufficient. High settling risk observed.`
    };
  }
}
