import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinStateService } from './core/services/digital-twin-state.service';
import { TopBar } from './components/top-bar/top-bar';
import { TwinViewport } from './components/twin-viewport/twin-viewport';
import { TwinQuickFormulation } from './components/twin-quick-formulation/twin-quick-formulation';
import { TelemetryHud } from './components/telemetry-hud/telemetry-hud';
import { TwinTimeline } from './components/twin-timeline/twin-timeline';
import { FormulationStudio } from './components/formulation-studio/formulation-studio';
import { ShadeStudio } from './components/shade-studio/shade-studio';
import { RheologyLab } from './components/rheology-lab/rheology-lab';
import { EquipmentScaleup } from './components/equipment-scaleup/equipment-scaleup';
import { QualitySpc } from './components/quality-spc/quality-spc';
import { DoeOptimizer } from './components/doe-optimizer/doe-optimizer';
import { ReportModal } from './components/report-modal/report-modal';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    TopBar,
    TwinViewport,
    TwinQuickFormulation,
    TelemetryHud,
    TwinTimeline,
    FormulationStudio,
    ShadeStudio,
    RheologyLab,
    EquipmentScaleup,
    QualitySpc,
    DoeOptimizer,
    ReportModal
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class App {
  readonly state = inject(DigitalTwinStateService);
  readonly showReportModal = signal<boolean>(false);
}
