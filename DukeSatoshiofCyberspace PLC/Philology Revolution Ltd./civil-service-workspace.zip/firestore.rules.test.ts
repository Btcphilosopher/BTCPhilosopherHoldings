import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

describe('Firestore Security Rules Structural Verification', () => {
  const rules = readFileSync('firestore.rules', 'utf8');

  it('enforces rules_version 2 and default-deny catch-all', () => {
    expect(rules).toContain("rules_version = '2';");
    expect(rules).toContain('match /{document=**}');
    expect(rules).toContain('allow read, write: if false;');
  });

  it('enforces email verification and strict ID regex hardening', () => {
    expect(rules).toContain('request.auth.token.email_verified == true');
    expect(rules).toContain("id.matches('^[a-zA-Z0-9_\\\\-]+$')");
  });

  it('prevents self-approval and isolates PII and HR cases', () => {
    expect(rules).toContain('data.requesterUid != data.approverUid');
    expect(rules).toContain('match /private/{docId}');
    expect(rules).toContain('match /hrCases/{caseId}');
    expect(rules).toContain('existing().subjectUid == request.auth.uid || existing().assignedAdviserUid == request.auth.uid');
  });

  it('locks audit logs against updates and deletes', () => {
    expect(rules).toContain('match /auditLogs/{logId}');
    expect(rules).toContain('allow update, delete: if false;');
  });
});
