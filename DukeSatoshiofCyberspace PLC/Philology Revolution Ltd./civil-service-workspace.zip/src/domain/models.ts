export type DemoRoleId =
  | 'employee'
  | 'line_manager'
  | 'hr_adviser'
  | 'finance_officer'
  | 'it_agent'
  | 'dept_admin'
  | 'auditor';

export type UkRegion = 'england-wales' | 'scotland' | 'northern-ireland';

export type HandlingClassification =
  | 'STANDARD'
  | 'INTERNAL-SENSITIVE'
  | 'RESTRICTED-HR'
  | 'RESTRICTED-FINANCE';

export type RequestCategory =
  | 'leave'
  | 'expense'
  | 'equipment'
  | 'personal-change'
  | 'onboarding'
  | 'service';

export type WorkflowStatus =
  | 'Draft'
  | 'Submitted'
  | 'Manager review'
  | 'Finance review'
  | 'Approved'
  | 'Returned for correction'
  | 'Rejected'
  | 'Withdrawn'
  | 'Payment failed'
  | 'Paid'
  | 'Completed';

export interface DepartmentConfig {
  id: string;
  name: string;
  code: string;
  gradeSystem: string[];
  timesheetsRequired: boolean;
  standardWeeklyHours: number;
  annualLeaveBaseDays: number;
  mileageRatePence: number;
  subsistenceDayCapGbp: number;
  mileageEffectiveDate: string;
  financeApprovalThresholdGbp: number;
  seniorApprovalThresholdGbp: number;
  reviewRatingModel: string;
}

export interface EmployeeRecord {
  id: string;
  staffNumber: string;
  displayName: string;
  roleTitle: string;
  demoRole: DemoRoleId;
  grade: string;
  departmentId: string;
  directorate: string;
  team: string;
  region: UkRegion;
  workingPattern: string;
  fte: number;
  hybridArrangement: string;
  managerId: string | null;
  workEmail: string;
  workLocation: string;
  startDate: string;
  authoritativeSource: string;
  lastSyncedAt: string;
  // Private PII fields (restricted to self or authorised HR with audit/break-glass)
  personalPhone: string;
  homeAddress: string;
  emergencyContactName: string;
  emergencyContactRelation: string;
  emergencyContactPhone: string;
  bankAccountMasked: string;
  bankSortCodeMasked: string;
}

export interface DelegationGrant {
  id: string;
  fromUserId: string;
  toUserId: string;
  scope: ('leave' | 'expense' | 'equipment' | 'tasks')[];
  reason: string;
  startsAt: string;
  endsAt: string;
  active: boolean;
}

export interface EmergencyAccessGrant {
  id: string;
  grantedToUserId: string;
  reason: string;
  scope: 'restricted-hr' | 'pii-verification';
  targetRecordId: string;
  grantedAt: string;
  expiresAt: string;
  revoked: boolean;
}

export interface LeaveBalance {
  employeeId: string;
  leaveYear: string;
  annualEntitlementDays: number;
  carriedOverDays: number;
  takenDays: number;
  pendingDays: number;
  flexiHoursBalance: number;
  toilHoursBalance: number;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  leaveType:
    | 'Annual leave'
    | 'Flexi leave'
    | 'Sickness absence'
    | 'Parental leave'
    | 'Special leave'
    | 'Time off in lieu (TOIL)';
  startDate: string;
  endDate: string;
  workingDays: number;
  region: UkRegion;
  halfDay: boolean;
  reasonNote: string;
  isMedicalConfidential: boolean;
  approverId: string;
  status: WorkflowStatus;
  ruleVersion: string;
  version: number;
  idempotencyKey: string;
  decisionReason?: string;
  submittedAt: string;
  updatedAt: string;
}

export interface TeamAvailabilityEntry {
  employeeId: string;
  employeeName: string;
  team: string;
  startDate: string;
  endDate: string;
  availabilityLabel: string; // Never exposes medical or confidential HR reason
  status: 'Confirmed' | 'Pending';
}

export interface ExpenseLineItem {
  id: string;
  category: 'Rail & Travel' | 'Mileage' | 'Subsistence' | 'Accommodation' | 'Conference';
  description: string;
  date: string;
  amountGbp: number;
  mileageMiles?: number;
  receiptFileName: string;
  receiptScanStatus: 'Scanned Clean' | 'Pending Scan';
}

export interface ExpenseClaim {
  id: string;
  employeeId: string;
  title: string;
  costCentre: string;
  totalAmountGbp: number;
  corporateCardUsed: boolean;
  advanceOffsetGbp: number;
  items: ExpenseLineItem[];
  managerApproverId: string;
  financeReviewerId: string;
  nextActionOwnerId: string | null;
  status: WorkflowStatus;
  ruleVersion: string;
  policyEffectiveDate: string;
  version: number;
  idempotencyKey: string;
  decisionReason?: string;
  paymentReference?: string;
  integrationError?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TaskChecklistItem {
  id: string;
  label: string;
  completed: boolean;
}

export interface TaskComment {
  id: string;
  authorId: string;
  authorName: string;
  body: string;
  createdAt: string;
}

export interface WorkspaceTask {
  id: string;
  title: string;
  description: string;
  ownerId: string;
  accountableTeam: string;
  creatorId: string;
  delegatedToId?: string;
  dueDate: string;
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  status: 'Backlog' | 'In Progress' | 'In Review' | 'Blocked' | 'Done';
  dependencies: string[];
  checklist: TaskChecklistItem[];
  attachments: string[];
  comments: TaskComment[];
  handling: HandlingClassification;
  requiresApproval: boolean;
  originatingType?: 'Request' | 'Case' | 'Project' | 'Onboarding';
  originatingId?: string;
  recurringCadence?: 'None' | 'Weekly' | 'Monthly' | 'Quarterly';
  escalationDeadline?: string;
  escalatedToId?: string;
  auditTrail: string[];
  version: number;
  updatedAt: string;
}

export interface WorkflowApprovalItem {
  id: string;
  requestType: RequestCategory;
  referenceId: string;
  title: string;
  requesterId: string;
  departmentId: string;
  amountGbp?: number;
  mode: 'Sequential' | 'Parallel';
  ruleVersion: string;
  ruleSummary: string;
  stages: {
    stageName: string;
    assignedRole: string;
    assignedUserId: string;
    status: 'Pending' | 'Approved' | 'Returned' | 'Rejected' | 'Skipped';
    actedByUserId?: string;
    actedAt?: string;
    reason?: string;
  }[];
  nextActionUserId: string | null;
  escalationDeadline: string;
  overallStatus: WorkflowStatus;
  version: number;
  idempotencyKey: string;
  createdAt: string;
  updatedAt: string;
}

export interface RestrictedHrCase {
  id: string;
  caseNumber: string;
  caseType:
    | 'HR enquiry'
    | 'Workplace adjustment'
    | 'Grievance'
    | 'Disciplinary'
    | 'Occupational health referral'
    | 'Return-to-work coordination'
    | 'Whistleblowing channel';
  subjectEmployeeId: string;
  assignedAdviserId: string;
  allowedViewerIds: string[];
  handling: 'RESTRICTED-HR';
  summary: string;
  confidentialNotes: string;
  status: 'Open' | 'Under Review' | 'Awaiting Specialist' | 'Resolved' | 'Closed';
  slaDueDate: string;
  createdAt: string;
  updatedAt: string;
}

export interface ServiceTicket {
  id: string;
  catalogueCategory:
    | 'IT Support'
    | 'Password & Access'
    | 'Equipment Request'
    | 'Software Request'
    | 'Building Access'
    | 'Desk & Room Booking'
    | 'Facilities Fault'
    | 'Procurement & PO'
    | 'Records Management'
    | 'Travel Support';
  title: string;
  requesterId: string;
  assignedAgentId: string;
  approverId?: string;
  expectedSla: string;
  costGbp?: number;
  status: WorkflowStatus;
  integrationJobStatus?: 'Synced' | 'Failed' | 'Pending';
  integrationError?: string;
  version: number;
  idempotencyKey: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface OnboardingStep {
  id: string;
  label: string;
  ownerTeam: 'HR' | 'Security Vetting' | 'IT Service' | 'Facilities' | 'Line Manager';
  status: 'Pending' | 'In Progress' | 'Completed' | 'Blocked';
  restrictedSummary?: string;
  completedAt?: string;
}

export interface LifecycleJourney {
  id: string;
  journeyType: 'Onboarding' | 'Internal Move' | 'Leaver';
  personName: string;
  staffNumber: string;
  roleTitle: string;
  directorate: string;
  managerId: string;
  effectiveDate: string;
  dateChangeNote?: string;
  cancelled: boolean;
  vettingStatus: 'Clearance Confirmed (Restricted)' | 'In Progress (Restricted)' | 'Not Required';
  steps: OnboardingStep[];
  updatedAt: string;
}

export interface PolicyDocument {
  id: string;
  title: string;
  category: 'HR & Leave' | 'Pay & Expenses' | 'Security & Handling' | 'Workplace & Hybrid' | 'Conduct & Whistleblowing';
  owner: string;
  version: string;
  effectiveDate: string;
  status: 'Current' | 'Superseded (Expired)' | 'Draft';
  departmentScope: 'All Departments' | string;
  requiresAcknowledgement: boolean;
  acknowledgedByIds: string[];
  summary: string;
  fullGuidance: string;
  handlingClassification: HandlingClassification;
}

export interface PersonalDetailChangeRequest {
  id: string;
  employeeId: string;
  changeType: 'Bank Account Details' | 'Home Address' | 'Emergency Contact' | 'Phone Number';
  proposedMaskedValue: string;
  verificationMethod: 'HR Two-Stage + Payroll Micro-Check' | 'Identity Provider Verification';
  approverId: string;
  status: WorkflowStatus;
  version: number;
  idempotencyKey: string;
  submittedAt: string;
  updatedAt: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actorId: string;
  actorName: string;
  actorRole: DemoRoleId;
  action: string;
  targetType: string;
  targetId: string;
  outcome: 'Success' | 'Denied' | 'Failed';
  detail: string;
  prevHash: string;
  hash: string;
}

export interface IntegrationAdapterInfo {
  id:
    | 'hris'
    | 'payroll'
    | 'idp'
    | 'calendar'
    | 'learning'
    | 'finance'
    | 'itsm'
    | 'records';
  name: string;
  systemName: string;
  sourceOfTruthFor: string;
  syncFrequency: string;
  conflictRule: string;
  lastSyncAt: string;
  health: 'Healthy' | 'Degraded';
}
