import {
  DepartmentConfig,
  LeaveBalance,
  LeaveRequest,
  TeamAvailabilityEntry,
  UkRegion,
} from './models';

export interface PublicHoliday {
  date: string; // YYYY-MM-DD
  name: string;
  regions: UkRegion[];
}

export const UK_PUBLIC_HOLIDAYS: PublicHoliday[] = [
  { date: '2026-01-01', name: 'New Year’s Day', regions: ['england-wales', 'scotland', 'northern-ireland'] },
  { date: '2026-01-02', name: '2nd January (Scotland)', regions: ['scotland'] },
  { date: '2026-03-17', name: 'St Patrick’s Day', regions: ['northern-ireland'] },
  { date: '2026-04-03', name: 'Good Friday', regions: ['england-wales', 'scotland', 'northern-ireland'] },
  { date: '2026-04-06', name: 'Easter Monday', regions: ['england-wales', 'northern-ireland'] },
  { date: '2026-05-04', name: 'Early May Bank Holiday', regions: ['england-wales', 'scotland', 'northern-ireland'] },
  { date: '2026-05-25', name: 'Spring Bank Holiday', regions: ['england-wales', 'scotland', 'northern-ireland'] },
  { date: '2026-07-13', name: 'Battle of the Boyne (NI)', regions: ['northern-ireland'] },
  { date: '2026-08-03', name: 'Summer Bank Holiday (Scotland)', regions: ['scotland'] },
  { date: '2026-08-31', name: 'Summer Bank Holiday', regions: ['england-wales', 'northern-ireland'] },
  { date: '2026-11-30', name: 'St Andrew’s Day', regions: ['scotland'] },
  { date: '2026-12-25', name: 'Christmas Day', regions: ['england-wales', 'scotland', 'northern-ireland'] },
  { date: '2026-12-28', name: 'Boxing Day (substitute)', regions: ['england-wales', 'scotland', 'northern-ireland'] },
  { date: '2027-01-01', name: 'New Year’s Day', regions: ['england-wales', 'scotland', 'northern-ireland'] },
];

export interface LeaveCalculationResult {
  workingDays: number;
  calendarDays: number;
  excludedBankHolidays: PublicHoliday[];
  remainingAfterRequest: number;
  hasSufficientBalance: boolean;
  conflictingRequestIds: string[];
  validationErrors: string[];
  approvalExplanation: string;
}

function parseIsoDate(dateStr: string): Date {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(Date.UTC(y, (m || 1) - 1, d || 1));
}

function formatIsoDate(date: Date): string {
  const y = date.getUTCFullYear();
  const m = String(date.getUTCMonth() + 1).padStart(2, '0');
  const d = String(date.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function calculateProRataEntitlement(baseDays: number, fte: number): number {
  const clampedFte = Math.max(0.1, Math.min(1, fte));
  return Math.round(baseDays * clampedFte * 2) / 2;
}

export function calculateLeaveBooking(params: {
  startDate: string;
  endDate: string;
  halfDay: boolean;
  region: UkRegion;
  leaveType: LeaveRequest['leaveType'];
  balance: LeaveBalance;
  existingRequests: LeaveRequest[];
  department: DepartmentConfig;
  editingRequestId?: string;
}): LeaveCalculationResult {
  const validationErrors: string[] = [];
  const { startDate, endDate, halfDay, region, leaveType, balance, existingRequests, department } = params;

  if (!startDate || !endDate) {
    validationErrors.push('Select both a start date and an end date.');
  }

  const start = parseIsoDate(startDate);
  const end = parseIsoDate(endDate);

  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
    validationErrors.push('Enter valid dates in YYYY-MM-DD format.');
  } else if (end.getTime() < start.getTime()) {
    validationErrors.push('End date must be on or after the start date.');
  }

  let calendarDays = 0;
  let workingDays = 0;
  const excludedBankHolidays: PublicHoliday[] = [];

  if (validationErrors.length === 0) {
    const cursor = new Date(start.getTime());
    while (cursor.getTime() <= end.getTime()) {
      calendarDays += 1;
      const dayOfWeek = cursor.getUTCDay();
      const iso = formatIsoDate(cursor);
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      const bankHoliday = UK_PUBLIC_HOLIDAYS.find(
        (h) => h.date === iso && h.regions.includes(region),
      );
      if (bankHoliday && !isWeekend) {
        excludedBankHolidays.push(bankHoliday);
      } else if (!isWeekend && !bankHoliday) {
        workingDays += 1;
      }
      cursor.setUTCDate(cursor.getUTCDate() + 1);
    }

    if (halfDay && workingDays >= 1) {
      if (startDate !== endDate) {
        validationErrors.push('Half-day requests must begin and end on the same working day.');
      } else {
        workingDays = 0.5;
      }
    }

    if (workingDays <= 0) {
      validationErrors.push('Selected dates fall entirely on weekends or regional public holidays.');
    }
  }

  const conflictingRequestIds = existingRequests
    .filter((req) => {
      if (req.id === params.editingRequestId) return false;
      if (['Rejected', 'Withdrawn'].includes(req.status)) return false;
      return req.startDate <= endDate && req.endDate >= startDate;
    })
    .map((req) => req.id);

  if (conflictingRequestIds.length > 0) {
    validationErrors.push(
      `Dates overlap with existing booking(s): ${conflictingRequestIds.join(', ')}. Cancel or adjust the existing booking first.`,
    );
  }

  const available =
    balance.annualEntitlementDays +
    balance.carriedOverDays -
    balance.takenDays -
    balance.pendingDays;

  const deductsAnnualLeave = leaveType === 'Annual leave';
  const remainingAfterRequest = deductsAnnualLeave ? available - workingDays : available;
  const hasSufficientBalance = !deductsAnnualLeave || remainingAfterRequest >= 0;

  if (!hasSufficientBalance) {
    validationErrors.push(
      `Insufficient annual leave balance (${available} days available; ${workingDays} days requested).`,
    );
  }

  const approvalExplanation =
    leaveType === 'Sickness absence'
      ? 'Sickness absence records are logged with restricted medical privacy. Your line manager sees absence dates and return-to-work milestones only, unless you explicitly share details.'
      : workingDays > 10
        ? `Requests over 10 working days under ${department.name} rules require Line Manager review followed by Directorate resource confirmation.`
        : `Standard leave requests under ${department.name} (${department.code}) route directly to your Line Manager or active delegate.`;

  return {
    workingDays,
    calendarDays,
    excludedBankHolidays,
    remainingAfterRequest,
    hasSufficientBalance,
    conflictingRequestIds,
    validationErrors,
    approvalExplanation,
  };
}

export function projectTeamAvailability(
  requests: LeaveRequest[],
  employeeLookup: Map<string, { displayName: string; team: string }>,
): TeamAvailabilityEntry[] {
  return requests
    .filter((r) => !['Rejected', 'Withdrawn', 'Draft'].includes(r.status))
    .map((r) => {
      const emp = employeeLookup.get(r.employeeId);
      const isPending = ['Submitted', 'Manager review'].includes(r.status);
      // Privacy guard: NEVER expose sickness or medical reason on shared team calendars
      const availabilityLabel = r.isMedicalConfidential || r.leaveType === 'Sickness absence'
        ? 'Unavailable (Absence)'
        : r.leaveType === 'Parental leave' || r.leaveType === 'Special leave'
          ? 'Unavailable (Authorised Leave)'
          : `Unavailable (${r.leaveType})`;

      return {
        employeeId: r.employeeId,
        employeeName: emp?.displayName ?? 'Team Member',
        team: emp?.team ?? 'Department',
        startDate: r.startDate,
        endDate: r.endDate,
        availabilityLabel,
        status: isPending ? 'Pending' : 'Confirmed',
      };
    });
}
