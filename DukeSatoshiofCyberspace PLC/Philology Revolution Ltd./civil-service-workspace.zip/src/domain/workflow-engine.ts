import {
  DelegationGrant,
  EmployeeRecord,
  ExpenseClaim,
  LeaveRequest,
  WorkflowApprovalItem,
  WorkflowStatus,
  WorkspaceTask,
} from './models';
import { canReassignTask, ROLE_MATRIX } from './permissions';

export interface WorkflowRuleVersion {
  versionId: string;
  category: 'leave' | 'expense' | 'equipment' | 'personal-change' | 'onboarding';
  effectiveFrom: string;
  status: 'Active' | 'Superseded';
  summary: string;
  financeThresholdGbp?: number;
  escalationHours: number;
}

export const WORKFLOW_RULE_VERSIONS: WorkflowRuleVersion[] = [
  {
    versionId: 'LEAVE-RULE-v2.1',
    category: 'leave',
    effectiveFrom: '2026-04-01',
    status: 'Active',
    summary: 'Line Manager approval required; >10 working days escalates to Directorate Lead.',
    escalationHours: 72,
  },
  {
    versionId: 'EXPENSE-RULE-v3.0',
    category: 'expense',
    effectiveFrom: '2026-01-01',
    status: 'Superseded',
    summary: 'Legacy threshold: Line Manager review + Finance Officer payout above £100.',
    financeThresholdGbp: 100,
    escalationHours: 96,
  },
  {
    versionId: 'EXPENSE-RULE-v3.1',
    category: 'expense',
    effectiveFrom: '2026-09-01',
    status: 'Active',
    summary: 'Sequential Line Manager review followed by mandatory Finance Officer compliance & payout check.',
    financeThresholdGbp: 0,
    escalationHours: 72,
  },
  {
    versionId: 'EQUIP-RULE-v1.4',
    category: 'equipment',
    effectiveFrom: '2026-05-15',
    status: 'Active',
    summary: 'Parallel Line Manager budget approval + IT Service Agent stock/procurement check.',
    financeThresholdGbp: 500,
    escalationHours: 48,
  },
  {
    versionId: 'PII-CHANGE-v2.0',
    category: 'personal-change',
    effectiveFrom: '2026-03-01',
    status: 'Active',
    summary: 'Bank-account and sensitive address changes require HR Adviser two-stage verification.',
    escalationHours: 48,
  },
];

export class WorkflowDomainError extends Error {
  constructor(
    public readonly code:
      | 'SELF_APPROVAL_FORBIDDEN'
      | 'UNAUTHORISED_APPROVER'
      | 'UNAUTHORISED_DELEGATION'
      | 'CONCURRENT_MODIFICATION_CONFLICT'
      | 'INVALID_STATE_TRANSITION'
      | 'DUPLICATE_SUBMISSION'
      | 'REASON_REQUIRED',
    message: string,
  ) {
    super(message);
    this.name = 'WorkflowDomainError';
  }
}

export function hasActiveDelegation(
  delegations: DelegationGrant[],
  fromUserId: string,
  toUserId: string,
  scope: 'leave' | 'expense' | 'equipment' | 'tasks',
  nowIso: string,
): boolean {
  return delegations.some(
    (d) =>
      d.active &&
      d.fromUserId === fromUserId &&
      d.toUserId === toUserId &&
      d.scope.includes(scope) &&
      d.startsAt <= nowIso &&
      d.endsAt >= nowIso,
  );
}

export function createDelegationGrant(params: {
  actor: EmployeeRecord;
  fromUserId: string;
  toUser: EmployeeRecord;
  scope: ('leave' | 'expense' | 'equipment' | 'tasks')[];
  reason: string;
  startsAt: string;
  endsAt: string;
}): DelegationGrant {
  const { actor, fromUserId, toUser, scope, reason, startsAt, endsAt } = params;
  if (fromUserId === toUser.id) {
    throw new WorkflowDomainError(
      'UNAUTHORISED_DELEGATION',
      'You cannot delegate approval authority to yourself.',
    );
  }
  if (actor.id !== fromUserId && actor.demoRole !== 'hr_adviser' && actor.demoRole !== 'dept_admin') {
    throw new WorkflowDomainError(
      'UNAUTHORISED_DELEGATION',
      'Only the authority holder, HR Adviser, or Department Administrator can register cover delegation.',
    );
  }
  if (toUser.demoRole === 'auditor') {
    throw new WorkflowDomainError(
      'UNAUTHORISED_DELEGATION',
      'Read-only Auditor accounts cannot receive operational approval delegations.',
    );
  }
  if (!reason.trim()) {
    throw new WorkflowDomainError('REASON_REQUIRED', 'Enter a recorded reason for delegation or cover.');
  }

  return {
    id: `del-${Date.now()}`,
    fromUserId,
    toUserId: toUser.id,
    scope,
    reason: reason.trim(),
    startsAt,
    endsAt,
    active: true,
  };
}

export function transitionLeaveRequest(params: {
  request: LeaveRequest;
  actor: EmployeeRecord;
  action: 'approve' | 'reject' | 'return' | 'withdraw';
  expectedVersion: number;
  reason?: string;
  delegations: DelegationGrant[];
  nowIso: string;
}): LeaveRequest {
  const { request, actor, action, expectedVersion, reason, delegations, nowIso } = params;

  if (request.version !== expectedVersion) {
    throw new WorkflowDomainError(
      'CONCURRENT_MODIFICATION_CONFLICT',
      `Leave request ${request.id} was updated concurrently (expected v${expectedVersion}, found v${request.version}). Reload before acting.`,
    );
  }

  if (['Approved', 'Rejected', 'Withdrawn', 'Completed'].includes(request.status)) {
    throw new WorkflowDomainError(
      'INVALID_STATE_TRANSITION',
      `Leave request ${request.id} is already in terminal state "${request.status}".`,
    );
  }

  if (action === 'withdraw') {
    if (actor.id !== request.employeeId) {
      throw new WorkflowDomainError('UNAUTHORISED_APPROVER', 'Only the requester can withdraw a leave booking.');
    }
    return {
      ...request,
      status: 'Withdrawn',
      decisionReason: reason?.trim() || 'Withdrawn by requester',
      version: request.version + 1,
      updatedAt: nowIso,
    };
  }

  // Separation of requester and approver
  if (actor.id === request.employeeId) {
    throw new WorkflowDomainError(
      'SELF_APPROVAL_FORBIDDEN',
      'Separation of duties: you cannot approve, reject, or return your own leave request.',
    );
  }

  const isAssignedApprover = request.approverId === actor.id;
  const isDelegated = hasActiveDelegation(delegations, request.approverId, actor.id, 'leave', nowIso);
  if (!isAssignedApprover && !isDelegated) {
    throw new WorkflowDomainError(
      'UNAUTHORISED_APPROVER',
      `Action requires ${request.approverId} or an active leave delegation.`,
    );
  }

  if ((action === 'reject' || action === 'return') && !reason?.trim()) {
    throw new WorkflowDomainError('REASON_REQUIRED', 'A recorded reason is required when rejecting or returning a request.');
  }

  const nextStatus: WorkflowStatus =
    action === 'approve' ? 'Approved' : action === 'reject' ? 'Rejected' : 'Returned for correction';

  return {
    ...request,
    status: nextStatus,
    decisionReason: reason?.trim() || (action === 'approve' ? 'Approved within departmental staffing cover' : undefined),
    version: request.version + 1,
    updatedAt: nowIso,
  };
}

export function transitionExpenseClaim(params: {
  claim: ExpenseClaim;
  actor: EmployeeRecord;
  action:
    | 'submit'
    | 'manager_approve'
    | 'finance_pay'
    | 'finance_fail_payment'
    | 'retry_payment'
    | 'return'
    | 'reject'
    | 'withdraw';
  expectedVersion: number;
  reason?: string;
  delegations: DelegationGrant[];
  nowIso: string;
}): ExpenseClaim {
  const { claim, actor, action, expectedVersion, reason, delegations, nowIso } = params;

  if (claim.version !== expectedVersion) {
    throw new WorkflowDomainError(
      'CONCURRENT_MODIFICATION_CONFLICT',
      `Expense claim ${claim.id} was modified concurrently (expected v${expectedVersion}, found v${claim.version}).`,
    );
  }

  if (['Paid', 'Rejected', 'Withdrawn'].includes(claim.status)) {
    throw new WorkflowDomainError(
      'INVALID_STATE_TRANSITION',
      `Expense claim ${claim.id} is in terminal state "${claim.status}".`,
    );
  }

  if (action === 'submit') {
    if (actor.id !== claim.employeeId) {
      throw new WorkflowDomainError('UNAUTHORISED_APPROVER', 'Only the claimant may submit or resubmit this claim.');
    }
    if (!['Draft', 'Returned for correction'].includes(claim.status)) {
      throw new WorkflowDomainError('INVALID_STATE_TRANSITION', 'Only Draft or Returned claims can be submitted.');
    }
    return {
      ...claim,
      status: 'Manager review',
      nextActionOwnerId: claim.managerApproverId,
      decisionReason: reason?.trim() || claim.decisionReason,
      version: claim.version + 1,
      updatedAt: nowIso,
    };
  }

  if (action === 'withdraw') {
    if (actor.id !== claim.employeeId) {
      throw new WorkflowDomainError('UNAUTHORISED_APPROVER', 'Only the claimant can withdraw their expense claim.');
    }
    return {
      ...claim,
      status: 'Withdrawn',
      nextActionOwnerId: null,
      decisionReason: reason?.trim() || 'Withdrawn by claimant',
      version: claim.version + 1,
      updatedAt: nowIso,
    };
  }

  // Self-approval guard for all review/payment actions
  if (actor.id === claim.employeeId) {
    throw new WorkflowDomainError(
      'SELF_APPROVAL_FORBIDDEN',
      'Separation of duties: claimants cannot review, approve, or disburse their own expenses.',
    );
  }

  if (action === 'manager_approve') {
    if (!['Submitted', 'Manager review'].includes(claim.status)) {
      throw new WorkflowDomainError('INVALID_STATE_TRANSITION', 'Claim is not awaiting manager review.');
    }
    const authorised =
      actor.id === claim.managerApproverId ||
      hasActiveDelegation(delegations, claim.managerApproverId, actor.id, 'expense', nowIso);
    if (!authorised) {
      throw new WorkflowDomainError('UNAUTHORISED_APPROVER', 'Only the designated line manager or delegate can approve.');
    }
    return {
      ...claim,
      status: 'Finance review',
      nextActionOwnerId: claim.financeReviewerId,
      decisionReason: reason?.trim() || 'Line manager verified business travel & receipts',
      version: claim.version + 1,
      updatedAt: nowIso,
    };
  }

  if (action === 'finance_pay' || action === 'finance_fail_payment' || action === 'retry_payment') {
    const canPay = ROLE_MATRIX[actor.demoRole].canProcessFinancePayments;
    if (!canPay) {
      throw new WorkflowDomainError('UNAUTHORISED_APPROVER', 'Finance Officer authority is required for payment processing.');
    }
    if (action === 'retry_payment' && claim.status !== 'Payment failed') {
      throw new WorkflowDomainError('INVALID_STATE_TRANSITION', 'Only failed payments can be retried.');
    }
    if ((action === 'finance_pay' || action === 'finance_fail_payment') && claim.status !== 'Finance review') {
      throw new WorkflowDomainError('INVALID_STATE_TRANSITION', 'Claim must be in Finance review before disbursement.');
    }

    if (action === 'finance_fail_payment') {
      return {
        ...claim,
        status: 'Payment failed',
        nextActionOwnerId: claim.financeReviewerId,
        integrationError: reason?.trim() || 'BACS clearing gateway returned timeout (E_PAYROLL_TIMEOUT). Reconcile and retry.',
        version: claim.version + 1,
        updatedAt: nowIso,
      };
    }

    return {
      ...claim,
      status: 'Paid',
      nextActionOwnerId: null,
      integrationError: undefined,
      paymentReference: `BACS-${claim.id.toUpperCase()}-${nowIso.slice(0, 10).replaceAll('-', '')}`,
      decisionReason: reason?.trim() || 'Verified against effective policy rates and settled via Payroll adapter',
      version: claim.version + 1,
      updatedAt: nowIso,
    };
  }

  if (action === 'return' || action === 'reject') {
    if (!reason?.trim()) {
      throw new WorkflowDomainError('REASON_REQUIRED', 'Enter a clear reason before returning or rejecting a claim.');
    }
    const isMgrStage = ['Submitted', 'Manager review'].includes(claim.status);
    const isFinStage = claim.status === 'Finance review' || claim.status === 'Payment failed';
    const mgrOk =
      isMgrStage &&
      (actor.id === claim.managerApproverId ||
        hasActiveDelegation(delegations, claim.managerApproverId, actor.id, 'expense', nowIso));
    const finOk = isFinStage && ROLE_MATRIX[actor.demoRole].canProcessFinancePayments;
    if (!mgrOk && !finOk) {
      throw new WorkflowDomainError('UNAUTHORISED_APPROVER', 'You are not authorised to return or reject at the current stage.');
    }
    return {
      ...claim,
      status: action === 'return' ? 'Returned for correction' : 'Rejected',
      nextActionOwnerId: action === 'return' ? claim.employeeId : null,
      decisionReason: reason.trim(),
      version: claim.version + 1,
      updatedAt: nowIso,
    };
  }

  throw new WorkflowDomainError('INVALID_STATE_TRANSITION', 'Unsupported expense transition.');
}

export function transitionApprovalItem(params: {
  approval: WorkflowApprovalItem;
  actor: EmployeeRecord;
  decision: 'Approve' | 'Return' | 'Reject';
  expectedVersion: number;
  reason?: string;
  delegations: DelegationGrant[];
  nowIso: string;
}): WorkflowApprovalItem {
  const { approval, actor, decision, expectedVersion, reason, delegations, nowIso } = params;

  if (approval.version !== expectedVersion) {
    throw new WorkflowDomainError(
      'CONCURRENT_MODIFICATION_CONFLICT',
      `Approval ${approval.id} has changed since loaded. Refresh to view current version v${approval.version}.`,
    );
  }
  if (actor.id === approval.requesterId) {
    throw new WorkflowDomainError(
      'SELF_APPROVAL_FORBIDDEN',
      'Requesters cannot approve, return, or reject their own submissions.',
    );
  }
  if ((decision === 'Return' || decision === 'Reject') && !reason?.trim()) {
    throw new WorkflowDomainError('REASON_REQUIRED', 'A recorded reason is mandatory when returning or rejecting.');
  }

  const scopeKey =
    approval.requestType === 'leave'
      ? 'leave'
      : approval.requestType === 'expense'
        ? 'expense'
        : 'equipment';

  // Find actionable pending stage(s) for actor
  const stageIdx = approval.stages.findIndex((s, index) => {
    if (s.status !== 'Pending') return false;
    if (approval.mode === 'Sequential') {
      const priorPending = approval.stages.slice(0, index).some((prev) => prev.status === 'Pending');
      if (priorPending) return false;
    }
    return (
      s.assignedUserId === actor.id ||
      hasActiveDelegation(delegations, s.assignedUserId, actor.id, scopeKey, nowIso)
    );
  });

  if (stageIdx === -1) {
    throw new WorkflowDomainError(
      'UNAUTHORISED_APPROVER',
      'No pending stage is currently awaiting your action or active delegation.',
    );
  }

  const updatedStages = approval.stages.map((stage, idx) => {
    if (idx !== stageIdx) return stage;
    return {
      ...stage,
      status:
        decision === 'Approve'
          ? ('Approved' as const)
          : decision === 'Return'
            ? ('Returned' as const)
            : ('Rejected' as const),
      actedByUserId: actor.id,
      actedAt: nowIso,
      reason: reason?.trim() || (decision === 'Approve' ? 'Approved' : undefined),
    };
  });

  let overallStatus: WorkflowStatus = approval.overallStatus;
  let nextActionUserId: string | null = null;

  if (decision === 'Reject') {
    overallStatus = 'Rejected';
  } else if (decision === 'Return') {
    overallStatus = 'Returned for correction';
    nextActionUserId = approval.requesterId;
  } else {
    const nextPending = updatedStages.find((s) => s.status === 'Pending');
    if (nextPending) {
      nextActionUserId = nextPending.assignedUserId;
      overallStatus = nextPending.assignedRole.includes('Finance') ? 'Finance review' : 'Manager review';
    } else {
      overallStatus = 'Approved';
      nextActionUserId = null;
    }
  }

  return {
    ...approval,
    // Rule version remains pinned to the version captured at submission!
    ruleVersion: approval.ruleVersion,
    stages: updatedStages,
    nextActionUserId,
    overallStatus,
    version: approval.version + 1,
    updatedAt: nowIso,
  };
}

export function delegateOrEscalateTask(params: {
  task: WorkspaceTask;
  actor: EmployeeRecord;
  targetUser: EmployeeRecord;
  mode: 'delegate' | 'escalate';
  reason: string;
  nowIso: string;
}): WorkspaceTask {
  const { task, actor, targetUser, mode, reason, nowIso } = params;
  const check = canReassignTask(actor, task);
  if (!check.allowed) {
    throw new WorkflowDomainError('UNAUTHORISED_APPROVER', check.reason ?? 'Not permitted to reassign task.');
  }
  if (!reason.trim()) {
    throw new WorkflowDomainError('REASON_REQUIRED', 'Provide a reason for delegation or escalation.');
  }

  const auditLine =
    mode === 'escalate'
      ? `${nowIso}: Escalated to ${targetUser.displayName} by ${actor.displayName} — ${reason.trim()}`
      : `${nowIso}: Delegated to ${targetUser.displayName} by ${actor.displayName} — ${reason.trim()}`;

  return {
    ...task,
    delegatedToId: mode === 'delegate' ? targetUser.id : task.delegatedToId,
    escalatedToId: mode === 'escalate' ? targetUser.id : task.escalatedToId,
    ownerId: mode === 'delegate' ? targetUser.id : task.ownerId,
    priority: mode === 'escalate' ? 'Urgent' : task.priority,
    auditTrail: [auditLine, ...task.auditTrail],
    version: task.version + 1,
    updatedAt: nowIso,
  };
}
