import { IntegrationAdapterInfo } from './models';

export interface IntegrationDispatchResult {
  idempotencyKey: string;
  adapterId: IntegrationAdapterInfo['id'];
  status: 'COMPLETED' | 'FAILED';
  externalReference?: string;
  errorMessage?: string;
  attempts: number;
  reconciledFromCache: boolean;
  dispatchedAt: string;
}

export const INTEGRATION_ADAPTERS: IntegrationAdapterInfo[] = [
  {
    id: 'hris',
    name: 'HR System Adapter',
    systemName: 'Core People HRIS',
    sourceOfTruthFor: 'Employment record, grade, directorate, working pattern, reporting line',
    syncFrequency: 'Every 15 minutes (webhook + delta poll)',
    conflictRule: 'HRIS authoritative; workspace personal-change requests write back only after HR two-stage approval.',
    lastSyncAt: '2026-11-21T08:30:00Z',
    health: 'Healthy',
  },
  {
    id: 'payroll',
    name: 'Payroll Adapter',
    systemName: 'Civil Payroll Gateway',
    sourceOfTruthFor: 'Payslips, P60/P45 tax statements, BACS expense disbursements, bank verification',
    syncFrequency: 'Real-time dispatch + nightly reconciliation',
    conflictRule: 'Payroll authoritative for net pay and settlement status; failed BACS never marks claim Paid.',
    lastSyncAt: '2026-11-21T08:15:00Z',
    health: 'Healthy',
  },
  {
    id: 'idp',
    name: 'Identity Provider Adapter',
    systemName: 'Enterprise SSO & MFA (OIDC)',
    sourceOfTruthFor: 'Authentication, MFA assurance level, RBAC group claims, joiner/leaver account state',
    syncFrequency: 'Real-time OIDC + SCIM provisioning',
    conflictRule: 'IdP authoritative for credentials and session revocation.',
    lastSyncAt: '2026-11-21T08:45:00Z',
    health: 'Healthy',
  },
  {
    id: 'calendar',
    name: 'Calendar & Collaboration Adapter',
    systemName: 'Departmental Calendar Exchange',
    sourceOfTruthFor: 'Meeting availability, out-of-office blocks (non-medical), desk/room bookings',
    syncFrequency: 'Every 5 minutes',
    conflictRule: 'Leave engine writes neutral availability blocks only; never syncs medical absence reasons.',
    lastSyncAt: '2026-11-21T08:40:00Z',
    health: 'Healthy',
  },
  {
    id: 'learning',
    name: 'Learning Platform Adapter',
    systemName: 'Civil Service Learning Hub',
    sourceOfTruthFor: 'Mandatory training completion, course catalogue, professional qualifications',
    syncFrequency: 'Hourly sync',
    conflictRule: 'Learning Hub authoritative for completion certificates.',
    lastSyncAt: '2026-11-21T08:00:00Z',
    health: 'Healthy',
  },
  {
    id: 'finance',
    name: 'Finance & Procurement Adapter',
    systemName: 'Departmental ERP Ledger',
    sourceOfTruthFor: 'Cost centres, purchase orders, invoice queries, corporate-card statements',
    syncFrequency: 'Every 30 minutes',
    conflictRule: 'ERP authoritative for cost-centre validity and PO numbers.',
    lastSyncAt: '2026-11-21T08:20:00Z',
    health: 'Healthy',
  },
  {
    id: 'itsm',
    name: 'IT Service Management Adapter',
    systemName: 'Enterprise ITSM Desk',
    sourceOfTruthFor: 'Hardware fulfilment, software licences, incident SLAs, leaver kit recovery',
    syncFrequency: 'Event-driven webhook + 10-min reconciliation',
    conflictRule: 'ITSM authoritative for asset tags and hardware dispatch state.',
    lastSyncAt: '2026-11-21T08:35:00Z',
    health: 'Healthy',
  },
  {
    id: 'records',
    name: 'Document & Records Adapter',
    systemName: 'Official Records Repository',
    sourceOfTruthFor: 'Retention schedules, legal holds, employment letters, receipt virus-scan archives',
    syncFrequency: 'Immediate on upload + nightly retention sweep',
    conflictRule: 'Records repository enforces immutable retention and holds.',
    lastSyncAt: '2026-11-21T08:10:00Z',
    health: 'Healthy',
  },
];

export class IdempotentIntegrationDispatcher {
  private readonly ledger = new Map<string, IntegrationDispatchResult>();

  dispatch(params: {
    adapterId: IntegrationAdapterInfo['id'];
    idempotencyKey: string;
    simulateFailure?: boolean;
    nowIso?: string;
  }): IntegrationDispatchResult {
    const { adapterId, idempotencyKey, simulateFailure = false, nowIso = new Date().toISOString() } = params;
    const existing = this.ledger.get(idempotencyKey);

    // If a prior attempt succeeded, return cached result without duplicating side-effects
    if (existing && existing.status === 'COMPLETED') {
      return {
        ...existing,
        reconciledFromCache: true,
      };
    }

    const attempts = existing ? existing.attempts + 1 : 1;

    if (simulateFailure) {
      const failed: IntegrationDispatchResult = {
        idempotencyKey,
        adapterId,
        status: 'FAILED',
        errorMessage: `${adapterId.toUpperCase()} upstream gateway timed out (HTTP 504). Parent workflow remains pending reconciliation.`,
        attempts,
        reconciledFromCache: false,
        dispatchedAt: nowIso,
      };
      this.ledger.set(idempotencyKey, failed);
      return failed;
    }

    const succeeded: IntegrationDispatchResult = {
      idempotencyKey,
      adapterId,
      status: 'COMPLETED',
      externalReference: `${adapterId.toUpperCase()}-REF-${idempotencyKey.slice(-6).toUpperCase()}`,
      attempts,
      reconciledFromCache: false,
      dispatchedAt: nowIso,
    };
    this.ledger.set(idempotencyKey, succeeded);
    return succeeded;
  }

  getByKey(idempotencyKey: string): IntegrationDispatchResult | undefined {
    return this.ledger.get(idempotencyKey);
  }
}
