import {
  DemoRoleId,
  EmergencyAccessGrant,
  EmployeeRecord,
  PolicyDocument,
  RestrictedHrCase,
  WorkspaceTask,
} from './models';

export type NavSectionId =
  | 'workspace'
  | 'employment'
  | 'leave'
  | 'pay-expenses'
  | 'tasks'
  | 'approvals'
  | 'learning'
  | 'people'
  | 'services'
  | 'policies'
  | 'hr-casework'
  | 'reporting'
  | 'governance';

export interface RoleCapabilities {
  roleId: DemoRoleId;
  label: string;
  summary: string;
  canApproveLeave: boolean;
  canApproveExpensesManager: boolean;
  canProcessFinancePayments: boolean;
  canManageHrCases: boolean;
  canFulfilItTickets: boolean;
  canViewManagementReporting: boolean;
  canViewAuditLogs: boolean;
  canConfigurePolicies: boolean;
  canBulkReassignTasks: boolean;
  hasAutomaticPersonnelPiiAccess: boolean;
  authorisedSections: NavSectionId[];
}

export const ROLE_MATRIX: Record<DemoRoleId, RoleCapabilities> = {
  employee: {
    roleId: 'employee',
    label: 'Employee',
    summary: 'Self-service access to employment, leave, expenses, tasks, approvals assigned as cover, learning, services, and policies.',
    canApproveLeave: false,
    canApproveExpensesManager: false,
    canProcessFinancePayments: false,
    canManageHrCases: false,
    canFulfilItTickets: false,
    canViewManagementReporting: false,
    canViewAuditLogs: false,
    canConfigurePolicies: false,
    canBulkReassignTasks: false,
    hasAutomaticPersonnelPiiAccess: false,
    authorisedSections: [
      'workspace',
      'employment',
      'leave',
      'pay-expenses',
      'tasks',
      'approvals',
      'learning',
      'people',
      'services',
      'policies',
    ],
  },
  line_manager: {
    roleId: 'line_manager',
    label: 'Line Manager',
    summary: 'Approves direct-report leave, expenses, and tasks; views team availability without confidential HR/medical case access.',
    canApproveLeave: true,
    canApproveExpensesManager: true,
    canProcessFinancePayments: false,
    canManageHrCases: false,
    canFulfilItTickets: false,
    canViewManagementReporting: true,
    canViewAuditLogs: false,
    canConfigurePolicies: false,
    canBulkReassignTasks: true,
    hasAutomaticPersonnelPiiAccess: false,
    authorisedSections: [
      'workspace',
      'employment',
      'leave',
      'pay-expenses',
      'tasks',
      'approvals',
      'learning',
      'people',
      'services',
      'policies',
      'reporting',
    ],
  },
  hr_adviser: {
    roleId: 'hr_adviser',
    label: 'HR Adviser',
    summary: 'Manages assigned HR & employee-relations cases, onboarding/leaver journeys, and personal detail verification workflows.',
    canApproveLeave: false,
    canApproveExpensesManager: false,
    canProcessFinancePayments: false,
    canManageHrCases: true,
    canFulfilItTickets: false,
    canViewManagementReporting: true,
    canViewAuditLogs: false,
    canConfigurePolicies: true,
    canBulkReassignTasks: true,
    hasAutomaticPersonnelPiiAccess: true,
    authorisedSections: [
      'workspace',
      'employment',
      'leave',
      'pay-expenses',
      'tasks',
      'approvals',
      'learning',
      'people',
      'services',
      'policies',
      'hr-casework',
      'reporting',
    ],
  },
  finance_officer: {
    roleId: 'finance_officer',
    label: 'Finance Officer',
    summary: 'Reviews expense claims for policy compliance, executes payroll/finance payouts, and reconciles payment failures.',
    canApproveLeave: false,
    canApproveExpensesManager: false,
    canProcessFinancePayments: true,
    canManageHrCases: false,
    canFulfilItTickets: false,
    canViewManagementReporting: true,
    canViewAuditLogs: false,
    canConfigurePolicies: false,
    canBulkReassignTasks: false,
    hasAutomaticPersonnelPiiAccess: false,
    authorisedSections: [
      'workspace',
      'employment',
      'leave',
      'pay-expenses',
      'tasks',
      'approvals',
      'learning',
      'people',
      'services',
      'policies',
      'reporting',
    ],
  },
  it_agent: {
    roleId: 'it_agent',
    label: 'IT Service Agent',
    summary: 'Fulfils equipment, software, access, and onboarding IT provisioning tickets through ITSM and IdP integrations.',
    canApproveLeave: false,
    canApproveExpensesManager: false,
    canProcessFinancePayments: false,
    canManageHrCases: false,
    canFulfilItTickets: true,
    canViewManagementReporting: true,
    canViewAuditLogs: false,
    canConfigurePolicies: false,
    canBulkReassignTasks: true,
    hasAutomaticPersonnelPiiAccess: false,
    authorisedSections: [
      'workspace',
      'employment',
      'leave',
      'pay-expenses',
      'tasks',
      'approvals',
      'learning',
      'people',
      'services',
      'policies',
      'reporting',
    ],
  },
  dept_admin: {
    roleId: 'dept_admin',
    label: 'Department Administrator',
    summary: 'Configures workflow rules, departmental parameters, and integrations; barred from unrestricted HR/personnel PII without emergency access.',
    canApproveLeave: false,
    canApproveExpensesManager: false,
    canProcessFinancePayments: false,
    canManageHrCases: false,
    canFulfilItTickets: false,
    canViewManagementReporting: true,
    canViewAuditLogs: true,
    canConfigurePolicies: true,
    canBulkReassignTasks: true,
    hasAutomaticPersonnelPiiAccess: false, // Explicit rule: technical/dept admin does NOT automatically receive unrestricted personnel-data access
    authorisedSections: [
      'workspace',
      'employment',
      'leave',
      'pay-expenses',
      'tasks',
      'approvals',
      'learning',
      'people',
      'services',
      'policies',
      'reporting',
      'governance',
    ],
  },
  auditor: {
    roleId: 'auditor',
    label: 'Auditor',
    summary: 'Read-only assurance access to tamper-evident audit logs, aggregated reporting, permission matrices, and workflow versions.',
    canApproveLeave: false,
    canApproveExpensesManager: false,
    canProcessFinancePayments: false,
    canManageHrCases: false,
    canFulfilItTickets: false,
    canViewManagementReporting: true,
    canViewAuditLogs: true,
    canConfigurePolicies: false,
    canBulkReassignTasks: false,
    hasAutomaticPersonnelPiiAccess: false,
    authorisedSections: [
      'workspace',
      'employment',
      'leave',
      'pay-expenses',
      'tasks',
      'approvals',
      'learning',
      'people',
      'services',
      'policies',
      'reporting',
      'governance',
    ],
  },
};

export function canAccessSection(role: DemoRoleId, section: NavSectionId): boolean {
  return ROLE_MATRIX[role].authorisedSections.includes(section);
}

export function isEmergencyGrantActive(
  grant: EmergencyAccessGrant | null | undefined,
  nowIso: string,
): boolean {
  if (!grant || grant.revoked) return false;
  return grant.expiresAt > nowIso;
}

/**
 * Enforces strict case-specific access controls:
 * - Subject employee can see their own case summary.
 * - Explicitly assigned HR adviser or named viewer in `allowedViewerIds` can view.
 * - A line manager does NOT automatically see sensitive cases relating to their reports.
 * - A technical/department administrator does NOT automatically see restricted HR cases unless holding a time-bounded Emergency Access grant.
 */
export function canViewRestrictedHrCase(
  actor: EmployeeRecord,
  hrCase: RestrictedHrCase,
  emergencyGrant?: EmergencyAccessGrant | null,
  nowIso = new Date().toISOString(),
): boolean {
  if (actor.id === hrCase.subjectEmployeeId) return true;
  if (actor.demoRole === 'hr_adviser' && hrCase.assignedAdviserId === actor.id) return true;
  if (hrCase.allowedViewerIds.includes(actor.id)) return true;

  if (
    emergencyGrant &&
    emergencyGrant.grantedToUserId === actor.id &&
    emergencyGrant.scope === 'restricted-hr' &&
    emergencyGrant.targetRecordId === hrCase.id &&
    isEmergencyGrantActive(emergencyGrant, nowIso)
  ) {
    return true;
  }

  return false;
}

export function canViewEmployeePrivatePii(
  actor: EmployeeRecord,
  targetEmployeeId: string,
  emergencyGrant?: EmergencyAccessGrant | null,
  nowIso = new Date().toISOString(),
): boolean {
  if (actor.id === targetEmployeeId) return true;
  if (actor.demoRole === 'hr_adviser') return true;
  if (
    emergencyGrant &&
    emergencyGrant.grantedToUserId === actor.id &&
    emergencyGrant.scope === 'pii-verification' &&
    emergencyGrant.targetRecordId === targetEmployeeId &&
    isEmergencyGrantActive(emergencyGrant, nowIso)
  ) {
    return true;
  }
  // Explicitly blocks dept_admin, auditor, line_manager, it_agent, finance_officer
  return false;
}

export function canReassignTask(
  actor: EmployeeRecord,
  task: WorkspaceTask,
): { allowed: boolean; reason?: string } {
  if (actor.demoRole === 'auditor') {
    return { allowed: false, reason: 'Auditors hold read-only assurance permissions and cannot reassign tasks.' };
  }
  const caps = ROLE_MATRIX[actor.demoRole];
  if (caps.canBulkReassignTasks) {
    return { allowed: true };
  }
  if (task.ownerId === actor.id || task.creatorId === actor.id) {
    return { allowed: true };
  }
  return {
    allowed: false,
    reason: 'You may only delegate tasks you own or manage within your team scope.',
  };
}

export function canViewPolicyDocument(
  actor: EmployeeRecord,
  policy: PolicyDocument,
): boolean {
  if (policy.handlingClassification === 'RESTRICTED-HR') {
    return actor.demoRole === 'hr_adviser' || actor.demoRole === 'auditor';
  }
  if (policy.departmentScope === 'All Departments') return true;
  return policy.departmentScope === actor.departmentId || actor.demoRole === 'dept_admin' || actor.demoRole === 'auditor';
}

export interface AggregatedMetricRow {
  groupLabel: string;
  count: number;
  suppressed: boolean;
  displayValue: string;
}

/**
 * Suppresses small groups (1 <= count < threshold) in sensitive management reports
 * to prevent indirect identification of individuals.
 */
export function suppressSmallGroups(
  rows: { groupLabel: string; count: number }[],
  threshold = 5,
): AggregatedMetricRow[] {
  return rows.map((row) => {
    const suppressed = row.count > 0 && row.count < threshold;
    return {
      groupLabel: row.groupLabel,
      count: suppressed ? 0 : row.count,
      suppressed,
      displayValue: suppressed ? `< ${threshold} (Suppressed)` : String(row.count),
    };
  });
}

/**
 * Pure deterministic hash function for tamper-evident audit chaining across browser & SSR.
 */
export function computeAuditHash(prevHash: string, payload: string): string {
  const input = `${prevHash}|${payload}`;
  let h1 = 0xdeadbeef ^ input.length;
  let h2 = 0x41c6ce57 ^ input.length;
  for (let i = 0; i < input.length; i++) {
    const ch = input.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  const part1 = (h1 >>> 0).toString(16).padStart(8, '0');
  const part2 = (h2 >>> 0).toString(16).padStart(8, '0');
  return `sha256-chain-${part1}${part2}`;
}
