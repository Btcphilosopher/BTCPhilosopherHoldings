import { describe, expect, it } from 'vitest';
import { IdempotentIntegrationDispatcher } from './integrations';
import {
  calculateLeaveBooking,
  calculateProRataEntitlement,
  projectTeamAvailability,
} from './leave-calculator';
import {
  canAccessSection,
  canViewEmployeePrivatePii,
  canViewRestrictedHrCase,
  computeAuditHash,
  suppressSmallGroups,
} from './permissions';
import {
  DEPARTMENTS,
  SEED_APPROVALS,
  SEED_DELEGATIONS,
  SEED_EMPLOYEES,
  SEED_EXPENSE_CLAIMS,
  SEED_HR_CASES,
  SEED_LEAVE_BALANCES,
  SEED_LEAVE_REQUESTS,
  SEED_TASKS,
} from './seed-data';
import {
  createDelegationGrant,
  delegateOrEscalateTask,
  transitionApprovalItem,
  transitionExpenseClaim,
  transitionLeaveRequest,
  WorkflowDomainError,
} from './workflow-engine';

const emp = SEED_EMPLOYEES.find((e) => e.id === 'emp-employee')!;
const mgr = SEED_EMPLOYEES.find((e) => e.id === 'emp-manager')!;
const hr = SEED_EMPLOYEES.find((e) => e.id === 'emp-hr')!;
const finance = SEED_EMPLOYEES.find((e) => e.id === 'emp-finance')!;
const itAgent = SEED_EMPLOYEES.find((e) => e.id === 'emp-it')!;
const deptAdmin = SEED_EMPLOYEES.find((e) => e.id === 'emp-admin')!;
const auditor = SEED_EMPLOYEES.find((e) => e.id === 'emp-auditor')!;
const digitalDept = DEPARTMENTS[0];

describe('Civil Service Workspace — Security, Permissions & Workflow Engine', () => {
  it('enforces navigation and role permission boundaries', () => {
    expect(canAccessSection('employee', 'hr-casework')).toBe(false);
    expect(canAccessSection('employee', 'governance')).toBe(false);
    expect(canAccessSection('hr_adviser', 'hr-casework')).toBe(true);
    expect(canAccessSection('dept_admin', 'governance')).toBe(true);
    expect(canAccessSection('dept_admin', 'hr-casework')).toBe(false);
    expect(canAccessSection('auditor', 'governance')).toBe(true);
  });

  it('isolates restricted HR cases from line managers and technical admins unless break-glass granted', () => {
    const grievanceCase = SEED_HR_CASES[1]; // subject: emp-it, adviser: emp-hr
    expect(canViewRestrictedHrCase(itAgent, grievanceCase)).toBe(true);
    expect(canViewRestrictedHrCase(hr, grievanceCase)).toBe(true);
    // Line manager and Dept Admin must NOT automatically see sensitive cases
    expect(canViewRestrictedHrCase(mgr, grievanceCase)).toBe(false);
    expect(canViewRestrictedHrCase(deptAdmin, grievanceCase)).toBe(false);
    // Technical admin also cannot inspect private PII without emergency break-glass
    expect(canViewEmployeePrivatePii(deptAdmin, emp.id)).toBe(false);
    expect(canViewEmployeePrivatePii(hr, emp.id)).toBe(true);

    const activeGrant = {
      id: 'emg-1',
      grantedToUserId: deptAdmin.id,
      reason: 'Urgent statutory subject-access compliance verification',
      scope: 'restricted-hr' as const,
      targetRecordId: grievanceCase.id,
      grantedAt: '2026-11-21T08:00:00Z',
      expiresAt: '2026-11-21T12:00:00Z',
      revoked: false,
    };
    expect(
      canViewRestrictedHrCase(deptAdmin, grievanceCase, activeGrant, '2026-11-21T09:00:00Z'),
    ).toBe(true);
    // Expired break-glass grant must immediately deny access
    expect(
      canViewRestrictedHrCase(deptAdmin, grievanceCase, activeGrant, '2026-11-21T13:00:00Z'),
    ).toBe(false);
  });

  it('blocks self-approval on leave requests, expense claims, and generic approvals', () => {
    const leaveReq = SEED_LEAVE_REQUESTS[0];
    expect(() =>
      transitionLeaveRequest({
        request: leaveReq,
        actor: emp,
        action: 'approve',
        expectedVersion: leaveReq.version,
        delegations: SEED_DELEGATIONS,
        nowIso: '2026-11-21T09:00:00Z',
      }),
    ).toThrowError(WorkflowDomainError);

    const expClaim = SEED_EXPENSE_CLAIMS[0];
    expect(() =>
      transitionExpenseClaim({
        claim: expClaim,
        actor: emp,
        action: 'manager_approve',
        expectedVersion: expClaim.version,
        delegations: SEED_DELEGATIONS,
        nowIso: '2026-11-21T09:00:00Z',
      }),
    ).toThrowError(/Separation of duties/);

    const apr = SEED_APPROVALS[0];
    expect(() =>
      transitionApprovalItem({
        approval: apr,
        actor: emp,
        decision: 'Approve',
        expectedVersion: apr.version,
        delegations: SEED_DELEGATIONS,
        nowIso: '2026-11-21T09:00:00Z',
      }),
    ).toThrowError(/cannot approve/);
  });

  it('blocks unauthorised delegation and prevents self-delegation or auditor delegation', () => {
    expect(() =>
      createDelegationGrant({
        actor: mgr,
        fromUserId: mgr.id,
        toUser: mgr,
        scope: ['leave'],
        reason: 'Self cover',
        startsAt: '2026-11-20T00:00:00Z',
        endsAt: '2026-11-30T23:59:59Z',
      }),
    ).toThrowError(/yourself/);

    expect(() =>
      createDelegationGrant({
        actor: emp,
        fromUserId: mgr.id,
        toUser: emp,
        scope: ['leave'],
        reason: 'Unauthorised hijack',
        startsAt: '2026-11-20T00:00:00Z',
        endsAt: '2026-11-30T23:59:59Z',
      }),
    ).toThrowError(/Only the authority holder/);

    expect(() =>
      createDelegationGrant({
        actor: mgr,
        fromUserId: mgr.id,
        toUser: auditor,
        scope: ['leave'],
        reason: 'Cover',
        startsAt: '2026-11-20T00:00:00Z',
        endsAt: '2026-11-30T23:59:59Z',
      }),
    ).toThrowError(/Auditor/);
  });

  it('detects concurrent optimistic version conflicts and preserves pinned rule versions', () => {
    const leaveReq = SEED_LEAVE_REQUESTS[0];
    const approved = transitionLeaveRequest({
      request: leaveReq,
      actor: mgr,
      action: 'approve',
      expectedVersion: leaveReq.version,
      reason: 'Cover confirmed',
      delegations: SEED_DELEGATIONS,
      nowIso: '2026-11-21T09:00:00Z',
    });
    expect(approved.status).toBe('Approved');
    expect(approved.version).toBe(2);
    expect(approved.ruleVersion).toBe('LEAVE-RULE-v2.1');

    // Second concurrent approver acting on stale version 1 must fail
    expect(() =>
      transitionLeaveRequest({
        request: approved,
        actor: deptAdmin, // has Friday cover delegation
        action: 'reject',
        expectedVersion: 1,
        reason: 'Late conflict',
        delegations: SEED_DELEGATIONS,
        nowIso: '2026-11-21T09:05:00Z',
      }),
    ).toThrowError(/concurrently|terminal state/);

    // In-flight approval preserves pinned ruleVersion
    const apr = SEED_APPROVALS[1];
    const stage1Done = transitionApprovalItem({
      approval: apr,
      actor: mgr,
      decision: 'Approve',
      expectedVersion: apr.version,
      delegations: SEED_DELEGATIONS,
      nowIso: '2026-11-21T09:00:00Z',
    });
    expect(stage1Done.ruleVersion).toBe('EXPENSE-RULE-v3.1');
    expect(stage1Done.nextActionUserId).toBe('emp-finance');
    expect(stage1Done.overallStatus).toBe('Finance review');
  });

  it('calculates regional UK bank holidays, pro-rata FTE, conflicts, and hides medical details on team calendars', () => {
    // 2026-11-30 is St Andrew's Day (Scotland Bank Holiday), Tuesday 2026-12-01 is normal working day
    const scotlandCalc = calculateLeaveBooking({
      startDate: '2026-11-30',
      endDate: '2026-12-01',
      halfDay: false,
      region: 'scotland',
      leaveType: 'Annual leave',
      balance: SEED_LEAVE_BALANCES[2],
      existingRequests: [],
      department: digitalDept,
    });
    expect(scotlandCalc.workingDays).toBe(1);
    expect(scotlandCalc.excludedBankHolidays.map((h) => h.name)).toContain('St Andrew’s Day');

    const englandCalc = calculateLeaveBooking({
      startDate: '2026-11-30',
      endDate: '2026-12-01',
      halfDay: false,
      region: 'england-wales',
      leaveType: 'Annual leave',
      balance: SEED_LEAVE_BALANCES[0],
      existingRequests: [],
      department: digitalDept,
    });
    expect(englandCalc.workingDays).toBe(2);

    // Overlapping date conflict detection
    const overlapCalc = calculateLeaveBooking({
      startDate: '2026-12-08',
      endDate: '2026-12-10',
      halfDay: false,
      region: 'england-wales',
      leaveType: 'Annual leave',
      balance: SEED_LEAVE_BALANCES[0],
      existingRequests: SEED_LEAVE_REQUESTS,
      department: digitalDept,
    });
    expect(overlapCalc.conflictingRequestIds).toContain('LV-2026-041');
    expect(overlapCalc.validationErrors.length).toBeGreaterThan(0);

    // Pro-rata entitlement
    expect(calculateProRataEntitlement(28, 0.8)).toBe(22.5);

    // Team calendar must NOT expose medical details
    const empMap = new Map(SEED_EMPLOYEES.map((e) => [e.id, { displayName: e.displayName, team: e.team }]));
    const availability = projectTeamAvailability(SEED_LEAVE_REQUESTS, empMap);
    const sicknessEntry = availability.find((a) => a.employeeId === 'emp-it');
    expect(sicknessEntry?.availabilityLabel).toBe('Unavailable (Absence)');
    expect(JSON.stringify(availability)).not.toContain('dental');
  });

  it('handles expense payment failure, idempotent integration retries, and recovery without false completion', () => {
    const dispatcher = new IdempotentIntegrationDispatcher();
    const failResult = dispatcher.dispatch({
      adapterId: 'payroll',
      idempotencyKey: 'idem-exp-115-pay',
      simulateFailure: true,
    });
    expect(failResult.status).toBe('FAILED');

    // Recover failed expense claim via Finance Officer retry
    const failedClaim = SEED_EXPENSE_CLAIMS[1];
    expect(failedClaim.status).toBe('Payment failed');

    const retryResult = dispatcher.dispatch({
      adapterId: 'payroll',
      idempotencyKey: 'idem-exp-115-pay',
      simulateFailure: false,
    });
    expect(retryResult.status).toBe('COMPLETED');
    expect(retryResult.attempts).toBe(2);

    // Duplicate call with same idempotencyKey returns cached result without side-effects
    const duplicateCall = dispatcher.dispatch({
      adapterId: 'payroll',
      idempotencyKey: 'idem-exp-115-pay',
      simulateFailure: false,
    });
    expect(duplicateCall.reconciledFromCache).toBe(true);
    expect(duplicateCall.attempts).toBe(2);

    const paidClaim = transitionExpenseClaim({
      claim: failedClaim,
      actor: finance,
      action: 'retry_payment',
      expectedVersion: failedClaim.version,
      delegations: SEED_DELEGATIONS,
      nowIso: '2026-11-21T10:00:00Z',
    });
    expect(paidClaim.status).toBe('Paid');
    expect(paidClaim.paymentReference).toContain('BACS-EXP-2026-115');
  });

  it('enforces task delegation permission checks, small-group suppression, and audit chain integrity', () => {
    const task = SEED_TASKS[0];
    expect(() =>
      delegateOrEscalateTask({
        task,
        actor: auditor,
        targetUser: mgr,
        mode: 'delegate',
        reason: 'Attempt by auditor',
        nowIso: '2026-11-21T10:00:00Z',
      }),
    ).toThrowError(/read-only/);

    const escalated = delegateOrEscalateTask({
      task,
      actor: mgr,
      targetUser: deptAdmin,
      mode: 'escalate',
      reason: 'Approaching WCAG publication deadline',
      nowIso: '2026-11-21T10:00:00Z',
    });
    expect(escalated.priority).toBe('Urgent');
    expect(escalated.escalatedToId).toBe(deptAdmin.id);

    const suppressed = suppressSmallGroups([
      { groupLabel: 'Citizen Services', count: 14 },
      { groupLabel: 'Security Vetting', count: 3 },
      { groupLabel: 'Zero Group', count: 0 },
    ]);
    expect(suppressed[0].suppressed).toBe(false);
    expect(suppressed[1].suppressed).toBe(true);
    expect(suppressed[1].displayValue).toBe('< 5 (Suppressed)');
    expect(suppressed[2].suppressed).toBe(false);

    const h1 = computeAuditHash('0000', 'event-1');
    const h2 = computeAuditHash('0000', 'event-1');
    const h3 = computeAuditHash('0000', 'event-2');
    expect(h1).toBe(h2);
    expect(h1).not.toBe(h3);
  });
});
