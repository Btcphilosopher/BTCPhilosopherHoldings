import { GoogleGenAI, Type } from '@google/genai';
import express, { Request, Response } from 'express';
import { IdempotentIntegrationDispatcher, INTEGRATION_ADAPTERS } from '../domain/integrations';
import { calculateLeaveBooking } from '../domain/leave-calculator';
import { canViewPolicyDocument, ROLE_MATRIX } from '../domain/permissions';
import {
  DEPARTMENTS,
  SEED_EMPLOYEES,
  SEED_LEAVE_BALANCES,
  SEED_POLICIES,
  SEED_TASKS,
} from '../domain/seed-data';
import { DemoRoleId, LeaveRequest, UkRegion } from '../domain/models';

const serverDispatcher = new IdempotentIntegrationDispatcher();

export const apiRouter = express.Router();

apiRouter.use(express.json({ limit: '512kb' }));

apiRouter.get('/health', (_req: Request, res: Response) => {
  res.json({
    service: 'Civil Service Workspace API',
    status: 'operational',
    timestamp: new Date().toISOString(),
  });
});

apiRouter.get('/docs', (_req: Request, res: Response) => {
  res.json({
    openapi: '3.1.0-preview',
    title: 'Civil Service Workspace REST API',
    version: '1.0.0',
    description:
      'Typed REST contract designed for the Angular web workspace and future Kotlin Android/multiplatform clients. All sensitive mutations validate RBAC, idempotency keys, and optimistic version numbers.',
    endpoints: [
      {
        method: 'GET',
        path: '/api/health',
        auth: 'Public health check',
        description: 'Returns service readiness without exposing internal configuration.',
      },
      {
        method: 'GET',
        path: '/api/docs',
        auth: 'Authenticated workspace session',
        description: 'Machine-readable API catalogue for web and Kotlin mobile clients.',
      },
      {
        method: 'POST',
        path: '/api/workflows/evaluate-leave',
        auth: 'Bearer token / Workspace role',
        requestBody: {
          employeeId: 'string',
          startDate: 'YYYY-MM-DD',
          endDate: 'YYYY-MM-DD',
          halfDay: 'boolean',
          region: 'england-wales | scotland | northern-ireland',
          leaveType: 'Annual leave | Flexi leave | Sickness absence | Parental leave | Special leave | Time off in lieu (TOIL)',
        },
        description:
          'Server-authoritative working-day, regional bank holiday, balance, and overlap validation.',
      },
      {
        method: 'POST',
        path: '/api/integrations/dispatch',
        auth: 'Finance Officer / IT Service Agent / Dept Admin',
        requestBody: {
          adapterId: 'hris | payroll | idp | calendar | learning | finance | itsm | records',
          idempotencyKey: 'string',
          simulateFailure: 'boolean (optional)',
        },
        description:
          'Idempotency-keyed downstream integration dispatch with explicit failure isolation and retry recovery.',
      },
      {
        method: 'POST',
        path: '/api/assistant/query',
        auth: 'Opt-in session (disabled by default)',
        requestBody: {
          role: 'DemoRoleId',
          employeeId: 'string',
          prompt: 'string (max 1000 chars)',
        },
        description:
          'Permission-aware policy and task guidance assistant. Returns citations and effective dates; never submits transactions or accesses restricted HR records.',
      },
    ],
    adapters: INTEGRATION_ADAPTERS,
  });
});

apiRouter.post('/workflows/evaluate-leave', (req: Request, res: Response) => {
  const body = req.body as Partial<{
    employeeId: string;
    startDate: string;
    endDate: string;
    halfDay: boolean;
    region: UkRegion;
    leaveType: LeaveRequest['leaveType'];
    existingRequests: LeaveRequest[];
  }>;

  if (!body.employeeId || !body.startDate || !body.endDate || !body.leaveType) {
    res.status(400).json({ error: 'employeeId, startDate, endDate, and leaveType are required.' });
    return;
  }

  const employee = SEED_EMPLOYEES.find((e) => e.id === body.employeeId);
  const balance = SEED_LEAVE_BALANCES.find((b) => b.employeeId === body.employeeId);
  if (!employee || !balance) {
    res.status(404).json({ error: 'Employee or leave balance record not found.' });
    return;
  }

  const department =
    DEPARTMENTS.find((d) => d.id === employee.departmentId) ?? DEPARTMENTS[0];

  const evaluation = calculateLeaveBooking({
    startDate: String(body.startDate),
    endDate: String(body.endDate),
    halfDay: Boolean(body.halfDay),
    region: body.region ?? employee.region,
    leaveType: body.leaveType,
    balance,
    existingRequests: Array.isArray(body.existingRequests) ? body.existingRequests : [],
    department,
  });

  res.json(evaluation);
});

apiRouter.post('/integrations/dispatch', (req: Request, res: Response) => {
  const body = req.body as Partial<{
    adapterId: string;
    idempotencyKey: string;
    simulateFailure: boolean;
    actorRole: DemoRoleId;
  }>;

  if (!body.adapterId || !body.idempotencyKey) {
    res.status(400).json({ error: 'adapterId and idempotencyKey are required.' });
    return;
  }

  const validAdapter = INTEGRATION_ADAPTERS.find((a) => a.id === body.adapterId);
  if (!validAdapter) {
    res.status(400).json({ error: 'Unknown integration adapterId.' });
    return;
  }

  if (body.actorRole === 'auditor') {
    res.status(403).json({ error: 'Auditors hold read-only assurance permissions and cannot dispatch integrations.' });
    return;
  }

  const result = serverDispatcher.dispatch({
    adapterId: validAdapter.id,
    idempotencyKey: String(body.idempotencyKey).slice(0, 128),
    simulateFailure: Boolean(body.simulateFailure),
  });

  res.status(result.status === 'FAILED' ? 502 : 200).json(result);
});

apiRouter.post('/assistant/query', async (req: Request, res: Response) => {
  const body = req.body as Partial<{
    employeeId: string;
    prompt: string;
    enabled: boolean;
  }>;

  if (!body.enabled) {
    res.status(403).json({
      error:
        'Policy Assistant is disabled by default. Enable it explicitly in the assistant panel before querying.',
    });
    return;
  }

  const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
  if (!prompt || prompt.length > 1000) {
    res.status(400).json({ error: 'Provide a concise question between 1 and 1000 characters.' });
    return;
  }

  const actor = SEED_EMPLOYEES.find((e) => e.id === body.employeeId) ?? SEED_EMPLOYEES[0];
  const roleCaps = ROLE_MATRIX[actor.demoRole];

  // Permission-aware retrieval: only current/authorised policies and non-restricted own tasks
  const authorisedPolicies = SEED_POLICIES.filter((p) => canViewPolicyDocument(actor, p)).map(
    (p) => ({
      id: p.id,
      title: p.title,
      version: p.version,
      effectiveDate: p.effectiveDate,
      status: p.status,
      owner: p.owner,
      summary: p.summary,
      guidance: p.fullGuidance,
    }),
  );

  const authorisedTasks = SEED_TASKS.filter(
    (t) => t.ownerId === actor.id && t.handling === 'STANDARD',
  ).map((t) => ({
    id: t.id,
    title: t.title,
    dueDate: t.dueDate,
    priority: t.priority,
    status: t.status,
  }));

  const apiKey = process.env['GEMINI_API_KEY'];
  if (!apiKey) {
    res.status(503).json({
      error:
        'GEMINI_API_KEY is not configured in server environment secrets. Add it in Settings > Secrets to use the Policy Assistant.',
    });
    return;
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const systemInstruction = [
      'You are the optional Civil Service Workspace Policy & Guidance Assistant.',
      'Follow these strict governance rules:',
      '1. Answer ONLY using the authorised policies and authorised tasks supplied in context.',
      '2. Cite exact policy IDs, versions, and effective dates; clearly warn if a cited document is Superseded (Expired).',
      '3. Never make employment decisions, never approve/reject requests, never submit transactions, and never invent official allowances or pension figures.',
      '4. Never disclose restricted HR, medical, or third-party personnel details.',
      `Current user role: ${roleCaps.label} (${actor.departmentId}).`,
    ].join('\n');

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: JSON.stringify({
        userQuestion: prompt,
        authorisedPolicies,
        authorisedTasks,
      }),
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            answer: {
              type: Type.STRING,
              description: 'Plain-English guidance answering the user request without making decisions.',
            },
            citations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  policyId: { type: Type.STRING },
                  title: { type: Type.STRING },
                  version: { type: Type.STRING },
                  effectiveDate: { type: Type.STRING },
                  status: { type: Type.STRING },
                },
              },
            },
            draftWording: {
              type: Type.STRING,
              description: 'Optional draft request text for the user to review before submitting manually.',
            },
            advisoryNote: {
              type: Type.STRING,
              description: 'Clear statement that final review/submission remains with the authorised user.',
            },
          },
          required: ['answer', 'citations', 'advisoryNote'],
        },
      },
    });

    const rawText = response.text ?? '{}';
    const parsed = JSON.parse(rawText);
    res.json(parsed);
  } catch (err) {
    console.error('Gemini Policy Assistant error:', err);
    res.status(502).json({
      error:
        'Unable to reach the Policy Assistant model service right now. Please consult the Policies & knowledge library directly.',
    });
  }
});
