import { isPlatformBrowser } from '@angular/common';
import { computed, inject, Injectable, PLATFORM_ID, signal } from '@angular/core';
import type { User } from 'firebase/auth';
import { IdempotentIntegrationDispatcher, INTEGRATION_ADAPTERS } from '../../domain/integrations';
import { calculateLeaveBooking, projectTeamAvailability } from '../../domain/leave-calculator';
import {
  AuditLogEntry,
  DelegationGrant,
  DemoRoleId,
  EmergencyAccessGrant,
  EmployeeRecord,
  ExpenseClaim,
  LeaveBalance,
  LeaveRequest,
  LifecycleJourney,
  PersonalDetailChangeRequest,
  PolicyDocument,
  RestrictedHrCase,
  ServiceTicket,
  UkRegion,
  WorkflowApprovalItem,
  WorkspaceTask,
} from '../../domain/models';
import {
  canAccessSection,
  canViewEmployeePrivatePii,
  canViewPolicyDocument,
  canViewRestrictedHrCase,
  computeAuditHash,
  isEmergencyGrantActive,
  NavSectionId,
  ROLE_MATRIX,
} from '../../domain/permissions';
import {
  buildInitialAuditLog,
  DEPARTMENTS,
  SEED_APPROVALS,
  SEED_DELEGATIONS,
  SEED_EMPLOYEES,
  SEED_EXPENSE_CLAIMS,
  SEED_HR_CASES,
  SEED_LEAVE_BALANCES,
  SEED_LEAVE_REQUESTS,
  SEED_LIFECYCLE_JOURNEYS,
  SEED_PERSONAL_CHANGES,
  SEED_POLICIES,
  SEED_SERVICE_TICKETS,
  SEED_TASKS,
} from '../../domain/seed-data';
import {
  createDelegationGrant,
  delegateOrEscalateTask,
  transitionApprovalItem,
  transitionExpenseClaim,
  transitionLeaveRequest,
  WORKFLOW_RULE_VERSIONS,
} from '../../domain/workflow-engine';
import {
  getFirebaseClient,
  handleFirestoreError,
  OperationType,
  signInWithGoogleWorkspace,
  signOutFirebase,
  testFirestoreConnection,
} from './firebase.client';

export interface NotificationBanner {
  id: string;
  tone: 'info' | 'success' | 'warning' | 'error';
  message: string;
}

@Injectable({ providedIn: 'root' })
export class WorkspaceStore {
  private readonly platformId = inject(PLATFORM_ID);
  private readonly integrationDispatcher = new IdempotentIntegrationDispatcher();

  // Accessibility & UI Preferences
  readonly darkMode = signal(false);
  readonly highContrast = signal(false);
  readonly reducedMotion = signal(false);
  readonly policyAssistantEnabled = signal(false); // Disabled by default per governance spec
  readonly activeSection = signal<NavSectionId>('workspace');
  readonly banner = signal<NotificationBanner | null>(null);

  // Firebase Auth state (optional live persistence alongside synthetic demo mode)
  readonly firebaseUser = signal<User | null>(null);
  readonly firestoreConnected = signal<boolean>(false);

  // Active Demo Actor (7 demonstration roles)
  readonly employees = signal<EmployeeRecord[]>(SEED_EMPLOYEES);
  readonly activeEmployeeId = signal<string>('emp-employee');

  // Core Domain State
  readonly departments = signal(DEPARTMENTS);
  readonly leaveBalances = signal<LeaveBalance[]>(SEED_LEAVE_BALANCES);
  readonly leaveRequests = signal<LeaveRequest[]>(SEED_LEAVE_REQUESTS);
  readonly expenseClaims = signal<ExpenseClaim[]>(SEED_EXPENSE_CLAIMS);
  readonly tasks = signal<WorkspaceTask[]>(SEED_TASKS);
  readonly approvals = signal<WorkflowApprovalItem[]>(SEED_APPROVALS);
  readonly hrCases = signal<RestrictedHrCase[]>(SEED_HR_CASES);
  readonly serviceTickets = signal<ServiceTicket[]>(SEED_SERVICE_TICKETS);
  readonly lifecycleJourneys = signal<LifecycleJourney[]>(SEED_LIFECYCLE_JOURNEYS);
  readonly personalChanges = signal<PersonalDetailChangeRequest[]>(SEED_PERSONAL_CHANGES);
  readonly policies = signal<PolicyDocument[]>(SEED_POLICIES);
  readonly delegations = signal<DelegationGrant[]>(SEED_DELEGATIONS);
  readonly emergencyGrants = signal<EmergencyAccessGrant[]>([]);
  readonly auditLog = signal<AuditLogEntry[]>(buildInitialAuditLog());
  readonly adapters = signal(INTEGRATION_ADAPTERS);
  readonly workflowRules = signal(WORKFLOW_RULE_VERSIONS);

  // Saved drafts for Save-and-Resume accessibility
  readonly leaveDraft = signal<{
    leaveType: LeaveRequest['leaveType'];
    startDate: string;
    endDate: string;
    halfDay: boolean;
    region: UkRegion;
    reasonNote: string;
    isMedicalConfidential: boolean;
  }>({
    leaveType: 'Annual leave',
    startDate: '2026-12-14',
    endDate: '2026-12-16',
    halfDay: false,
    region: 'england-wales',
    reasonNote: '',
    isMedicalConfidential: false,
  });

  // Derived Views
  readonly currentUser = computed(
    () => this.employees().find((e) => e.id === this.activeEmployeeId()) ?? this.employees()[0],
  );

  readonly currentRoleCapabilities = computed(() => ROLE_MATRIX[this.currentUser().demoRole]);

  readonly currentDepartment = computed(
    () =>
      this.departments().find((d) => d.id === this.currentUser().departmentId) ??
      this.departments()[0],
  );

  readonly currentLeaveBalance = computed(
    () =>
      this.leaveBalances().find((b) => b.employeeId === this.currentUser().id) ??
      this.leaveBalances()[0],
  );

  readonly authorisedSections = computed(() => this.currentRoleCapabilities().authorisedSections);

  readonly activeEmergencyGrantForCurrentUser = computed(() => {
    const now = new Date().toISOString();
    return (
      this.emergencyGrants().find(
        (g) => g.grantedToUserId === this.currentUser().id && isEmergencyGrantActive(g, now),
      ) ?? null
    );
  });

  readonly visibleHrCases = computed(() => {
    const actor = this.currentUser();
    const grant = this.activeEmergencyGrantForCurrentUser();
    const now = new Date().toISOString();
    return this.hrCases().filter((c) => canViewRestrictedHrCase(actor, c, grant, now));
  });

  readonly visiblePolicies = computed(() => {
    const actor = this.currentUser();
    return this.policies().filter((p) => canViewPolicyDocument(actor, p));
  });

  readonly teamAvailability = computed(() => {
    const map = new Map(
      this.employees().map((e) => [e.id, { displayName: e.displayName, team: e.team }]),
    );
    return projectTeamAvailability(this.leaveRequests(), map);
  });

  readonly pendingActionsForCurrentUser = computed(() => {
    const uid = this.currentUser().id;
    const now = new Date().toISOString();
    const activeDels = this.delegations();
    return this.approvals().filter((a) => {
      if (['Approved', 'Rejected', 'Withdrawn', 'Paid', 'Completed'].includes(a.overallStatus)) {
        return false;
      }
      return a.stages.some(
        (s) =>
          s.status === 'Pending' &&
          (s.assignedUserId === uid ||
            activeDels.some(
              (d) =>
                d.active &&
                d.fromUserId === s.assignedUserId &&
                d.toUserId === uid &&
                d.startsAt <= now &&
                d.endsAt >= now,
            )),
      );
    });
  });

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      void this.initBrowserFirebase();
    }
  }

  private async initBrowserFirebase(): Promise<void> {
    const { auth } = await getFirebaseClient(this.platformId);
    if (auth) {
      const { onAuthStateChanged } = await import('firebase/auth');
      onAuthStateChanged(auth, (user) => {
        this.firebaseUser.set(user);
      });
    }
    const ok = await testFirestoreConnection(this.platformId);
    this.firestoreConnected.set(ok);
  }

  toggleDarkMode(): void {
    const next = !this.darkMode();
    this.darkMode.set(next);
    if (isPlatformBrowser(this.platformId)) {
      document.documentElement.classList.toggle('dark', next);
    }
  }

  toggleHighContrast(): void {
    const next = !this.highContrast();
    this.highContrast.set(next);
    if (isPlatformBrowser(this.platformId)) {
      document.documentElement.classList.toggle('high-contrast', next);
    }
  }

  toggleReducedMotion(): void {
    const next = !this.reducedMotion();
    this.reducedMotion.set(next);
    if (isPlatformBrowser(this.platformId)) {
      document.documentElement.classList.toggle('reduce-motion', next);
    }
  }

  switchDemoRole(role: DemoRoleId): void {
    const target = this.employees().find((e) => e.demoRole === role);
    if (!target) return;
    this.activeEmployeeId.set(target.id);
    if (!canAccessSection(role, this.activeSection())) {
      this.activeSection.set('workspace');
    }
    this.notify('info', `Switched demonstration session to ${target.displayName} (${ROLE_MATRIX[role].label}).`);
    this.recordAudit('SWITCH_DEMO_ROLE', 'Session', target.id, 'Success', `Active role set to ${ROLE_MATRIX[role].label}`);
  }

  navigate(section: NavSectionId): void {
    if (!canAccessSection(this.currentUser().demoRole, section)) {
      this.recordAudit(
        'SECTION_ACCESS_DENIED',
        'Navigation',
        section,
        'Denied',
        `Role ${this.currentRoleCapabilities().label} is not authorised for ${section}`,
      );
      this.notify('error', 'Access denied: your current role does not hold permission for that section.');
      return;
    }
    this.activeSection.set(section);
  }

  async signInGoogle(): Promise<void> {
    try {
      const user = await signInWithGoogleWorkspace(this.platformId);
      if (user) {
        this.notify('success', `Authenticated via Firebase Google Sign-In as ${user.email}.`);
      }
    } catch (error) {
      this.notify('error', error instanceof Error ? error.message : 'Unable to complete Google sign-in.');
    }
  }

  async signOutGoogle(): Promise<void> {
    await signOutFirebase(this.platformId);
    this.notify('info', 'Signed out of live Firebase session. Synthetic demonstration mode remains available.');
  }

  canInspectPrivatePii(targetEmployeeId: string): boolean {
    return canViewEmployeePrivatePii(
      this.currentUser(),
      targetEmployeeId,
      this.activeEmergencyGrantForCurrentUser(),
      new Date().toISOString(),
    );
  }

  // ---- Journey 1: Annual Leave Request & Manager Approval ----
  submitLeaveRequest(params: {
    leaveType: LeaveRequest['leaveType'];
    startDate: string;
    endDate: string;
    halfDay: boolean;
    region: UkRegion;
    reasonNote: string;
    isMedicalConfidential: boolean;
    idempotencyKey?: string;
  }): { ok: boolean; errors: string[] } {
    const actor = this.currentUser();
    const balance = this.currentLeaveBalance();
    const dept = this.currentDepartment();
    const actorRequests = this.leaveRequests().filter((r) => r.employeeId === actor.id);

    const idempotencyKey =
      params.idempotencyKey ?? `idem-lv-${actor.id}-${params.startDate}-${params.endDate}`;

    if (this.leaveRequests().some((r) => r.idempotencyKey === idempotencyKey)) {
      const msg = 'Duplicate submission blocked: an identical leave request has already been recorded.';
      this.notify('warning', msg);
      return { ok: false, errors: [msg] };
    }

    const calc = calculateLeaveBooking({
      startDate: params.startDate,
      endDate: params.endDate,
      halfDay: params.halfDay,
      region: params.region,
      leaveType: params.leaveType,
      balance,
      existingRequests: actorRequests,
      department: dept,
    });

    if (calc.validationErrors.length > 0) {
      return { ok: false, errors: calc.validationErrors };
    }

    const approverId = actor.managerId ?? 'emp-admin';
    const nowIso = new Date().toISOString();
    const newId = `LV-2026-${String(this.leaveRequests().length + 42).padStart(3, '0')}`;

    const newReq: LeaveRequest = {
      id: newId,
      employeeId: actor.id,
      leaveType: params.leaveType,
      startDate: params.startDate,
      endDate: params.endDate,
      workingDays: calc.workingDays,
      region: params.region,
      halfDay: params.halfDay,
      reasonNote: params.reasonNote.trim(),
      isMedicalConfidential: params.isMedicalConfidential || params.leaveType === 'Sickness absence',
      approverId,
      status: 'Manager review',
      ruleVersion: 'LEAVE-RULE-v2.1',
      version: 1,
      idempotencyKey,
      submittedAt: nowIso,
      updatedAt: nowIso,
    };

    this.leaveRequests.update((list) => [newReq, ...list]);
    if (params.leaveType === 'Annual leave') {
      this.leaveBalances.update((bals) =>
        bals.map((b) =>
          b.employeeId === actor.id ? { ...b, pendingDays: b.pendingDays + calc.workingDays } : b,
        ),
      );
    }

    const approvalItem: WorkflowApprovalItem = {
      id: `APR-2026-${String(this.approvals().length + 305)}`,
      requestType: 'leave',
      referenceId: newId,
      title: `${params.leaveType} · ${actor.displayName} (${calc.workingDays} working days, ${params.startDate} to ${params.endDate})`,
      requesterId: actor.id,
      departmentId: actor.departmentId,
      mode: 'Sequential',
      ruleVersion: 'LEAVE-RULE-v2.1',
      ruleSummary: 'Line Manager review (pinned at submission)',
      stages: [
        {
          stageName: 'Line Manager Review',
          assignedRole: 'Line Manager',
          assignedUserId: approverId,
          status: 'Pending',
        },
      ],
      nextActionUserId: approverId,
      escalationDeadline: new Date(Date.now() + 72 * 3600 * 1000).toISOString(),
      overallStatus: 'Manager review',
      version: 1,
      idempotencyKey: `apr-${idempotencyKey}`,
      createdAt: nowIso,
      updatedAt: nowIso,
    };
    this.approvals.update((list) => [approvalItem, ...list]);

    this.recordAudit(
      'SUBMIT_LEAVE',
      'LeaveRequest',
      newId,
      'Success',
      `Submitted ${calc.workingDays} working days (${params.leaveType})`,
    );
    void this.persistRequestToFirestoreIfSignedIn(newId, 'leave', approvalItem.title, approverId, 'Manager review', 'LEAVE-RULE-v2.1', idempotencyKey);
    this.notify('success', `Leave request ${newId} submitted (${calc.workingDays} working days) and routed to Line Manager.`);
    return { ok: true, errors: [] };
  }

  actOnLeaveRequest(
    requestId: string,
    action: 'approve' | 'reject' | 'return' | 'withdraw',
    reason?: string,
  ): void {
    const req = this.leaveRequests().find((r) => r.id === requestId);
    if (!req) return;
    const actor = this.currentUser();
    const nowIso = new Date().toISOString();

    try {
      const updated = transitionLeaveRequest({
        request: req,
        actor,
        action,
        expectedVersion: req.version,
        reason,
        delegations: this.delegations(),
        nowIso,
      });

      this.leaveRequests.update((list) => list.map((r) => (r.id === requestId ? updated : r)));

      // Update balance cleanly on approval or cancellation/rejection
      if (req.leaveType === 'Annual leave') {
        this.leaveBalances.update((bals) =>
          bals.map((b) => {
            if (b.employeeId !== req.employeeId) return b;
            const pending = Math.max(0, b.pendingDays - req.workingDays);
            const taken = updated.status === 'Approved' ? b.takenDays + req.workingDays : b.takenDays;
            return { ...b, pendingDays: pending, takenDays: taken };
          }),
        );
      }

      // Sync matching approval queue item
      this.approvals.update((aprs) =>
        aprs.map((a) => {
          if (a.referenceId !== requestId) return a;
          return {
            ...a,
            overallStatus: updated.status,
            nextActionUserId: updated.status === 'Returned for correction' ? req.employeeId : null,
            stages: a.stages.map((s) => ({
              ...s,
              status:
                action === 'approve'
                  ? 'Approved'
                  : action === 'reject'
                    ? 'Rejected'
                    : action === 'return'
                      ? 'Returned'
                      : 'Skipped',
              actedByUserId: actor.id,
              actedAt: nowIso,
              reason: updated.decisionReason,
            })),
            version: a.version + 1,
            updatedAt: nowIso,
          };
        }),
      );

      this.recordAudit(
        `LEAVE_${action.toUpperCase()}`,
        'LeaveRequest',
        requestId,
        'Success',
        updated.decisionReason ?? `Leave moved to ${updated.status}`,
      );
      this.notify('success', `Leave request ${requestId} is now ${updated.status}.`);
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Unable to process leave action.';
      this.recordAudit(`LEAVE_${action.toUpperCase()}`, 'LeaveRequest', requestId, 'Denied', msg);
      this.notify('error', msg);
    }
  }

  // ---- Journey 2: Expense Submission, Manager Review, Finance Processing & Recovery ----
  createExpenseClaim(params: {
    title: string;
    costCentre: string;
    category: ExpenseClaim['items'][0]['category'];
    description: string;
    amountGbp: number;
    mileageMiles?: number;
    receiptFileName: string;
    corporateCardUsed: boolean;
  }): void {
    const actor = this.currentUser();
    const nowIso = new Date().toISOString();
    const id = `EXP-2026-${String(this.expenseClaims().length + 119)}`;
    const managerId = actor.managerId ?? 'emp-manager';
    const itemAmount =
      params.category === 'Mileage' && params.mileageMiles
        ? Math.round(params.mileageMiles * (this.currentDepartment().mileageRatePence / 100) * 100) / 100
        : params.amountGbp;

    const claim: ExpenseClaim = {
      id,
      employeeId: actor.id,
      title: params.title.trim(),
      costCentre: params.costCentre.trim() || 'CC-4410-DIG',
      totalAmountGbp: itemAmount,
      corporateCardUsed: params.corporateCardUsed,
      advanceOffsetGbp: 0,
      items: [
        {
          id: `ei-${Date.now()}`,
          category: params.category,
          description: params.description.trim(),
          date: nowIso.slice(0, 10),
          amountGbp: itemAmount,
          mileageMiles: params.mileageMiles,
          receiptFileName: params.receiptFileName.trim() || 'receipt_scan.pdf',
          receiptScanStatus: 'Scanned Clean',
        },
      ],
      managerApproverId: managerId,
      financeReviewerId: 'emp-finance',
      nextActionOwnerId: managerId,
      status: 'Manager review',
      ruleVersion: 'EXPENSE-RULE-v3.1',
      policyEffectiveDate: '2026-09-01',
      version: 1,
      idempotencyKey: `idem-${id.toLowerCase()}`,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    this.expenseClaims.update((list) => [claim, ...list]);
    this.approvals.update((list) => [
      {
        id: `APR-2026-${String(this.approvals().length + 310)}`,
        requestType: 'expense',
        referenceId: id,
        title: `Expense Claim · ${claim.title} (£${claim.totalAmountGbp.toFixed(2)})`,
        requesterId: actor.id,
        departmentId: actor.departmentId,
        amountGbp: claim.totalAmountGbp,
        mode: 'Sequential',
        ruleVersion: 'EXPENSE-RULE-v3.1',
        ruleSummary: 'Sequential: Line Manager review → Finance Officer compliance & payout',
        stages: [
          { stageName: 'Line Manager Verification', assignedRole: 'Line Manager', assignedUserId: managerId, status: 'Pending' },
          { stageName: 'Finance Compliance & Payout', assignedRole: 'Finance Officer', assignedUserId: 'emp-finance', status: 'Pending' },
        ],
        nextActionUserId: managerId,
        escalationDeadline: new Date(Date.now() + 72 * 3600 * 1000).toISOString(),
        overallStatus: 'Manager review',
        version: 1,
        idempotencyKey: `apr-${claim.idempotencyKey}`,
        createdAt: nowIso,
        updatedAt: nowIso,
      },
      ...list,
    ]);

    this.recordAudit('SUBMIT_EXPENSE', 'ExpenseClaim', id, 'Success', `Submitted £${claim.totalAmountGbp.toFixed(2)} claim`);
    void this.persistRequestToFirestoreIfSignedIn(id, 'expense', claim.title, managerId, 'Manager review', 'EXPENSE-RULE-v3.1', claim.idempotencyKey);
    this.notify('success', `Expense claim ${id} (£${claim.totalAmountGbp.toFixed(2)}) submitted to Line Manager.`);
  }

  actOnExpenseClaim(
    claimId: string,
    action:
      | 'submit'
      | 'manager_approve'
      | 'finance_pay'
      | 'finance_fail_payment'
      | 'retry_payment'
      | 'return'
      | 'reject'
      | 'withdraw',
    reason?: string,
  ): void {
    const claim = this.expenseClaims().find((c) => c.id === claimId);
    if (!claim) return;
    const actor = this.currentUser();
    const nowIso = new Date().toISOString();

    try {
      // If attempting payout, invoke idempotent payroll integration adapter first!
      if (action === 'finance_pay' || action === 'finance_fail_payment' || action === 'retry_payment') {
        const dispatch = this.integrationDispatcher.dispatch({
          adapterId: 'payroll',
          idempotencyKey: `${claim.idempotencyKey}-bacs`,
          simulateFailure: action === 'finance_fail_payment',
          nowIso,
        });
        if (dispatch.status === 'FAILED') {
          const failedUpdated = transitionExpenseClaim({
            claim,
            actor,
            action: 'finance_fail_payment',
            expectedVersion: claim.version,
            reason: dispatch.errorMessage,
            delegations: this.delegations(),
            nowIso,
          });
          this.expenseClaims.update((list) => list.map((c) => (c.id === claimId ? failedUpdated : c)));
          this.recordAudit('EXPENSE_PAYMENT_DISPATCH', 'ExpenseClaim', claimId, 'Failed', dispatch.errorMessage ?? 'BACS failure');
          this.notify('warning', `Payroll BACS failed for ${claimId}. Status held as "Payment failed" (never falsely marked Paid).`);
          return;
        }
      }

      const updated = transitionExpenseClaim({
        claim,
        actor,
        action,
        expectedVersion: claim.version,
        reason,
        delegations: this.delegations(),
        nowIso,
      });

      this.expenseClaims.update((list) => list.map((c) => (c.id === claimId ? updated : c)));
      this.recordAudit(
        `EXPENSE_${action.toUpperCase()}`,
        'ExpenseClaim',
        claimId,
        'Success',
        updated.decisionReason ?? `Claim transitioned to ${updated.status}`,
      );
      this.notify('success', `Expense claim ${claimId} updated to "${updated.status}".`);
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Expense transition rejected.';
      this.recordAudit(`EXPENSE_${action.toUpperCase()}`, 'ExpenseClaim', claimId, 'Denied', msg);
      this.notify('error', msg);
    }
  }

  // ---- Journey 3: Equipment & Service Catalogue Requests ----
  submitServiceTicket(params: {
    catalogueCategory: ServiceTicket['catalogueCategory'];
    title: string;
    notes: string;
    costGbp?: number;
  }): void {
    const actor = this.currentUser();
    const nowIso = new Date().toISOString();
    const id = `SRV-2026-${String(this.serviceTickets().length + 510)}`;
    const needsManagerApproval = (params.costGbp ?? 0) > 0 || params.catalogueCategory === 'Equipment Request';

    const ticket: ServiceTicket = {
      id,
      catalogueCategory: params.catalogueCategory,
      title: params.title.trim(),
      requesterId: actor.id,
      assignedAgentId: 'emp-it',
      approverId: needsManagerApproval ? actor.managerId ?? 'emp-manager' : undefined,
      expectedSla: params.catalogueCategory === 'Password & Access' ? '4 hours' : '3 working days',
      costGbp: params.costGbp,
      status: needsManagerApproval ? 'Manager review' : 'Submitted',
      integrationJobStatus: 'Pending',
      version: 1,
      idempotencyKey: `idem-${id.toLowerCase()}`,
      notes: params.notes.trim(),
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    this.serviceTickets.update((list) => [ticket, ...list]);
    this.recordAudit('CREATE_SERVICE_TICKET', 'ServiceTicket', id, 'Success', `${params.catalogueCategory}: ${ticket.title}`);
    this.notify('success', `Service request ${id} logged (Expected SLA: ${ticket.expectedSla}).`);
  }

  fulfilServiceTicket(ticketId: string, simulateItsmFailure = false): void {
    const ticket = this.serviceTickets().find((t) => t.id === ticketId);
    if (!ticket) return;
    const actor = this.currentUser();
    if (!ROLE_MATRIX[actor.demoRole].canFulfilItTickets && actor.demoRole !== 'line_manager') {
      this.recordAudit('FULFIL_SERVICE_TICKET', 'ServiceTicket', ticketId, 'Denied', 'IT Service Agent or Manager authority required');
      this.notify('error', 'Only IT Service Agents or designated approvers can advance service tickets.');
      return;
    }

    const nowIso = new Date().toISOString();
    if (ticket.status === 'Manager review') {
      if (actor.id === ticket.requesterId) {
        this.notify('error', 'Separation of duties: you cannot approve your own equipment request.');
        return;
      }
      this.serviceTickets.update((list) =>
        list.map((t) =>
          t.id === ticketId
            ? { ...t, status: 'Approved', version: t.version + 1, updatedAt: nowIso }
            : t,
        ),
      );
      this.recordAudit('APPROVE_SERVICE_TICKET', 'ServiceTicket', ticketId, 'Success', 'Approved for IT fulfilment');
      this.notify('success', `Equipment request ${ticketId} approved and queued for IT fulfilment.`);
      return;
    }

    const dispatch = this.integrationDispatcher.dispatch({
      adapterId: 'itsm',
      idempotencyKey: `${ticket.idempotencyKey}-itsm`,
      simulateFailure: simulateItsmFailure,
      nowIso,
    });

    if (dispatch.status === 'FAILED') {
      this.serviceTickets.update((list) =>
        list.map((t) =>
          t.id === ticketId
            ? {
                ...t,
                integrationJobStatus: 'Failed',
                integrationError: dispatch.errorMessage,
                updatedAt: nowIso,
              }
            : t,
        ),
      );
      this.recordAudit('ITSM_DISPATCH', 'ServiceTicket', ticketId, 'Failed', dispatch.errorMessage ?? 'ITSM timeout');
      this.notify('warning', `ITSM asset provisioning failed for ${ticketId}. Ticket remains open until reconciled.`);
      return;
    }

    this.serviceTickets.update((list) =>
      list.map((t) =>
        t.id === ticketId
          ? {
              ...t,
              status: 'Completed',
              integrationJobStatus: 'Synced',
              integrationError: undefined,
              version: t.version + 1,
              updatedAt: nowIso,
            }
          : t,
      ),
    );
    this.recordAudit('ITSM_DISPATCH', 'ServiceTicket', ticketId, 'Success', `Fulfilled via ${dispatch.externalReference}`);
    this.notify('success', `Service ticket ${ticketId} completed via ITSM (${dispatch.externalReference}).`);
  }

  // ---- Journey 4: Onboarding / Leaver Milestone Progression ----
  advanceLifecycleStep(journeyId: string, stepId: string): void {
    const actor = this.currentUser();
    if (actor.demoRole === 'auditor') {
      this.notify('error', 'Auditors cannot mutate onboarding or leaver records.');
      return;
    }
    const nowDate = new Date().toISOString().slice(0, 10);
    this.lifecycleJourneys.update((list) =>
      list.map((j) => {
        if (j.id !== journeyId || j.cancelled) return j;
        return {
          ...j,
          updatedAt: new Date().toISOString(),
          steps: j.steps.map((s) =>
            s.id === stepId ? { ...s, status: 'Completed', completedAt: nowDate } : s,
          ),
        };
      }),
    );
    this.recordAudit('ADVANCE_LIFECYCLE_STEP', 'LifecycleJourney', journeyId, 'Success', `Marked step ${stepId} completed`);
    this.notify('success', `Updated lifecycle milestone in ${journeyId}.`);
  }

  updateLifecycleEffectiveDate(journeyId: string, newDate: string, cancelDeparture = false): void {
    const actor = this.currentUser();
    if (!['hr_adviser', 'dept_admin', 'line_manager'].includes(actor.demoRole)) {
      this.notify('error', 'Only HR, Line Manager, or Department Admin may amend employment journey dates.');
      return;
    }
    this.lifecycleJourneys.update((list) =>
      list.map((j) =>
        j.id === journeyId
          ? {
              ...j,
              effectiveDate: newDate || j.effectiveDate,
              cancelled: cancelDeparture ? true : j.cancelled,
              dateChangeNote: cancelDeparture
                ? `Departure cancelled by ${actor.displayName} on ${new Date().toISOString().slice(0, 10)}`
                : `Effective date updated to ${newDate} by ${actor.displayName}`,
              updatedAt: new Date().toISOString(),
            }
          : j,
      ),
    );
    this.recordAudit('AMEND_LIFECYCLE_DATE', 'LifecycleJourney', journeyId, 'Success', cancelDeparture ? 'Cancelled departure' : `Date changed to ${newDate}`);
    this.notify('success', cancelDeparture ? `Departure ${journeyId} cancelled cleanly.` : `Effective date updated for ${journeyId}.`);
  }

  // ---- Journey 5: Task Delegation, Escalation & Bulk Reassignment ----
  delegateTaskAction(taskId: string, targetUserId: string, mode: 'delegate' | 'escalate', reason: string): void {
    const task = this.tasks().find((t) => t.id === taskId);
    const targetUser = this.employees().find((e) => e.id === targetUserId);
    if (!task || !targetUser) return;
    try {
      const updated = delegateOrEscalateTask({
        task,
        actor: this.currentUser(),
        targetUser,
        mode,
        reason,
        nowIso: new Date().toISOString(),
      });
      this.tasks.update((list) => list.map((t) => (t.id === taskId ? updated : t)));
      this.recordAudit(`TASK_${mode.toUpperCase()}`, 'WorkspaceTask', taskId, 'Success', `${mode} to ${targetUser.displayName}: ${reason}`);
      this.notify('success', `Task ${taskId} ${mode === 'escalate' ? 'escalated' : 'delegated'} to ${targetUser.displayName}.`);
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Task reassignment blocked.';
      this.recordAudit(`TASK_${mode.toUpperCase()}`, 'WorkspaceTask', taskId, 'Denied', msg);
      this.notify('error', msg);
    }
  }

  updateTaskStatus(taskId: string, status: WorkspaceTask['status']): void {
    if (this.currentUser().demoRole === 'auditor') {
      this.notify('error', 'Auditors cannot modify task status.');
      return;
    }
    this.tasks.update((list) =>
      list.map((t) =>
        t.id === taskId
          ? {
              ...t,
              status,
              version: t.version + 1,
              updatedAt: new Date().toISOString(),
              auditTrail: [`${new Date().toISOString()}: Status set to ${status} by ${this.currentUser().displayName}`, ...t.auditTrail],
            }
          : t,
      ),
    );
    this.recordAudit('UPDATE_TASK_STATUS', 'WorkspaceTask', taskId, 'Success', `Status -> ${status}`);
  }

  toggleTaskChecklistItem(taskId: string, checklistId: string): void {
    if (this.currentUser().demoRole === 'auditor') return;
    this.tasks.update((list) =>
      list.map((t) =>
        t.id === taskId
          ? {
              ...t,
              checklist: t.checklist.map((c) => (c.id === checklistId ? { ...c, completed: !c.completed } : c)),
              updatedAt: new Date().toISOString(),
            }
          : t,
      ),
    );
  }

  // ---- Approvals Engine Actions ----
  actOnApproval(approvalId: string, decision: 'Approve' | 'Return' | 'Reject', reason?: string): void {
    const approval = this.approvals().find((a) => a.id === approvalId);
    if (!approval) return;
    try {
      const updated = transitionApprovalItem({
        approval,
        actor: this.currentUser(),
        decision,
        expectedVersion: approval.version,
        reason,
        delegations: this.delegations(),
        nowIso: new Date().toISOString(),
      });
      this.approvals.update((list) => list.map((a) => (a.id === approvalId ? updated : a)));
      this.recordAudit(`APPROVAL_${decision.toUpperCase()}`, 'WorkflowApproval', approvalId, 'Success', `Outcome: ${updated.overallStatus}`);
      this.notify('success', `Approval ${approvalId} recorded (${updated.overallStatus}).`);
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Approval action failed.';
      this.recordAudit(`APPROVAL_${decision.toUpperCase()}`, 'WorkflowApproval', approvalId, 'Denied', msg);
      this.notify('error', msg);
    }
  }

  registerDelegation(toUserId: string, scope: DelegationGrant['scope'], reason: string, days = 7): void {
    const toUser = this.employees().find((e) => e.id === toUserId);
    if (!toUser) return;
    try {
      const grant = createDelegationGrant({
        actor: this.currentUser(),
        fromUserId: this.currentUser().id,
        toUser,
        scope,
        reason,
        startsAt: new Date().toISOString(),
        endsAt: new Date(Date.now() + days * 86400 * 1000).toISOString(),
      });
      this.delegations.update((list) => [grant, ...list]);
      this.recordAudit('REGISTER_DELEGATION', 'DelegationGrant', grant.id, 'Success', `Delegated ${scope.join(', ')} to ${toUser.displayName}`);
      this.notify('success', `Cover delegation granted to ${toUser.displayName} for ${days} days.`);
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Delegation rejected.';
      this.recordAudit('REGISTER_DELEGATION', 'DelegationGrant', this.currentUser().id, 'Denied', msg);
      this.notify('error', msg);
    }
  }

  // ---- Journey 6: Restricted HR Casework ----
  submitRestrictedHrCase(caseType: RestrictedHrCase['caseType'], summary: string, confidentialNotes: string): void {
    const actor = this.currentUser();
    const nowIso = new Date().toISOString();
    const id = `HRC-2026-${String(this.hrCases().length + 20).padStart(3, '0')}`;
    const newCase: RestrictedHrCase = {
      id,
      caseNumber: `ER-2026-${String(this.hrCases().length + 20).padStart(3, '0')}`,
      caseType,
      subjectEmployeeId: actor.id,
      assignedAdviserId: 'emp-hr',
      allowedViewerIds: [actor.id, 'emp-hr'], // Never auto-adds actor's Line Manager!
      handling: 'RESTRICTED-HR',
      summary: summary.trim(),
      confidentialNotes: confidentialNotes.trim(),
      status: 'Open',
      slaDueDate: new Date(Date.now() + 10 * 86400 * 1000).toISOString().slice(0, 10),
      createdAt: nowIso,
      updatedAt: nowIso,
    };
    this.hrCases.update((list) => [newCase, ...list]);
    this.recordAudit('OPEN_RESTRICTED_HR_CASE', 'RestrictedHrCase', id, 'Success', `${caseType} opened with line-manager isolation`);
    this.notify('success', `Restricted case ${newCase.caseNumber} logged. Line managers cannot view this record.`);
  }

  // ---- Journey 7: Personal Detail Change Request (Bank Account Verification) ----
  submitPersonalDetailChange(changeType: PersonalDetailChangeRequest['changeType'], proposedValue: string): void {
    const actor = this.currentUser();
    const nowIso = new Date().toISOString();
    const id = `PDC-2026-${String(this.personalChanges().length + 22).padStart(3, '0')}`;
    const req: PersonalDetailChangeRequest = {
      id,
      employeeId: actor.id,
      changeType,
      proposedMaskedValue: proposedValue.trim(),
      verificationMethod:
        changeType === 'Bank Account Details'
          ? 'HR Two-Stage + Payroll Micro-Check'
          : 'Identity Provider Verification',
      approverId: 'emp-hr',
      status: 'Manager review',
      version: 1,
      idempotencyKey: `idem-${id.toLowerCase()}`,
      submittedAt: nowIso,
      updatedAt: nowIso,
    };
    this.personalChanges.update((list) => [req, ...list]);
    this.recordAudit('SUBMIT_PERSONAL_DETAIL_CHANGE', 'PersonalDetailChange', id, 'Success', `Requested verification for ${changeType}`);
    this.notify('success', `Change request ${id} submitted for HR verification before writing to Core People HRIS.`);
  }

  verifyPersonalDetailChange(requestId: string, approve: boolean): void {
    const actor = this.currentUser();
    if (actor.demoRole !== 'hr_adviser') {
      this.recordAudit('VERIFY_PERSONAL_DETAIL_CHANGE', 'PersonalDetailChange', requestId, 'Denied', 'HR Adviser verification required');
      this.notify('error', 'Only an authorised HR Adviser can verify sensitive personal detail changes.');
      return;
    }
    const req = this.personalChanges().find((p) => p.id === requestId);
    if (!req) return;
    if (actor.id === req.employeeId) {
      this.notify('error', 'Separation of duties: you cannot verify your own personal detail change.');
      return;
    }

    const nowIso = new Date().toISOString();
    this.personalChanges.update((list) =>
      list.map((p) =>
        p.id === requestId
          ? { ...p, status: approve ? 'Completed' : 'Rejected', version: p.version + 1, updatedAt: nowIso }
          : p,
      ),
    );
    if (approve) {
      this.employees.update((emps) =>
        emps.map((e) => {
          if (e.id !== req.employeeId) return e;
          if (req.changeType === 'Bank Account Details') {
            return { ...e, bankAccountMasked: req.proposedMaskedValue, lastSyncedAt: nowIso };
          }
          if (req.changeType === 'Home Address') {
            return { ...e, homeAddress: req.proposedMaskedValue, lastSyncedAt: nowIso };
          }
          if (req.changeType === 'Phone Number') {
            return { ...e, personalPhone: req.proposedMaskedValue, lastSyncedAt: nowIso };
          }
          return { ...e, emergencyContactPhone: req.proposedMaskedValue, lastSyncedAt: nowIso };
        }),
      );
    }
    this.recordAudit('VERIFY_PERSONAL_DETAIL_CHANGE', 'PersonalDetailChange', requestId, 'Success', approve ? 'Verified and synced to HRIS' : 'Rejected');
    this.notify('success', `Personal detail change ${requestId} ${approve ? 'verified and synchronised with HRIS' : 'rejected'}.`);
  }

  // ---- Policy Acknowledgement ----
  acknowledgePolicy(policyId: string): void {
    const uid = this.currentUser().id;
    this.policies.update((list) =>
      list.map((p) =>
        p.id === policyId && !p.acknowledgedByIds.includes(uid)
          ? { ...p, acknowledgedByIds: [...p.acknowledgedByIds, uid] }
          : p,
      ),
    );
    this.recordAudit('ACKNOWLEDGE_POLICY', 'PolicyDocument', policyId, 'Success', 'Recorded formal policy acknowledgement');
    this.notify('success', `Policy ${policyId} acknowledged.`);
  }

  // ---- Controlled Emergency Break-Glass Access ----
  grantEmergencyAccess(targetRecordId: string, scope: EmergencyAccessGrant['scope'], reason: string): void {
    const actor = this.currentUser();
    if (!['dept_admin', 'hr_adviser'].includes(actor.demoRole)) {
      this.notify('error', 'Emergency break-glass requests are restricted to Department Administrators and HR Advisers.');
      return;
    }
    if (reason.trim().length < 10) {
      this.notify('error', 'Provide a detailed justification (minimum 10 characters) for emergency access.');
      return;
    }
    const now = new Date();
    const expires = new Date(now.getTime() + 4 * 3600 * 1000);
    const grant: EmergencyAccessGrant = {
      id: `EMG-${Date.now()}`,
      grantedToUserId: actor.id,
      reason: reason.trim(),
      scope,
      targetRecordId,
      grantedAt: now.toISOString(),
      expiresAt: expires.toISOString(),
      revoked: false,
    };
    this.emergencyGrants.update((list) => [grant, ...list]);
    this.recordAudit(
      'EMERGENCY_BREAK_GLASS_GRANTED',
      scope,
      targetRecordId,
      'Success',
      `4-hour break-glass access granted. Reason: ${reason.trim()}`,
    );
    this.notify('warning', `Controlled emergency access granted until ${expires.toISOString().slice(11, 16)} UTC and logged to audit trail.`);
  }

  notify(tone: NotificationBanner['tone'], message: string): void {
    this.banner.set({ id: String(Date.now()), tone, message });
  }

  clearBanner(): void {
    this.banner.set(null);
  }

  private recordAudit(
    action: string,
    targetType: string,
    targetId: string,
    outcome: AuditLogEntry['outcome'],
    detail: string,
  ): void {
    const actor = this.currentUser();
    const currentLogs = this.auditLog();
    const prevHash = currentLogs[0]?.hash ?? '0000000000000000';
    const payload = `${actor.id}|${action}|${targetId}|${outcome}`;
    const hash = computeAuditHash(prevHash, payload);
    const entry: AuditLogEntry = {
      id: `AUD-${1000 + currentLogs.length + 1}`,
      timestamp: new Date().toISOString(),
      actorId: actor.id,
      actorName: actor.displayName,
      actorRole: actor.demoRole,
      action,
      targetType,
      targetId,
      outcome,
      detail,
      prevHash,
      hash,
    };
    this.auditLog.update((logs) => [entry, ...logs]);
  }

  private async persistRequestToFirestoreIfSignedIn(
    id: string,
    category: string,
    title: string,
    approverUid: string,
    status: string,
    ruleVersion: string,
    idempotencyKey: string,
  ): Promise<void> {
    const { auth, db } = await getFirebaseClient(this.platformId);
    const user = auth?.currentUser;
    if (!db || !user || !user.emailVerified) return;
    if (user.uid === approverUid) return; // Matches Firestore self-approval rule

    const path = `requests/${id}`;
    try {
      const { doc, serverTimestamp, setDoc } = await import('firebase/firestore');
      await setDoc(doc(db, 'requests', id), {
        id,
        category,
        title: title.slice(0, 200),
        requesterUid: user.uid,
        approverUid,
        status,
        ruleVersion,
        version: 1,
        idempotencyKey,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path, auth);
    }
  }
}
