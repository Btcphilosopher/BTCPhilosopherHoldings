import { isPlatformBrowser } from '@angular/common';
import type { FirebaseApp } from 'firebase/app';
import type { Auth, User } from 'firebase/auth';
import type { Firestore } from 'firebase/firestore';
import firebaseConfig from '../../../firebase-applet-config.json';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

let appInstance: FirebaseApp | null = null;
let authInstance: Auth | null = null;
let dbInstance: Firestore | null = null;

export async function getFirebaseClient(platformId: object): Promise<{
  app: FirebaseApp | null;
  auth: Auth | null;
  db: Firestore | null;
}> {
  if (!isPlatformBrowser(platformId)) {
    return { app: null, auth: null, db: null };
  }
  if (!appInstance) {
    const [{ initializeApp, getApps }, { getAuth }, { getFirestore }] = await Promise.all([
      import('firebase/app'),
      import('firebase/auth'),
      import('firebase/firestore'),
    ]);
    appInstance = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
    authInstance = getAuth(appInstance);
    dbInstance = getFirestore(appInstance, firebaseConfig.firestoreDatabaseId);
  }
  return { app: appInstance, auth: authInstance, db: dbInstance };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null,
  auth: Auth | null,
): never {
  const user = auth?.currentUser;
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: user?.uid ?? null,
      email: user?.email ?? null,
      emailVerified: user?.emailVerified ?? null,
      isAnonymous: user?.isAnonymous ?? null,
      tenantId: user?.tenantId ?? null,
      providerInfo:
        user?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) ?? [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testFirestoreConnection(platformId: object): Promise<boolean> {
  const { db } = await getFirebaseClient(platformId);
  if (!db) return false;
  try {
    const { doc, getDocFromServer } = await import('firebase/firestore');
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
    return false;
  }
}

export async function signInWithGoogleWorkspace(platformId: object): Promise<User | null> {
  const { auth, db } = await getFirebaseClient(platformId);
  if (!auth || !db) return null;
  const { GoogleAuthProvider, signInWithPopup } = await import('firebase/auth');
  const { doc, serverTimestamp, setDoc } = await import('firebase/firestore');
  const provider = new GoogleAuthProvider();
  const credential = await signInWithPopup(auth, provider);
  const user = credential.user;
  const profilePath = `users/${user.uid}`;
  try {
    await setDoc(
      doc(db, 'users', user.uid),
      {
        uid: user.uid,
        displayName: user.displayName || 'Workspace User',
        roleTitle: 'Authenticated Staff Member',
        grade: 'SEO',
        directorate: 'Citizen Services & Platforms',
        region: 'england-wales',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      },
      { merge: true },
    );
  } catch (error) {
    console.warn('Profile sync note:', error instanceof Error ? error.message : error, profilePath);
  }
  return user;
}

export async function signOutFirebase(platformId: object): Promise<void> {
  const { auth } = await getFirebaseClient(platformId);
  if (auth) {
    const { signOut } = await import('firebase/auth');
    await signOut(auth);
  }
}
