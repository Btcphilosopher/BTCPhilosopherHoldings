import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WorkspaceStore } from '../core/workspace.store';

@Component({
  selector: 'app-hr-casework',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-8">
      <div class="border-b border-slate-200 pb-5 dark:border-slate-800">
        <h1 class="text-2xl font-semibold text-slate-900 dark:text-slate-100">HR & employee-relations casework</h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">
          Case-specific access control enforced. Line managers and technical administrators cannot view restricted records unless explicitly assigned or holding an audited break-glass grant.
        </p>
      </div>

      <section class="space-y-4">
        @for (c of store.visibleHrCases(); track c.id) {
          <article class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <p class="font-mono text-xs text-slate-500 dark:text-slate-400">
                  {{ c.caseNumber }} · {{ c.caseType }} · {{ c.handling }} · SLA {{ c.slaDueDate }}
                </p>
                <h2 class="mt-1 text-base font-semibold text-slate-900 dark:text-slate-100">{{ c.summary }}</h2>
                <p class="mt-1 text-xs text-slate-600 dark:text-slate-300">
                  Subject: <strong>{{ employeeName(c.subjectEmployeeId) }}</strong> · Assigned Adviser: {{ employeeName(c.assignedAdviserId) }}
                </p>
              </div>
              <span class="font-mono text-xs font-semibold text-slate-800 dark:text-slate-200">{{ c.status }}</span>
            </div>

            <div class="mt-3 rounded border border-slate-200 bg-slate-50 p-3 text-xs text-slate-700 dark:border-slate-800 dark:bg-slate-800/40 dark:text-slate-300">
              {{ c.confidentialNotes }}
            </div>
          </article>
        } @empty {
          <p class="rounded border border-slate-200 bg-white p-6 text-sm text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400">
            No HR cases are visible to your current role and case-level access permissions.
          </p>
        }
      </section>
    </div>
  `,
})
export class HrCaseworkComponent {
  readonly store = inject(WorkspaceStore);
  readonly noteDraft = signal('');

  employeeName(id: string): string {
    return this.store.employees().find((e) => e.id === id)?.displayName ?? id;
  }
}
