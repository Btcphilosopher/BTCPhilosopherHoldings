import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PersonalDetailChangeRequest } from '../../domain/models';
import { WorkspaceStore } from '../core/workspace.store';

@Component({
  selector: 'app-employment',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-8">
      <div class="border-b border-slate-200 pb-5 dark:border-slate-800">
        <h1 class="text-2xl font-semibold text-slate-900 dark:text-slate-100">My employment</h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">
          Authoritative source: <span class="font-medium">{{ store.currentUser().authoritativeSource }}</span>
          <span aria-hidden="true"> · </span>
          <span>Last synchronised <span class="font-mono tabular-nums">{{ store.currentUser().lastSyncedAt.slice(0, 16).replace('T', ' ') }} UTC</span></span>
        </p>
      </div>

      <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <!-- Core Employment Summary -->
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 lg:col-span-2">
          <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
            Role, grade & contractual details
          </h2>
          <dl class="mt-4 grid grid-cols-1 gap-x-6 gap-y-4 text-sm sm:grid-cols-2">
            <div>
              <dt class="text-xs font-medium text-slate-500 dark:text-slate-400">Staff number</dt>
              <dd class="mt-1 font-mono tabular-nums text-slate-900 dark:text-slate-100">{{ store.currentUser().staffNumber }}</dd>
            </div>
            <div>
              <dt class="text-xs font-medium text-slate-500 dark:text-slate-400">Substantive role</dt>
              <dd class="mt-1 text-slate-900 dark:text-slate-100">{{ store.currentUser().roleTitle }}</dd>
            </div>
            <div>
              <dt class="text-xs font-medium text-slate-500 dark:text-slate-400">Department & grade</dt>
              <dd class="mt-1 text-slate-900 dark:text-slate-100">
                {{ store.currentDepartment().code }} · Grade {{ store.currentUser().grade }}
              </dd>
            </div>
            <div>
              <dt class="text-xs font-medium text-slate-500 dark:text-slate-400">Organisational unit</dt>
              <dd class="mt-1 text-slate-900 dark:text-slate-100">
                {{ store.currentUser().directorate }} / {{ store.currentUser().team }}
              </dd>
            </div>
            <div>
              <dt class="text-xs font-medium text-slate-500 dark:text-slate-400">Working pattern & FTE</dt>
              <dd class="mt-1 text-slate-900 dark:text-slate-100">
                {{ store.currentUser().workingPattern }} ({{ store.currentUser().fte }} FTE)
              </dd>
            </div>
            <div>
              <dt class="text-xs font-medium text-slate-500 dark:text-slate-400">Primary base & region</dt>
              <dd class="mt-1 text-slate-900 dark:text-slate-100">
                {{ store.currentUser().workLocation }} · {{ store.currentUser().region }}
              </dd>
            </div>
            <div>
              <dt class="text-xs font-medium text-slate-500 dark:text-slate-400">Line manager</dt>
              <dd class="mt-1 text-slate-900 dark:text-slate-100">{{ managerName() }}</dd>
            </div>
            <div>
              <dt class="text-xs font-medium text-slate-500 dark:text-slate-400">Continuous service start date</dt>
              <dd class="mt-1 font-mono tabular-nums text-slate-900 dark:text-slate-100">{{ store.currentUser().startDate }}</dd>
            </div>
          </dl>

          <!-- Private PII Block (Self or HR / Verified Emergency Break-Glass only) -->
          <div class="mt-6 border-t border-slate-200 pt-5 dark:border-slate-800">
            <h3 class="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Restricted personal & payroll contact details
            </h3>
            @if (store.canInspectPrivatePii(store.currentUser().id)) {
              <dl class="mt-3 grid grid-cols-1 gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
                <div>
                  <dt class="text-xs text-slate-500 dark:text-slate-400">Home address</dt>
                  <dd class="mt-0.5 text-slate-900 dark:text-slate-100">{{ store.currentUser().homeAddress }}</dd>
                </div>
                <div>
                  <dt class="text-xs text-slate-500 dark:text-slate-400">Personal mobile</dt>
                  <dd class="mt-0.5 font-mono tabular-nums text-slate-900 dark:text-slate-100">{{ store.currentUser().personalPhone }}</dd>
                </div>
                <div>
                  <dt class="text-xs text-slate-500 dark:text-slate-400">Emergency contact</dt>
                  <dd class="mt-0.5 text-slate-900 dark:text-slate-100">
                    {{ store.currentUser().emergencyContactName }} ({{ store.currentUser().emergencyContactRelation }}) · {{ store.currentUser().emergencyContactPhone }}
                  </dd>
                </div>
                <div>
                  <dt class="text-xs text-slate-500 dark:text-slate-400">Verified bank account (Payroll)</dt>
                  <dd class="mt-0.5 font-mono tabular-nums text-slate-900 dark:text-slate-100">
                    Sort {{ store.currentUser().bankSortCodeMasked }} · Acc {{ store.currentUser().bankAccountMasked }}
                  </dd>
                </div>
              </dl>
            } @else {
              <p class="mt-2 text-xs text-slate-500 dark:text-slate-400">
                Restricted PII details are masked for non-owners.
              </p>
            }
          </div>
        </section>

        <!-- Employment Documents & Secondments -->
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
            Documents & contractual history
          </h2>
          <ul class="mt-4 space-y-3 text-sm">
            <li class="flex items-start justify-between gap-3 border-b border-slate-100 pb-3 dark:border-slate-800">
              <div>
                <p class="font-medium text-slate-900 dark:text-slate-100">Statement of Particulars</p>
                <p class="text-xs text-slate-500 dark:text-slate-400">Core People HRIS · Signed {{ store.currentUser().startDate }}</p>
              </div>
              <span class="font-mono text-xs text-slate-500">PDF</span>
            </li>
            <li class="flex items-start justify-between gap-3 border-b border-slate-100 pb-3 dark:border-slate-800">
              <div>
                <p class="font-medium text-slate-900 dark:text-slate-100">Hybrid Working Agreement</p>
                <p class="text-xs text-slate-500 dark:text-slate-400">{{ store.currentUser().hybridArrangement }}</p>
              </div>
              <span class="font-mono text-xs text-slate-500">Active</span>
            </li>
            <li>
              <p class="font-medium text-slate-900 dark:text-slate-100">Secondments & loans</p>
              <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">
                No active outward secondment. Browse internal secondments in Learning & development.
              </p>
            </li>
          </ul>
        </section>
      </div>

      <!-- Journey 7: Personal-Information & Bank-Account Change Verification Workflow -->
      <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <div class="border-b border-slate-200 pb-3 dark:border-slate-800">
          <h2 class="text-base font-semibold text-slate-900 dark:text-slate-100">
            Personal-information & bank-account change requests
          </h2>
          <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">
            Sensitive updates—especially bank-account changes—require HR two-stage verification before synchronising back to Core People HRIS and Payroll.
          </p>
        </div>

        <div class="mt-5 grid grid-cols-1 gap-6 lg:grid-cols-2">
          <form (ngSubmit)="submitChange()" class="space-y-4">
            <div>
              <label for="pdc-type" class="block text-xs font-medium text-slate-700 dark:text-slate-300">
                Information category
              </label>
              <select
                id="pdc-type"
                name="changeType"
                [(ngModel)]="changeType"
                class="mt-1 w-full rounded border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                <option value="Bank Account Details">Bank Account Details (High Assurance)</option>
                <option value="Home Address">Home Address</option>
                <option value="Emergency Contact">Emergency Contact</option>
                <option value="Phone Number">Phone Number</option>
              </select>
            </div>
            <div>
              <label for="pdc-val" class="block text-xs font-medium text-slate-700 dark:text-slate-300">
                New masked / proposed value
              </label>
              <input
                id="pdc-val"
                name="proposedValue"
                type="text"
                [(ngModel)]="proposedValue"
                placeholder="e.g. Sort 20-••-91 · Account •••• 8840"
                class="mt-1 w-full rounded border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>
            <button
              type="submit"
              class="rounded bg-[#1d70b8] px-4 py-2 text-sm font-medium text-white hover:bg-[#003078]"
            >
              Submit verified change request
            </button>
          </form>

          <div>
            <h3 class="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Active & historical verification queue
            </h3>
            <div class="mt-3 divide-y divide-slate-200 border border-slate-200 rounded dark:divide-slate-800 dark:border-slate-800">
              @for (req of visibleChangeRequests(); track req.id) {
                <div class="p-3.5 text-sm">
                  <div class="flex items-start justify-between gap-2">
                    <div>
                      <p class="font-medium text-slate-900 dark:text-slate-100">
                        {{ req.changeType }} · <span class="font-mono text-xs">{{ req.id }}</span>
                      </p>
                      <p class="mt-0.5 font-mono text-xs text-slate-600 dark:text-slate-300">
                        {{ req.proposedMaskedValue }}
                      </p>
                      <p class="mt-1 text-xs text-slate-500 dark:text-slate-400">
                        {{ req.verificationMethod }} · Status: <strong class="text-slate-800 dark:text-slate-200">{{ req.status }}</strong>
                      </p>
                    </div>
                    @if (store.currentUser().demoRole === 'hr_adviser' && req.status === 'Manager review') {
                      <div class="flex gap-2 shrink-0">
                        <button
                          type="button"
                          (click)="store.verifyPersonalDetailChange(req.id, true)"
                          class="rounded bg-[#00703c] px-2.5 py-1 text-xs font-medium text-white hover:bg-[#005a30]"
                        >
                          Verify & Sync
                        </button>
                        <button
                          type="button"
                          (click)="store.verifyPersonalDetailChange(req.id, false)"
                          class="rounded border border-red-300 px-2.5 py-1 text-xs font-medium text-red-700 hover:bg-red-50 dark:border-red-800 dark:text-red-400"
                        >
                          Reject
                        </button>
                      </div>
                    }
                  </div>
                </div>
              }
            </div>
          </div>
        </div>
      </section>
    </div>
  `,
})
export class EmploymentComponent {
  readonly store = inject(WorkspaceStore);

  changeType: PersonalDetailChangeRequest['changeType'] = 'Bank Account Details';
  proposedValue = signal('');

  readonly managerName = computed(() => {
    const mid = this.store.currentUser().managerId;
    if (!mid) return 'Directorate Head (Direct Reporting)';
    return this.store.employees().find((e) => e.id === mid)?.displayName ?? mid;
  });

  readonly visibleChangeRequests = computed(() => {
    const actor = this.store.currentUser();
    return this.store
      .personalChanges()
      .filter((r) => r.employeeId === actor.id || actor.demoRole === 'hr_adviser' || actor.demoRole === 'auditor');
  });

  submitChange(): void {
    const val = this.proposedValue().trim();
    if (!val) {
      this.store.notify('error', 'Enter the proposed value for verification.');
      return;
    }
    this.store.submitPersonalDetailChange(this.changeType, val);
    this.proposedValue.set('');
  }
}
