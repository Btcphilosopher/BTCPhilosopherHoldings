import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WorkspaceStore } from '../core/workspace.store';

@Component({
  selector: 'app-learning',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-8">
      <div class="border-b border-slate-200 pb-5 dark:border-slate-800">
        <h1 class="text-2xl font-semibold text-slate-900 dark:text-slate-100">Learning & development</h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">
          Review model ({{ store.currentDepartment().code }}): {{ store.currentDepartment().reviewRatingModel }}.
          No automated employee rankings or activity-derived performance scores are used.
        </p>
      </div>

      <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <!-- Objectives & Check-Ins -->
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
            Objectives, check-ins & probation milestones
          </h2>
          <ul class="mt-4 space-y-4 text-sm">
            @for (obj of objectives(); track obj.id) {
              <li class="rounded border border-slate-200 p-4 dark:border-slate-800">
                <div class="flex items-center justify-between">
                  <p class="font-medium text-slate-900 dark:text-slate-100">{{ obj.title }}</p>
                  <span class="font-mono text-xs text-slate-500">{{ obj.status }}</span>
                </div>
                <p class="mt-1 text-xs text-slate-600 dark:text-slate-300">{{ obj.detail }}</p>
              </li>
            }
          </ul>

          <form (ngSubmit)="addCheckIn()" class="mt-5 flex gap-2 border-t border-slate-200 pt-4 dark:border-slate-800">
            <input
              type="text"
              [(ngModel)]="newObjective"
              name="newObjective"
              aria-label="Add development objective or check-in note"
              placeholder="Add objective or check-in reflection..."
              class="flex-1 rounded border border-slate-300 bg-white px-3 py-1.5 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
            <button
              type="submit"
              class="whitespace-nowrap rounded bg-[#1d70b8] px-4 py-1.5 text-sm font-medium text-white hover:bg-[#003078]"
            >
              Save note
            </button>
          </form>
        </section>

        <!-- Mandatory Training & Catalogue -->
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
            Mandatory training & learning catalogue
          </h2>
          <div class="mt-4 divide-y divide-slate-200 text-sm dark:divide-slate-800">
            @for (course of courses(); track course.id) {
              <div class="flex items-center justify-between gap-4 py-3">
                <div>
                  <p class="font-medium text-slate-900 dark:text-slate-100">{{ course.title }}</p>
                  <p class="text-xs text-slate-500 dark:text-slate-400">
                    {{ course.provider }} · {{ course.mandatory ? 'Mandatory annual' : 'Optional catalogue' }} · Due {{ course.dueDate }}
                  </p>
                </div>
                @if (course.completed) {
                  <span class="font-mono text-xs font-medium text-[#00703c] dark:text-emerald-400">Completed</span>
                } @else {
                  <button
                    type="button"
                    (click)="markComplete(course.id)"
                    class="whitespace-nowrap rounded border border-[#1d70b8] px-3 py-1 text-xs font-medium text-[#1d70b8] hover:bg-[#1d70b8]/10 dark:text-sky-400"
                  >
                    Mark complete
                  </button>
                }
              </div>
            }
          </div>
        </section>

        <!-- Internal Opportunities & Secondments -->
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
            Internal opportunities, mentoring & secondments
          </h2>
          <ul class="mt-4 space-y-3 text-sm">
            <li class="border-b border-slate-100 pb-3 dark:border-slate-800">
              <p class="font-medium text-slate-900 dark:text-slate-100">12-Month Loan · Digital Service Standards Lead (Grade 7 EOI)</p>
              <p class="mt-0.5 text-xs text-slate-500 dark:text-slate-400">Cabinet Delivery Group (Sample) · Closes 12 Dec 2026 · Hybrid UK</p>
            </li>
            <li class="border-b border-slate-100 pb-3 dark:border-slate-800">
              <p class="font-medium text-slate-900 dark:text-slate-100">Cross-Departmental Mentoring Circle</p>
              <p class="mt-0.5 text-xs text-slate-500 dark:text-slate-400">Matched career conversations · Spring 2027 cohort open</p>
            </li>
            <li>
              <p class="font-medium text-slate-900 dark:text-slate-100">Professional Qualifications Support</p>
              <p class="mt-0.5 text-xs text-slate-500 dark:text-slate-400">CIPD / CIMA / GDS Digital Academy funded study pathways</p>
            </li>
          </ul>
        </section>

        <!-- Recognition & Feedback -->
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
            Peer recognition & feedback
          </h2>
          <ul class="mt-4 space-y-3 text-sm">
            <li class="rounded border border-slate-200 bg-slate-50 p-3.5 dark:border-slate-800 dark:bg-slate-800/40">
              <p class="text-xs text-slate-500 dark:text-slate-400">From David Thornton · 14 Nov 2026</p>
              <p class="mt-1 text-slate-800 dark:text-slate-200">
                Thank you for leading the plain-English redesign of the regional leave calculator and user-testing forms with screen-reader users.
              </p>
            </li>
          </ul>
        </section>
      </div>
    </div>
  `,
})
export class LearningComponent {
  readonly store = inject(WorkspaceStore);

  newObjective = '';

  readonly objectives = signal([
    {
      id: 'obj-1',
      title: 'Deliver WCAG 2.2 AA validation across departmental self-service journeys',
      status: 'On track',
      detail: 'Mid-year check-in completed 14 Oct 2026. Next narrative check-in 26 Nov.',
    },
    {
      id: 'obj-2',
      title: 'Complete Chartered Institute Accessibility Practitioner accreditation',
      status: 'In progress',
      detail: 'Study leave allocation agreed under departmental development plan.',
    },
  ]);

  readonly courses = signal([
    {
      id: 'crs-1',
      title: 'Information Handling & Data Protection 2026',
      provider: 'Civil Service Learning Hub',
      mandatory: true,
      dueDate: '2026-11-24',
      completed: false,
    },
    {
      id: 'crs-2',
      title: 'Counter-Fraud, Bribery & Procurement Ethics',
      provider: 'Civil Service Learning Hub',
      mandatory: true,
      dueDate: '2026-10-31',
      completed: true,
    },
    {
      id: 'crs-3',
      title: 'Managing Hybrid & Compressed Working Teams',
      provider: 'Departmental Academy',
      mandatory: false,
      dueDate: 'Optional',
      completed: false,
    },
  ]);

  addCheckIn(): void {
    if (!this.newObjective.trim()) return;
    this.objectives.update((list) => [
      {
        id: `obj-${Date.now()}`,
        title: this.newObjective.trim(),
        status: 'Logged',
        detail: `Recorded ${new Date().toISOString().slice(0, 10)} by ${this.store.currentUser().displayName}`,
      },
      ...list,
    ]);
    this.newObjective = '';
    this.store.notify('success', 'Development note saved to your performance plan.');
  }

  markComplete(courseId: string): void {
    this.courses.update((list) =>
      list.map((c) => (c.id === courseId ? { ...c, completed: true } : c)),
    );
    this.store.notify('success', 'Training completion synced with Learning Platform adapter.');
  }
}
