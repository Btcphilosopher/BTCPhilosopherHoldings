import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DelegationGrant } from '../../domain/models';
import { WorkspaceStore } from '../core/workspace.store';

@Component({
  selector: 'app-approvals',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-8">
      <div class="border-b border-slate-200 pb-5 dark:border-slate-800">
        <h1 class="text-2xl font-semibold text-slate-900 dark:text-slate-100">Approval engine</h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">
          Versioned sequential and parallel workflows. In-flight approvals keep their submission rule version, enforce separation of requester and approver, and block unauthorised delegation.
        </p>
      </div>

      <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <!-- Active Approval Chains -->
        <div class="space-y-4 lg:col-span-2">
          @for (item of store.approvals(); track item.id) {
            <article class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <p class="text-xs text-slate-500 dark:text-slate-400">
                    <span class="font-mono font-semibold text-slate-800 dark:text-slate-200">{{ item.id }}</span>
                    <span aria-hidden="true"> · </span>
                    <span>Ref <span class="font-mono">{{ item.referenceId }}</span></span>
                    <span aria-hidden="true"> · </span>
                    <span>{{ item.mode }} mode</span>
                    <span aria-hidden="true"> · </span>
                    <span class="font-mono">{{ item.ruleVersion }} (pinned)</span>
                  </p>
                  <h2 class="mt-1 text-base font-semibold text-slate-900 dark:text-slate-100">{{ item.title }}</h2>
                  <p class="mt-1 text-xs text-slate-600 dark:text-slate-300">{{ item.ruleSummary }}</p>
                </div>

                <div class="text-left sm:text-right shrink-0">
                  <p class="text-xs font-semibold text-slate-900 dark:text-slate-100">{{ item.overallStatus }}</p>
                  <p class="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                    @if (item.nextActionUserId) {
                      Next action: <strong>{{ employeeName(item.nextActionUserId) }}</strong>
                    } @else {
                      Chain complete
                    }
                  </p>
                </div>
              </div>

              <!-- Stage Timeline -->
              <div class="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2">
                @for (stage of item.stages; track stage.stageName) {
                  <div class="rounded border border-slate-200 bg-slate-50 p-3 text-xs dark:border-slate-800 dark:bg-slate-800/40">
                    <div class="flex items-center justify-between">
                      <span class="font-semibold text-slate-800 dark:text-slate-200">{{ stage.stageName }}</span>
                      <span class="font-mono text-slate-600 dark:text-slate-300">{{ stage.status }}</span>
                    </div>
                    <p class="mt-1 text-slate-600 dark:text-slate-400">
                      Assigned: {{ employeeName(stage.assignedUserId) }} ({{ stage.assignedRole }})
                    </p>
                    @if (stage.reason) {
                      <p class="mt-1 text-slate-500 dark:text-slate-400">Reason: {{ stage.reason }}</p>
                    }
                  </div>
                }
              </div>

              <!-- Decision Controls -->
              @if (!['Approved', 'Rejected', 'Withdrawn', 'Paid', 'Completed'].includes(item.overallStatus)) {
                <div class="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
                  <input
                    type="text"
                    [ngModel]="decisionNote()"
                    (ngModelChange)="decisionNote.set($event)"
                    aria-label="Approval decision reason"
                    placeholder="Recorded decision reason (required for Return / Reject)"
                    class="min-w-[220px] flex-1 rounded border border-slate-300 bg-white px-3 py-1.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                  />
                  <button
                    type="button"
                    (click)="store.actOnApproval(item.id, 'Approve', decisionNote() || 'Approved')"
                    class="whitespace-nowrap rounded bg-[#00703c] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#005a30]"
                  >
                    Approve stage
                  </button>
                  <button
                    type="button"
                    (click)="store.actOnApproval(item.id, 'Return', decisionNote())"
                    class="whitespace-nowrap rounded border border-amber-400 px-3 py-1.5 text-xs font-medium text-amber-800 hover:bg-amber-50 dark:border-amber-700 dark:text-amber-300"
                  >
                    Return
                  </button>
                  <button
                    type="button"
                    (click)="store.actOnApproval(item.id, 'Reject', decisionNote())"
                    class="whitespace-nowrap rounded border border-red-300 px-3 py-1.5 text-xs font-medium text-red-700 hover:bg-red-50 dark:border-red-800 dark:text-red-400"
                  >
                    Reject
                  </button>
                </div>
              }
            </article>
          }
        </div>

        <!-- Right Rail: Delegated Authority & Versioned Rules -->
        <div class="space-y-6">
          <section class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
              Delegated authority & temporary cover
            </h2>
            <form (ngSubmit)="addDelegation()" class="mt-4 space-y-3 text-sm">
              <div>
                <label for="del-to" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Delegate cover to</label>
                <select
                  id="del-to"
                  name="delegateTo"
                  [(ngModel)]="delegateToUserId"
                  class="mt-1 w-full rounded border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                >
                  @for (emp of store.employees(); track emp.id) {
                    <option [value]="emp.id">{{ emp.displayName }} ({{ emp.demoRole }})</option>
                  }
                </select>
              </div>
              <div>
                <label for="del-reason" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Recorded reason</label>
                <input
                  id="del-reason"
                  name="delegateReason"
                  type="text"
                  [(ngModel)]="delegateReason"
                  placeholder="e.g. Annual leave cover 1–8 Dec"
                  class="mt-1 w-full rounded border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>
              <button
                type="submit"
                class="w-full rounded bg-[#1d70b8] px-3 py-2 text-xs font-medium text-white hover:bg-[#003078]"
              >
                Grant temporary cover
              </button>
            </form>

            <ul class="mt-4 divide-y divide-slate-100 text-xs dark:divide-slate-800">
              @for (d of store.delegations(); track d.id) {
                <li class="py-2.5">
                  <p class="font-medium text-slate-800 dark:text-slate-200">
                    {{ employeeName(d.fromUserId) }} → {{ employeeName(d.toUserId) }}
                  </p>
                  <p class="text-slate-500 dark:text-slate-400">Scope: {{ d.scope.join(', ') }} · {{ d.reason }}</p>
                </li>
              }
            </ul>
          </section>

          <section class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
              Versioned approval rules
            </h2>
            <ul class="mt-3 space-y-3 text-xs">
              @for (rule of store.workflowRules(); track rule.versionId) {
                <li class="border-b border-slate-100 pb-2.5 last:border-b-0 dark:border-slate-800">
                  <div class="flex items-center justify-between font-mono">
                    <strong class="text-slate-900 dark:text-slate-100">{{ rule.versionId }}</strong>
                    <span [class.text-amber-700]="rule.status === 'Superseded'">{{ rule.status }}</span>
                  </div>
                  <p class="mt-1 text-slate-600 dark:text-slate-300">{{ rule.summary }}</p>
                  <p class="mt-0.5 text-slate-500">Effective {{ rule.effectiveFrom }} · Escalation {{ rule.escalationHours }}h</p>
                </li>
              }
            </ul>
          </section>
        </div>
      </div>
    </div>
  `,
})
export class ApprovalsComponent {
  readonly store = inject(WorkspaceStore);

  readonly decisionNote = signal('');
  delegateToUserId = 'emp-admin';
  delegateReason = '';

  addDelegation(): void {
    const scope: DelegationGrant['scope'] = ['leave', 'expense', 'tasks'];
    this.store.registerDelegation(this.delegateToUserId, scope, this.delegateReason, 7);
    this.delegateReason = '';
  }

  employeeName(id: string): string {
    return this.store.employees().find((e) => e.id === id)?.displayName ?? id;
  }
}
