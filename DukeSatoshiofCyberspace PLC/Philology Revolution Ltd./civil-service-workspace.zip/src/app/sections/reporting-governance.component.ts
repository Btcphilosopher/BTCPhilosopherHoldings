import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { suppressSmallGroups, ROLE_MATRIX } from '../../domain/permissions';
import { DemoRoleId } from '../../domain/models';
import { WorkspaceStore } from '../core/workspace.store';

@Component({
  selector: 'app-reporting-governance',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-8">
      <div class="border-b border-slate-200 pb-5 dark:border-slate-800">
        <h1 class="text-2xl font-semibold text-slate-900 dark:text-slate-100">
          {{ store.activeSection() === 'reporting' ? 'Management reporting & assurance' : 'System governance, permissions & integrations' }}
        </h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">
          Aggregated operational metrics with small-group privacy suppression (groups &lt; 5 suppressed). Zero covert monitoring, keystroke logging, or presence-based productivity scoring.
        </p>
      </div>

      <!-- Aggregated Operational Metrics + Small-Group Suppression -->
      <section class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p class="text-xs font-medium text-slate-500 dark:text-slate-400">Active leave & expense volume</p>
          <p class="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-900 dark:text-slate-100">
            {{ store.leaveRequests().length + store.expenseClaims().length }}
          </p>
          <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">Median turnaround 1.4 working days</p>
        </div>

        <div class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p class="text-xs font-medium text-slate-500 dark:text-slate-400">Approval bottlenecks</p>
          <p class="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-900 dark:text-slate-100">
            {{ pendingApprovalsCount() }}
          </p>
          <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">In-flight across sequential & parallel rules</p>
        </div>

        <div class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p class="text-xs font-medium text-slate-500 dark:text-slate-400">Mandatory learning completion</p>
          <p class="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-900 dark:text-slate-100">91.4%</p>
          <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">Synced hourly via Learning Hub</p>
        </div>

        <div class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p class="text-xs font-medium text-slate-500 dark:text-slate-400">Onboarding journeys active</p>
          <p class="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-900 dark:text-slate-100">
            {{ store.lifecycleJourneys().length }}
          </p>
          <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">HR · Security · IT · Facilities aligned</p>
        </div>
      </section>

      <!-- Small-Group Suppression Table -->
      <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
          Sensitive absence & HR enquiry aggregation (Small-group suppression threshold: n &lt; 5)
        </h2>
        <div class="mt-4 overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead>
              <tr class="border-b border-slate-200 text-xs text-slate-500 dark:border-slate-800">
                <th class="py-2 pr-4">Directorate / Cohort</th>
                <th class="py-2 px-3 text-right">Published Aggregate Count</th>
                <th class="py-2 pl-3">Privacy Protection Note</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
              @for (row of suppressedAbsenceMetrics(); track row.groupLabel) {
                <tr>
                  <td class="py-2.5 pr-4 font-medium text-slate-900 dark:text-slate-100">{{ row.groupLabel }}</td>
                  <td class="py-2.5 px-3 text-right font-mono tabular-nums">{{ row.displayValue }}</td>
                  <td class="py-2.5 pl-3 text-xs text-slate-500 dark:text-slate-400">
                    {{ row.suppressed ? 'Suppressed to prevent individual identification' : 'Meets k-anonymity reporting threshold' }}
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Controlled Emergency Access (Break-Glass) + Tamper-Evident Audit Log -->
      @if (store.currentRoleCapabilities().canViewAuditLogs) {
        <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
              Controlled emergency access (Break-glass)
            </h2>
            <p class="mt-2 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
              Department Administrators do not automatically receive personnel PII or HR case access. Emergency access requires a recorded reason and expires after 4 hours.
            </p>
            <form (ngSubmit)="requestBreakGlass()" class="mt-4 space-y-3 text-xs">
              <div>
                <label for="bg-target" class="block font-medium text-slate-700 dark:text-slate-300">Target record ID</label>
                <input
                  id="bg-target"
                  name="breakGlassTarget"
                  type="text"
                  [(ngModel)]="breakGlassTarget"
                  class="mt-1 w-full rounded border border-slate-300 bg-white px-2.5 py-1.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>
              <div>
                <label for="bg-reason" class="block font-medium text-slate-700 dark:text-slate-300">Mandatory justification (min 10 chars)</label>
                <textarea
                  id="bg-reason"
                  name="breakGlassReason"
                  rows="2"
                  [(ngModel)]="breakGlassReason"
                  placeholder="e.g. Statutory subject access verification under ICO deadline"
                  class="mt-1 w-full rounded border border-slate-300 bg-white px-2.5 py-1.5 text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                ></textarea>
              </div>
              <button
                type="submit"
                class="w-full rounded bg-[#0e233f] px-3 py-2 font-medium text-white hover:bg-slate-800"
              >
                Grant 4-hour audited access
              </button>
            </form>
          </section>

          <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 lg:col-span-2">
            <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
              Tamper-evident hash-chained audit trail
            </h2>
            <div class="mt-3 max-h-80 overflow-y-auto divide-y divide-slate-200 text-xs dark:divide-slate-800">
              @for (log of store.auditLog(); track log.id) {
                <div class="py-2.5">
                  <div class="flex flex-wrap items-center justify-between gap-2">
                    <span class="font-mono font-semibold text-slate-800 dark:text-slate-200">
                      {{ log.id }} · {{ log.action }} ({{ log.outcome }})
                    </span>
                    <span class="font-mono text-slate-500">{{ log.timestamp.slice(0, 19).replace('T', ' ') }} UTC</span>
                  </div>
                  <p class="mt-0.5 text-slate-600 dark:text-slate-300">
                    Actor: {{ log.actorName }} ({{ log.actorRole }}) → {{ log.targetType }} {{ log.targetId }} · {{ log.detail }}
                  </p>
                  <p class="mt-0.5 font-mono text-[11px] text-slate-400">Hash: {{ log.hash }} (prev {{ log.prevHash.slice(0, 14) }}…)</p>
                </div>
              }
            </div>
          </section>
        </div>
      }

      <!-- Governance Section: Permission Matrix, Integration Adapters & API Docs -->
      @if (store.activeSection() === 'governance') {
        <!-- Permission Matrix -->
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
            Role-based permission matrix
          </h2>
          <div class="mt-4 overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead>
                <tr class="border-b border-slate-200 text-slate-500 dark:border-slate-800">
                  <th class="py-2 pr-3">Role</th>
                  <th class="py-2 px-2">Leave / Exp Mgr</th>
                  <th class="py-2 px-2">Finance Payout</th>
                  <th class="py-2 px-2">HR Cases</th>
                  <th class="py-2 px-2">IT Fulfil</th>
                  <th class="py-2 px-2">Audit Logs</th>
                  <th class="py-2 pl-2">Auto Personnel PII</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
                @for (role of roleRows; track role.roleId) {
                  <tr>
                    <td class="py-2.5 pr-3 font-semibold text-slate-900 dark:text-slate-100">{{ role.label }}</td>
                    <td class="py-2.5 px-2 font-mono">{{ role.canApproveLeave ? 'Yes' : 'No' }}</td>
                    <td class="py-2.5 px-2 font-mono">{{ role.canProcessFinancePayments ? 'Yes' : 'No' }}</td>
                    <td class="py-2.5 px-2 font-mono">{{ role.canManageHrCases ? 'Assigned' : 'Own only' }}</td>
                    <td class="py-2.5 px-2 font-mono">{{ role.canFulfilItTickets ? 'Yes' : 'No' }}</td>
                    <td class="py-2.5 px-2 font-mono">{{ role.canViewAuditLogs ? 'Yes' : 'No' }}</td>
                    <td class="py-2.5 pl-2 font-mono">{{ role.hasAutomaticPersonnelPiiAccess ? 'HR Scope' : 'Blocked' }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </section>

        <!-- Integration Adapters & Source-of-Truth Registry -->
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <div class="flex flex-col gap-3 border-b border-slate-200 pb-3 dark:border-slate-800 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 class="text-base font-semibold text-slate-900 dark:text-slate-100">
                Enterprise integration adapters (Source of truth & idempotency)
              </h2>
              <p class="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                Uses idempotency keys and reconciliation so failed integrations never mark requests complete.
              </p>
            </div>
            <button
              type="button"
              (click)="testServerApiDocs()"
              class="whitespace-nowrap rounded border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200"
            >
              Fetch /api/docs contract
            </button>
          </div>

          <div class="mt-4 overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead>
                <tr class="border-b border-slate-200 text-slate-500 dark:border-slate-800">
                  <th class="py-2 pr-3">Adapter & System</th>
                  <th class="py-2 px-3">Source of Truth For</th>
                  <th class="py-2 px-3">Sync Frequency</th>
                  <th class="py-2 pl-3">Conflict Resolution Rule</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
                @for (ad of store.adapters(); track ad.id) {
                  <tr>
                    <td class="py-2.5 pr-3">
                      <p class="font-semibold text-slate-900 dark:text-slate-100">{{ ad.name }}</p>
                      <p class="text-slate-500">{{ ad.systemName }}</p>
                    </td>
                    <td class="py-2.5 px-3 text-slate-700 dark:text-slate-300">{{ ad.sourceOfTruthFor }}</td>
                    <td class="py-2.5 px-3 font-mono text-slate-600 dark:text-slate-400">{{ ad.syncFrequency }}</td>
                    <td class="py-2.5 pl-3 text-slate-600 dark:text-slate-300">{{ ad.conflictRule }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>

          @if (apiDocsSummary()) {
            <pre class="mt-4 overflow-x-auto rounded border border-slate-200 bg-slate-50 p-3 font-mono text-[11px] text-slate-800 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200">{{ apiDocsSummary() }}</pre>
          }
        </section>
      }
    </div>
  `,
})
export class ReportingGovernanceComponent {
  readonly store = inject(WorkspaceStore);

  breakGlassTarget = 'HRC-2026-019';
  breakGlassReason = '';
  readonly apiDocsSummary = signal<string | null>(null);

  readonly roleRows = (Object.keys(ROLE_MATRIX) as DemoRoleId[]).map((k) => ROLE_MATRIX[k]);

  readonly pendingApprovalsCount = computed(
    () =>
      this.store
        .approvals()
        .filter((a) => !['Approved', 'Rejected', 'Withdrawn', 'Paid', 'Completed'].includes(a.overallStatus))
        .length,
  );

  readonly suppressedAbsenceMetrics = computed(() =>
    suppressSmallGroups([
      { groupLabel: 'Citizen Services & Platforms', count: 12 },
      { groupLabel: 'Corporate Finance & Commercial', count: 6 },
      { groupLabel: 'Technology & Workplace Services', count: 3 }, // Suppressed (< 5)
      { groupLabel: 'Platform Governance', count: 1 }, // Suppressed (< 5)
    ]),
  );

  requestBreakGlass(): void {
    this.store.grantEmergencyAccess(this.breakGlassTarget, 'restricted-hr', this.breakGlassReason);
    this.breakGlassReason = '';
  }

  async testServerApiDocs(): Promise<void> {
    try {
      const resp = await fetch('/api/docs');
      const data = await resp.json();
      this.apiDocsSummary.set(JSON.stringify(data, null, 2));
    } catch {
      this.store.notify('error', 'Could not reach /api/docs endpoint.');
    }
  }
}
