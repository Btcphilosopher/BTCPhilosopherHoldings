import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ExpenseClaim } from '../../domain/models';
import { WorkspaceStore } from '../core/workspace.store';

@Component({
  selector: 'app-pay-expenses',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-8">
      <div class="border-b border-slate-200 pb-5 dark:border-slate-800">
        <h1 class="text-2xl font-semibold text-slate-900 dark:text-slate-100">Pay, pensions & expenses</h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">
          Configured policy rates (Sample · Effective {{ store.currentDepartment().mileageEffectiveDate }}):
          <span class="font-mono tabular-nums">{{ store.currentDepartment().mileageRatePence }}p/mile</span> ·
          Day subsistence cap <span class="font-mono tabular-nums">£{{ store.currentDepartment().subsistenceDayCapGbp }}.00</span>
        </p>
      </div>

      <!-- Payslips, Tax Documents & Authoritative Pension Links -->
      <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
            Payslips & tax documents
          </h2>
          <p class="mt-2 text-xs text-slate-500 dark:text-slate-400">
            Served via Civil Payroll Gateway (Authoritative). Never stores duplicate payroll master records.
          </p>
          <ul class="mt-4 divide-y divide-slate-100 text-sm dark:divide-slate-800">
            <li class="flex items-center justify-between py-2.5">
              <div>
                <p class="font-medium text-slate-900 dark:text-slate-100">November 2026 Payslip (Sample)</p>
                <p class="font-mono text-xs text-slate-500">Pay date 2026-11-27 · Published</p>
              </div>
              <span class="font-mono text-xs text-[#1d70b8] dark:text-sky-400">View PDF</span>
            </li>
            <li class="flex items-center justify-between py-2.5">
              <div>
                <p class="font-medium text-slate-900 dark:text-slate-100">October 2026 Payslip (Sample)</p>
                <p class="font-mono text-xs text-slate-500">Pay date 2026-10-30 · Settled</p>
              </div>
              <span class="font-mono text-xs text-[#1d70b8] dark:text-sky-400">View PDF</span>
            </li>
            <li class="flex items-center justify-between py-2.5">
              <div>
                <p class="font-medium text-slate-900 dark:text-slate-100">2025/26 P60 End of Year Summary</p>
                <p class="font-mono text-xs text-slate-500">Tax code verified via HMRC feed</p>
              </div>
              <span class="font-mono text-xs text-[#1d70b8] dark:text-sky-400">Download</span>
            </li>
          </ul>
        </section>

        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
            Pension & authoritative services
          </h2>
          <p class="mt-3 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
            This workspace links directly to the authoritative Pension Scheme Portal for official projections and benefit statements. Official pension calculations are never approximated locally.
          </p>
          <div class="mt-4 space-y-2 rounded border border-slate-200 bg-slate-50 p-3.5 text-xs dark:border-slate-800 dark:bg-slate-800/40">
            <p class="font-medium text-slate-800 dark:text-slate-200">Payroll query tracking</p>
            <p class="text-slate-600 dark:text-slate-400">No open payroll discrepancy queries for {{ store.currentUser().staffNumber }}.</p>
          </div>
        </section>

        <!-- Submit New Expense Claim -->
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
            Submit expense claim
          </h2>
          <form (ngSubmit)="submitExpense()" class="mt-4 space-y-3 text-sm">
            <div>
              <label for="exp-title" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Claim title</label>
              <input
                id="exp-title"
                name="title"
                type="text"
                [(ngModel)]="title"
                placeholder="e.g. Leeds Policy Workshop Rail & Subsistence"
                class="mt-1 w-full rounded border border-slate-300 bg-white px-3 py-1.5 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label for="exp-cat" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Category</label>
                <select
                  id="exp-cat"
                  name="category"
                  [(ngModel)]="category"
                  class="mt-1 w-full rounded border border-slate-300 bg-white px-2.5 py-1.5 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                >
                  <option value="Rail & Travel">Rail & Travel</option>
                  <option value="Mileage">Mileage ({{ store.currentDepartment().mileageRatePence }}p/mi)</option>
                  <option value="Subsistence">Subsistence</option>
                  <option value="Accommodation">Accommodation</option>
                </select>
              </div>
              <div>
                <label for="exp-cc" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Cost centre</label>
                <input
                  id="exp-cc"
                  name="costCentre"
                  type="text"
                  [(ngModel)]="costCentre"
                  class="mt-1 w-full rounded border border-slate-300 bg-white px-2.5 py-1.5 font-mono text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>
            </div>

            <div class="grid grid-cols-2 gap-3">
              @if (category === 'Mileage') {
                <div>
                  <label for="exp-miles" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Miles travelled</label>
                  <input
                    id="exp-miles"
                    name="mileageMiles"
                    type="number"
                    min="1"
                    [(ngModel)]="mileageMiles"
                    class="mt-1 w-full rounded border border-slate-300 bg-white px-2.5 py-1.5 font-mono text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                  />
                </div>
              } @else {
                <div>
                  <label for="exp-amt" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Amount (£ GBP)</label>
                  <input
                    id="exp-amt"
                    name="amountGbp"
                    type="number"
                    min="1"
                    step="0.01"
                    [(ngModel)]="amountGbp"
                    class="mt-1 w-full rounded border border-slate-300 bg-white px-2.5 py-1.5 font-mono text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                  />
                </div>
              }
              <div>
                <label for="exp-rcpt" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Receipt filename</label>
                <input
                  id="exp-rcpt"
                  name="receiptFileName"
                  type="text"
                  [(ngModel)]="receiptFileName"
                  class="mt-1 w-full rounded border border-slate-300 bg-white px-2.5 py-1.5 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>
            </div>

            <label class="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300">
              <input type="checkbox" name="corpCard" [(ngModel)]="corporateCardUsed" class="h-4 w-4 rounded" />
              Reconcile against corporate card statement
            </label>

            <button
              type="submit"
              class="w-full rounded bg-[#1d70b8] px-4 py-2 text-sm font-medium text-white hover:bg-[#003078]"
            >
              Submit expense claim
            </button>
          </form>
        </section>
      </div>

      <!-- Journey 2: Full Expense Lifecycle Ledger -->
      <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <div class="border-b border-slate-200 pb-3 dark:border-slate-800">
          <h2 class="text-base font-semibold text-slate-900 dark:text-slate-100">
            Expense claims lifecycle (Draft → Manager review → Finance review → Paid)
          </h2>
          <p class="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Includes returned-for-correction, rejected, withdrawn, and payment-failed recovery states. In-flight claims retain their submission rule version.
          </p>
        </div>

        <div class="mt-4 space-y-4">
          @for (claim of visibleClaims(); track claim.id) {
            <div class="rounded border border-slate-200 p-4 dark:border-slate-800">
              <div class="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                <div>
                  <div class="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                    <span class="font-mono font-semibold text-slate-800 dark:text-slate-200">{{ claim.id }}</span>
                    <span aria-hidden="true">·</span>
                    <span>Claimant: {{ employeeName(claim.employeeId) }}</span>
                    <span aria-hidden="true">·</span>
                    <span class="font-mono">{{ claim.ruleVersion }} (eff. {{ claim.policyEffectiveDate }})</span>
                    <span aria-hidden="true">·</span>
                    <span>{{ claim.corporateCardUsed ? 'Corporate card reconciliation' : 'Personal reimbursement' }}</span>
                  </div>
                  <h3 class="mt-1 text-base font-semibold text-slate-900 dark:text-slate-100">
                    {{ claim.title }}
                  </h3>
                  <p class="mt-1 text-xs text-slate-600 dark:text-slate-300">
                    Status:
                    <strong
                      [class.text-red-700]="claim.status === 'Payment failed' || claim.status === 'Rejected'"
                      [class.dark:text-red-400]="claim.status === 'Payment failed' || claim.status === 'Rejected'"
                      [class.text-[#00703c]]="claim.status === 'Paid'"
                      [class.dark:text-emerald-400]="claim.status === 'Paid'"
                    >
                      {{ claim.status }}
                    </strong>
                    @if (claim.nextActionOwnerId) {
                      <span> · Next action: {{ employeeName(claim.nextActionOwnerId) }}</span>
                    }
                    @if (claim.paymentReference) {
                      <span class="font-mono"> · Ref {{ claim.paymentReference }}</span>
                    }
                  </p>
                  @if (claim.decisionReason) {
                    <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">Note: {{ claim.decisionReason }}</p>
                  }
                  @if (claim.integrationError) {
                    <p class="mt-1 text-xs font-medium text-red-700 dark:text-red-400">
                      Integration error: {{ claim.integrationError }}
                    </p>
                  }
                </div>

                <div class="text-left lg:text-right shrink-0">
                  <p class="font-mono text-lg font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                    £{{ claim.totalAmountGbp.toFixed(2) }}
                  </p>
                  <p class="font-mono text-xs text-slate-500">Cost centre {{ claim.costCentre }}</p>
                </div>
              </div>

              <!-- Receipts -->
              <div class="mt-3 border-t border-slate-100 pt-2.5 text-xs text-slate-600 dark:border-slate-800 dark:text-slate-400">
                @for (item of claim.items; track item.id) {
                  <p>
                    {{ item.date }} · {{ item.category }}: {{ item.description }}
                    (<span class="font-mono">£{{ item.amountGbp.toFixed(2) }}</span> · {{ item.receiptFileName }} [{{ item.receiptScanStatus }}])
                  </p>
                }
              </div>

              <!-- Role-sensitive Workflow Actions -->
              <div class="mt-3 flex flex-wrap gap-2">
                @if (claim.status === 'Manager review' && store.currentUser().id === claim.managerApproverId) {
                  <button
                    type="button"
                    (click)="store.actOnExpenseClaim(claim.id, 'manager_approve', 'Verified business travel & receipts')"
                    class="rounded bg-[#00703c] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#005a30]"
                  >
                    Approve (Send to Finance)
                  </button>
                  <button
                    type="button"
                    (click)="store.actOnExpenseClaim(claim.id, 'return', 'Please attach itemised VAT breakdown')"
                    class="rounded border border-amber-400 px-3 py-1.5 text-xs font-medium text-amber-800 hover:bg-amber-50 dark:border-amber-700 dark:text-amber-300"
                  >
                    Return for correction
                  </button>
                  <button
                    type="button"
                    (click)="store.actOnExpenseClaim(claim.id, 'reject', 'Out-of-policy travel class')"
                    class="rounded border border-red-300 px-3 py-1.5 text-xs font-medium text-red-700 hover:bg-red-50 dark:border-red-800 dark:text-red-400"
                  >
                    Reject
                  </button>
                }

                @if (claim.status === 'Finance review' && store.currentUser().demoRole === 'finance_officer') {
                  <button
                    type="button"
                    (click)="store.actOnExpenseClaim(claim.id, 'finance_pay')"
                    class="rounded bg-[#00703c] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#005a30]"
                  >
                    Disburse BACS payment
                  </button>
                  <button
                    type="button"
                    (click)="store.actOnExpenseClaim(claim.id, 'finance_fail_payment')"
                    class="rounded border border-amber-400 px-3 py-1.5 text-xs font-medium text-amber-800 hover:bg-amber-50 dark:border-amber-700 dark:text-amber-300"
                  >
                    Simulate BACS timeout failure
                  </button>
                  <button
                    type="button"
                    (click)="store.actOnExpenseClaim(claim.id, 'return', 'Cost centre code mismatch')"
                    class="rounded border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 dark:border-slate-700 dark:text-slate-200"
                  >
                    Return to claimant
                  </button>
                }

                @if (claim.status === 'Payment failed' && store.currentUser().demoRole === 'finance_officer') {
                  <button
                    type="button"
                    (click)="store.actOnExpenseClaim(claim.id, 'retry_payment', 'Idempotent BACS retry settled')"
                    class="rounded bg-[#1d70b8] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#003078]"
                  >
                    Retry & recover payment (Idempotent)
                  </button>
                }

                @if (claim.status === 'Returned for correction' && claim.employeeId === store.currentUser().id) {
                  <button
                    type="button"
                    (click)="store.actOnExpenseClaim(claim.id, 'submit', 'Updated itemised receipt attached')"
                    class="rounded bg-[#1d70b8] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#003078]"
                  >
                    Resubmit corrected claim
                  </button>
                }

                @if (claim.employeeId === store.currentUser().id && !['Paid', 'Rejected', 'Withdrawn'].includes(claim.status)) {
                  <button
                    type="button"
                    (click)="store.actOnExpenseClaim(claim.id, 'withdraw', 'Withdrawn by claimant')"
                    class="rounded border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 dark:border-slate-700 dark:text-slate-200"
                  >
                    Withdraw
                  </button>
                }
              </div>
            </div>
          }
        </div>
      </section>
    </div>
  `,
})
export class PayExpensesComponent {
  readonly store = inject(WorkspaceStore);

  title = '';
  costCentre = 'CC-4410-DIG';
  category: ExpenseClaim['items'][0]['category'] = 'Rail & Travel';
  amountGbp = 68.5;
  mileageMiles = 45;
  receiptFileName = 'vat_receipt_nov2026.pdf';
  corporateCardUsed = false;

  readonly visibleClaims = computed(() => {
    const actor = this.store.currentUser();
    if (actor.demoRole === 'employee') {
      return this.store.expenseClaims().filter((c) => c.employeeId === actor.id);
    }
    return this.store.expenseClaims();
  });

  submitExpense(): void {
    if (!this.title.trim()) {
      this.store.notify('error', 'Enter a claim title before submitting.');
      return;
    }
    this.store.createExpenseClaim({
      title: this.title,
      costCentre: this.costCentre,
      category: this.category,
      description: `${this.category} claim submitted under ${this.store.currentDepartment().code} rules`,
      amountGbp: Number(this.amountGbp) || 0,
      mileageMiles: this.category === 'Mileage' ? Number(this.mileageMiles) || 1 : undefined,
      receiptFileName: this.receiptFileName,
      corporateCardUsed: this.corporateCardUsed,
    });
    this.title = '';
  }

  employeeName(id: string): string {
    return this.store.employees().find((e) => e.id === id)?.displayName ?? id;
  }
}
