import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RestrictedHrCase } from '../../domain/models';
import { WorkspaceStore } from '../core/workspace.store';

interface AssistantCitation {
  policyId: string;
  title: string;
  version: string;
  effectiveDate: string;
  status: string;
}

interface AssistantResponse {
  answer: string;
  citations: AssistantCitation[];
  draftWording?: string;
  advisoryNote: string;
}

@Component({
  selector: 'app-policies',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-8">
      <div class="border-b border-slate-200 pb-5 dark:border-slate-800">
        <h1 class="text-2xl font-semibold text-slate-900 dark:text-slate-100">Policies, knowledge & confidential support</h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">
          Permission-aware policy library with explicit version history, policy owners, and clear separation between current and superseded guidance.
        </p>
      </div>

      <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <!-- Policy Library (2 cols) -->
        <div class="space-y-4 lg:col-span-2">
          <div class="flex flex-col gap-3 rounded border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 sm:flex-row sm:items-center sm:justify-between">
            <input
              type="search"
              [ngModel]="query()"
              (ngModelChange)="query.set($event)"
              aria-label="Search policies and guidance"
              placeholder="Search policies, forms, or guidance..."
              class="flex-1 rounded border border-slate-300 bg-white px-3 py-1.5 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
            <label class="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                [ngModel]="includeExpired()"
                (ngModelChange)="includeExpired.set($event)"
                class="h-4 w-4 rounded"
              />
              Show superseded (expired) versions
            </label>
          </div>

          @for (pol of filteredPolicies(); track pol.id) {
            <article class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <p class="text-xs text-slate-500 dark:text-slate-400">
                    <span class="font-mono font-semibold text-slate-800 dark:text-slate-200">{{ pol.id }}</span>
                    <span aria-hidden="true"> · </span>
                    <span>{{ pol.version }}</span>
                    <span aria-hidden="true"> · </span>
                    <span>Effective {{ pol.effectiveDate }}</span>
                    <span aria-hidden="true"> · </span>
                    <strong [class.text-amber-700]="pol.status !== 'Current'" [class.dark:text-amber-400]="pol.status !== 'Current'">
                      {{ pol.status }}
                    </strong>
                  </p>
                  <h2 class="mt-1 text-base font-semibold text-slate-900 dark:text-slate-100">{{ pol.title }}</h2>
                  <p class="mt-0.5 text-xs text-slate-500 dark:text-slate-400">Policy owner: {{ pol.owner }}</p>
                </div>

                @if (pol.requiresAcknowledgement && pol.status === 'Current') {
                  @if (pol.acknowledgedByIds.includes(store.currentUser().id)) {
                    <span class="font-mono text-xs font-medium text-[#00703c] dark:text-emerald-400">Acknowledged</span>
                  } @else {
                    <button
                      type="button"
                      (click)="store.acknowledgePolicy(pol.id)"
                      class="whitespace-nowrap rounded bg-[#1d70b8] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#003078]"
                    >
                      Acknowledge policy
                    </button>
                  }
                }
              </div>

              <p class="mt-3 text-sm text-slate-700 dark:text-slate-300">{{ pol.summary }}</p>
              <p class="mt-2 text-xs leading-relaxed text-slate-600 dark:text-slate-400">{{ pol.fullGuidance }}</p>
            </article>
          }

          <!-- Journey 6: Restricted HR Enquiry & Whistleblowing Separated Route -->
          <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
              Confidential HR enquiry, workplace adjustment & whistleblowing routes
            </h2>
            <p class="mt-2 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
              Cases submitted here go directly to an assigned HR Adviser with strict case-specific access controls. Line managers do not receive automatic access. Note on whistleblowing: this route records your identity for statutory follow-up—it does not falsely promise technical anonymity; external independent whistleblowing helplines remain available in policy guidance.
            </p>

            <form (ngSubmit)="submitHrEnquiry()" class="mt-4 space-y-3 text-sm">
              <div>
                <label for="hr-type" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Channel / case type</label>
                <select
                  id="hr-type"
                  name="hrCaseType"
                  [(ngModel)]="hrCaseType"
                  class="mt-1 w-full rounded border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                >
                  <option value="HR enquiry">Confidential HR enquiry</option>
                  <option value="Workplace adjustment">Workplace adjustment / Occupational health</option>
                  <option value="Grievance">Formal grievance</option>
                  <option value="Whistleblowing channel">Whistleblowing / Safeguarding channel (Non-anonymous audit)</option>
                </select>
              </div>
              <div>
                <label for="hr-sum" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Brief non-clinical summary</label>
                <input
                  id="hr-sum"
                  name="hrSummary"
                  type="text"
                  [(ngModel)]="hrSummary"
                  placeholder="Short description for case routing"
                  class="mt-1 w-full rounded border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>
              <div>
                <label for="hr-notes" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Restricted case details</label>
                <textarea
                  id="hr-notes"
                  name="hrNotes"
                  rows="2"
                  [(ngModel)]="hrNotes"
                  placeholder="Only you and your assigned HR Adviser can view these notes..."
                  class="mt-1 w-full rounded border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                ></textarea>
              </div>
              <button
                type="submit"
                class="rounded bg-[#0e233f] px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
              >
                Open restricted HR case
              </button>
            </form>
          </section>
        </div>

        <!-- Right Column: Optional Disabled-by-Default Policy Assistant + Templates -->
        <div class="space-y-6">
          <section class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div class="flex items-start justify-between gap-3 border-b border-slate-200 pb-3 dark:border-slate-800">
              <div>
                <h2 class="text-base font-semibold text-slate-900 dark:text-slate-100">
                  Optional policy assistant
                </h2>
                <p class="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  Disabled by default. Read-only guidance with source citations.
                </p>
              </div>
              <button
                type="button"
                (click)="store.policyAssistantEnabled.set(!store.policyAssistantEnabled())"
                class="whitespace-nowrap rounded border border-slate-300 px-2.5 py-1 text-xs font-medium text-slate-800 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                {{ store.policyAssistantEnabled() ? 'Disable' : 'Enable' }}
              </button>
            </div>

            @if (!store.policyAssistantEnabled()) {
              <p class="mt-4 text-xs leading-relaxed text-slate-600 dark:text-slate-400">
                The assistant is turned off by default. Enable it to ask plain-English questions about authorised policies, explain form fields, summarise your open tasks, or draft request wording for your manual review.
              </p>
            } @else {
              <form (ngSubmit)="askAssistant()" class="mt-4 space-y-3">
                <label for="ai-q" class="block text-xs font-medium text-slate-700 dark:text-slate-300">
                  Ask about policies, forms, or your authorised tasks
                </label>
                <textarea
                  id="ai-q"
                  name="assistantPrompt"
                  rows="3"
                  [(ngModel)]="assistantPrompt"
                  placeholder="e.g. Which expense policy version applies to a claim submitted today, and what is the subsistence cap?"
                  class="w-full rounded border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                ></textarea>
                <button
                  type="submit"
                  [disabled]="assistantLoading()"
                  class="w-full rounded bg-[#1d70b8] px-3 py-2 text-xs font-medium text-white hover:bg-[#003078] disabled:opacity-60"
                >
                  {{ assistantLoading() ? 'Checking authorised guidance...' : 'Ask policy assistant' }}
                </button>
              </form>

              @if (assistantError()) {
                <p class="mt-3 rounded border border-red-300 bg-red-50 p-2.5 text-xs text-red-800 dark:border-red-800 dark:bg-red-950/50 dark:text-red-300">
                  {{ assistantError() }}
                </p>
              }

              @if (assistantReply(); as reply) {
                <div class="mt-4 space-y-3 border-t border-slate-200 pt-3 text-xs dark:border-slate-800">
                  <p class="leading-relaxed text-slate-800 dark:text-slate-200">{{ reply.answer }}</p>
                  @if (reply.citations.length > 0) {
                    <div>
                      <p class="font-semibold text-slate-700 dark:text-slate-300">Citations</p>
                      <ul class="mt-1 space-y-1 text-slate-600 dark:text-slate-400">
                        @for (c of reply.citations; track c.policyId) {
                          <li class="font-mono">
                            {{ c.policyId }} · {{ c.version }} (eff. {{ c.effectiveDate }}) [{{ c.status }}]
                          </li>
                        }
                      </ul>
                    </div>
                  }
                  @if (reply.draftWording) {
                    <div class="rounded border border-slate-200 bg-slate-50 p-2.5 dark:border-slate-800 dark:bg-slate-800/40">
                      <p class="font-semibold text-slate-700 dark:text-slate-300">Draft for your review</p>
                      <p class="mt-1 text-slate-600 dark:text-slate-300">{{ reply.draftWording }}</p>
                    </div>
                  }
                  <p class="text-[11px] text-slate-500 dark:text-slate-400">{{ reply.advisoryNote }}</p>
                </div>
              }
            }
          </section>

          <section class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
              Forms, templates & FAQs
            </h2>
            <ul class="mt-3 space-y-2.5 text-xs text-slate-700 dark:text-slate-300">
              <li>Flexible & Compressed Working Application Form (DOCX / Accessible HTML)</li>
              <li>Occupational Health Referral & Workplace Adjustment Passport</li>
              <li>Travel Pre-Authorisation & International Subsistence Guide</li>
              <li>FAQ: Why are superseded policies clearly labelled?</li>
            </ul>
          </section>
        </div>
      </div>
    </div>
  `,
})
export class PoliciesComponent {
  readonly store = inject(WorkspaceStore);

  readonly query = signal('');
  readonly includeExpired = signal(false);

  hrCaseType: RestrictedHrCase['caseType'] = 'HR enquiry';
  hrSummary = '';
  hrNotes = '';

  assistantPrompt = '';
  readonly assistantLoading = signal(false);
  readonly assistantError = signal<string | null>(null);
  readonly assistantReply = signal<AssistantResponse | null>(null);

  readonly filteredPolicies = computed(() => {
    const q = this.query().trim().toLowerCase();
    return this.store.visiblePolicies().filter((p) => {
      if (!this.includeExpired() && p.status === 'Superseded (Expired)') return false;
      if (!q) return true;
      return (
        p.title.toLowerCase().includes(q) ||
        p.summary.toLowerCase().includes(q) ||
        p.id.toLowerCase().includes(q)
      );
    });
  });

  submitHrEnquiry(): void {
    if (!this.hrSummary.trim()) {
      this.store.notify('error', 'Enter a brief summary before opening a restricted HR case.');
      return;
    }
    this.store.submitRestrictedHrCase(
      this.hrCaseType,
      this.hrSummary,
      this.hrNotes || 'Submitted via confidential HR channel.',
    );
    this.hrSummary = '';
    this.hrNotes = '';
  }

  async askAssistant(): Promise<void> {
    if (!this.assistantPrompt.trim()) return;
    this.assistantLoading.set(true);
    this.assistantError.set(null);
    try {
      const resp = await fetch('/api/assistant/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabled: this.store.policyAssistantEnabled(),
          employeeId: this.store.currentUser().id,
          prompt: this.assistantPrompt,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        this.assistantError.set(data.error || 'Policy Assistant request failed.');
      } else {
        this.assistantReply.set(data as AssistantResponse);
      }
    } catch {
      this.assistantError.set('Network error reaching server Policy Assistant.');
    } finally {
      this.assistantLoading.set(false);
    }
  }
}
