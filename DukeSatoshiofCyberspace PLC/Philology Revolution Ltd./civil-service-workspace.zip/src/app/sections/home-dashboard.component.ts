import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkspaceStore } from '../core/workspace.store';

@Component({
  selector: 'app-home-dashboard',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-8">
      <!-- Page Header -->
      <div class="flex flex-col gap-4 border-b border-slate-200 pb-6 dark:border-slate-800 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p class="text-xs font-medium text-slate-500 dark:text-slate-400">
            {{ store.currentDepartment().name }} · {{ store.currentUser().directorate }}
          </p>
          <h1 class="mt-1 text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
            Welcome back, {{ store.currentUser().displayName }}
          </h1>
          <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">
            {{ store.currentUser().roleTitle }} · Grade {{ store.currentUser().grade }} · {{ store.currentUser().hybridArrangement }}
          </p>
        </div>

        <!-- Shortcuts to common actions -->
        <div class="flex flex-wrap items-center gap-2">
          <button
            type="button"
            (click)="store.navigate('leave')"
            class="whitespace-nowrap shrink-0 rounded border border-[#1d70b8] bg-[#1d70b8] px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-[#003078]"
          >
            Request leave
          </button>
          <button
            type="button"
            (click)="store.navigate('pay-expenses')"
            class="whitespace-nowrap shrink-0 rounded border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-800 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
          >
            Submit expense
          </button>
          <button
            type="button"
            (click)="store.navigate('services')"
            class="whitespace-nowrap shrink-0 rounded border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-800 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
          >
            Request IT or equipment
          </button>
        </div>
      </div>

      <!-- KPI Summary Strip -->
      <section aria-label="Personal workspace summary" class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p class="text-xs font-medium text-slate-500 dark:text-slate-400">Available annual leave</p>
          <p class="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-900 dark:text-slate-100">
            {{ availableLeaveDays() }} days
          </p>
          <p class="mt-1 text-xs text-slate-600 dark:text-slate-400 tabular-nums">
            {{ store.currentLeaveBalance().pendingDays }} pending · Flexi +{{ store.currentLeaveBalance().flexiHoursBalance }}h
          </p>
        </div>

        <div class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p class="text-xs font-medium text-slate-500 dark:text-slate-400">Requests awaiting my action</p>
          <p class="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-900 dark:text-slate-100">
            {{ store.pendingActionsForCurrentUser().length }}
          </p>
          <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">
            <button
              type="button"
              (click)="store.navigate('approvals')"
              class="font-medium text-[#1d70b8] underline underline-offset-2 hover:text-[#003078] dark:text-sky-400"
            >
              Open approvals queue
            </button>
          </p>
        </div>

        <div class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p class="text-xs font-medium text-slate-500 dark:text-slate-400">My active tasks</p>
          <p class="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-900 dark:text-slate-100">
            {{ myOpenTasks().length }}
          </p>
          <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">
            <button
              type="button"
              (click)="store.navigate('tasks')"
              class="font-medium text-[#1d70b8] underline underline-offset-2 hover:text-[#003078] dark:text-sky-400"
            >
              View task workflow board
            </button>
          </p>
        </div>

        <div class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p class="text-xs font-medium text-slate-500 dark:text-slate-400">Open service tickets</p>
          <p class="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-900 dark:text-slate-100">
            {{ myOpenTickets().length }}
          </p>
          <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">
            Payroll: November payslip available 27 Nov
          </p>
        </div>
      </section>

      <!-- Main Two-Column Content -->
      <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <!-- Left 2 Columns: Tasks, Requests Awaiting Action, Upcoming Schedule -->
        <div class="space-y-6 lg:col-span-2">
          <!-- Requests awaiting action -->
          <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <div class="flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
              <h2 class="text-base font-semibold text-slate-900 dark:text-slate-100">
                Requests awaiting your action
              </h2>
              <button
                type="button"
                (click)="store.navigate('approvals')"
                class="text-xs font-medium text-[#1d70b8] underline underline-offset-2 dark:text-sky-400"
              >
                All approvals
              </button>
            </div>

            @if (store.pendingActionsForCurrentUser().length === 0) {
              <p class="py-6 text-sm text-slate-600 dark:text-slate-400">
                No approvals are currently waiting for your decision.
              </p>
            } @else {
              <div class="divide-y divide-slate-200 dark:divide-slate-800">
                @for (item of store.pendingActionsForCurrentUser(); track item.id) {
                  <div class="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between">
                    <div class="min-w-0">
                      <p class="text-sm font-medium text-slate-900 dark:text-slate-100">
                        {{ item.title }}
                      </p>
                      <p class="mt-1 text-xs text-slate-500 dark:text-slate-400">
                        <span class="font-mono">{{ item.referenceId }}</span>
                        <span aria-hidden="true"> · </span>
                        <span>{{ item.ruleVersion }}</span>
                        <span aria-hidden="true"> · </span>
                        <span>Escalates {{ item.escalationDeadline.slice(0, 10) }}</span>
                      </p>
                    </div>
                    <div class="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        (click)="store.actOnApproval(item.id, 'Approve', 'Approved from workspace home')"
                        class="whitespace-nowrap rounded bg-[#00703c] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#005a30]"
                      >
                        Approve
                      </button>
                      <button
                        type="button"
                        (click)="store.navigate('approvals')"
                        class="whitespace-nowrap rounded border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                      >
                        Review details
                      </button>
                    </div>
                  </div>
                }
              </div>
            }
          </section>

          <!-- My tasks and deadlines -->
          <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <div class="flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
              <h2 class="text-base font-semibold text-slate-900 dark:text-slate-100">
                My tasks & deadlines
              </h2>
              <button
                type="button"
                (click)="store.navigate('tasks')"
                class="text-xs font-medium text-[#1d70b8] underline underline-offset-2 dark:text-sky-400"
              >
                Open workflow engine
              </button>
            </div>
            <div class="overflow-x-auto">
              <table class="w-full text-left text-sm">
                <thead>
                  <tr class="border-b border-slate-200 text-xs font-medium text-slate-500 dark:border-slate-800 dark:text-slate-400">
                    <th class="py-2.5 pr-4">Reference & Title</th>
                    <th class="py-2.5 px-3">Priority</th>
                    <th class="py-2.5 px-3">Status</th>
                    <th class="py-2.5 pl-3 text-right">Due date</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
                  @for (task of myOpenTasks(); track task.id) {
                    <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td class="py-3 pr-4">
                        <p class="font-medium text-slate-900 dark:text-slate-100">{{ task.title }}</p>
                        <p class="text-xs text-slate-500 dark:text-slate-400">
                          <span class="font-mono">{{ task.id }}</span> · {{ task.accountableTeam }}
                        </p>
                      </td>
                      <td class="py-3 px-3 text-xs font-medium" [class.text-red-700]="task.priority === 'Urgent'" [class.dark:text-red-400]="task.priority === 'Urgent'">
                        {{ task.priority }}
                      </td>
                      <td class="py-3 px-3 text-xs text-slate-700 dark:text-slate-300">{{ task.status }}</td>
                      <td class="py-3 pl-3 text-right font-mono text-xs tabular-nums text-slate-600 dark:text-slate-300">
                        {{ task.dueDate }}
                      </td>
                    </tr>
                  } @empty {
                    <tr>
                      <td colspan="4" class="py-6 text-center text-sm text-slate-500 dark:text-slate-400">
                        All assigned tasks are completed.
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </section>

          <!-- Line Manager Operational Overview (Hidden from standard employees; never leaks confidential HR cases) -->
          @if (store.currentUser().demoRole === 'line_manager') {
            <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <div class="flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
                <h2 class="text-base font-semibold text-slate-900 dark:text-slate-100">
                  Line Manager Team Overview
                </h2>
                <span class="text-xs text-slate-500 dark:text-slate-400">
                  Confidential HR & medical cases excluded
                </span>
              </div>
              <div class="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div class="rounded border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-800/40">
                  <p class="text-xs text-slate-500 dark:text-slate-400">Upcoming staffing gaps</p>
                  <p class="mt-1 font-mono text-lg font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                    {{ store.teamAvailability().length }} scheduled
                  </p>
                  <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">
                    Availability shown without medical reasons
                  </p>
                </div>
                <div class="rounded border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-800/40">
                  <p class="text-xs text-slate-500 dark:text-slate-400">Mandatory learning</p>
                  <p class="mt-1 font-mono text-lg font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                    86% team complete
                  </p>
                  <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">
                    1 refresher due 24 Nov 2026
                  </p>
                </div>
                <div class="rounded border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-800/40">
                  <p class="text-xs text-slate-500 dark:text-slate-400">Probation & review milestones</p>
                  <p class="mt-1 font-mono text-lg font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                    2 upcoming
                  </p>
                  <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">
                    Amira Hassan Day-1 induction 1 Dec
                  </p>
                </div>
              </div>
            </section>
          }
        </div>

        <!-- Right Column: Announcements, Policy Changes, Payroll & Training -->
        <div class="space-y-6">
          <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
              Upcoming schedule & training
            </h2>
            <ul class="mt-4 space-y-3 text-sm">
              <li class="border-b border-slate-100 pb-3 dark:border-slate-800">
                <p class="font-medium text-slate-900 dark:text-slate-100">Accessibility & Inclusive Forms Clinic</p>
                <p class="mt-0.5 text-xs text-slate-500 dark:text-slate-400">Mon 23 Nov · 10:00–11:00 · Room 3.14 / Hybrid</p>
              </li>
              <li class="border-b border-slate-100 pb-3 dark:border-slate-800">
                <p class="font-medium text-slate-900 dark:text-slate-100">Information Handling Refresher (Mandatory)</p>
                <p class="mt-0.5 text-xs text-amber-700 dark:text-amber-400">Due 24 Nov 2026 · Civil Service Learning Hub</p>
              </li>
              <li>
                <p class="font-medium text-slate-900 dark:text-slate-100">Monthly Line Manager Check-In</p>
                <p class="mt-0.5 text-xs text-slate-500 dark:text-slate-400">Thu 26 Nov · 14:30–15:00 · Objective review</p>
              </li>
            </ul>
          </section>

          <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
              Departmental notices & policy updates
            </h2>
            <ul class="mt-4 space-y-4 text-sm">
              <li>
                <p class="font-medium text-slate-900 dark:text-slate-100">
                  Travel & Subsistence Policy v3.1 (Effective 1 Sep 2026)
                </p>
                <p class="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                  All new expense claims follow sequential Manager and Finance review. In-flight claims keep their submission rule version.
                </p>
                <button
                  type="button"
                  (click)="store.navigate('policies')"
                  class="mt-1.5 text-xs font-medium text-[#1d70b8] underline underline-offset-2 dark:text-sky-400"
                >
                  Read policy & acknowledge
                </button>
              </li>
              <li class="border-t border-slate-100 pt-3 dark:border-slate-800">
                <p class="font-medium text-slate-900 dark:text-slate-100">
                  November Payroll Cut-off Notice
                </p>
                <p class="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                  Approved overtime and verified bank-detail updates settle on 27 Nov 2026. Never share personal bank details via email.
                </p>
              </li>
            </ul>
          </section>
        </div>
      </div>
    </div>
  `,
})
export class HomeDashboardComponent {
  readonly store = inject(WorkspaceStore);

  readonly availableLeaveDays = computed(() => {
    const b = this.store.currentLeaveBalance();
    return b.annualEntitlementDays + b.carriedOverDays - b.takenDays - b.pendingDays;
  });

  readonly myOpenTasks = computed(() => {
    const uid = this.store.currentUser().id;
    return this.store
      .tasks()
      .filter((t) => (t.ownerId === uid || t.delegatedToId === uid) && t.status !== 'Done');
  });

  readonly myOpenTickets = computed(() => {
    const uid = this.store.currentUser().id;
    return this.store
      .serviceTickets()
      .filter((t) => t.requesterId === uid && !['Completed', 'Rejected', 'Withdrawn'].includes(t.status));
  });
}
