import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WorkspaceStore } from '../core/workspace.store';

@Component({
  selector: 'app-people',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-8">
      <div class="border-b border-slate-200 pb-5 dark:border-slate-800">
        <h1 class="text-2xl font-semibold text-slate-900 dark:text-slate-100">People, teams & joiner/mover/leaver journeys</h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">
          Public directory profiles and cross-departmental onboarding/exit orchestration. Private PII and vetting dossiers remain strictly isolated.
        </p>
      </div>

      <!-- Directory Search & Organisational Chart -->
      <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <div class="flex flex-col gap-3 border-b border-slate-200 pb-4 dark:border-slate-800 sm:flex-row sm:items-center sm:justify-between">
          <h2 class="text-base font-semibold text-slate-900 dark:text-slate-100">
            Staff directory & reporting lines
          </h2>
          <input
            type="search"
            [ngModel]="searchQuery()"
            (ngModelChange)="searchQuery.set($event)"
            aria-label="Search staff directory"
            placeholder="Search by name, grade, directorate or hub..."
            class="w-full rounded border border-slate-300 bg-white px-3 py-1.5 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 sm:w-72"
          />
        </div>

        <div class="mt-4 overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead>
              <tr class="border-b border-slate-200 text-xs font-medium text-slate-500 dark:border-slate-800 dark:text-slate-400">
                <th class="py-2.5 pr-3">Name & Role</th>
                <th class="py-2.5 px-3">Grade</th>
                <th class="py-2.5 px-3">Directorate & Team</th>
                <th class="py-2.5 px-3">Location & Hybrid</th>
                <th class="py-2.5 pl-3">Reports to</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
              @for (person of filteredStaff(); track person.id) {
                <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td class="py-3 pr-3">
                    <p class="font-medium text-slate-900 dark:text-slate-100">{{ person.displayName }}</p>
                    <p class="text-xs text-slate-500 dark:text-slate-400">{{ person.roleTitle }} · {{ person.workEmail }}</p>
                  </td>
                  <td class="py-3 px-3 font-mono text-xs">{{ person.grade }}</td>
                  <td class="py-3 px-3 text-xs text-slate-700 dark:text-slate-300">
                    {{ person.directorate }} · {{ person.team }}
                  </td>
                  <td class="py-3 px-3 text-xs text-slate-600 dark:text-slate-400">
                    {{ person.workLocation }}
                  </td>
                  <td class="py-3 pl-3 text-xs text-slate-700 dark:text-slate-300">
                    {{ person.managerId ? employeeName(person.managerId) : 'Senior Civil Service Lead' }}
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Journey 4: Coordinated Onboarding & Leaver Workflows -->
      <section class="space-y-6">
        <h2 class="text-lg font-semibold text-slate-900 dark:text-slate-100">
          Coordinated onboarding & leaver journeys (HR · Security · IT · Facilities · Manager)
        </h2>

        <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
          @for (journey of store.lifecycleJourneys(); track journey.id) {
            <article class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <div class="flex items-start justify-between gap-3 border-b border-slate-200 pb-3 dark:border-slate-800">
                <div>
                  <p class="font-mono text-xs text-slate-500 dark:text-slate-400">
                    {{ journey.id }} · {{ journey.journeyType }} · Staff {{ journey.staffNumber }}
                  </p>
                  <h3 class="mt-1 text-base font-semibold text-slate-900 dark:text-slate-100">
                    {{ journey.personName }} — {{ journey.roleTitle }}
                  </h3>
                  <p class="mt-1 text-xs text-slate-600 dark:text-slate-300">
                    Effective date: <strong class="font-mono">{{ journey.effectiveDate }}</strong>
                    · Vetting: <strong>{{ journey.vettingStatus }}</strong>
                    @if (journey.cancelled) {
                      <span class="font-semibold text-red-700 dark:text-red-400"> · DEPARTURE CANCELLED</span>
                    }
                  </p>
                  @if (journey.dateChangeNote) {
                    <p class="mt-1 text-xs text-amber-800 dark:text-amber-300">{{ journey.dateChangeNote }}</p>
                  }
                </div>
              </div>

              <ol class="mt-4 space-y-2.5 text-sm">
                @for (step of journey.steps; track step.id) {
                  <li class="flex items-center justify-between gap-3 rounded border border-slate-200 p-2.5 text-xs dark:border-slate-800">
                    <div>
                      <p class="font-medium text-slate-900 dark:text-slate-100">{{ step.label }}</p>
                      <p class="text-slate-500 dark:text-slate-400">
                        Owner: {{ step.ownerTeam }} · Status: <strong>{{ step.status }}</strong>
                        @if (step.completedAt) {
                          <span> ({{ step.completedAt }})</span>
                        }
                      </p>
                    </div>
                    @if (step.status !== 'Completed' && !journey.cancelled && store.currentUser().demoRole !== 'auditor') {
                      <button
                        type="button"
                        (click)="store.advanceLifecycleStep(journey.id, step.id)"
                        class="whitespace-nowrap rounded border border-[#1d70b8] px-2.5 py-1 text-xs font-medium text-[#1d70b8] hover:bg-[#1d70b8]/10 dark:text-sky-400"
                      >
                        Mark complete
                      </button>
                    }
                  </li>
                }
              </ol>

              <!-- Date Amendment / Cancel Departure Controls -->
              @if (['hr_adviser', 'dept_admin', 'line_manager'].includes(store.currentUser().demoRole) && !journey.cancelled) {
                <div class="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-200 pt-3 dark:border-slate-800">
                  <input
                    type="date"
                    [(ngModel)]="amendedDate"
                    [name]="'date-' + journey.id"
                    aria-label="Amend effective date"
                    class="rounded border border-slate-300 bg-white px-2.5 py-1 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                  />
                  <button
                    type="button"
                    (click)="store.updateLifecycleEffectiveDate(journey.id, amendedDate, false)"
                    class="rounded border border-slate-300 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200"
                  >
                    Amend date
                  </button>
                  @if (journey.journeyType === 'Leaver') {
                    <button
                      type="button"
                      (click)="store.updateLifecycleEffectiveDate(journey.id, journey.effectiveDate, true)"
                      class="rounded border border-red-300 px-2.5 py-1 text-xs font-medium text-red-700 hover:bg-red-50 dark:border-red-800 dark:text-red-400"
                    >
                      Cancel departure
                    </button>
                  }
                </div>
              }
            </article>
          }
        </div>
      </section>
    </div>
  `,
})
export class PeopleComponent {
  readonly store = inject(WorkspaceStore);
  readonly searchQuery = signal('');
  amendedDate = '2026-12-22';

  readonly filteredStaff = computed(() => {
    const q = this.searchQuery().trim().toLowerCase();
    if (!q) return this.store.employees();
    return this.store.employees().filter(
      (e) =>
        e.displayName.toLowerCase().includes(q) ||
        e.roleTitle.toLowerCase().includes(q) ||
        e.grade.toLowerCase().includes(q) ||
        e.directorate.toLowerCase().includes(q) ||
        e.workLocation.toLowerCase().includes(q),
    );
  });

  employeeName(id: string): string {
    return this.store.employees().find((e) => e.id === id)?.displayName ?? id;
  }
}
