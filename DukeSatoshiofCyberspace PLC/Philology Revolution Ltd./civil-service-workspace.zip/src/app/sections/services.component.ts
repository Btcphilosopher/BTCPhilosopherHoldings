import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ServiceTicket } from '../../domain/models';
import { WorkspaceStore } from '../core/workspace.store';

@Component({
  selector: 'app-services',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-8">
      <div class="border-b border-slate-200 pb-5 dark:border-slate-800">
        <h1 class="text-2xl font-semibold text-slate-900 dark:text-slate-100">Help, IT & workplace services</h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">
          Service catalogue with published response targets, identity/ITSM integrations, desk & meeting-room bookings, procurement queries, and equipment requests.
        </p>
      </div>

      <!-- Service Catalogue Quick Launcher -->
      <section class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
        @for (cat of catalogueItems; track cat.category) {
          <button
            type="button"
            (click)="selectCategory(cat.category, cat.defaultCost)"
            [class]="selectedCategory === cat.category ? 'border-[#1d70b8] bg-[#1d70b8]/5 dark:border-sky-400' : 'border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900'"
            class="rounded border p-3.5 text-left transition-colors hover:border-[#1d70b8]"
          >
            <p class="text-sm font-semibold text-slate-900 dark:text-slate-100">{{ cat.category }}</p>
            <p class="mt-1 text-xs text-slate-500 dark:text-slate-400">Target SLA: {{ cat.sla }}</p>
          </button>
        }
      </section>

      <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <!-- Submit Service / Equipment Request -->
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
            Raise service or equipment request
          </h2>
          <form (ngSubmit)="submitTicket()" class="mt-4 space-y-3 text-sm">
            <div>
              <label for="srv-cat" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Service catalogue item</label>
              <select
                id="srv-cat"
                name="selectedCategory"
                [(ngModel)]="selectedCategory"
                class="mt-1 w-full rounded border border-slate-300 bg-white px-2.5 py-2 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                @for (cat of catalogueItems; track cat.category) {
                  <option [value]="cat.category">{{ cat.category }} (SLA {{ cat.sla }})</option>
                }
              </select>
            </div>

            <div>
              <label for="srv-title" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Request summary</label>
              <input
                id="srv-title"
                name="ticketTitle"
                type="text"
                [(ngModel)]="ticketTitle"
                placeholder="e.g. Standard encrypted laptop replacement or Room 4B booking"
                class="mt-1 w-full rounded border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label for="srv-cost" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Estimated cost (£ GBP, 0 if standard)</label>
              <input
                id="srv-cost"
                name="ticketCost"
                type="number"
                min="0"
                [(ngModel)]="ticketCost"
                class="mt-1 w-full rounded border border-slate-300 bg-white px-3 py-2 font-mono text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label for="srv-notes" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Business justification & delivery hub</label>
              <textarea
                id="srv-notes"
                name="ticketNotes"
                rows="3"
                [(ngModel)]="ticketNotes"
                placeholder="Include building, desk zone, PO number, or access scope..."
                class="mt-1 w-full rounded border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              ></textarea>
            </div>

            <button
              type="submit"
              class="w-full rounded bg-[#1d70b8] px-4 py-2 text-sm font-medium text-white hover:bg-[#003078]"
            >
              Submit service request
            </button>
          </form>
        </section>

        <!-- Journey 3: Service & Equipment Request Tracking + ITSM Fulfilment -->
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 lg:col-span-2">
          <div class="border-b border-slate-200 pb-3 dark:border-slate-800">
            <h2 class="text-base font-semibold text-slate-900 dark:text-slate-100">
              Active requests & ITSM fulfilment queue
            </h2>
            <p class="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Equipment requests require manager budget approval before IT Service Agent dispatch. Failed ITSM sync keeps tickets open for reconciliation.
            </p>
          </div>

          <div class="mt-4 space-y-3">
            @for (ticket of store.serviceTickets(); track ticket.id) {
              <article class="rounded border border-slate-200 p-4 dark:border-slate-800">
                <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <p class="text-xs text-slate-500 dark:text-slate-400">
                      <span class="font-mono font-semibold text-slate-800 dark:text-slate-200">{{ ticket.id }}</span>
                      <span aria-hidden="true"> · </span>
                      <span>{{ ticket.catalogueCategory }}</span>
                      <span aria-hidden="true"> · </span>
                      <span>SLA {{ ticket.expectedSla }}</span>
                      @if (ticket.costGbp) {
                        <span aria-hidden="true"> · </span>
                        <span class="font-mono">£{{ ticket.costGbp.toFixed(2) }}</span>
                      }
                    </p>
                    <h3 class="mt-1 text-sm font-semibold text-slate-900 dark:text-slate-100">{{ ticket.title }}</h3>
                    <p class="mt-1 text-xs text-slate-600 dark:text-slate-300">{{ ticket.notes }}</p>
                    <p class="mt-1.5 text-xs text-slate-500 dark:text-slate-400">
                      Requester: {{ employeeName(ticket.requesterId) }} · Status: <strong>{{ ticket.status }}</strong> · ITSM: <strong>{{ ticket.integrationJobStatus }}</strong>
                    </p>
                    @if (ticket.integrationError) {
                      <p class="mt-1 text-xs font-medium text-red-700 dark:text-red-400">{{ ticket.integrationError }}</p>
                    }
                  </div>

                  <div class="flex flex-wrap gap-2 shrink-0">
                    @if (ticket.status === 'Manager review' && (store.currentUser().demoRole === 'line_manager' || store.currentUser().id === ticket.approverId)) {
                      <button
                        type="button"
                        (click)="store.fulfilServiceTicket(ticket.id)"
                        class="rounded bg-[#00703c] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#005a30]"
                      >
                        Approve equipment
                      </button>
                    }
                    @if ((ticket.status === 'Approved' || ticket.status === 'Submitted') && store.currentUser().demoRole === 'it_agent') {
                      <button
                        type="button"
                        (click)="store.fulfilServiceTicket(ticket.id, false)"
                        class="rounded bg-[#1d70b8] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#003078]"
                      >
                        Fulfil via ITSM
                      </button>
                      <button
                        type="button"
                        (click)="store.fulfilServiceTicket(ticket.id, true)"
                        class="rounded border border-amber-400 px-3 py-1.5 text-xs font-medium text-amber-800 dark:border-amber-700 dark:text-amber-300"
                      >
                        Simulate ITSM failure
                      </button>
                    }
                  </div>
                </div>
              </article>
            }
          </div>
        </section>
      </div>
    </div>
  `,
})
export class ServicesComponent {
  readonly store = inject(WorkspaceStore);

  selectedCategory: ServiceTicket['catalogueCategory'] = 'Equipment Request';
  ticketTitle = '';
  ticketCost = 280;
  ticketNotes = '';

  readonly catalogueItems: {
    category: ServiceTicket['catalogueCategory'];
    sla: string;
    defaultCost: number;
  }[] = [
    { category: 'IT Support', sla: '4 hours', defaultCost: 0 },
    { category: 'Password & Access', sla: '4 hours', defaultCost: 0 },
    { category: 'Equipment Request', sla: '5 working days', defaultCost: 280 },
    { category: 'Software Request', sla: '2 working days', defaultCost: 120 },
    { category: 'Building Access', sla: '24 hours', defaultCost: 0 },
    { category: 'Desk & Room Booking', sla: 'Instant', defaultCost: 0 },
    { category: 'Facilities Fault', sla: '24 hours', defaultCost: 0 },
    { category: 'Procurement & PO', sla: '3 working days', defaultCost: 650 },
    { category: 'Records Management', sla: '2 working days', defaultCost: 0 },
    { category: 'Travel Support', sla: '1 working day', defaultCost: 0 },
  ];

  selectCategory(cat: ServiceTicket['catalogueCategory'], cost: number): void {
    this.selectedCategory = cat;
    this.ticketCost = cost;
  }

  submitTicket(): void {
    if (!this.ticketTitle.trim()) {
      this.store.notify('error', 'Enter a summary for your service request.');
      return;
    }
    this.store.submitServiceTicket({
      catalogueCategory: this.selectedCategory,
      title: this.ticketTitle,
      notes: this.ticketNotes || 'Submitted via Help & services catalogue',
      costGbp: Number(this.ticketCost) || 0,
    });
    this.ticketTitle = '';
    this.ticketNotes = '';
  }

  employeeName(id: string): string {
    return this.store.employees().find((e) => e.id === id)?.displayName ?? id;
  }
}
