import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WorkspaceTask } from '../../domain/models';
import { WorkspaceStore } from '../core/workspace.store';

@Component({
  selector: 'app-tasks',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-8">
      <div class="flex flex-col gap-4 border-b border-slate-200 pb-5 dark:border-slate-800 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h1 class="text-2xl font-semibold text-slate-900 dark:text-slate-100">Tasks & projects</h1>
          <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">
            Operational workflow engine · Distinguishes <strong>Tasks</strong> (work execution) from <strong>Approvals</strong> (authorisations), <strong>Cases</strong> (restricted HR), and <strong>Projects</strong>.
          </p>
        </div>

        <!-- View Switcher -->
        <div class="flex flex-wrap items-center gap-1 rounded bg-slate-100 p-1 dark:bg-slate-800">
          @for (mode of viewModes; track mode.id) {
            <button
              type="button"
              (click)="viewMode.set(mode.id)"
              [class]="viewMode() === mode.id ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-900 dark:text-white' : 'text-slate-600 dark:text-slate-300'"
              class="whitespace-nowrap shrink-0 rounded px-3 py-1.5 text-xs font-medium"
            >
              {{ mode.label }}
            </button>
          }
        </div>
      </div>

      <!-- Saved Filters & Bulk Reassignment Bar -->
      <div class="flex flex-col gap-3 rounded border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 lg:flex-row lg:items-center lg:justify-between">
        <div class="flex flex-wrap items-center gap-2">
          <span class="text-xs font-medium text-slate-500 dark:text-slate-400">Saved filters:</span>
          <button
            type="button"
            (click)="savedFilter.set('mine')"
            [class]="savedFilter() === 'mine' ? 'border-[#1d70b8] bg-[#1d70b8]/10 text-[#1d70b8] dark:text-sky-300' : 'border-slate-300 text-slate-700 dark:border-slate-700 dark:text-slate-300'"
            class="whitespace-nowrap rounded border px-2.5 py-1 text-xs font-medium"
          >
            My assigned tasks
          </button>
          <button
            type="button"
            (click)="savedFilter.set('team')"
            [class]="savedFilter() === 'team' ? 'border-[#1d70b8] bg-[#1d70b8]/10 text-[#1d70b8] dark:text-sky-300' : 'border-slate-300 text-slate-700 dark:border-slate-700 dark:text-slate-300'"
            class="whitespace-nowrap rounded border px-2.5 py-1 text-xs font-medium"
          >
            Departmental queue
          </button>
          <button
            type="button"
            (click)="savedFilter.set('urgent')"
            [class]="savedFilter() === 'urgent' ? 'border-[#1d70b8] bg-[#1d70b8]/10 text-[#1d70b8] dark:text-sky-300' : 'border-slate-300 text-slate-700 dark:border-slate-700 dark:text-slate-300'"
            class="whitespace-nowrap rounded border px-2.5 py-1 text-xs font-medium"
          >
            Urgent / Blocked
          </button>
        </div>

        <!-- Journey 5: Delegation / Escalation / Bulk Reassignment -->
        <div class="flex flex-wrap items-center gap-2">
          <label for="bulk-target" class="text-xs font-medium text-slate-600 dark:text-slate-300">Delegate / Escalate to:</label>
          <select
            id="bulk-target"
            [(ngModel)]="delegateTargetId"
            name="delegateTargetId"
            class="rounded border border-slate-300 bg-white px-2.5 py-1 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          >
            @for (emp of store.employees(); track emp.id) {
              <option [value]="emp.id">{{ emp.displayName }} ({{ emp.grade }})</option>
            }
          </select>
          <input
            type="text"
            [(ngModel)]="actionReason"
            name="actionReason"
            aria-label="Delegation or escalation reason"
            placeholder="Reason for cover or escalation"
            class="w-48 rounded border border-slate-300 bg-white px-2.5 py-1 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          />
        </div>
      </div>

      <!-- List / Team Queue View -->
      @if (viewMode() === 'list') {
        <div class="space-y-4">
          @for (task of filteredTasks(); track task.id) {
            <article class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <div class="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                <div class="min-w-0">
                  <div class="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                    <span class="font-mono font-semibold text-slate-800 dark:text-slate-200">{{ task.id }}</span>
                    <span aria-hidden="true">·</span>
                    <span>{{ task.accountableTeam }}</span>
                    <span aria-hidden="true">·</span>
                    <span>Handling: {{ task.handling }}</span>
                    @if (task.recurringCadence && task.recurringCadence !== 'None') {
                      <span aria-hidden="true">·</span>
                      <span>Recurring: {{ task.recurringCadence }}</span>
                    }
                    @if (task.originatingId) {
                      <span aria-hidden="true">·</span>
                      <span>Origin: {{ task.originatingType }} <span class="font-mono">{{ task.originatingId }}</span></span>
                    }
                  </div>

                  <h2 class="mt-1 text-base font-semibold text-slate-900 dark:text-slate-100">{{ task.title }}</h2>
                  <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">{{ task.description }}</p>

                  <p class="mt-2 text-xs text-slate-500 dark:text-slate-400">
                    Owner: <strong class="text-slate-800 dark:text-slate-200">{{ employeeName(task.ownerId) }}</strong>
                    @if (task.delegatedToId) {
                      <span> · Delegated cover: {{ employeeName(task.delegatedToId) }}</span>
                    }
                    @if (task.escalatedToId) {
                      <span class="text-red-700 dark:text-red-400"> · Escalated to {{ employeeName(task.escalatedToId) }}</span>
                    }
                    <span> · Due <span class="font-mono tabular-nums">{{ task.dueDate }}</span></span>
                    <span> · Priority: <strong>{{ task.priority }}</strong></span>
                  </p>
                </div>

                <div class="flex flex-wrap items-center gap-2 shrink-0">
                  <select
                    [ngModel]="task.status"
                    (ngModelChange)="store.updateTaskStatus(task.id, $event)"
                    [attr.aria-label]="'Status for ' + task.id"
                    class="rounded border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                  >
                    <option value="Backlog">Backlog</option>
                    <option value="In Progress">In Progress</option>
                    <option value="In Review">In Review</option>
                    <option value="Blocked">Blocked</option>
                    <option value="Done">Done</option>
                  </select>

                  <button
                    type="button"
                    (click)="store.delegateTaskAction(task.id, delegateTargetId, 'delegate', actionReason || 'Planned absence cover')"
                    class="whitespace-nowrap rounded border border-slate-300 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                  >
                    Delegate
                  </button>

                  <button
                    type="button"
                    (click)="store.delegateTaskAction(task.id, delegateTargetId, 'escalate', actionReason || 'SLA deadline approaching')"
                    class="whitespace-nowrap rounded border border-amber-400 px-2.5 py-1.5 text-xs font-medium text-amber-800 hover:bg-amber-50 dark:border-amber-700 dark:text-amber-300"
                  >
                    Escalate
                  </button>
                </div>
              </div>

              <!-- Checklist & Audit Trail -->
              <div class="mt-4 grid grid-cols-1 gap-4 border-t border-slate-100 pt-3 dark:border-slate-800 md:grid-cols-2">
                <div>
                  <p class="text-xs font-semibold text-slate-600 dark:text-slate-400">Checklist & dependencies</p>
                  <ul class="mt-2 space-y-1.5 text-xs">
                    @for (chk of task.checklist; track chk.id) {
                      <li>
                        <label class="inline-flex items-center gap-2 text-slate-700 dark:text-slate-300">
                          <input
                            type="checkbox"
                            [checked]="chk.completed"
                            (change)="store.toggleTaskChecklistItem(task.id, chk.id)"
                            class="h-3.5 w-3.5 rounded"
                          />
                          <span [class.line-through]="chk.completed">{{ chk.label }}</span>
                        </label>
                      </li>
                    }
                  </ul>
                  @if (task.dependencies.length > 0) {
                    <p class="mt-2 font-mono text-xs text-slate-500">Depends on: {{ task.dependencies.join(', ') }}</p>
                  }
                </div>

                <div>
                  <p class="text-xs font-semibold text-slate-600 dark:text-slate-400">Task audit trail</p>
                  <ul class="mt-2 space-y-1 text-xs text-slate-500 dark:text-slate-400">
                    @for (line of task.auditTrail.slice(0, 3); track line) {
                      <li class="font-mono">{{ line }}</li>
                    }
                  </ul>
                </div>
              </div>
            </article>
          }
        </div>
      }

      <!-- Kanban Board View -->
      @if (viewMode() === 'kanban') {
        <div class="grid grid-cols-1 gap-4 md:grid-cols-4">
          @for (col of kanbanColumns; track col) {
            <div class="rounded border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-900/60">
              <h2 class="border-b border-slate-200 pb-2 text-xs font-semibold uppercase tracking-wider text-slate-600 dark:border-slate-800 dark:text-slate-300">
                {{ col }} ({{ tasksByStatus(col).length }})
              </h2>
              <div class="mt-3 space-y-2.5">
                @for (t of tasksByStatus(col); track t.id) {
                  <div class="rounded border border-slate-200 bg-white p-3 text-xs dark:border-slate-800 dark:bg-slate-900">
                    <p class="font-mono text-[11px] text-slate-500">{{ t.id }} · {{ t.priority }}</p>
                    <p class="mt-1 font-medium text-slate-900 dark:text-slate-100">{{ t.title }}</p>
                    <p class="mt-1.5 text-slate-500 dark:text-slate-400">
                      {{ employeeName(t.ownerId) }} · Due {{ t.dueDate }}
                    </p>
                  </div>
                }
              </div>
            </div>
          }
        </div>
      }

      <!-- Timeline / Calendar View -->
      @if (viewMode() === 'timeline') {
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
            Deadline calendar & project timeline
          </h2>
          <div class="mt-4 overflow-x-auto">
            <table class="w-full text-left text-sm">
              <thead>
                <tr class="border-b border-slate-200 text-xs text-slate-500 dark:border-slate-800">
                  <th class="py-2 pr-4">Due / Escalation Date</th>
                  <th class="py-2 px-3">Task</th>
                  <th class="py-2 px-3">Origin</th>
                  <th class="py-2 px-3">Owner</th>
                  <th class="py-2 pl-3">Status</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
                @for (t of filteredTasks(); track t.id) {
                  <tr>
                    <td class="py-3 pr-4 font-mono text-xs tabular-nums">{{ t.dueDate }}</td>
                    <td class="py-3 px-3 font-medium text-slate-900 dark:text-slate-100">{{ t.title }}</td>
                    <td class="py-3 px-3 font-mono text-xs text-slate-500">{{ t.originatingType }} {{ t.originatingId }}</td>
                    <td class="py-3 px-3 text-xs">{{ employeeName(t.ownerId) }}</td>
                    <td class="py-3 pl-3 text-xs font-medium">{{ t.status }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </section>
      }
    </div>
  `,
})
export class TasksComponent {
  readonly store = inject(WorkspaceStore);

  readonly viewMode = signal<'list' | 'kanban' | 'timeline'>('list');
  readonly savedFilter = signal<'mine' | 'team' | 'urgent'>('team');
  delegateTargetId = 'emp-admin';
  actionReason = '';

  readonly viewModes = [
    { id: 'list' as const, label: 'Queue & list' },
    { id: 'kanban' as const, label: 'Kanban board' },
    { id: 'timeline' as const, label: 'Calendar & timeline' },
  ];

  readonly kanbanColumns: WorkspaceTask['status'][] = [
    'In Progress',
    'In Review',
    'Blocked',
    'Done',
  ];

  readonly filteredTasks = computed(() => {
    const uid = this.store.currentUser().id;
    const all = this.store.tasks();
    if (this.savedFilter() === 'mine') {
      return all.filter((t) => t.ownerId === uid || t.delegatedToId === uid);
    }
    if (this.savedFilter() === 'urgent') {
      return all.filter((t) => t.priority === 'Urgent' || t.status === 'Blocked');
    }
    return all;
  });

  tasksByStatus(status: WorkspaceTask['status']): WorkspaceTask[] {
    return this.filteredTasks().filter((t) => t.status === status);
  }

  employeeName(id: string): string {
    return this.store.employees().find((e) => e.id === id)?.displayName ?? id;
  }
}
