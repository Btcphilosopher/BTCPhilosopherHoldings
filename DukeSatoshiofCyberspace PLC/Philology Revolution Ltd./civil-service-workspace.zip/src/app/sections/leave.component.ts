import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { calculateLeaveBooking, UK_PUBLIC_HOLIDAYS } from '../../domain/leave-calculator';
import { LeaveRequest, UkRegion } from '../../domain/models';
import { WorkspaceStore } from '../core/workspace.store';

@Component({
  selector: 'app-leave',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-8">
      <div class="border-b border-slate-200 pb-5 dark:border-slate-800">
        <h1 class="text-2xl font-semibold text-slate-900 dark:text-slate-100">Leave & attendance</h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">
          Configured for {{ store.currentDepartment().name }} · Standard week {{ store.currentDepartment().standardWeeklyHours }}h · Timesheets {{ store.currentDepartment().timesheetsRequired ? 'Required' : 'Not required (Flexi-tracked)' }}
        </p>
      </div>

      <!-- Balances & Working Pattern Cards -->
      <section class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p class="text-xs font-medium text-slate-500 dark:text-slate-400">Annual entitlement ({{ store.currentLeaveBalance().leaveYear }})</p>
          <p class="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-900 dark:text-slate-100">
            {{ store.currentLeaveBalance().annualEntitlementDays + store.currentLeaveBalance().carriedOverDays }} days
          </p>
          <p class="mt-1 text-xs text-slate-600 dark:text-slate-400 tabular-nums">
            Base {{ store.currentLeaveBalance().annualEntitlementDays }}d + {{ store.currentLeaveBalance().carriedOverDays }}d carried over
          </p>
        </div>

        <div class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p class="text-xs font-medium text-slate-500 dark:text-slate-400">Remaining available</p>
          <p class="mt-2 font-mono text-2xl font-semibold tabular-nums text-[#00703c] dark:text-emerald-400">
            {{ availableDays() }} days
          </p>
          <p class="mt-1 text-xs text-slate-600 dark:text-slate-400 tabular-nums">
            {{ store.currentLeaveBalance().takenDays }}d taken · {{ store.currentLeaveBalance().pendingDays }}d pending
          </p>
        </div>

        <div class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p class="text-xs font-medium text-slate-500 dark:text-slate-400">Flexitime & TOIL</p>
          <p class="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-900 dark:text-slate-100">
            +{{ store.currentLeaveBalance().flexiHoursBalance }}h / {{ store.currentLeaveBalance().toilHoursBalance }}h
          </p>
          <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">
            Flexi credit · Time off in lieu
          </p>
        </div>

        <div class="rounded border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p class="text-xs font-medium text-slate-500 dark:text-slate-400">Regional public holiday calendar</p>
          <p class="mt-2 text-base font-semibold text-slate-900 dark:text-slate-100">
            {{ regionLabel(selectedRegion()) }}
          </p>
          <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">
            Next holiday: {{ nextPublicHoliday() }}
          </p>
        </div>
      </section>

      <!-- Save-and-Resume Leave Request Form + Live Calculator -->
      <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 lg:col-span-2">
          <div class="flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
            <h2 class="text-base font-semibold text-slate-900 dark:text-slate-100">
              Request leave or record absence
            </h2>
            <span class="text-xs text-slate-500 dark:text-slate-400">Save-and-resume active</span>
          </div>

          @if (formErrors().length > 0) {
            <div role="alert" aria-live="polite" class="mt-4 rounded border border-red-300 bg-red-50 p-4 text-sm text-red-900 dark:border-red-800 dark:bg-red-950/50 dark:text-red-200">
              <p class="font-semibold">There is a problem with your leave request</p>
              <ul class="mt-1.5 list-disc pl-5 text-xs space-y-1">
                @for (err of formErrors(); track err) {
                  <li>{{ err }}</li>
                }
              </ul>
            </div>
          }

          <form (ngSubmit)="submitLeave()" class="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label for="lv-type" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Leave / absence type</label>
              <select
                id="lv-type"
                name="leaveType"
                [ngModel]="leaveType()"
                (ngModelChange)="leaveType.set($event); syncDraft()"
                class="mt-1 w-full rounded border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                <option value="Annual leave">Annual leave</option>
                <option value="Flexi leave">Flexi leave</option>
                <option value="Time off in lieu (TOIL)">Time off in lieu (TOIL)</option>
                <option value="Sickness absence">Sickness absence (Medical confidential)</option>
                <option value="Parental leave">Parental & family leave</option>
                <option value="Special leave">Special leave</option>
              </select>
            </div>

            <div>
              <label for="lv-region" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Regional bank holiday calendar</label>
              <select
                id="lv-region"
                name="region"
                [ngModel]="selectedRegion()"
                (ngModelChange)="selectedRegion.set($event); syncDraft()"
                class="mt-1 w-full rounded border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                <option value="england-wales">England & Wales</option>
                <option value="scotland">Scotland</option>
                <option value="northern-ireland">Northern Ireland</option>
              </select>
            </div>

            <div>
              <label for="lv-start" class="block text-xs font-medium text-slate-700 dark:text-slate-300">Start date</label>
              <input
                id="lv-start"
                name="startDate"
                type="date"
                [ngModel]="startDate()"
                (ngModelChange)="startDate.set($event); syncDraft()"
                class="mt-1 w-full rounded border border-slate-300 bg-white px-3 py-2 font-mono text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label for="lv-end" class="block text-xs font-medium text-slate-700 dark:text-slate-300">End date</label>
              <input
                id="lv-end"
                name="endDate"
                type="date"
                [ngModel]="endDate()"
                (ngModelChange)="endDate.set($event); syncDraft()"
                class="mt-1 w-full rounded border border-slate-300 bg-white px-3 py-2 font-mono text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div class="sm:col-span-2 flex flex-wrap items-center gap-6">
              <label class="inline-flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
                <input
                  type="checkbox"
                  [ngModel]="halfDay()"
                  (ngModelChange)="halfDay.set($event); syncDraft()"
                  name="halfDay"
                  class="h-4 w-4 rounded border-slate-300"
                />
                Half-day booking (0.5 working day)
              </label>

              <label class="inline-flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
                <input
                  type="checkbox"
                  [ngModel]="isMedicalConfidential()"
                  (ngModelChange)="isMedicalConfidential.set($event); syncDraft()"
                  name="isMedicalConfidential"
                  class="h-4 w-4 rounded border-slate-300"
                />
                Restrict reason on shared team calendars
              </label>
            </div>

            <div class="sm:col-span-2">
              <label for="lv-note" class="block text-xs font-medium text-slate-700 dark:text-slate-300">
                Handover & cover notes (visible to approver only)
              </label>
              <textarea
                id="lv-note"
                name="reasonNote"
                rows="2"
                [ngModel]="reasonNote()"
                (ngModelChange)="reasonNote.set($event); syncDraft()"
                placeholder="Identify cover arrangements or handover notes..."
                class="mt-1 w-full rounded border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              ></textarea>
            </div>

            <!-- Live Calculation Summary -->
            <div class="sm:col-span-2 rounded border border-slate-200 bg-slate-50 p-4 text-xs dark:border-slate-800 dark:bg-slate-800/50">
              <div class="flex flex-wrap items-center justify-between gap-2">
                <span class="font-medium text-slate-700 dark:text-slate-200">
                  Calculated deduction:
                  <strong class="font-mono tabular-nums text-slate-900 dark:text-white">{{ liveCalc().workingDays }} working days</strong>
                  (Remaining after approval: <span class="font-mono tabular-nums">{{ liveCalc().remainingAfterRequest }}d</span>)
                </span>
                @if (liveCalc().excludedBankHolidays.length > 0) {
                  <span class="text-slate-600 dark:text-slate-300">
                    Excluded public holiday(s): {{ excludedHolidayNames() }}
                  </span>
                }
              </div>
              <p class="mt-1.5 text-slate-600 dark:text-slate-300">{{ liveCalc().approvalExplanation }}</p>
            </div>

            <div class="sm:col-span-2 flex items-center gap-3">
              <button
                type="submit"
                class="rounded bg-[#1d70b8] px-4 py-2 text-sm font-medium text-white hover:bg-[#003078]"
              >
                Submit leave request
              </button>
              <button
                type="button"
                (click)="syncDraft(true)"
                class="rounded border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                Save draft for later
              </button>
            </div>
          </form>
        </section>

        <!-- Privacy-Preserving Team Availability Calendar -->
        <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 class="border-b border-slate-200 pb-3 text-base font-semibold text-slate-900 dark:border-slate-800 dark:text-slate-100">
            Team availability calendar
          </h2>
          <p class="mt-2 text-xs text-slate-600 dark:text-slate-400">
            Displays team availability only. Confidential medical and special-leave reasons are never shown.
          </p>
          <ul class="mt-4 space-y-3 text-sm">
            @for (entry of store.teamAvailability(); track entry.employeeName + entry.startDate) {
              <li class="border-b border-slate-100 pb-3 last:border-b-0 dark:border-slate-800">
                <p class="font-medium text-slate-900 dark:text-slate-100">{{ entry.employeeName }}</p>
                <p class="mt-0.5 font-mono text-xs tabular-nums text-slate-600 dark:text-slate-300">
                  {{ entry.startDate }} to {{ entry.endDate }}
                </p>
                <p class="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  {{ entry.availabilityLabel }} · {{ entry.status }}
                </p>
              </li>
            }
          </ul>
        </section>
      </div>

      <!-- Leave Requests Ledger (Journey 1 Employee-to-Manager End-to-End) -->
      <section class="rounded border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <div class="flex flex-col gap-3 border-b border-slate-200 pb-3 dark:border-slate-800 sm:flex-row sm:items-center sm:justify-between">
          <h2 class="text-base font-semibold text-slate-900 dark:text-slate-100">
            Leave requests & approval history
          </h2>
          <div class="flex items-center gap-1 rounded bg-slate-100 p-1 dark:bg-slate-800">
            <button
              type="button"
              (click)="statusFilter.set('all')"
              [class]="statusFilter() === 'all' ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-900 dark:text-white' : 'text-slate-600 dark:text-slate-300'"
              class="whitespace-nowrap rounded px-3 py-1 text-xs font-medium"
            >
              All
            </button>
            <button
              type="button"
              (click)="statusFilter.set('pending')"
              [class]="statusFilter() === 'pending' ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-900 dark:text-white' : 'text-slate-600 dark:text-slate-300'"
              class="whitespace-nowrap rounded px-3 py-1 text-xs font-medium"
            >
              Awaiting review
            </button>
          </div>
        </div>

        <div class="mt-4 overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead>
              <tr class="border-b border-slate-200 text-xs font-medium text-slate-500 dark:border-slate-800 dark:text-slate-400">
                <th class="py-2.5 pr-3">ID</th>
                <th class="py-2.5 px-3">Staff Member</th>
                <th class="py-2.5 px-3">Type & Rule</th>
                <th class="py-2.5 px-3">Dates</th>
                <th class="py-2.5 px-3 text-right">Days</th>
                <th class="py-2.5 px-3">Status & Reason</th>
                <th class="py-2.5 pl-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
              @for (req of filteredRequests(); track req.id) {
                <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td class="py-3 pr-3 font-mono text-xs">{{ req.id }}</td>
                  <td class="py-3 px-3 font-medium text-slate-900 dark:text-slate-100">
                    {{ employeeName(req.employeeId) }}
                  </td>
                  <td class="py-3 px-3">
                    <p class="text-slate-900 dark:text-slate-100">
                      {{ req.isMedicalConfidential && req.employeeId !== store.currentUser().id && store.currentUser().demoRole !== 'hr_adviser' ? 'Restricted Absence' : req.leaveType }}
                    </p>
                    <p class="font-mono text-xs text-slate-500">{{ req.ruleVersion }}</p>
                  </td>
                  <td class="py-3 px-3 font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                    {{ req.startDate }} → {{ req.endDate }}
                  </td>
                  <td class="py-3 px-3 text-right font-mono tabular-nums">{{ req.workingDays }}</td>
                  <td class="py-3 px-3">
                    <p class="font-medium text-slate-900 dark:text-slate-100">{{ req.status }}</p>
                    @if (req.decisionReason) {
                      <p class="text-xs text-slate-500 dark:text-slate-400">{{ req.decisionReason }}</p>
                    }
                  </td>
                  <td class="py-3 pl-3 text-right">
                    <div class="inline-flex flex-wrap justify-end gap-1.5">
                      @if (req.status === 'Manager review' && req.employeeId !== store.currentUser().id && (req.approverId === store.currentUser().id || store.currentUser().demoRole === 'dept_admin')) {
                        <button
                          type="button"
                          (click)="store.actOnLeaveRequest(req.id, 'approve', 'Approved within team cover limits')"
                          class="whitespace-nowrap rounded bg-[#00703c] px-2.5 py-1 text-xs font-medium text-white hover:bg-[#005a30]"
                        >
                          Approve
                        </button>
                        <button
                          type="button"
                          (click)="store.actOnLeaveRequest(req.id, 'return', 'Please confirm handover owner before re-submitting')"
                          class="whitespace-nowrap rounded border border-amber-400 px-2.5 py-1 text-xs font-medium text-amber-800 hover:bg-amber-50 dark:border-amber-700 dark:text-amber-300"
                        >
                          Return
                        </button>
                        <button
                          type="button"
                          (click)="store.actOnLeaveRequest(req.id, 'reject', 'Insufficient operational cover during window')"
                          class="whitespace-nowrap rounded border border-red-300 px-2.5 py-1 text-xs font-medium text-red-700 hover:bg-red-50 dark:border-red-800 dark:text-red-400"
                        >
                          Reject
                        </button>
                      }
                      @if (req.employeeId === store.currentUser().id && !['Approved', 'Rejected', 'Withdrawn'].includes(req.status)) {
                        <button
                          type="button"
                          (click)="store.actOnLeaveRequest(req.id, 'withdraw', 'Withdrawn by requester')"
                          class="whitespace-nowrap rounded border border-slate-300 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200"
                        >
                          Withdraw
                        </button>
                      }
                    </div>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `,
})
export class LeaveComponent {
  readonly store = inject(WorkspaceStore);

  readonly leaveType = signal<LeaveRequest['leaveType']>(this.store.leaveDraft().leaveType);
  readonly startDate = signal(this.store.leaveDraft().startDate);
  readonly endDate = signal(this.store.leaveDraft().endDate);
  readonly halfDay = signal(this.store.leaveDraft().halfDay);
  readonly selectedRegion = signal<UkRegion>(this.store.currentUser().region);
  readonly reasonNote = signal(this.store.leaveDraft().reasonNote);
  readonly isMedicalConfidential = signal(this.store.leaveDraft().isMedicalConfidential);
  readonly formErrors = signal<string[]>([]);
  readonly statusFilter = signal<'all' | 'pending'>('all');

  readonly availableDays = computed(() => {
    const b = this.store.currentLeaveBalance();
    return b.annualEntitlementDays + b.carriedOverDays - b.takenDays - b.pendingDays;
  });

  readonly liveCalc = computed(() => {
    const actor = this.store.currentUser();
    return calculateLeaveBooking({
      startDate: this.startDate(),
      endDate: this.endDate(),
      halfDay: this.halfDay(),
      region: this.selectedRegion(),
      leaveType: this.leaveType(),
      balance: this.store.currentLeaveBalance(),
      existingRequests: this.store.leaveRequests().filter((r) => r.employeeId === actor.id),
      department: this.store.currentDepartment(),
    });
  });

  readonly excludedHolidayNames = computed(() =>
    this.liveCalc()
      .excludedBankHolidays.map((h) => `${h.name} (${h.date})`)
      .join(', '),
  );

  readonly filteredRequests = computed(() => {
    const actor = this.store.currentUser();
    const list = this.store.leaveRequests().filter((r) => {
      if (actor.demoRole === 'employee') return r.employeeId === actor.id;
      return true;
    });
    if (this.statusFilter() === 'pending') {
      return list.filter((r) => ['Submitted', 'Manager review'].includes(r.status));
    }
    return list;
  });

  syncDraft(showConfirmation = false): void {
    this.store.leaveDraft.set({
      leaveType: this.leaveType(),
      startDate: this.startDate(),
      endDate: this.endDate(),
      halfDay: this.halfDay(),
      region: this.selectedRegion(),
      reasonNote: this.reasonNote(),
      isMedicalConfidential: this.isMedicalConfidential(),
    });
    if (showConfirmation) {
      this.store.notify('info', 'Leave request draft saved. You may resume from any section.');
    }
  }

  submitLeave(): void {
    const res = this.store.submitLeaveRequest({
      leaveType: this.leaveType(),
      startDate: this.startDate(),
      endDate: this.endDate(),
      halfDay: this.halfDay(),
      region: this.selectedRegion(),
      reasonNote: this.reasonNote(),
      isMedicalConfidential: this.isMedicalConfidential(),
    });
    this.formErrors.set(res.errors);
    if (res.ok) {
      this.reasonNote.set('');
      this.syncDraft();
    }
  }

  regionLabel(r: UkRegion): string {
    return r === 'scotland'
      ? 'Scotland'
      : r === 'northern-ireland'
        ? 'Northern Ireland'
        : 'England & Wales';
  }

  nextPublicHoliday(): string {
    const reg = this.selectedRegion();
    const upcoming = UK_PUBLIC_HOLIDAYS.find((h) => h.date >= '2026-11-21' && h.regions.includes(reg));
    return upcoming ? `${upcoming.name} (${upcoming.date})` : 'New Year’s Day (2027-01-01)';
  }

  employeeName(id: string): string {
    return this.store.employees().find((e) => e.id === id)?.displayName ?? id;
  }
}
