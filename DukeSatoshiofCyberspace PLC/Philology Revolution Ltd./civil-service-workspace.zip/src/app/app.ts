import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DemoRoleId } from '../domain/models';
import { canAccessSection, NavSectionId, ROLE_MATRIX } from '../domain/permissions';
import { WorkspaceStore } from './core/workspace.store';
import { ApprovalsComponent } from './sections/approvals.component';
import { EmploymentComponent } from './sections/employment.component';
import { HomeDashboardComponent } from './sections/home-dashboard.component';
import { HrCaseworkComponent } from './sections/hr-casework.component';
import { LearningComponent } from './sections/learning.component';
import { LeaveComponent } from './sections/leave.component';
import { PayExpensesComponent } from './sections/pay-expenses.component';
import { PeopleComponent } from './sections/people.component';
import { PoliciesComponent } from './sections/policies.component';
import { ReportingGovernanceComponent } from './sections/reporting-governance.component';
import { ServicesComponent } from './sections/services.component';
import { TasksComponent } from './sections/tasks.component';

interface NavItem {
  id: NavSectionId;
  label: string;
  group: 'core' | 'authorised';
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    FormsModule,
    HomeDashboardComponent,
    EmploymentComponent,
    LeaveComponent,
    PayExpensesComponent,
    TasksComponent,
    ApprovalsComponent,
    LearningComponent,
    PeopleComponent,
    ServicesComponent,
    PoliciesComponent,
    HrCaseworkComponent,
    ReportingGovernanceComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly store = inject(WorkspaceStore);
  readonly mobileMenuOpen = signal(false);

  readonly navItems: NavItem[] = [
    { id: 'workspace', label: 'My workspace', group: 'core' },
    { id: 'employment', label: 'My employment', group: 'core' },
    { id: 'leave', label: 'Leave & attendance', group: 'core' },
    { id: 'pay-expenses', label: 'Pay & expenses', group: 'core' },
    { id: 'tasks', label: 'Tasks & projects', group: 'core' },
    { id: 'approvals', label: 'Approvals', group: 'core' },
    { id: 'learning', label: 'Learning & development', group: 'core' },
    { id: 'people', label: 'People & teams', group: 'core' },
    { id: 'services', label: 'Help & services', group: 'core' },
    { id: 'policies', label: 'Policies & knowledge', group: 'core' },
    { id: 'hr-casework', label: 'HR casework', group: 'authorised' },
    { id: 'reporting', label: 'Management reporting', group: 'authorised' },
    { id: 'governance', label: 'Integrations & governance', group: 'authorised' },
  ];

  readonly coreNav = computed(() =>
    this.navItems.filter(
      (i) => i.group === 'core' && canAccessSection(this.store.currentUser().demoRole, i.id),
    ),
  );

  readonly authorisedNav = computed(() =>
    this.navItems.filter(
      (i) => i.group === 'authorised' && canAccessSection(this.store.currentUser().demoRole, i.id),
    ),
  );

  readonly allRoles = (Object.keys(ROLE_MATRIX) as DemoRoleId[]).map((id) => ({
    id,
    label: ROLE_MATRIX[id].label,
  }));

  readonly activeLabel = computed(
    () => this.navItems.find((i) => i.id === this.store.activeSection())?.label ?? 'My workspace',
  );

  selectSection(id: NavSectionId): void {
    this.store.navigate(id);
    this.mobileMenuOpen.set(false);
  }

  onRoleChange(role: DemoRoleId): void {
    this.store.switchDemoRole(role);
  }
}
