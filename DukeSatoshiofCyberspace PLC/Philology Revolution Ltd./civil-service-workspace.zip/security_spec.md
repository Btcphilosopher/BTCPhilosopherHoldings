# Security Specification & Hardened Firestore Rules Verification

## 1. Data Invariants
1. **Default-Deny Baseline**: Every unrecognised collection and operation defaults to `false`.
2. **PII Isolation**: Sensitive employee fields (`workEmail`, `personalPhone`, `homeAddress`, `emergencyContact*`, `bankAccountMasked`) reside strictly under `/users/{userId}/private/{docId}`, readable and writable only by `userId == request.auth.uid` or verified admins.
3. **Self-Approval Prevention**: In `/requests/{requestId}`, `approverUid` MUST NOT equal `requesterUid` during creation, and a requester cannot transition their own request to `Approved`, `Paid`, or `Completed`.
4. **Sensitive Case Isolation**: In `/hrCases/{caseId}`, only `subjectUid`, explicitly named `assignedAdviserUid`, or verified HR/system admins can read or update the record. Line managers have zero implicit access.
5. **Immutable Audit Trail**: `/auditLogs/{logId}` is strictly append-only (`allow update, delete: if false;`) and requires `actorUid == request.auth.uid` and `createdAt == request.time`.
6. **Verified Identity**: All authenticated writes require `request.auth != null && request.auth.token.email_verified == true`.
7. **Terminal State Locking**: Requests in terminal states (`Paid`, `Completed`, `Withdrawn`, `Rejected`) cannot be mutated by standard users.

## 2. The "Dirty Dozen" Adversarial Payloads (Must All Return `PERMISSION_DENIED`)
1. **Unauthenticated Read**: `GET /requests/req-1` with `auth: null`.
2. **Unverified Email Write**: `CREATE /requests/req-2` with `email_verified: false`.
3. **Self-Approval Attempt**: `CREATE /requests/req-3` where `requesterUid == approverUid == auth.uid`.
4. **Requester Approving Own Request**: `UPDATE /requests/req-1` by `requesterUid` changing `status` to `Approved`.
5. **Shadow / Ghost Field Injection**: `CREATE /requests/req-4` containing valid keys plus `isAdminApproved: true`.
6. **Line Manager Snooping Restricted Case**: `GET /hrCases/case-1` by a user who is neither `subjectUid` nor `assignedAdviserUid` nor admin.
7. **PII Cross-User Read**: `GET /users/user-a/private/info` by `user-b`.
8. **ID Poisoning**: `CREATE /tasks/${'a'.repeat(300)}` exceeding `isValidId` 128-char regex guard.
9. **Forged Timestamp**: `CREATE /requests/req-5` where `createdAt` is a client-backdated timestamp (`!= request.time`).
10. **Audit Log Tampering**: `UPDATE` or `DELETE /auditLogs/log-1` by any user, including admins.
11. **Blanket List Scraping**: `LIST /hrCases` without `subjectUid == auth.uid` or `assignedAdviserUid == auth.uid` constraint.
12. **Terminal State Mutation**: `UPDATE /requests/req-paid` (status `Paid`) by requester changing `status` back to `Submitted`.
