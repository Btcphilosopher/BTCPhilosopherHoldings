# Civil Service Workspace — Architecture, Permissions, Workflows & Setup

> **Independent Product Concept Notice**: This application uses synthetic employees and clearly labelled sample policies. It does not imply official UK Government or Civil Service endorsement, and is not assessed for classified information without a separate operating model and accreditation.

---

## 1. Demonstration Accounts & Role Switcher
The workspace starts in **Synthetic Demonstration Mode** (no login wall required) and provides a role switcher in the top toolbar covering all 7 demonstration roles, plus optional live **Google Sign-In** via Firebase Auth:

| Role ID | Demonstration User | Grade & Department | Key Permissions |
| :--- | :--- | :--- | :--- |
| `employee` | Hannah Patel | SEO · Digital Delivery (DDD) | Self-service employment, leave, expenses, tasks, service catalogue, own HR cases |
| `line_manager` | David Thornton | Grade 7 · Digital Delivery (DDD) | Direct-report approvals, team availability (no medical details), bulk task reassignment; **blocked** from restricted HR cases |
| `hr_adviser` | Fiona MacLeod | SEO · Employee Relations | Assigned HR cases, onboarding/leaver orchestration, bank/PII verification |
| `finance_officer` | Nadia Okafor | HEO · Corporate Finance | Expense compliance review, BACS payment dispatch & failure retry recovery |
| `it_agent` | Owen Gallagher | EO · Regulatory Ops (HMRO) | ITSM fulfilment, equipment/access provisioning, onboarding workstation build |
| `dept_admin` | Priya Subramanian | Grade 6 · Platform Governance | Rules & integrations governance, audit logs, 4-hour break-glass requests; **no automatic personnel PII access** |
| `auditor` | Gareth Davies | Grade 7 · Internal Audit | Read-only assurance access to audit trail, reporting, permission matrix, and rules |

---

## 2. Permission Matrix Summary
- **Separation of Duties**: Requesters can never approve, return, or reject their own leave, expenses, equipment, or personal-change requests (`SELF_APPROVAL_FORBIDDEN`).
- **Sensitive Case Isolation**: Restricted HR cases (`hrCases`) are visible only to the subject employee, the assigned HR Adviser, or an explicit 4-hour audited Break-Glass grant. Line managers and technical administrators have zero automatic access.
- **Small-Group Suppression**: Sensitive absence/case reports suppress cohorts with `1 <= count < 5` to prevent individual identification.
- **Tamper-Evident Audit Chain**: Every action and access denial appends a hash-chained `AuditLogEntry` (`prevHash` -> `hash`).

---

## 3. Core Workflow Diagrams

### Leave Request Workflow (`LEAVE-RULE-v2.1`)
```
[Employee Draft] -> (Validate Dates, Regional Bank Holidays, Overlap & Balance)
       |
       v
[Manager review] ---> [Approved] (Deducts balance; Calendar syncs availability only)
       |-----------> [Returned for correction] -> [Resubmit]
       |-----------> [Rejected] / [Withdrawn]
```

### Expense Claim Lifecycle (`EXPENSE-RULE-v3.1`)
```
[Draft] -> [Submitted / Manager review] -> [Finance review] -> (Payroll BACS Adapter)
                   |                              |                    |
                   v                              v                    +--> [Paid]
       [Returned for correction]              [Rejected]               +--> [Payment failed] -> (Idempotent Retry) -> [Paid]
```

### Onboarding Orchestration
```
Offer accepted -> Baseline vetting (Restricted status only) -> HRIS record
  -> Encrypted laptop build (IT) -> IdP / Pass provisioning (Facilities)
  -> Day-1 induction (Manager) -> Mandatory learning -> Probation milestones
```

---

## 4. API Documentation (Web & Future Kotlin Client Parity)
- `GET /api/health` — Readiness check.
- `GET /api/docs` — Machine-readable OpenAPI-style specification and adapter catalogue.
- `POST /api/workflows/evaluate-leave` — Server-authoritative leave day, UK regional bank holiday, balance, and overlap validator.
- `POST /api/integrations/dispatch` — Idempotency-keyed downstream integration dispatcher (`hris`, `payroll`, `idp`, `calendar`, `learning`, `finance`, `itsm`, `records`).
- `POST /api/assistant/query` — Disabled-by-default Gemini (`gemini-4-hydrogen`) Policy Assistant enforcing permission-aware retrieval, citations, and effective dates.

---

## 5. Setup & Verification Instructions
1. Install dependencies: `npm install`
2. Configure environment variables: set `GEMINI_API_KEY` in Settings > Secrets (see `.env.example`).
3. Run development server: `npm run dev` (serves on port `3000`).
4. Run security & workflow tests: `npx vitest run src/domain/workspace.spec.ts firestore.rules.test.ts`
5. Lint code and Firestore security rules: `npm run lint`
6. Production build: `npm run build`
