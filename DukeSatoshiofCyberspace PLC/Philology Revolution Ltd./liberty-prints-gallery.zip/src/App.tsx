import { useState, useEffect, useMemo } from "react";
import { Product, ProductFrame, ProductSize, CartItem } from "./types";
import { PRODUCTS, COLLECTIONS } from "./data/products";

// Components
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Collections from "./components/Collections";
import GalleryExplorer from "./components/GalleryExplorer";
import ProductDetailModal from "./components/ProductDetailModal";
import CartDrawer from "./components/CartDrawer";
import WishlistDrawer from "./components/WishlistDrawer";
import CheckoutModal from "./components/CheckoutModal";
import AdditionalSections from "./components/AdditionalSections";
import Footer from "./components/Footer";

// Animations
import { AnimatePresence } from "motion/react";

export default function App() {
  // --- STATE DECLARATIONS ---
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [currency, setCurrency] = useState<"USD" | "EUR" | "GBP">("USD");
  
  // Drawer & Modal Triggers
  const [cartOpen, setCartOpen] = useState(false);
  const [wishlistOpen, setWishlistOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [detailProduct, setDetailProduct] = useState<Product | null>(null);

  // Cart & Wishlist persistence with LocalStorage
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem("liberty_prints_cart");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem("liberty_prints_wishlist");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Discount / Promo management
  const [discountCode, setDiscountCode] = useState("");
  const [discountAmount, setDiscountAmount] = useState(0); // percentage

  // --- SYNC LOCAL STORAGE ---
  useEffect(() => {
    localStorage.setItem("liberty_prints_cart", JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem("liberty_prints_wishlist", JSON.stringify(wishlist));
  }, [wishlist]);

  // --- CURRENCY CONVERSION CONFIG ---
  const currencyMeta = useMemo(() => {
    switch (currency) {
      case "EUR":
        return { symbol: "€", rate: 0.92 };
      case "GBP":
        return { symbol: "£", rate: 0.78 };
      case "USD":
      default:
        return { symbol: "$", rate: 1.0 };
    }
  }, [currency]);

  // --- E-COMMERCE CALLBACKS ---
  const handleAddToCart = (product: Product, size: ProductSize, frame: ProductFrame) => {
    const itemUniqueId = `${product.id}-${size.id}-${frame.id}`;

    setCart((prevCart) => {
      const existingIdx = prevCart.findIndex((i) => i.id === itemUniqueId);
      if (existingIdx > -1) {
        const updated = [...prevCart];
        updated[existingIdx].quantity += 1;
        return updated;
      } else {
        return [...prevCart, { id: itemUniqueId, product, selectedSize: size, selectedFrame: frame, quantity: 1 }];
      }
    });

    // Automatically open the cart drawer to delight client
    setCartOpen(true);
    // Close detail modal if open
    setDetailProduct(null);
  };

  const handleUpdateCartQuantity = (itemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveCartItem(itemId);
      return;
    }
    setCart((prevCart) =>
      prevCart.map((i) => (i.id === itemId ? { ...i, quantity: newQuantity } : i))
    );
  };

  const handleRemoveCartItem = (itemId: string) => {
    setCart((prevCart) => prevCart.filter((i) => i.id !== itemId));
  };

  const handleToggleWishlist = (product: Product) => {
    setWishlist((prevWishlist) => {
      const exists = prevWishlist.some((p) => p.id === product.id);
      if (exists) {
        return prevWishlist.filter((p) => p.id !== product.id);
      } else {
        return [...prevWishlist, product];
      }
    });
  };

  const handleApplyDiscount = (code: string) => {
    const formatted = code.trim().toUpperCase();
    if (formatted === "MUSEUM20") {
      setDiscountAmount(20);
    } else if (formatted === "COCURATOR") {
      setDiscountAmount(15);
    } else if (formatted === "LIBERTY") {
      setDiscountAmount(10);
    } else {
      setDiscountAmount(0);
    }
  };

  const handleClearCart = () => {
    setCart([]);
    setDiscountAmount(0);
    setDiscountCode("");
  };

  // --- SMOOTH WINDOW ELEMENT SCROLLS ---
  const handleScrollToSection = (elementId: string) => {
    const element = document.getElementById(elementId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="bg-[#081826] min-h-screen relative overflow-x-hidden selection:bg-[#D8A33A]/30 selection:text-[#F8F4EE] text-[#F8F4EE]">
      {/* 1. GLOBAL AMBIENT LAYERED GRADIENTS BACKGROUNDS */}
      <div className="absolute top-0 left-0 w-full h-[150vh] bg-gradient-to-b from-[#081826] via-[#081826] to-[#081826] -z-20" />
      <div className="absolute top-[80px] left-[5%] w-[45vw] h-[45vw] rounded-full glow-spot-gold pointer-events-none -z-10" />

      {/* 2. STICKY NAV REVOLVING NAVIGATION HEADER */}
      <Navbar
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        wishlistCount={wishlist.length}
        onOpenCart={() => setCartOpen(true)}
        onOpenWishlist={() => setWishlistOpen(true)}
        currency={currency}
        onCurrencyChange={setCurrency}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSelectCategory={setSelectedCategory}
        collections={COLLECTIONS}
        onScrollToSection={handleScrollToSection}
      />

      {/* 3. CORE EDITORIAL SECTIONS CHANNELS */}
      <main className="space-y-0">
        {/* Cinema Hero Showcase */}
        <Hero
          onExploreClick={() => handleScrollToSection("gallery")}
          onAboutClick={() => handleScrollToSection("about")}
        />

        {/* Collections Series Grid */}
        <Collections
          collections={COLLECTIONS}
          onSelectCategory={setSelectedCategory}
          onScrollToSection={handleScrollToSection}
        />

        {/* Main Gallery Explorer & Filters Grid */}
        <GalleryExplorer
          wishlist={wishlist}
          currencySymbol={currencyMeta.symbol}
          currencyRate={currencyMeta.rate}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          onViewProductDetails={setDetailProduct}
          onToggleWishlist={handleToggleWishlist}
        />

        {/* Detailed Material Spec, Testimonials, FAQS & Trade Consultation */}
        <AdditionalSections />
      </main>

      {/* 4. PREMIUM FOOTER */}
      <Footer
        onScrollToSection={handleScrollToSection}
        onSelectCategory={setSelectedCategory}
      />

      {/* --- DRAWERS & MODALS ANCHORS --- */}
      <AnimatePresence>
        {/* Dynamic Frame Detail view Modal */}
        {detailProduct && (
          <ProductDetailModal
            product={detailProduct}
            isOpen={true}
            onClose={() => setDetailProduct(null)}
            onAddToCart={handleAddToCart}
            onToggleWishlist={handleToggleWishlist}
            isWishlisted={wishlist.some((w) => w.id === detailProduct.id)}
            currencySymbol={currencyMeta.symbol}
            currencyRate={currencyMeta.rate}
            onViewProduct={setDetailProduct}
          />
        )}

        {/* Curator Shopping Cart Drawer */}
        {cartOpen && (
          <CartDrawer
            isOpen={true}
            onClose={() => setCartOpen(false)}
            cart={cart}
            currency={currency}
            currencySymbol={currencyMeta.symbol}
            currencyRate={currencyMeta.rate}
            onUpdateQuantity={handleUpdateCartQuantity}
            onRemoveItem={handleRemoveCartItem}
            discountCode={discountCode}
            setDiscountCode={setDiscountCode}
            discountAmount={discountAmount}
            onApplyDiscount={handleApplyDiscount}
            onCheckout={() => {
              setCartOpen(false);
              setCheckoutOpen(true);
            }}
          />
        )}

        {/* Curator Wishlist Saved Drawer */}
        {wishlistOpen && (
          <WishlistDrawer
            isOpen={true}
            onClose={() => setWishlistOpen(false)}
            wishlist={wishlist}
            onRemoveFromWishlist={handleToggleWishlist}
            onViewProduct={setDetailProduct}
            currencySymbol={currencyMeta.symbol}
            currencyRate={currencyMeta.rate}
          />
        )}

        {/* Secured Premium Checkout Gate Modal */}
        {checkoutOpen && (
          <CheckoutModal
            isOpen={true}
            onClose={() => setCheckoutOpen(false)}
            cart={cart}
            currencySymbol={currencyMeta.symbol}
            currencyRate={currencyMeta.rate}
            discountAmount={discountAmount}
            onClearCart={handleClearCart}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
