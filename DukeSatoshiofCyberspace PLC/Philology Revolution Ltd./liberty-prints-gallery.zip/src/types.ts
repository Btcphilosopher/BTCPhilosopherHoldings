export interface Review {
  id: string;
  userName: string;
  rating: number;
  date: string;
  comment: string;
}

export interface ProductFrame {
  id: string;
  name: string;
  priceModifier: number;
  colorHex: string;
  borderColorHex: string;
  shadowClass: string;
}

export interface ProductSize {
  id: string;
  name: string;
  dimensions: string;
  priceModifier: number;
}

export interface Product {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  category: "landmarks" | "nature" | "cityscapes" | "abstract" | "vintage";
  basePrice: number;
  imageMain: string;
  imageSecondary: string;
  rating: number;
  location: string;
  artist: string;
  year: number;
  isLimited: boolean;
  totalLimitedPrints?: number;
  printsLeft?: number;
  reviews: Review[];
  featured?: boolean;
}

export interface CartItem {
  id: string; // unique item id (combines product, size, frame)
  product: Product;
  selectedSize: ProductSize;
  selectedFrame: ProductFrame;
  quantity: number;
}

export interface Collection {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
  icon: string;
}

export interface Article {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  readTime: string;
  date: string;
  image: string;
}

export interface Room {
  id: string;
  name: string;
  image: string;
  description: string;
}
