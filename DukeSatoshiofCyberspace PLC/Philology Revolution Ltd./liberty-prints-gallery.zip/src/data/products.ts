import { Product, ProductFrame, ProductSize, Collection, Article, Room } from "../types";

export const PRODUCT_SIZES: ProductSize[] = [
  { id: "size-s", name: "Classic Studio", dimensions: "12\" × 16\" / 30 × 40 cm", priceModifier: 0 },
  { id: "size-m", name: "Collector Select", dimensions: "18\" × 24\" / 45 × 60 cm", priceModifier: 45 },
  { id: "size-l", name: "Grand Salon", dimensions: "24\" × 32\" / 60 × 80 cm", priceModifier: 95 },
  { id: "size-xl", name: "Exhibition Masterpiece", dimensions: "36\" × 48\" / 90 × 120 cm", priceModifier: 175 }
];

export const PRODUCT_FRAMES: ProductFrame[] = [
  { 
    id: "frame-none", 
    name: "Giclée Fine Art Print Only", 
    priceModifier: 0, 
    colorHex: "transparent", 
    borderColorHex: "transparent",
    shadowClass: "shadow-md border-0" 
  },
  { 
    id: "frame-obsidian", 
    name: "Gallery Obsidian Maple", 
    priceModifier: 50, 
    colorHex: "#111111", 
    borderColorHex: "#1F1F1F",
    shadowClass: "shadow-[0_25px_50px_-12px_rgba(0,0,0,0.8)] border-[14px] border-[#111111] outline outline-1 outline-neutral-800" 
  },
  { 
    id: "frame-oak", 
    name: "Heritage Warm Oak", 
    priceModifier: 60, 
    colorHex: "#AE8050", 
    borderColorHex: "#8B5F34",
    shadowClass: "shadow-[0_25px_50px_-12px_rgba(0,0,0,0.8)] border-[14px] border-[#C19363] outline outline-1 outline-amber-900/30" 
  },
  { 
    id: "frame-gold", 
    name: "Museum Gilded Gold", 
    priceModifier: 85, 
    colorHex: "#D8A33A", 
    borderColorHex: "#C5932F",
    shadowClass: "shadow-[0_25px_50px_-12px_rgba(0,0,0,0.8)] border-[14px] border-[#D8A33A] outline outline-1 outline-amber-500/40 ring-1 ring-[#D8A33A]/50" 
  }
];

export const COLLECTIONS: Collection[] = [
  {
    id: "col-landmarks",
    name: "Landmarks",
    slug: "landmarks",
    description: "Iconic architectural wonders and structures, captured with cinematic twilight tones.",
    image: "/src/assets/images/golden_gate_sunset_1784217448780.jpg",
    icon: "Milestone"
  },
  {
    id: "col-nature",
    name: "Nature",
    slug: "nature",
    description: "Calming alpine lakes, towering peaks, and majestic coastal shores crafted with warm ambient light.",
    image: "/src/assets/images/mountain_serenity_1784217464755.jpg",
    icon: "Compass"
  },
  {
    id: "col-cityscapes",
    name: "Cityscapes",
    slug: "cityscapes",
    description: "The vibrant heartbeat of the world's finest metropolitan horizons at dusk.",
    image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?auto=format&fit=crop&w=800&q=80",
    icon: "Building2"
  },
  {
    id: "col-abstract",
    name: "Abstract",
    slug: "abstract",
    description: "Exquisite geometric compositions layered with custom gold leaf accents and dark navy weaves.",
    image: "/src/assets/images/abstract_geometry_1784217552513.jpg",
    icon: "Sparkles"
  },
  {
    id: "col-vintage",
    name: "Vintage Landscape",
    slug: "vintage",
    description: "Nostalgic desert panoramas and European avenues reflecting timeless romance.",
    image: "/src/assets/images/desert_dream_1784217533208.jpg",
    icon: "Hourglass"
  }
];

export const PRODUCTS: Product[] = [
  {
    id: "prod-golden-gate",
    title: "Golden Gate Sunset",
    subtitle: "A majestic expressionist study of light, steel, and fog.",
    description: "An exquisite, award-winning impressionist oil painting capturing the timeless Golden Gate Bridge at high-noon twilight. Heavy brushstrokes and rich impasto paint reflect the warm amber sun rays off the misty Pacific waves. This fine-art print preserves every layer of pigment and canvas texture with microscopic archival precision.",
    category: "landmarks",
    basePrice: 89,
    imageMain: "/src/assets/images/golden_gate_sunset_1784217448780.jpg",
    imageSecondary: "https://images.unsplash.com/photo-1506012787146-f92b2d7d6d96?auto=format&fit=crop&w=1200&q=80",
    rating: 4.9,
    location: "San Francisco, USA",
    artist: "Jean-Laurent Alighieri",
    year: 2024,
    isLimited: true,
    totalLimitedPrints: 250,
    printsLeft: 42,
    featured: true,
    reviews: [
      { id: "rev-1-1", userName: "Alistair H.", rating: 5, date: "June 14, 2026", comment: "The impasto details are breathtaking. When the afternoon sun hits this in my lounge, it actually glows. Truly museum quality." },
      { id: "rev-1-2", userName: "Diana V.", rating: 5, date: "May 28, 2026", comment: "The warm gold frame completely transforms my workspace. Stunning print accuracy!" }
    ]
  },
  {
    id: "prod-mountain-serenity",
    title: "Mountain Serenity",
    subtitle: "A silent reflection of romanticist grand alpine heights.",
    description: "An evocative romantic landscape rendering snow-capped mountain peaks reflecting perfectly onto an alpine lake. Crafted with soft glowing dawn mist and fine atmospheric depth, this artwork serves as a spiritual sanctuary for the contemporary interior. Giclée printed using pigment-based inks to guarantee a lifespan exceeding a century.",
    category: "nature",
    basePrice: 79,
    imageMain: "/src/assets/images/mountain_serenity_1784217464755.jpg",
    imageSecondary: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=80",
    rating: 5.0,
    location: "Swiss Alps",
    artist: "Elena Rostova",
    year: 2025,
    isLimited: false,
    featured: true,
    reviews: [
      { id: "rev-2-1", userName: "Sarah M.", rating: 5, date: "July 01, 2026", comment: "The quality is exceptional. It completely transformed my space and lifts my mood every single day. The paper feels extremely expensive." },
      { id: "rev-2-2", userName: "James T.", rating: 5, date: "June 20, 2026", comment: "Beautiful prints and fast shipping. I'll definitely be ordering more for our summer estate!" }
    ]
  },
  {
    id: "prod-desert-dream",
    title: "Desert Dream",
    subtitle: "A peaceful desert twilight of terracotta, dust, and time.",
    description: "Breathtaking desert poetry showcasing mature Joshua trees resting under a warm terracotta twilight dome. Gentle rolling dunes fade into the soft horizon, rendered in magnificent earth tones. Giclée printed with archival inks on premium ultra-heavy cotton rag paper.",
    category: "vintage",
    basePrice: 79,
    imageMain: "/src/assets/images/desert_dream_1784217533208.jpg",
    imageSecondary: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&w=1200&q=80",
    rating: 4.8,
    location: "Joshua Tree, USA",
    artist: "Marcus Vance",
    year: 2023,
    isLimited: true,
    totalLimitedPrints: 150,
    printsLeft: 18,
    featured: true,
    reviews: [
      { id: "rev-3-1", userName: "Olivia K.", rating: 5, date: "July 12, 2026", comment: "Fabulous warm tones. The print fits beautifully into our mid-century desert house." }
    ]
  },
  {
    id: "prod-abstract-geometry",
    title: "Abstract Geometry No. 4",
    subtitle: "A contemporary dialogue of navy depth and golden leaf.",
    description: "An elegant bento of balanced geometric shapes, layered with fine gold leaf textures and deep navy canvases. The composition moves fluidly from structure to flow, offering a sophisticated anchor for any luxury living room or corporate boardroom. Signed and numbered by the artist.",
    category: "abstract",
    basePrice: 119,
    imageMain: "/src/assets/images/abstract_geometry_1784217552513.jpg",
    imageSecondary: "https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=1200&q=80",
    rating: 4.9,
    location: "London, UK",
    artist: "Arthur Pendelton",
    year: 2026,
    isLimited: true,
    totalLimitedPrints: 75,
    printsLeft: 9,
    featured: true,
    reviews: [
      { id: "rev-4-1", userName: "Julian F.", rating: 5, date: "June 30, 2026", comment: "The gold-leaf reflections are so realistic. A true masterpiece of print engineering." }
    ]
  },
  {
    id: "prod-coastal-dawn",
    title: "Aetherial Coastal Dawn",
    subtitle: "The poetic edge where golden sea meets mountain cliffs.",
    description: "An immersive oil landscape depicting golden daylight breaking over a magnificent ocean coastline. Ambient sunbursts and thick impasto waves define the edge of the rocky cliff, creating a dramatic and expensive gallery feel. Selected for the 2026 European Salon Exhibition.",
    category: "nature",
    basePrice: 135,
    imageMain: "/src/assets/images/hero_coastal_art_1784217431645.jpg",
    imageSecondary: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80",
    rating: 5.0,
    location: "Amalfi Coast, Italy",
    artist: "Jean-Laurent Alighieri",
    year: 2026,
    isLimited: true,
    totalLimitedPrints: 50,
    printsLeft: 4,
    featured: true,
    reviews: [
      { id: "rev-5-1", userName: "Beatrice D.", rating: 5, date: "July 14, 2026", comment: "Outstanding luxury item. Arrived beautifully crated. The gilded gold frame is worth every single penny." }
    ]
  },
  {
    id: "prod-manhattan-twilight",
    title: "Manhattan Twilight",
    subtitle: "An urban symphony of lights, water, and copper sky.",
    description: "A breathtaking twilight snapshot of the Manhattan skyline. Warm building illuminations cascade onto the East River under a dramatic copper and burnt orange evening dome. Giclée printed to reveal microscopic architectural details and gorgeous chromatic transitions.",
    category: "cityscapes",
    basePrice: 95,
    imageMain: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?auto=format&fit=crop&w=1200&q=80",
    imageSecondary: "https://images.unsplash.com/photo-1518235506717-e1ed3306a89b?auto=format&fit=crop&w=1200&q=80",
    rating: 4.7,
    location: "New York, USA",
    artist: "Marcus Vance",
    year: 2024,
    isLimited: false,
    featured: false,
    reviews: []
  },
  {
    id: "prod-parisian-alley",
    title: "Vintage Parisian Alley",
    subtitle: "A cinematic walk through nostalgic lights and wet stone.",
    description: "An intimate depiction of a quiet Montmartre street corner in Paris after a light rain shower. Glowing gas lanterns reflect warm amber light onto wet cobblestones, creating a dreamy, highly nostalgic museum aesthetic.",
    category: "vintage",
    basePrice: 75,
    imageMain: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1200&q=80",
    imageSecondary: "https://images.unsplash.com/photo-1499856871958-5b9647a64dbd?auto=format&fit=crop&w=1200&q=80",
    rating: 4.8,
    location: "Paris, France",
    artist: "Elena Rostova",
    year: 2022,
    isLimited: false,
    featured: false,
    reviews: []
  },
  {
    id: "prod-tokyo-neon",
    title: "Tokyo Neon Dreams",
    subtitle: "A stunning chromatic night in Shibuya at golden dusk.",
    description: "An artistic study of Tokyo's neon glow intermingling with a rare copper sunset sky. The bustling streets are blurred into elegant light trails, contrasted against quiet structural facades. Extremely high dynamic range giclée print on fine-art metallic paper.",
    category: "cityscapes",
    basePrice: 99,
    imageMain: "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=1200&q=80",
    imageSecondary: "https://images.unsplash.com/photo-1540959733332-eab4deceeaf7?auto=format&fit=crop&w=1200&q=80",
    rating: 4.9,
    location: "Tokyo, Japan",
    artist: "Arthur Pendelton",
    year: 2025,
    isLimited: true,
    totalLimitedPrints: 100,
    printsLeft: 31,
    featured: false,
    reviews: []
  }
];

export const FEATURED_ARTISTS = [
  {
    name: "Jean-Laurent Alighieri",
    role: "Classical Landscape Painter",
    bio: "Living between Florence and Amalfi, Jean-Laurent merges 19th-century oil painting techniques with modern atmospheric high-contrast compositions.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=400&h=400&q=80"
  },
  {
    name: "Elena Rostova",
    role: "Romanticist Fine Artist",
    bio: "Based in Saint Petersburg, Elena's atmospheric mountain landscapes capture the sublime and peaceful silence of remote peaks under warm alpine light.",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=400&h=400&q=80"
  },
  {
    name: "Marcus Vance",
    role: "Atmospheric Photographer",
    bio: "Marcus documents the pristine warmth of southwestern deserts and vintage European streets, specializing in extreme light gradients and grain textures.",
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=400&h=400&q=80"
  }
];

export const ARTICLES: Article[] = [
  {
    id: "art-1",
    title: "The Craft of Museum Giclée Printing",
    excerpt: "Discover why 12-color archival pigment printing on heavy cotton rag ensures a print that outlasts a century.",
    category: "Mastery",
    readTime: "5 min read",
    date: "July 12, 2026",
    image: "https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "art-2",
    title: "Designing with Warm Light Gradients",
    excerpt: "How to anchor a modern minimalist room using high-contrast twilight artwork and custom gilded wooden frames.",
    category: "Curation",
    readTime: "7 min read",
    date: "June 28, 2026",
    image: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "art-3",
    title: "Understanding Limited Edition Art Scarcity",
    excerpt: "Why our micro-batches are hand-numbered, signed, and strictly preserved under custom digital ledger controls.",
    category: "Investment",
    readTime: "4 min read",
    date: "May 15, 2026",
    image: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?auto=format&fit=crop&w=600&q=80"
  }
];

export const INTERIOR_ROOMS: Room[] = [
  {
    id: "room-living",
    name: "Minimalist Grand Salon",
    image: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=80",
    description: "A wide, double-height space showing 'Aetherial Coastal Dawn' in a Museum Gilded Gold frame, perfectly matching warm leather and slate marble finishes."
  },
  {
    id: "room-office",
    name: "Creative Executive Boardroom",
    image: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80",
    description: "An elegant professional office anchored by 'Abstract Geometry No. 4' in a Gallery Obsidian Maple frame to inspire structure and strategic focus."
  },
  {
    id: "room-bedroom",
    name: "Ambient Master Suite",
    image: "https://images.unsplash.com/photo-1616594039964-ae9021a400a0?auto=format&fit=crop&w=1200&q=80",
    description: "A calm, earthy sanctuary featuring 'Desert Dream' on neutral plaster walls, accentuated by soft dimming amber uplights."
  }
];

export const FAQS = [
  {
    question: "What makes these prints 'Museum Quality'?",
    answer: "We use professional Epson SureColor 12-color printers with ultra-chrome archival pigment inks. Unlike dye-based home printers, pigment prints offer rich color fidelity and lightfastness rated for over 100 years. The prints are made on heavy 310gsm German-made 100% cotton acid-free rag paper with a subtle texture."
  },
  {
    question: "How are the wooden frames crafted?",
    answer: "Each frame is custom built to order by master framers in our partner studio. We use sustainable solid hardwoods (Obsidian Maple and American White Oak) or hand-gilded premium composites. Every framed piece includes custom white cotton acid-free matting and museum-grade antireflective UV acrylic which filters out 99% of harmful rays."
  },
  {
    question: "Do limited editions include certifications?",
    answer: "Yes. Every limited edition print comes with a physical, gold-stamped Certificate of Authenticity signed by the artist. It details the print number (e.g., 4 of 75), the production date, print dimensions, and chemical formulation of the paper batch."
  },
  {
    question: "What is your shipping and return policy?",
    answer: "Unframed prints ship within 2 business days in secure heavy-duty tubes. Framed artworks are carefully crated in timber boxes and ship via courier within 7-10 business days. We offer free, fully-insured worldwide shipping and a 30-day, no-questions-asked luxury return policy."
  },
  {
    question: "Do you offer a trade program for interior designers?",
    answer: "Absolutely. We offer a bespoke Trade Programme for architects, interior designers, and corporate art consultants. Members receive custom scaling options, priority custom framing, volume discounts, and 1-on-1 art advisory. Contact our trade desk via trade@libertyprints.com."
  }
];
