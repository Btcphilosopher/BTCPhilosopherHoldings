import React, { useState } from "react";
import { FEATURED_ARTISTS, ARTICLES, INTERIOR_ROOMS, FAQS } from "../data/products";
import { Compass, BookOpen, ShieldCheck, Mail, ChevronDown, Check, Star, Users, HardHat, FileText, Gift, Award, Hammer } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function AdditionalSections() {
  // Stepper for How printing works
  const [activeStep, setActiveStep] = useState(0);
  const printingSteps = [
    {
      title: "Archival Digital Capture",
      desc: "Artworks undergo 8K multispectral scanning under polarized filters. This eliminates light glare and captures the exact depth of every oil pigment and fiber weave.",
      icon: <Compass className="w-5 h-5 text-[#D8A33A]" />
    },
    {
      title: "D50 Chromatic Softproofing",
      desc: "Our colorists perform spectral color matching under controlled D50 daylight rooms to match target gamuts, ensuring identical translation from canvas to cotton paper.",
      icon: <FileText className="w-5 h-5 text-[#D8A33A]" />
    },
    {
      title: "12-Channel Micro-Pigmenting",
      desc: "Prints are made on custom professional Epson systems utilizing 12 separate ink streams of mineral-based pigments, ensuring rich black density and lightfastness.",
      icon: <Hammer className="w-5 h-5 text-[#D8A33A]" />
    },
    {
      title: "Master Framing Guild Joinery",
      desc: "Artisans build custom wooden frames from solid sustainable hardwoods. Artworks are set under white acid-free cotton mats and UV-filtration acrylic shields.",
      icon: <Award className="w-5 h-5 text-[#D8A33A]" />
    }
  ];

  // FAQ Accordions State
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  // Corporate Advisory Form State
  const [tradeForm, setTradeForm] = useState({ name: "", email: "", firm: "", budget: "1000", message: "" });
  const [tradeSuccess, setTradeSuccess] = useState(false);

  // Newsletter State
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterSuccess, setNewsletterSuccess] = useState(false);

  const handleTradeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTradeSuccess(true);
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setNewsletterSuccess(true);
  };

  return (
    <div className="text-[#F8F4EE]">
      {/* 1. OUR STORY & THE MUSEUM GUILD */}
      <section id="about" className="py-24 bg-[#081826]/95 border-t border-[#F8F4EE]/5 relative overflow-hidden">
        <div className="absolute top-[20%] right-[-10%] w-[40vw] h-[40vw] rounded-full glow-spot-gold pointer-events-none" />
        <div className="max-w-7xl mx-auto px-6 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Visual Museum Frame */}
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="w-72 md:w-80 lg:w-96 aspect-[3/4] border-[14px] border-[#111] shadow-2xl relative bg-neutral-900 overflow-hidden outline outline-1 outline-neutral-800">
              <img
                src="https://images.unsplash.com/photo-1545987796-200677ee1011?auto=format&fit=crop&w=800&q=80"
                alt="Our Printing Studio Workshop"
                className="w-full h-full object-cover filter brightness-[0.7] contrast-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
              <div className="absolute bottom-4 left-4 z-10 font-mono text-[9px] tracking-widest text-[#D8A33A]">
                LONDON FINE-ART STUDIO • GUILD ROOM
              </div>
            </div>
            {/* Soft decorative shadow circle */}
            <div className="absolute -inset-8 bg-gradient-to-tr from-transparent via-[#D8A33A]/5 to-transparent blur-3xl pointer-events-none" />
          </div>

          {/* Text Content */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <span className="text-xs font-mono text-[#D8A33A] uppercase tracking-[0.3em] font-semibold block">
              ESTABLISHED 2024 • LONDON FINE ART CO.
            </span>
            <h2 className="font-serif text-3xl md:text-4xl tracking-wide leading-tight text-white">
              The Guild of Liberty prints
            </h2>
            <p className="text-sm text-neutral-300 leading-relaxed font-sans">
              Founded on the belief that fine art should move, inspire, and dwell within spaces of living dialogue, Liberty Prints operates as a premium collaborative workshop. We reject mass production in favor of meticulous, micro-calibrated print batches that preserve the tactile truth of original pigments.
            </p>
            <p className="text-sm text-neutral-300 leading-relaxed font-sans">
              Our partner studios collaborate directly with painters, digital catalog houses, and master timber suppliers to build cohesive, physical masterpieces. We source sustainable, solid hardwoods and premium German cotton rags, delivering premium curations that stand the test of centuries.
            </p>

            {/* Core Values grid */}
            <div className="grid grid-cols-2 gap-6 pt-6 border-t border-[#F8F4EE]/10 text-xs font-mono">
              <div className="space-y-2">
                <span className="flex items-center gap-2 text-[#D8A33A]">
                  <ShieldCheck className="w-4 h-4" />
                  <strong className="text-white">100% Acid-Free Guarantee</strong>
                </span>
                <p className="text-[10px] text-neutral-400 leading-relaxed font-sans">
                  Prevents yellowing and color rot over the lifespan of our cotton prints.
                </p>
              </div>
              <div className="space-y-2">
                <span className="flex items-center gap-2 text-[#D8A33A]">
                  <Compass className="w-4 h-4" />
                  <strong className="text-white">FSC Sustainable Hardwoods</strong>
                </span>
                <p className="text-[10px] text-neutral-400 leading-relaxed font-sans">
                  Every solid wood profile is hand-selected and sourced from certified forest programs.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. HOW PRINTING WORKS (Interactive Stepper) */}
      <section id="how-printing-works" className="py-24 bg-[#081826] border-t border-[#F8F4EE]/5 relative">
        <div className="absolute top-[40%] left-[-10%] w-[35vw] h-[35vw] rounded-full glow-spot-orange pointer-events-none" />
        <div className="max-w-7xl mx-auto px-6 md:px-8 text-left">
          {/* Header */}
          <div className="mb-16">
            <span className="text-xs font-mono text-[#D8A33A] uppercase tracking-[0.25em] font-semibold block">
              The Alchemy of Fine Art
            </span>
            <h2 className="font-serif text-3xl md:text-4xl text-white tracking-wide mt-2">
              How Museum Printing Works
            </h2>
            <p className="text-sm text-neutral-400 mt-2 max-w-xl">
              From scanning original canvases to custom hardwood joinery, trace our physical print creation process.
            </p>
          </div>

          {/* Stepper Grid Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            {/* Steps navigation links */}
            <div className="lg:col-span-5 space-y-3">
              {printingSteps.map((step, index) => (
                <button
                  key={index}
                  onClick={() => setActiveStep(index)}
                  className={`w-full p-5 text-left border transition-all cursor-pointer flex items-center gap-4 ${activeStep === index ? "bg-[#D8A33A]/10 border-[#D8A33A] text-white" : "border-[#F8F4EE]/10 hover:border-white/20 text-neutral-400 hover:text-white"}`}
                >
                  <span className={`w-8 h-8 rounded-full border font-mono text-xs flex items-center justify-center shrink-0 ${activeStep === index ? "border-[#D8A33A] bg-[#D8A33A] text-[#081826] font-bold" : "border-neutral-700 text-neutral-400"}`}>
                    0{index + 1}
                  </span>
                  <div>
                    <span className="text-xs font-mono font-semibold uppercase tracking-wider block">{step.title}</span>
                    <span className="text-[9px] text-neutral-500 font-mono mt-0.5 block">Process Stage {index + 1}</span>
                  </div>
                </button>
              ))}
            </div>

            {/* Active Step Detailed Display */}
            <div className="lg:col-span-7 bg-[#273746]/10 border border-[#F8F4EE]/10 p-8 md:p-10 relative overflow-hidden min-h-[300px] flex flex-col justify-between">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-full border border-[#D8A33A]/20 flex items-center justify-center bg-[#081826]">
                  {printingSteps[activeStep].icon}
                </div>
                <h3 className="font-serif text-2xl text-white tracking-wide">{printingSteps[activeStep].title}</h3>
                <p className="text-neutral-300 font-sans text-xs leading-relaxed max-w-xl">
                  {printingSteps[activeStep].desc}
                </p>
              </div>

              {/* Assurances footer in detail box */}
              <div className="pt-6 border-t border-[#F8F4EE]/5 mt-8 flex items-center gap-2 text-[10px] font-mono text-neutral-400 uppercase tracking-widest">
                <ShieldCheck className="w-4 h-4 text-[#D8A33A]" />
                <span>Micro-Pigmented Calibration Profile verified</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. FEATURED ARTISTS PROFILE SECTION */}
      <section id="artists" className="py-24 bg-[#081826]/95 border-t border-[#F8F4EE]/5 relative">
        <div className="max-w-7xl mx-auto px-6 md:px-8 text-left">
          {/* Header */}
          <div className="mb-16">
            <span className="text-xs font-mono text-[#D8A33A] uppercase tracking-[0.25em] font-semibold block">
              The Creators of horisons
            </span>
            <h2 className="font-serif text-3xl md:text-4xl text-white tracking-wide mt-2">
              Featured Artists in Curation
            </h2>
            <p className="text-sm text-neutral-400 mt-2 max-w-xl">
              We collaborate directly with world-class romanticist painters, classical landscape scholars, and atmospheric photographers.
            </p>
          </div>

          {/* Artists Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {FEATURED_ARTISTS.map((artist, idx) => (
              <div
                key={idx}
                className="group border border-[#F8F4EE]/10 p-6 bg-white/[0.01] hover:border-[#D8A33A]/40 transition-all duration-500 hover:shadow-2xl hover:shadow-[#D8A33A]/5 flex flex-col justify-between"
              >
                <div className="space-y-4">
                  <div className="relative w-20 h-20 rounded-full overflow-hidden border border-[#D8A33A]/30">
                    <img src={artist.image} alt={artist.name} className="w-full h-full object-cover filter contrast-105" referrerPolicy="no-referrer" />
                  </div>
                  <div>
                    <h3 className="font-serif text-lg text-white font-bold tracking-wide group-hover:text-[#D8A33A] transition-colors">{artist.name}</h3>
                    <span className="text-[10px] font-mono uppercase tracking-widest text-[#D8A33A] block mt-0.5">{artist.role}</span>
                  </div>
                  <p className="text-xs text-neutral-400 font-sans leading-relaxed line-clamp-4">
                    {artist.bio}
                  </p>
                </div>

                <div className="pt-6 border-t border-[#F8F4EE]/5 mt-6 flex items-center gap-1.5 text-[9px] font-mono text-neutral-500 uppercase tracking-widest">
                  <Award className="w-3.5 h-3.5 text-[#D8A33A]" />
                  <span>Licensed collaborative contracts</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. INTERIOR INSPIRATION & FEATURED ROOMS */}
      <section id="rooms" className="py-24 bg-[#081826] border-t border-[#F8F4EE]/5 relative overflow-hidden">
        <div className="absolute top-[20%] right-[-10%] w-[40vw] h-[40vw] rounded-full glow-spot-gold pointer-events-none" />
        <div className="max-w-7xl mx-auto px-6 md:px-8 text-left">
          {/* Header */}
          <div className="mb-16">
            <span className="text-xs font-mono text-[#D8A33A] uppercase tracking-[0.25em] font-semibold block">
              Architectural placements
            </span>
            <h2 className="font-serif text-3xl md:text-4xl text-white tracking-wide mt-2">
              Interior Inspiration: Featured Rooms
            </h2>
            <p className="text-sm text-neutral-400 mt-2 max-w-xl">
              Preview how our certified museum-grade framed pieces anchor and elevate high-end modern residential, creative workspace, and bedroom environments.
            </p>
          </div>

          {/* Rooms List Carousel representation */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {INTERIOR_ROOMS.map((room) => (
              <div
                key={room.id}
                className="group border border-[#F8F4EE]/10 bg-black/10 overflow-hidden hover:border-[#D8A33A]/40 transition-all duration-500 hover:shadow-2xl flex flex-col justify-between"
              >
                <div className="relative aspect-[16/10] overflow-hidden">
                  <img
                    src={room.image}
                    alt={room.name}
                    className="w-full h-full object-cover filter brightness-[0.7] group-hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#081826]/90 via-transparent to-transparent pointer-events-none" />
                </div>
                <div className="p-6 space-y-3">
                  <h3 className="font-serif text-lg text-white font-bold tracking-wide group-hover:text-[#D8A33A] transition-colors">{room.name}</h3>
                  <p className="text-xs text-neutral-400 leading-relaxed font-sans">{room.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. EDITORIAL ARTICLES (BLOG) */}
      <section id="editorial" className="py-24 bg-[#081826]/95 border-t border-[#F8F4EE]/5 relative">
        <div className="max-w-7xl mx-auto px-6 md:px-8 text-left">
          {/* Header */}
          <div className="mb-16">
            <span className="text-xs font-mono text-[#D8A33A] uppercase tracking-[0.25em] font-semibold block">
              Curation Knowledge
            </span>
            <h2 className="font-serif text-3xl md:text-4xl text-white tracking-wide mt-2">
              The Editorial Archive
            </h2>
            <p className="text-sm text-neutral-400 mt-2 max-w-xl">
              Deep dives into print engineering, fine-art investments, and custom residential curations from our editorial board.
            </p>
          </div>

          {/* Blog cards grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {ARTICLES.map((art) => (
              <article
                key={art.id}
                className="group border border-[#F8F4EE]/10 bg-white/[0.01] overflow-hidden hover:border-[#D8A33A]/40 transition-all duration-500 flex flex-col justify-between"
              >
                <div className="relative aspect-[16/10] overflow-hidden bg-neutral-900 border-b border-[#F8F4EE]/10">
                  <img
                    src={art.image}
                    alt={art.title}
                    className="w-full h-full object-cover filter brightness-75 group-hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between text-left">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center text-[9px] font-mono text-[#D8A33A]">
                      <span className="uppercase tracking-widest">{art.category}</span>
                      <span>{art.readTime}</span>
                    </div>
                    <h3 className="font-serif text-base font-bold text-white tracking-wide group-hover:text-[#D8A33A] transition-colors line-clamp-2">
                      {art.title}
                    </h3>
                    <p className="text-xs text-neutral-400 leading-relaxed font-sans line-clamp-3">
                      {art.excerpt}
                    </p>
                  </div>

                  <div className="pt-4 mt-6 border-t border-[#F8F4EE]/5 flex justify-between items-center text-[10px] font-mono text-neutral-500">
                    <span>{art.date}</span>
                    <span className="text-[#D8A33A] group-hover:underline cursor-pointer">Read Article →</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* 6. TRADE DESK & CORPORATE ADVISORY (FORM) */}
      <section id="corporate" className="py-24 bg-[#081826] border-t border-[#F8F4EE]/5 relative overflow-hidden">
        <div className="absolute bottom-0 left-[20%] w-[50vw] h-[50vw] rounded-full glow-spot-orange pointer-events-none" />
        <div className="max-w-7xl mx-auto px-6 md:px-8 text-left">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Context Text */}
            <div className="lg:col-span-6 space-y-6">
              <span className="text-xs font-mono text-[#D8A33A] uppercase tracking-[0.25em] font-semibold block">
                Bespoke Solutions
              </span>
              <h2 className="font-serif text-3xl md:text-4xl text-white tracking-wide">
                Trade Desk & Corporate Advisory
              </h2>
              <p className="text-sm text-neutral-300 leading-relaxed font-sans">
                We operate a bespoke trade program tailored specifically for architects, high-end interior designers, hospitality renovators, and corporate art directors.
              </p>
              <p className="text-xs text-neutral-400 leading-relaxed font-sans">
                Trade members receive priority access to custom canvas sizing, bespoke frame molding joineries, flat volume discounts, and 1-on-1 consultations with our senior curators.
              </p>

              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-[#F8F4EE]/10 text-xs font-mono">
                <div>
                  <span className="block text-[#D8A33A] font-bold">1-ON-1</span>
                  <span className="block text-[10px] text-neutral-400 mt-0.5">Private Art Advising</span>
                </div>
                <div>
                  <span className="block text-[#D8A33A] font-bold">bespoke</span>
                  <span className="block text-[10px] text-neutral-400 mt-0.5">Sizing & Molding</span>
                </div>
                <div>
                  <span className="block text-[#D8A33A] font-bold">trade rate</span>
                  <span className="block text-[10px] text-neutral-400 mt-0.5">Commercial Discounts</span>
                </div>
              </div>
            </div>

            {/* Consulting Form */}
            <div className="lg:col-span-6 bg-[#273746]/10 border border-[#F8F4EE]/10 p-6 md:p-8 relative">
              <AnimatePresence mode="wait">
                {!tradeSuccess ? (
                  <motion.div
                    key="trade-form"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <h3 className="font-serif text-xl text-white mb-2 tracking-wide">Trade Application Desk</h3>
                    <p className="text-[11px] text-neutral-400 mb-6">Apply to initiate your premium commercial trade account.</p>

                    <form onSubmit={handleTradeSubmit} className="space-y-4 text-xs font-mono">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[9px] text-neutral-400 uppercase tracking-widest mb-1">Full Name</label>
                          <input
                            required
                            type="text"
                            value={tradeForm.name}
                            onChange={(e) => setTradeForm({ ...tradeForm, name: e.target.value })}
                            className="w-full bg-[#273746]/30 border border-[#F8F4EE]/10 px-3 py-2 text-white focus:outline-none focus:border-[#D8A33A]"
                          />
                        </div>
                        <div>
                          <label className="block text-[9px] text-neutral-400 uppercase tracking-widest mb-1">Design Firm / Org</label>
                          <input
                            required
                            type="text"
                            value={tradeForm.firm}
                            onChange={(e) => setTradeForm({ ...tradeForm, firm: e.target.value })}
                            className="w-full bg-[#273746]/30 border border-[#F8F4EE]/10 px-3 py-2 text-white focus:outline-none focus:border-[#D8A33A]"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[9px] text-neutral-400 uppercase tracking-widest mb-1">Professional Email</label>
                        <input
                          required
                          type="email"
                          value={tradeForm.email}
                          onChange={(e) => setTradeForm({ ...tradeForm, email: e.target.value })}
                          className="w-full bg-[#273746]/30 border border-[#F8F4EE]/10 px-3 py-2 text-white focus:outline-none focus:border-[#D8A33A]"
                        />
                      </div>

                      <div>
                        <label className="block text-[9px] text-neutral-400 uppercase tracking-widest mb-1">Estimated Annual Budget (USD)</label>
                        <select
                          value={tradeForm.budget}
                          onChange={(e) => setTradeForm({ ...tradeForm, budget: e.target.value })}
                          className="w-full bg-[#273746]/30 border border-[#F8F4EE]/10 px-3 py-2 text-white focus:outline-none focus:border-[#D8A33A] h-9"
                        >
                          <option value="1000">$1,000 - $5,000</option>
                          <option value="5000">$5,000 - $20,000</option>
                          <option value="20000">$20,000 - $100,000</option>
                          <option value="100000">$100,000+</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[9px] text-neutral-400 uppercase tracking-widest mb-1">Tell us about your project</label>
                        <textarea
                          required
                          rows={3}
                          value={tradeForm.message}
                          onChange={(e) => setTradeForm({ ...tradeForm, message: e.target.value })}
                          className="w-full bg-[#273746]/30 border border-[#F8F4EE]/10 px-3 py-2 text-white focus:outline-none focus:border-[#D8A33A] font-sans resize-none"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full py-3 bg-[#D8A33A] hover:bg-[#D8A33A]/90 text-[#081826] font-bold text-xs uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center gap-2"
                      >
                        <Users className="w-4 h-4" />
                        <span>Submit Trade Brief</span>
                      </button>
                    </form>
                  </motion.div>
                ) : (
                  <motion.div
                    key="trade-success"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="py-12 flex flex-col items-center justify-center text-center space-y-4 text-emerald-400"
                  >
                    <div className="w-12 h-12 bg-emerald-500/10 border border-emerald-500 rounded-full flex items-center justify-center">
                      <Check className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-serif text-xl text-white tracking-wide">Brief Received</h3>
                      <p className="text-[11px] text-neutral-400 mt-1 max-w-sm">
                        Thank you, <strong className="text-white">{tradeForm.name}</strong>. A senior art advisor from our London trade desk will contact your office at <strong className="text-white">{tradeForm.email}</strong> within 12 business hours.
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </section>

      {/* 7. DETAILED FAQS (ACCORDIONS) */}
      <section id="faqs" className="py-24 bg-[#081826]/95 border-t border-[#F8F4EE]/5 relative">
        <div className="max-w-4xl mx-auto px-6 md:px-8 text-left">
          {/* Header */}
          <div className="text-center mb-16">
            <span className="text-xs font-mono text-[#D8A33A] uppercase tracking-[0.25em] font-semibold block">
              Curator Assistance
            </span>
            <h2 className="font-serif text-3xl md:text-4xl text-white tracking-wide mt-2">
              Frequently Queried Inquiries
            </h2>
          </div>

          {/* Accordion List */}
          <div className="space-y-4">
            {FAQS.map((faq, idx) => (
              <div
                key={idx}
                className="border border-[#F8F4EE]/10 bg-white/[0.01] hover:border-white/20 transition-all rounded-none"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                  className="w-full p-5 flex items-center justify-between text-left focus:outline-none cursor-pointer"
                >
                  <span className="font-serif text-sm md:text-base text-white font-medium tracking-wide">
                    {faq.question}
                  </span>
                  <ChevronDown className={`w-4 h-4 text-[#D8A33A] shrink-0 transition-transform duration-300 ${openFaq === idx ? "rotate-180" : ""}`} />
                </button>

                <AnimatePresence initial={false}>
                  {openFaq === idx && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden"
                    >
                      <p className="p-5 pt-0 border-t border-[#F8F4EE]/5 text-xs text-neutral-400 font-sans leading-relaxed">
                        {faq.answer}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 8. NEWSLETTER SIGN UP (DECREE REGISTRY) */}
      <section className="py-24 bg-[#081826] border-t border-[#F8F4EE]/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[40vw] h-[40vw] glow-spot-gold pointer-events-none" />
        <div className="max-w-4xl mx-auto px-6 md:px-8 text-center relative z-10">
          <span className="text-xs font-mono text-[#D8A33A] uppercase tracking-[0.35em] block font-semibold mb-3">
            Stay Inspired
          </span>
          <h2 className="font-serif text-3xl md:text-4xl text-white tracking-wide">
            Registry for Private Releases
          </h2>
          <p className="text-xs text-neutral-400 mt-2 max-w-md mx-auto leading-relaxed">
            Register your coordinates to receive early notification of limited prints, micro-batches, and private artist catalog auctions. No noise. Only fine craft.
          </p>

          <div className="mt-8 max-w-md mx-auto bg-[#273746]/20 border border-[#F8F4EE]/10 p-5 rounded-none shadow-xl">
            <AnimatePresence mode="wait">
              {!newsletterSuccess ? (
                <motion.form
                  key="newsletter-form"
                  onSubmit={handleNewsletterSubmit}
                  className="flex flex-col sm:flex-row gap-2"
                >
                  <input
                    required
                    type="email"
                    placeholder="ENTER YOUR PROFESSIONAL EMAIL"
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    className="flex-1 bg-[#273746]/50 border border-[#F8F4EE]/10 text-[10px] font-mono tracking-wider px-3.5 py-3 text-white focus:outline-none focus:border-[#D8A33A]"
                  />
                  <button
                    type="submit"
                    className="bg-[#D8A33A] hover:bg-[#D8A33A]/90 text-[#081826] font-bold text-[10px] font-mono uppercase tracking-widest px-6 py-3 transition-all cursor-pointer shrink-0"
                  >
                    Subscribe
                  </button>
                </motion.form>
              ) : (
                <motion.div
                  key="newsletter-success"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-emerald-400 font-mono text-xs flex flex-col items-center gap-2 py-3"
                >
                  <div className="w-8 h-8 rounded-full border border-emerald-500 bg-emerald-500/10 flex items-center justify-center">
                    <Check className="w-4 h-4" />
                  </div>
                  <span>Credentials logged. Welcome to the Guild.</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </section>
    </div>
  );
}
