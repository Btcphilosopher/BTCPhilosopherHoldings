import React, { useState, useEffect } from "react";
import { CartItem } from "../types";
import { X, Lock, CreditCard, Ship, Check, RefreshCw, Printer, FileText } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  currencySymbol: string;
  currencyRate: number;
  discountAmount: number;
  onClearCart: () => void;
}

export default function CheckoutModal({
  isOpen,
  onClose,
  cart,
  currencySymbol,
  currencyRate,
  discountAmount,
  onClearCart
}: CheckoutModalProps) {
  if (!isOpen) return null;

  const [step, setStep] = useState<"shipping" | "payment" | "processing" | "success">("shipping");
  const [formData, setFormData] = useState({
    firstName: "Thomas",
    lastName: "Sterling",
    email: "tom@ahyx.org",
    address: "148 Pall Mall",
    city: "London",
    postcode: "SW1Y 5ED",
    country: "United Kingdom",
    cardName: "Thomas Sterling",
    cardNumber: "4111 2222 3333 4444",
    cardExpiry: "12/29",
    cardCvv: "381"
  });

  const [printLogs, setPrintLogs] = useState<string[]>([]);
  const [logIndex, setLogIndex] = useState(0);

  const logs = [
    "Establishing secure connection with London Fine-Art Lab...",
    "Validating client signature and currency ledger...",
    "Authenticating paper stock: Hahnemühle 310gsm Photo Rag (Acid-Free)...",
    "Calibrating 12-Channel Epson UltraChrome HDR Pigment system...",
    "Applying fine chromatic profile: D50 Standard Ambient Gallery Softproofing...",
    "Preparing micro-batch signature block and edition stamping...",
    "Generating cryptographic Certificate of Authenticity...",
    "Order securely committed. Packaging crates requested."
  ];

  useEffect(() => {
    if (step === "processing") {
      setPrintLogs([]);
      setLogIndex(0);
    }
  }, [step]);

  useEffect(() => {
    if (step === "processing" && logIndex < logs.length) {
      const delay = logIndex === 0 ? 400 : Math.random() * 600 + 400;
      const timer = setTimeout(() => {
        setPrintLogs((prev) => [...prev, logs[logIndex]]);
        setLogIndex((prev) => prev + 1);
      }, delay);
      return () => clearTimeout(timer);
    } else if (step === "processing" && logIndex === logs.length) {
      const timer = setTimeout(() => {
        setStep("success");
        onClearCart();
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [step, logIndex]);

  const getSubtotal = () => {
    return cart.reduce((sum, item) => {
      const itemBase = item.product.basePrice;
      const sizeMod = item.selectedSize.priceModifier;
      const frameMod = item.selectedFrame.priceModifier;
      return sum + (itemBase + sizeMod + frameMod) * currencyRate;
    }, 0);
  };

  const subtotal = getSubtotal();
  const discountVal = subtotal * (discountAmount / 100);
  const shipping = subtotal > 150 * currencyRate ? 0 : 25 * currencyRate;
  const total = subtotal - discountVal + shipping;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep("payment");
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep("processing");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={() => step !== "processing" && onClose()}
        className="fixed inset-0 bg-[#081826]/90 backdrop-blur-md"
      />

      {/* Modal Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-4xl glass rounded-none overflow-hidden z-10 flex flex-col md:flex-row h-auto max-h-[90vh] text-[#F8F4EE] shadow-2xl border border-[#F8F4EE]/10"
      >
        {/* Close Button */}
        {step !== "processing" && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-20 p-2 text-neutral-400 hover:text-white hover:bg-white/5 transition-all rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Left Column: Flow Forms */}
        <div className="flex-1 p-6 md:p-8 overflow-y-auto max-h-[80vh] md:max-h-none border-b md:border-b-0 md:border-r border-[#F8F4EE]/10">
          {/* Breadcrumbs */}
          {step !== "processing" && step !== "success" && (
            <div className="flex gap-4 mb-6 text-xs font-mono tracking-wider text-neutral-400">
              <span className={step === "shipping" ? "text-[#D8A33A] font-semibold" : ""}>01. SHIPPING</span>
              <span>/</span>
              <span className={step === "payment" ? "text-[#D8A33A] font-semibold" : ""}>02. CURATOR SETTLEMENT</span>
            </div>
          )}

          <AnimatePresence mode="wait">
            {step === "shipping" && (
              <motion.div
                key="shipping-form"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
              >
                <h2 className="font-serif text-2xl tracking-wide mb-1 text-[#F8F4EE]">Curator Shipping Address</h2>
                <p className="text-xs text-neutral-400 mb-6">Enter your residential or gallery destination details.</p>

                <form onSubmit={handleShippingSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-widest mb-1">First Name</label>
                      <input
                        required
                        type="text"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        className="w-full bg-[#273746]/50 border border-[#F8F4EE]/10 text-xs px-3 py-2.5 font-mono text-[#F8F4EE] focus:outline-none focus:border-[#D8A33A]"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-widest mb-1">Last Name</label>
                      <input
                        required
                        type="text"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        className="w-full bg-[#273746]/50 border border-[#F8F4EE]/10 text-xs px-3 py-2.5 font-mono text-[#F8F4EE] focus:outline-none focus:border-[#D8A33A]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-widest mb-1">Contact Email</label>
                    <input
                      required
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full bg-[#273746]/50 border border-[#F8F4EE]/10 text-xs px-3 py-2.5 font-mono text-[#F8F4EE] focus:outline-none focus:border-[#D8A33A]"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-widest mb-1">Street Address</label>
                    <input
                      required
                      type="text"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      className="w-full bg-[#273746]/50 border border-[#F8F4EE]/10 text-xs px-3 py-2.5 font-mono text-[#F8F4EE] focus:outline-none focus:border-[#D8A33A]"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="col-span-2">
                      <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-widest mb-1">City / State</label>
                      <input
                        required
                        type="text"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        className="w-full bg-[#273746]/50 border border-[#F8F4EE]/10 text-xs px-3 py-2.5 font-mono text-[#F8F4EE] focus:outline-none focus:border-[#D8A33A]"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-widest mb-1">Postcode</label>
                      <input
                        required
                        type="text"
                        name="postcode"
                        value={formData.postcode}
                        onChange={handleInputChange}
                        className="w-full bg-[#273746]/50 border border-[#F8F4EE]/10 text-xs px-3 py-2.5 font-mono text-[#F8F4EE] focus:outline-none focus:border-[#D8A33A]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-widest mb-1">Country / Region</label>
                    <select
                      name="country"
                      value={formData.country}
                      onChange={handleInputChange}
                      className="w-full bg-[#273746]/50 border border-[#F8F4EE]/10 text-xs px-3 py-2.5 font-mono text-[#F8F4EE] focus:outline-none focus:border-[#D8A33A] h-10"
                    >
                      <option value="United Kingdom">United Kingdom</option>
                      <option value="United States">United States</option>
                      <option value="Germany">Germany</option>
                      <option value="France">France</option>
                      <option value="Italy">Italy</option>
                      <option value="Japan">Japan</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 mt-6 bg-[#D8A33A] hover:bg-[#D8A33A]/90 text-[#081826] font-semibold text-xs uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Ship className="w-4 h-4" />
                    <span>Proceed to Settlement</span>
                  </button>
                </form>
              </motion.div>
            )}

            {step === "payment" && (
              <motion.div
                key="payment-form"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
              >
                <h2 className="font-serif text-2xl tracking-wide mb-1 text-[#F8F4EE]">Secure Curator Settlement</h2>
                <p className="text-xs text-neutral-400 mb-6">Transactions are processed over encrypted high-tier SSL rails.</p>

                <form onSubmit={handlePaymentSubmit} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-widest mb-1">Cardholder Name</label>
                    <input
                      required
                      type="text"
                      name="cardName"
                      value={formData.cardName}
                      onChange={handleInputChange}
                      className="w-full bg-[#273746]/50 border border-[#F8F4EE]/10 text-xs px-3 py-2.5 font-mono text-[#F8F4EE] focus:outline-none focus:border-[#D8A33A]"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-widest mb-1">Card Number</label>
                    <div className="relative">
                      <input
                        required
                        type="text"
                        name="cardNumber"
                        value={formData.cardNumber}
                        onChange={handleInputChange}
                        className="w-full bg-[#273746]/50 border border-[#F8F4EE]/10 text-xs pl-10 pr-3 py-2.5 font-mono text-[#F8F4EE] focus:outline-none focus:border-[#D8A33A]"
                      />
                      <CreditCard className="absolute left-3 top-3 w-4 h-4 text-neutral-400" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-widest mb-1">Expiry Date</label>
                      <input
                        required
                        type="text"
                        name="cardExpiry"
                        placeholder="MM/YY"
                        value={formData.cardExpiry}
                        onChange={handleInputChange}
                        className="w-full bg-[#273746]/50 border border-[#F8F4EE]/10 text-xs px-3 py-2.5 font-mono text-[#F8F4EE] focus:outline-none focus:border-[#D8A33A]"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-widest mb-1">CVV Code</label>
                      <input
                        required
                        type="password"
                        name="cardCvv"
                        placeholder="•••"
                        value={formData.cardCvv}
                        onChange={handleInputChange}
                        maxLength={4}
                        className="w-full bg-[#273746]/50 border border-[#F8F4EE]/10 text-xs px-3 py-2.5 font-mono text-[#F8F4EE] focus:outline-none focus:border-[#D8A33A]"
                      />
                    </div>
                  </div>

                  <div className="flex gap-4 mt-6">
                    <button
                      type="button"
                      onClick={() => setStep("shipping")}
                      className="px-6 py-3 border border-[#F8F4EE]/15 text-neutral-300 hover:text-white hover:bg-white/5 text-xs uppercase tracking-wider font-mono transition-all cursor-pointer"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      className="flex-1 py-3 bg-[#C86B28] hover:bg-[#C86B28]/90 text-[#F8F4EE] font-semibold text-xs uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center gap-2"
                    >
                      <Lock className="w-4 h-4 text-amber-300" />
                      <span>Authenticate Order</span>
                    </button>
                  </div>
                </form>
              </motion.div>
            )}

            {step === "processing" && (
              <motion.div
                key="processing"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="py-12 flex flex-col items-center justify-center text-center space-y-6"
              >
                <RefreshCw className="w-10 h-10 animate-spin text-[#D8A33A]" />
                <div>
                  <h3 className="font-serif text-xl text-[#F8F4EE] tracking-wide">Connecting Fine Art Lab...</h3>
                  <p className="text-xs text-neutral-400 mt-1">Calibrating pigments and stamping edition parameters.</p>
                </div>

                {/* Simulated printer terminal */}
                <div className="w-full max-w-md bg-black/50 p-4 border border-[#F8F4EE]/10 rounded font-mono text-[10px] text-emerald-400 text-left space-y-1.5 min-h-[140px] shadow-inner select-none">
                  {printLogs.map((log, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -5 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="flex items-center gap-2"
                    >
                      <span className="text-[#D8A33A]">&gt;</span>
                      <span>{log}</span>
                    </motion.div>
                  ))}
                  {logIndex < logs.length && (
                    <div className="w-1.5 h-3 bg-emerald-400 animate-pulse inline-block" />
                  )}
                </div>
              </motion.div>
            )}

            {step === "success" && (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="py-6 flex flex-col items-center space-y-6"
              >
                <div className="w-14 h-14 bg-emerald-500/10 border border-emerald-500 rounded-full flex items-center justify-center text-emerald-400">
                  <Check className="w-6 h-6" />
                </div>
                <div className="text-center">
                  <h2 className="font-serif text-2xl tracking-wide text-white">Acquisition Complete</h2>
                  <p className="text-xs text-[#D8A33A] mt-1 font-mono uppercase tracking-widest">
                    Order Ref: LP-{(100000 + Math.floor(Math.random() * 900000))}
                  </p>
                  <p className="text-xs text-neutral-400 mt-2 max-w-md mx-auto">
                    A receipt has been dispatched to <strong className="text-[#F8F4EE]">{formData.email}</strong>. Our custom framing team is now assembling your timber crates.
                  </p>
                </div>

                {/* Cryptographic Certificate display */}
                <div className="w-full border border-[#D8A33A]/30 bg-[#081826]/60 p-6 space-y-4 rounded-none relative overflow-hidden max-w-md select-none shadow-xl">
                  {/* Watermark */}
                  <div className="absolute right-[-40px] bottom-[-40px] text-white/[0.02] transform -rotate-45 font-serif text-[100px] pointer-events-none select-none">
                    MUSEUM
                  </div>

                  <div className="text-center pb-3 border-b border-[#D8A33A]/20">
                    <h3 className="font-serif text-xs uppercase tracking-widest text-[#D8A33A]">Certificate of Authenticity</h3>
                    <p className="text-[9px] font-mono text-neutral-500 mt-1">CRYPTOGRAPHIC LEDGER DECREE</p>
                  </div>

                  <div className="space-y-2 text-[11px] font-mono text-neutral-400">
                    <div className="flex justify-between">
                      <span>Recipient:</span>
                      <span className="text-[#F8F4EE]">{formData.firstName} {formData.lastName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Curation Date:</span>
                      <span className="text-[#F8F4EE]">{new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Lab Signature:</span>
                      <span className="text-emerald-400 text-[10px] truncate max-w-[200px]">SHA256_0x5F43E2C99...A81B</span>
                    </div>
                    <div className="h-[1px] bg-[#D8A33A]/10 my-2" />
                    <div className="text-[10px] text-neutral-400 leading-relaxed italic text-center px-4">
                      \"This certificate registers a certified fine-art giclée print on archival 310gsm cotton Photo Rag paper. Micro-batch calibrated and signed under the authority of Liberty Prints Gallery.\"
                    </div>
                  </div>

                  <div className="flex justify-center pt-3 border-t border-[#D8A33A]/20 gap-4 text-[10px] font-mono text-[#D8A33A]">
                    <div className="flex items-center gap-1">
                      <FileText className="w-3.5 h-3.5" />
                      <span>Archival 100+ Years</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Printer className="w-3.5 h-3.5" />
                      <span>Calibrated Lab Print</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={onClose}
                  className="px-8 py-3 bg-[#D8A33A] hover:bg-[#D8A33A]/90 text-[#081826] font-semibold text-xs uppercase tracking-widest transition-all cursor-pointer"
                >
                  Return to Gallery
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right Column: Order Summary */}
        <div className="w-full md:w-80 p-6 md:p-8 bg-black/20 flex flex-col justify-between max-h-[40vh] md:max-h-none overflow-y-auto">
          <div>
            <h3 className="font-serif text-lg tracking-wide mb-4 text-[#F8F4EE]">Order Curation</h3>

            <div className="space-y-4">
              {cart.map((item) => {
                const itemBasePrice = item.product.basePrice;
                const itemPriceMod = item.selectedSize.priceModifier + item.selectedFrame.priceModifier;
                const unitPrice = (itemBasePrice + itemPriceMod) * currencyRate;
                const finalItemPrice = unitPrice * item.quantity;

                return (
                  <div key={item.id} className="flex gap-3 text-xs">
                    <img
                      src={item.product.imageMain}
                      alt={item.product.title}
                      referrerPolicy="no-referrer"
                      className="w-10 h-12 object-cover bg-neutral-900 border border-[#F8F4EE]/10 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-serif text-[#F8F4EE] truncate">{item.product.title}</h4>
                      <p className="text-[10px] text-neutral-400 font-mono mt-0.5 uppercase tracking-wider">{item.product.artist}</p>
                      <p className="text-[10px] text-neutral-400 mt-1">{item.quantity} × {item.selectedSize.name}</p>
                    </div>
                    <div className="font-mono text-neutral-300 self-center">
                      {currencySymbol}{finalItemPrice.toFixed(0)}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="border-t border-[#F8F4EE]/10 pt-4 mt-6 space-y-2 text-xs font-mono text-neutral-400">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>{currencySymbol}{subtotal.toFixed(0)}</span>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between text-emerald-400">
                <span>Discount</span>
                <span>-{currencySymbol}{discountVal.toFixed(0)}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span>Shipping</span>
              <span>{shipping === 0 ? "Complimentary" : `${currencySymbol}${shipping.toFixed(0)}`}</span>
            </div>
            <div className="h-[1px] bg-[#F8F4EE]/10 my-2" />
            <div className="flex justify-between text-sm font-serif font-bold text-[#F8F4EE]">
              <span>Grand Total</span>
              <span className="font-mono text-[#D8A33A]">{currencySymbol}{total.toFixed(0)}</span>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
