import { Product } from "../types";
import { X, Trash2, ShoppingBag } from "lucide-react";
import { motion } from "motion/react";

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlist: Product[];
  onRemoveFromWishlist: (product: Product) => void;
  onViewProduct: (product: Product) => void;
  currencySymbol: string;
  currencyRate: number;
}

export default function WishlistDrawer({
  isOpen,
  onClose,
  wishlist,
  onRemoveFromWishlist,
  onViewProduct,
  currencySymbol,
  currencyRate
}: WishlistDrawerProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-[#081826]/80 backdrop-blur-sm"
      />

      {/* Drawer content */}
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <motion.div
          initial={{ x: "100%" }}
          animate={{ x: 0 }}
          exit={{ x: "100%" }}
          transition={{ type: "spring", damping: 25, stiffness: 200 }}
          className="w-screen max-w-md glass flex flex-col h-full shadow-2xl text-[#F8F4EE]"
        >
          {/* Header */}
          <div className="p-6 border-b border-[#F8F4EE]/10 flex items-center justify-between">
            <div className="flex items-baseline gap-2">
              <h2 className="font-serif text-2xl tracking-wide">Your Curator Wishlist</h2>
              <span className="text-xs font-mono text-[#D8A33A]">
                ({wishlist.length} saved)
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-1 hover:text-[#D8A33A] transition-colors rounded-full hover:bg-white/5"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Wishlist items */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {wishlist.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-16 h-16 rounded-full border border-[#F8F4EE]/10 flex items-center justify-center text-neutral-500">
                  <X className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif text-lg tracking-wide text-[#F8F4EE]">Wishlist empty</h3>
                  <p className="text-xs text-neutral-400 mt-1 max-w-[240px]">
                    Curate your private gallery. Click the heart on your favorite prints to store them here.
                  </p>
                </div>
                <button
                  onClick={onClose}
                  className="px-6 py-2 border border-[#D8A33A] text-[#D8A33A] text-xs uppercase tracking-widest hover:bg-[#D8A33A] hover:text-[#081826] transition-all duration-300"
                >
                  Discover Masterpieces
                </button>
              </div>
            ) : (
              wishlist.map((product) => {
                const finalPrice = product.basePrice * currencyRate;

                return (
                  <div key={product.id} className="flex gap-4 pb-6 border-b border-[#F8F4EE]/5">
                    {/* Image thumb */}
                    <div className="relative w-20 h-24 bg-neutral-900 overflow-hidden shrink-0 border border-[#F8F4EE]/10">
                      <img
                        src={product.imageMain}
                        alt={product.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Info */}
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start gap-1">
                          <h4 className="font-serif text-sm tracking-wide line-clamp-1">
                            {product.title}
                          </h4>
                          <span className="font-mono text-xs text-[#D8A33A]">
                            {currencySymbol}
                            {finalPrice.toFixed(0)}
                          </span>
                        </div>
                        <p className="text-[10px] text-neutral-400 font-mono mt-0.5 uppercase tracking-wider">
                          By {product.artist}
                        </p>
                        <p className="text-xs text-neutral-400 mt-2 line-clamp-2">
                          {product.subtitle}
                        </p>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center justify-between mt-3">
                        <button
                          onClick={() => {
                            onClose();
                            onViewProduct(product);
                          }}
                          className="flex items-center gap-1 text-[11px] text-[#D8A33A] hover:text-white uppercase tracking-wider transition-colors"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Customize & Frame</span>
                        </button>

                        <button
                          onClick={() => onRemoveFromWishlist(product)}
                          className="p-1 text-neutral-500 hover:text-[#C86B28] transition-colors"
                          title="Remove from wishlist"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
