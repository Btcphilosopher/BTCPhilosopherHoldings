import React, { useState } from "react";
import { Product } from "../types";
import { Star, Heart, Eye, ArrowRight, MapPin, Sparkles } from "lucide-react";
import { motion } from "motion/react";

interface ProductCardProps {
  product: Product;
  onViewDetails: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  isWishlisted: boolean;
  currencySymbol: string;
  currencyRate: number;
  key?: React.Key;
}

export default function ProductCard({
  product,
  onViewDetails,
  onToggleWishlist,
  isWishlisted,
  currencySymbol,
  currencyRate
}: ProductCardProps) {
  const [hovered, setHovered] = useState(false);

  const finalPrice = product.basePrice * currencyRate;

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="group relative border border-[#F8F4EE]/10 bg-[#081826] flex flex-col justify-between overflow-hidden transition-all duration-500 hover:border-[#D8A33A]/40 hover:shadow-2xl hover:shadow-amber-500/5 glow-hover h-[480px]"
    >
      {/* 1. VISUAL WORK / MEDIA CONTAINER */}
      <div className="relative aspect-[4/5] overflow-hidden bg-neutral-950/40 border-b border-[#F8F4EE]/5">
        {/* Main image */}
        <img
          src={product.imageMain}
          alt={product.title}
          referrerPolicy="no-referrer"
          className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 ease-out ${hovered ? "scale-105 opacity-0" : "scale-100 opacity-100"}`}
        />

        {/* Secondary image (hover reveals) */}
        <img
          src={product.imageSecondary}
          alt={`${product.title} Alternate`}
          referrerPolicy="no-referrer"
          className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 ease-out ${hovered ? "scale-100 opacity-100" : "scale-95 opacity-0"}`}
        />

        {/* Cinematic dark frame mask */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/10 pointer-events-none" />

        {/* Limited edition ribbon */}
        {product.isLimited && (
          <div className="absolute top-3 left-3 z-10 bg-[#C86B28] text-white text-[8px] font-mono uppercase tracking-[0.2em] px-2.5 py-1 rounded-sm shadow-md flex items-center gap-1">
            <Sparkles className="w-2.5 h-2.5" />
            <span>Limited Run</span>
          </div>
        )}

        {/* Heart Wishlist Trigger */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-3 right-3 z-10 p-2 rounded-full backdrop-blur-md transition-all duration-300 shadow ${isWishlisted ? "bg-[#C86B28] text-white" : "bg-[#081826]/60 text-neutral-400 hover:text-white"}`}
        >
          <Heart className={`w-3.5 h-3.5 ${isWishlisted ? "fill-current" : ""}`} />
        </button>

        {/* Interactive hover overlay bar (View Details button trigger) */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 z-10">
          <button
            onClick={() => onViewDetails(product)}
            className="px-5 py-2.5 bg-[#D8A33A] hover:bg-[#D8A33A]/90 text-[#081826] font-semibold text-xs uppercase tracking-widest flex items-center gap-1.5 shadow-xl transition-all cursor-pointer"
          >
            <Eye className="w-4 h-4" />
            <span>Examine & Frame</span>
          </button>
        </div>

        {/* Geographic Stamp footer bar on image */}
        <div className="absolute bottom-2 left-3 z-10 flex items-center gap-1 text-[9px] font-mono text-neutral-300 tracking-wider">
          <MapPin className="w-3 h-3 text-[#D8A33A]" />
          <span>{product.location}</span>
        </div>
      </div>

      {/* 2. TEXT AND E-COMMERCE INFORMATION FOOTER */}
      <div className="p-5 flex-1 flex flex-col justify-between text-left relative bg-white/[0.01]">
        <div>
          {/* Rating, Title and Author */}
          <div className="flex items-center justify-between text-neutral-400 mb-1">
            <span className="text-[10px] font-mono uppercase tracking-widest text-[#D8A33A] font-semibold">
              {product.artist}
            </span>
            <div className="flex items-center gap-1 font-mono text-[9px]">
              <Star className="w-3 h-3 text-amber-400 fill-current" />
              <span>{product.rating}</span>
            </div>
          </div>

          <h3 className="font-serif text-base font-semibold text-white tracking-wide leading-tight line-clamp-1 group-hover:text-[#D8A33A] transition-colors">
            {product.title}
          </h3>
          <p className="text-[10px] text-neutral-400 font-sans mt-1 line-clamp-1">
            {product.subtitle}
          </p>
        </div>

        {/* Sizes and Frames Indicators previews */}
        <div className="mt-2.5 pt-2.5 border-t border-[#F8F4EE]/5 flex justify-between items-center text-[9px] font-mono text-neutral-500">
          <div>
            <span className="uppercase block text-[8px] tracking-wider mb-1 text-neutral-400">SIZES AVAILABLE</span>
            <span className="text-white block uppercase">S, M, L, XL</span>
          </div>
          <div className="text-right">
            <span className="uppercase block text-[8px] tracking-wider mb-1 text-neutral-400">TIMBER MATTING</span>
            <div className="flex justify-end gap-1">
              <span className="w-2 h-2 rounded-full bg-[#111] border border-white/20" title="Obsidian Maple" />
              <span className="w-2 h-2 rounded-full bg-[#AE8050] border border-white/20" title="Warm Oak" />
              <span className="w-2 h-2 rounded-full bg-[#D8A33A] border border-white/20" title="Gilded Gold" />
            </div>
          </div>
        </div>

        {/* Pricing Block and Customizer CTA */}
        <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-[#F8F4EE]/5">
          <div>
            <span className="text-[8px] font-mono text-neutral-400 uppercase tracking-widest block">CURATION PRICING</span>
            <span className="font-mono text-[#D8A33A] text-sm font-semibold">
              {currencySymbol}{finalPrice.toFixed(0)} <span className="text-[10px] text-neutral-500 font-normal">from</span>
            </span>
          </div>

          <button
            onClick={() => onViewDetails(product)}
            className="text-[9px] font-mono uppercase tracking-widest text-[#D8A33A] font-semibold border-b border-[#D8A33A]/30 hover:border-[#D8A33A] pb-0.5 transition-all flex items-center gap-1 group/btn cursor-pointer"
          >
            <span>Configure</span>
            <ArrowRight className="w-3 h-3 group-hover/btn:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </div>
  );
}
