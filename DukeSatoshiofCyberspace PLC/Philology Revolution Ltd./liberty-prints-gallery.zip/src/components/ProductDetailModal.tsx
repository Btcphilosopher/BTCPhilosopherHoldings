import React, { useState, useRef, useEffect } from "react";
import { Product, ProductFrame, ProductSize } from "../types";
import { PRODUCT_SIZES, PRODUCT_FRAMES, PRODUCTS } from "../data/products";
import { X, Heart, Star, ShoppingBag, Eye, Info, Calendar, User, Compass, HelpCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, size: ProductSize, frame: ProductFrame) => void;
  onToggleWishlist: (product: Product) => void;
  isWishlisted: boolean;
  currencySymbol: string;
  currencyRate: number;
  onViewProduct: (product: Product) => void;
}

export default function ProductDetailModal({
  product,
  isOpen,
  onClose,
  onAddToCart,
  onToggleWishlist,
  isWishlisted,
  currencySymbol,
  currencyRate,
  onViewProduct
}: ProductDetailModalProps) {
  if (!isOpen || !product) return null;

  const [selectedSize, setSelectedSize] = useState<ProductSize>(PRODUCT_SIZES[0]);
  const [selectedFrame, setSelectedFrame] = useState<ProductFrame>(PRODUCT_FRAMES[0]);
  const [activeImage, setActiveImage] = useState<"main" | "secondary">("main");
  const [viewTab, setViewTab] = useState<"detail" | "room">("detail");
  const [roomBackground, setRoomBackground] = useState<"living" | "office" | "bedroom">("living");
  const [zoomStyle, setZoomStyle] = useState({ display: "none", backgroundPosition: "0% 0%" });

  // Reset states when product changes
  useEffect(() => {
    setSelectedSize(PRODUCT_SIZES[0]);
    setSelectedFrame(PRODUCT_FRAMES[0]);
    setActiveImage("main");
    setViewTab("detail");
  }, [product]);

  const currentImage = activeImage === "main" ? product.imageMain : product.imageSecondary;
  const unitPrice = (product.basePrice + selectedSize.priceModifier + selectedFrame.priceModifier) * currencyRate;

  // Zoom effect logic
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
    const x = ((e.pageX - left - window.scrollX) / width) * 100;
    const y = ((e.pageY - top - window.scrollY) / height) * 100;
    setZoomStyle({
      display: "block",
      backgroundPosition: `${x}% ${y}%`
    });
  };

  const handleMouseLeave = () => {
    setZoomStyle({ display: "none", backgroundPosition: "0% 0%" });
  };

  // Get related products (same category, excluding current)
  const relatedProducts = PRODUCTS.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 2);

  // Room backgrounds metadata
  const rooms = {
    living: {
      url: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=80",
      artClass: "absolute left-1/2 top-[35%] -translate-x-1/2 -translate-y-1/2 w-48 md:w-60 shadow-2xl transition-all duration-300 pointer-events-none"
    },
    office: {
      url: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80",
      artClass: "absolute left-[45%] top-[25%] -translate-x-1/2 -translate-y-1/2 w-36 md:w-44 shadow-2xl transition-all duration-300 pointer-events-none"
    },
    bedroom: {
      url: "https://images.unsplash.com/photo-1616594039964-ae9021a400a0?auto=format&fit=crop&w=1200&q=80",
      artClass: "absolute left-1/2 top-[32%] -translate-x-1/2 -translate-y-1/2 w-40 md:w-48 shadow-2xl transition-all duration-300 pointer-events-none"
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-[#081826]/95 backdrop-blur-md"
      />

      {/* Modal Container */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-6xl glass rounded-none overflow-hidden z-10 flex flex-col lg:flex-row h-auto max-h-[92vh] text-[#F8F4EE] shadow-2xl border border-[#F8F4EE]/10"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 text-neutral-400 hover:text-white hover:bg-white/5 rounded-full transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left Column: Visual Explorer */}
        <div className="w-full lg:w-[55%] p-4 md:p-6 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-[#F8F4EE]/10 bg-black/10">
          {/* View Mode Tabs */}
          <div className="flex gap-4 mb-4 text-xs font-mono tracking-wider border-b border-[#F8F4EE]/10 pb-2">
            <button
              onClick={() => setViewTab("detail")}
              className={`pb-1 uppercase cursor-pointer flex items-center gap-1 ${viewTab === "detail" ? "text-[#D8A33A] border-b border-[#D8A33A] font-semibold" : "text-neutral-400"}`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Art Detail</span>
            </button>
            <button
              onClick={() => setViewTab("room")}
              className={`pb-1 uppercase cursor-pointer flex items-center gap-1 ${viewTab === "room" ? "text-[#D8A33A] border-b border-[#D8A33A] font-semibold" : "text-neutral-400"}`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Room Simulator</span>
            </button>
          </div>

          {/* Interactive Views */}
          <div className="flex-1 flex items-center justify-center relative min-h-[300px] md:min-h-[420px]">
            {viewTab === "detail" ? (
              /* Detail View with Interactive Magnifier and visual Frame Border! */
              <div className="relative flex flex-col items-center">
                {/* Visual dynamic frame outer container */}
                <div
                  onMouseMove={handleMouseMove}
                  onMouseLeave={handleMouseLeave}
                  className={`relative cursor-zoom-in max-w-sm md:max-w-md transition-all duration-300 ease-out select-none overflow-hidden ${selectedFrame.shadowClass}`}
                  style={{
                    backgroundColor: selectedFrame.colorHex,
                    borderColor: selectedFrame.borderColorHex,
                  }}
                >
                  <img
                    src={currentImage}
                    alt={product.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-auto object-contain transition-transform duration-300"
                  />

                  {/* Glass magnifier lens overlay */}
                  <div
                    className="absolute inset-0 pointer-events-none border border-white/20 shadow-inner"
                    style={{
                      ...zoomStyle,
                      backgroundImage: `url(${currentImage})`,
                      backgroundRepeat: "no-repeat",
                      backgroundSize: "200%"
                    }}
                  />
                </div>
                <p className="text-[10px] text-neutral-400 font-mono mt-4 uppercase tracking-widest text-center flex items-center gap-1.5 bg-white/5 px-2.5 py-1 rounded-full">
                  <Info className="w-3 h-3 text-[#D8A33A]" />
                  <span>Hover to inspect brushstrokes & paper textures</span>
                </p>
              </div>
            ) : (
              /* Room Simulator: Displays print mounted on wall */
              <div className="w-full h-full min-h-[350px] relative rounded overflow-hidden shadow-inner border border-[#F8F4EE]/10 select-none">
                <img
                  src={rooms[roomBackground].url}
                  alt={rooms[roomBackground].name}
                  className="w-full h-full object-cover brightness-75 transition-all duration-500"
                  referrerPolicy="no-referrer"
                />

                {/* Ambient vignette lighting overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 pointer-events-none" />

                {/* Framed Art rendering on wall in perspective */}
                <div
                  className={`${rooms[roomBackground].artClass} ${selectedFrame.shadowClass}`}
                  style={{
                    backgroundColor: selectedFrame.colorHex,
                    borderColor: selectedFrame.borderColorHex
                  }}
                >
                  <img
                    src={product.imageMain}
                    alt={product.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-auto"
                  />
                </div>

                {/* Room Switcher controls */}
                <div className="absolute bottom-4 left-4 z-10 flex gap-2">
                  {(["living", "office", "bedroom"] as const).map((r) => (
                    <button
                      key={r}
                      onClick={() => setRoomBackground(r)}
                      className={`px-2.5 py-1 text-[9px] font-mono uppercase tracking-wider rounded transition-all cursor-pointer ${roomBackground === r ? "bg-[#D8A33A] text-[#081826] font-bold" : "bg-[#081826]/80 text-white hover:bg-[#273746]"}`}
                    >
                      {r === "living" ? "Salon" : r === "office" ? "Office" : "Bedroom"}
                    </button>
                  ))}
                </div>

                <div className="absolute top-4 left-4 bg-black/60 backdrop-blur px-3 py-1 text-[10px] font-mono tracking-wide rounded text-[#D8A33A]">
                  Art scale is approximate. Shown in <strong className="text-white">{selectedSize.name}</strong>.
                </div>
              </div>
            )}
          </div>

          {/* Alternate thumbnail view controls for Detail tab */}
          {viewTab === "detail" && (
            <div className="flex justify-center gap-3 mt-4 border-t border-[#F8F4EE]/5 pt-4">
              <button
                onClick={() => setActiveImage("main")}
                className={`relative w-12 h-16 bg-neutral-900 border overflow-hidden rounded transition-all cursor-pointer ${activeImage === "main" ? "border-[#D8A33A]" : "border-transparent opacity-60"}`}
              >
                <img src={product.imageMain} alt="main thumbnail" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
              </button>
              <button
                onClick={() => setActiveImage("secondary")}
                className={`relative w-12 h-16 bg-neutral-900 border overflow-hidden rounded transition-all cursor-pointer ${activeImage === "secondary" ? "border-[#D8A33A]" : "border-transparent opacity-60"}`}
              >
                <img src={product.imageSecondary} alt="secondary thumbnail" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
              </button>
            </div>
          )}
        </div>

        {/* Right Column: Customizer & E-Commerce Panel */}
        <div className="flex-1 p-6 md:p-8 overflow-y-auto max-h-[85vh] lg:max-h-[92vh] flex flex-col justify-between">
          <div className="space-y-6">
            {/* Breadcrumb / category info */}
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#D8A33A]">
                Curation category: {product.category}
              </span>
              {product.isLimited && (
                <span className="bg-[#C86B28]/25 border border-[#C86B28]/45 px-2.5 py-0.5 text-[9px] font-mono text-amber-300 uppercase tracking-widest rounded-full animate-pulse">
                  Limited Edition: {product.printsLeft} / {product.totalLimitedPrints} prints left
                </span>
              )}
            </div>

            {/* Title & metadata */}
            <div>
              <h1 className="font-serif text-3xl tracking-wide text-white leading-tight">{product.title}</h1>
              <p className="text-sm text-[#D8A33A] italic font-serif mt-1">{product.subtitle}</p>

              <div className="flex items-center gap-6 mt-4 text-xs font-mono text-neutral-400 border-b border-[#F8F4EE]/10 pb-4">
                <span className="flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-[#D8A33A]" />
                  <span>{product.artist}</span>
                </span>
                <span className="flex items-center gap-1">
                  <Compass className="w-3.5 h-3.5 text-[#D8A33A]" />
                  <span>{product.location}</span>
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-[#D8A33A]" />
                  <span>{product.year}</span>
                </span>
              </div>
            </div>

            {/* Core Story Description */}
            <div>
              <p className="text-xs text-neutral-300 leading-relaxed font-sans">{product.description}</p>
            </div>

            {/* 1. Size Selection */}
            <div>
              <h3 className="block text-[10px] font-mono text-neutral-400 uppercase tracking-widest mb-2.5">
                01. SELECT ARCHIVAL SIZE
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {PRODUCT_SIZES.map((size) => (
                  <button
                    key={size.id}
                    onClick={() => setSelectedSize(size)}
                    className={`p-3 text-left border flex flex-col justify-between transition-all cursor-pointer ${selectedSize.id === size.id ? "bg-[#D8A33A]/10 border-[#D8A33A] text-white" : "border-[#F8F4EE]/10 hover:border-white/20 text-neutral-400 hover:text-white"}`}
                  >
                    <span className="text-xs font-semibold tracking-wide font-serif">{size.name}</span>
                    <span className="text-[10px] font-mono mt-1 text-neutral-500">{size.dimensions}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Framing Customization */}
            <div>
              <h3 className="block text-[10px] font-mono text-neutral-400 uppercase tracking-widest mb-2.5">
                02. CHOOSE TIMBER FRAME OR UNFRAMED
              </h3>
              <div className="space-y-2">
                {PRODUCT_FRAMES.map((frame) => (
                  <button
                    key={frame.id}
                    onClick={() => setSelectedFrame(frame)}
                    className={`w-full p-3 border flex items-center justify-between transition-all text-left cursor-pointer ${selectedFrame.id === frame.id ? "bg-[#D8A33A]/10 border-[#D8A33A] text-white" : "border-[#F8F4EE]/10 hover:border-white/20 text-neutral-400 hover:text-white"}`}
                  >
                    <div className="flex items-center gap-3">
                      {frame.colorHex !== "transparent" ? (
                        <span
                          className="w-4 h-4 rounded-full border border-white/20 shadow"
                          style={{ backgroundColor: frame.colorHex }}
                        />
                      ) : (
                        <span className="w-4 h-4 rounded-full border border-dashed border-neutral-400" />
                      )}
                      <div>
                        <span className="text-xs font-semibold font-serif block">{frame.name}</span>
                        <span className="text-[9px] font-mono text-neutral-500 uppercase tracking-wider">Handcrafted timber</span>
                      </div>
                    </div>
                    <span className="text-xs font-mono text-[#D8A33A]">
                      {frame.priceModifier === 0 ? "Included" : `+${currencySymbol}${(frame.priceModifier * currencyRate).toFixed(0)}`}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Real reviews overview */}
            <div className="border-t border-[#F8F4EE]/10 pt-4">
              <h4 className="text-xs font-mono text-neutral-400 uppercase tracking-widest mb-3">Collector Assessments</h4>
              {product.reviews.length === 0 ? (
                <p className="text-[11px] text-neutral-500 italic">No reviews yet for this print batch.</p>
              ) : (
                <div className="space-y-3">
                  {product.reviews.map((rev) => (
                    <div key={rev.id} className="text-[11px] bg-white/5 p-3 border border-white/5 rounded-none">
                      <div className="flex justify-between items-center text-neutral-400">
                        <span className="font-semibold">{rev.userName}</span>
                        <span className="font-mono text-[9px]">{rev.date}</span>
                      </div>
                      <div className="flex text-amber-400 my-1">
                        {Array.from({ length: rev.rating }).map((_, i) => (
                          <Star key={i} className="w-3 h-3 fill-current" />
                        ))}
                      </div>
                      <p className="text-neutral-300 font-sans mt-1 italic">"{rev.comment}"</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Related curation recommendations */}
            {relatedProducts.length > 0 && (
              <div className="border-t border-[#F8F4EE]/10 pt-4">
                <h4 className="text-xs font-mono text-neutral-400 uppercase tracking-widest mb-3">Related Curation Recommendations</h4>
                <div className="grid grid-cols-2 gap-3">
                  {relatedProducts.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => onViewProduct(p)}
                      className="group flex gap-2 text-left bg-[#273746]/20 hover:bg-[#273746]/40 p-2 border border-[#F8F4EE]/5 hover:border-[#D8A33A]/40 transition-all cursor-pointer"
                    >
                      <img src={p.imageMain} alt={p.title} referrerPolicy="no-referrer" className="w-10 h-12 object-cover shrink-0" />
                      <div className="min-w-0">
                        <h5 className="font-serif text-xs text-white truncate group-hover:text-[#D8A33A] transition-colors">{p.title}</h5>
                        <p className="text-[10px] text-neutral-400 font-mono truncate">{p.artist}</p>
                        <p className="text-[10px] text-[#D8A33A] font-mono mt-0.5">{currencySymbol}{(p.basePrice * currencyRate).toFixed(0)}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Pricing & Checkout bar */}
          <div className="border-t border-[#F8F4EE]/15 pt-6 mt-8 space-y-4">
            <div className="flex items-baseline justify-between">
              <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest">CALCULATED VALUE:</span>
              <div className="text-right">
                <span className="text-2xl font-serif font-bold text-[#D8A33A] tracking-wider">
                  {currencySymbol}
                  {unitPrice.toFixed(0)}
                </span>
                <span className="block text-[9px] font-mono text-neutral-500 uppercase tracking-wider mt-0.5">Complimentary express shipping</span>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => onAddToCart(product, selectedSize, selectedFrame)}
                className="flex-1 py-3 bg-[#D8A33A] hover:bg-[#D8A33A]/90 text-[#081826] font-semibold text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Acquire Art Print</span>
              </button>
              <button
                onClick={() => onToggleWishlist(product)}
                className={`px-4 border transition-all cursor-pointer flex items-center justify-center ${isWishlisted ? "border-[#C86B28] text-[#C86B28] bg-[#C86B28]/10" : "border-[#F8F4EE]/15 text-neutral-300 hover:text-white hover:bg-white/5"}`}
                title={isWishlisted ? "Remove from wishlist" : "Save to wishlist"}
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? "fill-current" : ""}`} />
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
