import { CartItem } from "../types";
import { X, Plus, Minus, Trash2, ShieldCheck, HelpCircle } from "lucide-react";
import { motion } from "motion/react";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  currency: "USD" | "EUR" | "GBP";
  currencySymbol: string;
  currencyRate: number;
  onUpdateQuantity: (cartItemId: string, newQuantity: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onCheckout: () => void;
  discountCode: string;
  setDiscountCode: (code: string) => void;
  discountAmount: number; // percentage, e.g. 20 for 20%
  onApplyDiscount: (code: string) => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cart,
  currency,
  currencySymbol,
  currencyRate,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
  discountCode,
  setDiscountCode,
  discountAmount,
  onApplyDiscount
}: CartDrawerProps) {
  if (!isOpen) return null;

  const getSubtotal = () => {
    return cart.reduce((sum, item) => {
      const itemBase = item.product.basePrice;
      const sizeMod = item.selectedSize.priceModifier;
      const frameMod = item.selectedFrame.priceModifier;
      const unitPrice = (itemBase + sizeMod + frameMod) * currencyRate;
      return sum + unitPrice * item.quantity;
    }, 0);
  };

  const subtotal = getSubtotal();
  const discountVal = subtotal * (discountAmount / 100);
  const shipping = subtotal > 150 * currencyRate ? 0 : 25 * currencyRate;
  const total = subtotal - discountVal + shipping;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-[#081826]/80 backdrop-blur-sm"
      />

      {/* Drawer content */}
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <motion.div
          initial={{ x: "100%" }}
          animate={{ x: 0 }}
          exit={{ x: "100%" }}
          transition={{ type: "spring", damping: 25, stiffness: 200 }}
          className="w-screen max-w-md glass flex flex-col h-full shadow-2xl text-[#F8F4EE]"
        >
          {/* Header */}
          <div className="p-6 border-b border-[#F8F4EE]/10 flex items-center justify-between">
            <div className="flex items-baseline gap-2">
              <h2 className="font-serif text-2xl tracking-wide">Your Salon Cart</h2>
              <span className="text-xs font-mono text-[#D8A33A]">
                ({cart.reduce((sum, i) => sum + i.quantity, 0)} items)
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-1 hover:text-[#D8A33A] transition-colors rounded-full hover:bg-white/5"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart items */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-16 h-16 rounded-full border border-[#F8F4EE]/10 flex items-center justify-center text-neutral-500">
                  <Plus className="w-6 h-6 rotate-45" />
                </div>
                <div>
                  <h3 className="font-serif text-lg tracking-wide text-[#F8F4EE]">No prints selected</h3>
                  <p className="text-xs text-neutral-400 mt-1 max-w-[240px]">
                    Your private collection is empty. Explore our masterworks to begin curation.
                  </p>
                </div>
                <button
                  onClick={onClose}
                  className="px-6 py-2 border border-[#D8A33A] text-[#D8A33A] text-xs uppercase tracking-widest hover:bg-[#D8A33A] hover:text-[#081826] transition-all duration-300"
                >
                  Explore Prints
                </button>
              </div>
            ) : (
              cart.map((item) => {
                const itemBasePrice = item.product.basePrice;
                const itemPriceMod = item.selectedSize.priceModifier + item.selectedFrame.priceModifier;
                const unitPrice = (itemBasePrice + itemPriceMod) * currencyRate;
                const finalItemPrice = unitPrice * item.quantity;

                return (
                  <div key={item.id} className="flex gap-4 pb-6 border-b border-[#F8F4EE]/5">
                    {/* Image thumb */}
                    <div className="relative w-20 h-24 bg-neutral-900 overflow-hidden shrink-0 border border-[#F8F4EE]/10">
                      <img
                        src={item.product.imageMain}
                        alt={item.product.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Info */}
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start gap-1">
                          <h4 className="font-serif text-sm tracking-wide line-clamp-1">
                            {item.product.title}
                          </h4>
                          <span className="font-mono text-xs text-[#D8A33A] whitespace-nowrap">
                            {currencySymbol}
                            {finalItemPrice.toFixed(0)}
                          </span>
                        </div>
                        <p className="text-[10px] text-neutral-400 font-mono mt-0.5 uppercase tracking-wider">
                          {item.product.artist}
                        </p>
                        <div className="mt-2 space-y-0.5">
                          <p className="text-[11px] text-neutral-400 flex justify-between">
                            <span>Size:</span>
                            <span className="text-[#F8F4EE]">{item.selectedSize.name}</span>
                          </p>
                          <p className="text-[11px] text-neutral-400 flex justify-between">
                            <span>Frame:</span>
                            <span className="text-[#D8A33A]">{item.selectedFrame.name}</span>
                          </p>
                        </div>
                      </div>

                      {/* Quantity & Delete */}
                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center border border-[#F8F4EE]/10 rounded overflow-hidden bg-white/5">
                          <button
                            onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                            className="p-1.5 hover:bg-white/5 text-neutral-400 hover:text-[#F8F4EE] transition-all"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-3 font-mono text-xs">{item.quantity}</span>
                          <button
                            onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                            className="p-1.5 hover:bg-white/5 text-neutral-400 hover:text-[#F8F4EE] transition-all"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <button
                          onClick={() => onRemoveItem(item.id)}
                          className="p-1 text-neutral-500 hover:text-[#C86B28] transition-colors"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer controls */}
          {cart.length > 0 && (
            <div className="p-6 border-t border-[#F8F4EE]/10 bg-[#081826]/90 space-y-4">
              {/* Promo code input */}
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="DISCOUNT CODE"
                  value={discountCode}
                  onChange={(e) => setDiscountCode(e.target.value.toUpperCase())}
                  className="flex-1 bg-[#273746]/50 border border-[#F8F4EE]/10 text-xs px-3 py-2 font-mono tracking-wider focus:outline-none focus:border-[#D8A33A] text-white"
                />
                <button
                  onClick={() => onApplyDiscount(discountCode)}
                  className="px-4 py-2 border border-[#D8A33A]/50 text-[#D8A33A] text-xs font-mono uppercase hover:bg-[#D8A33A]/10 transition-all cursor-pointer"
                >
                  Apply
                </button>
              </div>

              {discountAmount > 0 && (
                <div className="bg-emerald-950/30 border border-emerald-500/20 px-3 py-1.5 text-[11px] text-emerald-400 flex justify-between font-mono">
                  <span>Code Applied: -{discountAmount}%</span>
                  <span>-{currencySymbol}{(subtotal * (discountAmount / 100)).toFixed(0)}</span>
                </div>
              )}

              {/* Price list */}
              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between text-neutral-400">
                  <span>Subtotal</span>
                  <span>{currencySymbol}{subtotal.toFixed(0)}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Discount</span>
                    <span>-{currencySymbol}{discountVal.toFixed(0)}</span>
                  </div>
                )}
                <div className="flex justify-between text-neutral-400">
                  <span>Premium Insured Shipping</span>
                  <span>
                    {shipping === 0 ? (
                      <span className="text-emerald-400 uppercase text-[10px] tracking-wide">Complimentary</span>
                    ) : (
                      `${currencySymbol}${shipping.toFixed(0)}`
                    )}
                  </span>
                </div>
                <div className="h-[1px] bg-[#F8F4EE]/10 my-1" />
                <div className="flex justify-between text-sm font-serif font-semibold text-[#F8F4EE] leading-loose">
                  <span className="tracking-wide">Grand Collection Total</span>
                  <span className="font-mono text-[#D8A33A]">
                    {currencySymbol}
                    {total.toFixed(0)}
                  </span>
                </div>
              </div>

              {/* Checkout CTA */}
              <button
                onClick={onCheckout}
                className="w-full py-3 bg-[#D8A33A] hover:bg-[#D8A33A]/90 text-[#081826] font-semibold text-xs uppercase tracking-widest text-center shadow-lg transition-all cursor-pointer"
              >
                Secure Checkout
              </button>

              <div className="flex items-center justify-center gap-2 text-[10px] text-neutral-500 font-mono mt-2">
                <ShieldCheck className="w-3.5 h-3.5 text-[#D8A33A]" />
                <span>100% Archival Guaranteed. Secure SSL Gateways.</span>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
