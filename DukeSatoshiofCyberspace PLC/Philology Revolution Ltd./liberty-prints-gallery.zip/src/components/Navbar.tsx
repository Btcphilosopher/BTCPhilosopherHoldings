import { useState, useEffect } from "react";
import { Product, Collection } from "../types";
import { Search, Heart, ShoppingCart, User, ChevronDown, Sparkles, Star } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface NavbarProps {
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  currency: "USD" | "EUR" | "GBP";
  onCurrencyChange: (curr: "USD" | "EUR" | "GBP") => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSelectCategory: (category: string) => void;
  collections: Collection[];
  onScrollToSection: (elementId: string) => void;
}

export default function Navbar({
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  currency,
  onCurrencyChange,
  searchQuery,
  onSearchChange,
  onSelectCategory,
  collections,
  onScrollToSection
}: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [activeMegaMenu, setActiveMegaMenu] = useState<"collections" | "explore" | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 w-full z-40 transition-all duration-500 border-b ${isScrolled ? "glass shadow-2xl py-4" : "bg-[#081826]/40 backdrop-blur-md border-[#F8F4EE]/10 py-6"}`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-8 flex items-center justify-between">
        {/* Left: Brand Logo & Emblem */}
        <button
          onClick={() => onScrollToSection("hero")}
          className="flex items-center gap-3 text-left focus:outline-none group cursor-pointer"
        >
          {/* Subtle elegant classical vector-like silhouette representation */}
          <div className="w-10 h-10 rounded-full border border-[#D8A33A]/40 flex items-center justify-center text-[#D8A33A] bg-[#081826]/30 group-hover:border-[#D8A33A] transition-all duration-500 shadow-inner">
            <span className="font-serif text-lg tracking-widest font-semibold">L</span>
          </div>
          <div>
            <span className="block font-sans text-sm font-light tracking-[0.2em] text-[#F8F4EE] uppercase group-hover:text-[#D8A33A] transition-colors">
              Atelier <span className="text-[#D8A33A] font-medium">Liberty</span>
            </span>
            <span className="block text-[7px] font-mono tracking-[0.35em] text-[#D8A33A] uppercase mt-0.5">
              FINE ART PRINTS
            </span>
          </div>
        </button>

        {/* Center: Desktop Navigation Links & Mega Menus */}
        <nav className="hidden lg:flex items-center gap-8 text-xs font-mono tracking-widest text-neutral-300">
          {/* Collections with Mega Menu Trigger */}
          <div
            className="relative"
            onMouseEnter={() => setActiveMegaMenu("collections")}
            onMouseLeave={() => setActiveMegaMenu(null)}
          >
            <button className="hover:text-white pb-2 pt-2 transition-colors flex items-center gap-1 cursor-pointer">
              <span>Collections</span>
              <ChevronDown className={`w-3 h-3 transition-transform duration-300 ${activeMegaMenu === "collections" ? "rotate-180 text-[#D8A33A]" : ""}`} />
            </button>

            {/* Mega Menu Dropdown */}
            <AnimatePresence>
              {activeMegaMenu === "collections" && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  transition={{ duration: 0.2 }}
                  className="absolute top-full left-[-150px] w-[600px] glass p-6 shadow-2xl rounded-none border border-[#F8F4EE]/10 flex gap-6"
                >
                  <div className="flex-1 space-y-3">
                    <h4 className="text-[10px] text-[#D8A33A] uppercase tracking-widest font-bold border-b border-[#F8F4EE]/10 pb-1.5 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Curation Series</span>
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                      {collections.map((col) => (
                        <button
                          key={col.id}
                          onClick={() => {
                            onSelectCategory(col.slug);
                            setActiveMegaMenu(null);
                            onScrollToSection("gallery");
                          }}
                          className="text-left py-1.5 px-2 hover:bg-white/5 hover:text-[#D8A33A] transition-all rounded text-xs block truncate"
                        >
                          {col.name}
                        </button>
                      ))}
                      <button
                        onClick={() => {
                          onSelectCategory("all");
                          setActiveMegaMenu(null);
                          onScrollToSection("gallery");
                        }}
                        className="text-left py-1.5 px-2 hover:bg-white/5 text-[#D8A33A] font-bold transition-all rounded text-xs block border border-[#D8A33A]/20"
                      >
                        All Masterworks
                      </button>
                    </div>
                  </div>

                  {/* Featured editorial promo */}
                  <div className="w-52 bg-black/30 border border-[#F8F4EE]/5 p-3 rounded flex flex-col justify-between">
                    <div>
                      <span className="bg-[#C86B28]/20 border border-[#C86B28]/30 px-1.5 py-0.5 text-[8px] font-mono text-amber-300 uppercase tracking-widest rounded-full">
                        Curator Spotlight
                      </span>
                      <h5 className="font-serif text-sm mt-2 text-white leading-tight">Aetherial Dawn Series</h5>
                      <p className="text-[10px] text-neutral-400 mt-1.5 leading-relaxed line-clamp-2">
                        Archival pigment oil textures from Florence, Italy.
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        onSelectCategory("nature");
                        setActiveMegaMenu(null);
                        onScrollToSection("gallery");
                      }}
                      className="text-[9px] text-[#D8A33A] uppercase tracking-wider font-bold mt-2 text-left hover:underline"
                    >
                      Acquire Limited Runs →
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <button
            onClick={() => onScrollToSection("about")}
            className="hover:text-white cursor-pointer transition-colors relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] after:bg-[#D8A33A] hover:after:w-full after:transition-all after:duration-300"
          >
            Our Story
          </button>
          <button
            onClick={() => onScrollToSection("how-printing-works")}
            className="hover:text-white cursor-pointer transition-colors relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] after:bg-[#D8A33A] hover:after:w-full after:transition-all after:duration-300"
          >
            Museum Materials
          </button>
          <button
            onClick={() => onScrollToSection("editorial")}
            className="hover:text-white cursor-pointer transition-colors relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] after:bg-[#D8A33A] hover:after:w-full after:transition-all after:duration-300"
          >
            Editorial Blog
          </button>
          <button
            onClick={() => onScrollToSection("corporate")}
            className="hover:text-white cursor-pointer transition-colors relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] after:bg-[#D8A33A] hover:after:w-full after:transition-all after:duration-300"
          >
            Trade Desk
          </button>
        </nav>

        {/* Right: Search, Currency, Wishlist, Cart & Controls */}
        <div className="flex items-center gap-4">
          {/* Integrated Search Input bar */}
          <div className="hidden sm:flex items-center bg-[#273746]/30 border border-[#F8F4EE]/10 px-3 py-1.5 hover:border-white/20 transition-all focus-within:border-[#D8A33A] focus-within:ring-1 focus-within:ring-[#D8A33A]/30">
            <Search className="w-3.5 h-3.5 text-neutral-400 mr-2" />
            <input
              type="text"
              placeholder="SEARCH GALLERY..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="bg-transparent text-[10px] font-mono tracking-wider focus:outline-none w-28 md:w-40 text-white placeholder-neutral-500"
            />
          </div>

          {/* Currency Switcher */}
          <select
            value={currency}
            onChange={(e) => onCurrencyChange(e.target.value as "USD" | "EUR" | "GBP")}
            className="bg-[#273746]/50 border border-[#F8F4EE]/10 rounded text-[10px] font-mono p-1 h-7 text-[#D8A33A] focus:outline-none focus:border-[#D8A33A] cursor-pointer"
          >
            <option value="USD">USD ($)</option>
            <option value="EUR">EUR (€)</option>
            <option value="GBP">GBP (£)</option>
          </select>

          {/* Wishlist Heart Icon with Count Badge */}
          <button
            onClick={onOpenWishlist}
            className="relative p-1.5 text-neutral-300 hover:text-[#C86B28] transition-colors rounded-full hover:bg-white/5 cursor-pointer"
            title="Open Curation Wishlist"
          >
            <Heart className="w-4 h-4" />
            {wishlistCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#C86B28] text-white text-[8px] font-mono w-4 h-4 rounded-full flex items-center justify-center font-bold shadow animate-pulse">
                {wishlistCount}
              </span>
            )}
          </button>

          {/* Cart Icon with Count Badge */}
          <button
            onClick={onOpenCart}
            className="relative p-1.5 text-neutral-300 hover:text-[#D8A33A] transition-colors rounded-full hover:bg-white/5 cursor-pointer"
            title="Open Cart"
          >
            <ShoppingCart className="w-4 h-4" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#D8A33A] text-[#081826] text-[8px] font-mono w-4 h-4 rounded-full flex items-center justify-center font-bold shadow animate-pulse">
                {cartCount}
              </span>
            )}
          </button>

          {/* Mobile menu burger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 text-neutral-300 hover:text-white cursor-pointer"
          >
            <div className="w-5 h-4 flex flex-col justify-between">
              <span className="block h-[1.5px] w-full bg-current transition-all duration-300" />
              <span className="block h-[1.5px] w-full bg-current transition-all duration-300" />
              <span className="block h-[1.5px] w-full bg-current transition-all duration-300" />
            </div>
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden border-t border-[#F8F4EE]/10 bg-[#081826]/95 backdrop-blur-lg px-6 py-4 space-y-3 font-mono text-xs text-neutral-300"
          >
            {/* Mobile Search */}
            <div className="flex items-center bg-[#273746]/50 border border-[#F8F4EE]/10 px-3 py-2">
              <Search className="w-3.5 h-3.5 text-neutral-400 mr-2" />
              <input
                type="text"
                placeholder="SEARCH PRINTS..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="bg-transparent text-[10px] font-mono tracking-wider focus:outline-none w-full text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 pb-2">
              {collections.map((col) => (
                <button
                  key={col.id}
                  onClick={() => {
                    onSelectCategory(col.slug);
                    setMobileMenuOpen(false);
                    onScrollToSection("gallery");
                  }}
                  className="text-left p-2 bg-white/5 hover:text-[#D8A33A] rounded text-[11px]"
                >
                  {col.name}
                </button>
              ))}
            </div>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onScrollToSection("about");
              }}
              className="block w-full text-left py-2 hover:text-[#D8A33A]"
            >
              Our Story
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onScrollToSection("how-printing-works");
              }}
              className="block w-full text-left py-2 hover:text-[#D8A33A]"
            >
              Museum Quality Materials
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onScrollToSection("editorial");
              }}
              className="block w-full text-left py-2 hover:text-[#D8A33A]"
            >
              Editorial Blog
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onScrollToSection("corporate");
              }}
              className="block w-full text-left py-2 hover:text-[#D8A33A]"
            >
              Corporate Advisory
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
