import { Compass, Landmark, Heart, Shield, HelpCircle } from "lucide-react";

interface FooterProps {
  onScrollToSection: (elementId: string) => void;
  onSelectCategory: (category: string) => void;
}

export default function Footer({ onScrollToSection, onSelectCategory }: FooterProps) {
  return (
    <footer className="bg-[#081826] border-t border-[#F8F4EE]/10 text-neutral-400 font-mono text-[11px] pt-16 pb-8 relative">
      <div className="max-w-7xl mx-auto px-6 md:px-8 grid grid-cols-1 md:grid-cols-12 gap-10 border-b border-[#F8F4EE]/5 pb-12">
        {/* Column 1: Brand info */}
        <div className="md:col-span-4 space-y-4 text-left">
          <button
            onClick={() => onScrollToSection("hero")}
            className="flex items-center gap-2 text-left text-white focus:outline-none group cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full border border-[#D8A33A]/30 flex items-center justify-center text-[#D8A33A] bg-[#081826] group-hover:border-[#D8A33A] transition-colors">
              <span className="font-serif text-sm font-semibold">L</span>
            </div>
            <div>
              <span className="block font-serif text-sm font-bold tracking-[0.2em] leading-none uppercase">Liberty</span>
              <span className="block text-[7px] tracking-[0.35em] text-[#D8A33A] uppercase mt-0.5">Prints Gallery</span>
            </div>
          </button>
          <p className="font-sans text-xs text-neutral-400 leading-relaxed max-w-sm">
            An award-winning online art gallery dedicated to museum-grade, certified fine art prints. We celebrate freedom, tactile truth, and atmospheric depth. Handcrafted with precision in our partner workshops.
          </p>
          {/* Social icons links placeholders styled to perfection */}
          <div className="flex gap-4 pt-2">
            <a href="#instagram" className="hover:text-[#D8A33A] transition-colors">INSTAGRAM</a>
            <span>/</span>
            <a href="#pinterest" className="hover:text-[#D8A33A] transition-colors">PINTEREST</a>
            <span>/</span>
            <a href="#facebook" className="hover:text-[#D8A33A] transition-colors">FACEBOOK</a>
          </div>
        </div>

        {/* Column 2: Shop links */}
        <div className="md:col-span-2 text-left space-y-3">
          <h4 className="text-[9px] font-bold text-white uppercase tracking-widest border-b border-[#F8F4EE]/5 pb-1">Shop Curation</h4>
          <ul className="space-y-1.5 font-mono">
            <li>
              <button
                onClick={() => {
                  onSelectCategory("all");
                  onScrollToSection("gallery");
                }}
                className="hover:text-[#D8A33A] transition-colors cursor-pointer text-[10px]"
              >
                All Art Prints
              </button>
            </li>
            <li>
              <button
                onClick={() => {
                  onSelectCategory("landmarks");
                  onScrollToSection("gallery");
                }}
                className="hover:text-[#D8A33A] transition-colors cursor-pointer text-[10px]"
              >
                Best Sellers
              </button>
            </li>
            <li>
              <button
                onClick={() => {
                  onSelectCategory("nature");
                  onScrollToSection("gallery");
                }}
                className="hover:text-[#D8A33A] transition-colors cursor-pointer text-[10px]"
              >
                New Releases
              </button>
            </li>
            <li>
              <button
                onClick={() => {
                  onSelectCategory("abstract");
                  onScrollToSection("gallery");
                }}
                className="hover:text-[#D8A33A] transition-colors cursor-pointer text-[10px]"
              >
                Collector Editions
              </button>
            </li>
          </ul>
        </div>

        {/* Column 3: Help links */}
        <div className="md:col-span-2 text-left space-y-3">
          <h4 className="text-[9px] font-bold text-white uppercase tracking-widest border-b border-[#F8F4EE]/5 pb-1">Assistance Desk</h4>
          <ul className="space-y-1.5 font-mono text-[10px]">
            <li><button onClick={() => onScrollToSection("faqs")} className="hover:text-[#D8A33A] transition-colors">Frequently Queried FAQs</button></li>
            <li><a href="#shipping" className="hover:text-[#D8A33A] transition-colors">Insured Shipping Policy</a></li>
            <li><a href="#returns" className="hover:text-[#D8A33A] transition-colors">30-Day Luxury Returns</a></li>
            <li><a href="#tracking" className="hover:text-[#D8A33A] transition-colors">Track Order Delivery</a></li>
          </ul>
        </div>

        {/* Column 4: About links */}
        <div className="md:col-span-2 text-left space-y-3">
          <h4 className="text-[9px] font-bold text-white uppercase tracking-widest border-b border-[#F8F4EE]/5 pb-1">The Gallery</h4>
          <ul className="space-y-1.5 font-mono text-[10px]">
            <li><button onClick={() => onScrollToSection("about")} className="hover:text-[#D8A33A] transition-colors">Our Founding Guild</button></li>
            <li><button onClick={() => onScrollToSection("how-printing-works")} className="hover:text-[#D8A33A] transition-colors">Archival Certification</button></li>
            <li><button onClick={() => onScrollToSection("artists")} className="hover:text-[#D8A33A] transition-colors">Licensed Collaborators</button></li>
            <li><button onClick={() => onScrollToSection("corporate")} className="hover:text-[#D8A33A] transition-colors">Corporate Consults</button></li>
          </ul>
        </div>

        {/* Column 5: visual mockup print representation */}
        <div className="md:col-span-2 flex flex-col items-center md:items-end justify-center">
          <div className="w-24 h-28 border-8 border-[#111] shadow-xl relative overflow-hidden bg-neutral-900 shrink-0">
            <img
              src="/src/assets/images/golden_gate_sunset_1784217448780.jpg"
              alt="gilded prints logo background"
              className="w-full h-full object-cover filter brightness-[0.6]"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-[#D8A33A]/5 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Underfooter bottom legal */}
      <div className="max-w-7xl mx-auto px-6 md:px-8 pt-6 flex flex-col md:flex-row items-center justify-between gap-4 font-mono text-[9px] text-neutral-500 uppercase tracking-widest">
        <span>© 2026 Liberty Prints Gallery Ltd. All rights reserved.</span>
        <div className="flex gap-4">
          <a href="#privacy" className="hover:text-[#D8A33A] transition-all">Privacy Ledger Decree</a>
          <span>•</span>
          <a href="#terms" className="hover:text-[#D8A33A] transition-all">Terms of Curation Services</a>
        </div>
      </div>
    </footer>
  );
}
