import { useState, useMemo } from "react";
import { Product, Collection } from "../types";
import { PRODUCTS, COLLECTIONS } from "../data/products";
import ProductCard from "./ProductCard";
import { SlidersHorizontal, Grid, ToggleLeft, ToggleRight, Sparkles, RefreshCw } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface GalleryExplorerProps {
  onViewProductDetails: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  wishlist: Product[];
  currencySymbol: string;
  currencyRate: number;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
}

export default function GalleryExplorer({
  onViewProductDetails,
  onToggleWishlist,
  wishlist,
  currencySymbol,
  currencyRate,
  searchQuery,
  onSearchChange,
  selectedCategory,
  onSelectCategory
}: GalleryExplorerProps) {
  const [sortBy, setSortBy] = useState<"featured" | "price-asc" | "price-desc" | "rating">("featured");
  const [limitedOnly, setLimitedOnly] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  const itemsPerPage = 6;

  // Filter and sort products
  const filteredAndSortedProducts = useMemo(() => {
    let result = [...PRODUCTS];

    // Search filter
    if (searchQuery.trim() !== "") {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.title.toLowerCase().includes(query) ||
          p.artist.toLowerCase().includes(query) ||
          p.subtitle.toLowerCase().includes(query) ||
          p.location.toLowerCase().includes(query)
      );
    }

    // Category filter
    if (selectedCategory !== "all") {
      result = result.filter((p) => p.category === selectedCategory);
    }

    // Limited edition filter
    if (limitedOnly) {
      result = result.filter((p) => p.isLimited);
    }

    // Sorting
    switch (sortBy) {
      case "price-asc":
        result.sort((a, b) => a.basePrice - b.basePrice);
        break;
      case "price-desc":
        result.sort((a, b) => b.basePrice - a.basePrice);
        break;
      case "rating":
        result.sort((a, b) => b.rating - a.rating);
        break;
      case "featured":
      default:
        // Featured first, then alphabetical or base sorting
        result.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
        break;
    }

    return result;
  }, [searchQuery, selectedCategory, limitedOnly, sortBy]);

  // Pagination bounds
  const paginatedProducts = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredAndSortedProducts.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredAndSortedProducts, currentPage]);

  const totalPages = Math.ceil(filteredAndSortedProducts.length / itemsPerPage);

  const handleResetFilters = () => {
    onSearchChange("");
    onSelectCategory("all");
    setLimitedOnly(false);
    setSortBy("featured");
    setCurrentPage(1);
  };

  const wishlistIds = useMemo(() => new Set(wishlist.map((w) => w.id)), [wishlist]);

  return (
    <section id="gallery" className="py-24 bg-[#081826] relative border-t border-[#F8F4EE]/5">
      <div className="absolute top-[10%] left-0 w-[30vw] h-[30vw] rounded-full glow-spot-orange pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-8">
        {/* Title */}
        <div className="mb-12 text-left">
          <span className="text-xs font-mono text-[#D8A33A] uppercase tracking-[0.35em] block font-semibold">
            Fine Art Exhibition
          </span>
          <h2 className="font-serif text-3xl md:text-4xl text-[#F8F4EE] tracking-wide mt-2">
            The Masterwork Print Catalogue
          </h2>
          <p className="text-sm text-neutral-400 mt-2 max-w-xl font-sans">
            Giclée pigment inkworks printed on heavy cotton-fiber paper, hand-numbered and certified under direct consultation.
          </p>
        </div>

        {/* Filters and Controls Bar */}
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-6 bg-white/[0.01] border border-[#F8F4EE]/10 p-5 md:p-6 mb-10">
          {/* Categories Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 overflow-x-auto pb-2 xl:pb-0 select-none">
            <button
              onClick={() => {
                onSelectCategory("all");
                setCurrentPage(1);
              }}
              className={`px-3.5 py-1.5 text-xs font-mono tracking-wider transition-all cursor-pointer ${selectedCategory === "all" ? "bg-[#D8A33A] text-[#081826] font-bold" : "text-neutral-400 hover:text-white hover:bg-white/5"}`}
            >
              All Prints
            </button>
            {COLLECTIONS.map((col) => (
              <button
                key={col.id}
                onClick={() => {
                  onSelectCategory(col.slug);
                  setCurrentPage(1);
                }}
                className={`px-3.5 py-1.5 text-xs font-mono tracking-wider transition-all cursor-pointer ${selectedCategory === col.slug ? "bg-[#D8A33A] text-[#081826] font-bold" : "text-neutral-400 hover:text-white hover:bg-white/5"}`}
              >
                {col.name}
              </button>
            ))}
          </div>

          {/* Right Filters, Sorts and Toggles */}
          <div className="flex flex-wrap items-center gap-6 text-xs font-mono text-neutral-400">
            {/* Limited editions only toggle */}
            <button
              onClick={() => {
                setLimitedOnly(!limitedOnly);
                setCurrentPage(1);
              }}
              className="flex items-center gap-2 hover:text-[#D8A33A] transition-colors cursor-pointer select-none"
            >
              <span>Limited Runs Only</span>
              {limitedOnly ? (
                <ToggleRight className="w-5 h-5 text-[#D8A33A]" />
              ) : (
                <ToggleLeft className="w-5 h-5 text-neutral-600" />
              )}
            </button>

            {/* Sorting Dropdown */}
            <div className="flex items-center gap-2 border-l border-[#F8F4EE]/10 pl-6">
              <SlidersHorizontal className="w-3.5 h-3.5 text-neutral-500" />
              <span>Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => {
                  setSortBy(e.target.value as any);
                  setCurrentPage(1);
                }}
                className="bg-[#273746]/50 border border-[#F8F4EE]/10 rounded px-2 py-1 text-[#D8A33A] focus:outline-none focus:border-[#D8A33A] h-7 cursor-pointer"
              >
                <option value="featured">Featured First</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="rating">Collector Rating</option>
              </select>
            </div>
          </div>
        </div>

        {/* Active Filters Display */}
        {(selectedCategory !== "all" || searchQuery !== "" || limitedOnly) && (
          <div className="flex flex-wrap items-center gap-3 mb-8 text-xs font-mono text-[#D8A33A]">
            <span className="text-neutral-400">Active filters:</span>
            {selectedCategory !== "all" && (
              <span className="bg-white/5 border border-[#F8F4EE]/10 px-3 py-1 text-[11px]">
                Category: <strong className="text-white uppercase">{selectedCategory}</strong>
              </span>
            )}
            {searchQuery !== "" && (
              <span className="bg-white/5 border border-[#F8F4EE]/10 px-3 py-1 text-[11px]">
                Search: <strong className="text-white">"{searchQuery}"</strong>
              </span>
            )}
            {limitedOnly && (
              <span className="bg-white/5 border border-[#F8F4EE]/10 px-3 py-1 text-[11px] flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-[#D8A33A]" />
                <strong className="text-white">Limited Edition Only</strong>
              </span>
            )}

            <button
              onClick={handleResetFilters}
              className="text-neutral-400 hover:text-white underline cursor-pointer hover:no-underline flex items-center gap-1.5 ml-auto text-[11px]"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset All Curation Filters</span>
            </button>
          </div>
        )}

        {/* Art Card Grid */}
        {paginatedProducts.length === 0 ? (
          <div className="py-20 border border-[#F8F4EE]/5 text-center space-y-4">
            <h3 className="font-serif text-xl text-[#F8F4EE]">No matching masterpieces found</h3>
            <p className="text-xs text-neutral-400 max-w-sm mx-auto">
              We couldn't locate any prints with your current selections. Adjust your search or clear filters to view catalog.
            </p>
            <button
              onClick={handleResetFilters}
              className="px-6 py-2 border border-[#D8A33A] text-[#D8A33A] text-xs uppercase tracking-widest hover:bg-[#D8A33A] hover:text-[#081826] transition-all duration-300"
            >
              Clear All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {paginatedProducts.map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                onViewDetails={onViewProductDetails}
                onToggleWishlist={onToggleWishlist}
                isWishlisted={wishlistIds.has(p.id)}
                currencySymbol={currencySymbol}
                currencyRate={currencyRate}
              />
            ))}
          </div>
        )}

        {/* Elegant Pagination Indicators */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between border-t border-[#F8F4EE]/10 pt-8 mt-12 text-xs font-mono text-neutral-400">
            <span>
              Showing Page <strong className="text-white">{currentPage}</strong> of <strong className="text-white">{totalPages}</strong>
            </span>
            <div className="flex gap-2">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage((p) => p - 1)}
                className={`px-4 py-2 border uppercase tracking-wider transition-all cursor-pointer ${currentPage === 1 ? "border-[#F8F4EE]/5 text-neutral-600 cursor-not-allowed" : "border-[#F8F4EE]/10 text-neutral-300 hover:text-[#D8A33A] hover:border-[#D8A33A]/50 bg-white/[0.01]"}`}
              >
                Previous
              </button>
              <button
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage((p) => p + 1)}
                className={`px-4 py-2 border uppercase tracking-wider transition-all cursor-pointer ${currentPage === totalPages ? "border-[#F8F4EE]/5 text-neutral-600 cursor-not-allowed" : "border-[#F8F4EE]/10 text-neutral-300 hover:text-[#D8A33A] hover:border-[#D8A33A]/50 bg-white/[0.01]"}`}
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
