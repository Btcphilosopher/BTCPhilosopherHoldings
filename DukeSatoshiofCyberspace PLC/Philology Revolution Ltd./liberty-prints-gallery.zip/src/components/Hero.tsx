import { useState, useEffect, useRef } from "react";
import { ArrowRight, Compass, ShieldCheck } from "lucide-react";
import { motion } from "motion/react";

interface HeroProps {
  onExploreClick: () => void;
  onAboutClick: () => void;
}

export default function Hero({ onExploreClick, onAboutClick }: HeroProps) {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  // Parallax tracking
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      const { left, top, width, height } = containerRef.current.getBoundingClientRect();
      const x = (e.clientX - left - width / 2) / 35; // sensitivity factor
      const y = (e.clientY - top - height / 2) / 35;
      setMousePosition({ x, y });
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <section
      ref={containerRef}
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#081826] pt-24 md:pt-32 pb-16 px-6 md:px-8"
    >
      {/* 1. LAYERED GRADIENT LIGHTING & AMBIENT GLOWS */}
      <div className="absolute top-[15%] left-[20%] w-[50vw] h-[50vw] rounded-full glow-spot-gold pointer-events-none select-none" />
      <div className="absolute bottom-[20%] right-[10%] w-[60vw] h-[60vw] rounded-full glow-spot-orange pointer-events-none select-none" />

      {/* 2. FLOATING AMBIENT LIGHT PARTICLES */}
      <div className="absolute inset-0 pointer-events-none select-none">
        {Array.from({ length: 15 }).map((_, i) => {
          const size = Math.random() * 4 + 2;
          const delay = Math.random() * 10;
          const duration = Math.random() * 8 + 6;
          const left = Math.random() * 100;
          const top = Math.random() * 100;

          return (
            <span
              key={i}
              className="absolute bg-[#D8A33A]/25 rounded-full blur-[1px] animate-pulse"
              style={{
                width: `${size}px`,
                height: `${size}px`,
                left: `${left}%`,
                top: `${top}%`,
                animationDelay: `${delay}s`,
                animationDuration: `${duration}s`
              }}
            />
          );
        })}
      </div>

      {/* 3. HERO CONTENT CONTAINER (with parallax) */}
      <div className="relative max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center z-10 w-full">
        {/* Left text block */}
        <div className="lg:col-span-7 flex flex-col space-y-8 text-left">
          <div className="space-y-4">
            <span className="text-[#D8A33A] text-xs uppercase tracking-[0.3em] font-bold block mb-1">
              Curated Exhibition • Series 04
            </span>
            <h1 className="font-serif text-5xl md:text-6xl lg:text-7xl text-white leading-[1.1] tracking-tight">
              Freedom. <br />
              <span className="italic text-[#F8F4EE]/90">Beauty.</span> & <br />
              <span className="text-[#D8A33A]">Perspective.</span>
            </h1>
          </div>

          <p className="text-[#F8F4EE]/70 text-base md:text-lg leading-relaxed max-w-xl font-light font-sans">
            A atmospheric exploration of light, form, and horizons. Museum-quality fine art prints inspired by iconic natural wonders, masterfully printed on archival cotton rag, finished under sustainable hardwood frames.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-wrap items-center gap-8 pt-2">
            <button
              onClick={onExploreClick}
              className="bg-[#D8A33A] text-[#081826] px-10 py-5 rounded-sm font-semibold tracking-widest uppercase text-[12px] shadow-2xl hover:bg-[#F8F4EE] hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
            >
              Explore Masterworks
            </button>

            <button
              onClick={onAboutClick}
              className="flex items-center gap-3 group cursor-pointer"
            >
              <span className="w-12 h-12 rounded-full border border-[#F8F4EE]/30 flex items-center justify-center group-hover:border-[#D8A33A] transition-all duration-300">
                <Compass className="w-4 h-4 text-[#D8A33A] group-hover:rotate-45 transition-transform duration-500" />
              </span>
              <span className="text-[11px] uppercase tracking-widest opacity-70 group-hover:opacity-100 transition-opacity">
                Our Printing Guild
              </span>
            </button>
          </div>

          {/* Core assurances metrics representation styled as the theme */}
          <div className="pt-12 flex flex-wrap gap-12 border-t border-[#F8F4EE]/10">
            <div className="flex flex-col">
              <span className="text-[26px] font-serif text-white tracking-wide">300g</span>
              <span className="text-[10px] uppercase tracking-wider text-neutral-400 mt-1">Archival Rag Paper</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[26px] font-serif text-white tracking-wide">100+ Yrs</span>
              <span className="text-[10px] uppercase tracking-wider text-neutral-400 mt-1">Lightfast Guarantee</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[26px] font-serif text-white tracking-wide">Handmade</span>
              <span className="text-[10px] uppercase tracking-wider text-neutral-400 mt-1">Hardwood Framing</span>
            </div>
          </div>
        </div>

        {/* Right artwork showcase (Parallax movement reacts to mouse position) */}
        <div className="lg:col-span-5 flex justify-center lg:justify-end">
          <div
            className="relative w-80 md:w-96 aspect-[3/4] transition-transform duration-300 ease-out"
            style={{
              transform: `translate3d(${mousePosition.x}px, ${mousePosition.y}px, 0px) rotateX(${-mousePosition.y / 2}deg) rotateY(${mousePosition.x / 2}deg)`
            }}
          >
            {/* Themed Luxury Frame Overlay */}
            <div className="absolute inset-0 p-4 bg-[#0A1D2D] shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)] border border-[#D8A33A]/20 transform rotate-2">
              <div className="relative w-full h-full bg-gradient-to-br from-[#122a3d] via-[#081826] to-[#273746] overflow-hidden flex items-center justify-center">
                {/* Radial golden glow spotlight */}
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,_rgba(216,163,58,0.22),transparent_70%)] pointer-events-none" />

                {/* Main fine art image */}
                <img
                  src="/src/assets/images/hero_coastal_art_1784217431645.jpg"
                  alt="Aetherial Coastal Dawn"
                  className="w-full h-full object-cover opacity-85 transition-transform duration-700 hover:scale-105 cursor-zoom-in brightness-[0.8] contrast-105"
                  referrerPolicy="no-referrer"
                />

                {/* Ambient matting frame visual accent */}
                <div className="absolute inset-4 border border-[#D8A33A]/20 pointer-events-none" />

                {/* Absolute Bottom Title bar */}
                <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-[#081826] to-transparent">
                  <div className="text-[9px] tracking-[0.4em] uppercase text-[#D8A33A] mb-1 font-mono">AVAILABLE FOR PURCHASE</div>
                  <div className="text-xs tracking-widest uppercase font-serif text-[#F8F4EE]">Aetherial Coastal Dawn No. 04</div>
                </div>
              </div>
            </div>

            {/* Price Badge float indicator */}
            <div className="absolute -bottom-6 -left-6 w-32 h-32 border border-[#F8F4EE]/15 rounded-full flex items-center justify-center backdrop-blur-xl bg-white/5 shadow-2xl z-20">
              <div className="text-center">
                <div className="text-[9px] uppercase tracking-widest opacity-50 font-mono text-neutral-300">FROM</div>
                <div className="text-base font-serif text-[#D8A33A] mt-0.5">$320</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative scroll indicator */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-neutral-400 select-none">
        <span className="text-[9px] font-mono tracking-[0.25em] uppercase text-neutral-500">Curation Catalogue</span>
        <div className="w-[1.5px] h-10 bg-gradient-to-b from-neutral-500 to-transparent relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-4 bg-[#D8A33A] animate-bounce" />
        </div>
      </div>
    </section>
  );
}
