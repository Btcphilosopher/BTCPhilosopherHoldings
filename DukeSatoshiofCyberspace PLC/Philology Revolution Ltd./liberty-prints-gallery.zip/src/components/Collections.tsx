import { Collection } from "../types";
import { Milestone, Compass, Building2, Sparkles, Hourglass, Landmark, ChevronRight } from "lucide-react";

interface CollectionsProps {
  collections: Collection[];
  onSelectCategory: (category: string) => void;
  onScrollToSection: (elementId: string) => void;
}

export default function Collections({ collections, onSelectCategory, onScrollToSection }: CollectionsProps) {
  // Map icons dynamically
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "Milestone":
        return <Landmark className="w-5 h-5 text-[#D8A33A]" />;
      case "Compass":
        return <Compass className="w-5 h-5 text-[#D8A33A]" />;
      case "Building2":
        return <Building2 className="w-5 h-5 text-[#D8A33A]" />;
      case "Sparkles":
        return <Sparkles className="w-5 h-5 text-[#D8A33A]" />;
      case "Hourglass":
        return <Hourglass className="w-5 h-5 text-[#D8A33A]" />;
      default:
        return <Compass className="w-5 h-5 text-[#D8A33A]" />;
    }
  };

  return (
    <section id="collections" className="py-24 bg-[#081826]/90 relative border-t border-[#F8F4EE]/5">
      <div className="absolute top-[30%] right-0 w-[40vw] h-[40vw] rounded-full glow-spot-gold pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6 text-left">
          <div>
            <span className="text-xs font-mono text-[#D8A33A] uppercase tracking-[0.25em] font-semibold">
              Curated Curation series
            </span>
            <h2 className="font-serif text-3xl md:text-4xl text-[#F8F4EE] tracking-wide mt-2">
              Shop by Collections
            </h2>
          </div>
          <p className="text-xs text-neutral-400 font-mono uppercase tracking-wider max-w-sm">
            Each series features works united by specific atmospheric palettes, historical weights, and artistic disciplines.
          </p>
        </div>

        {/* Collections Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {collections.map((col) => (
            <button
              key={col.id}
              onClick={() => {
                onSelectCategory(col.slug);
                onScrollToSection("gallery");
              }}
              className="group relative h-96 overflow-hidden border border-[#F8F4EE]/10 bg-[#081826] flex flex-col justify-end p-6 text-left hover:border-[#D8A33A]/50 transition-all duration-500 hover:shadow-2xl hover:shadow-[#D8A33A]/5 cursor-pointer"
            >
              {/* Image background */}
              <div className="absolute inset-0 z-0">
                <img
                  src={col.image}
                  alt={col.name}
                  className="w-full h-full object-cover transition-transform duration-700 ease-out scale-100 group-hover:scale-110 filter brightness-[0.5] group-hover:brightness-[0.4]"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Dynamic warm gradient lighting */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#081826] via-[#081826]/40 to-transparent z-1 pointer-events-none" />

              {/* Icon Container */}
              <div className="relative z-10 w-10 h-10 rounded-full bg-[#081826]/80 border border-[#F8F4EE]/10 flex items-center justify-center mb-4 transition-all duration-300 group-hover:border-[#D8A33A] group-hover:shadow-lg">
                {getIcon(col.icon)}
              </div>

              {/* Content */}
              <div className="relative z-10 space-y-2">
                <h3 className="font-serif text-xl font-bold text-white tracking-wide group-hover:text-[#D8A33A] transition-colors flex items-center gap-1.5">
                  <span>{col.name}</span>
                  <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
                </h3>
                <p className="text-neutral-400 text-[11px] leading-relaxed line-clamp-3">
                  {col.description}
                </p>
                <div className="pt-2">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-[#D8A33A] border-b border-[#D8A33A]/30 group-hover:border-[#D8A33A] pb-0.5 transition-all">
                    Shop collection
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
