import React, { useState } from 'react';
import { 
  Database, 
  PlusCircle, 
  TrendingUp, 
  Users, 
  BookOpen, 
  Settings, 
  Trash2, 
  Edit, 
  Calendar, 
  CheckCircle,
  BarChart2,
  DollarSign,
  Package,
  FileText
} from 'lucide-react';
import { Book, Category, Event } from '../types';

interface CMSProps {
  books: Book[];
  categories: Category[];
  events: Event[];
  onAddBook: (newBook: Book) => void;
  onUpdateInventory: (bookId: string, newQty: number) => void;
  onAddEvent: (newEvent: Event) => void;
  onDeleteBook: (bookId: string) => void;
}

export default function CMS({
  books,
  categories,
  events,
  onAddBook,
  onUpdateInventory,
  onAddEvent,
  onDeleteBook
}: CMSProps) {
  // CMS view state
  const [cmsTab, setCmsTab] = useState<'dashboard' | 'books' | 'events'>('dashboard');

  // New Book form state
  const [bookForm, setBookForm] = useState({
    title: '',
    author: '',
    authorBio: 'סופר וחוקר ישראלי בולט ומעמיק.',
    category: 'philosophy',
    publisher: 'הוצאת ספר חכמה',
    publishDate: '2026',
    price: 85,
    coverUrl: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=400',
    description: 'ספר הגות מרתק השואב את השראתו מהמקורות היהודיים הקלאסיים.',
    tableOfContents: 'מבוא שער האמונה,שער היצירה,פרק ג סיכום',
    isbn: '978-965-7281-99-9',
    pageCount: 220,
    language: 'עברית',
    isRare: false,
    inventory: 15,
    tags: 'הגות,חדש'
  });

  // New Event form state
  const [eventForm, setEventForm] = useState({
    title: '',
    speaker: '',
    date: '2026-08-30',
    time: '19:00',
    location: 'סניף ספר חכמה, ירושלים',
    description: 'ערב מיוחד להעמקה והרמת כוסית.',
    ticketPrice: 0,
    seatsTotal: 100
  });

  const [notification, setNotification] = useState<string | null>(null);

  // Stats calculation
  const totalBooksCount = books.length;
  const totalInventoryCount = books.reduce((sum, b) => sum + b.inventory, 0);
  const totalMembersCount = 248; // mock steady count
  const estimatedSalesVolume = 18450; // mock total sales volume in ILS

  const handleBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookForm.title || !bookForm.author) return;

    const newBook: Book = {
      id: (books.length + 1).toString(),
      title: bookForm.title,
      author: bookForm.author,
      authorBio: bookForm.authorBio,
      category: bookForm.category,
      publisher: bookForm.publisher,
      publishDate: bookForm.publishDate,
      price: Number(bookForm.price),
      rating: 5.0,
      reviewsCount: 0,
      reviews: [],
      coverUrl: bookForm.coverUrl || 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=400',
      description: bookForm.description,
      tableOfContents: bookForm.tableOfContents.split(','),
      isbn: bookForm.isbn,
      pageCount: Number(bookForm.pageCount),
      language: bookForm.language,
      isRare: bookForm.isRare,
      isEbook: true, // newly added through CMS are available in ebook
      inventory: Number(bookForm.inventory),
      tags: bookForm.tags.split(',')
    };

    onAddBook(newBook);
    setNotification(`הספר "${bookForm.title}" התווסף בהצלחה למלאי החנות!`);
    
    // reset form
    setBookForm({
      title: '',
      author: '',
      authorBio: 'סופר וחוקר ישראלי בולט ומעמיק.',
      category: 'philosophy',
      publisher: 'הוצאת ספר חכמה',
      publishDate: '2026',
      price: 85,
      coverUrl: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=400',
      description: 'ספר הגות מרתק השואב את השראתו מהמקורות היהודיים הקלאסיים.',
      tableOfContents: 'מבוא שער האמונה,שער היצירה,פרק ג סיכום',
      isbn: '978-965-7281-99-9',
      pageCount: 220,
      language: 'עברית',
      isRare: false,
      inventory: 15,
      tags: 'הגות,חדש'
    });

    setTimeout(() => setNotification(null), 3500);
  };

  const handleEventSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventForm.title || !eventForm.speaker) return;

    const newEvent: Event = {
      id: 'e' + (events.length + 1),
      title: eventForm.title,
      speaker: eventForm.speaker,
      date: eventForm.date,
      time: eventForm.time,
      location: eventForm.location,
      description: eventForm.description,
      imageUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=400',
      ticketPrice: Number(eventForm.ticketPrice),
      seatsTotal: Number(eventForm.seatsTotal),
      seatsAvailable: Number(eventForm.seatsTotal),
      type: 'lecture'
    };

    onAddEvent(newEvent);
    setNotification(`האירוע "${eventForm.title}" תוכנת בהצלחה בסניף!`);
    
    setEventForm({
      title: '',
      speaker: '',
      date: '2026-08-30',
      time: '19:00',
      location: 'סניף ספר חכמה, ירושלים',
      description: 'ערב מיוחד להעמקה והרמת כוסית.',
      ticketPrice: 0,
      seatsTotal: 100
    });

    setTimeout(() => setNotification(null), 3500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" dir="rtl">
      
      {/* Intro Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#EAE2D8] pb-6 mb-8">
        <div>
          <h3 className="text-3xl font-serif font-black text-[#0A1D37]">ניהול ספריית ספר חכמה</h3>
          <p className="text-neutral-500 text-sm font-sans mt-1">מערכת קצה (Headless CMS) לניהול קטלוגים, עדכוני מלאי, דוחות מכירות ואירועים תרבותיים.</p>
        </div>

        {/* Tab switch control */}
        <div className="flex gap-2 text-xs font-sans">
          {[
            { id: 'dashboard', label: 'לוח בקרה ודוחות', icon: BarChart2 },
            { id: 'books', label: 'ניהול ספרים ומלאי', icon: Database },
            { id: 'events', label: 'תזמון אירועים', icon: Calendar }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setCmsTab(tab.id as any)}
                className={`px-4 py-2 rounded-lg border font-semibold flex items-center gap-1.5 transition-all ${
                  cmsTab === tab.id 
                    ? 'bg-[#0A1D37] text-white border-[#0A1D37]' 
                    : 'bg-[#FAF7F2] border-[#EAE2D8] text-neutral-600 hover:bg-[#F5EFEB]'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Action Notification */}
      {notification && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl flex items-center gap-2 text-xs font-sans mb-6">
          <CheckCircle className="h-5 w-5 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* Tab content screens */}
      {cmsTab === 'dashboard' ? (
        /* TAB 1: Analytical Dashboard reports */
        <div className="space-y-8">
          
          {/* Analytical Bento Boxes KPIs (Non-nested elegant grid) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            <div className="bg-[#FAF7F2] border border-[#EAE2D8] rounded-xl p-5 space-y-1.5 text-right">
              <div className="flex justify-between items-center text-[#B8976C]">
                <span className="text-xs font-serif font-bold">מחזור מכירות חודשי (סימולטור)</span>
                <DollarSign className="h-5 w-5" />
              </div>
              <strong className="text-2xl font-bold text-[#0A1D37] font-mono block">₪{estimatedSalesVolume}</strong>
              <span className="text-[10px] text-emerald-600 font-sans block">↑ 12% מהחודש שעבר</span>
            </div>

            <div className="bg-[#FAF7F2] border border-[#EAE2D8] rounded-xl p-5 space-y-1.5 text-right">
              <div className="flex justify-between items-center text-[#B8976C]">
                <span className="text-xs font-serif font-bold">ספרים פעילים בקטלוג</span>
                <BookOpen className="h-5 w-5" />
              </div>
              <strong className="text-2xl font-bold text-[#0A1D37] font-sans block">{totalBooksCount} כותרים</strong>
              <span className="text-[10px] text-neutral-400 font-sans block">מתוכם {books.filter(b => b.isRare).length} נדירים</span>
            </div>

            <div className="bg-[#FAF7F2] border border-[#EAE2D8] rounded-xl p-5 space-y-1.5 text-right">
              <div className="flex justify-between items-center text-[#B8976C]">
                <span className="text-xs font-serif font-bold">סה״כ עותקים במלאי</span>
                <Package className="h-5 w-5" />
              </div>
              <strong className="text-2xl font-bold text-[#0A1D37] font-sans block">{totalInventoryCount} עותקים</strong>
              <span className="text-[10px] text-neutral-400 font-sans block">בכל {categories.length} מחלקות הספרייה</span>
            </div>

            <div className="bg-[#FAF7F2] border border-[#EAE2D8] rounded-xl p-5 space-y-1.5 text-right">
              <div className="flex justify-between items-center text-[#B8976C]">
                <span className="text-xs font-serif font-bold">קהילת חברים רשומים</span>
                <Users className="h-5 w-5" />
              </div>
              <strong className="text-2xl font-bold text-[#0A1D37] font-sans block">{totalMembersCount} חברים</strong>
              <span className="text-[10px] text-emerald-600 font-sans block">מתוכם 85% מנויים שנתיים</span>
            </div>

          </div>

          {/* Simulated chart / ratio bar */}
          <div className="bg-white border border-[#EAE2D8] rounded-2xl p-6 shadow-sm space-y-4">
            <h4 className="font-serif font-bold text-[#0A1D37] text-base border-b pb-2">חלוקת מכירות לפי מחלקות</h4>
            
            <div className="space-y-4 text-xs font-sans">
              {[
                { category: 'מחשבה והגות יהודית', percent: 45, color: 'bg-[#0A1D37]' },
                { category: 'ספרי קודש ותורה', percent: 25, color: 'bg-[#B8976C]' },
                { category: 'ספרות עברית וישראלית', percent: 18, color: 'bg-[#3E2723]' },
                { category: 'שירה ופיוט', percent: 7, color: 'bg-[#3B413C]' },
                { category: 'מהדורות נדירות ומתנות', percent: 5, color: 'bg-neutral-400' }
              ].map((item, idx) => (
                <div key={idx} className="space-y-1.5 text-right">
                  <div className="flex justify-between text-[#222]">
                    <span className="font-semibold">{item.category}</span>
                    <span className="font-mono">{item.percent}% מהמכירות</span>
                  </div>
                  <div className="h-2 w-full bg-neutral-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-500" style={{ width: `${item.percent}%`, backgroundColor: item.color === 'bg-[#0A1D37]' ? '#0A1D37' : item.color === 'bg-[#B8976C]' ? '#B8976C' : item.color === 'bg-[#3E2723]' ? '#3E2723' : '#777' }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      ) : cmsTab === 'books' ? (
        /* TAB 2: Book Catalog & Form management */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* LHS: Live Book management form (5 cols) */}
          <div className="lg:col-span-5 bg-white border border-[#EAE2D8] rounded-2xl p-6 shadow-sm text-right">
            <h4 className="font-serif font-black text-lg text-[#0A1D37] border-b pb-2 mb-4 flex items-center gap-1.5">
              <PlusCircle className="h-5 w-5 text-[#B8976C]" />
              <span>הוספת ספר חדש לקטלוג</span>
            </h4>

            <form onSubmit={handleBookSubmit} className="space-y-3 text-xs font-sans text-neutral-700">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-500 mb-1">שם הספר</label>
                  <input
                    type="text"
                    required
                    value={bookForm.title}
                    onChange={e => setBookForm({ ...bookForm, title: e.target.value })}
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none"
                    placeholder="שיר השירים המבואר"
                  />
                </div>
                <div>
                  <label className="block text-neutral-500 mb-1">מחבר</label>
                  <input
                    type="text"
                    required
                    value={bookForm.author}
                    onChange={e => setBookForm({ ...bookForm, author: e.target.value })}
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none"
                    placeholder="שלמה המלך"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-500 mb-1">קטגוריה</label>
                  <select
                    value={bookForm.category}
                    onChange={e => setBookForm({ ...bookForm, category: e.target.value })}
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.id}>{c.nameHe}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-neutral-500 mb-1">מחיר (₪)</label>
                  <input
                    type="number"
                    required
                    value={bookForm.price}
                    onChange={e => setBookForm({ ...bookForm, price: Number(e.target.value) })}
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-500 mb-1">כמות ראשונית במלאי</label>
                  <input
                    type="number"
                    required
                    value={bookForm.inventory}
                    onChange={e => setBookForm({ ...bookForm, inventory: Number(e.target.value) })}
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none font-mono"
                  />
                </div>
                <div className="pt-6 flex items-center gap-1.5">
                  <input
                    type="checkbox"
                    id="isRareCms"
                    checked={bookForm.isRare}
                    onChange={e => setBookForm({ ...bookForm, isRare: e.target.checked })}
                    className="accent-[#B8976C] h-4 w-4"
                  />
                  <label htmlFor="isRareCms" className="font-serif font-bold cursor-pointer">מהדורה נדירה</label>
                </div>
              </div>

              <div>
                <label className="block text-neutral-500 mb-1">תיאור הספר ותקציר הגותי</label>
                <textarea
                  required
                  rows={2}
                  value={bookForm.description}
                  onChange={e => setBookForm({ ...bookForm, description: e.target.value })}
                  className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-500 mb-1">מסת״ב (ISBN)</label>
                  <input
                    type="text"
                    value={bookForm.isbn}
                    onChange={e => setBookForm({ ...bookForm, isbn: e.target.value })}
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none font-mono text-left"
                  />
                </div>
                <div>
                  <label className="block text-neutral-500 mb-1">כתובת תמונת כריכה (URL)</label>
                  <input
                    type="text"
                    value={bookForm.coverUrl}
                    onChange={e => setBookForm({ ...bookForm, coverUrl: e.target.value })}
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none text-left"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#0A1D37] text-[#FAF7F2] hover:bg-[#B8976C] rounded-lg font-sans font-bold transition-all shadow-sm cursor-pointer"
              >
                הוסף ספר והעלה לקטלוג החנות 🚀
              </button>
            </form>
          </div>

          {/* RHS: Interactive inventory table manager (7 cols) */}
          <div className="lg:col-span-7 bg-white border border-[#EAE2D8] rounded-2xl p-5 shadow-sm space-y-4">
            <h4 className="font-serif font-bold text-base text-[#0A1D37] border-b pb-2">ניהול רשומות ספרים ומלאים פעילים</h4>
            
            <div className="overflow-x-auto max-h-[500px]">
              <table className="w-full text-right text-xs font-sans divide-y divide-neutral-100">
                <thead className="bg-[#FAF7F2] text-neutral-500">
                  <tr>
                    <th className="p-2.5 font-semibold">הכותר</th>
                    <th className="p-2.5 font-semibold">מחיר</th>
                    <th className="p-2.5 font-semibold">מלאי שוטף</th>
                    <th className="p-2.5 font-semibold text-center">פעולות</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-50 text-[#222]">
                  {books.map(book => (
                    <tr key={book.id} className="hover:bg-[#FCFAF7] transition-colors">
                      <td className="p-2.5">
                        <strong className="text-[#0A1D37] block font-serif">{book.title}</strong>
                        <span className="text-[10px] text-neutral-400 font-sans">{book.author}</span>
                      </td>
                      <td className="p-2.5 font-mono">₪{book.price}</td>
                      <td className="p-2.5">
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => onUpdateInventory(book.id, Math.max(0, book.inventory - 1))}
                            className="px-1.5 py-0.5 rounded bg-neutral-100 hover:bg-neutral-200"
                          >
                            -
                          </button>
                          <span className={`font-mono font-bold ${book.inventory <= 5 ? 'text-red-600' : 'text-neutral-800'}`}>{book.inventory}</span>
                          <button
                            onClick={() => onUpdateInventory(book.id, book.inventory + 1)}
                            className="px-1.5 py-0.5 rounded bg-neutral-100 hover:bg-neutral-200"
                          >
                            +
                          </button>
                        </div>
                      </td>
                      <td className="p-2.5 text-center">
                        <button
                          onClick={() => onDeleteBook(book.id)}
                          className="p-1 text-neutral-400 hover:text-red-600 transition-colors"
                          title="מחק כותר מהקטלוג"
                        >
                          <Trash2 className="h-4 w-4 mx-auto" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      ) : (
        /* TAB 3: Event Scheduling wizard */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* LHS: Register Event Form (5 cols) */}
          <div className="lg:col-span-5 bg-white border border-[#EAE2D8] rounded-2xl p-6 shadow-sm text-right">
            <h4 className="font-serif font-black text-lg text-[#0A1D37] border-b pb-2 mb-4">תזמון מפגש ספרותי חדש</h4>
            
            <form onSubmit={handleEventSubmit} className="space-y-3.5 text-xs font-sans text-neutral-700">
              <div>
                <label className="block text-neutral-500 mb-1">שם האירוע / נושא השיחה</label>
                <input
                  type="text"
                  required
                  value={eventForm.title}
                  onChange={e => setEventForm({ ...eventForm, title: e.target.value })}
                  className="w-full p-2.5 border border-[#EAE2D8] rounded-lg bg-[#FAF7F2] outline-none"
                  placeholder="שיח משוררים בעקבות זלדה"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-500 mb-1">מרצה / אורח כבוד</label>
                  <input
                    type="text"
                    required
                    value={eventForm.speaker}
                    onChange={e => setEventForm({ ...eventForm, speaker: e.target.value })}
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none"
                    placeholder="פרופ׳ חביבה פדיה"
                  />
                </div>
                <div>
                  <label className="block text-neutral-500 mb-1">תאריך</label>
                  <input
                    type="date"
                    required
                    value={eventForm.date}
                    onChange={e => setEventForm({ ...eventForm, date: e.target.value })}
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-500 mb-1">שעה</label>
                  <input
                    type="text"
                    required
                    value={eventForm.time}
                    onChange={e => setEventForm({ ...eventForm, time: e.target.value })}
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none"
                  />
                </div>
                <div>
                  <label className="block text-neutral-500 mb-1">עלות כרטיס (₪)</label>
                  <input
                    type="number"
                    required
                    value={eventForm.ticketPrice}
                    onChange={e => setEventForm({ ...eventForm, ticketPrice: Number(e.target.value) })}
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-500 mb-1">מיקום (סניף)</label>
                  <input
                    type="text"
                    required
                    value={eventForm.location}
                    onChange={e => setEventForm({ ...eventForm, location: e.target.value })}
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none"
                  />
                </div>
                <div>
                  <label className="block text-neutral-500 mb-1">סך הכל מושבים אקוסטיים</label>
                  <input
                    type="number"
                    required
                    value={eventForm.seatsTotal}
                    onChange={e => setEventForm({ ...eventForm, seatsTotal: Number(e.target.value) })}
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-neutral-500 mb-1">תקציר ותיאור המפגש</label>
                <textarea
                  rows={3}
                  required
                  value={eventForm.description}
                  onChange={e => setEventForm({ ...eventForm, description: e.target.value })}
                  className="w-full p-2.5 border border-[#EAE2D8] rounded-lg bg-[#FAF7F2] outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#0A1D37] text-white hover:bg-[#B8976C] rounded-lg font-sans font-bold transition-all shadow-sm cursor-pointer"
              >
                פרסם אירוע ופתח הרשמת כרטיסים 📅
              </button>
            </form>
          </div>

          {/* RHS: Active events lists (7 cols) */}
          <div className="lg:col-span-7 bg-white border border-[#EAE2D8] rounded-2xl p-5 shadow-sm space-y-4">
            <h4 className="font-serif font-bold text-base text-[#0A1D37] border-b pb-2">רשימת אירועי תרבות פעילים</h4>
            
            <div className="space-y-3">
              {events.map(ev => (
                <div key={ev.id} className="bg-[#FAF7F2] border border-[#EAE2D8] p-4 rounded-xl flex justify-between items-center text-xs font-sans text-[#222]">
                  <div className="text-right space-y-1">
                    <strong className="text-[#0A1D37] font-serif text-sm block">{ev.title}</strong>
                    <p className="text-neutral-500">מרצה: {ev.speaker} | סניף: {ev.location}</p>
                    <p className="text-neutral-400">תאריך: {ev.date} בשעה {ev.time}</p>
                  </div>
                  <div className="text-left">
                    <span className="px-2.5 py-1 bg-white border border-[#EAE2D8] text-[10px] font-bold rounded text-[#B8976C] block text-center">
                      ₪{ev.ticketPrice === 0 ? 'חינם לחברים' : ev.ticketPrice}
                    </span>
                    <span className="text-[9px] text-neutral-400 block mt-1 text-center">{ev.seatsAvailable} מושבים נותרו</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
