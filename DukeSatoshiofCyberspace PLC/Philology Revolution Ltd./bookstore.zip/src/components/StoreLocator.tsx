import React, { useState } from 'react';
import { 
  MapPin, 
  Clock, 
  Phone, 
  Car, 
  Accessibility, 
  Calendar, 
  Info, 
  Navigation,
  Compass,
  ArrowRight
} from 'lucide-react';
import { StoreLocation } from '../types';

interface StoreLocatorProps {
  locations: StoreLocation[];
  onBackToHome: () => void;
}

export default function StoreLocator({ locations, onBackToHome }: StoreLocatorProps) {
  const [selectedLoc, setSelectedLoc] = useState<StoreLocation>(locations[0]);

  // Extended list of mock locations to represent major Israeli hubs
  const allCitiesList = [
    { id: 'jerusalem', label: 'ירושלים (סניף ראשי)', coords: { top: '55%', right: '58%' } },
    { id: 'tel_aviv', label: 'תל אביב (אטלייה רוטשילד)', coords: { top: '48%', right: '40%' } },
    { id: 'haifa', label: 'חיפה (אטלייה הכרמל)', coords: { top: '22%', right: '45%' } },
    { id: 'beersheva', label: 'באר שבע (קונספט נגב)', coords: { top: '75%', right: '48%' } },
    { id: 'modiin', label: 'מודיעין (סלון ספרים)', coords: { top: '52%', right: '50%' } },
    { id: 'bneibrak', label: 'בני ברק (ארכיון וכתבי יד)', coords: { top: '47%', right: '43%' } }
  ];

  const handleCityPinClick = (cityId: string) => {
    // Find matching store location, default to current if not provisioned in database
    const found = locations.find(loc => loc.id === cityId || loc.cityEn.toLowerCase().replace(' ', '_') === cityId);
    if (found) {
      setSelectedLoc(found);
    } else {
      // Simulate/mock new store data
      const mockNewLoc: StoreLocation = {
        id: cityId,
        city: cityId === 'beersheva' ? 'באר שבע' : cityId === 'modiin' ? 'מודיעין' : 'בני ברק',
        cityEn: cityId,
        name: `ספר חכמה - ${cityId === 'beersheva' ? 'סלון הנגב החדש' : cityId === 'modiin' ? 'סלון מודיעין' : 'ארכיון בני ברק'}`,
        address: cityId === 'beersheva' ? 'שדרות רגר 12, באר שבע' : cityId === 'modiin' ? 'רחוב דם המכבים 5, מודיעין' : 'רחוב חזון איש 10, בני ברק',
        phone: '08-9124412',
        hours: [
          'ימים א׳-ה׳: 09:00 - 20:00',
          'יום ו׳: 09:00 - 13:00 (סגירה מוקדמת לשבת)',
          'מוצ״ש: סגור'
        ],
        accessibility: 'נגישות מלאה, סיוע קולי, לולאת השראה לקויי שמיעה',
        parking: 'חנייה חופשית בשעה הראשונה בחניון הסלון',
        imageUrl: 'https://images.unsplash.com/photo-1604871000636-074fa5117945?auto=format&fit=crop&q=80&w=600',
        eventsCount: 2
      };
      setSelectedLoc(mockNewLoc);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" dir="rtl">
      
      {/* Introduction text */}
      <div className="text-center mb-10 max-w-2xl mx-auto space-y-3">
        <h3 className="text-3xl font-serif font-black text-[#0A1D37]">סניפי ספר חכמה</h3>
        <p className="text-[#B8976C] text-xs font-sans uppercase tracking-widest">בקרו באחד מהאטליים המעוצבים שלנו וגלו את חוויית הספר המוחשי</p>
        <div className="h-0.5 w-12 bg-[#B8976C] mx-auto mt-2"></div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left column: Simulated Interactive Vector Map (5 cols) */}
        <div className="lg:col-span-5 bg-[#FAF7F2] border border-[#EAE2D8] rounded-2xl p-5 shadow-sm space-y-4">
          <div className="text-right pb-2 border-b border-[#EAE2D8]">
            <h4 className="font-serif font-bold text-sm text-[#0A1D37] flex items-center gap-1.5">
              <Compass className="h-4.5 w-4.5 text-[#B8976C]" />
              <span>מפת סניפים אינטראקטיבית</span>
            </h4>
            <p className="text-[10px] text-neutral-400 font-sans mt-0.5">לחצו על הפינים במפה לטעינת פרטי האטלייה</p>
          </div>

          {/* Map canvas simulation */}
          <div className="relative aspect-[3/5] bg-[#EAE2D8] rounded-xl overflow-hidden border border-neutral-300 shadow-inner flex items-center justify-center p-2">
            
            {/* Israel outline mock graphic (Vector background details) */}
            <div className="absolute inset-4 rounded border-2 border-dashed border-[#B8976C]/10 flex flex-col justify-between p-4 pointer-events-none">
              <span className="text-[10px] text-neutral-400 font-sans tracking-widest self-start">הים התיכון</span>
              <span className="text-[10px] text-neutral-400 font-sans tracking-widest self-end">הרי ירושלים והנגב</span>
            </div>

            {/* Simulated city markers */}
            {allCitiesList.map(city => {
              const isSelected = selectedLoc.cityEn.toLowerCase().replace(' ', '_') === city.id || (selectedLoc.city === 'ירושלים' && city.id === 'jerusalem') || (selectedLoc.city === 'תל אביב' && city.id === 'tel_aviv') || (selectedLoc.city === 'חיפה' && city.id === 'haifa');
              return (
                <button
                  key={city.id}
                  onClick={() => handleCityPinClick(city.id)}
                  style={{ top: city.coords.top, right: city.coords.right }}
                  className="absolute transform translate-x-1/2 -translate-y-1/2 z-20 group"
                >
                  <div className="flex items-center gap-1.5">
                    {/* Pulsing indicator pin */}
                    <div className="relative h-6 w-6 flex items-center justify-center">
                      <span className={`absolute h-full w-full rounded-full bg-[#B8976C]/30 ${isSelected ? 'animate-ping' : 'group-hover:scale-125 transition-transform'}`}></span>
                      <MapPin className={`h-5.5 w-5.5 ${isSelected ? 'text-[#0A1D37] fill-[#B8976C]/30' : 'text-[#B8976C] hover:text-[#0A1D37]'}`} />
                    </div>

                    {/* Popover city label */}
                    <span className={`px-2 py-0.5 text-[9px] font-sans font-bold rounded shadow-sm border whitespace-nowrap transition-all ${
                      isSelected 
                        ? 'bg-[#0A1D37] text-[#FAF7F2] border-[#0A1D37]' 
                        : 'bg-white text-neutral-700 border-neutral-200 group-hover:bg-[#FAF7F2]'
                    }`}>
                      {city.label.split(' ')[0]}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right column: Selected Store details view (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          <div className="bg-white border border-[#EAE2D8] rounded-2xl overflow-hidden shadow-sm">
            {/* Photography image with overlay */}
            <div className="h-56 w-full bg-neutral-200 relative">
              <img 
                src={selectedLoc.imageUrl} 
                alt={selectedLoc.name} 
                className="w-full h-full object-cover brightness-90"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A1D37] to-transparent"></div>
              
              <div className="absolute bottom-5 right-5 text-white text-right space-y-1">
                <span className="px-2.5 py-0.5 bg-[#B8976C] text-[#FCFAF7] rounded text-[10px] font-sans font-semibold tracking-wider">
                  אטלייה {selectedLoc.city}
                </span>
                <h4 className="font-serif font-black text-xl sm:text-2xl">{selectedLoc.name}</h4>
              </div>
            </div>

            {/* Details panel body */}
            <div className="p-6 space-y-6 text-right">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Contact & Hours */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <span className="text-xs font-serif font-bold text-[#0A1D37] border-b border-neutral-100 pb-1 block">צור קשר וכתובת</span>
                    <div className="text-xs font-sans text-neutral-600 space-y-2">
                      <p className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-[#B8976C]" />
                        <span>{selectedLoc.address}</span>
                      </p>
                      <p className="flex items-center gap-2">
                        <Phone className="h-4 w-4 text-[#B8976C]" />
                        <span>{selectedLoc.phone}</span>
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <span className="text-xs font-serif font-bold text-[#0A1D37] border-b border-neutral-100 pb-1 block">שעות פתיחה של האטלייה</span>
                    <div className="text-xs font-sans text-neutral-600 space-y-1.5">
                      {selectedLoc.hours.map((hr, index) => (
                        <p key={index} className="flex items-center gap-1.5">
                          <Clock className="h-3.5 w-3.5 text-neutral-400" />
                          <span>{hr}</span>
                        </p>
                      ))}
                    </div>
                    {/* Shabbat warning block */}
                    <div className="bg-[#FAF7F2] p-2 rounded border border-amber-200/50 text-[10px] text-[#3E2723] font-serif leading-relaxed mt-2">
                      ⚠️ <strong>הבהרת שבת וחגים:</strong> כל סניפי ספר חכמה סגורים בימי שבת ומועדי ישראל. הזמנות באתר במוצ״ש יטופלו ביום ראשון בבוקר.
                    </div>
                  </div>
                </div>

                {/* Amenities & Parking info */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <span className="text-xs font-serif font-bold text-[#0A1D37] border-b border-neutral-100 pb-1 block">נגישות ואירוח</span>
                    <div className="text-xs font-sans text-neutral-600 flex gap-2 items-start">
                      <Accessibility className="h-4.5 w-4.5 text-[#B8976C] shrink-0 mt-0.5" />
                      <p className="leading-relaxed">{selectedLoc.accessibility}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <span className="text-xs font-serif font-bold text-[#0A1D37] border-b border-neutral-100 pb-1 block">חנייה והגעה</span>
                    <div className="text-xs font-sans text-neutral-600 flex gap-2 items-start">
                      <Car className="h-4.5 w-4.5 text-[#B8976C] shrink-0 mt-0.5" />
                      <p className="leading-relaxed">{selectedLoc.parking}</p>
                    </div>
                  </div>

                  {/* Directions trigger simulator */}
                  <div className="pt-2">
                    <button
                      onClick={() => alert(`מפעיל סימולטור GPS ניווט מונחה לסניף: "${selectedLoc.name}". תודה ורכיבה בטוחה!`)}
                      className="w-full py-2 bg-[#0A1D37] hover:bg-[#B8976C] text-white text-xs font-sans font-bold rounded-lg transition-all flex items-center justify-center gap-2 shadow-sm"
                    >
                      <Navigation className="h-3.5 w-3.5" />
                      <span>פתח ניווט GPS מונחה (Waze / Maps)</span>
                    </button>
                  </div>
                </div>

              </div>

              {/* Active events at this location */}
              <div className="bg-[#FAF7F2] border border-[#EAE2D8] p-4 rounded-xl space-y-3 pt-4">
                <div className="flex items-center gap-1.5 text-xs font-serif font-bold text-[#0A1D37]">
                  <Calendar className="h-4.5 w-4.5 text-[#B8976C]" />
                  <span>אירועים וסדנאות מתוכננים בסניף זה</span>
                </div>
                
                <p className="text-xs text-neutral-500 font-sans leading-relaxed">
                  הסניף מארח השבוע {selectedLoc.eventsCount} מפגשים ספרותיים מונחים. חברי הקהילה זכאים לכרטיסי כניסה חינם ולחניה מסובסדת לכל אורך זמן המפגש.
                </p>
              </div>

            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
