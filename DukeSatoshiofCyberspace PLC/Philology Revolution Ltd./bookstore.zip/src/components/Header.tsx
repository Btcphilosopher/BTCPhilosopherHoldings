import React, { useState } from 'react';
import { 
  Search, 
  ShoppingBag, 
  User, 
  Menu, 
  X, 
  Trash2, 
  Minus, 
  Plus, 
  Volume2, 
  Mic, 
  QrCode, 
  Sparkles, 
  BookOpen, 
  ChevronDown, 
  CheckCircle,
  Clock,
  BookMarked
} from 'lucide-react';
import { Book, CartItem } from '../types';

interface HeaderProps {
  activeView: string;
  setActiveView: (view: string) => void;
  cart: CartItem[];
  removeFromCart: (index: number) => void;
  updateCartItemQty: (index: number, qty: number) => void;
  updateCartItemFormat: (index: number, format: 'print' | 'ebook' | 'audiobook') => void;
  clearCart: () => void;
  setSearchQuery: (query: string) => void;
  searchQuery: string;
  books: Book[];
  onSelectBook: (book: Book) => void;
  userCoins?: number;
}

export default function Header({
  activeView,
  setActiveView,
  cart,
  removeFromCart,
  updateCartItemQty,
  updateCartItemFormat,
  clearCart,
  setSearchQuery,
  searchQuery,
  books,
  onSelectBook,
}: HeaderProps) {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [checkoutForm, setCheckoutForm] = useState({
    fullName: '',
    email: 'tom@ahyx.org',
    address: 'שדרות רוטשילד 15, תל אביב',
    phone: '054-1234567',
    cardNum: '4580 1234 5678 9012',
    cardExpiry: '08/29',
    cardCvc: '189',
    isGift: false,
    giftMessage: ''
  });

  // Simulator state
  const [isListening, setIsListening] = useState(false);
  const [isScanning, setIsScanning] = useState(false);

  // Filter books on search
  const filteredBooks = searchQuery.trim() === '' ? [] : books.filter(book => 
    book.title.includes(searchQuery) || 
    book.author.includes(searchQuery) ||
    book.isbn.includes(searchQuery) ||
    book.tags.some(t => t.includes(searchQuery))
  );

  const cartTotal = cart.reduce((sum, item) => {
    let multiplier = 1;
    if (item.format === 'ebook') multiplier = 0.6; // 40% discount for eBooks
    if (item.format === 'audiobook') multiplier = 0.75; // 25% discount for Audiobooks
    return sum + (item.book.price * multiplier) * item.quantity;
  }, 0);

  const totalItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  const handleVoiceSearch = () => {
    setIsListening(true);
    const mockPhrases = ['מורה נבוכים', 'רבי יהודה הלוי', 'זלדה שירה', 'ספרי קודש', 'ספר הדקדוק הפנימי'];
    const randomPhrase = mockPhrases[Math.floor(Math.random() * mockPhrases.length)];
    setTimeout(() => {
      setSearchQuery(randomPhrase);
      setIsListening(false);
      setIsSearchFocused(true);
      setActiveView('catalog');
    }, 1500);
  };

  const handleBarcodeScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      // Pick a random book ISBN from our data
      const randomBook = books[Math.floor(Math.random() * books.length)];
      setSearchQuery(randomBook.isbn);
      setIsScanning(false);
      setIsSearchFocused(true);
      setActiveView('catalog');
    }, 1800);
  };

  const executeCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutStep('success');
    setTimeout(() => {
      clearCart();
      setIsCartOpen(false);
      setCheckoutStep('cart');
    }, 5000);
  };

  return (
    <header className="sticky top-0 z-50 bg-[#FCFAF7]/95 backdrop-blur-md border-b border-[#EAE2D8] transition-all duration-300 shadow-sm" id="main-header" dir="rtl">
      {/* Top micro-bar */}
      <div className="bg-[#0A1D37] text-[#FAF7F2] text-xs py-1.5 px-4 text-center tracking-wider font-sans border-b border-[#0C2340]">
        <span>משלוחים מהירים חינם לכל רחבי הארץ בקנייה מעל 250 ₪</span>
      </div>

      {/* Main Brand Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        
        {/* Search Bar (Responsive Grid) */}
        <div className="relative w-full sm:w-80 order-2 sm:order-1">
          <div className="relative flex items-center bg-[#F5EFEB] border border-[#EAE2D8] rounded-full px-3 py-1.5 focus-within:border-[#B8976C] focus-within:bg-[#FCFAF7] transition-all duration-300">
            <Search className="h-4 w-4 text-[#222] ml-2 shrink-0" />
            <input
              type="text"
              placeholder="חיפוש ספרים, מחברים, מסת״ב..."
              value={searchQuery}
              onChange={handleSearchChange}
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setTimeout(() => setIsSearchFocused(false), 250)}
              className="w-full text-sm bg-transparent outline-none text-[#222] placeholder-neutral-500 font-sans"
            />
            {/* Simulators */}
            <div className="flex items-center gap-1.5 mr-1 text-neutral-400">
              <button 
                onClick={handleVoiceSearch} 
                title="חיפוש קולי (סימולטור)" 
                className={`p-1 hover:text-[#B8976C] transition-colors rounded ${isListening ? 'animate-pulse text-[#B8976C]' : ''}`}
              >
                <Mic className="h-4 w-4" />
              </button>
              <button 
                onClick={handleBarcodeScan} 
                title="סורק ברקוד (סימולטור)" 
                className={`p-1 hover:text-[#B8976C] transition-colors rounded ${isScanning ? 'animate-pulse text-[#B8976C]' : ''}`}
              >
                <QrCode className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Listening Overlay Indicator */}
          {isListening && (
            <div className="absolute right-0 top-12 left-0 bg-[#0A1D37] text-[#FAF7F2] text-xs py-2 px-3 rounded-lg flex items-center justify-between shadow-md z-50">
              <span className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-red-500 animate-ping"></span>
                מקשיב... נסה לומר שם של ספר או מחבר
              </span>
              <Volume2 className="h-3.5 w-3.5 animate-bounce" />
            </div>
          )}

          {/* Scanning Overlay Indicator */}
          {isScanning && (
            <div className="absolute right-0 top-12 left-0 bg-[#3E2723] text-[#FAF7F2] text-xs py-2 px-3 rounded-lg flex items-center justify-between shadow-md z-50">
              <span className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-yellow-500 animate-ping"></span>
                סורק ברקוד על כריכת הספר...
              </span>
              <Clock className="h-3.5 w-3.5 animate-spin" />
            </div>
          )}

          {/* Search Dropdown Panel */}
          {isSearchFocused && filteredBooks.length > 0 && (
            <div className="absolute top-11 right-0 left-0 bg-white border border-[#EAE2D8] rounded-xl shadow-xl z-50 py-2 max-h-80 overflow-y-auto">
              <div className="px-3 py-1 text-xs font-semibold text-neutral-400 border-b border-neutral-100 pb-1 mb-1 font-sans">תוצאות חיפוש מהירות</div>
              {filteredBooks.map(book => (
                <button
                  key={book.id}
                  onClick={() => {
                    onSelectBook(book);
                    setSearchQuery('');
                  }}
                  className="w-full text-right px-4 py-2 hover:bg-[#FAF7F2] flex items-center justify-between group transition-colors"
                >
                  <div className="flex flex-col">
                    <span className="text-sm font-semibold text-[#0A1D37] group-hover:text-[#B8976C] transition-colors">{book.title}</span>
                    <span className="text-xs text-neutral-500 font-sans">{book.author} • {book.publisher}</span>
                  </div>
                  <span className="text-xs font-semibold text-[#B8976C] font-sans">₪{book.price}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Centered Serif Brand Logo */}
        <div className="text-center cursor-pointer order-1 sm:order-2" onClick={() => setActiveView('home')}>
          <h1 className="text-3xl sm:text-4.5xl font-serif font-extrabold tracking-widest text-[#0A1D37] leading-none mb-1 select-none">ספר חכמה</h1>
          <div className="flex items-center justify-center gap-1.5">
            <span className="h-px w-6 bg-[#B8976C]"></span>
            <span className="text-xs text-[#B8976C] font-serif uppercase tracking-widest">ספרים • מחשבה • מסורת</span>
            <span className="h-px w-6 bg-[#B8976C]"></span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-4 sm:gap-5 order-3">
          
          {/* Main Account Shortcut */}
          <button 
            onClick={() => setActiveView('account')}
            className={`flex items-center gap-1.5 p-2 rounded-full transition-all duration-300 ${activeView === 'account' ? 'text-[#B8976C] bg-[#F5EFEB]' : 'text-[#0A1D37] hover:text-[#B8976C]'}`}
            title="חשבון אישי"
          >
            <User className="h-5.5 w-5.5" />
            <span className="text-xs font-sans font-medium hidden md:inline">אזור אישי</span>
          </button>

          {/* Cart Icon with indicator */}
          <button 
            onClick={() => setIsCartOpen(true)}
            className="relative flex items-center gap-1.5 p-2 text-[#0A1D37] hover:text-[#B8976C] rounded-full transition-all duration-300"
            title="סל הקניות"
          >
            <ShoppingBag className="h-5.5 w-5.5" />
            {totalItemsCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#B8976C] text-[#FCFAF7] text-[10px] font-bold h-5 w-5 rounded-full flex items-center justify-center font-sans shadow-sm ring-2 ring-[#FCFAF7] animate-bounce">
                {totalItemsCount}
              </span>
            )}
            <span className="text-xs font-sans font-medium hidden md:inline">הסל שלי</span>
          </button>

          {/* Hamburger Menu on Mobile */}
          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="sm:hidden p-2 text-[#0A1D37] hover:text-[#B8976C]"
          >
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Navigation Bar (Desktop) */}
      <nav className="hidden sm:block border-t border-[#EAE2D8] bg-[#0A1D37]">
        <div className="max-w-7xl mx-auto px-4">
          <ul className="flex items-center justify-center space-x-1 md:space-x-4 lg:space-x-8 space-x-reverse py-3">
            {[
              { id: 'home', label: 'עמוד הבית' },
              { id: 'catalog', label: 'הקטלוג שלנו' },
              { id: 'library', label: 'הספרייה הדיגיטלית' },
              { id: 'membership', label: 'קהילת חכמה' },
              { id: 'events', label: 'אירועים וסדנאות' },
              { id: 'locator', label: 'הסניפים שלנו' },
              { id: 'cms', label: 'ניהול מלאי (CMS)' },
              { id: 'tech', label: 'מפרט טכני' },
            ].map(item => (
              <li key={item.id}>
                <button
                  onClick={() => setActiveView(item.id)}
                  className={`px-3 py-1.5 text-sm font-sans tracking-wide rounded transition-all duration-300 ${
                    activeView === item.id 
                      ? 'text-[#FAF7F2] bg-[#B8976C] font-semibold shadow-inner' 
                      : 'text-[#FAF7F2]/80 hover:text-[#FAF7F2] hover:bg-[#FAF7F2]/10'
                  }`}
                >
                  {item.label}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </nav>

      {/* Mobile Menu Panel */}
      {isMobileMenuOpen && (
        <div className="sm:hidden bg-[#0A1D37] border-t border-[#0C2340] px-4 py-4 space-y-2 text-[#FAF7F2] shadow-xl">
          {[
            { id: 'home', label: 'עמוד הבית' },
            { id: 'catalog', label: 'הקטלוג שלנו' },
            { id: 'library', label: 'הספרייה הדיגיטלית' },
            { id: 'membership', label: 'קהילת חכמה' },
            { id: 'events', label: 'אירועים וסדנאות' },
            { id: 'locator', label: 'הסניפים שלנו' },
            { id: 'cms', label: 'ניהול מלאי (CMS)' },
            { id: 'tech', label: 'מפרט טכני' },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => {
                setActiveView(item.id);
                setIsMobileMenuOpen(false);
              }}
              className={`w-full text-right px-4 py-3 rounded-lg text-sm font-sans flex items-center justify-between transition-all ${
                activeView === item.id ? 'bg-[#B8976C] text-[#FAF7F2]' : 'hover:bg-white/5 text-[#FAF7F2]/80'
              }`}
            >
              <span>{item.label}</span>
              <BookOpen className="h-4 w-4 opacity-55" />
            </button>
          ))}
        </div>
      )}

      {/* Interactive Cart Drawer Side Panel */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 flex justify-end" id="cart-drawer-overlay">
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-[#222]/60 backdrop-blur-sm transition-opacity duration-300"
            onClick={() => setIsCartOpen(false)}
          ></div>

          {/* Drawer Container */}
          <div className="relative w-full max-w-md bg-[#FCFAF7] h-full shadow-2xl z-50 flex flex-col border-l border-[#EAE2D8] text-right">
            
            {/* Header */}
            <div className="p-5 border-b border-[#EAE2D8] flex items-center justify-between bg-[#F5EFEB]">
              <div className="flex items-center gap-2 text-[#0A1D37]">
                <ShoppingBag className="h-5.5 w-5.5 text-[#B8976C]" />
                <h3 className="text-lg font-serif font-bold">סל הספרים שלך</h3>
              </div>
              <button 
                onClick={() => setIsCartOpen(false)}
                className="p-1.5 rounded-full hover:bg-[#EAE2D8] text-[#222] transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Steps bar if checking out */}
            {cart.length > 0 && (
              <div className="px-5 py-2.5 bg-[#FAF7F2] border-b border-[#EAE2D8] flex justify-between text-xs font-sans text-neutral-500">
                <span className={checkoutStep === 'cart' ? 'text-[#B8976C] font-semibold' : ''}>1. הסל שלי</span>
                <span className={checkoutStep === 'checkout' ? 'text-[#B8976C] font-semibold' : ''}>2. כתובת ותשלום</span>
                <span className={checkoutStep === 'success' ? 'text-[#B8976C] font-semibold' : ''}>3. אישור הזמנה</span>
              </div>
            )}

            {/* Body */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {cart.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
                  <BookMarked className="h-16 w-16 text-[#B8976C]/30 stroke-[1.2]" />
                  <div>
                    <p className="text-[#0A1D37] font-serif font-semibold text-lg">סל הספרים ריק כרגע</p>
                    <p className="text-neutral-500 text-sm font-sans mt-1">מלאו אותו בהגות משובחת או יצירות מופת עבריות</p>
                  </div>
                  <button
                    onClick={() => {
                      setIsCartOpen(false);
                      setActiveView('catalog');
                    }}
                    className="px-5 py-2.5 bg-[#0A1D37] text-[#FAF7F2] rounded-full text-sm font-sans font-medium hover:bg-[#B8976C] transition-all"
                  >
                    מעבר לקטלוג הספרים
                  </button>
                </div>
              ) : checkoutStep === 'cart' ? (
                /* Item list view */
                <div className="space-y-4">
                  {cart.map((item, index) => {
                    let formattedPrice = item.book.price;
                    if (item.format === 'ebook') formattedPrice = Math.round(item.book.price * 0.6);
                    if (item.format === 'audiobook') formattedPrice = Math.round(item.book.price * 0.75);

                    return (
                      <div key={index} className="flex gap-3 bg-white p-3 rounded-xl border border-[#EAE2D8] hover:shadow-sm transition-all">
                        {/* Mock Cover Preview */}
                        <div className="h-20 w-14 bg-[#0A1D37] rounded-md shrink-0 flex items-center justify-center p-1 text-center relative overflow-hidden text-[#FAF7F2] border border-[#EAE2D8]">
                          <div className="absolute inset-y-0 right-0 w-1.5 bg-gradient-to-l from-black/20 to-transparent"></div>
                          <span className="text-[7px] font-serif font-semibold overflow-hidden line-clamp-3">{item.book.title}</span>
                        </div>

                        {/* Content */}
                        <div className="flex-1 flex flex-col justify-between">
                          <div>
                            <h4 className="text-sm font-bold text-[#0A1D37] line-clamp-1">{item.book.title}</h4>
                            <p className="text-xs text-neutral-500 font-sans">{item.book.author}</p>
                          </div>

                          {/* Format Selector */}
                          <div className="flex gap-1.5 mt-1">
                            {(['print', 'ebook', 'audiobook'] as const).map(fmt => {
                              if (fmt === 'ebook' && !item.book.isEbook) return null;
                              if (fmt === 'audiobook' && !item.book.isAudiobook) return null;

                              const labels = { print: 'מודפס', ebook: 'דיגיטלי', audiobook: 'שמע' };
                              return (
                                <button
                                  key={fmt}
                                  onClick={() => updateCartItemFormat(index, fmt)}
                                  className={`text-[10px] font-sans px-2 py-0.5 rounded border transition-all ${
                                    item.format === fmt 
                                      ? 'bg-[#B8976C] text-[#FCFAF7] border-[#B8976C]' 
                                      : 'bg-neutral-50 text-neutral-600 border-neutral-200 hover:bg-[#F5EFEB]'
                                  }`}
                                >
                                  {labels[fmt]}
                                </button>
                              );
                            })}
                          </div>

                          {/* Quantity Controls & Price */}
                          <div className="flex items-center justify-between mt-2 pt-1 border-t border-neutral-100">
                            <div className="flex items-center gap-2">
                              <button 
                                onClick={() => updateCartItemQty(index, item.quantity - 1)}
                                className="p-0.5 rounded bg-neutral-100 hover:bg-neutral-200"
                              >
                                <Minus className="h-3.5 w-3.5" />
                              </button>
                              <span className="text-xs font-sans font-bold text-[#0A1D37]">{item.quantity}</span>
                              <button 
                                onClick={() => updateCartItemQty(index, item.quantity + 1)}
                                className="p-0.5 rounded bg-neutral-100 hover:bg-neutral-200"
                              >
                                <Plus className="h-3.5 w-3.5" />
                              </button>
                            </div>
                            <div className="text-right">
                              <span className="text-sm font-bold text-[#B8976C] font-sans">₪{formattedPrice * item.quantity}</span>
                              {item.quantity > 1 && (
                                <p className="text-[10px] text-neutral-400 font-sans">₪{formattedPrice} ליחידה</p>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Remove */}
                        <button 
                          onClick={() => removeFromCart(index)}
                          className="text-neutral-400 hover:text-red-500 self-start p-1"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              ) : checkoutStep === 'checkout' ? (
                /* Checkout Form view */
                <form onSubmit={executeCheckout} className="space-y-4 text-xs font-sans text-[#222]">
                  <div className="bg-white p-4 rounded-xl border border-[#EAE2D8] space-y-3">
                    <h4 className="font-serif font-bold text-sm text-[#0A1D37] border-b border-neutral-100 pb-1">פרטי משלוח</h4>
                    
                    <div>
                      <label className="block text-neutral-500 mb-1">שם מלא</label>
                      <input 
                        type="text" 
                        required
                        value={checkoutForm.fullName}
                        onChange={e => setCheckoutForm({...checkoutForm, fullName: e.target.value})}
                        className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none focus:border-[#B8976C]" 
                        placeholder="ישראל ישראלי" 
                      />
                    </div>

                    <div>
                      <label className="block text-neutral-500 mb-1">כתובת למשלוח</label>
                      <input 
                        type="text" 
                        required
                        value={checkoutForm.address}
                        onChange={e => setCheckoutForm({...checkoutForm, address: e.target.value})}
                        className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none focus:border-[#B8976C]" 
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-neutral-500 mb-1">אימייל</label>
                        <input 
                          type="email" 
                          required
                          value={checkoutForm.email}
                          onChange={e => setCheckoutForm({...checkoutForm, email: e.target.value})}
                          className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] text-neutral-500 cursor-not-allowed outline-none" 
                          disabled
                        />
                      </div>
                      <div>
                        <label className="block text-neutral-500 mb-1">טלפון</label>
                        <input 
                          type="text" 
                          required
                          value={checkoutForm.phone}
                          onChange={e => setCheckoutForm({...checkoutForm, phone: e.target.value})}
                          className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none focus:border-[#B8976C]" 
                        />
                      </div>
                    </div>

                    <div className="pt-2 flex items-center gap-2">
                      <input 
                        type="checkbox" 
                        id="isGift"
                        checked={checkoutForm.isGift}
                        onChange={e => setCheckoutForm({...checkoutForm, isGift: e.target.checked})}
                        className="accent-[#B8976C]"
                      />
                      <label htmlFor="isGift" className="text-neutral-700 font-medium">הזמנה זו היא מתנה (נא לארוז יפה)</label>
                    </div>

                    {checkoutForm.isGift && (
                      <div>
                        <label className="block text-neutral-500 mb-1">ברכה מצורפת</label>
                        <textarea 
                          className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none focus:border-[#B8976C] h-16" 
                          placeholder="כתבו פה את הברכה שלכם..."
                          value={checkoutForm.giftMessage}
                          onChange={e => setCheckoutForm({...checkoutForm, giftMessage: e.target.value})}
                        />
                      </div>
                    )}
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-[#EAE2D8] space-y-3">
                    <h4 className="font-serif font-bold text-sm text-[#0A1D37] border-b border-neutral-100 pb-1">פרטי תשלום (סימולטור Stripe מאובטח)</h4>
                    
                    <div>
                      <label className="block text-neutral-500 mb-1">מספר כרטיס אשראי</label>
                      <input 
                        type="text" 
                        required
                        value={checkoutForm.cardNum}
                        onChange={e => setCheckoutForm({...checkoutForm, cardNum: e.target.value})}
                        className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none focus:border-[#B8976C] font-mono tracking-wider text-left" 
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-neutral-500 mb-1">תוקף (MM/YY)</label>
                        <input 
                          type="text" 
                          required
                          value={checkoutForm.cardExpiry}
                          onChange={e => setCheckoutForm({...checkoutForm, cardExpiry: e.target.value})}
                          className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none focus:border-[#B8976C] font-mono text-center" 
                        />
                      </div>
                      <div>
                        <label className="block text-neutral-500 mb-1">קוד אבטחה (CVC)</label>
                        <input 
                          type="password" 
                          required
                          maxLength={3}
                          value={checkoutForm.cardCvc}
                          onChange={e => setCheckoutForm({...checkoutForm, cardCvc: e.target.value})}
                          className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] outline-none focus:border-[#B8976C] font-mono text-center" 
                        />
                      </div>
                    </div>
                  </div>
                </form>
              ) : (
                /* Success animation and status */
                <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
                  <CheckCircle className="h-16 w-16 text-emerald-600 animate-bounce" />
                  <div>
                    <h4 className="text-xl font-serif font-bold text-[#0A1D37]">התשלום עבר בהצלחה!</h4>
                    <p className="text-sm text-neutral-600 mt-2 font-sans">
                      הספרים הועברו לטיפול במחלקת האריזה והמשלוחים שלנו. מספר מעקב הזמנה נשלח לכתובת <strong>{checkoutForm.email}</strong>.
                    </p>
                  </div>
                  <div className="bg-white p-4 rounded-xl border border-emerald-100 w-full space-y-2 text-right text-xs font-sans">
                    <p><strong>מספר הזמנה:</strong> SC-98214</p>
                    <p><strong>משלוח לכתובת:</strong> {checkoutForm.address}</p>
                    <p><strong>סה״כ שולם:</strong> ₪{cartTotal}</p>
                    <p className="text-neutral-500 text-[11px] leading-relaxed mt-2 text-center">
                      סמל הדיגיטליות שלך: אם הזמנת גרסה דיגיטלית או שמע, היא כבר מופיעה בטאב <strong>"הספרייה הדיגיטלית"</strong> שלך לקריאה מיידית!
                    </p>
                  </div>
                  <p className="text-[10px] text-neutral-400 font-sans">חלון זה ייסגר אוטומטית כעת...</p>
                </div>
              )}
            </div>

            {/* Footer with checkout actions */}
            {cart.length > 0 && checkoutStep !== 'success' && (
              <div className="p-5 border-t border-[#EAE2D8] bg-[#FAF7F2]">
                <div className="space-y-2 mb-4 font-sans text-sm">
                  <div className="flex justify-between text-neutral-500">
                    <span>פריטים בסל:</span>
                    <span>{totalItemsCount}</span>
                  </div>
                  <div className="flex justify-between text-neutral-500">
                    <span>משלוח:</span>
                    <span className="text-emerald-600 font-medium">{cartTotal >= 250 ? 'חינם' : '₪15'}</span>
                  </div>
                  <div className="flex justify-between text-base font-serif font-bold text-[#0A1D37] pt-2 border-t border-[#EAE2D8]">
                    <span>סה״כ לתשלום:</span>
                    <span>₪{cartTotal + (cartTotal >= 250 ? 0 : 15)}</span>
                  </div>
                </div>

                {checkoutStep === 'cart' ? (
                  <button
                    onClick={() => setCheckoutStep('checkout')}
                    className="w-full bg-[#0A1D37] text-[#FAF7F2] py-3 rounded-full text-sm font-sans font-semibold hover:bg-[#B8976C] transition-all flex items-center justify-center gap-2 shadow-md"
                  >
                    <span>המשך לפרטי תשלום</span>
                    <Clock className="h-4 w-4" />
                  </button>
                ) : (
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setCheckoutStep('cart')}
                      className="bg-[#F5EFEB] text-[#222] py-3 rounded-full text-xs font-sans font-semibold hover:bg-[#EAE2D8] transition-all"
                    >
                      חזור לסל
                    </button>
                    <button
                      onClick={executeCheckout}
                      className="bg-[#B8976C] text-[#FCFAF7] py-3 rounded-full text-xs font-sans font-semibold hover:bg-[#0A1D37] transition-all flex items-center justify-center gap-1.5 shadow"
                    >
                      <span>אשר ובצע הזמנה</span>
                      <Sparkles className="h-4 w-4" />
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
