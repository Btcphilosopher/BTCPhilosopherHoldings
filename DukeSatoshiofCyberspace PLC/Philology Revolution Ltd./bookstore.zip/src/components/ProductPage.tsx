import React, { useState } from 'react';
import { 
  ArrowRight, 
  ShoppingBag, 
  Bookmark, 
  Share2, 
  Gift, 
  CheckCircle, 
  Star, 
  FileText, 
  BookOpen, 
  Clock, 
  Feather, 
  ChevronDown, 
  ChevronUp, 
  Smile,
  Check,
  Volume2
} from 'lucide-react';
import { Book } from '../types';

interface ProductPageProps {
  book: Book;
  onBack: () => void;
  addToCart: (book: Book, format: 'print' | 'ebook' | 'audiobook') => void;
  addToWishlist: (bookId: string) => void;
  wishlist: string[];
  allBooks: Book[];
  onSelectBook: (book: Book) => void;
  onSubmitReview: (bookId: string, user: string, rating: number, comment: string) => void;
}

export default function ProductPage({
  book,
  onBack,
  addToCart,
  addToWishlist,
  wishlist,
  allBooks,
  onSelectBook,
  onSubmitReview
}: ProductPageProps) {
  const [selectedFormat, setSelectedFormat] = useState<'print' | 'ebook' | 'audiobook'>('print');
  const [isTOCExpanded, setIsTOCExpanded] = useState(true);
  const [shareCopied, setShareCopied] = useState(false);
  const [isGiftOption, setIsGiftOption] = useState(false);

  // New review state
  const [newReview, setNewReview] = useState({ user: '', rating: 5, comment: '' });
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  const isWishlisted = wishlist.includes(book.id);

  // Calculate format-specific price
  let basePrice = book.price;
  let label = 'כריכה קשה מודפסת';
  if (selectedFormat === 'ebook') {
    basePrice = Math.round(book.price * 0.6);
    label = 'גרסה דיגיטלית (EPUB/PDF)';
  } else if (selectedFormat === 'audiobook') {
    basePrice = Math.round(book.price * 0.75);
    label = 'גרסת שמע דיגיטלית (MP3)';
  }

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setShareCopied(true);
    setTimeout(() => setShareCopied(false), 2500);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.user.trim() || !newReview.comment.trim()) return;
    onSubmitReview(book.id, newReview.user, newReview.rating, newReview.comment);
    setReviewSubmitted(true);
    setNewReview({ user: '', rating: 5, comment: '' });
    setTimeout(() => setReviewSubmitted(false), 3000);
  };

  // Filter related books
  const relatedBooks = allBooks
    .filter(b => b.category === book.category && b.id !== book.id)
    .slice(0, 3);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12" dir="rtl">
      
      {/* Back button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 px-4 py-2 text-sm font-sans font-semibold text-[#0A1D37] hover:text-[#B8976C] bg-white border border-[#EAE2D8] rounded-full transition-colors mb-8 cursor-pointer shadow-sm"
      >
        <ArrowRight className="h-4 w-4" />
        <span>חזרה לקטלוג</span>
      </button>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-start mb-16">
        
        {/* Left Column: 3D Book Cover & Media (4 cols) */}
        <div className="lg:col-span-4 flex flex-col items-center">
          
          {/* Elegant 3D Book perspective box */}
          <div className="relative group perspective-1000 mb-6 py-6 w-full max-w-[280px]">
            {/* 3D Book Frame */}
            <div className="relative transform-style-3d transition-transform duration-700 group-hover:rotate-y-12 shadow-2xl rounded-lg overflow-hidden border border-[#EAE2D8]">
              {/* Back pages simulator ridge */}
              <div className="absolute top-0 bottom-0 left-0 w-2.5 bg-gradient-to-r from-neutral-200 to-neutral-50 transform origin-left rotate-y-90 z-10"></div>
              {/* Book spine simulation overlay */}
              <div className="absolute inset-y-0 right-0 w-4 bg-gradient-to-l from-black/25 to-transparent z-20"></div>
              {/* Gold cover alignment foil */}
              <div className="absolute inset-2 border border-[#B8976C]/30 rounded-md pointer-events-none z-10"></div>
              
              <img 
                src={book.coverUrl} 
                alt={book.title} 
                className="w-full h-auto aspect-[3/4.2] object-cover block brightness-95"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Rare book leaf certificate of authenticity decoration */}
            {book.isRare && (
              <div className="mt-4 bg-[#3E2723]/10 border border-[#B8976C]/40 p-3 rounded-lg text-center text-xs font-serif text-[#3E2723]">
                <span className="font-bold">✦ מהדורה אספנית מיוחדת ✦</span>
                <p className="text-[10px] text-[#B8976C] mt-1 font-sans">כוללת כריכת עור משובח וקופסת מגן מרופדת קטיפה</p>
              </div>
            )}
          </div>

          {/* Book format quick info */}
          <div className="grid grid-cols-3 gap-2 w-full max-w-sm text-center text-[11px] font-sans text-neutral-500 bg-white p-3.5 rounded-xl border border-[#EAE2D8]">
            <div className="border-l border-neutral-100">
              <span className="block text-neutral-400">עמודים</span>
              <strong className="text-sm font-bold text-[#0A1D37] font-sans">{book.pageCount}</strong>
            </div>
            <div className="border-l border-neutral-100">
              <span className="block text-neutral-400">שפה</span>
              <strong className="text-sm font-bold text-[#0A1D37] font-serif">{book.language}</strong>
            </div>
            <div>
              <span className="block text-neutral-400">מסת״ב</span>
              <strong className="text-[10px] font-bold text-[#0A1D37] font-mono">{book.isbn}</strong>
            </div>
          </div>
        </div>

        {/* Right Column: Information, Selection & Review (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Header Title section */}
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 bg-[#B8976C]/10 text-[#B8976C] rounded-full text-xs font-sans font-bold">
                {book.category === 'torah' ? 'ספרי קודש' : book.category === 'philosophy' ? 'מחשבה והגות' : book.category === 'poetry' ? 'שירה ופיוט' : book.category === 'rare' ? 'מהדורה נדירה' : 'ספרות עברית'}
              </span>
              <div className="flex items-center gap-1 text-amber-500 text-xs">
                <Star className="h-4.5 w-4.5 fill-current" />
                <span className="font-sans font-bold text-neutral-800">{book.rating}</span>
                <span className="text-neutral-400">({book.reviewsCount} חוות דעת)</span>
              </div>
            </div>

            <h3 className="text-3xl sm:text-4xl font-serif font-black text-[#0A1D37] tracking-wide leading-tight">{book.title}</h3>
            
            <p className="text-sm text-[#B8976C] font-serif flex items-center gap-1.5 pt-1">
              <Feather className="h-4.5 w-4.5" />
              <span>מאת: <strong>{book.author}</strong></span>
              <span className="text-neutral-300">|</span>
              <span className="text-xs text-neutral-500 font-sans">הוצאה: {book.publisher} • שנת פרסום {book.publishDate}</span>
            </p>
          </div>

          {/* Core Description block */}
          <div className="bg-white border border-[#EAE2D8] rounded-2xl p-6 shadow-sm space-y-3">
            <h4 className="font-serif font-bold text-[#0A1D37] text-base border-b border-neutral-100 pb-2">על הספר</h4>
            <p className="text-neutral-600 text-sm leading-relaxed font-sans">{book.description}</p>
          </div>

          {/* Interactive Format Selector with discounts */}
          <div className="space-y-3">
            <h4 className="font-serif font-bold text-[#0A1D37] text-sm">בחרו את הפורמט המבוקש:</h4>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              
              {/* Printed */}
              <button
                onClick={() => setSelectedFormat('print')}
                className={`p-4 rounded-xl border text-right transition-all flex flex-col justify-between ${
                  selectedFormat === 'print'
                    ? 'bg-white border-[#B8976C] ring-2 ring-[#B8976C]/30 shadow-md'
                    : 'bg-[#FAF7F2] border-neutral-200 hover:bg-[#F5EFEB]'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="font-serif font-bold text-sm text-[#0A1D37]">ספר מודפס</span>
                  <BookOpen className="h-4 w-4 text-[#B8976C]" />
                </div>
                <div className="mt-4 pt-2 border-t border-neutral-100 w-full flex items-baseline justify-between">
                  <span className="text-xs text-neutral-400 font-sans">כריכה קשה</span>
                  <strong className="text-lg font-bold text-[#0A1D37] font-mono">₪{book.price}</strong>
                </div>
              </button>

              {/* eBook */}
              {book.isEbook && (
                <button
                  onClick={() => setSelectedFormat('ebook')}
                  className={`p-4 rounded-xl border text-right transition-all flex flex-col justify-between ${
                    selectedFormat === 'ebook'
                      ? 'bg-white border-[#B8976C] ring-2 ring-[#B8976C]/30 shadow-md'
                      : 'bg-[#FAF7F2] border-neutral-200 hover:bg-[#F5EFEB]'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-serif font-bold text-sm text-[#0A1D37]">דיגיטלי (eBook)</span>
                    <FileText className="h-4 w-4 text-[#B8976C]" />
                  </div>
                  <p className="text-[10px] text-[#B8976C] font-semibold mt-1">חיסכון של 40% ברכישה!</p>
                  <div className="mt-2 pt-2 border-t border-neutral-100 w-full flex items-baseline justify-between">
                    <span className="text-xs text-neutral-400 font-sans">קובץ EPUB/PDF</span>
                    <strong className="text-lg font-bold text-[#0A1D37] font-mono">₪{Math.round(book.price * 0.6)}</strong>
                  </div>
                </button>
              )}

              {/* Audiobook */}
              {book.isAudiobook && (
                <button
                  onClick={() => setSelectedFormat('audiobook')}
                  className={`p-4 rounded-xl border text-right transition-all flex flex-col justify-between ${
                    selectedFormat === 'audiobook'
                      ? 'bg-white border-[#B8976C] ring-2 ring-[#B8976C]/30 shadow-md'
                      : 'bg-[#FAF7F2] border-neutral-200 hover:bg-[#F5EFEB]'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-serif font-bold text-sm text-[#0A1D37]">שמע (Audiobook)</span>
                    <Volume2 className="h-4 w-4 text-[#B8976C]" />
                  </div>
                  <p className="text-[10px] text-neutral-500 font-sans mt-1">אורך: {book.audioDuration}</p>
                  <div className="mt-2 pt-2 border-t border-neutral-100 w-full flex items-baseline justify-between">
                    <span className="text-xs text-neutral-400 font-sans">קובץ MP3 איכותי</span>
                    <strong className="text-lg font-bold text-[#0A1D37] font-mono">₪{Math.round(book.price * 0.75)}</strong>
                  </div>
                </button>
              )}

            </div>
          </div>

          {/* Gift Option Selector */}
          <div className="bg-[#FAF7F2] border border-[#EAE2D8] p-4 rounded-xl space-y-3">
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="giftCheck"
                checked={isGiftOption}
                onChange={e => setIsGiftOption(e.target.checked)}
                className="accent-[#B8976C] h-4 w-4"
              />
              <label htmlFor="giftCheck" className="text-sm font-serif font-semibold text-[#0A1D37] cursor-pointer flex items-center gap-1.5">
                <Gift className="h-4.5 w-4.5 text-[#B8976C]" />
                <span>רכשו ספר זה כמתנה לחבר או קרוב משפחה</span>
              </label>
            </div>
            {isGiftOption && (
              <p className="text-xs text-neutral-500 font-sans leading-relaxed">
                * הזמנה כמתנה כוללת אריזה מפוארת מנייר ממוחזר בסרט משי, וגלויה מודפסת מרהיבה עם הקדשתכם האישית. (תוכלו להוסיף את תוכן ההקדשה במעמד התשלום בסל הקניות).
              </p>
            )}
          </div>

          {/* Action Bar */}
          <div className="flex flex-wrap items-center gap-3 border-t border-[#EAE2D8] pt-6">
            
            {/* Purchase button */}
            <button
              onClick={() => addToCart(book, selectedFormat)}
              className="px-8 py-3.5 bg-[#0A1D37] text-white hover:bg-[#B8976C] font-sans font-bold text-sm rounded-full transition-all flex items-center gap-2 shadow-md shrink-0"
            >
              <ShoppingBag className="h-4.5 w-4.5" />
              <span>הוסף לסל הקניות - ₪{basePrice}</span>
            </button>

            {/* Save to wishlist */}
            <button
              onClick={() => addToWishlist(book.id)}
              className={`p-3 rounded-full border transition-all ${
                isWishlisted
                  ? 'bg-rose-50 border-rose-200 text-rose-500'
                  : 'bg-white border-[#EAE2D8] text-[#0A1D37] hover:bg-neutral-50'
              }`}
              title="שמור ברשימת המשאלות"
            >
              <Bookmark className={`h-5 w-5 ${isWishlisted ? 'fill-current' : ''}`} />
            </button>

            {/* Share button */}
            <button
              onClick={handleShare}
              className="p-3 rounded-full border border-[#EAE2D8] bg-white text-[#0A1D37] hover:bg-neutral-50 transition-all flex items-center justify-center relative"
              title="שתף עם חברים"
            >
              {shareCopied ? (
                <Check className="h-5 w-5 text-emerald-600" />
              ) : (
                <Share2 className="h-5 w-5" />
              )}
              {shareCopied && (
                <span className="absolute -top-10 left-1/2 -translate-x-1/2 bg-neutral-800 text-white text-[10px] px-2 py-1 rounded shadow-lg whitespace-nowrap z-50">
                  הקישור הועתק!
                </span>
              )}
            </button>
          </div>

          {/* Collapsible Table of Contents */}
          <div className="border border-[#EAE2D8] rounded-2xl bg-white overflow-hidden shadow-sm">
            <button
              onClick={() => setIsTOCExpanded(!isTOCExpanded)}
              className="w-full p-4 bg-[#F5EFEB] flex items-center justify-between text-right"
            >
              <h4 className="font-serif font-extrabold text-[#0A1D37] text-sm">ראשי פרקים ותוכן עניינים</h4>
              {isTOCExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </button>

            {isTOCExpanded && (
              <ul className="p-4 divide-y divide-neutral-100 text-xs font-sans text-neutral-600">
                {book.tableOfContents.map((chapter, i) => (
                  <li key={i} className="py-2.5 flex items-center justify-between">
                    <span className="font-medium text-[#0A1D37]">{chapter}</span>
                    <span className="text-neutral-400">פרק {i + 1}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Author Profile block */}
          <div className="bg-[#FAF7F2] border border-[#EAE2D8] p-5 rounded-2xl space-y-2.5">
            <h4 className="font-serif font-bold text-sm text-[#0A1D37]">על המחבר: <strong>{book.author}</strong></h4>
            <p className="text-xs text-neutral-600 leading-relaxed font-sans">{book.authorBio}</p>
          </div>

          {/* Ratings & Interactive Review Form */}
          <div className="bg-white border border-[#EAE2D8] rounded-2xl p-6 shadow-sm space-y-6">
            <h4 className="font-serif font-bold text-[#0A1D37] text-base border-b border-neutral-100 pb-2">חוות דעת קוראים</h4>

            {/* List current reviews */}
            <div className="space-y-4">
              {book.reviews && book.reviews.length > 0 ? (
                book.reviews.map((rev) => (
                  <div key={rev.id} className="text-xs font-sans border-b border-neutral-50 pb-3 last:border-b-0 space-y-1">
                    <div className="flex items-center justify-between">
                      <strong className="text-[#0A1D37]">{rev.user}</strong>
                      <span className="text-neutral-400 font-mono">{rev.date}</span>
                    </div>
                    <div className="flex items-center gap-0.5 text-amber-500 pb-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`h-3 w-3 ${i < rev.rating ? 'fill-current' : 'text-neutral-200'}`} />
                      ))}
                    </div>
                    <p className="text-neutral-600 leading-relaxed font-sans">{rev.comment}</p>
                  </div>
                ))
              ) : (
                <p className="text-xs text-neutral-400 font-sans italic">אין עדיין חוות דעת לספר זה. היו הראשונים לכתוב!</p>
              )}
            </div>

            {/* Interactive review form */}
            <form onSubmit={handleReviewSubmit} className="bg-[#FCFAF7] border border-[#EAE2D8] p-4 rounded-xl space-y-3 text-xs">
              <span className="font-serif font-bold text-[#0A1D37]">הוספת חוות דעת משלכם:</span>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-neutral-500 mb-1">שמכם</label>
                  <input
                    type="text"
                    required
                    value={newReview.user}
                    onChange={e => setNewReview({ ...newReview, user: e.target.value })}
                    placeholder="שם מלא או כינוי"
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-white outline-none focus:border-[#B8976C]"
                  />
                </div>
                <div>
                  <label className="block text-neutral-500 mb-1">דירוג (כוכבים)</label>
                  <select
                    value={newReview.rating}
                    onChange={e => setNewReview({ ...newReview, rating: Number(e.target.value) })}
                    className="w-full p-2 border border-[#EAE2D8] rounded bg-white font-bold text-[#B8976C] outline-none"
                  >
                    <option value={5}>⭐⭐⭐⭐⭐ (5 כוכבים)</option>
                    <option value={4}>⭐⭐⭐⭐ (4 כוכבים)</option>
                    <option value={3}>⭐⭐⭐ (3 כוכבים)</option>
                    <option value={2}>⭐⭐ (2 כוכבים)</option>
                    <option value={1}>⭐ (כוכב אחד)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-neutral-500 mb-1">התרשמותכם וביקורתכם</label>
                <textarea
                  required
                  rows={3}
                  value={newReview.comment}
                  onChange={e => setNewReview({ ...newReview, comment: e.target.value })}
                  placeholder="שתפו אותנו בחוויית הקריאה שלכם..."
                  className="w-full p-2 border border-[#EAE2D8] rounded bg-white outline-none focus:border-[#B8976C]"
                />
              </div>

              <button
                type="submit"
                className="px-5 py-2 bg-[#0A1D37] text-white hover:bg-[#B8976C] rounded-lg font-sans font-bold transition-all shadow-sm"
              >
                שלח חוות דעת
              </button>

              {reviewSubmitted && (
                <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 p-2 rounded flex items-center gap-2 mt-2">
                  <CheckCircle className="h-4 w-4" />
                  <span>תודה! חוות דעתכם נקלטה בהצלחה ותוצג מיד במערכת.</span>
                </div>
              )}
            </form>
          </div>

          {/* Related books slider */}
          {relatedBooks.length > 0 && (
            <div className="space-y-4 pt-4">
              <h4 className="font-serif font-black text-[#0A1D37] text-lg">ספרים מומלצים נוספים מאותה מחלקה</h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {relatedBooks.map(rel => (
                  <div 
                    key={rel.id}
                    onClick={() => onSelectBook(rel)}
                    className="cursor-pointer group bg-white border border-[#EAE2D8] rounded-xl p-3 hover:shadow-md hover:border-[#B8976C]/30 transition-all text-right"
                  >
                    <div className="aspect-[3/4.2] overflow-hidden rounded-lg bg-neutral-100 mb-2.5 relative border border-neutral-200">
                      <img 
                        src={rel.coverUrl} 
                        alt={rel.title} 
                        className="w-full h-full object-cover group-hover:scale-103 transition-transform"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <h5 className="font-serif font-bold text-xs text-[#0A1D37] line-clamp-1 group-hover:text-[#B8976C] transition-colors">{rel.title}</h5>
                    <p className="text-[10px] text-neutral-500 font-sans mt-0.5">{rel.author}</p>
                    <p className="text-xs font-bold text-[#B8976C] font-mono mt-1">₪{rel.price}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
