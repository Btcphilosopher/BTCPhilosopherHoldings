import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Volume2, 
  Play, 
  Pause, 
  RotateCcw, 
  RotateCw, 
  Download, 
  Bookmark, 
  Maximize, 
  Sparkles, 
  ArrowRight,
  Sun,
  Moon,
  ChevronRight,
  Settings,
  Type
} from 'lucide-react';
import { Book, UserProfile } from '../types';

interface DigitalLibraryProps {
  books: Book[];
  userProfile: UserProfile;
  onUpdateReadingProgress: (bookId: string, percentage: number) => void;
  onBackToHome: () => void;
}

export default function DigitalLibrary({
  books,
  userProfile,
  onUpdateReadingProgress,
  onBackToHome
}: DigitalLibraryProps) {
  // Library view state
  const [activeTab, setActiveTab] = useState<'ebooks' | 'audiobooks'>('ebooks');
  
  // Reader state
  const [readingBook, setReadingBook] = useState<Book | null>(null);
  const [readerTheme, setReaderTheme] = useState<'parchment' | 'white' | 'charcoal'>('parchment');
  const [readerFontSize, setReaderFontSize] = useState<'sm' | 'md' | 'lg' | 'xl'>('md');
  const [readingPercent, setReadingPercent] = useState<number>(0);
  const [bookmarks, setBookmarks] = useState<number[]>([]);

  // Audiobook player state
  const [playingBook, setPlayingBook] = useState<Book | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [audioProgress, setAudioProgress] = useState<number>(35); // simulated percent
  const [audioTimer, setAudioTimer] = useState<string>('06:32');

  // Load books that are eBooks/Audiobooks from our catalogue
  const ebooks = books.filter(b => b.isEbook);
  const audiobooks = books.filter(b => b.isAudiobook);

  // Sync reading progress
  useEffect(() => {
    if (readingBook) {
      setReadingPercent(userProfile.readingProgress[readingBook.id] || 0);
    }
  }, [readingBook, userProfile]);

  const handleProgressChange = (newVal: number) => {
    setReadingPercent(newVal);
    if (readingBook) {
      onUpdateReadingProgress(readingBook.id, newVal);
    }
  };

  const toggleBookmark = (paraId: number) => {
    if (bookmarks.includes(paraId)) {
      setBookmarks(bookmarks.filter(id => id !== paraId));
    } else {
      setBookmarks([...bookmarks, paraId]);
    }
  };

  // Mock audiobook ticking
  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setAudioProgress(prev => {
          if (prev >= 100) {
            setIsPlaying(false);
            return 100;
          }
          const nextVal = prev + 0.2;
          // Calculate remaining time
          const totalSecs = 18.5 * 3600; // 18.5 hours
          const currentSecs = totalSecs * (nextVal / 100);
          const remainingSecs = totalSecs - currentSecs;
          const hrs = Math.floor(remainingSecs / 3600);
          const mins = Math.floor((remainingSecs % 3600) / 60);
          setAudioTimer(`${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`);
          return nextVal;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" dir="rtl">
      
      {/* If reading a book, render eBook reader panel */}
      {readingBook ? (
        <div className={`rounded-2xl border transition-all duration-300 shadow-xl overflow-hidden ${
          readerTheme === 'parchment' ? 'bg-[#FCFAF7] border-[#EAE2D8] text-neutral-800' :
          readerTheme === 'white' ? 'bg-white border-neutral-200 text-neutral-900' :
          'bg-[#1E1E1E] border-neutral-800 text-neutral-200'
        }`}>
          {/* Reader toolbar */}
          <div className="p-4 border-b flex flex-wrap items-center justify-between gap-3 bg-[#FAF7F2] text-neutral-800 border-[#EAE2D8]">
            <button
              onClick={() => setReadingBook(null)}
              className="px-3.5 py-1.5 bg-white border border-[#EAE2D8] text-sm rounded-lg flex items-center gap-1.5 font-sans font-semibold hover:bg-neutral-50"
            >
              <ArrowRight className="h-4 w-4" />
              <span>יציאה מהספרייה</span>
            </button>

            <span className="font-serif font-bold text-sm text-[#0A1D37] line-clamp-1">{readingBook.title} - מאת {readingBook.author}</span>

            {/* Formatting settings */}
            <div className="flex items-center gap-3">
              {/* Font size */}
              <div className="flex items-center gap-1 bg-white border border-[#EAE2D8] rounded-lg p-1">
                {(['sm', 'md', 'lg', 'xl'] as const).map(size => (
                  <button
                    key={size}
                    onClick={() => setReaderFontSize(size)}
                    className={`px-2 py-0.5 text-xs rounded font-sans transition-all ${
                      readerFontSize === size ? 'bg-[#0A1D37] text-white' : 'text-neutral-500 hover:bg-[#FAF7F2]'
                    }`}
                  >
                    {size === 'sm' ? 'א' : size === 'md' ? 'א+' : size === 'lg' ? 'א++' : 'א+++'}
                  </button>
                ))}
              </div>

              {/* Theme toggler */}
              <div className="flex items-center gap-1 bg-white border border-[#EAE2D8] rounded-lg p-1">
                {[
                  { id: 'parchment', color: 'bg-[#FCFAF7] border-[#EAE2D8]', label: 'קלף' },
                  { id: 'white', color: 'bg-white border-neutral-300', label: 'לבן' },
                  { id: 'charcoal', color: 'bg-[#222] border-neutral-700', label: 'כהה' }
                ].map(themeOpt => (
                  <button
                    key={themeOpt.id}
                    onClick={() => setReaderTheme(themeOpt.id as any)}
                    className={`px-2 py-1 rounded text-[10px] font-sans border transition-all ${
                      readerTheme === themeOpt.id ? 'bg-[#B8976C] text-[#FCFAF7] border-[#B8976C]' : 'text-neutral-500 hover:bg-neutral-100'
                    }`}
                    title={themeOpt.label}
                  >
                    {themeOpt.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Reading percent progress bar */}
          <div className="h-1 bg-neutral-100 w-full relative">
            <div 
              className="h-full bg-[#B8976C] transition-all"
              style={{ width: `${readingPercent}%` }}
            ></div>
          </div>

          {/* Reader scrollable canvas */}
          <div className="max-w-3xl mx-auto px-6 py-12 space-y-8 font-serif leading-relaxed text-right overflow-y-auto max-h-[600px]">
            <h1 className="text-3xl font-black text-center border-b pb-4 border-[#B8976C]/30 font-serif">הקדמת המתרגם וההקדמות היסודיות</h1>
            
            <div className={`space-y-6 ${
              readerFontSize === 'sm' ? 'text-sm' :
              readerFontSize === 'md' ? 'text-base' :
              readerFontSize === 'lg' ? 'text-lg' :
              'text-xl'
            }`}>
              {[
                '״דע, כי תועלת הספר הזה ודומיו איננה בהבנת המילים בלבד אלא בחיבור שבין השכל השופע לבין הלב החש. כי האותיות הללו שנכתבו בדיו על גבי קלף, יש בהן כוח לנענע את מיתרי הנשמה הקדומים ביותר.״',
                'הקדמה ראשונה זו מיועדת לכל אדם המבקש אמת וצדק פנימי. דורות רבים נהגו להסתיר את המסתורין של מורה נבוכים וראו בו פנינה למקובלים ואנשי מעשה בלבד. ואולם כיום, בימי חכמה מודרניים אלו, כל המבקש מים חיים יבוא וישתה ממעיין הרמב״ם.',
                'בפרקים הבאים נחקור את מהות הכינויים המושאלים. מה פירוש ״וישמע ה׳״? האם יש לאל אוזן? מה פירוש ״וירא אלוהים״? האם יש לו עיניים גשמיות? מובן שלא. כל אלו אינם אלא ביטויי השאלה של שפת האדם להשגת האלוהות הרוחנית.',
                'התורה דיברה בלשון בני אדם. זהו המפתח הגדול להבנת כל התנ״ך כולו. מי שמפרש את המקרא כפשוטו הגשמי גורם נזק להבנת האמת התורנית ומייחס חומר לאלוהים המופשט מכל גשמיות.',
                'מכאן נמשיך לחקור את בריאת העולם. האם העולם קדמון כפי שגרס אריסטו הפילוסוף היווני, או שמא הוא מחודש ונברא יש מאין כפי שמורה לנו ספר בראשית? דע כי שתי הדעות ניתנות להוכחה שכלית, אך יסוד האמונה גובר ומיישב את דעתנו.'
              ].map((para, idx) => (
                <div key={idx} className="relative group/para pr-6 hover:bg-[#FAF7F2]/50 p-2 rounded transition-all">
                  {/* Bookmark gutter indicator */}
                  <button
                    onClick={() => toggleBookmark(idx)}
                    className="absolute right-0 top-3 text-[#B8976C] opacity-0 group-hover/para:opacity-100 transition-opacity"
                    title="סמן פסקה זו כסימניה"
                  >
                    <Bookmark className={`h-4 w-4 ${bookmarks.includes(idx) ? 'fill-current' : ''}`} />
                  </button>
                  <p className="indent-4">{para}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Reader Footer Controls */}
          <div className="p-4 border-t bg-[#FAF7F2] border-[#EAE2D8] flex items-center justify-between font-sans text-xs text-neutral-500">
            <span>קראת {Math.round(readingPercent)}% מהספר</span>
            <div className="flex items-center gap-3 w-1/2">
              <span className="shrink-0">התקדמות קריאה:</span>
              <input 
                type="range" 
                min={0} 
                max={100}
                value={readingPercent}
                onChange={e => handleProgressChange(Number(e.target.value))}
                className="w-full accent-[#B8976C]"
              />
            </div>
            <div className="flex items-center gap-1">
              <span>מספר סימניות פעילות: {bookmarks.length}</span>
            </div>
          </div>

        </div>
      ) : (
        /* Regular Library view (Dashboard) */
        <div className="space-y-8">
          
          {/* Header block */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#EAE2D8] pb-6">
            <div>
              <h3 className="text-3xl font-serif font-black text-[#0A1D37]">הספרייה הדיגיטלית שלי</h3>
              <p className="text-neutral-500 text-sm font-sans mt-1">כל ספרי השמע, ה-eBooks והסימניות המסונכרנים שלך בענן ספר חכמה.</p>
            </div>

            {/* Offline and sync simulator indicators */}
            <div className="flex items-center gap-3 self-start md:self-auto text-xs font-sans">
              <span className="flex items-center gap-1 text-emerald-600 font-semibold bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-100">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping"></span>
                מסונכרן עם הענן (סייב אוטומטי)
              </span>
              <button 
                onClick={() => alert('כל קבצי ה-EPUB וה-MP3 הורדו לזיכרון המקומי בהצלחה! הספרייה זמינה כעת לקריאה ללא חיבור לאינטרנט.')}
                className="px-3.5 py-1.5 border border-[#EAE2D8] rounded-full hover:bg-[#FAF7F2] flex items-center gap-1.5 text-neutral-600 transition-colors"
              >
                <Download className="h-3.5 w-3.5" />
                <span>הורדה לאופליין</span>
              </button>
            </div>
          </div>

          {/* Tabs switch */}
          <div className="flex border-b border-[#EAE2D8]">
            <button
              onClick={() => setActiveTab('ebooks')}
              className={`pb-3 px-6 text-sm font-sans font-bold border-b-2 transition-all flex items-center gap-2 ${
                activeTab === 'ebooks' 
                  ? 'border-[#B8976C] text-[#B8976C]' 
                  : 'border-transparent text-neutral-400 hover:text-neutral-600'
              }`}
            >
              <BookOpen className="h-4.5 w-4.5" />
              <span>ספרים אלקטרוניים (eBooks) ({ebooks.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('audiobooks')}
              className={`pb-3 px-6 text-sm font-sans font-bold border-b-2 transition-all flex items-center gap-2 ${
                activeTab === 'audiobooks' 
                  ? 'border-[#B8976C] text-[#B8976C]' 
                  : 'border-transparent text-neutral-400 hover:text-neutral-600'
              }`}
            >
              <Volume2 className="h-4.5 w-4.5" />
              <span>ספרי שמע (Audiobooks) ({audiobooks.length})</span>
            </button>
          </div>

          {/* Tab contents */}
          {activeTab === 'ebooks' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {ebooks.map(book => {
                const progress = userProfile.readingProgress[book.id] || 0;
                return (
                  <div key={book.id} className="bg-white border border-[#EAE2D8] rounded-xl overflow-hidden p-4 flex flex-col justify-between shadow-sm hover:shadow-md transition-all">
                    <div className="space-y-3">
                      <div className="aspect-[3/4.2] rounded-lg overflow-hidden bg-neutral-100 border border-neutral-200">
                        <img 
                          src={book.coverUrl} 
                          alt={book.title} 
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      
                      <div className="space-y-1">
                        <h4 className="font-serif font-bold text-sm text-[#0A1D37] line-clamp-1">{book.title}</h4>
                        <p className="text-xs text-neutral-500 font-sans">{book.author}</p>
                      </div>

                      {/* Progress percentage slider */}
                      <div className="space-y-1 text-[10px] font-sans">
                        <div className="flex justify-between text-neutral-400">
                          <span>התקדמות קריאה</span>
                          <span>{Math.round(progress)}%</span>
                        </div>
                        <div className="h-1.5 w-full bg-neutral-100 rounded-full overflow-hidden">
                          <div className="h-full bg-[#B8976C]" style={{ width: `${progress}%` }}></div>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setReadingBook(book)}
                      className="mt-4 w-full py-2 bg-[#0A1D37] hover:bg-[#B8976C] text-white text-xs font-sans font-bold rounded-lg transition-all flex items-center justify-center gap-1 shadow-sm"
                    >
                      <BookOpen className="h-3.5 w-3.5" />
                      <span>פתח ספר לקריאה 📖</span>
                    </button>
                  </div>
                );
              })}
            </div>
          ) : (
            /* Audiobooks Tab */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Left sidebar: list of audiobooks */}
              <div className="space-y-3">
                {audiobooks.map(book => {
                  const isActive = playingBook?.id === book.id;
                  return (
                    <div
                      key={book.id}
                      onClick={() => {
                        setPlayingBook(book);
                        setIsPlaying(true);
                      }}
                      className={`cursor-pointer p-4 rounded-xl border text-right transition-all flex gap-3 ${
                        isActive 
                          ? 'bg-white border-[#B8976C] shadow-md ring-1 ring-[#B8976C]' 
                          : 'bg-[#FCFAF7] border-[#EAE2D8] hover:bg-white'
                      }`}
                    >
                      <div className="h-16 w-11 bg-neutral-100 rounded overflow-hidden border border-neutral-200 shrink-0">
                        <img 
                          src={book.coverUrl} 
                          alt={book.title} 
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      
                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                          <h4 className="font-serif font-bold text-xs text-[#0A1D37] line-clamp-1">{book.title}</h4>
                          <p className="text-[10px] text-neutral-400 font-sans">{book.author}</p>
                        </div>
                        <div className="flex items-center justify-between text-[9px] text-neutral-500 font-sans">
                          <span>אורך כולל: {book.audioDuration}</span>
                          {isActive && <span className="text-emerald-600 font-bold animate-pulse">מתנגן כעת 🔊</span>}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Right: Audio Player Panel (Tactile Walnut panel) */}
              {playingBook ? (
                <div className="bg-[#3E2723] text-[#FAF7F2] p-6 rounded-2xl shadow-xl border border-[#B8976C]/30 space-y-6 text-center relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-2xl"></div>
                  
                  {/* Speaker and header */}
                  <div className="flex items-center justify-between text-[#B8976C] text-xs font-sans pb-3 border-b border-white/10">
                    <span>נגן השמע של ספר חכמה</span>
                    <Sparkles className="h-4.5 w-4.5 text-yellow-500" />
                  </div>

                  {/* Album Cover & Title */}
                  <div className="space-y-3">
                    <div className="h-44 w-32 bg-white/10 mx-auto rounded-lg overflow-hidden shadow-2xl border-2 border-[#B8976C]/40">
                      <img 
                        src={playingBook.coverUrl} 
                        alt={playingBook.title} 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div>
                      <h4 className="font-serif font-black text-lg text-[#FAF7F2]">{playingBook.title}</h4>
                      <p className="text-xs text-[#B8976C] font-sans">{playingBook.author}</p>
                    </div>
                  </div>

                  {/* Scrub bar */}
                  <div className="space-y-1">
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={audioProgress}
                      onChange={e => setAudioProgress(Number(e.target.value))}
                      className="w-full accent-[#B8976C]"
                    />
                    <div className="flex justify-between text-[10px] text-[#FAF7F2]/60 font-mono">
                      <span>{audioTimer} נותר</span>
                      <span>{Math.round(audioProgress)}%</span>
                    </div>
                  </div>

                  {/* Synchronized Transcript preview */}
                  <div className="bg-black/30 p-3 rounded-lg text-xs leading-relaxed text-[#B8976C] font-serif border border-white/5 max-h-16 overflow-hidden">
                    <p className="animate-pulse">
                      ״...ודע, כי תועלת הספר הזה ודומיו איננה בהבנת המילים בלבד אלא בחיבור שבין השכל השופע...״
                    </p>
                  </div>

                  {/* Playback Speed controls */}
                  <div className="flex justify-center gap-1.5">
                    {[1.0, 1.25, 1.5, 2.0].map(speed => (
                      <button
                        key={speed}
                        onClick={() => setPlaybackSpeed(speed)}
                        className={`text-[9px] px-2 py-0.5 rounded border transition-colors ${
                          playbackSpeed === speed 
                            ? 'bg-[#B8976C] border-[#B8976C] text-[#3E2723] font-bold' 
                            : 'border-white/15 text-[#FAF7F2]/60 hover:bg-white/5'
                        }`}
                      >
                        {speed}x
                      </button>
                    ))}
                  </div>

                  {/* Core Player Controls */}
                  <div className="flex items-center justify-center gap-6 pt-2">
                    <button 
                      onClick={() => setAudioProgress(Math.max(0, audioProgress - 5))}
                      className="p-2 hover:text-[#B8976C] text-white/80 transition-colors"
                      title="15 שניות אחורה"
                    >
                      <RotateCcw className="h-5 w-5" />
                    </button>

                    <button
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="h-14 w-14 bg-[#B8976C] text-[#3E2723] rounded-full flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-md cursor-pointer"
                    >
                      {isPlaying ? <Pause className="h-6 w-6 fill-current" /> : <Play className="h-6 w-6 fill-current" />}
                    </button>

                    <button 
                      onClick={() => setAudioProgress(Math.min(100, audioProgress + 5))}
                      className="p-2 hover:text-[#B8976C] text-white/80 transition-colors"
                      title="15 שניות קדימה"
                    >
                      <RotateCw className="h-5 w-5" />
                    </button>
                  </div>

                </div>
              ) : (
                <div className="bg-[#FAF7F2] border border-[#EAE2D8] rounded-2xl p-10 text-center flex flex-col justify-center items-center text-neutral-400 space-y-2">
                  <Volume2 className="h-12 w-12 stroke-[1]" />
                  <p className="text-sm font-semibold text-[#0A1D37]">בחר ספר שמע בצד שמאל</p>
                  <p className="text-xs">הנגן המשובח שלנו יטען מיידית עם בקרת קצב וכתוביות שמע מסונכרנות.</p>
                </div>
              )}

            </div>
          )}

        </div>
      )}

    </div>
  );
}
