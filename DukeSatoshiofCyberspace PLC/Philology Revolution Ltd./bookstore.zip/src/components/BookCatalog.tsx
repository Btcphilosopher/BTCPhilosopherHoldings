import React, { useState } from 'react';
import { 
  Filter, 
  BookOpen, 
  Star, 
  ShoppingBag, 
  Sparkles, 
  Feather, 
  CheckCircle, 
  HelpCircle,
  FileText,
  Volume2,
  Bookmark
} from 'lucide-react';
import { Book, Category } from '../types';

interface BookCatalogProps {
  books: Book[];
  categories: Category[];
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  onSelectBook: (book: Book) => void;
  addToCart: (book: Book, format: 'print' | 'ebook' | 'audiobook') => void;
  addToWishlist: (bookId: string) => void;
  wishlist: string[];
}

export default function BookCatalog({
  books,
  categories,
  selectedCategory,
  setSelectedCategory,
  onSelectBook,
  addToCart,
  addToWishlist,
  wishlist
}: BookCatalogProps) {
  const [activeFormat, setActiveFormat] = useState<'all' | 'print' | 'ebook' | 'audiobook'>('all');
  const [activeType, setActiveType] = useState<'all' | 'rare' | 'preorder'>('all');
  const [maxPrice, setMaxPrice] = useState<number>(1500);
  const [sortBy, setSortBy] = useState<'rating' | 'priceAsc' | 'priceDesc' | 'title'>('rating');

  // Filter books
  const filteredBooks = books.filter(book => {
    // Category check
    if (selectedCategory !== 'all' && book.category !== selectedCategory) {
      return false;
    }
    // Format check
    if (activeFormat === 'ebook' && !book.isEbook) return false;
    if (activeFormat === 'audiobook' && !book.isAudiobook) return false;
    if (activeFormat === 'print' && book.isRare) {
      // Print is default but rare is separate
    }
    // Type check
    if (activeType === 'rare' && !book.isRare) return false;
    if (activeType === 'preorder' && !book.isPreOrder) return false;
    
    // Price check
    if (book.price > maxPrice) return false;

    return true;
  });

  // Sort books
  const sortedBooks = [...filteredBooks].sort((a, b) => {
    if (sortBy === 'rating') return b.rating - a.rating;
    if (sortBy === 'priceAsc') return a.price - b.price;
    if (sortBy === 'priceDesc') return b.price - a.price;
    if (sortBy === 'title') return a.title.localeCompare(b.title, 'he');
    return 0;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" dir="rtl">
      
      {/* Category Landing Mockup Grid (from uploaded mockup image) */}
      <div className="mb-14">
        <div className="text-center mb-8">
          <h3 className="text-2xl sm:text-3xl font-serif font-bold text-[#0A1D37]">קטגוריות מובילות</h3>
          <p className="text-[#B8976C] text-xs font-sans uppercase tracking-widest mt-1">מבחר מחלקות הספרייה הלאומית והפרטית</p>
          <div className="h-0.5 w-12 bg-[#B8976C] mx-auto mt-3"></div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <div 
            onClick={() => setSelectedCategory('all')}
            className={`cursor-pointer group flex flex-col items-center bg-[#FAF7F2] rounded-xl overflow-hidden border transition-all duration-300 ${
              selectedCategory === 'all' ? 'border-[#B8976C] ring-1 ring-[#B8976C] shadow-md' : 'border-[#EAE2D8] hover:shadow-sm'
            }`}
          >
            <div className="h-28 w-full bg-neutral-200 relative overflow-hidden shrink-0">
              <img 
                src="https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=300" 
                alt="כל הספרים" 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-[#0A1D37]/30 flex items-center justify-center">
                <span className="text-white text-3xl font-serif">כל</span>
              </div>
            </div>
            <div className="p-3 text-center w-full bg-white flex-1 flex flex-col justify-center">
              <span className="text-xs sm:text-sm font-serif font-bold text-[#0A1D37]">כל הספרים</span>
              <span className="text-[10px] text-neutral-400 font-sans mt-0.5">לחצו לצפייה</span>
            </div>
          </div>

          {categories.map(cat => {
            const isSelected = selectedCategory === cat.id;
            return (
              <div
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`cursor-pointer group flex flex-col items-center bg-[#FAF7F2] rounded-xl overflow-hidden border transition-all duration-300 ${
                  isSelected ? 'border-[#B8976C] ring-1 ring-[#B8976C] shadow-md' : 'border-[#EAE2D8] hover:shadow-sm'
                }`}
              >
                <div className="h-28 w-full bg-neutral-200 relative overflow-hidden shrink-0">
                  <img 
                    src={cat.imageUrl} 
                    alt={cat.nameHe} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/10"></div>
                </div>
                <div className="p-3 text-center w-full bg-white flex-1 flex flex-col justify-center">
                  <span className="text-xs sm:text-sm font-serif font-bold text-[#0A1D37] leading-tight line-clamp-1">{cat.nameHe}</span>
                  <span className="text-[10px] text-neutral-400 font-sans mt-0.5">← לצפייה</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Content Layout with Sidebar Filters */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Sidebar Filters */}
        <div className="lg:col-span-1 bg-white border border-[#EAE2D8] rounded-2xl p-5 space-y-6 h-fit sticky top-28 shadow-sm">
          <div className="flex items-center gap-2 border-b border-neutral-100 pb-3">
            <Filter className="h-4 w-4 text-[#B8976C]" />
            <h4 className="text-sm font-serif font-bold text-[#0A1D37]">מסננים מתקדמים</h4>
          </div>

          {/* Formats */}
          <div className="space-y-2">
            <span className="text-xs font-serif font-bold text-[#0A1D37]">פורמט ספר</span>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'all', label: 'הכל' },
                { id: 'print', label: 'מודפס' },
                { id: 'ebook', label: 'דיגיטלי (eBook)' },
                { id: 'audiobook', label: 'שמע (Audio)' }
              ].map(formatOption => (
                <button
                  key={formatOption.id}
                  onClick={() => setActiveFormat(formatOption.id as any)}
                  className={`text-xs font-sans px-2 py-1.5 rounded-lg border transition-all text-right ${
                    activeFormat === formatOption.id 
                      ? 'bg-[#0A1D37] text-white border-[#0A1D37]' 
                      : 'bg-[#FAF7F2] text-neutral-600 border-neutral-200 hover:bg-[#F5EFEB]'
                  }`}
                >
                  {formatOption.label}
                </button>
              ))}
            </div>
          </div>

          {/* Special Editions */}
          <div className="space-y-2 pt-2 border-t border-neutral-100">
            <span className="text-xs font-serif font-bold text-[#0A1D37]">סוג מהדורה</span>
            <div className="flex flex-col gap-1.5">
              {[
                { id: 'all', label: 'כל המהדורות' },
                { id: 'rare', label: 'מהדורות נדירות ואספניות בלבד' },
                { id: 'preorder', label: 'מכירה מוקדמת בלבד' }
              ].map(typeOption => (
                <button
                  key={typeOption.id}
                  onClick={() => setActiveType(typeOption.id as any)}
                  className={`text-xs font-sans px-3 py-2 rounded-lg border text-right transition-all flex items-center justify-between ${
                    activeType === typeOption.id 
                      ? 'bg-[#B8976C] text-[#FCFAF7] border-[#B8976C] font-semibold' 
                      : 'bg-[#FAF7F2] text-neutral-600 border-neutral-200 hover:bg-[#F5EFEB]'
                  }`}
                >
                  <span>{typeOption.label}</span>
                  {typeOption.id === 'rare' && <Sparkles className="h-3 w-3 text-amber-500 fill-amber-500/20" />}
                </button>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div className="space-y-2 pt-2 border-t border-neutral-100">
            <div className="flex justify-between items-center text-xs">
              <span className="font-serif font-bold text-[#0A1D37]">טווח מחירים</span>
              <span className="font-mono text-[#B8976C] font-semibold">עד ₪{maxPrice}</span>
            </div>
            <input 
              type="range" 
              min={50} 
              max={1500} 
              step={10}
              value={maxPrice}
              onChange={e => setMaxPrice(Number(e.target.value))}
              className="w-full accent-[#B8976C]"
            />
            <div className="flex justify-between text-[10px] text-neutral-400 font-sans">
              <span>₪50</span>
              <span>₪1500</span>
            </div>
          </div>

          {/* Quick Stats Helper */}
          <div className="bg-[#FAF7F2] p-3.5 rounded-xl border border-[#EAE2D8] space-y-1.5">
            <p className="text-[11px] font-sans text-neutral-500">
              מצאנו <strong className="text-[#0A1D37] font-sans font-bold">{filteredBooks.length}</strong> ספרים העונים להגדרות הסינון שלך.
            </p>
            <p className="text-[10px] text-[#B8976C] font-serif leading-relaxed">
              * מהדורות דיגיטליות זמינות לקריאה מיידית לאחר הרכישה תחת עמוד "הספרייה הדיגיטלית".
            </p>
          </div>
        </div>

        {/* Books Grid Area */}
        <div className="lg:col-span-3 space-y-6">
          
          {/* Grid Header Controls */}
          <div className="bg-white border border-[#EAE2D8] rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs shadow-sm">
            <div>
              <span className="text-neutral-500 font-sans">מציג ספרים בקטגוריית: </span>
              <strong className="text-[#0A1D37] font-serif font-bold">
                {selectedCategory === 'all' ? 'כל הספרים' : categories.find(c => c.id === selectedCategory)?.nameHe}
              </strong>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto font-sans">
              <span className="text-neutral-500">מיון לפי:</span>
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value as any)}
                className="bg-[#FAF7F2] border border-[#EAE2D8] p-1.5 rounded-lg text-[#222] font-semibold outline-none focus:border-[#B8976C]"
              >
                <option value="rating">ציון גולשים (גבוה לנמוך)</option>
                <option value="priceAsc">מחיר: נמוך לגבוה</option>
                <option value="priceDesc">מחיר: גבוה לנמוך</option>
                <option value="title">שם הספר (א-ת)</option>
              </select>
            </div>
          </div>

          {/* Book Cards Grid */}
          {sortedBooks.length === 0 ? (
            <div className="bg-[#FAF7F2] rounded-2xl border border-dashed border-[#EAE2D8] p-12 text-center space-y-3">
              <BookOpen className="h-12 w-12 text-[#B8976C]/40 mx-auto" />
              <h5 className="font-serif font-semibold text-[#0A1D37]">לא נמצאו ספרים תואמים</h5>
              <p className="text-xs text-neutral-500 font-sans">נסו לבחור קטגוריה אחרת או להרחיב את טווחי הסינון</p>
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setActiveFormat('all');
                  setActiveType('all');
                  setMaxPrice(1500);
                }}
                className="text-xs font-semibold text-[#B8976C] hover:underline"
              >
                אפס את כל המסננים
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {sortedBooks.map(book => {
                const isWishlisted = wishlist.includes(book.id);
                return (
                  <div
                    key={book.id}
                    className="group bg-[#FCFAF7] border border-[#EAE2D8] rounded-2xl p-4 flex flex-col justify-between transition-all duration-300 hover:shadow-lg hover:border-[#B8976C]/40 relative"
                  >
                    {/* Rare badge */}
                    {book.isRare && (
                      <div className="absolute top-4 right-4 z-10 bg-[#3E2723] text-[#FAF7F2] text-[9px] font-sans px-2.5 py-1 rounded-full border border-[#B8976C]/30 flex items-center gap-1">
                        <Sparkles className="h-2.5 w-2.5 text-[#B8976C]" />
                        <span>מהדורה נדירה</span>
                      </div>
                    )}

                    {/* Book Cover Lift Microinteraction (Tactile 3D effect on Hover) */}
                    <div 
                      onClick={() => onSelectBook(book)}
                      className="cursor-pointer aspect-[3/4] bg-neutral-100 rounded-lg overflow-hidden shadow-sm relative group mb-4 border border-neutral-200 flex items-center justify-center p-1"
                    >
                      {/* Left side book-page realistic shadow */}
                      <div className="absolute inset-y-0 right-0 w-3 bg-gradient-to-l from-black/25 to-transparent z-20"></div>
                      
                      {/* Interactive cover elements */}
                      <img 
                        src={book.coverUrl} 
                        alt={book.title} 
                        className="w-full h-full object-cover transition-all duration-500 group-hover:scale-104 group-hover:-translate-x-1.5 group-hover:rotate-1 group-hover:shadow-2xl brightness-95"
                        referrerPolicy="no-referrer"
                      />
                      
                      {/* Subtle elegant cover page lines for tactile luxury feel */}
                      <div className="absolute inset-y-0 left-0 w-px bg-white/20 z-20"></div>

                      <div className="absolute inset-0 bg-[#0A1D37]/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <span className="bg-[#FCFAF7] text-[#0A1D37] text-xs font-serif font-bold px-3 py-1.5 rounded-full shadow-md transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                          לעיון בספר 📖
                        </span>
                      </div>
                    </div>

                    {/* Meta info */}
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-[10px] text-neutral-400 font-sans">
                        <span>{book.publisher}</span>
                        <div className="flex items-center gap-1 text-[#B8976C]">
                          <Star className="h-3 w-3 fill-current" />
                          <span className="font-sans font-bold">{book.rating}</span>
                        </div>
                      </div>

                      <h4 
                        onClick={() => onSelectBook(book)}
                        className="font-serif font-extrabold text-sm text-[#0A1D37] cursor-pointer hover:text-[#B8976C] transition-colors leading-snug line-clamp-2"
                      >
                        {book.title}
                      </h4>

                      <p className="text-xs text-neutral-600 font-sans flex items-center gap-1">
                        <Feather className="h-3 w-3 text-neutral-400" />
                        <span>{book.author}</span>
                      </p>

                      <p className="text-xs text-neutral-500 font-sans line-clamp-2 leading-relaxed">
                        {book.description}
                      </p>
                    </div>

                    {/* Footer Action buttons */}
                    <div className="border-t border-neutral-100 mt-4 pt-3 flex items-center justify-between">
                      <div className="text-right">
                        <span className="text-sm font-extrabold text-[#B8976C] font-mono">₪{book.price}</span>
                        {book.isRare && (
                          <p className="text-[9px] text-neutral-400 font-serif font-semibold">אריזת מהדורה כלולה</p>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {/* Wishlist toggle */}
                        <button
                          onClick={() => addToWishlist(book.id)}
                          className={`p-2 rounded-full border transition-colors ${
                            isWishlisted 
                              ? 'bg-rose-50 border-rose-200 text-rose-500' 
                              : 'bg-white border-[#EAE2D8] text-neutral-400 hover:text-rose-500 hover:bg-rose-50'
                          }`}
                          title={isWishlisted ? 'הסר מרשימת המשאלות' : 'הוסף לרשימת המשאלות'}
                        >
                          <Bookmark className={`h-4 w-4 ${isWishlisted ? 'fill-current' : ''}`} />
                        </button>

                        {/* Add to Cart popup trigger or Quick purchase */}
                        <button
                          onClick={() => addToCart(book, 'print')}
                          className="px-3.5 py-1.5 bg-[#0A1D37] text-white hover:bg-[#B8976C] rounded-lg text-xs font-sans font-bold transition-all flex items-center gap-1 shadow-sm"
                        >
                          <ShoppingBag className="h-3.5 w-3.5" />
                          <span>רכישה</span>
                        </button>
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
