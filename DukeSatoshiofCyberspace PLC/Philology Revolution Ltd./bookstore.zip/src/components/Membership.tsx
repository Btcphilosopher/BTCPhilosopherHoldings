import React, { useState } from 'react';
import { 
  Sparkles, 
  CheckCircle, 
  Calendar, 
  Tv, 
  Award, 
  Users, 
  ArrowLeft, 
  Star, 
  CreditCard,
  Play,
  Lock,
  Pause,
  Clock
} from 'lucide-react';
import { Book, UserProfile } from '../types';

interface MembershipProps {
  userProfile: UserProfile;
  onJoinMembership: () => void;
  books: Book[];
  onSelectBook: (book: Book) => void;
}

export default function Membership({
  userProfile,
  onJoinMembership,
  books,
  onSelectBook
}: MembershipProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [cardName, setCardName] = useState('');
  const [cardNumber, setCardNumber] = useState('4580 9821 1234 5678');
  const [activeVideo, setActiveVideo] = useState<'intro' | 'philosophy' | 'poetry' | null>(null);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);

  // Exclusive member recommendations
  const memberBookSpotlight = books.find(b => b.id === '1') || books[0];

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      onJoinMembership();
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" dir="rtl">
      
      {/* Banner introduction */}
      <div className="text-center mb-10 max-w-3xl mx-auto space-y-3">
        <h3 className="text-3xl font-serif font-black text-[#0A1D37]">קהילת ספר חכמה</h3>
        <p className="text-[#B8976C] text-xs font-sans uppercase tracking-widest">מפגשים ספרותיים, הגות מעמיקה ומחירים בלעדיים לחברים</p>
        <div className="h-0.5 w-12 bg-[#B8976C] mx-auto mt-2"></div>
      </div>

      {/* Conditionally render Member Area based on Profile State */}
      {userProfile.isMember ? (
        /* Member Dashboard View */
        <div className="space-y-10">
          
          {/* Member Status Hero block */}
          <div className="bg-[#0A1D37] text-white rounded-2xl p-6 sm:p-8 border border-[#B8976C]/30 shadow-xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl"></div>
            
            <div className="space-y-3 relative text-right">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#B8976C] text-white text-xs rounded-full font-bold">
                <Award className="h-3.5 w-3.5" />
                <span>חבר קהילה רשום</span>
              </span>
              <h4 className="text-2xl sm:text-3xl font-serif font-bold">ברוך הבא, {userProfile.name}!</h4>
              <p className="text-neutral-300 text-xs font-sans">מספר חבר: <strong className="text-[#B8976C]">SC-MEMBER-99214</strong> • חבר פעיל מאז: {userProfile.membershipSince}</p>
              
              <div className="flex gap-4 pt-2 text-xs text-neutral-200">
                <span>✓ 10% הנחה קבועה על כל הספרים</span>
                <span>✓ גישה לכל ההרצאות הפרטיות</span>
              </div>
            </div>

            <div className="bg-[#FCFAF7] text-[#0A1D37] p-4 rounded-xl border border-[#EAE2D8] text-center w-full md:w-56 space-y-1 z-10 shrink-0">
              <span className="text-xs text-[#B8976C] font-semibold block">קוד קופון חברים פעיל</span>
              <strong className="text-lg font-mono tracking-widest block text-[#0A1D37]">CHOKHMAH10</strong>
              <span className="text-[10px] text-neutral-400 font-sans block pt-1 border-t border-neutral-100">הזן בקופה להחלת 10% הנחה</span>
            </div>
          </div>

          {/* Member Video Lecture Hub */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left: Interactive Media Player */}
            <div className="lg:col-span-8 bg-white border border-[#EAE2D8] rounded-2xl p-6 shadow-sm space-y-4">
              <h4 className="font-serif font-bold text-lg text-[#0A1D37] border-b border-neutral-100 pb-2">הרצאות ושיחות ספרותיות פרטיות (VOD לחברים)</h4>
              
              {activeVideo ? (
                <div className="space-y-4">
                  {/* Mock Video Player Canvas */}
                  <div className="relative aspect-video bg-[#222] rounded-xl overflow-hidden border border-[#EAE2D8] flex flex-col justify-between p-4">
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                    
                    {/* Header */}
                    <div className="z-10 flex items-center justify-between text-white text-xs font-sans">
                      <span className="bg-[#B8976C] px-2 py-0.5 rounded font-bold">שידור מוקלט מהסניף הירושלמי</span>
                      <Clock className="h-4 w-4" />
                    </div>

                    {/* Central Animation */}
                    <div className="z-10 text-center space-y-2">
                      {isVideoPlaying ? (
                        <div className="flex flex-col items-center gap-2">
                          <span className="h-3 w-3 rounded-full bg-red-600 animate-ping"></span>
                          <span className="text-white text-sm font-sans font-semibold">מזרים הרצאה ב-1080p Ultra HD...</span>
                          <div className="flex gap-1 justify-center py-2">
                            {[...Array(5)].map((_, i) => (
                              <span key={i} className="h-4 w-1 bg-[#B8976C] animate-pulse"></span>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <p className="text-white text-sm font-serif font-semibold">לחצו על לחצן הניגון להתחלת ההרצאה</p>
                      )}
                    </div>

                    {/* Controls */}
                    <div className="z-10 flex items-center justify-between text-white text-xs">
                      <button
                        onClick={() => setIsVideoPlaying(!isVideoPlaying)}
                        className="px-4 py-1.5 bg-[#B8976C] text-[#3E2723] rounded-full font-bold hover:bg-white hover:text-[#0A1D37] transition-all flex items-center gap-1.5"
                      >
                        {isVideoPlaying ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                        <span>{isVideoPlaying ? 'עצור הרצאה' : 'נגן שידור'}</span>
                      </button>
                      <span className="font-mono">42:15 / 55:00</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <h5 className="font-serif font-bold text-[#0A1D37] text-base">
                      {activeVideo === 'intro' ? 'הרמב״ם כמורה של המאה ה-21' : activeVideo === 'philosophy' ? 'תורת ארץ ישראל וספר הכוזרי' : 'הרמזים הנסתרים בשירת זלדה'}
                    </h5>
                    <p className="text-xs text-neutral-500 font-sans mt-1">
                      הרצאת מופת זו עוסקת במפעלו הפילוסופי האדיר של רבי משה בן מימון, בהנחיית פרופסורים מובילים לחקר מחשבת ישראל.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="bg-[#FAF7F2] border border-[#EAE2D8] rounded-xl p-8 text-center flex flex-col justify-center items-center text-neutral-500 space-y-3">
                  <Tv className="h-12 w-12 text-[#B8976C] stroke-[1]" />
                  <p className="font-serif font-bold text-sm text-[#0A1D37]">בחר אחת מן ההרצאות בצד שמאל</p>
                  <p className="text-xs">הצטרפו ללמדנות מעמיקה מכל מקום ובכל שעה בעזרת שידורי הארכיון של קהילת חכמה.</p>
                </div>
              )}

            </div>

            {/* Right: Lecture Playlist (4 cols) */}
            <div className="lg:col-span-4 bg-[#FCFAF7] border border-[#EAE2D8] rounded-2xl p-5 space-y-3 shadow-sm">
              <span className="text-xs font-serif font-bold text-[#B8976C] uppercase tracking-wider block">פלייליסט הרצאות חברים</span>
              
              <div className="flex flex-col gap-2">
                {[
                  { id: 'intro', title: 'הרמב״ם כמורה של המאה ה-21', length: '55 דקות', speaker: 'פרופ׳ אבי שגיא' },
                  { id: 'philosophy', title: 'ארץ ישראל וספר הכוזרי', length: '48 דקות', speaker: 'ד״ר דרור בונדי' },
                  { id: 'poetry', title: 'הרמזים הנסתרים בשירת זלדה', length: '39 דקות', speaker: 'בכל סרלואי' }
                ].map(lecture => (
                  <button
                    key={lecture.id}
                    onClick={() => {
                      setActiveVideo(lecture.id as any);
                      setIsVideoPlaying(true);
                    }}
                    className={`w-full text-right p-3 rounded-xl border transition-all flex flex-col justify-between ${
                      activeVideo === lecture.id 
                        ? 'bg-white border-[#B8976C] shadow' 
                        : 'bg-[#FAF7F2] border-neutral-100 hover:bg-white'
                    }`}
                  >
                    <span className="text-xs font-serif font-extrabold text-[#0A1D37]">{lecture.title}</span>
                    <div className="flex justify-between text-[10px] text-neutral-400 font-sans mt-2">
                      <span>מרצה: {lecture.speaker}</span>
                      <span>{lecture.length}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Member exclusive book review & spotlight */}
          <div className="bg-white border border-[#EAE2D8] rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-2 mb-6">
              <Sparkles className="h-5 w-5 text-[#B8976C]" />
              <h4 className="font-serif font-bold text-lg text-[#0A1D37]">ספר החודש הבלעדי לחברי הקהילה</h4>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
              <div className="md:col-span-3 max-w-[160px] mx-auto md:mx-0">
                <img 
                  src={memberBookSpotlight.coverUrl} 
                  alt={memberBookSpotlight.title} 
                  className="rounded-lg shadow-xl border border-[#EAE2D8]"
                  referrerPolicy="no-referrer"
                />
              </div>
              
              <div className="md:col-span-9 text-right space-y-3">
                <h5 className="font-serif font-black text-xl text-[#0A1D37]">{memberBookSpotlight.title}</h5>
                <p className="text-xs text-neutral-400 font-sans">{memberBookSpotlight.author} • מהדורת מוסד הרב קוק</p>
                <p className="text-neutral-600 text-sm leading-relaxed font-sans">
                  החודש אנו מעמיקים בספר היסוד לפילוסופיה היהודית. מהדורה זו, הכוללת הערות וביאורים של מוסד הרב קוק, מוגשת לחברי הקהילה בלבד במחיר מיוחד של <strong>₪169</strong> במקום ₪189.
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => onSelectBook(memberBookSpotlight)}
                    className="px-5 py-2.5 bg-[#0A1D37] text-white hover:bg-[#B8976C] font-sans font-bold text-xs rounded-lg shadow-sm transition-colors"
                  >
                    קרא חוות דעת ורכוש כעת
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Reading clubs schedules */}
          <div className="space-y-4">
            <h4 className="font-serif font-bold text-lg text-[#0A1D37]">מעגלי קריאה ואירועים סגורים לחברים השבוע</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs font-sans">
              {[
                { title: 'מעגל הגות: קריאה מונחית בכוזרי', date: 'יום שני, 19:00', host: 'הרב שמואל הלוי' },
                { title: 'סלון שירה: על הזיקה בין תפילה לפרוזה', date: 'יום רביעי, 20:30', host: 'ד״ר מיכל אבן' },
                { title: 'מועדון קוראים: שיחה על מיכאל שלי', date: 'יום חמישי, 18:00', host: 'הסופרת רונית בר' }
              ].map((club, idx) => (
                <div key={idx} className="bg-[#FAF7F2] border border-[#EAE2D8] p-4 rounded-xl space-y-2.5">
                  <div className="flex justify-between items-center text-[#B8976C] font-bold">
                    <span>{club.date}</span>
                    <Users className="h-4 w-4" />
                  </div>
                  <h5 className="font-serif font-bold text-sm text-[#0A1D37]">{club.title}</h5>
                  <p className="text-neutral-500 font-sans text-[11px]">מנחה: {club.host}</p>
                  <button 
                    onClick={() => alert(`נרשמת בהצלחה למעגל הקריאה: "${club.title}". קישור זום והזמנה ליומן נשלחו לתיבת האימייל שלך.`)}
                    className="w-full py-1.5 bg-white hover:bg-[#B8976C] hover:text-white border border-[#EAE2D8] text-[#0A1D37] rounded-lg transition-all font-semibold"
                  >
                    הירשם למעגל 📅
                  </button>
                </div>
              ))}
            </div>
          </div>

        </div>
      ) : (
        /* Invite Non-Member View (Premium Sales funnel) */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Register Form (5 cols) */}
          <div className="lg:col-span-5 bg-white border border-[#EAE2D8] rounded-2xl p-6 sm:p-8 shadow-xl text-right">
            <h4 className="font-serif font-black text-xl text-[#0A1D37] border-b border-neutral-100 pb-3 mb-4 flex items-center gap-2">
              <CreditCard className="h-5.5 w-5.5 text-[#B8976C]" />
              <span>הצטרפו לקהילת ספר חכמה</span>
            </h4>

            <form onSubmit={handleRegister} className="space-y-4 text-xs font-sans">
              <div>
                <label className="block text-neutral-500 mb-1">שמך המלא</label>
                <input
                  type="text"
                  required
                  value={cardName}
                  onChange={e => setCardName(e.target.value)}
                  placeholder="ישראל ישראלי"
                  className="w-full p-2.5 border border-[#EAE2D8] rounded-lg bg-[#FAF7F2] outline-none focus:border-[#B8976C]"
                />
              </div>

              <div>
                <label className="block text-neutral-500 mb-1">מספר כרטיס אשראי לחיוב</label>
                <input
                  type="text"
                  required
                  value={cardNumber}
                  onChange={e => setCardNumber(e.target.value)}
                  className="w-full p-2.5 border border-[#EAE2D8] rounded-lg bg-[#FAF7F2] font-mono text-left tracking-widest outline-none focus:border-[#B8976C]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-neutral-500 mb-1">תוקף</label>
                  <input
                    type="text"
                    required
                    placeholder="MM/YY"
                    className="w-full p-2.5 border border-[#EAE2D8] rounded-lg bg-[#FAF7F2] text-center font-mono outline-none"
                  />
                </div>
                <div>
                  <label className="block text-neutral-500 mb-1">CVC</label>
                  <input
                    type="password"
                    required
                    maxLength={3}
                    placeholder="•••"
                    className="w-full p-2.5 border border-[#EAE2D8] rounded-lg bg-[#FAF7F2] text-center font-mono outline-none"
                  />
                </div>
              </div>

              <div className="bg-[#FAF7F2] p-3.5 rounded-lg border border-[#EAE2D8] space-y-1">
                <div className="flex justify-between font-bold text-sm text-[#0A1D37]">
                  <span>דמי חברות שנתיים:</span>
                  <span>₪120 לשנה</span>
                </div>
                <p className="text-[10px] text-neutral-400">החיוב מתבצע פעם בשנה ומעניק גישה מיידית לכל הטבות המועדון.</p>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 bg-[#0A1D37] text-white hover:bg-[#B8976C] rounded-full text-sm font-sans font-bold transition-all shadow flex items-center justify-center gap-2 cursor-pointer"
              >
                {isSubmitting ? (
                  <span>רושם אותך במערכת...</span>
                ) : (
                  <>
                    <span>הירשמו עכשיו וקבלו 10% הנחה מיידית</span>
                    <ArrowLeft className="h-4 w-4" />
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Right Column: Perks and Benefits showcase (7 cols) */}
          <div className="lg:col-span-7 space-y-6 text-right">
            <h4 className="font-serif font-black text-2xl sm:text-3xl text-[#0A1D37] leading-tight">
              הצטרפו אל חובבי הספרים, המתרגמים, החוקרים והקוראים בישראל.
            </h4>
            <p className="text-neutral-600 text-sm font-sans leading-relaxed">
              העולם הדיגיטלי הופך לפעמים לשטחי, קהילת ״ספר חכמה״ נבנתה במטרה להוות אי של למדנות, מסורת, אהבת ספרים עברית ואסתטיקה ייחודית שאי אפשר למצוא בשום מקום אחר.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {[
                { title: '10% הנחה קבועה בספרייה', desc: 'הנחה אוטומטית על כל קטלוג הספרים כולל מהדורות נדירות, ספרי שמע ודיגיטל.' },
                { title: 'הרצאות אקדמיות מוקלטות', desc: 'גישה בלעדית לספריית השיעורים והמחקרים במחשבת ישראל ופילוסופיה של מומחים.' },
                { title: 'מפגשים עם סופרים וחוקרים', desc: 'קבלו הזמנות מוקדמות וחינמיות למפגשים אינטימיים, מעגלי קריאה ואירועי חתימות.' },
                { title: 'גרסאות דיגיטליות מתנה', desc: 'מדי שלושה חודשים בחרו eBook או ספר שמע מתוך קטגוריית "המלצת החודש" במתנה.' }
              ].map((perk, idx) => (
                <div key={idx} className="bg-[#FAF7F2] p-4 rounded-xl border border-[#EAE2D8] space-y-1">
                  <div className="flex items-center gap-1.5 text-[#B8976C] font-serif font-bold text-sm">
                    <CheckCircle className="h-4.5 w-4.5 shrink-0" />
                    <span>{perk.title}</span>
                  </div>
                  <p className="text-neutral-500 text-xs font-sans leading-relaxed">{perk.desc}</p>
                </div>
              ))}
            </div>

            {/* Micro quote decoration */}
            <div className="border-r-4 border-[#B8976C] pr-4 py-2 text-xs text-neutral-500 italic font-serif leading-relaxed bg-[#FAF7F2]">
              ״אין אהבת ספר קיימת ללא קהילה של מחשבה שתקיף אותו.״
              <span className="block text-[#0A1D37] font-semibold font-sans mt-1">מתוך מניפסט חכמה, תשפ״ו</span>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
