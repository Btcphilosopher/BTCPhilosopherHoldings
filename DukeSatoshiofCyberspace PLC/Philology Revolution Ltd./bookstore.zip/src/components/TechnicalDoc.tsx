import React from 'react';
import { 
  FileText, 
  Cpu, 
  Layers, 
  Server, 
  Compass, 
  CheckCircle,
  HelpCircle,
  BookOpen,
  Sparkles,
  ArrowRight,
  Database
} from 'lucide-react';
import { DESIGN_SYSTEM_INFO } from '../data';

interface TechnicalDocProps {
  onBackToHome: () => void;
}

export default function TechnicalDoc({ onBackToHome }: TechnicalDocProps) {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10 text-right space-y-10" dir="rtl">
      
      {/* Header introduction */}
      <div className="text-center space-y-3">
        <span className="px-3 py-1 bg-[#B8976C]/15 text-[#B8976C] text-xs font-sans font-bold rounded-full">מפרט ארכיטקטורה ועיצוב</span>
        <h3 className="text-3xl font-serif font-black text-[#0A1D37]">ספריית ספר חכמה - ספר מפרט טכני</h3>
        <p className="text-neutral-500 text-sm font-sans">מדריך הנדסי המפרט את בחירות הטיפוגרפיה, הקוד, בסיסי הנתונים ושרשרת האספקה הטכנולוגית.</p>
        <div className="h-0.5 w-12 bg-[#B8976C] mx-auto mt-2"></div>
      </div>

      {/* Philosophy Section */}
      <div className="bg-[#FAF7F2] border border-[#EAE2D8] rounded-2xl p-6 sm:p-8 space-y-4">
        <h4 className="font-serif font-black text-lg text-[#0A1D37] flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-[#B8976C]" />
          <span>פילוסופיית עיצוב אסתטית</span>
        </h4>
        <p className="text-neutral-600 text-xs sm:text-sm leading-relaxed font-sans">
          המערכת נבנתה תחת עקרון ה-<strong>Quiet Luxury (יוקרה שקטה)</strong> - הימנעות מוחלטת מצבעים זוהרים או אפקטים דיגיטליים רועשים. כל החלטה חזותית מבוססת על האות העברית, חלוקת משקל מושלמת ומרחב קריאה נקי.
        </p>

        {/* Color tokens showcase */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-4">
          {DESIGN_SYSTEM_INFO.palette.map((color, idx) => (
            <div key={idx} className="bg-white p-3 rounded-lg border border-neutral-100 flex items-center gap-2 text-xs">
              <div className="h-8 w-8 rounded-md border" style={{ backgroundColor: color.code }}></div>
              <div className="text-right">
                <strong className="block text-[#0A1D37]">{color.name}</strong>
                <span className="text-neutral-400 font-mono text-[9px]">{color.code}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Technical stack architecture summary */}
      <div className="space-y-4">
        <h4 className="font-serif font-black text-xl text-[#0A1D37] flex items-center gap-2 pb-2 border-b">
          <Layers className="h-5.5 w-5.5 text-[#B8976C]" />
          <span>מפרט המערכת הטכנולוגית (Tech Stack)</span>
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          
          <div className="bg-white border border-[#EAE2D8] p-5 rounded-xl space-y-3">
            <div className="flex items-center gap-1.5 font-serif font-bold text-sm text-[#0A1D37]">
              <Cpu className="h-4.5 w-4.5 text-[#B8976C]" />
              <span>צד לקוח (Frontend)</span>
            </div>
            <p className="text-[11px] text-neutral-500 font-sans leading-relaxed">
              ממשק משתמש קורן המבוסס על <strong>Next.js / Vite / React 19 / TypeScript</strong>. העימוד נעשה עם Tailwind CSS למהירות טעינה מרבית, ואנימציות עדינות של Framer Motion לתלת-ממד.
            </p>
          </div>

          <div className="bg-white border border-[#EAE2D8] p-5 rounded-xl space-y-3">
            <div className="flex items-center gap-1.5 font-serif font-bold text-sm text-[#0A1D37]">
              <Server className="h-4.5 w-4.5 text-[#B8976C]" />
              <span>צד שרת (Backend API)</span>
            </div>
            <p className="text-[11px] text-neutral-500 font-sans leading-relaxed">
              שרת מהיר ומאובטח במיוחד המקודד בשפת <strong>Rust (Axum Framework)</strong>. מאפשר ביצועי חומרה מקסימליים עם צריכת זיכרון אפסית, וממשקי REST API המשרתים את חלון המלאי.
            </p>
          </div>

          <div className="bg-white border border-[#EAE2D8] p-5 rounded-xl space-y-3">
            <div className="flex items-center gap-1.5 font-serif font-bold text-sm text-[#0A1D37]">
              <Database className="h-4.5 w-4.5 text-[#B8976C]" />
              <span>מסד נתונים וזיכרון (DB)</span>
            </div>
            <p className="text-[11px] text-neutral-500 font-sans leading-relaxed">
              רשומות הספרים, האירועים והמשתמשים שמורות בתוך <strong>PostgreSQL</strong> קלוד-ראן יציב. זיכרון המטמון (Cache) של המלאים מנוהל בתוך <strong>Redis</strong> למניעת עומסי שאילתות.
            </p>
          </div>

        </div>
      </div>

      {/* REST API Endpoints Schema Specification */}
      <div className="bg-white border border-[#EAE2D8] rounded-2xl p-6 shadow-sm space-y-4">
        <h4 className="font-serif font-bold text-base text-[#0A1D37] flex items-center gap-1.5">
          <FileText className="h-5 w-5 text-[#B8976C]" />
          <span>סכמת ממשקי REST API (Rust Axum Route Definitions)</span>
        </h4>
        <p className="text-neutral-500 text-xs font-sans leading-relaxed">
          להלן סכמת הראוטינג כפי שקודדה בצד שרת ה-Rust לאינטגרציה חלקה של סל הקניות וממשקי ה-CMS:
        </p>

        <div className="bg-neutral-900 text-neutral-300 p-4 rounded-xl text-left font-mono text-[10px] sm:text-xs overflow-x-auto space-y-1 leading-relaxed">
          <p className="text-yellow-500">// Rust Axum Endpoint Router definitions</p>
          <p>app.route("/api/books", get(list_books).post(create_book))</p>
          <p>   .route("/api/books/:id", get(get_book_detail).put(update_inventory).delete(delete_book))</p>
          <p>   .route("/api/events", get(list_events).post(create_event))</p>
          <p>   .route("/api/membership/join", post(register_member))</p>
          <p>   .route("/api/orders/checkout", post(stripe_proxy_charge))</p>
          <p>   .route("/api/user/progress", get(get_reading_progress).post(update_reading_progress));</p>
        </div>
      </div>

      {/* Accessibility WCAG AA Checklist compliance */}
      <div className="space-y-4">
        <h4 className="font-serif font-black text-xl text-[#0A1D37] border-b pb-2">נגישות מוגברת ועמידה בתקן WCAG AA</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans text-neutral-600">
          <div className="flex gap-2 items-start">
            <CheckCircle className="h-4.5 w-4.5 text-emerald-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed"><strong>ניגודיות צבעים קפדנית:</strong> כל טקסט עברי במערכת מוגש בניגודיות הגבוהה מ-4.5:1 על רקע השמנת/קלף, בהתאם לדרישות החוק.</p>
          </div>
          <div className="flex gap-2 items-start">
            <CheckCircle className="h-4.5 w-4.5 text-emerald-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed"><strong>תמיכה מלאה בקוראי מסך:</strong> שימוש קפדני בתגיות ARIA מותאמות ורכיבים בעלי הגדרה סמנטית ברורה לניווט קולי.</p>
          </div>
        </div>
      </div>

      {/* Closing button */}
      <div className="text-center pt-4">
        <button
          onClick={onBackToHome}
          className="px-6 py-2.5 bg-[#0A1D37] text-white hover:bg-[#B8976C] rounded-full text-xs font-sans font-bold"
        >
          חזרה לעמוד הבית
        </button>
      </div>

    </div>
  );
}
