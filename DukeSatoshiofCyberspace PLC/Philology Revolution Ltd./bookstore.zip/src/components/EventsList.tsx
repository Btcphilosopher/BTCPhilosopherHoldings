import React, { useState } from 'react';
import { 
  Calendar, 
  MapPin, 
  Clock, 
  Users, 
  CheckCircle, 
  QrCode, 
  Sparkles, 
  Bookmark, 
  ArrowLeft,
  ChevronRight,
  UserCheck
} from 'lucide-react';
import { Event } from '../types';

interface EventsListProps {
  events: Event[];
  onBackToHome: () => void;
}

export default function EventsList({ events, onBackToHome }: EventsListProps) {
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [bookingStep, setBookingStep] = useState<'details' | 'seats' | 'ticket'>('details');
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [attendeeName, setAttendeeName] = useState('');
  const [attendeeEmail, setAttendeeEmail] = useState('tom@ahyx.org');

  // Salon Seat layout simulation (A to E, 1 to 6)
  const rows = ['א', 'ב', 'ג', 'ד', 'ה'];
  const cols = [1, 2, 3, 4, 5, 6];
  // mock occupied seats
  const occupiedSeats = ['א3', 'א4', 'ב1', 'ג5', 'ג6', 'ד2'];

  const handleSeatClick = (seatId: string) => {
    if (occupiedSeats.includes(seatId)) return;
    if (selectedSeats.includes(seatId)) {
      setSelectedSeats(selectedSeats.filter(s => s !== seatId));
    } else {
      setSelectedSeats([...selectedSeats, seatId]);
    }
  };

  const handleBookComplete = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedSeats.length === 0 || !attendeeName.trim()) return;
    setBookingStep('ticket');
  };

  const resetBooking = () => {
    setSelectedEvent(null);
    setBookingStep('details');
    setSelectedSeats([]);
    setAttendeeName('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" dir="rtl">
      
      {/* Header introduction */}
      <div className="text-center mb-10 max-w-2xl mx-auto space-y-3">
        <h3 className="text-3xl font-serif font-black text-[#0A1D37]">אירועי תרבות וסדנאות</h3>
        <p className="text-[#B8976C] text-xs font-sans uppercase tracking-widest">שיח סופרים, השקות יוקרתיות וסדנאות לילדים בסניפי ספר חכמה</p>
        <div className="h-0.5 w-12 bg-[#B8976C] mx-auto mt-2"></div>
      </div>

      {/* Conditionally render Booking Wizard or Event List */}
      {selectedEvent ? (
        /* Event Booking Panel */
        <div className="bg-white border border-[#EAE2D8] rounded-2xl overflow-hidden shadow-xl max-w-4xl mx-auto">
          
          {/* Header Progress step indicators */}
          <div className="bg-[#FAF7F2] p-4 border-b border-[#EAE2D8] flex justify-between text-xs font-sans text-neutral-500">
            <button 
              onClick={resetBooking} 
              className="text-[#0A1D37] hover:text-[#B8976C] font-semibold flex items-center gap-1"
            >
              <ChevronRight className="h-4 w-4" />
              <span>ביטול וחזרה</span>
            </button>
            <div className="flex gap-4">
              <span className={bookingStep === 'details' ? 'text-[#B8976C] font-semibold' : ''}>1. פרטי האירוע</span>
              <span className={bookingStep === 'seats' ? 'text-[#B8976C] font-semibold' : ''}>2. בחירת מושב בסלון</span>
              <span className={bookingStep === 'ticket' ? 'text-[#B8976C] font-semibold' : ''}>3. כרטיס RSVP מוכן</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 p-6">
            
            {/* Left: Wizard step controller (7 cols) */}
            <div className="md:col-span-8 text-right space-y-6">
              
              {bookingStep === 'details' ? (
                /* STEP 1: Details & Introduction */
                <div className="space-y-4">
                  <span className="px-3 py-1 bg-[#B8976C]/15 text-[#B8976C] text-xs font-sans font-bold rounded-full">פרטי האירוע</span>
                  <h4 className="font-serif font-black text-2xl text-[#0A1D37]">{selectedEvent.title}</h4>
                  <p className="text-neutral-600 text-sm font-sans leading-relaxed">{selectedEvent.description}</p>
                  
                  <div className="bg-[#FAF7F2] p-4 rounded-xl border border-[#EAE2D8] text-xs font-sans text-neutral-600 space-y-3">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-[#B8976C]" />
                      <span><strong>זמן:</strong> {selectedEvent.date} בשעה {selectedEvent.time}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-[#B8976C]" />
                      <span><strong>מיקום:</strong> {selectedEvent.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-[#B8976C]" />
                      <span><strong>כרטיסים פנויים:</strong> {selectedEvent.seatsAvailable} מתוך {selectedEvent.seatsTotal} מושבים</span>
                    </div>
                  </div>

                  <div className="pt-4 flex justify-between items-center">
                    <div>
                      <span className="text-xs text-neutral-400 block font-sans">עלות כרטיס יחיד:</span>
                      <strong className="text-lg font-bold text-[#B8976C] font-mono">{selectedEvent.ticketPrice === 0 ? 'חינם לחברים' : `₪${selectedEvent.ticketPrice}`}</strong>
                    </div>
                    
                    <button
                      onClick={() => setBookingStep('seats')}
                      className="px-6 py-3 bg-[#0A1D37] text-white hover:bg-[#B8976C] font-sans font-bold text-xs rounded-full shadow-md transition-all"
                    >
                      המשך לבחירת מושבים בסלון הספרייה ←
                    </button>
                  </div>
                </div>
              ) : bookingStep === 'seats' ? (
                /* STEP 2: Interactive Seat Grid selection */
                <div className="space-y-5">
                  <div className="text-right">
                    <span className="px-3 py-1 bg-[#B8976C]/15 text-[#B8976C] text-xs font-sans font-bold rounded-full">מפת ישיבה אקוסטית</span>
                    <h4 className="font-serif font-bold text-lg text-[#0A1D37] mt-2">בחרו את מיקום המושב המועדף עליכם בסלון הספרים</h4>
                    <p className="text-xs text-neutral-400 font-sans">לחיצה על מושב פנוי מסמנת אותו עבור הכרטיס שלך.</p>
                  </div>

                  {/* Visual stage marker */}
                  <div className="w-full bg-[#3E2723] text-[#FAF7F2] text-center text-xs py-2 rounded-lg font-serif tracking-widest uppercase shadow">
                    🔊 במת המרצים / קבוצת הדיון 🔊
                  </div>

                  {/* Seat Grid layout */}
                  <div className="flex flex-col items-center gap-2 py-4">
                    {rows.map(row => (
                      <div key={row} className="flex gap-2 items-center">
                        <span className="w-4 text-xs font-bold text-neutral-400 font-sans">{row}</span>
                        {cols.map(col => {
                          const seatId = `${row}${col}`;
                          const isOccupied = occupiedSeats.includes(seatId);
                          const isSelected = selectedSeats.includes(seatId);

                          return (
                            <button
                              key={col}
                              disabled={isOccupied}
                              onClick={() => handleSeatClick(seatId)}
                              className={`h-9 w-9 rounded-lg flex items-center justify-center font-mono text-[10px] font-bold border transition-all ${
                                isOccupied 
                                  ? 'bg-neutral-200 border-neutral-300 text-neutral-400 cursor-not-allowed' 
                                  : isSelected 
                                  ? 'bg-[#B8976C] border-[#B8976C] text-[#FCFAF7] shadow-inner font-extrabold ring-2 ring-[#B8976C]/20' 
                                  : 'bg-[#FAF7F2] border-neutral-200 text-neutral-700 hover:border-[#B8976C]'
                              }`}
                              title={isOccupied ? `מושב ${seatId} תפוס` : `מושב ${seatId} פנוי`}
                            >
                              {col}
                            </button>
                          );
                        })}
                      </div>
                    ))}
                  </div>

                  {/* Legend explanation */}
                  <div className="flex gap-4 justify-center text-[10px] font-sans text-neutral-500">
                    <span className="flex items-center gap-1">
                      <span className="h-3 w-3 bg-[#FAF7F2] border border-neutral-200 rounded"></span> פנוי
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="h-3 w-3 bg-neutral-200 border border-neutral-300 rounded"></span> תפוס
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="h-3 w-3 bg-[#B8976C] rounded"></span> המושב שבחרת
                    </span>
                  </div>

                  {/* RSVP attendee info form */}
                  <form onSubmit={handleBookComplete} className="pt-4 border-t border-neutral-100 space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs text-neutral-500 mb-1">שם מלא למזמין</label>
                        <input
                          type="text"
                          required
                          value={attendeeName}
                          onChange={e => setAttendeeName(e.target.value)}
                          placeholder="ישראל ישראלי"
                          className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] text-xs outline-none focus:border-[#B8976C]"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-neutral-500 mb-1">כתובת דואר אלקטרוני למשלוח כרטיס</label>
                        <input
                          type="email"
                          required
                          value={attendeeEmail}
                          onChange={e => setAttendeeEmail(e.target.value)}
                          className="w-full p-2 border border-[#EAE2D8] rounded bg-[#FAF7F2] text-xs outline-none"
                          disabled
                        />
                      </div>
                    </div>

                    <div className="flex justify-between items-center pt-2">
                      <span className="text-xs font-sans text-neutral-500">
                        מושבים שנבחרו: <strong className="text-[#0A1D37] font-mono">{selectedSeats.join(', ') || 'אף מושב לא נבחר'}</strong>
                      </span>
                      <button
                        type="submit"
                        disabled={selectedSeats.length === 0}
                        className="px-6 py-2.5 bg-[#0A1D37] hover:bg-[#B8976C] text-white text-xs font-sans font-bold rounded-lg transition-colors shadow disabled:bg-neutral-300 disabled:cursor-not-allowed"
                      >
                        הפק כרטיס כניסה RSVP 🎫
                      </button>
                    </div>
                  </form>
                </div>
              ) : (
                /* STEP 3: Printable RSVP Ticket generated pass */
                <div className="space-y-6">
                  <div className="text-center py-4 bg-emerald-50 border border-emerald-100 rounded-xl space-y-1">
                    <CheckCircle className="h-10 w-10 text-emerald-600 mx-auto" />
                    <h5 className="font-serif font-bold text-emerald-900 text-base">ההרשמה לאירוע בוצעה בהצלחה!</h5>
                    <p className="text-xs text-emerald-700 font-sans">אישור השתתפות דיגיטלי וקבלה נשלחו לתיבת האימייל שלך.</p>
                  </div>

                  {/* High-Fidelity Printable Pass layout */}
                  <div className="border-2 border-dashed border-[#B8976C] rounded-2xl bg-[#FCFAF7] overflow-hidden p-6 relative max-w-md mx-auto shadow-md">
                    {/* Ornamental Gold border align */}
                    <div className="absolute inset-2 border border-[#B8976C]/20 rounded-xl pointer-events-none"></div>

                    {/* Left half cut-out circular visual dots */}
                    <div className="absolute -left-3 top-1/2 -translate-y-1/2 h-6 w-6 bg-white border border-[#EAE2D8] rounded-full"></div>
                    <div className="absolute -right-3 top-1/2 -translate-y-1/2 h-6 w-6 bg-white border border-[#EAE2D8] rounded-full"></div>

                    <div className="space-y-4 text-center">
                      <span className="text-xs font-serif font-bold text-[#B8976C] tracking-widest uppercase">כרטיס RSVP - ספר חכמה</span>
                      
                      <div className="border-b border-neutral-100 pb-2">
                        <h4 className="font-serif font-black text-base text-[#0A1D37]">{selectedEvent.title}</h4>
                        <p className="text-[11px] text-neutral-500 font-sans mt-0.5">מרצה/אורח: {selectedEvent.speaker}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-right text-[11px] font-sans text-neutral-600">
                        <p><strong>מזמין:</strong> {attendeeName}</p>
                        <p><strong>שער/מושב:</strong> סלון {selectedSeats.join(', ')}</p>
                        <p><strong>תאריך:</strong> {selectedEvent.date}</p>
                        <p><strong>שעה:</strong> {selectedEvent.time}</p>
                      </div>

                      <div className="bg-white p-3 rounded-lg border border-[#EAE2D8] w-fit mx-auto flex flex-col items-center">
                        <QrCode className="h-24 w-24 text-[#0A1D37]" />
                        <span className="text-[9px] font-mono text-neutral-400 mt-1">CODE: BOOKSHOW-99214-X</span>
                      </div>

                      <p className="text-[9px] text-neutral-400 font-sans">אנא הציגו קוד QR זה בקופת הסניף בכניסה לאירוע.</p>
                    </div>
                  </div>

                  <div className="text-center">
                    <button
                      onClick={resetBooking}
                      className="px-6 py-2 bg-[#0A1D37] text-white hover:bg-[#B8976C] rounded-full text-xs font-sans font-bold"
                    >
                      חזרה לרשימת האירועים
                    </button>
                  </div>
                </div>
              )}

            </div>

            {/* Right: Quick Cover Event Thumbnail (4 cols) */}
            <div className="md:col-span-4 bg-[#FAF7F2] border border-[#EAE2D8] p-4 rounded-xl flex flex-col justify-between">
              <div className="aspect-[4/3] rounded-lg overflow-hidden border border-[#EAE2D8] bg-neutral-200">
                <img 
                  src={selectedEvent.imageUrl} 
                  alt={selectedEvent.title} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="space-y-1.5 pt-3 text-right">
                <span className="text-[10px] text-neutral-400 font-sans">מיקום הסניף המארח:</span>
                <p className="text-xs font-serif font-bold text-[#0A1D37]">{selectedEvent.location}</p>
                <p className="text-[10px] text-neutral-500 font-sans">סגל האירוח יעניק סיוע נגישות וגישה לחניונים מסובסדים.</p>
              </div>
            </div>

          </div>

        </div>
      ) : (
        /* Event timeline list view */
        <div className="space-y-8">
          {events.map((event, index) => {
            const isSoldOut = event.seatsAvailable === 0;
            return (
              <div 
                key={event.id}
                className="bg-white border border-[#EAE2D8] rounded-2xl p-5 flex flex-col lg:flex-row gap-6 hover:shadow-md transition-all duration-300"
              >
                {/* Visual Cover/Media */}
                <div className="lg:w-64 aspect-[16/10] sm:aspect-[16/9] lg:aspect-square rounded-xl overflow-hidden bg-neutral-200 shrink-0 border border-[#EAE2D8]">
                  <img 
                    src={event.imageUrl} 
                    alt={event.title} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Event core info details */}
                <div className="flex-1 flex flex-col justify-between text-right">
                  <div className="space-y-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="px-2.5 py-1 bg-[#FAF7F2] border border-[#EAE2D8] text-xs font-sans text-neutral-500 rounded-lg">
                        {event.date} • יום {new Date(event.date).toLocaleDateString('he-IL', { weekday: 'long' })} בשעה {event.time}
                      </span>
                      {isSoldOut ? (
                        <span className="px-2.5 py-1 bg-neutral-100 text-neutral-500 text-xs font-sans font-bold rounded-lg">
                          אזלו הכרטיסים ⚠️
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 bg-emerald-50 text-emerald-800 text-xs font-sans font-bold rounded-lg border border-emerald-100">
                          {event.seatsAvailable} מושבים פנויים כעת
                        </span>
                      )}
                    </div>

                    <h4 className="font-serif font-black text-xl text-[#0A1D37] hover:text-[#B8976C] transition-colors">{event.title}</h4>
                    <p className="text-xs text-[#B8976C] font-serif flex items-center gap-1.5">
                      <UserCheck className="h-4 w-4" />
                      <span>אורח כבוד: <strong>{event.speaker}</strong></span>
                    </p>

                    <p className="text-neutral-500 text-xs leading-relaxed font-sans line-clamp-3">
                      {event.description}
                    </p>
                  </div>

                  {/* Booking Trigger Footer bar */}
                  <div className="flex flex-wrap justify-between items-center border-t border-neutral-100 pt-4 mt-4 text-xs font-sans text-neutral-400 gap-3">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4 text-[#B8976C]" />
                      <span>{event.location}</span>
                    </div>

                    <div className="flex items-center gap-3">
                      <div>
                        <span className="text-[10px] text-neutral-400 block text-left">כרטיס כניסה</span>
                        <strong className="text-sm font-bold text-[#B8976C] font-mono">{event.ticketPrice === 0 ? 'חינם לחברים' : `₪${event.ticketPrice}`}</strong>
                      </div>
                      
                      <button
                        onClick={() => setSelectedEvent(event)}
                        className={`px-5 py-2 rounded-full font-bold text-xs shadow-sm transition-all ${
                          isSoldOut 
                            ? 'bg-neutral-100 text-neutral-400 cursor-not-allowed border' 
                            : 'bg-[#0A1D37] text-white hover:bg-[#B8976C] cursor-pointer'
                        }`}
                        disabled={isSoldOut}
                      >
                        {isSoldOut ? 'הרשמה סגורה' : 'שמור מקום והפק כרטיס RSVP 🎫'}
                      </button>
                    </div>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
}
