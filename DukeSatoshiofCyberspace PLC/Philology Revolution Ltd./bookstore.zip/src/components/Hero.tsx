import React from 'react';
import { Sparkles, Compass, BookOpen, Star, ArrowLeft } from 'lucide-react';

interface HeroProps {
  onBrowseBooks: () => void;
  onFilterRare: () => void;
  onJoinCommunity: () => void;
}

export default function Hero({ onBrowseBooks, onFilterRare, onJoinCommunity }: HeroProps) {
  return (
    <section className="relative bg-[#FAF7F2] py-12 md:py-20 border-b border-[#EAE2D8] overflow-hidden" dir="rtl">
      {/* Background Ornaments */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#F5EFEB]/40 rounded-full blur-3xl -z-10"></div>
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#B8976C]/10 rounded-full blur-2xl -z-10"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-12 items-center">
          
          {/* Main Cinematic Text Card (Jerusalem Stone Frame) */}
          <div className="lg:col-span-7 space-y-6 text-right order-2 lg:order-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#0A1D37]/5 rounded-full text-xs font-sans text-[#0A1D37] font-semibold">
              <Sparkles className="h-3.5 w-3.5 text-[#B8976C]" />
              <span>חוויית למדנות וקריאה עילאית</span>
            </div>
            
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-black text-[#0A1D37] leading-tight tracking-wide">
              מקום של ספרים. <br />
              <span className="text-[#B8976C]">מקום של מחשבה.</span>
            </h2>

            <p className="text-neutral-600 text-base md:text-lg leading-relaxed max-w-2xl font-sans">
              גלו את קולקציית הספרים המובילה של ספרות עברית משובחת, הגות יהודית, תורה ומפרשים, שירה קלאסית, פילוסופיה עמוקה, ומהדורות אספנות חתומות בכריכות עור בעבודת יד. בית דיגיטלי למסורת מודרנית.
            </p>

            {/* Micro gold divider ornament */}
            <div className="flex items-center gap-2 py-2">
              <span className="h-px w-10 bg-[#B8976C]"></span>
              <span className="text-[#B8976C] text-sm font-serif">✦ ✦ ✦</span>
              <span className="h-px w-10 bg-[#B8976C]"></span>
            </div>

            {/* Call to Actions */}
            <div className="flex flex-wrap gap-3 pt-2">
              <button
                onClick={onBrowseBooks}
                className="px-6 py-3.5 bg-[#0A1D37] text-[#FAF7F2] font-sans font-semibold rounded-full hover:bg-[#B8976C] hover:shadow-md transition-all duration-300 flex items-center gap-2 cursor-pointer text-sm"
              >
                <Compass className="h-4.5 w-4.5" />
                <span>דפדוף בקטלוג</span>
              </button>
              
              <button
                onClick={onFilterRare}
                className="px-6 py-3.5 bg-white text-[#0A1D37] border border-[#EAE2D8] font-sans font-semibold rounded-full hover:bg-[#FAF7F2] transition-all duration-300 flex items-center gap-2 cursor-pointer text-sm shadow-sm"
              >
                <Star className="h-4.5 w-4.5 text-[#B8976C] fill-[#B8976C]/10" />
                <span>מהדורות נדירות</span>
              </button>

              <button
                onClick={onJoinCommunity}
                className="px-6 py-3.5 bg-transparent text-[#0A1D37] hover:text-[#B8976C] font-sans font-medium hover:underline transition-all duration-300 flex items-center gap-1.5 cursor-pointer text-sm"
              >
                <span>הצטרפות לקהילה</span>
                <ArrowLeft className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Large Scenic Bookstore Frame (RHS on Desktop) */}
          <div className="lg:col-span-5 order-1 lg:order-2">
            <div className="relative group max-w-md mx-auto">
              {/* Outer Elegant border frame mirroring Jerusalem stone library */}
              <div className="absolute -inset-2.5 rounded-2xl border-2 border-dashed border-[#B8976C]/30 -z-10 group-hover:scale-102 transition-transform duration-500"></div>
              
              {/* Main Image Container */}
              <div className="relative aspect-[4/3] sm:aspect-square overflow-hidden rounded-xl shadow-2xl border-4 border-white bg-neutral-200">
                <img 
                  src="https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=800" 
                  alt="ספריית ספר חכמה" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-95"
                  referrerPolicy="no-referrer"
                />
                
                {/* Floating Aesthetic Overlay Banner */}
                <div className="absolute bottom-4 right-4 left-4 bg-[#FCFAF7]/95 backdrop-blur-sm p-4 rounded-lg border border-[#EAE2D8] text-right shadow-lg">
                  <h4 className="font-serif font-bold text-sm text-[#0A1D37]">״לקרוא זה לאוורר את הנשמה״</h4>
                  <p className="text-xs text-[#B8976C] font-sans mt-0.5">ספר חכמה, סניף ירושלים ההיסטורית</p>
                </div>
              </div>

              {/* Little Floating Badge */}
              <div className="absolute -top-3 -left-3 bg-[#3E2723] text-[#FAF7F2] text-[10px] font-sans px-3 py-1.5 rounded-full shadow-lg font-bold tracking-wider border border-[#B8976C]/20 flex items-center gap-1.5 animate-pulse">
                <BookOpen className="h-3 w-3 text-[#B8976C]" />
                <span>100% ספרות מקור ומסורת</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
