import React, { useState } from 'react';
import { 
  User, 
  ShoppingBag, 
  Heart, 
  MapPin, 
  CreditCard, 
  Bell, 
  Bookmark, 
  Award, 
  Sparkles, 
  Clock, 
  BookOpen, 
  Quote,
  CheckCircle,
  Truck
} from 'lucide-react';
import { Book, UserProfile, Order } from '../types';

interface AccountProps {
  userProfile: UserProfile;
  books: Book[];
  onSelectBook: (book: Book) => void;
  onRemoveFromWishlist: (bookId: string) => void;
}

export default function Account({
  userProfile,
  books,
  onSelectBook,
  onRemoveFromWishlist
}: AccountProps) {
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'orders' | 'wishlist' | 'settings'>('profile');

  // Load wishlist books
  const wishlistBooks = books.filter(b => userProfile.wishlist.includes(b.id));

  // Mock order history
  const orders: Order[] = [
    {
      id: 'SC-98214',
      date: '2026-07-28',
      items: [
        {
          book: books.find(b => b.id === '1') || books[0],
          quantity: 1,
          format: 'print'
        }
      ],
      total: 189,
      status: 'shipped',
      trackingNumber: 'IL-POST-9928124'
    },
    {
      id: 'SC-88124',
      date: '2026-05-15',
      items: [
        {
          book: books.find(b => b.id === '6') || books[2],
          quantity: 1,
          format: 'ebook'
        }
      ],
      total: 57,
      status: 'delivered'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" dir="rtl">
      
      {/* Introduction */}
      <div className="text-center mb-10 max-w-2xl mx-auto space-y-3">
        <h3 className="text-3xl font-serif font-black text-[#0A1D37]">האזור האישי שלי</h3>
        <p className="text-[#B8976C] text-xs font-sans uppercase tracking-widest">מעקב משלוחים, ספרים שמורים ופרופיל קורא מותאם אישית</p>
        <div className="h-0.5 w-12 bg-[#B8976C] mx-auto mt-2"></div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Quick Sub-Navigation (4 cols) */}
        <div className="lg:col-span-4 bg-white border border-[#EAE2D8] rounded-2xl p-5 space-y-4 shadow-sm">
          <div className="flex items-center gap-3 pb-4 border-b border-neutral-100">
            <div className="h-12 w-12 rounded-full bg-[#0A1D37] text-[#FAF7F2] flex items-center justify-center font-bold text-lg">
              {userProfile.name[0]}
            </div>
            <div className="text-right">
              <h4 className="font-serif font-bold text-sm text-[#0A1D37]">{userProfile.name}</h4>
              <p className="text-[10px] text-neutral-400 font-sans">{userProfile.email}</p>
            </div>
          </div>

          <div className="flex flex-col gap-1.5 text-xs font-sans text-neutral-600">
            {[
              { id: 'profile', label: 'פרופיל למדן וסטטיסטיקה', icon: User },
              { id: 'orders', label: 'היסטוריית הזמנות ומשלוחים', icon: ShoppingBag },
              { id: 'wishlist', label: 'ספרים שמורים ומשאלות', icon: Heart },
              { id: 'settings', label: 'כתובות והגדרות חשבון', icon: MapPin }
            ].map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveSubTab(tab.id as any)}
                  className={`w-full text-right p-3 rounded-xl flex items-center justify-between transition-all ${
                    activeSubTab === tab.id 
                      ? 'bg-[#FAF7F2] border border-[#EAE2D8] text-[#B8976C] font-semibold' 
                      : 'hover:bg-neutral-50 border border-transparent'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <Icon className="h-4.5 w-4.5" />
                    <span>{tab.label}</span>
                  </span>
                </button>
              );
            })}
          </div>

          {/* Member badge promotion */}
          {userProfile.isMember ? (
            <div className="bg-[#0A1D37] text-white p-4 rounded-xl text-center space-y-2 border border-[#B8976C]/40">
              <div className="flex justify-center text-[#B8976C]">
                <Award className="h-5 w-5 fill-current" />
              </div>
              <p className="text-xs font-serif font-bold">חבר קהילת חכמה פעיל</p>
              <span className="text-[9px] text-neutral-300 font-sans block">זכאי ל-10% הנחה בכל קנייה</span>
            </div>
          ) : (
            <div className="bg-[#FAF7F2] border border-dashed border-[#EAE2D8] p-4 rounded-xl text-center space-y-1">
              <span className="text-xs font-serif font-bold text-[#0A1D37] block">טרם הצטרפת לקהילה?</span>
              <p className="text-[10px] text-neutral-500 font-sans leading-relaxed">הירשמו עכשיו וקבלו גישה להרצאות אקדמיות והנחות חברים.</p>
            </div>
          )}
        </div>

        {/* Right Column: Sub-Tab display boards (8 cols) */}
        <div className="lg:col-span-8 bg-white border border-[#EAE2D8] rounded-2xl p-6 shadow-sm min-h-[400px]">
          
          {activeSubTab === 'profile' ? (
            /* Tab 1: Reader profile and statistics */
            <div className="space-y-6 text-right">
              <h4 className="font-serif font-bold text-base text-[#0A1D37] border-b pb-2 mb-4">פרופיל הלמדן שלי</h4>

              {/* Stat dashboard */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-[#FAF7F2] p-4 rounded-xl border border-[#EAE2D8]">
                  <span className="text-neutral-400 text-[10px] font-sans block">ספרים שקראת השנה</span>
                  <strong className="text-2xl font-bold text-[#0A1D37] font-sans">14 כרכים</strong>
                </div>
                <div className="bg-[#FAF7F2] p-4 rounded-xl border border-[#EAE2D8]">
                  <span className="text-neutral-400 text-[10px] font-sans block">שעות שמע שהקשבת</span>
                  <strong className="text-2xl font-bold text-[#0A1D37] font-sans">22.5 שעות</strong>
                </div>
                <div className="bg-[#FAF7F2] p-4 rounded-xl border border-[#EAE2D8]">
                  <span className="text-neutral-400 text-[10px] font-sans block">ציון קהילה צבור</span>
                  <strong className="text-2xl font-bold text-[#B8976C] font-mono">480 נקודות</strong>
                </div>
              </div>

              {/* Saved quotes list */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center gap-1.5 font-serif font-bold text-sm text-[#0A1D37]">
                  <Quote className="h-4.5 w-4.5 text-[#B8976C]" />
                  <span>אמרה שבועית שנשמרה בפרופיל</span>
                </div>
                
                <div className="p-4 bg-[#FAF7F2] border border-[#EAE2D8] rounded-xl relative overflow-hidden">
                  <span className="absolute -top-6 -right-6 text-[#B8976C]/10 text-7xl font-serif">”</span>
                  <p className="text-xs font-serif text-neutral-600 leading-relaxed italic pr-6">
                    ״כל זמן שהאדם עוסק במחשבה טהורה, הריהו נוגע בנצח, ואין ספר כחוט המקשר בינו לבין שרשרת הדורות.״
                  </p>
                  <span className="block text-[10px] text-[#0A1D37] font-bold mt-2 text-left font-sans">- רב חסדא, ספר מחשבות הלב</span>
                </div>
              </div>

              {/* Saved Quotes section details */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center gap-1.5 font-serif font-bold text-sm text-[#0A1D37]">
                  <Bookmark className="h-4.5 w-4.5 text-[#B8976C]" />
                  <span>קריאה פעילה כעת</span>
                </div>
                <div className="p-4 bg-[#FAF7F2] border border-[#EAE2D8] rounded-xl flex items-center justify-between text-xs font-sans">
                  <div>
                    <strong className="text-[#0A1D37] font-serif block text-sm">מורה נבוכים - מהדורת מופת</strong>
                    <span className="text-neutral-400 font-sans text-[11px] block mt-0.5">סיימת 35% מהספר</span>
                  </div>
                  <span className="px-3 py-1.5 bg-white border rounded font-semibold text-[#B8976C]">המשך לקרוא ←</span>
                </div>
              </div>

            </div>
          ) : activeSubTab === 'orders' ? (
            /* Tab 2: Order history & Shipment tracker */
            <div className="space-y-6 text-right">
              <h4 className="font-serif font-bold text-base text-[#0A1D37] border-b pb-2">היסטוריית הזמנות ומשלוחים</h4>

              <div className="space-y-6 divide-y divide-neutral-100">
                {orders.map((order, idx) => (
                  <div key={order.id} className={`pt-4 first:pt-0 space-y-4 text-xs font-sans text-neutral-600`}>
                    
                    {/* Header info */}
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-neutral-50 pb-2">
                      <div>
                        <strong className="text-[#0A1D37] font-sans">מספר הזמנה: {order.id}</strong>
                        <span className="text-neutral-400 font-sans block mt-0.5">תאריך רכישה: {order.date}</span>
                      </div>
                      
                      <div className="self-end sm:self-auto">
                        <span className={`px-2.5 py-1 rounded text-[10px] font-bold ${
                          order.status === 'shipped' ? 'bg-amber-50 text-amber-800 border border-amber-100' : 'bg-emerald-50 text-emerald-800 border border-emerald-100'
                        }`}>
                          {order.status === 'shipped' ? 'בדרך אליך במשאית משלוחים 🚚' : 'נמסר בהצלחה ליעד ✓'}
                        </span>
                      </div>
                    </div>

                    {/* Order items lists */}
                    <div className="space-y-2">
                      {order.items.map((item, itemIdx) => (
                        <div key={itemIdx} className="flex gap-3 items-center">
                          <div className="h-12 w-8 bg-neutral-100 rounded border overflow-hidden shrink-0">
                            <img src={item.book.coverUrl} alt={item.book.title} className="w-full h-full object-cover" />
                          </div>
                          <div>
                            <strong className="text-[#0A1D37] font-serif">{item.book.title}</strong>
                            <p className="text-[10px] text-neutral-400">כמות: {item.quantity} • פורמט: {item.format === 'print' ? 'מודפס' : 'דיגיטלי'}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Shipping tracker indicator if shipped */}
                    {order.status === 'shipped' && (
                      <div className="bg-[#FAF7F2] p-4 rounded-xl border border-[#EAE2D8] space-y-2.5">
                        <div className="flex items-center gap-1.5 text-xs font-serif font-bold text-[#0A1D37]">
                          <Truck className="h-4.5 w-4.5 text-[#B8976C]" />
                          <span>מעקב משלוח פנימי - דואר ישראל</span>
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-neutral-400 font-sans relative pb-2 pt-1">
                          <span className="font-semibold text-emerald-600">התקבל במחסן</span>
                          <span className="font-semibold text-emerald-600">יצא למשלוח</span>
                          <span className="font-semibold">נמסר ליעד</span>
                          <div className="absolute bottom-0 right-0 left-0 h-1 bg-neutral-200 rounded">
                            <div className="h-full bg-emerald-500 rounded" style={{ width: '65%' }}></div>
                          </div>
                        </div>
                        <p className="text-[10px] text-neutral-500 font-sans">
                          מספר מעקב: <strong className="font-mono">{order.trackingNumber}</strong> • זמן הגעה משוער: 2 ימי עסקים.
                        </p>
                      </div>
                    )}

                    <div className="text-left font-sans font-bold text-sm text-[#0A1D37]">
                      סה״כ לתשלום: ₪{order.total}
                    </div>

                  </div>
                ))}
              </div>

            </div>
          ) : activeSubTab === 'wishlist' ? (
            /* Tab 3: Wishlist items */
            <div className="space-y-6 text-right">
              <h4 className="font-serif font-bold text-base text-[#0A1D37] border-b pb-2">הספרים ששמרת לקריאה</h4>

              {wishlistBooks.length === 0 ? (
                <div className="p-12 border-2 border-dashed border-[#EAE2D8] rounded-xl text-center space-y-2 text-neutral-400">
                  <Heart className="h-10 w-10 text-[#B8976C]/30 mx-auto" />
                  <p className="text-sm font-semibold text-[#0A1D37]">אין ספרים ברשימת המשאלות</p>
                  <p className="text-xs font-sans">לחצו על הלב בקטלוג לשמירת כותרים לקנייה עתידית.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {wishlistBooks.map(book => (
                    <div key={book.id} className="bg-[#FAF7F2] border border-[#EAE2D8] p-4 rounded-xl flex gap-3 text-xs font-sans justify-between hover:shadow-sm">
                      <div className="flex gap-3">
                        <div className="h-16 w-11 bg-neutral-100 rounded border overflow-hidden shrink-0">
                          <img src={book.coverUrl} alt={book.title} className="w-full h-full object-cover" />
                        </div>
                        <div className="text-right flex flex-col justify-between">
                          <div>
                            <strong className="text-[#0A1D37] font-serif block text-xs line-clamp-1">{book.title}</strong>
                            <span className="text-[10px] text-neutral-400 font-sans">{book.author}</span>
                          </div>
                          <strong className="text-[#B8976C] font-mono block">₪{book.price}</strong>
                        </div>
                      </div>

                      <div className="flex flex-col gap-1.5 justify-center">
                        <button
                          onClick={() => onSelectBook(book)}
                          className="px-3 py-1 bg-[#0A1D37] text-white rounded hover:bg-[#B8976C] transition-colors"
                        >
                          עיון
                        </button>
                        <button
                          onClick={() => onRemoveFromWishlist(book.id)}
                          className="text-neutral-400 hover:text-red-500 font-sans"
                        >
                          הסר
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

            </div>
          ) : (
            /* Tab 4: Account settings and addresses */
            <div className="space-y-6 text-right text-xs font-sans text-neutral-600">
              <h4 className="font-serif font-bold text-base text-[#0A1D37] border-b pb-2">כתובות והגדרות אבטחה</h4>

              <div className="bg-[#FAF7F2] p-4 rounded-xl border border-[#EAE2D8] space-y-3">
                <span className="text-xs font-serif font-bold text-[#0A1D37] block">כתובת ברירת מחדל למשלוחים</span>
                <div className="space-y-1">
                  <p className="font-bold text-[#0A1D37]">שדרות רוטשילד 15, תל אביב</p>
                  <p className="text-neutral-500">מיקוד: 6512104 • טלפון: 054-1234567</p>
                </div>
                <button className="px-3 py-1 bg-white border border-[#EAE2D8] rounded hover:bg-[#F5EFEB] font-semibold text-[#0A1D37] mt-1.5">
                  ערוך כתובת משלוח
                </button>
              </div>

              <div className="bg-[#FAF7F2] p-4 rounded-xl border border-[#EAE2D8] space-y-3">
                <span className="text-xs font-serif font-bold text-[#0A1D37] block">אמצעי תשלום שמור</span>
                <div className="flex items-center gap-2 font-mono">
                  <CreditCard className="h-5 w-5 text-[#B8976C]" />
                  <span>Visa המסתיים בספרות •••• 9012</span>
                </div>
                <button className="px-3 py-1 bg-white border border-[#EAE2D8] rounded hover:bg-[#F5EFEB] font-semibold text-[#0A1D37] mt-1.5">
                  הוסף כרטיס אשראי מאובטח
                </button>
              </div>

              <div className="space-y-2">
                <span className="text-xs font-serif font-bold text-[#0A1D37] block">התראות דואר אלקטרוני</span>
                <div className="space-y-2 pt-1">
                  <div className="flex items-center gap-2">
                    <input type="checkbox" defaultChecked className="accent-[#B8976C]" id="notif1" />
                    <label htmlFor="notif1" className="cursor-pointer">שלח לי עדכונים על השקות ספרים ומפגשי סופרים בסניף הקרוב אלי</label>
                  </div>
                  <div className="flex items-center gap-2">
                    <input type="checkbox" defaultChecked className="accent-[#B8976C]" id="notif2" />
                    <label htmlFor="notif2" className="cursor-pointer">שלח לי המלצות קריאה ומאמרי מחקר חודשיים של קהילת חכמה</label>
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>

      </div>

    </div>
  );
}
