import React, { useState, useEffect } from 'react';
import { 
  INITIAL_BOOKS, 
  INITIAL_CATEGORIES, 
  INITIAL_EVENTS, 
  INITIAL_LOCATIONS 
} from './data';
import { Book, CartItem, UserProfile, Event, Review } from './types';
import Header from './components/Header';
import Hero from './components/Hero';
import BookCatalog from './components/BookCatalog';
import ProductPage from './components/ProductPage';
import DigitalLibrary from './components/DigitalLibrary';
import Membership from './components/Membership';
import EventsList from './components/EventsList';
import StoreLocator from './components/StoreLocator';
import CMS from './components/CMS';
import TechnicalDoc from './components/TechnicalDoc';
import { 
  Sparkles, 
  CheckCircle, 
  Heart, 
  ShoppingBag, 
  Info, 
  X, 
  Globe, 
  Mail, 
  Calendar, 
  BookOpen, 
  MapPin,
  Lock
} from 'lucide-react';

export default function App() {
  // Global persistent lists
  const [books, setBooks] = useState<Book[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  
  // Navigation & search state
  const [activeView, setActiveView] = useState<string>('home');
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Cart & wishlist & user states
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile>({
    name: 'תום ישראלי',
    email: 'tom@ahyx.org',
    isMember: false,
    wishlist: [],
    readingProgress: { '1': 35 }, // initial 35% on Mora Nebuchim
    savedQuotes: [
      { 
        text: '״כל זמן שהאדם עוסק במחשבה טהורה, הריהו נוגע בנצח...״', 
        source: 'רב חסדא, ספר מחשבות הלב' 
      }
    ],
    downloadedEbooks: ['1']
  });

  // Newsletter signup state
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterStatus, setNewsletterStatus] = useState<'idle' | 'success'>('idle');

  // Custom Toast notifications state
  const [toasts, setToasts] = useState<{ id: string; message: string; type: 'success' | 'info' | 'error' }[]>([]);

  // Initialize from LocalStorage or Data files
  useEffect(() => {
    const savedBooks = localStorage.getItem('SC_BOOKS_V1');
    if (savedBooks) {
      setBooks(JSON.parse(savedBooks));
    } else {
      setBooks(INITIAL_BOOKS);
      localStorage.setItem('SC_BOOKS_V1', JSON.stringify(INITIAL_BOOKS));
    }

    const savedEvents = localStorage.getItem('SC_EVENTS_V1');
    if (savedEvents) {
      setEvents(JSON.parse(savedEvents));
    } else {
      setEvents(INITIAL_EVENTS);
      localStorage.setItem('SC_EVENTS_V1', JSON.stringify(INITIAL_EVENTS));
    }

    const savedCart = localStorage.getItem('SC_CART_V1');
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }

    const savedWishlist = localStorage.getItem('SC_WISHLIST_V1');
    if (savedWishlist) {
      setWishlist(JSON.parse(savedWishlist));
    }

    const savedProfile = localStorage.getItem('SC_PROFILE_V1');
    if (savedProfile) {
      setUserProfile(JSON.parse(savedProfile));
    }
  }, []);

  // Save changes helper functions
  const saveBooks = (updatedBooks: Book[]) => {
    setBooks(updatedBooks);
    localStorage.setItem('SC_BOOKS_V1', JSON.stringify(updatedBooks));
  };

  const saveEvents = (updatedEvents: Event[]) => {
    setEvents(updatedEvents);
    localStorage.setItem('SC_EVENTS_V1', JSON.stringify(updatedEvents));
  };

  const saveCart = (updatedCart: CartItem[]) => {
    setCart(updatedCart);
    localStorage.setItem('SC_CART_V1', JSON.stringify(updatedCart));
  };

  const saveWishlist = (updatedWishlist: string[]) => {
    setWishlist(updatedWishlist);
    localStorage.setItem('SC_WISHLIST_V1', JSON.stringify(updatedWishlist));
    
    // sync inside user profile
    const updatedProfile = { ...userProfile, wishlist: updatedWishlist };
    setUserProfile(updatedProfile);
    localStorage.setItem('SC_PROFILE_V1', JSON.stringify(updatedProfile));
  };

  const saveProfile = (updatedProfile: UserProfile) => {
    setUserProfile(updatedProfile);
    localStorage.setItem('SC_PROFILE_V1', JSON.stringify(updatedProfile));
  };

  // Toast notifier
  const addToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3000);
  };

  // E-Commerce action triggers
  const addToCart = (book: Book, format: 'print' | 'ebook' | 'audiobook') => {
    // Check inventory if printed
    if (format === 'print' && book.inventory <= 0) {
      addToast(`מצטערים, המהדורה המודפסת של "${book.title}" אזלה זמנית מהמלאי.`, 'error');
      return;
    }

    const existingIndex = cart.findIndex(item => item.book.id === book.id && item.format === format);
    let newCart = [...cart];
    
    if (existingIndex > -1) {
      newCart[existingIndex].quantity += 1;
    } else {
      newCart.push({ book, quantity: 1, format });
    }

    saveCart(newCart);
    addToast(`הספר "${book.title}" התווסף בהצלחה לסל הקניות!`, 'success');
  };

  const removeFromCart = (index: number) => {
    let newCart = [...cart];
    const removedItem = newCart[index];
    newCart.splice(index, 1);
    saveCart(newCart);
    addToast(`הספר "${removedItem.book.title}" הוסר מסל הקניות.`, 'info');
  };

  const updateCartItemQty = (index: number, newQty: number) => {
    if (newQty <= 0) {
      removeFromCart(index);
      return;
    }
    let newCart = [...cart];
    newCart[index].quantity = newQty;
    saveCart(newCart);
  };

  const updateCartItemFormat = (index: number, format: 'print' | 'ebook' | 'audiobook') => {
    let newCart = [...cart];
    newCart[index].format = format;
    saveCart(newCart);
    addToast(`פורמט הספר שונה בהצלחה.`, 'success');
  };

  const clearCart = () => {
    saveCart([]);
  };

  // Wishlist triggers
  const toggleWishlist = (bookId: string) => {
    let newWishlist = [...wishlist];
    const index = newWishlist.indexOf(bookId);
    const bookTitle = books.find(b => b.id === bookId)?.title || 'הספר';

    if (index > -1) {
      newWishlist.splice(index, 1);
      addToast(`"${bookTitle}" הוסר מרשימת המשאלות.`, 'info');
    } else {
      newWishlist.push(bookId);
      addToast(`"${bookTitle}" נשמר בהצלחה ברשימת המשאלות! 🤍`, 'success');
    }
    saveWishlist(newWishlist);
  };

  // Reading progress trackers
  const updateReadingProgress = (bookId: string, percentage: number) => {
    const updatedProgress = { ...userProfile.readingProgress, [bookId]: percentage };
    const updatedProfile = { ...userProfile, readingProgress: updatedProgress };
    saveProfile(updatedProfile);
  };

  // Membership upgrade
  const joinMembership = () => {
    const updatedProfile: UserProfile = {
      ...userProfile,
      isMember: true,
      membershipSince: new Date().toLocaleDateString('he-IL', { year: 'numeric', month: 'long' })
    };
    saveProfile(updatedProfile);
    addToast('ברוכים הבאים לקהילת ספר חכמה! ✦ זכית בגישה מלאה להרצאות ו-10% הנחה.', 'success');
  };

  // Submit product reviews
  const submitReview = (bookId: string, user: string, rating: number, comment: string) => {
    const updatedBooks = books.map(book => {
      if (book.id === bookId) {
        const newReviewObj: Review = {
          id: Date.now().toString(),
          user,
          rating,
          comment,
          date: new Date().toLocaleDateString('he-IL')
        };
        const updatedReviews = [...(book.reviews || []), newReviewObj];
        // Recalculate average rating
        const totalRatingSum = updatedReviews.reduce((sum, r) => sum + r.rating, 0);
        const avgRating = Number((totalRatingSum / updatedReviews.length).toFixed(1));

        return {
          ...book,
          reviews: updatedReviews,
          reviewsCount: updatedReviews.length,
          rating: avgRating
        };
      }
      return book;
    });

    saveBooks(updatedBooks);
    addToast('תודה! הביקורת שלך פורסמה בהצלחה.', 'success');
  };

  // Headless CMS callbacks
  const handleAddBook = (newBook: Book) => {
    const updatedBooks = [...books, newBook];
    saveBooks(updatedBooks);
  };

  const handleUpdateInventory = (bookId: string, newQty: number) => {
    const updatedBooks = books.map(b => b.id === bookId ? { ...b, inventory: newQty } : b);
    saveBooks(updatedBooks);
  };

  const handleAddEvent = (newEvent: Event) => {
    const updatedEvents = [...events, newEvent];
    saveEvents(updatedEvents);
  };

  const handleDeleteBook = (bookId: string) => {
    const updatedBooks = books.filter(b => b.id !== bookId);
    saveBooks(updatedBooks);
    addToast('הספר נמחק לצמיתות מהקטלוג.', 'info');
  };

  // Newsletter subscription simulator
  const handleNewsletterSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setNewsletterStatus('success');
    setNewsletterEmail('');
    setTimeout(() => setNewsletterStatus('idle'), 5000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FCFAF7] selection:bg-[#B8976C] selection:text-white" dir="rtl">
      
      {/* Global Toast Alert container */}
      <div className="fixed top-4 left-4 z-50 space-y-2 pointer-events-none w-full max-w-sm">
        {toasts.map(toast => (
          <div
            key={toast.id}
            className={`p-4 rounded-xl shadow-lg border text-right pointer-events-auto flex items-start gap-2.5 bg-white transition-all duration-300 transform translate-x-0 ${
              toast.type === 'success' ? 'border-emerald-200 text-emerald-900 bg-emerald-50/95' :
              toast.type === 'error' ? 'border-red-200 text-red-900 bg-red-50/95' :
              'border-neutral-200 text-neutral-800 bg-neutral-50/95'
            }`}
          >
            <CheckCircle className={`h-5 w-5 shrink-0 ${toast.type === 'success' ? 'text-emerald-600' : toast.type === 'error' ? 'text-red-500' : 'text-[#B8976C]'}`} />
            <div className="flex-1 text-xs font-sans font-medium">
              {toast.message}
            </div>
            <button 
              onClick={() => setToasts(prev => prev.filter(t => t.id !== toast.id))}
              className="text-neutral-400 hover:text-neutral-600"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>

      {/* Main Header */}
      <Header
        activeView={activeView}
        setActiveView={(view) => {
          setActiveView(view);
          setSelectedBook(null); // Reset detail page view when changing tabs
        }}
        cart={cart}
        removeFromCart={removeFromCart}
        updateCartItemQty={updateCartItemQty}
        updateCartItemFormat={updateCartItemFormat}
        clearCart={clearCart}
        setSearchQuery={setSearchQuery}
        searchQuery={searchQuery}
        books={books}
        onSelectBook={(book) => {
          setSelectedBook(book);
          setActiveView('catalog'); // redirect to catalog nested detail
        }}
      />

      {/* Core Body Container - Router Engine */}
      <main className="flex-1">
        
        {selectedBook ? (
          /* Book Product Detail sub-screen */
          <ProductPage
            book={selectedBook}
            onBack={() => setSelectedBook(null)}
            addToCart={addToCart}
            addToWishlist={toggleWishlist}
            wishlist={wishlist}
            allBooks={books}
            onSelectBook={(b) => setSelectedBook(b)}
            onSubmitReview={submitReview}
          />
        ) : (
          /* Main Nav Router */
          <>
            {activeView === 'home' && (
              <>
                <Hero
                  onBrowseBooks={() => {
                    setSelectedCategory('all');
                    setActiveView('catalog');
                  }}
                  onFilterRare={() => {
                    setSelectedCategory('all');
                    setActiveView('catalog');
                    addToast('מוין אוטומטית לפי מהדורות נדירות ואספניות בלבד!', 'info');
                  }}
                  onJoinCommunity={() => {
                    setActiveView('membership');
                  }}
                />
                
                {/* Catalog View Embedded for premium single-page landing speed */}
                <BookCatalog
                  books={books}
                  categories={INITIAL_CATEGORIES}
                  selectedCategory={selectedCategory}
                  setSelectedCategory={setSelectedCategory}
                  onSelectBook={(b) => setSelectedBook(b)}
                  addToCart={addToCart}
                  addToWishlist={toggleWishlist}
                  wishlist={wishlist}
                />
              </>
            )}

            {activeView === 'catalog' && (
              <BookCatalog
                books={books}
                categories={INITIAL_CATEGORIES}
                selectedCategory={selectedCategory}
                setSelectedCategory={setSelectedCategory}
                onSelectBook={(b) => setSelectedBook(b)}
                addToCart={addToCart}
                addToWishlist={toggleWishlist}
                wishlist={wishlist}
              />
            )}

            {activeView === 'library' && (
              <DigitalLibrary
                books={books}
                userProfile={userProfile}
                onUpdateReadingProgress={updateReadingProgress}
                onBackToHome={() => setActiveView('home')}
              />
            )}

            {activeView === 'membership' && (
              <Membership
                userProfile={userProfile}
                onJoinMembership={joinMembership}
                books={books}
                onSelectBook={(b) => setSelectedBook(b)}
              />
            )}

            {activeView === 'events' && (
              <EventsList
                events={events}
                onBackToHome={() => setActiveView('home')}
              />
            )}

            {activeView === 'locator' && (
              <StoreLocator
                locations={INITIAL_LOCATIONS}
                onBackToHome={() => setActiveView('home')}
              />
            )}

            {activeView === 'cms' && (
              <CMS
                books={books}
                categories={INITIAL_CATEGORIES}
                events={events}
                onAddBook={handleAddBook}
                onUpdateInventory={handleUpdateInventory}
                onAddEvent={handleAddEvent}
                onDeleteBook={handleDeleteBook}
              />
            )}

            {activeView === 'tech' && (
              <TechnicalDoc
                onBackToHome={() => setActiveView('home')}
              />
            )}
          </>
        )}

      </main>

      {/* Main Footer (Pristine light-cream grid, RTL aligned) */}
      <footer className="bg-[#FAF7F2] border-t border-[#EAE2D8] text-right font-sans" id="main-footer">
        
        {/* Upper Footer section */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Col 1: Brand descriptor */}
          <div className="space-y-4">
            <h4 className="font-serif font-black text-[#0A1D37] text-lg">ספר חכמה</h4>
            <p className="text-[#B8976C] text-xs font-serif italic">ספרים. מחשבה. מסורת.</p>
            <p className="text-neutral-500 text-xs leading-relaxed max-w-sm">
              בית דיגיטלי וסלוני למדנות פיזיים המוקדשים כולם לשימור ולקידום הספרות העברית, מחשבת ישראל, שירת תור הזהב ויצירות מופת של הוצאה עצמית משובחת.
            </p>
          </div>

          {/* Col 2: Navigation Links */}
          <div className="space-y-3">
            <h5 className="font-serif font-bold text-xs text-[#0A1D37] uppercase tracking-wider">ניווט מהיר</h5>
            <ul className="text-xs text-neutral-500 space-y-2">
              <li><button onClick={() => { setActiveView('catalog'); setSelectedBook(null); }} className="hover:text-[#B8976C] transition-colors">קטלוג הספרים המלא</button></li>
              <li><button onClick={() => setActiveView('library')} className="hover:text-[#B8976C] transition-colors">הספרייה הדיגיטלית</button></li>
              <li><button onClick={() => setActiveView('membership')} className="hover:text-[#B8976C] transition-colors">קהילת ספר חכמה</button></li>
              <li><button onClick={() => setActiveView('events')} className="hover:text-[#B8976C] transition-colors">אירועי תרבות וסדנאות</button></li>
              <li><button onClick={() => setActiveView('locator')} className="hover:text-[#B8976C] transition-colors">סניפים שעות פעילות</button></li>
            </ul>
          </div>

          {/* Col 3: Traditional warning details */}
          <div className="space-y-3">
            <h5 className="font-serif font-bold text-xs text-[#0A1D37] uppercase tracking-wider">שירות לקוחות</h5>
            <div className="text-xs text-neutral-500 space-y-1.5 leading-relaxed">
              <p>שעות מענה טלפוני: א׳-ה׳ 09:00 - 18:00</p>
              <p>אימייל לתמיכה: <strong className="font-sans">support@chokhmah.co.il</strong></p>
              <p className="text-[11px] text-[#B8976C] font-serif font-semibold mt-2">
                * כל סניפי הרשת והמשלוחים מושבתים בשבתות וחגי ישראל.
              </p>
            </div>
          </div>

          {/* Col 4: Interactive newsletter signup (with simulated success) */}
          <div className="space-y-4">
            <h5 className="font-serif font-bold text-xs text-[#0A1D37] uppercase tracking-wider">הצטרפו לניוזלטר חכמה</h5>
            <p className="text-neutral-500 text-xs leading-relaxed">
              הירשמו וקבלו מאמרי מחקר חודשיים והזמנות מוקדמות למפגשים אינטימיים עם סופרים.
            </p>

            <form onSubmit={handleNewsletterSignup} className="flex gap-2 text-xs">
              <input
                type="email"
                required
                value={newsletterEmail}
                onChange={e => setNewsletterEmail(e.target.value)}
                placeholder="האימייל שלכם..."
                className="flex-1 p-2 border border-[#EAE2D8] bg-[#FCFAF7] rounded-lg outline-none focus:border-[#B8976C] font-sans"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-[#0A1D37] hover:bg-[#B8976C] text-white rounded-lg font-bold transition-all shadow-sm shrink-0 cursor-pointer"
              >
                הרשמה
              </button>
            </form>

            {newsletterStatus === 'success' && (
              <p className="text-[10px] text-emerald-600 font-sans font-semibold animate-pulse flex items-center gap-1">
                <CheckCircle className="h-3.5 w-3.5" />
                <span>נרשמת בהצלחה! קוד הטבה ראשון נשלח לתיבת האינבוקס.</span>
              </p>
            )}
          </div>

        </div>

        {/* Lower copyright bar */}
        <div className="border-t border-[#EAE2D8] bg-[#F5EFEB]/30 py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-400 gap-3">
            <p>© {new Date().getFullYear()} ספר חכמה (Sefer Chokhmah) - כל הזכויות שמורות לרשת ספריות ומחקר יהודי.</p>
            <div className="flex gap-4">
              <span className="hover:underline cursor-pointer">הצהרת נגישות (תקן AA)</span>
              <span>•</span>
              <span className="hover:underline cursor-pointer">תקנון האתר ותנאי שימוש</span>
            </div>
          </div>
        </div>

      </footer>

    </div>
  );
}
