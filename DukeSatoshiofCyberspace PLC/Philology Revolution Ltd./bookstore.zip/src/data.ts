import { Book, Category, Event, StoreLocation } from './types';

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'torah',
    nameHe: 'ספרי קודש ותורה',
    nameEn: 'Torah & Tanakh',
    description: 'חומשים, תנ״ך במהדורות מפוארות, ומפרשים קלאסיים ומודרניים כאחד.',
    imageUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 'philosophy',
    nameHe: 'מחשבה והגות יהודית',
    nameEn: 'Jewish Philosophy',
    description: 'ממורה נבוכים וספר הכוזרי ועד פילוסופיה יהודית בת זמננו.',
    imageUrl: 'https://images.unsplash.com/photo-1604871000636-074fa5117945?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 'literature',
    nameHe: 'ספרות עברית וישראלית',
    nameEn: 'Hebrew Literature',
    description: 'יצירות המופת של עגנון, עוז, וגרוסמן לצד קולות צעירים ורעננים.',
    imageUrl: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 'poetry',
    nameHe: 'שירה ופיוט',
    nameEn: 'Poetry & Piyyut',
    description: 'מפיוטי תור הזהב בספרד ועד שירה ישראלית מודרנית ואינטימית.',
    imageUrl: 'https://images.unsplash.com/photo-1471107340929-a87cd0f5b5f3?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 'rare',
    nameHe: 'מהדורות נדירות ומתנות',
    nameEn: 'Rare & Gift Editions',
    description: 'ספרים בכריכות עור איכותיות, הדפסות פקסימיליה מוגבלות ופריטי אספנות.',
    imageUrl: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 'children',
    nameHe: 'ספרי ילדים ונוער',
    nameEn: "Children's Literature",
    description: 'קלאסיקות עבריות מאוירות וספרות עשירה לגיל הרך ולנוער.',
    imageUrl: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&q=80&w=400'
  }
];

export const INITIAL_BOOKS: Book[] = [
  {
    id: '1',
    title: 'מורה נבוכים - מהדורת מופת',
    author: 'רבי משה בן מימון (הרמב״ם)',
    authorBio: 'גדול הפוסקים והפילוסופים היהודיים בימי הביניים. חיבר את היד החזקה ומורה נבוכים, ושימש כרופאו האישי של השולטן במצרים.',
    category: 'philosophy',
    publisher: 'הוצאת מוסד הרב קוק',
    publishDate: '2023',
    price: 189,
    rating: 4.9,
    reviewsCount: 34,
    coverUrl: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=600',
    description: 'מהדורה מדעית מדויקת וחדשה של ספר היסוד לפילוסופיה היהודית. הספר עוסק ביישוב הסתירות שבין פשט המקרא לבין התבונה והשכל, מתוך העמקה מושגית ומטאפיזית חסרת תקדים. כולל הערות שוליים, ביאור מקיף והשוואת תרגומים מהמקור הערבי.',
    tableOfContents: [
      'הקדמת הרמב״ם למורה נבוכים',
      'חלק ראשון: שמות מושאלים וביטויי הגשמה במקרא',
      'חלק שני: בריאת העולם, נבואה ומעשה מרכבה',
      'חלק שלישי: טעמי המצוות, השגחה ופתרון בעיית הרע'
    ],
    isbn: '978-965-7281-04-1',
    pageCount: 642,
    language: 'עברית (עם ביאור)',
    isRare: false,
    isEbook: true,
    isAudiobook: true,
    audioDuration: '18 שעות ו-40 דקות',
    inventory: 24,
    tags: ['הרמב״ם', 'הגות', 'מטאפיזיקה', 'ראשונים', 'פילוסופיה']
  },
  {
    id: '2',
    title: 'ספר הכוזרי המבואר',
    author: 'רבי יהודה הלוי (ריה״ל)',
    authorBio: 'מגדולי משוררי תור הזהב בספרד, פילוסוף והוגה דעות פטריוט אשר עלה לירושלים ונעלם באורח מסתורי בשעריה.',
    category: 'philosophy',
    publisher: 'ספריית שלם',
    publishDate: '2024',
    price: 145,
    rating: 4.8,
    reviewsCount: 22,
    coverUrl: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=600',
    description: 'ספר ההגנה על האמונה היהודית, שנכתב במקור בערבית-יהודית כדו-שיח דרמטי בין מלך כוזר לבין ה״חבר״ - החכם היהודי. מהדורה חדשה זו מנגישה את השפה המליצית עם פירוש בהיר השם דגש על שאלות לאומיות, תורת ארץ ישראל וייחוד עם ישראל.',
    tableOfContents: [
      'הקדמה היסטורית: חלום המלך והחיפוש אחר הדת האמיתית',
      'מאמר ראשון: הוכחת מציאות האלוהים ההיסטורית ומעמד הר סיני',
      'מאמר שני: קדושת ארץ ישראל, השפה העברית והנבואה',
      'מאמר שלישי: תפילה, שבת, ומצוות מעשיות כחוקי חיים',
      'מאמר רביעי: שמות השם ותורת הסוד',
      'מאמר חמישי: ביקורת הדיאלקטיקה הפילוסופית וחופש הבחירה'
    ],
    isbn: '978-965-526-112-9',
    pageCount: 412,
    language: 'עברית',
    isRare: false,
    isEbook: true,
    isAudiobook: false,
    inventory: 18,
    tags: ['ריה״ל', 'הגות יהודית', 'כוזרים', 'הגנה על האמונה']
  },
  {
    id: '3',
    title: 'חמישה חומשי תורה - מהדורת עור יוקרתית',
    author: 'סופרי המסורה (עם פירוש רש״י והרמב״ן)',
    authorBio: 'עורכי ועבירי הטקסט המקודש מדור לדור בדיוק מתמטי עליון.',
    category: 'rare',
    publisher: 'הוצאת כתר שלמה',
    publishDate: '2022',
    price: 890,
    rating: 5.0,
    reviewsCount: 15,
    coverUrl: 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=600',
    description: 'הדפסה מוגבלת ואספנית של חמישה חומשי תורה. כריכת עור איטלקי אמיתי בעיבוד ידני מסורתי, עם הטבעות זהב ועיטורי ברונזה בהשראת תנ״ך ליל וכתר ארם צובא. דפי נייר פרגמנט נטול חומצה השומר על בהירותו למאות שנים. כולל תגים, מסורה גדולה וקטנה, ופירושי עמודי התווך של הפרשנות.',
    tableOfContents: [
      'ספר בראשית - סיפורי האבות ובריאת עולם',
      'ספר שמות - יציאת מצרים ומתן תורה',
      'ספר ויקרא - תורת כוהנים וקדושה',
      'ספר במדבר - המסע במדבר והנחלות',
      'ספר דברים - משנה תורה ונאום משה'
    ],
    isbn: '978-965-998-001-5',
    pageCount: 1250,
    language: 'עברית מקראית',
    isRare: true,
    isEbook: false,
    isAudiobook: false,
    inventory: 5,
    tags: ['תורה', 'עור אמיתי', 'אספנות', 'רש״י', 'רמב״ן', 'מהדורה מוגבלת']
  },
  {
    id: '4',
    title: 'מיכאל שלי',
    author: 'עמוס עוז',
    authorBio: 'מגדולי הסופרים והאינטלקטואלים בישראל. חתן פרס ישראל לספרות, יצירותיו תורגמו לעשרות שפות ברחבי העולם.',
    category: 'literature',
    publisher: 'הוצאת עם עובד',
    publishDate: '1968',
    price: 85,
    rating: 4.7,
    reviewsCount: 112,
    coverUrl: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=600',
    description: 'הרומן המופתי המתרחש בירושלים המפוצלת של שנות החמישים. חנה, סטודנטית צעירה לספרות, נישאת למיכאל, חוקר גאולוגיה שקט ומעשי. מבעד לחייהם המשותפים נפרשת מסכת פסיכולוגית מורכבת של בדידות, תשוקה לא ממומשת וירושלים המסתורית המהווה דמות בפני עצמה ברומן.',
    tableOfContents: [
      'פרק א: פגישה במדרגות האוניברסיטה בגבעת רם',
      'פרק ב: נישואים שקטים בבית אבן קטן',
      'פרק ג: חלומות ירושלמיים והרוחות השבושות',
      'פרק ד: שתיקה של חורף בלב העיר המוקפת חומות'
    ],
    isbn: '978-965-13-0021-9',
    pageCount: 248,
    language: 'עברית',
    isRare: false,
    isEbook: true,
    isAudiobook: true,
    audioDuration: '7 שעות ו-15 דקות',
    inventory: 40,
    tags: ['עמוס עוז', 'ירושלים', 'פסיכולוגי', 'קלאסיקה ישראלית']
  },
  {
    id: '5',
    title: 'ספר הדקדוק הפנימי',
    author: 'דויד גרוסמן',
    authorBio: 'סופר והוגה ישראלי בולט, זוכה פרס מאן בוקר הבינלאומי ופרס ישראל. יצירותיו עוסקות ביחסים אנושיים, כאב הגידול והמציאות הישראלית.',
    category: 'literature',
    publisher: 'הוצאת הספריה החדשה',
    publishDate: '1991',
    price: 89,
    rating: 4.8,
    reviewsCount: 88,
    coverUrl: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=600',
    description: 'אחד הרומנים הגדולים של הספרות העברית בת זמננו. סיפורו של אהרון קליינפלד, נער הגדל בשכונת פועלים בירושלים של שנות השישים. בעוד שכל חבריו צומחים ומשתנים, גופו של אהרון ממאן לגדול, והוא נותר לכוד בתוך ילדותו, מתבונן בדקדקנות ובעין גאונית ברשת השקרים והפשרות של עולם המבוגרים.',
    tableOfContents: [
      'חלק ראשון: הגוף הממאן לשתף פעולה',
      'חלק שני: משחקי הילדות בחצר האחורית',
      'חלק שלישי: סודות של משפחת פליטים',
      'חלק רביעי: הבריחה אל עולם פנימי אבסולוטי'
    ],
    isbn: '978-965-448-102-1',
    pageCount: 384,
    language: 'עברית',
    isRare: false,
    isEbook: true,
    isAudiobook: false,
    inventory: 31,
    tags: ['גרוסמן', 'ירושלים', 'התבגרות', 'דרמה משפחתית']
  },
  {
    id: '6',
    title: 'פרחי אש - כל השירים',
    author: 'זלדה (זלדה שניאורסון-מישקובסקי)',
    authorBio: 'המשוררת הירושלמית החרדית שכבשה את ליבם של חילונים ודתיים כאחד. שירתה מתאפיינת במיסטיקה עמוקה, אהבת אדם וחיבור פילוסופי ליומיומי.',
    category: 'poetry',
    publisher: 'הוצאת הקיבוץ המאוחד',
    publishDate: '2021',
    price: 95,
    rating: 4.9,
    reviewsCount: 56,
    coverUrl: 'https://images.unsplash.com/photo-1471107340929-a87cd0f5b5f3?auto=format&fit=crop&q=80&w=600',
    description: 'אסופת כל השירים של זלדה, הכוללת את הספרים "פנאי", "הכרמל האי-נראה", "אל תרחק" ועוד. שירה שכולה תפילה זכה, דימויים עשירים מן המקורות, ויחס קיומי נוקב למוות, בדידות וחצי הבשר המיוסר.',
    tableOfContents: [
      'שירים מתוך קובץ "פנאי" (כולל "לכל איש יש שם")',
      'הכרמל האי-נראה: שירת ירושלים וההרים',
      'אל תרחק: בדידות ויחסי קרבה עם הבורא',
      'מכתבים ושירים גנוזים שטרם פורסמו'
    ],
    isbn: '978-965-02-0921-2',
    pageCount: 290,
    language: 'עברית',
    isRare: false,
    isEbook: true,
    isAudiobook: true,
    audioDuration: '4 שעות ו-10 דקות',
    inventory: 15,
    tags: ['זלדה', 'שירה', 'מיסטיקה', 'חסידות', 'ירושלים']
  },
  {
    id: '7',
    title: 'רש״י על התורה - פקסימיליה נדירה של דפוס ראשון',
    author: 'רבי שלמה יצחקי (רש״י)',
    authorBio: 'פרשן המקרא והתלמוד הגדול ביותר בכל הזמנים. פעל בצרפת במאה ה-11 ויצר מפתח קריאה אוניברסלי לכל שכבות העם היהודי.',
    category: 'rare',
    publisher: 'הוצאת ארכיון הספר העברי',
    publishDate: '2020',
    price: 1200,
    rating: 5.0,
    reviewsCount: 8,
    coverUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=600',
    description: 'הדפסת פקסימיליה משובחת ויוצאת דופן של פירוש רש״י על התורה כפי שהודפס ברג׳ו די קלבריה בשנת 1475 - הספר העברי הראשון שהודפס אי פעם. הספר כרוך בכריכת עץ אגוז וגב עור עבה, הדפים עשויים נייר כותנה משובח המדמה את דפי הספר המקורי. מהדורה מוגבלת של 150 עותקים ממוספרים בלבד.',
    tableOfContents: [
      'מבוא מדעי מאת פרופ׳ מאיר דוב: מהפכת הדפוס העברי',
      'צילומי הפקסימיליה המלאים של דפוס רג׳ו די קלבריה',
      'נספחים: טבלאות השוואת גרסאות של כתבי יד קדומים של רש״י'
    ],
    isbn: '978-965-772-005-9',
    pageCount: 320,
    language: 'עברית מקורית (כתב רש״י)',
    isRare: true,
    isEbook: false,
    isAudiobook: false,
    inventory: 2,
    tags: ['רש״י', 'פקסימיליה', 'דפוס ראשון', 'אגוז', 'מהדורה מוגבלת']
  },
  {
    id: '8',
    title: 'הנסיך הקטן - תרגום המופת המקורי',
    author: 'אנטואן דה סנט-אכזופרי (תרגום: אריה אלברטין)',
    authorBio: 'טייס, סופר ומשורר צרפתי אשר נעלם במשימת טיסה בים התיכון. יצירתו הפילוסופית-פואטית שבתה לבבות של מאות מיליונים.',
    category: 'children',
    publisher: 'הוצאת עם עובד',
    publishDate: '1973',
    price: 68,
    rating: 4.9,
    reviewsCount: 142,
    coverUrl: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&q=80&w=600',
    description: 'המהדורה העברית הקלאסית והנוסטלגית של יצירת המופת האלמותית. תרגום נמלץ ופיוטי השומר על התחושה הפנטסטית והמלנכולית של הילד הגר על כוכב קטן ומחפש חברות, אהבה ומשמעות בין עולמות המבוגרים המוזרים.',
    tableOfContents: [
      'הנחיתה במדבר סהרה וציור הכבשה בקופסה',
      'אסטרואיד B-612 והשושנה הגאוותנית',
      'הטיול בין הכוכבים: המלך, העסקן, הגאוגרף והשיכור',
      'ההגעה לכדור הארץ, המפגש עם השועל וסוד הלב'
    ],
    isbn: '978-965-13-0504-2',
    pageCount: 96,
    language: 'עברית',
    isRare: false,
    isEbook: true,
    isAudiobook: true,
    audioDuration: '2 שעות ו-20 דקות',
    inventory: 55,
    tags: ['הנסיך הקטן', 'ילדים', 'פילוסופיה', 'תרגום קלאסי']
  }
];

export const INITIAL_EVENTS: Event[] = [
  {
    id: 'e1',
    title: 'השקת מהדורת הפקסימיליה של ״מורה נבוכים״',
    speaker: 'פרופ׳ אבי שגיא וד״ר דרור בונדי',
    date: '2026-08-15',
    time: '19:30',
    location: 'סניף ספר חכמה, ירושלים - רחוב יפו 45',
    description: 'דיון פילוסופי עמוק על הרמב״ם כמורה של המאה ה-21. הערב יכלול תצוגה מיוחדת של כתבי יד נדירים מן המאה ה-14 והרמת כוסית חגיגית עם פתיחת אירועי הקיץ.',
    imageUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=400',
    ticketPrice: 35,
    seatsTotal: 120,
    seatsAvailable: 42,
    type: 'launch'
  },
  {
    id: 'e2',
    title: 'ערב מחווה ועיון בשירת זלדה: ״לכל איש יש שם״',
    speaker: 'בכל סרלואי ופרופ׳ חביבה פדיה',
    date: '2026-08-28',
    time: '20:00',
    location: 'סניף ספר חכמה, תל אביב - שדרות רוטשילד 12',
    description: 'אירוע שירה ופיוט המוקדש לקול הייחודי והעל-זמני של המשוררת הירושלמית זלדה. באירוע יוקראו שירים גנוזים של המשוררת, לצד הרצאה מרתקת על מיסטיקה יומיומית וחסידות מודרנית.',
    imageUrl: 'https://images.unsplash.com/photo-1471107340929-a87cd0f5b5f3?auto=format&fit=crop&q=80&w=400',
    ticketPrice: 20,
    seatsTotal: 80,
    seatsAvailable: 8,
    type: 'lecture'
  },
  {
    id: 'e3',
    title: 'מפגש מרתק עם הסופר דויד גרוסמן',
    speaker: 'דויד גרוסמן (שיחה עם פרופ׳ נסים קלדרון)',
    date: '2026-09-10',
    time: '18:30',
    location: 'סניף ספר חכמה, חיפה - מרכז פנורמה, הר הכרמל',
    description: 'רב-שיח אינטימי ומרגש עם חתן פרס ישראל לספרות דויד גרוסמן, בעקבות חצי יובל לספרו המופתי "ספר הדקדוק הפנימי". המשתתפים יוכלו לרכוש עותקים חתומים על ידי הסופר.',
    imageUrl: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=400',
    ticketPrice: 50,
    seatsTotal: 150,
    seatsAvailable: 0,
    type: 'talk'
  }
];

export const INITIAL_LOCATIONS: StoreLocation[] = [
  {
    id: 'loc1',
    city: 'ירושלים',
    cityEn: 'Jerusalem',
    name: 'ספר חכמה - בית האבן ההיסטורי',
    address: 'רחוב יפו 45 (ליד נחלת שבעה), ירושלים',
    phone: '02-6245112',
    hours: [
      'ימים א׳-ה׳: 09:00 - 21:00',
      'יום ו׳: 09:00 - 14:00 (שעון קיץ)',
      'מוצ״ש: שעה לאחר צאת השבת - 23:00'
    ],
    accessibility: 'נגישות מלאה לכסאות גלגלים, מעלון קומות, מערכות עזר לשמיעה בקופות',
    parking: 'חניון עירוני מסובסד ברחוב אלישר (מרחק 2 דקות הליכה)',
    imageUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=600',
    eventsCount: 4
  },
  {
    id: 'loc2',
    city: 'תל אביב',
    cityEn: 'Tel Aviv',
    name: 'ספר חכמה - אטלייה רוטשילד',
    address: 'שדרות רוטשילד 12, תל אביב-יפו',
    phone: '03-5124489',
    hours: [
      'ימים א׳-ה׳: 10:00 - 22:00',
      'יום ו׳: 09:00 - 15:00',
      'מוצ״ש: סגור (אירועים פרטיים בלבד)'
    ],
    accessibility: 'נגיש, קומת קרקע רחבה ומרווחת',
    parking: 'חניון מגדל רוטשילד 22 (הנחה מיוחדת לקוני הספרייה)',
    imageUrl: 'https://images.unsplash.com/photo-1604871000636-074fa5117945?auto=format&fit=crop&q=80&w=600',
    eventsCount: 3
  },
  {
    id: 'loc3',
    city: 'חיפה',
    cityEn: 'Haifa',
    name: 'ספר חכמה - אטלייה הכרמל',
    address: 'שדרות הנשיא 115 (מרכז פנורמה), חיפה',
    phone: '04-8371109',
    hours: [
      'ימים א׳-ה׳: 09:30 - 20:30',
      'יום ו׳: 09:00 - 14:00',
      'מוצ״ש: שעה וחצי לאחר צאת השבת - 22:30'
    ],
    accessibility: 'נגישות מלאה דרך מעליות מרכז פנורמה',
    parking: 'חניון תת-קרקעי חינם לשעה ראשונה לקוני ספר חכמה',
    imageUrl: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=600',
    eventsCount: 1
  }
];

export const DESIGN_SYSTEM_INFO = {
  philosophy: 'חיבור הרמוני בין כריזמטיות ירושלמית היסטורית לבין ארכיטקטורה שקטה ונקייה. העיצוב מבטא כבוד עמוק לאות העברית, לשטח הלבן, ולחומרי גלם טבעיים - אבן, עור ועץ אגוז.',
  palette: [
    { name: 'Jerusalem Stone', code: '#F5EFEB', desc: 'צבע אבן ירושלמית חמה המשמש כרקע משני מרגיע' },
    { name: 'Warm Cream', code: '#FAF7F2', desc: 'צבע שמנת רך המונע עייפות בעיניים ומדמה כריכה איכותית' },
    { name: 'Parchment White', code: '#FCFAF7', desc: 'צבע קלף עתיק המזמין קריאה אינטימית וממושכת' },
    { name: 'Deep Navy', code: '#0A1D37', desc: 'כחול עמוק, סמכותי ומלכותי המייצג למדנות ומסורת עברית' },
    { name: 'Walnut Wood', code: '#3E2723', desc: 'חום אגוז עשיר המדמה מדפי ספריות קלאסיות' },
    { name: 'Bronze & Gold', code: '#C5A880', desc: 'גוון זהב מוברש לתוספת הדר ויוקרה מאופקת' }
  ],
  typography: {
    display: 'גופן סריף עברי אלגנטי (כגון דוד, פרנק-ריהל או הדסה) המעורר תחושת קדושה, מונומנטליות והיסטוריה.',
    body: 'גופן סנס-סריף עברי נקי ומודרני (כגון אלמוני או נרקיס) המבטיח קריאה שוטפת, קלה ונוחה בכל גודל מסך.'
  },
  techStack: {
    frontend: 'Vite / React 19 / TypeScript / Tailwind CSS / Framer Motion',
    backend: 'Rust (Axum) / PostgreSQL / Redis / REST API / Stripe SDK',
    infrastructure: 'Cloud Run / GCP / Cloud CDN / Edge Optimization'
  }
};
