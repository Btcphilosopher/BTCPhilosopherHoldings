export interface Book {
  id: string;
  title: string;
  author: string;
  authorBio: string;
  category: string;
  publisher: string;
  publishDate: string;
  price: number;
  rating: number;
  reviewsCount: number;
  reviews?: Review[];
  coverUrl: string;
  description: string;
  tableOfContents: string[];
  isbn: string;
  pageCount: number;
  language: string;
  isRare?: boolean;
  isPreOrder?: boolean;
  isAudiobook?: boolean;
  isEbook?: boolean;
  audioDuration?: string;
  inventory: number;
  tags: string[];
}

export interface Review {
  id: string;
  user: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Category {
  id: string;
  nameHe: string;
  nameEn: string;
  description: string;
  imageUrl: string;
}

export interface Event {
  id: string;
  title: string;
  speaker: string;
  date: string;
  time: string;
  location: string;
  description: string;
  imageUrl: string;
  ticketPrice: number;
  seatsTotal: number;
  seatsAvailable: number;
  type: 'launch' | 'lecture' | 'talk' | 'festival' | 'circle';
}

export interface StoreLocation {
  id: string;
  city: string;
  cityEn: string;
  name: string;
  address: string;
  phone: string;
  hours: string[];
  accessibility: string;
  parking: string;
  imageUrl: string;
  eventsCount: number;
}

export interface CartItem {
  book: Book;
  quantity: number;
  format: 'print' | 'ebook' | 'audiobook';
}

export interface Order {
  id: string;
  date: string;
  items: CartItem[];
  total: number;
  status: 'processing' | 'shipped' | 'delivered' | 'pending';
  trackingNumber?: string;
}

export interface UserProfile {
  name: string;
  email: string;
  isMember: boolean;
  membershipSince?: string;
  wishlist: string[]; // Book IDs
  readingProgress: { [bookId: string]: number }; // percentage
  savedQuotes: { text: string; source: string }[];
  downloadedEbooks: string[]; // Book IDs
}

export interface CMSReport {
  totalSales: number;
  ordersCount: number;
  membersCount: number;
  booksCount: number;
  salesByCategory: { category: string; value: number }[];
}
