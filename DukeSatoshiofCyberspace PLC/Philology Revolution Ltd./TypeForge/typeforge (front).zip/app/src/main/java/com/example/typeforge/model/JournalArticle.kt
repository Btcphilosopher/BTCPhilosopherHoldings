package com.example.typeforge.model

data class JournalArticle(
    val id: String,
    val title: String,
    val subtitle: String,
    val date: String,
    val readTime: String,
    val author: String,
    val excerpt: String,
    val content: List<String>
)
