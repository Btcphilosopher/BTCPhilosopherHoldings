package com.example.typeforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.ui.components.BrandMockupCard
import com.example.typeforge.ui.components.BrandMockupType
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.WarmWhite

@Composable
fun BrandPreviewScreen(
    wordmark: String,
    typefaceName: String,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Text(
                text = "USE YOUR TYPEFACE",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                letterSpacing = (-0.5).sp,
                color = OxfordInk,
                modifier = Modifier.testTag("brand_preview_title")
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Typography-first brand applications across architecture, digital, and print.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 13.sp,
                color = Graphite
            )
        }

        // Mockup cards list
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            BrandMockupCard(BrandMockupType.SIGNAGE, wordmark, typefaceName)
            BrandMockupCard(BrandMockupType.WEBSITE, wordmark, typefaceName)
            BrandMockupCard(BrandMockupType.PACKAGING, wordmark, typefaceName)
            BrandMockupCard(BrandMockupType.ANNUAL_REPORT, wordmark, typefaceName)
            BrandMockupCard(BrandMockupType.APP_INTERFACE, wordmark, typefaceName)
            BrandMockupCard(BrandMockupType.BUSINESS_CARD, wordmark, typefaceName)
            BrandMockupCard(BrandMockupType.POSTER, wordmark, typefaceName)
        }

        Spacer(modifier = Modifier.height(24.dp))

        // CTA
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {
            Button(
                onClick = { onNavigate(Screen.LICENSING) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = OxfordInk,
                    contentColor = WarmWhite
                ),
                shape = RectangleShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("brand_to_licence_btn")
            ) {
                Text(
                    text = "PROCEED TO LICENSING (£249) →",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.0.sp
                )
            }
        }
    }
}
