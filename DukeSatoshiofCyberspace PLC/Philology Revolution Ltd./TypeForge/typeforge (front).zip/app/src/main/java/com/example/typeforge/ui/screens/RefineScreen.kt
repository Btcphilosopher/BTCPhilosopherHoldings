package com.example.typeforge.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.model.GenerationCandidate
import com.example.typeforge.model.GlyphMetric
import com.example.typeforge.ui.components.GlyphVectorCanvas
import com.example.typeforge.ui.components.MinimalRuleSlider
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun RefineScreen(
    candidate: GenerationCandidate,
    weight: Float,
    width: Float,
    contrast: Float,
    curvature: Float,
    geometric: Float,
    humanist: Float,
    industrial: Float,
    editorial: Float,
    xHeight: Float,
    serifLength: Float,
    tracking: Float,
    selectedGlyph: GlyphMetric,
    glyphPrompt: String,
    glyphRefinements: Map<Char, String>,
    onUpdateParam: (
        weight: Float,
        width: Float,
        contrast: Float,
        geometric: Float,
        humanist: Float,
        industrial: Float,
        editorial: Float,
        curvature: Float,
        xHeight: Float,
        serifLength: Float,
        tracking: Float,
        lineHeight: Float
    ) -> Unit,
    onSelectGlyph: (GlyphMetric) -> Unit,
    onGlyphPromptChange: (String) -> Unit,
    onSubmitGlyphRefinement: () -> Unit,
    onSaveVersion: (String) -> Unit,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val glyphRowScroll = rememberScrollState()

    var versionNote by remember { mutableStateOf("Refined leg curvature and terminal angle on R") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Text(
                text = "REFINE TYPEFACE",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                letterSpacing = (-0.5).sp,
                color = OxfordInk,
                modifier = Modifier.testTag("refine_screen_title")
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Interactive parametric tuning & individual glyph geometry editing.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 13.sp,
                color = Graphite
            )
        }

        // Live Specimen Preview Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, OxfordInk, RectangleShape)
                .background(WarmWhite)
                .padding(18.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "LIVE REFINEMENT PREVIEW · ${candidate.codeNumber}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        letterSpacing = 1.0.sp,
                        color = MutedRed,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "wght: ${weight.toInt()} · wdth: ${width.toInt()}%",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = OxfordBlue
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Northstar Engineering",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = when {
                        weight < 400 -> FontWeight.Light
                        weight < 550 -> FontWeight.Medium
                        weight < 700 -> FontWeight.SemiBold
                        else -> FontWeight.Bold
                    },
                    fontSize = 24.sp,
                    letterSpacing = (tracking * 0.1f).sp,
                    color = OxfordInk
                )

                Text(
                    text = "0123456789 · ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 12.sp,
                    letterSpacing = 0.5.sp,
                    color = Graphite
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Parametric Sliders Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, Stone, RectangleShape)
                .background(WarmWhite)
                .padding(18.dp)
        ) {
            Text(
                text = "CONTINUOUS GEOMETRIC CONTROLS",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                letterSpacing = 1.0.sp,
                color = OxfordInk
            )

            Spacer(modifier = Modifier.height(10.dp))

            MinimalRuleSlider("WEIGHT (LIGHTER ↔ HEAVIER)", weight, 100f..900f, {
                onUpdateParam(it, width, contrast, geometric, humanist, industrial, editorial, curvature, xHeight, serifLength, tracking, 1.3f)
            })

            MinimalRuleSlider("WIDTH (NARROWER ↔ WIDER)", width, 75f..125f, {
                onUpdateParam(weight, it, contrast, geometric, humanist, industrial, editorial, curvature, xHeight, serifLength, tracking, 1.3f)
            }, formatDisplay = { "%.0f%%".format(it) })

            MinimalRuleSlider("CONTRAST (LESS ↔ MORE)", contrast, 0f..100f, {
                onUpdateParam(weight, width, it, geometric, humanist, industrial, editorial, curvature, xHeight, serifLength, tracking, 1.3f)
            }, formatDisplay = { "%.0f%%".format(it) })

            MinimalRuleSlider("GEOMETRIC ↔ HUMANIST", geometric, 0f..100f, {
                val hum = 100f - it
                onUpdateParam(weight, width, contrast, it, hum, industrial, editorial, curvature, xHeight, serifLength, tracking, 1.3f)
            })

            MinimalRuleSlider("INDUSTRIAL ↔ EDITORIAL", industrial, 0f..100f, {
                val ed = 100f - it
                onUpdateParam(weight, width, contrast, geometric, humanist, it, ed, curvature, xHeight, serifLength, tracking, 1.3f)
            })

            MinimalRuleSlider("X-HEIGHT RATIO", xHeight, 0.40f..0.70f, {
                onUpdateParam(weight, width, contrast, geometric, humanist, industrial, editorial, curvature, it, serifLength, tracking, 1.3f)
            }, formatDisplay = { "%.2f".format(it) })

            MinimalRuleSlider("TRACKING / SPACING", tracking, -10f..40f, {
                onUpdateParam(weight, width, contrast, geometric, humanist, industrial, editorial, curvature, xHeight, serifLength, it, 1.3f)
            })
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Individual Glyph Refinement Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, OxfordBlue, RectangleShape)
                .background(PaperDark)
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "REFINE INDIVIDUAL GLYPHS",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.0.sp,
                    color = OxfordBlue
                )
                Text(
                    text = "SELECTED: '${selectedGlyph.char}' (${selectedGlyph.unicode})",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = OxfordInk
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Glyph horizontal selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(glyphRowScroll),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val glyphChars = "RABDEGHKMNOPQSTWXYZ0123456789"
                for (c in glyphChars) {
                    val isCur = selectedGlyph.char == c
                    Box(
                        modifier = Modifier
                            .border(
                                width = if (isCur) 1.5.dp else 0.5.dp,
                                color = if (isCur) OxfordInk else Stone,
                                shape = RectangleShape
                            )
                            .background(if (isCur) OxfordInk else WarmWhite)
                            .clickable {
                                onSelectGlyph(
                                    GlyphMetric(
                                        char = c,
                                        unicode = "U+%04X".format(c.code),
                                        advanceWidth = 612,
                                        leftSideBearing = 41,
                                        rightSideBearing = 39,
                                        contoursCount = 4,
                                        pointsCount = 38
                                    )
                                )
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .testTag("glyph_pick_$c")
                    ) {
                        Text(
                            text = c.toString(),
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (isCur) WarmWhite else OxfordInk
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Selected Glyph Vector Canvas Inspector
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .border(1.dp, Stone, RectangleShape)
            ) {
                GlyphVectorCanvas(
                    char = selectedGlyph.char,
                    weight = weight,
                    curvature = curvature,
                    contrast = contrast,
                    widthFactor = width / 100f,
                    serifLength = serifLength,
                    showMetricsGuides = true,
                    showControlPoints = true,
                    isDarkBg = false,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sub-structure tags
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val parts = listOf("STEM", "BOWL", "LEG", "COUNTER", "TERMINAL")
                for (p in parts) {
                    Box(
                        modifier = Modifier
                            .background(WarmWhite)
                            .border(0.5.dp, Stone, RectangleShape)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = p,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.sp,
                            color = Graphite
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Natural language glyph refinement prompt
            Text(
                text = "NATURAL LANGUAGE GEOMETRY INSTRUCTION FOR '${selectedGlyph.char}':",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = Graphite,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = glyphPrompt,
                    onValueChange = onGlyphPromptChange,
                    placeholder = {
                        Text(
                            text = "e.g. 'Make the leg more distinctive', 'Open counter'",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Graphite
                        )
                    },
                    singleLine = true,
                    shape = RectangleShape,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = OxfordInk,
                        unfocusedBorderColor = Stone,
                        focusedContainerColor = WarmWhite,
                        unfocusedContainerColor = WarmWhite
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("glyph_refine_input")
                )

                Button(
                    onClick = {
                        onSubmitGlyphRefinement()
                        Toast.makeText(context, "Applied geometry mutation to '${selectedGlyph.char}'", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = OxfordInk,
                        contentColor = WarmWhite
                    ),
                    shape = RectangleShape,
                    modifier = Modifier
                        .height(46.dp)
                        .testTag("apply_glyph_refine_btn")
                ) {
                    Text(
                        text = "APPLY",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }
            }

            if (glyphRefinements.containsKey(selectedGlyph.char)) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "ACTIVE MODIFICATION: \"${glyphRefinements[selectedGlyph.char]}\"",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = OxfordBlue,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Save Version Checkpoint & Next Actions
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {
            Button(
                onClick = {
                    onSaveVersion(versionNote)
                    Toast.makeText(context, "Saved version checkpoint to workspace.", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = PaperDark,
                    contentColor = OxfordInk
                ),
                shape = RectangleShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .border(1.dp, OxfordInk, RectangleShape)
                    .testTag("save_version_checkpoint_btn")
            ) {
                Text(
                    text = "💾 SAVE VERSION CHECKPOINT (v1.1)",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 0.8.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onNavigate(Screen.WORDMARK) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = OxfordInk,
                        contentColor = WarmWhite
                    ),
                    shape = RectangleShape,
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("to_wordmark_btn")
                ) {
                    Text(
                        text = "WORDMARK MODE →",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        letterSpacing = 1.0.sp
                    )
                }

                OutlinedButton(
                    onClick = { onNavigate(Screen.LICENSING) },
                    shape = RectangleShape,
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .border(1.dp, OxfordInk, RectangleShape)
                        .testTag("to_licensing_btn")
                ) {
                    Text(
                        text = "LICENCE (£249) →",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = OxfordInk
                    )
                }
            }
        }
    }
}
