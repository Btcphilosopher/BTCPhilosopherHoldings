package com.example.typeforge.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.typeforge.model.Typeface
import com.example.ui.theme.Graphite
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun ExportDialog(
    typefaceName: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var downloadedFormat by remember { mutableStateOf<String?>(null) }

    val formats = listOf(
        "OTF" to "OpenType PostScript CFF Font (Desktop / Print)",
        "TTF" to "TrueType Static Binary Masters (Thin to Black)",
        "WOFF2" to "Compressed Web Font WOFF2 format for self-hosting",
        "VARIABLE TTF" to "Single container with continuous wght, wdth, opsz axes",
        "JSON MANIFEST" to "Complete computational metrics & kerning matrix",
        "SPECIMEN PDF" to "High-resolution vector specimen book & proof sheets"
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RectangleShape,
            color = Paper,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, OxfordInk, RectangleShape)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "EXPORT PACKAGE",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.2.sp,
                            color = OxfordInk
                        )
                        Text(
                            text = "$typefaceName · v1.0 Production",
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = OxfordInk
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("export_dialog_close")
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = OxfordInk)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = Stone, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "SELECT OUTPUT BINARY FORMAT:",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = Graphite,
                    letterSpacing = 0.8.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for ((ext, desc) in formats) {
                        val isDownloaded = downloadedFormat == ext
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, if (isDownloaded) OxfordInk else Stone, RectangleShape)
                                .background(if (isDownloaded) PaperDark else WarmWhite)
                                .clickable {
                                    downloadedFormat = ext
                                    Toast.makeText(context, "$ext package prepared & verified.", Toast.LENGTH_SHORT).show()
                                }
                                .padding(12.dp)
                                .testTag("export_format_$ext"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = ext,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = OxfordInk
                                )
                                Text(
                                    text = desc,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 10.sp,
                                    color = Graphite
                                )
                            }
                            if (isDownloaded) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Ready",
                                    tint = OxfordBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = "Download",
                                    tint = Graphite,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val manifestJson = """
                        {
                          "foundry": "TYPEFORGE OXFORD",
                          "family": "$typefaceName",
                          "version": "1.0",
                          "axes": ["wght:100-900", "wdth:75-125", "opsz:8-72"],
                          "glyphs": 380,
                          "checksum": "sha256:4f8e02d9a9b83c"
                        }
                        """.trimIndent()
                        clipboardManager.setText(AnnotatedString(manifestJson))
                        Toast.makeText(context, "Full font manifest copied to clipboard.", Toast.LENGTH_LONG).show()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = OxfordInk,
                        contentColor = WarmWhite
                    ),
                    shape = RectangleShape,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("download_all_btn")
                ) {
                    Text(
                        text = "DOWNLOAD ALL (.ZIP BUNDLE)",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.0.sp
                    )
                }
            }
        }
    }
}
