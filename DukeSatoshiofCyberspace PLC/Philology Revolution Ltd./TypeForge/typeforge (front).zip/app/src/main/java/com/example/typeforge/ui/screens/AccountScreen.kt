package com.example.typeforge.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.model.Order
import com.example.typeforge.model.ProjectVersion
import com.example.typeforge.model.TeamMember
import com.example.typeforge.model.TypefaceProject
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

enum class AccountTab(val title: String) {
    TYPEFACES("MY TYPEFACES"),
    VERSIONS("VERSION HISTORY"),
    LICENSES("LICENSES & ORDERS"),
    TEAM("TEAM"),
    SETTINGS("SETTINGS")
}

@Composable
fun AccountScreen(
    activeProject: TypefaceProject,
    userProjects: List<TypefaceProject>,
    orders: List<Order>,
    teamMembers: List<TeamMember>,
    onRestoreVersion: (ProjectVersion) -> Unit,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    var selectedTab by remember { mutableStateOf(AccountTab.TYPEFACES) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Dashboard Greeting Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Text(
                text = "GOOD MORNING.",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                letterSpacing = 1.2.sp,
                color = MutedRed
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "YOUR TYPEFACES",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                letterSpacing = (-0.5).sp,
                color = OxfordInk,
                modifier = Modifier.testTag("account_dashboard_title")
            )
            Text(
                text = "Studio Workspace · Oxford Systems Ltd",
                fontFamily = FontFamily.SansSerif,
                fontSize = 13.sp,
                color = Graphite
            )
        }

        // Account Tabs Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(PaperDark)
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (tab in AccountTab.values()) {
                val isSelected = selectedTab == tab
                Box(
                    modifier = Modifier
                        .border(
                            width = if (isSelected) 1.dp else 0.5.dp,
                            color = if (isSelected) OxfordInk else Stone,
                            shape = RectangleShape
                        )
                        .background(if (isSelected) OxfordInk else Paper)
                        .clickable { selectedTab = tab }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = tab.title,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 9.sp,
                        color = if (isSelected) WarmWhite else OxfordInk
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        when (selectedTab) {
            AccountTab.TYPEFACES -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Create Action Card
                    Button(
                        onClick = { onNavigate(Screen.GENERATE) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = OxfordInk,
                            contentColor = WarmWhite
                        ),
                        shape = RectangleShape,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("account_create_typeface_btn")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "+ CREATE NEW TYPEFACE",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                letterSpacing = 1.0.sp
                            )
                        }
                    }

                    // Project Cards
                    val displayProjects = if (userProjects.isNotEmpty()) userProjects else listOf(activeProject)
                    for (proj in displayProjects) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, OxfordInk, RectangleShape)
                                .background(WarmWhite)
                                .clickable { onNavigate(Screen.REFINE) }
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = proj.name.uppercase(),
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 20.sp,
                                    color = OxfordInk
                                )
                                Text(
                                    text = proj.currentVersion,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = OxfordBlue
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Created ${proj.createdAt} · Regular / Bold / Variable",
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 11.sp,
                                color = Graphite
                            )

                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider(color = Stone.copy(alpha = 0.4f), thickness = 0.5.dp)
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "STATUS: ${proj.status.label.uppercase()}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = OxfordInk
                                )
                                Text(
                                    text = "OPEN WORKSPACE →",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp,
                                    color = OxfordBlue
                                )
                            }
                        }
                    }
                }
            }
            AccountTab.VERSIONS -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "VERSION HISTORY FOR ${activeProject.name.uppercase()}:",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = Graphite
                    )

                    for (ver in activeProject.versions) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Stone, RectangleShape)
                                .background(WarmWhite)
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = ver.versionNumber,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = OxfordInk
                                )
                                Text(
                                    text = ver.timestamp,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    color = Graphite
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = ver.note,
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 11.sp,
                                color = OxfordInk
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "wght: ${ver.weightVal.toInt()} · wdth: ${ver.widthVal.toInt()}% · x-height: ${ver.xHeightVal}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                color = OxfordBlue
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    onRestoreVersion(ver)
                                    Toast.makeText(context, "Restored parameters from ${ver.versionNumber}", Toast.LENGTH_SHORT).show()
                                    onNavigate(Screen.REFINE)
                                },
                                shape = RectangleShape,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(34.dp)
                                    .border(1.dp, OxfordInk, RectangleShape)
                            ) {
                                Text(
                                    text = "RESTORE THIS CHECKPOINT",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = OxfordInk
                                )
                            }
                        }
                    }
                }
            }
            AccountTab.LICENSES -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (orders.isEmpty()) {
                        Text(
                            text = "ACTIVE LICENCE: TF-892104 · NORTHSTAR STUDIO LICENCE (£249)",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = OxfordInk
                        )
                    } else {
                        for (ord in orders) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, OxfordInk, RectangleShape)
                                    .background(WarmWhite)
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = ord.orderNumber, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MutedRed)
                                    Text(text = "£${ord.totalGbp}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = OxfordInk)
                                }
                                Text(text = "${ord.typefaceName} — ${ord.tier.title} Licence", fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = OxfordInk)
                                Text(text = "Key: ${ord.licenseKey}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Graphite)
                            }
                        }
                    }
                }
            }
            AccountTab.TEAM -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (member in teamMembers) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Stone, RectangleShape)
                                .background(WarmWhite)
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .background(OxfordInk),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = member.avatarLetter.toString(),
                                        color = WarmWhite,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(text = member.name, fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = OxfordInk)
                                    Text(text = member.email, fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Graphite)
                                }
                            }
                            Text(
                                text = member.role.label.uppercase(),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = OxfordBlue
                            )
                        }
                    }
                }
            }
            AccountTab.SETTINGS -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .border(1.dp, Stone, RectangleShape)
                        .background(WarmWhite)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "API CREDENTIALS & PYTHON INTEGRATION",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        letterSpacing = 0.8.sp,
                        color = OxfordInk
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "TYPEFORGE API ENDPOINT: https://engine.typeforge.ox.ac.uk/v1",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = Graphite
                    )
                    Text(
                        text = "CLIENT KEY: tf_live_948271038571029481",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = Graphite
                    )
                }
            }
        }
    }
}
