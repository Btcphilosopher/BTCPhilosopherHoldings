package com.example.typeforge.model

enum class GenerationStage(val stepName: String, val description: String) {
    INTERPRETING_BRIEF("INTERPRETING BRIEF", "Parsing typographic intent, semantic axes, and historical lineage..."),
    BUILDING_TYPE_SYSTEM("BUILDING TYPE SYSTEM", "Synthesising bezier skeleton, master coordinate space, and stem logic..."),
    GENERATING_GLYPHS("GENERATING GLYPH STRUCTURES", "Constructing primary glyph outlines, terminals, apertures, and counters..."),
    BALANCING_WEIGHTS("BALANCING WEIGHTS", "Harmonising stroke mass distribution and optical compensation across styles..."),
    CALCULATING_SPACING("CALCULATING SPACING", "Deriving mathematical left/right side bearings and rhythm curves..."),
    OPTIMISING_KERNING("OPTIMISING KERNING", "Computing 3,481 kerning matrix relationships via geometric constraint solver..."),
    VALIDATING_FAMILY("VALIDATING FAMILY", "Performing open-type outline validation and cross-axis interpolation test...")
}

data class CandidateScore(
    val geometric: Int,
    val humanist: Int,
    val contrast: Int,
    val width: Int,
    val industrial: Int,
    val editorial: Int
)

data class GenerationCandidate(
    val id: String,
    val codeNumber: String, // "OPTION 01", "OPTION 02", "OPTION 03", "OPTION 04"
    val name: String,
    val characterSummary: String,
    val scores: CandidateScore,
    val weight: Float,
    val width: Float,
    val contrast: Float,
    val curvature: Float,
    val terminalAngle: Float,
    val serifLength: Float,
    val xHeightRatio: Float,
    val pangramSample: String = "THE FUTURE IS MADE.",
    val numeralSample: String = "0123456789",
    val specimenWord: String = "Oxford"
)

data class EngineMetric(
    val activeJobs: Int = 3,
    val queuedJobs: Int = 14,
    val gpuUtilizationPct: Int = 87,
    val cpuUtilizationPct: Int = 62,
    val memoryUsageGb: Double = 18.4,
    val generationRateHz: Double = 4.2,
    val modelVersion: String = "TYPEFORGE Engine v3.7-Flash-Oxford",
    val clusterNode: String = "OXF-NODE-04-A100"
)

data class GenerationJob(
    val id: String,
    val briefPrompt: String,
    val classification: Classification,
    val timestamp: String,
    val stage: GenerationStage,
    val progress: Float, // 0.0f to 1.0f
    val logMessage: String,
    val candidates: List<GenerationCandidate>,
    val latentVectorSample: List<Float> = listOf(0.42f, -0.19f, 0.88f, 0.12f, -0.65f, 0.33f, 0.91f, -0.04f),
    val isFinished: Boolean = false
)

data class KerningLog(
    val pair: String,
    val delta: Int,
    val solverConfidence: Float
)
