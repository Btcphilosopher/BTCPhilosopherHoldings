package com.example.typeforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.model.Classification
import com.example.typeforge.model.PricingTier
import com.example.typeforge.model.Typeface
import com.example.typeforge.ui.components.GlyphVectorCanvas
import com.example.typeforge.ui.components.MinimalRuleSlider
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun FontDetailScreen(
    typeface: Typeface,
    onNavigate: (Screen) -> Unit,
    onSelectPricingTier: (PricingTier) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var specimenText by remember { mutableStateOf(typeface.name) }
    var sizeSlider by remember { mutableFloatStateOf(36f) }
    var weightSlider by remember { mutableFloatStateOf(400f) }
    var widthSlider by remember { mutableFloatStateOf(100f) }
    var opticalSizeSlider by remember { mutableFloatStateOf(14f) }
    var trackingSlider by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Detail Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = typeface.code,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MutedRed
                )
                Text(
                    text = "RELEASED ${typeface.year}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = Graphite
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = typeface.name.uppercase(),
                fontFamily = if (typeface.classification == Classification.SERIF) FontFamily.Serif else FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 36.sp,
                letterSpacing = (-0.5).sp,
                color = OxfordInk,
                modifier = Modifier.testTag("font_detail_title")
            )

            Text(
                text = typeface.subtitle,
                fontFamily = FontFamily.SansSerif,
                fontSize = 15.sp,
                lineHeight = 22.sp,
                color = Graphite
            )
        }

        // Technical Metadata Grid
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, Stone, RectangleShape)
                .background(WarmWhite)
                .padding(14.dp)
        ) {
            val meta = listOf(
                "TYPE" to (if (typeface.classification == Classification.SERIF) "Serif" else "Sans Serif"),
                "CLASS" to typeface.classificationLabel,
                "WIDTH" to typeface.widthCategory,
                "CONTRAST" to typeface.contrastLevel,
                "LANGUAGE" to typeface.languages,
                "AXES" to "Weight (wght: 100-900) / Width (wdth: 75-125%) / Optical Size (opsz: 8-72pt)"
            )

            for ((label, value) in meta) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = label,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = OxfordInk,
                        modifier = Modifier.width(90.dp)
                    )
                    Text(
                        text = value,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp,
                        color = Graphite,
                        modifier = Modifier.weight(1f)
                    )
                }
                HorizontalDivider(color = Stone.copy(alpha = 0.3f), thickness = 0.5.dp)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Interactive Specimen Area
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, OxfordInk, RectangleShape)
                .background(WarmWhite)
                .padding(18.dp)
        ) {
            Text(
                text = "INTERACTIVE SPECIMEN",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                letterSpacing = 1.0.sp,
                color = OxfordInk
            )
            Spacer(modifier = Modifier.height(8.dp))

            // User input
            OutlinedTextField(
                value = specimenText,
                onValueChange = { specimenText = it },
                placeholder = { Text("TYPE SOMETHING...") },
                singleLine = false,
                maxLines = 3,
                shape = RectangleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OxfordInk,
                    unfocusedBorderColor = Stone,
                    focusedContainerColor = Paper,
                    unfocusedContainerColor = Paper
                ),
                textStyle = MaterialTheme.typography.bodyLarge.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Medium
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("specimen_editor_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Rendered Large Specimen Output
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Stone, RectangleShape)
                    .background(Paper)
                    .padding(20.dp)
            ) {
                Text(
                    text = if (specimenText.isNotEmpty()) specimenText else typeface.name,
                    fontFamily = if (typeface.classification == Classification.SERIF) FontFamily.Serif else FontFamily.SansSerif,
                    fontWeight = when {
                        weightSlider < 250 -> FontWeight.Thin
                        weightSlider < 350 -> FontWeight.Light
                        weightSlider < 450 -> FontWeight.Normal
                        weightSlider < 550 -> FontWeight.Medium
                        weightSlider < 650 -> FontWeight.SemiBold
                        weightSlider < 800 -> FontWeight.Bold
                        else -> FontWeight.Black
                    },
                    fontSize = sizeSlider.sp,
                    lineHeight = (sizeSlider * 1.15f).sp,
                    letterSpacing = (trackingSlider * 0.1f).sp,
                    color = OxfordInk,
                    modifier = Modifier.testTag("specimen_output_rendered")
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Variable Sliders Controls
            Text(
                text = "VARIABLE AXES & TYPOGRAPHIC PARAMETERS",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = Graphite,
                letterSpacing = 0.8.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            MinimalRuleSlider(
                label = "wght · WEIGHT",
                value = weightSlider,
                range = 100f..900f,
                onValueChange = { weightSlider = it }
            )

            MinimalRuleSlider(
                label = "wdth · WIDTH",
                value = widthSlider,
                range = 75f..125f,
                formatDisplay = { "%.0f%%".format(it) },
                onValueChange = { widthSlider = it }
            )

            MinimalRuleSlider(
                label = "opsz · OPTICAL SIZE",
                value = opticalSizeSlider,
                range = 8f..72f,
                formatDisplay = { "%.1f pt".format(it) },
                onValueChange = { opticalSizeSlider = it }
            )

            MinimalRuleSlider(
                label = "SIZE",
                value = sizeSlider,
                range = 18f..64f,
                formatDisplay = { "%.0f sp".format(it) },
                onValueChange = { sizeSlider = it }
            )

            MinimalRuleSlider(
                label = "TRACKING",
                value = trackingSlider,
                range = -10f..40f,
                formatDisplay = { "%.0f".format(it) },
                onValueChange = { trackingSlider = it }
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Quick Navigation to Glyphs & Family
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = { onNavigate(Screen.GLYPH_INSPECTOR) },
                shape = RectangleShape,
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, OxfordInk, RectangleShape)
            ) {
                Text(
                    text = "INSPECT GLYPHS →",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = OxfordInk
                )
            }

            OutlinedButton(
                onClick = { onNavigate(Screen.FAMILY_VIEW) },
                shape = RectangleShape,
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, OxfordInk, RectangleShape)
            ) {
                Text(
                    text = "FAMILY WEIGHTS →",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = OxfordInk
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Primary Licensing CTA Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .background(OxfordInk)
                .padding(20.dp)
        ) {
            Column {
                Text(
                    text = "LICENCE ${typeface.name.uppercase()}",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Stone,
                    letterSpacing = 1.2.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Commercial Studio Licence · £${typeface.basePriceGbp}",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = WarmWhite
                )
                Text(
                    text = "Perpetual commercial use for web, desktop & applications. Includes full variable font binary.",
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 12.sp,
                    color = Stone
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        onSelectPricingTier(PricingTier.STUDIO)
                        onNavigate(Screen.LICENSING)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = WarmWhite,
                        contentColor = OxfordInk
                    ),
                    shape = RectangleShape,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("licence_now_btn")
                ) {
                    Text(
                        text = "PURCHASE LICENCE · £${typeface.basePriceGbp}",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.0.sp
                    )
                }
            }
        }
    }
}
