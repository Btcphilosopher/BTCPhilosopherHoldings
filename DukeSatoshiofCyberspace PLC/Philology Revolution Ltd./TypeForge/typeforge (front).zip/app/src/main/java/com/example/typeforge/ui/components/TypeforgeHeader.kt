package com.example.typeforge.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun TypeforgeHeader(
    currentScreen: Screen,
    cartItemCount: Int,
    onNavigate: (Screen) -> Unit,
    onOpenMenu: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Paper)
            .statusBarsPadding()
    ) {
        // Top micro-annotation bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(PaperDark)
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "OXFORD GENERATIVE TYPE FOUNDRY · 51.7520° N, 1.2577° W",
                style = MaterialTheme.typography.labelSmall,
                color = Graphite,
                fontSize = 9.sp,
                letterSpacing = 1.0.sp
            )
            Text(
                text = "ENGINE v3.7 · GEMINI FLASH",
                style = MaterialTheme.typography.labelSmall,
                color = Graphite,
                fontSize = 9.sp
            )
        }

        // Primary masthead
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand Wordmark
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clickable { onNavigate(Screen.LANDING) }
                    .testTag("brand_logo_click")
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(OxfordInk, RectangleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "TF",
                        color = WarmWhite,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "TYPEFORGE",
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        letterSpacing = 2.0.sp,
                        color = OxfordInk
                    )
                    Text(
                        text = "OXFORD",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.sp,
                        letterSpacing = 2.5.sp,
                        color = Graphite
                    )
                }
            }

            // Minimal Actions
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Start a Typeface CTA
                Button(
                    onClick = { onNavigate(Screen.GENERATE) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = OxfordInk,
                        contentColor = WarmWhite
                    ),
                    shape = RectangleShape,
                    modifier = Modifier
                        .height(34.dp)
                        .testTag("header_start_typeface_btn")
                ) {
                    Text(
                        text = "START A TYPEFACE",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        letterSpacing = 1.2.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Menu toggle
                IconButton(
                    onClick = onOpenMenu,
                    modifier = Modifier
                        .size(34.dp)
                        .border(1.dp, Stone, RectangleShape)
                        .testTag("header_menu_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Menu",
                        tint = OxfordInk,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Sub-nav strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(width = 0.5.dp, color = Stone)
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val navItems = listOf(
                "FONTS" to Screen.FOUNDRY,
                "GENERATE" to Screen.GENERATE,
                "COMPARE" to Screen.COMPARE,
                "REFINE" to Screen.REFINE,
                "SPECIMEN" to Screen.WORDMARK,
                "LICENCES" to Screen.LICENSING,
                "ACCOUNT" to Screen.ACCOUNT,
                "JOURNAL" to Screen.JOURNAL
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for ((label, screen) in navItems.take(5)) {
                    val isSelected = currentScreen == screen
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) OxfordInk else Graphite,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 10.sp,
                        letterSpacing = 1.0.sp,
                        modifier = Modifier
                            .clickable { onNavigate(screen) }
                            .padding(vertical = 2.dp)
                            .testTag("nav_item_$label")
                    )
                }
            }

            Text(
                text = "MADE IN OXFORD",
                style = MaterialTheme.typography.labelSmall,
                color = Graphite,
                fontSize = 8.sp,
                letterSpacing = 1.0.sp
            )
        }
    }
}
