package com.example.typeforge.data

import com.example.typeforge.model.JournalArticle

object JournalData {
    val articles: List<JournalArticle> = listOf(
        JournalArticle(
            id = "how-a-typeface-is-generated",
            title = "How a Typeface Is Generated",
            subtitle = "From semantic brief vectors to differential Bézier constraint solvers.",
            date = "18 Sep 2026",
            readTime = "7 min read",
            author = "Dr. Arthur Pendelton & Eleanor Finch",
            excerpt = "Traditional type design relied on manual node placement. TYPEFORGE models letterforms as continuous differential manifolds governed by optical mass balance.",
            content = listOf(
                "When a designer speaks of an 'industrial but human' letterform, they are expressing constraints across multiple latent geometric domains: terminal angle distribution, aperture constriction, counter-to-stem optical mass ratio, and stem curvature continuity.",
                "In our Oxford laboratory, we represent the Roman alphabet not as static vectors of points, but as parametric topological graphs. A capital 'R', for example, consists of three coupled sub-systems: the primary vertical stem, the upper closed bowl, and the dynamic branching leg.",
                "Our generative engine samples a 128-dimensional latent vector trained on historical foundry matrices spanning from the 15th century to contemporary Swiss typography. The engine applies numerical relaxation solvers to ensure that stems share consistent ink distribution across varying glyph widths.",
                "The result is not a collage of existing shapes, but an analytically coherent, newly synthesized typographic system that adheres to classical proportions while answering the exact brief provided."
            )
        ),
        JournalArticle(
            id = "why-kerning-still-matters",
            title = "Why Kerning Still Matters",
            subtitle = "The mathematical geometry of whitespace in contemporary typography.",
            date = "04 Sep 2026",
            readTime = "5 min read",
            author = "Henry W. Sterling",
            excerpt = "Kerning is often treated as an afterthought in digital fonts. We explain why mathematical whitespace equilibrium is the foundation of reading rhythm.",
            content = listOf(
                "Spacing is 70% of a typeface's visual character. The eye does not read black ink; it perceives the rhythmic tempo created by the white shapes enclosed within and between letters.",
                "In a typical Latin glyph set of 400 characters, there exist 160,000 potential pair combinations. Traditional foundries kern a manual subset of 800 to 2,000 pairs, leaving thousands of edge cases unresolved.",
                "TYPEFORGE employs a custom Voronoi energy-minimization solver that computes the optical mass field surrounding each glyph contour. Pairs such as 'To', 'WA', 'LV', and 'r.' are automatically resolved so that the perceived whitespace area matches the target cadence of the family.",
                "When kerning reaches mathematical equilibrium, the typeface disappears into pure legibility, allowing the reader's attention to flow unimpeded."
            )
        ),
        JournalArticle(
            id = "variable-fonts-explained",
            title = "Variable Fonts Explained",
            subtitle = "OpenType Font Variations as continuous n-dimensional design spaces.",
            date = "22 Aug 2026",
            readTime = "6 min read",
            author = "Eleanor Finch",
            excerpt = "Variable fonts are not just smaller file packages; they represent a fundamental paradigm shift from discrete font files to fluid typographic instruments.",
            content = listOf(
                "Before the OpenType 1.8 specification, a family of 18 styles required 18 separate font files, each containing duplicate outline headers and tables. Variable fonts compress this into a single master container.",
                "Inside a variable font file, every point coordinate is stored as a base value plus a set of delta vectors along defined axes: Weight (wght), Width (wdth), Optical Size (opsz), Slant (slnt), and custom parametric axes.",
                "At TYPEFORGE, all generated typefaces are natively variable. The customer is never locked into arbitrary pre-rendered weights (e.g. 400 or 700); any exact weight value such as 465 or optical size 18.5pt can be rendered with mathematical precision.",
                "This allows typography in digital software, automotive dashboards, and web interfaces to adapt dynamically to viewport width, ambient lighting, and display pixel density."
            )
        ),
        JournalArticle(
            id = "designing-corporate-numerals",
            title = "Designing Corporate Numerals",
            subtitle = "Why figures make or break financial and industrial branding.",
            date = "11 Aug 2026",
            readTime = "4 min read",
            author = "Marcus Vance",
            excerpt = "In financial reports, telemetry screens, and engineering blueprints, numerals carry more information density than alphabetical text.",
            content = listOf(
                "Corporate typography frequently fails in the numerals. While uppercase letters receive immense aesthetic attention, numbers are often treated as simple geometric afterthoughts.",
                "In engineering and financial use cases, numerals face severe legibility challenges: disambiguating '1', 'I', and 'l', preventing '3', '5', and '8' from blurring at small sizes, and maintaining tabular alignment without sacrificing proportional beauty.",
                "Every TYPEFORGE typeface generates four distinct numeral systems: Proportional Lining, Tabular Lining (for financial balance sheets and telemetry), Proportional Oldstyle (for editorial literature), and Tabular Oldstyle.",
                "Our algorithms specifically optimize counter open-ness in '6', '8', and '9' to maintain high visual contrast on high-resolution screens and physical industrial instrumentation."
            )
        ),
        JournalArticle(
            id = "oxford-computational-foundry",
            title = "Oxford and the Computational Type Foundry",
            subtitle = "A five-person software company in a five-hundred-year-old tradition.",
            date = "29 Jul 2026",
            readTime = "8 min read",
            author = "Dr. Arthur Pendelton",
            excerpt = "TYPEFORGE operates from rooms near the Radcliffe Camera in Oxford, combining centuries of typographic scholarship with modern computational geometry.",
            content = listOf(
                "Oxford has been printing type since 1478, when Theodoric Rood brought Gutenberg's moveable type methods from Cologne to the banks of the River Cherwell.",
                "Our company occupies several rooms in an old stone building overlooking Broad Street. We are five people: two type designers, two computational geometers, and one software engineer. We build software that treats type design not as static drawing, but as executable mathematics.",
                "We do not build generic AI tools that flood the web with low-quality letterforms. Our generative engine is rigorously constrained by the laws of optical balance, historical proportion, and mechanical precision.",
                "We believe that the next era of commercial typography belongs to companies who treat the computer not as an automated illustrator, but as an extraordinarily precise musical instrument for the creation of type."
            )
        )
    )
}
