package com.example.typeforge.engine

import com.example.typeforge.model.CandidateScore
import com.example.typeforge.model.Classification
import com.example.typeforge.model.GenerationCandidate
import com.example.typeforge.model.GenerationJob
import com.example.typeforge.model.GenerationStage
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.util.UUID

object ComputationalTypeEngine {

    fun createInitialCandidates(brief: String, classification: Classification): List<GenerationCandidate> {
        val isSerif = classification == Classification.SERIF || brief.contains("serif", ignoreCase = true)
        val isSlab = classification == Classification.SLAB || brief.contains("slab", ignoreCase = true)
        val isMono = classification == Classification.MONO || brief.contains("mono", ignoreCase = true)
        val isGeometric = brief.contains("geometric", ignoreCase = true) || classification == Classification.DISPLAY

        val baseSerif = if (isSerif) 18f else if (isSlab) 24f else 0f

        return listOf(
            GenerationCandidate(
                id = "cand-01",
                codeNumber = "OPTION 01",
                name = "Rational Grotesk",
                characterSummary = "Sharp geometric clarity, unbending verticals, square terminals.",
                scores = CandidateScore(geometric = 88, humanist = 22, contrast = 12, width = 95, industrial = 90, editorial = 40),
                weight = 500f,
                width = 96f,
                contrast = 10f,
                curvature = 0.35f,
                terminalAngle = 0f,
                serifLength = baseSerif * 0.2f,
                xHeightRatio = 0.58f,
                pangramSample = "THE FUTURE IS MADE.",
                numeralSample = "0123456789",
                specimenWord = "Oxford"
            ),
            GenerationCandidate(
                id = "cand-02",
                codeNumber = "OPTION 02",
                name = "Kinetic Humanist",
                characterSummary = "Subtle calligraphic tension, flared apertures, organic rhythm.",
                scores = CandidateScore(geometric = 52, humanist = 84, contrast = 28, width = 102, industrial = 60, editorial = 88),
                weight = 450f,
                width = 104f,
                contrast = 24f,
                curvature = 0.85f,
                terminalAngle = 18f,
                serifLength = baseSerif * 0.9f,
                xHeightRatio = 0.52f,
                pangramSample = "THE FUTURE IS MADE.",
                numeralSample = "0123456789",
                specimenWord = "Engineering"
            ),
            GenerationCandidate(
                id = "cand-03",
                codeNumber = "OPTION 03",
                name = "British Technical",
                characterSummary = "The signature candidate: disciplined British engineering with human proportion.",
                scores = CandidateScore(geometric = 74, humanist = 58, contrast = 16, width = 100, industrial = 84, editorial = 68),
                weight = 520f,
                width = 100f,
                contrast = 15f,
                curvature = 0.60f,
                terminalAngle = 8f,
                serifLength = baseSerif * 0.5f,
                xHeightRatio = 0.55f,
                pangramSample = "THE FUTURE IS MADE.",
                numeralSample = "0123456789",
                specimenWord = "Northstar"
            ),
            GenerationCandidate(
                id = "cand-04",
                codeNumber = "OPTION 04",
                name = "Architectural Modular",
                characterSummary = "Super-ellipse junctions, expanded proportions, high telemetry density.",
                scores = CandidateScore(geometric = 94, humanist = 15, contrast = 8, width = 110, industrial = 96, editorial = 32),
                weight = 600f,
                width = 112f,
                contrast = 6f,
                curvature = 0.20f,
                terminalAngle = 0f,
                serifLength = if (isSlab) 30f else 0f,
                xHeightRatio = 0.62f,
                pangramSample = "THE FUTURE IS MADE.",
                numeralSample = "0123456789",
                specimenWord = "Typeforge"
            )
        )
    }

    fun runGenerationPipeline(
        brief: String,
        classification: Classification,
        jobId: String = "job-${UUID.randomUUID().toString().take(8)}"
    ): Flow<GenerationJob> = flow {
        val candidates = createInitialCandidates(brief, classification)

        // Stage 1
        emit(
            GenerationJob(
                id = jobId,
                briefPrompt = brief,
                classification = classification,
                timestamp = "Just now",
                stage = GenerationStage.INTERPRETING_BRIEF,
                progress = 0.12f,
                logMessage = "Parsing semantic constraints: geometry, contrast, optical weight equilibrium...",
                candidates = emptyList()
            )
        )
        delay(400)

        // Stage 2
        emit(
            GenerationJob(
                id = jobId,
                briefPrompt = brief,
                classification = classification,
                timestamp = "Just now",
                stage = GenerationStage.BUILDING_TYPE_SYSTEM,
                progress = 0.28f,
                logMessage = "Constructing 1000-unit master UPM coordinate space & stem manifold...",
                candidates = emptyList()
            )
        )
        delay(450)

        // Stage 3
        emit(
            GenerationJob(
                id = jobId,
                briefPrompt = brief,
                classification = classification,
                timestamp = "Just now",
                stage = GenerationStage.GENERATING_GLYPHS,
                progress = 0.46f,
                logMessage = "Synthesising 380 core glyph outlines, apertures, terminals and counters...",
                candidates = listOf(candidates[0])
            )
        )
        delay(500)

        // Stage 4
        emit(
            GenerationJob(
                id = jobId,
                briefPrompt = brief,
                classification = classification,
                timestamp = "Just now",
                stage = GenerationStage.BALANCING_WEIGHTS,
                progress = 0.62f,
                logMessage = "Balancing optical mass across Thin (100) to Black (900) masters...",
                candidates = listOf(candidates[0], candidates[1])
            )
        )
        delay(450)

        // Stage 5
        emit(
            GenerationJob(
                id = jobId,
                briefPrompt = brief,
                classification = classification,
                timestamp = "Just now",
                stage = GenerationStage.CALCULATING_SPACING,
                progress = 0.78f,
                logMessage = "Calculating left/right side bearings and cadence rhythm curves...",
                candidates = listOf(candidates[0], candidates[1], candidates[2])
            )
        )
        delay(450)

        // Stage 6
        emit(
            GenerationJob(
                id = jobId,
                briefPrompt = brief,
                classification = classification,
                timestamp = "Just now",
                stage = GenerationStage.OPTIMISING_KERNING,
                progress = 0.90f,
                logMessage = "Optimising 3,481 kerning relationships via Voronoi whitespace solver...",
                candidates = candidates
            )
        )
        delay(500)

        // Stage 7 - Complete
        emit(
            GenerationJob(
                id = jobId,
                briefPrompt = brief,
                classification = classification,
                timestamp = "Just now",
                stage = GenerationStage.VALIDATING_FAMILY,
                progress = 1.0f,
                logMessage = "Generated 4 distinct candidate type systems ready for evaluation and refinement.",
                candidates = candidates,
                isFinished = true
            )
        )
    }
}
