package com.example.typeforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.model.GenerationCandidate
import com.example.typeforge.ui.components.MinimalRuleSlider
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun CompareScreen(
    candidates: List<GenerationCandidate>,
    selectedCandidateIds: Set<String>,
    onToggleCandidate: (String) -> Unit,
    onChooseCandidate: (GenerationCandidate) -> Unit,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var testWord by remember { mutableStateOf("Oxford Engineering") }
    var sizeSlider by remember { mutableFloatStateOf(26f) }
    var trackingSlider by remember { mutableFloatStateOf(0f) }

    val activeCandidates = candidates.filter { selectedCandidateIds.contains(it.id) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Text(
                text = "COMPARE TYPEFACES",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                letterSpacing = (-0.5).sp,
                color = OxfordInk,
                modifier = Modifier.testTag("compare_screen_title")
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Synchronized side-by-side evaluation of candidate type systems.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 13.sp,
                color = Graphite
            )
        }

        // Candidate Selection Pills
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .background(PaperDark)
                .padding(12.dp)
        ) {
            Text(
                text = "ACTIVE COMPARISON CANDIDATES (SELECT 2 OR MORE):",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                color = Graphite,
                letterSpacing = 0.8.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (cand in candidates) {
                    val isSelected = selectedCandidateIds.contains(cand.id)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .border(
                                width = if (isSelected) 1.dp else 0.5.dp,
                                color = if (isSelected) OxfordInk else Stone,
                                shape = RectangleShape
                            )
                            .background(if (isSelected) OxfordInk else WarmWhite)
                            .clickable { onToggleCandidate(cand.id) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = cand.codeNumber,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 9.sp,
                            color = if (isSelected) WarmWhite else OxfordInk
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Synchronized Text Input & Size
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, Stone, RectangleShape)
                .background(WarmWhite)
                .padding(14.dp)
        ) {
            Text(
                text = "SYNCHRONIZED TEST PHRASE:",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = Graphite
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = testWord,
                onValueChange = { testWord = it },
                singleLine = true,
                shape = RectangleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OxfordInk,
                    unfocusedBorderColor = Stone,
                    focusedContainerColor = Paper,
                    unfocusedContainerColor = Paper
                ),
                textStyle = MaterialTheme.typography.bodyLarge.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Medium
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("compare_test_word_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            MinimalRuleSlider("SYNC SIZE", sizeSlider, 18f..48f, { sizeSlider = it })
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Side-by-side Candidate Columns
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            for (cand in activeCandidates) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, OxfordInk, RectangleShape)
                        .background(WarmWhite)
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${cand.codeNumber} · ${cand.name.uppercase()}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MutedRed
                        )
                        Text(
                            text = "GEOM ${cand.scores.geometric}% · HUM ${cand.scores.humanist}%",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = Graphite
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Live word specimen
                    Text(
                        text = if (testWord.isNotEmpty()) testWord else "Oxford Engineering",
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = when {
                            cand.weight < 450 -> FontWeight.Normal
                            cand.weight < 550 -> FontWeight.Medium
                            else -> FontWeight.Bold
                        },
                        fontSize = sizeSlider.sp,
                        lineHeight = (sizeSlider * 1.2f).sp,
                        letterSpacing = (trackingSlider * 0.1f).sp,
                        color = OxfordInk
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = (sizeSlider * 0.55f).sp,
                        letterSpacing = 1.0.sp,
                        color = Graphite
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "0123456789",
                        fontFamily = FontFamily.Monospace,
                        fontSize = (sizeSlider * 0.55f).sp,
                        letterSpacing = 1.0.sp,
                        color = Graphite
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = Stone.copy(alpha = 0.5f), thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                onChooseCandidate(cand)
                                onNavigate(Screen.REFINE)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = OxfordInk,
                                contentColor = WarmWhite
                            ),
                            shape = RectangleShape,
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("choose_candidate_${cand.codeNumber.replace(" ", "_")}")
                        ) {
                            Text(
                                text = "CHOOSE & REFINE",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                letterSpacing = 0.8.sp
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                onChooseCandidate(cand)
                                onNavigate(Screen.WORDMARK)
                            },
                            shape = RectangleShape,
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .border(1.dp, OxfordInk, RectangleShape)
                        ) {
                            Text(
                                text = "WORDMARK →",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = OxfordInk
                            )
                        }
                    }
                }
            }
        }
    }
}
