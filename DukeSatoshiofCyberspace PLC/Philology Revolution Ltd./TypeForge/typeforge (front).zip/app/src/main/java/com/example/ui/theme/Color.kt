package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Oxford Generative Type Foundry Palette
val OxfordInk = Color(0xFF151515)
val Paper = Color(0xFFF5F2EA)
val WarmWhite = Color(0xFFFBFAF6)
val Graphite = Color(0xFF30302E)
val Stone = Color(0xFFC9C2B5)
val OxfordBlue = Color(0xFF243B5A)
val MutedRed = Color(0xFF8C3D35)
val PaleBlue = Color(0xFFDDE5EC)

// Secondary accents
val PaperDark = Color(0xFFEBE6DC)
val OxfordInkLight = Color(0xFF222220)
val GraphiteLight = Color(0xFF4A4A46)
val StoneLight = Color(0xFFDFDAD1)
val StoneDark = Color(0xFFA8A092)
val OxfordBlueLight = Color(0xFF3B567D)
val OxfordNavy = Color(0xFF131F30)
val GridLine = Color(0x1F151515)
val GridLineDark = Color(0x28FBFAF6)
val CodeHighlight = Color(0xFF1E2D40)
