package com.example.typeforge.data

import com.example.typeforge.model.Classification
import com.example.typeforge.model.ComputationalScore
import com.example.typeforge.model.FontAxis
import com.example.typeforge.model.FontStyle
import com.example.typeforge.model.GlyphMetric
import com.example.typeforge.model.Typeface

object DefaultCatalogue {

    fun generateStandardGlyphSet(): List<GlyphMetric> {
        val uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        val lowercase = "abcdefghijklmnopqrstuvwxyz"
        val numerals = "0123456789"
        val symbols = "ÀÁÂÄÅÆÇÈÉÊË£€$¥&@#%§"

        val list = mutableListOf<GlyphMetric>()

        for (c in uppercase) {
            val adv = when (c) {
                'I' -> 310
                'M', 'W' -> 890
                'J', 'L' -> 490
                'R' -> 612
                else -> 650
            }
            val lsb = when (c) {
                'T', 'V', 'W', 'Y' -> 18
                'R' -> 41
                'I' -> 95
                else -> 48
            }
            val rsb = when (c) {
                'A', 'V', 'W', 'Y' -> 20
                'R' -> 39
                'I' -> 95
                else -> 46
            }
            val contours = when (c) {
                'B' -> 3
                'A', 'D', 'O', 'P', 'Q', 'R' -> 2
                else -> 1
            }
            val points = when (c) {
                'I' -> 12
                'L', 'T', 'E', 'F', 'H' -> 24
                'R' -> 38
                'B' -> 44
                'M', 'W' -> 34
                else -> 28
            }
            list.add(
                GlyphMetric(
                    char = c,
                    unicode = "U+%04X".format(c.code),
                    advanceWidth = adv,
                    leftSideBearing = lsb,
                    rightSideBearing = rsb,
                    contoursCount = contours,
                    pointsCount = points,
                    category = "Latin Uppercase"
                )
            )
        }

        for (c in lowercase) {
            val adv = when (c) {
                'l', 'i', 'j', 'f', 't' -> 280
                'm', 'w' -> 820
                'r' -> 390
                else -> 560
            }
            list.add(
                GlyphMetric(
                    char = c,
                    unicode = "U+%04X".format(c.code),
                    advanceWidth = adv,
                    leftSideBearing = 38,
                    rightSideBearing = 35,
                    contoursCount = if (c in "abdegopq") 2 else 1,
                    pointsCount = if (c in "gqpb") 32 else 20,
                    category = "Latin Lowercase"
                )
            )
        }

        for (c in numerals) {
            list.add(
                GlyphMetric(
                    char = c,
                    unicode = "U+%04X".format(c.code),
                    advanceWidth = 580,
                    leftSideBearing = 42,
                    rightSideBearing = 40,
                    contoursCount = if (c in "069") 2 else if (c == '8') 3 else 1,
                    pointsCount = 26,
                    category = "Proportional Numeral"
                )
            )
        }

        for (c in symbols) {
            list.add(
                GlyphMetric(
                    char = c,
                    unicode = "U+%04X".format(c.code),
                    advanceWidth = 610,
                    leftSideBearing = 35,
                    rightSideBearing = 35,
                    contoursCount = if (c in "§%&@") 3 else 2,
                    pointsCount = 36,
                    category = "Diacritic / Symbol"
                )
            )
        }

        return list
    }

    private val defaultAxes = listOf(
        FontAxis(tag = "wght", name = "Weight", min = 100f, max = 900f, defaultValue = 400f, currentValue = 400f),
        FontAxis(tag = "wdth", name = "Width", min = 75f, max = 125f, defaultValue = 100f, currentValue = 100f, unit = "%"),
        FontAxis(tag = "opsz", name = "Optical Size", min = 8f, max = 72f, defaultValue = 14f, currentValue = 14f, unit = "pt")
    )

    private val standardStyles = listOf(
        FontStyle("Thin", 100),
        FontStyle("Light", 300),
        FontStyle("Regular", 400),
        FontStyle("Medium", 500),
        FontStyle("Semibold", 600),
        FontStyle("Bold", 700),
        FontStyle("Black", 900)
    )

    val typefaces: List<Typeface> = listOf(
        Typeface(
            id = "tf-018",
            code = "TF-018",
            name = "Aureline",
            subtitle = "A contemporary humanist grotesk.",
            classification = Classification.SANS,
            classificationLabel = "Humanist / Grotesk",
            contrastLevel = "Low",
            widthCategory = "Normal",
            axes = defaultAxes,
            styles = standardStyles,
            scores = ComputationalScore(geometric = 68, humanist = 78, contrast = 16, width = 100, technical = 74, editorial = 82),
            glyphs = generateStandardGlyphSet(),
            description = "Aureline pairs British modernist clarity with subtle humanist warmth. Its proportioned counters and open terminals yield extraordinary legibility at small sizes while offering sculptural distinction in headline treatments.",
            pangram = "The quick brown fox jumps over the lazy dog",
            specimenHeading = "AURELINE GROTESK",
            basePriceGbp = 249
        ),
        Typeface(
            id = "tf-009",
            code = "TF-009",
            name = "North",
            subtitle = "A disciplined British engineering typeface.",
            classification = Classification.SANS,
            classificationLabel = "Engineering / Technical Sans",
            contrastLevel = "Minimal",
            widthCategory = "Slightly Condensed",
            axes = defaultAxes,
            styles = standardStyles,
            scores = ComputationalScore(geometric = 86, humanist = 34, contrast = 10, width = 94, technical = 95, editorial = 48),
            glyphs = generateStandardGlyphSet(),
            description = "Commissioned for industrial precision and demanding display contexts. North features unyielding vertical stems, sharp square terminals, and laser-optimized numerals for instrumentation, telemetry, and architectural signage.",
            pangram = "OXFORD ENGINEERING & TELEMETRY SYSTEMS",
            specimenHeading = "NORTHSTAR 01",
            basePriceGbp = 249
        ),
        Typeface(
            id = "tf-024",
            code = "TF-024",
            name = "Brunel",
            subtitle = "An industrial slab-serif built on Victorian rail geometry.",
            classification = Classification.SLAB,
            classificationLabel = "Industrial / Slab Serif",
            contrastLevel = "Medium",
            widthCategory = "Extended",
            axes = defaultAxes,
            styles = standardStyles,
            scores = ComputationalScore(geometric = 74, humanist = 42, contrast = 38, width = 112, technical = 88, editorial = 76),
            glyphs = generateStandardGlyphSet(),
            description = "Named after Isambard Kingdom Brunel, this typeface combines unbending structural authority with heavy unbracketed serifs. Ideal for civil engineering, infrastructure brands, and physical manufacturing.",
            pangram = "BRUNEL FOUNDRY & STRUCTURAL CALCULUS",
            specimenHeading = "GREAT WESTERN RAIL",
            basePriceGbp = 249
        ),
        Typeface(
            id = "tf-031",
            code = "TF-031",
            name = "Ashmole",
            subtitle = "An academic transitional serif for long-form publishing.",
            classification = Classification.SERIF,
            classificationLabel = "Transitional / Academic Serif",
            contrastLevel = "High",
            widthCategory = "Normal",
            axes = defaultAxes,
            styles = standardStyles,
            scores = ComputationalScore(geometric = 32, humanist = 92, contrast = 72, width = 98, technical = 40, editorial = 98),
            glyphs = generateStandardGlyphSet(),
            description = "Derived from 17th-century Oxford University Press matrices with modern computational optical sizing. Ashmole offers rhythmic reading comfort in critical text editions, monographs, and literary journals.",
            pangram = "Bibliotheca Bodleiana & Ashmolean Monographs",
            specimenHeading = "OXFORD SCHOLARSHIP",
            basePriceGbp = 249
        ),
        Typeface(
            id = "tf-042",
            code = "TF-042",
            name = "Circuit",
            subtitle = "A computational monospace for laboratory instruments.",
            classification = Classification.MONO,
            classificationLabel = "Monospace / Terminal",
            contrastLevel = "Monolinear",
            widthCategory = "Fixed 600 Units",
            axes = defaultAxes,
            styles = standardStyles,
            scores = ComputationalScore(geometric = 94, humanist = 20, contrast = 0, width = 85, technical = 99, editorial = 30),
            glyphs = generateStandardGlyphSet(),
            description = "Strict monospaced metrics paired with disambiguated zeroes, crossbarred 7s, and distinct punctuation glyphs. Designed for silicon compiler interfaces, high-density telemetry, and code editors.",
            pangram = "0x7FFE_4A9B -> SYNTH_GLYPH_VEC(0.841)",
            specimenHeading = "TERMINAL MATRIX",
            basePriceGbp = 199
        ),
        Typeface(
            id = "tf-015",
            code = "TF-015",
            name = "Oxford Grotesk",
            subtitle = "A mathematical rational sans with strict optical curves.",
            classification = Classification.SANS,
            classificationLabel = "Rational / Neo-Grotesk",
            contrastLevel = "Low",
            widthCategory = "Normal",
            axes = defaultAxes,
            styles = standardStyles,
            scores = ComputationalScore(geometric = 80, humanist = 50, contrast = 14, width = 100, technical = 85, editorial = 70),
            glyphs = generateStandardGlyphSet(),
            description = "The foundry's foundational grotesque typeface. Built with mathematical Super-ellipse Bézier curves that eliminate optical pinching in junctions and provide effortless visual calm.",
            pangram = "MATHEMATICS & COMPUTATIONAL GEOMETRY",
            specimenHeading = "OXFORD GROTESK",
            basePriceGbp = 249
        ),
        Typeface(
            id = "tf-001",
            code = "TF-001",
            name = "Foundry 01",
            subtitle = "The original algorithmic architectural specimen.",
            classification = Classification.EXPERIMENTAL,
            classificationLabel = "Architectural / Algorithmic",
            contrastLevel = "Variable",
            widthCategory = "Modular",
            axes = defaultAxes,
            styles = standardStyles,
            scores = ComputationalScore(geometric = 98, humanist = 15, contrast = 22, width = 105, technical = 92, editorial = 45),
            glyphs = generateStandardGlyphSet(),
            description = "Constructed purely from Cartesian coordinate constraints and recursive circular arcs. Foundry 01 stands at the boundary of architectural blueprinting and pure typographic geometry.",
            pangram = "CARTESIAN MANIFOLDS & PURE GEOMETRY",
            specimenHeading = "FOUNDRY SYSTEM",
            basePriceGbp = 299
        ),
        Typeface(
            id = "tf-055",
            code = "TF-055",
            name = "Mason",
            subtitle = "A chiseled classical lapidary display typeface.",
            classification = Classification.DISPLAY,
            classificationLabel = "Lapidary / Chiseled Serif",
            contrastLevel = "High",
            widthCategory = "Wide",
            axes = defaultAxes,
            styles = standardStyles,
            scores = ComputationalScore(geometric = 60, humanist = 65, contrast = 64, width = 118, technical = 55, editorial = 90),
            glyphs = generateStandardGlyphSet(),
            description = "Inspired by monumental stone inscriptions carved across Oxford colleges. Sharp triangular serifs and broad proportions convey enduring gravitas and architectural presence.",
            pangram = "MONUMENTAL INSCRIPTIONS IN STONE",
            specimenHeading = "MASON LAPIDARY",
            basePriceGbp = 249
        ),
        Typeface(
            id = "tf-062",
            code = "TF-062",
            name = "Radial",
            subtitle = "A curvature-continuous modernist display sans.",
            classification = Classification.DISPLAY,
            classificationLabel = "Geometric / Curvature Continuous",
            contrastLevel = "Monoline",
            widthCategory = "Expanded",
            axes = defaultAxes,
            styles = standardStyles,
            scores = ComputationalScore(geometric = 92, humanist = 45, contrast = 8, width = 110, technical = 82, editorial = 65),
            glyphs = generateStandardGlyphSet(),
            description = "Engineered with G2-continuous curvature arcs borrowed from automotive body surfacing. Radial delivers frictionless organic transitions and immaculate silhouette tension.",
            pangram = "CONTINUOUS G2 CURVATURE SURFACES",
            specimenHeading = "RADIAL DESIGN",
            basePriceGbp = 249
        ),
        Typeface(
            id = "tf-077",
            code = "TF-077",
            name = "Meridian",
            subtitle = "A high-contrast luxury serif for contemporary fashion.",
            classification = Classification.SERIF,
            classificationLabel = "Modern / High-Contrast Serif",
            contrastLevel = "Extreme",
            widthCategory = "Narrow",
            axes = defaultAxes,
            styles = standardStyles,
            scores = ComputationalScore(geometric = 45, humanist = 70, contrast = 95, width = 90, technical = 40, editorial = 96),
            glyphs = generateStandardGlyphSet(),
            description = "An unapologetic high-contrast modern serif with hairline serifs, ball terminals, and dramatic vertical stress. Tailored for haute horlogerie, luxury packaging, and editorial mastheads.",
            pangram = "MERIDIAN HAUTE HORLOGERIE & ATELIER",
            specimenHeading = "MERIDIAN LUXE",
            basePriceGbp = 299
        )
    )

    fun findById(id: String): Typeface {
        return typefaces.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: typefaces.first()
    }
}
