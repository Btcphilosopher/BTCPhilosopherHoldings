package com.example.typeforge.model

enum class Classification(val label: String) {
    ALL("ALL"),
    SANS("SANS"),
    SERIF("SERIF"),
    SLAB("SLAB"),
    DISPLAY("DISPLAY"),
    TEXT("TEXT"),
    MONO("MONO"),
    VARIABLE("VARIABLE"),
    EXPERIMENTAL("EXPERIMENTAL")
}

data class FontAxis(
    val tag: String,
    val name: String,
    val min: Float,
    val max: Float,
    val defaultValue: Float,
    val currentValue: Float,
    val unit: String = ""
)

data class FontStyle(
    val name: String,
    val weight: Int,
    val isItalic: Boolean = false,
    val widthPercent: Int = 100
)

data class GlyphMetric(
    val char: Char,
    val unicode: String,
    val advanceWidth: Int,
    val leftSideBearing: Int,
    val rightSideBearing: Int,
    val contoursCount: Int,
    val pointsCount: Int,
    val category: String = "Uppercase",
    val pathGeometry: String = ""
)

data class ComputationalScore(
    val geometric: Int,
    val humanist: Int,
    val contrast: Int,
    val width: Int,
    val technical: Int = 80,
    val editorial: Int = 50
)

enum class LicenseType(val title: String, val description: String) {
    DESKTOP("Desktop", "For desktop design tools, publishing, packaging and internal documents."),
    WEB("Web", "Self-hosted web fonts for unlimited monthly pageviews across domains."),
    APP("App / Product", "Embedded binary fonts inside native iOS, Android, and desktop applications."),
    CORPORATE("Corporate", "Company-wide brand deployment covering all employees, web, and sub-brands."),
    BROADCAST("Broadcast", "Television, film titles, streaming video, and large-scale public broadcast."),
    EMBEDDED("Embedded / IoT", "Hardware devices, vehicle displays, medical instruments and appliances."),
    ENTERPRISE("Enterprise", "Full organisation-wide deployment, multi-product use, and indemnification.")
}

enum class PricingTier(
    val title: String,
    val priceGbp: Int,
    val subtitle: String,
    val coverage: String
) {
    STARTER("Starter", 79, "Personal & independent projects", "Desktop (1-3 users) or Web (100k views)"),
    STUDIO("Studio", 249, "Commercial design studios & mid-size brands", "Web + Desktop (up to 10 seats) + App"),
    BRAND("Brand", 1200, "Corporate identity & global product suite", "Worldwide unrestricted corporate license"),
    ENTERPRISE("Enterprise", 4800, "Global conglomerates & custom terms", "Custom SLA, source geometry & bespoke modifications")
}

data class Typeface(
    val id: String,
    val code: String,
    val name: String,
    val subtitle: String,
    val classification: Classification,
    val classificationLabel: String,
    val contrastLevel: String,
    val widthCategory: String,
    val languages: String = "Latin Extended (380+ glyphs), Cyrillic, Greek support",
    val axes: List<FontAxis>,
    val styles: List<FontStyle>,
    val scores: ComputationalScore,
    val glyphs: List<GlyphMetric>,
    val description: String,
    val pangram: String = "The quick brown fox jumps over the lazy dog",
    val specimenHeading: String = "OXFORD ENGINEERING",
    val isVariable: Boolean = true,
    val year: String = "2026",
    val basePriceGbp: Int = 249
)
