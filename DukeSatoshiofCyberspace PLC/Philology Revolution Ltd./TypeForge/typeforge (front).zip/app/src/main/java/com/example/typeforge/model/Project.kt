package com.example.typeforge.model

enum class ProjectStatus(val label: String) {
    DRAFT("Draft"),
    GENERATING("Generating"),
    REFINING("In Refinement"),
    FINALIZED("Production Ready"),
    LICENSED("Licensed")
}

data class ProjectVersion(
    val versionNumber: String, // e.g. "v0.1", "v0.2", "v1.0"
    val timestamp: String,
    val note: String,
    val weightVal: Float,
    val widthVal: Float,
    val contrastVal: Float,
    val geometricVal: Float,
    val xHeightVal: Float
)

data class TypefaceProject(
    val id: String,
    val name: String,
    val clientOrBrand: String,
    val brief: String,
    val classification: Classification,
    val status: ProjectStatus,
    val createdAt: String,
    val currentVersion: String,
    val versions: List<ProjectVersion>,
    val selectedCandidateId: String? = null,
    val weight: Float = 400f,
    val width: Float = 100f,
    val contrast: Float = 20f,
    val geometricScore: Float = 70f,
    val xHeight: Float = 55f,
    val customGlyphModifications: Map<Char, String> = emptyMap(),
    val licensePurchased: PricingTier? = null
)

enum class TeamRole(val label: String) {
    OWNER("Owner"),
    ADMIN("Admin"),
    DESIGNER("Type Designer"),
    VIEWER("Viewer")
}

data class TeamMember(
    val id: String,
    val name: String,
    val email: String,
    val role: TeamRole,
    val avatarLetter: Char
)

data class Order(
    val id: String,
    val orderNumber: String,
    val typefaceId: String,
    val typefaceName: String,
    val licenseType: LicenseType,
    val tier: PricingTier,
    val totalGbp: Int,
    val customerName: String,
    val customerEmail: String,
    val companyName: String,
    val vatNumber: String = "",
    val timestamp: String,
    val downloadToken: String,
    val licenseKey: String,
    val formatEntitlements: List<String> = listOf("OTF", "TTF", "WOFF", "WOFF2", "VF-TTF", "PDF Specimen", "JSON Manifest")
)
