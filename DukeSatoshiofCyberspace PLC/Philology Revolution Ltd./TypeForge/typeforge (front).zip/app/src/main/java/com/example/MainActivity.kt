package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.typeforge.ui.components.ExportDialog
import com.example.typeforge.ui.components.TypeforgeDrawerContent
import com.example.typeforge.ui.components.TypeforgeHeader
import com.example.typeforge.ui.screens.AccountScreen
import com.example.typeforge.ui.screens.AdminMonitorScreen
import com.example.typeforge.ui.screens.BespokeScreen
import com.example.typeforge.ui.screens.BrandPreviewScreen
import com.example.typeforge.ui.screens.CompareScreen
import com.example.typeforge.ui.screens.DownloadCentreScreen
import com.example.typeforge.ui.screens.FamilyViewScreen
import com.example.typeforge.ui.screens.FontDetailScreen
import com.example.typeforge.ui.screens.FoundryScreen
import com.example.typeforge.ui.screens.GenerateScreen
import com.example.typeforge.ui.screens.GlyphInspectorScreen
import com.example.typeforge.ui.screens.JournalDetailScreen
import com.example.typeforge.ui.screens.JournalScreen
import com.example.typeforge.ui.screens.LandingScreen
import com.example.typeforge.ui.screens.LicensingCheckoutScreen
import com.example.typeforge.ui.screens.RefineScreen
import com.example.typeforge.ui.screens.WordmarkScreen
import com.example.typeforge.viewmodel.Screen
import com.example.typeforge.viewmodel.TypeforgeViewModel
import com.example.ui.theme.Paper
import com.example.ui.theme.TypeforgeTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TypeforgeTheme {
                TypeforgeApp()
            }
        }
    }
}

@Composable
fun TypeforgeApp(viewModel: TypeforgeViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    // Handle back button
    BackHandler(enabled = uiState.currentScreen != Screen.LANDING || drawerState.isOpen) {
        if (drawerState.isOpen) {
            scope.launch { drawerState.close() }
        } else {
            viewModel.navigateBack()
        }
    }

    if (uiState.showExportDialog) {
        ExportDialog(
            typefaceName = if (uiState.activeProject.name.isNotEmpty()) uiState.activeProject.name else uiState.selectedTypeface.name,
            onDismiss = { viewModel.setShowExportDialog(false) }
        )
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            TypeforgeDrawerContent(
                currentScreen = uiState.currentScreen,
                onNavigate = { screen ->
                    viewModel.navigateTo(screen)
                    scope.launch { drawerState.close() }
                },
                onClose = {
                    scope.launch { drawerState.close() }
                }
            )
        }
    ) {
        Scaffold(
            topBar = {
                TypeforgeHeader(
                    currentScreen = uiState.currentScreen,
                    cartItemCount = uiState.orders.size,
                    onNavigate = { viewModel.navigateTo(it) },
                    onOpenMenu = {
                        scope.launch { drawerState.open() }
                    }
                )
            },
            modifier = Modifier
                .fillMaxSize()
                .background(Paper)
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (uiState.currentScreen) {
                    Screen.LANDING -> {
                        LandingScreen(
                            onNavigate = { viewModel.navigateTo(it) },
                            onSelectTypeface = { viewModel.selectTypeface(it) }
                        )
                    }
                    Screen.FOUNDRY -> {
                        FoundryScreen(
                            catalogue = uiState.catalogue,
                            selectedFilter = uiState.selectedFilter,
                            searchQuery = uiState.searchQuery,
                            onFilterChange = { viewModel.setFilter(it) },
                            onSearchChange = { viewModel.setSearchQuery(it) },
                            onSelectTypeface = { viewModel.selectTypeface(it) },
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                    Screen.FONT_DETAIL -> {
                        FontDetailScreen(
                            typeface = uiState.selectedTypeface,
                            onNavigate = { viewModel.navigateTo(it) },
                            onSelectPricingTier = { viewModel.selectPricingTier(it) }
                        )
                    }
                    Screen.GENERATE -> {
                        GenerateScreen(
                            prompt = uiState.generationPrompt,
                            selectedClassification = uiState.selectedClassification,
                            isGenerating = uiState.isGenerating,
                            activeJob = uiState.activeJob,
                            candidates = uiState.candidates,
                            selectedCandidate = uiState.selectedCandidate,
                            onPromptChange = { viewModel.setGenerationPrompt(it) },
                            onClassificationChange = { viewModel.setGenerationClassification(it) },
                            onStartGeneration = { viewModel.startGeneration() },
                            onSelectCandidate = { viewModel.selectCandidate(it) },
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                    Screen.COMPARE -> {
                        CompareScreen(
                            candidates = uiState.candidates,
                            selectedCandidateIds = uiState.comparisonSelectedIds,
                            onToggleCandidate = { viewModel.toggleComparisonCandidate(it) },
                            onChooseCandidate = {
                                viewModel.selectCandidate(it)
                                viewModel.navigateTo(Screen.REFINE)
                            },
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                    Screen.REFINE -> {
                        RefineScreen(
                            candidate = uiState.selectedCandidate,
                            weight = uiState.refineWeight,
                            width = uiState.refineWidth,
                            contrast = uiState.refineContrast,
                            curvature = uiState.refineCurvature,
                            geometric = uiState.refineGeometric,
                            humanist = uiState.refineHumanist,
                            industrial = uiState.refineIndustrial,
                            editorial = uiState.refineEditorial,
                            xHeight = uiState.refineXHeight,
                            serifLength = uiState.refineSerifLength,
                            tracking = uiState.refineTracking,
                            selectedGlyph = uiState.selectedGlyph,
                            glyphPrompt = uiState.glyphPrompt,
                            glyphRefinements = uiState.glyphRefinements,
                            onUpdateParam = { w, wd, c, g, h, ind, ed, curv, xh, sl, tr, lh ->
                                viewModel.updateRefineParameter(
                                    weight = w,
                                    width = wd,
                                    contrast = c,
                                    geometric = g,
                                    humanist = h,
                                    industrial = ind,
                                    editorial = ed,
                                    curvature = curv,
                                    xHeight = xh,
                                    serifLength = sl,
                                    tracking = tr,
                                    lineHeight = lh
                                )
                            },
                            onSelectGlyph = { viewModel.selectGlyph(it) },
                            onGlyphPromptChange = { viewModel.setGlyphPrompt(it) },
                            onSubmitGlyphRefinement = { viewModel.submitGlyphRefinement() },
                            onSaveVersion = { viewModel.saveProjectVersion(it) },
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                    Screen.WORDMARK -> {
                        WordmarkScreen(
                            wordmark = uiState.wordmarkInput,
                            weight = uiState.refineWeight,
                            onWordmarkChange = { viewModel.setWordmarkInput(it) },
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                    Screen.BRAND_PREVIEW -> {
                        BrandPreviewScreen(
                            wordmark = uiState.wordmarkInput,
                            typefaceName = uiState.selectedCandidate.name,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                    Screen.GLYPH_INSPECTOR -> {
                        GlyphInspectorScreen(
                            typeface = uiState.selectedTypeface,
                            selectedGlyph = uiState.selectedGlyph,
                            weight = uiState.refineWeight,
                            contrast = uiState.refineContrast,
                            width = uiState.refineWidth,
                            curvature = uiState.refineCurvature,
                            onSelectGlyph = { viewModel.selectGlyph(it) },
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                    Screen.FAMILY_VIEW -> {
                        FamilyViewScreen(
                            typeface = uiState.selectedTypeface,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                    Screen.LICENSING -> {
                        LicensingCheckoutScreen(
                            typeface = uiState.selectedTypeface,
                            projectName = uiState.activeProject.name,
                            selectedTier = uiState.selectedPricingTier,
                            selectedLicenseType = uiState.selectedLicenseType,
                            customerName = uiState.customerName,
                            customerEmail = uiState.customerEmail,
                            customerCompany = uiState.customerCompany,
                            onSelectTier = { viewModel.selectPricingTier(it) },
                            onSelectLicenseType = { viewModel.selectLicenseType(it) },
                            onCustomerInfoChange = { n, e, c -> viewModel.updateCustomerInfo(n, e, c) },
                            onProcessCheckout = { viewModel.processCheckout() },
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                    Screen.DOWNLOADS -> {
                        DownloadCentreScreen(
                            order = uiState.recentOrder,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                    Screen.ACCOUNT -> {
                        AccountScreen(
                            activeProject = uiState.activeProject,
                            userProjects = uiState.userProjects,
                            orders = uiState.orders,
                            teamMembers = uiState.teamMembers,
                            onRestoreVersion = { viewModel.restoreVersion(it) },
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                    Screen.ADMIN_MONITOR -> {
                        AdminMonitorScreen(
                            metrics = uiState.engineMetrics,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                    Screen.JOURNAL -> {
                        JournalScreen(
                            articles = uiState.journalArticles,
                            onSelectArticle = { viewModel.selectArticle(it) },
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                    Screen.JOURNAL_DETAIL -> {
                        JournalDetailScreen(
                            article = uiState.selectedArticle,
                            onBack = { viewModel.navigateBack() }
                        )
                    }
                    Screen.BESPOKE -> {
                        BespokeScreen(
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                }
            }
        }
    }
}
