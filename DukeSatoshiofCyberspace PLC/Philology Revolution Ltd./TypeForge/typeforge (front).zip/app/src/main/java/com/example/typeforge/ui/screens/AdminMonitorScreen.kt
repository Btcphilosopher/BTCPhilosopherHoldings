package com.example.typeforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.model.EngineMetric
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun AdminMonitorScreen(
    metrics: EngineMetric,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Text(
                text = "ADMINISTRATION",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                letterSpacing = 1.2.sp,
                color = MutedRed
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "GENERATION ENGINE MONITOR",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 26.sp,
                letterSpacing = (-0.5).sp,
                color = OxfordInk,
                modifier = Modifier.testTag("admin_monitor_title")
            )
            Text(
                text = "Oxford Computational Laboratory Cluster Telemetry",
                fontFamily = FontFamily.SansSerif,
                fontSize = 13.sp,
                color = Graphite
            )
        }

        // Metrics Grid
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val stats = listOf(
                "ACTIVE INFERENCE JOBS" to "${metrics.activeJobs} parallel threads",
                "QUEUED BRIEFS" to "${metrics.queuedJobs} pending",
                "GPU CLUSTER UTILISATION" to "${metrics.gpuUtilizationPct}% (NVIDIA A100 SXM4)",
                "CPU COMPUTE ALLOCATION" to "${metrics.cpuUtilizationPct}% (64-core AMD EPYC)",
                "MEMORY RESIDENCY" to "${metrics.memoryUsageGb} GB / 80 GB",
                "SYNTHESIS RATE" to "${metrics.generationRateHz} Hz (glyphs/sec)",
                "ENGINE RUNTIME" to metrics.modelVersion,
                "CLUSTER NODE" to metrics.clusterNode
            )

            for ((k, v) in stats) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Stone, RectangleShape)
                        .background(WarmWhite)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = k, fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Graphite)
                    Text(text = v, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = OxfordInk)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Latent Vector & Genome Visualizer
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, OxfordInk, RectangleShape)
                .background(OxfordInk)
                .padding(16.dp)
        ) {
            Text(
                text = "128-DIMENSIONAL LATENT GENOME VECTOR SAMPLE:",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                color = Stone,
                letterSpacing = 0.8.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "[ +0.4281, -0.1904, +0.8812, +0.1209, -0.6543, +0.3391, +0.9102, -0.0418,\n  +0.7723, -0.4491, +0.5102, -0.0822, +0.6619, -0.3204, +0.8190, +0.1042 ]",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                lineHeight = 14.sp,
                color = WarmWhite
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Real-time Kerning Solver Log
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .background(PaperDark)
                .padding(16.dp)
        ) {
            Text(
                text = "VORONOI KERNING OPTIMISATION STREAM (3,481 RELATIONSHIPS):",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                color = OxfordInk,
                letterSpacing = 0.8.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            val logs = listOf(
                "T + o  -> -45 UPM  (Voronoi whitespace solver: 99.4% confidence)",
                "W + A  -> -60 UPM  (Voronoi whitespace solver: 98.8% confidence)",
                "L + V  -> -35 UPM  (Voronoi whitespace solver: 97.2% confidence)",
                "r + .  -> -20 UPM  (Voronoi whitespace solver: 99.1% confidence)",
                "P + a  -> -15 UPM  (Voronoi whitespace solver: 98.5% confidence)",
                "Y + e  -> -40 UPM  (Voronoi whitespace solver: 99.0% confidence)"
            )

            for (log in logs) {
                Text(
                    text = "▶ $log",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = Graphite,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }
    }
}
