package com.example.typeforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.model.GlyphMetric
import com.example.typeforge.model.Typeface
import com.example.typeforge.ui.components.GlyphVectorCanvas
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun GlyphInspectorScreen(
    typeface: Typeface,
    selectedGlyph: GlyphMetric,
    weight: Float,
    contrast: Float,
    width: Float,
    curvature: Float,
    onSelectGlyph: (GlyphMetric) -> Unit,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "GLYPH INSPECTION",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Black,
                    fontSize = 28.sp,
                    letterSpacing = (-0.5).sp,
                    color = OxfordInk,
                    modifier = Modifier.testTag("glyph_inspector_title")
                )
                Text(
                    text = "${typeface.code} · ${typeface.name}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = OxfordBlue
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Vector Bézier manifold, bounding metrics, and control node coordinates.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 13.sp,
                color = Graphite
            )
        }

        // Large Vector Glyph Inspector Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .height(260.dp)
                .border(1.dp, OxfordInk, RectangleShape)
        ) {
            GlyphVectorCanvas(
                char = selectedGlyph.char,
                weight = weight,
                contrast = contrast,
                widthFactor = width / 100f,
                curvature = curvature,
                showMetricsGuides = true,
                showControlPoints = true,
                isDarkBg = false,
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Technical Information Grid
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, Stone, RectangleShape)
                .background(WarmWhite)
                .padding(14.dp)
        ) {
            Text(
                text = "COMPUTATIONAL METRICS: GLYPH '${selectedGlyph.char}'",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                letterSpacing = 1.0.sp,
                color = OxfordInk
            )
            Spacer(modifier = Modifier.height(8.dp))

            val metrics = listOf(
                "UNICODE" to selectedGlyph.unicode,
                "ADVANCE" to "${selectedGlyph.advanceWidth} UPM",
                "LSB (LEFT SIDE BEARING)" to "${selectedGlyph.leftSideBearing} UPM",
                "RSB (RIGHT SIDE BEARING)" to "${selectedGlyph.rightSideBearing} UPM",
                "CONTOURS" to "${selectedGlyph.contoursCount}",
                "BÉZIER POINTS" to "${selectedGlyph.pointsCount} nodes"
            )

            for ((label, valStr) in metrics) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = Graphite)
                    Text(text = valStr, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = OxfordInk)
                }
                HorizontalDivider(color = Stone.copy(alpha = 0.3f), thickness = 0.5.dp)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Full Glyph Matrix Grid
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .background(PaperDark)
                .padding(14.dp)
        ) {
            Text(
                text = "SELECT GLYPH TO INSPECT (${typeface.glyphs.size} GLYPHS):",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = OxfordInk,
                letterSpacing = 0.8.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            // Render glyph tiles
            val glyphRows = typeface.glyphs.chunked(8)
            for (row in glyphRows) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    for (g in row) {
                        val isCur = selectedGlyph.char == g.char
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .border(
                                    width = if (isCur) 1.5.dp else 0.5.dp,
                                    color = if (isCur) OxfordInk else Stone,
                                    shape = RectangleShape
                                )
                                .background(if (isCur) OxfordInk else WarmWhite)
                                .clickable { onSelectGlyph(g) }
                                .padding(2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = g.char.toString(),
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (isCur) WarmWhite else OxfordInk
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }
}
