package com.example.typeforge.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun GlyphVectorCanvas(
    char: Char,
    weight: Float = 500f, // 100..900
    widthFactor: Float = 1.0f, // 0.75..1.25
    contrast: Float = 16f, // 0..100
    curvature: Float = 0.6f, // 0..1.0
    serifLength: Float = 0f,
    showMetricsGuides: Boolean = true,
    showControlPoints: Boolean = true,
    isDarkBg: Boolean = false,
    modifier: Modifier = Modifier
) {
    val inkColor = if (isDarkBg) WarmWhite else OxfordInk
    val guideColor = if (isDarkBg) Color(0x40FBFAF6) else Color(0x30151515)
    val gridColor = if (isDarkBg) Color(0x18FBFAF6) else Color(0x14151515)
    val accentRed = MutedRed
    val accentBlue = OxfordBlue

    Canvas(
        modifier = modifier
            .background(if (isDarkBg) OxfordInk else WarmWhite)
            .padding(16.dp)
            .fillMaxSize()
    ) {
        val canvasWidth = size.width
        val canvasHeight = size.height

        // Background metric grid (1000-unit UPM system)
        val gridStep = 40.dp.toPx()
        var x = 0f
        while (x < canvasWidth) {
            drawLine(
                color = gridColor,
                start = Offset(x, 0f),
                end = Offset(x, canvasHeight),
                strokeWidth = 1f
            )
            x += gridStep
        }
        var y = 0f
        while (y < canvasHeight) {
            drawLine(
                color = gridColor,
                start = Offset(0f, y),
                end = Offset(canvasWidth, y),
                strokeWidth = 1f
            )
            y += gridStep
        }

        // Typographic guidelines
        val baselineY = canvasHeight * 0.78f
        val capHeightY = canvasHeight * 0.20f
        val xHeightY = canvasHeight * (0.20f + (0.58f * (baselineY - capHeightY) / (canvasHeight * 0.58f)))
        val ascenderY = canvasHeight * 0.12f
        val descenderY = canvasHeight * 0.90f

        val leftBearingX = canvasWidth * 0.18f
        val rightBearingX = canvasWidth * (0.18f + 0.64f * widthFactor.coerceIn(0.7f, 1.3f))

        if (showMetricsGuides) {
            val dash = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)

            // Baseline
            drawLine(
                color = inkColor.copy(alpha = 0.6f),
                start = Offset(0f, baselineY),
                end = Offset(canvasWidth, baselineY),
                strokeWidth = 2f
            )

            // Cap Height
            drawLine(
                color = guideColor,
                start = Offset(0f, capHeightY),
                end = Offset(canvasWidth, capHeightY),
                strokeWidth = 1.5f,
                pathEffect = dash
            )

            // x-Height
            drawLine(
                color = guideColor,
                start = Offset(0f, xHeightY),
                end = Offset(canvasWidth, xHeightY),
                strokeWidth = 1.5f,
                pathEffect = dash
            )

            // Left side bearing
            drawLine(
                color = accentBlue.copy(alpha = 0.5f),
                start = Offset(leftBearingX, 0f),
                end = Offset(leftBearingX, canvasHeight),
                strokeWidth = 1.5f,
                pathEffect = dash
            )

            // Right side bearing
            drawLine(
                color = accentBlue.copy(alpha = 0.5f),
                start = Offset(rightBearingX, 0f),
                end = Offset(rightBearingX, canvasHeight),
                strokeWidth = 1.5f,
                pathEffect = dash
            )
        }

        // Draw computational glyph contours
        val stemThickness = (20f + (weight / 900f) * 60f) * (canvasWidth / 400f).coerceIn(0.8f, 2.0f)
        val thinThickness = (stemThickness * (1f - (contrast / 100f) * 0.75f)).coerceAtLeast(4f)

        val glyphRect = Rect(
            left = leftBearingX,
            top = capHeightY,
            right = rightBearingX,
            bottom = baselineY
        )

        val controlPoints = mutableListOf<Offset>()

        drawCustomGlyph(
            char = char,
            rect = glyphRect,
            stem = stemThickness,
            thin = thinThickness,
            curvature = curvature,
            serifLength = serifLength,
            color = inkColor,
            onControlPoint = { pt -> controlPoints.add(pt) }
        )

        // Draw Bezier node markers and tangents
        if (showControlPoints) {
            for (pt in controlPoints) {
                drawCircle(
                    color = accentRed,
                    radius = 4.dp.toPx(),
                    center = pt,
                    style = Fill
                )
                drawCircle(
                    color = WarmWhite,
                    radius = 2.dp.toPx(),
                    center = pt,
                    style = Fill
                )
            }
        }
    }
}

private fun DrawScope.drawCustomGlyph(
    char: Char,
    rect: Rect,
    stem: Float,
    thin: Float,
    curvature: Float,
    serifLength: Float,
    color: Color,
    onControlPoint: (Offset) -> Unit
) {
    val path = Path()

    when (char) {
        'R' -> {
            // Capital R with architectural stem, curved bowl, and dynamic flared leg
            val stemLeft = rect.left
            val stemRight = stemLeft + stem
            val midY = rect.top + rect.height * 0.52f

            // Vertical stem
            path.moveTo(stemLeft, rect.bottom)
            path.lineTo(stemLeft, rect.top)
            path.lineTo(stemRight, rect.top)
            path.lineTo(stemRight, rect.bottom)
            path.close()

            onControlPoint(Offset(stemLeft, rect.bottom))
            onControlPoint(Offset(stemLeft, rect.top))
            onControlPoint(Offset(stemRight, rect.top))
            onControlPoint(Offset(stemRight, rect.bottom))

            // Upper bowl outer
            val bowlOuter = Path()
            bowlOuter.moveTo(stemRight, rect.top)
            val bowlRight = rect.right - thin * 0.2f
            bowlOuter.cubicTo(
                bowlRight, rect.top,
                bowlRight, midY,
                stemRight, midY
            )
            bowlOuter.lineTo(stemRight, midY - thin)
            val bowlInnerRight = bowlRight - stem
            bowlOuter.cubicTo(
                bowlInnerRight, midY - thin,
                bowlInnerRight, rect.top + thin,
                stemRight, rect.top + thin
            )
            bowlOuter.close()

            onControlPoint(Offset(bowlRight, rect.top + rect.height * 0.26f))
            onControlPoint(Offset(stemRight, midY))

            // Leg
            val legPath = Path()
            val legStartX = stemLeft + stem * 0.85f
            legPath.moveTo(legStartX, midY - thin * 0.5f)
            val legEndX = rect.right + (curvature * 15f)
            val legEndY = rect.bottom

            legPath.cubicTo(
                stemRight + 20f, midY + 10f,
                legEndX - 30f * curvature, legEndY - 40f,
                legEndX, legEndY
            )
            legPath.lineTo(legEndX - stem * 1.1f, legEndY)
            legPath.cubicTo(
                legEndX - stem * 1.1f - 20f, legEndY - 35f,
                stemRight + 5f, midY + 15f,
                legStartX, midY + thin * 0.5f
            )
            legPath.close()

            onControlPoint(Offset(legStartX, midY))
            onControlPoint(Offset(legEndX, legEndY))

            drawPath(path, color)
            drawPath(bowlOuter, color)
            drawPath(legPath, color)
        }
        'A' -> {
            val apexX = rect.center.x
            val apexY = rect.top
            val leftBottom = rect.left
            val rightBottom = rect.right

            val aPath = Path()
            aPath.moveTo(apexX, apexY)
            aPath.lineTo(rightBottom, rect.bottom)
            aPath.lineTo(rightBottom - stem, rect.bottom)
            aPath.lineTo(apexX + (stem * 0.2f), apexY + stem * 1.2f)
            aPath.lineTo(apexX - (stem * 0.2f), apexY + stem * 1.2f)
            aPath.lineTo(leftBottom + stem, rect.bottom)
            aPath.lineTo(leftBottom, rect.bottom)
            aPath.close()

            // Crossbar
            val crossY = rect.top + rect.height * 0.62f
            val crossPath = Path()
            val leftCrossX = leftBottom + (apexX - leftBottom) * 0.62f
            val rightCrossX = rightBottom - (rightBottom - apexX) * 0.62f
            crossPath.moveTo(leftCrossX, crossY)
            crossPath.lineTo(rightCrossX, crossY)
            crossPath.lineTo(rightCrossX, crossY + thin)
            crossPath.lineTo(leftCrossX, crossY + thin)
            crossPath.close()

            onControlPoint(Offset(apexX, apexY))
            onControlPoint(Offset(leftBottom, rect.bottom))
            onControlPoint(Offset(rightBottom, rect.bottom))
            onControlPoint(Offset(rect.center.x, crossY))

            drawPath(aPath, color)
            drawPath(crossPath, color)
        }
        'O', '0' -> {
            val outerOval = Path()
            val innerOval = Path()

            val cx = rect.center.x
            val cy = rect.center.y
            val rx = rect.width / 2f
            val ry = rect.height / 2f

            outerOval.addOval(Rect(rect.left, rect.top, rect.right, rect.bottom))
            val innerLeft = rect.left + stem
            val innerRight = rect.right - stem
            val innerTop = rect.top + thin
            val innerBottom = rect.bottom - thin
            innerOval.addOval(Rect(innerLeft, innerTop, innerRight, innerBottom))

            onControlPoint(Offset(rect.left, cy))
            onControlPoint(Offset(rect.right, cy))
            onControlPoint(Offset(cx, rect.top))
            onControlPoint(Offset(cx, rect.bottom))

            drawPath(outerOval, color)
            drawPath(innerOval, WarmWhite)
        }
        'N' -> {
            val leftStem = Path()
            leftStem.moveTo(rect.left, rect.bottom)
            leftStem.lineTo(rect.left, rect.top)
            leftStem.lineTo(rect.left + stem, rect.top)
            leftStem.lineTo(rect.left + stem, rect.bottom)
            leftStem.close()

            val rightStem = Path()
            rightStem.moveTo(rect.right - stem, rect.bottom)
            rightStem.lineTo(rect.right - stem, rect.top)
            rightStem.lineTo(rect.right, rect.top)
            rightStem.lineTo(rect.right, rect.bottom)
            rightStem.close()

            val diag = Path()
            diag.moveTo(rect.left, rect.top)
            diag.lineTo(rect.right, rect.bottom)
            diag.lineTo(rect.right - stem, rect.bottom)
            diag.lineTo(rect.left, rect.top + stem * 1.5f)
            diag.close()

            onControlPoint(Offset(rect.left, rect.top))
            onControlPoint(Offset(rect.right, rect.bottom))

            drawPath(leftStem, color)
            drawPath(rightStem, color)
            drawPath(diag, color)
        }
        'T' -> {
            val topBar = Path()
            topBar.moveTo(rect.left, rect.top)
            topBar.lineTo(rect.right, rect.top)
            topBar.lineTo(rect.right, rect.top + thin)
            topBar.lineTo(rect.left, rect.top + thin)
            topBar.close()

            val stemX = rect.center.x - stem / 2f
            val midStem = Path()
            midStem.moveTo(stemX, rect.top + thin)
            midStem.lineTo(stemX + stem, rect.top + thin)
            midStem.lineTo(stemX + stem, rect.bottom)
            midStem.lineTo(stemX, rect.bottom)
            midStem.close()

            onControlPoint(Offset(rect.left, rect.top))
            onControlPoint(Offset(rect.right, rect.top))
            onControlPoint(Offset(rect.center.x, rect.bottom))

            drawPath(topBar, color)
            drawPath(midStem, color)
        }
        else -> {
            // General architectural glyph representation
            val gPath = Path()
            gPath.moveTo(rect.left, rect.bottom)
            gPath.lineTo(rect.left, rect.top)
            gPath.lineTo(rect.right, rect.top)
            gPath.lineTo(rect.right, rect.top + thin)
            gPath.lineTo(rect.left + stem, rect.top + thin)
            gPath.lineTo(rect.left + stem, rect.bottom)
            gPath.close()

            onControlPoint(Offset(rect.left, rect.top))
            onControlPoint(Offset(rect.right, rect.top))
            onControlPoint(Offset(rect.left, rect.bottom))

            drawPath(gPath, color)
        }
    }
}
