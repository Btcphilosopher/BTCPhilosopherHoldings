package com.example.typeforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.model.LicenseType
import com.example.typeforge.model.PricingTier
import com.example.typeforge.model.Typeface
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun LicensingCheckoutScreen(
    typeface: Typeface,
    projectName: String,
    selectedTier: PricingTier,
    selectedLicenseType: LicenseType,
    customerName: String,
    customerEmail: String,
    customerCompany: String,
    onSelectTier: (PricingTier) -> Unit,
    onSelectLicenseType: (LicenseType) -> Unit,
    onCustomerInfoChange: (name: String, email: String, company: String) -> Unit,
    onProcessCheckout: () -> Unit,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val displayFamilyName = if (projectName.isNotEmpty()) projectName else typeface.name

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Text(
                text = "COMMERCIAL LICENSING",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                letterSpacing = (-0.5).sp,
                color = OxfordInk,
                modifier = Modifier.testTag("licensing_screen_title")
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Clear commercial terms, perpetual rights, and complete binary entitlements.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 13.sp,
                color = Graphite
            )
        }

        // Pricing Tiers Grid
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val tiers = PricingTier.values()
            for (tier in tiers) {
                val isSelected = selectedTier == tier
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) OxfordInk else Stone,
                            shape = RectangleShape
                        )
                        .background(if (isSelected) WarmWhite else Paper)
                        .clickable { onSelectTier(tier) }
                        .padding(16.dp)
                        .testTag("tier_${tier.name}")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = tier.title.uppercase(),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                letterSpacing = 1.0.sp,
                                color = OxfordInk
                            )
                            Text(
                                text = tier.subtitle,
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 11.sp,
                                color = Graphite
                            )
                        }
                        Text(
                            text = if (tier == PricingTier.ENTERPRISE) "£4,800" else "£${tier.priceGbp}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = OxfordInk
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "COVERAGE: ${tier.coverage}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = OxfordBlue
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // License Scope Categories
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, Stone, RectangleShape)
                .background(WarmWhite)
                .padding(16.dp)
        ) {
            Text(
                text = "SELECT DEPLOYMENT SCOPE:",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = OxfordInk,
                letterSpacing = 0.8.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            val types = LicenseType.values()
            for (t in types) {
                val isSelected = selectedLicenseType == t
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectLicenseType(t) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = if (isSelected) "● " else "○ ",
                        color = if (isSelected) OxfordInk else Stone,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = t.title,
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 12.sp,
                            color = OxfordInk
                        )
                        Text(
                            text = t.description,
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 11.sp,
                            color = Graphite
                        )
                    }
                }
                HorizontalDivider(color = Stone.copy(alpha = 0.3f), thickness = 0.5.dp)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // SaaS Checkout Form
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, OxfordInk, RectangleShape)
                .background(WarmWhite)
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CUSTOMER & BILLING DETAILS",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.0.sp,
                    color = OxfordInk
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = OxfordBlue,
                        modifier = Modifier.height(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "TLS 256-BIT",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = OxfordBlue
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text("FULL NAME:", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Graphite)
            OutlinedTextField(
                value = customerName,
                onValueChange = { onCustomerInfoChange(it, customerEmail, customerCompany) },
                singleLine = true,
                shape = RectangleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OxfordInk,
                    unfocusedBorderColor = Stone,
                    focusedContainerColor = Paper,
                    unfocusedContainerColor = Paper
                ),
                modifier = Modifier.fillMaxWidth().height(46.dp).testTag("checkout_name_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text("WORK EMAIL:", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Graphite)
            OutlinedTextField(
                value = customerEmail,
                onValueChange = { onCustomerInfoChange(customerName, it, customerCompany) },
                singleLine = true,
                shape = RectangleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OxfordInk,
                    unfocusedBorderColor = Stone,
                    focusedContainerColor = Paper,
                    unfocusedContainerColor = Paper
                ),
                modifier = Modifier.fillMaxWidth().height(46.dp).testTag("checkout_email_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text("ORGANISATION / BRAND:", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Graphite)
            OutlinedTextField(
                value = customerCompany,
                onValueChange = { onCustomerInfoChange(customerName, customerEmail, it) },
                singleLine = true,
                shape = RectangleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OxfordInk,
                    unfocusedBorderColor = Stone,
                    focusedContainerColor = Paper,
                    unfocusedContainerColor = Paper
                ),
                modifier = Modifier.fillMaxWidth().height(46.dp).testTag("checkout_company_input")
            )

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = Stone, thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(12.dp))

            // Order Summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "$displayFamilyName (${selectedTier.title} Licence)",
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 12.sp,
                    color = OxfordInk
                )
                Text(
                    text = "£${selectedTier.priceGbp}.00",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = OxfordInk
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "UK VAT / Applicable Tax (0% Business Exemption)",
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 11.sp,
                    color = Graphite
                )
                Text(
                    text = "£0.00",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = Graphite
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = OxfordInk, thickness = 1.dp)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TOTAL DUE:",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 1.0.sp,
                    color = OxfordInk
                )
                Text(
                    text = "£${selectedTier.priceGbp}.00 GBP",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = OxfordInk
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PaperDark)
                    .padding(8.dp)
            ) {
                Text(
                    text = "PAYMENT PROVIDER: MOCK ENVIRONMENT · INSTANT CLEARANCE",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 8.sp,
                    color = Graphite,
                    letterSpacing = 0.5.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onProcessCheckout,
                colors = ButtonDefaults.buttonColors(
                    containerColor = OxfordInk,
                    contentColor = WarmWhite
                ),
                shape = RectangleShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("pay_and_licence_btn")
            ) {
                Text(
                    text = "PAY £${selectedTier.priceGbp} & ISSUE LICENCE →",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.0.sp
                )
            }
        }
    }
}
