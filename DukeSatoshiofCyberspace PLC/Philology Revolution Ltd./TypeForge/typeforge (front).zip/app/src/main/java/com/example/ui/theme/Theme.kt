package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = OxfordInk,
    onPrimary = WarmWhite,
    primaryContainer = StoneLight,
    onPrimaryContainer = OxfordInk,
    secondary = OxfordBlue,
    onSecondary = WarmWhite,
    secondaryContainer = PaleBlue,
    onSecondaryContainer = OxfordNavy,
    tertiary = MutedRed,
    onTertiary = WarmWhite,
    background = Paper,
    onBackground = OxfordInk,
    surface = WarmWhite,
    onSurface = OxfordInk,
    surfaceVariant = PaperDark,
    onSurfaceVariant = Graphite,
    outline = Stone,
    outlineVariant = StoneLight
)

private val DarkColorScheme = darkColorScheme(
    primary = WarmWhite,
    onPrimary = OxfordInk,
    primaryContainer = Graphite,
    onPrimaryContainer = WarmWhite,
    secondary = PaleBlue,
    onSecondary = OxfordNavy,
    secondaryContainer = OxfordBlue,
    onSecondaryContainer = WarmWhite,
    tertiary = MutedRed,
    onTertiary = WarmWhite,
    background = OxfordInk,
    onBackground = WarmWhite,
    surface = OxfordInkLight,
    onSurface = WarmWhite,
    surfaceVariant = Graphite,
    onSurfaceVariant = Stone,
    outline = GraphiteLight,
    outlineVariant = Graphite
)

@Composable
fun TypeforgeTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
