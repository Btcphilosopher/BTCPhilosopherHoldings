package com.example.typeforge.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.model.Classification
import com.example.typeforge.model.GenerationCandidate
import com.example.typeforge.model.GenerationJob
import com.example.typeforge.model.GenerationStage
import com.example.typeforge.ui.components.MinimalRuleSlider
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun GenerateScreen(
    prompt: String,
    selectedClassification: Classification,
    isGenerating: Boolean,
    activeJob: GenerationJob?,
    candidates: List<GenerationCandidate>,
    selectedCandidate: GenerationCandidate,
    onPromptChange: (String) -> Unit,
    onClassificationChange: (Classification) -> Unit,
    onStartGeneration: () -> Unit,
    onSelectCandidate: (GenerationCandidate) -> Unit,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var geometricSlider by remember { mutableFloatStateOf(72f) }
    var humanistSlider by remember { mutableFloatStateOf(45f) }
    var industrialSlider by remember { mutableFloatStateOf(85f) }
    var editorialSlider by remember { mutableFloatStateOf(50f) }
    var luxurySlider by remember { mutableFloatStateOf(25f) }
    var technicalSlider by remember { mutableFloatStateOf(88f) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Section Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Text(
                text = "CREATE YOUR TYPEFACE.",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                letterSpacing = (-0.5).sp,
                color = OxfordInk,
                modifier = Modifier.testTag("generate_screen_title")
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Describe the character. TYPEFORGE constructs the system.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 14.sp,
                color = Graphite
            )
        }

        // Brief Input Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, OxfordInk, RectangleShape)
                .background(WarmWhite)
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DESIGN BRIEF & SEMANTIC CONSTRAINTS",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    letterSpacing = 1.0.sp,
                    color = OxfordInk
                )
                Text(
                    text = "SIGNATURE DEMO ⚡",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp,
                    color = MutedRed,
                    modifier = Modifier
                        .clickable {
                            onPromptChange("A sophisticated British engineering company needs a new corporate typeface. Precise, human, technical, confident, highly legible, strong numerals and signage performance.")
                            onClassificationChange(Classification.SANS)
                        }
                        .testTag("signature_demo_btn")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = prompt,
                onValueChange = onPromptChange,
                minLines = 4,
                maxLines = 6,
                shape = RectangleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OxfordInk,
                    unfocusedBorderColor = Stone,
                    focusedContainerColor = Paper,
                    unfocusedContainerColor = Paper
                ),
                textStyle = MaterialTheme.typography.bodyLarge.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                    color = OxfordInk
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("generation_brief_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Structured Classification Selector
            Text(
                text = "CLASSIFICATION",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                letterSpacing = 0.8.sp,
                color = Graphite
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val types = listOf(
                    Classification.SANS,
                    Classification.SERIF,
                    Classification.SLAB,
                    Classification.DISPLAY,
                    Classification.MONO,
                    Classification.EXPERIMENTAL
                )
                for (t in types) {
                    val isSelected = selectedClassification == t
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .border(
                                width = if (isSelected) 1.dp else 0.5.dp,
                                color = if (isSelected) OxfordInk else Stone,
                                shape = RectangleShape
                            )
                            .background(if (isSelected) OxfordInk else Paper)
                            .clickable { onClassificationChange(t) }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = t.label,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 8.sp,
                            color = if (isSelected) WarmWhite else OxfordInk
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Style Sliders
            Text(
                text = "PARAMETRIC STYLE WEIGHTS",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                letterSpacing = 0.8.sp,
                color = Graphite
            )

            Spacer(modifier = Modifier.height(6.dp))

            MinimalRuleSlider("GEOMETRIC", geometricSlider, 0f..100f, { geometricSlider = it })
            MinimalRuleSlider("HUMANIST", humanistSlider, 0f..100f, { humanistSlider = it })
            MinimalRuleSlider("INDUSTRIAL", industrialSlider, 0f..100f, { industrialSlider = it })
            MinimalRuleSlider("EDITORIAL", editorialSlider, 0f..100f, { editorialSlider = it })
            MinimalRuleSlider("LUXURY", luxurySlider, 0f..100f, { luxurySlider = it })
            MinimalRuleSlider("TECHNICAL", technicalSlider, 0f..100f, { technicalSlider = it })

            Spacer(modifier = Modifier.height(16.dp))

            // Primary Generate Button
            Button(
                onClick = onStartGeneration,
                enabled = !isGenerating,
                colors = ButtonDefaults.buttonColors(
                    containerColor = OxfordInk,
                    contentColor = WarmWhite,
                    disabledContainerColor = Graphite,
                    disabledContentColor = Stone
                ),
                shape = RectangleShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("generate_typeface_btn")
            ) {
                if (isGenerating) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            color = WarmWhite,
                            modifier = Modifier.height(16.dp).width(16.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "CONSTRUCTING TYPE SYSTEM...",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.0.sp
                        )
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "GENERATE TYPEFACE",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.2.sp
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.height(14.dp)
                        )
                    }
                }
            }
        }

        // Animated Generation Pipeline Progress View
        if (isGenerating || activeJob != null) {
            val job = activeJob
            if (job != null) {
                Spacer(modifier = Modifier.height(20.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .border(1.dp, OxfordBlue, RectangleShape)
                        .background(PaperDark)
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "GENERATION PIPELINE: ${job.stage.stepName}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = OxfordBlue,
                            letterSpacing = 1.0.sp
                        )
                        Text(
                            text = "${(job.progress * 100).toInt()}%",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = OxfordInk
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { job.progress },
                        color = OxfordInk,
                        trackColor = Stone,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = job.logMessage,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = Graphite
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // 7-step sequence status list
                    val stages = GenerationStage.values()
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        for (st in stages) {
                            val isPast = st.ordinal < job.stage.ordinal
                            val isCurrent = st.ordinal == job.stage.ordinal
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = if (isPast) "✓" else if (isCurrent) "▶" else "○",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    color = if (isPast) OxfordBlue else if (isCurrent) MutedRed else Graphite
                                )
                                Text(
                                    text = st.stepName,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isCurrent) OxfordInk else Graphite
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Generation Result: 4 Generated Candidates
        Column(modifier = Modifier.padding(horizontal = 20.dp)) {
            Text(
                text = "GENERATION RESULTS · 4 CANDIDATE SYSTEMS",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                letterSpacing = 1.2.sp,
                color = OxfordInk
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Select a candidate to refine, compare side-by-side, or preview in corporate identity.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 12.sp,
                color = Graphite
            )

            Spacer(modifier = Modifier.height(14.dp))

            for (candidate in candidates) {
                val isSelected = selectedCandidate.id == candidate.id
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) OxfordInk else Stone,
                            shape = RectangleShape
                        )
                        .background(if (isSelected) WarmWhite else Paper)
                        .clickable { onSelectCandidate(candidate) }
                        .padding(16.dp)
                        .testTag("candidate_card_${candidate.codeNumber.replace(" ", "_")}")
                ) {
                    // Candidate header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = candidate.codeNumber,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = if (isSelected) MutedRed else Graphite
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "· ${candidate.name}",
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = OxfordInk
                            )
                        }
                        if (isSelected) {
                            Box(
                                modifier = Modifier
                                    .background(OxfordInk)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "SELECTED",
                                    color = WarmWhite,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = candidate.characterSummary,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp,
                        color = Graphite
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Rendered specimen
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = candidate.pangramSample,
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = when {
                                candidate.weight < 450 -> FontWeight.Normal
                                candidate.weight < 550 -> FontWeight.Medium
                                else -> FontWeight.Bold
                            },
                            fontSize = 17.sp,
                            letterSpacing = 1.0.sp,
                            color = OxfordInk
                        )
                        Text(
                            text = "Aa",
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            color = OxfordInk
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = candidate.numeralSample,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = Graphite,
                        letterSpacing = 1.5.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = Stone.copy(alpha = 0.4f), thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Computational Descriptors (Not aesthetic scores!)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "GEOMETRIC ${candidate.scores.geometric}%",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = Graphite
                        )
                        Text(
                            text = "HUMANIST ${candidate.scores.humanist}%",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = Graphite
                        )
                        Text(
                            text = "CONTRAST ${candidate.scores.contrast}%",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = Graphite
                        )
                        Text(
                            text = "WIDTH ${candidate.scores.width}%",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = Graphite
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Next Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onNavigate(Screen.REFINE) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = OxfordInk,
                        contentColor = WarmWhite
                    ),
                    shape = RectangleShape,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("action_refine_btn")
                ) {
                    Text(
                        text = "REFINE ${selectedCandidate.codeNumber}",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        letterSpacing = 1.0.sp
                    )
                }

                OutlinedButton(
                    onClick = { onNavigate(Screen.COMPARE) },
                    shape = RectangleShape,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .border(1.dp, OxfordInk, RectangleShape)
                        .testTag("action_compare_btn")
                ) {
                    Text(
                        text = "COMPARE ALL →",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = OxfordInk
                    )
                }
            }
        }
    }
}
