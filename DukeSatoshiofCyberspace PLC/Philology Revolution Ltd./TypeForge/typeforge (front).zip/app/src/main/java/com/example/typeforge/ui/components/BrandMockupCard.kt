package com.example.typeforge.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.StoneDark
import com.example.ui.theme.WarmWhite

enum class BrandMockupType(val title: String, val subtitle: String) {
    SIGNAGE("BUILDING SIGNAGE", "Architectural cast bronze & stone façade"),
    WEBSITE("ENTERPRISE WEBSITE", "Responsive technology hero and typography hierarchy"),
    PACKAGING("LUXURY PACKAGING", "Debossed tactile paper with minimalist foil stamping"),
    ANNUAL_REPORT("ANNUAL REPORT", "Editorial financial columns and tabular numerals"),
    APP_INTERFACE("INSTRUMENTATION APP", "High-density telemetry and cockpit telemetry"),
    BUSINESS_CARD("BUSINESS CARD", "G.F Smith 540gsm duplexed cotton board"),
    POSTER("EXHIBITION POSTER", "Swiss grid typography specimen on uncoated stock")
}

@Composable
fun BrandMockupCard(
    mockupType: BrandMockupType,
    wordmark: String,
    typefaceName: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Stone, RectangleShape)
            .background(Paper)
    ) {
        // Mockup Header Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(PaperDark)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = mockupType.title,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                letterSpacing = 1.0.sp,
                color = OxfordInk
            )
            Text(
                text = typefaceName.uppercase(),
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = Graphite
            )
        }

        // Mockup Body
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            when (mockupType) {
                BrandMockupType.SIGNAGE -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(OxfordInk)
                            .border(1.dp, Graphite, RectangleShape)
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = wordmark.uppercase(),
                            color = WarmWhite,
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            letterSpacing = 4.0.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "ADVANCED ENGINEERING & PROPULSION · BUILDING 04",
                            color = Stone,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            letterSpacing = 2.0.sp
                        )
                    }
                }
                BrandMockupType.WEBSITE -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(WarmWhite)
                            .border(1.dp, Stone, RectangleShape)
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = wordmark.uppercase(),
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp,
                                letterSpacing = 2.0.sp,
                                color = OxfordInk
                            )
                            Text(
                                text = "SYSTEMS · PLATFORM · RESEARCH",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                color = Graphite
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "The physical architecture of future autonomous systems.",
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 18.sp,
                            lineHeight = 22.sp,
                            color = OxfordInk
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Precision telemetry, aerodynamic calculus, and structural type systems engineered in Britain.",
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 12.sp,
                            lineHeight = 16.sp,
                            color = Graphite
                        )
                    }
                }
                BrandMockupType.PACKAGING -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF2C2E33))
                            .padding(22.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "REF. TF-904",
                                color = Color(0xFF9EA3B0),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.sp
                            )
                            Text(
                                text = "EST. OXFORD 2026",
                                color = Color(0xFF9EA3B0),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = wordmark.uppercase(),
                            color = WarmWhite,
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Light,
                            fontSize = 20.sp,
                            letterSpacing = 6.0.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "500ML · COLD PRESSED TITANIUM SULPHATE · OXFORD UK",
                            color = Color(0xFFB0B6C4),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            letterSpacing = 1.0.sp
                        )
                    }
                }
                BrandMockupType.ANNUAL_REPORT -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Paper)
                            .border(1.dp, StoneDark, RectangleShape)
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "$wordmark HOLDINGS PLC",
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            letterSpacing = 1.5.sp,
                            color = OxfordInk
                        )
                        Text(
                            text = "CONSOLIDATED FINANCIAL STATEMENT 2026",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = Graphite
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = Stone, thickness = 0.5.dp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Q3 Group Revenue", fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = OxfordInk)
                            Text("£148,290,000", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = OxfordInk)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Operating Profit Margin", fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = OxfordInk)
                            Text("28.4%", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = OxfordInk)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("R&D Computational Allocation", fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = OxfordInk)
                            Text("£34,120,000", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = OxfordInk)
                        }
                    }
                }
                BrandMockupType.APP_INTERFACE -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(OxfordInk)
                            .border(1.dp, Graphite, RectangleShape)
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("TELEMETRY CHANNEL 01", color = OxfordBlue, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                            Text("4,290 RPM", color = WarmWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = wordmark.uppercase(),
                            color = WarmWhite,
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            letterSpacing = 2.0.sp
                        )
                        Text(
                            text = "CORE TEMPERATURE 428.4°C · STABILITY NORMAL",
                            color = Stone,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        )
                    }
                }
                BrandMockupType.BUSINESS_CARD -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(PaperDark)
                            .border(1.dp, Stone, RectangleShape)
                            .padding(20.dp)
                    ) {
                        Text(
                            text = wordmark.uppercase(),
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            letterSpacing = 2.0.sp,
                            color = OxfordInk
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                        Text(
                            text = "Dr. Arthur Pendelton",
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            color = OxfordInk
                        )
                        Text(
                            text = "Chief Computational Geometer",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = Graphite
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "a.pendelton@$wordmark.co.uk · +44 (0)1865 270000",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = Graphite
                        )
                    }
                }
                BrandMockupType.POSTER -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MutedRed)
                            .padding(24.dp)
                    ) {
                        Text(
                            text = "OXFORD\nINTERNATIONAL\nCOLLOQUIUM",
                            color = WarmWhite,
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            lineHeight = 24.sp,
                            letterSpacing = 1.0.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = wordmark.uppercase(),
                            color = WarmWhite.copy(alpha = 0.9f),
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Light,
                            fontSize = 26.sp,
                            letterSpacing = 4.0.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "28–30 SEPTEMBER 2026 · CLARENDON BUILDING",
                            color = WarmWhite.copy(alpha = 0.8f),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            letterSpacing = 1.5.sp
                        )
                    }
                }
            }
        }
    }
}
