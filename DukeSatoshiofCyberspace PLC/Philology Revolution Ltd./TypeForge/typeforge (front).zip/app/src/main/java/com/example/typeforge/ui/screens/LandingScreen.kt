package com.example.typeforge.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.data.DefaultCatalogue
import com.example.typeforge.model.Typeface
import com.example.typeforge.ui.components.GlyphVectorCanvas
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.StoneLight
import com.example.ui.theme.WarmWhite

@Composable
fun LandingScreen(
    onNavigate: (Screen) -> Unit,
    onSelectTypeface: (Typeface) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val infiniteTransition = rememberInfiniteTransition(label = "morphTransition")
    val animatedWeight by infiniteTransition.animateFloat(
        initialValue = 300f,
        targetValue = 850f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "weightAnim"
    )
    val animatedCurvature by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(5000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "curvatureAnim"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Hero Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 24.dp)
        ) {
            Text(
                text = "TYPE\nWITHOUT\nPRECEDENT.",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 42.sp,
                lineHeight = 44.sp,
                letterSpacing = (-1.5).sp,
                color = OxfordInk,
                modifier = Modifier.testTag("landing_hero_title")
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Original typefaces generated, refined and licensed for the companies building what comes next.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 15.sp,
                lineHeight = 22.sp,
                color = Graphite
            )

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onNavigate(Screen.GENERATE) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = OxfordInk,
                        contentColor = WarmWhite
                    ),
                    shape = RectangleShape,
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("landing_create_btn")
                ) {
                    Text(
                        text = "CREATE A TYPEFACE",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.0.sp
                    )
                }

                OutlinedButton(
                    onClick = { onNavigate(Screen.FOUNDRY) },
                    shape = RectangleShape,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = OxfordInk),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .border(1.dp, OxfordInk, RectangleShape)
                        .testTag("landing_explore_btn")
                ) {
                    Text(
                        text = "EXPLORE FOUNDRY",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.0.sp
                    )
                }
            }
        }

        // Enormous Animated Computational Specimen
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, OxfordInk, RectangleShape)
                .background(WarmWhite)
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "LIVE SPECIMEN · COMPUTATIONAL INTERPOLATION",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        letterSpacing = 1.0.sp,
                        color = Graphite
                    )
                    Text(
                        text = "wght: ${animatedWeight.toInt()} · crv: ${"%.2f".format(animatedCurvature)}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = OxfordBlue
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                ) {
                    GlyphVectorCanvas(
                        char = 'R',
                        weight = animatedWeight,
                        curvature = animatedCurvature,
                        widthFactor = 1.0f,
                        contrast = 18f,
                        showMetricsGuides = true,
                        showControlPoints = true,
                        isDarkBg = false,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "OXFORD ENGINEERING",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp,
                    letterSpacing = 2.0.sp,
                    color = OxfordInk
                )

                Text(
                    text = "0123456789 · ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = Graphite,
                    letterSpacing = 0.5.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Section: The Foundry
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(PaperDark)
                .padding(20.dp)
        ) {
            Text(
                text = "A TYPE FOUNDRY\nBUILT LIKE A\nSOFTWARE COMPANY.",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 26.sp,
                lineHeight = 30.sp,
                letterSpacing = (-0.5).sp,
                color = OxfordInk
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "TYPEFORGE combines computational geometry, machine learning and traditional typographic principles to create original type families.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                color = Graphite
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Restrained diagram
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Stone, RectangleShape)
                    .background(WarmWhite)
                    .padding(14.dp)
            ) {
                val stages = listOf(
                    "BRIEF" to "Semantic description & brand constraints",
                    "TYPE SYSTEM" to "1000 UPM master manifold & stem logic",
                    "GENERATION" to "Synthesis of 380 core glyph outlines",
                    "REFINEMENT" to "Parametric & Bezier node tuning",
                    "TYPEFACE" to "Production OpenType & Variable binary"
                )

                stages.forEachIndexed { index, (step, desc) ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "0${index + 1}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MutedRed
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = step,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                letterSpacing = 1.0.sp,
                                color = OxfordInk
                            )
                            Text(
                                text = desc,
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 11.sp,
                                color = Graphite
                            )
                        }
                    }
                    if (index < stages.size - 1) {
                        Box(
                            modifier = Modifier
                                .padding(start = 8.dp, top = 4.dp, bottom = 4.dp)
                                .width(1.dp)
                                .height(14.dp)
                                .background(Stone)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Featured Catalogue Preview
        Column(modifier = Modifier.padding(horizontal = 20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FEATURED FOUNDRY MASTERS",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.2.sp,
                    color = OxfordInk
                )
                Text(
                    text = "VIEW ALL →",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = OxfordBlue,
                    modifier = Modifier.clickable { onNavigate(Screen.FOUNDRY) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            for (tf in DefaultCatalogue.typefaces.take(3)) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Stone, RectangleShape)
                        .background(WarmWhite)
                        .clickable {
                            onSelectTypeface(tf)
                            onNavigate(Screen.FONT_DETAIL)
                        }
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = tf.code,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = Graphite
                        )
                        Text(
                            text = "£${tf.basePriceGbp}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = OxfordInk
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = tf.name,
                        fontFamily = if (tf.classification.name == "SERIF") FontFamily.Serif else FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        color = OxfordInk
                    )
                    Text(
                        text = tf.subtitle,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 12.sp,
                        color = Graphite
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "THE QUICK BROWN FOX 0123456789",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = OxfordBlue,
                        letterSpacing = 0.5.sp
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Micro-startup Oxford character note
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .background(OxfordInk)
                .padding(20.dp)
        ) {
            Column {
                Text(
                    text = "OXFORD MICRO-STARTUP",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = Stone,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "5 PEOPLE · 1 TYPE ENGINE · 1 VERY GOOD IDEA",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = WarmWhite
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Made in Oxford. Built for everywhere.",
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 12.sp,
                    color = Stone
                )
            }
        }
    }
}
