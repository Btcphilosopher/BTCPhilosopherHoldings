package com.example.typeforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.model.Classification
import com.example.typeforge.model.Typeface
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun FoundryScreen(
    catalogue: List<Typeface>,
    selectedFilter: Classification,
    searchQuery: String,
    onFilterChange: (Classification) -> Unit,
    onSearchChange: (String) -> Unit,
    onSelectTypeface: (Typeface) -> Unit,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    var previewPangram by remember { mutableStateOf("The quick brown fox jumps over the lazy dog") }
    val secondaryFilterScroll = rememberScrollState()
    val primaryFilterScroll = rememberScrollState()

    val filteredList = catalogue.filter { tf ->
        val matchesClassification = (selectedFilter == Classification.ALL) || (tf.classification == selectedFilter)
        val matchesSearch = searchQuery.isEmpty() ||
                tf.name.contains(searchQuery, ignoreCase = true) ||
                tf.code.contains(searchQuery, ignoreCase = true) ||
                tf.classificationLabel.contains(searchQuery, ignoreCase = true) ||
                tf.description.contains(searchQuery, ignoreCase = true)
        matchesClassification && matchesSearch
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
    ) {
        // Foundry Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Text(
                text = "THE FOUNDRY",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                letterSpacing = (-0.5).sp,
                color = OxfordInk,
                modifier = Modifier.testTag("foundry_title")
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Original typefaces generated in the TYPEFORGE system.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 13.sp,
                color = Graphite
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Search input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = {
                    Text(
                        text = "Search by name, geometry, industrial, serif...",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = Graphite
                    )
                },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = Graphite)
                },
                singleLine = true,
                shape = RectangleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OxfordInk,
                    unfocusedBorderColor = Stone,
                    focusedContainerColor = WarmWhite,
                    unfocusedContainerColor = WarmWhite
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("foundry_search_input")
            )
        }

        // Primary Classification Filters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(PaperDark)
                .horizontalScroll(primaryFilterScroll)
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (classification in Classification.values()) {
                val isSelected = selectedFilter == classification
                Box(
                    modifier = Modifier
                        .border(
                            width = if (isSelected) 1.dp else 0.5.dp,
                            color = if (isSelected) OxfordInk else Stone,
                            shape = RectangleShape
                        )
                        .background(if (isSelected) OxfordInk else Paper)
                        .clickable { onFilterChange(classification) }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                        .testTag("filter_${classification.name}")
                ) {
                    Text(
                        text = classification.label,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 10.sp,
                        letterSpacing = 0.8.sp,
                        color = if (isSelected) WarmWhite else OxfordInk
                    )
                }
            }
        }

        // Secondary computational filters strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(width = 0.5.dp, color = Stone)
                .horizontalScroll(secondaryFilterScroll)
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val tags = listOf("GEOMETRIC", "HUMANIST", "INDUSTRIAL", "EDITORIAL", "LUXURY", "TECHNICAL", "VARIABLE")
            for (t in tags) {
                Text(
                    text = "#$t",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = Graphite,
                    modifier = Modifier.clickable { onSearchChange(t.lowercase()) }
                )
            }
        }

        // Live Pangram Tester Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(WarmWhite)
                .border(width = 0.5.dp, color = Stone)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "PREVIEW:",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = Graphite,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedTextField(
                value = previewPangram,
                onValueChange = { previewPangram = it },
                singleLine = true,
                shape = RectangleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent
                ),
                textStyle = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 12.sp,
                    color = OxfordInk
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("foundry_preview_input")
            )
        }

        // Typeface Catalogue List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(filteredList) { tf ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Stone, RectangleShape)
                        .background(WarmWhite)
                        .clickable {
                            onSelectTypeface(tf)
                            onNavigate(Screen.FONT_DETAIL)
                        }
                        .padding(18.dp)
                        .testTag("font_card_${tf.code}")
                ) {
                    // Top Card metadata
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = tf.code,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MutedRed
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${tf.classificationLabel} · £${tf.basePriceGbp}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = Graphite
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Large Typeface Name & Aa
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = tf.name,
                                fontFamily = if (tf.classification == Classification.SERIF) FontFamily.Serif else FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 28.sp,
                                letterSpacing = (-0.5).sp,
                                color = OxfordInk
                            )
                            Text(
                                text = tf.subtitle,
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 12.sp,
                                color = Graphite
                            )
                        }
                        Text(
                            text = "Aa",
                            fontFamily = if (tf.classification == Classification.SERIF) FontFamily.Serif else FontFamily.SansSerif,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Light,
                            color = OxfordInk
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = Stone.copy(alpha = 0.5f), thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Live custom text specimen
                    Text(
                        text = if (previewPangram.isNotEmpty()) previewPangram else tf.pangram,
                        fontFamily = if (tf.classification == Classification.SERIF) FontFamily.Serif else if (tf.classification == Classification.MONO) FontFamily.Monospace else FontFamily.SansSerif,
                        fontSize = 15.sp,
                        lineHeight = 20.sp,
                        color = OxfordInk
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "0123456789 · THE FUTURE IS COMPUTED",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = Graphite,
                        letterSpacing = 0.5.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "GEOM ${tf.scores.geometric}% · CONTRAST ${tf.scores.contrast}%",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = Graphite
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "VIEW TYPEFACE",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                letterSpacing = 0.8.sp,
                                color = OxfordBlue
                            )
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = OxfordBlue,
                                modifier = Modifier.height(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
