package com.example.typeforge.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun BespokeScreen(
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var companyName by remember { mutableStateOf("") }
    var contactName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var brief by remember { mutableStateOf("") }
    var isSubmitted by remember { mutableStateOf(false) }

    val flowSteps = listOf(
        "01. BRIEF" to "Define brand character, global linguistic scope, and optical targets",
        "02. DESIGN DIRECTION" to "Computational synthesis of 4 distinct seed type systems",
        "03. GENERATION" to "Expansion to full 700+ glyph OpenType matrix and variable axes",
        "04. ART DIRECTION" to "Bespoke manual review by senior Oxford type designers",
        "05. REVISION" to "Iterative curve balance and bespoke numeral systems",
        "06. FINAL FAMILY" to "Enterprise sign-off, legal warranty, and binary mastering",
        "07. LICENCE" to "Worldwide unrestricted perpetual enterprise deployment"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Text(
                text = "BESPOKE COMMISSION",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                letterSpacing = 1.2.sp,
                color = MutedRed
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "YOUR COMPANY.\nYOUR TYPE SYSTEM.",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                lineHeight = 32.sp,
                letterSpacing = (-0.5).sp,
                color = OxfordInk,
                modifier = Modifier.testTag("bespoke_screen_title")
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "End-to-end custom typeface design for architecture, mobility, and corporate identity.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 13.sp,
                color = Graphite
            )
        }

        // Flow diagram
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, Stone, RectangleShape)
                .background(WarmWhite)
                .padding(16.dp)
        ) {
            Text(
                text = "THE BESPOKE PROCESS:",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                letterSpacing = 0.8.sp,
                color = OxfordInk
            )
            Spacer(modifier = Modifier.height(10.dp))

            for ((step, desc) in flowSteps) {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    Text(
                        text = step,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = OxfordInk
                    )
                    Text(
                        text = desc,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp,
                        color = Graphite
                    )
                }
                HorizontalDivider(color = Stone.copy(alpha = 0.3f), thickness = 0.5.dp)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Enquiry Form
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, OxfordInk, RectangleShape)
                .background(WarmWhite)
                .padding(18.dp)
        ) {
            Text(
                text = "INITIATE COMMISSION ENQUIRY",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                letterSpacing = 1.0.sp,
                color = OxfordInk
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text("ORGANISATION / BRAND:", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Graphite)
            OutlinedTextField(
                value = companyName,
                onValueChange = { companyName = it },
                singleLine = true,
                shape = RectangleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OxfordInk,
                    unfocusedBorderColor = Stone,
                    focusedContainerColor = Paper,
                    unfocusedContainerColor = Paper
                ),
                modifier = Modifier.fillMaxWidth().height(46.dp).testTag("bespoke_company_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text("CONTACT NAME & TITLE:", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Graphite)
            OutlinedTextField(
                value = contactName,
                onValueChange = { contactName = it },
                singleLine = true,
                shape = RectangleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OxfordInk,
                    unfocusedBorderColor = Stone,
                    focusedContainerColor = Paper,
                    unfocusedContainerColor = Paper
                ),
                modifier = Modifier.fillMaxWidth().height(46.dp).testTag("bespoke_contact_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text("CORPORATE EMAIL:", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Graphite)
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                singleLine = true,
                shape = RectangleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OxfordInk,
                    unfocusedBorderColor = Stone,
                    focusedContainerColor = Paper,
                    unfocusedContainerColor = Paper
                ),
                modifier = Modifier.fillMaxWidth().height(46.dp).testTag("bespoke_email_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text("BRIEF SUMMARY & TIMELINE:", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Graphite)
            OutlinedTextField(
                value = brief,
                onValueChange = { brief = it },
                minLines = 3,
                shape = RectangleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OxfordInk,
                    unfocusedBorderColor = Stone,
                    focusedContainerColor = Paper,
                    unfocusedContainerColor = Paper
                ),
                modifier = Modifier.fillMaxWidth().testTag("bespoke_brief_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    isSubmitted = true
                    Toast.makeText(context, "Bespoke inquiry received. The Oxford studio will respond within 24 hours.", Toast.LENGTH_LONG).show()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = OxfordInk,
                    contentColor = WarmWhite
                ),
                shape = RectangleShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("submit_bespoke_inquiry_btn")
            ) {
                Text(
                    text = if (isSubmitted) "ENQUIRY SUBMITTED ✓" else "SUBMIT COMMISSION ENQUIRY →",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.0.sp
                )
            }
        }
    }
}
