package com.example.typeforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.model.JournalArticle
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun JournalScreen(
    articles: List<JournalArticle>,
    onSelectArticle: (JournalArticle) -> Unit,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Text(
                text = "THE JOURNAL",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                letterSpacing = (-0.5).sp,
                color = OxfordInk,
                modifier = Modifier.testTag("journal_screen_title")
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Essays on computational geometry, historical matrices, and modern type systems.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 13.sp,
                color = Graphite
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(articles) { article ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Stone, RectangleShape)
                        .background(WarmWhite)
                        .clickable { onSelectArticle(article) }
                        .padding(18.dp)
                        .testTag("article_${article.id}")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = article.date.uppercase(),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = MutedRed
                        )
                        Text(
                            text = article.readTime,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = Graphite
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = article.title,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        lineHeight = 24.sp,
                        color = OxfordInk
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = article.subtitle,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 12.sp,
                        color = Graphite
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = article.excerpt,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        color = OxfordInk.copy(alpha = 0.85f)
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Stone.copy(alpha = 0.4f), thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "BY ${article.author.uppercase()}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.sp,
                            color = Graphite
                        )
                        Text(
                            text = "READ ESSAY →",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            color = OxfordBlue
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun JournalDetailScreen(
    article: JournalArticle,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Back Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("journal_back_btn")) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = OxfordInk)
            }
            Text(
                text = "BACK TO JOURNAL",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                letterSpacing = 1.0.sp,
                color = OxfordInk
            )
        }

        // Article Content
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
        ) {
            Text(
                text = article.date.uppercase() + " · " + article.readTime,
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = MutedRed
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = article.title,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 32.sp,
                lineHeight = 36.sp,
                color = OxfordInk
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = article.subtitle,
                fontFamily = FontFamily.SansSerif,
                fontSize = 15.sp,
                lineHeight = 20.sp,
                color = Graphite
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "By ${article.author} · Oxford Typography Laboratory",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = OxfordBlue
            )

            Spacer(modifier = Modifier.height(18.dp))
            HorizontalDivider(color = OxfordInk, thickness = 1.dp)
            Spacer(modifier = Modifier.height(18.dp))

            for (p in article.content) {
                Text(
                    text = p,
                    fontFamily = FontFamily.Serif,
                    fontSize = 15.sp,
                    lineHeight = 24.sp,
                    color = OxfordInk
                )
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
