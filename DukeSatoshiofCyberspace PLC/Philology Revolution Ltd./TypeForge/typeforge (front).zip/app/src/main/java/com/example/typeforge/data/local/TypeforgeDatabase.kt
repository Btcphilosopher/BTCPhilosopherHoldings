package com.example.typeforge.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [TypefaceProjectEntity::class, OrderEntity::class],
    version = 1,
    exportSchema = false
)
abstract class TypeforgeDatabase : RoomDatabase() {
    abstract fun typeforgeDao(): TypeforgeDao

    companion object {
        @Volatile
        private var INSTANCE: TypeforgeDatabase? = null

        fun getDatabase(context: Context): TypeforgeDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TypeforgeDatabase::class.java,
                    "typeforge_foundry.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
