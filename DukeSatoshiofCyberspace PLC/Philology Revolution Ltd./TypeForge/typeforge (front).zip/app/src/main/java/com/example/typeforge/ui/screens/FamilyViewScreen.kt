package com.example.typeforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.model.Classification
import com.example.typeforge.model.Typeface
import com.example.typeforge.ui.components.MinimalRuleSlider
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun FamilyViewScreen(
    typeface: Typeface,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    var scrubWeight by remember { mutableFloatStateOf(500f) }

    val styles = listOf(
        "THIN" to (100 to FontWeight.Thin),
        "LIGHT" to (300 to FontWeight.Light),
        "REGULAR" to (400 to FontWeight.Normal),
        "MEDIUM" to (500 to FontWeight.Medium),
        "SEMIBOLD" to (600 to FontWeight.SemiBold),
        "BOLD" to (700 to FontWeight.Bold),
        "BLACK" to (900 to FontWeight.Black)
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FAMILY MASTERS",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Black,
                    fontSize = 28.sp,
                    letterSpacing = (-0.5).sp,
                    color = OxfordInk,
                    modifier = Modifier.testTag("family_view_title")
                )
                Text(
                    text = typeface.name.uppercase(),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = OxfordBlue
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "7 discrete optical masters and continuous variable interpolation scale.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 13.sp,
                color = Graphite
            )
        }

        // Continuous Interpolation Scrubber Box
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, OxfordInk, RectangleShape)
                .background(WarmWhite)
                .padding(18.dp)
        ) {
            Text(
                text = "CONTINUOUS WEIGHT INTERPOLATION",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                letterSpacing = 1.0.sp,
                color = OxfordInk
            )

            Spacer(modifier = Modifier.height(8.dp))

            MinimalRuleSlider(
                label = "wght · SCRUB WEIGHT",
                value = scrubWeight,
                range = 100f..900f,
                onValueChange = { scrubWeight = it }
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Oxford Engineering Systems",
                fontFamily = if (typeface.classification == Classification.SERIF) FontFamily.Serif else FontFamily.SansSerif,
                fontWeight = when {
                    scrubWeight < 250 -> FontWeight.Thin
                    scrubWeight < 350 -> FontWeight.Light
                    scrubWeight < 450 -> FontWeight.Normal
                    scrubWeight < 550 -> FontWeight.Medium
                    scrubWeight < 650 -> FontWeight.SemiBold
                    scrubWeight < 800 -> FontWeight.Bold
                    else -> FontWeight.Black
                },
                fontSize = 22.sp,
                color = OxfordInk
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Discrete Masters Rows
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            for ((label, data) in styles) {
                val (weightInt, fWeight) = data
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Stone, RectangleShape)
                        .background(WarmWhite)
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$label · $weightInt",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = Graphite,
                            letterSpacing = 0.8.sp
                        )
                        Text(
                            text = "${typeface.code}-$weightInt",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = Stone
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "The quick brown fox jumps over the lazy dog",
                        fontFamily = if (typeface.classification == Classification.SERIF) FontFamily.Serif else FontFamily.SansSerif,
                        fontWeight = fWeight,
                        fontSize = 16.sp,
                        lineHeight = 22.sp,
                        color = OxfordInk
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "0123456789 · ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = Graphite
                    )
                }
            }
        }
    }
}
