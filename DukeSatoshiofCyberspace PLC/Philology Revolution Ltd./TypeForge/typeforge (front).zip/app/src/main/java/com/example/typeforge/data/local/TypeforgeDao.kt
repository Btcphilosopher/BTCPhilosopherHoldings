package com.example.typeforge.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TypeforgeDao {
    @Query("SELECT * FROM typeface_projects ORDER BY createdAt DESC")
    fun getAllProjects(): Flow<List<TypefaceProjectEntity>>

    @Query("SELECT * FROM typeface_projects WHERE id = :id")
    suspend fun getProjectById(id: String): TypefaceProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: TypefaceProjectEntity)

    @Update
    suspend fun updateProject(project: TypefaceProjectEntity)

    @Query("DELETE FROM typeface_projects WHERE id = :id")
    suspend fun deleteProject(id: String)

    @Query("SELECT * FROM orders ORDER BY timestamp DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)
}
