package com.example.typeforge.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

data class DrawerMenuItem(
    val section: String,
    val screen: Screen,
    val description: String,
    val code: String
)

@Composable
fun TypeforgeDrawerContent(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val items = listOf(
        DrawerMenuItem("01. FOUNDRY", Screen.FOUNDRY, "Commercial generative font catalogue", "TF-FONTS"),
        DrawerMenuItem("02. GENERATE", Screen.GENERATE, "Computational type engine studio", "TF-GEN"),
        DrawerMenuItem("03. COMPARE", Screen.COMPARE, "Side-by-side synchronized evaluation", "TF-CMP"),
        DrawerMenuItem("04. REFINE", Screen.REFINE, "Parametric tuning & glyph geometry", "TF-RFN"),
        DrawerMenuItem("05. WORDMARK", Screen.WORDMARK, "Company identity & casing preview", "TF-WRD"),
        DrawerMenuItem("06. BRAND PREVIEW", Screen.BRAND_PREVIEW, "Editorial, signage, packaging mockups", "TF-BND"),
        DrawerMenuItem("07. GLYPH INSPECTOR", Screen.GLYPH_INSPECTOR, "Vector curves, Unicode & contours", "TF-GLY"),
        DrawerMenuItem("08. FAMILY VIEW", Screen.FAMILY_VIEW, "Continuous weight interpolation scale", "TF-FAM"),
        DrawerMenuItem("09. LICENSING", Screen.LICENSING, "Commercial tiers & SaaS checkout", "TF-LIC"),
        DrawerMenuItem("10. DOWNLOADS", Screen.DOWNLOADS, "OTF, TTF, WOFF2 & Specimen packages", "TF-DLN"),
        DrawerMenuItem("11. ACCOUNT & PROJECTS", Screen.ACCOUNT, "Workspaces, versions & team", "TF-ACC"),
        DrawerMenuItem("12. ADMIN ENGINE", Screen.ADMIN_MONITOR, "Computational lab & latent vector monitor", "TF-ADM"),
        DrawerMenuItem("13. JOURNAL", Screen.JOURNAL, "Oxford computational typography essays", "TF-JRN"),
        DrawerMenuItem("14. BESPOKE SERVICE", Screen.BESPOKE, "Custom enterprise type systems", "TF-BSP")
    )

    ModalDrawerSheet(
        drawerShape = RectangleShape,
        drawerContainerColor = Paper,
        modifier = modifier
            .width(320.dp)
            .fillMaxHeight()
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TYPEFORGE",
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        letterSpacing = 2.0.sp,
                        color = OxfordInk
                    )
                    Text(
                        text = "OXFORD TYPE FOUNDRY · SaaS",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        letterSpacing = 1.0.sp,
                        color = Graphite
                    )
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier.testTag("drawer_close_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Menu",
                        tint = OxfordInk
                    )
                }
            }

            HorizontalDivider(color = Stone, thickness = 0.5.dp)

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                items(items) { item ->
                    val isSelected = currentScreen == item.screen
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onNavigate(item.screen)
                                onClose()
                            }
                            .background(if (isSelected) PaperDark else Paper)
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = item.section,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 12.sp,
                                    letterSpacing = 1.0.sp,
                                    color = OxfordInk
                                )
                                if (isSelected) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "●",
                                        color = OxfordInk,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                            Text(
                                text = item.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = Graphite,
                                fontSize = 11.sp
                            )
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = if (isSelected) OxfordInk else Stone,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    HorizontalDivider(color = Stone.copy(alpha = 0.4f), thickness = 0.5.dp)
                }
            }

            // Footer note
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PaperDark)
                    .padding(16.dp)
            ) {
                Text(
                    text = "FOUNDED IN OXFORD · 5 PEOPLE · 1 TYPE ENGINE",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    color = OxfordInk,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Made in Oxford. Built for everywhere.",
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 10.sp,
                    color = Graphite
                )
            }
        }
    }
}
