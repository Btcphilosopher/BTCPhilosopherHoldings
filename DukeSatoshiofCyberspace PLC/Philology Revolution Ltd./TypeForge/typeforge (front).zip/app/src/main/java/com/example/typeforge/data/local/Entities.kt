package com.example.typeforge.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "typeface_projects")
data class TypefaceProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val clientOrBrand: String,
    val brief: String,
    val classification: String,
    val status: String,
    val createdAt: String,
    val currentVersion: String,
    val selectedCandidateId: String?,
    val weight: Float,
    val width: Float,
    val contrast: Float,
    val geometricScore: Float,
    val xHeight: Float,
    val licensePurchased: String?
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val id: String,
    val orderNumber: String,
    val typefaceId: String,
    val typefaceName: String,
    val licenseType: String,
    val tier: String,
    val totalGbp: Int,
    val customerName: String,
    val customerEmail: String,
    val companyName: String,
    val vatNumber: String,
    val timestamp: String,
    val downloadToken: String,
    val licenseKey: String
)
