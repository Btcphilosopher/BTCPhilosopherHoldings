package com.example.typeforge.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.typeforge.data.DefaultCatalogue
import com.example.typeforge.data.JournalData
import com.example.typeforge.data.local.OrderEntity
import com.example.typeforge.data.local.TypeforgeDao
import com.example.typeforge.data.local.TypeforgeDatabase
import com.example.typeforge.data.local.TypefaceProjectEntity
import com.example.typeforge.engine.ComputationalTypeEngine
import com.example.typeforge.model.Classification
import com.example.typeforge.model.EngineMetric
import com.example.typeforge.model.FontAxis
import com.example.typeforge.model.GenerationCandidate
import com.example.typeforge.model.GenerationJob
import com.example.typeforge.model.GlyphMetric
import com.example.typeforge.model.JournalArticle
import com.example.typeforge.model.LicenseType
import com.example.typeforge.model.Order
import com.example.typeforge.model.PricingTier
import com.example.typeforge.model.ProjectStatus
import com.example.typeforge.model.ProjectVersion
import com.example.typeforge.model.TeamMember
import com.example.typeforge.model.TeamRole
import com.example.typeforge.model.Typeface
import com.example.typeforge.model.TypefaceProject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class Screen {
    LANDING,
    FOUNDRY,
    FONT_DETAIL,
    GENERATE,
    COMPARE,
    REFINE,
    WORDMARK,
    BRAND_PREVIEW,
    GLYPH_INSPECTOR,
    FAMILY_VIEW,
    LICENSING,
    DOWNLOADS,
    ACCOUNT,
    ADMIN_MONITOR,
    JOURNAL,
    JOURNAL_DETAIL,
    BESPOKE
}

enum class WordmarkCasing {
    UPPERCASE,
    TITLECASE,
    LOWERCASE,
    SPACED
}

data class TypeforgeUiState(
    val currentScreen: Screen = Screen.LANDING,
    val previousScreens: List<Screen> = emptyList(),
    val catalogue: List<Typeface> = DefaultCatalogue.typefaces,
    val selectedFilter: Classification = Classification.ALL,
    val searchQuery: String = "",
    val selectedTypeface: Typeface = DefaultCatalogue.typefaces[0],

    // Generation state
    val generationPrompt: String = "A sophisticated British engineering typeface, precise but human, slightly geometric, excellent numerals and strong signage performance.",
    val selectedClassification: Classification = Classification.SANS,
    val isGenerating: Boolean = false,
    val activeJob: GenerationJob? = null,
    val candidates: List<GenerationCandidate> = ComputationalTypeEngine.createInitialCandidates(
        "A sophisticated British engineering typeface, precise but human",
        Classification.SANS
    ),
    val selectedCandidate: GenerationCandidate = ComputationalTypeEngine.createInitialCandidates(
        "A sophisticated British engineering typeface, precise but human",
        Classification.SANS
    )[2], // Default to Candidate 03 (Northstar)
    val comparisonSelectedIds: Set<String> = setOf("cand-01", "cand-03"),

    // Refinement parameters
    val refineWeight: Float = 520f,
    val refineWidth: Float = 100f,
    val refineContrast: Float = 16f,
    val refineCurvature: Float = 0.60f,
    val refineGeometric: Float = 74f,
    val refineHumanist: Float = 58f,
    val refineIndustrial: Float = 84f,
    val refineEditorial: Float = 68f,
    val refineXHeight: Float = 0.55f,
    val refineSerifLength: Float = 0f,
    val refineTracking: Float = 0f,
    val refineLineHeight: Float = 1.3f,

    // Glyph Inspection & Specific Refinement
    val selectedGlyph: GlyphMetric = DefaultCatalogue.typefaces[0].glyphs.first { it.char == 'R' },
    val glyphPrompt: String = "",
    val glyphRefinements: Map<Char, String> = mapOf('R' to "Flared dynamic leg with architectural terminal"),

    // Interactive Specimen Text & Wordmark
    val customSpecimenText: String = "OXFORD ENGINEERING & COMPUTATIONAL FOUNDRY",
    val wordmarkInput: String = "NORTHSTAR",
    val wordmarkCasing: WordmarkCasing = WordmarkCasing.UPPERCASE,

    // Active Project & Versioning
    val activeProject: TypefaceProject = TypefaceProject(
        id = "proj-northstar-01",
        name = "Northstar",
        clientOrBrand = "Northstar Engineering Ltd",
        brief = "A sophisticated British engineering company needs a new corporate typeface. Precise, human, technical, confident, highly legible.",
        classification = Classification.SANS,
        status = ProjectStatus.FINALIZED,
        createdAt = "26 Sep 2026",
        currentVersion = "v1.0",
        versions = listOf(
            ProjectVersion("v0.1", "26 Sep 2026, 10:14", "Initial geometric seed generation", 400f, 100f, 10f, 85f, 0.50f),
            ProjectVersion("v0.2", "26 Sep 2026, 14:30", "Harmonised numerals and expanded leg curve on 'R'", 480f, 98f, 14f, 78f, 0.54f),
            ProjectVersion("v1.0", "27 Sep 2026, 09:45", "Production master balance & OpenType kerning", 520f, 100f, 16f, 74f, 0.55f)
        ),
        selectedCandidateId = "cand-03",
        weight = 520f,
        width = 100f,
        contrast = 16f,
        geometricScore = 74f,
        xHeight = 0.55f,
        licensePurchased = PricingTier.STUDIO
    ),
    val userProjects: List<TypefaceProject> = emptyList(),

    // Licensing & Checkout
    val selectedPricingTier: PricingTier = PricingTier.STUDIO,
    val selectedLicenseType: LicenseType = LicenseType.DESKTOP,
    val customerName: String = "Arthur Pendelton",
    val customerEmail: String = "arthur@oxford-systems.co.uk",
    val customerCompany: String = "Northstar Technologies",
    val recentOrder: Order? = null,
    val orders: List<Order> = emptyList(),
    val isCheckoutComplete: Boolean = false,
    val showExportDialog: Boolean = false,

    // Journal & Admin
    val journalArticles: List<JournalArticle> = JournalData.articles,
    val selectedArticle: JournalArticle = JournalData.articles[0],
    val engineMetrics: EngineMetric = EngineMetric(),

    // Team members
    val teamMembers: List<TeamMember> = listOf(
        TeamMember("tm-1", "Arthur Pendelton", "a.pendelton@typeforge.ox.ac.uk", TeamRole.OWNER, 'A'),
        TeamMember("tm-2", "Eleanor Finch", "e.finch@typeforge.ox.ac.uk", TeamRole.DESIGNER, 'E'),
        TeamMember("tm-3", "Henry Sterling", "h.sterling@typeforge.ox.ac.uk", TeamRole.DESIGNER, 'H'),
        TeamMember("tm-4", "Marcus Vance", "m.vance@typeforge.ox.ac.uk", TeamRole.ADMIN, 'M'),
        TeamMember("tm-5", "Sarah Bradley", "s.bradley@typeforge.ox.ac.uk", TeamRole.VIEWER, 'S')
    )
)

class TypeforgeViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TypeforgeDatabase.getDatabase(application)
    private val dao = db.typeforgeDao()

    private val _uiState = MutableStateFlow(TypeforgeUiState())
    val uiState: StateFlow<TypeforgeUiState> = _uiState.asStateFlow()

    init {
        loadProjectsFromDb()
        loadOrdersFromDb()
    }

    private fun loadProjectsFromDb() {
        viewModelScope.launch {
            dao.getAllProjects().collectLatest { entities: List<TypefaceProjectEntity> ->
                if (entities.isNotEmpty()) {
                    val projects = entities.map { entity ->
                        TypefaceProject(
                            id = entity.id,
                            name = entity.name,
                            clientOrBrand = entity.clientOrBrand,
                            brief = entity.brief,
                            classification = runCatching { Classification.valueOf(entity.classification) }.getOrDefault(Classification.SANS),
                            status = runCatching { ProjectStatus.valueOf(entity.status) }.getOrDefault(ProjectStatus.DRAFT),
                            createdAt = entity.createdAt,
                            currentVersion = entity.currentVersion,
                            versions = listOf(
                                ProjectVersion(entity.currentVersion, entity.createdAt, "Current saved checkpoint", entity.weight, entity.width, entity.contrast, entity.geometricScore, entity.xHeight)
                            ),
                            selectedCandidateId = entity.selectedCandidateId,
                            weight = entity.weight,
                            width = entity.width,
                            contrast = entity.contrast,
                            geometricScore = entity.geometricScore,
                            xHeight = entity.xHeight,
                            licensePurchased = entity.licensePurchased?.let { tierName: String ->
                                runCatching { PricingTier.valueOf(tierName) }.getOrNull()
                            }
                        )
                    }
                    _uiState.value = _uiState.value.copy(userProjects = projects)
                } else {
                    // Seed initial demo project
                    val defaultProj = _uiState.value.activeProject
                    val initialEntity = TypefaceProjectEntity(
                        id = defaultProj.id,
                        name = defaultProj.name,
                        clientOrBrand = defaultProj.clientOrBrand,
                        brief = defaultProj.brief,
                        classification = defaultProj.classification.name,
                        status = defaultProj.status.name,
                        createdAt = defaultProj.createdAt,
                        currentVersion = defaultProj.currentVersion,
                        selectedCandidateId = defaultProj.selectedCandidateId,
                        weight = defaultProj.weight,
                        width = defaultProj.width,
                        contrast = defaultProj.contrast,
                        geometricScore = defaultProj.geometricScore,
                        xHeight = defaultProj.xHeight,
                        licensePurchased = defaultProj.licensePurchased?.name
                    )
                    dao.insertProject(initialEntity)
                    _uiState.value = _uiState.value.copy(userProjects = listOf(defaultProj))
                }
            }
        }
    }

    private fun loadOrdersFromDb() {
        viewModelScope.launch {
            dao.getAllOrders().collectLatest { entities: List<OrderEntity> ->
                val list = entities.map { entity ->
                    Order(
                        id = entity.id,
                        orderNumber = entity.orderNumber,
                        typefaceId = entity.typefaceId,
                        typefaceName = entity.typefaceName,
                        licenseType = runCatching { LicenseType.valueOf(entity.licenseType) }.getOrDefault(LicenseType.DESKTOP),
                        tier = runCatching { PricingTier.valueOf(entity.tier) }.getOrDefault(PricingTier.STUDIO),
                        totalGbp = entity.totalGbp,
                        customerName = entity.customerName,
                        customerEmail = entity.customerEmail,
                        companyName = entity.companyName,
                        vatNumber = entity.vatNumber,
                        timestamp = entity.timestamp,
                        downloadToken = entity.downloadToken,
                        licenseKey = entity.licenseKey
                    )
                }
                _uiState.value = _uiState.value.copy(orders = list)
            }
        }
    }

    fun navigateTo(screen: Screen) {
        if (_uiState.value.currentScreen == screen) return
        val updatedHistory = _uiState.value.previousScreens + _uiState.value.currentScreen
        _uiState.value = _uiState.value.copy(
            currentScreen = screen,
            previousScreens = updatedHistory
        )
    }

    fun navigateBack(): Boolean {
        val history = _uiState.value.previousScreens
        if (history.isNotEmpty()) {
            val prev = history.last()
            _uiState.value = _uiState.value.copy(
                currentScreen = prev,
                previousScreens = history.dropLast(1)
            )
            return true
        }
        return false
    }

    fun setFilter(classification: Classification) {
        _uiState.value = _uiState.value.copy(selectedFilter = classification)
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun selectTypeface(typeface: Typeface) {
        _uiState.value = _uiState.value.copy(
            selectedTypeface = typeface,
            refineWeight = typeface.axes.find { it.tag == "wght" }?.currentValue ?: 400f,
            refineWidth = typeface.axes.find { it.tag == "wdth" }?.currentValue ?: 100f,
            refineContrast = typeface.scores.contrast.toFloat(),
            refineGeometric = typeface.scores.geometric.toFloat(),
            refineHumanist = typeface.scores.humanist.toFloat()
        )
        navigateTo(Screen.FONT_DETAIL)
    }

    fun setGenerationPrompt(prompt: String) {
        _uiState.value = _uiState.value.copy(generationPrompt = prompt)
    }

    fun setGenerationClassification(classification: Classification) {
        _uiState.value = _uiState.value.copy(selectedClassification = classification)
    }

    fun startGeneration() {
        val prompt = _uiState.value.generationPrompt
        val classification = _uiState.value.selectedClassification
        _uiState.value = _uiState.value.copy(isGenerating = true)

        viewModelScope.launch {
            ComputationalTypeEngine.runGenerationPipeline(prompt, classification).collect { job ->
                _uiState.value = _uiState.value.copy(
                    activeJob = job,
                    candidates = if (job.candidates.isNotEmpty()) job.candidates else _uiState.value.candidates,
                    isGenerating = !job.isFinished
                )
                if (job.isFinished && job.candidates.isNotEmpty()) {
                    _uiState.value = _uiState.value.copy(
                        selectedCandidate = job.candidates.firstOrNull { it.codeNumber == "OPTION 03" } ?: job.candidates[0]
                    )
                }
            }
        }
    }

    fun selectCandidate(candidate: GenerationCandidate) {
        _uiState.value = _uiState.value.copy(
            selectedCandidate = candidate,
            refineWeight = candidate.weight,
            refineWidth = candidate.width,
            refineContrast = candidate.contrast,
            refineGeometric = candidate.scores.geometric.toFloat(),
            refineHumanist = candidate.scores.humanist.toFloat(),
            refineIndustrial = candidate.scores.industrial.toFloat(),
            refineEditorial = candidate.scores.editorial.toFloat(),
            refineCurvature = candidate.curvature,
            refineXHeight = candidate.xHeightRatio,
            refineSerifLength = candidate.serifLength
        )
    }

    fun toggleComparisonCandidate(candidateId: String) {
        val current = _uiState.value.comparisonSelectedIds.toMutableSet()
        if (current.contains(candidateId)) {
            if (current.size > 1) {
                current.remove(candidateId)
            }
        } else {
            current.add(candidateId)
        }
        _uiState.value = _uiState.value.copy(comparisonSelectedIds = current)
    }

    fun updateRefineParameter(
        weight: Float = _uiState.value.refineWeight,
        width: Float = _uiState.value.refineWidth,
        contrast: Float = _uiState.value.refineContrast,
        geometric: Float = _uiState.value.refineGeometric,
        humanist: Float = _uiState.value.refineHumanist,
        industrial: Float = _uiState.value.refineIndustrial,
        editorial: Float = _uiState.value.refineEditorial,
        curvature: Float = _uiState.value.refineCurvature,
        xHeight: Float = _uiState.value.refineXHeight,
        serifLength: Float = _uiState.value.refineSerifLength,
        tracking: Float = _uiState.value.refineTracking,
        lineHeight: Float = _uiState.value.refineLineHeight
    ) {
        _uiState.value = _uiState.value.copy(
            refineWeight = weight,
            refineWidth = width,
            refineContrast = contrast,
            refineGeometric = geometric,
            refineHumanist = humanist,
            refineIndustrial = industrial,
            refineEditorial = editorial,
            refineCurvature = curvature,
            refineXHeight = xHeight,
            refineSerifLength = serifLength,
            refineTracking = tracking,
            refineLineHeight = lineHeight
        )
    }

    fun selectGlyph(glyph: GlyphMetric) {
        _uiState.value = _uiState.value.copy(selectedGlyph = glyph)
    }

    fun setGlyphPrompt(prompt: String) {
        _uiState.value = _uiState.value.copy(glyphPrompt = prompt)
    }

    fun submitGlyphRefinement() {
        val char = _uiState.value.selectedGlyph.char
        val prompt = _uiState.value.glyphPrompt.trim()
        if (prompt.isNotEmpty()) {
            val map = _uiState.value.glyphRefinements.toMutableMap()
            map[char] = prompt
            _uiState.value = _uiState.value.copy(
                glyphRefinements = map,
                glyphPrompt = ""
            )
        }
    }

    fun setCustomSpecimenText(text: String) {
        _uiState.value = _uiState.value.copy(customSpecimenText = text)
    }

    fun setWordmarkInput(text: String) {
        _uiState.value = _uiState.value.copy(wordmarkInput = text)
    }

    fun setWordmarkCasing(casing: WordmarkCasing) {
        _uiState.value = _uiState.value.copy(wordmarkCasing = casing)
    }

    fun selectPricingTier(tier: PricingTier) {
        _uiState.value = _uiState.value.copy(selectedPricingTier = tier)
    }

    fun selectLicenseType(type: LicenseType) {
        _uiState.value = _uiState.value.copy(selectedLicenseType = type)
    }

    fun updateCustomerInfo(name: String, email: String, company: String) {
        _uiState.value = _uiState.value.copy(
            customerName = name,
            customerEmail = email,
            customerCompany = company
        )
    }

    fun processCheckout() {
        val state = _uiState.value
        val now = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.UK).format(Date())
        val orderNumber = "TF-${(100000..999999).random()}"
        val token = "dln_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val key = "TYPEFORGE-LIC-${UUID.randomUUID().toString().take(8).uppercase()}-${state.selectedPricingTier.name}"

        val order = Order(
            id = "ord-${UUID.randomUUID().toString().take(8)}",
            orderNumber = orderNumber,
            typefaceId = state.selectedTypeface.id,
            typefaceName = if (state.activeProject.name.isNotEmpty()) state.activeProject.name else state.selectedTypeface.name,
            licenseType = state.selectedLicenseType,
            tier = state.selectedPricingTier,
            totalGbp = state.selectedPricingTier.priceGbp,
            customerName = state.customerName.ifEmpty { "Oxford Client" },
            customerEmail = state.customerEmail.ifEmpty { "client@oxford.co.uk" },
            companyName = state.customerCompany.ifEmpty { "Oxford Studio" },
            timestamp = now,
            downloadToken = token,
            licenseKey = key
        )

        viewModelScope.launch {
            dao.insertOrder(
                OrderEntity(
                    id = order.id,
                    orderNumber = order.orderNumber,
                    typefaceId = order.typefaceId,
                    typefaceName = order.typefaceName,
                    licenseType = order.licenseType.name,
                    tier = order.tier.name,
                    totalGbp = order.totalGbp,
                    customerName = order.customerName,
                    customerEmail = order.customerEmail,
                    companyName = order.companyName,
                    vatNumber = "GB-394821948",
                    timestamp = order.timestamp,
                    downloadToken = order.downloadToken,
                    licenseKey = order.licenseKey
                )
            )
        }

        _uiState.value = _uiState.value.copy(
            recentOrder = order,
            isCheckoutComplete = true
        )
        navigateTo(Screen.DOWNLOADS)
    }

    fun saveProjectVersion(note: String) {
        val state = _uiState.value
        val currentVersions = state.activeProject.versions
        val nextVersionNum = "v1.${currentVersions.size}"
        val dateStr = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.UK).format(Date())

        val newVersion = ProjectVersion(
            versionNumber = nextVersionNum,
            timestamp = dateStr,
            note = note.ifEmpty { "Parametric geometry checkpoint" },
            weightVal = state.refineWeight,
            widthVal = state.refineWidth,
            contrastVal = state.refineContrast,
            geometricVal = state.refineGeometric,
            xHeightVal = state.refineXHeight
        )

        val updatedProject = state.activeProject.copy(
            currentVersion = nextVersionNum,
            versions = currentVersions + newVersion,
            weight = state.refineWeight,
            width = state.refineWidth,
            contrast = state.refineContrast,
            geometricScore = state.refineGeometric,
            xHeight = state.refineXHeight
        )

        viewModelScope.launch {
            dao.insertProject(
                TypefaceProjectEntity(
                    id = updatedProject.id,
                    name = updatedProject.name,
                    clientOrBrand = updatedProject.clientOrBrand,
                    brief = updatedProject.brief,
                    classification = updatedProject.classification.name,
                    status = updatedProject.status.name,
                    createdAt = updatedProject.createdAt,
                    currentVersion = updatedProject.currentVersion,
                    selectedCandidateId = updatedProject.selectedCandidateId,
                    weight = updatedProject.weight,
                    width = updatedProject.width,
                    contrast = updatedProject.contrast,
                    geometricScore = updatedProject.geometricScore,
                    xHeight = updatedProject.xHeight,
                    licensePurchased = updatedProject.licensePurchased?.name
                )
            )
        }

        _uiState.value = _uiState.value.copy(activeProject = updatedProject)
    }

    fun restoreVersion(version: ProjectVersion) {
        _uiState.value = _uiState.value.copy(
            refineWeight = version.weightVal,
            refineWidth = version.widthVal,
            refineContrast = version.contrastVal,
            refineGeometric = version.geometricVal,
            refineXHeight = version.xHeightVal
        )
    }

    fun selectArticle(article: JournalArticle) {
        _uiState.value = _uiState.value.copy(selectedArticle = article)
        navigateTo(Screen.JOURNAL_DETAIL)
    }

    fun setShowExportDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showExportDialog = show)
    }
}
