package com.example.typeforge.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.model.Order
import com.example.typeforge.ui.components.ExportDialog
import com.example.typeforge.viewmodel.Screen
import com.example.ui.theme.Graphite
import com.example.ui.theme.MutedRed
import com.example.ui.theme.OxfordBlue
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun DownloadCentreScreen(
    order: Order?,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scrollState = rememberScrollState()

    var showDialog by remember { mutableStateOf(false) }

    val currentOrder = order ?: Order(
        id = "ord-demo-01",
        orderNumber = "TF-892104",
        typefaceId = "tf-009",
        typefaceName = "Northstar",
        licenseType = com.example.typeforge.model.LicenseType.DESKTOP,
        tier = com.example.typeforge.model.PricingTier.STUDIO,
        totalGbp = 249,
        customerName = "Arthur Pendelton",
        customerEmail = "arthur@oxford-systems.co.uk",
        companyName = "Northstar Technologies",
        vatNumber = "GB-394821948",
        timestamp = "27 Sep 2026, 11:30",
        downloadToken = "dln_8f3a9e2c410b98",
        licenseKey = "TYPEFORGE-LIC-892104-STUDIO"
    )

    if (showDialog) {
        ExportDialog(
            typefaceName = currentOrder.typefaceName,
            onDismiss = { showDialog = false }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Success Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Text(
                text = "YOUR TYPEFACE IS READY.",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                letterSpacing = (-0.5).sp,
                color = OxfordInk,
                modifier = Modifier.testTag("download_screen_title")
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Complete production bundle compiled and cryptographically signed.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 13.sp,
                color = Graphite
            )
        }

        // Order Entitlement Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, OxfordInk, RectangleShape)
                .background(WarmWhite)
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ENTITLEMENT RECORD · ${currentOrder.orderNumber}",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = MutedRed,
                    letterSpacing = 1.0.sp
                )
                Text(
                    text = "STATUS: LICENSED ✓",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp,
                    color = OxfordBlue
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "${currentOrder.typefaceName.uppercase()} — ${currentOrder.tier.title} Licence",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 20.sp,
                color = OxfordInk
            )

            Spacer(modifier = Modifier.height(6.dp))

            val details = listOf(
                "LICENSEE" to "${currentOrder.customerName} (${currentOrder.companyName})",
                "LICENSE KEY" to currentOrder.licenseKey,
                "DOWNLOAD TOKEN" to currentOrder.downloadToken,
                "ISSUED" to currentOrder.timestamp
            )

            for ((k, v) in details) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = k, fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Graphite)
                    Text(text = v, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 9.sp, color = OxfordInk)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Downloadable Packages List
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .background(PaperDark)
                .padding(16.dp)
        ) {
            Text(
                text = "DOWNLOAD ENTITLEMENTS (CLICK TO DOWNLOAD INDIVIDUAL FILES):",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                color = OxfordInk,
                letterSpacing = 0.8.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            val files = listOf(
                "OTF" to "OpenType PostScript binaries (7 master weights)",
                "TTF" to "TrueType static masters for print & Windows",
                "WOFF" to "Legacy Web Open Font Format (Self-hosted)",
                "WOFF2" to "Modern Brotli-compressed WOFF2 binary",
                "VARIABLE FONT" to "Single TTF container with wght, wdth, opsz axes",
                "LICENSE CERTIFICATE" to "Cryptographically signed legal warranty certificate",
                "SPECIMEN PDF" to "High-resolution 32-page specimen proof book",
                "JSON METRICS" to "Complete OpenType UPM & kerning data manifest"
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((ext, desc) in files) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Stone, RectangleShape)
                            .background(WarmWhite)
                            .clickable {
                                Toast.makeText(context, "Downloaded $ext binary for ${currentOrder.typefaceName}", Toast.LENGTH_SHORT).show()
                            }
                            .padding(12.dp)
                            .testTag("download_item_$ext"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = ext,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = OxfordInk
                            )
                            Text(
                                text = desc,
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 10.sp,
                                color = Graphite
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            tint = OxfordInk,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { showDialog = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = OxfordInk,
                    contentColor = WarmWhite
                ),
                shape = RectangleShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("download_all_zip_btn")
            ) {
                Text(
                    text = "DOWNLOAD ALL (.ZIP BUNDLE) ↓",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.0.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Next Actions
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { onNavigate(Screen.ACCOUNT) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = PaperDark,
                    contentColor = OxfordInk
                ),
                shape = RectangleShape,
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .border(1.dp, OxfordInk, RectangleShape)
                    .testTag("to_my_typefaces_btn")
            ) {
                Text(
                    text = "MY TYPEFACES →",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    letterSpacing = 0.8.sp
                )
            }

            OutlinedButton(
                onClick = { onNavigate(Screen.GENERATE) },
                shape = RectangleShape,
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .border(1.dp, OxfordInk, RectangleShape)
            ) {
                Text(
                    text = "+ CREATE ANOTHER",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = OxfordInk
                )
            }
        }
    }
}
