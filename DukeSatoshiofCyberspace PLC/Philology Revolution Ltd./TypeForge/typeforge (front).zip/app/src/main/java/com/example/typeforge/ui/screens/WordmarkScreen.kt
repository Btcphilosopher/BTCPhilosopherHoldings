package com.example.typeforge.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.typeforge.ui.components.MinimalRuleSlider
import com.example.typeforge.viewmodel.Screen
import com.example.typeforge.viewmodel.WordmarkCasing
import com.example.ui.theme.Graphite
import com.example.ui.theme.OxfordInk
import com.example.ui.theme.Paper
import com.example.ui.theme.PaperDark
import com.example.ui.theme.Stone
import com.example.ui.theme.WarmWhite

@Composable
fun WordmarkScreen(
    wordmark: String,
    weight: Float,
    onWordmarkChange: (String) -> Unit,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var trackingSlider by remember { mutableFloatStateOf(6f) }
    var sizeSlider by remember { mutableFloatStateOf(34f) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(scrollState)
            .padding(bottom = 40.dp)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Text(
                text = "WORDMARK MODE",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                letterSpacing = (-0.5).sp,
                color = OxfordInk,
                modifier = Modifier.testTag("wordmark_screen_title")
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Instant corporate identity testing across 4 structural casings.",
                fontFamily = FontFamily.SansSerif,
                fontSize = 13.sp,
                color = Graphite
            )
        }

        // Input Field
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .border(1.dp, Stone, RectangleShape)
                .background(WarmWhite)
                .padding(16.dp)
        ) {
            Text(
                text = "COMPANY OR PRODUCT NAME:",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = Graphite,
                letterSpacing = 0.8.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = wordmark,
                onValueChange = onWordmarkChange,
                singleLine = true,
                shape = RectangleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OxfordInk,
                    unfocusedBorderColor = Stone,
                    focusedContainerColor = Paper,
                    unfocusedContainerColor = Paper
                ),
                textStyle = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("company_name_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            MinimalRuleSlider("LETTER SPACING (TRACKING)", trackingSlider, 0f..25f, { trackingSlider = it })
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Casing Renderings
        val name = wordmark.ifEmpty { "NORTHSTAR" }

        val casingOptions = listOf(
            "UPPERCASE" to name.uppercase(),
            "TITLE CASE" to name.lowercase().replaceFirstChar { it.uppercase() },
            "LOWERCASE" to name.lowercase(),
            "EXPANDED TRACKING" to name.uppercase().map { "$it " }.joinToString("").trim()
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            for ((label, formatted) in casingOptions) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, OxfordInk, RectangleShape)
                        .background(WarmWhite)
                        .padding(18.dp)
                ) {
                    Text(
                        text = label,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Graphite,
                        letterSpacing = 1.0.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = formatted,
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = when {
                            weight < 400 -> FontWeight.Normal
                            weight < 600 -> FontWeight.SemiBold
                            else -> FontWeight.Bold
                        },
                        fontSize = sizeSlider.sp,
                        letterSpacing = (trackingSlider * 0.1f).sp,
                        color = OxfordInk,
                        modifier = Modifier.testTag("wordmark_render_$label")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Actions
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { onNavigate(Screen.BRAND_PREVIEW) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = OxfordInk,
                    contentColor = WarmWhite
                ),
                shape = RectangleShape,
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("wordmark_to_brand_btn")
            ) {
                Text(
                    text = "BRAND SPECIMENS →",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    letterSpacing = 1.0.sp
                )
            }

            OutlinedButton(
                onClick = { onNavigate(Screen.LICENSING) },
                shape = RectangleShape,
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .border(1.dp, OxfordInk, RectangleShape)
                    .testTag("wordmark_to_licence_btn")
            ) {
                Text(
                    text = "LICENCE NOW (£249) →",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = OxfordInk
                )
            }
        }
    }
}
