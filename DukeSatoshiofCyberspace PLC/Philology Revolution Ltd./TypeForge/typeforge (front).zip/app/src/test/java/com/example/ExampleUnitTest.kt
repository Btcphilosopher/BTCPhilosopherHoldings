package com.example

import com.example.typeforge.data.DefaultCatalogue
import com.example.typeforge.engine.ComputationalTypeEngine
import com.example.typeforge.model.Classification
import com.example.typeforge.model.PricingTier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testCatalogueHasTenFictionalTypefaces() {
        val catalogue = DefaultCatalogue.typefaces
        assertEquals(10, catalogue.size)
        assertNotNull(catalogue.find { it.name == "Aureline" })
        assertNotNull(catalogue.find { it.name == "North" })
        assertNotNull(catalogue.find { it.name == "Brunel" })
        assertNotNull(catalogue.find { it.name == "Ashmole" })
        assertNotNull(catalogue.find { it.name == "Circuit" })
    }

    @Test
    fun testCandidateGenerationProducesFourDistinctOptions() {
        val candidates = ComputationalTypeEngine.createInitialCandidates(
            brief = "A sophisticated British engineering company needs a new corporate typeface",
            classification = Classification.SANS
        )
        assertEquals(4, candidates.size)
        assertEquals("OPTION 01", candidates[0].codeNumber)
        assertEquals("OPTION 02", candidates[1].codeNumber)
        assertEquals("OPTION 03", candidates[2].codeNumber)
        assertEquals("OPTION 04", candidates[3].codeNumber)

        assertTrue(candidates[0].scores.geometric > 0)
        assertTrue(candidates[2].scores.industrial > 50)
    }

    @Test
    fun testPricingTiersGbp() {
        assertEquals(79, PricingTier.STARTER.priceGbp)
        assertEquals(249, PricingTier.STUDIO.priceGbp)
        assertEquals(1200, PricingTier.BRAND.priceGbp)
        assertEquals(4800, PricingTier.ENTERPRISE.priceGbp)
    }
}
