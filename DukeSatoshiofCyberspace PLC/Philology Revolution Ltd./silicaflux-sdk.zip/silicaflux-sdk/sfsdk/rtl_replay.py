"""Replay SDK workloads through the *verified SF-G1 RTL blocks* (decoder, ALU, SIMT stack).

The authoritative SF-G1 tree ships three RTL blocks verified against the reference model with model-generated
vectors (docs/09).  This module re-uses that machinery with vectors derived from **the SDK's own binaries**:

1. each workload (a function that drives a :class:`~sfsdk.runtime.Device` -- compiled samples, hand assembled
   kernels, ...) runs on the reference simulator with two hooks: every SIMT-stack command each warp issued is
   recorded, and every ALU operation (function, A, B, result) is recorded;
2. the code words the workloads executed become decoder vectors;
3. the three testbenches (``sf-g1/rtl/tb``) are compiled with Icarus Verilog against the generated package for
   the configuration and run on those vectors.  **Expected values always come from the reference model** (rule V2);
4. a *negative control* corrupts one expected value per block and requires the testbench to FAIL, so a pass is not vacuous.

What this establishes, and what it does not: the real RTL blocks agree with the reference model on the
instructions, ALU operands and divergence/reconvergence command streams that the SDK's binaries actually produce.
It does **not** make the RTL a complete device (no register file, load/store unit, scheduler, ... exist in RTL).
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import tempfile
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from .spec import SF_G1_DIR, Config

Workload = Callable[["object"], None]          # fn(device) -> None


def tools_available() -> Tuple[bool, str]:
    if not shutil.which("iverilog") or not shutil.which("vvp"):
        return False, "Icarus Verilog (iverilog/vvp) not found on PATH"
    return True, ""


@dataclass
class BlockResult:
    block: str
    vectors: int
    passed: bool
    line: str
    negative_control_failed_as_expected: Optional[bool] = None


@dataclass
class ReplayReport:
    config: str
    cfg_hash: int
    blocks: List[BlockResult] = field(default_factory=list)
    workloads: List[str] = field(default_factory=list)
    code_words: int = 0
    alu_ops: int = 0
    stack_commands: int = 0
    stack_streams: int = 0

    @property
    def ok(self) -> bool:
        return all(b.passed and b.negative_control_failed_as_expected is not False for b in self.blocks) and bool(self.blocks)

    def text(self) -> str:
        L = [f"RTL replay, config {self.config} (CFG_HASH {self.cfg_hash:#010x}): {len(self.workloads)} workload(s), "
             f"{self.code_words} distinct code words, {self.alu_ops} distinct ALU operations, "
             f"{self.stack_commands} SIMT-stack commands in {self.stack_streams} warp streams"]
        for b in self.blocks:
            nc = {None: "", True: "  negative control: FAIL as expected", False: "  negative control: DID NOT FAIL (vacuous!)"}[b.negative_control_failed_as_expected]
            L.append(f"  {b.block:<11s} {'PASS' if b.passed else 'FAIL'}  vectors={b.vectors}{nc}")
        return "\n".join(L)


@contextmanager
def alu_operation_log():
    """Log (function code, A, B, result) of every ALU operation the reference model performs while active."""
    from . import _ref  # noqa: F401
    from sfg1 import alu as ref_alu
    orig = dict(ref_alu.BY_CODE)
    log: Set[Tuple[int, int, int, int]] = set()

    def wrap(code, fn):
        def f(a, b):
            y = fn(a, b)
            log.add((code, a, b, y))
            return y
        return f

    for code, fn in orig.items():
        ref_alu.BY_CODE[code] = wrap(code, fn)
    try:
        yield log
    finally:
        ref_alu.BY_CODE.clear()
        ref_alu.BY_CODE.update(orig)


def collect(cfg: Config, workloads: Dict[str, Workload]) -> Tuple[Dict[str, List[str]], ReplayReport]:
    """Run workloads on the reference simulator; return vector files (name -> lines) and a report skeleton."""
    from . import _ref  # noqa: F401
    from sfg1 import isa as ref_isa, vectors as ref_vec
    from .discovery import open_device
    from .transport import ReferenceTransport

    words: Set[int] = set()
    alu_ops: Set[Tuple[int, int, int, int]] = set()
    streams: List[list] = []
    with alu_operation_log() as log:
        for name, fn in workloads.items():
            t = ReferenceTransport(cfg, record_stack=True)
            with open_device(transport=t) as dev:
                fn(dev)
                dev.synchronize()
                for k in dev.kernels:
                    words.update(k.image.words)
                for key in sorted(t.stack_logs):
                    streams.append([tuple(c) for c in t.stack_logs[key]])
        alu_ops |= log
    rcfg = _ref.ref_spec.Config.from_dict(cfg.parameters(), name=cfg.name)
    dec = [f"{len(words)}"] + [f"{w:08x} {ref_isa.decode(w).pack():x}" for w in sorted(words)]
    alu = [f"{len(alu_ops)}"] + [f"{c:x} {a:08x} {b:08x} {y:08x}" for c, a, b, y in sorted(alu_ops)]
    results = []
    for s in streams:
        results.extend(ref_vec.replay(rcfg, s))
    simt = ref_vec._fmt_simt(results)
    rep = ReplayReport(cfg.name, cfg.cfg_hash(), workloads=list(workloads), code_words=len(words), alu_ops=len(alu_ops),
                       stack_commands=len(results), stack_streams=len(streams))
    return {"decode": dec, "alu": alu, "simt_stack": simt}, rep


def _gen_tree(cfg: Config, root: Path) -> Path:
    """Generate the configuration-dependent RTL (package + decoder) into ``root`` (never into the vendored tree)."""
    sys.path.insert(0, str(SF_G1_DIR / "tools"))
    sys.path.insert(0, str(SF_G1_DIR / "sim"))
    try:
        import gen as genmod
        from sfg1.spec import Config as RefConfig
    finally:
        sys.path.pop(0)
        sys.path.pop(0)
    rcfg = RefConfig.from_dict(cfg.parameters(), name=cfg.name)
    for rel, text in genmod.generate(rcfg, include_docs=False).items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)
    return root


def _blocks() -> List[dict]:
    reg = json.loads((SF_G1_DIR / "verification" / "blocks.json").read_text())["blocks"]
    return [b for b in reg if b["status"] == "verified"]


def _run_tb(block: dict, gen_root: Path, vec_file: Path, obj_dir: Path) -> Tuple[bool, str]:
    files = [gen_root / "rtl/gen/sf_g1_pkg.sv"]
    for b in _blocks():
        rel = b["rtl"]
        p = gen_root / rel if rel.startswith("rtl/gen/") else SF_G1_DIR / rel
        if p not in files:
            files.append(p)
    vvp = obj_dir / f"tb_{block['id']}.vvp"
    c = subprocess.run(["iverilog", "-g2012", "-o", str(vvp), *map(str, files), str(SF_G1_DIR / block["testbench"])],
                       capture_output=True, text=True)
    if c.returncode:
        return False, f"COMPILE FAIL: {c.stderr[:400]}"
    r = subprocess.run(["vvp", str(vvp), f"+VEC={vec_file}"], capture_output=True, text=True)
    line = next((l for l in r.stdout.splitlines() if l.startswith("TB_RESULT")), "TB_RESULT ? FAIL no result line")
    return line.startswith(f"TB_RESULT {block['id']} PASS"), line


def _corrupt(lines: List[str], block: str) -> List[str]:
    """Flip one expected bit in the last record so the testbench has something to catch."""
    out = list(lines)
    toks = out[-1].split()
    if block == "decode":
        toks[1] = f"{int(toks[1], 16) ^ 1:x}"                     # packed decode result
    elif block == "alu":
        toks[3] = f"{int(toks[3], 16) ^ 1:08x}"                   # expected ALU result
    else:                                                          # simt_stack: expected pc after the command
        toks[4] = f"{int(toks[4], 16) ^ 1:x}"
    out[-1] = " ".join(toks)
    return out


def replay(workloads: Dict[str, Workload], config_names: Sequence[str] = ("default",), workdir: Optional[Path] = None,
           negative_control: bool = True) -> List[ReplayReport]:
    ok, why = tools_available()
    if not ok:
        raise RuntimeError(why)
    base = Path(workdir) if workdir else Path(tempfile.mkdtemp(prefix="sfsdk-rtl-"))
    reports: List[ReplayReport] = []
    for cname in config_names:
        cfg = Config.named(cname)
        vecs, rep = collect(cfg, workloads)
        root = base / cname
        gen_root = _gen_tree(cfg, root)
        vdir, odir = root / "vectors", root / "obj"
        vdir.mkdir(parents=True, exist_ok=True)
        odir.mkdir(parents=True, exist_ok=True)
        for b in _blocks():
            lines = vecs[b["vectors"]]
            vf = vdir / f"{b['vectors']}.vec"
            vf.write_text("\n".join(lines) + "\n")
            passed, line = _run_tb(b, gen_root, vf, odir)
            nc = None
            if negative_control and int(lines[0]) > 0:
                bad = vdir / f"{b['vectors']}.neg.vec"
                bad.write_text("\n".join(_corrupt(lines, b["vectors"])) + "\n")
                nc_pass, _ = _run_tb(b, gen_root, bad, odir)
                nc = not nc_pass
            rep.blocks.append(BlockResult(b["id"], int(lines[0]), passed, line, nc))
        reports.append(rep)
    return reports
