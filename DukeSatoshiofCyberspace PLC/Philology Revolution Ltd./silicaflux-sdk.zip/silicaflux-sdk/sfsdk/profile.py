"""Profiling: what happened, how long (in device ticks and host seconds), and how well the lanes were used.

Two clocks are reported and must not be confused:

* **device ticks** (``PERF_CYCLES``): time on the simulated device.  For the reference simulator a tick is one
  scheduling round (zero-latency memory); for the hardware model it is one clock cycle of the model.  Ticks
  from different backends are *not* comparable (docs/05 5.7, docs/07 7.6).
* **host seconds**: wall-clock time spent in the Python SDK/simulator.  This measures the simulator, not silicon.

Architectural counters (``issued``, ``lane_ops``, SIMT efficiency) are comparable across backends for race-free kernels.
"""
from __future__ import annotations

import json
import time
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Sequence

from .disasm import format_instr
from .spec import MASK32


@dataclass
class TransferEvent:
    kind: str                 # h2d | d2h | fill
    nbytes: int
    addr: int
    host_s: float
    label: str = ""


@dataclass
class SyncEvent:
    reason: str               # explicit | implicit-transfer | implicit-alloc | reset
    host_s: float
    queued: int = 0


@dataclass
class LaunchEvent:
    launch_id: int
    kernel: str
    backend: str
    config: str
    grid: int
    wg: int
    shared: int
    status: str               # done | fault | rejected | timeout | cancelled
    ticks: int = 0
    issued: int = 0
    lane_ops: int = 0
    lanes: int = 1
    num_eg: int = 1
    workgroups: int = 0
    host_s: float = 0.0
    error: str = ""
    ext: Dict[str, Any] = field(default_factory=dict)

    @property
    def simt_efficiency(self) -> float:
        return self.lane_ops / (self.issued * self.lanes) if self.issued else 0.0

    @property
    def ipc(self) -> float:
        """Warp instructions per device tick, summed over all execution groups."""
        return self.issued / self.ticks if self.ticks else 0.0

    @property
    def issue_utilization(self) -> float:
        """Fraction of issue slots used: at most one warp instruction per EG per tick."""
        return self.issued / (self.ticks * self.num_eg) if self.ticks else 0.0

    def as_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d.update(simt_efficiency=round(self.simt_efficiency, 6), ipc=round(self.ipc, 6),
                 issue_utilization=round(self.issue_utilization, 6))
        return d


class Profiler:
    """Collects events for one :class:`~sfsdk.runtime.Device`; cheap enough to leave on."""

    def __init__(self) -> None:
        self.enabled = True
        self.launches: List[LaunchEvent] = []
        self.transfers: List[TransferEvent] = []
        self.syncs: List[SyncEvent] = []
        self._t0 = time.perf_counter()

    def reset(self) -> None:
        self.launches.clear()
        self.transfers.clear()
        self.syncs.clear()

    def add_launch(self, ev: LaunchEvent) -> None:
        if self.enabled:
            self.launches.append(ev)

    def add_transfer(self, kind: str, nbytes: int, addr: int, host_s: float, label: str = "") -> None:
        if self.enabled:
            self.transfers.append(TransferEvent(kind, nbytes, addr, host_s, label))

    def add_sync(self, reason: str, host_s: float, queued: int = 0) -> None:
        if self.enabled:
            self.syncs.append(SyncEvent(reason, host_s, queued))

    # ------------------------------------------------------------------ aggregation
    def per_kernel(self) -> Dict[str, Dict[str, Any]]:
        agg: Dict[str, Dict[str, Any]] = defaultdict(lambda: {"launches": 0, "ticks": 0, "issued": 0, "lane_ops": 0,
                                                              "host_s": 0.0, "lane_slots": 0, "faults": 0})
        for e in self.launches:
            a = agg[e.kernel]
            a["launches"] += 1
            a["ticks"] += e.ticks
            a["issued"] += e.issued
            a["lane_ops"] += e.lane_ops
            a["lane_slots"] += e.issued * e.lanes
            a["host_s"] += e.host_s
            a["faults"] += e.status != "done"
        out = {}
        for k, a in agg.items():
            a["simt_efficiency"] = round(a["lane_ops"] / a["lane_slots"], 6) if a["lane_slots"] else 0.0
            a["ipc"] = round(a["issued"] / a["ticks"], 6) if a["ticks"] else 0.0
            del a["lane_slots"]
            out[k] = a
        return out

    def transfer_summary(self) -> Dict[str, Dict[str, float]]:
        out: Dict[str, Dict[str, float]] = {}
        for kind in ("h2d", "d2h", "fill"):
            ev = [t for t in self.transfers if t.kind == kind]
            out[kind] = {"count": len(ev), "bytes": sum(t.nbytes for t in ev), "host_s": sum(t.host_s for t in ev)}
        return out

    def summary(self) -> Dict[str, Any]:
        return {"launches": [e.as_dict() for e in self.launches], "per_kernel": self.per_kernel(),
                "transfers": self.transfer_summary(),
                "syncs": {"count": len(self.syncs), "host_s": sum(s.host_s for s in self.syncs)},
                "clocks": "ticks = device ticks of the backend (not comparable across backends); host_s = simulator wall time"}

    def to_json(self, **kw) -> str:
        return json.dumps(self.summary(), indent=kw.pop("indent", 1), sort_keys=True, **kw)

    def report(self) -> str:
        L: List[str] = []
        L.append("launches (device ticks; architectural counters are comparable across backends):")
        L.append(f"  {'#':>3} {'kernel':<20} {'grid':>5} {'wg':>4} {'shared':>6} {'status':<8} {'ticks':>8} {'warp-insn':>9} "
                 f"{'lane-ops':>9} {'simt%':>6} {'ipc':>5} {'host ms':>8}")
        for e in self.launches:
            L.append(f"  {e.launch_id:>3} {e.kernel[:20]:<20} {e.grid:>5} {e.wg:>4} {e.shared:>6} {e.status:<8} {e.ticks:>8} "
                     f"{e.issued:>9} {e.lane_ops:>9} {100 * e.simt_efficiency:>5.1f}% {e.ipc:>5.2f} {1000 * e.host_s:>8.2f}")
        if len(self.per_kernel()) > 1:
            L.append("per kernel:")
            for k, a in sorted(self.per_kernel().items()):
                L.append(f"  {k:<20} launches={a['launches']} ticks={a['ticks']} warp-insn={a['issued']} "
                         f"simt={100 * a['simt_efficiency']:.1f}% ipc={a['ipc']:.2f}")
        t = self.transfer_summary()
        L.append("transfers: " + ", ".join(f"{k} {int(v['count'])}x {int(v['bytes'])} B" for k, v in t.items() if v["count"]) or "none")
        if self.syncs:
            L.append(f"synchronisations: {len(self.syncs)} ({sum(1 for s in self.syncs if s.reason.startswith('implicit'))} implicit)")
        ext = [e.ext for e in self.launches if e.ext]
        if ext:
            L.append("backend counters of the last launch: " + ", ".join(f"{k}={v}" for k, v in sorted(ext[-1].items())))
        return "\n".join(L)


# ---------------------------------------------------------------------------- instruction profile
@dataclass
class PcStat:
    pc: int
    executions: int = 0          # warp instructions committed at this pc
    lane_ops: int = 0
    mem: int = 0
    insn: int = 0


class InstructionProfile:
    """Per-pc execution counts and lane utilisation, from a canonical commit trace."""

    def __init__(self, trace_lines: Sequence[str], words: Sequence[int], lanes: int,
                 source_lines: Optional[Dict[int, int]] = None) -> None:
        self.lanes = lanes
        self.words = list(words)
        self.source_lines = source_lines or {}
        self.stats: Dict[int, PcStat] = {}
        self.active_hist: Dict[int, int] = defaultdict(int)         # active lanes -> warp instructions
        for ln in trace_lines:
            ev = json.loads(ln)
            s = self.stats.setdefault(ev["pc"], PcStat(ev["pc"], insn=ev["insn"]))
            n = bin(ev["mask"]).count("1")
            s.executions += 1
            s.lane_ops += n
            s.mem += ev["mem"] is not None
            self.active_hist[n] += 1
        self.total_issued = sum(s.executions for s in self.stats.values())

    def simt_efficiency(self) -> float:
        slots = self.total_issued * self.lanes
        return sum(s.lane_ops for s in self.stats.values()) / slots if slots else 0.0

    def hottest(self, top: int = 10) -> List[PcStat]:
        return sorted(self.stats.values(), key=lambda s: (-s.executions, s.pc))[:top]

    def text(self, top: int = 12) -> str:
        L = [f"instruction profile: {self.total_issued} warp instructions, SIMT efficiency {100 * self.simt_efficiency():.1f}%",
             f"  {'pc':>4} {'warp-insn':>9} {'avg lanes':>9}  instruction"]
        for s in self.hottest(top):
            txt = format_instr(s.insn, s.pc)
            src = f"   ; line {self.source_lines[s.pc]}" if s.pc in self.source_lines else ""
            L.append(f"  {s.pc:>4} {s.executions:>9} {s.lane_ops / s.executions:>9.2f}  {txt}{src}")
        hist = ", ".join(f"{k}:{v}" for k, v in sorted(self.active_hist.items()))
        L.append(f"  active-lane histogram (lanes:warp-instructions): {hist}")
        return "\n".join(L)
