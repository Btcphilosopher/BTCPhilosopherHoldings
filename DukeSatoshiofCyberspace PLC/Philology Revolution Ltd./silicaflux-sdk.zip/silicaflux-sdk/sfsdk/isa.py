"""SF-G1 instruction tables, encoding and decoding, driven only by ``spec/sf_g1_isa.json``.

Nothing about opcodes, formats or field positions is hard-coded here: adding a row to the
JSON adds an instruction to the assembler, disassembler and hardware model decode.

Public surface
--------------
``ISA``                   the singleton :class:`IsaTable`
``decode(word)``          -> :class:`Instr` or ``None`` when the word is illegal
``encode(mnemonic, ...)`` -> 32-bit word from raw field values
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Dict, List, Optional, Tuple

from .spec import MASK32, load_json


@dataclass(frozen=True)
class FieldSpec:
    name: str
    hi: int
    lo: int
    signed: bool = False

    @property
    def width(self) -> int:
        return self.hi - self.lo + 1

    @property
    def mask(self) -> int:
        return ((1 << self.width) - 1) << self.lo

    @property
    def limits(self) -> Tuple[int, int]:
        if self.signed:
            return -(1 << (self.width - 1)), (1 << (self.width - 1)) - 1
        return 0, (1 << self.width) - 1


@dataclass(frozen=True)
class FormatSpec:
    name: str
    fields: Dict[str, FieldSpec]
    reserved_mask: int          # instruction bits no field and no opcode uses; must be zero


@dataclass(frozen=True)
class InsnSpec:
    mnemonic: str
    opcode: int
    fmt: FormatSpec
    iclass: str                 # NOP / ALU / SREAD / LDG / STG / LDS / STS / ATOM / BRANCH / JUMP / EXIT / BAR / FENCE / TRAP
    alu: str                    # ALU function name (ADD for address generation)
    b_imm: bool                 # operand B comes from the immediate
    reads: Tuple[str, ...]      # source register fields read ("rs1", "rs2")
    writes_rd: bool
    syntax: Tuple[str, ...]
    require: Tuple[str, ...]
    imm_shift: int
    doc: str
    semantics: str


@dataclass(frozen=True)
class Instr:
    """A decoded, legal instruction."""

    spec: InsnSpec
    word: int
    rd: int = 0
    rs1: int = 0
    rs2: int = 0
    imm: int = 0                # raw field value, sign-extended if the field is signed (NOT shifted)
    imm2: int = 0               # second immediate (B format: reconvergence offset)

    @property
    def mnemonic(self) -> str:
        return self.spec.mnemonic

    @property
    def iclass(self) -> str:
        return self.spec.iclass

    @property
    def imm32(self) -> int:
        """The immediate as the datapath sees it: sign-extended and shifted, modulo 2**32."""
        return (self.imm << self.spec.imm_shift) & MASK32

    @property
    def writes_rd(self) -> bool:
        return self.spec.writes_rd

    @property
    def reads(self) -> Tuple[str, ...]:
        return self.spec.reads

    @property
    def src_regs(self) -> Tuple[int, ...]:
        return tuple(getattr(self, r) for r in self.spec.reads)


class IsaTable:
    def __init__(self, raw: Dict) -> None:
        self.raw = raw
        self.opcode_hi, self.opcode_lo = raw["opcode"]["hi"], raw["opcode"]["lo"]
        self.opcode_mask = ((1 << (self.opcode_hi - self.opcode_lo + 1)) - 1) << self.opcode_lo
        self.insn_bits = raw["insn_bits"]
        op_mask = self.opcode_mask
        self.formats: Dict[str, FormatSpec] = {}
        for fname, f in raw["formats"].items():
            fields = {n: FieldSpec(n, d["hi"], d["lo"], d.get("signed", False)) for n, d in f["fields"].items()}
            used = 0
            for fl in fields.values():
                if used & fl.mask:
                    raise ValueError(f"ISA format {fname}: overlapping fields")
                used |= fl.mask
            self.formats[fname] = FormatSpec(fname, fields, (~(used | op_mask)) & MASK32)
        self.classes: Dict[str, int] = {c["name"]: c["code"] for c in raw["classes"]}
        self.alu_functions: Dict[str, int] = {a["name"]: a["code"] for a in raw["alu_functions"]}
        self.special_registers: Dict[str, int] = {s["name"]: s["index"] for s in raw["special_registers"]}
        self.sr_names: Dict[int, str] = {v: k for k, v in self.special_registers.items()}
        self.by_mnemonic: Dict[str, InsnSpec] = {}
        self.by_opcode: Dict[int, InsnSpec] = {}
        for d in raw["instructions"]:
            spec = InsnSpec(
                mnemonic=d["mnemonic"], opcode=d["opcode"], fmt=self.formats[d["format"]], iclass=d["class"],
                alu=d.get("alu", "ADD"), b_imm=d.get("b_src", "rs2") == "imm", reads=tuple(d.get("reads", [])),
                writes_rd=bool(d.get("writes_rd", False)), syntax=tuple(d["syntax"]),
                require=tuple(d.get("require", [])), imm_shift=d.get("imm_shift", 0),
                doc=d.get("doc", ""), semantics=d.get("semantics", ""))
            if spec.mnemonic in self.by_mnemonic or spec.opcode in self.by_opcode:
                raise ValueError(f"duplicate instruction {spec.mnemonic}/{spec.opcode}")
            self.by_mnemonic[spec.mnemonic] = spec
            self.by_opcode[spec.opcode] = spec
        self.pseudo: List[str] = [p["name"] for p in raw.get("pseudo_instructions", [])]

    # ------------------------------------------------------------------ encode
    def encode(self, mnemonic: str, rd: int = 0, rs1: int = 0, rs2: int = 0, imm: int = 0, imm2: int = 0) -> int:
        spec = self.by_mnemonic[mnemonic]
        vals = {"rd": rd, "rs1": rs1, "rs2": rs2, "imm": imm, "imm2": imm2}
        word = spec.opcode << self.opcode_lo
        for name, fl in spec.fmt.fields.items():
            lo, hi = fl.limits
            v = vals[name]
            if not lo <= v <= hi:
                raise ValueError(f"{mnemonic}: {name}={v} out of range [{lo}, {hi}]")
            word |= (v & ((1 << fl.width) - 1)) << fl.lo
        for name, v in vals.items():
            if name not in spec.fmt.fields and v != 0:
                raise ValueError(f"{mnemonic}: format {spec.fmt.name} has no {name} field")
        return word

    # ------------------------------------------------------------------ decode
    def decode(self, word: int) -> Optional[Instr]:
        """Decode ``word``; ``None`` means the word is illegal (F_ILLEGAL_INSN when executed)."""
        word &= MASK32
        spec = self.by_opcode.get((word & self.opcode_mask) >> self.opcode_lo)
        if spec is None or (word & spec.fmt.reserved_mask):
            return None
        vals = {"rd": 0, "rs1": 0, "rs2": 0, "imm": 0, "imm2": 0}
        for name, fl in spec.fmt.fields.items():
            v = (word >> fl.lo) & ((1 << fl.width) - 1)
            if fl.signed and v >> (fl.width - 1):
                v -= 1 << fl.width
            vals[name] = v
        if "imm2_nonzero" in spec.require and vals["imm2"] == 0:
            return None
        if "valid_sr" in spec.require and vals["imm"] not in self.sr_names:
            return None
        return Instr(spec, word, **vals)


@lru_cache(maxsize=1)
def _table() -> IsaTable:
    return IsaTable(load_json("sf_g1_isa.json"))


ISA = _table()


def decode(word: int) -> Optional[Instr]:
    return ISA.decode(word)


def encode(mnemonic: str, **kw: int) -> int:
    return ISA.encode(mnemonic, **kw)


# ----------------------------------------------------------------------- limits used by tools
IMM18_MIN, IMM18_MAX = -(1 << 17), (1 << 17) - 1
BRANCH_TOFF_MIN, BRANCH_TOFF_MAX = ISA.formats["B"].fields["imm"].limits
BRANCH_ROFF_MIN, BRANCH_ROFF_MAX = ISA.formats["B"].fields["imm2"].limits
JUMP_MIN, JUMP_MAX = ISA.formats["J"].fields["imm"].limits
