"""The sample kernels: vector add, histograms (global atomic and privatised), reductions (sum; two-pass signed max)
and matrix multiplication (naive and shared-memory), as *scenarios* that run on any backend.

Sources are ``kernels/*.sfir`` (restricted IR, see ``docs/COMPILER.md``).  :func:`build_all` compiles each once with
``sfsdk.compiler`` into ``kernels/build/<name>.{sfk,sfa,lst}``; scenarios load those ``.sfk`` files, so every backend
receives **byte-identical binaries**.  Every scenario computes its expected results on the host, independently of
any device model, and returns them in the :class:`~sfsdk.compare.Outcome` for comparison.
"""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Optional, Sequence

from .binfmt import KernelImage
from .compare import Outcome, Scenario, ScenarioSkip, compare_matrix, format_matrix, timing_table
from .errors import ArgumentError, SfError
from .runtime import Device
from .spec import ROOT, Config, MASK32

KERNEL_DIR = ROOT / "kernels"
BUILD_DIR = KERNEL_DIR / "build"


# ------------------------------------------------------------------------------------------------ binaries
def source_names() -> List[str]:
    return sorted(p.stem for p in KERNEL_DIR.glob("*.sfir"))


def build_all(outdir: Optional[Path] = None, config: str = "default") -> Dict[str, Dict]:
    """Compile every ``kernels/*.sfir`` to ``<outdir>/<name>.sfk`` (+ ``.sfa`` generated assembly, ``.lst`` listing)."""
    from .compiler import compile_ir
    out = Path(outdir) if outdir else BUILD_DIR
    out.mkdir(parents=True, exist_ok=True)
    cfg = Config.named(config)
    info = {}
    for name in source_names():
        src = (KERNEL_DIR / f"{name}.sfir").read_text()
        res = compile_ir(src, f"kernels/{name}.sfir", config=cfg)
        img = res.image()
        (out / f"{name}.sfk").write_bytes(img.to_bytes())
        (out / f"{name}.sfa").write_text(res.asm)
        (out / f"{name}.lst").write_text("\n".join(res.program.listing) + "\n")
        info[name] = dict(res.info, sha256=img.sha256(), warnings=list(res.warnings))
    return info


def compile_info() -> Dict[str, Dict]:
    """Compiler statistics and code hashes of the shipped binaries (rebuilt in memory, compared with ``kernels/build``)."""
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        info = build_all(Path(d))
        for name in info:
            shipped = BUILD_DIR / f"{name}.sfk"
            info[name]["matches_shipped_binary"] = shipped.exists() and shipped.read_bytes() == (Path(d) / f"{name}.sfk").read_bytes()
    return info


_IMAGES: Dict[str, KernelImage] = {}


def binary(name: str) -> KernelImage:
    """The shipped ``.sfk`` of sample kernel ``name`` (built on demand if the build directory is missing)."""
    if name not in _IMAGES:
        path = BUILD_DIR / f"{name}.sfk"
        if not path.exists():
            build_all()
        _IMAGES[name] = KernelImage.load(str(path))
    return _IMAGES[name]


# ------------------------------------------------------------------------------------------------ host helpers
def lcg(seed: int, n: int) -> List[int]:
    out, x = [], seed & MASK32
    for _ in range(n):
        x = (x * 1664525 + 1013904223) & MASK32
        out.append(x)
    return out


def s32(x: int) -> int:
    return x - (1 << 32) if x & 0x80000000 else x


def pow2_at_most(n: int, cap: int) -> int:
    p = 1
    while p * 2 <= min(n, cap):
        p *= 2
    return p


# ------------------------------------------------------------------------------------------------ scenarios
def vecadd(n: int, wg: int, seed: int = 1) -> Scenario:
    def run(dev: Device) -> Outcome:
        w = min(wg, dev.config.max_wg_threads)
        a, b = lcg(seed, n), lcg(seed + 1, n)
        pa, pb, pc = dev.alloc_words(a, "a"), dev.alloc_words(b, "b"), dev.alloc(4 * n, name="c")
        k = dev.load_kernel(binary("vecadd"))
        r = k.launch((n + w - 1) // w, w, [pa, pb, pc, n])
        return Outcome({"c": pc.read_words()}, [r], {"c": [(x + y) & MASK32 for x, y in zip(a, b)]})
    return Scenario(f"vecadd n={n} wg={wg}", run, "c[i] = a[i] + b[i]")


def histogram_global(n: int, bins: int, grid: int, wg: int) -> Scenario:
    def run(dev: Device) -> Outcome:
        w = min(wg, dev.config.max_wg_threads)
        data = [x >> 8 for x in lcg(7, n)]
        pd, ph = dev.alloc_words(data, "data"), dev.alloc(4 * bins, name="hist")
        k = dev.load_kernel(binary("histogram_global"))
        r = k.launch(grid, w, [pd, ph, n, bins])
        exp = [0] * bins
        for v in data:
            exp[v & (bins - 1)] += 1
        return Outcome({"hist": ph.read_words()}, [r], {"hist": exp})
    return Scenario(f"histogram_global n={n} bins={bins} grid={grid} wg={wg}", run, "atomadd histogram, grid-stride loop")


def histogram_private(n: int, bins: int, chunk: int, wg: int) -> Scenario:
    def run(dev: Device) -> Outcome:
        w = pow2_at_most(wg, dev.config.max_wg_threads)
        if 4 * bins > dev.config.wg_slot_smem_bytes:
            raise ScenarioSkip(f"{4 * bins} B of shared memory per workgroup does not fit ({dev.config.wg_slot_smem_bytes} B)")
        data = [x >> 8 for x in lcg(11, n)]
        pd, ph = dev.alloc_words(data, "data"), dev.alloc(4 * bins, name="hist")
        k = dev.load_kernel(binary("histogram_private"))
        r = k.launch((n + chunk - 1) // chunk, w, [pd, ph, n, bins, chunk])
        exp = [0] * bins
        for v in data:
            exp[v & (bins - 1)] += 1
        return Outcome({"hist": ph.read_words()}, [r], {"hist": exp})
    return Scenario(f"histogram_private n={n} bins={bins} chunk={chunk} wg={wg}", run, "ownership-based private counters, one atomadd per bin per workgroup")


def reduce_sum(n: int, wg: int) -> Scenario:
    def run(dev: Device) -> Outcome:
        w = pow2_at_most(wg, dev.config.max_wg_threads)
        data = [x >> 4 for x in lcg(3, n)]
        pin, pout = dev.alloc_words(data, "in"), dev.alloc(4, name="out")
        k = dev.load_kernel(binary("reduce_sum"))
        r = k.launch((n + w - 1) // w, w, [pin, pout, n])
        return Outcome({"sum": pout.read_words()}, [r], {"sum": [sum(data) & MASK32]})
    return Scenario(f"reduce_sum n={n} wg={wg}", run, "shared-memory tree + one atomadd per workgroup")


def reduce_max(n: int, wg: int, negative_only: bool = False) -> Scenario:
    def run(dev: Device) -> Outcome:
        w = pow2_at_most(wg, dev.config.max_wg_threads)
        vals = [((x >> 4) & 0xFFFFFFF) - 0x8000000 for x in lcg(5, n)]           # signed, mostly mixed sign
        if negative_only:
            vals = [-1 - abs(v) for v in vals]
        data = [v & MASK32 for v in vals]
        grid = (n + w - 1) // w
        pdat, ppart, pout = dev.alloc_words(data, "data"), dev.alloc(4 * grid, name="partial"), dev.alloc(4, name="out")
        k1, k2 = dev.load_kernel(binary("reduce_max_pass1")), dev.load_kernel(binary("reduce_max_pass2"))
        l1 = k1.submit(grid, w, [pdat, ppart, n])                               # two dependent launches through the in-order queue
        l2 = k2.submit(1, w, [ppart, pout, grid])
        dev.synchronize()
        return Outcome({"max": pout.read_words(), "partial": ppart.read_words()}, [l1.wait(), l2.wait()],
                       {"max": [max(vals) & MASK32],
                        "partial": [max(vals[i * w:(i + 1) * w]) & MASK32 for i in range(grid)]})
    return Scenario(f"reduce_max n={n} wg={wg}{' negatives' if negative_only else ''}", run, "two-pass signed max (no atomic max exists)")


def spill_demo(n: int, wg: int) -> Scenario:
    """Twenty simultaneously live values: the compiler must spill (docs/COMPILER.md section 10)."""
    def f(x: int) -> int:                                          # host mirror of kernels/spill_demo.sfir
        M = MASK32
        a = [(x + 1) & M, (x * 3) & M, x ^ 0x55, (x << 1) & M, (x - 7) & M, x | 0x100, x & 0xFFFF, x >> 3, (s32(x) >> 2) & M,
             (x + 0x1234) & M, (x * 5) & M, x ^ 0xAA, (x << 4) & M, (x - 0x99) & M, x | 7, x & 0xFF00, x >> 5, (s32(x) >> 6) & M,
             (x + 0xFFFF) & M, (x * 11) & M]
        t = (a[0] + a[1]) & M
        for k in range(2, 20):
            t = ((t + a[k]) & M, t ^ a[k], (t - a[k]) & M)[(0, 1, 2)[k % 3]]
        return t

    def run(dev: Device) -> Outcome:
        w = min(wg, dev.config.max_wg_threads)
        data = lcg(13, n)
        pd, po = dev.alloc_words(data, "data"), dev.alloc(4 * n, name="out")
        k = dev.load_kernel(binary("spill_demo"))
        r = k.launch((n + w - 1) // w, w, [pd, po, n])             # the SDK adds shared_per_thread x wg bytes of spill area
        return Outcome({"out": po.read_words()}, [r], {"out": [f(x) for x in data]},
                       [f"shared bytes given to the launch: {r.shared}"])
    return Scenario(f"spill_demo n={n} wg={wg}", run, "20 live values: register spilling to shared memory")


def matmul(kind: str, M: int, N: int, K: int, wg: int, small_values: bool = True) -> Scenario:
    kname = f"matmul_{kind}"

    def run(dev: Device) -> Outcome:
        w = min(wg, dev.config.max_wg_threads)
        if kind == "tiled" and 4 * K > dev.config.wg_slot_smem_bytes:
            raise ScenarioSkip(f"A row of {4 * K} B does not fit in shared memory ({dev.config.wg_slot_smem_bytes} B)")
        if small_values:
            A = [((x >> 16) % 201 - 100) & MASK32 for x in lcg(4, M * K)]
            B = [((x >> 16) % 201 - 100) & MASK32 for x in lcg(5, K * N)]
        else:                                                                    # full 32-bit operands: exercises wrap-around
            A, B = lcg(4, M * K), lcg(5, K * N)
        pA, pB, pC = dev.alloc_words(A, "A"), dev.alloc_words(B, "B"), dev.alloc(4 * M * N, name="C")
        k = dev.load_kernel(binary(kname))
        r = k.launch(M, w, [pA, pB, pC, M, N, K])
        exp = [sum(s32(A[i * K + t]) * s32(B[t * N + j]) for t in range(K)) & MASK32 for i in range(M) for j in range(N)]
        return Outcome({"C": pC.read_words()}, [r], {"C": exp})
    return Scenario(f"{kname} {M}x{K}x{N} wg={wg}{'' if small_values else ' wrap'}", run, "integer matrix multiply, wrapping 32-bit")


@dataclass
class Sample:
    name: str
    description: str
    kernels: List[str]
    scenarios: Callable[[], List[Scenario]]


def catalog() -> List[Sample]:
    return [
        Sample("vecadd", "c[i] = a[i] + b[i]; partial warps, wg=1", ["vecadd"],
               lambda: [vecadd(70, 32), vecadd(33, 7), vecadd(5, 1), vecadd(300, 32)]),
        Sample("histogram_global", "histogram with the global atomic, grid-stride loop", ["histogram_global"],
               lambda: [histogram_global(500, 16, 3, 16), histogram_global(257, 64, 2, 8), histogram_global(1, 4, 1, 1)]),
        Sample("histogram_private", "histogram with per-workgroup private counters (no shared atomics exist)", ["histogram_private"],
               lambda: [histogram_private(450, 32, 100, 8), histogram_private(300, 8, 64, 16), histogram_private(97, 64, 40, 4)]),
        Sample("reduce_sum", "shared-memory tree reduction + one atomadd per workgroup", ["reduce_sum"],
               lambda: [reduce_sum(100, 16), reduce_sum(1000, 32), reduce_sum(7, 8), reduce_sum(9, 1)]),
        Sample("reduce_max", "two-pass signed maximum through the in-order launch queue", ["reduce_max_pass1", "reduce_max_pass2"],
               lambda: [reduce_max(777, 32), reduce_max(100, 8, True), reduce_max(5, 1), reduce_max(2000, 16)]),
        Sample("spill_demo", "20 simultaneously live values: compiler spills to shared memory", ["spill_demo"],
               lambda: [spill_demo(70, 32), spill_demo(13, 7), spill_demo(5, 1)]),
        Sample("matmul_naive", "C = A x B, one workgroup per row, everything from global memory", ["matmul_naive"],
               lambda: [matmul("naive", 6, 7, 5, 8), matmul("naive", 3, 3, 1, 8), matmul("naive", 4, 2, 6, 8), matmul("naive", 8, 8, 8, 4, False)]),
        Sample("matmul_tiled", "C = A x B with the A row staged in shared memory", ["matmul_tiled"],
               lambda: [matmul("tiled", 6, 7, 5, 8), matmul("tiled", 5, 9, 33, 16), matmul("tiled", 4, 2, 6, 8), matmul("tiled", 8, 8, 8, 4, False)]),
    ]


def scenarios(names: Optional[Sequence[str]] = None) -> List[Scenario]:
    out: List[Scenario] = []
    for s in catalog():
        if not names or s.name in names:
            out.extend(s.scenarios())
    if names and not out:
        raise SfError(f"no sample named {', '.join(names)}; known: {', '.join(s.name for s in catalog())}", "E_CLI")
    return out


def replay_workloads(per_sample: int = 2) -> Dict[str, Callable[[Device], None]]:
    """Workloads for :mod:`sfsdk.rtl_replay`: the first ``per_sample`` scenarios of every sample."""
    wl: Dict[str, Callable[[Device], None]] = {}
    for s in catalog():
        for scn in s.scenarios()[:per_sample]:
            wl[scn.name] = (lambda dev, scn=scn: scn.run(dev))
    return wl


# ------------------------------------------------------------------------------------------------ CLI entry points
def main_run(a) -> int:
    from .discovery import open_device
    names = a.names or None
    scns = scenarios(names)
    bad = 0
    with open_device(a.device, keep_trace=False) as dev:
        for scn in scns:
            try:
                out = scn.run(dev)
            except ScenarioSkip as e:
                print(f"{scn.name:<52} skipped ({e})")
                continue
            ok = out.expected is None or all(out.outputs.get(k) == v for k, v in out.expected.items())
            bad += not ok
            r = out.launches[-1]
            tt = sum(l.ticks for l in out.launches)
            print(f"{scn.name:<52} {'PASS' if ok else 'FAIL'}  launches={len(out.launches)} ticks={tt} warp-insn={sum(l.issued for l in out.launches)} "
                  f"simt={100 * r.simt_efficiency:.1f}%")
        if a.profile:
            print(dev.profiler.report())
    return 1 if bad else 0


def main_compare(a) -> int:
    scns = scenarios(a.names or None)
    res = compare_matrix(scns, backends=tuple(a.backends), configs=tuple(a.configs))
    print(format_matrix(res))
    print()
    print(timing_table(res))
    if a.json:
        with open(a.json, "w") as f:
            json.dump([c.as_dict() for c in res], f, indent=1, sort_keys=True)
    ran = [c for c in res if not c.skipped]
    return 0 if all(c.ok for c in ran) else 1
