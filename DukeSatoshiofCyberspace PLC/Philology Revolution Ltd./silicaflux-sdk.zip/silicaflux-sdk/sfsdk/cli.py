"""``sfsdk`` command line."""
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Dict, List, Optional

from .errors import AsmError, CompileError, SfError


def _p(msg: str) -> None:
    print(msg)


def _parse_buf(spec: str) -> List[int]:
    """``1,2,3`` -> words; ``8x100`` -> eight copies of 100 (numbers: decimal, 0x.., negative allowed)."""
    body = spec.strip()
    if "x" in body and "," not in body and not body.lower().startswith("0x"):
        n, _, v = body.partition("x")
        return [int(v, 0)] * int(n, 0)
    return [int(t, 0) for t in body.split(",") if t.strip()]


# ------------------------------------------------------------------------------------------ commands
def cmd_devices(a) -> int:
    from .discovery import enumerate_devices, unavailable_backends
    devs = enumerate_devices()
    if a.json:
        _p(json.dumps([d.as_dict() for d in devs], indent=1))
    else:
        for d in devs:
            _p(d.line())
        for name, why in unavailable_backends().items():
            _p(f"(backend '{name}' unavailable: {why})")
    return 0


def cmd_asm(a) -> int:
    from .asm import assemble_file
    prog = assemble_file(a.source)
    for w in prog.warnings:
        print(w, file=sys.stderr)
    out = a.output or os.path.splitext(a.source)[0] + ".sfk"
    img = prog.image()
    with open(out, "wb") as f:
        f.write(img.to_bytes())
    if a.sfbin:
        with open(a.sfbin, "wb") as f:
            f.write(img.to_sfbin())
    if a.hex:
        with open(a.hex, "w") as f:
            f.write(prog.to_hex())
    if a.listing:
        with open(a.listing, "w") as f:
            f.write("\n".join(prog.listing) + "\n")
    if a.symbols:
        with open(a.symbols, "w") as f:
            json.dump(prog.symbols(), f, indent=1, sort_keys=True)
    _p(f"{a.source}: {len(prog.words)} instructions -> {out}")
    return 0


def cmd_dis(a) -> int:
    from .binfmt import KernelImage
    from .disasm import disassemble
    img = KernelImage.load(a.file)
    sys.stdout.write(disassemble(img.words, addresses=a.addresses, symbols=img.labels if a.symbols else None))
    return 0


def cmd_cc(a) -> int:
    from .compiler import compile_ir
    from .spec import Config
    with open(a.source, "r", encoding="utf-8") as f:
        src = f.read()
    cfg = Config.named(a.config) if a.config else None
    res = compile_ir(src, a.source, config=cfg, max_regs=a.max_regs, opt=not a.no_opt, kernel=a.kernel)
    for w in res.warnings:
        print(w, file=sys.stderr)
    out = a.output or os.path.splitext(a.source)[0] + ".sfk"
    with open(out, "wb") as f:
        f.write(res.image().to_bytes())
    if a.asm:
        with open(a.asm, "w") as f:
            f.write(res.asm)
    if a.listing:
        with open(a.listing, "w") as f:
            f.write("\n".join(res.program.listing) + "\n")
    info = res.info
    _p(f"{a.source}: {info.get('instructions', len(res.program.words))} instructions, {info.get('regs_used', '?')} registers, "
       f"{info.get('spill_slots', 0)} spill slot(s) -> {out}")
    return 0


def cmd_info(a) -> int:
    from .binfmt import KernelImage
    img = KernelImage.load(a.file)
    m = img.meta
    _p(f"kernel   : {m.name}   ({img.num_words} instructions, entry {m.entry}, sha256 {img.sha256()[:16]})")
    _p(f"producer : {img.producer or '?'}   source: {img.source_name or '?'}")
    if img.has_meta:
        _p("arguments: " + (", ".join(f"{x.kind} {x.name}" + (f" [{x.access}]" if x.access else "") + (f" extent={x.elems}" if x.elems else "") for x in m.args) or "(none)"))
        _p(f"shared   : {m.shared} bytes + ({m.shared_per_thread}) bytes per thread")
        for e, msg in m.requires:
            _p(f"requires : {e}   -- {msg}")
        if m.info:
            _p("info     : " + ", ".join(f"{k}={v}" for k, v in sorted(m.info.items())))
    else:
        _p("(raw .sfbin: no launch metadata)")
    _p(f"order-dependent atomics (trace digests not comparable): {img.uses_order_dependent_atomics}")
    return 0


def cmd_run(a) -> int:
    from .discovery import open_device
    dev = open_device(a.device, keep_trace=a.instr_profile, wait_mode=a.wait_mode, guard=not a.no_guard)
    bufs: Dict[str, object] = {}
    try:
        for spec in a.buf or []:
            name, _, val = spec.partition("=")
            words = _parse_buf(val)
            bufs[name] = dev.alloc_words(words, name)
        args = []
        for t in a.arg or []:
            if t.startswith("@"):
                if t[1:] not in bufs:
                    raise SfError(f"--arg {t}: no --buf named {t[1:]!r}", "E_CLI")
                args.append(bufs[t[1:]])
            else:
                args.append(int(t, 0))
        k = dev.load_kernel(a.kernel)
        for d in k.diagnostics:
            print(f"warning: {d}", file=sys.stderr)
        r = k.launch(a.grid, a.wg, args, shared=a.shared, watchdog=a.watchdog)
        _p(f"{r.kernel}: done on {dev.backend}:{dev.config.name}  ticks={r.ticks} warp-insn={r.issued} lane-ops={r.lane_ops} "
           f"simt={100 * r.simt_efficiency:.1f}%  workgroups={r.workgroups}")
        for w in r.warnings:
            print(f"warning: {w}", file=sys.stderr)
        for spec in a.dump or []:
            name, _, cnt = spec.partition(":")
            b = bufs[name]
            words = b.read_i32(int(cnt)) if (cnt and a.signed) else (b.read_i32() if a.signed else (b.read_words(int(cnt)) if cnt else b.read_words()))
            _p(f"{name} = {words}")
        if a.profile:
            _p(dev.profiler.report())
        if a.instr_profile:
            _p(r.instruction_profile().text())
        if a.json:
            _p(dev.profiler.to_json())
        return 0
    finally:
        dev.close()


def cmd_conformance(a) -> int:
    from . import conformance
    return conformance.main(["--backend", a.backend] + (["--config", *a.configs] if a.configs else []))


def cmd_rtl(a) -> int:
    from . import rtl_replay
    from .samples import replay_workloads
    ok, why = rtl_replay.tools_available()
    if not ok:
        print(why, file=sys.stderr)
        return 2
    good = True
    for rep in rtl_replay.replay(replay_workloads(), a.configs or ("default", "small", "wide")):
        _p(rep.text())
        good &= rep.ok
    _p("RTL REPLAY: " + ("PASS" if good else "FAIL"))
    return 0 if good else 1


def cmd_samples(a) -> int:
    from . import samples
    if a.action == "list":
        for s in samples.catalog():
            _p(f"{s.name:<22} {s.description}")
        return 0
    return samples.main_run(a)


def cmd_compare(a) -> int:
    from . import samples
    return samples.main_compare(a)


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="sfsdk", description="SilicaFlux SDK for SF-G1")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("devices", help="enumerate devices"); s.add_argument("--json", action="store_true"); s.set_defaults(fn=cmd_devices)
    s = sub.add_parser("asm", help="assemble .sfa -> .sfk"); s.add_argument("source"); s.add_argument("-o", "--output")
    for o in ("sfbin", "hex", "listing", "symbols"):
        s.add_argument("--" + o)
    s.set_defaults(fn=cmd_asm)
    s = sub.add_parser("dis", help="disassemble .sfk/.sfbin"); s.add_argument("file"); s.add_argument("--addresses", action="store_true")
    s.add_argument("--symbols", action="store_true", help="use label names stored in the container"); s.set_defaults(fn=cmd_dis)
    s = sub.add_parser("cc", help="compile .sfir -> .sfk"); s.add_argument("source"); s.add_argument("-o", "--output")
    s.add_argument("--asm", help="also write the generated assembly"); s.add_argument("--listing"); s.add_argument("--config")
    s.add_argument("--max-regs", type=int); s.add_argument("--no-opt", action="store_true"); s.add_argument("--kernel"); s.set_defaults(fn=cmd_cc)
    s = sub.add_parser("info", help="show kernel metadata"); s.add_argument("file"); s.set_defaults(fn=cmd_info)
    s = sub.add_parser("run", help="run one kernel (.sfk/.sfbin/.sfa/.sfir)"); s.add_argument("kernel")
    s.add_argument("--device", default="reference:default"); s.add_argument("--grid", type=lambda x: int(x, 0), required=True)
    s.add_argument("--wg", type=lambda x: int(x, 0), required=True); s.add_argument("--shared", type=lambda x: int(x, 0))
    s.add_argument("--arg", action="append", help="integer, or @name for a --buf buffer"); s.add_argument("--buf", action="append", help="name=1,2,3 | name=8x100")
    s.add_argument("--dump", action="append", help="name[:count]"); s.add_argument("--signed", action="store_true")
    s.add_argument("--profile", action="store_true"); s.add_argument("--instr-profile", action="store_true"); s.add_argument("--json", action="store_true")
    s.add_argument("--wait-mode", choices=("poll", "irq"), default="poll"); s.add_argument("--watchdog", type=int); s.add_argument("--no-guard", action="store_true")
    s.set_defaults(fn=cmd_run)
    s = sub.add_parser("samples", help="list/run the sample kernels"); s.add_argument("action", choices=("list", "run"))
    s.add_argument("names", nargs="*"); s.add_argument("--device", default="reference:default"); s.add_argument("--profile", action="store_true")
    s.set_defaults(fn=cmd_samples)
    s = sub.add_parser("compare", help="run the samples on several backends and compare"); s.add_argument("names", nargs="*")
    s.add_argument("--backends", nargs="+", default=["reference", "hwmodel"]); s.add_argument("--configs", nargs="+", default=["default", "small", "wide"])
    s.add_argument("--json"); s.set_defaults(fn=cmd_compare)
    s = sub.add_parser("conformance", help="host-level conformance suite"); s.add_argument("--backend", default="both"); s.add_argument("--configs", nargs="*"); s.set_defaults(fn=cmd_conformance)
    s = sub.add_parser("rtl-replay", help="replay sample binaries through the verified RTL blocks (needs iverilog)"); s.add_argument("--configs", nargs="*"); s.set_defaults(fn=cmd_rtl)
    return ap


def main(argv: Optional[List[str]] = None) -> int:
    a = build_parser().parse_args(argv)
    try:
        return a.fn(a)
    except (AsmError, CompileError) as e:
        for line in e.errors:
            print(line, file=sys.stderr)
        return 1
    except SfError as e:
        print(f"error [{e.code}]: {e}", file=sys.stderr)
        return 1
    except ImportError as e:
        print(f"error: component not available: {e}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    sys.exit(main())
