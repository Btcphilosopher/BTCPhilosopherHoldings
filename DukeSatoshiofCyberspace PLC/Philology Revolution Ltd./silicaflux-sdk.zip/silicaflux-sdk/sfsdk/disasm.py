"""SF-G1 disassembler, driven by ``spec/sf_g1_isa.json``.

``disassemble`` output re-assembles to exactly the same words (tested): illegal words are
emitted as ``.word 0x...`` so even arbitrary data round-trips.
"""
from __future__ import annotations

from typing import Callable, Dict, List, Optional, Sequence

from .isa import ISA, Instr, decode
from .spec import MASK32


def _reg(n: int) -> str:
    return f"r{n}"


def _mem(base: int, off: int) -> str:
    if off == 0:
        return f"[{_reg(base)}]"
    return f"[{_reg(base)} {'+' if off > 0 else '-'} {abs(off)}]"


def format_instr(word: int, pc: int, label: Optional[Callable[[int], str]] = None) -> str:
    """Text of one instruction word at ``pc``. ``label(addr)`` names branch targets (default: numbers)."""
    i = decode(word)
    if i is None:
        return f".word {word & MASK32:#010x}"
    name = label or str
    s = i.spec
    ops: List[str] = []
    for tok in s.syntax:
        if tok in ("rd", "rs1", "rs2"):
            ops.append(_reg(getattr(i, tok)))
        elif tok == "imm":
            ops.append(str(i.imm))
        elif tok == "sr":
            ops.append(ISA.sr_names.get(i.imm, str(i.imm)))
        elif tok == "mem":
            ops.append(_mem(i.rs1, i.imm))
        elif tok == "memr":
            ops.append(f"[{_reg(i.rs1)}]")
        elif tok == "target":
            ops.append(name(pc + i.imm))
        elif tok == "reconv":
            ops.append(name(pc + i.imm2))
    return s.mnemonic + (" " + ", ".join(ops) if ops else "")


def branch_targets(words: Sequence[int]) -> Dict[int, str]:
    """Addresses that are branch targets or reconvergence points, with generated label names."""
    addrs = set()
    for pc, w in enumerate(words):
        i = decode(w)
        if i is None:
            continue
        if i.iclass == "JUMP":
            addrs.add(pc + i.imm)
        elif i.iclass == "BRANCH":
            addrs.add(pc + i.imm)
            addrs.add(pc + i.imm2)
    return {a: f"L{a}" for a in sorted(addrs) if 0 <= a <= len(words)}


def disassemble(words: Sequence[int], labels: bool = True, addresses: bool = False,
                symbols: Optional[Dict[str, int]] = None) -> str:
    """Disassemble a code image to assembler source.

    ``labels``: synthesise ``L<n>:`` labels at branch targets.  ``symbols``: real label names
    (e.g. from a kernel container) to prefer over generated ones.  ``addresses``: add ``; pc: word`` comments.
    """
    names = branch_targets(words) if labels else {}
    for n, a in (symbols or {}).items():
        if a in names or not labels:
            names[a] = n
    lab = (lambda a: names.get(a, str(a))) if labels else None
    out: List[str] = []
    for pc, w in enumerate(words):
        if pc in names:
            out.append(f"{names[pc]}:")
        line = "    " + format_instr(w, pc, lab)
        if addresses:
            line = f"{line:<44}; {pc:4d}: {w:08x}"
        out.append(line)
    end = len(words)
    if end in names:                                    # a reconvergence point just past the last word
        out.append(f"{names[end]}:")
    return "\n".join(out) + "\n"
