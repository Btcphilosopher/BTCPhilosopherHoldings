"""Loader for the machine-readable SF-G1 specification (the authoritative definitions).

The JSON files under ``sf-g1/spec`` are the single source of truth for the ISA, the
device interface and the hardware parameters.  Everything in the SDK that depends on
them (assembler, disassembler, runtime, hardware model) reads them through this module.

``Config.cfg_hash()`` re-implements the CRC-32 that devices report in the ``CFG_HASH``
register.  It is deliberately a second implementation (not an import of the reference
model's) and the test-suite requires the two to agree.
"""
from __future__ import annotations

import json
import zlib
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Optional

ROOT = Path(__file__).resolve().parents[1]
SF_G1_DIR = ROOT / "sf-g1"
SPEC_DIR = SF_G1_DIR / "spec"
MASK32 = 0xFFFFFFFF


def clog2(n: int) -> int:
    if n < 1:
        raise ValueError("clog2 requires n >= 1")
    return (n - 1).bit_length()


@lru_cache(maxsize=None)
def load_json(name: str) -> Dict[str, Any]:
    with open(SPEC_DIR / name, "r", encoding="utf-8") as f:
        return json.load(f)


def _strip_docs(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _strip_docs(v) for k, v in obj.items() if k not in ("doc", "semantics")}
    if isinstance(obj, list):
        return [_strip_docs(v) for v in obj]
    return obj


class ConfigError(ValueError):
    pass


@dataclass(frozen=True)
class Config:
    """A validated SF-G1 hardware configuration."""

    name: str = "default"
    lanes: int = 8
    warps_per_eg: int = 4
    num_eg: int = 2
    wg_slots_per_eg: int = 2
    smem_bytes_per_eg: int = 8192
    imem_words: int = 1024
    simt_stack_depth: int = 16
    gmem_bytes: int = 1048576
    wdog_reset_ticks: int = 1000000
    xlen: int = 32
    insn_bits: int = 32
    num_regs: int = 16
    num_args: int = 8
    max_grid_dim: int = 65535
    reset_ticks: int = 4
    launch_ticks: int = 1

    # ---- derived ----------------------------------------------------------
    @property
    def max_wg_threads(self) -> int:
        return self.lanes * self.warps_per_eg

    @property
    def wg_slot_smem_bytes(self) -> int:
        return self.smem_bytes_per_eg // self.wg_slots_per_eg

    @property
    def rpc_none(self) -> int:
        return self.imem_words + 1

    @property
    def full_mask(self) -> int:
        return (1 << self.lanes) - 1

    @property
    def stack_overflow_free_depth(self) -> int:
        return 2 * self.lanes - 1

    # ---- construction -------------------------------------------------------
    @staticmethod
    def parameter_table() -> Dict[str, Any]:
        return load_json("sf_g1_config.json")["parameters"]

    @staticmethod
    def fixed_table() -> Dict[str, Any]:
        return load_json("sf_g1_config.json")["fixed"]

    @classmethod
    def from_params(cls, params: Dict[str, Any], name: str = "custom") -> "Config":
        table, fixed = cls.parameter_table(), cls.fixed_table()
        unknown = set(params) - set(table)
        if unknown:
            raise ConfigError(f"unknown configuration parameter(s): {sorted(unknown)}")
        values = {k: v["default"] for k, v in table.items()}
        values.update(params)
        values.update({k: v["value"] for k, v in fixed.items()})
        cfg = cls(name=name, **values)
        cfg.validate()
        return cfg

    @classmethod
    def named(cls, name: str) -> "Config":
        """``default``, ``small``, ``wide`` or a path to a configuration JSON file."""
        p = Path(name)
        if not p.exists():
            p = SPEC_DIR / "configs" / f"{name}.json"
        if not p.exists():
            raise ConfigError(f"unknown configuration '{name}' (known: {', '.join(config_names())})")
        with open(p, "r", encoding="utf-8") as f:
            d = json.load(f)
        return cls.from_params(d.get("parameters", {}), name=d.get("name", p.stem))

    def parameters(self) -> Dict[str, Any]:
        return {k: getattr(self, k) for k in self.parameter_table()}

    def validate(self) -> None:
        for k, meta in self.parameter_table().items():
            v = getattr(self, k)
            if not isinstance(v, int) or isinstance(v, bool):
                raise ConfigError(f"{k} must be an integer, got {v!r}")
            if "allowed" in meta and v not in meta["allowed"]:
                raise ConfigError(f"{k}={v} not in allowed set {meta['allowed']}")
            if "min" in meta and v < meta["min"]:
                raise ConfigError(f"{k}={v} below minimum {meta['min']}")
            if "max" in meta and v > meta["max"]:
                raise ConfigError(f"{k}={v} above maximum {meta['max']}")
        if self.wg_slots_per_eg > self.warps_per_eg:
            raise ConfigError("wg_slots_per_eg must not exceed warps_per_eg")
        if self.smem_bytes_per_eg % (4 * self.wg_slots_per_eg):
            raise ConfigError("smem_bytes_per_eg must be a multiple of 4*wg_slots_per_eg")
        if self.gmem_bytes % 4096:
            raise ConfigError("gmem_bytes must be a multiple of 4096")
        if self.max_wg_threads > 0xFFFF:
            raise ConfigError("lanes*warps_per_eg must fit in 16 bits")

    # ---- device-visible capability registers ----------------------------------
    def caps_regs(self) -> Dict[str, int]:
        return {
            "CAPS_GEOM": (self.wg_slots_per_eg << 24) | (self.num_eg << 16) | (self.warps_per_eg << 8) | self.lanes,
            "CAPS_SMEM": self.smem_bytes_per_eg,
            "CAPS_IMEM": (self.num_regs << 24) | (self.simt_stack_depth << 16) | self.imem_words,
            "CAPS_GMEM": self.gmem_bytes,
            "CAPS_LIMITS": (self.max_grid_dim << 16) | self.max_wg_threads,
        }

    def cfg_hash(self) -> int:
        """CRC-32 of the canonical, documentation-free (config, ISA, device) specification."""
        payload = {
            "config": {"parameters": self.parameters(),
                       "fixed": {k: getattr(self, k) for k in self.fixed_table()}},
            "isa": _strip_docs(load_json("sf_g1_isa.json")),
            "device": _strip_docs(load_json("sf_g1_device.json")),
        }
        data = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return zlib.crc32(data) & MASK32

    @staticmethod
    def from_caps(caps: Dict[str, int], name: str = "probed") -> "Config":
        """Rebuild the architectural parameters a device reports in its ``CAPS_*`` registers.

        ``wdog_reset_ticks`` is not discoverable from CAPS and is left at its default.
        """
        g, im, lim = caps["CAPS_GEOM"], caps["CAPS_IMEM"], caps["CAPS_LIMITS"]
        return Config.from_params({
            "lanes": g & 0xFF, "warps_per_eg": (g >> 8) & 0xFF, "num_eg": (g >> 16) & 0xFF,
            "wg_slots_per_eg": (g >> 24) & 0xFF, "smem_bytes_per_eg": caps["CAPS_SMEM"],
            "imem_words": im & 0xFFFF, "simt_stack_depth": (im >> 16) & 0xFF,
            "gmem_bytes": caps["CAPS_GMEM"]}, name=name)


def config_names() -> list:
    return sorted(p.stem for p in (SPEC_DIR / "configs").glob("*.json"))


def isa_hash() -> int:
    """CRC-32 of the documentation-free ISA definition; stored in kernel containers."""
    data = json.dumps(_strip_docs(load_json("sf_g1_isa.json")), sort_keys=True, separators=(",", ":")).encode()
    return zlib.crc32(data) & MASK32


# --------------------------------------------------------------------------- device interface
class DeviceSpec:
    """Parsed view of ``sf_g1_device.json``: register map, descriptor layout, error codes."""

    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        r = raw or load_json("sf_g1_device.json")
        self.raw = r
        self.device_id = int(r["ids"]["device_id"]["value"], 0)
        self.desc_magic = int(r["ids"]["desc_magic"]["value"], 0)
        self.desc_version = int(r["ids"]["desc_version"]["value"])
        v = r["ids"]["version"]
        self.version_word = (v["major"] << 16) | (v["minor"] << 8) | v["patch"]
        self.regs = {x["name"]: x for x in r["registers"]}
        self.reg_offset = {x["name"]: int(x["offset"], 0) for x in r["registers"]}
        self.reg_by_offset = {int(x["offset"], 0): x for x in r["registers"]}
        self.launch_errors = {x["name"]: x["code"] for x in r["launch_errors"]}
        self.faults = {x["name"]: x["code"] for x in r["faults"]}
        self.fault_info = {x["code"]: x for x in r["faults"]}
        self.error_names = {c: n for n, c in {**self.launch_errors, **self.faults}.items()}
        self.desc_words = {w["name"]: w["index"] for w in r["descriptor"]["words"]}
        self.desc_size_words = r["descriptor"]["size_words"]
        self.desc_flags = {f["name"]: f["bit"] for f in r["descriptor"]["flags"]}
        self.window_bytes = r["mmio"]["window_bytes"]

    def field(self, reg: str, name: str):
        for f in self.regs[reg].get("fields", []):
            if f["name"] == name:
                return f["hi"], f["lo"]
        raise KeyError(f"{reg}.{name}")

    def field_mask(self, reg: str, name: str) -> int:
        hi, lo = self.field(reg, name)
        return ((1 << (hi - lo + 1)) - 1) << lo


@lru_cache(maxsize=1)
def device_spec() -> DeviceSpec:
    return DeviceSpec()
