"""SilicaFlux SDK error taxonomy.

Every error raised by the SDK derives from :class:`SfError` and carries a stable
symbolic ``code`` so that callers can branch on it without parsing messages.

* ``AsmError`` / ``CompileError``  - toolchain diagnostics (``.errors`` lists them all)
* ``ApiError`` (and subclasses)    - the host misused the SDK; nothing reached the device
* ``LaunchRejected``               - the device refused a descriptor (``LE_*``)
* ``DeviceFault``                  - a kernel faulted on the device (``F_*``), with decoded location
* ``DeviceTimeout``                - the host gave up waiting
* ``DeviceMismatch``               - wrong device, or hardware/software specification mismatch
"""
from __future__ import annotations

from typing import Dict, List, Optional


class SfError(Exception):
    code = "E_SF"

    def __init__(self, message: str, code: Optional[str] = None) -> None:
        super().__init__(message)
        if code:
            self.code = code


class AsmError(SfError):
    code = "E_ASM"

    def __init__(self, errors: List[str]) -> None:
        super().__init__("\n".join(errors))
        self.errors = list(errors)


class CompileError(SfError):
    code = "E_COMPILE"

    def __init__(self, errors: List[str]) -> None:
        super().__init__("\n".join(errors))
        self.errors = list(errors)


class ApiError(SfError):
    """The host program used the SDK incorrectly (detected before touching the device)."""
    code = "E_API"


class ArgumentError(ApiError):
    code = "E_ARGUMENT"


class OutOfDeviceMemory(ApiError):
    code = "E_OUT_OF_MEMORY"


class DeviceBusy(ApiError):
    code = "E_BUSY"


class BufferCorrupted(ApiError):
    """A guard canary around a buffer was overwritten (a kernel wrote out of bounds)."""
    code = "E_BUFFER_OVERRUN"


class LaunchRejected(SfError):
    code = "E_LAUNCH_REJECTED"

    def __init__(self, name: str, value: int, detail: str = "") -> None:
        super().__init__(f"device rejected the launch: {name} ({value})" + (f": {detail}" if detail else ""))
        self.name, self.value, self.detail = name, value, detail
        self.code = name


class DeviceFault(SfError):
    code = "E_FAULT"

    def __init__(self, report: "FaultReport") -> None:
        super().__init__(report.describe())
        self.report = report
        self.code = report.name


class DeviceTimeout(SfError):
    code = "E_TIMEOUT"


class DeviceMismatch(SfError):
    code = "E_DEVICE_MISMATCH"


class FaultReport:
    """Decoded ``FAULT_*`` registers (see docs/08 in the SF-G1 specification)."""

    def __init__(self, name: str, code: int, regs: Dict[str, int], where: Dict[str, int],
                 meaning: str, insn_text: Optional[str] = None, source_line: Optional[int] = None,
                 kernel: Optional[str] = None) -> None:
        self.name, self.code, self.regs, self.where = name, code, regs, where
        self.meaning, self.insn_text, self.source_line, self.kernel = meaning, insn_text, source_line, kernel
        self.notes: List[str] = []          # extra findings (e.g. guard canaries damaged before the fault)

    def describe(self) -> str:
        w = self.where
        s = (f"{self.name} in workgroup {self.regs.get('WG', 0)} at pc {self.regs.get('PC', 0)} "
             f"(EG {w.get('eg', 0)}, warp slot {w.get('warp_slot', 0)}, lane {w.get('lane', 0)}, "
             f"active mask {self.regs.get('MASK', 0):#x}): {self.meaning}")
        if self.insn_text:
            s += f"; faulting instruction: {self.insn_text}"
        if self.source_line:
            s += f" (source line {self.source_line})"
        if self.kernel:
            s += f" [kernel {self.kernel}]"
        for n in self.notes:
            s += f"; also: {n}"
        return s

    def as_dict(self) -> Dict[str, object]:
        return {"name": self.name, "code": self.code, "regs": dict(self.regs), "where": dict(self.where),
                "meaning": self.meaning, "insn": self.insn_text, "source_line": self.source_line,
                "kernel": self.kernel, "notes": list(self.notes)}
