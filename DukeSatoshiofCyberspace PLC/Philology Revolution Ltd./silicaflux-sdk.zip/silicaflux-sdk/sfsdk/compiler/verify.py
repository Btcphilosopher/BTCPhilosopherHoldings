"""Semantic checks on a parsed kernel: structure, unreachable code, definite assignment, expressions."""
from __future__ import annotations

from typing import Dict, List, Optional, Set

from .. import expr
from ..errors import CompileError
from . import ir
from .ir import (Assign, AtomAdd, Barrier, Break, BreakIf, If, Kernel, Load, Loop, Opd, Return, Stmt, Store,
                 contains_direct_break, defined_var, operands_of)


# ----------------------------------------------------------------------------- reachability
def terminates(stmts: List[Stmt]) -> bool:
    """True if control can never fall out of the bottom of this block."""
    for s in stmts:
        if isinstance(s, (Return, Break)):
            return True
        if isinstance(s, If) and s.els and terminates(s.then) and terminates(s.els):
            return True
        if isinstance(s, Loop) and not contains_direct_break(s.body):
            return True
    return False


def prune_unreachable(stmts: List[Stmt], warn: List[str], filename: str) -> List[Stmt]:
    """Drop statements that follow a statement after which control cannot continue."""
    out: List[Stmt] = []
    for i, s in enumerate(stmts):
        if isinstance(s, If):
            s.then = prune_unreachable(s.then, warn, filename)
            s.els = prune_unreachable(s.els, warn, filename)
        elif isinstance(s, Loop):
            s.body = prune_unreachable(s.body, warn, filename)
        out.append(s)
        if terminates([s]):
            if i + 1 < len(stmts):
                warn.append(f"{filename}:{stmts[i + 1].line}: warning: unreachable code removed")
            break
    return out


# ----------------------------------------------------------------------------- definite assignment
class _DA:
    def __init__(self, kernel: Kernel, filename: str) -> None:
        self.k, self.filename = kernel, filename
        self.errors: List[str] = []
        self.ever: Set[str] = {v for s in ir.walk(kernel.body) for v in [defined_var(s)] if v}
        self.breaks: List[List[Set[str]]] = []
        self.reported: Set[str] = set()

    def err(self, line: int, msg: str) -> None:
        self.errors.append(f"{self.filename}:{line}: error: {msg}")

    def check_uses(self, s: Stmt, state: Set[str]) -> None:
        for o in operands_of(s):
            if o.kind == "var" and o.value not in state:
                name = str(o.value)
                if name not in self.ever:
                    self.err(s.line, f"undefined variable '{name}' (never assigned)")
                elif (name, s.line) not in self.reported:
                    self.reported.add((name, s.line))
                    self.err(s.line, f"variable '{name}' may be used before it is assigned on every path "
                                     f"(registers are not guaranteed zero: assign it first)")

    def block(self, stmts: List[Stmt], state: Optional[Set[str]]) -> Optional[Set[str]]:
        for s in stmts:
            if state is None:
                break
            state = self.stmt(s, state)
        return state

    @staticmethod
    def join(a: Optional[Set[str]], b: Optional[Set[str]]) -> Optional[Set[str]]:
        if a is None:
            return None if b is None else set(b)
        if b is None:
            return set(a)
        return a & b

    def stmt(self, s: Stmt, state: Set[str]) -> Optional[Set[str]]:
        self.check_uses(s, state)
        d = defined_var(s)
        if isinstance(s, If):
            a = self.block(s.then, set(state))
            b = self.block(s.els, set(state))
            return self.join(a, b)
        if isinstance(s, Loop):
            self.breaks.append([])
            self.block(s.body, set(state))
            exits = self.breaks.pop()
            out: Optional[Set[str]] = None
            for e in exits:
                out = self.join(out, e) if out is not None else set(e)
            return out
        if isinstance(s, Break):
            if not self.breaks:
                self.err(s.line, "`break` outside of a loop")
            else:
                self.breaks[-1].append(set(state))
            return None
        if isinstance(s, BreakIf):
            if not self.breaks:
                self.err(s.line, "`break_if` outside of a loop")
            else:
                self.breaks[-1].append(set(state))
            return state
        if isinstance(s, Return):
            return None
        if d:
            state = set(state)
            state.add(d)
        return state


def check_expressions(k: Kernel, filename: str, errors: List[str]) -> None:
    names = {p.name for p in k.params} | {"wg_dim", "grid_dim", "lanes"}

    def chk(text: str, line: int, what: str) -> None:
        try:
            for sym in expr.free_symbols(text):
                if sym not in names:
                    errors.append(f"{filename}:{line}: error: {what}: unknown name '{sym}' "
                                  f"(allowed: parameters, wg_dim, grid_dim, lanes)")
        except expr.ExprError as e:
            errors.append(f"{filename}:{line}: error: {what}: {e}")

    chk(k.shared, k.line, "`shared` expression")
    for e, _m in k.requires:
        chk(e, k.line, "`require` expression")
    for p in k.params:
        if p.extent:
            chk(p.extent, p.line, f"extent of '{p.name}'")


def verify_kernel(k: Kernel, filename: str) -> List[str]:
    """Run all checks; returns warnings, raises CompileError with every error found."""
    warnings: List[str] = []
    errors: List[str] = []
    check_expressions(k, filename, errors)
    k.body = prune_unreachable(k.body, warnings, filename)
    for s in ir.walk(k.body):
        if isinstance(s, Loop) and not contains_direct_break(s.body) and not _has_return(s.body):
            warnings.append(f"{filename}:{s.line}: warning: loop has no `break` or `return`: it never terminates")
    da = _DA(k, filename)
    da.block(k.body, set())
    errors += da.errors
    if errors:
        raise CompileError(errors)
    return warnings


def _has_return(stmts: List[Stmt]) -> bool:
    return any(isinstance(s, Return) for s in ir.walk(stmts))
