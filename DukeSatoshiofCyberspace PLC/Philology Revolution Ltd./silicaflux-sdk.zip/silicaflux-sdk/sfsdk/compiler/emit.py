"""Emit assembler text from allocated LIR, check branch ranges, and map instruction addresses to IR lines."""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from ..errors import CompileError
from ..isa import BRANCH_ROFF_MAX, BRANCH_TOFF_MAX, BRANCH_TOFF_MIN, IMM18_MAX, IMM18_MIN
from .lir import Ins
from .semantics import MASK32, s32

RR = {"add", "sub", "mul", "and", "or", "xor", "shl", "shr", "sar", "slt", "sltu"}
RI = {"addi", "andi", "ori", "xori", "slti", "sltiu", "shli", "shri", "sari"}


def _size(ins: Ins) -> int:
    if ins.op == "label":
        return 0
    if ins.op == "li":
        v = int(ins.imm) & MASK32
        sv = s32(v)
        return 1 if (IMM18_MIN <= sv <= IMM18_MAX or v & 0x3FF == 0) else 2
    return 1


def _imm(v: int) -> str:
    return str(v) if -(1 << 20) < v < (1 << 20) else hex(v & MASK32)


def format_ins(i: Ins) -> str:
    r = lambda n: f"r{n}"                                    # noqa: E731
    op = i.op
    if op in RR:
        return f"{op} {r(i.dst)}, {r(i.srcs[0])}, {r(i.srcs[1])}"
    if op in RI:
        return f"{op} {r(i.dst)}, {r(i.srcs[0])}, {i.imm}"
    if op == "li":
        return f"li {r(i.dst)}, {_imm(s32(int(i.imm)))}"
    if op == "rdsr":
        return f"rdsr {r(i.dst)}, {i.imm}"
    if op in ("ldg", "lds"):
        off = int(i.imm)
        return f"{op} {r(i.dst)}, [{r(i.srcs[0])}{'' if off == 0 else (' + ' if off > 0 else ' - ') + str(abs(off))}]"
    if op in ("stg", "sts"):
        off = int(i.imm)
        return f"{op} {r(i.srcs[1])}, [{r(i.srcs[0])}{'' if off == 0 else (' + ' if off > 0 else ' - ') + str(abs(off))}]"
    if op == "atomadd":
        return f"atomadd {r(i.dst or 0)}, [{r(i.srcs[0])}], {r(i.srcs[1])}"
    if op in ("bz", "bnz"):
        return f"{op} {r(i.srcs[0])}, {i.target}, {i.reconv}"
    if op == "bra":
        return f"bra {i.target}"
    if op == "trap":
        return f"trap {i.imm}"
    if op in ("bar", "fence", "exit"):
        return op
    raise ValueError(f"cannot format {op}")                  # pragma: no cover


def layout(code: List[Ins]) -> Tuple[Dict[str, int], List[int]]:
    """Label addresses and the address of each instruction."""
    pc, labels, addr = 0, {}, []
    for ins in code:
        addr.append(pc)
        if ins.op == "label":
            labels[ins.target] = pc
        pc += _size(ins)
    return labels, addr


def check_ranges(code: List[Ins], filename: str) -> None:
    labels, addr = layout(code)
    errs: List[str] = []
    for ins, pc in zip(code, addr):
        if ins.op in ("bz", "bnz"):
            toff = labels[ins.target] - pc
            roff = labels[ins.reconv] - pc
            if not BRANCH_TOFF_MIN <= toff <= BRANCH_TOFF_MAX:
                errs.append(f"{filename}:{ins.line}: error: E_BRANCH_RANGE: conditional branch needs a displacement of "
                            f"{toff:+d} instructions; the encodable range is {BRANCH_TOFF_MIN}..{BRANCH_TOFF_MAX}. "
                            f"Shorten the `if`/`loop` body (or split the kernel)")
            if not 1 <= roff <= BRANCH_ROFF_MAX:
                errs.append(f"{filename}:{ins.line}: error: E_BRANCH_RANGE: reconvergence point is {roff} instructions "
                            f"from the branch; the encodable range is 1..{BRANCH_ROFF_MAX}")
    if errs:
        raise CompileError(errs)


def emit_text(code: List[Ins], header: List[str], ir_name: str) -> Tuple[str, Dict[int, int]]:
    """Return (assembler source, pc -> IR line)."""
    lines = list(header)
    pcmap: Dict[int, int] = {}
    pc = 0
    for ins in code:
        if ins.op == "label":
            lines.append(f"{ins.target}:")
            continue
        text = format_ins(ins)
        note = [f"{ir_name}:{ins.line}"] if ins.line else []
        if ins.tag in ("spill", "remat"):
            note.append(f"({ins.tag})")
        tag = ("  ; " + " ".join(note)) if note else ""
        lines.append(f"    {text}{tag}")
        for k in range(_size(ins)):
            pcmap[pc + k] = ins.line
        pc += _size(ins)
    return "\n".join(lines) + "\n", pcmap
