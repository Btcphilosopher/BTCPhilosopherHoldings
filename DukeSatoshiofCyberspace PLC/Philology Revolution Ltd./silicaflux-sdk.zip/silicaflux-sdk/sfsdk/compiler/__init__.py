"""SF-G1 compiler: restricted structured IR -> SF-G1 assembler text / kernel image.

Public API::

    from sfsdk.compiler import compile_ir, parse_ir, interpret, KernelBuilder
    res = compile_ir(source, "k.sfir", config=Config.named("default"))
    res.asm, res.program, res.image(), res.warnings, res.info

See docs/COMPILER.md for the IR reference, register allocation, spilling and unsupported constructs.
"""
from .driver import CompileResult, compile_ir
from .ir import KernelBuilder, Module, Param, format_kernel
from .parser import parse_ir

__all__ = ["compile_ir", "CompileResult", "parse_ir", "KernelBuilder", "Module", "Param", "format_kernel",
           "interpret", "InterpError"]


def __getattr__(name):                                 # lazy: the interpreter is only needed by tests/tools
    if name in ("interpret", "InterpError"):
        from . import interp
        return getattr(interp, name)
    raise AttributeError(name)
