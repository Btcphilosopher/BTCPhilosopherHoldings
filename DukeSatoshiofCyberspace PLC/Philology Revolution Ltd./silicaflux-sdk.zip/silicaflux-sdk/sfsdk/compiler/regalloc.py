"""Liveness, live intervals, linear-scan register allocation and shared-memory spilling.

Registers: ``r0`` is hard zero, so ``r1..r15`` are allocatable.  The allocator runs in two modes:

* **plain** - all of ``r1..r{N}`` (N = 15 by default) are allocatable;
* **spilling** - used only if plain mode would spill: ``r1..r{min(12,N)}`` are allocatable and three registers
  are reserved: ``SB`` (r15, spill base address), ``S1`` (r14) and ``S2`` (r13) (scratch for reloads and for the
  value being stored).

SF-G1 has no local memory and no stack (docs/04 4.1), so spill slots are thread-private words in *shared* memory,
at the end of the workgroup's shared region::

    shared region  [ 0 ......... user_bytes ...... | ... | spill area: wg_dim threads x (4*P bytes) ]  SHARED_BYTES
    thread t's slots start at   SB = SHARED_BYTES - 4*P*(wg_dim - t)      slot s is at   SB + 4*s

where P is the slot count rounded up to a power of two.  The spill area is requested from the runtime with the
``.shared_per_thread 4*P`` directive.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Set, Tuple

from ..errors import CompileError
from .lir import PURE, V0, Ins, is_virtual

SB, S1, S2 = 15, 14, 13
MAX_PLAIN = 15
MAX_SPILL_MODE = 12


# ----------------------------------------------------------------------------- CFG + liveness
class Block:
    __slots__ = ("start", "end", "succs", "use", "defs", "live_in", "live_out")

    def __init__(self, start: int, end: int) -> None:
        self.start, self.end = start, end
        self.succs: List[int] = []
        self.use: Set[int] = set()
        self.defs: Set[int] = set()
        self.live_in: Set[int] = set()
        self.live_out: Set[int] = set()


def build_blocks(code: List[Ins]) -> List[Block]:
    n = len(code)
    leaders = {0}
    for i, ins in enumerate(code):
        if ins.op == "label":
            leaders.add(i)
        elif ins.op in ("bz", "bnz", "bra", "exit") and i + 1 < n:
            leaders.add(i + 1)
    starts = sorted(leaders)
    blocks = [Block(s, (starts[j + 1] - 1) if j + 1 < len(starts) else n - 1) for j, s in enumerate(starts)]
    label_block: Dict[str, int] = {}
    for bi, b in enumerate(blocks):
        for i in range(b.start, b.end + 1):
            if code[i].op == "label":
                label_block[code[i].target] = bi
    for bi, b in enumerate(blocks):
        last = code[b.end]
        if last.op == "bra":
            b.succs = [label_block[last.target]]
        elif last.op in ("bz", "bnz"):
            b.succs = [label_block[last.target]] + ([bi + 1] if bi + 1 < len(blocks) else [])
        elif last.op == "exit":
            b.succs = []
        elif bi + 1 < len(blocks):
            b.succs = [bi + 1]
        for i in range(b.start, b.end + 1):
            ins = code[i]
            for u in ins.uses():
                if is_virtual(u) and u not in b.defs:
                    b.use.add(u)
            for d in ins.defs():
                if is_virtual(d):
                    b.defs.add(d)
    return blocks


def liveness(code: List[Ins]) -> List[Block]:
    blocks = build_blocks(code)
    changed = True
    while changed:
        changed = False
        for b in reversed(blocks):
            out: Set[int] = set()
            for s in b.succs:
                out |= blocks[s].live_in
            inn = b.use | (out - b.defs)
            if out != b.live_out or inn != b.live_in:
                b.live_out, b.live_in, changed = out, inn, True
    return blocks


def dce(code: List[Ins]) -> List[Ins]:
    """Remove pure instructions whose result is never used; drop atomic return values that are not used."""
    while True:
        blocks = liveness(code)
        dead: Set[int] = set()
        for b in blocks:
            live = set(b.live_out)
            for i in range(b.end, b.start - 1, -1):
                ins = code[i]
                d = ins.dst
                if d is not None and is_virtual(d) and d not in live:
                    if ins.op in PURE:
                        dead.add(i)
                        continue
                    if ins.op == "atomadd":
                        ins.dst = 0
                        d = None
                if d is not None and is_virtual(d):
                    live.discard(d)
                for u in ins.uses():
                    if is_virtual(u):
                        live.add(u)
        if not dead:
            return code
        code = [ins for i, ins in enumerate(code) if i not in dead]


def fuse_compare_branch(code: List[Ins]) -> List[Ins]:
    """Branch directly on the operand of an ``eq``/``ne`` test instead of materialising the 0/1 result.

    ``sltiu d,t,1`` is ``d = (t == 0)`` and ``sltu d,r0,t`` is ``d = (t != 0)``.  If ``d`` is used only by the
    immediately following ``bz``/``bnz`` the pair collapses to a single branch on ``t`` (sense flipped for ``eq``).
    """
    uses: Dict[int, int] = {}
    ndefs: Dict[int, int] = {}
    for ins in code:
        for u in ins.uses():
            uses[u] = uses.get(u, 0) + 1
        for d in ins.defs():
            ndefs[d] = ndefs.get(d, 0) + 1
    out: List[Ins] = []
    i = 0
    while i < len(code):
        a = code[i]
        b = code[i + 1] if i + 1 < len(code) else None
        if (b is not None and b.op in ("bz", "bnz") and a.dst is not None and is_virtual(a.dst)
                and b.srcs == [a.dst] and uses.get(a.dst) == 1 and ndefs.get(a.dst) == 1):
            if a.op == "sltiu" and a.imm == 1 and a.srcs and a.srcs[0] != 0:      # d = (t == 0)
                nb = b.copy()
                nb.srcs = [a.srcs[0]]
                nb.op = "bnz" if b.op == "bz" else "bz"
                out.append(nb)
                i += 2
                continue
            if a.op == "sltu" and len(a.srcs) == 2 and a.srcs[0] == 0 and a.srcs[1] != 0:   # d = (t != 0)
                nb = b.copy()
                nb.srcs = [a.srcs[1]]
                out.append(nb)
                i += 2
                continue
        out.append(a)
        i += 1
    return out


# ----------------------------------------------------------------------------- intervals
class Interval:
    __slots__ = ("v", "start", "end", "nospill", "uses")

    def __init__(self, v: int) -> None:
        self.v, self.start, self.end, self.nospill, self.uses = v, 1 << 60, -1, False, 0


def build_intervals(code: List[Ins], blocks: List[Block]) -> Dict[int, Interval]:
    """Conservative live intervals over *half positions*: instruction i reads at 2i and writes at 2i+1."""
    iv: Dict[int, Interval] = {}

    def get(v: int) -> Interval:
        if v not in iv:
            iv[v] = Interval(v)
        return iv[v]

    for b in blocks:
        for v in b.live_in:
            x = get(v)
            x.start = min(x.start, 2 * b.start - 1)
        for v in b.live_out:
            x = get(v)
            x.end = max(x.end, 2 * b.end + 1)
    ndefs: Dict[int, int] = {}
    remat_def: Dict[int, bool] = {}
    for i, ins in enumerate(code):
        for u in ins.uses():
            if is_virtual(u):
                x = get(u)
                x.start = min(x.start, 2 * i)
                x.end = max(x.end, 2 * i)
                x.uses += 1
        for d in ins.defs():
            if is_virtual(d):
                x = get(d)
                x.start = min(x.start, 2 * i + 1)
                x.end = max(x.end, 2 * i + 1)
                ndefs[d] = ndefs.get(d, 0) + 1
                remat_def[d] = ins.tag == "remat"
    for v, x in iv.items():
        # short-lived rematerialisation temporaries (single `li`/`rdsr` def) must stay in registers
        x.nospill = ndefs.get(v, 0) == 1 and remat_def.get(v, False)
    return iv


# ----------------------------------------------------------------------------- linear scan
def linear_scan(iv: Dict[int, Interval], regs: List[int]) -> Tuple[Dict[int, int], Set[int]]:
    assign: Dict[int, int] = {}
    spilled: Set[int] = set()
    free = list(reversed(regs))                       # pop() yields the lowest-numbered register first
    active: List[Interval] = []
    for cur in sorted(iv.values(), key=lambda x: (x.start, x.end, x.v)):
        keep = []
        for a in active:
            if a.end < cur.start:
                free.append(assign[a.v])
            else:
                keep.append(a)
        active = keep
        free.sort(reverse=True)
        if free:
            assign[cur.v] = free.pop()
            active.append(cur)
            continue
        cands = [a for a in active if not a.nospill]
        if not cur.nospill:
            cands.append(cur)
        if not cands:
            raise CompileError([f"register allocation failed: {len(regs)} registers cannot hold the operands of "
                                f"one statement; raise max_regs or simplify the expression"])
        victim = max(cands, key=lambda x: (x.end, -x.uses))
        if victim is cur:
            spilled.add(cur.v)
        else:
            spilled.add(victim.v)
            assign[cur.v] = assign.pop(victim.v)
            active.remove(victim)
            active.append(cur)
    return assign, spilled


# ----------------------------------------------------------------------------- result container
class Allocation:
    def __init__(self) -> None:
        self.code: List[Ins] = []
        self.spilled = 0                   # variables living in memory
        self.remat_spilled = 0             # spilled variables rebuilt from rdsr/li instead of a slot
        self.slots = 0                     # distinct spill slots
        self.slots_padded = 0              # P
        self.spill_loads = 0
        self.spill_stores = 0
        self.spill_mode = False
        self.regs_used: Set[int] = set()
        self.nregs = 0


def _count_defs(code: List[Ins]) -> Dict[int, List[Ins]]:
    d: Dict[int, List[Ins]] = {}
    for ins in code:
        for r in ins.defs():
            if is_virtual(r):
                d.setdefault(r, []).append(ins)
    return d


def _round_pow2(n: int) -> int:
    p = 1
    while p < n:
        p <<= 1
    return p


def allocate(code: List[Ins], max_regs: Optional[int] = None) -> Allocation:
    """Allocate registers; falls back to the spilling mode when the plain mode cannot hold everything."""
    cap = 15 if max_regs is None else max_regs
    if cap < 4:
        raise CompileError(["max_regs must be at least 4"])
    blocks = liveness(code)
    iv = build_intervals(code, blocks)
    assign, spilled = linear_scan(iv, list(range(1, min(MAX_PLAIN, cap) + 1)))
    res = Allocation()
    if not spilled:
        res.code = _apply(code, assign, {}, {}, set())
        res.regs_used = {r for r in assign.values()}
        res.nregs = min(MAX_PLAIN, cap)
        _peephole(res)
        return res
    # ---- spilling mode
    res.spill_mode = True
    assign, spilled = linear_scan(iv, list(range(1, min(MAX_SPILL_MODE, cap) + 1)))
    defs = _count_defs(code)
    remat: Dict[int, Ins] = {}
    slot_cands: List[Interval] = []
    for v in sorted(spilled):
        ds = defs.get(v, [])
        if len(ds) == 1 and ds[0].op in ("rdsr", "li"):
            remat[v] = ds[0]
        else:
            slot_cands.append(iv[v])
    slot_of: Dict[int, int] = {}
    slot_end: List[int] = []
    for x in sorted(slot_cands, key=lambda x: (x.start, x.v)):
        for s, e in enumerate(slot_end):
            if e < x.start:
                slot_of[x.v], slot_end[s] = s, x.end
                break
        else:
            slot_of[x.v] = len(slot_end)
            slot_end.append(x.end)
    res.slots = len(slot_end)
    res.slots_padded = _round_pow2(max(res.slots, 1)) if res.slots else 0
    res.spilled = len(spilled)
    res.remat_spilled = len(remat)
    res.nregs = min(MAX_SPILL_MODE, cap) + 3
    out = _apply(code, assign, slot_of, remat, set(spilled), res)
    if res.slots:
        out = _prologue(res.slots_padded) + out
    res.code = out
    res.regs_used = {r for r in assign.values()} | ({SB, S1, S2} if res.slots else {S1, S2})
    res.code = out
    _peephole(res)
    return res


def _prologue(p: int) -> List[Ins]:
    """SB = SHARED_BYTES - 4*P*(wg_dim - tid)"""
    sh = 2 + (p.bit_length() - 1)
    pro = [
        Ins("rdsr", SB, imm="SR_WG_DIM", tag="spill"),
        Ins("rdsr", S1, imm="SR_TID", tag="spill"),
        Ins("sub", SB, [SB, S1], tag="spill"),
        Ins("shli", SB, [SB], imm=sh, tag="spill"),
        Ins("rdsr", S1, imm="SR_SHARED_BYTES", tag="spill"),
        Ins("sub", SB, [S1, SB], tag="spill"),
    ]
    return pro


def _apply(code: List[Ins], assign: Dict[int, int], slot_of: Dict[int, int], remat: Dict[int, Ins],
           spilled: Set[int], res: Optional[Allocation] = None) -> List[Ins]:
    def ph(r: int) -> int:
        return r if (r is not None and r < V0) else assign[r]

    out: List[Ins] = []
    for ins in code:
        if ins.op == "label":
            out.append(ins)
            continue
        if ins.dst in remat and ins.op in ("rdsr", "li"):
            continue                                    # rebuilt at every use instead
        scratch = [S1, S2]
        smap: Dict[int, int] = {}
        srcs: List[int] = []
        for r in ins.srcs:
            if r in spilled:
                if r not in smap:
                    s = scratch.pop(0)
                    smap[r] = s
                    if r in remat:
                        d = remat[r]
                        out.append(Ins(d.op, s, [], d.imm, line=ins.line, tag="remat"))
                    else:
                        out.append(Ins("lds", s, [SB], imm=4 * slot_of[r], line=ins.line, tag="spill"))
                        if res:
                            res.spill_loads += 1
                srcs.append(smap[r])
            else:
                srcs.append(ph(r))
        n = ins.copy()
        n.srcs = srcs
        post: Optional[Ins] = None
        if ins.dst is not None and ins.dst != 0:
            if ins.dst in spilled:
                n.dst = S1
                post = Ins("sts", None, [SB, S1], imm=4 * slot_of[ins.dst], line=ins.line, tag="spill")
                if res:
                    res.spill_stores += 1
            else:
                n.dst = ph(ins.dst)
        out.append(n)
        if post:
            out.append(post)
    return out


def _peephole(res: Allocation) -> None:
    """Drop register-to-register copies that the allocator made redundant (``addi rX, rX, 0``)."""
    res.code = [i for i in res.code if not (i.op == "addi" and i.imm == 0 and i.srcs == [i.dst] and i.dst)]
