"""Conservative uniformity analysis (is a value / the active mask the same for every lane of a warp?).

Why it exists: ``bar`` requires ``active == live``; if some live lane of a warp is parked on another path the
warp faults with F_BAR_DIVERGENT.  A barrier is therefore only accepted where the compiler can show that no
lane of a warp can be waiting elsewhere: i.e. it is not nested under any construct controlled by a
*non-uniform* condition.  ``return`` is not a divergence source (exited lanes leave the live mask).

Lattice: uniform < non-uniform.  Uniform sources are literals, parameters and the builtins ``wg_id wg_dim
grid_dim lanes shared_bytes``; ``tid gtid lane warp``, loads and atomic results are non-uniform.  A variable is
uniform only if *every* assignment to it is uniform and executes in a uniform control context.  The analysis
iterates to a fixed point (monotone, so it terminates).  ``assume_uniform`` is the programmer's override.
"""
from __future__ import annotations

from typing import Dict, List, Set

from . import ir
from .ir import (Assign, AtomAdd, Barrier, Break, BreakIf, If, Kernel, Load, Loop, Opd, Stmt)


class UniformInfo:
    def __init__(self) -> None:
        self.var_uniform: Dict[str, bool] = {}
        self.divergent_barriers: List[Barrier] = []
        self.max_divergence_depth = 0
        self.nonuniform_loops: Set[int] = set()       # id(Loop) with a divergent exit
        self.nonuniform_ifs: Set[int] = set()         # id(If) with a non-uniform condition
        self.divergent_escapes = 0                    # non-uniform ifs whose arms break out of the enclosing loop

    def is_uniform(self, o: Opd) -> bool:
        if o.kind in ("const", "param"):
            return True
        if o.kind == "builtin":
            return o.value in ir.UNIFORM_BUILTINS
        return self.var_uniform.get(str(o.value), True)


def analyze(k: Kernel) -> UniformInfo:
    info = UniformInfo()
    for s in ir.walk(k.body):
        d = ir.defined_var(s)
        if d:
            info.var_uniform[d] = True
    changed = True
    while changed:
        changed = False
        info.divergent_barriers = []
        info.nonuniform_loops, info.nonuniform_ifs = set(), set()
        info.max_divergence_depth = 0
        info.divergent_escapes = 0
        changed = _walk(k.body, False, 0, info)
    return info


def _loop_has_divergent_exit(loop: Loop, info: UniformInfo) -> bool:
    def rec(stmts: List[Stmt], under_nonuniform_if: bool) -> bool:
        for s in stmts:
            if isinstance(s, BreakIf) and (under_nonuniform_if or not info.is_uniform(s.cond)):
                return True
            if isinstance(s, Break) and under_nonuniform_if:
                return True
            if isinstance(s, If):
                nu = under_nonuniform_if or not info.is_uniform(s.cond)
                if rec(s.then, nu) or rec(s.els, nu):
                    return True
        return False
    return rec(loop.body, False)


def _walk(stmts: List[Stmt], div: bool, depth: int, info: UniformInfo) -> bool:
    changed = False
    for s in stmts:
        if isinstance(s, (Assign, Load, AtomAdd)):
            dst = ir.defined_var(s)
            if dst is None:
                continue
            if isinstance(s, Assign):
                if s.op == "assume_uniform":
                    uni = True
                else:
                    uni = all(info.is_uniform(a) for a in s.args) and not div
            else:
                uni = False
            if info.var_uniform.get(dst, True) and not uni:
                info.var_uniform[dst] = False
                changed = True
        elif isinstance(s, Barrier):
            if div:
                info.divergent_barriers.append(s)
        elif isinstance(s, If):
            nu = not info.is_uniform(s.cond)
            if nu:
                info.nonuniform_ifs.add(id(s))
                if ir.contains_direct_break(s.then) or ir.contains_direct_break(s.els):
                    info.divergent_escapes += 1
            d2 = depth + (1 if nu else 0)
            info.max_divergence_depth = max(info.max_divergence_depth, d2)
            changed |= _walk(s.then, div or nu, d2, info)
            changed |= _walk(s.els, div or nu, d2, info)
        elif isinstance(s, Loop):
            ld = _loop_has_divergent_exit(s, info)
            if ld:
                info.nonuniform_loops.add(id(s))
            d2 = depth + (1 if ld else 0)
            info.max_divergence_depth = max(info.max_divergence_depth, d2)
            changed |= _walk(s.body, div or ld, d2, info)
    return changed
