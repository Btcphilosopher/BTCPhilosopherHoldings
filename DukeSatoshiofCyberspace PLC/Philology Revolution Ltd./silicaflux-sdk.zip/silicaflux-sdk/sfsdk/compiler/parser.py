"""Parser for the textual IR (``.sfir``).

One statement per line; blocks are delimited by ``{`` ... ``}`` with ``} else {`` joining the arms of an
``if``.  Comments start with ``#``, ``;`` or ``//``.  Every diagnostic in the file is collected and
reported together as ``file:line: error: message``.
"""
from __future__ import annotations

import re
from typing import List, Optional, Tuple

from .. import expr
from ..errors import CompileError
from . import ir
from .ir import (Assign, AtomAdd, Barrier, Break, BreakIf, Fence, If, Kernel, Load, Loop, Mem, Module, Opd,
                 Param, Return, Store, Trap)

_TOKEN = re.compile(
    r"\s*(?:(?P<num>-?(?:0[xX][0-9a-fA-F_]+|0[bB][01_]+|\d[\d_]*)(?![\w.]))"
    r"|(?P<id>[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)?)"
    r"|(?P<p>[=,\[\]+\-(){}]))")
_RESERVED = set(ir.BUILTINS) | set(ir.KEYWORDS) | set(ir.VALUE_OPS) | set(ir.UNSUPPORTED_OPS) | {"mov"}
_IDENT = re.compile(r"^[A-Za-z_]\w*$")

Tok = Tuple[str, str]


def _strip_comment(line: str) -> str:
    out, quoted, i = [], False, 0
    while i < len(line):
        c = line[i]
        if c == '"':
            quoted = not quoted
        elif not quoted and (c in "#;" or line.startswith("//", i)):
            break
        out.append(c)
        i += 1
    return "".join(out).strip()


def _tokenize(text: str) -> List[Tok]:
    toks: List[Tok] = []
    pos = 0
    while pos < len(text):
        m = _TOKEN.match(text, pos)
        if not m or m.end() == pos:
            rest = text[pos:].strip()
            if not rest:
                break
            raise ValueError(f"unexpected character {rest[0]!r}")
        pos = m.end()
        toks.append((m.lastgroup, m.group(m.lastgroup)))
    return toks


class _Parser:
    def __init__(self, source: str, filename: str) -> None:
        self.filename = filename
        self.errors: List[str] = []
        self.lines: List[Tuple[int, str]] = [(n, _strip_comment(r)) for n, r in enumerate(source.splitlines(), 1)]
        self.pos = 0
        self.params: List[Param] = []
        self.pnames: set = set()

    # ------------------------------------------------------------------ plumbing
    def err(self, line: int, msg: str) -> None:
        self.errors.append(f"{self.filename}:{line}: error: {msg}")

    def _next_line(self) -> Optional[Tuple[int, str]]:
        while self.pos < len(self.lines):
            n, t = self.lines[self.pos]
            self.pos += 1
            if t:
                return n, t
        return None

    # ------------------------------------------------------------------ module / kernel
    def parse(self) -> List[Kernel]:
        kernels: List[Kernel] = []
        while True:
            item = self._next_line()
            if item is None:
                break
            n, t = item
            if t.split()[0] != "kernel":
                self.err(n, f"expected 'kernel', found '{t.split()[0]}'")
                continue
            k = self._kernel(n, t)
            if k is not None:
                if any(x.name == k.name for x in kernels):
                    self.err(n, f"duplicate kernel '{k.name}'")
                kernels.append(k)
        if not kernels and not self.errors:
            self.err(1, "no kernel found")
        return kernels

    def _kernel(self, n: int, first: str) -> Optional[Kernel]:
        # gather the header up to the matching ')'
        text, depth, opened = first, first.count("(") - first.count(")"), "(" in first
        while (not opened) or depth > 0:
            nxt = self._next_line()
            if nxt is None:
                self.err(n, "unterminated kernel header")
                return None
            text += " " + nxt[1]
            depth = text.count("(") - text.count(")")
            opened = "(" in text
        m = re.match(r"^kernel\s+([A-Za-z_]\w*)\s*\((.*)\)\s*(.*)$", text)
        if not m:
            self.err(n, "malformed kernel header; expected: kernel NAME(PARAM, ...)")
            return None
        name, plist, rest = m.group(1), m.group(2), m.group(3).strip()
        k = Kernel(name, [], [], "0", [], n, self.filename)
        self.params = k.params
        self.pnames = set()
        self._params(n, plist, k)
        # attribute lines up to '{'
        have_brace = False
        pending = rest
        while True:
            if pending:
                if pending.endswith("{"):
                    pending, have_brace = pending[:-1].strip(), True
                if pending:
                    self._attribute(n, pending, k)
                if have_brace:
                    break
            nxt = self._next_line()
            if nxt is None:
                self.err(n, f"kernel '{name}': missing '{{'")
                return None
            n, pending = nxt
        body, term = self._block(True)
        if term != "}":
            self.err(k.line, f"kernel '{name}': missing closing '}}'")
        k.body = body
        return k

    def _params(self, n: int, plist: str, k: Kernel) -> None:
        parts, depth, cur = [], 0, []
        for ch in plist:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            if ch == "," and depth == 0:
                parts.append("".join(cur).strip())
                cur = []
            else:
                cur.append(ch)
        if "".join(cur).strip() or parts:
            parts.append("".join(cur).strip())
        if len(parts) > 8:
            self.err(n, f"a kernel has at most 8 parameters (SR_ARG0..SR_ARG7), found {len(parts)}")
        for p in parts:
            if not p:
                self.err(n, "empty parameter")
                continue
            toks = p.split(None, 3)
            if len(toks) < 2:
                self.err(n, f"parameter '{p}': expected KIND NAME [ACCESS [EXTENT]]")
                continue
            kind, pname = toks[0], toks[1]
            if kind not in ("ptr", "u32", "i32"):
                self.err(n, f"parameter '{pname}': kind must be ptr, u32 or i32 (found '{kind}')"
                         + (" -- SF-G1 has no floating point" if kind in ("f32", "float", "f64") else ""))
                continue
            if not _IDENT.match(pname) or pname in _RESERVED or pname in ("wg_dim", "grid_dim"):
                self.err(n, f"parameter name '{pname}' is reserved or invalid")
                continue
            if pname in self.pnames:
                self.err(n, f"duplicate parameter '{pname}'")
                continue
            access, extent = "", None
            if len(toks) > 2:
                if kind != "ptr":
                    self.err(n, f"parameter '{pname}': only ptr parameters take an access mode and an extent")
                    continue
                access = toks[2]
                if access not in ("r", "w", "rw"):
                    self.err(n, f"parameter '{pname}': access must be r, w or rw (found '{access}')")
                    continue
                if len(toks) > 3:
                    extent = toks[3].strip()
                    if extent.startswith("(") and extent.endswith(")"):
                        extent = extent[1:-1].strip()
                    try:
                        expr.free_symbols(extent)
                    except expr.ExprError as e:
                        self.err(n, f"parameter '{pname}': bad extent expression: {e}")
                        continue
            elif kind == "ptr":
                access = "rw"
            self.pnames.add(pname)
            k.params.append(Param(pname, kind, access, extent, n))

    def _attribute(self, n: int, text: str, k: Kernel) -> None:
        head, _, rest = text.partition(" ")
        rest = rest.strip()
        try:
            if head == "shared":
                if not rest:
                    raise ValueError("`shared` needs an expression")
                expr.free_symbols(rest)
                k.shared = rest
            elif head == "require":
                m = re.match(r'^(.*?)\s*(?:"([^"]*)")?\s*$', rest)
                cond = (m.group(1) if m else rest).strip()
                if not cond:
                    raise ValueError('`require` needs EXPR ["message"]')
                expr.free_symbols(cond)
                k.requires.append((cond, (m.group(2) if m and m.group(2) else f"launch requirement failed: {cond}")))
            else:
                raise ValueError(f"unknown kernel attribute '{head}' (expected `shared` or `require`)")
        except (ValueError, expr.ExprError) as e:
            self.err(n, str(e))

    # ------------------------------------------------------------------ blocks and statements
    def _block(self, top: bool = False) -> Tuple[List[ir.Stmt], str]:
        stmts: List[ir.Stmt] = []
        while True:
            item = self._next_line()
            if item is None:
                return stmts, "eof"
            n, t = item
            if t == "}":
                return stmts, "}"
            if re.match(r"^\}\s*else\s*\{$", t):
                return stmts, "}else{"
            try:
                toks = _tokenize(t)
            except ValueError as e:
                self.err(n, str(e))
                continue
            s = self._statement(n, toks, t)
            if s is not None:
                stmts.append(s)

    def _statement(self, n: int, toks: List[Tok], text: str) -> Optional[ir.Stmt]:
        kind0, v0 = toks[0]
        if kind0 == "p" and v0 == "}":
            self.err(n, "unexpected '}'")
            return None
        if kind0 == "id" and v0 == "if":
            return self._if(n, toks)
        if kind0 == "id" and v0 == "loop":
            if [t for t in toks[1:]] != [("p", "{")]:
                self.err(n, "expected `loop {`")
                return None
            body, term = self._block()
            if term != "}":
                self.err(n, "`loop` block is not closed with '}'" if term == "eof" else "`else` without a matching `if`")
            return Loop(body=body, line=n)
        if kind0 == "id" and v0 == "else":
            self.err(n, "`else` must follow the closing brace of an `if` on the same line: `} else {`")
            return None
        if kind0 == "id" and v0 == "continue":
            self.err(n, "`continue` is not supported: a backward jump out of a divergent path would overrun the "
                        "path's reconvergence address and fault with F_RECONV; restructure the loop body with `if` "
                        "(docs/COMPILER.md 'Unsupported constructs')")
            return None
        if kind0 == "id" and v0 in ir.UNSUPPORTED_OPS and not (len(toks) > 1 and toks[1] == ("p", "=")):
            self.err(n, f"`{v0}` is not supported: {ir.UNSUPPORTED_OPS[v0]}")
            return None
        try:
            return self._simple(n, toks)
        except (ValueError, expr.ExprError) as e:
            self.err(n, str(e))
            return None

    def _if(self, n: int, toks: List[Tok]) -> Optional[ir.Stmt]:
        if len(toks) != 3 or toks[2] != ("p", "{"):
            self.err(n, "expected `if OPERAND {` (the condition is a variable, parameter, builtin or literal; "
                        "compute comparisons into a variable first)")
            # still consume the block to keep going
            self._block()
            return None
        try:
            cond = self._operand(toks[1])
        except ValueError as e:
            self.err(n, str(e))
            cond = Opd.const(0)
        then, term = self._block()
        els: List[ir.Stmt] = []
        if term == "}else{":
            els, term = self._block()
            if term == "}else{":
                self.err(n, "an `if` has at most one `else`")
        if term not in ("}",):
            self.err(n, "`if` block is not closed with '}'")
        return If(cond=cond, then=then, els=els, line=n)

    # ---- operands
    def _operand(self, tok: Tok) -> Opd:
        kind, v = tok
        if kind == "num":
            val = int(v.replace("_", ""), 0)
            if not -(1 << 31) <= val <= ir.MASK32:
                raise ValueError(f"integer literal {v} does not fit in 32 bits")
            return Opd.const(val)
        if kind == "id":
            if v in ir.BUILTINS:
                return Opd("builtin", v)
            if v in self.pnames:
                return Opd("param", v)
            if v in _RESERVED:
                raise ValueError(f"'{v}' is a keyword/operation name, not a value")
            return Opd("var", v)
        raise ValueError(f"expected an operand, found '{v}'")

    def _mem(self, toks: List[Tok], i: int) -> Tuple[Mem, int]:
        if i >= len(toks) or toks[i] != ("p", "["):
            raise ValueError("expected a memory operand like [addr] or [addr + 4]")
        i += 1
        if i >= len(toks):
            raise ValueError("unterminated memory operand")
        base = self._operand(toks[i])
        i += 1
        off = 0
        if i < len(toks) and toks[i] != ("p", "]"):
            kind, v = toks[i]
            if kind == "num" and v.startswith("-"):
                off = int(v.replace("_", ""), 0)
                i += 1
            elif kind == "p" and v in "+-" and i + 1 < len(toks) and toks[i + 1][0] == "num" \
                    and not toks[i + 1][1].startswith("-"):
                off = int(toks[i + 1][1].replace("_", ""), 0) * (1 if v == "+" else -1)
                i += 2
            else:
                raise ValueError("memory operand offset must be a literal: [addr + 4] or [addr - 4]")
        if i >= len(toks) or toks[i] != ("p", "]"):
            raise ValueError("expected ']' to close the memory operand")
        if not -(1 << 17) <= off < (1 << 17):
            raise ValueError(f"memory offset {off} does not fit the signed 18-bit immediate")
        return Mem(base, off), i + 1

    def _operand_list(self, toks: List[Tok], i: int, count: int, what: str) -> List[Opd]:
        out: List[Opd] = []
        while i < len(toks):
            out.append(self._operand(toks[i]))
            i += 1
            if i < len(toks):
                if toks[i] != ("p", ","):
                    raise ValueError(f"expected ',' between operands of `{what}`")
                i += 1
                if i >= len(toks):
                    raise ValueError(f"missing operand after ',' in `{what}`")
        if len(out) != count:
            raise ValueError(f"`{what}` takes {count} operand(s), found {len(out)}")
        return out

    def _simple(self, n: int, toks: List[Tok]) -> Optional[ir.Stmt]:
        kind0, v0 = toks[0]
        # assignment
        if kind0 == "id" and len(toks) >= 2 and toks[1] == ("p", "="):
            dst = v0
            if dst in ir.BUILTINS:
                raise ValueError(f"cannot assign to builtin '{dst}'")
            if dst in self.pnames:
                raise ValueError(f"cannot assign to parameter '{dst}' (parameters are read-only)")
            if dst in _RESERVED:
                raise ValueError(f"'{dst}' is a keyword/operation name and cannot be a variable")
            rhs = toks[2:]
            if not rhs:
                raise ValueError("missing right-hand side")
            if rhs[0][0] == "id" and rhs[0][1] in ir.UNSUPPORTED_OPS:
                raise ValueError(f"`{rhs[0][1]}` is not supported: {ir.UNSUPPORTED_OPS[rhs[0][1]]}")
            if rhs[0][0] == "id" and rhs[0][1] in ir.VALUE_OPS + ("mov",):
                op = rhs[0][1]
                if op in ir.LOAD_OPS:
                    mem, j = self._mem(rhs, 1)
                    if j != len(rhs):
                        raise ValueError(f"unexpected tokens after `{op}` operand")
                    return Load(dst=dst, space=op[-1], mem=mem, line=n)
                if op == "atomadd":
                    mem, j = self._mem(rhs, 1)
                    if j >= len(rhs) or rhs[j] != ("p", ","):
                        raise ValueError("`atomadd` takes [addr], value")
                    (val,) = self._operand_list(rhs, j + 1, 1, "atomadd")
                    return AtomAdd(dst=dst, mem=mem, value=val, line=n)
                arity = 3 if op in ir.TERNARY_OPS else 2 if op in ir.BINARY_OPS else 1
                args = self._operand_list(rhs, 1, arity, op)
                return Assign(dst=dst, op=op, args=args, line=n)
            if len(rhs) != 1:
                raise ValueError("expected a single operand or an operation: `x = a` or `x = add a, b`")
            return Assign(dst=dst, op="mov", args=[self._operand(rhs[0])], line=n)
        if kind0 != "id":
            raise ValueError(f"cannot parse statement starting with '{v0}'")
        if v0 in ("st.g", "st.s"):
            mem, j = self._mem(toks, 1)
            if j >= len(toks) or toks[j] != ("p", ","):
                raise ValueError(f"`{v0}` takes [addr], value")
            (val,) = self._operand_list(toks, j + 1, 1, v0)
            return Store(space=v0[-1], mem=mem, value=val, line=n)
        if v0 == "atomadd":
            mem, j = self._mem(toks, 1)
            if j >= len(toks) or toks[j] != ("p", ","):
                raise ValueError("`atomadd` takes [addr], value")
            (val,) = self._operand_list(toks, j + 1, 1, "atomadd")
            return AtomAdd(dst=None, mem=mem, value=val, line=n)
        if v0 in ("barrier", "fence", "return", "break"):
            if len(toks) != 1:
                raise ValueError(f"`{v0}` takes no operands")
            return {"barrier": Barrier, "fence": Fence, "return": Return, "break": Break}[v0](line=n)
        if v0 == "break_if":
            (c,) = self._operand_list(toks, 1, 1, "break_if")
            return BreakIf(cond=c, line=n)
        if v0 == "trap":
            if len(toks) != 2 or toks[1][0] != "num":
                raise ValueError("`trap` takes one literal code (0..65535)")
            code = int(toks[1][1].replace("_", ""), 0)
            if not 0 <= code <= 0xFFFF:
                raise ValueError("trap code must fit 16 bits (0..65535)")
            return Trap(code=code, line=n)
        if v0 in ir.VALUE_OPS:
            raise ValueError(f"`{v0}` produces a value: write `x = {v0} ...`")
        raise ValueError(f"unknown statement '{v0}'")


def parse_ir(source: str, filename: str = "<ir>") -> Module:
    p = _Parser(source, filename)
    kernels = p.parse()
    if p.errors:
        raise CompileError(p.errors)
    return Module(kernels, filename, source)
