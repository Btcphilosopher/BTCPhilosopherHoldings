"""Random structured-program generator for differential testing of the compiler.

Every generated kernel is *valid* (definitely-assigned variables, barriers only where the uniformity analysis
accepts them), *terminating* (loops count up to a small bound), *fault-free* (all addresses are masked into their
buffers) and *race-free* (each thread stores only to its own output row, shared memory is written to ``sh[tid]``
and read after a barrier, the only cross-thread writes are ``atomadd``s whose results are discarded).  A
mismatch between the compiled code and the interpreter is therefore a compiler (or simulator) bug.

Kernel shape::

    kernel fuzz(ptr out w, ptr inp r, ptr hist rw, u32 seed, u32 k0)   [shared 4*wg_dim]

``out``  OW words per thread (row = gtid), ``inp`` N words (read only, index masked), ``hist`` H words (atomadd).
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

from . import ir
from .ir import KernelBuilder, Param

OW = 6          # output words per thread
N_IN = 64       # input words (power of two)
N_HIST = 8      # histogram words (power of two)

BIN_OPS = ["add", "sub", "mul", "and", "or", "xor", "shl", "shr", "sar", "lt", "ltu", "le", "leu", "gt", "gtu",
           "ge", "geu", "eq", "ne"]
UN_OPS = ["not", "neg", "lnot", "bool", "mov"]
CONSTS = [0, 1, 2, 3, 4, 7, 8, 15, 31, 255, 1000, 0x1FFFF, 0x20000, -1, -2, -17, -131072, 0x7FFFFFFF, 0x80000000,
          0xFFFF0000, 0x12345678, 0xDEADBEEF]
BUILTIN_NU = ["tid", "gtid", "lane", "warp"]
BUILTIN_U = ["wg_id", "wg_dim", "grid_dim", "lanes"]


@dataclass
class FuzzCase:
    kernel: ir.Kernel
    text: str
    grid: int
    wg: int
    bufs: Dict[str, List[int]]
    args: List[object]
    uses_shared: bool
    pressure: bool
    seed: int


class _Gen:
    def __init__(self, rng: random.Random, pressure: bool, use_shared: bool, depth: int, nstmts: int) -> None:
        self.rng, self.pressure, self.use_shared = rng, pressure, use_shared
        self.depth, self.nstmts = depth, nstmts
        self.n = 0
        self.kb = KernelBuilder("fuzz", [Param("out", "ptr", "w"), Param("inp", "ptr", "r"),
                                         Param("hist", "ptr", "rw"), Param("seed", "u32"), Param("k0", "u32")],
                                shared="4*wg_dim" if use_shared else "0")
        self.reserved: Set[str] = set()
        self.uconds: List[str] = []
        self.pool: List[str] = []

    # ---- naming / operands
    def fresh(self, p: str = "v") -> str:
        self.n += 1
        return f"{p}{self.n}"

    def opd(self, assigned: Set[str]):
        r = self.rng.random()
        pool = sorted(assigned)
        if r < 0.55 and pool:
            if self.pressure and self.pool and self.rng.random() < 0.7:
                cand = [v for v in self.pool if v in assigned]
                if cand:
                    return self.rng.choice(cand)
            return self.rng.choice(pool)
        if r < 0.75:
            return self.rng.choice(CONSTS)
        if r < 0.9:
            return self.rng.choice(BUILTIN_NU + BUILTIN_U)
        return self.rng.choice(["seed", "k0"])

    def mutable(self, assigned: Set[str]) -> List[str]:
        return sorted(v for v in assigned if v not in self.reserved)

    def target(self, assigned: Set[str]) -> str:
        mu = self.mutable(assigned)
        if mu and self.rng.random() < 0.3:
            return self.rng.choice(mu)
        return self.fresh()

    # ---- statements
    def s_assign(self, assigned: Set[str]) -> None:
        kb, rng = self.kb, self.rng
        t = self.target(assigned)
        r = rng.random()
        if r < 0.6:
            op = rng.choice(BIN_OPS)
            kb.assign(t, op, self.opd(assigned), self.opd(assigned))
        elif r < 0.75:
            kb.assign(t, rng.choice(UN_OPS), self.opd(assigned))
        elif r < 0.9:
            kb.assign(t, "select", self.opd(assigned), self.opd(assigned), self.opd(assigned))
        else:
            kb.assign(t, "assume_uniform", self.opd(assigned))
        assigned.add(t)

    def s_load(self, assigned: Set[str]) -> None:
        kb = self.kb
        idx, p, t = self.fresh("i"), self.fresh("p"), self.target(assigned)
        kb.assign(idx, "and", self.opd(assigned), N_IN - 1)
        kb.assign(p, "lea", "inp", idx)
        kb.load(t, "g", p)
        assigned.add(t)

    def s_store(self, assigned: Set[str]) -> None:
        self.kb.store("g", "rowp", self.opd(assigned), 4 * self.rng.randrange(OW))

    def s_atomic(self, assigned: Set[str]) -> None:
        kb = self.kb
        h, p = self.fresh("h"), self.fresh("p")
        kb.assign(h, "and", self.opd(assigned), N_HIST - 1)
        kb.assign(p, "lea", "hist", h)
        if self.rng.random() < 0.25:
            kb.atomadd(p, self.opd(assigned), dst=self.fresh("old"))     # result unused -> compiler drops it (rd = r0)
        else:
            kb.atomadd(p, self.opd(assigned))

    def cond(self, assigned: Set[str]) -> str:
        c = self.fresh("c")
        self.kb.assign(c, self.rng.choice(BIN_OPS[9:]), self.opd(assigned), self.opd(assigned))
        return c

    def s_barrier_phase(self, assigned: Set[str]) -> None:
        kb = self.kb
        off, nb, c, noff, v = self.fresh("so"), self.fresh("nb"), self.fresh("nc"), self.fresh("no"), self.target(assigned)
        kb.assign(off, "shl", "tid", 2)
        kb.store("s", off, self.opd(assigned))
        kb.barrier()
        kb.assign(nb, "add", "tid", 1)
        kb.assign(c, "lt", nb, "wg_dim")
        kb.assign(nb, "select", c, nb, 0)
        kb.assign(noff, "shl", nb, 2)
        kb.load(v, "s", noff)
        kb.barrier()                                   # all neighbour reads done before the next write phase
        assigned.add(v)

    def s_if(self, assigned: Set[str], depth: int, uniform: bool, in_loop: bool, allow_break: bool = True) -> None:
        kb, rng = self.kb, self.rng
        if uniform and self.uconds and rng.random() < 0.3:
            c, cu = rng.choice(self.uconds), True
        else:
            c, cu = self.cond(assigned), False
        # arms start from the same entry set; afterwards only variables assigned in both arms are definite
        ctx = kb.if_(c)
        with ctx:
            a1 = self.block(set(assigned), depth - 1, uniform and cu, in_loop, True, allow_break)
        a2 = set(assigned)
        if rng.random() < 0.5:
            with ctx.else_():
                a2 = self.block(set(assigned), depth - 1, uniform and cu, in_loop, True, allow_break)
            assigned |= (a1 & a2)

    def s_guarded_break(self, assigned: Set[str], depth: int) -> None:
        """``if c { ...; [nested guarded break | break_if c2 | break] }`` [``else { ... }``]: an `if` whose arm leaves the
        enclosing loop, which forces the loop-exit reconvergence rule (docs/03 3.6) at every enclosing level."""
        kb, rng = self.kb, self.rng
        c = self.cond(assigned)
        ctx = kb.if_(c)
        with ctx:
            inner = set(assigned)
            for _ in range(rng.randint(0, 2)):
                self.s_assign(inner)
            r = rng.random()
            if depth > 1 and r < 0.45:
                self.s_guarded_break(inner, depth - 1)
                if rng.random() < 0.5:
                    self.s_assign(inner)
                    self.s_store(inner)
            elif r < 0.75:
                kb.break_if(self.cond(inner))
                self.s_assign(inner)
            else:
                kb.brk()
        if rng.random() < 0.5:
            with ctx.else_():
                inner = set(assigned)
                for _ in range(rng.randint(1, 3)):
                    self.s_assign(inner)
                if rng.random() < 0.4:
                    self.s_store(inner)

    def s_loop(self, assigned: Set[str], depth: int, uniform: bool, in_loop: bool) -> None:
        kb, rng = self.kb, self.rng
        i, b, d = self.fresh("li"), self.fresh("lb"), self.fresh("ld")
        self.reserved |= {i, b, d}
        use_uniform = uniform and self.uconds and rng.random() < 0.5
        if use_uniform:
            kb.assign(b, "add", rng.choice(self.uconds), rng.randint(0, 2))
        else:
            t = self.fresh("lt")
            kb.assign(t, "and", self.opd(assigned), 3)
            kb.assign(b, "add", t, rng.randint(0, 1))
        kb.assign(i, "mov", 0)
        assigned |= {i, b}
        with kb.loop():
            kb.assign(d, "ge", i, b)
            kb.break_if(d)
            inner = set(assigned) | {d}
            self.block(inner, depth - 1, use_uniform, True, False, allow_break=not use_uniform)
            kb.assign(i, "add", i, 1)

    def block(self, assigned: Set[str], depth: int, uniform: bool, in_loop: bool, nested: bool,
              allow_break: bool = True) -> Set[str]:
        kb, rng = self.kb, self.rng
        for _ in range(rng.randint(1, max(2, self.nstmts // (2 if nested else 1)))):
            if in_loop and allow_break and rng.random() < 0.16:
                self.s_guarded_break(assigned, rng.randint(1, 3))
                continue
            r = rng.random()
            if r < 0.38:
                self.s_assign(assigned)
            elif r < 0.48:
                self.s_load(assigned)
            elif r < 0.58:
                self.s_store(assigned)
            elif r < 0.64:
                self.s_atomic(assigned)
            elif r < 0.78 and depth > 0:
                self.s_if(assigned, depth, uniform, in_loop, allow_break)
            elif r < 0.86 and depth > 0:
                self.s_loop(assigned, depth, uniform, in_loop)
            elif r < 0.91 and self.use_shared and uniform:
                self.s_barrier_phase(assigned)
            elif r < 0.95 and in_loop and allow_break:
                if rng.random() < 0.5:
                    kb.break_if(self.cond(assigned))
                else:
                    c = self.cond(assigned)
                    with kb.if_(c):
                        self.s_assign(set(assigned))
                        kb.brk()
            elif r < 0.97:
                kb.fence()
            elif r < 0.985 and depth > 0:
                c = self.cond(assigned)
                with kb.if_(c):
                    kb.ret()
            else:
                self.s_assign(assigned)
        return assigned

    def build(self) -> ir.Kernel:
        kb, rng = self.kb, self.rng
        assigned: Set[str] = set()
        kb.assign("rb", "mul", "gtid", OW)
        kb.assign("rowp", "lea", "out", "rb")
        self.reserved |= {"rb", "rowp"}
        assigned |= {"rb", "rowp"}
        for k in range(rng.randint(1, 3)):                      # uniform conditions derived only from parameters,
            sh, u = self.fresh("us"), self.fresh("u")           # kept in 0..3 so they are safe loop bounds
            kb.assign(sh, "shr", "k0", 2 * k)
            kb.assign(u, "and", sh, 3)
            self.uconds.append(u)
            self.reserved |= {u, sh}
            assigned |= {u, sh}
        for nm, src in (("a0", "gtid"), ("a1", "tid"), ("a2", "seed")):
            kb.assign(nm, "mov", src)
            assigned.add(nm)
        if self.pressure:
            for _ in range(rng.randint(17, 22)):
                v = self.fresh("w")
                kb.assign(v, rng.choice(["add", "xor", "mul", "sub"]), rng.choice(BUILTIN_NU + ["seed"]),
                          rng.choice(CONSTS))
                self.pool.append(v)
                assigned.add(v)
        self.block(assigned, self.depth, True, False, False)
        if self.pressure and self.pool:
            acc = "acc"
            kb.assign(acc, "mov", 0)
            for v in self.pool:
                kb.assign(acc, "xor", acc, v)
                kb.assign(acc, "add", acc, rng.choice([1, 3, 5]))
            assigned.add(acc)
        pick = sorted(v for v in assigned if v not in self.reserved) or ["a0"]
        for j in range(OW):                                      # publish results of definitely-assigned variables
            kb.store("g", "rowp", rng.choice(pick), 4 * j)
        return kb.kernel


def random_case(rng: random.Random, max_wg: int = 32, lanes: int = 8, pressure: Optional[bool] = None,
                use_shared: Optional[bool] = None, depth: Optional[int] = None) -> FuzzCase:
    """One random launch: kernel, geometry, initial memory and arguments."""
    seed = rng.getrandbits(30)
    r = random.Random(seed)
    pressure = (r.random() < 0.2) if pressure is None else pressure
    use_shared = (r.random() < 0.45) if use_shared is None else use_shared
    g = _Gen(r, pressure, use_shared, depth if depth is not None else r.randint(1, 3), r.randint(4, 9))
    kernel = g.build()
    choices = [1, 2, 3, 5, lanes - 1, lanes, lanes + 1, 2 * lanes, 3 * lanes + 2, max_wg]
    wg = r.choice([w for w in choices if 1 <= w <= max_wg])
    grid = r.randint(1, 3)
    total = grid * wg
    bufs = {"out": [0xAAAAAAAA] * (total * OW), "inp": [r.getrandbits(32) for _ in range(N_IN)],
            "hist": [0] * N_HIST}
    args = ["out", "inp", "hist", r.getrandbits(32), r.getrandbits(32)]
    return FuzzCase(kernel, ir.format_kernel(kernel), grid, wg, bufs, args, use_shared, pressure, seed)
