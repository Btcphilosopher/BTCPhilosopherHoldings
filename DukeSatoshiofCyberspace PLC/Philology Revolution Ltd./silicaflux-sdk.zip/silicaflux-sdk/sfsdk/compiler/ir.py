"""Restricted intermediate representation (IR) for SF-G1 kernels.

The IR is a small *structured* language: mutable 32-bit variables, three-address value
operations, word loads/stores to global and shared memory, one atomic (``atomadd``), a barrier,
and structured control flow (``if``/``else``, ``loop`` with ``break``).  There are no types
beyond the parameter kinds; signedness is carried by the operation (``lt`` vs ``ltu``, ``shr`` vs ``sar``).

This module holds the data structures, a programmatic builder (used by the fuzzer and tests)
and a printer that emits the textual form accepted by :mod:`sfsdk.compiler.parser`.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterator, List, Optional, Tuple, Union

MASK32 = 0xFFFFFFFF

BUILTINS = ("tid", "wg_id", "wg_dim", "grid_dim", "gtid", "lane", "warp", "lanes", "shared_bytes")
# builtins whose value is the same for every thread of a workgroup (uniform)
UNIFORM_BUILTINS = ("wg_id", "wg_dim", "grid_dim", "lanes", "shared_bytes")
BUILTIN_SR = {"tid": "SR_TID", "wg_id": "SR_WG_ID", "wg_dim": "SR_WG_DIM", "grid_dim": "SR_GRID_DIM",
              "gtid": "SR_GTID", "lane": "SR_LANE_ID", "warp": "SR_WARP_ID", "lanes": "SR_LANES",
              "shared_bytes": "SR_SHARED_BYTES"}

BINARY_OPS = ("add", "sub", "mul", "and", "or", "xor", "shl", "shr", "sar",
              "lt", "ltu", "le", "leu", "gt", "gtu", "ge", "geu", "eq", "ne", "lea")
UNARY_OPS = ("not", "neg", "lnot", "bool", "mov", "assume_uniform")
TERNARY_OPS = ("select",)
LOAD_OPS = ("ld.g", "ld.s")
VALUE_OPS = BINARY_OPS + UNARY_OPS + TERNARY_OPS + LOAD_OPS + ("atomadd",)
STORE_OPS = ("st.g", "st.s")
KEYWORDS = ("kernel", "if", "else", "loop", "break", "break_if", "continue", "return", "barrier", "fence", "trap",
            "shared", "require") + STORE_OPS + ("atomadd",)
# spelled-out unsupported operations: rejected with an explanation (see docs/COMPILER.md)
UNSUPPORTED_OPS = {
    "div": "SF-G1 has no divide instruction",
    "udiv": "SF-G1 has no divide instruction",
    "sdiv": "SF-G1 has no divide instruction",
    "rem": "SF-G1 has no divide/remainder instruction",
    "urem": "SF-G1 has no divide/remainder instruction",
    "srem": "SF-G1 has no divide/remainder instruction",
    "mod": "SF-G1 has no divide/remainder instruction (use `and` with a power-of-two mask)",
    "mulh": "SF-G1 `mul` returns only the low 32 bits; there is no high-half multiply",
    "mulhu": "SF-G1 `mul` returns only the low 32 bits; there is no high-half multiply",
    "ld.b": "SF-G1 memory accesses are 32-bit words only (no byte access)",
    "st.b": "SF-G1 memory accesses are 32-bit words only (no byte access)",
    "ld.h": "SF-G1 memory accesses are 32-bit words only (no halfword access)",
    "st.h": "SF-G1 memory accesses are 32-bit words only (no halfword access)",
    "atomadd.s": "SF-G1 has no shared-memory atomics; `atomadd` is global-only",
    "atomic.s": "SF-G1 has no shared-memory atomics; `atomadd` is global-only",
    "atommax": "SF-G1 has exactly one atomic (`atomadd`); no atomic max (use a two-pass reduction)",
    "atommin": "SF-G1 has exactly one atomic (`atomadd`); no atomic min (use a two-pass reduction)",
    "atomsub": "SF-G1 has exactly one atomic (`atomadd`); use atomadd with the negated value",
    "atomand": "SF-G1 has exactly one atomic (`atomadd`)", "atomor": "SF-G1 has exactly one atomic (`atomadd`)",
    "atomxor": "SF-G1 has exactly one atomic (`atomadd`)", "atomxchg": "SF-G1 has exactly one atomic (`atomadd`)",
    "cas": "SF-G1 has no compare-and-swap", "atomcas": "SF-G1 has no compare-and-swap",
    "shfl": "SF-G1 has no warp shuffle", "shuffle": "SF-G1 has no warp shuffle",
    "vote": "SF-G1 has no warp vote/ballot", "ballot": "SF-G1 has no warp vote/ballot",
    "call": "SF-G1 has no function calls (no stack, no link register)",
    "fadd": "SF-G1 has no floating point", "fsub": "SF-G1 has no floating point",
    "fmul": "SF-G1 has no floating point", "fdiv": "SF-G1 has no floating point",
    "printf": "SF-G1 has no printf/IO",
    "jump": "SF-G1 control flow is structured in the IR (no goto/indirect branches)",
    "goto": "SF-G1 control flow is structured in the IR (no goto/indirect branches)",
    "while": "use `loop { ... break_if ... }`",
    "for": "use `loop { ... break_if ... }`",
}


@dataclass(frozen=True)
class Opd:
    """An operand: ``const`` (u32), ``var``, ``param`` or ``builtin``."""
    kind: str
    value: Union[int, str]

    @staticmethod
    def const(v: int) -> "Opd":
        return Opd("const", v & MASK32)

    @staticmethod
    def var(name: str) -> "Opd":
        return Opd("var", name)

    @property
    def is_const(self) -> bool:
        return self.kind == "const"


@dataclass(frozen=True)
class Mem:
    base: Opd
    off: int = 0


@dataclass
class Param:
    name: str
    kind: str                       # ptr | u32 | i32
    access: str = ""                # r | w | rw (ptr)
    extent: Optional[str] = None    # expression (words) for ptr
    line: int = 0


# ----------------------------------------------------------------------------- statements
@dataclass
class Stmt:
    line: int = 0


@dataclass
class Assign(Stmt):
    """``dst = op args`` for value ops (including ``mov``); loads and atomics use their own nodes."""
    dst: str = ""
    op: str = "mov"
    args: List[Opd] = field(default_factory=list)


@dataclass
class Load(Stmt):
    dst: str = ""
    space: str = "g"                # g | s
    mem: Mem = None                 # type: ignore[assignment]


@dataclass
class Store(Stmt):
    space: str = "g"
    mem: Mem = None                 # type: ignore[assignment]
    value: Opd = None               # type: ignore[assignment]


@dataclass
class AtomAdd(Stmt):
    dst: Optional[str] = None       # None: result discarded (rd = r0)
    mem: Mem = None                 # type: ignore[assignment]
    value: Opd = None               # type: ignore[assignment]


@dataclass
class Barrier(Stmt):
    pass


@dataclass
class Fence(Stmt):
    pass


@dataclass
class Trap(Stmt):
    code: int = 0


@dataclass
class Return(Stmt):
    pass


@dataclass
class Break(Stmt):
    pass


@dataclass
class BreakIf(Stmt):
    cond: Opd = None                # type: ignore[assignment]


@dataclass
class If(Stmt):
    cond: Opd = None                # type: ignore[assignment]
    then: List[Stmt] = field(default_factory=list)
    els: List[Stmt] = field(default_factory=list)


@dataclass
class Loop(Stmt):
    body: List[Stmt] = field(default_factory=list)


@dataclass
class Kernel:
    name: str
    params: List[Param]
    body: List[Stmt]
    shared: str = "0"
    requires: List[Tuple[str, str]] = field(default_factory=list)
    line: int = 0
    filename: str = "<ir>"

    def param(self, name: str) -> Optional[Param]:
        for p in self.params:
            if p.name == name:
                return p
        return None

    def param_index(self, name: str) -> int:
        for i, p in enumerate(self.params):
            if p.name == name:
                return i
        raise KeyError(name)


@dataclass
class Module:
    kernels: List[Kernel]
    filename: str = "<ir>"
    source: str = ""

    def kernel(self, name: Optional[str] = None) -> Kernel:
        if name is None:
            if len(self.kernels) != 1:
                raise KeyError("module has several kernels; pass kernel=NAME")
            return self.kernels[0]
        for k in self.kernels:
            if k.name == name:
                return k
        raise KeyError(f"no kernel named '{name}'")


# ----------------------------------------------------------------------------- traversal helpers
def walk(stmts: List[Stmt]) -> Iterator[Stmt]:
    """Pre-order traversal of every statement (including nested ones)."""
    for s in stmts:
        yield s
        if isinstance(s, If):
            yield from walk(s.then)
            yield from walk(s.els)
        elif isinstance(s, Loop):
            yield from walk(s.body)


def contains_direct_break(stmts: List[Stmt]) -> bool:
    """True if ``stmts`` contain a ``break``/``break_if`` that targets a loop *outside* of them
    (i.e. not nested inside a loop contained in ``stmts``)."""
    for s in stmts:
        if isinstance(s, (Break, BreakIf)):
            return True
        if isinstance(s, If) and (contains_direct_break(s.then) or contains_direct_break(s.els)):
            return True
    return False


def operands_of(s: Stmt) -> List[Opd]:
    """Operands read by a statement (not including nested statements)."""
    if isinstance(s, Assign):
        return list(s.args)
    if isinstance(s, Load):
        return [s.mem.base]
    if isinstance(s, Store):
        return [s.mem.base, s.value]
    if isinstance(s, AtomAdd):
        return [s.mem.base, s.value]
    if isinstance(s, BreakIf):
        return [s.cond]
    if isinstance(s, If):
        return [s.cond]
    return []


def defined_var(s: Stmt) -> Optional[str]:
    if isinstance(s, (Assign, Load)):
        return s.dst
    if isinstance(s, AtomAdd):
        return s.dst
    return None


# ----------------------------------------------------------------------------- builder
class KernelBuilder:
    """Programmatic construction of a kernel (used by the fuzzer and by tests).

    >>> kb = KernelBuilder("k", [Param("out", "ptr", "w"), Param("n", "u32")])
    >>> kb.assign("i", "mov", "gtid")
    >>> with kb.if_("i"):
    ...     kb.store("g", "out", "i")
    """

    def __init__(self, name: str, params: List[Param], shared: str = "0",
                 requires: Optional[List[Tuple[str, str]]] = None) -> None:
        self.kernel = Kernel(name, list(params), [], shared, list(requires or []))
        self._stack: List[List[Stmt]] = [self.kernel.body]
        self._pnames = {p.name for p in params}

    # operand coercion: int -> const; str -> builtin/param/var
    def opd(self, x: Union[int, str, Opd]) -> Opd:
        if isinstance(x, Opd):
            return x
        if isinstance(x, int):
            return Opd.const(x)
        if x in BUILTINS:
            return Opd("builtin", x)
        if x in self._pnames:
            return Opd("param", x)
        return Opd("var", x)

    def _add(self, s: Stmt) -> None:
        self._stack[-1].append(s)

    def assign(self, dst: str, op: str, *args: Union[int, str, Opd]) -> None:
        self._add(Assign(dst=dst, op=op, args=[self.opd(a) for a in args]))

    def load(self, dst: str, space: str, base: Union[int, str, Opd], off: int = 0) -> None:
        self._add(Load(dst=dst, space=space, mem=Mem(self.opd(base), off)))

    def store(self, space: str, base: Union[int, str, Opd], value: Union[int, str, Opd], off: int = 0) -> None:
        self._add(Store(space=space, mem=Mem(self.opd(base), off), value=self.opd(value)))

    def atomadd(self, base, value, dst: Optional[str] = None, off: int = 0) -> None:
        self._add(AtomAdd(dst=dst, mem=Mem(self.opd(base), off), value=self.opd(value)))

    def barrier(self) -> None:
        self._add(Barrier())

    def fence(self) -> None:
        self._add(Fence())

    def trap(self, code: int) -> None:
        self._add(Trap(code=code))

    def ret(self) -> None:
        self._add(Return())

    def brk(self) -> None:
        self._add(Break())

    def break_if(self, cond) -> None:
        self._add(BreakIf(cond=self.opd(cond)))

    def if_(self, cond):
        return _IfCtx(self, self.opd(cond))

    def loop(self):
        return _LoopCtx(self)


class _IfCtx:
    def __init__(self, kb: KernelBuilder, cond: Opd) -> None:
        self.kb, self.node = kb, If(cond=cond)
        self.kb._add(self.node)

    def __enter__(self):
        self.kb._stack.append(self.node.then)
        return self

    def __exit__(self, *a):
        self.kb._stack.pop()

    def else_(self):
        return _Block(self.kb, self.node.els)


class _LoopCtx:
    def __init__(self, kb: KernelBuilder) -> None:
        self.kb, self.node = kb, Loop()
        self.kb._add(self.node)

    def __enter__(self):
        self.kb._stack.append(self.node.body)
        return self

    def __exit__(self, *a):
        self.kb._stack.pop()


class _Block:
    def __init__(self, kb: KernelBuilder, body: List[Stmt]) -> None:
        self.kb, self.body = kb, body

    def __enter__(self):
        self.kb._stack.append(self.body)

    def __exit__(self, *a):
        self.kb._stack.pop()


# ----------------------------------------------------------------------------- printer
def _fmt_opd(o: Opd) -> str:
    if o.kind == "const":
        v = int(o.value)
        s = v - (1 << 32) if v >= 1 << 31 else v
        return str(s) if -(1 << 20) < s < (1 << 20) else hex(v)
    return str(o.value)


def _fmt_mem(m: Mem) -> str:
    if m.off == 0:
        return f"[{_fmt_opd(m.base)}]"
    return f"[{_fmt_opd(m.base)} {'+' if m.off > 0 else '-'} {abs(m.off)}]"


def format_stmts(stmts: List[Stmt], indent: int = 1) -> List[str]:
    pad = "    " * indent
    out: List[str] = []
    for s in stmts:
        if isinstance(s, Assign):
            if s.op == "mov":
                out.append(f"{pad}{s.dst} = {_fmt_opd(s.args[0])}")
            else:
                out.append(f"{pad}{s.dst} = {s.op} {', '.join(_fmt_opd(a) for a in s.args)}")
        elif isinstance(s, Load):
            out.append(f"{pad}{s.dst} = ld.{s.space} {_fmt_mem(s.mem)}")
        elif isinstance(s, Store):
            out.append(f"{pad}st.{s.space} {_fmt_mem(s.mem)}, {_fmt_opd(s.value)}")
        elif isinstance(s, AtomAdd):
            lhs = f"{s.dst} = " if s.dst else ""
            out.append(f"{pad}{lhs}atomadd {_fmt_mem(s.mem)}, {_fmt_opd(s.value)}")
        elif isinstance(s, Barrier):
            out.append(f"{pad}barrier")
        elif isinstance(s, Fence):
            out.append(f"{pad}fence")
        elif isinstance(s, Trap):
            out.append(f"{pad}trap {s.code}")
        elif isinstance(s, Return):
            out.append(f"{pad}return")
        elif isinstance(s, Break):
            out.append(f"{pad}break")
        elif isinstance(s, BreakIf):
            out.append(f"{pad}break_if {_fmt_opd(s.cond)}")
        elif isinstance(s, If):
            out.append(f"{pad}if {_fmt_opd(s.cond)} {{")
            out += format_stmts(s.then, indent + 1)
            if s.els:
                out.append(f"{pad}}} else {{")
                out += format_stmts(s.els, indent + 1)
            out.append(f"{pad}}}")
        elif isinstance(s, Loop):
            out.append(f"{pad}loop {{")
            out += format_stmts(s.body, indent + 1)
            out.append(f"{pad}}}")
        else:                                               # pragma: no cover
            raise TypeError(f"unknown statement {s!r}")
    return out


def format_kernel(k: Kernel) -> str:
    params = ", ".join(
        " ".join(x for x in (p.kind, p.name, p.access,
                             (f"({p.extent})" if p.extent and " " in p.extent else p.extent) if p.extent else "") if x)
        for p in k.params)
    lines = [f"kernel {k.name}({params})"]
    if k.shared not in ("0", ""):
        lines.append(f"    shared {k.shared}")
    for expr_, msg in k.requires:
        lines.append(f'    require {expr_} "{msg}"')
    lines.append("{")
    lines += format_stmts(k.body)
    lines.append("}")
    return "\n".join(lines) + "\n"
