"""Constant folding, single-definition constant propagation and constant-``if`` elimination."""
from __future__ import annotations

import copy
from typing import Dict, List

from . import ir, semantics
from .ir import (Assign, AtomAdd, Break, BreakIf, If, Kernel, Load, Loop, Mem, Opd, Stmt, Store, defined_var)
from .verify import prune_unreachable


def _map_operands(s: Stmt, f) -> None:
    if isinstance(s, Assign):
        s.args = [f(a) for a in s.args]
    elif isinstance(s, (Load,)):
        s.mem = Mem(f(s.mem.base), s.mem.off)
    elif isinstance(s, (Store, AtomAdd)):
        s.mem = Mem(f(s.mem.base), s.mem.off)
        s.value = f(s.value)
    elif isinstance(s, (BreakIf, If)):
        s.cond = f(s.cond)


def _fold_assigns(stmts: List[Stmt]) -> bool:
    changed = False
    for s in stmts:
        if isinstance(s, Assign):
            consts = [a.is_const for a in s.args]
            if s.op == "select" and s.args[0].is_const:
                s.args, s.op = [s.args[1] if s.args[0].value else s.args[2]], "mov"
                changed = True
            elif s.op != "mov" and all(consts):
                s.args = [Opd.const(semantics.evaluate(s.op, [int(a.value) for a in s.args]))]
                s.op = "mov"
                changed = True
            elif s.op == "assume_uniform" and len(s.args) == 1 and s.args[0].is_const:
                s.op = "mov"
                changed = True
        elif isinstance(s, If):
            changed |= _fold_assigns(s.then) | _fold_assigns(s.els)
        elif isinstance(s, Loop):
            changed |= _fold_assigns(s.body)
    return changed


def _propagate(k: Kernel) -> bool:
    defs: Dict[str, List[Stmt]] = {}
    for s in ir.walk(k.body):
        d = defined_var(s)
        if d:
            defs.setdefault(d, []).append(s)
    consts: Dict[str, Opd] = {}
    for v, ds in defs.items():
        if len(ds) == 1 and isinstance(ds[0], Assign) and ds[0].op == "mov" and ds[0].args[0].is_const:
            consts[v] = ds[0].args[0]
    if not consts:
        return False
    changed = False

    def sub(o: Opd) -> Opd:
        nonlocal changed
        if o.kind == "var" and o.value in consts:
            changed = True
            return consts[str(o.value)]
        return o

    for s in ir.walk(k.body):
        _map_operands(s, sub)
    return changed


def _simplify_ifs(stmts: List[Stmt]) -> List[Stmt]:
    """Replace ``if <literal>`` by the live arm; ``break_if <literal>`` by ``break`` or nothing."""
    out: List[Stmt] = []
    for s in stmts:
        if isinstance(s, If):
            s.then, s.els = _simplify_ifs(s.then), _simplify_ifs(s.els)
            if s.cond.is_const:
                out.extend(s.then if s.cond.value else s.els)
                continue
        elif isinstance(s, Loop):
            s.body = _simplify_ifs(s.body)
        elif isinstance(s, BreakIf) and s.cond.is_const:
            if s.cond.value:
                out.append(Break(line=s.line))
            continue
        out.append(s)
    return out


def optimize(kernel: Kernel, opt: bool = True) -> Kernel:
    """Return an optimised deep copy of ``kernel``.

    Literal ``if``/``break_if`` conditions are always eliminated (it is structural: the reconvergence
    address of an enclosing ``if`` depends on which ``break`` statements actually remain); folding and
    constant propagation only run when ``opt`` is true.
    """
    k = copy.deepcopy(kernel)
    sink: List[str] = []
    for _ in range(16):
        changed = False
        if opt:
            changed |= _fold_assigns(k.body)
            changed |= _propagate(k)
        before = repr(k.body)
        k.body = _simplify_ifs(k.body)
        k.body = prune_unreachable(k.body, sink, k.filename)
        changed |= repr(k.body) != before
        if not changed:
            break
    return k
