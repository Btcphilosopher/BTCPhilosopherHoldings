"""Value semantics of the IR operations (32-bit two's complement, wrap-around).

This is the meaning of the IR, written independently of the SF-G1 ISA.  The constant folder and the IR
interpreter share it; the tests check it against the ISA's ALU (``sfg1.alu``) so that a mistake here cannot
hide a codegen bug.
"""
from __future__ import annotations

from typing import Callable, Dict, Sequence

MASK32 = 0xFFFFFFFF


def s32(x: int) -> int:
    x &= MASK32
    return x - (1 << 32) if x & 0x80000000 else x


def _b(c: bool) -> int:
    return 1 if c else 0


BINARY: Dict[str, Callable[[int, int], int]] = {
    "add": lambda a, b: (a + b) & MASK32,
    "sub": lambda a, b: (a - b) & MASK32,
    "mul": lambda a, b: (a * b) & MASK32,
    "and": lambda a, b: a & b,
    "or": lambda a, b: a | b,
    "xor": lambda a, b: a ^ b,
    "shl": lambda a, b: (a << (b & 31)) & MASK32,
    "shr": lambda a, b: a >> (b & 31),
    "sar": lambda a, b: (s32(a) >> (b & 31)) & MASK32,
    "lt": lambda a, b: _b(s32(a) < s32(b)),
    "ltu": lambda a, b: _b(a < b),
    "le": lambda a, b: _b(s32(a) <= s32(b)),
    "leu": lambda a, b: _b(a <= b),
    "gt": lambda a, b: _b(s32(a) > s32(b)),
    "gtu": lambda a, b: _b(a > b),
    "ge": lambda a, b: _b(s32(a) >= s32(b)),
    "geu": lambda a, b: _b(a >= b),
    "eq": lambda a, b: _b(a == b),
    "ne": lambda a, b: _b(a != b),
    "lea": lambda a, b: (a + 4 * b) & MASK32,
}

UNARY: Dict[str, Callable[[int], int]] = {
    "not": lambda a: (~a) & MASK32,
    "neg": lambda a: (-a) & MASK32,
    "lnot": lambda a: _b(a == 0),
    "bool": lambda a: _b(a != 0),
    "mov": lambda a: a,
    "assume_uniform": lambda a: a,
}


def evaluate(op: str, args: Sequence[int]) -> int:
    """Evaluate a value op on u32 arguments; result is u32."""
    args = [a & MASK32 for a in args]
    if op in BINARY:
        return BINARY[op](args[0], args[1])
    if op in UNARY:
        return UNARY[op](args[0])
    if op == "select":
        return args[1] if args[0] else args[2]
    raise KeyError(op)
