"""Linear machine IR (LIR): SF-G1 instructions over virtual registers, and lowering from the structured IR.

Registers are integers: ``0`` is the hard-wired zero register ``r0``; ``1..15`` are physical registers (only
present after allocation); values ``>= V0`` are virtual registers.
"""
from __future__ import annotations

from typing import Dict, List, Optional

from ..isa import IMM18_MAX, IMM18_MIN
from . import ir
from .ir import (Assign, AtomAdd, Barrier, Break, BreakIf, Fence, If, Kernel, Load, Loop, Mem, Opd, Return,
                 Store, Trap, contains_direct_break)
from .semantics import MASK32, s32
from .verify import terminates

V0 = 100

R_OPS = {"add", "sub", "mul", "and", "or", "xor", "shl", "shr", "sar", "slt", "sltu"}
I_OPS = {"addi", "andi", "ori", "xori", "slti", "sltiu", "shli", "shri", "sari"}
PURE = R_OPS | I_OPS | {"li", "rdsr"}
COMMUTATIVE = {"add", "mul", "and", "or", "xor", "eq", "ne"}


class Ins:
    __slots__ = ("op", "dst", "srcs", "imm", "target", "reconv", "line", "tag")

    def __init__(self, op: str, dst: Optional[int] = None, srcs: Optional[List[int]] = None, imm=None,
                 target: Optional[str] = None, reconv: Optional[str] = None, line: int = 0, tag: str = "") -> None:
        self.op, self.dst, self.srcs, self.imm = op, dst, list(srcs or []), imm
        self.target, self.reconv, self.line, self.tag = target, reconv, line, tag

    def defs(self) -> List[int]:
        return [self.dst] if self.dst not in (None, 0) else []

    def uses(self) -> List[int]:
        return [r for r in self.srcs if r != 0]

    def copy(self) -> "Ins":
        return Ins(self.op, self.dst, list(self.srcs), self.imm, self.target, self.reconv, self.line, self.tag)

    def __repr__(self) -> str:                                   # pragma: no cover - debugging aid
        return f"Ins({self.op} dst={self.dst} srcs={self.srcs} imm={self.imm} t={self.target} r={self.reconv})"


def is_virtual(r: Optional[int]) -> bool:
    return r is not None and r >= V0


def fits18(v: int) -> bool:
    return IMM18_MIN <= v <= IMM18_MAX


class Lowerer:
    def __init__(self, kernel: Kernel) -> None:
        self.k = kernel
        self.code: List[Ins] = []
        self.next_v = V0
        self.varmap: Dict[str, int] = {}
        self.loops: List[str] = []
        self.nlabel = 0
        self.line = kernel.line
        self.remat = 0

    # ------------------------------------------------------------------ helpers
    def new(self) -> int:
        self.next_v += 1
        return self.next_v - 1

    def var(self, name: str) -> int:
        if name not in self.varmap:
            self.varmap[name] = self.new()
        return self.varmap[name]

    def emit(self, op: str, dst: Optional[int] = None, srcs=(), imm=None, target=None, reconv=None,
             tag: str = "") -> Ins:
        i = Ins(op, dst, list(srcs), imm, target, reconv, self.line, tag)
        self.code.append(i)
        return i

    def label(self, name: str) -> None:
        self.emit("label", target=name)

    def newlabel(self, kind: str) -> str:
        self.nlabel += 1
        return f"L{self.nlabel}_{kind}"

    def sr_of(self, o: Opd) -> str:
        if o.kind == "builtin":
            return ir.BUILTIN_SR[str(o.value)]
        return f"SR_ARG{self.k.param_index(str(o.value))}"

    def reg(self, o: Opd) -> int:
        """A register holding the operand's value (rematerialising constants/params/builtins)."""
        if o.kind == "var":
            return self.var(str(o.value))
        if o.kind == "const":
            if int(o.value) == 0:
                return 0
            t = self.new()
            self.emit("li", t, imm=int(o.value), tag="remat")
            self.remat += 1
            return t
        t = self.new()
        self.emit("rdsr", t, imm=self.sr_of(o), tag="remat")
        self.remat += 1
        return t

    # ------------------------------------------------------------------ statements
    def block(self, stmts: List[ir.Stmt]) -> None:
        for s in stmts:
            self.line = s.line or self.line
            self.stmt(s)

    def stmt(self, s: ir.Stmt) -> None:
        if isinstance(s, Assign):
            self.assign(s)
        elif isinstance(s, Load):
            base, off = self.address(s.mem)
            self.emit("ldg" if s.space == "g" else "lds", self.var(s.dst), [base], imm=off)
        elif isinstance(s, Store):
            base, off = self.address(s.mem)
            self.emit("stg" if s.space == "g" else "sts", None, [base, self.reg(s.value)], imm=off)
        elif isinstance(s, AtomAdd):
            base, off = self.address(s.mem)
            if off:
                t = self.new()
                self.emit("addi", t, [base], imm=off)
                base = t
            self.emit("atomadd", self.var(s.dst) if s.dst else 0, [base, self.reg(s.value)])
        elif isinstance(s, Barrier):
            self.emit("bar")
        elif isinstance(s, Fence):
            self.emit("fence")
        elif isinstance(s, Trap):
            self.emit("trap", imm=s.code)
        elif isinstance(s, Return):
            self.emit("exit")
        elif isinstance(s, Break):
            self.emit("bra", target=self.loops[-1])
        elif isinstance(s, BreakIf):
            if s.cond.is_const:
                if s.cond.value:
                    self.emit("bra", target=self.loops[-1])
            else:
                ex = self.loops[-1]
                self.emit("bnz", None, [self.reg(s.cond)], target=ex, reconv=ex)
        elif isinstance(s, If):
            self.if_(s)
        elif isinstance(s, Loop):
            self.loop(s)
        else:                                                    # pragma: no cover
            raise TypeError(s)

    def address(self, m: Mem):
        """(base register, byte offset) for ``ld/st``: constants that fit use r0 as the base."""
        b = m.base
        if b.is_const:
            c = s32(int(b.value)) + m.off
            if fits18(c):
                return 0, c
            return self.reg(Opd.const(c & MASK32)), 0
        return self.reg(b), m.off

    def if_(self, s: If) -> None:
        if s.cond.is_const:                                      # normally removed by fold.optimize
            self.block(s.then if s.cond.value else s.els)
            return
        if not s.then and not s.els:
            return
        c = self.reg(s.cond)
        lend = self.newlabel("endif")
        # docs/03 3.6: an `if` whose arms contain a break that leaves the enclosing loop reconverges at the loop exit
        reconv = self.loops[-1] if (self.loops and (contains_direct_break(s.then) or contains_direct_break(s.els))) \
            else lend
        if s.els:
            lelse = self.newlabel("else")
            self.emit("bz", None, [c], target=lelse, reconv=reconv)
            self.block(s.then)
            if not terminates(s.then):
                self.emit("bra", target=lend)
            self.label(lelse)
            self.block(s.els)
        else:
            self.emit("bz", None, [c], target=lend, reconv=reconv)
            self.block(s.then)
        self.label(lend)

    def loop(self, s: Loop) -> None:
        top, exit_ = self.newlabel("loop"), self.newlabel("loopend")
        self.label(top)
        self.loops.append(exit_)
        self.block(s.body)
        if not terminates(s.body):
            self.emit("bra", target=top)
        self.loops.pop()
        self.label(exit_)

    # ------------------------------------------------------------------ value operations
    def assign(self, s: Assign) -> None:
        d = self.var(s.dst)
        op, a = s.op, s.args
        if op in ("mov", "assume_uniform"):
            o = a[0]
            if o.kind == "const":
                self.emit("li", d, imm=int(o.value))
            elif o.kind == "var":
                self.emit("addi", d, [self.var(str(o.value))], imm=0)
            else:
                self.emit("rdsr", d, imm=self.sr_of(o))
        elif op == "not":
            self.emit("xori", d, [self.reg(a[0])], imm=-1)
        elif op == "neg":
            self.emit("sub", d, [0, self.reg(a[0])])
        elif op == "lnot":
            self.emit("sltiu", d, [self.reg(a[0])], imm=1)
        elif op == "bool":
            self.emit("sltu", d, [0, self.reg(a[0])])
        elif op == "select":
            self.select(d, a[0], a[1], a[2])
        else:
            self.binop(d, op, a[0], a[1])

    def rr(self, mn: str, d: int, a: Opd, b: Opd) -> None:
        ra = self.reg(a)
        rb = self.reg(b)
        self.emit(mn, d, [ra, rb])

    def ri(self, mn: str, d: int, a: Opd, imm: int) -> None:
        self.emit(mn, d, [self.reg(a)], imm=imm)

    def binop(self, d: int, op: str, a: Opd, b: Opd) -> None:
        if op in COMMUTATIVE and a.is_const and not b.is_const:
            a, b = b, a
        cb = s32(int(b.value)) if b.is_const else None
        if op == "add":
            return self.ri("addi", d, a, cb) if cb is not None and fits18(cb) else self.rr("add", d, a, b)
        if op == "sub":
            if cb is not None and fits18(-cb):
                return self.ri("addi", d, a, -cb)
            return self.rr("sub", d, a, b)
        if op == "mul":
            if cb is not None:
                if cb == 0:
                    self.emit("li", d, imm=0)
                    return
                if cb == 1:
                    self.emit("addi", d, [self.reg(a)], imm=0)
                    return
                if cb > 0 and cb & (cb - 1) == 0:
                    return self.ri("shli", d, a, cb.bit_length() - 1)
            return self.rr("mul", d, a, b)
        if op in ("and", "or", "xor"):
            if cb is not None and fits18(cb):
                return self.ri(op + "i", d, a, cb)
            return self.rr(op, d, a, b)
        if op in ("shl", "shr", "sar"):
            if cb is not None:
                return self.ri(op + "i", d, a, int(b.value) & 31)
            return self.rr(op, d, a, b)
        if op == "lt":
            return self.ri("slti", d, a, cb) if cb is not None and fits18(cb) else self.rr("slt", d, a, b)
        if op == "ltu":
            if cb is not None and fits18(cb):
                return self.ri("sltiu", d, a, cb)
            return self.rr("sltu", d, a, b)
        if op == "gt":
            return self.binop(d, "lt", b, a)
        if op == "gtu":
            return self.binop(d, "ltu", b, a)
        if op in ("le", "leu", "ge", "geu"):
            signed = op in ("le", "ge")
            base = "lt" if signed else "ltu"
            if op in ("le", "leu"):
                # a <= c  <=>  a < c+1  (when c+1 does not wrap)
                if cb is not None and ((signed and cb < 0x7FFFFFFF) or (not signed and int(b.value) < MASK32)) \
                        and fits18(cb + 1 if signed else s32(int(b.value) + 1)):
                    nb = Opd.const((int(b.value) + 1) & MASK32)
                    return self.binop(d, base, a, nb)
                t = self.new()
                self.binop(t, base, b, a)                        # !(b < a)
            else:
                t = self.new()
                self.binop(t, base, a, b)                        # !(a < b)
            self.emit("xori", d, [t], imm=1)
            return
        if op in ("eq", "ne"):
            t = self.new()
            if cb is not None and cb == 0:
                src = self.reg(a)
                self.emit("sltiu" if op == "eq" else "sltu", d, [src] if op == "eq" else [0, src],
                          imm=1 if op == "eq" else None)
                return
            if cb is not None and fits18(-cb):
                self.emit("addi", t, [self.reg(a)], imm=-cb)
            elif cb is not None and fits18(cb):
                self.emit("xori", t, [self.reg(a)], imm=cb)
            else:
                ra, rb = self.reg(a), self.reg(b)
                self.emit("xor", t, [ra, rb])
            self.emit("sltiu" if op == "eq" else "sltu", d, [t] if op == "eq" else [0, t],
                      imm=1 if op == "eq" else None)
            return
        if op == "lea":                                          # a + 4*b
            if b.is_const:
                off = (4 * int(b.value)) & MASK32
                if fits18(s32(off)):
                    return self.ri("addi", d, a, s32(off))
                return self.rr("add", d, a, Opd.const(off))
            t = self.new()
            self.emit("shli", t, [self.reg(b)], imm=2)
            if a.is_const and fits18(s32(int(a.value))):
                self.emit("addi", d, [t], imm=s32(int(a.value)))
            else:
                self.emit("add", d, [self.reg(a), t])
            return
        raise ValueError(f"cannot lower op {op}")                # pragma: no cover

    def select(self, d: int, c: Opd, a: Opd, b: Opd) -> None:
        """d = c != 0 ? a : b  ==  b ^ ((a ^ b) & -(c != 0))"""
        rc = self.reg(c)
        n, m, x = self.new(), self.new(), self.new()
        self.emit("sltu", n, [0, rc])
        self.emit("sub", m, [0, n])
        ra, rb = self.reg(a), self.reg(b)
        self.emit("xor", x, [ra, rb])
        self.emit("and", x, [x, m])
        self.emit("xor", d, [rb, x])

    # ------------------------------------------------------------------ driver
    def run(self) -> List[Ins]:
        self.block(self.k.body)
        self.line = self.k.line
        self.emit("exit")
        return self.code


def lower(kernel: Kernel) -> Lowerer:
    lw = Lowerer(kernel)
    lw.run()
    return lw
