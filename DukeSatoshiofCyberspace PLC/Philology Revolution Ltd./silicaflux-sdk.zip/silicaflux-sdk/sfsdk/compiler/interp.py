"""Per-thread interpreter of the IR: the semantic oracle that compiled code is checked against.

It knows nothing about SF-G1 registers, masks or reconvergence.  Each thread runs the structured program
sequentially; the threads of a workgroup advance in lock-step *phases* separated by barriers (every live thread
runs to its next ``barrier`` or to the end, then all waiting threads are released together).  Atomics are applied
immediately, in ascending thread order within a phase -- one valid ordering, which is all that race-free kernels
(the only ones with a defined result) can observe.

Errors mirror what the hardware would fault on: misaligned or out-of-range accesses, and a barrier reached at
different sites by threads of one warp (F_BAR_DIVERGENT).
"""
from __future__ import annotations

import struct
from typing import Dict, Generator, List, Optional, Sequence

from . import ir, semantics
from .ir import (Assign, AtomAdd, Barrier, Break, BreakIf, Fence, If, Kernel, Load, Loop, Mem, Opd, Return, Store, Trap)

MASK32 = 0xFFFFFFFF
POISON = 0xDEADBEEF


class InterpError(Exception):
    pass


class _Thread:
    def __init__(self, k: Kernel, args: Sequence[int], tid: int, wg_id: int, grid: int, wg: int, lanes: int,
                 gmem: bytearray, shared: bytearray, shared_bytes: int, budget: List[int]) -> None:
        self.k, self.args, self.tid, self.wg_id = k, list(args), tid, wg_id
        self.grid, self.wg, self.lanes = grid, wg, lanes
        self.gmem, self.shared, self.shared_bytes = gmem, shared, shared_bytes
        self.env: Dict[str, int] = {}
        self.budget = budget
        self.pidx = {p.name: i for i, p in enumerate(k.params)}

    # ---- operands
    def val(self, o: Opd) -> int:
        if o.kind == "const":
            return int(o.value)
        if o.kind == "var":
            try:
                return self.env[str(o.value)]
            except KeyError:
                raise InterpError(f"thread {self.tid}: variable '{o.value}' read before assignment") from None
        if o.kind == "param":
            return self.args[self.pidx[str(o.value)]] & MASK32
        b = o.value
        if b == "tid":
            return self.tid
        if b == "wg_id":
            return self.wg_id
        if b == "wg_dim":
            return self.wg
        if b == "grid_dim":
            return self.grid
        if b == "gtid":
            return (self.wg_id * self.wg + self.tid) & MASK32
        if b == "lane":
            return self.tid % self.lanes
        if b == "warp":
            return self.tid // self.lanes
        if b == "lanes":
            return self.lanes
        if b == "shared_bytes":
            return self.shared_bytes
        raise InterpError(f"unknown builtin {b}")                   # pragma: no cover

    def addr(self, m: Mem, space: str) -> int:
        a = (self.val(m.base) + m.off) & MASK32
        mem, name = (self.gmem, "global") if space == "g" else (self.shared, "shared")
        if a & 3:
            raise InterpError(f"thread {self.tid} wg {self.wg_id}: misaligned {name} access at {a:#x}")
        if a + 4 > len(mem):
            raise InterpError(f"thread {self.tid} wg {self.wg_id}: {name} access at {a:#x} out of range "
                              f"(size {len(mem)})")
        return a

    # ---- execution
    def step(self) -> None:
        self.budget[0] -= 1
        if self.budget[0] < 0:
            raise InterpError("step limit exceeded (infinite loop?)")

    def block(self, stmts: List[ir.Stmt]) -> Generator:
        for s in stmts:
            sig = yield from self.stmt(s)
            if sig:
                return sig
        return None

    def stmt(self, s: ir.Stmt) -> Generator:
        self.step()
        if isinstance(s, Assign):
            self.env[s.dst] = semantics.evaluate(s.op, [self.val(a) for a in s.args])
        elif isinstance(s, Load):
            mem = self.gmem if s.space == "g" else self.shared
            self.env[s.dst] = struct.unpack_from("<I", mem, self.addr(s.mem, s.space))[0]
        elif isinstance(s, Store):
            mem = self.gmem if s.space == "g" else self.shared
            a = self.addr(s.mem, s.space)
            struct.pack_into("<I", mem, a, self.val(s.value))
        elif isinstance(s, AtomAdd):
            a = self.addr(s.mem, "g")
            old = struct.unpack_from("<I", self.gmem, a)[0]
            struct.pack_into("<I", self.gmem, a, (old + self.val(s.value)) & MASK32)
            if s.dst:
                self.env[s.dst] = old
        elif isinstance(s, Barrier):
            yield s
        elif isinstance(s, Fence):
            pass
        elif isinstance(s, Trap):
            raise InterpError(f"thread {self.tid} wg {self.wg_id}: trap {s.code}")
        elif isinstance(s, Return):
            return "return"
        elif isinstance(s, Break):
            return "break"
        elif isinstance(s, BreakIf):
            if self.val(s.cond):
                return "break"
        elif isinstance(s, If):
            sig = yield from self.block(s.then if self.val(s.cond) else s.els)
            if sig:
                return sig
        elif isinstance(s, Loop):
            while True:
                sig = yield from self.block(s.body)
                if sig == "break":
                    break
                if sig == "return":
                    return sig
                self.step()
        return None

    def run(self) -> Generator:
        yield from self.block(self.k.body)


def interpret(kernel: Kernel, grid: int, wg: int, args: Sequence[int], gmem: bytearray, *, lanes: int = 8,
              shared_bytes: int = 0, max_steps: int = 2_000_000) -> None:
    """Run ``kernel`` over a ``grid`` x ``wg`` launch, modifying ``gmem`` in place."""
    if len(args) != len(kernel.params):
        raise InterpError(f"kernel '{kernel.name}' takes {len(kernel.params)} argument(s), got {len(args)}")
    budget = [max_steps * max(1, grid * wg)]
    for wg_id in range(grid):
        shared = bytearray(struct.pack("<I", POISON) * (shared_bytes // 4))
        threads = [_Thread(kernel, args, t, wg_id, grid, wg, lanes, gmem, shared, shared_bytes, budget)
                   for t in range(wg)]
        gens = {t.tid: t.run() for t in threads}
        alive = list(gens)
        while alive:
            waiting: Dict[int, Barrier] = {}
            for tid in alive:
                try:
                    waiting[tid] = next(gens[tid])
                except StopIteration:
                    pass
            # threads of one warp must all be at the same barrier site
            sites: Dict[int, Barrier] = {}
            for tid, b in waiting.items():
                w = tid // lanes
                if w in sites and sites[w] is not b:
                    raise InterpError(f"workgroup {wg_id}: warp {w} reached different barriers (divergent barrier)")
                sites[w] = b
            alive = list(waiting)
