"""Small integer expression evaluator (never uses ``eval``).

Used by the assembler for immediates and by the runtime for kernel metadata expressions
(shared-memory size, buffer extents, launch requirements).

Grammar, lowest to highest precedence (comparison and logical operators bind *looser* than
the bitwise operators, as in Python)::

    ||   &&   == != < <= > >=   |   ^   &   << >>   + -   * / %   unary - + ~ !   ( )   %hi(x) %lo(x)

``/`` and ``%`` truncate toward zero.  Comparison and logical operators yield 0 or 1.
"""
from __future__ import annotations

import re
from typing import Callable, Dict, List, Optional, Tuple, Union

MASK32 = 0xFFFFFFFF


class ExprError(Exception):
    pass


_TOKEN = re.compile(
    r"\s*(?:(?P<num>0[xX][0-9a-fA-F_]+|0[bB][01_]+|\d[\d_]*)"
    r"|(?P<hilo>%(?:hi|lo)\b)"
    r"|(?P<sym>[A-Za-z_.$][\w.$]*)"
    r"|(?P<op>\|\||&&|==|!=|<=|>=|<<|>>|[-+*/%&|^~!<>()]))", re.IGNORECASE)

_BIN: Dict[str, Tuple[int, Callable[[int, int], int]]] = {}


def _tdiv(a: int, b: int) -> int:
    q = abs(a) // abs(b)
    return q if (a < 0) == (b < 0) else -q


_BIN.update({
    "||": (0, lambda a, b: int(bool(a) or bool(b))),
    "&&": (1, lambda a, b: int(bool(a) and bool(b))),
    "==": (2, lambda a, b: int(a == b)), "!=": (2, lambda a, b: int(a != b)),
    "<": (2, lambda a, b: int(a < b)), "<=": (2, lambda a, b: int(a <= b)),
    ">": (2, lambda a, b: int(a > b)), ">=": (2, lambda a, b: int(a >= b)),
    "|": (3, lambda a, b: a | b), "^": (4, lambda a, b: a ^ b), "&": (5, lambda a, b: a & b),
    "<<": (6, lambda a, b: a << b), ">>": (6, lambda a, b: a >> b),
    "+": (7, lambda a, b: a + b), "-": (7, lambda a, b: a - b),
    "*": (8, lambda a, b: a * b), "/": (8, _tdiv), "%": (8, lambda a, b: a - b * _tdiv(a, b)),
})

Symbols = Union[Dict[str, int], Callable[[str], Optional[int]]]


class _Parser:
    def __init__(self, text: str, symbols: Symbols, lenient: bool = False) -> None:
        self.text, self.symbols, self.lenient = text, symbols, lenient
        self.toks: List[Tuple[str, str]] = []
        s, pos = text.strip(), 0
        while pos < len(s):
            m = _TOKEN.match(s, pos)
            if not m or m.end() == pos:
                raise ExprError(f"bad character {s[pos:pos + 1]!r} in expression '{text}'")
            pos = m.end()
            self.toks.append((m.lastgroup, m.group(m.lastgroup)))
        self.i = 0

    def _peek(self):
        return self.toks[self.i] if self.i < len(self.toks) else None

    def _take(self):
        t = self._peek()
        if t is None:
            raise ExprError(f"unexpected end of expression '{self.text}'")
        self.i += 1
        return t

    def parse(self) -> int:
        if not self.toks:
            raise ExprError("empty expression")
        v = self._binary(0)
        if self._peek() is not None:
            raise ExprError(f"unexpected '{self._peek()[1]}' in expression '{self.text}'")
        return v

    def _binary(self, min_prec: int) -> int:
        lhs = self._unary()
        while True:
            t = self._peek()
            if t is None or t[0] != "op" or t[1] not in _BIN or _BIN[t[1]][0] < min_prec:
                return lhs
            op = self._take()[1]
            rhs = self._binary(_BIN[op][0] + 1)
            if self.lenient:                    # syntax-only pass: values are placeholders
                lhs = 1
                continue
            if op in ("/", "%") and rhs == 0:
                raise ExprError("division by zero")
            if op in ("<<", ">>") and not 0 <= rhs <= 64:
                raise ExprError(f"shift amount {rhs} out of range 0..64")
            lhs = _BIN[op][1](lhs, rhs)

    def _unary(self) -> int:
        kind, val = self._take()
        if kind == "op":
            if val == "-":
                return -self._unary()
            if val == "+":
                return self._unary()
            if val == "~":
                return ~self._unary()
            if val == "!":
                return int(not self._unary())
            if val == "(":
                v = self._binary(0)
                if self._take() != ("op", ")"):
                    raise ExprError("missing ')'")
                return v
            raise ExprError(f"unexpected '{val}' in expression '{self.text}'")
        if kind == "num":
            return int(val.replace("_", ""), 0)
        if kind == "hilo":
            if self._take() != ("op", "("):
                raise ExprError(f"{val} needs '('")
            v = self._binary(0)
            if self._take() != ("op", ")"):
                raise ExprError("missing ')'")
            return (v & MASK32) >> 10 if val.lower() == "%hi" else (v & 0x3FF)
        r = self.symbols(val) if callable(self.symbols) else self.symbols.get(val)
        if r is None:
            raise ExprError(f"undefined symbol '{val}'")
        return r


def evaluate(text: str, symbols: Symbols) -> int:
    return _Parser(text, symbols).parse()


def free_symbols(text: str) -> List[str]:
    """Identifiers mentioned in ``text``.  Raises :class:`ExprError` if the text is not a well-formed expression
    (a syntax-only parse: identifiers are not resolved and values are not computed)."""
    p = _Parser(text, lambda _name: 1, lenient=True)
    p.parse()
    return [v for k, v in p.toks if k == "sym"]
