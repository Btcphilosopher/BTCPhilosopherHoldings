"""Tunable microarchitecture parameters of the SF-G1 hardware model.

None of these values are architectural: any setting must give the same *results* (memory
contents, per-warp commit trace, PERF_ISSUED, PERF_LANE_OPS) for a race-free kernel; only
timing (PERF_CYCLES, watchdog, interleaving across warps) changes.  The defaults are chosen to
be *different from the reference simulator* (which has zero-latency memory and a loose
round-robin scheduler) so that agreement between the two is a meaningful check.
"""
from __future__ import annotations

from dataclasses import dataclass, replace

SCHEDULERS = ("oldest", "lrr", "gto")
DISPATCH_POLICIES = ("least_loaded", "lowest", "round_robin")


@dataclass(frozen=True)
class HwParams:
    scheduler: str = "oldest"            # oldest-ready-first | lrr (loose round robin) | gto (greedy-then-oldest)
    reset_cycles: int = 7                # STATUS.READY=0 duration after reset (reference: 4)
    # -- execution pipeline (cycles spent in the EX stage) ------------------------------------------------
    alu_latency: int = 2
    mul_latency: int = 4
    sreg_latency: int = 2                # rdsr
    branch_latency: int = 2              # branch / jump / exit / bar / trap / fence unit
    agu_latency: int = 2                 # address generation + checks of memory instructions
    # -- memory system ----------------------------------------------------------------------------------------
    global_latency: int = 24
    shared_latency: int = 4
    shared_banks: int = 8
    segment_bytes: int = 32              # coalescing granule of the global port
    global_ports: int = 1                # transactions the global memory accepts per cycle (device wide)
    mem_queue_depth: int = 8             # outstanding memory requests per warp (posted stores + loads)
    global_jitter: int = 0               # extra 0..N cycles of (pseudo-random) latency per global request
    shared_jitter: int = 0               # same for shared requests; both make completion order across warps vary
    # -- launch / dispatch ------------------------------------------------------------------------------------
    desc_fetch_cycles: int = 3           # descriptor read + validation
    imem_copy_words_per_cycle: int = 4   # instruction-memory fill rate (EGs fill in parallel)
    dispatch_policy: str = "least_loaded"
    dispatch_per_cycle: int = 2          # workgroups the launch unit can place per cycle
    dispatch_latency: int = 2            # register zeroing / stack init before a warp may issue
    barrier_release_latency: int = 1
    retire_latency: int = 1
    # -- misc ---------------------------------------------------------------------------------------------------
    seed: int = 0x5F1C5EED               # power-up memory pattern
    starvation_limit: int = 256          # a ready warp older than this always wins (forward progress guard)

    def __post_init__(self) -> None:
        if self.scheduler not in SCHEDULERS:
            raise ValueError(f"scheduler must be one of {SCHEDULERS}")
        if self.dispatch_policy not in DISPATCH_POLICIES:
            raise ValueError(f"dispatch_policy must be one of {DISPATCH_POLICIES}")
        for name in ("alu_latency", "mul_latency", "sreg_latency", "branch_latency", "agu_latency", "global_latency",
                     "shared_latency", "shared_banks", "segment_bytes", "global_ports", "mem_queue_depth",
                     "desc_fetch_cycles", "imem_copy_words_per_cycle", "dispatch_per_cycle", "dispatch_latency",
                     "barrier_release_latency", "retire_latency", "starvation_limit"):
            if getattr(self, name) < 1:
                raise ValueError(f"{name} must be >= 1")
        if self.reset_cycles < 1:
            raise ValueError("reset_cycles must be >= 1")
        if self.global_jitter < 0 or self.shared_jitter < 0:
            raise ValueError("jitter must be >= 0")
        if self.segment_bytes % 4:
            raise ValueError("segment_bytes must be a multiple of 4")

    def with_(self, **kw) -> "HwParams":
        return replace(self, **kw)
