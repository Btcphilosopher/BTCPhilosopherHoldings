"""Memory system of the hardware model: per-warp in-order request queues, a coalescing global
port and a banked shared-memory port per execution group.

Key properties (all permitted by SF-G1 docs/04 4.5 and 4.8):

* **Posted stores.**  A store is accepted into the issuing warp's queue and the warp moves on; the
  data reaches memory when the request *completes*, ``latency`` cycles after the port started it.
* **Per-warp program order (C2).**  A warp's requests start in queue order and complete in order
  per address space, so a later load by the same thread always sees an earlier store of its own.
* **Different warps interleave arbitrarily**: ports serve the oldest queue head first, so the
  order in which two warps' accesses reach memory is *not* the reference simulator's issue order.
* **Coalescing.**  A warp-wide global access takes one port cycle per distinct 32-byte segment of
  its active lanes (atomics: one per active lane).  Shared accesses take as many cycles as the
  busiest bank holds distinct words.
* Within one request, lanes are applied in ascending lane order (stores: highest lane wins;
  ``atomadd``: lane i sees the sum of lower lanes), exactly as docs/04 4.4 requires.
"""
from __future__ import annotations

import heapq
import random
import struct
from collections import deque
from typing import Deque, Dict, List, Optional, Set

from .params import HwParams

_M = 0xFFFFFFFF
_U32 = struct.Struct("<I")


class MemReq:
    __slots__ = ("warp", "eg", "kind", "space", "lanes", "addrs", "vals", "base", "enq", "txns", "fl",
                 "result", "seq")

    def __init__(self, warp, eg: int, kind: str, space: str, lanes: List[int], addrs: List[int],
                 vals: Optional[List[int]], base: int, enq: int, txns: int, fl) -> None:
        self.warp, self.eg, self.kind, self.space = warp, eg, kind, space
        self.lanes, self.addrs, self.vals, self.base = lanes, addrs, vals, base
        self.enq, self.txns, self.fl = enq, txns, fl
        self.result: Optional[List[int]] = None
        self.seq = 0


class MemSystem:
    def __init__(self, p: HwParams, gmem: bytearray, smems: List[bytearray], counters: Dict[str, int]) -> None:
        self.p = p
        self.gmem = gmem
        self.smems = smems
        self.cnt = counters
        self.gports: List[int] = [0] * p.global_ports      # cycle at which each port is next free
        self.sports: List[int] = [0] * len(smems)
        self.heap: list = []                                # (complete_at, seq, req)
        self.qwarps: Set = set()                            # warps with not-yet-started requests
        self._seq = 0
        self.inflight = 0
        self._rng = random.Random(p.seed ^ 0xC0FFEE)       # request-latency jitter (a model of DRAM/bank timing variation)

    # ------------------------------------------------------------------ cost model
    def global_txns(self, kind: str, addrs: List[int]) -> int:
        if kind == "atomadd":
            return max(1, len(addrs))                       # RMWs are serialised at the memory
        seg = self.p.segment_bytes
        return max(1, len({a // seg for a in addrs}))

    def shared_txns(self, addrs: List[int]) -> int:
        banks: Dict[int, Set[int]] = {}
        nb = self.p.shared_banks
        for a in addrs:
            banks.setdefault((a >> 2) % nb, set()).add(a >> 2)
        return max(1, max(len(s) for s in banks.values())) if banks else 1

    # ------------------------------------------------------------------ queueing
    def enqueue(self, req: MemReq) -> None:
        w = req.warp
        w.mq.append(req)
        w.outstanding += 1
        self.qwarps.add(w)
        self.inflight += 1
        if w.outstanding > self.cnt["max_mem_queue_depth"]:
            self.cnt["max_mem_queue_depth"] = w.outstanding
        if req.space == "g":
            self.cnt["global_requests"] += 1
            self.cnt["global_transactions"] += req.txns
            if req.kind != "atomadd":
                self.cnt["global_lane_accesses"] += len(req.lanes)
                self.cnt["global_ldst_transactions"] += req.txns
        else:
            self.cnt["shared_requests"] += 1
            self.cnt["shared_bank_conflict_cycles"] += req.txns - 1

    def busy(self) -> bool:
        return self.inflight > 0

    # ------------------------------------------------------------------ port arbitration
    def _start(self, w, req: MemReq, port_list: List[int], idx: int, now: int) -> None:
        latency = self.p.global_latency if req.space == "g" else self.p.shared_latency
        jitter = self.p.global_jitter if req.space == "g" else self.p.shared_jitter
        if jitter:
            latency += self._rng.randrange(jitter + 1)
        port_list[idx] = now + req.txns
        done = now + req.txns - 1 + latency
        space_i = 0 if req.space == "g" else 1
        done = max(done, w.last_complete[space_i] + 1)       # in-order completion per warp and space
        w.last_complete[space_i] = done
        self._seq += 1
        req.seq = self._seq
        heapq.heappush(self.heap, (done, self._seq, req))
        w.mq.popleft()

    def arbitrate(self, now: int) -> None:
        if not self.qwarps:
            return
        # global port(s): oldest request first, ties -> lowest EG, lowest warp slot
        g = sorted(((w.mq[0].enq, w.eg, w.slot, id(w), w) for w in self.qwarps if w.mq and w.mq[0].space == "g"),
                   key=lambda t: t[:4])
        for i, free_at in enumerate(self.gports):
            if g and free_at <= now:
                w = g.pop(0)[4]
                self._start(w, w.mq[0], self.gports, i, now)
        # one shared-memory port per execution group
        for e, free_at in enumerate(self.sports):
            if free_at > now:
                continue
            cands = sorted(((w.mq[0].enq, w.slot, id(w), w) for w in self.qwarps
                            if w.eg == e and w.mq and w.mq[0].space == "s"), key=lambda t: t[:3])
            if cands:
                w = cands[0][3]
                self._start(w, w.mq[0], self.sports, e, now)
        for w in [w for w in self.qwarps if not w.mq]:
            self.qwarps.discard(w)

    # ------------------------------------------------------------------ completion
    def complete(self, now: int) -> List[MemReq]:
        """Apply every request whose time has come; returns loads/atomics whose data is now available."""
        ready: List[MemReq] = []
        while self.heap and self.heap[0][0] <= now:
            _, _, req = heapq.heappop(self.heap)
            self._apply(req)
            req.warp.outstanding -= 1
            self.inflight -= 1
            if req.kind in ("ldg", "lds", "atomadd"):
                ready.append(req)
        return ready

    def _apply(self, req: MemReq) -> None:
        mem = self.gmem if req.space == "g" else self.smems[req.eg]
        base = 0 if req.space == "g" else req.base
        k = req.kind
        if k in ("ldg", "lds"):
            req.result = [_U32.unpack_from(mem, base + a)[0] for a in req.addrs]
        elif k in ("stg", "sts"):
            for a, v in zip(req.addrs, req.vals):            # ascending lane order: highest lane wins
                _U32.pack_into(mem, base + a, v)
        else:                                                # atomadd: lane by lane, each RMW indivisible
            olds = []
            for a, v in zip(req.addrs, req.vals):
                old = _U32.unpack_from(mem, a)[0]
                _U32.pack_into(mem, a, (old + v) & _M)
                olds.append(old)
            req.result = olds

    def abort_all(self) -> None:
        """Fault or reset: drop everything in flight (memory after a fault is unspecified)."""
        self.heap.clear()
        for w in list(self.qwarps):
            w.mq.clear()
        self.qwarps.clear()
        self.inflight = 0
        self.gports = [0] * len(self.gports)
        self.sports = [0] * len(self.sports)
