"""SF-G1 hardware model: a cycle-level microarchitectural model (see docs/HWMODEL.md).

It is a model written in Python from the normative SF-G1 specification -- not RTL, not
synthesisable, and it makes no claim about silicon timing.
"""
from .params import HwParams
from .transport import HwModelTransport

__all__ = ["HwModelTransport", "HwParams"]
