"""Lane ALU of the hardware model.

One function per ALU function *name* in ``spec/sf_g1_isa.json`` (``alu_functions``).  The module
checks at import time that the table covers exactly the names the ISA defines, so a new ALU
function added to the JSON cannot be silently ignored by the model.
"""
from __future__ import annotations

from typing import Callable, Dict

from ..isa import ISA

_M = 0xFFFFFFFF
_SIGN = 0x80000000


def _signed(x: int) -> int:
    return (x ^ _SIGN) - _SIGN


LANE_ALU: Dict[str, Callable[[int, int], int]] = {
    "ADD": lambda a, b: (a + b) & _M,
    "SUB": lambda a, b: (a + (~b & _M) + 1) & _M,                 # two's-complement add of the complement
    "MUL": lambda a, b: (a * b) & _M,                            # low half of the product (sign-agnostic)
    "AND": lambda a, b: a & b,
    "OR": lambda a, b: a | b,
    "XOR": lambda a, b: a ^ b,
    "SHL": lambda a, b: (a << (b & 31)) & _M,
    "SHR": lambda a, b: a >> (b & 31),
    "SAR": lambda a, b: (_signed(a) >> (b & 31)) & _M,
    "SLT": lambda a, b: int((a ^ _SIGN) < (b ^ _SIGN)),          # signed compare via sign-bit flip
    "SLTU": lambda a, b: int(a < b),
    "PASSB": lambda a, b: b,
}

if set(LANE_ALU) != set(ISA.alu_functions):                       # pragma: no cover - guards spec drift
    raise ImportError("hwmodel ALU table does not match spec/sf_g1_isa.json alu_functions: "
                      f"{sorted(set(LANE_ALU) ^ set(ISA.alu_functions))}")
