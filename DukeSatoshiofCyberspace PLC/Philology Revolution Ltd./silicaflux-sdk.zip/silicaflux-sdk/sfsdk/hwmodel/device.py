"""Cycle-level microarchitectural model of an SF-G1 implementation.

This is a *model* (Python), not RTL: it is not synthesisable and makes no claim about silicon
timing, area or power.  It is a second, structurally different implementation of the SF-G1
specification, written from the normative documents, so that "the same binary gives the same
results on the reference simulator and on this model" is a real check (docs/HWMODEL.md).

Per execution group (EG) the model has: warp slots with private register files and a
hardware-style SIMT stack, a scheduler issuing at most one warp instruction per cycle, a
one-instruction-per-warp pipeline (FD -> RD -> EX -> [MEM] -> WB), a banked shared memory and
a share of a coalescing global memory port, and barrier hardware.  The device adds a launch
unit (descriptor validation, instruction-memory fill, workgroup dispatch) and the BAR0
register block.  Everything software can observe is the architecture of docs/02..09; the
rest is free to differ and does (see HwParams).
"""
from __future__ import annotations

import json
import math
import random
import struct
from collections import deque
from typing import Callable, Dict, List, Optional, Tuple

from ..isa import ISA, Instr, decode
from ..spec import Config, MASK32, device_spec
from .alu import LANE_ALU
from .memory import MemReq, MemSystem
from .params import HwParams
from .simt import HwSimtStack

_D = device_spec()
FC = _D.faults
LE = _D.launch_errors
_SR = ISA.special_registers

# device states
S_RESET, S_IDLE, S_LAUNCHING, S_RUNNING, S_FAULTED = range(5)
# warp states
W_READY, W_BARRIER, W_DONE = range(3)
# pipeline stages of an in-flight instruction
P_RD, P_EX, P_MEM, P_WB = range(4)

INT_DONE, INT_FAULT, INT_LAUNCH_ERR, INT_HOST_ERR = 1, 2, 4, 8
_U32 = struct.Struct("<I")


class Fault(Exception):
    def __init__(self, code: int, pc: int = 0, data: int = 0, lane: Optional[int] = None) -> None:
        super().__init__(_D.error_names.get(code, str(code)))
        self.code, self.pc, self.data, self.lane = code, pc, data & MASK32, lane


class Inflight:
    __slots__ = ("ins", "word", "pc", "active", "lanes", "stage", "next", "va", "vb", "vals", "req", "queued",
                 "waiting", "drain", "target", "reconv", "cond", "finishes")

    def __init__(self, ins: Instr, word: int, pc: int, active: int, lanes: List[int], nxt: int) -> None:
        self.ins, self.word, self.pc, self.active, self.lanes = ins, word, pc, active, lanes
        self.stage, self.next = P_RD, nxt
        self.va: List[int] = []
        self.vb: List[int] = []
        self.vals: List[int] = []
        self.req: Optional[MemReq] = None
        self.queued = False
        self.waiting = False
        self.drain = False
        self.target = self.reconv = self.cond = 0
        self.finishes = False


class Workgroup:
    __slots__ = ("wg_id", "eg", "slot", "shared_bytes", "smem_base", "warps", "retire_at")

    def __init__(self, wg_id: int, eg: int, slot: int, shared_bytes: int, smem_base: int) -> None:
        self.wg_id, self.eg, self.slot = wg_id, eg, slot
        self.shared_bytes, self.smem_base = shared_bytes, smem_base
        self.warps: List["Warp"] = []
        self.retire_at: Optional[int] = None


class Warp:
    __slots__ = ("wg", "index", "slot", "eg", "regs", "stack", "state", "ready_at", "seq", "fl", "mq",
                 "outstanding", "last_complete")

    def __init__(self, wg: Workgroup, index: int, slot: int, eg: int, regs: List[List[int]], stack: HwSimtStack,
                 ready_at: int) -> None:
        self.wg, self.index, self.slot, self.eg = wg, index, slot, eg
        self.regs, self.stack = regs, stack
        self.state = W_READY
        self.ready_at = ready_at
        self.seq = 0
        self.fl: Optional[Inflight] = None
        self.mq: deque = deque()
        self.outstanding = 0
        self.last_complete = [0, 0]


class EG:
    __slots__ = ("index", "warps", "wgs", "smem", "last", "last_warp")

    def __init__(self, index: int, cfg: Config) -> None:
        self.index = index
        self.warps: List[Optional[Warp]] = [None] * cfg.warps_per_eg
        self.wgs: List[Optional[Workgroup]] = [None] * cfg.wg_slots_per_eg
        self.smem = bytearray(cfg.smem_bytes_per_eg)
        self.last = cfg.warps_per_eg - 1
        self.last_warp: Optional[Warp] = None


_COUNTER_KEYS = (
    "cycles", "issued", "lane_ops", "issue_slots_idle", "stall_memory", "stall_barrier", "stall_pipeline",
    "stall_stack_resolve", "stall_no_ready_warp", "shared_requests", "shared_bank_conflict_cycles",
    "global_requests", "global_transactions", "global_lane_accesses", "global_ldst_transactions",
    "max_mem_queue_depth", "wg_dispatch_cycles", "stack_resolve_cycles")


class HwDevice:
    def __init__(self, cfg: Config, params: Optional[HwParams] = None, trace: bool = False) -> None:
        self.cfg = cfg
        self.p = params or HwParams()
        self.trace_on = trace
        self.events: List[Tuple[int, int, int, str]] = []
        # power-up: global memory holds a pseudo-random pattern (NOT the reference's 0xDEADBEEF)
        self.gmem = bytearray(random.Random(self.p.seed).randbytes(cfg.gmem_bytes))
        self._srng = random.Random(self.p.seed ^ 0x9E3779B9)
        self.egs = [EG(i, cfg) for i in range(cfg.num_eg)]
        self.cnt: Dict[str, int] = {}
        self._clear_counters()
        self.mem = MemSystem(self.p, self.gmem, [e.smem for e in self.egs], self.cnt)
        self.cycle_total = 0
        self.scratch = 0
        self._caps = cfg.caps_regs()
        self._regs_rd: Dict[str, Callable[[], int]] = {
            "ID": lambda: _D.device_id, "VERSION": lambda: _D.version_word, "CFG_HASH": cfg.cfg_hash,
            "CTRL": lambda: 0, "STATUS": self._status, "INT_STATUS": lambda: self.int_status,
            "INT_ENABLE": lambda: self.int_enable, "LAUNCH_ADDR": lambda: self.launch_addr,
            "DOORBELL": lambda: 0, "LAUNCH_ERR": lambda: self.launch_err, "WDOG_LIMIT": lambda: self.wdog_limit,
            "FAULT_CODE": lambda: self.fault["code"], "FAULT_LOC": lambda: self.fault["loc"],
            "FAULT_PC": lambda: self.fault["pc"], "FAULT_WG": lambda: self.fault["wg"],
            "FAULT_MASK": lambda: self.fault["mask"], "FAULT_DATA": lambda: self.fault["data"],
            "PERF_CYCLES": lambda: self.perf_cycles & MASK32, "PERF_ISSUED": lambda: self.perf_issued & MASK32,
            "PERF_LANE_OPS": lambda: self.perf_lane_ops & MASK32, "WG_DISPATCHED": lambda: self.wg_dispatched,
            "WG_COMPLETED": lambda: self.wg_completed, "SCRATCH": lambda: self.scratch,
        }
        self._flag_known = 0
        for bit in _D.desc_flags.values():
            self._flag_known |= 1 << bit
        self.int_status = 0
        self._reset_state()

    # ===================================================================== reset
    def _clear_counters(self) -> None:
        self.cnt.clear()
        for k in _COUNTER_KEYS:
            self.cnt[k] = 0
        for i in range(self.cfg.num_eg):
            self.cnt[f"eg{i}_busy_cycles"] = 0

    def _reset_state(self) -> None:
        """Everything a (soft or hard) reset clears.  Global memory is not touched."""
        self.state = S_RESET
        self.reset_left = self.p.reset_cycles
        self.int_status = 0
        self.int_enable = 0
        self.launch_addr = 0
        self.launch_latched = 0
        self.launch_err = 0
        self.wdog_limit = self.cfg.wdog_reset_ticks
        self.done = False
        self.fault = dict(code=0, loc=0, pc=0, wg=0, mask=0, data=0)
        self.perf_cycles = self.perf_issued = self.perf_lane_ops = 0
        self.wg_dispatched = self.wg_completed = 0
        self.elapsed = 0
        self.scratch = 0
        self._clear_counters()
        self.decoded: List[Optional[Instr]] = []
        self.code: List[int] = []
        self.code_words = 0
        self.entry_pc = 0
        self.args = [0] * self.cfg.num_args
        self.grid_dim = self.wg_dim = self.shared_bytes = self.flags = 0
        self.next_wg = 0
        self.dispatch_rr = 0
        self.lphase = self.lcount = self.lleft = 0
        self._faults: list = []
        self.mem.abort_all()
        for eg in self.egs:
            eg.warps = [None] * self.cfg.warps_per_eg
            eg.wgs = [None] * self.cfg.wg_slots_per_eg
            eg.last = self.cfg.warps_per_eg - 1
            eg.last_warp = None

    # ===================================================================== register block
    @property
    def ready(self) -> bool:
        return self.state != S_RESET

    @property
    def busy(self) -> bool:
        return self.state in (S_LAUNCHING, S_RUNNING)

    @property
    def irq(self) -> bool:
        return bool(self.int_status & self.int_enable)

    @property
    def active(self) -> bool:
        return self.state in (S_RESET, S_LAUNCHING, S_RUNNING)

    def _status(self) -> int:
        return (int(self.ready) | int(self.busy) << 1 | int(self.done) << 2
                | int(self.state == S_FAULTED) << 3 | int(self.irq) << 4)

    def _host_err(self) -> None:
        self.int_status |= INT_HOST_ERR

    def reg_read(self, off: int) -> int:
        if off < 0 or off & 3 or off not in _D.reg_by_offset:
            self._host_err()
            return 0
        name = _D.reg_by_offset[off]["name"]
        if name in self._caps:
            return self._caps[name]
        return self._regs_rd[name]() & MASK32

    def reg_write(self, off: int, val: int) -> None:
        val &= MASK32
        if off < 0 or off & 3 or off not in _D.reg_by_offset:
            self._host_err()
            return
        if not self.ready:
            return                                            # valid writes are ignored while resetting
        reg = _D.reg_by_offset[off]
        name = reg["name"]
        if reg["access"] == "RO":
            return
        if name == "CTRL":
            if val & 1:
                self._reset_state()
        elif name == "INT_STATUS":
            self.int_status &= ~val & 0xF                      # write-1-to-clear
        elif name == "INT_ENABLE":
            self.int_enable = val & 0xF
        elif name == "LAUNCH_ADDR":
            self.launch_addr = val
        elif name == "WDOG_LIMIT":
            self.wdog_limit = val
        elif name == "SCRATCH":
            self.scratch = val
        elif name == "DOORBELL" and val & 1:
            self._doorbell()

    def _doorbell(self) -> None:
        if self.busy:
            return self._launch_error(LE["LE_BUSY"])
        if self.state == S_FAULTED:
            return self._launch_error(LE["LE_FAULTED"])
        self.launch_err = 0
        self.done = False
        self.perf_cycles = self.perf_issued = self.perf_lane_ops = 0
        self.wg_dispatched = self.wg_completed = 0
        self.elapsed = 0
        self._clear_counters()
        self.launch_latched = self.launch_addr
        for eg in self.egs:
            eg.last = self.cfg.warps_per_eg - 1
            eg.last_warp = None
        self.lphase, self.lcount = 0, 0
        self.state = S_LAUNCHING

    def _launch_error(self, code: int) -> None:
        self.launch_err = code
        self.int_status |= INT_LAUNCH_ERR

    # ===================================================================== host aperture
    def mem_read(self, addr: int, n: int) -> Optional[bytes]:
        if not self.ready or self.busy or addr < 0 or n < 0 or addr + n > len(self.gmem):
            self._host_err()
            return None
        return bytes(self.gmem[addr:addr + n])

    def mem_write(self, addr: int, data: bytes) -> bool:
        if not self.ready or self.busy or addr < 0 or addr + len(data) > len(self.gmem):
            self._host_err()
            return False
        self.gmem[addr:addr + len(data)] = data
        return True

    # ===================================================================== time
    def run(self, max_ticks: int) -> int:
        n = 0
        while n < max_ticks and self.active:
            self.cycle()
            n += 1
        return n

    def cycle(self) -> None:
        self.cycle_total += 1
        now = self.cycle_total
        st = self.state
        if st == S_RESET:
            self.reset_left -= 1
            if self.reset_left <= 0:
                self.state = S_IDLE
            return
        if st == S_LAUNCHING:
            self.perf_cycles += 1
            self.elapsed += 1
            self.cnt["cycles"] = self.perf_cycles
            self._launch_cycle()
            return
        if st != S_RUNNING:
            return
        self.perf_cycles += 1
        self.elapsed += 1
        self.cnt["cycles"] = self.perf_cycles
        self._faults = []
        for req in self.mem.complete(now):
            fl = req.fl
            fl.vals = req.result
            fl.stage, fl.next, fl.waiting = P_WB, now + 1, False
        self.mem.arbitrate(now)
        for eg in self.egs:
            for w in eg.warps:
                if w is not None and w.fl is not None:
                    try:
                        self._step(eg, w, now)
                    except Fault as f:
                        self._faults.append((eg.index, w.slot, f, w))
        for eg in self.egs:
            self._issue_one(eg, now)
        self._dispatch(now)
        self._retire(now)
        if self._faults:
            self._latch_fault(*min(self._faults, key=lambda t: (t[0], t[1])))
            return
        if self.next_wg >= self.grid_dim and self.wg_completed >= self.grid_dim and not self.mem.busy():
            self.state = S_IDLE
            self.done = True
            self.int_status |= INT_DONE
            return
        if self.wdog_limit and self.elapsed >= self.wdog_limit:
            self._latch_watchdog()

    # ===================================================================== launch unit
    def _validate(self) -> Tuple[int, Optional[list]]:
        cfg, a = self.cfg, self.launch_latched
        dsz = _D.desc_size_words * 4
        if a & 3:
            return LE["LE_ALIGN"], None
        if a + dsz > cfg.gmem_bytes:
            return LE["LE_RANGE"], None
        w = list(struct.unpack_from(f"<{_D.desc_size_words}I", self.gmem, a))
        W = _D.desc_words
        magic, vf = w[W["MAGIC"]], w[W["VERSION_FLAGS"]]
        code_addr, code_words, entry = w[W["CODE_ADDR"]], w[W["CODE_WORDS"]], w[W["ENTRY_PC"]]
        grid, wgd, shared = w[W["GRID_DIM"]], w[W["WG_DIM"]], w[W["SHARED_BYTES"]]
        checks = (
            (magic != _D.desc_magic, "LE_MAGIC"),
            ((vf >> 16) != _D.desc_version, "LE_VERSION"),
            (((vf & 0xFFFF) & ~self._flag_known) != 0, "LE_RESERVED"),
            (code_addr & 3 != 0, "LE_ALIGN"),
            (code_words == 0 or code_words > cfg.imem_words, "LE_CODE_SIZE"),
            (code_addr + 4 * code_words > cfg.gmem_bytes, "LE_RANGE"),
            (entry >= code_words, "LE_ENTRY"),
            (grid == 0 or grid > cfg.max_grid_dim or wgd == 0 or wgd > cfg.max_wg_threads, "LE_DIMS"),
            (shared & 3 != 0, "LE_ALIGN"),
            (shared > cfg.wg_slot_smem_bytes, "LE_SHARED"),
        )
        for bad, name in checks:
            if bad:
                return LE[name], None
        return 0, w

    def _launch_cycle(self) -> None:
        self.lcount += 1
        if self.lphase == 0:
            if self.lcount < self.p.desc_fetch_cycles:
                return
            err, w = self._validate()
            if err:
                self.state = S_IDLE
                self._launch_error(err)
                return
            W = _D.desc_words
            words = w[W["CODE_WORDS"]]
            self.code = list(struct.unpack_from(f"<{words}I", self.gmem, w[W["CODE_ADDR"]]))
            self.decoded = [decode(x) for x in self.code]          # pre-decoded into the instruction memories
            self.code_words, self.entry_pc = words, w[W["ENTRY_PC"]]
            self.grid_dim, self.wg_dim, self.shared_bytes = w[W["GRID_DIM"]], w[W["WG_DIM"]], w[W["SHARED_BYTES"]]
            self.flags = w[W["VERSION_FLAGS"]] & 0xFFFF
            self.args = w[W["ARG0"]:W["ARG0"] + self.cfg.num_args]
            self.lphase = 1
            self.lleft = max(1, math.ceil(words / self.p.imem_copy_words_per_cycle))
            return
        self.lleft -= 1
        if self.lleft <= 0:
            self.next_wg = 0
            self.state = S_RUNNING

    def _choose_eg(self, nwarps: int) -> Optional[EG]:
        ok = [e for e in self.egs if None in e.wgs and sum(1 for w in e.warps if w is None) >= nwarps]
        if not ok:
            return None
        pol = self.p.dispatch_policy
        if pol == "lowest":
            return ok[0]
        if pol == "least_loaded":
            return min(ok, key=lambda e: (sum(1 for w in e.warps if w is not None), e.index))
        n = len(self.egs)                                           # round_robin
        for k in range(n):
            e = self.egs[(self.dispatch_rr + k) % n]
            if e in ok:
                self.dispatch_rr = (e.index + 1) % n
                return e
        return None

    def _dispatch(self, now: int) -> None:
        if self.next_wg >= self.grid_dim:
            return
        cfg, L = self.cfg, self.cfg.lanes
        nwarps = (self.wg_dim + L - 1) // L
        placed = 0
        while placed < self.p.dispatch_per_cycle and self.next_wg < self.grid_dim:
            eg = self._choose_eg(nwarps)
            if eg is None:
                break
            slot = eg.wgs.index(None)
            base = slot * cfg.wg_slot_smem_bytes
            wg = Workgroup(self.next_wg, eg.index, slot, self.shared_bytes, base)
            n = cfg.wg_slot_smem_bytes
            if self.flags & (1 << _D.desc_flags["SMEM_ZERO"]):
                eg.smem[base:base + n] = bytes(n)
            else:
                eg.smem[base:base + n] = self._srng.randbytes(n)         # undefined contents: random, not poison
            free = [i for i, w in enumerate(eg.warps) if w is None]
            for k in range(nwarps):
                nthreads = min(L, self.wg_dim - k * L)
                stack = HwSimtStack(cfg.simt_stack_depth, cfg.rpc_none)
                stack.start(self.entry_pc, (1 << nthreads) - 1)
                w = Warp(wg, k, free[k], eg.index, [[0] * L for _ in range(cfg.num_regs)], stack,
                         now + self.p.dispatch_latency)
                wg.warps.append(w)
                eg.warps[free[k]] = w
            eg.wgs[slot] = wg
            self.next_wg += 1
            self.wg_dispatched += 1
            placed += 1
        if placed:
            self.cnt["wg_dispatch_cycles"] += 1

    def _retire(self, now: int) -> None:
        for eg in self.egs:
            resident = False
            for i, wg in enumerate(eg.wgs):
                if wg is None:
                    continue
                resident = True
                if wg.retire_at is not None and now >= wg.retire_at:
                    for w in wg.warps:
                        eg.warps[w.slot] = None
                    eg.wgs[i] = None
                    self.wg_completed += 1
            if resident:
                self.cnt[f"eg{eg.index}_busy_cycles"] += 1

    # ===================================================================== scheduler / issue
    def _pick(self, eg: EG, now: int) -> Optional[Warp]:
        cands = [w for w in eg.warps if w is not None and w.state == W_READY and w.fl is None and w.ready_at <= now]
        if not cands:
            return None
        p = self.p
        oldest = min(cands, key=lambda w: (w.ready_at, w.slot))
        if now - oldest.ready_at > p.starvation_limit:
            return oldest                                          # forward-progress guard
        if p.scheduler == "oldest":
            return oldest
        if p.scheduler == "gto":
            return eg.last_warp if eg.last_warp in cands else oldest
        n = len(eg.warps)                                          # lrr: first ready slot after the last issued
        ids = {id(w) for w in cands}
        for k in range(1, n + 1):
            w = eg.warps[(eg.last + k) % n]
            if w is not None and id(w) in ids:
                return w
        return oldest                                              # pragma: no cover

    def _issue_one(self, eg: EG, now: int) -> None:
        resident = any(w is not None for w in eg.warps)
        w = self._pick(eg, now)
        if w is None:
            if resident:
                self.cnt["issue_slots_idle"] += 1
                self.cnt[self._stall_reason(eg, now)] += 1
            return
        eg.last, eg.last_warp = w.slot, w
        try:
            self._fetch(eg, w, now)
        except Fault as f:
            self._faults.append((eg.index, w.slot, f, w))

    def _stall_reason(self, eg: EG, now: int) -> str:
        mem = pipe = resolve = bar = False
        for w in eg.warps:
            if w is None or w.state == W_DONE:
                continue
            if w.state == W_BARRIER:
                bar = True
            elif w.fl is not None:
                if w.fl.stage == P_MEM:
                    mem = True
                else:
                    pipe = True
            elif w.ready_at > now:
                resolve = True
        if mem:
            return "stall_memory"
        if pipe:
            return "stall_pipeline"
        if resolve:
            return "stall_stack_resolve"
        if bar:
            return "stall_barrier"
        return "stall_no_ready_warp"

    def _fetch(self, eg: EG, w: Warp, now: int) -> None:
        """FD stage: fetch from the EG's instruction memory and decode; fetch-time faults (docs/02 2.6)."""
        st = w.stack
        pc = st.top_pc
        if pc >= self.code_words:
            raise Fault(FC["F_PC_RANGE"], pc, pc)
        if st.rpc_violation():
            raise Fault(FC["F_RECONV"], pc, st.top_rpc)
        ins = self.decoded[pc]
        if ins is None:
            raise Fault(FC["F_ILLEGAL_INSN"], pc, self.code[pc])
        active = st.active
        lanes = [l for l in range(self.cfg.lanes) if active >> l & 1]
        w.fl = Inflight(ins, self.code[pc], pc, active, lanes, now + 1)

    # ===================================================================== pipeline
    def _ex_latency(self, ins: Instr) -> int:
        c, p = ins.iclass, self.p
        if c == "ALU":
            return p.mul_latency if ins.spec.alu == "MUL" else p.alu_latency
        if c == "SREAD":
            return p.sreg_latency
        if c in ("LDG", "STG", "LDS", "STS", "ATOM"):
            return p.agu_latency
        return p.branch_latency if c in ("BRANCH", "JUMP", "EXIT", "BAR", "FENCE", "TRAP") else 1

    def _step(self, eg: EG, w: Warp, now: int) -> None:
        fl = w.fl
        if now < fl.next:
            return
        s = fl.stage
        if s == P_RD:
            regs, ins = w.regs, fl.ins
            reads, n = ins.reads, len(fl.lanes)
            fl.va = [regs[ins.rs1][l] for l in fl.lanes] if "rs1" in reads else [0] * n
            fl.vb = [regs[ins.rs2][l] for l in fl.lanes] if "rs2" in reads else [0] * n
            fl.stage, fl.next = P_EX, now + self._ex_latency(ins)
        elif s == P_EX:
            self._execute(eg, w, fl, now)
        elif s == P_MEM:
            self._mem_stage(w, fl, now)
        else:
            self._writeback(eg, w, fl, now)

    def _sr_value(self, idx: int, w: Warp, lane: int) -> int:
        L = self.cfg.lanes
        if idx == _SR["SR_LANE_ID"]:
            return lane
        if idx == _SR["SR_WARP_ID"]:
            return w.index
        tid = w.index * L + lane
        if idx == _SR["SR_TID"]:
            return tid
        if idx == _SR["SR_WG_ID"]:
            return w.wg.wg_id
        if idx == _SR["SR_WG_DIM"]:
            return self.wg_dim
        if idx == _SR["SR_GRID_DIM"]:
            return self.grid_dim
        if idx == _SR["SR_GTID"]:
            return (w.wg.wg_id * self.wg_dim + tid) & MASK32
        if idx == _SR["SR_LANES"]:
            return L
        if idx == _SR["SR_SHARED_BYTES"]:
            return w.wg.shared_bytes
        return self.args[idx - _SR["SR_ARG0"]]

    @staticmethod
    def _check_addrs(pc: int, lanes: List[int], addrs: List[int], limit: int, align_code: int, range_code: int) -> None:
        """All lanes are checked before any access; lowest failing lane wins, misalignment before range."""
        for l, a in zip(lanes, addrs):
            if a & 3:
                raise Fault(align_code, pc, a, l)
            if a >= limit:
                raise Fault(range_code, pc, a, l)

    def _to_wb(self, fl: Inflight, now: int) -> None:
        fl.stage, fl.next = P_WB, now + 1

    def _execute(self, eg: EG, w: Warp, fl: Inflight, now: int) -> None:
        ins, c, st, pc = fl.ins, fl.ins.iclass, w.stack, fl.pc
        if c == "ALU":
            fn = LANE_ALU[ins.spec.alu]
            if ins.spec.b_imm:
                b = ins.imm32
                fl.vals = [fn(a, b) for a in fl.va]
            else:
                fl.vals = [fn(a, b) for a, b in zip(fl.va, fl.vb)]
            self._to_wb(fl, now)
        elif c == "SREAD":
            fl.vals = [self._sr_value(ins.imm, w, l) for l in fl.lanes]
            self._to_wb(fl, now)
        elif c == "NOP":
            self._to_wb(fl, now)
        elif c == "FENCE":
            fl.drain, fl.stage, fl.next = True, P_MEM, now + 1
        elif c == "TRAP":
            raise Fault(FC["F_TRAP"], pc, ins.imm)
        elif c == "BAR":
            if fl.active != st.live:
                raise Fault(FC["F_BAR_DIVERGENT"], pc, st.live)
            fl.drain, fl.stage, fl.next = True, P_MEM, now + 1
        elif c == "EXIT":
            fl.finishes = (st.live & ~fl.active) == 0
            if fl.finishes:
                fl.drain, fl.stage, fl.next = True, P_MEM, now + 1          # a finishing warp drains first
            else:
                self._to_wb(fl, now)
        elif c == "JUMP":
            fl.target = pc + ins.imm
            if not 0 <= fl.target < self.code_words:
                raise Fault(FC["F_PC_RANGE"], pc, fl.target)
            self._to_wb(fl, now)
        elif c == "BRANCH":
            fl.target, fl.reconv = pc + ins.imm, pc + ins.imm2
            if not 0 <= fl.target < self.code_words:
                raise Fault(FC["F_PC_RANGE"], pc, fl.target)
            if fl.reconv >= self.code_words:
                raise Fault(FC["F_PC_RANGE"], pc, fl.reconv)
            want_zero = ins.mnemonic == "bz"
            fl.cond = sum(1 << l for l, a in zip(fl.lanes, fl.va) if (a == 0) == want_zero)
            if st.would_overflow(fl.cond, fl.target, fl.reconv):
                raise Fault(FC["F_STACK_OVERFLOW"], pc, st.depth)
            self._to_wb(fl, now)
        else:                                                                # LDG STG ATOM LDS STS
            is_g = c in ("LDG", "STG", "ATOM")
            off = 0 if c == "ATOM" else ins.imm
            addrs = [(a + off) & MASK32 for a in fl.va]
            if is_g:
                self._check_addrs(pc, fl.lanes, addrs, self.cfg.gmem_bytes, FC["F_GMEM_ALIGN"], FC["F_GMEM_RANGE"])
                txns = self.mem.global_txns(ins.mnemonic, addrs)
            else:
                self._check_addrs(pc, fl.lanes, addrs, w.wg.shared_bytes, FC["F_SMEM_ALIGN"], FC["F_SMEM_RANGE"])
                txns = self.mem.shared_txns(addrs)
            vals = fl.vb if c in ("STG", "STS", "ATOM") else None
            fl.req = MemReq(w, eg.index, ins.mnemonic, "g" if is_g else "s", fl.lanes, addrs, vals,
                            0 if is_g else w.wg.smem_base, now, txns, fl)
            fl.stage, fl.next = P_MEM, now + 1

    def _mem_stage(self, w: Warp, fl: Inflight, now: int) -> None:
        fl.next = now + 1
        if fl.waiting:
            return                                            # load/atomic data still on its way
        if fl.drain:
            if w.outstanding == 0:
                self._to_wb(fl, now)
            return
        if w.outstanding >= self.p.mem_queue_depth:
            return                                            # request queue full: stall the warp
        self.mem.enqueue(fl.req)
        fl.queued = True
        if fl.ins.iclass in ("STG", "STS"):
            self._to_wb(fl, now)                              # posted: the warp does not wait for completion
        else:
            fl.waiting = True

    def _write(self, w: Warp, rd: int, lanes: List[int], vals: List[int]):
        if not rd:
            return None
        row = w.regs[rd]
        for l, v in zip(lanes, vals):
            row[l] = v
        return [rd, [[l, v] for l, v in zip(lanes, vals)]]

    def _writeback(self, eg: EG, w: Warp, fl: Inflight, now: int) -> None:
        ins, c, st, lanes = fl.ins, fl.ins.iclass, w.stack, fl.lanes
        wb = mem = None
        if c in ("ALU", "SREAD"):
            wb = self._write(w, ins.rd, lanes, fl.vals)
            st.seq()
        elif c in ("NOP", "FENCE"):
            st.seq()
        elif c in ("LDG", "LDS"):
            wb = self._write(w, ins.rd, lanes, fl.vals)
            mem = [ins.mnemonic, [[l, a] for l, a in zip(lanes, fl.req.addrs)]]
            st.seq()
        elif c in ("STG", "STS"):
            mem = [ins.mnemonic, [[l, a, v] for l, a, v in zip(lanes, fl.req.addrs, fl.vb)]]
            st.seq()
        elif c == "ATOM":
            wb = self._write(w, ins.rd, lanes, fl.vals)
            mem = ["atomadd", [[l, a, v] for l, a, v in zip(lanes, fl.req.addrs, fl.vb)]]
            st.seq()
        elif c == "BRANCH":
            st.branch(fl.cond, fl.target, fl.reconv)
        elif c == "JUMP":
            st.jump(fl.target)
        elif c == "EXIT":
            st.exit_()
        elif c == "BAR":
            st.seq()
            w.state = W_BARRIER
        # ---- commit ------------------------------------------------------------------------------------------
        self.perf_issued += 1
        self.perf_lane_ops += len(lanes)
        self.cnt["issued"] = self.perf_issued
        self.cnt["lane_ops"] = self.perf_lane_ops
        self.cnt["stack_resolve_cycles"] += st.last_cost
        if self.trace_on:
            rec = {"wg": w.wg.wg_id, "warp": w.index, "seq": w.seq, "pc": fl.pc, "insn": fl.word, "mask": fl.active,
                   "wb": wb, "mem": mem, "npc": None if st.done else st.top_pc, "nmask": st.active,
                   "depth": st.depth}
            self.events.append((w.wg.wg_id, w.index, w.seq, json.dumps(rec, separators=(",", ":"))))
        w.seq += 1
        w.fl = None
        w.ready_at = now + 1 + st.last_cost                    # the warp is unschedulable while the stack resolves
        if st.done:
            w.state = W_DONE
            if all(x.state == W_DONE for x in w.wg.warps):
                w.wg.retire_at = now + self.p.retire_latency
        if w.state in (W_BARRIER, W_DONE):
            self._barrier_check(w.wg, now)

    def _barrier_check(self, wg: Workgroup, now: int) -> None:
        parts = [x for x in wg.warps if x.state != W_DONE]
        if parts and all(x.state == W_BARRIER for x in parts):
            for x in parts:
                x.state = W_READY
                x.ready_at = now + self.p.barrier_release_latency + 1

    # ===================================================================== faults
    def _latch_fault(self, eg_index: int, slot: int, f: Fault, w: Warp) -> None:
        mask = w.stack.active
        lane = f.lane if f.lane is not None else ((mask & -mask).bit_length() - 1 if mask else 0)
        self.fault = dict(code=f.code, loc=eg_index | slot << 8 | lane << 16, pc=f.pc, wg=w.wg.wg_id,
                          mask=mask, data=f.data)
        self._enter_faulted()

    def _latch_watchdog(self) -> None:
        self.fault = dict(code=FC["F_WATCHDOG"], loc=0xFFFFFF, pc=0, wg=0, mask=0, data=self.elapsed)
        self._enter_faulted()

    def _enter_faulted(self) -> None:
        self.state = S_FAULTED
        self.int_status |= INT_FAULT
        self.mem.abort_all()                                   # in-flight/posted memory operations are dropped
