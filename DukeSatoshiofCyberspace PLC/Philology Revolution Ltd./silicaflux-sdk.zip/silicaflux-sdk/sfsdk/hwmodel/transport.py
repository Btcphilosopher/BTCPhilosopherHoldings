"""``HwModelTransport``: the hardware model behind the SDK's transport interface."""
from __future__ import annotations

from typing import Dict, List, Optional

from ..spec import Config, MASK32
from ..transport import ApertureError, Transport
from .device import HwDevice
from .params import HwParams


class HwModelTransport(Transport):
    """Cycle-level microarchitectural model of an SF-G1 implementation (a model, not RTL).

    ``trace=True`` records the canonical commit trace (``commit_trace()``); ``clear_trace()`` empties it so
    the next launch's trace stands alone.  ``counters()`` describes the most recent launch: every value is
    reset at each accepted doorbell exactly like ``PERF_*`` and stays readable after completion or a fault.
    """

    name = "hwmodel"
    description = "SF-G1 cycle-level microarchitectural hardware model (not RTL): pipelined, banked memory, posted stores"

    def __init__(self, config: Config, trace: bool = False, params: Optional[HwParams] = None) -> None:
        self.config = config
        self.params = params or HwParams()
        self.dev = HwDevice(config, self.params, trace=trace)

    # ---- host-visible interface -----------------------------------------------------------------------
    def reg_read(self, off: int) -> int:
        return self.dev.reg_read(off)

    def reg_write(self, off: int, val: int) -> None:
        self.dev.reg_write(off, val & MASK32)

    def mem_read(self, addr: int, n: int) -> bytes:
        b = self.dev.mem_read(addr, n)
        if b is None:
            raise ApertureError(f"aperture read rejected at {addr:#x}+{n}")
        return b

    def mem_write(self, addr: int, data: bytes) -> None:
        if not self.dev.mem_write(addr, bytes(data)):
            raise ApertureError(f"aperture write rejected at {addr:#x}+{len(data)}")

    def advance(self, max_ticks: int) -> int:
        return self.dev.run(max_ticks)

    def irq(self) -> bool:
        return self.dev.irq

    # ---- observability ------------------------------------------------------------------------------------
    def commit_trace(self) -> Optional[List[str]]:
        if not self.dev.trace_on:
            return None
        return [line for _wg, _warp, _seq, line in sorted(self.dev.events, key=lambda e: e[:3])]

    def clear_trace(self) -> None:
        self.dev.events.clear()

    def counters(self) -> Dict[str, int]:
        c = dict(self.dev.cnt)
        c["coalescing_ratio"] = (c["global_lane_accesses"] / c["global_ldst_transactions"]
                                 if c["global_ldst_transactions"] else 0.0)
        c["simt_efficiency_ratio"] = (c["lane_ops"] / (c["issued"] * self.config.lanes) if c["issued"] else 0.0)
        c["ipc_ratio"] = (c["issued"] / c["cycles"]) if c["cycles"] else 0.0
        return c
