"""Hardware-style SIMT reconvergence stack.

Implemented from the normative text of SF-G1 docs/03 (not from the reference model's class):
fixed-capacity parallel arrays ``pc[] / rpc[] / msk[]`` with a stack pointer, a live mask, and
an explicit *resolution* step that pops one entry at a time.  Besides the architectural state
the unit reports ``last_cost``: the number of micro-steps (pushes + pops) the last command took,
which the core turns into cycles during which the warp cannot be scheduled.

Commands: ``start``, ``seq``, ``jump``, ``branch`` (with ``would_overflow`` for a precise,
side-effect-free check) and ``exit_``.
"""
from __future__ import annotations

from typing import List, Tuple


class HwSimtStack:
    __slots__ = ("cap", "rpc_none", "pc", "rpc", "msk", "sp", "live", "last_cost")

    def __init__(self, capacity: int, rpc_none: int) -> None:
        self.cap = capacity
        self.rpc_none = rpc_none
        self.pc: List[int] = [0] * capacity
        self.rpc: List[int] = [0] * capacity
        self.msk: List[int] = [0] * capacity
        self.sp = 0
        self.live = 0
        self.last_cost = 0

    # ---------------------------------------------------------------- observers
    @property
    def done(self) -> bool:
        return self.sp == 0

    @property
    def depth(self) -> int:
        return self.sp

    @property
    def top_pc(self) -> int:
        return self.pc[self.sp - 1] if self.sp else 0

    @property
    def top_rpc(self) -> int:
        return self.rpc[self.sp - 1] if self.sp else self.rpc_none

    @property
    def active(self) -> int:
        return (self.msk[self.sp - 1] & self.live) if self.sp else 0

    def rpc_violation(self) -> bool:
        """The running path is past its reconvergence address (docs/03 3.5)."""
        return self.sp > 0 and self.rpc[self.sp - 1] != self.rpc_none and self.pc[self.sp - 1] > self.rpc[self.sp - 1]

    # ---------------------------------------------------------------- commands
    def start(self, pc: int, mask: int) -> None:
        self.pc[0], self.rpc[0], self.msk[0] = pc, self.rpc_none, mask
        self.sp = 1
        self.live = mask
        self.last_cost = 0
        self._resolve()

    def seq(self) -> None:
        self.pc[self.sp - 1] += 1
        self.last_cost = 0
        self._resolve()

    def jump(self, target: int) -> None:
        self.pc[self.sp - 1] = target
        self.last_cost = 0
        self._resolve()

    def exit_(self) -> None:
        self.live &= ~self.active
        self.last_cost = 0
        self._resolve()

    def _plan(self, cond: int, target: int, reconv: int):
        """Decide what a branch does.  Returns (kind, paths, reuse, needed)."""
        t = self.sp - 1
        pc = self.pc[t]
        act = self.msk[t] & self.live
        taken = act & cond
        fall = act & ~cond
        if taken == 0:
            return "seq", None, False, 0
        if fall == 0:
            return "all", None, False, 0
        paths: List[Tuple[int, int]] = []          # execution stack, bottom first
        if pc + 1 != reconv:
            paths.append((pc + 1, fall))
        if target != reconv:
            paths.append((target, taken))
        reuse = self.rpc[t] == reconv
        needed = max(len(paths) - 1, 0) if reuse else len(paths)
        return "split", paths, reuse, needed

    def would_overflow(self, cond: int, target: int, reconv: int) -> bool:
        kind, _paths, _reuse, needed = self._plan(cond, target, reconv)
        return kind == "split" and self.sp + needed > self.cap

    def branch(self, cond: int, target: int, reconv: int) -> None:
        """Apply a conditional branch; the caller has already ruled out overflow."""
        kind, paths, reuse, needed = self._plan(cond, target, reconv)
        t = self.sp - 1
        pushes = 0
        if kind == "seq":
            self.pc[t] += 1
        elif kind == "all":
            self.pc[t] = target
        else:
            assert self.sp + needed <= self.cap, "branch() called without a would_overflow() check"
            if reuse:
                if paths:
                    self.pc[t], self.msk[t] = paths[0]
                    rest = paths[1:]
                else:
                    self.pc[t] = reconv
                    rest = []
            else:
                self.pc[t] = reconv
                rest = paths
            for pc, m in rest:
                self.pc[self.sp], self.rpc[self.sp], self.msk[self.sp] = pc, reconv, m
                self.sp += 1
                pushes += 1
        self.last_cost = pushes
        self._resolve()

    # ---------------------------------------------------------------- resolution
    def _resolve(self) -> None:
        """Pop paths that finished or have no live lanes, one entry per micro-step (docs/03 3.4)."""
        pops = 0
        while self.sp:
            t = self.sp - 1
            if (self.msk[t] & self.live) == 0 or self.pc[t] == self.rpc[t]:
                self.sp -= 1
                pops += 1
            else:
                break
        self.last_cost += pops
