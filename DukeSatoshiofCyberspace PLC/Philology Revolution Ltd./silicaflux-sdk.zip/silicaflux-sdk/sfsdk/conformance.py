"""Host-level conformance suite for any SF-G1 implementation, driven only through a Transport.

``run_conformance(make_transport)`` builds a fresh device per check (``make_transport(config)``),
drives it purely through BAR0 register access, the BAR1 aperture and ``advance``, and checks
the behaviour the SF-G1 specification (docs/02..09 of the vendored ``sf-g1`` tree) requires.
Expected values come from the specification text, not from running another implementation;
the four example kernels are additionally compared with the authoritative golden reports in
``sf-g1/reference/``.

The suite is itself validated by requiring 100 % on the reference simulator.

    python3 -m sfsdk.conformance [--backend reference|hwmodel|both] [--config default small wide] [-k substring]

What it does NOT cover: timing (PERF_CYCLES, watchdog cycle counts, reset duration), behaviour the
specification calls unspecified (uninitialised memory, memory contents after a fault, EG placement
other than the one flagged 'policy'), and data races.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import traceback
from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

from .asm import assemble
from .isa import encode
from .spec import SF_G1_DIR, Config, MASK32, device_spec
from .transport import ApertureError, Transport

D = device_spec()
R = D.reg_offset
FC, LE = D.faults, D.launch_errors
SENT = 0xCCCCCCCC
CODE_BASE = 0x4000


class CheckFailure(AssertionError):
    pass


def expect(cond: bool, msg: str = "") -> None:
    if not cond:
        raise CheckFailure(msg or "expectation failed")


def expect_eq(got, want, what: str = "") -> None:
    if got != want:
        g = hex(got) if isinstance(got, int) else got
        w = hex(want) if isinstance(want, int) else want
        raise CheckFailure(f"{what}: got {g}, expected {w}")


@dataclass
class Check:
    name: str
    ok: bool
    detail: str = ""
    config: str = ""
    backend: str = ""
    skipped: bool = False


@dataclass
class ConformanceReport:
    backend: str
    checks: List[Check] = field(default_factory=list)

    @property
    def passed(self) -> int:
        return sum(1 for c in self.checks if c.ok)

    @property
    def failed(self) -> int:
        return sum(1 for c in self.checks if not c.ok)

    @property
    def ok(self) -> bool:
        return self.failed == 0 and bool(self.checks)

    def failures(self) -> List[Check]:
        return [c for c in self.checks if not c.ok]

    def summary(self) -> str:
        sk = sum(1 for c in self.checks if c.skipped)
        s = f"[{self.backend}] {self.passed}/{len(self.checks)} checks passed" + (f" ({sk} skipped)" if sk else "")
        for c in self.failures():
            s += f"\n  FAIL {c.name} [{c.config}]: {c.detail}"
        return s

    def as_dict(self) -> Dict:
        return {"backend": self.backend, "passed": self.passed, "failed": self.failed,
                "checks": [c.__dict__ for c in self.checks]}


# =============================================================================== device driver
@dataclass
class Outcome:
    kind: str                       # done | fault | launch_error
    launch_err: int = 0
    fault: Dict[str, int] = field(default_factory=dict)
    issued: int = 0
    lane_ops: int = 0
    cycles: int = 0
    wg_dispatched: int = 0
    wg_completed: int = 0
    status: int = 0
    int_status: int = 0


class Dev:
    """Minimal host driver over a Transport (bring-up, memory, descriptors, launch, wait)."""

    def __init__(self, t: Transport, cfg: Config) -> None:
        self.t, self.cfg = t, cfg
        self._next = 0x100
        self.wait_ready()

    # ---- registers ---------------------------------------------------------------------------------
    def r(self, name: str) -> int:
        return self.t.reg_read(R[name])

    def w(self, name: str, v: int) -> None:
        self.t.reg_write(R[name], v)

    def field(self, reg: str, name: str) -> int:
        hi, lo = D.field(reg, name)
        return (self.r(reg) >> lo) & ((1 << (hi - lo + 1)) - 1)

    def wait_ready(self, limit: int = 100000) -> int:
        n = 0
        while not self.r("STATUS") & 1:
            self.t.advance(1)
            n += 1
            expect(n < limit, "device never became READY")
        return n

    def reset(self) -> None:
        self.w("CTRL", 1)
        self.wait_ready()
        self._next = max(self._next, 0x100)

    # ---- memory --------------------------------------------------------------------------------------
    def alloc(self, nbytes: int, align: int = 64) -> int:
        a = (self._next + align - 1) & ~(align - 1)
        expect(a + nbytes <= self.cfg.gmem_bytes, "test ran out of device memory")
        self._next = a + max(nbytes, 4)
        return a

    def put(self, addr: int, words: Sequence[int]) -> None:
        self.t.mem_write(addr, b"".join((w & MASK32).to_bytes(4, "little") for w in words))

    def get(self, addr: int, n: int) -> List[int]:
        b = self.t.mem_read(addr, 4 * n)
        return [int.from_bytes(b[4 * i:4 * i + 4], "little") for i in range(n)]

    def load(self, words: Sequence[int]) -> int:
        a = self.alloc(4 * len(words))
        self.put(a, words)
        return a

    # ---- launch ------------------------------------------------------------------------------------------
    def desc(self, code_addr: int, code_words: int, grid: int = 1, wg: int = 1, shared: int = 0,
             args: Sequence[int] = (), flags: int = 0, entry: int = 0, magic: Optional[int] = None,
             version: int = 1) -> List[int]:
        W = D.desc_words
        w = [0] * D.desc_size_words
        w[W["MAGIC"]] = D.desc_magic if magic is None else magic
        w[W["VERSION_FLAGS"]] = (version << 16) | (flags & 0xFFFF)
        w[W["CODE_ADDR"]], w[W["CODE_WORDS"]], w[W["ENTRY_PC"]] = code_addr, code_words, entry
        w[W["GRID_DIM"]], w[W["WG_DIM"]], w[W["SHARED_BYTES"]] = grid, wg, shared
        for i, a in enumerate(args):
            w[W["ARG0"] + i] = a & MASK32
        return w

    def submit(self, desc_words: Sequence[int]) -> int:
        a = self.alloc(4 * len(desc_words))
        self.put(a, desc_words)
        self.w("LAUNCH_ADDR", a)
        self.w("DOORBELL", 1)
        return a

    def finish(self, limit: int = 4_000_000) -> Outcome:
        total = 0
        while self.r("STATUS") & 2:
            total += max(self.t.advance(2000), 1)
            expect(total < limit, "launch did not finish (device still BUSY)")
        st = self.r("STATUS")
        o = Outcome("done", status=st, int_status=self.r("INT_STATUS"), cycles=self.r("PERF_CYCLES"),
                    issued=self.r("PERF_ISSUED"), lane_ops=self.r("PERF_LANE_OPS"),
                    wg_dispatched=self.r("WG_DISPATCHED"), wg_completed=self.r("WG_COMPLETED"))
        le = self.r("LAUNCH_ERR")
        if le:
            o.kind, o.launch_err = "launch_error", le
        elif st & 8:
            o.kind = "fault"
            o.fault = {n: self.r("FAULT_" + n) for n in ("CODE", "LOC", "PC", "WG", "MASK", "DATA")}
        return o

    def run(self, src, grid: int = 1, wg: int = 1, shared: int = 0, args: Sequence[int] = (), flags: int = 0,
            entry: int = 0, wdog: Optional[int] = None) -> Outcome:
        words = src if isinstance(src, (list, tuple)) else assemble(src).words
        code = self.load(words)
        if wdog is not None:
            self.w("WDOG_LIMIT", wdog)
        self.submit(self.desc(code, len(words), grid, wg, shared, args, flags, entry))
        return self.finish()

    def launch_expect_done(self, *a, **k) -> Outcome:
        o = self.run(*a, **k)
        expect_eq(o.kind, "done", f"launch outcome (fault={o.fault}, launch_err={o.launch_err})")
        return o


# =============================================================================== registry
_CHECKS: List[Tuple[str, Callable[[Dev], None], Optional[Tuple[str, ...]]]] = []


def check(name: str, configs: Optional[Tuple[str, ...]] = None):
    def deco(fn):
        _CHECKS.append((name, fn, configs))
        return fn
    return deco


def run_conformance(make_transport: Callable[[Config], Transport],
                    config_names: Iterable[str] = ("default", "small", "wide"),
                    only: Optional[str] = None, backend: str = "", fail_fast: bool = False) -> ConformanceReport:
    rep = ConformanceReport(backend or "transport")
    for cname in config_names:
        if fail_fast and rep.failed:
            break
        cfg = Config.named(cname)
        for name, fn, cfgs in _CHECKS:
            if (cfgs and cname not in cfgs) or (only and only not in name):
                continue
            t = None
            try:
                t = make_transport(cfg)
                fn(Dev(t, cfg))
                rep.checks.append(Check(name, True, "", cname, rep.backend))
            except _Skip as s:
                rep.checks.append(Check(name, True, f"skipped: {s}", cname, rep.backend, skipped=True))
            except CheckFailure as e:
                rep.checks.append(Check(name, False, str(e), cname, rep.backend))
            except Exception as e:                                   # noqa: BLE001 - report, don't hide
                tb = traceback.extract_tb(e.__traceback__)[-1]
                rep.checks.append(Check(name, False, f"{type(e).__name__}: {e} (at {tb.name}:{tb.lineno})", cname,
                                        rep.backend))
            finally:
                if t is not None:
                    t.close()
            if fail_fast and rep.failed:
                break
    return rep


class _Skip(Exception):
    pass


# =============================================================================== 1. identity, registers
@check("identity_and_capabilities")
def _identity(d: Dev) -> None:
    expect_eq(d.r("ID"), 0x31474653, "ID ('SFG1')")
    expect_eq(d.r("VERSION"), 0x00010000, "VERSION 1.0.0")
    expect_eq(d.r("CFG_HASH"), d.cfg.cfg_hash(), "CFG_HASH (CRC-32 of the canonical spec)")
    for name, v in d.cfg.caps_regs().items():
        expect_eq(d.r(name), v, name)


@check("power_up_state_and_reset_values")
def _powerup(d: Dev) -> None:
    expect_eq(d.r("STATUS"), 1, "STATUS after READY (READY only)")
    for n in ("INT_STATUS", "INT_ENABLE", "LAUNCH_ADDR", "LAUNCH_ERR", "FAULT_CODE", "FAULT_LOC", "FAULT_PC",
              "FAULT_WG", "FAULT_MASK", "FAULT_DATA", "PERF_CYCLES", "PERF_ISSUED", "PERF_LANE_OPS",
              "WG_DISPATCHED", "WG_COMPLETED", "SCRATCH", "CTRL", "DOORBELL"):
        expect_eq(d.r(n), 0, f"reset value of {n}")
    expect_eq(d.r("WDOG_LIMIT"), d.cfg.wdog_reset_ticks, "WDOG_LIMIT reset value")


@check("power_up_ready_gating")
def _powerup_gate(d: Dev) -> None:
    d.w("SCRATCH", 0x55)
    d.w("CTRL", 1)
    expect_eq(d.r("STATUS") & 1, 0, "READY while resetting")
    d.w("SCRATCH", 0x77)                                             # valid write while resetting: ignored
    d.w("CTRL", 1)                                                   # second soft reset: ignored (must not extend/loop)
    expect_eq(d.r("SCRATCH"), 0, "SCRATCH reads its reset value during reset")
    expect_eq(d.r("ID"), 0x31474653, "registers stay readable during reset")
    d.wait_ready()
    expect_eq(d.r("SCRATCH"), 0, "write during reset was ignored")


@check("registers_ro_ignore_writes")
def _ro(d: Dev) -> None:
    before = {n: d.r(n) for n in ("ID", "VERSION", "CFG_HASH", "CAPS_GEOM", "CAPS_SMEM", "CAPS_IMEM", "CAPS_GMEM",
                                  "CAPS_LIMITS", "STATUS", "LAUNCH_ERR", "FAULT_CODE", "PERF_ISSUED", "WG_COMPLETED")}
    for n in before:
        d.w(n, 0xFFFFFFFF)
    for n, v in before.items():
        expect_eq(d.r(n), v, f"RO register {n} changed by a write")
    expect_eq(d.r("INT_STATUS") & 8, 0, "writes to RO registers are ignored without HOST_ERR")


@check("registers_unmapped_and_misaligned_set_host_err")
def _unmapped(d: Dev) -> None:
    for off in (0x058, 0x05C, 0x06C, 0x078, 0x0F4, 0x100, 0xFFC, 0x1000, 0x001, 0x026, 0x03F):
        d.w("INT_STATUS", 0xF)
        expect_eq(d.t.reg_read(off), 0, f"read of unmapped/misaligned offset {off:#x}")
        expect_eq(d.r("INT_STATUS") & 8, 8, f"HOST_ERR after reading {off:#x}")
        d.w("INT_STATUS", 8)
        d.t.reg_write(off, 0x1234)
        expect_eq(d.r("INT_STATUS") & 8, 8, f"HOST_ERR after writing {off:#x}")
    d.w("INT_STATUS", 0xF)
    expect_eq(d.r("INT_STATUS"), 0, "INT_STATUS cleared by W1C")


@check("registers_w1c_and_enable_mask")
def _w1c(d: Dev) -> None:
    d.t.reg_read(0x058)
    expect_eq(d.r("INT_STATUS"), 8, "HOST_ERR set")
    d.w("INT_STATUS", 0)
    expect_eq(d.r("INT_STATUS"), 8, "writing 0 clears nothing")
    d.w("INT_STATUS", 1 | 2 | 4)
    expect_eq(d.r("INT_STATUS"), 8, "writing 1 to clear bits that are not set changes nothing")
    d.w("INT_STATUS", 8)
    expect_eq(d.r("INT_STATUS"), 0, "W1C clears the bit")
    d.w("INT_ENABLE", 0xFFFFFFFF)
    expect_eq(d.r("INT_ENABLE"), 0xF, "INT_ENABLE keeps only bits [3:0]")
    d.w("INT_ENABLE", 0)


@check("registers_rw_and_write_only")
def _rw(d: Dev) -> None:
    for n, v in (("SCRATCH", 0xA5A5F00D), ("LAUNCH_ADDR", 0x12344), ("WDOG_LIMIT", 12345)):
        d.w(n, v)
        expect_eq(d.r(n), v, f"{n} read-back")
    d.w("WDOG_LIMIT", d.cfg.wdog_reset_ticks)
    expect_eq(d.r("DOORBELL"), 0, "DOORBELL reads as 0")
    expect_eq(d.r("CTRL"), 0, "CTRL reads as 0")
    expect_eq(d.field("STATUS", "IRQ"), 0, "STATUS.IRQ low")


@check("soft_reset_clears_registers_preserves_memory")
def _soft_reset(d: Dev) -> None:
    a = d.alloc(16)
    d.put(a, [0x11111111, 0x22222222])
    d.w("SCRATCH", 9)
    d.w("INT_ENABLE", 5)
    d.w("WDOG_LIMIT", 77)
    d.w("LAUNCH_ADDR", 0x100)
    d.t.reg_read(0x058)                                              # HOST_ERR
    d.reset()
    for n in ("SCRATCH", "INT_ENABLE", "LAUNCH_ADDR", "INT_STATUS", "LAUNCH_ERR"):
        expect_eq(d.r(n), 0, f"{n} after soft reset")
    expect_eq(d.r("WDOG_LIMIT"), d.cfg.wdog_reset_ticks, "WDOG_LIMIT after soft reset")
    expect_eq(d.get(a, 2), [0x11111111, 0x22222222], "global memory is preserved across a soft reset")


@check("host_err_during_reset_survives_reset")
def _herr_reset(d: Dev) -> None:
    d.w("CTRL", 1)
    d.t.reg_read(0x058)                                              # invalid access while READY=0
    d.wait_ready()
    expect_eq(d.r("INT_STATUS") & 8, 8, "HOST_ERR raised during reset must survive the end of reset")


# =============================================================================== 2. aperture
@check("aperture_bounds_and_host_err")
def _aperture(d: Dev) -> None:
    G = d.cfg.gmem_bytes
    d.put(G - 4, [0xCAFEF00D])
    expect_eq(d.get(G - 4, 1), [0xCAFEF00D], "last word of global memory is accessible")
    d.put(0, [0x01020304])
    expect_eq(d.t.mem_read(0, 4), bytes([4, 3, 2, 1]), "byte-addressed, little-endian, address 0 valid")
    expect_eq(d.t.mem_read(1, 2), bytes([3, 2]), "aperture allows unaligned byte accesses")
    d.w("INT_STATUS", 0xF)
    for fn in (lambda: d.t.mem_read(G - 3, 4), lambda: d.t.mem_write(G - 2, b"\0\0\0"), lambda: d.t.mem_read(G, 1)):
        try:
            fn()
        except ApertureError:
            continue
        raise CheckFailure("out-of-range aperture access was accepted")
    expect_eq(d.r("INT_STATUS") & 8, 8, "HOST_ERR after rejected aperture access")


@check("aperture_rejected_while_resetting_and_busy")
def _aperture_busy(d: Dev) -> None:
    d.w("CTRL", 1)
    d.w("INT_STATUS", 0xF)                                           # ignored (resetting) -> still testable
    try:
        d.t.mem_read(0, 4)
        raise CheckFailure("aperture read accepted while READY=0")
    except ApertureError:
        pass
    d.wait_ready()
    expect_eq(d.r("INT_STATUS") & 8, 8, "HOST_ERR from the aperture access during reset survives")
    d.w("INT_STATUS", 0xF)
    code = d.load(assemble("L: bra L").words)
    d.w("WDOG_LIMIT", 0)
    d.submit(d.desc(code, 1))
    expect(d.r("STATUS") & 2, "device must be BUSY after an accepted doorbell")
    for fn in (lambda: d.t.mem_read(0x100, 4), lambda: d.t.mem_write(0x100, b"abcd")):
        try:
            fn()
            raise CheckFailure("aperture access accepted while BUSY")
        except ApertureError:
            pass
    expect_eq(d.r("INT_STATUS") & 8, 8, "HOST_ERR after aperture access while BUSY")
    d.reset()                                                        # soft reset aborts the endless launch
    expect_eq(d.r("STATUS"), 1, "idle after soft reset")
    d.get(0x100, 1)


# =============================================================================== 3. launch errors
def _le_case(d: Dev, mutate: Callable[[List[int]], None], code: str, desc_addr_override: Optional[int] = None,
             words: Optional[List[int]] = None) -> None:
    words = words or assemble("exit").words
    ca = d.load(words)
    dw = d.desc(ca, len(words))
    mutate(dw)
    if desc_addr_override is None:
        d.submit(dw)
    else:
        d.w("LAUNCH_ADDR", desc_addr_override)
        d.w("DOORBELL", 1)
    o = d.finish()
    expect_eq(o.kind, "launch_error", f"{code}: outcome")
    expect_eq(o.launch_err, LE[code], f"{code}: LAUNCH_ERR")
    expect_eq(o.status & 2, 0, f"{code}: BUSY must return to 0")
    expect_eq(o.status & 4, 0, f"{code}: DONE must be 0")
    expect_eq(o.status & 8, 0, f"{code}: a launch error is not a fault")
    expect_eq(o.int_status & 4, 4, f"{code}: INT_STATUS.LAUNCH_ERR")
    d.w("INT_STATUS", 4)
    ok = d.run("exit")                                               # device must stay usable
    expect_eq(ok.kind, "done", f"{code}: next launch must succeed")
    expect_eq(d.r("LAUNCH_ERR"), 0, f"{code}: an accepted doorbell clears LAUNCH_ERR")


def _w(i: str) -> int:
    return D.desc_words[i]


@check("launch_error_align_descriptor_address")
def _le1(d: Dev) -> None:
    _le_case(d, lambda w: None, "LE_ALIGN", desc_addr_override=d.alloc(128) + 2)


@check("launch_error_range_descriptor")
def _le2(d: Dev) -> None:
    _le_case(d, lambda w: None, "LE_RANGE", desc_addr_override=d.cfg.gmem_bytes - 32)


@check("launch_error_magic_version_reserved")
def _le3(d: Dev) -> None:
    _le_case(d, lambda w: w.__setitem__(_w("MAGIC"), 0x12345678), "LE_MAGIC")
    _le_case(d, lambda w: w.__setitem__(_w("VERSION_FLAGS"), (2 << 16)), "LE_VERSION")
    _le_case(d, lambda w: w.__setitem__(_w("VERSION_FLAGS"), (0 << 16)), "LE_VERSION")
    _le_case(d, lambda w: w.__setitem__(_w("VERSION_FLAGS"), (1 << 16) | 2), "LE_RESERVED")
    _le_case(d, lambda w: w.__setitem__(_w("VERSION_FLAGS"), (1 << 16) | 0x8000), "LE_RESERVED")


@check("launch_error_code_fields")
def _le4(d: Dev) -> None:
    G = d.cfg.gmem_bytes
    _le_case(d, lambda w: w.__setitem__(_w("CODE_ADDR"), w[_w("CODE_ADDR")] + 2), "LE_ALIGN")
    _le_case(d, lambda w: w.__setitem__(_w("CODE_WORDS"), 0), "LE_CODE_SIZE")
    _le_case(d, lambda w: w.__setitem__(_w("CODE_WORDS"), d.cfg.imem_words + 1), "LE_CODE_SIZE")
    _le_case(d, lambda w: w.__setitem__(_w("CODE_ADDR"), G - 4) or w.__setitem__(_w("CODE_WORDS"), 2), "LE_RANGE")
    _le_case(d, lambda w: w.__setitem__(_w("ENTRY_PC"), 1), "LE_ENTRY")
    _le_case(d, lambda w: w.__setitem__(_w("ENTRY_PC"), 0xFFFFFFFF), "LE_ENTRY")


@check("launch_error_dims_and_shared")
def _le5(d: Dev) -> None:
    c = d.cfg
    _le_case(d, lambda w: w.__setitem__(_w("GRID_DIM"), 0), "LE_DIMS")
    _le_case(d, lambda w: w.__setitem__(_w("GRID_DIM"), c.max_grid_dim + 1), "LE_DIMS")
    _le_case(d, lambda w: w.__setitem__(_w("WG_DIM"), 0), "LE_DIMS")
    _le_case(d, lambda w: w.__setitem__(_w("WG_DIM"), c.max_wg_threads + 1), "LE_DIMS")
    _le_case(d, lambda w: w.__setitem__(_w("SHARED_BYTES"), 2), "LE_ALIGN")
    _le_case(d, lambda w: w.__setitem__(_w("SHARED_BYTES"), c.wg_slot_smem_bytes + 4), "LE_SHARED")
    o = d.run("exit", grid=c.max_grid_dim, wg=c.max_wg_threads, shared=c.wg_slot_smem_bytes)   # exact limits are legal
    expect_eq(o.kind, "done", "descriptor with every field at its maximum")


@check("launch_error_priority_order")
def _le6(d: Dev) -> None:
    def many(w):
        w[_w("MAGIC")] = 1
        w[_w("VERSION_FLAGS")] = 7 << 16
        w[_w("CODE_WORDS")] = 0
        w[_w("GRID_DIM")] = 0
    _le_case(d, many, "LE_MAGIC")
    def two(w):
        w[_w("CODE_WORDS")] = 0
        w[_w("GRID_DIM")] = 0
    _le_case(d, two, "LE_CODE_SIZE")
    def three(w):
        w[_w("ENTRY_PC")] = 5
        w[_w("WG_DIM")] = 0
    _le_case(d, three, "LE_ENTRY")
    def four(w):
        w[_w("WG_DIM")] = 0
        w[_w("SHARED_BYTES")] = 2
    _le_case(d, four, "LE_DIMS")


@check("launch_error_counters_cleared_at_acceptance")
def _le7(d: Dev) -> None:
    d.launch_expect_done("nop\nnop\nexit")
    expect(d.r("PERF_ISSUED") > 0, "PERF_ISSUED after a launch")
    ca = d.load(assemble("exit").words)
    d.submit(d.desc(ca, 1, magic=3))
    o = d.finish()
    expect_eq(o.launch_err, LE["LE_MAGIC"], "LE_MAGIC")
    for n in ("PERF_ISSUED", "PERF_LANE_OPS", "WG_DISPATCHED", "WG_COMPLETED"):
        expect_eq(d.r(n), 0, f"{n}: cleared by the accepted (then invalid) doorbell")
    expect_eq(d.field("STATUS", "DONE"), 0, "DONE cleared by an accepted doorbell")


@check("launch_busy_rejection_is_sticky_and_harmless")
def _busy(d: Dev) -> None:
    out = d.alloc(4)
    d.put(out, [0])
    src = """
        li   r2, 300
    spin:
        addi r2, r2, -1
        bnz  r2, spin, after
    after:
        rdsr r3, SR_ARG0
        li   r4, 99
        stg  r4, [r3]
        exit
    """
    code = d.load(assemble(src).words)
    d.w("WDOG_LIMIT", 0)
    d.submit(d.desc(code, len(assemble(src).words), args=[out]))
    d.w("INT_STATUS", 0xF)
    d.w("DOORBELL", 1)                                               # second doorbell while BUSY
    expect_eq(d.r("LAUNCH_ERR"), LE["LE_BUSY"], "LAUNCH_ERR after a doorbell while BUSY")
    expect_eq(d.r("INT_STATUS") & 4, 4, "INT_STATUS.LAUNCH_ERR after LE_BUSY")
    o = d.finish()
    expect_eq(o.launch_err, LE["LE_BUSY"], "LE_BUSY stays in LAUNCH_ERR after the running launch completes")
    expect_eq(d.get(out, 1), [99], "the running launch was not disturbed")
    d.w("WDOG_LIMIT", d.cfg.wdog_reset_ticks)
    ok = d.run("exit")
    expect_eq(ok.kind, "done", "next accepted launch")
    expect_eq(d.r("LAUNCH_ERR"), 0, "accepted doorbell clears LAUNCH_ERR")


@check("launch_addr_latched_at_doorbell")
def _latched(d: Dev) -> None:
    src = "li r2, 200\nl: addi r2, r2, -1\nbnz r2, l, e\ne: exit"
    code = d.load(assemble(src).words)
    d.w("WDOG_LIMIT", 0)
    d.submit(d.desc(code, 5))
    d.w("LAUNCH_ADDR", 0x2)                                          # harmless: latched at the doorbell
    o = d.finish()
    expect_eq(o.kind, "done", "launch completes despite LAUNCH_ADDR rewrite")
    d.w("WDOG_LIMIT", d.cfg.wdog_reset_ticks)


# =============================================================================== 4. geometry, registers, ALU
def _s32(x: int) -> int:
    return x - (1 << 32) if x & 0x80000000 else x


@check("special_registers_and_partial_warps")
def _sr(d: Dev) -> None:
    L, grid = d.cfg.lanes, 3
    wgd, shared = L + 3, 16                       # last warp is partial (3 live lanes)
    names = ["SR_TID", "SR_WARP_ID", "SR_LANE_ID", "SR_WG_ID", "SR_GTID", "SR_WG_DIM", "SR_GRID_DIM", "SR_LANES",
             "SR_SHARED_BYTES", "SR_ARG1", "SR_ARG7"]
    lines = ["rdsr r1, SR_GTID", "rdsr r2, SR_ARG0", f"li r3, {4 * len(names)}", "mul r3, r1, r3", "add r2, r2, r3"]
    for k, n in enumerate(names):
        lines += [f"rdsr r4, {n}", f"stg r4, [r2 + {4 * k}]"]
    lines.append("exit")
    total, guard = len(names) * wgd * grid, 2 * len(names)
    out = d.alloc(4 * (total + guard))
    d.put(out, [SENT] * (total + guard))
    args = [out, 0xA1, 0, 0, 0, 0, 0, 0xA7]
    d.launch_expect_done("\n".join(lines), grid, wgd, shared, args)
    got = d.get(out, total + guard)
    exp = []
    for wg in range(grid):
        for tid in range(wgd):
            exp += [tid, tid // L, tid % L, wg, (wg * wgd + tid) & MASK32, wgd, grid, L, shared, 0xA1, 0xA7]
    expect_eq(got[:total], exp, "special-register values (incl. the partial last warp)")
    expect_eq(got[total:], [SENT] * guard, "threads that do not exist (upper lanes of the partial warp) must not run")


@check("registers_zero_at_thread_start_and_r0")
def _regs0(d: Dev) -> None:
    lines = [f"atomadd r0, [r0], r{i}" for i in range(1, 16)]
    lines += ["addi r0, r0, 5", "add r1, r0, r0", "lui r0, 7", "rdsr r0, SR_TID", "add r2, r0, r0",
              "atomadd r0, [r0], r1", "atomadd r0, [r0], r2", "exit"]
    d.put(0, [0])
    d.launch_expect_done("\n".join(lines), grid=2, wg=d.cfg.lanes + 1)
    expect_eq(d.get(0, 1), [0], "sum of every register of every thread at start, and r0 after writes (must be 0)")


_V16 = [0, 1, 2, 3, 31, 32, 33, 0x7FFFFFFF, 0x80000000, 0x80000001, 0xFFFFFFFE, 0xFFFFFFFF, 0x12345678,
        0xAAAAAAAA, 0x55555555, 0xDEADBEEF]
_RR = [("add", lambda a, b: (a + b) & MASK32), ("sub", lambda a, b: (a - b) & MASK32),
       ("mul", lambda a, b: (a * b) & MASK32), ("and", lambda a, b: a & b), ("or", lambda a, b: a | b),
       ("xor", lambda a, b: a ^ b), ("shl", lambda a, b: (a << (b & 31)) & MASK32), ("shr", lambda a, b: a >> (b & 31)),
       ("sar", lambda a, b: (_s32(a) >> (b & 31)) & MASK32), ("slt", lambda a, b: int(_s32(a) < _s32(b))),
       ("sltu", lambda a, b: int(a < b))]
_IMMS = (-131072, -1, 0, 1, 131071)
_RI = [("addi", lambda a, i: (a + i) & MASK32), ("andi", lambda a, i: a & (i & MASK32)),
       ("ori", lambda a, i: a | (i & MASK32)), ("xori", lambda a, i: a ^ (i & MASK32)),
       ("slti", lambda a, i: int(_s32(a) < i)), ("sltiu", lambda a, i: int(a < (i & MASK32)))]
_SHIFTS = (0, 1, 5, 31)
_SI = [("shli", lambda a, k: (a << k) & MASK32), ("shri", lambda a, k: a >> k),
       ("sari", lambda a, k: (_s32(a) >> k) & MASK32)]
_LUI = (0, 1, 0x3FFFFF, 0x200000, 0x155555)


@check("alu_semantics_all_instructions")
def _alu(d: Dev) -> None:
    n = 256
    A = [_V16[p // 16] for p in range(n)]
    B = [_V16[p % 16] for p in range(n)]
    a_buf, b_buf = d.alloc(4 * n), d.alloc(4 * n)
    d.put(a_buf, A)
    d.put(b_buf, B)
    ops: List[Tuple[str, Callable[[int, int], int], str]] = []     # (label, python fn of (a,b), asm line)
    for m, f in _RR:
        ops.append((m, f, f"{m} r7, r4, r5"))
    for m, f in _RI:
        for i in _IMMS:
            ops.append((f"{m} {i}", (lambda f, i: lambda a, b: f(a, i))(f, i), f"{m} r7, r4, {i}"))
    for m, f in _SI:
        for k in _SHIFTS:
            ops.append((f"{m} {k}", (lambda f, k: lambda a, b: f(a, k))(f, k), f"{m} r7, r4, {k}"))
    for v in _LUI:
        ops.append((f"lui {v}", (lambda v: lambda a, b: (v << 10) & MASK32)(v), f"lui r7, {v}"))
    out = d.alloc(4 * n * len(ops))
    lines = ["rdsr r1, SR_GTID", "shli r1, r1, 2", "rdsr r2, SR_ARG0", "add r2, r2, r1", "ldg r4, [r2]",
             "rdsr r3, SR_ARG1", "add r3, r3, r1", "ldg r5, [r3]", "rdsr r6, SR_ARG2", "add r6, r6, r1"]
    for k, (_lbl, _f, asm_line) in enumerate(ops):
        lines += [asm_line, f"stg r7, [r6 + {4 * n * k}]"]
    lines.append("exit")
    wg = min(32, d.cfg.max_wg_threads)
    d.launch_expect_done("\n".join(lines), grid=n // wg, wg=wg, args=[a_buf, b_buf, out])
    got = d.get(out, n * len(ops))
    for k, (lbl, f, _l) in enumerate(ops):
        for p in range(n):
            want = f(A[p], B[p])
            if got[k * n + p] != want:
                raise CheckFailure(f"{lbl}: a={A[p]:#x} b={B[p]:#x} -> {got[k * n + p]:#x}, expected {want:#x}")


# =============================================================================== 5. memory semantics
@check("store_lane_order_highest_lane_wins")
def _store_order(d: Dev) -> None:
    L = d.cfg.lanes
    slot = d.alloc(4)
    full = "rdsr r1, SR_LANE_ID\naddi r2, r1, 100\nrdsr r3, SR_ARG0\nstg r2, [r3]\nexit"
    for wg in (L, 3):
        d.put(slot, [0])
        d.launch_expect_done(full, 1, wg, 0, [slot])
        expect_eq(d.get(slot, 1), [100 + wg - 1], f"highest active lane wins (wg={wg})")
    odd = ("rdsr r1, SR_LANE_ID\nandi r4, r1, 1\nbz r4, done, done\naddi r2, r1, 100\nrdsr r3, SR_ARG0\n"
           "stg r2, [r3]\ndone: exit")
    wg = L - 1
    hi = wg - 1 if (wg - 1) % 2 == 1 else wg - 2
    d.put(slot, [0])
    d.launch_expect_done(odd, 1, wg, 0, [slot])
    expect_eq(d.get(slot, 1), [100 + hi], "highest *active* lane wins (odd lanes only)")
    sh = ("rdsr r1, SR_LANE_ID\naddi r2, r1, 7\nsts r2, [r0]\nlds r3, [r0]\nrdsr r4, SR_ARG0\nstg r3, [r4]\nexit")
    d.put(slot, [0])
    d.launch_expect_done(sh, 1, L, 8, [slot])
    expect_eq(d.get(slot, 1), [7 + L - 1], "shared stores: highest lane wins too")


@check("atomadd_lane_order_and_totality")
def _atomic(d: Dev) -> None:
    L = d.cfg.lanes
    cell, out = d.alloc(8), d.alloc(4 * L)
    src = ("rdsr r1, SR_LANE_ID\naddi r2, r1, 1\nrdsr r3, SR_ARG0\natomadd r4, [r3], r2\nrdsr r5, SR_ARG1\n"
           "shli r6, r1, 2\nadd r5, r5, r6\nstg r4, [r5]\nexit")
    for wg in (L, L - 1):
        d.put(cell, [10])
        d.launch_expect_done(src, 1, wg, 0, [cell, out])
        exp = [10 + sum(j + 1 for j in range(i)) for i in range(wg)]
        expect_eq(d.get(out, wg), exp, f"lane i receives init + sum of lower lanes' operands (wg={wg})")
        expect_eq(d.get(cell, 1), [10 + wg * (wg + 1) // 2], "final value")
    two = ("rdsr r1, SR_LANE_ID\naddi r2, r1, 1\nandi r7, r1, 1\nshli r7, r7, 2\nrdsr r3, SR_ARG0\nadd r3, r3, r7\n"
           "atomadd r4, [r3], r2\nrdsr r5, SR_ARG1\nshli r6, r1, 2\nadd r5, r5, r6\nstg r4, [r5]\nexit")
    d.put(cell, [10, 20])
    d.launch_expect_done(two, 1, L, 0, [cell, out])
    exp = [(10, 20)[i & 1] + sum(j + 1 for j in range(i) if j & 1 == i & 1) for i in range(L)]
    expect_eq(d.get(out, L), exp, "same-address ordering with two addresses interleaved")


@check("atomadd_total_order_across_workgroups")
def _atomic_total(d: Dev) -> None:
    wg = min(2 * d.cfg.lanes, d.cfg.max_wg_threads)
    grid = 9
    n = wg * grid
    ctr, out = d.alloc(4), d.alloc(4 * n)
    d.put(ctr, [0])
    src = ("rdsr r1, SR_GTID\nrdsr r2, SR_ARG0\naddi r3, r0, 1\natomadd r4, [r2], r3\nshli r5, r1, 2\nrdsr r6, SR_ARG1\n"
           "add r6, r6, r5\nstg r4, [r6]\nexit")
    d.launch_expect_done(src, grid, wg, 0, [ctr, out])
    expect_eq(d.get(ctr, 1), [n], "counter after n atomic increments")
    expect_eq(sorted(d.get(out, n)), list(range(n)), "old values must be a permutation of 0..n-1 (C5: total order)")


@check("same_thread_read_after_write_global_and_shared")
def _raw(d: Dev) -> None:
    L = d.cfg.lanes
    wgd, grid = L + 2, 2
    n = wgd * grid
    gbuf, out = d.alloc(4 * n), d.alloc(4 * n)
    src = """
        rdsr r1, SR_TID
        shli r2, r1, 2
        rdsr r3, SR_GTID
        shli r3, r3, 2
        rdsr r4, SR_ARG0
        add  r4, r4, r3
        rdsr r8, SR_ARG1
        add  r8, r8, r3
        addi r5, r0, 0
        addi r6, r0, 0
        li   r9, 7
    loop:
        mul  r7, r5, r9
        add  r7, r7, r1
        sts  r7, [r2]
        lds  r10, [r2]
        add  r6, r6, r10
        stg  r7, [r4]
        ldg  r11, [r4]
        add  r6, r6, r11
        addi r5, r5, 1
        slti r12, r5, 16
        bnz  r12, loop, after
    after:
        stg  r6, [r8]
        exit
    """
    d.launch_expect_done(src, grid, wgd, 4 * wgd, [gbuf, out])
    got = d.get(out, n)
    exp = [1680 + 32 * (g % wgd) for g in range(n)]
    expect_eq(got, exp, "a thread must observe its own earlier stores (C2)")


_K_BAR = """
        rdsr r1, SR_TID
        shli r2, r1, 2
        rdsr r3, SR_GTID
        shli r3, r3, 2
        rdsr r4, SR_ARG0
        add  r4, r4, r3
        rdsr r5, SR_ARG1
        add  r5, r5, r3
        rdsr r6, SR_WG_DIM
        rdsr r7, SR_LANES
        add  r8, r1, r7
        slt  r9, r8, r6
        bnz  r9, keep, keep
        sub  r8, r8, r6
    keep:
        sub  r10, r8, r1
        shli r10, r10, 2
        addi r12, r0, 0
        addi r15, r0, 0
        li   r13, 3
        mul  r11, r1, r13
    round:
        li   r14, 1000
        mul  r14, r12, r14
        add  r14, r14, r11
        addi r14, r14, 1
        sts  r14, [r2]
        stg  r14, [r4]
        bar
        add  r9, r2, r10
        lds  r9, [r9]
        add  r13, r4, r10
        ldg  r13, [r13]
        add  r15, r15, r9
        add  r15, r15, r13
        bar
        addi r12, r12, 1
        slti r9, r12, 2
        bnz  r9, round, after
    after:
        stg  r15, [r5]
        exit
"""


@check("barrier_publishes_shared_and_global_across_warps")
def _bar(d: Dev) -> None:
    L = d.cfg.lanes
    wgd, grid = 2 * L, 2
    n = wgd * grid
    gbuf, out = d.alloc(4 * n), d.alloc(4 * n)
    d.put(gbuf, [SENT] * n)
    d.launch_expect_done(_K_BAR, grid, wgd, 4 * wgd, [gbuf, out])
    got = d.get(out, n)
    exp = [12 * ((t + L) % wgd) + 4 + 2000 for _ in range(grid) for t in range(wgd)]
    expect_eq(got, exp, "values read from the other warp after bar (two rounds, barrier reuse)")


@check("barrier_ignores_exited_warps_and_lanes")
def _bar_exit(d: Dev) -> None:
    L = d.cfg.lanes
    wgd = 2 * L
    out = d.alloc(4 * wgd)
    d.put(out, [SENT] * wgd)
    src = ("rdsr r1, SR_TID\nrdsr r3, SR_LANES\nslt r2, r1, r3\nbnz r2, go, go\nexit\ngo:\nbar\nbar\nrdsr r4, SR_ARG0\n"
           "shli r5, r1, 2\nadd r4, r4, r5\nli r6, 77\nstg r6, [r4]\nexit")
    o = d.run(src, 1, wgd, 0, [out], wdog=300000)
    expect_eq(o.kind, "done", "a warp that exited must not deadlock the barrier")
    expect_eq(d.get(out, wgd), [77] * L + [SENT] * L, "surviving warp passed both barriers")
    d.w("WDOG_LIMIT", d.cfg.wdog_reset_ticks)
    src2 = ("rdsr r1, SR_LANE_ID\nandi r2, r1, 1\nbz r2, ev, ev\nexit\nev:\nbar\nrdsr r4, SR_ARG0\nrdsr r5, SR_TID\n"
            "shli r5, r5, 2\nadd r4, r4, r5\nli r6, 5\nstg r6, [r4]\nexit")
    d.put(out, [SENT] * wgd)
    o = d.run(src2, 1, wgd, 0, [out], wdog=300000)
    expect_eq(o.kind, "done", "lanes that exited do not make a barrier divergent")
    expect_eq(d.get(out, wgd), [5 if (t % L) % 2 == 0 else SENT for t in range(wgd)], "even lanes passed the barrier")


@check("shared_memory_is_private_to_each_workgroup")
def _shared_iso(d: Dev) -> None:
    L = d.cfg.lanes
    wgd, grid = 2 * L, 7
    n = wgd * grid
    out = d.alloc(4 * n)
    src = """
        rdsr r1, SR_TID
        shli r2, r1, 2
        rdsr r3, SR_WG_ID
        li   r4, 1000
        mul  r4, r3, r4
        add  r4, r4, r1
        sts  r4, [r2]
        bar
        rdsr r5, SR_WG_DIM
        addi r6, r1, 1
        slt  r7, r6, r5
        bnz  r7, ok, ok
        addi r6, r0, 0
    ok:
        shli r6, r6, 2
        lds  r8, [r6]
        rdsr r9, SR_GTID
        shli r9, r9, 2
        rdsr r10, SR_ARG0
        add  r10, r10, r9
        stg  r8, [r10]
        exit
    """
    d.launch_expect_done(src, grid, wgd, 4 * wgd, [out])
    exp = [wg * 1000 + (t + 1) % wgd for wg in range(grid) for t in range(wgd)]
    expect_eq(d.get(out, n), exp, "each workgroup sees only its own shared memory")


@check("smem_zero_flag_zeroes_shared_memory")
def _smem_zero(d: Dev) -> None:
    L = d.cfg.lanes
    wgd, grid = L + 1, 5
    n = wgd * grid
    out = d.alloc(4 * n)
    fill = "rdsr r1, SR_TID\nshli r2, r1, 2\nli r3, -1\nsts r3, [r2]\nexit"
    d.launch_expect_done(fill, grid, wgd, 4 * wgd)                       # dirty every slot (flag clear)
    rd = ("rdsr r1, SR_TID\nshli r2, r1, 2\nlds r4, [r2]\nrdsr r5, SR_GTID\nshli r5, r5, 2\nrdsr r6, SR_ARG0\n"
          "add r6, r6, r5\nstg r4, [r6]\nexit")
    d.put(out, [SENT] * n)
    d.launch_expect_done(rd, grid, wgd, 4 * wgd, [out], flags=1)
    expect_eq(d.get(out, n), [0] * n, "SMEM_ZERO: shared memory reads zero at workgroup start")


@check("fence_keeps_program_order")
def _fence(d: Dev) -> None:
    wgd, grid = d.cfg.lanes + 1, 2
    n = wgd * grid
    a, b, out = d.alloc(4 * n), d.alloc(4 * n), d.alloc(4 * n)
    src = """
        rdsr r1, SR_GTID
        shli r1, r1, 2
        rdsr r2, SR_ARG0
        add  r2, r2, r1
        rdsr r3, SR_ARG1
        add  r3, r3, r1
        rdsr r4, SR_ARG2
        add  r4, r4, r1
        li   r5, 11
        stg  r5, [r2]
        fence
        li   r6, 22
        stg  r6, [r3]
        fence
        ldg  r7, [r2]
        ldg  r8, [r3]
        add  r9, r7, r8
        stg  r9, [r4]
        exit
    """
    d.launch_expect_done(src, grid, wgd, 0, [a, b, out])
    expect_eq(d.get(out, n), [33] * n, "loads after fence see the earlier stores")


@check("instruction_memory_capacity_and_fall_off_end")
def _imem(d: Dev) -> None:
    n = d.cfg.imem_words
    full = ["nop"] * (n - 1) + ["exit"]
    o = d.run("\n".join(full))
    expect_eq(o.kind, "done", "a kernel of exactly IMEM_WORDS instructions is legal")
    d.reset()
    o = d.run("\n".join(["nop"] * n))
    expect_eq(o.kind, "fault", "a kernel with no exit faults")
    expect_eq(o.fault["CODE"], FC["F_PC_RANGE"], "falling off the end of a full image")
    expect_eq(o.fault["DATA"], n, "FAULT_DATA = pc")
    expect_eq(o.fault["PC"], n, "FAULT_PC")


# =============================================================================== 6. interrupts
@check("interrupts_levels_enable_and_sticky")
def _ints(d: Dev) -> None:
    d.w("INT_ENABLE", 0)
    d.launch_expect_done("exit")
    expect_eq(d.r("INT_STATUS") & 1, 1, "INT_STATUS.DONE set even when not enabled")
    expect(not d.t.irq(), "irq low while INT_ENABLE=0")
    expect_eq(d.field("STATUS", "IRQ"), 0, "STATUS.IRQ low")
    d.w("INT_ENABLE", 1)
    expect(d.t.irq(), "irq is the level |(INT_STATUS & INT_ENABLE)")
    expect_eq(d.field("STATUS", "IRQ"), 1, "STATUS.IRQ high")
    d.w("INT_STATUS", 1)
    expect(not d.t.irq(), "irq drops once the cause is cleared")
    d.launch_expect_done("exit")
    d.launch_expect_done("exit")                                    # second event while set: not queued
    expect(d.t.irq(), "irq high after completion")
    d.w("INT_STATUS", 1)
    expect_eq(d.r("INT_STATUS") & 1, 0, "one W1C clears a sticky bit (events are not queued)")
    d.w("INT_ENABLE", 2)
    o = d.run("trap 1")
    expect_eq(o.kind, "fault", "trap faults")
    expect(d.t.irq(), "fault interrupt")
    d.w("INT_STATUS", 2)
    d.reset()
    d.w("INT_ENABLE", 4)
    d.submit(d.desc(0, 0))
    expect_eq(d.finish().launch_err, LE["LE_CODE_SIZE"], "descriptor with CODE_WORDS=0 is rejected")
    expect(d.t.irq(), "launch-error interrupt (LE_CODE_SIZE)")
    d.w("INT_STATUS", 4)
    d.w("INT_ENABLE", 8)
    d.t.reg_read(0x058)
    expect(d.t.irq(), "host-error interrupt")


# =============================================================================== 7. performance counters
@check("perf_counters_architectural_values")
def _perf(d: Dev) -> None:
    L, grid = d.cfg.lanes, 2
    wgd = L + 2
    o = d.launch_expect_done("nop\nnop\nnop\nexit", grid, wgd)
    expect_eq(o.issued, grid * 2 * 4, "PERF_ISSUED = warp instructions committed (2 warps x 4 insns x 2 workgroups)")
    expect_eq(o.lane_ops, grid * (4 * L + 4 * 2), "PERF_LANE_OPS = sum of active-lane counts")
    expect_eq(o.wg_dispatched, grid, "WG_DISPATCHED")
    expect_eq(o.wg_completed, grid, "WG_COMPLETED")
    expect(o.cycles > 0, "PERF_CYCLES counts while BUSY")
    o2 = d.launch_expect_done("exit")
    expect_eq(o2.issued, 1, "counters are cleared by the next accepted doorbell")
    expect_eq(o2.wg_completed, 1, "WG_COMPLETED cleared")


@check("perf_counters_exclude_faulting_instruction")
def _perf_fault(d: Dev) -> None:
    o = d.run("nop\nnop\ntrap 1")
    expect_eq(o.kind, "fault", "trap")
    expect_eq(o.issued, 2, "the faulting instruction is not counted")
    expect_eq(o.lane_ops, 2, "lane ops of the two committed instructions")


# =============================================================================== 8. execution faults
def _expect_fault(o: Outcome, code: str, pc=None, data=None, lane=None, mask=None, wg=None, tag: str = "") -> None:
    t = f"{code}{(' ' + tag) if tag else ''}"
    expect_eq(o.kind, "fault", f"{t}: outcome (launch_err={o.launch_err})")
    f = o.fault
    expect_eq(f["CODE"], FC[code], f"{t}: FAULT_CODE")
    if pc is not None:
        expect_eq(f["PC"], pc, f"{t}: FAULT_PC")
    if data is not None:
        expect_eq(f["DATA"], data & MASK32, f"{t}: FAULT_DATA")
    if lane is not None:
        expect_eq((f["LOC"] >> 16) & 0xFF, lane, f"{t}: FAULT_LOC.LANE")
    if mask is not None:
        expect_eq(f["MASK"], mask, f"{t}: FAULT_MASK")
    if wg is not None:
        expect_eq(f["WG"], wg, f"{t}: FAULT_WG")
    expect_eq(o.status & 0xF, 9, f"{t}: STATUS must be READY|FAULTED (BUSY=0, DONE=0)")
    expect_eq(o.int_status & 2, 2, f"{t}: INT_STATUS.FAULT")


@check("fault_illegal_instruction")
def _f_illegal(d: Dev) -> None:
    cases = [
        ("undefined opcode 63", 0xFC000000),
        ("nop with a reserved bit", 0x00000001),
        ("add with a reserved bit", encode("add", rd=1, rs1=2, rs2=3) | 1),
        ("bz with reconvergence offset 0", encode("bz", rs1=1, imm=1, imm2=1) & ~0x7FF),
        ("rdsr of undefined special register 9", encode("rdsr", rd=1, imm=9)),
        ("rdsr of undefined special register 24", encode("rdsr", rd=1, imm=24)),
        ("exit with a reserved bit", encode("exit") | (1 << 25)),
    ]
    for label, word in cases:
        o = d.run(f"nop\n.word {word}\nexit")
        _expect_fault(o, "F_ILLEGAL_INSN", pc=1, data=word, lane=0, mask=1, tag=label)
        d.reset()


@check("fault_pc_range")
def _f_pc(d: Dev) -> None:
    _expect_fault(d.run("nop"), "F_PC_RANGE", pc=1, data=1, tag="falling off the end")
    d.reset()
    _expect_fault(d.run("nop\nbra 50\nexit"), "F_PC_RANGE", pc=1, data=50, tag="bra beyond the image")
    d.reset()
    _expect_fault(d.run("nop\nnop\nbra -3\nexit"), "F_PC_RANGE", pc=2, data=-3, tag="bra before the image")
    d.reset()
    _expect_fault(d.run("bz r0, 99, 100\nexit"), "F_PC_RANGE", pc=0, data=99, tag="target outside wins over reconv")
    d.reset()
    _expect_fault(d.run("bnz r0, 2, 100\nnop\nexit"), "F_PC_RANGE", pc=0, data=100,
                  tag="reconvergence outside (branch not taken: still checked)")
    d.reset()
    _expect_fault(d.run("bnz r0, 2, 3\nnop\nexit"), "F_PC_RANGE", pc=0, data=3, tag="reconvergence == CODE_WORDS")


@check("fault_reconvergence_layout_violation")
def _f_reconv(d: Dev) -> None:
    src = "rdsr r1, SR_LANE_ID\nandi r2, r1, 1\nbz r2, far, near\nnop\nnear: nop\nnop\nfar: nop\nexit"
    o = d.run(src, 1, 2)
    _expect_fault(o, "F_RECONV", pc=6, data=4, tag="path ran past its reconvergence address")


@check("fault_global_memory_alignment_and_range")
def _f_gmem(d: Dev) -> None:
    GM = d.cfg.gmem_bytes
    cases = [
        ("misaligned load", f"li r2, 0x1002\nldg r1, [r2]\nexit", "F_GMEM_ALIGN", 0x1002),
        ("misaligned via offset", f"li r2, 0x1000\nldg r1, [r2 + 2]\nexit", "F_GMEM_ALIGN", 0x1002),
        ("misaligned store", f"li r2, 0x1001\nstg r1, [r2]\nexit", "F_GMEM_ALIGN", 0x1001),
        ("misaligned atomic", f"li r2, 0x1003\natomadd r1, [r2], r1\nexit", "F_GMEM_ALIGN", 0x1003),
        ("load at GMEM_BYTES", f"li r2, {GM}\nldg r1, [r2]\nexit", "F_GMEM_RANGE", GM),
        ("store at GMEM_BYTES", f"li r2, {GM}\nstg r1, [r2]\nexit", "F_GMEM_RANGE", GM),
        ("atomic at GMEM_BYTES", f"li r2, {GM}\natomadd r1, [r2], r1\nexit", "F_GMEM_RANGE", GM),
        ("negative address", "li r2, -4\nldg r1, [r2]\nexit", "F_GMEM_RANGE", 0xFFFFFFFC),
        ("misaligned and out of range: misalignment first", f"li r2, {GM + 2}\nldg r1, [r2]\nexit",
         "F_GMEM_ALIGN", GM + 2),
    ]
    for label, src, code, data in cases:
        o = d.run(src)
        _expect_fault(o, code, data=data, lane=0, mask=1, tag=label)
        d.reset()


@check("global_memory_boundary_accesses_are_legal")
def _g_bound(d: Dev) -> None:
    GM = d.cfg.gmem_bytes
    out = d.alloc(8)
    d.put(GM - 4, [0xBEEF0001])
    d.put(0, [0x1234ABCD])
    src = (f"li r2, {GM - 4}\nldg r3, [r2]\nrdsr r4, SR_ARG0\nstg r3, [r4]\nldg r5, [r0]\nstg r5, [r4 + 4]\n"
           f"li r6, 0x55\nstg r6, [r2]\nexit")
    d.launch_expect_done(src, 1, 1, 0, [out])
    expect_eq(d.get(out, 2), [0xBEEF0001, 0x1234ABCD], "last word and address 0 are valid")
    expect_eq(d.get(GM - 4, 1), [0x55], "store to the last word")


_K_LANEADDR = """
        rdsr r1, SR_LANE_ID
        shli r2, r1, 2
        rdsr r3, SR_ARG0
        add  r3, r3, r2
        ldg  r4, [r3]
        li   r5, 0x1234
        {op}
        exit
"""


@check("fault_memory_instruction_is_precise_and_lowest_lane_reported")
def _f_prec(d: Dev) -> None:
    GM = d.cfg.gmem_bytes
    buf, tbl = d.alloc(16), d.alloc(16)
    scen = [
        ("range before misalign (lane 1 is lowest failing)", [buf, GM + 8, buf + 2], "F_GMEM_RANGE", 1, GM + 8),
        ("misalign lane 1, range lane 2", [buf, buf + 2, GM + 8], "F_GMEM_ALIGN", 1, buf + 2),
        ("lane 1 both misaligned and out of range", [buf, GM + 2, buf], "F_GMEM_ALIGN", 1, GM + 2),
        ("lane 0 range, lane 1 misaligned", [GM + 8, buf + 2, buf], "F_GMEM_RANGE", 0, GM + 8),
    ]
    for opname, op in (("store", "stg r5, [r4]"), ("load", "ldg r6, [r4]"), ("atomic", "atomadd r6, [r4], r5")):
        for label, addrs, code, lane, data in scen:
            d.put(buf, [SENT] * 4)
            d.put(tbl, addrs)
            o = d.run(_K_LANEADDR.format(op=op), 1, 3, 0, [tbl])
            _expect_fault(o, code, data=data, lane=lane, mask=0b111, tag=f"{opname}: {label}")
            if opname != "load":
                expect_eq(d.get(buf, 1), [SENT], f"{opname}: no lane may have performed its access ({label})")
            d.reset()


@check("fault_shared_memory_alignment_and_range")
def _f_smem(d: Dev) -> None:
    cases = [
        ("lds at SHARED_BYTES", "lds r1, [r0 + 64]", 64, "F_SMEM_RANGE", 64),
        ("sts at SHARED_BYTES", "sts r1, [r0 + 64]", 64, "F_SMEM_RANGE", 64),
        ("lds misaligned", "lds r1, [r0 + 2]", 64, "F_SMEM_ALIGN", 2),
        ("sts misaligned", "sts r1, [r0 + 6]", 64, "F_SMEM_ALIGN", 6),
        ("misaligned and out of range", "sts r1, [r0 + 66]", 64, "F_SMEM_ALIGN", 66),
        ("negative offset", "lds r1, [r0 - 4]", 64, "F_SMEM_RANGE", 0xFFFFFFFC),
        ("no shared memory allocated", "lds r1, [r0]", 0, "F_SMEM_RANGE", 0),
    ]
    for label, insn, shared, code, data in cases:
        o = d.run(f"{insn}\nexit", 1, 1, shared)
        _expect_fault(o, code, pc=0, data=data, lane=0, mask=1, tag=label)
        d.reset()
    out = d.alloc(4)
    d.launch_expect_done("li r2, 7\nsts r2, [r0 + 60]\nlds r3, [r0 + 60]\nrdsr r4, SR_ARG0\nstg r3, [r4]\nexit",
                         1, 1, 64, [out])
    expect_eq(d.get(out, 1), [7], "last shared word (SHARED_BYTES-4) is valid")


@check("fault_stack_overflow_small_config", configs=("small",))
def _f_stack(d: Dev) -> None:
    src = """
        rdsr r1, SR_LANE_ID
        andi r2, r1, 1
        bz   r2, evenp, join1
        andi r3, r1, 2
        bz   r3, o_a, o_j
        nop
    o_a: nop
    o_j: bra join1
    evenp:
        andi r3, r1, 2
        bz   r3, e_a, e_j
        nop
    e_a: nop
    e_j: nop
    join1:
        exit
    """
    o = d.run(src, 1, d.cfg.lanes)
    _expect_fault(o, "F_STACK_OVERFLOW", data=3, tag="nested divergence on a 4-entry stack")


@check("fault_barrier_divergent")
def _f_bar(d: Dev) -> None:
    src = "rdsr r1, SR_LANE_ID\nbz r1, other, join\nbar\nother: nop\njoin: exit"
    o = d.run(src, 1, 2)
    _expect_fault(o, "F_BAR_DIVERGENT", pc=2, data=0b11, mask=0b10, tag="bar while lane 0 waits elsewhere")


@check("fault_trap_location_and_masks")
def _f_trap(d: Dev) -> None:
    _expect_fault(d.run("nop\ntrap 0x1234"), "F_TRAP", pc=1, data=0x1234, lane=0, mask=1, tag="trap code")
    d.reset()
    L = d.cfg.lanes
    src = "rdsr r1, SR_WG_ID\naddi r1, r1, -2\nbnz r1, ok, ok\ntrap 7\nok: exit"
    _expect_fault(d.run(src, 3, L), "F_TRAP", pc=3, data=7, lane=0, mask=(1 << L) - 1, wg=2,
                  tag="only workgroup 2 traps")
    d.reset()
    _expect_fault(d.run("trap 1", 1, 3), "F_TRAP", pc=0, data=1, lane=0, mask=0b111, tag="partial warp")
    d.reset()
    src = "rdsr r1, SR_LANE_ID\nslti r2, r1, 2\nbnz r2, ok, ok\ntrap 3\nok: exit"
    _expect_fault(d.run(src, 1, L), "F_TRAP", pc=3, data=3, lane=2, mask=((1 << L) - 1) & ~3,
                  tag="lowest *active* lane is reported when lanes 0,1 are elsewhere")


@check("fault_location_single_warp_reference_dispatch_policy")
def _f_loc(d: Dev) -> None:
    """Policy check (docs/05 5.1 lists this under the reference policy): on an idle device a lone warp
    lands on EG 0, warp slot 0.  Any sane dispatch policy does this; it is not architectural."""
    o = d.run("trap 1")
    _expect_fault(o, "F_TRAP")
    loc = o.fault["LOC"]
    expect_eq(loc & 0xFF, 0, "EG")
    expect_eq((loc >> 8) & 0xFF, 0, "warp slot")


@check("fault_is_sticky_blocks_launch_and_soft_reset_recovers")
def _f_sticky(d: Dev) -> None:
    code = d.load(assemble("trap 9").words)
    d.submit(d.desc(code, 1))
    o = d.finish()
    _expect_fault(o, "F_TRAP", data=9)
    saved = dict(o.fault)
    d.submit(d.desc(code, 1, grid=1, wg=1, args=[1]))                 # doorbell in FAULTED
    o2 = d.finish()
    expect_eq(o2.kind, "launch_error", "doorbell while FAULTED")
    expect_eq(o2.launch_err, LE["LE_FAULTED"], "LE_FAULTED")
    expect_eq({n: d.r("FAULT_" + n) for n in saved}, saved, "fault registers are not overwritten by a rejection")
    expect_eq(d.r("STATUS") & 8, 8, "FAULTED stays set")
    d.get(0x100, 1)                                                   # aperture is accessible in FAULTED
    d.reset()
    expect_eq(d.r("STATUS"), 1, "READY only after soft reset")
    for n in ("FAULT_CODE", "FAULT_LOC", "FAULT_PC", "FAULT_WG", "FAULT_MASK", "FAULT_DATA", "LAUNCH_ERR"):
        expect_eq(d.r(n), 0, f"{n} after soft reset")
    d.launch_expect_done("exit")


@check("watchdog_fault_and_disable")
def _wdog(d: Dev) -> None:
    o = d.run("L: bra L", wdog=40)
    expect_eq(o.kind, "fault", "endless loop with WDOG_LIMIT=40")
    f = o.fault
    expect_eq(f["CODE"], FC["F_WATCHDOG"], "FAULT_CODE")
    expect_eq(f["LOC"], 0xFFFFFF, "device-level fault location")
    expect_eq((f["PC"], f["WG"], f["MASK"]), (0, 0, 0), "FAULT_PC/WG/MASK of a watchdog fault")
    expect(f["DATA"] >= 40, f"FAULT_DATA = elapsed time must be >= WDOG_LIMIT, got {f['DATA']}")
    d.reset()
    d.w("WDOG_LIMIT", 0)
    src = "li r2, 400\nl: addi r2, r2, -1\nbnz r2, l, e\ne: exit"
    o = d.run(src, wdog=0)
    expect_eq(o.kind, "done", "WDOG_LIMIT=0 disables the watchdog")


@check("soft_reset_aborts_running_launch")
def _reset_run(d: Dev) -> None:
    mark = d.alloc(4)
    d.put(mark, [0x600D])
    code = d.load(assemble("L: bra L").words)
    d.w("WDOG_LIMIT", 0)
    d.submit(d.desc(code, 1))
    d.t.advance(50)
    expect_eq(d.r("STATUS") & 2, 2, "still BUSY")
    d.reset()
    expect_eq(d.r("STATUS"), 1, "idle after reset")
    expect_eq(d.get(mark, 1), [0x600D], "global memory survives")
    for n in ("PERF_CYCLES", "PERF_ISSUED", "WG_DISPATCHED", "WG_COMPLETED", "INT_STATUS"):
        expect_eq(d.r(n), 0, f"{n} after reset")
    d.launch_expect_done("exit")


# =============================================================================== 9. the example kernels
def _lcg(seed: int, n: int) -> List[int]:
    out, x = [], seed & MASK32
    for _ in range(n):
        x = (x * 1664525 + 1013904223) & MASK32
        out.append(x)
    return out


def _p2floor(n: int) -> int:
    p = 1
    while p * 2 <= n:
        p *= 2
    return p


def _diverge_ref(t: int) -> Optional[int]:
    v = 100 + t if t & 1 else 200 - t
    v += 1000 if t & 2 else -1
    n, i = t & 7, 0
    while i < n:
        v += i
        i += 1
        if v & 16:
            break
    return None if n == 5 else v & MASK32


def _kernel_words(name: str) -> List[int]:
    with open(SF_G1_DIR / "examples" / "kernels" / f"{name}.sfa", encoding="utf-8") as fh:
        return assemble(fh.read(), f"{name}.sfa").words


def _run_example(d: Dev, name: str):
    """Mirror of the vendored host flow (same allocation order, so device addresses -- and the
    commit trace -- equal the golden run).  Returns (outcome, outputs-dict, expected-dict)."""
    cfg, G = d.cfg, 8
    if name == "vecadd":
        n, wg = 70, min(32, cfg.max_wg_threads)
        a, b = _lcg(1, n), _lcg(2, n)
        pa, pb, pc = d.alloc(4 * n), d.alloc(4 * n), d.alloc(4 * (n + G))
        d.put(pa, a), d.put(pb, b), d.put(pc, [SENT] * (n + G))
        o = d.run(_kernel_words(name), (n + wg - 1) // wg, wg, 0, [pa, pb, pc, n])
        exp = [(x + y) & MASK32 for x, y in zip(a, b)] + [SENT] * G
        return o, {"c": d.get(pc, n + G)}, {"c": exp}
    if name == "reduce_sum":
        n, wg = 100, _p2floor(min(16, cfg.max_wg_threads))
        data = [(x >> 8) % 1000 for x in _lcg(3, n)]
        pin, pout = d.alloc(4 * n), d.alloc(4)
        d.put(pin, data), d.put(pout, [0])
        o = d.run(_kernel_words(name), (n + wg - 1) // wg, wg, 4 * wg, [pin, pout, n])
        return o, {"sum": d.get(pout, 1)[0]}, {"sum": sum(data) & MASK32}
    if name == "matmul_i32":
        M, K, N = 6, 5, 7
        wg = min(8, cfg.max_wg_threads)
        A = [((x >> 16) % 201 - 100) & MASK32 for x in _lcg(4, M * K)]
        B = [((x >> 16) % 201 - 100) & MASK32 for x in _lcg(5, K * N)]
        pA, pB, pC = d.alloc(4 * M * K), d.alloc(4 * K * N), d.alloc(4 * (M * N + G))
        d.put(pA, A), d.put(pB, B), d.put(pC, [SENT] * (M * N + G))
        o = d.run(_kernel_words(name), M, wg, 0, [pA, pB, pC, N, K])
        exp = [sum(_s32(A[i * K + t]) * _s32(B[t * N + j]) for t in range(K)) & MASK32
               for i in range(M) for j in range(N)] + [SENT] * G
        return o, {"C": d.get(pC, M * N + G)}, {"C": exp}
    if name == "diverge":
        wg, grid = min(20, cfg.max_wg_threads), 2
        nthr = wg * grid
        po = d.alloc(4 * nthr)
        d.put(po, [0xAAAAAAAA] * nthr)
        o = d.run(_kernel_words(name), grid, wg, 0, [po])
        exp = [0xAAAAAAAA if _diverge_ref(t) is None else _diverge_ref(t) for t in range(nthr)]
        return o, {"out": d.get(po, nthr)}, {"out": exp}
    raise KeyError(name)


def _example_check(name: str):
    def fn(d: Dev) -> None:
        o, got, exp = _run_example(d, name)
        expect_eq(o.kind, "done", f"{name}: launch outcome (fault={o.fault})")
        for k in exp:
            expect_eq(got[k], exp[k], f"{name}: output '{k}' vs independent host computation")
    fn.__name__ = f"_ex_{name}"
    return fn


def _golden_check(name: str):
    def fn(d: Dev) -> None:
        o, got, _exp = _run_example(d, name)
        expect_eq(o.kind, "done", f"{name}: launch outcome")
        with open(SF_G1_DIR / "reference" / name / "report.json", encoding="utf-8") as fh:
            rep = json.load(fh)
        gouts = rep["outputs"]
        key = {"vecadd": "c", "matmul_i32": "C", "diverge": "out"}.get(name)
        if key:
            expect_eq(got[key], gouts[key]["data"] + ([SENT] * 8 if name != "diverge" else []),
                      f"{name}: output equals the golden report")
        else:
            expect_eq(got["sum"], gouts["sum"], f"{name}: sum equals the golden report")
        expect_eq(o.issued, rep["stats"]["warp_instructions"], f"{name}: PERF_ISSUED vs golden")
        expect_eq(o.lane_ops, rep["stats"]["lane_ops"], f"{name}: PERF_LANE_OPS vs golden")
        expect_eq(hashlib.sha256(b"".join(w.to_bytes(4, "little") for w in _kernel_words(name))).hexdigest(),
                  rep["kernel_sha256"], f"{name}: assembled kernel image vs golden")
        tr = d.t.commit_trace()
        if tr is None:
            raise _Skip("transport records no commit trace")
        h = hashlib.sha256()
        for line in tr:
            h.update(line.encode())
            h.update(b"\n")
        expect_eq(h.hexdigest(), rep["trace"]["sha256"], f"{name}: commit-trace digest vs golden")
    fn.__name__ = f"_gold_{name}"
    return fn


for _n in ("vecadd", "reduce_sum", "matmul_i32", "diverge"):
    _CHECKS.append((f"example_{_n}_matches_independent_computation", _example_check(_n), None))
    _CHECKS.append((f"example_{_n}_matches_golden_report", _golden_check(_n), ("default",)))


# =============================================================================== command line
def _backends(which: str) -> List[Tuple[str, Callable[[Config], Transport]]]:
    from .hwmodel import HwModelTransport
    from .transport import ReferenceTransport
    ref = ("reference", lambda c: ReferenceTransport(c, trace=True))
    hw = ("hwmodel", lambda c: HwModelTransport(c, trace=True))
    return {"reference": [ref], "hwmodel": [hw], "both": [ref, hw]}[which]


def main(argv: Optional[Sequence[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="python3 -m sfsdk.conformance", description=__doc__.split("\n\n")[0])
    ap.add_argument("--backend", choices=("reference", "hwmodel", "both"), default="both")
    ap.add_argument("--config", nargs="*", default=["default", "small", "wide"])
    ap.add_argument("-k", dest="only", default=None, help="run only checks whose name contains this text")
    ap.add_argument("--json", metavar="FILE", help="write the full report as JSON")
    a = ap.parse_args(argv)
    ok, reports = True, []
    for name, mk in _backends(a.backend):
        rep = run_conformance(mk, a.config, a.only, backend=name)
        print(rep.summary())
        ok &= rep.ok
        reports.append(rep.as_dict())
    if a.json:
        with open(a.json, "w") as f:
            json.dump(reports, f, indent=1)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
