"""SF-G1 assembler, driven by ``spec/sf_g1_isa.json`` (via :mod:`sfsdk.isa`).

Language: the SF-G1 assembler language of the specification (docs/10) -- labels, ``.equ``,
``.reg``, ``.word``, the pseudo-instructions ``li la mov neg not sgt sgtu j``, absolute
branch labels -- plus SDK *metadata directives* that describe how a kernel is to be launched::

    .kernel  NAME                          kernel name
    .arg     KIND NAME [ACCESS [ELEMS]]    KIND: ptr|u32|i32; ACCESS: r|w|rw (ptr only);
                                           ELEMS: expression = minimum extent of the buffer in words
    .shared  EXPR                          shared bytes per workgroup the kernel itself needs
    .shared_per_thread EXPR                additional shared bytes per *thread* (e.g. register spill area)
    .require EXPR [, "message"]            launch precondition (must evaluate non-zero)
    .entry   LABEL|INDEX                   entry instruction (default 0)

Metadata expressions are evaluated by the runtime at launch time over the argument names,
``wg_dim``, ``grid_dim``, ``lanes`` and the ``.equ`` constants.  The directives never change the
code words: a file without them assembles to exactly the words the reference assembler produces.
"""
from __future__ import annotations

import hashlib
import re
import struct
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from . import expr
from .binfmt import ACCESS, ARG_KINDS, ArgSpec, KernelImage, KernelMeta
from .errors import AsmError
from .isa import (BRANCH_ROFF_MAX, BRANCH_TOFF_MAX, BRANCH_TOFF_MIN, IMM18_MAX, IMM18_MIN, ISA, InsnSpec)
from .spec import MASK32

_REG = re.compile(r"^(?:r(\d{1,2})|zero)$", re.IGNORECASE)
_IDENT = re.compile(r"^[A-Za-z_.$][\w.$]*$")
_LABEL = re.compile(r"^\s*([A-Za-z_.$][\w.$]*)\s*:(?!:)")
_PSEUDO_ARITY = {"mov": 2, "neg": 2, "not": 2, "sgt": 3, "sgtu": 3, "j": 1}


@dataclass
class Program:
    """Result of assembling one source file."""

    words: List[int]
    labels: Dict[str, int]
    equs: Dict[str, int]
    listing: List[str]
    warnings: List[str]
    lines: Dict[int, int]                       # pc -> 1-based source line
    meta: Optional[KernelMeta] = None           # present iff the source used metadata directives
    filename: str = "<asm>"
    source_sha256: str = ""

    def to_bytes(self) -> bytes:
        return struct.pack(f"<{len(self.words)}I", *self.words)

    def to_hex(self) -> str:
        return "".join(f"{w:08x}\n" for w in self.words)

    def symbols(self) -> Dict[str, Dict[str, int]]:
        return {"labels": dict(self.labels), "equ": dict(self.equs)}

    def image(self, producer: str = "sfsdk.asm") -> KernelImage:
        import os
        meta = self.meta or KernelMeta(name=os.path.splitext(os.path.basename(self.filename))[0])
        meta.equ = dict(self.equs)
        return KernelImage(list(self.words), meta, self.meta is not None, dict(self.labels), dict(self.lines),
                           self.filename, self.source_sha256, producer)


@dataclass
class _Stmt:
    line: int
    kind: str                     # insn | li | word
    mnemonic: str
    operands: List[str]
    pc: int
    size: int


def _strip_comment(line: str) -> str:
    """Remove ``;`` and ``//`` comments, ignoring those inside double-quoted strings."""
    out, quoted, i = [], False, 0
    while i < len(line):
        c = line[i]
        if c == '"':
            quoted = not quoted
        elif not quoted and (c == ";" or line.startswith("//", i)):
            break
        out.append(c)
        i += 1
    return "".join(out).strip()


def _split_operands(s: str) -> List[str]:
    out, depth, cur, quoted = [], 0, [], False
    for ch in s:
        if ch == '"':
            quoted = not quoted
        if not quoted:
            if ch in "([":
                depth += 1
            elif ch in ")]":
                depth -= 1
        if ch == "," and depth == 0 and not quoted:
            out.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    tail = "".join(cur).strip()
    if tail or out:
        out.append(tail)
    return out


class Assembler:
    def __init__(self, num_regs: int = 16) -> None:
        self.num_regs = num_regs

    # ------------------------------------------------------------------ driver
    def assemble(self, source: str, filename: str = "<asm>") -> Program:
        self.filename = filename
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.symbols: Dict[str, int] = dict(ISA.special_registers)
        self.labels: Dict[str, int] = {}
        self.equs: Dict[str, int] = {}
        self.regalias: Dict[str, int] = {}
        self.meta = KernelMeta(name=_stem(filename))
        self.meta_seen = False
        self.entry_expr: Optional[Tuple[int, str]] = None
        src_lines = source.splitlines()
        stmts = self._pass1(src_lines)
        words, listing, lines = self._pass2(stmts, src_lines)
        self._finish_meta()
        if self.errors:
            raise AsmError(self.errors)
        return Program(words, dict(self.labels), dict(self.equs), listing, self.warnings, lines,
                       self.meta if self.meta_seen else None, filename,
                       hashlib.sha256(source.encode()).hexdigest())

    def _err(self, line: int, msg: str) -> None:
        self.errors.append(f"{self.filename}:{line}: error: {msg}")

    def _warn(self, line: int, msg: str) -> None:
        self.warnings.append(f"{self.filename}:{line}: warning: {msg}")

    # ------------------------------------------------------------------ symbols
    def _define(self, name: str, value: int, line: int, is_label: bool) -> None:
        if name in ISA.special_registers:
            self._err(line, f"'{name}' is a reserved special-register name")
        elif name in self.symbols:
            self._err(line, f"symbol '{name}' already defined")
        elif _REG.match(name) or name.lower() in ISA.by_mnemonic:
            self._err(line, f"'{name}' conflicts with a register or mnemonic")
        else:
            self.symbols[name] = value
            (self.labels if is_label else self.equs)[name] = value

    def _eval(self, text: str) -> int:
        return expr.evaluate(text, self.symbols)

    # ------------------------------------------------------------------ pass 1
    def _pass1(self, src_lines: List[str]) -> List[_Stmt]:
        stmts: List[_Stmt] = []
        pc = 0
        for lineno, raw in enumerate(src_lines, start=1):
            text = _strip_comment(raw)
            while True:
                m = _LABEL.match(text)
                if not m:
                    break
                self._define(m.group(1), pc, lineno, True)
                text = text[m.end():].strip()
            if not text:
                continue
            parts = text.split(None, 1)
            head, rest = parts[0], (parts[1] if len(parts) > 1 else "")
            hl = head.lower()
            if hl.startswith("."):
                pc = self._directive(hl, rest, lineno, stmts, pc)
                continue
            st = self._classify(lineno, hl, _split_operands(rest.strip()), pc)
            if st is not None:
                stmts.append(st)
                pc += st.size
        return stmts

    def _directive(self, d: str, rest: str, line: int, stmts: List[_Stmt], pc: int) -> int:
        ops = _split_operands(rest.strip())
        if d in (".equ", ".set"):
            if len(ops) != 2 or not _IDENT.match(ops[0]):
                self._err(line, f"{d} needs NAME, expr")
                return pc
            try:
                self._define(ops[0], self._eval(ops[1]), line, False)
            except expr.ExprError as e:
                self._err(line, str(e))
        elif d == ".reg":
            if len(ops) != 2 or not _IDENT.match(ops[0]) or not _REG.match(ops[1]):
                self._err(line, ".reg needs NAME, rN")
                return pc
            try:
                self.regalias[ops[0]] = self._regnum(ops[1])
            except expr.ExprError as e:
                self._err(line, str(e))
        elif d == ".word":
            if not ops or ops == [""]:
                self._err(line, ".word needs at least one value")
                return pc
            stmts.append(_Stmt(line, "word", d, ops, pc, len(ops)))
            return pc + len(ops)
        elif d in (".kernel", ".arg", ".shared", ".shared_per_thread", ".require", ".entry"):
            self.meta_seen = True
            self._meta_directive(d, rest.strip(), line)
        else:
            self._err(line, f"unknown directive '{d}'")
        return pc

    def _meta_directive(self, d: str, rest: str, line: int) -> None:
        try:
            if d == ".kernel":
                if not _IDENT.match(rest):
                    raise ValueError(".kernel needs a name")
                self.meta.name = rest
            elif d == ".arg":
                toks = rest.split(None, 3)
                if len(toks) < 2:
                    raise ValueError(".arg needs KIND NAME [ACCESS [ELEMS]]")
                kind, name = toks[0].lower(), toks[1]
                access = toks[2].lower() if len(toks) > 2 else ""
                elems = toks[3].strip() if len(toks) > 3 else None
                if kind not in ARG_KINDS:
                    raise ValueError(f"argument kind must be one of {', '.join(ARG_KINDS)}")
                if not _IDENT.match(name) or name in ("wg_dim", "grid_dim", "lanes"):
                    raise ValueError(f"bad argument name '{name}'")
                if any(a.name == name for a in self.meta.args):
                    raise ValueError(f"duplicate argument '{name}'")
                if access not in ACCESS:
                    raise ValueError("access must be r, w or rw")
                if kind != "ptr" and (access or elems):
                    raise ValueError("only ptr arguments take an access mode and an extent")
                if kind == "ptr" and not access:
                    access = "rw"
                if elems is not None:
                    expr.free_symbols(elems)
                if len(self.meta.args) >= 8:
                    raise ValueError("a kernel has at most 8 arguments (SR_ARG0..SR_ARG7)")
                self.meta.args.append(ArgSpec(name, kind, access, elems))
            elif d in (".shared", ".shared_per_thread"):
                expr.free_symbols(rest)
                setattr(self.meta, "shared" if d == ".shared" else "shared_per_thread", rest)
            elif d == ".require":
                ops = _split_operands(rest)
                if not ops or ops == [""] or len(ops) > 2:
                    raise ValueError('.require needs EXPR [, "message"]')
                expr.free_symbols(ops[0])
                msg = ops[1].strip().strip('"') if len(ops) == 2 else f"launch requirement failed: {ops[0]}"
                self.meta.requires.append((ops[0], msg))
            elif d == ".entry":
                self.entry_expr = (line, rest)
        except (ValueError, expr.ExprError) as e:
            self._err(line, f"{d}: {e}")

    def _finish_meta(self) -> None:
        if self.entry_expr:
            line, text = self.entry_expr
            try:
                self.meta.entry = self._eval(text)
            except expr.ExprError as e:
                self._err(line, f".entry: {e}")

    def _classify(self, line: int, mnem: str, ops: List[str], pc: int) -> Optional[_Stmt]:
        if mnem in ("li", "la"):
            if len(ops) != 2:
                self._err(line, f"{mnem} needs rd, expr")
                return None
            try:
                size = len(self._li_plan(self._eval(ops[1])))
            except expr.ExprError:
                size = 2                    # forward reference: reserve two words
            return _Stmt(line, "li", mnem, ops, pc, size)
        if mnem in _PSEUDO_ARITY:
            if len(ops) != _PSEUDO_ARITY[mnem]:
                self._err(line, f"{mnem} needs {_PSEUDO_ARITY[mnem]} operand(s)")
                return None
            return _Stmt(line, "insn", mnem, ops, pc, 1)
        if mnem not in ISA.by_mnemonic:
            self._err(line, f"unknown mnemonic '{mnem}'")
            return None
        return _Stmt(line, "insn", mnem, [] if ops == [""] else ops, pc, 1)

    @staticmethod
    def _li_plan(v: int) -> List[Tuple[str, int]]:
        if not -(1 << 31) <= v <= MASK32:
            raise expr.ExprError(f"constant {v} does not fit in 32 bits")
        u = v & MASK32
        s = u - (1 << 32) if u & 0x80000000 else u
        if IMM18_MIN <= s <= IMM18_MAX:
            return [("addi", s)]
        if u & 0x3FF == 0:
            return [("lui", u >> 10)]
        return [("lui", u >> 10), ("ori", u & 0x3FF)]

    # ------------------------------------------------------------------ operands
    def _regnum(self, tok: str) -> int:
        t = tok.strip()
        if t in self.regalias:
            return self.regalias[t]
        if t.lower() == "zero":
            return 0
        m = _REG.match(t)
        if not m or m.group(1) is None:
            raise expr.ExprError(f"expected a register, found '{tok}'")
        n = int(m.group(1))
        if n >= self.num_regs:
            raise expr.ExprError(f"register r{n} does not exist (r0..r{self.num_regs - 1})")
        return n

    def _mem(self, tok: str, allow_offset: bool) -> Tuple[int, int]:
        t = tok.strip()
        if not (t.startswith("[") and t.endswith("]")):
            raise expr.ExprError(f"expected a memory operand [rN + imm], found '{tok}'")
        m = re.match(r"^([A-Za-z_]\w*)\s*(.*)$", t[1:-1].strip())
        if not m:
            raise expr.ExprError(f"bad memory operand '{tok}'")
        base, rest, off = self._regnum(m.group(1)), m.group(2).strip(), 0
        if rest:
            if not allow_offset:
                raise expr.ExprError("this instruction takes [rN] with no offset")
            if rest[0] not in "+-":
                raise expr.ExprError(f"expected '+' or '-' after the base register in '{tok}'")
            off = self._eval(rest)
        return base, off

    # ------------------------------------------------------------------ pass 2
    def _pass2(self, stmts: List[_Stmt], src: List[str]):
        words: List[int] = []
        listing: List[str] = []
        lines: Dict[int, int] = {}
        for st in stmts:
            try:
                out = self._emit(st)
            except (expr.ExprError, ValueError) as e:
                self._err(st.line, f"{st.mnemonic}: {e}")
                out = [0] * st.size
            out = (out + [0] * st.size)[: st.size]
            for k, w in enumerate(out):
                lines[st.pc + k] = st.line
                text = src[st.line - 1].rstrip() if k == 0 else ""
                listing.append(f"{st.pc + k:04x}: {w:08x}  {text}".rstrip())
            words.extend(out)
        return words, listing, lines

    def _emit(self, st: _Stmt) -> List[int]:
        enc = ISA.encode
        m, ops = st.mnemonic, st.operands
        if st.kind == "word":
            out = []
            for o in ops:
                v = self._eval(o)
                if not -(1 << 31) <= v <= MASK32:
                    raise expr.ExprError(f".word value {v} does not fit in 32 bits")
                out.append(v & MASK32)
            return out
        if st.kind == "li":
            rd = self._regnum(ops[0])
            plan = self._li_plan(self._eval(ops[1]))
            out = []
            for mn, imm in plan:
                out.append(enc("addi", rd=rd, rs1=0, imm=imm) if mn == "addi" else
                           enc("lui", rd=rd, imm=imm) if mn == "lui" else enc("ori", rd=rd, rs1=rd, imm=imm))
            while len(out) < st.size:
                out.append(enc("nop"))
            return out
        if m == "mov":
            return [enc("addi", rd=self._regnum(ops[0]), rs1=self._regnum(ops[1]), imm=0)]
        if m == "neg":
            return [enc("sub", rd=self._regnum(ops[0]), rs1=0, rs2=self._regnum(ops[1]))]
        if m == "not":
            return [enc("xori", rd=self._regnum(ops[0]), rs1=self._regnum(ops[1]), imm=-1)]
        if m in ("sgt", "sgtu"):
            return [enc("slt" if m == "sgt" else "sltu", rd=self._regnum(ops[0]),
                        rs1=self._regnum(ops[2]), rs2=self._regnum(ops[1]))]
        if m == "j":
            m = "bra"
        return [self._encode(ISA.by_mnemonic[m], ops, st)]

    def _encode(self, spec: InsnSpec, ops: List[str], st: _Stmt) -> int:
        if len(ops) != len(spec.syntax):
            raise ValueError(f"expected {len(spec.syntax)} operand(s) ({', '.join(spec.syntax)}), got {len(ops)}")
        f = {"rd": 0, "rs1": 0, "rs2": 0, "imm": 0, "imm2": 0}
        target = reconv = None
        for tok, op in zip(spec.syntax, ops):
            if tok in ("rd", "rs1", "rs2"):
                f[tok] = self._regnum(op)
            elif tok in ("imm", "sr"):
                f["imm"] = self._eval(op)
            elif tok == "mem":
                f["rs1"], f["imm"] = self._mem(op, True)
            elif tok == "memr":
                f["rs1"], _ = self._mem(op, False)
            elif tok == "target":
                target = self._eval(op)
            elif tok == "reconv":
                reconv = self._eval(op)
            else:                                           # pragma: no cover
                raise ValueError(f"internal: unknown syntax token {tok}")
        pc = st.pc
        if target is not None:
            f["imm"] = target - pc
            if spec.fmt.name == "B" and not BRANCH_TOFF_MIN <= f["imm"] <= BRANCH_TOFF_MAX:
                raise ValueError(f"branch target {target} is {f['imm']:+d} instructions away; a conditional "
                                 f"branch reaches {BRANCH_TOFF_MIN}..{BRANCH_TOFF_MAX}")
        if reconv is not None:
            if reconv <= pc:
                raise ValueError(f"reconvergence address {reconv} must be after the branch at {pc}")
            f["imm2"] = reconv - pc
            if f["imm2"] > BRANCH_ROFF_MAX:
                raise ValueError(f"reconvergence address {reconv} is {f['imm2']} instructions after the branch; "
                                 f"the field holds at most {BRANCH_ROFF_MAX}")
            if target is not None and target > reconv:
                self._warn(st.line, f"branch target {target} is beyond its reconvergence address {reconv}; "
                                    "a divergent execution will fault with F_RECONV")
        return ISA.encode(spec.mnemonic, **f)


def _stem(filename: str) -> str:
    import os
    s = os.path.splitext(os.path.basename(filename))[0]
    return s if _IDENT.match(s) else "kernel"


def assemble(source: str, filename: str = "<asm>", num_regs: int = 16) -> Program:
    return Assembler(num_regs).assemble(source, filename)


def assemble_file(path: str) -> Program:
    with open(path, "r", encoding="utf-8") as fh:
        return assemble(fh.read(), path)
