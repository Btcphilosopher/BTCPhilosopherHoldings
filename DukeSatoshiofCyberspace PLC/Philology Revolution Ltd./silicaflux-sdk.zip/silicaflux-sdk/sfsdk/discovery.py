"""Device enumeration and opening.

A *backend* is a named way of obtaining transports (simulators here; a board or an RTL co-simulation
would register itself the same way).  Enumeration instantiates each (backend, configuration) pair,
reads the device's own identification and capability registers and returns :class:`DeviceInfo` records:
what is listed is what the device reports, not what the SDK assumes.

Built-in backends
-----------------
``reference``  the functional reference simulator (architectural oracle)
``hwmodel``    the cycle-level microarchitectural hardware model (a *model*, not RTL)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple, Union

from .errors import ApiError
from .runtime import Device, DeviceInfo, probe
from .spec import Config, config_names
from .transport import LineTransport, ReferenceTransport, Transport

Factory = Callable[..., Transport]


@dataclass
class Backend:
    name: str
    description: str
    factory: Factory                          # factory(config: Config, trace: bool) -> Transport
    available: Callable[[], Tuple[bool, str]] = lambda: (True, "")
    configs: Optional[Callable[[], List[str]]] = None


def _hw_factory(config: Config, trace: bool = False, **kw) -> Transport:
    from .hwmodel import HwModelTransport
    return HwModelTransport(config, trace=trace, **kw)


def _hw_available() -> Tuple[bool, str]:
    try:
        from .hwmodel import HwModelTransport  # noqa: F401
        return True, ""
    except Exception as e:                       # pragma: no cover - reported to the caller
        return False, f"{type(e).__name__}: {e}"


_BACKENDS: Dict[str, Backend] = {
    "reference": Backend("reference", ReferenceTransport.description,
                         lambda config, trace=False, **kw: ReferenceTransport(config, trace=trace, **kw)),
    "hwmodel": Backend("hwmodel", "SF-G1 cycle-level microarchitectural model (a model, not RTL)", _hw_factory, _hw_available),
}


def register_backend(backend: Backend) -> None:
    """Make another implementation (board bridge, RTL co-simulation, ...) discoverable."""
    _BACKENDS[backend.name] = backend


def register_line_device(name: str, command: List[str], description: str = "device behind the SF-G1 line protocol",
                         config: str = "default") -> None:
    """Register an external process speaking the line protocol of the SF-G1 spec (docs/11 11.4)."""
    register_backend(Backend(name, description, lambda cfg, trace=False, **kw: LineTransport(command, cfg),
                             configs=lambda: [config]))


def backends() -> Dict[str, Backend]:
    return dict(_BACKENDS)


def enumerate_devices(backend_names: Optional[List[str]] = None, configs: Optional[List[str]] = None) -> List[DeviceInfo]:
    """List every available device, in a stable order (backend registration order x configuration name)."""
    out: List[DeviceInfo] = []
    for bname, b in _BACKENDS.items():
        if backend_names and bname not in backend_names:
            continue
        ok, _why = b.available()
        if not ok:
            continue
        for cname in (configs or (b.configs() if b.configs else config_names())):
            t = b.factory(Config.named(cname), False)
            try:
                out.append(probe(t, len(out)))
            finally:
                t.close()
    return out


def unavailable_backends() -> Dict[str, str]:
    return {n: why for n, b in _BACKENDS.items() for ok, why in [b.available()] if not ok}


def open_device(spec: Union[None, int, str] = None, *, backend: Optional[str] = None, config: Union[str, Config, None] = None,
                trace: bool = False, transport: Optional[Transport] = None, **device_opts) -> Device:
    """Open a device.

    ``spec``: ``None`` (reference:default), an index into :func:`enumerate_devices`, or ``"backend"`` / ``"backend:config"``.
    ``transport``: open an already constructed transport instead.  ``device_opts`` go to :class:`Device`
    (``guard``, ``auto_sync``, ``wait_mode``, ``keep_trace``).
    """
    if transport is not None:
        return Device(transport, **device_opts)
    if isinstance(spec, int):
        devs = enumerate_devices()
        if not 0 <= spec < len(devs):
            raise ApiError(f"no device with index {spec}; {len(devs)} device(s) available", "E_NO_DEVICE")
        backend, config = devs[spec].backend, devs[spec].config_name
    elif isinstance(spec, str):
        backend, _, c = spec.partition(":")
        config = c or config
    backend = backend or "reference"
    if backend not in _BACKENDS:
        raise ApiError(f"unknown backend {backend!r}; known: {', '.join(_BACKENDS)}", "E_NO_DEVICE")
    b = _BACKENDS[backend]
    ok, why = b.available()
    if not ok:
        raise ApiError(f"backend {backend!r} is not available: {why}", "E_NO_DEVICE")
    cfg = config if isinstance(config, Config) else Config.named(config or "default")
    trace = trace or device_opts.get("keep_trace", False)
    return Device(b.factory(cfg, trace), **device_opts)
