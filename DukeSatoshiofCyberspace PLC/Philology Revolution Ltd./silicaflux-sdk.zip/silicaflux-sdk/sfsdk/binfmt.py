"""Kernel images: the code words plus the metadata the SDK needs to launch them safely.

The *architectural* artefact is the code image: a flat array of little-endian 32-bit
instruction words (``.sfbin``), which is what a launch descriptor points at.  The device
neither knows nor checks anything else.

The SDK additionally defines the ``.sfk`` container, which wraps the same words with
**launch metadata** (argument kinds, buffer extents, shared-memory demand, launch
constraints, symbols, a pc->source-line table).  The metadata is SDK-level policy used for
argument validation; it is not part of the SF-G1 architecture.

``.sfk`` layout (little-endian)::

    0   4  magic  b"SFK1"
    4   2  container version (1)
    6   2  flags (0)
    8   4  ISA hash   (CRC-32 of the documentation-free ISA definition the code was built for)
   12   4  code_words
   16   4  meta_len
   20   4  CRC-32 over code bytes + meta bytes
   24  4*code_words   code
   ..  meta_len       metadata, canonical JSON (UTF-8)
"""
from __future__ import annotations

import hashlib
import json
import struct
import zlib
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

from .errors import SfError
from .isa import ISA, decode
from .spec import MASK32, isa_hash

MAGIC = b"SFK1"
ARG_KINDS = ("ptr", "u32", "i32")
ACCESS = ("", "r", "w", "rw")


@dataclass
class ArgSpec:
    name: str
    kind: str                       # "ptr" | "u32" | "i32"
    access: str = ""                # for ptr: "r", "w" or "rw" (what the kernel does through it)
    elems: Optional[str] = None     # for ptr: expression giving the minimum extent in 32-bit words

    def to_json(self) -> Dict:
        d = {"name": self.name, "kind": self.kind}
        if self.access:
            d["access"] = self.access
        if self.elems is not None:
            d["elems"] = self.elems
        return d

    @staticmethod
    def from_json(d: Dict) -> "ArgSpec":
        return ArgSpec(d["name"], d["kind"], d.get("access", ""), d.get("elems"))


@dataclass
class KernelMeta:
    name: str = "kernel"
    args: List[ArgSpec] = field(default_factory=list)
    shared: str = "0"                               # expression: user shared bytes per workgroup
    shared_per_thread: str = "0"                    # expression: extra shared bytes *per thread* (e.g. spill area)
    requires: List[Tuple[str, str]] = field(default_factory=list)   # (expression, message): must be non-zero at launch
    entry: int = 0
    equ: Dict[str, int] = field(default_factory=dict)
    info: Dict[str, object] = field(default_factory=dict)           # producer-specific facts (regs used, spills, ...)

    def to_json(self) -> Dict:
        return {"name": self.name, "args": [a.to_json() for a in self.args], "shared": self.shared,
                "shared_per_thread": self.shared_per_thread, "requires": [list(r) for r in self.requires],
                "entry": self.entry, "equ": dict(self.equ), "info": dict(self.info)}

    @staticmethod
    def from_json(d: Dict) -> "KernelMeta":
        return KernelMeta(d.get("name", "kernel"), [ArgSpec.from_json(a) for a in d.get("args", [])],
                          d.get("shared", "0"), d.get("shared_per_thread", "0"),
                          [tuple(r) for r in d.get("requires", [])], d.get("entry", 0),
                          dict(d.get("equ", {})), dict(d.get("info", {})))


@dataclass
class KernelImage:
    words: List[int]
    meta: KernelMeta = field(default_factory=KernelMeta)
    has_meta: bool = True                           # False for a bare .sfbin
    labels: Dict[str, int] = field(default_factory=dict)
    lines: Dict[int, int] = field(default_factory=dict)             # pc -> source line
    source_name: str = ""
    source_sha256: str = ""
    producer: str = ""

    @property
    def name(self) -> str:
        return self.meta.name

    @property
    def num_words(self) -> int:
        return len(self.words)

    def to_sfbin(self) -> bytes:
        return struct.pack(f"<{len(self.words)}I", *[w & MASK32 for w in self.words])

    @staticmethod
    def from_sfbin(data: bytes, name: str = "kernel") -> "KernelImage":
        if len(data) % 4 or not data:
            raise SfError(f"not a code image: {len(data)} bytes is not a positive multiple of 4", "E_BINFMT")
        words = list(struct.unpack(f"<{len(data) // 4}I", data))
        return KernelImage(words, KernelMeta(name=name), has_meta=False, producer="raw .sfbin")

    @property
    def uses_order_dependent_atomics(self) -> bool:
        """True if some ``atomadd`` keeps its return value (rd != r0): such a kernel's commit
        trace depends on the order in which warps reach the atomic, so trace digests of two
        implementations are legitimately allowed to differ (SF-G1 docs/09 9.4)."""
        for w in self.words:
            i = decode(w)
            if i is not None and i.iclass == "ATOM" and i.rd != 0:
                return True
        return False

    def to_bytes(self) -> bytes:
        meta = {"meta": self.meta.to_json(), "labels": self.labels,
                "lines": {str(k): v for k, v in sorted(self.lines.items())},
                "source_name": self.source_name, "source_sha256": self.source_sha256, "producer": self.producer}
        mb = json.dumps(meta, sort_keys=True, separators=(",", ":")).encode()
        code = self.to_sfbin()
        crc = zlib.crc32(code + mb) & MASK32
        return MAGIC + struct.pack("<HHIIII", 1, 0, isa_hash(), len(self.words), len(mb), crc) + code + mb

    @staticmethod
    def from_bytes(data: bytes) -> "KernelImage":
        if data[:4] != MAGIC:
            raise SfError("not an .sfk kernel container (bad magic)", "E_BINFMT")
        if len(data) < 24:
            raise SfError("truncated .sfk container", "E_BINFMT")
        ver, _flags, ih, nwords, mlen, crc = struct.unpack_from("<HHIIII", data, 4)
        if ver != 1:
            raise SfError(f"unsupported .sfk container version {ver}", "E_BINFMT")
        if len(data) != 24 + 4 * nwords + mlen or nwords == 0:
            raise SfError("corrupt .sfk container (length mismatch)", "E_BINFMT")
        body = data[24:]
        if zlib.crc32(body) & MASK32 != crc:
            raise SfError("corrupt .sfk container (CRC mismatch)", "E_BINFMT")
        if ih != isa_hash():
            raise SfError(f".sfk was built for a different ISA definition (hash {ih:#010x}, this SDK {isa_hash():#010x})",
                          "E_ISA_MISMATCH")
        words = list(struct.unpack_from(f"<{nwords}I", body, 0))
        m = json.loads(body[4 * nwords:].decode())
        return KernelImage(words, KernelMeta.from_json(m["meta"]), True, dict(m.get("labels", {})),
                           {int(k): v for k, v in m.get("lines", {}).items()}, m.get("source_name", ""),
                           m.get("source_sha256", ""), m.get("producer", ""))

    @staticmethod
    def load(path: str) -> "KernelImage":
        """Load ``.sfk`` (container) or ``.sfbin`` (raw words, no metadata)."""
        with open(path, "rb") as f:
            data = f.read()
        if data[:4] == MAGIC:
            return KernelImage.from_bytes(data)
        import os
        return KernelImage.from_sfbin(data, os.path.splitext(os.path.basename(path))[0])

    def sha256(self) -> str:
        return hashlib.sha256(self.to_sfbin()).hexdigest()
