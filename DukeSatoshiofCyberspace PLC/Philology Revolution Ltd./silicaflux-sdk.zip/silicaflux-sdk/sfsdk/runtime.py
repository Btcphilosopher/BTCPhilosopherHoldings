"""SilicaFlux SDK runtime: device, buffers, kernels, launches.

A :class:`Device` wraps one transport (reference simulator, hardware model, or anything that speaks the
SF-G1 host interface) and implements the host side of the SF-G1 programming sequence (docs/07 7.7):

======================  ==============================================================================
enumeration             :mod:`sfsdk.discovery` (``enumerate_devices``/``open_device``); ``Device.info``
buffer allocation       ``Device.alloc`` -> :class:`Buffer` (first-fit allocator, 64-byte aligned, guard canaries)
host/device transfers   ``Buffer.write/read``, ``Device.write/read`` (bounds-checked against live allocations)
kernel loading          ``Device.load_kernel`` -> :class:`Kernel` (image placed in global memory, statically analysed)
argument validation     ``Kernel.bind`` (kinds, pointer extents, geometry, shared-memory demand, ``.require``)
dispatch                ``Kernel.submit/launch`` (64-byte descriptor, ``LAUNCH_ADDR``, ``DOORBELL``)
synchronisation         ``Launch.wait/poll``, ``Device.synchronize`` (polling or interrupt), in-order launch queue
error reporting         :mod:`sfsdk.errors`: ``LaunchRejected`` (LE_*), ``DeviceFault`` (decoded F_* report)
profiling               :mod:`sfsdk.profile` (``Device.profiler``), ``LaunchResult`` counters, instruction profile
======================  ==============================================================================

Execution model of the SDK (it mirrors the device): the device runs **one launch at a time** and has no queue
(docs/01 1.5).  ``submit`` therefore appends to a small *software* FIFO; the SDK starts the next launch when the
previous one completes.  Simulated devices only advance time inside ``wait/poll/synchronize``.
"""
from __future__ import annotations

import hashlib
import os
import struct
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Deque, Dict, List, Optional, Sequence, Tuple, Union

from . import expr
from .asm import Program, assemble
from .binfmt import KernelImage
from .disasm import format_instr
from .errors import (ApiError, ArgumentError, BufferCorrupted, DeviceBusy, DeviceFault, DeviceMismatch,
                     DeviceTimeout, FaultReport, LaunchRejected, SfError)
from .isa import decode
from .memory import Allocator, Block, canary_word
from .profile import InstructionProfile, LaunchEvent, Profiler
from .spec import MASK32, Config, DeviceSpec, device_spec
from .transport import ApertureError, Transport

SPEC: DeviceSpec = device_spec()
R = SPEC.reg_offset

LE_DETAIL = {
    "LE_MAGIC": "descriptor magic mismatch", "LE_VERSION": "unsupported descriptor version",
    "LE_RESERVED": "unknown descriptor flag bit set", "LE_ALIGN": "a descriptor, code or shared-size field is not 4-byte aligned",
    "LE_RANGE": "descriptor or code image lies outside global memory", "LE_CODE_SIZE": "CODE_WORDS is 0 or exceeds IMEM_WORDS",
    "LE_ENTRY": "ENTRY_PC is outside the code image", "LE_DIMS": "GRID_DIM or WG_DIM is 0 or exceeds its limit",
    "LE_SHARED": "SHARED_BYTES exceeds the per-workgroup allocation",
    "LE_BUSY": "doorbell written while a launch was running", "LE_FAULTED": "doorbell written while the device was FAULTED (reset it first)",
}


# ====================================================================================== info
@dataclass
class DeviceInfo:
    """What a device reports about itself (all values are read from its registers)."""

    index: int
    backend: str
    config_name: str
    description: str
    device_id: int
    version: str
    cfg_hash: int
    lanes: int
    warps_per_eg: int
    num_eg: int
    wg_slots_per_eg: int
    smem_bytes_per_eg: int
    smem_per_workgroup: int
    imem_words: int
    simt_stack_depth: int
    num_regs: int
    gmem_bytes: int
    max_wg_threads: int
    max_grid_dim: int
    caps: Dict[str, int] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        d = dict(self.__dict__)
        d["cfg_hash"] = f"{self.cfg_hash:#010x}"
        d["device_id"] = f"{self.device_id:#010x}"
        return d

    def line(self) -> str:
        return (f"[{self.index}] {self.backend}:{self.config_name:<8} SF-G1 v{self.version}  cfg_hash={self.cfg_hash:#010x}  "
                f"{self.num_eg} EG x {self.warps_per_eg} warps x {self.lanes} lanes, "
                f"max wg {self.max_wg_threads}, shared {self.smem_per_workgroup} B/wg, imem {self.imem_words} words, "
                f"gmem {self.gmem_bytes // 1024} KiB")


def probe(transport: Transport, index: int = 0, ready_ticks: int = 1000) -> DeviceInfo:
    """Bring a transport up far enough to identify it: wait for READY, read ID/VERSION/CFG_HASH/CAPS_*."""
    n = 0
    while not (transport.reg_read(R["STATUS"]) & 1):
        n += max(transport.advance(1), 1)
        if n > ready_ticks:
            raise DeviceTimeout("device never became READY")
    dev_id = transport.reg_read(R["ID"])
    if dev_id != SPEC.device_id:
        raise DeviceMismatch(f"not an SF-G1 device: ID register reads {dev_id:#010x}, expected {SPEC.device_id:#010x}")
    ver = transport.reg_read(R["VERSION"])
    if ver >> 16 != SPEC.version_word >> 16:
        raise DeviceMismatch(f"unsupported SF-G1 major version {ver >> 16} (this SDK implements {SPEC.version_word >> 16})")
    caps = {c: transport.reg_read(R[c]) for c in ("CAPS_GEOM", "CAPS_SMEM", "CAPS_IMEM", "CAPS_GMEM", "CAPS_LIMITS")}
    cfg = Config.from_caps(caps)
    return DeviceInfo(index, transport.name, getattr(transport.config, "name", "probed"), transport.description, dev_id,
                      f"{ver >> 16}.{(ver >> 8) & 0xFF}.{ver & 0xFF}", transport.reg_read(R["CFG_HASH"]), cfg.lanes,
                      cfg.warps_per_eg, cfg.num_eg, cfg.wg_slots_per_eg, cfg.smem_bytes_per_eg, cfg.wg_slot_smem_bytes,
                      cfg.imem_words, cfg.simt_stack_depth, caps["CAPS_IMEM"] >> 24, cfg.gmem_bytes, cfg.max_wg_threads,
                      caps["CAPS_LIMITS"] >> 16, caps)


# ====================================================================================== values
def to_words(data: Union[bytes, bytearray, Sequence[int]]) -> bytes:
    """Little-endian bytes of ``data``: bytes-like objects pass through, integer sequences become 32-bit words."""
    if isinstance(data, (bytes, bytearray, memoryview)):
        return bytes(data)
    out = bytearray()
    for i, v in enumerate(data):
        if isinstance(v, bool) or not isinstance(v, int):
            raise ArgumentError(f"element {i} is {type(v).__name__}, expected an integer")
        if not -(1 << 31) <= v <= MASK32:
            raise ArgumentError(f"element {i} = {v} does not fit in 32 bits")
        out += struct.pack("<I", v & MASK32)
    return bytes(out)


@dataclass(frozen=True)
class DevicePtr:
    """An address inside a buffer (``Buffer.at``)."""
    addr: int
    buffer: "Buffer"

    def __int__(self) -> int:
        return self.addr


class Buffer:
    """A region of device global memory returned by :meth:`Device.alloc`."""

    def __init__(self, device: "Device", block: Block) -> None:
        self.device, self._block = device, block

    # -- properties --------------------------------------------------------------
    @property
    def addr(self) -> int:
        return self._block.addr

    @property
    def nbytes(self) -> int:
        return self._block.size

    @property
    def nwords(self) -> int:
        return self._block.size // 4

    @property
    def name(self) -> str:
        return self._block.name

    @property
    def freed(self) -> bool:
        return self._block.freed

    def __int__(self) -> int:
        return self.addr

    def __repr__(self) -> str:
        return f"<Buffer {self.name or '?'} @{self.addr:#x} {self.nbytes} B{' FREED' if self.freed else ''}>"

    def at(self, byte_offset: int) -> DevicePtr:
        if byte_offset % 4 or not 0 <= byte_offset < self._block.rsize:
            raise ArgumentError(f"offset {byte_offset} is outside buffer {self.name!r} ({self.nbytes} bytes) or not word aligned")
        return DevicePtr(self.addr + byte_offset, self)

    # -- transfers ---------------------------------------------------------------
    def write(self, data: Union[bytes, Sequence[int]], offset: int = 0) -> None:
        self.device._write(self, offset, to_words(data))

    def write_words(self, words: Sequence[int], offset_words: int = 0) -> None:
        self.device._write(self, 4 * offset_words, to_words(list(words)))

    def read(self, nbytes: Optional[int] = None, offset: int = 0) -> bytes:
        return self.device._read(self, offset, self.nbytes - offset if nbytes is None else nbytes)

    def read_words(self, count: Optional[int] = None, offset_words: int = 0) -> List[int]:
        n = (self.nwords - offset_words) if count is None else count
        b = self.device._read(self, 4 * offset_words, 4 * n)
        return list(struct.unpack(f"<{n}I", b)) if n else []

    def read_i32(self, count: Optional[int] = None, offset_words: int = 0) -> List[int]:
        return [w - (1 << 32) if w & 0x80000000 else w for w in self.read_words(count, offset_words)]

    def fill(self, word: int = 0) -> None:
        self.write_words([word] * self.nwords)

    def free(self) -> None:
        self.device.free(self)

    def check_guards(self) -> List[Tuple[int, int, int]]:
        """Return ``(address, expected, found)`` for every damaged guard word (empty when intact)."""
        return self.device._guard_damage(self._block)


# ====================================================================================== kernels
@dataclass
class BoundLaunch:
    """A fully validated launch: everything the descriptor needs."""
    grid: int
    wg: int
    shared: int
    words: List[int]                      # ARG0..ARGn
    values: Dict[str, int]
    flags: int
    warnings: List[str]


class Kernel:
    """A kernel image resident in device memory."""

    def __init__(self, device: "Device", image: KernelImage) -> None:
        self.device, self.image = device, image
        self.diagnostics: List[str] = []
        self._block: Optional[Block] = None
        cfg = device.config
        if image.num_words > cfg.imem_words:
            raise ArgumentError(f"kernel {image.name!r} has {image.num_words} instructions; the device's instruction memory holds "
                                f"{cfg.imem_words} (launch error LE_CODE_SIZE)", "E_KERNEL_TOO_LARGE")
        if not 0 <= image.meta.entry < image.num_words:
            raise ArgumentError(f"kernel {image.name!r}: entry {image.meta.entry} is outside the image (0..{image.num_words - 1})", "E_KERNEL_ENTRY")
        self.diagnostics = analyze_image(image)
        block = device.allocator.alloc(4 * image.num_words, 64, "code", f"code:{image.name}")
        self._block = block
        device._raw_write(block.addr, image.to_sfbin(), "code")
        device._init_guards(block)

    @property
    def name(self) -> str:
        return self.image.name

    @property
    def addr(self) -> int:
        return self._block.addr if self._block else 0

    @property
    def num_words(self) -> int:
        return self.image.num_words

    def disassemble(self, addresses: bool = False) -> str:
        from .disasm import disassemble
        return disassemble(self.image.words, addresses=addresses, symbols=self.image.labels)

    def unload(self) -> None:
        if self._block is not None:
            self.device.allocator.free(self._block.addr)
            self._block = None

    # ------------------------------------------------------------------ validation
    def signature(self) -> str:
        m = self.image.meta
        if not self.image.has_meta or not m.args:
            return f"{m.name}(<{'any' if not self.image.has_meta else 'no'} arguments>)"
        return f"{m.name}(" + ", ".join(f"{a.kind} {a.name}" + (f" [{a.access}]" if a.access else "") for a in m.args) + ")"

    def bind(self, grid: int, wg: int, args: Sequence[Any] = (), shared: Optional[int] = None, smem_zero: bool = False,
             **kwargs: Any) -> BoundLaunch:
        """Validate a launch completely, without touching the device.  Raises :class:`ArgumentError`."""
        dev, cfg, img = self.device, self.device.config, self.image
        meta = img.meta
        for nm, v, lo, hi in (("grid", grid, 1, cfg.max_grid_dim), ("wg", wg, 1, cfg.max_wg_threads)):
            if isinstance(v, bool) or not isinstance(v, int):
                raise ArgumentError(f"{nm} must be an integer, got {type(v).__name__}", "E_GEOMETRY")
            if not lo <= v <= hi:
                what = "workgroups per launch" if nm == "grid" else f"threads per workgroup (lanes {cfg.lanes} x warps per EG {cfg.warps_per_eg})"
                raise ArgumentError(f"{nm}={v} is outside 1..{hi}: this device allows at most {hi} {what}", "E_GEOMETRY")
        decl = meta.args if img.has_meta else None
        values: Dict[str, int] = {}
        words: List[int] = []
        warnings: List[str] = []
        ptrs: List[Tuple[str, Block, int, int, str]] = []        # name, block, addr, words, access
        pos = list(args)
        if decl is None:
            if kwargs:
                raise ArgumentError(f"kernel {meta.name!r} has no argument metadata; pass positional arguments only", "E_ARG_NAMES")
            if len(pos) > cfg.num_args:
                raise ArgumentError(f"a kernel takes at most {cfg.num_args} arguments, got {len(pos)}", "E_ARG_COUNT")
            for i, a in enumerate(pos):
                words.append(self._plain_arg(f"arg{i}", a))
                values[f"arg{i}"] = words[-1]
        else:
            if len(pos) > len(decl):
                raise ArgumentError(f"{self.signature()} takes {len(decl)} argument(s), got {len(pos)} positional", "E_ARG_COUNT")
            named = dict(zip([d.name for d in decl], pos))
            for k, v in kwargs.items():
                if k not in [d.name for d in decl]:
                    raise ArgumentError(f"unknown argument {k!r}; {self.signature()}", "E_ARG_NAMES")
                if k in named:
                    raise ArgumentError(f"argument {k!r} given twice", "E_ARG_NAMES")
                named[k] = v
            missing = [d.name for d in decl if d.name not in named]
            if missing:
                raise ArgumentError(f"missing argument(s) {', '.join(missing)}; {self.signature()}", "E_ARG_COUNT")
            for d in decl:
                v = named[d.name]
                if d.kind == "ptr":
                    block, addr = dev._resolve_ptr(d.name, v)
                    words.append(addr)
                    values[d.name] = addr
                    ptrs.append((d.name, block, addr, (block.payload_end - addr) // 4 if block else 0, d.access))
                else:
                    lo, hi = (0, MASK32) if d.kind == "u32" else (-(1 << 31), (1 << 31) - 1)
                    if isinstance(v, (Buffer, DevicePtr)) or isinstance(v, bool) or not isinstance(v, int):
                        raise ArgumentError(f"argument {d.name!r} ({d.kind}) expects an integer, got {type(v).__name__}", "E_ARG_KIND")
                    if not lo <= v <= hi:
                        raise ArgumentError(f"argument {d.name!r} ({d.kind}) = {v} is outside {lo}..{hi}", "E_ARG_RANGE")
                    values[d.name] = v
                    words.append(v & MASK32)
        # --- metadata expressions ------------------------------------------------
        env = dict(meta.equ)
        env.update(values)
        env.update(wg_dim=wg, grid_dim=grid, lanes=cfg.lanes)

        def ev(text: str, what: str) -> int:
            try:
                return expr.evaluate(text, env)
            except expr.ExprError as e:
                raise ArgumentError(f"kernel {meta.name!r}: cannot evaluate {what} '{text}': {e}", "E_METADATA")

        if decl is not None:
            for d in decl:
                if d.kind == "ptr" and d.elems is not None:
                    need = ev(d.elems, f"extent of {d.name}")
                    blk = next(p for p in ptrs if p[0] == d.name)
                    if need > 0:
                        if blk[1] is None or blk[2] == 0:
                            raise ArgumentError(f"argument {d.name!r} must point to a buffer of at least {need} words", "E_ARG_EXTENT")
                        if blk[3] < need:
                            raise ArgumentError(f"argument {d.name!r}: kernel needs {need} words ({4 * need} bytes) but the buffer "
                                                f"{blk[1].name!r} has only {blk[3]} words after the pointer", "E_ARG_EXTENT")
            for i, p in enumerate(ptrs):                          # aliasing between written and other buffers
                for q in ptrs[i + 1:]:
                    if p[1] is q[1] and p[1] is not None and ("w" in p[4] or "w" in q[4]):
                        pe = next((x.elems for x in decl if x.name == p[0]), None)
                        qe = next((x.elems for x in decl if x.name == q[0]), None)
                        pn = max(ev(pe, "extent"), 1) if pe is not None else p[3]
                        qn = max(ev(qe, "extent"), 1) if qe is not None else q[3]
                        if p[2] < q[2] + 4 * qn and q[2] < p[2] + 4 * pn:
                            warnings.append(f"arguments {p[0]!r} and {q[0]!r} overlap in buffer {p[1].name!r} and at least one is written "
                                            "(data race unless accesses are disjoint)")
        for text, msg in meta.requires:
            if not ev(text, "requirement"):
                raise ArgumentError(f"kernel {meta.name!r}: {msg} (requirement '{text}' failed for grid={grid}, wg={wg})", "E_REQUIRE")
        # --- shared memory --------------------------------------------------------
        fixed, per_thread = ev(meta.shared, "shared"), ev(meta.shared_per_thread, "shared_per_thread")
        need = fixed + per_thread * wg
        if need < 0:
            raise ArgumentError(f"kernel {meta.name!r}: shared-memory expression is negative ({need})", "E_SHARED")
        need = (need + 3) & ~3
        cap = cfg.wg_slot_smem_bytes
        if shared is None:
            shared = need
        else:
            if isinstance(shared, bool) or not isinstance(shared, int) or shared < 0 or shared % 4:
                raise ArgumentError(f"shared must be a non-negative multiple of 4, got {shared!r}", "E_SHARED")
            if shared < need:
                raise ArgumentError(f"kernel {meta.name!r} needs {need} shared bytes at wg={wg} ({fixed} fixed + {per_thread} x {wg} per-thread) "
                                    f"but shared={shared} was requested", "E_SHARED")
        if shared > cap:
            raise ArgumentError(f"launch needs {shared} bytes of shared memory per workgroup ({fixed} fixed + {per_thread} per thread x {wg} threads) "
                                f"but this device provides {cap} ({cfg.smem_bytes_per_eg} per EG / {cfg.wg_slots_per_eg} workgroup slots); "
                                f"reduce wg or the kernel's shared/spill demand", "E_SHARED")
        return BoundLaunch(grid, wg, shared, words, values, 1 if smem_zero else 0, warnings)

    @staticmethod
    def _plain_arg(name: str, a: Any) -> int:
        if isinstance(a, (Buffer, DevicePtr)):
            return int(a)
        if isinstance(a, bool) or not isinstance(a, int) or not -(1 << 31) <= a <= MASK32:
            raise ArgumentError(f"{name}: expected an integer or buffer, got {a!r}", "E_ARG_KIND")
        return a & MASK32

    # ------------------------------------------------------------------ dispatch
    def submit(self, grid: int, wg: int, args: Sequence[Any] = (), shared: Optional[int] = None, smem_zero: bool = False,
               watchdog: Optional[int] = None, **kwargs: Any) -> "Launch":
        """Validate and enqueue a launch; returns immediately with a :class:`Launch` handle."""
        bound = self.bind(grid, wg, args, shared, smem_zero, **kwargs)
        return self.device._enqueue(self, bound, watchdog)

    def launch(self, grid: int, wg: int, args: Sequence[Any] = (), shared: Optional[int] = None, smem_zero: bool = False,
               watchdog: Optional[int] = None, timeout_ticks: Optional[int] = None, **kwargs: Any) -> "LaunchResult":
        """``submit`` + ``wait``: returns the :class:`LaunchResult` or raises the launch's error."""
        return self.submit(grid, wg, args, shared, smem_zero, watchdog, **kwargs).wait(timeout_ticks)


def analyze_image(image: KernelImage) -> List[str]:
    """Static checks the architecture only performs at run time; returned as warnings."""
    out: List[str] = []
    n = len(image.words)
    max_arg = -1
    for pc, w in enumerate(image.words):
        i = decode(w)
        if i is None:
            out.append(f"pc {pc}: word {w:#010x} is not a legal instruction (F_ILLEGAL_INSN if executed)")
            continue
        if i.iclass == "JUMP" and not 0 <= pc + i.imm < n:
            out.append(f"pc {pc}: jump target {pc + i.imm} is outside the image (F_PC_RANGE)")
        if i.iclass == "BRANCH":
            if not 0 <= pc + i.imm < n:
                out.append(f"pc {pc}: branch target {pc + i.imm} is outside the image (F_PC_RANGE)")
            if pc + i.imm2 >= n:
                out.append(f"pc {pc}: reconvergence address {pc + i.imm2} is outside the image (F_PC_RANGE)")
        if i.mnemonic == "rdsr" and i.imm >= 16:
            max_arg = max(max_arg, i.imm - 16)
    last = decode(image.words[-1])
    if last is None or last.mnemonic not in ("exit", "bra", "trap"):
        out.append("the last instruction is neither exit nor an unconditional jump: execution can fall off the end (F_PC_RANGE)")
    if image.has_meta and max_arg >= len(image.meta.args):
        out.append(f"the code reads SR_ARG{max_arg} but only {len(image.meta.args)} argument(s) are declared")
    return out


# ====================================================================================== launches
@dataclass
class LaunchResult:
    kernel: str
    grid: int
    wg: int
    shared: int
    args: Dict[str, int]
    status: str
    ticks: int
    issued: int
    lane_ops: int
    lanes: int
    workgroups: int
    host_s: float
    backend: str
    config: str
    warnings: List[str] = field(default_factory=list)
    trace_digest: Optional[str] = None
    trace_lines: Optional[List[str]] = None
    counters: Dict[str, Any] = field(default_factory=dict)
    image: Optional[KernelImage] = None

    @property
    def ok(self) -> bool:
        return self.status == "done"

    @property
    def simt_efficiency(self) -> float:
        return self.lane_ops / (self.issued * self.lanes) if self.issued else 0.0

    def architectural(self) -> Dict[str, Any]:
        """The counters that must be identical on every conforming implementation of a race-free kernel."""
        return {"warp_instructions": self.issued, "lane_ops": self.lane_ops, "workgroups": self.workgroups,
                "trace_digest": self.trace_digest}

    def instruction_profile(self) -> InstructionProfile:
        if self.trace_lines is None or self.image is None:
            raise ApiError("no commit trace was recorded: open the device with trace=True", "E_NO_TRACE")
        return InstructionProfile(self.trace_lines, self.image.words, self.lanes, self.image.lines)


class Launch:
    """Handle of one submitted launch."""

    def __init__(self, device: "Device", kernel: Kernel, bound: BoundLaunch, watchdog: Optional[int], lid: int) -> None:
        self.device, self.kernel, self.bound, self.watchdog, self.id = device, kernel, bound, watchdog, lid
        self.state = "queued"             # queued | running | done | fault | rejected | timeout | cancelled
        self.result: Optional[LaunchResult] = None
        self.error: Optional[SfError] = None
        self._t0 = 0.0

    @property
    def finished(self) -> bool:
        return self.state not in ("queued", "running")

    @property
    def ok(self) -> bool:
        return self.state == "done"

    def poll(self, ticks: int = 0) -> bool:
        """Advance the device by up to ``ticks`` ticks (simulated devices) and report whether this launch has finished."""
        self.device._pump(ticks)
        return self.finished

    def wait(self, timeout_ticks: Optional[int] = None) -> LaunchResult:
        """Block until this launch finishes; raise its error (``DeviceFault``, ``LaunchRejected``, ...) if it failed."""
        self.device._run_until(lambda: self.finished, timeout_ticks, self)
        if self.error is not None:
            raise self.error
        assert self.result is not None
        return self.result

    def __repr__(self) -> str:
        return f"<Launch #{self.id} {self.kernel.name} grid={self.bound.grid} wg={self.bound.wg} {self.state}>"


# ====================================================================================== device
FAULT_MEANING: Dict[str, Callable[[int, Dict[str, int], "Device", "Launch"], str]] = {}


class Device:
    """One open SF-G1 device."""

    DEFAULT_TIMEOUT_TICKS = 50_000_000
    CHUNK_TICKS = 10_000

    def __init__(self, transport: Transport, *, guard: bool = True, auto_sync: bool = True, wait_mode: str = "poll",
                 keep_trace: bool = False, index: int = 0) -> None:
        if wait_mode not in ("poll", "irq"):
            raise ArgumentError("wait_mode must be 'poll' or 'irq'")
        self.t = transport
        self.info = probe(transport, index)
        self.config: Config = getattr(transport, "config", None) or Config.from_caps(self.info.caps)
        if self.config.caps_regs() != self.info.caps:
            raise DeviceMismatch("CAPS registers do not match the configuration the transport claims to implement")
        if self.config.cfg_hash() != self.info.cfg_hash:
            raise DeviceMismatch(f"CFG_HASH mismatch: device reports {self.info.cfg_hash:#010x}, this SDK's specification/configuration "
                                 f"hashes to {self.config.cfg_hash():#010x} (software and hardware were built from different definitions)")
        self.guard, self.auto_sync, self.wait_mode, self.keep_trace = guard, auto_sync, wait_mode, keep_trace
        self.allocator = Allocator(self.config.gmem_bytes, guard)
        self.profiler = Profiler()
        self.kernels: List[Kernel] = []
        self.queue: Deque[Launch] = deque()
        self.inflight: Optional[Launch] = None
        self.last_fault: Optional[FaultReport] = None
        self._lid = 0
        self._closed = False
        self._desc = self.allocator.alloc(4 * SPEC.desc_size_words, 64, "descriptor", "launch-descriptor")
        self._init_guards(self._desc)
        self.t.reg_write(R["INT_STATUS"], 0xF)                       # clear anything left from bring-up

    # ------------------------------------------------------------------ lifecycle
    @property
    def backend(self) -> str:
        return self.t.name

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self.t.close()

    def __enter__(self) -> "Device":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"<Device {self.backend}:{self.config.name} {self.info.cfg_hash:#010x}>"

    def reset(self) -> None:
        """Soft reset: abort everything, keep global memory (docs/08 8.3).  Queued launches are cancelled."""
        t0 = time.perf_counter()
        self._cancel_pending("the device was reset")
        self._soft_reset()
        self.profiler.add_sync("reset", time.perf_counter() - t0)

    def _soft_reset(self) -> None:
        self.t.reg_write(R["CTRL"], 1)
        n = 0
        while not (self.t.reg_read(R["STATUS"]) & 1):
            n += max(self.t.advance(1), 1)
            if n > 1000:
                raise DeviceTimeout("device did not leave reset")
        self.t.reg_write(R["INT_STATUS"], 0xF)
        self.inflight = None

    # ------------------------------------------------------------------ registers
    def reg(self, name: str) -> int:
        return self.t.reg_read(R[name])

    def status(self) -> Dict[str, bool]:
        s = self.reg("STATUS")
        return {"ready": bool(s & 1), "busy": bool(s & 2), "done": bool(s & 4), "faulted": bool(s & 8), "irq": bool(s & 16)}

    # ------------------------------------------------------------------ memory
    def alloc(self, nbytes: int, align: int = 64, name: str = "", zero: bool = True, init: Optional[Sequence[int]] = None) -> Buffer:
        """Allocate ``nbytes`` of device memory.  Memory is **zero-filled by default**: device global memory powers up
        with implementation-defined contents (the reference simulator poisons it with 0xDEADBEEF) and a kernel that
        reads uninitialised memory is not portable.  ``init`` (words or bytes) overrides ``zero``."""
        self._sync_for_transfer("implicit-alloc")
        block = self.allocator.alloc(nbytes, align, "buffer", name or f"buf{len(self.allocator.blocks)}")
        buf = Buffer(self, block)
        self._init_guards(block)
        if init is not None:
            data = to_words(init)
            if len(data) > block.rsize:
                self.allocator.free(block.addr)
                raise ArgumentError(f"init data is {len(data)} bytes but the buffer is {nbytes}")
            buf.write(data)
            if len(data) < block.rsize:
                self._raw_write(block.addr + len(data), bytes(block.rsize - len(data)), "fill")
        elif zero:
            self._raw_write(block.addr, bytes(block.rsize), "fill")
        return buf

    def alloc_words(self, words: Sequence[int], name: str = "", align: int = 64) -> Buffer:
        w = list(words)
        return self.alloc(4 * len(w), align, name, init=w)

    def free(self, buf: Union[Buffer, int]) -> None:
        addr = int(buf)
        blk = self.allocator.blocks.get(addr)
        if blk is not None and self.guard:
            damage = self._guard_damage(blk)
            if damage:
                self.allocator.free(addr)
                raise BufferCorrupted(self._damage_text(blk, damage))
        self.allocator.free(addr)

    def memory_info(self) -> Dict[str, int]:
        return self.allocator.stats()

    def buffers(self) -> List[Buffer]:
        return [Buffer(self, b) for b in self.allocator.live() if b.kind == "buffer"]

    def write(self, dst: Union[Buffer, DevicePtr, int], data: Union[bytes, Sequence[int]]) -> None:
        """Copy host data to device memory at a buffer, pointer or raw address (must lie inside one live buffer)."""
        raw = to_words(data)
        block, addr = self._resolve_ptr("destination", dst)
        if block is None or addr + len(raw) > block.payload_end:
            raise ApiError(f"write of {len(raw)} bytes at {addr:#x} does not fit inside one live allocation", "E_BOUNDS")
        self._xfer_write(addr, raw, "h2d", block.name)

    def read(self, src: Union[Buffer, DevicePtr, int], nbytes: int) -> bytes:
        block, addr = self._resolve_ptr("source", src)
        if block is None or addr + nbytes > block.payload_end:
            raise ApiError(f"read of {nbytes} bytes at {addr:#x} does not fit inside one live allocation", "E_BOUNDS")
        return self._xfer_read(addr, nbytes, block.name)

    # buffer-relative primitives (bounds checked against the buffer)
    def _write(self, buf: Buffer, offset: int, data: bytes) -> None:
        self._live(buf)
        if offset < 0 or offset % 4 or offset + len(data) > buf._block.rsize:
            raise ApiError(f"write of {len(data)} bytes at offset {offset} overruns buffer {buf.name!r} ({buf.nbytes} bytes) or is misaligned", "E_BOUNDS")
        self._xfer_write(buf.addr + offset, data, "h2d", buf.name)

    def _read(self, buf: Buffer, offset: int, n: int) -> bytes:
        self._live(buf)
        if offset < 0 or n < 0 or offset + n > buf._block.rsize:
            raise ApiError(f"read of {n} bytes at offset {offset} overruns buffer {buf.name!r} ({buf.nbytes} bytes)", "E_BOUNDS")
        return self._xfer_read(buf.addr + offset, n, buf.name)

    def _live(self, buf: Buffer) -> None:
        if buf.device is not self:
            raise ApiError(f"buffer {buf.name!r} belongs to a different device", "E_WRONG_DEVICE")
        if buf.freed:
            raise ApiError(f"buffer {buf.name!r} was freed", "E_USE_AFTER_FREE")

    def _sync_for_transfer(self, reason: str) -> None:
        if self.inflight is None and not self.queue and not (self.reg("STATUS") & 2):
            return
        if not self.auto_sync:
            raise DeviceBusy("the device is running a launch and the global-memory aperture is closed while BUSY; call synchronize() first")
        t0 = time.perf_counter()
        self.synchronize(raise_errors=False)
        self.profiler.add_sync(reason, time.perf_counter() - t0)

    def _xfer_write(self, addr: int, data: bytes, kind: str, label: str) -> None:
        self._sync_for_transfer("implicit-transfer")
        self._raw_write(addr, data, kind, label)

    def _xfer_read(self, addr: int, n: int, label: str) -> bytes:
        self._sync_for_transfer("implicit-transfer")
        t0 = time.perf_counter()
        try:
            data = self.t.mem_read(addr, n) if n else b""
        except ApertureError as e:
            raise DeviceBusy(str(e)) from e
        self.profiler.add_transfer("d2h", n, addr, time.perf_counter() - t0, label)
        return data

    def _raw_write(self, addr: int, data: bytes, kind: str, label: str = "") -> None:
        t0 = time.perf_counter()
        try:
            if data:
                self.t.mem_write(addr, data)
        except ApertureError as e:
            raise DeviceBusy(str(e)) from e
        self.profiler.add_transfer(kind, len(data), addr, time.perf_counter() - t0, label)

    # ------------------------------------------------------------------ pointers
    def _resolve_ptr(self, name: str, v: Any) -> Tuple[Optional[Block], int]:
        if isinstance(v, Buffer):
            self._live(v)
            return v._block, v.addr
        if isinstance(v, DevicePtr):
            self._live(v.buffer)
            return v.buffer._block, v.addr
        if isinstance(v, bool) or not isinstance(v, int):
            raise ArgumentError(f"argument {name!r} expects a Buffer, pointer or device address, got {type(v).__name__}", "E_ARG_KIND")
        if v % 4:
            raise ArgumentError(f"argument {name!r}: address {v:#x} is not 4-byte aligned", "E_ARG_ALIGN")
        blk = self.allocator.find(v)
        if blk is None:
            if v == 0:
                return None, 0
            raise ArgumentError(f"argument {name!r}: address {v:#x} is not inside any live allocation", "E_ARG_POINTER")
        return blk, v

    # ------------------------------------------------------------------ guards
    def _init_guards(self, b: Block) -> None:
        if not b.guard:
            return
        lo = b"".join(struct.pack("<I", canary_word(a)) for a in range(b.start, b.addr, 4))
        hi = b"".join(struct.pack("<I", canary_word(a)) for a in range(b.payload_end, b.end, 4))
        self._raw_write(b.start, lo, "fill", "guard")
        self._raw_write(b.payload_end, hi, "fill", "guard")

    def _guard_damage(self, b: Block) -> List[Tuple[int, int, int]]:
        if not b.guard or b.freed:
            return []
        bad = []
        for lo in (b.start, b.payload_end):
            raw = self.t.mem_read(lo, b.guard)
            for k in range(0, b.guard, 4):
                a = lo + k
                got = struct.unpack_from("<I", raw, k)[0]
                if got != canary_word(a):
                    bad.append((a, canary_word(a), got))
        return bad

    def _damage_text(self, b: Block, damage: List[Tuple[int, int, int]]) -> str:
        where = []
        for a, _e, _g in damage[:4]:
            side = "before the start" if a < b.addr else f"{a - b.payload_end} bytes past the end"
            where.append(f"{a:#x} ({side})")
        return (f"guard canary of buffer {b.name!r} ({b.size} bytes @ {b.addr:#x}) was overwritten at {', '.join(where)}"
                f"{' ...' if len(damage) > 4 else ''}: a kernel stored outside its buffer")

    def check_guards(self) -> List[str]:
        """Verify every live buffer's guards; returns descriptions of damaged ones (and repairs them)."""
        out = []
        for b in self.allocator.live():
            d = self._guard_damage(b)
            if d:
                out.append(self._damage_text(b, d))
                self._init_guards(b)
        return out

    def describe_address(self, addr: int) -> str:
        blk = self.allocator.find(addr)
        if blk is not None:
            return f"inside buffer {blk.name!r} (+{addr - blk.addr} of {blk.size} bytes)"
        for b in self.allocator.live():
            if b.start <= addr < b.addr:
                return f"{b.addr - addr} bytes before buffer {b.name!r} (in its guard region)"
            if b.payload_end <= addr < b.end:
                return f"{addr - b.payload_end} bytes past the end of buffer {b.name!r} (in its guard region)"
        if addr >= self.config.gmem_bytes:
            return f"beyond the end of global memory ({self.config.gmem_bytes:#x} bytes)"
        if addr < self.allocator.base:
            return "in the reserved low region (null-pointer area)"
        return "in unallocated device memory"

    # ------------------------------------------------------------------ kernels
    def load_kernel(self, source: Union[KernelImage, Program, str, bytes, "os.PathLike[str]"], *, name: Optional[str] = None,
                    **compile_opts: Any) -> Kernel:
        """Place a kernel in device memory.

        ``source`` may be a :class:`KernelImage`, an assembled :class:`Program`, or a path: ``.sfk`` (container),
        ``.sfbin`` (raw words, no metadata), ``.sfa`` (assembled on the fly) or ``.sfir`` (compiled on the fly)."""
        image = to_image(source, name, **compile_opts)
        self._sync_for_transfer("implicit-alloc")
        k = Kernel(self, image)
        self.kernels.append(k)
        return k

    # ------------------------------------------------------------------ dispatch machinery
    def _enqueue(self, kernel: Kernel, bound: BoundLaunch, watchdog: Optional[int]) -> Launch:
        if self._closed:
            raise ApiError("device is closed", "E_CLOSED")
        if kernel._block is None:
            raise ApiError(f"kernel {kernel.name!r} was unloaded", "E_USE_AFTER_FREE")
        if watchdog is not None and (isinstance(watchdog, bool) or not isinstance(watchdog, int) or not 0 <= watchdog <= MASK32):
            raise ArgumentError("watchdog must be an integer tick count in 0..2**32-1 (0 disables it)", "E_ARGUMENT")
        self._lid += 1
        ln = Launch(self, kernel, bound, watchdog, self._lid)
        self.queue.append(ln)
        self._pump(0)
        return ln

    def _start(self, ln: Launch) -> None:
        b, k = ln.bound, ln.kernel
        st = self.status()
        if st["faulted"]:
            raise ApiError("device is in the FAULTED state (an earlier fault was not cleared); call Device.reset()", "E_DEVICE_FAULTED")
        D = SPEC.desc_words
        desc = [0] * SPEC.desc_size_words
        desc[D["MAGIC"]] = SPEC.desc_magic
        desc[D["VERSION_FLAGS"]] = (SPEC.desc_version << 16) | (b.flags & 0xFFFF)
        desc[D["CODE_ADDR"]], desc[D["CODE_WORDS"]], desc[D["ENTRY_PC"]] = k.addr, k.num_words, k.image.meta.entry
        desc[D["GRID_DIM"]], desc[D["WG_DIM"]], desc[D["SHARED_BYTES"]] = b.grid, b.wg, b.shared
        for i, w in enumerate(b.words):
            desc[D["ARG0"] + i] = w
        self._raw_write(self._desc.addr, struct.pack(f"<{len(desc)}I", *desc), "h2d", "descriptor")
        if ln.watchdog is not None:
            self.t.reg_write(R["WDOG_LIMIT"], ln.watchdog)
        self.t.clear_trace()
        if self.wait_mode == "irq":
            self.t.reg_write(R["INT_ENABLE"], 0xF)
        self.t.reg_write(R["INT_STATUS"], 0xF)
        self.t.reg_write(R["LAUNCH_ADDR"], self._desc.addr)
        ln._t0 = time.perf_counter()
        self.t.reg_write(R["DOORBELL"], 1)
        ln.state = "running"
        self.inflight = ln

    def _pump(self, ticks: int) -> None:
        """Start the next queued launch if idle; advance the running launch by up to ``ticks``; finish it if it ended."""
        for _ in range(len(self.queue) + 2):
            if self.inflight is None:
                if not self.queue:
                    return
                ln = self.queue.popleft()
                try:
                    self._start(ln)
                except SfError as e:
                    ln.state, ln.error = "rejected", e
                    self._cancel_pending(f"launch #{ln.id} could not be started")
                    return
            cur = self.inflight
            if cur is None:
                return
            if self.t.reg_read(R["STATUS"]) & 2 and ticks > 0:
                self.t.advance(ticks)
                ticks = 0                                   # one advance per pump; a launch that ends is finished below
            if not (self.t.reg_read(R["STATUS"]) & 2):
                self._finish(cur)
                ticks = 0
                continue
            return

    def _run_until(self, pred: Callable[[], bool], timeout_ticks: Optional[int], who: Optional[Launch] = None) -> None:
        budget = self.DEFAULT_TIMEOUT_TICKS if timeout_ticks is None else timeout_ticks
        spent = 0
        self._pump(0)
        while not pred():
            if spent >= budget:
                self._timeout(who)
                return
            chunk = min(self.CHUNK_TICKS, budget - spent)
            ran = self._advance_running(chunk)
            spent += max(ran, 1)
            self._pump(0)

    def _advance_running(self, chunk: int) -> int:
        if self.inflight is None:
            return 1
        if self.wait_mode == "irq":
            ran = 0
            step = min(chunk, 64)
            while ran < chunk and not self.t.irq():
                r = self.t.advance(step)
                ran += max(r, 1)
                if r == 0:
                    break
            return ran
        return self.t.advance(chunk)

    def _timeout(self, who: Optional[Launch]) -> None:
        ln = self.inflight
        msg = f"launch did not finish within the tick budget; the device was reset (kernel {ln.kernel.name!r})" if ln else "timed out"
        if ln is not None:
            ln.state, ln.error = "timeout", DeviceTimeout(msg)
            self._record(ln, "timeout", {})
            self.inflight = None
        self._cancel_pending("an earlier launch timed out")
        self._soft_reset()
        if self.guard:
            damaged = self.check_guards()       # global memory survives the reset: do not blame the next launch
            if damaged:
                msg += "; also: " + "; ".join(damaged)
                if ln is not None:
                    ln.error = DeviceTimeout(msg)
        if who is not None and who.error is None:
            who.state, who.error = "timeout", DeviceTimeout(msg)

    def _cancel_pending(self, why: str) -> None:
        while self.queue:
            ln = self.queue.popleft()
            ln.state, ln.error = "cancelled", ApiError(f"launch #{ln.id} ({ln.kernel.name}) was cancelled because {why}", "E_CANCELLED")
        if self.inflight is not None:
            ln, self.inflight = self.inflight, None
            ln.state, ln.error = "cancelled", ApiError(f"launch #{ln.id} ({ln.kernel.name}) was cancelled because {why}", "E_CANCELLED")

    def synchronize(self, timeout_ticks: Optional[int] = None, raise_errors: bool = True) -> None:
        """Wait until every submitted launch has finished.  Raises the first launch error (the others are cancelled)."""
        t0 = time.perf_counter()
        pending = list(self.queue) + ([self.inflight] if self.inflight else [])
        self._run_until(lambda: self.inflight is None and not self.queue, timeout_ticks)
        self.profiler.add_sync("explicit", time.perf_counter() - t0, len(pending))
        if raise_errors:
            for ln in pending:
                if ln.error is not None:
                    raise ln.error

    # ------------------------------------------------------------------ completion
    def _finish(self, ln: Launch) -> None:
        self.inflight = None
        host_s = time.perf_counter() - ln._t0
        ticks, issued, lane_ops = self.reg("PERF_CYCLES"), self.reg("PERF_ISSUED"), self.reg("PERF_LANE_OPS")
        wgs = self.reg("WG_COMPLETED")
        st = self.reg("STATUS")
        le = self.reg("LAUNCH_ERR")
        ext = dict(self.t.counters())
        info = dict(ticks=ticks, issued=issued, lane_ops=lane_ops, wgs=wgs, host_s=host_s, ext=ext)
        if self.wait_mode == "irq":
            self.t.reg_write(R["INT_ENABLE"], 0)
        hostint = self.reg("INT_STATUS") & 8
        self.t.reg_write(R["INT_STATUS"], 0xF)
        # LAUNCH_ERR is cleared by every accepted submission, so non-zero means *this* submission was rejected (docs/11 11.2).
        if le:
            name = SPEC.error_names.get(le, f"LE_{le}")
            ln.state, ln.error = "rejected", LaunchRejected(name, le, LE_DETAIL.get(name, ""))
            self._record(ln, "rejected", info, name)
            self._cancel_pending(f"launch #{ln.id} was rejected ({name})")
            return
        if st & 8:
            rep = self._decode_fault(ln)
            if self.guard:                      # the aperture is open in FAULTED: attribute any overrun to *this* launch
                rep.notes += [f"memory is unspecified after a fault; {d}" for d in self.check_guards()]
            self.last_fault = rep
            ln.state, ln.error = "fault", DeviceFault(rep)
            self._record(ln, "fault", info, rep.name)
            self._cancel_pending(f"launch #{ln.id} faulted ({rep.name}); the device was reset")
            self._soft_reset()                   # FAULTED is only left by a soft reset; global memory survives it
            return
        warns = list(ln.bound.warnings)
        if hostint:
            warns.append("the device flagged INT_STATUS.HOST_ERR during this launch")
        lines = self.t.commit_trace()
        digest = None
        if lines is not None:
            digest = hashlib.sha256(("\n".join(lines) + "\n").encode()).hexdigest() if lines else hashlib.sha256(b"").hexdigest()
        ln.result = LaunchResult(ln.kernel.name, ln.bound.grid, ln.bound.wg, ln.bound.shared, dict(ln.bound.values), "done", ticks,
                                 issued, lane_ops, self.config.lanes, wgs, host_s, self.backend, self.config.name, warns, digest,
                                 list(lines) if (self.keep_trace and lines is not None) else None, ext, ln.kernel.image)
        ln.state = "done"
        self._record(ln, "done", info)
        if self.guard:
            damaged = self.check_guards()
            if damaged:
                ln.state, ln.error = "fault", BufferCorrupted(f"kernel {ln.kernel.name!r}: " + "; ".join(damaged))
                ln.error.result = ln.result                                   # type: ignore[attr-defined]
                self._cancel_pending("an earlier launch wrote out of bounds")

    def _record(self, ln: Launch, status: str, info: Dict[str, Any], error: str = "") -> None:
        b = ln.bound
        self.profiler.add_launch(LaunchEvent(
            ln.id, ln.kernel.name, self.backend, self.config.name, b.grid, b.wg, b.shared, status, info.get("ticks", 0),
            info.get("issued", 0), info.get("lane_ops", 0), self.config.lanes, self.config.num_eg, info.get("wgs", 0),
            info.get("host_s", 0.0), error, info.get("ext", {})))

    # ------------------------------------------------------------------ fault decoding
    def _decode_fault(self, ln: Launch) -> FaultReport:
        regs = {n: self.reg("FAULT_" + n) for n in ("CODE", "LOC", "PC", "WG", "MASK", "DATA")}
        loc = regs["LOC"]
        where = {"eg": loc & 0xFF, "warp_slot": (loc >> 8) & 0xFF, "lane": (loc >> 16) & 0xFF, "raw": loc}
        name = SPEC.error_names.get(regs["CODE"], f"F_{regs['CODE']}")
        data, cfg = regs["DATA"], self.config
        shared = ln.bound.shared
        m = {
            "F_ILLEGAL_INSN": lambda: f"instruction word {data:#010x} is not a legal SF-G1 instruction",
            "F_PC_RANGE": lambda: f"instruction index {data} is outside the code image ({ln.kernel.num_words} words): a branch target, "
                                  "reconvergence address or fall-through left the kernel (every path must end in exit)",
            "F_RECONV": lambda: f"a path ran past its reconvergence address {data}: a bz/bnz reconv operand is wrong or the code between "
                                "branch and reconvergence point is not laid out in increasing order",
            "F_GMEM_ALIGN": lambda: f"global access at byte address {data:#x} is not 4-byte aligned ({self.describe_address(data & ~3)})",
            "F_GMEM_RANGE": lambda: f"global access at byte address {data:#x} is outside global memory (0..{cfg.gmem_bytes:#x})",
            "F_SMEM_ALIGN": lambda: f"shared access at workgroup-relative address {data:#x} is not 4-byte aligned",
            "F_SMEM_RANGE": lambda: f"shared access at workgroup-relative address {data:#x} is outside this launch's SHARED_BYTES={shared} "
                                    f"(spill area and user region included)",
            "F_STACK_OVERFLOW": lambda: f"divergence needs more than the {cfg.simt_stack_depth} reconvergence-stack entries "
                                        f"(depth was {data}); overflow is impossible only when depth >= 2*lanes-1 = {2 * cfg.lanes - 1}",
            "F_BAR_DIVERGENT": lambda: f"bar executed while live lanes {data:#x} were not all active: reconverge before a barrier",
            "F_TRAP": lambda: f"trap executed with code {data}",
            "F_WATCHDOG": lambda: f"{data} ticks elapsed without the launch completing (limit {self.reg('WDOG_LIMIT')}); "
                                  "infinite loop, a warp waiting at a barrier that never completes, or a limit that is too low",
        }
        meaning = m.get(name, lambda: f"FAULT_DATA = {data:#x}")()
        if name in ("F_GMEM_ALIGN", "F_GMEM_RANGE"):
            meaning += f" -- {self.describe_address(data & ~3)}" if name == "F_GMEM_RANGE" else ""
        insn_text = src_line = None
        if name != "F_WATCHDOG" and 0 <= regs["PC"] < ln.kernel.num_words:
            insn_text = format_instr(ln.kernel.image.words[regs["PC"]], regs["PC"])
            src_line = ln.kernel.image.lines.get(regs["PC"])
        if name == "F_WATCHDOG":
            where = {"eg": 0xFF, "warp_slot": 0xFF, "lane": 0xFF, "raw": loc}
        return FaultReport(name, regs["CODE"], regs, where, meaning, insn_text, src_line, ln.kernel.name)

    # ------------------------------------------------------------------ misc
    def launch(self, kernel: Kernel, grid: int, wg: int, args: Sequence[Any] = (), **kw: Any) -> LaunchResult:
        return kernel.launch(grid, wg, args, **kw)

    def stats(self) -> Dict[str, Any]:
        return self.profiler.summary()


def to_image(source: Any, name: Optional[str] = None, **compile_opts: Any) -> KernelImage:
    """Normalise anything kernel-like to a :class:`KernelImage`."""
    if isinstance(source, KernelImage):
        img = source
    elif isinstance(source, Program):
        img = source.image()
    elif isinstance(source, (bytes, bytearray)):
        img = KernelImage.from_bytes(bytes(source)) if bytes(source[:4]) == b"SFK1" else KernelImage.from_sfbin(bytes(source), name or "kernel")
    elif isinstance(source, (str, os.PathLike)):
        path = os.fspath(source)
        if not os.path.exists(path):
            raise ArgumentError(f"kernel file not found: {path}", "E_KERNEL_FILE")
        ext = os.path.splitext(path)[1].lower()
        if ext == ".sfa":
            from .asm import assemble_file
            img = assemble_file(path).image()
        elif ext == ".sfir":
            from .compiler import compile_ir
            with open(path, "r", encoding="utf-8") as f:
                img = compile_ir(f.read(), path, **compile_opts).image()
        else:
            img = KernelImage.load(path)
    else:
        raise ArgumentError(f"cannot load a kernel from {type(source).__name__}", "E_KERNEL_SOURCE")
    if name:
        img.meta.name = name
    return img
