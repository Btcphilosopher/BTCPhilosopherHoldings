"""Transports: how the SDK reaches a device.

A *transport* is the host-visible face of one SF-G1 implementation, exactly the interface
of the SF-G1 specification (docs/11 11.1): BAR0 register access, the BAR1 global-memory
aperture, and -- for simulated devices only -- a way to let simulated time pass.

Implementations in this package:

* :class:`ReferenceTransport`   the vendored functional reference simulator (the oracle)
* :class:`sfsdk.hwmodel.HwModelTransport`   the cycle-level microarchitectural hardware model
* :class:`LineTransport`        any process that speaks the line protocol of docs/11 11.4
  (this is how an RTL co-simulation or a board bridge would attach)

Contract for every transport (``Transport`` below):

``reg_read(off) / reg_write(off, val)``   32-bit BAR0 access; never raises for bad offsets (the
                                          device sets ``INT_STATUS.HOST_ERR``), exactly as in hardware.
``mem_read(addr, n) / mem_write(addr, data)``   aperture access; raise :class:`ApertureError` when the
                                          device rejects the access (busy, resetting, out of range).
``advance(max_ticks)``                    run up to ``max_ticks`` device ticks (cycles), stopping early once
                                          the device is idle; returns the ticks actually run.
``irq()``                                 level of the interrupt output.
``commit_trace()``                        canonical commit-trace lines (``sfg1.trace.canon`` format) if the
                                          transport was opened with ``trace=True``, else ``None``.
``counters()``                            implementation-specific counters of the most recent launch (may be empty).
``clear_trace()``                         drop recorded trace events (the SDK calls it before every launch).
"""
from __future__ import annotations

import os
import subprocess
import sys
from typing import Dict, List, Optional, Sequence

from .errors import SfError
from .spec import SF_G1_DIR, Config, MASK32


class ApertureError(SfError):
    """The device rejected a BAR1 (global-memory aperture) access."""
    code = "E_APERTURE"


class TransportError(SfError):
    code = "E_TRANSPORT"


class Transport:
    """Abstract base; see the module docstring for the contract."""

    name: str = "abstract"
    description: str = ""
    config: Config

    def reg_read(self, off: int) -> int:
        raise NotImplementedError

    def reg_write(self, off: int, val: int) -> None:
        raise NotImplementedError

    def mem_read(self, addr: int, n: int) -> bytes:
        raise NotImplementedError

    def mem_write(self, addr: int, data: bytes) -> None:
        raise NotImplementedError

    def advance(self, max_ticks: int) -> int:
        raise NotImplementedError

    def irq(self) -> bool:
        raise NotImplementedError

    def close(self) -> None:
        pass

    def commit_trace(self) -> Optional[List[str]]:
        return None

    def counters(self) -> Dict[str, int]:
        """Implementation-specific counters describing the most recent launch (may be empty)."""
        return {}

    def clear_trace(self) -> None:
        """Forget recorded commit-trace events so the next ``commit_trace()`` covers one launch only."""


# --------------------------------------------------------------------------- reference simulator
class ReferenceTransport(Transport):
    """The vendored functional reference simulator (``sf-g1/sim/sfg1``), run in-process."""

    name = "reference"
    description = "SF-G1 functional reference simulator (architectural oracle; zero-latency memory)"

    def __init__(self, config: Config, trace: bool = False, poison: bool = True, record_stack: bool = False) -> None:
        from . import _ref
        self.config = config
        rcfg = _ref.ref_spec.Config.from_dict(config.parameters(), name=config.name)
        if rcfg.cfg_hash() != config.cfg_hash():                       # pragma: no cover - guards spec drift
            raise TransportError("SDK and reference simulator disagree on CFG_HASH; the vendored tree was modified")
        self.dev = _ref.ref_device.Device(rcfg, trace=trace, poison=poison, record_stack=record_stack)

    def reg_read(self, off: int) -> int:
        return self.dev.reg_read(off)

    def reg_write(self, off: int, val: int) -> None:
        self.dev.reg_write(off, val & MASK32)

    def mem_read(self, addr: int, n: int) -> bytes:
        b = self.dev.mem_read(addr, n)
        if b is None:
            raise ApertureError(f"aperture read rejected at {addr:#x}+{n}")
        return b

    def mem_write(self, addr: int, data: bytes) -> None:
        if not self.dev.mem_write(addr, bytes(data)):
            raise ApertureError(f"aperture write rejected at {addr:#x}+{len(data)}")

    def advance(self, max_ticks: int) -> int:
        return self.dev.run(max_ticks)

    def irq(self) -> bool:
        return self.dev.irq

    def commit_trace(self) -> Optional[List[str]]:
        return self.dev.trace.canonical_lines() if self.dev.trace is not None else None

    @property
    def stack_logs(self):
        """SIMT-stack command streams per (workgroup, warp), if opened with ``record_stack=True`` (used by the RTL replay)."""
        return self.dev.stack_logs

    def counters(self) -> Dict[str, int]:
        return {"ticks_total": self.dev.ticks_total}

    def clear_trace(self) -> None:
        if self.dev.trace is not None:
            self.dev.trace.events.clear()


# --------------------------------------------------------------------------- line protocol
class LineTransport(Transport):
    """Speaks the SF-G1 line protocol (docs/11 11.4) to a subprocess.

    ``command`` is the process to start (stdin/stdout, one request and one reply per line).  The
    vendored reference device server is available as ``LineTransport.reference_server(config)``.
    An RTL co-simulation or a hardware bridge attaches by implementing the same eight commands.
    """

    name = "line"
    description = "device behind the SF-G1 line protocol (docs/11 11.4)"

    def __init__(self, command: Sequence[str], config: Config, env: Optional[Dict[str, str]] = None) -> None:
        self.config = config
        self.p = subprocess.Popen(list(command), stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True,
                                  bufsize=1, env=env)

    @classmethod
    def reference_server(cls, config: Config, extra: Sequence[str] = ()) -> "LineTransport":
        script = str(SF_G1_DIR / "sim" / "sfg1_devserver.py")
        cfg_arg = config.name if config.name in ("default", "small", "wide") else config.name
        return cls([sys.executable, script, "--config", cfg_arg, *extra], config)

    def _cmd(self, line: str) -> List[str]:
        if self.p.poll() is not None:
            raise TransportError("device server exited")
        assert self.p.stdin and self.p.stdout
        self.p.stdin.write(line + "\n")
        self.p.stdin.flush()
        reply = self.p.stdout.readline().split()
        if not reply:
            raise TransportError("device server closed the pipe")
        if reply[0] != "OK":
            if reply[:2] == ["ERR", "bus"]:
                raise ApertureError(f"aperture access rejected ({line[:40]})")
            raise TransportError(f"device server: {' '.join(reply)} (for '{line[:40]}')")
        return reply[1:]

    def reg_read(self, off: int) -> int:
        return int(self._cmd(f"RR {off:x}")[0], 16)

    def reg_write(self, off: int, val: int) -> None:
        self._cmd(f"RW {off:x} {val & MASK32:x}")

    def mem_read(self, addr: int, n: int) -> bytes:
        out = bytearray()
        while n:
            k = min(n, 4096)
            out += bytes.fromhex(self._cmd(f"MR {addr:x} {k}")[0])
            addr, n = addr + k, n - k
        return bytes(out)

    def mem_write(self, addr: int, data: bytes) -> None:
        for i in range(0, len(data), 4096):
            self._cmd(f"MW {addr + i:x} {bytes(data[i:i + 4096]).hex()}")

    def advance(self, max_ticks: int) -> int:
        return int(self._cmd(f"ST {max_ticks}")[0])

    def irq(self) -> bool:
        return self._cmd("IRQ")[0] == "1"

    def close(self) -> None:
        try:
            self._cmd("QUIT")
        except Exception:
            pass
        for f in (self.p.stdin, self.p.stdout):
            if f:
                f.close()
        try:
            self.p.wait(timeout=10)
        except Exception:                                            # pragma: no cover
            self.p.kill()
