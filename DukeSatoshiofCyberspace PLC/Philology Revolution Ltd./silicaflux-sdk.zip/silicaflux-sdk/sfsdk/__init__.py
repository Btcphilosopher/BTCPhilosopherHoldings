"""SilicaFlux SDK for SF-G1: a userspace programming system for the SilicaFlux SF-G1 SIMT architecture.

SF-G1 is an original architecture.  This SDK is **not** compatible with, and makes no claim about, CUDA, OpenCL,
Vulkan, HIP, SYCL, Metal or any other existing GPU language, API or ISA; nothing here implements or has been
checked against them.  Everything is defined by the SF-G1 specification vendored in ``sf-g1/``.

Quick start::

    import sfsdk
    dev = sfsdk.open_device("reference:default")          # or "hwmodel:default"
    a = dev.alloc_words(range(100)); b = dev.alloc_words([7] * 100); c = dev.alloc(400)
    k = dev.load_kernel("kernels/vecadd.sfir")             # compiled on the fly (or .sfa / .sfk / .sfbin)
    result = k.launch(grid=4, wg=32, args=[a, b, c, 100])
    print(c.read_words(), result.ticks, result.simt_efficiency)
    print(dev.profiler.report())
"""
from __future__ import annotations

__version__ = "0.1.0"

from .asm import Program, assemble, assemble_file
from .binfmt import ArgSpec, KernelImage, KernelMeta
from .disasm import disassemble, format_instr
from .discovery import Backend, enumerate_devices, open_device, register_backend, register_line_device
from .errors import (ApiError, ArgumentError, AsmError, BufferCorrupted, CompileError, DeviceBusy, DeviceFault, DeviceMismatch,
                     DeviceTimeout, FaultReport, LaunchRejected, OutOfDeviceMemory, SfError)
from .profile import InstructionProfile, Profiler
from .runtime import Buffer, Device, DeviceInfo, DevicePtr, Kernel, Launch, LaunchResult
from .spec import Config


def compile(source: str, filename: str = "<ir>", **options):          # noqa: A001 - public name, mirrors "assemble"
    """Compile restricted-IR text (``.sfir``) to a :class:`CompileResult` (``.image()`` gives a loadable kernel)."""
    from .compiler import compile_ir
    return compile_ir(source, filename, **options)


__all__ = [n for n in dir() if not n.startswith("_")]
