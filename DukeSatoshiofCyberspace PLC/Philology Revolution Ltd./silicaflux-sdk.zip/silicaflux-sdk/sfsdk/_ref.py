"""Access to the vendored, unmodified reference simulator (``sf-g1/sim/sfg1``).

The reference model is the *oracle*: the SDK drives it as one backend and compares other
backends against it, but SDK code paths for assembling, decoding and hardware modelling do not
depend on it.  Importing this module puts the vendored package on ``sys.path``.
"""
from __future__ import annotations

import sys

from .spec import SF_G1_DIR

_SIM = str(SF_G1_DIR / "sim")
if _SIM not in sys.path:
    sys.path.insert(0, _SIM)

import sfg1  # noqa: E402,F401
from sfg1 import device as ref_device  # noqa: E402,F401
from sfg1 import spec as ref_spec  # noqa: E402,F401
from sfg1 import trace as ref_trace  # noqa: E402,F401
