"""Device global-memory management: the allocator behind ``Device.alloc``.

SF-G1 has no memory protection and no virtual memory: kernels address physical global memory
directly and a stray store silently corrupts whatever lives there.  The SDK therefore keeps its
own authoritative map of live allocations, which it uses

* to hand out non-overlapping, 64-byte-aligned buffers (first-fit with coalescing on free);
* to resolve any pointer argument to the buffer that contains it (argument validation checks
  extents against it);
* optionally to surround every buffer with *guard canaries* that are verified after each launch,
  so an out-of-bounds kernel store is reported against the buffer it overran.

Address range ``[0, ALLOC_BASE)`` is never allocated (a null-pointer convention of the SDK, not an
architectural rule: the architecture treats address 0 as valid).
"""
from __future__ import annotations

from bisect import bisect_right, insort
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from .errors import ApiError, OutOfDeviceMemory

ALLOC_BASE = 0x100
GUARD_BYTES = 64
MASK32 = 0xFFFFFFFF


def canary_word(addr: int) -> int:
    """Guard pattern for the word at byte address ``addr`` (position-dependent)."""
    return (0xC0DEC0DE ^ ((addr >> 2) * 0x9E3779B1)) & MASK32


@dataclass
class Block:
    addr: int            # payload address (what the kernel sees)
    size: int            # bytes requested
    rsize: int           # bytes reserved for the payload (multiple of 4)
    start: int           # first reserved byte (includes the leading guard)
    end: int             # one past the last reserved byte (includes the trailing guard)
    guard: int
    kind: str = "buffer"          # buffer | code | descriptor
    name: str = ""
    freed: bool = False

    @property
    def payload_end(self) -> int:
        return self.addr + self.rsize


class Allocator:
    def __init__(self, total_bytes: int, guard: bool = True, base: int = ALLOC_BASE) -> None:
        self.total = total_bytes
        self.base = base
        self.guard = GUARD_BYTES if guard else 0
        self.free_spans: List[Tuple[int, int]] = [(base, total_bytes - base)]     # (start, length), sorted
        self.blocks: Dict[int, Block] = {}                                        # by payload address
        self._starts: List[int] = []                                              # sorted payload addresses

    # ------------------------------------------------------------------ allocate / free
    def alloc(self, nbytes: int, align: int = 64, kind: str = "buffer", name: str = "") -> Block:
        if nbytes < 0:
            raise ApiError("allocation size must be non-negative", "E_ARGUMENT")
        if align < 4 or align & (align - 1):
            raise ApiError(f"alignment must be a power of two >= 4, got {align}", "E_ARGUMENT")
        rsize = max((nbytes + 3) & ~3, 4)
        g = self.guard
        for i, (s, ln) in enumerate(self.free_spans):
            payload = (s + g + align - 1) & ~(align - 1)
            end = payload + rsize + g
            if end <= s + ln:
                start = payload - g
                spans = []
                if start > s:
                    spans.append((s, start - s))
                if end < s + ln:
                    spans.append((end, s + ln - end))
                self.free_spans[i:i + 1] = spans
                b = Block(payload, nbytes, rsize, start, end, g, kind, name)
                self.blocks[payload] = b
                insort(self._starts, payload)
                return b
        raise OutOfDeviceMemory(
            f"cannot allocate {nbytes} bytes (align {align}): largest free span is {self.largest_free()} bytes "
            f"of {self.free_bytes()} free; {len(self.blocks)} live allocation(s)")

    def free(self, addr: int) -> Block:
        b = self.blocks.get(addr)
        if b is None:
            raise ApiError(f"free of {addr:#x}: not the start of a live allocation (double free?)", "E_BAD_FREE")
        del self.blocks[addr]
        self._starts.remove(addr)
        b.freed = True
        self._release(b.start, b.end - b.start)
        return b

    def _release(self, start: int, length: int) -> None:
        spans = self.free_spans
        spans.append((start, length))
        spans.sort()
        merged: List[Tuple[int, int]] = []
        for s, ln in spans:
            if merged and merged[-1][0] + merged[-1][1] == s:
                merged[-1] = (merged[-1][0], merged[-1][1] + ln)
            else:
                merged.append((s, ln))
        self.free_spans = merged

    # ------------------------------------------------------------------ queries
    def find(self, addr: int) -> Optional[Block]:
        """The live block whose *payload* contains ``addr`` (``None`` for guards, gaps or free memory)."""
        i = bisect_right(self._starts, addr) - 1
        if i < 0:
            return None
        b = self.blocks[self._starts[i]]
        return b if b.addr <= addr < b.payload_end else None

    def live(self) -> List[Block]:
        return [self.blocks[a] for a in self._starts]

    def free_bytes(self) -> int:
        return sum(ln for _, ln in self.free_spans)

    def largest_free(self) -> int:
        return max((ln for _, ln in self.free_spans), default=0)

    def stats(self) -> Dict[str, int]:
        used = sum(b.end - b.start for b in self.blocks.values())
        free = self.free_bytes()
        return {"total": self.total, "reserved_low": self.base, "used": used, "payload": sum(b.rsize for b in self.blocks.values()),
                "free": free, "largest_free": self.largest_free(), "live_blocks": len(self.blocks),
                "free_spans": len(self.free_spans)}
