"""Run the same kernels on several backends and compare what they computed.

A *scenario* drives a :class:`~sfsdk.runtime.Device` through the public SDK API (allocate, upload, load kernel,
launch, read back) and returns an :class:`Outcome`.  :func:`compare_scenario` runs it unchanged on each target
(backend + configuration), then checks, against the first target (the oracle, normally the reference simulator):

``outputs``     every named result array is word-for-word identical;
``expected``    each target also reproduces the *host-computed* golden values (independent of every device model);
``counters``    architectural counters of every launch are equal: warp instructions, lane operations, workgroups
                (the cycle counts are timing and are reported but never compared);
``trace``       the SHA-256 of the per-warp commit trace is equal (docs/09 9.4).  The digest is only comparable for
                race-free kernels whose atomics discard their return value; a kernel that keeps an ``atomadd``
                result is reported as ``n/a`` instead of being compared.

The first mismatch is reported with enough detail to find it (array index and values; first differing trace line).
"""
from __future__ import annotations

import json
import traceback
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from .discovery import open_device
from .runtime import Device, LaunchResult


class ScenarioSkip(Exception):
    """Raised by a scenario that cannot run on a given configuration (e.g. the problem does not fit)."""


@dataclass
class Outcome:
    outputs: Dict[str, List[int]]
    launches: List[LaunchResult]
    expected: Optional[Dict[str, List[int]]] = None
    notes: List[str] = field(default_factory=list)


@dataclass
class Scenario:
    name: str
    run: Callable[[Device], Outcome]
    description: str = ""


@dataclass
class LaunchRecord:
    kernel: str
    grid: int
    wg: int
    ticks: int
    issued: int
    lane_ops: int
    workgroups: int
    digest: Optional[str]
    order_dependent: bool
    trace_lines: Optional[List[str]] = None


@dataclass
class RunRecord:
    target: str
    outputs: Dict[str, List[int]] = field(default_factory=dict)
    expected_ok: Optional[bool] = None
    expected_detail: str = ""
    launches: List[LaunchRecord] = field(default_factory=list)
    error: str = ""
    skipped: str = ""
    notes: List[str] = field(default_factory=list)

    @property
    def ran(self) -> bool:
        return not self.error and not self.skipped


@dataclass
class Comparison:
    scenario: str
    runs: List[RunRecord]
    checks: Dict[str, Optional[bool]] = field(default_factory=dict)       # name -> True/False/None(n/a)
    details: List[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        ran = [r for r in self.runs if r.ran]
        return bool(ran) and all(r.ran or r.skipped for r in self.runs) and all(v in (True, None) for v in self.checks.values()) \
            and all(r.expected_ok in (True, None) for r in ran)

    @property
    def skipped(self) -> bool:
        return all(r.skipped for r in self.runs)

    def as_dict(self) -> Dict[str, Any]:
        return {"scenario": self.scenario, "ok": self.ok, "checks": self.checks, "details": self.details,
                "runs": [{"target": r.target, "expected_ok": r.expected_ok, "error": r.error, "skipped": r.skipped,
                          "launches": [{k: v for k, v in l.__dict__.items() if k != "trace_lines"} for l in r.launches]} for r in self.runs]}


def first_trace_difference(a: Sequence[str], b: Sequence[str]) -> str:
    """Describe the first difference between two canonical commit traces (both sorted by wg, warp, seq)."""
    for i, (x, y) in enumerate(zip(a, b)):
        if x != y:
            ex, ey = json.loads(x), json.loads(y)
            keys = [k for k in ex if ex[k] != ey.get(k)]
            return (f"first trace difference at event {i} (wg {ex['wg']}, warp {ex['warp']}, seq {ex['seq']}, pc {ex['pc']}): "
                    f"fields {keys}: reference {x[:160]} vs {y[:160]}")
    if len(a) != len(b):
        return f"traces agree for {min(len(a), len(b))} events, then one has {len(a)} events and the other {len(b)}"
    return "traces identical"


def _diff_words(a: Sequence[int], b: Sequence[int]) -> str:
    if len(a) != len(b):
        return f"length {len(a)} vs {len(b)}"
    bad = [i for i, (x, y) in enumerate(zip(a, b)) if x != y]
    i = bad[0]
    return f"{len(bad)} of {len(a)} words differ; first at index {i}: {a[i]:#010x} vs {b[i]:#010x}"


def run_target(scn: Scenario, backend: str, config: str, keep_trace: bool = True) -> RunRecord:
    rec = RunRecord(f"{backend}:{config}")
    try:
        with open_device(f"{backend}:{config}", keep_trace=keep_trace) as dev:
            try:
                out = scn.run(dev)
            except ScenarioSkip as e:
                rec.skipped = str(e)
                return rec
            rec.outputs = {k: list(v) for k, v in out.outputs.items()}
            rec.notes = list(out.notes)
            if out.expected is not None:
                bad = [f"{k}: {_diff_words(out.outputs.get(k, []), v)}" for k, v in out.expected.items() if out.outputs.get(k) != v]
                rec.expected_ok = not bad
                rec.expected_detail = "; ".join(bad)
            for r in out.launches:
                rec.launches.append(LaunchRecord(
                    r.kernel, r.grid, r.wg, r.ticks, r.issued, r.lane_ops, r.workgroups, r.trace_digest,
                    bool(r.image and r.image.uses_order_dependent_atomics), r.trace_lines))
    except Exception as e:                                                   # report, do not hide, any failure
        rec.error = f"{type(e).__name__}: {e}"
        rec.notes.append(traceback.format_exc(limit=3))
    return rec


def compare_scenario(scn: Scenario, targets: Sequence[Tuple[str, str]] = (("reference", "default"), ("hwmodel", "default")),
                     keep_trace: bool = True) -> Comparison:
    runs = [run_target(scn, b, c, keep_trace) for b, c in targets]
    cmp = Comparison(scn.name, runs)
    base = runs[0]
    if not base.ran:
        cmp.details.append(f"{base.target}: {'skipped: ' + base.skipped if base.skipped else base.error}")
        cmp.checks["ran"] = bool(base.skipped)
        return cmp
    for r in runs:
        if r.error:
            cmp.details.append(f"{r.target}: ERROR {r.error}")
    cmp.checks["ran"] = all(not r.error for r in runs)
    cmp.checks["expected"] = all(r.expected_ok for r in runs if r.ran and r.expected_ok is not None) if any(r.expected_ok is not None for r in runs if r.ran) else None
    for r in runs:
        if r.ran and r.expected_ok is False:
            cmp.details.append(f"{r.target}: differs from host-computed expectation: {r.expected_detail}")
    out_ok = ctr_ok = True
    dig: Optional[bool] = None
    for r in runs[1:]:
        if not r.ran:
            continue
        if r.outputs.keys() != base.outputs.keys():
            out_ok = False
            cmp.details.append(f"{r.target}: result arrays {sorted(r.outputs)} vs {sorted(base.outputs)}")
        for k in base.outputs:
            if r.outputs.get(k) != base.outputs[k]:
                out_ok = False
                cmp.details.append(f"{r.target} vs {base.target}: output '{k}': {_diff_words(base.outputs[k], r.outputs.get(k, []))}")
        if len(r.launches) != len(base.launches):
            ctr_ok = False
            cmp.details.append(f"{r.target}: {len(r.launches)} launches vs {len(base.launches)}")
            continue
        for i, (a, b) in enumerate(zip(base.launches, r.launches)):
            if (a.issued, a.lane_ops, a.workgroups) != (b.issued, b.lane_ops, b.workgroups):
                ctr_ok = False
                cmp.details.append(f"{r.target} launch {i} ({a.kernel}): warp-insn/lane-ops/workgroups "
                                   f"{(a.issued, a.lane_ops, a.workgroups)} vs {(b.issued, b.lane_ops, b.workgroups)}")
            if a.order_dependent or b.order_dependent or a.digest is None or b.digest is None:
                continue
            dig = True if dig is None else dig
            if a.digest != b.digest:
                dig = False
                msg = f"{r.target} launch {i} ({a.kernel}): commit-trace digest differs"
                if a.trace_lines is not None and b.trace_lines is not None:
                    msg += "; " + first_trace_difference(a.trace_lines, b.trace_lines)
                cmp.details.append(msg)
    cmp.checks["outputs"] = out_ok if len(runs) > 1 else None
    cmp.checks["counters"] = ctr_ok if len(runs) > 1 else None
    cmp.checks["trace"] = dig if len(runs) > 1 else None
    return cmp


def compare_matrix(scenarios: Sequence[Scenario], backends: Sequence[str] = ("reference", "hwmodel"),
                   configs: Sequence[str] = ("default", "small", "wide"), keep_trace: bool = True) -> List[Comparison]:
    """Every scenario on every configuration, each time comparing all ``backends`` (first = oracle)."""
    out = []
    for cfg in configs:
        for scn in scenarios:
            c = compare_scenario(scn, [(b, cfg) for b in backends], keep_trace)
            c.scenario = f"{scn.name} @ {cfg}"
            out.append(c)
    return out


def format_matrix(results: Sequence[Comparison]) -> str:
    def mark(v):
        return "n/a " if v is None else ("ok  " if v else "FAIL")
    L = [f"{'scenario':<44} {'expected':<8} {'outputs':<8} {'counters':<9} {'trace':<6} status"]
    for c in results:
        if c.skipped:
            L.append(f"{c.scenario:<44} {'':<8} {'':<8} {'':<9} {'':<6} skipped ({[r.skipped for r in c.runs][0]})")
            continue
        L.append(f"{c.scenario:<44} {mark(c.checks.get('expected')):<8} {mark(c.checks.get('outputs')):<8} "
                 f"{mark(c.checks.get('counters')):<9} {mark(c.checks.get('trace')):<6} {'PASS' if c.ok else 'FAIL'}")
        for d in c.details:
            L.append(f"    - {d}")
    ran = [c for c in results if not c.skipped]
    L.append(f"{sum(c.ok for c in ran)}/{len(ran)} comparisons passed" + (f", {len(results) - len(ran)} skipped" if len(ran) != len(results) else ""))
    return "\n".join(L)


def timing_table(results: Sequence[Comparison]) -> str:
    """Device ticks per target for every comparison (informational: ticks are not comparable across backends)."""
    L = [f"{'scenario':<44} " + "  ".join(f"{r.target:>18}" for r in results[0].runs) if results else ""]
    for c in results:
        L.append(f"{c.scenario:<44} " + "  ".join(f"{sum(l.ticks for l in r.launches):>18}" if r.ran else f"{'-':>18}" for r in c.runs))
    return "\n".join(L)
