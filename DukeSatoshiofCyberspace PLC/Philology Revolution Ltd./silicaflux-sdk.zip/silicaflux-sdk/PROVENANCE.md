# Provenance of the vendored authoritative sources

`sf-g1/` is an **unmodified** copy of the SilicaFlux SF-G1 tree from the Aureom.AI repository:

| | |
|---|---|
| Source archive | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sf-g1.zip` |
| Archive SHA-256 | `a67aa85c2a2ee169ec14ef0065bce6ef4d98cb33d39c468670d7636ea9926712` |
| Contents used by the SDK | `spec/*.json` (ISA, device interface, configuration: **authoritative**), `sim/sfg1/` (functional reference simulator: the **oracle**), `docs/` (normative specification), `examples/`, `reference/` (golden outputs and commit traces), `rtl/`, `tools/`, `verification/` (verified RTL blocks: decoder, ALU, SIMT stack) |
| Integrity | `sf-g1.MANIFEST.sha256` lists every file; `tests/test_foundation.py` (`ProvenanceTests`) fails if any file differs, is added or is removed |

Nothing in `sf-g1/` was edited, generated into, or patched. All SDK code lives outside it and reads the JSON
specification through `sfsdk/spec.py` and `sfsdk/isa.py`.

## Other SilicaFlux material in the repository that was examined and deliberately NOT used

* `sf-g1-execution-core.zip` — a SystemVerilog integer core + Python simulator. Its own README states that **no SF-G1
  specification was available to its author**: its ISA (32 registers, predicates, `SETP`/`MOVI`, `ALU_R` at opcode `0x08`,
  no memory or branch instructions) is *assumed* and is not the authoritative SF-G1 encoding, so it cannot execute SF-G1
  binaries and is not used as the hardware model.
* `silicaflux-sf-g1-fpx.zip` — a floating-point extension of the same tree. The SDK targets the base integer ISA.
* `silicaflux-simt.zip` — a separate SIMT design with its own `sfx_*` tools; not the SF-G1 definition.

## Status of the authoritative tree itself

The SF-G1 README states that its register file, lane execution, load/store unit, barrier unit, scheduler, launch unit,
register/interrupt block and core top are **planned and not written**; only the decoder, ALU and SIMT stack exist as
RTL (verified in simulation, no synthesis or timing). Consequently there is no complete SF-G1 hardware implementation to
run binaries on; see `docs/HWMODEL.md` for what the SDK's "hardware model" is.
