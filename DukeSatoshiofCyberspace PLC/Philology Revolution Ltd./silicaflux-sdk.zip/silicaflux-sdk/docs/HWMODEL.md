# The SF-G1 hardware model

> **This is a model, not RTL.** It is a cycle-level *microarchitectural model* written in Python from the
> normative SF-G1 specification. It is not synthesisable, it has not been through any hardware flow, and it makes
> **no claim about silicon timing, area or power**. Its purpose is to be a *second, structurally different
> implementation* of the architecture, so that "the same binary gives the same results on the reference simulator
> and on the hardware model" is a meaningful check rather than a tautology.

Code: `sfsdk/hwmodel/` (about 1,250 lines) and `sfsdk/conformance.py` (about 1,400 lines). Tests: `tests/test_hwmodel_*.py`,
`tests/test_conformance.py`.

## 1. Why a new model, and why it is not the vendored RTL

* The authoritative tree (`sf-g1/`) contains a functional **reference simulator** and three *verified RTL blocks*
  (decoder, ALU, SIMT stack). Its register file, lane execution, LSU, barrier unit, scheduler, launch unit,
  register/interrupt block and core top are **"planned, not written"** (`sf-g1/docs/13-pipeline-plan.md`,
  `sf-g1/verification/blocks.json`). There is no RTL that can execute a kernel.
* `sf-g1-execution-core` (another archive in the repository) *does* have a complete RTL core, but its own README says
  the SF-G1 specification "was not available" to it, and it implements an **assumed, different ISA** (32 registers,
  predicate registers, `SETP`/`MOVI`, `ALU_R` at opcode `0x08`, no branches or memory operations). It cannot run
  SF-G1 binaries and is not used here.

So the SDK's "hardware" backend is this model. Where the model and the reference agree, that is evidence that the
*specification* pins the behaviour down, and that two independently written implementations read it the same way.

## 2. Using it

```python
from sfsdk.hwmodel import HwModelTransport, HwParams
from sfsdk.spec import Config

t = HwModelTransport(Config.named("default"), trace=True, params=HwParams(scheduler="gto"))
# t is an sfsdk.transport.Transport: reg_read/reg_write (BAR0), mem_read/mem_write (BAR1), advance(n), irq()
t.commit_trace()   # canonical per-warp commit-trace lines (trace=True), ordered (wg, warp, seq)
t.clear_trace()    # forget recorded events so the next launch's trace stands alone
t.counters()       # microarchitectural counters of the MOST RECENT launch (see 6)
```

Any host driver written against the transport interface (the SDK runtime, the vendored `sfg1.host.Host`) drives it
unchanged. Conformance suite: `python3 -m sfsdk.conformance --backend both`.

## 3. Microarchitecture

```
 host ── BAR0 regs ─▶ ┌──────────── register block / launch unit ───────────┐
 host ── BAR1 aperture │ descriptor fetch+validate (docs/06 6.3 order)        │
                       │ IMEM fill (4 words/cycle) · in-order WG dispatch     │
                       │ (policy: least-loaded EG, ≤2 WG/cycle, +2 cycle init)│
                       └──────────┬───────────────────────────┬───────────────┘
                     per EG (×NUM_EG)                          │
        ┌─────────────────────────┴───────────────┐             │
        │ warp slots: regs[16][lanes], HwSimtStack │             │
        │ scheduler: oldest | lrr | gto, 1 issue/cycle           │
        │                                                        │
        │  issue ─▶ FD ─▶ RD ─▶ EX (1..4 cyc) ─▶ [MEM] ─▶ WB(commit)
        │           fetch+  operand  alu/mul/agu/                 │
        │           decode  read     branch unit                  │
        │  one instruction in flight per warp (docs/13 13.1)      │
        │                                                        │
        │ barrier unit: per-WG arrival; warp arrives only after   │
        │               its memory queue has drained              │
        │ LSU: per-warp in-order queue (posted stores)            │
        │   ├─ shared port (1/EG): 8 banks, cycles = max words per bank
        │   └─────────────────────────────┐                      │
        └──────────────────────────────────┼──────────────────────┘
                                           ▼
              global port(s): oldest-request-first across all EGs,
              one 32-byte-segment transaction per cycle per port,
              latency 24 (+ optional jitter), data applied at COMPLETION
```

### 3.1 Instruction flow (one in flight per warp)

| Stage | Cycle(s) | What happens |
|---|---|---|
| FD  | issue cycle *T* | scheduler picks a warp; fetch from the EG's instruction memory, pre-decoded by `sfsdk.isa.decode`; fetch-time faults (`F_PC_RANGE`, `F_RECONV`, `F_ILLEGAL_INSN`, docs/02 2.6) |
| RD  | *T*+1 | operand read for the active lanes |
| EX  | next 1–4 | ALU 2 cycles, `mul` 4, `rdsr` 2, branch/exit/bar/fence/trap unit 2, address generation 2. Execute-time faults are raised here, so they are precise (nothing has been committed): branch range, stack overflow (a side-effect-free `would_overflow` check), memory alignment/range (all lanes checked before any access), `bar` divergence, `trap` |
| MEM | variable | loads/atomics wait for their request to complete; stores are *posted* (accepted into the warp's queue, warp moves on, stalls only if the queue is full); `fence`, `bar` and a warp-finishing `exit` wait for the queue to drain |
| WB  | 1 | commit: register write, SIMT-stack command, trace record, `PERF_ISSUED`/`PERF_LANE_OPS`. The warp is unschedulable for `1 + pops + pushes` further cycles while the stack resolves |

Measured issue-to-issue time of one warp: `nop` 4 cycles, ALU/`rdsr` 5, `mul` 7 (plus stack-resolution cycles after control instructions, plus memory
latency for loads); latency is hidden only by other warps. This is the "simplest legal design" of docs/13 13.1, not a performance claim.

### 3.2 Memory system

* **Per-warp in-order queues, posted stores.** The data of a store reaches memory when its request *completes* (`latency` cycles after the
  port started it), not when the instruction issues. A warp's requests start in order and complete in order per address space (an explicit clamp),
  so a thread always observes its own earlier stores (C2).
* **Different warps interleave arbitrarily**: the global port serves the oldest queue head first; with `global_ports > 1` and/or
  `global_jitter > 0` a later request can complete before an earlier one from another warp. This is what makes the drains at `bar`, `fence` and `exit`
  load-bearing (section 7: the mutation that removes the `bar` drain is caught only when completion order can invert).
* **Coalescing.** Cycles on the global port = number of distinct 32-byte segments touched by the active lanes (atomics: one per active lane).
  **Banking.** Shared accesses take as many cycles as the busiest of 8 banks has distinct words.
* Within one warp-wide request the lanes are applied in ascending order (docs/04 4.4): highest lane wins on stores, lane *i* of an `atomadd`
  sees the sum of the lower lanes.
* Power-up contents: global memory holds a seeded pseudo-random pattern (the reference uses `0xDEADBEEF`), shared slots get fresh random bytes at dispatch
  (unless `SMEM_ZERO`). A kernel that reads uninitialised memory therefore behaves differently on the two models, loudly.

### 3.3 Scheduler, dispatch, barriers, faults

* **Scheduler**: `oldest` (default: the warp that has been ready longest), `lrr` (the reference's loose round robin), `gto` (greedy then oldest), with a starvation guard.
* **Dispatch**: workgroups in id order (docs/05 5.1 (1)); EG choice `least_loaded` (default; the reference uses lowest-numbered EG), `lowest` or `round_robin`;
  up to 2 workgroups per cycle, 2 cycles of register/stack initialisation.
* **Barrier**: warps of a workgroup that are not done participate; a warp arrives only after draining; exited warps and lanes never block it.
* **Faults**: the first fault of a cycle wins, ties broken by lowest EG then lowest warp slot (docs/08 8.2); posted memory operations in flight are
  *dropped* (the specification calls memory after a fault unspecified; dropping is the stricter choice because it removes any accidental dependence).
* **Launch phase**: descriptor read/validation (3 cycles) + instruction-memory fill (⌈words/4⌉ cycles) instead of the reference's single tick.

## 4. Parameters (`HwParams`)

None is architectural: every setting must give the same results for a race-free kernel (tested, section 7).

| Parameter | Default | Meaning |
|---|---|---|
| `scheduler` | `oldest` | `oldest` / `lrr` / `gto` |
| `reset_cycles` | 7 | `STATUS.READY=0` duration (reference: 4) |
| `alu_latency`, `mul_latency`, `sreg_latency`, `branch_latency`, `agu_latency` | 2, 4, 2, 2, 2 | EX-stage cycles |
| `global_latency`, `shared_latency` | 24, 4 | cycles from port start to completion |
| `global_jitter`, `shared_jitter` | 0, 0 | extra 0..N cycles (seeded) per request: makes completion order across warps vary |
| `shared_banks`, `segment_bytes`, `global_ports` | 8, 32, 1 | banking, coalescing granule, global transactions/cycle |
| `mem_queue_depth` | 8 | outstanding requests per warp (full queue stalls the warp) |
| `desc_fetch_cycles`, `imem_copy_words_per_cycle` | 3, 4 | launch phase |
| `dispatch_policy`, `dispatch_per_cycle`, `dispatch_latency` | `least_loaded`, 2, 2 | launch unit |
| `barrier_release_latency`, `retire_latency` | 1, 1 | |
| `seed`, `starvation_limit` | `0x5F1C5EED`, 256 | power-up pattern / jitter seed; forward-progress guard |

## 5. Freedoms the model exercises

| Freedom (spec reference) | Reference simulator | Hardware model | Evidence it matters |
|---|---|---|---|
| Memory latency, posted stores (04 4.8) | zero latency, immediate | 24-cycle global, 4-cycle shared, posted | cycles 96→327 (vecadd), 183→371 (diverge); all results equal |
| Order of accesses between warps (04 4.8, C8) | exact issue order | oldest-first arbitration, optional jitter reordering | atomic "tickets" differ between models yet form a permutation (`PlacementAndInterleavingDiffer`) |
| Banking / coalescing inside a warp instruction (04 4.8) | none | 8 banks, 32-byte segments | counters; results equal |
| Warp scheduling policy (05 5.3) | loose round robin | `oldest` / `lrr` / `gto` | same trace digests under all three |
| EG / slot placement, dispatch rate (05 5.1) | lowest EG, 1 WG/tick | least-loaded, 2 WG/cycle | a trap in workgroup 1 reports EG 0 (reference) vs EG 1 (model) |
| Barrier / fence / exit implementation (05 5.4, 5.5) | instantaneous | queue drain before arrival | mutation `barrier-does-not-drain-stores` is caught under jitter |
| Multi-cycle SIMT-stack resolution (03 3.4) | settled immediately | `1 + pops + pushes` cycles | `stack_resolve_cycles` counter; digests equal |
| Uninitialised memory (04 4.8, 08 8.3) | `0xDEADBEEF` poison | seeded random pattern | uninitialised-read test differs |
| Reset length, launch phase, watchdog units (01 1.8, 05 5.7) | 4 ticks, 1 tick, ticks | 7 / ~5+ / cycles | `PERF_CYCLES`, reset test |

## 6. Counters (`counters()`)

Describe the **most recent launch**: zeroed at every accepted doorbell exactly like `PERF_*`, readable after completion or a fault, plain integers
(ratios are floats under keys ending `_ratio`). `cycles`, `issued`, `lane_ops` mirror `PERF_CYCLES/ISSUED/LANE_OPS`;
`issue_slots_idle` = EG-cycles with resident warps in which nothing issued, split exactly into `stall_memory`, `stall_pipeline`, `stall_stack_resolve`,
`stall_barrier`, `stall_no_ready_warp` (tested to sum to `issue_slots_idle`); `global_requests`, `global_transactions`, `global_lane_accesses`,
`global_ldst_transactions`, `coalescing_ratio` (lane accesses per load/store transaction); `shared_requests`, `shared_bank_conflict_cycles`;
`max_mem_queue_depth`; `wg_dispatch_cycles`; `stack_resolve_cycles`; `eg<i>_busy_cycles`; `simt_efficiency_ratio`, `ipc_ratio`.

## 7. How conformance is measured

| Layer | What | Where | Result |
|---|---|---|---|
| L3 host-visible | **58 checks** (164 runs over `default`/`small`/`wide`; some are config-specific): identity/caps/`CFG_HASH`, every register access rule, aperture rules, every `LE_*` incl. priority order and stickiness, every `F_*` with `FAULT_*` contents and precision, interrupts, perf counters, SR values/partial warps/zero registers, **every ALU instruction on 256 operand pairs**, store/atomic lane order, atomic total order, C2, barriers (incl. exited warps/lanes), shared isolation, `SMEM_ZERO`, fences, instruction-memory capacity, watchdog, reset, the four example kernels vs independent computation and vs the **authoritative golden reports** | `sfsdk/conformance.py` | **164/164 on the reference and 164/164 on the model** (the unit tests also run it at 100 % on `small`+`default` under `jitter_gto` and `tiny_queue`; I additionally ran all three configs under `jitter` and `jitter_gto`: 164/164 each; the full parameter matrix is behind `SFSDK_SLOW_TESTS=1`) |
| L2 commit trace | per-warp trace digest equality: the 4 examples in 128 (example, configuration, microarchitecture) combinations (3 configs × 9 parameter sets, schedulers `oldest`/`lrr`/`gto`, three dispatch policies, fast/slow/narrow/wide memory, three jitter settings); the golden digests stored in the authoritative tree; 260 random structured programs (vendored generator: nested if/else, loops, breaks, early exits, loads, stores, spread over all parameter sets incl. jitter); 800 random "fault soup" programs | `tests/test_hwmodel_examples.py`, `test_hwmodel_differential.py` | all equal (outcome, counters, every `FAULT_*` register, trace up to the fault, final memory when completed). Soup outcome mix: 271 completed, 529 faulted across 9 distinct fault codes |
| L1 SIMT stack | 71,983 commands (random streams incl. overflow and ill-formed layouts, plus kernel-derived streams) on 3 configs vs the reference stack, including every overflow decision | `tests/test_hwmodel_stack.py` | all equal |
| Can it fail? | **22 injected bugs** (ALU, store/atomic lane order, C2, barrier drain, completion before drain, stack reuse, fault priority/lane, descriptor flags, `HOST_ERR`, barrier counting exited warps, shared-slot aliasing, `SMEM_ZERO`, perf counters, W1C, `DONE` clearing, SR values, partial-warp liveness) | `tests/test_hwmodel_mutation.py` | **22/22 caught**; the same selectors pass on the clean model (control) |
| Not vacuous | cycles, EG placement, interleaving, uninitialised memory, reset length all differ from the reference | `tests/test_hwmodel_nonvacuous.py` | pass |

The first mutation run caught 19 of 22: the three survivors were analysed, not waved away. One was an ineffective mutant, one was a genuinely weak check
(extra threads of a partial warp could write into unguarded memory: guard words were added), and one showed the *model* lacked a freedom
(with a single FIFO port and equal latencies a later load can never complete before an earlier store, so the barrier drain was unobservable): that is why `global_jitter` exists.

## 8. Reference / specification discrepancies found

1. **Reference trace bug for `atomadd rX, [rA], rX`** (destination = addend register, `rX != r0`). The reference builds the `mem` trace record after
   overwriting the destination row, which aliases the addend row, so it records the *returned old values* as the addends (`[100,112,124,136]` for four lanes adding 12 to 100)
   instead of the operand actually added (`12`). Memory contents are identical in both models. docs/09 9.4 defines the third element as the stored/added operand,
   so the hardware model records the operand. Consequences: such a kernel's trace digest differs between the models (already flagged as order-dependent when the old
   value is kept, docs/09 9.4); `atomadd r0, ...` (result discarded) is unaffected. Pinned by `AtomicTraceQuirk`. A register allocator that reuses the addend register for the
   result of `old = atomadd [p], v` would trigger it.
2. **`RESET_TICKS`**: docs/08 8.3 says `STATUS.READY` is 0 "for `RESET_TICKS`", and `reset_ticks` is a fixed constant (4) covered by `CFG_HASH`. Docs/01 1.8 says only the
   watchdog and `PERF_CYCLES` count the implementation's own cycles. The model treats reset duration as its own timing (7 cycles, brief-sanctioned). The conformance suite waits for
   `READY` rather than counting ticks, so it does not decide the question.
3. Two checks are *policy*, not architecture, and are named so: `fault_location_single_warp_reference_dispatch_policy` (a lone warp on an idle device lands on EG 0, warp slot 0; docs/05 5.1 lists it under the reference policy).

## 9. Limits and what is not modelled

* Not RTL; no timing/area/power meaning; no formal verification; the model does **not** use the vendored RTL blocks (its ALU and SIMT stack are separate Python code).
* Idealised: instruction fetch always hits (no contention), unlimited register-file and write-back ports, no caches, instantaneous aperture accesses, interrupts as a level only.
* One instruction in flight per warp (no intra-warp overlap); a hardware designer would pipeline more aggressively.
* Atomics are serialised per lane at the memory; no combining.
* Memory after a fault is dropped rather than drained (allowed; not what every implementation would do).
* Behaviour for data-racy kernels is not compared (the specification leaves it open); fault-soup memory is compared only for completed runs.
* Python speed: about 170k cycles/s, so a hung kernel under the default `WDOG_LIMIT` (1,000,000) costs roughly 6 s; set `WDOG_LIMIT` for experiments.
* Power-up global memory is a seeded random fill of the whole `gmem_bytes` (a 1 GiB configuration would allocate 1 GiB).
