# Toolchain: assembler, disassembler, kernel container, command line

```
 .sfir  --(sfsdk.compiler)-->  .sfa assembly text  --(sfsdk.asm)-->  .sfk container  --(sfsdk.runtime)-->  device
 (restricted IR)               (+ metadata directives)               (code + launch metadata)            (any backend)
                                                  .sfbin = the bare code words (what a launch descriptor points at)
```

## 1. Authoritative ISA definitions

The assembler (`sfsdk/asm.py`), disassembler (`sfsdk/disasm.py`) and the hardware model's decoder all read the instruction set
from **`sf-g1/spec/sf_g1_isa.json`** through `sfsdk/isa.py`. Nothing about opcodes, formats, field positions or special registers is
hard-coded: adding a row to the JSON adds an instruction to every tool. The reference model's decoder is *not* imported by this
code; instead the test-suite requires the two independent implementations to agree on 79,200 words (60,000 random and 300 per opcode),
on `CFG_HASH` for all configurations, and requires the assembler to emit **byte-identical** code to the reference assembler for the
four example kernels (also compared with the golden `kernel.hex` files) and for 150 random programs, and to reject the same malformed
sources. Reserved bits, a zero reconvergence offset and undefined special-register indices decode as *illegal*, exactly as specified.

The 35 instructions (formats R, I, IS, U, S, B, J, T, Z, SR) are tabulated in `sf-g1/docs/generated/isa_reference.md`.
`r0` reads zero; there are 16 registers; the PC is an instruction index; branches are PC-relative with an explicit reconvergence offset.

## 2. Assembler language

The language of `sf-g1/docs/10-assembler.md` is accepted unchanged:

```
; comment      // comment
label:         add  r1, r2, r3
.equ  N, 4*8                     constant (expressions may use earlier symbols)
.reg  acc, r9                    register alias
.word 0x12345678, -1, label      raw words
```

Mnemonics, registers and `zero` are case-insensitive; labels and constants are case-sensitive. Immediates are expressions:
decimal, `0x..`, `0b..`, symbols, `+ - * / % << >> & | ^ ~`, parentheses, `%hi(x)` (`x >> 10`), `%lo(x)` (`x & 0x3ff`).
Memory operands: `[r5]`, `[r5 + 8]`, `[r5 - 4]`; `atomadd` takes `[rN]` only. **Branch operands are absolute labels**
(instruction indices); the assembler converts them to PC-relative offsets and range-checks them (`bz`/`bnz`: target within
-1024..+1023 instructions, reconvergence 1..2047 after the branch). `lui rd, imm22` takes the raw 22-bit field and loads
`imm22 << 10`.

Pseudo-instructions: `li la mov neg not sgt sgtu j`. `li rd, expr` is one word if the value fits a signed 18-bit immediate or has
zero low 10 bits, two (`lui` + `ori`) otherwise; a *forward-referenced* `li` always reserves two words (padded with `nop`).

Diagnostics are collected for the whole file (`AsmError.errors`, each `file:line: error: ...`): unknown mnemonic, operand count,
`r16`, immediate out of range, undefined or duplicate symbol, reconvergence address not after the branch, unencodable branch
offset. Warning: branch target beyond its reconvergence address (it faults with `F_RECONV` if the branch diverges).

### SDK extension directives (launch metadata)

They never change the code words; a file without them assembles to exactly what the reference assembler produces.

| directive | meaning |
|---|---|
| `.kernel NAME` | kernel name |
| `.arg KIND NAME [ACCESS [ELEMS]]` | `KIND` = `ptr`/`u32`/`i32`; for `ptr`, `ACCESS` = `r`/`w`/`rw` and `ELEMS` = expression for the minimum extent in 32-bit words; at most 8 arguments (`SR_ARG0..7`) |
| `.shared EXPR` | shared bytes per workgroup the kernel itself needs |
| `.shared_per_thread EXPR` | additional shared bytes **per thread** (the compiler uses this for its register-spill area) |
| `.require EXPR [, "message"]` | launch precondition; must be non-zero |
| `.entry LABEL` | entry instruction (default 0) |

Metadata expressions are evaluated at launch over the argument names, `wg_dim`, `grid_dim`, `lanes` and `.equ` constants. They use the
same evaluator as immediates (no `eval`), plus comparisons and `&& || !`; comparison/logical operators bind **looser** than the bitwise
operators (as in Python), so `(wg_dim & (wg_dim - 1)) == 0` means what it says.

```python
import sfsdk
prog = sfsdk.assemble("""
    .kernel demo
    .arg ptr out w n
    .arg u32 n
    .shared 4*wg_dim
    .require (wg_dim & (wg_dim - 1)) == 0, "wg_dim must be a power of two"
    start:  li   r1, 0x12345678      ; two words
            bz   r1, start, end
            nop
    end:    exit
""", "demo.sfa")
assert len(prog.words) == 5                                                    # li = lui + ori (two words)
assert [sfsdk.format_instr(w, i) for i, w in enumerate(prog.words[:2])] == [f"lui r1, {0x12345678 >> 10}", f"ori r1, r1, {0x12345678 & 0x3FF}"]
assert prog.labels == {"start": 0, "end": 4}
assert prog.meta.name == "demo" and [a.name for a in prog.meta.args] == ["out", "n"]
img = prog.image()
assert sfsdk.KernelImage.from_bytes(img.to_bytes()).words == img.words        # container round trip
```

## 3. Disassembler

`disassemble(words)` returns assembler source that **re-assembles to exactly the same words** (tested on random programs and on
arbitrary 32-bit words): illegal words are written as `.word 0x...`; branch targets and reconvergence points get `L<n>:` labels, or
the real label names stored in a `.sfk` (`symbols=`); `addresses=True` adds `; pc: word` comments.

```python
words = sfsdk.assemble("top: addi r1, r1, 1\n slt r2, r1, r3\n bnz r2, top, after\nafter: exit\n").words
text = sfsdk.disassemble(words)
assert "bnz r2, L0, L3" in text and sfsdk.assemble(text).words == words
assert sfsdk.format_instr(0xFFFFFFFF, 0) == ".word 0xffffffff"
```

## 4. Kernel container `.sfk`

The architectural artefact is the code image (`.sfbin`: little-endian 32-bit words). The `.sfk` container wraps the same words with launch
metadata: argument kinds, extents, shared demand, requirements, symbols and a pc-to-source-line table (used to name the faulting source line).
The metadata is **SDK policy** for argument validation; the device neither knows nor checks it.

```
 0  4  magic "SFK1"      4  2  version (1)      6  2  flags (0)      8  4  ISA hash (CRC-32 of the documentation-free ISA JSON)
12  4  code_words       16  4  meta_len        20  4  CRC-32 over code + metadata       24 ...  code words, then metadata (canonical JSON)
```

Loading verifies magic, lengths, the CRC and that the ISA hash equals the hash of the definition the SDK was built from (a container
produced for a different ISA revision is refused). `KernelImage.uses_order_dependent_atomics` flags kernels that keep an `atomadd` result
(`rd != r0`); the commit-trace digests of such kernels are legitimately implementation-dependent (docs/09 9.4) and the comparison
harness does not compare them.

## 5. Command line (`bin/sfsdk`)

| command | purpose |
|---|---|
| `sfsdk devices [--json]` | enumerate devices from their own registers |
| `sfsdk asm k.sfa -o k.sfk [--sfbin F --hex F --listing F --symbols F]` | assemble |
| `sfsdk dis k.sfk [--addresses --symbols]` | disassemble `.sfk`/`.sfbin` |
| `sfsdk cc k.sfir -o k.sfk [--asm F --listing F --max-regs N --config C --no-opt]` | compile restricted IR |
| `sfsdk info k.sfk` | metadata of a kernel |
| `sfsdk run K --grid G --wg W --buf a=1,2,3 --buf c=8x0 --arg @a --arg @c --arg 8 --dump c [--profile --instr-profile --device hwmodel:small]` | run one kernel |
| `sfsdk samples list|run [NAME...]` | the sample kernels |
| `sfsdk compare [NAME...] [--backends reference hwmodel] [--configs default small wide]` | run on several backends and compare |
| `sfsdk conformance [--backend reference|hwmodel|both]` | host-level conformance suite |
| `sfsdk rtl-replay` | replay sample binaries through the verified RTL blocks (needs Icarus Verilog) |
