# SilicaFlux SF-G1 compiler: restricted IR to SF-G1 instructions

This document describes `sfsdk/compiler/`: a small compiler from a **restricted, structured intermediate
representation (IR)** to SF-G1 machine code. It documents the IR, how each construct is lowered, how registers are
allocated and spilled, how workgroup dimensions and memory are laid out, and which constructs are **not** supported.

> **Non-claims.** The IR is an original language defined in this document. It is **not** CUDA, OpenCL, Vulkan/GLSL/SPIR-V,
> HIP, Metal, SYCL, PTX or any other existing GPU language, API or ISA, and nothing here is, or claims to be, source- or
> binary-compatible with them. SF-G1 itself is specified in `sf-g1/docs/`; this compiler targets exactly that
> specification (`sf-g1/spec/sf_g1_isa.json` is authoritative for every encoding limit the compiler uses).
> Quality claims below are limited to what the test-suite measures (section 15).

## 1. Pipeline

```
 .sfir text ──parse──▶ IR ──verify──▶ uniformity ──fold──▶ lower ──▶ LIR (virtual regs) ──dce──▶ fuse ──▶ regalloc ──▶ emit ──▶ .s ──asm──▶ words / .sfk
 parser.py            verify.py     uniform.py     fold.py   lir.py                 regalloc.py                emit.py     driver.py     sfsdk.asm
```

| Stage | Module | What it does |
|---|---|---|
| Parse | `parser.py`, `ir.py` | Text to a tree of statements; collects **all** diagnostics with `file:line`; explains every unsupported construct. A Python builder (`KernelBuilder`) and a printer (`format_kernel`) round-trip the same tree. |
| Verify | `verify.py` | Removes unreachable code (warning), enforces **definite assignment**, `break` placement, expression names in `shared`/`require`/extents. |
| Uniformity | `uniform.py` | Conservative lane-uniformity analysis; rejects a `barrier` that could be reached by only some lanes of a warp (section 8). Also counts divergence nesting for the SIMT-stack estimate (section 9). |
| Fold | `fold.py` | Folds literal-only operations, propagates single-definition constants, **always** removes `if <literal>` / `break_if <literal>` (it is structural, see section 7.3). |
| Lower | `lir.py` | Structured IR to a linear list of SF-G1 instructions over **virtual** registers, including immediate selection, compare lowering, and reconvergence labels. |
| Clean-up | `regalloc.py` | Liveness-based dead-code elimination; fusion of `eq`/`ne` compares into the following branch. |
| Allocate | `regalloc.py` | Live intervals, linear-scan allocation, two-mode spilling to shared memory (sections 10, 11). |
| Emit | `emit.py`, `driver.py` | Assembler text with the SDK metadata directives, branch-range and size checks, pc-to-IR-line table. The text is assembled by `sfsdk.asm` (the compiler never writes words itself). |

Public API (`sfsdk.compiler`):

```python
from sfsdk.compiler import compile_ir, parse_ir, interpret, KernelBuilder, format_kernel
res = compile_ir(source, "k.sfir", config=Config.named("default"), max_regs=None, opt=True, kernel=None)
res.asm        # assembler text (.kernel/.arg/.shared/.shared_per_thread/.require directives + code)
res.program    # sfsdk.asm.Program         res.image()  -> sfsdk.binfmt.KernelImage (words + launch metadata + pc->IR-line table)
res.warnings   # list[str]                 res.info     -> statistics dict (section 15.1)
```
`compile_ir` raises `sfsdk.errors.CompileError` whose `.errors` lists every diagnostic. `interpret(kernel, grid, wg, args, gmem, ...)`
executes the IR itself (section 14) and is used as the semantic oracle for testing.

## 2. The IR language

One statement per line; blocks use `{ }` (`} else {` joins the arms of an `if`). Comments start with `#`, `;` or `//`.
Everything is a 32-bit value. There are **no types** beyond the parameter kinds; signedness is carried by the operation
(`lt` vs `ltu`, `shr` vs `sar`).

```
kernel reduce_sum(ptr data r n, ptr out rw 1, u32 n)           # PARAM := KIND NAME [ACCESS [EXTENT]]
    shared 4*wg_dim                                              # user shared bytes per workgroup (expression)
    require (wg_dim & (wg_dim - 1)) == 0 "wg_dim must be a power of two"
{
    ...statements...
}
```

### 2.1 Header

| Part | Meaning |
|---|---|
| `kind` | `ptr` (global **byte** address), `u32`, `i32`. The kind is metadata for the SDK's argument validation; inside the kernel every parameter is just a 32-bit value. |
| `access` (ptr only) | `r`, `w`, `rw` (default `rw`): what the kernel does through the pointer. Recorded in the kernel metadata; the SDK runtime uses it to warn when a written buffer overlaps another buffer argument. It does **not** enforce read-only/write-only buffers (SF-G1 has no memory protection; the runtime's guard canaries catch stores outside a buffer, not stores to a buffer declared `r`). |
| `extent` (ptr only) | Minimum size of the pointed-to buffer **in 32-bit words**, an expression over parameters, `wg_dim`, `grid_dim`, `lanes`. Parenthesise it if it contains spaces: `ptr A r (M * K)`. |
| `shared EXPR` | Shared-memory bytes the kernel itself needs per workgroup (default 0). |
| `require EXPR "msg"` | Launch precondition: must evaluate non-zero when the kernel is launched. Operators: `|| && == != < <= > >= | ^ & << >> + - * / % ! ~` (comparison/logical bind looser than bitwise, as in Python). |
| parameters | At most **8** (`SR_ARG0..SR_ARG7`); parameter *i* is read with `rdsr SR_ARG<i>`. |

Header attributes become the assembler directives `.kernel .arg .shared .shared_per_thread .require` (see `sfsdk/asm.py`),
which the runtime evaluates at launch time.

### 2.2 Names, operands, literals

* **Builtins** (readable anywhere): `tid wg_id wg_dim grid_dim gtid lane warp lanes shared_bytes` (section 12 gives their meaning).
* **Parameters**: read-only. **Variables**: any other identifier that is assigned; mutable, function scope. A variable (or
  parameter) may not share a name with a builtin, keyword or operation.
* **Definite assignment is enforced**: a variable used on a path where it might not have been assigned is a compile error
  (`variable 'x' may be used before it is assigned`). Registers are *not* guaranteed zero after allocation reuses them.
* **Literals**: decimal, `0x...`, `0b...`, optionally negative; must fit `-2^31 .. 2^32-1` and are stored modulo 2^32.
* A **condition** (`if X`, `break_if X`) is a variable, parameter, builtin or literal; non-zero means true. Compute comparisons into a
  variable first (`c = lt a, b` then `if c`).

### 2.3 Value operations (`x = OP operands`)

| Group | Operations | Meaning (all modulo 2^32) |
|---|---|---|
| arithmetic | `add sub mul` | `mul` = low 32 bits |
| logic | `and or xor` | bitwise |
| shifts | `shl shr sar` | amount is `b & 31`; `shr` logical, `sar` arithmetic |
| compare, 0/1 | `lt le gt ge` (signed), `ltu leu gtu geu` (unsigned), `eq ne` | result is 0 or 1 |
| unary | `not neg lnot bool mov` | `not` = `~a`; `lnot` = `a == 0`; `bool` = `a != 0` |
| select | `select c, a, b` | `a` if `c != 0` else `b` (branch-free) |
| address | `lea base, idx` | `base + 4*idx` |
| memory | `ld.g [addr]`, `ld.s [addr]`, `old = atomadd [addr], v` | `addr` is an operand with an optional literal `+ n`/`- n` (signed 18-bit) |
| uniformity | `y = assume_uniform x` | identity; a programmer assertion for the uniformity analysis (section 8) |

`x = a` is a copy (`mov`). Statements without a result: `st.g [addr], v`, `st.s [addr], v`, `atomadd [addr], v` (result discarded),
`barrier`, `fence`, `trap N` (N is a 16-bit literal), `return`, `break`, `break_if X`, `if X { } [else { }]`, `loop { }`.

### 2.4 Control flow

* `if X { A } [else { B }]` — per-lane two-way branch (may diverge).
* `loop { ... }` — infinite loop; leave with `break`, `break_if X`, or `return`. There is no `while`/`for` keyword
  (a counted loop is `loop { d = ge i, n; break_if d; ...; i = add i, 1 }`).
* `return` — the executing threads terminate (`exit`).
* The kernel ends with an implicit `exit` for every thread that reaches the end.

## 3. Lowering of value operations

SF-G1 has no flags, no divide, no compare-and-branch, and immediates are **signed 18-bit, sign-extended for every immediate
instruction** (also `andi/ori/xori`), so `andi r, r, 0xFFFFFF00` is encoded as `andi r, r, -256`. Constants that do not fit use
the assembler pseudo `li` (one word if the value fits 18 signed bits or has zero low 10 bits, else `lui`+`ori`).

| IR | SF-G1 sequence |
|---|---|
| `add x, c` / `sub x, c` | `addi x, c` / `addi x, -c` when the immediate fits, else `li` + `add`/`sub` |
| `mul x, 2^k` / `mul x, 0` / `mul x, 1` | `shli x, k` / `li 0` / `addi x, 0`; otherwise `mul` (no immediate form; constant via `li`) |
| `and/or/xor x, c` | `andi/ori/xori` if `c` (as int32) fits 18 bits, else `li` + register form |
| `shl/shr/sar x, c` | `shli/shri/sari x, c & 31` |
| `lt x, y` / `ltu x, y` | `slt` / `sltu` (`slti`/`sltiu` for a fitting right-hand literal) |
| `gt x, y` | `slt y, x` (operands swapped) |
| `le x, y` | `slt t, y, x; xori d, t, 1` (or `slti x, c+1` for a literal `c`) |
| `ge x, y` | `slt t, x, y; xori d, t, 1` (`geu/leu/gtu` analogously with `sltu`) |
| `eq x, y` | `xor t, x, y; sltiu d, t, 1` (`addi t, x, -c` / `xori t, x, c` for a literal; `x == 0`: `sltiu d, x, 1`) |
| `ne x, y` | `xor t, x, y; sltu d, r0, t` |
| `not x` / `neg x` / `lnot x` / `bool x` | `xori x, -1` / `sub r0, x` / `sltiu x, 1` / `sltu r0, x` |
| `select c, a, b` | `sltu n, r0, c; sub m, r0, n; xor t, a, b; and t, t, m; xor d, b, t` (5 instructions, branch-free) |
| `lea b, i` | `shli t, i, 2; add d, b, t` (`addi` forms when `b` or `i` is a literal) |
| `ld.g/ld.s [a + off]` | `ldg/lds d, [a + off]`; a literal address that fits uses `[r0 + c]` |
| `st.g/st.s [a + off], v` | `stg/sts v, [a + off]`; literal `0` is `r0` |
| `atomadd [a], v` | `atomadd r0, [a], v` (result discarded: `rd = r0`) |
| `old = atomadd [a], v` | `atomadd rd, [a], v`; if `old` is never used the optimiser rewrites it to `rd = r0` |
| `barrier` / `fence` / `return` / `trap n` | `bar` / `fence` / `exit` / `trap n` |

Peephole: if an `eq`/`ne` result feeds only the immediately following `if`/`break_if`, the pair collapses to one branch on the
`xor`/`addi` result (`sltiu d,t,1; bz d` becomes `bnz t`).

Not done (by design, to keep the compiler small): common-subexpression elimination, strength reduction beyond powers of two, instruction
scheduling, loop-invariant code motion. For example the compiled `vecadd` has 18 instructions where the hand-written reference kernel has 16,
because `shli t, i, 2` is recomputed for each `lea`.

## 4. Control flow and reconvergence

SF-G1 branches are `bz/bnz rs1, target, reconv`: lanes whose condition holds go to `target`, the others fall through, and diverged groups
re-meet at `reconv` (which must be the branch's **immediate post-dominator**, `sf-g1/docs/03` 3.6). The compiler emits:

| Construct | Code | `target` | `reconv` |
|---|---|---|---|
| `if c { A }` | `bz c, Lend, Lend; A; Lend:` | `Lend` | `Lend` |
| `if c { A } else { B }` | `bz c, Lelse, Lend; A; bra Lend; Lelse: B; Lend:` | `Lelse` | `Lend` |
| `loop { B }` | `Ltop: B; bra Ltop; Lexit:` | | |
| `break_if c` | `bnz c, Lexit, Lexit` | `Lexit` | `Lexit` |
| `break` | `bra Lexit` | | |
| `return` | `exit` | | |

### 4.1 The break rule

A `break` changes the post-dominator of every enclosing `if` inside its loop: lanes that break never pass that `if`'s end. So **every `if`
whose then/else region contains a `break`/`break_if` that leaves the innermost enclosing loop uses that loop's exit label as its
reconvergence address** (its target stays its own else/end label, so `target <= reconv` as the layout rule requires). The compiler decides this on
the *post-optimisation* tree (a break removed by folding does not force the rule), and an `if` that merely *contains a loop with its own breaks* does
not escape. A `return` needs no special handling (exited lanes leave the live mask). The rule is tested by name in
`tests/test_compiler_codegen.py::Reconvergence` and by the mutant "break rule ignored" (killed: the device faults with `F_RECONV`).

### 4.2 Why `continue` is not supported

A `continue` is a backward jump from inside a path whose reconvergence address lies *ahead*. When that path runs again from the loop top it
overruns its reconvergence address and the device faults with `F_RECONV` (or reconverges at the wrong place). Restructure the body with `if`.

### 4.3 Branch ranges and size

`bz/bnz` reach `-1024..+1023` instructions (target) and `1..2047` (reconvergence); a violation is reported as `E_BRANCH_RANGE` with the IR line.
A kernel larger than `imem_words` of the target configuration (default 1024) is rejected, and that check precedes the range check.

## 5. The `.sfk` kernel image

`res.image()` returns a `KernelImage`: the code words (what a launch descriptor points at) plus launch metadata: argument kinds, access modes and extents,
`shared`, `shared_per_thread`, `require`s, labels, and a **pc to IR line** table (a device fault's `FAULT_PC` can be mapped back to the IR line).
`image().meta.info` carries the statistics of section 15.1. The metadata is SDK policy, not architecture; a bare `.sfbin` of the same words launches identically.

## 6. Optimisations (all optional except `if <literal>`)

`compile_ir(..., opt=False)` disables folding, propagation, DCE and branch fusion; the fuzz-suite checks `opt=False` produces identical results
(`test_optimisation_does_not_change_results`). Constant `if`/`break_if` elimination always runs (section 4.1 explains why).

## 7. Uniformity analysis and barriers

`bar` requires `active == live` for the issuing warp; otherwise the device faults with `F_BAR_DIVERGENT`. The compiler therefore accepts a `barrier` only if
it is **not nested, at any depth, under a construct controlled by a condition it cannot prove uniform across a warp**:

* *uniform sources*: literals, parameters, `wg_id wg_dim grid_dim lanes shared_bytes`; *non-uniform*: `tid gtid lane warp`, every load, every atomic result;
* an operation is uniform iff all operands are; a variable is uniform iff **every** assignment is uniform **and** executes in uniform control context;
* an `if` with a non-uniform condition makes its arms divergent; a `loop` whose `break`/`break_if` can fire under a non-uniform condition makes its whole body divergent
  (lanes that left are parked at the loop exit while others continue);
* `return` under a non-uniform condition is **not** divergence (exited lanes are no longer live), so `if c { return } barrier` is accepted;
* a barrier *after* a divergent `if` or loop is fine (the lanes have reconverged).

`assume_uniform` overrides the analysis; if the assertion is wrong the barrier faults precisely at run time (tested: without the check the reference simulator
faults with `F_BAR_DIVERGENT`). **Limitation:** the analysis is flow-insensitive. A variable that is *ever* assigned a non-uniform value is non-uniform everywhere, even
if every use follows a uniform reassignment; use a fresh variable (or `assume_uniform`). This is conservative, never unsafe.

## 8. SIMT stack depth

Each warp has a reconvergence stack of `simt_stack_depth` entries (default 16, `small` 4, `wide` 32) and a divergent branch that needs more faults with
`F_STACK_OVERFLOW`. By the specification the depth can never exceed `2*lanes - 1`. The compiler estimates the worst case and **warns** when the target configuration
is smaller:

* structured code needs `1 + 2 x D`, D = nesting depth of non-uniform `if`s and loops with a divergent exit;
* **exception, found by testing:** a divergent `if` that breaks out of its loop reconverges at the loop exit (section 4.1), so the lanes that took the other arm stay
  parked for the rest of the loop and each iteration can park another group: need grows with the data. The estimate then becomes the architectural bound `2*lanes - 1`.
  A loop that peels one lane per iteration (`if tid == i { break }`) measurably needs depth 9 on 8 lanes (the nesting formula says 5).
* warning condition: `min(estimate, 2*lanes - 1) > simt_stack_depth`. `info["stack_overflow_possible"]` records it. The default and `wide` configurations
  (depth >= 2*lanes-1) can never overflow; only `small` can.

The estimate is conservative: three sample kernels warn on `small` and in practice run without overflow on every geometry the tests use.

## 9. Register allocation

SF-G1 has 16 registers per thread; `r0` is hard zero, so **`r1..r15` are allocatable**. There is no stack, link register or calling convention.

1. **Rematerialisation.** Every use of a literal, parameter or builtin that needs a register is rebuilt (`li` / `rdsr`) in a fresh short-lived virtual register
   right before the use, so these never occupy a register across statements. Cost: one instruction per use (visible as `(remat)` in listings). To keep a value in a register,
   copy it into a variable (`i = gtid`).
2. **Liveness.** The LIR is split into blocks (labels and branches), successors follow the branches (the `reconv` operand is not an edge: lanes reach it through ordinary edges),
   and live-in/live-out sets are computed to a fixed point, so loops (back edges) extend live ranges around the whole loop.
3. **Intervals.** Conservative `[first live, last live]` over *half positions*: instruction `i` reads at `2i` and writes at `2i+1`. A value whose last use is instruction `i`
   shares a register with the value instruction `i` defines; a value that is live *into* a block overlaps anything used in its first instruction. (The mutants "intervals shortened" and
   "liveness ignores back edges" are both killed by the fuzz-suite.)
4. **Linear scan** (Poletto-Sarkar): intervals in start order, lowest free register first. If none is free, the victim is the live interval with the **furthest end**
   (ties: fewest uses), excluding rematerialisation temporaries, which are never spilled. If an instruction's operands alone cannot fit, allocation fails with a clear error.
5. **Two modes.** First try all 15 registers. If *any* interval would spill, redo with **12** allocatable registers (`r1..r12`) and 3 reserved: `SB=r15` (spill base), `S1=r14`,
   `S2=r13` (scratch). Reserving only when needed means kernels that fit pay nothing.
6. **Testing knob.** `compile_ir(..., max_regs=N)` (N >= 4) caps the allocatable registers in both modes (`min(N,15)`, `min(N,12)`), forcing spills in small programs.

Post-pass: register-to-register copies the allocator made redundant (`addi rX, rX, 0`) are deleted.

## 10. Spilling

SF-G1 has **no local memory and no stack** (`sf-g1/docs/04` 4.1). A spilled value therefore lives in a **thread-private word of shared memory**, at the *end* of the workgroup's
shared region:

```
shared region (SHARED_BYTES from the launch descriptor, per workgroup)

 0                       user_bytes                                              SHARED_BYTES
 | kernel's own shared data | (free: whatever the launch added) | spill area: wg_dim threads x 4P bytes |
                                                                   ^ thread t owns [SB_t, SB_t + 4P)
 SB_t = SHARED_BYTES - 4*P*(wg_dim - t)        slot s of thread t is at  SB_t + 4*s
 P = number of slots, rounded up to a power of two
```

* **Prologue** (only in spilling kernels that use slots), 6 instructions:
  `rdsr SB, SR_WG_DIM; rdsr S1, SR_TID; sub SB, SB, S1; shli SB, SB, 2+log2(P); rdsr S1, SR_SHARED_BYTES; sub SB, S1, SB`.
* **Spill** `sts value, [SB + 4*slot]` right after each definition; **reload** `lds S, [SB + 4*slot]` before each use (S1, then S2 for a second spilled operand;
  a spilled destination is computed into S1, then stored). Whole-interval spilling: a spilled variable lives only in memory.
* **Slot sharing**: spilled intervals that do not overlap share a slot.
* **Rematerialisation spills**: a spilled variable whose only definition is `rdsr` or `li` is *not* stored; its definition is deleted and rebuilt before each use (no slot, no memory traffic).
* **Directive** `.shared_per_thread 4*P` tells the runtime to launch with `shared = <kernel shared> + 4*P*wg_dim`. If the launch gives less, the spill base can fall below zero and the
  kernel faults with `F_SMEM_RANGE` (tested) instead of corrupting memory silently.
* **Capacity**: `4*P*wg_dim` must fit `wg_slot_smem_bytes` of the configuration (default 4096, `small` 2048, `wide` 4096). The compiler errors only if one *thread's* demand cannot fit; otherwise it
  emits `.require (<shared>) + 4P*wg_dim <= <capacity>` (checked at launch) and warns if the configuration's largest workgroup would exceed it, e.g. a 64-byte-per-thread spill area limits
  `wide` to 64 threads.
* **Cost model**: +1 store per definition and +1 load per use of a slot-spilled value (no cache; shared memory is the cheapest memory SF-G1 offers); every use of a spilled
  rematerialisable value costs 1-2 instructions. Example: `histogram_global` with `max_regs=4`: 23 to 31 instructions, 1 slot, 1 reload, 1 store.
* **Not implemented**: live-range splitting (a value is in a register or in memory for its entire life), global-memory spill, coalescing of spill slots with user shared data.

Measured spill behaviour of the samples with a restricted allocatable register count (default configuration):

| kernel | max_regs | instructions | slots (P) | reloads | stores |
|---|---|---|---|---|---|
| histogram_private | none (15) | 61 | 0 | 0 | 0 |
| histogram_private | 5 / 4 | 71 / 77 | 2 (2) / 3 (4) | 2 / 5 | 2 / 4 |
| matmul_naive | 5 / 4 | 60 / 64 | 3 (4) / 4 (4) | 6 / 8 | 4 / 6 |
| matmul_tiled | 5 / 4 | 76 / 80 | 3 (4) / 4 (4) | 7 / 9 | 5 / 7 |
| reduce_max_pass1 | 5 / 4 | 42 / 52 | 0 / 1 (1) | 0 / 3 | 0 / 1 |

## 11. Workgroup dimensions

* Grids and workgroups are **one-dimensional** (`sf-g1/docs/01` 1.5). `grid_dim` is 1..65535; `wg_dim` is 1..`max_wg_threads = lanes x warps_per_eg` of the device (`default` 32, `small` 8, `wide` 128).
* Thread `tid` (0..wg_dim-1) is in warp `tid / lanes`, lane `tid % lanes`. `gtid = wg_id * wg_dim + tid` (mod 2^32). The last warp of a workgroup may be **partial**; its missing lanes never execute anything,
  so `wg_dim` need not be a multiple of `lanes` (all samples are tested with partial warps and `wg_dim = 1`).
* There is no 2-D/3-D index. Without a divide instruction a flat index cannot be split into row/column, so the samples use **one workgroup per row** with threads striding across columns
  (`matmul_*`) or grid-stride loops (`histogram_global`, `reduce`).
* Constraints are expressed with `require`: `(wg_dim & (wg_dim - 1)) == 0` for the tree reductions and the private histogram; `grid_dim == M` for the matrix kernels; `grid_dim == 1` for the second reduction pass.
  The runtime evaluates them at launch and also checks `wg_dim`/`grid_dim`/shared size against the device's capability registers.
* `shared EXPR` may use `wg_dim`, `grid_dim`, `lanes` and parameters (`shared 4*wg_dim`, `shared 4*K`).
* A workgroup runs on one execution group; workgroups of one launch may run in any order or concurrently and must not wait for each other (`sf-g1/docs/04` C8).

## 12. Memory layout and conventions

| Space | Layout / convention |
|---|---|
| Global memory | One flat byte-addressed space of `gmem_bytes` (default 1 MiB), **word (4-byte) accesses only**, little-endian, addresses must be 4-byte aligned (`F_GMEM_ALIGN`) and inside the space (`F_GMEM_RANGE`). Address 0 is architecturally valid; the host library keeps `0..0xFF` unmapped by convention and allocates buffers from `0x100`, 64-byte aligned. Code images and the 64-byte launch descriptor also live here (placed by the host). Power-up contents are undefined (the reference simulator fills `0xDEADBEEF`). |
| Shared memory | Per workgroup, **workgroup-relative** byte addresses in `[0, SHARED_BYTES)`; layout `[user data | free | spill area]` (section 10); undefined at workgroup start unless the descriptor sets `SMEM_ZERO` (the reference model poisons it with `0xDEADBEEF`). A workgroup cannot name another workgroup's shared memory. |
| Registers | `r1..r15` per thread, zero at thread start but never assume it (the compiler enforces definite assignment). |
| Arguments | Up to 8 words in the launch descriptor, read with `rdsr SR_ARG0..7`: pointers are **global byte addresses**, sizes are element counts. |
| Addresses in the IR | **Bytes**. `lea base, idx` computes `base + 4*idx`. `ld/st` offsets are literals in `-131072..131071`. |

Memory ordering follows `sf-g1/docs/04`: a thread sees its own earlier stores; `barrier` is a workgroup-wide release/acquire (global and shared); `fence` orders a warp's accesses device-wide; there is
**no ordering between workgroups** except `atomadd` (totally ordered per address) plus `fence`. Kernels must be data-race-free for their results to be defined; all samples and all fuzz programs are.

## 13. Unsupported constructs

All are rejected at compile time with an explanation (`tests/test_compiler_frontend.py::Parser`).

| Construct | Reason |
|---|---|
| `div`, `rem`, `mod` (and unsigned/signed variants) | SF-G1 has no divide instruction. Use masks/shifts for powers of two, or restructure (one workgroup per row). |
| `continue` | A backward jump out of a divergent path overruns its reconvergence address (`F_RECONV`); restructure with `if` (section 4.2). |
| labelled `break`, `goto`, indirect branches | Control flow is structured; `break` targets the innermost loop only. |
| function calls, recursion | No stack and no link register. Inline by hand. |
| floating point (`f32` params, `fadd`, ...) | The SF-G1 v1 ISA is integer-only (an FP extension exists as a separate tree and is not targeted here). |
| byte / halfword loads and stores | Memory accesses are 32-bit words. |
| high-half multiply (`mulh`, `mulhu`) | `mul` returns the low 32 bits only. |
| shared-memory atomics | SF-G1 has exactly one atomic: global `atomadd`. (`histogram_private` shows a technique that avoids needing them.) |
| any atomic other than add (`atommax`, `atomxchg`, ...), compare-and-swap | not in the ISA (use a two-pass reduction, see `reduce_max_pass1/2`). |
| warp shuffle, vote/ballot | not in the ISA. |
| 2-D/3-D grids or workgroups | descriptors carry `GRID_DIM` and `WG_DIM` only. |
| dynamic shared allocation inside a kernel | shared size is fixed per launch (declare it with `shared`). |
| more than 8 parameters | `SR_ARG0..SR_ARG7`. |
| `printf`, I/O, system calls | none exist. |
| self-modifying code, reading the code image | instruction memory is not addressable. |
| `barrier` under a condition not provably uniform | `F_BAR_DIVERGENT` (section 7); use `assume_uniform` only if guaranteed. |
| arrays of registers / indexing registers | registers are not addressable; use shared memory. |

## 14. The IR interpreter (testing oracle)

`interpret(kernel, grid, wg, args, gmem, lanes=8, shared_bytes=0)` runs the IR itself, knowing nothing about registers, masks or reconvergence. Threads run sequentially; the threads of a workgroup advance in lock-step
phases separated by barriers; atomics apply in ascending thread order (one valid order; race-free kernels cannot tell). It raises `InterpError` for misaligned/out-of-range accesses, `trap`, a barrier reached at
different sites by threads of one warp, and runaway loops. Its operation semantics (`semantics.py`) are checked against the ISA's real ALU in the tests (about 37,000 operand pairs).

## 15. Evidence

### 15.1 `res.info`

`instructions regs_used allocatable_regs spilling spilled_variables spill_slots spill_slots_padded spill_bytes_per_thread spill_max_wg_dim spill_loads spill_stores remat_count branches max_divergence_depth
est_stack_depth stack_depth_basis stack_overflow_possible ir_statements optimised config`.

### 15.2 Sample kernels (`kernels/*.sfir`, default configuration)

| kernel | IR stmts | instructions | regs | divergence depth | stack need |
|---|---|---|---|---|---|
| vecadd | 10 | 18 | 4 | 1 | 3 |
| histogram_global | 12 | 23 | 5 | 1 | 3 |
| histogram_private | 38 | 61 | 7 | 2 | 5 |
| reduce_sum | 27 | 31 | 5 | 1 | 3 |
| reduce_max_pass1 | 29 | 39 | 6 | 1 | 3 |
| reduce_max_pass2 | 32 | 46 | 6 | 1 | 3 |
| matmul_naive | 24 | 44 | 8 | 2 | 5 |
| matmul_tiled | 35 | 58 | 8 | 2 | 5 |

| spill_demo | 46 | 81 | 15 | 1 | 3 |

Only `spill_demo` spills at 15 registers (10 variables in 9 slots padded to 16, 64 B per thread, 9 reloads and 9 stores); it exists to show spilled code running on both backends. Each is compiled for `default`, `small` and `wide`, run on the **reference simulator** and compared with an independent Python computation on awkward geometries
(partial warps, `wg_dim = 1`, `N < wg_dim`, `n = 0`, `K = 0`, input values at INT_MIN/INT_MAX), and again with `max_regs = 4/5` (forced spills): 11 tests in `tests/test_compiler_samples.py`, all passing.

### 15.3 Test-suite (all run on the vendored reference simulator; Python 3.13)

| File | Tests | Covers |
|---|---|---|
| `test_compiler_frontend.py` | 32 | parser, printer round trip, every unsupported-construct diagnostic, error collection, verifier (definite assignment, unreachable code), value semantics **vs the ISA ALU**, folding, interpreter |
| `test_compiler_codegen.py` | 53 | **every value operation x register/literal operands around the immediate boundaries** (637 expressions, 16x16 operand corners, on default, wide and with forced spills), instruction selection, reconvergence shapes incl. the break rule, branch ranges, stack-depth estimate (incl. the measured peeling loop), uniformity analysis, register allocation unit tests, spilling end-to-end on 3 configs |
| `test_compiler_samples.py` | 11 | the eight sample kernels (above) |
| `test_compiler_fuzz.py` | 5 | differential fuzzing (225 programs per run by default, `SFSDK_FUZZ_N` scales it), stack-estimate soundness, `opt=False` equivalence, generator determinism |
| `test_compiler_mutation.py` | 16 | 16 deliberately broken code generators, all **killed** |
| **total** | **117** | all passing |

**Differential fuzzing.** `sfsdk/compiler/fuzz.py` generates valid, terminating, fault-free, race-free structured programs (nested if/else, bounded loops with per-thread trip counts, `break`/`break_if`/guarded breaks,
`return`, shared-memory phases separated by uniform barriers, per-thread output rows, atomic histograms with discarded results, optional high register pressure with 17-22 simultaneously live values). Each is compiled,
run on the reference simulator and **all** of memory compared with the IR interpreter. A campaign of **6000 programs** (3 configurations x `max_regs` in {15, 8, 6, 5, 4} x 400), run by the compiler's author against the reference simulator, produced **0 mismatches**
(45 skipped: a launch `require` rejected the geometry, or the compiler had warned that `small`'s stack may overflow and it did). The programs exercised: spilling in 3308, loops in 1892, barriers in 670, an `if` that breaks out
of its loop in 930, `return` in 521, atomics in 2050, `select` in 2353; 375,833 instructions in total.

**Independent re-run.** `scripts/fuzz_cross_backend.py` (written separately, fresh seeds) compiles the same generator's programs once and runs them on the reference simulator *and* the hardware model, comparing both with the IR interpreter and the two commit traces with each other: its final campaign was 6,000 programs, 0 mismatches (see `docs/VERIFICATION.md`; two earlier campaigns of that script were stopped by defects in the script itself, which are documented there).

**Mutation sanity.** 16 mutants (break rule ignored; reconvergence at the else label; `break_if` sense inverted; spill stores dropped; reload from the wrong slot; spill stride ignoring `P`; intervals shortened; liveness ignoring back
edges; `le` lowered as `lt`; `sar` as `shr`; `select` ignoring its condition; argument index off by one; a live instruction deleted by DCE; atomic operand lost; IR `sub` semantics corrupted; stack estimate ignoring divergent breaks) are each
detected, by a wrong result, a device fault, or a compile error.

### 15.4 Defects found by this testing (and fixed)

1. Spill-prologue lines had no IR line, so the emitter's `(spill)` tag fell outside a comment and the assembler rejected the file (found by the first spilling fuzz program).
2. Spill capacity was a **compile-time error** whenever the *largest possible* workgroup would not fit, although a launch may use a smaller one. It is now a launch-time `.require` plus a warning.
3. The SIMT-stack warning compared the estimate with the wrong bound and stayed silent for a program that overflowed `small`'s stack (needed 5, depth 4); and the nesting estimate itself was unsound for divergent breaks inside loops
   (section 8). Both fixed; regression tests `test_peeling_loop_really_needs_more_than_the_nesting_estimate` and `test_stack_warning_compares_against_the_architectural_bound`, mutant "stack estimate ignores divergent breaks".
4. The fuzz generator itself had bugs that the compiler correctly diagnosed or that produced hangs (loop bounds from a 32-bit parameter; "uniform loop" status lost inside nested `if` arms; loop-control variables reassigned in the body;
   iteration over Python `set`s made generated programs depend on `PYTHONHASHSEED`, so failures were not reproducible). All fixed; determinism across hash seeds is now a test.

## 16. Known limitations

* **Uniformity is flow-insensitive** (section 7): safe but can reject a valid barrier whose condition variable is reused for different purposes.
* **Stack estimate is conservative**: for kernels with a divergent `if`/`break` in a loop it reports the architectural bound, so small configurations (`small`) always get a warning for them.
* **No CSE, no scheduling, no live-range splitting**; whole-interval spilling only; parameter/builtin uses are rematerialised at each use (+1 instruction per use) unless copied into a variable.
* **`select` is 5 instructions** and normalises its condition; no `min`/`max`/`abs` operations.
* **Spilling needs shared memory**: spill area = `4*P*wg_dim`, which limits the workgroup size of spilling kernels on small-shared configurations (the compiler tells you the limit).
* **Fault-site mapping** is per instruction via the pc-to-IR-line table; there is no debug-info beyond that.
* The compiler targets SF-G1 v1 as specified in `sf-g1/`; any change to the ISA JSON is picked up for encoding limits but the *lowering patterns* (e.g. use of `sltiu` semantics) assume the v1 instruction set.
* Tested on Python 3.13 only (written for 3.9+; no third-party packages).
