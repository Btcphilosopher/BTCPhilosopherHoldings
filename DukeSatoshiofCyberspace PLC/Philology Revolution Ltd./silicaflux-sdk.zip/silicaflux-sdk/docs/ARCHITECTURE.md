# SilicaFlux SDK: architecture and design decisions

## 1. Layers

```
                    your program / bin/sfsdk
                               │
   ┌───────────────────────────┴────────────────────────────┐
   │  compile (sfsdk.compiler)   assemble / disassemble      │  toolchain      .sfir → .sfa → .sfk
   └───────────────────────────┬────────────────────────────┘
                               │ KernelImage (code + launch metadata)
   ┌───────────────────────────┴────────────────────────────┐
   │  runtime (sfsdk.runtime, memory, profile, discovery)    │  Device · Buffer · Kernel · Launch · Profiler
   └───────────────────────────┬────────────────────────────┘
                               │ Transport: BAR0 registers, BAR1 aperture, advance(), irq()
        ┌──────────────────────┼───────────────────────┐
  ReferenceTransport     HwModelTransport         LineTransport ──► any process speaking docs/11 11.4
  (functional oracle)    (cycle-level model)      (board bridge, RTL co-simulation)
```

The **Transport** is exactly the host interface of the SF-G1 specification (`sf-g1/docs/11` 11.1). Everything above it is
backend-agnostic: the runtime never reaches into a simulator. Everything below is one implementation of the specification.

## 2. Module map

| module | role |
|---|---|
| `spec.py` | loads `sf-g1/spec/*.json`; `Config` (validated parameters, `CAPS_*` registers, `CFG_HASH`), `DeviceSpec` (register map, descriptor layout, `LE_*`/`F_*` codes) |
| `isa.py` | instruction tables, `encode`, `decode`, driven only by `sf_g1_isa.json` |
| `expr.py` | integer expression evaluator (no `eval`) shared by the assembler and by kernel metadata |
| `asm.py`, `disasm.py` | assembler / disassembler (§ `docs/TOOLCHAIN.md`) |
| `binfmt.py` | `KernelImage`, `.sfk` container, launch metadata |
| `compiler/` | restricted IR → SF-G1 assembly (`docs/COMPILER.md`) |
| `transport.py` | `Transport` base class, `ReferenceTransport`, `LineTransport` |
| `hwmodel/` | cycle-level microarchitectural model (`docs/HWMODEL.md`) |
| `memory.py` | device-memory allocator with guard canaries |
| `runtime.py` | `Device`, `Buffer`, `Kernel`, `Launch`; argument validation, descriptor, queue, completion, fault decoding |
| `profile.py` | launch/transfer/sync events, derived metrics, per-instruction profile |
| `discovery.py` | backend registry, enumeration, `open_device` |
| `compare.py`, `samples.py` | run scenarios on several backends and compare |
| `conformance.py` | host-level conformance suite runnable against any transport |
| `rtl_replay.py` | sample binaries through the verified RTL blocks |
| `cli.py` | `bin/sfsdk` |
| `sf-g1/` | **vendored, unmodified** authoritative sources (spec JSON, reference simulator, docs, RTL); see `PROVENANCE.md` |

## 3. Independent implementations and what ties each to the oracle

The point of having several implementations of one specification is that disagreements are findings. None of the SDK components
below imports the reference model's corresponding component; the reference is used only as an oracle in tests.

| SDK component | independent of | cross-check |
|---|---|---|
| `spec.Config.cfg_hash`, caps | `sfg1.spec` | equal `CFG_HASH` for all configs; equal to the value the authoritative RTL flow prints |
| `isa.decode` / `encode` | `sfg1.isa` | 79,200-word decode differential; encode equality for every instruction |
| `asm` | `sfg1.asm` | byte-identical output on the example kernels (also vs golden `kernel.hex`) and on 150 random programs; same accept/reject on a malformed-source corpus |
| `disasm` | `sfg1.disasm` | round-trip of random programs and arbitrary words |
| `hwmodel` | `sfg1.device`, `sfg1.simt`, `sfg1.alu` | commit-trace digests, outputs, architectural counters and fault registers; SIMT stack vs reference stack on random command streams; conformance suite on both |
| `compiler` | the machine: compiled kernels are checked against an **IR interpreter** that never sees SF-G1 | randomised differential testing, spills forced |
| verified RTL blocks (vendored) | everything above | `rtl_replay`: decoder, ALU and SIMT stack on vectors derived from the SDK's binaries, expected values from the reference model, with negative controls |

## 4. Design decisions

**D1. Metadata lives outside the ISA.** The architecture has no notion of argument types or buffer sizes; a launch descriptor carries
eight opaque words. Argument validation therefore needs metadata the *toolchain* produces and the `.sfk` container carries. A bare
`.sfbin` is still launchable (no checks beyond count/kind). The device never sees the metadata.

**D2. Software FIFO over a one-launch device.** The device has no queue (docs/01 1.5, 06 6.2: a doorbell while BUSY is rejected). The SDK
serialises in software so applications can submit freely, and so `LE_BUSY` is unreachable through the API.

**D3. Zero-filled allocation by default.** Global memory contents after power-up are *undefined* (docs/04 4.8). The reference poisons
it, the hardware model fills it differently. Zero-fill makes programs deterministic across backends; `zero=False` exists for tests of
that very behaviour.

**D4. Guard canaries.** SF-G1 has no memory protection (an out-of-range *global* address faults only beyond `GMEM_BYTES`). Canaries are
the only way to attribute an out-of-bounds store to a buffer. They cost 128 bytes per buffer and two 64-byte reads per buffer per
launch and can be disabled (`guard=False`).

**D5. Fault handling resets the device.** `FAULTED` is only left by a soft reset, which preserves global memory (docs/08 8.3). The SDK
decodes the fault registers *first* (they are cleared by reset), then resets, so one failing launch does not poison the session.
Queued launches behind a fault are cancelled rather than run on an unknown state.

**D6. Implicit synchronisation on transfers.** The aperture is rejected while BUSY. Making that automatic keeps simple programs correct;
it is visible in the profile, and `auto_sync=False` turns it into an error.

**D7. The hardware model is a model.** The authoritative tree has RTL only for the decoder, ALU and SIMT stack; the register file, lane
execution, LSU, scheduler and core top are *planned, not written* (`sf-g1/docs/13`). The SDK's "hardware model" is therefore a new
cycle-level model that deliberately exercises every freedom the specification gives an implementation (latency, scheduling policy,
banked and coalescing memory, posted stores, differing power-up contents, a different EG placement policy). It is not RTL and carries no
timing, area or power claim about silicon.

**D8. Honest comparison.** Trace digests are compared only where the specification says they must agree (race-free kernels, atomics that
discard their result). A kernel that keeps an `atomadd` result is reported as "not comparable" rather than silently passing.

## 5. What is deliberately not here

No floating point (the base ISA has none; a separate FPX extension exists in the repository and is not targeted), no multi-dimensional
grids, no streams/events beyond the in-order FIFO, no concurrent launches, no unified or virtual memory, no peer-to-peer. No
compatibility layer for any existing GPU language or API exists or is claimed.
