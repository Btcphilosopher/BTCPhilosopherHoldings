# SilicaFlux SDK: runtime guide

The runtime (`sfsdk.runtime`, `sfsdk.discovery`) is the host side of the SF-G1 programming sequence
(`sf-g1/docs/07` 7.7, `11`). Every code block below is executed by `tests/test_docs_examples.py`, so the examples are
checked against the real API.

> **Scope and non-claims.** SF-G1 is an original architecture. The SDK is not compatible with, and has not been
> checked against, CUDA, OpenCL, Vulkan, HIP, SYCL, Metal or any other existing GPU language, API or ISA. Names such as
> *warp*, *lane*, *workgroup* have the meanings defined in `sf-g1/docs/01-terminology.md` and nowhere else.

## 1. Execution model of the SDK

* A device runs **one launch at a time** and has **no queue** (`docs/01` 1.5). `Kernel.submit()` therefore puts the
  launch in a small *software* FIFO and the SDK starts the next one when the previous finishes.
* The backends in this repository are **simulators**. Simulated time only passes inside `wait`, `poll` and
  `synchronize`; a device never "runs in the background" between your calls.
* The host aperture (global-memory access) is closed while the device is `BUSY`. By default the SDK
  **synchronises implicitly** before any transfer (recorded in the profile as an `implicit-*` sync); open the device with
  `auto_sync=False` to get a `DeviceBusy` error instead.
* After a fault the SDK reads and decodes the fault registers, then soft-resets the device (global memory is preserved by a
  soft reset), so the `Device` object stays usable. Queued launches behind a failed one are **cancelled**, never run.

## 2. Device enumeration

```python
import sfsdk
for info in sfsdk.enumerate_devices():
    print(info.line())
dev = sfsdk.open_device("reference:default")      # also: open_device(0), open_device("hwmodel:wide"), open_device(backend=..., config=...)
assert dev.info.version == "1.0.0" and dev.info.lanes == 8
```

`enumerate_devices()` instantiates every (backend, configuration) pair and lists **what the device reports in its own
registers** (`ID`, `VERSION`, `CFG_HASH`, `CAPS_*`), not what the SDK assumes. Built-in backends:

| backend | what it is |
|---|---|
| `reference` | the functional reference simulator of the SF-G1 tree: the architectural oracle, zero-latency memory |
| `hwmodel` | the SDK's cycle-level microarchitectural model (a *model*, not RTL; see `docs/HWMODEL.md`) |

Opening a device performs the bring-up of `docs/07` 7.7: wait for `STATUS.READY`, check `ID`, the major version, that `CAPS_*`
agree with the configuration, and that `CFG_HASH` equals the hash of the specification this SDK was built from. A mismatch
raises `DeviceMismatch` ("software built for a different configuration is caught at run time, not by wrong results").
Other implementations (a board bridge, an RTL co-simulation) attach through `register_backend` or
`register_line_device` (the line protocol of `docs/11` 11.4).

## 3. Buffer allocation

```python
buf = dev.alloc(64, name="scratch")              # 64-byte aligned, ZERO-FILLED by default
assert buf.read_words() == [0] * 16
words = dev.alloc_words([1, 2, 3, 4], name="in")  # allocate + upload
assert (words.addr % 64, words.nbytes, words.nwords) == (0, 16, 4)
assert dev.memory_info()["live_blocks"] >= 3      # descriptor + the two buffers
buf.free()
```

* **Zero-fill is the default** because device memory powers up with implementation-defined contents (the reference
  poisons it with `0xDEADBEEF`, the hardware model with a different pattern). A kernel that reads uninitialised memory is
  not portable; pass `zero=False` to see the raw contents.
* The allocator is first-fit with coalescing on free; `[0, 0x100)` is never allocated (an SDK null-pointer convention, not an
  architectural rule: the architecture treats address 0 as valid).
* With `guard=True` (default) every buffer is surrounded by 64-byte **guard canaries** that are verified after every launch.
  SF-G1 has no memory protection, so this is the SDK's only defence against a kernel that stores outside its buffer:
  you get `BufferCorrupted` naming the buffer and how far past the end the store landed.

## 4. Host/device transfers

```python
buf = dev.alloc(16)
buf.write_words([10, 20, -1, 0x80000000])
assert buf.read_words() == [10, 20, 0xFFFFFFFF, 0x80000000]
assert buf.read_i32() == [10, 20, -1, -(1 << 31)]
buf.write(b"\x07\x00\x00\x00", offset=4)           # bytes are fine too (little-endian words)
assert buf.read_words(2) == [10, 7]
```

Transfers are bounds-checked against the buffer (or, for raw addresses, against one live allocation), word-checked
(integers must fit 32 bits; `bool`/`float` are rejected) and 4-byte aligned. The aperture is byte-addressable, but
kernels access whole words only.

## 5. Kernel loading

```python
SCALE = """
.kernel scale
.arg ptr  src r n            ; global pointer, the kernel reads it, at least n words
.arg ptr  dst w n            ; global pointer, the kernel writes it
.arg u32  n
.arg u32  factor
    rdsr  r1, SR_GTID
    rdsr  r2, SR_ARG2
    slt   r3, r1, r2
    bz    r3, done, done
    shli  r4, r1, 2
    rdsr  r5, SR_ARG0
    add   r5, r5, r4
    ldg   r6, [r5]
    rdsr  r7, SR_ARG3
    mul   r6, r6, r7
    rdsr  r5, SR_ARG1
    add   r5, r5, r4
    stg   r6, [r5]
done:
    exit
"""
k = dev.load_kernel(sfsdk.assemble(SCALE, "scale.sfa"))
assert k.name == "scale" and k.num_words == 14
assert k.diagnostics == []                         # static checks passed
```

`load_kernel` accepts a `KernelImage`, a `Program`, bytes, or a path: `.sfk` (the SDK container), `.sfbin` (raw words),
`.sfa` (assembled on the fly) or `.sfir` (compiled on the fly). The image is copied into device memory once and
analysed statically: illegal words, branch targets or reconvergence addresses outside the image, a last instruction that
can fall off the end, reads of undeclared arguments. These are *warnings* in `kernel.diagnostics` (the architecture only
faults when they execute); an image larger than the device's instruction memory, or an invalid entry, is an error.

The `.arg`, `.shared`, `.shared_per_thread` and `.require` directives (see `docs/TOOLCHAIN.md`) are the launch metadata used for
argument validation. A bare `.sfbin` has none: arguments are then passed through unchecked (at most 8 words).

## 6. Argument validation and dispatch

```python
src = dev.alloc_words(range(10), name="src")
dst = dev.alloc(40, name="dst")
r = k.launch(grid=2, wg=8, args=[src, dst, 10, 3])        # positional ...
assert dst.read_words() == [3 * i for i in range(10)]
r = k.launch(2, 8, src=src, dst=dst, n=10, factor=5)      # ... or by name
assert dst.read_words()[9] == 45
assert r.ok and r.workgroups == 2 and r.issued > 0
```

`Kernel.bind()` validates a launch completely **before anything reaches the device** and raises `ArgumentError` with a stable
`code`:

| code | checked |
|---|---|
| `E_GEOMETRY` | `grid` in `1..max_grid_dim`, `wg` in `1..lanes x warps_per_eg`, both integers |
| `E_ARG_COUNT`, `E_ARG_NAMES` | number and names of arguments (`kernel(ptr src [r], ...)` signature is shown in the message) |
| `E_ARG_KIND`, `E_ARG_RANGE` | `u32`/`i32` ranges; pointers must be a `Buffer`, `buf.at(offset)` or an address inside a live allocation; no `bool`/`float` |
| `E_ARG_POINTER`, `E_ARG_ALIGN` | an address must lie in a live buffer's payload (not a guard, not free memory) and be word aligned |
| `E_ARG_EXTENT` | the metadata extent (`.arg ptr a r n` = at least `n` words) fits in the buffer *after* the pointer |
| `E_REQUIRE` | the kernel's `.require` conditions (e.g. "wg_dim must be a power of two") |
| `E_SHARED` | shared demand `.shared + .shared_per_thread x wg` against the per-workgroup allocation |
| `E_METADATA` | a metadata expression could not be evaluated |

```python
try:
    k.launch(1, 8, [src, dst, 11, 3])                      # n = 11 but src holds 10 words
except sfsdk.ArgumentError as e:
    assert e.code == "E_ARG_EXTENT"
```

Dispatch builds the 64-byte launch descriptor, writes `LAUNCH_ADDR` and `DOORBELL` and waits. Options:
`shared=` (bytes, at least the computed demand), `smem_zero=True` (descriptor flag `SMEM_ZERO`), `watchdog=` (`WDOG_LIMIT` in
device ticks; 0 disables it), `timeout_ticks=` (host-side budget).

## 7. Synchronisation

```python
inc = dev.load_kernel(sfsdk.assemble(".kernel inc\n.arg ptr p rw 1\nrdsr r1, SR_ARG0\nldg r2, [r1]\naddi r2, r2, 1\nstg r2, [r1]\nexit\n"))
ctr = dev.alloc(4, name="ctr")
launches = [inc.submit(1, 1, [ctr]) for _ in range(5)]      # asynchronous: returns Launch handles
assert launches[-1].state in ("queued", "running")
dev.synchronize()                                            # runs the whole FIFO, in order
assert [l.state for l in launches] == ["done"] * 5 and ctr.read_words() == [5]
assert launches[2].wait().status == "done"
```

* `Launch.wait(timeout_ticks)` blocks until that launch finishes and raises its error if it failed. `Launch.poll(ticks)`
  advances a simulated device by up to `ticks` and reports whether it finished. `Device.synchronize()` waits for everything and
  raises the first error.
* Completion is detected by polling `STATUS` (default) or, with `open_device(..., wait_mode="irq")`, from the interrupt line;
  the SDK acknowledges `INT_STATUS` either way.
* `LAUNCH_ERR` is checked **before** `STATUS.FAULTED` (docs/11 11.2): it describes the most recent submission only.
* If a launch exceeds the tick budget the SDK soft-resets the device and raises `DeviceTimeout`.

## 8. Error reporting

| exception (`code`) | meaning |
|---|---|
| `ArgumentError` / `ApiError` | host misuse, detected before touching the device |
| `LaunchRejected` (`LE_*`) | the device refused the descriptor; `.name`, `.value`, `.detail` |
| `DeviceFault` (`F_*`) | a kernel faulted; `.report` is a decoded `FaultReport` |
| `BufferCorrupted` | a guard canary was overwritten (out-of-bounds kernel store) |
| `DeviceTimeout`, `DeviceBusy`, `DeviceMismatch`, `OutOfDeviceMemory` | as named |
| `AsmError`, `CompileError` | toolchain diagnostics, `.errors` lists every one with `file:line:` |

```python
bad = dev.load_kernel(sfsdk.assemble("; kernel with a bug\naddi r1, r0, 6\nldg r2, [r1]\nexit\n", "bug.sfa"))
try:
    bad.launch(1, 1)
except sfsdk.DeviceFault as e:
    rep = e.report
    assert rep.name == "F_GMEM_ALIGN" and rep.regs["DATA"] == 6 and rep.regs["PC"] == 1
    assert rep.insn_text == "ldg r2, [r1]" and rep.source_line == 3
    print(e)
assert not dev.status()["faulted"]                          # the SDK reset the device; memory survived
```

A fault report contains the fault code and `FAULT_*` registers, the decoded location (EG, warp slot, lane), the **disassembled
faulting instruction** and its **source line** (from the kernel's line table), and a plain-language meaning, which for address
faults says where the address falls relative to your buffers ("12 bytes past the end of buffer 'dst'").
Faults are precise (docs/08): the faulting instruction has no effect, but memory written by *other* warps earlier is
unspecified, so treat all outputs of a faulted launch as invalid.

## 9. Profiling

```python
r = k.launch(2, 8, [src, dst, 10, 3])
prof = dev.profiler
ev = prof.launches[-1]
assert ev.kernel == "scale" and 0 < ev.simt_efficiency <= 1 and ev.ticks == r.ticks
print(prof.report())
```

Every launch records device ticks (`PERF_CYCLES`), warp instructions, lane operations, **SIMT efficiency**
(`lane_ops / (warp_instructions x lanes)`), IPC and issue-slot utilisation; transfers record bytes and host time; syncs are
counted. Two clocks are reported and must not be confused: *device ticks* belong to the backend and are **not comparable across
backends**; *host seconds* measure the simulator, not silicon. Architectural counters (`warp_instructions`, `lane_ops`) are
comparable for race-free kernels (`docs/07` 7.6).

With `open_device(..., keep_trace=True)` the commit trace is kept and `result.instruction_profile()` gives per-instruction
execution counts, average active lanes and the active-lane histogram, mapped back to source lines. Backends can add counters
(`result.counters`; the hardware model reports bank conflicts, memory-queue depth, stall reasons, ...).

## 10. Limits worth knowing

* One dimension of grid and workgroup only; `wg <= lanes x warps_per_eg`; a workgroup lives on one execution group.
* Shared memory per workgroup is `smem_bytes_per_eg / wg_slots_per_eg` (4096 B on `default`), whatever the kernel uses.
* There is exactly one atomic (`atomadd`, global) and no atomics on shared memory.
* The SDK never gives a launch more than one doorbell at a time; `LE_BUSY` therefore cannot occur through this API.
