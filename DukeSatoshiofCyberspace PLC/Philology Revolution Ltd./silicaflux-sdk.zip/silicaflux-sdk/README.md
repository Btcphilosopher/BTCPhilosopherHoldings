# SilicaFlux SDK for SF-G1

A userspace programming system for **SilicaFlux SF-G1**, the original educational SIMT architecture specified in
`sf-g1/` (35 fixed-width instructions, 16 x 32-bit registers per thread, explicit reconvergence stack, one atomic).

> **Non-claims.** SF-G1 is **not** compatible with, derived from, or a subset of CUDA, OpenCL, Vulkan, HIP, SYCL, Metal or any
> other existing GPU language, API, ISA or driver interface, and this SDK implements none of them. No conformance to any such
> standard has been attempted or is claimed. The words *warp*, *lane* and *workgroup* mean what `sf-g1/docs/01-terminology.md`
> defines and nothing else.

## What is in the box

| capability | where | doc |
|---|---|---|
| Device enumeration, buffer allocation, host/device transfers, kernel loading, argument validation, dispatch, synchronisation, error reporting, profiling | `sfsdk/runtime.py` `memory.py` `profile.py` `discovery.py` | [docs/SDK.md](docs/SDK.md) |
| Assembler and disassembler driven by the authoritative ISA JSON; `.sfk` kernel container | `sfsdk/asm.py` `disasm.py` `isa.py` `binfmt.py` | [docs/TOOLCHAIN.md](docs/TOOLCHAIN.md) |
| Compiler from a restricted IR to SF-G1: straight-line integer code, structured branches, shared memory; register allocation with spilling | `sfsdk/compiler/` | [docs/COMPILER.md](docs/COMPILER.md) |
| Sample kernels: vector add, histograms (global atomic; privatised), reductions (sum; two-pass signed max), matrix multiply (naive; shared-memory), and a register-spilling demo | `kernels/*.sfir`, binaries in `kernels/build/` | [docs/COMPILER.md](docs/COMPILER.md) |
| **The same binaries** on the reference simulator and the hardware model, outputs compared | `sfsdk/compare.py` `samples.py`, `bin/sfsdk compare` | [docs/VERIFICATION.md](docs/VERIFICATION.md) |
| Hardware model: cycle-level microarchitectural model | `sfsdk/hwmodel/` | [docs/HWMODEL.md](docs/HWMODEL.md) |
| Host-level conformance suite runnable against any backend | `sfsdk/conformance.py` | [docs/HWMODEL.md](docs/HWMODEL.md) |
| Sample binaries through the *real* verified RTL blocks (decoder, ALU, SIMT stack) under Icarus Verilog | `sfsdk/rtl_replay.py` | [docs/VERIFICATION.md](docs/VERIFICATION.md) |
| Design decisions, module map, what is independent of what | | [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) |
| Vendored, **unmodified** authoritative sources and where they came from | `sf-g1/`, `PROVENANCE.md` | |

## Quick start

Python 3 standard library only (tested on 3.13 only). `make rtl` additionally needs Icarus Verilog 12.

```bash
make test                       # every test
bin/sfsdk devices               # enumerate (reference and hardware model, 3 configurations each)
bin/sfsdk samples run           # the samples on the reference simulator, checked against host-computed results
bin/sfsdk compare               # the SAME binaries on reference and hardware model, all configurations
bin/sfsdk conformance           # host-level conformance of both backends
bin/sfsdk rtl-replay            # the binaries' instructions/ALU ops/divergence streams through the verified RTL
make fuzz PER_CELL=100          # random programs: IR interpreter vs reference vs hardware model
python3 scripts/gen_report.py   # regenerate reports/VERIFICATION_REPORT.md with freshly measured numbers
```

```python
import sfsdk
dev = sfsdk.open_device("reference:default")                  # or "hwmodel:default"
a, b = dev.alloc_words(range(100)), dev.alloc_words([7] * 100)
c = dev.alloc(400)
k = dev.load_kernel("kernels/vecadd.sfir")                    # compiled on the fly; .sfa/.sfk/.sfbin also accepted
r = k.launch(grid=4, wg=32, args=[a, b, c, 100])              # validated against the kernel's declared signature
assert c.read_words() == [i + 7 for i in range(100)]
print(r.ticks, r.simt_efficiency)
```

## Status: what is and is not established

* **Established (by running it):** the SDK's runtime, toolchain and compiler behave as documented; compiled binaries produce the
  host-computed results on the reference simulator *and* on the hardware model, with identical per-warp commit traces and
  architectural counters, on three configurations; the real decoder/ALU/SIMT-stack RTL agree with the reference model on those binaries.
  Figures: [reports/VERIFICATION_REPORT.md](reports/VERIFICATION_REPORT.md).
* **The "hardware model" is a model.** The authoritative SF-G1 tree has RTL only for the decoder, ALU and SIMT stack; its register file,
  lane execution, load/store unit, scheduler and core top are *planned, not written*. There is therefore **no complete SF-G1 RTL device**
  to run binaries on. The SDK's hardware model is a new Python cycle-level model that exercises every freedom the specification allows an
  implementation (latency, scheduling policy, banked/coalescing memory, posted stores, different power-up contents, different workgroup
  placement). It is not RTL, not synthesisable, and carries no timing, area or power claim about silicon.
* **Findings about the authoritative tree** (it is vendored unmodified; details in [docs/VERIFICATION.md](docs/VERIFICATION.md) section 4):
  the reference simulator's commit trace mis-records the operand of `atomadd rX, [rA], rX` (destination = addend register; memory contents are right),
  and docs 08/01 leave unclear whether reset duration is architectural. Neither affects the sample kernels.
* **Not hardware-validated.** Nothing here has run on silicon or an FPGA.
* Agreement is checked on **race-free** kernels; racy kernels have implementation-dependent results by definition.
* One-dimensional grids and workgroups, 32-bit integers only, one atomic (`atomadd`, global), no shared-memory atomics, no divide.
  See "unsupported constructs" in [docs/COMPILER.md](docs/COMPILER.md).
* No license file is included (the vendored tree states the same); add one before publishing.

## Layout

```
sfsdk/            the SDK package            sf-g1/        vendored authoritative tree (unmodified)
kernels/          sample IR + built binaries  docs/         guides and references
tests/            all tests                   reports/      generated verification report
bin/sfsdk         command line               scripts/      packaging and report generation
```
