// sf-conformance: alu
// SF-G1 per-lane integer ALU.  Purely combinational.
// Reference model: sim/sfg1/alu.py (functions selected by the alu_fn field of the decoded record).
// alu_fn codes 12..15 are never produced by the decoder; the result for them is 0.
module sf_g1_alu
  import sf_g1_pkg::*;
(
  input  logic [3:0]  fn,
  input  logic [31:0] a,
  input  logic [31:0] b,
  output logic [31:0] y
);
  logic signed [31:0] sa, sb;
  logic        [63:0] prod;
  logic        [31:0] prod_lo;
  logic        [4:0]  sh;

  assign sa   = a;
  assign sb   = b;
  assign prod = {32'd0, a} * {32'd0, b};
  assign prod_lo = prod[31:0];
  assign sh   = b[4:0];

  always_comb begin
    case (fn)
      ALU_ADD:   y = a + b;
      ALU_SUB:   y = a - b;
      ALU_MUL:   y = prod_lo;
      ALU_AND:   y = a & b;
      ALU_OR:    y = a | b;
      ALU_XOR:   y = a ^ b;
      ALU_SHL:   y = a << sh;
      ALU_SHR:   y = a >> sh;
      ALU_SAR:   y = sa >>> sh;
      ALU_SLT:   y = {31'd0, sa < sb};
      ALU_SLTU:  y = {31'd0, a < b};
      ALU_PASSB: y = b;
      default:   y = 32'd0;
    endcase
  end
endmodule
