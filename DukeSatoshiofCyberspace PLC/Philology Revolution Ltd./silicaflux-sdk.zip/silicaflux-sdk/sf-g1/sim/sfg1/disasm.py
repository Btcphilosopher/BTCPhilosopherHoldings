"""SF-G1 disassembler.  Output re-assembles to the same words (round-trip tested)."""
from __future__ import annotations

from typing import List, Optional, Sequence

from .isa import isa
from .spec import MASK32


def _s(x: int, bits: int) -> int:
    return x - (1 << bits) if x >> (bits - 1) else x


def disassemble_word(word: int, pc: int = 0, labels: Optional[dict] = None) -> str:
    I = isa()
    d = I.decode(word)
    if d.illegal:
        return f".word 0x{word & MASK32:08x}"
    ins = I.by_mnemonic[d.mnemonic]
    f = I.field_values(word)
    labels = labels or {}

    def lab(a: int) -> str:
        return labels.get(a, str(a))

    parts: List[str] = []
    for tok in ins.syntax:
        if tok in ("rd", "rs1", "rs2"):
            parts.append(f"r{f[tok]}")
        elif tok == "imm":
            parts.append(str(f["imm"]))
        elif tok == "sr":
            parts.append(I.sr_names[f["imm"]])
        elif tok == "mem":
            off = f["imm"]
            parts.append(f"[r{f['rs1']}]" if off == 0 else f"[r{f['rs1']} {'+' if off > 0 else '-'} {abs(off)}]")
        elif tok == "memr":
            parts.append(f"[r{f['rs1']}]")
        elif tok == "target":
            parts.append(lab(pc + f["imm"]))
        elif tok == "reconv":
            parts.append(lab(pc + f["imm2"]))
    return (ins.mnemonic + (" " + ", ".join(parts) if parts else "")).strip()


def disassemble(words: Sequence[int], with_addresses: bool = False) -> str:
    I = isa()
    targets = set()
    for pc, w in enumerate(words):
        d = I.decode(w)
        if d.illegal:
            continue
        ins = I.by_mnemonic[d.mnemonic]
        f = I.field_values(w)
        if "target" in ins.syntax:
            targets.add(pc + f["imm"])
        if "reconv" in ins.syntax:
            targets.add(pc + f["imm2"])
    labels = {a: f"L{a:04x}" for a in sorted(targets) if 0 <= a < len(words)}
    out = []
    for pc, w in enumerate(words):
        if pc in labels:
            out.append(f"{labels[pc]}:")
        text = disassemble_word(w, pc, labels)
        out.append(f"    {text}" if not with_addresses else f"    {pc:04x}: {w:08x}  {text}")
    return "\n".join(out) + "\n"
