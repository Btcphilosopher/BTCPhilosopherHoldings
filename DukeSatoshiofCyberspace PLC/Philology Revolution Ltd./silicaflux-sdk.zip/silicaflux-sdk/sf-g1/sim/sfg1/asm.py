"""SF-G1 assembler.

Two-pass assembler producing a flat word image (instruction index == word
index, which is the architectural PC).  Syntax is documented in
docs/10-assembler.md.  Instruction forms come from spec/sf_g1_isa.json.
"""
from __future__ import annotations

import re
import struct
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .isa import isa, Insn
from .spec import MASK32


class AsmError(Exception):
    """Raised with every diagnostic collected during assembly."""

    def __init__(self, errors: List[str]) -> None:
        super().__init__("\n".join(errors))
        self.errors = errors


@dataclass
class AsmResult:
    words: List[int]
    labels: Dict[str, int]
    equs: Dict[str, int]
    listing: List[str]
    warnings: List[str]
    source_lines: Dict[int, int] = field(default_factory=dict)  # pc -> source line number

    def to_bytes(self) -> bytes:
        return struct.pack(f"<{len(self.words)}I", *self.words)

    def to_hex(self) -> str:
        return "".join(f"{w:08x}\n" for w in self.words)

    def symbols(self) -> Dict[str, Dict[str, int]]:
        return {"labels": dict(self.labels), "equ": dict(self.equs)}


# --------------------------------------------------------------------------
# Expression evaluator (no eval): ints, symbols, unary - ~ +, binary
# * / % + - << >> & ^ |, parentheses, %hi(x) and %lo(x).
# --------------------------------------------------------------------------
_TOKEN = re.compile(
    r"\s*(?:(?P<num>0[xX][0-9a-fA-F_]+|0[bB][01_]+|\d[\d_]*)"
    r"|(?P<sym>%?[A-Za-z_.$][\w.$]*)"
    r"|(?P<op><<|>>|[-+*/%&|^~()]))"
)


class ExprError(Exception):
    pass


class _Expr:
    PREC = {"|": 1, "^": 2, "&": 3, "<<": 4, ">>": 4, "+": 5, "-": 5, "*": 6, "/": 6, "%": 6}

    def __init__(self, text: str, symbols: Dict[str, int]) -> None:
        self.text = text
        self.symbols = symbols
        self.toks: List[Tuple[str, str]] = []
        pos = 0
        text = text.strip()
        while pos < len(text):
            m = _TOKEN.match(text, pos)
            if not m or m.end() == pos:
                raise ExprError(f"bad character {text[pos:pos+1]!r} in expression '{self.text}'")
            pos = m.end()
            kind = m.lastgroup
            self.toks.append((kind, m.group(kind)))
        self.i = 0

    def peek(self) -> Optional[Tuple[str, str]]:
        return self.toks[self.i] if self.i < len(self.toks) else None

    def take(self) -> Tuple[str, str]:
        t = self.peek()
        if t is None:
            raise ExprError(f"unexpected end of expression '{self.text}'")
        self.i += 1
        return t

    def parse(self) -> int:
        if not self.toks:
            raise ExprError("empty expression")
        v = self.binary(0)
        if self.peek() is not None:
            raise ExprError(f"unexpected '{self.peek()[1]}' in expression '{self.text}'")
        return v

    def binary(self, min_prec: int) -> int:
        lhs = self.unary()
        while True:
            t = self.peek()
            if t is None or t[0] != "op" or t[1] not in self.PREC or self.PREC[t[1]] < min_prec:
                return lhs
            op = self.take()[1]
            rhs = self.binary(self.PREC[op] + 1)
            if op in ("/", "%") and rhs == 0:
                raise ExprError("division by zero")
            lhs = {
                "|": lambda a, b: a | b, "^": lambda a, b: a ^ b, "&": lambda a, b: a & b,
                "<<": lambda a, b: a << b, ">>": lambda a, b: a >> b,
                "+": lambda a, b: a + b, "-": lambda a, b: a - b, "*": lambda a, b: a * b,
                "/": lambda a, b: int(a / b) if (a < 0) != (b < 0) else a // b,
                "%": lambda a, b: a - b * (int(a / b) if (a < 0) != (b < 0) else a // b),
            }[op](lhs, rhs)

    def unary(self) -> int:
        kind, val = self.take()
        if kind == "op":
            if val == "-":
                return -self.unary()
            if val == "+":
                return self.unary()
            if val == "~":
                return ~self.unary()
            if val == "(":
                v = self.binary(0)
                if self.take() != ("op", ")"):
                    raise ExprError("missing ')'")
                return v
            raise ExprError(f"unexpected '{val}' in expression '{self.text}'")
        if kind == "num":
            return int(val.replace("_", ""), 0)
        # symbol or %hi/%lo
        if val.lower() in ("%hi", "%lo"):
            if self.take() != ("op", "("):
                raise ExprError(f"{val} needs '('")
            v = self.binary(0)
            if self.take() != ("op", ")"):
                raise ExprError("missing ')'")
            return (v & MASK32) >> 10 if val.lower() == "%hi" else (v & 0x3FF)
        if val not in self.symbols:
            raise ExprError(f"undefined symbol '{val}'")
        return self.symbols[val]


def evaluate(text: str, symbols: Dict[str, int]) -> int:
    return _Expr(text, symbols).parse()


# --------------------------------------------------------------------------
_REG = re.compile(r"^(?:r(\d{1,2})|zero)$", re.IGNORECASE)
_IDENT = re.compile(r"^[A-Za-z_.$][\w.$]*$")
_LABEL = re.compile(r"^\s*([A-Za-z_.$][\w.$]*)\s*:")


def _split_operands(s: str) -> List[str]:
    out, depth, cur = [], 0, []
    for ch in s:
        if ch in "([":
            depth += 1
        elif ch in ")]":
            depth -= 1
        if ch == "," and depth == 0:
            out.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    tail = "".join(cur).strip()
    if tail or out:
        out.append(tail)
    return out


def _strip_comment(line: str) -> str:
    for marker in (";", "//"):
        i = line.find(marker)
        if i >= 0:
            line = line[:i]
    return line.strip()


@dataclass
class _Stmt:
    line: int
    text: str
    kind: str            # "insn" | "word" | "li"
    mnemonic: str = ""
    operands: List[str] = field(default_factory=list)
    pc: int = 0
    size: int = 1


class Assembler:
    def __init__(self, num_regs: int = 16) -> None:
        self.isa = isa()
        self.num_regs = num_regs
        self.errors: List[str] = []
        self.warnings: List[str] = []

    # ------------------------------------------------------------------
    def assemble(self, source: str, filename: str = "<asm>") -> AsmResult:
        self.filename = filename
        self.errors = []
        self.warnings = []
        self.symbols: Dict[str, int] = dict(self.isa.special_registers)
        self.labels: Dict[str, int] = {}
        self.equs: Dict[str, int] = {}
        self.regalias: Dict[str, int] = {}
        stmts = self._pass1(source)
        words, listing, srcmap = self._pass2(stmts, source.splitlines())
        if self.errors:
            raise AsmError(self.errors)
        return AsmResult(words, self.labels, self.equs, listing, self.warnings, srcmap)

    def _err(self, line: int, msg: str) -> None:
        self.errors.append(f"{self.filename}:{line}: error: {msg}")

    def _warn(self, line: int, msg: str) -> None:
        self.warnings.append(f"{self.filename}:{line}: warning: {msg}")

    # ------------------------------------------------------------------
    def _define(self, name: str, value: int, line: int, is_label: bool) -> None:
        if name in self.symbols and name not in self.isa.special_registers:
            self._err(line, f"symbol '{name}' already defined")
            return
        if name in self.isa.special_registers:
            self._err(line, f"'{name}' is a reserved special-register name")
            return
        if _REG.match(name) or name.lower() in self.isa.by_mnemonic:
            self._err(line, f"'{name}' conflicts with a register or mnemonic")
            return
        self.symbols[name] = value
        (self.labels if is_label else self.equs)[name] = value

    def _pass1(self, source: str) -> List[_Stmt]:
        stmts: List[_Stmt] = []
        pc = 0
        for lineno, raw in enumerate(source.splitlines(), start=1):
            text = _strip_comment(raw)
            while True:
                m = _LABEL.match(text)
                if not m:
                    break
                self._define(m.group(1), pc, lineno, True)
                text = text[m.end():].strip()
            if not text:
                continue
            head, _, rest = text.partition(" ")
            if "\t" in head:
                head, _, rest2 = text.partition("\t")
                rest = rest2
            head_l = head.lower()
            ops = _split_operands(rest.strip())
            if head_l in (".equ", ".set"):
                if len(ops) != 2 or not _IDENT.match(ops[0]):
                    self._err(lineno, f"{head_l} needs NAME, expr")
                    continue
                try:
                    self._define(ops[0], evaluate(ops[1], self.symbols), lineno, False)
                except ExprError as e:
                    self._err(lineno, str(e))
                continue
            if head_l == ".reg":
                if len(ops) != 2 or not _IDENT.match(ops[0]) or not _REG.match(ops[1]):
                    self._err(lineno, ".reg needs NAME, rN")
                    continue
                self.regalias[ops[0]] = self._regnum(ops[1], lineno)
                continue
            if head_l == ".word":
                if not ops or ops == [""]:
                    self._err(lineno, ".word needs at least one value")
                    continue
                st = _Stmt(lineno, text, "word", head_l, ops, pc, len(ops))
                stmts.append(st)
                pc += st.size
                continue
            if head_l.startswith("."):
                self._err(lineno, f"unknown directive '{head}'")
                continue
            st = self._classify(lineno, text, head_l, ops, pc)
            if st is not None:
                stmts.append(st)
                pc += st.size
        return stmts

    def _classify(self, lineno: int, text: str, mnem: str, ops: List[str], pc: int) -> Optional[_Stmt]:
        if mnem in ("li", "la"):
            if len(ops) != 2:
                self._err(lineno, f"{mnem} needs rd, expr")
                return None
            size = 2
            try:
                v = evaluate(ops[1], self.symbols)
                size = len(self._li_plan(v))
            except ExprError:
                pass  # forward reference: reserve two words
            return _Stmt(lineno, text, "li", mnem, ops, pc, size)
        if mnem in ("mov", "neg", "not", "sgt", "sgtu", "j"):
            expect = {"mov": 2, "neg": 2, "not": 2, "sgt": 3, "sgtu": 3, "j": 1}[mnem]
            if len(ops) != expect:
                self._err(lineno, f"{mnem} needs {expect} operand(s)")
                return None
            return _Stmt(lineno, text, "insn", mnem, ops, pc, 1)
        if mnem not in self.isa.by_mnemonic:
            self._err(lineno, f"unknown mnemonic '{mnem}'")
            return None
        if ops == [""]:
            ops = []
        return _Stmt(lineno, text, "insn", mnem, ops, pc, 1)

    @staticmethod
    def _li_plan(v: int) -> List[Tuple[str, int]]:
        if not -(1 << 31) <= v <= MASK32:
            raise ExprError(f"constant {v} does not fit in 32 bits")
        u = v & MASK32
        s = u - (1 << 32) if u & 0x80000000 else u
        if -(1 << 17) <= s < (1 << 17):
            return [("addi", s)]
        if u & 0x3FF == 0:
            return [("lui", u >> 10)]
        return [("lui", u >> 10), ("ori", u & 0x3FF)]

    # ------------------------------------------------------------------
    def _regnum(self, tok: str, line: int) -> int:
        t = tok.strip()
        if t in self.regalias:
            return self.regalias[t]
        if t.lower() == "zero":
            return 0
        m = _REG.match(t)
        if not m or m.group(1) is None:
            raise ExprError(f"expected a register, found '{tok}'")
        n = int(m.group(1))
        if n >= self.num_regs:
            raise ExprError(f"register r{n} does not exist (r0..r{self.num_regs - 1})")
        return n

    def _imm(self, tok: str) -> int:
        return evaluate(tok, self.symbols)

    def _parse_mem(self, tok: str, allow_offset: bool) -> Tuple[int, int]:
        t = tok.strip()
        if not (t.startswith("[") and t.endswith("]")):
            raise ExprError(f"expected a memory operand [rN + imm], found '{tok}'")
        inner = t[1:-1].strip()
        m = re.match(r"^([A-Za-z_]\w*)\s*(.*)$", inner)
        if not m:
            raise ExprError(f"bad memory operand '{tok}'")
        base = self._regnum(m.group(1), 0)
        rest = m.group(2).strip()
        off = 0
        if rest:
            if not allow_offset:
                raise ExprError("this instruction takes [rN] with no offset")
            if rest[0] not in "+-":
                raise ExprError(f"expected '+' or '-' after base register in '{tok}'")
            off = evaluate(rest, self.symbols)
        return base, off

    # ------------------------------------------------------------------
    def _pass2(self, stmts: List[_Stmt], lines: List[str]):
        words: List[int] = []
        listing: List[str] = []
        srcmap: Dict[int, int] = {}
        for st in stmts:
            try:
                emitted = self._emit(st)
            except (ExprError, ValueError) as e:
                self._err(st.line, f"{st.mnemonic}: {e}")
                emitted = [0] * st.size
            if len(emitted) != st.size:  # keeps later addresses consistent after an error
                emitted = (emitted + [0] * st.size)[: st.size]
            for k, w in enumerate(emitted):
                srcmap[st.pc + k] = st.line
                listing.append(f"{st.pc + k:04x}: {w:08x}  {lines[st.line - 1].rstrip() if k == 0 else ''}".rstrip())
            words.extend(emitted)
        return words, listing, srcmap

    def _emit(self, st: _Stmt) -> List[int]:
        I = self.isa
        if st.kind == "word":
            out = []
            for op in st.operands:
                v = evaluate(op, self.symbols)
                if not -(1 << 31) <= v <= MASK32:
                    raise ExprError(f".word value {v} does not fit in 32 bits")
                out.append(v & MASK32)
            return out
        if st.kind == "li":
            rd = self._regnum(st.operands[0], st.line)
            v = evaluate(st.operands[1], self.symbols)
            plan = self._li_plan(v)
            if len(plan) > st.size:
                raise ExprError("internal: li grew between passes")
            words: List[int] = []
            for k, (m, imm) in enumerate(plan):
                if m == "addi":
                    words.append(I.encode("addi", rd=rd, rs1=0, imm=imm))
                elif m == "lui":
                    words.append(I.encode("lui", rd=rd, imm=imm))
                else:
                    words.append(I.encode("ori", rd=rd, rs1=rd, imm=imm))
            while len(words) < st.size:  # forward-referenced li whose value turned out short
                if len(plan) == 1 and plan[0][0] == "addi":
                    words.append(I.encode("nop"))
                else:
                    words.append(I.encode("nop"))
            return words
        m, ops = st.mnemonic, st.operands
        if m == "mov":
            return [I.encode("addi", rd=self._regnum(ops[0], st.line), rs1=self._regnum(ops[1], st.line), imm=0)]
        if m == "neg":
            return [I.encode("sub", rd=self._regnum(ops[0], st.line), rs1=0, rs2=self._regnum(ops[1], st.line))]
        if m == "not":
            return [I.encode("xori", rd=self._regnum(ops[0], st.line), rs1=self._regnum(ops[1], st.line), imm=-1)]
        if m in ("sgt", "sgtu"):
            base = "slt" if m == "sgt" else "sltu"
            return [I.encode(base, rd=self._regnum(ops[0], st.line),
                             rs1=self._regnum(ops[2], st.line), rs2=self._regnum(ops[1], st.line))]
        if m == "j":
            m, ops = "bra", ops
        ins = I.by_mnemonic[m]
        return [self._encode_insn(ins, ops, st)]

    def _encode_insn(self, ins: Insn, ops: List[str], st: _Stmt) -> int:
        syn = ins.syntax
        if len(ops) != len(syn):
            raise ValueError(f"expected {len(syn)} operand(s) ({', '.join(syn)}), got {len(ops)}")
        f = {"rd": 0, "rs1": 0, "rs2": 0, "imm": 0, "imm2": 0}
        target = reconv = None
        for tok, op in zip(syn, ops):
            if tok in ("rd", "rs1", "rs2"):
                f[tok] = self._regnum(op, st.line)
            elif tok == "imm":
                f["imm"] = self._imm(op)
            elif tok == "sr":
                f["imm"] = self._imm(op)
            elif tok == "mem":
                f["rs1"], f["imm"] = self._parse_mem(op, True)
            elif tok == "memr":
                f["rs1"], _ = self._parse_mem(op, False)
            elif tok == "target":
                target = self._imm(op)
            elif tok == "reconv":
                reconv = self._imm(op)
            else:  # pragma: no cover
                raise ValueError(f"internal: unknown syntax token {tok}")
        pc = st.pc
        if target is not None:
            f["imm"] = target - pc
        if reconv is not None:
            if reconv <= pc:
                raise ValueError(f"reconvergence address {reconv} must be after the branch at {pc}")
            f["imm2"] = reconv - pc
            if target is not None and target > reconv:
                self._warn(st.line, f"branch target {target} is beyond its reconvergence address {reconv}; "
                                    "a divergent execution will fault with F_RECONV")
        return self.isa.encode(ins.mnemonic, **f)


def assemble(source: str, filename: str = "<asm>", num_regs: int = 16) -> AsmResult:
    return Assembler(num_regs).assemble(source, filename)


def assemble_file(path: str) -> AsmResult:
    with open(path, "r", encoding="utf-8") as fh:
        return assemble(fh.read(), path)
