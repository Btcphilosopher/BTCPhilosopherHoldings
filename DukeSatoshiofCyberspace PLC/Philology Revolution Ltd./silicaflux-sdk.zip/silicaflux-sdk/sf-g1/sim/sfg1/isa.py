"""SF-G1 instruction encoding and decoding, driven entirely by spec/sf_g1_isa.json.

``decode()`` is the reference for the generated SystemVerilog decoder
(rtl/gen/sf_g1_decode.sv): the conformance vectors compare its packed output
bit for bit.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Dict, List, Optional, Tuple

from .spec import SPEC_DIR, MASK32

INSN_BITS = 32


@dataclass(frozen=True)
class Field:
    name: str
    hi: int
    lo: int
    signed: bool = False

    @property
    def width(self) -> int:
        return self.hi - self.lo + 1

    @property
    def mask(self) -> int:
        return ((1 << self.width) - 1) << self.lo


@dataclass(frozen=True)
class Format:
    name: str
    fields: Dict[str, Field]
    reserved_mask: int  # bits [25:0] that no field uses; must be zero in a legal word


@dataclass(frozen=True)
class Insn:
    mnemonic: str
    opcode: int
    fmt: Format
    iclass: str
    iclass_code: int
    alu: str
    alu_code: int
    b_imm: bool
    reads: Tuple[str, ...]
    writes_rd: bool
    syntax: Tuple[str, ...]
    require: Tuple[str, ...]
    imm_shift: int
    doc: str
    semantics: str


@dataclass(frozen=True)
class Decoded:
    """Normalised decode result (mirrors sf_decoded_t in the generated RTL)."""

    illegal: int = 0
    iclass: int = 0
    opcode: int = 0
    rd: int = 0
    rs1: int = 0
    rs2: int = 0
    rd_we: int = 0
    rs1_re: int = 0
    rs2_re: int = 0
    alu_fn: int = 0
    b_imm: int = 0
    imm: int = 0
    imm2: int = 0
    mnemonic: Optional[str] = None  # not part of the packed record

    def pack(self, layout: Optional[List[Tuple[str, int]]] = None) -> int:
        layout = layout or isa().record_layout
        v = 0
        for name, width in layout:
            val = getattr(self, name)
            if val < 0 or val >> width:
                raise ValueError(f"field {name}={val} does not fit {width} bits")
            v = (v << width) | val
        return v


class Isa:
    def __init__(self, raw: Dict) -> None:
        self.raw = raw
        self.opcode_hi = raw["opcode"]["hi"]
        self.opcode_lo = raw["opcode"]["lo"]
        op_mask = ((1 << (self.opcode_hi - self.opcode_lo + 1)) - 1) << self.opcode_lo
        self.formats: Dict[str, Format] = {}
        for fname, f in raw["formats"].items():
            fields = {n: Field(n, d["hi"], d["lo"], d.get("signed", False)) for n, d in f["fields"].items()}
            used = 0
            for fl in fields.values():
                if used & fl.mask:
                    raise ValueError(f"format {fname}: overlapping fields")
                used |= fl.mask
            reserved = (~(used | op_mask)) & MASK32
            self.formats[fname] = Format(fname, fields, reserved)
        self.classes = {c["name"]: c["code"] for c in raw["classes"]}
        self.class_names = {v: k for k, v in self.classes.items()}
        self.alu_functions = {a["name"]: a["code"] for a in raw["alu_functions"]}
        self.alu_names = {v: k for k, v in self.alu_functions.items()}
        self.special_registers = {s["name"]: s["index"] for s in raw["special_registers"]}
        self.sr_names = {v: k for k, v in self.special_registers.items()}
        self.valid_sr = set(self.special_registers.values())
        self.record_layout: List[Tuple[str, int]] = [
            (f["name"], f["width"]) for f in raw["decoded_record"]["fields"]
        ]
        self.by_mnemonic: Dict[str, Insn] = {}
        self.by_opcode: Dict[int, Insn] = {}
        for d in raw["instructions"]:
            fmt = self.formats[d["format"]]
            alu = d.get("alu", "ADD")
            ins = Insn(
                mnemonic=d["mnemonic"],
                opcode=d["opcode"],
                fmt=fmt,
                iclass=d["class"],
                iclass_code=self.classes[d["class"]],
                alu=alu,
                alu_code=self.alu_functions[alu],
                b_imm=d.get("b_src", "rs2") == "imm",
                reads=tuple(d.get("reads", [])),
                writes_rd=bool(d.get("writes_rd", False)),
                syntax=tuple(d["syntax"]),
                require=tuple(d.get("require", [])),
                imm_shift=d.get("imm_shift", 0),
                doc=d.get("doc", ""),
                semantics=d.get("semantics", ""),
            )
            if ins.mnemonic in self.by_mnemonic or ins.opcode in self.by_opcode:
                raise ValueError(f"duplicate instruction {ins.mnemonic}/{ins.opcode}")
            self.by_mnemonic[ins.mnemonic] = ins
            self.by_opcode[ins.opcode] = ins

    # ------------------------------------------------------------------
    def encode(self, mnemonic: str, rd: int = 0, rs1: int = 0, rs2: int = 0,
               imm: int = 0, imm2: int = 0) -> int:
        """Encode raw field values (``imm`` is the field value, not shifted)."""
        ins = self.by_mnemonic[mnemonic]
        vals = {"rd": rd, "rs1": rs1, "rs2": rs2, "imm": imm, "imm2": imm2}
        word = ins.opcode << self.opcode_lo
        for name, fl in ins.fmt.fields.items():
            v = vals[name]
            if fl.signed:
                lo_lim, hi_lim = -(1 << (fl.width - 1)), (1 << (fl.width - 1)) - 1
            else:
                lo_lim, hi_lim = 0, (1 << fl.width) - 1
            if not lo_lim <= v <= hi_lim:
                raise ValueError(f"{mnemonic}: {name}={v} out of range [{lo_lim}, {hi_lim}]")
            word |= (v & ((1 << fl.width) - 1)) << fl.lo
        for name in ("rd", "rs1", "rs2", "imm", "imm2"):
            if name not in ins.fmt.fields and vals[name] != 0:
                raise ValueError(f"{mnemonic}: format {ins.fmt.name} has no {name} field")
        return word

    def decode(self, word: int) -> Decoded:
        word &= MASK32
        opcode = (word >> self.opcode_lo) & ((1 << (self.opcode_hi - self.opcode_lo + 1)) - 1)
        ins = self.by_opcode.get(opcode)
        if ins is None or (word & ins.fmt.reserved_mask):
            return Decoded(illegal=1)
        raw: Dict[str, int] = {}
        for name, fl in ins.fmt.fields.items():
            v = (word >> fl.lo) & ((1 << fl.width) - 1)
            raw[name] = v
        if "imm2_nonzero" in ins.require and raw.get("imm2", 0) == 0:
            return Decoded(illegal=1)
        if "valid_sr" in ins.require and raw.get("imm", 0) not in self.valid_sr:
            return Decoded(illegal=1)
        imm = 0
        if "imm" in ins.fmt.fields:
            fl = ins.fmt.fields["imm"]
            imm = raw["imm"]
            if fl.signed and imm >> (fl.width - 1):
                imm -= 1 << fl.width
            imm = (imm << ins.imm_shift) & MASK32
        return Decoded(
            illegal=0,
            iclass=ins.iclass_code,
            opcode=opcode,
            rd=raw.get("rd", 0),
            rs1=raw.get("rs1", 0),
            rs2=raw.get("rs2", 0),
            rd_we=int(ins.writes_rd),
            rs1_re=int("rs1" in ins.reads),
            rs2_re=int("rs2" in ins.reads),
            alu_fn=ins.alu_code,
            b_imm=int(ins.b_imm),
            imm=imm,
            imm2=raw.get("imm2", 0),
            mnemonic=ins.mnemonic,
        )

    def field_values(self, word: int) -> Dict[str, int]:
        """Raw (unshifted, unextended) field values; used by the disassembler."""
        ins = self.by_opcode[(word >> self.opcode_lo) & 0x3F]
        out = {}
        for name, fl in ins.fmt.fields.items():
            v = (word >> fl.lo) & ((1 << fl.width) - 1)
            if fl.signed and v >> (fl.width - 1):
                v -= 1 << fl.width
            out[name] = v
        return out


@lru_cache(maxsize=1)
def isa() -> Isa:
    with open(SPEC_DIR / "sf_g1_isa.json", "r", encoding="utf-8") as f:
        return Isa(json.load(f))


def decode(word: int) -> Decoded:
    return isa().decode(word)


def encode(mnemonic: str, **kw: int) -> int:
    return isa().encode(mnemonic, **kw)
