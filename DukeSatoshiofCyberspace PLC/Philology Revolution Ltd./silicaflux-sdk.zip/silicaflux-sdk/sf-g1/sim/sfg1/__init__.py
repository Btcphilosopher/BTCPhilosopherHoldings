"""SilicaFlux SF-G1 reference model: assembler, functional simulator, device model, host driver."""
__version__ = "1.0.0"
