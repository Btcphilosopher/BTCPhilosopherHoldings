"""Command-line front end: sfg1 {asm,dis,run,examples,vectors,devserver}."""
from __future__ import annotations

import argparse
import json
import re
import struct
import sys
from pathlib import Path
from typing import List

from .asm import AsmError, assemble, assemble_file
from .disasm import disassemble
from .examples import EXAMPLES, ROOT_REFERENCE, report_json, run_example
from .host import open_local
from .spec import load_config


def _load_words(path: str) -> List[int]:
    p = Path(path)
    if p.suffix == ".sfbin":
        b = p.read_bytes()
        return list(struct.unpack(f"<{len(b) // 4}I", b))
    if p.suffix == ".hex":
        return [int(x, 16) for x in p.read_text().split()]
    return assemble_file(str(p)).words


def cmd_asm(a) -> int:
    try:
        res = assemble_file(a.file)
    except AsmError as e:
        print(e, file=sys.stderr)
        return 1
    for w in res.warnings:
        print(w, file=sys.stderr)
    stem = Path(a.file).with_suffix("")
    out = Path(a.output) if a.output else stem.with_suffix(".sfbin")
    out.write_bytes(res.to_bytes())
    if a.hex:
        Path(a.hex).write_text(res.to_hex())
    if a.listing:
        Path(a.listing).write_text("\n".join(res.listing) + "\n")
    if a.symbols:
        Path(a.symbols).write_text(json.dumps(res.symbols(), indent=1, sort_keys=True) + "\n")
    print(f"{a.file}: {len(res.words)} words -> {out}")
    return 0


def cmd_dis(a) -> int:
    sys.stdout.write(disassemble(_load_words(a.file), with_addresses=a.addresses))
    return 0


def _parse_buf(spec: str) -> tuple:
    name, _, rhs = spec.partition("=")
    m = re.match(r"^(\d+)x(.+)$", rhs)
    words = [int(m.group(2), 0)] * int(m.group(1)) if m else [int(x, 0) for x in rhs.split(",") if x]
    return name, [w & 0xFFFFFFFF for w in words]


def cmd_run(a) -> int:
    cfg = load_config(a.config)
    host = open_local(cfg, trace=bool(a.trace))
    bufs = {}
    for spec in a.buf:
        name, words = _parse_buf(spec)
        addr = host.alloc(4 * len(words))
        host.write_words(addr, words)
        bufs[name] = (addr, len(words))
    k = host.load_kernel(_load_words(a.kernel))
    args = [bufs[x[1:]][0] if x.startswith("@") else int(x, 0) for x in a.arg]
    r = host.launch(k, a.grid, a.wg, a.shared, args)
    print(f"status={r.status} {r.error}".rstrip())
    print(json.dumps(r.stats(cfg.lanes)))
    if r.status == "fault":
        print("fault:", {k: f"0x{v:x}" for k, v in r.fault.items()})
    for name in a.dump:
        addr, n = bufs[name]
        words = host.read_words(addr, n)
        print(f"{name} @ 0x{addr:x}: " + " ".join(f"{w:#x}" if w > 9 else str(w) for w in words))
    if a.trace:
        host.device.trace.write_jsonl(a.trace)  # type: ignore[attr-defined]
        print(f"trace: {len(host.device.trace.events)} events, sha256 {host.device.trace.digest()}")  # type: ignore[attr-defined]
    return 0 if r.ok else 2


def _write_reference(ex, outdir: Path) -> None:
    d = outdir / ex.name
    d.mkdir(parents=True, exist_ok=True)
    (d / "report.json").write_text(report_json(ex.report))
    ex.trace.write_jsonl(str(d / "commit_trace.jsonl"))
    asm = assemble_file(str(Path(__file__).resolve().parents[2] / "examples" / "kernels" / f"{ex.name}.sfa"))
    (d / "kernel.lst").write_text("\n".join(asm.listing) + "\n")
    (d / "kernel.hex").write_text(asm.to_hex())


def cmd_examples(a) -> int:
    cfg = load_config(a.config)
    names = a.names or list(EXAMPLES)
    rc = 0
    for n in names:
        ex = run_example(n, cfg)
        s = ex.report["stats"]
        line = (f"{n:12s} {'PASS' if ex.ok else 'FAIL'}  ticks={s['ticks']:<5d} warp_insns={s['warp_instructions']:<5d} "
                f"lane_ops={s['lane_ops']:<6d} simt_eff={s['simt_efficiency']:.3f}  trace={ex.report['trace']['sha256'][:12]}")
        if not ex.ok:
            rc = 1
            line += f"  <- {ex.message or ex.result.error}"
        if a.update:
            _write_reference(ex, Path(a.reference))
        elif a.check:
            d = Path(a.reference) / n
            try:
                same = (d / "report.json").read_text() == report_json(ex.report)
                import tempfile, os
                with tempfile.TemporaryDirectory() as td:
                    ex.trace.write_jsonl(os.path.join(td, "t.jsonl"))
                    same_trace = Path(os.path.join(td, "t.jsonl")).read_text() == (d / "commit_trace.jsonl").read_text()
            except FileNotFoundError:
                same = same_trace = False
            if not (same and same_trace):
                rc = 1
                line += "  <- DIFFERS from reference"
            else:
                line += "  (matches reference)"
        print(line)
    if a.update:
        print(f"reference outputs written to {a.reference}/")
    return rc


def cmd_vectors(a) -> int:
    from .vectors import write_vectors
    cfg = load_config(a.config)
    write_vectors(cfg, Path(a.out), seed=a.seed)
    print(f"vectors for config '{cfg.name}' written to {a.out}")
    return 0


def cmd_devserver(a) -> int:
    from .devserver import main as dmain
    return dmain(a.rest)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="sfg1", description="SilicaFlux SF-G1 reference toolchain")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("asm", help="assemble a .sfa file")
    p.add_argument("file")
    p.add_argument("-o", "--output")
    p.add_argument("--hex", help="also write a $readmemh file")
    p.add_argument("--listing")
    p.add_argument("--symbols")
    p.set_defaults(fn=cmd_asm)

    p = sub.add_parser("dis", help="disassemble .sfbin/.hex/.sfa")
    p.add_argument("file")
    p.add_argument("-a", "--addresses", action="store_true")
    p.set_defaults(fn=cmd_dis)

    p = sub.add_parser("run", help="run a kernel on the functional model")
    p.add_argument("kernel")
    p.add_argument("--grid", type=int, default=1)
    p.add_argument("--wg", type=int, default=8)
    p.add_argument("--shared", type=int, default=0)
    p.add_argument("--arg", action="append", default=[], help="integer, or @name for a --buf buffer address")
    p.add_argument("--buf", action="append", default=[], help="NAME=w0,w1,... or NAME=NxVALUE (allocated in order)")
    p.add_argument("--dump", action="append", default=[], help="print a buffer after the run")
    p.add_argument("--config", default="default")
    p.add_argument("--trace", help="write the canonical commit trace")
    p.set_defaults(fn=cmd_run)

    p = sub.add_parser("examples", help="run the bundled examples and compare with reference/")
    p.add_argument("names", nargs="*")
    p.add_argument("--config", default="default")
    p.add_argument("--reference", default=str(ROOT_REFERENCE))
    g = p.add_mutually_exclusive_group()
    g.add_argument("--update", action="store_true", help="rewrite the reference outputs (default config only)")
    g.add_argument("--check", action="store_true", help="fail if results differ from the reference outputs")
    p.set_defaults(fn=cmd_examples)

    p = sub.add_parser("vectors", help="generate RTL conformance vectors")
    p.add_argument("--config", default="default")
    p.add_argument("--out", required=True)
    p.add_argument("--seed", type=int, default=1)
    p.set_defaults(fn=cmd_vectors)

    p = sub.add_parser("devserver", help="run the line-protocol device server")
    p.add_argument("rest", nargs=argparse.REMAINDER)
    p.set_defaults(fn=cmd_devserver)

    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    raise SystemExit(main())
