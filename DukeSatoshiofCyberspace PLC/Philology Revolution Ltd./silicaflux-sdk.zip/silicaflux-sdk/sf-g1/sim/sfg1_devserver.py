#!/usr/bin/env python3
"""Entry point used by the C host library: python3 sim/sfg1_devserver.py --config default"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sfg1.devserver import main  # noqa: E402

raise SystemExit(main())
