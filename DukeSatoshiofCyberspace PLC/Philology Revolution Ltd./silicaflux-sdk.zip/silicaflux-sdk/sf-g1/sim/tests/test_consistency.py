"""Generated RTL/C/docs must agree with the JSON spec and the Python model (docs/09, 'Configuration consistency')."""
import re
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools"))

import gen  # noqa: E402
from sfg1.isa import isa  # noqa: E402
from sfg1.spec import Config, device_spec, _strip_docs  # noqa: E402

I = isa()
D = device_spec()


def sv_params(text):
    return {m.group(1): int(m.group(2)) for m in re.finditer(r"localparam int (\w+)\s*=\s*(\d+);", text)}


def sv_enum(text, typename):
    body = re.search(r"typedef enum logic \[\d+:\d+\] \{([^}]*)\}\s*" + typename + ";", text).group(1)
    return {m.group(1): int(m.group(2)) for m in re.finditer(r"(\w+)\s*=\s*\d+'d(\d+)", body)}


def c_defs(text):
    out = {}
    for m in re.finditer(r"#define\s+(\w+)\s+(0x[0-9a-fA-F]+|\d+)u?\b", text):
        out[m.group(1)] = int(m.group(2), 0)
    return out


class Consistency(unittest.TestCase):
    def test_checked_in_files_are_current(self):
        files = gen.generate(Config.from_file("default"))
        for rel, text in files.items():
            self.assertEqual((ROOT / rel).read_text(), text, f"{rel} is stale: run `make gen`")

    def check_config(self, name):
        cfg = Config.from_file(name)
        files = gen.generate(cfg, include_docs=False)
        pkg = files["rtl/gen/sf_g1_pkg.sv"]
        params = sv_params(pkg)
        for k in cfg.parameter_table():
            self.assertEqual(params[k.upper()], getattr(cfg, k), f"{name}: SV {k}")
        for k in cfg.fixed_table():
            self.assertEqual(params[k.upper()], getattr(cfg, k), f"{name}: SV {k}")
        for k, v in dict(MAX_WG_THREADS=cfg.max_wg_threads, PC_W=cfg.pc_bits, RPC_NONE=cfg.rpc_none,
                         LANE_W=cfg.lane_bits, WG_SLOT_SMEM_BYTES=cfg.wg_slot_smem_bytes).items():
            self.assertEqual(params[k], v, f"{name}: SV {k}")
        self.assertIn(f"CFG_HASH   = 32'h{cfg.cfg_hash():08x}", pkg)
        # ISA enums
        self.assertEqual(sv_enum(pkg, "sf_opcode_e"), {f"OP_{m.upper()}": i.opcode for m, i in I.by_mnemonic.items()})
        self.assertEqual(sv_enum(pkg, "sf_alu_fn_e"), {f"ALU_{n}": c for n, c in I.alu_functions.items()})
        self.assertEqual(sv_enum(pkg, "sf_iclass_e"), {f"ICLASS_{n}": c for n, c in I.classes.items()})
        for n, idx in I.special_registers.items():
            self.assertRegex(pkg, rf"{n} = 5'd{idx};")
        for n, off in D.reg_offset.items():
            self.assertRegex(pkg, rf"REG_{n}\s*= 12'h{off:03x};")
        for n, code in {**D.launch_errors, **D.faults}.items():
            self.assertRegex(pkg, rf"{n}\s*= 8'd{code};")
        # C headers
        c = c_defs(files["sw/include/gen/sf_g1_config.h"])
        for k in cfg.parameter_table():
            self.assertEqual(c[f"SF_G1_{k.upper()}"], getattr(cfg, k), f"{name}: C {k}")
        self.assertEqual(c["SF_G1_CFG_HASH"], cfg.cfg_hash())
        self.assertEqual(c["SF_G1_MAX_WG_THREADS"], cfg.max_wg_threads)
        self.assertEqual(c["SF_G1_RPC_NONE"], cfg.rpc_none)
        ci = c_defs(files["sw/include/gen/sf_g1_isa.h"])
        for m, i in I.by_mnemonic.items():
            self.assertEqual(ci[f"SF_OP_{m.upper()}"], i.opcode)
        for n, idx in I.special_registers.items():
            self.assertEqual(ci[f"SF_{n}"], idx)
        cr = c_defs(files["sw/include/gen/sf_g1_regs.h"])
        for n, off in D.reg_offset.items():
            self.assertEqual(cr[f"SF_REG_{n}"], off)
        for n, code in {**D.launch_errors, **D.faults}.items():
            self.assertEqual(cr[f"SF_{n}"], code)
        for n, idx in D.desc_words.items():
            self.assertEqual(cr[f"SF_DESC_{n}"], idx)
        self.assertEqual(cr["SF_G1_DEVICE_ID"], D.device_id)

    def test_default(self):
        self.check_config("default")

    def test_small(self):
        self.check_config("small")

    def test_wide(self):
        self.check_config("wide")

    def test_hash_differs_between_configs_and_ignores_prose(self):
        hs = {n: Config.from_file(n).cfg_hash() for n in ("default", "small", "wide")}
        self.assertEqual(len(set(hs.values())), 3)
        self.assertEqual(_strip_docs({"doc": "x", "a": [{"semantics": "y", "b": 1}]}), {"a": [{"b": 1}]})

    def test_device_caps_registers_match_config(self):
        from sfg1.device import Device
        for n in ("default", "small", "wide"):
            cfg = Config.from_file(n)
            dev = Device(cfg)
            dev.run(10)
            for reg, val in cfg.caps_regs().items():
                self.assertEqual(dev.reg_read(D.reg_offset[reg]), val, f"{n} {reg}")
            self.assertEqual(dev.reg_read(D.reg_offset["CFG_HASH"]), cfg.cfg_hash())

    def test_invalid_configs_are_rejected(self):
        from sfg1.spec import ConfigError
        for bad in (dict(lanes=6), dict(wg_slots_per_eg=5), dict(smem_bytes_per_eg=100), dict(imem_words=4096),
                    dict(gmem_bytes=5000), dict(simt_stack_depth=1), dict(num_eg=0), dict(bogus=1)):
            with self.assertRaises(ConfigError, msg=str(bad)):
                Config.from_dict(bad)

    def test_reference_reports_carry_current_hash(self):
        import json
        h = f"0x{Config.default().cfg_hash():08x}"
        for p in (ROOT / "reference").glob("*/report.json"):
            self.assertEqual(json.loads(p.read_text())["cfg_hash"], h, p)

    def test_gen_check_cli(self):
        r = subprocess.run([sys.executable, str(ROOT / "tools/gen.py"), "--check"], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)


if __name__ == "__main__":
    unittest.main()
