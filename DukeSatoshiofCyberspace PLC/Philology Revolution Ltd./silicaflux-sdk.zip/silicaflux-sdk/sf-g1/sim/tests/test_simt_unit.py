"""Unit tests and properties of the reference SIMT stack (docs/03-execution-model.md)."""
import random
import unittest

from sfg1.simt import SimtStack
from sfg1.spec import Config
from sfg1.vectors import random_stream, replay, CMD_BRANCH, CMD_INIT

NONE = 1025


def S(depth=16):
    return SimtStack(depth, NONE)


class StackScenarios(unittest.TestCase):
    def test_if_else_serialises_then_reconverges(self):
        s = S(); s.init(0, 0xFF)
        s.seq()                                   # pc 1: the branch
        self.assertFalse(s.branch(0x0F, 10, 20))   # lanes 0-3 take it to 10, others fall to 2; reconverge at 20
        self.assertEqual((s.pc, s.active, s.depth), (10, 0x0F, 3))         # taken path runs first
        s.jump(20)                                 # taken path reaches the join
        self.assertEqual((s.pc, s.active, s.depth), (2, 0xF0, 2))          # fall-through path next
        s.jump(20)
        self.assertEqual((s.pc, s.active, s.depth), (20, 0xFF, 1))         # all lanes together again

    def test_uniform_branches_do_not_touch_the_stack(self):
        s = S(); s.init(5, 0xFF)
        s.branch(0xFF, 40, 50); self.assertEqual((s.pc, s.depth), (40, 1))
        s.branch(0x00, 90, 99); self.assertEqual((s.pc, s.depth), (41, 1))

    def test_skip_when_target_equals_reconvergence(self):
        s = S(); s.init(0, 0xFF)
        s.branch(0xC0, 9, 9)                       # taken lanes wait at 9; only the fall-through path is pushed
        self.assertEqual((s.pc, s.active, s.depth), (1, 0x3F, 2))

    def test_loop_with_shrinking_mask_uses_constant_stack(self):
        s = S(); s.init(0, 0xFF)
        # Loop body at 0..28, back-edge `bnz r, 0, 30` at 29 (fall-through == reconvergence == 30);
        # one more lane runs out of iterations each time round.
        for i in range(7):
            s.jump(29)                              # body executed, now at the back-edge
            cond = s.active & ~(1 << i)             # lane i leaves the loop
            self.assertFalse(s.branch(cond, 0, 30))
            self.assertLessEqual(s.depth, 2, f"iteration {i}")
            self.assertEqual(s.pc, 0)
        self.assertEqual(s.active, 0x80)
        s.jump(29)
        s.branch(0, 0, 30)                          # last lane leaves: everyone is at 30
        self.assertEqual((s.pc, s.active, s.depth), (30, 0xFF, 1))

    def test_exit_removes_lanes_everywhere_and_pops_empty_entries(self):
        s = S(); s.init(0, 0b1111)
        s.branch(0b0011, 8, 12)
        s.exit_()                                   # taken lanes (0,1) exit
        self.assertEqual((s.pc, s.active, s.live), (1, 0b1100, 0b1100))
        s.jump(12)
        self.assertEqual((s.pc, s.active), (12, 0b1100))                   # reconverged without the dead lanes
        s.exit_()
        self.assertTrue(s.done)

    def test_overflow_is_precise(self):
        s = S(2); s.init(0, 0xF)
        before = [list(e) for e in s.entries]
        self.assertTrue(s.branch(0b0011, 5, 9))     # needs 2 more entries, only 1 free
        self.assertEqual(s.entries, before)
        self.assertEqual(s.depth, 1)

    def test_rpc_violation_flag(self):
        s = S(); s.init(0, 0xF)
        s.branch(0b0011, 8, 10)                     # taken path (rpc 10) at pc 8
        s.jump(11)                                  # runs past the reconvergence address
        self.assertTrue(s.rpc_violation())


class StackProperties(unittest.TestCase):
    def test_depth_never_exceeds_two_lanes_minus_one(self):
        # With unlimited capacity, depth is bounded by 2*lanes-1 for ANY command stream
        # (even ill-formed ones): this is why simt_stack_depth >= 2*lanes-1 cannot overflow.
        rng = random.Random(11)
        for lanes in (4, 8, 16):
            cfg = Config.from_file("default").with_overrides(lanes=lanes, simt_stack_depth=64)
            worst = 0
            for _ in range(250):
                st = SimtStack(64, cfg.rpc_none)
                for kind, pc, rc, m in random_stream(cfg, rng, 80):
                    if kind == CMD_INIT:
                        st.init(pc, m)
                    elif kind == 1:
                        st.seq()
                    elif kind == 2:
                        st.jump(pc)
                    elif kind == CMD_BRANCH:
                        self.assertFalse(st.branch(m, pc, rc))
                    else:
                        st.exit_()
                    worst = max(worst, st.depth)
            self.assertLessEqual(worst, 2 * lanes - 1, lanes)

    def test_replay_matches_direct_execution(self):
        cfg = Config.from_file("small")
        rng = random.Random(5)
        cmds = random_stream(cfg, rng, 60)
        a = replay(cfg, cmds)
        b = replay(cfg, cmds)
        self.assertEqual(a, b)

    def test_active_is_never_empty_while_not_done(self):
        rng = random.Random(3)
        cfg = Config.from_file("default")
        for _ in range(200):
            for cmd, snap, ovf in replay(cfg, random_stream(cfg, rng, 60)):
                pc, active, live, depth, done, viol = snap
                self.assertEqual(done, int(depth == 0))
                if not done:
                    self.assertNotEqual(active, 0)
                    self.assertEqual(active & ~live, 0)


if __name__ == "__main__":
    unittest.main()
