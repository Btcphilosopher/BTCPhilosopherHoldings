"""Differential test of masks and reconvergence.

Random structured programs (nested if/else, loops with per-thread trip counts,
breaks, early exits, loads, stores) are run on the SIMT model and compared with an
oracle that executes every thread alone, with no masks, no stack and no
reconvergence.  Any difference means the SIMT machinery changed the meaning of
a program.

The generator follows the layout rule of docs/03: the reconvergence address of
a branch is its immediate post-dominator.  An ``if`` that contains a ``break``
therefore reconverges at the end of the enclosing loop, not at its own endif.
"""
import random
import struct
import unittest

from sfg1.asm import assemble
from sfg1.device import Device
from sfg1.host import Host, LocalTransport
from sfg1.isa import decode
from sfg1.spec import Config, MASK32
from sfg1 import alu as alu_mod

VARS = [3, 4, 5, 6, 7, 8]          # data registers
OUT_WORDS = 8                       # per-thread output slots
IN_WORDS = 32


class Gen:
    """Structured random program generator with unique labels."""

    def __init__(self, rng: random.Random, max_depth: int, max_stmts: int) -> None:
        self.r = rng
        self.max_depth = max_depth
        self.max_stmts = max_stmts
        self.n = 0
        self.lines = []

    def label(self, p):
        self.n += 1
        return f"{p}{self.n}"

    def var(self):
        return self.r.choice(VARS + [1])

    def emit(self, s):
        self.lines.append("    " + s)

    def capture(self, fn, *args):
        """Run ``fn`` and return the lines it emitted instead of appending them."""
        saved, self.lines = self.lines, []
        fn(*args)
        out, self.lines = self.lines, saved
        return out

    def assign(self):
        d = self.r.choice(VARS)
        k = self.r.random()
        if k < 0.5:
            op = self.r.choice(["add", "sub", "xor", "and", "or", "mul", "slt", "sltu"])
            self.emit(f"{op} r{d}, r{self.var()}, r{self.var()}")
        elif k < 0.85:
            op = self.r.choice(["addi", "xori", "andi", "ori", "slti"])
            self.emit(f"{op} r{d}, r{self.var()}, {self.r.randint(-40, 200)}")
        else:
            op = self.r.choice(["shli", "shri", "sari"])
            self.emit(f"{op} r{d}, r{self.var()}, {self.r.randint(0, 7)}")

    def load(self):
        self.emit(f"andi r9, r{self.var()}, {IN_WORDS - 1}")
        self.emit("shli r9, r9, 2")
        self.emit("add r9, r9, r2")
        self.emit(f"ldg r{self.r.choice(VARS)}, [r9]")

    def store(self):
        self.emit(f"stg r{self.var()}, [r10 + {4 * self.r.randrange(OUT_WORDS)}]")

    def cond(self, reg):
        k = self.r.random()
        if k < 0.6:
            self.emit(f"andi r{reg}, r{self.var()}, {self.r.choice([1, 2, 4, 8, 3, 5, 7])}")
        elif k < 0.85:
            self.emit(f"slt r{reg}, r{self.var()}, r{self.var()}")
        else:
            self.emit(f"xor r{reg}, r{self.var()}, r{self.var()}")

    def block(self, depth, loop_end, loop_depth):
        """Emit statements.  ``loop_end`` is the end label of the innermost enclosing loop."""
        for _ in range(self.r.randint(1, self.max_stmts)):
            roll = self.r.random()
            if roll < 0.30 or depth >= self.max_depth:
                (self.assign if self.r.random() < 0.8 else (self.load if self.r.random() < 0.6 else self.store))()
            elif roll < 0.62:
                self.if_stmt(depth, loop_end, loop_depth)
            elif roll < 0.80 and loop_depth < 2:
                self.loop_stmt(depth, loop_depth)
            elif roll < 0.88 and loop_end is not None:
                self.break_stmt(loop_end)
            else:
                self.exit_stmt()

    def if_stmt(self, depth, loop_end, loop_depth):
        has_else = self.r.random() < 0.6
        l_else, l_end = self.label("else"), self.label("endif")
        arm_a = self.capture(self.block, depth + 1, loop_end, loop_depth)
        arm_b = self.capture(self.block, depth + 1, loop_end, loop_depth) if has_else else []
        # Immediate post-dominator: a break inside either arm leaves the loop
        # without passing endif, so the if must reconverge at the loop exit.
        contains_break = any("BREAKMARK" in ln for ln in arm_a + arm_b)
        reconv = loop_end if (contains_break and loop_end is not None) else l_end
        self.cond(14)
        br = self.r.choice(["bz", "bnz"])
        if has_else:
            self.emit(f"{br} r14, {l_else}, {reconv}")     # taken lanes run the else arm
            self.lines.extend(arm_a)
            self.emit(f"bra {l_end}")
            self.lines.append(f"{l_else}:")
            self.lines.extend(arm_b)
        else:
            self.emit(f"{br} r14, {l_end}, {reconv}")
            self.lines.extend(arm_a)
        self.lines.append(f"{l_end}:")

    def loop_stmt(self, depth, loop_depth):
        cnt, lim = (11, 12) if loop_depth == 0 else (13, 15)
        l_top, l_end = self.label("loop"), self.label("endloop")
        body = self.capture(self.block, depth + 1, l_end, loop_depth + 1)
        self.emit(f"addi r{cnt}, r0, 0")
        self.emit(f"andi r{lim}, r{self.var()}, 3")
        self.lines.append(f"{l_top}:")
        self.emit(f"slt r14, r{cnt}, r{lim}")
        self.emit(f"bz r14, {l_end}, {l_end}")
        self.lines.extend(body)
        self.emit(f"addi r{cnt}, r{cnt}, 1")
        self.emit(f"bra {l_top}")
        self.lines.append(f"{l_end}:")

    def break_stmt(self, loop_end):
        self.cond(14)
        self.lines.append(f"    bnz r14, {loop_end}, {loop_end}   ; BREAKMARK")

    def exit_stmt(self):
        l = self.label("noexit")
        self.cond(14)
        self.emit(f"bnz r14, {l}, {l}")
        self.emit("exit")
        self.lines.append(f"{l}:")


def build_program(rng, max_depth=3, max_stmts=4):
    g = Gen(rng, max_depth, max_stmts)
    # r10 = out + gtid * OUT_WORDS * 4
    prologue = [
        "    rdsr r1, SR_GTID",
        "    rdsr r2, SR_ARG1          ; input table",
        "    rdsr r10, SR_ARG0         ; output base",
        f"    addi r9, r0, {OUT_WORDS * 4}",
        "    mul  r9, r9, r1",
        "    add  r10, r10, r9",
        "    mul  r3, r1, r1",
        "    addi r4, r1, 7",
        "    xori r5, r1, 21",
        "    shli r6, r1, 1",
        "    addi r7, r0, 3",
        "    sub  r8, r0, r1",
    ]
    g.lines.extend(prologue)
    g.block(0, None, 0)
    epilogue = [f"    stg r{v}, [r10 + {4 * i}]" for i, v in enumerate(VARS)] + ["    exit"]
    g.lines.extend(epilogue)
    return "\n".join(g.lines) + "\n"


# --------------------------------------------------------------- oracle
def s32(x):
    return x - (1 << 32) if x & 0x80000000 else x


def oracle(words, tid_count, gtid_base_fn, out_base, in_base, in_vals, out_slots):
    """Run each thread alone with no SIMT machinery; returns {addr: value} of stores."""
    decoded = [decode(w) for w in words]
    mem = {}
    for t in range(tid_count):
        regs = [0] * 16
        pc = 0
        gtid = gtid_base_fn(t)
        steps = 0
        while True:
            steps += 1
            assert steps < 100000, "oracle runaway"
            d = decoded[pc]
            assert not d.illegal, f"illegal at {pc}"
            m = d.mnemonic
            c = d.iclass
            if m == "exit":
                break
            if m == "nop":
                pc += 1
            elif m == "rdsr":
                v = {2: in_base, 0: 0}
                from sfg1.isa import isa as _isa
                names = _isa().sr_names
                nm = names[d.imm]
                val = {"SR_GTID": gtid, "SR_ARG0": out_base, "SR_ARG1": in_base}[nm]
                if d.rd:
                    regs[d.rd] = val & MASK32
                pc += 1
            elif m in ("bz", "bnz"):
                taken = (regs[d.rs1] == 0) == (m == "bz")
                pc = pc + s32(d.imm) if taken else pc + 1
            elif m == "bra":
                pc = pc + s32(d.imm)
            elif m == "ldg":
                a = (regs[d.rs1] + s32(d.imm)) & MASK32
                v = in_vals[(a - in_base) // 4] if in_base <= a < in_base + 4 * len(in_vals) else mem.get(a, 0x55555555)
                if d.rd:
                    regs[d.rd] = v
                pc += 1
            elif m == "stg":
                mem[(regs[d.rs1] + s32(d.imm)) & MASK32] = regs[d.rs2]
                pc += 1
            elif c == 1:  # ALU
                a = regs[d.rs1]
                b = d.imm if d.b_imm else regs[d.rs2]
                if d.rd:
                    regs[d.rd] = alu_mod.alu(d.alu_fn, a, b)
                pc += 1
            else:
                raise AssertionError(f"oracle does not model {m}")
    return mem


class DifferentialTest(unittest.TestCase):
    def run_case(self, cfg, seed):
        rng = random.Random(seed)
        src = build_program(rng, max_depth=rng.choice([1, 2, 3]), max_stmts=rng.choice([2, 3, 4]))
        res = assemble(src, f"<seed {seed}>")
        words = res.words
        wg = rng.randint(1, min(cfg.max_wg_threads, 3 * cfg.lanes))
        grid = rng.randint(1, 3)
        dev = Device(cfg)
        host = Host(LocalTransport(dev), cfg)
        nthreads = wg * grid
        out_base = host.alloc(4 * OUT_WORDS * nthreads)
        in_base = host.alloc(4 * IN_WORDS)
        in_vals = [rng.randrange(1 << 32) for _ in range(IN_WORDS)]
        host.write_words(in_base, in_vals)
        host.write_words(out_base, [0x55555555] * (OUT_WORDS * nthreads))
        k = host.load_kernel(words)
        r = host.launch(k, grid=grid, wg=wg, args=[out_base, in_base])
        self.assertTrue(r.ok, f"seed {seed}: {r.status} {r.error} fault={r.fault}\n{src}")
        got = host.read_words(out_base, OUT_WORDS * nthreads)
        exp = oracle(words, nthreads, lambda t: t, out_base, in_base, in_vals, OUT_WORDS)
        expected = [exp.get(out_base + 4 * i, 0x55555555) for i in range(OUT_WORDS * nthreads)]
        if got != expected:
            bad = [i for i in range(len(got)) if got[i] != expected[i]][:5]
            self.fail(f"seed {seed} cfg {cfg.name}: mismatch at words {bad}\n"
                      f"got {[hex(got[i]) for i in bad]} exp {[hex(expected[i]) for i in bad]}\n{src}")
        return r

    def test_default_config(self):
        for seed in range(250):
            self.run_case(Config.from_file("default"), seed)

    def test_wide_config(self):
        for seed in range(1000, 1060):
            self.run_case(Config.from_file("wide"), seed)

    def test_stack_depth_never_exceeds_bound(self):
        # With depth = 2*lanes-1 the stack cannot overflow (docs/03): run the
        # same programs on a minimum-sufficient stack and require success.
        cfg = Config.from_file("default").with_overrides(simt_stack_depth=2 * 8 - 1)
        for seed in range(2000, 2080):
            self.run_case(cfg, seed)


if __name__ == "__main__":
    unittest.main()
