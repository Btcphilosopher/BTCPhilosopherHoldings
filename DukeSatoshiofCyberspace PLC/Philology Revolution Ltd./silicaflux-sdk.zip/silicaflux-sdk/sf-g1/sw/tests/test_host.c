/*
 * Host-library self-test against the reference device model.
 *   test_host --sim <sim_root> --config <name> --other-config <a different config name>
 * Exercises registers, interrupts, descriptor validation, faults, watchdog, reset, aperture errors,
 * multi-chunk transfers, hand-assembled kernels built with the generated encoders, and CFG_HASH protection.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>

#include "sfg1_host.h"
#include "sf_g1_config.h"
#include "sf_g1_isa.h"
#include "sf_g1_regs.h"

static int failures, checks;
#define CHECK(cond, ...) do { checks++; if (!(cond)) { failures++; printf("  FAIL line %d: %s  ", __LINE__, #cond); printf(__VA_ARGS__); printf("\n"); } } while (0)

static const char *sim, *config, *other;

static int open_cfg(sfg1_dev *d, const char *cfg, unsigned flags)
{
    sfg1_transport t;
    if (sfg1_pipe_open(&t, NULL, sim, cfg, NULL)) return SFG1_E_IO;
    int rc = sfg1_open(d, &t, flags);
    if (rc && t.close) t.close(t.ctx);
    return rc;
}

static uint32_t rd(sfg1_dev *d, uint32_t off) { uint32_t v = 0xDEADBEEF; sfg1_reg_read(d, off, &v); return v; }

static void run_kernel(sfg1_dev *d, const uint32_t *code, uint32_t n, uint32_t grid, uint32_t wg, uint32_t shared,
                       const uint32_t *args, unsigned nargs, sfg1_result *r)
{
    sfg1_kernel k;
    CHECK(sfg1_load_kernel(d, code, n, &k) == SFG1_OK, "load");
    sfg1_launch(d, &k, grid, wg, shared, args, nargs, 0, r);
}

int main(int argc, char **argv)
{
    for (int i = 1; i + 1 < argc; i += 2) {
        if (!strcmp(argv[i], "--sim")) sim = argv[i + 1];
        else if (!strcmp(argv[i], "--config")) config = argv[i + 1];
        else if (!strcmp(argv[i], "--other-config")) other = argv[i + 1];
    }
    if (!sim || !config || !other) { fprintf(stderr, "usage: test_host --sim DIR --config A --other-config B\n"); return 2; }

    const uint32_t EXIT = SF_ENC_Z(SF_OP_EXIT);
    sfg1_dev d;
    sfg1_result r;

    printf("[open + identity + capabilities]\n");
    CHECK(open_cfg(&d, config, 0) == SFG1_OK, "open");
    CHECK(rd(&d, SF_REG_ID) == SF_G1_DEVICE_ID, "id");
    CHECK(rd(&d, SF_REG_VERSION) == SF_G1_VERSION_WORD, "version");
    CHECK(d.caps.lanes == SF_G1_LANES && d.caps.warps_per_eg == SF_G1_WARPS_PER_EG && d.caps.num_eg == SF_G1_NUM_EG, "geometry");
    CHECK(d.caps.wg_slots_per_eg == SF_G1_WG_SLOTS_PER_EG && d.caps.smem_bytes_per_eg == SF_G1_SMEM_BYTES_PER_EG, "slots/smem");
    CHECK(d.caps.imem_words == SF_G1_IMEM_WORDS && d.caps.simt_stack_depth == SF_G1_SIMT_STACK_DEPTH, "imem/stack");
    CHECK(d.caps.gmem_bytes == SF_G1_GMEM_BYTES && d.caps.max_wg_threads == SF_G1_MAX_WG_THREADS, "gmem/limits");
    CHECK(d.caps.num_regs == SF_G1_NUM_REGS && d.caps.max_grid_dim == SF_G1_MAX_GRID_DIM, "regs/grid");
    CHECK(d.caps.cfg_hash == SF_G1_CFG_HASH, "hash");

    printf("[register access rules]\n");
    sfg1_reg_write(&d, SF_REG_SCRATCH, 0x1234ABCD);
    CHECK(rd(&d, SF_REG_SCRATCH) == 0x1234ABCD, "scratch");
    sfg1_reg_write(&d, SF_REG_ID, 0);
    CHECK(rd(&d, SF_REG_ID) == SF_G1_DEVICE_ID, "RO write ignored");
    CHECK(rd(&d, 0x0F4) == 0, "unmapped read returns 0");
    CHECK(rd(&d, SF_REG_INT_STATUS) & (1u << 3), "HOST_ERR set by unmapped read");
    sfg1_reg_write(&d, SF_REG_INT_STATUS, 1u << 3);
    CHECK(rd(&d, SF_REG_INT_STATUS) == 0, "W1C clears");
    sfg1_reg_write(&d, SF_REG_INT_ENABLE, 0xFFFF);
    CHECK(rd(&d, SF_REG_INT_ENABLE) == 0xF, "INT_ENABLE masked to 4 bits");
    sfg1_reg_write(&d, SF_REG_INT_ENABLE, 0);

    printf("[aperture: chunked transfer, bounds]\n");
    {
        enum { W = 3000 };
        static uint32_t out[W], in[W];
        for (int i = 0; i < W; i++) out[i] = (uint32_t)i * 2654435761u;
        uint32_t a;
        CHECK(sfg1_alloc(&d, 4 * W, 64, &a) == SFG1_OK, "alloc");
        CHECK(sfg1_write_words(&d, a, out, W) == SFG1_OK, "write 12 kB");
        CHECK(sfg1_read_words(&d, a, in, W) == SFG1_OK, "read 12 kB");
        CHECK(memcmp(in, out, sizeof in) == 0, "round trip");
        uint32_t tmp;
        CHECK(sfg1_read(&d, d.caps.gmem_bytes - 2, &tmp, 4) == SFG1_E_BUS, "read past end rejected");
        CHECK(rd(&d, SF_REG_INT_STATUS) & (1u << 3), "HOST_ERR after rejected aperture access");
        sfg1_reg_write(&d, SF_REG_INT_STATUS, 0xF);
    }

    printf("[completion interrupt + progress counters]\n");
    {
        int lvl = -1;
        sfg1_reg_write(&d, SF_REG_INT_ENABLE, 1);
        sfg1_irq_level(&d, &lvl);
        CHECK(lvl == 0, "irq low before launch");
        run_kernel(&d, &EXIT, 1, 3, 8, 0, NULL, 0, &r);
        CHECK(r.status == SFG1_OK, "exit kernel ran: %s", sfg1_strerror(r.status));
        sfg1_irq_level(&d, &lvl);
        CHECK(lvl == 1, "irq high after DONE");
        CHECK(rd(&d, SF_REG_STATUS) & (1u << SF_STATUS_DONE_SHIFT), "STATUS.DONE");
        CHECK(rd(&d, SF_REG_WG_COMPLETED) == 3 && rd(&d, SF_REG_WG_DISPATCHED) == 3, "workgroup counters");
        sfg1_reg_write(&d, SF_REG_INT_STATUS, 1);
        sfg1_irq_level(&d, &lvl);
        CHECK(lvl == 0, "irq cleared by W1C");
        sfg1_reg_write(&d, SF_REG_INT_ENABLE, 0);
    }

    printf("[hand-assembled kernel using generated encoders: out[tid] = 3 * tid]\n");
    {
        const uint32_t code[] = {
            SF_ENC_I(SF_OP_RDSR, 1, 0, SF_SR_TID),            /* rdsr r1, SR_TID  */
            SF_ENC_I(SF_OP_RDSR, 2, 0, SF_SR_ARG0),           /* rdsr r2, SR_ARG0 */
            SF_ENC_I(SF_OP_ADDI, 3, 0, 3),                    /* addi r3, r0, 3   */
            SF_ENC_R(SF_OP_MUL, 3, 3, 1),                     /* mul  r3, r3, r1  */
            SF_ENC_I(SF_OP_SHLI, 4, 1, 2),                    /* shli r4, r1, 2   */
            SF_ENC_R(SF_OP_ADD, 4, 4, 2),                     /* add  r4, r4, r2  */
            SF_ENC_S(SF_OP_STG, 3, 4, 0),                     /* stg  r3, [r4]    */
            SF_ENC_Z(SF_OP_EXIT),
        };
        uint32_t wg = d.caps.max_wg_threads < 8 ? d.caps.max_wg_threads : 8, buf, got[8] = {0};
        sfg1_alloc(&d, 32, 64, &buf);
        run_kernel(&d, code, 8, 1, wg, 0, &buf, 1, &r);
        CHECK(r.status == SFG1_OK, "run");
        sfg1_read_words(&d, buf, got, wg);
        int ok = 1;
        for (uint32_t t = 0; t < wg; t++) ok &= got[t] == 3 * t;
        CHECK(ok, "results");
    }

    printf("[descriptor validation]\n");
    {
        sfg1_kernel k;
        sfg1_load_kernel(&d, &EXIT, 1, &k);
        sfg1_launch(&d, &k, 0, 8, 0, NULL, 0, 0, &r);
        CHECK(r.status == SFG1_E_LAUNCH && r.launch_err == SF_LE_DIMS, "grid 0 -> LE_DIMS (got %u)", r.launch_err);
        sfg1_launch(&d, &k, 1, d.caps.max_wg_threads + 1, 0, NULL, 0, 0, &r);
        CHECK(r.status == SFG1_E_LAUNCH && r.launch_err == SF_LE_DIMS, "wg too big -> LE_DIMS");
        sfg1_launch(&d, &k, 1, 8, SF_G1_WG_SLOT_SMEM_BYTES + 4, NULL, 0, 0, &r);
        CHECK(r.status == SFG1_E_LAUNCH && r.launch_err == SF_LE_SHARED, "shared too big -> LE_SHARED");
        sfg1_launch(&d, &k, 1, 8, 0, NULL, 0, 0x8000, &r);
        CHECK(r.status == SFG1_E_LAUNCH && r.launch_err == SF_LE_RESERVED, "unknown flag -> LE_RESERVED");
        CHECK(rd(&d, SF_REG_INT_STATUS) & 4, "INT_STATUS.LAUNCH_ERR");
        sfg1_reg_write(&d, SF_REG_INT_STATUS, 0xF);
        sfg1_launch(&d, &k, 1, 8, 0, NULL, 0, 0, &r);
        CHECK(r.status == SFG1_OK && rd(&d, SF_REG_LAUNCH_ERR) == 0, "device still usable; LAUNCH_ERR cleared");
    }

    printf("[fault, sticky state, reset, recovery]\n");
    {
        const uint32_t trap[] = {SF_ENC_T(SF_OP_TRAP, 0x1234)};
        run_kernel(&d, trap, 1, 1, 8, 0, NULL, 0, &r);
        CHECK(r.status == SFG1_E_FAULT && r.fault.code == SF_F_TRAP && r.fault.data == 0x1234 && r.fault.pc == 0, "trap fault");
        CHECK(r.fault.mask == (uint32_t)((1ull << (d.caps.lanes < 8 ? d.caps.lanes : 8)) - 1), "fault mask 0x%x", r.fault.mask);
        CHECK((rd(&d, SF_REG_STATUS) & 0xF) == 0x9, "STATUS READY|FAULTED");
        CHECK(rd(&d, SF_REG_INT_STATUS) & 2, "INT_STATUS.FAULT");
        run_kernel(&d, &EXIT, 1, 1, 8, 0, NULL, 0, &r);
        CHECK(r.status == SFG1_E_LAUNCH && r.launch_err == SF_LE_FAULTED, "launch refused while FAULTED (got %d/%u)", r.status, r.launch_err);
        CHECK(rd(&d, SF_REG_FAULT_CODE) == SF_F_TRAP, "first fault preserved");
        uint32_t a, v = 77, back = 0;
        sfg1_alloc(&d, 4, 64, &a);
        sfg1_write_words(&d, a, &v, 1);
        CHECK(sfg1_reset(&d) == SFG1_OK, "reset");
        CHECK(rd(&d, SF_REG_STATUS) == 1 && rd(&d, SF_REG_FAULT_CODE) == 0, "state cleared");
        sfg1_read_words(&d, a, &back, 1);
        CHECK(back == 77, "global memory survives reset");
        run_kernel(&d, &EXIT, 1, 1, 8, 0, NULL, 0, &r);
        CHECK(r.status == SFG1_OK, "works after reset");
    }

    printf("[watchdog]\n");
    {
        const uint32_t spin[] = {SF_ENC_J(SF_OP_BRA, 0)};
        sfg1_reg_write(&d, SF_REG_WDOG_LIMIT, 100);
        run_kernel(&d, spin, 1, 1, 1, 0, NULL, 0, &r);
        CHECK(r.status == SFG1_E_FAULT && r.fault.code == SF_F_WATCHDOG && r.fault.data == 100, "watchdog (code %u)", r.fault.code);
        CHECK(r.fault.loc == 0xFFFFFF, "device-level fault location");
        sfg1_reset(&d);
        CHECK(rd(&d, SF_REG_WDOG_LIMIT) == SF_G1_WDOG_RESET_TICKS, "WDOG_LIMIT back to reset value");
    }
    sfg1_close(&d);

    printf("[CFG_HASH protection]\n");
    {
        sfg1_dev d2;
        int rc = open_cfg(&d2, other, 0);
        CHECK(rc == SFG1_E_CFG_MISMATCH, "mismatched device refused (rc=%d)", rc);
        rc = open_cfg(&d2, other, SFG1_OPEN_IGNORE_CFG_HASH);
        CHECK(rc == SFG1_OK, "override accepted");
        CHECK(d2.caps.cfg_hash != SF_G1_CFG_HASH && (d2.caps.lanes != SF_G1_LANES || d2.caps.num_eg != SF_G1_NUM_EG), "caps describe the other device");
        if (rc == SFG1_OK) sfg1_close(&d2);
    }

    printf("test_host: %d checks, %d failures\n", checks, failures);
    return failures ? 1 : 0;
}
