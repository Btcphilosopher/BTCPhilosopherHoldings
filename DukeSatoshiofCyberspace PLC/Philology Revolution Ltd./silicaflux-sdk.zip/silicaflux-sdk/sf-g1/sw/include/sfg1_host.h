/*
 * SilicaFlux SF-G1 host library (C11, POSIX).
 *
 * Talks to an SF-G1 device through a *transport*: BAR0 register access, BAR1
 * global-memory aperture access and, for simulated devices only, a way to
 * advance device time.  The bundled pipe transport drives the Python reference
 * model (sim/sfg1_devserver.py); an RTL co-simulation or real board supplies
 * its own transport and leaves `advance` NULL.
 *
 * Configuration constants come from the generated headers (sf_g1_config.h,
 * sf_g1_regs.h); sfg1_open() refuses a device whose CFG_HASH differs from the
 * value compiled in here unless SFG1_OPEN_IGNORE_CFG_HASH is given.
 */
#ifndef SFG1_HOST_H
#define SFG1_HOST_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    SFG1_OK = 0,
    SFG1_E_IO = -1,            /* transport failure */
    SFG1_E_PROTO = -2,         /* malformed reply */
    SFG1_E_BAD_ID = -3,        /* not an SF-G1 device */
    SFG1_E_CFG_MISMATCH = -4,  /* device CFG_HASH differs from this build */
    SFG1_E_NOT_READY = -5,     /* device never became READY */
    SFG1_E_BUS = -6,           /* aperture access rejected */
    SFG1_E_NOMEM = -7,         /* device memory or host memory exhausted */
    SFG1_E_LAUNCH = -8,        /* descriptor rejected: see result.launch_err */
    SFG1_E_FAULT = -9,         /* execution fault: see result.fault */
    SFG1_E_TIMEOUT = -10,
    SFG1_E_ARG = -11,
    SFG1_E_FILE = -12
} sfg1_status;

#define SFG1_OPEN_IGNORE_CFG_HASH 0x1u

typedef struct sfg1_transport {
    int (*reg_read)(void *ctx, uint32_t off, uint32_t *val);
    int (*reg_write)(void *ctx, uint32_t off, uint32_t val);
    int (*mem_read)(void *ctx, uint32_t addr, void *buf, size_t n);
    int (*mem_write)(void *ctx, uint32_t addr, const void *buf, size_t n);
    /* Simulated devices only: run up to max_ticks device ticks (stops early when idle). */
    int (*advance)(void *ctx, uint64_t max_ticks, uint64_t *ran);
    /* Optional: level of the interrupt output. */
    int (*irq_level)(void *ctx, int *level);
    void (*close)(void *ctx);
    void *ctx;
} sfg1_transport;

typedef struct {
    uint32_t lanes, warps_per_eg, num_eg, wg_slots_per_eg;
    uint32_t smem_bytes_per_eg, imem_words, simt_stack_depth, num_regs;
    uint32_t gmem_bytes, max_wg_threads, max_grid_dim;
    uint32_t cfg_hash;
} sfg1_caps;

typedef struct {
    sfg1_transport t;
    sfg1_caps caps;
    uint32_t next_alloc;
} sfg1_dev;

typedef struct { uint32_t addr, words; } sfg1_kernel;

typedef struct { uint32_t code, loc, pc, wg, mask, data; } sfg1_fault;

typedef struct {
    int status;              /* SFG1_OK, SFG1_E_LAUNCH, SFG1_E_FAULT, SFG1_E_TIMEOUT, ... */
    uint32_t launch_err;     /* LE_* code when status == SFG1_E_LAUNCH */
    sfg1_fault fault;        /* valid when status == SFG1_E_FAULT */
    uint32_t ticks, issued, lane_ops;
} sfg1_result;

/* Pipe transport to the Python device server.  `python` may be NULL (uses $SFG1_PYTHON or "python3").
 * `trace_path` may be NULL; otherwise the server writes the canonical commit trace there on close. */
int sfg1_pipe_open(sfg1_transport *t, const char *python, const char *sim_root,
                   const char *config, const char *trace_path);

int  sfg1_open(sfg1_dev *d, const sfg1_transport *t, unsigned flags);
void sfg1_close(sfg1_dev *d);

/* Bump allocator over device memory (starts at 0x100; address 0 is left unmapped by convention). */
int sfg1_alloc(sfg1_dev *d, uint32_t bytes, uint32_t align, uint32_t *addr);
int sfg1_write(sfg1_dev *d, uint32_t addr, const void *src, size_t n);
int sfg1_read(sfg1_dev *d, uint32_t addr, void *dst, size_t n);
int sfg1_write_words(sfg1_dev *d, uint32_t addr, const uint32_t *w, size_t count);
int sfg1_read_words(sfg1_dev *d, uint32_t addr, uint32_t *w, size_t count);

int sfg1_load_kernel(sfg1_dev *d, const uint32_t *code, uint32_t words, sfg1_kernel *k);
int sfg1_load_kernel_file(sfg1_dev *d, const char *sfbin_path, sfg1_kernel *k);

/* Build the 64-byte descriptor, submit it, and wait for completion. */
int sfg1_launch(sfg1_dev *d, const sfg1_kernel *k, uint32_t grid, uint32_t wg_dim, uint32_t shared_bytes,
                const uint32_t *args, unsigned nargs, uint32_t flags, sfg1_result *res);
/* Submit without waiting / wait for an already-submitted launch. */
int sfg1_submit(sfg1_dev *d, const sfg1_kernel *k, uint32_t grid, uint32_t wg_dim, uint32_t shared_bytes,
                const uint32_t *args, unsigned nargs, uint32_t flags);
int sfg1_wait(sfg1_dev *d, uint64_t max_ticks, sfg1_result *res);

int sfg1_reset(sfg1_dev *d);
int sfg1_reg_read(sfg1_dev *d, uint32_t off, uint32_t *val);
int sfg1_reg_write(sfg1_dev *d, uint32_t off, uint32_t val);
int sfg1_advance(sfg1_dev *d, uint64_t ticks, uint64_t *ran);
int sfg1_irq_level(sfg1_dev *d, int *level);

const char *sfg1_strerror(int status);

#ifdef __cplusplus
}
#endif
#endif /* SFG1_HOST_H */
