# SilicaFlux SF-G1

An original, educational **SIMT GPU architecture** for Aureom.AI, with its executable reference model.

SF-G1 is **not** compatible with, and makes no claim about, CUDA, Vulkan, OpenCL or any commercial GPU ISA, programming model or driver
interface. It is a small ISA of its own: 35 instructions, 16 x 32-bit registers per thread, divergence handled by an explicit reconvergence stack,
a few execution groups of warps, a host register interface, launch descriptors, precise faults and a defined reset.

## What is in this tree

| | |
|---|---|
| **Architecture specification** | `docs/00`-`13`: terminology (lane, warp, workgroup, thread, execution group), ISA and encoding, masks and reconvergence, memory spaces and consistency, scheduling and barriers, launch descriptors, device registers and interrupts, errors and reset, verification contract |
| **Machine-readable definitions** | `spec/sf_g1_isa.json` (formats, opcodes, special registers, decoded-record layout), `sf_g1_device.json` (registers, descriptor, errors), `sf_g1_config.json` + `configs/` (parameters; `default`, `small`, `wide`) |
| **Python** | assembler, disassembler, SIMT stack, functional simulator and device model, host driver, vector generators (`sim/sfg1`, CLI `bin/sfg1`) |
| **Example kernels** | vector add, tree reduction, integer matrix multiply, and a divergence stress test (`examples/kernels`) |
| **Reference outputs** | results, statistics and commit traces per example (`reference/`) |
| **SystemVerilog** | generated package and decoder, ALU, SIMT stack, each with a self-checking testbench driven by model-generated vectors (`rtl/`) |
| **C host software** | transport-independent driver + pipe transport to the model, demo and self-test (`sw/`) |
| **Generated, consistent configuration** | `tools/gen.py` produces the RTL package, C headers and doc tables from the JSON; `CFG_HASH` ties hardware, host and model together at run time |
| **Verification gate** | `verification/blocks.json` + `tools/check_registry.py`: no RTL block without a model-backed conformance test |

## Try it

```bash
make test            # ~1-2 minutes: generation check, Python tests, examples vs reference, RTL conformance + mutation check, C host (3 configs)
bin/sfg1 examples    # run the four kernels and compare with reference/
bin/sfg1 dis examples/kernels/diverge.sfa
make help
```

Needs: Python 3 (standard library only; written for 3.9+, **tested only on 3.13**), a C11 compiler and `make`; for `make rtl`/`gate`: Icarus Verilog 12 (the version tested) and, optionally, Verilator 5 (tested: 5.020) for lint.

## Status: what is and is not done

Done and tested: everything in the table above. Numbers from the last full run:

* 86 Python tests including 390 random differential programs (SIMT model vs a per-thread oracle), plus mutation checks of both the model's SIMT stack and the RTL;
* RTL: decoder, ALU and SIMT stack pass ~20,000 model-generated vectors on three configurations, lint clean (Verilator `-Wall`), and 15 of 15 injected RTL bugs are detected;
* C host: 57 checks per configuration; every example driven from C reproduces the model's results, statistics **and commit-trace digest**.

**Not done, by design:** the execution pipeline and the remaining hardware blocks (register file, lane execution, load/store unit, barrier unit, scheduler,
launch unit, register/interrupt block, core top). They are listed as `planned` in `verification/blocks.json`, with the reference-model hook and compare
point for each; the plan is `docs/13-pipeline-plan.md`. The RTL that exists is behaviourally verified in simulation only: no synthesis, timing or formal work.

Known limits of the model: timing is approximate (ticks, zero-latency memory); the watchdog counts ticks; shared and global memory are poisoned rather than random after reset;
only one launch runs at a time and there is no queue. One dimension of grid and workgroup only.

## Layout

```
spec/            JSON specification (single source of truth)     rtl/       SystemVerilog + testbenches
docs/            architecture specification + generated tables   sw/        C host library, demo, tests
sim/sfg1/        Python model, assembler, host, vectors           tools/     generator, RTL runner, registry gate, mutation checks
sim/tests/       Python tests                                     verification/  conformance registry
examples/kernels example programs                                 reference/ golden outputs        bin/sfg1  CLI
```

## Housekeeping

* Generated files (`rtl/gen`, `sw/include/gen`, `docs/generated`) are checked in for the default configuration; `make gen` rewrites them, `make check-gen` fails on drift.
  Other configurations are generated into `build/<name>/` on demand.
* This tree contains no license file; add one before publishing.
* `make zip` builds `dist/silicaflux-sf-g1.zip` from a clean tree.
