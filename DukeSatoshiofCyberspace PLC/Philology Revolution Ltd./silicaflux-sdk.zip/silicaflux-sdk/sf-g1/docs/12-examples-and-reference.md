# 12. Example kernels and reference outputs

Sources: `examples/kernels/*.sfa`. Run all: `bin/sfg1 examples` (add `--check` to compare with `reference/`).

| Kernel | What it computes | Launch (default config) | Demonstrates |
|---|---|---|---|
| `vecadd.sfa` | `c[i] = a[i] + b[i]` for `i < n` | n = 70, wg = 32, grid = 3 | tail masking: the last warp has lanes with `gtid >= n`; a guard region after `c` proves they write nothing |
| `reduce_sum.sfa` | `*out += sum(in[0..n))` | n = 100, wg = 16, grid = 7 | shared memory, barriers in a loop, `tid < s` divergence, one atomic per workgroup (old value discarded so the trace is scheduling-independent) |
| `matmul_i32.sfa` | `C[M][N] = A[M][K] x B[K][N]`, wrap-around 32-bit | M = 6, K = 5, N = 7, wg = 8, grid = 6 | one workgroup per output row, threads stride over columns, divergent column loop (`N` not a multiple of `wg`), `mul`, address arithmetic |
| `diverge.sfa` | per-thread value built with nested if/else, a loop with a per-lane trip count, a `break`, and early `exit` | 2 workgroups x 20 threads | every reconvergence feature; SIMT efficiency 0.49; partial last warp |

Each example allocates buffers in a fixed order, fills inputs from a documented LCG, and checks the result against an **independent**
computation (in Python in `sim/sfg1/examples.py`, and again in C in `sfg1_demo.c`). Outputs have `0xCCCCCCCC` guard words after them to show
that masked lanes never write.

## 12.1 LCG, checksums

`x <- x * 1664525 + 1013904223 (mod 2^32)`, the stream is the successive values of `x`. FNV-1a is the 32-bit variant over the
little-endian bytes of the words.

| Example | Inputs |
|---|---|
| vecadd | `a = stream(seed 1)`, `b = stream(seed 2)` (full 32-bit) |
| reduce_sum | `in[i] = (stream(seed 3)[i] >> 8) % 1000` |
| matmul_i32 | `A = ((stream(4) >> 16) % 201) - 100`, `B = ((stream(5) >> 16) % 201) - 100`, as int32 |
| diverge | none; the reference for thread *t* is `diverge_reference(t)` |

## 12.2 `reference/` layout

```
reference/<example>/report.json         launch parameters, input checksums, output data/checksums, statistics, kernel sha256, CFG_HASH, trace digest
reference/<example>/commit_trace.jsonl  canonical architectural commit trace (docs/09 9.4): the L2 conformance target
reference/<example>/kernel.lst          assembler listing
reference/<example>/kernel.hex          $readmemh image for an RTL instruction memory
```

All of it is for the **default** configuration (`CFG_HASH` is recorded). Other configurations are verified by result (against the independent
reference) and by cross-language trace equality, not by stored files.

| Example | Ticks | Warp insns | Lane ops | SIMT eff. | Trace events |
|---|---|---|---|---|---|
| vecadd | 96 | 159 | 1250 | 0.983 | 159 |
| reduce_sum | 397 | 689 | 4635 | 0.841 | 689 |
| matmul_i32 | 301 | 450 | 3246 | 0.902 | 450 |
| diverge | 183 | 330 | 1299 | 0.492 | 330 |

Regenerate with `make reference` **only** when the specification or the model has intentionally changed, and review the diff:
`make examples` (and `make test`) fail if a run no longer matches.

## 12.3 Using the reference outputs against hardware

A future core is conformant at L3 when, for each example, driving it through the host interface with the generated inputs
produces `outputs` equal to `report.json` and `PERF_ISSUED`, `PERF_LANE_OPS` equal to `stats`; and at L2 when its per-warp commit
trace digest equals `trace.sha256` (compare line by line against `commit_trace.jsonl` to localise a difference).
`PERF_CYCLES` / `ticks` are timing and are expected to differ.
