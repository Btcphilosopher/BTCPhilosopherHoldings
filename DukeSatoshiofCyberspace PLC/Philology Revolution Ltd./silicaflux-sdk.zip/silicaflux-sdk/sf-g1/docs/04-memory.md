# 4. Memory spaces and consistency

## 4.1 Spaces

| Space | Instructions | Scope | Size | Initial contents |
|---|---|---|---|---|
| **Registers** | all | one thread | 16 x 32 bit | zero at thread start |
| **Special registers** | `rdsr` | one thread (read-only) | 17 values | defined by the launch |
| **Instruction memory** | fetch | one EG (copy of the kernel) | `IMEM_WORDS` words | loaded from global memory at launch |
| **Shared memory** | `lds`, `sts` | one workgroup | `SMEM_BYTES_PER_EG / WG_SLOTS_PER_EG` per workgroup slot | undefined, or zero if `SMEM_ZERO` is set in the descriptor |
| **Global memory** | `ldg`, `stg`, `atomadd`, host aperture | whole device and host | `GMEM_BYTES` | undefined after a hard reset; preserved across a soft reset |

There is no local/private memory, no stack and no constant memory; kernel arguments are special registers.

## 4.2 Addressing

* All data accesses are **32-bit words**; there are no byte or halfword accesses by threads (the host
  aperture is byte-addressable).
* Effective address = `rs1 + sext(imm18)` modulo 2^32 (`atomadd`: `rs1`).
* The address MUST be 4-byte aligned: otherwise `F_GMEM_ALIGN` / `F_SMEM_ALIGN` with the address in `FAULT_DATA`.
* **Global:** valid addresses are `[0, GMEM_BYTES)`; otherwise `F_GMEM_RANGE`. Address 0 is valid; the host library keeps
  it unmapped by convention only.
* **Shared:** addresses are **relative to the workgroup's own region** and valid in `[0, SHARED_BYTES)` where `SHARED_BYTES` is the
  descriptor value; otherwise `F_SMEM_RANGE`. A workgroup cannot name another workgroup's shared memory, so a kernel is
  independent of which slot it landed in. `SHARED_BYTES` MUST be a multiple of 4 and at most `SMEM_BYTES_PER_EG / WG_SLOTS_PER_EG`.
* Little-endian: byte `a` of a word is bits `[8(a%4)+7 : 8(a%4)]`.

## 4.3 Faults are precise, per warp instruction

For a warp-wide memory instruction every active lane's address is checked **before any lane performs its access**. If any
lane fails, the instruction raises one fault and has **no architectural effect**: no register is written, no memory changes.
The reported code is that of the **lowest-numbered failing lane**, and for that lane misalignment takes priority over a range
error; `FAULT_LOC.LANE` names the lane and `FAULT_DATA` its address ([08](08-errors-reset.md)).

## 4.4 Ordering inside one warp instruction

When all checks pass, the active lanes perform their accesses **in ascending lane order**:

* loads: any order (they cannot interfere);
* stores: lane 0 first, so if several lanes store to the same word the **highest active lane's value remains**;
* `atomadd`: each lane's read-modify-write completes before the next lane's starts, so lane *i* receives the sum of the
  initial value and the operands of all lower active lanes that used the same address.

## 4.5 Consistency rules

The model is deliberately *weaker* than what the reference simulator happens to do, so that real hardware with queues, banks
and multiple EGs can conform. Software may rely only on these rules.

**C1. Single-copy atomicity.** Every aligned 32-bit access is performed atomically: a load returns a value that was
stored by some single store (or the initial value), never a mixture of bytes.

**C2. Same-thread order.** A thread observes its own earlier stores and atomics to the same address, in program order.
(A thread need not use `fence` to read back its own write; the reduction kernel relies on this.)

**C3. Same-warp order within an instruction.** As 4.4.

**C4. Barrier.** `bar` is a release/acquire for the whole workgroup: every memory access (shared *and* global)
made by any thread of the workgroup before the barrier is visible to every thread of the workgroup after it.
(This is what makes the shared-memory tree reduction correct.)

**C5. Atomicity of `atomadd`.** For one address, the `atomadd`s of all threads of the device are totally ordered and each is
indivisible with respect to every other access to that word. Different addresses are unordered with respect to each other.

**C6. Fence.** `fence` orders the executing warp's earlier memory accesses before its later ones, as observed by **any** thread
in the device (a device-scope release/acquire for that warp). Without a fence or barrier, two accesses by one thread to
different addresses may become visible to other threads in either order.

**C7. Launch boundaries.** Host writes completed before the doorbell are visible to every thread of the launch. All memory
writes of the launch are complete and visible to the host when `STATUS.DONE` is set (and, after a fault, the memory state
is only *unspecified*, see [08](08-errors-reset.md)).

**C8. No other ordering.** Between workgroups there is no ordering during a launch except via `atomadd` (C5) combined
with `fence`. SF-G1 gives **no guarantee that two workgroups are ever resident at the same time**, so a workgroup MUST NOT
wait for another workgroup.

### Data races

A **data race** is two accesses to the same word by threads that are not ordered by C2, C4, C5, or C6 where at least one is a
non-atomic store. The value read by a racing load is any value that C1 allows (some earlier store); racing stores leave
either value. The reference model produces one valid outcome; **all reference outputs in this repository come from race-free
kernels**, which is what lets any compliant implementation reproduce them.

Mixing `atomadd` and non-atomic accesses to one word without ordering is a race.

## 4.6 Instruction memory

The code image is copied from global memory (descriptor `CODE_ADDR`, `CODE_WORDS`) into each EG's instruction memory
during the launch phase. Changing the image in global memory afterwards has no effect on the running launch. Threads cannot
read or write instruction memory (no `ldg` of code, no self-modifying code).

## 4.7 Host access

The host reaches global memory through the **aperture** (BAR1): byte-addressed reads and writes of any length inside
`[0, GMEM_BYTES)`. Aperture accesses are rejected (and set `INT_STATUS.HOST_ERR`) while `STATUS.BUSY=1`, while the device is
resetting, or when they extend outside global memory. Accesses are allowed in the `IDLE` and `FAULTED` states, so a host can
inspect memory after a fault.

## 4.8 Reference model vs. implementations

| | Reference model | A conforming implementation MAY |
|---|---|---|
| Memory latency | zero (access completes in the issuing tick) | take many cycles |
| Access order between warps | exactly the issue order | reorder, subject to C1-C8 |
| Within one warp instruction | ascending lane order | be banked/coalesced, if the result equals ascending-lane order |
| `fence` | no-op | drain queues |
| Uninitialised memory | global memory is filled with the poison word `0xDEADBEEF` at power-up; each workgroup's shared slot is poisoned at dispatch unless `SMEM_ZERO` is set | contain anything |
