# 8. Errors, faults and reset

## 8.1 Three kinds of error

| Kind | Examples | Effect on the device | Reported in |
|---|---|---|---|
| **Launch error** | bad descriptor, doorbell while busy | none: stays usable | `LAUNCH_ERR`, `INT_STATUS.LAUNCH_ERR` |
| **Execution fault** | illegal instruction, bad address, divergent barrier, trap, watchdog | launch aborted, device enters `FAULTED` | `FAULT_*`, `STATUS.FAULTED`, `INT_STATUS.FAULT` |
| **Host error** | unmapped register, aperture access while busy | none | `INT_STATUS.HOST_ERR` only |

Launch errors (`LE_*`) and faults (`F_*`) are listed with codes in [generated/device_reference.md](generated/device_reference.md).

## 8.2 Execution faults

A fault is raised by one warp instruction and is **precise**: the faulting instruction has no architectural effect
(no register or memory write, no stack change, not counted in `PERF_ISSUED`). Fetch-time faults (`F_PC_RANGE`, `F_RECONV`,
`F_ILLEGAL_INSN`) are precise for the instruction that would have been fetched.

| Fault | Cause | `FAULT_DATA` |
|---|---|---|
| `F_ILLEGAL_INSN` | undefined opcode, reserved bit set, `roff = 0`, undefined special register | the instruction word |
| `F_PC_RANGE` | fetch at/after `CODE_WORDS`; branch/jump target or reconvergence address outside the code | the offending index (for a `bz`/`bnz`, the target if it is outside, else the reconvergence address) |
| `F_RECONV` | path ran past its reconvergence address | that address |
| `F_GMEM_ALIGN` `F_GMEM_RANGE` | global access misaligned / outside `[0, GMEM_BYTES)` | byte address |
| `F_SMEM_ALIGN` `F_SMEM_RANGE` | shared access misaligned / outside `[0, SHARED_BYTES)` | byte address (workgroup-relative) |
| `F_STACK_OVERFLOW` | divergent branch needs more stack entries than exist | current depth |
| `F_BAR_DIVERGENT` | `bar` with `active != live` | the live mask |
| `F_TRAP` | `trap` executed | the 16-bit code |
| `F_WATCHDOG` | `WDOG_LIMIT` cycles elapsed | elapsed cycles |

### What is latched

On the **first** fault since reset (later ones are ignored):

| Register | Content |
|---|---|
| `FAULT_CODE` | the `F_*` code |
| `FAULT_LOC` | `[7:0]` EG, `[15:8]` warp slot, `[23:16]` lane: the lowest failing lane for per-lane faults, otherwise the lowest active lane. `0xFFFFFF` for `F_WATCHDOG` (device-level). |
| `FAULT_PC` | instruction index (0 for the watchdog) |
| `FAULT_WG` | workgroup id of the faulting warp (0 for the watchdog) |
| `FAULT_MASK` | the warp's active mask when the fault occurred (0 for the watchdog) |
| `FAULT_DATA` | as in the table |

### What happens next

1. The device enters `FAULTED`: `STATUS.BUSY=0`, `STATUS.FAULTED=1`, `INT_STATUS.FAULT=1`. No further instruction issues in the
   reference model; an implementation MAY let instructions that issued in the same cycle in other EGs retire.
2. **Memory after a fault is unspecified**: stores of other warps made before the fault may or may not be visible, and
   `STATUS.DONE` stays 0. Only the faulting instruction is guaranteed to have had no effect. Software must treat the launch's
   outputs as invalid.
3. Global memory stays accessible through the aperture (to read data back for debugging).
4. New doorbells are rejected with `LE_FAULTED`; the fault registers are *not* overwritten by such a rejection.
5. The only way out is `CTRL.SOFT_RESET`.

If several warps fault in the same cycle, the reported fault is the one in the **lowest-numbered EG, then the lowest warp slot**;
the others are discarded. (The reference model issues one warp per EG per tick and stops stepping EGs after the first fault, so ties
within an EG cannot occur; instructions committed by lower-numbered EGs earlier in the faulting tick do count in `PERF_ISSUED`.)
An execution fault in a cycle takes precedence over completion and over the watchdog ([05](05-scheduling-sync.md) 5.7).

## 8.3 Reset

| | Hard reset (power-up / `rst_n`) | Soft reset (`CTRL.SOFT_RESET`) |
|---|---|---|
| All registers (`INT_*`, `LAUNCH_*`, `FAULT_*`, `PERF_*`, `SCRATCH`) | reset values | reset values |
| `WDOG_LIMIT` | `WDOG_RESET_TICKS` | `WDOG_RESET_TICKS` |
| Running launch, warps, stacks, barriers, workgroup slots | cleared | **aborted and cleared** |
| Shared memory | undefined | undefined |
| Global memory | **undefined** | **preserved** |
| `STATUS.READY` | 0 for `RESET_TICKS`, then 1 | 0 for `RESET_TICKS`, then 1 |

* During reset (`READY=0`) valid register writes are ignored (including a second `SOFT_RESET`) and aperture accesses are rejected;
  an invalid access still sets `INT_STATUS.HOST_ERR`, which survives the reset ([07](07-registers-interrupts.md) 7.2).
  Every register can be read and returns its reset value (`STATUS.READY = 0`).
* Soft reset is the recovery path from a fault, a hung kernel (watchdog or not) and any confused host state.
* The reference model fills **global memory** with `0xDEADBEEF` at power-up and poisons each workgroup's **shared** slot at dispatch
  (unless `SMEM_ZERO` is set), so a kernel that relies on uninitialised memory fails loudly. Hardware may contain anything.

## 8.4 Device state machine

| From | Event | To | Visible effect |
|---|---|---|---|
| `RESET` | `RESET_TICKS` elapsed | `IDLE` | `STATUS.READY=1` |
| `IDLE` | doorbell accepted | `LAUNCHING` | `BUSY=1`, `DONE=0`, counters cleared, `LAUNCH_ERR=0` |
| `LAUNCHING` | descriptor invalid | `IDLE` | `BUSY=0`, `LAUNCH_ERR=LE_*`, `INT_STATUS.LAUNCH_ERR` |
| `LAUNCHING` | descriptor valid | `RUNNING` | code loaded into every EG |
| `RUNNING` | all workgroups complete | `IDLE` | `BUSY=0`, `DONE=1`, `INT_STATUS.DONE` |
| `RUNNING` | execution fault or watchdog | `FAULTED` | `BUSY=0`, `FAULTED=1`, `FAULT_*` latched, `INT_STATUS.FAULT` |
| `LAUNCHING`, `RUNNING` | doorbell | unchanged | `LAUNCH_ERR=LE_BUSY`, `INT_STATUS.LAUNCH_ERR` |
| `FAULTED` | doorbell | unchanged | `LAUNCH_ERR=LE_FAULTED`, `INT_STATUS.LAUNCH_ERR` |
| any state except `RESET` | `CTRL.SOFT_RESET` | `RESET` | everything cleared as in 8.3 |

`IDLE` with `STATUS.DONE=1` means "idle after a successful launch". Power-up enters `RESET`.

## 8.5 Fault injection in the test suite

Each fault code has a directed test in `sim/tests/test_model.py` (class `Faults`, plus `MemorySpaces`, `Barriers`):
illegal opcode / reserved bits / zero `roff`, fall-off-the-end (including a kernel of exactly `IMEM_WORDS` instructions),
branch target range, reconvergence violation, trap, stack overflow (small configuration), watchdog, alignment and range for both
memory spaces (with precision and lane-priority checks), divergent barrier. `sw/tests/test_host.c` repeats the fault, watchdog,
launch-error and reset paths through the C host.
