# 3. Execution masks and branch reconvergence

Reference implementation: `sim/sfg1/simt.py` (class `SimtStack`). The RTL block `sf_g1_simt_stack`
is verified against it command by command. This chapter is normative; where prose and code could
disagree, the code and vectors are the arbiter and the prose is a bug.

## 3.1 State of a warp

* `live` — `LANES`-bit mask of threads that have not exited.
* a stack of **entries** `(pc, rpc, mask)`, at most `SIMT_STACK_DEPTH` deep:
  * `pc` — next instruction of the lanes in this entry;
  * `rpc` — *reconvergence PC*: where the lanes of this entry meet the entry below it
    (`RPC_NONE = IMEM_WORDS + 1`, larger than any reachable pc, for the bottom entry);
  * `mask` — the lanes this entry covers.

The **top entry** is the executing path. Its `pc` is the warp's PC and **`active = top.mask & live`**.
Entries below the top are either *pending paths* (waiting to run) or *reconvergence entries* (waiting for
the paths above them to arrive).

A warp starts with one entry `(ENTRY_PC, RPC_NONE, launch mask)` and `live = launch mask`.
It is done when the stack is empty.

## 3.2 Control commands

Each issued instruction updates the stack with exactly one command (this is also the interface of the
RTL block):

| Command | Issued by | Effect |
|---|---|---|
| `SEQ` | every instruction except `bra`, `bz`, `bnz`, `exit` and `trap` (`bar` issues it on arrival; `trap` faults and issues nothing) | `top.pc <- top.pc + 1` |
| `JUMP t` | `bra` | `top.pc <- t` |
| `BRANCH cond, t, R` | `bz`, `bnz` | see 3.3 |
| `EXIT` | `exit` | `live <- live & ~active` |

After **every** command the stack is *resolved* (3.4).

## 3.3 Branches

`BRANCH` carries `cond` (bit *i* set when lane *i* is taken), target `t` and reconvergence address `R`.
Let `pc` be the top's pc, `act = top.mask & live`, `T = act & cond` (taken), `N = act & ~cond` (fall through).

```
if T == 0:            top.pc <- pc + 1                      # nobody takes it
elif N == 0:          top.pc <- t                           # everybody takes it
else:                                                       # divergence
    paths = []
    if pc + 1 != R:   paths.append((pc + 1, R, N))          # fall-through path   (runs second)
    if t      != R:   paths.append((t,      R, T))          # taken path          (runs first, on top)
    reuse  = (top.rpc == R)
    needed = max(len(paths) - 1, 0) if reuse else len(paths)
    if depth + needed > SIMT_STACK_DEPTH:  FAULT F_STACK_OVERFLOW (no state change)
    if reuse:                                               # top already reconverges at R
        if paths:  replace top with paths[0]; push paths[1:]
        else:      top.pc <- R
    else:
        top.pc <- R                                         # top becomes the reconvergence entry
        push all of paths
```

Notes:

* A path whose first instruction **is** the reconvergence address is not pushed: its lanes simply wait in the
  entry below (this is the `if (c) {...}` case where `target == reconv`, and the loop exit case where the
  fall-through is the reconvergence address).
* **Reuse.** If the top entry already reconverges at `R` the lanes that wait are covered by an entry further
  down, so no new reconvergence entry is created. This is what keeps loops at constant stack depth.
* The taken path executes first; the fall-through path runs after it. Which path goes first is
  *unspecified* to software (correct programs cannot tell), but fixed in the model and in the vectors.

## 3.4 Resolution

```
while stack not empty:
    top = stack.top
    if (top.mask & live) == 0  or  top.pc == top.rpc:  pop
    else: break
```

A path that reaches its reconvergence address is popped, exposing the next pending path, or the
reconvergence entry whose `pc` is `R` with the full mask of the lanes that diverged. An entry with no live lanes left is
dropped. A hardware implementation may take several cycles to resolve; the settled state is what is architectural.

## 3.5 Fetch-time layout check

Before an instruction executes: if `top.rpc != RPC_NONE` and `top.pc > top.rpc` the warp faults with
`F_RECONV` (`FAULT_DATA = rpc`). A correct program never runs a path past its reconvergence address,
so this catches a wrong `reconv` operand at the moment it matters instead of silently executing the wrong code.
(A settled entry never has `pc == rpc`, because such an entry is popped.)

## 3.6 Choosing the reconvergence address

`reconv` MUST be the **immediate post-dominator** of the branch: the first instruction that every path
leaving the branch is guaranteed to pass through (or leave the kernel before reaching). For structured code:

| Construct | Branch | `target` | `reconv` |
|---|---|---|---|
| `if (c) { A }` | `bz c, L_end, L_end` (skip `A` when `c == 0`) | `L_end` | `L_end` |
| `if (c) { A } else { B }` | `bz c, L_else, L_end` ... `A` ... `bra L_end` ... `L_else: B` ... | `L_else` | `L_end` |
| `do { body } while (c)` (back-edge) | `bnz c, L_top, L_exit` as the last instruction of the loop; `L_exit` is the next instruction | `L_top` | `L_exit` (= fall-through) |
| `while (c) { body }` | test at top: `bz c, L_exit, L_exit` ... body ... `bra L_top` | `L_exit` | `L_exit` |
| `break` in a loop | `bnz b, L_exit, L_exit` | `L_exit` | `L_exit` |
| early thread exit | `bnz c, L_go, L_go` then `exit` then `L_go:` | `L_go` | `L_go` |

**A `break` (or any early leave of a loop) changes the post-dominator of every enclosing `if` inside that loop.**
Paths that break out of the loop do not pass through the `if`'s `endif`, so the enclosing `if` branches must
use the *loop exit* as `reconv`, not their own `endif`:

```
loop:  ...
       bz  c, L_endif, L_exit      ; reconv = L_exit (NOT L_endif): the arm below may break out
       bnz b, L_exit, L_exit       ; break
       ...
L_endif: ...
       bra loop
L_exit:
```

`sim/tests/test_differential.py` generates random structured programs that follow this rule and checks
the SIMT model against a per-thread oracle (see 3.9).

**Layout rule.** While a path with reconvergence address `R` runs, its `pc` never exceeds `R`: the code
between a branch and its reconvergence address is laid out in increasing address order, and `target <= reconv`
for forward branches. The assembler warns when `target > reconv`; the machine faults (`F_RECONV`) if a path
overruns.

## 3.7 Worked examples

**If/else** (`LANES = 8`; lanes 0-3 take the branch to `else`):

```
 2: bz  r1, else, endif   ; else = 6, endif = 9
 3: ... then ...
 4: ...
 5: bra endif
 6: else: ...
 7: ...
 8: ...
 9: endif:
```

| After | Stack, top first: `(pc, rpc, mask)` | Active |
|---|---|---|
| start at pc 2 | `(2, -, FF)` | `FF` |
| the divergent `bz` | `(6, 9, 0F)` `(3, 9, F0)` `(9, -, FF)` | `0F` (else lanes) |
| else path reaches 9 -> pop | `(3, 9, F0)` `(9, -, FF)` | `F0` (then lanes) |
| `bra 9` reaches 9 -> pop | `(9, -, FF)` | `FF`, reconverged |

**Loop with a per-lane trip count** (body at 0..28, back-edge `bnz r, 0, 30` at 29, one more lane leaves each trip):

| After | Stack, top first | Active |
|---|---|---|
| trip 0, lane 0 leaves | `(0, 30, FE)` `(30, -, FF)` | `FE` |
| trip 1, lane 1 leaves | `(0, 30, FC)` `(30, -, FF)` | `FC` |
| trip 2, lane 2 leaves | `(0, 30, F8)` `(30, -, FF)` | `F8` |
| last lanes leave | `(30, -, FF)` | `FF` |

The depth stays at 2 however many lanes drop out.

## 3.8 Exit and divergence

`exit` clears the active lanes from `live`. They are then ignored by every entry (entries are masked with `live`
when they run, and entries left with no live lane are dropped by resolution). Consequences:

* lanes that exit inside one arm of an `if` simply never arrive at the join: the others reconverge without them;
* if all lanes of the top entry exit, that path ends and the next pending path (or the reconvergence entry) runs;
* the warp is done when the stack becomes empty (which implies `live = 0`).

## 3.9 Stack depth

For **any** command stream (even ill-formed ones) the depth never exceeds `2 x LANES - 1`: every divergence
splits the active live lanes into two strictly smaller non-empty groups, so the entries form a binary tree over
at most `LANES` lanes, whose frontier has at most `2L - 1` nodes. The bound is property-tested
(`test_depth_never_exceeds_two_lanes_minus_one`) and used by the differential test (a stack of exactly
`2 x LANES - 1` entries never overflows).

Therefore **`SIMT_STACK_DEPTH >= 2 x LANES - 1` makes `F_STACK_OVERFLOW` impossible**. Smaller stacks save area
and are legal; programs then risk the fault (the `small` configuration has depth 4 with 4 lanes so
overflow is reachable and tested). Typical structured code needs `1 + 2 x (divergent nesting depth)` entries.

## 3.10 What diverged lanes may and may not do

* Within a warp, diverged paths execute **serially**, never concurrently. A lane may not wait for another lane
  of the same warp that is on a different path (e.g. a spin lock between lanes): the waiting path can run first
  and never yield. SF-G1 gives **no forward-progress guarantee between diverged lanes of one warp**.
* `bar` is illegal while any live lane is inactive (`F_BAR_DIVERGENT`). Reconverge before a barrier.
* Per-warp state is independent: warps of a workgroup interact only through shared memory, global memory, and barriers.

## 3.11 How this is checked

| Check | Where |
|---|---|
| unit scenarios (if/else, loops, exit, overflow, layout) | `sim/tests/test_simt_unit.py` |
| depth bound over random streams, 4/8/16 lanes | same file |
| semantics of real programs vs a per-thread oracle (390 random programs on the default and wide configurations; 5 injected stack bugs all detected) | `sim/tests/test_differential.py` |
| RTL stack vs the model: kernel-derived and random command streams, all configs, 8 injected RTL bugs all detected | `verification/blocks.json` block `simt_stack` |
