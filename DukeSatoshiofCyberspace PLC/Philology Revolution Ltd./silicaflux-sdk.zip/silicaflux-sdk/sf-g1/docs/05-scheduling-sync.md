# 5. Scheduling and synchronisation

## 5.1 Launch-level dispatch

A launch consists of `grid_dim` workgroups. The **launch unit** assigns them to EGs:

1. Workgroups are dispatched **in order of workgroup id**. A workgroup is never dispatched before a lower-numbered one.
2. A workgroup needs: one free workgroup slot **and** `ceil(wg_dim / LANES)` free warp slots **on the same EG**
   (shared memory is pre-partitioned per slot, so slots are the only shared-memory accounting needed).
3. The reference policy picks the **lowest-numbered EG** that has both. If none can take the next workgroup, dispatch
   waits (it does not skip ahead). The reference model dispatches at most one workgroup per tick.
4. Within the chosen EG, the workgroup takes the lowest free workgroup slot, and its warps take the lowest free warp slots.
5. At dispatch, shared memory is zeroed (`SMEM_ZERO` flag) or left undefined; registers are zeroed; each warp's stack is
   initialised to `(ENTRY_PC, RPC_NONE, live lanes)`.
6. When every warp of a workgroup is done, the workgroup slot and its warp slots are released.
   (Done warps keep their slot until then but are ignored by the barrier logic.)
7. The launch completes when all workgroups have been dispatched and completed.

Which EG or slot a workgroup lands on is **not** observable by a correct kernel; it is visible only in `FAULT_LOC` and in the
trace's debug fields. The dispatch order and EG choice above are the reference policy; an implementation MAY use any
policy that respects (1) and (2).

## 5.2 Warp states

```
              issue: stays READY
  READY ──── executes bar ────────▶ BARRIER_WAIT ── barrier releases ──▶ READY
  READY ──── stack becomes empty ─▶ DONE
```

Only `READY` warps may issue. A warp in `BARRIER_WAIT` is not schedulable until its workgroup's barrier releases it.

## 5.3 Warp scheduling

Each EG issues **at most one warp instruction per cycle** (per tick in the reference model).

Reference policy: **loose round-robin**. The scheduler remembers the slot it issued last and scans the warp slots
starting at the next one, wrapping around; it issues the first `READY` warp it finds. If none is ready it idles for the cycle.
The remembered slot is set to the **last** slot of the EG at every accepted doorbell (and at reset), so a launch's schedule, and
therefore the `FAULT_LOC` it reports, never depends on earlier launches.

**Scheduling is not architectural.** Any work-conserving policy is permitted so long as every warp that is `READY`
eventually issues (no starvation), and an instruction issues only after the warp's previous instruction has completed or
is known not to conflict (in-order issue per warp; scoreboarding is an implementation matter). What is architectural:

* per-warp instruction order and results (the **commit trace**, [09](09-verification.md));
* the effects of barriers, atomics and fences ([04](04-memory.md));
* final memory contents for race-free kernels.

## 5.4 Barriers

`bar` synchronises all live threads of one workgroup.

* **Arrival.** A warp *arrives* by executing `bar` with `active == live` (all lanes that have not exited are active). If some live
  lane is not active, the warp faults with `F_BAR_DIVERGENT` and `FAULT_DATA = live mask`.
  On arrival the warp advances past the `bar` and enters `BARRIER_WAIT`.
* **Participants.** The barrier waits for every warp of the workgroup that is not done. Warps (and individual lanes) that
  have exited do **not** take part, so an `exit` in one warp cannot deadlock the others.
* **Release.** When every non-done warp of the workgroup is in `BARRIER_WAIT` the barrier releases: all of them become
  `READY` together. The same check is repeated when a warp finishes, so a warp that exits while others wait releases them.
* **Memory.** A barrier is a release/acquire fence for the workgroup (C4).
* **Reuse.** Barriers can be executed repeatedly (in loops). Each workgroup has its own barrier; warps of different
  workgroups never wait for each other.
* **Barrier counts are not checked.** If some warps execute `bar` more times than others, the extra arrivals are released as
  soon as the other warps exit (a done warp does not take part). A workgroup hangs only if a warp that has not exited
  never reaches a `bar` the others are waiting at; the watchdog is then the only recovery.

Divergence before a barrier is a **fault**, not undefined behaviour, so hardware can use a simple per-warp arrival bit.

## 5.5 Fences and atomics in scheduling

`fence` has no scheduling effect in the reference model. A pipelined implementation drains the warp's outstanding memory
operations (and keeps the warp unschedulable) until they are globally visible. `atomadd` has no scheduling effect beyond C5.

## 5.6 Forward progress

* Every `READY` warp eventually issues (no starvation within an EG).
* A warp that executes a finite instruction sequence terminates; infinite loops are stopped only by the watchdog.
* **Within a warp**, no guarantee between diverged paths ([03](03-execution-model.md) 3.10).
* **Between warps of a workgroup**: guaranteed if they are all resident (they always are: a workgroup is dispatched whole).
* **Between workgroups**: none. A workgroup may run before, after or concurrently with any other.

## 5.7 Watchdog

`WDOG_LIMIT` (reset value: `WDOG_RESET_TICKS`; 0 disables) bounds the time of a launch. *Elapsed* time counts from the accepted
doorbell and includes the launch phase. At the end of each running cycle, if the launch has not completed and
`elapsed >= WDOG_LIMIT`, the device raises fault `F_WATCHDOG` with `FAULT_DATA = elapsed` and `FAULT_LOC = 0xFFFFFF`
(device-level). The watchdog is not evaluated during the launch phase, so the earliest it can fire is the end of the first running cycle
(`WDOG_LIMIT = 1` fires at elapsed 2 in the reference model).

**Precedence within one cycle:** an execution fault wins over completion, and completion wins over the watchdog
(a launch that finishes in the cycle the limit is reached is a success). `WDOG_LIMIT` is read continuously, so changing it while
the launch runs changes the limit.

The reference model counts ticks; an implementation counts its own clock cycles, so watchdog timing is the one place where
reference and hardware numbers are not comparable.
Conformance tests that must not time out use `WDOG_LIMIT = 0` or a large value.
