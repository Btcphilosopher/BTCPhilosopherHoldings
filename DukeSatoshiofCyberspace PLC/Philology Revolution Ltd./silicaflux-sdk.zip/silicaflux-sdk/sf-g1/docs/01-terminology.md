# 1. Terminology

These definitions are normative. They are the only meanings of these words in SF-G1 documents,
code and interfaces.

## 1.1 Thread

A **thread** is the unit of software execution: one instance of the kernel with its own 16
general registers (`r0`..`r15`, `r0` reads as zero) and its own values of the special registers
(identity, geometry, arguments). Threads do not share registers.

* A thread belongs to exactly one workgroup, occupies exactly one lane of exactly one warp, and never
  moves for its whole lifetime.
* A thread has no program counter of its own. Its next instruction is determined by the warp's
  reconvergence stack ([03](03-execution-model.md)): a thread is *active* when its lane is in the
  warp's active mask, and *waiting* when it sits in a stack entry below the top.
* A thread ends when it executes `exit`. It cannot be restarted and does not take part in barriers
  afterwards.

## 1.2 Lane

A **lane** is one of the `LANES` parallel datapath positions of a warp, numbered `0 .. LANES-1`.
Lane *i* of a warp owns the register file slice, the ALU and the memory port that serve the thread
in position *i*.

* A lane is a *position*, not a thread of control. "Lane 3 is active" means "the thread in position 3 of
  this warp executes the current instruction".
* Masks are `LANES`-bit vectors indexed by lane: bit *i* describes lane *i*.
* `LANES` is a configuration parameter: 4, 8, 16 or 32 (default 8).

## 1.3 Warp

A **warp** is a group of exactly `LANES` consecutive threads of one workgroup that share one instruction
stream (one reconvergence stack) and issue together. It is the unit of scheduling: the scheduler picks a
warp, the warp issues **one instruction** for all of its active lanes.

* Thread `tid` of a workgroup is in warp `tid / LANES`, lane `tid % LANES`.
* A workgroup of `wg_dim` threads has `ceil(wg_dim / LANES)` warps. If `wg_dim` is not a multiple of
  `LANES`, the last warp is *partial*: its upper lanes hold no thread and are never live.
* A warp is *done* when its live mask is empty.

## 1.4 Workgroup

A **workgroup** is a set of `1 .. MAX_WG_THREADS` threads (`MAX_WG_THREADS = LANES x WARPS_PER_EG`) that
are launched together onto **one execution group**, stay there until all of them have exited, share one
region of shared memory, and can synchronise with each other with `bar`.

* Workgroups are numbered `0 .. grid_dim-1` in the grid (`SR_WG_ID`).
* All workgroups of a launch have the same `wg_dim` and the same shared-memory size.
* Threads of different workgroups cannot synchronise during a launch. Their only defined interaction is
  through global-memory atomics ([04](04-memory.md)). A workgroup may not assume any other workgroup is running.

## 1.5 Grid, kernel, launch

* A **kernel** is a code image (a sequence of 32-bit instructions) plus an entry instruction index.
* A **grid** is the set of `grid_dim` workgroups of one launch.
* A **launch** is one execution of one kernel over one grid, described by a launch descriptor
  ([06](06-launch.md)). The device runs one launch at a time.

Total threads of a launch: `grid_dim x wg_dim`. Global thread id: `gtid = wg_id x wg_dim + tid`
(mod 2^32, `SR_GTID`). Grids and workgroups are one-dimensional.

## 1.6 Execution group

An **execution group (EG)** is a replicated compute cluster. Each EG contains:

* `WARPS_PER_EG` warp slots, each holding one warp's registers and reconvergence stack;
* `WG_SLOTS_PER_EG` workgroup slots, each with its own barrier state and an equal share of the EG's
  `SMEM_BYTES_PER_EG` shared memory;
* one instruction memory (`IMEM_WORDS` words) holding the kernel's code;
* a warp scheduler that issues at most one warp instruction per cycle.

`NUM_EG` EGs (default 2) share the global memory and the launch unit. A workgroup runs on exactly one EG.

## 1.7 Masks

| Mask | Meaning |
|---|---|
| **live mask** | lanes whose thread has not executed `exit` (initially: lanes that hold a thread) |
| **active mask** | lanes that execute the current instruction: `top.mask & live` |
| **entry mask** | lanes covered by one reconvergence-stack entry |

Inactive lanes are architecturally untouched by an instruction: no register write, no memory access, no
fault contribution.

## 1.8 Time

The reference model advances in **ticks**: one tick is one scheduling round in which every EG issues
at most one warp instruction and finishes it. Ticks are the unit of `PERF_CYCLES` and the watchdog in
the reference model. A hardware implementation uses its own clock cycles; the two are not required to
agree, except that the watchdog and `PERF_CYCLES` count the implementation's own cycles
([05](05-scheduling-sync.md)).

## 1.9 Worked example (default configuration)

`LANES = 8`, `wg_dim = 20`, `grid_dim = 3`:

| Workgroup | Warp | Threads (`tid`) | Live lanes | Live mask |
|---|---|---|---|---|
| any | 0 | 0..7 | 0..7 | `0xFF` |
| any | 1 | 8..15 | 0..7 | `0xFF` |
| any | 2 | 16..19 | 0..3 | `0x0F` (partial) |

Thread 19 of workgroup 2 has `SR_TID = 19`, `SR_WARP_ID = 2`, `SR_LANE_ID = 3`, `SR_WG_ID = 2`,
`SR_GTID = 2 x 20 + 19 = 59`. A 20-thread workgroup occupies 3 warp slots and one workgroup slot of
one EG; with 4 warp slots and 2 workgroup slots per EG, no second 20-thread workgroup fits on that EG
(it needs 3 more warp slots), so the next one goes to the other EG.

## 1.10 Invariants

1. Every thread is bound to one (workgroup, warp, lane) for life.
2. `active ⊆ live` at all times; a warp whose stack is empty has `live = 0`.
3. Lanes `>= wg_dim - warp_id x LANES` of a partial warp are never live.
4. Every warp of a workgroup resides in the same EG; a workgroup slot is released only when all of its
   warps are done.
5. Registers are zero at thread start.
