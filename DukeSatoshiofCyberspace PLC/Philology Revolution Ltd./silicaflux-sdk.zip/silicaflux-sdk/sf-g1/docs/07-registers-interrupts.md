# 7. Device registers and interrupts

The host interface has two windows:

* **BAR0** — 4 KiB of 32-bit registers (this chapter). Registers are at word-aligned byte offsets; only offsets up to `0x0F0` are used.
* **BAR1** — the global-memory aperture ([04](04-memory.md) 4.7).

The register table with offsets, access types, reset values and bit fields is
[generated/device_reference.md](generated/device_reference.md) (from `spec/sf_g1_device.json`); the SystemVerilog and C
definitions are generated from the same file.

## 7.1 Register groups

| Group | Registers |
|---|---|
| Identification | `ID` (`0x31474653`, "SFG1"), `VERSION` (1.0.0), `CFG_HASH` |
| Capabilities (read-only) | `CAPS_GEOM`, `CAPS_SMEM`, `CAPS_IMEM`, `CAPS_GMEM`, `CAPS_LIMITS` |
| Control and status | `CTRL`, `STATUS` |
| Interrupts | `INT_STATUS`, `INT_ENABLE` |
| Launch | `LAUNCH_ADDR`, `DOORBELL`, `LAUNCH_ERR`, `WDOG_LIMIT` |
| Fault report | `FAULT_CODE`, `FAULT_LOC`, `FAULT_PC`, `FAULT_WG`, `FAULT_MASK`, `FAULT_DATA` |
| Performance | `PERF_CYCLES`, `PERF_ISSUED`, `PERF_LANE_OPS`, `WG_DISPATCHED`, `WG_COMPLETED` |
| Bring-up | `SCRATCH` |

## 7.2 Access rules

* All accesses are 32-bit and word-aligned.
* **Unmapped or misaligned** offsets: reads return 0, writes are ignored, and `INT_STATUS.HOST_ERR` is set.
* **RO** registers ignore writes (no error). **WO** (`DOORBELL`) reads as 0. **W1C** (`INT_STATUS`): writing 1 to a bit clears it.
* `CTRL.SOFT_RESET` is write-1-to-trigger and reads as 0. `INT_ENABLE` keeps only bits `[3:0]`.
* **While `STATUS.READY = 0` (reset in progress) every valid register write is ignored**; every register can still be read (it returns its
  reset value). The invalid-access check comes first: an unmapped or misaligned offset, or an aperture access, during reset still sets
  `INT_STATUS.HOST_ERR`, and that bit then survives the end of the reset (it is not cleared a second time).
* `LAUNCH_ADDR` is latched when a doorbell is accepted, so writing it afterwards is harmless. `WDOG_LIMIT` is read
  continuously by the watchdog: changing it while `BUSY=1` changes the limit of the running launch. Set it while idle.

## 7.3 `STATUS`

| Bit | Name | Meaning |
|---|---|---|
| 0 | `READY` | 1 when register writes are accepted; 0 for `RESET_TICKS` after reset |
| 1 | `BUSY` | 1 from an accepted doorbell until completion, fault or launch rejection |
| 2 | `DONE` | the last accepted launch completed; cleared by the next accepted doorbell and by reset |
| 3 | `FAULTED` | an execution fault occurred; cleared only by `SOFT_RESET` |
| 4 | `IRQ` | the interrupt output level, `|(INT_STATUS & INT_ENABLE)` |

Legal combinations: `READY` alone (idle), `READY|BUSY` (running), `READY|DONE` (idle after success), `READY|FAULTED`, and `0` (resetting).

## 7.4 Capabilities and `CFG_HASH`

Software reads the geometry and limits from the `CAPS_*` registers instead of assuming them. `CFG_HASH` is the CRC-32 of
the canonical, documentation-free JSON of the configuration, ISA and device specification the hardware was built from. The
same constant is generated into `sf_g1_pkg.sv`, `sf_g1_config.h`, and computed by the Python model. A host built against
generated headers compares them at `sfg1_open()` and refuses a mismatched device (`SFG1_E_CFG_MISMATCH`); this is how
"software built for a different configuration" is caught at run time rather than by wrong results.

## 7.5 Interrupts

One output line, **`irq = |(INT_STATUS & INT_ENABLE)`**, level-sensitive.

| `INT_STATUS` bit | Name | Set when |
|---|---|---|
| 0 | `DONE` | a launch completes |
| 1 | `FAULT` | an execution fault is latched |
| 2 | `LAUNCH_ERR` | a doorbell is rejected or a descriptor fails validation |
| 3 | `HOST_ERR` | an illegal register or aperture access |

Bits are sticky until written 1. Events that occur while a bit is already set are not queued. `INT_STATUS` and `INT_ENABLE` are cleared by reset.

Recommended handler: read `INT_STATUS`; for `DONE` read the results; for `FAULT` read the `FAULT_*` registers then `SOFT_RESET`; for
`LAUNCH_ERR` read `LAUNCH_ERR`; write the handled bits back to clear them.

## 7.6 Performance counters

Cleared at each accepted doorbell. 32 bits, wrapping.

* `PERF_CYCLES` — device cycles while `BUSY` (including the launch phase).
* `PERF_ISSUED` — warp instructions committed (not counting the one that faults).
* `PERF_LANE_OPS` — sum over committed warp instructions of `popcount(active mask)`.
* **SIMT efficiency** = `PERF_LANE_OPS / (PERF_ISSUED x LANES)`: 1.0 means no lane was ever masked off.
  The `diverge` example runs at 0.49, `vecadd` at 0.98.
* `WG_DISPATCHED`, `WG_COMPLETED` — workgroup progress.

`PERF_ISSUED` and `PERF_LANE_OPS` are architectural for race-free kernels (they depend only on the program, the data and the
configuration's `LANES`); `PERF_CYCLES` is implementation timing.

## 7.7 Programming sequence for a host driver

```
reset / power-up:   poll STATUS.READY
bring-up:           read ID, CFG_HASH, CAPS_*; check against the compiled-in configuration
launch:             write code+data+descriptor via the aperture; LAUNCH_ADDR; DOORBELL
completion:         poll STATUS.BUSY==0 (or wait for irq); then
                      LAUNCH_ERR != 0?  this submission was rejected: read LAUNCH_ERR
                      FAULTED?  read FAULT_*; SOFT_RESET
                      DONE?  read results from the aperture
                    (LAUNCH_ERR reflects the most recent submission only; a stray second doorbell while BUSY leaves
                     LE_BUSY in it, so submit one launch at a time and test it only after that single submission)
```
