#!/usr/bin/env python3
"""Run RTL conformance for every block in verification/blocks.json.

For each configuration: generate the package/decoder (non-default configs go to
build/<cfg>/), generate model vectors, compile each testbench with Icarus
Verilog, run it against the vectors and require `TB_RESULT <block> PASS`.
Verilator lint (-Wall) is run on all RTL when available.

    tools/run_rtl.py                      default config
    tools/run_rtl.py --config small wide  other configs
    tools/run_rtl.py --lint-only
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "sim"))
sys.path.insert(0, str(ROOT / "tools"))

from sfg1.spec import Config  # noqa: E402
from sfg1.vectors import write_vectors  # noqa: E402
import gen as genmod  # noqa: E402


def registry():
    return json.loads((ROOT / "verification" / "blocks.json").read_text())["blocks"]


def rtl_tree(cfg: Config) -> Path:
    """Directory holding rtl/gen/ for this config (the source tree for 'default')."""
    if cfg.name == "default":
        return ROOT
    out = ROOT / "build" / cfg.name
    for rel, text in genmod.generate(cfg, include_docs=False).items():
        p = out / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)
    return out


def sources(gen_root: Path, rtl_root: Path = ROOT):
    """Package first, then every RTL file listed in the registry (verified blocks only)."""
    files = [gen_root / "rtl/gen/sf_g1_pkg.sv"]
    for b in registry():
        if b["status"] != "verified":
            continue
        rel = b["rtl"]
        p = (gen_root / rel) if rel.startswith("rtl/gen/") else (rtl_root / rel)
        if p not in files:
            files.append(p)
    return files


def run_block(block, cfg, gen_root, vec_dir, obj_dir, rtl_root=ROOT, verbose=False) -> bool:
    obj_dir.mkdir(parents=True, exist_ok=True)
    tb = ROOT / block["testbench"]
    vvp = obj_dir / f"tb_{block['id']}.vvp"
    cmd = ["iverilog", "-g2012", "-o", str(vvp), *map(str, sources(gen_root, rtl_root)), str(tb)]
    c = subprocess.run(cmd, capture_output=True, text=True)
    if c.returncode != 0:
        print(f"  [{cfg.name}] {block['id']}: COMPILE FAIL\n{c.stderr}")
        return False
    r = subprocess.run(["vvp", str(vvp), f"+VEC={vec_dir / (block['vectors'] + '.vec')}"], capture_output=True, text=True)
    line = next((l for l in r.stdout.splitlines() if l.startswith("TB_RESULT")), "TB_RESULT ? FAIL no result line")
    ok = line.startswith(f"TB_RESULT {block['id']} PASS")
    print(f"  [{cfg.name}] {block['id']:<11s} {'PASS' if ok else 'FAIL'}  {line.split(' ', 3)[-1]}")
    if not ok:
        print("\n".join(r.stdout.splitlines()[:15]))
    return ok


def lint(cfg, gen_root) -> bool:
    if not shutil.which("verilator"):
        print("  verilator not found: lint skipped")
        return True
    ok = True
    for b in registry():
        if b["status"] != "verified":
            continue
        cmd = ["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "-Wno-UNUSEDPARAM", "-Wno-UNUSEDSIGNAL",
               "--top-module", b["top"], *map(str, sources(gen_root))]
        r = subprocess.run(cmd, capture_output=True, text=True)
        bad = r.returncode != 0 or "%Warning" in r.stderr
        print(f"  [{cfg.name}] lint {b['top']:<18s} {'FAIL' if bad else 'clean'}")
        if bad:
            ok = False
            print(r.stderr[:2000])
    return ok


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", nargs="*", default=["default"])
    ap.add_argument("--lint-only", action="store_true")
    ap.add_argument("--no-lint", action="store_true")
    a = ap.parse_args(argv)
    if not shutil.which("iverilog"):
        print("iverilog not found: install Icarus Verilog >= 12 (see docs/09-verification.md)", file=sys.stderr)
        return 2
    allok = True
    for name in a.config:
        cfg = Config.from_file(name)
        gen_root = rtl_tree(cfg)
        print(f"config {cfg.name} (CFG_HASH 0x{cfg.cfg_hash():08x})")
        if not a.no_lint:
            allok &= lint(cfg, gen_root)
        if a.lint_only:
            continue
        vec_dir = ROOT / "build" / cfg.name / "vectors"
        write_vectors(cfg, vec_dir)
        for b in registry():
            if b["status"] == "verified":
                allok &= run_block(b, cfg, gen_root, vec_dir, ROOT / "build" / cfg.name / "obj")
    print("RTL CONFORMANCE:", "PASS" if allok else "FAIL")
    return 0 if allok else 1


if __name__ == "__main__":
    raise SystemExit(main())
