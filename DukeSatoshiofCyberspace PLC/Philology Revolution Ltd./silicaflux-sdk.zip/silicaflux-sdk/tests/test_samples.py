"""Sample kernels: shipped binaries, host-checked results, and the same binaries on reference vs hardware model."""
import io
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

from sfsdk import cli, compare, samples
from sfsdk.binfmt import KernelImage
from sfsdk.compare import compare_scenario
from sfsdk.discovery import open_device

try:
    from sfsdk.hwmodel import HwModelTransport  # noqa: F401
    HAVE_HW = True
except Exception:                                    # pragma: no cover
    HAVE_HW = False


class ShippedBinaries(unittest.TestCase):
    def test_build_is_deterministic_and_matches_shipped_files(self):
        info = samples.compile_info()
        self.assertEqual(sorted(info), sorted(samples.source_names()))
        for name, i in info.items():
            self.assertTrue(i["matches_shipped_binary"], f"kernels/build/{name}.sfk is stale: run `python3 -c 'from sfsdk import samples; samples.build_all()'`")
            self.assertEqual(i["warnings"], [], name)

    def test_expected_sample_set(self):
        self.assertEqual(set(samples.source_names()),
                         {"vecadd", "histogram_global", "histogram_private", "reduce_sum", "reduce_max_pass1", "reduce_max_pass2",
                          "matmul_naive", "matmul_tiled", "spill_demo"})

    def test_spill_demo_really_spills_and_the_others_do_not(self):
        info = samples.compile_info()
        self.assertTrue(info["spill_demo"]["spilling"])
        self.assertGreaterEqual(info["spill_demo"]["spill_slots"], 5)
        self.assertEqual(info["spill_demo"]["spill_bytes_per_thread"], 64)
        for n, i in info.items():
            if n != "spill_demo":
                self.assertFalse(i["spilling"], n)
        img = samples.binary("spill_demo")
        self.assertEqual(img.meta.shared_per_thread, "64")
        with open_device("reference:default") as dev:                   # the SDK sizes the spill area from the metadata
            k = dev.load_kernel(img)
            a, o = dev.alloc(4 * 40), dev.alloc(4 * 40)
            self.assertEqual(k.bind(2, 20, [a, o, 40]).shared, 64 * 20)

    def test_binaries_carry_launch_metadata(self):
        img = samples.binary("matmul_tiled")
        self.assertEqual([a.name for a in img.meta.args], ["A", "B", "C", "M", "N", "K"])
        self.assertEqual(img.meta.args[0].elems, "M * K")
        self.assertEqual(img.meta.shared, "4*K")
        self.assertTrue(any("grid_dim == M" in r[0] for r in img.meta.requires))
        self.assertEqual(KernelImage.from_bytes(img.to_bytes()).words, img.words)

    def test_atomics_discard_their_result_so_traces_are_comparable(self):
        for n in samples.source_names():
            self.assertFalse(samples.binary(n).uses_order_dependent_atomics, n)

    def test_argument_validation_protects_sample_launches(self):
        from sfsdk.errors import ArgumentError
        with open_device("reference:default") as dev:
            k = dev.load_kernel(samples.binary("reduce_sum"))
            a, out = dev.alloc(400), dev.alloc(4)
            with self.assertRaises(ArgumentError) as cm:
                k.launch(4, 24, [a, out, 100])                         # wg_dim not a power of two
            self.assertEqual(cm.exception.code, "E_REQUIRE")
            with self.assertRaises(ArgumentError) as cm:
                k.launch(4, 32, [a, out, 101])                         # data buffer holds only 100 words
            self.assertEqual(cm.exception.code, "E_ARG_EXTENT")
            mm = dev.load_kernel(samples.binary("matmul_tiled"))
            M, N, K = 4, 1, 1100                                       # the A row needs 4*K = 4400 B; the default allows 4096 B per workgroup
            A, B, C = dev.alloc(4 * M * K), dev.alloc(4 * K * N), dev.alloc(4 * M * N)
            with self.assertRaises(ArgumentError) as cm:
                mm.launch(M, 8, [A, B, C, M, N, K])
            self.assertEqual(cm.exception.code, "E_SHARED")
            with self.assertRaises(ArgumentError) as cm:
                mm.launch(M + 1, 8, [A, B, C, M, N, 4])                # one workgroup per row is part of the kernel's contract
            self.assertEqual(cm.exception.code, "E_REQUIRE")


class SamplesOnReference(unittest.TestCase):
    def test_every_scenario_matches_host_golden_on_every_config(self):
        for cfg in ("default", "small", "wide"):
            with open_device(f"reference:{cfg}") as dev:
                for scn in samples.scenarios():
                    try:
                        out = scn.run(dev)
                    except compare.ScenarioSkip:
                        continue
                    for k, v in out.expected.items():
                        self.assertEqual(out.outputs[k], v, f"{scn.name} @ {cfg}: {k}")
                    self.assertEqual(dev.check_guards(), [], scn.name)

    def test_cli_run_and_list(self):
        buf = io.StringIO()
        with redirect_stdout(buf):
            self.assertEqual(cli.main(["samples", "list"]), 0)
        self.assertIn("histogram_private", buf.getvalue())
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = cli.main(["samples", "run", "vecadd", "reduce_max", "--device", "reference:small"])
        self.assertEqual(rc, 0, buf.getvalue())
        self.assertIn("PASS", buf.getvalue())
        self.assertNotIn("FAIL", buf.getvalue())

    def test_unknown_sample(self):
        buf = io.StringIO()
        with redirect_stdout(buf):
            self.assertEqual(cli.main(["samples", "run", "nosuch"]), 1)


@unittest.skipUnless(HAVE_HW, "hardware model not available")
class SameBinariesOnBothBackends(unittest.TestCase):
    def test_full_matrix_reference_vs_hardware_model(self):
        res = compare.compare_matrix(samples.scenarios(), backends=("reference", "hwmodel"), configs=("default", "small", "wide"))
        ran = [c for c in res if not c.skipped]
        self.assertGreaterEqual(len(ran), 70)
        text = compare.format_matrix(res)
        for c in ran:
            self.assertTrue(c.ok, f"{c.scenario}: {c.details}\n{text}")
            self.assertEqual((c.checks["expected"], c.checks["outputs"], c.checks["counters"], c.checks["trace"]), (True, True, True, True), c.scenario)

    def test_comparison_is_not_vacuous_the_models_really_differ(self):
        c = compare_scenario(samples.reduce_sum(1000, 32), [("reference", "default"), ("hwmodel", "default")])
        self.assertTrue(c.ok)
        ref, hw = c.runs[0].launches[0], c.runs[1].launches[0]
        self.assertNotEqual(ref.ticks, hw.ticks)                       # different timing...
        self.assertGreater(hw.ticks, ref.ticks)                        # ...slower, with real memory latency
        self.assertEqual(ref.digest, hw.digest)                        # ...but identical architectural behaviour
        self.assertEqual((ref.issued, ref.lane_ops), (hw.issued, hw.lane_ops))

    def test_forced_spills_in_every_sample_agree_across_backends(self):
        """Recompile every sample with only 5 allocatable registers (spilling to shared memory) and compare both backends."""
        from sfsdk.compiler import compile_ir
        from sfsdk.spec import Config
        originals = dict(samples._IMAGES)
        try:
            for name in samples.source_names():
                src = (samples.KERNEL_DIR / f"{name}.sfir").read_text()
                img = compile_ir(src, name, config=Config.named("default"), max_regs=5).image()
                samples._IMAGES[name] = img
            spilled = [n for n in samples.source_names() if samples._IMAGES[n].meta.info.get("spilling")]
            self.assertGreaterEqual(len(spilled), 6, spilled)
            res = compare.compare_matrix(samples.scenarios(), backends=("reference", "hwmodel"), configs=("default", "small"))
            for c in res:
                if not c.skipped:
                    self.assertTrue(c.ok, f"{c.scenario}: {c.details}")
        finally:
            samples._IMAGES.clear()
            samples._IMAGES.update(originals)

    def test_compare_cli(self):
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = cli.main(["compare", "vecadd", "--configs", "default"])
        self.assertEqual(rc, 0, buf.getvalue())
        self.assertIn("4/4 comparisons passed", buf.getvalue())


if __name__ == "__main__":
    unittest.main()
