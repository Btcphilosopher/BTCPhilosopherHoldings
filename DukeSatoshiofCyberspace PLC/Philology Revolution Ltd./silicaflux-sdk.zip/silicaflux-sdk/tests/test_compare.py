"""The comparison harness: it must agree when backends agree, and report differences precisely when they do not."""
import unittest

from sfsdk import asm, compare
from sfsdk.compare import Outcome, Scenario, ScenarioSkip, compare_scenario, first_trace_difference
from sfsdk.discovery import register_backend, Backend
from sfsdk.transport import ReferenceTransport
from tests._golden import EXAMPLES, run_example

TRIPLE = """.kernel triple
.arg ptr out w n
.arg u32 n
    rdsr r1, SR_GTID
    rdsr r2, SR_ARG1
    slt  r3, r1, r2
    bz   r3, done, done
    addi r4, r0, 3
    mul  r4, r4, r1
    shli r5, r1, 2
    rdsr r6, SR_ARG0
    add  r5, r5, r6
    stg  r4, [r5]
done:
    exit
"""


def triple_scenario(n=37):
    def run(dev):
        k = dev.load_kernel(asm.assemble(TRIPLE, "t.sfa"))
        out = dev.alloc(4 * n)
        wg = min(16, dev.config.max_wg_threads)
        r = k.launch((n + wg - 1) // wg, wg, [out, n])
        return Outcome({"out": out.read_words()}, [r], {"out": [3 * i for i in range(n)]})
    return Scenario("triple", run)


class MutantTransport(ReferenceTransport):
    """A deliberately broken 'implementation': reads back one wrong word. The harness must catch it."""
    name = "mutant"

    def mem_read(self, addr, n):
        b = bytearray(super().mem_read(addr, n))
        if n >= 8 and n != 64 and addr % 64 == 0:          # leave the SDK's 64-byte guard reads alone
            b[4] ^= 1
        return bytes(b)


class MutantTrace(ReferenceTransport):
    """Correct results, wrong commit trace (e.g. a stack-depth bug): only the trace check can see it."""
    name = "mutant_trace"

    def commit_trace(self):
        lines = super().commit_trace()
        if lines:
            lines = list(lines)
            lines[len(lines) // 2] = lines[len(lines) // 2].replace('"depth":1', '"depth":2')
        return lines


class Compare(unittest.TestCase):
    def test_identical_backends_pass(self):
        c = compare_scenario(triple_scenario(), [("reference", "default"), ("reference", "default")])
        self.assertTrue(c.ok, c.details)
        self.assertEqual((c.checks["outputs"], c.checks["counters"], c.checks["trace"], c.checks["expected"]), (True, True, True, True))

    def test_separate_process_over_line_protocol(self):
        # the same reference model behind the line protocol (a genuinely separate process); it records no commit trace,
        # so the trace check is "n/a" rather than silently passing
        import sys
        from sfsdk.discovery import register_line_device
        from sfsdk.spec import SF_G1_DIR
        register_line_device("refproc", [sys.executable, str(SF_G1_DIR / "sim" / "sfg1_devserver.py"), "--config", "default"])
        c = compare_scenario(triple_scenario(), [("reference", "default"), ("refproc", "default")])
        self.assertTrue(c.ok, c.details)
        self.assertEqual((c.checks["outputs"], c.checks["counters"], c.checks["expected"]), (True, True, True))
        self.assertIsNone(c.checks["trace"])

    def test_reference_examples_as_scenarios(self):
        for name in EXAMPLES:
            def run(dev, name=name):
                r, out = run_example(dev, name)
                key = {"vecadd": "c", "reduce_sum": "sum", "matmul_i32": "C", "diverge": "out"}[name]
                v = out[key] if isinstance(out[key], list) else [out[key]]
                e = out["exp"] if isinstance(out["exp"], list) else [out["exp"]]
                return Outcome({key: v}, [r], {key: e})
            c = compare_scenario(Scenario(name, run), [("reference", "default"), ("reference", "default")])
            self.assertTrue(c.ok, c.details)

    def test_wrong_output_is_localised(self):
        register_backend(Backend("mutant", "broken", lambda cfg, trace=False, **kw: MutantTransport(cfg, trace=trace)))
        c = compare_scenario(triple_scenario(), [("reference", "default"), ("mutant", "default")])
        self.assertFalse(c.ok)
        self.assertFalse(c.checks["outputs"])
        self.assertFalse(c.checks["expected"])
        text = "\n".join(c.details)
        self.assertIn("output 'out'", text)
        self.assertIn("first at index 1", text)

    def test_wrong_trace_with_right_results_is_caught_by_trace_check_only(self):
        register_backend(Backend("mutant_trace", "bad trace", lambda cfg, trace=False, **kw: MutantTrace(cfg, trace=trace)))
        c = compare_scenario(triple_scenario(), [("reference", "default"), ("mutant_trace", "default")])
        self.assertTrue(c.checks["outputs"] and c.checks["counters"] and c.checks["expected"])
        self.assertFalse(c.checks["trace"])
        self.assertFalse(c.ok)
        self.assertIn("first trace difference", "\n".join(c.details))

    def test_order_dependent_atomics_are_not_trace_compared(self):
        src = ".kernel t\n.arg ptr p rw 1\nrdsr r1, SR_ARG0\naddi r2, r0, 1\natomadd r3, [r1], r2\nexit\n"

        def run(dev):
            k = dev.load_kernel(asm.assemble(src))
            p = dev.alloc(4)
            r = k.launch(2, 8, [p])
            return Outcome({"p": p.read_words()}, [r], {"p": [16]})
        # make the second target's digest different on purpose; it must be ignored for this kernel
        register_backend(Backend("mutant_trace", "bad trace", lambda cfg, trace=False, **kw: MutantTrace(cfg, trace=trace)))
        c = compare_scenario(Scenario("atomret", run), [("reference", "default"), ("mutant_trace", "default")])
        self.assertIsNone(c.checks["trace"])
        self.assertTrue(c.ok, c.details)

    def test_scenario_errors_and_skips_are_reported(self):
        def boom(dev):
            raise RuntimeError("kaboom")

        def skip(dev):
            raise ScenarioSkip("does not fit")
        c = compare_scenario(Scenario("boom", boom), [("reference", "default")])
        self.assertFalse(c.ok)
        self.assertIn("kaboom", "\n".join(c.details))
        c = compare_scenario(Scenario("skip", skip), [("reference", "default")])
        self.assertTrue(c.skipped)

    def test_matrix_formatting(self):
        res = compare.compare_matrix([triple_scenario()], backends=("reference", "reference"), configs=("default", "small"))
        txt = compare.format_matrix(res)
        self.assertIn("2/2 comparisons passed", txt)
        self.assertIn("triple @ small", txt)
        self.assertIn("reference:default", compare.timing_table(res))

    def test_first_trace_difference(self):
        a = ['{"wg":0,"warp":0,"seq":0,"pc":0,"insn":1,"mask":3,"wb":null,"mem":null,"npc":1,"nmask":3,"depth":1}']
        b = [a[0].replace('"npc":1', '"npc":5')]
        self.assertIn("npc", first_trace_difference(a, b))
        self.assertIn("identical", first_trace_difference(a, a))
        self.assertIn("then one has", first_trace_difference(a, a + a))


if __name__ == "__main__":
    unittest.main()
