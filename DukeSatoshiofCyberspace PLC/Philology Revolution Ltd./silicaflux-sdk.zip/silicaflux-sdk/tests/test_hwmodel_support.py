"""Shared helpers for the hardware-model tests (no tests in here)."""
from __future__ import annotations

import hashlib
import importlib.util
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from sfsdk import _ref  # noqa: E402
from sfsdk.hwmodel import HwModelTransport, HwParams  # noqa: E402
from sfsdk.spec import Config  # noqa: E402
from sfsdk.transport import ReferenceTransport  # noqa: E402
from sfg1.host import Host  # noqa: E402  (vendored reference host driver; works with any Transport)

CONFIGS = ("default", "small", "wide")

# Parameter sets that exercise very different microarchitectures; results must not depend on any of them.
PARAM_SETS = {
    "default": HwParams(),
    "lrr": HwParams(scheduler="lrr"),
    "gto": HwParams(scheduler="gto"),
    "dispatch_lowest": HwParams(dispatch_policy="lowest", dispatch_per_cycle=1),
    "dispatch_rr": HwParams(dispatch_policy="round_robin"),
    "fast": HwParams(alu_latency=1, mul_latency=1, sreg_latency=1, branch_latency=1, agu_latency=1,
                     global_latency=1, shared_latency=1, desc_fetch_cycles=1, dispatch_latency=1),
    "slow_memory": HwParams(global_latency=90, shared_latency=12, global_ports=1, shared_banks=2),
    "tiny_queue": HwParams(mem_queue_depth=1, segment_bytes=4),
    "wide_ports": HwParams(global_ports=4, shared_banks=32, segment_bytes=128),
    # completion order across warps varies (a later request may finish first): drains, fences and per-warp
    # ordering are what keeps results correct
    "jitter": HwParams(global_jitter=40, shared_jitter=6, global_ports=2, segment_bytes=4, seed=77),
    "jitter_gto": HwParams(global_jitter=90, shared_jitter=12, global_ports=4, scheduler="gto", seed=1234),
    # heavy jitter: a request can finish ~200 cycles after a later one from another warp
    "jitter_heavy_0": HwParams(global_jitter=200, shared_jitter=60, global_ports=2, seed=0),
    "jitter_heavy_1": HwParams(global_jitter=200, shared_jitter=60, global_ports=2, seed=1),
    "jitter_heavy_2": HwParams(global_jitter=200, shared_jitter=60, global_ports=2, seed=2),
}


def ref_config(cfg: Config):
    return _ref.ref_spec.Config.from_dict(cfg.parameters(), name=cfg.name)


def digest(lines) -> str:
    h = hashlib.sha256()
    for ln in lines:
        h.update(ln.encode())
        h.update(b"\n")
    return h.hexdigest()


def make_host(backend: str, cfg: Config, params: HwParams = None, trace: bool = True):
    """(Host, Transport) for 'reference' or 'hwmodel' driven by the vendored reference host driver."""
    t = ReferenceTransport(cfg, trace=trace) if backend == "reference" else HwModelTransport(cfg, trace=trace, params=params)
    return Host(t, ref_config(cfg)), t


def load_vendored(module_file: str, name: str):
    """Import a file of the vendored reference tests (e.g. its random-program generator)."""
    path = os.path.join(ROOT, "sf-g1", "sim", "tests", module_file)
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod
