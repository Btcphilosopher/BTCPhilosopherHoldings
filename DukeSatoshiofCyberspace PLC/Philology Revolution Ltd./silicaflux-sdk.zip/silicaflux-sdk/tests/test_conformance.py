"""The host-level conformance suite (sfsdk/conformance.py): it must pass 100 % on the reference simulator
(which validates the suite itself) and on the hardware model, and it must be able to fail."""
import os
import unittest

import sfsdk._ref  # noqa: F401
from sfsdk import conformance
from sfsdk.conformance import run_conformance
from sfsdk.hwmodel import HwModelTransport
from sfsdk.spec import Config
from sfsdk.transport import ReferenceTransport
from tests.test_hwmodel_support import PARAM_SETS


class ReferencePasses(unittest.TestCase):
    def test_reference_simulator_passes_every_check(self):
        rep = run_conformance(lambda c: ReferenceTransport(c, trace=True), backend="reference")
        self.assertTrue(rep.ok, rep.summary())
        names = {c.name for c in rep.checks}
        self.assertGreaterEqual(len(names), 55, "the suite should cover the specification broadly")
        self.assertGreaterEqual(len(rep.checks), 160)
        self.assertEqual(sum(c.skipped for c in rep.checks), 0)
        for must in ("identity_and_capabilities", "alu_semantics_all_instructions", "fault_illegal_instruction",
                     "fault_stack_overflow_small_config", "watchdog_fault_and_disable",
                     "example_diverge_matches_golden_report"):
            self.assertIn(must, names)


class HardwareModelPasses(unittest.TestCase):
    def test_default_microarchitecture(self):
        rep = run_conformance(lambda c: HwModelTransport(c, trace=True), backend="hwmodel")
        self.assertTrue(rep.ok, rep.summary())
        self.assertGreaterEqual(len(rep.checks), 160)

    def test_other_microarchitectures(self):
        """Results must not depend on scheduler, memory latency/jitter or queue depth."""
        for pname in ("jitter_gto", "tiny_queue"):
            rep = run_conformance(lambda c, p=PARAM_SETS[pname]: HwModelTransport(c, trace=True, params=p),
                                  ("small", "default"), backend=f"hwmodel:{pname}")
            self.assertTrue(rep.ok, rep.summary())

    @unittest.skipUnless(os.environ.get("SFSDK_SLOW_TESTS"), "set SFSDK_SLOW_TESTS=1 for the full parameter matrix")
    def test_full_parameter_matrix(self):
        for pname, p in PARAM_SETS.items():
            rep = run_conformance(lambda c, p=p: HwModelTransport(c, trace=True, params=p), backend=f"hwmodel:{pname}")
            self.assertTrue(rep.ok, rep.summary())


class SuiteCanFail(unittest.TestCase):
    def test_detects_a_transport_with_wrong_identity(self):
        class Liar(ReferenceTransport):
            def reg_read(self, off):
                v = super().reg_read(off)
                return v ^ 1 if off == 0x008 else v                # CFG_HASH off by one bit

        rep = run_conformance(lambda c: Liar(c), ("small",), only="identity", backend="liar")
        self.assertFalse(rep.ok)
        self.assertIn("CFG_HASH", rep.failures()[0].detail)

    def test_detects_a_device_that_loses_memory_on_soft_reset(self):
        class Amnesiac(ReferenceTransport):
            def reg_write(self, off, val):
                super().reg_write(off, val)
                if off == 0x020 and val & 1:
                    self.dev.gmem[:] = bytes(len(self.dev.gmem))

        rep = run_conformance(lambda c: Amnesiac(c), ("small",), only="soft_reset_clears", backend="amnesiac")
        self.assertFalse(rep.ok)

    def test_report_api_and_cli(self):
        rep = run_conformance(lambda c: ReferenceTransport(c), ("small",), only="power_up", backend="ref")
        self.assertTrue(rep.ok)
        d = rep.as_dict()
        self.assertEqual(d["failed"], 0)
        self.assertIn("checks passed", rep.summary())
        self.assertEqual(conformance.main(["--backend", "both", "--config", "small", "-k", "identity"]), 0)


if __name__ == "__main__":
    unittest.main()
