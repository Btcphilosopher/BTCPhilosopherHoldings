"""The reference example kernels, driven through the SDK runtime, must reproduce the golden reports."""
import unittest

from sfsdk.discovery import open_device
from tests._golden import EXAMPLES, golden, run_example


class ReferenceExamplesThroughSdk(unittest.TestCase):
    def test_outputs_and_architectural_counters_match_golden_reports(self):
        for name in EXAMPLES:
            with self.subTest(example=name):
                with open_device("reference:default", keep_trace=True) as dev:
                    r, out = run_example(dev, name)
                    g = golden(name)
                    self.assertTrue(r.ok)
                    key = {"vecadd": "c", "reduce_sum": "sum", "matmul_i32": "C", "diverge": "out"}[name]
                    self.assertEqual(out[key], out["exp"])
                    gold_out = g["outputs"]
                    if name == "reduce_sum":
                        self.assertEqual(out["sum"], gold_out["sum"])
                    elif name == "vecadd":
                        self.assertEqual(out["c"][:70], gold_out["c"]["data"])
                    elif name == "matmul_i32":
                        self.assertEqual(out["C"][:42], gold_out["C"]["data"])
                    else:
                        self.assertEqual(out["out"], gold_out["out"]["data"])
                    # architectural counters equal the golden ones (ticks are timing and may differ)
                    self.assertEqual(r.issued, g["stats"]["warp_instructions"])
                    self.assertEqual(r.lane_ops, g["stats"]["lane_ops"])
                    self.assertEqual(r.ticks, g["stats"]["ticks"])   # reference model: ticks are deterministic too
                    self.assertAlmostEqual(r.simt_efficiency, g["stats"]["simt_efficiency"], places=5)
                    self.assertEqual(len(r.trace_lines), g["trace"]["events"])

    def test_all_examples_all_configs(self):
        for cfgname in ("default", "small", "wide"):
            for name in EXAMPLES:
                with self.subTest(config=cfgname, example=name):
                    with open_device(f"reference:{cfgname}") as dev:
                        r, out = run_example(dev, name)
                        key = {"vecadd": "c", "reduce_sum": "sum", "matmul_i32": "C", "diverge": "out"}[name]
                        self.assertEqual(out[key], out["exp"])
                        self.assertEqual(dev.check_guards(), [])


if __name__ == "__main__":
    unittest.main()
