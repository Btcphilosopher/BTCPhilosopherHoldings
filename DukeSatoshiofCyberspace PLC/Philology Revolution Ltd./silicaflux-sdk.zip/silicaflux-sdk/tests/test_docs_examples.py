"""Execute every ```python block of the SDK guide (in order, one namespace per document): the docs must not lie."""
import io
import re
import unittest
from contextlib import redirect_stdout
from pathlib import Path

DOCS = Path(__file__).resolve().parents[1] / "docs"


def blocks(path):
    text = path.read_text()
    return re.findall(r"```python\n(.*?)```", text, re.S)


class DocExamples(unittest.TestCase):
    def run_doc(self, name):
        ns = {}
        for i, code in enumerate(blocks(DOCS / name)):
            try:
                with redirect_stdout(io.StringIO()):
                    exec(compile(code, f"{name}:block{i}", "exec"), ns)
            except Exception as e:                                          # pragma: no cover - failure path
                self.fail(f"{name} block {i} failed: {type(e).__name__}: {e}\n{code}")
        return ns

    def test_sdk_guide(self):
        ns = self.run_doc("SDK.md")
        self.assertIn("dev", ns)

    def test_toolchain_guide(self):
        ns = self.run_doc("TOOLCHAIN.md")
        self.assertIn("prog", ns)


if __name__ == "__main__":
    unittest.main()
