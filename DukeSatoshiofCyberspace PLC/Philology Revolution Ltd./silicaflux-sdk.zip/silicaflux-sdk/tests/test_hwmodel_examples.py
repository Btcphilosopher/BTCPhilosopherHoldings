"""The four example kernels on the hardware model: same results, same architectural counters,
same per-warp commit trace as the reference simulator -- under many microarchitectures."""
import unittest

import sfsdk._ref  # noqa: F401  (puts the vendored reference package `sfg1` on sys.path)
from sfg1 import examples

from tests.test_hwmodel_support import CONFIGS, PARAM_SETS, digest, make_host, ref_config
from sfsdk.spec import Config


class ExampleEquivalence(unittest.TestCase):
    def _compare(self, cfgname: str, pname: str) -> None:
        cfg = Config.named(cfgname)
        for name in examples.EXAMPLES:
            rhost, rt = make_host("reference", cfg)
            hhost, ht = make_host("hwmodel", cfg, PARAM_SETS[pname])
            rex = examples.EXAMPLES[name](rhost, ref_config(cfg), True)
            hex_ = examples.EXAMPLES[name](hhost, ref_config(cfg), True)
            tag = f"{name}/{cfgname}/{pname}"
            self.assertTrue(rex.ok and hex_.ok, f"{tag}: result check (ref ok={rex.ok}, hw ok={hex_.ok}: {hex_.message})")
            self.assertEqual(hex_.result.issued, rex.result.issued, f"{tag}: PERF_ISSUED")
            self.assertEqual(hex_.result.lane_ops, rex.result.lane_ops, f"{tag}: PERF_LANE_OPS")
            rl, hl = rt.commit_trace(), ht.commit_trace()
            self.assertEqual(len(hl), len(rl), f"{tag}: number of commit-trace events")
            self.assertEqual(digest(hl), digest(rl), f"{tag}: commit-trace digest")
            if hl != rl:                                              # pragma: no cover - localise a difference
                i = next(i for i, (a, b) in enumerate(zip(hl, rl)) if a != b)
                self.fail(f"{tag}: first differing trace line {i}:\n hw  {hl[i]}\n ref {rl[i]}")

    def test_default_microarchitecture_all_configs(self):
        for cfgname in CONFIGS:
            self._compare(cfgname, "default")

    def test_scheduler_and_dispatch_policies(self):
        for pname in ("lrr", "gto", "dispatch_lowest", "dispatch_rr"):
            self._compare("default", pname)
            self._compare("wide", pname)

    def test_memory_system_variants(self):
        for pname in ("fast", "slow_memory", "tiny_queue", "wide_ports"):
            for cfgname in CONFIGS:
                self._compare(cfgname, pname)


    def test_jitter_variants(self):
        """Completion order across warps varies (a later request can finish first)."""
        for pname in ("jitter", "jitter_gto", "jitter_heavy_0"):
            for cfgname in CONFIGS:
                self._compare(cfgname, pname)


class GoldenDigests(unittest.TestCase):
    def test_trace_digest_equals_authoritative_golden(self):
        """Against the stored golden reports (not a live reference run)."""
        import json
        import os
        from sfsdk.spec import SF_G1_DIR
        cfg = Config.named("default")
        for name in examples.EXAMPLES:
            host, t = make_host("hwmodel", cfg)
            ex = examples.EXAMPLES[name](host, ref_config(cfg), True)
            self.assertTrue(ex.ok)
            with open(os.path.join(SF_G1_DIR, "reference", name, "report.json")) as fh:
                gold = json.load(fh)
            self.assertEqual(digest(t.commit_trace()), gold["trace"]["sha256"], name)
            self.assertEqual(ex.result.issued, gold["stats"]["warp_instructions"])
            self.assertEqual(ex.result.lane_ops, gold["stats"]["lane_ops"])


if __name__ == "__main__":
    unittest.main()
