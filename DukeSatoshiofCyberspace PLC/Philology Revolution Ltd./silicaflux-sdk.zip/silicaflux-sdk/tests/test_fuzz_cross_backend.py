"""Fast regression run of scripts/fuzz_cross_backend.py (IR interpreter vs reference vs hardware model)."""
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

try:
    from sfsdk.hwmodel import HwModelTransport  # noqa: F401
    HAVE = True
except Exception:                                  # pragma: no cover
    HAVE = False


@unittest.skipUnless(HAVE, "hardware model not available")
class CrossBackendFuzz(unittest.TestCase):
    def run_script(self, *extra):
        return subprocess.run([sys.executable, str(ROOT / "scripts" / "fuzz_cross_backend.py"), "--per-cell", "4", "--seed", "99",
                               "--max-regs", "none", "5", *extra], capture_output=True, text=True, cwd=str(ROOT), timeout=600,
                              env={"PYTHONPATH": str(ROOT), "PATH": "/usr/bin:/bin"})

    def test_small_campaign_has_no_mismatch_and_exercises_spilling(self):
        r = self.run_script()
        self.assertEqual(r.returncode, 0, r.stdout[-3000:] + r.stderr[-2000:])
        line = next(l for l in r.stdout.splitlines() if l.startswith("RESULT"))
        self.assertIn("'mismatches': 0", line)
        self.assertIn("'programs': 24", line)                          # 4 programs x 3 configurations x 2 register budgets
        spilled = int(line.split("'spilled': ")[1].split(",")[0])
        self.assertGreater(spilled, 0)


if __name__ == "__main__":
    unittest.main()
