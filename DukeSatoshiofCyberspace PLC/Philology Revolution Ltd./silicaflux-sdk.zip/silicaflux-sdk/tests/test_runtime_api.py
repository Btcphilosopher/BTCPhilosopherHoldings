"""Runtime SDK behaviour: enumeration, allocation, transfers, kernel loading, argument validation, dispatch,
synchronisation, error reporting and profiling -- on the reference simulator through the public API."""
import json
import unittest

from sfsdk import asm
from sfsdk.discovery import enumerate_devices, open_device, unavailable_backends
from sfsdk.errors import (ApiError, ArgumentError, BufferCorrupted, DeviceBusy, DeviceFault, DeviceMismatch,
                          DeviceTimeout, LaunchRejected, OutOfDeviceMemory)
from sfsdk.runtime import BoundLaunch, DevicePtr, to_words
from sfsdk.spec import Config, device_spec
from sfsdk.transport import ApertureError, LineTransport, ReferenceTransport

R = device_spec().reg_offset

TRIPLE = """
.kernel triple
.arg ptr out w n
.arg u32 n
    rdsr r1, SR_GTID
    rdsr r2, SR_ARG1
    slt  r3, r1, r2
    bz   r3, done, done
    addi r4, r0, 3
    mul  r4, r4, r1
    shli r5, r1, 2
    rdsr r6, SR_ARG0
    add  r5, r5, r6
    stg  r4, [r5]
done:
    exit
"""
INC = """
.kernel inc
.arg ptr p rw 1
    rdsr r1, SR_ARG0
    ldg  r2, [r1]
    addi r2, r2, 1
    stg  r2, [r1]
    exit
"""
SPIN = ".kernel spin\nL: bra L\n"


BACKEND = "reference"          # tests/test_runtime_api_hwmodel.py runs this same suite against the hardware model


def dev_(spec="reference:default", **kw):
    """Open ``spec``'s configuration on the backend under test (``reference:`` is rewritten to BACKEND)."""
    if spec.startswith("reference:"):
        spec = BACKEND + spec[len("reference"):]
    return open_device(spec, **kw)


def load(dev, src, name="t.sfa"):
    return dev.load_kernel(asm.assemble(src, name))


class Enumeration(unittest.TestCase):
    def test_lists_devices_from_their_own_registers(self):
        devs = enumerate_devices(["reference"])
        self.assertEqual([d.config_name for d in devs], ["default", "small", "wide"])
        for d in devs:
            cfg = Config.named(d.config_name)
            self.assertEqual((d.lanes, d.num_eg, d.warps_per_eg, d.max_wg_threads, d.gmem_bytes), (cfg.lanes, cfg.num_eg, cfg.warps_per_eg, cfg.max_wg_threads, cfg.gmem_bytes))
            self.assertEqual(d.cfg_hash, cfg.cfg_hash())
            self.assertEqual(d.version, "1.0.0")
            self.assertIn("SF-G1", d.line())
            json.dumps(d.as_dict())

    def test_open_by_index_string_and_default(self):
        self.assertEqual(open_device().config.name, "default")
        self.assertEqual(open_device(1).config.name, "small")
        self.assertEqual(open_device("reference:wide").config.name, "wide")
        self.assertEqual(open_device(backend="reference", config="small").config.name, "small")

    def test_errors(self):
        for bad in (lambda: open_device(99), lambda: open_device("nosuch:default"), lambda: open_device("reference:nosuch")):
            with self.assertRaises(Exception):
                bad()

    def test_unavailable_backend_is_reported_not_hidden(self):
        # whichever backends cannot load must be explained
        for name, why in unavailable_backends().items():
            self.assertTrue(why)


class Memory(unittest.TestCase):
    def setUp(self):
        self.dev = dev_()

    def tearDown(self):
        self.dev.close()

    def test_alloc_is_aligned_zeroed_and_disjoint(self):
        # the reference poisons global memory with 0xDEADBEEF; alloc() zero-fills by default
        a, b = self.dev.alloc(100, name="a"), self.dev.alloc(100, name="b")
        for buf in (a, b):
            self.assertEqual(buf.addr % 64, 0)
            self.assertEqual(buf.read_words(), [0] * 25)
        self.assertGreaterEqual(abs(a.addr - b.addr), 100 + 64)             # separated by guard space
        self.assertGreaterEqual(a.addr, 0x100)

    def test_zero_false_exposes_poison(self):
        buf = self.dev.alloc(16, zero=False)
        if BACKEND == "reference":
            self.assertEqual(buf.read_words(), [0xDEADBEEF] * 4)            # the reference poisons memory at power-up
        else:
            self.assertNotEqual(buf.read_words(), [0] * 4)                  # other backends: implementation-defined, but not our zeros

    def test_roundtrip_and_typed_helpers(self):
        buf = self.dev.alloc(32)
        buf.write_words([1, 2, 0xFFFFFFFF, -5, 0x80000000, 7, 8, 9])
        self.assertEqual(buf.read_words(3), [1, 2, 0xFFFFFFFF])
        self.assertEqual(buf.read_i32(5)[2:], [-1, -5, -(1 << 31)])
        buf.write(b"\x01\x00\x00\x00", offset=4)
        self.assertEqual(buf.read_words(2, 0), [1, 1])
        self.assertEqual(buf.read(8, 4), (b"\x01\x00\x00\x00\xff\xff\xff\xff"))
        buf.fill(0xAB)
        self.assertEqual(buf.read_words(), [0xAB] * 8)
        self.assertEqual(self.dev.read(buf, 8), b"\xab\x00\x00\x00" * 2)
        self.dev.write(buf.at(8), [5])
        self.assertEqual(buf.read_words(1, 2), [5])

    def test_bounds_and_value_checks(self):
        buf = self.dev.alloc(16)
        with self.assertRaises(ApiError):
            buf.write_words([1] * 5)
        with self.assertRaises(ApiError):
            buf.read_words(5)
        with self.assertRaises(ApiError):
            buf.write(b"\x00" * 4, offset=2)                                  # misaligned
        with self.assertRaises(ArgumentError):
            buf.write_words([1 << 32])
        with self.assertRaises(ArgumentError):
            buf.write_words([-(1 << 31) - 1])
        with self.assertRaises(ArgumentError):
            buf.write_words([True])
        with self.assertRaises(ArgumentError):
            buf.write_words([1.5])
        with self.assertRaises(ApiError):
            self.dev.write(buf.addr + 12, [1, 2])                             # crosses the end
        with self.assertRaises(ApiError):
            self.dev.write(0x99999, [1])                                      # not in any allocation
        with self.assertRaises(ArgumentError):
            buf.at(3)

    def test_free_reuse_double_free_use_after_free(self):
        a = self.dev.alloc(256)
        addr = a.addr
        a.free()
        with self.assertRaises(ApiError) as cm:
            a.read_words()
        self.assertEqual(cm.exception.code, "E_USE_AFTER_FREE")
        with self.assertRaises(ApiError):
            self.dev.free(addr)                                               # double free
        self.assertEqual(self.dev.alloc(256).addr, addr)                      # reused

    def test_out_of_memory_message_and_stats(self):
        with self.assertRaises(OutOfDeviceMemory) as cm:
            self.dev.alloc(self.dev.config.gmem_bytes)
        self.assertIn("largest free span", str(cm.exception))
        keep = [self.dev.alloc(1000) for _ in range(5)]
        st = self.dev.memory_info()
        self.assertEqual(st["live_blocks"], 1 + 5)                            # + the launch descriptor
        self.assertEqual(len(self.dev.buffers()), 5)

    def test_alloc_with_init(self):
        b = self.dev.alloc(12, init=[1, 2])
        self.assertEqual(b.read_words(), [1, 2, 0])
        with self.assertRaises(ArgumentError):
            self.dev.alloc(4, init=[1, 2])

    def test_foreign_buffer_rejected(self):
        other = dev_()
        b = other.alloc(16)
        with self.assertRaises(ApiError):
            self.dev.write(b, [1])
        with self.assertRaises(ApiError):
            self.dev._write(b, 0, b"\0\0\0\0")


class KernelLoading(unittest.TestCase):
    def setUp(self):
        self.dev = dev_("reference:small")

    def test_sources(self):
        img = asm.assemble(TRIPLE, "t.sfa").image()
        for src in (img, asm.assemble(TRIPLE, "t.sfa"), img.to_bytes(), img.to_sfbin()):
            k = self.dev.load_kernel(src)
            self.assertEqual(k.num_words, img.num_words)
            self.assertEqual(self.dev.read(self.dev.allocator.find(k.addr).addr, 4 * k.num_words), img.to_sfbin())
        self.assertTrue(self.dev.load_kernel(img.to_bytes()).image.has_meta)
        self.assertFalse(self.dev.load_kernel(img.to_sfbin()).image.has_meta)

    def test_paths(self):
        import os, tempfile
        d = tempfile.mkdtemp()
        sfa, sfk, sfbin = (os.path.join(d, n) for n in ("a.sfa", "a.sfk", "a.sfbin"))
        img = asm.assemble(TRIPLE, sfa).image()
        for path, data, mode in ((sfa, TRIPLE, "w"), (sfk, img.to_bytes(), "wb"), (sfbin, img.to_sfbin(), "wb")):
            with open(path, mode) as fh:
                fh.write(data)
        for p in (sfa, sfk, sfbin):
            self.assertEqual(self.dev.load_kernel(p).num_words, img.num_words)
        with self.assertRaises(ArgumentError):
            self.dev.load_kernel(os.path.join(d, "missing.sfa"))
        with self.assertRaises(ArgumentError):
            self.dev.load_kernel(12345)

    def test_too_large_for_instruction_memory(self):
        big = asm.assemble("nop\n" * 600 + "exit\n")
        with self.assertRaises(ArgumentError) as cm:
            self.dev.load_kernel(big)                                         # small config: 512 words
        self.assertEqual(cm.exception.code, "E_KERNEL_TOO_LARGE")
        with open_device("reference:wide") as wide:
            wide.load_kernel(big)                                             # wide: 2048 words

    def test_bad_entry(self):
        p = asm.assemble(".entry 7\nexit\n")
        with self.assertRaises(ArgumentError) as cm:
            self.dev.load_kernel(p)
        self.assertEqual(cm.exception.code, "E_KERNEL_ENTRY")

    def test_static_analysis_warnings(self):
        k = self.dev.load_kernel(asm.assemble(".kernel w\n.arg u32 a\nrdsr r1, SR_ARG3\n.word 0xFFFFFFFF\nnop\n"))
        text = " | ".join(k.diagnostics)
        self.assertIn("not a legal instruction", text)
        self.assertIn("fall off the end", text)
        self.assertIn("SR_ARG3", text)
        clean = self.dev.load_kernel(asm.assemble(TRIPLE))
        self.assertEqual(clean.diagnostics, [])

    def test_unload_frees_memory(self):
        before = self.dev.memory_info()["free"]
        k = self.dev.load_kernel(asm.assemble(TRIPLE))
        self.assertLess(self.dev.memory_info()["free"], before)
        k.unload()
        self.assertEqual(self.dev.memory_info()["free"], before)
        with self.assertRaises(ApiError):
            k.submit(1, 1, [self.dev.alloc(4), 1])

    def test_disassemble_kernel(self):
        k = self.dev.load_kernel(asm.assemble(TRIPLE, "t.sfa"))
        self.assertIn("done:", k.disassemble())


class ArgumentValidation(unittest.TestCase):
    def setUp(self):
        self.dev = dev_()
        self.k = load(self.dev, TRIPLE)
        self.out = self.dev.alloc(4 * 64, name="out")

    def bad(self, code, *a, **kw):
        with self.assertRaises(ArgumentError) as cm:
            self.k.bind(*a, **kw)
        self.assertEqual(cm.exception.code, code, str(cm.exception))
        return str(cm.exception)

    def test_valid(self):
        b = self.k.bind(2, 32, [self.out, 64])
        self.assertEqual((b.grid, b.wg, b.shared, b.words), (2, 32, 0, [self.out.addr, 64]))
        self.assertEqual(self.k.bind(2, 32, [self.out.at(8), 8]).words[0], self.out.addr + 8)
        self.assertEqual(self.k.bind(1, 1, n=3, out=self.out).words, [self.out.addr, 3])
        self.assertEqual(self.k.bind(1, 1, [self.out], n=5).values["n"], 5)

    def test_geometry(self):
        cfg = self.dev.config
        for g, w in [(0, 1), (1, 0), (-1, 1), (cfg.max_grid_dim + 1, 1), (1, cfg.max_wg_threads + 1)]:
            self.bad("E_GEOMETRY", g, w, [self.out, 1])
        for g, w in [(1.0, 1), (True, 1), ("1", 1)]:
            self.bad("E_GEOMETRY", g, w, [self.out, 1])
        self.k.bind(cfg.max_grid_dim, cfg.max_wg_threads, [self.out, 1])

    def test_argument_count_and_names(self):
        self.bad("E_ARG_COUNT", 1, 1, [self.out])
        self.bad("E_ARG_COUNT", 1, 1, [self.out, 1, 2])
        self.bad("E_ARG_NAMES", 1, 1, [self.out], m=3)
        self.bad("E_ARG_NAMES", 1, 1, [self.out, 1], n=2)
        self.assertIn("triple(ptr out [w], u32 n)", self.bad("E_ARG_COUNT", 1, 1, []))

    def test_scalar_kinds_and_ranges(self):
        self.bad("E_ARG_RANGE", 1, 1, [self.out, -1])
        self.bad("E_ARG_RANGE", 1, 1, [self.out, 1 << 32])
        self.bad("E_ARG_KIND", 1, 1, [self.out, 1.5])
        self.bad("E_ARG_KIND", 1, 1, [self.out, True])
        self.bad("E_ARG_KIND", 1, 1, [self.out, self.out])

    def test_i32_range(self):
        k = load(self.dev, ".kernel s\n.arg i32 v\nexit\n")
        self.assertEqual(k.bind(1, 1, [-5]).words, [0xFFFFFFFB])
        for v in (1 << 31, -(1 << 31) - 1):
            with self.assertRaises(ArgumentError):
                k.bind(1, 1, [v])

    def test_pointer_checks(self):
        self.bad("E_ARG_POINTER", 1, 1, [0x77770, 1])                         # not in any allocation
        self.bad("E_ARG_ALIGN", 1, 1, [self.out.addr + 2, 1])
        self.bad("E_ARG_KIND", 1, 1, [1.5, 1])
        self.bad("E_ARG_POINTER", 1, 1, [self.out.addr + self.out.nbytes + 4, 1])   # in the guard, not the payload
        gone = self.dev.alloc(16)
        gone.free()
        with self.assertRaises(ApiError):
            self.k.bind(1, 1, [gone, 1])
        self.assertEqual(self.k.bind(1, 1, [self.out.addr + 16, 1]).words[0], self.out.addr + 16)   # raw interior address is fine

    def test_raw_address_resolves_through_allocator(self):
        self.assertEqual(self.k.bind(1, 1, [int(self.out), 1]).words[0], self.out.addr)

    def test_extent_check_uses_remaining_bytes(self):
        k = load(self.dev, ".kernel e\n.arg ptr a r n\n.arg u32 n\nexit\n")
        k.bind(1, 1, [self.out, 64])
        msg = ""
        with self.assertRaises(ArgumentError) as cm:
            k.bind(1, 1, [self.out, 65])
        self.assertEqual(cm.exception.code, "E_ARG_EXTENT")
        self.assertIn("out", str(cm.exception))
        with self.assertRaises(ArgumentError):
            k.bind(1, 1, [self.out.at(16), 61])                               # interior pointer shrinks the extent
        k.bind(1, 1, [self.out.at(16), 60])
        k.bind(1, 1, [0, 0])                                                  # null pointer allowed only when nothing is accessed

    def test_requirements(self):
        k = load(self.dev, '.kernel r\n.require (wg_dim & (wg_dim-1)) == 0, "wg_dim must be a power of two"\n.require grid_dim <= 4\nexit\n')
        k.bind(4, 16)
        self.assertIn("power of two", self._err(k, 4, 12))
        self.assertIn("grid_dim <= 4", self._err(k, 5, 16))

    def _err(self, k, *a):
        with self.assertRaises(ArgumentError) as cm:
            k.bind(*a)
        self.assertEqual(cm.exception.code, "E_REQUIRE")
        return str(cm.exception)

    def test_shared_memory_demand(self):
        k = load(self.dev, ".kernel s\n.arg u32 n\n.shared 4*n\n.shared_per_thread 8\nexit\n")
        self.assertEqual(k.bind(1, 16, [10]).shared, 40 + 8 * 16)
        self.assertEqual(k.bind(1, 16, [10], shared=1000).shared, 1000)
        with self.assertRaises(ArgumentError) as cm:
            k.bind(1, 16, [10], shared=100)
        self.assertEqual(cm.exception.code, "E_SHARED")
        with self.assertRaises(ArgumentError):
            k.bind(1, 32, [1024])                                             # 4096 + 256 > 4096 per workgroup
        for bad in (-4, 6, True, 1.0):
            with self.assertRaises(ArgumentError):
                k.bind(1, 16, [10], shared=bad)
        self.assertEqual(load(self.dev, "exit\n").bind(1, 1).shared, 0)

    def test_metadata_expression_error_is_reported(self):
        k = load(self.dev, ".kernel m\n.shared 4*mystery\nexit\n")
        with self.assertRaises(ArgumentError) as cm:
            k.bind(1, 1)
        self.assertEqual(cm.exception.code, "E_METADATA")

    def test_overlapping_written_buffers_warn(self):
        k = load(self.dev, ".kernel o\n.arg ptr a r 8\n.arg ptr b w 8\nexit\n")
        self.assertEqual(k.bind(1, 1, [self.out, self.out.at(64)]).warnings, [])
        self.assertTrue(k.bind(1, 1, [self.out, self.out.at(16)]).warnings)

    def test_raw_image_allows_plain_arguments(self):
        k = self.dev.load_kernel(asm.assemble(TRIPLE).image().to_sfbin())
        self.assertEqual(k.bind(1, 1, [self.out, 5]).words, [self.out.addr, 5])
        with self.assertRaises(ArgumentError):
            k.bind(1, 1, [1] * 9)
        with self.assertRaises(ArgumentError):
            k.bind(1, 1, [1.5])
        with self.assertRaises(ArgumentError):
            k.bind(1, 1, [], n=1)

    def test_smem_zero_flag(self):
        self.assertEqual(self.k.bind(1, 1, [self.out, 1], smem_zero=True).flags, 1)


class Dispatch(unittest.TestCase):
    def test_launch_result_and_counters(self):
        for cfgname in ("default", "small", "wide"):
            with dev_("reference:" + cfgname, keep_trace=True) as dev:
                k = load(dev, TRIPLE)
                out = dev.alloc(4 * 40, name="out")
                wg = min(16, dev.config.max_wg_threads)
                r = k.launch((37 + wg - 1) // wg, wg, [out, 37])
                self.assertTrue(r.ok)
                self.assertEqual(out.read_words(40), [3 * i for i in range(37)] + [0] * 3)
                self.assertEqual((r.kernel, r.status, r.backend, r.config), ("triple", "done", BACKEND, cfgname))
                self.assertGreater(r.ticks, 0)
                self.assertGreater(r.issued, 0)
                self.assertEqual(r.lane_ops, sum(bin(json.loads(l)["mask"]).count("1") for l in r.trace_lines))
                self.assertEqual(r.workgroups, (37 + wg - 1) // wg)
                self.assertEqual(len(r.trace_digest), 64)
                self.assertTrue(0 < r.simt_efficiency <= 1)

    def test_queue_executes_in_order(self):
        with dev_() as dev:
            k = load(dev, INC)
            p = dev.alloc(4)
            launches = [k.submit(1, 1, [p]) for _ in range(6)]
            self.assertEqual([l.id for l in launches], sorted(l.id for l in launches))
            self.assertIn(launches[-1].state, ("queued", "running"))
            dev.synchronize()
            self.assertTrue(all(l.state == "done" for l in launches))
            self.assertEqual(p.read_words(1), [6])
            self.assertEqual(len(dev.profiler.launches), 6)

    def test_poll_advances_time(self):
        with dev_() as dev:
            k = load(dev, INC)
            p = dev.alloc(4)
            ln = k.submit(1, 1, [p])
            self.assertFalse(ln.finished) if ln.state != "done" else None
            for _ in range(200):
                if ln.poll(5):
                    break
            self.assertTrue(ln.finished)
            self.assertEqual(ln.wait().status, "done")

    def test_irq_wait_mode_matches_poll_mode(self):
        outs = []
        for mode in ("poll", "irq"):
            with dev_(wait_mode=mode) as dev:
                k = load(dev, TRIPLE)
                out = dev.alloc(4 * 20)
                r = k.launch(2, 16, [out, 20])
                outs.append((out.read_words(), r.issued, r.lane_ops))
                self.assertEqual(dev.reg("INT_STATUS"), 0)                    # SDK acknowledged the interrupt
        self.assertEqual(outs[0], outs[1])

    def test_watchdog_argument_validation(self):
        with dev_() as dev:
            k = load(dev, INC)
            p = dev.alloc(4)
            for bad in (-1, 1 << 32, 1.5, True):
                with self.assertRaises(ArgumentError):
                    k.submit(1, 1, [p], watchdog=bad)

    def test_implicit_sync_on_transfer_and_strict_mode(self):
        with dev_() as dev:
            k = load(dev, INC)
            p = dev.alloc(4)
            k.submit(1, 1, [p])
            self.assertEqual(p.read_words(1), [1])                            # read waited for the launch
            self.assertTrue(any(s.reason.startswith("implicit") for s in dev.profiler.syncs))
        with dev_(auto_sync=False) as dev:
            k = load(dev, INC)
            p = dev.alloc(4)
            k.submit(1, 1, [p])
            with self.assertRaises(DeviceBusy):
                p.read_words(1)
            dev.synchronize()
            self.assertEqual(p.read_words(1), [1])

    @unittest.skipUnless(BACKEND == "reference", "line-protocol server is the reference model")
    def test_line_protocol_transport_gives_identical_results(self):
        cfg = Config.named("default")
        results = []
        for t in (ReferenceTransport(cfg), LineTransport.reference_server(cfg)):
            with open_device(transport=t) as dev:
                k = load(dev, TRIPLE)
                out = dev.alloc(4 * 40)
                r = k.launch(3, 16, [out, 40])
                results.append((out.read_words(), r.ticks, r.issued, r.lane_ops))
        self.assertEqual(results[0], results[1])


class FaultReporting(unittest.TestCase):
    """Every execution fault, decoded, through the SDK.  (Single-warp launches: FAULT_LOC is schedule independent.)"""

    def run_fault(self, src, name, *, grid=1, wg=1, shared=None, cfg="default", args=(), watchdog=None):
        with dev_("reference:" + cfg) as dev:
            k = load(dev, src, "f.sfa")
            buf = dev.alloc(64, name="victim")
            buf.write_words([0x11111111] * 16)
            with self.assertRaises(DeviceFault) as cm:
                k.launch(grid, wg, list(args), shared=shared, watchdog=watchdog)
            rep = cm.exception.report
            self.assertEqual(rep.name, name)
            self.assertEqual(cm.exception.code, name)
            self.assertIn(name, str(cm.exception))
            # the device is usable again and global memory survived the soft reset
            self.assertTrue(dev.status()["ready"] and not dev.status()["faulted"])
            self.assertEqual(buf.read_words(), [0x11111111] * 16)
            ok = load(dev, INC)
            ok.launch(1, 1, [buf])
            self.assertEqual(buf.read_words(1), [0x11111112])
            return rep

    def test_illegal_instruction(self):
        r = self.run_fault(".word 0xFFFFFFFF\nexit\n", "F_ILLEGAL_INSN")
        self.assertEqual((r.regs["PC"], r.regs["DATA"]), (0, 0xFFFFFFFF))
        self.assertEqual(r.source_line, 1)
        self.assertEqual(r.insn_text, ".word 0xffffffff")

    def test_pc_range_fall_off_end(self):
        r = self.run_fault("nop\nnop\n", "F_PC_RANGE")
        self.assertEqual((r.regs["PC"], r.regs["DATA"]), (2, 2))
        self.assertIsNone(r.insn_text)                                        # nothing at pc 2: it is past the image

    def test_reconvergence_layout_violation(self):
        r = self.run_fault("rdsr r1, SR_LANE_ID\nbnz r1, 4, 2\nnop\nnop\nnop\nexit\n", "F_RECONV", wg=2)
        self.assertEqual(r.regs["DATA"], 2)

    def test_global_alignment_and_range(self):
        r = self.run_fault("addi r1, r0, 6\nldg r2, [r1]\nexit\n", "F_GMEM_ALIGN")
        self.assertEqual((r.regs["PC"], r.regs["DATA"]), (1, 6))
        self.assertEqual(r.insn_text, "ldg r2, [r1]")
        r = self.run_fault("lui r1, 0x20000\nstg r1, [r1]\nexit\n", "F_GMEM_RANGE")
        self.assertEqual(r.regs["DATA"], 0x20000 << 10)
        self.assertIn("beyond the end of global memory", r.meaning)

    def test_address_descriptions_name_the_nearest_buffer(self):
        with dev_() as dev:
            a = dev.alloc(64, name="vec")
            self.assertIn("inside buffer 'vec' (+8 of 64 bytes)", dev.describe_address(a.addr + 8))
            self.assertIn("0 bytes past the end of buffer 'vec'", dev.describe_address(a.addr + 64))
            self.assertIn("8 bytes before buffer 'vec'", dev.describe_address(a.addr - 8))
            self.assertIn("unallocated", dev.describe_address(a.addr + 4096))
            self.assertIn("beyond the end of global memory", dev.describe_address(dev.config.gmem_bytes + 8))
            self.assertIn("reserved low region", dev.describe_address(0x40))

    def test_shared_alignment_and_range(self):
        r = self.run_fault("addi r1, r0, 2\nlds r2, [r1]\nexit\n", "F_SMEM_ALIGN", shared=64)
        self.assertEqual(r.regs["DATA"], 2)
        r = self.run_fault("addi r1, r0, 64\nlds r2, [r1]\nexit\n", "F_SMEM_RANGE", shared=64)
        self.assertEqual(r.regs["DATA"], 64)
        self.assertIn("SHARED_BYTES=64", r.meaning)

    def test_stack_overflow_on_small_config(self):
        src = """
            rdsr r1, SR_LANE_ID
            andi r2, r1, 1
            bnz  r2, tk, j1
            nop
            bra  j1
        tk: andi r3, r1, 2
            bz   r3, e2, j2
            nop
            bra  j2
        e2: nop
        j2: nop
        j1: exit
        """
        r = self.run_fault(src, "F_STACK_OVERFLOW", wg=4, cfg="small")
        self.assertEqual(r.regs["DATA"], 3)                                   # depth when the second divergence was attempted
        self.assertIn("2*lanes-1 = 7", r.meaning)
        with dev_("reference:default") as dev:                                # default depth 16 holds it
            self.assertTrue(load(dev, src).launch(1, 4).ok)

    def test_divergent_barrier(self):
        r = self.run_fault("rdsr r1, SR_LANE_ID\nandi r2, r1, 1\nbz r2, j, j\nbar\nj: exit\n", "F_BAR_DIVERGENT", wg=2)
        self.assertEqual(r.regs["DATA"], 0b11)

    def test_trap(self):
        r = self.run_fault("nop\ntrap 1234\nexit\n", "F_TRAP")
        self.assertEqual((r.regs["PC"], r.regs["DATA"]), (1, 1234))
        self.assertIn("trap 1234", r.insn_text)

    def test_watchdog(self):
        r = self.run_fault(SPIN, "F_WATCHDOG", watchdog=300)
        self.assertGreaterEqual(r.regs["DATA"], 300)
        self.assertEqual((r.where["eg"], r.where["lane"]), (0xFF, 0xFF))
        self.assertIsNone(r.insn_text)

    def test_fault_location_decoded(self):
        r = self.run_fault("rdsr r1, SR_LANE_ID\nrdsr r2, SR_GTID\nxori r1, r1, 3\nbnz r1, ok, ok\ntrap 9\nok: exit\n", "F_TRAP", wg=4)
        self.assertEqual(r.where["lane"], 3)                                  # lane 3 is the only one that reaches the trap
        self.assertEqual(r.regs["MASK"], 0b1000)

    def test_fault_cancels_queued_launches_and_recovers(self):
        with dev_() as dev:
            bad = load(dev, "trap 1\n")
            inc = load(dev, INC)
            p = dev.alloc(4)
            a, b, c = bad.submit(1, 1), inc.submit(1, 1, [p]), inc.submit(1, 1, [p])
            with self.assertRaises(DeviceFault):
                a.wait()
            self.assertEqual((b.state, c.state), ("cancelled", "cancelled"))
            with self.assertRaises(ApiError) as cm:
                b.wait()
            self.assertEqual(cm.exception.code, "E_CANCELLED")
            self.assertEqual(p.read_words(1), [0])
            inc.launch(1, 1, [p])
            self.assertEqual(p.read_words(1), [1])
            self.assertEqual(dev.last_fault.name, "F_TRAP")

    def test_launch_rejected_decodes_launch_error(self):
        with dev_() as dev:
            k = load(dev, "exit\n")
            cases = {"LE_DIMS": BoundLaunch(0, 1, 0, [], {}, 0, []), "LE_SHARED": BoundLaunch(1, 1, 8192, [], {}, 0, []),
                     "LE_ALIGN": BoundLaunch(1, 1, 6, [], {}, 0, []), "LE_RESERVED": BoundLaunch(1, 1, 0, [], {}, 0x80, [])}
            for name, bound in cases.items():
                ln = dev._enqueue(k, bound, None)
                with self.assertRaises(LaunchRejected) as cm:
                    ln.wait()
                self.assertEqual(cm.exception.name, name)
                self.assertEqual(ln.state, "rejected")
                self.assertTrue(dev.status()["ready"])
            self.assertTrue(k.launch(1, 1).ok)                                # device still usable

    def test_timeout_recovers_the_device(self):
        with dev_() as dev:
            k = load(dev, SPIN)
            with self.assertRaises(DeviceTimeout):
                k.launch(1, 1, watchdog=0, timeout_ticks=2000)
            self.assertTrue(dev.status()["ready"] and not dev.status()["busy"])
            self.assertTrue(load(dev, "exit\n").launch(1, 1).ok)
            self.assertEqual(dev.profiler.launches[0].status, "timeout")

    def test_guard_canary_detects_out_of_bounds_store_and_recovers(self):
        with dev_() as dev:
            buf = dev.alloc(64, name="small_buf")
            other = dev.alloc(64, name="neighbour")
            k = load(dev, ".kernel oob\n.arg ptr p\nrdsr r1, SR_ARG0\naddi r1, r1, 64\naddi r2, r0, 77\nstg r2, [r1]\nexit\n")
            with self.assertRaises(BufferCorrupted) as cm:
                k.launch(1, 1, [buf])
            self.assertIn("small_buf", str(cm.exception))
            self.assertIn("0 bytes past the end", str(cm.exception))
            self.assertEqual(other.read_words(), [0] * 16)
            self.assertEqual(dev.check_guards(), [])                          # repaired after reporting
            with open_device(guard=False) as raw:                             # guards off: the overrun is silent
                b2 = raw.alloc(64)
                self.assertTrue(raw.load_kernel(k.image).launch(1, 1, [b2]).ok)

    def test_guard_damage_before_a_fault_is_attributed_to_the_faulting_launch(self):
        with dev_() as dev:
            buf = dev.alloc(64, name="victim_buf")
            bad = load(dev, ".kernel oob_then_trap\n.arg ptr p\nrdsr r1, SR_ARG0\naddi r1, r1, 64\nstg r0, [r1]\ntrap 3\n")
            with self.assertRaises(DeviceFault) as cm:
                bad.launch(1, 1, [buf])
            notes = cm.exception.report.notes
            if BACKEND == "reference":                                        # zero-latency memory: the store has landed
                self.assertTrue(any("victim_buf" in n for n in notes), notes)
                self.assertIn("also:", str(cm.exception))
            else:                                                             # posted stores may be dropped at a fault (docs/08 8.2):
                self.assertTrue(all("victim_buf" in n for n in notes), notes)  # either not visible, or correctly attributed
            self.assertTrue(load(dev, "exit\n").launch(1, 1).ok)             # in every case the next, innocent launch is not blamed
            self.assertEqual(dev.check_guards(), [])

    def test_guard_damage_before_a_timeout_is_attributed_to_the_timed_out_launch(self):
        with dev_() as dev:
            buf = dev.alloc(64, name="t_buf")
            spin = load(dev, ".kernel oob_then_spin\n.arg ptr p\nrdsr r1, SR_ARG0\naddi r1, r1, 64\nstg r0, [r1]\nL: bra L\n")
            with self.assertRaises(DeviceTimeout) as cm:
                spin.launch(1, 1, [buf], watchdog=0, timeout_ticks=1500)
            self.assertIn("t_buf", str(cm.exception))
            self.assertTrue(load(dev, "exit\n").launch(1, 1).ok)

    def test_stale_host_error_is_cleared_and_mid_launch_host_error_is_reported(self):
        with dev_() as dev:
            dev.t.reg_read(0xFFC)                                             # unmapped register: sets HOST_ERR
            self.assertTrue(dev.reg("INT_STATUS") & 8)
            r = load(dev, "exit\n").launch(1, 1)
            self.assertEqual(r.warnings, [])                                  # stale bit from before the launch: cleared at launch start
            self.assertEqual(dev.reg("INT_STATUS"), 0)

        class Noisy(ReferenceTransport):                                      # raises HOST_ERR while the launch runs
            def advance(s, n):
                s.dev.int_status |= 8
                return super().advance(n)
        with open_device(transport=Noisy(Config.named("default"))) as dev:
            r = load(dev, "exit\n").launch(1, 1)
            self.assertTrue(any("HOST_ERR" in w for w in r.warnings))
            self.assertEqual(dev.reg("INT_STATUS"), 0)


class Profiling(unittest.TestCase):
    def test_profile_contents(self):
        with dev_(keep_trace=True) as dev:
            k = load(dev, TRIPLE)
            out = dev.alloc(4 * 20)
            out.write_words(list(range(20)))
            r = k.launch(2, 16, [out, 20])
            out.read_words()
            prof = dev.profiler
            self.assertEqual(len(prof.launches), 1)
            ev = prof.launches[0]
            self.assertEqual((ev.kernel, ev.status, ev.ticks, ev.issued), ("triple", "done", r.ticks, r.issued))
            self.assertAlmostEqual(ev.simt_efficiency, r.simt_efficiency)
            self.assertAlmostEqual(ev.ipc, r.issued / r.ticks)
            self.assertLessEqual(ev.issue_utilization, 1.0)
            ts = prof.transfer_summary()
            self.assertGreaterEqual(ts["h2d"]["count"], 2)                    # kernel image + data (+ descriptor)
            self.assertEqual(ts["d2h"]["bytes"], 80 + 0)
            text = prof.report()
            for needle in ("triple", "warp-insn", "simt%", "transfers"):
                self.assertIn(needle, text)
            data = json.loads(prof.to_json())
            self.assertEqual(data["per_kernel"]["triple"]["launches"], 1)
            self.assertIn("ticks", data["clocks"])
            ip = r.instruction_profile()
            self.assertEqual(ip.total_issued, r.issued)
            self.assertAlmostEqual(ip.simt_efficiency(), r.simt_efficiency)
            self.assertIn("slt", ip.text())
            self.assertGreater(ip.hottest(1)[0].executions, 0)

    def test_instruction_profile_requires_trace(self):
        with dev_() as dev:
            r = load(dev, "exit\n").launch(1, 1)
            with self.assertRaises(ApiError):
                r.instruction_profile()

    def test_failed_launches_are_recorded(self):
        with dev_() as dev:
            with self.assertRaises(DeviceFault):
                load(dev, "trap 5\n").launch(1, 1)
            self.assertEqual([e.status for e in dev.profiler.launches], ["fault"])
            self.assertEqual(dev.profiler.launches[0].error, "F_TRAP")
            self.assertEqual(dev.profiler.per_kernel()["trap5"]["faults"] if "trap5" in dev.profiler.per_kernel() else 1, 1)


class BringUp(unittest.TestCase):
    def _patched(self, reg, value):
        class T(ReferenceTransport):
            def reg_read(s, off):
                return value if off == R[reg] else super().reg_read(off)
        return T(Config.named("default"))

    def test_wrong_device_id(self):
        with self.assertRaises(DeviceMismatch) as cm:
            open_device(transport=self._patched("ID", 0x12345678))
        self.assertIn("not an SF-G1", str(cm.exception))

    def test_cfg_hash_mismatch_is_refused(self):
        with self.assertRaises(DeviceMismatch) as cm:
            open_device(transport=self._patched("CFG_HASH", 0xBADC0DE))
        self.assertIn("CFG_HASH mismatch", str(cm.exception))

    def test_major_version_mismatch(self):
        with self.assertRaises(DeviceMismatch):
            open_device(transport=self._patched("VERSION", 0x00020000))

    def test_caps_inconsistent_with_configuration(self):
        with self.assertRaises(DeviceMismatch):
            open_device(transport=self._patched("CAPS_GMEM", 0x2000))

    def test_to_words(self):
        self.assertEqual(to_words([1, -1]), b"\x01\x00\x00\x00\xff\xff\xff\xff")
        self.assertEqual(to_words(b"ab"), b"ab")


if __name__ == "__main__":
    unittest.main()
