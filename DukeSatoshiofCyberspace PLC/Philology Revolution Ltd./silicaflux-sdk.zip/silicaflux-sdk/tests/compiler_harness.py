"""Helpers shared by the compiler tests: run a compiled kernel on the reference simulator (through the vendored
host driver, not the SDK runtime) and/or on the IR interpreter, and compare memory."""
from __future__ import annotations

import struct
from typing import Dict, List, Optional, Sequence, Tuple, Union

from sfsdk import _ref, expr
from sfsdk.binfmt import KernelImage
from sfsdk.spec import Config

from sfg1.host import open_local  # noqa: E402  (vendored reference host driver; path set up by sfsdk._ref)

MASK32 = 0xFFFFFFFF
ALLOC_BASE = 0x100


class RequirementFailed(Exception):
    """The kernel's own launch precondition (`require`) rejects this geometry: the launch must not be attempted."""


def ref_config(cfg: Config):
    return _ref.ref_spec.Config.from_dict(cfg.parameters(), name=cfg.name)


class Buffers:
    """Deterministic buffer layout shared by the reference run and the interpreter run (same addresses)."""

    def __init__(self, bufs: Dict[str, Sequence[int]]) -> None:
        self.addr: Dict[str, int] = {}
        self.data: Dict[str, List[int]] = {k: [x & MASK32 for x in v] for k, v in bufs.items()}
        nxt = ALLOC_BASE
        for name, words in self.data.items():
            a = (nxt + 63) & ~63
            self.addr[name] = a
            nxt = a + max(4 * len(words), 4)
        self.end = nxt

    def resolve(self, args: Sequence[Union[int, str]]) -> List[int]:
        return [self.addr[a] if isinstance(a, str) else a & MASK32 for a in args]

    def image(self, size: int) -> bytearray:
        mem = bytearray(size)
        for name, words in self.data.items():
            a = self.addr[name]
            mem[a:a + 4 * len(words)] = struct.pack(f"<{len(words)}I", *words)
        return mem

    def extract(self, mem: bytes) -> Dict[str, List[int]]:
        return {n: list(struct.unpack_from(f"<{len(w)}I", mem, self.addr[n])) for n, w in self.data.items()}


def shared_bytes_for(image: KernelImage, arg_values: Dict[str, int], grid: int, wg: int, lanes: int) -> int:
    syms = dict(arg_values)
    syms.update({"wg_dim": wg, "grid_dim": grid, "lanes": lanes})
    m = image.meta
    return expr.evaluate(m.shared, syms) + expr.evaluate(m.shared_per_thread, syms) * wg


def arg_names(image: KernelImage) -> List[str]:
    return [a.name for a in image.meta.args]


def check_requires(image: KernelImage, arg_values: Dict[str, int], grid: int, wg: int, lanes: int) -> None:
    syms = dict(arg_values)
    syms.update({"wg_dim": wg, "grid_dim": grid, "lanes": lanes})
    for e, msg in image.meta.requires:
        if not expr.evaluate(e, syms):
            raise RequirementFailed(msg)


def run_reference(image: KernelImage, cfg: Config, grid: int, wg: int, bufs: Dict[str, Sequence[int]],
                  args: Sequence[Union[int, str]], shared: Optional[int] = None, max_ticks: int = 20_000_000,
                  trace: bool = False):
    """Returns (outputs, LaunchResult, device)."""
    b = Buffers(bufs)
    host = open_local(ref_config(cfg), trace=trace)
    dev = host.device
    for name, words in b.data.items():
        a = host.alloc(max(4 * len(words), 4))
        assert a == b.addr[name], (name, a, b.addr[name])
        if words:
            host.write_words(a, words)
    vals = b.resolve(args)
    names = arg_names(image)
    av = dict(zip(names, vals))
    check_requires(image, av, grid, wg, cfg.lanes)
    sh = shared_bytes_for(image, av, grid, wg, cfg.lanes) if shared is None else shared
    k = host.load_kernel(image.words)
    res = host.launch(k, grid, wg, sh, vals, max_ticks=max_ticks)
    out = None
    if res.status == "done":
        mem = bytes(dev.gmem)
        out = b.extract(mem)
    return out, res, dev


def run_interp(kernel, cfg: Config, grid: int, wg: int, bufs: Dict[str, Sequence[int]],
               args: Sequence[Union[int, str]], shared_bytes: int, max_steps: int = 2_000_000):
    from sfsdk.compiler.interp import interpret
    b = Buffers(bufs)
    mem = b.image(max(b.end + 64, 4096))
    interpret(kernel, grid, wg, b.resolve(args), mem, lanes=cfg.lanes, shared_bytes=shared_bytes,
              max_steps=max_steps)
    return b.extract(bytes(mem))


# ----------------------------------------------------------------------------- differential runner
def diff_case(case, cfg: Config, max_regs: Optional[int] = None, opt: bool = True):
    """Compile ``case`` (a ``sfsdk.compiler.fuzz.FuzzCase``) and compare the reference simulator against the IR
    interpreter.  Returns ``(ok, message, compile_result)``."""
    from sfsdk.compiler import compile_ir, parse_ir
    from sfsdk.compiler.interp import InterpError
    res = compile_ir(case.text, "fuzz.sfir", cfg, max_regs=max_regs, opt=opt)
    img = res.image()
    kernel = parse_ir(case.text).kernel()
    b = Buffers(case.bufs)
    av = dict(zip(arg_names(img), b.resolve(case.args)))
    shared = shared_bytes_for(img, av, case.grid, case.wg, cfg.lanes)
    try:
        out, run, _dev = run_reference(img, cfg, case.grid, case.wg, case.bufs, case.args, shared=shared)
    except RequirementFailed as e:
        return True, f"skipped: {e}", res
    if run.status == "fault" and run.error == "F_STACK_OVERFLOW" and res.info["stack_overflow_possible"]:
        return True, "skipped: F_STACK_OVERFLOW (the compiler warned this configuration's stack may be too small)", res
    if run.status != "done":
        return False, f"reference run {run.status}: {run.error}", res
    try:
        exp = run_interp(kernel, cfg, case.grid, case.wg, case.bufs, case.args, shared_bytes=eval_user_shared(img, av,
                         case.grid, case.wg, cfg.lanes))
    except InterpError as e:
        return False, f"interpreter error (generator bug?): {e}", res
    for name in exp:
        if out[name] != exp[name]:
            first = next(i for i, (x, y) in enumerate(zip(out[name], exp[name])) if x != y)
            return False, (f"buffer '{name}' differs at word {first}: device {out[name][first]:#x} "
                           f"interp {exp[name][first]:#x}"), res
    return True, "ok", res


def eval_user_shared(image: KernelImage, arg_values: Dict[str, int], grid: int, wg: int, lanes: int) -> int:
    """The kernel's own shared-memory demand (without the spill area)."""
    syms = dict(arg_values)
    syms.update({"wg_dim": wg, "grid_dim": grid, "lanes": lanes})
    return expr.evaluate(image.meta.shared, syms)
