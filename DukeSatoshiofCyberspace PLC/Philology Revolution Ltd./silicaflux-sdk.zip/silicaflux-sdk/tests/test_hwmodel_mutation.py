"""Can the verification fail?  Inject deliberate bugs into the hardware model (monkey-patching the live
classes) and require the conformance suite to catch every one.  A suite that cannot fail proves nothing.

Each mutant names the check(s) expected to catch it; the whole suite is *not* re-run per mutant, only the
named checks on the stated configurations (the full suite runs in test_conformance.py on the unmutated model).
"""
import unittest
from contextlib import contextmanager
from unittest import mock

import sfsdk._ref  # noqa: F401
from sfsdk import conformance
from sfsdk.hwmodel import HwModelTransport
from sfsdk.hwmodel import alu as hw_alu
from tests.test_hwmodel_support import PARAM_SETS
from sfsdk.hwmodel import device as hw_dev
from sfsdk.hwmodel.memory import MemSystem
from sfsdk.hwmodel.simt import HwSimtStack
from sfsdk.spec import MASK32


def _wrap(cls, name, fn_factory):
    """Replace method ``name`` of ``cls`` by ``fn_factory(original)``."""
    orig = getattr(cls, name)
    return mock.patch.object(cls, name, fn_factory(orig))


# ---------------------------------------------------------------------------------------------- mutants
def m_sar_logical():
    return mock.patch.dict(hw_alu.LANE_ALU, {"SAR": lambda a, b: a >> (b & 31)})


def m_slt_unsigned():
    return mock.patch.dict(hw_alu.LANE_ALU, {"SLT": lambda a, b: int(a < b)})


def m_sub_wraps_wrong():
    return mock.patch.dict(hw_alu.LANE_ALU, {"SUB": lambda a, b: (a - b - 1) & MASK32 if b == 0x80000000 else (a - b) & MASK32})


def m_store_order_reversed():
    def f(orig):
        def bad(self, req):
            if req.kind in ("stg", "sts"):
                req.addrs, req.vals = req.addrs[::-1], req.vals[::-1]
            orig(self, req)
        return bad
    return _wrap(MemSystem, "_apply", f)


def m_atomic_old_values_reversed():
    def f(orig):
        def bad(self, req):
            orig(self, req)
            if req.kind == "atomadd":
                req.result = req.result[::-1]
        return bad
    return _wrap(MemSystem, "_apply", f)


def m_loads_sample_memory_at_start():
    """C2 violation: a load reads memory when the port starts it, not when it completes, so it can miss the
    same thread's older posted store that is still in flight."""
    o_start, o_apply = MemSystem._start, MemSystem._apply

    def start(self, w, req, port_list, idx, now):
        o_start(self, w, req, port_list, idx, now)
        if req.kind in ("ldg", "lds"):
            o_apply(self, req)                       # read now ...

    def apply(self, req):
        if req.kind in ("ldg", "lds") and req.result is not None:
            return                                   # ... and keep the early value
        o_apply(self, req)
    return [mock.patch.object(MemSystem, "_start", start), mock.patch.object(MemSystem, "_apply", apply)]


def m_barrier_does_not_drain():
    def f(orig):
        def bad(self, eg, w, fl, now):
            orig(self, eg, w, fl, now)
            if fl.ins.iclass == "BAR" and fl.drain:
                fl.drain, fl.stage, fl.next = False, hw_dev.P_WB, now + 1
        return bad
    return _wrap(hw_dev.HwDevice, "_execute", f)


def m_done_before_memory_drains():
    def f(orig):
        def bad(self, eg, w, fl, now):
            orig(self, eg, w, fl, now)
            if fl.ins.iclass == "EXIT" and fl.drain:
                fl.drain, fl.stage, fl.next = False, hw_dev.P_WB, now + 1
        return bad
    return [_wrap(hw_dev.HwDevice, "_execute", f), mock.patch.object(MemSystem, "busy", lambda self: False)]


def m_stack_no_reuse():
    orig = HwSimtStack._plan

    def bad(self, cond, target, reconv):
        kind, paths, reuse, needed = orig(self, cond, target, reconv)
        if kind == "split":
            return kind, paths, False, len(paths)
        return kind, paths, reuse, needed
    return mock.patch.object(HwSimtStack, "_plan", bad)


def m_range_checked_before_alignment():
    def f(orig):
        def bad(pc, lanes, addrs, limit, align_code, range_code):
            for l, a in zip(lanes, addrs):
                if a >= limit:
                    raise hw_dev.Fault(range_code, pc, a, l)
                if a & 3:
                    raise hw_dev.Fault(align_code, pc, a, l)
        return staticmethod(bad)
    return mock.patch.object(hw_dev.HwDevice, "_check_addrs", f(None))


def m_highest_failing_lane_reported():
    def bad(pc, lanes, addrs, limit, align_code, range_code):
        for l, a in reversed(list(zip(lanes, addrs))):
            if a & 3:
                raise hw_dev.Fault(align_code, pc, a, l)
            if a >= limit:
                raise hw_dev.Fault(range_code, pc, a, l)
    return mock.patch.object(hw_dev.HwDevice, "_check_addrs", staticmethod(bad))


def m_reserved_flag_bits_accepted():
    def f(orig):
        def bad(self, *a, **k):
            orig(self, *a, **k)
            self._flag_known = 0xFFFF
        return bad
    return _wrap(hw_dev.HwDevice, "_validate", lambda orig: (lambda self: (setattr(self, "_flag_known", 0xFFFF), orig(self))[1]))


def m_host_err_never_set():
    return mock.patch.object(hw_dev.HwDevice, "_host_err", lambda self: None)


def m_barrier_waits_for_exited_warps():
    def bad(self, wg, now):
        parts = list(wg.warps)
        if parts and all(x.state == hw_dev.W_BARRIER for x in parts):
            for x in parts:
                x.state, x.ready_at = hw_dev.W_READY, now + 2
    return mock.patch.object(hw_dev.HwDevice, "_barrier_check", bad)


def m_shared_slots_alias():
    def f(orig):
        def bad(self, eg, w, fl, now):
            orig(self, eg, w, fl, now)
            if fl.req is not None and fl.req.space == "s":
                fl.req.base = 0
        return bad
    return _wrap(hw_dev.HwDevice, "_execute", f)


def m_smem_zero_ignored():
    def f(orig):
        def bad(self, now):
            self.flags = 0
            orig(self, now)
        return bad
    return _wrap(hw_dev.HwDevice, "_dispatch", f)


def m_fault_instruction_counted():
    def f(orig):
        def bad(self, *a, **k):
            self.perf_issued += 1
            orig(self, *a, **k)
        return bad
    return _wrap(hw_dev.HwDevice, "_latch_fault", f)


def m_w1c_clears_everything():
    def f(orig):
        def bad(self, off, val):
            if off == hw_dev._D.reg_offset["INT_STATUS"]:
                val = 0xF
            orig(self, off, val)
        return bad
    return _wrap(hw_dev.HwDevice, "reg_write", f)


def m_done_not_cleared_by_doorbell():
    def f(orig):
        def bad(self):
            was = self.done
            orig(self)
            if self.state == hw_dev.S_LAUNCHING:
                self.done = was
        return bad
    return _wrap(hw_dev.HwDevice, "_doorbell", f)


def m_lane_ops_off_by_one():
    def f(orig):
        def bad(self, eg, w, fl, now):
            orig(self, eg, w, fl, now)
            self.perf_lane_ops += 1
        return bad
    return _wrap(hw_dev.HwDevice, "_writeback", f)


def m_warp_id_wrong():
    def f(orig):
        def bad(self, idx, w, lane):
            v = orig(self, idx, w, lane)
            return v + 1 if idx == hw_dev._SR["SR_WARP_ID"] else v
        return bad
    return _wrap(hw_dev.HwDevice, "_sr_value", f)


def m_partial_warp_fully_live():
    """small configuration (4 lanes): a partial warp gets one more live lane than it has threads."""
    orig = HwSimtStack.start

    def bad(self, pc, mask):
        orig(self, pc, (mask | (mask + 1)) & 0xF)
    return mock.patch.object(HwSimtStack, "start", bad)


# (name, mutant factory, [checks any of which must catch it], configs, parameter set name(s) of the model under test;
#  with several, the mutant counts as caught if ANY of them exposes it -- e.g. a missing store drain is only visible
#  when completion order across warps can invert, which depends on the jitter seed)
MUTANTS = [
    ("sar-is-logical", m_sar_logical, ["alu_semantics"], ("small",), "default"),
    ("slt-is-unsigned", m_slt_unsigned, ["alu_semantics"], ("small",), "default"),
    ("sub-corner-case", m_sub_wraps_wrong, ["alu_semantics"], ("small",), "default"),
    ("store-lane-order-reversed", m_store_order_reversed, ["store_lane_order"], ("small",), "default"),
    ("atomic-old-values-reversed", m_atomic_old_values_reversed, ["atomadd_lane_order"], ("small",), "default"),
    ("loads-sample-memory-before-older-stores-complete", m_loads_sample_memory_at_start,
     ["same_thread_read_after_write"], ("small",), "default"),
    ("barrier-does-not-drain-stores", m_barrier_does_not_drain, ["barrier_publishes"], ("small",),
     ("jitter_heavy_0", "jitter_heavy_1", "jitter_heavy_2")),
    ("done-before-memory-drains", m_done_before_memory_drains,
     ["example_vecadd_matches_independent", "example_matmul_i32_matches_independent"], ("small",), "default"),
    ("simt-stack-reuse-disabled", m_stack_no_reuse,
     ["example_diverge_matches_golden", "example_reduce_sum_matches_golden"], ("default",), "default"),
    ("range-checked-before-alignment", m_range_checked_before_alignment, ["fault_global_memory"], ("small",), "default"),
    ("highest-failing-lane-reported", m_highest_failing_lane_reported, ["fault_memory_instruction"], ("small",), "default"),
    ("reserved-descriptor-flags-accepted", m_reserved_flag_bits_accepted,
     ["launch_error_magic_version_reserved"], ("small",), "default"),
    ("host-err-never-raised", m_host_err_never_set, ["registers_unmapped"], ("small",), "default"),
    ("barrier-waits-for-exited-warps", m_barrier_waits_for_exited_warps, ["barrier_ignores_exited"], ("small",), "default"),
    ("shared-memory-slots-alias", m_shared_slots_alias, ["shared_memory_is_private"], ("default",), "default"),
    ("smem-zero-flag-ignored", m_smem_zero_ignored, ["smem_zero_flag"], ("small",), "default"),
    ("faulting-instruction-counted", m_fault_instruction_counted, ["perf_counters_exclude_faulting"], ("small",), "default"),
    ("w1c-clears-everything", m_w1c_clears_everything, ["registers_w1c"], ("small",), "default"),
    ("done-survives-next-doorbell", m_done_not_cleared_by_doorbell, ["launch_error_counters_cleared"], ("small",), "default"),
    ("lane-ops-off-by-one", m_lane_ops_off_by_one, ["perf_counters_architectural"], ("small",), "default"),
    ("warp-id-off-by-one", m_warp_id_wrong, ["special_registers"], ("small",), "default"),
    ("partial-warp-lanes-live", m_partial_warp_fully_live,
     ["special_registers", "perf_counters_architectural"], ("small",), "default"),
]


@contextmanager
def _applied(factory):
    made = factory()
    patches = made if isinstance(made, list) else [made]
    for p in patches:
        p.start()
    try:
        yield
    finally:
        for p in reversed(patches):
            p.stop()


class MutationCampaign(unittest.TestCase):
    def test_every_mutant_is_caught(self):
        survivors, caught_by = [], {}
        for name, factory, checks, configs, pnames in MUTANTS:
            with _applied(factory):
                failed = []
                for pname in ((pnames,) if isinstance(pnames, str) else pnames):
                    for chk in checks:
                        rep = conformance.run_conformance(
                            lambda c, p=PARAM_SETS[pname]: HwModelTransport(c, trace=True, params=p), configs, only=chk,
                            backend="mutant", fail_fast=True)
                        self.assertGreater(len(rep.checks), 0, f"mutant {name}: selector '{chk}' matched no check")
                        failed += [c.name for c in rep.failures()]
                if failed:
                    caught_by[name] = failed
                else:
                    survivors.append(name)
        self.assertEqual(survivors, [], f"mutants that the conformance suite did NOT catch: {survivors}")
        self.assertEqual(len(caught_by), len(MUTANTS))

    def test_unmutated_model_passes_the_same_checks(self):
        """Control: the very same selectors pass on the clean model (otherwise 'caught' would be meaningless)."""
        for name, _f, checks, configs, pnames in MUTANTS:
            for pname in ((pnames,) if isinstance(pnames, str) else pnames):
                for chk in checks:
                    rep = conformance.run_conformance(
                        lambda c, p=PARAM_SETS[pname]: HwModelTransport(c, trace=True, params=p), configs, only=chk,
                        backend="clean")
                    self.assertTrue(rep.ok, f"{name}/{chk}/{pname}: clean model must pass: {rep.summary()}")


if __name__ == "__main__":
    unittest.main()
