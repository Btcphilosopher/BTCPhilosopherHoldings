"""Parser, printer, verifier, semantics (checked against the ISA's ALU), folding and the IR interpreter."""
from __future__ import annotations

import random
import struct
import unittest
from pathlib import Path

from sfsdk import _ref
from sfsdk.compiler import ir, parse_ir, fold, verify, interp
from sfsdk.compiler import semantics
from sfsdk.compiler.interp import InterpError, interpret
from sfsdk.errors import CompileError
from sfsdk.isa import ISA

from sfg1 import alu as ref_alu  # vendored reference ALU (the ISA's ground truth)

ROOT = Path(__file__).resolve().parents[1]
M32 = 0xFFFFFFFF
CORNERS = [0, 1, 2, 3, 31, 32, 33, 0x7FFFFFFF, 0x80000000, 0x80000001, 0xFFFFFFFE, 0xFFFFFFFF, 0x12345678,
           0xAAAAAAAA, 0x55555555, 0x1FFFF, 0x20000, 0xFFFE0000]


def errs(src):
    try:
        parse_ir(src)
    except CompileError as e:
        return e.errors
    return []


class Parser(unittest.TestCase):
    def test_roundtrip_samples(self):
        for p in sorted((ROOT / "kernels").glob("*.sfir")):
            k = parse_ir(p.read_text(), str(p)).kernel()
            again = parse_ir(ir.format_kernel(k)).kernel()
            self.assertEqual(ir.format_kernel(k), ir.format_kernel(again), p.name)

    def test_header_params_and_attributes(self):
        k = parse_ir('''kernel k(ptr a r (M * K), ptr b, u32 M,
                         i32 K)
            shared 4*K
            require K > 0 "K must be positive"
        {
            return
        }''').kernel()
        self.assertEqual([(p.name, p.kind, p.access, p.extent) for p in k.params],
                         [("a", "ptr", "r", "M * K"), ("b", "ptr", "rw", None), ("M", "u32", "", None), ("K", "i32", "", None)])
        self.assertEqual(k.shared, "4*K")
        self.assertEqual(k.requires, [("K > 0", "K must be positive")])

    def test_operands_and_memory_forms(self):
        k = parse_ir('''kernel k(ptr p w, u32 n) {
            x = ld.g [p + 8]
            y = ld.s [x - 4]
            z = ld.s [x -4]
            st.g [p], 0xFFFFFFFF
            st.s [p + 0x10], -1
            q = add n, -2147483648
        }''').kernel()
        loads = [s for s in k.body if isinstance(s, ir.Load)]
        self.assertEqual([m.mem.off for m in loads], [8, -4, -4])
        self.assertEqual(k.body[3].value, ir.Opd.const(M32))
        self.assertEqual(k.body[5].args[1], ir.Opd.const(0x80000000))

    def test_collects_all_errors(self):
        e = errs('''kernel k(u32 n) {
            x = div n, 2
            y = foo n
            n = 3
            gtid = 4
            z = add n
        }''')
        self.assertGreaterEqual(len(e), 5, e)
        self.assertTrue(all(":" in m and "error:" in m for m in e))

    def test_unsupported_constructs_are_explained(self):
        cases = {
            "x = div n, 2": "no divide",
            "x = rem n, 2": "no divide",
            "x = mulh n, n": "low 32 bits",
            "x = ld.b [n]": "no byte access",
            "st.h [n], n": "no halfword access",
            "x = atomadd.s [n], 1": "no shared-memory atomics",
            "x = atommax [n], 1": "no atomic max",
            "x = cas [n], 1": "no compare-and-swap",
            "x = shfl n, 1": "no warp shuffle",
            "x = vote n": "no warp vote",
            "x = fadd n, n": "no floating point",
            "call foo": "no function calls",
            "printf n": "no printf",
            "goto top": "structured",
            "while n": "loop",
        }
        for stmt, why in cases.items():
            e = errs("kernel k(u32 n) {\n%s\n}" % stmt)
            self.assertTrue(e and why in e[0], (stmt, e))

    def test_continue_is_rejected_with_reason(self):
        e = errs("kernel k(u32 n) {\nloop {\ncontinue\n}\n}")
        self.assertTrue(e and "continue" in e[0] and "F_RECONV" in e[0], e)

    def test_float_param_kind_rejected(self):
        e = errs("kernel k(f32 x) {\nreturn\n}")
        self.assertTrue(e and "floating point" in e[0], e)

    def test_more_than_eight_params(self):
        e = errs("kernel k(" + ", ".join(f"u32 a{i}" for i in range(9)) + ") {\nreturn\n}")
        self.assertTrue(any("at most 8" in m for m in e), e)

    def test_structure_errors(self):
        self.assertTrue(errs("kernel k(u32 n) {\nif n {\n"))                       # unterminated
        self.assertTrue(errs("kernel k(u32 n) {\nelse {\n}\n}"))                    # stray else
        self.assertTrue(errs("kernel k(u32 n) {\nif lt n, 1 {\n}\n}"))              # condition must be an operand
        self.assertTrue(errs("kernel k(u32 n) {\nif n { return }\n}"))              # one statement per line
        self.assertTrue(errs("kernel k(u32 n) {\nx = 99999999999\n}"))              # literal too wide
        self.assertTrue(errs("kernel k(u32 n) {\nx = ld.g [n + 200000]\n}"))        # offset exceeds imm18
        self.assertTrue(errs("kernel k(u32 n) {\ntrap 70000\n}"))
        self.assertTrue(errs("garbage"))
        self.assertEqual(errs("# only a comment\n"), ["<ir>:1: error: no kernel found"])

    def test_expressions_in_attributes_are_checked(self):
        e = errs("kernel k(u32 n)\n shared 4*bogus\n{\nreturn\n}")
        self.assertEqual(errs("kernel k(u32 n)\n shared 4*n\n{\nreturn\n}"), [])
        # unknown names are caught by the verifier (it knows the parameter list)
        from sfsdk.compiler import compile_ir
        with self.assertRaises(CompileError) as cm:
            compile_ir("kernel k(u32 n)\n shared 4*bogus\n{\nreturn\n}")
        self.assertIn("unknown name 'bogus'", str(cm.exception))


class Semantics(unittest.TestCase):
    """The IR's value semantics (used by the folder and the interpreter) must equal the ISA's ALU."""

    PAIRS = {"add": "ADD", "sub": "SUB", "mul": "MUL", "and": "AND", "or": "OR", "xor": "XOR", "shl": "SHL",
             "shr": "SHR", "sar": "SAR", "lt": "SLT", "ltu": "SLTU"}

    def test_against_isa_alu(self):
        rng = random.Random(3)
        vals = CORNERS + [rng.getrandbits(32) for _ in range(40)]
        for op, fn in self.PAIRS.items():
            code = ISA.alu_functions[fn]
            for a in vals:
                for b in vals:
                    self.assertEqual(semantics.evaluate(op, [a, b]), ref_alu.alu(code, a, b), (op, hex(a), hex(b)))

    def test_derived_comparisons(self):
        slt, sltu = ISA.alu_functions["SLT"], ISA.alu_functions["SLTU"]
        for a in CORNERS:
            for b in CORNERS:
                S, U = ref_alu.alu(slt, a, b), ref_alu.alu(sltu, a, b)
                Sr, Ur = ref_alu.alu(slt, b, a), ref_alu.alu(sltu, b, a)
                ev = semantics.evaluate
                self.assertEqual(ev("gt", [a, b]), Sr)
                self.assertEqual(ev("gtu", [a, b]), Ur)
                self.assertEqual(ev("le", [a, b]), 1 - Sr)
                self.assertEqual(ev("leu", [a, b]), 1 - Ur)
                self.assertEqual(ev("ge", [a, b]), 1 - S)
                self.assertEqual(ev("geu", [a, b]), 1 - U)
                self.assertEqual(ev("eq", [a, b]), int(a == b))
                self.assertEqual(ev("ne", [a, b]), int(a != b))

    def test_unary_select_lea(self):
        ev = semantics.evaluate
        self.assertEqual(ev("not", [0x0F0F0F0F]), 0xF0F0F0F0)
        self.assertEqual(ev("neg", [1]), M32)
        self.assertEqual(ev("neg", [0x80000000]), 0x80000000)
        self.assertEqual((ev("lnot", [0]), ev("lnot", [5])), (1, 0))
        self.assertEqual((ev("bool", [0]), ev("bool", [0x80000000])), (0, 1))
        self.assertEqual(ev("select", [7, 11, 22]), 11)
        self.assertEqual(ev("select", [0, 11, 22]), 22)
        self.assertEqual(ev("lea", [100, 3]), 112)
        self.assertEqual(ev("lea", [M32, 1]), 3)                      # wraps


class Folding(unittest.TestCase):
    def kernel(self, body, params="u32 n"):
        k = parse_ir("kernel k(%s) {\n%s\n}" % (params, body)).kernel()
        verify.verify_kernel(k, "<ir>")
        return k

    def test_fold_literal_ops(self):
        k = fold.optimize(self.kernel("x = add 3, 4\ny = mul x, 6\nst.g [n], y"))
        st = [s for s in ir.walk(k.body) if isinstance(s, ir.Store)][0]
        self.assertEqual(st.value, ir.Opd.const(42))                  # propagated through two single-def variables

    def test_no_propagation_for_multiple_defs(self):
        k = fold.optimize(self.kernel("x = 1\nx = add x, n\nst.g [n], x"))
        st = [s for s in ir.walk(k.body) if isinstance(s, ir.Store)][0]
        self.assertEqual(st.value, ir.Opd.var("x"))

    def test_constant_if_is_eliminated_even_without_opt(self):
        for opt in (True, False):
            k = fold.optimize(self.kernel("if 1 {\nst.g [n], 1\n} else {\nst.g [n], 2\n}\nif 0 {\nst.g [n], 3\n}"), opt)
            vals = [s.value.value for s in ir.walk(k.body) if isinstance(s, ir.Store)]
            self.assertEqual(vals, [1], opt)
            self.assertFalse([s for s in ir.walk(k.body) if isinstance(s, ir.If)])

    def test_break_if_literals(self):
        k = fold.optimize(self.kernel("loop {\nbreak_if 0\nst.g [n], 1\nbreak_if 1\nst.g [n], 2\n}"))
        names = [type(s).__name__ for s in ir.walk(k.body)]
        self.assertEqual(names.count("Break"), 1)
        self.assertEqual(names.count("BreakIf"), 0)
        self.assertEqual(sum(1 for s in ir.walk(k.body) if isinstance(s, ir.Store)), 1)   # code after `break` is gone

    def test_select_with_literal_condition(self):
        k = fold.optimize(self.kernel("x = select 1, n, 5\nst.g [n], x"))
        a = [s for s in ir.walk(k.body) if isinstance(s, ir.Assign)][0]
        self.assertEqual((a.op, a.args), ("mov", [ir.Opd("param", "n")]))


class Verifier(unittest.TestCase):
    def check(self, body, *, errors=0, warns=0, params="u32 n"):
        k = parse_ir("kernel k(%s) {\n%s\n}" % (params, body)).kernel()
        if errors:
            with self.assertRaises(CompileError) as cm:
                verify.verify_kernel(k, "<ir>")
            self.assertEqual(len(cm.exception.errors), errors, cm.exception.errors)
            return cm.exception.errors
        w = verify.verify_kernel(k, "<ir>")
        self.assertEqual(len(w), warns, w)
        return w

    def test_definite_assignment(self):
        self.check("x = 1\nst.g [n], x")
        self.check("if n {\nx = 1\n} else {\nx = 2\n}\nst.g [n], x")                  # assigned on both arms
        e = self.check("if n {\nx = 1\n}\nst.g [n], x", errors=1)
        self.assertIn("may be used before it is assigned", e[0])
        e = self.check("st.g [n], y", errors=1)
        self.assertIn("never assigned", e[0])

    def test_loops_and_breaks_in_definite_assignment(self):
        self.check("loop {\nx = 1\nbreak\n}\nst.g [n], x")                            # assigned before the only break
        self.check("loop {\nx = 1\nbreak_if n\n}\nst.g [n], x")
        self.check("x = 0\nloop {\nbreak_if n\nx = add x, 1\n}\nst.g [n], x")
        self.check("loop {\nbreak_if n\ny = 1\n}\nst.g [n], n", warns=0)
        self.check("loop {\nbreak_if n\ny = 1\n}\nst.g [n], y", errors=1)             # y not assigned on the break path

    def test_break_outside_loop(self):
        self.check("break", errors=1)
        self.check("break_if n", errors=1)

    def test_unreachable_code_removed_with_warning(self):
        w = self.check("return\nst.g [n], 1", warns=1)
        self.assertIn("unreachable", w[0])
        self.check("loop {\nbreak\nst.g [n], 1\n}", warns=1)
        self.check("if n {\nreturn\n} else {\nreturn\n}\nst.g [n], 1", warns=1)

    def test_infinite_loop_warning(self):
        w = self.check("loop {\nst.g [n], 1\n}", warns=1)
        self.assertIn("never terminates", w[0])
        self.check("loop {\nreturn\n}", warns=0)                                      # exit via return is fine

    def test_unknown_names_in_expressions(self):
        k = parse_ir("kernel k(ptr p w n, u32 n)\n shared 4*zzz\n{\nreturn\n}").kernel()
        with self.assertRaises(CompileError):
            verify.verify_kernel(k, "<ir>")


class Interpreter(unittest.TestCase):
    def run_k(self, src, grid, wg, args, nbytes=4096, lanes=8, shared=0, **kw):
        k = parse_ir(src).kernel()
        mem = bytearray(nbytes)
        interpret(k, grid, wg, args, mem, lanes=lanes, shared_bytes=shared, **kw)
        return mem

    def words(self, mem, addr, n):
        return list(struct.unpack_from(f"<{n}I", mem, addr))

    def test_builtins(self):
        mem = self.run_k('''kernel k(ptr o w 1) {
            g = gtid
            p = lea o, g
            a = mul tid, 1000
            b = mul wg_id, 100
            c = add a, b
            d = add c, lane
            e = add d, warp
            st.g [p], e
        }''', 2, 5, [0x100], lanes=4)
        exp = [t * 1000 + w * 100 + (t % 4) + t // 4 for w in range(2) for t in range(5)]
        self.assertEqual(self.words(mem, 0x100, 10), exp)

    def test_atomadd_and_value_form(self):
        mem = self.run_k('''kernel k(ptr o w 2) {
            old = atomadd [o], 5
            p = lea o, 1
            q = add tid, wg_id
            st.g [p], q
        }''', 2, 3, [0x100])
        self.assertEqual(self.words(mem, 0x100, 1), [30])

    def test_barrier_phases_and_shared(self):
        src = '''kernel k(ptr o w 8) shared 4*wg_dim {
            off = shl tid, 2
            st.s [off], tid
            barrier
            nb = add tid, 1
            c = lt nb, wg_dim
            nb = select c, nb, 0
            noff = shl nb, 2
            v = ld.s [noff]
            p = lea o, tid
            st.g [p], v
        }'''.replace(") shared", ")\n shared").replace("{\n            off", "\n{\n            off", 1)
        mem = self.run_k(src, 1, 5, [0x100], shared=20, lanes=2)
        self.assertEqual(self.words(mem, 0x100, 5), [1, 2, 3, 4, 0])

    def test_faults_are_reported(self):
        with self.assertRaises(InterpError):
            self.run_k("kernel k(ptr o w 1) {\nst.g [o + 2], 1\n}", 1, 1, [0x100])        # misaligned
        with self.assertRaises(InterpError):
            self.run_k("kernel k(ptr o w 1) {\nst.g [o], 1\n}", 1, 1, [1 << 20])          # out of range
        with self.assertRaises(InterpError):
            self.run_k("kernel k(ptr o w 1) shared 8\n{\nst.s [o], 1\n}", 1, 1, [100], shared=8)
        with self.assertRaises(InterpError):
            self.run_k("kernel k(u32 n) {\ntrap 7\n}", 1, 1, [0])

    def test_divergent_barrier_detected(self):
        with self.assertRaises(InterpError):
            self.run_k('''kernel k(u32 n) {
                c = lt tid, 2
                if c {
                    barrier
                } else {
                    barrier
                }
            }''', 1, 4, [0], lanes=4)

    def test_exited_threads_do_not_block_barrier(self):
        self.run_k('''kernel k(u32 n) {
            c = lt tid, 2
            if c {
                return
            }
            barrier
            barrier
        }''', 1, 8, [0], lanes=4)

    def test_step_limit(self):
        with self.assertRaises(InterpError):
            self.run_k("kernel k(u32 n) {\nloop {\nx = 1\n}\n}", 1, 1, [0], max_steps=500)

    def test_unassigned_read_is_an_error(self):
        # (the verifier normally prevents this; the interpreter is defensive)
        k = ir.KernelBuilder("k", [ir.Param("n", "u32")])
        k.assign("x", "add", "y", 1)
        with self.assertRaises(InterpError):
            interpret(k.kernel, 1, 1, [0], bytearray(64))


if __name__ == "__main__":
    unittest.main()
