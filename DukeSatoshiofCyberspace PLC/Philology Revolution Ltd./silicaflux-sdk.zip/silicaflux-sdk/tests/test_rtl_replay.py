"""RTL replay: SDK binaries through the verified RTL blocks (skipped when Icarus Verilog is not installed)."""
import unittest

from sfsdk import rtl_replay
from sfsdk.runtime import Device
from tests._golden import EXAMPLES, run_example

AVAILABLE, WHY = rtl_replay.tools_available()


@unittest.skipUnless(AVAILABLE, WHY)
class RtlReplay(unittest.TestCase):
    def test_reference_examples_through_rtl_all_configs(self):
        workloads = {n: (lambda dev, n=n: run_example(dev, n)) for n in EXAMPLES}
        for rep in rtl_replay.replay(workloads, ("default", "small", "wide")):
            print("\n" + rep.text())
            self.assertTrue(rep.ok, rep.text())
            self.assertEqual({b.block for b in rep.blocks}, {"decode", "alu", "simt_stack"})
            self.assertGreater(rep.stack_commands, 500)
            self.assertGreater(rep.alu_ops, 100)
            for b in rep.blocks:
                self.assertTrue(b.negative_control_failed_as_expected, b.block)

    def test_alu_hook_restores_reference_model(self):
        from sfsdk import _ref  # noqa: F401
        from sfg1 import alu
        before = dict(alu.BY_CODE)
        with rtl_replay.alu_operation_log() as log:
            alu.BY_CODE[0](3, 4)
        self.assertEqual(log, {(0, 3, 4, 7)})
        self.assertEqual(alu.BY_CODE, before)


if __name__ == "__main__":
    unittest.main()
