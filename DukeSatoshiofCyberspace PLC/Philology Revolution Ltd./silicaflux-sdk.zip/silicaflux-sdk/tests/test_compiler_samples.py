"""The sample kernels (``kernels/*.sfir``) compiled and run on the reference simulator, compared with an
independent host computation, on every configuration and on awkward geometries."""
from __future__ import annotations

import random
import unittest
from pathlib import Path

from sfsdk.compiler import compile_ir
from sfsdk.spec import Config
from tests.compiler_harness import RequirementFailed, open_local, ref_config, run_reference, Buffers, arg_names, \
    shared_bytes_for, check_requires

ROOT = Path(__file__).resolve().parents[1]
KDIR = ROOT / "kernels"
M32 = 0xFFFFFFFF
CONFIGS = ("default", "small", "wide")


def s32(x):
    x &= M32
    return x - (1 << 32) if x & 0x80000000 else x


def compile_sample(name, cfg, max_regs=None):
    p = KDIR / f"{name}.sfir"
    return compile_ir(p.read_text(), str(p), cfg, max_regs=max_regs)


def pow2s(limit):
    out, w = [], 1
    while w <= limit:
        out.append(w)
        w *= 2
    return out


class SampleBase(unittest.TestCase):
    max_regs_variants = (None,)

    def configs(self):
        for c in CONFIGS:
            yield Config.named(c)


class VecAdd(SampleBase):
    def test_vecadd(self):
        rng = random.Random(11)
        runs = 0
        for cfg in self.configs():
            for mr in (None, 4):
                img = compile_sample("vecadd", cfg, mr).image()
                for n in (1, 5, 33, 70):
                    for wg in sorted({1, 3, cfg.lanes, cfg.lanes + 1, cfg.max_wg_threads}):
                        if wg > cfg.max_wg_threads:
                            continue
                        a = [rng.getrandbits(32) for _ in range(n)]
                        b = [rng.getrandbits(32) for _ in range(n)]
                        grid = (n + wg - 1) // wg
                        out, res, _ = run_reference(img, cfg, grid, wg, {"a": a, "b": b, "c": [0xCCCCCCCC] * (n + 8)},
                                                    ["a", "b", "c", n])
                        self.assertTrue(res.ok, (cfg.name, n, wg, res))
                        exp = [(x + y) & M32 for x, y in zip(a, b)] + [0xCCCCCCCC] * 8   # guard words untouched
                        self.assertEqual(out["c"], exp, (cfg.name, n, wg))
                        runs += 1
        self.assertGreater(runs, 40)


class Histograms(SampleBase):
    def _expected(self, data, bins):
        h = [0] * bins
        for v in data:
            h[v & (bins - 1)] += 1
        return h

    def test_histogram_global(self):
        rng = random.Random(21)
        for cfg in self.configs():
            img = compile_sample("histogram_global", cfg).image()
            for bins in (1, 4, 16):
                for n in (0, 1, 37, 200):
                    for grid, wg in ((1, 1), (3, 5), (2, cfg.lanes), (1, cfg.max_wg_threads)):
                        data = [rng.getrandbits(32) for _ in range(n)]
                        out, res, _ = run_reference(img, cfg, grid, wg, {"data": data, "hist": [0] * bins},
                                                    ["data", "hist", n, bins])
                        self.assertTrue(res.ok, (cfg.name, bins, n, grid, wg, res))
                        self.assertEqual(out["hist"], self._expected(data, bins), (cfg.name, bins, n, grid, wg))

    def test_histogram_global_requires_power_of_two(self):
        cfg = Config.named("default")
        img = compile_sample("histogram_global", cfg).image()
        with self.assertRaises(RequirementFailed):
            run_reference(img, cfg, 1, 4, {"data": [1, 2, 3], "hist": [0] * 6}, ["data", "hist", 3, 6])
        with self.assertRaises(RequirementFailed):          # bins == 0 must not slip through `(bins & (bins-1)) == 0`
            run_reference(img, cfg, 1, 4, {"data": [1, 2, 3], "hist": [0] * 4}, ["data", "hist", 3, 0])

    def test_histogram_private(self):
        rng = random.Random(22)
        for cfg in self.configs():
            for mr in (None, 5):
                img = compile_sample("histogram_private", cfg, mr).image()
                for bins in (1, 4, 16, 64):
                    for wg in pow2s(cfg.max_wg_threads):
                        if wg > 16:
                            continue
                        for n, chunk in ((1, 1), (37, 7), (100, 64), (64, 16)):
                            data = [rng.getrandbits(32) for _ in range(n)]
                            grid = (n + chunk - 1) // chunk
                            out, res, _ = run_reference(img, cfg, grid, wg, {"data": data, "hist": [0] * bins},
                                                        ["data", "hist", n, bins, chunk])
                            self.assertTrue(res.ok, (cfg.name, mr, bins, wg, n, chunk, res))
                            self.assertEqual(out["hist"], self._expected(data, bins), (cfg.name, bins, wg, n, chunk))

    def test_histogram_private_avoids_atomics_on_the_hot_path(self):
        """Exactly one atomadd instruction in the kernel, and it is in the publish loop (not the scan loop)."""
        cfg = Config.named("default")
        res = compile_sample("histogram_private", cfg)
        self.assertEqual(sum(1 for l in res.asm.splitlines() if l.strip().startswith("atomadd")), 1)


class Reductions(SampleBase):
    def test_reduce_sum(self):
        rng = random.Random(31)
        for cfg in self.configs():
            for mr in (None, 4):
                img = compile_sample("reduce_sum", cfg, mr).image()
                for wg in pow2s(cfg.max_wg_threads):
                    for n in (1, 5, 100, 257):
                        data = [rng.getrandbits(32) for _ in range(n)]
                        grid = (n + wg - 1) // wg
                        if grid > 300:
                            continue
                        out, res, _ = run_reference(img, cfg, grid, wg, {"data": data, "out": [12345]},
                                                    ["data", "out", n])
                        self.assertTrue(res.ok, (cfg.name, wg, n, res))
                        self.assertEqual(out["out"], [(12345 + sum(data)) & M32], (cfg.name, wg, n))

    def test_reduce_max_two_passes(self):
        rng = random.Random(32)
        for cfg in self.configs():
            for mr in (None, 4):
                p1 = compile_sample("reduce_max_pass1", cfg, mr).image()
                p2 = compile_sample("reduce_max_pass2", cfg, mr).image()
                for wg in pow2s(cfg.max_wg_threads):
                    for n in (1, 7, 100, 300):
                        data = [rng.getrandbits(32) for _ in range(n)]
                        if n > 5:
                            data[rng.randrange(n)] = 0x80000000           # INT_MIN and INT_MAX in the mix
                            data[rng.randrange(n)] = 0x7FFFFFFF
                        grid = (n + wg - 1) // wg
                        bufs = Buffers({"data": data, "partial": [0xAAAAAAAA] * grid, "out": [0xBBBBBBBB]})
                        host = open_local(ref_config(cfg))
                        dev = host.device
                        for name, words in bufs.data.items():
                            a = host.alloc(max(4 * len(words), 4))
                            host.write_words(a, words)
                            self.assertEqual(a, bufs.addr[name])
                        k1, k2 = host.load_kernel(p1.words), host.load_kernel(p2.words)
                        av1 = dict(zip(arg_names(p1), [bufs.addr["data"], bufs.addr["partial"], n]))
                        r1 = host.launch(k1, grid, wg, shared_bytes_for(p1, av1, grid, wg, cfg.lanes),
                                         [bufs.addr["data"], bufs.addr["partial"], n])
                        self.assertTrue(r1.ok, (cfg.name, wg, n, r1))
                        av2 = dict(zip(arg_names(p2), [bufs.addr["partial"], bufs.addr["out"], grid]))
                        r2 = host.launch(k2, 1, wg, shared_bytes_for(p2, av2, 1, wg, cfg.lanes),
                                         [bufs.addr["partial"], bufs.addr["out"], grid])
                        self.assertTrue(r2.ok, (cfg.name, wg, n, r2))
                        got = host.read_words(bufs.addr["out"], 1)[0]
                        self.assertEqual(s32(got), max(s32(x) for x in data), (cfg.name, wg, n))
                        parts = host.read_words(bufs.addr["partial"], grid)
                        for w in range(grid):
                            chunk = data[w * wg:(w + 1) * wg]
                            self.assertEqual(s32(parts[w]), max(s32(x) for x in chunk), (cfg.name, wg, n, w))


class MatMul(SampleBase):
    def _golden(self, A, B, M, N, K):
        return [sum(A[i * K + k] * B[k * N + j] for k in range(K)) & M32 for i in range(M) for j in range(N)]

    def _run(self, name, mr=None):
        rng = random.Random(41 if name == "matmul_naive" else 42)
        for cfg in self.configs():
            img = compile_sample(name, cfg, mr).image()
            for (M, N, K) in ((1, 1, 1), (3, 4, 2), (6, 7, 5), (2, 9, 3), (2, 3, 0), (4, 20, 6)):
                for wg in sorted({1, 3, cfg.lanes, cfg.max_wg_threads}):
                    if wg > cfg.max_wg_threads:
                        continue
                    A = [rng.getrandbits(32) for _ in range(M * K)]
                    B = [rng.getrandbits(32) for _ in range(K * N)]
                    out, res, _ = run_reference(img, cfg, M, wg, {"A": A, "B": B, "C": [0xCCCCCCCC] * (M * N + 4)},
                                                ["A", "B", "C", M, N, K])
                    self.assertTrue(res.ok, (name, cfg.name, M, N, K, wg, res))
                    self.assertEqual(out["C"], self._golden(A, B, M, N, K) + [0xCCCCCCCC] * 4, (name, cfg.name, M, N, K, wg))

    def test_matmul_naive(self):
        self._run("matmul_naive")
        self._run("matmul_naive", 4)

    def test_matmul_tiled(self):
        self._run("matmul_tiled")
        self._run("matmul_tiled", 4)

    def test_tiled_uses_shared_memory_for_a(self):
        cfg = Config.named("default")
        naive = compile_sample("matmul_naive", cfg).asm
        tiled = compile_sample("matmul_tiled", cfg).asm
        count = lambda t, m: sum(1 for l in t.splitlines() if l.strip().startswith(m))     # noqa: E731
        self.assertEqual(count(naive, "lds"), 0)
        self.assertGreater(count(tiled, "lds"), 0)
        self.assertEqual(count(tiled, "bar"), 1)


class Metadata(SampleBase):
    def test_every_sample_has_complete_metadata(self):
        cfg = Config.named("default")
        for p in sorted(KDIR.glob("*.sfir")):
            img = compile_ir(p.read_text(), str(p), cfg).image()
            self.assertTrue(img.meta.args, p.name)
            self.assertEqual(img.meta.name, p.stem)
            self.assertLessEqual(len(img.meta.args), 8)
            self.assertTrue(img.lines, "pc -> IR line table missing")
            self.assertEqual(img.meta.info["instructions"], len(img.words))


if __name__ == "__main__":
    unittest.main()
