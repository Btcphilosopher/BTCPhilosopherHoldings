"""The hardware model must differ from the reference where the specification permits it; otherwise
"both agree" would prove nothing.  Also pins the transport-level contract the SDK runtime relies on
(clear_trace, per-launch counters)."""
import json
import unittest

import sfsdk._ref  # noqa: F401
from sfg1 import examples
from sfsdk.asm import assemble
from sfsdk.hwmodel import HwModelTransport, HwParams
from sfsdk.spec import Config, device_spec
from sfsdk.transport import ReferenceTransport
from tests.test_hwmodel_support import PARAM_SETS, digest, make_host, ref_config

R = device_spec().reg_offset
FC = device_spec().faults


def _launch(host, words, grid, wg, args=(), shared=0):
    return host.launch(host.load_kernel(words), grid=grid, wg=wg, shared=shared, args=list(args))


class TimingDiffers(unittest.TestCase):
    def test_cycles_differ_and_policies_change_timing_not_results(self):
        cfg = Config.named("default")
        cycles, digests = {}, set()
        for pname in ("default", "lrr", "gto", "slow_memory", "fast"):
            host, t = make_host("hwmodel", cfg, PARAM_SETS[pname])
            ex = examples.EXAMPLES["reduce_sum"](host, ref_config(cfg), True)
            self.assertTrue(ex.ok)
            cycles[pname] = ex.result.ticks
            digests.add(digest(t.commit_trace()))
        rhost, rt = make_host("reference", cfg)
        rex = examples.EXAMPLES["reduce_sum"](rhost, ref_config(cfg), True)
        self.assertEqual(len(digests), 1, "one architectural trace for every microarchitecture")
        self.assertGreater(len(set(cycles.values())), 3, f"policies/latencies must change timing: {cycles}")
        self.assertNotEqual(cycles["default"], rex.result.ticks, "PERF_CYCLES differs from the reference's ticks")
        self.assertGreater(cycles["slow_memory"], cycles["default"], "slower memory => more cycles")
        self.assertGreater(cycles["default"], cycles["fast"], "shorter latencies => fewer cycles")

    def test_reset_takes_a_different_number_of_cycles(self):
        cfg = Config.named("small")
        counts = {}
        for name, t in (("reference", ReferenceTransport(cfg)), ("hwmodel", HwModelTransport(cfg))):
            n = 0
            while not t.reg_read(R["STATUS"]) & 1:
                t.advance(1)
                n += 1
            counts[name] = n
        self.assertEqual(counts["reference"], cfg.reset_ticks)
        self.assertNotEqual(counts["hwmodel"], counts["reference"])


class PlacementAndInterleavingDiffer(unittest.TestCase):
    def test_workgroups_land_on_different_execution_groups(self):
        """docs/05 5.1: EG choice is policy.  Only FAULT_LOC shows it: workgroup 1 traps."""
        cfg = Config.named("default")
        src = assemble("rdsr r1, SR_WG_ID\naddi r1, r1, -1\nbnz r1, ok, ok\ntrap 1\nok: exit").words
        loc = {}
        for backend in ("reference", "hwmodel"):
            host, _ = make_host(backend, cfg)
            r = _launch(host, src, grid=2, wg=8)
            self.assertEqual(r.status, "fault")
            self.assertEqual(r.fault["WG"], 1)
            loc[backend] = r.fault["LOC"] & 0xFF
        self.assertEqual(loc["reference"], 0, "reference fills EG 0 first (it has two workgroup slots)")
        self.assertEqual(loc["hwmodel"], 1, "hardware model balances load: second workgroup goes to EG 1")

    def test_atomic_return_values_depend_on_interleaving_but_form_a_permutation(self):
        cfg = Config.named("default")
        src = assemble("rdsr r1, SR_GTID\nrdsr r2, SR_ARG0\naddi r3, r0, 1\natomadd r4, [r2], r3\nshli r5, r1, 2\n"
                       "rdsr r6, SR_ARG1\nadd r6, r6, r5\nstg r4, [r6]\nexit").words
        n, res = 4 * 16, {}
        for backend in ("reference", "hwmodel"):
            host, _ = make_host(backend, cfg)
            ctr, out = host.alloc(4), host.alloc(4 * n)
            host.write_words(ctr, [0])
            r = _launch(host, src, 4, 16, [ctr, out])
            self.assertTrue(r.ok)
            res[backend] = host.read_words(out, n)
            self.assertEqual(sorted(res[backend]), list(range(n)), f"{backend}: total order of atomics")
        self.assertNotEqual(res["reference"], res["hwmodel"], "different warp interleaving => different tickets")

    def test_uninitialised_memory_differs(self):
        cfg = Config.named("default")
        src = assemble("rdsr r1, SR_ARG0\nli r2, 0x8000\nldg r3, [r2]\nlds r4, [r0]\nstg r3, [r1]\nstg r4, [r1 + 4]\nexit").words
        got = {}
        for backend in ("reference", "hwmodel"):
            host, _ = make_host(backend, cfg)
            out = host.alloc(8)
            self.assertTrue(_launch(host, src, 1, 1, [out], shared=4).ok)
            got[backend] = host.read_words(out, 2)
        self.assertEqual(got["reference"], [0xDEADBEEF, 0xDEADBEEF], "reference poisons uninitialised memory")
        self.assertNotIn(0xDEADBEEF, got["hwmodel"], "the model's power-up contents are a different pattern")


class MicroarchitecturalCounters(unittest.TestCase):
    def _run(self, src, grid, wg, args_fn, shared=0, params=None):
        cfg = Config.named("default")
        host, t = make_host("hwmodel", cfg, params)
        args = args_fn(host)
        r = host.launch(host.load_kernel(assemble(src).words), grid=grid, wg=wg, shared=shared, args=args)
        self.assertTrue(r.ok, r)
        return t.counters(), r

    def test_coalescing_and_queue_depth(self):
        # unit-stride stores: 8 lanes x 4 B = one 32-byte segment per request
        src = "rdsr r1, SR_LANE_ID\nshli r2, r1, 2\nrdsr r3, SR_ARG0\nadd r3, r3, r2\nstg r1, [r3]\nstg r1, [r3 + 64]\nstg r1, [r3 + 128]\nexit"
        c, _ = self._run(src, 1, 8, lambda h: [h.alloc(4096)])
        self.assertEqual(c["global_requests"], 3)
        self.assertEqual(c["global_transactions"], 3)
        self.assertAlmostEqual(c["coalescing_ratio"], 8.0)
        self.assertGreaterEqual(c["max_mem_queue_depth"], 2, "stores are posted: several outstanding at once")
        # 128-byte stride: every lane its own segment
        src2 = "rdsr r1, SR_LANE_ID\nshli r2, r1, 7\nrdsr r3, SR_ARG0\nadd r3, r3, r2\nstg r1, [r3]\nexit"
        c2, _ = self._run(src2, 1, 8, lambda h: [h.alloc(4096)])
        self.assertEqual(c2["global_transactions"], 8)
        self.assertAlmostEqual(c2["coalescing_ratio"], 1.0)

    def test_shared_bank_conflicts(self):
        ok = "rdsr r1, SR_LANE_ID\nshli r2, r1, 2\nsts r1, [r2]\nexit"                       # 8 lanes -> 8 banks: no conflict
        bad = "rdsr r1, SR_LANE_ID\nshli r2, r1, 5\nsts r1, [r2]\nexit"                      # stride 8 words: all in bank 0
        c1, _ = self._run(ok, 1, 8, lambda h: [], shared=1024)
        c2, _ = self._run(bad, 1, 8, lambda h: [], shared=1024)
        self.assertEqual(c1["shared_bank_conflict_cycles"], 0)
        self.assertEqual(c2["shared_bank_conflict_cycles"], 7)

    def test_stall_breakdown_accounts_for_idle_issue_slots(self):
        cfg = Config.named("default")
        host, t = make_host("hwmodel", cfg)
        ex = examples.EXAMPLES["matmul_i32"](host, ref_config(cfg), True)
        self.assertTrue(ex.ok)
        c = t.counters()
        stalls = sum(c[k] for k in c if k.startswith("stall_"))
        self.assertEqual(stalls, c["issue_slots_idle"], "every idle issue slot is attributed to one reason")
        self.assertGreater(c["stall_memory"], 0)
        self.assertEqual(c["issued"], ex.result.issued)
        self.assertGreater(c["eg0_busy_cycles"], 0)


class TransportContract(unittest.TestCase):
    """What the SDK runtime relies on (parent's interface note)."""

    def test_trace_is_optional_and_clearable(self):
        cfg = Config.named("small")
        self.assertIsNone(HwModelTransport(cfg, trace=False).commit_trace())
        host, t = make_host("hwmodel", cfg)
        k = host.load_kernel(assemble("nop\nnop\nexit").words)
        self.assertTrue(host.launch(k, grid=1, wg=1).ok)
        first = t.commit_trace()
        self.assertEqual(len(first), 3)
        t.clear_trace()
        self.assertEqual(t.commit_trace(), [])
        self.assertTrue(host.launch(k, grid=1, wg=2).ok)
        self.assertEqual(len(t.commit_trace()), 3, "only the second launch's events (wg=2 fits one warp)")

    def test_counters_describe_the_most_recent_launch(self):
        cfg = Config.named("small")
        host, t = make_host("hwmodel", cfg)
        k1 = host.load_kernel(assemble("nop\nnop\nnop\nnop\nexit").words)
        k2 = host.load_kernel(assemble("exit").words)
        self.assertTrue(host.launch(k1, grid=1, wg=1).ok)
        c1 = t.counters()
        self.assertEqual(c1["issued"], 5)
        self.assertGreater(c1["cycles"], 0)
        self.assertEqual(c1["cycles"], host.t.reg_read(R["PERF_CYCLES"]), "counters['cycles'] mirrors PERF_CYCLES")
        self.assertTrue(host.launch(k2, grid=1, wg=1).ok)
        c2 = t.counters()
        self.assertEqual(c2["issued"], 1, "reset at every accepted doorbell, exactly like PERF_*")
        self.assertLess(c2["cycles"], c1["cycles"])
        # readable after a fault, plain ints (ratios are floats under *_ratio keys)
        k3 = host.load_kernel(assemble("nop\ntrap 1").words)
        host.reset()
        r = host.launch(k3, grid=1, wg=1)
        self.assertEqual(r.status, "fault")
        c3 = t.counters()
        self.assertEqual(c3["issued"], 1)
        for k, v in c3.items():
            self.assertTrue(isinstance(v, int) or k.endswith("_ratio"), f"{k}={v!r}")

    def test_trace_lines_are_canonical_json_in_wg_warp_seq_order(self):
        cfg = Config.named("default")
        host, t = make_host("hwmodel", cfg)
        ex = examples.EXAMPLES["vecadd"](host, ref_config(cfg), True)
        self.assertTrue(ex.ok)
        recs = [json.loads(l) for l in t.commit_trace()]
        self.assertEqual(list(recs[0].keys()), ["wg", "warp", "seq", "pc", "insn", "mask", "wb", "mem", "npc", "nmask", "depth"])
        keys = [(r["wg"], r["warp"], r["seq"]) for r in recs]
        self.assertEqual(keys, sorted(keys))
        for line in t.commit_trace():
            self.assertEqual(line, json.dumps(json.loads(line), separators=(",", ":")))


if __name__ == "__main__":
    unittest.main()
