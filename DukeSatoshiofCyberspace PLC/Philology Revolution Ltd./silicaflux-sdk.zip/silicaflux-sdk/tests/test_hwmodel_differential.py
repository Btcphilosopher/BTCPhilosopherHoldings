"""Randomised differential tests: hardware model vs reference simulator.

1. Race-free structured programs (the vendored reference generator: nested if/else, per-thread
   loops, breaks, early exits, loads, stores) -> memory, counters and the per-warp commit trace
   must be identical, whatever the scheduler / memory parameters.
2. "Fault soup": arbitrary (mostly forward-only) instruction streams on a single warp -> the
   outcome class, every FAULT_* register, PERF_ISSUED/PERF_LANE_OPS and the commit trace up to
   the fault must be identical (memory after a fault is unspecified and is not compared).
"""
import random
import unittest

import sfsdk._ref  # noqa: F401
from sfsdk.asm import assemble
from sfsdk.isa import ISA, encode
from sfsdk.spec import Config, device_spec
from tests.test_hwmodel_support import PARAM_SETS, digest, load_vendored, make_host

DG = load_vendored("test_differential.py", "_vendored_differential")
D = device_spec()
R = D.reg_offset


class StructuredPrograms(unittest.TestCase):
    def _run(self, cfgname, seed, pname):
        cfg = Config.named(cfgname)
        rng = random.Random(seed)
        src = DG.build_program(rng, max_depth=rng.choice([1, 2, 3]), max_stmts=rng.choice([2, 3, 4]))
        words = assemble(src, f"<seed {seed}>").words
        wg = rng.randint(1, min(cfg.max_wg_threads, 3 * cfg.lanes))
        grid = rng.randint(1, 3)
        n = wg * grid
        in_vals = [rng.randrange(1 << 32) for _ in range(DG.IN_WORDS)]
        res = {}
        for backend in ("reference", "hwmodel"):
            host, t = make_host(backend, cfg, PARAM_SETS[pname])
            out = host.alloc(4 * DG.OUT_WORDS * n)
            inp = host.alloc(4 * DG.IN_WORDS)
            host.write_words(inp, in_vals)
            host.write_words(out, [0x55555555] * (DG.OUT_WORDS * n))
            k = host.load_kernel(words)
            r = host.launch(k, grid=grid, wg=wg, args=[out, inp])
            self.assertTrue(r.ok, f"{backend} seed {seed} {cfgname}: {r.status} {r.error} {r.fault}\n{src}")
            res[backend] = (host.read_words(out, DG.OUT_WORDS * n), r.issued, r.lane_ops, t.commit_trace())
        self.assertEqual(res["hwmodel"][0], res["reference"][0], f"seed {seed} {cfgname}/{pname}: memory\n{src}")
        self.assertEqual(res["hwmodel"][1:3], res["reference"][1:3], f"seed {seed} {cfgname}/{pname}: counters")
        self.assertEqual(digest(res["hwmodel"][3]), digest(res["reference"][3]), f"seed {seed} {cfgname}/{pname}: trace")

    def test_default_config(self):
        names = list(PARAM_SETS)
        for seed in range(150):
            self._run("default", seed, names[seed % len(names)])

    def test_small_config(self):
        names = list(PARAM_SETS)
        for seed in range(3000, 3070):
            self._run("small", seed, names[seed % len(names)])

    def test_wide_config(self):
        names = list(PARAM_SETS)
        for seed in range(1000, 1040):
            self._run("wide", seed, names[seed % len(names)])


# ----------------------------------------------------------------------------- fault soup
_ALU_RR = ["add", "sub", "mul", "and", "or", "xor", "shl", "shr", "sar", "slt", "sltu"]
_ALU_RI = ["addi", "andi", "ori", "xori", "slti", "sltiu"]
_VALID_SR = sorted(ISA.special_registers.values())


def _soup(rng, n):
    """n arbitrary instruction words; every branch goes forward, so the program always terminates."""
    w = []
    for pc in range(n):
        k = rng.random()
        r = lambda: rng.randrange(16)                                       # noqa: E731
        if k < 0.22:
            w.append(encode(rng.choice(_ALU_RR), rd=r(), rs1=r(), rs2=r()))
        elif k < 0.38:
            w.append(encode(rng.choice(_ALU_RI), rd=r(), rs1=r(), imm=rng.choice([0, 1, -1, 4, 64, rng.randint(-300, 300)])))
        elif k < 0.44:
            w.append(encode(rng.choice(["shli", "shri", "sari"]), rd=r(), rs1=r(), imm=rng.randrange(32)))
        elif k < 0.48:
            w.append(encode("lui", rd=r(), imm=rng.randrange(1 << 22)))
        elif k < 0.58:
            w.append(encode("rdsr", rd=r(), imm=rng.choice(_VALID_SR)))
        elif k < 0.70:
            m = rng.choice(["ldg", "stg", "lds", "sts"])
            off = rng.choice([0, 4, 8, 2, -4, 64, 256])
            if m in ("ldg", "lds"):
                w.append(encode(m, rd=r(), rs1=r(), imm=off))
            else:
                w.append(encode(m, rs2=r(), rs1=r(), imm=off))
        elif k < 0.74:
            rd, rs2 = r(), r()
            while rd and rd == rs2:                  # reference trace quirk, see AtomicTraceQuirk below
                rs2 = r()
            w.append(encode("atomadd", rd=rd, rs1=r(), rs2=rs2))
        elif k < 0.88 and pc + 3 < n:
            t = rng.randint(1, min(8, n - 1 - pc))
            rc = max(1, t + rng.choice([0, 0, 1, 2, -1]))
            w.append(encode(rng.choice(["bz", "bnz"]), rs1=r(), imm=t, imm2=rc))
        elif k < 0.91 and pc + 2 < n:
            w.append(encode("bra", imm=rng.randint(1, min(6, n - 1 - pc))))
        elif k < 0.935:
            w.append(encode(rng.choice(["nop", "fence", "bar"])))
        elif k < 0.945:
            w.append(encode("trap", imm=rng.randrange(1 << 16)))
        elif k < 0.955:
            w.append(rng.getrandbits(32))                                    # raw word: mostly illegal
        else:
            w.append(encode("exit"))
    w.append(encode("exit"))
    return w


def _run_soup(backend, cfg, words, wg, params, seed):
    host, t = make_host(backend, cfg, params)
    t.mem_write(0, bytes(cfg.gmem_bytes))                                    # fully defined memory
    base = 0x100
    prologue = assemble("\n".join([
        "rdsr r1, SR_LANE_ID", "addi r2, r1, 3", "li r9, 0x4000", "addi r10, r9, 8", "li r11, 12", "li r12, 0x7FFFFFF0",
        "mul r13, r1, r2", "sub r14, r0, r2", "li r15, 0xFFFFFFFC"])).words
    code = prologue + words
    k = host.load_kernel(code)
    r = host.launch(k, grid=1, wg=wg, shared=64, flags=1, args=[1, 2, 3, 4, 5, 6, 7, 8], max_ticks=3_000_000)
    mem = t.mem_read(0, cfg.gmem_bytes) if r.ok else None
    return r, t.commit_trace(), mem


class FaultSoup(unittest.TestCase):
    def _campaign(self, cfgname, seeds, pname):
        cfg = Config.named(cfgname)
        kinds = {}
        for seed in seeds:
            rng = random.Random(seed)
            words = _soup(rng, rng.randint(6, 40))
            wg = rng.randint(1, cfg.lanes)                                    # one warp: schedule-independent
            a, ta, ma = _run_soup("reference", cfg, words, wg, None, seed)
            b, tb, mb = _run_soup("hwmodel", cfg, words, wg, PARAM_SETS[pname], seed)
            tag = f"seed {seed} {cfgname}/{pname} wg={wg}"
            self.assertEqual((b.status, b.error), (a.status, a.error), f"{tag}: outcome")
            self.assertEqual((b.issued, b.lane_ops), (a.issued, a.lane_ops), f"{tag}: counters")
            self.assertEqual(b.fault, a.fault, f"{tag}: FAULT_* registers")
            self.assertEqual(digest(tb), digest(ta), f"{tag}: commit trace up to the fault")
            if a.ok:
                self.assertEqual(mb, ma, f"{tag}: final memory")
            kinds[a.error or "done"] = kinds.get(a.error or "done", 0) + 1
        return kinds

    def test_default(self):
        kinds = self._campaign("default", range(400), "default")
        self.assertGreaterEqual(len(kinds), 6, f"campaign must hit many outcomes, hit {kinds}")
        self.assertGreater(kinds.get("done", 0), 20)

    def test_small_with_slow_memory_and_gto(self):
        kinds = self._campaign("small", range(5000, 5200), "slow_memory")
        self.assertGreaterEqual(len(kinds), 5, kinds)
        self._campaign("small", range(6000, 6100), "gto")

    def test_wide(self):
        self._campaign("wide", range(7000, 7100), "lrr")


class AtomicTraceQuirk(unittest.TestCase):
    """Reference/spec discrepancy (documented in docs/HWMODEL.md).

    For ``atomadd rX, [rA], rX`` (destination == addend register) the reference simulator's commit-trace
    ``mem`` record shows the *returned old value* as the addend, because its trace is built after the
    destination row (which aliases the addend row) was overwritten.  Memory contents are correct in
    both; docs/09 9.4 defines the third element as the stored/added operand, which is what the hardware
    model records.  This test pins both behaviours so the difference stays visible.
    """

    SRC = "li r11, 12\nli r4, 0x2000\natomadd r11, [r4], r11\nexit"

    def test_quirk_is_visible_and_memory_agrees(self):
        cfg = Config.named("default")
        res = {}
        for backend in ("reference", "hwmodel"):
            host, t = make_host(backend, cfg)
            host.write_words(0x2000, [100])
            k = host.load_kernel(assemble(self.SRC).words)
            r = host.launch(k, grid=1, wg=4)
            self.assertTrue(r.ok)
            mem = [__import__("json").loads(l)["mem"] for l in t.commit_trace() if '"atomadd"' in l][0]
            res[backend] = (mem, host.read_words(0x2000, 1)[0])
        self.assertEqual(res["hwmodel"][1], res["reference"][1], "memory effect is identical")
        self.assertEqual(res["hwmodel"][1], 100 + 4 * 12)
        self.assertEqual([x[2] for x in res["hwmodel"][0][1]], [12, 12, 12, 12], "hwmodel: the addend actually used")
        self.assertEqual([x[2] for x in res["reference"][0][1]], [100, 112, 124, 136],
                         "reference: old values (post-write register contents) -- discrepancy")


if __name__ == "__main__":
    unittest.main()
