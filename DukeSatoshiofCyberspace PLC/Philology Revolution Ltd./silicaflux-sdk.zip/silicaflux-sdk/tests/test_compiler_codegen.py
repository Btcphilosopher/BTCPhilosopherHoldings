"""Code generation: operation lowering (exhaustive on corner values), reconvergence shapes, uniformity analysis,
register allocation and spilling."""
from __future__ import annotations

import re
import unittest
from unittest import mock

from sfsdk.compiler import compile_ir, ir, parse_ir, uniform, regalloc, lir
from sfsdk.compiler import semantics
from sfsdk.compiler.lir import Ins
from sfsdk.errors import CompileError
from sfsdk.spec import Config
from tests.compiler_harness import run_reference, run_interp, shared_bytes_for, arg_names, Buffers, \
    eval_user_shared, RequirementFailed

M32 = 0xFFFFFFFF
VALS = [0, 1, 2, 31, 32, 33, 0x1FFFF, 0x20000, 0x7FFFFFFF, 0x80000000, 0xFFFE0000, 0xFFFFFFFF, 0x12345678, 5, 0x3FF, 0x400]
CONSTS = [0, 1, 4, 31, 32, 0x1FFFF, 0x20000, 0xFFFE0000, 0xFFFE0001, 0x7FFFFFFF, 0x80000000, 0xFFFFFFFF, 0x12345678,
          0x400, 0xFFFFF000]
BIN = ["add", "sub", "mul", "and", "or", "xor", "shl", "shr", "sar", "lt", "ltu", "le", "leu", "gt", "gtu", "ge",
       "geu", "eq", "ne", "lea"]
UN = ["not", "neg", "lnot", "bool", "mov"]


def s32(x):
    x &= M32
    return x - (1 << 32) if x & 0x80000000 else x


def lines_of(res):
    return [l.split(";")[0].strip() for l in res.asm.splitlines() if l.startswith("    ")]


def branches(res):
    """(mnemonic, target label, reconv label) for every bz/bnz in the generated assembly."""
    out = []
    for l in lines_of(res):
        m = re.match(r"(bz|bnz) r\d+, (\w+), (\w+)$", l)
        if m:
            out.append(m.groups())
    return out


class Lowering(unittest.TestCase):
    """Every value operation, with register/literal operand combinations around the immediate-range boundaries,
    run on the reference simulator and compared with the IR's value semantics."""

    def _kernel(self, exprs):
        body = ["    i = gtid", "    ok = ltu i, n", "    if ok {", "        o2 = shl i, 1", "        pa = lea inp, o2",
                "        x = ld.g [pa]", "        y = ld.g [pa + 4]", f"        row = mul i, {len(exprs)}",
                "        po = lea out, row"]
        for k, e in enumerate(exprs):
            body += [f"        r{k} = {e}", f"        st.g [po + {4 * k}], r{k}"]
        body.append("    }")
        return ("kernel t(ptr inp r (2 * n), ptr out w (n * %d), u32 n)\n{\n" % len(exprs)) + "\n".join(body) + "\n}\n"

    def _run(self, exprs, cfg, max_regs=None):
        src = self._kernel(exprs)
        res = compile_ir(src, "t.sfir", cfg, max_regs=max_regs)
        pairs = [(a, b) for a in VALS for b in VALS]
        inp = [w for p in pairs for w in p]
        n = len(pairs)
        wg = cfg.max_wg_threads
        out, run, _ = run_reference(res.image(), cfg, (n + wg - 1) // wg, wg,
                                    {"inp": inp, "out": [0] * (n * len(exprs))}, ["inp", "out", n])
        self.assertTrue(run.ok, run)
        return pairs, out["out"]

    def _check(self, exprs, evalfns, cfg, max_regs=None):
        for chunk in range(0, len(exprs), 40):
            ex, ev = exprs[chunk:chunk + 40], evalfns[chunk:chunk + 40]
            pairs, got = self._run(ex, cfg, max_regs)
            for ti, (x, y) in enumerate(pairs):
                for k, f in enumerate(ev):
                    self.assertEqual(got[ti * len(ex) + k], f(x, y) & M32, (ex[k], hex(x), hex(y)))

    def _all_cases(self):
        exprs, fns = [], []
        for op in BIN:
            exprs.append(f"{op} x, y")
            fns.append(lambda x, y, op=op: semantics.evaluate(op, [x, y]))
            for c in CONSTS:
                lit = c if c < 0x80000000 else c - (1 << 32)
                exprs.append(f"{op} x, {lit}")
                fns.append(lambda x, y, op=op, c=c: semantics.evaluate(op, [x, c]))
                exprs.append(f"{op} {lit}, y")
                fns.append(lambda x, y, op=op, c=c: semantics.evaluate(op, [c, y]))
        for op in UN:
            exprs.append(f"{op} x")
            fns.append(lambda x, y, op=op: semantics.evaluate(op, [x]))
        for c in (0, 1, 0xFFFFFFFF):
            lit = c if c < 0x80000000 else c - (1 << 32)
            exprs += [f"select x, y, {lit}", f"select x, {lit}, y", f"select {lit}, x, y", f"select y, x, x"]
            fns += [lambda x, y, c=c: semantics.evaluate("select", [x, y, c]),
                    lambda x, y, c=c: semantics.evaluate("select", [x, c, y]),
                    lambda x, y, c=c: semantics.evaluate("select", [c, x, y]),
                    lambda x, y: semantics.evaluate("select", [y, x, x])]
        return exprs, fns

    def test_all_operations_default(self):
        ex, fn = self._all_cases()
        self.assertGreater(len(ex), 600)
        self._check(ex, fn, Config.named("default"))

    def test_all_operations_wide(self):
        ex, fn = self._all_cases()
        self._check(ex, fn, Config.named("wide"))

    def test_all_operations_with_spilling_registers(self):
        ex, fn = self._all_cases()
        self._check(ex[:200], fn[:200], Config.named("default"), max_regs=4)

    def test_literal_only_expressions_fold_without_changing_values(self):
        cfg = Config.named("default")
        for opt in (True, False):
            exprs = [f"{op} 7, -3" for op in BIN] + ["select 1, 5, 6", "not 0x12345678"]
            src = self._kernel(exprs)
            res = compile_ir(src, "t.sfir", cfg, opt=opt)
            out, run, _ = run_reference(res.image(), cfg, 1, 1, {"inp": [1, 2], "out": [0] * len(exprs)}, ["inp", "out", 1])
            self.assertTrue(run.ok)
            exp = [semantics.evaluate(op, [7, M32 - 2]) for op in BIN] + [5, 0xEDCBA987]
            self.assertEqual(out["out"], exp, opt)

    def test_instruction_selection_uses_immediates(self):
        def body(expr):
            r = compile_ir("kernel k(ptr o w 1, u32 n)\n{\n x = %s\n st.g [o], x\n}" % expr, "k.sfir")
            return [l for l in lines_of(r) if not l.startswith(("rdsr", "stg", "exit"))]
        self.assertEqual(body("add n, 100"), ["addi r1, r1, 100"])
        self.assertEqual(body("sub n, 100"), ["addi r1, r1, -100"])                 # sub x, c -> addi x, -c
        self.assertEqual(body("shl n, 3"), ["shli r1, r1, 3"])
        self.assertEqual(body("mul n, 8"), ["shli r1, r1, 3"])                      # power-of-two multiply
        self.assertEqual(body("and n, 0xFFFFFF00"), ["andi r1, r1, -256"])          # sign-extended immediate
        self.assertEqual(body("lt n, 5"), ["slti r1, r1, 5"])
        self.assertEqual(body("ltu n, 5"), ["sltiu r1, r1, 5"])
        self.assertEqual(body("add n, 0x12345678"), ["li r2, 0x12345678", "add r1, r1, r2"])   # does not fit imm18
        self.assertEqual(body("eq n, 0"), ["sltiu r1, r1, 1"])
        self.assertEqual(body("ne n, 0"), ["sltu r1, r0, r1"])

    def test_compare_branch_fusion(self):
        r = compile_ir('''kernel k(ptr o w 1, u32 n)
{
    c = eq gtid, n
    if c {
        st.g [o], 1
    }
    d = ne tid, n
    if d {
        st.g [o], 2
    }
}''', "k.sfir")
        ls = lines_of(r)
        self.assertEqual(sum(1 for l in ls if l.startswith("sltiu")), 0, ls)      # the 0/1 materialisation is gone
        self.assertEqual([b[0] for b in branches(r)], ["bnz", "bz"])             # eq flips bz->bnz, ne keeps it
        r2 = compile_ir(r.source, "k.sfir", opt=False)
        self.assertGreater(len(lines_of(r2)), len(ls))


# A loop that peels one lane off per iteration: `if tid == i { break }`.  Each iteration splits the running group, and
# because the `if` reconverges at the loop exit (docs/03 3.6) the lane that broke waits on the stack for the rest of
# the loop, so the stack grows by one entry per iteration: 8 lanes need depth 9 although the nesting depth is only 2.
PEEL = """kernel peel(ptr o w 8, u32 n)
{
    i = 0
    loop {
        d = geu i, 8
        break_if d
        c = eq tid, i
        if c {
            break
        }
        p = lea o, tid
        st.g [p], i
        i = add i, 1
    }
}"""


class Reconvergence(unittest.TestCase):
    cfg = Config.named("default")

    def test_if_without_else(self):
        r = compile_ir("kernel k(ptr o w 1, u32 n) {\nc = ltu tid, n\nif c {\nst.g [o], 1\n}\n}", "k.sfir")
        (op, tgt, rc), = branches(r)
        self.assertEqual((op, tgt), ("bz", rc))                  # docs/03: `bz c, Lend, Lend`

    def test_if_else_shape(self):
        r = compile_ir("kernel k(ptr o w 1, u32 n) {\nc = ltu tid, n\nif c {\nst.g [o], 1\n} else {\nst.g [o], 2\n}\n}",
                       "k.sfir")
        (op, tgt, rc), = branches(r)
        lab = r.program.labels
        self.assertLess(lab[tgt], lab[rc])                       # target = else label, reconv = end label
        ls = lines_of(r)
        self.assertEqual(sum(1 for l in ls if l.startswith("bra ")), 1)   # the then-arm jumps over the else-arm

    def test_loop_shape(self):
        r = compile_ir("kernel k(ptr o w 1, u32 n) {\ni = 0\nloop {\nd = geu i, n\nbreak_if d\ni = add i, 1\n}\n}", "k.sfir")
        (op, tgt, rc), = branches(r)
        self.assertEqual((op, tgt), ("bnz", rc))                 # break_if -> bnz c, Lexit, Lexit
        lab = r.program.labels
        back = [l for l in lines_of(r) if l.startswith("bra ")]
        self.assertEqual(len(back), 1)
        self.assertLess(lab[back[0].split()[1]], lab[tgt])       # backward jump to the loop top

    BREAK_SRC = '''kernel k(ptr o w 1, u32 n)
{
    i = 0
    loop {
        d = geu i, n
        break_if d
        c = and i, 1
        if c {
            e = eq i, 5
            if e {
                break
            }
        }
        f = and i, 2
        if f {
            st.g [o], i
        }
        i = add i, 1
    }
}'''

    def test_break_rule(self):
        """docs/03 3.6: ifs whose arms break out of the loop reconverge at the loop exit; others at their own end."""
        r = compile_ir(self.BREAK_SRC, "k.sfir")
        br = branches(r)
        exit_label = [t for (_, t, rc) in br if t == rc and r.program.labels[t] == max(r.program.labels[x] for x in r.program.labels if x.endswith("loopend"))][0]
        loopend = [n for n in r.program.labels if n.endswith("_loopend")][0]
        self.assertEqual(exit_label, loopend)
        # branches in source order: break_if, if c, if e, if f
        self.assertEqual(br[0], ("bnz", loopend, loopend))                       # the loop-exit test
        self.assertEqual(br[1][2], loopend)                                      # `if c` contains a break (nested)
        self.assertEqual(br[2][2], loopend)                                      # `if e` contains the break
        self.assertEqual(br[3][1], br[3][2])                                     # `if f`: no break -> own end
        self.assertNotEqual(br[3][2], loopend)

    def test_break_rule_executes_correctly(self):
        cfg = self.cfg
        res = compile_ir(self.BREAK_SRC, "k.sfir", cfg)
        kernel = parse_ir(self.BREAK_SRC).kernel()
        for n in (0, 3, 6, 9):
            bufs = {"o": [0xAAAAAAAA]}
            out, run, _ = run_reference(res.image(), cfg, 1, 8, bufs, ["o", n])
            self.assertTrue(run.ok, run)
            exp = run_interp(kernel, cfg, 1, 8, bufs, ["o", n], 0)
            self.assertEqual(out["o"], exp["o"], n)

    def test_inner_loop_break_does_not_change_outer_if(self):
        src = '''kernel k(ptr o w 1, u32 n)
{
    c = ltu tid, n
    if c {
        i = 0
        loop {
            d = geu i, 3
            break_if d
            i = add i, 1
        }
        st.g [o], i
    }
}'''
        r = compile_ir(src, "k.sfir")
        br = branches(r)
        outer = br[0]
        self.assertEqual(outer[1], outer[2])                     # the outer `if` still reconverges at its own end
        self.assertTrue(r.program.labels[outer[1]] > r.program.labels[br[1][1]])

    def test_return_needs_no_special_reconvergence(self):
        r = compile_ir('''kernel k(ptr o w 1, u32 n)
{
    c = ltu tid, n
    if c {
        return
    }
    st.g [o], 1
}''', "k.sfir")
        (op, tgt, rc), = branches(r)
        self.assertEqual(tgt, rc)
        self.assertEqual(sum(1 for l in lines_of(r) if l == "exit"), 2)

    def test_kernel_always_ends_with_exit_and_labels_stay_inside_the_image(self):
        r = compile_ir("kernel k(ptr o w 1, u32 n) {\nc = ltu tid, n\nif c {\nst.g [o], 1\n}\n}", "k.sfir")
        self.assertEqual(lines_of(r)[-1], "exit")
        self.assertLess(max(r.program.labels.values()), len(r.program.words))

    def test_branch_range_error(self):
        body = "\n".join("x = add x, 1" for _ in range(1100))
        src = "kernel k(ptr o w 1, u32 n) {\nx = 0\nc = ltu tid, n\nif c {\n%s\n}\nst.g [o], x\n}" % body
        with self.assertRaises(CompileError) as cm:
            compile_ir(src, "k.sfir", Config.named("wide"))        # fits wide's 2048-word IMEM, but not the 11-bit offset
        self.assertIn("E_BRANCH_RANGE", str(cm.exception))
        with self.assertRaises(CompileError) as cm:
            compile_ir(src, "k.sfir", Config.named("default"))     # larger than the 1024-word IMEM
        self.assertIn("holds 1024", str(cm.exception))

    def test_stack_depth_warning(self):
        src = '''kernel k(ptr o w 1, u32 n)
{
    a = ltu tid, n
    if a {
        b = and tid, 1
        if b {
            c = and tid, 2
            if c {
                st.g [o], 1
            }
        }
    }
}'''
        small = compile_ir(src, "k.sfir", Config.named("small"))
        self.assertTrue(any("SIMT stack" in w for w in small.warnings), small.warnings)
        self.assertEqual(small.info["est_stack_depth"], 7)
        self.assertTrue(small.info["stack_overflow_possible"])
        wide = compile_ir(src, "k.sfir", Config.named("wide"))
        self.assertFalse(any("SIMT stack" in w for w in wide.warnings))
        self.assertFalse(compile_ir(src, "k.sfir", Config.named("default")).info["stack_overflow_possible"])

    def test_peeling_loop_really_needs_more_than_the_nesting_estimate(self):
        """Measured on the reference simulator: the minimum stack depth for the peeling loop is lanes + 1, not 1 + 2D."""
        base = Config.named("default")                              # 8 lanes
        needed = None
        for depth in range(2, 16):
            probe = Config.from_params(dict(base.parameters(), simt_stack_depth=depth), name="probe")
            res = compile_ir(PEEL, "peel.sfir", probe)
            out, run, _ = run_reference(res.image(), probe, 1, 8, {"o": [0] * 8}, ["o", 0])
            if run.ok:
                needed = depth
                break
            self.assertEqual(run.error, "F_STACK_OVERFLOW")
        self.assertEqual(needed, 9)
        self.assertGreater(needed, 1 + 2 * 2)                       # the nesting formula would say 5
        # and the compiler therefore reports the architectural bound (15) as its worst case, warning below it
        info = compile_ir(PEEL, "peel.sfir", base).info
        self.assertEqual((info["est_stack_depth"], info["stack_overflow_possible"]), (15, False))
        small_depth = Config.from_params(dict(base.parameters(), simt_stack_depth=9), name="d9")
        self.assertTrue(compile_ir(PEEL, "peel.sfir", small_depth).info["stack_overflow_possible"])   # 9 < 15: warned

    def test_stack_warning_compares_against_the_architectural_bound(self):
        """Regression (found by fuzzing): the estimate can exceed 2*lanes-1 yet the configured depth can still be too
        small; the warning must fire whenever depth < min(estimate, 2*lanes-1)."""
        nest = ""
        for i in range(5):
            nest += f"c{i} = and tid, {1 << i}\nif c{i} {{\n"
        src = "kernel k(ptr o w 1, u32 n)\n{\n" + nest + "st.g [o], 1\n" + "}\n" * 5 + "}"
        small = compile_ir(src, "k.sfir", Config.named("small"))
        self.assertEqual(small.info["est_stack_depth"], 7)            # min(1 + 2*5, 2*4 - 1)
        self.assertTrue(small.warnings and "SIMT stack" in small.warnings[0])

    def test_divergent_escaping_if_has_a_data_dependent_stack_need(self):
        src = """kernel k(ptr o w 1, u32 n)
{
    i = 0
    loop {
        d = geu i, 4
        break_if d
        c = and tid, i
        if c {
            e = eq i, 2
            if e {
                break
            }
            st.g [o], i
        }
        i = add i, 1
    }
}"""
        r = compile_ir(src, "k.sfir", Config.named("small"))
        self.assertIn("data-dependent", r.info["stack_depth_basis"])
        self.assertEqual(r.info["est_stack_depth"], 7)
        self.assertTrue(r.info["stack_overflow_possible"])
        self.assertFalse(compile_ir(src, "k.sfir", Config.named("default")).info["stack_overflow_possible"])


class Uniformity(unittest.TestCase):
    def compile(self, body, params="u32 n"):
        return compile_ir("kernel k(%s)\n shared 4*wg_dim\n{\n%s\n}" % (params, body), "k.sfir")

    def rejected(self, body):
        with self.assertRaises(CompileError) as cm:
            self.compile(body)
        self.assertIn("barrier", str(cm.exception))

    def test_uniform_loop_with_barrier_is_accepted(self):
        self.compile("s = shr wg_dim, 1\nloop {\nd = eq s, 0\nbreak_if d\nbarrier\ns = shr s, 1\n}")

    def test_barrier_after_a_divergent_if_is_accepted(self):
        self.compile("c = ltu tid, 3\nif c {\nst.s [0], 1\n}\nbarrier")

    def test_barrier_under_nonuniform_if_is_rejected(self):
        self.rejected("c = ltu tid, 3\nif c {\nbarrier\n}")

    def test_barrier_under_uniform_if_is_accepted(self):
        self.compile("c = ltu wg_id, n\nif c {\nbarrier\n}")

    def test_barrier_in_loop_with_divergent_break_is_rejected(self):
        self.rejected("i = 0\nloop {\nd = geu i, tid\nbreak_if d\nbarrier\ni = add i, 1\n}")

    def test_break_under_divergent_if_makes_the_loop_divergent(self):
        self.rejected("i = 0\nloop {\nd = geu i, 4\nbreak_if d\nc = ltu tid, 2\nif c {\nbreak\n}\nbarrier\ni = add i, 1\n}")

    def test_loads_and_atomics_are_nonuniform(self):
        self.rejected("x = ld.g [n]\nif x {\nbarrier\n}")
        self.rejected("x = atomadd [n], 1\nif x {\nbarrier\n}")

    def test_assume_uniform_overrides(self):
        self.compile("x = ld.g [n]\nu = assume_uniform x\nif u {\nbarrier\n}")

    def test_variable_assigned_in_divergent_context_is_nonuniform(self):
        self.rejected("x = 0\nc = ltu tid, 2\nif c {\nx = 1\n}\nif x {\nbarrier\n}")

    def test_return_does_not_make_the_rest_divergent(self):
        self.compile("c = ltu tid, 2\nif c {\nreturn\n}\nbarrier\nbarrier")

    def test_flow_insensitivity_is_conservative(self):
        """Documented limitation: a variable that is *ever* assigned a non-uniform value is non-uniform everywhere,
        even if every use happens right after a uniform reassignment."""
        self.rejected("x = n\nbarrier\nx = tid\ny = x\nz = n\nx = z\nif x {\nbarrier\n}")

    def test_analysis_matters_on_hardware(self):
        """Without the check a divergent barrier faults precisely with F_BAR_DIVERGENT on the device."""
        cfg = Config.named("default")
        src = "kernel k(ptr o w 1)\n shared 4*wg_dim\n{\nc = ltu tid, 3\nif c {\nbarrier\n}\n}"
        with self.assertRaises(CompileError):
            compile_ir(src, "k.sfir", cfg)
        class NoCheck(uniform.UniformInfo):
            pass
        real = uniform.analyze

        def lenient(k):
            info = real(k)
            info.divergent_barriers = []
            return info
        with mock.patch("sfsdk.compiler.driver.uniform.analyze", lenient):
            res = compile_ir(src, "k.sfir", cfg)
        out, run, _ = run_reference(res.image(), cfg, 1, 8, {"o": [0]}, ["o"])
        self.assertEqual((run.status, run.error), ("fault", "F_BAR_DIVERGENT"))


# ----------------------------------------------------------------------------- register allocation
def L(op, dst=None, srcs=(), imm=None, tag=""):
    return Ins(op, dst, list(srcs), imm, tag=tag)


class RegisterAllocation(unittest.TestCase):
    V = lir.V0

    def chain(self, k, extra_uses=True):
        """k values defined up front, all alive until a final accumulation chain."""
        v = [self.V + i for i in range(k)]
        code = [L("li", r, imm=i + 1) for i, r in enumerate(v)]
        acc = self.V + k
        code.append(L("addi", acc, [v[0]], imm=0))
        for r in v[1:]:
            nxt = acc + 1000
            code.append(L("add", nxt, [acc, r]))
            acc = nxt
        code.append(L("stg", None, [0, acc], imm=0))
        code.append(L("exit"))
        return code

    def test_dead_registers_are_reused(self):
        code = [L("li", self.V, imm=5), L("addi", self.V + 1, [self.V], imm=1), L("addi", self.V + 2, [self.V + 1], imm=1),
                L("stg", None, [0, self.V + 2], imm=0), L("exit")]
        res = regalloc.allocate(code, 4)
        self.assertFalse(res.spill_mode)
        self.assertEqual(res.regs_used, {1})                      # value flows through one register: last use frees it
        self.assertEqual({i.dst for i in res.code if i.dst}, {1})

    def test_overlapping_live_ranges_get_distinct_registers(self):
        res = regalloc.allocate(self.chain(4), 15)
        self.assertFalse(res.spill_mode)
        defs = [i.dst for i in res.code[:4]]
        self.assertEqual(len(set(defs)), 4)

    def test_r0_and_reserved_registers(self):
        res = regalloc.allocate(self._multi_def_chain(20), 15)
        self.assertTrue(res.spill_mode)
        self.assertGreater(res.slots, 0)
        # Reserved registers (SB=r15, S1=r14, S2=r13) appear only in spill machinery: the prologue, reloads/stores, or as
        # the destination of a value that is spilled right after being computed (an `sts` follows immediately).
        for k, ins in enumerate(res.code):
            if ins.tag in ("spill", "remat"):
                continue
            for r in ([ins.dst] if ins.dst else []):
                if r in (regalloc.SB, regalloc.S1, regalloc.S2):
                    nxt = res.code[k + 1]
                    self.assertEqual((nxt.op, nxt.srcs[1]), ("sts", r), (k, ins.op, r))
        self.assertTrue(all(1 <= r <= 12 or r in (13, 14, 15) for r in res.regs_used))
        self.assertTrue(len({r for r in res.regs_used if r <= 12}) <= 12)
        self.assertNotIn(0, {i.dst for i in res.code if i.op not in ("stg", "exit") and i.dst is not None})
        self.assertTrue(res.regs_used >= {regalloc.SB, regalloc.S1, regalloc.S2})

    def test_no_spill_when_everything_fits(self):
        res = regalloc.allocate(self.chain(15), 15)
        self.assertFalse(res.spill_mode)
        self.assertEqual(res.spilled, 0)

    def test_spill_when_pressure_exceeds_registers(self):
        res = regalloc.allocate(self.chain(6), 4)
        self.assertTrue(res.spill_mode)
        self.assertGreater(res.spilled, 0)
        self.assertEqual(res.slots + res.remat_spilled, res.spilled)

    def test_remat_spill_needs_no_slots(self):
        """Single-definition `li`/`rdsr` values are rebuilt at their uses instead of being stored."""
        res = regalloc.allocate(self.chain(8), 4)
        self.assertGreater(res.remat_spilled, 0)
        self.assertEqual(res.slots, 0)
        self.assertEqual(res.spill_loads, 0)
        self.assertFalse(any(i.op in ("lds", "sts") for i in res.code))
        self.assertFalse(any(i.imm == "SR_SHARED_BYTES" for i in res.code))   # no prologue without slots

    def _multi_def_chain(self, k):
        """Like chain(), but every value has TWO definitions so it cannot be rematerialised."""
        v = [self.V + i for i in range(k)]
        code = []
        for i, r in enumerate(v):
            code += [L("li", r, imm=i), L("addi", r, [r], imm=1)]
        acc = self.V + k
        code.append(L("addi", acc, [v[0]], imm=0))
        for r in v[1:]:
            nxt = acc + 1000
            code.append(L("add", nxt, [acc, r]))
            acc = nxt
        code += [L("stg", None, [0, acc], imm=0), L("exit")]
        return code

    def test_slot_spills_emit_prologue_loads_and_stores(self):
        res = regalloc.allocate(self._multi_def_chain(8), 4)
        self.assertGreater(res.slots, 0)
        self.assertGreater(res.spill_loads, 0)
        self.assertGreater(res.spill_stores, 0)
        pro = res.code[:6]
        self.assertEqual([i.op for i in pro], ["rdsr", "rdsr", "sub", "shli", "rdsr", "sub"])
        self.assertEqual([i.imm for i in pro if i.op == "rdsr"], ["SR_WG_DIM", "SR_TID", "SR_SHARED_BYTES"])
        P = res.slots_padded
        self.assertEqual(P & (P - 1), 0)                          # padded to a power of two
        self.assertGreaterEqual(P, res.slots)
        self.assertEqual(pro[3].imm, 2 + P.bit_length() - 1)      # SB = SHARED_BYTES - ((wg_dim - tid) << (2 + log2 P))
        slot_imms = {i.imm for i in res.code if i.op in ("lds", "sts")}
        self.assertTrue(all(isinstance(x, int) and x % 4 == 0 and 0 <= x < 4 * P for x in slot_imms), slot_imms)

    def test_slots_are_shared_between_disjoint_intervals(self):
        a = self._multi_def_chain(7)
        # second group of values starts after the first has completely died
        off = 500
        b = []
        for ins in self._multi_def_chain(7):
            c = ins.copy()
            c.dst = c.dst + off if c.dst and c.dst >= lir.V0 else c.dst
            c.srcs = [s + off if s >= lir.V0 else s for s in c.srcs]
            b.append(c)
        res = regalloc.allocate(a[:-1] + b, 4)
        self.assertGreater(res.spilled, res.slots, (res.spilled, res.slots))      # reuse: fewer slots than spilled values

    def test_short_remat_temporaries_are_never_spilled(self):
        code = [L("li", self.V + i, imm=i + 1, tag="remat") for i in range(3)]
        code += [L("add", self.V + 10, [self.V, self.V + 1]), L("add", self.V + 11, [self.V + 10, self.V + 2]),
                 L("stg", None, [0, self.V + 11], imm=0), L("exit")]
        res = regalloc.allocate(code, 4)
        self.assertFalse(res.spill_mode)

    def test_impossible_allocation_is_a_clean_error(self):
        code = [L("li", self.V + i, imm=i, tag="remat") for i in range(5)]
        code += [L("add", self.V + 20, [self.V, self.V + 1])]
        code += [L("add", self.V + 21, [self.V + 2, self.V + 3]), L("add", self.V + 22, [self.V + 4, self.V + 21]),
                 L("stg", None, [self.V + 20, self.V + 22], imm=0), L("exit")]
        with self.assertRaises(CompileError):
            regalloc.allocate(code, 4)

    def test_liveness_across_loops(self):
        v = self.V
        code = [L("li", v, imm=0), L("li", v + 1, imm=10), Ins("label", target="top"),
                L("add", v, [v, v + 1]), Ins("bnz", None, [v], target="top", reconv="done"), Ins("label", target="done"),
                L("stg", None, [0, v], imm=0), L("exit")]
        blocks = regalloc.liveness(code)
        iv = regalloc.build_intervals(code, blocks)
        # v+1 is only read inside the loop but must stay alive for the whole loop (it is live around the back edge)
        self.assertGreaterEqual(iv[v + 1].end, 2 * 4 + 1)

    def test_dce_removes_dead_pure_defs_and_atomic_results(self):
        v = self.V
        code = [L("li", v, imm=1), L("li", v + 1, imm=2), L("add", v + 2, [v, v + 1]),
                L("li", v + 3, imm=9), Ins("atomadd", v + 4, [v + 3, v]), L("stg", None, [0, v], imm=0), L("exit")]
        out = regalloc.dce(code)
        ops = [i.op for i in out]
        self.assertNotIn("add", ops)                              # v+2 is unused
        at = [i for i in out if i.op == "atomadd"][0]
        self.assertEqual(at.dst, 0)                               # unused atomic result is dropped (rd = r0)
        self.assertEqual(sum(1 for i in out if i.op == "li"), 2)  # v+1 is dead too


class SpillingEndToEnd(unittest.TestCase):
    SRC = None

    @staticmethod
    def source(nvars=22, shared=True):
        lines = ["kernel pressure(ptr out w (n * 4), u32 n)"]
        if shared:
            lines.append("    shared 4*wg_dim")
        lines.append("{")
        lines += [f"    v{i} = add gtid, {1000 * (i + 1)}" for i in range(nvars)]
        lines += ["    acc = 0", "    i = 0", "    loop {", "        d = geu i, 3", "        break_if d"]
        for i in range(nvars):
            lines.append(f"        v{i} = add v{i}, v{(i + 1) % nvars}")
            lines.append("        acc = xor acc, v%d" % i)
        if shared:
            lines += ["        off = shl tid, 2", "        st.s [off], acc", "        barrier", "        nb = add tid, 1",
                      "        c = lt nb, wg_dim", "        nb = select c, nb, 0", "        no = shl nb, 2",
                      "        nbv = ld.s [no]", "        barrier", "        acc = add acc, nbv"]
        lines += ["        i = add i, 1", "    }", "    base = shl gtid, 3", "    q = add out, base",
                  "    st.g [q], acc"]
        lines += [f"    s{k} = add v{k % nvars}, v{(k + 5) % nvars}" for k in range(4)]
        lines += ["    t = add s0, s1", "    t = add t, s2", "    t = add t, s3", "    st.g [q + 4], t", "}"]
        return "\n".join(lines)

    def test_spills_and_matches_interpreter_with_user_shared_memory(self):
        src = self.source()
        kernel = parse_ir(src).kernel()
        for cname in ("default", "small", "wide"):
            cfg = Config.named(cname)
            res = compile_ir(src, "p.sfir", cfg)
            self.assertTrue(res.info["spilling"], res.info)
            self.assertGreater(res.info["spill_slots"], 0)
            self.assertIn(".shared_per_thread", res.asm)
            self.assertIn(".require", res.asm)
            img = res.image()
            for wg in sorted({1, 3, cfg.lanes, cfg.max_wg_threads}):
                if wg > cfg.max_wg_threads:
                    continue
                n = 2 * wg
                bufs = {"out": [0xAAAAAAAA] * (n * 4)}
                try:
                    out, run, _ = run_reference(img, cfg, 2, wg, bufs, ["out", n])
                except RequirementFailed:
                    continue
                self.assertTrue(run.ok, (cfg.name, wg, run))
                av = dict(zip(arg_names(img), Buffers(bufs).resolve(["out", n])))
                exp = run_interp(kernel, cfg, 2, wg, bufs, ["out", n], eval_user_shared(img, av, 2, wg, cfg.lanes))
                self.assertEqual(out["out"], exp["out"], (cfg.name, wg))

    def test_spill_area_does_not_overlap_user_shared_memory(self):
        """With the *user* size only (no spill area) the spill base falls inside user data or below zero: the launch
        must use shared = user + shared_per_thread * wg_dim, which the metadata provides."""
        cfg = Config.named("default")
        res = compile_ir(self.source(), "p.sfir", cfg)
        img = res.image()
        wg = 8
        bufs = {"out": [0] * (2 * wg * 4)}
        user_only = 4 * wg
        out, run, _ = run_reference(img, cfg, 2, wg, bufs, ["out", 2 * wg], shared=user_only)
        self.assertEqual(run.status, "fault")                       # SB < 0 -> F_SMEM_RANGE: precise, not silent
        self.assertEqual(run.error, "F_SMEM_RANGE")
        ok, run2, _ = run_reference(img, cfg, 2, wg, bufs, ["out", 2 * wg])
        self.assertTrue(run2.ok)

    def test_capacity_requirement_is_emitted_and_enforced(self):
        cfg = Config.named("wide")                                   # 128-thread workgroups, 4096 B/slot
        res = compile_ir(self.source(shared=False), "p.sfir", cfg)
        info = res.info
        self.assertEqual(info["spill_max_wg_dim"], cfg.wg_slot_smem_bytes // info["spill_bytes_per_thread"])
        req = [r for r in res.image().meta.requires if "spill" in r[1]]
        self.assertEqual(len(req), 1)
        if info["spill_max_wg_dim"] < cfg.max_wg_threads:
            self.assertTrue(any("limits workgroups" in w for w in res.warnings))
            with self.assertRaises(RequirementFailed):
                run_reference(res.image(), cfg, 1, cfg.max_wg_threads, {"out": [0] * 4 * cfg.max_wg_threads},
                              ["out", cfg.max_wg_threads])

    def test_unspillable_demand_is_an_error(self):
        # one thread needs more spill bytes than a whole workgroup slot has
        cfg = Config.named("small")
        with mock.patch.object(Config, "wg_slot_smem_bytes", new_callable=mock.PropertyMock, return_value=8):
            with self.assertRaises(CompileError):
                compile_ir(self.source(shared=False), "p.sfir", cfg)

    def test_spilled_values_survive_a_barrier_in_a_loop(self):
        # covered by test_spills_and_matches_interpreter_with_user_shared_memory (barriers inside the loop); also check
        # that the default (non-forced) allocation of the same kernel with few variables does not spill
        res = compile_ir(self.source(nvars=4), "p.sfir", Config.named("default"))
        self.assertFalse(res.info["spilling"])


class Diagnostics(unittest.TestCase):
    def test_kernel_selection(self):
        src = "kernel a(u32 n) {\nreturn\n}\nkernel b(u32 n) {\nreturn\n}\n"
        with self.assertRaises(CompileError):
            compile_ir(src)                                          # ambiguous without kernel=
        self.assertEqual(compile_ir(src, kernel="b").kernel.name, "b")
        with self.assertRaises(CompileError):
            compile_ir(src, kernel="zzz")

    def test_all_errors_reported_together(self):
        with self.assertRaises(CompileError) as cm:
            compile_ir("kernel k(u32 n) {\nx = add y, 1\nz = add w, 1\n}", "k.sfir")
        self.assertEqual(len(cm.exception.errors), 2)

    def test_max_regs_minimum(self):
        with self.assertRaises(CompileError):
            compile_ir("kernel k(u32 n) {\nreturn\n}", max_regs=3)

    def test_image_metadata(self):
        res = compile_ir("kernel k(ptr a r n, ptr b w (n * 2), u32 n)\n shared 4*n\n require n > 0 \"n>0\"\n{\nreturn\n}\n", "k.sfir")
        m = res.image().meta
        self.assertEqual([(a.name, a.kind, a.access, a.elems) for a in m.args],
                         [("a", "ptr", "r", "n"), ("b", "ptr", "w", "n * 2"), ("n", "u32", "", None)])
        self.assertEqual(m.shared, "4*n")
        self.assertEqual(m.requires, [("n > 0", "n>0")])
        img2 = type(res.image()).from_bytes(res.image().to_bytes())          # survives the .sfk container
        self.assertEqual(img2.words, res.image().words)
        self.assertEqual(img2.meta.args[1].elems, "n * 2")
        self.assertEqual(res.image().producer, "sfsdk.compiler")

    def test_line_table_maps_to_ir_lines(self):
        src = "kernel k(ptr o w 1, u32 n)\n{\n  x = add n, 1\n  st.g [o], x\n}\n"
        res = compile_ir(src, "k.sfir")
        img = res.image()
        self.assertEqual(img.source_name, "k.sfir")
        self.assertTrue({3, 4} <= set(img.lines.values()), img.lines)


if __name__ == "__main__":
    unittest.main()
