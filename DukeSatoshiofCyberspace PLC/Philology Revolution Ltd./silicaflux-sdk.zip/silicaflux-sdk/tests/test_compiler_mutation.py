"""Mutation sanity checks for the differential fuzzer: deliberately break the code generator in realistic ways
and require that the fuzz campaign notices.  If a mutant survives, the tests that are supposed to protect the
compiler are not sharp enough."""
from __future__ import annotations

import random
import unittest
from contextlib import contextmanager
from unittest import mock

from sfsdk.compiler import fuzz, lir, regalloc, driver
from sfsdk.errors import CompileError
from sfsdk.spec import Config
from tests.compiler_harness import diff_case


def detect(n=400, seed=2024, max_regs=None, cfg_name="default", prefer=None):
    """Run fuzz cases until one fails; return a description of the first detection (or None if the mutant survives)."""
    cfg = Config.named(cfg_name)
    rng = random.Random(seed)
    for i in range(n):
        case = fuzz.random_case(rng, max_wg=cfg.max_wg_threads, lanes=cfg.lanes)
        if prefer and not prefer(case):
            continue
        try:
            ok, msg, _ = diff_case(case, cfg, max_regs=max_regs)
        except CompileError as e:
            return f"compile error: {str(e).splitlines()[0][:100]}"
        except Exception as e:                                          # noqa: BLE001 - any crash is a detection
            return f"crash: {type(e).__name__}"
        if not ok:
            return msg[:120]
    return None


@contextmanager
def patched_lowering(post):
    """Post-process the LIR the lowerer produces (before DCE / allocation)."""
    orig = lir.Lowerer.run

    def run(self):
        code = orig(self)
        post(code)
        return code
    with mock.patch.object(lir.Lowerer, "run", run):
        yield


@contextmanager
def patched_allocation(post):
    """Post-process the allocated code (after register assignment and spill rewriting)."""
    orig = regalloc.allocate

    def alloc(code, max_regs=None):
        res = orig(code, max_regs)
        post(res)
        return res
    with mock.patch.object(regalloc, "allocate", alloc), mock.patch.object(driver.regalloc, "allocate", alloc):
        yield


class Mutants(unittest.TestCase):
    def survive(self, what, found):
        self.assertIsNotNone(found, f"mutant SURVIVED (not detected): {what}")
        print(f"\n[mutant killed] {what}: {found}")

    def test_break_rule_ignored(self):
        """if-arms that break reconverge at their own end instead of the loop exit."""
        with mock.patch.object(lir, "contains_direct_break", lambda stmts: False):
            self.survive("break rule ignored", detect(prefer=lambda c: "break" in c.text))

    def test_if_else_reconvergence_at_else_label(self):
        def post(code):
            for i in code:
                if i.op == "bz" and i.reconv != i.target:
                    i.reconv = i.target
        with patched_lowering(post):
            self.survive("reconv := else label", detect())

    def test_break_if_inverted(self):
        def post(code):
            for i in code:
                if i.op == "bnz" and i.target == i.reconv:
                    i.op = "bz"
        with patched_lowering(post):
            self.survive("break_if sense inverted", detect())

    def test_spill_store_dropped(self):
        def post(res):
            res.code = [i for i in res.code if not (i.op == "sts" and i.tag == "spill")]
        with patched_allocation(post):
            self.survive("spill stores dropped", detect(max_regs=6))

    def test_spill_slot_off_by_one(self):
        def post(res):
            for i in res.code:
                if i.op == "lds" and i.tag == "spill":
                    i.imm += 4
        with patched_allocation(post):
            self.survive("reload from wrong slot", detect(max_regs=5))

    def test_spill_prologue_forgets_per_thread_stride(self):
        orig = regalloc._prologue

        def bad(p):
            pro = orig(p)
            pro[3].imm = 2                                  # threads share slots: stride 4 bytes instead of 4*P
            return pro
        with mock.patch.object(regalloc, "_prologue", bad):
            self.survive("spill base ignores P", detect(max_regs=5))

    def test_registers_freed_too_early(self):
        orig = regalloc.build_intervals

        def short(code, blocks):
            iv = orig(code, blocks)
            for x in iv.values():
                if x.end - x.start >= 4:
                    x.end -= 2                               # live range shortened by one instruction
            return iv
        with mock.patch.object(regalloc, "build_intervals", short):
            self.survive("intervals shortened", detect())

    def test_loop_carried_value_not_extended(self):
        orig = regalloc.build_blocks

        def no_backedges(code):                               # the CFG forgets every backward edge before the dataflow runs
            blocks = orig(code)
            for bi, b in enumerate(blocks):
                b.succs = [s for s in b.succs if s > bi]
            return blocks
        with mock.patch.object(regalloc, "build_blocks", no_backedges):
            self.survive("liveness ignores back edges", detect())

    def test_le_lowered_as_lt(self):
        orig = lir.Lowerer.binop

        def bad(self, d, op, a, b):
            return orig(self, d, "lt" if op == "le" else op, a, b)
        with mock.patch.object(lir.Lowerer, "binop", bad):
            self.survive("le lowered as lt", detect())

    def test_sar_lowered_as_shr(self):
        orig = lir.Lowerer.binop

        def bad(self, d, op, a, b):
            return orig(self, d, "shr" if op == "sar" else op, a, b)
        with mock.patch.object(lir.Lowerer, "binop", bad):
            self.survive("sar lowered as shr", detect())

    def test_select_ignores_condition(self):
        def bad(self, d, c, a, b):
            self.emit("addi", d, [self.reg(a)], imm=0)
        with mock.patch.object(lir.Lowerer, "select", bad):
            self.survive("select always takes first value", detect())

    def test_wrong_argument_register(self):
        orig = lir.Lowerer.sr_of

        def bad(self, o):
            s = orig(self, o)
            if s.startswith("SR_ARG") and s != "SR_ARG7":
                return "SR_ARG" + str(int(s[6:]) + 1)
            return s
        with mock.patch.object(lir.Lowerer, "sr_of", bad):
            self.survive("argument index off by one", detect())

    def test_dce_removes_live_definitions(self):
        orig = regalloc.dce

        def bad(code):
            code = orig(code)
            out, dropped = [], False
            for i in code:
                if not dropped and i.op == "xor" and i.tag == "":
                    dropped = True
                    continue
                out.append(i)
            return out
        with mock.patch.object(driver.regalloc, "dce", bad):
            self.survive("a live xor deleted", detect())

    def test_atomic_result_register_clobbered(self):
        def post(code):
            for i in code:
                if i.op == "atomadd":
                    i.srcs = [i.srcs[0], 0]                   # adds zero instead of the value
        with patched_lowering(post):
            self.survive("atomadd operand lost", detect())

    def test_constant_folding_wrong(self):
        from sfsdk.compiler import semantics
        orig = semantics.BINARY["sub"]
        semantics.BINARY["sub"] = lambda a, b: (a + b) & 0xFFFFFFFF
        try:
            # fold and interpreter share semantics; the mutant must be caught through *compiled* (unfolded) code
            found = detect(prefer=lambda c: " sub " in c.text)
        finally:
            semantics.BINARY["sub"] = orig
        self.survive("IR semantics of sub corrupted", found)


if __name__ == "__main__":
    unittest.main()


class StackEstimateMutant(unittest.TestCase):
    def test_unsound_stack_estimate_is_caught(self):
        """The nesting formula 1 + 2*D under-counts loops in which a divergent `if` breaks (one more entry per
        iteration).  With the divergent-escape rule disabled, a configuration sized to the estimate overflows."""
        from sfsdk.compiler import uniform
        from tests.compiler_harness import run_reference
        from tests.test_compiler_codegen import PEEL
        real = uniform.analyze

        def old_analysis(k):
            info = real(k)
            info.divergent_escapes = 0
            return info
        base = Config.named("default")                          # 8 lanes: architectural bound 15
        with mock.patch.object(driver.uniform, "analyze", old_analysis):
            est = driver.compile_ir(PEEL, "peel.sfir", base).info
            self.assertFalse(est["stack_overflow_possible"])
            depth = max(2, 1 + 2 * 2)                           # what the old formula says is enough: D = 2 -> 5
            probe = Config.from_params(dict(base.parameters(), simt_stack_depth=depth), name="probe")
            res = driver.compile_ir(PEEL, "peel.sfir", probe)
            self.assertFalse(res.info["stack_overflow_possible"])   # the mutant stays silent ...
            out, run, _ = run_reference(res.image(), probe, 1, 8, {"o": [0] * 8}, ["o", 0])
        self.assertEqual((run.status, run.error), ("fault", "F_STACK_OVERFLOW"))    # ... and the device faults
        # with the real analysis the compiler warns for exactly this configuration
        res = driver.compile_ir(PEEL, "peel.sfir", probe)
        self.assertTrue(res.info["stack_overflow_possible"])
        print("\n[mutant killed] stack estimate ignores divergent breaks: F_STACK_OVERFLOW on the peeling loop")
