"""The hardware SIMT stack against the reference stack: random command streams (incl. overflow and
ill-formed layouts) and the streams real kernels produce."""
import random
import unittest

import sfsdk._ref  # noqa: F401  (puts the vendored reference package `sfg1` on sys.path)
from sfg1 import vectors
from sfg1.simt import SimtStack

from sfsdk.hwmodel.simt import HwSimtStack
from sfsdk.spec import Config
from tests.test_hwmodel_support import CONFIGS, ref_config


def _snap_ref(s):
    return (s.pc if s.entries else 0, s.active, s.live, s.depth, int(s.done), int(s.rpc_violation()))


def _snap_hw(h):
    return (h.top_pc, h.active, h.live, h.depth, int(h.done), int(h.rpc_violation()))


class StackEquivalence(unittest.TestCase):
    def test_random_and_kernel_streams(self):
        total = overflows = 0
        for cname in CONFIGS:
            cfg = Config.named(cname)
            rcfg = ref_config(cfg)
            rng = random.Random(2024)
            streams = [vectors.random_stream(rcfg, rng, rng.choice([8, 20, 40, 80])) for _ in range(1200)]
            streams += vectors.kernel_streams(rcfg)
            for s in streams:
                ref = SimtStack(rcfg.simt_stack_depth, rcfg.rpc_none)
                hw = HwSimtStack(cfg.simt_stack_depth, cfg.rpc_none)
                for kind, pc, rc, m in s:
                    if kind == 0:
                        ref.init(pc, m)
                        hw.start(pc, m)
                    elif kind == 1:
                        ref.seq()
                        hw.seq()
                    elif kind == 2:
                        ref.jump(pc)
                        hw.jump(pc)
                    elif kind == 3:
                        ro, ho = ref.branch(m, pc, rc), hw.would_overflow(m, pc, rc)
                        self.assertEqual(ro, ho, f"{cname}: overflow decision")
                        overflows += ro
                        if not ho:
                            hw.branch(m, pc, rc)
                    else:
                        ref.exit_()
                        hw.exit_()
                    self.assertEqual(_snap_hw(hw), _snap_ref(ref), f"{cname}: stack state after command kind {kind}")
                    total += 1
        self.assertGreater(total, 50000)
        self.assertGreater(overflows, 0, "streams must include overflow cases (small configuration)")

    def test_resolution_cost_is_reported(self):
        """The multi-cycle part: a divergent branch costs pushes, reaching a reconvergence point costs pops."""
        h = HwSimtStack(16, 1025)
        h.start(0, 0xFF)
        h.branch(0x0F, 5, 9)                    # divergence: top -> reconv entry + 2 paths
        self.assertEqual(h.last_cost, 2)
        self.assertEqual(h.depth, 3)
        h.jump(9)                               # taken path reaches R=9 -> popped
        self.assertEqual(h.last_cost, 1)


if __name__ == "__main__":
    unittest.main()
