"""Foundation layer: spec loader, ISA tables, expression evaluator, assembler, disassembler, kernel container.

The vendored reference implementation (sf-g1/sim/sfg1) is used strictly as an *oracle*: each SDK component is a
separate implementation of the same specification, and these tests require the two to agree.
"""
import glob
import hashlib
import random
import struct
import unittest
from pathlib import Path

from sfsdk import _ref  # noqa: F401  (puts sfg1 on sys.path)
from sfsdk import asm, disasm, expr, isa as sisa, spec
from sfsdk.binfmt import ArgSpec, KernelImage, KernelMeta
from sfsdk.errors import AsmError, SfError
from sfsdk.spec import SF_G1_DIR, ROOT

import sfg1.asm as rasm
import sfg1.isa as risa
import sfg1.spec as rspec

I = sisa.ISA


class SpecTests(unittest.TestCase):
    def test_cfg_hash_matches_reference_for_all_configs(self):
        for name in spec.config_names():
            self.assertEqual(spec.Config.named(name).cfg_hash(), rspec.Config.from_file(name).cfg_hash(), name)

    def test_known_hashes(self):
        self.assertEqual(spec.Config.named("default").cfg_hash(), 0x3B334A66)  # printed by the authoritative RTL flow

    def test_caps_and_derived_values_match_reference(self):
        for name in spec.config_names():
            a, b = spec.Config.named(name), rspec.Config.from_file(name)
            self.assertEqual(a.caps_regs(), b.caps_regs())
            self.assertEqual((a.max_wg_threads, a.wg_slot_smem_bytes, a.rpc_none), (b.max_wg_threads, b.wg_slot_smem_bytes, b.rpc_none))

    def test_from_caps_roundtrip(self):
        for name in spec.config_names():
            c = spec.Config.named(name)
            self.assertEqual(spec.Config.from_caps(c.caps_regs()).caps_regs(), c.caps_regs())

    def test_config_validation(self):
        bad = [{"lanes": 5}, {"warps_per_eg": 0}, {"num_eg": 99}, {"gmem_bytes": 5000}, {"smem_bytes_per_eg": 130, "wg_slots_per_eg": 2},
               {"wg_slots_per_eg": 8, "warps_per_eg": 2}, {"bogus": 1}]
        for p in bad:
            with self.assertRaises(spec.ConfigError, msg=str(p)):
                spec.Config.from_params(p)

    def test_device_spec_matches_reference(self):
        a, b = spec.device_spec(), rspec.device_spec()
        self.assertEqual(a.reg_offset, b.reg_offset)
        self.assertEqual(a.launch_errors, b.launch_errors)
        self.assertEqual(a.faults, b.faults)
        self.assertEqual(a.desc_words, b.desc_words)
        self.assertEqual((a.device_id, a.desc_magic, a.version_word), (b.device_id, b.desc_magic, b.version_word))


class IsaTests(unittest.TestCase):
    def test_table_has_35_instructions(self):
        self.assertEqual(len(I.by_mnemonic), 35)

    def test_decode_agrees_with_reference_decoder(self):
        rng = random.Random(2024)
        words = [rng.getrandbits(32) for _ in range(60000)]
        words += [(op << 26) | rng.getrandbits(26) for op in range(64) for _ in range(300)]
        for w in words:
            a, b = sisa.decode(w), risa.decode(w)
            self.assertEqual(a is None, bool(b.illegal), hex(w))
            if a is not None:
                self.assertEqual((a.mnemonic, a.rd, a.rs1, a.rs2, a.imm32, a.imm2), (b.mnemonic, b.rd, b.rs1, b.rs2, b.imm, b.imm2), hex(w))

    def test_encode_decode_roundtrip_every_instruction(self):
        rng = random.Random(5)
        for spec_ in I.by_mnemonic.values():
            for _ in range(200):
                kw = {}
                for name, fl in spec_.fmt.fields.items():
                    lo, hi = fl.limits
                    kw[name] = rng.choice([lo, hi, 0, rng.randint(lo, hi)])
                if "imm2_nonzero" in spec_.require and not kw.get("imm2"):
                    kw["imm2"] = 1
                if "valid_sr" in spec_.require:
                    kw["imm"] = rng.choice(sorted(I.sr_names))
                w = I.encode(spec_.mnemonic, **kw)
                d = sisa.decode(w)
                self.assertIsNotNone(d, (spec_.mnemonic, kw))
                self.assertEqual(d.mnemonic, spec_.mnemonic)
                for k, v in kw.items():
                    self.assertEqual(getattr(d, k), v)
                self.assertEqual(w, risa.encode(spec_.mnemonic, **kw))     # same word as the reference encoder

    def test_reserved_bits_and_branch_rules_are_illegal(self):
        self.assertIsNone(sisa.decode(I.encode("nop") | 1))
        self.assertIsNone(sisa.decode(I.encode("bz", rs1=1, imm=3, imm2=1) & ~0x7FF))
        self.assertIsNone(sisa.decode(I.encode("rdsr", rd=1, imm=9)))
        self.assertIsNone(sisa.decode(0xFFFFFFFF))

    def test_encode_rejects_out_of_range(self):
        for m, kw in [("addi", dict(rd=1, rs1=1, imm=1 << 17)), ("shli", dict(rd=1, rs1=1, imm=32)), ("add", dict(rd=16)),
                      ("bz", dict(rs1=1, imm=1024, imm2=1)), ("nop", dict(rd=1))]:
            with self.assertRaises(ValueError):
                I.encode(m, **kw)


class ExprTests(unittest.TestCase):
    def test_arithmetic_and_precedence(self):
        for text, want in [("1+2*3", 7), ("(1+2)*3", 9), ("1<<4|1", 17), ("7&3^1", 2), ("-7/2", -3), ("-7%3", -1), ("~0", -1),
                           ("0x10 + 0b11 + 1_000", 16 + 3 + 1000), ("%hi(0xdeadbeef)", 0xDEADBEEF >> 10), ("%lo(0xdeadbeef)", 0xDEADBEEF & 0x3FF)]:
            self.assertEqual(expr.evaluate(text, {}), want, text)

    def test_comparison_binds_looser_than_bitwise(self):
        self.assertEqual(expr.evaluate("(w & (w - 1)) == 0", {"w": 8}), 1)
        self.assertEqual(expr.evaluate("w & (w - 1) == 0", {"w": 6}), 0)          # == lower than &
        self.assertEqual(expr.evaluate("1 < 2 && 3 >= 3 || 0", {}), 1)
        self.assertEqual(expr.evaluate("!0 + !5", {}), 1)

    def test_errors(self):
        for bad in ["", "1+", "(1", "1 2", "foo", "1/0", "3 % 0", "1 << 99", "$", "%hi 3"]:
            with self.assertRaises(expr.ExprError, msg=bad):
                expr.evaluate(bad, {})

    def test_symbols_callable_and_dict(self):
        self.assertEqual(expr.evaluate("a*b", {"a": 3, "b": 4}), 12)
        self.assertEqual(expr.evaluate("a*b", lambda n: {"a": 2, "b": 5}.get(n)), 10)
        self.assertEqual(expr.free_symbols("4*n + wg_dim"), ["n", "wg_dim"])


def _rand_program(rng: random.Random, n: int) -> str:
    """Random *legal* assembly using every instruction form, numeric absolute branch operands and symbols."""
    lines = [".equ K, 7", ".equ BIG, 0x12345678", ".reg acc, r9"]
    names = sorted(I.by_mnemonic)
    for pc in range(n):
        if rng.random() < 0.1:
            lines.append(f"lab{pc}:")
        m = rng.choice(names + ["li", "mov", "neg", "not", "sgt", "sgtu", "j", "li"])
        r = lambda: rng.choice(["r%d" % rng.randint(0, 15), "zero", "acc"])
        if m == "li":
            v = rng.choice([0, 1, -1, 131071, -131072, 131072, 0x400, 0x12345678, "BIG", "K", -(1 << 31), 0xFFFFFFFF, rng.getrandbits(32), "lab0+1"])
            lines.append(f"li {r()}, {v}")
        elif m in ("mov", "neg", "not"):
            lines.append(f"{m} {r()}, {r()}")
        elif m in ("sgt", "sgtu"):
            lines.append(f"{m} {r()}, {r()}, {r()}")
        elif m == "j":
            lines.append(f"j {rng.randint(0, n)}")
        else:
            sp = I.by_mnemonic[m]
            ops = []
            for tok in sp.syntax:
                if tok in ("rd", "rs1", "rs2"):
                    ops.append(r())
                elif tok == "imm":
                    fl = sp.fmt.fields["imm"]
                    lo, hi = fl.limits
                    ops.append(str(rng.choice([lo, hi, 0, rng.randint(lo, hi), "K"] if m != "lui" else [0, hi, rng.randint(0, hi)])))
                elif tok == "sr":
                    ops.append(rng.choice(sorted(I.special_registers)))
                elif tok == "mem":
                    ops.append(f"[{r()} {rng.choice(['+', '-'])} {rng.randint(0, 5000)}]" if rng.random() < .7 else f"[{r()}]")
                elif tok == "memr":
                    ops.append(f"[{r()}]")
                elif tok == "target":
                    ops.append(str(max(0, pc + rng.randint(-50, 50))) if m == "bz" or m == "bnz" else str(rng.randint(0, n)))
                    tgt = int(ops[-1])
                elif tok == "reconv":
                    ops.append(str(pc + rng.randint(max(1, tgt - pc), tgt - pc + 20) if tgt - pc >= 1 else pc + rng.randint(1, 30)))
            lines.append(f"{m} {', '.join(ops)}")
    return "\n".join(lines) + "\n"


class AssemblerTests(unittest.TestCase):
    def test_example_kernels_identical_to_reference_assembler(self):
        for f in sorted(glob.glob(str(SF_G1_DIR / "examples/kernels/*.sfa"))):
            a, b = asm.assemble_file(f), rasm.assemble_file(f)
            self.assertEqual(a.words, b.words, f)
            self.assertEqual(a.labels, b.labels)
            self.assertEqual(a.lines, b.source_lines)
            self.assertEqual(a.listing, b.listing)
            self.assertEqual(a.warnings, b.warnings)

    def test_golden_kernel_hex_files(self):
        for k in ("vecadd", "reduce_sum", "matmul_i32", "diverge"):
            hexwords = [int(x, 16) for x in (SF_G1_DIR / "reference" / k / "kernel.hex").read_text().split()]
            self.assertEqual(asm.assemble_file(str(SF_G1_DIR / "examples/kernels" / f"{k}.sfa")).words, hexwords)

    def test_random_programs_match_reference(self):
        rng = random.Random(11)
        ok = 0
        for _ in range(150):
            src = _rand_program(rng, rng.randint(5, 60))
            try:
                ref = rasm.assemble(src).words
            except rasm.AsmError as e:
                with self.assertRaises(AsmError, msg=src + "\n" + str(e)):
                    asm.assemble(src)
                continue
            self.assertEqual(asm.assemble(src).words, ref, src)
            ok += 1
        self.assertGreater(ok, 60)               # the generator must mostly produce programs both accept

    def test_malformed_sources_rejected_like_reference(self):
        bad = ["frobnicate r1", "add r1, r2", "add r1, r2, r16", "addi r1, r1, 131072", "shli r1, r1, 32", "lui r1, 4194304",
               "bz r1, 5, 3", "bz r1, 5000, 5001", "bz r1, 2, 9999", "dup:\ndup:", "r1:", "add:", ".word", ".bogus 1", "li r1, 1 +",
               "li r1, 4294967296", "ldg r1, r2", "atomadd r1, [r2 + 4], r3", "stg r1, [r2 +]", "ldg r1, [r2 4]", "rdsr r1, 9",
               "j undefined_label", ".equ X", ".reg q, r99", "li r17, 1", "nop r1", ".word 99999999999", "SR_TID:"]
        for src in bad:
            try:
                rasm.assemble(src + "\n")
                ref_ok = True
            except Exception:
                ref_ok = False
            try:
                asm.assemble(src + "\n")
                my_ok = True
            except AsmError:
                my_ok = False
            self.assertEqual(my_ok, ref_ok, f"disagreement on {src!r}: reference accepts={ref_ok}")
            if not ref_ok:
                self.assertFalse(my_ok)

    def test_all_errors_are_collected_with_line_numbers(self):
        with self.assertRaises(AsmError) as cm:
            asm.assemble("nop\nbogus r1\nadd r1, r2\n  ldg r1, r2\n", "t.sfa")
        self.assertEqual(len(cm.exception.errors), 3)
        self.assertTrue(all(e.startswith("t.sfa:") for e in cm.exception.errors))
        self.assertIn("t.sfa:2:", cm.exception.errors[0])

    def test_forward_li_reserves_two_words(self):
        p = asm.assemble("li r1, end\nli r2, 5\nend: exit\n")
        self.assertEqual(len(p.words), 4)                         # forward li = 2 words (padded with nop), li 5 = 1
        self.assertEqual(p.labels["end"], 3)

    def test_branch_target_range_error_is_clear(self):
        src = "bz r1, far, far\n" + "nop\n" * 1100 + "far: exit\n"
        with self.assertRaises(AsmError) as cm:
            asm.assemble(src)
        self.assertIn("reaches", str(cm.exception))

    def test_warning_when_target_beyond_reconv(self):
        p = asm.assemble("bz r1, 5, 3\nnop\nnop\nnop\nnop\nexit\n")
        self.assertTrue(any("beyond its reconvergence" in w for w in p.warnings))

    def test_metadata_directives(self):
        src = """
        .kernel scale
        .arg ptr a r n
        .arg ptr out w n
        .arg u32 n
        .shared 4*wg_dim
        .shared_per_thread 8
        .require (wg_dim & (wg_dim-1)) == 0, "wg_dim must be a power of two; got ; odd"
        .equ ELEM, 4
        exit
        """
        p = asm.assemble(src, "x/scale.sfa")
        m = p.meta
        self.assertEqual((m.name, [a.name for a in m.args], [a.kind for a in m.args]), ("scale", ["a", "out", "n"], ["ptr", "ptr", "u32"]))
        self.assertEqual(m.args[0].elems, "n")
        self.assertEqual((m.shared, m.shared_per_thread), ("4*wg_dim", "8"))
        self.assertEqual(m.requires[0][1], "wg_dim must be a power of two; got ; odd")
        self.assertEqual(p.image().meta.equ, {"ELEM": 4})
        self.assertEqual(p.words, rasm.assemble("exit").words)    # directives never change the code

    def test_metadata_directive_errors(self):
        for bad in [".arg float x", ".arg u32 x r", ".arg ptr a q", ".arg u32 x\n.arg u32 x", ".kernel 9bad", ".require", ".shared 4*",
                    ".arg u32 wg_dim"]:
            with self.assertRaises(AsmError, msg=bad):
                asm.assemble(bad + "\nexit\n")
        with self.assertRaises(AsmError):
            asm.assemble("\n".join(f".arg u32 a{i}" for i in range(9)) + "\nexit\n")

    def test_source_plain_file_has_no_metadata(self):
        self.assertIsNone(asm.assemble("exit\n").meta)


class DisassemblerTests(unittest.TestCase):
    def test_roundtrip_random_legal_programs(self):
        rng = random.Random(3)
        done = 0
        for _ in range(120):
            try:
                words = asm.assemble(_rand_program(rng, rng.randint(4, 50))).words
            except AsmError:
                continue
            text = disasm.disassemble(words)
            self.assertEqual(asm.assemble(text).words, words, text)
            self.assertEqual(asm.assemble(disasm.disassemble(words, labels=False)).words, words)
            done += 1
        self.assertGreater(done, 40)

    def test_roundtrip_arbitrary_words_including_illegal(self):
        rng = random.Random(8)
        words = [rng.getrandbits(32) for _ in range(500)] + [0xFFFFFFFF, 0, 0x04000001]
        text = "\n".join(disasm.format_instr(w, pc) for pc, w in enumerate(words))
        # branch operands in raw words may be out of encodable range after re-assembly; compare only words without targets
        for pc, w in enumerate(words):
            d = sisa.decode(w)
            if d is not None and d.iclass in ("BRANCH", "JUMP"):
                continue
            self.assertEqual(asm.assemble(disasm.format_instr(w, pc)).words, [w], hex(w))

    def test_examples_and_labels(self):
        words = asm.assemble_file(str(SF_G1_DIR / "examples/kernels/diverge.sfa")).words
        text = disasm.disassemble(words)
        self.assertIn("bz r2, L", text)
        self.assertEqual(asm.assemble(text).words, words)
        named = disasm.disassemble(words, symbols=asm.assemble_file(str(SF_G1_DIR / "examples/kernels/diverge.sfa")).labels)
        self.assertIn("endif1:", named)
        self.assertEqual(asm.assemble(named).words, words)

    def test_illegal_word_becomes_dot_word(self):
        self.assertEqual(disasm.format_instr(0xFFFFFFFF, 0), ".word 0xffffffff")


class ContainerTests(unittest.TestCase):
    def _img(self):
        p = asm.assemble(".kernel k\n.arg ptr a r 4\n.arg u32 n\n.shared 16\nstart: exit\n", "k.sfa")
        return p.image()

    def test_roundtrip(self):
        img = self._img()
        back = KernelImage.from_bytes(img.to_bytes())
        self.assertEqual(back.words, img.words)
        self.assertEqual(back.meta.to_json(), img.meta.to_json())
        self.assertEqual(back.labels, {"start": 0})
        self.assertEqual(back.lines, img.lines)
        self.assertEqual(back.source_sha256, img.source_sha256)

    def test_corruption_is_detected(self):
        data = bytearray(self._img().to_bytes())
        for pos in (24, len(data) - 3):
            d = bytearray(data)
            d[pos] ^= 0x40
            with self.assertRaises(SfError):
                KernelImage.from_bytes(bytes(d))
        with self.assertRaises(SfError):
            KernelImage.from_bytes(b"XXXX" + bytes(data[4:]))
        with self.assertRaises(SfError):
            KernelImage.from_bytes(bytes(data[:-1]))
        wrong_isa = bytearray(data)
        wrong_isa[8:12] = struct.pack("<I", 0x1234)
        with self.assertRaises(SfError) as cm:
            KernelImage.from_bytes(bytes(wrong_isa))
        self.assertIn("different ISA", str(cm.exception))

    def test_sfbin(self):
        img = KernelImage.from_sfbin(self._img().to_sfbin(), "raw")
        self.assertFalse(img.has_meta)
        with self.assertRaises(SfError):
            KernelImage.from_sfbin(b"abc")

    def test_order_dependent_atomics_flag(self):
        a = asm.assemble("atomadd r0, [r1], r2\nexit\n").image()
        b = asm.assemble("atomadd r3, [r1], r2\nexit\n").image()
        self.assertFalse(a.uses_order_dependent_atomics)
        self.assertTrue(b.uses_order_dependent_atomics)


class ProvenanceTests(unittest.TestCase):
    def test_vendored_tree_is_unmodified(self):
        manifest = (ROOT / "sf-g1.MANIFEST.sha256").read_text().splitlines()
        listed = {}
        for line in manifest:
            digest, path = line.split("  ", 1)
            listed[path[2:]] = digest
        for rel, digest in listed.items():
            got = hashlib.sha256((SF_G1_DIR / rel).read_bytes()).hexdigest()
            self.assertEqual(got, digest, f"vendored file modified: {rel}")
        present = {str(p.relative_to(SF_G1_DIR)) for p in SF_G1_DIR.rglob("*") if p.is_file()
                   and "__pycache__" not in p.parts and "build" not in p.relative_to(SF_G1_DIR).parts[:1]}
        self.assertEqual(present - set(listed), set(), "files added to the vendored tree")
        self.assertEqual(set(listed) - present, set(), "files removed from the vendored tree")


if __name__ == "__main__":
    unittest.main()
