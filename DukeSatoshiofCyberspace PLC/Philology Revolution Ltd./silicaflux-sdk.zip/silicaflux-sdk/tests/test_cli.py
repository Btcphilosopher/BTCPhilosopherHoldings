"""Command-line tool: behaviour, output and exit codes."""
import io
import json
import os
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout

from sfsdk import cli
from sfsdk.spec import SF_G1_DIR

VECADD = str(SF_G1_DIR / "examples" / "kernels" / "vecadd.sfa")


def run(*argv):
    out, err = io.StringIO(), io.StringIO()
    with redirect_stdout(out), redirect_stderr(err):
        rc = cli.main(list(argv))
    return rc, out.getvalue(), err.getvalue()


class Cli(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()

    def p(self, name):
        return os.path.join(self.d, name)

    def test_devices(self):
        rc, out, _ = run("devices")
        self.assertEqual(rc, 0)
        self.assertIn("reference:default", out)
        rc, out, _ = run("devices", "--json")
        data = json.loads(out)
        self.assertEqual(data[0]["cfg_hash"], "0x3b334a66")

    def test_asm_dis_info_roundtrip(self):
        rc, out, _ = run("asm", VECADD, "-o", self.p("v.sfk"), "--sfbin", self.p("v.bin"), "--hex", self.p("v.hex"),
                         "--listing", self.p("v.lst"), "--symbols", self.p("v.json"))
        self.assertEqual(rc, 0)
        self.assertEqual(os.path.getsize(self.p("v.bin")), 4 * 16)
        with open(self.p("v.hex")) as f:
            self.assertEqual(len(f.read().split()), 16)
        with open(self.p("v.json")) as f:
            self.assertIn("done", json.load(f)["labels"])
        rc, out, _ = run("dis", self.p("v.sfk"), "--symbols", "--addresses")
        self.assertIn("done:", out)
        self.assertIn("rdsr r1, SR_GTID", out)
        rc, out, _ = run("info", self.p("v.sfk"))
        self.assertIn("vecadd", out)
        self.assertIn("16 instructions", out)
        rc, out, _ = run("info", self.p("v.bin"))
        self.assertIn("no launch metadata", out)

    def test_run_with_buffers_dump_and_profile(self):
        rc, out, err = run("run", VECADD, "--grid", "1", "--wg", "8", "--buf", "a=1,2,3,4,5,6,7,8", "--buf", "b=8x100", "--buf", "c=8x0",
                           "--arg", "@a", "--arg", "@b", "--arg", "@c", "--arg", "8", "--dump", "c", "--profile", "--instr-profile")
        self.assertEqual(rc, 0, err)
        self.assertIn("c = [101, 102, 103, 104, 105, 106, 107, 108]", out)
        self.assertIn("simt%", out)
        self.assertIn("instruction profile", out)
        rc, out, err = run("run", VECADD, "--grid", "1", "--wg", "4", "--buf", "a=1,2,3,4", "--buf", "b=4x1", "--buf", "c=4x0",
                           "--arg", "@a", "--arg", "@b", "--arg", "@c", "--arg", "4", "--dump", "c:2", "--device", "reference:small", "--wait-mode", "irq")
        self.assertEqual(rc, 0, err)
        self.assertIn("c = [2, 3]", out)

    def test_error_paths_have_nonzero_exit_and_messages(self):
        bad = self.p("bad.sfa")
        with open(bad, "w") as f:
            f.write("nop\nfrobnicate r1\nadd r1, r2\n")
        rc, out, err = run("asm", bad)
        self.assertEqual(rc, 1)
        self.assertEqual(len(err.strip().splitlines()), 2)
        self.assertIn("bad.sfa:2: error", err)
        rc, out, err = run("run", VECADD, "--grid", "0", "--wg", "8", "--arg", "1")
        self.assertEqual(rc, 1)
        self.assertIn("E_GEOMETRY", err)
        rc, out, err = run("run", VECADD, "--grid", "1", "--wg", "1", "--arg", "@nobuf")
        self.assertEqual(rc, 1)
        self.assertIn("no --buf named", err)
        with open(self.p("trap.sfa"), "w") as f:
            f.write("trap 7\n")
        rc, out, err = run("run", self.p("trap.sfa"), "--grid", "1", "--wg", "1")
        self.assertEqual(rc, 1)
        self.assertIn("F_TRAP", err)

    def test_conformance_command_passes_its_arguments_through(self):
        rc, out, err = run("conformance", "--backend", "reference", "--configs", "small")
        self.assertEqual(rc, 0, out + err)
        self.assertRegex(out, r"\[reference\] \d+/\d+ checks passed")

    def test_parse_buf(self):
        self.assertEqual(cli._parse_buf("1,2,0x10,-1"), [1, 2, 16, -1])
        self.assertEqual(cli._parse_buf("3x7"), [7, 7, 7])
        self.assertEqual(cli._parse_buf("0x10"), [16])

    def test_unknown_command_is_a_usage_error(self):
        with self.assertRaises(SystemExit):
            with redirect_stderr(io.StringIO()):
                cli.main(["nosuchcommand"])


if __name__ == "__main__":
    unittest.main()
