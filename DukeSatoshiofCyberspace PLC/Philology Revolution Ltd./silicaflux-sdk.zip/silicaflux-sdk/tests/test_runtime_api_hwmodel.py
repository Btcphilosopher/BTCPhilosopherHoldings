"""The runtime API suite, unchanged, against the hardware-model backend.

If the hardware model implements the specification, everything the SDK promises (zero-filled allocation, argument validation,
decoded faults with the right registers, queue semantics, interrupt completion, guard canaries, profiling) holds on it exactly
as on the reference simulator."""
import unittest

import tests.test_runtime_api as base

try:
    from sfsdk.hwmodel import HwModelTransport  # noqa: F401
    HAVE = True
except Exception:                                  # pragma: no cover
    HAVE = False


def _make(cls):
    class Hw(cls):
        @classmethod
        def setUpClass(c):
            base.BACKEND = "hwmodel"

        @classmethod
        def tearDownClass(c):
            base.BACKEND = "reference"
    Hw.__name__ = Hw.__qualname__ = "Hw" + cls.__name__
    return unittest.skipUnless(HAVE, "hardware model not available")(Hw)


for _n in ("Enumeration", "Memory", "KernelLoading", "ArgumentValidation", "Dispatch", "FaultReporting", "Profiling", "BringUp"):
    globals()["Hw" + _n] = _make(getattr(base, _n))
del _n

if __name__ == "__main__":
    unittest.main()
