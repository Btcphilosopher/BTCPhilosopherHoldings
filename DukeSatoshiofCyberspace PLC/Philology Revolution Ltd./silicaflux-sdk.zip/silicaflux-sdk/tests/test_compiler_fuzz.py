"""Differential fuzzing: random structured programs -> compile -> reference simulator, compared with the IR
interpreter on *all* of memory.  ``SFSDK_FUZZ_N`` (default 25) sets the number of programs per (config, max_regs) cell."""
from __future__ import annotations

import hashlib
import os
import random
import subprocess
import sys
import unittest

from sfsdk.compiler import fuzz, ir, parse_ir
from sfsdk.spec import Config
from sfsdk.compiler import compile_ir
from tests.compiler_harness import RequirementFailed, diff_case

N = int(os.environ.get("SFSDK_FUZZ_N", "25"))
CONFIGS = ("default", "small", "wide")
MAX_REGS = (None, 6, 5)


def compile_ir_safe(text, cfg):
    return compile_ir(text, "fuzz.sfir", cfg)


def cases(cfg, n, seed):
    rng = random.Random(seed)
    return [fuzz.random_case(rng, max_wg=cfg.max_wg_threads, lanes=cfg.lanes) for _ in range(n)]


def features(case, res):
    st = list(ir.walk(res.kernel.body))
    ifs = [s for s in st if isinstance(s, ir.If)]
    return {
        "spilling": res.info["spilling"],
        "loops": any(isinstance(s, ir.Loop) for s in st),
        "barriers": any(isinstance(s, ir.Barrier) for s in st),
        "escaping_break_if": any(ir.contains_direct_break(s.then) or ir.contains_direct_break(s.els) for s in ifs),
        "returns": any(isinstance(s, ir.Return) for s in st),
        "atomics": any(isinstance(s, ir.AtomAdd) for s in st),
        "selects": any(isinstance(s, ir.Assign) and s.op == "select" for s in st),
    }


class DifferentialFuzz(unittest.TestCase):
    totals = {}
    programs = 0

    def test_compiled_code_matches_the_interpreter(self):
        agg = {k: 0 for k in ("spilling", "loops", "barriers", "escaping_break_if", "returns", "atomics", "selects")}
        n_prog = skipped = 0
        for mr in MAX_REGS:
            for cname in CONFIGS:
                cfg = Config.named(cname)
                for case in cases(cfg, N, seed=1000 + 31 * (mr or 0) + len(cname)):
                    ok, msg, res = diff_case(case, cfg, max_regs=mr)
                    self.assertTrue(ok, f"cfg={cname} max_regs={mr} seed={case.seed}: {msg}\n{case.text}")
                    n_prog += 1
                    skipped += msg.startswith("skipped")
                    for k, v in features(case, res).items():
                        agg[k] += bool(v)
        self.assertEqual(n_prog, N * len(CONFIGS) * len(MAX_REGS))
        # the campaign must actually have exercised the interesting constructs (guards against a vacuous generator)
        floor = {"spilling": 0.15, "loops": 0.2, "barriers": 0.08, "escaping_break_if": 0.05, "returns": 0.03,
                 "atomics": 0.2, "selects": 0.2}
        for k, f in floor.items():
            self.assertGreaterEqual(agg[k], f * n_prog, (k, agg, n_prog))
        print(f"\n[fuzz] {n_prog} programs ({skipped} skipped by a launch requirement); coverage: {agg}")

    def test_stack_depth_estimate_is_sound(self):
        """If the compiler does not warn, the program must run on a configuration whose stack depth is exactly the
        estimate (empirical soundness of the SIMT-stack-need analysis)."""
        from tests.compiler_harness import run_reference
        n_checked = 0
        for lanes_cfg in ("small", "default"):
            base = Config.named(lanes_cfg)
            for case in cases(base, N * 2, seed=4242):
                est = compile_ir_safe(case.text, base).info["est_stack_depth"]
                depth = max(2, est)
                probe = Config.from_params(dict(base.parameters(), simt_stack_depth=depth), name="probe")
                res = compile_ir_safe(case.text, probe)
                self.assertFalse(res.info["stack_overflow_possible"], (case.seed, est, depth))
                try:
                    out, run, _ = run_reference(res.image(), probe, case.grid, case.wg, case.bufs, case.args)
                except RequirementFailed:
                    continue
                self.assertNotEqual(run.error, "F_STACK_OVERFLOW",
                                    f"estimate {est} too low for seed {case.seed} on {lanes_cfg}\n{case.text}")
                self.assertTrue(run.ok, (case.seed, run))
                n_checked += 1
        self.assertGreater(n_checked, 20)

    def test_optimisation_does_not_change_results(self):
        cfg = Config.named("default")
        for case in cases(cfg, N, seed=77):
            ok, msg, _ = diff_case(case, cfg, opt=False)
            self.assertTrue(ok, f"seed={case.seed} opt=False: {msg}")

    def test_generator_text_round_trips(self):
        cfg = Config.named("default")
        for case in cases(cfg, 40, seed=5):
            k = parse_ir(case.text).kernel()
            self.assertEqual(ir.format_kernel(k), case.text)

    def test_generator_is_deterministic_across_hash_seeds(self):
        code = ("import random, hashlib, sys\nsys.path.insert(0, %r)\n"
                "from sfsdk.compiler import fuzz\nr = random.Random(42)\nh = hashlib.sha256()\n"
                "for _ in range(30): h.update(fuzz.random_case(r, max_wg=32, lanes=8).text.encode())\nprint(h.hexdigest())\n"
                % os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        digests = set()
        for hs in ("0", "1", "12345"):
            env = dict(os.environ, PYTHONHASHSEED=hs)
            digests.add(subprocess.check_output([sys.executable, "-c", code], env=env).decode().strip())
        self.assertEqual(len(digests), 1, digests)


if __name__ == "__main__":
    unittest.main()
