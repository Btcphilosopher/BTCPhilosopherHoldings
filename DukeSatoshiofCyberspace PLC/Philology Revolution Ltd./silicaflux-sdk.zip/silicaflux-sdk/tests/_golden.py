"""Shared helpers: run the SF-G1 reference example kernels through the *SDK* and compare to the golden reports."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Callable, Dict, List

from sfsdk.spec import SF_G1_DIR, MASK32

GOLD = SF_G1_DIR / "reference"
KDIR = SF_G1_DIR / "examples" / "kernels"
SENT = 0xCCCCCCCC


def lcg(seed: int, n: int) -> List[int]:
    out, x = [], seed & MASK32
    for _ in range(n):
        x = (x * 1664525 + 1013904223) & MASK32
        out.append(x)
    return out


def s32(x: int) -> int:
    return x - (1 << 32) if x & 0x80000000 else x


def diverge_ref(t: int):
    v = 100 + t if t & 1 else 200 - t
    v += 1000 if t & 2 else -1
    n, i = t & 7, 0
    while i < n:
        v += i
        i += 1
        if v & 16:
            break
    return None if n == 5 else v & MASK32


def golden(name: str) -> Dict:
    return json.loads((GOLD / name / "report.json").read_text())


def run_example(dev, name: str):
    """Drive one example through the SDK API; returns (LaunchResult, outputs dict). Mirrors docs/12."""
    cfg = dev.config
    if name == "vecadd":
        n, wg = 70, min(32, cfg.max_wg_threads)
        a, b = lcg(1, n), lcg(2, n)
        pa, pb = dev.alloc_words(a, "a"), dev.alloc_words(b, "b")
        pc = dev.alloc_words([SENT] * (n + 8), "c")
        k = dev.load_kernel(str(KDIR / "vecadd.sfa"))
        r = k.launch((n + wg - 1) // wg, wg, [pa, pb, pc, n])
        return r, {"c": pc.read_words(n + 8), "exp": [(x + y) & MASK32 for x, y in zip(a, b)] + [SENT] * 8}
    if name == "reduce_sum":
        n = 100
        wg = 1
        while wg * 2 <= min(16, cfg.max_wg_threads):
            wg *= 2
        data = [w % 1000 for w in (x >> 8 for x in lcg(3, n))]
        pin, pout = dev.alloc_words(data, "in"), dev.alloc_words([0], "out")
        k = dev.load_kernel(str(KDIR / "reduce_sum.sfa"))
        r = k.launch((n + wg - 1) // wg, wg, [pin, pout, n], shared=4 * wg)
        return r, {"sum": pout.read_words(1)[0], "exp": sum(data) & MASK32}
    if name == "matmul_i32":
        M, K, N = 6, 5, 7
        wg = min(8, cfg.max_wg_threads)
        A = [((x >> 16) % 201 - 100) & MASK32 for x in lcg(4, M * K)]
        B = [((x >> 16) % 201 - 100) & MASK32 for x in lcg(5, K * N)]
        pA, pB = dev.alloc_words(A, "A"), dev.alloc_words(B, "B")
        pC = dev.alloc_words([SENT] * (M * N + 8), "C")
        k = dev.load_kernel(str(KDIR / "matmul_i32.sfa"))
        r = k.launch(M, wg, [pA, pB, pC, N, K])
        exp = [sum(s32(A[i * K + t]) * s32(B[t * N + j]) for t in range(K)) & MASK32
               for i in range(M) for j in range(N)] + [SENT] * 8
        return r, {"C": pC.read_words(M * N + 8), "exp": exp}
    if name == "diverge":
        wg = min(20, cfg.max_wg_threads)
        nthr = wg * 2
        po = dev.alloc_words([0xAAAAAAAA] * nthr, "out")
        k = dev.load_kernel(str(KDIR / "diverge.sfa"))
        r = k.launch(2, wg, [po])
        exp = [0xAAAAAAAA if diverge_ref(t) is None else diverge_ref(t) for t in range(nthr)]
        return r, {"out": po.read_words(nthr), "exp": exp}
    raise KeyError(name)


EXAMPLES = ("vecadd", "reduce_sum", "matmul_i32", "diverge")
