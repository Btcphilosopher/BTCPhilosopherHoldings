#!/usr/bin/env python3
"""Build the distributable zip: deterministic order, no caches, no work-in-progress briefs.

    python3 scripts/package.py dist/silicaflux-sdk.zip
"""
import hashlib
import os
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PREFIX = "silicaflux-sdk"
EXCLUDE_DIRS = {"__pycache__", ".git", "dist", "build", ".pytest_cache"}
EXCLUDE_FILES = {"BRIEF_HWMODEL.md", "BRIEF_COMPILER.md"}
EXCLUDE_SUFFIX = (".pyc", ".pyo", ".vvp")


def files():
    out = []
    for dp, dns, fns in os.walk(ROOT):
        dns[:] = sorted(d for d in dns if d not in EXCLUDE_DIRS and not (Path(dp) == ROOT / "sf-g1" and d == "build"))
        for fn in sorted(fns):
            if fn in EXCLUDE_FILES or fn.endswith(EXCLUDE_SUFFIX) or fn == "SHA256SUMS.txt":
                continue
            out.append(Path(dp) / fn)
    return sorted(out)


def main() -> int:
    target = Path(sys.argv[1] if len(sys.argv) > 1 else "dist/silicaflux-sdk.zip")
    target.parent.mkdir(parents=True, exist_ok=True)
    fl = files()
    sums = "".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}\n" for p in fl)
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in fl:
            info = zipfile.ZipInfo(f"{PREFIX}/{p.relative_to(ROOT).as_posix()}", (2026, 11, 21, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            mode = p.stat().st_mode & 0o777
            info.external_attr = (0o100000 | (0o755 if mode & 0o100 else 0o644)) << 16
            z.writestr(info, p.read_bytes())
        z.writestr(zipfile.ZipInfo(f"{PREFIX}/SHA256SUMS.txt", (2026, 11, 21, 0, 0, 0)), sums)
    print(f"{target}: {len(fl) + 1} files, {target.stat().st_size} bytes")
    return 0


if __name__ == "__main__":
    sys.exit(main())
