#!/usr/bin/env python3
"""Three-way differential fuzzing of the compiler across BOTH backends.

For every random structured program (sfsdk.compiler.fuzz): compile once; run the *same binary* through the SDK runtime on
the reference simulator and on the hardware model; compare every output buffer of both against the IR interpreter (which
never sees SF-G1) and compare the two commit-trace digests with each other.

    python3 scripts/fuzz_cross_backend.py [--per-cell N] [--seed S] [--configs default small wide] [--max-regs none 6 4]

A program is *skipped* (and counted) when the kernel's own launch requirement rejects the generated geometry, when the
shared-memory demand does not fit the configuration, or when the compiler warned that the configuration's SIMT stack may
overflow and the device really did overflow.  Exit status is non-zero on any mismatch.

Launches use the architecture's ``SMEM_ZERO`` descriptor flag.  Generated programs may read a shared-memory slot that an exited
thread never wrote; without the flag that read returns implementation-defined power-up contents (the reference poisons shared
memory with 0xDEADBEEF, the hardware model uses a different pattern), the *values* would legitimately differ in the commit trace,
and the program would not be deterministic in the sense of the specification.  ``--no-smem-zero`` shows this effect.
"""
import argparse
import random
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import sfsdk                                                    # noqa: E402
from sfsdk.compiler import compile_ir, fuzz, parse_ir           # noqa: E402
from sfsdk.compiler.interp import InterpError                   # noqa: E402
from sfsdk.errors import ArgumentError, DeviceFault              # noqa: E402
from sfsdk.spec import Config                                   # noqa: E402
import struct                                                   # noqa: E402
import sfsdk.compiler.interp as interp_mod                      # noqa: E402
from sfsdk.compiler.interp import interpret                     # noqa: E402
from tests.compiler_harness import arg_names, eval_user_shared   # noqa: E402


def run_on(backend, cfg, img, case, smem_zero=True):
    with sfsdk.open_device(f"{backend}:{cfg.name}", keep_trace=True) as dev:
        bufs = {n: dev.alloc_words(w if w else [0], n) for n, w in case.bufs.items()}
        args = [bufs[a] if isinstance(a, str) else a for a in case.args]
        k = dev.load_kernel(img)
        r = k.launch(case.grid, case.wg, args, smem_zero=smem_zero)
        out = {n: bufs[n].read_words(max(len(w), 1))[:len(w)] for n, w in case.bufs.items()}
        return out, r, {n: b.addr for n, b in bufs.items()}


def interpret_at(kernel, cfg, case, addrs, shared_bytes):
    """Run the IR interpreter with the buffers at the SAME addresses the SDK allocated: some generated programs store
    pointer-derived values, so their results legitimately depend on where buffers live."""
    mem = bytearray(max(addrs[n] + 4 * max(len(w), 1) for n, w in case.bufs.items()) + 64)
    for n, w in case.bufs.items():
        if w:
            struct.pack_into(f"<{len(w)}I", mem, addrs[n], *[x & 0xFFFFFFFF for x in w])
    args = [addrs[a] if isinstance(a, str) else a & 0xFFFFFFFF for a in case.args]
    interpret(kernel, case.grid, case.wg, args, mem, lanes=cfg.lanes, shared_bytes=shared_bytes, max_steps=2_000_000)
    return {n: list(struct.unpack_from(f"<{len(w)}I", mem, addrs[n])) for n, w in case.bufs.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-cell", type=int, default=40)
    ap.add_argument("--seed", type=int, default=424242)
    ap.add_argument("--configs", nargs="+", default=["default", "small", "wide"])
    ap.add_argument("--max-regs", nargs="+", default=["none", "6", "4"])
    ap.add_argument("--no-smem-zero", action="store_true", help="leave shared memory uninitialised (expect legitimate trace differences)")
    a = ap.parse_args()
    smz = not a.no_smem_zero
    # The oracle must follow the same rule as the launch flag: SMEM_ZERO means shared memory starts as zeros, while the
    # interpreter's default is to poison it (like the reference simulator does) so that reads of unwritten slots are loud.
    interp_mod.POISON = 0 if smz else 0xDEADBEEF
    tally = dict(programs=0, skipped=0, spilled=0, traced=0, mismatches=0, instr=0)
    t0 = time.time()
    for mr_s in a.max_regs:
        mr = None if mr_s == "none" else int(mr_s)
        for cname in a.configs:
            cfg = Config.named(cname)
            rng = random.Random(a.seed + 7919 * (mr or 0) + len(cname))
            for _ in range(a.per_cell):
                case = fuzz.random_case(rng, max_wg=cfg.max_wg_threads, lanes=cfg.lanes)
                res = compile_ir(case.text, "fuzz.sfir", cfg, max_regs=mr)
                img = res.image()
                tally["programs"] += 1
                try:
                    out_ref, r_ref, addr_ref = run_on("reference", cfg, img, case, smz)
                    out_hw, r_hw, addr_hw = run_on("hwmodel", cfg, img, case, smz)
                    assert addr_ref == addr_hw, "the SDK allocator must be deterministic across backends"
                except ArgumentError:
                    tally["skipped"] += 1
                    continue
                except DeviceFault as e:
                    if e.report.name == "F_STACK_OVERFLOW" and res.info["stack_overflow_possible"]:
                        tally["skipped"] += 1
                        continue
                    print(f"FAULT cfg={cname} max_regs={mr} seed={case.seed}: {e}\n{case.text}")
                    tally["mismatches"] += 1
                    continue
                kernel = parse_ir(case.text).kernel()
                av = dict(zip(arg_names(img), [addr_ref[a] if isinstance(a, str) else a & 0xFFFFFFFF for a in case.args]))
                try:
                    exp = interpret_at(kernel, cfg, case, addr_ref,
                                       eval_user_shared(img, av, case.grid, case.wg, cfg.lanes))
                except InterpError as e:
                    print(f"interpreter error (generator bug?) seed={case.seed}: {e}")
                    tally["mismatches"] += 1
                    continue
                bad = []
                for n in exp:
                    if out_ref[n] != exp[n]:
                        bad.append(f"reference differs from interpreter in '{n}'")
                    if out_hw[n] != exp[n]:
                        bad.append(f"hardware model differs from interpreter in '{n}'")
                if (r_ref.issued, r_ref.lane_ops) != (r_hw.issued, r_hw.lane_ops):
                    bad.append(f"counters {(r_ref.issued, r_ref.lane_ops)} vs {(r_hw.issued, r_hw.lane_ops)}")
                if not img.uses_order_dependent_atomics:
                    tally["traced"] += 1
                    if r_ref.trace_digest != r_hw.trace_digest:
                        bad.append("commit-trace digests differ")
                if bad:
                    tally["mismatches"] += 1
                    print(f"MISMATCH cfg={cname} max_regs={mr} seed={case.seed}: {'; '.join(bad)}\n{case.text}")
                tally["spilled"] += bool(res.info["spilling"])
                tally["instr"] += res.info["instructions"]
        print(f"[{time.time() - t0:6.1f}s] max_regs={mr_s}: {tally}", flush=True)
    print(f"RESULT: {tally}")
    return 1 if tally["mismatches"] else 0


if __name__ == "__main__":
    sys.exit(main())
