"""Public exports for sentinel_detection."""

from sentinel_detection.engine import DetectionConfig, correlate_process_evidence

__all__ = ["DetectionConfig", "correlate_process_evidence"]
