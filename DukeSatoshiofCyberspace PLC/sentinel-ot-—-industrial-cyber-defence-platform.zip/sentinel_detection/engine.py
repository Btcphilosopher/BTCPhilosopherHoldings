"""Process-integrity correlation and defensive detection engine."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from sentinel_integrity.crypto import utc_now_iso
from sentinel_telemetry.buffer import find_stale_or_missing_tags, parse_iso_utc
from sentinel_types import (
    BaselineClassification,
    BaselineComparisonResult,
    ControllerSnapshot,
    DetectionFinding,
    EWSAuditRecord,
    FindingCategory,
    HypothesisClass,
    MaintenanceRecord,
    QualityFlag,
    Severity,
    TelemetryObservation,
)


@dataclass(frozen=True)
class DetectionConfig:
    stale_threshold_seconds: float = 30.0
    flow_mismatch_tolerance_lpm: float = 15.0
    stuck_sensor_min_samples: int = 4
    stuck_sensor_epsilon: float = 0.05
    redundant_sensor_delta_pct: float = 4.0
    expected_tags: tuple[tuple[str, str], ...] = (
        ("TK-101", "tank_level_pct"),
        ("P-101", "pump_command"),
        ("FT-101", "flow_rate_lpm"),
        ("PT-101", "discharge_pressure_kpa"),
    )


def _within_window(ts_iso: str, start_iso: str, end_iso: str) -> bool:
    ts = parse_iso_utc(ts_iso)
    return parse_iso_utc(start_iso) <= ts <= parse_iso_utc(end_iso)


def _matching_maintenance(
    asset_id: str,
    ts_iso: str,
    maintenance_records: list[MaintenanceRecord],
) -> MaintenanceRecord | None:
    for m in maintenance_records:
        if m.status == "approved" and m.asset_id == asset_id and _within_window(ts_iso, m.window_start, m.window_end):
            return m
    return None


def correlate_process_evidence(
    *,
    run_id: str,
    baseline_comparisons: list[BaselineComparisonResult],
    snapshots: list[ControllerSnapshot],
    ews_records: list[EWSAuditRecord],
    maintenance_records: list[MaintenanceRecord],
    telemetry: list[TelemetryObservation],
    evidence_ids: list[str],
    config: DetectionConfig | None = None,
) -> list[DetectionFinding]:
    """Correlate baseline diffs, EWS logs, maintenance windows, and process telemetry."""
    cfg = config or DetectionConfig()
    findings: list[DetectionFinding] = []
    seq = 0

    def next_id() -> str:
        nonlocal seq
        seq += 1
        return f"FND-{run_id}-{seq:03d}"

    unauthorised_assets: set[str] = set()
    snapshot_by_id = {s.snapshot_id: s for s in snapshots}

    # 1. Baseline comparison + Maintenance + EWS correlation
    for comp in baseline_comparisons:
        snap = snapshot_by_id.get(comp.snapshot_id)
        if comp.classification == BaselineClassification.UNAUTHORISED and snap is not None:
            maint = _matching_maintenance(comp.asset_id, snap.captured_at, maintenance_records)
            related_ews = [
                e for e in ews_records
                if e.target_asset_id == comp.asset_id
                and e.action in ("program_download", "setpoint_write", "mode_change")
            ]
            ews_summary = ", ".join(f"{e.event_id}({e.operator_id}:{e.action})" for e in related_ews) or "none recorded"

            if maint is not None and (
                maint.expected_program_hash is None or maint.expected_program_hash == snap.program_hash
            ):
                findings.append(
                    DetectionFinding(
                        finding_id=next_id(),
                        category=FindingCategory.UNEXPECTED_PROGRAM_CHANGE,
                        hypothesis=HypothesisClass.LEGITIMATE_MAINTENANCE,
                        severity=Severity.INFO,
                        asset_id=comp.asset_id,
                        title=f"Authorised configuration deviation on {comp.asset_id} within maintenance window",
                        summary=(
                            f"Snapshot {snap.snapshot_id} differs from baseline {comp.baseline_id} "
                            f"({len(comp.diffs)} diff(s)), matched by approved work order {maint.work_order_id}. "
                            f"Correlated EWS events: {ews_summary}."
                        ),
                        detected_at=utc_now_iso(),
                        supporting_evidence_ids=tuple(evidence_ids),
                        telemetry_extracts=(),
                        alternative_explanations=(
                            "Work order scope could have been exceeded if unreviewed logic rungs were also modified; verify structural diffs against work order specification.",
                            "Baseline manifest has not yet been updated to the new approved revision.",
                        ),
                        uncertainty_notes="Maintenance record timestamps and EWS audit logs rely on local clock synchronisation.",
                        baseline_diff_refs=tuple(d.path for d in comp.diffs),
                    )
                )
            else:
                unauthorised_assets.add(comp.asset_id)
                findings.append(
                    DetectionFinding(
                        finding_id=next_id(),
                        category=FindingCategory.UNEXPECTED_PROGRAM_CHANGE,
                        hypothesis=HypothesisClass.POSSIBLE_UNAUTHORISED_ACTIVITY,
                        severity=Severity.CRITICAL,
                        asset_id=comp.asset_id,
                        title=f"Unapproved controller configuration/program change on {comp.asset_id}",
                        summary=(
                            f"Snapshot {snap.snapshot_id} deviates from signed baseline {comp.baseline_id} "
                            f"({len(comp.diffs)} structural diff(s)) with no matching approved maintenance window. "
                            f"Correlated EWS events: {ews_summary}."
                        ),
                        detected_at=utc_now_iso(),
                        supporting_evidence_ids=tuple(evidence_ids),
                        telemetry_extracts=(),
                        alternative_explanations=(
                            "Emergency field intervention may have occurred without prior maintenance ticket entry.",
                            "Baseline manifest could be superseded locally if an update was approved out-of-band.",
                        ),
                        uncertainty_notes=(
                            "Detection engine confirms mismatch against signed baseline and absence of matching "
                            "maintenance record in imported datasets; physical intent requires human investigation."
                        ),
                        baseline_diff_refs=tuple(d.path for d in comp.diffs),
                    )
                )
                findings.append(
                    DetectionFinding(
                        finding_id=next_id(),
                        category=FindingCategory.MISSING_MAINTENANCE_AUTH,
                        hypothesis=HypothesisClass.POSSIBLE_UNAUTHORISED_ACTIVITY,
                        severity=Severity.HIGH,
                        asset_id=comp.asset_id,
                        title=f"Missing maintenance authorisation for change on {comp.asset_id}",
                        summary=(
                            f"Change observed on {comp.asset_id} at {snap.captured_at} lacks an approved "
                            f"maintenance record covering the asset and timestamp."
                        ),
                        detected_at=utc_now_iso(),
                        supporting_evidence_ids=tuple(evidence_ids),
                        telemetry_extracts=(),
                        alternative_explanations=(
                            "Maintenance record export may be delayed or omitted from the offline import batch.",
                        ),
                        uncertainty_notes="Authorisation check is bounded to imported maintenance records.",
                        baseline_diff_refs=tuple(d.path for d in comp.diffs),
                    )
                )

    # 2. Unexplained operating-mode transitions on controllers
    for snap in snapshots:
        if snap.operating_mode not in ("RUN", "AUTO"):
            maint = _matching_maintenance(snap.asset_id, snap.captured_at, maintenance_records)
            if maint is None:
                findings.append(
                    DetectionFinding(
                        finding_id=next_id(),
                        category=FindingCategory.UNEXPLAINED_STATE_TRANSITION,
                        hypothesis=(
                            HypothesisClass.POSSIBLE_UNAUTHORISED_ACTIVITY
                            if snap.asset_id in unauthorised_assets
                            else HypothesisClass.INCONCLUSIVE
                        ),
                        severity=Severity.HIGH,
                        asset_id=snap.asset_id,
                        title=f"Unexplained controller operating mode '{snap.operating_mode}' on {snap.asset_id}",
                        summary=(
                            f"Controller {snap.asset_id} observed in non-production mode '{snap.operating_mode}' "
                            f"at {snap.captured_at} without an active maintenance window."
                        ),
                        detected_at=utc_now_iso(),
                        supporting_evidence_ids=tuple(evidence_ids),
                        telemetry_extracts=(),
                        alternative_explanations=(
                            "Local keyswitch or operator HMI mode change during troubleshooting.",
                            "Unrecorded maintenance or commissioning test.",
                        ),
                        uncertainty_notes="Operating mode reflects snapshot capture instant only.",
                    )
                )

    # 3. Stale or missing telemetry observations
    if telemetry:
        latest_ts = max(telemetry, key=lambda o: parse_iso_utc(o.source_timestamp)).source_timestamp
        stale_issues = find_stale_or_missing_tags(
            telemetry,
            expected_tags=list(cfg.expected_tags),
            window_end_iso=latest_ts,
            stale_threshold_seconds=cfg.stale_threshold_seconds,
        )
        for issue in stale_issues:
            findings.append(
                DetectionFinding(
                    finding_id=next_id(),
                    category=FindingCategory.STALE_OR_MISSING_OBSERVATION,
                    hypothesis=HypothesisClass.TELEMETRY_LOSS_OR_DELAY,
                    severity=Severity.MEDIUM,
                    asset_id=str(issue["asset_id"]),
                    title=f"Stale or missing telemetry on {issue['asset_id']}.{issue['tag']}",
                    summary=f"Observation health check flagged '{issue['reason']}' (stale_seconds={issue.get('stale_seconds')}).",
                    detected_at=utc_now_iso(),
                    supporting_evidence_ids=tuple(evidence_ids),
                    telemetry_extracts=(issue,),
                    alternative_explanations=(
                        "Historian polling interruption, span-port buffer drop, or isolated telemetry gateway.",
                        "Field transmitter powered down or disconnected from I/O module.",
                    ),
                    uncertainty_notes="Missing telemetry reduces visibility and prevents verifying physical state during the gap.",
                )
            )

    # Index telemetry by timestamp bucket for correlation
    by_ts: dict[str, dict[tuple[str, str], TelemetryObservation]] = {}
    by_tag: dict[tuple[str, str], list[TelemetryObservation]] = {}
    for obs in telemetry:
        by_ts.setdefault(obs.source_timestamp, {})[(obs.asset_id, obs.tag)] = obs
        by_tag.setdefault((obs.asset_id, obs.tag), []).append(obs)

    # 4. Command-versus-observation mismatch (P-101 pump_command vs FT-101 flow_rate_lpm)
    mismatch_samples: list[dict[str, Any]] = []
    for ts in sorted(by_ts.keys()):
        bucket = by_ts[ts]
        pump = bucket.get(("P-101", "pump_command"))
        flow = bucket.get(("FT-101", "flow_rate_lpm"))
        if pump is None or flow is None:
            continue
        if pump.quality in (QualityFlag.BAD, QualityFlag.STALE) or flow.quality in (QualityFlag.BAD, QualityFlag.STALE):
            continue
        cmd_on = bool(pump.value) if isinstance(pump.value, bool) else float(pump.value) > 0.5
        flow_val = float(flow.value)
        if cmd_on and flow_val < cfg.flow_mismatch_tolerance_lpm:
            mismatch_samples.append({
                "timestamp": ts,
                "pump_command": pump.value,
                "flow_rate_lpm": flow_val,
                "flow_unit": flow.unit,
                "reason": "pump_command_on_zero_flow",
            })
        elif (not cmd_on) and flow_val > cfg.flow_mismatch_tolerance_lpm:
            mismatch_samples.append({
                "timestamp": ts,
                "pump_command": pump.value,
                "flow_rate_lpm": flow_val,
                "flow_unit": flow.unit,
                "reason": "pump_command_off_positive_flow",
            })

    if mismatch_samples:
        hyp = (
            HypothesisClass.POSSIBLE_UNAUTHORISED_ACTIVITY
            if "PLC-101" in unauthorised_assets
            else HypothesisClass.EQUIPMENT_OR_SENSOR_FAULT
        )
        findings.append(
            DetectionFinding(
                finding_id=next_id(),
                category=FindingCategory.COMMAND_OBSERVATION_MISMATCH,
                hypothesis=hyp,
                severity=Severity.HIGH,
                asset_id="P-101",
                title=f"Command-versus-observation mismatch between P-101 and FT-101 ({len(mismatch_samples)} sample(s))",
                summary=(
                    f"Observed {len(mismatch_samples)} timestamp(s) where pump command state contradicted "
                    f"measured discharge flow on FT-101."
                ),
                detected_at=utc_now_iso(),
                supporting_evidence_ids=tuple(evidence_ids),
                telemetry_extracts=tuple(mismatch_samples[:10]),
                alternative_explanations=(
                    "Mechanical pump trip, closed manual isolation valve, or cavitating impeller.",
                    "Flow transmitter FT-101 fault, clogged impulse line, or wiring open-circuit.",
                    "Logic manipulation altering HMI/command reporting independently of physical output.",
                ),
                uncertainty_notes="Telemetry alone cannot differentiate a stuck check valve from a spoofed flow reading without local physical inspection.",
            )
        )

    # 5. Contradictory measurements: frozen tank level sensor while flow is active OR redundant sensor divergence
    level_series = sorted(
        by_tag.get(("TK-101", "tank_level_pct"), []),
        key=lambda o: parse_iso_utc(o.source_timestamp),
    )
    flow_by_ts = {o.source_timestamp: o for o in by_tag.get(("FT-101", "flow_rate_lpm"), [])}
    frozen_streak: list[dict[str, Any]] = []
    for i in range(1, len(level_series)):
        prev_o = level_series[i - 1]
        curr_o = level_series[i]
        if curr_o.quality != QualityFlag.GOOD and curr_o.quality != QualityFlag.SIMULATED:
            continue
        flow_o = flow_by_ts.get(curr_o.source_timestamp)
        active_flow = flow_o is not None and float(flow_o.value) > cfg.flow_mismatch_tolerance_lpm
        if active_flow and abs(float(curr_o.value) - float(prev_o.value)) <= cfg.stuck_sensor_epsilon:
            frozen_streak.append({
                "timestamp": curr_o.source_timestamp,
                "tank_level_pct": curr_o.value,
                "flow_rate_lpm": flow_o.value if flow_o else None,
            })
        else:
            if len(frozen_streak) >= cfg.stuck_sensor_min_samples:
                break
            frozen_streak.clear()

    if len(frozen_streak) >= cfg.stuck_sensor_min_samples:
        findings.append(
            DetectionFinding(
                finding_id=next_id(),
                category=FindingCategory.CONTRADICTORY_MEASUREMENTS,
                hypothesis=(
                    HypothesisClass.POSSIBLE_UNAUTHORISED_ACTIVITY
                    if "PLC-101" in unauthorised_assets
                    else HypothesisClass.EQUIPMENT_OR_SENSOR_FAULT
                ),
                severity=Severity.HIGH,
                asset_id="TK-101",
                title="Contradictory process measurements: tank level frozen during active inflow",
                summary=(
                    f"Tank level LT-101 remained constant (~{frozen_streak[0]['tank_level_pct']}%) across "
                    f"{len(frozen_streak)} consecutive intervals while FT-101 reported active flow."
                ),
                detected_at=utc_now_iso(),
                supporting_evidence_ids=tuple(evidence_ids),
                telemetry_extracts=tuple(frozen_streak[:10]),
                alternative_explanations=(
                    "Level transmitter LT-101 frozen/faulted (e.g., bridged float or ADC lockup).",
                    "Simultaneous equal outflow through an unmonitored drain/overflow line.",
                    "Telemetry replay or masked sensor input inside controller logic.",
                ),
                uncertainty_notes="Verification requires reading local sight-glass level at TK-101.",
            )
        )

    # Check redundant level sensor divergence if LT-101_BACKUP present
    backup_by_ts = {o.source_timestamp: o for o in by_tag.get(("TK-101", "tank_level_backup_pct"), [])}
    divergent_samples: list[dict[str, Any]] = []
    for obs in level_series:
        b = backup_by_ts.get(obs.source_timestamp)
        if b is None:
            continue
        delta = abs(float(obs.value) - float(b.value))
        if delta > cfg.redundant_sensor_delta_pct:
            divergent_samples.append({
                "timestamp": obs.source_timestamp,
                "primary_pct": obs.value,
                "backup_pct": b.value,
                "delta_pct": round(delta, 2),
            })

    if divergent_samples:
        findings.append(
            DetectionFinding(
                finding_id=next_id(),
                category=FindingCategory.CONTRADICTORY_MEASUREMENTS,
                hypothesis=(
                    HypothesisClass.POSSIBLE_UNAUTHORISED_ACTIVITY
                    if "PLC-101" in unauthorised_assets
                    else HypothesisClass.EQUIPMENT_OR_SENSOR_FAULT
                ),
                severity=Severity.HIGH,
                asset_id="TK-101",
                title=f"Redundant tank level sensor divergence ({len(divergent_samples)} sample(s))",
                summary=(
                    f"Primary and backup level measurements for TK-101 diverged by up to "
                    f"{max(s['delta_pct'] for s in divergent_samples)}%."
                ),
                detected_at=utc_now_iso(),
                supporting_evidence_ids=tuple(evidence_ids),
                telemetry_extracts=tuple(divergent_samples[:10]),
                alternative_explanations=(
                    "Calibration drift or mechanical fault on one transmitter.",
                    "Scaling factor modification in PLC analog input block.",
                ),
                uncertainty_notes="Check both transmitters against physical tank gauge.",
            )
        )

    return findings
