"""Explicitly configured read-only OT collection adapters."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from sentinel_integrity.parser import safe_load_json_file
from sentinel_types import AdapterReadOnlyError, ResourceLimits


class ReadOnlyAdapter(ABC):
    """Base contract enforcing strict read-only operation; write methods fail closed."""

    adapter_id: str
    read_only: bool = True

    @abstractmethod
    def collect(self) -> dict[str, Any]:
        """Collect read-only snapshots, telemetry, or logs."""

    def write_register(self, *args: Any, **kwargs: Any) -> None:
        raise AdapterReadOnlyError(
            f"Adapter '{self.adapter_id}' is strictly read-only; write_register is prohibited.",
            component="sentinel_adapters",
            operation="write_register",
        )

    def write_coil(self, *args: Any, **kwargs: Any) -> None:
        raise AdapterReadOnlyError(
            f"Adapter '{self.adapter_id}' is strictly read-only; write_coil is prohibited.",
            component="sentinel_adapters",
            operation="write_coil",
        )

    def upload_program(self, *args: Any, **kwargs: Any) -> None:
        raise AdapterReadOnlyError(
            f"Adapter '{self.adapter_id}' is strictly read-only; controller program upload is prohibited.",
            component="sentinel_adapters",
            operation="upload_program",
        )

    def send_command(self, *args: Any, **kwargs: Any) -> None:
        raise AdapterReadOnlyError(
            f"Adapter '{self.adapter_id}' is strictly read-only; controller commands are prohibited.",
            component="sentinel_adapters",
            operation="send_command",
        )


class OfflineBundleAdapter(ReadOnlyAdapter):
    """Reads explicitly authorised offline export files under bounded parser checks."""

    def __init__(self, adapter_id: str, bundle_dir: Path, *, limits: ResourceLimits | None = None) -> None:
        self.adapter_id = adapter_id
        self._bundle_dir = bundle_dir
        self._limits = limits or ResourceLimits()

    def collect(self) -> dict[str, Any]:
        files = {}
        for name in ("inventory.json", "snapshot.json", "telemetry.json", "ews_audit.json", "maintenance.json"):
            p = self._bundle_dir / name
            if p.exists():
                files[name] = safe_load_json_file(p, limits=self._limits)
        return files


class SyntheticLabTapAdapter(ReadOnlyAdapter):
    """Read-only tap adapter bound to a synthetic laboratory scenario bundle."""

    def __init__(self, adapter_id: str, scenario_bundle: dict[str, Any]) -> None:
        self.adapter_id = adapter_id
        self._bundle = scenario_bundle

    def collect(self) -> dict[str, Any]:
        return {
            "inventory": self._bundle["inventory"],
            "snapshot": self._bundle["snapshot"],
            "telemetry": self._bundle["telemetry"],
            "ews_audit": self._bundle["ews_audit"],
            "maintenance": self._bundle["maintenance"],
        }
