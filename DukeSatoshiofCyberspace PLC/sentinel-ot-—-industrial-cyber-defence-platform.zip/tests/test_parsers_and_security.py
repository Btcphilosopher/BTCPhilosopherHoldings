"""Tests for defensive parsers, security boundaries, encrypted backups, and read-only adapters."""

from __future__ import annotations

import os
import stat
import tempfile
import unittest
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

from sentinel_adapters import OfflineBundleAdapter
from sentinel_integrity import (
    CredentialStore,
    KeyRing,
    RedactedLogger,
    SigningKey,
    create_encrypted_backup,
    create_signed_update_bundle,
    enforce_retention_policy,
    restore_encrypted_backup,
    safe_load_json_bytes,
    safe_read_zip_entries,
    verify_signed_update_bundle,
)
from sentinel_types import (
    AdapterReadOnlyError,
    IntegrityError,
    ResourceLimitError,
    ResourceLimits,
    SecurityBoundaryError,
    ValidationError,
)


class TestParsersAndSecurity(unittest.TestCase):
    def test_json_parser_bounds_and_malformed_rejection(self) -> None:
        limits = ResourceLimits(max_input_bytes=1024, max_json_depth=4)
        with self.assertRaises(ValidationError):
            safe_load_json_bytes(b"{broken json", limits=limits)
        with self.assertRaises(ValidationError):
            safe_load_json_bytes(b'{"x": NaN}', limits=limits)
        with self.assertRaises(ResourceLimitError):
            safe_load_json_bytes(b'{"a":{"b":{"c":{"d":{"e":1}}}}}', limits=limits)
        with self.assertRaises(ResourceLimitError):
            safe_load_json_bytes(b'{"k":"' + b"x" * 2000 + b'"}', limits=limits)

    def test_zip_parser_blocks_traversal_symlinks_and_bombs(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)

            # 1. Path traversal
            trav_zip = root / "trav.zip"
            with zipfile.ZipFile(trav_zip, "w") as zf:
                zf.writestr("../../etc/passwd", b"root:x:0:0")
            with self.assertRaises(SecurityBoundaryError):
                safe_read_zip_entries(trav_zip)

            # 2. POSIX symlink inside ZIP
            sym_zip = root / "sym.zip"
            with zipfile.ZipFile(sym_zip, "w") as zf:
                zi = zipfile.ZipInfo("link.txt")
                zi.create_system = 3  # Unix
                zi.external_attr = (stat.S_IFLNK | 0o777) << 16
                zf.writestr(zi, b"/etc/shadow")
            with self.assertRaises(SecurityBoundaryError):
                safe_read_zip_entries(sym_zip)

            # 3. Compression ratio / zip bomb guard
            bomb_zip = root / "bomb.zip"
            with zipfile.ZipFile(bomb_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
                zf.writestr("zeros.bin", b"\x00" * 500_000)
            with self.assertRaises(ResourceLimitError):
                safe_read_zip_entries(bomb_zip, limits=ResourceLimits(max_archive_compression_ratio=5.0))

    def test_credentials_redacted_logs_signed_updates_and_backups(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)

            # Credential store
            cstore = CredentialStore(root / "creds.enc", "Master-Vault-Secret-99!")
            cstore.put_secret("historian_ro_token", "super_secret_token_value")
            raw_on_disk = (root / "creds.enc").read_bytes()
            self.assertNotIn(b"super_secret_token_value", raw_on_disk)
            self.assertEqual(cstore.get_secret("historian_ro_token"), "super_secret_token_value")

            # Redacted logger
            log_path = root / "audit.jsonl"
            logger = RedactedLogger(log_path)
            logger.log(
                "INFO",
                "auth",
                "login_attempt",
                password="PlaintextPassword123",
                authorization="Bearer abc.def.ghi",
                user="analyst_01",
            )
            text = log_path.read_text(encoding="utf-8")
            self.assertNotIn("PlaintextPassword123", text)
            self.assertNotIn("abc.def.ghi", text)
            self.assertIn("[REDACTED]", text)

            # Signed update verification
            kr = KeyRing()
            kr.add_key(SigningKey.generate("UPD-01", "update"))
            bundle = create_signed_update_bundle({"rules": ["R1", "R2"]}, version="1.0.1", keyring=kr, key_id="UPD-01")
            verified_body = verify_signed_update_bundle(bundle, kr)
            self.assertEqual(verified_body["bundle_version"], "1.0.1")
            bundle["body"]["bundle_version"] = "9.9.9"
            with self.assertRaises(IntegrityError):
                verify_signed_update_bundle(bundle, kr)

            # Encrypted backup and restore
            src_dir = root / "state_src"
            src_dir.mkdir()
            (src_dir / "config.json").write_text('{"mode":"read_only"}', encoding="utf-8")
            bak_file = root / "state.sotbak"
            create_encrypted_backup(src_dir, bak_file, "Backup-Key-2026!")
            self.assertNotIn(b"read_only", bak_file.read_bytes())

            with self.assertRaises(IntegrityError):
                restore_encrypted_backup(bak_file, root / "restore_bad", "Wrong-Key!")

            restore_dir = root / "restore_ok"
            res = restore_encrypted_backup(bak_file, restore_dir, "Backup-Key-2026!")
            self.assertEqual(res["restored_files"], 1)
            self.assertEqual((restore_dir / "config.json").read_text(encoding="utf-8"), '{"mode":"read_only"}')

            # Retention enforcement
            old_file = restore_dir / "old_export.json"
            old_file.write_text("{}", encoding="utf-8")
            past_epoch = (datetime.now(timezone.utc) - timedelta(days=120)).timestamp()
            os.utime(old_file, (past_epoch, past_epoch))
            removed = enforce_retention_policy(restore_dir, retention_days=90)
            self.assertEqual(removed, ["old_export.json"])

    def test_read_only_adapter_rejects_all_writes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            adapter = OfflineBundleAdapter("RO-01", Path(tmp))
            with self.assertRaises(AdapterReadOnlyError):
                adapter.write_register(40001, 999)
            with self.assertRaises(AdapterReadOnlyError):
                adapter.write_coil(1, True)
            with self.assertRaises(AdapterReadOnlyError):
                adapter.upload_program(b"malicious")
            with self.assertRaises(AdapterReadOnlyError):
                adapter.send_command("STOP_PUMP")


if __name__ == "__main__":
    unittest.main()
