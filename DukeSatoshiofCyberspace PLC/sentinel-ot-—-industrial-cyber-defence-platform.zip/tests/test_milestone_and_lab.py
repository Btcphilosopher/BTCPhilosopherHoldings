"""Tests for First Acceptance Milestone and Synthetic Verification Laboratory."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from sentinel_cases import approve_incident_case
from sentinel_cli.pipeline import SentinelWorkspace, run_verification_laboratory
from sentinel_evidence import verify_evidence_package
from sentinel_simulator import generate_scenario_bundle
from sentinel_types import (
    CaseStatus,
    FindingCategory,
    HypothesisClass,
    IncidentCase,
    ChecklistItem,
    DetectionFinding,
    BaselineComparisonResult,
    TimelineEntry,
)


class TestMilestoneAndLab(unittest.TestCase):
    def test_first_acceptance_milestone_with_interrupted_recovery(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            ws = SentinelWorkspace(Path(tmp))
            tokens = ws.bootstrap_demo_identities_and_keys()
            baseline = ws.create_signed_lab_baseline(tokens["preparer_01"], tokens["approver_01"])
            bundle = generate_scenario_bundle("unapproved_controller_change")

            # 1. Start analysis and simulate interruption after evidence sealing
            interrupted = ws.run_bundle_analysis(
                run_id="MS-001",
                bundle=bundle,
                baseline=baseline,
                custodian="collector_01",
                analyst_token=tokens["analyst_01"],
                simulate_interrupt=True,
            )
            self.assertEqual(interrupted["status"], "interrupted")
            self.assertEqual(interrupted["checkpoint_stage"], "INTERRUPTED_AFTER_INGEST")

            # 2. Recover cleanly from SQLite WAL checkpoint
            resumed = ws.resume_interrupted_analysis(
                run_id="MS-001",
                baseline=baseline,
                analyst_token=tokens["analyst_01"],
            )
            self.assertEqual(resumed["status"], "completed")
            case = resumed["case"]
            categories = {f["category"] for f in case["findings"]}
            self.assertIn(FindingCategory.UNEXPECTED_PROGRAM_CHANGE.value, categories)
            self.assertIn(FindingCategory.MISSING_MAINTENANCE_AUTH.value, categories)
            self.assertIn(FindingCategory.UNEXPLAINED_STATE_TRANSITION.value, categories)
            self.assertIn(FindingCategory.COMMAND_OBSERVATION_MISMATCH.value, categories)

            # Ensure no duplicate findings on repeated recovery
            resumed_again = ws.resume_interrupted_analysis(
                run_id="MS-001",
                baseline=baseline,
                analyst_token=tokens["analyst_01"],
            )
            self.assertEqual(len(resumed_again["case"]["findings"]), len(case["findings"]))

            # 3. Verify preserved evidence package independently
            pkg_zip = Path(resumed["package_zip"])
            self.assertTrue(pkg_zip.exists())
            verif = verify_evidence_package(pkg_zip, ws.keyring)
            self.assertTrue(verif["verified"])
            self.assertIn("not automatically confer legal admissibility", verif["provenance_caveat"])

            # 4. Verify non-automated containment guardrail
            self.assertIn("disabled", case["containment_guardrail"].lower())

    def test_verification_laboratory_accuracy_and_latency(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            out_json = Path(tmp) / "verification_results.json"
            report = run_verification_laboratory(Path(tmp) / "lab_work", output_json=out_json)
            self.assertTrue(out_json.exists())
            summary = report["summary"]
            self.assertEqual(summary["total_scenarios"], 6)
            self.assertEqual(summary["false_positives"], 0)
            self.assertEqual(summary["false_negatives"], 0)
            self.assertEqual(summary["detection_accuracy"], 1.0)
            self.assertEqual(summary["false_positive_rate"], 0.0)
            self.assertTrue(summary["all_packages_verified"])
            self.assertTrue(summary["all_categories_matched"])
            self.assertLess(summary["mean_latency_ms"], 500.0)

            # Check alternative explanations & hypothesis distinction on sensor fault vs planned maintenance
            by_name = {s["scenario"]: s for s in report["scenarios"]}
            self.assertIn(HypothesisClass.LEGITIMATE_MAINTENANCE.value, by_name["planned_maintenance"]["observed_hypotheses"])
            self.assertIn(HypothesisClass.EQUIPMENT_OR_SENSOR_FAULT.value, by_name["sensor_fault"]["observed_hypotheses"])
            self.assertIn(HypothesisClass.TELEMETRY_LOSS_OR_DELAY.value, by_name["stale_telemetry"]["observed_hypotheses"])


if __name__ == "__main__":
    unittest.main()
