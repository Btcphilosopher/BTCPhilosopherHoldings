"""Tests for trusted baselines, dual approval, RBAC, and authentication."""

from __future__ import annotations

import unittest
from dataclasses import replace

from sentinel_baselines import (
    approve_and_sign_baseline,
    compare_snapshot_to_baseline,
    prepare_baseline_draft,
    verify_baseline_manifest,
)
from sentinel_integrity import AuthManager, KeyRing, SigningKey
from sentinel_simulator import baseline_controller_snapshot
from sentinel_types import (
    AuthorizationError,
    BaselineClassification,
    BaselineDocumentRef,
    IntegrityError,
    Role,
    ValidationError,
)


class TestBaselinesAndRBAC(unittest.TestCase):
    def setUp(self) -> None:
        self.auth = AuthManager()
        self.auth.register_user("prep_user", "Strong-Preparer-123!", {Role.BASELINE_PREPARER})
        self.auth.register_user("appr_user", "Strong-Approver-456!", {Role.BASELINE_APPROVER})
        self.auth.register_user("dual_user", "Strong-DualRole-789!", {Role.BASELINE_PREPARER, Role.BASELINE_APPROVER})
        self.auth.register_user("viewer", "Strong-Auditor-000!", {Role.AUDITOR})

        self.prep_sess = self.auth.authenticate("prep_user", "Strong-Preparer-123!")
        self.appr_sess = self.auth.authenticate("appr_user", "Strong-Approver-456!")
        self.dual_sess = self.auth.authenticate("dual_user", "Strong-DualRole-789!")
        self.viewer_sess = self.auth.authenticate("viewer", "Strong-Auditor-000!")

        self.keyring = KeyRing()
        self.keyring.add_key(SigningKey.generate("KEY-BL", "baseline"))

    def test_dual_approval_rejects_self_approval(self) -> None:
        snap = baseline_controller_snapshot()
        draft = prepare_baseline_draft(
            self.dual_sess,
            baseline_id="BL-01",
            asset_id="PLC-101",
            version="1.0.0",
            effective_from="2026-01-01T00:00:00+00:00",
            effective_until="2027-01-01T00:00:00+00:00",
            documents=[BaselineDocumentRef("D1", "program", "abc", "ews")],
            snapshot=snap,
        )
        with self.assertRaises(AuthorizationError):
            approve_and_sign_baseline(
                self.dual_sess,
                draft,
                approval_reference="ECR-1",
                keyring=self.keyring,
                key_id="KEY-BL",
            )

    def test_rbac_blocks_unprivileged_roles_and_weak_passwords(self) -> None:
        with self.assertRaises(ValidationError):
            self.auth.register_user("weak_u", "short", {Role.ANALYST})

        snap = baseline_controller_snapshot()
        with self.assertRaises(AuthorizationError):
            prepare_baseline_draft(
                self.viewer_sess,
                baseline_id="BL-02",
                asset_id="PLC-101",
                version="1.0.0",
                effective_from="2026-01-01T00:00:00+00:00",
                effective_until="2027-01-01T00:00:00+00:00",
                documents=[],
                snapshot=snap,
            )

        # Account lockout after repeated failed attempts
        for _ in range(AuthManager.MAX_FAILED_ATTEMPTS):
            with self.assertRaises(AuthorizationError):
                self.auth.authenticate("viewer", "WrongPassword-999!")
        with self.assertRaises(AuthorizationError) as ctx:
            self.auth.authenticate("viewer", "Strong-Auditor-000!")
        self.assertIn("locked", str(ctx.exception).lower())

    def test_baseline_classifications_and_tamper_detection(self) -> None:
        snap = baseline_controller_snapshot()
        draft = prepare_baseline_draft(
            self.prep_sess,
            baseline_id="BL-03",
            asset_id="PLC-101",
            version="1.4.0",
            effective_from="2026-11-01T00:00:00+00:00",
            effective_until="2026-12-01T00:00:00+00:00",
            documents=[BaselineDocumentRef("D1", "program", snap.program_hash, "EWS-01")],
            snapshot=snap,
        )
        manifest = approve_and_sign_baseline(
            self.appr_sess,
            draft,
            approval_reference="ECR-2026-55",
            keyring=self.keyring,
            key_id="KEY-BL",
        )
        self.assertTrue(verify_baseline_manifest(manifest, self.keyring, at_time="2026-11-19T10:00:00+00:00"))

        # Tampered manifest fails signature/hash verification
        tampered = replace(manifest, expected_firmware="9.9.9")
        with self.assertRaises(IntegrityError):
            verify_baseline_manifest(tampered, self.keyring, at_time="2026-11-19T10:00:00+00:00")

        # EXPECTED classification includes safety disclaimer
        res_ok = compare_snapshot_to_baseline(
            replace(snap, captured_at="2026-11-19T10:00:00+00:00"),
            manifest,
            self.keyring,
            comparison_id="C-OK",
        )
        self.assertEqual(res_ok.classification, BaselineClassification.EXPECTED)
        self.assertIn("does not constitute proof of physical process safety", res_ok.safety_disclaimer)

        # UNSUPPORTED format classification
        res_unsup = compare_snapshot_to_baseline(
            replace(snap, format_type="proprietary_binary_blob"),
            manifest,
            self.keyring,
            comparison_id="C-UNSUP",
        )
        self.assertEqual(res_unsup.classification, BaselineClassification.UNSUPPORTED)

        # INCONCLUSIVE when baseline missing or expired
        res_inc = compare_snapshot_to_baseline(snap, None, self.keyring, comparison_id="C-NONE")
        self.assertEqual(res_inc.classification, BaselineClassification.INCONCLUSIVE)

        res_exp = compare_snapshot_to_baseline(
            replace(snap, captured_at="2027-05-01T00:00:00+00:00"),
            manifest,
            self.keyring,
            comparison_id="C-EXP",
        )
        self.assertEqual(res_exp.classification, BaselineClassification.INCONCLUSIVE)


if __name__ == "__main__":
    unittest.main()
