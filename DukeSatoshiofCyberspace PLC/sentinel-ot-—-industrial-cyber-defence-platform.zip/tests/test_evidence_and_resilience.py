"""Tests for evidence integrity, audit-chain tamper detection, and bounded telemetry resilience."""

from __future__ import annotations

import os
import tempfile
import unittest
import zipfile
from pathlib import Path

from sentinel_evidence import EvidenceVault, verify_evidence_package
from sentinel_integrity import KeyRing, SigningKey
from sentinel_telemetry import TelemetryBuffer
from sentinel_types import IntegrityError, QualityFlag, ResourceLimits


class TestEvidenceAndResilience(unittest.TestCase):
    def test_evidence_vault_immutability_and_package_tamper_detection(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            vault = EvidenceVault(root / "vault")
            kr = KeyRing()
            kr.add_key(SigningKey.generate("EVD-KEY", "evidence"))

            raw_payload = b'{"asset":"PLC-101","register":10}'
            rec = vault.preserve_bytes(
                evidence_id="EV-01",
                artifact_type="controller_snapshot",
                original_filename="plc101.json",
                raw_bytes=raw_payload,
                collection_method="offline_usb_readonly",
                custodian="collector_01",
                source_timestamps=["2026-11-19T10:00:00+00:00"],
            )
            self.assertTrue(vault.verify_record("EV-01"))

            # Write-once enforcement refuses overwriting same evidence_id with different bytes
            with self.assertRaises(IntegrityError):
                vault.preserve_bytes(
                    evidence_id="EV-01",
                    artifact_type="controller_snapshot",
                    original_filename="plc101.json",
                    raw_bytes=b'{"asset":"PLC-101","register":99}',
                    collection_method="offline_usb_readonly",
                    custodian="collector_01",
                    source_timestamps=["2026-11-19T10:00:00+00:00"],
                )

            pkg_zip = root / "pkg.zip"
            vault.export_evidence_package(
                output_zip=pkg_zip,
                evidence_ids=["EV-01"],
                case_payload={"case_id": "CASE-1"},
                keyring=kr,
                key_id="EVD-KEY",
                custodian="analyst_01",
            )
            res = verify_evidence_package(pkg_zip, kr)
            self.assertTrue(res["verified"])

            # Tamper with file inside exported zip and verify detection
            tampered_zip = root / "tampered_pkg.zip"
            with zipfile.ZipFile(pkg_zip, "r") as zin, zipfile.ZipFile(tampered_zip, "w") as zout:
                for info in zin.infolist():
                    data = zin.read(info.filename)
                    if info.filename == "case/incident_case.json":
                        data = b'{"case_id":"CASE-TAMPERED"}'
                    zout.writestr(info.filename, data)
            with self.assertRaises(IntegrityError):
                verify_evidence_package(tampered_zip, kr)

            # Tamper with raw blob on disk
            blob_path = root / "vault" / rec.vault_path
            os.chmod(blob_path, 0o644)
            blob_path.write_bytes(b"corrupted")
            with self.assertRaises(IntegrityError):
                vault.verify_record("EV-01")

    def test_telemetry_deduplication_and_bounded_drop_surfacing(self) -> None:
        buf = TelemetryBuffer(limits=ResourceLimits(max_telemetry_queue_size=3, max_events_per_batch=10))
        batch = [
            {
                "observation_id": f"O-{i}",
                "asset_id": "TK-101",
                "tag": "tank_level_pct",
                "value": 40.0 + i,
                "unit": "%",
                "quality": QualityFlag.GOOD.value,
                "source_timestamp": f"2026-11-19T10:00:0{i}+00:00",
                "source_identity": "HISTORIAN_RO",
                "sequence_no": i,
            }
            for i in range(5)
        ]
        # Duplicate the first observation
        batch.append(dict(batch[0]))

        metrics = buf.ingest_raw_batch(batch)
        self.assertEqual(metrics.accepted_count, 3)
        self.assertEqual(metrics.duplicate_count, 1)
        self.assertEqual(metrics.dropped_count, 2)
        self.assertTrue(metrics.data_loss_detected)
        self.assertEqual(metrics.queue_depth, 3)


if __name__ == "__main__":
    unittest.main()
