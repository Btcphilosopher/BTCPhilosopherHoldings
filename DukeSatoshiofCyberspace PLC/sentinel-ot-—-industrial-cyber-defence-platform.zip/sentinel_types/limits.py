"""Bounded resource limits and retention configuration for Sentinel OT."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ResourceLimits:
    """Hard bounds protecting parsers, queues, and analysis pipelines."""

    max_input_bytes: int = 16 * 1024 * 1024  # 16 MiB per file/payload
    max_archive_uncompressed_bytes: int = 64 * 1024 * 1024  # 64 MiB total
    max_archive_files: int = 512
    max_archive_compression_ratio: float = 25.0
    max_json_depth: int = 32
    max_telemetry_queue_size: int = 10_000
    max_events_per_batch: int = 5_000
    max_findings_per_case: int = 1_000
    max_retries: int = 3
    retention_days: int = 90

    def validate(self) -> None:
        if self.max_input_bytes <= 0 or self.max_archive_uncompressed_bytes <= 0:
            raise ValueError("Byte limits must be positive integers.")
        if self.max_archive_files <= 0 or self.max_json_depth <= 0:
            raise ValueError("Count and depth limits must be positive integers.")
        if self.max_telemetry_queue_size <= 0 or self.max_events_per_batch <= 0:
            raise ValueError("Queue and batch limits must be positive integers.")
        if self.max_retries < 0 or self.retention_days <= 0:
            raise ValueError("Invalid retry or retention configuration.")
