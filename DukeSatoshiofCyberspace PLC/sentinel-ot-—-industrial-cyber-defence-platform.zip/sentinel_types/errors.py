"""Structured error hierarchy for Sentinel OT."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ErrorContext:
    """Bounded contextual metadata attached to structured errors."""

    component: str
    operation: str
    details: dict[str, Any] = field(default_factory=dict)


class SentinelError(Exception):
    """Base structured exception for all Sentinel OT subsystems."""

    code: str = "SENTINEL_ERROR"

    def __init__(
        self,
        message: str,
        *,
        code: str | None = None,
        component: str = "sentinel",
        operation: str = "unknown",
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        if code is not None:
            self.code = code
        self.message = message
        self.context = ErrorContext(
            component=component,
            operation=operation,
            details=details or {},
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "component": self.context.component,
            "operation": self.context.operation,
            "details": self.context.details,
        }


class ValidationError(SentinelError):
    code = "VALIDATION_ERROR"


class SecurityBoundaryError(SentinelError):
    code = "SECURITY_BOUNDARY_ERROR"


class IntegrityError(SentinelError):
    code = "INTEGRITY_ERROR"


class ResourceLimitError(SentinelError):
    code = "RESOURCE_LIMIT_ERROR"


class AdapterReadOnlyError(SecurityBoundaryError):
    code = "ADAPTER_READ_ONLY_VIOLATION"


class AuthorizationError(SecurityBoundaryError):
    code = "AUTHORIZATION_ERROR"


class PersistenceError(SentinelError):
    code = "PERSISTENCE_ERROR"


class RecoveryError(SentinelError):
    code = "RECOVERY_ERROR"
