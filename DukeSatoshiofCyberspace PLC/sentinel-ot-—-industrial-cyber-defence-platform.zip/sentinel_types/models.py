"""Core typed domain models and versioned schemas for Sentinel OT."""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any

SCHEMA_VERSION = "1.0.0"
TOOL_NAME = "sentinel-ot"
TOOL_VERSION = "1.0.0"


class Role(str, Enum):
    COLLECTOR = "collector"
    BASELINE_PREPARER = "baseline_preparer"
    BASELINE_APPROVER = "baseline_approver"
    ANALYST = "analyst"
    CASE_APPROVER = "case_approver"
    AUDITOR = "auditor"
    ADMIN = "admin"


class AssetKind(str, Enum):
    PLC = "plc"
    RTU = "rtu"
    SENSOR = "sensor"
    ACTUATOR = "actuator"
    EWS = "ews"
    HMI = "hmi"
    HISTORIAN = "historian"


class Criticality(str, Enum):
    SAFETY_CRITICAL = "safety_critical"
    PROCESS_CRITICAL = "process_critical"
    MONITORING = "monitoring"


class QualityFlag(str, Enum):
    GOOD = "GOOD"
    UNCERTAIN = "UNCERTAIN"
    BAD = "BAD"
    STALE = "STALE"
    SIMULATED = "SIMULATED"


class BaselineClassification(str, Enum):
    EXPECTED = "expected"
    UNAUTHORISED = "unauthorised"
    UNSUPPORTED = "unsupported"
    INCONCLUSIVE = "inconclusive"


class FindingCategory(str, Enum):
    UNEXPECTED_PROGRAM_CHANGE = "unexpected_program_change"
    UNEXPLAINED_STATE_TRANSITION = "unexplained_state_transition"
    STALE_OR_MISSING_OBSERVATION = "stale_or_missing_observation"
    CONTRADICTORY_MEASUREMENTS = "contradictory_measurements"
    COMMAND_OBSERVATION_MISMATCH = "command_observation_mismatch"
    MISSING_MAINTENANCE_AUTH = "missing_maintenance_authorisation"


class HypothesisClass(str, Enum):
    LEGITIMATE_MAINTENANCE = "legitimate_maintenance"
    EQUIPMENT_OR_SENSOR_FAULT = "equipment_or_sensor_fault"
    TELEMETRY_LOSS_OR_DELAY = "telemetry_loss_or_delay"
    POSSIBLE_UNAUTHORISED_ACTIVITY = "possible_unauthorised_activity"
    INCONCLUSIVE = "inconclusive"


class Severity(str, Enum):
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class CaseStatus(str, Enum):
    OPEN = "open"
    UNDER_REVIEW = "under_review"
    APPROVED_FOR_OPERATIONAL_HANDOFF = "approved_for_operational_handoff"
    CLOSED = "closed"


@dataclass(frozen=True)
class AssetRecord:
    asset_id: str
    name: str
    kind: AssetKind
    zone: str
    criticality: Criticality
    vendor: str
    model: str
    firmware_version: str
    expected_protocol: str
    connected_assets: tuple[str, ...] = ()
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["kind"] = self.kind.value
        d["criticality"] = self.criticality.value
        d["connected_assets"] = list(self.connected_assets)
        return d


@dataclass(frozen=True)
class ControllerSnapshot:
    snapshot_id: str
    asset_id: str
    captured_at: str
    source_identity: str
    collection_method: str
    firmware_version: str
    program_version: str
    program_hash: str
    logic_blocks: dict[str, str]
    setpoints: dict[str, float | int | bool | str]
    io_mappings: dict[str, str]
    operating_mode: str
    format_type: str = "sentinel_plc_json_v1"
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EWSAuditRecord:
    event_id: str
    timestamp: str
    workstation_id: str
    operator_id: str
    action: str
    target_asset_id: str
    session_id: str
    outcome: str
    artifact_hash: str | None = None
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class MaintenanceRecord:
    work_order_id: str
    asset_id: str
    window_start: str
    window_end: str
    approved_by: str
    executed_by: str
    scope: str
    expected_program_hash: str | None = None
    expected_setpoints: dict[str, float | int | bool | str] = field(default_factory=dict)
    status: str = "approved"
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class TelemetryObservation:
    observation_id: str
    asset_id: str
    tag: str
    value: float | int | bool | str
    unit: str
    quality: QualityFlag
    source_timestamp: str
    receipt_timestamp: str
    source_identity: str
    sequence_no: int = 0
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["quality"] = self.quality.value
        return d


@dataclass(frozen=True)
class StructuralDiffItem:
    path: str
    change_type: str  # "added" | "removed" | "modified"
    baseline_value: Any
    observed_value: Any

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class BaselineDocumentRef:
    doc_id: str
    doc_type: str
    sha256: str
    provenance: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class BaselineManifest:
    baseline_id: str
    asset_id: str
    version: str
    effective_from: str
    effective_until: str
    prepared_by: str
    approved_by: str
    approval_reference: str
    documents: tuple[BaselineDocumentRef, ...]
    expected_firmware: str
    expected_program_version: str
    expected_program_hash: str
    expected_logic_blocks: dict[str, str]
    expected_setpoints: dict[str, float | int | bool | str]
    expected_io_mappings: dict[str, str]
    manifest_sha256: str
    signature: str
    signer_key_id: str
    created_at: str
    safety_disclaimer: str = (
        "Baseline agreement confirms correspondence with an approved configuration snapshot "
        "only; it does not constitute proof of physical process safety or absence of risk."
    )
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["documents"] = [doc.to_dict() for doc in self.documents]
        return d


@dataclass(frozen=True)
class BaselineComparisonResult:
    comparison_id: str
    baseline_id: str
    snapshot_id: str
    asset_id: str
    classification: BaselineClassification
    diffs: tuple[StructuralDiffItem, ...]
    rationale: str
    safety_disclaimer: str
    compared_at: str
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["classification"] = self.classification.value
        d["diffs"] = [x.to_dict() for x in self.diffs]
        return d


@dataclass(frozen=True)
class EvidenceRecord:
    evidence_id: str
    artifact_type: str
    original_filename: str
    vault_path: str
    sha256: str
    sha512: str
    byte_size: int
    collection_method: str
    receipt_timestamp: str
    source_timestamps: tuple[str, ...]
    custodian: str
    tool_name: str
    tool_version: str
    processing_history: tuple[str, ...]
    provenance_caveat: str
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["source_timestamps"] = list(self.source_timestamps)
        d["processing_history"] = list(self.processing_history)
        return d


@dataclass(frozen=True)
class DetectionFinding:
    finding_id: str
    category: FindingCategory
    hypothesis: HypothesisClass
    severity: Severity
    asset_id: str
    title: str
    summary: str
    detected_at: str
    supporting_evidence_ids: tuple[str, ...]
    telemetry_extracts: tuple[dict[str, Any], ...]
    alternative_explanations: tuple[str, ...]
    uncertainty_notes: str
    baseline_diff_refs: tuple[str, ...] = ()
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["category"] = self.category.value
        d["hypothesis"] = self.hypothesis.value
        d["severity"] = self.severity.value
        d["supporting_evidence_ids"] = list(self.supporting_evidence_ids)
        d["telemetry_extracts"] = list(self.telemetry_extracts)
        d["alternative_explanations"] = list(self.alternative_explanations)
        d["baseline_diff_refs"] = list(self.baseline_diff_refs)
        return d


@dataclass(frozen=True)
class TimelineEntry:
    timestamp: str
    source: str
    event_type: str
    description: str
    evidence_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ChecklistItem:
    item_id: str
    step: str
    owner_role: str
    completed: bool = False
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class CaseApprovalRecord:
    approved_by: str
    role: str
    approved_at: str
    decision: str
    rationale: str
    operational_handoff_ref: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class IncidentCase:
    case_id: str
    title: str
    created_at: str
    status: CaseStatus
    asset_ids: tuple[str, ...]
    findings: tuple[DetectionFinding, ...]
    timeline: tuple[TimelineEntry, ...]
    baseline_comparisons: tuple[BaselineComparisonResult, ...]
    telemetry_extracts: tuple[dict[str, Any], ...]
    unresolved_questions: tuple[str, ...]
    response_checklist: tuple[ChecklistItem, ...]
    evidence_ids: tuple[str, ...]
    approvals: tuple[CaseApprovalRecord, ...] = ()
    containment_guardrail: str = (
        "Automated controller isolation, machinery stop, and configuration changes are strictly "
        "disabled. Any physical or network action requires an authorised operational process "
        "outside this detection engine."
    )
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["status"] = self.status.value
        d["asset_ids"] = list(self.asset_ids)
        d["findings"] = [f.to_dict() for f in self.findings]
        d["timeline"] = [t.to_dict() for t in self.timeline]
        d["baseline_comparisons"] = [b.to_dict() for b in self.baseline_comparisons]
        d["telemetry_extracts"] = list(self.telemetry_extracts)
        d["unresolved_questions"] = list(self.unresolved_questions)
        d["response_checklist"] = [c.to_dict() for c in self.response_checklist]
        d["evidence_ids"] = list(self.evidence_ids)
        d["approvals"] = [a.to_dict() for a in self.approvals]
        return d
