"""Command-line interface for Sentinel OT."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from sentinel_adapters import OfflineBundleAdapter
from sentinel_cli.pipeline import SentinelWorkspace, run_verification_laboratory
from sentinel_integrity import create_encrypted_backup, restore_encrypted_backup
from sentinel_simulator import SCENARIO_NAMES, generate_scenario_bundle


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="sentinel-ot",
        description="DUKE SATOSHI OF CYBERSPACE — SENTINEL OT Defensive Platform CLI",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    lab = sub.add_parser("lab", help="Run synthetic plant verification laboratory")
    lab_sub = lab.add_subparsers(dest="lab_cmd", required=True)
    run_all = lab_sub.add_parser("run-all", help="Execute all labelled verification scenarios")
    run_all.add_argument("--work-dir", type=Path, default=Path(".sentinel_lab_work"))
    run_all.add_argument("--output", type=Path, default=Path("verification_results.json"))

    gen = lab_sub.add_parser("export-datasets", help="Write deterministic synthetic datasets to disk")
    gen.add_argument("--out-dir", type=Path, default=Path("datasets"))

    run_scn = lab_sub.add_parser("run-scenario", help="Run a single labelled scenario")
    run_scn.add_argument("scenario", choices=SCENARIO_NAMES)
    run_scn.add_argument("--work-dir", type=Path, default=Path(".sentinel_lab_work"))
    run_scn.add_argument("--simulate-interrupt", action="store_true")
    run_scn.add_argument("--resume", action="store_true")

    analyze = sub.add_parser("analyze-bundle", help="Analyze an offline export directory")
    analyze.add_argument("bundle_dir", type=Path)
    analyze.add_argument("--run-id", required=True)
    analyze.add_argument("--work-dir", type=Path, default=Path(".sentinel_work"))
    analyze.add_argument("--simulate-interrupt", action="store_true")
    analyze.add_argument("--resume", action="store_true")

    bak = sub.add_parser("backup", help="Create or restore encrypted backups")
    bak_sub = bak.add_subparsers(dest="bak_cmd", required=True)
    bak_create = bak_sub.add_parser("create")
    bak_create.add_argument("source_dir", type=Path)
    bak_create.add_argument("backup_file", type=Path)
    bak_create.add_argument("--passphrase", required=True)
    bak_restore = bak_sub.add_parser("restore")
    bak_restore.add_argument("backup_file", type=Path)
    bak_restore.add_argument("target_dir", type=Path)
    bak_restore.add_argument("--passphrase", required=True)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "lab":
        if args.lab_cmd == "run-all":
            report = run_verification_laboratory(args.work_dir, output_json=args.output)
            print(json.dumps(report, indent=2))
            return 0
        if args.lab_cmd == "export-datasets":
            args.out_dir.mkdir(parents=True, exist_ok=True)
            for scenario in SCENARIO_NAMES:
                bundle = generate_scenario_bundle(scenario)
                scn_dir = args.out_dir / scenario
                scn_dir.mkdir(parents=True, exist_ok=True)
                for key in ("inventory", "baseline_snapshot", "snapshot", "telemetry", "ews_audit", "maintenance", "ground_truth"):
                    (scn_dir / f"{key}.json").write_text(
                        json.dumps(bundle[key], indent=2, sort_keys=True) + "\n",
                        encoding="utf-8",
                    )
            print(json.dumps({"exported_scenarios": list(SCENARIO_NAMES), "out_dir": str(args.out_dir)}, indent=2))
            return 0
        if args.lab_cmd == "run-scenario":
            ws = SentinelWorkspace(args.work_dir)
            tokens = ws.bootstrap_demo_identities_and_keys()
            baseline = ws.create_signed_lab_baseline(tokens["preparer_01"], tokens["approver_01"])
            run_id = f"SCN-{args.scenario.upper()}"
            if args.resume:
                res = ws.resume_interrupted_analysis(
                    run_id=run_id,
                    baseline=baseline,
                    analyst_token=tokens["analyst_01"],
                )
            else:
                bundle = generate_scenario_bundle(args.scenario)
                res = ws.run_bundle_analysis(
                    run_id=run_id,
                    bundle=bundle,
                    baseline=baseline,
                    custodian="collector_01",
                    analyst_token=tokens["analyst_01"],
                    simulate_interrupt=args.simulate_interrupt,
                )
            print(json.dumps(res, indent=2))
            return 0

    if args.command == "analyze-bundle":
        ws = SentinelWorkspace(args.work_dir)
        tokens = ws.bootstrap_demo_identities_and_keys()
        baseline = ws.create_signed_lab_baseline(tokens["preparer_01"], tokens["approver_01"])
        if args.resume:
            res = ws.resume_interrupted_analysis(
                run_id=args.run_id,
                baseline=baseline,
                analyst_token=tokens["analyst_01"],
            )
        else:
            adapter = OfflineBundleAdapter("OFFLINE-DIR-01", args.bundle_dir)
            collected = adapter.collect()
            bundle = {
                "scenario": args.run_id,
                "inventory": collected["inventory.json"],
                "snapshot": collected["snapshot.json"],
                "telemetry": collected["telemetry.json"],
                "ews_audit": collected.get("ews_audit.json", {"records": []}),
                "maintenance": collected.get("maintenance.json", {"records": []}),
            }
            res = ws.run_bundle_analysis(
                run_id=args.run_id,
                bundle=bundle,
                baseline=baseline,
                custodian="collector_01",
                analyst_token=tokens["analyst_01"],
                simulate_interrupt=args.simulate_interrupt,
            )
        print(json.dumps(res, indent=2))
        return 0

    if args.command == "backup":
        if args.bak_cmd == "create":
            res = create_encrypted_backup(args.source_dir, args.backup_file, args.passphrase)
            print(json.dumps(res, indent=2))
            return 0
        if args.bak_cmd == "restore":
            res = restore_encrypted_backup(args.backup_file, args.target_dir, args.passphrase)
            print(json.dumps(res, indent=2))
            return 0

    return 1


if __name__ == "__main__":
    sys.exit(main())
