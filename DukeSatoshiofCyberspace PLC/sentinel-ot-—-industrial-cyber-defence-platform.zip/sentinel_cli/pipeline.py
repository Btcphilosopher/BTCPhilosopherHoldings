"""End-to-end defensive analysis pipeline, checkpoint recovery, and verification lab runner."""

from __future__ import annotations

import json
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

from sentinel_adapters import SyntheticLabTapAdapter
from sentinel_baselines import (
    approve_and_sign_baseline,
    compare_snapshot_to_baseline,
    prepare_baseline_draft,
)
from sentinel_cases import (
    AnalysisCheckpointStore,
    approve_incident_case,
    build_incident_case,
)
from sentinel_detection import DetectionConfig, correlate_process_evidence
from sentinel_evidence import EvidenceVault, verify_evidence_package
from sentinel_integrity import (
    AuthManager,
    KeyRing,
    RedactedLogger,
    SigningKey,
    canonical_json_bytes,
    sha256_bytes,
    utc_now_iso,
)
from sentinel_inventory import AssetRegistry
from sentinel_simulator import SCENARIO_NAMES, baseline_controller_snapshot, generate_scenario_bundle
from sentinel_telemetry import TelemetryBuffer
from sentinel_types import (
    BaselineDocumentRef,
    BaselineManifest,
    ControllerSnapshot,
    EWSAuditRecord,
    HypothesisClass,
    IncidentCase,
    MaintenanceRecord,
    RecoveryError,
    ResourceLimits,
    Role,
    SCHEMA_VERSION,
    Severity,
    TOOL_NAME,
    TOOL_VERSION,
)


def parse_snapshot_dict(raw: dict[str, Any]) -> ControllerSnapshot:
    return ControllerSnapshot(
        snapshot_id=str(raw["snapshot_id"]),
        asset_id=str(raw["asset_id"]),
        captured_at=str(raw["captured_at"]),
        source_identity=str(raw["source_identity"]),
        collection_method=str(raw["collection_method"]),
        firmware_version=str(raw["firmware_version"]),
        program_version=str(raw["program_version"]),
        program_hash=str(raw["program_hash"]),
        logic_blocks=dict(raw["logic_blocks"]),
        setpoints=dict(raw["setpoints"]),
        io_mappings=dict(raw["io_mappings"]),
        operating_mode=str(raw["operating_mode"]),
        format_type=str(raw.get("format_type", "sentinel_plc_json_v1")),
        schema_version=str(raw.get("schema_version", SCHEMA_VERSION)),
    )


def parse_ews_list(raw: dict[str, Any]) -> list[EWSAuditRecord]:
    out: list[EWSAuditRecord] = []
    for item in raw.get("records", []):
        out.append(
            EWSAuditRecord(
                event_id=str(item["event_id"]),
                timestamp=str(item["timestamp"]),
                workstation_id=str(item["workstation_id"]),
                operator_id=str(item["operator_id"]),
                action=str(item["action"]),
                target_asset_id=str(item["target_asset_id"]),
                session_id=str(item["session_id"]),
                outcome=str(item["outcome"]),
                artifact_hash=item.get("artifact_hash"),
                schema_version=str(item.get("schema_version", SCHEMA_VERSION)),
            )
        )
    return out


def parse_maintenance_list(raw: dict[str, Any]) -> list[MaintenanceRecord]:
    out: list[MaintenanceRecord] = []
    for item in raw.get("records", []):
        out.append(
            MaintenanceRecord(
                work_order_id=str(item["work_order_id"]),
                asset_id=str(item["asset_id"]),
                window_start=str(item["window_start"]),
                window_end=str(item["window_end"]),
                approved_by=str(item["approved_by"]),
                executed_by=str(item["executed_by"]),
                scope=str(item["scope"]),
                expected_program_hash=item.get("expected_program_hash"),
                expected_setpoints=dict(item.get("expected_setpoints", {})),
                status=str(item.get("status", "approved")),
                schema_version=str(item.get("schema_version", SCHEMA_VERSION)),
            )
        )
    return out


class SentinelWorkspace:
    """Self-contained workspace managing keys, vault, checkpoints, and analytical runs."""

    def __init__(self, root_dir: Path, *, limits: ResourceLimits | None = None) -> None:
        self.root_dir = root_dir.resolve()
        self.limits = limits or ResourceLimits()
        self.vault = EvidenceVault(self.root_dir / "vault", limits=self.limits)
        self.checkpoints = AnalysisCheckpointStore(self.root_dir / "state" / "sentinel.db")
        self.logger = RedactedLogger(self.root_dir / "logs" / "sentinel_audit.jsonl")
        self.keyring = KeyRing()
        self.auth = AuthManager()

    def bootstrap_demo_identities_and_keys(self) -> dict[str, str]:
        """Provision distinct RBAC accounts and signing keys for offline/lab verification."""
        self.keyring.add_key(SigningKey.generate("KEY-BASELINE-01", "baseline"))
        self.keyring.add_key(SigningKey.generate("KEY-EVIDENCE-01", "evidence"))
        self.keyring.add_key(SigningKey.generate("KEY-UPDATE-01", "update"))

        accounts = [
            ("collector_01", "Collector-Passphrase-901!", {Role.COLLECTOR}),
            ("preparer_01", "Preparer-Passphrase-902!", {Role.BASELINE_PREPARER}),
            ("approver_01", "Approver-Passphrase-903!", {Role.BASELINE_APPROVER}),
            ("analyst_01", "Analyst-Passphrase-904!", {Role.ANALYST}),
            ("case_approver_01", "CaseApprover-Passphrase-905!", {Role.CASE_APPROVER}),
            ("auditor_01", "Auditor-Passphrase-906!", {Role.AUDITOR}),
        ]
        tokens: dict[str, str] = {}
        for uid, pw, roles in accounts:
            self.auth.register_user(uid, pw, roles)
            tokens[uid] = self.auth.authenticate(uid, pw).token
        return tokens

    def create_signed_lab_baseline(self, preparer_token: str, approver_token: str) -> BaselineManifest:
        prep_sess = self.auth.authorize(preparer_token, {Role.BASELINE_PREPARER})
        appr_sess = self.auth.authorize(approver_token, {Role.BASELINE_APPROVER})
        base_snap = baseline_controller_snapshot()
        doc_bytes = canonical_json_bytes(base_snap.to_dict())
        draft = prepare_baseline_draft(
            prep_sess,
            baseline_id="BL-PLC101-2026-11",
            asset_id="PLC-101",
            version="1.4.0",
            effective_from="2026-11-01T00:00:00+00:00",
            effective_until="2027-01-01T00:00:00+00:00",
            documents=[
                BaselineDocumentRef(
                    doc_id="DOC-PLC101-L5",
                    doc_type="controller_program_export",
                    sha256=sha256_bytes(doc_bytes),
                    provenance="Air-gapped EWS-01 golden export verified at FAT",
                )
            ],
            snapshot=base_snap,
        )
        manifest = approve_and_sign_baseline(
            appr_sess,
            draft,
            approval_reference="ECR-2026-0088",
            keyring=self.keyring,
            key_id="KEY-BASELINE-01",
        )
        self.logger.log(
            "INFO",
            "sentinel_baselines",
            "baseline_signed",
            baseline_id=manifest.baseline_id,
            prepared_by=manifest.prepared_by,
            approved_by=manifest.approved_by,
        )
        return manifest

    def run_bundle_analysis(
        self,
        *,
        run_id: str,
        bundle: dict[str, Any],
        baseline: BaselineManifest,
        custodian: str,
        analyst_token: str,
        simulate_interrupt: bool = False,
        detection_config: DetectionConfig | None = None,
    ) -> dict[str, Any]:
        """Execute bounded, checkpointed analysis with optional simulated crash for recovery testing."""
        self.auth.authorize(analyst_token, {Role.ANALYST})

        # Stage 1: Preserve unmodified raw artifacts into write-once EvidenceVault
        evidence_ids: list[str] = []
        for art_type, key in (
            ("asset_inventory", "inventory"),
            ("controller_snapshot", "snapshot"),
            ("telemetry_batch", "telemetry"),
            ("ews_audit_log", "ews_audit"),
            ("maintenance_records", "maintenance"),
        ):
            raw_bytes = canonical_json_bytes(bundle[key])
            eid = f"EVD-{run_id}-{art_type[:4].upper()}"
            rec = self.vault.preserve_bytes(
                evidence_id=eid,
                artifact_type=art_type,
                original_filename=f"{key}.json",
                raw_bytes=raw_bytes,
                collection_method="read_only_authorised_import",
                custodian=custodian,
                source_timestamps=[str(bundle["snapshot"].get("captured_at", utc_now_iso()))],
            )
            evidence_ids.append(rec.evidence_id)

        state_payload = {
            "bundle": bundle,
            "baseline": baseline.to_dict(),
            "evidence_ids": evidence_ids,
            "custodian": custodian,
        }
        self.checkpoints.save_checkpoint(run_id, "INGESTED", state_payload, interrupted=False)

        if simulate_interrupt:
            self.checkpoints.save_checkpoint(run_id, "INTERRUPTED_AFTER_INGEST", state_payload, interrupted=True)
            self.logger.log("WARN", "sentinel_cases", "analysis_interrupted", run_id=run_id, stage="INGESTED")
            return {"status": "interrupted", "run_id": run_id, "checkpoint_stage": "INTERRUPTED_AFTER_INGEST"}

        return self._finish_analysis_from_state(
            run_id=run_id,
            state_payload=state_payload,
            baseline=baseline,
            detection_config=detection_config,
        )

    def resume_interrupted_analysis(
        self,
        *,
        run_id: str,
        baseline: BaselineManifest,
        analyst_token: str,
        detection_config: DetectionConfig | None = None,
    ) -> dict[str, Any]:
        """Resume an interrupted analysis cleanly from the last SQLite WAL checkpoint."""
        self.auth.authorize(analyst_token, {Role.ANALYST})
        ckpt = self.checkpoints.load_checkpoint(run_id)
        if ckpt is None:
            raise RecoveryError(
                f"No checkpoint found for run_id '{run_id}'.",
                component="sentinel_cli",
                operation="resume_interrupted_analysis",
            )
        self.logger.log(
            "INFO",
            "sentinel_cases",
            "analysis_resumed",
            run_id=run_id,
            previous_stage=ckpt["stage"],
        )
        return self._finish_analysis_from_state(
            run_id=run_id,
            state_payload=ckpt["state"],
            baseline=baseline,
            detection_config=detection_config,
        )

    def _finish_analysis_from_state(
        self,
        *,
        run_id: str,
        state_payload: dict[str, Any],
        baseline: BaselineManifest,
        detection_config: DetectionConfig | None = None,
    ) -> dict[str, Any]:
        bundle = state_payload["bundle"]
        evidence_ids = list(state_payload["evidence_ids"])
        custodian = str(state_payload["custodian"])

        AssetRegistry.from_dict_list(bundle["inventory"])
        snapshot = parse_snapshot_dict(bundle["snapshot"])
        ews_records = parse_ews_list(bundle["ews_audit"])
        maint_records = parse_maintenance_list(bundle["maintenance"])

        telemetry_buf = TelemetryBuffer(limits=self.limits)
        ingest_metrics = telemetry_buf.ingest_raw_batch(
            bundle["telemetry"].get("observations", []),
            default_source_identity="authorised_offline_historian",
        )
        observations = telemetry_buf.drain()

        comp = compare_snapshot_to_baseline(
            snapshot,
            baseline,
            self.keyring,
            comparison_id=f"CMP-{run_id}-001",
        )
        self.checkpoints.save_checkpoint(run_id, "BASELINES_VERIFIED", state_payload, interrupted=False)

        findings = correlate_process_evidence(
            run_id=run_id,
            baseline_comparisons=[comp],
            snapshots=[snapshot],
            ews_records=ews_records,
            maintenance_records=maint_records,
            telemetry=observations,
            evidence_ids=evidence_ids,
            config=detection_config,
        )
        self.checkpoints.save_checkpoint(run_id, "CORRELATED", state_payload, interrupted=False)

        case = build_incident_case(
            case_id=f"CASE-{run_id}",
            title=f"Sentinel OT Investigation — {bundle.get('scenario', run_id)} ({snapshot.asset_id})",
            findings=findings,
            baseline_comparisons=[comp],
            snapshots=[snapshot],
            ews_records=ews_records,
            maintenance_records=maint_records,
            telemetry=observations,
            evidence_ids=evidence_ids,
            dropped_telemetry_count=ingest_metrics.dropped_count,
        )
        self.checkpoints.save_case(run_id, case)
        self.checkpoints.save_checkpoint(run_id, "COMPLETED", state_payload, interrupted=False)

        package_zip = self.root_dir / "exports" / f"{case.case_id}.sotpkg.zip"
        package_manifest = self.vault.export_evidence_package(
            output_zip=package_zip,
            evidence_ids=evidence_ids,
            case_payload=case.to_dict(),
            keyring=self.keyring,
            key_id="KEY-EVIDENCE-01",
            custodian=custodian,
        )
        verification = verify_evidence_package(package_zip, self.keyring, limits=self.limits)

        return {
            "status": "completed",
            "run_id": run_id,
            "case": case.to_dict(),
            "ingestion_metrics": asdict(ingest_metrics),
            "package_zip": str(package_zip),
            "package_manifest": package_manifest,
            "package_verification": verification,
        }


def run_verification_laboratory(work_dir: Path, output_json: Path | None = None) -> dict[str, Any]:
    """Run all labelled synthetic plant scenarios and collect accuracy, latency, and security metrics."""
    ws = SentinelWorkspace(work_dir)
    tokens = ws.bootstrap_demo_identities_and_keys()
    baseline = ws.create_signed_lab_baseline(tokens["preparer_01"], tokens["approver_01"])

    scenario_results: list[dict[str, Any]] = []
    true_positives = 0
    false_positives = 0
    true_negatives = 0
    false_negatives = 0

    for scenario in SCENARIO_NAMES:
        bundle = generate_scenario_bundle(scenario)
        adapter = SyntheticLabTapAdapter(f"TAP-{scenario.upper()}", bundle)
        collected = adapter.collect()

        t_start = time.perf_counter()
        result = ws.run_bundle_analysis(
            run_id=f"LAB-{scenario.upper()}",
            bundle={**bundle, **collected},
            baseline=baseline,
            custodian="collector_01",
            analyst_token=tokens["analyst_01"],
        )
        latency_ms = round((time.perf_counter() - t_start) * 1000.0, 3)

        case = result["case"]
        findings = case["findings"]
        observed_cats = sorted({f["category"] for f in findings})
        actionable_alerts = [
            f for f in findings
            if f["severity"] in (Severity.MEDIUM.value, Severity.HIGH.value, Severity.CRITICAL.value)
            and f["hypothesis"] != HypothesisClass.LEGITIMATE_MAINTENANCE.value
        ]
        alerted = len(actionable_alerts) > 0
        gt = bundle["ground_truth"]
        should_alert = bool(gt["should_alert"])

        if should_alert and alerted:
            true_positives += 1
        elif should_alert and not alerted:
            false_negatives += 1
        elif not should_alert and alerted:
            false_positives += 1
        else:
            true_negatives += 1

        expected_cats = sorted(gt["expected_categories"])
        category_match = all(cat in observed_cats for cat in expected_cats)

        scenario_results.append(
            {
                "scenario": scenario,
                "description": gt["description"],
                "should_alert": should_alert,
                "alerted": alerted,
                "expected_categories": expected_cats,
                "observed_categories": observed_cats,
                "category_match": category_match,
                "expected_hypothesis": gt["expected_hypothesis"],
                "observed_hypotheses": sorted({f["hypothesis"] for f in findings}),
                "finding_count": len(findings),
                "latency_ms": latency_ms,
                "package_verified": bool(result["package_verification"]["verified"]),
                "case_id": case["case_id"],
            }
        )

    # First acceptance milestone interrupted-recovery check
    milestone_bundle = generate_scenario_bundle("unapproved_controller_change")
    interrupted = ws.run_bundle_analysis(
        run_id="MILESTONE-RECOVERY",
        bundle=milestone_bundle,
        baseline=baseline,
        custodian="collector_01",
        analyst_token=tokens["analyst_01"],
        simulate_interrupt=True,
    )
    resumed = ws.resume_interrupted_analysis(
        run_id="MILESTONE-RECOVERY",
        baseline=baseline,
        analyst_token=tokens["analyst_01"],
    )
    # Record analyst operational handoff approval on resumed case
    approved_case = approve_incident_case(
        ws.auth.validate_session(tokens["case_approver_01"]),
        IncidentCase(
            **{
                **build_incident_case(
                    case_id=resumed["case"]["case_id"],
                    title=resumed["case"]["title"],
                    findings=(),
                    baseline_comparisons=(),
                    snapshots=(),
                    ews_records=(),
                    maintenance_records=(),
                    telemetry=(),
                    evidence_ids=resumed["case"]["evidence_ids"],
                ).__dict__,
            }
        ),
        decision="approve",
        rationale="Verified unapproved PLC-101 change against offline engineering archive; escalate for controlled restoration.",
        operational_handoff_ref="OPS-HANDOFF-2026-001",
    )

    total = len(SCENARIO_NAMES)
    accuracy = round((true_positives + true_negatives) / total, 4) if total else 0.0
    fpr = round(false_positives / max(1, (false_positives + true_negatives)), 4)

    report = {
        "schema_version": SCHEMA_VERSION,
        "tool_name": TOOL_NAME,
        "tool_version": TOOL_VERSION,
        "generated_at": utc_now_iso(),
        "laboratory_only": True,
        "summary": {
            "total_scenarios": total,
            "true_positives": true_positives,
            "true_negatives": true_negatives,
            "false_positives": false_positives,
            "false_negatives": false_negatives,
            "detection_accuracy": accuracy,
            "false_positive_rate": fpr,
            "all_packages_verified": all(r["package_verified"] for r in scenario_results),
            "all_categories_matched": all(r["category_match"] for r in scenario_results),
            "mean_latency_ms": round(sum(r["latency_ms"] for r in scenario_results) / total, 3),
        },
        "first_acceptance_milestone": {
            "interrupted_stage": interrupted["checkpoint_stage"],
            "resumed_status": resumed["status"],
            "resumed_case_id": resumed["case"]["case_id"],
            "resumed_findings_count": len(resumed["case"]["findings"]),
            "package_verified": resumed["package_verification"]["verified"],
            "handoff_status": approved_case.status.value,
        },
        "scenarios": scenario_results,
        "known_limitations": [
            "All telemetry and PLC snapshots in the laboratory are synthetic representations; vendor-specific proprietary binary PLC project formats require dedicated parsers.",
            "Source timestamps originate from upstream EWS/historian clocks and cannot independently prove physical event ordering if upstream clocks drifted or were altered prior to collection.",
            "HMAC-SHA256 signatures authenticate possession of the Sentinel signing key at manifest creation/export time; hardware HSM integration is not included in the offline reference deployment.",
        ],
    }

    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    return report
