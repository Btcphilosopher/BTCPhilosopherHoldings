"""Bounded process telemetry ingestion, deduplication, and quality/staleness tracking."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from sentinel_integrity.crypto import utc_now_iso
from sentinel_types import (
    QualityFlag,
    ResourceLimitError,
    ResourceLimits,
    SCHEMA_VERSION,
    TelemetryObservation,
    ValidationError,
)


@dataclass(frozen=True)
class IngestionMetrics:
    accepted_count: int
    duplicate_count: int
    dropped_count: int
    data_loss_detected: bool
    queue_depth: int
    queue_capacity: int


class TelemetryBuffer:
    """Bounded FIFO buffer preserving timestamps, units, quality flags, and loss counters."""

    def __init__(self, limits: ResourceLimits | None = None) -> None:
        self._limits = limits or ResourceLimits()
        self._limits.validate()
        self._queue: deque[TelemetryObservation] = deque()
        self._seen_keys: set[tuple[str, str, str, int]] = set()
        self._accepted = 0
        self._duplicates = 0
        self._dropped = 0

    def ingest_raw_batch(
        self,
        records: list[dict[str, Any]],
        *,
        default_source_identity: str = "offline_import",
        receipt_timestamp: str | None = None,
    ) -> IngestionMetrics:
        if len(records) > self._limits.max_events_per_batch:
            raise ResourceLimitError(
                f"Batch size {len(records)} exceeds max_events_per_batch ({self._limits.max_events_per_batch}).",
                component="sentinel_telemetry",
                operation="ingest_raw_batch",
            )
        rx_ts = receipt_timestamp or utc_now_iso()
        for idx, raw in enumerate(records):
            obs = self._parse_record(raw, idx=idx, default_source=default_source_identity, receipt_ts=rx_ts)
            dedup_key = (obs.asset_id, obs.tag, obs.source_timestamp, obs.sequence_no)
            if dedup_key in self._seen_keys:
                self._duplicates += 1
                continue
            if len(self._queue) >= self._limits.max_telemetry_queue_size:
                self._dropped += 1
                continue
            self._seen_keys.add(dedup_key)
            self._queue.append(obs)
            self._accepted += 1
        return self.metrics()

    def _parse_record(
        self,
        raw: dict[str, Any],
        *,
        idx: int,
        default_source: str,
        receipt_ts: str,
    ) -> TelemetryObservation:
        try:
            quality = QualityFlag(str(raw.get("quality", QualityFlag.GOOD.value)))
            return TelemetryObservation(
                observation_id=str(raw["observation_id"]),
                asset_id=str(raw["asset_id"]),
                tag=str(raw["tag"]),
                value=raw["value"],
                unit=str(raw["unit"]),
                quality=quality,
                source_timestamp=str(raw["source_timestamp"]),
                receipt_timestamp=str(raw.get("receipt_timestamp") or receipt_ts),
                source_identity=str(raw.get("source_identity") or default_source),
                sequence_no=int(raw.get("sequence_no", idx)),
                schema_version=str(raw.get("schema_version", SCHEMA_VERSION)),
            )
        except (KeyError, ValueError, TypeError) as exc:
            raise ValidationError(
                f"Invalid telemetry observation at index {idx}: {exc}",
                component="sentinel_telemetry",
                operation="parse_record",
            ) from exc

    def drain(self) -> list[TelemetryObservation]:
        items = list(self._queue)
        self._queue.clear()
        return items

    def snapshot(self) -> list[TelemetryObservation]:
        return list(self._queue)

    def metrics(self) -> IngestionMetrics:
        return IngestionMetrics(
            accepted_count=self._accepted,
            duplicate_count=self._duplicates,
            dropped_count=self._dropped,
            data_loss_detected=self._dropped > 0,
            queue_depth=len(self._queue),
            queue_capacity=self._limits.max_telemetry_queue_size,
        )


def parse_iso_utc(ts: str) -> datetime:
    dt = datetime.fromisoformat(ts)
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def find_stale_or_missing_tags(
    observations: list[TelemetryObservation],
    *,
    expected_tags: list[tuple[str, str]],
    window_end_iso: str,
    stale_threshold_seconds: float = 30.0,
) -> list[dict[str, Any]]:
    """Identify tags with STALE/BAD quality, delayed timestamps, or complete absence."""
    end_dt = parse_iso_utc(window_end_iso)
    by_pair: dict[tuple[str, str], list[TelemetryObservation]] = {}
    for obs in observations:
        by_pair.setdefault((obs.asset_id, obs.tag), []).append(obs)

    issues: list[dict[str, Any]] = []
    for asset_id, tag in expected_tags:
        series = sorted(by_pair.get((asset_id, tag), []), key=lambda o: parse_iso_utc(o.source_timestamp))
        if not series:
            issues.append(
                {
                    "asset_id": asset_id,
                    "tag": tag,
                    "reason": "missing_all_observations",
                    "stale_seconds": None,
                }
            )
            continue
        latest = series[-1]
        age_sec = (end_dt - parse_iso_utc(latest.source_timestamp)).total_seconds()
        if latest.quality in (QualityFlag.STALE, QualityFlag.BAD):
            issues.append(
                {
                    "asset_id": asset_id,
                    "tag": tag,
                    "reason": f"quality_flag_{latest.quality.value.lower()}",
                    "stale_seconds": round(age_sec, 3),
                    "latest_observation_id": latest.observation_id,
                    "latest_timestamp": latest.source_timestamp,
                }
            )
        elif age_sec > stale_threshold_seconds:
            issues.append(
                {
                    "asset_id": asset_id,
                    "tag": tag,
                    "reason": "telemetry_staleness_threshold_exceeded",
                    "stale_seconds": round(age_sec, 3),
                    "latest_observation_id": latest.observation_id,
                    "latest_timestamp": latest.source_timestamp,
                }
            )
    return issues
