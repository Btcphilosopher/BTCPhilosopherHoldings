#!/usr/bin/env bash
set -euo pipefail

PYTHON_BIN="${PYTHON_BIN:-python3}"

echo "[sentinel-ot] Running full automated test suite..."
"$PYTHON_BIN" -m unittest discover -s tests -v

echo "[sentinel-ot] Exporting deterministic synthetic plant datasets..."
"$PYTHON_BIN" -m sentinel_cli.main lab export-datasets --out-dir datasets

echo "[sentinel-ot] Executing Verification Laboratory..."
"$PYTHON_BIN" -m sentinel_cli.main lab run-all --work-dir /tmp/sentinel_lab_verify --output verification_results.json

echo "[sentinel-ot] Verification complete. Results written to verification_results.json"
