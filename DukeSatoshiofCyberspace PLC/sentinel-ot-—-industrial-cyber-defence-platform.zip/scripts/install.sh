#!/usr/bin/env bash
set -euo pipefail

# Sentinel OT Air-Gapped / Controlled Environment Installation Script
# Enforces Python >= 3.11 and zero external network downloads for core runtime.

PYTHON_BIN="${PYTHON_BIN:-python3}"

echo "[sentinel-ot] Checking Python interpreter..."
"$PYTHON_BIN" -c '
import sys
if sys.version_info < (3, 11):
    raise SystemExit(f"Python >= 3.11 required, found {sys.version}")
print(f"[sentinel-ot] Verified Python {sys.version.split()[0]}")
'

echo "[sentinel-ot] Verifying standard library cryptographic & persistence modules..."
"$PYTHON_BIN" -c 'import hashlib, hmac, sqlite3, json, zipfile, pathlib, dataclasses; print("[sentinel-ot] Core runtime modules verified.")'

echo "[sentinel-ot] Creating restricted runtime directories (umask 027)..."
umask 027
mkdir -p .sentinel_work/vault .sentinel_work/state .sentinel_work/logs .sentinel_work/exports

echo "[sentinel-ot] Installation checks complete. Run scripts/verify.sh to execute verification suite."
