"""Cryptographic primitives, protected credential store, signed updates, and encrypted backups."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import shutil
import tarfile
import io
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from sentinel_types import IntegrityError, ResourceLimitError, SecurityBoundaryError, ValidationError


PBKDF2_ITERATIONS = 210_000


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def canonical_json_bytes(payload: Any) -> bytes:
    """Deterministic UTF-8 canonical JSON representation for hashing and signing."""
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha512_bytes(data: bytes) -> str:
    return hashlib.sha512(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def sha512_file(path: Path) -> str:
    h = hashlib.sha512()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def hash_password(password: str, salt: bytes | None = None) -> str:
    if len(password) < 12:
        raise ValidationError(
            "Password must be at least 12 characters.",
            component="sentinel_integrity.crypto",
            operation="hash_password",
        )
    salt_bytes = salt if salt is not None else secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt_bytes, PBKDF2_ITERATIONS)
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${base64.b64encode(salt_bytes).decode()}${base64.b64encode(dk).decode()}"


def verify_password(password: str, encoded_hash: str) -> bool:
    try:
        scheme, iter_str, salt_b64, dk_b64 = encoded_hash.split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        iterations = int(iter_str)
        if iterations < 100_000:
            return False
        salt_bytes = base64.b64decode(salt_b64)
        expected_dk = base64.b64decode(dk_b64)
        actual_dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt_bytes, iterations)
        return hmac.compare_digest(actual_dk, expected_dk)
    except Exception:
        return False


def _derive_enc_and_mac_keys(master_secret: bytes, salt: bytes) -> tuple[bytes, bytes]:
    dk = hashlib.pbkdf2_hmac("sha256", master_secret, salt, PBKDF2_ITERATIONS, dklen=64)
    return dk[:32], dk[32:]


def _keystream_block(enc_key: bytes, nonce: bytes, counter: int) -> bytes:
    return hashlib.sha256(enc_key + nonce + counter.to_bytes(8, "big")).digest()


def encrypt_authenticated(plaintext: bytes, passphrase: str) -> bytes:
    """Encrypt bytes using PBKDF2-SHA256 + SHA-256 CTR stream + Encrypt-then-MAC HMAC-SHA256."""
    if not passphrase:
        raise ValidationError(
            "Passphrase must not be empty.",
            component="sentinel_integrity.crypto",
            operation="encrypt_authenticated",
        )
    salt = secrets.token_bytes(16)
    nonce = secrets.token_bytes(16)
    enc_key, mac_key = _derive_enc_and_mac_keys(passphrase.encode("utf-8"), salt)

    ciphertext = bytearray(len(plaintext))
    for offset in range(0, len(plaintext), 32):
        block = _keystream_block(enc_key, nonce, offset // 32)
        chunk = plaintext[offset : offset + 32]
        for i, b in enumerate(chunk):
            ciphertext[offset + i] = b ^ block[i]

    header = b"SOTENC1" + salt + nonce
    tag = hmac.new(mac_key, header + bytes(ciphertext), hashlib.sha256).digest()
    return header + tag + bytes(ciphertext)


def decrypt_authenticated(blob: bytes, passphrase: str) -> bytes:
    """Verify Encrypt-then-MAC HMAC-SHA256 before decrypting."""
    if len(blob) < 7 + 16 + 16 + 32 or not blob.startswith(b"SOTENC1"):
        raise IntegrityError(
            "Malformed or unsupported encrypted envelope.",
            component="sentinel_integrity.crypto",
            operation="decrypt_authenticated",
        )
    salt = blob[7:23]
    nonce = blob[23:39]
    tag = blob[39:71]
    ciphertext = blob[71:]
    enc_key, mac_key = _derive_enc_and_mac_keys(passphrase.encode("utf-8"), salt)
    expected_tag = hmac.new(mac_key, blob[:39] + ciphertext, hashlib.sha256).digest()
    if not hmac.compare_digest(tag, expected_tag):
        raise IntegrityError(
            "Authentication tag mismatch; ciphertext corrupted or wrong passphrase.",
            component="sentinel_integrity.crypto",
            operation="decrypt_authenticated",
        )
    plaintext = bytearray(len(ciphertext))
    for offset in range(0, len(ciphertext), 32):
        block = _keystream_block(enc_key, nonce, offset // 32)
        chunk = ciphertext[offset : offset + 32]
        for i, b in enumerate(chunk):
            plaintext[offset + i] = b ^ block[i]
    return bytes(plaintext)


@dataclass(frozen=True)
class SigningKey:
    key_id: str
    secret: bytes
    purpose: str  # "baseline" | "evidence" | "update"

    @classmethod
    def generate(cls, key_id: str, purpose: str) -> "SigningKey":
        return cls(key_id=key_id, secret=secrets.token_bytes(32), purpose=purpose)

    def sign_bytes(self, data: bytes) -> str:
        return hmac.new(self.secret, data, hashlib.sha256).hexdigest()

    def verify_bytes(self, data: bytes, signature_hex: str) -> bool:
        expected = self.sign_bytes(data)
        return hmac.compare_digest(expected, signature_hex)


class KeyRing:
    """In-memory and encrypted-on-disk keyring with key ID lookup."""

    def __init__(self) -> None:
        self._keys: dict[str, SigningKey] = {}

    def add_key(self, key: SigningKey) -> None:
        self._keys[key.key_id] = key

    def get_key(self, key_id: str) -> SigningKey:
        if key_id not in self._keys:
            raise SecurityBoundaryError(
                f"Unknown signing key ID: {key_id}",
                component="sentinel_integrity.crypto",
                operation="get_key",
                details={"key_id": key_id},
            )
        return self._keys[key_id]

    def sign_payload(self, key_id: str, payload: Any) -> str:
        key = self.get_key(key_id)
        return key.sign_bytes(canonical_json_bytes(payload))

    def verify_payload(self, key_id: str, payload: Any, signature: str) -> bool:
        if key_id not in self._keys:
            return False
        return self._keys[key_id].verify_bytes(canonical_json_bytes(payload), signature)

    def save_encrypted(self, path: Path, passphrase: str) -> None:
        serialised = {
            "keys": [
                {
                    "key_id": k.key_id,
                    "purpose": k.purpose,
                    "secret_b64": base64.b64encode(k.secret).decode("ascii"),
                }
                for k in self._keys.values()
            ]
        }
        blob = encrypt_authenticated(canonical_json_bytes(serialised), passphrase)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(blob)
        os.chmod(path, 0o600)

    @classmethod
    def load_encrypted(cls, path: Path, passphrase: str) -> "KeyRing":
        raw = decrypt_authenticated(path.read_bytes(), passphrase)
        data = json.loads(raw.decode("utf-8"))
        ring = cls()
        for entry in data.get("keys", []):
            ring.add_key(
                SigningKey(
                    key_id=entry["key_id"],
                    purpose=entry["purpose"],
                    secret=base64.b64decode(entry["secret_b64"]),
                )
            )
        return ring


class CredentialStore:
    """Encrypted credential store preventing plaintext secrets at rest."""

    def __init__(self, vault_path: Path, passphrase: str) -> None:
        self._vault_path = vault_path
        self._passphrase = passphrase

    def _load_all(self) -> dict[str, str]:
        if not self._vault_path.exists():
            return {}
        raw = decrypt_authenticated(self._vault_path.read_bytes(), self._passphrase)
        data = json.loads(raw.decode("utf-8"))
        if not isinstance(data, dict):
            raise IntegrityError(
                "Corrupted credential store payload.",
                component="sentinel_integrity.crypto",
                operation="load_credentials",
            )
        return {str(k): str(v) for k, v in data.items()}

    def _save_all(self, creds: dict[str, str]) -> None:
        self._vault_path.parent.mkdir(parents=True, exist_ok=True)
        blob = encrypt_authenticated(canonical_json_bytes(creds), self._passphrase)
        self._vault_path.write_bytes(blob)
        os.chmod(self._vault_path, 0o600)

    def put_secret(self, name: str, value: str) -> None:
        if not name or not value:
            raise ValidationError(
                "Credential name and secret value must be non-empty.",
                component="sentinel_integrity.crypto",
                operation="put_secret",
            )
        creds = self._load_all()
        creds[name] = value
        self._save_all(creds)

    def get_secret(self, name: str) -> str:
        creds = self._load_all()
        if name not in creds:
            raise SecurityBoundaryError(
                f"Credential '{name}' not found.",
                component="sentinel_integrity.crypto",
                operation="get_secret",
            )
        return creds[name]

    def list_names(self) -> list[str]:
        return sorted(self._load_all().keys())


def create_signed_update_bundle(
    payload: dict[str, Any],
    *,
    version: str,
    keyring: KeyRing,
    key_id: str,
) -> dict[str, Any]:
    """Create a signed rule/configuration update bundle for offline verification."""
    body = {
        "bundle_version": version,
        "created_at": utc_now_iso(),
        "payload": payload,
    }
    body_sha256 = sha256_bytes(canonical_json_bytes(body))
    signature = keyring.sign_payload(key_id, {"body_sha256": body_sha256, "body": body})
    return {
        "body": body,
        "body_sha256": body_sha256,
        "signer_key_id": key_id,
        "signature": signature,
    }


def verify_signed_update_bundle(bundle: dict[str, Any], keyring: KeyRing) -> dict[str, Any]:
    """Verify cryptographic hash and HMAC signature of an update bundle before applying."""
    required = {"body", "body_sha256", "signer_key_id", "signature"}
    if not required.issubset(bundle.keys()):
        raise IntegrityError(
            "Signed update bundle missing required fields.",
            component="sentinel_integrity.crypto",
            operation="verify_signed_update_bundle",
        )
    actual_sha = sha256_bytes(canonical_json_bytes(bundle["body"]))
    if not hmac.compare_digest(actual_sha, str(bundle["body_sha256"])):
        raise IntegrityError(
            "Update bundle SHA-256 checksum mismatch.",
            component="sentinel_integrity.crypto",
            operation="verify_signed_update_bundle",
        )
    valid = keyring.verify_payload(
        str(bundle["signer_key_id"]),
        {"body_sha256": bundle["body_sha256"], "body": bundle["body"]},
        str(bundle["signature"]),
    )
    if not valid:
        raise SecurityBoundaryError(
            "Update bundle signature verification failed.",
            component="sentinel_integrity.crypto",
            operation="verify_signed_update_bundle",
        )
    return bundle["body"]


def create_encrypted_backup(
    source_dir: Path,
    backup_file: Path,
    passphrase: str,
    *,
    max_bytes: int = 128 * 1024 * 1024,
) -> dict[str, Any]:
    """Create an authenticated encrypted tar.gz backup of a Sentinel OT state directory."""
    if not source_dir.exists() or not source_dir.is_dir():
        raise ValidationError(
            f"Backup source directory does not exist: {source_dir}",
            component="sentinel_integrity.crypto",
            operation="create_encrypted_backup",
        )
    buf = io.BytesIO()
    total_bytes = 0
    file_count = 0
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for item in sorted(source_dir.rglob("*")):
            if item.is_symlink():
                continue
            if item.is_file():
                size = item.stat().st_size
                total_bytes += size
                if total_bytes > max_bytes:
                    raise ResourceLimitError(
                        "Backup exceeds maximum allowed byte budget.",
                        component="sentinel_integrity.crypto",
                        operation="create_encrypted_backup",
                    )
                tar.add(item, arcname=item.relative_to(source_dir).as_posix(), recursive=False)
                file_count += 1
    raw_tar = buf.getvalue()
    encrypted = encrypt_authenticated(raw_tar, passphrase)
    backup_file.parent.mkdir(parents=True, exist_ok=True)
    backup_file.write_bytes(encrypted)
    os.chmod(backup_file, 0o600)
    return {
        "backup_file": str(backup_file),
        "files_archived": file_count,
        "uncompressed_bytes": total_bytes,
        "encrypted_sha256": sha256_bytes(encrypted),
        "created_at": utc_now_iso(),
    }


def restore_encrypted_backup(
    backup_file: Path,
    target_dir: Path,
    passphrase: str,
    *,
    max_bytes: int = 128 * 1024 * 1024,
) -> dict[str, Any]:
    """Verify and restore an authenticated encrypted backup safely (no path traversal)."""
    encrypted = backup_file.read_bytes()
    raw_tar = decrypt_authenticated(encrypted, passphrase)
    target_dir.mkdir(parents=True, exist_ok=True)
    base_resolved = target_dir.resolve()
    restored = 0
    total_extracted = 0

    with tarfile.open(fileobj=io.BytesIO(raw_tar), mode="r:gz") as tar:
        for member in tar.getmembers():
            if member.issym() or member.islnk() or member.ischr() or member.isblk() or member.isfifo():
                raise SecurityBoundaryError(
                    f"Disallowed tar member type in backup: {member.name}",
                    component="sentinel_integrity.crypto",
                    operation="restore_encrypted_backup",
                )
            if not member.isfile():
                continue
            member_path = (base_resolved / member.name).resolve()
            if base_resolved not in member_path.parents and member_path != base_resolved:
                raise SecurityBoundaryError(
                    f"Path traversal blocked in backup archive: {member.name}",
                    component="sentinel_integrity.crypto",
                    operation="restore_encrypted_backup",
                )
            total_extracted += member.size
            if total_extracted > max_bytes:
                raise ResourceLimitError(
                    "Backup restoration exceeds byte limit.",
                    component="sentinel_integrity.crypto",
                    operation="restore_encrypted_backup",
                )
            member_path.parent.mkdir(parents=True, exist_ok=True)
            src = tar.extractfile(member)
            if src is None:
                continue
            with src, member_path.open("wb") as dst:
                shutil.copyfileobj(src, dst)
            restored += 1

    return {
        "restored_files": restored,
        "restored_bytes": total_extracted,
        "target_dir": str(target_dir),
    }


def enforce_retention_policy(directory: Path, retention_days: int, *, now: datetime | None = None) -> list[str]:
    """Remove expired archived artifacts older than retention_days while preserving active evidence locks."""
    if retention_days <= 0:
        raise ValidationError(
            "retention_days must be positive.",
            component="sentinel_integrity.crypto",
            operation="enforce_retention_policy",
        )
    if not directory.exists():
        return []
    cutoff = (now or datetime.now(timezone.utc)) - timedelta(days=retention_days)
    removed: list[str] = []
    for path in sorted(directory.iterdir()):
        if path.is_file():
            mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
            if mtime < cutoff:
                path.unlink()
                removed.append(path.name)
    return removed
