"""Bounded, defensive parsers preventing path traversal, zip bombs, and unsafe deserialisation."""

from __future__ import annotations

import json
import stat
import zipfile
from pathlib import Path
from typing import Any

from sentinel_types import (
    ResourceLimitError,
    ResourceLimits,
    SecurityBoundaryError,
    ValidationError,
)


def ensure_within_base_dir(base_dir: Path, candidate: Path) -> Path:
    """Resolve candidate path and block any path traversal outside base_dir."""
    base_resolved = base_dir.resolve()
    cand_resolved = candidate.resolve()
    if cand_resolved != base_resolved and base_resolved not in cand_resolved.parents:
        raise SecurityBoundaryError(
            f"Path traversal blocked: '{candidate}' escapes '{base_dir}'.",
            component="sentinel_integrity.parser",
            operation="ensure_within_base_dir",
            details={"candidate": str(candidate)},
        )
    return cand_resolved


def _check_json_depth(node: Any, max_depth: int, current_depth: int = 0) -> None:
    if current_depth > max_depth:
        raise ResourceLimitError(
            f"JSON nesting depth exceeds limit of {max_depth}.",
            component="sentinel_integrity.parser",
            operation="check_json_depth",
            details={"max_depth": max_depth},
        )
    if isinstance(node, dict):
        for v in node.values():
            _check_json_depth(v, max_depth, current_depth + 1)
    elif isinstance(node, list):
        for item in node:
            _check_json_depth(item, max_depth, current_depth + 1)


def _reject_nonstandard_constant(token: str) -> Any:
    raise ValidationError(
        f"Non-standard JSON numeric constant rejected: {token}",
        component="sentinel_integrity.parser",
        operation="safe_load_json_bytes",
    )


def safe_load_json_bytes(
    raw: bytes,
    *,
    limits: ResourceLimits | None = None,
    expected_root_type: type = dict,
) -> Any:
    """Safely decode bounded JSON without NaN/Infinity or excessive nesting."""
    lim = limits or ResourceLimits()
    if len(raw) > lim.max_input_bytes:
        raise ResourceLimitError(
            f"Input size {len(raw)} exceeds limit {lim.max_input_bytes} bytes.",
            component="sentinel_integrity.parser",
            operation="safe_load_json_bytes",
        )
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ValidationError(
            "Input is not valid UTF-8.",
            component="sentinel_integrity.parser",
            operation="safe_load_json_bytes",
        ) from exc

    try:
        parsed = json.loads(text, parse_constant=_reject_nonstandard_constant)
    except ValidationError:
        raise
    except RecursionError as exc:
        raise ResourceLimitError(
            "JSON recursion depth exceeded interpreter limit.",
            component="sentinel_integrity.parser",
            operation="safe_load_json_bytes",
        ) from exc
    except json.JSONDecodeError as exc:
        raise ValidationError(
            f"Malformed JSON payload: {exc.msg}",
            component="sentinel_integrity.parser",
            operation="safe_load_json_bytes",
            details={"line": exc.lineno, "col": exc.colno},
        ) from exc

    _check_json_depth(parsed, lim.max_json_depth)
    if not isinstance(parsed, expected_root_type):
        raise ValidationError(
            f"Expected JSON root of type {expected_root_type.__name__}, got {type(parsed).__name__}.",
            component="sentinel_integrity.parser",
            operation="safe_load_json_bytes",
        )
    return parsed


def safe_load_json_file(
    file_path: Path,
    *,
    limits: ResourceLimits | None = None,
    expected_root_type: type = dict,
) -> Any:
    lim = limits or ResourceLimits()
    if not file_path.exists() or not file_path.is_file():
        raise ValidationError(
            f"Input file not found: {file_path}",
            component="sentinel_integrity.parser",
            operation="safe_load_json_file",
        )
    if file_path.is_symlink():
        raise SecurityBoundaryError(
            f"Symlink input file rejected: {file_path}",
            component="sentinel_integrity.parser",
            operation="safe_load_json_file",
        )
    size = file_path.stat().st_size
    if size > lim.max_input_bytes:
        raise ResourceLimitError(
            f"File '{file_path.name}' ({size} bytes) exceeds limit {lim.max_input_bytes} bytes.",
            component="sentinel_integrity.parser",
            operation="safe_load_json_file",
        )
    return safe_load_json_bytes(
        file_path.read_bytes(),
        limits=lim,
        expected_root_type=expected_root_type,
    )


def _validate_archive_entry_name(name: str) -> None:
    if "\x00" in name:
        raise SecurityBoundaryError(
            "Null byte in archive member path.",
            component="sentinel_integrity.parser",
            operation="validate_archive_entry_name",
        )
    if name.startswith("/") or name.startswith("\\") or (len(name) >= 2 and name[1] == ":"):
        raise SecurityBoundaryError(
            f"Absolute path blocked in archive: {name}",
            component="sentinel_integrity.parser",
            operation="validate_archive_entry_name",
        )
    parts = Path(name.replace("\\", "/")).parts
    if ".." in parts:
        raise SecurityBoundaryError(
            f"Path traversal ('..') blocked in archive: {name}",
            component="sentinel_integrity.parser",
            operation="validate_archive_entry_name",
        )


def safe_read_zip_entries(
    zip_path: Path,
    *,
    limits: ResourceLimits | None = None,
) -> dict[str, bytes]:
    """Read ZIP archive entries in memory under strict bomb, symlink, and traversal limits."""
    lim = limits or ResourceLimits()
    if not zip_path.exists() or not zip_path.is_file() or zip_path.is_symlink():
        raise ValidationError(
            f"Invalid archive path: {zip_path}",
            component="sentinel_integrity.parser",
            operation="safe_read_zip_entries",
        )
    archive_size = zip_path.stat().st_size
    if archive_size > lim.max_input_bytes:
        raise ResourceLimitError(
            f"Archive size {archive_size} exceeds limit {lim.max_input_bytes}.",
            component="sentinel_integrity.parser",
            operation="safe_read_zip_entries",
        )

    entries: dict[str, bytes] = {}
    total_uncompressed = 0

    try:
        with zipfile.ZipFile(zip_path, mode="r") as zf:
            infos = zf.infolist()
            if len(infos) > lim.max_archive_files:
                raise ResourceLimitError(
                    f"Archive entry count {len(infos)} exceeds limit {lim.max_archive_files}.",
                    component="sentinel_integrity.parser",
                    operation="safe_read_zip_entries",
                )
            for info in infos:
                _validate_archive_entry_name(info.filename)
                # Block POSIX symlinks inside ZIP external_attr
                mode = info.external_attr >> 16
                if stat.S_ISLNK(mode):
                    raise SecurityBoundaryError(
                        f"Symlink entry blocked in archive: {info.filename}",
                        component="sentinel_integrity.parser",
                        operation="safe_read_zip_entries",
                    )
                if info.is_dir():
                    continue
                if info.file_size > lim.max_input_bytes:
                    raise ResourceLimitError(
                        f"Archive member '{info.filename}' exceeds single-file byte limit.",
                        component="sentinel_integrity.parser",
                        operation="safe_read_zip_entries",
                    )
                if info.compress_size > 0:
                    ratio = info.file_size / info.compress_size
                    if ratio > lim.max_archive_compression_ratio and info.file_size > 65536:
                        raise ResourceLimitError(
                            f"Suspected compression bomb in '{info.filename}' (ratio {ratio:.1f}x).",
                            component="sentinel_integrity.parser",
                            operation="safe_read_zip_entries",
                        )
                total_uncompressed += info.file_size
                if total_uncompressed > lim.max_archive_uncompressed_bytes:
                    raise ResourceLimitError(
                        "Total uncompressed archive bytes exceed resource limit.",
                        component="sentinel_integrity.parser",
                        operation="safe_read_zip_entries",
                    )
                # Read bounded bytes to guard against spoofed headers
                with zf.open(info, mode="r") as member_fh:
                    data = member_fh.read(lim.max_input_bytes + 1)
                    if len(data) > lim.max_input_bytes:
                        raise ResourceLimitError(
                            f"Actual uncompressed member '{info.filename}' exceeded limit.",
                            component="sentinel_integrity.parser",
                            operation="safe_read_zip_entries",
                        )
                    entries[info.filename] = data
    except zipfile.BadZipFile as exc:
        raise ValidationError(
            "Malformed or corrupted ZIP archive.",
            component="sentinel_integrity.parser",
            operation="safe_read_zip_entries",
        ) from exc

    return entries
