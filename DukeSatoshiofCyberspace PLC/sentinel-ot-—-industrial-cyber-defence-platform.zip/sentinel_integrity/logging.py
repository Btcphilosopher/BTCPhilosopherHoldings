"""Redacted structured security and operational logger."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SENSITIVE_KEYS = frozenset({
    "password",
    "passphrase",
    "secret",
    "token",
    "api_key",
    "apikey",
    "private_key",
    "credential",
    "authorization",
    "secret_b64",
    "password_hash",
})

TOKEN_PATTERN = re.compile(r"(Bearer\s+[A-Za-z0-9\-._~+/]+=*|pbkdf2_sha256\$[^\s\"']+)", re.IGNORECASE)


def redact_value(key: str, value: Any) -> Any:
    if any(sk in key.lower() for sk in SENSITIVE_KEYS):
        return "[REDACTED]"
    if isinstance(value, dict):
        return {str(k): redact_value(str(k), v) for k, v in value.items()}
    if isinstance(value, list):
        return [redact_value(key, item) for item in value]
    if isinstance(value, str):
        return TOKEN_PATTERN.sub("[REDACTED]", value)
    return value


@dataclass
class RedactedLogger:
    """Append-only structured JSONL logger that strips credentials and secrets."""

    log_path: Path | None = None
    records: list[dict[str, Any]] = field(default_factory=list)

    def log(self, level: str, component: str, event: str, **fields: Any) -> dict[str, Any]:
        sanitized = {str(k): redact_value(str(k), v) for k, v in fields.items()}
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": level.upper(),
            "component": component,
            "event": event,
            "fields": sanitized,
        }
        self.records.append(entry)
        if self.log_path is not None:
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            with self.log_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry, sort_keys=True) + "\n")
        return entry
