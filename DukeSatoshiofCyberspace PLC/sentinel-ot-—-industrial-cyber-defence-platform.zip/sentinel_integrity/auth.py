"""Strong authentication and role-based access control (RBAC) with separation of duties."""

from __future__ import annotations

import hmac
import secrets
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

from sentinel_integrity.crypto import hash_password, verify_password
from sentinel_types import AuthorizationError, Role, ValidationError


@dataclass
class UserAccount:
    user_id: str
    roles: frozenset[Role]
    password_hash: str
    active: bool = True
    failed_attempts: int = 0
    locked_until: datetime | None = None


@dataclass
class AuthSession:
    token: str
    user_id: str
    roles: frozenset[Role]
    issued_at: datetime
    expires_at: datetime


class AuthManager:
    """Enforces PBKDF2 authentication, lockout protection, and strict RBAC."""

    MAX_FAILED_ATTEMPTS = 5
    LOCKOUT_MINUTES = 15

    def __init__(self) -> None:
        self._users: dict[str, UserAccount] = {}
        self._sessions: dict[str, AuthSession] = {}

    def register_user(self, user_id: str, password: str, roles: set[Role] | list[Role]) -> UserAccount:
        if not user_id or not roles:
            raise ValidationError(
                "user_id and at least one role are required.",
                component="sentinel_integrity.auth",
                operation="register_user",
            )
        if user_id in self._users:
            raise ValidationError(
                f"User '{user_id}' already exists.",
                component="sentinel_integrity.auth",
                operation="register_user",
            )
        account = UserAccount(
            user_id=user_id,
            roles=frozenset(roles),
            password_hash=hash_password(password),
        )
        self._users[user_id] = account
        return account

    def authenticate(self, user_id: str, password: str, *, ttl_minutes: int = 60) -> AuthSession:
        account = self._users.get(user_id)
        now = datetime.now(timezone.utc)
        if account is None or not account.active:
            raise AuthorizationError(
                "Invalid credentials or inactive account.",
                component="sentinel_integrity.auth",
                operation="authenticate",
            )
        if account.locked_until is not None and now < account.locked_until:
            raise AuthorizationError(
                "Account temporarily locked due to repeated failed authentications.",
                component="sentinel_integrity.auth",
                operation="authenticate",
            )
        if not verify_password(password, account.password_hash):
            account.failed_attempts += 1
            if account.failed_attempts >= self.MAX_FAILED_ATTEMPTS:
                account.locked_until = now + timedelta(minutes=self.LOCKOUT_MINUTES)
            raise AuthorizationError(
                "Invalid credentials.",
                component="sentinel_integrity.auth",
                operation="authenticate",
            )
        account.failed_attempts = 0
        account.locked_until = None
        token = secrets.token_urlsafe(32)
        session = AuthSession(
            token=token,
            user_id=account.user_id,
            roles=account.roles,
            issued_at=now,
            expires_at=now + timedelta(minutes=ttl_minutes),
        )
        self._sessions[token] = session
        return session

    def validate_session(self, token: str) -> AuthSession:
        now = datetime.now(timezone.utc)
        for stored_token, session in self._sessions.items():
            if hmac.compare_digest(stored_token, token):
                if now > session.expires_at:
                    raise AuthorizationError(
                        "Session token expired.",
                        component="sentinel_integrity.auth",
                        operation="validate_session",
                    )
                return session
        raise AuthorizationError(
            "Invalid session token.",
            component="sentinel_integrity.auth",
            operation="validate_session",
        )

    def authorize(self, token: str, required_roles: set[Role]) -> AuthSession:
        session = self.validate_session(token)
        if Role.ADMIN in session.roles:
            return session
        if not session.roles.intersection(required_roles):
            raise AuthorizationError(
                f"User '{session.user_id}' lacks required role(s): {[r.value for r in required_roles]}",
                component="sentinel_integrity.auth",
                operation="authorize",
                details={"user_id": session.user_id},
            )
        return session

    def revoke_session(self, token: str) -> None:
        self._sessions.pop(token, None)
