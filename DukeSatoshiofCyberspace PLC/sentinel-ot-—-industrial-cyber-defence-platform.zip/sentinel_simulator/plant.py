"""Harmless synthetic water-holding plant laboratory for defensive verification."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from sentinel_integrity.crypto import canonical_json_bytes, sha256_bytes
from sentinel_types import (
    ControllerSnapshot,
    FindingCategory,
    HypothesisClass,
    QualityFlag,
    SCHEMA_VERSION,
)


SCENARIO_NAMES = (
    "nominal",
    "planned_maintenance",
    "sensor_fault",
    "stale_telemetry",
    "unapproved_controller_change",
    "inconsistent_observations",
)


def default_inventory_payload() -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "laboratory_only": True,
        "assets": [
            {
                "asset_id": "PLC-101",
                "name": "Holding Tank Main Controller",
                "kind": "plc",
                "zone": "cell_a_control",
                "criticality": "process_critical",
                "vendor": "SyntheticControls",
                "model": "SC-PLC-400",
                "firmware_version": "4.2.1",
                "expected_protocol": "offline_export",
                "connected_assets": ["TK-101", "P-101", "LT-101", "FT-101", "PT-101", "EWS-01"],
            },
            {
                "asset_id": "TK-101",
                "name": "Primary Buffer Tank",
                "kind": "sensor",
                "zone": "cell_a_field",
                "criticality": "process_critical",
                "vendor": "SyntheticProcess",
                "model": "TANK-5000L",
                "firmware_version": "n/a",
                "expected_protocol": "hardwired_4_20ma",
                "connected_assets": ["PLC-101", "P-101"],
            },
            {
                "asset_id": "P-101",
                "name": "Feed Transfer Pump",
                "kind": "actuator",
                "zone": "cell_a_field",
                "criticality": "process_critical",
                "vendor": "SyntheticPumps",
                "model": "CENT-200",
                "firmware_version": "1.1.0",
                "expected_protocol": "hardwired_io",
                "connected_assets": ["PLC-101", "FT-101", "PT-101"],
            },
            {
                "asset_id": "LT-101",
                "name": "Tank Level Transmitter",
                "kind": "sensor",
                "zone": "cell_a_field",
                "criticality": "process_critical",
                "vendor": "SyntheticInstruments",
                "model": "LVL-RADAR-2",
                "firmware_version": "2.0.3",
                "expected_protocol": "hart_4_20ma",
                "connected_assets": ["PLC-101", "TK-101"],
            },
            {
                "asset_id": "FT-101",
                "name": "Pump Discharge Flow Meter",
                "kind": "sensor",
                "zone": "cell_a_field",
                "criticality": "process_critical",
                "vendor": "SyntheticInstruments",
                "model": "MAG-FLOW-90",
                "firmware_version": "3.1.0",
                "expected_protocol": "hart_4_20ma",
                "connected_assets": ["PLC-101", "P-101"],
            },
            {
                "asset_id": "PT-101",
                "name": "Discharge Pressure Transmitter",
                "kind": "sensor",
                "zone": "cell_a_field",
                "criticality": "monitoring",
                "vendor": "SyntheticInstruments",
                "model": "PRESS-40",
                "firmware_version": "1.4.2",
                "expected_protocol": "hart_4_20ma",
                "connected_assets": ["PLC-101", "P-101"],
            },
            {
                "asset_id": "EWS-01",
                "name": "Air-Gapped Engineering Workstation",
                "kind": "ews",
                "zone": "engineering_dmz",
                "criticality": "process_critical",
                "vendor": "SyntheticWorkstation",
                "model": "EWS-HARDENED-1",
                "firmware_version": "11.0",
                "expected_protocol": "offline_audit",
                "connected_assets": ["PLC-101"],
            },
        ],
    }


def baseline_controller_snapshot() -> ControllerSnapshot:
    logic_blocks = {
        "OB1_MAIN": "CALL FB_LEVEL_CTRL(LT_101, HIGH_SP=>80.0, LOW_SP=>25.0); CALL FB_PUMP_INTERLOCK(P_101, PT_101);",
        "FB_LEVEL_CTRL": "IF LEVEL < LOW_SP THEN P_101_CMD := TRUE; ELSIF LEVEL > HIGH_SP THEN P_101_CMD := FALSE; END_IF;",
        "FB_PUMP_INTERLOCK": "IF PT_101 > 450.0 THEN P_101_CMD := FALSE; ALARM_OVERPRESSURE := TRUE; END_IF;",
    }
    setpoints: dict[str, float | int | bool | str] = {
        "tank_high_level_pct": 80.0,
        "tank_low_level_pct": 25.0,
        "pump_max_flow_lpm": 180.0,
        "overpressure_trip_kpa": 450.0,
    }
    io_mappings = {
        "AI_01": "LT-101.tank_level_pct",
        "AI_02": "FT-101.flow_rate_lpm",
        "AI_03": "PT-101.discharge_pressure_kpa",
        "DO_01": "P-101.pump_command",
    }
    program_hash = sha256_bytes(
        canonical_json_bytes({"logic_blocks": logic_blocks, "setpoints": setpoints, "io_mappings": io_mappings})
    )
    return ControllerSnapshot(
        snapshot_id="SNAP-BASE-001",
        asset_id="PLC-101",
        captured_at="2026-11-19T08:00:00+00:00",
        source_identity="EWS-01_OFFLINE_EXPORT",
        collection_method="authorised_offline_export",
        firmware_version="4.2.1",
        program_version="v1.4.0",
        program_hash=program_hash,
        logic_blocks=logic_blocks,
        setpoints=setpoints,
        io_mappings=io_mappings,
        operating_mode="RUN",
    )


def _generate_telemetry_series(
    *,
    scenario: str,
    base_time: datetime,
    steps: int = 12,
    interval_sec: int = 5,
) -> list[dict[str, Any]]:
    observations: list[dict[str, Any]] = []
    seq = 0
    level = 42.0

    for i in range(steps):
        ts = base_time + timedelta(seconds=i * interval_sec)
        ts_iso = ts.isoformat()

        pump_on = i >= 2
        if scenario == "nominal":
            flow = 120.0 if pump_on else 0.0
            pressure = 210.0 if pump_on else 15.0
            level = round(level + (1.4 if pump_on else -0.2), 2)
        elif scenario == "planned_maintenance":
            flow = 115.0 if pump_on else 0.0
            pressure = 205.0 if pump_on else 15.0
            level = round(level + (1.3 if pump_on else -0.2), 2)
        elif scenario == "sensor_fault":
            # Flow active, pump ON, but primary tank level LT-101 frozen at 42.0 while backup tracks rise
            flow = 122.0 if pump_on else 0.0
            pressure = 212.0 if pump_on else 15.0
            level = 42.0  # stuck transmitter
        elif scenario == "stale_telemetry":
            flow = 118.0 if pump_on else 0.0
            pressure = 208.0 if pump_on else 15.0
            level = round(level + (1.3 if pump_on else -0.2), 2)
        elif scenario == "unapproved_controller_change":
            # Unapproved setpoint/logic change overrides pump_command vs flow or drives unsafe overfill
            flow = 0.0 if (i >= 6) else (125.0 if pump_on else 0.0)
            pressure = 22.0 if (i >= 6) else (215.0 if pump_on else 15.0)
            level = round(level + (1.5 if (pump_on and i < 6) else 0.0), 2)
        elif scenario == "inconsistent_observations":
            # Pump command ON throughout, yet flow stays 0.0 after step 3
            flow = 0.0 if i >= 3 else (110.0 if pump_on else 0.0)
            pressure = 25.0 if i >= 3 else 200.0
            level = round(level + (0.9 if (pump_on and i < 3) else 0.0), 2)
        else:
            raise ValueError(f"Unknown scenario: {scenario}")

        if scenario == "stale_telemetry" and i >= 5:
            # Simulate dropped/stale historian updates for flow & level at tail
            continue

        for asset_id, tag, val, unit, qual in (
            ("TK-101", "tank_level_pct", level, "%", QualityFlag.SIMULATED.value),
            ("P-101", "pump_command", pump_on, "bool", QualityFlag.SIMULATED.value),
            ("FT-101", "flow_rate_lpm", flow, "L/min", QualityFlag.SIMULATED.value),
            ("PT-101", "discharge_pressure_kpa", pressure, "kPa", QualityFlag.SIMULATED.value),
        ):
            seq += 1
            observations.append(
                {
                    "observation_id": f"OBS-{scenario[:4].upper()}-{seq:04d}",
                    "asset_id": asset_id,
                    "tag": tag,
                    "value": val,
                    "unit": unit,
                    "quality": qual,
                    "source_timestamp": ts_iso,
                    "receipt_timestamp": (ts + timedelta(seconds=1)).isoformat(),
                    "source_identity": "SYNTH_LAB_HISTORIAN_RO",
                    "sequence_no": seq,
                }
            )

        if scenario == "sensor_fault":
            seq += 1
            observations.append(
                {
                    "observation_id": f"OBS-{scenario[:4].upper()}-{seq:04d}",
                    "asset_id": "TK-101",
                    "tag": "tank_level_backup_pct",
                    "value": round(42.0 + max(0, i - 1) * 1.4, 2),
                    "unit": "%",
                    "quality": QualityFlag.SIMULATED.value,
                    "source_timestamp": ts_iso,
                    "receipt_timestamp": (ts + timedelta(seconds=1)).isoformat(),
                    "source_identity": "SYNTH_LAB_HISTORIAN_RO",
                    "sequence_no": seq,
                }
            )

    if scenario == "stale_telemetry":
        # Add an explicit STALE marker at window end for FT-101
        stale_ts = (base_time + timedelta(seconds=(steps - 1) * interval_sec)).isoformat()
        seq += 1
        observations.append(
            {
                "observation_id": f"OBS-STAL-{seq:04d}",
                "asset_id": "FT-101",
                "tag": "flow_rate_lpm",
                "value": 118.0,
                "unit": "L/min",
                "quality": QualityFlag.STALE.value,
                "source_timestamp": (base_time + timedelta(seconds=4 * interval_sec)).isoformat(),
                "receipt_timestamp": stale_ts,
                "source_identity": "SYNTH_LAB_HISTORIAN_RO",
                "sequence_no": seq,
            }
        )

    return observations


def generate_scenario_bundle(scenario: str) -> dict[str, Any]:
    """Generate a deterministic, self-contained labelled synthetic plant scenario."""
    if scenario not in SCENARIO_NAMES:
        raise ValueError(f"Unsupported scenario '{scenario}'. Valid: {SCENARIO_NAMES}")

    base_snap = baseline_controller_snapshot()
    t0 = datetime(2026, 11, 19, 10, 0, 0, tzinfo=timezone.utc)
    snap_dict = base_snap.to_dict()
    snap_dict["snapshot_id"] = f"SNAP-{scenario.upper()}-001"
    snap_dict["captured_at"] = (t0 + timedelta(seconds=15)).isoformat()

    ews_records: list[dict[str, Any]] = []
    maintenance_records: list[dict[str, Any]] = []

    if scenario == "nominal":
        ground_truth = {
            "should_alert": False,
            "expected_categories": [],
            "expected_hypothesis": None,
            "description": "Nominal holding-tank transfer under signed baseline configuration.",
        }
    elif scenario == "planned_maintenance":
        new_setpoints = dict(base_snap.setpoints)
        new_setpoints["tank_high_level_pct"] = 82.0
        new_hash = sha256_bytes(
            canonical_json_bytes(
                {
                    "logic_blocks": base_snap.logic_blocks,
                    "setpoints": new_setpoints,
                    "io_mappings": base_snap.io_mappings,
                }
            )
        )
        snap_dict["program_version"] = "v1.4.1"
        snap_dict["setpoints"] = new_setpoints
        snap_dict["program_hash"] = new_hash
        ews_records.append(
            {
                "event_id": "EWS-MAINT-001",
                "timestamp": (t0 + timedelta(seconds=5)).isoformat(),
                "workstation_id": "EWS-01",
                "operator_id": "eng_m_patel",
                "action": "setpoint_write",
                "target_asset_id": "PLC-101",
                "session_id": "SESS-MAINT-881",
                "outcome": "success",
                "artifact_hash": new_hash,
            }
        )
        maintenance_records.append(
            {
                "work_order_id": "WO-2026-1142",
                "asset_id": "PLC-101",
                "window_start": (t0 - timedelta(minutes=10)).isoformat(),
                "window_end": (t0 + timedelta(minutes=20)).isoformat(),
                "approved_by": "lead_k_okafor",
                "executed_by": "eng_m_patel",
                "scope": "Adjust tank_high_level_pct from 80.0 to 82.0 per process engineering ECR-44",
                "expected_program_hash": new_hash,
                "expected_setpoints": new_setpoints,
                "status": "approved",
            }
        )
        ground_truth = {
            "should_alert": False,
            "expected_categories": [FindingCategory.UNEXPECTED_PROGRAM_CHANGE.value],
            "expected_hypothesis": HypothesisClass.LEGITIMATE_MAINTENANCE.value,
            "description": "Approved maintenance change within authorised work-order window (classified legitimate_maintenance, non-malicious).",
        }
    elif scenario == "sensor_fault":
        ground_truth = {
            "should_alert": True,
            "expected_categories": [FindingCategory.CONTRADICTORY_MEASUREMENTS.value],
            "expected_hypothesis": HypothesisClass.EQUIPMENT_OR_SENSOR_FAULT.value,
            "description": "Frozen primary level transmitter LT-101 contradicted by active inflow and backup level transmitter.",
        }
    elif scenario == "stale_telemetry":
        ground_truth = {
            "should_alert": True,
            "expected_categories": [FindingCategory.STALE_OR_MISSING_OBSERVATION.value],
            "expected_hypothesis": HypothesisClass.TELEMETRY_LOSS_OR_DELAY.value,
            "description": "Historian telemetry interruption resulting in stale/missing sensor observations.",
        }
    elif scenario == "unapproved_controller_change":
        mod_logic = dict(base_snap.logic_blocks)
        mod_logic["FB_PUMP_INTERLOCK"] = (
            "IF PT_101 > 999.0 THEN P_101_CMD := FALSE; END_IF; (* BYPASSED OVERPRESSURE TRIP *)"
        )
        mod_setpoints = dict(base_snap.setpoints)
        mod_setpoints["overpressure_trip_kpa"] = 999.0
        mod_hash = sha256_bytes(
            canonical_json_bytes(
                {
                    "logic_blocks": mod_logic,
                    "setpoints": mod_setpoints,
                    "io_mappings": base_snap.io_mappings,
                }
            )
        )
        snap_dict["program_version"] = "v1.4.0-unauth"
        snap_dict["logic_blocks"] = mod_logic
        snap_dict["setpoints"] = mod_setpoints
        snap_dict["program_hash"] = mod_hash
        snap_dict["operating_mode"] = "REMOTE_PROG"
        ews_records.append(
            {
                "event_id": "EWS-UNAUTH-701",
                "timestamp": (t0 + timedelta(seconds=8)).isoformat(),
                "workstation_id": "EWS-01",
                "operator_id": "unknown_session_user",
                "action": "program_download",
                "target_asset_id": "PLC-101",
                "session_id": "SESS-ANON-909",
                "outcome": "success",
                "artifact_hash": mod_hash,
            }
        )
        ground_truth = {
            "should_alert": True,
            "expected_categories": [
                FindingCategory.UNEXPECTED_PROGRAM_CHANGE.value,
                FindingCategory.MISSING_MAINTENANCE_AUTH.value,
                FindingCategory.UNEXPLAINED_STATE_TRANSITION.value,
                FindingCategory.COMMAND_OBSERVATION_MISMATCH.value,
            ],
            "expected_hypothesis": HypothesisClass.POSSIBLE_UNAUTHORISED_ACTIVITY.value,
            "description": "Unapproved PLC logic & setpoint modification outside maintenance window correlated with mode transition and flow mismatch.",
        }
    elif scenario == "inconsistent_observations":
        ground_truth = {
            "should_alert": True,
            "expected_categories": [FindingCategory.COMMAND_OBSERVATION_MISMATCH.value],
            "expected_hypothesis": HypothesisClass.EQUIPMENT_OR_SENSOR_FAULT.value,
            "description": "Pump P-101 commanded ON while FT-101 reports zero flow without controller configuration change.",
        }
    else:
        raise ValueError(f"Unhandled scenario {scenario}")

    telemetry = _generate_telemetry_series(scenario=scenario, base_time=t0)

    return {
        "schema_version": SCHEMA_VERSION,
        "laboratory_only": True,
        "scenario": scenario,
        "ground_truth": ground_truth,
        "inventory": default_inventory_payload(),
        "baseline_snapshot": base_snap.to_dict(),
        "snapshot": snap_dict,
        "ews_audit": {"records": ews_records},
        "maintenance": {"records": maintenance_records},
        "telemetry": {"observations": telemetry},
    }
