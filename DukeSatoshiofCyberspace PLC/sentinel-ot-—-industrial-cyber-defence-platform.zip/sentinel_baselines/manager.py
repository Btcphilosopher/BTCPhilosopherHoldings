"""Signed trusted baselines, dual-approval workflow, and structural comparison."""

from __future__ import annotations

import hmac
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any

from sentinel_integrity.auth import AuthSession
from sentinel_integrity.crypto import KeyRing, canonical_json_bytes, sha256_bytes, utc_now_iso
from sentinel_types import (
    AuthorizationError,
    BaselineClassification,
    BaselineComparisonResult,
    BaselineDocumentRef,
    BaselineManifest,
    ControllerSnapshot,
    IntegrityError,
    Role,
    SCHEMA_VERSION,
    StructuralDiffItem,
    ValidationError,
)

SUPPORTED_SNAPSHOT_FORMATS = frozenset({"sentinel_plc_json_v1", "plcopen_structured_json_v1"})


@dataclass(frozen=True)
class BaselineDraft:
    baseline_id: str
    asset_id: str
    version: str
    effective_from: str
    effective_until: str
    prepared_by: str
    documents: tuple[BaselineDocumentRef, ...]
    expected_firmware: str
    expected_program_version: str
    expected_program_hash: str
    expected_logic_blocks: dict[str, str]
    expected_setpoints: dict[str, float | int | bool | str]
    expected_io_mappings: dict[str, str]
    created_at: str

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["documents"] = [doc.to_dict() for doc in self.documents]
        return d


def _parse_iso(ts: str) -> datetime:
    dt = datetime.fromisoformat(ts)
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def prepare_baseline_draft(
    session: AuthSession,
    *,
    baseline_id: str,
    asset_id: str,
    version: str,
    effective_from: str,
    effective_until: str,
    documents: list[BaselineDocumentRef],
    snapshot: ControllerSnapshot,
) -> BaselineDraft:
    """Create an unsigned baseline draft; requires BASELINE_PREPARER (or ADMIN) role."""
    if Role.BASELINE_PREPARER not in session.roles and Role.ADMIN not in session.roles:
        raise AuthorizationError(
            "Role 'baseline_preparer' required to prepare a baseline draft.",
            component="sentinel_baselines",
            operation="prepare_baseline_draft",
        )
    if _parse_iso(effective_until) <= _parse_iso(effective_from):
        raise ValidationError(
            "effective_until must be strictly after effective_from.",
            component="sentinel_baselines",
            operation="prepare_baseline_draft",
        )
    if snapshot.asset_id != asset_id:
        raise ValidationError(
            f"Snapshot asset_id '{snapshot.asset_id}' does not match '{asset_id}'.",
            component="sentinel_baselines",
            operation="prepare_baseline_draft",
        )
    return BaselineDraft(
        baseline_id=baseline_id,
        asset_id=asset_id,
        version=version,
        effective_from=effective_from,
        effective_until=effective_until,
        prepared_by=session.user_id,
        documents=tuple(documents),
        expected_firmware=snapshot.firmware_version,
        expected_program_version=snapshot.program_version,
        expected_program_hash=snapshot.program_hash,
        expected_logic_blocks=dict(snapshot.logic_blocks),
        expected_setpoints=dict(snapshot.setpoints),
        expected_io_mappings=dict(snapshot.io_mappings),
        created_at=utc_now_iso(),
    )


def _manifest_signing_body(manifest_dict: dict[str, Any]) -> dict[str, Any]:
    excluded = {"manifest_sha256", "signature", "signer_key_id"}
    return {k: v for k, v in manifest_dict.items() if k not in excluded}


def approve_and_sign_baseline(
    session: AuthSession,
    draft: BaselineDraft,
    *,
    approval_reference: str,
    keyring: KeyRing,
    key_id: str,
) -> BaselineManifest:
    """Approve and cryptographically sign a baseline draft enforcing dual control."""
    if Role.BASELINE_APPROVER not in session.roles and Role.ADMIN not in session.roles:
        raise AuthorizationError(
            "Role 'baseline_approver' required to approve a baseline.",
            component="sentinel_baselines",
            operation="approve_and_sign_baseline",
        )
    if session.user_id == draft.prepared_by:
        raise AuthorizationError(
            "Dual approval violated: preparer cannot approve their own baseline.",
            component="sentinel_baselines",
            operation="approve_and_sign_baseline",
            details={"user_id": session.user_id, "baseline_id": draft.baseline_id},
        )
    if not approval_reference.strip():
        raise ValidationError(
            "approval_reference is required.",
            component="sentinel_baselines",
            operation="approve_and_sign_baseline",
        )

    provisional = BaselineManifest(
        baseline_id=draft.baseline_id,
        asset_id=draft.asset_id,
        version=draft.version,
        effective_from=draft.effective_from,
        effective_until=draft.effective_until,
        prepared_by=draft.prepared_by,
        approved_by=session.user_id,
        approval_reference=approval_reference,
        documents=draft.documents,
        expected_firmware=draft.expected_firmware,
        expected_program_version=draft.expected_program_version,
        expected_program_hash=draft.expected_program_hash,
        expected_logic_blocks=draft.expected_logic_blocks,
        expected_setpoints=draft.expected_setpoints,
        expected_io_mappings=draft.expected_io_mappings,
        manifest_sha256="",
        signature="",
        signer_key_id=key_id,
        created_at=draft.created_at,
        schema_version=SCHEMA_VERSION,
    )
    body = _manifest_signing_body(provisional.to_dict())
    manifest_sha = sha256_bytes(canonical_json_bytes(body))
    signature = keyring.sign_payload(key_id, {"manifest_sha256": manifest_sha, "body": body})

    return BaselineManifest(
        **{
            **provisional.__dict__,
            "manifest_sha256": manifest_sha,
            "signature": signature,
        }
    )


def verify_baseline_manifest(
    manifest: BaselineManifest,
    keyring: KeyRing,
    *,
    at_time: str | None = None,
) -> bool:
    """Verify dual-approval invariant, SHA-256 checksum, HMAC signature, and effective dates."""
    if manifest.prepared_by == manifest.approved_by:
        raise AuthorizationError(
            "Invalid baseline manifest: preparer and approver must be distinct identities.",
            component="sentinel_baselines",
            operation="verify_baseline_manifest",
        )
    body = _manifest_signing_body(manifest.to_dict())
    expected_sha = sha256_bytes(canonical_json_bytes(body))
    if not hmac.compare_digest(expected_sha, manifest.manifest_sha256):
        raise IntegrityError(
            f"Baseline '{manifest.baseline_id}' manifest SHA-256 mismatch.",
            component="sentinel_baselines",
            operation="verify_baseline_manifest",
        )
    if not keyring.verify_payload(
        manifest.signer_key_id,
        {"manifest_sha256": manifest.manifest_sha256, "body": body},
        manifest.signature,
    ):
        raise IntegrityError(
            f"Baseline '{manifest.baseline_id}' signature verification failed.",
            component="sentinel_baselines",
            operation="verify_baseline_manifest",
        )
    check_dt = _parse_iso(at_time) if at_time else datetime.now(timezone.utc)
    if check_dt < _parse_iso(manifest.effective_from) or check_dt > _parse_iso(manifest.effective_until):
        return False
    return True


def _diff_flat_dict(prefix: str, expected: dict[str, Any], observed: dict[str, Any]) -> list[StructuralDiffItem]:
    diffs: list[StructuralDiffItem] = []
    all_keys = sorted(set(expected.keys()) | set(observed.keys()))
    for key in all_keys:
        path = f"{prefix}.{key}"
        if key not in expected:
            diffs.append(StructuralDiffItem(path=path, change_type="added", baseline_value=None, observed_value=observed[key]))
        elif key not in observed:
            diffs.append(StructuralDiffItem(path=path, change_type="removed", baseline_value=expected[key], observed_value=None))
        elif expected[key] != observed[key]:
            diffs.append(StructuralDiffItem(path=path, change_type="modified", baseline_value=expected[key], observed_value=observed[key]))
    return diffs


def compare_snapshot_to_baseline(
    snapshot: ControllerSnapshot,
    baseline: BaselineManifest | None,
    keyring: KeyRing,
    *,
    comparison_id: str,
) -> BaselineComparisonResult:
    """Compare an imported controller snapshot against its signed baseline."""
    now_iso = utc_now_iso()
    if snapshot.format_type not in SUPPORTED_SNAPSHOT_FORMATS:
        return BaselineComparisonResult(
            comparison_id=comparison_id,
            baseline_id=baseline.baseline_id if baseline else "none",
            snapshot_id=snapshot.snapshot_id,
            asset_id=snapshot.asset_id,
            classification=BaselineClassification.UNSUPPORTED,
            diffs=(),
            rationale=f"Snapshot format '{snapshot.format_type}' is not supported for deterministic structural diffing.",
            safety_disclaimer=(
                "Unsupported format prevents reliable structural comparison; do not assume safety."
            ),
            compared_at=now_iso,
        )

    if baseline is None:
        return BaselineComparisonResult(
            comparison_id=comparison_id,
            baseline_id="none",
            snapshot_id=snapshot.snapshot_id,
            asset_id=snapshot.asset_id,
            classification=BaselineClassification.INCONCLUSIVE,
            diffs=(),
            rationale=f"No signed baseline exists for asset '{snapshot.asset_id}'.",
            safety_disclaimer=(
                "Absence of baseline renders conformance inconclusive; physical safety cannot be inferred."
            ),
            compared_at=now_iso,
        )

    is_effective = verify_baseline_manifest(baseline, keyring, at_time=snapshot.captured_at)
    if not is_effective:
        return BaselineComparisonResult(
            comparison_id=comparison_id,
            baseline_id=baseline.baseline_id,
            snapshot_id=snapshot.snapshot_id,
            asset_id=snapshot.asset_id,
            classification=BaselineClassification.INCONCLUSIVE,
            diffs=(),
            rationale=(
                f"Baseline '{baseline.baseline_id}' is outside its effective window "
                f"({baseline.effective_from} to {baseline.effective_until}) at capture time {snapshot.captured_at}."
            ),
            safety_disclaimer=baseline.safety_disclaimer,
            compared_at=now_iso,
        )

    diffs: list[StructuralDiffItem] = []
    if snapshot.firmware_version != baseline.expected_firmware:
        diffs.append(
            StructuralDiffItem(
                path="firmware_version",
                change_type="modified",
                baseline_value=baseline.expected_firmware,
                observed_value=snapshot.firmware_version,
            )
        )
    if snapshot.program_version != baseline.expected_program_version:
        diffs.append(
            StructuralDiffItem(
                path="program_version",
                change_type="modified",
                baseline_value=baseline.expected_program_version,
                observed_value=snapshot.program_version,
            )
        )
    if snapshot.program_hash != baseline.expected_program_hash:
        diffs.append(
            StructuralDiffItem(
                path="program_hash",
                change_type="modified",
                baseline_value=baseline.expected_program_hash,
                observed_value=snapshot.program_hash,
            )
        )

    diffs.extend(_diff_flat_dict("logic_blocks", baseline.expected_logic_blocks, snapshot.logic_blocks))
    diffs.extend(_diff_flat_dict("setpoints", baseline.expected_setpoints, snapshot.setpoints))
    diffs.extend(_diff_flat_dict("io_mappings", baseline.expected_io_mappings, snapshot.io_mappings))

    if not diffs:
        return BaselineComparisonResult(
            comparison_id=comparison_id,
            baseline_id=baseline.baseline_id,
            snapshot_id=snapshot.snapshot_id,
            asset_id=snapshot.asset_id,
            classification=BaselineClassification.EXPECTED,
            diffs=(),
            rationale=(
                f"Snapshot matches signed baseline '{baseline.baseline_id}' "
                f"(approval ref {baseline.approval_reference})."
            ),
            safety_disclaimer=baseline.safety_disclaimer,
            compared_at=now_iso,
        )

    return BaselineComparisonResult(
        comparison_id=comparison_id,
        baseline_id=baseline.baseline_id,
        snapshot_id=snapshot.snapshot_id,
        asset_id=snapshot.asset_id,
        classification=BaselineClassification.UNAUTHORISED,
        diffs=tuple(diffs),
        rationale=(
            f"Detected {len(diffs)} structural deviation(s) from signed baseline '{baseline.baseline_id}'."
        ),
        safety_disclaimer=baseline.safety_disclaimer,
        compared_at=now_iso,
    )
