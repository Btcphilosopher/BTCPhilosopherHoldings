"""Asset inventory registry and validation for Sentinel OT."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from sentinel_integrity.parser import safe_load_json_file
from sentinel_types import (
    AssetKind,
    AssetRecord,
    Criticality,
    ResourceLimits,
    SCHEMA_VERSION,
    ValidationError,
)


class AssetRegistry:
    """In-memory and JSON-backed registry of authorised OT assets and topology."""

    def __init__(self) -> None:
        self._assets: dict[str, AssetRecord] = {}

    def register(self, record: AssetRecord) -> None:
        if not record.asset_id or not record.name:
            raise ValidationError(
                "AssetRecord requires non-empty asset_id and name.",
                component="sentinel_inventory",
                operation="register",
            )
        self._assets[record.asset_id] = record

    def get(self, asset_id: str) -> AssetRecord | None:
        return self._assets.get(asset_id)

    def require(self, asset_id: str) -> AssetRecord:
        asset = self._assets.get(asset_id)
        if asset is None:
            raise ValidationError(
                f"Unknown asset_id '{asset_id}' not present in authorised inventory.",
                component="sentinel_inventory",
                operation="require",
            )
        return asset

    def list_all(self) -> list[AssetRecord]:
        return sorted(self._assets.values(), key=lambda a: a.asset_id)

    def list_by_zone(self, zone: str) -> list[AssetRecord]:
        return [a for a in self.list_all() if a.zone == zone]

    def related_assets(self, asset_id: str) -> list[AssetRecord]:
        root = self.require(asset_id)
        related: list[AssetRecord] = []
        for cid in root.connected_assets:
            item = self._assets.get(cid)
            if item is not None:
                related.append(item)
        return related

    @classmethod
    def from_dict_list(cls, payload: dict[str, Any]) -> "AssetRegistry":
        if "assets" not in payload or not isinstance(payload["assets"], list):
            raise ValidationError(
                "Inventory payload must contain an 'assets' list.",
                component="sentinel_inventory",
                operation="from_dict_list",
            )
        registry = cls()
        for idx, raw in enumerate(payload["assets"]):
            if not isinstance(raw, dict):
                raise ValidationError(
                    f"Asset entry at index {idx} must be an object.",
                    component="sentinel_inventory",
                    operation="from_dict_list",
                )
            try:
                record = AssetRecord(
                    asset_id=str(raw["asset_id"]),
                    name=str(raw["name"]),
                    kind=AssetKind(str(raw["kind"])),
                    zone=str(raw["zone"]),
                    criticality=Criticality(str(raw["criticality"])),
                    vendor=str(raw.get("vendor", "unknown")),
                    model=str(raw.get("model", "unknown")),
                    firmware_version=str(raw.get("firmware_version", "unknown")),
                    expected_protocol=str(raw.get("expected_protocol", "offline_export")),
                    connected_assets=tuple(str(x) for x in raw.get("connected_assets", [])),
                    schema_version=str(raw.get("schema_version", SCHEMA_VERSION)),
                )
            except (KeyError, ValueError) as exc:
                raise ValidationError(
                    f"Invalid asset record at index {idx}: {exc}",
                    component="sentinel_inventory",
                    operation="from_dict_list",
                ) from exc
            registry.register(record)
        return registry

    @classmethod
    def load_from_file(cls, path: Path, *, limits: ResourceLimits | None = None) -> "AssetRegistry":
        data = safe_load_json_file(path, limits=limits, expected_root_type=dict)
        return cls.from_dict_list(data)
