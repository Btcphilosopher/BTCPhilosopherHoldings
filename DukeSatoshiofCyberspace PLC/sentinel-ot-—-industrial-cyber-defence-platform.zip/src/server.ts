import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {execFile} from 'node:child_process';
import {readFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {promisify} from 'node:util';

const execFileAsync = promisify(execFile);

const browserDistFolder = join(import.meta.dirname, '../browser');
const workspaceRoot = resolve(process.cwd());

const ALLOWED_SCENARIOS = new Set([
  'nominal',
  'planned_maintenance',
  'sensor_fault',
  'stale_telemetry',
  'unapproved_controller_change',
  'inconsistent_observations',
]);

const ALLOWED_DATASET_FILES = new Set([
  'inventory',
  'baseline_snapshot',
  'snapshot',
  'telemetry',
  'ews_audit',
  'maintenance',
  'ground_truth',
]);

const app = express();
app.use(express.json({limit: '1mb'}));
const angularApp = new AngularNodeAppEngine();

async function runPythonCli(args: string[]): Promise<{stdout: string; stderr: string}> {
  return execFileAsync('python3', args, {
    cwd: workspaceRoot,
    timeout: 25000,
    maxBuffer: 4 * 1024 * 1024,
  });
}

app.get('/api/health', (_req, res) => {
  res.json({status: 'ok', service: 'sentinel-ot-console'});
});

app.get('/api/verification-results', async (_req, res) => {
  try {
    const filePath = join(workspaceRoot, 'verification_results.json');
    const raw = await readFile(filePath, 'utf-8');
    res.json(JSON.parse(raw));
  } catch {
    try {
      const {stdout} = await runPythonCli([
        '-m',
        'sentinel_cli.main',
        'lab',
        'run-all',
        '--work-dir',
        '/tmp/sentinel_lab_work',
        '--output',
        'verification_results.json',
      ]);
      res.json(JSON.parse(stdout));
    } catch (err) {
      res.status(500).json({error: 'Failed to load verification results', detail: String(err)});
    }
  }
});

app.post('/api/lab/run', async (_req, res) => {
  try {
    const {stdout} = await runPythonCli([
      '-m',
      'sentinel_cli.main',
      'lab',
      'run-all',
      '--work-dir',
      '/tmp/sentinel_lab_work',
      '--output',
      'verification_results.json',
    ]);
    res.json(JSON.parse(stdout));
  } catch (err) {
    res.status(500).json({error: 'Verification lab execution failed', detail: String(err)});
  }
});

app.post('/api/lab/scenario', async (req, res) => {
  const scenario = String(req.body?.scenario ?? '');
  const simulateInterrupt = Boolean(req.body?.simulateInterrupt);
  const resume = Boolean(req.body?.resume);

  if (!ALLOWED_SCENARIOS.has(scenario)) {
    res.status(400).json({error: `Unsupported scenario: ${scenario}`});
    return;
  }

  const cliArgs = [
    '-m',
    'sentinel_cli.main',
    'lab',
    'run-scenario',
    scenario,
    '--work-dir',
    '/tmp/sentinel_web_console_work',
  ];
  if (simulateInterrupt && !resume) {
    cliArgs.push('--simulate-interrupt');
  }
  if (resume) {
    cliArgs.push('--resume');
  }

  try {
    const {stdout} = await runPythonCli(cliArgs);
    res.json(JSON.parse(stdout));
  } catch (err) {
    res.status(500).json({error: 'Scenario execution failed', detail: String(err)});
  }
});

app.get('/api/datasets/:scenario', async (req, res) => {
  const scenario = String(req.params['scenario'] ?? '');
  if (!ALLOWED_SCENARIOS.has(scenario)) {
    res.status(400).json({error: `Unsupported scenario: ${scenario}`});
    return;
  }
  try {
    const bundle: Record<string, unknown> = {};
    for (const part of ALLOWED_DATASET_FILES) {
      const p = join(workspaceRoot, 'datasets', scenario, `${part}.json`);
      bundle[part] = JSON.parse(await readFile(p, 'utf-8'));
    }
    res.json(bundle);
  } catch (err) {
    res.status(500).json({error: 'Failed to read scenario dataset', detail: String(err)});
  }
});

app.post('/api/tests/run', async (_req, res) => {
  try {
    const {stdout, stderr} = await runPythonCli(['-m', 'unittest', 'discover', '-s', 'tests', '-v']);
    res.json({passed: true, output: `${stdout}\n${stderr}`.trim()});
  } catch (err: unknown) {
    const e = err as {stdout?: string; stderr?: string; message?: string};
    res.status(200).json({
      passed: false,
      output: `${e.stdout ?? ''}\n${e.stderr ?? e.message ?? String(err)}`.trim(),
    });
  }
});

app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) => (response ? writeResponseToNodeResponse(response, res) : next()))
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
