import {ChangeDetectionStrategy, Component, OnInit, computed, inject, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {
  ChecklistItem,
  IncidentCase,
  ScenarioRunResponse,
  SentinelApi,
  TestSuiteResponse,
  VerificationReport,
} from './sentinel.service';

type ConsoleView = 'lab' | 'scenario' | 'evidence' | 'tests';

const SCENARIO_LIST = [
  {id: 'unapproved_controller_change', label: 'Unapproved Controller Change'},
  {id: 'planned_maintenance', label: 'Planned Maintenance'},
  {id: 'sensor_fault', label: 'Sensor Fault'},
  {id: 'stale_telemetry', label: 'Stale Telemetry'},
  {id: 'inconsistent_observations', label: 'Inconsistent Observations'},
  {id: 'nominal', label: 'Nominal Operation'},
] as const;

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  private readonly api = inject(SentinelApi);

  readonly activeView = signal<ConsoleView>('lab');
  readonly scenarios = SCENARIO_LIST;
  readonly selectedScenario = signal<string>('unapproved_controller_change');

  readonly report = signal<VerificationReport | null>(null);
  readonly loadingReport = signal<boolean>(true);
  readonly runningLab = signal<boolean>(false);
  readonly errorMessage = signal<string | null>(null);

  readonly scenarioResult = signal<ScenarioRunResponse | null>(null);
  readonly runningScenario = signal<boolean>(false);
  readonly checklistOverrides = signal<Record<string, boolean>>({});

  readonly testResult = signal<TestSuiteResponse | null>(null);
  readonly runningTests = signal<boolean>(false);

  readonly breadcrumbLabel = computed(() => {
    switch (this.activeView()) {
      case 'lab':
        return 'Verification Laboratory';
      case 'scenario':
        return 'Scenario & Crash Recovery';
      case 'evidence':
        return 'Case & Evidence Custody';
      case 'tests':
        return 'Test Suite & Traceability';
    }
  });

  readonly activeCase = computed<IncidentCase | null>(() => {
    const res = this.scenarioResult();
    return res?.case ?? null;
  });

  readonly checklistItems = computed<ChecklistItem[]>(() => {
    const currentCase = this.activeCase();
    if (!currentCase) {
      return [];
    }
    const overrides = this.checklistOverrides();
    return currentCase.response_checklist.map((item) => ({
      ...item,
      completed: overrides[item.item_id] ?? item.completed,
    }));
  });

  readonly completedChecklistCount = computed(() => {
    return this.checklistItems().filter((i) => i.completed).length;
  });

  ngOnInit(): void {
    this.loadReport();
    this.executeScenario(false, false);
  }

  setView(view: ConsoleView): void {
    this.activeView.set(view);
  }

  selectScenario(scenarioId: string): void {
    this.selectedScenario.set(scenarioId);
    this.checklistOverrides.set({});
    this.executeScenario(false, false);
  }

  loadReport(): void {
    this.loadingReport.set(true);
    this.errorMessage.set(null);
    this.api.getVerificationResults().subscribe({
      next: (data) => {
        this.report.set(data);
        this.loadingReport.set(false);
      },
      error: () => {
        this.errorMessage.set('Unable to load verification results from Python backend.');
        this.loadingReport.set(false);
      },
    });
  }

  triggerLabRun(): void {
    this.runningLab.set(true);
    this.errorMessage.set(null);
    this.api.runVerificationLab().subscribe({
      next: (data) => {
        this.report.set(data);
        this.runningLab.set(false);
      },
      error: () => {
        this.errorMessage.set('Verification laboratory run failed.');
        this.runningLab.set(false);
      },
    });
  }

  executeScenario(simulateInterrupt: boolean, resume: boolean): void {
    this.runningScenario.set(true);
    this.errorMessage.set(null);
    this.api
      .runScenario(this.selectedScenario(), {simulateInterrupt, resume})
      .subscribe({
        next: (res) => {
          this.scenarioResult.set(res);
          this.runningScenario.set(false);
        },
        error: () => {
          this.errorMessage.set('Scenario execution failed.');
          this.runningScenario.set(false);
        },
      });
  }

  toggleChecklistItem(itemId: string): void {
    const current = this.checklistItems().find((i) => i.item_id === itemId);
    const nextVal = !(current?.completed ?? false);
    this.checklistOverrides.update((prev) => ({
      ...prev,
      [itemId]: nextVal,
    }));
  }

  executeTests(): void {
    this.runningTests.set(true);
    this.errorMessage.set(null);
    this.api.runTests().subscribe({
      next: (res) => {
        this.testResult.set(res);
        this.runningTests.set(false);
      },
      error: () => {
        this.errorMessage.set('Failed to run Python test suite.');
        this.runningTests.set(false);
      },
    });
  }

  formatPercent(value: number): string {
    return `${(value * 100).toFixed(1)}%`;
  }

  formatCategory(cat: string): string {
    return cat.split('_').join(' ');
  }

  formatJson(val: unknown): string {
    return JSON.stringify(val);
  }
}
