import {HttpClient} from '@angular/common/http';
import {Injectable, inject} from '@angular/core';
import {Observable} from 'rxjs';

export interface ScenarioEvaluation {
  scenario: string;
  description: string;
  should_alert: boolean;
  alerted: boolean;
  expected_categories: string[];
  observed_categories: string[];
  category_match: boolean;
  expected_hypothesis: string | null;
  observed_hypotheses: string[];
  finding_count: number;
  latency_ms: number;
  package_verified: boolean;
  case_id: string;
}

export interface VerificationReport {
  schema_version: string;
  tool_name: string;
  tool_version: string;
  generated_at: string;
  laboratory_only: boolean;
  summary: {
    total_scenarios: number;
    true_positives: number;
    true_negatives: number;
    false_positives: number;
    false_negatives: number;
    detection_accuracy: number;
    false_positive_rate: number;
    all_packages_verified: boolean;
    all_categories_matched: boolean;
    mean_latency_ms: number;
  };
  first_acceptance_milestone: {
    interrupted_stage: string;
    resumed_status: string;
    resumed_case_id: string;
    resumed_findings_count: number;
    package_verified: boolean;
    handoff_status: string;
  };
  scenarios: ScenarioEvaluation[];
  known_limitations: string[];
}

export interface StructuralDiff {
  path: string;
  change_type: string;
  baseline_value: unknown;
  observed_value: unknown;
}

export interface BaselineComparison {
  comparison_id: string;
  baseline_id: string;
  snapshot_id: string;
  asset_id: string;
  classification: string;
  diffs: StructuralDiff[];
  rationale: string;
  safety_disclaimer: string;
  compared_at: string;
}

export interface DetectionFinding {
  finding_id: string;
  category: string;
  hypothesis: string;
  severity: string;
  asset_id: string;
  title: string;
  summary: string;
  detected_at: string;
  supporting_evidence_ids: string[];
  telemetry_extracts: Record<string, unknown>[];
  alternative_explanations: string[];
  uncertainty_notes: string;
  baseline_diff_refs: string[];
}

export interface ChecklistItem {
  item_id: string;
  step: string;
  owner_role: string;
  completed: boolean;
  notes: string;
}

export interface TimelineEntry {
  timestamp: string;
  source: string;
  event_type: string;
  description: string;
}

export interface IncidentCase {
  case_id: string;
  title: string;
  created_at: string;
  status: string;
  asset_ids: string[];
  findings: DetectionFinding[];
  timeline: TimelineEntry[];
  baseline_comparisons: BaselineComparison[];
  telemetry_extracts: Record<string, unknown>[];
  unresolved_questions: string[];
  response_checklist: ChecklistItem[];
  evidence_ids: string[];
  containment_guardrail: string;
}

export interface ScenarioRunResponse {
  status: 'interrupted' | 'completed';
  run_id: string;
  checkpoint_stage?: string;
  case?: IncidentCase;
  ingestion_metrics?: {
    accepted_count: number;
    duplicate_count: number;
    dropped_count: number;
    data_loss_detected: boolean;
    queue_depth: number;
    queue_capacity: number;
  };
  package_zip?: string;
  package_verification?: {
    verified: boolean;
    case_id: string;
    verified_files: number;
    package_sha256: string;
    provenance_caveat: string;
  };
}

export interface TestSuiteResponse {
  passed: boolean;
  output: string;
}

@Injectable({providedIn: 'root'})
export class SentinelApi {
  private readonly http = inject(HttpClient);

  getVerificationResults(): Observable<VerificationReport> {
    return this.http.get<VerificationReport>('/api/verification-results');
  }

  runVerificationLab(): Observable<VerificationReport> {
    return this.http.post<VerificationReport>('/api/lab/run', {});
  }

  runScenario(
    scenario: string,
    options: {simulateInterrupt?: boolean; resume?: boolean} = {},
  ): Observable<ScenarioRunResponse> {
    return this.http.post<ScenarioRunResponse>('/api/lab/scenario', {
      scenario,
      simulateInterrupt: Boolean(options.simulateInterrupt),
      resume: Boolean(options.resume),
    });
  }

  getDataset(scenario: string): Observable<Record<string, unknown>> {
    return this.http.get<Record<string, unknown>>(`/api/datasets/${scenario}`);
  }

  runTests(): Observable<TestSuiteResponse> {
    return this.http.post<TestSuiteResponse>('/api/tests/run', {});
  }
}
