# DUKE SATOSHI OF CYBERSPACE — SENTINEL OT
## Operator Runbook

### 1. Operational Boundaries & Safety Invariants
- **Read-Only & Offline First**: Sentinel OT analyzes offline exports (controller snapshots, EWS audit logs, asset inventories, process telemetry, maintenance records) and explicitly configured read-only adapters (`sentinel_adapters`). Controller write commands (`write_register`, `write_coil`, `upload_program`, `send_command`) are structurally blocked (`AdapterReadOnlyError`).
- **No Automated Physical/Network Actions**: Sentinel OT **never** automatically isolates controllers, stops machinery, or alters PLC configurations. Any consequential action requires an authorised external operational process and change-control sign-off.
- **Equipment Protection Independence**: Safety Instrumented Systems (SIS), hardwired interlocks, and emergency shutdown systems must remain physically and logically independent of Sentinel OT. A Sentinel OT failure does not interfere with control loop execution.
- **Baseline Agreement != Safety**: Agreement between a snapshot and a signed baseline confirms configuration correspondence at capture time only; it does **not** prove physical process safety or absence of risk.

### 2. Installation & Air-Gapped Verification
```bash
bash scripts/install.sh
bash scripts/verify.sh
```
Core runtime requires only Python 3.11+ standard library modules (`requirements.lock`), avoiding external PyPI supply-chain exposure in air-gapped OT enclaves.

### 3. Role-Based Access & Dual Approval
- `collector`: Preserves raw exports into the write-once `EvidenceVault`.
- `baseline_preparer`: Creates unsigned `BaselineDraft` records.
- `baseline_approver`: Reviews and signs `BaselineManifest` records. Self-approval (`prepared_by == approved_by`) is rejected.
- `analyst`: Executes correlation pipelines and compiles `IncidentCase` packages.
- `case_approver`: Records formal operational handoff sign-off.
- `auditor`: Inspects hash-chained audit logs (`audit_chain.jsonl`) and verifies exported evidence packages.

### 4. Standard Offline Investigation Workflow
1. **Export Datasets / Collect Offline Bundles**: Ensure source bundles follow `schemas/` contracts and originate from authorised read-only exports.
2. **Ingest & Preserve Evidence**: `EvidenceVault` writes original bytes unmodified with `0o444` permissions, computing SHA-256 and SHA-512 hashes and appending to `audit_chain.jsonl`.
3. **Run Correlation Analysis**:
   ```bash
   python3 -m sentinel_cli.main analyze-bundle datasets/unapproved_controller_change --run-id INC-001
   ```
4. **Interrupted Analysis Recovery**:
   If a worker crashes or is interrupted (`--simulate-interrupt`), SQLite WAL checkpoints preserve `INGESTED`, `BASELINES_VERIFIED`, and `CORRELATED` stages. Resume cleanly without duplicating findings:
   ```bash
   python3 -m sentinel_cli.main analyze-bundle datasets/unapproved_controller_change --run-id INC-001 --resume
   ```
5. **Review Incident Case & Verify Package**:
   - Inspect timeline, structural baseline diffs, alternative explanations, and unresolved questions.
   - Complete the 4-step human response checklist (verify local physical gauges, confirm badge/EWS logs, compare PLC project offline, obtain Change Control approval).
   - Independently verify the exported `.sotpkg.zip` package before archival or handoff.

### 5. Evidence Custody & Limitations
- **Timestamps**: Source timestamps reflect upstream OT/EWS/historian clocks, which may drift or lack cryptographic authentication prior to collection. Receipt timestamps reflect the Sentinel OT host clock at ingestion.
- **Signatures**: HMAC-SHA256 signatures attest to possession of the Sentinel signing key at signing/export time; they do not guarantee upstream artifact truthfulness before receipt.
- **Legal Admissibility**: Sentinel OT provides reproducible hashing, write-once preservation, and chain-of-custody metadata, but does **not** automatically confer legal admissibility without jurisdictional chain-of-custody procedures.

### 6. Encrypted Backups & Retention
```bash
python3 -m sentinel_cli.main backup create .sentinel_work /secure/backups/sentinel.sotbak --passphrase "<STRONG_PASSPHRASE>"
python3 -m sentinel_cli.main backup restore /secure/backups/sentinel.sotbak /restore/target --passphrase "<STRONG_PASSPHRASE>"
```
Logs automatically redact `password`, `passphrase`, `secret`, `token`, `authorization`, and bearer patterns.
