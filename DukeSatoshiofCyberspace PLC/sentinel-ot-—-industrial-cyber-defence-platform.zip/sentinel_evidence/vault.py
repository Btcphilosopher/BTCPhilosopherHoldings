"""Immutable evidence preservation, hash-chained audit history, and verifiable export packages."""

from __future__ import annotations

import hmac
import json
import os
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from sentinel_integrity.crypto import (
    KeyRing,
    canonical_json_bytes,
    sha256_bytes,
    sha512_bytes,
    utc_now_iso,
)
from sentinel_integrity.parser import ensure_within_base_dir, safe_load_json_bytes, safe_read_zip_entries
from sentinel_types import (
    EvidenceRecord,
    IntegrityError,
    ResourceLimitError,
    ResourceLimits,
    SCHEMA_VERSION,
    TOOL_NAME,
    TOOL_VERSION,
)

DEFAULT_PROVENANCE_CAVEAT = (
    "Evidence preservation guarantees byte-level integrity from receipt time onward via SHA-256/SHA-512 "
    "hashes and keyring signatures. Source timestamps originate from upstream OT/EWS clocks that may "
    "drift or lack cryptographic authentication prior to collection. Signatures attest to signing-key "
    "possession at export time and do not automatically confer legal admissibility."
)


@dataclass(frozen=True)
class AuditEntry:
    seq: int
    timestamp: str
    actor: str
    action: str
    target_id: str
    details: dict[str, Any]
    prev_hash: str
    entry_hash: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class AuditChain:
    """Append-only SHA-256 hash-chained audit trail."""

    GENESIS_HASH = "0" * 64

    def __init__(self, log_path: Path) -> None:
        self._log_path = log_path
        self._log_path.parent.mkdir(parents=True, exist_ok=True)

    def _load_entries(self) -> list[AuditEntry]:
        if not self._log_path.exists():
            return []
        entries: list[AuditEntry] = []
        for line in self._log_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            obj = json.loads(line)
            entries.append(AuditEntry(**obj))
        return entries

    def append(self, *, actor: str, action: str, target_id: str, details: dict[str, Any] | None = None) -> AuditEntry:
        existing = self._load_entries()
        seq = len(existing) + 1
        prev_hash = existing[-1].entry_hash if existing else self.GENESIS_HASH
        ts = utc_now_iso()
        body = {
            "seq": seq,
            "timestamp": ts,
            "actor": actor,
            "action": action,
            "target_id": target_id,
            "details": details or {},
            "prev_hash": prev_hash,
        }
        entry_hash = sha256_bytes(canonical_json_bytes(body))
        entry = AuditEntry(**body, entry_hash=entry_hash)
        with self._log_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry.to_dict(), sort_keys=True) + "\n")
        return entry

    def verify(self) -> tuple[bool, int]:
        entries = self._load_entries()
        expected_prev = self.GENESIS_HASH
        for idx, entry in enumerate(entries, start=1):
            if entry.seq != idx or entry.prev_hash != expected_prev:
                raise IntegrityError(
                    f"Audit chain discontinuity at sequence {entry.seq}.",
                    component="sentinel_evidence",
                    operation="audit_chain_verify",
                )
            body = {
                "seq": entry.seq,
                "timestamp": entry.timestamp,
                "actor": entry.actor,
                "action": entry.action,
                "target_id": entry.target_id,
                "details": entry.details,
                "prev_hash": entry.prev_hash,
            }
            actual_hash = sha256_bytes(canonical_json_bytes(body))
            if not hmac.compare_digest(actual_hash, entry.entry_hash):
                raise IntegrityError(
                    f"Audit chain hash mismatch at sequence {entry.seq}.",
                    component="sentinel_evidence",
                    operation="audit_chain_verify",
                )
            expected_prev = entry.entry_hash
        return True, len(entries)

    def entries(self) -> list[AuditEntry]:
        return self._load_entries()


class EvidenceVault:
    """Write-once immutable storage for original OT artifacts and manifests."""

    def __init__(self, root_dir: Path, *, limits: ResourceLimits | None = None) -> None:
        self._root_dir = root_dir.resolve()
        self._raw_dir = self._root_dir / "raw"
        self._manifest_dir = self._root_dir / "manifests"
        self._raw_dir.mkdir(parents=True, exist_ok=True)
        self._manifest_dir.mkdir(parents=True, exist_ok=True)
        self._limits = limits or ResourceLimits()
        self.audit = AuditChain(self._root_dir / "audit_chain.jsonl")

    def preserve_bytes(
        self,
        *,
        evidence_id: str,
        artifact_type: str,
        original_filename: str,
        raw_bytes: bytes,
        collection_method: str,
        custodian: str,
        source_timestamps: list[str] | tuple[str, ...],
        processing_step: str = "ingested_unmodified",
    ) -> EvidenceRecord:
        if len(raw_bytes) > self._limits.max_input_bytes:
            raise ResourceLimitError(
                f"Evidence payload '{original_filename}' exceeds max_input_bytes.",
                component="sentinel_evidence",
                operation="preserve_bytes",
            )
        safe_name = Path(original_filename).name or "artifact.bin"
        sha256 = sha256_bytes(raw_bytes)
        sha512 = sha512_bytes(raw_bytes)
        rel_blob = f"{evidence_id}_{sha256[:12]}_{safe_name}"
        blob_path = ensure_within_base_dir(self._raw_dir, self._raw_dir / rel_blob)
        manifest_path = ensure_within_base_dir(self._manifest_dir, self._manifest_dir / f"{evidence_id}.json")

        if manifest_path.exists():
            existing = safe_load_json_bytes(manifest_path.read_bytes(), limits=self._limits)
            if existing.get("sha256") != sha256:
                raise IntegrityError(
                    f"Write-once violation: evidence_id '{evidence_id}' already exists with a different hash.",
                    component="sentinel_evidence",
                    operation="preserve_bytes",
                )
            return self.get_manifest(evidence_id)

        blob_path.write_bytes(raw_bytes)
        os.chmod(blob_path, 0o444)

        record = EvidenceRecord(
            evidence_id=evidence_id,
            artifact_type=artifact_type,
            original_filename=safe_name,
            vault_path=str(blob_path.relative_to(self._root_dir)),
            sha256=sha256,
            sha512=sha512,
            byte_size=len(raw_bytes),
            collection_method=collection_method,
            receipt_timestamp=utc_now_iso(),
            source_timestamps=tuple(source_timestamps),
            custodian=custodian,
            tool_name=TOOL_NAME,
            tool_version=TOOL_VERSION,
            processing_history=(f"{utc_now_iso()}:{processing_step}",),
            provenance_caveat=DEFAULT_PROVENANCE_CAVEAT,
            schema_version=SCHEMA_VERSION,
        )
        manifest_path.write_bytes(canonical_json_bytes(record.to_dict()))
        os.chmod(manifest_path, 0o444)
        self.audit.append(
            actor=custodian,
            action="evidence_preserved",
            target_id=evidence_id,
            details={"sha256": sha256, "artifact_type": artifact_type, "collection_method": collection_method},
        )
        return record

    def preserve_file(
        self,
        *,
        evidence_id: str,
        artifact_type: str,
        source_path: Path,
        collection_method: str,
        custodian: str,
        source_timestamps: list[str] | tuple[str, ...],
    ) -> EvidenceRecord:
        if not source_path.exists() or not source_path.is_file() or source_path.is_symlink():
            raise IntegrityError(
                f"Invalid source evidence file: {source_path}",
                component="sentinel_evidence",
                operation="preserve_file",
            )
        size = source_path.stat().st_size
        if size > self._limits.max_input_bytes:
            raise ResourceLimitError(
                f"Source file '{source_path.name}' ({size} bytes) exceeds limit.",
                component="sentinel_evidence",
                operation="preserve_file",
            )
        return self.preserve_bytes(
            evidence_id=evidence_id,
            artifact_type=artifact_type,
            original_filename=source_path.name,
            raw_bytes=source_path.read_bytes(),
            collection_method=collection_method,
            custodian=custodian,
            source_timestamps=source_timestamps,
        )

    def get_manifest(self, evidence_id: str) -> EvidenceRecord:
        manifest_path = ensure_within_base_dir(self._manifest_dir, self._manifest_dir / f"{evidence_id}.json")
        if not manifest_path.exists():
            raise IntegrityError(
                f"Evidence manifest not found: {evidence_id}",
                component="sentinel_evidence",
                operation="get_manifest",
            )
        data = safe_load_json_bytes(manifest_path.read_bytes(), limits=self._limits)
        return EvidenceRecord(
            evidence_id=data["evidence_id"],
            artifact_type=data["artifact_type"],
            original_filename=data["original_filename"],
            vault_path=data["vault_path"],
            sha256=data["sha256"],
            sha512=data["sha512"],
            byte_size=int(data["byte_size"]),
            collection_method=data["collection_method"],
            receipt_timestamp=data["receipt_timestamp"],
            source_timestamps=tuple(data["source_timestamps"]),
            custodian=data["custodian"],
            tool_name=data["tool_name"],
            tool_version=data["tool_version"],
            processing_history=tuple(data["processing_history"]),
            provenance_caveat=data["provenance_caveat"],
            schema_version=data.get("schema_version", SCHEMA_VERSION),
        )

    def verify_record(self, evidence_id: str) -> bool:
        rec = self.get_manifest(evidence_id)
        blob_path = ensure_within_base_dir(self._root_dir, self._root_dir / rec.vault_path)
        if not blob_path.exists():
            raise IntegrityError(
                f"Evidence blob missing for '{evidence_id}'.",
                component="sentinel_evidence",
                operation="verify_record",
            )
        raw = blob_path.read_bytes()
        if not hmac.compare_digest(sha256_bytes(raw), rec.sha256):
            raise IntegrityError(
                f"Evidence SHA-256 mismatch for '{evidence_id}'.",
                component="sentinel_evidence",
                operation="verify_record",
            )
        if not hmac.compare_digest(sha512_bytes(raw), rec.sha512):
            raise IntegrityError(
                f"Evidence SHA-512 mismatch for '{evidence_id}'.",
                component="sentinel_evidence",
                operation="verify_record",
            )
        return True

    def read_raw_bytes(self, evidence_id: str) -> bytes:
        self.verify_record(evidence_id)
        rec = self.get_manifest(evidence_id)
        blob_path = ensure_within_base_dir(self._root_dir, self._root_dir / rec.vault_path)
        return blob_path.read_bytes()

    def export_evidence_package(
        self,
        *,
        output_zip: Path,
        evidence_ids: list[str],
        case_payload: dict[str, Any],
        keyring: KeyRing,
        key_id: str,
        custodian: str,
    ) -> dict[str, Any]:
        """Export a self-contained, hash-verified, signed investigation ZIP package."""
        self.audit.verify()
        file_hashes: dict[str, dict[str, str]] = {}
        package_files: dict[str, bytes] = {}

        for eid in sorted(set(evidence_ids)):
            self.verify_record(eid)
            rec = self.get_manifest(eid)
            raw_bytes = self.read_raw_bytes(eid)
            raw_arc = f"evidence/raw/{Path(rec.vault_path).name}"
            man_arc = f"evidence/manifests/{eid}.json"
            man_bytes = canonical_json_bytes(rec.to_dict())
            package_files[raw_arc] = raw_bytes
            package_files[man_arc] = man_bytes
            file_hashes[raw_arc] = {"sha256": sha256_bytes(raw_bytes), "sha512": sha512_bytes(raw_bytes)}
            file_hashes[man_arc] = {"sha256": sha256_bytes(man_bytes), "sha512": sha512_bytes(man_bytes)}

        case_bytes = canonical_json_bytes(case_payload)
        package_files["case/incident_case.json"] = case_bytes
        file_hashes["case/incident_case.json"] = {
            "sha256": sha256_bytes(case_bytes),
            "sha512": sha512_bytes(case_bytes),
        }

        audit_bytes = canonical_json_bytes([e.to_dict() for e in self.audit.entries()])
        package_files["audit/audit_chain.json"] = audit_bytes
        file_hashes["audit/audit_chain.json"] = {
            "sha256": sha256_bytes(audit_bytes),
            "sha512": sha512_bytes(audit_bytes),
        }

        pkg_body = {
            "schema_version": SCHEMA_VERSION,
            "tool_name": TOOL_NAME,
            "tool_version": TOOL_VERSION,
            "exported_at": utc_now_iso(),
            "custodian": custodian,
            "case_id": case_payload.get("case_id"),
            "evidence_count": len(set(evidence_ids)),
            "file_hashes": file_hashes,
            "provenance_caveat": DEFAULT_PROVENANCE_CAVEAT,
        }
        pkg_sha256 = sha256_bytes(canonical_json_bytes(pkg_body))
        signature = keyring.sign_payload(key_id, {"package_sha256": pkg_sha256, "body": pkg_body})
        package_manifest = {
            "body": pkg_body,
            "package_sha256": pkg_sha256,
            "signer_key_id": key_id,
            "signature": signature,
        }
        package_files["package_manifest.json"] = canonical_json_bytes(package_manifest)

        output_zip.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(output_zip, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
            for arcname in sorted(package_files.keys()):
                zf.writestr(arcname, package_files[arcname])

        self.audit.append(
            actor=custodian,
            action="evidence_package_exported",
            target_id=str(case_payload.get("case_id", "unknown")),
            details={"output_zip": output_zip.name, "package_sha256": pkg_sha256},
        )
        return package_manifest


def verify_evidence_package(
    package_zip: Path,
    keyring: KeyRing,
    *,
    limits: ResourceLimits | None = None,
) -> dict[str, Any]:
    """Independently verify signature, file hashes, and audit chain inside an exported package."""
    entries = safe_read_zip_entries(package_zip, limits=limits)
    if "package_manifest.json" not in entries:
        raise IntegrityError(
            "Exported package missing 'package_manifest.json'.",
            component="sentinel_evidence",
            operation="verify_evidence_package",
        )
    manifest = safe_load_json_bytes(entries["package_manifest.json"], limits=limits)
    for req in ("body", "package_sha256", "signer_key_id", "signature"):
        if req not in manifest:
            raise IntegrityError(
                f"Package manifest missing '{req}'.",
                component="sentinel_evidence",
                operation="verify_evidence_package",
            )
    actual_pkg_sha = sha256_bytes(canonical_json_bytes(manifest["body"]))
    if not hmac.compare_digest(actual_pkg_sha, str(manifest["package_sha256"])):
        raise IntegrityError(
            "Package manifest SHA-256 mismatch.",
            component="sentinel_evidence",
            operation="verify_evidence_package",
        )
    if not keyring.verify_payload(
        str(manifest["signer_key_id"]),
        {"package_sha256": manifest["package_sha256"], "body": manifest["body"]},
        str(manifest["signature"]),
    ):
        raise IntegrityError(
            "Package manifest signature verification failed.",
            component="sentinel_evidence",
            operation="verify_evidence_package",
        )

    file_hashes = manifest["body"].get("file_hashes", {})
    for arcname, expected_hashes in file_hashes.items():
        if arcname not in entries:
            raise IntegrityError(
                f"Package missing declared file '{arcname}'.",
                component="sentinel_evidence",
                operation="verify_evidence_package",
            )
        raw = entries[arcname]
        if not hmac.compare_digest(sha256_bytes(raw), expected_hashes["sha256"]):
            raise IntegrityError(
                f"SHA-256 mismatch inside package for '{arcname}'.",
                component="sentinel_evidence",
                operation="verify_evidence_package",
            )
        if not hmac.compare_digest(sha512_bytes(raw), expected_hashes["sha512"]):
            raise IntegrityError(
                f"SHA-512 mismatch inside package for '{arcname}'.",
                component="sentinel_evidence",
                operation="verify_evidence_package",
            )

    # Verify included audit chain continuity
    if "audit/audit_chain.json" in entries:
        audit_list = safe_load_json_bytes(entries["audit/audit_chain.json"], limits=limits, expected_root_type=list)
        prev_hash = AuditChain.GENESIS_HASH
        for idx, item in enumerate(audit_list, start=1):
            if item.get("seq") != idx or item.get("prev_hash") != prev_hash:
                raise IntegrityError(
                    f"Exported audit chain broken at sequence {idx}.",
                    component="sentinel_evidence",
                    operation="verify_evidence_package",
                )
            body = {
                "seq": item["seq"],
                "timestamp": item["timestamp"],
                "actor": item["actor"],
                "action": item["action"],
                "target_id": item["target_id"],
                "details": item["details"],
                "prev_hash": item["prev_hash"],
            }
            if not hmac.compare_digest(sha256_bytes(canonical_json_bytes(body)), item["entry_hash"]):
                raise IntegrityError(
                    f"Exported audit entry hash mismatch at sequence {idx}.",
                    component="sentinel_evidence",
                    operation="verify_evidence_package",
                )
            prev_hash = item["entry_hash"]

    return {
        "verified": True,
        "case_id": manifest["body"].get("case_id"),
        "verified_files": len(file_hashes),
        "package_sha256": manifest["package_sha256"],
        "provenance_caveat": manifest["body"].get("provenance_caveat"),
    }
