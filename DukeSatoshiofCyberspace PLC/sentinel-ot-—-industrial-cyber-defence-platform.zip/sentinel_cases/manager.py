"""Incident case generation, analyst approval records, and checkpointed crash recovery."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from sentinel_integrity.auth import AuthSession
from sentinel_integrity.crypto import canonical_json_bytes, utc_now_iso
from sentinel_types import (
    AuthorizationError,
    BaselineClassification,
    BaselineComparisonResult,
    CaseApprovalRecord,
    CaseStatus,
    ChecklistItem,
    ControllerSnapshot,
    DetectionFinding,
    EWSAuditRecord,
    MaintenanceRecord,
    RecoveryError,
    Role,
    SCHEMA_VERSION,
    IncidentCase,
    TelemetryObservation,
    TimelineEntry,
)


class AnalysisCheckpointStore:
    """SQLite WAL-mode checkpoint store enabling clean restart recovery after interrupted analysis."""

    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=FULL;")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS analysis_runs (
                    run_id TEXT PRIMARY KEY,
                    stage TEXT NOT NULL,
                    state_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    interrupted INTEGER NOT NULL DEFAULT 0
                );
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS incident_cases (
                    case_id TEXT PRIMARY KEY,
                    run_id TEXT NOT NULL,
                    case_json TEXT NOT NULL,
                    status TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                """
            )

    def save_checkpoint(self, run_id: str, stage: str, state: dict[str, Any], *, interrupted: bool = False) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO analysis_runs (run_id, stage, state_json, updated_at, interrupted)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(run_id) DO UPDATE SET
                    stage = excluded.stage,
                    state_json = excluded.state_json,
                    updated_at = excluded.updated_at,
                    interrupted = excluded.interrupted;
                """,
                (run_id, stage, canonical_json_bytes(state).decode("utf-8"), utc_now_iso(), int(interrupted)),
            )

    def load_checkpoint(self, run_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT stage, state_json, updated_at, interrupted FROM analysis_runs WHERE run_id = ?",
                (run_id,),
            ).fetchone()
        if row is None:
            return None
        return {
            "run_id": run_id,
            "stage": row[0],
            "state": json.loads(row[1]),
            "updated_at": row[2],
            "interrupted": bool(row[3]),
        }

    def save_case(self, run_id: str, case: IncidentCase) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO incident_cases (case_id, run_id, case_json, status, updated_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(case_id) DO UPDATE SET
                    case_json = excluded.case_json,
                    status = excluded.status,
                    updated_at = excluded.updated_at;
                """,
                (case.case_id, run_id, canonical_json_bytes(case.to_dict()).decode("utf-8"), case.status.value, utc_now_iso()),
            )

    def load_case(self, case_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT case_json FROM incident_cases WHERE case_id = ?", (case_id,)).fetchone()
        if row is None:
            raise RecoveryError(
                f"Incident case '{case_id}' not found.",
                component="sentinel_cases",
                operation="load_case",
            )
        return json.loads(row[0])

    def list_cases(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT case_json FROM incident_cases ORDER BY updated_at DESC").fetchall()
        return [json.loads(r[0]) for r in rows]


def build_incident_case(
    *,
    case_id: str,
    title: str,
    findings: list[DetectionFinding],
    baseline_comparisons: list[BaselineComparisonResult],
    snapshots: list[ControllerSnapshot],
    ews_records: list[EWSAuditRecord],
    maintenance_records: list[MaintenanceRecord],
    telemetry: list[TelemetryObservation],
    evidence_ids: list[str],
    dropped_telemetry_count: int = 0,
) -> IncidentCase:
    """Assemble a human-reviewable incident case without executing any OT control actions."""
    timeline: list[TimelineEntry] = []
    for m in maintenance_records:
        timeline.append(
            TimelineEntry(
                timestamp=m.window_start,
                source="maintenance_registry",
                event_type="maintenance_window_start",
                description=f"Work order {m.work_order_id} ({m.asset_id}): {m.scope} [approved by {m.approved_by}]",
            )
        )
    for e in ews_records:
        timeline.append(
            TimelineEntry(
                timestamp=e.timestamp,
                source=e.workstation_id,
                event_type=f"ews_{e.action}",
                description=f"Operator {e.operator_id} executed {e.action} on {e.target_asset_id} (session {e.session_id}, outcome {e.outcome})",
            )
        )
    for s in snapshots:
        timeline.append(
            TimelineEntry(
                timestamp=s.captured_at,
                source=s.source_identity,
                event_type="controller_snapshot",
                description=f"Snapshot {s.snapshot_id} for {s.asset_id} (program {s.program_version}, mode {s.operating_mode}, hash {s.program_hash[:12]})",
            )
        )
    for f in findings:
        timeline.append(
            TimelineEntry(
                timestamp=f.detected_at,
                source="sentinel_detection",
                event_type=f.category.value,
                description=f"{f.title} [{f.hypothesis.value}]",
            )
        )
    timeline.sort(key=lambda t: t.timestamp)

    asset_ids = sorted({f.asset_id for f in findings} | {b.asset_id for b in baseline_comparisons})

    unresolved: list[str] = []
    if any(c.classification == BaselineClassification.UNAUTHORISED for c in baseline_comparisons):
        unresolved.append("Confirm with plant engineering whether an undocumented emergency change occurred outside change-control records.")
    if any(f.category.value == "stale_or_missing_observation" for f in findings) or dropped_telemetry_count > 0:
        unresolved.append(f"Account for missing/dropped telemetry ({dropped_telemetry_count} queue drops) during the observation window.")
    if ews_records:
        unresolved.append("Verify engineering workstation physical badge logs against EWS session operator IDs.")
    unresolved.append("Perform local physical gauge/sight-glass verification to rule out instrumentation fault versus logic manipulation.")

    checklist = (
        ChecklistItem(
            item_id="CHK-01",
            step="Verify evidence manifest hashes and source clock offsets before escalating.",
            owner_role="analyst",
        ),
        ChecklistItem(
            item_id="CHK-02",
            step="Compare controller program diff offline against engineering archive on air-gapped EWS.",
            owner_role="analyst",
        ),
        ChecklistItem(
            item_id="CHK-03",
            step="Confirm physical tank level and pump status locally with shift operations.",
            owner_role="operations_engineer",
        ),
        ChecklistItem(
            item_id="CHK-04",
            step="Execute authorised change-control or safe-state procedure externally if restoration is required.",
            owner_role="case_approver",
        ),
    )

    extracts: list[dict[str, Any]] = []
    for f in findings:
        for ex in f.telemetry_extracts[:5]:
            extracts.append({"finding_id": f.finding_id, **ex})
    if not extracts and telemetry:
        for obs in telemetry[:10]:
            extracts.append(obs.to_dict())

    return IncidentCase(
        case_id=case_id,
        title=title,
        created_at=utc_now_iso(),
        status=CaseStatus.OPEN,
        asset_ids=tuple(asset_ids),
        findings=tuple(findings),
        timeline=tuple(timeline),
        baseline_comparisons=tuple(baseline_comparisons),
        telemetry_extracts=tuple(extracts[:25]),
        unresolved_questions=tuple(unresolved),
        response_checklist=checklist,
        evidence_ids=tuple(sorted(set(evidence_ids))),
        approvals=(),
        schema_version=SCHEMA_VERSION,
    )


def approve_incident_case(
    session: AuthSession,
    case: IncidentCase,
    *,
    decision: str,
    rationale: str,
    operational_handoff_ref: str,
) -> IncidentCase:
    """Record analyst/approver sign-off for external operational handoff (no automatic OT changes)."""
    if Role.CASE_APPROVER not in session.roles and Role.ADMIN not in session.roles:
        raise AuthorizationError(
            "Role 'case_approver' required to approve an incident case for operational handoff.",
            component="sentinel_cases",
            operation="approve_incident_case",
        )
    approval = CaseApprovalRecord(
        approved_by=session.user_id,
        role=Role.CASE_APPROVER.value if Role.CASE_APPROVER in session.roles else Role.ADMIN.value,
        approved_at=utc_now_iso(),
        decision=decision,
        rationale=rationale,
        operational_handoff_ref=operational_handoff_ref,
    )
    new_status = (
        CaseStatus.APPROVED_FOR_OPERATIONAL_HANDOFF
        if decision.lower() in ("approve", "approved", "handoff")
        else CaseStatus.UNDER_REVIEW
    )
    return IncidentCase(
        **{
            **case.__dict__,
            "status": new_status,
            "approvals": case.approvals + (approval,),
        }
    )
