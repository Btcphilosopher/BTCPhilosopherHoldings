'use client';

import React, { useState, useEffect, useRef } from 'react';
import { SimulationRunner } from '@/lib/engine/simulationRunner';
import { PRESET_CHARGERS, PRESET_VEHICLES, DEFAULT_GRID, DEFAULT_SITE_MICROGRID } from '@/lib/engine/presetDesigns';
import { SimulationTelemetryFrame, FaultType, ProtocolMessage } from '@/lib/engine/types';
import { ThreeChargerTwin } from '@/components/twin/ThreeChargerTwin';
import { EngineeringWorkstation } from '@/components/workstation/EngineeringWorkstation';
import { DigitalOscilloscope } from '@/components/oscilloscope/DigitalOscilloscope';
import { ProtocolTracer } from '@/components/protocols/ProtocolTracer';
import { SiteMicrogridDashboard } from '@/components/microgrid/SiteMicrogridDashboard';
import { GoldenTestDashboard } from '@/components/validation/GoldenTestDashboard';
import { PythonIde } from '@/components/python/PythonIde';
import { MonteCarloStudio } from '@/components/optimization/MonteCarloStudio';

import { 
  Play, 
  Pause, 
  RotateCcw, 
  Zap, 
  Cpu, 
  Layers, 
  Radio, 
  Sun, 
  Award, 
  Code2, 
  Activity, 
  ShieldAlert, 
  Clock, 
  Gauge, 
  Car,
  ChevronDown
} from 'lucide-react';

export type MainViewTab = 
  | 'DIGITAL_TWIN' 
  | 'OSCILLOSCOPE' 
  | 'PROTOCOL_STACK' 
  | 'SITE_MICROGRID' 
  | 'GOLDEN_BENCHMARK' 
  | 'PYTHON_IDE' 
  | 'MONTE_CARLO';

export default function ChargeForgePage() {
  // Runner instance stored in state to satisfy react hooks linter
  const [runner] = useState(() => new SimulationRunner(
    PRESET_CHARGERS['CHARGEFORGE-350'],
    PRESET_VEHICLES['TAYCAN_800V'],
    DEFAULT_GRID
  ));
  const runnerRef = useRef(runner);

  useEffect(() => {
    runnerRef.current = runner;
  }, [runner]);

  const [activeTab, setActiveTab] = useState<MainViewTab>('DIGITAL_TWIN');
  const [selectedChargerKey, setSelectedChargerKey] = useState<string>('CHARGEFORGE-350');
  const [selectedVehicleKey, setSelectedVehicleKey] = useState<string>('TAYCAN_800V');
  const [timeMultiplier, setTimeMultiplier] = useState<number>(1);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  // Live state frame
  const [frame, setFrame] = useState<SimulationTelemetryFrame>(() => {
    return runner.step(0.01);
  });
  const [history, setHistory] = useState<SimulationTelemetryFrame[]>([]);
  const [protocolHistory, setProtocolHistory] = useState<ProtocolMessage[]>([]);

  // Simulation Clock Loop (10 Hz ticker)
  useEffect(() => {
    const interval = setInterval(() => {
      const activeRunner = runnerRef.current;
      if (activeRunner.getIsRunning()) {
        const dt = (0.1 * timeMultiplier); // Scaled time step
        const newFrame = activeRunner.step(dt);
        setFrame(newFrame);
        setHistory([...activeRunner.getTelemetryHistory()]);
        setProtocolHistory([...activeRunner.getProtocolHistory()]);
      } else {
        // Still push frame to refresh static sensors
        setFrame(activeRunner.step(0));
      }
    }, 100);

    return () => clearInterval(interval);
  }, [timeMultiplier]);

  // Handle Architecture & Vehicle Switches
  const handleSelectCharger = (key: string) => {
    setSelectedChargerKey(key);
    const c = PRESET_CHARGERS[key];
    if (c) {
      runner.setCharger(c);
      runner.resetSession();
      setIsRunning(false);
      setFrame(runner.step(0));
      setProtocolHistory([]);
    }
  };

  const handleSelectVehicle = (key: string) => {
    setSelectedVehicleKey(key);
    const v = PRESET_VEHICLES[key];
    if (v) {
      runner.setVehicle(v);
      runner.resetSession();
      setIsRunning(false);
      setFrame(runner.step(0));
      setProtocolHistory([]);
    }
  };

  const handleStart = () => {
    runner.startCharging();
    setIsRunning(true);
  };

  const handlePause = () => {
    runner.pause();
    setIsRunning(false);
  };

  const handleReset = () => {
    runner.resetSession();
    setIsRunning(false);
    setFrame(runner.step(0));
    setHistory([]);
    setProtocolHistory([]);
  };

  const handleMultiplierChange = (mult: number) => {
    setTimeMultiplier(mult);
    runner.setTimeMultiplier(mult);
  };

  const handleInjectFault = (type: FaultType, msg: string, comp: string) => {
    runner.injectFault(type, msg, comp);
  };

  const handleClearFaults = () => {
    runner.clearAllFaults();
  };

  const handleEmergencyStop = () => {
    runner.setIsEmergencyStop(true);
    runner.injectFault('EMERGENCY_STOP_PRESSED', 'E-STOP contactor trip button actuated by operator', 'SAFETY_RELAY', 'FATAL');
  };

  const livePowerKw = (frame.session.sessionState === 'CHARGING' || frame.session.sessionState === 'TAPERING')
    ? (frame.vehicle.battery.terminalVoltageV * frame.vehicle.battery.currentA) / 1000
    : 0;

  return (
    <div className="min-h-screen bg-[#06090e] text-slate-100 flex flex-col antialiased selection:bg-cyan-500 selection:text-black">
      {/* 1. MASTER APPLICATION HEADER & CLOCK CONTROLS */}
      <header className="w-full bg-[#0a0e14] border-b border-slate-800 sticky top-0 z-50 px-4 py-2.5 flex flex-wrap items-center justify-between gap-4">
        {/* Brand & Identity */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-cyan-500 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-cyan-500/30">
            CF
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono font-black text-sm tracking-wider text-white">CHARGEFORGE.OS</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950 border border-cyan-800/80 text-cyan-300 font-bold">
                PROTOTYPER & DIGITAL TWIN
              </span>
            </div>
            <div className="text-[10px] font-mono text-slate-400">
              High-Power EV Charging Systems & Power Electronics Test Platform
            </div>
          </div>
        </div>

        {/* Center: Deterministic Clock Controls */}
        <div className="flex items-center gap-2 bg-[#05070a] border border-slate-800 rounded-lg p-1 font-mono text-xs">
          {!isRunning ? (
            <button
              onClick={handleStart}
              className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5 transition-all shadow shadow-emerald-950/50"
            >
              <Play className="w-3.5 h-3.5 fill-current" /> START CHARGE
            </button>
          ) : (
            <button
              onClick={handlePause}
              className="px-3 py-1.5 rounded bg-amber-600 hover:bg-amber-500 text-white font-bold flex items-center gap-1.5 transition-all shadow shadow-amber-950/50"
            >
              <Pause className="w-3.5 h-3.5 fill-current" /> PAUSE
            </button>
          )}

          <button
            onClick={handleReset}
            className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1 transition-all"
            title="Reset Simulation Session"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <div className="h-4 w-px bg-slate-800 mx-1"></div>

          {/* Clock Multipliers */}
          <div className="flex items-center gap-1">
            {[1, 10, 50, 100].map((m) => (
              <button
                key={m}
                onClick={() => handleMultiplierChange(m)}
                className={`px-2 py-1 rounded text-[11px] font-bold ${
                  timeMultiplier === m
                    ? 'bg-cyan-950 border border-cyan-500 text-cyan-300'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {m}x
              </button>
            ))}
          </div>

          <div className="h-4 w-px bg-slate-800 mx-1"></div>

          <div className="px-2 text-slate-300 font-bold flex items-center gap-1 text-[11px]">
            <Clock className="w-3 h-3 text-cyan-400" />
            <span>{frame.timeString}</span>
          </div>
        </div>

        {/* Right: Architecture & Vehicle Selectors */}
        <div className="flex items-center gap-2 text-xs font-mono">
          {/* Charger Model */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1">
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            <select
              value={selectedChargerKey}
              onChange={(e) => handleSelectCharger(e.target.value)}
              className="bg-transparent text-white focus:outline-none cursor-pointer"
            >
              {Object.keys(PRESET_CHARGERS).map((k) => (
                <option key={k} value={k} className="bg-slate-900 text-white">{k}</option>
              ))}
            </select>
          </div>

          {/* Vehicle Model */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1">
            <Car className="w-3.5 h-3.5 text-emerald-400" />
            <select
              value={selectedVehicleKey}
              onChange={(e) => handleSelectVehicle(e.target.value)}
              className="bg-transparent text-white focus:outline-none cursor-pointer"
            >
              {Object.entries(PRESET_VEHICLES).map(([k, v]) => (
                <option key={k} value={k} className="bg-slate-900 text-white">{v.vehicleName}</option>
              ))}
            </select>
          </div>
        </div>
      </header>

      {/* 2. FAULT & SAFETY BANNER (Rendered when active faults exist) */}
      {frame.activeFaults.length > 0 && (
        <div className="w-full bg-red-950/80 border-b border-red-700 px-4 py-2 flex items-center justify-between text-xs font-mono text-red-200">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-400 animate-pulse" />
            <span className="font-bold uppercase tracking-wider text-red-400">ACTIVE SAFETY FAULT:</span>
            <span>{frame.activeFaults[frame.activeFaults.length - 1].message}</span>
          </div>
          <button
            onClick={handleClearFaults}
            className="px-2.5 py-1 bg-red-800 hover:bg-red-700 text-white rounded font-bold transition-colors"
          >
            Acknowledge & Clear
          </button>
        </div>
      )}

      {/* 3. PRIMARY VIEW NAVIGATION TABS */}
      <div className="w-full bg-[#080c12] border-b border-slate-800 px-4 flex items-center gap-1 overflow-x-auto text-xs font-mono">
        <button
          onClick={() => setActiveTab('DIGITAL_TWIN')}
          className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'DIGITAL_TWIN'
              ? 'border-cyan-400 text-cyan-300 font-bold bg-cyan-950/20'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-4 h-4" /> 3D Digital Twin & Workstation
        </button>

        <button
          onClick={() => setActiveTab('OSCILLOSCOPE')}
          className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'OSCILLOSCOPE'
              ? 'border-cyan-400 text-cyan-300 font-bold bg-cyan-950/20'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Activity className="w-4 h-4" /> Digital Oscilloscope (4-CH DSO)
        </button>

        <button
          onClick={() => setActiveTab('PROTOCOL_STACK')}
          className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'PROTOCOL_STACK'
              ? 'border-cyan-400 text-cyan-300 font-bold bg-cyan-950/20'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Radio className="w-4 h-4" /> V2G Protocol Stack (ISO 15118 / OCPP)
        </button>

        <button
          onClick={() => setActiveTab('SITE_MICROGRID')}
          className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'SITE_MICROGRID'
              ? 'border-cyan-400 text-cyan-300 font-bold bg-cyan-950/20'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sun className="w-4 h-4" /> Site Microgrid & BESS Dispatch
        </button>

        <button
          onClick={() => setActiveTab('GOLDEN_BENCHMARK')}
          className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'GOLDEN_BENCHMARK'
              ? 'border-cyan-400 text-cyan-300 font-bold bg-cyan-950/20'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Award className="w-4 h-4" /> Golden Test Validation
        </button>

        <button
          onClick={() => setActiveTab('PYTHON_IDE')}
          className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'PYTHON_IDE'
              ? 'border-cyan-400 text-cyan-300 font-bold bg-cyan-950/20'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Code2 className="w-4 h-4" /> Python Scientific IDE
        </button>

        <button
          onClick={() => setActiveTab('MONTE_CARLO')}
          className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'MONTE_CARLO'
              ? 'border-cyan-400 text-cyan-300 font-bold bg-cyan-950/20'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Gauge className="w-4 h-4" /> Monte Carlo & Pareto Space
        </button>
      </div>

      {/* 4. MAIN VIEWPORT CONTENT */}
      <main className="flex-1 p-4 max-w-7xl w-full mx-auto flex flex-col gap-5">
        {activeTab === 'DIGITAL_TWIN' && (
          <div className="flex flex-col gap-5">
            {/* 3D Digital Twin Viewport */}
            <div className="w-full h-[460px]">
              <ThreeChargerTwin
                charger={frame.charger}
                vehicle={frame.vehicle}
                powerKw={livePowerKw}
                currentA={frame.vehicle.battery.currentA}
                voltageV={frame.vehicle.battery.terminalVoltageV}
                maxTempC={frame.sensors['SEN_TEMP_MOD_MAX']?.raw || 25}
                safetyState={frame.safety}
              />
            </div>

            {/* Engineering Workstation Instruments */}
            <EngineeringWorkstation
              currentFrame={frame}
              history={history}
              onInjectFault={handleInjectFault}
              onClearFaults={handleClearFaults}
              onEmergencyStop={handleEmergencyStop}
            />
          </div>
        )}

        {activeTab === 'OSCILLOSCOPE' && (
          <DigitalOscilloscope
            dcVoltageV={frame.vehicle.battery.terminalVoltageV}
            dcCurrentA={frame.vehicle.battery.currentA}
            cpState={frame.session.sessionState === 'CHARGING' ? 'C' : frame.session.sessionState === 'CONNECTED' ? 'B' : frame.session.sessionState === 'FAULT' ? 'F' : 'A'}
            gridVoltageLL={frame.grid.nominalVoltageLL}
          />
        )}

        {activeTab === 'PROTOCOL_STACK' && (
          <ProtocolTracer
            sessionState={frame.session.sessionState}
            protocolHistory={protocolHistory}
            voltageV={frame.vehicle.battery.terminalVoltageV}
            currentA={frame.vehicle.battery.currentA}
          />
        )}

        {activeTab === 'SITE_MICROGRID' && (
          <SiteMicrogridDashboard currentSiteSpec={DEFAULT_SITE_MICROGRID} />
        )}

        {activeTab === 'GOLDEN_BENCHMARK' && (
          <GoldenTestDashboard
            energy={frame.energy}
            peakPowerKw={frame.energy.peakPowerKw}
            currentSoc={frame.vehicle.battery.socCurrent}
            maxTempC={frame.sensors['SEN_TEMP_MOD_MAX']?.raw || 52.4}
            sessionDurationSec={frame.session.durationSeconds}
          />
        )}

        {activeTab === 'PYTHON_IDE' && (
          <PythonIde
            onSyncTwinParams={(params) => {
              if (params['ambientTempC'] !== undefined) {
                setFrame(prev => ({
                  ...prev,
                  charger: {
                    ...prev.charger,
                    cooling: {
                      ...prev.charger.cooling,
                      ambientTempC: Number(params['ambientTempC']),
                    },
                  },
                }));
              }
            }}
          />
        )}

        {activeTab === 'MONTE_CARLO' && (
          <MonteCarloStudio />
        )}
      </main>

      {/* 5. FOOTER STATUS BAR */}
      <footer className="w-full bg-[#0a0e14] border-t border-slate-800/80 px-4 py-2 flex flex-wrap items-center justify-between text-[11px] font-mono text-slate-500">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            Simulation Core: Deterministic First-Principles
          </span>
          <span>ISO 15118-20 / IEC 61851-1 / OCPP 2.0.1</span>
        </div>

        <div className="flex items-center gap-4">
          <span>First Law Residual: <strong className="text-emerald-400">{frame.energy.energyResidualKwh.toFixed(4)} kWh</strong></span>
          <span>System Efficiency: <strong className="text-cyan-400">{frame.energy.overallEfficiencyPercent.toFixed(1)}%</strong></span>
        </div>
      </footer>
    </div>
  );
}
