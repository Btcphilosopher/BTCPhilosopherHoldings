import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'CHARGEFORGE.OS | EV Charging Engineering & Digital Twin Platform',
  description: 'EV Charger Prototyper, Engineering Simulator, Digital Twin & Test Platform for high-power EV charging infrastructure.',
  openGraph: {
    title: 'CHARGEFORGE.OS | EV Charging Engineering & Digital Twin Platform',
    description: 'EV Charger Prototyper, Engineering Simulator, Digital Twin & Test Platform for high-power EV charging infrastructure.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'CHARGEFORGE.OS | EV Charging Engineering & Digital Twin Platform',
    description: 'EV Charger Prototyper, Engineering Simulator, Digital Twin & Test Platform for high-power EV charging infrastructure.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#0b0f14] text-[#e1e7ec] antialiased selection:bg-emerald-500/30 selection:text-emerald-200" suppressHydrationWarning>{children}</body>
    </html>
  );
}
