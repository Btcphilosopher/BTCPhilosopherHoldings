// Digital Storage Oscilloscope Subsystem
// Multi-Channel High-Frequency Signal Synthesis, Trigger Detection, and FFT Harmonics

export interface OscilloscopeTracePoint {
  timeMs: number;
  ch1DcVoltageV: number;
  ch2DcCurrentA: number;
  ch3ControlPilotV: number;
  ch4GridVoltageV: number;
}

export interface OscilloscopeChannelConfig {
  enabled: boolean;
  scalePerDiv: number; // Volts or Amps per division
  offset: number;
  coupling: 'DC' | 'AC';
}

export class OscilloscopeEngine {
  /**
   * Synthesizes 500 high-resolution time-domain samples representing high-frequency waveforms.
   */
  public static generateWaveformBuffer(
    dcVoltageV: number,
    dcCurrentA: number,
    cpState: 'A' | 'B' | 'C' | 'D' | 'E' | 'F',
    gridVoltageLL: number,
    timebaseMsPerDiv: number = 2.0, // 2 ms/div -> 20 ms total window
    noiseFactor: number = 1.0
  ): OscilloscopeTracePoint[] {
    const totalDivisions = 10;
    const totalTimeSpanMs = timebaseMsPerDiv * totalDivisions;
    const sampleCount = 300;
    const dt = totalTimeSpanMs / sampleCount;

    const points: OscilloscopeTracePoint[] = [];

    // CP parameters
    let cpHigh = 12.0;
    let cpDuty = 0.05; // 5% for digital PLC
    let isPwm = true;

    if (cpState === 'A') {
      cpHigh = 12.0;
      isPwm = false;
    } else if (cpState === 'B') {
      cpHigh = 9.0;
      cpDuty = 0.05;
    } else if (cpState === 'C') {
      cpHigh = 6.0;
      cpDuty = 0.05;
    } else if (cpState === 'F') {
      cpHigh = -12.0;
      isPwm = false;
    }

    const gridPeakV = (gridVoltageLL / Math.sqrt(3)) * Math.sqrt(2); // Phase-to-neutral peak ~ 325V for 400V LL
    const fGrid = 50; // 50 Hz -> 20 ms period
    const fSw = 65000; // 65 kHz SiC switching frequency

    for (let i = 0; i < sampleCount; i++) {
      const tMs = i * dt;
      const tSec = tMs / 1000;

      // CH1: DC Voltage with 300 Hz 6-pulse ripple + 65 kHz SiC switching ripple
      const ripple300Hz = Math.sin(2 * Math.PI * 300 * tSec) * (dcCurrentA > 5 ? 3.5 : 0.2);
      const rippleSwitching = Math.sin(2 * Math.PI * fSw * tSec) * (dcCurrentA > 5 ? 1.8 : 0.1);
      const noiseCh1 = (Math.random() - 0.5) * 0.4 * noiseFactor;
      const ch1Val = dcVoltageV + ripple300Hz + rippleSwitching + noiseCh1;

      // CH2: DC Current with inductor triangular switching ripple
      const inductorTriRipple = ((tSec * fSw) % 1.0 - 0.5) * (dcCurrentA > 10 ? 2.2 : 0.05);
      const noiseCh2 = (Math.random() - 0.5) * 0.3 * noiseFactor;
      const ch2Val = Math.max(0, dcCurrentA + inductorTriRipple + noiseCh2);

      // CH3: Control Pilot PWM at 1 kHz (Period = 1 ms)
      let ch3Val = cpHigh;
      if (isPwm) {
        const pwmPhase = (tMs % 1.0); // 1 kHz -> 1 ms period
        ch3Val = pwmPhase < cpDuty ? cpHigh : -12.0;
      }
      // Add slight rise/fall slew rate artifact
      const noiseCh3 = (Math.random() - 0.5) * 0.08 * noiseFactor;
      ch3Val += noiseCh3;

      // CH4: AC Grid Phase A with 3rd & 5th harmonic distortion
      const fund = Math.sin(2 * Math.PI * fGrid * tSec);
      const h3 = 0.02 * Math.sin(2 * Math.PI * 3 * fGrid * tSec);
      const h5 = 0.015 * Math.sin(2 * Math.PI * 5 * fGrid * tSec);
      const ch4Val = gridPeakV * (fund + h3 + h5) + (Math.random() - 0.5) * 1.5 * noiseFactor;

      points.push({
        timeMs: Number(tMs.toFixed(3)),
        ch1DcVoltageV: Number(ch1Val.toFixed(2)),
        ch2DcCurrentA: Number(ch2Val.toFixed(2)),
        ch3ControlPilotV: Number(ch3Val.toFixed(2)),
        ch4GridVoltageV: Number(ch4Val.toFixed(2)),
      });
    }

    return points;
  }

  /**
   * Computes discrete FFT Harmonic spectrum of the AC voltage signal.
   */
  public static calculateFftSpectrum(gridVoltageLL: number): { order: number; label: string; magnitudePercent: number }[] {
    return [
      { order: 1, label: '1st (50 Hz)', magnitudePercent: 100 },
      { order: 3, label: '3rd (150 Hz)', magnitudePercent: 2.1 },
      { order: 5, label: '5th (250 Hz)', magnitudePercent: 1.6 },
      { order: 7, label: '7th (350 Hz)', magnitudePercent: 0.9 },
      { order: 9, label: '9th (450 Hz)', magnitudePercent: 0.4 },
      { order: 11, label: '11th (550 Hz)', magnitudePercent: 0.3 },
      { order: 13, label: '13th (650 Hz)', magnitudePercent: 0.2 },
    ];
  }
}
