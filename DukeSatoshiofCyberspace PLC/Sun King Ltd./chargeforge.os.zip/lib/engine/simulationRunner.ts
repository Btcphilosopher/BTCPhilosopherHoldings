// Master Simulation Clock & Deterministic Orchestrator Engine
// Coordinates Electrical, Thermal, Battery, Control, Protocols, Safety, and Telemetry

import { 
  SimulationTelemetryFrame,
  ChargerHardwareSpec,
  VehicleModelSpec,
  GridParameters,
  ChargingSessionSummary,
  EnergyAccounting,
  ActiveFault,
  FaultType,
  ProtocolMessage,
  SessionState,
  SafetyState,
} from './types';
import { ElectricalEngine } from './electrical';
import { PowerElectronicsEngine } from './powerElectronics';
import { ThermalEngine } from './thermal';
import { BatteryEngine } from './battery';
import { SafetyEngine } from './safety';
import { ProtocolEngine } from './protocols';
import { SensorEngine } from './sensors';
import { DEFAULT_GRID, PRESET_CHARGERS, PRESET_VEHICLES } from './presetDesigns';

export class SimulationRunner {
  private grid: GridParameters;
  private charger: ChargerHardwareSpec;
  private vehicle: VehicleModelSpec;
  private session: ChargingSessionSummary;
  private energy: EnergyAccounting;
  private activeFaults: ActiveFault[] = [];
  private isEmergencyStopPressed: boolean = false;
  private protocolHistory: ProtocolMessage[] = [];
  private telemetryHistory: SimulationTelemetryFrame[] = [];
  
  // Clock state
  private simulationTimeSec: number = 0;
  private timeMultiplier: number = 1; // 1x, 10x, 100x, 1000x
  private isRunning: boolean = false;
  private isCompleted: boolean = false;

  constructor(
    initialCharger: ChargerHardwareSpec = PRESET_CHARGERS['CHARGEFORGE-350'],
    initialVehicle: VehicleModelSpec = PRESET_VEHICLES['TAYCAN_800V'],
    initialGrid: GridParameters = DEFAULT_GRID
  ) {
    this.charger = JSON.parse(JSON.stringify(initialCharger));
    this.vehicle = JSON.parse(JSON.stringify(initialVehicle));
    this.grid = JSON.parse(JSON.stringify(initialGrid));

    const startTime = Date.now();
    this.session = {
      sessionId: `SESS_${startTime}`,
      chargerId: this.charger.chargerId,
      vehicleId: this.vehicle.vehicleId,
      startTime,
      initialSoc: this.vehicle.battery.socCurrent,
      targetSoc: this.vehicle.battery.socTarget,
      currentSoc: this.vehicle.battery.socCurrent,
      energyDeliveredKwh: 0,
      energyImportedKwh: 0,
      averagePowerKw: 0,
      peakPowerKw: 0,
      durationSeconds: 0,
      totalCostUsd: 0,
      revenueUsd: 0,
      grossMarginPercent: 28.5,
      sessionState: 'IDLE',
      safetyState: 'NORMAL',
      faults: [],
    };

    this.energy = {
      energyImportedKwh: 0,
      energyDeliveredKwh: 0,
      energyLostKwh: 0,
      conversionLossesKwh: 0,
      cableLossesKwh: 0,
      coolingConsumptionKwh: 0,
      standbyLossesKwh: 0,
      energyResidualKwh: 0,
      overallEfficiencyPercent: 96.5,
      sessionDurationSec: 0,
      peakPowerKw: 0,
      averagePowerKw: 0,
    };
  }

  public getGrid(): GridParameters { return this.grid; }
  public getCharger(): ChargerHardwareSpec { return this.charger; }
  public getVehicle(): VehicleModelSpec { return this.vehicle; }
  public getSession(): ChargingSessionSummary { return this.session; }
  public getEnergy(): EnergyAccounting { return this.energy; }
  public getFaults(): ActiveFault[] { return this.activeFaults; }
  public getProtocolHistory(): ProtocolMessage[] { return this.protocolHistory; }
  public getTelemetryHistory(): SimulationTelemetryFrame[] { return this.telemetryHistory; }
  public getTimeSec(): number { return this.simulationTimeSec; }
  public getIsRunning(): boolean { return this.isRunning; }
  public getTimeMultiplier(): number { return this.timeMultiplier; }

  public setTimeMultiplier(mult: number) { this.timeMultiplier = mult; }
  public setIsEmergencyStop(pressed: boolean) { this.isEmergencyStopPressed = pressed; }

  public setCharger(newCharger: ChargerHardwareSpec) {
    this.charger = JSON.parse(JSON.stringify(newCharger));
  }

  public setVehicle(newVehicle: VehicleModelSpec) {
    this.vehicle = JSON.parse(JSON.stringify(newVehicle));
  }

  public setGrid(newGrid: GridParameters) {
    this.grid = JSON.parse(JSON.stringify(newGrid));
  }

  public startCharging() {
    if (this.session.sessionState === 'IDLE' || this.session.sessionState === 'AVAILABLE') {
      this.session.sessionState = 'CONNECTED';
      this.isRunning = true;
    } else {
      this.isRunning = true;
    }
  }

  public pause() {
    this.isRunning = false;
  }

  public resume() {
    if (!this.isCompleted) {
      this.isRunning = true;
    }
  }

  public injectFault(type: FaultType, message: string, component: string, severity: 'WARNING' | 'CRITICAL' | 'FATAL' = 'CRITICAL') {
    const fault: ActiveFault = {
      id: `FLT_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      type,
      severity,
      timestamp: Date.now(),
      message,
      cleared: false,
      component,
    };
    this.activeFaults.push(fault);
  }

  public clearAllFaults() {
    this.activeFaults = [];
    this.isEmergencyStopPressed = false;
    if (this.session.sessionState === 'FAULT' || this.session.sessionState === 'EMERGENCY_STOP') {
      this.session.sessionState = 'AVAILABLE';
      this.session.safetyState = 'NORMAL';
    }
  }

  public resetSession() {
    this.simulationTimeSec = 0;
    this.isRunning = false;
    this.isCompleted = false;
    this.activeFaults = [];
    this.isEmergencyStopPressed = false;
    this.protocolHistory = [];
    this.telemetryHistory = [];

    // Reset vehicle battery to start SoC
    this.vehicle.battery.socCurrent = this.vehicle.battery.socStart;
    this.vehicle.battery.currentA = 0;
    this.vehicle.battery.temperatureC = 25.0;

    const startTime = Date.now();
    this.session = {
      sessionId: `SESS_${startTime}`,
      chargerId: this.charger.chargerId,
      vehicleId: this.vehicle.vehicleId,
      startTime,
      initialSoc: this.vehicle.battery.socStart,
      targetSoc: this.vehicle.battery.socTarget,
      currentSoc: this.vehicle.battery.socStart,
      energyDeliveredKwh: 0,
      energyImportedKwh: 0,
      averagePowerKw: 0,
      peakPowerKw: 0,
      durationSeconds: 0,
      totalCostUsd: 0,
      revenueUsd: 0,
      grossMarginPercent: 28.5,
      sessionState: 'IDLE',
      safetyState: 'NORMAL',
      faults: [],
    };

    this.energy = {
      energyImportedKwh: 0,
      energyDeliveredKwh: 0,
      energyLostKwh: 0,
      conversionLossesKwh: 0,
      cableLossesKwh: 0,
      coolingConsumptionKwh: 0,
      standbyLossesKwh: 0,
      energyResidualKwh: 0,
      overallEfficiencyPercent: 96.5,
      sessionDurationSec: 0,
      peakPowerKw: 0,
      averagePowerKw: 0,
    };
  }

  /**
   * Deterministic step advancing the entire cyber-physical charging simulation by dt seconds.
   */
  public step(dtSeconds: number = 1.0): SimulationTelemetryFrame {
    this.simulationTimeSec += dtSeconds;

    // 1. Safety State Machine Assessment
    const safetyEval = SafetyEngine.evaluateSafetyState(
      this.charger,
      this.grid,
      this.activeFaults,
      this.isEmergencyStopPressed
    );
    this.session.safetyState = safetyEval.state;

    if (!safetyEval.allowPowerDelivery) {
      if (safetyEval.state === 'EMERGENCY_STOP') {
        this.session.sessionState = 'EMERGENCY_STOP';
      } else {
        this.session.sessionState = 'FAULT';
      }
      this.charger = SafetyEngine.executeSafeShutdownSequence(this.charger);
      this.vehicle.battery.currentA = 0;
    }

    // 2. Session State Machine Transitions
    if (safetyEval.allowPowerDelivery) {
      switch (this.session.sessionState) {
        case 'CONNECTED':
          if (this.simulationTimeSec > 2) {
            this.session.sessionState = 'AUTHENTICATING';
            this.recordProtocol('AUTHENTICATING');
          }
          break;
        case 'AUTHENTICATING':
          if (this.simulationTimeSec > 5) {
            this.session.sessionState = 'NEGOTIATING';
            this.recordProtocol('NEGOTIATING');
          }
          break;
        case 'NEGOTIATING':
          if (this.simulationTimeSec > 9) {
            this.session.sessionState = 'PREPARING';
            this.recordProtocol('PREPARING');
          }
          break;
        case 'PREPARING':
          if (this.simulationTimeSec > 14) {
            this.session.sessionState = 'CHARGING';
            this.recordProtocol('CHARGING');
          }
          break;
        case 'CHARGING':
          if (this.vehicle.battery.socCurrent >= 0.80 && this.vehicle.battery.socCurrent < this.vehicle.battery.socTarget) {
            this.session.sessionState = 'TAPERING';
          } else if (this.vehicle.battery.socCurrent >= this.vehicle.battery.socTarget) {
            this.session.sessionState = 'STOPPING';
          }
          break;
        case 'TAPERING':
          if (this.vehicle.battery.socCurrent >= this.vehicle.battery.socTarget) {
            this.session.sessionState = 'STOPPING';
            this.recordProtocol('STOPPING');
          }
          break;
        case 'STOPPING':
          this.session.sessionState = 'COMPLETED';
          this.recordProtocol('COMPLETED');
          this.isRunning = false;
          this.isCompleted = true;
          break;
      }
    }

    // 3. Power Demand & Negotiation Calculation
    const isPowerActive = (this.session.sessionState === 'CHARGING' || this.session.sessionState === 'TAPERING') && safetyEval.allowPowerDelivery;
    
    let appliedPowerKw = 0;
    let appliedCurrentA = 0;
    let targetVoltageV = this.vehicle.battery.openCircuitVoltageV;

    if (isPowerActive) {
      // Vehicle non-linear acceptance limit
      const acceptance = BatteryEngine.calculateAcceptanceLimit(this.vehicle);
      
      // Multi-constraint safe envelope: min(Vehicle, Charger, Cable, Grid, ThermalDerate)
      const chargerLimitKw = this.charger.ratedPowerKw;
      const cableLimitKw = (this.charger.cables[0].cableMaxCurrentA * targetVoltageV) / 1000;
      const gridLimitKw = this.grid.maxImportKw;

      // Thermal derate multiplier
      const thermalDerate = safetyEval.state === 'DERATED' ? 0.75 : 1.0;

      // Final unconstrained power
      const unconstrainedKw = Math.min(
        acceptance.maxPowerKw,
        chargerLimitKw,
        cableLimitKw,
        gridLimitKw
      ) * thermalDerate;

      appliedPowerKw = Math.max(0, unconstrainedKw);
      appliedCurrentA = (appliedPowerKw * 1000) / Math.max(300, targetVoltageV);
    }

    // 4. Power Electronics & Module Array Losses
    const arrayMetrics = PowerElectronicsEngine.distributeArrayPower(
      this.charger,
      appliedPowerKw,
      targetVoltageV
    );
    this.charger.moduleArray = arrayMetrics.updatedModules;

    // 5. Cable & Connector Losses
    const cableMetrics = ElectricalEngine.calculateCableLosses(this.charger.cables[0], appliedCurrentA);
    this.charger.cables[0] = {
      ...this.charger.cables[0],
      currentA: appliedCurrentA,
      voltageV: targetVoltageV,
      voltageDropV: cableMetrics.voltageDropV,
      cableLossKw: cableMetrics.cableLossKw,
      connectorLossKw: cableMetrics.connectorLossKw,
    };

    // 6. Thermal Network Step
    const thermalStep = ThermalEngine.stepThermalNetwork(
      this.charger.moduleArray,
      this.charger.cooling,
      this.charger.cables[0],
      this.charger.cooling.ambientTempC,
      dtSeconds
    );
    this.charger.moduleArray = thermalStep.updatedModules;
    this.charger.cooling = thermalStep.updatedCooling;
    this.charger.cables[0] = thermalStep.updatedCable;

    // 7. Battery Equivalent Circuit Step
    const batteryStep = BatteryEngine.stepBatteryState(
      this.vehicle.battery,
      appliedCurrentA,
      this.charger.cooling.ambientTempC,
      dtSeconds
    );
    this.vehicle.battery = batteryStep.updatedBattery;

    // 8. Grid Input Power & Transformer Model
    const totalLossKw = arrayMetrics.totalModuleLossKw + cableMetrics.totalLossKw + (this.charger.cooling.type === 'LIQUID_GLYCOL' ? 1.2 : 0.4);
    const gridInputPowerKw = appliedPowerKw + totalLossKw;
    
    const acPower = ElectricalEngine.calculateAcInputPower(
      this.grid.nominalVoltageLL,
      (gridInputPowerKw * 1000) / (Math.sqrt(3) * this.grid.nominalVoltageLL * this.grid.powerFactorTarget),
      this.grid.powerFactorTarget,
      3
    );

    this.grid.liveRealPowerKw = gridInputPowerKw;
    this.grid.liveApparentPowerKva = acPower.apparentPowerKva;
    this.grid.liveReactivePowerKvar = acPower.reactivePowerKvar;
    this.grid.liveCurrent = (gridInputPowerKw * 1000) / (Math.sqrt(3) * this.grid.nominalVoltageLL * this.grid.powerFactorTarget);

    // 9. Energy Accounting & First Law Conservation Check
    const energyDeliveredDelta = batteryStep.energyDeliveredKwh;
    const energyImportedDelta = (gridInputPowerKw * dtSeconds) / 3600;
    const energyLostDelta = (totalLossKw * dtSeconds) / 3600;

    this.energy.energyDeliveredKwh += energyDeliveredDelta;
    this.energy.energyImportedKwh += energyImportedDelta;
    this.energy.energyLostKwh += energyLostDelta;
    this.energy.conversionLossesKwh += (arrayMetrics.totalModuleLossKw * dtSeconds) / 3600;
    this.energy.cableLossesKwh += (cableMetrics.totalLossKw * dtSeconds) / 3600;
    this.energy.sessionDurationSec = this.simulationTimeSec;
    
    // Residual = Ein - Eout - Eloss (Should strictly equal 0)
    this.energy.energyResidualKwh = Math.abs(this.energy.energyImportedKwh - this.energy.energyDeliveredKwh - this.energy.energyLostKwh);
    
    if (this.energy.energyImportedKwh > 0) {
      this.energy.overallEfficiencyPercent = (this.energy.energyDeliveredKwh / this.energy.energyImportedKwh) * 100;
    }

    if (appliedPowerKw > this.energy.peakPowerKw) {
      this.energy.peakPowerKw = appliedPowerKw;
    }
    if (this.simulationTimeSec > 0) {
      this.energy.averagePowerKw = (this.energy.energyDeliveredKwh / (this.simulationTimeSec / 3600));
    }

    // Update session summary
    this.session.currentSoc = this.vehicle.battery.socCurrent;
    this.session.energyDeliveredKwh = this.energy.energyDeliveredKwh;
    this.session.energyImportedKwh = this.energy.energyImportedKwh;
    this.session.peakPowerKw = this.energy.peakPowerKw;
    this.session.averagePowerKw = this.energy.averagePowerKw;
    this.session.durationSeconds = this.simulationTimeSec;
    this.session.revenueUsd = this.session.energyDeliveredKwh * 0.42; // $0.42 / kWh retail
    this.session.totalCostUsd = this.session.energyImportedKwh * 0.28; // $0.28 / kWh grid cost
    if (this.session.revenueUsd > 0) {
      this.session.grossMarginPercent = ((this.session.revenueUsd - this.session.totalCostUsd) / this.session.revenueUsd) * 100;
    }

    // 10. Sensor Telemetry Processing
    const sensors: Record<string, any> = {
      'SEN_DC_VOLT': SensorEngine.processSensor('SEN_DC_VOLT', 'DC Output Voltage', targetVoltageV, 'V', 0.005, 0.1),
      'SEN_DC_CURR': SensorEngine.processSensor('SEN_DC_CURR', 'DC Output Current', appliedCurrentA, 'A', 0.008, 0.1),
      'SEN_TEMP_MOD_MAX': SensorEngine.processSensor('SEN_TEMP_MOD_MAX', 'Module Peak Temp', thermalStep.maxSystemTempC, '°C', 0.012, 0.1),
      'SEN_COOL_INLET': SensorEngine.processSensor('SEN_COOL_INLET', 'Coolant Inlet Temp', this.charger.cooling.coolantInletTempC, '°C', 0.01, 0.1),
      'SEN_CABLE_TEMP': SensorEngine.processSensor('SEN_CABLE_TEMP', 'Cable Core Temp', this.charger.cables[0].cableTempC, '°C', 0.01, 0.1),
      'SEN_GRID_POWER': SensorEngine.processSensor('SEN_GRID_POWER', 'Grid Real Power', gridInputPowerKw, 'kW', 0.006, 0.1),
      'SEN_IMD_RES': SensorEngine.processSensor('SEN_IMD_RES', 'Insulation Resistance', this.charger.isolationResistanceMOhm, 'MΩ', 0.02, 0.01),
    };

    const frame: SimulationTelemetryFrame = {
      timestampSec: this.simulationTimeSec,
      clockStepMs: dtSeconds * 1000,
      timeString: this.formatTime(this.simulationTimeSec),
      grid: JSON.parse(JSON.stringify(this.grid)),
      charger: JSON.parse(JSON.stringify(this.charger)),
      vehicle: JSON.parse(JSON.stringify(this.vehicle)),
      session: JSON.parse(JSON.stringify(this.session)),
      energy: JSON.parse(JSON.stringify(this.energy)),
      sensors,
      safety: this.session.safetyState,
      activeFaults: [...this.activeFaults],
      derateFactor: thermalStep.thermalDerateFactor,
      derateReason: thermalStep.derateReason,
    };

    // Keep up to 600 historic telemetry frames
    this.telemetryHistory.push(frame);
    if (this.telemetryHistory.length > 600) {
      this.telemetryHistory.shift();
    }

    return frame;
  }

  private recordProtocol(state: SessionState) {
    const msg = ProtocolEngine.createProtocolMessage(
      state,
      this.vehicle.battery.terminalVoltageV,
      this.vehicle.battery.currentA,
      (this.vehicle.battery.terminalVoltageV * this.vehicle.battery.currentA) / 1000,
      this.vehicle.battery.socCurrent
    );
    this.protocolHistory.push(msg);
    if (this.protocolHistory.length > 50) {
      this.protocolHistory.shift();
    }
  }

  private formatTime(totalSec: number): string {
    const mins = Math.floor(totalSec / 60);
    const secs = Math.floor(totalSec % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
}
