// Synthetic Sensor & Telemetry Subsystem
// Real-world Noise (Gaussian, Drift, Spikes, Quantization) + Kalman / Low-pass Filter Estimator

import { SensorTelemetry } from './types';

export class SensorEngine {
  private static driftOffset: Record<string, number> = {};

  /**
   * Generates synthetic sensor measurement from ground truth physics value.
   * Injects realistic sensor noise, quantization, calibration bias, and drift.
   * Then computes filtered and estimated state.
   */
  public static processSensor(
    id: string,
    name: string,
    groundTruthValue: number,
    unit: string,
    noiseSigma: number = 0.015, // 1.5% stddev
    quantizationStep: number = 0.1,
    previousFiltered: number = groundTruthValue
  ): SensorTelemetry {
    // 1. Long-term thermal/electrical drift accumulation
    if (!this.driftOffset[id]) {
      this.driftOffset[id] = 0;
    }
    this.driftOffset[id] += (Math.random() - 0.5) * (groundTruthValue * 0.0002);
    // Bound drift within +/- 2%
    this.driftOffset[id] = Math.max(-0.02 * groundTruthValue, Math.min(0.02 * groundTruthValue, this.driftOffset[id]));

    // 2. Gaussian white noise (Box-Muller transform)
    const u1 = Math.max(1e-6, Math.random());
    const u2 = Math.random();
    const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    const noise = z0 * (groundTruthValue * noiseSigma);

    // 3. Rare transient spike injection (0.5% probability)
    let spike = 0;
    if (Math.random() < 0.005) {
      spike = (Math.random() > 0.5 ? 1 : -1) * (groundTruthValue * 0.08);
    }

    // Raw measured signal
    let rawValue = groundTruthValue + noise + this.driftOffset[id] + spike;
    if (quantizationStep > 0) {
      rawValue = Math.round(rawValue / quantizationStep) * quantizationStep;
    }

    // 4. State Estimation & Filtering (1st Order IIR / Kalman filter approximation)
    const alpha = 0.25; // Filter gain
    const filteredValue = previousFiltered + alpha * (rawValue - previousFiltered);

    // Estimated value with bias rejection
    const estimatedValue = filteredValue - this.driftOffset[id] * 0.8;

    // Physical sanity validation
    const validated = rawValue >= 0 && isFinite(rawValue) && Math.abs(rawValue - groundTruthValue) < Math.max(10, groundTruthValue * 0.4);

    return {
      id,
      name,
      raw: Number(rawValue.toFixed(2)),
      filtered: Number(filteredValue.toFixed(2)),
      estimated: Number(estimatedValue.toFixed(2)),
      validated,
      unit,
      noiseSigma,
      status: validated ? 'HEALTHY' : 'DEGRADED',
      confidence: validated ? 0.98 : 0.65,
    };
  }
}
