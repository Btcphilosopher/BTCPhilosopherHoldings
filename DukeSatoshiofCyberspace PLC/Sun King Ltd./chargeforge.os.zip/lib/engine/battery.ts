// Battery & Vehicle Physics Subsystem
// Thevenin 2-RC Equivalent Circuit, Non-linear Taper Curves, and Chemistry Models

import { BatteryEquivalentCircuit, VehicleModelSpec } from './types';

export class BatteryEngine {
  /**
   * Evaluates the non-linear Open-Circuit Voltage (OCV) curve based on chemistry and SoC.
   */
  public static calculateOcv(
    soc: number,
    nominalVoltageV: number,
    chemistry: string = 'NMC_811'
  ): number {
    const clampedSoc = Math.max(0.001, Math.min(1.0, soc));
    
    if (chemistry === 'LFP') {
      // Flat plateau for LFP between 20% and 80% SoC
      // Base cell: 3.2V nominal, 2.8V empty, 3.65V full
      const vScale = nominalVoltageV / 3.2; // Number of series cells
      if (clampedSoc < 0.10) {
        return (2.8 + (clampedSoc / 0.10) * 0.35) * vScale;
      } else if (clampedSoc > 0.90) {
        return (3.35 + ((clampedSoc - 0.90) / 0.10) * 0.30) * vScale;
      } else {
        // Flat nominal plateau
        return (3.22 + (clampedSoc - 0.10) * 0.15) * vScale;
      }
    } else {
      // NMC 811 / NCA: 3.0V empty, 3.7V nominal, 4.2V full
      const vScale = nominalVoltageV / 3.7;
      // High-precision polynomial curve
      const cellV = 3.05 + 0.65 * clampedSoc + 0.50 * Math.pow(clampedSoc, 2) - 0.30 * Math.pow(clampedSoc, 3) + 0.30 * Math.pow(clampedSoc, 4);
      return cellV * vScale;
    }
  }

  /**
   * Returns the vehicle battery's maximum acceptable charging power at given SoC and temperature.
   * Models the non-linear manufacturer fast-charging curve.
   */
  public static calculateAcceptanceLimit(
    vehicle: VehicleModelSpec
  ): { maxPowerKw: number; maxCurrentA: number; taperReason: string } {
    const { battery, maxChargePowerKw } = vehicle;
    const soc = battery.socCurrent;
    const tempC = battery.temperatureC;

    let basePowerKw = maxChargePowerKw;
    let reason = 'OPTIMAL_CHARGING_WINDOW';

    // 1. Cold/Hot Battery Derating
    if (tempC < 15) {
      const coldDerate = Math.max(0.2, (tempC + 5) / 20);
      basePowerKw *= coldDerate;
      reason = `COLD_BATTERY_DERATE (${tempC.toFixed(1)}°C)`;
    } else if (tempC > 45) {
      const hotDerate = Math.max(0.2, 1 - (tempC - 45) / 15);
      basePowerKw *= hotDerate;
      reason = `HOT_BATTERY_DERATE (${tempC.toFixed(1)}°C)`;
    }

    // 2. SoC Taper Envelope (Standard EV Fast-Charge Curve)
    if (soc <= 0.25) {
      // Peak boost / initial ramp
      basePowerKw = basePowerKw * 0.95;
    } else if (soc <= 0.50) {
      // Maximum charging plateau
      basePowerKw = basePowerKw * 1.0;
    } else if (soc <= 0.65) {
      // Gentle early taper
      basePowerKw = basePowerKw * 0.82;
      reason = 'EARLY_SOC_TAPER';
    } else if (soc <= 0.80) {
      // Mid-stage taper
      basePowerKw = basePowerKw * 0.60;
      reason = 'CC_TO_CV_TRANSITION_TAPER';
    } else if (soc <= 0.90) {
      // Deep CV taper
      basePowerKw = basePowerKw * 0.35;
      reason = 'DEEP_CV_TAPER';
    } else {
      // Final saturation trickle
      basePowerKw = Math.max(12, basePowerKw * 0.15 * (1 - (soc - 0.90) / 0.10));
      reason = 'TOPPING_OFF_TRICKLE';
    }

    // Cap at nominal battery power & voltage
    const maxPower = Math.min(maxChargePowerKw, basePowerKw);
    const maxCurrent = (maxPower * 1000) / Math.max(300, battery.openCircuitVoltageV);

    return {
      maxPowerKw: Math.max(0, maxPower),
      maxCurrentA: Math.max(0, maxCurrent),
      taperReason: reason,
    };
  }

  /**
   * Advances the 2-RC Equivalent Circuit state by dt seconds.
   * Calculates new SoC, terminal voltage, and polarization voltage drops.
   */
  public static stepBatteryState(
    battery: BatteryEquivalentCircuit,
    appliedCurrentA: number,
    ambientTempC: number,
    dtSeconds: number = 1.0
  ): {
    updatedBattery: BatteryEquivalentCircuit;
    energyDeliveredKwh: number;
    jouleHeatLossW: number;
  } {
    const currentA = Math.max(0, appliedCurrentA);

    // 1. OCV based on current SoC
    const ocv = this.calculateOcv(battery.socCurrent, battery.nominalVoltageV, battery.chemistry);

    // 2. Temperature effect on internal resistance (Arrhenius equation)
    const tempKelvin = battery.temperatureC + 273.15;
    const r0Ref = battery.r0InternalResistanceMilliohm * 1e-3;
    const r0Temp = r0Ref * Math.exp(1200 * (1 / tempKelvin - 1 / 298.15));

    // 3. RC polarization branches (Thevenin 2-RC transient state integration)
    const r1 = battery.r1PolarizationMilliohm * 1e-3;
    const c1 = battery.c1PolarizationFarad || 1500;
    const r2 = battery.r2PolarizationMilliohm * 1e-3;
    const c2 = battery.c2PolarizationFarad || 6000;

    const dVrc1 = (-battery.vRc1 / (r1 * c1) + currentA / c1) * dtSeconds;
    const dVrc2 = (-battery.vRc2 / (r2 * c2) + currentA / c2) * dtSeconds;

    const newVrc1 = Math.max(0, battery.vRc1 + dVrc1);
    const newVrc2 = Math.max(0, battery.vRc2 + dVrc2);

    // 4. Terminal voltage under charge load: V_term = OCV + I*R0 + V_rc1 + V_rc2
    const terminalVoltage = ocv + currentA * r0Temp + newVrc1 + newVrc2;

    // 5. Energy and SoC Integration (Coulomb Counting + Charge Efficiency)
    // Capacity in Ah = (Capacity in kWh * 1000) / Nominal Voltage
    const capacityAh = (battery.usableCapacityKwh * 1000) / battery.nominalVoltageV;
    const chargeEfficiency = battery.chargeEfficiency || 0.985;
    const dSoc = ((currentA * chargeEfficiency * dtSeconds) / (capacityAh * 3600));
    
    const newSoc = Math.min(1.0, battery.socCurrent + dSoc);
    const powerDeliveredW = terminalVoltage * currentA;
    const energyDeliveredKwh = (powerDeliveredW * dtSeconds) / (3600 * 1000);

    // 6. Thermal generation in pack: Q_gen = I^2 * R0 + (V_rc1^2 / R1) + (V_rc2^2 / R2)
    const jouleHeatLossW = Math.pow(currentA, 2) * r0Temp + (Math.pow(newVrc1, 2) / r1) + (Math.pow(newVrc2, 2) / r2);
    
    // Battery pack thermal mass ~ 350 kg @ 950 J/(kg*K) = 332,500 J/K
    const packCth = 332500;
    const packCoolingRth = 0.045; // Active battery chiller plate
    const dTemp = ((jouleHeatLossW - (battery.temperatureC - 25) / packCoolingRth) / packCth) * dtSeconds;
    const newTempC = Math.max(10, battery.temperatureC + dTemp);

    const updatedBattery: BatteryEquivalentCircuit = {
      ...battery,
      openCircuitVoltageV: ocv,
      terminalVoltageV: terminalVoltage,
      vRc1: newVrc1,
      vRc2: newVrc2,
      currentA,
      socCurrent: newSoc,
      temperatureC: newTempC,
    };

    return {
      updatedBattery,
      energyDeliveredKwh,
      jouleHeatLossW,
    };
  }
}
