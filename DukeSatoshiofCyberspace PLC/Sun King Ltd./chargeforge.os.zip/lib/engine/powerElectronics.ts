// Power Electronics Modular Subsystem
// SiC / GaN Switching & Conduction Losses, Efficiency Mapping, and Parallel Interleaving

import { PowerModuleSpec, ChargerHardwareSpec } from './types';

export class PowerElectronicsEngine {
  /**
   * Evaluates efficiency and semiconductor power losses of a single power module.
   * Total Loss = P_cond + P_sw + P_core + P_aux
   */
  public static calculateModuleLosses(
    module: PowerModuleSpec,
    outputPowerKw: number,
    outputVoltageV: number
  ): {
    lossKw: number;
    efficiency: number;
    outputCurrentA: number;
    conductionLossW: number;
    switchingLossW: number;
    coreAndAuxLossW: number;
  } {
    if (outputPowerKw <= 0.05 || module.status === 'FAULT') {
      return {
        lossKw: 0.045, // 45W standby
        efficiency: 0,
        outputCurrentA: 0,
        conductionLossW: 0,
        switchingLossW: 0,
        coreAndAuxLossW: 45,
      };
    }

    const voltage = Math.max(150, outputVoltageV);
    const currentA = (outputPowerKw * 1000) / voltage;
    const loadFraction = Math.min(1.2, outputPowerKw / module.nominalPowerKw);

    // Silicon Carbide (SiC) MOSFET / Diode parameters
    // R_ds_on at 25°C ~ 25 mOhm, rises to ~ 45 mOhm at 100°C
    const tempFactor = 1 + 0.007 * Math.max(0, module.temperatureC - 25);
    const rdsOn = 0.025 * tempFactor;

    // Conduction loss: I^2 * R
    const conductionLossW = Math.pow(currentA / 2, 2) * rdsOn * 4; // 4 switches per H-bridge

    // Switching loss: f_sw * (E_on + E_off) * (V / V_ref) * (I / I_ref)
    const fSwHz = module.switchingFrequencyKhz * 1000;
    const eOnPlusOffRefJoules = 0.0022; // 2.2 mJ at 800V, 50A
    const switchingLossW = fSwHz * eOnPlusOffRefJoules * (voltage / 800) * (currentA / 50);

    // High frequency transformer core loss (Steinmetz equation approx) + auxiliary power
    const coreLossW = 120 * Math.pow(loadFraction, 0.6);
    const auxLossW = 45; // Controller, gate drivers, telemetry sensors

    const totalLossW = conductionLossW + switchingLossW + coreLossW + auxLossW;
    const totalLossKw = totalLossW / 1000;
    const inputPowerKw = outputPowerKw + totalLossKw;
    const efficiency = inputPowerKw > 0 ? outputPowerKw / inputPowerKw : 0;

    return {
      lossKw: totalLossKw,
      efficiency: Math.min(0.985, Math.max(0.70, efficiency)),
      outputCurrentA: currentA,
      conductionLossW,
      switchingLossW,
      coreAndAuxLossW: coreLossW + auxLossW,
    };
  }

  /**
   * Distributes demanded power across active, healthy power modules in the array.
   * Handles redundant N+1 architecture and failure degradation gracefully.
   */
  public static distributeArrayPower(
    hardware: ChargerHardwareSpec,
    demandedPowerKw: number,
    targetVoltageV: number
  ): {
    totalModulePowerKw: number;
    totalModuleLossKw: number;
    averageEfficiency: number;
    activeModuleCount: number;
    updatedModules: PowerModuleSpec[];
  } {
    const onlineModules = hardware.moduleArray.filter(m => m.status === 'ONLINE');
    const activeCount = onlineModules.length;

    if (activeCount === 0 || demandedPowerKw <= 0.1) {
      const updatedModules = hardware.moduleArray.map(m => ({
        ...m,
        outputPowerKw: 0,
        outputCurrentA: 0,
        lossKw: 0.045,
        efficiency: 0,
      }));
      return {
        totalModulePowerKw: 0,
        totalModuleLossKw: hardware.moduleArray.length * 0.045,
        averageEfficiency: 0,
        activeModuleCount: 0,
        updatedModules,
      };
    }

    // Determine power per online module
    const powerPerModule = demandedPowerKw / activeCount;
    let totalLossKw = 0;
    let totalPowerKw = 0;

    const updatedModules = hardware.moduleArray.map(m => {
      if (m.status !== 'ONLINE') {
        return {
          ...m,
          outputPowerKw: 0,
          outputCurrentA: 0,
          lossKw: m.status === 'FAULT' ? 0 : 0.045,
          efficiency: 0,
        };
      }

      // Cap at single module max power
      const moduleAssignedKw = Math.min(m.nominalPowerKw, powerPerModule);
      const metrics = this.calculateModuleLosses(m, moduleAssignedKw, targetVoltageV);

      totalPowerKw += moduleAssignedKw;
      totalLossKw += metrics.lossKw;

      return {
        ...m,
        outputPowerKw: moduleAssignedKw,
        outputCurrentA: metrics.outputCurrentA,
        outputVoltageV: targetVoltageV,
        lossKw: metrics.lossKw,
        efficiency: metrics.efficiency,
      };
    });

    const averageEfficiency = (totalPowerKw + totalLossKw) > 0 ? totalPowerKw / (totalPowerKw + totalLossKw) : 0;

    return {
      totalModulePowerKw: totalPowerKw,
      totalModuleLossKw: totalLossKw,
      averageEfficiency,
      activeModuleCount: activeCount,
      updatedModules,
    };
  }
}
