// Safety Interlock & Fault Engine
// ISO 61851 / ISO 15118 Safety State Machine, IMD Insulation Monitoring, and Safe E-Stop Sequence

import { SafetyState, ActiveFault, FaultType, ChargerHardwareSpec, GridParameters } from './types';

export class SafetyEngine {
  /**
   * Evaluates all electrical, thermal, mechanical, and communication interlocks.
   * Enforces the fundamental rule: Safety logic ALWAYS overrides optimization and control.
   */
  public static evaluateSafetyState(
    hardware: ChargerHardwareSpec,
    grid: GridParameters,
    activeFaults: ActiveFault[],
    isEmergencyStopPressed: boolean
  ): {
    state: SafetyState;
    triggeredFaults: ActiveFault[];
    allowPowerDelivery: boolean;
    shutdownReason?: string;
  } {
    const newFaults: ActiveFault[] = [...activeFaults.filter(f => !f.cleared)];

    // 1. Manual E-Stop Button Pressed
    if (isEmergencyStopPressed) {
      return {
        state: 'EMERGENCY_STOP',
        triggeredFaults: newFaults,
        allowPowerDelivery: false,
        shutdownReason: 'MANUAL_EMERGENCY_STOP_ACTUATED',
      };
    }

    // 2. Insulation Monitoring Device (IMD) Check
    // Standard IEC 61851-23 requires > 100 Ohm/V -> For 1000V system = > 100 kOhm (0.1 MOhm)
    if (hardware.isolationResistanceMOhm < 0.10) {
      const imdFault: ActiveFault = {
        id: `IMD_${Date.now()}`,
        type: 'INSULATION_RESISTANCE_FAULT',
        severity: 'CRITICAL',
        timestamp: Date.now(),
        message: `Insulation resistance critically low: ${(hardware.isolationResistanceMOhm * 1000).toFixed(0)} kΩ (min 100 kΩ)`,
        cleared: false,
        component: 'INSULATION_MONITOR',
      };
      if (!newFaults.some(f => f.type === 'INSULATION_RESISTANCE_FAULT')) {
        newFaults.push(imdFault);
      }
      return {
        state: 'TRIP',
        triggeredFaults: newFaults,
        allowPowerDelivery: false,
        shutdownReason: 'IMD_INSULATION_RESISTANCE_TRIP',
      };
    }

    // 3. Grid Over/Under Voltage
    if (grid.liveVoltageLL > grid.nominalVoltageLL * 1.15) {
      if (!newFaults.some(f => f.type === 'OVERVOLTAGE_GRID')) {
        newFaults.push({
          id: `OVR_${Date.now()}`,
          type: 'OVERVOLTAGE_GRID',
          severity: 'CRITICAL',
          timestamp: Date.now(),
          message: `Grid voltage surge: ${grid.liveVoltageLL.toFixed(1)} V AC (max ${(grid.nominalVoltageLL * 1.15).toFixed(0)} V)`,
          cleared: false,
          component: 'GRID_AC_INPUT',
        });
      }
      return {
        state: 'TRIP',
        triggeredFaults: newFaults,
        allowPowerDelivery: false,
        shutdownReason: 'GRID_OVERVOLTAGE_TRIP',
      };
    }

    // 4. Critical Overtemperature Check (> 95°C)
    const maxModuleTemp = Math.max(...hardware.moduleArray.map(m => m.temperatureC), 0);
    const maxCableTemp = Math.max(...hardware.cables.map(c => c.cableTempC), 0);
    const maxConnTemp = Math.max(...hardware.cables.map(c => c.connectorPinTempC), 0);
    const maxTemp = Math.max(maxModuleTemp, maxCableTemp, maxConnTemp);

    if (maxTemp >= hardware.thermalTripThresholdC || maxTemp >= 95) {
      if (!newFaults.some(f => f.type === 'OVERTEMPERATURE_MODULE')) {
        newFaults.push({
          id: `TMP_CRIT_${Date.now()}`,
          type: 'OVERTEMPERATURE_MODULE',
          severity: 'FATAL',
          timestamp: Date.now(),
          message: `Thermal trip threshold exceeded: ${maxTemp.toFixed(1)}°C (limit ${hardware.thermalTripThresholdC}°C)`,
          cleared: false,
          component: 'THERMAL_PROTECTION',
        });
      }
      return {
        state: 'TRIP',
        triggeredFaults: newFaults,
        allowPowerDelivery: false,
        shutdownReason: 'CRITICAL_OVERTEMPERATURE_TRIP',
      };
    }

    // 5. Active Critical / Fatal Faults in Queue
    const criticalFault = newFaults.find(f => f.severity === 'CRITICAL' || f.severity === 'FATAL');
    if (criticalFault) {
      return {
        state: 'FAULT',
        triggeredFaults: newFaults,
        allowPowerDelivery: false,
        shutdownReason: criticalFault.message,
      };
    }

    // 6. Warnings and Derated State
    if (maxTemp >= hardware.thermalDerateThresholdC || newFaults.some(f => f.severity === 'WARNING')) {
      return {
        state: 'DERATED',
        triggeredFaults: newFaults,
        allowPowerDelivery: true,
      };
    }

    return {
      state: 'NORMAL',
      triggeredFaults: newFaults,
      allowPowerDelivery: true,
    };
  }

  /**
   * Executes the deterministic safe emergency shutdown sequence.
   */
  public static executeSafeShutdownSequence(
    hardware: ChargerHardwareSpec
  ): ChargerHardwareSpec {
    return {
      ...hardware,
      dcContactorState: 'OPEN',
      acBreakerState: 'TRIPPED',
      cooling: {
        ...hardware.cooling,
        pumpSpeedPercent: 100, // Maximum purge cooling
        radiatorFanSpeedPercent: 100,
        pumpStatus: 'RUNNING',
        fanStatus: 'RUNNING',
      },
      moduleArray: hardware.moduleArray.map(m => ({
        ...m,
        outputPowerKw: 0,
        outputCurrentA: 0,
        lossKw: 0,
      })),
      cables: hardware.cables.map(c => ({
        ...c,
        currentA: 0,
        cableLossKw: 0,
        connectorLossKw: 0,
      })),
    };
  }
}
