// Dynamic Multi-Vehicle Power Sharing & Allocation Engine
// Algorithms: First-Come-First-Serve, Equal Share, Priority, Maximum Acceptance, SoC-Aware, Grid-Constrained

import { SharingPolicy } from './types';

export interface VehicleAllocationRequest {
  id: string;
  name: string;
  requestedKw: number;
  maxAcceptanceKw: number;
  currentSoc: number;
  priorityScore: number; // 1 (low) to 10 (high)
  arrivalTimeMinutes: number;
  allocatedKw: number;
}

export class PowerSharingEngine {
  /**
   * Arbitrates available charger or site capacity across multiple connected vehicles.
   */
  public static allocatePower(
    totalAvailablePowerKw: number,
    requests: VehicleAllocationRequest[],
    policy: SharingPolicy
  ): VehicleAllocationRequest[] {
    if (requests.length === 0) return [];
    if (totalAvailablePowerKw <= 0) {
      return requests.map(r => ({ ...r, allocatedKw: 0 }));
    }

    const n = requests.length;

    switch (policy) {
      case 'EQUAL_SHARE': {
        const equalSlot = totalAvailablePowerKw / n;
        return requests.map(r => ({
          ...r,
          allocatedKw: Math.min(r.requestedKw, r.maxAcceptanceKw, equalSlot),
        }));
      }

      case 'FIRST_COME_FIRST_SERVE': {
        // Sort by arrival time
        const sorted = [...requests].sort((a, b) => a.arrivalTimeMinutes - b.arrivalTimeMinutes);
        let remainingPower = totalAvailablePowerKw;
        
        const allocated = sorted.map(r => {
          const alloc = Math.min(remainingPower, r.requestedKw, r.maxAcceptanceKw);
          remainingPower = Math.max(0, remainingPower - alloc);
          return { ...r, allocatedKw: alloc };
        });

        // Restore original order
        return requests.map(r => allocated.find(a => a.id === r.id) || r);
      }

      case 'PRIORITY_WEIGHTED': {
        const totalPriority = requests.reduce((acc, r) => acc + Math.max(1, r.priorityScore), 0);
        return requests.map(r => {
          const weight = Math.max(1, r.priorityScore) / totalPriority;
          const share = totalAvailablePowerKw * weight;
          return {
            ...r,
            allocatedKw: Math.min(r.requestedKw, r.maxAcceptanceKw, share),
          };
        });
      }

      case 'SOC_AWARE_OPTIMAL': {
        // Vehicles with lower SoC (e.g. 10%) need rapid energy more than vehicles at 85%
        const urgencyScores = requests.map(r => ({
          ...r,
          urgency: Math.pow(Math.max(0.05, 1.0 - r.currentSoc), 1.5),
        }));
        const totalUrgency = urgencyScores.reduce((acc, u) => acc + u.urgency, 0);

        return urgencyScores.map(u => {
          const weight = totalUrgency > 0 ? u.urgency / totalUrgency : 1 / n;
          const targetPower = totalAvailablePowerKw * weight;
          return {
            ...u,
            allocatedKw: Math.min(u.requestedKw, u.maxAcceptanceKw, targetPower),
          };
        });
      }

      case 'MAX_ACCEPTANCE_RATE':
      case 'GRID_CONSTRAINED':
      default: {
        // Proportional to vehicle acceptance limit
        const totalAcceptance = requests.reduce((acc, r) => acc + r.maxAcceptanceKw, 0);
        if (totalAcceptance <= totalAvailablePowerKw) {
          return requests.map(r => ({
            ...r,
            allocatedKw: Math.min(r.requestedKw, r.maxAcceptanceKw),
          }));
        }
        return requests.map(r => {
          const ratio = r.maxAcceptanceKw / totalAcceptance;
          const alloc = totalAvailablePowerKw * ratio;
          return {
            ...r,
            allocatedKw: Math.min(r.requestedKw, r.maxAcceptanceKw, alloc),
          };
        });
      }
    }
  }
}
