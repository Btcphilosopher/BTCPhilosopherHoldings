// Electrical Subsystem Mathematical Models
// AC 3-Phase Grid, Transformer, PFC Rectifier, DC Link, and Losses

import { GridParameters, ChargerHardwareSpec, CableAndConnectorSpec } from './types';

export class ElectricalEngine {
  /**
   * Calculates 3-phase AC input real, reactive, and apparent power given line voltage, current, and PF.
   * Equations:
   * S = sqrt(3) * V_LL * I_line
   * P = S * cos(phi)
   * Q = S * sin(phi)
   */
  public static calculateAcInputPower(
    voltageLL: number,
    currentA: number,
    powerFactor: number,
    phaseCount: 1 | 3 = 3
  ): { realPowerKw: number; reactivePowerKvar: number; apparentPowerKva: number } {
    const factor = phaseCount === 3 ? Math.sqrt(3) : 1;
    const apparentPowerVa = factor * voltageLL * currentA;
    const realPowerW = apparentPowerVa * powerFactor;
    const sinPhi = Math.sqrt(Math.max(0, 1 - powerFactor * powerFactor));
    const reactivePowerVar = apparentPowerVa * sinPhi;

    return {
      realPowerKw: realPowerW / 1000,
      reactivePowerKvar: reactivePowerVar / 1000,
      apparentPowerKva: apparentPowerVa / 1000,
    };
  }

  /**
   * Calculates DC link voltage ripple and capacitor current stress.
   * Delta_V_dc = I_dc / (2 * f_grid * C_dc_link)
   */
  public static calculateDcLinkRipple(
    dcOutputCurrentA: number,
    dcLinkCapacitanceFarad: number = 0.005, // 5000 uF
    gridFrequencyHz: number = 50
  ): { rippleVoltagePeakToPeakV: number; ripplePercent: number } {
    if (dcOutputCurrentA <= 0.1 || dcLinkCapacitanceFarad <= 0) {
      return { rippleVoltagePeakToPeakV: 0.1, ripplePercent: 0.01 };
    }
    const rippleV = dcOutputCurrentA / (2 * gridFrequencyHz * 6 * dcLinkCapacitanceFarad); // 6-pulse / active rectifier
    return {
      rippleVoltagePeakToPeakV: Math.min(rippleV, 25),
      ripplePercent: (rippleV / 800) * 100,
    };
  }

  /**
   * Calculates copper resistive conduction loss: P_loss = I^2 * R
   * R(T) = R_20 * (1 + alpha * (T - 20))
   * For Copper: alpha = 0.00393 / °C, resistivity = 1.72e-8 Ohm*m
   */
  public static calculateCableLosses(
    cable: CableAndConnectorSpec,
    currentA: number
  ): {
    resistanceOhm: number;
    voltageDropV: number;
    cableLossKw: number;
    connectorLossKw: number;
    totalLossKw: number;
  } {
    const alphaCu = 0.00393;
    const tRef = 20;
    const tempC = Math.max(10, cable.cableTempC);
    
    // Cross-sectional area in m^2
    const csaM2 = cable.cableCsaMm2 * 1e-6;
    // Length for 2 conductors (DC + and DC -)
    const totalLengthM = cable.cableLengthM * 2;
    
    // Base resistance at 20°C
    const r20 = (cable.conductorResistivityOhmM * totalLengthM) / csaM2;
    // Temperature corrected resistance
    const rTemp = r20 * (1 + alphaCu * (tempC - tRef));
    
    // Conductor voltage drop & loss
    const voltageDropCable = currentA * rTemp;
    const cableLossW = currentA * currentA * rTemp;

    // Connector pin contact resistance loss (e.g. 2 pins * 0.15 mOhm)
    const pinContactOhm = (cable.contactResistanceMilliohm * 1e-3) * 2;
    const voltageDropConnector = currentA * pinContactOhm;
    const connectorLossW = currentA * currentA * pinContactOhm;

    return {
      resistanceOhm: rTemp,
      voltageDropV: voltageDropCable + voltageDropConnector,
      cableLossKw: cableLossW / 1000,
      connectorLossKw: connectorLossW / 1000,
      totalLossKw: (cableLossW + connectorLossW) / 1000,
    };
  }

  /**
   * Transformer load loss and voltage regulation under heavy charging demand.
   */
  public static calculateTransformerState(
    grid: GridParameters,
    siteDemandKw: number
  ): {
    transformerLoadPercent: number;
    voltageDropPercent: number;
    secondaryVoltageV: number;
    transformerLossKw: number;
  } {
    const sSiteKva = siteDemandKw / Math.max(0.7, grid.powerFactorTarget);
    const loadFraction = sSiteKva / Math.max(10, grid.transformerRatingKva);
    const transformerLoadPercent = loadFraction * 100;

    // Typical transformer core + copper loss
    // P_loss = P_no_load + (loadFraction^2) * P_load
    const noLoadLossKw = grid.transformerRatingKva * 0.003; // ~0.3% core loss
    const fullLoadLossKw = grid.transformerRatingKva * 0.012; // ~1.2% copper loss
    const transformerLossKw = noLoadLossKw + Math.pow(loadFraction, 2) * fullLoadLossKw;

    // Voltage drop based on transformer % impedance
    const voltageDropPercent = loadFraction * (grid.transformerImpedancePercent * 0.8);
    const secondaryVoltageV = grid.nominalVoltageLL * (1 - voltageDropPercent / 100);

    return {
      transformerLoadPercent: Math.min(transformerLoadPercent, 180),
      voltageDropPercent,
      secondaryVoltageV,
      transformerLossKw,
    };
  }
}
