// Communication & Protocol Engine
// ISO 15118-20, DIN 70121, IEC 61851-1 Control Pilot, and OCPP 2.0.1 State Machines

import { ProtocolMessage, SessionState } from './types';

export interface ControlPilotState {
  state: 'A' | 'B' | 'C' | 'D' | 'E' | 'F';
  voltageVolts: number;
  pwmFrequencyHz: number;
  dutyCyclePercent: number;
  availableCurrentA: number;
  description: string;
}

export class ProtocolEngine {
  /**
   * Generates IEC 61851-1 Control Pilot status based on Session State and Max Current.
   * Duty Cycle mapping: Current (A) = DutyCycle (%) * 0.6 (for 10% - 85%)
   */
  public static evaluateControlPilot(
    sessionState: SessionState,
    maxCurrentA: number = 500
  ): ControlPilotState {
    const dutyCycle = Math.min(96, Math.max(10, (Math.min(maxCurrentA, 80) / 0.6))); // 10% - 96%
    
    switch (sessionState) {
      case 'IDLE':
      case 'AVAILABLE':
        return {
          state: 'A',
          voltageVolts: 12.0,
          pwmFrequencyHz: 0,
          dutyCyclePercent: 100,
          availableCurrentA: 0,
          description: 'State A: Standby, No vehicle connected (+12V DC)',
        };
      case 'CONNECTED':
      case 'AUTHENTICATING':
      case 'NEGOTIATING':
      case 'PREPARING':
        return {
          state: 'B',
          voltageVolts: 9.0,
          pwmFrequencyHz: 1000,
          dutyCyclePercent: 5.0, // 5% duty cycle = digital comms (ISO 15118 / DIN 70121 PLC active)
          availableCurrentA: 0,
          description: 'State B: Vehicle connected, Digital PLC negotiation active (+9V PWM 5%)',
        };
      case 'CHARGING':
      case 'TAPERING':
        return {
          state: 'C',
          voltageVolts: 6.0,
          pwmFrequencyHz: 1000,
          dutyCyclePercent: 5.0, // High-level digital communication
          availableCurrentA: maxCurrentA,
          description: `State C: Power delivery active, Contactors closed (+6V PWM)`,
        };
      case 'STOPPING':
      case 'COMPLETED':
        return {
          state: 'B',
          voltageVolts: 9.0,
          pwmFrequencyHz: 1000,
          dutyCyclePercent: 100,
          availableCurrentA: 0,
          description: 'State B: Session termination / Contactors opened',
        };
      case 'FAULT':
      case 'EMERGENCY_STOP':
      default:
        return {
          state: 'F',
          voltageVolts: -12.0,
          pwmFrequencyHz: 0,
          dutyCyclePercent: 0,
          availableCurrentA: 0,
          description: 'State F: Fault condition / Safe interlock tripped (-12V DC)',
        };
    }
  }

  /**
   * Generates real-time ISO 15118-20 and OCPP 2.0.1 sequence messages for the active session.
   */
  public static createProtocolMessage(
    sessionState: SessionState,
    voltageV: number,
    currentA: number,
    powerKw: number,
    soc: number
  ): ProtocolMessage {
    const timestamp = Date.now();
    const id = `MSG_${timestamp}_${Math.floor(Math.random() * 1000)}`;

    switch (sessionState) {
      case 'AUTHENTICATING':
        return {
          id,
          timestamp,
          protocol: 'ISO_15118_20',
          direction: 'VEHICLE_TO_CHARGER',
          messageName: 'AuthorizationReq',
          payload: {
            authType: 'Contract',
            eId: 'EMAID:US-V2G-1894726-X',
            challenge: '0x9F4C2A1E8B0D7F63',
          },
          rawHex: '80 01 02 03 45 4D 41 49 44 2D 55 53 2D 56 32 47',
          stateChange: 'AUTHENTICATING',
          latencyMs: 14.2,
        };

      case 'NEGOTIATING':
        return {
          id,
          timestamp,
          protocol: 'ISO_15118_20',
          direction: 'CHARGER_TO_VEHICLE',
          messageName: 'ChargeParameterDiscoveryRes',
          payload: {
            EVSEMaxPowerLimit: 350000,
            EVSEMaxVoltageLimit: 1000,
            EVSEMaxCurrentLimit: 500,
            EVSEMinVoltageLimit: 150,
            EVSEMinCurrentLimit: 2,
            EVSENominalFrequency: 50,
            EnergyTransferMode: 'DC_extended',
          },
          rawHex: '80 98 01 00 05 57 30 03 E8 01 F4 00 96 00 02',
          stateChange: 'NEGOTIATING',
          latencyMs: 18.5,
        };

      case 'PREPARING':
        return {
          id,
          timestamp,
          protocol: 'ISO_15118_20',
          direction: 'VEHICLE_TO_CHARGER',
          messageName: 'PreChargeReq',
          payload: {
            EVTargetVoltage: Number(voltageV.toFixed(1)),
            EVTargetCurrent: 2.0, // Low current matching
          },
          rawHex: '80 04 01 03 20 00 02',
          stateChange: 'PREPARING',
          latencyMs: 11.8,
        };

      case 'CHARGING':
      case 'TAPERING':
        return {
          id,
          timestamp,
          protocol: 'ISO_15118_20',
          direction: 'VEHICLE_TO_CHARGER',
          messageName: 'CurrentDemandReq',
          payload: {
            EVTargetVoltage: Number(voltageV.toFixed(1)),
            EVTargetCurrent: Number(currentA.toFixed(1)),
            EVMaximumPowerLimit: 350000,
            EVPresentSOC: Number((soc * 100).toFixed(1)),
            BulkChargingComplete: soc > 0.80,
            ChargingComplete: soc >= 0.99,
          },
          rawHex: '80 05 02 ' + Math.floor(voltageV).toString(16).padStart(4, '0') + ' ' + Math.floor(currentA).toString(16).padStart(4, '0'),
          stateChange: sessionState,
          latencyMs: 9.4,
        };

      case 'STOPPING':
      case 'COMPLETED':
        return {
          id,
          timestamp,
          protocol: 'ISO_15118_20',
          direction: 'CHARGER_TO_VEHICLE',
          messageName: 'WeldingDetectionRes',
          payload: {
            EVSEPresentVoltage: 2.4, // Confirmed safe de-energized voltage < 20V
            ResponseCode: 'OK',
          },
          rawHex: '80 07 01 00 00 18',
          stateChange: 'COMPLETED',
          latencyMs: 15.6,
        };

      default:
        return {
          id,
          timestamp,
          protocol: 'OCPP_201',
          direction: 'CHARGER_TO_CSMS',
          messageName: 'StatusNotificationRequest',
          payload: {
            connectorId: 1,
            connectorStatus: sessionState === 'AVAILABLE' ? 'Available' : 'Occupied',
            timestamp: new Date().toISOString(),
          },
          rawHex: '7B 22 63 6F 6E 6E 65 63 74 6F 72 49 64 22 3A 31 7D',
          stateChange: sessionState,
          latencyMs: 25.1,
        };
    }
  }
}
