// CHARGEFORGE.OS Canonical Data Model & Type Definitions
// Rigorous Engineering Specifications for EV Charging Digital Twin

export type ChargerClass = 'AC_LEVEL_1' | 'AC_LEVEL_2' | 'DC_FAST' | 'DC_HIGH_POWER' | 'ULTRA_HIGH_POWER' | 'MEGAWATT_MCS';

export type FidelityLevel = 'FIDELITY_0_CONCEPTUAL' | 'FIDELITY_1_APPROXIMATION' | 'FIDELITY_2_ENGINEERING' | 'FIDELITY_3_CALIBRATED';

export type TwinDataState = 'REAL' | 'ESTIMATED' | 'SIMULATED' | 'PREDICTED';

export type SessionState = 
  | 'IDLE'
  | 'AVAILABLE'
  | 'CONNECTED'
  | 'AUTHENTICATING'
  | 'NEGOTIATING'
  | 'PREPARING'
  | 'CHARGING'
  | 'TAPERING'
  | 'STOPPING'
  | 'COMPLETED'
  | 'FAULT'
  | 'EMERGENCY_STOP';

export type SafetyState = 
  | 'NORMAL'
  | 'WARNING'
  | 'DERATED'
  | 'FAULT'
  | 'TRIP'
  | 'EMERGENCY_STOP'
  | 'RECOVERY';

export type CoolingType = 'PASSIVE' | 'FORCED_AIR' | 'LIQUID_GLYCOL' | 'REFRIGERATED_CHILLER' | 'HYBRID_ACTIVE';

export type ConnectorType = 'CCS1' | 'CCS2' | 'NACS_J3400' | 'CHADEMO' | 'GB_T' | 'MCS_MEGACAB';

export type BatteryChemistry = 'NMC_811' | 'NMC_622' | 'LFP' | 'NCA' | 'SOLID_STATE';

export type SharingPolicy = 
  | 'FIRST_COME_FIRST_SERVE'
  | 'EQUAL_SHARE'
  | 'PRIORITY_WEIGHTED'
  | 'MAX_ACCEPTANCE_RATE'
  | 'SOC_AWARE_OPTIMAL'
  | 'GRID_CONSTRAINED';

export type FaultType = 
  | 'OVERVOLTAGE_GRID'
  | 'UNDERVOLTAGE_GRID'
  | 'OVERCURRENT_DC'
  | 'OVERTEMPERATURE_MODULE'
  | 'OVERTEMPERATURE_CABLE'
  | 'OVERTEMPERATURE_CONNECTOR'
  | 'INSULATION_RESISTANCE_FAULT'
  | 'GROUND_FAULT'
  | 'COOLANT_PUMP_STALL'
  | 'RADIATOR_FAN_FAILURE'
  | 'CONTACTOR_WELD_FAILURE'
  | 'COMM_TIMEOUT_VEHICLE'
  | 'COMM_TIMEOUT_BACKEND'
  | 'POWER_MODULE_TRIP'
  | 'PILOT_SIGNAL_ERROR'
  | 'EMERGENCY_STOP_PRESSED';

export interface GridParameters {
  nominalVoltageLL: number; // V AC (e.g. 400V, 480V)
  nominalVoltageLN: number; // V AC (e.g. 230V, 277V)
  frequency: number; // Hz (50 or 60)
  phaseCount: 1 | 3;
  transformerRatingKva: number; // kVA (e.g. 500, 1000)
  transformerImpedancePercent: number; // % (e.g. 5.75%)
  breakerRatingA: number; // A (e.g. 630A)
  powerFactorTarget: number; // e.g. 0.99 with active PFC
  thdCurrentMaxPercent: number; // % THD (e.g. < 5%)
  maxImportKw: number; // kW site limit
  liveVoltageLL: number; // V
  liveCurrent: number; // A
  livePowerFactor: number;
  liveRealPowerKw: number;
  liveReactivePowerKvar: number;
  liveApparentPowerKva: number;
}

export interface PowerModuleSpec {
  id: string;
  name: string;
  nominalPowerKw: number; // e.g. 50 kW or 75 kW
  maxVoltageOut: number; // V (e.g. 1000V)
  minVoltageOut: number; // V (e.g. 150V)
  maxCurrentOut: number; // A (e.g. 133A)
  topology: 'VIENNA_RECTIFIER_LLC' | 'DUAL_ACTIVE_BRIDGE' | 'THREE_LEVEL_PFC_BUCK';
  semiconductorTech: 'SiC_MOSFET' | 'GaN_HEMT' | 'IGBT_7';
  switchingFrequencyKhz: number; // kHz (e.g. 65 kHz)
  peakEfficiency: number; // e.g. 0.975 (97.5%)
  heatsinkThermalResistance: number; // K/W
  thermalCapacitance: number; // J/K
  temperatureC: number;
  status: 'ONLINE' | 'STANDBY' | 'FAULT' | 'DEGRADED';
  outputCurrentA: number;
  outputVoltageV: number;
  outputPowerKw: number;
  lossKw: number;
  efficiency: number;
}

export interface CoolingSystemSpec {
  type: CoolingType;
  coolantFluid: 'WATER_GLYCOL_50_50' | 'DIELECTRIC_OIL' | 'R134A_REFRIGERANT';
  specificHeatJkgK: number; // J/(kg*K) ~ 3450 for 50/50 glycol
  densityKgM3: number; // kg/m3 ~ 1060
  pumpMaxFlowLpm: number; // Litres per minute
  currentFlowLpm: number;
  pumpSpeedPercent: number;
  radiatorFanSpeedPercent: number;
  coolantInletTempC: number;
  coolantOutletTempC: number;
  ambientTempC: number;
  heatsinkTargetTempC: number;
  pumpStatus: 'RUNNING' | 'OFF' | 'STALLED' | 'DEGRADED';
  fanStatus: 'RUNNING' | 'OFF' | 'FAILED';
  heatDissipatedKw: number;
}

export interface CableAndConnectorSpec {
  connectorType: ConnectorType;
  cableLengthM: number;
  cableCsaMm2: number; // Copper cross-section mm^2 (e.g. 70 mm2)
  conductorResistivityOhmM: number; // ~ 1.72e-8 Ohm*m
  liquidCooled: boolean;
  contactResistanceMilliohm: number; // Connector pin contact resistance (e.g. 0.15 mOhm)
  cableMaxCurrentA: number; // Continuous rated A
  currentA: number;
  voltageV: number;
  voltageDropV: number;
  cableLossKw: number;
  connectorLossKw: number;
  cableTempC: number;
  connectorPinTempC: number;
  maxAllowableTempC: number; // e.g. 90°C for cable, 85°C for connector
  lockingMechanism: 'UNLOCKED' | 'LOCKING' | 'LOCKED' | 'ERROR';
}

export interface BatteryEquivalentCircuit {
  modelType: 'THEVENIN_2RC' | 'RINT_SIMPLE' | 'DATA_DRIVEN';
  chemistry: BatteryChemistry;
  nominalCapacityKwh: number;
  usableCapacityKwh: number;
  cellSeriesCount: number;
  cellParallelCount: number;
  nominalVoltageV: number; // e.g. 800V or 400V
  openCircuitVoltageV: number; // OCV(SoC)
  terminalVoltageV: number; // Terminal voltage under load
  r0InternalResistanceMilliohm: number; // Ohmic resistance R0
  r1PolarizationMilliohm: number; // RC branch 1 resistance
  c1PolarizationFarad: number; // RC branch 1 capacitance
  r2PolarizationMilliohm: number; // RC branch 2 resistance
  c2PolarizationFarad: number; // RC branch 2 capacitance
  vRc1: number; // Dynamic voltage drop on RC1
  vRc2: number; // Dynamic voltage drop on RC2
  currentA: number;
  socCurrent: number; // 0.0 to 1.0 (e.g. 0.20 = 20%)
  socStart: number;
  socTarget: number;
  sohCurrent: number; // State of Health (0.0 to 1.0)
  temperatureC: number;
  maxChargePowerKw: number;
  maxChargeCurrentA: number;
  chargeEfficiency: number;
}

export interface VehicleModelSpec {
  vehicleId: string;
  vehicleName: string;
  makeModel: string;
  architectureVoltage: 400 | 800 | 1000;
  maxChargePowerKw: number;
  maxChargeCurrentA: number;
  battery: BatteryEquivalentCircuit;
  requestedVoltageV: number;
  requestedCurrentA: number;
  requestedPowerKw: number;
  chargeCurveType: 'PEAK_THEN_STEP_TAPER' | 'LINEAR_TAPER' | 'AGGRESSIVE_PLATEAU';
}

export interface ChargerHardwareSpec {
  chargerId: string;
  modelName: string;
  manufacturer: string;
  firmwareVersion: string;
  hardwareRevision: string;
  chargerClass: ChargerClass;
  ratedPowerKw: number; // e.g. 350 kW
  maxOutputVoltageV: number; // e.g. 1000V
  minOutputVoltageV: number; // e.g. 150V
  maxOutputCurrentA: number; // e.g. 500A
  moduleArray: PowerModuleSpec[];
  cooling: CoolingSystemSpec;
  cables: CableAndConnectorSpec[];
  standbyPowerKw: number;
  operatingTempMinC: number;
  operatingTempMaxC: number;
  thermalDerateThresholdC: number;
  thermalTripThresholdC: number;
  isolationResistanceMOhm: number; // > 100 Ohm/V standard -> > 0.5 MOhm
  dcContactorState: 'OPEN' | 'CLOSING' | 'CLOSED' | 'OPENING' | 'WELDED';
  acBreakerState: 'CLOSED' | 'TRIPPED' | 'OPEN';
}

export interface ActiveFault {
  id: string;
  type: FaultType;
  severity: 'WARNING' | 'CRITICAL' | 'FATAL';
  timestamp: number;
  message: string;
  cleared: boolean;
  component: string;
}

export interface SensorTelemetry {
  id: string;
  name: string;
  raw: number;
  filtered: number; // Kalman / Lowpass
  estimated: number;
  validated: boolean;
  unit: string;
  noiseSigma: number;
  status: 'HEALTHY' | 'DEGRADED' | 'FAILED';
  confidence: number; // 0.0 to 1.0
}

export interface ProtocolMessage {
  id: string;
  timestamp: number;
  protocol: 'ISO_15118_20' | 'DIN_70121' | 'IEC_61851' | 'OCPP_201';
  direction: 'VEHICLE_TO_CHARGER' | 'CHARGER_TO_VEHICLE' | 'CHARGER_TO_CSMS' | 'CSMS_TO_CHARGER';
  messageName: string;
  payload: Record<string, unknown>;
  rawHex: string;
  stateChange?: string;
  latencyMs: number;
}

export interface EnergyAccounting {
  energyImportedKwh: number;
  energyDeliveredKwh: number;
  energyLostKwh: number;
  conversionLossesKwh: number;
  cableLossesKwh: number;
  coolingConsumptionKwh: number;
  standbyLossesKwh: number;
  energyResidualKwh: number; // Conservation balance: Ein - Eout - Eloss
  overallEfficiencyPercent: number;
  sessionDurationSec: number;
  peakPowerKw: number;
  averagePowerKw: number;
}

export interface ChargingSessionSummary {
  sessionId: string;
  chargerId: string;
  vehicleId: string;
  startTime: number;
  endTime?: number;
  initialSoc: number;
  targetSoc: number;
  currentSoc: number;
  energyDeliveredKwh: number;
  energyImportedKwh: number;
  averagePowerKw: number;
  peakPowerKw: number;
  durationSeconds: number;
  totalCostUsd: number;
  revenueUsd: number;
  grossMarginPercent: number;
  sessionState: SessionState;
  safetyState: SafetyState;
  faults: ActiveFault[];
}

export interface SiteMicrogridSpec {
  siteName: string;
  transformerCapacityKva: number;
  solarPvPeakKw: number;
  solarPvCurrentKw: number;
  bessCapacityKwh: number;
  bessCurrentKwh: number;
  bessMaxPowerKw: number;
  bessCurrentPowerKw: number; // + is discharging, - is charging
  buildingBaseLoadKw: number;
  activeStallsCount: number;
  totalStallsCount: number;
  siteTotalDemandKw: number;
  gridImportKw: number;
  tariffPerKwhUsd: number;
  peakDemandChargeUsdPerKw: number;
  sharingPolicy: SharingPolicy;
}

export interface SimulationTelemetryFrame {
  timestampSec: number;
  clockStepMs: number;
  timeString: string;
  grid: GridParameters;
  charger: ChargerHardwareSpec;
  vehicle: VehicleModelSpec;
  session: ChargingSessionSummary;
  energy: EnergyAccounting;
  sensors: Record<string, SensorTelemetry>;
  safety: SafetyState;
  activeFaults: ActiveFault[];
  derateFactor: number; // 0.0 to 1.0
  derateReason?: string;
}

export interface GoldenTestReference {
  name: string;
  ratedPowerKw: number;
  batteryCapacityKwh: number;
  initialSoc: number;
  targetSoc: number;
  ambientTempC: number;
  expectedEnergyDeliveredKwh: number;
  expectedTimeSeconds: number;
  expectedPeakPowerKw: number;
  expectedAvgEfficiencyPercent: number;
  expectedMaxTempC: number;
  tolerancePercent: number;
}
