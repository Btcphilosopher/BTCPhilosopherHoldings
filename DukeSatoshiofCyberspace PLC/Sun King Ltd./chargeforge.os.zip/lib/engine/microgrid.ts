// Site Microgrid, Solar PV, and BESS Energy Management Subsystem
// Peak Shaving, TOU Economic Dispatch, and Transformer Capacity Protection

import { SiteMicrogridSpec } from './types';

export interface MicrogridEnergyFlow {
  gridImportKw: number;
  solarGenerationKw: number;
  bessDischargeKw: number;
  bessChargeKw: number;
  evTotalDemandKw: number;
  buildingBaseLoadKw: number;
  siteTotalLoadKw: number;
  transformerUtilizationPercent: number;
  curtailedSolarKw: number;
  peakShavedKw: number;
  costRateUsdPerHour: number;
}

export class MicrogridEngine {
  /**
   * Generates solar PV output based on hour of day (0-24) and peak capacity.
   * Model: Half-sine solar irradiance curve from 6:00 to 18:00
   */
  public static calculateSolarOutput(peakKw: number, hourOfDay: number): number {
    if (hourOfDay < 6.0 || hourOfDay > 18.0) return 0;
    const solarFraction = Math.sin(((hourOfDay - 6.0) / 12.0) * Math.PI);
    return Math.max(0, peakKw * Math.pow(solarFraction, 1.2));
  }

  /**
   * Performs dynamic BESS dispatch and peak shaving to protect transformer capacity and minimize grid import.
   */
  public static calculateSiteDispatch(
    spec: SiteMicrogridSpec,
    evDemandedKw: number,
    hourOfDay: number = 14.5
  ): MicrogridEnergyFlow {
    const solarGenKw = this.calculateSolarOutput(spec.solarPvPeakKw, hourOfDay);
    const totalSiteDemandKw = evDemandedKw + spec.buildingBaseLoadKw;

    // Transformer capacity limit in kW (assumes PF 0.98)
    const transformerLimitKw = spec.transformerCapacityKva * 0.98;

    // Net demand before BESS
    const netDemandBeforeBess = totalSiteDemandKw - solarGenKw;

    let bessDischargeKw = 0;
    let bessChargeKw = 0;
    let gridImportKw = 0;
    let curtailedSolarKw = 0;
    let peakShavedKw = 0;

    const bessSoc = spec.bessCapacityKwh > 0 ? spec.bessCurrentKwh / spec.bessCapacityKwh : 0;

    if (netDemandBeforeBess > transformerLimitKw) {
      // Need peak shaving: discharge BESS if available
      const deficit = netDemandBeforeBess - transformerLimitKw;
      if (bessSoc > 0.15) {
        bessDischargeKw = Math.min(deficit, spec.bessMaxPowerKw);
        peakShavedKw = bessDischargeKw;
      }
      gridImportKw = Math.min(transformerLimitKw, netDemandBeforeBess - bessDischargeKw);
    } else if (netDemandBeforeBess < 0) {
      // Solar surplus: charge BESS
      const surplus = Math.abs(netDemandBeforeBess);
      if (bessSoc < 0.95) {
        bessChargeKw = Math.min(surplus, spec.bessMaxPowerKw);
      } else {
        curtailedSolarKw = surplus;
      }
      gridImportKw = 0;
    } else {
      // Normal demand: If TOU peak hour (16:00 - 21:00) and BESS has charge, discharge partially for economic optimization
      const isPeakHour = hourOfDay >= 16.0 && hourOfDay <= 21.0;
      if (isPeakHour && bessSoc > 0.25) {
        bessDischargeKw = Math.min(netDemandBeforeBess * 0.4, spec.bessMaxPowerKw);
      }
      gridImportKw = netDemandBeforeBess - bessDischargeKw;
    }

    const transformerUtilizationPercent = (gridImportKw / transformerLimitKw) * 100;
    const costRateUsdPerHour = (gridImportKw * spec.tariffPerKwhUsd);

    return {
      gridImportKw: Math.max(0, gridImportKw),
      solarGenerationKw: solarGenKw,
      bessDischargeKw,
      bessChargeKw,
      evTotalDemandKw: evDemandedKw,
      buildingBaseLoadKw: spec.buildingBaseLoadKw,
      siteTotalLoadKw: totalSiteDemandKw,
      transformerUtilizationPercent: Math.min(150, transformerUtilizationPercent),
      curtailedSolarKw,
      peakShavedKw,
      costRateUsdPerHour,
    };
  }
}
