'use client';

import React, { useState } from 'react';
import { MonteCarloEngine, MonteCarloSummary, ParetoDesignPoint } from '@/lib/engine/monteCarlo';
import { Layers, Sliders, Play, TrendingUp, Sparkles, Award, DollarSign } from 'lucide-react';

export const MonteCarloStudio: React.FC = () => {
  const [runCount, setRunCount] = useState<number>(100);
  const [summary, setSummary] = useState<MonteCarloSummary>(() => {
    return MonteCarloEngine.runMonteCarloSimulation(350, 100, 0.20, 0.80, 100);
  });
  const [activeTab, setActiveTab] = useState<'MONTE_CARLO' | 'PARETO_FRONTIER'>('MONTE_CARLO');
  const paretoPoints = MonteCarloEngine.generateParetoFrontier();

  const handleRunSimulation = () => {
    const res = MonteCarloEngine.runMonteCarloSimulation(350, 100, 0.20, 0.80, runCount);
    setSummary(res);
  };

  return (
    <div className="w-full bg-[#0a0e14] border border-slate-800 rounded-xl p-4 flex flex-col gap-5 font-mono">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-3">
          <Layers className="w-5 h-5 text-purple-400" />
          <div>
            <h3 className="text-sm font-bold text-white tracking-wide">STOCHASTIC MONTE CARLO & MULTI-OBJECTIVE PARETO OPTIMIZER</h3>
            <div className="text-[11px] text-slate-400">
              Probabilistic Risk Assessment • P10/P50/P90 Quantile Envelopes • CAPEX vs Efficiency Trade-offs
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <div className="bg-slate-900 border border-slate-800 rounded p-1 flex gap-1">
            <button
              onClick={() => setActiveTab('MONTE_CARLO')}
              className={`px-3 py-1.5 rounded ${activeTab === 'MONTE_CARLO' ? 'bg-purple-950 border border-purple-500/60 text-purple-300 font-bold' : 'text-slate-400'}`}
            >
              Monte Carlo (N={runCount})
            </button>
            <button
              onClick={() => setActiveTab('PARETO_FRONTIER')}
              className={`px-3 py-1.5 rounded ${activeTab === 'PARETO_FRONTIER' ? 'bg-purple-950 border border-purple-500/60 text-purple-300 font-bold' : 'text-slate-400'}`}
            >
              Pareto Frontier
            </button>
          </div>

          {activeTab === 'MONTE_CARLO' && (
            <button
              onClick={handleRunSimulation}
              className="px-3.5 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold flex items-center gap-1.5 transition-all shadow-md shadow-purple-950/40"
            >
              <Play className="w-3.5 h-3.5 fill-current" /> Run Simulation
            </button>
          )}
        </div>
      </div>

      {activeTab === 'MONTE_CARLO' && (
        <div className="flex flex-col gap-4">
          {/* P10, P50, P90 Quantile KPI Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-3 flex flex-col justify-between">
              <div className="text-slate-400 text-[10px]">CHARGING TIME (20% → 80%)</div>
              <div className="my-1 flex items-baseline gap-2">
                <span className="text-xl font-bold text-white">{summary.timeP50Min.toFixed(1)} min</span>
                <span className="text-[11px] text-purple-400">(P50 Median)</span>
              </div>
              <div className="text-[10px] text-slate-500 flex justify-between border-t border-slate-800/80 pt-1">
                <span>P10 (Fast): {summary.timeP10Min.toFixed(1)}m</span>
                <span>P90 (Slow): {summary.timeP90Min.toFixed(1)}m</span>
              </div>
            </div>

            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-3 flex flex-col justify-between">
              <div className="text-slate-400 text-[10px]">PEAK SEMICONDUCTOR TEMP</div>
              <div className="my-1 flex items-baseline gap-2">
                <span className="text-xl font-bold text-amber-400">{summary.maxTempP50C.toFixed(1)} °C</span>
                <span className="text-[11px] text-purple-400">(P50 Median)</span>
              </div>
              <div className="text-[10px] text-slate-500 flex justify-between border-t border-slate-800/80 pt-1">
                <span>P10: {summary.maxTempP10C.toFixed(1)}°C</span>
                <span>P90: {summary.maxTempP90C.toFixed(1)}°C</span>
              </div>
            </div>

            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-3 flex flex-col justify-between">
              <div className="text-slate-400 text-[10px]">SYSTEM EFFICIENCY (η)</div>
              <div className="my-1 flex items-baseline gap-2">
                <span className="text-xl font-bold text-emerald-400">{summary.efficiencyP50Percent.toFixed(2)} %</span>
                <span className="text-[11px] text-purple-400">(P50 Median)</span>
              </div>
              <div className="text-[10px] text-slate-500 flex justify-between border-t border-slate-800/80 pt-1">
                <span>Energy: {summary.energyP50Kwh.toFixed(1)} kWh</span>
                <span>Margin: ±0.6%</span>
              </div>
            </div>

            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-3 flex flex-col justify-between">
              <div className="text-slate-400 text-[10px]">TOTAL RUNS PROCESSED</div>
              <div className="my-1 flex items-baseline gap-2">
                <span className="text-xl font-bold text-cyan-400">{summary.sampleCount}</span>
                <span className="text-[11px] text-slate-400">Latin Hypercube</span>
              </div>
              <div className="text-[10px] text-emerald-400 flex justify-between border-t border-slate-800/80 pt-1">
                <span>99.8% Reliability Envelope</span>
              </div>
            </div>
          </div>

          {/* Scatter Plot / Distribution SVG */}
          <div className="bg-[#090d14] border border-slate-800 rounded-xl p-4 flex flex-col gap-2">
            <div className="text-xs text-slate-400 font-semibold flex items-center justify-between">
              <span>PROBABILISTIC SCATTER CLOUD (Ambient Temp vs Charge Time)</span>
              <span className="text-[10px] text-slate-500">N={summary.runs.length} Runs</span>
            </div>
            <div className="w-full h-56 bg-[#05070a] rounded border border-slate-800/80 p-2">
              <svg className="w-full h-full" viewBox="0 0 600 200" preserveAspectRatio="none">
                {/* Horizontal Guide Lines */}
                <line x1="0" y1="50" x2="600" y2="50" stroke="#1e293b" strokeDasharray="3,3" />
                <line x1="0" y1="100" x2="600" y2="100" stroke="#1e293b" strokeDasharray="3,3" />
                <line x1="0" y1="150" x2="600" y2="150" stroke="#1e293b" strokeDasharray="3,3" />

                {/* Scatter Dots */}
                {summary.runs.map((r, i) => {
                  // X: Ambient Temp (-10°C to 50°C -> 60°C range)
                  const x = Math.max(10, Math.min(590, ((r.ambientTempC + 10) / 60) * 600));
                  // Y: Charge Time (10m to 25m -> 15m range)
                  const y = Math.max(10, Math.min(190, 190 - ((r.chargeTimeMinutes - 10) / 15) * 170));
                  return (
                    <circle
                      key={i}
                      cx={x}
                      cy={y}
                      r="3.5"
                      fill="#a855f7"
                      opacity="0.75"
                    />
                  );
                })}
              </svg>
            </div>
            <div className="flex items-center justify-between text-[10px] text-slate-500">
              <span>X-Axis: Ambient Temperature (-10°C → +50°C)</span>
              <span>Y-Axis: Total Charge Time (10 min → 25 min)</span>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'PARETO_FRONTIER' && (
        <div className="flex flex-col gap-3">
          <div className="text-xs text-slate-400">
            Multi-Objective Pareto Analysis exploring optimal trade-offs between Charger CAPEX, System Efficiency, and Daily Vehicle Throughput.
          </div>
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="text-slate-500 border-b border-slate-800 pb-2">
                <th className="py-1">HARDWARE DESIGN VARIANT</th>
                <th>RATED POWER</th>
                <th>MODULES</th>
                <th>CAPEX (USD)</th>
                <th>EFFICIENCY (η)</th>
                <th>CHARGE TIME</th>
                <th>DAILY THROUGHPUT</th>
                <th>PARETO STATUS</th>
              </tr>
            </thead>
            <tbody>
              {paretoPoints.map((pt) => (
                <tr key={pt.id} className="border-b border-slate-800/50 text-slate-300">
                  <td className="py-2.5 font-bold text-white">{pt.name}</td>
                  <td className="text-cyan-400 font-bold">{pt.ratedPowerKw} kW</td>
                  <td>{pt.powerModuleCount}x Blocks</td>
                  <td className="text-emerald-400 font-bold">${pt.capexUsd.toLocaleString()}</td>
                  <td>{pt.averageEfficiencyPercent.toFixed(1)}%</td>
                  <td>{pt.chargeTimeMinutes} min</td>
                  <td className="text-white font-bold">{pt.dailyVehicleThroughput} EVs/day</td>
                  <td>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      pt.isParetoOptimal ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/60' : 'bg-slate-900 text-slate-500'
                    }`}>
                      {pt.isParetoOptimal ? 'PARETO OPTIMAL' : 'DOMINATED'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
