'use client';

import React, { useState } from 'react';
import { PythonRunnerEngine, SAMPLE_PYTHON_SCRIPTS, PythonExecutionResult } from '@/lib/engine/pythonRunner';
import { Terminal, Play, RotateCcw, Check, Sparkles, TrendingUp, Code2 } from 'lucide-react';

interface PythonIdeProps {
  onSyncTwinParams?: (params: Record<string, unknown>) => void;
}

export const PythonIde: React.FC<PythonIdeProps> = ({ onSyncTwinParams }) => {
  const [selectedSampleKey, setSelectedSampleKey] = useState<string>('CC_CV_SIMULATION');
  const [scriptCode, setScriptCode] = useState<string>(SAMPLE_PYTHON_SCRIPTS['CC_CV_SIMULATION'].code);
  const [result, setResult] = useState<PythonExecutionResult | null>(() => {
    return PythonRunnerEngine.executeScript(SAMPLE_PYTHON_SCRIPTS['CC_CV_SIMULATION'].code);
  });
  const [isExecuting, setIsExecuting] = useState(false);

  const handleSelectSample = (key: string) => {
    setSelectedSampleKey(key);
    setScriptCode(SAMPLE_PYTHON_SCRIPTS[key].code);
  };

  const handleRunScript = () => {
    setIsExecuting(true);
    setTimeout(() => {
      const res = PythonRunnerEngine.executeScript(scriptCode);
      setResult(res);
      setIsExecuting(false);
      if (res.syncedTwinParams && onSyncTwinParams) {
        onSyncTwinParams(res.syncedTwinParams);
      }
    }, 150);
  };

  return (
    <div className="w-full bg-[#0a0e14] border border-slate-800 rounded-xl p-4 flex flex-col gap-4 font-mono">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-3">
          <Code2 className="w-5 h-5 text-yellow-400" />
          <div>
            <h3 className="text-sm font-bold text-white tracking-wide">PYTHON SCIENTIFIC SCRIPTING & NUMERICAL KERNEL</h3>
            <div className="text-[11px] text-slate-400">
              In-Browser NumPy / SciPy Simulation Engine & Digital Twin Live Synchronizer
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <select
            value={selectedSampleKey}
            onChange={(e) => handleSelectSample(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-300 rounded-lg px-3 py-1.5 focus:outline-none focus:border-yellow-500"
          >
            {Object.entries(SAMPLE_PYTHON_SCRIPTS).map(([k, v]) => (
              <option key={k} value={k}>{v.name}</option>
            ))}
          </select>

          <button
            onClick={handleRunScript}
            disabled={isExecuting}
            className="px-4 py-1.5 rounded-lg bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-bold flex items-center gap-1.5 transition-all shadow-md shadow-yellow-950/40 disabled:opacity-50"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            {isExecuting ? 'Executing...' : 'Run Python Script (Shift+Enter)'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Python Code Editor */}
        <div className="flex flex-col gap-2">
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>INPUT SCRIPT: simulation.py</span>
            <span className="text-[10px] text-slate-500">Python 3.13 Virtualized Kernel</span>
          </div>
          <textarea
            value={scriptCode}
            onChange={(e) => setScriptCode(e.target.value)}
            rows={15}
            spellCheck={false}
            className="w-full bg-[#05070a] text-yellow-100/90 font-mono text-xs p-3.5 rounded-lg border border-slate-800 focus:outline-none focus:border-yellow-500 leading-relaxed resize-none shadow-inner"
          />
        </div>

        {/* Stdout Console & Matplotlib Graph Area */}
        <div className="flex flex-col gap-3">
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              STDOUT / TERMINAL OUTPUT
            </span>
            <span className="text-[10px] text-slate-500">Execution: {result?.executionTimeMs || 0} ms</span>
          </div>

          <div className="bg-[#05070a] border border-slate-800 rounded-lg p-3 text-xs font-mono text-cyan-300 min-h-[160px] max-h-[180px] overflow-y-auto flex flex-col gap-1">
            {result?.stdout.map((line, idx) => (
              <div key={idx} className="leading-tight">{line}</div>
            ))}
            {result?.stderr.map((line, idx) => (
              <div key={idx} className="text-red-400 leading-tight">{line}</div>
            ))}
          </div>

          {/* Matplotlib Figure / Plot */}
          {result?.plots && result.plots.length > 0 && (
            <div className="bg-[#090d14] border border-slate-800 rounded-lg p-3 flex flex-col gap-2">
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-yellow-400" />
                {result.plots[0].title}
              </div>
              <div className="w-full h-32 bg-[#05070a] rounded border border-slate-800/80 p-2">
                <svg className="w-full h-full" viewBox="0 0 400 100" preserveAspectRatio="none">
                  {/* Axes */}
                  <line x1="30" y1="10" x2="30" y2="85" stroke="#334155" strokeWidth="1" />
                  <line x1="30" y1="85" x2="390" y2="85" stroke="#334155" strokeWidth="1" />

                  {/* Polyline */}
                  <polyline
                    fill="none"
                    stroke="#eab308"
                    strokeWidth="2.0"
                    points={result.plots[0].dataPoints
                      .map((pt, i, arr) => {
                        const x = 30 + (i / (arr.length - 1)) * 350;
                        const minY = Math.min(...arr.map(p => p.y));
                        const maxY = Math.max(...arr.map(p => p.y));
                        const yRange = maxY - minY || 1;
                        const y = 80 - ((pt.y - minY) / yRange) * 65;
                        return `${x},${y}`;
                      })
                      .join(' ')}
                  />
                </svg>
              </div>
              <div className="flex items-center justify-between text-[10px] text-slate-500">
                <span>X: {result.plots[0].xLabel}</span>
                <span>Y: {result.plots[0].yLabel}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
