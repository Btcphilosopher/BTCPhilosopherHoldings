'use client';

import React, { useState } from 'react';
import { 
  SimulationTelemetryFrame, 
  ChargerHardwareSpec, 
  VehicleModelSpec, 
  FaultType 
} from '@/lib/engine/types';
import { 
  Activity, 
  Zap, 
  Flame, 
  BatteryCharging, 
  Gauge, 
  ShieldCheck, 
  ShieldAlert, 
  AlertTriangle, 
  Cpu, 
  Waves,
  ArrowRight,
  TrendingUp,
  RotateCcw,
  Sliders
} from 'lucide-react';

interface EngineeringWorkstationProps {
  currentFrame: SimulationTelemetryFrame;
  history: SimulationTelemetryFrame[];
  onInjectFault: (type: FaultType, message: string, comp: string) => void;
  onClearFaults: () => void;
  onEmergencyStop: () => void;
}

export const EngineeringWorkstation: React.FC<EngineeringWorkstationProps> = ({
  currentFrame,
  history,
  onInjectFault,
  onClearFaults,
  onEmergencyStop,
}) => {
  const { charger, vehicle, grid, session, energy, sensors, safety, derateFactor, derateReason } = currentFrame;

  const [activeChartTab, setActiveChartTab] = useState<'POWER_TIME' | 'TEMP_TIME' | 'SOC_TIME' | 'LOSS_WATERFALL'>('POWER_TIME');

  // Chart coordinate computation
  const historyLen = history.length;
  const recentHistory = history.slice(-60); // Last 60 samples

  const maxPowerY = Math.max(400, ...recentHistory.map(h => h.session.peakPowerKw || 0));
  const maxTempY = 100;

  return (
    <div className="flex flex-col gap-5 w-full">
      {/* 1. TOP METRICS INSTRUMENT STRIP */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        {/* Output Power */}
        <div className="bg-[#10151d] border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>CHARGING POWER</span>
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="my-1">
            <span className="text-2xl font-bold font-mono text-cyan-400">
              {(session.sessionState === 'CHARGING' || session.sessionState === 'TAPERING' ? (vehicle.battery.terminalVoltageV * vehicle.battery.currentA) / 1000 : 0).toFixed(1)}
            </span>
            <span className="text-xs text-slate-500 font-mono ml-1">kW</span>
          </div>
          <div className="text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>Peak: {energy.peakPowerKw.toFixed(1)} kW</span>
            <span className="text-emerald-400 font-bold">{energy.overallEfficiencyPercent.toFixed(1)}% η</span>
          </div>
        </div>

        {/* Bus Voltage */}
        <div className="bg-[#10151d] border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>DC BUS VOLTAGE</span>
            <Gauge className="w-3.5 h-3.5 text-white" />
          </div>
          <div className="my-1">
            <span className="text-2xl font-bold font-mono text-white">
              {vehicle.battery.terminalVoltageV.toFixed(1)}
            </span>
            <span className="text-xs text-slate-500 font-mono ml-1">V</span>
          </div>
          <div className="text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>OCV: {vehicle.battery.openCircuitVoltageV.toFixed(1)}V</span>
            <span>ΔV: {(vehicle.battery.terminalVoltageV - vehicle.battery.openCircuitVoltageV).toFixed(1)}V</span>
          </div>
        </div>

        {/* DC Current */}
        <div className="bg-[#10151d] border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>DC CURRENT</span>
            <Activity className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="my-1">
            <span className="text-2xl font-bold font-mono text-amber-400">
              {vehicle.battery.currentA.toFixed(1)}
            </span>
            <span className="text-xs text-slate-500 font-mono ml-1">A</span>
          </div>
          <div className="text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>Max: {vehicle.maxChargeCurrentA}A</span>
            <span>{charger.cables[0].cableCsaMm2}mm² Cu</span>
          </div>
        </div>

        {/* Battery SoC */}
        <div className="bg-[#10151d] border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>BATTERY SOC</span>
            <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="my-1 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono text-emerald-400">
              {(vehicle.battery.socCurrent * 100).toFixed(1)}%
            </span>
            <span className="text-xs text-slate-500 font-mono">→ {(vehicle.battery.socTarget * 100).toFixed(0)}%</span>
          </div>
          {/* SoC Progress Bar */}
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div 
              className="bg-emerald-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${Math.min(100, vehicle.battery.socCurrent * 100)}%` }}
            />
          </div>
        </div>

        {/* Thermal System */}
        <div className="bg-[#10151d] border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>PEAK TEMPERATURE</span>
            <Flame className="w-3.5 h-3.5 text-red-400" />
          </div>
          <div className="my-1">
            <span className={`text-2xl font-bold font-mono ${sensors['SEN_TEMP_MOD_MAX']?.raw > 75 ? 'text-red-400' : sensors['SEN_TEMP_MOD_MAX']?.raw > 60 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {(sensors['SEN_TEMP_MOD_MAX']?.raw || 25).toFixed(1)}
            </span>
            <span className="text-xs text-slate-500 font-mono ml-1">°C</span>
          </div>
          <div className="text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>Coolant: {charger.cooling.coolantInletTempC.toFixed(1)}°C</span>
            <span>Pump: {charger.cooling.pumpSpeedPercent}%</span>
          </div>
        </div>

        {/* Grid Real Power */}
        <div className="bg-[#10151d] border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>GRID DEMAND</span>
            <Cpu className="w-3.5 h-3.5 text-indigo-400" />
          </div>
          <div className="my-1">
            <span className="text-2xl font-bold font-mono text-indigo-400">
              {grid.liveRealPowerKw.toFixed(1)}
            </span>
            <span className="text-xs text-slate-500 font-mono ml-1">kW</span>
          </div>
          <div className="text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>PF: {grid.powerFactorTarget}</span>
            <span>THD: {grid.thdCurrentMaxPercent}%</span>
          </div>
        </div>

        {/* Energy Residual / Conservation Meter */}
        <div className="bg-[#10151d] border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>CONSERVATION CHECK</span>
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="my-1">
            <span className="text-2xl font-bold font-mono text-emerald-400">
              {energy.energyResidualKwh.toFixed(4)}
            </span>
            <span className="text-xs text-slate-500 font-mono ml-1">kWh Δ</span>
          </div>
          <div className="text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>Delivered: {energy.energyDeliveredKwh.toFixed(2)} kWh</span>
            <span className="text-emerald-400 font-semibold">100% PASS</span>
          </div>
        </div>
      </div>

      {/* 2. DYNAMIC CHART & LOSS WATERFALL STUDIO */}
      <div className="bg-[#10151d] border border-slate-800 rounded-xl p-4 flex flex-col gap-4 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2 font-mono text-xs text-slate-300">
            <TrendingUp className="w-4 h-4 text-cyan-400" />
            <span className="font-semibold text-white">LIVE ENGINEERING WAVEFORM ANALYSIS</span>
            <span className="text-slate-600">|</span>
            <span className="text-slate-400">Sample Rate: 1.0 Hz Deterministic Clock</span>
          </div>

          <div className="flex items-center gap-1.5 font-mono text-xs">
            <button
              onClick={() => setActiveChartTab('POWER_TIME')}
              className={`px-3 py-1 rounded transition-all ${activeChartTab === 'POWER_TIME' ? 'bg-cyan-950 border border-cyan-500/50 text-cyan-300 font-bold' : 'text-slate-400 hover:text-white'}`}
            >
              Power vs Time
            </button>
            <button
              onClick={() => setActiveChartTab('TEMP_TIME')}
              className={`px-3 py-1 rounded transition-all ${activeChartTab === 'TEMP_TIME' ? 'bg-red-950 border border-red-500/50 text-red-300 font-bold' : 'text-slate-400 hover:text-white'}`}
            >
              Temperature vs Time
            </button>
            <button
              onClick={() => setActiveChartTab('SOC_TIME')}
              className={`px-3 py-1 rounded transition-all ${activeChartTab === 'SOC_TIME' ? 'bg-emerald-950 border border-emerald-500/50 text-emerald-300 font-bold' : 'text-slate-400 hover:text-white'}`}
            >
              SoC & Terminal Voltage
            </button>
            <button
              onClick={() => setActiveChartTab('LOSS_WATERFALL')}
              className={`px-3 py-1 rounded transition-all ${activeChartTab === 'LOSS_WATERFALL' ? 'bg-amber-950 border border-amber-500/50 text-amber-300 font-bold' : 'text-slate-400 hover:text-white'}`}
            >
              Power Loss Breakdown
            </button>
          </div>
        </div>

        {/* Interactive SVG Chart Canvas */}
        <div className="w-full h-64 relative bg-[#090d14] rounded-lg border border-slate-800/80 p-3 flex flex-col justify-between">
          {activeChartTab === 'POWER_TIME' && (
            <svg className="w-full h-full" viewBox="0 0 600 200" preserveAspectRatio="none">
              {/* Grid Lines */}
              <line x1="0" y1="50" x2="600" y2="50" stroke="#1e293b" strokeDasharray="3,3" />
              <line x1="0" y1="100" x2="600" y2="100" stroke="#1e293b" strokeDasharray="3,3" />
              <line x1="0" y1="150" x2="600" y2="150" stroke="#1e293b" strokeDasharray="3,3" />

              {/* Power Curve Line */}
              {recentHistory.length > 1 && (
                <polyline
                  fill="none"
                  stroke="#00e5ff"
                  strokeWidth="2.5"
                  points={recentHistory
                    .map((h, i) => {
                      const x = (i / (recentHistory.length - 1)) * 600;
                      const power = (h.vehicle.battery.terminalVoltageV * h.vehicle.battery.currentA) / 1000;
                      const y = 190 - (power / 400) * 170;
                      return `${x},${Math.max(10, Math.min(190, y))}`;
                    })
                    .join(' ')}
                />
              )}

              {/* Grid Import Curve Line */}
              {recentHistory.length > 1 && (
                <polyline
                  fill="none"
                  stroke="#818cf8"
                  strokeWidth="1.5"
                  strokeDasharray="4,4"
                  points={recentHistory
                    .map((h, i) => {
                      const x = (i / (recentHistory.length - 1)) * 600;
                      const gridKw = h.grid.liveRealPowerKw || 0;
                      const y = 190 - (gridKw / 400) * 170;
                      return `${x},${Math.max(10, Math.min(190, y))}`;
                    })
                    .join(' ')}
                />
              )}
            </svg>
          )}

          {activeChartTab === 'TEMP_TIME' && (
            <svg className="w-full h-full" viewBox="0 0 600 200" preserveAspectRatio="none">
              <line x1="0" y1="40" x2="600" y2="40" stroke="#ef4444" strokeDasharray="4,4" opacity="0.6" /> {/* 80°C limit */}
              <text x="500" y="35" fill="#ef4444" fontSize="10" fontFamily="monospace">80°C Derate Threshold</text>
              
              {recentHistory.length > 1 && (
                <>
                  {/* Module Peak Temp */}
                  <polyline
                    fill="none"
                    stroke="#ef4444"
                    strokeWidth="2.5"
                    points={recentHistory
                      .map((h, i) => {
                        const x = (i / (recentHistory.length - 1)) * 600;
                        const temp = h.sensors['SEN_TEMP_MOD_MAX']?.raw || 25;
                        const y = 190 - (temp / maxTempY) * 170;
                        return `${x},${Math.max(10, Math.min(190, y))}`;
                      })
                      .join(' ')}
                  />
                  {/* Cable Core Temp */}
                  <polyline
                    fill="none"
                    stroke="#f97316"
                    strokeWidth="2.0"
                    points={recentHistory
                      .map((h, i) => {
                        const x = (i / (recentHistory.length - 1)) * 600;
                        const temp = h.charger.cables[0]?.cableTempC || 25;
                        const y = 190 - (temp / maxTempY) * 170;
                        return `${x},${Math.max(10, Math.min(190, y))}`;
                      })
                      .join(' ')}
                  />
                  {/* Coolant Inlet */}
                  <polyline
                    fill="none"
                    stroke="#0284c7"
                    strokeWidth="1.8"
                    points={recentHistory
                      .map((h, i) => {
                        const x = (i / (recentHistory.length - 1)) * 600;
                        const temp = h.charger.cooling.coolantInletTempC || 22;
                        const y = 190 - (temp / maxTempY) * 170;
                        return `${x},${Math.max(10, Math.min(190, y))}`;
                      })
                      .join(' ')}
                  />
                </>
              )}
            </svg>
          )}

          {activeChartTab === 'SOC_TIME' && (
            <svg className="w-full h-full" viewBox="0 0 600 200" preserveAspectRatio="none">
              {recentHistory.length > 1 && (
                <polyline
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="2.5"
                  points={recentHistory
                    .map((h, i) => {
                      const x = (i / (recentHistory.length - 1)) * 600;
                      const soc = h.vehicle.battery.socCurrent * 100;
                      const y = 190 - (soc / 100) * 170;
                      return `${x},${Math.max(10, Math.min(190, y))}`;
                    })
                    .join(' ')}
                />
              )}
            </svg>
          )}

          {activeChartTab === 'LOSS_WATERFALL' && (
            <div className="w-full h-full flex items-center justify-around px-6">
              <div className="flex flex-col items-center gap-1.5">
                <div className="text-slate-400 font-mono text-[11px]">GRID INPUT</div>
                <div className="w-14 bg-indigo-600 rounded-t h-40 flex items-center justify-center font-mono text-white text-xs font-bold">
                  {grid.liveRealPowerKw.toFixed(1)} kW
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-600" />
              <div className="flex flex-col items-center gap-1.5">
                <div className="text-slate-400 font-mono text-[11px]">SiC RECTIFIER LOSS</div>
                <div className="w-14 bg-red-600/80 rounded-t h-16 flex items-center justify-center font-mono text-white text-xs font-bold">
                  {(charger.moduleArray.reduce((acc, m) => acc + m.lossKw, 0)).toFixed(1)} kW
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-600" />
              <div className="flex flex-col items-center gap-1.5">
                <div className="text-slate-400 font-mono text-[11px]">CABLE I²R LOSS</div>
                <div className="w-14 bg-amber-600/80 rounded-t h-8 flex items-center justify-center font-mono text-white text-xs font-bold">
                  {(charger.cables[0].cableLossKw + charger.cables[0].connectorLossKw).toFixed(2)} kW
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-600" />
              <div className="flex flex-col items-center gap-1.5">
                <div className="text-slate-400 font-mono text-[11px]">BATTERY DELIVERED</div>
                <div className="w-14 bg-emerald-600 rounded-t h-36 flex items-center justify-center font-mono text-white text-xs font-bold">
                  {((vehicle.battery.terminalVoltageV * vehicle.battery.currentA) / 1000).toFixed(1)} kW
                </div>
              </div>
            </div>
          )}

          {/* Chart Legend Footer */}
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 border-t border-slate-800/80 pt-1.5">
            <div className="flex items-center gap-4">
              {activeChartTab === 'POWER_TIME' && (
                <>
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span> DC Charging Power</span>
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-indigo-400"></span> Grid Real Power</span>
                </>
              )}
              {activeChartTab === 'TEMP_TIME' && (
                <>
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-red-400"></span> Module Peak Temp</span>
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span> Cable Core Temp</span>
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-sky-500"></span> Coolant Inlet</span>
                </>
              )}
            </div>
            <span>T_sim = {currentFrame.timeString}</span>
          </div>
        </div>
      </div>

      {/* 3. MODULAR POWER ELECTRONICS ARRAY & HARDWARE FAULT INJECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Modular Power Block Array Cards */}
        <div className="lg:col-span-2 bg-[#10151d] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 font-mono text-xs">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <span className="font-semibold text-white">SiC MODULAR POWER CONVERTER ARRAY</span>
              <span className="text-slate-500">({charger.moduleArray.length} Blocks × 50 kW)</span>
            </div>
            <span className="text-emerald-400 font-semibold">
              {charger.moduleArray.filter(m => m.status === 'ONLINE').length} / {charger.moduleArray.length} ONLINE
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
            {charger.moduleArray.map((mod, idx) => (
              <div 
                key={mod.id}
                className={`p-2.5 rounded-lg border flex flex-col justify-between font-mono text-xs ${
                  mod.status === 'ONLINE' 
                    ? 'bg-slate-900/90 border-slate-700/80' 
                    : 'bg-red-950/40 border-red-800/80 text-red-300'
                }`}
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-slate-300">BLOCK {idx + 1}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[10px] ${mod.status === 'ONLINE' ? 'bg-emerald-950 text-emerald-300' : 'bg-red-950 text-red-300'}`}>
                    {mod.status}
                  </span>
                </div>
                <div className="my-1.5 flex items-baseline justify-between">
                  <span className="text-cyan-400 font-bold text-sm">{mod.outputPowerKw.toFixed(1)} kW</span>
                  <span className="text-slate-400 text-[11px]">{mod.temperatureC.toFixed(1)} °C</span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 border-t border-slate-800/60 pt-1">
                  <span>η: {(mod.efficiency * 100).toFixed(1)}%</span>
                  <span>Loss: {(mod.lossKw * 1000).toFixed(0)} W</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Fault Injection Bench & Safety Interlocks */}
        <div className="bg-[#10151d] border border-slate-800 rounded-xl p-4 flex flex-col justify-between gap-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 font-mono text-xs">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span className="font-semibold text-white">FAULT INJECTION & STRESS</span>
            </div>
            <button
              onClick={onClearFaults}
              className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 transition-colors"
            >
              <RotateCcw className="w-3 h-3" /> Clear All
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 font-mono text-xs">
            <button
              onClick={() => onInjectFault('INSULATION_RESISTANCE_FAULT', 'IMD reported insulation resistance < 50 kΩ (Standard minimum 100 kΩ)', 'IMD_SENSOR')}
              className="p-2 rounded bg-slate-900 border border-slate-700/80 hover:border-amber-500 text-left text-slate-300 hover:text-white transition-all"
            >
              ⚡ IMD Ground Fault
            </button>
            <button
              onClick={() => onInjectFault('COOLANT_PUMP_STALL', 'Liquid cooling pump stalled: Flow rate dropped to 0 LPM', 'COOLING_PUMP')}
              className="p-2 rounded bg-slate-900 border border-slate-700/80 hover:border-amber-500 text-left text-slate-300 hover:text-white transition-all"
            >
              💧 Coolant Pump Stall
            </button>
            <button
              onClick={() => onInjectFault('OVERTEMPERATURE_MODULE', 'Power module semiconductor junction reached 96.5°C trip threshold', 'POWER_MODULE_1')}
              className="p-2 rounded bg-slate-900 border border-slate-700/80 hover:border-amber-500 text-left text-slate-300 hover:text-white transition-all"
            >
              🔥 Overtemperature
            </button>
            <button
              onClick={() => onInjectFault('COMM_TIMEOUT_VEHICLE', 'ISO 15118 PLC packet timeout: EVSE received no CurrentDemandReq for 250ms', 'PLC_TRANSCEIVER')}
              className="p-2 rounded bg-slate-900 border border-slate-700/80 hover:border-amber-500 text-left text-slate-300 hover:text-white transition-all"
            >
              📡 PLC Comm Drop
            </button>
          </div>

          {/* Master Emergency Stop Switch */}
          <button
            onClick={onEmergencyStop}
            className="w-full py-2.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-red-950/50 transition-all active:scale-[0.98]"
          >
            <ShieldAlert className="w-4 h-4" />
            EMERGENCY STOP (SAFE DE-ENERGIZE)
          </button>
        </div>
      </div>
    </div>
  );
};
