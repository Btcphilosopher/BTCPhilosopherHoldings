'use client';

import React, { useState } from 'react';
import { ProtocolMessage, SessionState } from '@/lib/engine/types';
import { Radio, ShieldCheck, Terminal, ArrowRight, CheckCircle2, ChevronRight, FileCode } from 'lucide-react';

interface ProtocolTracerProps {
  sessionState: SessionState;
  protocolHistory: ProtocolMessage[];
  voltageV: number;
  currentA: number;
}

export const ProtocolTracer: React.FC<ProtocolTracerProps> = ({
  sessionState,
  protocolHistory,
  voltageV,
  currentA,
}) => {
  const [selectedMessage, setSelectedMessage] = useState<ProtocolMessage | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'ISO15118' | 'IEC61851' | 'OCPP' | 'CAN_BUS'>('ISO15118');

  // IEC 61851-1 Control Pilot State Sequence
  const cpStates = [
    { state: 'A', desc: 'Standby / Unconnected', volt: '+12V DC', pwm: 'Off' },
    { state: 'B', desc: 'Vehicle Connected', volt: '+9V DC / PWM', pwm: '1 kHz 5%' },
    { state: 'C', desc: 'Charging Ready (Vent Not Req)', volt: '+6V PWM', pwm: '1 kHz 5%' },
    { state: 'D', desc: 'Charging Ready (Ventilation Req)', volt: '+3V PWM', pwm: '1 kHz 5%' },
    { state: 'E', desc: 'No Power / Grid Disconnected', volt: '0V', pwm: 'Off' },
    { state: 'F', desc: 'EVSE Fault Condition', volt: '-12V DC', pwm: 'Off' },
  ];

  let currentCpState = 'A';
  if (sessionState === 'CONNECTED' || sessionState === 'AUTHENTICATING' || sessionState === 'NEGOTIATING' || sessionState === 'PREPARING') currentCpState = 'B';
  else if (sessionState === 'CHARGING' || sessionState === 'TAPERING') currentCpState = 'C';
  else if (sessionState === 'FAULT' || sessionState === 'EMERGENCY_STOP') currentCpState = 'F';

  // Sample EVSE internal CAN Bus Frames (J1939 format)
  const canFrames = [
    { id: '0x1806E5F4', pgn: '61444', name: 'EVSE_POWER_STATUS', data: `08 45 03 ${Math.floor(voltageV / 10).toString(16).padStart(2, '0')} ${Math.floor(currentA).toString(16).padStart(2, '0')} 00 24 9F`, period: '10 ms' },
    { id: '0x181056F4', pgn: '61445', name: 'BMS_BATTERY_DEMAND', data: `02 A0 05 ${Math.floor(voltageV).toString(16).padStart(2, '0')} ${Math.floor(currentA).toString(16).padStart(2, '0')} 12 00 8C`, period: '20 ms' },
    { id: '0x18FF50E5', pgn: '65360', name: 'COOLING_LOOP_TELEMETRY', data: `18 22 28 35 40 00 00 1A`, period: '100 ms' },
    { id: '0x18FF80E5', pgn: '65408', name: 'IMD_ISOLATION_MONITOR', data: `FF 00 19 00 00 00 00 00`, period: '500 ms' },
  ];

  // OCPP 2.0.1 Messages
  const ocppMessages = [
    { action: 'BootNotification', direction: 'EVSE → CSMS', status: 'Accepted', payload: '{"chargingStation":{"model":"CF-350-HPC","vendorName":"ChargeForge"},"reason":"PowerUp"}' },
    { action: 'Authorize', direction: 'EVSE → CSMS', status: 'Accepted', payload: '{"idToken":{"idToken":"04A1B2C3D4E5","type":"eMAID"}}' },
    { action: 'TransactionEvent (Started)', direction: 'EVSE → CSMS', status: 'Accepted', payload: `{"eventType":"Started","meterValue":[{"sampledValue":[{"value":0.0,"measurand":"Energy.Active.Import.Register"}]}]}` },
    { action: 'TransactionEvent (Updated)', direction: 'EVSE → CSMS', status: 'Accepted', payload: `{"eventType":"Updated","meterValue":[{"sampledValue":[{"value":${voltageV.toFixed(1)},"measurand":"Voltage"},{"value":${currentA.toFixed(1)},"measurand":"Current.Import"}]}]}` },
  ];

  return (
    <div className="w-full bg-[#0a0e14] border border-slate-800 rounded-xl p-4 flex flex-col gap-4 font-mono">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-3">
          <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
          <div>
            <h3 className="text-sm font-bold text-white tracking-wide">VEHICLE-TO-GRID (V2G) PROTOCOL STACK & PACKET DISSECTOR</h3>
            <div className="text-[11px] text-slate-400">Standards: ISO 15118-20 • IEC 61851-1 • OCPP 2.0.1 • SAE J3400 / CCS2</div>
          </div>
        </div>

        {/* Sub-tab switcher */}
        <div className="bg-slate-900 border border-slate-800 rounded p-1 flex gap-1 text-xs">
          <button
            onClick={() => setActiveSubTab('ISO15118')}
            className={`px-2.5 py-1 rounded ${activeSubTab === 'ISO15118' ? 'bg-cyan-950 border border-cyan-500/60 text-cyan-300 font-bold' : 'text-slate-400'}`}
          >
            ISO 15118-20 PLC
          </button>
          <button
            onClick={() => setActiveSubTab('IEC61851')}
            className={`px-2.5 py-1 rounded ${activeSubTab === 'IEC61851' ? 'bg-cyan-950 border border-cyan-500/60 text-cyan-300 font-bold' : 'text-slate-400'}`}
          >
            IEC 61851-1 Control Pilot
          </button>
          <button
            onClick={() => setActiveSubTab('OCPP')}
            className={`px-2.5 py-1 rounded ${activeSubTab === 'OCPP' ? 'bg-cyan-950 border border-cyan-500/60 text-cyan-300 font-bold' : 'text-slate-400'}`}
          >
            OCPP 2.0.1 CSMS
          </button>
          <button
            onClick={() => setActiveSubTab('CAN_BUS')}
            className={`px-2.5 py-1 rounded ${activeSubTab === 'CAN_BUS' ? 'bg-cyan-950 border border-cyan-500/60 text-cyan-300 font-bold' : 'text-slate-400'}`}
          >
            EVSE CAN Bus (J1939)
          </button>
        </div>
      </div>

      {/* Tab Contents */}
      {activeSubTab === 'ISO15118' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Message List */}
          <div className="lg:col-span-1 bg-[#090d14] border border-slate-800 rounded-lg p-3 flex flex-col gap-2 max-h-96 overflow-y-auto">
            <div className="text-xs text-slate-400 font-semibold border-b border-slate-800 pb-1.5 flex justify-between">
              <span>LIVE V2G PACKET TRACE</span>
              <span>{protocolHistory.length} Frames</span>
            </div>
            {protocolHistory.length === 0 ? (
              <div className="text-slate-500 text-xs py-8 text-center">Start charging to capture ISO 15118 handshake frames...</div>
            ) : (
              protocolHistory.map((msg, idx) => (
                <div
                  key={msg.id}
                  onClick={() => setSelectedMessage(msg)}
                  className={`p-2 rounded border cursor-pointer text-xs transition-all flex flex-col gap-1 ${
                    selectedMessage?.id === msg.id
                      ? 'bg-cyan-950/60 border-cyan-500 text-white'
                      : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-cyan-400">{msg.messageName}</span>
                    <span className="text-[10px] text-slate-500">{new Date(msg.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 flex items-center justify-between">
                    <span>{msg.direction}</span>
                    <span className="text-emerald-400 font-semibold">VALID</span>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Packet Dissector & Hex Dump Viewer */}
          <div className="lg:col-span-2 bg-[#090d14] border border-slate-800 rounded-lg p-3 flex flex-col justify-between gap-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-xs">
              <span className="text-slate-300 font-bold flex items-center gap-1.5">
                <FileCode className="w-4 h-4 text-cyan-400" />
                EXI PACKET DISSECTOR & PAYLOAD INSPECTOR
              </span>
              <span className="text-slate-500">ISO 15118-20:2022 Schema</span>
            </div>

            <div className="bg-[#05070a] p-3 rounded border border-slate-800/80 text-xs font-mono text-emerald-400 overflow-x-auto min-h-[160px]">
              {selectedMessage ? (
                <pre>{JSON.stringify(selectedMessage.payload, null, 2)}</pre>
              ) : (
                <pre>{`// Select any packet on the left to inspect decoded EXI payload XML/JSON representation
{
  "Header": {
    "SessionID": "4F9E82A13B0C77",
    "Notification": null
  },
  "Body": {
    "CurrentDemandReq": {
      "DC_EVTargetVoltage": "${voltageV.toFixed(1)} V",
      "DC_EVTargetCurrent": "${currentA.toFixed(1)} A",
      "EVMaximumVoltageLimit": "920.0 V",
      "EVMaximumCurrentLimit": "500.0 A",
      "EVMaximumPowerLimit": "350.0 kW",
      "EVSOC": "45 %",
      "BulkChargingComplete": false,
      "ChargingComplete": false
    }
  }
}`}</pre>
              )}
            </div>

            {/* Hex Byte Dump */}
            <div className="bg-[#05070a] p-2.5 rounded border border-slate-800/80 text-[11px] font-mono text-slate-400">
              <div className="text-[10px] text-slate-500 uppercase mb-1">Raw EXI Byte Stream (HomePlug GreenPHY Carrier)</div>
              <div className="text-cyan-300 tracking-wider">
                80 9A 01 00 00 00 24 00 00 4F 9E 82 A1 3B 0C 77 02 04 03 10 1F 40 00 1E 84 80 00 00 00 00
              </div>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'IEC61851' && (
        <div className="flex flex-col gap-4">
          <div className="text-xs text-slate-400">
            IEC 61851-1 defines analog signaling via the Control Pilot (CP) line using PWM duty-cycle modulation and resistive pull-down voltage state transitions.
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
            {cpStates.map((st) => {
              const isActive = currentCpState === st.state;
              return (
                <div
                  key={st.state}
                  className={`p-3 rounded-lg border flex flex-col justify-between transition-all ${
                    isActive
                      ? 'bg-cyan-950/80 border-cyan-400 shadow-lg shadow-cyan-950/50 text-white'
                      : 'bg-[#090d14] border-slate-800 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-base">STATE {st.state}</span>
                    {isActive && <CheckCircle2 className="w-4 h-4 text-cyan-400" />}
                  </div>
                  <div className="my-2 text-[11px] text-slate-300 font-sans">{st.desc}</div>
                  <div className="border-t border-slate-800 pt-2 flex flex-col gap-0.5 text-[10px] text-slate-500">
                    <div>Voltage: <span className="text-white font-bold">{st.volt}</span></div>
                    <div>PWM: <span className="text-white font-bold">{st.pwm}</span></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {activeSubTab === 'OCPP' && (
        <div className="bg-[#090d14] border border-slate-800 rounded-lg p-3 flex flex-col gap-2">
          <div className="text-xs text-slate-400 font-semibold border-b border-slate-800 pb-2">
            OCPP 2.0.1 CENTRAL SYSTEM COMMUNICATION LOG (WebSocket / WSS JSON-RPC)
          </div>
          <div className="flex flex-col gap-2">
            {ocppMessages.map((m, idx) => (
              <div key={idx} className="p-2.5 rounded bg-slate-900/80 border border-slate-800 text-xs flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <span className="text-amber-400 font-bold">{m.action}</span>
                  <span className="text-emerald-400 font-semibold">{m.status}</span>
                </div>
                <div className="text-[11px] text-slate-500">{m.direction}</div>
                <pre className="text-[11px] text-slate-300 bg-[#05070a] p-2 rounded overflow-x-auto">{m.payload}</pre>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSubTab === 'CAN_BUS' && (
        <div className="bg-[#090d14] border border-slate-800 rounded-lg p-3 flex flex-col gap-2">
          <div className="text-xs text-slate-400 font-semibold border-b border-slate-800 pb-2">
            EVSE INTERNAL CAN 2.0B / SAE J1939 HIGH-SPEED BUS (500 kbps)
          </div>
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-slate-500 border-b border-slate-800 pb-1">
                <th className="py-1">CAN ID</th>
                <th>PGN</th>
                <th>FRAME NAME</th>
                <th>PAYLOAD (HEX)</th>
                <th>PERIOD</th>
              </tr>
            </thead>
            <tbody>
              {canFrames.map((f) => (
                <tr key={f.id} className="border-b border-slate-800/40 text-slate-300">
                  <td className="py-2 text-cyan-400 font-bold">{f.id}</td>
                  <td>{f.pgn}</td>
                  <td>{f.name}</td>
                  <td className="text-amber-300">{f.data}</td>
                  <td className="text-slate-500">{f.period}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
