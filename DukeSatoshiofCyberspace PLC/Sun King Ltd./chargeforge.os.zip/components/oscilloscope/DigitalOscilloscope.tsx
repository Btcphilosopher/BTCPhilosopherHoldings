'use client';

import React, { useState, useEffect } from 'react';
import { OscilloscopeEngine, OscilloscopeTracePoint } from '@/lib/engine/oscilloscope';
import { Activity, Sliders, Play, Square, Eye, EyeOff, Radio } from 'lucide-react';

interface DigitalOscilloscopeProps {
  dcVoltageV: number;
  dcCurrentA: number;
  cpState: 'A' | 'B' | 'C' | 'D' | 'E' | 'F';
  gridVoltageLL: number;
}

export const DigitalOscilloscope: React.FC<DigitalOscilloscopeProps> = ({
  dcVoltageV,
  dcCurrentA,
  cpState,
  gridVoltageLL,
}) => {
  const [timebaseMs, setTimebaseMs] = useState<number>(2.0); // 2 ms/div
  const [isLive, setIsLive] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'TIME_DOMAIN' | 'FFT_SPECTRUM'>('TIME_DOMAIN');

  // Channel enable toggles
  const [ch1Enabled, setCh1Enabled] = useState(true); // DC Bus Voltage
  const [ch2Enabled, setCh2Enabled] = useState(true); // DC Current
  const [ch3Enabled, setCh3Enabled] = useState(true); // Control Pilot
  const [ch4Enabled, setCh4Enabled] = useState(false); // AC Grid

  const [traces, setTraces] = useState<OscilloscopeTracePoint[]>([]);

  useEffect(() => {
    const updateTraces = () => {
      if (!isLive) return;
      const pts = OscilloscopeEngine.generateWaveformBuffer(
        dcVoltageV,
        dcCurrentA,
        cpState,
        gridVoltageLL,
        timebaseMs
      );
      setTraces(pts);
    };

    updateTraces();
    const interval = setInterval(updateTraces, 100); // 10 Hz refresh
    return () => clearInterval(interval);
  }, [isLive, dcVoltageV, dcCurrentA, cpState, gridVoltageLL, timebaseMs]);

  const ffts = OscilloscopeEngine.calculateFftSpectrum(gridVoltageLL);

  // Normalization for SVG drawing (600px width × 240px height)
  // Grid: 10 horizontal divisions, 8 vertical divisions
  const width = 600;
  const height = 240;

  return (
    <div className="w-full bg-[#0a0e14] border border-slate-800 rounded-xl p-4 flex flex-col gap-4 font-mono">
      {/* Top Scope Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-cyan-400 animate-pulse"></div>
          <div>
            <h3 className="text-sm font-bold text-white tracking-wide">DIGITAL STORAGE OSCILLOSCOPE (4-CH 100 MSa/s)</h3>
            <div className="text-[11px] text-slate-400">Timebase: {timebaseMs} ms/div • Trigger: AUTO (CH1 750V Rising)</div>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <button
            onClick={() => setIsLive(!isLive)}
            className={`px-3 py-1.5 rounded flex items-center gap-1.5 font-bold transition-all ${
              isLive ? 'bg-emerald-950 border border-emerald-500 text-emerald-300' : 'bg-amber-950 border border-amber-500 text-amber-300'
            }`}
          >
            {isLive ? <Play className="w-3.5 h-3.5" /> : <Square className="w-3.5 h-3.5" />}
            {isLive ? 'LIVE' : 'STOPPED'}
          </button>

          <div className="bg-slate-900 border border-slate-800 rounded p-1 flex gap-1">
            <button
              onClick={() => setActiveTab('TIME_DOMAIN')}
              className={`px-2.5 py-1 rounded ${activeTab === 'TIME_DOMAIN' ? 'bg-slate-700 text-white font-bold' : 'text-slate-400'}`}
            >
              Time Domain
            </button>
            <button
              onClick={() => setActiveTab('FFT_SPECTRUM')}
              className={`px-2.5 py-1 rounded ${activeTab === 'FFT_SPECTRUM' ? 'bg-slate-700 text-white font-bold' : 'text-slate-400'}`}
            >
              FFT Harmonics
            </button>
          </div>
        </div>
      </div>

      {/* Screen & Scope Graticule */}
      <div className="relative w-full h-64 bg-[#05070a] rounded-lg border border-slate-700/80 p-1 flex items-center justify-center overflow-hidden">
        {activeTab === 'TIME_DOMAIN' ? (
          <svg className="w-full h-full" viewBox="0 0 600 240">
            {/* Graticule 10x8 Grid */}
            {Array.from({ length: 11 }).map((_, i) => (
              <line key={`v_${i}`} x1={(i * 600) / 10} y1="0" x2={(i * 600) / 10} y2="240" stroke="#172233" strokeWidth="0.8" strokeDasharray="2,2" />
            ))}
            {Array.from({ length: 9 }).map((_, i) => (
              <line key={`h_${i}`} x1="0" y1={(i * 240) / 8} x2="600" y2={(i * 240) / 8} stroke="#172233" strokeWidth="0.8" strokeDasharray="2,2" />
            ))}
            {/* Center Axes */}
            <line x1="300" y1="0" x2="300" y2="240" stroke="#253549" strokeWidth="1.2" />
            <line x1="0" y1="120" x2="600" y2="120" stroke="#253549" strokeWidth="1.2" />

            {/* CH1: DC Voltage (Cyan) */}
            {ch1Enabled && traces.length > 1 && (
              <polyline
                fill="none"
                stroke="#00e5ff"
                strokeWidth="2.0"
                points={traces
                  .map((t, idx) => {
                    const x = (idx / (traces.length - 1)) * 600;
                    // Scale: 1000V full scale -> 240px
                    const y = 220 - (t.ch1DcVoltageV / 1000) * 190;
                    return `${x},${y}`;
                  })
                  .join(' ')}
              />
            )}

            {/* CH2: DC Current (Yellow) */}
            {ch2Enabled && traces.length > 1 && (
              <polyline
                fill="none"
                stroke="#eab308"
                strokeWidth="2.0"
                points={traces
                  .map((t, idx) => {
                    const x = (idx / (traces.length - 1)) * 600;
                    // Scale: 500A full scale
                    const y = 220 - (t.ch2DcCurrentA / 500) * 190;
                    return `${x},${y}`;
                  })
                  .join(' ')}
              />
            )}

            {/* CH3: Control Pilot PWM (Purple) */}
            {ch3Enabled && traces.length > 1 && (
              <polyline
                fill="none"
                stroke="#c084fc"
                strokeWidth="2.0"
                points={traces
                  .map((t, idx) => {
                    const x = (idx / (traces.length - 1)) * 600;
                    // CP: -12V to +12V -> map to lower 60px
                    const y = 200 - ((t.ch3ControlPilotV + 12) / 24) * 50;
                    return `${x},${y}`;
                  })
                  .join(' ')}
              />
            )}

            {/* CH4: AC Grid Phase A (Green) */}
            {ch4Enabled && traces.length > 1 && (
              <polyline
                fill="none"
                stroke="#22c55e"
                strokeWidth="1.8"
                points={traces
                  .map((t, idx) => {
                    const x = (idx / (traces.length - 1)) * 600;
                    // AC Phase A: -350V to +350V -> centered at y=120
                    const y = 120 - (t.ch4GridVoltageV / 400) * 70;
                    return `${x},${y}`;
                  })
                  .join(' ')}
              />
            )}
          </svg>
        ) : (
          <div className="w-full h-full flex items-end justify-around px-8 pb-4">
            {ffts.map((f) => (
              <div key={f.order} className="flex flex-col items-center gap-1">
                <div
                  className="w-10 bg-cyan-500/80 rounded-t border border-cyan-400"
                  style={{ height: `${Math.max(4, (f.magnitudePercent / 100) * 180)}px` }}
                />
                <div className="text-[10px] text-slate-400 font-mono">{f.label}</div>
                <div className="text-[10px] text-cyan-300 font-bold font-mono">{f.magnitudePercent}%</div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Channel Strip Controls & Cursors */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
        {/* CH1 */}
        <div className={`p-2.5 rounded-lg border flex flex-col justify-between ${ch1Enabled ? 'bg-cyan-950/40 border-cyan-700/60' : 'bg-slate-900 border-slate-800 opacity-60'}`}>
          <div className="flex items-center justify-between">
            <span className="text-cyan-400 font-bold">CH1: DC Bus Voltage</span>
            <button onClick={() => setCh1Enabled(!ch1Enabled)} className="text-slate-400 hover:text-white">
              {ch1Enabled ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            </button>
          </div>
          <div className="my-1 text-base font-bold text-white">{dcVoltageV.toFixed(1)} V</div>
          <div className="text-[10px] text-slate-400 flex justify-between">
            <span>Ripple: 1.8 Vpp</span>
            <span>200V / div</span>
          </div>
        </div>

        {/* CH2 */}
        <div className={`p-2.5 rounded-lg border flex flex-col justify-between ${ch2Enabled ? 'bg-amber-950/40 border-amber-700/60' : 'bg-slate-900 border-slate-800 opacity-60'}`}>
          <div className="flex items-center justify-between">
            <span className="text-yellow-400 font-bold">CH2: DC Current</span>
            <button onClick={() => setCh2Enabled(!ch2Enabled)} className="text-slate-400 hover:text-white">
              {ch2Enabled ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            </button>
          </div>
          <div className="my-1 text-base font-bold text-white">{dcCurrentA.toFixed(1)} A</div>
          <div className="text-[10px] text-slate-400 flex justify-between">
            <span>Ripple: 2.2 App</span>
            <span>100A / div</span>
          </div>
        </div>

        {/* CH3 */}
        <div className={`p-2.5 rounded-lg border flex flex-col justify-between ${ch3Enabled ? 'bg-purple-950/40 border-purple-700/60' : 'bg-slate-900 border-slate-800 opacity-60'}`}>
          <div className="flex items-center justify-between">
            <span className="text-purple-400 font-bold">CH3: Control Pilot (CP)</span>
            <button onClick={() => setCh3Enabled(!ch3Enabled)} className="text-slate-400 hover:text-white">
              {ch3Enabled ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            </button>
          </div>
          <div className="my-1 text-base font-bold text-white">State {cpState} (PWM 1 kHz)</div>
          <div className="text-[10px] text-slate-400 flex justify-between">
            <span>Duty: 5.0%</span>
            <span>5V / div</span>
          </div>
        </div>

        {/* CH4 */}
        <div className={`p-2.5 rounded-lg border flex flex-col justify-between ${ch4Enabled ? 'bg-emerald-950/40 border-emerald-700/60' : 'bg-slate-900 border-slate-800 opacity-60'}`}>
          <div className="flex items-center justify-between">
            <span className="text-emerald-400 font-bold">CH4: AC Grid Phase A</span>
            <button onClick={() => setCh4Enabled(!ch4Enabled)} className="text-slate-400 hover:text-white">
              {ch4Enabled ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            </button>
          </div>
          <div className="my-1 text-base font-bold text-white">{(gridVoltageLL / Math.sqrt(3)).toFixed(1)} Vrms</div>
          <div className="text-[10px] text-slate-400 flex justify-between">
            <span>THD: 2.8%</span>
            <span>100V / div</span>
          </div>
        </div>
      </div>
    </div>
  );
};
