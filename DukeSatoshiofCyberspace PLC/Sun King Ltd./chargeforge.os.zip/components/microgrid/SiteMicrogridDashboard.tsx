'use client';

import React, { useState } from 'react';
import { SiteMicrogridSpec, SharingPolicy } from '@/lib/engine/types';
import { MicrogridEngine } from '@/lib/engine/microgrid';
import { PowerSharingEngine, VehicleAllocationRequest } from '@/lib/engine/sharing';
import { Sun, Battery, Building2, Zap, ArrowRight, DollarSign, ShieldCheck, Sliders, Cpu } from 'lucide-react';

interface SiteMicrogridDashboardProps {
  currentSiteSpec: SiteMicrogridSpec;
}

export const SiteMicrogridDashboard: React.FC<SiteMicrogridDashboardProps> = ({
  currentSiteSpec,
}) => {
  const [hourOfDay, setHourOfDay] = useState<number>(14.5); // 2:30 PM
  const [sharingPolicy, setSharingPolicy] = useState<SharingPolicy>('SOC_AWARE_OPTIMAL');
  
  // 4 Connected EVs on the charging plaza
  const [vehicles, setVehicles] = useState<VehicleAllocationRequest[]>([
    { id: 'EV_01', name: 'Stall 1: 800V GT', requestedKw: 270, maxAcceptanceKw: 270, currentSoc: 0.22, priorityScore: 8, arrivalTimeMinutes: 10, allocatedKw: 0 },
    { id: 'EV_02', name: 'Stall 2: 400V Sedan', requestedKw: 250, maxAcceptanceKw: 250, currentSoc: 0.15, priorityScore: 6, arrivalTimeMinutes: 15, allocatedKw: 0 },
    { id: 'EV_03', name: 'Stall 3: 800V Crossover', requestedKw: 235, maxAcceptanceKw: 235, currentSoc: 0.65, priorityScore: 5, arrivalTimeMinutes: 20, allocatedKw: 0 },
    { id: 'EV_04', name: 'Stall 4: Commercial Hauler', requestedKw: 450, maxAcceptanceKw: 450, currentSoc: 0.35, priorityScore: 9, arrivalTimeMinutes: 5, allocatedKw: 0 },
  ]);

  const totalEvDemandKw = vehicles.reduce((acc, v) => acc + v.requestedKw, 0); // 1205 kW unconstrained

  // Compute microgrid dispatch (Solar, BESS, Grid)
  const dispatch = MicrogridEngine.calculateSiteDispatch(currentSiteSpec, totalEvDemandKw, hourOfDay);

  // Available EV capacity at plaza (Transformer limit + Solar + BESS discharge - building load)
  const totalAvailableEvPowerKw = (currentSiteSpec.transformerCapacityKva * 0.98) + dispatch.solarGenerationKw + dispatch.bessDischargeKw - currentSiteSpec.buildingBaseLoadKw;

  // Allocate power across vehicles based on policy
  const allocatedVehicles = PowerSharingEngine.allocatePower(
    Math.max(100, totalAvailableEvPowerKw),
    vehicles,
    sharingPolicy
  );

  const totalAllocatedKw = allocatedVehicles.reduce((acc, v) => acc + v.allocatedKw, 0);

  return (
    <div className="w-full bg-[#0a0e14] border border-slate-800 rounded-xl p-4 flex flex-col gap-5 font-mono">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-3">
          <Sun className="w-4 h-4 text-amber-400" />
          <div>
            <h3 className="text-sm font-bold text-white tracking-wide">SITE MICROGRID, SOLAR PV & BESS DISPATCH</h3>
            <div className="text-[11px] text-slate-400">
              Site: {currentSiteSpec.siteName} • Transformer: {currentSiteSpec.transformerCapacityKva} kVA
            </div>
          </div>
        </div>

        {/* Hour of Day Slider */}
        <div className="flex items-center gap-3 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 text-xs">
          <span className="text-slate-400">Time of Day:</span>
          <span className="text-cyan-400 font-bold w-12">{Math.floor(hourOfDay)}:{(Math.floor((hourOfDay % 1) * 60)).toString().padStart(2, '0')}</span>
          <input
            type="range"
            min="0"
            max="24"
            step="0.5"
            value={hourOfDay}
            onChange={(e) => setHourOfDay(parseFloat(e.target.value))}
            className="w-32 accent-cyan-400"
          />
        </div>
      </div>

      {/* Microgrid Energy Flow Sankey / Block Flow */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
        {/* Solar PV */}
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span>SOLAR PV ARRAY</span>
            <Sun className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="my-1 text-xl font-bold text-amber-400">{dispatch.solarGenerationKw.toFixed(1)} kW</div>
          <div className="text-[11px] text-slate-400">Peak Rating: {currentSiteSpec.solarPvPeakKw} kWp</div>
        </div>

        {/* BESS Battery */}
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span>BESS STORAGE (500 kWh)</span>
            <Battery className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="my-1 text-xl font-bold text-emerald-400">
            {dispatch.bessDischargeKw > 0 ? `-${dispatch.bessDischargeKw.toFixed(1)} kW (Discharge)` : dispatch.bessChargeKw > 0 ? `+${dispatch.bessChargeKw.toFixed(1)} kW (Charge)` : '0.0 kW (Idle)'}
          </div>
          <div className="text-[11px] text-slate-400">State of Charge: {((currentSiteSpec.bessCurrentKwh / currentSiteSpec.bessCapacityKwh) * 100).toFixed(0)}%</div>
        </div>

        {/* Utility Grid Import */}
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span>UTILITY GRID IMPORT</span>
            <Building2 className="w-3.5 h-3.5 text-indigo-400" />
          </div>
          <div className="my-1 text-xl font-bold text-indigo-400">{dispatch.gridImportKw.toFixed(1)} kW</div>
          <div className="text-[11px] text-slate-400 flex justify-between">
            <span>Transformer Util:</span>
            <span className={dispatch.transformerUtilizationPercent > 90 ? 'text-amber-400 font-bold' : 'text-emerald-400'}>
              {dispatch.transformerUtilizationPercent.toFixed(1)}%
            </span>
          </div>
        </div>

        {/* Cost Rate */}
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span>ENERGY COST RATE</span>
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="my-1 text-xl font-bold text-emerald-400">${dispatch.costRateUsdPerHour.toFixed(2)} / hr</div>
          <div className="text-[11px] text-slate-400">Tariff: ${currentSiteSpec.tariffPerKwhUsd}/kWh</div>
        </div>
      </div>

      {/* Dynamic Multi-Vehicle Power Sharing Policy Engine */}
      <div className="bg-[#090d14] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2 text-xs">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-white">DYNAMIC MULTI-VEHICLE POWER SHARING ARBITRATOR</span>
          </div>

          <div className="flex items-center gap-1">
            <span className="text-slate-400 text-[11px] mr-1">Policy:</span>
            {(['SOC_AWARE_OPTIMAL', 'EQUAL_SHARE', 'FIRST_COME_FIRST_SERVE', 'PRIORITY_WEIGHTED'] as SharingPolicy[]).map((pol) => (
              <button
                key={pol}
                onClick={() => setSharingPolicy(pol)}
                className={`px-2 py-1 rounded text-[11px] ${
                  sharingPolicy === pol ? 'bg-cyan-950 border border-cyan-500/60 text-cyan-300 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                {pol.replace(/_/g, ' ')}
              </button>
            ))}
          </div>
        </div>

        {/* Power Allocation Table */}
        <table className="w-full text-left text-xs font-mono">
          <thead>
            <tr className="text-slate-500 border-b border-slate-800 pb-1">
              <th className="py-1">VEHICLE / STALL</th>
              <th>CURRENT SOC</th>
              <th>REQUESTED</th>
              <th>MAX ACCEPTANCE</th>
              <th>ALLOCATED POWER</th>
              <th>DELIVERY RATIO</th>
            </tr>
          </thead>
          <tbody>
            {allocatedVehicles.map((v) => {
              const ratio = (v.allocatedKw / v.requestedKw) * 100;
              return (
                <tr key={v.id} className="border-b border-slate-800/50 text-slate-300">
                  <td className="py-2.5 font-bold text-white">{v.name}</td>
                  <td>
                    <span className="text-emerald-400 font-semibold">{(v.currentSoc * 100).toFixed(0)}%</span>
                  </td>
                  <td className="text-slate-400">{v.requestedKw} kW</td>
                  <td className="text-slate-400">{v.maxAcceptanceKw} kW</td>
                  <td className="text-cyan-400 font-bold text-sm">{v.allocatedKw.toFixed(1)} kW</td>
                  <td>
                    <div className="flex items-center gap-2">
                      <div className="w-20 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-cyan-400 h-full rounded-full" style={{ width: `${ratio}%` }} />
                      </div>
                      <span className="text-[10px] text-slate-400">{ratio.toFixed(0)}%</span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {/* Summary Footer */}
        <div className="flex items-center justify-between text-xs text-slate-400 border-t border-slate-800 pt-2">
          <span>Total Vehicle Demand: <strong className="text-white">{totalEvDemandKw} kW</strong></span>
          <span>Plaza Available Power: <strong className="text-emerald-400">{totalAvailableEvPowerKw.toFixed(1)} kW</strong></span>
          <span>Total Dispatched: <strong className="text-cyan-400">{totalAllocatedKw.toFixed(1)} kW</strong></span>
        </div>
      </div>
    </div>
  );
};
