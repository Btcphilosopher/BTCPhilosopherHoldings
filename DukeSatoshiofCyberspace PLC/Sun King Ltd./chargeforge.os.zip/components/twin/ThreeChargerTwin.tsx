'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { ChargerHardwareSpec, VehicleModelSpec, SafetyState } from '@/lib/engine/types';
import { Maximize2, RotateCcw, Eye, Layers, Zap, Flame, Box, ShieldAlert } from 'lucide-react';

export type TwinViewMode = 'NORMAL' | 'CUTAWAY' | 'EXPLODED' | 'THERMAL' | 'ELECTRICAL' | 'XRAY';

interface ThreeChargerTwinProps {
  charger: ChargerHardwareSpec;
  vehicle: VehicleModelSpec;
  powerKw: number;
  currentA: number;
  voltageV: number;
  maxTempC: number;
  safetyState: SafetyState;
  onSelectComponent?: (compName: string, specs: Record<string, unknown>) => void;
}

export const ThreeChargerTwin: React.FC<ThreeChargerTwinProps> = ({
  charger,
  vehicle,
  powerKw,
  currentA,
  voltageV,
  maxTempC,
  safetyState,
  onSelectComponent,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [viewMode, setViewMode] = useState<TwinViewMode>('NORMAL');
  const [selectedCompName, setSelectedCompName] = useState<string | null>(null);

  // References to 3D objects for dynamic animation
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const fanMeshesRef = useRef<THREE.Mesh[]>([]);
  const particleSystemRef = useRef<THREE.Points | null>(null);
  const moduleMeshesRef = useRef<THREE.Mesh[]>([]);
  const cableMeshRef = useRef<THREE.Mesh | null>(null);
  const contactorMeshRef = useRef<THREE.Mesh | null>(null);

  // Mouse interaction state
  const isDraggingRef = useRef(false);
  const prevMousePosRef = useRef({ x: 0, y: 0 });
  const cameraAngleRef = useRef({ theta: 0.7, phi: 0.45, radius: 14 });
  const powerKwRef = useRef(powerKw);
  const fanSpeedPercentRef = useRef(charger.cooling.radiatorFanSpeedPercent);

  useEffect(() => {
    powerKwRef.current = powerKw;
    fanSpeedPercentRef.current = charger.cooling.radiatorFanSpeedPercent;
  }, [powerKw, charger.cooling.radiatorFanSpeedPercent]);

  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    // 1. Setup Scene, Camera, Renderer
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x0a0e14);

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    rendererRef.current = renderer;
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    while (container.firstChild) {
      container.removeChild(container.firstChild);
    }
    container.appendChild(renderer.domElement);

    // 2. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight1.position.set(10, 15, 10);
    dirLight1.castShadow = true;
    scene.add(dirLight1);

    const bluePoint = new THREE.PointLight(0x00e5ff, 1.5, 15);
    bluePoint.position.set(0, 3, 2);
    scene.add(bluePoint);

    // 3. Grid Floor
    const gridHelper = new THREE.GridHelper(24, 24, 0x1f2937, 0x111827);
    gridHelper.position.y = -0.01;
    scene.add(gridHelper);

    // 4. Construct 3D Assembly
    const mainGroup = new THREE.Group();
    mainGroup.name = 'ASSEMBLY_ROOT';
    scene.add(mainGroup);

    // --- A. CHARGER CABINET ---
    const cabinetGeom = new THREE.BoxGeometry(2.4, 4.8, 1.6);
    const cabinetMat = new THREE.MeshStandardMaterial({
      color: 0x181e29,
      roughness: 0.35,
      metalness: 0.85,
    });
    const cabinetMesh = new THREE.Mesh(cabinetGeom, cabinetMat);
    cabinetMesh.position.set(-2.5, 2.4, 0);
    cabinetMesh.castShadow = true;
    cabinetMesh.receiveShadow = true;
    cabinetMesh.name = 'CHARGER_CABINET';
    mainGroup.add(cabinetMesh);

    // Front Glass / Display Screen
    const screenGeom = new THREE.PlaneGeometry(1.2, 0.8);
    const screenMat = new THREE.MeshBasicMaterial({ color: 0x00f0ff });
    const screenMesh = new THREE.Mesh(screenGeom, screenMat);
    screenMesh.position.set(-2.5, 3.4, 0.81);
    screenMesh.name = 'HMI_TOUCHSCREEN';
    mainGroup.add(screenMesh);

    // Status LED Top Lightbar
    const ledGeom = new THREE.CylinderGeometry(0.08, 0.08, 2.2, 16);
    const ledMat = new THREE.MeshBasicMaterial({ color: 0x10b981 });
    const ledMesh = new THREE.Mesh(ledGeom, ledMat);
    ledMesh.rotation.z = Math.PI / 2;
    ledMesh.position.set(-2.5, 4.85, 0);
    ledMesh.name = 'STATUS_BEACON';
    mainGroup.add(ledMesh);

    // --- B. POWER MODULE ARRAY (7x Modular Blocks) ---
    moduleMeshesRef.current = [];
    for (let i = 0; i < 7; i++) {
      const modGeom = new THREE.BoxGeometry(1.8, 0.42, 1.2);
      const modMat = new THREE.MeshStandardMaterial({
        color: 0x334155,
        roughness: 0.4,
        metalness: 0.6,
      });
      const modMesh = new THREE.Mesh(modGeom, modMat);
      modMesh.position.set(-2.5, 0.6 + i * 0.52, 0);
      modMesh.name = `POWER_MODULE_${i + 1}`;
      mainGroup.add(modMesh);
      moduleMeshesRef.current.push(modMesh);
    }

    // --- C. COOLING SYSTEM (Radiator + Dual Fans + Coolant Tubes) ---
    fanMeshesRef.current = [];
    const radiatorGeom = new THREE.BoxGeometry(2.0, 1.2, 0.3);
    const radiatorMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.8 });
    const radiatorMesh = new THREE.Mesh(radiatorGeom, radiatorMat);
    radiatorMesh.position.set(-2.5, 4.0, -0.6);
    radiatorMesh.name = 'RADIATOR_HEAT_EXCHANGER';
    mainGroup.add(radiatorMesh);

    // 2x Fan Discs
    for (let f = 0; f < 2; f++) {
      const fanGeom = new THREE.CylinderGeometry(0.38, 0.38, 0.06, 8);
      const fanMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.5 });
      const fanMesh = new THREE.Mesh(fanGeom, fanMat);
      fanMesh.rotation.x = Math.PI / 2;
      fanMesh.position.set(-3.1 + f * 1.2, 4.0, -0.76);
      fanMesh.name = `COOLING_FAN_${f + 1}`;
      mainGroup.add(fanMesh);
      fanMeshesRef.current.push(fanMesh);
    }

    // --- D. DC CONTACTOR ASSEMBLY ---
    const contactorGeom = new THREE.BoxGeometry(0.8, 0.6, 0.6);
    const contactorMat = new THREE.MeshStandardMaterial({ color: 0x713f12, roughness: 0.6 });
    const contactorMesh = new THREE.Mesh(contactorGeom, contactorMat);
    contactorMesh.position.set(-2.5, 0.4, 0.3);
    contactorMesh.name = 'DC_CONTACTOR_ASSEMBLY';
    mainGroup.add(contactorMesh);
    contactorMeshRef.current = contactorMesh;

    // --- E. CHARGING CABLE (Spline curve from charger to vehicle) ---
    const curve = new THREE.CubicBezierCurve3(
      new THREE.Vector3(-1.4, 1.2, 0.5),
      new THREE.Vector3(-0.5, 0.1, 1.8),
      new THREE.Vector3(1.2, 0.1, 1.8),
      new THREE.Vector3(2.4, 1.1, 0.8)
    );
    const cableGeom = new THREE.TubeGeometry(curve, 32, 0.08, 12, false);
    const cableMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.7,
      metalness: 0.2,
    });
    const cableMesh = new THREE.Mesh(cableGeom, cableMat);
    cableMesh.name = 'LIQUID_COOLED_CABLE';
    mainGroup.add(cableMesh);
    cableMeshRef.current = cableMesh;

    // --- F. VEHICLE INLET & CHASSIS WIREFRAME ---
    const carGroup = new THREE.Group();
    carGroup.position.set(3.5, 0, 0);

    // Car Body Envelope (Translucent)
    const carGeom = new THREE.BoxGeometry(3.6, 1.4, 2.0);
    const carMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      transparent: true,
      opacity: 0.4,
      roughness: 0.2,
      metalness: 0.9,
    });
    const carMesh = new THREE.Mesh(carGeom, carMat);
    carMesh.position.set(0, 0.9, 0);
    carMesh.name = 'EV_CHASSIS_ENVELOPE';
    carGroup.add(carMesh);

    // Battery Pack Floor (Underbody)
    const battGeom = new THREE.BoxGeometry(2.8, 0.28, 1.6);
    const battMat = new THREE.MeshStandardMaterial({
      color: 0x059669,
      roughness: 0.3,
      metalness: 0.7,
    });
    const battMesh = new THREE.Mesh(battGeom, battMat);
    battMesh.position.set(0, 0.25, 0);
    battMesh.name = 'BATTERY_PACK_800V';
    carGroup.add(battMesh);

    // 4 Wheels
    const wheelGeom = new THREE.CylinderGeometry(0.42, 0.42, 0.25, 18);
    const wheelMat = new THREE.MeshStandardMaterial({ color: 0x09090b });
    const wheelPositions = [
      [-1.2, 0.42, 1.05],
      [1.2, 0.42, 1.05],
      [-1.2, 0.42, -1.05],
      [1.2, 0.42, -1.05],
    ];
    wheelPositions.forEach((pos) => {
      const wheel = new THREE.Mesh(wheelGeom, wheelMat);
      wheel.rotation.x = Math.PI / 2;
      wheel.position.set(pos[0], pos[1], pos[2]);
      carGroup.add(wheel);
    });

    mainGroup.add(carGroup);

    // --- G. ELECTRICAL PARTICLE STREAM (Moving along cable to battery) ---
    const particleCount = 120;
    const particleGeom = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleSpeeds = new Float32Array(particleCount);

    for (let p = 0; p < particleCount; p++) {
      const t = p / particleCount;
      const pt = curve.getPoint(t);
      particlePositions[p * 3] = pt.x;
      particlePositions[p * 3 + 1] = pt.y;
      particlePositions[p * 3 + 2] = pt.z;
      particleSpeeds[p] = t;
    }
    particleGeom.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));

    const particleMat = new THREE.PointsMaterial({
      color: 0x00f0ff,
      size: 0.12,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
    });
    const particleSystem = new THREE.Points(particleGeom, particleMat);
    particleSystem.name = 'ELECTRICAL_FLOW_PARTICLES';
    mainGroup.add(particleSystem);
    particleSystemRef.current = particleSystem;

    // 5. Mouse Orbit Interaction Handler
    const updateCamera = () => {
      const { theta, phi, radius } = cameraAngleRef.current;
      camera.position.x = radius * Math.sin(theta) * Math.cos(phi);
      camera.position.y = radius * Math.sin(phi);
      camera.position.z = radius * Math.cos(theta) * Math.cos(phi);
      camera.lookAt(0, 1.8, 0);
    };
    updateCamera();

    const onMouseDown = (e: MouseEvent) => {
      isDraggingRef.current = true;
      prevMousePosRef.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDraggingRef.current) return;
      const dx = e.clientX - prevMousePosRef.current.x;
      const dy = e.clientY - prevMousePosRef.current.y;
      prevMousePosRef.current = { x: e.clientX, y: e.clientY };

      cameraAngleRef.current.theta += dx * 0.008;
      cameraAngleRef.current.phi = Math.max(0.1, Math.min(1.4, cameraAngleRef.current.phi + dy * 0.008));
      updateCamera();
    };

    const onMouseUp = () => {
      isDraggingRef.current = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      cameraAngleRef.current.radius = Math.max(6, Math.min(26, cameraAngleRef.current.radius + e.deltaY * 0.015));
      updateCamera();
    };

    const domElem = renderer.domElement;
    domElem.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    domElem.addEventListener('wheel', onWheel, { passive: false });

    // 6. Animation Loop
    let animationId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationId = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const elapsedTime = clock.getElapsedTime();

      // Spin cooling fans according to simulated pump/fan load
      const fanSpeed = (fanSpeedPercentRef.current / 100) * 25;
      fanMeshesRef.current.forEach((fan) => {
        fan.rotation.y += fanSpeed * delta;
      });

      // Animate electrical energy particles along the charging cable curve
      if (particleSystemRef.current && powerKwRef.current > 1.0) {
        const positions = particleSystemRef.current.geometry.attributes.position.array as Float32Array;
        const speed = (powerKwRef.current / 350) * 0.8 + 0.1;

        for (let p = 0; p < particleCount; p++) {
          particleSpeeds[p] = (particleSpeeds[p] + speed * delta) % 1.0;
          const pt = curve.getPoint(particleSpeeds[p]);
          positions[p * 3] = pt.x + (Math.random() - 0.5) * 0.04;
          positions[p * 3 + 1] = pt.y + (Math.random() - 0.5) * 0.04;
          positions[p * 3 + 2] = pt.z + (Math.random() - 0.5) * 0.04;
        }
        particleSystemRef.current.geometry.attributes.position.needsUpdate = true;
        particleSystemRef.current.visible = true;
      } else if (particleSystemRef.current) {
        particleSystemRef.current.visible = false;
      }

      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!mountRef.current) return;
      const newW = mountRef.current.clientWidth;
      const newH = mountRef.current.clientHeight;
      camera.aspect = newW / newH;
      camera.updateProjectionMatrix();
      renderer.setSize(newW, newH);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      domElem.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      domElem.removeEventListener('wheel', onWheel);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  // Update Visual View Modes (Thermal, Exploded, Cutaway, X-Ray)
  useEffect(() => {
    if (!sceneRef.current) return;
    const root = sceneRef.current.getObjectByName('ASSEMBLY_ROOT') as THREE.Group;
    if (!root) return;

    const cabinet = root.getObjectByName('CHARGER_CABINET') as THREE.Mesh;
    const cable = cableMeshRef.current;

    if (viewMode === 'CUTAWAY') {
      if (cabinet) (cabinet.material as THREE.MeshStandardMaterial).opacity = 0.2;
      if (cabinet) (cabinet.material as THREE.MeshStandardMaterial).transparent = true;
      moduleMeshesRef.current.forEach((m, idx) => {
        m.position.set(-2.5, 0.6 + idx * 0.52, 0);
      });
    } else if (viewMode === 'EXPLODED') {
      if (cabinet) (cabinet.material as THREE.MeshStandardMaterial).opacity = 0.4;
      if (cabinet) (cabinet.material as THREE.MeshStandardMaterial).transparent = true;
      moduleMeshesRef.current.forEach((m, idx) => {
        m.position.set(-2.5 - (idx % 2 === 0 ? 0.8 : -0.8), 0.6 + idx * 0.65, idx * 0.3);
      });
    } else if (viewMode === 'THERMAL') {
      // Color-map temperature onto power modules and cables
      if (cabinet) (cabinet.material as THREE.MeshStandardMaterial).opacity = 0.3;
      if (cabinet) (cabinet.material as THREE.MeshStandardMaterial).transparent = true;
      moduleMeshesRef.current.forEach((m, idx) => {
        m.position.set(-2.5, 0.6 + idx * 0.52, 0);
        const temp = charger.moduleArray[idx]?.temperatureC || maxTempC;
        // False-color gradient: 25°C (cyan) -> 50°C (green) -> 75°C (yellow/orange) -> 90°C (red)
        let colorHex = 0x00e5ff;
        if (temp > 80) colorHex = 0xef4444; // Red
        else if (temp > 65) colorHex = 0xf97316; // Orange
        else if (temp > 50) colorHex = 0xeab308; // Yellow
        else if (temp > 35) colorHex = 0x10b981; // Green

        (m.material as THREE.MeshStandardMaterial).color.setHex(colorHex);
      });

      if (cable) {
        const cableTemp = charger.cables[0]?.cableTempC || 30;
        let cCol = 0x10b981;
        if (cableTemp > 75) cCol = 0xef4444;
        else if (cableTemp > 60) cCol = 0xf97316;
        (cable.material as THREE.MeshStandardMaterial).color.setHex(cCol);
      }
    } else if (viewMode === 'XRAY') {
      if (cabinet) (cabinet.material as THREE.MeshStandardMaterial).wireframe = true;
      moduleMeshesRef.current.forEach((m) => {
        (m.material as THREE.MeshStandardMaterial).wireframe = true;
      });
    } else {
      // NORMAL
      if (cabinet) {
        (cabinet.material as THREE.MeshStandardMaterial).wireframe = false;
        (cabinet.material as THREE.MeshStandardMaterial).opacity = 1.0;
        (cabinet.material as THREE.MeshStandardMaterial).transparent = false;
        (cabinet.material as THREE.MeshStandardMaterial).color.setHex(0x181e29);
      }
      moduleMeshesRef.current.forEach((m, idx) => {
        m.position.set(-2.5, 0.6 + idx * 0.52, 0);
        (m.material as THREE.MeshStandardMaterial).wireframe = false;
        (m.material as THREE.MeshStandardMaterial).color.setHex(0x334155);
      });
      if (cable) (cable.material as THREE.MeshStandardMaterial).color.setHex(0x0f172a);
    }
  }, [viewMode, maxTempC, charger]);

  return (
    <div className="relative w-full h-full min-h-[460px] bg-[#0a0e14] rounded-xl border border-slate-800 overflow-hidden flex flex-col">
      {/* Top 3D Viewport Controls */}
      <div className="absolute top-3 left-3 right-3 z-10 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-2 pointer-events-auto bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800 text-xs">
          <span className="font-mono font-semibold text-emerald-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            3D DIGITAL TWIN
          </span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400 font-mono">{charger.modelName}</span>
          <span className="text-slate-600">→</span>
          <span className="text-cyan-400 font-mono">{vehicle.vehicleName}</span>
        </div>

        {/* View Mode Switcher Pills */}
        <div className="flex items-center gap-1 pointer-events-auto bg-slate-900/80 backdrop-blur-md p-1 rounded-lg border border-slate-800 text-xs font-mono">
          <button
            onClick={() => setViewMode('NORMAL')}
            className={`px-2.5 py-1 rounded transition-all ${viewMode === 'NORMAL' ? 'bg-slate-700 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
          >
            NORMAL
          </button>
          <button
            onClick={() => setViewMode('CUTAWAY')}
            className={`px-2.5 py-1 rounded transition-all ${viewMode === 'CUTAWAY' ? 'bg-blue-600/80 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
          >
            CUTAWAY
          </button>
          <button
            onClick={() => setViewMode('EXPLODED')}
            className={`px-2.5 py-1 rounded transition-all ${viewMode === 'EXPLODED' ? 'bg-purple-600/80 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
          >
            EXPLODED
          </button>
          <button
            onClick={() => setViewMode('THERMAL')}
            className={`px-2.5 py-1 rounded transition-all flex items-center gap-1 ${viewMode === 'THERMAL' ? 'bg-amber-600/80 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
          >
            <Flame className="w-3 h-3" />
            THERMAL
          </button>
          <button
            onClick={() => setViewMode('ELECTRICAL')}
            className={`px-2.5 py-1 rounded transition-all flex items-center gap-1 ${viewMode === 'ELECTRICAL' ? 'bg-cyan-600/80 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
          >
            <Zap className="w-3 h-3" />
            PARTICLES
          </button>
          <button
            onClick={() => setViewMode('XRAY')}
            className={`px-2.5 py-1 rounded transition-all ${viewMode === 'XRAY' ? 'bg-emerald-600/80 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
          >
            X-RAY
          </button>
        </div>
      </div>

      {/* 3D WebGL Canvas Container */}
      <div ref={mountRef} className="w-full flex-1 cursor-grab active:cursor-grabbing" />

      {/* Bottom Live Telemetry HUD Bar */}
      <div className="absolute bottom-3 left-3 right-3 z-10 pointer-events-none flex items-center justify-between">
        <div className="bg-slate-900/85 backdrop-blur-md px-4 py-2 rounded-lg border border-slate-800 grid grid-cols-5 gap-6 text-xs pointer-events-auto">
          <div>
            <div className="text-slate-500 font-mono text-[10px]">OUTPUT POWER</div>
            <div className="font-mono text-cyan-400 font-bold text-sm">{powerKw.toFixed(1)} kW</div>
          </div>
          <div>
            <div className="text-slate-500 font-mono text-[10px]">BUS VOLTAGE</div>
            <div className="font-mono text-white font-bold text-sm">{voltageV.toFixed(1)} V</div>
          </div>
          <div>
            <div className="text-slate-500 font-mono text-[10px]">DC CURRENT</div>
            <div className="font-mono text-amber-400 font-bold text-sm">{currentA.toFixed(1)} A</div>
          </div>
          <div>
            <div className="text-slate-500 font-mono text-[10px]">PEAK TEMP</div>
            <div className={`font-mono font-bold text-sm ${maxTempC > 80 ? 'text-red-400' : maxTempC > 65 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {maxTempC.toFixed(1)} °C
            </div>
          </div>
          <div>
            <div className="text-slate-500 font-mono text-[10px]">FAN / PUMP SPEED</div>
            <div className="font-mono text-blue-400 font-bold text-sm">
              {charger.cooling.radiatorFanSpeedPercent.toFixed(0)}% / {charger.cooling.currentFlowLpm.toFixed(1)} LPM
            </div>
          </div>
        </div>

        <div className="bg-slate-900/85 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800 text-[11px] font-mono text-slate-400 pointer-events-auto flex items-center gap-2">
          <span>Rotate: Left Drag</span>
          <span>•</span>
          <span>Zoom: Wheel</span>
        </div>
      </div>
    </div>
  );
};
