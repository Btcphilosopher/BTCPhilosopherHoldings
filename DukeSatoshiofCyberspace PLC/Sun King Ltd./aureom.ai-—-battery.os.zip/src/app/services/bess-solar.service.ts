import { Injectable } from '@angular/core';
import { BessSolarDataPoint } from '../models/battery.models';

export type DispatchStrategy = 'PEAK_SHAVING' | 'TOU_ARBITRAGE' | 'SOLAR_SELF_CONSUMPTION' | 'FREQUENCY_REGULATION';

export interface BessSystemSpec {
  name: string;
  inverterPowerKw: number; // e.g. 1000 kW (1 MW)
  batteryCapacityKwh: number; // e.g. 2000 kWh (2 MWh, 2-hour storage)
  roundTripEfficiencyPct: number; // e.g. 89%
  hvacParasiticKw: number; // e.g. 18 kW continuous
  solarCapacityKwp: number; // e.g. 1200 kWp
  peakDemandTargetKw: number; // e.g. 650 kW
}

export interface BessSimulationOutput {
  data: BessSolarDataPoint[];
  solarSelfConsumptionPct: number;
  dailyArbitrageRevenueUsd: number;
  peakReductionKw: number;
  roundTripLossesKwh: number;
  gridImportTotalKwh: number;
  gridExportTotalKwh: number;
}

@Injectable({
  providedIn: 'root'
})
export class BessSolarService {
  public readonly defaultSpec: BessSystemSpec = {
    name: 'Aureom Titan 2.0 BESS Container',
    inverterPowerKw: 1000,
    batteryCapacityKwh: 2000,
    roundTripEfficiencyPct: 89.5,
    hvacParasiticKw: 14.0,
    solarCapacityKwp: 1250,
    peakDemandTargetKw: 620
  };

  /**
   * Simulates a 24-hour dispatch cycle with hourly solar PV generation,
   * commercial load, dynamic electricity pricing, and energy management strategy.
   */
  public simulate24HourDispatch(
    strategy: DispatchStrategy = 'TOU_ARBITRAGE',
    spec: BessSystemSpec = this.defaultSpec
  ): {
    data: BessSolarDataPoint[];
    solarSelfConsumptionPct: number;
    dailyArbitrageRevenueUsd: number;
    peakReductionKw: number;
    roundTripLossesKwh: number;
    gridImportTotalKwh: number;
    gridExportTotalKwh: number;
  } {
    const data: BessSolarDataPoint[] = [];
    let currentSoc = 0.35; // Start at 35% at midnight
    const oneWayEff = Math.sqrt(spec.roundTripEfficiencyPct / 100.0);

    let totalSolarKwh = 0;
    let totalDirectSolarUsedKwh = 0;
    let totalSolarStoredKwh = 0;
    let totalArbitrageSavings = 0;
    let maxBaseLoad = 0;
    let maxNetLoad = 0;
    let totalGridImport = 0;
    let totalGridExport = 0;
    let totalLosses = 0;

    for (let h = 0; h < 24; h++) {
      // 1. Hourly solar generation curve (bell-curve peak around 12:00-13:00)
      let solarNorm = 0;
      if (h >= 6 && h <= 19) {
        solarNorm = Math.sin(((h - 6) / 13.0) * Math.PI);
        solarNorm = Math.pow(Math.max(0, solarNorm), 1.4);
      }
      const solarKw = solarNorm * spec.solarCapacityKwp;
      totalSolarKwh += solarKw;

      // 2. Commercial / Industrial facility baseline demand (morning ramp, afternoon peak)
      let demandNorm = 0.32; // Night baseline
      if (h >= 7 && h <= 18) {
        demandNorm = 0.65 + 0.30 * Math.sin(((h - 7) / 11.0) * Math.PI);
      } else if (h >= 19 && h <= 22) {
        demandNorm = 0.52;
      }
      const facilityDemandKw = demandNorm * spec.peakDemandTargetKw * 1.55;
      maxBaseLoad = Math.max(maxBaseLoad, facilityDemandKw);

      // 3. Time-of-use (TOU) electricity pricing profile ($/kWh)
      // Off-peak (00-06): $0.09/kWh
      // Shoulder (07-15, 22-24): $0.18/kWh
      // On-Peak (16-21): $0.38/kWh (expensive peak demand period)
      let price = 0.18;
      if (h >= 0 && h < 6) {
        price = 0.085;
      } else if (h >= 16 && h <= 21) {
        price = 0.385;
      } else if (h >= 11 && h <= 14) {
        price = 0.12; // Solar midday shoulder
      }

      // 4. Energy Management Dispatch Logic
      let batteryChargeKw = 0;
      let batteryDischargeKw = 0;
      let curtailmentKw = 0;

      const availableCapacityToChargeKwh = (0.95 - currentSoc) * spec.batteryCapacityKwh;
      const availableEnergyToDischargeKwh = (currentSoc - 0.10) * spec.batteryCapacityKwh;

      switch (strategy) {
        case 'PEAK_SHAVING': {
          // If demand exceeds peak target, discharge battery to clip peak
          if (facilityDemandKw > spec.peakDemandTargetKw && availableEnergyToDischargeKwh > 0) {
            const neededDischarge = facilityDemandKw - spec.peakDemandTargetKw;
            batteryDischargeKw = Math.min(neededDischarge, spec.inverterPowerKw, availableEnergyToDischargeKwh * oneWayEff);
          } else if (solarKw > facilityDemandKw && availableCapacityToChargeKwh > 0) {
            // Charge from excess solar
            const excessSolar = solarKw - facilityDemandKw;
            batteryChargeKw = Math.min(excessSolar, spec.inverterPowerKw, availableCapacityToChargeKwh / oneWayEff);
          } else if (h >= 1 && h <= 5 && currentSoc < 0.80) {
            // Pre-charge during cheap night hours to ensure reserve
            batteryChargeKw = Math.min(spec.inverterPowerKw * 0.45, availableCapacityToChargeKwh / oneWayEff);
          }
          break;
        }

        case 'TOU_ARBITRAGE': {
          // Charge during cheap hours (00:00-05:00 and 11:00-14:00 solar hours)
          if ((h >= 0 && h <= 4) || (h >= 11 && h <= 13 && solarKw > 200)) {
            if (availableCapacityToChargeKwh > 0) {
              const maxRate = (h >= 0 && h <= 4) ? spec.inverterPowerKw * 0.6 : spec.inverterPowerKw * 0.8;
              batteryChargeKw = Math.min(maxRate, availableCapacityToChargeKwh / oneWayEff);
            }
          } else if (h >= 16 && h <= 21 && availableEnergyToDischargeKwh > 0) {
            // Full discharge during expensive peak ($0.385/kWh)
            batteryDischargeKw = Math.min(spec.inverterPowerKw * 0.9, availableEnergyToDischargeKwh * oneWayEff, facilityDemandKw * 0.95);
          }
          break;
        }

        case 'SOLAR_SELF_CONSUMPTION': {
          if (solarKw > facilityDemandKw) {
            const surplus = solarKw - facilityDemandKw;
            if (availableCapacityToChargeKwh > 0) {
              batteryChargeKw = Math.min(surplus, spec.inverterPowerKw, availableCapacityToChargeKwh / oneWayEff);
            } else {
              curtailmentKw = surplus;
            }
          } else if (facilityDemandKw > solarKw && availableEnergyToDischargeKwh > 0) {
            const deficit = facilityDemandKw - solarKw;
            batteryDischargeKw = Math.min(deficit, spec.inverterPowerKw, availableEnergyToDischargeKwh * oneWayEff);
          }
          break;
        }

        case 'FREQUENCY_REGULATION': {
          // Fast bidirectional regulation balancing synthetic microgrid frequency excursions
          const freqDeviation = Math.sin(h * 1.8) * 0.15; // ±0.15 Hz
          if (freqDeviation > 0.05 && availableCapacityToChargeKwh > 0) {
            batteryChargeKw = Math.min(spec.inverterPowerKw * 0.5, availableCapacityToChargeKwh);
          } else if (freqDeviation < -0.05 && availableEnergyToDischargeKwh > 0) {
            batteryDischargeKw = Math.min(spec.inverterPowerKw * 0.5, availableEnergyToDischargeKwh);
          }
          break;
        }
      }

      // Update State of Charge
      if (batteryChargeKw > 0) {
        const storedKwh = batteryChargeKw * oneWayEff;
        currentSoc += storedKwh / spec.batteryCapacityKwh;
        totalLosses += batteryChargeKw * (1.0 - oneWayEff);
        totalSolarStoredKwh += storedKwh;
      } else if (batteryDischargeKw > 0) {
        const extractedKwh = batteryDischargeKw / oneWayEff;
        currentSoc -= extractedKwh / spec.batteryCapacityKwh;
        totalLosses += (extractedKwh - batteryDischargeKw);
      }
      currentSoc = Math.max(0.08, Math.min(0.98, currentSoc));

      // Grid balance: Demand + HVAC + BatteryCharge = Solar + BatteryDischarge + GridImport - GridExport
      const totalLoadKw = facilityDemandKw + spec.hvacParasiticKw + batteryChargeKw;
      const totalSupplyKw = solarKw + batteryDischargeKw;
      let gridImportKw = 0;
      let gridExportKw = 0;

      if (totalLoadKw > totalSupplyKw) {
        gridImportKw = totalLoadKw - totalSupplyKw;
        totalGridImport += gridImportKw;
      } else {
        gridExportKw = totalSupplyKw - totalLoadKw;
        totalGridExport += gridExportKw;
      }

      maxNetLoad = Math.max(maxNetLoad, gridImportKw);

      // Financial savings computation
      const baselineCost = (facilityDemandKw * price);
      const actualCost = (gridImportKw * price) - (gridExportKw * (price * 0.65)); // Feed-in tariff discount
      totalArbitrageSavings += Math.max(0, baselineCost - actualCost);

      totalDirectSolarUsedKwh += Math.min(solarKw, facilityDemandKw);

      data.push({
        hour: h,
        solarGenerationKw: Math.round(solarKw),
        facilityDemandKw: Math.round(facilityDemandKw),
        batteryChargeKw: Math.round(batteryChargeKw),
        batteryDischargeKw: Math.round(batteryDischargeKw),
        gridImportKw: Math.round(gridImportKw),
        gridExportKw: Math.round(gridExportKw),
        curtailmentKw: Math.round(curtailmentKw),
        socPct: Math.round(currentSoc * 1000) / 10,
        electricityPricePerKwh: price
      });
    }

    const selfConsumption = totalSolarKwh > 0 
      ? Math.min(100, Math.round(((totalDirectSolarUsedKwh + totalSolarStoredKwh) / totalSolarKwh) * 100))
      : 0;

    return {
      data,
      solarSelfConsumptionPct: selfConsumption,
      dailyArbitrageRevenueUsd: Math.round(totalArbitrageSavings),
      peakReductionKw: Math.max(0, Math.round(maxBaseLoad - maxNetLoad)),
      roundTripLossesKwh: Math.round(totalLosses),
      gridImportTotalKwh: Math.round(totalGridImport),
      gridExportTotalKwh: Math.round(totalGridExport)
    };
  }
}
