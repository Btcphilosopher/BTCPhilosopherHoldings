import { Injectable } from '@angular/core';
import { 
  BatteryChemistryType, 
  CellState, 
  PackConfiguration, 
  PackTelemetry, 
  BMSState 
} from '../models/battery.models';
import { CHEMISTRIES, CELL_FORMATS, calculateOcv } from '../models/chemistry-database';

export interface EkfState {
  socEstimate: number;
  vRc1: number;
  vRc2: number;
  covarianceP: number[][]; // 3x3 error covariance matrix
  kalmanGain: number[];
  innovationResidual: number;
}

@Injectable({
  providedIn: 'root'
})
export class ElectrochemEngine {
  private cells: CellState[] = [];
  private vRc1Array: number[] = [];
  private vRc2Array: number[] = [];
  private ekfStates: EkfState[] = [];

  // Extended Kalman Filter parameters
  private readonly qSoc = 1e-6; // Process noise covariance for SOC
  private readonly qVrc1 = 1e-5;
  private readonly qVrc2 = 1e-5;
  private readonly rVoltage = 1e-3; // Measurement noise covariance (voltage sensor)

  /**
   * Initializes the pack with realistic cell-to-cell variations
   */
  public initializePack(config: PackConfiguration): CellState[] {
    const totalCells = config.seriesCount * config.parallelCount;
    const chemProps = CHEMISTRIES[config.chemistry];
    const formatProps = CELL_FORMATS[config.format];

    this.cells = [];
    this.vRc1Array = new Array(totalCells).fill(0);
    this.vRc2Array = new Array(totalCells).fill(0);
    this.ekfStates = [];

    // Deterministic pseudo-random seed generator for realistic reproducibility
    let seed = 42;
    const pseudoRandom = () => {
      seed = (seed * 9301 + 49297) % 233280;
      return seed / 233280;
    };
    const gaussianRandom = (mean: number, stdDev: number) => {
      const u1 = Math.max(1e-6, pseudoRandom());
      const u2 = pseudoRandom();
      const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
      return mean + z0 * stdDev;
    };

    const cellsPerModule = Math.min(16, config.seriesCount);
    const nominalCap = config.cellCapacityAh || formatProps.defaultCapacityAh;
    const baseR0 = (config.cellResistanceMOhms || chemProps.baseResistance);
    const mismatch = (config.cellMismatchPct ?? 1.5) / 100.0;

    for (let s = 0; s < config.seriesCount; s++) {
      const moduleIdx = Math.floor(s / cellsPerModule);
      for (let p = 0; p < config.parallelCount; p++) {
        // Individual capacity with Gaussian manufacturing dispersion
        const cellCap = Math.max(nominalCap * 0.9, gaussianRandom(nominalCap, nominalCap * mismatch));
        // Resistance variance (inversely correlated with capacity)
        const cellR0 = Math.max(baseR0 * 0.8, gaussianRandom(baseR0, baseR0 * mismatch * 1.5));
        
        // Initial state of charge (90% nominal with small 0.5% imbalance)
        const initialSoc = Math.max(0.05, Math.min(0.98, gaussianRandom(0.88, 0.008)));
        const cellOcv = calculateOcv(config.chemistry, initialSoc);
        
        // Geometric position in pack grid
        const cols = config.parallelCount;
        const x = (p - cols / 2) * 1.4;
        const y = (moduleIdx * 0.8);
        const z = ((s % cellsPerModule) - cellsPerModule / 2) * 1.1;

        const cell: CellState = {
          id: `CELL-${String(s + 1).padStart(3, '0')}-${String(p + 1).padStart(2, '0')}`,
          seriesIdx: s,
          parallelIdx: p,
          moduleIdx,
          x,
          y,
          z,
          voltage: cellOcv,
          current: 0,
          temperature: config.ambientTempC,
          soc: initialSoc,
          soh: 1.0,
          capacityAh: cellCap,
          nominalCapacityAh: nominalCap,
          internalResistanceMOhms: cellR0,
          etaOhmic: 0,
          etaChargeTransfer: 0,
          etaDiffusion: 0,
          qJoule: 0,
          qRev: 0,
          qTotal: 0,
          balancingActive: false,
          seiThicknessNm: 5.0, // Initial virgin SEI passivation layer
          lossOfLithiumPct: 0.0,
          faultFlags: {
            overVoltage: false,
            underVoltage: false,
            overTemperature: false,
            highImbalance: false,
            thermalRunawayRisk: false
          }
        };

        this.cells.push(cell);

        // Initialize EKF tracking state
        this.ekfStates.push({
          socEstimate: initialSoc + (pseudoRandom() - 0.5) * 0.04, // slight initial estimation error
          vRc1: 0,
          vRc2: 0,
          covarianceP: [
            [0.01, 0, 0],
            [0, 0.001, 0],
            [0, 0, 0.001]
          ],
          kalmanGain: [0, 0, 0],
          innovationResidual: 0
        });
      }
    }

    return this.cells;
  }

  /**
   * Advances the multiphysics simulation by dt seconds with an applied pack current.
   * Positive current = Discharge; Negative current = Charge.
   */
  public stepSimulation(
    config: PackConfiguration,
    packCurrentA: number,
    dtSec: number,
    bmsState: BMSState,
    ambientTempC: number,
    coolantInletTempC: number,
    coolantFlowRateLpm: number
  ): { cells: CellState[]; telemetry: PackTelemetry } {
    const chemProps = CHEMISTRIES[config.chemistry];
    const formatProps = CELL_FORMATS[config.format];
    const totalCells = this.cells.length;

    if (totalCells === 0) {
      this.initializePack(config);
    }

    // Branch current through parallel branches
    const nominalCellCurrent = packCurrentA / config.parallelCount;

    // Thermal properties of cell
    const cellMassKg = formatProps.weightGrams / 1000.0;
    const cp = formatProps.heatCapacity; // J/(kg·K)
    const thermalCapacitance = cellMassKg * cp; // J/K (~65-85 J/K for 21700, ~1700 J/K for prismatic)
    
    // Thermal resistance to cooling plate / ambient
    const rThCoolBase = config.coolingType === 'LIQUID' ? 0.8 :
                        config.coolingType === 'IMMERSION' ? 0.3 :
                        config.coolingType === 'FORCED_AIR' ? 2.5 : 8.0; // K/W
    // Convective scaling with flow rate
    const flowScale = Math.max(0.2, Math.min(2.0, coolantFlowRateLpm / 10.0));
    const rThCool = rThCoolBase / (config.coolingType === 'LIQUID' ? flowScale : 1.0);
    const rThAmb = 15.0; // K/W to ambient air

    let totalPackVoltage = 0;
    let minV = Infinity;
    let maxV = -Infinity;
    let minT = Infinity;
    let maxT = -Infinity;
    let sumT = 0;
    let sumSoc = 0;
    let sumSoh = 0;
    let sumLossW = 0;
    let totalHeatGenW = 0;

    // Determine cell balancing: active if BMS is in BALANCING or CHARGING state and voltage is top 5%
    const currentMaxCellVoltage = Math.max(...this.cells.map(c => c.voltage));
    const balancingThreshold = chemProps.maxVoltage * 0.94; // e.g. >3.45V for LFP or >4.05V for NMC

    for (let i = 0; i < totalCells; i++) {
      const cell = this.cells[i];

      // Balancing shunt current (passive bleeding resistor ~100mA)
      let cellBalancingCurrent = 0;
      if ((bmsState === 'BALANCING' || bmsState === 'CHARGING') && 
          cell.voltage >= balancingThreshold && 
          (currentMaxCellVoltage - cell.voltage < 0.035)) {
        cellBalancingCurrent = 0.12; // 120 mA dissipative balancing
        cell.balancingActive = true;
      } else {
        cell.balancingActive = false;
      }

      // Actual current through this individual cell (including parallel branch resistance division)
      const cellI = nominalCellCurrent + (cellBalancingCurrent);
      cell.current = cellI;

      // 1. Coulomb counting state of charge progression
      const deltaAh = (cellI * dtSec) / 3600.0;
      cell.soc = Math.max(0.001, Math.min(0.999, cell.soc - (deltaAh / cell.capacityAh)));

      // 2. Temperature scaling of internal resistance via Arrhenius
      // R_0(T) = R_ref * exp( Ea/R * (1/T - 1/T_ref) )
      const T_kelvin = cell.temperature + 273.15;
      const T_ref = 298.15; // 25°C
      const R_gas = 8.314; // J/(mol·K)
      const arrheniusFactor = Math.exp((chemProps.activationEnergy / R_gas) * ((1.0 / T_kelvin) - (1.0 / T_ref)));
      const activeR0_ohms = (cell.internalResistanceMOhms / 1000.0) * arrheniusFactor;

      // 3. Multiphysics overpotential calculations based on fidelity level
      const etaOhmic = cellI * activeR0_ohms;
      let etaChargeTransfer = 0;
      let etaDiffusion = 0;

      // Equivalent circuit RC dynamics (Thevenin 2-RC model)
      // R1 = 0.4*R0, C1 = 1500F, tau1 = 15s (Charge transfer double-layer)
      // R2 = 0.6*R0, C2 = 8000F, tau2 = 80s (Electrolyte/solid diffusion relaxation)
      const r1 = activeR0_ohms * 0.45;
      const c1 = 2000.0;
      const tau1 = r1 * c1;
      const r2 = activeR0_ohms * 0.55;
      const c2 = 12000.0;
      const tau2 = r2 * c2;

      // Discretized RC state transitions: vRC(k+1) = vRC(k)*exp(-dt/tau) + I*R*(1 - exp(-dt/tau))
      const exp1 = Math.exp(-dtSec / tau1);
      const exp2 = Math.exp(-dtSec / tau2);
      this.vRc1Array[i] = this.vRc1Array[i] * exp1 + cellI * r1 * (1 - exp1);
      this.vRc2Array[i] = this.vRc2Array[i] * exp2 + cellI * r2 * (1 - exp2);

      etaChargeTransfer = this.vRc1Array[i];
      etaDiffusion = this.vRc2Array[i];

      // High-fidelity SPMe / DFN electrochemical diffusion adjustments if selected
      if (config.fidelity === 'LEVEL_3_SPME' || config.fidelity === 'LEVEL_4_DFN') {
        // Solid phase diffusion limitation: Butler-Volmer overpotential: eta = 2RT/F * asinh(I / (2*I0))
        const i0 = 1.8 * Math.sqrt(Math.max(0.01, cell.soc * (1 - cell.soc))); // exchange current
        const f = 96485.0 / (R_gas * T_kelvin);
        const etaBv = (2.0 / f) * Math.asinh(Math.max(-5.0, Math.min(5.0, (cellI / (2.0 * i0)))));
        etaChargeTransfer = etaBv * 0.4 + this.vRc1Array[i] * 0.6;

        // Concentration overpotential due to liquid electrolyte concentration gradient
        const diffLimitingCurrent = 35.0; // A
        const concRatio = Math.max(0.05, 1.0 - (cellI / diffLimitingCurrent));
        etaDiffusion += (config.fidelity === 'LEVEL_4_DFN' ? 0.035 : 0.02) * Math.log(concRatio);
      }

      // 4. Terminal Cell Voltage Calculation
      // V_term = OCV(SOC) - eta_ohmic - eta_ct - eta_diff
      const ocv = calculateOcv(config.chemistry, cell.soc);
      cell.voltage = Math.max(0.5, ocv - etaOhmic - etaChargeTransfer - etaDiffusion);

      cell.etaOhmic = etaOhmic;
      cell.etaChargeTransfer = etaChargeTransfer;
      cell.etaDiffusion = etaDiffusion;

      // 5. Thermal generation: Joule heat (I^2 * R0 + I*vRC) + Entropic reversible heat
      const qJoule = Math.pow(cellI, 2) * activeR0_ohms + Math.abs(cellI * (etaChargeTransfer + etaDiffusion));
      const qRev = cellI * T_kelvin * chemProps.dEdT; // Reversible entropic heat
      const qTotal = Math.max(0, qJoule + qRev);

      cell.qJoule = qJoule;
      cell.qRev = qRev;
      cell.qTotal = qTotal;
      totalHeatGenW += qTotal;
      sumLossW += qJoule;

      // Thermal heat transfer: cell conduction to cooling fluid & ambient
      // m*Cp * dT/dt = Q_gen - (T_cell - T_coolant)/R_cool - (T_cell - T_amb)/R_amb
      const heatFluxCooling = (cell.temperature - coolantInletTempC) / rThCool;
      const heatFluxAmbient = (cell.temperature - ambientTempC) / rThAmb;
      const netThermalPower = qTotal - heatFluxCooling - heatFluxAmbient;

      const deltaT = (netThermalPower * dtSec) / thermalCapacitance;
      cell.temperature += deltaT;

      // Check for thermal runaway acceleration if T > criticalTemp
      if (cell.temperature > chemProps.criticalTemp) {
        // Arrhenius exothermic decomposition
        const runawayExotherm = 450.0 * Math.exp(0.04 * (cell.temperature - chemProps.criticalTemp));
        cell.temperature += (runawayExotherm * dtSec) / thermalCapacitance;
        cell.faultFlags.thermalRunawayRisk = true;
      } else {
        cell.faultFlags.thermalRunawayRisk = false;
      }

      // Update safety fault flags
      cell.faultFlags.overVoltage = cell.voltage > chemProps.maxVoltage;
      cell.faultFlags.underVoltage = cell.voltage < chemProps.minVoltage;
      cell.faultFlags.overTemperature = cell.temperature > 55.0;

      // 6. Step Extended Kalman Filter for this cell
      this.updateEkf(i, cellI, cell.voltage, dtSec, config.chemistry, activeR0_ohms, r1, c1, r2, c2);

      // Aggregates
      totalPackVoltage += (cell.voltage / config.parallelCount);
      minV = Math.min(minV, cell.voltage);
      maxV = Math.max(maxV, cell.voltage);
      minT = Math.min(minT, cell.temperature);
      maxT = Math.max(maxT, cell.temperature);
      sumT += cell.temperature;
      sumSoc += cell.soc;
      sumSoh += cell.soh;
    }

    const voltageImbalanceMv = (maxV - minV) * 1000.0;
    for (const c of this.cells) {
      c.faultFlags.highImbalance = voltageImbalanceMv > 80.0;
    }

    // Coolant outlet temperature rise: Q_total = m_dot * Cp_fluid * (T_out - T_in)
    // Water-glycol 50/50: Cp ≈ 3400 J/(kg·K), density ≈ 1.05 kg/L
    const coolantMassFlowKgSec = (coolantFlowRateLpm * 1.05) / 60.0;
    const coolantCp = 3400.0;
    const coolantTempRise = coolantMassFlowKgSec > 0.01 
      ? (totalHeatGenW * 0.85) / (coolantMassFlowKgSec * coolantCp)
      : 0.0;
    const coolantTempOutC = coolantInletTempC + coolantTempRise;

    const avgSoc = sumSoc / totalCells;
    const avgSoh = sumSoh / totalCells;
    const avgTemp = sumT / totalCells;

    const packPowerKw = (totalPackVoltage * packCurrentA) / 1000.0;
    const nominalEnergyKwh = (totalPackVoltage * config.cellCapacityAh * config.parallelCount) / 1000.0;
    const usableEnergyKwh = nominalEnergyKwh * avgSoc * avgSoh;

    // Contactors status
    const contactors = {
      mainPositive: bmsState !== 'FAULT' && bmsState !== 'SAFE_SHUTDOWN' && bmsState !== 'INITIALIZATION',
      mainNegative: bmsState !== 'FAULT' && bmsState !== 'SAFE_SHUTDOWN' && bmsState !== 'INITIALIZATION',
      precharge: bmsState === 'INITIALIZATION',
      auxiliary: true
    };

    const alarms: string[] = [];
    if (maxV > chemProps.maxVoltage) alarms.push(`CRITICAL: Cell Overvoltage (${maxV.toFixed(3)} V > ${chemProps.maxVoltage} V)`);
    if (minV < chemProps.minVoltage) alarms.push(`WARNING: Cell Undervoltage (${minV.toFixed(3)} V < ${chemProps.minVoltage} V)`);
    if (maxT > 55.0) alarms.push(`ALERT: Pack High Temperature Hotspot (${maxT.toFixed(1)} °C)`);
    if (voltageImbalanceMv > 70.0) alarms.push(`NOTICE: Cell Imbalance High (Δ${voltageImbalanceMv.toFixed(1)} mV)`);
    if (maxT > chemProps.criticalTemp) alarms.push(`EMERGENCY: Thermal Runaway Propagation Risk detected`);

    const telemetry: PackTelemetry = {
      packVoltage: totalPackVoltage,
      packCurrent: packCurrentA,
      packPowerKw,
      socPct: avgSoc * 100.0,
      sohPct: avgSoh * 100.0,
      avgTemperatureC: avgTemp,
      maxTemperatureC: maxT,
      minTemperatureC: minT,
      maxCellVoltage: maxV,
      minCellVoltage: minV,
      voltageImbalanceMv,
      nominalEnergyKwh,
      usableEnergyKwh,
      deliveredEnergyKwh: 0,
      totalResistanceMOhms: (chemProps.baseResistance * config.seriesCount) / config.parallelCount,
      powerLossKw: sumLossW / 1000.0,
      efficiencyPct: Math.max(88, 100.0 - (sumLossW / Math.max(100, Math.abs(packPowerKw * 1000))) * 100.0),
      coolantTempOutC,
      bmsState,
      contactors,
      alarms
    };

    return { cells: this.cells, telemetry };
  }

  /**
   * Extended Kalman Filter (EKF) observer algorithm
   */
  private updateEkf(
    idx: number, 
    currentA: number, 
    measuredVoltage: number, 
    dtSec: number, 
    chem: BatteryChemistryType,
    r0: number, 
    r1: number, 
    c1: number, 
    r2: number, 
    c2: number
  ): void {
    const ekf = this.ekfStates[idx];
    const cell = this.cells[idx];
    if (!ekf) return;

    // 1. Time Update (Prediction)
    const tau1 = r1 * c1;
    const tau2 = r2 * c2;
    const a1 = Math.exp(-dtSec / tau1);
    const a2 = Math.exp(-dtSec / tau2);

    // Predict state: x_hat = [SOC, vRc1, vRc2]
    const capSeconds = cell.capacityAh * 3600.0;
    const socPred = Math.max(0.001, Math.min(0.999, ekf.socEstimate - (currentA * dtSec) / capSeconds));
    const vRc1Pred = ekf.vRc1 * a1 + currentA * r1 * (1 - a1);
    const vRc2Pred = ekf.vRc2 * a2 + currentA * r2 * (1 - a2);

    // State transition Jacobian matrix F
    // F = [ [1, 0, 0], [0, a1, 0], [0, 0, a2] ]
    const p = ekf.covarianceP;
    const pPred = [
      [p[0][0] + this.qSoc, p[0][1], p[0][2]],
      [p[1][0], p[1][1] * a1 * a1 + this.qVrc1, p[1][2] * a1 * a2],
      [p[2][0], p[2][1] * a2 * a1, p[2][2] * a2 * a2 + this.qVrc2]
    ];

    // 2. Measurement Update (Correction)
    // Predicted measurement: y_hat = OCV(socPred) - I*R0 - vRc1Pred - vRc2Pred
    const ocvPred = calculateOcv(chem, socPred);
    const yHat = ocvPred - currentA * r0 - vRc1Pred - vRc2Pred;
    const innovation = measuredVoltage - yHat;
    ekf.innovationResidual = innovation;

    // Measurement matrix H = [dOCV/dSOC, -1, -1]
    const deltaSoc = 0.005;
    const dOcvDsoc = (calculateOcv(chem, Math.min(0.999, socPred + deltaSoc)) - calculateOcv(chem, Math.max(0.001, socPred - deltaSoc))) / (2 * deltaSoc);
    const H = [dOcvDsoc, -1.0, -1.0];

    // Innovation covariance: S = H * P_pred * H^T + R
    const HP0 = H[0] * pPred[0][0] + H[1] * pPred[1][0] + H[2] * pPred[2][0];
    const HP1 = H[0] * pPred[0][1] + H[1] * pPred[1][1] + H[2] * pPred[2][1];
    const HP2 = H[0] * pPred[0][2] + H[1] * pPred[1][2] + H[2] * pPred[2][2];
    const S = HP0 * H[0] + HP1 * H[1] + HP2 * H[2] + this.rVoltage;

    // Kalman Gain: K = P_pred * H^T / S
    const K0 = (pPred[0][0] * H[0] + pPred[0][1] * H[1] + pPred[0][2] * H[2]) / S;
    const K1 = (pPred[1][0] * H[0] + pPred[1][1] * H[1] + pPred[1][2] * H[2]) / S;
    const K2 = (pPred[2][0] * H[0] + pPred[2][1] * H[1] + pPred[2][2] * H[2]) / S;
    ekf.kalmanGain = [K0, K1, K2];

    // Updated state estimates
    ekf.socEstimate = Math.max(0.001, Math.min(0.999, socPred + K0 * innovation));
    ekf.vRc1 = vRc1Pred + K1 * innovation;
    ekf.vRc2 = vRc2Pred + K2 * innovation;

    // Updated covariance: P = (I - K*H) * P_pred
    ekf.covarianceP = [
      [pPred[0][0] - K0 * HP0, pPred[0][1] - K0 * HP1, pPred[0][2] - K0 * HP2],
      [pPred[1][0] - K1 * HP0, pPred[1][1] - K1 * HP1, pPred[1][2] - K1 * HP2],
      [pPred[2][0] - K2 * HP0, pPred[2][1] - K2 * HP1, pPred[2][2] - K2 * HP2]
    ];
  }

  public getEkfState(index = 0): EkfState | null {
    return this.ekfStates[index] || null;
  }
}
