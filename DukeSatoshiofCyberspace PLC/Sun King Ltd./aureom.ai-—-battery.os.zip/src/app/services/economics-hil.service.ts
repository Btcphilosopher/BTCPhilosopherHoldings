import { Injectable } from '@angular/core';
import { EconomicAnalysisResult, HilCanMessage, ModbusRegister, BatteryChemistryType } from '../models/battery.models';

export interface EconomicsInputParams {
  storageCapacityKwh: number;
  inverterPowerKw: number;
  cellCostPerKwhUsd: number;
  bopCostPerKwhUsd: number;
  inverterCostPerKwUsd: number;
  epcInstallationPct: number;
  annualOpexPerKwUsd: number;
  cyclesPerDay: number;
  discountRatePct: number;
  projectLifeYears: number;
  electricityPurchasePriceUsdKwh: number;
  peakDemandChargeUsdPerKwMonth: number;
  chemistry: BatteryChemistryType;
}

@Injectable({
  providedIn: 'root'
})
export class EconomicsHilService {

  /**
   * Calculates CAPEX, OPEX, LCOS, NPV, IRR, and payback period
   */
  public calculateEconomics(params: EconomicsInputParams): EconomicAnalysisResult {
    // 1. CAPEX Breakdown
    const batteryPackCapex = params.storageCapacityKwh * (params.cellCostPerKwhUsd + params.bopCostPerKwhUsd);
    const inverterCapex = params.inverterPowerKw * params.inverterCostPerKwUsd;
    const hardwareSubtotal = batteryPackCapex + inverterCapex;
    const epcCivilCost = hardwareSubtotal * (params.epcInstallationPct / 100.0);
    const totalCapex = hardwareSubtotal + epcCivilCost;

    const costPerUsableKwh = totalCapex / params.storageCapacityKwh;

    // 2. OPEX and Annual Cash Flows
    const annualFixedOpex = params.inverterPowerKw * params.annualOpexPerKwUsd;

    // Daily energy throughput
    const dod = 0.85;
    const roundTripEff = 0.89;
    const dailyThroughputKwh = params.storageCapacityKwh * dod * params.cyclesPerDay;
    const annualDischargeKwh = dailyThroughputKwh * 365.25;
    const annualChargeKwh = annualDischargeKwh / roundTripEff;
    const annualChargingCost = annualChargeKwh * params.electricityPurchasePriceUsdKwh;

    // Annual Revenues / Savings
    // A: Energy arbitrage (spread between peak $0.38 and off-peak $0.09)
    const priceSpread = 0.28; // $/kWh
    const annualArbitrageSavings = annualDischargeKwh * priceSpread;

    // B: Demand charge reduction ($/kW-month * 12 * avoided peak kW)
    const demandReductionKw = params.inverterPowerKw * 0.70;
    const annualPeakShavingSavings = demandReductionKw * params.peakDemandChargeUsdPerKwMonth * 12;

    const totalAnnualBenefit = annualArbitrageSavings + annualPeakShavingSavings;
    const netAnnualCashFlow = totalAnnualBenefit - annualFixedOpex - annualChargingCost;

    // 3. Discounted Cash Flow for LCOS, NPV & IRR
    const r = params.discountRatePct / 100.0;
    let npv = -totalCapex;
    let discountedTotalCost = totalCapex;
    let discountedEnergyMwh = 0;

    for (let t = 1; t <= params.projectLifeYears; t++) {
      const discountFactor = Math.pow(1 + r, -t);
      // Include mid-life cell augmentation at year 10 if NMC/NCA
      let augmentationCost = 0;
      if (t === 10 && (params.chemistry === 'NMC811' || params.chemistry === 'NCA')) {
        augmentationCost = batteryPackCapex * 0.40; // 40% cell replacement
      }

      const yearCost = annualFixedOpex + annualChargingCost + augmentationCost;
      const yearCashFlow = totalAnnualBenefit - yearCost;

      npv += yearCashFlow * discountFactor;
      discountedTotalCost += yearCost * discountFactor;

      const yearDischargeMwh = (annualDischargeKwh * Math.max(0.70, 1.0 - 0.015 * t)) / 1000.0;
      discountedEnergyMwh += yearDischargeMwh * discountFactor;
    }

    const lcosPerMwh = discountedEnergyMwh > 0 ? discountedTotalCost / discountedEnergyMwh : 0;
    const simplePaybackYears = netAnnualCashFlow > 0 ? totalCapex / netAnnualCashFlow : 99;
    
    // Approximate IRR using Newton-Raphson approximation
    let irr = 0.12;
    for (let iter = 0; iter < 10; iter++) {
      let f = -totalCapex;
      let df = 0;
      for (let t = 1; t <= params.projectLifeYears; t++) {
        const factor = Math.pow(1 + irr, -t);
        f += netAnnualCashFlow * factor;
        df -= t * netAnnualCashFlow * Math.pow(1 + irr, -t - 1);
      }
      if (Math.abs(df) > 1e-4) {
        irr = irr - f / df;
      }
    }
    const irrPct = Math.max(0, Math.min(60, irr * 100.0));

    // CO2 avoided (clean solar/battery dispatch vs coal/gas peak generation ~0.42 kg CO2 / kWh)
    const co2TonsPerYear = (annualDischargeKwh * 0.42) / 1000.0;

    return {
      capexUsd: Math.round(totalCapex),
      opexAnnualUsd: Math.round(annualFixedOpex),
      costPerUsableKwh: Math.round(costPerUsableKwh),
      lcosPerMwh: Math.round(lcosPerMwh * 10) / 10,
      annualArbitrageSavingsUsd: Math.round(annualArbitrageSavings),
      annualPeakShavingSavingsUsd: Math.round(annualPeakShavingSavings),
      totalAnnualBenefitUsd: Math.round(totalAnnualBenefit),
      netPresentValueUsd: Math.round(npv),
      internalRateOfReturnPct: Math.round(irrPct * 10) / 10,
      simplePaybackYears: Math.round(simplePaybackYears * 10) / 10,
      discountedPaybackYears: Math.round((simplePaybackYears * 1.25) * 10) / 10,
      co2EmissionsAvoidedTonsPerYear: Math.round(co2TonsPerYear)
    };
  }

  /**
   * Generates Hardware-In-The-Loop CAN 2.0B / CAN-FD DBC messages for BMS integration
   */
  public generateCanDbcMessages(): HilCanMessage[] {
    return [
      {
        idHex: '0x1806E5F4',
        name: 'BMS_PackSummary',
        cycleTimeMs: 10,
        signals: [
          { name: 'Pack_Voltage', startBit: 0, length: 16, factor: 0.1, offset: 0, unit: 'V', currentValue: 384.2 },
          { name: 'Pack_Current', startBit: 16, length: 16, factor: 0.1, offset: -1000, unit: 'A', currentValue: -45.0 },
          { name: 'Pack_SOC', startBit: 32, length: 8, factor: 0.5, offset: 0, unit: '%', currentValue: 88.5 },
          { name: 'Pack_SOH', startBit: 40, length: 8, factor: 0.5, offset: 0, unit: '%', currentValue: 99.0 },
          { name: 'BMS_Operating_State', startBit: 48, length: 4, factor: 1.0, offset: 0, unit: 'enum', currentValue: 3 },
          { name: 'Heartbeat_Counter', startBit: 52, length: 4, factor: 1.0, offset: 0, unit: 'cnt', currentValue: 7 }
        ]
      },
      {
        idHex: '0x1807E5F4',
        name: 'BMS_CellExtremes',
        cycleTimeMs: 20,
        signals: [
          { name: 'Max_Cell_Voltage', startBit: 0, length: 16, factor: 0.001, offset: 0, unit: 'V', currentValue: 3.284 },
          { name: 'Min_Cell_Voltage', startBit: 16, length: 16, factor: 0.001, offset: 0, unit: 'V', currentValue: 3.242 },
          { name: 'Max_Cell_Temperature', startBit: 32, length: 8, factor: 1.0, offset: -40, unit: '°C', currentValue: 28.5 },
          { name: 'Min_Cell_Temperature', startBit: 40, length: 8, factor: 1.0, offset: -40, unit: '°C', currentValue: 24.1 },
          { name: 'Max_Cell_V_Index', startBit: 48, length: 8, factor: 1.0, offset: 0, unit: 'idx', currentValue: 14 },
          { name: 'Min_Cell_V_Index', startBit: 56, length: 8, factor: 1.0, offset: 0, unit: 'idx', currentValue: 82 }
        ]
      },
      {
        idHex: '0x1808E5F4',
        name: 'BMS_SafetyAlarms',
        cycleTimeMs: 10,
        signals: [
          { name: 'Alarm_OverVoltage', startBit: 0, length: 1, factor: 1, offset: 0, unit: 'bit', currentValue: 0 },
          { name: 'Alarm_UnderVoltage', startBit: 1, length: 1, factor: 1, offset: 0, unit: 'bit', currentValue: 0 },
          { name: 'Alarm_OverTemp', startBit: 2, length: 1, factor: 1, offset: 0, unit: 'bit', currentValue: 0 },
          { name: 'Alarm_IsolationFault', startBit: 3, length: 1, factor: 1, offset: 0, unit: 'bit', currentValue: 0 },
          { name: 'Contactor_MainPos', startBit: 4, length: 1, factor: 1, offset: 0, unit: 'bit', currentValue: 1 },
          { name: 'Contactor_MainNeg', startBit: 5, length: 1, factor: 1, offset: 0, unit: 'bit', currentValue: 1 },
          { name: 'Contactor_Precharge', startBit: 6, length: 1, factor: 1, offset: 0, unit: 'bit', currentValue: 0 },
          { name: 'Interlock_EmergencyStop', startBit: 7, length: 1, factor: 1, offset: 0, unit: 'bit', currentValue: 0 }
        ]
      },
      {
        idHex: '0x1809E5F4',
        name: 'BMS_ThermalCooling',
        cycleTimeMs: 50,
        signals: [
          { name: 'Coolant_Inlet_Temp', startBit: 0, length: 8, factor: 0.5, offset: -40, unit: '°C', currentValue: 22.0 },
          { name: 'Coolant_Outlet_Temp', startBit: 8, length: 8, factor: 0.5, offset: -40, unit: '°C', currentValue: 24.8 },
          { name: 'Coolant_Flow_Rate', startBit: 16, length: 8, factor: 0.1, offset: 0, unit: 'L/min', currentValue: 12.5 },
          { name: 'Total_Thermal_Loss', startBit: 24, length: 16, factor: 1.0, offset: 0, unit: 'W', currentValue: 680 }
        ]
      }
    ];
  }

  /**
   * Generates Modbus TCP Register Map for Industrial BESS Integration
   */
  public generateModbusRegisters(): ModbusRegister[] {
    return [
      { address: 30001, name: 'BMS_SYSTEM_STATE', type: 'UINT16', unit: '-', scale: 1, access: 'RO', value: 3 },
      { address: 30002, name: 'DC_BUS_VOLTAGE', type: 'UINT16', unit: '0.1 V', scale: 0.1, access: 'RO', value: '384.2 V' },
      { address: 30003, name: 'DC_BUS_CURRENT', type: 'INT16', unit: '0.1 A', scale: 0.1, access: 'RO', value: '-45.0 A' },
      { address: 30004, name: 'ACTIVE_POWER_KW', type: 'INT16', unit: '0.1 kW', scale: 0.1, access: 'RO', value: '-17.3 kW' },
      { address: 30005, name: 'SYSTEM_SOC', type: 'UINT16', unit: '0.1 %', scale: 0.1, access: 'RO', value: '88.5 %' },
      { address: 30006, name: 'SYSTEM_SOH', type: 'UINT16', unit: '0.1 %', scale: 0.1, access: 'RO', value: '99.0 %' },
      { address: 30007, name: 'MAX_CELL_VOLTAGE', type: 'UINT16', unit: '1 mV', scale: 0.001, access: 'RO', value: '3284 mV' },
      { address: 30008, name: 'MIN_CELL_VOLTAGE', type: 'UINT16', unit: '1 mV', scale: 0.001, access: 'RO', value: '3242 mV' },
      { address: 30009, name: 'MAX_CELL_TEMP', type: 'INT16', unit: '0.1 °C', scale: 0.1, access: 'RO', value: '28.5 °C' },
      { address: 30010, name: 'MIN_CELL_TEMP', type: 'INT16', unit: '0.1 °C', scale: 0.1, access: 'RO', value: '24.1 °C' },
      { address: 40001, name: 'REMOTE_COMMAND_CONTROL', type: 'UINT16', unit: 'bitmask', scale: 1, access: 'RW', value: '0x0001 (ENABLE)' },
      { address: 40002, name: 'CHARGE_POWER_LIMIT_KW', type: 'UINT16', unit: '1 kW', scale: 1, access: 'RW', value: '250 kW' },
      { address: 40003, name: 'DISCHARGE_POWER_LIMIT_KW', type: 'UINT16', unit: '1 kW', scale: 1, access: 'RW', value: '350 kW' },
      { address: 40004, name: 'WATCHDOG_HEARTBEAT_SEC', type: 'UINT16', unit: 'sec', scale: 1, access: 'RW', value: '5 s' }
    ];
  }
}
