import { BatteryChemistryType, CellFormatType, ChemistryProperties, CellFormatProperties, OcvSocCurvePoint } from './battery.models';

export const CHEMISTRIES: Record<BatteryChemistryType, ChemistryProperties> = {
  LFP: {
    type: 'LFP',
    name: 'Lithium Iron Phosphate',
    chemicalFormula: 'LiFePO₄ / Graphite',
    nominalVoltage: 3.20,
    maxVoltage: 3.65,
    minVoltage: 2.50,
    specificEnergy: 165, // Wh/kg
    energyDensity: 320, // Wh/L
    maxContinuousCrate: 3.0,
    maxPulseCrate: 6.0,
    maxFastChargeCrate: 1.5,
    cycleLife80Pct: 4500,
    criticalTemp: 270, // °C
    dEdT: -0.00012, // V/K
    baseResistance: 0.85, // mΩ
    diffusionCoeffRef: 1.2e-14, // m²/s
    activationEnergy: 35000, // J/mol
    description: 'Flat 3.2V plateau with exceptional thermal stability, non-toxic olive crystal structure, and superior 4000+ cycle life. Ideal for ESS and safety-critical mobility.',
    colorHex: '#408060'
  },
  NMC811: {
    type: 'NMC811',
    name: 'Nickel Manganese Cobalt (8:1:1)',
    chemicalFormula: 'LiNi₀.₈Mn₀.₁Co₀.₁O₂ / Graphite-Si',
    nominalVoltage: 3.70,
    maxVoltage: 4.20,
    minVoltage: 2.80,
    specificEnergy: 275, // Wh/kg
    energyDensity: 700, // Wh/L
    maxContinuousCrate: 2.0,
    maxPulseCrate: 4.5,
    maxFastChargeCrate: 2.5,
    cycleLife80Pct: 1800,
    criticalTemp: 210, // °C
    dEdT: -0.00028, // V/K
    baseResistance: 1.15, // mΩ
    diffusionCoeffRef: 2.5e-14, // m²/s
    activationEnergy: 42000, // J/mol
    description: 'Ultra-high energy density chemistry for long-range EV applications. Requires precise thermal management to mitigate oxygen release during high-temperature overcharge.',
    colorHex: '#357595'
  },
  NMC622: {
    type: 'NMC622',
    name: 'Nickel Manganese Cobalt (6:2:2)',
    chemicalFormula: 'LiNi₀.₆Mn₀.₂Co₀.₂O₂ / Graphite',
    nominalVoltage: 3.65,
    maxVoltage: 4.20,
    minVoltage: 2.80,
    specificEnergy: 235, // Wh/kg
    energyDensity: 580, // Wh/L
    maxContinuousCrate: 2.5,
    maxPulseCrate: 5.0,
    maxFastChargeCrate: 2.0,
    cycleLife80Pct: 2400,
    criticalTemp: 235, // °C
    dEdT: -0.00024, // V/K
    baseResistance: 1.05, // mΩ
    diffusionCoeffRef: 2.0e-14, // m²/s
    activationEnergy: 39000, // J/mol
    description: 'Balanced performance offering higher cycle life and thermal stability than 811 while maintaining strong gravimetric energy density.',
    colorHex: '#486888'
  },
  NCA: {
    type: 'NCA',
    name: 'Nickel Cobalt Aluminium',
    chemicalFormula: 'LiNi₀.₈Co₀.₁₅Al₀.₀₅O₂ / C-SiOx',
    nominalVoltage: 3.65,
    maxVoltage: 4.20,
    minVoltage: 2.75,
    specificEnergy: 285, // Wh/kg
    energyDensity: 720, // Wh/L
    maxContinuousCrate: 3.0,
    maxPulseCrate: 6.5,
    maxFastChargeCrate: 2.2,
    cycleLife80Pct: 1600,
    criticalTemp: 195, // °C
    dEdT: -0.00030, // V/K
    baseResistance: 0.95, // mΩ
    diffusionCoeffRef: 3.0e-14, // m²/s
    activationEnergy: 44000, // J/mol
    description: 'High power and high specific energy. Premium automotive chemistry with rapid charge capabilities and steep voltage-to-SOC slope.',
    colorHex: '#7B5E99'
  },
  LTO: {
    type: 'LTO',
    name: 'Lithium Titanate',
    chemicalFormula: 'Li₄Ti₅O₁₂ / LiMn₂O₄',
    nominalVoltage: 2.40,
    maxVoltage: 2.85,
    minVoltage: 1.50,
    specificEnergy: 95, // Wh/kg
    energyDensity: 200, // Wh/L
    maxContinuousCrate: 10.0,
    maxPulseCrate: 25.0,
    maxFastChargeCrate: 6.0,
    cycleLife80Pct: 20000,
    criticalTemp: 340, // °C
    dEdT: +0.00008, // V/K
    baseResistance: 0.45, // mΩ
    diffusionCoeffRef: 8.0e-14, // m²/s
    activationEnergy: 28000, // J/mol
    description: 'Zero-strain spinel anode preventing lithium plating even at sub-zero temperatures. Capable of 10C continuous fast charge and >20,000 cycles.',
    colorHex: '#A27038'
  },
  SODIUM_ION: {
    type: 'SODIUM_ION',
    name: 'Sodium-ion (Prussian Blue / Hard Carbon)',
    chemicalFormula: 'Na₃V₂(PO₄)₃ / Hard Carbon',
    nominalVoltage: 3.10,
    maxVoltage: 3.90,
    minVoltage: 2.00,
    specificEnergy: 155, // Wh/kg
    energyDensity: 290, // Wh/L
    maxContinuousCrate: 3.0,
    maxPulseCrate: 7.0,
    maxFastChargeCrate: 3.0,
    cycleLife80Pct: 3500,
    criticalTemp: 290, // °C
    dEdT: -0.00018, // V/K
    baseResistance: 1.30, // mΩ
    diffusionCoeffRef: 0.9e-14, // m²/s
    activationEnergy: 34000, // J/mol
    description: 'Earth-abundant sodium chemistry free of lithium, nickel, and cobalt. Low supply-chain risk and zero-volt deep discharge transport capability.',
    colorHex: '#388878'
  }
};

export const CELL_FORMATS: Record<CellFormatType, CellFormatProperties> = {
  CYLINDRICAL_21700: {
    format: 'CYLINDRICAL_21700',
    name: '21700 Cylindrical (21mm × 70mm)',
    defaultCapacityAh: 5.0,
    weightGrams: 70,
    lengthMm: 21,
    widthMm: 21,
    heightMm: 70,
    thermalConductivityRadial: 0.9, // W/(m·K)
    thermalConductivityAxial: 32.0, // W/(m·K)
    heatCapacity: 920 // J/(kg·K)
  },
  CYLINDRICAL_4680: {
    format: 'CYLINDRICAL_4680',
    name: '4680 Cylindrical (46mm × 80mm Tabless)',
    defaultCapacityAh: 26.0,
    weightGrams: 355,
    lengthMm: 46,
    widthMm: 46,
    heightMm: 80,
    thermalConductivityRadial: 1.2,
    thermalConductivityAxial: 45.0,
    heatCapacity: 940
  },
  PRISMATIC: {
    format: 'PRISMATIC',
    name: 'Prismatic (148mm × 27mm × 91mm)',
    defaultCapacityAh: 105.0,
    weightGrams: 1850,
    lengthMm: 148,
    widthMm: 27,
    heightMm: 91,
    thermalConductivityRadial: 1.4,
    thermalConductivityAxial: 28.0,
    heatCapacity: 910
  },
  POUCH: {
    format: 'POUCH',
    name: 'Pouch Cell (200mm × 100mm × 8mm)',
    defaultCapacityAh: 62.0,
    weightGrams: 890,
    lengthMm: 200,
    widthMm: 100,
    heightMm: 8,
    thermalConductivityRadial: 1.8,
    thermalConductivityAxial: 35.0,
    heatCapacity: 930
  }
};

/**
 * Calculates open circuit voltage V_oc from state of charge (0.0 to 1.0)
 * utilizing scientifically validated empirical curves for each chemistry.
 */
export function calculateOcv(chemistry: BatteryChemistryType, soc: number): number {
  const s = Math.max(0.001, Math.min(0.999, soc));
  
  switch (chemistry) {
    case 'LFP':
      // Distinctive two-phase flat plateau at ~3.25V with steep knee below 10% and rapid rise above 90%
      return 2.50 + 0.65 * Math.pow(s, 0.15) 
        + 0.12 * Math.tanh(18 * (s - 0.5)) 
        + 0.08 * Math.pow(s, 8) 
        - 0.35 * Math.exp(-35 * s)
        + 0.28 * Math.exp(40 * (s - 1.0));
      
    case 'NMC811':
      // Continuous sloping OCV profile reflecting solid-solution intercalation into layered oxide
      return 3.00 + 0.95 * s 
        + 0.15 * Math.pow(s, 2) 
        - 0.25 * Math.exp(-25 * s) 
        + 0.22 * Math.exp(30 * (s - 1.0))
        - 0.04 * Math.sin(Math.PI * s);

    case 'NMC622':
      return 3.05 + 0.90 * s 
        + 0.12 * Math.pow(s, 2) 
        - 0.28 * Math.exp(-25 * s) 
        + 0.20 * Math.exp(30 * (s - 1.0));

    case 'NCA':
      return 2.98 + 1.02 * s 
        + 0.14 * Math.pow(s, 2.5) 
        - 0.30 * Math.exp(-22 * s) 
        + 0.24 * Math.exp(32 * (s - 1.0));

    case 'LTO':
      // Ultra-flat 1.55V anode plateau resulting in 2.40V nominal cell voltage
      return 1.65 + 0.68 * Math.pow(s, 0.2) 
        + 0.10 * Math.tanh(12 * (s - 0.5))
        - 0.22 * Math.exp(-30 * s)
        + 0.35 * Math.exp(35 * (s - 1.0));

    case 'SODIUM_ION':
      // Sodium insertion profile with multiple step transitions in Prussian blue / Hard carbon
      return 2.10 + 1.25 * s 
        + 0.10 * Math.sin(2 * Math.PI * s)
        - 0.25 * Math.exp(-20 * s)
        + 0.30 * Math.exp(25 * (s - 1.0));
  }
}

/**
 * Generate full OCV-SOC and differential capacity dQ/dV curve data for plotting
 */
export function generateOcvSocCurve(chemistry: BatteryChemistryType, pointsCount = 100): OcvSocCurvePoint[] {
  const points: OcvSocCurvePoint[] = [];
  const dSoc = 1.0 / pointsCount;
  
  for (let i = 0; i <= pointsCount; i++) {
    const soc = i * dSoc;
    const ocv = calculateOcv(chemistry, soc);
    
    // Numerical derivative dOCV/dSOC
    const delta = 0.005;
    const ocvPlus = calculateOcv(chemistry, Math.min(0.999, soc + delta));
    const ocvMinus = calculateOcv(chemistry, Math.max(0.001, soc - delta));
    const dOcvDsoc = (ocvPlus - ocvMinus) / (2 * delta);
    
    // Differential capacity dQ/dV = (dQ/dSOC) / (dV/dSOC) = Q_nom / (dOCV/dSOC)
    const dQdV = dOcvDsoc > 0.01 ? (1.0 / dOcvDsoc) : 0;
    
    points.push({ soc, ocv, dOcvDsoc, dQdV });
  }
  return points;
}
