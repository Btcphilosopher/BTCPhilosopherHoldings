export type BatteryChemistryType = 'LFP' | 'NMC811' | 'NMC622' | 'NCA' | 'LTO' | 'SODIUM_ION';
export type CellFormatType = 'CYLINDRICAL_21700' | 'CYLINDRICAL_4680' | 'PRISMATIC' | 'POUCH';
export type SimulationFidelity = 'LEVEL_1_ECM' | 'LEVEL_2_SPM' | 'LEVEL_3_SPME' | 'LEVEL_4_DFN';
export type CoolingType = 'LIQUID' | 'FORCED_AIR' | 'IMMERSION' | 'PASSIVE';
export type VisualisationMode = 'REALISTIC' | 'ELECTRICAL' | 'THERMAL' | 'SOC' | 'SOH' | 'COOLING' | 'FAULT';
export type BMSState = 'INITIALIZATION' | 'STANDBY' | 'CHARGING' | 'DISCHARGING' | 'BALANCING' | 'FAULT' | 'SAFE_SHUTDOWN';

export interface ChemistryProperties {
  type: BatteryChemistryType;
  name: string;
  chemicalFormula: string;
  nominalVoltage: number; // V
  maxVoltage: number; // V
  minVoltage: number; // V
  specificEnergy: number; // Wh/kg
  energyDensity: number; // Wh/L
  maxContinuousCrate: number; // C
  maxPulseCrate: number; // C
  maxFastChargeCrate: number; // C
  cycleLife80Pct: number; // cycles
  criticalTemp: number; // °C (thermal runaway trigger threshold)
  dEdT: number; // V/K entropic coefficient
  baseResistance: number; // mΩ (for reference 1C)
  diffusionCoeffRef: number; // m²/s
  activationEnergy: number; // J/mol (Arrhenius)
  description: string;
  colorHex: string;
}

export interface CellFormatProperties {
  format: CellFormatType;
  name: string;
  defaultCapacityAh: number;
  weightGrams: number;
  lengthMm: number;
  widthMm: number; // or diameter for cylindrical
  heightMm: number;
  thermalConductivityRadial: number; // W/(m·K)
  thermalConductivityAxial: number; // W/(m·K)
  heatCapacity: number; // J/(kg·K)
}

export interface PackConfiguration {
  chemistry: BatteryChemistryType;
  format: CellFormatType;
  seriesCount: number; // e.g. 96
  parallelCount: number; // e.g. 4
  cellCapacityAh: number;
  cellResistanceMOhms: number;
  cellMismatchPct: number; // Gaussian variance in capacity & resistance
  coolingType: CoolingType;
  coolantInletTempC: number;
  coolantFlowRateLpm: number;
  ambientTempC: number;
  fidelity: SimulationFidelity;
}

export interface CellState {
  id: string;
  seriesIdx: number;
  parallelIdx: number;
  moduleIdx: number;
  x: number;
  y: number;
  z: number;
  voltage: number; // V
  current: number; // A (positive = discharge, negative = charge)
  temperature: number; // °C
  soc: number; // 0.0 - 1.0 (State of Charge)
  soh: number; // 0.0 - 1.0 (State of Health)
  capacityAh: number; // actual usable Ah
  nominalCapacityAh: number;
  internalResistanceMOhms: number;
  etaOhmic: number; // V
  etaChargeTransfer: number; // V
  etaDiffusion: number; // V
  qJoule: number; // W heat
  qRev: number; // W heat
  qTotal: number; // W
  balancingActive: boolean;
  seiThicknessNm: number;
  lossOfLithiumPct: number;
  faultFlags: {
    overVoltage: boolean;
    underVoltage: boolean;
    overTemperature: boolean;
    highImbalance: boolean;
    thermalRunawayRisk: boolean;
  };
}

export interface PackTelemetry {
  packVoltage: number; // V
  packCurrent: number; // A (negative = charge, positive = discharge)
  packPowerKw: number; // kW
  socPct: number; // %
  sohPct: number; // %
  avgTemperatureC: number;
  maxTemperatureC: number;
  minTemperatureC: number;
  maxCellVoltage: number;
  minCellVoltage: number;
  voltageImbalanceMv: number;
  nominalEnergyKwh: number;
  usableEnergyKwh: number;
  deliveredEnergyKwh: number;
  totalResistanceMOhms: number;
  powerLossKw: number;
  efficiencyPct: number;
  coolantTempOutC: number;
  bmsState: BMSState;
  contactors: {
    mainPositive: boolean;
    mainNegative: boolean;
    precharge: boolean;
    auxiliary: boolean;
  };
  alarms: string[];
}

export interface SimulationStepResult {
  timestampSec: number;
  telemetry: PackTelemetry;
  cells: CellState[];
}

export interface OcvSocCurvePoint {
  soc: number;
  ocv: number;
  dOcvDsoc: number;
  dQdV: number;
}

export interface DegradationForecastPoint {
  cycle: number;
  years: number;
  capacityRetentionPct: number;
  capacityRetentionUpperPct: number;
  capacityRetentionLowerPct: number;
  resistanceIncreasePct: number;
  seiThicknessNm: number;
  sohPct: number;
}

export interface BessSolarDataPoint {
  hour: number;
  solarGenerationKw: number;
  facilityDemandKw: number;
  batteryChargeKw: number;
  batteryDischargeKw: number;
  gridImportKw: number;
  gridExportKw: number;
  curtailmentKw: number;
  socPct: number;
  electricityPricePerKwh: number;
}

export interface EconomicAnalysisResult {
  capexUsd: number;
  opexAnnualUsd: number;
  costPerUsableKwh: number;
  lcosPerMwh: number;
  annualArbitrageSavingsUsd: number;
  annualPeakShavingSavingsUsd: number;
  totalAnnualBenefitUsd: number;
  netPresentValueUsd: number;
  internalRateOfReturnPct: number;
  simplePaybackYears: number;
  discountedPaybackYears: number;
  co2EmissionsAvoidedTonsPerYear: number;
}

export interface HilCanMessage {
  idHex: string;
  name: string;
  cycleTimeMs: number;
  signals: {
    name: string;
    startBit: number;
    length: number;
    factor: number;
    offset: number;
    unit: string;
    currentValue: number;
  }[];
}

export interface ModbusRegister {
  address: number;
  name: string;
  type: 'INT16' | 'UINT16' | 'FLOAT32' | 'BOOLEAN';
  unit: string;
  scale: number;
  access: 'RO' | 'RW';
  value: string | number;
}
