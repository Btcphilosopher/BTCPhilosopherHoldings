import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  OnDestroy,
  computed,
  signal,
  inject
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';
import { BatteryViewport } from './components/battery-viewport/battery-viewport';
import { 
  BatteryChemistryType, 
  CellFormatType, 
  SimulationFidelity, 
  CoolingType, 
  VisualisationMode, 
  BMSState, 
  CellState, 
  PackConfiguration, 
  PackTelemetry, 
  OcvSocCurvePoint,
  DegradationForecastPoint,
  EconomicAnalysisResult,
  HilCanMessage,
  ModbusRegister
} from './models/battery.models';
import { CHEMISTRIES, CELL_FORMATS, generateOcvSocCurve } from './models/chemistry-database';
import { ElectrochemEngine } from './services/electrochem-engine.service';
import { DegradationEngine, MonteCarloFleetResult } from './services/degradation-engine.service';
import { BessSolarService, DispatchStrategy, BessSimulationOutput } from './services/bess-solar.service';
import { EconomicsHilService, EconomicsInputParams } from './services/economics-hil.service';

export type WorkstationTab = 'TWIN' | 'ELECTROCHEM' | 'BMS' | 'DEGRADATION' | 'BESS_SOLAR' | 'ECONOMICS_HIL' | 'AI_DIAGNOSTICS';
export type LoadScenarioPreset = 'CONSTANT_1C_DISCHARGE' | 'FAST_CHARGE_2C' | 'WLTP_DRIVE_CYCLE' | 'HEAVY_PEAK_PULSE' | 'GRID_ARBITRAGE' | 'THERMAL_OVERCHARGE';

@Component({
  selector: 'app-root',
  imports: [CommonModule, MatIconModule, BatteryViewport],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit, OnDestroy {
  private http = inject(HttpClient);
  private electrochemEngine = inject(ElectrochemEngine);
  private degradationEngine = inject(DegradationEngine);
  private bessSolarService = inject(BessSolarService);
  private economicsHilService = inject(EconomicsHilService);

  // Workstation Tab
  public currentTab = signal<WorkstationTab>('TWIN');

  // Pack Configuration Signals
  public selectedChemistry = signal<BatteryChemistryType>('LFP');
  public selectedFormat = signal<CellFormatType>('CYLINDRICAL_21700');
  public seriesCount = signal<number>(96); // e.g. 96S
  public parallelCount = signal<number>(4); // e.g. 4P (total 384 cells)
  public cellCapacityAh = signal<number>(5.0);
  public cellResistanceMOhms = signal<number>(0.85);
  public cellMismatchPct = signal<number>(1.5);
  public coolingType = signal<CoolingType>('LIQUID');
  public coolantInletTempC = signal<number>(22.0);
  public coolantFlowRateLpm = signal<number>(12.0);
  public ambientTempC = signal<number>(25.0);
  public fidelity = signal<SimulationFidelity>('LEVEL_3_SPME');

  // Simulation Controls & Telemetry
  public isRunning = signal<boolean>(true);
  public simSpeed = signal<number>(1); // 1x, 5x, 20x, 60x
  public simTimeSec = signal<number>(240); // Elapsed simulation seconds
  public currentLoadScenario = signal<LoadScenarioPreset>('CONSTANT_1C_DISCHARGE');
  public appliedCurrentA = signal<number>(50.0); // positive = discharge, negative = charge
  public bmsState = signal<BMSState>('DISCHARGING');

  // 3D Viewport Controls
  public visualMode = signal<VisualisationMode>('REALISTIC');
  public explodedRatio = signal<number>(0.0);
  public inspectedCell = signal<CellState | null>(null);

  // Live Multiphysics State
  public cells = signal<CellState[]>([]);
  public telemetry = signal<PackTelemetry>({
    packVoltage: 307.2,
    packCurrent: 50.0,
    packPowerKw: 15.36,
    socPct: 84.5,
    sohPct: 99.2,
    avgTemperatureC: 27.8,
    maxTemperatureC: 29.4,
    minTemperatureC: 25.1,
    maxCellVoltage: 3.245,
    minCellVoltage: 3.208,
    voltageImbalanceMv: 37.0,
    nominalEnergyKwh: 61.44,
    usableEnergyKwh: 51.5,
    deliveredEnergyKwh: 12.8,
    totalResistanceMOhms: 20.4,
    powerLossKw: 0.051,
    efficiencyPct: 98.2,
    coolantTempOutC: 23.4,
    bmsState: 'DISCHARGING',
    contactors: {
      mainPositive: true,
      mainNegative: true,
      precharge: false,
      auxiliary: true
    },
    alarms: []
  });

  // Secondary Data Signals
  public ocvSocCurve = signal<OcvSocCurvePoint[]>([]);
  public degradationPoints = signal<DegradationForecastPoint[]>([]);
  public fleetMonteCarlo = signal<MonteCarloFleetResult | null>(null);
  public bessSolarResult = signal<BessSimulationOutput | null>(null);
  public bessDispatchStrategy = signal<DispatchStrategy>('TOU_ARBITRAGE');
  public economicsResult = signal<EconomicAnalysisResult | null>(null);
  public canDbcMessages = signal<HilCanMessage[]>([]);
  public modbusRegisters = signal<ModbusRegister[]>([]);

  // AI Diagnostic Advisory Signals
  public aiReport = signal<string>('');
  public isAiLoading = signal<boolean>(false);
  public customAiPrompt = signal<string>('');

  // Computed helper properties
  public chemistryInfo = computed(() => CHEMISTRIES[this.selectedChemistry()]);
  public formatInfo = computed(() => CELL_FORMATS[this.selectedFormat()]);
  public ekfState = computed(() => this.electrochemEngine.getEkfState(0));

  // Computed SVG Polyline strings for templates (no arrow functions in templates)
  public ocvPointsString = computed(() => {
    const chem = this.chemistryInfo();
    const span = Math.max(0.1, chem.maxVoltage - chem.minVoltage);
    return this.ocvSocCurve().map(p => {
      const x = p.soc * 100;
      const y = 100 - (((p.ocv - chem.minVoltage) / span) * 85 + 5);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');
  });

  public operatingPointY = computed(() => {
    const chem = this.chemistryInfo();
    const span = Math.max(0.1, chem.maxVoltage - chem.minVoltage);
    return 100 - (((this.telemetry().maxCellVoltage - chem.minVoltage) / span) * 85 + 5);
  });

  public dqdvPointsString = computed(() => {
    const chem = this.chemistryInfo();
    const span = Math.max(0.1, chem.maxVoltage - chem.minVoltage);
    return this.ocvSocCurve().map(p => {
      const x = ((p.ocv - chem.minVoltage) / span) * 100;
      const y = Math.max(5, Math.min(95, 100 - (p.dQdV * 18)));
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');
  });

  public degradationMedianPointsString = computed(() => {
    return this.degradationPoints().map(p => {
      const x = p.cycle / 40;
      const y = 100 - (p.capacityRetentionPct - 60) * 2.5;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');
  });

  public degradationFanPolygonString = computed(() => {
    const pts = this.degradationPoints();
    const upper = pts.map(p => `${(p.cycle / 40).toFixed(1)},${(100 - (p.capacityRetentionUpperPct - 60) * 2.5).toFixed(1)}`).join(' ');
    const lower = pts.slice().reverse().map(p => `${(p.cycle / 40).toFixed(1)},${(100 - (p.capacityRetentionLowerPct - 60) * 2.5).toFixed(1)}`).join(' ');
    return `${upper} ${lower}`;
  });

  public solarPointsString = computed(() => {
    const res = this.bessSolarResult();
    if (!res || !res.data) return '';
    return res.data.map(d => `${d.hour},${(1000 - d.solarGenerationKw * 0.75).toFixed(1)}`).join(' ');
  });

  public demandPointsString = computed(() => {
    const res = this.bessSolarResult();
    if (!res || !res.data) return '';
    return res.data.map(d => `${d.hour},${(1000 - d.facilityDemandKw * 0.75).toFixed(1)}`).join(' ');
  });

  public batteryDischargePointsString = computed(() => {
    const res = this.bessSolarResult();
    if (!res || !res.data) return '';
    return res.data.map(d => `${d.hour},${(1000 - d.batteryDischargeKw * 0.75).toFixed(1)}`).join(' ');
  });

  private timerInterval: ReturnType<typeof setInterval> | null = null;

  ngOnInit(): void {
    this.reinitializePack();
    this.generateAuxiliaryData();
    this.startSimulationClock();
  }

  ngOnDestroy(): void {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
    }
  }

  public reinitializePack(): void {
    const config: PackConfiguration = {
      chemistry: this.selectedChemistry(),
      format: this.selectedFormat(),
      seriesCount: this.seriesCount(),
      parallelCount: this.parallelCount(),
      cellCapacityAh: this.cellCapacityAh(),
      cellResistanceMOhms: this.cellResistanceMOhms(),
      cellMismatchPct: this.cellMismatchPct(),
      coolingType: this.coolingType(),
      coolantInletTempC: this.coolantInletTempC(),
      coolantFlowRateLpm: this.coolantFlowRateLpm(),
      ambientTempC: this.ambientTempC(),
      fidelity: this.fidelity()
    };

    const initialCells = this.electrochemEngine.initializePack(config);
    this.cells.set([...initialCells]);
    this.stepPhysics(0.1);
  }

  public generateAuxiliaryData(): void {
    // 1. OCV-SOC Curve
    this.ocvSocCurve.set(generateOcvSocCurve(this.selectedChemistry(), 60));

    // 2. Degradation & Monte Carlo
    this.degradationPoints.set(
      this.degradationEngine.forecastDegradation(this.selectedChemistry(), 365, 80, 1.0, 28, 60, 4000)
    );
    this.fleetMonteCarlo.set(
      this.degradationEngine.runMonteCarloFleet(this.selectedChemistry(), 250, 4500)
    );

    // 3. BESS Solar Dispatch
    this.bessSolarResult.set(
      this.bessSolarService.simulate24HourDispatch(this.bessDispatchStrategy())
    );

    // 4. Economics & HIL
    const econParams: EconomicsInputParams = {
      storageCapacityKwh: (this.seriesCount() * this.parallelCount() * this.cellCapacityAh() * this.chemistryInfo().nominalVoltage) / 1000.0 * 20.0, // Scale to commercial BESS
      inverterPowerKw: 1000,
      cellCostPerKwhUsd: this.selectedChemistry() === 'LFP' ? 68 : this.selectedChemistry() === 'SODIUM_ION' ? 52 : 95,
      bopCostPerKwhUsd: 45,
      inverterCostPerKwUsd: 85,
      epcInstallationPct: 18,
      annualOpexPerKwUsd: 12,
      cyclesPerDay: 1.2,
      discountRatePct: 7.5,
      projectLifeYears: 15,
      electricityPurchasePriceUsdKwh: 0.09,
      peakDemandChargeUsdPerKwMonth: 22.0,
      chemistry: this.selectedChemistry()
    };
    this.economicsResult.set(this.economicsHilService.calculateEconomics(econParams));
    this.canDbcMessages.set(this.economicsHilService.generateCanDbcMessages());
    this.modbusRegisters.set(this.economicsHilService.generateModbusRegisters());
  }

  private startSimulationClock(): void {
    if (this.timerInterval) clearInterval(this.timerInterval);

    // Advance physics at 10Hz tick
    this.timerInterval = setInterval(() => {
      if (this.isRunning()) {
        const dt = 0.1 * this.simSpeed();
        this.simTimeSec.update(t => t + dt);
        this.stepPhysics(dt);
      }
    }, 100);
  }

  private stepPhysics(dtSec: number): void {
    const config: PackConfiguration = {
      chemistry: this.selectedChemistry(),
      format: this.selectedFormat(),
      seriesCount: this.seriesCount(),
      parallelCount: this.parallelCount(),
      cellCapacityAh: this.cellCapacityAh(),
      cellResistanceMOhms: this.cellResistanceMOhms(),
      cellMismatchPct: this.cellMismatchPct(),
      coolingType: this.coolingType(),
      coolantInletTempC: this.coolantInletTempC(),
      coolantFlowRateLpm: this.coolantFlowRateLpm(),
      ambientTempC: this.ambientTempC(),
      fidelity: this.fidelity()
    };

    // Calculate applied current based on active scenario
    let currentA = this.appliedCurrentA();
    switch (this.currentLoadScenario()) {
      case 'CONSTANT_1C_DISCHARGE':
        currentA = config.cellCapacityAh * config.parallelCount; // 1C discharge
        this.bmsState.set('DISCHARGING');
        break;

      case 'FAST_CHARGE_2C':
        currentA = -config.cellCapacityAh * config.parallelCount * 2.0; // 2C charge (negative)
        this.bmsState.set('CHARGING');
        break;

      case 'WLTP_DRIVE_CYCLE': {
        // Dynamic drive cycle profile with regenerative braking
        const phase = (this.simTimeSec() % 120) / 120.0;
        const speedKph = Math.max(0, 110 * Math.sin(phase * Math.PI) + 20 * Math.sin(phase * 6 * Math.PI));
        const powerDemand = (speedKph * 1.2) - (phase > 0.75 ? 40 : 0);
        currentA = (powerDemand * 1000.0) / Math.max(100, this.telemetry().packVoltage);
        this.bmsState.set(currentA >= 0 ? 'DISCHARGING' : 'CHARGING');
        break;
      }

      case 'HEAVY_PEAK_PULSE': {
        const pulse = Math.floor(this.simTimeSec() / 10) % 2 === 0;
        currentA = pulse ? config.cellCapacityAh * config.parallelCount * 3.5 : 5.0;
        this.bmsState.set('DISCHARGING');
        break;
      }

      case 'GRID_ARBITRAGE': {
        // Alternating charge/discharge for energy arbitrage
        const hourEquivalent = Math.floor(this.simTimeSec() / 30) % 24;
        currentA = (hourEquivalent >= 0 && hourEquivalent < 6) ? -40.0 : (hourEquivalent >= 16 && hourEquivalent <= 21) ? 65.0 : 0.0;
        this.bmsState.set(currentA < 0 ? 'CHARGING' : currentA > 0 ? 'DISCHARGING' : 'STANDBY');
        break;
      }

      case 'THERMAL_OVERCHARGE':
        currentA = -config.cellCapacityAh * config.parallelCount * 3.0; // Severe overcharge stressing thermal runaway
        this.bmsState.set('CHARGING');
        break;
    }
    this.appliedCurrentA.set(currentA);

    const result = this.electrochemEngine.stepSimulation(
      config,
      currentA,
      dtSec,
      this.bmsState(),
      this.ambientTempC(),
      this.coolantInletTempC(),
      this.coolantFlowRateLpm()
    );

    this.cells.set([...result.cells]);
    this.telemetry.set(result.telemetry);

    // If a cell is currently inspected in modal, refresh its reference
    const currentInspected = this.inspectedCell();
    if (currentInspected) {
      const updated = result.cells.find(c => c.id === currentInspected.id);
      if (updated) this.inspectedCell.set(updated);
    }
  }

  // UI Event Handlers
  public setTab(tab: WorkstationTab): void {
    this.currentTab.set(tab);
  }

  public setChemistry(chem: BatteryChemistryType): void {
    this.selectedChemistry.set(chem);
    const props = CHEMISTRIES[chem];
    this.cellResistanceMOhms.set(props.baseResistance);
    this.reinitializePack();
    this.generateAuxiliaryData();
  }

  public setFormat(format: CellFormatType): void {
    this.selectedFormat.set(format);
    const f = CELL_FORMATS[format];
    this.cellCapacityAh.set(f.defaultCapacityAh);
    this.reinitializePack();
    this.generateAuxiliaryData();
  }

  public setCoolingType(cooling: CoolingType): void {
    this.coolingType.set(cooling);
  }

  public setFidelity(fid: SimulationFidelity): void {
    this.fidelity.set(fid);
  }

  public setScenario(scenario: LoadScenarioPreset): void {
    this.currentLoadScenario.set(scenario);
  }

  public togglePlayPause(): void {
    this.isRunning.update(r => !r);
  }

  public stepForward(seconds: number): void {
    this.simTimeSec.update(t => t + seconds);
    this.stepPhysics(seconds);
  }

  public setSimSpeed(speed: number): void {
    this.simSpeed.set(speed);
  }

  public resetSimulation(): void {
    this.simTimeSec.set(0);
    this.reinitializePack();
  }

  public onSeriesChange(e: Event): void {
    const val = parseInt((e.target as HTMLInputElement).value, 10);
    if (!isNaN(val) && val > 0 && val <= 384) {
      this.seriesCount.set(val);
      this.reinitializePack();
    }
  }

  public onParallelChange(e: Event): void {
    const val = parseInt((e.target as HTMLInputElement).value, 10);
    if (!isNaN(val) && val > 0 && val <= 48) {
      this.parallelCount.set(val);
      this.reinitializePack();
    }
  }

  public onCoolantTempChange(e: Event): void {
    const val = parseFloat((e.target as HTMLInputElement).value);
    if (!isNaN(val)) this.coolantInletTempC.set(val);
  }

  public onFlowRateChange(e: Event): void {
    const val = parseFloat((e.target as HTMLInputElement).value);
    if (!isNaN(val)) this.coolantFlowRateLpm.set(val);
  }

  public onAmbientTempChange(e: Event): void {
    const val = parseFloat((e.target as HTMLInputElement).value);
    if (!isNaN(val)) this.ambientTempC.set(val);
  }

  public onCellSelected(cell: CellState | null): void {
    this.inspectedCell.set(cell);
  }

  public setDispatchStrategy(strat: DispatchStrategy): void {
    this.bessDispatchStrategy.set(strat);
    this.bessSolarResult.set(this.bessSolarService.simulate24HourDispatch(strat));
  }

  // Format Elapsed Time as HH:MM:SS
  public formatSimTime(totalSec: number): string {
    const s = Math.floor(totalSec % 60);
    const m = Math.floor((totalSec / 60) % 60);
    const h = Math.floor(totalSec / 3600);
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  // AI Diagnostic Advisory Request
  public runAiDiagnostic(): void {
    this.isAiLoading.set(true);
    this.http.post<{ success: boolean; report: string }>('/api/v1/ai/diagnostics', {
      telemetry: this.telemetry(),
      chemistry: this.selectedChemistry(),
      config: {
        seriesCount: this.seriesCount(),
        parallelCount: this.parallelCount(),
        cooling: this.coolingType()
      },
      query: this.customAiPrompt()
    }).subscribe({
      next: (res) => {
        this.aiReport.set(res.report || 'Diagnostic report compiled successfully.');
        this.isAiLoading.set(false);
      },
      error: (err) => {
        console.error('Failed to run AI diagnostics:', err);
        this.aiReport.set('Heuristic Diagnostic: System within operating limits. Check cooling flow rate.');
        this.isAiLoading.set(false);
      }
    });
  }

  public onAiPromptInput(e: Event): void {
    const val = (e.target as HTMLInputElement).value;
    this.customAiPrompt.set(val);
  }

  public getCellVoltageHeightPct(cell: CellState): number {
    const chem = this.chemistryInfo();
    const span = Math.max(0.1, chem.maxVoltage - chem.minVoltage);
    const norm = (cell.voltage - chem.minVoltage) / span;
    return Math.max(10, Math.min(100, norm * 100));
  }

  // Export full pack telemetry snapshot (JSON file download)
  public exportTelemetry(): void {
    const payload = {
      timestamp: new Date().toISOString(),
      platform: 'AUREOM.AI BATTERY.OS',
      assetId: 'BESS-TITAN-ALPHA-01',
      chemistry: this.selectedChemistry(),
      packConfig: {
        seriesCount: this.seriesCount(),
        parallelCount: this.parallelCount(),
        coolingType: this.coolingType(),
        fidelity: this.fidelity()
      },
      telemetry: this.telemetry(),
      sampleCellsCount: this.cells().length
    };

    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BATTERY_OS_TELEMETRY_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
