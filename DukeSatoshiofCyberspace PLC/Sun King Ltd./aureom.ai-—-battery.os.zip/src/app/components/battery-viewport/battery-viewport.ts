import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
  signal,
  EventEmitter
} from '@angular/core';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { CellState, VisualisationMode, BatteryChemistryType } from '../../models/battery.models';
import { CHEMISTRIES } from '../../models/chemistry-database';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-battery-viewport',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './battery-viewport.html',
  styleUrl: './battery-viewport.css'
})
export class BatteryViewport implements OnInit, OnChanges, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainer!: ElementRef<HTMLDivElement>;

  @Input() cells: CellState[] = [];
  @Input() mode: VisualisationMode = 'REALISTIC';
  @Input() chemistry: BatteryChemistryType = 'LFP';
  @Input() explodedRatio = 0.0; // 0.0 to 1.0

  @Output() cellSelected = new EventEmitter<CellState | null>();

  public selectedCell = signal<CellState | null>(null);
  public isHudCollapsed = signal<boolean>(false);
  public activeCameraPreset = signal<string>('isometric');

  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private controls!: OrbitControls;
  private frameId = 0;
  private isSoftwareGl = false;

  // 3D Model component groups for exploded view
  private packEnclosureLid!: THREE.Group;
  private busbarsGroup!: THREE.Group;
  private cellMeshes: { mesh: THREE.Mesh; cell: CellState; basePos: THREE.Vector3 }[] = [];
  private coldPlateGroup!: THREE.Group;
  private bmsModuleGroup!: THREE.Group;
  private coolingChannelsMesh!: THREE.Mesh;

  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2(-999, -999);
  private hoveredMesh: THREE.Mesh | null = null;

  // Reusable materials
  private metalMaterial!: THREE.MeshStandardMaterial;
  private busbarMaterial!: THREE.MeshStandardMaterial;
  private coldPlateMaterial!: THREE.MeshStandardMaterial;
  private lidMaterial!: THREE.MeshPhysicalMaterial;
  private channelMaterial!: THREE.MeshStandardMaterial;

  ngOnInit(): void {
    this.initThree();
    this.buildPackAssembly();
    this.startRenderLoop();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['mode'] && !changes['mode'].firstChange) {
      this.updateCellMaterials();
    }
    if (changes['explodedRatio'] && !changes['explodedRatio'].firstChange) {
      this.applyExplodedView(this.explodedRatio);
    }
    if (changes['cells'] && !changes['cells'].firstChange) {
      this.syncCellStates();
    }
  }

  ngOnDestroy(): void {
    if (this.frameId) {
      cancelAnimationFrame(this.frameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private initThree(): void {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    // Detect software WebGL to adapt performance gracefully
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x101820); // Graphite
    this.scene.fog = new THREE.FogExp2(0x101820, 0.035);

    this.camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    this.camera.position.set(5.5, 4.2, 6.5);

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance'
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // Controls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = !this.isSoftwareGl;
    this.controls.dampingFactor = 0.05;
    this.controls.target.set(0, 0.4, 0);
    this.controls.maxPolarAngle = Math.PI / 2 + 0.05; // Don't orbit below ground
    this.controls.minDistance = 1.5;
    this.controls.maxDistance = 25.0;

    // Lighting rig (PBR studio environment)
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Key directional light with warm tone
    const keyLight = new THREE.DirectionalLight(0xfff3e6, 2.8);
    keyLight.position.set(8, 12, 6);
    keyLight.castShadow = !this.isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.camera.near = 0.5;
      keyLight.shadow.camera.far = 25;
      const d = 4.5;
      keyLight.shadow.camera.left = -d;
      keyLight.shadow.camera.right = d;
      keyLight.shadow.camera.top = d;
      keyLight.shadow.camera.bottom = -d;
    }
    this.scene.add(keyLight);

    // Cool fill light
    const fillLight = new THREE.DirectionalLight(0x75aacc, 1.2);
    fillLight.position.set(-6, 8, -4);
    this.scene.add(fillLight);

    // Rim backlight
    const rimLight = new THREE.DirectionalLight(0x55b9c9, 1.4);
    rimLight.position.set(0, -2, -8);
    this.scene.add(rimLight);

    // Ground plane with subtle engineering grid
    const gridHelper = new THREE.GridHelper(16, 32, 0x243648, 0x172430);
    gridHelper.position.y = -0.01;
    this.scene.add(gridHelper);

    // Shared PBR Materials
    this.metalMaterial = new THREE.MeshStandardMaterial({
      color: 0x283845,
      metalness: 0.85,
      roughness: 0.25
    });

    this.busbarMaterial = new THREE.MeshStandardMaterial({
      color: 0xd98845, // Copper orange / brass
      metalness: 0.9,
      roughness: 0.2
    });

    this.coldPlateMaterial = new THREE.MeshStandardMaterial({
      color: 0x1f3240, // Anodized aluminum dark teal
      metalness: 0.7,
      roughness: 0.35
    });

    this.lidMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x223545,
      metalness: 0.2,
      roughness: 0.15,
      transparent: true,
      opacity: 0.38,
      transmission: this.isSoftwareGl ? 0 : 0.65,
      ior: 1.45,
      depthWrite: false
    });

    this.channelMaterial = new THREE.MeshStandardMaterial({
      color: 0x55b9c9, // Electrical cyan fluid
      emissive: 0x113a44,
      metalness: 0.3,
      roughness: 0.4
    });

    // Window resize observer
    window.addEventListener('resize', this.onWindowResize);

    // Canvas click & hover listeners for cell telemetry selection
    const dom = this.renderer.domElement;
    dom.addEventListener('pointermove', this.onPointerMove);
    dom.addEventListener('click', this.onCanvasClick);
  }

  private buildPackAssembly(): void {
    // 1. Pack Base Tray (Cast Aluminum Enclosure)
    const trayGeo = new THREE.BoxGeometry(4.8, 0.14, 3.4);
    const trayMesh = new THREE.Mesh(trayGeo, this.metalMaterial);
    trayMesh.position.y = 0.07;
    trayMesh.receiveShadow = !this.isSoftwareGl;
    this.scene.add(trayMesh);

    // Side frame structural walls
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x1c2b36, metalness: 0.8, roughness: 0.3 });
    const wallFrontGeo = new THREE.BoxGeometry(4.8, 0.85, 0.08);
    const wallFront = new THREE.Mesh(wallFrontGeo, wallMat);
    wallFront.position.set(0, 0.45, 1.66);
    this.scene.add(wallFront);

    const wallBack = new THREE.Mesh(wallFrontGeo, wallMat);
    wallBack.position.set(0, 0.45, -1.66);
    this.scene.add(wallBack);

    // 2. Cold Plate with Serpentine Cooling Channels
    this.coldPlateGroup = new THREE.Group();
    const plateGeo = new THREE.BoxGeometry(4.5, 0.06, 3.1);
    const plateMesh = new THREE.Mesh(plateGeo, this.coldPlateMaterial);
    plateMesh.position.y = 0.17;
    this.coldPlateGroup.add(plateMesh);

    // Serpentine fluid channels
    const channelCurve = new THREE.CurvePath<THREE.Vector3>();
    for (let c = -1.3; c <= 1.3; c += 0.45) {
      channelCurve.add(new THREE.LineCurve3(new THREE.Vector3(-2.1, 0.21, c), new THREE.Vector3(2.1, 0.21, c)));
      channelCurve.add(new THREE.LineCurve3(new THREE.Vector3(2.1, 0.21, c), new THREE.Vector3(2.1, 0.21, c + 0.22)));
      channelCurve.add(new THREE.LineCurve3(new THREE.Vector3(2.1, 0.21, c + 0.22), new THREE.Vector3(-2.1, 0.21, c + 0.22)));
    }
    const tubeGeo = new THREE.TubeGeometry(channelCurve, 120, 0.025, 8, false);
    this.coolingChannelsMesh = new THREE.Mesh(tubeGeo, this.channelMaterial);
    this.coldPlateGroup.add(this.coolingChannelsMesh);

    // Coolant inlet & outlet manifold fittings
    const fittingGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.22, 16);
    const fittingMat = new THREE.MeshStandardMaterial({ color: 0x55b9c9, metalness: 0.9, roughness: 0.2 });
    const inlet = new THREE.Mesh(fittingGeo, fittingMat);
    inlet.rotation.z = Math.PI / 2;
    inlet.position.set(-2.35, 0.21, -1.2);
    this.coldPlateGroup.add(inlet);

    const outlet = new THREE.Mesh(fittingGeo, fittingMat);
    outlet.rotation.z = Math.PI / 2;
    outlet.position.set(-2.35, 0.21, 1.2);
    this.coldPlateGroup.add(outlet);

    this.scene.add(this.coldPlateGroup);

    // 3. Cells Array (Cylindrical / Prismatic)
    this.createCellMeshes();

    // 4. Interconnect Busbars Group
    this.busbarsGroup = new THREE.Group();
    this.createBusbarSystem();
    this.scene.add(this.busbarsGroup);

    // 5. BMS Master Controller & High-Voltage Contactors Module
    this.bmsModuleGroup = new THREE.Group();
    const bmsBoxGeo = new THREE.BoxGeometry(0.8, 0.4, 0.5);
    const bmsBoxMat = new THREE.MeshStandardMaterial({ color: 0x172633, metalness: 0.6, roughness: 0.4 });
    const bmsBox = new THREE.Mesh(bmsBoxGeo, bmsBoxMat);
    bmsBox.position.set(2.0, 0.65, 0);
    this.bmsModuleGroup.add(bmsBox);

    // Contactor cylinders (positive & negative high-voltage contactors)
    const contactorGeo = new THREE.CylinderGeometry(0.09, 0.09, 0.28, 16);
    const contactorMat = new THREE.MeshStandardMaterial({ color: 0x8a382c, metalness: 0.8, roughness: 0.3 });
    const contactorPos = new THREE.Mesh(contactorGeo, contactorMat);
    contactorPos.position.set(1.9, 0.9, 0.15);
    this.bmsModuleGroup.add(contactorPos);

    const contactorNeg = new THREE.Mesh(contactorGeo, contactorMat);
    contactorNeg.position.set(1.9, 0.9, -0.15);
    this.bmsModuleGroup.add(contactorNeg);

    // Pre-charge resistor
    const resGeo = new THREE.BoxGeometry(0.25, 0.08, 0.08);
    const resMat = new THREE.MeshStandardMaterial({ color: 0x9e733b, metalness: 0.7, roughness: 0.4 });
    const resistor = new THREE.Mesh(resGeo, resMat);
    resistor.position.set(2.15, 0.85, 0);
    this.bmsModuleGroup.add(resistor);

    this.scene.add(this.bmsModuleGroup);

    // 6. Pack Enclosure Transparent / Removable Lid
    this.packEnclosureLid = new THREE.Group();
    const lidGeo = new THREE.BoxGeometry(4.82, 0.06, 3.42);
    const lidMesh = new THREE.Mesh(lidGeo, this.lidMaterial);
    lidMesh.position.y = 1.05;
    this.packEnclosureLid.add(lidMesh);

    // Lid structural reinforcement ribs
    const ribMat = new THREE.MeshStandardMaterial({ color: 0x304455, metalness: 0.85, roughness: 0.25 });
    for (let rx = -1.8; rx <= 1.8; rx += 0.9) {
      const ribGeo = new THREE.BoxGeometry(0.06, 0.08, 3.3);
      const rib = new THREE.Mesh(ribGeo, ribMat);
      rib.position.set(rx, 1.08, 0);
      this.packEnclosureLid.add(rib);
    }
    this.scene.add(this.packEnclosureLid);
  }

  private createCellMeshes(): void {
    // Clear old meshes
    for (const item of this.cellMeshes) {
      this.scene.remove(item.mesh);
    }
    this.cellMeshes = [];

    // Base geometry for cylindrical 21700 / 4680 cell with cathode top cap
    const cellRadius = 0.085;
    const cellHeight = 0.58;
    const cylinderGeo = new THREE.CylinderGeometry(cellRadius, cellRadius, cellHeight, 16);
    const capGeo = new THREE.CylinderGeometry(0.045, 0.045, 0.035, 16);

    const defaultCellColor = new THREE.Color(CHEMISTRIES[this.chemistry].colorHex);

    for (const cell of this.cells) {
      const cellMat = new THREE.MeshStandardMaterial({
        color: defaultCellColor,
        metalness: 0.35,
        roughness: 0.45
      });

      const cellMesh = new THREE.Mesh(cylinderGeo, cellMat);
      cellMesh.castShadow = !this.isSoftwareGl;
      cellMesh.receiveShadow = !this.isSoftwareGl;

      // Positive terminal cathode button
      const capMat = new THREE.MeshStandardMaterial({ color: 0xc8d0d6, metalness: 0.95, roughness: 0.15 });
      const capMesh = new THREE.Mesh(capGeo, capMat);
      capMesh.position.y = cellHeight / 2 + 0.015;
      cellMesh.add(capMesh);

      // Map geometric position
      // Grid across modules
      const row = cell.seriesIdx % 8;
      const col = Math.floor(cell.seriesIdx / 8);
      const pIdx = cell.parallelIdx;

      const posX = (col - 5) * 0.36 + (pIdx - 1.5) * 0.18;
      const posZ = (row - 3.5) * 0.34;
      const posY = 0.52; // Sitting atop cold plate

      cellMesh.position.set(posX, posY, posZ);
      cellMesh.userData['cellData'] = cell;

      this.scene.add(cellMesh);
      this.cellMeshes.push({
        mesh: cellMesh,
        cell,
        basePos: new THREE.Vector3(posX, posY, posZ)
      });
    }

    this.updateCellMaterials();
  }

  private createBusbarSystem(): void {
    // Clear previous busbars
    while (this.busbarsGroup.children.length > 0) {
      this.busbarsGroup.remove(this.busbarsGroup.children[0]);
    }

    const barGeo = new THREE.BoxGeometry(0.38, 0.02, 0.06);
    for (let c = 0; c < 12; c++) {
      for (let r = 0; r < 8; r++) {
        const busbar = new THREE.Mesh(barGeo, this.busbarMaterial);
        const posX = (c - 5) * 0.36;
        const posZ = (r - 3.5) * 0.34;
        busbar.position.set(posX, 0.83, posZ);
        this.busbarsGroup.add(busbar);
      }
    }
  }

  private updateCellMaterials(): void {
    const chemProps = CHEMISTRIES[this.chemistry];

    for (const item of this.cellMeshes) {
      const cell = item.cell;
      const mat = item.mesh.material as THREE.MeshStandardMaterial;

      const color = new THREE.Color();

      switch (this.mode) {
        case 'REALISTIC':
          color.set(chemProps.colorHex);
          break;

        case 'ELECTRICAL': {
          // Voltage gradient: from minVoltage (blue) to maxVoltage (electrical cyan/white)
          const vRatio = Math.max(0, Math.min(1, (cell.voltage - chemProps.minVoltage) / (chemProps.maxVoltage - chemProps.minVoltage)));
          color.setHSL(0.55 + 0.15 * (1.0 - vRatio), 0.85, 0.3 + 0.4 * vRatio);
          break;
        }

        case 'THERMAL': {
          // Temperature heatmap: 20°C (cool blue #2563EB) to 35°C (green) to 48°C (amber) to >60°C (warning red)
          const t = cell.temperature;
          if (t <= 25.0) {
            color.setHex(0x326890); // Cool steel blue
          } else if (t <= 35.0) {
            const ratio = (t - 25.0) / 10.0;
            color.lerpColors(new THREE.Color(0x326890), new THREE.Color(0x58A985), ratio);
          } else if (t <= 50.0) {
            const ratio = (t - 35.0) / 15.0;
            color.lerpColors(new THREE.Color(0x58A985), new THREE.Color(0xE7AA49), ratio);
          } else {
            const ratio = Math.min(1.0, (t - 50.0) / 20.0);
            color.lerpColors(new THREE.Color(0xE7AA49), new THREE.Color(0xD95757), ratio);
          }
          break;
        }

        case 'SOC': {
          // State of Charge: 0% red to 50% amber to 100% electric cyan
          const s = cell.soc;
          if (s < 0.25) {
            color.setHex(0xd95757);
          } else if (s < 0.65) {
            color.setHex(0xe7aa49);
          } else {
            color.setHex(0x55b9c9);
          }
          break;
        }

        case 'SOH': {
          // State of Health: 100% healthy green to 80% amber to <70% degraded red
          const h = cell.soh;
          if (h >= 0.90) {
            color.setHex(0x58a985);
          } else if (h >= 0.80) {
            color.setHex(0xe7aa49);
          } else {
            color.setHex(0xd95757);
          }
          break;
        }

        case 'COOLING': {
          // Highlights bottom contact thermal flux
          color.setHex(0x284f60);
          break;
        }

        case 'FAULT': {
          if (cell.faultFlags.thermalRunawayRisk || cell.faultFlags.overVoltage) {
            color.setHex(0xd93838); // Pulsing bright red
          } else if (cell.faultFlags.underVoltage || cell.faultFlags.highImbalance) {
            color.setHex(0xe7aa49);
          } else {
            color.setHex(0x283845);
          }
          break;
        }
      }

      mat.color.copy(color);
    }
  }

  private applyExplodedView(ratio: number): void {
    const r = Math.max(0, Math.min(1.0, ratio));

    // Lid moves up
    if (this.packEnclosureLid) {
      this.packEnclosureLid.position.y = r * 1.8;
    }

    // Busbars lift upward
    if (this.busbarsGroup) {
      this.busbarsGroup.position.y = r * 0.9;
    }

    // BMS module lifts
    if (this.bmsModuleGroup) {
      this.bmsModuleGroup.position.y = r * 1.1;
    }

    // Cells expand slightly outward for granular inspection
    for (const item of this.cellMeshes) {
      const base = item.basePos;
      item.mesh.position.set(
        base.x * (1.0 + r * 0.18),
        base.y + r * 0.35,
        base.z * (1.0 + r * 0.18)
      );
    }

    // Cold plate drops downward
    if (this.coldPlateGroup) {
      this.coldPlateGroup.position.y = -r * 0.6;
    }
  }

  private syncCellStates(): void {
    if (this.cells.length !== this.cellMeshes.length) {
      this.createCellMeshes();
      return;
    }

    for (let i = 0; i < this.cells.length; i++) {
      this.cellMeshes[i].cell = this.cells[i];
      this.cellMeshes[i].mesh.userData['cellData'] = this.cells[i];
    }

    this.updateCellMaterials();
  }

  private startRenderLoop(): void {
    const clock = new THREE.Clock();

    const tick = () => {
      clock.getDelta();

      if (this.controls) {
        this.controls.update();
      }

      // Subtle coolant flow pulse animation in COOLING mode
      if (this.mode === 'COOLING' && this.channelMaterial) {
        this.channelMaterial.emissiveIntensity = 0.4 + 0.3 * Math.sin(clock.getElapsedTime() * 4.0);
      }

      this.renderer.render(this.scene, this.camera);
      this.frameId = requestAnimationFrame(tick);
    };

    tick();
  }

  private onWindowResize = (): void => {
    if (!this.canvasContainer || !this.renderer || !this.camera) return;
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth;
    const height = container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private onPointerMove = (e: MouseEvent): void => {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const meshes = this.cellMeshes.map(c => c.mesh);
    const intersects = this.raycaster.intersectObjects(meshes, false);

    if (intersects.length > 0) {
      this.renderer.domElement.style.cursor = 'crosshair';
    } else {
      this.renderer.domElement.style.cursor = 'default';
    }
  };

  private onCanvasClick = (e: MouseEvent): void => {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const meshes = this.cellMeshes.map(c => c.mesh);
    const intersects = this.raycaster.intersectObjects(meshes, false);

    if (intersects.length > 0) {
      const clickedMesh = intersects[0].object as THREE.Mesh;
      const cellData = clickedMesh.userData['cellData'] as CellState | undefined;
      if (cellData) {
        this.selectedCell.set(cellData);
        this.cellSelected.emit(cellData);
      }
    }
  };

  public setCameraPreset(preset: 'isometric' | 'top' | 'side' | 'bms'): void {
    this.activeCameraPreset.set(preset);
    switch (preset) {
      case 'isometric':
        this.camera.position.set(5.5, 4.2, 6.5);
        this.controls.target.set(0, 0.4, 0);
        break;
      case 'top':
        this.camera.position.set(0, 8.5, 0.05);
        this.controls.target.set(0, 0, 0);
        break;
      case 'side':
        this.camera.position.set(7.5, 0.8, 0);
        this.controls.target.set(0, 0.4, 0);
        break;
      case 'bms':
        this.camera.position.set(3.2, 1.8, 1.4);
        this.controls.target.set(1.9, 0.7, 0);
        break;
    }
  }

  public setMode(mode: VisualisationMode): void {
    this.mode = mode;
    this.updateCellMaterials();
  }

  public onExplodedSliderChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.explodedRatio = val;
    this.applyExplodedView(val);
  }

  public toggleHud(): void {
    this.isHudCollapsed.update(v => !v);
  }

  public closeCellInspection(): void {
    this.selectedCell.set(null);
    this.cellSelected.emit(null);
  }
}
