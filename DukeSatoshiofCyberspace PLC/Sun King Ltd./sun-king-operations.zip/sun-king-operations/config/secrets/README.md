# Secrets (not committed)

`scripts/init-secrets.sh` generates every file below with random values.
Files are mounted as Docker secrets (`/run/secrets/<name>`); application
settings read them through the `*_FILE` environment variables.

| File | Used by |
|---|---|
| `db_password` | Password for the `sunking` role (injected via `SUN_KING_DATABASE_PASSWORD_FILE`) |
| `app_secret` | JWT signing key (`SUN_KING_SECRET_KEY_FILE`) |
| `demo_password` | Password for the fictional demo accounts |
| `s3_user`, `s3_password` | MinIO root credentials |
| `s3_credentials` | AWS-style credentials file for the API's S3 client |
| `collector_token` | Ingest-only service token for the OT collector (`sun-king token svc-collector`) |
