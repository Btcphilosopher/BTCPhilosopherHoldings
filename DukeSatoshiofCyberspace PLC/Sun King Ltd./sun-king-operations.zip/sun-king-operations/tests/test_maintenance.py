import struct
import zlib
from datetime import UTC, datetime

from conftest import login


def png() -> bytes:
    raw = b"".join(b"\x00" + bytes([200, 120, 40]) * 8 for _ in range(8))

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)

    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", 8, 8, 8, 2, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(raw))
        + chunk(b"IEND", b"")
    )


def test_work_order_lifecycle_requires_evidence_and_independent_review(client, admin):
    eng = login(client, "engineer")
    tech = login(client, "tech")
    wo = client.post(
        "/api/maintenance/work-orders",
        headers=eng,
        json={
            "site_id": "site-hlm",
            "title": "Inspect combiner box 3.2",
            "work_type": "corrective",
            "asset_ids": ["HLM-CB-03-2"],
        },
    ).json()
    assert "does not certify electrical safety" in wo["safety_notice"]

    def tr(h, to, **kw):
        return client.post(
            f"/api/maintenance/work-orders/{wo['id']}/transition", headers=h, json={"to_status": to, **kw}
        )

    assert tr(eng, "assigned", assigned_to="u-tech").status_code == 200
    assert tr(tech, "in_progress").status_code == 200
    r = tr(tech, "completed", completion_notes="replaced cable")
    assert r.status_code == 409 and "evidence" in r.json()["detail"]
    bad = client.post(
        "/api/maintenance/evidence",
        headers=tech,
        data={"site_id": "site-hlm", "entity_type": "work_order", "entity_id": wo["id"]},
        files={"file": ("x.png", b"not a png", "image/png")},
    )
    assert bad.status_code == 422
    ok = client.post(
        "/api/maintenance/evidence",
        headers=tech,
        data={
            "site_id": "site-hlm",
            "entity_type": "work_order",
            "entity_id": wo["id"],
            "captured_at": "2026-01-05T10:00:00Z",
        },
        files={"file": ("photo.png", png(), "image/png")},
    )
    assert ok.status_code == 201
    got = client.get(f"/api/maintenance/evidence/{ok.json()['id']}", headers=eng)
    assert got.status_code == 200 and got.content == png()
    assert tr(tech, "completed", completion_notes="replaced cable").status_code == 200
    assert tr(eng, "signed_off").status_code == 403  # manager role required
    r = client.post(
        f"/api/maintenance/work-orders/{wo['id']}/transition", headers=admin, json={"to_status": "reviewed"}
    )
    assert r.status_code == 200
    assert tr(admin, "signed_off").status_code == 200


def test_offline_inspection_sync_conflict(client):
    tech = login(client, "tech")
    eng = login(client, "engineer")
    base = {
        "client_draft_id": "drf-test-0001",
        "template_id": "tpl-site-inspection",
        "site_id": "site-hlm",
        "answers": {"fencing_ok": "yes"},
        "status": "draft",
        "captured_at": "2026-01-05T09:00:00Z",
        "device_id": "tab-1",
    }
    r = client.post("/api/maintenance/inspections/sync", headers=tech, json=base).json()
    assert r["outcome"] == "created" and r["record"]["captured_at"].startswith("2026-01-05T09:00")
    v1 = r["record"]["version"]
    # someone else updates from v1
    r2 = client.post(
        "/api/maintenance/inspections/sync",
        headers=eng,
        json={**base, "answers": {"fencing_ok": "no"}, "base_version": v1},
    )
    assert r2.json()["outcome"] == "updated"
    # the tablet syncs an offline edit still based on v1 → explicit conflict
    stale = {
        **base,
        "answers": {"fencing_ok": "yes", "notes": "gate latch loose"},
        "base_version": v1,
        "captured_at": "2026-01-05T09:30:00Z",
    }
    c = client.post("/api/maintenance/inspections/sync", headers=tech, json=stale)
    assert c.status_code == 409 and c.json()["conflict"]
    k = client.post(
        "/api/maintenance/inspections/sync", headers=tech, json={**stale, "resolution": "keep_client"}
    ).json()
    assert k["outcome"] == "updated" and k["record"]["answers"]["notes"] == "gate latch loose"
    assert k["record"]["conflict_history"][0]["overwritten_server"] == {"fencing_ok": "no"}
    bad = client.post(
        "/api/maintenance/inspections/sync",
        headers=tech,
        json={**base, "client_draft_id": "drf-test-0002", "answers": {"fencing_ok": "maybe"}},
    )
    assert bad.status_code == 422
    fut = client.post(
        "/api/maintenance/inspections/sync",
        headers=tech,
        json={
            **base,
            "client_draft_id": "drf-test-0003",
            "captured_at": datetime(2100, 1, 1, tzinfo=UTC).isoformat(),
        },
    )
    assert fut.status_code == 422


def test_spare_part_usage_bounded(client, admin):
    wo = client.post(
        "/api/maintenance/work-orders",
        headers=admin,
        json={"site_id": "site-hlm", "title": "Fan swap", "work_type": "preventive"},
    ).json()
    assert (
        client.post(
            f"/api/maintenance/work-orders/{wo['id']}/parts",
            headers=admin,
            json={"part_id": "sp-fan-vc", "quantity": 1},
        ).status_code
        == 200
    )
    assert (
        client.post(
            f"/api/maintenance/work-orders/{wo['id']}/parts",
            headers=admin,
            json={"part_id": "sp-fan-vc", "quantity": 999},
        ).status_code
        == 409
    )
