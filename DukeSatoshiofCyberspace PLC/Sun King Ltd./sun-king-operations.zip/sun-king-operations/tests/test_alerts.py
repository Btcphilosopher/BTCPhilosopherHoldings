from datetime import timedelta

import pytest
from sqlalchemy import select

from sun_king.alerts import engine as eng
from sun_king.alerts.models import Alert, AlertRule
from sun_king.alerts.workflow import WorkflowError, acknowledge, transition
from sun_king.core.timeutil import utcnow


def alerts(db, **kw):
    stmt = select(Alert)
    for k, v in kw.items():
        stmt = stmt.where(getattr(Alert, k) == v)
    return db.scalars(stmt).all()


def test_failed_inverter_detected_and_attributed(seeded, db):
    a = alerts(db, alert_type="inverter_outage", subject_id="HLM-INV-03")
    assert len(a) == 1
    al = a[0]
    assert al.attribution == "equipment_failure" and al.attribution_confidence == "high"
    assert al.evidence["status_code"] == 312
    assert al.threshold_source and al.rule_version == 1
    assert not al.condition_active and al.condition_cleared_at is not None  # repaired in the simulation


def test_missing_telemetry_is_not_reported_as_failure(seeded, db):
    assert not alerts(db, alert_type="inverter_outage", subject_id="CLE-INV-02")
    stale = alerts(db, alert_type="stale_telemetry", subject_id="CLE-INV-02")
    assert stale and stale[0].attribution == "communication_loss"
    ev = stale[0].evidence
    assert ev.get("implied_unreported_kw") is None or ev["implied_unreported_kw"] > 20


def test_underperformance_and_stuck_sensor(seeded, db):
    up = alerts(db, alert_type="underperformance", subject_id="CLE-INV-04")
    assert up and up[0].condition_active and up[0].evidence["performance_index"] < 0.9
    sd = alerts(db, alert_type="sensor_disagreement", subject_id="CLE-PYR1")
    assert sd and sd[0].attribution == "sensor_fault"
    assert not alerts(db, alert_type="underperformance", subject_id="HLM-INV-01")


def test_no_fault_inferred_at_night_or_low_irradiance(seeded, db):
    night = utcnow().replace(hour=1, minute=0, second=0, microsecond=0)
    before = len(alerts(db, alert_type="inverter_outage"))
    eng.evaluate_site(db, "site-hlm", night)
    assert len(alerts(db, alert_type="inverter_outage")) == before


def test_persistence_hysteresis_and_acknowledgement(seeded, db):
    seq = iter([0.80, 0.80, 0.80, 0.90, 0.90, 0.95, 0.95, 0.95])
    calls = {}

    def fake(w, rule):
        val = next(seq)
        open_ = eng.alert_open(w.session, rule.id, "X-1")
        thr = rule.params["clear"] if open_ else rule.params["trigger"]
        calls[w.at] = val
        return [eng.Condition("X-1", val < thr, "test condition", value=val)]

    eng.EVALUATORS["unit_fake"] = fake
    db.add(
        AlertRule(
            id="unit-fake",
            version=1,
            rule_type="unit_fake",
            name="fake",
            site_id="site-hlm",
            severity="warning",
            params={"trigger": 0.85, "clear": 0.92},
            persistence_s=1200,
            clear_persistence_s=1200,
            threshold_source="unit test",
        )
    )
    db.flush()
    t0 = utcnow() - timedelta(hours=3)
    try:
        for i in range(8):
            eng.evaluate_site(db, "site-hlm", t0 + timedelta(minutes=10 * i))
            a = alerts(db, rule_id="unit-fake")
            if i < 2:
                assert not a, "persistence not respected"
            if i == 2:
                assert len(a) == 1 and a[0].condition_active
                acknowledge(db, a[0], "u-eng")
                assert a[0].condition_active and a[0].status == "detected"  # ack clears nothing
            if i in (3, 4, 5):
                assert a[0].condition_active, "hysteresis: 0.90 < clear threshold keeps the condition"
        a = alerts(db, rule_id="unit-fake")[0]
        assert not a.condition_active and a.status == "detected"  # cleared condition, workflow still open
    finally:
        del eng.EVALUATORS["unit_fake"]
        db.rollback()


def test_workflow_rules(seeded, db):
    up = alerts(db, alert_type="underperformance", subject_id="CLE-INV-04")[0]
    with pytest.raises(WorkflowError):
        transition(db, up, "verified", "u-eng")
    with pytest.raises(WorkflowError):
        transition(db, up, "assigned", "u-eng")  # needs assignee
    transition(db, up, "investigating", "u-eng")
    with pytest.raises(WorkflowError):
        transition(db, up, "resolved", "u-eng")  # condition still active
    transition(db, up, "resolved", "u-eng", force_reason="fuses replaced; awaiting next clear-sky day")
    with pytest.raises(WorkflowError):
        transition(db, up, "verified", "u-eng")  # cannot verify while active
    db.rollback()


def test_suppression_window_blocks_new_alerts(seeded, db):
    from sun_king.alerts.models import Suppression

    seq = iter([0.1] * 4)
    eng.EVALUATORS["unit_fake2"] = lambda w, r: [eng.Condition("Y-1", next(seq) < 0.5, "x")]
    db.add(
        AlertRule(
            id="unit-fake2",
            version=1,
            rule_type="unit_fake2",
            name="f2",
            site_id="site-hlm",
            severity="info",
            params={},
            persistence_s=0,
            clear_persistence_s=0,
            threshold_source="unit test",
        )
    )
    t0 = utcnow() - timedelta(hours=1)
    db.add(
        Suppression(
            id="sup-test",
            site_id="site-hlm",
            asset_id=None,
            alert_types=["unit_fake2"],
            start_time=t0 - timedelta(hours=1),
            end_time=t0 + timedelta(hours=2),
            reason="planned maintenance window",
        )
    )
    db.flush()
    try:
        s = eng.evaluate_site(db, "site-hlm", t0)
        assert "Y-1" in s["suppressed"] and not alerts(db, rule_id="unit-fake2")
    finally:
        del eng.EVALUATORS["unit_fake2"]
        db.rollback()
