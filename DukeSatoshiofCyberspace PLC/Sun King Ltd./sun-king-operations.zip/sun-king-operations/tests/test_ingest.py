from datetime import UTC, datetime, timedelta

import pytest
from pydantic import ValidationError
from sqlalchemy import select

from sun_king.telemetry.ingest import BatchTooLarge, ingest_batch
from sun_king.telemetry.models import CleanObservation, RawObservation
from sun_king.telemetry.schemas import ObservationIn

T = datetime(2026, 1, 10, 12, 0, tzinfo=UTC)


def ob(t, v, asset="HLM-INV-01", mt="ac_power", unit="kW"):
    return ObservationIn(
        asset_id=asset, measurement_type=mt, value=v, unit=unit, observation_time=t, source="unit-test"
    )


def test_ingest_pipeline(seeded, db):
    s1 = ingest_batch(
        db,
        [ob(T, 400.0), ob(T + timedelta(minutes=5), 410_000.0, unit="W")],
        "unit-test",
        now=T + timedelta(minutes=6),
    )
    assert s1.accepted == 2 and s1.duplicates == 0
    clean = db.scalar(
        select(CleanObservation).where(
            CleanObservation.asset_id == "HLM-INV-01",
            CleanObservation.observation_time == T + timedelta(minutes=5),
        )
    )
    raw = db.get(RawObservation, clean.raw_measurement_id)
    assert raw.value == 410_000.0 and raw.unit == "W"  # raw preserved as received
    assert clean.value == pytest.approx(410.0) and clean.unit == "kW"  # cleaned in canonical units

    # identical duplicate → counted, not stored
    s2 = ingest_batch(db, [ob(T, 400.0)], "unit-test", now=T + timedelta(minutes=7))
    assert s2.duplicates == 1 and s2.accepted == 0

    # same key, different value → new revision; clean row updated; raw keeps both
    s3 = ingest_batch(db, [ob(T, 402.0)], "unit-test", now=T + timedelta(minutes=8))
    assert s3.revisions == 1
    revs = db.scalars(
        select(RawObservation).where(
            RawObservation.asset_id == "HLM-INV-01",
            RawObservation.observation_time == T,
            RawObservation.source == "unit-test",
        )
    ).all()
    assert sorted(r.revision for r in revs) == [0, 1]
    c = db.scalar(
        select(CleanObservation).where(
            CleanObservation.asset_id == "HLM-INV-01", CleanObservation.observation_time == T
        )
    )
    assert c.value == 402.0 and "revised" in c.quality_flags

    # out-of-order and late delivery are flagged, not dropped
    s4 = ingest_batch(db, [ob(T - timedelta(hours=1), 300.0)], "unit-test", now=T + timedelta(minutes=9))
    assert s4.out_of_order == 1 and s4.late == 1 and s4.accepted == 1


def test_idempotent_replay_and_unknown_asset(seeded, db):
    batch = [ob(T + timedelta(hours=3), 100.0), ob(T + timedelta(hours=3), 1.0, asset="NOPE-1")]
    a = ingest_batch(db, batch, "unit-test", idempotency_key="k-replay-1", now=T + timedelta(hours=3))
    b = ingest_batch(db, batch, "unit-test", idempotency_key="k-replay-1", now=T + timedelta(hours=4))
    assert a.rejected == 1 and a.errors[0]["error"] == "unknown_asset" and a.status == "partial"
    assert b.replayed and b.batch_id == a.batch_id


def test_bounds_and_schema(seeded, db):
    from sun_king import config

    s = config.get_settings()
    object.__setattr__(s, "max_ingest_batch", 2)
    try:
        with pytest.raises(BatchTooLarge):
            ingest_batch(db, [ob(T, 1.0)] * 3, "unit-test")
    finally:
        object.__setattr__(s, "max_ingest_batch", 10_000)
    with pytest.raises(ValidationError):
        ObservationIn(
            asset_id="A",
            measurement_type="ac_power",
            value=1,
            unit="kW",
            observation_time=datetime(2026, 1, 1),
            source="x",
        )
    nan = ObservationIn(
        asset_id="HLM-INV-01",
        measurement_type="ac_power",
        value=float("nan"),
        unit="kW",
        observation_time=T,
        source="x",
    )
    assert nan.value is None
