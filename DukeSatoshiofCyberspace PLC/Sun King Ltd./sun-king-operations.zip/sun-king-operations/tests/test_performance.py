from datetime import timedelta

from sun_king.core.timeutil import local_day_bounds, utcnow
from sun_king.performance.analysis import (
    availability,
    inverter_comparison,
    loss_breakdown,
    performance_ratio,
    run_site_model,
    specific_yield,
)


def day(offset: int):
    from sun_king.core.timeutil import local_date

    return local_day_bounds(local_date(utcnow(), "Europe/London") + timedelta(days=offset), "Europe/London")


def test_pr_computed_with_adequate_inputs(seeded, db):
    s, e = day(-1)
    pr = performance_ratio(db, "site-hlm", s, e)
    assert pr.status == "ok" and 0.6 < pr.value < 1.0
    assert pr.uncertainty and pr.formula.startswith("PR =")
    assert any(x["type"] == "recorded_curtailment" for x in pr.exclusions)


def test_pr_refused_when_inputs_inadequate(seeded, db):
    s, e = day(-1)
    cle = performance_ratio(db, "site-cle", s, e)
    assert cle.status == "not_computed" and cle.value is None
    assert any("orientations" in r for r in cle.reasons)
    old = performance_ratio(db, "site-hlm", s - timedelta(days=60), e - timedelta(days=60))
    assert old.status == "not_computed" and any("coverage" in r or "unavailable" in r for r in old.reasons)


def test_specific_yield_withheld_on_meter_reset_day(seeded, db):
    s, e = day(-5)
    sy = specific_yield(db, "site-hlm", s, e)
    assert sy.status == "not_computed" and "meter_reset" in sy.reasons[0]
    s, e = day(-1)
    assert specific_yield(db, "site-hlm", s, e).status == "ok"


def test_inverter_comparison_and_losses_separate_causes(seeded, db):
    s, _ = day(-3)
    _, e = day(-2)
    run = run_site_model(db, "site-hlm", s, e)
    rows = {r["asset_id"]: r for r in inverter_comparison(db, "site-hlm", s, e, run)}
    assert rows["HLM-INV-03"]["performance_index"] < 0.5
    assert rows["HLM-INV-03"]["peer_robust_z"] < -3
    assert all(rows[i]["performance_index"] > 0.9 for i in ("HLM-INV-01", "HLM-INV-02", "HLM-INV-04"))
    lb = loss_breakdown(db, "site-hlm", s, e, run)
    assert lb["categories"]["equipment_failure"]["kwh"] > 100
    assert lb["categories"]["curtailment"]["kwh"] == 0
    av = availability(run, "HLM-INV-03")
    assert av.value < 0.6


def test_comm_loss_not_counted_as_production_loss(seeded, db):
    s, e = day(-1)
    run = run_site_model(db, "site-cle", s, e)
    lb = loss_breakdown(db, "site-cle", s, e, run)
    c = lb["categories"]["communication_loss_unobserved"]
    assert c["kwh"] > 0 and c["counted_as_loss"] is False
    assert lb["categories"]["equipment_failure"]["kwh"] == 0
    av = availability(run, "CLE-INV-02")
    assert av.status == "estimate" and av.uncertainty["lower_bound"] < av.uncertainty["upper_bound"]


def test_curtailment_attributed_from_record(seeded, db):
    s, e = day(-4)
    lb = loss_breakdown(db, "site-cle", s, e)
    assert lb["categories"]["curtailment"]["kwh"] > 50
    assert lb["categories"]["curtailment"]["records"] == ["curt-cle-001"]
