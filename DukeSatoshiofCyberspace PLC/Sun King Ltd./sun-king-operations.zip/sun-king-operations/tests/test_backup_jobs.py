import gzip
import json
import os
from datetime import timedelta

import pytest
from sqlalchemy import func, select

from sun_king.admin.backup import backup, restore
from sun_king.core.db import Base, create_all, make_engine
from sun_king.core.timeutil import utcnow
from sun_king.workers import jobs


def _counts(session):
    import sun_king.models  # noqa: F401

    return {t.name: session.scalar(select(func.count()).select_from(t)) for t in Base.metadata.sorted_tables}


def test_backup_and_tested_restoration(seeded, db, tmp_path):
    from sqlalchemy.orm import Session

    path = tmp_path / "b.json.gz"
    info = backup(db, str(path))
    assert info["rows"] > 10_000
    target = make_engine(f"sqlite:///{tmp_path}/restore.db")
    create_all(target)
    with Session(target) as s2:
        res = restore(s2, str(path))
        s2.commit()
        assert res["rows"] == info["rows"]
        src, dst = _counts(db), _counts(s2)
        assert src == dst
        # restored data is usable: the energy calculation gives the same result
        from sun_king.energy.service import meter_export

        now = utcnow()
        a = meter_export(db, "site-hlm", now - timedelta(days=2), now - timedelta(days=1))
        b = meter_export(s2, "site-hlm", now - timedelta(days=2), now - timedelta(days=1))
        assert a["energy_kwh"] == pytest.approx(b["energy_kwh"])
        with pytest.raises(RuntimeError, match="not empty"):
            restore(s2, str(path))


def test_restore_detects_tampering(seeded, db, tmp_path):
    from sqlalchemy.orm import Session

    path = tmp_path / "b.json.gz"
    backup(db, str(path))
    lines = gzip.open(path, "rt").read().splitlines()
    for i, ln in enumerate(lines):
        o = json.loads(ln)
        if o.get("asset_id") == "HLM-INV-03" and "rated_capacity" in o:
            o["rated_capacity"] = 9999
            lines[i] = json.dumps(o, sort_keys=True)
            break
    bad = tmp_path / "bad.json.gz"
    with gzip.open(bad, "wt") as f:
        f.write("\n".join(lines) + "\n")
    target = make_engine(f"sqlite:///{tmp_path}/r2.db")
    create_all(target)
    with Session(target) as s2, pytest.raises(RuntimeError, match="checksum"):
        restore(s2, str(bad))


def test_job_retry_budget_and_restart_recovery(engine, db):
    calls = {"n": 0}

    @jobs.handler("unit_flaky")
    def flaky(session, payload):
        calls["n"] += 1
        raise RuntimeError("upstream timeout")

    @jobs.handler("unit_ok")
    def ok(session, payload):
        return {"done": payload["x"]}

    j = jobs.enqueue(db, "unit_flaky", {}, idempotency_key="unit-flaky-1", max_attempts=3)
    assert jobs.enqueue(db, "unit_flaky", {}, idempotency_key="unit-flaky-1").id == j.id  # idempotent
    t = utcnow()
    for k in range(3):
        jobs.run_one(db, "w1", now=t + timedelta(hours=k + 1))
    assert j.status == "failed" and j.attempts == 3 and "upstream timeout" in j.last_error
    # simulated crash: job left running with an expired lease is requeued on restart
    j2 = jobs.enqueue(db, "unit_ok", {"x": 1})
    t2 = utcnow() + timedelta(seconds=1)
    assert jobs.claim(db, "w-crashed", now=t2).id == j2.id
    assert j2.status == "running"
    assert jobs.recover_expired(db, now=t2 + timedelta(minutes=10)) >= 1
    db.refresh(j2)
    assert j2.status == "queued"
    done = jobs.run_one(db, "w2", now=t2 + timedelta(minutes=11))
    assert done.status == "done" and done.result == {"done": 1} and done.attempts == 2
    db.rollback()


@pytest.mark.postgres
def test_migrations_round_trip():
    url = os.environ.get("SUN_KING_TEST_DATABASE_URL")
    if not url:
        pytest.skip("PostgreSQL not configured")
    from alembic import command
    from alembic.config import Config

    from conftest import ROOT

    cfg = Config(str(ROOT / "alembic.ini"))
    cfg.set_main_option("script_location", str(ROOT / "migrations"))
    command.downgrade(cfg, "0001")
    command.upgrade(cfg, "head")
