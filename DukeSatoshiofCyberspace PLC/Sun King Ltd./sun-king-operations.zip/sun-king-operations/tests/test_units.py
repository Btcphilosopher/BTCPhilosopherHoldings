import pytest

from sun_king.core.units import (
    Quantity,
    UnitError,
    convert,
    energy_from_constant_power,
    sum_quantities,
    to_canonical,
)


def test_conversions():
    assert convert(1500, "W", "kW") == pytest.approx(1.5)
    assert convert(2.5, "MWh", "kWh") == pytest.approx(2500)
    assert to_canonical(300, "K") == (pytest.approx(26.85), "degC")
    assert convert(212, "degF", "degC") == pytest.approx(100)
    assert to_canonical(50, "%") == (pytest.approx(0.5), "fraction")
    assert to_canonical(1, "W/m²")[1] == "W/m2"


def test_power_and_energy_never_mix():
    with pytest.raises(UnitError):
        Quantity(5, "kW") + Quantity(5, "kWh")
    with pytest.raises(UnitError):
        convert(10, "kW", "kWh")
    # summing power stays power — never relabelled as energy
    total = sum_quantities([Quantity(1, "kW"), Quantity(500, "W")])
    assert total.unit == "kW" and total.value == pytest.approx(1.5)
    with pytest.raises(UnitError):
        total.relabel("kWh")


def test_energy_requires_time():
    e = energy_from_constant_power(Quantity(2, "MW"), 0.5)
    assert e.unit == "kWh" and e.value == pytest.approx(1000)
    with pytest.raises(UnitError):
        energy_from_constant_power(Quantity(2, "kWh"), 1)


def test_unknown_unit_and_absolute_temperature_addition():
    with pytest.raises(UnitError):
        Quantity(1, "furlong")
    with pytest.raises(UnitError):
        Quantity(20, "degC") + Quantity(5, "degC")
