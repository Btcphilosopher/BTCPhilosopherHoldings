from conftest import login


def test_authentication_required(client):
    assert client.get("/api/overview").status_code == 401
    assert client.get("/api/overview", headers={"Authorization": "Bearer nonsense"}).status_code == 401
    r = client.post("/api/auth/login", json={"email": "admin@sunking.example", "password": "wrong"})
    assert r.status_code == 401


def test_site_scoping(client):
    tech = login(client, "tech")  # field technician on Hollin Moor only
    sites = [s["id"] for s in client.get("/api/sites", headers=tech).json()]
    assert sites == ["site-hlm"]
    assert client.get("/api/sites/site-cle", headers=tech).status_code == 404
    assert client.get("/api/alerts?site_id=site-cle", headers=tech).status_code == 404
    assert all(a["site_id"] == "site-hlm" for a in client.get("/api/alerts", headers=tech).json())
    # role too low for work-order creation
    r = client.post(
        "/api/maintenance/work-orders",
        headers=tech,
        json={"site_id": "site-hlm", "title": "x" * 5, "work_type": "corrective"},
    )
    assert r.status_code == 403


def test_viewer_is_read_only(client):
    viewer = login(client, "viewer")
    assert client.get("/api/sites/site-cle/overview", headers=viewer).status_code == 200
    assert (
        client.post(
            "/api/curtailment",
            headers=viewer,
            json={
                "site_id": "site-cle",
                "start_time": "2026-01-01T10:00:00Z",
                "end_time": "2026-01-01T11:00:00Z",
                "limit_kw": 1,
                "issued_by": "x",
            },
        ).status_code
        == 403
    )
    assert client.get("/api/admin/users", headers=viewer).status_code == 403
    assert (
        client.post("/api/storage/scenarios", headers=viewer, json={"site_id": "site-cle"}).status_code == 403
    )


def test_service_account_can_only_ingest(client, db):
    from sun_king.admin.models import User
    from sun_king.admin.security import create_token

    svc = db.get(User, "svc-collector")
    h = {"Authorization": f"Bearer {create_token(svc)}"}
    assert client.get("/api/overview", headers=h).status_code == 403
    r = client.post(
        "/api/telemetry/ingest",
        headers=h,
        json={
            "source": "ot-collector",
            "observations": [
                {
                    "asset_id": "HLM-INV-01",
                    "measurement_type": "ac_power",
                    "value": 1.0,
                    "unit": "kW",
                    "observation_time": "2026-01-02T12:00:00Z",
                    "source": "ot-collector",
                }
            ],
        },
    )
    assert r.status_code == 200 and r.json()["accepted"] == 1


def test_input_validation_and_bounds(client, admin):
    r = client.get(
        "/api/telemetry/observations?asset_id=HLM-INV-01&measurement_type=ac_power&start=2026-01-01T00:00:00&end=2026-01-02T00:00:00Z",
        headers=admin,
    )
    assert r.status_code == 422  # naive datetime
    r = client.get(
        "/api/energy/sites/site-hlm?start=2025-01-01T00:00:00Z&end=2026-01-01T00:00:00Z", headers=admin
    )
    assert r.status_code == 422  # window too long
    r = client.post(
        "/api/telemetry/ingest",
        headers=admin,
        json={
            "source": "x",
            "observations": [
                {
                    "asset_id": "HLM-INV-01",
                    "measurement_type": "ac_power",
                    "value": 1,
                    "unit": "kW",
                    "observation_time": "2026-01-01T00:00:00",
                    "source": "x",
                }
            ],
        },
    )
    assert r.status_code == 422


def test_no_control_endpoints_exist(client):
    paths = [r.path for r in client.app.routes if hasattr(r, "path")]
    spec = client.get("/openapi.json").json()["paths"]
    for p in list(spec) + paths:
        for word in ("setpoint", "command", "switch", "trip", "curtail-now", "control"):
            assert word not in p.lower()
