"""End-to-end demonstration through the public API (mirrors scripts/demo.py)."""

from datetime import timedelta

from conftest import login
from sun_king.core.timeutil import utcnow
from test_maintenance import png


def test_demonstration_workflow(client, admin):
    eng = login(client, "engineer")
    tech = login(client, "tech")
    # 1. portfolio overview
    ov = client.get("/api/overview", headers=admin).json()
    assert {s["site"]["id"] for s in ov["sites"]} == {"site-hlm", "site-cle"}
    assert ov["totals"]["today_export"]["bases"]["site-hlm"] == "meter:export_settlement"
    # 2. site + asset hierarchy (physical, electrical and monitoring views are separate)
    tree = client.get("/api/sites/site-hlm/hierarchy", headers=admin).json()["tree"]
    assert any(n["asset_type"] == "grid_connection" for n in tree)
    edges = client.get("/api/sites/site-hlm/connectivity", headers=admin).json()["edges"]
    assert {"from": "HLM-INV-03", "to": "HLM-TX1", "type": "ac_lv", "source": "single_line_diagram"} in edges
    # 3. live simulated measurements, with age
    latest = client.get("/api/telemetry/latest?site_id=site-hlm", headers=admin).json()["values"]
    assert latest and all("age_s" in v for v in latest)
    # 4–5. failed vs silent inverter
    alerts = client.get("/api/alerts?include_verified=true", headers=admin).json()
    outage = next(
        a for a in alerts if a["alert_type"] == "inverter_outage" and a["subject_id"] == "HLM-INV-03"
    )
    comm = next(a for a in alerts if a["alert_type"] == "stale_telemetry" and a["subject_id"] == "CLE-INV-02")
    assert outage["attribution"] == "equipment_failure" and comm["attribution"] == "communication_loss"
    assert any(a["alert_type"] == "underperformance" and a["subject_id"] == "CLE-INV-04" for a in alerts)
    # 6. work order from the alert
    wo = client.post(
        "/api/maintenance/work-orders",
        headers=eng,
        json={
            "site_id": "site-hlm",
            "title": "INV-03 DC insulation fault",
            "work_type": "corrective",
            "priority": "urgent",
            "asset_ids": ["HLM-INV-03"],
            "alert_id": outage["id"],
        },
    ).json()
    assert (
        client.post(
            f"/api/alerts/{outage['id']}/transition",
            headers=eng,
            json={"to_status": "assigned", "assignee": "u-tech"},
        ).status_code
        == 200
    )
    assert (
        client.post(
            f"/api/alerts/{outage['id']}/transition", headers=tech, json={"to_status": "investigating"}
        ).status_code
        == 200
    )

    def tr(h, to, **kw):
        return client.post(
            f"/api/maintenance/work-orders/{wo['id']}/transition", headers=h, json={"to_status": to, **kw}
        )

    assert tr(eng, "assigned", assigned_to="u-tech", contractor_id="con-pennine-elec").status_code == 200
    assert tr(tech, "in_progress").status_code == 200
    # 7. field inspection evidence
    r = client.post(
        "/api/maintenance/inspections/sync",
        headers=tech,
        json={
            "client_draft_id": "drf-demo-inv03",
            "template_id": "tpl-inverter-corrective",
            "site_id": "site-hlm",
            "work_order_id": wo["id"],
            "asset_id": "HLM-INV-03",
            "status": "submitted",
            "captured_at": (utcnow() - timedelta(days=1, hours=1)).isoformat(),
            "answers": {
                "arrival_status_code": 312,
                "visual_condition": "minor damage",
                "dc_insulation_ok": "no",
                "findings": "Rodent damage to DC feeder in CB 3.2",
                "actions": "Feeder replaced under permit",
            },
        },
    )
    assert r.status_code == 200
    assert (
        client.post(
            "/api/maintenance/evidence",
            headers=tech,
            data={
                "site_id": "site-hlm",
                "entity_type": "work_order",
                "entity_id": wo["id"],
                "kind": "completion",
            },
            files={"file": ("cb32.png", png(), "image/png")},
        ).status_code
        == 201
    )
    repaired_at = outage["condition_cleared_at"]
    from datetime import datetime

    at = (datetime.fromisoformat(repaired_at) - timedelta(minutes=20)).isoformat()
    assert (
        tr(
            tech,
            "completed",
            completion_notes="Feeder replaced; inverter restarted by authorised person",
            repair_summary="DC feeder replaced",
            at=at,
        ).status_code
        == 200
    )
    # 8. verify post-maintenance performance
    v = client.post(
        f"/api/alerts/{outage['id']}/verify", headers=eng, json={"work_order_id": wo["id"]}
    ).json()
    assert v["verification"]["passed"], v["verification"]
    assert v["alert"]["status"] == "verified"
    # 9. day-ahead forecast
    fc = client.post(
        "/api/forecasts/issue", headers=eng, json={"site_id": "site-hlm", "horizon_type": "day_ahead"}
    )
    assert fc.status_code == 201
    f = fc.json()
    assert f["kind"] == "forecast" and f["weather_issue_time"] and len(f["values"]) in (46, 48, 50)
    assert all(x["p10_kw"] <= x["p50_kw"] <= x["p90_kw"] for x in f["values"])
    # 10. energy completeness — meter-reset day shown as incomplete with an explicit estimate
    comp = client.get("/api/energy/sites/site-hlm/completeness?days=6", headers=admin).json()["days"]
    reset_day = next(d for d in comp if d["meter_resets"])
    assert (
        reset_day["status"] == "incomplete_meter_reset"
        and reset_day["estimated_export_kwh"] >= reset_day["measured_export_kwh"]
    )
    # 11. storage scenario
    st = client.post("/api/storage/scenarios", headers=eng, json={"site_id": "site-cle"}).json()
    assert (
        st["schedules"]["optimised_dp"]["constraint_violations"] == []
        and "not a forecast" in st["disclaimer"]
    )
    # 12. source-linked report
    today = utcnow().date()
    rep = client.post(
        "/api/reports/operational",
        headers=admin,
        json={"start_day": str(today - timedelta(days=5)), "end_day": str(today - timedelta(days=1))},
    ).json()
    html = client.get(rep["links"]["html"], headers=admin).text
    assert "/api/telemetry/observations?asset_id=HLM-MTR-EXP" in html
    assert "do not certify electrical safety" in html
    assert "incomplete_meter_reset" in html or "INCOMPLETE" in html
    js = client.get(rep["links"]["json"], headers=admin).json()
    hlm = next(s for s in js["sites"] if s["site_id"] == "site-hlm")
    assert any(a["id"] == outage["id"] for a in hlm["alerts"])
    assert client.get(rep["links"]["csv"], headers=admin).text.startswith("site_id,date,status")


def test_disconnected_site_shows_last_known_values(client, admin):
    from datetime import timedelta as td

    from sun_king.core.db import session_factory
    from sun_king.reporting.overview import site_overview

    with session_factory()() as s:
        later = utcnow() + td(hours=2)
        o = site_overview(s, "site-cle", now=later)
    assert o["connection_state"] == "disconnected"
    ex = o["current_generation"]["export_meter"]
    assert ex is not None and ex["is_current"] is False and ex["age_s"] > 3600
    assert all(i["state"] == "no_telemetry" for i in o["inverters"])
    assert o["capacity"]["available_ac_kw"] == 0 and o["capacity"]["unknown_ac_kw"] == 3500
