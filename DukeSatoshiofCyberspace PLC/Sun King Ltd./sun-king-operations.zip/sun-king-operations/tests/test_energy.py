from datetime import UTC, date, datetime, timedelta

import pytest

from sun_king.core.timeutil import ensure_utc, local_day_bounds
from sun_king.energy.accounting import (
    aggregate_buckets,
    difference_register,
    estimate_gaps_from_reference,
    integrate_power,
)
from sun_king.energy.hierarchy import choose_site_figure, portfolio_total

T0 = datetime(2026, 6, 1, 0, 0, tzinfo=UTC)


def series(start, n, step_s, f):
    return [(start + timedelta(seconds=i * step_s), f(i)) for i in range(n)]


def test_constant_power_integrates_to_energy():
    s = series(T0, 13, 300, lambda i: 120.0)  # 0..60 min
    r = integrate_power(s, T0, T0 + timedelta(hours=1))
    assert r.energy_kwh == pytest.approx(120.0)
    assert r.complete and r.coverage == pytest.approx(1.0)
    assert r.method == "power_integration_trapezoid"


def test_irregular_sampling_is_exact_for_linear_ramp():
    # power ramps 0 → 100 kW over one hour; samples at irregular times
    offs = [0, 7, 9, 23, 31, 44, 45, 52, 60]
    s = [(T0 + timedelta(minutes=m), 100 * m / 60) for m in offs]
    r = integrate_power(s, T0, T0 + timedelta(hours=1), max_gap_s=900)
    assert r.energy_kwh == pytest.approx(50.0)
    assert r.n_samples == 8


def test_summing_kw_samples_is_not_energy():
    s = series(T0, 13, 300, lambda i: 100.0)
    naive = sum(v for _, v in s)  # 1300 — the classic mistake
    r = integrate_power(s, T0, T0 + timedelta(hours=1))
    assert naive != pytest.approx(r.energy_kwh)
    assert r.energy_kwh == pytest.approx(100.0)


def test_gap_is_reported_not_zero_filled():
    s = series(T0, 13, 300, lambda i: 100.0)
    s = [p for p in s if not (T0 + timedelta(minutes=20) < p[0] < T0 + timedelta(minutes=45))]
    r = integrate_power(s, T0, T0 + timedelta(hours=1), max_gap_s=900)
    assert not r.complete
    assert "incomplete" in r.flags
    assert r.coverage == pytest.approx(35 / 60, abs=1e-3)
    assert r.energy_kwh == pytest.approx(100 * 35 / 60)
    assert len(r.gaps) == 1 and r.gaps[0].seconds == 25 * 60


def test_missing_values_and_duplicate_timestamps():
    s = series(T0, 13, 300, lambda i: 60.0)
    s.insert(3, (T0 + timedelta(minutes=10), 9999.0))  # duplicate timestamp: later value wins
    s.insert(4, (T0 + timedelta(minutes=10), 60.0))
    s.append((T0 + timedelta(minutes=30), None))  # missing value ignored
    r = integrate_power(s, T0, T0 + timedelta(hours=1))
    assert r.energy_kwh == pytest.approx(60.0)


def test_boundary_interpolation_and_bucket_additivity():
    s = series(T0 - timedelta(minutes=5), 30, 300, lambda i: 10.0 * i)
    edges = [T0 + timedelta(minutes=m) for m in (0, 17, 30, 61, 90)]
    parts = aggregate_buckets(s, edges)
    whole = integrate_power(s, edges[0], edges[-1])
    assert sum(p.energy_kwh for p in parts) == pytest.approx(whole.energy_kwh)
    assert all(p.complete for p in parts)


def test_register_difference_and_reset():
    base = 50_000.0
    readings = [(T0 + timedelta(minutes=5 * i), base + 10 * i) for i in range(13)]
    r = difference_register(readings, T0, T0 + timedelta(hours=1))
    assert r.energy_kwh == pytest.approx(120) and r.complete
    # reset to zero at minute 32 (between readings at 30 and 35): reading at 35 shows 3 kWh since reset
    reset = [
        (t, v) if t < T0 + timedelta(minutes=35) else (t, 3 + 10 * (i - 7))
        for i, (t, v) in enumerate(readings)
    ]
    r2 = difference_register(reset, T0, T0 + timedelta(hours=1))
    assert "meter_reset" in r2.flags and not r2.complete
    assert r2.resets and r2.resets[0]["before"] == base + 60
    # 60 kWh before the reset pair + 3 after reset + 50 after = 113 measured; unobservable 2 min not invented
    assert r2.energy_kwh == pytest.approx(113)
    assert any(g.reason == "meter_reset_unobserved" for g in r2.gaps)


def test_register_rollover_and_jitter():
    roll = [
        (T0, 99_990.0),
        (T0 + timedelta(minutes=5), 99_998.0),
        (T0 + timedelta(minutes=10), 6.0),
        (T0 + timedelta(minutes=15), 14.0),
    ]
    r = difference_register(roll, T0, T0 + timedelta(minutes=15), rollover_kwh=100_000)
    assert r.energy_kwh == pytest.approx(24) and "register_rollover" in r.flags
    jit = [(T0, 100.0), (T0 + timedelta(minutes=5), 99.9), (T0 + timedelta(minutes=10), 101.0)]
    r = difference_register(jit, T0, T0 + timedelta(minutes=10))
    assert r.energy_kwh == pytest.approx(1.0) and "register_jitter" in r.flags


def test_estimation_is_separate_from_measurement():
    s = [
        p
        for p in series(T0, 13, 300, lambda i: 100.0)
        if not (T0 + timedelta(minutes=20) < p[0] < T0 + timedelta(minutes=45))
    ]
    r = integrate_power(s, T0, T0 + timedelta(hours=1))
    ref = series(T0, 13, 300, lambda i: 50.0)
    est = estimate_gaps_from_reference(r, ref, 2.0, "scaled reference")
    assert est.energy_kwh == pytest.approx(100 * 35 / 60)  # measured unchanged
    assert est.estimated_kwh == pytest.approx(100.0)
    assert "contains_estimate" in est.flags and est.estimation_method == "scaled reference"


@pytest.mark.parametrize(
    "day,hours", [(date(2026, 3, 29), 23), (date(2026, 10, 25), 25), (date(2026, 7, 1), 24)]
)
def test_dst_local_days(day, hours):
    s, e = local_day_bounds(day, "Europe/London")
    assert (e - s).total_seconds() / 3600 == hours
    pts = [(s + timedelta(minutes=5 * i), 100.0) for i in range(int(hours * 12) + 1)]
    r = integrate_power(pts, s, e)
    assert r.energy_kwh == pytest.approx(100 * hours) and r.complete


def test_naive_datetimes_rejected():
    with pytest.raises(ValueError):
        ensure_utc(datetime(2026, 1, 1, 12))


def test_no_double_counting_across_meters():
    meter = {"export_settlement": {"asset_id": "M", "energy_kwh": 1000.0, "complete": True, "coverage": 1.0}}
    invs = [{"asset_id": f"I{i}", "energy_kwh": 260.0, "complete": True, "coverage": 1.0} for i in range(4)]
    f = choose_site_figure("s1", meter, invs)
    assert f.energy_kwh == 1000.0 and f.basis == "meter:export_settlement"
    fb = choose_site_figure("s2", {}, invs)
    assert fb.basis == "inverter_sum_fallback" and fb.energy_kwh == 1040.0
    tot = portfolio_total([f, fb])
    assert tot["energy_kwh"] == 2040.0  # never 1000 + 1040 + 1040
    tot2 = portfolio_total([f, choose_site_figure("s3", {}, [])])
    assert tot2["sites_missing"] == ["s3"] and not tot2["complete"]
