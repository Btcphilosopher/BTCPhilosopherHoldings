"""Test configuration.

By default tests run against a temporary SQLite database. Set
``SUN_KING_TEST_DATABASE_URL`` to a PostgreSQL+PostGIS URL to run the same
suite against PostgreSQL (schema created with Alembic migrations).
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
_TMP = tempfile.mkdtemp(prefix="sunking-test-")
PG_URL = os.environ.get("SUN_KING_TEST_DATABASE_URL")
os.environ["SUN_KING_DATABASE_URL"] = PG_URL or f"sqlite:///{_TMP}/test.db"
os.environ["SUN_KING_OBJECT_STORE_PATH"] = f"{_TMP}/objects"
os.environ["SUN_KING_SECRET_KEY"] = "test-secret-key-for-unit-tests-only-0123456789"
os.environ["SUN_KING_EMBEDDED_WORKERS"] = "false"

import pytest  # noqa: E402

from sun_king.core.db import Base, create_all, init_engine, session_factory  # noqa: E402


def _reset_schema(engine):
    if engine.dialect.name == "postgresql":
        from alembic import command
        from alembic.config import Config
        from sqlalchemy import text

        with engine.begin() as c:
            c.execute(text("DROP SCHEMA public CASCADE; CREATE SCHEMA public;"))
        cfg = Config(str(ROOT / "alembic.ini"))
        cfg.set_main_option("script_location", str(ROOT / "migrations"))
        command.upgrade(cfg, "head")
    else:
        import sun_king.models  # noqa: F401

        Base.metadata.drop_all(engine)
        create_all(engine)


@pytest.fixture(scope="session")
def engine():
    e = init_engine(os.environ["SUN_KING_DATABASE_URL"])
    _reset_schema(e)
    return e


@pytest.fixture(scope="session")
def seeded(engine):
    """Six days of simulated history through the real pipeline (includes every injected event)."""
    from sun_king.simulation.seed import finalise_statement, seed

    s = session_factory()()
    info = seed(s, days=6, replay_days=4, train_forecasts=False, progress=lambda *_: None)
    finalise_statement(s)
    s.commit()
    s.close()
    return info


@pytest.fixture
def db(engine):
    s = session_factory()()
    yield s
    s.rollback()
    s.close()


@pytest.fixture(scope="session")
def client(seeded):
    from fastapi.testclient import TestClient

    from sun_king.api.app import app

    with TestClient(app) as c:
        yield c


def login(client, who: str = "admin") -> dict:
    r = client.post("/api/auth/login", json={"email": f"{who}@sunking.example", "password": "sunking-demo"})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture(scope="session")
def admin(client):
    return login(client, "admin")
