from datetime import UTC, datetime, timedelta

from sun_king.quality.rules import StreamContext, validate

NOW = datetime(2026, 6, 1, 12, tzinfo=UTC)


def v(mt, val, unit, t=NOW, ctx=None):
    return validate(mt, val, unit, t, NOW, ctx or StreamContext())


def test_good_value_converted_to_canonical():
    r = v("ac_power", 950_000, "W")
    assert r.value == 950 and r.unit == "kW" and r.quality == "good"


def test_physical_range_and_units():
    assert v("ambient_temperature", 85, "degC").quality == "bad"
    assert "out_of_range" in v("ambient_temperature", 85, "degC").flags
    assert "unit_mismatch" in v("ac_power", 5, "kWh").flags
    assert "unknown_unit" in v("ac_power", 5, "horsepower").flags
    assert v("not_a_type", 1, "kW").quality == "bad"


def test_night_irradiance_offsets_and_suspect_values():
    r = v("poa_irradiance", -3.2, "W/m2", ctx=StreamContext(sun_up=False))
    assert r.value == 0.0 and r.quality == "good" and "night_offset_clamped" in r.flags
    r = v("poa_irradiance", 180, "W/m2", ctx=StreamContext(sun_up=False))
    assert r.quality == "suspect" and "night_irradiance" in r.flags


def test_stuck_sensor_detection():
    ctx = StreamContext(sun_up=True, recent_values=[212.4] * 6)
    assert "stuck_value" in v("poa_irradiance", 212.4, "W/m2", ctx=ctx).flags
    assert "stuck_value" not in v("poa_irradiance", 215.0, "W/m2", ctx=ctx).flags


def test_timestamps_and_rates():
    assert "future_timestamp" in v("ac_power", 1, "kW", t=NOW + timedelta(hours=1)).flags
    assert "late_arrival" in v("ac_power", 1, "kW", t=NOW - timedelta(hours=2)).flags
    assert (
        "out_of_order"
        in validate(
            "ac_power", 1, "kW", NOW, NOW, StreamContext(latest_seen_time=NOW + timedelta(minutes=5))
        ).flags
    )
    ctx = StreamContext(previous_value=20, previous_time=NOW - timedelta(seconds=60))
    assert "implausible_rate" in v("module_temperature", 45, "degC", ctx=ctx).flags


def test_missing_and_rating():
    r = v("ac_power", None, "kW")
    assert r.quality == "missing" and r.value is None
    assert "exceeds_rating" in v("ac_power", 1500, "kW", ctx=StreamContext(rated_kw=1250)).flags
