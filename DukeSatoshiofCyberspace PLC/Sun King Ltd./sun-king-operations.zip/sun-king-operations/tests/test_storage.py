import numpy as np
import pytest

from sun_king.storage.scenario import BatteryParams, check_constraints, compare, optimise


def params(**kw):
    d = dict(
        energy_kwh=4000,
        power_kw=2000,
        round_trip_efficiency=0.88,
        soc_min=0.05,
        soc_max=0.95,
        soc_initial=0.3,
        pv_only_charging=True,
        export_limit_kw=3000,
    )
    d.update(kw)
    return BatteryParams(**d)


def day():
    t = np.arange(48)
    pv = np.clip(1200 * np.sin((t - 16) / 18 * np.pi), 0, None)
    price = 60 + 40 * np.exp(-((t - 36) ** 2) / 8) - 20 * np.exp(-((t - 26) ** 2) / 10)
    return price, pv


def test_dp_respects_physical_constraints():
    price, pv = day()
    res = optimise(price, pv, 0.5, params())
    assert check_constraints(res, pv, 0.5, params()) == []
    assert res["soc"].min() >= 0.05 - 1e-9 and res["soc"].max() <= 0.95 + 1e-9
    assert np.all(res["battery_kw"][pv <= 0] >= -1e-9)  # no grid charging when PV-only


def test_dp_dominates_rule_based_and_discloses():
    price, pv = day()
    out = compare(price, pv, 0.5, params(), "GBP", "synthetic")
    s = out["schedules"]
    assert s["optimised_dp"]["modelled_value"] >= s["rule_based"]["modelled_value"] - 1e-6
    assert "not a forecast of achievable market income" in out["disclaimer"]


def test_flat_prices_give_no_arbitrage_value():
    _, pv = day()
    out = compare(np.full(48, 70.0), pv, 0.5, params(), "GBP", "flat")
    assert out["uplift_vs_no_storage"]["optimised_dp"] <= 1e-6


def test_invalid_parameters_rejected():
    price, pv = day()
    with pytest.raises(ValueError):
        optimise(price, pv, 0.5, params(soc_min=0.9, soc_max=0.5))
    with pytest.raises(ValueError):
        optimise(price, pv, 0.5, params(round_trip_efficiency=1.4))
    with pytest.raises(ValueError):
        optimise(price[:10], pv, 0.5, params())
