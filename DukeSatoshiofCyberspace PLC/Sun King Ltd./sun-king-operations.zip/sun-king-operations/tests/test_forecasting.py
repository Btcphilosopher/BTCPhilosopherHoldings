from datetime import timedelta

import numpy as np
import pandas as pd
import pytest

from sun_king.adapters.base import WeatherForecastPoint
from sun_king.adapters.simulator import SimulatedWeatherForecastAdapter
from sun_king.assets.models import Site
from sun_king.core.timeutil import utcnow
from sun_king.forecasting.features import (
    LeakageError,
    LeakageGuard,
    build_rows,
    intraday_targets,
    load_history,
)
from sun_king.forecasting.service import ForecastModelError, evaluate, fit, train_and_evaluate
from sun_king.simulation.plant import PlantSimulator


def test_leakage_guard_rejects_future_inputs():
    now = utcnow()
    g = LeakageGuard(now)
    g.check("ok", [now - timedelta(hours=1)])
    with pytest.raises(LeakageError):
        g.check("nwp", [now + timedelta(minutes=1)])


def test_feature_rows_only_use_data_available_at_issue(seeded, db):
    site = db.get(Site, "site-hlm")
    issue = utcnow().replace(minute=0, second=0, microsecond=0) - timedelta(days=2)
    hist = load_history(db, site.id, issue - timedelta(days=3), issue + timedelta(days=1))
    future_nwp = [
        WeatherForecastPoint(issue, issue + timedelta(hours=1), issue + timedelta(hours=2), 100, 5, 3)
    ]
    with pytest.raises(LeakageError):
        build_rows(db, site, issue, intraday_targets(issue), future_nwp, hist)
    # observed values after the issue time must not leak into persistence
    hist2 = load_history(db, site.id, issue - timedelta(days=3), issue + timedelta(days=1))
    rows_a = build_rows(db, site, issue, intraday_targets(issue), [], hist2)
    hist2.pv_kw.loc[hist2.pv_kw.index >= issue] = 1e6
    rows_b = build_rows(db, site, issue, intraday_targets(issue), [], hist2)
    pd.testing.assert_series_equal(rows_a["persistence_kw"], rows_b["persistence_kw"])


def test_simulated_nwp_respects_availability(seeded):
    from datetime import date

    nwp = SimulatedWeatherForecastAdapter(PlantSimulator(date.today()))
    now = utcnow()
    pts = nwp.latest_issue("site-hlm", now)
    assert all(p.available_time <= now for p in pts)


def _rows(n, const=False, seed=0):
    rng = np.random.default_rng(seed)
    cs = rng.uniform(5, 1000, n)
    nwp = cs * rng.uniform(0.3, 1.0, n)
    actual = np.full(n, 300.0) if const else np.clip(nwp + rng.normal(0, 40, n), 0, None)
    return pd.DataFrame(
        {
            "cs_kw": cs,
            "nwp_kw": nwp,
            "persistence_kw": nwp * 0.9,
            "horizon_h": rng.uniform(0, 6, n),
            "elevation": rng.uniform(5, 40, n),
            "actual_kw": actual,
            "curtailed": False,
            "issue_time": pd.Timestamp("2026-01-01", tz="UTC"),
            "target_time": pd.Timestamp("2026-01-01", tz="UTC"),
        }
    )


def test_model_fallbacks_and_quantile_order():
    small = fit(_rows(40), 3500)
    assert small.status == "baseline_only" and small.models is None
    const = fit(_rows(400, const=True), 3500)
    assert const.status == "baseline_only"
    ok = fit(_rows(600), 3500)
    assert ok.status == "ok"
    p = ok.predict(_rows(100, seed=3))
    assert (p.p10 <= p.p50 + 1e-9).all() and (p.p50 <= p.p90 + 1e-9).all() and (p.p10 >= 0).all()
    ev = evaluate(_rows(200, seed=4), ok, 3500, "intraday")
    assert {
        "model",
        "persistence",
        "nwp_physical",
        "by_horizon",
        "by_generation_level",
        "missing_input_rows",
    } <= set(ev)


def test_train_and_evaluate_on_seeded_history(seeded, db):
    site = db.get(Site, "site-cle")
    nwp = SimulatedWeatherForecastAdapter(PlantSimulator(pd.Timestamp(seeded["anchor_day"]).date()))
    now = utcnow()
    r = train_and_evaluate(db, site, nwp, now - timedelta(days=5), now, "intraday")
    ev = r["evaluation"]
    assert ev["test_rows"] > 0 and ev["status"] in ("ok", "baseline_only")
    assert ev["model"]["n"] > 0 and ev["persistence"]["n"] > 0
    with pytest.raises(ForecastModelError):
        train_and_evaluate(
            db, site, nwp, now + timedelta(days=30), now + timedelta(days=30, hours=1), "intraday"
        )
