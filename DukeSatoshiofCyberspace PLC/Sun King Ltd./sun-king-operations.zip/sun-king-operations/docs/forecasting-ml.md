# Forecasting and machine learning

## Forecasts

* Quantity: site PV AC power (sum of inverters), 30-min means — battery behaviour is excluded.
* **Intraday** (issued hourly, 0–6 h) and **day-ahead** (issued 10:00 site time for the next local day).
* Inputs: synthetic NWP (issues at 00/06/12/18 UTC, available 3 h 30 min later — mimicking real latency),
  clear-sky model, last *available* observation.
* Baselines: **persistence** (clear-sky-index persistence; day-ahead: same time 48 h earlier) and a
  **weather-based physical baseline** (NWP GHI → pvlib site model).
* Model: scikit-learn `GradientBoostingRegressor` with quantile loss (P10/P50/P90). With fewer than 150
  usable training rows or zero target variance, the issued forecast falls back to the physical baseline with
  empirical residual intervals, and `status = baseline_only` is shown.
* Every forecast stores issue time, model name/version, weather source and its issue time, training window.
  `kind = retrospective` runs (observed weather) are labelled and never presented as forecasts.

## Leakage controls

`forecasting/features.py::LeakageGuard` rejects any input available after issue time; NWP issues are
selected by availability time; persistence uses only observations ingested before issue time (so late or
revised data cannot leak); training uses targets observed before the hold-out cut-off; curtailment periods
are excluded from training and scoring. The anomaly model never trains on labels; maintenance outcomes
are used only for evaluation.

## Bounded models

| Purpose | Method | Notes |
|---|---|---|
| Weather-adjusted anomaly detection | `HistGradientBoostingRegressor` on physics-expected output, POA, T_cell, elevation; rolling residual z-score | abstains on missing inputs (reported) |
| Peer comparison | robust z of expected-normalised output per timestamp | transparent |
| Investigation prioritisation | transparent score: severity × confidence × (1 + log10(1 + energy at risk)); logistic regression only with ≥ 30 verified outcomes | currently rule score (insufficient labels) |
| Repeated-fault patterns | episode extraction from status codes, repeats within 30 days, time-of-day | **no remaining-useful-life or failure-date claims** |

## Evaluation (synthetic data — method demonstration, not field evidence)

`sun-king evaluate-ml` writes `docs/evaluation.json`. Result from the build run (14 days of November
history, hold-out = last 6 days):

| Evaluation | Precision | Recall | Events detected | Delay | False-alarm episodes | Abstained |
|---|---|---|---|---|---|---|
| HLM time hold-out | 0.93 | 0.87 | inverter failure ✔ | 0.4 h | 0 | 0 % |
| CLE time hold-out | 1.00 | 0.68 | partial DC loss ✔ | 1.0 h | 0 | 11 % (comms gap, stuck sensor) |
| Train HLM → test CLE (site hold-out) | 1.00 | 0.64 | partial DC loss ✔ | 1.0 h | 0 | 11 % |

Forecast evaluation per site/horizon (MAE by horizon bucket and generation level, skill vs persistence and
the weather baseline, P10–P90 coverage, performance when persistence input is missing) is stored in the
model registry and shown on the Forecasts page. With ~2 weeks of winter data the sample is small; treat
skill figures as indicative.
