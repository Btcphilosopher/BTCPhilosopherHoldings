# Performance metrics

Expected-yield model (`adapters/pvmodel.py`, verified against **pvlib 0.16.1**):
Ineichen clear sky · Erbs decomposition · Hay–Davies transposition ·
`tracking.singleaxis` (backtracking) · SAPM cell temperature (from measured
back-of-module temperature where available) · PVWatts DC (γ from configuration)
· PVWatts inverter with AC clipping. Grid: 5-minute intervals.

## Irradiance basis

Two coplanar POA pyranometers per site are compared each window.
A sensor with >20 % of daylight samples flagged `stuck_value`/`out_of_range`
is excluded; valid sensors disagreeing by >5 % (median) make the basis
`uncertain`. Blocks not coplanar with the sensors use measured GHI →
decomposition → transposition, with a larger stated uncertainty.

## Definitions

| Metric | Formula | Inputs | Window | Exclusions | Uncertainty | Withheld when |
|---|---|---|---|---|---|---|
| Specific yield | E_export / P_DC,STC (kWh/kWp) | settlement-meter register | requested | — | meter class 0.2S (±0.5 %) | export energy incomplete (gaps, meter reset) |
| Performance ratio | (Σ E / P_STC) / (Σ H_POA / G_STC) | export meter power (site) or inverter AC (per inverter), POA | requested, 5-min | recorded curtailment, missing energy, missing POA (both numerator & denominator) | √(sensor 2 %² + meter 0.5 %²) | POA coverage < 95 % of daylight; basis `uncertain`/`unavailable`; arrays not coplanar with sensor (site PR); energy missing > 5 %; insolation < 0.2 kWh/m² |
| Temperature-corrected PR | E / Σ(P_STC·(1+γ(T_cell−25))·G/G_STC) | as above + modelled T_cell | as above | as above | as above | as above |
| Performance index | Σ measured / Σ expected | inverter AC, model expected AC | requested | curtailed, no-telemetry intervals | ±3.5 % coplanar, ±7 % transposed (k=1, configured) | no expected energy |
| Peer z | (index − median) / (1.4826·MAD) | indices of ≥3 inverters | requested | — | — | < 3 inverters |
| Availability | t_available / (t_available + t_unavailable) | status, AC power, POA | intervals with POA ≥ 50 W/m², sun up | curtailed counts as available; no-telemetry excluded | bounds: unknown → unavailable (lower) / available (upper) | no daylight intervals |
| Clipping (estimate) | Σ(AC_unclipped − AC_clipped) where measured ≥ 97 % rating | model | requested | — | low confidence | — |

## Loss categories (kept separate)

`temperature` (modelled), `clipping` (modelled estimate), `curtailment`
(only during *recorded* curtailment), `equipment_failure` (fault status code
present), `unexplained_zero_output` (zero output, no code — uncertain),
`communication_loss_unobserved` (expected energy during telemetry gaps —
**not** counted as lost production), `soiling` (soiling-station estimate),
`unattributed_residual` (includes model error). Each category states basis
and confidence.

## Cleaning

`performance/cleaning.py` estimates cleaning benefit as the change in the
weather-adjusted index between comparable windows (POA ≥ 150 W/m², elevation
≥ 10°, producing intervals, cleaning day excluded) with a day-block bootstrap
90 % CI. Raw before/after output is never presented as proof. Scenario
estimates (recoverable energy, value, cost, break-even soiling, constraints)
are labelled as scenarios.
