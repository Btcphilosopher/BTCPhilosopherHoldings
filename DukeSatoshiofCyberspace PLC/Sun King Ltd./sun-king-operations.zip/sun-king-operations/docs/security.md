# Security and resilience

| Control | Implementation |
|---|---|
| Organisational sign-in | Organisation accounts with bcrypt passwords and short-lived HS256 JWTs (`/api/auth/login`). OIDC SSO is a configured, **deferred** integration point (`SUN_KING_OIDC_ISSUER`). |
| Site-scoped permissions | Roles per site: viewer < field_technician < operator < engineer < manager < admin; org admins see all. Sites without a role return 404 (existence not revealed); insufficient role returns 403. Service accounts are ingest-only. |
| Protected credentials | Docker secrets / `*_FILE` variables for JWT key, DB password, S3 keys, demo password, collector token; production refuses the development secret; adapter credentials referenced by name only. |
| Encrypted connections | Caddy terminates TLS (HSTS, CSP, frame-deny); MinIO bucket server-side encryption; DB on a private network. |
| Audit history | `audit_log` for logins (incl. failures), asset/site changes, ingestion, alert transitions, work orders, evidence, rules, reports, backups, simulator controls; append-only trigger on PostgreSQL. |
| Input validation | Pydantic models with bounds; naive datetimes rejected; query windows capped; NaN/inf → missing; enums/patterns on identifiers. |
| Bounded imports | Ingest batch ≤ 10 000 observations; CSV ≤ 50 000 rows / 20 MB; uploads ≤ 25 MB with type + magic-byte checks; request-size middleware. |
| Backup + tested restoration | `sun-king backup/restore` (gzip JSON, per-table SHA-256, refuses non-empty target, parent-first ordering); automated test restores into a fresh DB and compares every table count and an energy calculation; `scripts/backup.sh` does `pg_dump` + test restore. |
| Disconnected operation | Last-known values always shown with age and `is_current=false`; tablet drafts queue offline; collector spools. |
| Retry budgets / restart recovery | Worker loops back off; job queue leases with `recover_expired`; idempotency keys on ingestion and jobs; duplicate imports detected. |
| Cached ≠ current | Overview, WebSocket and telemetry endpoints report observation time, age and `is_current`; stale data never counts towards available capacity. |
