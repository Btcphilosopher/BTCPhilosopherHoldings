# Energy accounting

| Rule | Implementation |
|---|---|
| Power ≠ energy | `core.units` refuses to add/convert power and energy; kW samples are integrated over time (`energy.accounting.integrate_power`, trapezoid on actual sample times). Tests assert that naive summation differs. |
| Cumulative registers | `difference_register`: differences between readings, linear interpolation at window boundaries, high-water mark against small backwards jitter. |
| Meter resets | A decrease beyond tolerance is a reset: the post-reset reading counts as energy since the reset; the span between the last pre-reset reading and the reset is **unobservable** and reported as a gap (`meter_reset_unobserved`). The day is `incomplete_meter_reset`. An *explicit* estimate (gap filled by integrating the meter's power channel) is reported separately as `estimated_export_kwh`. |
| Roll-over | If the register maximum is known and the previous value was near it, the wrap is added. |
| Irregular sampling | Integration uses real timestamps; boundaries are interpolated only from samples within `max_gap_s`. |
| Missing data | Gaps longer than `max_gap_s` (15 min power / 30 min registers) are *not bridged*: coverage drops and `complete=false`. Missing values never become zero. |
| Estimation | Only via `estimate_gaps_from_reference(...)`, which leaves measured energy unchanged and records `estimation_method`. |
| Double counting | `energy.hierarchy`: a site figure comes from exactly one meter role (`export_settlement` → `site_check` → labelled inverter-sum fallback). Portfolio totals sum one figure per site. Inverter totals are shown only as comparisons and to estimate transformer/aux losses. |
| Time | Stored in UTC (`UTCDateTime` rejects naive datetimes). Site-local days come from `local_day_bounds` and are 23 h / 25 h on DST change days (tested for 29 Mar 2026 and 25 Oct 2026). Buckets are half-open so boundaries are counted once. |
| Completeness | Daily status: `complete` (≥98 % coverage, no reset), `incomplete`, `incomplete_meter_reset`, `in_progress`, `no_data`. Reports list incomplete days instead of filling them. |

Every energy figure returned by the API carries `method`, `coverage`,
`complete`, `gaps`, `flags`, `resets`, `calc_version` and `sources` (links to
the underlying observations).
