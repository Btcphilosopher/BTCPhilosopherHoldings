# Test and check report (build run, 27 Nov 2026)

Environment: Python 3.13, pvlib 0.16.1, scikit-learn 1.9, FastAPI 0.165, SQLAlchemy 2.1, pandas 3.0,
PostgreSQL 16.15 + PostGIS 3.4, Node 22, TypeScript 5.6, Vite 5.4.

| Check | Command | Result |
|---|---|---|
| Unit + integration + end-to-end tests (SQLite) | `pytest` | **63 passed, 1 skipped** (PostgreSQL-only migration test) |
| Same suite on PostgreSQL + PostGIS (schema via Alembic) | `SUN_KING_TEST_DATABASE_URL=… pytest` | **64 passed** |
| Migrations | `alembic upgrade head` → `downgrade base` → `upgrade head`; `alembic check` | pass; no drift |
| Lint | `ruff check src tests scripts migrations` | pass |
| Frontend types / build | `npx tsc -b --noEmit`, `npm run build` | pass |
| UI smoke | Playwright over all 12 pages | no page or console errors |
| Demonstration (12 steps, PostgreSQL, live workers) | `python scripts/demo.py` | all steps completed — see `demo-transcript.md` |
| ML evaluation | `sun-king evaluate-ml` | see `evaluation.json` / `forecasting-ml.md` |
| Docker Compose | — | **not executed** (no Docker daemon in the build environment); YAML parsed and validated only |

## What the tests cover

* **Units**: conversions, power/energy separation, refusing to relabel kW as kWh.
* **Energy**: constant and linear-ramp integration on irregular samples, gaps not zero-filled, missing values,
  duplicate timestamps, boundary interpolation and bucket additivity, register differencing, meter reset
  (unobservable span reported), roll-over, jitter (high-water mark), explicit estimation kept separate,
  DST days of 23/24/25 h, naive datetimes rejected, no double counting across meters/portfolio.
* **Quality**: range, unit mismatch/unknown, night offsets vs suspect night irradiance, stuck sensor,
  future/late/out-of-order timestamps, implausible rate, missing values, rating.
* **Ingestion**: raw vs clean, unit conversion, identical duplicates, revisions, out-of-order + late,
  idempotent replay, unknown assets, batch bound, NaN handling.
* **Alerts**: failed inverter attributed from status code; comm loss not reported as failure (meter
  balance incl. battery); underperformance; stuck sensor; no inference at night; persistence; hysteresis;
  acknowledgement does not clear; workflow guards; suppression windows.
* **Performance**: PR computed with adequate inputs and refused otherwise (mixed orientations, no data);
  specific yield withheld on the meter-reset day; inverter comparison and peer z; separation of failure,
  curtailment and communication loss; availability bounds.
* **Forecasting**: leakage guard, late data invisible to earlier issues, NWP availability, fallback on
  too-few rows / zero variance (model failure modes), quantile ordering, evaluation structure, training
  failure raised with no observed generation.
* **Storage**: DP constraints, DP ≥ rule-based, flat prices → no arbitrage, invalid parameters.
* **Permissions**: authentication, site scoping (404 vs 403), viewer read-only, service account ingest-only,
  input bounds, absence of control endpoints.
* **Maintenance**: completion needs evidence, magic-byte check, independent review, manager sign-off,
  offline inspection conflict + explicit resolution, future capture time rejected, bounded spare usage.
* **Restoration**: backup → restore into a fresh database with identical table counts and identical energy
  result; tamper detection; refusal to restore into a non-empty database; job retry budget and restart
  recovery of expired leases.
* **End-to-end**: the 12-step demonstration through the API, and a disconnected site showing last-known
  values with age (never zero).

Bugs found and fixed by these checks during the build: unstable chart query URLs, 5-minute grid
misalignment in the performance model, storage DP terminal valuation, meter-balance check ignoring the
battery, register jitter over-counting, restore ordering for the self-referencing asset table, empty-history
dtype in forecasting, and verification starting before the repair (now a 15-min settling margin).
