# Alerts and investigation

## Rules (`alerts/rules.py`, versioned in `alert_rules`)

| Rule | Condition | Persistence / clear | Notes |
|---|---|---|---|
| stale_telemetry | newest observation older than max(15 min, 3 × nominal interval) | 0 / 5 min | meter balance (meter − battery − reporting inverters + loss allowance) tells whether a silent inverter is still producing |
| inverter_outage | AC < 2 % rating while POA ≥ 150 W/m² **and** (peers' index ≥ 0.5 **or** fault code) | 15 / 15 min | suspended while telemetry is stale; never raised at low irradiance or at night |
| underperformance | index < 0.88 (clears > 0.94) over 60 min, ≥ 8 comparable intervals | 60 / 60 min | requires POA ≥ 120 W/m², excludes curtailment; if the whole site is low, only an inverter ≥ 6 pts below peers is flagged |
| sensor_disagreement | stuck-value flags or > 10 % disagreement with the reference | 30 / 30 min | |
| abnormal_temperature | module > 75 °C, inverter > 80 °C, battery > 45 °C | 15 / 15 min | |
| missing_meter_data | export-register coverage < 90 % in last hour | 15 / 15 min | distinguishes meter link loss from site disconnection |
| maintenance_overdue | schedule `next_due` passed | 0 | |
| equipment_status | configured status codes (e.g. 312, 401) | 5 / 10 min | |

Every alert stores `rule_id`, `rule_version`, the parameter snapshot,
`threshold_source`, affected assets, supporting evidence (including
observation ids linking to raw records), attribution + confidence, and
energy at risk (estimate).

**Persistence** — a condition must hold for `persistence_s` before an alert
is created. **Hysteresis** — separate trigger/clear thresholds and
`clear_persistence_s`. **Suppression** — explicit, recorded windows
(`alert_suppressions`), plus rule-level suppression (stale telemetry replaces
outage/underperformance; curtailment excludes intervals).

**As-of evaluation** — the engine only sees observations whose ingestion time
is ≤ the evaluation time, so historical replays have no look-ahead.

## Workflow

Detected → Assigned → Investigating → Action planned → Resolved → Verified.

* Acknowledge records who saw it; it never changes status or the condition.
* The condition flag is controlled only by the engine.
* Resolving while the condition is active needs a recorded `force_reason`.
* Verification needs an inactive condition and (via `/verify`) a passing
  post-maintenance check: inverter index ≥ 0.92 and within 5 points of peers
  over ≥ 1.5 h of comparable daylight, starting 15 min after completion, with
  no fault code.
