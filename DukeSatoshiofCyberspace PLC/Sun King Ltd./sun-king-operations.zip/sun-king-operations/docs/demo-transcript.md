# SUN KING demonstration transcript

Run at 2026-11-27T12:35:35.013965+00:00 against `http://localhost:8000`. All sites and data are fictional and synthetic.

## 1. Portfolio overview
- Installed: 10200 kWp DC · 8500 kW AC · export limit 7800 kW
- Current export 2088 kW (all sites current: True)
- Today's measured export 6272 kWh, bases {'site-cle': 'meter:export_settlement', 'site-hlm': 'meter:export_settlement'} (one meter per site — no double counting)
- Calder Edge Solar Farm: state **live**, newest observation 2 s old, 3 active alert conditions
- Hollin Moor Solar Farm: state **partial**, newest observation 2 s old, 1 active alert conditions

## 2. Site and asset hierarchy (Hollin Moor)
- `HLM-GRID` grid_connection 4800.0 kW
  - `HLM-TX1` transformer 5500.0 kVA
  - `HLM-MTR-EXP` meter  
- `HLM-B1` array_block 1500.0 kWp
  - `HLM-INV-01` inverter 1250.0 kW
  - `HLM-CB-01-1` combiner_box 750.0 kWp
  - `HLM-CB-01-2` combiner_box 750.0 kWp
- `HLM-B2` array_block 1500.0 kWp
  - `HLM-INV-02` inverter 1250.0 kW
  - `HLM-CB-02-1` combiner_box 750.0 kWp
  - `HLM-CB-02-2` combiner_box 750.0 kWp
- `HLM-B3` array_block 1500.0 kWp
  - `HLM-INV-03` inverter 1250.0 kW
  - `HLM-CB-03-1` combiner_box 750.0 kWp
  - `HLM-CB-03-2` combiner_box 750.0 kWp
- `HLM-B4` array_block 1500.0 kWp
  - `HLM-INV-04` inverter 1250.0 kW
  - `HLM-CB-04-1` combiner_box 750.0 kWp
  - `HLM-CB-04-2` combiner_box 750.0 kWp
- `HLM-WS1` weather_station  
  - `HLM-GHI` sensor  
  - `HLM-PYR1` sensor  
  - `HLM-PYR2` sensor  
  - `HLM-SOIL` sensor  
  - `HLM-TMOD` sensor  
- Electrical connectivity is a separate graph: 30 edges, e.g. HLM-INV-01→HLM-TX1 (ac_lv), HLM-INV-02→HLM-TX1 (ac_lv), HLM-INV-03→HLM-TX1 (ac_lv), HLM-INV-04→HLM-TX1 (ac_lv)
- Monitoring-point mappings are a third, separate view: 38 points (e.g. `HLM.INV01.AC_POWER` → HLM-INV-01/ac_power)

## 3. Live simulated measurements
- HLM-GHI ghi = 179.0829 W/m2 · age 3 s · quality good
- HLM-INV-01 ac_energy = 3030985.5002 kWh · age 3 s · quality good
- HLM-INV-01 ac_power = 440.9114 kW · age 3 s · quality good
- HLM-INV-01 dc_current = 399.4 A · age 3 s · quality good
- HLM-INV-01 dc_power = 449.1503 kW · age 3 s · quality good
- HLM-INV-01 dc_voltage = 1124.5628 V · age 3 s · quality good
- HLM-INV-01 inverter_temperature = 25.4733 degC · age 3 s · quality good
- HLM-INV-01 status_code = 0.0 code · age 3 s · quality good

## 4. Detect an underperforming inverter
- **Central inverter INV-04 (CLE-INV-04) producing 85% of weather-adjusted expectation** — index 0.841 vs peers [0.974, 0.97, 0.965] (threshold 0.88, rule `underperformance` v1, source: Performance engineering guideline PE-07 (fictional): index < 0.88 for 1 h; clears > 0.94)
- Attribution: uncertain (medium) — Underperformance relative to model and peers; cause not yet attributed (soiling, string/fuse loss, shading, MPPT, or model error).
  - CLE-INV-01: index 0.9944 · peer z 1.34 · basis measured GHI transposed (Erbs + Hay–Davies)
  - CLE-INV-02: index 0.9847 · peer z -0.01 · basis measured GHI transposed (Erbs + Hay–Davies)
  - CLE-INV-03: index 0.9848 · peer z 0.01 · basis measured GHI transposed (Erbs + Hay–Davies)
  - CLE-INV-04: index 0.8509 · peer z -18.61 · basis measured POA (coplanar)
- Site PR at Calder Edge: **not_computed** — ['site has arrays in orientations other than the POA sensor plane; a single-plane site PR would be misleading — use per-inverter PR for coplanar blocks or the expected-energy index']

## 5. Equipment failure vs missing telemetry
- HLM-INV-03: `inverter_outage` attributed **equipment_failure** (high); status code 312 'DC insulation fault', POA 281.8 W/m², peers at index 0.968
- CLE-INV-02: `stale_telemetry` attributed **communication_loss** — Site meter balance implies ≈195 kW from unreported inverter(s): equipment likely producing; monitoring link loss only. Not an equipment failure.
  - meter balance evidence: {'site_meter_kw': 321.7, 'battery_kw': -500.0, 'reporting_inverters_kw': 638.6, 'implied_unreported_kw': 195.1}

## 6. Create a work order
- Created `wo-a7991f57c815` (urgent) — safety notice: “This work order does not certify electrical safety. Isolation, permits-to-work and safe-working procedures must follow the organisation's authorised safety management system.”
- Alert → assigned → investigating; work order → assigned → in progress

## 7. Field inspection evidence
- Inspection `insp-f2e7742d4717` synced; device capture time preserved: 2026-11-26T11:16:00+00:00
- Photo evidence stored: sha256 a87e1d4612cbeb8f… (1147 bytes)
- Work order completed at 2026-11-26T13:16:00+00:00 (recorded repair time)

## 8. Verify post-maintenance performance
- Verification **PASSED**: recovered — index 0.966 vs peer median 0.9712 over 3.42 h; alert status now `verified`

## 9. Day-ahead forecast
- Forecast `fc-e0fec6d9b211` issued 2026-11-27T12:35:37.053255+00:00 · model gbm_quantile fc-1.0 (status ok) · weather sim-nwp issued 2026-11-27T06:00:00+00:00
- Peak P50 1041 kW at 2026-11-28T13:00:00+00:00 (P10–P90 661–1330 kW); baselines: weather 1274.99, persistence 1399.83
- Held-out evaluation: model MAE 324.6 kW vs persistence 443.51 vs weather 353.66; P10–P90 coverage 0.946

## 10. Energy completeness
- 2026-11-21 (24 h): **complete** · measured 2272 kWh · coverage 1.000 
- 2026-11-22 (24 h): **incomplete_meter_reset** · measured 5373 kWh · coverage 0.997, estimate incl. gap fill 5437 · resets 1
- 2026-11-23 (24 h): **complete** · measured 8152 kWh · coverage 1.000 
- 2026-11-24 (24 h): **complete** · measured 3909 kWh · coverage 1.000 
- 2026-11-25 (24 h): **complete** · measured 4128 kWh · coverage 1.000 
- 2026-11-26 (24 h): **complete** · measured 6062 kWh · coverage 1.000 
- 2026-11-27 (24 h): **in_progress** · measured 4910 kWh · coverage 1.000, estimate incl. gap fill 4910 

## 11. Storage scenario (simulation only)
- No storage GBP 90.69 · rule-based 93.84 · optimised 124.92 · constraint violations []
- Modelled scenario only. Values depend on the stated price series and constraints and are not a forecast of achievable market income. No commands are sent to the battery.

## 12. Source-linked operational report
- Report `rpt-ddb17e61df1a` sha256 1dc3b3a7e309fe6c… · formats: /api/reports/rpt-ddb17e61df1a.json, /api/reports/rpt-ddb17e61df1a.html, /api/reports/rpt-ddb17e61df1a.csv
  - Calder Edge Solar Farm: period measured export 16681 kWh, complete=True (incomplete days: []); PR not_computed
  - Hollin Moor Solar Farm: period measured export 29896 kWh, complete=False (incomplete days: ['2026-11-22']); PR ok
- Example source link: `/api/telemetry/observations?asset_id=CLE-MTR-EXP&measurement_type=export_energy&start=2026-11-21T00:00:00+00:00&end=2026-11-22T00:00:00+00:00`
