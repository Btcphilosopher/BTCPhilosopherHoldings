# Architecture

SUN KING is a **modular monolith**: one Python package (`src/sun_king`) with
strict module boundaries, deployed as several processes from one image.

```
            ┌───────────── ot_net (internal) ─────────────┐
 equipment ─┤ collector (read-only adapters, spool, retry) │──HTTPS──┐
            └──────────────────────────────────────────────┘         │ ingest-only token
                                                                     ▼
 browser ──HTTPS/WSS──► web (Caddy: TLS, CSP, static React) ──► api (FastAPI, WebSocket)
                                                                     │
                                       worker (simulator, alert     │
                                       evaluation, job queue) ──────┤
                                                                     ▼
                                     PostgreSQL 16 + PostGIS        MinIO (S3) object storage
                                     (raw/clean telemetry,          (photos, documents, manuals,
                                      register, alerts, …)           inspection evidence)
```

## Modules

| Module | Responsibility |
|---|---|
| `core` | units (dimension-checked), UTC/local time, DB base types |
| `assets` | portfolio/site/asset register; physical hierarchy, electrical connectivity, monitoring points (three separate tables) |
| `telemetry` | ingestion (duplicates, revisions, ordering, idempotency), raw vs clean storage, freshness |
| `quality` | validation rules → quality level + flags, solar-geometry helpers |
| `energy` | power integration, register differencing, reset/roll-over, completeness, meter hierarchy |
| `performance` | pvlib-based expected yield, irradiance basis, PR, availability, losses, cleaning analysis |
| `alerts` | rule engine (persistence, hysteresis, suppression), investigation workflow, recovery verification |
| `maintenance` | work orders, inspections (offline sync), defects, evidence, spares, contractors, cleaning, vegetation |
| `forecasting` | intraday/day-ahead forecasts, baselines, leakage guard, evaluation |
| `ml` | anomaly detection, peer comparison, repeated-fault patterns, prioritisation |
| `storage` | read-only battery views, schedule optimisation (simulation) |
| `commercial` | contracts, prices, statements, receipts, costs, valuation estimates, lost-revenue scenarios |
| `adapters` | typed adapter protocols, simulator, CSV import, live HTTPS template, object store, pvlib adapter |
| `simulation` | deterministic plant/weather simulator and the demo seeder |
| `reporting` | overview figures and source-linked reports (JSON/HTML/CSV) |
| `workers` | background loops, durable job queue, OT collector |
| `admin` | users, site roles, audit log, jobs, adapter configs, backup/restore |
| `api` | HTTP + WebSocket interface |

## Time-series storage

* `raw_observations` — append-only (PostgreSQL trigger blocks UPDATE/DELETE),
  every revision kept, original unit and value, source flags, batch id.
* `clean_observations` — one row per stream timestamp, canonical units,
  quality level + flags, link to the raw record and validation version.
* Calculated values (`energy_calculations`, reports, forecasts) are separate tables.
* Indexing: composite B-tree `(asset_id, measurement_type, observation_time)`
  plus BRIN on `observation_time` (cheap for append-ordered data),
  `(site_id, observation_time)` for site windows.
* TimescaleDB is **optional and not required**. To adopt it, change the
  cleaned table's primary key to include `observation_time` and call
  `create_hypertable`; the ORM and queries do not depend on it.

## Live updates

`/ws/live?token=…` pushes a per-site snapshot (newest observation, age,
`is_current`, export power with its observation time, active alert count)
every 5 s when it changes. Snapshots are computed from the database so the
API and worker can run in separate processes.

## Background work

`sun-king worker` runs loops with per-loop retry budgets and back-off:
simulator ingestion (30 s), alert evaluation (60 s), scheduler (enqueue
day-ahead forecasts after 10:00 site time) and the durable job queue (leases,
`FOR UPDATE SKIP LOCKED`, restart recovery of expired leases).

## Geospatial

Sites and assets store WGS84 latitude/longitude; migration `0002` adds
PostGIS `geography(Point,4326)` generated columns with GiST indexes, used by
`GET /api/sites/nearby` (SQLite falls back to haversine).
