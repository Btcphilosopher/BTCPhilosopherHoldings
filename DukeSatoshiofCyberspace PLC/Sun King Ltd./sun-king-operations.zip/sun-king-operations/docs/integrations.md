# Equipment and data integrations

Typed, **read-only** adapter protocols (`adapters/base.py`): inverter monitoring, site meters, weather
stations, historians, battery monitoring, weather forecasts, commercial imports.

| Adapter | Status |
|---|---|
| Simulator (all telemetry kinds) | **Implemented — default** |
| Simulated NWP weather forecast | **Implemented** (synthetic, with availability latency) |
| Historian CSV import (`/api/telemetry/import-csv`) | **Implemented** (bounded rows/size, offset-aware timestamps, idempotent by content hash) |
| Settlement statement CSV import | **Implemented** (currency checked against contract, duplicate refs skipped) |
| Generic read-only HTTPS JSON adapter | **Template only — not integrated** with any vendor |
| Vendor-specific protocols (Modbus/TCP, SunSpec, IEC 61850, OPC UA, vendor clouds) | **Deferred** |

Before any live adapter runs, `check_live_permitted` requires: deployment flag
`SUN_KING_LIVE_ADAPTERS_ENABLED=true`, config `enabled` and `mode=live`, a recorded
`verified_documentation_ref` (protocol, authentication, rate limits and terms checked against the vendor's
official documentation), an HTTPS endpoint whose host is in the config's explicit `allowed_hosts`.
Credentials are referenced by environment/secret name (`credential_ref`); values are never stored in the
database or returned by the API. Adapters never scan networks, enumerate devices or probe endpoints.

**No control**: there are no endpoints, adapter methods or job types that write set-points, switch
inverters, change protection settings or send any electrical command. The battery module is read-only;
storage schedules are simulations. A test asserts that no control-style routes exist.

**OT boundary**: `collector` runs on an internal Docker network (`ot_net`) with no database access, uses an
ingest-only service token, spools to disk when the API is unreachable (bounded), retries within a budget
and uses idempotency keys so retries never double-ingest.
