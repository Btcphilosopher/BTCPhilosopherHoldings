# Maintenance and field inspections

* **Work orders**: draft → scheduled/assigned → in progress → completed → reviewed → signed off (or cancelled).
  Completion requires notes and evidence (photo/document) or a submitted inspection; review must be by someone
  other than the assignee; sign-off needs the manager role. Signing off a scheduled task advances the schedule.
* **Safety**: every work order carries the notice *"This work order does not certify electrical safety…"*.
  Permit-to-work references are recorded as references to the organisation's safety system; the platform
  never authorises isolation or energisation.
* **Inspections** (tablet): templates with typed fields; drafts are stored on the device with device capture
  time and a client draft id, queued while offline (visible offline banner) and synchronised when online.
  The server detects stale drafts (`base_version` ≠ server version) and returns `409`; the user explicitly
  chooses *keep mine* or *keep server*; the other version is preserved in `conflict_history`.
* **Evidence**: content-type allow-list, magic-byte check, size limit, SHA-256, object storage key
  `site/entity/id/sha-filename`, served with `nosniff`.
* **Also**: preventive schedules, defects, spare parts (bounded stock decrements), contractors with
  accreditation, cleaning and vegetation records with ecological constraints.
