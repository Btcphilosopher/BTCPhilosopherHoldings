# API

Interactive documentation: `/docs` (Swagger UI) and `/redoc` on a running API. The full schema is in
[`openapi.json`](openapi.json) (74 paths, regenerated with `sun-king export-openapi`).

| Area | Key endpoints |
|---|---|
| Auth | `POST /api/auth/login`, `GET /api/auth/me` |
| Overview | `GET /api/overview`, `GET /api/sites/{id}/overview` |
| Register | `GET/POST /api/sites`, `GET /api/sites/nearby`, `GET /api/sites/{id}/hierarchy|connectivity|monitoring-points`, `GET/POST/PATCH /api/assets`, `GET /api/assets/{id}/history` |
| Telemetry | `POST /api/telemetry/ingest`, `POST /api/telemetry/import-csv`, `GET /api/telemetry/observations|series|raw|raw/{id}|latest|batches` |
| Energy | `GET /api/energy/sites/{id}`, `GET /api/energy/sites/{id}/completeness`, `GET /api/energy/portfolio` |
| Performance | `GET /api/performance/sites/{id}`, `GET …/expected`, `POST /api/performance/cleaning-benefit|cleaning-scenario` |
| Alerts | `GET /api/alerts`, `GET /api/alerts/{id}`, `POST …/acknowledge|transition|verify`, `POST /api/alerts/evaluate`, `GET /api/alerts/rules`, `POST /api/alerts/rules/{id}/versions`, `POST /api/alerts/suppressions`, `GET /api/alerts/priorities` |
| Maintenance | `GET/POST /api/maintenance/work-orders`, `POST …/{id}/transition|parts`, `POST /api/maintenance/evidence`, `GET /api/maintenance/evidence/{id}`, `POST /api/maintenance/inspections/sync`, `GET /api/maintenance/summary|templates|inspections`, `POST /api/maintenance/defects|cleaning` |
| Curtailment | `GET/POST /api/curtailment` |
| Forecasts | `GET /api/forecasts`, `GET /api/forecasts/{id}`, `POST /api/forecasts/issue`, `GET /api/forecasts/evaluation` |
| Storage | `GET /api/storage/sites/{id}`, `POST /api/storage/scenarios` |
| Commercial | `GET /api/commercial/sites/{id}`, `POST /api/commercial/lost-revenue`, `POST /api/commercial/statements/import` |
| Reports | `POST /api/reports/operational`, `GET /api/reports`, `GET /api/reports/{id}.json|html|csv` |
| Admin | `GET/POST /api/admin/users`, `GET /api/admin/audit|adapters|jobs`, `POST /api/admin/backup`, `POST /api/admin/simulator/outage`, `GET /api/health` |
| Live | `WS /ws/live?token=…` |
