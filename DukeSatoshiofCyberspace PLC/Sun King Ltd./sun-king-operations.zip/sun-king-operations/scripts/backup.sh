#!/usr/bin/env sh
# Physical-logical PostgreSQL backup (custom format) with a restore test into a scratch database.
set -eu
export PGPASSWORD="$(cat "${PGPASSWORD_FILE:-/run/secrets/db_password}")"
ts=$(date -u +%Y%m%dT%H%M%SZ)
out=/backups/sunking-$ts.dump
pg_dump --format=custom --no-owner --file="$out" "$PGDATABASE"
sha256sum "$out" > "$out.sha256"
# tested restoration: restore into a temporary database and compare table counts
createdb sunking_restore_test
pg_restore --no-owner --dbname=sunking_restore_test "$out"
for t in assets raw_observations clean_observations alerts work_orders; do
  a=$(psql -tA -d "$PGDATABASE" -c "select count(*) from $t")
  b=$(psql -tA -d sunking_restore_test -c "select count(*) from $t")
  [ "$a" = "$b" ] || { echo "restore check failed for $t ($a vs $b)"; exit 1; }
done
dropdb sunking_restore_test
echo "backup $out verified by test restore"
