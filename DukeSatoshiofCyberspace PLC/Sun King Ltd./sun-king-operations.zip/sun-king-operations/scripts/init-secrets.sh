#!/usr/bin/env sh
# Generate random secrets for docker compose. Run once from the repository root.
set -eu
d=config/secrets
mkdir -p "$d"
rand() { python3 -c "import secrets;print(secrets.token_urlsafe($1))"; }
[ -f $d/db_password ] || rand 24 > $d/db_password
[ -f $d/app_secret ] || rand 48 > $d/app_secret
[ -f $d/demo_password ] || echo "sunking-demo" > $d/demo_password
[ -f $d/s3_user ] || echo "sunking" > $d/s3_user
[ -f $d/s3_password ] || rand 24 > $d/s3_password
printf '[default]\naws_access_key_id = %s\naws_secret_access_key = %s\n' "$(cat $d/s3_user)" "$(cat $d/s3_password)" > $d/s3_credentials
[ -f $d/collector_token ] || echo "replace-with: docker compose run --rm api sun-king token svc-collector" > $d/collector_token
chmod 600 $d/*
echo "secrets written to $d"
