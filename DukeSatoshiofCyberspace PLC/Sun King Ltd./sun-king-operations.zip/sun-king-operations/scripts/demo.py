#!/usr/bin/env python3
"""Reproducible demonstration of SUN KING against a running API.

    python scripts/demo.py --base http://localhost:8000 [--out docs/demo-transcript.md]

Prerequisite: the database has been seeded (``sun-king seed``). The script
walks the twelve demonstration steps through the public API only and writes a
Markdown transcript. All sites and data are fictional and synthetic.
"""

from __future__ import annotations

import argparse
import struct
import sys
import zlib
from datetime import datetime, timedelta, timezone

import httpx

LINES: list[str] = []


def say(s: str = "") -> None:
    print(s)
    LINES.append(s)


def png_photo() -> bytes:
    """A small synthetic 'thermal image' PNG (hot spot on a combiner terminal) — fictional evidence."""
    w = h = 48
    rows = []
    for y in range(h):
        row = bytearray([0])
        for x in range(w):
            d = ((x - 30) ** 2 + (y - 20) ** 2) ** 0.5
            t = max(0.0, 1 - d / 18)
            row += bytes([int(40 + 215 * t), int(30 + 120 * t * t), int(90 * (1 - t))])
        rows.append(bytes(row))

    def chunk(tag, data):
        return (
            struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
        )

    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(b"".join(rows)))
        + chunk(b"IEND", b"")
    )


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://localhost:8000")
    ap.add_argument("--password", default="sunking-demo")
    ap.add_argument("--out", default="docs/demo-transcript.md")
    a = ap.parse_args()
    c = httpx.Client(base_url=a.base, timeout=180, verify=False)

    def login(who):
        r = c.post("/api/auth/login", json={"email": f"{who}@sunking.example", "password": a.password})
        r.raise_for_status()
        return {"Authorization": f"Bearer {r.json()['access_token']}"}

    admin, eng, tech = login("admin"), login("engineer"), login("tech")
    get = lambda u, h=admin: c.get(u, headers=h).raise_for_status().json()  # noqa: E731

    def post(u, body, h=admin, ok=(200, 201)):
        r = c.post(u, json=body, headers=h)
        if r.status_code not in ok:
            raise SystemExit(f"POST {u} failed {r.status_code}: {r.text[:400]}")
        return r.json()

    say(
        f"# SUN KING demonstration transcript\n\nRun at {datetime.now(timezone.utc).isoformat()} against `{a.base}`. "
        "All sites and data are fictional and synthetic.\n"
    )

    say("## 1. Portfolio overview")
    ov = get("/api/overview")
    t = ov["totals"]
    say(
        f"- Installed: {t['dc_kwp']:.0f} kWp DC · {t['ac_kw']:.0f} kW AC · export limit {t['export_limit_kw']:.0f} kW"
    )
    say(
        f"- Current export {t['current_export_kw']:.0f} kW (all sites current: {t['current_export_complete']})"
    )
    te = t["today_export"]
    say(
        f"- Today's measured export {te['energy_kwh']:.0f} kWh, bases {te['bases']} (one meter per site — no double counting)"
    )
    for s in ov["sites"]:
        f = s["telemetry_freshness"]
        say(
            f"- {s['site']['name']}: state **{s['connection_state']}**, newest observation {f['age_s']:.0f} s old, "
            f"{s['alerts']['condition_active']} active alert conditions"
        )

    say("\n## 2. Site and asset hierarchy (Hollin Moor)")
    tree = get("/api/sites/site-hlm/hierarchy")["tree"]

    def walk(n, d=0):
        if d <= 2 and n["asset_type"] not in ("string",):
            say(
                f"{'  ' * d}- `{n['asset_id']}` {n['asset_type']} {n['rated_capacity'] or ''} {n['rated_capacity_unit'] or ''}"
            )
        for ch in n["children"]:
            walk(ch, d + 1)

    for n in tree:
        walk(n)
    edges = get("/api/sites/site-hlm/connectivity")["edges"]
    say(
        f"- Electrical connectivity is a separate graph: {len(edges)} edges, e.g. "
        + ", ".join(f"{e['from']}→{e['to']} ({e['type']})" for e in edges if e["from"].startswith("HLM-INV"))[
            :300
        ]
    )
    pts = get("/api/sites/site-hlm/monitoring-points")["points"]
    say(
        f"- Monitoring-point mappings are a third, separate view: {len(pts)} points (e.g. `{pts[0]['external_tag']}` → {pts[0]['asset_id']}/{pts[0]['measurement_type']})"
    )

    say("\n## 3. Live simulated measurements")
    lat = get("/api/telemetry/latest?site_id=site-hlm")
    for v in sorted(lat["values"], key=lambda v: v["asset_id"])[:8]:
        say(
            f"- {v['asset_id']} {v['measurement_type']} = {v['value']} {v['unit']} · age {v['age_s']:.0f} s · quality {v['quality']}"
        )

    say("\n## 4. Detect an underperforming inverter")
    alerts = get("/api/alerts?include_verified=true")
    up = next(x for x in alerts if x["alert_type"] == "underperformance" and x["subject_id"] == "CLE-INV-04")
    ev = up["evidence"]
    say(
        f"- **{up['title']}** — index {ev['performance_index']:.3f} vs peers {ev['peer_indices']} (threshold {ev['threshold_trigger']}, "
        f"rule `{up['rule_id']}` v{up['rule_version']}, source: {up['threshold_source']})"
    )
    say(f"- Attribution: {up['attribution']} ({up['attribution_confidence']}) — {up['attribution_notes']}")
    day = (datetime.now(timezone.utc) - timedelta(days=1)).date()
    perf = get(
        f"/api/performance/sites/site-cle?start={day}T00:00:00Z&end={day + timedelta(days=1)}T00:00:00Z"
    )
    for r in perf["inverters"]:
        say(
            f"  - {r['asset_id']}: index {r['performance_index']} · peer z {r.get('peer_robust_z')} · basis {r['irradiance_basis']}"
        )
    say(
        f"- Site PR at Calder Edge: **{perf['performance_ratio']['status']}** — {perf['performance_ratio']['reasons']}"
    )

    say("\n## 5. Equipment failure vs missing telemetry")
    outage = next(
        x for x in alerts if x["alert_type"] == "inverter_outage" and x["subject_id"] == "HLM-INV-03"
    )
    comm = next(x for x in alerts if x["alert_type"] == "stale_telemetry" and x["subject_id"] == "CLE-INV-02")
    say(
        f"- HLM-INV-03: `{outage['alert_type']}` attributed **{outage['attribution']}** ({outage['attribution_confidence']}); "
        f"status code {outage['evidence'].get('status_code')} '{outage['evidence'].get('status_text')}', POA "
        f"{outage['evidence'].get('poa_wm2_15min')} W/m², peers at index {outage['evidence'].get('peer_median_index')}"
    )
    say(
        f"- CLE-INV-02: `{comm['alert_type']}` attributed **{comm['attribution']}** — {comm['attribution_notes']}"
    )
    say(
        f"  - meter balance evidence: { {k: comm['evidence'].get(k) for k in ('site_meter_kw', 'battery_kw', 'reporting_inverters_kw', 'implied_unreported_kw')} }"
    )

    say("\n## 6. Create a work order")
    wo = post(
        "/api/maintenance/work-orders",
        {
            "site_id": "site-hlm",
            "title": "HLM-INV-03 DC insulation fault (312)",
            "work_type": "corrective",
            "priority": "urgent",
            "asset_ids": ["HLM-INV-03", "HLM-CB-03-2"],
            "alert_id": outage["id"],
            "contractor_id": "con-pennine-elec",
            "description": "Inverter tripped on DC insulation fault; investigate feeders of CB 3.1/3.2.",
        },
        eng,
    )
    say(f"- Created `{wo['id']}` ({wo['priority']}) — safety notice: “{wo['safety_notice']}”")
    if outage["status"] == "detected":
        post(f"/api/alerts/{outage['id']}/transition", {"to_status": "assigned", "assignee": "u-tech"}, eng)
        post(
            f"/api/alerts/{outage['id']}/transition", {"to_status": "investigating", "note": "on site"}, tech
        )
    post(
        f"/api/maintenance/work-orders/{wo['id']}/transition",
        {"to_status": "assigned", "assigned_to": "u-tech"},
        eng,
    )
    post(f"/api/maintenance/work-orders/{wo['id']}/transition", {"to_status": "in_progress"}, tech)
    say("- Alert → assigned → investigating; work order → assigned → in progress")

    say("\n## 7. Field inspection evidence")
    repaired = datetime.fromisoformat(outage["condition_cleared_at"]) - timedelta(minutes=16)
    insp = post(
        "/api/maintenance/inspections/sync",
        {
            "client_draft_id": f"drf-demo-{wo['id']}",
            "template_id": "tpl-inverter-corrective",
            "site_id": "site-hlm",
            "work_order_id": wo["id"],
            "asset_id": "HLM-INV-03",
            "status": "submitted",
            "captured_at": (repaired - timedelta(hours=2)).isoformat(),
            "device_id": "tablet-demo",
            "answers": {
                "arrival_status_code": 312,
                "visual_condition": "minor damage",
                "dc_insulation_ok": "no",
                "findings": "Rodent damage to DC feeder insulation in CB 3.2",
                "actions": "Feeder section replaced (under permit)",
                "permit_reference": "PTW-HLM-2026-118 (fictional)",
            },
        },
        tech,
    )
    say(
        f"- Inspection `{insp['record']['id']}` synced; device capture time preserved: {insp['record']['captured_at']}"
    )
    r = c.post(
        "/api/maintenance/evidence",
        headers=tech,
        data={
            "site_id": "site-hlm",
            "entity_type": "work_order",
            "entity_id": wo["id"],
            "caption": "Thermal image of CB 3.2 terminal (synthetic)",
            "kind": "photo",
            "captured_at": (repaired - timedelta(hours=2)).isoformat(),
        },
        files={"file": ("cb32-thermal.png", png_photo(), "image/png")},
    )
    r.raise_for_status()
    say(f"- Photo evidence stored: sha256 {r.json()['sha256'][:16]}… ({r.json()['size_bytes']} bytes)")
    post(
        f"/api/maintenance/work-orders/{wo['id']}/transition",
        {
            "to_status": "completed",
            "completion_notes": "Feeder replaced, IR test passed per authorised procedure",
            "repair_summary": "DC feeder section replaced in CB 3.2",
            "at": repaired.isoformat(),
        },
        tech,
    )
    say(f"- Work order completed at {repaired.isoformat()} (recorded repair time)")

    say("\n## 8. Verify post-maintenance performance")
    v = post(f"/api/alerts/{outage['id']}/verify", {"work_order_id": wo["id"]}, eng)
    ver = v["verification"]
    say(
        f"- Verification **{'PASSED' if ver['passed'] else 'NOT PASSED'}**: {ver['reason']} — index {ver.get('index')} vs peer median "
        f"{ver.get('peer_median_index')} over {ver.get('comparable_hours')} h; alert status now `{v['alert']['status']}`"
    )

    say("\n## 9. Day-ahead forecast")
    fc = post("/api/forecasts/issue", {"site_id": "site-hlm", "horizon_type": "day_ahead"}, eng)
    peak = max(fc["values"], key=lambda x: x["p50_kw"])
    say(
        f"- Forecast `{fc['id']}` issued {fc['issue_time']} · model {fc['model_name']} {fc['model_version']} (status {fc['status']}) · "
        f"weather {fc['weather_source']} issued {fc['weather_issue_time']}"
    )
    say(
        f"- Peak P50 {peak['p50_kw']:.0f} kW at {peak['t']} (P10–P90 {peak['p10_kw']:.0f}–{peak['p90_kw']:.0f} kW); "
        f"baselines: weather {peak['nwp_physical_kw']}, persistence {peak['persistence_kw']}"
    )
    e = fc["evaluation"]
    say(
        f"- Held-out evaluation: model MAE {e['model'].get('mae_kw')} kW vs persistence {e['persistence'].get('mae_kw')} vs weather "
        f"{e['nwp_physical'].get('mae_kw')}; P10–P90 coverage {e.get('interval_coverage_p10_p90')}"
    )

    say("\n## 10. Energy completeness")
    for d in get("/api/energy/sites/site-hlm/completeness?days=7")["days"]:
        est = (
            f", estimate incl. gap fill {d['estimated_export_kwh']:.0f}"
            if d["estimated_export_kwh"] and d["status"] != "complete"
            else ""
        )
        say(
            f"- {d['date']} ({d['hours']:.0f} h): **{d['status']}** · measured {d['measured_export_kwh'] or 0:.0f} kWh · coverage "
            f"{d['export_coverage']:.3f}{est} {'· resets ' + str(len(d['meter_resets'])) if d['meter_resets'] else ''}"
        )

    say("\n## 11. Storage scenario (simulation only)")
    st = post("/api/storage/scenarios", {"site_id": "site-cle", "soc_initial": 0.3}, eng)
    s = st["schedules"]
    say(
        f"- No storage {st['currency']} {s['no_storage']['modelled_value']} · rule-based {s['rule_based']['modelled_value']} · "
        f"optimised {s['optimised_dp']['modelled_value']} · constraint violations {s['optimised_dp']['constraint_violations']}"
    )
    say(f"- {st['disclaimer']}")

    say("\n## 12. Source-linked operational report")
    today = datetime.now(timezone.utc).date()
    rep = post(
        "/api/reports/operational",
        {"start_day": str(today - timedelta(days=6)), "end_day": str(today - timedelta(days=1))},
    )
    js = c.get(rep["links"]["json"], headers=admin).json()
    say(f"- Report `{rep['id']}` sha256 {rep['sha256'][:16]}… · formats: {', '.join(rep['links'].values())}")
    for site in js["sites"]:
        e = site["energy"]
        say(
            f"  - {site['name']}: period measured export {e['period_measured_export_kwh']:.0f} kWh, complete={e['period_complete']} "
            f"(incomplete days: {e['incomplete_days']}); PR {site['performance']['performance_ratio']['status']}"
        )
    sample = js["sites"][0]["energy"]["daily"][0]["sources"][0]
    say(f"- Example source link: `{sample}`")
    from pathlib import Path

    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text("\n".join(LINES) + "\n")
    print(f"\ntranscript written to {a.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
