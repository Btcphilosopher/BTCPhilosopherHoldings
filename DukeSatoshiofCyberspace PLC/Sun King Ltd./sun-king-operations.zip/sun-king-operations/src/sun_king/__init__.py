"""SUN KING — Solar Farm Operations."""

__version__ = "0.1.0"
