"""Repeated-fault pattern analysis and investigation prioritisation.

These are descriptive statistics over recorded events. They do **not**
estimate remaining useful life or predict failure dates — that would need
longitudinal failure histories this dataset does not contain.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import timedelta

import numpy as np
import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from sun_king.alerts.models import Alert
from sun_king.telemetry.models import CleanObservation

NO_RUL = (
    "Descriptive pattern analysis only. No remaining-useful-life or failure-date estimate is made: the "
    "available history is too short and lacks longitudinal failure outcomes."
)


def fault_episodes(session: Session, site_id: str, start, end) -> list[dict]:
    rows = session.execute(
        select(CleanObservation.asset_id, CleanObservation.observation_time, CleanObservation.value)
        .where(
            CleanObservation.site_id == site_id,
            CleanObservation.measurement_type == "status_code",
            CleanObservation.observation_time >= start,
            CleanObservation.observation_time < end,
        )
        .order_by(CleanObservation.asset_id, CleanObservation.observation_time)
    ).all()
    eps = []
    cur: dict[str, dict] = {}
    for aid, t, v in rows:
        code = int(v) if v is not None else None
        c = cur.get(aid)
        if code is not None and code >= 100:
            if c is None or c["code"] != code:
                if c:
                    eps.append(c)
                cur[aid] = {"asset_id": aid, "code": code, "start": t, "end": t}
            else:
                c["end"] = t
        elif c is not None:
            eps.append(c)
            cur.pop(aid)
    eps.extend(cur.values())
    return eps


def repeated_faults(session: Session, site_id: str, start, end, repeat_window_days: int = 30) -> dict:
    eps = fault_episodes(session, site_id, start, end)
    by = defaultdict(list)
    for e in eps:
        by[(e["asset_id"], e["code"])].append(e)
    patterns = []
    for (aid, code), lst in by.items():
        lst.sort(key=lambda e: e["start"])
        repeats = sum(
            1
            for a, b in zip(lst, lst[1:], strict=False)
            if b["start"] - a["end"] <= timedelta(days=repeat_window_days)
        )
        hours = [e["start"].hour for e in lst]
        patterns.append(
            {
                "asset_id": aid,
                "code": code,
                "episodes": len(lst),
                "repeats_within_window": repeats,
                "total_duration_h": round(
                    sum((e["end"] - e["start"]).total_seconds() for e in lst) / 3600, 2
                ),
                "start_hours_utc": hours,
                "repeat_flag": repeats > 0,
            }
        )
    alerts = session.scalars(select(Alert).where(Alert.site_id == site_id)).all()
    by_type = defaultdict(int)
    for a in alerts:
        by_type[(a.subject_id, a.alert_type)] += 1
    return {
        "site_id": site_id,
        "window": [str(start), str(end)],
        "fault_code_patterns": patterns,
        "alert_counts": [
            {"subject": k[0], "alert_type": k[1], "count": v} for k, v in sorted(by_type.items())
        ],
        "statement": NO_RUL,
    }


def prioritise(session: Session, site_ids: list[str], min_labelled: int = 30) -> dict:
    """Rank open alerts. A logistic model is used only with enough labelled outcomes; otherwise the transparent
    rule score (severity × confidence × log energy at risk) is used and the reason is reported."""
    open_alerts = session.scalars(
        select(Alert).where(Alert.site_id.in_(site_ids), Alert.status != "verified")
    ).all()
    labelled = session.scalars(select(Alert).where(Alert.status == "verified")).all()
    method = "rule_score"
    reason = f"{len(labelled)} verified outcomes < {min_labelled} required for a learned model"
    scores = {a.id: a.priority_score or 0.0 for a in open_alerts}
    if len(labelled) >= min_labelled:
        from sklearn.linear_model import LogisticRegression

        X = np.array(
            [
                [
                    {"info": 0, "warning": 1, "critical": 2}[a.severity],
                    np.log1p(a.energy_at_risk_kwh or 0),
                    1.0 if a.attribution == "equipment_failure" else 0.0,
                ]
                for a in labelled
            ]
        )
        y = np.array([1 if a.attribution in ("equipment_failure",) else 0 for a in labelled])
        if len(set(y)) == 2:
            lr = LogisticRegression().fit(X, y)
            for a in open_alerts:
                x = [
                    [
                        {"info": 0, "warning": 1, "critical": 2}[a.severity],
                        np.log1p(a.energy_at_risk_kwh or 0),
                        1.0 if a.attribution == "equipment_failure" else 0.0,
                    ]
                ]
                scores[a.id] = float(lr.predict_proba(x)[0, 1])
            method, reason = "logistic_regression", f"trained on {len(labelled)} verified outcomes"
    ranked = sorted(open_alerts, key=lambda a: (-(scores[a.id]), a.first_detected_at))
    return {
        "method": method,
        "reason": reason,
        "ranking": [
            {
                "alert_id": a.id,
                "title": a.title,
                "score": round(scores[a.id], 3),
                "severity": a.severity,
                "condition_active": a.condition_active,
                "energy_at_risk_kwh": a.energy_at_risk_kwh,
                "status": a.status,
            }
            for a in ranked
        ],
    }


def peer_comparison(df: pd.DataFrame) -> pd.DataFrame:
    """Robust z-score of each inverter's expected-normalised output against peers at each timestamp."""
    d = df[(df.elevation > 5) & (df.poa > 50) & df.y.notna() & (df.exp_norm > 0.02)].copy()
    d["ratio"] = d.y / d.exp_norm
    g = d.groupby("t")["ratio"]
    d["peer_median"] = g.transform("median")
    d["peer_mad"] = g.transform(lambda s: np.median(np.abs(s - np.median(s))) * 1.4826).clip(lower=0.02)
    d["peer_z"] = (d.ratio - d.peer_median) / d.peer_mad
    return d[["t", "asset_id", "ratio", "peer_median", "peer_z"]]
