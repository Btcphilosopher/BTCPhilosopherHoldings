"""Evaluation harness for the bounded ML models against the simulator's ground truth.

* Anomaly detection: train on the earliest part of the history, evaluate on the
  later part (time hold-out) for each site, and train on HLM / evaluate on CLE
  (site hold-out). Reports interval precision/recall, event detection and delay,
  false-alarm episodes and abstentions on missing inputs.
* Forecasting: time hold-out per site and horizon (see forecasting.service).

Labels come from the simulator's injected-event list and are used **only** for
evaluation.
"""

from __future__ import annotations

import json
from datetime import date, timedelta
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from sun_king.admin.models import AdapterConfig
from sun_king.assets.models import Site
from sun_king.core.timeutil import utcnow
from sun_king.ml import anomaly
from sun_king.simulation.plant import PlantSimulator


def run(session: Session, out_path: str | None = "docs/evaluation.json") -> dict:
    cfg = session.get(AdapterConfig, "sim-all")
    anchor = date.fromisoformat((cfg.settings or {})["anchor_day"])
    plant = PlantSimulator(anchor)
    now = utcnow()
    start = now - timedelta(days=14)
    split = now - timedelta(days=6)
    res: dict = {"generated": now.isoformat(), "anchor_day": anchor.isoformat(), "anomaly": {}, "notes": []}
    frames = {}
    for site in session.scalars(select(Site)):
        frames[site.id] = anomaly.site_frame(session, site.id, start, now)
    for sid, df in frames.items():
        tr = df[df.t < split]
        te = df[df.t >= split]
        m = anomaly.train(tr)
        if m.model is None:
            res["anomaly"][f"{sid}:time_holdout"] = {"status": m.status, "notes": m.notes}
            continue
        sc = anomaly.score(m, te)
        lab = anomaly.truth_labels(sc, [e for e in plant.events if e.site_id == sid])
        res["anomaly"][f"{sid}:time_holdout"] = {
            "train_rows": m.n_train,
            "train_until": split.isoformat(),
            **anomaly.evaluate(sc, lab, [e for e in plant.events if e.site_id == sid]),
        }
    if "site-hlm" in frames and "site-cle" in frames:
        m = anomaly.train(frames["site-hlm"])
        sc = anomaly.score(m, frames["site-cle"][frames["site-cle"].t >= split])
        ev = [e for e in plant.events if e.site_id == "site-cle"]
        res["anomaly"]["train_hlm_test_cle:site_holdout"] = {
            "train_rows": m.n_train,
            **anomaly.evaluate(sc, anomaly.truth_labels(sc, ev), ev),
        }
    from sun_king.forecasting.models import ModelRegistryEntry

    res["forecasting"] = {
        r.name: r.evaluation
        for r in session.scalars(select(ModelRegistryEntry).order_by(ModelRegistryEntry.trained_at))
    }
    res["notes"].append(
        "Synthetic data, ~2 weeks of November history: results show the evaluation method works; they are not "
        "evidence of field performance. No remaining-useful-life claims are made."
    )
    if out_path:
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        Path(out_path).write_text(json.dumps(res, indent=1, default=str))
    return res
