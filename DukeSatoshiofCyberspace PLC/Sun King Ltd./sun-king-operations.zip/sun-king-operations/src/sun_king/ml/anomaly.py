"""Weather-adjusted anomaly detection (bounded scikit-learn model).

Model: ``HistGradientBoostingRegressor`` predicting normalised inverter output
(measured kW / rated kW) from physics-based expected output, POA, cell
temperature and solar elevation. The anomaly score is the 1-hour rolling mean
residual divided by the training residual spread. An interval is flagged when
the score stays below −``z`` for ``min_consecutive`` intervals.

Leakage controls: training uses only an earlier time window; labels from
maintenance outcomes or the simulator ground truth are used for *evaluation
only*, never for training. Training rows exclude intervals with a fault status
code (known at the time) and recorded curtailment.

The model abstains (no score) when inputs are missing; abstentions are
reported, not silently counted as normal.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sqlalchemy.orm import Session

from sun_king.performance.analysis import classify_intervals, run_site_model

FEATURES = ["exp_norm", "poa", "tcell", "elevation"]


@dataclass
class AnomalyModel:
    model: HistGradientBoostingRegressor | None
    resid_sd: float
    n_train: int
    status: str
    notes: list[str]


def site_frame(session: Session, site_id: str, start: datetime, end: datetime) -> pd.DataFrame:
    run = run_site_model(session, site_id, start, end)
    from sun_king.adapters.pvmodel import solar_elevation

    elev = solar_elevation(run.site.latitude, run.site.longitude, run.grid)
    frames = []
    for iid, e in run.expected.items():
        cls = classify_intervals(run, iid)
        rated = float(e["rated_kw"].iloc[0])
        meas = run.measured_ac[iid] if iid in run.measured_ac else pd.Series(np.nan, index=run.grid)
        status = run.status[iid] if iid in run.status else pd.Series(np.nan, index=run.grid)
        frames.append(
            pd.DataFrame(
                {
                    "t": run.grid,
                    "site_id": site_id,
                    "asset_id": iid,
                    "y": (meas / rated).to_numpy(),
                    "exp_norm": (e["ac_kw"] / rated).to_numpy(),
                    "poa": e["poa"].to_numpy(),
                    "tcell": e["tcell"].to_numpy(),
                    "elevation": elev,
                    "cls": cls.to_numpy(),
                    "status": status.to_numpy(),
                    "curtailed": run.curtailed.to_numpy(),
                }
            )
        )
    return pd.concat(frames, ignore_index=True)


def train(df: pd.DataFrame, min_rows: int = 300) -> AnomalyModel:
    d = df[
        (df.elevation > 5)
        & (df.poa > 50)
        & df.y.notna()
        & df[FEATURES].notna().all(axis=1)
        & ~df.curtailed.astype(bool)
        & ~(df.status.fillna(0) >= 100)
    ]
    if len(d) < min_rows:
        return AnomalyModel(None, np.nan, len(d), "insufficient_data", [f"{len(d)} rows < {min_rows}"])
    m = HistGradientBoostingRegressor(
        max_iter=200, learning_rate=0.05, max_depth=4, loss="absolute_error", random_state=0
    )
    m.fit(d[FEATURES], d["y"])
    resid = d["y"] - m.predict(d[FEATURES])
    sd = float(1.4826 * np.median(np.abs(resid - np.median(resid))))
    return AnomalyModel(m, max(sd, 0.005), len(d), "ok", [])


def score(model: AnomalyModel, df: pd.DataFrame, z: float = 4.0, min_consecutive: int = 4) -> pd.DataFrame:
    out = df.copy()
    usable = (
        (out.elevation > 5)
        & (out.poa > 50)
        & out[FEATURES].notna().all(axis=1)
        & out.y.notna()
        & ~out.curtailed.astype(bool)
    )
    out["abstained"] = (out.elevation > 5) & (out.poa > 50) & ~usable
    out["pred"] = np.nan
    if model.model is not None and usable.any():
        out.loc[usable, "pred"] = model.model.predict(out.loc[usable, FEATURES])
    out["resid"] = out["y"] - out["pred"]
    out["score"] = (
        out.groupby("asset_id")["resid"].transform(lambda s: s.rolling(12, min_periods=6).mean())
        / model.resid_sd
    )
    flag = out["score"] < -z
    out["flag"] = flag & out.groupby("asset_id")["score"].transform(
        lambda s: (s < -z).rolling(min_consecutive, min_periods=min_consecutive).sum() >= min_consecutive
    ).fillna(False)
    return out


def truth_labels(df: pd.DataFrame, events: list) -> pd.Series:
    lab = pd.Series(False, index=df.index)
    for ev in events:
        if ev.type not in ("inverter_failure", "partial_dc_loss"):
            continue
        end = pd.Timestamp(ev.end) if ev.end else pd.Timestamp.max.tz_localize("UTC")
        lab |= (df.asset_id == ev.asset_id) & (df.t >= pd.Timestamp(ev.start)) & (df.t < end)
    return lab & (df.elevation > 5) & (df.poa > 50)


def evaluate(scored: pd.DataFrame, labels: pd.Series, events: list) -> dict:
    s = scored[(scored.elevation > 5) & (scored.poa > 50)]
    lab = labels.loc[s.index]
    flag = s["flag"].astype(bool)
    tp = int((flag & lab).sum())
    fp = int((flag & ~lab).sum())
    fn = int((~flag & lab & ~s.abstained).sum())
    days = max(s.t.dt.date.nunique(), 1)
    ev_rows = []
    for ev in events:
        if ev.type not in ("inverter_failure", "partial_dc_loss"):
            continue
        m = (s.asset_id == ev.asset_id) & (s.t >= pd.Timestamp(ev.start))
        if ev.end:
            m &= s.t < pd.Timestamp(ev.end)
        if not m.any():
            continue
        hits = s[m & flag]
        ev_rows.append(
            {
                "event": ev.id,
                "asset_id": ev.asset_id,
                "type": ev.type,
                "detected": bool(len(hits)),
                "first_detection": hits.t.min().isoformat() if len(hits) else None,
                "delay_h": round(
                    (hits.t.min() - max(pd.Timestamp(ev.start), s[m].t.min())).total_seconds() / 3600, 2
                )
                if len(hits)
                else None,
            }
        )
    # false-alarm episodes: contiguous flagged runs not overlapping any labelled interval
    fa_eps = 0
    for _, g in s.assign(fl=flag, lab=lab).groupby("asset_id"):
        run = (g.fl != g.fl.shift()).cumsum()
        for _, r in g[g.fl].groupby(run[g.fl]):
            if not r.lab.any():
                fa_eps += 1
    return {
        "interval_level": {
            "true_positive": tp,
            "false_positive": fp,
            "false_negative": fn,
            "precision": round(tp / (tp + fp), 3) if tp + fp else None,
            "recall": round(tp / (tp + fn), 3) if tp + fn else None,
        },
        "events": ev_rows,
        "missed_events": [e["event"] for e in ev_rows if not e["detected"]],
        "false_alarm_episodes": fa_eps,
        "false_alarm_episodes_per_inverter_day": round(fa_eps / (days * s.asset_id.nunique()), 4),
        "abstained_intervals": int(s.abstained.sum()),
        "abstained_fraction": round(float(s.abstained.mean()), 4),
        "evaluated_days": days,
    }
