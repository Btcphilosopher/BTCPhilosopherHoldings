"""Storage schedule comparison (simulation only — never an equipment command).

Dynamic programming over a discretised state-of-charge grid finds the
schedule that maximises modelled value subject to:

* charge/discharge power limits, SoC min/max and usable energy;
* one-way efficiencies η_c = η_d = √(round-trip efficiency);
* optional grid-export limit: discharge + PV export ≤ export limit;
* optional "PV-only charging": charging power ≤ available PV in the interval.

The result is a *modelled* value under the stated price assumptions; it is
not a claim of achievable market income.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

DISCLAIMER = (
    "Modelled scenario only. Values depend on the stated price series and constraints and are not a "
    "forecast of achievable market income. No commands are sent to the battery."
)


@dataclass
class BatteryParams:
    energy_kwh: float
    power_kw: float
    round_trip_efficiency: float
    soc_min: float
    soc_max: float
    soc_initial: float
    pv_only_charging: bool = True
    export_limit_kw: float | None = None
    degradation_cost_per_mwh: float = 0.0


def optimise(
    prices: np.ndarray, pv_kw: np.ndarray, step_h: float, p: BatteryParams, n_soc: int = 121
) -> dict:
    """Prices in currency/MWh; returns schedule (kW, + = discharge), SoC path and value."""
    if len(prices) != len(pv_kw):
        raise ValueError("prices and pv must align")
    if not (0 <= p.soc_min < p.soc_max <= 1) or not (p.soc_min <= p.soc_initial <= p.soc_max):
        raise ValueError("invalid SoC bounds")
    if not 0 < p.round_trip_efficiency <= 1:
        raise ValueError("round-trip efficiency must be in (0, 1]")
    eta = np.sqrt(p.round_trip_efficiency)
    socs = np.linspace(p.soc_min, p.soc_max, n_soc)
    e = socs * p.energy_kwh
    T = len(prices)
    # Terminal value: energy left above/below the initial SoC is valued at the mean price after the
    # discharge efficiency — the same adjustment applied to every compared schedule.
    V = terminal_value(socs, p, float(np.mean(prices)))
    policy = np.zeros((T, n_soc), dtype=int)
    for t in range(T - 1, -1, -1):
        de = e[None, :] - e[:, None]  # from i (rows) to j (cols), kWh stored change
        charge = de > 0
        p_batt = np.where(charge, -de / eta / step_h, -de * eta / step_h)  # kW at the grid side (+ discharge)
        feasible = np.abs(p_batt) <= p.power_kw + 1e-9
        if p.pv_only_charging:
            feasible &= ~charge | (-p_batt <= pv_kw[t] + 1e-9)
        export = pv_kw[t] + p_batt
        if p.export_limit_kw is not None:
            # discharging must not push export above the limit; PV above the limit is spilled (curtailed)
            feasible &= (p_batt <= 1e-9) | (export <= p.export_limit_kw + 1e-9)
        value = (
            (np.minimum(export, p.export_limit_kw if p.export_limit_kw is not None else np.inf))
            * step_h
            / 1000
            * prices[t]
        )
        value -= np.abs(np.where(charge, 0, p_batt)) * step_h / 1000 * p.degradation_cost_per_mwh
        total = np.where(feasible, value + V[None, :], -1e15)
        policy[t] = np.argmax(total, axis=1)
        V = total[np.arange(n_soc), policy[t]]
    i = int(np.argmin(np.abs(socs - p.soc_initial)))
    sched, soc_path = [], [socs[i]]
    for t in range(T):
        j = policy[t, i]
        de = e[j] - e[i]
        pb = -de / eta / step_h if de > 0 else -de * eta / step_h
        sched.append(pb)
        soc_path.append(socs[j])
        i = j
    sched = np.array(sched)
    export = pv_kw + sched
    if p.export_limit_kw is not None:
        export = np.minimum(export, p.export_limit_kw)
    value = float(np.sum(export * step_h / 1000 * prices))
    adj = float(terminal_value(np.array([soc_path[-1]]), p, float(np.mean(prices)))[0])
    return {
        "battery_kw": sched,
        "soc": np.array(soc_path),
        "export_kw": export,
        "value": value,
        "terminal_adjustment": adj,
    }


def terminal_value(socs: np.ndarray, p: BatteryParams, mean_price: float) -> np.ndarray:
    eta = np.sqrt(p.round_trip_efficiency)
    de = (socs - p.soc_initial) * p.energy_kwh
    return np.where(de >= 0, de * eta, de / eta) / 1000 * mean_price


def check_constraints(res: dict, pv_kw: np.ndarray, step_h: float, p: BatteryParams) -> list[str]:
    v = []
    eta = np.sqrt(p.round_trip_efficiency)
    soc = res["soc"]
    if soc.min() < p.soc_min - 1e-6 or soc.max() > p.soc_max + 1e-6:
        v.append("soc bounds")
    if np.abs(res["battery_kw"]).max() > p.power_kw + 1e-6:
        v.append("power limit")
    for t, pb in enumerate(res["battery_kw"]):
        de = (soc[t + 1] - soc[t]) * p.energy_kwh
        expected = -de / eta / step_h if de > 0 else -de * eta / step_h
        if abs(expected - pb) > 1e-6:
            v.append(f"energy balance t={t}")
            break
        if p.pv_only_charging and pb < -1e-6 and -pb > pv_kw[t] + 1e-6:
            v.append(f"pv-only charging t={t}")
            break
    return v


def compare(
    prices: np.ndarray, pv_kw: np.ndarray, step_h: float, p: BatteryParams, currency: str, price_source: str
) -> dict:
    base_export = pv_kw if p.export_limit_kw is None else np.minimum(pv_kw, p.export_limit_kw)
    base_value = float(np.sum(base_export * step_h / 1000 * prices))
    opt = optimise(prices, pv_kw, step_h, p)
    violations = check_constraints(opt, pv_kw, step_h, p)
    # Simple rule-based alternative: charge from PV in the cheapest third, discharge in the dearest third.
    order = np.argsort(prices)
    rule = np.zeros_like(pv_kw)
    soc = p.soc_initial * p.energy_kwh
    eta = np.sqrt(p.round_trip_efficiency)
    cheap, dear = set(order[: len(order) // 3]), set(order[-len(order) // 3 :])
    rule_soc = [soc / p.energy_kwh]
    for t in range(len(prices)):
        if t in cheap and pv_kw[t] > 0:
            room = (p.soc_max * p.energy_kwh - soc) / eta / step_h
            c = min(p.power_kw, pv_kw[t] if p.pv_only_charging else p.power_kw, max(room, 0))
            rule[t] = -c
            soc += c * eta * step_h
        elif t in dear:
            avail = (soc - p.soc_min * p.energy_kwh) * eta / step_h
            d = min(p.power_kw, max(avail, 0))
            if p.export_limit_kw is not None:
                d = min(d, max(p.export_limit_kw - pv_kw[t], 0))
            rule[t] = d
            soc -= d / eta * step_h
        rule_soc.append(soc / p.energy_kwh)
    rule_export = np.minimum(pv_kw + rule, p.export_limit_kw) if p.export_limit_kw else pv_kw + rule
    rule_value = float(np.sum(rule_export * step_h / 1000 * prices))
    rule_adj = float(terminal_value(np.array([rule_soc[-1]]), p, float(np.mean(prices)))[0])
    return {
        "currency": currency,
        "price_source": price_source,
        "step_h": step_h,
        "constraints": p.__dict__,
        "schedules": {
            "no_storage": {
                "modelled_value": round(base_value, 2),
                "export_kwh": round(float(base_export.sum() * step_h), 1),
            },
            "rule_based": {
                "modelled_value": round(rule_value + rule_adj, 2),
                "export_value": round(rule_value, 2),
                "terminal_soc_adjustment": round(rule_adj, 2),
                "battery_kw": rule.round(1).tolist(),
                "soc": np.round(rule_soc, 4).tolist(),
                "export_kwh": round(float(rule_export.sum() * step_h), 1),
            },
            "optimised_dp": {
                "modelled_value": round(opt["value"] + opt["terminal_adjustment"], 2),
                "export_value": round(opt["value"], 2),
                "terminal_soc_adjustment": round(opt["terminal_adjustment"], 2),
                "battery_kw": opt["battery_kw"].round(1).tolist(),
                "soc": np.round(opt["soc"], 4).tolist(),
                "export_kwh": round(float(opt["export_kw"].sum() * step_h), 1),
                "constraint_violations": violations,
            },
        },
        "uplift_vs_no_storage": {
            "rule_based": round(rule_value + rule_adj - base_value, 2),
            "optimised_dp": round(opt["value"] + opt["terminal_adjustment"] - base_value, 2),
        },
        "valuation_note": "Modelled value = export × price + terminal SoC adjustment (energy above/below the initial SoC valued "
        "at the period mean price after efficiency), so schedules ending at different SoC compare fairly.",
        "efficiency_losses_kwh": round(float(-np.sum(opt["battery_kw"]) * step_h), 1),
        "disclaimer": DISCLAIMER,
    }
