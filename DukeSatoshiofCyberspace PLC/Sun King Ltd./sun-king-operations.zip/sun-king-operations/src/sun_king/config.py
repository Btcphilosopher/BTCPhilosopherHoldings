"""Runtime configuration read from environment variables.

Secrets are never given defaults that would be safe for production. In
``SUN_KING_ENV=production`` the application refuses to start with the
development secret.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

DEV_SECRET = "dev-only-insecure-secret-change-me"


def _bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    env: str = "development"
    database_url: str = "sqlite:///./sun_king.db"
    secret_key: str = DEV_SECRET
    token_ttl_minutes: int = 480
    cors_origins: tuple[str, ...] = ("http://localhost:5173", "http://localhost:8080")
    object_store: str = "local"  # local | s3
    object_store_path: Path = Path("./var/objects")
    s3_endpoint: str | None = None
    s3_bucket: str = "sun-king-evidence"
    max_ingest_batch: int = 10_000
    max_upload_bytes: int = 25 * 1024 * 1024
    max_import_rows: int = 50_000
    stale_after_seconds: int = 900
    simulator_enabled: bool = True
    simulator_interval_seconds: int = 30
    live_adapters_enabled: bool = False
    oidc_issuer: str | None = None
    oidc_audience: str | None = None
    demo_password: str = "sunking-demo"
    extra: dict[str, str] = field(default_factory=dict)

    @property
    def is_postgres(self) -> bool:
        return self.database_url.startswith("postgresql")


@lru_cache
def get_settings() -> Settings:
    s = Settings(
        env=os.environ.get("SUN_KING_ENV", "development"),
        database_url=_database_url(),
        secret_key=_read_secret("SUN_KING_SECRET_KEY", DEV_SECRET),
        token_ttl_minutes=int(os.environ.get("SUN_KING_TOKEN_TTL_MINUTES", "480")),
        cors_origins=tuple(
            o.strip()
            for o in os.environ.get(
                "SUN_KING_CORS_ORIGINS", "http://localhost:5173,http://localhost:8080"
            ).split(",")
            if o.strip()
        ),
        object_store=os.environ.get("SUN_KING_OBJECT_STORE", "local"),
        object_store_path=Path(os.environ.get("SUN_KING_OBJECT_STORE_PATH", "./var/objects")),
        s3_endpoint=os.environ.get("SUN_KING_S3_ENDPOINT"),
        s3_bucket=os.environ.get("SUN_KING_S3_BUCKET", "sun-king-evidence"),
        max_ingest_batch=int(os.environ.get("SUN_KING_MAX_INGEST_BATCH", "10000")),
        max_upload_bytes=int(os.environ.get("SUN_KING_MAX_UPLOAD_BYTES", str(25 * 1024 * 1024))),
        max_import_rows=int(os.environ.get("SUN_KING_MAX_IMPORT_ROWS", "50000")),
        stale_after_seconds=int(os.environ.get("SUN_KING_STALE_AFTER_SECONDS", "900")),
        simulator_enabled=_bool("SUN_KING_SIMULATOR_ENABLED", True),
        simulator_interval_seconds=int(os.environ.get("SUN_KING_SIMULATOR_INTERVAL_SECONDS", "30")),
        live_adapters_enabled=_bool("SUN_KING_LIVE_ADAPTERS_ENABLED", False),
        oidc_issuer=os.environ.get("SUN_KING_OIDC_ISSUER"),
        oidc_audience=os.environ.get("SUN_KING_OIDC_AUDIENCE"),
        demo_password=_read_secret("SUN_KING_DEMO_PASSWORD", "sunking-demo"),
    )
    if s.env == "production" and s.secret_key == DEV_SECRET:
        raise RuntimeError("SUN_KING_SECRET_KEY must be set in production")
    return s


def _read_secret(name: str, default: str) -> str:
    """Read a secret from NAME or from the file named by NAME_FILE (Docker secrets)."""
    file_path = os.environ.get(f"{name}_FILE")
    if file_path:
        return Path(file_path).read_text().strip()
    return os.environ.get(name, default)


def _database_url() -> str:
    """Database URL, with the password injected from SUN_KING_DATABASE_PASSWORD_FILE when provided."""
    url = os.environ.get("SUN_KING_DATABASE_URL", "sqlite:///./sun_king.db")
    pw_file = os.environ.get("SUN_KING_DATABASE_PASSWORD_FILE")
    if pw_file:
        from sqlalchemy.engine import make_url

        url = (
            make_url(url)
            .set(password=Path(pw_file).read_text().strip())
            .render_as_string(hide_password=False)
        )
    return url
