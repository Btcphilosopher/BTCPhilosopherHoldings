"""Engineering units with explicit dimensions.

Power and energy are different dimensions. Adding or summing power values
never produces energy; energy requires integration over time
(:mod:`sun_king.energy.accounting`). Conversions are table-driven so that
unknown or mismatched units raise instead of being silently accepted.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class Dimension(StrEnum):
    POWER = "power"
    ENERGY = "energy"
    VOLTAGE = "voltage"
    CURRENT = "current"
    IRRADIANCE = "irradiance"
    IRRADIATION = "irradiation"
    TEMPERATURE = "temperature"
    SPEED = "speed"
    ANGLE = "angle"
    RATIO = "ratio"
    STATUS = "status"
    REACTIVE_POWER = "reactive_power"
    CURRENCY = "currency"


# unit -> (dimension, factor to canonical, offset to canonical)
# canonical units: kW, kWh, V, A, W/m2, Wh/m2, degC, m/s, deg, fraction, code
_UNITS: dict[str, tuple[Dimension, float, float]] = {
    "W": (Dimension.POWER, 1e-3, 0.0),
    "kW": (Dimension.POWER, 1.0, 0.0),
    "MW": (Dimension.POWER, 1e3, 0.0),
    "Wh": (Dimension.ENERGY, 1e-3, 0.0),
    "kWh": (Dimension.ENERGY, 1.0, 0.0),
    "MWh": (Dimension.ENERGY, 1e3, 0.0),
    "GWh": (Dimension.ENERGY, 1e6, 0.0),
    "V": (Dimension.VOLTAGE, 1.0, 0.0),
    "kV": (Dimension.VOLTAGE, 1e3, 0.0),
    "mA": (Dimension.CURRENT, 1e-3, 0.0),
    "A": (Dimension.CURRENT, 1.0, 0.0),
    "W/m2": (Dimension.IRRADIANCE, 1.0, 0.0),
    "kW/m2": (Dimension.IRRADIANCE, 1e3, 0.0),
    "Wh/m2": (Dimension.IRRADIATION, 1.0, 0.0),
    "kWh/m2": (Dimension.IRRADIATION, 1e3, 0.0),
    "degC": (Dimension.TEMPERATURE, 1.0, 0.0),
    "K": (Dimension.TEMPERATURE, 1.0, -273.15),
    "degF": (Dimension.TEMPERATURE, 5.0 / 9.0, -32.0 * 5.0 / 9.0),
    "m/s": (Dimension.SPEED, 1.0, 0.0),
    "km/h": (Dimension.SPEED, 1.0 / 3.6, 0.0),
    "deg": (Dimension.ANGLE, 1.0, 0.0),
    "fraction": (Dimension.RATIO, 1.0, 0.0),
    "%": (Dimension.RATIO, 0.01, 0.0),
    "code": (Dimension.STATUS, 1.0, 0.0),
    "kvar": (Dimension.REACTIVE_POWER, 1.0, 0.0),
}

ALIASES = {
    "w/m²": "W/m2",
    "w/m^2": "W/m2",
    "W/m²": "W/m2",
    "°C": "degC",
    "C": "degC",
    "celsius": "degC",
    "kwh": "kWh",
    "kw": "kW",
    "mwh": "MWh",
    "mw": "MW",
    "percent": "%",
}

CANONICAL = {
    Dimension.POWER: "kW",
    Dimension.ENERGY: "kWh",
    Dimension.VOLTAGE: "V",
    Dimension.CURRENT: "A",
    Dimension.IRRADIANCE: "W/m2",
    Dimension.IRRADIATION: "Wh/m2",
    Dimension.TEMPERATURE: "degC",
    Dimension.SPEED: "m/s",
    Dimension.ANGLE: "deg",
    Dimension.RATIO: "fraction",
    Dimension.STATUS: "code",
    Dimension.REACTIVE_POWER: "kvar",
}


class UnitError(ValueError):
    """Raised for unknown units or dimensionally invalid operations."""


def normalise_unit(unit: str) -> str:
    u = unit.strip()
    u = ALIASES.get(u, ALIASES.get(u.lower(), u))
    if u not in _UNITS:
        raise UnitError(f"unknown unit {unit!r}")
    return u


def dimension_of(unit: str) -> Dimension:
    return _UNITS[normalise_unit(unit)][0]


def to_canonical(value: float, unit: str) -> tuple[float, str]:
    u = normalise_unit(unit)
    dim, factor, offset = _UNITS[u]
    return value * factor + offset, CANONICAL[dim]


def convert(value: float, from_unit: str, to_unit: str) -> float:
    fu, tu = normalise_unit(from_unit), normalise_unit(to_unit)
    fd, ff, fo = _UNITS[fu]
    td, tf, to = _UNITS[tu]
    if fd != td:
        raise UnitError(f"cannot convert {fu} ({fd}) to {tu} ({td})")
    canonical = value * ff + fo
    return (canonical - to) / tf


@dataclass(frozen=True)
class Quantity:
    """A value with a unit. Arithmetic is restricted to same-dimension values."""

    value: float
    unit: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "unit", normalise_unit(self.unit))

    @property
    def dimension(self) -> Dimension:
        return dimension_of(self.unit)

    def to(self, unit: str) -> Quantity:
        return Quantity(convert(self.value, self.unit, unit), unit)

    def __add__(self, other: Quantity) -> Quantity:
        if not isinstance(other, Quantity):
            return NotImplemented
        if other.dimension != self.dimension:
            raise UnitError(f"cannot add {self.dimension} and {other.dimension}")
        if self.dimension == Dimension.TEMPERATURE:
            raise UnitError("adding absolute temperatures is not meaningful")
        return Quantity(self.value + other.to(self.unit).value, self.unit)

    def relabel(self, unit: str) -> Quantity:  # pragma: no cover - guard
        raise UnitError("relabelling a quantity's unit is not permitted; use .to() or integrate")


def energy_from_constant_power(power: Quantity, hours: float) -> Quantity:
    """Energy for a power held constant for ``hours`` — the only power→energy shortcut."""
    if power.dimension != Dimension.POWER:
        raise UnitError("energy_from_constant_power requires a power quantity")
    return Quantity(power.to("kW").value * hours, "kWh")


def sum_quantities(values: list[Quantity]) -> Quantity:
    if not values:
        raise UnitError("cannot sum an empty list without a unit")
    total = values[0]
    for v in values[1:]:
        total = total + v
    return total
