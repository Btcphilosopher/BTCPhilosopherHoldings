"""UTC storage and site-local presentation helpers, DST-aware."""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, date, datetime, time, timedelta
from zoneinfo import ZoneInfo


def utcnow() -> datetime:
    return datetime.now(UTC)


def ensure_utc(dt: datetime) -> datetime:
    """Require timezone-aware input and convert to UTC. Naive datetimes are rejected."""
    if dt.tzinfo is None or dt.tzinfo.utcoffset(dt) is None:
        raise ValueError("naive datetime rejected: observation times must carry a UTC offset")
    return dt.astimezone(UTC)


def as_utc(dt: datetime) -> datetime:
    """Interpret database values (which may come back naive from SQLite) as UTC."""
    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC)


def local_day_bounds(day: date, tz: str) -> tuple[datetime, datetime]:
    """UTC start/end of a site-local calendar day. Length is 23h/24h/25h across DST."""
    zone = ZoneInfo(tz)
    start = datetime.combine(day, time(0), tzinfo=zone)
    end = datetime.combine(day + timedelta(days=1), time(0), tzinfo=zone)
    return start.astimezone(UTC), end.astimezone(UTC)


def local_days(start_day: date, end_day: date, tz: str) -> Iterator[tuple[date, datetime, datetime]]:
    d = start_day
    while d <= end_day:
        s, e = local_day_bounds(d, tz)
        yield d, s, e
        d += timedelta(days=1)


def local_date(dt: datetime, tz: str) -> date:
    return ensure_utc(dt).astimezone(ZoneInfo(tz)).date()


def to_local_iso(dt: datetime, tz: str) -> str:
    return as_utc(dt).astimezone(ZoneInfo(tz)).isoformat()


def floor_time(dt: datetime, seconds: int) -> datetime:
    ts = int(as_utc(dt).timestamp())
    return datetime.fromtimestamp(ts - ts % seconds, UTC)


def interval_edges(start: datetime, end: datetime, seconds: int) -> list[datetime]:
    """Fixed-width UTC edges. Local-day bucketing should use :func:`local_day_bounds`."""
    edges = []
    t = as_utc(start)
    end = as_utc(end)
    while t < end:
        edges.append(t)
        t += timedelta(seconds=seconds)
    edges.append(end)
    return edges
