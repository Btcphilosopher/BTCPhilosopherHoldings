"""Command line: ``sun-king <command>`` (or ``python -m sun_king.cli``)."""

from __future__ import annotations

import argparse
import json
import logging
import sys


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="sun-king")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser(
        "init-db", help="create tables directly from the ORM (SQLite/dev); production uses alembic"
    )
    sd = sub.add_parser("seed", help="load the Pennine demo portfolio and synthetic history")
    sd.add_argument("--days", type=int, default=14)
    sd.add_argument("--replay-days", type=int, default=7)
    sd.add_argument("--no-forecasts", action="store_true")
    sub.add_parser("worker", help="run background workers (live simulator, alert evaluation, jobs)")
    bk = sub.add_parser("backup", help="logical JSON backup")
    bk.add_argument("path")
    rs = sub.add_parser("restore", help="restore a logical backup into an empty database")
    rs.add_argument("path")
    tk = sub.add_parser("token", help="mint a token for a user or service account (e.g. svc-collector)")
    tk.add_argument("user_id")
    tk.add_argument("--ttl-minutes", type=int, default=60 * 24 * 30)
    sub.add_parser("export-openapi", help="write docs/openapi.json")
    sub.add_parser(
        "evaluate-ml",
        help="evaluate anomaly + forecast models on the seeded data; writes docs/evaluation.json",
    )
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    from sun_king.core.db import create_all, session_scope

    if a.cmd == "init-db":
        create_all()
        print("tables created")
    elif a.cmd == "seed":
        from sun_king.simulation.seed import finalise_statement, seed

        create_all()
        with session_scope() as s:
            out = seed(s, days=a.days, replay_days=a.replay_days, train_forecasts=not a.no_forecasts)
            finalise_statement(s)
        print(json.dumps(out, indent=2, default=str))
    elif a.cmd == "worker":
        from sun_king.workers.runner import run_forever

        run_forever()
    elif a.cmd == "backup":
        from sun_king.admin.backup import backup

        with session_scope() as s:
            print(json.dumps(backup(s, a.path), indent=2))
    elif a.cmd == "restore":
        from sun_king.admin.backup import restore

        create_all()
        with session_scope() as s:
            print(json.dumps(restore(s, a.path), indent=2))
    elif a.cmd == "token":
        from sun_king.admin.models import User
        from sun_king.admin.security import create_token

        with session_scope() as s:
            u = s.get(User, a.user_id)
            if u is None:
                print("unknown user", file=sys.stderr)
                return 2
            print(create_token(u, a.ttl_minutes))
    elif a.cmd == "export-openapi":
        from pathlib import Path

        from sun_king.api.app import app

        Path("docs").mkdir(exist_ok=True)
        Path("docs/openapi.json").write_text(json.dumps(app.openapi(), indent=1))
        print("docs/openapi.json written")
    elif a.cmd == "evaluate-ml":
        from sun_king.ml.evaluate import run

        with session_scope() as s:
            print(json.dumps(run(s), indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
