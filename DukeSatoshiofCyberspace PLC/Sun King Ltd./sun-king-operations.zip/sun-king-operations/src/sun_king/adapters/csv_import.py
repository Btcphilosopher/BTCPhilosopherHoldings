"""Bounded CSV import for historian exports and commercial statements."""

from __future__ import annotations

import csv
import io
from datetime import date, datetime

REQUIRED_STATEMENT = [
    "statement_ref",
    "contract_id",
    "period_start",
    "period_end",
    "settled_energy_mwh",
    "amount",
    "currency",
    "issued_on",
]
REQUIRED_TELEMETRY = ["asset_id", "measurement_type", "value", "unit", "observation_time"]


class ImportError_(ValueError):
    pass


def _rows(content: bytes, max_rows: int, required: list[str]) -> list[dict]:
    if len(content) > 20 * 1024 * 1024:
        raise ImportError_("file exceeds 20 MB")
    text = content.decode("utf-8-sig")
    reader = csv.DictReader(io.StringIO(text))
    missing = [c for c in required if c not in (reader.fieldnames or [])]
    if missing:
        raise ImportError_(f"missing columns: {missing}")
    rows = []
    for i, r in enumerate(reader):
        if i >= max_rows:
            raise ImportError_(f"more than {max_rows} rows")
        rows.append(r)
    return rows


class SettlementCSVAdapter:
    kind = "commercial_import"

    def parse(self, content: bytes, max_rows: int) -> list[dict]:
        out = []
        for i, r in enumerate(_rows(content, max_rows, REQUIRED_STATEMENT)):
            try:
                cur = r["currency"].strip().upper()
                if len(cur) != 3:
                    raise ValueError("currency must be ISO 4217")
                out.append(
                    {
                        "statement_ref": r["statement_ref"].strip()[:120],
                        "contract_id": r["contract_id"].strip(),
                        "period_start": date.fromisoformat(r["period_start"]),
                        "period_end": date.fromisoformat(r["period_end"]),
                        "settled_energy_mwh": float(r["settled_energy_mwh"]),
                        "amount": float(r["amount"]),
                        "currency": cur,
                        "issued_on": date.fromisoformat(r["issued_on"]),
                    }
                )
            except (ValueError, KeyError) as e:
                raise ImportError_(f"row {i + 2}: {e}") from e
        return out


class HistorianCSVAdapter:
    kind = "historian"

    def __init__(self, source: str):
        self.source = source

    def parse(self, content: bytes, max_rows: int) -> list[dict]:
        out = []
        for i, r in enumerate(_rows(content, max_rows, REQUIRED_TELEMETRY)):
            try:
                t = datetime.fromisoformat(r["observation_time"])
                if t.tzinfo is None:
                    raise ValueError("observation_time must include a UTC offset")
                v = r["value"].strip()
                out.append(
                    {
                        "asset_id": r["asset_id"].strip(),
                        "measurement_type": r["measurement_type"].strip(),
                        "value": float(v) if v not in ("", "null", "NaN") else None,
                        "unit": r["unit"].strip(),
                        "observation_time": t,
                        "source": self.source,
                    }
                )
            except ValueError as e:
                raise ImportError_(f"row {i + 2}: {e}") from e
        return out
