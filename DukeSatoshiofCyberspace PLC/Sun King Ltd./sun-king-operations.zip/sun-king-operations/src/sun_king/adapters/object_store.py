"""Object storage for imagery, manuals and inspection evidence.

``LocalObjectStore`` (default, development) writes content-addressed files
below a root directory. ``S3ObjectStore`` targets any S3-compatible service
(MinIO in ``compose.yaml``) and needs the optional ``boto3`` dependency;
credentials come from the standard AWS environment variables / secrets.
"""

from __future__ import annotations

from pathlib import Path
from typing import Protocol


class ObjectStore(Protocol):
    def put(self, key: str, data: bytes, content_type: str) -> None: ...
    def get(self, key: str) -> bytes: ...
    def exists(self, key: str) -> bool: ...


class LocalObjectStore:
    def __init__(self, root: Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        p = (self.root / key).resolve()
        if self.root not in p.parents:
            raise ValueError("object key escapes store root")
        return p

    def put(self, key: str, data: bytes, content_type: str) -> None:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)

    def get(self, key: str) -> bytes:
        return self._path(key).read_bytes()

    def exists(self, key: str) -> bool:
        return self._path(key).exists()


class S3ObjectStore:  # pragma: no cover - exercised only with MinIO in compose
    def __init__(self, endpoint: str | None, bucket: str):
        import boto3

        self.bucket = bucket
        self.client = boto3.client("s3", endpoint_url=endpoint)

    def put(self, key: str, data: bytes, content_type: str) -> None:
        self.client.put_object(
            Bucket=self.bucket, Key=key, Body=data, ContentType=content_type, ServerSideEncryption="AES256"
        )

    def get(self, key: str) -> bytes:
        return self.client.get_object(Bucket=self.bucket, Key=key)["Body"].read()

    def exists(self, key: str) -> bool:
        try:
            self.client.head_object(Bucket=self.bucket, Key=key)
            return True
        except Exception:
            return False


_store: ObjectStore | None = None


def get_object_store() -> ObjectStore:
    global _store
    if _store is None:
        from sun_king.config import get_settings

        s = get_settings()
        _store = (
            S3ObjectStore(s.s3_endpoint, s.s3_bucket)
            if s.object_store == "s3"
            else LocalObjectStore(s.object_store_path)
        )
    return _store


def set_object_store(store: ObjectStore | None) -> None:
    global _store
    _store = store
