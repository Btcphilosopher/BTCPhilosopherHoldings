"""Simulator adapters — the default data source for every adapter kind."""

from __future__ import annotations

from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from sun_king.adapters.base import FetchResult, WeatherForecastPoint
from sun_king.simulation.noise import normal
from sun_king.simulation.plant import SITE_KEYS, PlantSimulator
from sun_king.simulation.telemetry_sim import RegisterState, TelemetrySimulator

FORECAST_ISSUE_HOURS = (0, 6, 12, 18)
FORECAST_AVAILABILITY_DELAY = timedelta(hours=3, minutes=30)


class SimulatorTelemetryAdapter:
    """Implements every telemetry adapter Protocol by sampling the plant simulator."""

    kind = "simulator"
    source = "simulator"

    def __init__(self, plant: PlantSimulator):
        self.plant = plant
        self.sim = TelemetrySimulator(plant)
        self.registers: dict[str, dict[str, RegisterState]] = {}

    def fetch(self, site_id: str, since: datetime, until: datetime, freq: str | None = None) -> FetchResult:
        if freq:
            times = pd.date_range(since, until, freq=freq, inclusive="right")
        else:
            times = pd.DatetimeIndex([pd.Timestamp(until)])
        if len(times) == 0:
            return FetchResult([], self.source, True)
        obs, regs = self.sim.observations(site_id, times, self.registers.get(site_id))
        self.registers[site_id] = regs
        return FetchResult(obs, self.source, True, next_cursor=until)


class SimulatedWeatherForecastAdapter:
    """Synthetic NWP: truth GHI with error that grows with lead time.

    Each issue (00/06/12/18 UTC) becomes *available* 3 h 30 min after its
    nominal issue time, mimicking real NWP latency. ``latest_issue`` only
    returns issues available at ``as_of`` — the forecasting pipeline relies on
    this to avoid look-ahead.
    """

    kind = "weather_forecast"
    source = "sim-nwp"

    def __init__(self, plant: PlantSimulator, horizon_h: int = 48):
        self.plant = plant
        self.horizon_h = horizon_h

    def issue_time_for(self, as_of: datetime) -> datetime:
        t = pd.Timestamp(as_of - FORECAST_AVAILABILITY_DELAY).floor("6h")
        return t.to_pydatetime()

    def forecast(self, site_id: str, issue: datetime) -> list[WeatherForecastPoint]:
        site = self.plant.sites[site_id]
        times = pd.date_range(issue, issue + timedelta(hours=self.horizon_h), freq="30min", inclusive="left")
        wx = self.plant.weather.observe(site, SITE_KEYS[site_id], times)
        lead_h = (times - pd.Timestamp(issue)).total_seconds().to_numpy() / 3600
        key = f"nwp{site_id}{int(pd.Timestamp(issue).timestamp())}"
        # smoothed (forecasts cannot resolve individual clouds) + lead-dependent error
        kt = (
            pd.Series(wx["kt"].to_numpy(), index=times)
            .rolling(6, min_periods=1, center=True)
            .mean()
            .to_numpy()
        )
        err = (0.06 + 0.12 * np.clip(lead_h / 36, 0, 1)) * normal(key, np.arange(len(times)) // 4)
        bias = 0.04 * normal(key + "b", np.array([0]))[0]
        from sun_king.adapters import pvmodel

        cs = pvmodel.clearsky(site.latitude, site.longitude, site.elevation_m, times)["ghi"].to_numpy()
        ghi = np.clip(kt + err + bias, 0.05, 1.05) * cs
        avail = issue + FORECAST_AVAILABILITY_DELAY
        return [
            WeatherForecastPoint(
                issue,
                avail,
                t.to_pydatetime(),
                float(g),
                float(ta + 0.8 * normal(key + "t", np.array([i]))[0]),
                float(ws),
                None,
            )
            for i, (t, g, ta, ws) in enumerate(zip(times, ghi, wx["temp_air"], wx["wind_speed"], strict=True))
        ]

    def latest_issue(self, site_id: str, as_of: datetime) -> list[WeatherForecastPoint]:
        return self.forecast(site_id, self.issue_time_for(as_of))
