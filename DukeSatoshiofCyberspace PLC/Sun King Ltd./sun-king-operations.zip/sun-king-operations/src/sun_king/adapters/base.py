"""Typed adapter interfaces for equipment and data integrations.

All adapters are **read-only**. There is deliberately no method for writing
set-points, switching inverters, changing protection or sending any remote
electrical command; the monitoring platform is separated from any future
control system.

Live adapters are only constructed when *all* of the following hold:

1. ``SUN_KING_LIVE_ADAPTERS_ENABLED=true`` for the deployment;
2. the :class:`~sun_king.admin.models.AdapterConfig` row is ``enabled`` with ``mode='live'``;
3. ``verified_documentation_ref`` records the vendor documentation/terms that
   were checked (protocol, authentication, rate limits, permitted use);
4. the endpoint host is in that config's explicit ``allowed_hosts``.

Adapters never scan networks, enumerate devices or probe endpoints that are
not explicitly configured.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol, runtime_checkable

from sun_king.telemetry.schemas import ObservationIn


@dataclass
class FetchResult:
    observations: list[ObservationIn]
    source: str
    complete: bool
    next_cursor: datetime | None = None
    error: str | None = None


@runtime_checkable
class TelemetryAdapter(Protocol):
    kind: str
    source: str

    def fetch(self, site_id: str, since: datetime, until: datetime) -> FetchResult: ...


class InverterMonitoringAdapter(TelemetryAdapter, Protocol):
    kind = "inverter_monitoring"


class SiteMeterAdapter(TelemetryAdapter, Protocol):
    kind = "site_meter"


class WeatherStationAdapter(TelemetryAdapter, Protocol):
    kind = "weather_station"


class HistorianAdapter(TelemetryAdapter, Protocol):
    kind = "historian"


class BatteryMonitoringAdapter(TelemetryAdapter, Protocol):
    kind = "battery_monitoring"


@dataclass
class WeatherForecastPoint:
    issue_time: datetime
    available_time: datetime
    valid_time: datetime
    ghi_wm2: float
    temp_air_c: float
    wind_speed_ms: float
    cloud_cover: float | None = None


class WeatherForecastAdapter(Protocol):
    kind: str
    source: str

    def latest_issue(self, site_id: str, as_of: datetime) -> list[WeatherForecastPoint]: ...


class CommercialImportAdapter(Protocol):
    kind: str

    def parse(self, content: bytes, max_rows: int) -> list[dict]: ...


class AdapterNotPermitted(PermissionError):
    pass


def check_live_permitted(cfg, live_enabled: bool) -> None:
    """Raise unless a live adapter config satisfies every precondition above."""
    from urllib.parse import urlparse

    if cfg.mode != "live":
        return
    if not live_enabled:
        raise AdapterNotPermitted("live adapters are disabled for this deployment")
    if not cfg.enabled:
        raise AdapterNotPermitted(f"adapter {cfg.id} is not enabled")
    if not cfg.verified_documentation_ref:
        raise AdapterNotPermitted("verified_documentation_ref is required before live use")
    host = urlparse(cfg.endpoint or "").hostname
    if not host or host not in (cfg.allowed_hosts or []):
        raise AdapterNotPermitted(f"endpoint host {host!r} is not in allowed_hosts")
    if urlparse(cfg.endpoint).scheme != "https":
        raise AdapterNotPermitted("live endpoints must use https")
