"""Skeleton for an authorised, read-only HTTPS JSON telemetry adapter.

This is a *template*, not an integration with any real vendor. Before use,
the vendor's official documentation must be checked for the protocol,
authentication scheme, rate limits and terms, and recorded in
``AdapterConfig.verified_documentation_ref``. Field mapping is supplied via
``AdapterConfig.settings['mapping']`` against configured monitoring points.
"""

from __future__ import annotations

import os
from datetime import datetime

import httpx

from sun_king.adapters.base import FetchResult, check_live_permitted
from sun_king.telemetry.schemas import ObservationIn


class ReadOnlyHTTPJSONAdapter:
    kind = "generic_https_json"

    def __init__(self, cfg, live_enabled: bool, timeout_s: float = 10.0):
        check_live_permitted(cfg, live_enabled)
        self.cfg = cfg
        self.source = cfg.id
        self.timeout_s = timeout_s

    def _headers(self) -> dict:
        token = os.environ.get(self.cfg.credential_ref or "", "")
        return {"Authorization": f"Bearer {token}"} if token else {}

    def fetch(
        self, site_id: str, since: datetime, until: datetime
    ) -> FetchResult:  # pragma: no cover - no live endpoint
        mapping: dict = self.cfg.settings.get("mapping", {})
        with httpx.Client(timeout=self.timeout_s, follow_redirects=False) as client:
            r = client.get(
                self.cfg.endpoint,
                params={"from": since.isoformat(), "to": until.isoformat()},
                headers=self._headers(),
            )
            r.raise_for_status()
            rows = r.json()
        obs = []
        for row in rows[:10_000]:
            m = mapping.get(row.get("tag"))
            if not m:
                continue
            obs.append(
                ObservationIn(
                    asset_id=m["asset_id"],
                    measurement_type=m["measurement_type"],
                    value=row.get("value"),
                    unit=m["unit"],
                    observation_time=datetime.fromisoformat(row["time"]),
                    source=self.source,
                )
            )
        return FetchResult(obs, self.source, True, until)
