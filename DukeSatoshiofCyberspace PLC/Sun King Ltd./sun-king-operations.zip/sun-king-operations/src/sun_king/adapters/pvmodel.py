"""Documented adapter around **pvlib** (https://pvlib-python.readthedocs.io).

Verified against pvlib 0.16.x signatures (see ``docs/pv-model.md``):

* ``pvlib.location.Location.get_solarposition`` / ``get_clearsky(model='ineichen')``
* ``pvlib.irradiance.erbs`` (GHI → DNI/DHI decomposition)
* ``pvlib.irradiance.get_total_irradiance(model='haydavies')``
* ``pvlib.tracking.singleaxis`` (single-axis tracker angles with backtracking)
* ``pvlib.temperature.sapm_cell`` with ``TEMPERATURE_MODEL_PARAMETERS['sapm']``
* ``pvlib.pvsystem.pvwatts_dc`` and ``pvlib.inverter.pvwatts``

The rest of the platform calls only the functions in this module, so a pvlib
API change is contained here. Every function returns plain pandas objects
in SI/engineering units (W/m², °C, kW).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
import pvlib
from pvlib import inverter, irradiance, pvsystem, temperature, tracking
from pvlib.location import Location

MODEL_ID = f"pvlib-{pvlib.__version__}/pvwatts+sapm+haydavies"


@dataclass(frozen=True)
class ArraySpec:
    asset_id: str
    inverter_asset_id: str
    dc_kwp: float
    tilt: float
    azimuth: float
    mounting: str = "fixed"  # fixed | single_axis
    axis_azimuth: float = 180.0
    max_rotation: float = 55.0
    gcr: float = 0.35
    gamma_pdc: float = -0.0035
    temperature_model: str = "open_rack_glass_polymer"
    dc_loss_fraction: float = 0.03


@dataclass(frozen=True)
class InverterSpec:
    asset_id: str
    ac_kw: float
    eta_nom: float = 0.98


def solar_elevation(lat: float, lon: float, times: pd.DatetimeIndex) -> np.ndarray:
    sp = pvlib.solarposition.get_solarposition(times, lat, lon)
    return sp["apparent_elevation"].to_numpy()


def solar_position(lat: float, lon: float, alt: float, times: pd.DatetimeIndex) -> pd.DataFrame:
    return Location(lat, lon, altitude=alt).get_solarposition(times)


def clearsky(lat: float, lon: float, alt: float, times: pd.DatetimeIndex) -> pd.DataFrame:
    """Ineichen clear-sky GHI/DNI/DHI (W/m²) with default Linke turbidity lookup."""
    return Location(lat, lon, altitude=alt).get_clearsky(times, model="ineichen")


def decompose_ghi(ghi: pd.Series, solpos: pd.DataFrame) -> pd.DataFrame:
    out = irradiance.erbs(ghi, solpos["zenith"], ghi.index)
    return pd.DataFrame({"ghi": ghi, "dni": out["dni"].fillna(0), "dhi": out["dhi"].fillna(0)})


def surface_orientation(spec: ArraySpec, solpos: pd.DataFrame) -> tuple[pd.Series, pd.Series]:
    if spec.mounting == "single_axis":
        tr = tracking.singleaxis(
            solpos["apparent_zenith"],
            solpos["azimuth"],
            axis_tilt=0,
            axis_azimuth=spec.axis_azimuth,
            max_angle=spec.max_rotation,
            backtrack=True,
            gcr=spec.gcr,
        )
        tilt = tr["surface_tilt"].fillna(0.0)
        az = tr["surface_azimuth"].fillna(spec.axis_azimuth + 90)
        return tilt, az
    idx = solpos.index
    return pd.Series(spec.tilt, index=idx), pd.Series(spec.azimuth, index=idx)


def poa_irradiance(
    spec: ArraySpec, sky: pd.DataFrame, solpos: pd.DataFrame, albedo: float = 0.2
) -> pd.Series:
    tilt, az = surface_orientation(spec, solpos)
    dni_extra = irradiance.get_extra_radiation(sky.index)
    poa = irradiance.get_total_irradiance(
        tilt,
        az,
        solpos["apparent_zenith"],
        solpos["azimuth"],
        sky["dni"],
        sky["ghi"],
        sky["dhi"],
        dni_extra=dni_extra,
        albedo=albedo,
        model="haydavies",
    )
    return poa["poa_global"].fillna(0.0).clip(lower=0.0)


def tracker_angle(spec: ArraySpec, solpos: pd.DataFrame) -> pd.Series:
    tr = tracking.singleaxis(
        solpos["apparent_zenith"],
        solpos["azimuth"],
        axis_azimuth=spec.axis_azimuth,
        max_angle=spec.max_rotation,
        backtrack=True,
        gcr=spec.gcr,
    )
    return tr["tracker_theta"].fillna(0.0)


def cell_temperature(spec: ArraySpec, poa: pd.Series, temp_air: pd.Series, wind: pd.Series) -> pd.Series:
    p = temperature.TEMPERATURE_MODEL_PARAMETERS["sapm"][spec.temperature_model]
    return temperature.sapm_cell(poa, temp_air, wind, p["a"], p["b"], p["deltaT"])


def module_back_temperature(
    spec: ArraySpec, poa: pd.Series, temp_air: pd.Series, wind: pd.Series
) -> pd.Series:
    p = temperature.TEMPERATURE_MODEL_PARAMETERS["sapm"][spec.temperature_model]
    return temperature.sapm_module(poa, temp_air, wind, p["a"], p["b"])


def cell_from_module_temperature(spec: ArraySpec, t_module: pd.Series, poa: pd.Series) -> pd.Series:
    """SAPM relation T_cell = T_module + (E/1000)·ΔT (used with measured back-of-module temperature)."""
    p = temperature.TEMPERATURE_MODEL_PARAMETERS["sapm"][spec.temperature_model]
    return t_module + poa / 1000.0 * p["deltaT"]


def dc_power_kw(spec: ArraySpec, poa: pd.Series, t_cell: pd.Series) -> pd.Series:
    pdc = pvsystem.pvwatts_dc(poa, t_cell, spec.dc_kwp * 1000.0, spec.gamma_pdc)
    return (pdc * (1 - spec.dc_loss_fraction) / 1000.0).clip(lower=0.0)


def ac_power_kw(inv: InverterSpec, pdc_kw: pd.Series) -> tuple[pd.Series, pd.Series]:
    """Returns (ac_kw clipped at the inverter AC rating, ac_kw unclipped).

    ``pvlib.inverter.pvwatts`` itself limits output at ``pdc0 * eta_inv_nom``;
    the unclipped curve is evaluated with a large pdc0 scaled to keep the same
    efficiency curve shape, giving an *estimate* of clipped power.
    """
    pdc0_w = inv.ac_kw * 1000.0 / inv.eta_nom
    pdc_w = pdc_kw * 1000.0
    ac = inverter.pvwatts(pdc_w, pdc0_w, eta_inv_nom=inv.eta_nom)
    # Unclipped: same efficiency, no AC limit
    eff = (ac / pdc_w.where(pdc_w > 0)).fillna(0)
    unclipped = pdc_w * eff.where(pdc_w <= pdc0_w, inv.eta_nom)
    return (ac.clip(lower=0) / 1000.0), (unclipped.clip(lower=0) / 1000.0)


def expected_ac_from_poa(
    spec: ArraySpec,
    inv: InverterSpec,
    poa: pd.Series,
    t_cell: pd.Series,
) -> pd.DataFrame:
    pdc = dc_power_kw(spec, poa, t_cell)
    ac, unclipped = ac_power_kw(inv, pdc)
    pdc_ref = dc_power_kw(spec, poa, pd.Series(25.0, index=poa.index))
    return pd.DataFrame({"dc_kw": pdc, "ac_kw": ac, "ac_unclipped_kw": unclipped, "dc_kw_25c": pdc_ref})
