"""Site and asset register.

Three views of a site are kept deliberately separate:

* **Physical hierarchy** — ``Asset.parent_asset_id`` (where a thing is / what it is part of).
* **Electrical connectivity** — :class:`ElectricalConnection` (what feeds what).
* **Monitoring-point mappings** — :class:`MonitoringPoint` (which external tag reports
  which measurement for which asset, from which source).

Capacity is never a single number: module DC capacity (kWp), inverter AC
capacity (kW) and grid export limit (kW) are stored separately.
"""

from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import Boolean, Date, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from sun_king.core.db import Base, JSONType, UTCDateTime
from sun_king.core.timeutil import utcnow

ASSET_TYPES = (
    "array_block",
    "string",
    "combiner_box",
    "inverter",
    "transformer",
    "meter",
    "weather_station",
    "sensor",
    "tracker",
    "grid_connection",
    "battery_system",
)


class Organisation(Base):
    __tablename__ = "organisations"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class Portfolio(Base):
    __tablename__ = "portfolios"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    organisation_id: Mapped[str] = mapped_column(ForeignKey("organisations.id"))
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[str | None] = mapped_column(Text)
    reporting_currency: Mapped[str] = mapped_column(String(3), default="GBP")
    sites: Mapped[list[Site]] = relationship(back_populates="portfolio")


class Site(Base):
    __tablename__ = "sites"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    portfolio_id: Mapped[str] = mapped_column(ForeignKey("portfolios.id"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    code: Mapped[str] = mapped_column(String(32), unique=True)
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    elevation_m: Mapped[float] = mapped_column(Float, default=0.0)
    timezone: Mapped[str] = mapped_column(String(64), default="Europe/London")
    dc_capacity_kwp: Mapped[float] = mapped_column(Float)
    ac_capacity_kw: Mapped[float] = mapped_column(Float)
    export_limit_kw: Mapped[float] = mapped_column(Float)
    albedo: Mapped[float] = mapped_column(Float, default=0.2)
    commissioning_date: Mapped[date | None] = mapped_column(Date)
    grid_connection_ref: Mapped[str | None] = mapped_column(String(100))
    status: Mapped[str] = mapped_column(String(32), default="operational")
    boundary: Mapped[list | None] = mapped_column(JSONType)  # [[lon, lat], ...] polygon (WGS84)
    source: Mapped[str] = mapped_column(String(64), default="manual")
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    portfolio: Mapped[Portfolio] = relationship(back_populates="sites")


class ModuleType(Base):
    __tablename__ = "module_types"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    manufacturer: Mapped[str] = mapped_column(String(120))
    model: Mapped[str] = mapped_column(String(120))
    pmax_w: Mapped[float] = mapped_column(Float)
    vmp_v: Mapped[float] = mapped_column(Float)
    imp_a: Mapped[float] = mapped_column(Float)
    voc_v: Mapped[float] = mapped_column(Float)
    isc_a: Mapped[float] = mapped_column(Float)
    gamma_pmax_per_c: Mapped[float] = mapped_column(Float)  # e.g. -0.0035 /°C
    technology: Mapped[str] = mapped_column(String(40), default="mono-Si")
    bifacial: Mapped[bool] = mapped_column(Boolean, default=False)
    datasheet_object_key: Mapped[str | None] = mapped_column(String(300))
    source: Mapped[str] = mapped_column(String(64), default="datasheet")


class Asset(Base):
    __tablename__ = "assets"
    asset_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), index=True)
    asset_type: Mapped[str] = mapped_column(String(32), index=True)
    name: Mapped[str] = mapped_column(String(200))
    manufacturer: Mapped[str | None] = mapped_column(String(120))
    model: Mapped[str | None] = mapped_column(String(120))
    serial_reference: Mapped[str | None] = mapped_column(String(120))
    commissioning_date: Mapped[date | None] = mapped_column(Date)
    rated_capacity: Mapped[float | None] = mapped_column(Float)
    rated_capacity_unit: Mapped[str | None] = mapped_column(String(16))  # kWp | kW | kVA | kWh
    electrical_parameters: Mapped[dict] = mapped_column(JSONType, default=dict)
    latitude: Mapped[float | None] = mapped_column(Float)
    longitude: Mapped[float | None] = mapped_column(Float)
    parent_asset_id: Mapped[str | None] = mapped_column(ForeignKey("assets.asset_id"), index=True)
    module_type_id: Mapped[str | None] = mapped_column(ForeignKey("module_types.id"))
    warranty_reference: Mapped[str | None] = mapped_column(String(120))
    warranty_expiry: Mapped[date | None] = mapped_column(Date)
    maintenance_status: Mapped[str] = mapped_column(String(32), default="in_service")
    source: Mapped[str] = mapped_column(String(64), default="manual")
    effective_from: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    effective_to: Mapped[datetime | None] = mapped_column(UTCDateTime)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class PVSystemConfig(Base):
    """Modelling parameters for an array block (orientation, tracking, DC rating, losses)."""

    __tablename__ = "pv_system_configs"
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.asset_id"), primary_key=True)
    inverter_asset_id: Mapped[str] = mapped_column(ForeignKey("assets.asset_id"))
    mounting: Mapped[str] = mapped_column(String(32), default="fixed")  # fixed | single_axis
    surface_tilt_deg: Mapped[float] = mapped_column(Float)
    surface_azimuth_deg: Mapped[float] = mapped_column(Float)  # 180 = south
    axis_azimuth_deg: Mapped[float | None] = mapped_column(Float)
    max_rotation_deg: Mapped[float | None] = mapped_column(Float)
    gcr: Mapped[float | None] = mapped_column(Float)
    dc_capacity_kwp: Mapped[float] = mapped_column(Float)
    gamma_pdc_per_c: Mapped[float] = mapped_column(Float, default=-0.0035)
    temperature_model: Mapped[str] = mapped_column(String(64), default="open_rack_glass_polymer")
    dc_loss_fraction: Mapped[float] = mapped_column(Float, default=0.03)
    effective_from: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    source: Mapped[str] = mapped_column(String(64), default="design_documents")


class ElectricalConnection(Base):
    __tablename__ = "electrical_connections"
    __table_args__ = (UniqueConstraint("from_asset_id", "to_asset_id", "effective_from"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), index=True)
    from_asset_id: Mapped[str] = mapped_column(ForeignKey("assets.asset_id"))
    to_asset_id: Mapped[str] = mapped_column(ForeignKey("assets.asset_id"))
    connection_type: Mapped[str] = mapped_column(String(32))  # dc | ac_lv | ac_mv | ac_hv | measurement
    effective_from: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    effective_to: Mapped[datetime | None] = mapped_column(UTCDateTime)
    source: Mapped[str] = mapped_column(String(64), default="single_line_diagram")


class MonitoringPoint(Base):
    __tablename__ = "monitoring_points"
    __table_args__ = (UniqueConstraint("source", "external_tag", "effective_from"),)
    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.asset_id"), index=True)
    measurement_type: Mapped[str] = mapped_column(String(48))
    unit: Mapped[str] = mapped_column(String(16))
    source: Mapped[str] = mapped_column(String(64))
    external_tag: Mapped[str] = mapped_column(String(160))
    nominal_interval_s: Mapped[int] = mapped_column(Integer, default=300)
    meter_role: Mapped[str | None] = mapped_column(String(32))  # export_settlement|site_check|inverter
    effective_from: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    effective_to: Mapped[datetime | None] = mapped_column(UTCDateTime)
