"""Asset register services: fixture loading, hierarchy, connectivity, history."""

from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from sun_king.assets.models import (
    Asset,
    ElectricalConnection,
    ModuleType,
    MonitoringPoint,
    Organisation,
    Portfolio,
    PVSystemConfig,
    Site,
)


def _d(v):
    return date.fromisoformat(v) if isinstance(v, str) else v


def load_register(session: Session, fx: dict, effective_from: datetime) -> None:
    """Idempotently load organisation, portfolio, sites and assets from a fixture dict."""
    if session.get(Organisation, fx["organisation"]["id"]) is None:
        session.add(Organisation(**fx["organisation"]))
    if session.get(Portfolio, fx["portfolio"]["id"]) is None:
        session.add(Portfolio(**fx["portfolio"]))
    for m in fx["module_types"]:
        if session.get(ModuleType, m["id"]) is None:
            session.add(ModuleType(**m))
    for s in fx["sites"]:
        if session.get(Site, s["id"]) is None:
            session.add(Site(**{**s, "commissioning_date": _d(s["commissioning_date"])}))
    session.flush()
    # parents before children
    pending = list(fx["assets"])
    known = {a for (a,) in session.execute(select(Asset.asset_id))}
    while pending:
        progressed = False
        for a in list(pending):
            if a["asset_id"] in known:
                pending.remove(a)
                continue
            if a["parent_asset_id"] and a["parent_asset_id"] not in known:
                continue
            session.add(
                Asset(
                    **{
                        **a,
                        "commissioning_date": _d(a["commissioning_date"]),
                        "warranty_expiry": _d(a.get("warranty_expiry")),
                        "effective_from": effective_from,
                    }
                )
            )
            session.flush()
            known.add(a["asset_id"])
            pending.remove(a)
            progressed = True
        if not progressed and pending:
            raise ValueError(f"unresolvable parents: {[a['asset_id'] for a in pending]}")
    for p in fx["pv_system_configs"]:
        if session.get(PVSystemConfig, p["asset_id"]) is None:
            session.add(PVSystemConfig(**p, effective_from=effective_from))
    if not session.scalar(select(ElectricalConnection.id).limit(1)):
        for c in fx["electrical_connections"]:
            session.add(ElectricalConnection(**c, effective_from=effective_from))
    for mp in fx["monitoring_points"]:
        if session.get(MonitoringPoint, mp["id"]) is None:
            session.add(MonitoringPoint(**mp, effective_from=effective_from))
    session.flush()


def asset_dict(a: Asset) -> dict:
    return {
        "asset_id": a.asset_id,
        "site_id": a.site_id,
        "asset_type": a.asset_type,
        "name": a.name,
        "manufacturer": a.manufacturer,
        "model": a.model,
        "serial_reference": a.serial_reference,
        "commissioning_date": a.commissioning_date.isoformat() if a.commissioning_date else None,
        "rated_capacity": a.rated_capacity,
        "rated_capacity_unit": a.rated_capacity_unit,
        "electrical_parameters": a.electrical_parameters,
        "location": {"latitude": a.latitude, "longitude": a.longitude} if a.latitude is not None else None,
        "parent_asset": a.parent_asset_id,
        "module_type_id": a.module_type_id,
        "warranty_reference": a.warranty_reference,
        "warranty_expiry": a.warranty_expiry.isoformat() if a.warranty_expiry else None,
        "maintenance_status": a.maintenance_status,
        "source": a.source,
        "effective_dates": {
            "from": a.effective_from.isoformat() if a.effective_from else None,
            "to": a.effective_to.isoformat() if a.effective_to else None,
        },
    }


def hierarchy(session: Session, site_id: str) -> list[dict]:
    """Physical hierarchy as a nested tree (parent_asset_id)."""
    assets = list(
        session.scalars(select(Asset).where(Asset.site_id == site_id, Asset.effective_to.is_(None)))
    )
    nodes = {a.asset_id: {**asset_dict(a), "children": []} for a in assets}
    roots = []
    for a in assets:
        if a.parent_asset_id and a.parent_asset_id in nodes:
            nodes[a.parent_asset_id]["children"].append(nodes[a.asset_id])
        else:
            roots.append(nodes[a.asset_id])
    order = {
        t: i
        for i, t in enumerate(
            [
                "grid_connection",
                "transformer",
                "meter",
                "battery_system",
                "array_block",
                "inverter",
                "tracker",
                "combiner_box",
                "string",
                "weather_station",
                "sensor",
            ]
        )
    }

    def sort(ns):
        ns.sort(key=lambda n: (order.get(n["asset_type"], 99), n["asset_id"]))
        for n in ns:
            sort(n["children"])

    sort(roots)
    return roots


def connectivity(session: Session, site_id: str) -> dict:
    conns = session.scalars(
        select(ElectricalConnection).where(
            ElectricalConnection.site_id == site_id, ElectricalConnection.effective_to.is_(None)
        )
    ).all()
    return {
        "edges": [
            {"from": c.from_asset_id, "to": c.to_asset_id, "type": c.connection_type, "source": c.source}
            for c in conns
        ]
    }


def monitoring_points(session: Session, site_id: str) -> list[dict]:
    rows = session.execute(
        select(MonitoringPoint)
        .join(Asset, Asset.asset_id == MonitoringPoint.asset_id)
        .where(Asset.site_id == site_id)
    ).scalars()
    return [
        {
            "id": m.id,
            "asset_id": m.asset_id,
            "measurement_type": m.measurement_type,
            "unit": m.unit,
            "source": m.source,
            "external_tag": m.external_tag,
            "nominal_interval_s": m.nominal_interval_s,
            "meter_role": m.meter_role,
        }
        for m in rows
    ]


def meter_for_role(session: Session, site_id: str, role: str) -> str | None:
    return session.scalar(
        select(MonitoringPoint.asset_id)
        .join(Asset, Asset.asset_id == MonitoringPoint.asset_id)
        .where(Asset.site_id == site_id, MonitoringPoint.meter_role == role)
        .limit(1)
    )


def site_inverters(session: Session, site_id: str) -> list[Asset]:
    return list(
        session.scalars(
            select(Asset)
            .where(Asset.site_id == site_id, Asset.asset_type == "inverter", Asset.effective_to.is_(None))
            .order_by(Asset.asset_id)
        )
    )


def asset_history(session: Session, asset_id: str) -> list[dict]:
    from sun_king.admin.models import AuditLog
    from sun_king.alerts.models import Alert
    from sun_king.maintenance.models import Defect, InspectionRecord, WorkOrder

    ev: list[dict] = []
    for a in session.scalars(select(AuditLog).where(AuditLog.entity_id == asset_id)):
        ev.append({"at": a.at.isoformat(), "kind": "audit", "summary": a.action, "detail": a.detail})
    for al in session.scalars(select(Alert)):
        if asset_id in (al.affected_assets or []) or al.subject_id == asset_id:
            ev.append(
                {
                    "at": al.first_detected_at.isoformat(),
                    "kind": "alert",
                    "summary": al.title,
                    "ref": al.id,
                    "status": al.status,
                }
            )
    for wo in session.scalars(select(WorkOrder)):
        if asset_id in (wo.asset_ids or []):
            ev.append(
                {
                    "at": (wo.completed_at or wo.created_at).isoformat(),
                    "kind": "work_order",
                    "summary": wo.title,
                    "ref": wo.id,
                    "status": wo.status,
                    "repair": wo.repair_summary,
                }
            )
    for d in session.scalars(select(Defect).where(Defect.asset_id == asset_id)):
        ev.append(
            {
                "at": d.observed_at.isoformat(),
                "kind": "defect",
                "summary": d.description,
                "ref": d.id,
                "status": d.status,
            }
        )
    for i in session.scalars(select(InspectionRecord).where(InspectionRecord.asset_id == asset_id)):
        ev.append(
            {
                "at": i.captured_at.isoformat(),
                "kind": "inspection",
                "summary": f"Inspection {i.template_id}",
                "ref": i.id,
                "status": i.status,
            }
        )
    ev.sort(key=lambda e: e["at"], reverse=True)
    return ev


def search_assets(
    session: Session, site_ids: list[str], q: str | None, asset_type: str | None
) -> list[Asset]:
    stmt = select(Asset).where(Asset.site_id.in_(site_ids), Asset.effective_to.is_(None))
    if asset_type:
        stmt = stmt.where(Asset.asset_type == asset_type)
    if q:
        like = f"%{q}%"
        stmt = stmt.where(
            or_(Asset.asset_id.ilike(like), Asset.name.ilike(like), Asset.serial_reference.ilike(like))
        )
    return list(session.scalars(stmt.order_by(Asset.site_id, Asset.asset_id)))
