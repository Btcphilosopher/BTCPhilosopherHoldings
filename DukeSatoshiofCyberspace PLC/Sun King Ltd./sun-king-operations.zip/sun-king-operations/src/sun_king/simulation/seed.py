"""Build the 'Sun King Pennine Portfolio' demonstration dataset.

Usage::

    python -m sun_king.cli seed --days 14

Telemetry passes through the real ingestion pipeline (validation, duplicate
handling, late/out-of-order detection); alerts are produced by replaying the
alert engine *as-of* each evaluation time.
"""

from __future__ import annotations

import logging
import time as _time
from datetime import UTC, date, datetime, timedelta

import pandas as pd
from sqlalchemy.orm import Session

from sun_king.adapters.simulator import SimulatedWeatherForecastAdapter, SimulatorTelemetryAdapter
from sun_king.admin.models import AdapterConfig, SiteRole, User
from sun_king.admin.security import hash_password
from sun_king.alerts.engine import ensure_default_rules, replay
from sun_king.assets.models import Site
from sun_king.assets.service import load_register
from sun_king.commercial.models import Contract, MaintenanceCost, Receipt, SettlementStatement
from sun_king.commercial.service import synthetic_price_series
from sun_king.config import get_settings
from sun_king.core.timeutil import floor_time, local_date, utcnow
from sun_king.energy.models import CurtailmentRecord
from sun_king.maintenance.models import (
    CleaningRecord,
    Contractor,
    InspectionTemplate,
    MaintenanceSchedule,
    SparePart,
    VegetationRecord,
)
from sun_king.maintenance.service import DEFAULT_TEMPLATES
from sun_king.simulation.plant import PlantSimulator, load_fixture
from sun_king.telemetry.ingest import ingest_batch
from sun_king.telemetry.schemas import ObservationIn

log = logging.getLogger("sun_king.seed")


def _chunks(obs: list[ObservationIn], n: int):
    for i in range(0, len(obs), n):
        yield obs[i : i + n]


def seed(
    session: Session,
    days: int = 14,
    now: datetime | None = None,
    replay_days: int = 7,
    train_forecasts: bool = True,
    progress=print,
) -> dict:
    t0 = _time.time()
    now = floor_time(now or utcnow(), 60)
    fx = load_fixture()
    tz = fx["sites"][0]["timezone"]
    anchor = local_date(now, tz)
    plant = PlantSimulator(anchor, fx)
    start = floor_time(now - timedelta(days=days), 300)
    load_register(session, fx, effective_from=start - timedelta(days=1))
    _users(session, fx)
    _reference_data(session, fx, plant, anchor, now)
    ensure_default_rules(session)
    session.commit()
    progress(f"register loaded ({_time.time() - t0:.1f}s)")

    adapter = SimulatorTelemetryAdapter(plant)
    late = plant.event("late_delivery")
    dup = plant.event("duplicate_delivery")
    stats = {"batches": 0, "observations": 0, "duplicates": 0, "late": 0, "out_of_order": 0, "rejected": 0}
    for site in fx["sites"]:
        sid = site["id"]
        t = start
        held: list[ObservationIn] = []
        while t < now:
            t_end = min(t + timedelta(hours=4), now)
            res = adapter.fetch(sid, t, t_end, freq="5min")
            obs = res.observations
            if sid == late.site_id:
                keep = []
                for o in obs:
                    if o.source == "sim-weather" and late.start <= o.observation_time < late.end:
                        held.append(o)
                    else:
                        keep.append(o)
                obs = keep
            for chunk in _chunks(obs, 8000):
                s = ingest_batch(
                    session,
                    chunk,
                    source="simulator",
                    now=t_end + timedelta(seconds=40),
                    arrival_time=lambda o: o.observation_time + timedelta(seconds=40),
                    idempotency_key=f"seed-{sid}-{t_end.isoformat()}-{len(chunk)}-{chunk[0].observation_time.isoformat()}",
                )
                _acc(stats, s)
            # deliver held (late) data 95 minutes after the window closes
            if held and t_end >= late.end + timedelta(minutes=95):
                s = ingest_batch(session, held, source="simulator", now=late.end + timedelta(minutes=95))
                _acc(stats, s)
                held = []
            # logger re-sends one hour of meter data the next morning
            if sid == dup.site_id and t <= dup.start + timedelta(hours=22) < t_end:
                again = adapter.sim.observations(
                    sid,
                    pd.date_range(
                        dup.start + timedelta(hours=1),
                        dup.start + timedelta(hours=2),
                        freq="5min",
                        inclusive="right",
                    ),
                )[0]
                again = [o for o in again if o.source == "sim-meter" and o.measurement_type == "ac_power"]
                s = ingest_batch(session, again, source="simulator", now=dup.start + timedelta(hours=22))
                _acc(stats, s)
            session.commit()
            t = t_end
        progress(f"{sid}: telemetry ingested ({_time.time() - t0:.1f}s)")
    # replay alert engine as-of each evaluation time
    rs = max(start, now - timedelta(days=replay_days))
    for site in fx["sites"]:
        n = replay(session, site["id"], rs, now, step_min=15)
        session.commit()
        progress(f"{site['id']}: alert replay {n} evaluations ({_time.time() - t0:.1f}s)")
    out = {"anchor_day": anchor.isoformat(), "start": start.isoformat(), "now": now.isoformat(), **stats}
    if train_forecasts:
        from sun_king.forecasting.service import issue_forecast, train_and_evaluate

        nwp = SimulatedWeatherForecastAdapter(plant)
        for site in fx["sites"]:
            s = session.get(Site, site["id"])
            for ht in ("intraday", "day_ahead"):
                r = train_and_evaluate(session, s, nwp, start + timedelta(days=1), now, ht)
                issue_forecast(session, s, nwp, now, r["model"], ht)
                out[f"forecast_{site['id']}_{ht}"] = {
                    k: r["evaluation"].get(k) for k in ("status", "train_rows", "test_rows")
                }
            yday = now - timedelta(days=1)
            r = train_and_evaluate(
                session, s, nwp, start + timedelta(days=1), yday - timedelta(hours=14), "day_ahead"
            )
            issue_forecast(
                session,
                s,
                nwp,
                (yday - timedelta(days=1)).replace(hour=10, minute=0),
                r["model"],
                "day_ahead",
            )
            issue_forecast(
                session,
                s,
                nwp,
                (yday - timedelta(days=1)).replace(hour=10, minute=0),
                r["model"],
                "day_ahead",
                observed_weather=True,
            )
            session.commit()
        progress(f"forecasts trained and issued ({_time.time() - t0:.1f}s)")
    out["seconds"] = round(_time.time() - t0, 1)
    return out


def _acc(stats, s):
    stats["batches"] += 1
    stats["observations"] += s.accepted
    stats["duplicates"] += s.duplicates
    stats["late"] += s.late
    stats["out_of_order"] += s.out_of_order
    stats["rejected"] += s.rejected


def _users(session: Session, fx: dict) -> None:
    pw = get_settings().demo_password
    h = hash_password(pw)
    for u in fx["users"]:
        if session.get(User, u["id"]) is None:
            session.add(
                User(
                    id=u["id"],
                    organisation_id=fx["organisation"]["id"],
                    email=u["email"],
                    display_name=u["display_name"],
                    password_hash=h,
                    org_role=u["org_role"],
                )
            )
            session.flush()
            for sid, role in (u.get("site_roles") or {}).items():
                session.add(SiteRole(user_id=u["id"], site_id=sid, role=role))
    if session.get(User, "svc-collector") is None:
        session.add(
            User(
                id="svc-collector",
                organisation_id=fx["organisation"]["id"],
                email="collector@sunking.example",
                display_name="OT collector (ingest only)",
                password_hash=None,
                org_role="viewer",
                is_service_account=True,
                service_scope="ingest",
            )
        )
    session.flush()


def _reference_data(session: Session, fx: dict, plant: PlantSimulator, anchor: date, now: datetime) -> None:
    if session.get(Contractor, fx["contractors"][0]["id"]) is not None:
        return
    for c in fx["contractors"]:
        session.add(
            Contractor(
                **{
                    **c,
                    "accreditation_expiry": date.fromisoformat(c["accreditation_expiry"])
                    if c.get("accreditation_expiry")
                    else None,
                }
            )
        )
    for t in DEFAULT_TEMPLATES:
        session.add(InspectionTemplate(**t))
    session.flush()
    # recorded curtailment (from the DNO instruction log)
    cev = plant.event("curtailment")
    session.add(
        CurtailmentRecord(
            id="curt-cle-001",
            site_id=cev.site_id,
            start_time=cev.start,
            end_time=cev.end,
            limit_kw=cev.data["limit_kw"],
            instruction_ref=cev.data["instruction_ref"],
            issued_by=cev.data["issued_by"],
            reason="Thermal constraint on 11 kV feeder (fictional)",
            compensable=False,
            source="dno_instruction_log",
        )
    )
    clean = plant.event("cleaning")
    session.add(
        CleaningRecord(
            id="cln-hlm-001",
            site_id="site-hlm",
            asset_ids=["HLM-B1", "HLM-B2", "HLM-B3", "HLM-B4"],
            performed_on=clean.start.date(),
            method="water-fed pole",
            cost=3850.0,
            currency="GBP",
            contractor_id="con-clearpanel",
            notes="Annual clean ahead of winter (fictional)",
        )
    )
    session.add(
        VegetationRecord(
            id="veg-cle-001",
            site_id="site-cle",
            area="Perimeter and rows B1–B4",
            performed_on=anchor - timedelta(days=20),
            method="sheep grazing",
            ecological_constraints="Ground-nesting bird survey clear; no cutting within 5 m of hedge (fictional)",
            contractor_id="con-moorgreen",
            cost=900.0,
            currency="GBP",
        )
    )
    # preventive schedules (one overdue on purpose)
    scheds = [
        (
            "sch-hlm-inv-pm",
            "site-hlm",
            None,
            "preventive",
            "Inverter annual preventive maintenance (all)",
            365,
            anchor - timedelta(days=300),
            "con-pennine-elec",
        ),
        (
            "sch-hlm-thermo",
            "site-hlm",
            None,
            "inspection",
            "Thermographic survey (drone)",
            365,
            anchor - timedelta(days=372),
            None,
        ),
        (
            "sch-hlm-clean",
            "site-hlm",
            None,
            "cleaning",
            "Module cleaning",
            180,
            clean.start.date(),
            "con-clearpanel",
        ),
        (
            "sch-cle-veg",
            "site-cle",
            None,
            "vegetation",
            "Vegetation management",
            60,
            anchor - timedelta(days=20),
            "con-moorgreen",
        ),
        (
            "sch-cle-bess",
            "site-cle",
            "CLE-BESS-1",
            "preventive",
            "BESS HVAC and fire-system service",
            180,
            anchor - timedelta(days=170),
            None,
        ),
        (
            "sch-cle-insp",
            "site-cle",
            None,
            "inspection",
            "Quarterly site inspection",
            90,
            anchor - timedelta(days=95),
            None,
        ),
    ]
    for sid_, site, asset, tt, title, iv, last, con in scheds:
        session.add(
            MaintenanceSchedule(
                id=sid_,
                site_id=site,
                asset_id=asset,
                task_type=tt,
                title=title,
                interval_days=iv,
                last_completed=last,
                next_due=last + timedelta(days=iv),
                contractor_id=con,
                form_template_id="tpl-site-inspection" if tt == "inspection" else None,
            )
        )
    for pid, pn, desc, models, qty, mn, loc, cost in [
        (
            "sp-igbt-1250",
            "VC-IGBT-1250",
            "IGBT power module for VC-1250 (fictional)",
            ["VC-1250"],
            2,
            1,
            "HLM store",
            4200.0,
        ),
        (
            "sp-fan-vc",
            "VC-FAN-02",
            "Inverter cooling fan assembly",
            ["VC-1250", "VC-875"],
            6,
            4,
            "HLM store",
            380.0,
        ),
        ("sp-fuse-20a", "PV-FUSE-20A-1500V", "20 A 1500 V gPV string fuse", [], 40, 30, "CLE store", 9.5),
        ("sp-dc-cable", "H1Z2Z2-K-6MM", "6 mm² DC solar cable (m)", [], 120, 100, "HLM store", 2.1),
        (
            "sp-pyr",
            "MP-20",
            "Pyranometer (secondary standard) — calibration spare",
            ["MP-20"],
            0,
            1,
            "Head office",
            1650.0,
        ),
    ]:
        session.add(
            SparePart(
                id=pid,
                part_number=pn,
                description=desc,
                compatible_models=models,
                quantity_on_hand=qty,
                minimum_quantity=mn,
                storage_location=loc,
                unit_cost=cost,
            )
        )
    # commercial
    session.add(
        Contract(
            id="ctr-hlm-ppa",
            site_id="site-hlm",
            counterparty="Northern Grid Supply Ltd (fictional)",
            contract_type="fixed_ppa",
            start_date=date(2025, 1, 1),
            end_date=date(2029, 12, 31),
            currency="GBP",
            fixed_price_per_mwh=72.5,
            price_source="PPA schedule 2, clause 4.1 (fictional)",
            settlement_meter_asset_id="HLM-MTR-EXP",
        )
    )
    session.add(
        Contract(
            id="ctr-cle-idx",
            site_id="site-cle",
            counterparty="Calder Offtake Partners (fictional)",
            contract_type="index_linked",
            start_date=date(2025, 4, 1),
            end_date=date(2030, 3, 31),
            currency="GBP",
            price_series_id="idx-synthetic-hh",
            price_source="SYNTHETIC half-hourly index (demo only)",
            settlement_meter_asset_id="CLE-MTR-EXP",
        )
    )
    for pp in synthetic_price_series(
        "idx-synthetic-hh", datetime.combine(anchor - timedelta(days=30), datetime.min.time(), UTC), 33
    ):
        session.add(pp)
    # a settlement statement for a past week, with a receipt
    ws = anchor - timedelta(days=13)
    we = anchor - timedelta(days=7)
    session.add(
        SettlementStatement(
            id="stm-hlm-001",
            site_id="site-hlm",
            contract_id="ctr-hlm-ppa",
            period_start=ws,
            period_end=we,
            statement_ref="NGS-STM-2026-0471 (fictional)",
            settled_energy_mwh=0.0,
            amount=0.0,
            currency="GBP",
            issued_on=anchor - timedelta(days=2),
            source="csv_import",
        )
    )
    session.add(
        MaintenanceCost(
            id="cost-cln-001",
            site_id="site-hlm",
            incurred_on=clean.start.date(),
            category="cleaning",
            amount=3850.0,
            currency="GBP",
            supplier="ClearPanel Cleaning Co (fictional)",
            invoice_ref="CP-INV-8812",
        )
    )
    session.add(
        MaintenanceCost(
            id="cost-veg-001",
            site_id="site-cle",
            incurred_on=anchor - timedelta(days=20),
            category="vegetation",
            amount=900.0,
            currency="GBP",
            supplier="Moorgreen Land Management (fictional)",
            invoice_ref="MG-2209",
        )
    )
    session.add(
        AdapterConfig(
            id="sim-all",
            kind="simulator",
            implementation="simulator",
            enabled=True,
            mode="simulated",
            poll_interval_s=30,
            settings={
                "note": "Synthetic telemetry for all demo sites",
                "anchor_day": anchor.isoformat(),
                "seed": plant.seed,
            },
        )
    )
    session.add(
        AdapterConfig(
            id="example-inverter-portal",
            kind="inverter_monitoring",
            implementation="generic_https_json",
            site_id="site-hlm",
            enabled=False,
            mode="live",
            endpoint=None,
            credential_ref="SUN_KING_HLM_PORTAL_TOKEN",
            allowed_hosts=[],
            verified_documentation_ref=None,
            settings={
                "note": "Disabled template. Requires verified vendor documentation, explicit host allow-list and "
                "deployment-level enablement before any live use."
            },
        )
    )
    session.flush()


def finalise_statement(session: Session) -> None:
    """Fill the demo statement with figures close to (but not equal to) the measured export."""
    from sun_king.commercial.service import estimated_value

    st = session.get(SettlementStatement, "stm-hlm-001")
    if st is None or st.settled_energy_mwh:
        return
    est = estimated_value(session, st.site_id, st.period_start, st.period_end)
    mwh = (est.get("measured_export_kwh") or 0) / 1000
    st.settled_energy_mwh = round(mwh * 0.9985, 3)  # counterparty applies line-loss factor (fictional)
    st.amount = round(st.settled_energy_mwh * 72.5, 2)
    session.add(
        Receipt(
            id="rcp-hlm-001",
            statement_id=st.id,
            site_id=st.site_id,
            received_on=st.issued_on,
            amount=round(st.amount * 0.6, 2),
            currency="GBP",
            reference="BACS 77120 (part payment, fictional)",
        )
    )
    session.flush()
