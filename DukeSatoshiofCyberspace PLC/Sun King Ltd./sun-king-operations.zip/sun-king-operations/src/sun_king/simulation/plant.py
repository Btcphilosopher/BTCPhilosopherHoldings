"""Synthetic PV plant behaviour, including the demo's injected events.

The "truth" model deliberately differs a little from the platform's
expected-yield model (per-unit mismatch, soiling, a different cell
temperature model and noise) so that expected-vs-measured comparisons show
realistic residuals rather than a perfect match.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from pathlib import Path
from types import SimpleNamespace
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

from sun_king.adapters import pvmodel
from sun_king.simulation.noise import normal, ns, uniform
from sun_king.simulation.weather import WeatherModel

FIXTURE = Path(__file__).resolve().parents[3] / "fixtures" / "pennine_portfolio.json"
SITE_KEYS = {"site-hlm": 1, "site-cle": 2}
UNIT_FACTOR = {  # per-inverter mismatch/availability of DC (truth only)
    "HLM-INV-01": 0.985,
    "HLM-INV-02": 0.992,
    "HLM-INV-03": 0.981,
    "HLM-INV-04": 0.976,
    "CLE-INV-01": 0.988,
    "CLE-INV-02": 0.983,
    "CLE-INV-03": 0.979,
    "CLE-INV-04": 0.990,
}
REGISTER_BASE = {
    "HLM-MTR-EXP:export_energy": 21_480_000.0,
    "HLM-MTR-EXP:import_energy": 61_250.0,
    "CLE-MTR-EXP:export_energy": 9_842_000.0,
    "CLE-MTR-EXP:import_energy": 38_400.0,
}


def load_fixture(path: Path | None = None) -> dict:
    return json.loads((path or FIXTURE).read_text())


@dataclass
class Event:
    id: str
    type: str
    site_id: str
    asset_id: str | None
    start: datetime
    end: datetime | None
    data: dict = field(default_factory=dict)


def _at(anchor: date, offset: int, hhmm: str, tz: str) -> datetime:
    h, m = map(int, hhmm.split(":"))
    return datetime.combine(anchor + timedelta(days=offset), time(h, m), tzinfo=ZoneInfo(tz)).astimezone(
        ZoneInfo("UTC")
    )


class PlantSimulator:
    """Deterministic generator of 'true' plant behaviour for the fixture sites."""

    def __init__(self, anchor_day: date, fixture: dict | None = None, seed: int = 20261127):
        self.fx = fixture or load_fixture()
        self.anchor = anchor_day
        self.seed = seed
        self.sites = {s["id"]: SimpleNamespace(**s) for s in self.fx["sites"]}
        self.assets = {a["asset_id"]: a for a in self.fx["assets"]}
        self.pv = {p["asset_id"]: p for p in self.fx["pv_system_configs"]}
        forced = {
            anchor_day + timedelta(days=int(k)): v for k, v in self.fx["scenario"]["forced_day_types"].items()
        }
        self.weather = WeatherModel(seed, forced)
        self.events = self._events()
        self.disconnected_until: dict[str, datetime] = {}  # site_id -> until (demo outage toggle)

    # ------------------------------------------------------------------ events
    def _events(self) -> list[Event]:
        out = []
        for e in self.fx["scenario"]["events"]:
            tz = self.sites[e["site_id"]].timezone
            off = e["day_offset"]
            if "local_start" in e:
                start = _at(self.anchor, off, e["local_start"], tz)
                end = _at(self.anchor, off, e["local_end"], tz)
            elif "local_time" in e:
                start = _at(self.anchor, off, e["local_time"], tz)
                end = (
                    _at(self.anchor, e["repair_day_offset"], e["repair_local_time"], tz)
                    if "repair_day_offset" in e
                    else None
                )
            else:
                start = _at(self.anchor, off, "09:00", tz)
                end = start + timedelta(hours=6)
            out.append(Event(e["id"], e["type"], e["site_id"], e.get("asset_id"), start, end, e))
        return out

    def event(self, etype: str) -> Event:
        return next(e for e in self.events if e.type == etype)

    def _active(self, ev: Event, times: pd.DatetimeIndex) -> np.ndarray:
        t = ns(times)
        s = pd.Timestamp(ev.start).value
        e = pd.Timestamp(ev.end).value if ev.end else np.iinfo(np.int64).max
        return (t >= s) & (t < e)

    # ------------------------------------------------------------------ specs
    def array_specs(self, site_id: str) -> list[tuple[pvmodel.ArraySpec, pvmodel.InverterSpec]]:
        out = []
        for p in self.pv.values():
            inv = self.assets[p["inverter_asset_id"]]
            if inv["site_id"] != site_id:
                continue
            spec = pvmodel.ArraySpec(
                asset_id=p["asset_id"],
                inverter_asset_id=p["inverter_asset_id"],
                dc_kwp=p["dc_capacity_kwp"],
                tilt=p["surface_tilt_deg"],
                azimuth=p["surface_azimuth_deg"],
                mounting=p["mounting"],
                axis_azimuth=p.get("axis_azimuth_deg") or 180.0,
                max_rotation=p.get("max_rotation_deg") or 55.0,
                gcr=p.get("gcr") or 0.35,
                gamma_pdc=p["gamma_pdc_per_c"],
                temperature_model=p["temperature_model"],
                dc_loss_fraction=p["dc_loss_fraction"],
            )
            ip = inv["electrical_parameters"]
            out.append((spec, pvmodel.InverterSpec(inv["asset_id"], ip["ac_kw"], ip.get("eta_nom", 0.98))))
        return sorted(out, key=lambda x: x[1].asset_id)

    def soiling_ratio(self, site_id: str, times: pd.DatetimeIndex) -> np.ndarray:
        if site_id != "site-hlm":
            return np.full(len(times), 0.995)
        clean = next(e for e in self.events if e.type == "cleaning")
        days_since = (ns(times) - pd.Timestamp(clean.start).value) / 86400e9
        pre = 0.962 - 0.0012 * (days_since + 30)  # dirty before the cleaning
        post = 0.996 - 0.0016 * days_since
        return np.where(days_since >= 0, np.clip(post, 0.93, 1.0), np.clip(pre, 0.90, 1.0))

    # ------------------------------------------------------------------ truth
    def truth(self, site_id: str, times: pd.DatetimeIndex) -> dict:
        site = self.sites[site_id]
        wx = self.weather.observe(site, SITE_KEYS[site_id], times)
        secs = ns(times) // 10**9
        soil = self.soiling_ratio(site_id, times)
        inv_out: dict[str, pd.DataFrame] = {}
        poa_ref = None
        for spec, inv in self.array_specs(site_id):
            poa = pvmodel.poa_irradiance(spec, wx[["ghi", "dni", "dhi"]], wx, site.albedo)
            # truth uses Faiman cell temperature (the platform model uses SAPM)
            from pvlib import temperature

            tcell = temperature.faiman(poa, wx["temp_air"], wx["wind_speed"])
            dc = pvmodel.dc_power_kw(spec, poa * soil, tcell) * UNIT_FACTOR[inv.asset_id]
            dc = dc * (1 + 0.004 * normal(inv.asset_id + "dc", secs // 60))
            status = np.where(wx["apparent_elevation"].to_numpy() > -2.0, 0, 1)
            for ev in self.events:
                if ev.asset_id != inv.asset_id:
                    continue
                act = self._active(ev, times)
                if ev.type == "partial_dc_loss":
                    dc = dc.where(~act, dc * (1 - ev.data["fraction_lost"]))
            dc = dc.clip(lower=0)
            ac, _ = pvmodel.ac_power_kw(inv, dc)
            fail = np.zeros(len(times), bool)
            for ev in self.events:
                if ev.asset_id == inv.asset_id and ev.type == "inverter_failure":
                    fail = self._active(ev, times)
            ac = ac.where(~fail, 0.0)
            status = np.where(fail, ev_code(self, inv.asset_id), status)
            day = wx["apparent_elevation"].to_numpy() > 0
            vmp = np.where(
                day,
                1080
                + 40 * (1 - (tcell.to_numpy() - 25) * 0.003)
                + 6 * normal(inv.asset_id + "v", secs // 60),
                0,
            )
            vmp = np.where(fail & day, 1470.0, vmp)
            dcp = np.where(fail, 0.0, dc.to_numpy())
            inv_out[inv.asset_id] = pd.DataFrame(
                {
                    "ac_kw": ac.to_numpy(),
                    "dc_kw": dcp,
                    "dc_v": vmp,
                    "dc_a": np.where(vmp > 0, dcp * 1000 / np.maximum(vmp, 1), 0.0),
                    "poa": poa.to_numpy(),
                    "tcell": tcell.to_numpy(),
                    "status": status,
                    "inv_temp": wx["temp_air"].to_numpy() + 8 + 22 * ac.to_numpy() / inv.ac_kw,
                },
                index=times,
            )
            if poa_ref is None and spec.mounting == "fixed" and spec.azimuth == 180:
                poa_ref = poa
                tmod_ref = pvmodel.module_back_temperature(spec, poa, wx["temp_air"], wx["wind_speed"])

        # curtailment / export limiting
        total_ac = sum(df["ac_kw"] for df in inv_out.values())
        limit = np.full(len(times), site.export_limit_kw)
        curtailed = np.zeros(len(times), bool)
        for ev in self.events:
            if ev.site_id == site_id and ev.type == "curtailment":
                act = self._active(ev, times)
                limit = np.where(act, ev.data["limit_kw"], limit)
                curtailed |= act

        # battery (CLE only)
        batt = None
        bess = next(
            (
                a
                for a in self.assets.values()
                if a["site_id"] == site_id and a["asset_type"] == "battery_system"
            ),
            None,
        )
        if bess:
            batt = self._battery(site, bess, times, total_ac.to_numpy())

        tx = next(
            a for a in self.assets.values() if a["site_id"] == site_id and a["asset_type"] == "transformer"
        )
        txp = tx["electrical_parameters"]
        bp = batt["power_kw"] if batt is not None else np.zeros(len(times))
        gross = total_ac.to_numpy() + bp
        tx_loss = txp["no_load_loss_kw"] + txp["load_loss_kw_at_rated"] * (gross / tx["rated_capacity"]) ** 2
        aux = np.where(wx["apparent_elevation"].to_numpy() > 0, 6.0, 4.0)
        net = gross - tx_loss - aux
        over = np.maximum(net - limit, 0)
        if over.any():
            # inverters reduce output proportionally to respect the export limit
            scale = np.where(total_ac.to_numpy() > 0, 1 - over / np.maximum(total_ac.to_numpy(), 1e-6), 1)
            for df in inv_out.values():
                df["ac_kw"] = df["ac_kw"].to_numpy() * scale
                df["status"] = np.where(
                    (over > 0) & (df["status"].to_numpy() == 0), 2, df["status"].to_numpy()
                )
                df["dc_kw"] = np.where(over > 0, df["ac_kw"].to_numpy() / 0.975, df["dc_kw"].to_numpy())
                df["dc_a"] = np.where(df["dc_v"] > 0, df["dc_kw"] * 1000 / np.maximum(df["dc_v"], 1), 0.0)
            net = np.minimum(net, limit)
        meter_kw = net + 0.8 * normal(site_id + "mtr", secs // 60)
        return {
            "weather": wx,
            "poa_ref": poa_ref,
            "tmod": tmod_ref,
            "inverters": inv_out,
            "meter_kw": meter_kw,
            "curtailed": curtailed,
            "export_limit": limit,
            "battery": batt,
            "soiling": soil,
            "bess_id": bess["asset_id"] if bess else None,
        }

    def _battery(self, site, bess, times: pd.DatetimeIndex, pv_ac: np.ndarray) -> dict:
        p = bess["electrical_parameters"]
        e_kwh, pmax = p["energy_kwh"], p["power_kw"]
        eff = np.sqrt(p["round_trip_efficiency"])
        local = times.tz_convert(site.timezone)
        hours = (local.hour + local.minute / 60.0).to_numpy()
        # deterministic schedule recomputed from a fixed daily start SoC so live == history
        soc = np.empty(len(times))
        power = np.empty(len(times))
        day_start: dict = {}
        for i, h in enumerate(hours):
            d = local[i].date()
            if d not in day_start:
                day_start[d] = p[
                    "soc_min"
                ]  # schedule always ends the evening at SoC min → no jump at midnight
            soc0 = day_start[d]
            # analytic SoC: charge 10:30-13:30 at min(500, pv), discharge 16:00-19:00 at 650
            ch_h = np.clip(h - 10.5, 0, 3.0)
            dis_h = np.clip(h - 16.0, 0, 3.0)
            charge_kw = min(500.0, max(pv_ac[i] - 50, 0))
            s = (
                soc0
                + ch_h * 500.0 * eff / e_kwh * (0.85 if pv_ac[i] < 500 else 1.0)
                - dis_h * 650.0 / eff / e_kwh
            )
            s = float(np.clip(s, p["soc_min"], p["soc_max"]))
            soc[i] = s
            if 10.5 <= h < 13.5:
                power[i] = -charge_kw
            elif 16.0 <= h < 19.0 and s > p["soc_min"] + 0.01:
                power[i] = 650.0
            else:
                power[i] = 0.0
        secs = ns(times) // 10**9
        return {
            "soc": soc,
            "power_kw": power,
            "available_kwh": (soc - p["soc_min"]) * e_kwh,
            "max_charge_kw": np.where(soc < p["soc_max"] - 0.01, pmax, 0.0),
            "max_discharge_kw": np.where(soc > p["soc_min"] + 0.01, pmax, 0.0),
            "temp": 18 + 6 * np.abs(power) / pmax + 0.3 * normal("bess-t", secs // 300),
            "state": np.where(power > 0, 3, np.where(power < 0, 2, 1)),  # 1 idle 2 charging 3 discharging
        }


def ev_code(sim: PlantSimulator, asset_id: str) -> int:
    for ev in sim.events:
        if ev.asset_id == asset_id and ev.type == "inverter_failure":
            return int(ev.data.get("status_code", 312))
    return 0


def jitter_mask(key: str, times: pd.DatetimeIndex, p: float) -> np.ndarray:
    return uniform(key, ns(times) // 10**9) < p
