"""Turns simulated plant truth into monitoring observations, including the
imperfections a real platform must handle: night sensor offsets, missing
values, an implausible spike, a frozen pyranometer, a monitoring-link outage,
a meter register reset, late and duplicated deliveries."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from sun_king.simulation.noise import normal, ns
from sun_king.simulation.plant import REGISTER_BASE, PlantSimulator, jitter_mask
from sun_king.telemetry.schemas import ObservationIn

SRC_SCADA, SRC_METER, SRC_WX, SRC_BMS = "sim-scada", "sim-meter", "sim-weather", "sim-bms"


@dataclass
class RegisterState:
    value: float
    time: datetime
    power_kw: float


def _integrate_register(
    start_value: float,
    times: pd.DatetimeIndex,
    power_kw: np.ndarray,
    prev_time: datetime | None = None,
    prev_kw: float | None = None,
) -> np.ndarray:
    t = ns(times) / 1e9
    p = np.maximum(power_kw, 0.0)
    inc = np.zeros(len(t))
    if len(t) > 1:
        inc[1:] = 0.5 * (p[1:] + p[:-1]) * np.diff(t) / 3600.0
    if prev_time is not None and prev_kw is not None and len(t):
        inc[0] = 0.5 * (max(prev_kw, 0) + p[0]) * (t[0] - prev_time.timestamp()) / 3600.0
    return start_value + np.cumsum(inc)


class TelemetrySimulator:
    def __init__(self, plant: PlantSimulator):
        self.plant = plant
        self.ev = {e.type: e for e in plant.events}

    def observations(
        self,
        site_id: str,
        times: pd.DatetimeIndex,
        registers: dict[str, RegisterState] | None = None,
    ) -> tuple[list[ObservationIn], dict[str, RegisterState]]:
        """Observations for ``times``. ``registers`` carries cumulative counters from a previous call."""
        registers = dict(registers or {})
        tr = self.plant.truth(site_id, times)
        site = self.plant.sites[site_id]
        S = site.code
        secs = ns(times) // 10**9
        obs: list[ObservationIn] = []
        pyts = list(times.to_pydatetime())

        def emit(asset, mtype, values, unit, source, mask=None, status=None):
            vals = np.asarray(values, dtype=float)
            for i, t in enumerate(pyts):
                if mask is not None and not mask[i]:
                    continue
                v = vals[i]
                obs.append(
                    ObservationIn(
                        asset_id=asset,
                        measurement_type=mtype,
                        value=None if np.isnan(v) else round(float(v), 4),
                        unit=unit,
                        observation_time=t,
                        source=source,
                        status_text=status[i] if status is not None else None,
                    )
                )

        # ---- inverters
        comm = self.ev["telemetry_outage"]
        for aid, df in tr["inverters"].items():
            mask = np.ones(len(times), bool)
            if comm.asset_id == aid:
                mask &= ~self.plant._active(comm, times)
            mask &= ~self._site_disconnected(site_id, times)
            emit(aid, "ac_power", df["ac_kw"], "kW", SRC_SCADA, mask)
            emit(aid, "dc_power", df["dc_kw"], "kW", SRC_SCADA, mask)
            emit(aid, "dc_voltage", df["dc_v"], "V", SRC_SCADA, mask)
            emit(aid, "dc_current", df["dc_a"], "A", SRC_SCADA, mask)
            emit(aid, "inverter_temperature", df["inv_temp"], "degC", SRC_SCADA, mask)
            codes = df["status"].to_numpy()
            labels = {0: "running", 1: "standby", 2: "derated", 312: "DC insulation fault", 401: "grid fault"}
            emit(
                aid,
                "status_code",
                codes,
                "code",
                SRC_SCADA,
                mask,
                [labels.get(int(c), "unknown") for c in codes],
            )
            key = f"{aid}:ac_energy"
            prev = registers.get(key)
            start = prev.value if prev else 3_000_000.0 + 10_000 * int(aid[-1])
            reg = _integrate_register(
                start,
                times,
                df["ac_kw"].to_numpy(),
                prev.time if prev else None,
                prev.power_kw if prev else None,
            )
            emit(aid, "ac_energy", reg, "kWh", SRC_SCADA, mask)
            registers[key] = RegisterState(float(reg[-1]), pyts[-1], float(df["ac_kw"].iloc[-1]))

        # ---- export meter (power + cumulative registers with reset)
        meter = f"{S}-MTR-EXP"
        mkw = tr["meter_kw"]
        mmask = ~self._site_disconnected(site_id, times)
        emit(meter, "ac_power", mkw, "kW", SRC_METER, mmask)
        for reg_name, pw in (("export_energy", np.maximum(mkw, 0)), ("import_energy", np.maximum(-mkw, 0))):
            key = f"{meter}:{reg_name}"
            prev = registers.get(key)
            start = prev.value if prev else REGISTER_BASE[key]
            reg = _integrate_register(
                start, times, pw, prev.time if prev else None, prev.power_kw if prev else None
            )
            reset = self.ev["meter_reset"]
            if reset.site_id == site_id and reg_name == "export_energy":
                rt = pd.Timestamp(reset.start).value
                after = ns(times) >= rt
                if after.any() and (prev is None or prev.time.timestamp() * 1e9 < rt):
                    # register restarts from zero at the reset instant
                    i0 = int(np.argmax(after))
                    # energy accumulated from reset instant to the first post-reset sample
                    t0 = ns(times)[i0] / 1e9
                    e0 = max(pw[i0], 0) * (t0 - rt / 1e9) / 3600.0
                    reg = np.where(after, reg - reg[i0] + e0, reg)
            emit(meter, reg_name, reg, "kWh", SRC_METER, mmask)
            registers[key] = RegisterState(float(reg[-1]), pyts[-1], float(pw[-1]))

        # ---- weather station
        wmask = ~self._site_disconnected(site_id, times)
        poa = tr["poa_ref"].to_numpy()
        night = tr["weather"]["apparent_elevation"].to_numpy() <= 0
        off = -2.5 + 0.8 * normal(S + "off", secs // 600)
        p1 = np.where(night, off, poa * 1.004 * (1 + 0.006 * normal(S + "p1", secs)))
        p2 = np.where(night, off - 0.5, poa * 0.996 * (1 + 0.006 * normal(S + "p2", secs)))
        stuck = self.ev["stuck_sensor"]
        if stuck.site_id == site_id:
            act = self.plant._active(stuck, times)
            if act.any():
                # frozen at the value the channel latched at
                ts = pd.DatetimeIndex([pd.Timestamp(stuck.start)])
                latched = float(self.plant.truth(site_id, ts)["poa_ref"].iloc[0]) * 1.004
                p1 = np.where(act, round(latched, 1), p1)
        sensor_ids = {
            "PYR1": f"{S}-PYR1",
            "PYR2": f"{S}-PYR2",
            "GHI": f"{S}-GHI",
            "TMOD": f"{S}-TMOD",
            "WS": f"{S}-WS1",
        }
        emit(sensor_ids["PYR1"], "poa_irradiance", p1, "W/m2", SRC_WX, wmask)
        emit(sensor_ids["PYR2"], "poa_irradiance", p2, "W/m2", SRC_WX, wmask)
        ghi = np.where(night, off, tr["weather"]["ghi"].to_numpy() * (1 + 0.008 * normal(S + "g", secs)))
        emit(sensor_ids["GHI"], "ghi", ghi, "W/m2", SRC_WX, wmask)
        emit(
            sensor_ids["TMOD"],
            "module_temperature",
            tr["tmod"].to_numpy() + 0.3 * normal(S + "tm", secs),
            "degC",
            SRC_WX,
            wmask,
        )
        tamb = tr["weather"]["temp_air"].to_numpy().copy()
        # one implausible spike (logger glitch) seven days before the anchor
        spike_t = pd.Timestamp(self.plant.anchor - timedelta(days=7)).tz_localize("UTC") + pd.Timedelta(
            hours=11, minutes=15
        )
        tamb = np.where((times == spike_t) & (site_id == "site-hlm"), 85.0, tamb)
        emit(sensor_ids["WS"], "ambient_temperature", tamb, "degC", SRC_WX, wmask)
        wind = tr["weather"]["wind_speed"].to_numpy().copy()
        wind = np.where(jitter_mask(S + "wnan", times, 0.006), np.nan, wind)  # sensor dropouts → missing
        emit(sensor_ids["WS"], "wind_speed", wind, "m/s", SRC_WX, wmask)
        if site_id == "site-hlm":
            hourly = (times.minute == 0) & wmask
            emit(f"{S}-SOIL", "soiling_ratio", tr["soiling"], "fraction", SRC_WX, hourly)

        # ---- tracker
        trk = next(
            (
                a
                for a in self.plant.assets.values()
                if a["site_id"] == site_id and a["asset_type"] == "tracker"
            ),
            None,
        )
        if trk:
            from sun_king.adapters import pvmodel

            spec = next(s for s, _ in self.plant.array_specs(site_id) if s.mounting == "single_axis")
            ang = pvmodel.tracker_angle(spec, tr["weather"]).to_numpy()
            emit(trk["asset_id"], "tracker_angle", ang + 0.3 * normal("trk", secs), "deg", SRC_SCADA, wmask)
            emit(trk["asset_id"], "tracker_setpoint", ang, "deg", SRC_SCADA, wmask)

        # ---- battery (read-only BMS telemetry)
        if tr["battery"] is not None:
            b, bid = tr["battery"], tr["bess_id"]
            emit(bid, "battery_soc", b["soc"], "fraction", SRC_BMS, wmask)
            emit(bid, "battery_power", b["power_kw"], "kW", SRC_BMS, wmask)
            emit(bid, "battery_available_energy", b["available_kwh"], "kWh", SRC_BMS, wmask)
            emit(bid, "battery_max_charge_power", b["max_charge_kw"], "kW", SRC_BMS, wmask)
            emit(bid, "battery_max_discharge_power", b["max_discharge_kw"], "kW", SRC_BMS, wmask)
            emit(bid, "battery_temperature", b["temp"], "degC", SRC_BMS, wmask)
            labels = {1: "idle", 2: "charging", 3: "discharging"}
            emit(
                bid, "battery_state", b["state"], "code", SRC_BMS, wmask, [labels[int(x)] for x in b["state"]]
            )
        return obs, registers

    def _site_disconnected(self, site_id: str, times: pd.DatetimeIndex) -> np.ndarray:
        win = self.plant.disconnected_until.get(site_id)
        if win is None:
            return np.zeros(len(times), bool)
        a, b = win
        t = ns(times)
        return (t >= pd.Timestamp(a).value) & (t < pd.Timestamp(b).value)
