"""Deterministic, stateless pseudo-random noise keyed by (stream, time).

Live ticks and history generation therefore produce identical values for the
same timestamp, which keeps the demo reproducible.
"""

from __future__ import annotations

import zlib

import numpy as np

_M64 = np.uint64(0xFFFFFFFFFFFFFFFF)


def _splitmix(x: np.ndarray) -> np.ndarray:
    with np.errstate(over="ignore"):
        x = (x + np.uint64(0x9E3779B97F4A7C15)) & _M64
        z = x
        z = ((z ^ (z >> np.uint64(30))) * np.uint64(0xBF58476D1CE4E5B9)) & _M64
        z = ((z ^ (z >> np.uint64(27))) * np.uint64(0x94D049BB133111EB)) & _M64
        return z ^ (z >> np.uint64(31))


def uniform(key: str, seconds: np.ndarray) -> np.ndarray:
    k = np.uint64(zlib.crc32(key.encode()))
    s = np.asarray(seconds, dtype=np.int64).astype(np.uint64)
    with np.errstate(over="ignore"):
        h = _splitmix(s * np.uint64(1_000_003) ^ (k << np.uint64(20)))
    return (h >> np.uint64(11)).astype(np.float64) / float(1 << 53)


def normal(key: str, seconds: np.ndarray) -> np.ndarray:
    u1 = np.clip(uniform(key + ":a", seconds), 1e-12, 1.0)
    u2 = uniform(key + ":b", seconds)
    return np.sqrt(-2.0 * np.log(u1)) * np.cos(2 * np.pi * u2)


def ns(times) -> np.ndarray:
    """Epoch nanoseconds regardless of the index's stored resolution (pandas ≥3 may use µs)."""
    import pandas as pd

    return pd.DatetimeIndex(times).as_unit("ns").asi8
