"""Synthetic but physically shaped weather for the demo sites.

Clear-sky irradiance comes from pvlib (Ineichen). A clear-sky index profile
per local day is drawn from a seeded generator according to a day type
(clear / bright / partly / overcast). Sites within a portfolio share the
day type and the slow component, with site-specific fast fluctuations.
"""

from __future__ import annotations

from datetime import date
from functools import lru_cache

import numpy as np
import pandas as pd

from sun_king.adapters import pvmodel
from sun_king.simulation.noise import normal, ns

DAY_TYPES = ("clear", "bright", "partly", "overcast")
BASE = {
    "clear": (0.96, 0.01, 0.0),
    "bright": (0.86, 0.04, 0.08),
    "partly": (0.62, 0.12, 0.25),
    "overcast": (0.28, 0.06, 0.05),
}


@lru_cache(maxsize=4096)
def day_type(seed: int, ordinal: int, forced: tuple = ()) -> str:
    forced_map = dict(forced)
    if ordinal in forced_map:
        return forced_map[ordinal]
    rng = np.random.default_rng([seed, ordinal, 11])
    return str(rng.choice(DAY_TYPES, p=[0.15, 0.25, 0.35, 0.25]))


@lru_cache(maxsize=4096)
def _kt_profile(seed: int, site_key: int, ordinal: int, dtype: str) -> np.ndarray:
    """1440 one-minute clear-sky-index values for a day."""
    mean, slow_sd, cloud_rate = BASE[dtype]
    shared = np.random.default_rng([seed, ordinal, 1])
    local = np.random.default_rng([seed, ordinal, site_key, 2])
    # slow component: smoothed random walk shared across sites
    slow = np.cumsum(shared.normal(0, slow_sd / 6, 1440))
    slow = pd.Series(slow).rolling(90, min_periods=1, center=True).mean().to_numpy().copy()
    slow -= slow.mean()
    kt = (mean + slow).copy()
    # cloud passages: site-specific
    n_clouds = local.poisson(cloud_rate * 60)
    for _ in range(n_clouds):
        c = local.integers(0, 1440)
        w = local.integers(3, 25)
        depth = local.uniform(0.25, 0.65)
        lo, hi = max(0, c - w), min(1440, c + w)
        kt[lo:hi] *= 1 - depth * np.hanning(hi - lo)
    kt += local.normal(0, 0.01, 1440)
    out = np.clip(kt, 0.05, 1.05)
    out.setflags(write=False)
    return out


class WeatherModel:
    def __init__(self, seed: int, forced_day_types: dict[date, str] | None = None):
        self.seed = seed
        self.forced = tuple(sorted((d.toordinal(), t) for d, t in (forced_day_types or {}).items()))

    def day_type(self, d: date) -> str:
        return day_type(self.seed, d.toordinal(), self.forced)

    def kt(self, site_key: int, times: pd.DatetimeIndex, tz: str) -> np.ndarray:
        local = times.tz_convert(tz)
        out = np.empty(len(times))
        dates = local.date
        minutes = (local.hour * 60 + local.minute + local.second / 60.0).to_numpy()
        for d in sorted(set(dates)):
            mask = np.array([x == d for x in dates])
            prof = _kt_profile(self.seed, site_key, d.toordinal(), self.day_type(d))
            out[mask] = np.interp(minutes[mask], np.arange(1440), prof)
        return out

    def observe(self, site, site_key: int, times: pd.DatetimeIndex) -> pd.DataFrame:
        cs = pvmodel.clearsky(site.latitude, site.longitude, site.elevation_m, times)
        sp = pvmodel.solar_position(site.latitude, site.longitude, site.elevation_m, times)
        kt = self.kt(site_key, times, site.timezone)
        ghi = cs["ghi"].to_numpy() * kt
        ghi = pd.Series(ghi, index=times)
        sky = pvmodel.decompose_ghi(ghi, sp)
        local = times.tz_convert(site.timezone)
        hours = (local.hour + local.minute / 60.0).to_numpy()
        secs = ns(times) // 10**9
        day_off = np.array(
            [np.random.default_rng([self.seed, d.toordinal(), 5]).normal(0, 1.5) for d in local.date]
        )
        tamb = (
            5.0
            + 3.0 * np.sin((hours - 9.0) / 24 * 2 * np.pi)
            + day_off
            + 0.2 * normal(f"tamb{site_key}", secs // 300)
        )
        wind = np.clip(
            3.5 + 1.5 * np.sin(hours / 5.0 + site_key) + 0.8 * normal(f"wind{site_key}", secs // 60),
            0.2,
            None,
        )
        return pd.DataFrame(
            {
                "ghi": sky["ghi"],
                "dni": sky["dni"],
                "dhi": sky["dhi"],
                "temp_air": tamb,
                "wind_speed": wind,
                "kt": kt,
            },
            index=times,
        ).join(sp[["apparent_zenith", "zenith", "azimuth", "apparent_elevation"]])
