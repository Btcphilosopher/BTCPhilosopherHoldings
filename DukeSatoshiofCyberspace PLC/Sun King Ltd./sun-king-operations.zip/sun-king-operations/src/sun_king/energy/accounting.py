"""Energy accounting: power integration and cumulative-register differencing.

Rules enforced here
-------------------
* Instantaneous power (kW) is integrated over time (trapezoidal rule on the
  actual, possibly irregular, sample times). kW samples are never summed.
* Accumulated energy registers (kWh) are differenced, with explicit handling of
  meter resets and register roll-over.
* Gaps longer than ``max_gap_s`` are *not* bridged. The missing span is
  reported in ``gaps`` and reduces ``coverage``; the total is marked
  ``complete=False`` instead of silently treating the gap as zero.
* Estimation is only performed when explicitly requested and is reported as a
  separate ``estimated_kwh`` with its method.

All timestamps are UTC; callers use :func:`sun_king.core.timeutil.local_day_bounds`
for site-local days (23/24/25 h around DST changes).
"""

from __future__ import annotations

from bisect import bisect_left
from collections.abc import Sequence
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta

CALC_VERSION = "energy-1.2"
DEFAULT_COMPLETE_THRESHOLD = 0.98


@dataclass
class Gap:
    start: datetime
    end: datetime
    reason: str = "missing_samples"

    @property
    def seconds(self) -> float:
        return (self.end - self.start).total_seconds()


@dataclass
class EnergyResult:
    energy_kwh: float | None
    method: str
    interval_start: datetime
    interval_end: datetime
    coverage: float
    complete: bool
    n_samples: int
    gaps: list[Gap] = field(default_factory=list)
    flags: list[str] = field(default_factory=list)
    resets: list[dict] = field(default_factory=list)
    estimated_kwh: float | None = None
    estimation_method: str | None = None
    calc_version: str = CALC_VERSION

    def to_dict(self) -> dict:
        d = asdict(self)
        d["interval_start"] = self.interval_start.isoformat()
        d["interval_end"] = self.interval_end.isoformat()
        d["gaps"] = [
            {"start": g.start.isoformat(), "end": g.end.isoformat(), "reason": g.reason, "seconds": g.seconds}
            for g in self.gaps
        ]
        d["unit"] = "kWh"
        return d


def _sorted_unique(samples: Sequence[tuple[datetime, float | None]]) -> list[tuple[datetime, float]]:
    """Sort by time, drop None values, keep the last value for duplicate timestamps."""
    by_t: dict[datetime, float] = {}
    for t, v in samples:
        if v is None:
            continue
        by_t[t] = float(v)
    return sorted(by_t.items())


def integrate_power(
    samples: Sequence[tuple[datetime, float | None]],
    start: datetime,
    end: datetime,
    max_gap_s: float = 900.0,
    complete_threshold: float = DEFAULT_COMPLETE_THRESHOLD,
) -> EnergyResult:
    """Integrate kW samples to kWh over [start, end) using the trapezoidal rule.

    Samples just outside the window are used to interpolate the boundary values
    when they are within ``max_gap_s``. Spans between consecutive samples longer
    than ``max_gap_s`` are counted as gaps (no energy, reduced coverage).
    """
    if end <= start:
        raise ValueError("end must be after start")
    pts = _sorted_unique(samples)
    window_s = (end - start).total_seconds()
    times = [t for t, _ in pts]
    inside = [(t, v) for t, v in pts if start <= t < end]

    # Build the series clipped to [start, end] with interpolated edge values.
    series: list[tuple[datetime, float]] = []
    i0 = bisect_left(times, start)
    if i0 < len(pts) and pts[i0][0] == start:
        series.append(pts[i0])
    elif 0 < i0 < len(pts):
        (ta, va), (tb, vb) = pts[i0 - 1], pts[i0]
        if (tb - ta).total_seconds() <= max_gap_s:
            frac = (start - ta) / (tb - ta)
            series.append((start, va + (vb - va) * frac))
    series.extend(p for p in inside if p[0] != start)
    i1 = bisect_left(times, end)
    if i1 < len(pts) and pts[i1][0] == end:
        series.append(pts[i1])
    elif 0 < i1 < len(pts):
        (ta, va), (tb, vb) = pts[i1 - 1], pts[i1]
        if ta < end < tb and (tb - ta).total_seconds() <= max_gap_s:
            frac = (end - ta) / (tb - ta)
            series.append((end, va + (vb - va) * frac))

    gaps: list[Gap] = []
    energy_kwh = 0.0
    covered_s = 0.0
    if not series:
        gaps.append(Gap(start, end))
    else:
        if series[0][0] > start:
            gaps.append(Gap(start, series[0][0]))
        for (ta, va), (tb, vb) in zip(series, series[1:], strict=False):
            dt = (tb - ta).total_seconds()
            if dt <= 0:
                continue
            if dt > max_gap_s:
                gaps.append(Gap(ta, tb))
                continue
            energy_kwh += 0.5 * (va + vb) * dt / 3600.0
            covered_s += dt
        if series[-1][0] < end:
            # A trailing sample covers up to half a gap budget only if a later sample exists;
            # otherwise the tail is uncovered.
            gaps.append(Gap(series[-1][0], end))
    coverage = min(1.0, covered_s / window_s) if window_s else 0.0
    flags = []
    if any(v < 0 for _, v in series):
        flags.append("negative_power_samples")
    complete = coverage >= complete_threshold
    if not complete:
        flags.append("incomplete")
    return EnergyResult(
        energy_kwh=energy_kwh if series else None,
        method="power_integration_trapezoid",
        interval_start=start,
        interval_end=end,
        coverage=round(coverage, 6),
        complete=complete,
        n_samples=len(inside),
        gaps=gaps,
        flags=flags,
    )


def difference_register(
    readings: Sequence[tuple[datetime, float | None]],
    start: datetime,
    end: datetime,
    max_gap_s: float = 3600.0,
    reset_tolerance_kwh: float = 0.5,
    rollover_kwh: float | None = None,
    complete_threshold: float = DEFAULT_COMPLETE_THRESHOLD,
) -> EnergyResult:
    """Energy from a cumulative kWh register over [start, end).

    * A decrease larger than ``reset_tolerance_kwh`` is a **reset** (or a
      roll-over if ``rollover_kwh`` is given and the previous value was near it).
      After a reset, the post-reset reading is taken as energy since the reset
      (registers reset to zero). Energy between the last pre-reset reading and
      the reset itself cannot be observed; that span is reported as a gap.
    * Small decreases (within tolerance) are treated as register jitter: zero.
    * Boundary register values are interpolated linearly between readings that
      straddle the boundary within ``max_gap_s``; otherwise the boundary span
      is a gap.
    """
    if end <= start:
        raise ValueError("end must be after start")
    pts = _sorted_unique(readings)
    window_s = (end - start).total_seconds()

    # Restrict to readings near the window
    relevant = [
        (t, v)
        for t, v in pts
        if start - timedelta(seconds=max_gap_s) <= t <= end + timedelta(seconds=max_gap_s)
    ]
    gaps: list[Gap] = []
    resets: list[dict] = []
    flags: list[str] = []
    if len(relevant) < 2:
        return EnergyResult(
            None,
            "register_difference",
            start,
            end,
            0.0,
            False,
            len(relevant),
            [Gap(start, end)],
            ["incomplete"],
        )

    energy = 0.0
    covered_s = 0.0
    hw = relevant[0][1]  # high-water mark: a register never runs backwards except on reset/roll-over
    for (ta, va), (tb, vb) in zip(relevant, relevant[1:], strict=False):
        ref = max(va, hw)
        hw = max(hw, vb) if vb >= ref - reset_tolerance_kwh else vb
        # Overlap of this reading pair with the window
        seg_start, seg_end = max(ta, start), min(tb, end)
        if seg_end <= seg_start:
            continue
        dt_pair = (tb - ta).total_seconds()
        overlap_s = (seg_end - seg_start).total_seconds()
        delta = vb - ref
        if delta < -reset_tolerance_kwh:
            if rollover_kwh is not None and ref > 0.9 * rollover_kwh:
                delta = (rollover_kwh - ref) + vb
                resets.append({"at": tb.isoformat(), "type": "rollover", "before": va, "after": vb})
                flags.append("register_rollover")
            else:
                # Reset: energy since reset is vb; energy from ta to reset is unobservable.
                resets.append({"at": tb.isoformat(), "type": "reset", "before": ref, "after": vb})
                flags.append("meter_reset")
                gaps.append(Gap(seg_start, seg_end, "meter_reset_unobserved"))
                if seg_start == ta and seg_end == tb:
                    energy += max(vb, 0.0)
                # Partial overlap with an unobservable span: count nothing for it.
                continue
        elif delta < 0:
            delta = 0.0
            flags.append("register_jitter")  # small backwards step: ignored, high-water mark kept
        if dt_pair > max_gap_s:
            gaps.append(Gap(seg_start, seg_end, "missing_readings"))
            if seg_start == ta and seg_end == tb:
                # Whole pair inside window: the register delta is still *measured*
                # energy (the meter kept counting) — only its timing is unknown.
                energy += delta
                covered_s += overlap_s
                flags.append("long_reading_interval")
            continue
        energy += delta * (overlap_s / dt_pair)
        covered_s += overlap_s
    if relevant[0][0] > start:
        gaps.insert(0, Gap(start, min(relevant[0][0], end)))
    if relevant[-1][0] < end:
        gaps.append(Gap(max(relevant[-1][0], start), end))
    coverage = min(1.0, covered_s / window_s)
    complete = coverage >= complete_threshold and "meter_reset" not in flags
    if coverage < complete_threshold:
        flags.append("incomplete")
    return EnergyResult(
        energy_kwh=energy,
        method="register_difference",
        interval_start=start,
        interval_end=end,
        coverage=round(coverage, 6),
        complete=complete,
        n_samples=sum(1 for t, _ in pts if start <= t < end),
        gaps=gaps,
        flags=sorted(set(flags)),
        resets=resets,
    )


def estimate_gaps_from_reference(
    result: EnergyResult,
    reference: Sequence[tuple[datetime, float | None]],
    scale: float,
    method_label: str,
) -> EnergyResult:
    """Explicit estimation: fill gaps using a reference power series × scale.

    The measured ``energy_kwh`` is left unchanged. The filled total is placed
    in ``estimated_kwh`` with ``estimation_method`` so it is never mistaken
    for measured energy.
    """
    filled = 0.0
    for g in result.gaps:
        r = integrate_power(reference, g.start, g.end)
        if r.energy_kwh is not None:
            filled += r.energy_kwh * scale
    result.estimated_kwh = (result.energy_kwh or 0.0) + filled
    result.estimation_method = method_label
    result.flags = sorted(set(result.flags + ["contains_estimate"]))
    return result


def aggregate_buckets(
    samples: Sequence[tuple[datetime, float | None]],
    edges: Sequence[datetime],
    kind: str = "power",
    max_gap_s: float = 900.0,
) -> list[EnergyResult]:
    """Energy per consecutive bucket defined by ``edges``. ``kind`` is 'power' or 'register'.

    Buckets are half-open [edge_i, edge_i+1), so a sample on a boundary is
    attributed exactly once and adjacent buckets sum to the whole-window total.
    """
    out = []
    for a, b in zip(edges, edges[1:], strict=False):
        if kind == "power":
            out.append(integrate_power(samples, a, b, max_gap_s=max_gap_s))
        elif kind == "register":
            out.append(difference_register(samples, a, b, max_gap_s=max_gap_s))
        else:
            raise ValueError("kind must be 'power' or 'register'")
    return out
