from __future__ import annotations

from datetime import datetime

from sqlalchemy import Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from sun_king.core.db import Base, JSONType, UTCDateTime
from sun_king.core.timeutil import utcnow


class CurtailmentRecord(Base):
    """A recorded export restriction. Curtailment is recorded, never inferred from low output."""

    __tablename__ = "curtailment_records"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), index=True)
    start_time: Mapped[datetime] = mapped_column(UTCDateTime)
    end_time: Mapped[datetime] = mapped_column(UTCDateTime)
    limit_kw: Mapped[float] = mapped_column(Float)
    instruction_ref: Mapped[str | None] = mapped_column(String(120))
    issued_by: Mapped[str] = mapped_column(String(120))  # e.g. "DNO" / "ESO" / "internal"
    reason: Mapped[str | None] = mapped_column(Text)
    compensable: Mapped[bool | None] = mapped_column()
    source: Mapped[str] = mapped_column(String(64), default="manual")
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class EnergyCalculation(Base):
    """Persisted energy figure with its method, coverage and inputs, so reports link to it."""

    __tablename__ = "energy_calculations"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), index=True)
    asset_id: Mapped[str] = mapped_column(String(64))
    quantity: Mapped[str] = mapped_column(String(48))  # measured_export | measured_inverter_ac | ...
    interval_start: Mapped[datetime] = mapped_column(UTCDateTime)
    interval_end: Mapped[datetime] = mapped_column(UTCDateTime)
    energy_kwh: Mapped[float | None] = mapped_column(Float)
    method: Mapped[str] = mapped_column(String(48))
    coverage: Mapped[float] = mapped_column(Float)
    complete: Mapped[bool] = mapped_column()
    flags: Mapped[list] = mapped_column(JSONType, default=list)
    inputs: Mapped[dict] = mapped_column(JSONType, default=dict)
    calc_version: Mapped[str] = mapped_column(String(32))
    computed_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    n_samples: Mapped[int] = mapped_column(Integer, default=0)
