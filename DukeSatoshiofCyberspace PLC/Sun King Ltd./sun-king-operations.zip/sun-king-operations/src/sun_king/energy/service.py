"""Energy figures from stored telemetry, with method, coverage and source links."""

from __future__ import annotations

from datetime import date, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from sun_king.assets.models import Asset, Site
from sun_king.assets.service import meter_for_role, site_inverters
from sun_king.core.ids import new_id
from sun_king.core.timeutil import local_date, local_day_bounds, utcnow
from sun_king.energy.accounting import (
    CALC_VERSION,
    difference_register,
    estimate_gaps_from_reference,
    integrate_power,
)
from sun_king.energy.hierarchy import choose_site_figure
from sun_king.energy.models import CurtailmentRecord, EnergyCalculation
from sun_king.telemetry.query import series

QUAL = ("good",)


def _src(asset_id: str, mtype: str, start: datetime, end: datetime) -> str:
    return (
        f"/api/telemetry/observations?asset_id={asset_id}&measurement_type={mtype}"
        f"&start={start.isoformat()}&end={end.isoformat()}"
    )


def meter_export(
    session: Session, site_id: str, start: datetime, end: datetime, estimate: bool = False
) -> dict:
    meter = meter_for_role(session, site_id, "export_settlement")
    if meter is None:
        return {
            "asset_id": None,
            "energy_kwh": None,
            "complete": False,
            "coverage": 0.0,
            "method": "unavailable",
        }
    reg = series(session, meter, "export_energy", start, end, QUAL, pad=timedelta(hours=1))
    r = difference_register(reg, start, end, max_gap_s=1800)
    # Cross-check: integrate the meter's own active-power channel (export part only).
    pw = [
        (t, max(v, 0.0) if v is not None else None) for t, v in series(session, meter, "ac_power", start, end)
    ]
    check = integrate_power(pw, start, end, max_gap_s=900)
    out = r.to_dict()
    if estimate and r.gaps:
        est = estimate_gaps_from_reference(
            r, pw, 1.0, "gap filled by integrating meter active power (estimate)"
        )
        out["estimated_kwh"] = est.estimated_kwh
        out["estimation_method"] = est.estimation_method
    out.update(
        asset_id=meter,
        role="export_settlement",
        cross_check_power_integration_kwh=check.energy_kwh,
        cross_check_coverage=check.coverage,
        sources=[_src(meter, "export_energy", start, end), _src(meter, "ac_power", start, end)],
    )
    return out


def inverter_energy(session: Session, inv: Asset, start: datetime, end: datetime) -> dict:
    s = series(session, inv.asset_id, "ac_power", start, end, QUAL)
    r = integrate_power(s, start, end, max_gap_s=900)
    d = r.to_dict()
    d.update(asset_id=inv.asset_id, sources=[_src(inv.asset_id, "ac_power", start, end)])
    return d


def site_energy(
    session: Session, site_id: str, start: datetime, end: datetime, persist: bool = False
) -> dict:
    meter = meter_export(session, site_id, start, end, estimate=True)
    invs = [inverter_energy(session, inv, start, end) for inv in site_inverters(session, site_id)]
    fig = choose_site_figure(
        site_id,
        {"export_settlement": meter} if meter.get("energy_kwh") is not None else {},
        invs,
    )
    inv_total = sum(i["energy_kwh"] or 0 for i in invs)
    result = {
        "site_id": site_id,
        "interval_start": start.isoformat(),
        "interval_end": end.isoformat(),
        "unit": "kWh",
        "measured_export_kwh": meter.get("energy_kwh"),
        "measured_export_complete": meter.get("complete"),
        "measured_export_coverage": meter.get("coverage"),
        "estimated_export_kwh": meter.get("estimated_kwh"),
        "estimation_method": meter.get("estimation_method"),
        "site_figure": {
            "energy_kwh": fig.energy_kwh,
            "basis": fig.basis,
            "meter_asset_id": fig.meter_asset_id,
            "complete": fig.complete,
            "coverage": fig.coverage,
            "note": fig.note,
        },
        "meter": meter,
        "inverters": invs,
        "inverter_ac_total_kwh": inv_total,
        "inverter_ac_complete": all(i["complete"] for i in invs) if invs else False,
        "losses_inverter_to_meter_kwh": (inv_total - meter["energy_kwh"])
        if meter.get("energy_kwh") is not None
        and invs
        and all(i["complete"] for i in invs)
        and meter.get("complete")
        else None,
        "calc_version": CALC_VERSION,
        "double_counting_rule": "Site figure uses one meter role only; inverter totals are comparison values.",
    }
    if persist:
        calc = EnergyCalculation(
            id=new_id("ecalc"),
            site_id=site_id,
            asset_id=meter.get("asset_id") or "inverter_sum",
            quantity="measured_export" if fig.basis.startswith("meter") else "inverter_ac_sum",
            interval_start=start,
            interval_end=end,
            energy_kwh=fig.energy_kwh,
            method=meter.get("method", "unavailable")
            if fig.basis.startswith("meter")
            else "power_integration_trapezoid",
            coverage=fig.coverage,
            complete=fig.complete,
            flags=meter.get("flags", []),
            inputs={"sources": meter.get("sources", []), "resets": meter.get("resets", [])},
            calc_version=CALC_VERSION,
            n_samples=meter.get("n_samples", 0),
        )
        session.add(calc)
        session.flush()
        result["calculation_id"] = calc.id
    return result


def daily_completeness(session: Session, site_id: str, days: int, today: date | None = None) -> list[dict]:
    site = session.get(Site, site_id)
    now = utcnow()
    today = today or local_date(now, site.timezone)
    out = []
    for k in range(days - 1, -1, -1):
        d = today - timedelta(days=k)
        s, e = local_day_bounds(d, site.timezone)
        partial_day = e > now
        e_eff = min(e, now)
        meter = meter_export(session, site_id, s, e_eff, estimate=True)
        invs = [inverter_energy(session, inv, s, e_eff) for inv in site_inverters(session, site_id)]
        curt = session.scalars(
            select(CurtailmentRecord).where(
                CurtailmentRecord.site_id == site_id,
                CurtailmentRecord.start_time < e,
                CurtailmentRecord.end_time > s,
            )
        ).all()
        out.append(
            {
                "date": d.isoformat(),
                "utc_start": s.isoformat(),
                "utc_end": e.isoformat(),
                "hours": (e - s).total_seconds() / 3600.0,
                "day_in_progress": partial_day,
                "measured_export_kwh": meter.get("energy_kwh"),
                "estimated_export_kwh": meter.get("estimated_kwh"),
                "export_coverage": meter.get("coverage"),
                "export_complete": meter.get("complete") and not partial_day,
                "export_flags": meter.get("flags", []),
                "meter_resets": meter.get("resets", []),
                "export_gaps": meter.get("gaps", []),
                "cross_check_power_integration_kwh": meter.get("cross_check_power_integration_kwh"),
                "inverters": [
                    {
                        "asset_id": i["asset_id"],
                        "energy_kwh": i["energy_kwh"],
                        "coverage": i["coverage"],
                        "complete": i["complete"],
                        "gaps": i["gaps"],
                    }
                    for i in invs
                ],
                "curtailment_records": [c.id for c in curt],
                "status": _status(meter, partial_day),
                "sources": meter.get("sources", []),
            }
        )
    return out


def _status(meter: dict, partial: bool) -> str:
    if meter.get("energy_kwh") is None:
        return "no_data"
    if partial:
        return "in_progress"
    if "meter_reset" in meter.get("flags", []):
        return "incomplete_meter_reset"
    if not meter.get("complete"):
        return "incomplete"
    return "complete"
