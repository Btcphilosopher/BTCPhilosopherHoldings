"""Source-of-truth hierarchy to prevent double counting.

A site's energy figure is taken from exactly one meter role, chosen in order:

1. ``export_settlement`` — the revenue/settlement export meter.
2. ``site_check`` — a site-level check meter.
3. Sum of inverter AC energy — *only as a labelled fallback* (``basis =
   'inverter_sum_fallback'``) because it excludes transformer/cable losses
   and auxiliary consumption.

Inverter and site meters are never added together. Portfolio totals sum one
figure per site. Measured export is never equated with gross generation.
"""

from __future__ import annotations

from dataclasses import dataclass

ROLE_PRIORITY = ("export_settlement", "site_check")


@dataclass
class SiteEnergyFigure:
    site_id: str
    energy_kwh: float | None
    basis: str
    meter_asset_id: str | None
    complete: bool
    coverage: float
    components: list[dict]
    note: str


def choose_site_figure(
    site_id: str,
    meter_results: dict[str, dict],
    inverter_results: list[dict],
) -> SiteEnergyFigure:
    """``meter_results``: role -> {asset_id, energy_kwh, complete, coverage}.
    ``inverter_results``: list of {asset_id, energy_kwh, complete, coverage}."""
    for role in ROLE_PRIORITY:
        r = meter_results.get(role)
        if r and r.get("energy_kwh") is not None:
            return SiteEnergyFigure(
                site_id,
                r["energy_kwh"],
                f"meter:{role}",
                r["asset_id"],
                bool(r["complete"]),
                float(r["coverage"]),
                [r],
                f"Measured at {role.replace('_', ' ')} meter {r['asset_id']}. Inverter totals shown for comparison only.",
            )
    if inverter_results:
        vals = [r for r in inverter_results if r.get("energy_kwh") is not None]
        total = sum(r["energy_kwh"] for r in vals) if vals else None
        complete = bool(vals) and len(vals) == len(inverter_results) and all(r["complete"] for r in vals)
        cov = min((r["coverage"] for r in inverter_results), default=0.0)
        return SiteEnergyFigure(
            site_id,
            total,
            "inverter_sum_fallback",
            None,
            complete,
            cov,
            inverter_results,
            "No usable site meter data: sum of inverter AC energy (excludes transformer losses and "
            "auxiliary load; not export).",
        )
    return SiteEnergyFigure(site_id, None, "unavailable", None, False, 0.0, [], "No energy data available.")


def portfolio_total(figures: list[SiteEnergyFigure]) -> dict:
    known = [f for f in figures if f.energy_kwh is not None]
    return {
        "energy_kwh": sum(f.energy_kwh for f in known) if known else None,  # type: ignore[misc]
        "complete": bool(figures) and all(f.complete for f in figures),
        "sites_included": [f.site_id for f in known],
        "sites_missing": [f.site_id for f in figures if f.energy_kwh is None],
        "bases": {f.site_id: f.basis for f in figures},
    }
