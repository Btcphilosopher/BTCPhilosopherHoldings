"""Maintenance, inspections, cleaning, vegetation, spares, contractors and evidence.

A completed or signed-off work order records that the described work was
done and reviewed. It never declares equipment electrically safe: isolation
and safe-working procedures stay within the organisation's authorised
safety-management system and are referenced, not executed, here.
"""

from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import Boolean, Date, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from sun_king.core.db import Base, JSONType, UTCDateTime
from sun_king.core.timeutil import utcnow

WORK_ORDER_STATUSES = (
    "draft",
    "scheduled",
    "assigned",
    "in_progress",
    "completed",
    "reviewed",
    "signed_off",
    "cancelled",
)
SAFETY_NOTICE = (
    "This work order does not certify electrical safety. Isolation, permits-to-work and "
    "safe-working procedures must follow the organisation's authorised safety management system."
)


class Contractor(Base):
    __tablename__ = "contractors"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    trade: Mapped[str] = mapped_column(String(80))
    contact_email: Mapped[str | None] = mapped_column(String(200))
    contact_phone: Mapped[str | None] = mapped_column(String(40))
    accreditation_ref: Mapped[str | None] = mapped_column(String(120))
    accreditation_expiry: Mapped[date | None] = mapped_column(Date)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class MaintenanceSchedule(Base):
    __tablename__ = "maintenance_schedules"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), index=True)
    asset_id: Mapped[str | None] = mapped_column(ForeignKey("assets.asset_id"))
    task_type: Mapped[str] = mapped_column(
        String(48)
    )  # preventive|inspection|cleaning|vegetation|thermography
    title: Mapped[str] = mapped_column(String(200))
    interval_days: Mapped[int] = mapped_column(Integer)
    last_completed: Mapped[date | None] = mapped_column(Date)
    next_due: Mapped[date] = mapped_column(Date)
    contractor_id: Mapped[str | None] = mapped_column(ForeignKey("contractors.id"))
    form_template_id: Mapped[str | None] = mapped_column(String(64))
    source: Mapped[str] = mapped_column(String(120), default="O&M contract")
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class WorkOrder(Base):
    __tablename__ = "work_orders"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), index=True)
    alert_id: Mapped[str | None] = mapped_column(ForeignKey("alerts.id"))
    schedule_id: Mapped[str | None] = mapped_column(ForeignKey("maintenance_schedules.id"))
    work_type: Mapped[str] = mapped_column(String(32))  # corrective|preventive|inspection|cleaning|vegetation
    title: Mapped[str] = mapped_column(String(300))
    description: Mapped[str | None] = mapped_column(Text)
    priority: Mapped[str] = mapped_column(String(16), default="medium")
    status: Mapped[str] = mapped_column(String(16), default="draft")
    asset_ids: Mapped[list] = mapped_column(JSONType, default=list)
    contractor_id: Mapped[str | None] = mapped_column(ForeignKey("contractors.id"))
    assigned_to: Mapped[str | None] = mapped_column(String(64))
    due_date: Mapped[date | None] = mapped_column(Date)
    planned_start: Mapped[datetime | None] = mapped_column(UTCDateTime)
    started_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    completed_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    reviewed_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    reviewed_by: Mapped[str | None] = mapped_column(String(64))
    signed_off_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    signed_off_by: Mapped[str | None] = mapped_column(String(64))
    completion_notes: Mapped[str | None] = mapped_column(Text)
    repair_summary: Mapped[str | None] = mapped_column(Text)
    permit_reference: Mapped[str | None] = mapped_column(String(120))  # external safety-system ref
    safety_notice: Mapped[str] = mapped_column(Text, default=SAFETY_NOTICE)
    verification: Mapped[dict | None] = mapped_column(JSONType)
    created_by: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    version: Mapped[int] = mapped_column(Integer, default=1)


class InspectionTemplate(Base):
    __tablename__ = "inspection_templates"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    applies_to: Mapped[str] = mapped_column(String(32))
    fields: Mapped[list] = mapped_column(JSONType)  # [{key,label,type,options,required}]
    version: Mapped[int] = mapped_column(Integer, default=1)


class InspectionRecord(Base):
    __tablename__ = "inspection_records"
    __table_args__ = (UniqueConstraint("client_draft_id"),)
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    work_order_id: Mapped[str | None] = mapped_column(ForeignKey("work_orders.id"), index=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"))
    asset_id: Mapped[str | None] = mapped_column(ForeignKey("assets.asset_id"))
    template_id: Mapped[str] = mapped_column(ForeignKey("inspection_templates.id"))
    template_version: Mapped[int] = mapped_column(Integer)
    answers: Mapped[dict] = mapped_column(JSONType, default=dict)
    status: Mapped[str] = mapped_column(String(16), default="draft")  # draft|submitted|reviewed
    inspector_id: Mapped[str | None] = mapped_column(String(64))
    captured_at: Mapped[datetime] = mapped_column(UTCDateTime)  # device capture time
    synced_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    device_id: Mapped[str | None] = mapped_column(String(64))
    client_draft_id: Mapped[str | None] = mapped_column(String(64))
    version: Mapped[int] = mapped_column(Integer, default=1)
    conflict_history: Mapped[list] = mapped_column(JSONType, default=list)


class Defect(Base):
    __tablename__ = "defects"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), index=True)
    asset_id: Mapped[str | None] = mapped_column(ForeignKey("assets.asset_id"))
    inspection_id: Mapped[str | None] = mapped_column(ForeignKey("inspection_records.id"))
    work_order_id: Mapped[str | None] = mapped_column(ForeignKey("work_orders.id"))
    category: Mapped[str] = mapped_column(String(48))
    severity: Mapped[str] = mapped_column(String(16))
    description: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16), default="open")
    observed_at: Mapped[datetime] = mapped_column(UTCDateTime)
    closed_at: Mapped[datetime | None] = mapped_column(UTCDateTime)


class Evidence(Base):
    """Photo/document metadata. Content lives in object storage, addressed by SHA-256."""

    __tablename__ = "evidence"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"))
    entity_type: Mapped[str] = mapped_column(String(32))  # work_order|inspection|defect|asset|module_type
    entity_id: Mapped[str] = mapped_column(String(64), index=True)
    object_key: Mapped[str] = mapped_column(String(300))
    sha256: Mapped[str] = mapped_column(String(64))
    content_type: Mapped[str] = mapped_column(String(100))
    size_bytes: Mapped[int] = mapped_column(Integer)
    filename: Mapped[str] = mapped_column(String(200))
    caption: Mapped[str | None] = mapped_column(Text)
    captured_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    uploaded_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    uploaded_by: Mapped[str | None] = mapped_column(String(64))
    kind: Mapped[str] = mapped_column(String(32), default="photo")  # photo|document|manual|completion


class CleaningRecord(Base):
    __tablename__ = "cleaning_records"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), index=True)
    asset_ids: Mapped[list] = mapped_column(JSONType, default=list)
    work_order_id: Mapped[str | None] = mapped_column(ForeignKey("work_orders.id"))
    performed_on: Mapped[date] = mapped_column(Date)
    method: Mapped[str] = mapped_column(String(64))
    cost: Mapped[float | None] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(3), default="GBP")
    contractor_id: Mapped[str | None] = mapped_column(ForeignKey("contractors.id"))
    notes: Mapped[str | None] = mapped_column(Text)


class VegetationRecord(Base):
    __tablename__ = "vegetation_records"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), index=True)
    area: Mapped[str] = mapped_column(String(120))
    performed_on: Mapped[date] = mapped_column(Date)
    method: Mapped[str] = mapped_column(String(64))  # mowing|grazing|strimming
    ecological_constraints: Mapped[str | None] = mapped_column(Text)
    contractor_id: Mapped[str | None] = mapped_column(ForeignKey("contractors.id"))
    cost: Mapped[float | None] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(3), default="GBP")


class SparePart(Base):
    __tablename__ = "spare_parts"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    part_number: Mapped[str] = mapped_column(String(80))
    description: Mapped[str] = mapped_column(String(200))
    compatible_models: Mapped[list] = mapped_column(JSONType, default=list)
    quantity_on_hand: Mapped[int] = mapped_column(Integer, default=0)
    minimum_quantity: Mapped[int] = mapped_column(Integer, default=0)
    storage_location: Mapped[str | None] = mapped_column(String(120))
    unit_cost: Mapped[float | None] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(3), default="GBP")


class PartUsage(Base):
    __tablename__ = "part_usages"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    work_order_id: Mapped[str] = mapped_column(ForeignKey("work_orders.id"), index=True)
    part_id: Mapped[str] = mapped_column(ForeignKey("spare_parts.id"))
    quantity: Mapped[int] = mapped_column(Integer)
    recorded_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    recorded_by: Mapped[str | None] = mapped_column(String(64))


class WorkOrderEvent(Base):
    __tablename__ = "work_order_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    work_order_id: Mapped[str] = mapped_column(ForeignKey("work_orders.id"), index=True)
    at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    actor_id: Mapped[str | None] = mapped_column(String(64))
    from_status: Mapped[str | None] = mapped_column(String(16))
    to_status: Mapped[str | None] = mapped_column(String(16))
    note: Mapped[str | None] = mapped_column(Text)
