"""Work orders, inspections (offline sync with conflict detection), evidence and spares."""

from __future__ import annotations

import hashlib
from datetime import date, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from sun_king.core.ids import new_id
from sun_king.core.timeutil import utcnow
from sun_king.maintenance.models import (
    SAFETY_NOTICE,
    Evidence,
    InspectionRecord,
    InspectionTemplate,
    MaintenanceSchedule,
    PartUsage,
    SparePart,
    WorkOrder,
    WorkOrderEvent,
)

WO_TRANSITIONS = {
    "draft": {"scheduled", "assigned", "cancelled"},
    "scheduled": {"assigned", "cancelled"},
    "assigned": {"in_progress", "scheduled", "cancelled"},
    "in_progress": {"completed", "assigned"},
    "completed": {"reviewed", "in_progress"},
    "reviewed": {"signed_off", "in_progress"},
    "signed_off": set(),
    "cancelled": set(),
}


class MaintenanceError(ValueError):
    pass


class SyncConflict(Exception):
    def __init__(self, server: InspectionRecord):
        super().__init__("inspection conflict")
        self.server = server


def create_work_order(
    session: Session,
    *,
    site_id: str,
    title: str,
    work_type: str,
    created_by: str,
    asset_ids: list[str] | None = None,
    alert_id: str | None = None,
    priority: str = "medium",
    description: str | None = None,
    due_date: date | None = None,
    contractor_id: str | None = None,
    schedule_id: str | None = None,
) -> WorkOrder:
    wo = WorkOrder(
        id=new_id("wo"),
        site_id=site_id,
        title=title,
        work_type=work_type,
        created_by=created_by,
        asset_ids=asset_ids or [],
        alert_id=alert_id,
        priority=priority,
        description=description,
        due_date=due_date,
        contractor_id=contractor_id,
        schedule_id=schedule_id,
        status="draft",
        safety_notice=SAFETY_NOTICE,
    )
    session.add(wo)
    session.flush()
    session.add(WorkOrderEvent(work_order_id=wo.id, actor_id=created_by, to_status="draft", note="created"))
    return wo


def transition_work_order(
    session: Session,
    wo: WorkOrder,
    to: str,
    user_id: str,
    note: str | None = None,
    at: datetime | None = None,
    **fields,
) -> WorkOrder:
    if to not in WO_TRANSITIONS.get(wo.status, set()):
        raise MaintenanceError(f"cannot move work order from {wo.status} to {to}")
    at = at or utcnow()
    if to == "assigned" and not (
        fields.get("assigned_to") or wo.assigned_to or fields.get("contractor_id") or wo.contractor_id
    ):
        raise MaintenanceError("assignment requires a technician or contractor")
    if to == "completed":
        if not (fields.get("completion_notes") or wo.completion_notes):
            raise MaintenanceError("completion requires completion notes")
        ev = session.scalar(
            select(Evidence.id)
            .where(Evidence.entity_type == "work_order", Evidence.entity_id == wo.id)
            .limit(1)
        )
        insp = session.scalar(
            select(InspectionRecord.id)
            .where(InspectionRecord.work_order_id == wo.id, InspectionRecord.status != "draft")
            .limit(1)
        )
        if not ev and not insp:
            raise MaintenanceError("completion requires evidence (photo/document) or a submitted inspection")
        wo.completed_at = at
    if to == "in_progress" and wo.started_at is None:
        wo.started_at = at
    if to == "reviewed":
        if user_id == wo.assigned_to:
            raise MaintenanceError("review must be by someone other than the assignee")
        wo.reviewed_at, wo.reviewed_by = at, user_id
    if to == "signed_off":
        wo.signed_off_at, wo.signed_off_by = at, user_id
    for k, v in fields.items():
        if v is not None and hasattr(wo, k):
            setattr(wo, k, v)
    prev = wo.status
    wo.status = to
    wo.version += 1
    session.add(
        WorkOrderEvent(
            work_order_id=wo.id, actor_id=user_id, from_status=prev, to_status=to, note=note, at=at
        )
    )
    if to == "signed_off" and wo.schedule_id:
        sched = session.get(MaintenanceSchedule, wo.schedule_id)
        if sched:
            done = (wo.completed_at or at).date()
            sched.last_completed = done
            sched.next_due = done + timedelta(days=sched.interval_days)
    return wo


def record_part_usage(session: Session, wo: WorkOrder, part_id: str, qty: int, user_id: str) -> PartUsage:
    part = session.get(SparePart, part_id)
    if part is None:
        raise MaintenanceError("unknown part")
    if qty <= 0 or qty > part.quantity_on_hand:
        raise MaintenanceError(f"invalid quantity (on hand {part.quantity_on_hand})")
    part.quantity_on_hand -= qty
    pu = PartUsage(work_order_id=wo.id, part_id=part_id, quantity=qty, recorded_by=user_id)
    session.add(pu)
    return pu


def sync_inspection(session: Session, payload: dict, user_id: str) -> tuple[InspectionRecord, str]:
    """Upsert an inspection captured (possibly offline) on a tablet.

    ``payload`` carries ``client_draft_id``, ``base_version`` (server version
    the draft was based on; None for new), ``captured_at`` (device time) and
    ``answers``. A stale ``base_version`` raises :class:`SyncConflict` so the
    client can choose explicitly (``resolution='keep_client'`` or
    ``'keep_server'``); the overwritten answers are kept in ``conflict_history``.
    """
    tpl = session.get(InspectionTemplate, payload["template_id"])
    if tpl is None:
        raise MaintenanceError("unknown inspection template")
    validate_answers(tpl, payload.get("answers", {}), payload.get("status", "draft"))
    rec = session.scalar(
        select(InspectionRecord).where(InspectionRecord.client_draft_id == payload["client_draft_id"])
    )
    captured = payload["captured_at"]
    if rec is None:
        rec = InspectionRecord(
            id=new_id("insp"),
            work_order_id=payload.get("work_order_id"),
            site_id=payload["site_id"],
            asset_id=payload.get("asset_id"),
            template_id=tpl.id,
            template_version=tpl.version,
            answers=payload.get("answers", {}),
            status=payload.get("status", "draft"),
            inspector_id=user_id,
            captured_at=captured,
            synced_at=utcnow(),
            device_id=payload.get("device_id"),
            client_draft_id=payload["client_draft_id"],
            version=1,
            conflict_history=[],
        )
        session.add(rec)
        session.flush()
        return rec, "created"
    base = payload.get("base_version")
    resolution = payload.get("resolution")
    if rec.status == "reviewed":
        raise MaintenanceError("inspection already reviewed; changes require a new inspection")
    if base != rec.version and resolution is None:
        raise SyncConflict(rec)
    if resolution == "keep_server":
        rec.conflict_history = rec.conflict_history + [
            {
                "discarded_client": payload.get("answers"),
                "captured_at": captured.isoformat(),
                "at": utcnow().isoformat(),
            }
        ]
        return rec, "kept_server"
    if base != rec.version:
        rec.conflict_history = rec.conflict_history + [
            {
                "overwritten_server": rec.answers,
                "server_version": rec.version,
                "at": utcnow().isoformat(),
                "by": user_id,
            }
        ]
    rec.answers = payload.get("answers", {})
    rec.status = payload.get("status", rec.status)
    rec.captured_at = captured
    rec.synced_at = utcnow()
    rec.version += 1
    return rec, "updated"


def validate_answers(tpl: InspectionTemplate, answers: dict, status: str) -> None:
    fields = {f["key"]: f for f in tpl.fields}
    for k in answers:
        if k not in fields:
            raise MaintenanceError(f"unknown field {k}")
    for k, f in fields.items():
        v = answers.get(k)
        if status == "submitted" and f.get("required") and v in (None, ""):
            raise MaintenanceError(f"required field {k} missing")
        if v is None:
            continue
        if f["type"] == "number" and not isinstance(v, (int, float)):
            raise MaintenanceError(f"{k} must be numeric")
        if f["type"] == "choice" and v not in f.get("options", []):
            raise MaintenanceError(f"{k} must be one of {f.get('options')}")
        if f["type"] == "text" and len(str(v)) > 4000:
            raise MaintenanceError(f"{k} too long")


def store_evidence(
    session: Session,
    store,
    *,
    site_id: str,
    entity_type: str,
    entity_id: str,
    data: bytes,
    filename: str,
    content_type: str,
    user_id: str,
    caption: str | None = None,
    captured_at: datetime | None = None,
    kind: str = "photo",
    max_bytes: int,
) -> Evidence:
    allowed = {"image/jpeg", "image/png", "image/webp", "application/pdf", "text/plain", "text/csv"}
    if content_type not in allowed:
        raise MaintenanceError(f"content type {content_type} not permitted")
    if len(data) > max_bytes:
        raise MaintenanceError("file too large")
    if content_type == "image/png" and not data.startswith(b"\x89PNG"):
        raise MaintenanceError("file content does not match declared type")
    if content_type == "image/jpeg" and not data.startswith(b"\xff\xd8"):
        raise MaintenanceError("file content does not match declared type")
    if content_type == "application/pdf" and not data.startswith(b"%PDF"):
        raise MaintenanceError("file content does not match declared type")
    sha = hashlib.sha256(data).hexdigest()
    key = f"{site_id}/{entity_type}/{entity_id}/{sha[:16]}-{_safe(filename)}"
    store.put(key, data, content_type)
    ev = Evidence(
        id=new_id("evd"),
        site_id=site_id,
        entity_type=entity_type,
        entity_id=entity_id,
        object_key=key,
        sha256=sha,
        content_type=content_type,
        size_bytes=len(data),
        filename=_safe(filename),
        caption=caption,
        captured_at=captured_at,
        uploaded_by=user_id,
        kind=kind,
    )
    session.add(ev)
    session.flush()
    return ev


def _safe(name: str) -> str:
    keep = "".join(c if c.isalnum() or c in "._-" else "_" for c in name)[:120]
    return keep or "file"


DEFAULT_TEMPLATES = [
    {
        "id": "tpl-inverter-corrective",
        "name": "Inverter corrective visit",
        "applies_to": "inverter",
        "fields": [
            {
                "key": "arrival_status_code",
                "label": "Status code on arrival",
                "type": "number",
                "required": True,
            },
            {
                "key": "visual_condition",
                "label": "Visual condition",
                "type": "choice",
                "options": ["normal", "minor damage", "major damage"],
                "required": True,
            },
            {
                "key": "dc_insulation_ok",
                "label": "DC insulation resistance within limit (per authorised test procedure)",
                "type": "choice",
                "options": ["yes", "no", "not tested"],
                "required": True,
            },
            {"key": "findings", "label": "Findings", "type": "text", "required": True},
            {"key": "actions", "label": "Actions taken", "type": "text", "required": True},
            {
                "key": "permit_reference",
                "label": "Permit-to-work reference (from safety system)",
                "type": "text",
                "required": False,
            },
        ],
    },
    {
        "id": "tpl-site-inspection",
        "name": "Routine site inspection",
        "applies_to": "site",
        "fields": [
            {
                "key": "fencing_ok",
                "label": "Perimeter fencing intact",
                "type": "choice",
                "options": ["yes", "no"],
                "required": True,
            },
            {
                "key": "vegetation_height_cm",
                "label": "Vegetation height (cm)",
                "type": "number",
                "required": True,
            },
            {
                "key": "soiling_visual",
                "label": "Visual soiling",
                "type": "choice",
                "options": ["low", "moderate", "heavy"],
                "required": True,
            },
            {
                "key": "module_damage",
                "label": "Module damage observed",
                "type": "choice",
                "options": ["none", "isolated", "widespread"],
                "required": True,
            },
            {"key": "notes", "label": "Notes", "type": "text", "required": False},
        ],
    },
    {
        "id": "tpl-cleaning",
        "name": "Cleaning completion",
        "applies_to": "array_block",
        "fields": [
            {"key": "blocks_cleaned", "label": "Blocks cleaned", "type": "text", "required": True},
            {
                "key": "method",
                "label": "Method",
                "type": "choice",
                "options": ["water-fed pole", "robotic", "dry brush"],
                "required": True,
            },
            {"key": "water_litres", "label": "Water used (L)", "type": "number", "required": False},
        ],
    },
]
