"""Telemetry storage: raw observations are append-only and kept apart from
cleaned values and from calculated results.

On PostgreSQL the ``raw_observations`` and ``clean_observations`` tables get
BRIN indexes on time and, where the TimescaleDB extension is available, are
converted to hypertables by migration ``0002`` (see ``docs/architecture.md``).
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import BigInteger, Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from sun_king.core.db import Base, JSONType, UTCDateTime
from sun_king.core.timeutil import utcnow

BigIntPK = BigInteger().with_variant(Integer, "sqlite")


class IngestionBatch(Base):
    __tablename__ = "ingestion_batches"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    source: Mapped[str] = mapped_column(String(64), index=True)
    idempotency_key: Mapped[str | None] = mapped_column(String(128), unique=True)
    received_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    received: Mapped[int] = mapped_column(Integer, default=0)
    accepted: Mapped[int] = mapped_column(Integer, default=0)
    duplicates: Mapped[int] = mapped_column(Integer, default=0)
    revisions: Mapped[int] = mapped_column(Integer, default=0)
    rejected: Mapped[int] = mapped_column(Integer, default=0)
    out_of_order: Mapped[int] = mapped_column(Integer, default=0)
    late: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(16), default="complete")
    errors: Mapped[list] = mapped_column(JSONType, default=list)


class RawObservation(Base):
    __tablename__ = "raw_observations"
    __table_args__ = (
        UniqueConstraint("asset_id", "measurement_type", "observation_time", "source", "revision"),
        Index("ix_raw_obs_stream_time", "asset_id", "measurement_type", "observation_time"),
    )
    measurement_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.asset_id"))
    measurement_type: Mapped[str] = mapped_column(String(48))
    value: Mapped[float | None] = mapped_column(Float)  # None = source reported missing
    unit: Mapped[str] = mapped_column(String(16))
    observation_time: Mapped[datetime] = mapped_column(UTCDateTime)
    ingestion_time: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    source: Mapped[str] = mapped_column(String(64))
    quality_flags: Mapped[list] = mapped_column(JSONType, default=list)
    revision: Mapped[int] = mapped_column(Integer, default=0)
    batch_id: Mapped[str | None] = mapped_column(ForeignKey("ingestion_batches.id"))
    status_text: Mapped[str | None] = mapped_column(String(64))


class CleanObservation(Base):
    """Validated value in canonical units. One row per stream timestamp (latest revision)."""

    __tablename__ = "clean_observations"
    __table_args__ = (
        UniqueConstraint("asset_id", "measurement_type", "observation_time"),
        Index("ix_clean_obs_time", "observation_time"),
    )
    id: Mapped[int] = mapped_column(BigIntPK, primary_key=True, autoincrement=True)
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.asset_id"), index=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), index=True)
    measurement_type: Mapped[str] = mapped_column(String(48))
    observation_time: Mapped[datetime] = mapped_column(UTCDateTime)
    value: Mapped[float | None] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(16))
    quality: Mapped[str] = mapped_column(String(12))  # good | suspect | bad | missing
    quality_flags: Mapped[list] = mapped_column(JSONType, default=list)
    raw_measurement_id: Mapped[str] = mapped_column(ForeignKey("raw_observations.measurement_id"))
    validation_version: Mapped[str] = mapped_column(String(32))
    source: Mapped[str] = mapped_column(String(64))
    ingestion_time: Mapped[datetime] = mapped_column(UTCDateTime)


class StreamState(Base):
    """Last-seen bookkeeping per (asset, measurement, source) for freshness and ordering checks."""

    __tablename__ = "stream_states"
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.asset_id"), primary_key=True)
    measurement_type: Mapped[str] = mapped_column(String(48), primary_key=True)
    source: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), index=True)
    last_observation_time: Mapped[datetime] = mapped_column(UTCDateTime)
    last_ingestion_time: Mapped[datetime] = mapped_column(UTCDateTime)
    last_value: Mapped[float | None] = mapped_column(Float)
    last_unit: Mapped[str] = mapped_column(String(16))
    last_quality: Mapped[str] = mapped_column(String(12))
    last_measurement_id: Mapped[str] = mapped_column(String(64))


class SourceStatus(Base):
    """Connection state of a telemetry source (adapter) for a site."""

    __tablename__ = "source_statuses"
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), primary_key=True)
    source: Mapped[str] = mapped_column(String(64), primary_key=True)
    last_contact: Mapped[datetime | None] = mapped_column(UTCDateTime)
    last_error: Mapped[str | None] = mapped_column(Text)
    consecutive_failures: Mapped[int] = mapped_column(Integer, default=0)
    state: Mapped[str] = mapped_column(String(16), default="unknown")  # connected|degraded|disconnected
