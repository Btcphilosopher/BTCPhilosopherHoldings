from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field, field_validator

from sun_king.core.timeutil import ensure_utc


class ObservationIn(BaseModel):
    measurement_id: str | None = Field(default=None, max_length=64)
    asset_id: str = Field(max_length=64)
    measurement_type: str = Field(max_length=48)
    value: float | None
    unit: str = Field(max_length=16)
    observation_time: datetime
    source: str = Field(max_length=64)
    quality_flags: list[str] = Field(default_factory=list, max_length=20)
    status_text: str | None = Field(default=None, max_length=64)

    @field_validator("observation_time")
    @classmethod
    def _aware(cls, v: datetime) -> datetime:
        return ensure_utc(v)

    @field_validator("value")
    @classmethod
    def _finite(cls, v: float | None) -> float | None:
        if v is not None and (v != v or v in (float("inf"), float("-inf"))):
            return None  # NaN/inf treated as missing; flagged downstream
        return v


class IngestRequest(BaseModel):
    source: str = Field(max_length=64)
    idempotency_key: str | None = Field(default=None, max_length=128)
    observations: list[ObservationIn]


class IngestSummary(BaseModel):
    batch_id: str
    source: str
    received: int
    accepted: int
    duplicates: int
    revisions: int
    rejected: int
    out_of_order: int
    late: int
    status: str
    replayed: bool = False
    errors: list[dict] = Field(default_factory=list)
