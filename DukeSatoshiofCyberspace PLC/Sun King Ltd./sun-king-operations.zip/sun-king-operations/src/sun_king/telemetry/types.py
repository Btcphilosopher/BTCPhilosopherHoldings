"""Measurement-type catalogue: expected unit dimension and kind (power/energy/state)."""

from __future__ import annotations

from dataclasses import dataclass

from sun_king.core.units import Dimension


@dataclass(frozen=True)
class MeasurementType:
    key: str
    dimension: Dimension
    kind: str  # instantaneous | cumulative | state
    description: str


MEASUREMENT_TYPES: dict[str, MeasurementType] = {
    m.key: m
    for m in [
        MeasurementType("dc_voltage", Dimension.VOLTAGE, "instantaneous", "DC input voltage"),
        MeasurementType("dc_current", Dimension.CURRENT, "instantaneous", "DC input current"),
        MeasurementType("dc_power", Dimension.POWER, "instantaneous", "DC input power"),
        MeasurementType("ac_power", Dimension.POWER, "instantaneous", "Inverter / meter AC active power"),
        MeasurementType("reactive_power", Dimension.REACTIVE_POWER, "instantaneous", "Reactive power"),
        MeasurementType("export_energy", Dimension.ENERGY, "cumulative", "Exported energy register"),
        MeasurementType("import_energy", Dimension.ENERGY, "cumulative", "Imported energy register"),
        MeasurementType("ac_energy", Dimension.ENERGY, "cumulative", "Inverter AC energy counter"),
        MeasurementType("poa_irradiance", Dimension.IRRADIANCE, "instantaneous", "Plane-of-array irradiance"),
        MeasurementType("ghi", Dimension.IRRADIANCE, "instantaneous", "Global horizontal irradiance"),
        MeasurementType("module_temperature", Dimension.TEMPERATURE, "instantaneous", "Back-of-module temp."),
        MeasurementType("ambient_temperature", Dimension.TEMPERATURE, "instantaneous", "Ambient air temp."),
        MeasurementType("inverter_temperature", Dimension.TEMPERATURE, "instantaneous", "Inverter heatsink"),
        MeasurementType("wind_speed", Dimension.SPEED, "instantaneous", "Wind speed"),
        MeasurementType("status_code", Dimension.STATUS, "state", "Equipment status code"),
        MeasurementType("tracker_angle", Dimension.ANGLE, "instantaneous", "Tracker rotation angle"),
        MeasurementType("tracker_setpoint", Dimension.ANGLE, "instantaneous", "Tracker target angle"),
        MeasurementType("soiling_ratio", Dimension.RATIO, "instantaneous", "Soiling station ratio"),
        MeasurementType("battery_soc", Dimension.RATIO, "instantaneous", "Battery state of charge"),
        MeasurementType("battery_power", Dimension.POWER, "instantaneous", "Battery power (+discharge)"),
        MeasurementType("battery_available_energy", Dimension.ENERGY, "instantaneous", "Available energy"),
        MeasurementType("battery_max_charge_power", Dimension.POWER, "instantaneous", "Charge limit"),
        MeasurementType("battery_max_discharge_power", Dimension.POWER, "instantaneous", "Discharge limit"),
        MeasurementType("battery_temperature", Dimension.TEMPERATURE, "instantaneous", "Battery temp."),
        MeasurementType("battery_state", Dimension.STATUS, "state", "Battery operating state"),
    ]
}
