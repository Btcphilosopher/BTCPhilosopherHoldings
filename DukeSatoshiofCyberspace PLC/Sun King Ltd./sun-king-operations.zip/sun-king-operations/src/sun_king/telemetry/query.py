"""Read-side helpers for cleaned telemetry and freshness."""

from __future__ import annotations

from datetime import datetime, timedelta

import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from sun_king.core.timeutil import utcnow
from sun_king.telemetry.models import CleanObservation, RawObservation, SourceStatus, StreamState


def series(
    session: Session,
    asset_id: str,
    measurement_type: str,
    start: datetime,
    end: datetime,
    qualities: tuple[str, ...] = ("good",),
    pad: timedelta = timedelta(minutes=15),
) -> list[tuple[datetime, float | None]]:
    """Cleaned samples in [start - pad, end + pad] restricted to the given quality levels."""
    rows = session.execute(
        select(CleanObservation.observation_time, CleanObservation.value)
        .where(
            CleanObservation.asset_id == asset_id,
            CleanObservation.measurement_type == measurement_type,
            CleanObservation.observation_time >= start - pad,
            CleanObservation.observation_time <= end + pad,
            CleanObservation.quality.in_(qualities),
        )
        .order_by(CleanObservation.observation_time)
    ).all()
    return [(t, v) for t, v in rows]


def frame(
    session: Session,
    asset_ids: list[str],
    measurement_type: str,
    start: datetime,
    end: datetime,
    qualities: tuple[str, ...] = ("good",),
    resample: str | None = None,
) -> pd.DataFrame:
    """Wide DataFrame (columns = asset) of cleaned values; non-accepted qualities become NaN."""
    rows = session.execute(
        select(
            CleanObservation.observation_time,
            CleanObservation.asset_id,
            CleanObservation.value,
            CleanObservation.quality,
        ).where(
            CleanObservation.asset_id.in_(asset_ids),
            CleanObservation.measurement_type == measurement_type,
            CleanObservation.observation_time >= start,
            CleanObservation.observation_time < end,
        )
    ).all()
    if not rows:
        return pd.DataFrame(columns=asset_ids, dtype=float)
    df = pd.DataFrame(rows, columns=["t", "asset", "value", "quality"])
    df.loc[~df["quality"].isin(qualities), "value"] = float("nan")
    df["t"] = pd.to_datetime(df["t"], utc=True)
    wide = df.pivot_table(index="t", columns="asset", values="value", aggfunc="last", dropna=False)
    wide = wide.reindex(columns=asset_ids)
    if resample:
        wide = wide.resample(resample).mean()
    return wide.astype(float)


def latest_values(session: Session, site_id: str, now: datetime | None = None) -> list[dict]:
    now = now or utcnow()
    out = []
    for st in session.scalars(select(StreamState).where(StreamState.site_id == site_id)):
        age = (now - st.last_observation_time).total_seconds()
        out.append(
            {
                "asset_id": st.asset_id,
                "measurement_type": st.measurement_type,
                "source": st.source,
                "value": st.last_value,
                "unit": st.last_unit,
                "quality": st.last_quality,
                "observation_time": st.last_observation_time.isoformat(),
                "ingestion_time": st.last_ingestion_time.isoformat(),
                "age_s": round(age, 1),
                "measurement_id": st.last_measurement_id,
            }
        )
    return out


def freshness(session: Session, site_id: str, stale_after_s: int, now: datetime | None = None) -> dict:
    now = now or utcnow()
    states = session.scalars(select(StreamState).where(StreamState.site_id == site_id)).all()
    sources = session.scalars(select(SourceStatus).where(SourceStatus.site_id == site_id)).all()
    if not states:
        return {
            "state": "no_data",
            "newest_observation": None,
            "age_s": None,
            "stale_streams": 0,
            "streams": 0,
            "sources": [],
        }
    newest = max(s.last_observation_time for s in states)
    stale = [s for s in states if (now - s.last_observation_time).total_seconds() > stale_after_s]
    age = (now - newest).total_seconds()
    state = (
        "live"
        if age <= stale_after_s and not stale
        else ("partial" if age <= stale_after_s else "disconnected")
    )
    return {
        "state": state,
        "newest_observation": newest.isoformat(),
        "age_s": round(age, 1),
        "stale_streams": len(stale),
        "stale_stream_ids": sorted({f"{s.asset_id}:{s.measurement_type}" for s in stale})[:50],
        "streams": len(states),
        "sources": [
            {
                "source": s.source,
                "last_contact": s.last_contact.isoformat() if s.last_contact else None,
                "age_s": round((now - s.last_contact).total_seconds(), 1) if s.last_contact else None,
                "state": "disconnected"
                if s.last_contact and (now - s.last_contact).total_seconds() > stale_after_s
                else s.state,
                "consecutive_failures": s.consecutive_failures,
                "last_error": s.last_error,
            }
            for s in sources
        ],
    }


def raw_for(
    session: Session, asset_id: str, measurement_type: str, start: datetime, end: datetime, limit=5000
):
    rows = session.scalars(
        select(RawObservation)
        .where(
            RawObservation.asset_id == asset_id,
            RawObservation.measurement_type == measurement_type,
            RawObservation.observation_time >= start,
            RawObservation.observation_time < end,
        )
        .order_by(RawObservation.observation_time, RawObservation.revision)
        .limit(limit)
    ).all()
    return [
        {
            "measurement_id": r.measurement_id,
            "asset_id": r.asset_id,
            "measurement_type": r.measurement_type,
            "value": r.value,
            "unit": r.unit,
            "observation_time": r.observation_time.isoformat(),
            "ingestion_time": r.ingestion_time.isoformat(),
            "source": r.source,
            "quality_flags": r.quality_flags,
            "revision": r.revision,
            "batch_id": r.batch_id,
            "status_text": r.status_text,
        }
        for r in rows
    ]
