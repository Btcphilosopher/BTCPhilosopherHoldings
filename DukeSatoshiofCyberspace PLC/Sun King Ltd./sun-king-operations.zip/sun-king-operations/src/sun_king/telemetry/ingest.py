"""Telemetry ingestion: idempotent, duplicate-safe, order-tolerant.

Pipeline per batch
------------------
1. Bound the batch size (``max_ingest_batch``).
2. Replay protection: a repeated ``idempotency_key`` returns the original summary.
3. Reject observations for unknown assets (recorded in the batch errors).
4. Duplicate handling on (asset, type, observation_time, source):
   identical value → counted as duplicate, not stored again;
   different value → stored as a new *revision* and flagged ``revised``.
5. Arrival-order bookkeeping flags ``out_of_order`` and ``late_arrival``.
6. Validation (``sun_king.quality.rules``) produces a cleaned row in canonical
   units; raw rows are stored unchanged.
7. Stream and source freshness state is updated (never moved backwards).
"""

from __future__ import annotations

import hashlib
from collections import defaultdict
from collections.abc import Callable, Iterable
from datetime import datetime

import pandas as pd
from sqlalchemy import insert, select, update
from sqlalchemy.orm import Session

from sun_king.adapters.pvmodel import solar_elevation
from sun_king.assets.models import Asset, Site
from sun_king.config import get_settings
from sun_king.core.ids import new_id
from sun_king.core.timeutil import utcnow
from sun_king.quality.rules import STUCK_SAMPLES, VALIDATION_VERSION, StreamContext, validate
from sun_king.telemetry.models import (
    CleanObservation,
    IngestionBatch,
    RawObservation,
    SourceStatus,
    StreamState,
)
from sun_king.telemetry.schemas import IngestSummary, ObservationIn

SUN_TYPES = {"poa_irradiance", "ghi", "module_temperature", "ambient_temperature"}


class BatchTooLarge(ValueError):
    pass


def _mid(o: ObservationIn, revision: int) -> str:
    if o.measurement_id and revision == 0:
        return o.measurement_id
    h = hashlib.sha256(
        f"{o.asset_id}|{o.measurement_type}|{o.observation_time.isoformat()}|{o.source}|{revision}".encode()
    ).hexdigest()[:24]
    return f"m-{h}"


def ingest_batch(
    session: Session,
    observations: list[ObservationIn],
    source: str,
    idempotency_key: str | None = None,
    now: datetime | None = None,
    listeners: Iterable = (),
    arrival_time: Callable[[ObservationIn], datetime] | None = None,
) -> IngestSummary:
    """Ingest one batch. ``arrival_time`` is only for simulation backfill: it emulates the
    per-delivery receipt times of a logger pushing every few minutes; live ingestion uses ``now``."""
    settings = get_settings()
    if len(observations) > settings.max_ingest_batch:
        raise BatchTooLarge(f"batch of {len(observations)} exceeds limit {settings.max_ingest_batch}")
    now = now or utcnow()

    if idempotency_key:
        prior = session.scalar(
            select(IngestionBatch).where(IngestionBatch.idempotency_key == idempotency_key)
        )
        if prior is not None:
            return IngestSummary(
                batch_id=prior.id,
                source=prior.source,
                received=prior.received,
                accepted=prior.accepted,
                duplicates=prior.duplicates,
                revisions=prior.revisions,
                rejected=prior.rejected,
                out_of_order=prior.out_of_order,
                late=prior.late,
                status=prior.status,
                replayed=True,
                errors=prior.errors,
            )

    batch = IngestionBatch(
        id=new_id("batch"), source=source, idempotency_key=idempotency_key, received_at=now
    )
    session.add(batch)
    session.flush()

    asset_ids = {o.asset_id for o in observations}
    assets = {a.asset_id: a for a in session.scalars(select(Asset).where(Asset.asset_id.in_(asset_ids)))}
    sites = {
        s.id: s
        for s in session.scalars(select(Site).where(Site.id.in_({a.site_id for a in assets.values()})))
    }

    errors: list[dict] = []
    valid: list[tuple[int, ObservationIn]] = []
    for i, o in enumerate(observations):
        if o.asset_id not in assets:
            errors.append({"index": i, "asset_id": o.asset_id, "error": "unknown_asset"})
            continue
        valid.append((i, o))

    # ---- existing revisions for duplicate detection: one ranged query per stream
    existing: dict[tuple, tuple[int, float | None]] = {}
    spans: dict[tuple, list[datetime]] = defaultdict(list)
    for _, o in valid:
        spans[(o.asset_id, o.measurement_type, o.source)].append(o.observation_time)
    for (a, m, s), ts in spans.items():
        wanted = set(ts)
        rows = session.execute(
            select(RawObservation.observation_time, RawObservation.revision, RawObservation.value).where(
                RawObservation.asset_id == a,
                RawObservation.measurement_type == m,
                RawObservation.source == s,
                RawObservation.observation_time >= min(ts),
                RawObservation.observation_time <= max(ts),
            )
        ).all()
        for t, rev, val in rows:
            if t not in wanted:
                continue
            key = (a, m, t, s)
            if key not in existing or rev > existing[key][0]:
                existing[key] = (rev, val)

    # ---- stream state + recent clean values
    stream_keys = {(o.asset_id, o.measurement_type, o.source) for _, o in valid}
    states: dict[tuple, StreamState] = {}
    for st in session.scalars(
        select(StreamState).where(StreamState.asset_id.in_({k[0] for k in stream_keys}))
    ):
        states[(st.asset_id, st.measurement_type, st.source)] = st

    # Arrival-order flags (before sorting)
    pre_flags: dict[int, list[str]] = defaultdict(list)
    max_seen: dict[tuple, datetime] = {k: st.last_observation_time for k, st in states.items()}
    for i, o in valid:
        sk = (o.asset_id, o.measurement_type, o.source)
        if sk in max_seen and o.observation_time < max_seen[sk]:
            pre_flags[i].append("out_of_order")
        if sk not in max_seen or o.observation_time > max_seen[sk]:
            max_seen[sk] = o.observation_time
        pre_flags[i].extend(f for f in o.quality_flags if f.startswith("source:") or f.startswith("src_"))

    # Sun-up for relevant types, vectorised per site
    sun_up: dict[int, bool] = {}
    by_site: dict[str, list[tuple[int, ObservationIn]]] = defaultdict(list)
    for i, o in valid:
        if o.measurement_type in SUN_TYPES:
            by_site[assets[o.asset_id].site_id].append((i, o))
    for site_id, items in by_site.items():
        site = sites[site_id]
        idx = pd.DatetimeIndex([o.observation_time for _, o in items])
        elev = solar_elevation(site.latitude, site.longitude, idx)
        for (i, _), e in zip(items, elev, strict=True):
            sun_up[i] = bool(e > 0.0)

    # Recent daytime values per stream for stuck detection
    recent: dict[tuple, list[float]] = defaultdict(list)
    prev: dict[tuple, tuple[datetime, float]] = {}
    for sk in stream_keys:
        if sk[1] not in SUN_TYPES and sk[1] not in ("inverter_temperature",):
            continue
        first_t = min(
            o.observation_time for _, o in valid if (o.asset_id, o.measurement_type, o.source) == sk
        )
        rows = session.execute(
            select(CleanObservation.observation_time, CleanObservation.value)
            .where(
                CleanObservation.asset_id == sk[0],
                CleanObservation.measurement_type == sk[1],
                CleanObservation.observation_time < first_t,
                CleanObservation.value.is_not(None),
            )
            .order_by(CleanObservation.observation_time.desc())
            .limit(STUCK_SAMPLES)
        ).all()
        recent[sk] = [r[1] for r in rows if r[1] is not None and r[1] > 20]
        if rows:
            prev[sk] = (rows[0][0], rows[0][1])

    raw_rows: list[dict] = []
    clean_new: list[dict] = []
    clean_updates: list[dict] = []
    duplicates = revisions = out_of_order = late = 0
    latest: dict[tuple, dict] = {}

    for i, o in sorted(valid, key=lambda x: x[1].observation_time):
        key = (o.asset_id, o.measurement_type, o.observation_time, o.source)
        sk = key[0], key[1], key[3]
        rev = 0
        flags = list(pre_flags.get(i, []))
        if key in existing:
            prior_rev, prior_val = existing[key]
            if (prior_val is None and o.value is None) or (
                prior_val is not None and o.value is not None and abs(prior_val - o.value) < 1e-9
            ):
                duplicates += 1
                continue
            rev = prior_rev + 1
            flags.append("revised")
            revisions += 1
        existing[key] = (rev, o.value)
        asset = assets[o.asset_id]
        rated_kw = asset.rated_capacity if asset.rated_capacity_unit in ("kW", "kVA") else None
        ctx = StreamContext(
            rated_kw=rated_kw,
            sun_up=sun_up.get(i),
            previous_value=prev.get(sk, (None, None))[1],
            previous_time=prev.get(sk, (None, None))[0],
            recent_values=recent.get(sk, []),
        )
        arrived = arrival_time(o) if arrival_time else now
        res = validate(o.measurement_type, o.value, o.unit, o.observation_time, arrived, ctx, flags)
        if "out_of_order" in res.flags:
            out_of_order += 1
        if "late_arrival" in res.flags:
            late += 1
        mid = _mid(o, rev)
        raw_rows.append(
            dict(
                measurement_id=mid,
                asset_id=o.asset_id,
                measurement_type=o.measurement_type,
                value=o.value,
                unit=o.unit,
                observation_time=o.observation_time,
                ingestion_time=arrived,
                source=o.source,
                quality_flags=sorted(set(o.quality_flags + res.flags)),
                revision=rev,
                batch_id=batch.id,
                status_text=o.status_text,
            )
        )
        clean = dict(
            asset_id=o.asset_id,
            site_id=asset.site_id,
            measurement_type=o.measurement_type,
            observation_time=o.observation_time,
            value=res.value,
            unit=res.unit,
            quality=res.quality,
            quality_flags=res.flags,
            raw_measurement_id=mid,
            validation_version=VALIDATION_VERSION,
            source=o.source,
            ingestion_time=arrived,
        )
        (clean_updates if rev > 0 else clean_new).append(clean)
        if res.value is not None and o.measurement_type in SUN_TYPES | {"inverter_temperature"}:
            if sun_up.get(i) and res.value > 20:
                recent[sk] = [res.value] + recent[sk][: STUCK_SAMPLES - 1]
            prev[sk] = (o.observation_time, res.value)
        cur = latest.get(sk)
        if cur is None or o.observation_time >= cur["observation_time"]:
            latest[sk] = {**clean, "site_id": asset.site_id}

    if raw_rows:
        session.execute(insert(RawObservation), raw_rows)
    if clean_new:
        session.execute(insert(CleanObservation), clean_new)
    for c in clean_updates:
        res_upd = session.execute(
            update(CleanObservation)
            .where(
                CleanObservation.asset_id == c["asset_id"],
                CleanObservation.measurement_type == c["measurement_type"],
                CleanObservation.observation_time == c["observation_time"],
            )
            .values(
                **{
                    k: v
                    for k, v in c.items()
                    if k not in ("asset_id", "measurement_type", "observation_time")
                }
            )
        )
        if res_upd.rowcount == 0:
            session.execute(insert(CleanObservation), [c])

    for sk, c in latest.items():
        st = states.get(sk)
        if st is None:
            session.add(
                StreamState(
                    asset_id=sk[0],
                    measurement_type=sk[1],
                    source=sk[2],
                    site_id=c["site_id"],
                    last_observation_time=c["observation_time"],
                    last_ingestion_time=now,
                    last_value=c["value"],
                    last_unit=c["unit"],
                    last_quality=c["quality"],
                    last_measurement_id=c["raw_measurement_id"],
                )
            )
        elif c["observation_time"] >= st.last_observation_time:
            st.last_observation_time = c["observation_time"]
            st.last_ingestion_time = now
            st.last_value = c["value"]
            st.last_unit = c["unit"]
            st.last_quality = c["quality"]
            st.last_measurement_id = c["raw_measurement_id"]

    for site_id in {assets[o.asset_id].site_id for _, o in valid}:
        ss = session.get(SourceStatus, (site_id, source))
        if ss is None:
            ss = SourceStatus(site_id=site_id, source=source)
            session.add(ss)
        ss.last_contact = now
        ss.consecutive_failures = 0
        ss.state = "connected"
        ss.last_error = None

    batch.received = len(observations)
    batch.accepted = len(raw_rows)
    batch.duplicates = duplicates
    batch.revisions = revisions
    batch.rejected = len(errors)
    batch.out_of_order = out_of_order
    batch.late = late
    batch.errors = errors[:200]
    batch.status = "complete" if not errors else "partial"
    session.flush()
    summary = IngestSummary(
        batch_id=batch.id,
        source=source,
        received=batch.received,
        accepted=batch.accepted,
        duplicates=duplicates,
        revisions=revisions,
        rejected=batch.rejected,
        out_of_order=out_of_order,
        late=late,
        status=batch.status,
        errors=batch.errors,
    )
    for fn in listeners:
        fn(summary, list(latest.values()))
    return summary


def record_source_failure(
    session: Session, site_id: str, source: str, error: str, now: datetime | None = None
):
    now = now or utcnow()
    ss = session.get(SourceStatus, (site_id, source))
    if ss is None:
        ss = SourceStatus(site_id=site_id, source=source)
        session.add(ss)
    ss.consecutive_failures = (ss.consecutive_failures or 0) + 1
    ss.last_error = error[:2000]
    ss.state = "degraded" if ss.consecutive_failures < 3 else "disconnected"
    return ss
