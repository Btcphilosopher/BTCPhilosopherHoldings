"""Investigation workflow: Detected → Assigned → Investigating → Action planned → Resolved → Verified.

* Acknowledgement records who has seen the alert; it never changes the
  workflow status or the condition flag.
* Resolving while the condition is still active requires an explicit reason,
  which is recorded.
* Verification requires either a passing post-maintenance recovery check or a
  cleared condition, and an engineer-level user.
"""

from __future__ import annotations

from datetime import datetime, timedelta

import numpy as np
import pandas as pd
from sqlalchemy.orm import Session

from sun_king.alerts.models import ALERT_WORKFLOW, Alert, AlertEvent
from sun_king.core.timeutil import utcnow

TRANSITIONS = {
    "detected": {"assigned", "investigating"},
    "assigned": {"investigating", "detected"},
    "investigating": {"action_planned", "resolved", "assigned"},
    "action_planned": {"resolved", "investigating"},
    "resolved": {"verified", "investigating"},
    "verified": {"investigating"},
}


class WorkflowError(ValueError):
    pass


def acknowledge(session: Session, alert: Alert, user_id: str, note: str | None = None) -> Alert:
    alert.acknowledged_at = utcnow()
    alert.acknowledged_by = user_id
    session.add(
        AlertEvent(
            alert_id=alert.id,
            actor_id=user_id,
            event="acknowledged",
            note=note,
            data={"condition_active": alert.condition_active, "status": alert.status},
        )
    )
    return alert


def transition(
    session: Session,
    alert: Alert,
    to_status: str,
    user_id: str,
    note: str | None = None,
    assignee: str | None = None,
    force_reason: str | None = None,
    verification: dict | None = None,
) -> Alert:
    if to_status not in ALERT_WORKFLOW:
        raise WorkflowError(f"unknown status {to_status}")
    if to_status not in TRANSITIONS.get(alert.status, set()):
        raise WorkflowError(f"cannot move from {alert.status} to {to_status}")
    if to_status == "assigned" and not (assignee or alert.assigned_to):
        raise WorkflowError("assignment requires an assignee")
    if to_status == "resolved" and alert.condition_active and not force_reason:
        raise WorkflowError("condition is still active: resolve requires force_reason (recorded)")
    if to_status == "verified":
        if alert.condition_active:
            raise WorkflowError("cannot verify while the underlying condition is active")
        if verification is not None and not verification.get("passed"):
            raise WorkflowError("recovery verification did not pass")
    prev = alert.status
    alert.status = to_status
    if assignee:
        alert.assigned_to = assignee
    now = utcnow()
    if to_status == "resolved":
        alert.resolved_at = now
    if to_status == "verified":
        alert.verified_at = now
    data = {"condition_active": alert.condition_active}
    if force_reason:
        data["force_reason"] = force_reason
    if verification:
        data["verification"] = verification
    session.add(
        AlertEvent(
            alert_id=alert.id,
            actor_id=user_id,
            event="status_change",
            from_status=prev,
            to_status=to_status,
            note=note,
            data=data,
        )
    )
    return alert


def verify_recovery(
    session: Session,
    site_id: str,
    asset_id: str,
    after: datetime,
    min_hours: float = 1.5,
    max_hours: float = 30.0,
    pass_index: float = 0.92,
    settle_minutes: int = 15,
) -> dict:
    """Post-maintenance recovery check for an inverter.

    Uses daylight intervals from ``after`` + ``settle_minutes`` (restart and
    settling time) with POA ≥ 150 W/m² and no curtailment. Passes when the inverter's expected-energy index is ≥
    ``pass_index`` *and* within 5 percentage points of its peers' median.
    """
    from sun_king.performance.analysis import classify_intervals, run_site_model

    after = after + timedelta(minutes=settle_minutes)
    end = min(after + timedelta(hours=max_hours), utcnow())
    if end <= after:
        return {"passed": False, "reason": "no data after maintenance yet"}
    run = run_site_model(session, site_id, after, end)
    if asset_id not in run.expected:
        return {"passed": False, "reason": f"{asset_id} has no performance model"}
    rows = {}
    for iid, e in run.expected.items():
        cls = classify_intervals(run, iid)
        meas = run.measured_ac[iid] if iid in run.measured_ac else pd.Series(np.nan, index=run.grid)
        ok = (cls == "producing") & (e["poa"] >= 150) & meas.notna() & e["ac_kw"].notna()
        if iid == asset_id:
            ok = (
                cls.isin(["producing", "fault", "zero_output_unexplained"]) & (e["poa"] >= 150) & meas.notna()
            )
        rows[iid] = {
            "intervals": int(ok.sum()),
            "index": float(meas[ok].sum() / e["ac_kw"][ok].sum())
            if ok.sum() and e["ac_kw"][ok].sum() > 0
            else None,
            "measured_kwh": round(float(meas[ok].sum() / 12), 2),
            "expected_kwh": round(float(e["ac_kw"][ok].sum() / 12), 2),
            "fault_intervals": int((cls == "fault").sum()),
        }
    tgt = rows[asset_id]
    hours = tgt["intervals"] * 5 / 60
    peers = [r["index"] for k, r in rows.items() if k != asset_id and r["index"]]
    peer_med = float(np.median(peers)) if peers else None
    result = {
        "asset_id": asset_id,
        "window_start": after.isoformat(),
        "window_end": end.isoformat(),
        "comparable_hours": round(hours, 2),
        "required_hours": min_hours,
        "index": round(tgt["index"], 4) if tgt["index"] else None,
        "pass_index": pass_index,
        "peer_median_index": round(peer_med, 4) if peer_med else None,
        "peers": rows,
        "irradiance_basis": run.basis.status,
        "method": "expected-energy index after repair vs pvlib model and peers",
    }
    if hours < min_hours:
        result.update(
            passed=False, reason=f"only {hours:.1f} h of comparable daylight data (need {min_hours} h)"
        )
    elif tgt["index"] is None:
        result.update(passed=False, reason="no expected energy in window")
    elif tgt["fault_intervals"] > 0:
        result.update(passed=False, reason="fault status recorded after repair")
    else:
        ok = tgt["index"] >= pass_index and (peer_med is None or abs(tgt["index"] - peer_med) <= 0.05)
        result.update(passed=bool(ok), reason="recovered" if ok else "index below threshold or off peers")
    return result
