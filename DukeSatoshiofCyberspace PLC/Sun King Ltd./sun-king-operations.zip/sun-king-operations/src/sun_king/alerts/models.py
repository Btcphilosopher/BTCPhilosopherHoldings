from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, Float, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from sun_king.core.db import Base, JSONType, UTCDateTime
from sun_king.core.timeutil import utcnow

ALERT_WORKFLOW = ("detected", "assigned", "investigating", "action_planned", "resolved", "verified")


class AlertRule(Base):
    __tablename__ = "alert_rules"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    version: Mapped[int] = mapped_column(Integer, primary_key=True)
    rule_type: Mapped[str] = mapped_column(String(48))
    name: Mapped[str] = mapped_column(String(200))
    site_id: Mapped[str | None] = mapped_column(ForeignKey("sites.id"))  # None = portfolio default
    severity: Mapped[str] = mapped_column(String(16))  # info | warning | critical
    params: Mapped[dict] = mapped_column(JSONType, default=dict)
    persistence_s: Mapped[int] = mapped_column(Integer, default=900)
    clear_persistence_s: Mapped[int] = mapped_column(Integer, default=900)
    threshold_source: Mapped[str] = mapped_column(String(200))
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    active_version: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    created_by: Mapped[str | None] = mapped_column(String(64))


class AlertConditionState(Base):
    """Per (rule, subject) persistence/hysteresis state for the evaluator."""

    __tablename__ = "alert_condition_states"
    rule_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    subject_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    pending_since: Mapped[datetime | None] = mapped_column(UTCDateTime)
    clearing_since: Mapped[datetime | None] = mapped_column(UTCDateTime)
    active_alert_id: Mapped[str | None] = mapped_column(String(64))
    last_evaluated: Mapped[datetime | None] = mapped_column(UTCDateTime)
    last_value: Mapped[float | None] = mapped_column(Float)


class Alert(Base):
    __tablename__ = "alerts"
    __table_args__ = (Index("ix_alerts_site_status", "site_id", "status"),)
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"))
    rule_id: Mapped[str] = mapped_column(String(64))
    rule_version: Mapped[int] = mapped_column(Integer)
    rule_params: Mapped[dict] = mapped_column(JSONType, default=dict)
    threshold_source: Mapped[str] = mapped_column(String(200))
    alert_type: Mapped[str] = mapped_column(String(48), index=True)
    severity: Mapped[str] = mapped_column(String(16))
    title: Mapped[str] = mapped_column(String(300))
    subject_id: Mapped[str] = mapped_column(String(64))
    affected_assets: Mapped[list] = mapped_column(JSONType, default=list)
    status: Mapped[str] = mapped_column(String(24), default="detected")
    condition_active: Mapped[bool] = mapped_column(Boolean, default=True)
    acknowledged_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    acknowledged_by: Mapped[str | None] = mapped_column(String(64))
    assigned_to: Mapped[str | None] = mapped_column(String(64))
    attribution: Mapped[str] = mapped_column(String(32), default="uncertain")
    attribution_confidence: Mapped[str] = mapped_column(String(16), default="low")
    attribution_notes: Mapped[str | None] = mapped_column(Text)
    evidence: Mapped[dict] = mapped_column(JSONType, default=dict)
    first_detected_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    condition_started_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    condition_cleared_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    last_evaluated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    resolved_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    verified_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    suppressed_count: Mapped[int] = mapped_column(Integer, default=0)
    priority_score: Mapped[float | None] = mapped_column(Float)
    energy_at_risk_kwh: Mapped[float | None] = mapped_column(Float)


class AlertEvent(Base):
    __tablename__ = "alert_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    alert_id: Mapped[str] = mapped_column(ForeignKey("alerts.id"), index=True)
    at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    actor_id: Mapped[str | None] = mapped_column(String(64))
    event: Mapped[str] = mapped_column(String(48))
    from_status: Mapped[str | None] = mapped_column(String(24))
    to_status: Mapped[str | None] = mapped_column(String(24))
    note: Mapped[str | None] = mapped_column(Text)
    data: Mapped[dict] = mapped_column(JSONType, default=dict)


class Suppression(Base):
    """Planned suppression window (e.g. during maintenance) — always recorded and visible."""

    __tablename__ = "alert_suppressions"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"))
    asset_id: Mapped[str | None] = mapped_column(String(64))
    alert_types: Mapped[list] = mapped_column(JSONType, default=list)
    start_time: Mapped[datetime] = mapped_column(UTCDateTime)
    end_time: Mapped[datetime] = mapped_column(UTCDateTime)
    reason: Mapped[str] = mapped_column(Text)
    created_by: Mapped[str | None] = mapped_column(String(64))
