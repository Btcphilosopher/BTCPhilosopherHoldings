"""Alert evaluation with persistence, hysteresis and suppression.

Evaluation is *as-of*: only observations whose ``ingestion_time`` ≤ the
evaluation time are visible, so replaying history never uses data that had
not yet arrived (no look-ahead).

Electrical faults are not inferred from low output alone: the outage and
underperformance rules require adequate irradiance and producing peers, and
are suspended (not triggered) when telemetry is stale, irradiance is
uncertain or a curtailment is recorded.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

import numpy as np
import pandas as pd
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from sun_king.adapters import pvmodel
from sun_king.alerts.models import Alert, AlertConditionState, AlertEvent, AlertRule, Suppression
from sun_king.alerts.rules import DEFAULT_RULES
from sun_king.assets.models import Asset, PVSystemConfig, Site
from sun_king.core.ids import new_id
from sun_king.core.timeutil import local_date
from sun_king.energy.models import CurtailmentRecord
from sun_king.telemetry.models import CleanObservation

SEV_WEIGHT = {"info": 0.2, "warning": 1.0, "critical": 3.0}
CONF_WEIGHT = {"low": 0.5, "medium": 0.8, "high": 1.0}


@dataclass
class Condition:
    subject_id: str
    active: bool | None  # None = cannot evaluate (inputs inadequate)
    title: str
    value: float | None = None
    affected_assets: list[str] = field(default_factory=list)
    evidence: dict = field(default_factory=dict)
    attribution: str = "uncertain"
    confidence: str = "low"
    notes: str | None = None
    severity: str | None = None
    energy_at_risk_kwh: float | None = None


def ensure_default_rules(session: Session) -> None:
    for r in DEFAULT_RULES:
        if session.get(AlertRule, (r["id"], 1)) is None:
            session.add(AlertRule(version=1, **r))
    session.flush()


def active_rules(session: Session, site_id: str) -> list[AlertRule]:
    rules = session.scalars(
        select(AlertRule).where(AlertRule.active_version.is_(True), AlertRule.enabled.is_(True))
    ).all()
    by_id: dict[str, AlertRule] = {}
    for r in rules:
        if r.site_id not in (None, site_id):
            continue
        cur = by_id.get(r.id)
        if cur is None or (r.site_id == site_id and cur.site_id is None):
            by_id[r.id] = r
    return list(by_id.values())


# --------------------------------------------------------------------------- data access (as-of)
class AsOfWindow:
    def __init__(self, session: Session, site: Site, at: datetime, minutes: int = 90):
        self.session, self.site, self.at = session, site, at
        self.start = at - timedelta(minutes=minutes)
        rows = session.execute(
            select(
                CleanObservation.asset_id,
                CleanObservation.measurement_type,
                CleanObservation.observation_time,
                CleanObservation.value,
                CleanObservation.quality,
                CleanObservation.quality_flags,
                CleanObservation.raw_measurement_id,
            ).where(
                CleanObservation.site_id == site.id,
                CleanObservation.observation_time > self.start,
                CleanObservation.observation_time <= at,
                CleanObservation.ingestion_time <= at,
            )
        ).all()
        self.df = pd.DataFrame(rows, columns=["asset", "mtype", "t", "value", "quality", "flags", "mid"])
        if not self.df.empty:
            self.df["t"] = pd.to_datetime(self.df["t"], utc=True)
        last = session.execute(
            select(CleanObservation.asset_id, func.max(CleanObservation.observation_time))
            .where(
                CleanObservation.site_id == site.id,
                CleanObservation.observation_time <= at,
                CleanObservation.observation_time > at - timedelta(days=3),
                CleanObservation.ingestion_time <= at,
            )
            .group_by(CleanObservation.asset_id)
        ).all()
        self.last_seen = {a: t for a, t in last}
        self.grid = pd.date_range(pd.Timestamp(self.start).ceil("5min"), at, freq="5min")
        self._groups = {k: g for k, g in self.df.groupby(["asset", "mtype"])} if not self.df.empty else {}
        self._cache: dict = {}
        from sun_king.assets.models import MonitoringPoint

        self.nominal = {}
        for aid, iv in session.execute(select(MonitoringPoint.asset_id, MonitoringPoint.nominal_interval_s)):
            self.nominal[aid] = min(self.nominal.get(aid, iv), iv)

    def cached(self, key, fn):
        if key not in self._cache:
            self._cache[key] = fn()
        return self._cache[key]

    def series(self, asset: str, mtype: str, good_only=True, resample=True) -> pd.Series:
        key = ("s", asset, mtype, good_only, resample)
        if key in self._cache:
            return self._cache[key]
        self._cache[key] = self._series(asset, mtype, good_only, resample)
        return self._cache[key]

    def _series(self, asset: str, mtype: str, good_only=True, resample=True) -> pd.Series:
        d = self._groups.get((asset, mtype))
        if d is None:
            return pd.Series(np.nan, index=self.grid) if resample else pd.Series(dtype=float)
        if good_only:
            d = d[d.quality == "good"]
        s = d.set_index("t")["value"].astype(float).sort_index()
        if resample and not s.empty:
            s = s.resample("5min", label="right", closed="right").mean().reindex(self.grid)
        return s

    def ids(self, asset: str, mtype: str, n: int = 6) -> list[str]:
        d = self._groups.get((asset, mtype))
        return [] if d is None else d.sort_values("t")["mid"].tail(n).tolist()

    def flags(self, asset: str, mtype: str) -> list[list[str]]:
        d = self._groups.get((asset, mtype))
        return [] if d is None else d.sort_values("t")["flags"].tolist()


def _assets(session, site_id, atype):
    return list(
        session.scalars(
            select(Asset)
            .where(Asset.site_id == site_id, Asset.asset_type == atype, Asset.effective_to.is_(None))
            .order_by(Asset.asset_id)
        )
    )


def _poa_basis(w: AsOfWindow) -> tuple[pd.Series, str, list[str]]:
    return w.cached("poa_basis", lambda: _poa_basis_impl(w))


def _poa_basis_impl(w: AsOfWindow) -> tuple[pd.Series, str, list[str]]:
    pyrs = [
        s
        for s in _assets(w.session, w.site.id, "sensor")
        if (s.electrical_parameters or {}).get("sensor_role") in ("primary", "reference")
    ]
    usable = []
    for s in pyrs:
        fl = w.flags(s.asset_id, "poa_irradiance")
        if fl and sum(1 for f in fl if "stuck_value" in (f or [])) / len(fl) > 0.2:
            continue
        ser = w.series(s.asset_id, "poa_irradiance")
        if ser.notna().any():
            usable.append((s.asset_id, ser))
    if not usable:
        return pd.Series(np.nan, index=w.grid), "unavailable", []
    if len(usable) == 1:
        return usable[0][1], "single_sensor", [usable[0][0]]
    a, b = usable[0][1], usable[1][1]
    m = (a > 80) & (b > 80)
    if m.any() and float((abs(a[m] - b[m]) / ((a[m] + b[m]) / 2)).median()) > 0.10:
        return (a + b) / 2, "uncertain", [usable[0][0], usable[1][0]]
    return (a + b) / 2, "ok", [usable[0][0], usable[1][0]]


def _expected(w: AsOfWindow, poa: pd.Series) -> dict[str, pd.Series]:
    return w.cached("expected", lambda: _expected_impl(w, poa))


def _expected_impl(w: AsOfWindow, poa: pd.Series) -> dict[str, pd.Series]:
    from sun_king.performance.analysis import _spec

    site = w.site
    cfgs = {c.inverter_asset_id: c for c in w.session.scalars(select(PVSystemConfig))}
    pyr = next(
        (
            s
            for s in _assets(w.session, site.id, "sensor")
            if (s.electrical_parameters or {}).get("sensor_role") == "primary"
        ),
        None,
    )
    plane = (pyr.electrical_parameters if pyr else {}) or {}
    ghi_sensor = next(
        (
            s
            for s in _assets(w.session, site.id, "sensor")
            if (s.electrical_parameters or {}).get("sensor_role") == "ghi"
        ),
        None,
    )
    ghi = w.series(ghi_sensor.asset_id, "ghi") if ghi_sensor else pd.Series(np.nan, index=w.grid)
    solpos = pvmodel.solar_position(site.latitude, site.longitude, site.elevation_m, w.grid)
    sky = pvmodel.decompose_ghi(ghi.fillna(0).clip(lower=0), solpos) if ghi.notna().any() else None
    out = {}
    for inv in _assets(w.session, site.id, "inverter"):
        cfg = cfgs.get(inv.asset_id)
        if not cfg:
            continue
        spec, ispec = _spec(cfg, inv)
        coplanar = (
            spec.mounting == "fixed"
            and plane.get("plane_tilt_deg") == spec.tilt
            and plane.get("plane_azimuth_deg") == spec.azimuth
        )
        if coplanar:
            p = poa
        elif sky is not None:
            p = pvmodel.poa_irradiance(spec, sky, solpos, site.albedo).where(ghi.notna())
        else:
            p = pd.Series(np.nan, index=w.grid)
        tc = pvmodel.cell_temperature(
            spec, p.fillna(0), pd.Series(6.0, index=w.grid), pd.Series(3.0, index=w.grid)
        )
        out[inv.asset_id] = pvmodel.expected_ac_from_poa(spec, ispec, p.fillna(0), tc)["ac_kw"].where(
            p.notna()
        )
        out[inv.asset_id].attrs["poa"] = p
    return out


def _curtailed(w: AsOfWindow) -> list[CurtailmentRecord]:
    return list(
        w.session.scalars(
            select(CurtailmentRecord).where(
                CurtailmentRecord.site_id == w.site.id,
                CurtailmentRecord.start_time <= w.at,
                CurtailmentRecord.end_time > w.start,
            )
        )
    )


_DAYLIGHT_CACHE: dict = {}


def _remaining_daylight_h(site: Site, at: datetime) -> float:
    key = (site.id, at)
    if key in _DAYLIGHT_CACHE:
        return _DAYLIGHT_CACHE[key]
    if len(_DAYLIGHT_CACHE) > 5000:
        _DAYLIGHT_CACHE.clear()
    _DAYLIGHT_CACHE[key] = _remaining_daylight_impl(site, at)
    return _DAYLIGHT_CACHE[key]


def _remaining_daylight_impl(site: Site, at: datetime) -> float:
    grid = pd.date_range(at, at + timedelta(hours=24), freq="15min")
    el = pvmodel.solar_elevation(site.latitude, site.longitude, grid)
    return float((el > 5).sum() * 0.25)


# --------------------------------------------------------------------------- rule evaluators
def eval_stale(w: AsOfWindow, rule: AlertRule) -> list[Condition]:
    out = []
    lim = rule.params.get("stale_after_s", 900)
    types = rule.params.get("asset_types", [])
    inv_now = {}
    for atype in types:
        for a in _assets(w.session, w.site.id, atype):
            last = w.last_seen.get(a.asset_id)
            if last is None and atype in ("weather_station",):
                continue
            age = (w.at - last).total_seconds() if last else None
            lim_a = max(lim, 3 * w.nominal.get(a.asset_id, 300))
            stale = age is None or age > lim_a
            if atype == "inverter":
                inv_now[a.asset_id] = stale
            out.append(
                Condition(
                    subject_id=a.asset_id,
                    active=stale,
                    title=f"No telemetry from {a.name} ({a.asset_id})",
                    value=age,
                    affected_assets=[a.asset_id],
                    evidence={
                        "last_observation_time": last.isoformat() if last else None,
                        "age_s": age,
                        "threshold_s": lim_a,
                    },
                    attribution="communication_loss",
                    confidence="high",
                    severity="critical" if atype == "meter" else None,
                )
            )
    # Is the site meter consistent with a silent inverter still producing?
    # Balance at the export meter: meter ≈ Σ inverter AC + battery (+discharge) − transformer/aux losses.
    meter = next((a for a in _assets(w.session, w.site.id, "meter")), None)
    if meter is not None and any(inv_now.values()):
        mk = w.series(meter.asset_id, "ac_power").tail(3).mean()
        reporting = [i for i, s in inv_now.items() if not s]
        rep_kw = sum(w.series(i, "ac_power").tail(3).mean() for i in reporting) if reporting else 0.0
        bess = next(iter(_assets(w.session, w.site.id, "battery_system")), None)
        b_kw = w.series(bess.asset_id, "battery_power").tail(3).mean() if bess else 0.0
        b_known = bess is None or pd.notna(b_kw)
        b_kw = 0.0 if pd.isna(b_kw) else float(b_kw)
        for c in out:
            if c.subject_id in inv_now and inv_now[c.subject_id] and c.active:
                silent = [i for i, s in inv_now.items() if s]
                losses = 0.015 * max(rep_kw + b_kw, 0) + 10.0  # documented allowance: ~1.5 % + aux/no-load
                implied = (mk - b_kw - rep_kw + losses) if pd.notna(mk) else None
                c.evidence["site_meter_kw"] = None if pd.isna(mk) else round(float(mk), 1)
                c.evidence["reporting_inverters_kw"] = round(float(rep_kw), 1)
                c.evidence["battery_kw"] = round(b_kw, 1) if bess else None
                c.evidence["loss_allowance_kw"] = round(losses, 1)
                c.evidence["implied_unreported_kw"] = None if implied is None else round(float(implied), 1)
                c.evidence["silent_inverters"] = silent
                c.evidence["balance"] = "meter − battery − reporting inverters + losses"
                if implied is not None and implied > 20 and b_known:
                    c.notes = (
                        f"Site meter balance implies ≈{implied:.0f} kW from unreported inverter(s): equipment likely "
                        "producing; monitoring link loss only. Not an equipment failure."
                    )
                    c.confidence = "high"
                elif implied is not None and b_known:
                    c.notes = "Site meter balance does not show production from the silent inverter(s); outage possible."
                    c.attribution = "uncertain"
                    c.confidence = "medium"
                else:
                    c.notes = "Meter or battery data unavailable — cannot tell whether the silent inverter is producing."
                    c.confidence = "low"
    # whole-site disconnection
    if out and all(c.active for c in out if c.subject_id in inv_now):
        pass
    return out


def eval_outage(w: AsOfWindow, rule: AlertRule) -> list[Condition]:
    p = rule.params
    poa, basis, sensors = _poa_basis(w)
    exp = _expected(w, poa)
    curt = _curtailed(w)
    out = []
    recent = w.grid[-3:]
    for inv in _assets(w.session, w.site.id, "inverter"):
        meas = w.series(inv.asset_id, "ac_power")
        status = w.series(inv.asset_id, "status_code", good_only=False, resample=False)
        last = w.last_seen.get(inv.asset_id)
        e = exp.get(inv.asset_id)
        if e is None:
            continue
        if last is None or (w.at - last).total_seconds() > 900:
            out.append(Condition(inv.asset_id, None, "", notes="telemetry stale — outage not inferred"))
            continue
        e_recent = e.reindex(recent)
        p_recent = e.attrs["poa"].reindex(recent)
        if basis == "unavailable" or p_recent.isna().all() or float(p_recent.mean()) < p["min_poa_wm2"]:
            out.append(
                Condition(
                    inv.asset_id,
                    False if not alert_open(w.session, rule.id, inv.asset_id) else None,
                    "",
                    notes="irradiance below threshold or unavailable — no inference",
                )
            )
            continue
        peers = [i for i in exp if i != inv.asset_id]
        peer_idx = []
        for pid in peers:
            pm = w.series(pid, "ac_power").reindex(recent).mean()
            pe = exp[pid].reindex(recent).mean()
            if pd.notna(pm) and pe and pe > 1:
                peer_idx.append(pm / pe)
        peers_ok = bool(peer_idx) and float(np.median(peer_idx)) >= p["peer_min_index"]
        m_recent = meas.reindex(recent).mean()
        zero = pd.notna(m_recent) and m_recent < p["zero_fraction_of_rating"] * (inv.rated_capacity or 1)
        if any(c.start_time <= w.at < c.end_time for c in curt) and not zero:
            out.append(Condition(inv.asset_id, False, ""))
            continue
        code = int(status.iloc[-1]) if not status.empty and pd.notna(status.iloc[-1]) else None
        fault_code = code is not None and code >= 100
        active = bool(zero and (peers_ok or fault_code))
        codes = (inv.electrical_parameters or {}).get("status_codes", {})
        exp_kw = float(e_recent.mean()) if pd.notna(e_recent.mean()) else 0.0
        out.append(
            Condition(
                subject_id=inv.asset_id,
                active=active if (zero or not alert_open(w.session, rule.id, inv.asset_id)) else False,
                title=f"{inv.name} ({inv.asset_id}) not producing while irradiance and peers indicate it should",
                value=None if pd.isna(m_recent) else float(m_recent),
                affected_assets=[inv.asset_id, inv.parent_asset_id],
                evidence={
                    "measured_ac_kw_15min": None if pd.isna(m_recent) else round(float(m_recent), 2),
                    "expected_ac_kw_15min": round(exp_kw, 1),
                    "poa_wm2_15min": round(float(p_recent.mean()), 1),
                    "irradiance_basis": basis,
                    "irradiance_sensors": sensors,
                    "peer_median_index": round(float(np.median(peer_idx)), 3) if peer_idx else None,
                    "status_code": code,
                    "status_text": codes.get(str(code)) if code is not None else None,
                    "observation_ids": w.ids(inv.asset_id, "ac_power")
                    + w.ids(inv.asset_id, "status_code", 2),
                },
                attribution="equipment_failure" if fault_code else "uncertain",
                confidence="high" if fault_code else "medium",
                notes=None
                if fault_code
                else "Zero output without fault code: could be equipment, protection trip or measurement; investigate.",
                energy_at_risk_kwh=round(exp_kw * _remaining_daylight_h(w.site, w.at) * 0.5, 0),
            )
        )
    return out


def eval_underperformance(w: AsOfWindow, rule: AlertRule) -> list[Condition]:
    p = rule.params
    poa, basis, sensors = _poa_basis(w)
    exp = _expected(w, poa)
    curt = _curtailed(w)
    win = w.grid[-int(p["window_min"] / 5) :]
    out = []
    if basis in ("unavailable", "uncertain"):
        return [Condition(i, None, "", notes=f"irradiance basis {basis}") for i in exp]
    for inv in _assets(w.session, w.site.id, "inverter"):
        e = exp.get(inv.asset_id)
        if e is None:
            continue
        meas = w.series(inv.asset_id, "ac_power").reindex(win)
        ee = e.reindex(win)
        pp = e.attrs["poa"].reindex(win)
        curt_mask = pd.Series(False, index=win)
        for c in curt:
            curt_mask |= (win >= pd.Timestamp(c.start_time)) & (win < pd.Timestamp(c.end_time))
        ok = (
            meas.notna()
            & ee.notna()
            & (pp >= p["min_poa_wm2"])
            & ~curt_mask
            & (meas > 0.02 * (inv.rated_capacity or 1))
        )
        is_open = alert_open(w.session, rule.id, inv.asset_id)
        if ok.sum() < p["min_intervals"]:
            out.append(
                Condition(
                    inv.asset_id,
                    None if is_open else False,
                    "",
                    notes="insufficient comparable intervals (low irradiance, curtailment, gaps or outage)",
                )
            )
            continue
        idx = float(meas[ok].sum() / ee[ok].sum())
        thr = p["clear_index"] if is_open else p["trigger_index"]
        active = idx < thr
        peers = []
        for pid, pe in exp.items():
            if pid == inv.asset_id:
                continue
            pm = w.series(pid, "ac_power").reindex(win)
            m2 = ok & pm.notna()
            if m2.sum() >= p["min_intervals"] and pe.reindex(win)[m2].sum() > 0:
                peers.append(float(pm[m2].sum() / pe.reindex(win)[m2].sum()))
        peer_med = float(np.median(peers)) if peers else None
        if active and peer_med is not None and peer_med < thr:
            # whole site low: suspect model/irradiance/weather rather than this inverter
            active = idx < peer_med - 0.06
        out.append(
            Condition(
                inv.asset_id,
                active,
                f"{inv.name} ({inv.asset_id}) producing {idx:.0%} of weather-adjusted expectation",
                value=idx,
                affected_assets=[inv.asset_id, inv.parent_asset_id],
                evidence={
                    "performance_index": round(idx, 3),
                    "threshold_trigger": p["trigger_index"],
                    "threshold_clear": p["clear_index"],
                    "threshold_applied": thr,
                    "peer_indices": [round(x, 3) for x in peers],
                    "peer_median": round(peer_med, 3) if peer_med else None,
                    "comparable_intervals": int(ok.sum()),
                    "irradiance_basis": basis,
                    "irradiance_sensors": sensors,
                    "measured_kwh_window": round(float(meas[ok].sum() * 5 / 60), 2),
                    "expected_kwh_window": round(float(ee[ok].sum() * 5 / 60), 2),
                    "observation_ids": w.ids(inv.asset_id, "ac_power"),
                },
                attribution="uncertain",
                confidence="medium" if peers else "low",
                notes="Underperformance relative to model and peers; cause not yet attributed (soiling, string/fuse loss, "
                "shading, MPPT, or model error).",
                energy_at_risk_kwh=round(
                    float((ee[ok] - meas[ok]).clip(lower=0).mean())
                    * _remaining_daylight_h(w.site, w.at)
                    * 0.5,
                    0,
                ),
            )
        )
    return out


def eval_sensor(w: AsOfWindow, rule: AlertRule) -> list[Condition]:
    p = rule.params
    pyrs = [
        s
        for s in _assets(w.session, w.site.id, "sensor")
        if (s.electrical_parameters or {}).get("sensor_role") in ("primary", "reference")
    ]
    if len(pyrs) < 2:
        return []
    win = w.grid[-int(p["window_min"] / 5) :]
    out = []
    a, b = pyrs[0], pyrs[1]
    sa = w.series(a.asset_id, "poa_irradiance", good_only=False).reindex(win)
    sb = w.series(b.asset_id, "poa_irradiance", good_only=False).reindex(win)
    m = (sa > p["min_poa_wm2"]) | (sb > p["min_poa_wm2"])
    for s, other in ((a, b), (b, a)):
        fl = w.flags(s.asset_id, "poa_irradiance")
        recent_fl = fl[-6:]
        stuck = bool(recent_fl) and sum(1 for f in recent_fl if "stuck_value" in (f or [])) >= 3
        diff = None
        if m.sum() >= 3:
            x, y = (sa, sb) if s is a else (sb, sa)
            diff = float((abs(x[m] - y[m]) / ((x[m] + y[m]) / 2).clip(lower=1)).median())
        if not m.any() and not stuck:
            out.append(
                Condition(s.asset_id, None if alert_open(w.session, rule.id, s.asset_id) else False, "")
            )
            continue
        active = stuck or (diff is not None and diff > p["max_rel_diff"] and _less_trusted(s, other, w))
        out.append(
            Condition(
                s.asset_id,
                active,
                f"{s.name} ({s.asset_id}) {'output frozen (stuck value)' if stuck else 'disagrees with reference sensor'}",
                value=diff,
                affected_assets=[s.asset_id],
                evidence={
                    "stuck_flags_recent": sum(1 for f in recent_fl if "stuck_value" in (f or [])),
                    "median_relative_difference": round(diff, 3) if diff is not None else None,
                    "compared_with": other.asset_id,
                    "threshold": p["max_rel_diff"],
                    "observation_ids": w.ids(s.asset_id, "poa_irradiance")
                    + w.ids(other.asset_id, "poa_irradiance", 3),
                },
                attribution="sensor_fault",
                confidence="high" if stuck else "medium",
                notes="Irradiance-dependent metrics use the remaining valid sensor; PR is withheld while sensors disagree.",
            )
        )
    return out


def _less_trusted(s: Asset, other: Asset, w: AsOfWindow) -> bool:
    fs = sum(1 for f in w.flags(s.asset_id, "poa_irradiance") if f)
    fo = sum(1 for f in w.flags(other.asset_id, "poa_irradiance") if f)
    return fs >= fo


def eval_temperature(w: AsOfWindow, rule: AlertRule) -> list[Condition]:
    p = rule.params
    out = []
    checks = [
        ("inverter", "inverter_temperature", p["inverter_max_c"]),
        ("battery_system", "battery_temperature", p["battery_max_c"]),
    ]
    for atype, mt, lim in checks:
        for a in _assets(w.session, w.site.id, atype):
            s = w.series(a.asset_id, mt).dropna().tail(3)
            if s.empty:
                continue
            v = float(s.mean())
            out.append(
                Condition(
                    a.asset_id,
                    v > lim,
                    f"{a.name} temperature {v:.1f} °C above {lim} °C",
                    value=v,
                    affected_assets=[a.asset_id],
                    evidence={
                        "mean_last_15min_c": round(v, 1),
                        "limit_c": lim,
                        "observation_ids": w.ids(a.asset_id, mt, 3),
                    },
                    attribution="equipment_condition",
                    confidence="medium",
                )
            )
    for a in _assets(w.session, w.site.id, "sensor"):
        if (a.electrical_parameters or {}).get("sensor_role") != "module_temp":
            continue
        s = w.series(a.asset_id, "module_temperature").dropna().tail(3)
        if not s.empty:
            v = float(s.mean())
            out.append(
                Condition(
                    a.asset_id,
                    v > p["module_max_c"],
                    f"Module temperature {v:.1f} °C",
                    value=v,
                    affected_assets=[a.asset_id],
                    evidence={"mean_last_15min_c": round(v, 1), "limit_c": p["module_max_c"]},
                    attribution="equipment_condition",
                )
            )
    return out


def eval_meter(w: AsOfWindow, rule: AlertRule) -> list[Condition]:
    p = rule.params
    out = []
    for m in _assets(w.session, w.site.id, "meter"):
        win = w.grid[-int(p["window_min"] / 5) :]
        s = w.series(m.asset_id, "export_energy").reindex(win)
        cov = float(s.notna().mean()) if len(win) else 0.0
        others_fresh = any(
            (w.at - t).total_seconds() < 900 for a, t in w.last_seen.items() if a != m.asset_id
        )
        out.append(
            Condition(
                m.asset_id,
                cov < p["min_coverage"],
                f"Settlement meter {m.asset_id} data coverage {cov:.0%} in last hour",
                value=cov,
                affected_assets=[m.asset_id],
                evidence={
                    "coverage": round(cov, 3),
                    "required": p["min_coverage"],
                    "other_sources_fresh": others_fresh,
                },
                attribution="communication_loss" if others_fresh else "site_disconnected",
                confidence="medium",
                severity="critical",
            )
        )
    return out


def eval_maintenance(w: AsOfWindow, rule: AlertRule) -> list[Condition]:
    from sun_king.maintenance.models import MaintenanceSchedule

    today = local_date(w.at, w.site.timezone)
    out = []
    for s in w.session.scalars(
        select(MaintenanceSchedule).where(
            MaintenanceSchedule.site_id == w.site.id, MaintenanceSchedule.active.is_(True)
        )
    ):
        overdue = (today - s.next_due).days - rule.params.get("grace_days", 0)
        out.append(
            Condition(
                s.id,
                overdue > 0,
                f"Overdue: {s.title} (due {s.next_due.isoformat()})",
                value=overdue,
                affected_assets=[s.asset_id] if s.asset_id else [],
                evidence={
                    "next_due": s.next_due.isoformat(),
                    "days_overdue": overdue,
                    "interval_days": s.interval_days,
                    "source": s.source,
                },
                attribution="maintenance",
                confidence="high",
            )
        )
    return out


def eval_status(w: AsOfWindow, rule: AlertRule) -> list[Condition]:
    codes = rule.params.get("codes", {})
    out = []
    for inv in _assets(w.session, w.site.id, "inverter"):
        s = w.series(inv.asset_id, "status_code", good_only=False, resample=False).dropna()
        if s.empty:
            continue
        c = str(int(s.iloc[-1]))
        txt = (inv.electrical_parameters or {}).get("status_codes", {}).get(c, "unknown code")
        out.append(
            Condition(
                inv.asset_id,
                c in codes,
                f"{inv.asset_id} status {c}: {txt}",
                value=float(c),
                affected_assets=[inv.asset_id],
                severity=codes.get(c),
                evidence={
                    "status_code": int(c),
                    "status_text": txt,
                    "configured_codes": codes,
                    "observation_ids": w.ids(inv.asset_id, "status_code", 3),
                },
                attribution="equipment_failure" if c in codes else "none",
                confidence="high",
            )
        )
    return out


EVALUATORS: dict[str, Callable[[AsOfWindow, AlertRule], list[Condition]]] = {
    "stale_telemetry": eval_stale,
    "inverter_outage": eval_outage,
    "underperformance": eval_underperformance,
    "sensor_disagreement": eval_sensor,
    "abnormal_temperature": eval_temperature,
    "missing_meter_data": eval_meter,
    "maintenance_overdue": eval_maintenance,
    "equipment_status": eval_status,
}


def alert_open(session: Session, rule_id: str, subject_id: str) -> bool:
    st = session.get(AlertConditionState, (rule_id, subject_id))
    if st is None or st.active_alert_id is None:
        return False
    a = session.get(Alert, st.active_alert_id)
    return bool(a and a.condition_active)


def _suppressed(
    session: Session, site_id: str, subject: str, rule_type: str, at: datetime
) -> Suppression | None:
    for s in session.scalars(
        select(Suppression).where(
            Suppression.site_id == site_id, Suppression.start_time <= at, Suppression.end_time > at
        )
    ):
        if (s.asset_id in (None, subject)) and (not s.alert_types or rule_type in s.alert_types):
            return s
    return None


def evaluate_site(
    session: Session, site_id: str, at: datetime, on_change: Callable[[Alert, str], None] | None = None
) -> dict:
    site = session.get(Site, site_id)
    w = AsOfWindow(session, site, at)
    summary = {
        "site_id": site_id,
        "at": at.isoformat(),
        "created": [],
        "cleared": [],
        "suppressed": [],
        "not_evaluable": 0,
    }
    stale_inverters = set()
    rules = sorted(active_rules(session, site_id), key=lambda r: 0 if r.rule_type == "stale_telemetry" else 1)
    for rule in rules:
        conds = EVALUATORS[rule.rule_type](w, rule)
        for c in conds:
            if rule.rule_type == "stale_telemetry" and c.active:
                stale_inverters.add(c.subject_id)
            if rule.rule_type in ("inverter_outage", "underperformance") and c.subject_id in stale_inverters:
                c.active = None  # stale telemetry is reported separately, never as a failure
            _apply(session, site, rule, c, at, summary, on_change)
    return summary


def _apply(session, site, rule, c: Condition, at, summary, on_change):
    st = session.get(AlertConditionState, (rule.id, c.subject_id))
    if st is None:
        st = AlertConditionState(rule_id=rule.id, subject_id=c.subject_id)
        session.add(st)
    st.last_evaluated = at
    st.last_value = c.value
    alert = session.get(Alert, st.active_alert_id) if st.active_alert_id else None
    if c.active is None:
        summary["not_evaluable"] += 1
        if alert:
            alert.last_evaluated_at = at
            alert.evidence = {
                **(alert.evidence or {}),
                "last_evaluation_note": c.notes or "inputs inadequate",
            }
        return
    if c.active:
        st.clearing_since = None
        if st.pending_since is None:
            st.pending_since = at
        if alert is None:
            if (at - st.pending_since).total_seconds() >= rule.persistence_s:
                sup = _suppressed(session, site.id, c.subject_id, rule.rule_type, at)
                if sup:
                    summary["suppressed"].append(c.subject_id)
                    return
                sev = c.severity or rule.severity
                alert = Alert(
                    id=new_id("alr"),
                    site_id=site.id,
                    rule_id=rule.id,
                    rule_version=rule.version,
                    rule_params=rule.params,
                    threshold_source=rule.threshold_source,
                    alert_type=rule.rule_type,
                    severity=sev,
                    title=c.title,
                    subject_id=c.subject_id,
                    affected_assets=[a for a in c.affected_assets if a],
                    status="detected",
                    condition_active=True,
                    attribution=c.attribution,
                    attribution_confidence=c.confidence,
                    attribution_notes=c.notes,
                    evidence={
                        **c.evidence,
                        "persistence_s": rule.persistence_s,
                        "config_version": rule.version,
                    },
                    first_detected_at=at,
                    condition_started_at=st.pending_since,
                    last_evaluated_at=at,
                    energy_at_risk_kwh=c.energy_at_risk_kwh,
                    priority_score=priority(sev, c.confidence, c.energy_at_risk_kwh),
                )
                session.add(alert)
                session.flush()
                session.add(
                    AlertEvent(
                        alert_id=alert.id,
                        at=at,
                        event="detected",
                        to_status="detected",
                        note=f"Rule {rule.id} v{rule.version}: condition held {rule.persistence_s}s",
                        data={"value": c.value},
                    )
                )
                st.active_alert_id = alert.id
                summary["created"].append(alert.id)
                if on_change:
                    on_change(alert, "created")
        else:
            if not alert.condition_active:
                alert.condition_active = True
                alert.condition_cleared_at = None
                session.add(AlertEvent(alert_id=alert.id, at=at, event="condition_returned"))
            alert.last_evaluated_at = at
            alert.evidence = {
                **c.evidence,
                "persistence_s": rule.persistence_s,
                "config_version": rule.version,
                "first_evidence": (alert.evidence or {}).get("first_evidence") or alert.evidence,
            }
            if c.notes:
                alert.attribution_notes = c.notes
            alert.attribution_confidence = c.confidence
            if c.energy_at_risk_kwh is not None:
                alert.energy_at_risk_kwh = c.energy_at_risk_kwh
                alert.priority_score = priority(alert.severity, c.confidence, c.energy_at_risk_kwh)
    else:
        st.pending_since = None
        if alert and alert.condition_active:
            if st.clearing_since is None:
                st.clearing_since = at
            if (at - st.clearing_since).total_seconds() >= rule.clear_persistence_s:
                alert.condition_active = False
                alert.condition_cleared_at = at
                alert.last_evaluated_at = at
                session.add(
                    AlertEvent(
                        alert_id=alert.id,
                        at=at,
                        event="condition_cleared",
                        note="Underlying condition no longer present (hysteresis satisfied). "
                        "Workflow status unchanged — resolution/verification still required.",
                    )
                )
                summary["cleared"].append(alert.id)
                if on_change:
                    on_change(alert, "cleared")
        if alert and alert.status == "verified":
            st.active_alert_id = None


def priority(severity: str, confidence: str, energy_kwh: float | None) -> float:
    """Transparent investigation priority: severity × confidence × (1 + log10(1 + energy at risk))."""
    import math

    return round(
        SEV_WEIGHT.get(severity, 1)
        * CONF_WEIGHT.get(confidence, 0.5)
        * (1 + math.log10(1 + (energy_kwh or 0))),
        3,
    )


def replay(
    session: Session,
    site_id: str,
    start: datetime,
    end: datetime,
    step_min: int = 15,
    daylight_only: bool = True,
) -> int:
    site = session.get(Site, site_id)
    times = pd.date_range(start, end, freq=f"{step_min}min")
    if daylight_only:
        el = pvmodel.solar_elevation(site.latitude, site.longitude, times)
        keep = el > -3
        # keep a sparse night cadence for staleness checks
        keep |= (times.minute == 0) & (times.hour % 3 == 0)
        times = times[keep]
    for t in times:
        evaluate_site(session, site_id, t.to_pydatetime())
    session.flush()
    return len(times)


def last_day(d: date) -> date:  # pragma: no cover - helper for docs
    return d
