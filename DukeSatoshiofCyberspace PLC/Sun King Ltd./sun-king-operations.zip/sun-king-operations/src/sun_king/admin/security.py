"""Authentication (organisational accounts, JWT bearer tokens) and site-scoped authorisation.

Organisational SSO (OIDC) is supported by configuration: when
``SUN_KING_OIDC_ISSUER`` is set, ``/api/auth/oidc/callback`` is the intended
integration point (deferred: requires the organisation's IdP metadata). Local
password accounts use bcrypt.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import bcrypt
import jwt
from sqlalchemy import select
from sqlalchemy.orm import Session

from sun_king.admin.models import ROLE_RANK, AuditLog, SiteRole, User
from sun_king.assets.models import Site
from sun_king.config import get_settings


def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt(rounds=10)).decode()


def verify_password(pw: str, hashed: str | None) -> bool:
    if not hashed:
        return False
    try:
        return bcrypt.checkpw(pw.encode(), hashed.encode())
    except ValueError:
        return False


def create_token(user: User, ttl_minutes: int | None = None) -> str:
    s = get_settings()
    now = datetime.now(UTC)
    payload = {
        "sub": user.id,
        "org": user.organisation_id,
        "iat": now,
        "exp": now + timedelta(minutes=ttl_minutes or s.token_ttl_minutes),
        "typ": "access",
    }
    if user.is_service_account:
        payload["scope"] = user.service_scope
    return jwt.encode(payload, s.secret_key, algorithm="HS256")


def decode_token(token: str) -> dict:
    return jwt.decode(
        token, get_settings().secret_key, algorithms=["HS256"], options={"require": ["exp", "sub"]}
    )


def site_role(session: Session, user: User, site_id: str) -> str | None:
    if user.org_role == "admin":
        return "admin"
    sr = session.get(SiteRole, (user.id, site_id))
    return sr.role if sr else None


def has_site_role(session: Session, user: User, site_id: str, min_role: str) -> bool:
    r = site_role(session, user, site_id)
    return r is not None and ROLE_RANK[r] >= ROLE_RANK[min_role]


def permitted_sites(session: Session, user: User, min_role: str = "viewer") -> list[str]:
    if user.org_role == "admin":
        return [s for (s,) in session.execute(select(Site.id).order_by(Site.id))]
    rows = session.scalars(select(SiteRole).where(SiteRole.user_id == user.id)).all()
    return sorted(r.site_id for r in rows if ROLE_RANK[r.role] >= ROLE_RANK[min_role])


def audit(
    session: Session,
    actor: str | None,
    action: str,
    entity_type: str,
    entity_id: str,
    site_id: str | None = None,
    detail: dict | None = None,
    ip: str | None = None,
) -> None:
    session.add(
        AuditLog(
            actor_id=actor,
            action=action,
            entity_type=entity_type,
            entity_id=str(entity_id),
            site_id=site_id,
            detail=detail or {},
            client_ip=ip,
        )
    )
