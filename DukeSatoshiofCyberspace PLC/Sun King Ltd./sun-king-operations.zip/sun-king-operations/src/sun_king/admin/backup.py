"""Logical backup and tested restoration.

Format: gzip-compressed JSON lines. The first line is a manifest (format
version, schema revision, table order, created time). Each table section
starts with a header line and ends with a footer carrying the row count and
a SHA-256 over the canonical JSON of its rows. Restore verifies every
checksum before committing and refuses to restore into a non-empty database.

This complements, and does not replace, physical PostgreSQL backups
(``pg_dump``/PITR, see ``scripts/backup.sh``).
"""

from __future__ import annotations

import base64
import gzip
import hashlib
import json
from datetime import date, datetime
from pathlib import Path

from sqlalchemy import func, insert, select, text
from sqlalchemy.orm import Session

from sun_king.core.db import Base, UTCDateTime

FORMAT = "sun-king-backup/1"
SKIP = {"alembic_version", "spatial_ref_sys"}
CHUNK = 5000


def _enc(v):
    if isinstance(v, datetime):
        return {"$dt": v.isoformat()}
    if isinstance(v, date):
        return {"$d": v.isoformat()}
    if isinstance(v, bytes):
        return {"$b": base64.b64encode(v).decode()}
    return v


def _dec(v, col):
    if isinstance(v, dict) and len(v) == 1:
        k = next(iter(v))
        if k == "$dt":
            return datetime.fromisoformat(v[k])
        if k == "$d":
            return date.fromisoformat(v[k])
        if k == "$b":
            return base64.b64decode(v[k])
    return v


def _tables():
    import sun_king.models  # noqa: F401

    return [t for t in Base.metadata.sorted_tables if t.name not in SKIP]


def backup(session: Session, path: str) -> dict:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tables = _tables()
    total = 0
    with gzip.open(p, "wt", encoding="utf-8") as f:
        f.write(
            json.dumps(
                {
                    "format": FORMAT,
                    "created": datetime.now().astimezone().isoformat(),
                    "tables": [t.name for t in tables],
                    "dialect": session.bind.dialect.name,
                }
            )
            + "\n"
        )
        for t in tables:
            f.write(json.dumps({"table": t.name}) + "\n")
            h = hashlib.sha256()
            n = 0
            pk = list(t.primary_key.columns)
            stmt = select(*[t.c[c.name] for c in t.columns]).order_by(*pk)
            for row in session.execute(stmt).yield_per(CHUNK):
                rec = {c.name: _enc(v) for c, v in zip(t.columns, row, strict=True)}
                line = json.dumps(rec, sort_keys=True, default=str)
                h.update(line.encode())
                f.write(line + "\n")
                n += 1
            f.write(json.dumps({"end": t.name, "rows": n, "sha256": h.hexdigest()}) + "\n")
            total += n
    digest = hashlib.sha256(p.read_bytes()).hexdigest()
    return {"path": str(p), "tables": len(tables), "rows": total, "file_sha256": digest, "format": FORMAT}


def restore(session: Session, path: str) -> dict:
    tables = {t.name: t for t in _tables()}
    for t in tables.values():
        if session.scalar(select(func.count()).select_from(t)):
            raise RuntimeError(f"refusing to restore: table {t.name} is not empty")
    pg = session.bind.dialect.name == "postgresql"
    if pg:
        session.execute(text("SET LOCAL sun_king.allow_raw_maintenance = 'on'"))
    counts = {}
    with gzip.open(path, "rt", encoding="utf-8") as f:
        manifest = json.loads(f.readline())
        if manifest.get("format") != FORMAT:
            raise RuntimeError("unsupported backup format")
        cur = None
        buf: list[dict] = []
        h = hashlib.sha256()
        n = 0
        for line in f:
            obj = json.loads(line)
            if cur is None:
                cur = tables[obj["table"]]
                h, n, buf = hashlib.sha256(), 0, []
                continue
            if "end" in obj and set(obj) == {"end", "rows", "sha256"}:
                if buf:
                    session.execute(insert(cur), _parents_first(cur, buf))
                if obj["rows"] != n or obj["sha256"] != h.hexdigest():
                    raise RuntimeError(f"checksum/row-count mismatch in table {cur.name}")
                counts[cur.name] = n
                cur = None
                continue
            h.update(json.dumps(obj, sort_keys=True, default=str).encode())
            n += 1
            row = {}
            for c in cur.columns:
                v = _dec(obj.get(c.name), c)
                if isinstance(c.type, UTCDateTime) and isinstance(v, datetime) and v.tzinfo is None:
                    from datetime import UTC

                    v = v.replace(tzinfo=UTC)
                row[c.name] = v
            buf.append(row)
            if len(buf) >= CHUNK and not _self_fk(cur):
                session.execute(insert(cur), buf)
                buf = []
    if pg:
        # keep sequences ahead of restored integer keys
        for t in tables.values():
            for c in t.primary_key.columns:
                if c.autoincrement is True or (c.autoincrement == "auto" and c.type.python_type is int):
                    session.execute(
                        text(
                            f"SELECT setval(pg_get_serial_sequence('{t.name}', '{c.name}'), "
                            f"COALESCE((SELECT MAX({c.name}) FROM {t.name}), 1))"
                        )
                    )
    session.flush()
    return {"restored_tables": len(counts), "rows": sum(counts.values()), "counts": counts}


def _self_fk(table):
    return [fk for fk in table.foreign_keys if fk.column.table is table]


def _parents_first(table, rows: list[dict]) -> list[dict]:
    """Order rows of a self-referencing table (e.g. the asset hierarchy) so parents precede children."""
    fks = _self_fk(table)
    if not fks:
        return rows
    child_col, parent_col = fks[0].parent.name, fks[0].column.name
    done: set = set()
    out: list[dict] = []
    pending = rows
    while pending:
        nxt = [r for r in pending if r[child_col] is None or r[child_col] in done]
        if not nxt:
            raise RuntimeError(f"cycle or dangling reference in {table.name}")
        out.extend(nxt)
        done.update(r[parent_col] for r in nxt)
        pending = [r for r in pending if not (r[child_col] is None or r[child_col] in done) or r not in nxt]
        pending = [r for r in pending if r not in out]
    return out
