"""Identity, site-scoped permissions, audit history, job queue and adapter configuration."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from sun_king.core.db import Base, JSONType, UTCDateTime
from sun_king.core.timeutil import utcnow

ROLES = ("viewer", "field_technician", "operator", "engineer", "manager", "admin")
ROLE_RANK = {r: i for i, r in enumerate(ROLES)}


class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    organisation_id: Mapped[str] = mapped_column(ForeignKey("organisations.id"))
    email: Mapped[str] = mapped_column(String(200), unique=True)
    display_name: Mapped[str] = mapped_column(String(200))
    password_hash: Mapped[str | None] = mapped_column(String(200))  # None for SSO-only accounts
    org_role: Mapped[str] = mapped_column(String(32), default="viewer")  # admin => all sites
    is_service_account: Mapped[bool] = mapped_column(Boolean, default=False)
    service_scope: Mapped[str | None] = mapped_column(String(64))  # e.g. "ingest"
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class SiteRole(Base):
    __tablename__ = "site_roles"
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), primary_key=True)
    role: Mapped[str] = mapped_column(String(32))


class AuditLog(Base):
    __tablename__ = "audit_log"
    __table_args__ = (Index("ix_audit_entity", "entity_type", "entity_id"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, index=True)
    actor_id: Mapped[str | None] = mapped_column(String(64))
    action: Mapped[str] = mapped_column(String(64))
    entity_type: Mapped[str] = mapped_column(String(64))
    entity_id: Mapped[str] = mapped_column(String(120))
    site_id: Mapped[str | None] = mapped_column(String(64))
    detail: Mapped[dict] = mapped_column(JSONType, default=dict)
    client_ip: Mapped[str | None] = mapped_column(String(64))


class Job(Base):
    """Durable background job with lease-based recovery and a retry budget."""

    __tablename__ = "jobs"
    __table_args__ = (Index("ix_jobs_ready", "status", "run_after"),)
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    kind: Mapped[str] = mapped_column(String(64))
    payload: Mapped[dict] = mapped_column(JSONType, default=dict)
    idempotency_key: Mapped[str | None] = mapped_column(String(160), unique=True)
    status: Mapped[str] = mapped_column(String(16), default="queued")  # queued|running|done|failed
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, default=5)
    run_after: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    lease_expires: Mapped[datetime | None] = mapped_column(UTCDateTime)
    worker_id: Mapped[str | None] = mapped_column(String(64))
    last_error: Mapped[str | None] = mapped_column(Text)
    result: Mapped[dict | None] = mapped_column(JSONType)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(UTCDateTime)


class AdapterConfig(Base):
    """Configured data adapter. Credentials are referenced by name, never stored here."""

    __tablename__ = "adapter_configs"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    kind: Mapped[str] = mapped_column(String(48))  # inverter_monitoring | site_meter | weather_station | ...
    implementation: Mapped[str] = mapped_column(String(64))  # simulator | csv_import | <vendor>_http
    site_id: Mapped[str | None] = mapped_column(ForeignKey("sites.id"))
    enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    mode: Mapped[str] = mapped_column(String(16), default="simulated")  # simulated | live
    endpoint: Mapped[str | None] = mapped_column(String(300))
    credential_ref: Mapped[str | None] = mapped_column(String(120))  # env var / secret name
    allowed_hosts: Mapped[list] = mapped_column(JSONType, default=list)
    poll_interval_s: Mapped[int] = mapped_column(Integer, default=300)
    retry_budget: Mapped[int] = mapped_column(Integer, default=5)
    verified_documentation_ref: Mapped[str | None] = mapped_column(String(300))
    settings: Mapped[dict] = mapped_column(JSONType, default=dict)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
