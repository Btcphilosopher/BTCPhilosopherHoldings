"""Forecasts, storage, commercial, reports, administration and live WebSocket."""

from __future__ import annotations

import asyncio
import json
from datetime import date, datetime, timedelta

import jwt
from fastapi import (
    APIRouter,
    Depends,
    File,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
    WebSocket,
    WebSocketDisconnect,
)
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from sun_king.admin.models import ROLES, AdapterConfig, AuditLog, Job, SiteRole, User
from sun_king.admin.security import audit, decode_token, hash_password, permitted_sites
from sun_king.api.deps import client_ip, get_db, human_user, require_org_admin, require_site, sites_for
from sun_king.api.routes_ops import _row
from sun_king.api.util import parse_window
from sun_king.assets.models import Asset, Site
from sun_king.commercial.models import CommercialScenario, Contract, PricePoint, SettlementStatement
from sun_king.commercial.service import cost_summary, estimated_value, lost_revenue_estimate, reconciliation
from sun_king.config import get_settings
from sun_king.core.db import session_factory
from sun_king.core.ids import new_id
from sun_king.core.timeutil import local_date, local_day_bounds, utcnow
from sun_king.forecasting.models import Forecast, ForecastValue, ModelRegistryEntry
from sun_king.reporting.models import Report
from sun_king.storage.models import StorageScenario

router = APIRouter(prefix="/api")


# ------------------------------------------------------------------ forecasts
def _fc(f: Forecast, values=None) -> dict:
    d = _row(f)
    if values is not None:
        d["values"] = [
            {
                "t": v.target_time.isoformat(),
                "p10_kw": v.p10_kw,
                "p50_kw": v.p50_kw,
                "p90_kw": v.p90_kw,
                "persistence_kw": v.baseline_persistence_kw,
                "nwp_physical_kw": v.baseline_weather_kw,
            }
            for v in values
        ]
    return d


@router.get("/forecasts", tags=["forecasts"])
def list_forecasts(
    site_id: str, kind: str | None = None, user: User = Depends(human_user), db: Session = Depends(get_db)
):
    require_site(db, user, site_id)
    stmt = select(Forecast).where(Forecast.site_id == site_id)
    if kind:
        stmt = stmt.where(Forecast.kind == kind)
    return [_fc(f) for f in db.scalars(stmt.order_by(Forecast.issue_time.desc()).limit(50))]


@router.get("/forecasts/evaluation", tags=["forecasts"])
def forecast_evaluation(site_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, site_id)
    code = db.get(Site, site_id).code
    rows = db.scalars(
        select(ModelRegistryEntry)
        .where(ModelRegistryEntry.name.like(f"%_{code}"))
        .order_by(ModelRegistryEntry.trained_at.desc())
    ).all()
    return [_row(r) for r in rows]


@router.get("/forecasts/{forecast_id}", tags=["forecasts"])
def get_forecast(forecast_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    f = db.get(Forecast, forecast_id)
    if f is None:
        raise HTTPException(404, "forecast not found")
    require_site(db, user, f.site_id)
    vals = db.scalars(
        select(ForecastValue)
        .where(ForecastValue.forecast_id == forecast_id)
        .order_by(ForecastValue.target_time)
    ).all()
    d = _fc(f, vals)
    # actuals (only for elapsed targets) for comparison
    from sun_king.forecasting.features import load_history

    if f.target_start < utcnow():
        h = load_history(db, f.site_id, f.target_start, min(f.target_end, utcnow()))
        act = {t.isoformat(): (None if v != v else round(float(v), 2)) for t, v in h.pv_kw.items()}
        for v in d["values"]:
            v["actual_kw"] = act.get(v["t"])
    return d


class IssueIn(BaseModel):
    site_id: str
    horizon_type: str = Field("day_ahead", pattern=r"^(intraday|day_ahead)$")


@router.post("/forecasts/issue", tags=["forecasts"], status_code=201)
def issue(body: IssueIn, request: Request, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, body.site_id, "engineer")
    from sun_king.forecasting.service import ForecastModelError, issue_forecast, train_and_evaluate

    app = request.app
    site = db.get(Site, body.site_id)
    now = utcnow()
    try:
        r = train_and_evaluate(db, site, app.state.nwp, now - timedelta(days=13), now, body.horizon_type)
    except ForecastModelError as e:
        raise HTTPException(409, f"model training failed: {e}") from e
    f = issue_forecast(db, site, app.state.nwp, now, r["model"], body.horizon_type)
    vals = db.scalars(
        select(ForecastValue).where(ForecastValue.forecast_id == f.id).order_by(ForecastValue.target_time)
    ).all()
    audit(db, user.id, "forecast_issued", "forecast", f.id, site.id, {"horizon_type": body.horizon_type})
    return {**_fc(f, vals), "evaluation": r["evaluation"]}


# ------------------------------------------------------------------ storage
@router.get("/storage/sites/{site_id}", tags=["storage"])
def storage_site(
    site_id: str,
    start: datetime | None = None,
    end: datetime | None = None,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    require_site(db, user, site_id)
    start, end = parse_window(start, end, default_hours=48, max_days=14)
    batt = db.scalar(select(Asset).where(Asset.site_id == site_id, Asset.asset_type == "battery_system"))
    if batt is None:
        return {"site_id": site_id, "battery": None, "note": "No battery system registered at this site."}
    from sun_king.telemetry.query import frame, latest_values

    mts = [
        "battery_soc",
        "battery_power",
        "battery_available_energy",
        "battery_max_charge_power",
        "battery_max_discharge_power",
        "battery_temperature",
        "battery_state",
    ]
    out = {}
    for mt in mts:
        df = frame(db, [batt.asset_id], mt, start, end, resample="15min")
        out[mt] = (
            [
                {"t": t.isoformat(), "v": None if v != v else round(float(v), 4)}
                for t, v in df[batt.asset_id].items()
            ]
            if batt.asset_id in df
            else []
        )
    lat = [v for v in latest_values(db, site_id) if v["asset_id"] == batt.asset_id]
    total = sum(len(v) for v in out.values())
    good = sum(1 for v in out.values() for p in v if p["v"] is not None)
    return {
        "site_id": site_id,
        "battery": {"asset_id": batt.asset_id, "name": batt.name, **(batt.electrical_parameters or {})},
        "integration": "read_only — no commands are issued",
        "latest": lat,
        "series": out,
        "communication_quality": {
            "interval_coverage": round(good / total, 3) if total else None,
            "window": [start.isoformat(), end.isoformat()],
        },
    }


class StorageScenarioIn(BaseModel):
    site_id: str
    day: date | None = None
    soc_initial: float = Field(0.3, ge=0, le=1)
    pv_only_charging: bool = True
    apply_export_limit: bool = True
    energy_kwh: float | None = Field(None, gt=0, le=1e6)
    power_kw: float | None = Field(None, gt=0, le=1e6)
    round_trip_efficiency: float | None = Field(None, gt=0, le=1)
    name: str = Field("Storage schedule comparison", max_length=200)


@router.post("/storage/scenarios", tags=["storage"], status_code=201)
def storage_scenario(
    body: StorageScenarioIn, user: User = Depends(human_user), db: Session = Depends(get_db)
):
    require_site(db, user, body.site_id, "engineer")
    import numpy as np

    from sun_king.forecasting.features import load_history
    from sun_king.storage.scenario import BatteryParams, compare

    site = db.get(Site, body.site_id)
    batt = db.scalar(select(Asset).where(Asset.site_id == body.site_id, Asset.asset_type == "battery_system"))
    if batt is None:
        raise HTTPException(422, "no battery at this site")
    ep = batt.electrical_parameters or {}
    day = body.day or (local_date(utcnow(), site.timezone) - timedelta(days=1))
    s, e = local_day_bounds(day, site.timezone)
    h = load_history(db, body.site_id, s, e)
    pv = h.pv_kw.fillna(0).clip(lower=0).to_numpy()
    c = db.scalar(select(Contract).where(Contract.site_id == body.site_id))
    prices = db.scalars(
        select(PricePoint)
        .where(
            PricePoint.series_id == (c.price_series_id if c else None),
            PricePoint.start_time >= s,
            PricePoint.start_time < e,
        )
        .order_by(PricePoint.start_time)
    ).all()
    if len(prices) != len(pv):
        raise HTTPException(409, f"price series has {len(prices)} intervals, expected {len(pv)}")
    params = BatteryParams(
        energy_kwh=body.energy_kwh or ep["energy_kwh"],
        power_kw=body.power_kw or ep["power_kw"],
        round_trip_efficiency=body.round_trip_efficiency or ep["round_trip_efficiency"],
        soc_min=ep["soc_min"],
        soc_max=ep["soc_max"],
        soc_initial=body.soc_initial,
        pv_only_charging=body.pv_only_charging,
        export_limit_kw=site.export_limit_kw if body.apply_export_limit else None,
    )
    res = compare(
        np.array([p.price_per_mwh for p in prices]), pv, 0.5, params, prices[0].currency, prices[0].source
    )
    res["pv_input"] = {
        "basis": "measured site PV AC (sum of inverters), 30-min means",
        "day": day.isoformat(),
        "missing_intervals": int(h.pv_kw.isna().sum()),
        "pv_kw": [round(float(x), 1) for x in pv],
    }
    res["times"] = [t.isoformat() for t in h.pv_kw.index]
    res["prices"] = [p.price_per_mwh for p in prices]
    sc = StorageScenario(
        id=new_id("sto"),
        site_id=body.site_id,
        battery_asset_id=batt.asset_id,
        name=body.name,
        inputs=body.model_dump(mode="json"),
        results=res,
        created_by=user.id,
    )
    db.add(sc)
    db.flush()
    return {"id": sc.id, **res}


# ------------------------------------------------------------------ commercial
@router.get("/commercial/sites/{site_id}", tags=["commercial"])
def commercial(
    site_id: str,
    start_day: date | None = None,
    end_day: date | None = None,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    require_site(db, user, site_id, "viewer")
    site = db.get(Site, site_id)
    end_day = end_day or local_date(utcnow(), site.timezone) - timedelta(days=1)
    start_day = start_day or end_day - timedelta(days=6)
    if (end_day - start_day).days > 62:
        raise HTTPException(422, "period too long")
    return {
        "site_id": site_id,
        "separation": [
            "measured_export",
            "estimated_value",
            "contract",
            "settlement_statements",
            "receipts",
            "maintenance_costs",
            "scenarios",
        ],
        "estimated_value": estimated_value(db, site_id, start_day, end_day),
        "contracts": [_row(c) for c in db.scalars(select(Contract).where(Contract.site_id == site_id))],
        "reconciliation": reconciliation(db, site_id),
        "maintenance_costs": cost_summary(db, site_id, start_day - timedelta(days=60), end_day),
        "scenarios": [
            _row(s)
            for s in db.scalars(select(CommercialScenario).where(CommercialScenario.site_id == site_id))
        ],
    }


class LostRevenueIn(BaseModel):
    site_id: str
    start: datetime
    end: datetime
    use_model_baseline: bool = True
    price_per_mwh: float | None = Field(None, gt=0)
    currency: str | None = Field(None, pattern=r"^[A-Z]{3}$")
    price_source: str | None = Field(None, max_length=200)


@router.post("/commercial/lost-revenue", tags=["commercial"])
def lost_revenue(body: LostRevenueIn, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, body.site_id, "engineer")
    s, e = parse_window(body.start, body.end, max_days=31)
    baseline = method = measured = None
    if body.use_model_baseline:
        from sun_king.performance.analysis import run_site_model

        run = run_site_model(db, body.site_id, s, e)
        if run.basis.status in ("ok", "single_sensor"):
            exp = sum(ex["ac_kw"].fillna(0) for ex in run.expected.values())
            meas = run.measured_ac.sum(axis=1, min_count=len(run.expected))
            ok = meas.notna()
            baseline = float(exp[ok].sum() / 12)
            measured = float(meas[ok].sum() / 12)
            method = f"pvlib expected AC from measured irradiance ({run.basis.status}); intervals with all inverters reporting"
    out = lost_revenue_estimate(
        db,
        body.site_id,
        s,
        e,
        baseline,
        method,
        body.price_per_mwh,
        body.currency,
        body.price_source,
        measured,
    )
    if out["status"] == "estimate":
        db.add(
            CommercialScenario(
                id=new_id("csc"),
                site_id=body.site_id,
                scenario_type="lost_revenue",
                inputs=body.model_dump(mode="json"),
                results=out,
            )
        )
    return out


@router.post("/commercial/statements/import", tags=["commercial"])
async def import_statements(
    site_id: str,
    file: UploadFile = File(...),
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    require_site(db, user, site_id, "manager")
    from sun_king.adapters.csv_import import ImportError_, SettlementCSVAdapter

    s = get_settings()
    content = await file.read(s.max_upload_bytes + 1)
    if len(content) > s.max_upload_bytes:
        raise HTTPException(413, "file too large")
    try:
        rows = SettlementCSVAdapter().parse(content, s.max_import_rows)
    except ImportError_ as e:
        raise HTTPException(422, str(e)) from e
    created, skipped = [], []
    for r in rows:
        c = db.get(Contract, r["contract_id"])
        if c is None or c.site_id != site_id:
            raise HTTPException(422, f"contract {r['contract_id']} not on site {site_id}")
        if r["currency"] != c.currency:
            raise HTTPException(
                422, f"statement currency {r['currency']} differs from contract currency {c.currency}"
            )
        if db.scalar(
            select(SettlementStatement).where(SettlementStatement.statement_ref == r["statement_ref"])
        ):
            skipped.append(r["statement_ref"])
            continue
        st = SettlementStatement(id=new_id("stm"), site_id=site_id, source="csv_import", **r)
        db.add(st)
        created.append(st.id)
    audit(
        db,
        user.id,
        "statements_imported",
        "site",
        site_id,
        site_id,
        {"created": len(created), "duplicates": skipped},
    )
    return {"created": created, "duplicates_skipped": skipped}


# ------------------------------------------------------------------ reports
class ReportIn(BaseModel):
    start_day: date
    end_day: date
    site_ids: list[str] | None = None


@router.post("/reports/operational", tags=["reports"], status_code=201)
def make_report(body: ReportIn, user: User = Depends(human_user), db: Session = Depends(get_db)):
    if (body.end_day - body.start_day).days > 31 or body.end_day < body.start_day:
        raise HTTPException(422, "report period must be 1–31 days")
    ids = body.site_ids or sites_for(db, user)
    for sid in ids:
        require_site(db, user, sid)
    from sun_king.reporting.report import operational_report

    pf = db.get(Site, ids[0]).portfolio_id
    rep = operational_report(db, pf, ids, body.start_day, body.end_day, user.id)
    audit(db, user.id, "report_generated", "report", rep.id, None, {"sites": ids})
    return {
        "id": rep.id,
        "sha256": rep.content_sha256,
        "links": {f: f"/api/reports/{rep.id}.{f}" for f in ("json", "html", "csv")},
    }


@router.get("/reports", tags=["reports"])
def list_reports(user: User = Depends(human_user), db: Session = Depends(get_db)):
    allowed = set(sites_for(db, user))
    out = []
    for r in db.scalars(select(Report).order_by(Report.generated_at.desc()).limit(50)):
        sids = {s["site_id"] for s in r.content.get("sites", [])}
        if sids <= allowed:
            out.append(
                {
                    "id": r.id,
                    "type": r.report_type,
                    "generated_at": r.generated_at.isoformat(),
                    "period_start": r.period_start.isoformat(),
                    "period_end": r.period_end.isoformat(),
                    "sha256": r.content_sha256,
                    "sites": sorted(sids),
                }
            )
    return out


@router.get("/reports/{report_id}.{fmt}", tags=["reports"])
def get_report(report_id: str, fmt: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    r = db.get(Report, report_id)
    if r is None:
        raise HTTPException(404, "report not found")
    for s in r.content.get("sites", []):
        require_site(db, user, s["site_id"])
    from sun_king.reporting.report import to_csv, to_html

    if fmt == "json":
        return Response(
            json.dumps(r.content, indent=1),
            media_type="application/json",
            headers={"Content-Disposition": f'attachment; filename="{report_id}.json"'},
        )
    if fmt == "html":
        return Response(to_html(r), media_type="text/html")
    if fmt == "csv":
        return Response(
            to_csv(r),
            media_type="text/csv",
            headers={"Content-Disposition": f'attachment; filename="{report_id}.csv"'},
        )
    raise HTTPException(404, "format must be json, html or csv")


# ------------------------------------------------------------------ admin
@router.get("/admin/users", tags=["admin"])
def users(user: User = Depends(require_org_admin), db: Session = Depends(get_db)):
    out = []
    for u in db.scalars(select(User).order_by(User.id)):
        out.append(
            {
                "id": u.id,
                "email": u.email,
                "display_name": u.display_name,
                "org_role": u.org_role,
                "active": u.active,
                "service_account": u.is_service_account,
                "site_roles": {
                    r.site_id: r.role for r in db.scalars(select(SiteRole).where(SiteRole.user_id == u.id))
                },
            }
        )
    return out


class UserIn(BaseModel):
    email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$", max_length=200)
    display_name: str = Field(max_length=200)
    password: str = Field(min_length=12, max_length=200)
    org_role: str = "viewer"
    site_roles: dict[str, str] = Field(default_factory=dict)


@router.post("/admin/users", tags=["admin"], status_code=201)
def create_user(
    body: UserIn, request: Request, admin: User = Depends(require_org_admin), db: Session = Depends(get_db)
):
    if body.org_role not in ("viewer", "admin") or any(r not in ROLES for r in body.site_roles.values()):
        raise HTTPException(422, "invalid role")
    if db.scalar(select(User).where(User.email == body.email.lower())):
        raise HTTPException(409, "email exists")
    u = User(
        id=new_id("u"),
        organisation_id=admin.organisation_id,
        email=body.email.lower(),
        display_name=body.display_name,
        password_hash=hash_password(body.password),
        org_role=body.org_role,
    )
    db.add(u)
    db.flush()
    for sid, role in body.site_roles.items():
        if db.get(Site, sid) is None:
            raise HTTPException(422, f"unknown site {sid}")
        db.add(SiteRole(user_id=u.id, site_id=sid, role=role))
    audit(
        db,
        admin.id,
        "user_created",
        "user",
        u.id,
        None,
        {"email": u.email, "site_roles": body.site_roles},
        client_ip(request),
    )
    return {"id": u.id}


@router.get("/admin/audit", tags=["admin"])
def audit_log(
    limit: int = Query(200, le=2000),
    entity_id: str | None = None,
    user: User = Depends(require_org_admin),
    db: Session = Depends(get_db),
):
    stmt = select(AuditLog).order_by(AuditLog.at.desc()).limit(limit)
    if entity_id:
        stmt = stmt.where(AuditLog.entity_id == entity_id)
    return [_row(a) for a in db.scalars(stmt)]


@router.get("/admin/adapters", tags=["admin"])
def adapters(user: User = Depends(require_org_admin), db: Session = Depends(get_db)):
    s = get_settings()
    return {
        "live_adapters_enabled": s.live_adapters_enabled,
        "policy": "Read-only adapters only. No discovery or probing; live use requires verified documentation, explicit allowed "
        "hosts and deployment-level enablement.",
        "adapters": [
            {
                **_row(a),
                "credential_ref": a.credential_ref,
                "credential_present": bool(
                    a.credential_ref and __import__("os").environ.get(a.credential_ref)
                ),
            }
            for a in db.scalars(select(AdapterConfig))
        ],
    }


@router.get("/admin/jobs", tags=["admin"])
def jobs(user: User = Depends(require_org_admin), db: Session = Depends(get_db)):
    return [_row(j) for j in db.scalars(select(Job).order_by(Job.created_at.desc()).limit(100))]


@router.post("/admin/backup", tags=["admin"])
def make_backup(request: Request, user: User = Depends(require_org_admin), db: Session = Depends(get_db)):
    from sun_king.admin.backup import backup

    path = (
        get_settings().object_store_path.parent
        / "backups"
        / f"backup-{utcnow().strftime('%Y%m%dT%H%M%SZ')}.json.gz"
    )
    res = backup(db, str(path))
    audit(db, user.id, "backup_created", "backup", path.name, None, res, client_ip(request))
    return res


class OutageIn(BaseModel):
    site_id: str
    minutes: int = Field(ge=0, le=240)


@router.post("/admin/simulator/outage", tags=["admin"])
def sim_outage(
    body: OutageIn, request: Request, user: User = Depends(require_org_admin), db: Session = Depends(get_db)
):
    """Demo control: stop the simulated monitoring link for a site (0 minutes restores it)."""
    plant = request.app.state.plant
    now = utcnow()
    if body.minutes == 0:
        plant.disconnected_until.pop(body.site_id, None)
    else:
        plant.disconnected_until[body.site_id] = (now, now + timedelta(minutes=body.minutes))
    db.merge(
        AdapterConfig(
            id="sim-all",
            kind="simulator",
            implementation="simulator",
            enabled=True,
            mode="simulated",
            settings={
                **(db.get(AdapterConfig, "sim-all").settings or {}),
                "outages": {
                    k: [a.isoformat(), b.isoformat()] for k, (a, b) in plant.disconnected_until.items()
                },
            },
        )
    )
    audit(db, user.id, "simulator_outage", "site", body.site_id, body.site_id, {"minutes": body.minutes})
    return {
        "site_id": body.site_id,
        "disconnected_until": (now + timedelta(minutes=body.minutes)).isoformat() if body.minutes else None,
    }


@router.get("/health", tags=["admin"])
def health(db: Session = Depends(get_db)):
    from sun_king.telemetry.models import StreamState

    newest = db.scalar(select(func.max(StreamState.last_ingestion_time)))
    return {
        "status": "ok",
        "database": db.bind.dialect.name,
        "newest_ingestion": newest.isoformat() if newest else None,
        "time": utcnow().isoformat(),
    }


# ------------------------------------------------------------------ websocket
ws_router = APIRouter()


@ws_router.websocket("/ws/live")
async def live(ws: WebSocket, token: str = Query(...)):
    """Pushes per-site freshness, current power and alert counts every 5 s when anything changes.

    Messages are derived from the database (not from worker memory), so the
    worker and API can run in separate processes. Cached values are sent with
    their observation time and age; clients must not present them as current
    when ``is_current`` is false.
    """
    try:
        claims = decode_token(token)
    except jwt.PyJWTError:
        await ws.close(code=4401)
        return
    await ws.accept()
    last = None
    try:
        while True:
            with session_factory()() as db:
                user = db.get(User, claims["sub"])
                if user is None or user.is_service_account:
                    await ws.close(code=4403)
                    return
                msg = snapshot(db, permitted_sites(db, user))
            key = json.dumps(msg["fingerprint"])
            if key != last:
                await ws.send_json(msg)
                last = key
            await asyncio.sleep(5)
    except WebSocketDisconnect:
        return


def snapshot(db: Session, site_ids: list[str]) -> dict:
    from sun_king.alerts.models import Alert
    from sun_king.assets.service import meter_for_role
    from sun_king.telemetry.models import StreamState

    now = utcnow()
    stale = get_settings().stale_after_seconds
    sites = []
    fp = []
    for sid in site_ids:
        newest = db.scalar(
            select(func.max(StreamState.last_observation_time)).where(StreamState.site_id == sid)
        )
        meter = meter_for_role(db, sid, "export_settlement")
        st = db.get(StreamState, (meter, "ac_power", "simulator")) if meter else None
        if st is None and meter:
            st = db.scalar(
                select(StreamState).where(
                    StreamState.asset_id == meter, StreamState.measurement_type == "ac_power"
                )
            )
        n_alerts = (
            db.scalar(
                select(func.count())
                .select_from(Alert)
                .where(Alert.site_id == sid, Alert.condition_active.is_(True))
            )
            or 0
        )
        age = (now - newest).total_seconds() if newest else None
        sites.append(
            {
                "site_id": sid,
                "newest_observation": newest.isoformat() if newest else None,
                "age_s": age,
                "is_current": age is not None and age <= stale,
                "export_kw": None
                if st is None
                else {
                    "value": st.last_value,
                    "observation_time": st.last_observation_time.isoformat(),
                    "is_current": (now - st.last_observation_time).total_seconds() <= stale,
                },
                "active_alerts": n_alerts,
            }
        )
        fp.append([sid, newest.isoformat() if newest else None, n_alerts, age is not None and age <= stale])
    return {"type": "snapshot", "at": now.isoformat(), "sites": sites, "fingerprint": fp}
