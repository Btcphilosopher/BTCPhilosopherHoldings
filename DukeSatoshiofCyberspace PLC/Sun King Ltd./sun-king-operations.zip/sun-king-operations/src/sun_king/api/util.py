from __future__ import annotations

from datetime import datetime, timedelta

from fastapi import HTTPException

from sun_king.core.timeutil import ensure_utc, utcnow

MAX_WINDOW_DAYS = 62


def parse_window(
    start: datetime | None, end: datetime | None, default_hours: int = 24, max_days: int = MAX_WINDOW_DAYS
) -> tuple[datetime, datetime]:
    try:
        end = ensure_utc(end) if end else utcnow()
        start = ensure_utc(start) if start else end - timedelta(hours=default_hours)
    except ValueError as e:
        raise HTTPException(422, str(e)) from e
    if end <= start:
        raise HTTPException(422, "end must be after start")
    if end - start > timedelta(days=max_days):
        raise HTTPException(422, f"window longer than {max_days} days")
    return start, end
