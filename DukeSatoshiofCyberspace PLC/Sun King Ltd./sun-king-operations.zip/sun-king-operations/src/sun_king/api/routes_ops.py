"""Performance, alerts, maintenance, inspections and curtailment endpoints."""

from __future__ import annotations

from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, Response, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from sun_king.admin.models import User
from sun_king.admin.security import audit, has_site_role
from sun_king.alerts.engine import evaluate_site
from sun_king.alerts.models import Alert, AlertEvent, AlertRule, Suppression
from sun_king.alerts.workflow import WorkflowError, acknowledge, transition, verify_recovery
from sun_king.api.deps import client_ip, get_db, human_user, require_site, sites_for
from sun_king.api.util import parse_window
from sun_king.config import get_settings
from sun_king.core.ids import new_id
from sun_king.core.timeutil import ensure_utc, utcnow
from sun_king.energy.models import CurtailmentRecord
from sun_king.maintenance.models import (
    CleaningRecord,
    Contractor,
    Defect,
    Evidence,
    InspectionRecord,
    InspectionTemplate,
    MaintenanceSchedule,
    PartUsage,
    SparePart,
    VegetationRecord,
    WorkOrder,
    WorkOrderEvent,
)
from sun_king.maintenance.service import (
    MaintenanceError,
    SyncConflict,
    create_work_order,
    record_part_usage,
    store_evidence,
    sync_inspection,
    transition_work_order,
)
from sun_king.performance.analysis import (
    availability,
    expected_vs_measured,
    inverter_comparison,
    loss_breakdown,
    performance_ratio,
    run_site_model,
    specific_yield,
)

router = APIRouter(prefix="/api")


def _row(o) -> dict:
    out = {}
    for c in o.__table__.columns:
        v = getattr(o, c.name)
        out[c.name] = v.isoformat() if isinstance(v, datetime | date) else v
    return out


# ------------------------------------------------------------------ performance
@router.get("/performance/sites/{site_id}", tags=["performance"])
def performance(
    site_id: str,
    start: datetime | None = None,
    end: datetime | None = None,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    require_site(db, user, site_id)
    start, end = parse_window(start, end, default_hours=24 * 7, max_days=31)
    run = run_site_model(db, site_id, start, end)
    pr_inv = {
        i: performance_ratio(db, site_id, start, end, run, scope=i).to_dict()
        for i in run.expected
        if run.coplanar.get(i)
    }
    return {
        "site_id": site_id,
        "window": {"start": start.isoformat(), "end": end.isoformat()},
        "specific_yield": specific_yield(db, site_id, start, end).to_dict(),
        "performance_ratio": performance_ratio(db, site_id, start, end, run).to_dict(),
        "performance_ratio_by_inverter": pr_inv,
        "inverters": inverter_comparison(db, site_id, start, end, run),
        "availability": {i: availability(run, i).to_dict() for i in run.expected},
        "losses": loss_breakdown(db, site_id, start, end, run),
        "definitions": "docs/performance.md",
    }


@router.get("/performance/sites/{site_id}/expected", tags=["performance"])
def expected(
    site_id: str,
    start: datetime | None = None,
    end: datetime | None = None,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    require_site(db, user, site_id)
    start, end = parse_window(start, end, max_days=7)
    return expected_vs_measured(db, site_id, start, end)


class CleaningBenefitIn(BaseModel):
    site_id: str
    cleaned_on: date
    window_days: int = Field(5, ge=2, le=21)


@router.post("/performance/cleaning-benefit", tags=["performance"])
def cleaning_benefit_ep(
    body: CleaningBenefitIn, user: User = Depends(human_user), db: Session = Depends(get_db)
):
    require_site(db, user, body.site_id)
    from sun_king.performance.cleaning import cleaning_benefit

    return cleaning_benefit(db, body.site_id, body.cleaned_on, body.window_days)


class CleaningScenarioIn(BaseModel):
    site_id: str
    expected_energy_kwh_per_day: float = Field(gt=0, le=1e7)
    soiling_loss_fraction: float = Field(ge=0, lt=0.5)
    loss_uncertainty: float = Field(0.01, ge=0, le=0.2)
    benefit_days: int = Field(30, ge=1, le=365)
    cleaning_cost: float = Field(ge=0)
    price_per_mwh: float = Field(gt=0)
    currency: str = Field("GBP", pattern=r"^[A-Z]{3}$")
    constraints: list[str] = Field(default_factory=list, max_length=20)


@router.post("/performance/cleaning-scenario", tags=["performance"])
def cleaning_scenario_ep(
    body: CleaningScenarioIn, user: User = Depends(human_user), db: Session = Depends(get_db)
):
    require_site(db, user, body.site_id)
    from sun_king.performance.cleaning import cleaning_scenario

    return cleaning_scenario(
        body.expected_energy_kwh_per_day,
        body.soiling_loss_fraction,
        body.loss_uncertainty,
        body.benefit_days,
        body.cleaning_cost,
        body.price_per_mwh,
        body.currency,
        body.constraints,
    )


# ------------------------------------------------------------------ alerts
def _alert(a: Alert, events=None) -> dict:
    d = _row(a)
    d["acknowledged"] = a.acknowledged_at is not None
    if events is not None:
        d["events"] = [_row(e) for e in events]
    return d


@router.get("/alerts", tags=["alerts"])
def list_alerts(
    site_id: str | None = None,
    status: str | None = None,
    active: bool | None = None,
    include_verified: bool = False,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    ids = sites_for(db, user)
    if site_id:
        require_site(db, user, site_id)
        ids = [site_id]
    stmt = select(Alert).where(Alert.site_id.in_(ids))
    if status:
        stmt = stmt.where(Alert.status == status)
    elif not include_verified:
        stmt = stmt.where(Alert.status != "verified")
    if active is not None:
        stmt = stmt.where(Alert.condition_active.is_(active))
    rows = db.scalars(
        stmt.order_by(
            Alert.condition_active.desc(),
            Alert.priority_score.desc().nulls_last(),
            Alert.first_detected_at.desc(),
        )
    ).all()
    return [_alert(a) for a in rows]


@router.get("/alerts/priorities", tags=["alerts"])
def priorities(user: User = Depends(human_user), db: Session = Depends(get_db)):
    from sun_king.ml.patterns import prioritise

    return prioritise(db, sites_for(db, user))


@router.get("/alerts/rules", tags=["alerts"])
def rules(user: User = Depends(human_user), db: Session = Depends(get_db)):
    return [_row(r) for r in db.scalars(select(AlertRule).order_by(AlertRule.id, AlertRule.version))]


class RuleUpdate(BaseModel):
    params: dict
    persistence_s: int | None = Field(None, ge=0, le=86400)
    clear_persistence_s: int | None = Field(None, ge=0, le=86400)
    threshold_source: str = Field(min_length=5, max_length=200)
    enabled: bool = True


@router.post("/alerts/rules/{rule_id}/versions", tags=["alerts"], status_code=201)
def new_rule_version(
    rule_id: str,
    body: RuleUpdate,
    request: Request,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    if user.org_role != "admin" and not sites_for(db, user, "manager"):
        raise HTTPException(403, "manager role required")
    cur = db.scalar(select(AlertRule).where(AlertRule.id == rule_id, AlertRule.active_version.is_(True)))
    if cur is None:
        raise HTTPException(404, "rule not found")
    unknown = set(body.params) - set(cur.params)
    if unknown:
        raise HTTPException(422, f"unknown parameters {sorted(unknown)}")
    cur.active_version = False
    new = AlertRule(
        id=rule_id,
        version=cur.version + 1,
        rule_type=cur.rule_type,
        name=cur.name,
        site_id=cur.site_id,
        severity=cur.severity,
        params={**cur.params, **body.params},
        persistence_s=body.persistence_s if body.persistence_s is not None else cur.persistence_s,
        clear_persistence_s=body.clear_persistence_s
        if body.clear_persistence_s is not None
        else cur.clear_persistence_s,
        threshold_source=body.threshold_source,
        enabled=body.enabled,
        active_version=True,
        created_by=user.id,
    )
    db.add(new)
    audit(
        db,
        user.id,
        "alert_rule_versioned",
        "alert_rule",
        f"{rule_id}:v{new.version}",
        None,
        {"from": cur.params, "to": new.params},
        client_ip(request),
    )
    db.flush()
    return _row(new)


@router.get("/alerts/{alert_id}", tags=["alerts"])
def get_alert(alert_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    a = db.get(Alert, alert_id)
    if a is None:
        raise HTTPException(404, "alert not found")
    require_site(db, user, a.site_id)
    ev = db.scalars(select(AlertEvent).where(AlertEvent.alert_id == alert_id).order_by(AlertEvent.at)).all()
    d = _alert(a, ev)
    d["work_orders"] = [w.id for w in db.scalars(select(WorkOrder).where(WorkOrder.alert_id == alert_id))]
    d["evidence_links"] = [f"/api/telemetry/raw/{m}" for m in (a.evidence or {}).get("observation_ids", [])]
    return d


class AckIn(BaseModel):
    note: str | None = Field(None, max_length=2000)


@router.post("/alerts/{alert_id}/acknowledge", tags=["alerts"])
def ack(alert_id: str, body: AckIn, user: User = Depends(human_user), db: Session = Depends(get_db)):
    a = db.get(Alert, alert_id)
    if a is None:
        raise HTTPException(404, "alert not found")
    require_site(db, user, a.site_id, "field_technician")
    acknowledge(db, a, user.id, body.note)
    return _alert(a)


class TransitionIn(BaseModel):
    to_status: str
    note: str | None = Field(None, max_length=4000)
    assignee: str | None = None
    force_reason: str | None = Field(None, max_length=2000)


@router.post("/alerts/{alert_id}/transition", tags=["alerts"])
def alert_transition(
    alert_id: str,
    body: TransitionIn,
    request: Request,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    a = db.get(Alert, alert_id)
    if a is None:
        raise HTTPException(404, "alert not found")
    require_site(
        db,
        user,
        a.site_id,
        "engineer"
        if body.to_status in ("resolved", "verified")
        else "operator"
        if body.to_status == "assigned"
        else "field_technician",
    )
    try:
        transition(db, a, body.to_status, user.id, body.note, body.assignee, body.force_reason)
    except WorkflowError as e:
        raise HTTPException(409, str(e)) from e
    audit(
        db,
        user.id,
        f"alert_{body.to_status}",
        "alert",
        alert_id,
        a.site_id,
        body.model_dump(),
        client_ip(request),
    )
    return _alert(a)


class VerifyIn(BaseModel):
    after: datetime | None = None
    work_order_id: str | None = None
    min_hours: float = Field(1.5, ge=0.5, le=48)


@router.post("/alerts/{alert_id}/verify", tags=["alerts"])
def alert_verify(
    alert_id: str,
    body: VerifyIn,
    request: Request,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    """Run the post-maintenance recovery check; on pass, move the alert to *verified*."""
    a = db.get(Alert, alert_id)
    if a is None:
        raise HTTPException(404, "alert not found")
    require_site(db, user, a.site_id, "engineer")
    wo = db.get(WorkOrder, body.work_order_id) if body.work_order_id else None
    after = ensure_utc(body.after) if body.after else (wo.completed_at if wo and wo.completed_at else None)
    if after is None:
        raise HTTPException(422, "provide 'after' or a completed work order")
    target = a.subject_id
    result = verify_recovery(db, a.site_id, target, after, min_hours=body.min_hours)
    if wo:
        wo.verification = result
    if result["passed"]:
        path = {
            "detected": ["investigating", "resolved"],
            "assigned": ["investigating", "resolved"],
            "investigating": ["resolved"],
            "action_planned": ["resolved"],
            "resolved": [],
        }
        try:
            for st in path.get(a.status, []):
                transition(db, a, st, user.id, "stepped by recovery verification")
            transition(
                db, a, "verified", user.id, "post-maintenance performance verified", verification=result
            )
        except WorkflowError as e:
            result["workflow_error"] = str(e)
    audit(
        db,
        user.id,
        "recovery_verification",
        "alert",
        alert_id,
        a.site_id,
        {"passed": result["passed"], "reason": result.get("reason")},
        client_ip(request),
    )
    return {"alert": _alert(a), "verification": result}


@router.post("/alerts/evaluate", tags=["alerts"])
def evaluate_now(site_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, site_id, "operator")
    return evaluate_site(db, site_id, utcnow())


class SuppressionIn(BaseModel):
    site_id: str
    asset_id: str | None = None
    alert_types: list[str] = Field(default_factory=list)
    start_time: datetime
    end_time: datetime
    reason: str = Field(min_length=5, max_length=2000)


@router.post("/alerts/suppressions", tags=["alerts"], status_code=201)
def add_suppression(body: SuppressionIn, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, body.site_id, "engineer")
    s, e = ensure_utc(body.start_time), ensure_utc(body.end_time)
    if e <= s or e - s > timedelta(days=14):
        raise HTTPException(422, "suppression window must be positive and ≤ 14 days")
    sup = Suppression(
        id=new_id("sup"),
        site_id=body.site_id,
        asset_id=body.asset_id,
        alert_types=body.alert_types,
        start_time=s,
        end_time=e,
        reason=body.reason,
        created_by=user.id,
    )
    db.add(sup)
    audit(
        db, user.id, "suppression_created", "suppression", sup.id, body.site_id, body.model_dump(mode="json")
    )
    return _row(sup)


@router.get("/alerts/suppressions/list", tags=["alerts"])
def list_suppressions(site_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, site_id)
    return [_row(s) for s in db.scalars(select(Suppression).where(Suppression.site_id == site_id))]


# ------------------------------------------------------------------ maintenance
class WorkOrderIn(BaseModel):
    site_id: str
    title: str = Field(min_length=3, max_length=300)
    work_type: str = Field(pattern=r"^(corrective|preventive|inspection|cleaning|vegetation)$")
    description: str | None = Field(None, max_length=8000)
    priority: str = Field("medium", pattern=r"^(low|medium|high|urgent)$")
    asset_ids: list[str] = Field(default_factory=list, max_length=200)
    alert_id: str | None = None
    due_date: date | None = None
    contractor_id: str | None = None
    schedule_id: str | None = None


@router.get("/maintenance/work-orders", tags=["maintenance"])
def list_wos(
    site_id: str | None = None,
    status: str | None = None,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    ids = sites_for(db, user)
    if site_id:
        require_site(db, user, site_id)
        ids = [site_id]
    stmt = select(WorkOrder).where(WorkOrder.site_id.in_(ids))
    if status:
        stmt = stmt.where(WorkOrder.status == status)
    return [_row(w) for w in db.scalars(stmt.order_by(WorkOrder.created_at.desc()))]


@router.post("/maintenance/work-orders", tags=["maintenance"], status_code=201)
def new_wo(
    body: WorkOrderIn, request: Request, user: User = Depends(human_user), db: Session = Depends(get_db)
):
    require_site(db, user, body.site_id, "operator")
    if body.alert_id:
        a = db.get(Alert, body.alert_id)
        if a is None or a.site_id != body.site_id:
            raise HTTPException(422, "alert not on this site")
    wo = create_work_order(db, created_by=user.id, **body.model_dump())
    audit(
        db,
        user.id,
        "work_order_created",
        "work_order",
        wo.id,
        wo.site_id,
        body.model_dump(mode="json"),
        client_ip(request),
    )
    return _row(wo)


@router.get("/maintenance/work-orders/{wo_id}", tags=["maintenance"])
def get_wo(wo_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    wo = db.get(WorkOrder, wo_id)
    if wo is None:
        raise HTTPException(404, "work order not found")
    require_site(db, user, wo.site_id)
    d = _row(wo)
    d["events"] = [
        _row(e)
        for e in db.scalars(
            select(WorkOrderEvent).where(WorkOrderEvent.work_order_id == wo_id).order_by(WorkOrderEvent.at)
        )
    ]
    d["evidence"] = [
        _row(e)
        for e in db.scalars(
            select(Evidence).where(Evidence.entity_type == "work_order", Evidence.entity_id == wo_id)
        )
    ]
    d["inspections"] = [
        _row(i) for i in db.scalars(select(InspectionRecord).where(InspectionRecord.work_order_id == wo_id))
    ]
    d["parts"] = [_row(p) for p in db.scalars(select(PartUsage).where(PartUsage.work_order_id == wo_id))]
    d["defects"] = [_row(x) for x in db.scalars(select(Defect).where(Defect.work_order_id == wo_id))]
    return d


class WoTransitionIn(BaseModel):
    to_status: str
    note: str | None = Field(None, max_length=4000)
    assigned_to: str | None = None
    contractor_id: str | None = None
    completion_notes: str | None = Field(None, max_length=8000)
    repair_summary: str | None = Field(None, max_length=8000)
    permit_reference: str | None = Field(None, max_length=120)
    at: datetime | None = None


@router.post("/maintenance/work-orders/{wo_id}/transition", tags=["maintenance"])
def wo_transition(
    wo_id: str,
    body: WoTransitionIn,
    request: Request,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    wo = db.get(WorkOrder, wo_id)
    if wo is None:
        raise HTTPException(404, "work order not found")
    need = {
        "reviewed": "engineer",
        "signed_off": "manager",
        "assigned": "operator",
        "scheduled": "operator",
        "cancelled": "operator",
    }
    require_site(db, user, wo.site_id, need.get(body.to_status, "field_technician"))
    try:
        transition_work_order(
            db,
            wo,
            body.to_status,
            user.id,
            body.note,
            at=ensure_utc(body.at) if body.at else None,
            assigned_to=body.assigned_to,
            contractor_id=body.contractor_id,
            completion_notes=body.completion_notes,
            repair_summary=body.repair_summary,
            permit_reference=body.permit_reference,
        )
    except MaintenanceError as e:
        raise HTTPException(409, str(e)) from e
    audit(
        db,
        user.id,
        f"work_order_{body.to_status}",
        "work_order",
        wo_id,
        wo.site_id,
        body.model_dump(mode="json"),
        client_ip(request),
    )
    return _row(wo)


class PartUseIn(BaseModel):
    part_id: str
    quantity: int = Field(gt=0, le=1000)


@router.post("/maintenance/work-orders/{wo_id}/parts", tags=["maintenance"])
def wo_parts(wo_id: str, body: PartUseIn, user: User = Depends(human_user), db: Session = Depends(get_db)):
    wo = db.get(WorkOrder, wo_id)
    if wo is None:
        raise HTTPException(404, "work order not found")
    require_site(db, user, wo.site_id, "field_technician")
    try:
        pu = record_part_usage(db, wo, body.part_id, body.quantity, user.id)
    except MaintenanceError as e:
        raise HTTPException(409, str(e)) from e
    db.flush()
    return _row(pu)


@router.post("/maintenance/evidence", tags=["maintenance"], status_code=201)
async def upload_evidence(
    site_id: str = Form(...),
    entity_type: str = Form(..., pattern=r"^(work_order|inspection|defect|asset)$"),
    entity_id: str = Form(..., max_length=64),
    caption: str | None = Form(None, max_length=2000),
    captured_at: datetime | None = Form(None),
    kind: str = Form("photo", pattern=r"^(photo|document|manual|completion)$"),
    file: UploadFile = File(...),
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    require_site(db, user, site_id, "field_technician")
    s = get_settings()
    data = await file.read(s.max_upload_bytes + 1)
    from sun_king.adapters.object_store import get_object_store

    try:
        ev = store_evidence(
            db,
            get_object_store(),
            site_id=site_id,
            entity_type=entity_type,
            entity_id=entity_id,
            data=data,
            filename=file.filename or "upload",
            content_type=file.content_type or "application/octet-stream",
            user_id=user.id,
            caption=caption,
            captured_at=ensure_utc(captured_at) if captured_at else None,
            kind=kind,
            max_bytes=s.max_upload_bytes,
        )
    except MaintenanceError as e:
        raise HTTPException(422, str(e)) from e
    audit(
        db,
        user.id,
        "evidence_uploaded",
        entity_type,
        entity_id,
        site_id,
        {"evidence_id": ev.id, "sha256": ev.sha256},
    )
    return _row(ev)


@router.get("/maintenance/evidence/{evidence_id}", tags=["maintenance"])
def get_evidence(evidence_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    ev = db.get(Evidence, evidence_id)
    if ev is None:
        raise HTTPException(404, "evidence not found")
    require_site(db, user, ev.site_id)
    from sun_king.adapters.object_store import get_object_store

    data = get_object_store().get(ev.object_key)
    return Response(
        content=data,
        media_type=ev.content_type,
        headers={
            "Content-Disposition": f'inline; filename="{ev.filename}"',
            "X-Content-SHA256": ev.sha256,
            "X-Content-Type-Options": "nosniff",
        },
    )


@router.get("/maintenance/templates", tags=["maintenance"])
def templates(user: User = Depends(human_user), db: Session = Depends(get_db)):
    return [_row(t) for t in db.scalars(select(InspectionTemplate))]


class InspectionSyncIn(BaseModel):
    client_draft_id: str = Field(min_length=8, max_length=64)
    template_id: str
    site_id: str
    work_order_id: str | None = None
    asset_id: str | None = None
    answers: dict
    status: str = Field("draft", pattern=r"^(draft|submitted)$")
    captured_at: datetime
    device_id: str | None = Field(None, max_length=64)
    base_version: int | None = None
    resolution: str | None = Field(None, pattern=r"^(keep_client|keep_server)$")


@router.post("/maintenance/inspections/sync", tags=["maintenance"])
def inspection_sync(
    body: InspectionSyncIn,
    response: Response,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    require_site(db, user, body.site_id, "field_technician")
    payload = body.model_dump()
    payload["captured_at"] = ensure_utc(body.captured_at)
    if payload["captured_at"] > utcnow() + timedelta(minutes=5):
        raise HTTPException(422, "captured_at is in the future")
    try:
        rec, outcome = sync_inspection(db, payload, user.id)
    except SyncConflict as c:
        response.status_code = 409
        return {
            "conflict": True,
            "server": _row(c.server),
            "message": "Server copy changed since this draft was based on it. Resend with resolution=keep_client or keep_server.",
        }
    except MaintenanceError as e:
        raise HTTPException(422, str(e)) from e
    audit(
        db,
        user.id,
        f"inspection_{outcome}",
        "inspection",
        rec.id,
        rec.site_id,
        {"client_draft_id": rec.client_draft_id},
    )
    return {"conflict": False, "outcome": outcome, "record": _row(rec)}


@router.get("/maintenance/inspections", tags=["maintenance"])
def list_inspections(site_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, site_id)
    return [
        _row(i)
        for i in db.scalars(
            select(InspectionRecord)
            .where(InspectionRecord.site_id == site_id)
            .order_by(InspectionRecord.captured_at.desc())
        )
    ]


class DefectIn(BaseModel):
    site_id: str
    asset_id: str | None = None
    inspection_id: str | None = None
    work_order_id: str | None = None
    category: str = Field(max_length=48)
    severity: str = Field(pattern=r"^(low|medium|high|critical)$")
    description: str = Field(min_length=3, max_length=4000)
    observed_at: datetime


@router.post("/maintenance/defects", tags=["maintenance"], status_code=201)
def add_defect(body: DefectIn, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, body.site_id, "field_technician")
    d = Defect(id=new_id("def"), **{**body.model_dump(), "observed_at": ensure_utc(body.observed_at)})
    db.add(d)
    db.flush()
    return _row(d)


@router.get("/maintenance/summary", tags=["maintenance"])
def maintenance_summary(
    site_id: str | None = None, user: User = Depends(human_user), db: Session = Depends(get_db)
):
    ids = sites_for(db, user)
    if site_id:
        require_site(db, user, site_id)
        ids = [site_id]
    return {
        "schedules": [
            _row(s)
            for s in db.scalars(
                select(MaintenanceSchedule)
                .where(MaintenanceSchedule.site_id.in_(ids))
                .order_by(MaintenanceSchedule.next_due)
            )
        ],
        "spare_parts": [
            {**_row(p), "below_minimum": p.quantity_on_hand < p.minimum_quantity}
            for p in db.scalars(select(SparePart))
        ],
        "contractors": [_row(c) for c in db.scalars(select(Contractor))],
        "cleaning": [
            _row(c) for c in db.scalars(select(CleaningRecord).where(CleaningRecord.site_id.in_(ids)))
        ],
        "vegetation": [
            _row(v) for v in db.scalars(select(VegetationRecord).where(VegetationRecord.site_id.in_(ids)))
        ],
        "defects": [_row(d) for d in db.scalars(select(Defect).where(Defect.site_id.in_(ids)))],
        "safety": "Work orders never certify electrical safety; isolation follows the organisation's authorised procedures.",
    }


class CleaningIn(BaseModel):
    site_id: str
    asset_ids: list[str]
    performed_on: date
    method: str = Field(max_length=64)
    cost: float | None = Field(None, ge=0)
    currency: str = Field("GBP", pattern=r"^[A-Z]{3}$")
    contractor_id: str | None = None
    work_order_id: str | None = None
    notes: str | None = Field(None, max_length=4000)


@router.post("/maintenance/cleaning", tags=["maintenance"], status_code=201)
def add_cleaning(body: CleaningIn, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, body.site_id, "operator")
    c = CleaningRecord(id=new_id("cln"), **body.model_dump())
    db.add(c)
    db.flush()
    return _row(c)


# ------------------------------------------------------------------ curtailment
class CurtailmentIn(BaseModel):
    site_id: str
    start_time: datetime
    end_time: datetime
    limit_kw: float = Field(ge=0)
    instruction_ref: str | None = Field(None, max_length=120)
    issued_by: str = Field(max_length=120)
    reason: str | None = Field(None, max_length=2000)
    compensable: bool | None = None


@router.get("/curtailment", tags=["curtailment"])
def list_curtailment(site_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, site_id)
    return [
        _row(c)
        for c in db.scalars(
            select(CurtailmentRecord)
            .where(CurtailmentRecord.site_id == site_id)
            .order_by(CurtailmentRecord.start_time.desc())
        )
    ]


@router.post("/curtailment", tags=["curtailment"], status_code=201)
def add_curtailment(
    body: CurtailmentIn, request: Request, user: User = Depends(human_user), db: Session = Depends(get_db)
):
    require_site(db, user, body.site_id, "operator")
    s, e = ensure_utc(body.start_time), ensure_utc(body.end_time)
    if e <= s:
        raise HTTPException(422, "end must be after start")
    c = CurtailmentRecord(
        id=new_id("curt"), **{**body.model_dump(), "start_time": s, "end_time": e}, source="api"
    )
    db.add(c)
    audit(
        db,
        user.id,
        "curtailment_recorded",
        "curtailment",
        c.id,
        body.site_id,
        body.model_dump(mode="json"),
        client_ip(request),
    )
    db.flush()
    return _row(c)


def can(db, user, site_id, role):  # pragma: no cover - helper
    return has_site_role(db, user, site_id, role)


def _q(v):  # pragma: no cover
    return Query(v)
