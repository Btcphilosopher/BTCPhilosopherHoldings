"""Auth, portfolio overview, sites, assets, telemetry and energy endpoints."""

from __future__ import annotations

from datetime import date, datetime

from fastapi import APIRouter, Depends, File, HTTPException, Query, Request, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import select, text
from sqlalchemy.orm import Session

from sun_king.admin.models import User
from sun_king.admin.security import audit, create_token, permitted_sites, site_role, verify_password
from sun_king.api.deps import client_ip, current_user, get_db, human_user, require_site, sites_for
from sun_king.api.util import parse_window
from sun_king.assets.models import ASSET_TYPES, Asset, Portfolio, Site
from sun_king.assets.service import (
    asset_dict,
    asset_history,
    connectivity,
    hierarchy,
    monitoring_points,
    search_assets,
)
from sun_king.config import get_settings
from sun_king.core.timeutil import local_date, utcnow
from sun_king.energy.service import daily_completeness, site_energy
from sun_king.reporting.overview import portfolio_overview, site_overview
from sun_king.telemetry.ingest import BatchTooLarge, ingest_batch
from sun_king.telemetry.models import IngestionBatch, RawObservation
from sun_king.telemetry.query import latest_values, raw_for, series
from sun_king.telemetry.schemas import IngestRequest, IngestSummary, ObservationIn

router = APIRouter(prefix="/api")


# ------------------------------------------------------------------ auth
class LoginIn(BaseModel):
    email: str = Field(max_length=200)
    password: str = Field(max_length=200)


@router.post("/auth/login", tags=["auth"])
def login(body: LoginIn, request: Request, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == body.email.lower().strip()))
    if user is None or user.is_service_account or not verify_password(body.password, user.password_hash):
        audit(db, None, "login_failed", "user", body.email[:120], ip=client_ip(request))
        raise HTTPException(401, "invalid credentials")
    audit(db, user.id, "login", "user", user.id, ip=client_ip(request))
    return {"access_token": create_token(user), "token_type": "bearer", "user": _me(db, user)}


def _me(db, user):
    return {
        "id": user.id,
        "email": user.email,
        "display_name": user.display_name,
        "org_role": user.org_role,
        "sites": {s: site_role(db, user, s) for s in permitted_sites(db, user)},
    }


@router.get("/auth/me", tags=["auth"])
def me(user: User = Depends(human_user), db: Session = Depends(get_db)):
    return _me(db, user)


@router.get("/auth/oidc", tags=["auth"])
def oidc_info():
    s = get_settings()
    return {
        "configured": bool(s.oidc_issuer),
        "issuer": s.oidc_issuer,
        "status": "deferred: organisational OIDC sign-in requires the IdP's metadata and client registration",
    }


# ------------------------------------------------------------------ overview / portfolio
@router.get("/overview", tags=["overview"])
def overview(user: User = Depends(human_user), db: Session = Depends(get_db)):
    return portfolio_overview(db, sites_for(db, user))


@router.get("/portfolios", tags=["sites"])
def portfolios(user: User = Depends(human_user), db: Session = Depends(get_db)):
    ids = sites_for(db, user)
    sites = db.scalars(select(Site).where(Site.id.in_(ids))).all()
    pfs = {s.portfolio_id for s in sites}
    return [
        {
            "id": p.id,
            "name": p.name,
            "description": p.description,
            "currency": p.reporting_currency,
            "sites": [s.id for s in sites if s.portfolio_id == p.id],
        }
        for p in db.scalars(select(Portfolio).where(Portfolio.id.in_(pfs)))
    ]


def _site(s: Site) -> dict:
    return {
        "id": s.id,
        "portfolio_id": s.portfolio_id,
        "name": s.name,
        "code": s.code,
        "latitude": s.latitude,
        "longitude": s.longitude,
        "elevation_m": s.elevation_m,
        "timezone": s.timezone,
        "dc_capacity_kwp": s.dc_capacity_kwp,
        "ac_capacity_kw": s.ac_capacity_kw,
        "export_limit_kw": s.export_limit_kw,
        "commissioning_date": s.commissioning_date.isoformat() if s.commissioning_date else None,
        "grid_connection_ref": s.grid_connection_ref,
        "status": s.status,
        "boundary": s.boundary,
        "capacity_note": "DC (module STC), AC (inverter rating) and export limit (grid agreement) are distinct.",
    }


@router.get("/sites", tags=["sites"])
def list_sites(user: User = Depends(human_user), db: Session = Depends(get_db)):
    ids = sites_for(db, user)
    return [_site(s) for s in db.scalars(select(Site).where(Site.id.in_(ids)).order_by(Site.id))]


class SiteIn(BaseModel):
    id: str = Field(pattern=r"^[a-z0-9-]{3,64}$")
    portfolio_id: str
    name: str = Field(max_length=200)
    code: str = Field(pattern=r"^[A-Z0-9]{2,8}$")
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    elevation_m: float = Field(default=0, ge=-500, le=6000)
    timezone: str = "Europe/London"
    dc_capacity_kwp: float = Field(gt=0, le=2_000_000)
    ac_capacity_kw: float = Field(gt=0, le=2_000_000)
    export_limit_kw: float = Field(gt=0, le=2_000_000)
    commissioning_date: date | None = None


@router.post("/sites", tags=["sites"], status_code=201)
def register_site(
    body: SiteIn, request: Request, user: User = Depends(human_user), db: Session = Depends(get_db)
):
    if user.org_role != "admin":
        raise HTTPException(403, "organisation admin required to register a site")
    from zoneinfo import ZoneInfo

    try:
        ZoneInfo(body.timezone)
    except Exception as e:
        raise HTTPException(422, "unknown timezone") from e
    if db.get(Site, body.id) or db.scalar(select(Site).where(Site.code == body.code)):
        raise HTTPException(409, "site id or code already exists")
    if db.get(Portfolio, body.portfolio_id) is None:
        raise HTTPException(422, "unknown portfolio")
    s = Site(**body.model_dump(), source="api")
    db.add(s)
    audit(
        db, user.id, "site_registered", "site", s.id, s.id, body.model_dump(mode="json"), client_ip(request)
    )
    db.flush()
    return _site(s)


@router.get("/sites/nearby", tags=["sites"])
def nearby(
    lat: float = Query(ge=-90, le=90),
    lon: float = Query(ge=-180, le=180),
    km: float = Query(25, gt=0, le=500),
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    ids = sites_for(db, user)
    if db.bind.dialect.name == "postgresql":
        rows = db.execute(
            text(
                "SELECT id, ST_Distance(geog, ST_SetSRID(ST_MakePoint(:lon,:lat),4326)::geography)/1000 AS km "
                "FROM sites WHERE ST_DWithin(geog, ST_SetSRID(ST_MakePoint(:lon,:lat),4326)::geography, :m) "
                "ORDER BY km"
            ),
            {"lat": lat, "lon": lon, "m": km * 1000},
        ).all()
        method = "PostGIS ST_DWithin on geography"
    else:
        import math

        rows = []
        for s in db.scalars(select(Site)):
            d = (
                6371
                * 2
                * math.asin(
                    math.sqrt(
                        math.sin(math.radians(s.latitude - lat) / 2) ** 2
                        + math.cos(math.radians(lat))
                        * math.cos(math.radians(s.latitude))
                        * math.sin(math.radians(s.longitude - lon) / 2) ** 2
                    )
                )
            )
            if d <= km:
                rows.append((s.id, d))
        rows.sort(key=lambda r: r[1])
        method = "haversine (SQLite fallback)"
    return {
        "method": method,
        "sites": [{"site_id": i, "distance_km": round(float(d), 3)} for i, d in rows if i in ids],
    }


@router.get("/sites/{site_id}", tags=["sites"])
def get_site(site_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, site_id)
    return _site(db.get(Site, site_id))


@router.get("/sites/{site_id}/overview", tags=["overview"])
def get_site_overview(site_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, site_id)
    return site_overview(db, site_id)


@router.get("/sites/{site_id}/hierarchy", tags=["assets"])
def get_hierarchy(site_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, site_id)
    return {"site_id": site_id, "view": "physical_hierarchy", "tree": hierarchy(db, site_id)}


@router.get("/sites/{site_id}/connectivity", tags=["assets"])
def get_connectivity(site_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, site_id)
    return {"site_id": site_id, "view": "electrical_connectivity", **connectivity(db, site_id)}


@router.get("/sites/{site_id}/monitoring-points", tags=["assets"])
def get_points(site_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, site_id)
    return {"site_id": site_id, "view": "monitoring_point_mappings", "points": monitoring_points(db, site_id)}


# ------------------------------------------------------------------ assets
@router.get("/assets", tags=["assets"])
def list_assets(
    site_id: str | None = None,
    asset_type: str | None = None,
    q: str | None = Query(None, max_length=80),
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    ids = sites_for(db, user)
    if site_id:
        require_site(db, user, site_id)
        ids = [site_id]
    return [asset_dict(a) for a in search_assets(db, ids, q, asset_type)]


@router.get("/assets/{asset_id}", tags=["assets"])
def get_asset(asset_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    a = db.get(Asset, asset_id)
    if a is None:
        raise HTTPException(404, "asset not found")
    require_site(db, user, a.site_id)
    from sun_king.assets.models import ModuleType, PVSystemConfig

    d = asset_dict(a)
    cfg = db.get(PVSystemConfig, asset_id)
    if cfg:
        d["pv_system_config"] = {
            c.name: getattr(cfg, c.name)
            for c in PVSystemConfig.__table__.columns
            if c.name != "effective_from"
        }
    if a.module_type_id:
        mt = db.get(ModuleType, a.module_type_id)
        d["module_type"] = {c.name: getattr(mt, c.name) for c in ModuleType.__table__.columns}
    d["children"] = [c.asset_id for c in db.scalars(select(Asset).where(Asset.parent_asset_id == asset_id))]
    return d


@router.get("/assets/{asset_id}/history", tags=["assets"])
def get_asset_history(asset_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    a = db.get(Asset, asset_id)
    if a is None:
        raise HTTPException(404, "asset not found")
    require_site(db, user, a.site_id)
    return {"asset_id": asset_id, "events": asset_history(db, asset_id)}


class AssetIn(BaseModel):
    asset_id: str = Field(pattern=r"^[A-Z0-9][A-Z0-9-]{2,63}$")
    site_id: str
    asset_type: str
    name: str = Field(max_length=200)
    manufacturer: str | None = Field(None, max_length=120)
    model: str | None = Field(None, max_length=120)
    serial_reference: str | None = Field(None, max_length=120)
    commissioning_date: date | None = None
    rated_capacity: float | None = Field(None, ge=0)
    rated_capacity_unit: str | None = Field(None, pattern=r"^(kWp|kW|kVA|kWh)$")
    electrical_parameters: dict = Field(default_factory=dict)
    latitude: float | None = Field(None, ge=-90, le=90)
    longitude: float | None = Field(None, ge=-180, le=180)
    parent_asset_id: str | None = None
    warranty_reference: str | None = Field(None, max_length=120)
    maintenance_status: str = "in_service"


@router.post("/assets", tags=["assets"], status_code=201)
def create_asset(
    body: AssetIn, request: Request, user: User = Depends(human_user), db: Session = Depends(get_db)
):
    require_site(db, user, body.site_id, "engineer")
    if body.asset_type not in ASSET_TYPES:
        raise HTTPException(422, f"asset_type must be one of {ASSET_TYPES}")
    if db.get(Asset, body.asset_id):
        raise HTTPException(409, "asset exists")
    if body.parent_asset_id:
        p = db.get(Asset, body.parent_asset_id)
        if p is None or p.site_id != body.site_id:
            raise HTTPException(422, "parent asset must exist on the same site")
    a = Asset(**body.model_dump(), source="api", effective_from=utcnow())
    db.add(a)
    audit(
        db,
        user.id,
        "asset_created",
        "asset",
        a.asset_id,
        a.site_id,
        body.model_dump(mode="json"),
        client_ip(request),
    )
    db.flush()
    return asset_dict(a)


class AssetPatch(BaseModel):
    name: str | None = Field(None, max_length=200)
    serial_reference: str | None = Field(None, max_length=120)
    maintenance_status: str | None = Field(
        None, pattern=r"^(in_service|degraded|out_of_service|under_maintenance|retired)$"
    )
    warranty_reference: str | None = Field(None, max_length=120)
    electrical_parameters: dict | None = None


@router.patch("/assets/{asset_id}", tags=["assets"])
def patch_asset(
    asset_id: str,
    body: AssetPatch,
    request: Request,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    a = db.get(Asset, asset_id)
    if a is None:
        raise HTTPException(404, "asset not found")
    require_site(db, user, a.site_id, "engineer")
    changes = {}
    for k, v in body.model_dump(exclude_none=True).items():
        changes[k] = {"from": getattr(a, k), "to": v}
        setattr(a, k, v)
    audit(db, user.id, "asset_updated", "asset", asset_id, a.site_id, changes, client_ip(request))
    return asset_dict(a)


# ------------------------------------------------------------------ telemetry
@router.post("/telemetry/ingest", tags=["telemetry"], response_model=IngestSummary)
def ingest(
    body: IngestRequest, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)
):
    if user.is_service_account and user.service_scope != "ingest":
        raise HTTPException(403, "token not permitted to ingest")
    assets = {
        a.asset_id: a.site_id
        for a in db.scalars(select(Asset).where(Asset.asset_id.in_({o.asset_id for o in body.observations})))
    }
    if not user.is_service_account:
        for sid in set(assets.values()):
            require_site(db, user, sid, "operator")
    try:
        summary = ingest_batch(db, body.observations, body.source, body.idempotency_key)
    except BatchTooLarge as e:
        raise HTTPException(413, str(e)) from e
    audit(
        db,
        user.id,
        "telemetry_ingested",
        "ingestion_batch",
        summary.batch_id,
        None,
        {"received": summary.received, "accepted": summary.accepted, "replayed": summary.replayed},
        client_ip(request),
    )
    return summary


@router.post("/telemetry/import-csv", tags=["telemetry"], response_model=IngestSummary)
async def import_csv(
    source: str = Query(max_length=64),
    file: UploadFile = File(...),
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    from sun_king.adapters.csv_import import HistorianCSVAdapter, ImportError_

    s = get_settings()
    content = await file.read(s.max_upload_bytes + 1)
    if len(content) > s.max_upload_bytes:
        raise HTTPException(413, "file too large")
    try:
        rows = HistorianCSVAdapter(source).parse(content, min(s.max_import_rows, s.max_ingest_batch))
    except ImportError_ as e:
        raise HTTPException(422, str(e)) from e
    obs = [ObservationIn(**r) for r in rows]
    for sid in {
        a.site_id for a in db.scalars(select(Asset).where(Asset.asset_id.in_({o.asset_id for o in obs})))
    }:
        require_site(db, user, sid, "engineer")
    import hashlib

    return ingest_batch(db, obs, source, idempotency_key=f"csv-{hashlib.sha256(content).hexdigest()[:40]}")


def _asset_site(db, asset_id, user):
    a = db.get(Asset, asset_id)
    if a is None:
        raise HTTPException(404, "asset not found")
    require_site(db, user, a.site_id)
    return a


@router.get("/telemetry/observations", tags=["telemetry"])
def observations(
    asset_id: str,
    measurement_type: str,
    start: datetime | None = None,
    end: datetime | None = None,
    quality: str = Query("good,suspect,bad,missing", max_length=40),
    max_points: int = Query(5000, le=20000),
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    """Cleaned observations (canonical units) with quality flags and links to raw records."""
    _asset_site(db, asset_id, user)
    start, end = parse_window(start, end)
    from sun_king.telemetry.models import CleanObservation

    rows = db.scalars(
        select(CleanObservation)
        .where(
            CleanObservation.asset_id == asset_id,
            CleanObservation.measurement_type == measurement_type,
            CleanObservation.observation_time >= start,
            CleanObservation.observation_time < end,
            CleanObservation.quality.in_(quality.split(",")),
        )
        .order_by(CleanObservation.observation_time)
        .limit(max_points)
    ).all()
    return {
        "asset_id": asset_id,
        "measurement_type": measurement_type,
        "start": start.isoformat(),
        "end": end.isoformat(),
        "unit": rows[0].unit if rows else None,
        "count": len(rows),
        "truncated": len(rows) == max_points,
        "observations": [
            {
                "t": r.observation_time.isoformat(),
                "value": r.value,
                "quality": r.quality,
                "flags": r.quality_flags,
                "raw": r.raw_measurement_id,
                "ingested": r.ingestion_time.isoformat(),
                "source": r.source,
            }
            for r in rows
        ],
    }


@router.get("/telemetry/series", tags=["telemetry"])
def multi_series(
    site_id: str,
    measurement_type: str,
    start: datetime | None = None,
    end: datetime | None = None,
    resample: str = Query("5min", pattern=r"^(1min|5min|15min|30min|1h)$"),
    asset_type: str | None = None,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    require_site(db, user, site_id)
    start, end = parse_window(start, end, max_days=31)
    from sun_king.telemetry.query import frame

    stmt = select(Asset.asset_id).where(Asset.site_id == site_id)
    if asset_type:
        stmt = stmt.where(Asset.asset_type == asset_type)
    ids = list(db.scalars(stmt))
    df = frame(db, ids, measurement_type, start, end, resample=resample)
    df = df.dropna(axis=1, how="all")
    return {
        "site_id": site_id,
        "measurement_type": measurement_type,
        "resample": resample,
        "aggregation": "mean of good-quality samples",
        "assets": list(df.columns),
        "points": [
            {"t": t.isoformat(), **{c: (None if v != v else round(float(v), 3)) for c, v in row.items()}}
            for t, row in df.iterrows()
        ],
    }


@router.get("/telemetry/raw", tags=["telemetry"])
def raw(
    asset_id: str,
    measurement_type: str,
    start: datetime | None = None,
    end: datetime | None = None,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    _asset_site(db, asset_id, user)
    start, end = parse_window(start, end, max_days=7)
    return {
        "note": "Raw observations exactly as received, including all revisions.",
        "observations": raw_for(db, asset_id, measurement_type, start, end),
    }


@router.get("/telemetry/raw/{measurement_id}", tags=["telemetry"])
def raw_one(measurement_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    r = db.get(RawObservation, measurement_id)
    if r is None:
        raise HTTPException(404, "measurement not found")
    _asset_site(db, r.asset_id, user)
    return raw_for(
        db, r.asset_id, r.measurement_type, r.observation_time, r.observation_time.replace(microsecond=999999)
    )


@router.get("/telemetry/latest", tags=["telemetry"])
def latest(site_id: str, user: User = Depends(human_user), db: Session = Depends(get_db)):
    require_site(db, user, site_id)
    s = get_settings()
    vals = latest_values(db, site_id)
    for v in vals:
        v["is_current"] = v["age_s"] <= s.stale_after_seconds
    return {
        "site_id": site_id,
        "as_of": utcnow().isoformat(),
        "stale_after_s": s.stale_after_seconds,
        "values": vals,
    }


@router.get("/telemetry/batches", tags=["telemetry"])
def batches(limit: int = Query(50, le=500), user: User = Depends(human_user), db: Session = Depends(get_db)):
    if user.org_role != "admin" and not sites_for(db, user, "engineer"):
        raise HTTPException(403, "engineer role required")
    rows = db.scalars(select(IngestionBatch).order_by(IngestionBatch.received_at.desc()).limit(limit)).all()
    return [{c.name: getattr(b, c.name) for c in IngestionBatch.__table__.columns} for b in rows]


# ------------------------------------------------------------------ energy
@router.get("/energy/sites/{site_id}", tags=["energy"])
def energy(
    site_id: str,
    start: datetime | None = None,
    end: datetime | None = None,
    persist: bool = False,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    require_site(db, user, site_id)
    start, end = parse_window(start, end)
    return site_energy(db, site_id, start, end, persist=persist)


@router.get("/energy/sites/{site_id}/completeness", tags=["energy"])
def completeness(
    site_id: str,
    days: int = Query(7, ge=1, le=62),
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    require_site(db, user, site_id)
    return {
        "site_id": site_id,
        "days": daily_completeness(db, site_id, days),
        "statuses": {
            "complete": "≥98% coverage, no reset",
            "incomplete": "gaps; total shown is measured only",
            "incomplete_meter_reset": "register reset; part of the interval unobservable",
            "in_progress": "day not finished",
            "no_data": "no meter data",
        },
    }


@router.get("/energy/series", tags=["energy"])
def energy_series(
    asset_id: str,
    measurement_type: str = "ac_power",
    start: datetime | None = None,
    end: datetime | None = None,
    user: User = Depends(human_user),
    db: Session = Depends(get_db),
):
    _asset_site(db, asset_id, user)
    start, end = parse_window(start, end)
    return {"samples": [(t.isoformat(), v) for t, v in series(db, asset_id, measurement_type, start, end)]}


@router.get("/energy/portfolio", tags=["energy"])
def energy_portfolio(
    day: date | None = None, user: User = Depends(human_user), db: Session = Depends(get_db)
):
    from sun_king.core.timeutil import local_day_bounds
    from sun_king.energy.hierarchy import SiteEnergyFigure, portfolio_total

    figs, per = [], []
    for sid in sites_for(db, user):
        site = db.get(Site, sid)
        d = day or local_date(utcnow(), site.timezone)
        s, e = local_day_bounds(d, site.timezone)
        r = site_energy(db, sid, s, min(e, utcnow()))
        f = r["site_figure"]
        figs.append(
            SiteEnergyFigure(
                sid,
                f["energy_kwh"],
                f["basis"],
                f["meter_asset_id"],
                f["complete"],
                f["coverage"],
                [],
                f["note"],
            )
        )
        per.append(
            {"site_id": sid, "date": d.isoformat(), **f, "inverter_ac_total_kwh": r["inverter_ac_total_kwh"]}
        )
    return {"sites": per, "portfolio": portfolio_total(figs)}
