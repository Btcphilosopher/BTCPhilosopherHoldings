"""FastAPI application factory."""

from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse

from sun_king import __version__
from sun_king.config import get_settings
from sun_king.core.db import get_engine

log = logging.getLogger("sun_king.api")
FRONTEND = Path(
    os.environ.get("SUN_KING_FRONTEND_DIST", Path(__file__).resolve().parents[3] / "frontend" / "dist")
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    get_engine()
    from sun_king.adapters.simulator import SimulatedWeatherForecastAdapter
    from sun_king.workers.runner import make_plant, start_embedded

    try:
        app.state.plant = make_plant()
    except Exception:  # noqa: BLE001 - empty database before seeding
        from datetime import date

        from sun_king.simulation.plant import PlantSimulator

        app.state.plant = PlantSimulator(date.today())
    app.state.nwp = SimulatedWeatherForecastAdapter(app.state.plant)
    stop = (
        start_embedded() if os.environ.get("SUN_KING_EMBEDDED_WORKERS", "false").lower() == "true" else None
    )
    yield
    if stop:
        stop.set()


def create_app() -> FastAPI:
    s = get_settings()
    app = FastAPI(
        title="SUN KING — Solar Farm Operations API",
        version=__version__,
        description=(
            "Monitoring, energy accounting, performance, alerts, maintenance, forecasting and commercial evidence "
            "for PV portfolios. Read-only with respect to plant equipment: no control commands exist. "
            "Demo data is fictional and synthetic."
        ),
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(s.cors_origins),
        allow_credentials=False,
        allow_methods=["GET", "POST", "PATCH"],
        allow_headers=["Authorization", "Content-Type"],
    )

    @app.middleware("http")
    async def guard(request: Request, call_next):
        cl = request.headers.get("content-length")
        if cl and cl.isdigit() and int(cl) > s.max_upload_bytes + 1024 * 1024:
            return JSONResponse({"detail": "request body too large"}, status_code=413)
        resp = await call_next(request)
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "no-referrer")
        if request.url.path.startswith("/api"):
            resp.headers.setdefault("Cache-Control", "no-store")
        return resp

    from sun_king.api import routes_core, routes_more, routes_ops

    app.include_router(routes_core.router)
    app.include_router(routes_ops.router)
    app.include_router(routes_more.router)
    app.include_router(routes_more.ws_router)

    if FRONTEND.exists():

        @app.get("/{path:path}", include_in_schema=False)
        def spa(path: str):
            f = (FRONTEND / path).resolve()
            if path and FRONTEND.resolve() in f.parents and f.is_file():
                return FileResponse(f)
            return FileResponse(FRONTEND / "index.html")

    return app


app = create_app()
