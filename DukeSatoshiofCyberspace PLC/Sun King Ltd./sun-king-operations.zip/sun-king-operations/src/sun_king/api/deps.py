from __future__ import annotations

from collections.abc import Iterator

import jwt
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from sun_king.admin.models import User
from sun_king.admin.security import decode_token, has_site_role, permitted_sites
from sun_king.core.db import session_factory

bearer = HTTPBearer(auto_error=False)


def get_db() -> Iterator[Session]:
    s = session_factory()()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()


def current_user(
    creds: HTTPAuthorizationCredentials | None = Depends(bearer), db: Session = Depends(get_db)
) -> User:
    if creds is None:
        raise HTTPException(
            status.HTTP_401_UNAUTHORIZED, "authentication required", headers={"WWW-Authenticate": "Bearer"}
        )
    try:
        claims = decode_token(creds.credentials)
    except jwt.PyJWTError as e:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, f"invalid token: {e.__class__.__name__}") from e
    user = db.get(User, claims["sub"])
    if user is None or not user.active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "unknown or inactive user")
    if user.is_service_account and claims.get("scope") != user.service_scope:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "service token scope mismatch")
    return user


def human_user(user: User = Depends(current_user)) -> User:
    if user.is_service_account:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "service accounts may only ingest telemetry")
    return user


def require_site(db: Session, user: User, site_id: str, min_role: str = "viewer") -> None:
    if not has_site_role(db, user, site_id, min_role):
        # 404 for no access at all, 403 for insufficient role: do not reveal other sites' existence
        if not has_site_role(db, user, site_id, "viewer"):
            raise HTTPException(status.HTTP_404_NOT_FOUND, "site not found")
        raise HTTPException(status.HTTP_403_FORBIDDEN, f"requires {min_role} role on {site_id}")


def require_org_admin(user: User = Depends(human_user)) -> User:
    if user.org_role != "admin":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "organisation admin required")
    return user


def sites_for(db: Session, user: User, min_role: str = "viewer") -> list[str]:
    return permitted_sites(db, user, min_role)


def client_ip(request: Request) -> str | None:
    return request.client.host if request.client else None
