"""Background workers: live simulated ingestion, alert evaluation, scheduled jobs.

Run as a separate process (``sun-king worker``) in Docker Compose, or embedded
in the API process for single-process demos (``SUN_KING_EMBEDDED_WORKERS=true``).
Each loop has its own retry budget: on repeated failure the loop backs off and
records the error on the source status rather than crashing.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from datetime import date, datetime, timedelta

from sqlalchemy import select

from sun_king.adapters.simulator import SimulatedWeatherForecastAdapter, SimulatorTelemetryAdapter
from sun_king.admin.models import AdapterConfig
from sun_king.alerts.engine import evaluate_site
from sun_king.assets.models import Site
from sun_king.config import get_settings
from sun_king.core.db import session_scope
from sun_king.core.timeutil import local_date, utcnow
from sun_king.simulation.plant import PlantSimulator
from sun_king.simulation.telemetry_sim import RegisterState
from sun_king.telemetry.ingest import ingest_batch, record_source_failure
from sun_king.telemetry.models import StreamState
from sun_king.workers import jobs

log = logging.getLogger("sun_king.worker")


def make_plant() -> PlantSimulator:
    with session_scope() as s:
        cfg = s.get(AdapterConfig, "sim-all")
        settings = (cfg.settings if cfg else {}) or {}
    anchor = (
        date.fromisoformat(settings["anchor_day"])
        if "anchor_day" in settings
        else local_date(utcnow(), "Europe/London")
    )
    plant = PlantSimulator(anchor, seed=settings.get("seed", 20261127))
    for sid, (a, b) in (settings.get("outages") or {}).items():
        plant.disconnected_until[sid] = (datetime.fromisoformat(a), datetime.fromisoformat(b))
    return plant


def registers_from_db(session, site_id: str) -> dict[str, RegisterState]:
    regs = {}
    rows = session.scalars(select(StreamState).where(StreamState.site_id == site_id)).all()
    power = {(r.asset_id, r.measurement_type): r for r in rows}
    for r in rows:
        if r.measurement_type in ("ac_energy", "export_energy", "import_energy") and r.last_value is not None:
            p = power.get((r.asset_id, "ac_power"))
            pk = p.last_value if p and p.last_value is not None else 0.0
            if r.measurement_type == "export_energy":
                pk = max(pk, 0)
            elif r.measurement_type == "import_energy":
                pk = max(-pk, 0)
            regs[f"{r.asset_id}:{r.measurement_type}"] = RegisterState(
                r.last_value, r.last_observation_time, pk
            )
    return regs


def live_tick(plant: PlantSimulator, adapter: SimulatorTelemetryAdapter, now: datetime | None = None) -> dict:
    now = now or utcnow()
    out = {}
    with session_scope() as s:
        cfg = s.get(AdapterConfig, "sim-all")
        outages = ((cfg.settings or {}).get("outages") or {}) if cfg else {}
        plant.disconnected_until = {
            k: (datetime.fromisoformat(a), datetime.fromisoformat(b)) for k, (a, b) in outages.items()
        }
        for site in s.scalars(select(Site)):
            try:
                adapter.registers[site.id] = registers_from_db(s, site.id)
                res = adapter.fetch(site.id, now - timedelta(seconds=30), now)
                if not res.observations:
                    record_source_failure(s, site.id, "simulator", "no data (simulated link outage)", now)
                    out[site.id] = 0
                    continue
                summ = ingest_batch(s, res.observations, source="simulator", now=now)
                out[site.id] = summ.accepted
            except Exception as e:  # noqa: BLE001
                log.exception("live tick failed for %s", site.id)
                record_source_failure(s, site.id, "simulator", str(e), now)
    return out


def evaluate_all(now: datetime | None = None) -> dict:
    now = now or utcnow()
    out = {}
    with session_scope() as s:
        for site in s.scalars(select(Site)):
            out[site.id] = evaluate_site(s, site.id, now)
    return out


@jobs.handler("operational_report")
def _report_job(session, payload):
    from sun_king.reporting.report import operational_report

    r = operational_report(
        session,
        payload["portfolio_id"],
        payload["site_ids"],
        date.fromisoformat(payload["start_day"]),
        date.fromisoformat(payload["end_day"]),
    )
    return {"report_id": r.id}


@jobs.handler("day_ahead_forecast")
def _forecast_job(session, payload):
    from sun_king.forecasting.service import issue_forecast, train_and_evaluate

    plant = make_plant()
    nwp = SimulatedWeatherForecastAdapter(plant)
    site = session.get(Site, payload["site_id"])
    now = utcnow()
    r = train_and_evaluate(session, site, nwp, now - timedelta(days=13), now, "day_ahead")
    f = issue_forecast(session, site, nwp, now, r["model"], "day_ahead")
    return {"forecast_id": f.id}


def schedule_daily(now: datetime) -> None:
    with session_scope() as s:
        for site in s.scalars(select(Site)):
            d = local_date(now, site.timezone)
            local_hour = now.astimezone(__import__("zoneinfo").ZoneInfo(site.timezone)).hour
            if local_hour >= 10:
                jobs.enqueue(
                    s, "day_ahead_forecast", {"site_id": site.id}, idempotency_key=f"da-{site.id}-{d}"
                )


class Loop:
    def __init__(self, name: str, interval_s: float, fn, budget: int = 5):
        self.name, self.interval, self.fn, self.budget = name, interval_s, fn, budget
        self.failures = 0
        self.next_run = 0.0

    def maybe_run(self):
        t = time.monotonic()
        if t < self.next_run:
            return
        try:
            self.fn()
            self.failures = 0
            self.next_run = t + self.interval
        except Exception:  # noqa: BLE001
            self.failures += 1
            backoff = min(self.interval * 2**self.failures, 600)
            log.exception(
                "%s failed (%d/%d); backing off %.0fs", self.name, self.failures, self.budget, backoff
            )
            self.next_run = t + backoff


def build_loops() -> list[Loop]:
    settings = get_settings()
    plant = make_plant()
    adapter = SimulatorTelemetryAdapter(plant)
    worker_id = f"worker-{os.getpid()}"
    with session_scope() as s:
        n = jobs.recover_expired(s)
        if n:
            log.warning("requeued %d jobs with expired leases", n)
    loops = [
        Loop("alerts", 60, evaluate_all),
        Loop("schedule", 600, lambda: schedule_daily(utcnow())),
        Loop("jobs", 5, lambda: _drain(worker_id)),
    ]
    if settings.simulator_enabled:
        loops.insert(
            0, Loop("simulator", settings.simulator_interval_seconds, lambda: live_tick(plant, adapter))
        )
    return loops


def _drain(worker_id: str):
    for _ in range(10):
        with session_scope() as s:
            if jobs.run_one(s, worker_id) is None:
                return


def run_forever(stop: threading.Event | None = None) -> None:
    loops = build_loops()
    log.info("workers started: %s", [lp.name for lp in loops])
    stop = stop or threading.Event()
    while not stop.is_set():
        for lp in loops:
            lp.maybe_run()
        stop.wait(1.0)


def start_embedded() -> threading.Event:
    stop = threading.Event()
    threading.Thread(target=run_forever, args=(stop,), daemon=True, name="sun-king-workers").start()
    return stop
