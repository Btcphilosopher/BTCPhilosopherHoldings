"""OT-boundary collector: polls configured read-only adapters and pushes to the API.

Runs on an isolated network (``ot_net`` in ``compose.yaml``) with an
ingest-only service token. It has no database credentials, keeps a bounded
on-disk spool when the API is unreachable (store-and-forward), retries with
exponential backoff within a retry budget, and uses idempotency keys so a
retried batch is never double-ingested.
"""

from __future__ import annotations

import json
import logging
import os
import time
from datetime import timedelta
from pathlib import Path

import httpx

from sun_king.core.timeutil import utcnow

log = logging.getLogger("sun_king.collector")
SPOOL = Path(os.environ.get("SUN_KING_COLLECTOR_SPOOL", "/tmp/sun-king-spool"))
MAX_SPOOL_FILES = 2000


def _token() -> str:
    f = os.environ.get("SUN_KING_COLLECTOR_TOKEN_FILE")
    return Path(f).read_text().strip() if f else os.environ.get("SUN_KING_COLLECTOR_TOKEN", "")


def push(client: httpx.Client, api: str, payload: dict, budget: int = 4) -> bool:
    delay = 2.0
    for attempt in range(budget):
        try:
            r = client.post(
                f"{api}/api/telemetry/ingest", json=payload, headers={"Authorization": f"Bearer {_token()}"}
            )
            if r.status_code < 500:
                if r.status_code >= 400:
                    log.error("ingest rejected (%s): %s", r.status_code, r.text[:300])
                return True  # 2xx accepted, 4xx will never succeed: do not retry
        except httpx.HTTPError as e:
            log.warning("ingest attempt %d failed: %s", attempt + 1, e)
        time.sleep(delay)
        delay *= 2
    return False


def spool(payload: dict) -> None:
    SPOOL.mkdir(parents=True, exist_ok=True)
    files = sorted(SPOOL.glob("*.json"))
    if len(files) >= MAX_SPOOL_FILES:
        files[0].unlink()  # bounded: drop oldest, logged
        log.error("spool full; dropped %s", files[0].name)
    (SPOOL / f"{payload['idempotency_key']}.json").write_text(json.dumps(payload))


def drain(client: httpx.Client, api: str) -> None:
    for f in sorted(SPOOL.glob("*.json"))[:50]:
        if push(client, api, json.loads(f.read_text()), budget=1):
            f.unlink()
        else:
            return


def main() -> None:  # pragma: no cover - long-running service
    logging.basicConfig(level=logging.INFO)
    from datetime import date

    from sun_king.adapters.simulator import SimulatorTelemetryAdapter
    from sun_king.simulation.plant import PlantSimulator

    api = os.environ.get("SUN_KING_COLLECTOR_API", "http://localhost:8000")
    sites = os.environ.get("SUN_KING_COLLECTOR_SITES", "site-hlm,site-cle").split(",")
    interval = int(os.environ.get("SUN_KING_COLLECTOR_INTERVAL_S", "60"))
    adapter = SimulatorTelemetryAdapter(PlantSimulator(date.today()))  # replace with configured live adapters
    with httpx.Client(timeout=15) as client:
        while True:
            now = utcnow()
            drain(client, api)
            for sid in sites:
                res = adapter.fetch(sid, now - timedelta(seconds=interval), now)
                payload = {
                    "source": "ot-collector",
                    "idempotency_key": f"col-{sid}-{now.isoformat()}",
                    "observations": [json.loads(o.model_dump_json()) for o in res.observations],
                }
                if not push(client, api, payload):
                    spool(payload)
            time.sleep(interval)


if __name__ == "__main__":  # pragma: no cover
    main()
