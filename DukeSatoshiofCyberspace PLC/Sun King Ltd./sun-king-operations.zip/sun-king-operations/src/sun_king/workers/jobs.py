"""Durable job queue with leases, retry budgets and restart recovery.

* ``enqueue`` is idempotent on ``idempotency_key``.
* ``claim`` takes the next runnable job with a lease (``FOR UPDATE SKIP LOCKED``
  on PostgreSQL so several workers can share the queue).
* A job whose lease expired (worker crashed/restarted) is returned to the
  queue by ``recover_expired``; it counts as an attempt.
* Failures back off exponentially until ``max_attempts`` is exhausted, after
  which the job is marked ``failed`` with its last error.
"""

from __future__ import annotations

import traceback
from collections.abc import Callable
from datetime import datetime, timedelta

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from sun_king.admin.models import Job
from sun_king.core.ids import new_id
from sun_king.core.timeutil import utcnow

LEASE = timedelta(minutes=5)
HANDLERS: dict[str, Callable[[Session, dict], dict]] = {}


def handler(kind: str):
    def deco(fn):
        HANDLERS[kind] = fn
        return fn

    return deco


def enqueue(
    session: Session,
    kind: str,
    payload: dict,
    idempotency_key: str | None = None,
    max_attempts: int = 5,
    run_after: datetime | None = None,
) -> Job:
    if idempotency_key:
        existing = session.scalar(select(Job).where(Job.idempotency_key == idempotency_key))
        if existing:
            return existing
    j = Job(
        id=new_id("job"),
        kind=kind,
        payload=payload,
        idempotency_key=idempotency_key,
        max_attempts=max_attempts,
        run_after=run_after or utcnow(),
    )
    session.add(j)
    session.flush()
    return j


def recover_expired(session: Session, now: datetime | None = None) -> int:
    now = now or utcnow()
    res = session.execute(
        update(Job)
        .where(Job.status == "running", Job.lease_expires < now)
        .values(
            status="queued",
            worker_id=None,
            lease_expires=None,
            last_error="lease expired (worker restart); requeued",
        )
    )
    return res.rowcount or 0


def claim(session: Session, worker_id: str, now: datetime | None = None) -> Job | None:
    now = now or utcnow()
    stmt = select(Job).where(Job.status == "queued", Job.run_after <= now).order_by(Job.run_after).limit(1)
    if session.bind.dialect.name == "postgresql":
        stmt = stmt.with_for_update(skip_locked=True)
    job = session.scalar(stmt)
    if job is None:
        return None
    job.status = "running"
    job.worker_id = worker_id
    job.lease_expires = now + LEASE
    job.attempts += 1
    session.flush()
    return job


def run_one(session: Session, worker_id: str, now: datetime | None = None) -> Job | None:
    job = claim(session, worker_id, now)
    if job is None:
        return None
    fn = HANDLERS.get(job.kind)
    try:
        if fn is None:
            raise RuntimeError(f"no handler for {job.kind}")
        with session.begin_nested():
            job.result = fn(session, job.payload)
        job.status = "done"
        job.finished_at = utcnow()
        job.last_error = None
    except Exception as e:  # noqa: BLE001 - recorded on the job
        job.last_error = "".join(traceback.format_exception_only(e)).strip()[:2000]
        if job.attempts >= job.max_attempts:
            job.status = "failed"
            job.finished_at = utcnow()
        else:
            job.status = "queued"
            job.run_after = (now or utcnow()) + timedelta(seconds=min(2**job.attempts * 15, 3600))
        job.worker_id = None
        job.lease_expires = None
    session.flush()
    return job
