"""Operational overview figures. Every number carries its source and calculation."""

from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from sun_king.alerts.models import Alert
from sun_king.assets.models import Asset, Site
from sun_king.assets.service import meter_for_role, site_inverters
from sun_king.config import get_settings
from sun_king.core.timeutil import local_date, local_day_bounds, utcnow
from sun_king.energy.models import CurtailmentRecord
from sun_king.energy.service import meter_export
from sun_king.maintenance.models import MaintenanceSchedule, WorkOrder
from sun_king.telemetry.models import StreamState
from sun_king.telemetry.query import freshness


def _state(session, asset_id, mtype):
    return session.scalar(
        select(StreamState).where(StreamState.asset_id == asset_id, StreamState.measurement_type == mtype)
    )


def site_overview(session: Session, site_id: str, now: datetime | None = None) -> dict:
    now = now or utcnow()
    settings = get_settings()
    site = session.get(Site, site_id)
    stale_s = settings.stale_after_seconds
    fr = freshness(session, site_id, stale_s, now)
    meter = meter_for_role(session, site_id, "export_settlement")
    invs = site_inverters(session, site_id)

    def lv(asset_id, mtype):
        st = _state(session, asset_id, mtype)
        if st is None:
            return None
        age = (now - st.last_observation_time).total_seconds()
        return {
            "value": st.last_value,
            "unit": st.last_unit,
            "observation_time": st.last_observation_time.isoformat(),
            "age_s": round(age, 0),
            "is_current": age <= stale_s,
            "quality": st.last_quality,
            "measurement_id": st.last_measurement_id,
            "source": f"/api/telemetry/raw/{st.last_measurement_id}",
        }

    inv_rows = []
    available_kw = 0.0
    n_avail = n_unknown = 0
    for inv in invs:
        p = lv(inv.asset_id, "ac_power")
        s = lv(inv.asset_id, "status_code")
        if p is None or not p["is_current"]:
            state = "no_telemetry"
            n_unknown += 1
        elif s and s["value"] is not None and s["value"] >= 100:
            state = "fault"
        elif s and s["value"] == 1:
            state = "standby"
            available_kw += inv.rated_capacity or 0
            n_avail += 1
        else:
            state = "available"
            available_kw += inv.rated_capacity or 0
            n_avail += 1
        inv_rows.append(
            {
                "asset_id": inv.asset_id,
                "name": inv.name,
                "rated_kw": inv.rated_capacity,
                "ac_power": p,
                "status": s,
                "state": state,
            }
        )
    gen = lv(meter, "ac_power") if meter else None
    inv_sum = sum(
        (r["ac_power"] or {}).get("value") or 0
        for r in inv_rows
        if r["ac_power"] and r["ac_power"]["is_current"]
    )
    today = local_date(now, site.timezone)
    ds, _ = local_day_bounds(today, site.timezone)
    energy_today = meter_export(session, site_id, ds, now, estimate=True) if meter else None
    active_alerts = session.scalars(
        select(Alert).where(Alert.site_id == site_id, Alert.status != "verified")
    ).all()
    curt = session.scalars(
        select(CurtailmentRecord).where(
            CurtailmentRecord.site_id == site_id, CurtailmentRecord.end_time > now - timedelta(days=7)
        )
    ).all()
    curt_now = [c for c in curt if c.start_time <= now < c.end_time]
    wo_open = (
        session.scalar(
            select(func.count())
            .select_from(WorkOrder)
            .where(WorkOrder.site_id == site_id, WorkOrder.status.notin_(["signed_off", "cancelled"]))
        )
        or 0
    )
    overdue = (
        session.scalar(
            select(func.count())
            .select_from(MaintenanceSchedule)
            .where(
                MaintenanceSchedule.site_id == site_id,
                MaintenanceSchedule.next_due < today,
                MaintenanceSchedule.active.is_(True),
            )
        )
        or 0
    )
    pyr = [
        a.asset_id
        for a in session.scalars(select(Asset).where(Asset.site_id == site_id, Asset.asset_type == "sensor"))
        if (a.electrical_parameters or {}).get("sensor_role") in ("primary", "reference")
    ]
    batt = session.scalar(select(Asset).where(Asset.site_id == site_id, Asset.asset_type == "battery_system"))
    return {
        "site": {
            "id": site.id,
            "name": site.name,
            "code": site.code,
            "timezone": site.timezone,
            "latitude": site.latitude,
            "longitude": site.longitude,
            "boundary": site.boundary,
        },
        "as_of": now.isoformat(),
        "local_time": now.astimezone(__import__("zoneinfo").ZoneInfo(site.timezone)).isoformat(),
        "telemetry_freshness": fr,
        "connection_state": fr["state"],
        "capacity": {
            "dc_kwp": site.dc_capacity_kwp,
            "ac_kw": site.ac_capacity_kw,
            "export_limit_kw": site.export_limit_kw,
            "available_ac_kw": available_kw,
            "available_basis": "sum of AC ratings of inverters with current telemetry and no fault code",
            "unknown_ac_kw": sum(r["rated_kw"] or 0 for r in inv_rows if r["state"] == "no_telemetry"),
        },
        "current_generation": {
            "export_meter": gen,
            "inverter_ac_sum_kw": round(inv_sum, 1),
            "inverters_reporting": sum(1 for r in inv_rows if r["state"] != "no_telemetry"),
            "inverters_total": len(inv_rows),
            "note": "Export meter is the site's measured export; inverter sum excludes non-reporting inverters.",
        },
        "today_measured_export": None
        if energy_today is None
        else {
            "energy_kwh": energy_today.get("energy_kwh"),
            "coverage": energy_today.get("coverage"),
            "complete_so_far": energy_today.get("complete"),
            "flags": energy_today.get("flags"),
            "method": energy_today.get("method"),
            "gaps": energy_today.get("gaps"),
            "sources": energy_today.get("sources"),
            "estimated_kwh": energy_today.get("estimated_kwh"),
            "resets": energy_today.get("resets"),
            "calculation": f"/api/energy/sites/{site_id}?start={ds.isoformat()}&end={now.isoformat()}",
        },
        "inverter_availability": {
            "available": n_avail,
            "unknown": n_unknown,
            "total": len(inv_rows),
            "fraction_known": round(n_avail / (len(inv_rows) - n_unknown), 3)
            if len(inv_rows) - n_unknown
            else None,
        },
        "inverters": inv_rows,
        "grid_export_kw": gen,
        "irradiance": {a: lv(a, "poa_irradiance") for a in pyr},
        "alerts": {
            "open": len(active_alerts),
            "condition_active": sum(1 for a in active_alerts if a.condition_active),
            "critical": sum(1 for a in active_alerts if a.severity == "critical" and a.condition_active),
            "link": f"/api/alerts?site_id={site_id}",
        },
        "maintenance": {
            "open_work_orders": wo_open,
            "overdue_schedules": overdue,
            "link": f"/api/maintenance/work-orders?site_id={site_id}",
        },
        "curtailment": {
            "active_now": [c.id for c in curt_now],
            "last_7_days": [
                {
                    "id": c.id,
                    "start": c.start_time.isoformat(),
                    "end": c.end_time.isoformat(),
                    "limit_kw": c.limit_kw,
                    "instruction_ref": c.instruction_ref,
                }
                for c in curt
            ],
        },
        "battery": None
        if batt is None
        else {
            "asset_id": batt.asset_id,
            "soc": lv(batt.asset_id, "battery_soc"),
            "power": lv(batt.asset_id, "battery_power"),
            "state": lv(batt.asset_id, "battery_state"),
            "integration": "read_only",
        },
        "data_completeness": {
            "today_export_coverage": energy_today.get("coverage") if energy_today else None,
            "stale_streams": fr["stale_streams"],
            "streams": fr["streams"],
            "link": f"/api/energy/sites/{site_id}/completeness?days=7",
        },
    }


def portfolio_overview(session: Session, site_ids: list[str], now: datetime | None = None) -> dict:
    now = now or utcnow()
    sites = [site_overview(session, s, now) for s in site_ids]
    from sun_king.energy.hierarchy import SiteEnergyFigure, portfolio_total

    figs = [
        SiteEnergyFigure(
            s["site"]["id"],
            (s["today_measured_export"] or {}).get("energy_kwh"),
            "meter:export_settlement",
            None,
            bool((s["today_measured_export"] or {}).get("complete_so_far")),
            (s["today_measured_export"] or {}).get("coverage") or 0,
            [],
            "",
        )
        for s in sites
    ]
    cur = [s["current_generation"]["export_meter"] for s in sites]
    return {
        "as_of": now.isoformat(),
        "sites": sites,
        "totals": {
            "dc_kwp": sum(s["capacity"]["dc_kwp"] for s in sites),
            "ac_kw": sum(s["capacity"]["ac_kw"] for s in sites),
            "export_limit_kw": sum(s["capacity"]["export_limit_kw"] for s in sites),
            "available_ac_kw": sum(s["capacity"]["available_ac_kw"] for s in sites),
            "current_export_kw": sum(
                c["value"] for c in cur if c and c["is_current"] and c["value"] is not None
            ),
            "current_export_complete": all(c and c["is_current"] for c in cur),
            "sites_not_current": [
                s["site"]["id"] for s, c in zip(sites, cur, strict=True) if not (c and c["is_current"])
            ],
            "today_export": portfolio_total(figs),
            "open_alerts": sum(s["alerts"]["open"] for s in sites),
            "active_conditions": sum(s["alerts"]["condition_active"] for s in sites),
            "open_work_orders": sum(s["maintenance"]["open_work_orders"] for s in sites),
        },
    }
