from __future__ import annotations

from datetime import datetime

from sqlalchemy import ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from sun_king.core.db import Base, JSONType, UTCDateTime
from sun_king.core.timeutil import utcnow


class Report(Base):
    __tablename__ = "reports"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    report_type: Mapped[str] = mapped_column(String(48))
    portfolio_id: Mapped[str | None] = mapped_column(ForeignKey("portfolios.id"))
    site_id: Mapped[str | None] = mapped_column(ForeignKey("sites.id"))
    period_start: Mapped[datetime] = mapped_column(UTCDateTime)
    period_end: Mapped[datetime] = mapped_column(UTCDateTime)
    generated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    generated_by: Mapped[str | None] = mapped_column(String(64))
    content: Mapped[dict] = mapped_column(JSONType)
    content_sha256: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(16), default="complete")
