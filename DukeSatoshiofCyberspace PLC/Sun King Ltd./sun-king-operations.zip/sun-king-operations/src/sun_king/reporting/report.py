"""Source-linked operational report (JSON, HTML and CSV exports)."""

from __future__ import annotations

import csv
import hashlib
import html
import io
import json
from datetime import date, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from sun_king.alerts.models import Alert
from sun_king.assets.models import Portfolio, Site
from sun_king.core.ids import new_id
from sun_king.core.timeutil import local_day_bounds, utcnow
from sun_king.energy.service import daily_completeness
from sun_king.forecasting.models import Forecast
from sun_king.maintenance.models import WorkOrder
from sun_king.performance.analysis import (
    availability,
    inverter_comparison,
    loss_breakdown,
    performance_ratio,
    run_site_model,
    specific_yield,
)
from sun_king.reporting.models import Report


def _clean(o):
    if isinstance(o, dict):
        return {k: _clean(v) for k, v in o.items()}
    if isinstance(o, list | tuple):
        return [_clean(v) for v in o]
    if isinstance(o, float) and o != o:
        return None
    if isinstance(o, datetime | date):
        return o.isoformat()
    return o


def operational_report(
    session: Session,
    portfolio_id: str,
    site_ids: list[str],
    start_day: date,
    end_day: date,
    user_id: str | None = None,
) -> Report:
    pf = session.get(Portfolio, portfolio_id)
    site_sections = []
    p_start = p_end = None
    for sid in site_ids:
        site = session.get(Site, sid)
        s, _ = local_day_bounds(start_day, site.timezone)
        _, e = local_day_bounds(end_day, site.timezone)
        e = min(e, utcnow())
        p_start = s if p_start is None else min(p_start, s)
        p_end = e if p_end is None else max(p_end, e)
        days = (end_day - start_day).days + 1
        comp = daily_completeness(session, sid, days, today=end_day)
        run = run_site_model(session, sid, s, e)
        alerts = session.scalars(
            select(Alert).where(
                Alert.site_id == sid,
                Alert.first_detected_at < e,
                (Alert.condition_cleared_at.is_(None)) | (Alert.condition_cleared_at >= s),
            )
        ).all()
        wos = session.scalars(
            select(WorkOrder).where(WorkOrder.site_id == sid, WorkOrder.created_at < e + timedelta(days=30))
        ).all()
        fcs = session.scalars(
            select(Forecast).where(Forecast.site_id == sid).order_by(Forecast.issue_time.desc()).limit(3)
        ).all()
        measured = [d["measured_export_kwh"] for d in comp]
        site_sections.append(
            {
                "site_id": sid,
                "name": site.name,
                "timezone": site.timezone,
                "capacity": {
                    "dc_kwp": site.dc_capacity_kwp,
                    "ac_kw": site.ac_capacity_kw,
                    "export_limit_kw": site.export_limit_kw,
                },
                "energy": {
                    "daily": comp,
                    "period_measured_export_kwh": sum(m for m in measured if m is not None)
                    if any(m is not None for m in measured)
                    else None,
                    "period_complete": all(d["status"] == "complete" for d in comp),
                    "incomplete_days": [d["date"] for d in comp if d["status"] != "complete"],
                    "statement": "Period total is the sum of daily measured export; days not 'complete' are listed and not filled.",
                },
                "performance": {
                    "specific_yield": specific_yield(session, sid, s, e).to_dict(),
                    "performance_ratio": performance_ratio(session, sid, s, e, run).to_dict(),
                    "inverters": inverter_comparison(session, sid, s, e, run),
                    "availability": {i: availability(run, i).to_dict() for i in run.expected},
                    "losses": loss_breakdown(session, sid, s, e, run),
                },
                "alerts": [
                    {
                        "id": a.id,
                        "type": a.alert_type,
                        "severity": a.severity,
                        "title": a.title,
                        "status": a.status,
                        "condition_active": a.condition_active,
                        "attribution": a.attribution,
                        "attribution_confidence": a.attribution_confidence,
                        "detected": a.first_detected_at.isoformat(),
                        "cleared": a.condition_cleared_at.isoformat() if a.condition_cleared_at else None,
                        "rule": f"{a.rule_id} v{a.rule_version}",
                        "threshold_source": a.threshold_source,
                        "source": f"/api/alerts/{a.id}",
                    }
                    for a in alerts
                ],
                "maintenance": [
                    {
                        "id": w.id,
                        "title": w.title,
                        "status": w.status,
                        "work_type": w.work_type,
                        "completed_at": w.completed_at.isoformat() if w.completed_at else None,
                        "verification": w.verification,
                        "safety_notice": w.safety_notice,
                        "source": f"/api/maintenance/work-orders/{w.id}",
                    }
                    for w in wos
                ],
                "forecasts": [
                    {
                        "id": f.id,
                        "kind": f.kind,
                        "horizon_type": f.horizon_type,
                        "issue_time": f.issue_time.isoformat(),
                        "model": f"{f.model_name} {f.model_version}",
                        "weather_source": f.weather_source,
                        "source": f"/api/forecasts/{f.id}",
                    }
                    for f in fcs
                ],
            }
        )
    content = _clean(
        {
            "title": f"Operational report — {pf.name}",
            "period": {"start_day": start_day.isoformat(), "end_day": end_day.isoformat()},
            "generated_at": utcnow().isoformat(),
            "data_notice": "All sites and data in this demonstration are fictional and synthetic.",
            "conventions": {
                "storage_time": "UTC",
                "presentation": "site-local (Europe/London)",
                "energy_unit": "kWh",
                "power_unit": "kW",
                "measured_vs_estimated": "Measured, estimated, forecast and commercial "
                "figures are reported in separate fields and never summed together.",
            },
            "sites": site_sections,
        }
    )
    body = json.dumps(content, sort_keys=True).encode()
    rep = Report(
        id=new_id("rpt"),
        report_type="operational",
        portfolio_id=portfolio_id,
        period_start=p_start,
        period_end=p_end,
        generated_by=user_id,
        content=content,
        content_sha256=hashlib.sha256(body).hexdigest(),
    )
    session.add(rep)
    session.flush()
    return rep


def to_csv(rep: Report) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(
        [
            "site_id",
            "date",
            "status",
            "measured_export_kwh",
            "estimated_export_kwh",
            "export_coverage",
            "flags",
            "source",
        ]
    )
    for s in rep.content["sites"]:
        for d in s["energy"]["daily"]:
            w.writerow(
                [
                    s["site_id"],
                    d["date"],
                    d["status"],
                    d["measured_export_kwh"],
                    d["estimated_export_kwh"],
                    d["export_coverage"],
                    ";".join(d["export_flags"]),
                    (d["sources"] or [""])[0],
                ]
            )
    return buf.getvalue()


def to_html(rep: Report, base_url: str = "") -> str:
    c = rep.content
    e = html.escape

    def link(u):
        return f'<a href="{e(base_url + u)}">source</a>' if u else ""

    def num(v, d=1):
        return "—" if v is None else f"{v:,.{d}f}"

    parts = [
        f"""<!doctype html><html><head><meta charset="utf-8"><title>{e(c["title"])}</title>
<style>body{{font-family:Inter,system-ui,sans-serif;color:#0f1b2d;margin:32px;max-width:1100px}}h1{{color:#0b1530}}
h2{{border-bottom:3px solid #f2b705;padding-bottom:4px}}table{{border-collapse:collapse;width:100%;margin:12px 0;font-size:13px}}
th,td{{border:1px solid #d6dbe3;padding:5px 8px;text-align:left}}th{{background:#eef1f5}}.warn{{color:#a35d00;font-weight:600}}
.crit{{color:#b3261e;font-weight:600}}.ok{{color:#1e7d4f}}.note{{background:#f6f7f9;padding:8px 12px;border-left:4px solid #0aa5c2}}
</style></head><body><h1>{e(c["title"])}</h1><p>Period {e(c["period"]["start_day"])} to {e(c["period"]["end_day"])} ·
generated {e(c["generated_at"])} · report {e(rep.id)} · SHA-256 <code>{rep.content_sha256[:16]}…</code></p>
<p class="note">{e(c["data_notice"])} {e(c["conventions"]["measured_vs_estimated"])}</p>"""
    ]
    for s in c["sites"]:
        parts.append(
            f"<h2>{e(s['name'])}</h2><p>DC {num(s['capacity']['dc_kwp'], 0)} kWp · AC {num(s['capacity']['ac_kw'], 0)} kW · export limit {num(s['capacity']['export_limit_kw'], 0)} kW</p>"
        )
        parts.append(
            "<h3>Measured export energy (settlement meter)</h3><table><tr><th>Date</th><th>Status</th><th>Measured kWh</th><th>Estimate incl. gap fill kWh</th><th>Coverage</th><th>Flags</th><th></th></tr>"
        )
        for d in s["energy"]["daily"]:
            cls = "ok" if d["status"] == "complete" else "warn"
            parts.append(
                f"<tr><td>{e(d['date'])}</td><td class='{cls}'>{e(d['status'])}</td><td>{num(d['measured_export_kwh'])}</td>"
                f"<td>{num(d['estimated_export_kwh'])}</td><td>{num((d['export_coverage'] or 0) * 100)}%</td>"
                f"<td>{e(', '.join(d['export_flags']))}</td><td>{link((d['sources'] or [''])[0])}</td></tr>"
            )
        parts.append(
            f"</table><p>Period measured export: <b>{num(s['energy']['period_measured_export_kwh'])} kWh</b> "
            f"({'complete' if s['energy']['period_complete'] else 'INCOMPLETE: ' + ', '.join(s['energy']['incomplete_days'])})</p>"
        )
        pr = s["performance"]["performance_ratio"]
        sy = s["performance"]["specific_yield"]
        parts.append(
            "<h3>Performance</h3><table><tr><th>Metric</th><th>Value</th><th>Status</th><th>Formula</th><th>Reasons / uncertainty</th></tr>"
        )
        for m in (sy, pr):
            unc = m.get("uncertainty") or {}
            parts.append(
                f"<tr><td>{e(m['name'])}</td><td>{num(m['value'], 3)} {e(m['unit'])}</td><td>{e(m['status'])}</td>"
                f"<td>{e(m['formula'])}</td><td>{e('; '.join(m['reasons'])) or e(json.dumps(unc))}</td></tr>"
            )
        parts.append(
            "</table><table><tr><th>Inverter</th><th>Measured kWh</th><th>Expected kWh</th><th>Index</th><th>Peer z</th><th>Irradiance basis</th></tr>"
        )
        for r in s["performance"]["inverters"]:
            parts.append(
                f"<tr><td>{e(r['asset_id'])}</td><td>{num(r['measured_kwh'])}</td><td>{num(r['expected_kwh'])}</td>"
                f"<td>{num(r['performance_index'], 3)}</td><td>{num(r.get('peer_robust_z'), 2)}</td><td>{e(r['irradiance_basis'])}</td></tr>"
            )
        parts.append(
            "</table><h3>Loss categories (kWh)</h3><table><tr><th>Category</th><th>kWh</th><th>Basis</th><th>Confidence</th></tr>"
        )
        for k, v in s["performance"]["losses"]["categories"].items():
            parts.append(
                f"<tr><td>{e(k)}</td><td>{num(v['kwh'])}</td><td>{e(v['basis'])}</td><td>{e(v['confidence'])}</td></tr>"
            )
        parts.append(
            "</table><h3>Alerts</h3><table><tr><th>Severity</th><th>Title</th><th>Status</th><th>Condition</th><th>Attribution</th><th>Rule</th><th></th></tr>"
        )
        for a in s["alerts"]:
            cls = "crit" if a["severity"] == "critical" else "warn"
            parts.append(
                f"<tr><td class='{cls}'>{e(a['severity'])}</td><td>{e(a['title'])}</td><td>{e(a['status'])}</td>"
                f"<td>{'ACTIVE' if a['condition_active'] else 'cleared'}</td><td>{e(a['attribution'])} ({e(a['attribution_confidence'])})</td>"
                f"<td>{e(a['rule'])}</td><td>{link(a['source'])}</td></tr>"
            )
        parts.append(
            "</table><h3>Maintenance</h3><table><tr><th>Work order</th><th>Status</th><th>Completed</th><th>Verification</th><th></th></tr>"
        )
        for w in s["maintenance"]:
            ver = (w.get("verification") or {}).get("reason", "—")
            parts.append(
                f"<tr><td>{e(w['title'])}</td><td>{e(w['status'])}</td><td>{e(w['completed_at'] or '—')}</td><td>{e(str(ver))}</td><td>{link(w['source'])}</td></tr>"
            )
        parts.append("</table>")
    parts.append(
        "<p class='note'>Completed work orders record work done; they do not certify electrical safety.</p></body></html>"
    )
    return "".join(parts)
