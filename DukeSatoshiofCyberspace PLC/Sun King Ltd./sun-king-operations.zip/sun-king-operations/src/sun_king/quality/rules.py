"""Validation of raw observations into cleaned values.

Each check appends a flag; the overall quality level is derived from the
worst flag. Raw observations are never modified — validation produces a
separate :class:`~sun_king.telemetry.models.CleanObservation`.

Flags
-----
``missing_value``        source reported no value                      → missing
``unit_mismatch``        unit dimension not valid for the type          → bad
``unknown_unit``         unit not recognised                            → bad
``out_of_range``         outside physical limits                        → bad
``implausible_rate``     change faster than physically plausible        → suspect
``night_irradiance``     irradiance at night above sensor offset band   → suspect
``night_offset_clamped`` small negative night irradiance clamped to 0    → good
``stuck_value``          identical value for N daytime samples           → suspect
``future_timestamp``     observation time ahead of ingestion            → bad
``late_arrival``         ingested long after observation time           → good (informational)
``out_of_order``         older than the latest already seen             → good (informational)
``revised``              newer revision of an existing reading          → good (informational)
``exceeds_rating``       above rated capacity by margin                 → suspect
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from sun_king.core.units import UnitError, dimension_of, to_canonical
from sun_king.telemetry.types import MEASUREMENT_TYPES

VALIDATION_VERSION = "qc-1.3"

SEVERITY = {
    "missing_value": "missing",
    "unit_mismatch": "bad",
    "unknown_unit": "bad",
    "unknown_measurement_type": "bad",
    "out_of_range": "bad",
    "future_timestamp": "bad",
    "implausible_rate": "suspect",
    "night_irradiance": "suspect",
    "stuck_value": "suspect",
    "exceeds_rating": "suspect",
    "sensor_disagreement": "suspect",
}
LEVEL_ORDER = {"good": 0, "suspect": 1, "bad": 2, "missing": 3}

# canonical-unit physical limits
RANGES: dict[str, tuple[float, float]] = {
    "dc_voltage": (0, 1600),
    "dc_current": (-5, 3000),
    "dc_power": (-50, 1e5),
    "ac_power": (-500, 1e5),
    "poa_irradiance": (-20, 1600),
    "ghi": (-20, 1500),
    "module_temperature": (-40, 100),
    "ambient_temperature": (-40, 50),
    "inverter_temperature": (-40, 110),
    "wind_speed": (0, 75),
    "tracker_angle": (-90, 90),
    "tracker_setpoint": (-90, 90),
    "soiling_ratio": (0.5, 1.05),
    "battery_soc": (0, 1),
    "battery_temperature": (-30, 70),
    "export_energy": (0, 1e12),
    "import_energy": (0, 1e12),
    "ac_energy": (0, 1e12),
}
# max plausible change per second in canonical units
MAX_RATE: dict[str, float] = {
    "module_temperature": 0.2,  # °C/s
    "ambient_temperature": 0.05,
    "inverter_temperature": 0.3,
}
NIGHT_IRRADIANCE_BAND = 10.0  # W/m2: sensor thermal offset band at night
STUCK_SAMPLES = 6
FUTURE_TOLERANCE_S = 120
LATE_AFTER_S = 1800


@dataclass
class StreamContext:
    """What the validator knows about a stream beyond the single observation."""

    rated_kw: float | None = None
    sun_up: bool | None = None  # computed from site location/time when available
    previous_value: float | None = None
    previous_time: datetime | None = None
    latest_seen_time: datetime | None = None
    recent_values: list[float] = field(default_factory=list)  # most recent first, daytime only


@dataclass
class ValidationResult:
    value: float | None
    unit: str
    quality: str
    flags: list[str]


def validate(
    measurement_type: str,
    value: float | None,
    unit: str,
    observation_time: datetime,
    ingestion_time: datetime,
    ctx: StreamContext | None = None,
    pre_flags: list[str] | None = None,
) -> ValidationResult:
    ctx = ctx or StreamContext()
    flags: list[str] = list(pre_flags or [])
    mt = MEASUREMENT_TYPES.get(measurement_type)
    if mt is None:
        return ValidationResult(None, unit, "bad", flags + ["unknown_measurement_type"])
    try:
        dim = dimension_of(unit)
    except UnitError:
        return ValidationResult(None, unit, "bad", flags + ["unknown_unit"])
    if dim != mt.dimension:
        return ValidationResult(None, unit, "bad", flags + ["unit_mismatch"])

    if (observation_time - ingestion_time).total_seconds() > FUTURE_TOLERANCE_S:
        flags.append("future_timestamp")
    if (ingestion_time - observation_time).total_seconds() > LATE_AFTER_S:
        flags.append("late_arrival")
    if ctx.latest_seen_time is not None and observation_time < ctx.latest_seen_time:
        flags.append("out_of_order")

    if value is None:
        flags.append("missing_value")
        return ValidationResult(None, _canon_unit(unit), _level(flags), flags)

    v, cu = to_canonical(float(value), unit)
    lo, hi = RANGES.get(measurement_type, (float("-inf"), float("inf")))
    if not (lo <= v <= hi):
        flags.append("out_of_range")
        return ValidationResult(None, cu, _level(flags), flags)

    if measurement_type in ("poa_irradiance", "ghi") and ctx.sun_up is False:
        if v < 0 or v <= NIGHT_IRRADIANCE_BAND:
            if v != 0:
                flags.append("night_offset_clamped")
            v = 0.0
        else:
            flags.append("night_irradiance")
    elif measurement_type in ("poa_irradiance", "ghi") and v < 0:
        flags.append("night_offset_clamped")
        v = 0.0

    if measurement_type in MAX_RATE and ctx.previous_value is not None and ctx.previous_time is not None:
        dt = abs((observation_time - ctx.previous_time).total_seconds())
        if 0 < dt <= 3600 and abs(v - ctx.previous_value) / dt > MAX_RATE[measurement_type]:
            flags.append("implausible_rate")

    if (
        measurement_type in ("poa_irradiance", "ghi", "module_temperature", "ambient_temperature")
        and ctx.sun_up
        and v > 20
        and len(ctx.recent_values) >= STUCK_SAMPLES - 1
        and all(abs(x - v) < 1e-9 for x in ctx.recent_values[: STUCK_SAMPLES - 1])
    ):
        flags.append("stuck_value")

    if measurement_type in ("ac_power", "dc_power") and ctx.rated_kw and v > ctx.rated_kw * 1.15:
        flags.append("exceeds_rating")

    return ValidationResult(v, cu, _level(flags), flags)


def _canon_unit(unit: str) -> str:
    try:
        return to_canonical(0.0, unit)[1]
    except UnitError:
        return unit


def _level(flags: list[str]) -> str:
    level = "good"
    for f in flags:
        lv = SEVERITY.get(f, "good")
        if LEVEL_ORDER[lv] > LEVEL_ORDER[level]:
            level = lv
    return level
