"""Sun position helper used by validation (pvlib adapter, cached per site/minute)."""

from __future__ import annotations

from datetime import datetime
from functools import lru_cache

import pandas as pd

from sun_king.adapters.pvmodel import solar_elevation


@lru_cache(maxsize=50_000)
def _elev(lat: float, lon: float, minute_ts: int) -> float:
    t = pd.Timestamp(minute_ts * 60, unit="s", tz="UTC")
    return float(solar_elevation(lat, lon, pd.DatetimeIndex([t]))[0])


def sun_is_up(lat: float, lon: float, t: datetime, threshold_deg: float = 0.0) -> bool:
    return _elev(round(lat, 3), round(lon, 3), int(t.timestamp() // 60)) > threshold_deg
