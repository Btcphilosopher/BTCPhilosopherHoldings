"""Leakage-safe feature construction for generation forecasting.

Every input carries an *availability time*. :class:`LeakageGuard` refuses to
build a row whose inputs became available after the forecast issue time.
That excludes, by construction:

* weather observations after issue time (only NWP issues available at issue time are used);
* measurements ingested after issue time (late data is not visible to earlier forecasts);
* corrected/revised measurements made later (revisions carry a later ingestion time);
* curtailment records or maintenance outcomes created after issue time.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from sun_king.assets.models import Site
from sun_king.assets.service import site_inverters
from sun_king.energy.models import CurtailmentRecord
from sun_king.forecasting.physical import clear_sky_pv, pv_ac_from_ghi, site_specs
from sun_king.telemetry.models import CleanObservation

STEP = "30min"


class LeakageError(AssertionError):
    pass


class LeakageGuard:
    def __init__(self, issue_time: datetime):
        self.issue_time = pd.Timestamp(issue_time)

    def check(self, name: str, available_times) -> None:
        av = pd.to_datetime(pd.Series(available_times), utc=True)
        if (av > self.issue_time).any():
            raise LeakageError(f"feature {name!r} uses data available after issue time {self.issue_time}")


@dataclass
class SiteHistory:
    """Observed site PV AC (sum of inverters) on a 30-min grid, with availability (ingestion) times."""

    pv_kw: pd.Series
    available_at: pd.Series
    curtailed: pd.Series
    ghi_obs: pd.Series
    tamb_obs: pd.Series


def load_history(session: Session, site_id: str, start: datetime, end: datetime) -> SiteHistory:
    invs = [i.asset_id for i in site_inverters(session, site_id)]
    rows = session.execute(
        select(
            CleanObservation.asset_id,
            CleanObservation.observation_time,
            CleanObservation.value,
            CleanObservation.ingestion_time,
            CleanObservation.quality,
            CleanObservation.measurement_type,
        ).where(
            CleanObservation.site_id == site_id,
            CleanObservation.observation_time >= start,
            CleanObservation.observation_time < end,
            CleanObservation.measurement_type.in_(["ac_power", "ghi", "ambient_temperature"]),
        )
    ).all()
    grid = pd.date_range(pd.Timestamp(start).floor(STEP), end, freq=STEP, inclusive="left")
    df = pd.DataFrame(rows, columns=["asset", "t", "v", "ing", "q", "mt"])
    if df.empty:
        nan = pd.Series(np.nan, index=grid)
        nat = pd.Series(pd.NaT, index=grid, dtype="datetime64[ns, UTC]")
        return SiteHistory(nan, nat, pd.Series(False, index=grid), nan, nan)
    df["t"] = pd.to_datetime(df["t"], utc=True)
    df["ing"] = pd.to_datetime(df["ing"], utc=True)
    df.loc[df.q != "good", "v"] = np.nan
    ac = df[(df.mt == "ac_power") & df.asset.isin(invs)]
    bins = ac.assign(b=ac.t.dt.floor(STEP))
    per_inv = bins.pivot_table(index="b", columns="asset", values="v", aggfunc="mean")
    per_inv = per_inv.reindex(index=grid, columns=invs)
    pv = per_inv.sum(axis=1, min_count=len(invs))
    avail = bins.groupby("b")["ing"].max().reindex(grid)
    ghi = df[df.mt == "ghi"].assign(b=lambda d: d.t.dt.floor(STEP)).groupby("b")["v"].mean().reindex(grid)
    tamb = (
        df[df.mt == "ambient_temperature"]
        .assign(b=lambda d: d.t.dt.floor(STEP))
        .groupby("b")["v"]
        .mean()
        .reindex(grid)
    )
    curt = pd.Series(False, index=grid)
    for c in session.scalars(select(CurtailmentRecord).where(CurtailmentRecord.site_id == site_id)):
        curt |= (grid + pd.Timedelta(STEP) > pd.Timestamp(c.start_time)) & (grid < pd.Timestamp(c.end_time))
    return SiteHistory(pv, avail, curt, ghi, tamb)


def build_rows(
    session: Session,
    site: Site,
    issue: datetime,
    targets: pd.DatetimeIndex,
    nwp: list,
    hist: SiteHistory,
    specs=None,
    horizon_type: str = "intraday",
) -> pd.DataFrame:
    """Feature rows for one issue time. ``nwp`` are WeatherForecastPoints from an issue available at ``issue``."""
    guard = LeakageGuard(issue)
    specs = specs or site_specs(session, site.id)
    if nwp:
        guard.check("nwp", [p.available_time for p in nwp])
        nw = pd.DataFrame(
            [{"t": p.valid_time, "ghi": p.ghi_wm2, "ta": p.temp_air_c, "ws": p.wind_speed_ms} for p in nwp]
        )
        nw["t"] = pd.to_datetime(nw["t"], utc=True)
        nw = nw.set_index("t").sort_index()
        # interval-mean: NWP is instantaneous at :00/:30; target bins are [t, t+30m)
        nw = nw.reindex(nw.index.union(targets + pd.Timedelta("15min"))).interpolate(limit_area="inside")
        nw_t = nw.reindex(targets + pd.Timedelta("15min"))
        nw_t.index = targets
        nwp_kw = pv_ac_from_ghi(site, specs, nw_t["ghi"], nw_t["ta"], nw_t["ws"])
        nwp_issue = nwp[0].issue_time
    else:
        nwp_kw = pd.Series(np.nan, index=targets)
        nwp_issue = None
    mid = targets + pd.Timedelta("15min")
    cs = clear_sky_pv(site, specs, mid)
    cs.index = targets
    # persistence inputs, restricted to data available at issue time
    visible = hist.available_at.notna() & (hist.available_at <= pd.Timestamp(issue))
    obs_vis = hist.pv_kw.where(visible)
    last_bin = pd.Timestamp(issue).floor(STEP) - pd.Timedelta(STEP)
    cs_last = clear_sky_pv(site, specs, pd.DatetimeIndex([last_bin + pd.Timedelta("15min")])).iloc[0]
    last = obs_vis.get(last_bin, np.nan)
    kt_last = float(last / cs_last) if cs_last and cs_last > 20 and pd.notna(last) else np.nan
    persistence_kw = (
        (cs * kt_last).where(cs > 0, 0.0) if not np.isnan(kt_last) else pd.Series(np.nan, index=targets)
    )
    if horizon_type == "day_ahead":
        lag = obs_vis.reindex(targets - pd.Timedelta(days=2)).to_numpy()  # value 48 h earlier is available
        persistence_kw = pd.Series(lag, index=targets)
    guard.check("persistence", hist.available_at[visible & (hist.available_at.index <= last_bin)].dropna())
    from sun_king.adapters.pvmodel import solar_elevation

    elev = solar_elevation(site.latitude, site.longitude, mid)
    rows = pd.DataFrame(
        {
            "target_time": targets,
            "issue_time": pd.Timestamp(issue),
            "horizon_h": (targets - pd.Timestamp(issue)).total_seconds() / 3600,
            "cs_kw": cs.to_numpy(),
            "nwp_kw": nwp_kw.to_numpy(),
            "persistence_kw": persistence_kw.to_numpy(),
            "kt_last": kt_last,
            "elevation": elev,
            "actual_kw": hist.pv_kw.reindex(targets).to_numpy(),
            "curtailed": hist.curtailed.reindex(targets).fillna(False).to_numpy(),
            "nwp_issue_time": nwp_issue,
        }
    )
    return rows


def intraday_targets(issue: datetime, hours: int = 6) -> pd.DatetimeIndex:
    start = pd.Timestamp(issue).ceil(STEP)
    return pd.date_range(start, start + pd.Timedelta(hours=hours), freq=STEP, inclusive="left")


def day_ahead_targets(site: Site, issue: datetime) -> pd.DatetimeIndex:
    from sun_king.core.timeutil import local_date, local_day_bounds

    d = local_date(issue, site.timezone) + timedelta(days=1)
    s, e = local_day_bounds(d, site.timezone)
    return pd.date_range(s, e, freq=STEP, inclusive="left")
