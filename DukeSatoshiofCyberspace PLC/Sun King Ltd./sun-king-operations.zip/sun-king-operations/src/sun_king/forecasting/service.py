"""Intraday and day-ahead generation forecasts with intervals, provenance and baselines.

Models
------
* ``persistence`` — intraday: clear-sky-index persistence of the last fully
  available 30-min interval; day-ahead: same time two days earlier (the most
  recent same-time value available at issue time).
* ``nwp_physical`` — weather-based baseline: NWP GHI → pvlib site model.
* ``gbm_quantile`` — scikit-learn GradientBoosting (quantile loss, α = 0.1/0.5/0.9)
  on [nwp_kw, cs_kw, persistence_kw, horizon, elevation]. Used only when it was
  trained on enough rows; otherwise the forecast falls back to the physical
  baseline with empirical residual intervals and says so (``status``).

Quantity: site PV AC power (sum of inverter AC), kW, 30-min interval mean.
Battery operation is not part of this quantity.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from sqlalchemy.orm import Session

from sun_king.assets.models import Site
from sun_king.core.ids import new_id
from sun_king.forecasting.features import (
    build_rows,
    day_ahead_targets,
    intraday_targets,
    load_history,
)
from sun_king.forecasting.models import Forecast, ForecastValue, ModelRegistryEntry, WeatherForecastValue
from sun_king.forecasting.physical import site_specs

MODEL_VERSION = "fc-1.0"
FEATURES = ["nwp_kw", "cs_kw", "persistence_kw", "horizon_h", "elevation"]
MIN_TRAIN_ROWS = 150


class ForecastModelError(RuntimeError):
    pass


@dataclass
class TrainedModel:
    models: dict[float, GradientBoostingRegressor] | None
    status: str
    n_train: int
    residual_q: tuple[float, float]  # relative residual quantiles of the physical baseline (p10, p90)
    train_window: dict
    capacity_kw: float
    notes: list[str]

    def predict(self, rows: pd.DataFrame) -> pd.DataFrame:
        base = rows["nwp_kw"].fillna(rows["cs_kw"] * 0.5)
        if self.models is not None:
            X = rows[FEATURES].copy()
            X["persistence_kw"] = X["persistence_kw"].fillna(X["nwp_kw"])
            X["nwp_kw"] = X["nwp_kw"].fillna(X["cs_kw"] * 0.5)
            preds = {q: np.clip(m.predict(X), 0, None) for q, m in self.models.items()}
            p10, p50, p90 = np.minimum(preds[0.1], preds[0.5]), preds[0.5], np.maximum(preds[0.9], preds[0.5])
        else:
            p50 = base.to_numpy()
            p10 = np.clip(p50 * (1 + self.residual_q[0]), 0, None)
            p90 = p50 * (1 + self.residual_q[1])
        cap = rows["cs_kw"].to_numpy() * 1.15 + 1
        night = rows["cs_kw"].to_numpy() <= 0.5
        out = pd.DataFrame(
            {"p10": np.minimum(p10, cap), "p50": np.minimum(p50, cap), "p90": np.minimum(p90, cap)},
            index=rows.index,
        )
        out.loc[night, :] = 0.0
        return out


def training_rows(
    session: Session,
    site: Site,
    nwp_adapter,
    start: datetime,
    end: datetime,
    horizon_type: str = "intraday",
    hist=None,
) -> pd.DataFrame:
    hist = hist or load_history(session, site.id, start - timedelta(days=3), end + timedelta(days=2))
    specs = site_specs(session, site.id)
    frames = []
    if horizon_type == "intraday":
        issues = pd.date_range(pd.Timestamp(start).ceil("1h"), end, freq="1h")
        from sun_king.adapters.pvmodel import solar_elevation

        el = solar_elevation(site.latitude, site.longitude, issues + pd.Timedelta("2h"))
        issues = issues[el > -5]
    else:
        from sun_king.core.timeutil import local_date

        days = pd.date_range(start, end, freq="1D")
        issues = pd.DatetimeIndex(
            [
                pd.Timestamp(f"{local_date(d.to_pydatetime(), site.timezone)} 10:00")
                .tz_localize(site.timezone)
                .tz_convert("UTC")
                for d in days
            ]
        )
    for iss in issues:
        issue = iss.to_pydatetime()
        nwp = nwp_adapter.latest_issue(site.id, issue)
        tg = intraday_targets(issue) if horizon_type == "intraday" else day_ahead_targets(site, issue)
        tg = tg[tg < pd.Timestamp(end)]
        if len(tg) == 0:
            continue
        frames.append(build_rows(session, site, issue, tg, nwp, hist, specs, horizon_type))
    if not frames:
        return pd.DataFrame(columns=FEATURES + ["actual_kw"])
    return pd.concat(frames, ignore_index=True)


def fit(rows: pd.DataFrame, capacity_kw: float, random_state: int = 0) -> TrainedModel:
    use = rows[(rows["cs_kw"] > 1) & rows["actual_kw"].notna() & ~rows["curtailed"].astype(bool)].copy()
    notes = []
    excluded = len(rows[(rows["cs_kw"] > 1)]) - len(use)
    if excluded:
        notes.append(f"{excluded} daylight rows excluded (missing actuals or recorded curtailment)")
    rel = ((use["actual_kw"] - use["nwp_kw"]) / use["nwp_kw"].clip(lower=20)).dropna()
    rq = (float(rel.quantile(0.1)), float(rel.quantile(0.9))) if len(rel) >= 20 else (-0.35, 0.35)
    tw = {
        "start": str(use["issue_time"].min()) if len(use) else None,
        "end": str(use["issue_time"].max()) if len(use) else None,
    }
    if len(use) < MIN_TRAIN_ROWS:
        notes.append(
            f"only {len(use)} usable rows (< {MIN_TRAIN_ROWS}); using physical baseline with empirical intervals"
        )
        return TrainedModel(None, "baseline_only", len(use), rq, tw, capacity_kw, notes)
    if use["actual_kw"].std() < 1e-6:
        notes.append("target has no variance; model not trained")
        return TrainedModel(None, "baseline_only", len(use), rq, tw, capacity_kw, notes)
    X = use[FEATURES].copy()
    X["persistence_kw"] = X["persistence_kw"].fillna(X["nwp_kw"])
    X["nwp_kw"] = X["nwp_kw"].fillna(X["cs_kw"] * 0.5)
    y = use["actual_kw"].to_numpy()
    models = {}
    for q in (0.1, 0.5, 0.9):
        m = GradientBoostingRegressor(
            loss="quantile",
            alpha=q,
            n_estimators=150,
            max_depth=3,
            learning_rate=0.05,
            subsample=0.8,
            min_samples_leaf=10,
            random_state=random_state,
        )
        m.fit(X, y)
        if not np.isfinite(m.train_score_).all():
            raise ForecastModelError("training diverged (non-finite loss)")
        models[q] = m
    return TrainedModel(models, "ok", len(use), rq, tw, capacity_kw, notes)


def metrics(df: pd.DataFrame, capacity_kw: float, pred_col: str) -> dict:
    d = df[df["actual_kw"].notna() & (df["cs_kw"] > 1) & ~df["curtailed"].astype(bool) & df[pred_col].notna()]
    if d.empty:
        return {"n": 0}
    err = d[pred_col] - d["actual_kw"]
    return {
        "n": int(len(d)),
        "mae_kw": round(float(err.abs().mean()), 2),
        "rmse_kw": round(float(np.sqrt((err**2).mean())), 2),
        "nmae_capacity": round(float(err.abs().mean() / capacity_kw), 4),
        "bias_kw": round(float(err.mean()), 2),
    }


def evaluate(rows: pd.DataFrame, model: TrainedModel, capacity_kw: float, horizon_type: str) -> dict:
    pred = model.predict(rows)
    df = rows.copy()
    df["model_p50"], df["model_p10"], df["model_p90"] = pred["p50"], pred["p10"], pred["p90"]
    out = {
        "model": metrics(df, capacity_kw, "model_p50"),
        "persistence": metrics(df, capacity_kw, "persistence_kw"),
        "nwp_physical": metrics(df, capacity_kw, "nwp_kw"),
    }
    d = df[df["actual_kw"].notna() & (df["cs_kw"] > 1) & ~df["curtailed"].astype(bool)]
    if len(d):
        out["interval_coverage_p10_p90"] = round(
            float(((d.actual_kw >= d.model_p10) & (d.actual_kw <= d.model_p90)).mean()), 3
        )
        out["nominal_coverage"] = 0.8
    for name in ("persistence", "nwp_physical"):
        b = out[name].get("mae_kw")
        if b and out["model"].get("mae_kw") is not None:
            out[f"skill_vs_{name}"] = round(1 - out["model"]["mae_kw"] / b, 3)
    bins = [0, 1, 3, 6.01] if horizon_type == "intraday" else [0, 24, 36, 60]
    labels = ["0–1 h", "1–3 h", "3–6 h"] if horizon_type == "intraday" else ["<24 h", "24–36 h", "36+ h"]
    df["hbin"] = pd.cut(df["horizon_h"], bins=bins, labels=labels, include_lowest=True)
    out["by_horizon"] = {
        str(k): {
            "model": metrics(g, capacity_kw, "model_p50"),
            "persistence": metrics(g, capacity_kw, "persistence_kw"),
            "nwp_physical": metrics(g, capacity_kw, "nwp_kw"),
        }
        for k, g in df.groupby("hbin", observed=True)
    }
    lv = pd.cut(
        df["actual_kw"] / capacity_kw,
        [-0.01, 0.1, 0.3, 2],
        labels=["low (<10% cap.)", "mid (10–30%)", "high (>30%)"],
    )
    out["by_generation_level"] = {
        str(k): {
            "model": metrics(g, capacity_kw, "model_p50"),
            "persistence": metrics(g, capacity_kw, "persistence_kw"),
        }
        for k, g in df.groupby(lv, observed=True)
    }
    miss = df["persistence_kw"].isna() & (df["cs_kw"] > 1)
    out["missing_input_rows"] = {
        "persistence_missing": int(miss.sum()),
        "model_when_persistence_missing": metrics(df[miss], capacity_kw, "model_p50"),
    }
    out["excluded_curtailed_rows"] = int((df["curtailed"].astype(bool) & (df["cs_kw"] > 1)).sum())
    return out


def train_and_evaluate(
    session: Session,
    site: Site,
    nwp_adapter,
    start: datetime,
    end: datetime,
    horizon_type: str = "intraday",
    split: float = 0.7,
) -> dict:
    """Time-ordered hold-out: train on the earlier ``split`` of the window, evaluate on the rest."""
    hist = load_history(session, site.id, start - timedelta(days=3), end + timedelta(days=2))
    rows = training_rows(session, site, nwp_adapter, start, end, horizon_type, hist)
    if rows.empty or rows["actual_kw"].notna().sum() == 0:
        raise ForecastModelError("no observed generation in the training window")
    cut = pd.Timestamp(start) + (pd.Timestamp(end) - pd.Timestamp(start)) * split
    # A target must be observed before the cut-off for the row to be in training (no future actuals).
    train = rows[(rows.issue_time < cut) & (rows.target_time < cut)]
    test = rows[rows.issue_time >= cut]
    model = fit(train, site.ac_capacity_kw)
    ev = evaluate(test, model, site.ac_capacity_kw, horizon_type)
    ev.update(
        train_rows=model.n_train,
        test_rows=int(len(test)),
        status=model.status,
        notes=model.notes,
        split_time=str(cut),
        horizon_type=horizon_type,
        site_id=site.id,
    )
    final = fit(rows[rows.target_time < pd.Timestamp(end)], site.ac_capacity_kw)
    entry = ModelRegistryEntry(
        id=new_id("mdl"),
        name=f"gbm_quantile_{horizon_type}_{site.code}",
        version=MODEL_VERSION,
        purpose=f"{horizon_type} site PV forecast",
        train_window=final.train_window,
        features=FEATURES,
        evaluation=_jsonable(ev),
        status=final.status,
    )
    session.add(entry)
    session.flush()
    return {"model": final, "evaluation": ev, "registry_id": entry.id}


def _jsonable(o):
    if isinstance(o, dict):
        return {str(k): _jsonable(v) for k, v in o.items()}
    if isinstance(o, list | tuple):
        return [_jsonable(v) for v in o]
    if isinstance(o, float | np.floating):
        return None if np.isnan(o) else float(o)
    if isinstance(o, np.integer):
        return int(o)
    return o


def issue_forecast(
    session: Session,
    site: Site,
    nwp_adapter,
    issue: datetime,
    model: TrainedModel,
    horizon_type: str = "day_ahead",
    kind: str = "forecast",
    observed_weather: bool = False,
) -> Forecast:
    """Persist a forecast issued at ``issue``. ``kind='retrospective'`` uses observed GHI instead of NWP."""
    hist = load_history(session, site.id, issue - timedelta(days=3), issue + timedelta(days=2))
    targets = intraday_targets(issue) if horizon_type == "intraday" else day_ahead_targets(site, issue)
    if observed_weather:
        from sun_king.adapters.base import WeatherForecastPoint

        g = hist.ghi_obs.reindex(targets).interpolate(limit=2)
        ta = hist.tamb_obs.reindex(targets).interpolate(limit=4)
        nwp = [
            WeatherForecastPoint(
                issue, issue, t.to_pydatetime(), float(g.get(t, 0) or 0), float(ta.get(t, 6) or 6), 3.0
            )
            for t in targets
        ]
        wx_src, wx_issue = "observed (retrospective)", None
        kind = "retrospective"
    else:
        nwp = nwp_adapter.latest_issue(site.id, issue)
        wx_src, wx_issue = nwp_adapter.source, nwp[0].issue_time if nwp else None
        for p in nwp:
            session.add(
                WeatherForecastValue(
                    site_id=site.id,
                    source=nwp_adapter.source,
                    issue_time=p.issue_time,
                    available_time=p.available_time,
                    valid_time=p.valid_time,
                    ghi_wm2=p.ghi_wm2,
                    temp_air_c=p.temp_air_c,
                    wind_speed_ms=p.wind_speed_ms,
                )
            )
    rows = (
        build_rows(session, site, issue, targets, nwp, hist, horizon_type=horizon_type)
        if not observed_weather
        else _retro_rows(session, site, issue, targets, nwp, hist, horizon_type)
    )
    pred = model.predict(rows)
    fc = Forecast(
        id=new_id("fc"),
        site_id=site.id,
        kind=kind,
        horizon_type=horizon_type,
        issue_time=issue,
        target_start=targets[0].to_pydatetime(),
        target_end=(targets[-1] + pd.Timedelta("30min")).to_pydatetime(),
        model_name="gbm_quantile" if model.models else "nwp_physical+empirical_intervals",
        model_version=MODEL_VERSION,
        weather_source=wx_src,
        weather_issue_time=wx_issue,
        quantity="site_pv_ac_kw",
        interval_s=1800,
        status=model.status,
        notes={
            "train_rows": model.n_train,
            "train_window": model.train_window,
            "notes": model.notes,
            "provenance": "NWP issue available at forecast issue time only"
            if kind == "forecast"
            else "RETROSPECTIVE: uses observed weather; not a forecast",
        },
    )
    session.add(fc)
    session.flush()
    for i, t in enumerate(targets):
        session.add(
            ForecastValue(
                forecast_id=fc.id,
                target_time=t.to_pydatetime(),
                p10_kw=round(float(pred["p10"].iloc[i]), 2),
                p50_kw=round(float(pred["p50"].iloc[i]), 2),
                p90_kw=round(float(pred["p90"].iloc[i]), 2),
                baseline_persistence_kw=None
                if pd.isna(rows["persistence_kw"].iloc[i])
                else round(float(rows["persistence_kw"].iloc[i]), 2),
                baseline_weather_kw=None
                if pd.isna(rows["nwp_kw"].iloc[i])
                else round(float(rows["nwp_kw"].iloc[i]), 2),
            )
        )
    session.flush()
    return fc


def _retro_rows(session, site, issue, targets, pts, hist, horizon_type):
    from sun_king.forecasting.features import build_rows as br

    # Retrospective runs deliberately bypass the leakage guard by declaring availability = issue.
    return br(session, site, issue, targets, pts, hist, horizon_type=horizon_type)
