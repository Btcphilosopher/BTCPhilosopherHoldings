"""Forecasts carry issue time, model version and weather-input provenance.

``kind`` separates genuine forecasts (inputs available at issue time) from
retrospective model runs that use observed weather.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Float, ForeignKey, Index, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from sun_king.core.db import Base, JSONType, UTCDateTime
from sun_king.core.timeutil import utcnow


class WeatherForecastValue(Base):
    __tablename__ = "weather_forecast_values"
    __table_args__ = (Index("ix_wfc_site_issue", "site_id", "issue_time", "valid_time"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"))
    source: Mapped[str] = mapped_column(String(64))
    issue_time: Mapped[datetime] = mapped_column(UTCDateTime)
    available_time: Mapped[datetime] = mapped_column(UTCDateTime)  # when we could first use it
    valid_time: Mapped[datetime] = mapped_column(UTCDateTime)
    ghi_wm2: Mapped[float] = mapped_column(Float)
    temp_air_c: Mapped[float] = mapped_column(Float)
    wind_speed_ms: Mapped[float] = mapped_column(Float)
    cloud_cover: Mapped[float | None] = mapped_column(Float)


class Forecast(Base):
    __tablename__ = "forecasts"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), index=True)
    kind: Mapped[str] = mapped_column(String(16))  # forecast | retrospective
    horizon_type: Mapped[str] = mapped_column(String(16))  # intraday | day_ahead
    issue_time: Mapped[datetime] = mapped_column(UTCDateTime)
    target_start: Mapped[datetime] = mapped_column(UTCDateTime)
    target_end: Mapped[datetime] = mapped_column(UTCDateTime)
    model_name: Mapped[str] = mapped_column(String(64))
    model_version: Mapped[str] = mapped_column(String(32))
    weather_source: Mapped[str | None] = mapped_column(String(64))
    weather_issue_time: Mapped[datetime | None] = mapped_column(UTCDateTime)
    quantity: Mapped[str] = mapped_column(String(32), default="site_export_kw")
    interval_s: Mapped[int] = mapped_column(Integer, default=1800)
    status: Mapped[str] = mapped_column(String(16), default="ok")
    notes: Mapped[dict] = mapped_column(JSONType, default=dict)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class ForecastValue(Base):
    __tablename__ = "forecast_values"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    forecast_id: Mapped[str] = mapped_column(ForeignKey("forecasts.id"), index=True)
    target_time: Mapped[datetime] = mapped_column(UTCDateTime)
    p10_kw: Mapped[float] = mapped_column(Float)
    p50_kw: Mapped[float] = mapped_column(Float)
    p90_kw: Mapped[float] = mapped_column(Float)
    baseline_persistence_kw: Mapped[float | None] = mapped_column(Float)
    baseline_weather_kw: Mapped[float | None] = mapped_column(Float)


class ModelRegistryEntry(Base):
    __tablename__ = "model_registry"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(64))
    version: Mapped[str] = mapped_column(String(32))
    purpose: Mapped[str] = mapped_column(String(64))
    trained_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    train_window: Mapped[dict] = mapped_column(JSONType, default=dict)
    features: Mapped[list] = mapped_column(JSONType, default=list)
    evaluation: Mapped[dict] = mapped_column(JSONType, default=dict)
    status: Mapped[str] = mapped_column(String(16), default="candidate")
