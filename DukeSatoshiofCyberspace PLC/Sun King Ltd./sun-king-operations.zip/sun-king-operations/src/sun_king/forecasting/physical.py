"""Weather-based physical baseline: forecast (or observed) GHI → site PV AC power via pvlib."""

from __future__ import annotations

import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from sun_king.adapters import pvmodel
from sun_king.assets.models import Asset, PVSystemConfig, Site
from sun_king.performance.analysis import _spec


def site_specs(session: Session, site_id: str):
    cfgs = session.scalars(select(PVSystemConfig)).all()
    invs = {
        a.asset_id: a
        for a in session.scalars(
            select(Asset).where(Asset.site_id == site_id, Asset.asset_type == "inverter")
        )
    }
    return [_spec(c, invs[c.inverter_asset_id]) for c in cfgs if c.inverter_asset_id in invs]


def pv_ac_from_ghi(site: Site, specs, ghi: pd.Series, temp_air: pd.Series, wind: pd.Series) -> pd.Series:
    """Sum of inverter AC (kW) for the given GHI/temperature/wind series."""
    times = ghi.index
    solpos = pvmodel.solar_position(site.latitude, site.longitude, site.elevation_m, times)
    sky = pvmodel.decompose_ghi(ghi.clip(lower=0).fillna(0), solpos)
    total = pd.Series(0.0, index=times)
    for spec, inv in specs:
        poa = pvmodel.poa_irradiance(spec, sky, solpos, site.albedo)
        tc = pvmodel.cell_temperature(spec, poa, temp_air.fillna(6), wind.fillna(3))
        total = total + pvmodel.expected_ac_from_poa(spec, inv, poa, tc)["ac_kw"]
    return total


def clear_sky_pv(site: Site, specs, times: pd.DatetimeIndex) -> pd.Series:
    cs = pvmodel.clearsky(site.latitude, site.longitude, site.elevation_m, times)
    return pv_ac_from_ghi(site, specs, cs["ghi"], pd.Series(8.0, index=times), pd.Series(3.0, index=times))
