"""Cleaning benefit and scenario estimation.

A before/after output change is *not* proof of cleaning benefit. The benefit
estimate compares the **weather-adjusted performance index** (measured /
expected from measured irradiance and temperature) in comparable windows
before and after the cleaning, using only intervals that:

* have POA ≥ ``min_poa`` W/m² and solar elevation ≥ 10°,
* are not curtailed and not in fault/no-telemetry states,
* fall within ``window_days`` either side, excluding the cleaning day.

The result reports the index change with a bootstrap confidence interval. If
the soiling-station ratio is available it is reported alongside as an
independent indicator. When too few comparable intervals exist the estimate
is withheld.
"""

from __future__ import annotations

from datetime import date, timedelta

import numpy as np
import pandas as pd
from sqlalchemy.orm import Session

from sun_king.assets.models import Site
from sun_king.core.timeutil import local_day_bounds
from sun_king.performance.analysis import classify_intervals, run_site_model


def cleaning_benefit(
    session: Session,
    site_id: str,
    cleaned_on: date,
    window_days: int = 5,
    min_poa: float = 150,
    min_intervals: int = 24,
    seed: int = 0,
) -> dict:
    site = session.get(Site, site_id)
    s, _ = local_day_bounds(cleaned_on - timedelta(days=window_days), site.timezone)
    _, e = local_day_bounds(cleaned_on + timedelta(days=window_days), site.timezone)
    cs, ce = local_day_bounds(cleaned_on, site.timezone)
    run = run_site_model(session, site_id, s, e)
    from sun_king.adapters.pvmodel import solar_elevation

    elev = pd.Series(solar_elevation(site.latitude, site.longitude, run.grid), index=run.grid)
    meas_tot, exp_tot = [], []
    for iid, ex in run.expected.items():
        cls = classify_intervals(run, iid)
        ok = (cls == "producing") & (ex["poa"] >= min_poa) & (elev >= 10)
        meas_tot.append(run.measured_ac[iid].where(ok))
        exp_tot.append(ex["ac_kw"].where(ok))
    m = pd.concat(meas_tot, axis=1).sum(axis=1, min_count=len(meas_tot))
    x = pd.concat(exp_tot, axis=1).sum(axis=1, min_count=len(exp_tot))
    ok = m.notna() & x.notna() & (x > 0)
    before = ok & (run.grid < pd.Timestamp(cs))
    after = ok & (run.grid >= pd.Timestamp(ce))
    res = {
        "site_id": site_id,
        "cleaned_on": cleaned_on.isoformat(),
        "window_days": window_days,
        "method": "weather-adjusted performance index before vs after (excluding cleaning day), bootstrap 90% CI",
        "comparable_intervals": {"before": int(before.sum()), "after": int(after.sum())},
        "irradiance_basis": run.basis.status,
    }
    if before.sum() < min_intervals or after.sum() < min_intervals:
        res.update(status="not_estimated", reason="too few comparable intervals before/after cleaning")
        return res
    ib = float(m[before].sum() / x[before].sum())
    ia = float(m[after].sum() / x[after].sum())
    rng = np.random.default_rng(seed)
    mb, xb, ma, xa = m[before].to_numpy(), x[before].to_numpy(), m[after].to_numpy(), x[after].to_numpy()
    # block bootstrap by day to respect autocorrelation
    db = pd.Series(run.grid[before].date)
    da = pd.Series(run.grid[after].date)
    boots = []
    days_b, days_a = db.unique(), da.unique()
    for _ in range(400):
        sb = np.isin(db, rng.choice(days_b, len(days_b)))
        sa = np.isin(da, rng.choice(days_a, len(days_a)))
        if sb.sum() and sa.sum():
            boots.append(ma[sa].sum() / xa[sa].sum() - mb[sb].sum() / xb[sb].sum())
    lo, hi = (float(np.quantile(boots, 0.05)), float(np.quantile(boots, 0.95))) if boots else (None, None)
    soil = run.soiling
    sr = None
    if soil.notna().any():
        sr = {
            "before_mean": round(float(soil[run.grid < pd.Timestamp(cs)].mean()), 4),
            "after_mean": round(float(soil[run.grid >= pd.Timestamp(ce)].mean()), 4),
            "source": "soiling reference station",
        }
    res.update(
        status="estimate",
        index_before=round(ib, 4),
        index_after=round(ia, 4),
        change=round(ia - ib, 4),
        change_ci90=[round(lo, 4), round(hi, 4)] if lo is not None else None,
        soiling_station=sr,
        interpretation="change attributable to cleaning only if the CI excludes zero and no other change "
        "(repairs, curtailment, sensor recalibration) occurred in the window",
    )
    return res


def cleaning_scenario(
    expected_energy_kwh_per_day: float,
    soiling_loss_fraction: float,
    loss_uncertainty: float,
    days_until_rain_or_next_clean: int,
    cleaning_cost: float,
    price_per_mwh: float,
    currency: str,
    constraints: list[str] | None = None,
) -> dict:
    """Scenario estimate (not a measurement) of recoverable energy and value vs cleaning cost."""
    if not 0 <= soiling_loss_fraction < 0.5:
        raise ValueError("soiling loss fraction must be in [0, 0.5)")
    rec = expected_energy_kwh_per_day * soiling_loss_fraction * days_until_rain_or_next_clean
    lo = (
        expected_energy_kwh_per_day
        * max(soiling_loss_fraction - loss_uncertainty, 0)
        * days_until_rain_or_next_clean
    )
    hi = (
        expected_energy_kwh_per_day
        * (soiling_loss_fraction + loss_uncertainty)
        * days_until_rain_or_next_clean
    )
    val = rec / 1000 * price_per_mwh
    return {
        "label": "SCENARIO ESTIMATE",
        "recoverable_energy_kwh": round(rec, 0),
        "recoverable_energy_range_kwh": [round(lo, 0), round(hi, 0)],
        "energy_value": round(val, 2),
        "energy_value_range": [round(lo / 1000 * price_per_mwh, 2), round(hi / 1000 * price_per_mwh, 2)],
        "cleaning_cost": cleaning_cost,
        "net_value": round(val - cleaning_cost, 2),
        "currency": currency,
        "break_even_soiling_fraction": round(
            cleaning_cost
            / max(expected_energy_kwh_per_day * days_until_rain_or_next_clean / 1000 * price_per_mwh, 1e-9),
            4,
        ),
        "operational_constraints": constraints or [],
        "assumptions": {
            "expected_energy_kwh_per_day": expected_energy_kwh_per_day,
            "soiling_loss_fraction": soiling_loss_fraction,
            "loss_uncertainty": loss_uncertainty,
            "benefit_days": days_until_rain_or_next_clean,
            "price_per_mwh": price_per_mwh,
        },
    }
