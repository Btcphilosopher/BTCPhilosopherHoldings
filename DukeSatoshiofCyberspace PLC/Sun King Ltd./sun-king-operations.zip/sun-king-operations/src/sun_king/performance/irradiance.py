"""Irradiance basis selection with explicit sensor-quality reasoning.

Two coplanar POA pyranometers are compared. A sensor whose cleaned values
are flagged ``stuck_value``/``out_of_range`` is excluded. Where both are
valid but disagree by more than ``DISAGREE_FRAC`` the basis is marked
``uncertain`` and metrics that need irradiance refuse to compute.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

import numpy as np
import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from sun_king.assets.models import Asset
from sun_king.telemetry.models import CleanObservation

DISAGREE_FRAC = 0.05
DAYLIGHT_WM2 = 50.0
GRID = "5min"


@dataclass
class IrradianceBasis:
    poa: pd.Series  # W/m² on the sensor plane, NaN where unavailable
    plane_tilt: float | None
    plane_azimuth: float | None
    ghi: pd.Series
    sensors_used: list[str]
    sensors_excluded: dict[str, str]
    disagreement_fraction: float | None
    status: str  # ok | single_sensor | uncertain | unavailable
    coverage: float  # fraction of daylight grid points with a valid POA value
    notes: list[str] = field(default_factory=list)


def _sensor_frame(
    session: Session, asset_id: str, mtype: str, start: datetime, end: datetime
) -> pd.DataFrame:
    rows = session.execute(
        select(
            CleanObservation.observation_time,
            CleanObservation.value,
            CleanObservation.quality,
            CleanObservation.quality_flags,
        ).where(
            CleanObservation.asset_id == asset_id,
            CleanObservation.measurement_type == mtype,
            CleanObservation.observation_time >= start,
            CleanObservation.observation_time < end,
        )
    ).all()
    df = pd.DataFrame(rows, columns=["t", "value", "quality", "flags"])
    if df.empty:
        return df
    df["t"] = pd.to_datetime(df["t"], utc=True)
    return df.set_index("t").sort_index()


def irradiance_basis(
    session: Session, site_id: str, start: datetime, end: datetime, grid: pd.DatetimeIndex | None = None
) -> IrradianceBasis:
    grid = grid if grid is not None else pd.date_range(start, end, freq=GRID, inclusive="left")
    sensors = session.scalars(
        select(Asset).where(Asset.site_id == site_id, Asset.asset_type == "sensor")
    ).all()
    pyrs = [
        s for s in sensors if (s.electrical_parameters or {}).get("sensor_role") in ("primary", "reference")
    ]
    ghi_sensor = next(
        (s for s in sensors if (s.electrical_parameters or {}).get("sensor_role") == "ghi"), None
    )
    used, excluded, cols = [], {}, {}
    notes: list[str] = []
    for s in pyrs:
        df = _sensor_frame(session, s.asset_id, "poa_irradiance", start, end)
        if df.empty:
            excluded[s.asset_id] = "no data in window"
            continue
        bad_flags = df["flags"].apply(
            lambda f: bool({"stuck_value", "out_of_range", "night_irradiance"} & set(f or []))
        )
        frac_bad = (
            float(bad_flags[df["value"].fillna(0) > DAYLIGHT_WM2].mean())
            if (df["value"].fillna(0) > DAYLIGHT_WM2).any()
            else 0.0
        )
        if frac_bad > 0.2:
            excluded[s.asset_id] = f"{frac_bad:.0%} of daylight samples flagged stuck/implausible"
            continue
        good = df["value"].where(df["quality"] == "good")
        cols[s.asset_id] = good.resample(GRID).mean().reindex(grid)
        used.append(s.asset_id)
    ghi = pd.Series(np.nan, index=grid)
    if ghi_sensor is not None:
        g = _sensor_frame(session, ghi_sensor.asset_id, "ghi", start, end)
        if not g.empty:
            ghi = g["value"].where(g["quality"] == "good").resample(GRID).mean().reindex(grid)
    plane = pyrs[0].electrical_parameters if pyrs else {}
    disagreement = None
    if len(used) >= 2:
        a, b = cols[used[0]], cols[used[1]]
        day = (a > DAYLIGHT_WM2) & (b > DAYLIGHT_WM2)
        if day.any():
            disagreement = float((abs(a[day] - b[day]) / ((a[day] + b[day]) / 2)).median())
        poa = pd.concat([a, b], axis=1).mean(axis=1)
        status = "ok"
        if disagreement is not None and disagreement > DISAGREE_FRAC:
            status = "uncertain"
            notes.append(f"Valid sensors disagree by median {disagreement:.1%} (> {DISAGREE_FRAC:.0%}).")
    elif len(used) == 1:
        poa = cols[used[0]]
        status = "single_sensor"
        notes.append(f"Only {used[0]} usable; no independent cross-check in this window.")
    else:
        poa = pd.Series(np.nan, index=grid)
        status = "unavailable"
        notes.append("No usable POA irradiance in this window.")
    daylight = ghi.fillna(poa) > DAYLIGHT_WM2
    # coverage relative to clear-sky daylight would be stricter; we use solar elevation from pvlib
    from sun_king.adapters.pvmodel import solar_elevation
    from sun_king.assets.models import Site

    site = session.get(Site, site_id)
    elev = solar_elevation(site.latitude, site.longitude, grid)
    sun = pd.Series(elev > 5.0, index=grid)
    coverage = float(poa[sun].notna().mean()) if sun.any() else 0.0
    return IrradianceBasis(
        poa=poa,
        plane_tilt=plane.get("plane_tilt_deg"),
        plane_azimuth=plane.get("plane_azimuth_deg"),
        ghi=ghi,
        sensors_used=used,
        sensors_excluded=excluded,
        disagreement_fraction=disagreement,
        status=status,
        coverage=round(coverage, 4),
        notes=notes + ([] if daylight.any() else ["No daylight in window."]),
    )
