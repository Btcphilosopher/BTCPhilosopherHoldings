"""Performance metrics with explicit formula, inputs, window, exclusions and uncertainty.

Every public function returns :class:`MetricResult` (or a dict of them).
A metric whose inputs are inadequate returns ``status='not_computed'`` with
reasons instead of a number.

Expected-yield model: ``sun_king.adapters.pvmodel`` (pvlib PVWatts DC,
SAPM cell temperature from measured back-of-module temperature, PVWatts
inverter). Blocks coplanar with the POA sensors use measured POA; other
orientations use measured GHI → Erbs decomposition → Hay–Davies
transposition, with a larger stated uncertainty.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field
from datetime import datetime

import numpy as np
import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from sun_king.adapters import pvmodel
from sun_king.assets.models import Asset, PVSystemConfig, Site
from sun_king.assets.service import meter_for_role, site_inverters
from sun_king.energy.models import CurtailmentRecord
from sun_king.performance.irradiance import DAYLIGHT_WM2, GRID, IrradianceBasis, irradiance_basis
from sun_king.telemetry.query import frame

PERF_VERSION = "perf-1.1"
G_STC = 1000.0
STEP_H = 5 / 60
MIN_IRR_COVERAGE = 0.95
MIN_ENERGY_COVERAGE = 0.95
UNC_COPLANAR = 0.035  # model + sensor (k=1), configured estimate — see docs/performance.md
UNC_TRANSPOSED = 0.07
UNC_SENSOR = 0.02


@dataclass
class MetricResult:
    name: str
    value: float | None
    unit: str
    status: str  # ok | not_computed | estimate
    formula: str
    window: dict
    inputs: dict = field(default_factory=dict)
    exclusions: list[dict] = field(default_factory=list)
    uncertainty: dict | None = None
    reasons: list[str] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    version: str = PERF_VERSION

    def to_dict(self) -> dict:
        d = asdict(self)
        if d["value"] is not None and isinstance(d["value"], float) and math.isnan(d["value"]):
            d["value"] = None
        return d


def _spec(cfg: PVSystemConfig, inv: Asset) -> tuple[pvmodel.ArraySpec, pvmodel.InverterSpec]:
    ip = inv.electrical_parameters or {}
    return (
        pvmodel.ArraySpec(
            asset_id=cfg.asset_id,
            inverter_asset_id=cfg.inverter_asset_id,
            dc_kwp=cfg.dc_capacity_kwp,
            tilt=cfg.surface_tilt_deg,
            azimuth=cfg.surface_azimuth_deg,
            mounting=cfg.mounting,
            axis_azimuth=cfg.axis_azimuth_deg or 180.0,
            max_rotation=cfg.max_rotation_deg or 55.0,
            gcr=cfg.gcr or 0.35,
            gamma_pdc=cfg.gamma_pdc_per_c,
            temperature_model=cfg.temperature_model,
            dc_loss_fraction=cfg.dc_loss_fraction,
        ),
        pvmodel.InverterSpec(inv.asset_id, ip.get("ac_kw", inv.rated_capacity or 0), ip.get("eta_nom", 0.98)),
    )


@dataclass
class SiteModelRun:
    site: Site
    grid: pd.DatetimeIndex
    basis: IrradianceBasis
    expected: dict[str, pd.DataFrame]  # inverter -> expected_ac/unclipped/dc/dc_25c + poa
    measured_ac: pd.DataFrame
    status: pd.DataFrame
    meter_kw: pd.Series
    coplanar: dict[str, bool]
    curtailed: pd.Series
    curtailment_records: list[CurtailmentRecord]
    soiling: pd.Series
    tcell_basis: str


def run_site_model(session: Session, site_id: str, start: datetime, end: datetime) -> SiteModelRun:
    site = session.get(Site, site_id)
    # align to the 5-minute grid so resampled telemetry lines up with model intervals
    start = pd.Timestamp(start).floor(GRID).to_pydatetime()
    end = pd.Timestamp(end).ceil(GRID).to_pydatetime()
    grid = pd.date_range(start, end, freq=GRID, inclusive="left")
    basis = irradiance_basis(session, site_id, start, end, grid)
    invs = site_inverters(session, site_id)
    inv_ids = [i.asset_id for i in invs]
    cfgs = {c.inverter_asset_id: c for c in session.scalars(select(PVSystemConfig))}
    sensors = {
        s.electrical_parameters.get("sensor_role"): s.asset_id
        for s in session.scalars(select(Asset).where(Asset.site_id == site_id, Asset.asset_type == "sensor"))
    }
    ws = session.scalar(
        select(Asset.asset_id).where(Asset.site_id == site_id, Asset.asset_type == "weather_station")
    )

    def one(aid, mt):
        f = frame(session, [aid], mt, start, end, resample=GRID) if aid else pd.DataFrame()
        return f[aid].reindex(grid) if aid and aid in f else pd.Series(np.nan, index=grid)

    tamb = one(ws, "ambient_temperature").interpolate(limit=3)
    wind = one(ws, "wind_speed").interpolate(limit=3).fillna(2.0)
    tmod = one(sensors.get("module_temp"), "module_temperature").interpolate(limit=3)
    soil = (
        one(sensors.get("soiling"), "soiling_ratio").ffill().bfill()
        if sensors.get("soiling")
        else pd.Series(np.nan, index=grid)
    )
    solpos = pvmodel.solar_position(site.latitude, site.longitude, site.elevation_m, grid)
    measured = frame(session, inv_ids, "ac_power", start, end, resample=GRID).reindex(grid)
    status = frame(session, inv_ids, "status_code", start, end, resample=None)
    status = (
        status.reindex(status.index.union(grid)).ffill(limit=2).reindex(grid)
        if not status.empty
        else pd.DataFrame(index=grid, columns=inv_ids)
    )
    meter = meter_for_role(session, site_id, "export_settlement")
    mk = frame(session, [meter], "ac_power", start, end, resample=GRID) if meter else pd.DataFrame()
    meter_kw = mk[meter].reindex(grid) if meter and meter in mk else pd.Series(np.nan, index=grid)

    expected, coplanar = {}, {}
    sky = None
    if basis.ghi.notna().any():
        sky = pvmodel.decompose_ghi(basis.ghi.fillna(0).clip(lower=0), solpos)
    tcell_basis = (
        "measured module temperature (SAPM ΔT relation)"
        if tmod.notna().any()
        else "SAPM from ambient and wind"
    )
    for inv in invs:
        cfg = cfgs.get(inv.asset_id)
        if cfg is None:
            continue
        spec, ispec = _spec(cfg, inv)
        same_plane = (
            spec.mounting == "fixed"
            and basis.plane_tilt is not None
            and abs(spec.tilt - basis.plane_tilt) < 1
            and abs(spec.azimuth - (basis.plane_azimuth or 0)) < 1
        )
        coplanar[inv.asset_id] = same_plane
        if same_plane:
            poa = basis.poa.clip(lower=0)
        elif sky is not None:
            poa = pvmodel.poa_irradiance(spec, sky, solpos, site.albedo).where(basis.ghi.notna())
        else:
            poa = pd.Series(np.nan, index=grid)
        if tmod.notna().any():
            tcell = pvmodel.cell_from_module_temperature(spec, tmod, poa)
            tcell = tcell.fillna(pvmodel.cell_temperature(spec, poa, tamb.fillna(5), wind))
        else:
            tcell = pvmodel.cell_temperature(spec, poa, tamb.fillna(5), wind)
        e = pvmodel.expected_ac_from_poa(spec, ispec, poa.fillna(0), tcell.fillna(25))
        e = e.where(poa.notna())
        e["poa"] = poa
        e["tcell"] = tcell
        e["rated_kw"] = ispec.ac_kw
        e["dc_kwp"] = spec.dc_kwp
        expected[inv.asset_id] = e

    curt_recs = list(
        session.scalars(
            select(CurtailmentRecord).where(
                CurtailmentRecord.site_id == site_id,
                CurtailmentRecord.start_time < end,
                CurtailmentRecord.end_time > start,
            )
        )
    )
    curtailed = pd.Series(False, index=grid)
    for c in curt_recs:
        curtailed |= (grid >= pd.Timestamp(c.start_time)) & (grid < pd.Timestamp(c.end_time))
    return SiteModelRun(
        site,
        grid,
        basis,
        expected,
        measured,
        status,
        meter_kw,
        coplanar,
        curtailed,
        curt_recs,
        soil,
        tcell_basis,
    )


def _window(start, end):
    return {"start": start.isoformat(), "end": end.isoformat(), "grid": GRID}


def _kwh(s: pd.Series) -> float:
    return float(s.fillna(0).sum() * STEP_H)


def classify_intervals(run: SiteModelRun, inv_id: str) -> pd.Series:
    """Per-interval state: night | producing | curtailed | fault | zero_output_unexplained | no_telemetry | low_irradiance."""
    e = run.expected[inv_id]
    meas = run.measured_ac[inv_id] if inv_id in run.measured_ac else pd.Series(np.nan, index=run.grid)
    st = run.status[inv_id] if inv_id in run.status else pd.Series(np.nan, index=run.grid)
    out = pd.Series("producing", index=run.grid, dtype=object)
    poa = e["poa"]
    lowirr = poa.fillna(0) < DAYLIGHT_WM2
    out[lowirr] = "low_irradiance"
    out[meas.isna() & ~lowirr] = "no_telemetry"
    fault = st.fillna(0) >= 100
    out[fault & meas.notna()] = "fault"
    zero = (meas.fillna(1) < 0.01 * e["rated_kw"].iloc[0]) & ~lowirr & ~fault & meas.notna()
    out[zero] = "zero_output_unexplained"
    out[run.curtailed & ~fault & meas.notna()] = "curtailed"
    sun = pvmodel.solar_elevation(run.site.latitude, run.site.longitude, run.grid) > 0
    out[~sun] = "night"
    return out


def inverter_comparison(
    session: Session, site_id: str, start: datetime, end: datetime, run: SiteModelRun | None = None
) -> list[dict]:
    run = run or run_site_model(session, site_id, start, end)
    rows = []
    for inv_id, e in run.expected.items():
        cls = classify_intervals(run, inv_id)
        meas = run.measured_ac[inv_id] if inv_id in run.measured_ac else pd.Series(np.nan, index=run.grid)
        valid = (
            cls.isin(["producing", "fault", "zero_output_unexplained", "low_irradiance"])
            & meas.notna()
            & e["ac_kw"].notna()
        )
        exp_kwh = _kwh(e["ac_kw"][valid])
        meas_kwh = _kwh(meas[valid])
        unc = UNC_COPLANAR if run.coplanar.get(inv_id) else UNC_TRANSPOSED
        ratio = meas_kwh / exp_kwh if exp_kwh > 1 else None
        daylight = cls != "night"
        n_day = int((daylight & (e["poa"].fillna(0) > DAYLIGHT_WM2)).sum())
        rows.append(
            {
                "asset_id": inv_id,
                "measured_kwh": round(meas_kwh, 2),
                "expected_kwh": round(exp_kwh, 2),
                "performance_index": round(ratio, 4) if ratio else None,
                "performance_index_uncertainty": round(unc * (ratio or 0), 4) if ratio else None,
                "specific_yield_kwh_per_kwp": round(meas_kwh / e["dc_kwp"].iloc[0], 3),
                "irradiance_basis": "measured POA (coplanar)"
                if run.coplanar.get(inv_id)
                else "measured GHI transposed (Erbs + Hay–Davies)",
                "comparable_intervals": int(valid.sum()),
                "daylight_intervals": n_day,
                "intervals": {k: int(v) for k, v in cls.value_counts().items()},
                "excluded": "curtailed and no-telemetry intervals excluded from both measured and expected",
            }
        )
    pis = [r["performance_index"] for r in rows if r["performance_index"]]
    if len(pis) >= 3:
        med = float(np.median(pis))
        mad = float(np.median(np.abs(np.array(pis) - med))) or 0.01
        for r in rows:
            if r["performance_index"]:
                r["peer_robust_z"] = round((r["performance_index"] - med) / (1.4826 * mad), 2)
                r["peer_median_index"] = round(med, 4)
    return rows


def availability(run: SiteModelRun, inv_id: str) -> MetricResult:
    cls = classify_intervals(run, inv_id)
    considered = cls[(cls != "night") & (cls != "low_irradiance")]
    up = considered.isin(["producing", "curtailed"]).sum()
    down = considered.isin(["fault", "zero_output_unexplained"]).sum()
    unknown = (considered == "no_telemetry").sum()
    total = len(considered)
    if total == 0:
        return MetricResult(
            "availability",
            None,
            "fraction",
            "not_computed",
            "A = t_available / (t_available + t_unavailable)",
            _window(run.grid[0], run.grid[-1]),
            reasons=["no daylight intervals with irradiance ≥ 50 W/m²"],
        )
    known = up + down
    value = up / known if known else None
    return MetricResult(
        "availability",
        round(value, 4) if value is not None else None,
        "fraction",
        "ok" if unknown == 0 else "estimate",
        "A = t_available / (t_available + t_unavailable); intervals with POA ≥ 50 W/m² and sun up; "
        "curtailed intervals count as available (grid-side restriction, not equipment)",
        _window(run.grid[0], run.grid[-1]),
        inputs={
            "available_intervals": int(up),
            "unavailable_intervals": int(down),
            "unknown_intervals": int(unknown),
            "interval_minutes": 5,
        },
        exclusions=[
            {"type": "no_telemetry", "intervals": int(unknown), "treatment": "excluded; bounds reported"}
        ],
        uncertainty={
            "lower_bound": round(up / total, 4),
            "upper_bound": round((up + unknown) / total, 4),
            "method": "unknown intervals counted as unavailable (lower) or available (upper)",
        },
    )


def performance_ratio(
    session: Session,
    site_id: str,
    start: datetime,
    end: datetime,
    run: SiteModelRun | None = None,
    scope: str = "site",
) -> MetricResult:
    """IEC 61724-1 style PR = (E / P0) / (H_poa / G_stc), with exclusions applied to both terms."""
    run = run or run_site_model(session, site_id, start, end)
    w = _window(start, end)
    formula = "PR = (Σ E_out / P_STC) / (Σ H_POA / G_STC); G_STC = 1000 W/m²; 5-min intervals"
    reasons = []
    b = run.basis
    if b.status in ("unavailable", "uncertain"):
        reasons.append(f"irradiance basis {b.status}: {'; '.join(b.notes)}")
    if b.coverage < MIN_IRR_COVERAGE:
        reasons.append(
            f"POA coverage {b.coverage:.1%} below required {MIN_IRR_COVERAGE:.0%} of daylight intervals"
        )
    if scope == "site":
        if not all(run.coplanar.values()):
            reasons.append(
                "site has arrays in orientations other than the POA sensor plane; a single-plane site PR "
                "would be misleading — use per-inverter PR for coplanar blocks or the expected-energy index"
            )
        energy = run.meter_kw.clip(lower=0)
        p0 = run.site.dc_capacity_kwp
        energy_label = "export meter active power (5-min mean)"
    else:
        energy = run.measured_ac[scope] if scope in run.measured_ac else pd.Series(np.nan, index=run.grid)
        p0 = float(run.expected[scope]["dc_kwp"].iloc[0]) if scope in run.expected else 0
        if not run.coplanar.get(scope):
            reasons.append(f"{scope} is not coplanar with the POA sensors")
        energy_label = f"{scope} AC power (5-min mean)"
    sun = pd.Series(
        pvmodel.solar_elevation(run.site.latitude, run.site.longitude, run.grid) > 5, index=run.grid
    )
    excl = run.curtailed.copy()
    poa = b.poa
    no_energy = energy.isna() & sun
    excl |= no_energy
    if sun.any() and float(no_energy[sun].mean()) > 1 - MIN_ENERGY_COVERAGE:
        reasons.append(f"energy data missing for {float(no_energy[sun].mean()):.1%} of daylight intervals")
    mask = sun & ~excl & poa.notna()
    exclusions = [
        {
            "type": "recorded_curtailment",
            "intervals": int((run.curtailed & sun).sum()),
            "records": [c.id for c in run.curtailment_records],
        },
        {"type": "missing_energy_data", "intervals": int(no_energy.sum())},
        {"type": "missing_irradiance", "intervals": int((sun & poa.isna()).sum())},
    ]
    if reasons:
        return MetricResult(
            "performance_ratio",
            None,
            "fraction",
            "not_computed",
            formula,
            w,
            inputs={"irradiance_basis": asdict_basis(b)},
            exclusions=exclusions,
            reasons=reasons,
        )
    e_kwh = _kwh(energy[mask])
    h_kwh_m2 = _kwh(poa[mask]) / 1000.0
    if h_kwh_m2 < 0.2:
        return MetricResult(
            "performance_ratio",
            None,
            "fraction",
            "not_computed",
            formula,
            w,
            exclusions=exclusions,
            reasons=[f"insolation {h_kwh_m2:.2f} kWh/m² too low for a meaningful PR"],
        )
    pr = (e_kwh / p0) / (h_kwh_m2 / (G_STC / 1000.0))
    # temperature-corrected PR (IEC 61724-1 Annex style) using modelled cell temperature
    tc_terms = []
    for iid, e in run.expected.items():
        if scope in ("site", iid):
            gamma = -0.0035
            tc_terms.append(
                (1 + gamma * (e["tcell"][mask].fillna(25) - 25)) * poa[mask] * float(e["dc_kwp"].iloc[0])
            )
    pr_tc = None
    if tc_terms:
        denom = sum(_kwh(t) for t in tc_terms) / 1000.0
        pr_tc = e_kwh / denom if denom > 0 else None
    u_rel = math.sqrt(UNC_SENSOR**2 + 0.005**2)
    return MetricResult(
        "performance_ratio",
        round(pr, 4),
        "fraction",
        "ok",
        formula,
        w,
        inputs={
            "energy_kwh": round(e_kwh, 1),
            "energy_basis": energy_label,
            "p_stc_kwp": p0,
            "h_poa_kwh_m2": round(h_kwh_m2, 3),
            "irradiance_basis": asdict_basis(b),
            "temperature_corrected_pr": round(pr_tc, 4) if pr_tc else None,
            "cell_temperature_basis": run.tcell_basis,
        },
        exclusions=exclusions,
        uncertainty={
            "relative_k1": round(u_rel, 4),
            "absolute_k1": round(pr * u_rel, 4),
            "components": {"poa_sensor": UNC_SENSOR, "meter": 0.005},
        },
        sources=[
            f"/api/telemetry/observations?asset_id={s}&measurement_type=poa_irradiance&start={start.isoformat()}&end={end.isoformat()}"
            for s in b.sensors_used
        ],
    )


def asdict_basis(b: IrradianceBasis) -> dict:
    return {
        "status": b.status,
        "sensors_used": b.sensors_used,
        "sensors_excluded": b.sensors_excluded,
        "disagreement_fraction": b.disagreement_fraction,
        "coverage": b.coverage,
        "plane": {"tilt": b.plane_tilt, "azimuth": b.plane_azimuth},
        "notes": b.notes,
    }


def specific_yield(session: Session, site_id: str, start: datetime, end: datetime) -> MetricResult:
    from sun_king.energy.service import meter_export

    site = session.get(Site, site_id)
    m = meter_export(session, site_id, start, end)
    formula = "Y_f = E_export / P_DC,STC  (kWh/kWp)"
    if m.get("energy_kwh") is None:
        return MetricResult(
            "specific_yield",
            None,
            "kWh/kWp",
            "not_computed",
            formula,
            _window(start, end),
            reasons=["no export meter data"],
        )
    status = "ok" if m["complete"] else "not_computed"
    reasons = (
        []
        if m["complete"]
        else [f"export energy incomplete (coverage {m['coverage']:.1%}, flags {m['flags']})"]
    )
    return MetricResult(
        "specific_yield",
        round(m["energy_kwh"] / site.dc_capacity_kwp, 4) if m["complete"] else None,
        "kWh/kWp",
        status,
        formula,
        _window(start, end),
        inputs={
            "export_kwh": round(m["energy_kwh"], 2),
            "dc_capacity_kwp": site.dc_capacity_kwp,
            "meter": m["asset_id"],
            "method": m["method"],
        },
        uncertainty={"relative_k1": 0.005, "basis": "meter accuracy class 0.2S"} if m["complete"] else None,
        reasons=reasons,
        sources=m.get("sources", []),
    )


def expected_vs_measured(
    session: Session, site_id: str, start: datetime, end: datetime, run: SiteModelRun | None = None
) -> dict:
    run = run or run_site_model(session, site_id, start, end)
    exp_total = sum(e["ac_kw"] for e in run.expected.values())
    meas_total = run.measured_ac.sum(axis=1, min_count=len(run.expected))
    series = pd.DataFrame(
        {
            "expected_ac_kw": exp_total,
            "measured_inverter_ac_kw": meas_total,
            "export_meter_kw": run.meter_kw,
            "poa_wm2": run.basis.poa,
            "curtailed": run.curtailed,
        }
    )
    return {
        "site_id": site_id,
        "window": _window(start, end),
        "model": pvmodel.MODEL_ID,
        "irradiance_basis": asdict_basis(run.basis),
        "cell_temperature_basis": run.tcell_basis,
        "series": [
            {
                "t": t.isoformat(),
                **{
                    k: (
                        None
                        if (isinstance(v, float) and math.isnan(v))
                        else (bool(v) if k == "curtailed" else round(float(v), 2))
                    )
                    for k, v in row.items()
                },
            }
            for t, row in series.iterrows()
        ],
        "note": "Expected = weather-adjusted model output with no soiling, availability or curtailment losses. "
        "Measured inverter total is shown only where every inverter reported.",
    }


def loss_breakdown(
    session: Session, site_id: str, start: datetime, end: datetime, run: SiteModelRun | None = None
) -> dict:
    """Documented loss categories. Each carries basis and attribution confidence."""
    run = run or run_site_model(session, site_id, start, end)
    cats: dict[str, dict] = {}
    temp_loss = clip = outage_fault = outage_unexplained = curtail = comm_unobserved = soiling = 0.0
    ref = measured = 0.0
    for iid, e in run.expected.items():
        cls = classify_intervals(run, iid)
        meas = run.measured_ac[iid] if iid in run.measured_ac else pd.Series(np.nan, index=run.grid)
        ok = e["ac_kw"].notna()
        ref += _kwh(e["dc_kw_25c"][ok] * 0.975)
        temp_loss += _kwh((e["dc_kw_25c"] - e["dc_kw"])[ok] * 0.975)
        clip_mask = ok & (meas >= 0.97 * e["rated_kw"])
        clip += _kwh((e["ac_unclipped_kw"] - e["ac_kw"])[clip_mask].clip(lower=0))
        outage_fault += _kwh((e["ac_kw"] - meas.fillna(0))[cls == "fault"].clip(lower=0))
        outage_unexplained += _kwh(
            (e["ac_kw"] - meas.fillna(0))[cls == "zero_output_unexplained"].clip(lower=0)
        )
        curtail += _kwh((e["ac_kw"] - meas.fillna(0))[cls == "curtailed"].clip(lower=0))
        comm_unobserved += _kwh(e["ac_kw"][cls == "no_telemetry"])
        if run.soiling.notna().any():
            soiling += _kwh((e["ac_kw"] * (1 - run.soiling.clip(upper=1)))[cls == "producing"])
        measured += _kwh(meas[ok])
    expected_total = sum(_kwh(e["ac_kw"]) for e in run.expected.values())
    cats["temperature"] = {
        "kwh": round(temp_loss, 1),
        "basis": "modelled (PVWatts γ × (T_cell − 25 °C))",
        "confidence": "medium",
    }
    cats["clipping"] = {
        "kwh": round(clip, 1),
        "basis": "modelled estimate where measured ≥ 97% of AC rating",
        "confidence": "low" if clip > 0 else "n/a",
    }
    cats["curtailment"] = {
        "kwh": round(curtail, 1),
        "basis": "recorded curtailment periods; expected − measured",
        "records": [c.id for c in run.curtailment_records],
        "confidence": "medium" if curtail else "n/a",
    }
    cats["equipment_failure"] = {
        "kwh": round(outage_fault, 1),
        "basis": "intervals with a fault status code; expected − measured",
        "confidence": "high" if outage_fault else "n/a",
    }
    cats["unexplained_zero_output"] = {
        "kwh": round(outage_unexplained, 1),
        "basis": "zero output with irradiance but no fault code — attribution uncertain",
        "confidence": "low" if outage_unexplained else "n/a",
    }
    cats["communication_loss_unobserved"] = {
        "kwh": round(comm_unobserved, 1),
        "basis": "expected energy during inverter telemetry gaps; NOT a production loss — energy was not observed at inverter level",
        "confidence": "n/a",
        "counted_as_loss": False,
    }
    cats["soiling"] = {
        "kwh": round(soiling, 1),
        "basis": "soiling-station ratio × expected (estimate)" if soiling else "no soiling sensor",
        "confidence": "low" if soiling else "n/a",
    }
    attributed = outage_fault + outage_unexplained + curtail + soiling
    observed_expected = expected_total - sum(
        _kwh(e["ac_kw"][classify_intervals(run, i) == "no_telemetry"]) for i, e in run.expected.items()
    )
    residual = observed_expected - measured - attributed
    cats["unattributed_residual"] = {
        "kwh": round(residual, 1),
        "basis": "expected (observed intervals) − measured − attributed losses; includes model error",
        "confidence": "low",
    }
    return {
        "site_id": site_id,
        "window": _window(start, end),
        "unit": "kWh",
        "reference_stc_temperature_kwh": round(ref, 1),
        "expected_kwh": round(expected_total, 1),
        "measured_inverter_ac_kwh": round(measured, 1),
        "categories": cats,
        "model": pvmodel.MODEL_ID,
        "irradiance_basis": asdict_basis(run.basis),
        "rules": "Clipping, curtailment, equipment failure and communication loss are separated; communication loss is "
        "never counted as lost production. Attribution confidence is stated per category.",
    }
