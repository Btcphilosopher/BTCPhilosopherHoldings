"""Commercial reporting with strict separation of evidence types.

* **Measured export** — settlement-meter register difference (kWh), with completeness.
* **Estimated value** — measured export × contract price (fixed or interval index), an *estimate*.
* **Settlement statements** — imported counterparty documents (authoritative for billing).
* **Receipts** — recorded cash received.
* **Maintenance costs** — recorded costs.
* **Scenario estimates** — modelled, labelled as such.

Gross generation is never used as exported or billable energy.
"""

from __future__ import annotations

from datetime import date, datetime

import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from sun_king.assets.models import Site
from sun_king.commercial.models import Contract, MaintenanceCost, PricePoint, Receipt, SettlementStatement
from sun_king.core.timeutil import local_day_bounds
from sun_king.energy.service import meter_export


def contract_for(session: Session, site_id: str, d: date) -> Contract | None:
    return session.scalar(
        select(Contract).where(Contract.site_id == site_id, Contract.start_date <= d, Contract.end_date >= d)
    )


def estimated_value(session: Session, site_id: str, start_day: date, end_day: date) -> dict:
    site = session.get(Site, site_id)
    s, _ = local_day_bounds(start_day, site.timezone)
    _, e = local_day_bounds(end_day, site.timezone)
    c = contract_for(session, site_id, start_day)
    m = meter_export(session, site_id, s, e)
    out = {
        "site_id": site_id,
        "period": {"start": start_day.isoformat(), "end": end_day.isoformat(), "timezone": site.timezone},
        "measured_export_kwh": m.get("energy_kwh"),
        "measured_export_complete": m.get("complete"),
        "measured_export_flags": m.get("flags"),
        "sources": m.get("sources"),
        "label": "ESTIMATE — measured export × contract price; not a settlement figure",
    }
    if c is None:
        out.update(status="not_estimated", reason="no contract covers this period")
        return out
    out["contract"] = {
        "id": c.id,
        "type": c.contract_type,
        "currency": c.currency,
        "price_source": c.price_source,
        "period": [c.start_date.isoformat(), c.end_date.isoformat()],
    }
    if m.get("energy_kwh") is None:
        out.update(status="not_estimated", reason="no measured export")
        return out
    if c.contract_type == "fixed_ppa":
        val = m["energy_kwh"] / 1000 * c.fixed_price_per_mwh
        out.update(
            status="estimate",
            estimated_value=round(val, 2),
            currency=c.currency,
            price={"type": "fixed", "per_mwh": c.fixed_price_per_mwh},
        )
    else:
        # interval valuation: half-hourly export from meter power integration × index price
        prices = session.scalars(
            select(PricePoint).where(
                PricePoint.series_id == c.price_series_id,
                PricePoint.start_time >= s,
                PricePoint.start_time < e,
            )
        ).all()
        if not prices:
            out.update(status="not_estimated", reason=f"no prices for series {c.price_series_id} in period")
            return out
        from sun_king.energy.accounting import integrate_power
        from sun_king.telemetry.query import series

        pw = [
            (t, max(v, 0) if v is not None else None)
            for t, v in series(session, m["asset_id"], "ac_power", s, e)
        ]
        val = 0.0
        e_kwh = 0.0
        for p in prices:
            r = integrate_power(pw, p.start_time, p.end_time)
            if r.energy_kwh is not None:
                val += r.energy_kwh / 1000 * p.price_per_mwh
                e_kwh += r.energy_kwh
        out.update(
            status="estimate",
            estimated_value=round(val, 2),
            currency=c.currency,
            price={
                "type": "index",
                "series": c.price_series_id,
                "points": len(prices),
                "synthetic": all(p.is_synthetic for p in prices),
            },
            valued_energy_kwh=round(e_kwh, 1),
        )
    if not m.get("complete"):
        out["warning"] = "measured export incomplete for this period; estimate understated or uncertain"
    return out


def reconciliation(session: Session, site_id: str) -> list[dict]:
    rows = []
    for st in session.scalars(
        select(SettlementStatement)
        .where(SettlementStatement.site_id == site_id)
        .order_by(SettlementStatement.period_start)
    ):
        est = estimated_value(session, site_id, st.period_start, st.period_end)
        rec = session.scalars(select(Receipt).where(Receipt.statement_id == st.id)).all()
        measured_mwh = (
            (est["measured_export_kwh"] or 0) / 1000 if est.get("measured_export_kwh") is not None else None
        )
        rows.append(
            {
                "statement_id": st.id,
                "statement_ref": st.statement_ref,
                "period": [st.period_start.isoformat(), st.period_end.isoformat()],
                "settled_energy_mwh": st.settled_energy_mwh,
                "statement_amount": st.amount,
                "currency": st.currency,
                "measured_export_mwh": round(measured_mwh, 3) if measured_mwh is not None else None,
                "measured_complete": est.get("measured_export_complete"),
                "energy_difference_mwh": round(st.settled_energy_mwh - measured_mwh, 3)
                if measured_mwh is not None
                else None,
                "estimated_value": est.get("estimated_value"),
                "receipts_total": round(sum(r.amount for r in rec), 2),
                "receipts": [r.reference for r in rec],
                "outstanding": round(st.amount - sum(r.amount for r in rec), 2),
            }
        )
    return rows


def lost_revenue_estimate(
    session: Session,
    site_id: str,
    start: datetime,
    end: datetime,
    baseline_kwh: float | None,
    baseline_method: str | None,
    price_per_mwh: float | None,
    currency: str | None,
    price_source: str | None,
    measured_kwh: float | None,
) -> dict:
    missing = [
        k
        for k, v in {
            "baseline_kwh": baseline_kwh,
            "baseline_method": baseline_method,
            "price_per_mwh": price_per_mwh,
            "currency": currency,
            "price_source": price_source,
            "measured_kwh": measured_kwh,
        }.items()
        if v is None
    ]
    base = {"site_id": site_id, "affected_period": {"start": start.isoformat(), "end": end.isoformat()}}
    if missing:
        return {**base, "status": "not_estimated", "reason": f"undocumented assumptions: {missing}"}
    lost = max(baseline_kwh - measured_kwh, 0.0)
    return {
        **base,
        "status": "estimate",
        "lost_energy_kwh": round(lost, 1),
        "estimated_lost_value": round(lost / 1000 * price_per_mwh, 2),
        "currency": currency,
        "assumptions": {
            "baseline_kwh": round(baseline_kwh, 1),
            "baseline_method": baseline_method,
            "measured_kwh": round(measured_kwh, 1),
            "price_per_mwh": price_per_mwh,
            "price_source": price_source,
        },
        "label": "ESTIMATE — depends on the modelled production baseline and valuation assumptions above",
    }


def cost_summary(session: Session, site_id: str, start: date, end: date) -> dict:
    costs = session.scalars(
        select(MaintenanceCost).where(
            MaintenanceCost.site_id == site_id,
            MaintenanceCost.incurred_on >= start,
            MaintenanceCost.incurred_on <= end,
        )
    ).all()
    by_cur: dict[str, dict] = {}
    for c in costs:
        d = by_cur.setdefault(c.currency, {"total": 0.0, "by_category": {}})
        d["total"] += c.amount
        d["by_category"][c.category] = d["by_category"].get(c.category, 0.0) + c.amount
    return {
        "site_id": site_id,
        "period": [start.isoformat(), end.isoformat()],
        "recorded_costs": by_cur,
        "items": [
            {
                "id": c.id,
                "date": c.incurred_on.isoformat(),
                "category": c.category,
                "amount": c.amount,
                "currency": c.currency,
                "work_order_id": c.work_order_id,
                "invoice_ref": c.invoice_ref,
            }
            for c in costs
        ],
    }


def synthetic_price_series(
    series_id: str, start: datetime, days: int, currency: str = "GBP"
) -> list[PricePoint]:
    """Clearly-labelled synthetic half-hourly index (shape only; not market data)."""
    out = []
    t = pd.Timestamp(start)
    import math

    for i in range(days * 48):
        st = t + pd.Timedelta(minutes=30 * i)
        h = st.hour + st.minute / 60
        price = (
            68
            + 22 * math.exp(-((h - 18) ** 2) / 4)
            + 10 * math.exp(-((h - 8) ** 2) / 3)
            - 14 * math.exp(-((h - 13) ** 2) / 6)
        )
        price += 6 * math.sin(i / 37.0)
        out.append(
            PricePoint(
                series_id=series_id,
                source="SYNTHETIC index (demo only — not market data)",
                start_time=st.to_pydatetime(),
                end_time=(st + pd.Timedelta(minutes=30)).to_pydatetime(),
                price_per_mwh=round(price, 2),
                currency=currency,
                is_synthetic=True,
            )
        )
    return out
