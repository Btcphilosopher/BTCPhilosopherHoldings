"""Commercial evidence, kept in separate tables so that measured export,
estimated value, contract prices, settlement statements, receipts,
maintenance costs and scenarios are never conflated."""

from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import Date, Float, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from sun_king.core.db import Base, JSONType, UTCDateTime
from sun_king.core.timeutil import utcnow


class Contract(Base):
    __tablename__ = "contracts"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), index=True)
    counterparty: Mapped[str] = mapped_column(String(200))
    contract_type: Mapped[str] = mapped_column(String(32))  # fixed_ppa | index_linked | merchant
    start_date: Mapped[date] = mapped_column(Date)
    end_date: Mapped[date] = mapped_column(Date)
    currency: Mapped[str] = mapped_column(String(3))
    fixed_price_per_mwh: Mapped[float | None] = mapped_column(Float)
    price_series_id: Mapped[str | None] = mapped_column(String(64))
    price_source: Mapped[str] = mapped_column(String(200))
    settlement_meter_asset_id: Mapped[str] = mapped_column(String(64))
    notes: Mapped[str | None] = mapped_column(Text)


class PricePoint(Base):
    __tablename__ = "price_points"
    __table_args__ = (Index("ix_price_series_time", "series_id", "start_time"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    series_id: Mapped[str] = mapped_column(String(64))
    source: Mapped[str] = mapped_column(String(200))
    start_time: Mapped[datetime] = mapped_column(UTCDateTime)
    end_time: Mapped[datetime] = mapped_column(UTCDateTime)
    price_per_mwh: Mapped[float] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(3))
    is_synthetic: Mapped[bool] = mapped_column(default=True)


class SettlementStatement(Base):
    __tablename__ = "settlement_statements"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"), index=True)
    contract_id: Mapped[str] = mapped_column(ForeignKey("contracts.id"))
    period_start: Mapped[date] = mapped_column(Date)
    period_end: Mapped[date] = mapped_column(Date)  # inclusive
    statement_ref: Mapped[str] = mapped_column(String(120))
    settled_energy_mwh: Mapped[float] = mapped_column(Float)
    amount: Mapped[float] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(3))
    issued_on: Mapped[date] = mapped_column(Date)
    source: Mapped[str] = mapped_column(String(64), default="csv_import")
    imported_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class Receipt(Base):
    __tablename__ = "receipts"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    statement_id: Mapped[str | None] = mapped_column(ForeignKey("settlement_statements.id"))
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"))
    received_on: Mapped[date] = mapped_column(Date)
    amount: Mapped[float] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(3))
    reference: Mapped[str] = mapped_column(String(120))


class MaintenanceCost(Base):
    __tablename__ = "maintenance_costs"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"))
    work_order_id: Mapped[str | None] = mapped_column(ForeignKey("work_orders.id"))
    incurred_on: Mapped[date] = mapped_column(Date)
    category: Mapped[str] = mapped_column(String(48))
    amount: Mapped[float] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(3))
    supplier: Mapped[str | None] = mapped_column(String(200))
    invoice_ref: Mapped[str | None] = mapped_column(String(120))


class CommercialScenario(Base):
    __tablename__ = "commercial_scenarios"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    site_id: Mapped[str] = mapped_column(ForeignKey("sites.id"))
    scenario_type: Mapped[str] = mapped_column(String(48))  # cleaning | lost_revenue | storage
    inputs: Mapped[dict] = mapped_column(JSONType)
    results: Mapped[dict] = mapped_column(JSONType)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
