"""Import every ORM module so ``Base.metadata`` is complete (Alembic, create_all)."""

from sun_king.admin.models import *  # noqa: F401,F403
from sun_king.alerts.models import *  # noqa: F401,F403
from sun_king.assets.models import *  # noqa: F401,F403
from sun_king.commercial.models import *  # noqa: F401,F403
from sun_king.energy.models import *  # noqa: F401,F403
from sun_king.forecasting.models import *  # noqa: F401,F403
from sun_king.maintenance.models import *  # noqa: F401,F403
from sun_king.reporting.models import *  # noqa: F401,F403
from sun_king.storage.models import *  # noqa: F401,F403
from sun_king.telemetry.models import *  # noqa: F401,F403
