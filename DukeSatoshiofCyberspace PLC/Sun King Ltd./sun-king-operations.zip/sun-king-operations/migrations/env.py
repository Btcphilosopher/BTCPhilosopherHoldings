from __future__ import annotations

import os

from alembic import context
from sqlalchemy import engine_from_config, pool

import sun_king.models  # noqa: F401
from sun_king.core.db import Base

config = context.config
url = os.environ.get("SUN_KING_DATABASE_URL")
if url:
    config.set_main_option("sqlalchemy.url", url)
target_metadata = Base.metadata
MIGRATION_ONLY = {"spatial_ref_sys", "geog", "ix_sites_geog", "ix_assets_geog", "brin_raw_obs_time", "brin_clean_obs_time",
                  "ix_clean_obs_site_time"}


def include_object(obj, name, type_, reflected, compare_to):
    """Ignore PostGIS/time-series objects that are managed by migration 0002 rather than the ORM."""
    return not (reflected and compare_to is None and name in MIGRATION_ONLY)


def run_migrations_offline() -> None:
    context.configure(url=config.get_main_option("sqlalchemy.url"), target_metadata=target_metadata, literal_binds=True)
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(config.get_section(config.config_ini_section, {}), prefix="sqlalchemy.", poolclass=pool.NullPool)
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata, include_object=include_object,
                          render_as_batch=connection.dialect.name == "sqlite")
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
