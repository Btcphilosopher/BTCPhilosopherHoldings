"""PostGIS geography, time-series indexes, append-only protection for raw telemetry.

Time-series approach
--------------------
* ``raw_observations`` is append-only (UPDATE/DELETE blocked by trigger;
  corrections arrive as new revisions).
* BRIN indexes on ``observation_time`` keep large, time-ordered tables cheap
  to scan by time range; composite B-tree indexes serve per-stream queries.
* TimescaleDB is optional: if the extension is available, operators can
  convert the cleaned table after changing its primary key to include time —
  see docs/architecture.md. This migration does not require it.

Revision ID: 0002
Revises: 0001
"""
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return
    op.execute("CREATE EXTENSION IF NOT EXISTS postgis")
    op.execute(
        "ALTER TABLE sites ADD COLUMN IF NOT EXISTS geog geography(Point,4326) "
        "GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)::geography) STORED"
    )
    op.execute("CREATE INDEX IF NOT EXISTS ix_sites_geog ON sites USING GIST (geog)")
    op.execute(
        "ALTER TABLE assets ADD COLUMN IF NOT EXISTS geog geography(Point,4326) "
        "GENERATED ALWAYS AS (CASE WHEN longitude IS NULL OR latitude IS NULL THEN NULL "
        "ELSE ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)::geography END) STORED"
    )
    op.execute("CREATE INDEX IF NOT EXISTS ix_assets_geog ON assets USING GIST (geog)")
    op.execute("CREATE INDEX IF NOT EXISTS brin_raw_obs_time ON raw_observations USING BRIN (observation_time)")
    op.execute("CREATE INDEX IF NOT EXISTS brin_clean_obs_time ON clean_observations USING BRIN (observation_time)")
    op.execute("CREATE INDEX IF NOT EXISTS ix_clean_obs_site_time ON clean_observations (site_id, observation_time)")
    op.execute(
        """
        CREATE OR REPLACE FUNCTION sun_king_raw_append_only() RETURNS trigger AS $$
        BEGIN
          IF current_setting('sun_king.allow_raw_maintenance', true) = 'on' THEN
            RETURN COALESCE(NEW, OLD);
          END IF;
          RAISE EXCEPTION 'raw_observations is append-only; submit a new revision instead';
        END $$ LANGUAGE plpgsql
        """
    )
    op.execute(
        "CREATE TRIGGER raw_observations_append_only BEFORE UPDATE OR DELETE ON raw_observations "
        "FOR EACH ROW EXECUTE FUNCTION sun_king_raw_append_only()"
    )
    op.execute(
        "CREATE TRIGGER audit_log_append_only BEFORE UPDATE OR DELETE ON audit_log "
        "FOR EACH ROW EXECUTE FUNCTION sun_king_raw_append_only()"
    )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return
    op.execute("DROP TRIGGER IF EXISTS audit_log_append_only ON audit_log")
    op.execute("DROP TRIGGER IF EXISTS raw_observations_append_only ON raw_observations")
    op.execute("DROP FUNCTION IF EXISTS sun_king_raw_append_only()")
    for ix in ("ix_clean_obs_site_time", "brin_clean_obs_time", "brin_raw_obs_time", "ix_assets_geog", "ix_sites_geog"):
        op.execute(f"DROP INDEX IF EXISTS {ix}")
    op.execute("ALTER TABLE assets DROP COLUMN IF EXISTS geog")
    op.execute("ALTER TABLE sites DROP COLUMN IF EXISTS geog")
