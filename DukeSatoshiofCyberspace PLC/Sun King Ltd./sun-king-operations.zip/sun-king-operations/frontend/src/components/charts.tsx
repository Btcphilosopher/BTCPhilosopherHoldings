import { Area, CartesianGrid, ComposedChart, Legend, Line, ReferenceArea, ResponsiveContainer, Tooltip, XAxis, YAxis, Bar } from "recharts";
import { hhmm, dayLabel } from "../lib/format";

export const PALETTE = ["#0aa5c2", "#f2b705", "#13214a", "#7b5ea7", "#2f9e6e", "#d0662b", "#5b6577", "#b3261e"];

type SeriesDef = { key: string; name: string; color?: string; type?: "line" | "area" | "bar"; dashed?: boolean; yAxis?: "left" | "right"; width?: number };

export function TimeChart({ data, series, unit, rightUnit, height = 260, multiDay = false, bands = [], band }: {
  data: any[]; series: SeriesDef[]; unit: string; rightUnit?: string; height?: number; multiDay?: boolean;
  bands?: { from: string; to: string; label: string; color?: string }[];
  band?: { low: string; high: string; name: string };
}) {
  const rows = band ? data.map((d) => ({ ...d, __band: d[band.low] !== null && d[band.high] !== null ? [d[band.low], d[band.high]] : null })) : data;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <ComposedChart data={rows} margin={{ top: 6, right: rightUnit ? 8 : 16, left: 4, bottom: 0 }}>
        <CartesianGrid stroke="#eef1f5" vertical={false} />
        <XAxis dataKey="t" tickFormatter={(t) => (multiDay ? dayLabel(t) : hhmm(t))} minTickGap={48} tick={{ fontSize: 11, fill: "#5b6577" }} />
        <YAxis yAxisId="left" tick={{ fontSize: 11, fill: "#5b6577" }} width={56} label={{ value: unit, angle: -90, position: "insideLeft", fontSize: 11, fill: "#5b6577" }} />
        {rightUnit && <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11, fill: "#5b6577" }} width={50} label={{ value: rightUnit, angle: 90, position: "insideRight", fontSize: 11, fill: "#5b6577" }} />}
        <Tooltip labelFormatter={(t) => `${dayLabel(String(t))} (site time)`} formatter={(v: any, n: any) => [v === null || v === undefined ? "no data" : Array.isArray(v) ? `${v[0]?.toFixed?.(0)}–${v[1]?.toFixed?.(0)}` : Number(v).toFixed(1), n]} contentStyle={{ fontSize: 12 }} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        {bands.map((b, i) => (
          <ReferenceArea key={i} yAxisId="left" x1={b.from} x2={b.to} fill={b.color ?? "#f2b705"} fillOpacity={0.12} label={{ value: b.label, fontSize: 10, fill: "#b86e00", position: "insideTop" }} />
        ))}
        {band && <Area yAxisId="left" type="monotone" dataKey="__band" name={band.name} stroke="none" fill="#0aa5c2" fillOpacity={0.15} isAnimationActive={false} connectNulls={false} />}
        {series.map((s, i) => {
          const color = s.color ?? PALETTE[i % PALETTE.length];
          if (s.type === "area")
            return <Area key={s.key} yAxisId={s.yAxis ?? "left"} type="monotone" dataKey={s.key} name={s.name} stroke={color} fill={color} fillOpacity={0.12} strokeWidth={1.5} dot={false} isAnimationActive={false} connectNulls={false} />;
          if (s.type === "bar") return <Bar key={s.key} yAxisId={s.yAxis ?? "left"} dataKey={s.key} name={s.name} fill={color} isAnimationActive={false} />;
          return <Line key={s.key} yAxisId={s.yAxis ?? "left"} type="monotone" dataKey={s.key} name={s.name} stroke={color} strokeWidth={s.width ?? 1.6} strokeDasharray={s.dashed ? "5 4" : undefined} dot={false} isAnimationActive={false} connectNulls={false} />;
        })}
      </ComposedChart>
    </ResponsiveContainer>
  );
}
