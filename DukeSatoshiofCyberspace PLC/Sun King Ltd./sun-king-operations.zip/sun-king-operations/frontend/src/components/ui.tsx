import { createContext, ReactNode, useContext, useState } from "react";
import { api } from "../lib/api";
import { age, titleCase } from "../lib/format";

export function Card({ title, children, actions, className = "" }: { title?: ReactNode; children: ReactNode; actions?: ReactNode; className?: string }) {
  return (
    <section className={`card ${className}`}>
      {title && <h2><span>{title}</span>{actions && <span className="row">{actions}</span>}</h2>}
      {children}
    </section>
  );
}

type Tone = "ok" | "warn" | "crit" | "info" | "muted" | "gold";
const ICON: Record<Tone, ReactNode> = {
  ok: <svg viewBox="0 0 12 12"><path d="M2 6.5l2.5 2.5L10 3.5" stroke="currentColor" strokeWidth="2" fill="none" /></svg>,
  warn: <svg viewBox="0 0 12 12"><path d="M6 1L11 11H1z" fill="currentColor" /></svg>,
  crit: <svg viewBox="0 0 12 12"><circle cx="6" cy="6" r="5" fill="currentColor" /><path d="M4 4l4 4M8 4l-4 4" stroke="#fff" strokeWidth="1.5" /></svg>,
  info: <svg viewBox="0 0 12 12"><circle cx="6" cy="6" r="5" fill="none" stroke="currentColor" strokeWidth="1.5" /></svg>,
  muted: null,
  gold: null,
};
export function Badge({ tone = "muted", children, title }: { tone?: Tone; children: ReactNode; title?: string }) {
  return <span className={`badge ${tone}`} title={title}>{ICON[tone]}{children}</span>;
}

export function SeverityBadge({ severity, active = true }: { severity: string; active?: boolean }) {
  const tone: Tone = !active ? "muted" : severity === "critical" ? "crit" : severity === "warning" ? "warn" : "info";
  const label = severity === "critical" ? "CRITICAL" : severity === "warning" ? "WARNING" : severity.toUpperCase();
  return <Badge tone={tone}>{label}{!active && " · cleared"}</Badge>;
}

export function StatusBadge({ status }: { status: string }) {
  const tone: Tone = ["complete", "verified", "signed_off", "ok", "live", "available", "producing", "connected"].includes(status)
    ? "ok"
    : ["incomplete", "incomplete_meter_reset", "partial", "estimate", "standby", "in_progress", "degraded", "uncertain", "single_sensor"].includes(status)
      ? "warn"
      : ["fault", "no_data", "disconnected", "not_computed", "failed", "no_telemetry", "unavailable"].includes(status)
        ? "crit"
        : "info";
  return <Badge tone={tone}>{titleCase(status)}</Badge>;
}

export function Freshness({ ageS, current, label }: { ageS: number | null | undefined; current: boolean; label?: string }) {
  if (current) return <span className="freshness ok-text"><span className="pulse" />LIVE · {age(ageS)} ago</span>;
  return (
    <span className="freshness warn-text" title="Values shown are last-known, not current">
      <svg width="12" height="12" viewBox="0 0 12 12"><path d="M6 1L11 11H1z" fill="currentColor" /></svg>
      {label ?? "NOT CURRENT"} · last data {age(ageS)} ago
    </span>
  );
}

export function Stat({ label, value, unit, meta, source, accent }: { label: string; value: ReactNode; unit?: string; meta?: ReactNode; source?: string; accent?: boolean }) {
  return (
    <div className={`card stat ${accent ? "accent" : ""}`}>
      <span className="label">{label}</span>
      <span className="value">{value}{unit && <span className="unit">{unit}</span>}</span>
      <span className="meta">{meta}{source && <SourceLink url={source} />}</span>
    </div>
  );
}

// ---------------------------------------------------------------- source drawer
const SourceCtx = createContext<(url: string, title?: string) => void>(() => {});
export function SourceProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState<{ url: string; title?: string } | null>(null);
  const [data, setData] = useState<unknown>(null);
  const [err, setErr] = useState<string | null>(null);
  const show = (url: string, title?: string) => {
    setOpen({ url, title });
    setData(null);
    setErr(null);
    api.get(url).then(setData).catch((e) => setErr(String(e.message)));
  };
  return (
    <SourceCtx.Provider value={show}>
      {children}
      {open && (
        <>
          <div className="drawer-bg" onClick={() => setOpen(null)} />
          <aside className="drawer" role="dialog" aria-label="Source data">
            <header>
              <div>
                <b>{open.title ?? "Source and calculation"}</b>
                <div className="small mono muted" style={{ wordBreak: "break-all" }}>{open.url}</div>
              </div>
              <button className="btn sm" onClick={() => setOpen(null)}>Close</button>
            </header>
            <div className="body">
              {err && <div className="notice crit">{err}</div>}
              {!data && !err && <div className="empty">Loading…</div>}
              {data !== null && <SourceView data={data} />}
            </div>
          </aside>
        </>
      )}
    </SourceCtx.Provider>
  );
}
function SourceView({ data }: { data: any }) {
  const obs = data?.observations;
  return (
    <>
      {Array.isArray(obs) && (
        <>
          <p className="small muted">{obs.length} observations{data.unit ? ` · unit ${data.unit}` : ""}{data.note ? ` · ${data.note}` : ""}</p>
          <div className="scroll" style={{ maxHeight: 300 }}>
            <table className="t">
              <thead><tr><th>Observation time (UTC)</th><th className="num">Value</th><th>Quality / flags</th><th>Raw id</th></tr></thead>
              <tbody>
                {obs.slice(-300).map((o: any, i: number) => (
                  <tr key={i}>
                    <td className="mono">{o.t ?? o.observation_time}</td>
                    <td className="num">{o.value ?? "—"}</td>
                    <td>{o.quality ? <StatusBadge status={o.quality === "good" ? "ok" : o.quality} /> : null} <span className="small">{(o.flags ?? o.quality_flags ?? []).join(", ")}</span></td>
                    <td className="mono small">{o.raw ?? o.measurement_id}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
      <h3 className="section-title">JSON</h3>
      <pre>{JSON.stringify(Array.isArray(obs) ? { ...data, observations: `[${obs.length} rows shown above]` } : data, null, 2)}</pre>
    </>
  );
}
export function SourceLink({ url, label = "source" }: { url: string; label?: string }) {
  const show = useContext(SourceCtx);
  return (
    <a href="#" className="small" onClick={(e) => { e.preventDefault(); show(url); }} title="Show source observations and calculation">
      ⓘ {label}
    </a>
  );
}
export function useSource() {
  return useContext(SourceCtx);
}

export function Tabs({ tabs, value, onChange }: { tabs: [string, string][]; value: string; onChange: (v: string) => void }) {
  return (
    <div className="tabs">
      {tabs.map(([k, l]) => (
        <button key={k} className={value === k ? "on" : ""} onClick={() => onChange(k)}>{l}</button>
      ))}
    </div>
  );
}

export function Loading({ error }: { error?: string | null }) {
  return error ? <div className="notice crit">{error}</div> : <div className="empty">Loading…</div>;
}

export function MetricCard({ m, title }: { m: any; title: string }) {
  const [open, setOpen] = useState(false);
  if (!m) return null;
  const ok = m.status === "ok" || m.status === "estimate";
  return (
    <div className="card stat accent">
      <span className="label">{title}</span>
      <span className="value">
        {ok && m.value !== null ? (m.unit === "fraction" ? `${(m.value * 100).toFixed(1)}` : m.value.toFixed(3)) : "Not computed"}
        {ok && m.value !== null && <span className="unit">{m.unit === "fraction" ? "%" : m.unit}</span>}
      </span>
      <span className="meta">
        <StatusBadge status={m.status} />
        {m.uncertainty?.absolute_k1 && <span>± {(m.uncertainty.absolute_k1 * 100).toFixed(1)} pts (k=1)</span>}
        {m.uncertainty?.lower_bound !== undefined && <span>bounds {(m.uncertainty.lower_bound * 100).toFixed(1)}–{(m.uncertainty.upper_bound * 100).toFixed(1)}%</span>}
        <a href="#" className="small" onClick={(e) => { e.preventDefault(); setOpen(!open); }}>{open ? "hide" : "definition"}</a>
      </span>
      {!ok && m.reasons?.length > 0 && <div className="notice warn small">{m.reasons.join(" · ")}</div>}
      {open && (
        <div className="small" style={{ marginTop: 6 }}>
          <div><b>Formula:</b> <span className="mono">{m.formula}</span></div>
          <div><b>Window:</b> {m.window?.start} → {m.window?.end}</div>
          {m.inputs && <div><b>Inputs:</b> <span className="mono">{JSON.stringify(m.inputs).slice(0, 600)}</span></div>}
          {m.exclusions?.length > 0 && <div><b>Exclusions:</b> {m.exclusions.map((x: any) => `${x.type}: ${x.intervals ?? ""}`).join("; ")}</div>}
          {m.uncertainty && <div><b>Uncertainty:</b> <span className="mono">{JSON.stringify(m.uncertainty)}</span></div>}
          <div className="muted">Version {m.version}</div>
        </div>
      )}
    </div>
  );
}
