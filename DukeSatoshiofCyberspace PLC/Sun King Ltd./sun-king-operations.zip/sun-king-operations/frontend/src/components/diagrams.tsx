import { useMemo } from "react";

// ---------------------------------------------------------------- site layout map (equirectangular, local)
export function SiteMap({ site, assets, alerts = [], height = 280, onSelect }: {
  site: any; assets: any[]; alerts?: string[]; height?: number; onSelect?: (id: string) => void;
}) {
  const pts = assets.filter((a) => a.location);
  const boundary: [number, number][] = site.boundary ?? [];
  const all = [...boundary, ...pts.map((a) => [a.location.longitude, a.location.latitude] as [number, number])];
  const lons = all.map((p) => p[0]);
  const lats = all.map((p) => p[1]);
  const pad = 0.0006;
  const [minX, maxX, minY, maxY] = [Math.min(...lons) - pad, Math.max(...lons) + pad, Math.min(...lats) - pad, Math.max(...lats) + pad];
  const k = Math.cos((site.latitude * Math.PI) / 180);
  const W = 520;
  const H = Math.max(200, (W * (maxY - minY)) / ((maxX - minX) * k));
  const x = (lon: number) => ((lon - minX) / (maxX - minX)) * W;
  const y = (lat: number) => H - ((lat - minY) / (maxY - minY)) * H;
  const colour: Record<string, string> = { array_block: "#f2b705", inverter: "#0aa5c2", transformer: "#13214a", meter: "#13214a", weather_station: "#2f9e6e", grid_connection: "#7b5ea7", battery_system: "#d0662b", combiner_box: "#9aa4b5", tracker: "#0aa5c2" };
  const metres = (maxX - minX) * 111320 * k;
  const scaleM = metres > 800 ? 200 : 100;
  return (
    <svg viewBox={`0 0 ${W} ${H + 24}`} style={{ width: "100%", height, background: "#f5f7fa", borderRadius: 8 }} role="img" aria-label={`Layout of ${site.name}`}>
      {boundary.length > 2 && <polygon points={boundary.map((p) => `${x(p[0])},${y(p[1])}`).join(" ")} fill="#eef5e9" stroke="#2f9e6e" strokeDasharray="5 4" />}
      {pts.filter((a) => a.asset_type === "array_block").map((a) => (
        <g key={a.asset_id} onClick={() => onSelect?.(a.asset_id)} style={{ cursor: "pointer" }}>
          <rect x={x(a.location.longitude) - 52} y={y(a.location.latitude) - 26} width={104} height={44} rx={3} fill="#fff8e1" stroke="#c99600" />
          {Array.from({ length: 6 }).map((_, i) => <line key={i} x1={x(a.location.longitude) - 46} x2={x(a.location.longitude) + 46} y1={y(a.location.latitude) - 20 + i * 6.5} y2={y(a.location.latitude) - 20 + i * 6.5} stroke="#e0b84a" strokeWidth={2} />)}
          <text x={x(a.location.longitude)} y={y(a.location.latitude) + 30} fontSize="10" textAnchor="middle" fill="#5b6577">{a.asset_id}</text>
        </g>
      ))}
      {pts.filter((a) => a.asset_type !== "array_block" && a.asset_type !== "sensor" && a.asset_type !== "combiner_box").map((a) => {
        const bad = alerts.includes(a.asset_id);
        return (
          <g key={a.asset_id} onClick={() => onSelect?.(a.asset_id)} style={{ cursor: "pointer" }}>
            <circle cx={x(a.location.longitude)} cy={y(a.location.latitude)} r={bad ? 7 : 5} fill={bad ? "#b3261e" : colour[a.asset_type] ?? "#5b6577"} stroke="#fff" strokeWidth={1.5} />
            {(a.asset_type !== "inverter") && <text x={x(a.location.longitude) + 8} y={y(a.location.latitude) + 4} fontSize="9.5" fill="#13214a">{a.asset_id}</text>}
          </g>
        );
      })}
      <g transform={`translate(10, ${H + 14})`}>
        <line x1={0} x2={(scaleM / metres) * W} y1={0} y2={0} stroke="#13214a" strokeWidth={2} />
        <text x={(scaleM / metres) * W + 6} y={4} fontSize="10" fill="#13214a">{scaleM} m</text>
        <text x={W - 20} y={4} fontSize="10" textAnchor="end" fill="#5b6577">N ↑ · WGS84 · schematic, not survey grade</text>
      </g>
    </svg>
  );
}

// ---------------------------------------------------------------- portfolio map
export function PortfolioMap({ sites, onSelect }: { sites: any[]; onSelect: (id: string) => void }) {
  if (!sites.length) return null;
  const lats = sites.map((s) => s.site.latitude);
  const lons = sites.map((s) => s.site.longitude);
  const pad = 0.03;
  const [minX, maxX, minY, maxY] = [Math.min(...lons) - pad, Math.max(...lons) + pad, Math.min(...lats) - pad, Math.max(...lats) + pad];
  const W = 420, H = 220;
  const x = (v: number) => ((v - minX) / (maxX - minX)) * W;
  const y = (v: number) => H - ((v - minY) / (maxY - minY)) * H;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", height: 220, background: "linear-gradient(#eef3f8,#e6edf4)", borderRadius: 8 }} role="img" aria-label="Portfolio map">
      <path d={`M0 ${H * 0.62} C ${W * 0.3} ${H * 0.5}, ${W * 0.55} ${H * 0.8}, ${W} ${H * 0.66}`} stroke="#b9cbe0" strokeWidth={6} fill="none" />
      <text x={W - 8} y={H * 0.62} fontSize="9" textAnchor="end" fill="#7a8ca5">River Calder (schematic)</text>
      {sites.map((s) => {
        const cur = s.current_generation?.export_meter?.is_current;
        const crit = s.alerts?.critical > 0;
        return (
          <g key={s.site.id} onClick={() => onSelect(s.site.id)} style={{ cursor: "pointer" }}>
            <circle cx={x(s.site.longitude)} cy={y(s.site.latitude)} r={16} fill={cur ? "#f2b705" : "#dde2ea"} stroke={crit ? "#b3261e" : "#0b1530"} strokeWidth={crit ? 3 : 1.5} />
            <text x={x(s.site.longitude)} y={y(s.site.latitude) + 4} fontSize="10" fontWeight="700" textAnchor="middle" fill="#0b1530">{s.site.code}</text>
            <text x={x(s.site.longitude) + 22} y={y(s.site.latitude) + 4} fontSize="11" fill="#0b1530">{s.site.name}</text>
          </g>
        );
      })}
      <text x={8} y={H - 8} fontSize="9" fill="#7a8ca5">Fictional sites · positions to scale (WGS84)</text>
    </svg>
  );
}

// ---------------------------------------------------------------- single-line diagram (electrical connectivity)
export function SingleLine({ edges, assets, live, onSelect }: { edges: any[]; assets: any[]; live: Record<string, any>; onSelect?: (id: string) => void }) {
  const byId = useMemo(() => Object.fromEntries(assets.map((a) => [a.asset_id, a])), [assets]);
  const ac = edges.filter((e) => e.type !== "dc" || byId[e.from]?.asset_type === "combiner_box");
  const invs = assets.filter((a) => a.asset_type === "inverter");
  const tx = assets.find((a) => a.asset_type === "transformer");
  const meter = assets.find((a) => a.asset_type === "meter");
  const grid = assets.find((a) => a.asset_type === "grid_connection");
  const bess = assets.find((a) => a.asset_type === "battery_system");
  const W = 760, top = 30, colW = W / (invs.length + (bess ? 1 : 0) + 1);
  const busY = 210;
  const txY = 250, meterY = 320, gridY = 380;
  const cbFor = (inv: string) => ac.filter((e) => e.to === inv).map((e) => e.from);
  const node = (id: string | undefined, x: number, yy: number, label: string, sub?: string, shape: "box" | "circle" = "box") => {
    if (!id) return null;
    const v = live[id];
    return (
      <g onClick={() => onSelect?.(id)} style={{ cursor: "pointer" }}>
        {shape === "box" ? <rect x={x - 46} y={yy - 16} width={92} height={32} rx={5} fill="#fff" stroke="#0aa5c2" strokeWidth={1.6} /> : <circle cx={x} cy={yy} r={18} fill="#fff" stroke="#0aa5c2" strokeWidth={1.6} />}
        <text x={x} y={yy - 1} fontSize="10.5" fontWeight="700" textAnchor="middle" fill="#0b1530">{label}</text>
        <text x={x} y={yy + 11} fontSize="9.5" textAnchor="middle" fill={v?.bad ? "#b3261e" : v && !v.current ? "#b86e00" : "#08839b"}>{v?.text ?? sub ?? ""}</text>
      </g>
    );
  };
  return (
    <svg className="sld" viewBox={`0 0 ${W} 410`} style={{ width: "100%", height: 410, background: "#fbfdfe", borderRadius: 8, border: "1px solid #e3f6fa" }} role="img" aria-label="Single-line diagram">
      <text x={10} y={16} fontSize="10" fill="#5b6577">Electrical connectivity (from single-line diagram records) · live values with age · cyan = energised path</text>
      {invs.map((inv, i) => {
        const x = colW * (i + 1);
        const cbs = cbFor(inv.asset_id);
        return (
          <g key={inv.asset_id}>
            {cbs.map((cb, j) => {
              const cx = x + (j - (cbs.length - 1) / 2) * 50;
              return (
                <g key={cb}>
                  <line x1={cx} y1={top + 40} x2={x} y2={130} stroke="#0aa5c2" strokeDasharray="3 3" />
                  <rect x={cx - 20} y={top + 22} width={40} height={18} rx={3} fill="#e3f6fa" stroke="#0aa5c2" />
                  <text x={cx} y={top + 35} fontSize="8.5" textAnchor="middle" fill="#13214a">{cb.split("-").slice(-2).join(".")}</text>
                </g>
              );
            })}
            <line x1={x} y1={146} x2={x} y2={busY} stroke={live[inv.asset_id]?.bad ? "#b3261e" : "#0aa5c2"} strokeWidth={2} />
            {node(inv.asset_id, x, 130, inv.asset_id.replace(/^\w+-/, ""), `${inv.rated_capacity} kW`)}
          </g>
        );
      })}
      {bess && (
        <g>
          <line x1={colW * (invs.length + 1)} y1={146} x2={colW * (invs.length + 1)} y2={busY} stroke="#0aa5c2" strokeWidth={2} />
          {node(bess.asset_id, colW * (invs.length + 1), 130, "BESS-1", "read-only")}
        </g>
      )}
      <line x1={colW * 0.6} x2={W - colW * 0.4} y1={busY} y2={busY} stroke="#0aa5c2" strokeWidth={4} />
      <text x={colW * 0.6} y={busY - 6} fontSize="9.5" fill="#08839b">LV / MV busbar</text>
      <line x1={W / 2} y1={busY} x2={W / 2} y2={txY - 16} stroke="#0aa5c2" strokeWidth={2.5} />
      {tx && node(tx.asset_id, W / 2, txY, "TX1", `${tx.rated_capacity} kVA`)}
      <line x1={W / 2} y1={txY + 16} x2={W / 2} y2={meterY - 18} stroke="#0aa5c2" strokeWidth={2.5} />
      {meter && node(meter.asset_id, W / 2, meterY, "M", undefined, "circle")}
      {meter && <text x={W / 2 + 26} y={meterY + 4} fontSize="10" fill="#13214a">Export settlement meter · {live[meter.asset_id]?.text ?? ""}</text>}
      <line x1={W / 2} y1={meterY + 18} x2={W / 2} y2={gridY - 10} stroke="#0aa5c2" strokeWidth={2.5} />
      {grid && (
        <g onClick={() => onSelect?.(grid.asset_id)} style={{ cursor: "pointer" }}>
          <path d={`M${W / 2 - 30} ${gridY - 10} h60 M${W / 2 - 20} ${gridY - 3} h40 M${W / 2 - 10} ${gridY + 4} h20`} stroke="#13214a" strokeWidth={2} />
          <text x={W / 2 + 40} y={gridY} fontSize="10" fill="#13214a">Grid · export limit {grid.rated_capacity} kW</text>
        </g>
      )}
    </svg>
  );
}

export function Tree({ nodes, selected, onSelect }: { nodes: any[]; selected?: string; onSelect: (id: string) => void }) {
  return (
    <div className="tree">
      <ul>{nodes.map((n) => <TreeNode key={n.asset_id} n={n} selected={selected} onSelect={onSelect} depth={0} />)}</ul>
    </div>
  );
}
function TreeNode({ n, selected, onSelect, depth }: { n: any; selected?: string; onSelect: (id: string) => void; depth: number }) {
  const hide = n.asset_type === "string" && depth > 2;
  return (
    <li>
      <span className={`node ${selected === n.asset_id ? "sel" : ""}`} onClick={() => onSelect(n.asset_id)}>
        <span className="type">{n.asset_type.replace("_", " ")}</span>
        <b>{n.asset_id}</b>
        <span className="muted small">{n.rated_capacity ? `${n.rated_capacity} ${n.rated_capacity_unit}` : ""}</span>
      </span>
      {n.children?.length > 0 && !hide && <ul>{n.children.map((c: any) => <TreeNode key={c.asset_id} n={c} selected={selected} onSelect={onSelect} depth={depth + 1} />)}</ul>}
    </li>
  );
}
