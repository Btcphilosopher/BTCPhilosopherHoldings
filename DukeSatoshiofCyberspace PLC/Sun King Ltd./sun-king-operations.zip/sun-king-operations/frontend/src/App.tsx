import { NavLink, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { useState } from "react";
import { api, setToken } from "./lib/api";
import { SessionProvider, useSession } from "./lib/session";
import { SourceProvider } from "./components/ui";
import { useLive } from "./lib/hooks";
import Overview from "./pages/Overview";
import Sites from "./pages/Sites";
import Assets from "./pages/Assets";
import Generation from "./pages/Generation";
import Performance from "./pages/Performance";
import Alerts from "./pages/Alerts";
import Maintenance from "./pages/Maintenance";
import Forecasts from "./pages/Forecasts";
import Storage from "./pages/Storage";
import Commercial from "./pages/Commercial";
import Reports from "./pages/Reports";
import Administration from "./pages/Administration";

const NAV: [string, string][] = [
  ["/", "Overview"], ["/sites", "Sites"], ["/assets", "Assets"], ["/generation", "Generation"], ["/performance", "Performance"],
  ["/alerts", "Alerts"], ["/maintenance", "Maintenance"], ["/forecasts", "Forecasts"], ["/storage", "Storage"],
  ["/commercial", "Commercial"], ["/reports", "Reports"], ["/admin", "Administration"],
];

export default function App() {
  return (
    <SessionProvider>
      <SourceProvider>
        <Shell />
      </SourceProvider>
    </SessionProvider>
  );
}

function Shell() {
  const { me, setMe, siteId, setSiteId } = useSession();
  const live = useLive();
  const loc = useLocation();
  if (!me) return <Login />;
  const title = NAV.find(([p]) => (p === "/" ? loc.pathname === "/" : loc.pathname.startsWith(p)))?.[1] ?? "";
  return (
    <div className="app">
      <aside className="nav">
        <div className="brand">
          <svg width="34" height="34" viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="11" fill="#f2b705" /><g stroke="#f2b705" strokeWidth="4" strokeLinecap="round"><path d="M32 8v8M32 48v8M8 32h8M48 32h8M15 15l6 6M43 43l6 6M15 49l6-6M43 21l6-6" /></g></svg>
          <div><b>SUN KING</b><small>Solar Farm Operations</small></div>
        </div>
        <nav>
          {NAV.map(([p, l]) => (
            <NavLink key={p} to={p} end={p === "/"}><span className="dot" />{l}</NavLink>
          ))}
        </nav>
        <div className="foot">
          <div style={{ color: "#fff", fontWeight: 600 }}>{me.display_name}</div>
          <div className="small">{me.org_role === "admin" ? "Organisation admin" : Object.entries(me.sites).map(([s, r]) => `${s.replace("site-", "").toUpperCase()}: ${r}`).join(" · ")}</div>
          <div className="small" style={{ marginTop: 4 }}>{live.connected ? "● live link" : "○ live link reconnecting"}</div>
          <button onClick={() => { setToken(null); setMe(null); }}>Sign out</button>
        </div>
      </aside>
      <div className="main">
        <header className="topbar">
          <div>
            <h1>{title}</h1>
            <div className="sub">Sun King Pennine Portfolio · fictional sites, synthetic data · times shown in site-local time (Europe/London), stored in UTC</div>
          </div>
          <div className="row">
            <label className="small muted" htmlFor="site-sel">Site</label>
            <select id="site-sel" value={siteId} onChange={(e) => setSiteId(e.target.value)}>
              {Object.keys(me.sites).map((s) => <option key={s} value={s}>{s === "site-hlm" ? "Hollin Moor (HLM)" : s === "site-cle" ? "Calder Edge (CLE)" : s}</option>)}
            </select>
          </div>
        </header>
        <main className="content">
          <Routes>
            <Route path="/" element={<Overview live={live.snap} />} />
            <Route path="/sites" element={<Sites />} />
            <Route path="/assets" element={<Assets />} />
            <Route path="/generation" element={<Generation live={live.snap} />} />
            <Route path="/performance" element={<Performance />} />
            <Route path="/alerts" element={<Alerts />} />
            <Route path="/maintenance" element={<Maintenance />} />
            <Route path="/forecasts" element={<Forecasts />} />
            <Route path="/storage" element={<Storage />} />
            <Route path="/commercial" element={<Commercial />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/admin" element={<Administration />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

function Login() {
  const { setMe } = useSession();
  const [email, setEmail] = useState("admin@sunking.example");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const r = await api.post<{ access_token: string; user: any }>("/api/auth/login", { email, password });
      setToken(r.access_token);
      setMe(r.user);
    } catch (x) {
      setErr((x as Error).message);
    }
  };
  return (
    <div className="login">
      <form className="box" onSubmit={submit}>
        <div className="row" style={{ marginBottom: 14 }}>
          <svg width="40" height="40" viewBox="0 0 64 64"><rect width="64" height="64" rx="12" fill="#0b1530" /><circle cx="32" cy="32" r="11" fill="#f2b705" /></svg>
          <div><b style={{ letterSpacing: ".14em" }}>SUN KING</b><div className="small muted">Solar Farm Operations — organisational sign-in</div></div>
        </div>
        <label className="f">Email<input value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" /></label>
        <div style={{ height: 10 }} />
        <label className="f">Password<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" /></label>
        {err && <div className="notice crit" style={{ marginTop: 10 }}>{err}</div>}
        <div style={{ height: 14 }} />
        <button className="btn primary" style={{ width: "100%", justifyContent: "center" }}>Sign in</button>
        <p className="small muted" style={{ marginTop: 14 }}>
          Demo accounts (password from <code>SUN_KING_DEMO_PASSWORD</code>, default <code>sunking-demo</code>): admin@, engineer@, tech@ (Hollin Moor field technician), viewer@ (Calder Edge read-only) — all <code>@sunking.example</code>.
        </p>
      </form>
    </div>
  );
}
