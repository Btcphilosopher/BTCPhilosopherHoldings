export const SITE_TZ = "Europe/London";

export function fmt(v: number | null | undefined, digits = 1): string {
  if (v === null || v === undefined || Number.isNaN(v)) return "—";
  return v.toLocaleString("en-GB", { minimumFractionDigits: digits, maximumFractionDigits: digits });
}
export function pct(v: number | null | undefined, digits = 1): string {
  if (v === null || v === undefined) return "—";
  return `${(v * 100).toFixed(digits)}%`;
}
export function energy(kwh: number | null | undefined): { v: string; u: string } {
  if (kwh === null || kwh === undefined) return { v: "—", u: "kWh" };
  if (Math.abs(kwh) >= 10000) return { v: fmt(kwh / 1000, 2), u: "MWh" };
  return { v: fmt(kwh, 0), u: "kWh" };
}
export function power(kw: number | null | undefined): { v: string; u: string } {
  if (kw === null || kw === undefined) return { v: "—", u: "kW" };
  if (Math.abs(kw) >= 10000) return { v: fmt(kw / 1000, 2), u: "MW" };
  return { v: fmt(kw, 0), u: "kW" };
}
export function localTime(iso: string | null | undefined, tz = SITE_TZ, withDate = true): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString("en-GB", {
    timeZone: tz,
    hour: "2-digit",
    minute: "2-digit",
    ...(withDate ? { day: "2-digit", month: "short" } : {}),
  });
}
export function hhmm(iso: string, tz = SITE_TZ) {
  return new Date(iso).toLocaleTimeString("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit" });
}
export function dayLabel(iso: string, tz = SITE_TZ) {
  return new Date(iso).toLocaleString("en-GB", { timeZone: tz, day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
}
export function age(seconds: number | null | undefined): string {
  if (seconds === null || seconds === undefined) return "never";
  if (seconds < 90) return `${Math.round(seconds)} s`;
  if (seconds < 5400) return `${Math.round(seconds / 60)} min`;
  if (seconds < 172800) return `${(seconds / 3600).toFixed(1)} h`;
  return `${Math.round(seconds / 86400)} d`;
}
export function isoDay(d: Date) {
  return d.toLocaleDateString("en-CA", { timeZone: SITE_TZ });
}
export function addDays(iso: string, n: number) {
  const d = new Date(iso + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
export const titleCase = (s: string) => s.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

/** ISO time `hours` ago, rounded down to the minute so request URLs stay stable between renders. */
export function agoISO(hours: number) {
  return new Date(Math.floor((Date.now() - hours * 3600e3) / 60000) * 60000).toISOString();
}
