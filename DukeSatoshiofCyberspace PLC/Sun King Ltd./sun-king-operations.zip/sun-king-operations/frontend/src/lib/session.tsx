import { createContext, ReactNode, useContext, useEffect, useState } from "react";
import { api, getToken, setToken } from "./api";

export type Me = { id: string; email: string; display_name: string; org_role: string; sites: Record<string, string> };
const Ctx = createContext<{ me: Me | null; setMe: (m: Me | null) => void; siteId: string; setSiteId: (s: string) => void }>({
  me: null, setMe: () => {}, siteId: "", setSiteId: () => {},
});

export function SessionProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [ready, setReady] = useState(false);
  const [siteId, setSiteIdState] = useState<string>(() => { try { return localStorage.getItem("sunking.site") ?? ""; } catch { return ""; } });
  const setSiteId = (s: string) => { setSiteIdState(s); try { localStorage.setItem("sunking.site", s); } catch { /* ignore */ } };
  useEffect(() => {
    if (!getToken()) { setReady(true); return; }
    api.get<Me>("/api/auth/me").then(setMe).catch(() => setToken(null)).finally(() => setReady(true));
    const out = () => setMe(null);
    window.addEventListener("sunking:logout", out);
    return () => window.removeEventListener("sunking:logout", out);
  }, []);
  useEffect(() => {
    if (me && (!siteId || !me.sites[siteId])) setSiteId(Object.keys(me.sites)[0] ?? "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [me]);
  if (!ready) return null;
  return <Ctx.Provider value={{ me, setMe, siteId, setSiteId }}>{children}</Ctx.Provider>;
}
export const useSession = () => useContext(Ctx);
export const ROLE_RANK: Record<string, number> = { viewer: 0, field_technician: 1, operator: 2, engineer: 3, manager: 4, admin: 5 };
export function can(me: Me | null, siteId: string, role: string) {
  if (!me) return false;
  const r = me.sites[siteId];
  return r !== undefined && ROLE_RANK[r] >= ROLE_RANK[role];
}
