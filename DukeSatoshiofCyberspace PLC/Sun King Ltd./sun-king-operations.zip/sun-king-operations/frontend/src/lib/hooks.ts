import { useCallback, useEffect, useRef, useState } from "react";
import { api, getToken } from "./api";

export function useApi<T = any>(url: string | null, deps: unknown[] = [], refreshMs?: number) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const urlRef = useRef(url);
  urlRef.current = url;
  const load = useCallback(async () => {
    if (!urlRef.current) return;
    setLoading(true);
    try {
      const d = await api.get<T>(urlRef.current);
      setData(d);
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    setData(null);
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url, ...deps]);
  useEffect(() => {
    if (!refreshMs) return;
    const id = setInterval(load, refreshMs);
    return () => clearInterval(id);
  }, [refreshMs, load]);
  return { data, error, loading, reload: load, setData };
}

export type LiveSnapshot = {
  at: string;
  sites: { site_id: string; age_s: number | null; is_current: boolean; newest_observation: string | null; active_alerts: number;
    export_kw: { value: number | null; observation_time: string; is_current: boolean } | null }[];
};

export function useLive(): { snap: LiveSnapshot | null; connected: boolean } {
  const [snap, setSnap] = useState<LiveSnapshot | null>(null);
  const [connected, setConnected] = useState(false);
  useEffect(() => {
    let ws: WebSocket | null = null;
    let stop = false;
    let retry = 1000;
    const open = () => {
      const tok = getToken();
      if (!tok || stop) return;
      const proto = location.protocol === "https:" ? "wss" : "ws";
      ws = new WebSocket(`${proto}://${location.host}/ws/live?token=${encodeURIComponent(tok)}`);
      ws.onopen = () => { setConnected(true); retry = 1000; };
      ws.onmessage = (m) => { try { setSnap(JSON.parse(m.data)); } catch { /* ignore */ } };
      ws.onclose = () => { setConnected(false); if (!stop) setTimeout(open, (retry = Math.min(retry * 2, 30000))); };
    };
    open();
    return () => { stop = true; ws?.close(); };
  }, []);
  return { snap, connected };
}

export function useOnline() {
  const [online, setOnline] = useState(typeof navigator === "undefined" ? true : navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, []);
  return online;
}
