import { useState } from "react";
import { useApi, LiveSnapshot } from "../lib/hooks";
import { useSession } from "../lib/session";
import { Badge, Card, Freshness, Loading, SourceLink, StatusBadge } from "../components/ui";
import { TimeChart } from "../components/charts";
import { age, agoISO, fmt, localTime } from "../lib/format";
import { qs } from "../lib/api";

const WINDOWS: [string, number][] = [["6 h", 6], ["24 h", 24], ["3 days", 72], ["7 days", 168]];

export default function Generation({ live }: { live: LiveSnapshot | null }) {
  const { siteId } = useSession();
  const [hours, setHours] = useState(24);
  const start = agoISO(hours);
  const res = hours > 72 ? "30min" : hours > 24 ? "15min" : "5min";
  const k = [siteId, hours, live?.at];
  const inv = useApi<any>(`/api/telemetry/series?${qs({ site_id: siteId, measurement_type: "ac_power", asset_type: "inverter", start, resample: res })}`, k);
  const met = useApi<any>(`/api/telemetry/series?${qs({ site_id: siteId, measurement_type: "ac_power", asset_type: "meter", start, resample: res })}`, k);
  const poa = useApi<any>(`/api/telemetry/series?${qs({ site_id: siteId, measurement_type: "poa_irradiance", start, resample: res })}`, k);
  const tmp = useApi<any>(`/api/telemetry/series?${qs({ site_id: siteId, measurement_type: "module_temperature", start, resample: res })}`, k);
  const latest = useApi<any>(`/api/telemetry/latest?site_id=${siteId}`, [siteId, live?.at]);
  const multi = hours > 24;
  const end = agoISO(0);
  return (
    <>
      <div className="row" style={{ marginBottom: 12 }}>
        {WINDOWS.map(([l, h]) => <button key={l} className={`btn sm ${hours === h ? "primary" : ""}`} onClick={() => setHours(h)}>{l}</button>)}
        <span className="spacer" />
        <span className="small muted">Mean of good-quality samples per {res}; gaps are shown as gaps (never zero).</span>
      </div>
      <div className="grid g2">
        <Card title="Export settlement meter — active power (kW)" actions={met.data?.assets?.[0] && <SourceLink url={`/api/telemetry/observations?${qs({ asset_id: met.data.assets[0], measurement_type: "ac_power", start, end })}`} />}>
          {met.data ? <TimeChart data={met.data.points} unit="kW" series={met.data.assets.map((a: string) => ({ key: a, name: a, type: "area" as const, color: "#13214a" }))} multiDay={multi} /> : <Loading error={met.error} />}
        </Card>
        <Card title="Inverter AC power (kW)">
          {inv.data ? <TimeChart data={inv.data.points} unit="kW" series={inv.data.assets.map((a: string) => ({ key: a, name: a }))} multiDay={multi} /> : <Loading error={inv.error} />}
        </Card>
        <Card title="Plane-of-array irradiance (W/m²) — both reference sensors">
          {poa.data ? <TimeChart data={poa.data.points} unit="W/m²" series={poa.data.assets.map((a: string, i: number) => ({ key: a, name: a, color: i ? "#f2b705" : "#0aa5c2", dashed: i === 1 }))} multiDay={multi} /> : <Loading />}
          <p className="small muted">Suspect samples (e.g. stuck-value flags) are excluded from this view; see raw records via the source drawer.</p>
        </Card>
        <Card title="Module back-of-panel temperature (°C)">
          {tmp.data ? <TimeChart data={tmp.data.points} unit="°C" series={tmp.data.assets.map((a: string) => ({ key: a, name: a, color: "#d0662b" }))} multiDay={multi} /> : <Loading />}
        </Card>
      </div>
      <Card title="Latest measurements" actions={latest.data && <span className="small muted">stale after {latest.data.stale_after_s / 60} min</span>}>
        {!latest.data ? <Loading /> : (
          <div className="scroll" style={{ maxHeight: 420 }}>
            <table className="t">
              <thead><tr><th>Asset</th><th>Measurement</th><th className="num">Value</th><th>Unit</th><th>Observed (site time)</th><th>Age</th><th>Quality</th><th>Source</th><th></th></tr></thead>
              <tbody>
                {latest.data.values.sort((a: any, b: any) => a.asset_id.localeCompare(b.asset_id) || a.measurement_type.localeCompare(b.measurement_type)).map((v: any) => (
                  <tr key={`${v.asset_id}-${v.measurement_type}`}>
                    <td>{v.asset_id}</td><td>{v.measurement_type}</td>
                    <td className="num">{v.value === null ? "—" : fmt(v.value, v.unit === "fraction" ? 3 : 1)}</td><td>{v.unit}</td>
                    <td>{localTime(v.observation_time)}</td>
                    <td>{v.is_current ? <span className="ok-text">{age(v.age_s)}</span> : <Badge tone="warn">{age(v.age_s)} — not current</Badge>}</td>
                    <td><StatusBadge status={v.quality === "good" ? "ok" : v.quality} /></td>
                    <td className="small muted">{v.source}</td>
                    <td><SourceLink url={`/api/telemetry/raw/${v.measurement_id}`} label="raw" /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {live && <p className="small muted">Live link: {live.sites.map((s) => <span key={s.site_id} style={{ marginRight: 12 }}>{s.site_id}: <Freshness ageS={s.age_s} current={s.is_current} /></span>)}</p>}
      </Card>
    </>
  );
}
