import { useState } from "react";
import { useApi } from "../lib/hooks";
import { can, useSession } from "../lib/session";
import { Badge, Card, Loading, SourceLink } from "../components/ui";
import { addDays, fmt, isoDay } from "../lib/format";
import { api } from "../lib/api";

export default function Commercial() {
  const { siteId, me } = useSession();
  const { data, error } = useApi<any>(`/api/commercial/sites/${siteId}`, [siteId]);
  const [lost, setLost] = useState<any>(null);
  if (!data) return <Loading error={error} />;
  const ev = data.estimated_value;
  const runLost = (withPrice: boolean) => {
    const d = addDays(isoDay(new Date()), siteId === "site-hlm" ? -3 : -4);
    api.post("/api/commercial/lost-revenue", { site_id: siteId, start: `${d}T08:00:00Z`, end: `${d}T16:00:00Z`, use_model_baseline: true,
      ...(withPrice ? { price_per_mwh: 72.5, currency: "GBP", price_source: "HLM PPA schedule 2 (fictional) — fixed price" } : {}) }).then(setLost);
  };
  return (
    <>
      <div className="notice">Measured export, estimated value, contract terms, settlement statements, receipts, maintenance costs and scenarios are kept separate. Gross generation is never treated as exported or billable energy.</div>
      <div className="grid g3" style={{ marginTop: 12 }}>
        <Card title="1 · Measured export (settlement meter)">
          <div className="stat"><span className="value">{fmt((ev.measured_export_kwh ?? 0) / 1000, 3)}<span className="unit">MWh</span></span>
            <span className="meta">{ev.period.start} → {ev.period.end} · {ev.measured_export_complete ? <Badge tone="ok">complete</Badge> : <Badge tone="warn">incomplete: {ev.measured_export_flags?.join(", ")}</Badge>} {ev.sources?.[0] && <SourceLink url={ev.sources[0]} />}</span></div>
        </Card>
        <Card title="2 · Estimated energy value">
          {ev.status === "estimate" ? (
            <div className="stat"><span className="value">{ev.currency} {fmt(ev.estimated_value, 2)}</span>
              <span className="meta"><Badge tone="warn">ESTIMATE</Badge> {ev.price.type === "fixed" ? `fixed ${ev.currency} ${ev.price.per_mwh}/MWh` : `index ${ev.price.series} (${ev.price.points} half-hours${ev.price.synthetic ? ", SYNTHETIC" : ""})`}</span></div>
          ) : <div className="notice warn">{ev.reason}</div>}
          {ev.warning && <div className="notice warn small">{ev.warning}</div>}
          <p className="small muted">{ev.label}</p>
        </Card>
        <Card title="3 · Contracts">
          {data.contracts.map((c: any) => (
            <dl key={c.id} className="kv small"><dt>Counterparty</dt><dd>{c.counterparty}</dd><dt>Type</dt><dd>{c.contract_type}</dd><dt>Period</dt><dd>{c.start_date} → {c.end_date}</dd>
              <dt>Price</dt><dd>{c.fixed_price_per_mwh ? `${c.currency} ${c.fixed_price_per_mwh}/MWh` : `index ${c.price_series_id}`}</dd><dt>Price source</dt><dd>{c.price_source}</dd><dt>Settlement meter</dt><dd>{c.settlement_meter_asset_id}</dd></dl>
          ))}
        </Card>
      </div>
      <Card title="4–5 · Settlement statements, reconciliation and receipts">
        {data.reconciliation.length === 0 ? <div className="empty">No statements imported for this site.</div> : (
          <table className="t"><thead><tr><th>Statement</th><th>Period</th><th className="num">Settled MWh</th><th className="num">Measured MWh</th><th className="num">Difference</th><th className="num">Statement amount</th><th className="num">Estimated value</th><th className="num">Receipts</th><th className="num">Outstanding</th></tr></thead>
            <tbody>{data.reconciliation.map((r: any) => (
              <tr key={r.statement_id}><td>{r.statement_ref}</td><td className="small">{r.period.join(" → ")}</td><td className="num">{fmt(r.settled_energy_mwh, 3)}</td>
                <td className="num">{fmt(r.measured_export_mwh, 3)} {!r.measured_complete && <Badge tone="warn">incomplete</Badge>}</td><td className="num">{fmt(r.energy_difference_mwh, 3)}</td>
                <td className="num">{r.currency} {fmt(r.statement_amount, 2)}</td><td className="num">{fmt(r.estimated_value, 2)}</td><td className="num">{fmt(r.receipts_total, 2)}</td><td className="num">{fmt(r.outstanding, 2)}</td></tr>))}</tbody></table>
        )}
        <p className="small muted">The statement is the authoritative billing figure; the measured value is our independent check. Differences can arise from line-loss factors, meter-data validation or estimation by the settlement body.</p>
      </Card>
      <div className="grid g2" style={{ marginTop: 16 }}>
        <Card title="6 · Recorded maintenance costs">
          {Object.entries(data.maintenance_costs.recorded_costs).map(([cur, v]: any) => <p key={cur}><b>{cur} {fmt(v.total, 2)}</b> · {Object.entries(v.by_category).map(([k, x]: any) => `${k}: ${fmt(x, 0)}`).join(" · ")}</p>)}
          <table className="t"><tbody>{data.maintenance_costs.items.map((c: any) => <tr key={c.id}><td>{c.date}</td><td>{c.category}</td><td className="num">{c.currency} {fmt(c.amount, 2)}</td><td className="small">{c.invoice_ref}</td></tr>)}</tbody></table>
        </Card>
        <Card title="7 · Scenario: estimated lost revenue" actions={can(me, siteId, "engineer") && <><button className="btn sm" onClick={() => runLost(false)}>Without valuation</button><button className="btn sm primary" onClick={() => runLost(true)}>With documented price</button></>}>
          {!lost ? <p className="muted small">Estimates lost energy against the pvlib baseline for the {siteId === "site-hlm" ? "inverter-failure" : "curtailment"} day (08:00–16:00). Shown only when baseline, period and valuation are documented.</p> :
            lost.status !== "estimate" ? <div className="notice warn">Not estimated — {lost.reason}</div> : (
              <dl className="kv"><dt>Lost energy</dt><dd>{fmt(lost.lost_energy_kwh, 0)} kWh</dd><dt>Estimated lost value</dt><dd><b>{lost.currency} {fmt(lost.estimated_lost_value, 2)}</b> <Badge tone="warn">ESTIMATE</Badge></dd>
                <dt>Baseline</dt><dd className="small">{fmt(lost.assumptions.baseline_kwh, 0)} kWh — {lost.assumptions.baseline_method}</dd><dt>Measured</dt><dd>{fmt(lost.assumptions.measured_kwh, 0)} kWh</dd>
                <dt>Price</dt><dd className="small">{lost.currency} {lost.assumptions.price_per_mwh}/MWh — {lost.assumptions.price_source}</dd><dt>Period</dt><dd className="small">{lost.affected_period.start} → {lost.affected_period.end}</dd></dl>
            )}
        </Card>
      </div>
    </>
  );
}
