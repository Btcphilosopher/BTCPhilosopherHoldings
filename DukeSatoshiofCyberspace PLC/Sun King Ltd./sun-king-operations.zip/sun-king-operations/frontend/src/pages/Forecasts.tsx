import { useEffect, useState } from "react";
import { useApi } from "../lib/hooks";
import { can, useSession } from "../lib/session";
import { Badge, Card, Loading } from "../components/ui";
import { TimeChart } from "../components/charts";
import { fmt, localTime } from "../lib/format";
import { api } from "../lib/api";

export default function Forecasts() {
  const { siteId, me } = useSession();
  const list = useApi<any[]>(`/api/forecasts?site_id=${siteId}`, [siteId]);
  const evals = useApi<any[]>(`/api/forecasts/evaluation?site_id=${siteId}`, [siteId]);
  const [sel, setSel] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (list.data?.length && !sel) setSel(list.data.find((f) => f.horizon_type === "day_ahead" && f.kind === "forecast")?.id ?? list.data[0].id); }, [list.data]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => setSel(null), [siteId]);
  const fc = useApi<any>(sel ? `/api/forecasts/${sel}` : null, [sel]);
  const issue = async (h: string) => {
    setBusy(true);
    try { const r = await api.post("/api/forecasts/issue", { site_id: siteId, horizon_type: h }); await list.reload(); await evals.reload(); setSel(r.id); } finally { setBusy(false); }
  };
  const latestEval = (h: string) => evals.data?.find((e) => e.name.includes(h));
  return (
    <>
      <div className="grid g3">
        <Card title="Forecasts" actions={can(me, siteId, "engineer") && <>
          <button className="btn sm gold" disabled={busy} onClick={() => issue("day_ahead")}>{busy ? "Training…" : "Issue day-ahead"}</button>
          <button className="btn sm" disabled={busy} onClick={() => issue("intraday")}>Issue intraday</button></>}>
          {!list.data ? <Loading /> : (
            <div className="scroll" style={{ maxHeight: 520 }}>
              <table className="t"><thead><tr><th>Issued</th><th>Type</th><th>Kind</th><th>Model</th></tr></thead>
                <tbody>{list.data.map((f) => (
                  <tr key={f.id} className={sel === f.id ? "sel" : ""} onClick={() => setSel(f.id)} style={{ cursor: "pointer" }}>
                    <td className="small">{localTime(f.issue_time)}</td><td>{f.horizon_type === "day_ahead" ? "Day-ahead" : "Intraday"}</td>
                    <td>{f.kind === "retrospective" ? <Badge tone="warn">retrospective</Badge> : <Badge tone="info">forecast</Badge>}</td>
                    <td className="small">{f.model_name} {f.model_version}</td>
                  </tr>))}</tbody></table>
            </div>
          )}
        </Card>
        <Card className="span2" title={fc.data ? `${fc.data.horizon_type === "day_ahead" ? "Day-ahead" : "Intraday"} forecast — site PV AC power (kW)` : "Forecast"}>
          {!fc.data ? <Loading /> : (
            <>
              {fc.data.kind === "retrospective" && <div className="notice warn small">RETROSPECTIVE run using observed weather — this is a model back-cast, not a forecast that could have been issued in advance.</div>}
              <TimeChart data={fc.data.values} unit="kW" multiDay band={{ low: "p10_kw", high: "p90_kw", name: "P10–P90 interval" }} series={[
                { key: "p50_kw", name: "P50 (model)", color: "#13214a", width: 2.2 },
                { key: "nwp_physical_kw", name: "Weather baseline (NWP → pvlib)", color: "#f2b705", dashed: true },
                { key: "persistence_kw", name: "Persistence baseline", color: "#9aa4b5", dashed: true },
                { key: "actual_kw", name: "Measured (sum of inverters)", color: "#0aa5c2", width: 2 },
              ]} height={300} />
              <dl className="kv small" style={{ marginTop: 8 }}>
                <dt>Issue time</dt><dd>{localTime(fc.data.issue_time)} ({fc.data.issue_time})</dd>
                <dt>Target period</dt><dd>{localTime(fc.data.target_start)} → {localTime(fc.data.target_end)}</dd>
                <dt>Model / version</dt><dd>{fc.data.model_name} {fc.data.model_version} · status <b>{fc.data.status}</b></dd>
                <dt>Weather input</dt><dd>{fc.data.weather_source} {fc.data.weather_issue_time && <>· NWP issued {localTime(fc.data.weather_issue_time)} (available after +3 h 30)</>}</dd>
                <dt>Provenance</dt><dd>{fc.data.notes?.provenance}</dd>
                <dt>Training</dt><dd>{fc.data.notes?.train_rows} rows · {fc.data.notes?.notes?.join("; ")}</dd>
              </dl>
            </>
          )}
        </Card>
      </div>
      <div className="grid g2" style={{ marginTop: 16 }}>
        {["day_ahead", "intraday"].map((h) => <EvalCard key={h} title={h === "day_ahead" ? "Day-ahead evaluation (held-out later period)" : "Intraday evaluation (held-out later period)"} e={latestEval(h)} />)}
      </div>
    </>
  );
}

function EvalCard({ title, e }: { title: string; e: any }) {
  if (!e) return <Card title={title}><div className="empty">No evaluation yet.</div></Card>;
  const ev = e.evaluation;
  const row = (n: string, m: any) => <tr key={n}><td>{n}</td><td className="num">{m?.n ?? 0}</td><td className="num">{fmt(m?.mae_kw, 1)}</td><td className="num">{fmt(m?.rmse_kw, 1)}</td><td className="num">{fmt((m?.nmae_capacity ?? 0) * 100, 2)}%</td><td className="num">{fmt(m?.bias_kw, 1)}</td></tr>;
  return (
    <Card title={title} actions={<Badge tone={ev.status === "ok" ? "ok" : "warn"}>{ev.status}</Badge>}>
      <p className="small muted">Train {ev.train_rows} rows before {ev.split_time?.slice(0, 16)} · test {ev.test_rows} rows after. Curtailed intervals excluded ({ev.excluded_curtailed_rows}).</p>
      <table className="t"><thead><tr><th>Model</th><th className="num">n</th><th className="num">MAE kW</th><th className="num">RMSE kW</th><th className="num">nMAE</th><th className="num">Bias</th></tr></thead>
        <tbody>{row("GBM quantile (P50)", ev.model)}{row("Weather baseline", ev.nwp_physical)}{row("Persistence", ev.persistence)}</tbody></table>
      <p className="small">Skill vs persistence <b>{fmt((ev.skill_vs_persistence ?? 0) * 100, 1)}%</b> · vs weather baseline <b>{fmt((ev.skill_vs_nwp_physical ?? 0) * 100, 1)}%</b> · P10–P90 coverage <b>{fmt((ev.interval_coverage_p10_p90 ?? 0) * 100, 0)}%</b> (nominal 80%)</p>
      <h3>MAE by horizon (kW)</h3>
      <table className="t"><thead><tr><th>Horizon</th><th className="num">n</th><th className="num">Model</th><th className="num">Weather</th><th className="num">Persistence</th></tr></thead>
        <tbody>{Object.entries(ev.by_horizon ?? {}).map(([k, v]: any) => <tr key={k}><td>{k}</td><td className="num">{v.model.n}</td><td className="num">{fmt(v.model.mae_kw, 1)}</td><td className="num">{fmt(v.nwp_physical.mae_kw, 1)}</td><td className="num">{fmt(v.persistence.mae_kw, 1)}</td></tr>)}</tbody></table>
      <h3>MAE by generation level (kW)</h3>
      <table className="t"><tbody>{Object.entries(ev.by_generation_level ?? {}).map(([k, v]: any) => <tr key={k}><td>{k}</td><td className="num">n {v.model.n}</td><td className="num">model {fmt(v.model.mae_kw, 1)}</td><td className="num">persistence {fmt(v.persistence.mae_kw, 1)}</td></tr>)}</tbody></table>
      <p className="small muted">Rows with missing persistence input: {ev.missing_input_rows?.persistence_missing}; model MAE on those: {fmt(ev.missing_input_rows?.model_when_persistence_missing?.mae_kw, 1)} kW. Small synthetic sample — treat skill as indicative only.</p>
    </Card>
  );
}
