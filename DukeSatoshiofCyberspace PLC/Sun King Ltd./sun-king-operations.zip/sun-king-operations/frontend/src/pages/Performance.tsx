import { useState } from "react";
import { useApi } from "../lib/hooks";
import { useSession } from "../lib/session";
import { Badge, Card, Loading, MetricCard } from "../components/ui";
import { TimeChart } from "../components/charts";
import { addDays, fmt, isoDay, titleCase } from "../lib/format";
import { api, qs } from "../lib/api";

function dayStartUTC(day: string) { return new Date(day + "T00:00:00Z").toISOString(); }

export default function Performance() {
  const { siteId } = useSession();
  const today = isoDay(new Date());
  const [preset, setPreset] = useState("yesterday");
  const ranges: Record<string, [string, string]> = {
    yesterday: [addDays(today, -1), today],
    "3d": [addDays(today, -3), today],
    "7d": [addDays(today, -7), today],
    failure: [addDays(today, -3), addDays(today, -2)],
  };
  const [s, e] = ranges[preset];
  const start = dayStartUTC(s), end = dayStartUTC(e);
  const { data, error } = useApi<any>(`/api/performance/sites/${siteId}?${qs({ start, end })}`, [siteId, preset]);
  const exp = useApi<any>(`/api/performance/sites/${siteId}/expected?${qs({ start: dayStartUTC(addDays(e, -1)), end })}`, [siteId, preset]);
  return (
    <>
      <div className="row" style={{ marginBottom: 12 }}>
        {[["yesterday", "Yesterday"], ["3d", "Last 3 days"], ["7d", "Last 7 days"], ["failure", "Inverter failure day (D-3)"]].map(([k, l]) => (
          <button key={k} className={`btn sm ${preset === k ? "primary" : ""}`} onClick={() => setPreset(k)}>{l}</button>
        ))}
        <span className="spacer" /><span className="small muted">Window {s} → {e} (UTC day boundaries) · model: pvlib PVWatts + SAPM + Hay–Davies</span>
      </div>
      {!data ? <Loading error={error} /> : (
        <>
          <div className="grid g4">
            <MetricCard title="Specific yield (export)" m={data.specific_yield} />
            <MetricCard title="Performance ratio (site)" m={data.performance_ratio} />
            {Object.entries(data.performance_ratio_by_inverter).map(([k, m]) => <MetricCard key={k} title={`PR ${k} (coplanar)`} m={m} />)}
            <div className="card stat">
              <span className="label">Irradiance basis</span>
              <span className="value" style={{ fontSize: 18 }}>{titleCase(data.losses.irradiance_basis.status)}</span>
              <span className="meta">used: {data.losses.irradiance_basis.sensors_used.join(", ") || "none"}</span>
              {Object.entries(data.losses.irradiance_basis.sensors_excluded).map(([k, v]) => <div key={k} className="notice warn small">{k} excluded: {String(v)}</div>)}
              {data.losses.irradiance_basis.notes.map((n: string, i: number) => <div key={i} className="small muted">{n}</div>)}
            </div>
          </div>
          <div className="grid g3" style={{ marginTop: 16 }}>
            <Card title="Expected vs measured (last day of window)" className="span2">
              {exp.data ? <TimeChart data={exp.data.series} unit="kW" rightUnit="W/m²" series={[
                { key: "expected_ac_kw", name: "Expected AC (model)", color: "#f2b705", width: 2 },
                { key: "measured_inverter_ac_kw", name: "Measured inverter AC", color: "#13214a" },
                { key: "export_meter_kw", name: "Export meter", color: "#0aa5c2", dashed: true },
                { key: "poa_wm2", name: "POA irradiance", color: "#9aa4b5", yAxis: "right" },
              ]} multiDay /> : <Loading />}
              <p className="small muted">{exp.data?.note}</p>
            </Card>
            <Card title="Loss categories (kWh)">
              <LossTable losses={data.losses} />
            </Card>
          </div>
          <Card title="Inverter comparison (weather-adjusted)">
            <table className="t">
              <thead><tr><th>Inverter</th><th className="num">Measured kWh</th><th className="num">Expected kWh</th><th className="num">Performance index</th><th className="num">Peer z</th><th className="num">kWh/kWp</th><th>Availability</th><th>Irradiance basis</th><th>Intervals</th></tr></thead>
              <tbody>
                {data.inverters.map((r: any) => {
                  const av = data.availability[r.asset_id];
                  const z = r.peer_robust_z;
                  return (
                    <tr key={r.asset_id}>
                      <td><b>{r.asset_id}</b></td>
                      <td className="num">{fmt(r.measured_kwh, 0)}</td><td className="num">{fmt(r.expected_kwh, 0)}</td>
                      <td className="num">{r.performance_index ? <>{fmt(r.performance_index * 100, 1)}% <span className="muted small">±{fmt(r.performance_index_uncertainty * 100, 1)}</span></> : "—"}</td>
                      <td className="num">{z === undefined ? "—" : <span className={z < -3 ? "crit-text" : z < -2 ? "warn-text" : ""}>{fmt(z, 1)}</span>}</td>
                      <td className="num">{fmt(r.specific_yield_kwh_per_kwp, 2)}</td>
                      <td>{av?.value !== null && av?.value !== undefined ? <>{fmt(av.value * 100, 1)}% {av.status === "estimate" && <Badge tone="warn" title="Some intervals had no telemetry">bounds {fmt(av.uncertainty.lower_bound * 100, 0)}–{fmt(av.uncertainty.upper_bound * 100, 0)}%</Badge>}</> : "—"}</td>
                      <td className="small">{r.irradiance_basis}</td>
                      <td className="small muted">{Object.entries(r.intervals).filter(([k]) => k !== "night").map(([k, v]) => `${k}: ${v}`).join(" · ")}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <p className="small muted">Index = Σ measured / Σ expected over comparable intervals (curtailed and no-telemetry intervals excluded from both). Peer z is a robust z-score of the index against the other inverters. Transposed irradiance carries ±7% (k=1) model uncertainty vs ±3.5% for coplanar POA.</p>
          </Card>
          <CleaningTools siteId={siteId} />
        </>
      )}
    </>
  );
}

function LossTable({ losses }: { losses: any }) {
  const cats = Object.entries(losses.categories) as [string, any][];
  const max = Math.max(...cats.map(([, v]) => Math.abs(v.kwh)), 1);
  return (
    <>
      <dl className="kv small"><dt>Expected (model)</dt><dd>{fmt(losses.expected_kwh, 0)} kWh</dd><dt>Measured inverter AC</dt><dd>{fmt(losses.measured_inverter_ac_kwh, 0)} kWh</dd></dl>
      <table className="t" style={{ marginTop: 8 }}>
        <tbody>
          {cats.map(([k, v]) => (
            <tr key={k}>
              <td style={{ width: "42%" }}><b>{titleCase(k)}</b>{v.counted_as_loss === false && <div className="small muted">not a production loss</div>}</td>
              <td className="num">{fmt(v.kwh, 0)}</td>
              <td style={{ width: "30%" }}><div className="bar-h"><i style={{ width: `${(Math.abs(v.kwh) / max) * 100}%`, background: k === "equipment_failure" ? "#b3261e" : k === "curtailment" ? "#b86e00" : k.startsWith("communication") ? "#9aa4b5" : "#0aa5c2" }} /></div></td>
              <td><Badge tone={v.confidence === "high" ? "ok" : v.confidence === "n/a" ? "muted" : "warn"}>{v.confidence}</Badge></td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="small muted">{losses.rules} Negative temperature loss = cold-weather gain.</p>
    </>
  );
}

function CleaningTools({ siteId }: { siteId: string }) {
  const [benefit, setBenefit] = useState<any>(null);
  const [scen, setScen] = useState<any>(null);
  const [cleaned, setCleaned] = useState(addDays(isoDay(new Date()), -8));
  const [loss, setLoss] = useState(0.03);
  return (
    <div className="grid g2" style={{ marginTop: 16 }}>
      <Card title="Cleaning benefit (weather-adjusted, comparable conditions)">
        <div className="row"><label className="f">Cleaning date<input type="date" value={cleaned} onChange={(e) => setCleaned(e.target.value)} /></label>
          <button className="btn primary" onClick={() => api.post("/api/performance/cleaning-benefit", { site_id: siteId, cleaned_on: cleaned, window_days: 5 }).then(setBenefit)}>Estimate</button></div>
        {benefit && (
          <div style={{ marginTop: 10 }}>
            {benefit.status !== "estimate" ? <div className="notice warn">{benefit.reason}</div> : (
              <dl className="kv">
                <dt>Index before</dt><dd>{fmt(benefit.index_before * 100, 1)}%</dd>
                <dt>Index after</dt><dd>{fmt(benefit.index_after * 100, 1)}%</dd>
                <dt>Change</dt><dd><b>{fmt(benefit.change * 100, 1)} pts</b> (90% CI {fmt(benefit.change_ci90?.[0] * 100, 1)} to {fmt(benefit.change_ci90?.[1] * 100, 1)})</dd>
                {benefit.soiling_station && <><dt>Soiling station</dt><dd>{fmt(benefit.soiling_station.before_mean, 3)} → {fmt(benefit.soiling_station.after_mean, 3)}</dd></>}
                <dt>Comparable intervals</dt><dd>{benefit.comparable_intervals.before} before / {benefit.comparable_intervals.after} after</dd>
              </dl>
            )}
            <p className="small muted">{benefit.method}. {benefit.interpretation}</p>
          </div>
        )}
      </Card>
      <Card title="Cleaning scenario (estimate)">
        <div className="row">
          <label className="f">Soiling loss<input type="number" step="0.005" value={loss} onChange={(e) => setLoss(Number(e.target.value))} style={{ width: 90 }} /></label>
          <button className="btn" onClick={() => api.post("/api/performance/cleaning-scenario", { site_id: siteId, expected_energy_kwh_per_day: 9000, soiling_loss_fraction: loss, loss_uncertainty: 0.01, benefit_days: 45, cleaning_cost: 3850, price_per_mwh: 72.5, currency: "GBP", constraints: ["no cleaning below 2 °C (freezing)", "access route via north gate only"] }).then(setScen)}>Run scenario</button>
        </div>
        {scen && (
          <dl className="kv" style={{ marginTop: 10 }}>
            <dt>Recoverable energy</dt><dd>{fmt(scen.recoverable_energy_kwh, 0)} kWh ({fmt(scen.recoverable_energy_range_kwh[0], 0)}–{fmt(scen.recoverable_energy_range_kwh[1], 0)})</dd>
            <dt>Energy value</dt><dd>{scen.currency} {fmt(scen.energy_value, 0)} ({fmt(scen.energy_value_range[0], 0)}–{fmt(scen.energy_value_range[1], 0)})</dd>
            <dt>Cleaning cost</dt><dd>{scen.currency} {fmt(scen.cleaning_cost, 0)}</dd>
            <dt>Net</dt><dd className={scen.net_value < 0 ? "crit-text" : "ok-text"}>{scen.currency} {fmt(scen.net_value, 0)}</dd>
            <dt>Break-even soiling</dt><dd>{fmt(scen.break_even_soiling_fraction * 100, 2)}%</dd>
            <dt>Constraints</dt><dd className="small">{scen.operational_constraints.join("; ")}</dd>
          </dl>
        )}
        <p className="small muted">Assumes 9 MWh/day expected, 45 benefit days, £72.50/MWh PPA price (HLM). A scenario, not a measurement.</p>
      </Card>
    </div>
  );
}
