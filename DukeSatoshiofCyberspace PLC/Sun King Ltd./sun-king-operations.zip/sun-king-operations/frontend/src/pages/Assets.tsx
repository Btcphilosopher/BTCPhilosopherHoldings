import { useState } from "react";
import { useApi } from "../lib/hooks";
import { useSession } from "../lib/session";
import { Badge, Card, Loading, StatusBadge } from "../components/ui";
import { localTime, titleCase } from "../lib/format";
import { qs } from "../lib/api";

const TYPES = ["", "array_block", "inverter", "combiner_box", "string", "transformer", "meter", "weather_station", "sensor", "tracker", "grid_connection", "battery_system"];

export default function Assets() {
  const { siteId } = useSession();
  const [type, setType] = useState("");
  const [q, setQ] = useState("");
  const [sel, setSel] = useState<string | null>(null);
  const { data, error } = useApi<any[]>(`/api/assets?${qs({ site_id: siteId, asset_type: type, q })}`, [siteId, type, q]);
  return (
    <div className="grid g3">
      <Card className="span2" title="Asset register" actions={<>
        <input placeholder="Search id, name, serial…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={type} onChange={(e) => setType(e.target.value)}>{TYPES.map((t) => <option key={t} value={t}>{t ? titleCase(t) : "All types"}</option>)}</select>
      </>}>
        {!data ? <Loading error={error} /> : (
          <div className="scroll" style={{ maxHeight: 640 }}>
            <table className="t">
              <thead><tr><th>Asset id</th><th>Type</th><th>Manufacturer / model</th><th>Serial</th><th className="num">Rating</th><th>Parent</th><th>Status</th><th>Source</th></tr></thead>
              <tbody>
                {data.map((a) => (
                  <tr key={a.asset_id} className={sel === a.asset_id ? "sel" : ""} onClick={() => setSel(a.asset_id)} style={{ cursor: "pointer" }}>
                    <td><b>{a.asset_id}</b><div className="small muted">{a.name}</div></td>
                    <td><span className="type">{a.asset_type.replace("_", " ")}</span></td>
                    <td>{a.manufacturer ?? "—"}<div className="small muted">{a.model}</div></td>
                    <td className="mono small">{a.serial_reference ?? "—"}</td>
                    <td className="num">{a.rated_capacity ? `${a.rated_capacity.toLocaleString("en-GB")} ${a.rated_capacity_unit}` : "—"}</td>
                    <td className="small">{a.parent_asset ?? "—"}</td>
                    <td><StatusBadge status={a.maintenance_status === "in_service" ? "ok" : a.maintenance_status} /></td>
                    <td className="small muted">{a.source}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
      <Card title={sel ? `Asset ${sel}` : "Asset detail"}>{sel ? <AssetPanel assetId={sel} /> : <p className="muted">Select an asset to see its record, modelling parameters and history.</p>}</Card>
    </div>
  );
}

export function AssetPanel({ assetId }: { assetId: string }) {
  const { data } = useApi<any>(`/api/assets/${assetId}`, [assetId]);
  const hist = useApi<any>(`/api/assets/${assetId}/history`, [assetId]);
  if (!data) return <Loading />;
  const ep = data.electrical_parameters ?? {};
  return (
    <>
      <div className="row"><span className="type">{data.asset_type.replace("_", " ")}</span><b>{data.name}</b></div>
      <dl className="kv" style={{ marginTop: 8 }}>
        <dt>Manufacturer</dt><dd>{data.manufacturer ?? "—"}</dd>
        <dt>Model</dt><dd>{data.model ?? "—"}</dd>
        <dt>Serial</dt><dd className="mono">{data.serial_reference ?? "—"}</dd>
        <dt>Commissioned</dt><dd>{data.commissioning_date ?? "—"}</dd>
        <dt>Rated capacity</dt><dd>{data.rated_capacity ? `${data.rated_capacity} ${data.rated_capacity_unit}` : "—"}</dd>
        <dt>Parent (physical)</dt><dd>{data.parent_asset ?? "—"}</dd>
        <dt>Children</dt><dd className="small">{data.children?.join(", ") || "—"}</dd>
        <dt>Warranty</dt><dd>{data.warranty_reference ?? "—"} {data.warranty_expiry && <span className="muted">to {data.warranty_expiry}</span>}</dd>
        <dt>Maintenance status</dt><dd>{data.maintenance_status}</dd>
        <dt>Effective</dt><dd className="small">{data.effective_dates.from?.slice(0, 10)} → {data.effective_dates.to ?? "current"}</dd>
        <dt>Source</dt><dd>{data.source}</dd>
      </dl>
      {Object.keys(ep).length > 0 && (<><h3>Electrical parameters</h3><pre className="mono small" style={{ whiteSpace: "pre-wrap", background: "#f5f7fa", padding: 8, borderRadius: 6 }}>{JSON.stringify(ep, null, 1)}</pre></>)}
      {data.pv_system_config && (<><h3>PV model configuration</h3><dl className="kv small">
        <dt>Mounting</dt><dd>{data.pv_system_config.mounting}</dd><dt>Tilt / azimuth</dt><dd>{data.pv_system_config.surface_tilt_deg}° / {data.pv_system_config.surface_azimuth_deg}°</dd>
        <dt>DC capacity</dt><dd>{data.pv_system_config.dc_capacity_kwp} kWp</dd><dt>γ Pmp</dt><dd>{data.pv_system_config.gamma_pdc_per_c} /°C</dd>
        <dt>Inverter</dt><dd>{data.pv_system_config.inverter_asset_id}</dd><dt>Temp. model</dt><dd>{data.pv_system_config.temperature_model}</dd></dl></>)}
      {data.module_type && <p className="small">Module: {data.module_type.manufacturer} {data.module_type.model} · {data.module_type.pmax_w} W · {data.module_type.technology}</p>}
      <h3>History</h3>
      {hist.data?.events?.length ? (
        <ul className="small" style={{ paddingLeft: 16 }}>
          {hist.data.events.slice(0, 20).map((e: any, i: number) => <li key={i}><Badge tone={e.kind === "alert" ? "warn" : "info"}>{e.kind}</Badge> {localTime(e.at)} — {e.summary} {e.status && <span className="muted">({e.status})</span>}</li>)}
        </ul>
      ) : <p className="small muted">No recorded events.</p>}
    </>
  );
}
