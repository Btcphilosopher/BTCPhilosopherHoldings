import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useApi } from "../lib/hooks";
import { can, useSession } from "../lib/session";
import { Badge, Card, Loading, SeverityBadge, SourceLink, StatusBadge } from "../components/ui";
import { fmt, localTime, titleCase } from "../lib/format";
import { api, qs } from "../lib/api";

const FLOW = ["detected", "assigned", "investigating", "action_planned", "resolved", "verified"];

export default function Alerts() {
  const { siteId } = useSession();
  const [scope, setScope] = useState<"site" | "all">("site");
  const [active, setActive] = useState<string>("");
  const [sel, setSel] = useState<string | null>(null);
  const list = useApi<any[]>(`/api/alerts?${qs({ site_id: scope === "site" ? siteId : undefined, active })}`, [siteId, scope, active], 60000);
  const pri = useApi<any>("/api/alerts/priorities", []);
  return (
    <div className="grid g3">
      <Card className="span2" title="Alerts" actions={<>
        <select value={scope} onChange={(e) => setScope(e.target.value as any)}><option value="site">This site</option><option value="all">All permitted sites</option></select>
        <select value={active} onChange={(e) => setActive(e.target.value)}><option value="">Condition: any</option><option value="true">Condition active</option><option value="false">Condition cleared</option></select>
      </>}>
        {!list.data ? <Loading error={list.error} /> : (
          <div className="scroll" style={{ maxHeight: 640 }}>
            <table className="t">
              <thead><tr><th>Severity</th><th>Alert</th><th>Condition</th><th>Workflow</th><th>Attribution</th><th>Detected</th><th className="num">Priority</th></tr></thead>
              <tbody>
                {list.data.map((a) => (
                  <tr key={a.id} className={sel === a.id ? "sel" : ""} onClick={() => setSel(a.id)} style={{ cursor: "pointer" }}>
                    <td><SeverityBadge severity={a.severity} active={a.condition_active} /></td>
                    <td style={{ minWidth: 280 }}><b>{a.title}</b><div className="small muted">{titleCase(a.alert_type)} · rule {a.rule_id} v{a.rule_version}</div></td>
                    <td>{a.condition_active ? <Badge tone={a.severity === "critical" ? "crit" : "warn"}>ACTIVE</Badge> : <Badge tone="muted">cleared {localTime(a.condition_cleared_at)}</Badge>}{a.acknowledged && <div className="small muted">acknowledged</div>}</td>
                    <td><StatusBadge status={a.status} /></td>
                    <td className="small">{titleCase(a.attribution)} <span className="muted">({a.attribution_confidence})</span></td>
                    <td className="small">{localTime(a.first_detected_at)}</td>
                    <td className="num">{fmt(a.priority_score, 2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {pri.data && <p className="small muted">Prioritisation: {pri.data.method} — {pri.data.reason}.</p>}
      </Card>
      <Card title="Investigation">{sel ? <AlertDetail id={sel} onChange={list.reload} /> : <p className="muted">Select an alert. Acknowledging records that you have seen it; it never clears the underlying condition.</p>}</Card>
    </div>
  );
}

function AlertDetail({ id, onChange }: { id: string; onChange: () => void }) {
  const { me } = useSession();
  const nav = useNavigate();
  const { data, reload } = useApi<any>(`/api/alerts/${id}`, [id]);
  const [msg, setMsg] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [verif, setVerif] = useState<any>(null);
  if (!data) return <Loading />;
  const act = async (fn: () => Promise<any>) => {
    setMsg(null);
    try { await fn(); await reload(); onChange(); } catch (e) { setMsg((e as Error).message); }
  };
  const idx = FLOW.indexOf(data.status);
  const ev = data.evidence ?? {};
  const isEng = can(me, data.site_id, "engineer");
  return (
    <>
      <div className="row"><SeverityBadge severity={data.severity} active={data.condition_active} /><StatusBadge status={data.status} /></div>
      <h3 style={{ marginTop: 10 }}>{data.title}</h3>
      <div className="row small" style={{ gap: 4, margin: "8px 0" }}>
        {FLOW.map((f, i) => <span key={f} className={`badge ${i <= idx ? "gold" : "muted"}`}>{i + 1}. {titleCase(f)}</span>)}
      </div>
      <dl className="kv small">
        <dt>Condition</dt><dd>{data.condition_active ? <b className="crit-text">active</b> : <>cleared {localTime(data.condition_cleared_at)}</>} (started {localTime(data.condition_started_at)})</dd>
        <dt>Rule</dt><dd>{data.rule_id} v{data.rule_version} · persistence {data.evidence?.persistence_s}s</dd>
        <dt>Threshold source</dt><dd>{data.threshold_source}</dd>
        <dt>Affected assets</dt><dd>{data.affected_assets.join(", ")}</dd>
        <dt>Attribution</dt><dd><b>{titleCase(data.attribution)}</b> ({data.attribution_confidence} confidence)</dd>
        {data.energy_at_risk_kwh != null && <><dt>Energy at risk</dt><dd>{fmt(data.energy_at_risk_kwh, 0)} kWh (estimate)</dd></>}
        <dt>Assigned to</dt><dd>{data.assigned_to ?? "—"}</dd>
        <dt>Work orders</dt><dd>{data.work_orders.join(", ") || "—"}</dd>
      </dl>
      {data.attribution_notes && <div className="notice small" style={{ marginTop: 8 }}>{data.attribution_notes}</div>}
      <h3>Supporting evidence</h3>
      <pre className="mono small" style={{ whiteSpace: "pre-wrap", background: "#f5f7fa", padding: 8, borderRadius: 6, maxHeight: 220, overflow: "auto" }}>
        {JSON.stringify(Object.fromEntries(Object.entries(ev).filter(([k]) => !["observation_ids", "first_evidence"].includes(k))), null, 1)}
      </pre>
      <div className="small">{data.evidence_links.slice(0, 6).map((l: string) => <span key={l} style={{ marginRight: 8 }}><SourceLink url={l} label={l.split("/").pop()!.slice(0, 10)} /></span>)}</div>
      <h3>Actions</h3>
      <textarea placeholder="Note (recorded in the alert history)" value={note} onChange={(e) => setNote(e.target.value)} />
      <div className="row" style={{ marginTop: 8 }}>
        <button className="btn" onClick={() => act(() => api.post(`/api/alerts/${id}/acknowledge`, { note }))}>Acknowledge</button>
        {data.status === "detected" && <button className="btn" onClick={() => act(() => api.post(`/api/alerts/${id}/transition`, { to_status: "assigned", assignee: "u-tech", note }))}>Assign to field tech</button>}
        {["detected", "assigned"].includes(data.status) && <button className="btn" onClick={() => act(() => api.post(`/api/alerts/${id}/transition`, { to_status: "investigating", note }))}>Start investigation</button>}
        {data.status === "investigating" && <button className="btn" onClick={() => act(() => api.post(`/api/alerts/${id}/transition`, { to_status: "action_planned", note }))}>Action planned</button>}
        <button className="btn gold" onClick={() => act(async () => {
          const wo = await api.post("/api/maintenance/work-orders", { site_id: data.site_id, title: `Investigate: ${data.title}`.slice(0, 290), work_type: "corrective", priority: data.severity === "critical" ? "urgent" : "high", asset_ids: data.affected_assets, alert_id: id, description: `Raised from alert ${id}. Attribution: ${data.attribution} (${data.attribution_confidence}).` });
          nav(`/maintenance?wo=${wo.id}`);
        })}>Create work order</button>
        {isEng && ["investigating", "action_planned", "resolved", "detected", "assigned"].includes(data.status) && !data.condition_active && (
          <button className="btn primary" onClick={() => act(async () => {
            const r = await api.post(`/api/alerts/${id}/verify`, { work_order_id: data.work_orders[0], after: data.work_orders[0] ? undefined : data.condition_cleared_at });
            setVerif(r.verification);
          })}>Verify recovery</button>
        )}
      </div>
      {data.condition_active && isEng && <p className="small muted">Recovery cannot be verified while the condition is active.</p>}
      {msg && <div className="notice crit small" style={{ marginTop: 8 }}>{msg}</div>}
      {verif && (
        <div className={`notice ${verif.passed ? "" : "warn"}`} style={{ marginTop: 8 }}>
          <b>{verif.passed ? "Recovery verified" : "Not verified"}</b>: {verif.reason}. Index {fmt((verif.index ?? 0) * 100, 1)}% vs peers {fmt((verif.peer_median_index ?? 0) * 100, 1)}% over {verif.comparable_hours} h (need {verif.required_hours} h).
        </div>
      )}
      <h3>History</h3>
      <ul className="small" style={{ paddingLeft: 16 }}>
        {data.events.map((e: any) => <li key={e.id}>{localTime(e.at)} · <b>{e.event}</b>{e.to_status ? ` → ${e.to_status}` : ""} {e.actor_id ? `by ${e.actor_id}` : ""} {e.note && <span className="muted">— {e.note}</span>}</li>)}
      </ul>
    </>
  );
}
