import { useState } from "react";
import { useApi } from "../lib/hooks";
import { useSession } from "../lib/session";
import { Badge, Card, Loading, Tabs } from "../components/ui";
import { localTime } from "../lib/format";
import { api } from "../lib/api";

export default function Administration() {
  const { me, siteId } = useSession();
  const [tab, setTab] = useState("users");
  const isAdmin = me?.org_role === "admin";
  const users = useApi<any[]>(isAdmin ? "/api/admin/users" : null, []);
  const adapters = useApi<any>(isAdmin ? "/api/admin/adapters" : null, []);
  const audit = useApi<any[]>(isAdmin && tab === "audit" ? "/api/admin/audit?limit=200" : null, [tab]);
  const jobs = useApi<any[]>(isAdmin && tab === "jobs" ? "/api/admin/jobs" : null, [tab]);
  const rules = useApi<any[]>("/api/alerts/rules", []);
  const [msg, setMsg] = useState<string | null>(null);
  if (!isAdmin) return <Card title="Administration"><div className="notice warn">Organisation administrator role required. Your access: {JSON.stringify(me?.sites)}</div></Card>;
  return (
    <>
      <Tabs value={tab} onChange={setTab} tabs={[["users", "Users & site permissions"], ["adapters", "Integrations"], ["rules", "Alert rules"], ["audit", "Audit history"], ["jobs", "Background jobs"], ["resilience", "Backup & simulator"]]} />
      {msg && <div className="notice small" style={{ marginBottom: 10 }}>{msg}</div>}
      {tab === "users" && (users.data ? (
        <Card title="Users (organisational accounts)">
          <table className="t"><thead><tr><th>User</th><th>Organisation role</th><th>Site roles</th><th>Type</th></tr></thead>
            <tbody>{users.data.map((u) => <tr key={u.id}><td><b>{u.display_name}</b><div className="small muted">{u.email}</div></td><td>{u.org_role}</td><td className="small">{Object.entries(u.site_roles).map(([s, r]) => `${s}: ${r}`).join(" · ") || (u.org_role === "admin" ? "all sites" : "—")}</td><td>{u.service_account ? <Badge tone="info">service (ingest only)</Badge> : "person"}</td></tr>)}</tbody></table>
          <p className="small muted">Roles (ascending): viewer · field_technician · operator · engineer · manager · admin. Permissions are site-scoped; users cannot see sites they have no role on. OIDC sign-in is configurable (see docs/security.md).</p>
        </Card>) : <Loading />)}
      {tab === "adapters" && (adapters.data ? (
        <Card title="Equipment and data integrations">
          <div className="notice gold small">{adapters.data.policy} Live adapters enabled for this deployment: <b>{String(adapters.data.live_adapters_enabled)}</b>.</div>
          <table className="t" style={{ marginTop: 10 }}><thead><tr><th>Adapter</th><th>Kind</th><th>Implementation</th><th>Mode</th><th>Enabled</th><th>Credential</th><th>Allowed hosts</th><th>Verified docs</th></tr></thead>
            <tbody>{adapters.data.adapters.map((a: any) => <tr key={a.id}><td><b>{a.id}</b><div className="small muted">{a.settings?.note}</div></td><td>{a.kind}</td><td>{a.implementation}</td><td>{a.mode}</td><td>{a.enabled ? <Badge tone="ok">yes</Badge> : <Badge tone="muted">no</Badge>}</td><td className="small">{a.credential_ref ? <>{a.credential_ref} {a.credential_present ? <Badge tone="ok">present</Badge> : <Badge tone="muted">not set</Badge>}</> : "—"}</td><td className="small">{a.allowed_hosts.join(", ") || "—"}</td><td className="small">{a.verified_documentation_ref ?? <Badge tone="warn">not verified</Badge>}</td></tr>)}</tbody></table>
        </Card>) : <Loading />)}
      {tab === "rules" && rules.data && (
        <Card title="Alert rules (versioned)">
          <table className="t"><thead><tr><th>Rule</th><th>Version</th><th>Severity</th><th>Parameters</th><th className="num">Persistence</th><th className="num">Clear after</th><th>Threshold source</th></tr></thead>
            <tbody>{rules.data.map((r) => <tr key={`${r.id}-${r.version}`} style={{ opacity: r.active_version ? 1 : 0.5 }}><td><b>{r.name}</b><div className="small muted">{r.id}</div></td><td>v{r.version}{r.active_version && <Badge tone="ok">active</Badge>}</td><td>{r.severity}</td><td className="mono small">{JSON.stringify(r.params)}</td><td className="num">{r.persistence_s} s</td><td className="num">{r.clear_persistence_s} s</td><td className="small">{r.threshold_source}</td></tr>)}</tbody></table>
        </Card>
      )}
      {tab === "audit" && (audit.data ? (
        <Card title="Audit history (append-only)"><div className="scroll"><table className="t"><thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Entity</th><th>Detail</th></tr></thead>
          <tbody>{audit.data.map((a) => <tr key={a.id}><td className="small">{localTime(a.at)}</td><td>{a.actor_id ?? "—"}</td><td>{a.action}</td><td className="small">{a.entity_type}:{a.entity_id}</td><td className="mono small">{JSON.stringify(a.detail).slice(0, 140)}</td></tr>)}</tbody></table></div></Card>) : <Loading />)}
      {tab === "jobs" && (jobs.data ? (
        <Card title="Background jobs"><table className="t"><thead><tr><th>Job</th><th>Kind</th><th>Status</th><th className="num">Attempts</th><th>Last error</th></tr></thead>
          <tbody>{jobs.data.map((j) => <tr key={j.id}><td className="mono small">{j.id}</td><td>{j.kind}</td><td>{j.status}</td><td className="num">{j.attempts}/{j.max_attempts}</td><td className="small">{j.last_error}</td></tr>)}</tbody></table>
          {jobs.data.length === 0 && <div className="empty">No jobs yet (the worker enqueues day-ahead forecasts after 10:00 site time).</div>}</Card>) : <Loading />)}
      {tab === "resilience" && (
        <div className="grid g2">
          <Card title="Backup">
            <p className="small">Logical backup of every table (gzip JSON with per-table SHA-256). Restoration is tested in the automated test suite. For production also use <code>pg_dump</code> (see scripts/backup.sh).</p>
            <button className="btn primary" onClick={() => api.post("/api/admin/backup").then((r) => setMsg(`Backup written: ${r.path} · ${r.rows} rows · ${r.tables} tables`)).catch((e) => setMsg(e.message))}>Create backup now</button>
          </Card>
          <Card title="Simulator controls (demo)">
            <p className="small">Disconnect the simulated monitoring link for the selected site to see last-known values and their age instead of zero production.</p>
            <div className="row">
              <button className="btn danger" onClick={() => api.post("/api/admin/simulator/outage", { site_id: siteId, minutes: 30 }).then(() => setMsg(`${siteId} link disconnected for 30 min`))}>Disconnect {siteId} for 30 min</button>
              <button className="btn" onClick={() => api.post("/api/admin/simulator/outage", { site_id: siteId, minutes: 0 }).then(() => setMsg(`${siteId} link restored`))}>Restore</button>
            </div>
          </Card>
        </div>
      )}
    </>
  );
}
