import { useMemo, useState } from "react";
import { useApi } from "../lib/hooks";
import { useSession } from "../lib/session";
import { Badge, Card, Freshness, Loading, SourceLink, Tabs } from "../components/ui";
import { SingleLine, SiteMap, Tree } from "../components/diagrams";
import { age, fmt, localTime } from "../lib/format";
import { AssetPanel } from "./Assets";

export default function Sites() {
  const { siteId } = useSession();
  const [tab, setTab] = useState("layout");
  const [sel, setSel] = useState<string | undefined>();
  const site = useApi<any>(siteId ? `/api/sites/${siteId}` : null, [siteId]);
  const ov = useApi<any>(siteId ? `/api/sites/${siteId}/overview` : null, [siteId], 30000);
  const assets = useApi<any[]>(siteId ? `/api/assets?site_id=${siteId}` : null, [siteId]);
  const tree = useApi<any>(siteId ? `/api/sites/${siteId}/hierarchy` : null, [siteId]);
  const conn = useApi<any>(siteId ? `/api/sites/${siteId}/connectivity` : null, [siteId]);
  const points = useApi<any>(siteId ? `/api/sites/${siteId}/monitoring-points` : null, [siteId]);
  const alerts = useApi<any[]>(siteId ? `/api/alerts?site_id=${siteId}&active=true` : null, [siteId]);
  const liveMap = useMemo(() => {
    const m: Record<string, any> = {};
    const o = ov.data;
    if (!o) return m;
    for (const i of o.inverters) m[i.asset_id] = { text: i.ac_power ? `${fmt(i.ac_power.value, 0)} kW${i.ac_power.is_current ? "" : ` · ${age(i.ac_power.age_s)} old`}` : "no data", bad: i.state === "fault", current: i.ac_power?.is_current };
    const ex = o.current_generation.export_meter;
    const meter = assets.data?.find((a) => a.asset_type === "meter");
    if (ex && meter) m[meter.asset_id] = { text: `${fmt(ex.value, 0)} kW${ex.is_current ? "" : ` (${age(ex.age_s)} old)`}`, current: ex.is_current };
    if (o.battery?.power) m[o.battery.asset_id] = { text: `${fmt(o.battery.power.value, 0)} kW · SoC ${fmt((o.battery.soc?.value ?? 0) * 100, 0)}%`, current: o.battery.power.is_current };
    return m;
  }, [ov.data, assets.data]);
  if (!site.data || !assets.data) return <Loading error={site.error} />;
  const s = site.data;
  const alertAssets = (alerts.data ?? []).flatMap((a) => a.affected_assets);
  return (
    <>
      <div className="grid g4">
        <Card title={s.name}>
          <dl className="kv">
            <dt>Code</dt><dd>{s.code}</dd>
            <dt>Location</dt><dd>{s.latitude.toFixed(4)}°, {s.longitude.toFixed(4)}° · {s.elevation_m} m</dd>
            <dt>Time zone</dt><dd>{s.timezone}</dd>
            <dt>Commissioned</dt><dd>{s.commissioning_date}</dd>
            <dt>Grid connection</dt><dd>{s.grid_connection_ref}</dd>
          </dl>
        </Card>
        <Card title="Capacity (three distinct ratings)">
          <dl className="kv">
            <dt>Module DC (STC)</dt><dd><b>{fmt(s.dc_capacity_kwp, 0)} kWp</b></dd>
            <dt>Inverter AC</dt><dd><b>{fmt(s.ac_capacity_kw, 0)} kW</b></dd>
            <dt>Grid export limit</dt><dd><b>{fmt(s.export_limit_kw, 0)} kW</b></dd>
            <dt>DC/AC ratio</dt><dd>{(s.dc_capacity_kwp / s.ac_capacity_kw).toFixed(2)}</dd>
          </dl>
        </Card>
        <Card title="Telemetry">
          {ov.data ? (
            <>
              <Freshness ageS={ov.data.telemetry_freshness.age_s} current={ov.data.connection_state !== "disconnected"} label="DISCONNECTED" />
              <p className="small">{ov.data.telemetry_freshness.streams} streams · {ov.data.telemetry_freshness.stale_streams} stale</p>
              {ov.data.telemetry_freshness.stale_stream_ids?.length > 0 && <p className="small warn-text">{ov.data.telemetry_freshness.stale_stream_ids.slice(0, 6).join(", ")}</p>}
              {ov.data.telemetry_freshness.sources.map((x: any) => <div key={x.source} className="small">{x.source}: <Badge tone={x.state === "connected" ? "ok" : "warn"}>{x.state}</Badge> last contact {localTime(x.last_contact)}</div>)}
            </>
          ) : <Loading />}
        </Card>
        <Card title="Today">
          {ov.data ? (
            <dl className="kv">
              <dt>Measured export</dt><dd>{fmt(ov.data.today_measured_export?.energy_kwh, 0)} kWh <SourceLink url={ov.data.today_measured_export?.calculation} label="calc" /></dd>
              <dt>Coverage</dt><dd>{fmt((ov.data.today_measured_export?.coverage ?? 0) * 100, 1)} %</dd>
              <dt>Active alerts</dt><dd>{ov.data.alerts.condition_active} ({ov.data.alerts.critical} critical)</dd>
              <dt>Open WOs</dt><dd>{ov.data.maintenance.open_work_orders}</dd>
            </dl>
          ) : <Loading />}
        </Card>
      </div>
      <div className="grid g3" style={{ marginTop: 16 }}>
        <Card className="span2">
          <Tabs value={tab} onChange={setTab} tabs={[["layout", "Site layout map"], ["sld", "Electrical single-line"], ["tree", "Physical hierarchy"], ["points", "Monitoring points"]]} />
          {tab === "layout" && <SiteMap site={s} assets={assets.data} alerts={alertAssets} height={420} onSelect={setSel} />}
          {tab === "sld" && conn.data && <SingleLine edges={conn.data.edges} assets={assets.data} live={liveMap} onSelect={setSel} />}
          {tab === "tree" && tree.data && <div className="scroll" style={{ maxHeight: 460 }}><Tree nodes={tree.data.tree} selected={sel} onSelect={setSel} /></div>}
          {tab === "points" && points.data && (
            <div className="scroll">
              <p className="small muted">Monitoring-point mappings are kept separate from the physical hierarchy and the electrical connectivity.</p>
              <table className="t">
                <thead><tr><th>Asset</th><th>Measurement</th><th>Unit</th><th>Source</th><th>External tag</th><th className="num">Interval</th><th>Meter role</th></tr></thead>
                <tbody>{points.data.points.map((p: any) => <tr key={p.id} className={sel === p.asset_id ? "sel" : ""} onClick={() => setSel(p.asset_id)}><td>{p.asset_id}</td><td>{p.measurement_type}</td><td>{p.unit}</td><td>{p.source}</td><td className="mono">{p.external_tag}</td><td className="num">{p.nominal_interval_s} s</td><td>{p.meter_role ?? ""}</td></tr>)}</tbody>
              </table>
            </div>
          )}
        </Card>
        <Card title={sel ? `Asset ${sel}` : "Select an asset"}>
          {sel ? <AssetPanel assetId={sel} /> : <p className="muted small">Click a block, inverter or node on the map, diagram or tree.</p>}
        </Card>
      </div>
    </>
  );
}
