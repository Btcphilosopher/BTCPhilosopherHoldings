import { useState } from "react";
import { useApi } from "../lib/hooks";
import { can, useSession } from "../lib/session";
import { Badge, Card, Loading } from "../components/ui";
import { TimeChart } from "../components/charts";
import { fmt, localTime, pct } from "../lib/format";
import { api } from "../lib/api";

export default function Storage() {
  const { siteId, me } = useSession();
  const { data } = useApi<any>(`/api/storage/sites/${siteId}`, [siteId], 60000);
  const [res, setRes] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);
  const [soc0, setSoc0] = useState(0.3);
  const [pvOnly, setPvOnly] = useState(true);
  if (!data) return <Loading />;
  if (!data.battery) return <Card title="Storage"><div className="empty">{data.note} Select Calder Edge (CLE) to see the optional battery module.</div></Card>;
  const merge = (keys: string[]) => {
    const m: Record<string, any> = {};
    keys.forEach((k) => (data.series[k] ?? []).forEach((p: any) => { m[p.t] = { ...(m[p.t] ?? { t: p.t }), [k]: k === "battery_soc" ? (p.v === null ? null : p.v * 100) : p.v }; }));
    return Object.values(m).sort((a: any, b: any) => a.t.localeCompare(b.t));
  };
  const lat = Object.fromEntries(data.latest.map((v: any) => [v.measurement_type, v]));
  const run = async () => {
    setErr(null);
    try { setRes(await api.post("/api/storage/scenarios", { site_id: siteId, soc_initial: soc0, pv_only_charging: pvOnly })); } catch (e) { setErr((e as Error).message); }
  };
  const sched = res ? res.times.map((t: string, i: number) => ({ t, pv: res.pv_input.pv_kw[i], dp: res.schedules.optimised_dp.battery_kw[i], rule: res.schedules.rule_based.battery_kw[i], price: res.prices[i] })) : [];
  return (
    <>
      <div className="notice gold">Battery integration is <b>read-only</b>. This platform observes state and simulates schedules; it never sends commands to the battery or inverters.</div>
      <div className="grid g4" style={{ marginTop: 12 }}>
        {[["State of charge", pct(lat.battery_soc?.value, 0), ""], ["Power (+discharge)", fmt(lat.battery_power?.value, 0), "kW"], ["Available energy", fmt(lat.battery_available_energy?.value, 0), "kWh"], ["Temperature", fmt(lat.battery_temperature?.value, 1), "°C"]].map(([l, v, u]) => (
          <div key={l} className="card stat"><span className="label">{l}</span><span className="value">{v}<span className="unit">{u}</span></span>
            <span className="meta">{lat.battery_soc && (lat.battery_soc.is_current !== false ? `observed ${localTime(lat.battery_soc.observation_time)}` : <Badge tone="warn">not current</Badge>)}</span></div>
        ))}
      </div>
      <div className="grid g2" style={{ marginTop: 16 }}>
        <Card title={`${data.battery.name} — observed (15-min means)`}>
          <TimeChart data={merge(["battery_power", "battery_soc"])} unit="kW" rightUnit="SoC %" multiDay series={[{ key: "battery_power", name: "Power kW", type: "area", color: "#d0662b" }, { key: "battery_soc", name: "SoC %", yAxis: "right", color: "#13214a" }]} />
          <p className="small muted">Limits: {fmt(data.battery.power_kw, 0)} kW / {fmt(data.battery.energy_kwh, 0)} kWh · SoC {pct(data.battery.soc_min, 0)}–{pct(data.battery.soc_max, 0)} · RTE {pct(data.battery.round_trip_efficiency, 0)} · communication coverage {pct(data.communication_quality.interval_coverage, 1)}</p>
        </Card>
        <Card title="Storage scenario workspace (simulation)" actions={can(me, siteId, "engineer") && <button className="btn primary sm" onClick={run}>Compare schedules</button>}>
          <div className="row">
            <label className="f">Initial SoC<input type="number" step="0.05" min="0.05" max="0.95" value={soc0} onChange={(e) => setSoc0(Number(e.target.value))} style={{ width: 90 }} /></label>
            <label className="small"><input type="checkbox" checked={pvOnly} onChange={(e) => setPvOnly(e.target.checked)} /> charge from PV only</label>
          </div>
          {err && <div className="notice crit small">{err}</div>}
          {res && (
            <>
              <table className="t" style={{ marginTop: 10 }}>
                <thead><tr><th>Schedule</th><th className="num">Modelled value</th><th className="num">Export kWh</th><th className="num">vs no storage</th></tr></thead>
                <tbody>
                  <tr><td>No storage</td><td className="num">{res.currency} {fmt(res.schedules.no_storage.modelled_value, 2)}</td><td className="num">{fmt(res.schedules.no_storage.export_kwh, 0)}</td><td className="num">—</td></tr>
                  <tr><td>Rule-based (cheap → dear thirds)</td><td className="num">{res.currency} {fmt(res.schedules.rule_based.modelled_value, 2)}</td><td className="num">{fmt(res.schedules.rule_based.export_kwh, 0)}</td><td className="num">{fmt(res.uplift_vs_no_storage.rule_based, 2)}</td></tr>
                  <tr><td>Optimised (dynamic programming)</td><td className="num">{res.currency} {fmt(res.schedules.optimised_dp.modelled_value, 2)}</td><td className="num">{fmt(res.schedules.optimised_dp.export_kwh, 0)}</td><td className="num">{fmt(res.uplift_vs_no_storage.optimised_dp, 2)}</td></tr>
                </tbody>
              </table>
              <p className="small">Constraint check: {res.schedules.optimised_dp.constraint_violations.length === 0 ? <Badge tone="ok">power, energy, efficiency and SoC limits respected</Badge> : <Badge tone="crit">{res.schedules.optimised_dp.constraint_violations.join(", ")}</Badge>}</p>
              <p className="small muted">{res.price_source} · {res.valuation_note}</p>
              <div className="notice warn small">{res.disclaimer}</div>
            </>
          )}
        </Card>
      </div>
      {res && (
        <Card title={`Schedules for ${res.pv_input.day} (kW, + = discharge)`}>
          <TimeChart data={sched} unit="kW" rightUnit="£/MWh" series={[{ key: "pv", name: "Measured PV (input)", type: "area", color: "#f2b705" }, { key: "dp", name: "Optimised battery", color: "#13214a", width: 2 }, { key: "rule", name: "Rule-based battery", color: "#0aa5c2", dashed: true }, { key: "price", name: "Synthetic price", yAxis: "right", color: "#9aa4b5" }]} />
        </Card>
      )}
    </>
  );
}
