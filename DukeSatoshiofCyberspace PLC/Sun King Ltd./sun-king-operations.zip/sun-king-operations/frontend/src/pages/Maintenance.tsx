import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useApi, useOnline } from "../lib/hooks";
import { can, useSession } from "../lib/session";
import { Badge, Card, Loading, StatusBadge, Tabs } from "../components/ui";
import { fmt, localTime, titleCase } from "../lib/format";
import { api, ApiError } from "../lib/api";

const NEXT: Record<string, [string, string][]> = {
  draft: [["assigned", "Assign"], ["scheduled", "Schedule"], ["cancelled", "Cancel"]],
  scheduled: [["assigned", "Assign"]],
  assigned: [["in_progress", "Start work"]],
  in_progress: [["completed", "Complete"]],
  completed: [["reviewed", "Review"], ["in_progress", "Reopen"]],
  reviewed: [["signed_off", "Sign off"]],
};

export default function Maintenance() {
  const { siteId } = useSession();
  const [params, setParams] = useSearchParams();
  const [tab, setTab] = useState("wo");
  const sel = params.get("wo");
  const list = useApi<any[]>(`/api/maintenance/work-orders?site_id=${siteId}`, [siteId]);
  const sum = useApi<any>(`/api/maintenance/summary?site_id=${siteId}`, [siteId]);
  return (
    <>
      <Tabs value={tab} onChange={setTab} tabs={[["wo", "Work orders"], ["field", "Field inspection (tablet)"], ["sched", "Schedules"], ["spares", "Spare parts"], ["contractors", "Contractors"], ["cleaning", "Cleaning & vegetation"]]} />
      {tab === "wo" && (
        <div className="grid g3">
          <Card title="Work orders" className="span2">
            {!list.data ? <Loading /> : list.data.length === 0 ? <div className="empty">No work orders yet. Create one from an alert.</div> : (
              <table className="t">
                <thead><tr><th>Work order</th><th>Type</th><th>Priority</th><th>Status</th><th>Assets</th><th>Created</th></tr></thead>
                <tbody>{list.data.map((w) => (
                  <tr key={w.id} className={sel === w.id ? "sel" : ""} onClick={() => setParams({ wo: w.id })} style={{ cursor: "pointer" }}>
                    <td><b>{w.title}</b><div className="small muted mono">{w.id}</div></td><td>{w.work_type}</td>
                    <td><Badge tone={w.priority === "urgent" ? "crit" : w.priority === "high" ? "warn" : "muted"}>{w.priority}</Badge></td>
                    <td><StatusBadge status={w.status} /></td><td className="small">{w.asset_ids.join(", ")}</td><td className="small">{localTime(w.created_at)}</td>
                  </tr>))}</tbody>
              </table>
            )}
          </Card>
          <Card title="Work order">{sel ? <WorkOrder id={sel} onChange={list.reload} /> : <p className="muted">Select a work order.</p>}</Card>
        </div>
      )}
      {tab === "field" && <FieldInspection siteId={siteId} workOrderId={sel} />}
      {tab === "sched" && sum.data && (
        <Card title="Preventive and recurring schedules">
          <table className="t"><thead><tr><th>Task</th><th>Type</th><th className="num">Interval</th><th>Last done</th><th>Next due</th><th>Source</th></tr></thead>
            <tbody>{sum.data.schedules.map((s: any) => {
              const overdue = s.next_due < new Date().toISOString().slice(0, 10);
              return <tr key={s.id}><td><b>{s.title}</b>{s.asset_id && <div className="small muted">{s.asset_id}</div>}</td><td>{s.task_type}</td><td className="num">{s.interval_days} d</td><td>{s.last_completed}</td><td>{overdue ? <Badge tone="warn">OVERDUE {s.next_due}</Badge> : s.next_due}</td><td className="small muted">{s.source}</td></tr>;
            })}</tbody></table>
        </Card>
      )}
      {tab === "spares" && sum.data && (
        <Card title="Spare parts">
          <table className="t"><thead><tr><th>Part</th><th>Description</th><th>Compatible</th><th className="num">On hand</th><th className="num">Minimum</th><th>Location</th><th className="num">Unit cost</th></tr></thead>
            <tbody>{sum.data.spare_parts.map((p: any) => <tr key={p.id}><td className="mono">{p.part_number}</td><td>{p.description}</td><td className="small">{p.compatible_models.join(", ")}</td><td className="num">{p.quantity_on_hand} {p.below_minimum && <Badge tone="warn">below min</Badge>}</td><td className="num">{p.minimum_quantity}</td><td>{p.storage_location}</td><td className="num">{p.currency} {fmt(p.unit_cost, 2)}</td></tr>)}</tbody></table>
        </Card>
      )}
      {tab === "contractors" && sum.data && (
        <Card title="Contractors">
          <table className="t"><thead><tr><th>Name</th><th>Trade</th><th>Contact</th><th>Accreditation</th></tr></thead>
            <tbody>{sum.data.contractors.map((c: any) => <tr key={c.id}><td><b>{c.name}</b></td><td>{c.trade}</td><td className="small">{c.contact_email}</td><td className="small">{c.accreditation_ref ?? "—"} {c.accreditation_expiry && <span className="muted">to {c.accreditation_expiry}</span>}</td></tr>)}</tbody></table>
        </Card>
      )}
      {tab === "cleaning" && sum.data && (
        <div className="grid g2">
          <Card title="Cleaning records">
            <table className="t"><thead><tr><th>Date</th><th>Blocks</th><th>Method</th><th className="num">Cost</th></tr></thead>
              <tbody>{sum.data.cleaning.map((c: any) => <tr key={c.id}><td>{c.performed_on}</td><td className="small">{c.asset_ids.join(", ")}</td><td>{c.method}</td><td className="num">{c.currency} {fmt(c.cost, 0)}</td></tr>)}</tbody></table>
            <p className="small muted">Cleaning benefit is estimated on the Performance page with a weather-adjusted method; raw before/after output is not treated as proof.</p>
          </Card>
          <Card title="Vegetation management">
            <table className="t"><thead><tr><th>Date</th><th>Area</th><th>Method</th><th>Ecological constraints</th></tr></thead>
              <tbody>{sum.data.vegetation.map((v: any) => <tr key={v.id}><td>{v.performed_on}</td><td>{v.area}</td><td>{v.method}</td><td className="small">{v.ecological_constraints}</td></tr>)}</tbody></table>
          </Card>
        </div>
      )}
    </>
  );
}

function WorkOrder({ id, onChange }: { id: string; onChange: () => void }) {
  const { me } = useSession();
  const { data, reload } = useApi<any>(`/api/maintenance/work-orders/${id}`, [id]);
  const [msg, setMsg] = useState<string | null>(null);
  const [notes, setNotes] = useState("");
  const [repair, setRepair] = useState("");
  const [at, setAt] = useState("");
  if (!data) return <Loading />;
  const go = async (to: string) => {
    setMsg(null);
    try {
      await api.post(`/api/maintenance/work-orders/${id}/transition`, {
        to_status: to, note: notes || undefined, assigned_to: to === "assigned" ? "u-tech" : undefined,
        contractor_id: to === "assigned" ? "con-pennine-elec" : undefined,
        completion_notes: to === "completed" ? notes : undefined, repair_summary: to === "completed" ? repair : undefined,
        at: at ? new Date(at).toISOString() : undefined,
      });
      await reload(); onChange();
    } catch (e) { setMsg((e as Error).message); }
  };
  const upload = async (f: File) => {
    const fd = new FormData();
    fd.set("site_id", data.site_id); fd.set("entity_type", "work_order"); fd.set("entity_id", id); fd.set("kind", "photo");
    fd.set("caption", f.name); fd.set("captured_at", new Date().toISOString()); fd.set("file", f);
    try { await api.form("/api/maintenance/evidence", fd); await reload(); } catch (e) { setMsg((e as Error).message); }
  };
  return (
    <>
      <div className="row"><StatusBadge status={data.status} /><Badge tone="muted">{data.work_type}</Badge></div>
      <h3 style={{ marginTop: 8 }}>{data.title}</h3>
      <p className="small">{data.description}</p>
      <div className="notice warn small">{data.safety_notice}</div>
      <dl className="kv small" style={{ marginTop: 8 }}>
        <dt>Alert</dt><dd>{data.alert_id ?? "—"}</dd><dt>Assets</dt><dd>{data.asset_ids.join(", ")}</dd>
        <dt>Assigned</dt><dd>{data.assigned_to ?? "—"} {data.contractor_id && `· ${data.contractor_id}`}</dd>
        <dt>Started</dt><dd>{localTime(data.started_at)}</dd><dt>Completed</dt><dd>{localTime(data.completed_at)}</dd>
        <dt>Reviewed</dt><dd>{data.reviewed_by ? `${data.reviewed_by} ${localTime(data.reviewed_at)}` : "—"}</dd>
        <dt>Signed off</dt><dd>{data.signed_off_by ? `${data.signed_off_by} ${localTime(data.signed_off_at)}` : "—"}</dd>
        <dt>Repair</dt><dd>{data.repair_summary ?? "—"}</dd>
      </dl>
      {data.verification && <div className={`notice ${data.verification.passed ? "" : "warn"} small`}>Post-maintenance check: <b>{data.verification.passed ? "passed" : "not passed"}</b> — {data.verification.reason}</div>}
      <h3>Evidence ({data.evidence.length})</h3>
      <div className="row">{data.evidence.map((e: any) => (
        <a key={e.id} href="#" onClick={async (ev) => { ev.preventDefault(); const r = await fetch(`/api/maintenance/evidence/${e.id}`, { headers: { Authorization: `Bearer ${localStorage.getItem("sunking.token")}` } }); window.open(URL.createObjectURL(await r.blob())); }} className="small">📎 {e.filename} <span className="muted">sha256 {e.sha256.slice(0, 8)}…</span></a>
      ))}</div>
      {can(me, data.site_id, "field_technician") && <input type="file" accept="image/png,image/jpeg,application/pdf" onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} style={{ marginTop: 6 }} />}
      <h3>Inspections ({data.inspections.length})</h3>
      {data.inspections.map((i: any) => <div key={i.id} className="small">{i.template_id} · {i.status} · captured {localTime(i.captured_at)} · synced {localTime(i.synced_at)} · v{i.version}</div>)}
      <h3>Next step</h3>
      <textarea placeholder={data.status === "in_progress" ? "Completion notes (required)" : "Note"} value={notes} onChange={(e) => setNotes(e.target.value)} />
      {data.status === "in_progress" && <><textarea placeholder="Repair summary" value={repair} onChange={(e) => setRepair(e.target.value)} />
        <label className="f">Work completed at (site time; blank = now)<input type="datetime-local" value={at} onChange={(e) => setAt(e.target.value)} /></label></>}
      <div className="row" style={{ marginTop: 8 }}>{(NEXT[data.status] ?? []).map(([to, l]) => <button key={to} className={`btn ${to === "completed" || to === "signed_off" ? "primary" : ""}`} onClick={() => go(to)}>{l}</button>)}</div>
      {msg && <div className="notice crit small" style={{ marginTop: 8 }}>{msg}</div>}
      <h3>History</h3>
      <ul className="small" style={{ paddingLeft: 16 }}>{data.events.map((e: any) => <li key={e.id}>{localTime(e.at)} {e.from_status ?? ""} → <b>{e.to_status}</b> {e.actor_id} {e.note && <span className="muted">— {e.note}</span>}</li>)}</ul>
    </>
  );
}

// ---------------------------------------------------------------- offline-capable inspection form
type Draft = { client_draft_id: string; template_id: string; site_id: string; work_order_id?: string | null; asset_id?: string | null;
  answers: Record<string, any>; status: "draft" | "submitted"; captured_at: string; device_id: string; base_version: number | null; sync: "queued" | "synced" | "conflict"; server?: any; error?: string };
const QKEY = "sunking.inspection-queue";
const loadQ = (): Draft[] => { try { return JSON.parse(localStorage.getItem(QKEY) ?? "[]"); } catch { return []; } };
const saveQ = (q: Draft[]) => { try { localStorage.setItem(QKEY, JSON.stringify(q)); } catch { /* storage unavailable */ } };
const deviceId = () => { try { let d = localStorage.getItem("sunking.device"); if (!d) { d = `tablet-${Math.random().toString(36).slice(2, 8)}`; localStorage.setItem("sunking.device", d); } return d; } catch { return "tablet-unknown"; } };

function FieldInspection({ siteId, workOrderId }: { siteId: string; workOrderId: string | null }) {
  const online = useOnline();
  const [simOffline, setSimOffline] = useState(false);
  const isOnline = online && !simOffline;
  const tpls = useApi<any[]>("/api/maintenance/templates", []);
  const [tplId, setTplId] = useState("tpl-inverter-corrective");
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [queue, setQueue] = useState<Draft[]>(loadQ);
  const [assetId, setAssetId] = useState("HLM-INV-03");
  useEffect(() => saveQ(queue), [queue]);
  const sync = async () => {
    const next: Draft[] = [];
    for (const d of queue) {
      if (d.sync === "synced") { next.push(d); continue; }
      try {
        const { sync: _s, server: _sv, error: _e, ...payload } = d;
        const r = await api.post("/api/maintenance/inspections/sync", payload);
        next.push({ ...d, sync: "synced", base_version: r.record.version, error: undefined });
      } catch (e) {
        if (e instanceof ApiError && e.status === 409) next.push({ ...d, sync: "conflict", server: (e.detail as any)?.server ?? e.detail });
        else next.push({ ...d, error: (e as Error).message });
      }
    }
    setQueue(next);
  };
  useEffect(() => { if (isOnline && queue.some((d) => d.sync === "queued")) sync(); }, [isOnline]); // eslint-disable-line react-hooks/exhaustive-deps
  const tpl = tpls.data?.find((t) => t.id === tplId);
  const save = (status: "draft" | "submitted") => {
    const d: Draft = { client_draft_id: `drf-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`, template_id: tplId, site_id: siteId,
      work_order_id: workOrderId, asset_id: assetId || null, answers, status, captured_at: new Date().toISOString(), device_id: deviceId(), base_version: null, sync: "queued" };
    setQueue([d, ...queue]);
    setAnswers({});
    if (isOnline) setTimeout(sync, 50);
  };
  const resolve = async (d: Draft, resolution: "keep_client" | "keep_server") => {
    const { sync: _s, server: _sv, error: _e, ...payload } = d;
    await api.post("/api/maintenance/inspections/sync", { ...payload, resolution });
    setQueue(queue.map((x) => (x.client_draft_id === d.client_draft_id ? { ...x, sync: "synced" } : x)));
  };
  return (
    <>
      <div className={`offline-bar ${isOnline ? "on" : "off"}`}>
        {isOnline ? "● Online — drafts synchronise automatically" : "○ OFFLINE — inspections are saved on this device with their capture time and queued for synchronisation"}
        <label style={{ float: "right", fontWeight: 500 }}><input type="checkbox" checked={simOffline} onChange={(e) => setSimOffline(e.target.checked)} /> simulate offline</label>
      </div>
      <div className="grid g2" style={{ marginTop: 12 }}>
        <Card title="Inspection form">
          <div className="row">
            <select value={tplId} onChange={(e) => { setTplId(e.target.value); setAnswers({}); }}>{tpls.data?.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select>
            <input value={assetId} onChange={(e) => setAssetId(e.target.value)} placeholder="Asset id" style={{ width: 140 }} />
            {workOrderId && <Badge tone="info">linked to {workOrderId}</Badge>}
          </div>
          <div className="field-form">
            {tpl?.fields.map((f: any) => (
              <div className="q" key={f.key}>
                <label>{f.label}{f.required && " *"}</label>
                {f.type === "choice" ? (
                  <div className="choices">{f.options.map((o: string) => <button key={o} className={answers[f.key] === o ? "on" : ""} onClick={() => setAnswers({ ...answers, [f.key]: o })}>{o}</button>)}</div>
                ) : f.type === "number" ? (
                  <input type="number" inputMode="decimal" value={answers[f.key] ?? ""} onChange={(e) => setAnswers({ ...answers, [f.key]: e.target.value === "" ? undefined : Number(e.target.value) })} />
                ) : (
                  <textarea value={answers[f.key] ?? ""} onChange={(e) => setAnswers({ ...answers, [f.key]: e.target.value })} />
                )}
              </div>
            ))}
          </div>
          <div className="row" style={{ marginTop: 12 }}>
            <button className="btn" onClick={() => save("draft")}>Save draft</button>
            <button className="btn primary" onClick={() => save("submitted")}>Submit inspection</button>
          </div>
          <p className="small muted">This form records observations. It does not authorise or confirm isolation; follow the permit-to-work system.</p>
        </Card>
        <Card title={`Synchronisation queue (${queue.filter((q) => q.sync !== "synced").length} pending)`} actions={<button className="btn sm" disabled={!isOnline} onClick={sync}>Sync now</button>}>
          {queue.length === 0 ? <div className="empty">No drafts on this device.</div> : (
            <table className="t"><thead><tr><th>Draft</th><th>Captured (device)</th><th>Status</th><th>Sync</th></tr></thead>
              <tbody>{queue.map((d) => (
                <tr key={d.client_draft_id}>
                  <td className="mono small">{d.client_draft_id}<div className="muted">{titleCase(d.template_id.replace("tpl-", ""))}</div></td>
                  <td className="small">{localTime(d.captured_at)}</td><td>{d.status}</td>
                  <td>{d.sync === "synced" ? <Badge tone="ok">synced</Badge> : d.sync === "conflict" ? (
                    <><Badge tone="crit">conflict</Badge><div className="row" style={{ marginTop: 4 }}><button className="btn sm" onClick={() => resolve(d, "keep_client")}>Keep mine</button><button className="btn sm" onClick={() => resolve(d, "keep_server")}>Keep server</button></div></>
                  ) : <Badge tone="warn">queued</Badge>}{d.error && <div className="small crit-text">{d.error}</div>}</td>
                </tr>))}</tbody></table>
          )}
          <p className="small muted">Conflicts (server copy changed since the draft was based on it) are never merged silently: choose which version to keep; the other is preserved in the record's conflict history.</p>
        </Card>
      </div>
    </>
  );
}
