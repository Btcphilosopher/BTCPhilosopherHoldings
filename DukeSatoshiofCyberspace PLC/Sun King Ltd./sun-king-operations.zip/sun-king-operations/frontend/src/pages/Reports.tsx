import { useState } from "react";
import { useApi } from "../lib/hooks";
import { Card, Loading } from "../components/ui";
import { addDays, isoDay, localTime } from "../lib/format";
import { api, getToken } from "../lib/api";

async function openAuthed(url: string, download?: string) {
  const r = await fetch(url, { headers: { Authorization: `Bearer ${getToken()}` } });
  const blob = await r.blob();
  const u = URL.createObjectURL(blob);
  if (download) { const a = document.createElement("a"); a.href = u; a.download = download; a.click(); } else window.open(u, "_blank");
}

export default function Reports() {
  const today = isoDay(new Date());
  const [start, setStart] = useState(addDays(today, -7));
  const [end, setEnd] = useState(addDays(today, -1));
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const list = useApi<any[]>("/api/reports", []);
  const gen = async () => {
    setBusy(true); setErr(null);
    try { await api.post("/api/reports/operational", { start_day: start, end_day: end }); await list.reload(); } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  };
  return (
    <div className="grid g3">
      <Card title="Generate operational report">
        <label className="f">First day (site-local)<input type="date" value={start} onChange={(e) => setStart(e.target.value)} /></label>
        <div style={{ height: 8 }} />
        <label className="f">Last day<input type="date" value={end} onChange={(e) => setEnd(e.target.value)} /></label>
        <div style={{ height: 12 }} />
        <button className="btn gold" disabled={busy} onClick={gen}>{busy ? "Generating…" : "Generate source-linked report"}</button>
        {err && <div className="notice crit small">{err}</div>}
        <p className="small muted">Includes daily measured export with completeness, performance metrics with formulas and reasons when not computed, inverter comparison, loss categories, alerts with rule versions, maintenance with verification, and forecasts. Every figure links to its API source. Content is hashed (SHA-256).</p>
      </Card>
      <Card title="Reports" className="span2">
        {!list.data ? <Loading /> : (
          <table className="t"><thead><tr><th>Report</th><th>Period</th><th>Generated</th><th>SHA-256</th><th>Export</th></tr></thead>
            <tbody>{list.data.map((r) => (
              <tr key={r.id}><td className="mono">{r.id}<div className="small muted">{r.sites.join(", ")}</div></td><td className="small">{localTime(r.period_start)} → {localTime(r.period_end)}</td><td className="small">{localTime(r.generated_at)}</td><td className="mono small">{r.sha256.slice(0, 12)}…</td>
                <td className="row"><button className="btn sm" onClick={() => openAuthed(`/api/reports/${r.id}.html`)}>HTML</button><button className="btn sm" onClick={() => openAuthed(`/api/reports/${r.id}.json`, `${r.id}.json`)}>JSON</button><button className="btn sm" onClick={() => openAuthed(`/api/reports/${r.id}.csv`, `${r.id}.csv`)}>CSV</button></td></tr>))}</tbody></table>
        )}
      </Card>
    </div>
  );
}
