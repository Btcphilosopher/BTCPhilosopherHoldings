import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { useApi, LiveSnapshot } from "../lib/hooks";
import { Badge, Card, Freshness, Loading, SourceLink, Stat, StatusBadge } from "../components/ui";
import { PortfolioMap } from "../components/diagrams";
import { TimeChart } from "../components/charts";
import { age, agoISO, energy, fmt, localTime, pct, power } from "../lib/format";
import { useSession } from "../lib/session";
import { qs } from "../lib/api";

export default function Overview({ live }: { live: LiveSnapshot | null }) {
  const { data, error, reload } = useApi<any>("/api/overview", [], 60000);
  const { setSiteId } = useSession();
  const nav = useNavigate();
  useEffect(() => { if (live) reload(); }, [live?.at]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!data) return <Loading error={error} />;
  const t = data.totals;
  const today = t.today_export;
  const e = energy(today.energy_kwh);
  const p = power(t.current_export_kw);
  return (
    <>
      <div className="grid g5">
        <Stat accent label="Current export" value={p.v} unit={p.u}
          meta={t.current_export_complete ? <Badge tone="ok">all sites current</Badge> : <Badge tone="warn">{t.sites_not_current.length} site(s) not current — excluded</Badge>}
          source={`/api/overview`} />
        <Stat accent label="Today's measured export" value={e.v} unit={e.u}
          meta={<>{today.complete ? <Badge tone="info">so far · complete coverage</Badge> : <Badge tone="warn">incomplete</Badge>}<span>settlement meters</span></>} />
        <Stat label="Available vs installed AC" value={fmt(t.available_ac_kw / 1000, 2)} unit={`/ ${fmt(t.ac_kw / 1000, 2)} MW`}
          meta={<span>DC {fmt(t.dc_kwp / 1000, 1)} MWp · export limit {fmt(t.export_limit_kw / 1000, 1)} MW</span>} />
        <Stat label="Active alert conditions" value={t.active_conditions} unit={`of ${t.open_alerts} open`}
          meta={<a href="/alerts" onClick={(ev) => { ev.preventDefault(); nav("/alerts"); }}>review alerts →</a>} />
        <Stat label="Open work orders" value={t.open_work_orders}
          meta={<a href="/maintenance" onClick={(ev) => { ev.preventDefault(); nav("/maintenance"); }}>maintenance →</a>} />
      </div>
      <div className="grid g2" style={{ marginTop: 16 }}>
        <Card title="Portfolio map">
          <PortfolioMap sites={data.sites} onSelect={(id) => { setSiteId(id); nav("/sites"); }} />
        </Card>
        <Card title="Telemetry freshness (live link)">
          <table className="t">
            <thead><tr><th>Site</th><th>State</th><th>Newest observation</th><th className="num">Export (meter)</th><th className="num">Active alerts</th></tr></thead>
            <tbody>
              {data.sites.map((s: any) => {
                const lv = live?.sites.find((x) => x.site_id === s.site.id);
                const ex = s.current_generation.export_meter;
                return (
                  <tr key={s.site.id}>
                    <td><b>{s.site.name}</b></td>
                    <td><Freshness ageS={lv?.age_s ?? s.telemetry_freshness.age_s} current={lv ? lv.is_current : s.connection_state !== "disconnected"} /></td>
                    <td>{localTime(lv?.newest_observation ?? s.telemetry_freshness.newest_observation)}</td>
                    <td className="num">{ex ? <>{fmt(ex.value, 0)} kW {!ex.is_current && <Badge tone="warn">last known, {age(ex.age_s)} old</Badge>}</> : "—"}</td>
                    <td className="num">{lv?.active_alerts ?? s.alerts.condition_active}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <p className="small muted">A disconnected site shows its last-known values and their age; it is never shown as producing zero.</p>
        </Card>
      </div>
      {data.sites.map((s: any) => <SiteSummary key={s.site.id} s={s} onOpen={() => { setSiteId(s.site.id); nav("/sites"); }} />)}
    </>
  );
}

function SiteSummary({ s, onOpen }: { s: any; onOpen: () => void }) {
  const start = agoISO(18);
  const meter = s.current_generation.export_meter;
  const { data: ser } = useApi<any>(`/api/telemetry/series?${qs({ site_id: s.site.id, measurement_type: "ac_power", start, asset_type: "meter", resample: "5min" })}`, [], 60000);
  const today = s.today_measured_export;
  const e = energy(today?.energy_kwh);
  return (
    <>
      <div className="section-title">{s.site.name} · {s.site.code}</div>
      <div className="grid g4">
        <Stat label="Export now" value={meter ? fmt(meter.value, 0) : "—"} unit="kW"
          meta={meter ? <Freshness ageS={meter.age_s} current={meter.is_current} /> : <Badge tone="crit">no meter data</Badge>}
          source={meter ? meter.source : undefined} />
        <Stat label="Measured export today" value={e.v} unit={e.u}
          meta={<>{today?.resets?.length ? <Badge tone="warn">meter reset</Badge> : null}<span>coverage {pct(today?.coverage)}</span>{today && <SourceLink url={today.calculation} label="calculation" />}</>} />
        <Stat label="Inverters available" value={`${s.inverter_availability.available}/${s.inverter_availability.total}`}
          meta={<>{s.inverter_availability.unknown > 0 && <Badge tone="warn">{s.inverter_availability.unknown} no telemetry</Badge>}<span>{fmt(s.capacity.available_ac_kw, 0)} of {fmt(s.capacity.ac_kw, 0)} kW AC</span></>} />
        <Stat label="Alerts · work" value={s.alerts.condition_active} unit="active"
          meta={<>{s.alerts.critical > 0 && <Badge tone="crit">{s.alerts.critical} critical</Badge>}<span>{s.maintenance.open_work_orders} open WOs · {s.maintenance.overdue_schedules} overdue schedules</span></>} />
      </div>
      <div className="grid g3" style={{ marginTop: 16 }}>
        <Card title="Export meter power (kW) — last 18 h" className="span2" actions={<button className="btn sm" onClick={onOpen}>Open site</button>}>
          {ser ? <TimeChart data={ser.points} unit="kW" series={ser.assets.map((a: string) => ({ key: a, name: `${a} (5-min mean)`, type: "area" as const }))} height={220} multiDay /> : <Loading />}
        </Card>
        <Card title="Inverters">
          <table className="t">
            <thead><tr><th>Inverter</th><th>State</th><th className="num">AC kW</th></tr></thead>
            <tbody>
              {s.inverters.map((i: any) => (
                <tr key={i.asset_id}>
                  <td>{i.asset_id}</td>
                  <td><StatusBadge status={i.state} /></td>
                  <td className="num">{i.ac_power ? <>{fmt(i.ac_power.value, 0)}{!i.ac_power.is_current && <div className="small warn-text">{age(i.ac_power.age_s)} old</div>}</> : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {s.curtailment.active_now.length > 0 && <div className="notice warn small">Curtailment active: {s.curtailment.active_now.join(", ")}</div>}
          {s.curtailment.last_7_days.length > 0 && <p className="small muted">Recorded curtailment (7 d): {s.curtailment.last_7_days.map((c: any) => `${localTime(c.start)}–${localTime(c.end, undefined, false)} @ ${c.limit_kw} kW`).join("; ")}</p>}
          {s.battery && <p className="small">Battery SoC <b>{pct(s.battery.soc?.value, 0)}</b> · {s.battery.state?.value === 2 ? "charging" : s.battery.state?.value === 3 ? "discharging" : "idle"} · <span className="muted">read-only integration</span></p>}
        </Card>
      </div>
    </>
  );
}
