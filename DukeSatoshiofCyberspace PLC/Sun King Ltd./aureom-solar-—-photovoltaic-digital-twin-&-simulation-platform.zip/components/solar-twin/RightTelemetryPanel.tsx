'use client';

import React from 'react';
import {
  Activity,
  Sun,
  Zap,
  Thermometer,
  Battery,
  ArrowDownRight,
  ArrowUpRight,
  Percent,
  CheckCircle2,
  AlertTriangle,
  Minimize2,
  ChevronLeft,
} from 'lucide-react';
import { IrradianceResult } from '@/lib/physics/irradiance';
import { ThermalResult } from '@/lib/physics/thermal';
import { BatteryDispatchResult } from '@/lib/physics/battery';
import { GridBalanceResult } from '@/lib/physics/grid-system';

interface RightTelemetryPanelProps {
  irradiance: IrradianceResult;
  thermal: ThermalResult;
  bifacialGainPercent: number;
  dcPowerKw: number;
  acPowerKw: number;
  inverterEfficiencyPercent: number;
  isClipping: boolean;
  clippingLossKw: number;
  battery: BatteryDispatchResult;
  grid: GridBalanceResult;
  dailyYieldKwh: number;
  performanceRatioPercent: number;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

export function RightTelemetryPanel({
  irradiance,
  thermal,
  bifacialGainPercent,
  dcPowerKw,
  acPowerKw,
  inverterEfficiencyPercent,
  isClipping,
  clippingLossKw,
  battery,
  grid,
  dailyYieldKwh,
  performanceRatioPercent,
  isCollapsed,
  onToggleCollapse,
}: RightTelemetryPanelProps) {
  if (isCollapsed) {
    return (
      <div className="w-12 bg-[#101820] border-l border-[#34576C]/30 flex flex-col items-center py-4 gap-4 text-[#94a3b8] z-20">
        <button
          onClick={onToggleCollapse}
          title="Expand Telemetry Instrumentation"
          className="p-2 hover:text-[#53B6CA] hover:bg-[#172735] rounded transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <span className="text-[10px] font-mono tracking-widest uppercase rotate-90 my-8 text-[#53B6CA]">
          TELEMETRY
        </span>
      </div>
    );
  }

  return (
    <aside className="w-80 md:w-88 h-full bg-[#101820] border-l border-[#34576C]/30 flex flex-col overflow-y-auto z-20 select-none">
      {/* Panel Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-[#34576C]/30 bg-[#172735]/40">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-[#E9A83B]" />
          <span className="text-xs font-semibold text-white tracking-wide uppercase font-mono">
            PHYSICAL TELEMETRY STREAM
          </span>
        </div>
        <button
          onClick={onToggleCollapse}
          title="Collapse Panel"
          className="text-[#94a3b8] hover:text-white p-1 rounded"
        >
          <Minimize2 className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="flex-1 p-3 space-y-3 font-mono text-xs">
        {/* CARD 1: IRRADIANCE SENSORS */}
        <div className="p-3 bg-[#172735]/30 border border-[#34576C]/40 rounded">
          <div className="flex items-center justify-between text-[#94a3b8] text-[10px] uppercase tracking-wider mb-1">
            <span className="flex items-center gap-1.5">
              <Sun className="w-3.5 h-3.5 text-[#E9A83B]" />
              <span>PLANE-OF-ARRAY IRRADIANCE</span>
            </span>
            <span className="text-[#53B6CA]">AOI: {irradiance.aoi.toFixed(1)}°</span>
          </div>

          <div className="flex items-baseline mb-2">
            <span className="text-3xl font-bold font-mono text-white tabular-nums">
              {irradiance.poaTotal.toFixed(0)}
            </span>
            <span className="text-xs text-[#94a3b8] ml-1.5">W/m²</span>
            {bifacialGainPercent > 0 && (
              <span className="ml-auto text-[11px] text-[#53B6CA] bg-[#101820] px-1.5 py-0.5 rounded border border-[#53B6CA]/30">
                +{bifacialGainPercent.toFixed(1)}% BIFACIAL
              </span>
            )}
          </div>

          <div className="grid grid-cols-3 gap-1 pt-2 border-t border-[#34576C]/30 text-[10px]">
            <div>
              <span className="text-[#94a3b8] block">Beam:</span>
              <strong className="text-white tabular-nums">{irradiance.poaBeam.toFixed(0)} W/m²</strong>
            </div>
            <div>
              <span className="text-[#94a3b8] block">Sky Diff:</span>
              <strong className="text-white tabular-nums">{irradiance.poaSkyDiffuse.toFixed(0)} W/m²</strong>
            </div>
            <div>
              <span className="text-[#94a3b8] block">Albedo Ref:</span>
              <strong className="text-white tabular-nums">{irradiance.poaGroundReflected.toFixed(0)} W/m²</strong>
            </div>
          </div>
        </div>

        {/* CARD 2: ELECTRICAL GENERATION & INVERTER */}
        <div className="p-3 bg-[#172735]/30 border border-[#34576C]/40 rounded">
          <div className="flex items-center justify-between text-[#94a3b8] text-[10px] uppercase tracking-wider mb-1">
            <span className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-[#53B6CA]" />
              <span>POWER OUTPUT</span>
            </span>
            <span className="text-[#53B6CA]">η_inv: {inverterEfficiencyPercent}%</span>
          </div>

          <div className="grid grid-cols-2 gap-2 mb-2">
            <div>
              <span className="text-[10px] text-[#94a3b8] block">DC GENERATION</span>
              <div className="flex items-baseline">
                <span className="text-2xl font-bold font-mono text-white tabular-nums">
                  {dcPowerKw.toFixed(1)}
                </span>
                <span className="text-[11px] text-[#94a3b8] ml-1">kW</span>
              </div>
            </div>

            <div>
              <span className="text-[10px] text-[#94a3b8] block">AC GRID INJECTION</span>
              <div className="flex items-baseline">
                <span className="text-2xl font-bold font-mono text-[#53B6CA] tabular-nums">
                  {acPowerKw.toFixed(1)}
                </span>
                <span className="text-[11px] text-[#94a3b8] ml-1">kW</span>
              </div>
            </div>
          </div>

          {isClipping && (
            <div className="flex items-center gap-1.5 p-1.5 bg-[#D95D57]/10 border border-[#D95D57]/40 rounded text-[11px] text-[#D95D57]">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
              <span>Clipping: {clippingLossKw.toFixed(1)} kW curtailed at inverter limit</span>
            </div>
          )}
        </div>

        {/* CARD 3: THERMAL DIGITAL TWIN */}
        <div className="p-3 bg-[#172735]/30 border border-[#34576C]/40 rounded">
          <div className="flex items-center justify-between text-[#94a3b8] text-[10px] uppercase tracking-wider mb-1">
            <span className="flex items-center gap-1.5">
              <Thermometer className="w-3.5 h-3.5 text-[#E9A83B]" />
              <span>THERMAL STATE</span>
            </span>
            <span className="text-[#E9A83B] tabular-nums">{thermal.thermalDeratingPercent}% Pmp Loss</span>
          </div>

          <div className="flex items-baseline justify-between mb-2">
            <div className="flex items-baseline">
              <span className="text-2xl font-bold font-mono text-white tabular-nums">
                {thermal.cellTemperatureC}
              </span>
              <span className="text-xs text-[#94a3b8] ml-1">°C Cell</span>
            </div>
            <div className="text-right text-[11px]">
              <span className="text-[#94a3b8]">Backsheet:</span>{' '}
              <strong className="text-white tabular-nums">{thermal.backsheetTemperatureC}°C</strong>
            </div>
          </div>

          {/* Visual calibrated thermal bar */}
          <div className="space-y-1">
            <div className="w-full h-1.5 rounded-full bg-[#101820] overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-300"
                style={{
                  width: `${thermal.normalizedHeatValue * 100}%`,
                  backgroundColor: thermal.thermographicColorHex,
                }}
              />
            </div>
            <div className="flex justify-between text-[9px] text-[#94a3b8]">
              <span>20°C (Cold)</span>
              <span>45°C (NOCT)</span>
              <span>75°C (Extreme)</span>
            </div>
          </div>
        </div>

        {/* CARD 4: BATTERY STATE & GRID FLOW */}
        <div className="p-3 bg-[#172735]/30 border border-[#34576C]/40 rounded space-y-2">
          <div className="flex items-center justify-between text-[#94a3b8] text-[10px] uppercase tracking-wider">
            <span className="flex items-center gap-1.5">
              <Battery className="w-3.5 h-3.5 text-[#53B6CA]" />
              <span>BESS STORAGE & DISPATCH</span>
            </span>
            <span className="text-[#53B6CA] font-bold tabular-nums">{battery.newSocPercent}% SOC</span>
          </div>

          {/* SOC Progress Bar */}
          <div className="w-full h-2 rounded bg-[#101820] overflow-hidden p-0.5 border border-[#34576C]/40">
            <div
              className={`h-full rounded transition-all duration-300 ${
                battery.newSocPercent < 20 ? 'bg-[#D95D57]' : 'bg-[#53B6CA]'
              }`}
              style={{ width: `${Math.min(100, Math.max(0, battery.newSocPercent))}%` }}
            />
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1 text-[11px]">
            <div>
              <span className="text-[#94a3b8] block">Stored Energy:</span>
              <strong className="text-white tabular-nums">{battery.storedEnergyKwh} kWh</strong>
            </div>
            <div>
              <span className="text-[#94a3b8] block">Net Flow:</span>
              <strong
                className={`tabular-nums ${
                  battery.netBatteryFlowKw > 0
                    ? 'text-[#53B6CA]'
                    : battery.netBatteryFlowKw < 0
                    ? 'text-[#E9A83B]'
                    : 'text-[#94a3b8]'
                }`}
              >
                {battery.netBatteryFlowKw > 0
                  ? `+${battery.netBatteryFlowKw} kW (Chg)`
                  : battery.netBatteryFlowKw < 0
                  ? `${battery.netBatteryFlowKw} kW (Dis)`
                  : 'Idle (0 kW)'}
              </strong>
            </div>
          </div>

          {/* Grid Import / Export */}
          <div className="p-2 bg-[#101820] rounded border border-[#34576C]/30 text-[11px] space-y-1">
            <div className="flex justify-between">
              <span className="text-[#94a3b8]">Facility Electrical Load:</span>
              <strong className="text-white tabular-nums">{grid.facilityLoadKw} kW</strong>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[#94a3b8] flex items-center gap-1">
                <ArrowUpRight className="w-3 h-3 text-[#53B6CA]" />
                <span>Grid Export:</span>
              </span>
              <strong className="text-[#53B6CA] tabular-nums">{grid.gridExportKw} kW</strong>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[#94a3b8] flex items-center gap-1">
                <ArrowDownRight className="w-3 h-3 text-[#E9A83B]" />
                <span>Grid Import:</span>
              </span>
              <strong className="text-[#E9A83B] tabular-nums">{grid.gridImportKw} kW</strong>
            </div>
          </div>
        </div>

        {/* CARD 5: CUMULATIVE METRICS */}
        <div className="p-3 bg-[#172735]/30 border border-[#34576C]/40 rounded">
          <div className="flex items-center justify-between text-[#94a3b8] text-[10px] uppercase tracking-wider mb-2">
            <span>KEY PERFORMANCE RATIOS</span>
            <span className="text-[#53B6CA] flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              <span>IEC 61724</span>
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-center">
            <div className="p-2 bg-[#101820] rounded border border-[#34576C]/30">
              <span className="text-[10px] text-[#94a3b8] block">TODAY YIELD</span>
              <span className="text-lg font-bold font-mono text-white tabular-nums">
                {dailyYieldKwh.toFixed(1)}
              </span>
              <span className="text-[10px] text-[#94a3b8] block">kWh</span>
            </div>

            <div className="p-2 bg-[#101820] rounded border border-[#34576C]/30">
              <span className="text-[10px] text-[#94a3b8] block">PERF. RATIO (PR)</span>
              <span className="text-lg font-bold font-mono text-[#53B6CA] tabular-nums">
                {performanceRatioPercent.toFixed(1)}%
              </span>
              <span className="text-[10px] text-[#94a3b8] block">Target: &gt;80%</span>
            </div>
          </div>

          <div className="flex justify-between text-[11px] pt-2 mt-2 border-t border-[#34576C]/30">
            <span className="text-[#94a3b8]">Self-Consumption:</span>
            <strong className="text-white tabular-nums">{grid.selfConsumptionRatioPercent}%</strong>
          </div>
          <div className="flex justify-between text-[11px]">
            <span className="text-[#94a3b8]">Self-Sufficiency:</span>
            <strong className="text-white tabular-nums">{grid.selfSufficiencyRatioPercent}%</strong>
          </div>
        </div>
      </div>
    </aside>
  );
}
