'use client';

import React from 'react';
import { FileText, Sliders, Activity, BarChart3, Layers } from 'lucide-react';

interface WorkstationHeaderProps {
  onOpenPhysicsModal: () => void;
  onOpenScaleModal: () => void;
  onOpenFinancialsModal: () => void;
  onOpenReportModal: () => void;
  activeView: 'workstation' | 'physics' | 'financials' | 'report';
}

export function WorkstationHeader({
  onOpenPhysicsModal,
  onOpenScaleModal,
  onOpenFinancialsModal,
  onOpenReportModal,
  activeView,
}: WorkstationHeaderProps) {
  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-[#101820] border-b border-[#34576C]/30 select-none z-30">
      {/* Zone 1: Wordmark */}
      <div className="flex items-center gap-3 whitespace-nowrap shrink-0">
        <div className="w-6 h-6 rounded bg-[#E9A83B] flex items-center justify-center font-bold text-[#101820] text-xs">
          A
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-base font-bold tracking-tight text-white">
            AUREOM SOLAR
          </span>
          <span className="text-xs font-mono text-[#53B6CA] hidden sm:inline">
            Digital Twin v3.8
          </span>
        </div>
      </div>

      {/* Zone 2: Navigation Links (4-5 single-line clean controls) */}
      <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-[#94a3b8]">
        <button
          onClick={onOpenScaleModal}
          className="hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
        >
          <Layers className="w-3.5 h-3.5 text-[#53B6CA]" />
          <span>Array Architecture</span>
        </button>
        <button
          onClick={onOpenPhysicsModal}
          className="hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
        >
          <Activity className="w-3.5 h-3.5 text-[#E9A83B]" />
          <span>I-V Semiconductor Lab</span>
        </button>
        <button
          onClick={onOpenFinancialsModal}
          className="hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
        >
          <BarChart3 className="w-3.5 h-3.5 text-[#53B6CA]" />
          <span>LCOE & Monte Carlo</span>
        </button>
      </nav>

      {/* Zone 3: 1 Primary Action */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onOpenReportModal}
          className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-[#101820] bg-[#E9A83B] hover:bg-[#d8962b] rounded transition-colors shadow-sm whitespace-nowrap shrink-0"
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Engineering Report</span>
        </button>
      </div>
    </header>
  );
}
