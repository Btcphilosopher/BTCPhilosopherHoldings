'use client';

import React, { useState, useMemo } from 'react';
import { X, Sliders, Activity, Info, RefreshCw } from 'lucide-react';
import { MODULE_PRESETS, ModuleSpecs, calculateModulePhysics } from '@/lib/physics/single-diode';

interface PhysicsCurveModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialModule?: ModuleSpecs;
}

export function PhysicsCurveModal({ isOpen, onClose, initialModule }: PhysicsCurveModalProps) {
  const [selectedModuleKey, setSelectedModuleKey] = useState<string>(initialModule?.id || 'topcon-580');
  const [irradiance, setIrradiance] = useState<number>(1000);
  const [cellTempC, setCellTempC] = useState<number>(25);
  const [customRs, setCustomRs] = useState<number>(0.32);
  const [customRsh, setCustomRsh] = useState<number>(650);
  const [customN, setCustomN] = useState<number>(1.08);
  const [shadedSubstrings, setShadedSubstrings] = useState<number>(0);
  const [showMultiCurveFamily, setShowMultiCurveFamily] = useState<boolean>(true);
  const [hoveredPoint, setHoveredPoint] = useState<{ v: number; i: number; p: number } | null>(null);

  const currentSpecs = MODULE_PRESETS[selectedModuleKey] || MODULE_PRESETS['topcon-580'];

  // Calculate primary operating curve
  const cellPhysics = useMemo(() => {
    return calculateModulePhysics(currentSpecs, {
      effectiveIrradiance: irradiance,
      cellTemperatureC: cellTempC,
      customRs,
      customRsh,
      customN,
      shadedSubstringsCount: shadedSubstrings,
      shadedFraction: 0.25,
    });
  }, [currentSpecs, irradiance, cellTempC, customRs, customRsh, customN, shadedSubstrings]);

  // Family of curves at 200, 400, 600, 800, 1000 W/m²
  const curveFamily = useMemo(() => {
    if (!showMultiCurveFamily) return [];
    const gLevels = [200, 400, 600, 800, 1000];
    return gLevels.map((g) => ({
      g,
      res: calculateModulePhysics(currentSpecs, {
        effectiveIrradiance: g,
        cellTemperatureC: cellTempC,
        customRs,
        customRsh,
        customN,
      }),
    }));
  }, [currentSpecs, cellTempC, customRs, customRsh, customN, showMultiCurveFamily]);

  if (!isOpen) return null;

  // Chart dimensions & scaling
  const svgWidth = 620;
  const svgHeight = 320;
  const margin = { top: 20, right: 60, bottom: 40, left: 55 };
  const plotWidth = svgWidth - margin.left - margin.right;
  const plotHeight = svgHeight - margin.top - margin.bottom;

  // Axes scales
  const maxV = Math.max(60, currentSpecs.vocRef * 1.15);
  const maxI = Math.max(18, currentSpecs.iscRef * 1.25);
  const maxP = Math.max(750, currentSpecs.pmpRef * 1.3);

  const scaleX = (v: number) => margin.left + (v / maxV) * plotWidth;
  const scaleYI = (i: number) => margin.top + plotHeight - (i / maxI) * plotHeight;
  const scaleYP = (p: number) => margin.top + plotHeight - (p / maxP) * plotHeight;

  // Convert points to SVG path strings
  const ivPath = cellPhysics.ivCurve
    .map((pt, idx) => `${idx === 0 ? 'M' : 'L'} ${scaleX(pt.v).toFixed(1)} ${scaleYI(pt.i).toFixed(1)}`)
    .join(' ');

  const pvPath = cellPhysics.pvCurve
    .map((pt, idx) => `${idx === 0 ? 'M' : 'L'} ${scaleX(pt.v).toFixed(1)} ${scaleYP(pt.p).toFixed(1)}`)
    .join(' ');

  // Reset to factory defaults
  const resetToFactory = () => {
    setIrradiance(1000);
    setCellTempC(25);
    setCustomRs(currentSpecs.rsRef);
    setCustomRsh(currentSpecs.rshRef);
    setCustomN(currentSpecs.idealityFactor);
    setShadedSubstrings(0);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="w-full max-w-5xl bg-[#101820] border border-[#34576C]/60 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#34576C]/40 bg-[#172735]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-[#E9A83B]/20 text-[#E9A83B]">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold tracking-wide uppercase text-white font-mono">
                Semiconductor I–V and P–V Physics Laboratory
              </h2>
              <p className="text-xs text-[#94a3b8] font-mono">
                5-Parameter Single-Diode Model • Newton-Raphson Solver • De Soto Temperature Scaling
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#94a3b8] hover:text-white hover:bg-[#101820] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono text-xs">
          {/* Left Column: Interactive Controls */}
          <div className="lg:col-span-4 space-y-4">
            <div className="p-4 bg-[#172735]/40 border border-[#34576C]/40 rounded-lg space-y-3">
              <div className="flex items-center justify-between border-b border-[#34576C]/40 pb-2">
                <span className="font-semibold text-white uppercase text-[11px] flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-[#53B6CA]" />
                  <span>Diode Parameters</span>
                </span>
                <button
                  onClick={resetToFactory}
                  className="text-[10px] text-[#53B6CA] hover:text-white flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Reset STC</span>
                </button>
              </div>

              {/* Module Selector */}
              <div>
                <label className="text-[11px] text-[#94a3b8] block mb-1">Module Technology:</label>
                <select
                  value={selectedModuleKey}
                  onChange={(e) => {
                    setSelectedModuleKey(e.target.value);
                    const specs = MODULE_PRESETS[e.target.value];
                    if (specs) {
                      setCustomRs(specs.rsRef);
                      setCustomRsh(specs.rshRef);
                      setCustomN(specs.idealityFactor);
                    }
                  }}
                  className="w-full bg-[#101820] text-xs text-white px-2 py-1.5 rounded border border-[#34576C]/60"
                >
                  {Object.values(MODULE_PRESETS).map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.pmpRef}W, {m.efficiencyRef}%)
                    </option>
                  ))}
                </select>
              </div>

              {/* Irradiance Slider */}
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94a3b8]">Effective Irradiance (G):</span>
                  <span className="text-[#E9A83B] font-bold tabular-nums">{irradiance} W/m²</span>
                </div>
                <input
                  type="range"
                  min="100"
                  max="1200"
                  step="25"
                  value={irradiance}
                  onChange={(e) => setIrradiance(Number(e.target.value))}
                  className="w-full accent-[#E9A83B] h-1.5 bg-[#101820] rounded cursor-pointer"
                />
              </div>

              {/* Cell Temperature Slider */}
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94a3b8]">Cell Temperature (Tc):</span>
                  <span className="text-[#53B6CA] font-bold tabular-nums">{cellTempC}°C</span>
                </div>
                <input
                  type="range"
                  min="-15"
                  max="85"
                  step="1"
                  value={cellTempC}
                  onChange={(e) => setCellTempC(Number(e.target.value))}
                  className="w-full accent-[#53B6CA] h-1.5 bg-[#101820] rounded cursor-pointer"
                />
              </div>

              {/* Series Resistance (Rs) */}
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94a3b8]">Series Resistance (Rs):</span>
                  <span className="text-white font-bold tabular-nums">{customRs.toFixed(2)} Ω</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="1.50"
                  step="0.02"
                  value={customRs}
                  onChange={(e) => setCustomRs(Number(e.target.value))}
                  className="w-full accent-[#53B6CA] h-1.5 bg-[#101820] rounded cursor-pointer"
                />
              </div>

              {/* Shunt Resistance (Rsh) */}
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94a3b8]">Shunt Resistance (Rsh):</span>
                  <span className="text-white font-bold tabular-nums">{customRsh} Ω</span>
                </div>
                <input
                  type="range"
                  min="100"
                  max="2000"
                  step="50"
                  value={customRsh}
                  onChange={(e) => setCustomRsh(Number(e.target.value))}
                  className="w-full accent-[#53B6CA] h-1.5 bg-[#101820] rounded cursor-pointer"
                />
              </div>

              {/* Diode Ideality Factor (n) */}
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94a3b8]">Diode Ideality Factor (n):</span>
                  <span className="text-white font-bold tabular-nums">{customN.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0.95"
                  max="1.60"
                  step="0.02"
                  value={customN}
                  onChange={(e) => setCustomN(Number(e.target.value))}
                  className="w-full accent-[#53B6CA] h-1.5 bg-[#101820] rounded cursor-pointer"
                />
              </div>

              {/* Bypass Diode Shading Knees */}
              <div>
                <label className="text-[11px] text-[#94a3b8] block mb-1">Bypass Diode Partial Shading:</label>
                <div className="grid grid-cols-4 gap-1">
                  {[0, 1, 2, 3].map((val) => (
                    <button
                      key={val}
                      onClick={() => setShadedSubstrings(val)}
                      className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                        shadedSubstrings === val
                          ? 'bg-[#E9A83B] text-[#101820] font-bold'
                          : 'bg-[#101820] text-[#94a3b8] hover:text-white border border-[#34576C]/40'
                      }`}
                    >
                      {val === 0 ? 'None' : `${val} String`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Toggle Curve Family */}
              <div className="flex items-center justify-between pt-2 border-t border-[#34576C]/30 text-[11px]">
                <span className="text-[#94a3b8]">Overlay Irradiance Family:</span>
                <input
                  type="checkbox"
                  checked={showMultiCurveFamily}
                  onChange={(e) => setShowMultiCurveFamily(e.target.checked)}
                  className="accent-[#53B6CA] w-4 h-4 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Right Column: High-Precision SVG Curves & Output KPI Grid */}
          <div className="lg:col-span-8 space-y-4">
            {/* KPI Cards Row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div className="p-3 bg-[#172735]/40 border border-[#34576C]/40 rounded-lg">
                <span className="text-[10px] text-[#94a3b8] block uppercase">Max Power (Pmp)</span>
                <div className="flex items-baseline">
                  <span className="text-xl font-bold text-white tabular-nums">
                    {cellPhysics.pmp.toFixed(1)}
                  </span>
                  <span className="text-xs text-[#94a3b8] ml-1">W</span>
                </div>
                <span className="text-[10px] text-[#53B6CA]">
                  Vmp: {cellPhysics.vmp.toFixed(1)}V • Imp: {cellPhysics.imp.toFixed(2)}A
                </span>
              </div>

              <div className="p-3 bg-[#172735]/40 border border-[#34576C]/40 rounded-lg">
                <span className="text-[10px] text-[#94a3b8] block uppercase">Open-Circuit (Voc)</span>
                <div className="flex items-baseline">
                  <span className="text-xl font-bold text-white tabular-nums">
                    {cellPhysics.voc.toFixed(1)}
                  </span>
                  <span className="text-xs text-[#94a3b8] ml-1">V</span>
                </div>
                <span className="text-[10px] text-[#94a3b8]">
                  Short-Circuit (Isc): {cellPhysics.isc.toFixed(2)}A
                </span>
              </div>

              <div className="p-3 bg-[#172735]/40 border border-[#34576C]/40 rounded-lg">
                <span className="text-[10px] text-[#94a3b8] block uppercase">Fill Factor (FF)</span>
                <div className="flex items-baseline">
                  <span className="text-xl font-bold text-[#E9A83B] tabular-nums">
                    {(cellPhysics.fillFactor * 100).toFixed(1)}
                  </span>
                  <span className="text-xs text-[#94a3b8] ml-1">%</span>
                </div>
                <span className="text-[10px] text-[#94a3b8]">
                  Vt(mod): {cellPhysics.vtMod.toFixed(2)}V
                </span>
              </div>

              <div className="p-3 bg-[#172735]/40 border border-[#34576C]/40 rounded-lg">
                <span className="text-[10px] text-[#94a3b8] block uppercase">Conversion Efficiency</span>
                <div className="flex items-baseline">
                  <span className="text-xl font-bold text-[#53B6CA] tabular-nums">
                    {cellPhysics.efficiency.toFixed(2)}
                  </span>
                  <span className="text-xs text-[#94a3b8] ml-1">%</span>
                </div>
                <span className="text-[10px] text-[#94a3b8]">
                  STC: {currentSpecs.efficiencyRef}%
                </span>
              </div>
            </div>

            {/* SVG Interactive Dual-Axis Chart */}
            <div className="p-4 bg-[#172735]/20 border border-[#34576C]/40 rounded-lg relative overflow-hidden">
              <div className="flex items-center justify-between text-[11px] mb-2">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1.5 text-[#53B6CA] font-semibold">
                    <span className="w-3 h-0.5 bg-[#53B6CA]" />
                    <span>I–V Current Curve (Amperes)</span>
                  </span>
                  <span className="flex items-center gap-1.5 text-[#E9A83B] font-semibold">
                    <span className="w-3 h-0.5 bg-[#E9A83B]" />
                    <span>P–V Power Curve (Watts)</span>
                  </span>
                </div>

                {hoveredPoint && (
                  <div className="text-[11px] text-white bg-[#101820] px-2 py-0.5 rounded border border-[#34576C]/60 tabular-nums">
                    V: {hoveredPoint.v.toFixed(1)}V | I: {hoveredPoint.i.toFixed(2)}A | P: {hoveredPoint.p.toFixed(1)}W
                  </div>
                )}
              </div>

              <svg
                viewBox={`0 0 ${svgWidth} ${svgHeight}`}
                className="w-full h-auto overflow-visible cursor-crosshair"
                onMouseMove={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const mouseX = e.clientX - rect.left;
                  const svgX = (mouseX / rect.width) * svgWidth;
                  if (svgX >= margin.left && svgX <= margin.left + plotWidth) {
                    const vHover = ((svgX - margin.left) / plotWidth) * maxV;
                    // Find closest point in curve
                    let closest = cellPhysics.ivCurve[0];
                    let minDiff = Infinity;
                    for (const pt of cellPhysics.ivCurve) {
                      const diff = Math.abs(pt.v - vHover);
                      if (diff < minDiff) {
                        minDiff = diff;
                        closest = pt;
                      }
                    }
                    setHoveredPoint(closest);
                  }
                }}
                onMouseLeave={() => setHoveredPoint(null)}
              >
                {/* Background gridlines */}
                {[0, 0.25, 0.5, 0.75, 1].map((frac) => {
                  const y = margin.top + plotHeight * frac;
                  return (
                    <line
                      key={frac}
                      x1={margin.left}
                      y1={y}
                      x2={margin.left + plotWidth}
                      y2={y}
                      stroke="#223344"
                      strokeDasharray="3 3"
                    />
                  );
                })}
                {[0, 0.25, 0.5, 0.75, 1].map((frac) => {
                  const x = margin.left + plotWidth * frac;
                  return (
                    <line
                      key={frac}
                      x1={x}
                      y1={margin.top}
                      x2={x}
                      y2={margin.top + plotHeight}
                      stroke="#223344"
                      strokeDasharray="3 3"
                    />
                  );
                })}

                {/* Multi-curve family under-traces */}
                {curveFamily.map(({ g, res }) => {
                  const famIvPath = res.ivCurve
                    .map((pt, idx) => `${idx === 0 ? 'M' : 'L'} ${scaleX(pt.v).toFixed(1)} ${scaleYI(pt.i).toFixed(1)}`)
                    .join(' ');
                  return (
                    <path
                      key={g}
                      d={famIvPath}
                      fill="none"
                      stroke="#34576C"
                      strokeWidth="1.2"
                      strokeOpacity="0.45"
                    />
                  );
                })}

                {/* Primary I-V Curve */}
                <path d={ivPath} fill="none" stroke="#53B6CA" strokeWidth="2.5" />

                {/* Primary P-V Curve */}
                <path d={pvPath} fill="none" stroke="#E9A83B" strokeWidth="2.5" strokeDasharray="4 2" />

                {/* MPP Marker Point */}
                <circle
                  cx={scaleX(cellPhysics.vmp)}
                  cy={scaleYI(cellPhysics.imp)}
                  r="5"
                  fill="#53B6CA"
                  stroke="#101820"
                  strokeWidth="2"
                />
                <circle
                  cx={scaleX(cellPhysics.vmp)}
                  cy={scaleYP(cellPhysics.pmp)}
                  r="5"
                  fill="#E9A83B"
                  stroke="#101820"
                  strokeWidth="2"
                />

                {/* Hover Probe Line & Indicator */}
                {hoveredPoint && (
                  <g>
                    <line
                      x1={scaleX(hoveredPoint.v)}
                      y1={margin.top}
                      x2={scaleX(hoveredPoint.v)}
                      y2={margin.top + plotHeight}
                      stroke="#EDF2F3"
                      strokeWidth="1"
                      strokeDasharray="2 2"
                    />
                    <circle
                      cx={scaleX(hoveredPoint.v)}
                      cy={scaleYI(hoveredPoint.i)}
                      r="4"
                      fill="#53B6CA"
                    />
                    <circle
                      cx={scaleX(hoveredPoint.v)}
                      cy={scaleYP(hoveredPoint.p)}
                      r="4"
                      fill="#E9A83B"
                    />
                  </g>
                )}

                {/* Left Y-Axis: Current (A) */}
                <text
                  x={margin.left - 10}
                  y={margin.top + 8}
                  fill="#53B6CA"
                  textAnchor="end"
                  className="font-mono text-[10px]"
                >
                  {maxI.toFixed(0)}A
                </text>
                <text
                  x={margin.left - 10}
                  y={margin.top + plotHeight}
                  fill="#53B6CA"
                  textAnchor="end"
                  className="font-mono text-[10px]"
                >
                  0A
                </text>

                {/* Right Y-Axis: Power (W) */}
                <text
                  x={margin.left + plotWidth + 10}
                  y={margin.top + 8}
                  fill="#E9A83B"
                  textAnchor="start"
                  className="font-mono text-[10px]"
                >
                  {maxP.toFixed(0)}W
                </text>
                <text
                  x={margin.left + plotWidth + 10}
                  y={margin.top + plotHeight}
                  fill="#E9A83B"
                  textAnchor="start"
                  className="font-mono text-[10px]"
                >
                  0W
                </text>

                {/* X-Axis: Voltage (V) */}
                <text
                  x={margin.left}
                  y={margin.top + plotHeight + 20}
                  fill="#94a3b8"
                  textAnchor="middle"
                  className="font-mono text-[10px]"
                >
                  0V
                </text>
                <text
                  x={margin.left + plotWidth / 2}
                  y={margin.top + plotHeight + 20}
                  fill="#94a3b8"
                  textAnchor="middle"
                  className="font-mono text-[10px]"
                >
                  Terminal Voltage V (Volts)
                </text>
                <text
                  x={margin.left + plotWidth}
                  y={margin.top + plotHeight + 20}
                  fill="#94a3b8"
                  textAnchor="middle"
                  className="font-mono text-[10px]"
                >
                  {maxV.toFixed(0)}V
                </text>
              </svg>
            </div>

            {/* Scientific Notes */}
            <div className="p-3 bg-[#101820] border border-[#34576C]/30 rounded text-[11px] text-[#94a3b8] flex items-start gap-2">
              <Info className="w-4 h-4 text-[#53B6CA] shrink-0 mt-0.5" />
              <span>
                <strong>Semiconductor Invariant:</strong> At the Maximum Power Point, the derivative of electrical power with respect to terminal voltage satisfies <code className="text-white">dP/dV = I + V·(dI/dV) = 0</code>. Series resistance <code className="text-white">Rs</code> degrades Fill Factor by flattening the knee, while shunt resistance <code className="text-white">Rsh</code> causes slope leakage at low voltages.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
