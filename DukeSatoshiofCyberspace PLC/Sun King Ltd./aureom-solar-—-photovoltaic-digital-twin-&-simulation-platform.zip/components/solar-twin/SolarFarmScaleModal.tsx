'use client';

import React, { useState } from 'react';
import { X, Layers, Compass, Grid, Map, CheckCircle2, Sliders, ArrowRight } from 'lucide-react';

interface SolarFarmScaleModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentScale: 'single' | 'string' | 'commercial' | 'utility';
  onSelectScale: (scale: 'single' | 'string' | 'commercial' | 'utility') => void;
  activeFidelity: 'cell' | 'module' | 'string' | 'array' | 'plant';
  onSelectFidelity: (fidelity: 'cell' | 'module' | 'string' | 'array' | 'plant') => void;
}

export function SolarFarmScaleModal({
  isOpen,
  onClose,
  currentScale,
  onSelectScale,
  activeFidelity,
  onSelectFidelity,
}: SolarFarmScaleModalProps) {
  if (!isOpen) return null;

  const farmArchetypes = [
    {
      id: 'single',
      name: 'Single Module Inspection Station',
      scaleLabel: '580 Wp Research Bench',
      moduleCount: 1,
      dcCapacityKw: 0.58,
      landAreaM2: 2.6,
      recommendedFidelity: 'cell',
      description: 'Single-cell & bypass diode sub-string level resolution with localized thermal hot-spot tracking.',
    },
    {
      id: 'string',
      name: 'Residential / Commercial String',
      scaleLabel: '14.0 kWp Series String',
      moduleCount: 24,
      dcCapacityKw: 13.9,
      landAreaM2: 75,
      recommendedFidelity: 'module',
      description: 'Module-level electrical matching and bypass diode conduction across 24 series-connected modules.',
    },
    {
      id: 'commercial',
      name: 'Commercial Rooftop & Microgrid',
      scaleLabel: '110 kWp Industrial Array',
      moduleCount: 192,
      dcCapacityKw: 111.4,
      landAreaM2: 950,
      recommendedFidelity: 'string',
      description: 'Multi-MPPT combiner box string mismatch, building boundary shading, and BESS hybrid coupling.',
    },
    {
      id: 'utility',
      name: 'Utility-Scale Solar Farm',
      scaleLabel: '50 MWp Tracking Power Plant',
      moduleCount: 86200,
      dcCapacityKw: 50000,
      landAreaM2: 650000,
      recommendedFidelity: 'plant',
      description: 'Aggregate plant block modeling, MV substation collection grid, and horizontal tracker backtracking across 160 hectares.',
    },
  ] as const;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="w-full max-w-4xl bg-[#101820] border border-[#34576C]/60 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#34576C]/40 bg-[#172735]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-[#53B6CA]/20 text-[#53B6CA]">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold tracking-wide uppercase text-white font-mono">
                Solar Farm Layout & Simulation Scale Architecture
              </h2>
              <p className="text-xs text-[#94a3b8] font-mono">
                Multi-Scale Digital Twin Hierarchy • 1 kWp to 500 MWp • Model Fidelity Resolution
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#94a3b8] hover:text-white hover:bg-[#101820] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 font-mono text-xs text-[#EDF2F3]">
          {/* Section 1: Model Fidelity Selector */}
          <div className="p-4 bg-[#172735]/30 border border-[#34576C]/40 rounded-lg space-y-2">
            <span className="text-[11px] font-semibold text-[#53B6CA] uppercase tracking-wider block">
              Computational Model Fidelity Level
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {(
                [
                  { id: 'cell', label: 'Cell-Level', sub: 'Single-diode I(V)' },
                  { id: 'module', label: 'Module-Level', sub: '3-Bypass Diodes' },
                  { id: 'string', label: 'String-Level', sub: 'Ohmic & Mismatch' },
                  { id: 'array', label: 'Array-Level', sub: 'Inverter MPPT' },
                  { id: 'plant', label: 'Plant-Level', sub: 'Aggregate Yield' },
                ] as const
              ).map((f) => (
                <button
                  key={f.id}
                  onClick={() => onSelectFidelity(f.id)}
                  className={`p-2.5 rounded border text-left transition-all ${
                    activeFidelity === f.id
                      ? 'bg-[#172735] border-[#53B6CA] text-white shadow-sm'
                      : 'bg-[#101820] border-[#34576C]/30 text-[#94a3b8] hover:text-white'
                  }`}
                >
                  <span className="block font-bold text-xs">{f.label}</span>
                  <span className="text-[10px] text-[#94a3b8]">{f.sub}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Section 2: Farm Scale Selector */}
          <div>
            <span className="text-[11px] font-semibold text-[#53B6CA] uppercase tracking-wider block mb-3">
              Array Footprint & Infrastructure Archetypes
            </span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {farmArchetypes.map((arch) => {
                const isSelected = currentScale === arch.id;
                return (
                  <div
                    key={arch.id}
                    onClick={() => onSelectScale(arch.id)}
                    className={`p-4 rounded-lg border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-[#172735] border-[#53B6CA] ring-1 ring-[#53B6CA] shadow-lg'
                        : 'bg-[#172735]/20 border-[#34576C]/30 hover:border-[#34576C] hover:bg-[#172735]/40'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-bold text-white text-sm">{arch.name}</h3>
                        <span className="text-xs text-[#E9A83B] font-semibold">{arch.scaleLabel}</span>
                      </div>
                      {isSelected ? (
                        <CheckCircle2 className="w-5 h-5 text-[#53B6CA]" />
                      ) : (
                        <div className="w-5 h-5 rounded-full border border-[#34576C]" />
                      )}
                    </div>

                    <p className="text-[11px] text-[#94a3b8] mb-3 leading-relaxed">
                      {arch.description}
                    </p>

                    <div className="grid grid-cols-3 gap-2 p-2 bg-[#101820] rounded border border-[#34576C]/30 text-[10px]">
                      <div>
                        <span className="text-[#94a3b8] block">Modules:</span>
                        <strong className="text-white tabular-nums">{arch.moduleCount.toLocaleString()}</strong>
                      </div>
                      <div>
                        <span className="text-[#94a3b8] block">Capacity:</span>
                        <strong className="text-[#53B6CA] tabular-nums">
                          {arch.dcCapacityKw >= 1000
                            ? `${(arch.dcCapacityKw / 1000).toFixed(1)} MWp`
                            : `${arch.dcCapacityKw} kWp`}
                        </strong>
                      </div>
                      <div>
                        <span className="text-[#94a3b8] block">Land Area:</span>
                        <strong className="text-white tabular-nums">
                          {arch.landAreaM2 >= 10000
                            ? `${(arch.landAreaM2 / 10000).toFixed(1)} ha`
                            : `${arch.landAreaM2} m²`}
                        </strong>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-[#34576C]/40 bg-[#172735] flex justify-between items-center text-xs font-mono">
          <span className="text-[#94a3b8]">
            Active Resolution: <strong className="text-white uppercase">{activeFidelity} Mode</strong>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#53B6CA] hover:bg-[#429cb0] text-[#101820] font-bold rounded transition-colors"
          >
            Apply Configuration
          </button>
        </div>
      </div>
    </div>
  );
}
