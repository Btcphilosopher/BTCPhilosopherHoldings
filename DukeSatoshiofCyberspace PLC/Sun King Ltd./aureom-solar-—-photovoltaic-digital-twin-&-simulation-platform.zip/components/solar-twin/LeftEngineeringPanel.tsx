'use client';

import React, { useState } from 'react';
import {
  Sliders,
  Sun,
  Layers,
  Battery,
  Zap,
  Wind,
  Compass,
  ChevronDown,
  ChevronRight,
  Maximize2,
  Minimize2,
} from 'lucide-react';
import { MODULE_PRESETS, ModuleSpecs } from '@/lib/physics/single-diode';
import { INVERTER_PRESETS, InverterSpecs } from '@/lib/physics/inverter';
import { BATTERY_PRESETS, BatterySpecs, DispatchStrategy } from '@/lib/physics/battery';
import { TrackingMode } from '@/lib/physics/tracking';
import { MountingType } from '@/lib/physics/thermal';

interface LeftEngineeringPanelProps {
  selectedModule: ModuleSpecs;
  onSelectModule: (m: ModuleSpecs) => void;
  modulesCount: number;
  onModulesCountChange: (count: number) => void;
  tiltAngle: number;
  onTiltChange: (val: number) => void;
  azimuthAngle: number;
  onAzimuthChange: (val: number) => void;
  trackingMode: TrackingMode;
  onTrackingModeChange: (mode: TrackingMode) => void;
  enableBacktracking: boolean;
  onToggleBacktracking: (val: boolean) => void;
  mountingType: MountingType;
  onMountingTypeChange: (type: MountingType) => void;
  rowPitchMeters: number;
  onRowPitchChange: (pitch: number) => void;
  clearanceHeightMeters: number;
  onClearanceHeightChange: (h: number) => void;
  selectedInverter: InverterSpecs;
  onSelectInverter: (inv: InverterSpecs) => void;
  selectedBattery: BatterySpecs;
  onSelectBattery: (bat: BatterySpecs) => void;
  batteryDispatch: DispatchStrategy;
  onBatteryDispatchChange: (strategy: DispatchStrategy) => void;
  ambientTempC: number;
  onAmbientTempChange: (temp: number) => void;
  windSpeedMs: number;
  onWindSpeedChange: (ws: number) => void;
  albedo: number;
  onAlbedoChange: (alb: number) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

export function LeftEngineeringPanel({
  selectedModule,
  onSelectModule,
  modulesCount,
  onModulesCountChange,
  tiltAngle,
  onTiltChange,
  azimuthAngle,
  onAzimuthChange,
  trackingMode,
  onTrackingModeChange,
  enableBacktracking,
  onToggleBacktracking,
  mountingType,
  onMountingTypeChange,
  rowPitchMeters,
  onRowPitchChange,
  clearanceHeightMeters,
  onClearanceHeightChange,
  selectedInverter,
  onSelectInverter,
  selectedBattery,
  onSelectBattery,
  batteryDispatch,
  onBatteryDispatchChange,
  ambientTempC,
  onAmbientTempChange,
  windSpeedMs,
  onWindSpeedChange,
  albedo,
  onAlbedoChange,
  isCollapsed,
  onToggleCollapse,
}: LeftEngineeringPanelProps) {
  const [openSections, setOpenSections] = useState({
    module: true,
    array: true,
    inverter: false,
    storage: false,
    environment: false,
  });

  const toggleSection = (key: keyof typeof openSections) => {
    setOpenSections((prev) => ({ ...prev, [key]: !prev [key] }));
  };

  // Calculated DC Array capacity and GCR
  const totalArrayKwp = ((modulesCount * selectedModule.pmpRef) / 1000).toFixed(1);
  const gcr = (selectedModule.lengthMeters / rowPitchMeters).toFixed(2);

  if (isCollapsed) {
    return (
      <div className="w-12 bg-[#101820] border-r border-[#34576C]/30 flex flex-col items-center py-4 gap-4 text-[#94a3b8] z-20">
        <button
          onClick={onToggleCollapse}
          title="Expand Engineering Controls"
          className="p-2 hover:text-[#53B6CA] hover:bg-[#172735] rounded transition-colors"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
        <span className="text-[10px] font-mono tracking-widest uppercase rotate-90 my-8 text-[#53B6CA]">
          PARAMETERS
        </span>
      </div>
    );
  }

  return (
    <aside className="w-80 md:w-88 h-full bg-[#101820] border-r border-[#34576C]/30 flex flex-col overflow-y-auto z-20 select-none">
      {/* Panel Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-[#34576C]/30 bg-[#172735]/40">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-[#53B6CA]" />
          <span className="text-xs font-semibold text-white tracking-wide uppercase font-mono">
            ARRAY & EQUIPMENT PARAMETERS
          </span>
        </div>
        <button
          onClick={onToggleCollapse}
          title="Collapse Panel"
          className="text-[#94a3b8] hover:text-white p-1 rounded"
        >
          <Minimize2 className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="flex-1 p-3 space-y-3 font-mono text-xs text-[#EDF2F3]">
        {/* SECTION 1: PHOTOVOLTAIC MODULE */}
        <div className="border border-[#34576C]/30 rounded bg-[#172735]/20 overflow-hidden">
          <button
            onClick={() => toggleSection('module')}
            className="w-full flex items-center justify-between px-3 py-2 bg-[#172735]/60 hover:bg-[#172735] text-left transition-colors font-medium text-[11px] uppercase tracking-wider text-[#53B6CA]"
          >
            <div className="flex items-center gap-2">
              <Sun className="w-3.5 h-3.5 text-[#E9A83B]" />
              <span>01. Module Technology</span>
            </div>
            {openSections.module ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>

          {openSections.module && (
            <div className="p-3 space-y-2.5">
              <div>
                <label className="text-[11px] text-[#94a3b8] block mb-1">Module Preset:</label>
                <select
                  value={selectedModule.id}
                  onChange={(e) => {
                    const m = MODULE_PRESETS[e.target.value];
                    if (m) onSelectModule(m);
                  }}
                  className="w-full bg-[#101820] text-xs text-white px-2 py-1.5 rounded border border-[#34576C]/60 focus:outline-none focus:border-[#53B6CA]"
                >
                  {Object.values(MODULE_PRESETS).map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.pmpRef}W, {m.efficiencyRef}%)
                    </option>
                  ))}
                </select>
              </div>

              {/* Module Specs Grid */}
              <div className="grid grid-cols-2 gap-2 p-2 bg-[#101820] rounded border border-[#34576C]/30 text-[11px]">
                <div>
                  <span className="text-[#94a3b8]">STC Power:</span>{' '}
                  <strong className="text-white tabular-nums">{selectedModule.pmpRef} W</strong>
                </div>
                <div>
                  <span className="text-[#94a3b8]">Efficiency:</span>{' '}
                  <strong className="text-[#53B6CA] tabular-nums">{selectedModule.efficiencyRef}%</strong>
                </div>
                <div>
                  <span className="text-[#94a3b8]">Vmp / Imp:</span>{' '}
                  <strong className="text-white tabular-nums">{selectedModule.vmpRef}V / {selectedModule.impRef}A</strong>
                </div>
                <div>
                  <span className="text-[#94a3b8]">Voc / Isc:</span>{' '}
                  <strong className="text-white tabular-nums">{selectedModule.vocRef}V / {selectedModule.iscRef}A</strong>
                </div>
                <div>
                  <span className="text-[#94a3b8]">γ (Pmp coeff):</span>{' '}
                  <strong className="text-[#E9A83B] tabular-nums">{selectedModule.gammaPmp}%/°C</strong>
                </div>
                <div>
                  <span className="text-[#94a3b8]">Bifaciality:</span>{' '}
                  <strong className="text-[#53B6CA] tabular-nums">
                    {selectedModule.bifacialityFactor > 0 ? `${(selectedModule.bifacialityFactor * 100).toFixed(0)}%` : 'Monofacial'}
                  </strong>
                </div>
              </div>

              {/* Module Count */}
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94a3b8]">Number of Modules:</span>
                  <span className="text-[#53B6CA] font-bold tabular-nums">
                    {modulesCount} units ({totalArrayKwp} kWp)
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="1000"
                  step="1"
                  value={modulesCount}
                  onChange={(e) => onModulesCountChange(Number(e.target.value))}
                  className="w-full accent-[#53B6CA] h-1.5 bg-[#172735] rounded cursor-pointer"
                />
              </div>
            </div>
          )}
        </div>

        {/* SECTION 2: ARRAY GEOMETRY & TRACKING */}
        <div className="border border-[#34576C]/30 rounded bg-[#172735]/20 overflow-hidden">
          <button
            onClick={() => toggleSection('array')}
            className="w-full flex items-center justify-between px-3 py-2 bg-[#172735]/60 hover:bg-[#172735] text-left transition-colors font-medium text-[11px] uppercase tracking-wider text-[#53B6CA]"
          >
            <div className="flex items-center gap-2">
              <Layers className="w-3.5 h-3.5 text-[#53B6CA]" />
              <span>02. Array & Tracking</span>
            </div>
            {openSections.array ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>

          {openSections.array && (
            <div className="p-3 space-y-2.5">
              {/* Tracking Mode */}
              <div>
                <label className="text-[11px] text-[#94a3b8] block mb-1">Racking & Tracking System:</label>
                <div className="grid grid-cols-3 gap-1">
                  {(
                    [
                      { id: 'fixed', label: 'Fixed Tilt' },
                      { id: 'single_axis', label: '1-Axis SAT' },
                      { id: 'dual_axis', label: '2-Axis' },
                    ] as const
                  ).map((t) => (
                    <button
                      key={t.id}
                      onClick={() => onTrackingModeChange(t.id)}
                      className={`px-2 py-1.5 rounded text-[11px] font-medium transition-colors ${
                        trackingMode === t.id
                          ? 'bg-[#34576C] text-white border border-[#53B6CA]'
                          : 'bg-[#101820] text-[#94a3b8] hover:text-white border border-[#34576C]/40'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Backtracking Toggle for SAT */}
              {trackingMode === 'single_axis' && (
                <div className="flex items-center justify-between p-2 bg-[#101820] rounded border border-[#34576C]/30 text-[11px]">
                  <div>
                    <span className="text-white block font-medium">Astronomical Backtracking</span>
                    <span className="text-[10px] text-[#94a3b8]">Passias-Källbäck shadow elimination</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={enableBacktracking}
                    onChange={(e) => onToggleBacktracking(e.target.checked)}
                    className="accent-[#53B6CA] w-4 h-4 cursor-pointer"
                  />
                </div>
              )}

              {/* Tilt Angle (for fixed mode) */}
              {trackingMode === 'fixed' && (
                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-[#94a3b8]">Panel Tilt Angle:</span>
                    <span className="text-white font-bold tabular-nums">{tiltAngle}°</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="65"
                    step="1"
                    value={tiltAngle}
                    onChange={(e) => onTiltChange(Number(e.target.value))}
                    className="w-full accent-[#53B6CA] h-1.5 bg-[#172735] rounded cursor-pointer"
                  />
                </div>
              )}

              {/* Azimuth Angle (for fixed mode) */}
              {trackingMode === 'fixed' && (
                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-[#94a3b8]">Panel Azimuth:</span>
                    <span className="text-white font-bold tabular-nums">
                      {azimuthAngle}° ({azimuthAngle === 180 ? 'Due South' : azimuthAngle === 90 ? 'East' : 'West'})
                    </span>
                  </div>
                  <input
                    type="range"
                    min="90"
                    max="270"
                    step="5"
                    value={azimuthAngle}
                    onChange={(e) => onAzimuthChange(Number(e.target.value))}
                    className="w-full accent-[#53B6CA] h-1.5 bg-[#172735] rounded cursor-pointer"
                  />
                </div>
              )}

              {/* Row Pitch & GCR */}
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94a3b8]">Row Pitch Spacing:</span>
                  <span className="text-[#53B6CA] font-bold tabular-nums">
                    {rowPitchMeters} m (GCR: {gcr})
                  </span>
                </div>
                <input
                  type="range"
                  min="3.5"
                  max="12.0"
                  step="0.5"
                  value={rowPitchMeters}
                  onChange={(e) => onRowPitchChange(Number(e.target.value))}
                  className="w-full accent-[#53B6CA] h-1.5 bg-[#172735] rounded cursor-pointer"
                />
              </div>

              {/* Ground Clearance Height (H) */}
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94a3b8]">Ground Clearance (H):</span>
                  <span className="text-white font-bold tabular-nums">{clearanceHeightMeters} m</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="3.0"
                  step="0.1"
                  value={clearanceHeightMeters}
                  onChange={(e) => onClearanceHeightChange(Number(e.target.value))}
                  className="w-full accent-[#53B6CA] h-1.5 bg-[#172735] rounded cursor-pointer"
                />
              </div>
            </div>
          )}
        </div>

        {/* SECTION 3: INVERTER ARCHITECTURE */}
        <div className="border border-[#34576C]/30 rounded bg-[#172735]/20 overflow-hidden">
          <button
            onClick={() => toggleSection('inverter')}
            className="w-full flex items-center justify-between px-3 py-2 bg-[#172735]/60 hover:bg-[#172735] text-left transition-colors font-medium text-[11px] uppercase tracking-wider text-[#53B6CA]"
          >
            <div className="flex items-center gap-2">
              <Zap className="w-3.5 h-3.5 text-[#E9A83B]" />
              <span>03. Inverter & BOS</span>
            </div>
            {openSections.inverter ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>

          {openSections.inverter && (
            <div className="p-3 space-y-2.5">
              <div>
                <label className="text-[11px] text-[#94a3b8] block mb-1">Inverter Specification:</label>
                <select
                  value={selectedInverter.id}
                  onChange={(e) => {
                    const inv = INVERTER_PRESETS[e.target.value];
                    if (inv) onSelectInverter(inv);
                  }}
                  className="w-full bg-[#101820] text-xs text-white px-2 py-1.5 rounded border border-[#34576C]/60 focus:outline-none focus:border-[#53B6CA]"
                >
                  {Object.values(INVERTER_PRESETS).map((inv) => (
                    <option key={inv.id} value={inv.id}>
                      {inv.name} ({(inv.pacMaxWatts / 1000).toFixed(0)} kW AC)
                    </option>
                  ))}
                </select>
              </div>

              <div className="p-2 bg-[#101820] rounded border border-[#34576C]/30 text-[11px] space-y-1">
                <div className="flex justify-between">
                  <span className="text-[#94a3b8]">Max AC Power:</span>
                  <span className="text-white font-bold tabular-nums">{(selectedInverter.pacMaxWatts / 1000).toFixed(0)} kW</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#94a3b8]">MPPT Window:</span>
                  <span className="text-white font-bold tabular-nums">{selectedInverter.vmpptMinVolts}V – {selectedInverter.vmpptMaxVolts}V</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#94a3b8]">Max Permissible DC Voc:</span>
                  <span className="text-[#E9A83B] font-bold tabular-nums">{selectedInverter.vdcAbsoluteMaxVolts}V</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#94a3b8]">Euro Efficiency:</span>
                  <span className="text-[#53B6CA] font-bold tabular-nums">{selectedInverter.efficiencyEuroPercent}%</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* SECTION 4: BATTERY ENERGY STORAGE (BESS) */}
        <div className="border border-[#34576C]/30 rounded bg-[#172735]/20 overflow-hidden">
          <button
            onClick={() => toggleSection('storage')}
            className="w-full flex items-center justify-between px-3 py-2 bg-[#172735]/60 hover:bg-[#172735] text-left transition-colors font-medium text-[11px] uppercase tracking-wider text-[#53B6CA]"
          >
            <div className="flex items-center gap-2">
              <Battery className="w-3.5 h-3.5 text-[#53B6CA]" />
              <span>04. Battery Energy Storage</span>
            </div>
            {openSections.storage ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>

          {openSections.storage && (
            <div className="p-3 space-y-2.5">
              <div>
                <label className="text-[11px] text-[#94a3b8] block mb-1">BESS Unit:</label>
                <select
                  value={selectedBattery.id}
                  onChange={(e) => {
                    const bat = BATTERY_PRESETS[e.target.value];
                    if (bat) onSelectBattery(bat);
                  }}
                  className="w-full bg-[#101820] text-xs text-white px-2 py-1.5 rounded border border-[#34576C]/60 focus:outline-none focus:border-[#53B6CA]"
                >
                  {Object.values(BATTERY_PRESETS).map((bat) => (
                    <option key={bat.id} value={bat.id}>
                      {bat.name} ({bat.capacityKwh} kWh, {bat.chemistry})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] text-[#94a3b8] block mb-1">Dispatch Strategy:</label>
                <select
                  value={batteryDispatch}
                  onChange={(e) => onBatteryDispatchChange(e.target.value as any)}
                  className="w-full bg-[#101820] text-xs text-white px-2 py-1.5 rounded border border-[#34576C]/60 focus:outline-none focus:border-[#53B6CA]"
                >
                  <option value="self_consumption">Self-Consumption Maximization</option>
                  <option value="peak_shaving">Peak Shaving Demand Cut</option>
                  <option value="tou_arbitrage">Time-of-Use Arbitrage</option>
                  <option value="backup_reserve">Emergency Backup Reserve (50% min)</option>
                </select>
              </div>

              <div className="p-2 bg-[#101820] rounded border border-[#34576C]/30 text-[11px] space-y-1">
                <div className="flex justify-between">
                  <span className="text-[#94a3b8]">Usable SOC Range:</span>
                  <span className="text-white font-bold tabular-nums">{selectedBattery.usableMinSoc}% – {selectedBattery.usableMaxSoc}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#94a3b8]">Round-Trip Efficiency:</span>
                  <span className="text-[#53B6CA] font-bold tabular-nums">{selectedBattery.roundTripEfficiencyPercent}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#94a3b8]">Cycle Life to 80%:</span>
                  <span className="text-white font-bold tabular-nums">{selectedBattery.cycleLifeTo80Percent} cycles</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* SECTION 5: ENVIRONMENTAL PARAMETERS */}
        <div className="border border-[#34576C]/30 rounded bg-[#172735]/20 overflow-hidden">
          <button
            onClick={() => toggleSection('environment')}
            className="w-full flex items-center justify-between px-3 py-2 bg-[#172735]/60 hover:bg-[#172735] text-left transition-colors font-medium text-[11px] uppercase tracking-wider text-[#53B6CA]"
          >
            <div className="flex items-center gap-2">
              <Wind className="w-3.5 h-3.5 text-[#53B6CA]" />
              <span>05. Environmental Conditions</span>
            </div>
            {openSections.environment ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>

          {openSections.environment && (
            <div className="p-3 space-y-2.5">
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94a3b8]">Ambient Temperature (Ta):</span>
                  <span className="text-white font-bold tabular-nums">{ambientTempC}°C</span>
                </div>
                <input
                  type="range"
                  min="-10"
                  max="50"
                  step="1"
                  value={ambientTempC}
                  onChange={(e) => onAmbientTempChange(Number(e.target.value))}
                  className="w-full accent-[#53B6CA] h-1.5 bg-[#172735] rounded cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94a3b8]">Wind Speed (v_wind):</span>
                  <span className="text-white font-bold tabular-nums">{windSpeedMs} m/s</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="15"
                  step="0.5"
                  value={windSpeedMs}
                  onChange={(e) => onWindSpeedChange(Number(e.target.value))}
                  className="w-full accent-[#53B6CA] h-1.5 bg-[#172735] rounded cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94a3b8]">Ground Albedo (ρ):</span>
                  <span className="text-[#53B6CA] font-bold tabular-nums">{albedo.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0.10"
                  max="0.85"
                  step="0.05"
                  value={albedo}
                  onChange={(e) => onAlbedoChange(Number(e.target.value))}
                  className="w-full accent-[#53B6CA] h-1.5 bg-[#172735] rounded cursor-pointer"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}
