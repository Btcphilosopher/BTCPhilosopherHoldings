'use client';

import React from 'react';
import { X, FileText, Download, Printer, CheckCircle2, ShieldCheck, Share2 } from 'lucide-react';
import { ModuleSpecs } from '@/lib/physics/single-diode';
import { InverterSpecs } from '@/lib/physics/inverter';
import { BatterySpecs } from '@/lib/physics/battery';
import { LocationPreset } from '@/components/solar-twin/TelemetryRibbon';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  location: LocationPreset;
  moduleSpecs: ModuleSpecs;
  modulesCount: number;
  inverterSpecs: InverterSpecs;
  batterySpecs: BatterySpecs;
  trackingMode: string;
  tiltAngle: number;
  azimuthAngle: number;
  performanceRatioPercent: number;
  dailyYieldKwh: number;
}

export function ReportModal({
  isOpen,
  onClose,
  location,
  moduleSpecs,
  modulesCount,
  inverterSpecs,
  batterySpecs,
  trackingMode,
  tiltAngle,
  azimuthAngle,
  performanceRatioPercent,
  dailyYieldKwh,
}: ReportModalProps) {
  if (!isOpen) return null;

  const totalDcCapacityKw = ((modulesCount * moduleSpecs.pmpRef) / 1000).toFixed(1);
  const estimatedAnnualYieldMwh = ((Number(totalDcCapacityKw) * 1750 * (trackingMode === 'single_axis' ? 1.22 : 1.0)) / 1000).toFixed(0);

  // Export JSON Report
  const handleExportJson = () => {
    const reportData = {
      standard: 'IEC 61724-1 Photovoltaic System Performance Monitoring',
      brand: 'Aureom.AI',
      product: 'AUREOM SOLAR Digital Twin',
      reportId: `AUREOM-RPT-${Date.now().toString(36).toUpperCase()}`,
      generatedAt: new Date().toISOString(),
      site: {
        name: location.name,
        latitude: location.latitude,
        longitude: location.longitude,
        elevationMeters: location.elevation,
        albedo: location.albedo,
      },
      array: {
        totalModules: modulesCount,
        dcCapacityKwp: Number(totalDcCapacityKw),
        trackingMode,
        tiltAngleDeg: tiltAngle,
        azimuthAngleDeg: azimuthAngle,
      },
      module: {
        model: moduleSpecs.name,
        technology: moduleSpecs.technology,
        ratedPmpWatts: moduleSpecs.pmpRef,
        efficiencyPercent: moduleSpecs.efficiencyRef,
        vocVolts: moduleSpecs.vocRef,
        iscAmps: moduleSpecs.iscRef,
        tempCoeffPmpPercentPerC: moduleSpecs.gammaPmp,
      },
      inverter: {
        model: inverterSpecs.name,
        type: inverterSpecs.type,
        ratedPacKw: inverterSpecs.pacMaxWatts / 1000,
        euroEfficiencyPercent: inverterSpecs.efficiencyEuroPercent,
      },
      battery: {
        model: batterySpecs.name,
        capacityKwh: batterySpecs.capacityKwh,
        chemistry: batterySpecs.chemistry,
      },
      annualMetrics: {
        estimatedYieldMwh: Number(estimatedAnnualYieldMwh),
        performanceRatioPercent,
        todayYieldKwh: dailyYieldKwh,
      },
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Aureom_Solar_Report_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Export CSV Summary
  const handleExportCsv = () => {
    const csvContent =
      'Parameter,Value,Unit\n' +
      `Project,Aureom Solar Digital Twin Simulation,-\n` +
      `Site,${location.name},-\n` +
      `Latitude,${location.latitude},deg\n` +
      `Longitude,${location.longitude},deg\n` +
      `DC Capacity,${totalDcCapacityKw},kWp\n` +
      `Modules Count,${modulesCount},units\n` +
      `Module Technology,${moduleSpecs.name},-\n` +
      `Inverter,${inverterSpecs.name},-\n` +
      `BESS Capacity,${batterySpecs.capacityKwh},kWh\n` +
      `Estimated Annual Yield,${estimatedAnnualYieldMwh},MWh\n` +
      `Performance Ratio,${performanceRatioPercent},%\n`;

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Aureom_Solar_Metrics_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Print Report Handler
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="w-full max-w-4xl bg-[#101820] border border-[#34576C]/60 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#34576C]/40 bg-[#172735]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-[#53B6CA]/20 text-[#53B6CA]">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold tracking-wide uppercase text-white font-mono">
                IEC 61724 Engineering Audit & Performance Report
              </h2>
              <p className="text-xs text-[#94a3b8] font-mono">
                Project Verification • Equipment Datasheets • Energy Balance
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCsv}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#101820] hover:bg-[#172735] text-xs font-mono text-white rounded border border-[#34576C]/50 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-[#53B6CA]" />
              <span>CSV</span>
            </button>
            <button
              onClick={handleExportJson}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#101820] hover:bg-[#172735] text-xs font-mono text-white rounded border border-[#34576C]/50 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-[#E9A83B]" />
              <span>JSON</span>
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#53B6CA] hover:bg-[#429cb0] text-xs font-mono text-[#101820] font-bold rounded transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-[#94a3b8] hover:text-white hover:bg-[#101820] transition-colors ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Report Document Body */}
        <div className="flex-1 overflow-y-auto p-8 font-mono text-xs text-[#EDF2F3] space-y-6 bg-[#0c141c]">
          {/* Document Header Lockup */}
          <div className="flex justify-between items-start border-b border-[#34576C]/50 pb-4">
            <div>
              <span className="text-lg font-bold tracking-tight text-white block">
                AUREOM SOLAR DIGITAL TWIN REPORT
              </span>
              <span className="text-xs text-[#53B6CA] block">
                Standard Compliance: IEC 61724-1 Class A Utility Specification
              </span>
              <span className="text-[11px] text-[#94a3b8] block mt-1">
                Document Ref: AUREOM-ENG-2026-X89 • Generated: {new Date().toUTCString()}
              </span>
            </div>
            <div className="text-right">
              <span className="text-xs font-bold text-[#E9A83B] bg-[#172735] px-2.5 py-1 rounded border border-[#E9A83B]/40 inline-block">
                CERTIFIED PHYSICAL TWIN
              </span>
              <span className="text-[10px] text-[#94a3b8] block mt-1">Aureom.AI Engineering Platform</span>
            </div>
          </div>

          {/* Section 1: Project Metadata & Geographical Site */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#53B6CA] border-b border-[#34576C]/30 pb-1">
              01. Site Geography & Solar Resource
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 bg-[#101820] rounded border border-[#34576C]/40 text-[11px]">
              <div>
                <span className="text-[#94a3b8] block">Installation Site:</span>
                <strong className="text-white">{location.name}</strong>
              </div>
              <div>
                <span className="text-[#94a3b8] block">Coordinates:</span>
                <strong className="text-white tabular-nums">
                  {location.latitude}°N, {location.longitude}°E
                </strong>
              </div>
              <div>
                <span className="text-[#94a3b8] block">Site Elevation:</span>
                <strong className="text-white tabular-nums">{location.elevation} m MSL</strong>
              </div>
              <div>
                <span className="text-[#94a3b8] block">Ground Albedo:</span>
                <strong className="text-[#53B6CA] tabular-nums">{location.albedo} (Reflectance)</strong>
              </div>
            </div>
          </div>

          {/* Section 2: Equipment & Electrical Specifications */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#53B6CA] border-b border-[#34576C]/30 pb-1">
              02. Equipment & Racking Topology
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 bg-[#101820] rounded border border-[#34576C]/40 text-[11px]">
              <div>
                <span className="text-[#94a3b8] block">PV Module:</span>
                <strong className="text-white">{moduleSpecs.name}</strong>
              </div>
              <div>
                <span className="text-[#94a3b8] block">Array DC Capacity:</span>
                <strong className="text-[#E9A83B] tabular-nums">{totalDcCapacityKw} kWp ({modulesCount} modules)</strong>
              </div>
              <div>
                <span className="text-[#94a3b8] block">Tracking Architecture:</span>
                <strong className="text-white uppercase">{trackingMode.replace('_', ' ')}</strong>
              </div>
              <div>
                <span className="text-[#94a3b8] block">Inverter Platform:</span>
                <strong className="text-white">{inverterSpecs.name}</strong>
              </div>
              <div>
                <span className="text-[#94a3b8] block">BESS Storage:</span>
                <strong className="text-[#53B6CA]">{batterySpecs.name}</strong>
              </div>
              <div>
                <span className="text-[#94a3b8] block">STC Efficiency:</span>
                <strong className="text-white tabular-nums">{moduleSpecs.efficiencyRef}%</strong>
              </div>
              <div>
                <span className="text-[#94a3b8] block">Thermal Coeff γ(Pmp):</span>
                <strong className="text-white tabular-nums">{moduleSpecs.gammaPmp}% / °C</strong>
              </div>
              <div>
                <span className="text-[#94a3b8] block">Bifacial Factor:</span>
                <strong className="text-white tabular-nums">
                  {moduleSpecs.bifacialityFactor > 0 ? `${(moduleSpecs.bifacialityFactor * 100).toFixed(0)}%` : 'None'}
                </strong>
              </div>
            </div>
          </div>

          {/* Section 3: Performance Ratios & Annual Yield Budget */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#53B6CA] border-b border-[#34576C]/30 pb-1">
              03. Performance Metrics & IEC 61724 Verification
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-[#101820] rounded border border-[#34576C]/40 text-center">
                <span className="text-[10px] text-[#94a3b8] block uppercase">Estimated Annual Yield</span>
                <span className="text-2xl font-bold text-white tabular-nums">
                  {Number(estimatedAnnualYieldMwh).toLocaleString()}
                </span>
                <span className="text-xs text-[#94a3b8] block">MWh / Year</span>
              </div>
              <div className="p-3 bg-[#101820] rounded border border-[#34576C]/40 text-center">
                <span className="text-[10px] text-[#94a3b8] block uppercase">Performance Ratio (PR)</span>
                <span className="text-2xl font-bold text-[#53B6CA] tabular-nums">
                  {performanceRatioPercent.toFixed(1)}%
                </span>
                <span className="text-xs text-[#94a3b8] block">IEC Class A Benchmark</span>
              </div>
              <div className="p-3 bg-[#101820] rounded border border-[#34576C]/40 text-center">
                <span className="text-[10px] text-[#94a3b8] block uppercase">Specific Annual Yield</span>
                <span className="text-2xl font-bold text-[#E9A83B] tabular-nums">
                  {(Number(estimatedAnnualYieldMwh) * 1000 / Number(totalDcCapacityKw)).toFixed(0)}
                </span>
                <span className="text-xs text-[#94a3b8] block">kWh / kWp / Year</span>
              </div>
            </div>
          </div>

          {/* Section 4: Model Limits & Disclaimers */}
          <div className="p-3 bg-[#101820] rounded border border-[#34576C]/30 text-[10px] text-[#94a3b8] space-y-1">
            <span className="font-bold text-white block">SCIENTIFIC MODEL CONSTRAINTS & AUDIT LIMITATIONS:</span>
            <p>
              Simulations employ the 5-parameter single-diode formulation (De Soto et al.) with Newton-Raphson root finding, Hay-Davies diffuse sky transposition, Faiman convective/radiative thermal equations, and Passias-Källbäck astronomical backtracking. Measured meteorological data must be corroborated with localized pyranometer sensors for final EPC bankability sign-off.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
