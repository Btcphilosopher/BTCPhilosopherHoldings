'use client';

import React from 'react';
import { MapPin, Clock, Sun, CloudRain, CheckCircle2, ShieldAlert } from 'lucide-react';
import { SolarPositionResult } from '@/lib/physics/solar-position';

export interface LocationPreset {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  elevation: number;
  albedo: number;
  typicalAmbTempC: number;
}

export const LOCATION_PRESETS: Record<string, LocationPreset> = {
  'atacama': {
    id: 'atacama',
    name: 'Atacama Desert, Chile',
    latitude: -23.86,
    longitude: -69.14,
    elevation: 2300,
    albedo: 0.28,
    typicalAmbTempC: 22,
  },
  'mojave': {
    id: 'mojave',
    name: 'Mojave Desert, California',
    latitude: 34.89,
    longitude: -117.02,
    elevation: 650,
    albedo: 0.25,
    typicalAmbTempC: 32,
  },
  'tabernas': {
    id: 'tabernas',
    name: 'Plataforma Solar de Almería, Spain',
    latitude: 37.09,
    longitude: -2.36,
    elevation: 500,
    albedo: 0.24,
    typicalAmbTempC: 26,
  },
  'bavaria': {
    id: 'bavaria',
    name: 'Bavaria Solar Park, Germany',
    latitude: 48.76,
    longitude: 11.42,
    elevation: 374,
    albedo: 0.20,
    typicalAmbTempC: 18,
  },
};

interface TelemetryRibbonProps {
  selectedLocation: LocationPreset;
  onLocationChange: (loc: LocationPreset) => void;
  solarPos: SolarPositionResult;
  simDate: Date;
  weatherScenario: 'clear' | 'scattered' | 'overcast' | 'desert_extreme' | 'winter_clean';
  onWeatherChange: (scenario: 'clear' | 'scattered' | 'overcast' | 'desert_extreme' | 'winter_clean') => void;
  isEnergyConserved: boolean;
  isClipping: boolean;
}

export function TelemetryRibbon({
  selectedLocation,
  onLocationChange,
  solarPos,
  simDate,
  weatherScenario,
  onWeatherChange,
  isEnergyConserved,
  isClipping,
}: TelemetryRibbonProps) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-2 bg-[#172735] border-b border-[#34576C]/40 text-xs font-mono text-[#EDF2F3] select-none z-20">
      {/* Location Selector */}
      <div className="flex items-center gap-2">
        <MapPin className="w-3.5 h-3.5 text-[#53B6CA]" />
        <span className="text-[#94a3b8]">SITE:</span>
        <select
          value={selectedLocation.id}
          onChange={(e) => {
            const loc = LOCATION_PRESETS[e.target.value];
            if (loc) onLocationChange(loc);
          }}
          className="bg-[#101820] text-xs font-medium text-white px-2 py-0.5 rounded border border-[#34576C]/60 focus:outline-none focus:border-[#53B6CA]"
        >
          {Object.values(LOCATION_PRESETS).map((loc) => (
            <option key={loc.id} value={loc.id}>
              {loc.name} ({loc.latitude > 0 ? `+${loc.latitude}°` : `${loc.latitude}°`}, {loc.elevation}m)
            </option>
          ))}
        </select>
      </div>

      {/* Ephemeris & Time */}
      <div className="flex items-center gap-4 text-[11px] text-[#94a3b8]">
        <div className="flex items-center gap-1.5">
          <Clock className="w-3 h-3 text-[#E9A83B]" />
          <span className="text-white font-medium">
            {simDate.toTimeString().slice(0, 8)} UTC
          </span>
          <span>(Day {Math.floor((simDate.getTime() - new Date(simDate.getFullYear(), 0, 1).getTime()) / 86400000) + 1})</span>
        </div>

        <div className="hidden lg:flex items-center gap-3">
          <span>
            AM: <strong className="text-[#EDF2F3] font-semibold">{solarPos.airMass.toFixed(2)}</strong>
          </span>
          <span>
            DEC: <strong className="text-[#EDF2F3] font-semibold">{solarPos.declination.toFixed(1)}°</strong>
          </span>
          <span>
            EoT: <strong className="text-[#EDF2F3] font-semibold">{solarPos.equationOfTime.toFixed(1)} min</strong>
          </span>
        </div>
      </div>

      {/* Weather Scenario Picker */}
      <div className="flex items-center gap-2">
        <Sun className="w-3.5 h-3.5 text-[#E9A83B]" />
        <span className="text-[#94a3b8]">WEATHER:</span>
        <select
          value={weatherScenario}
          onChange={(e) => onWeatherChange(e.target.value as any)}
          className="bg-[#101820] text-xs font-medium text-white px-2 py-0.5 rounded border border-[#34576C]/60 focus:outline-none focus:border-[#53B6CA]"
        >
          <option value="clear">Clear Sky (Ineichen)</option>
          <option value="scattered">Scattered Clouds (DHI Rich)</option>
          <option value="overcast">Diffuse Overcast</option>
          <option value="desert_extreme">High-DNI Desert Peak</option>
          <option value="winter_clean">Cold Winter Clear (Albedo Boost)</option>
        </select>
      </div>

      {/* System Invariant Status */}
      <div className="flex items-center gap-2">
        {isClipping ? (
          <div className="flex items-center gap-1.5 text-[#E9A83B] text-[11px]">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>INVERTER CLIPPING</span>
          </div>
        ) : isEnergyConserved ? (
          <div className="flex items-center gap-1.5 text-[#53B6CA] text-[11px]">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>ENERGY CONSERVED (100%)</span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-[#D95D57] text-[11px]">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>BALANCE IMBALANCE</span>
          </div>
        )}
      </div>
    </div>
  );
}
