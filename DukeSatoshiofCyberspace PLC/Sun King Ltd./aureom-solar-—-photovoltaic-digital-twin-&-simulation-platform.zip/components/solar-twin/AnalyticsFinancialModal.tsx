'use client';

import React, { useState, useMemo } from 'react';
import { X, DollarSign, TrendingUp, BarChart3, PieChart, ShieldCheck, Download, AlertCircle } from 'lucide-react';
import { calculateProjectFinancials, FinancialAssumptions } from '@/lib/physics/economics';
import { runMonteCarloSimulation } from '@/lib/physics/monte-carlo';
import { calculateLossWaterfall } from '@/lib/physics/loss-tree';

interface AnalyticsFinancialModalProps {
  isOpen: boolean;
  onClose: () => void;
  systemCapacityDcKw: number;
  batteryCapacityKwh: number;
  isTracking: boolean;
  isBifacial: boolean;
  bifacialGainPercent: number;
}

export function AnalyticsFinancialModal({
  isOpen,
  onClose,
  systemCapacityDcKw,
  batteryCapacityKwh,
  isTracking,
  isBifacial,
  bifacialGainPercent,
}: AnalyticsFinancialModalProps) {
  const [discountRate, setDiscountRate] = useState<number>(6.5);
  const [retailTariff, setRetailTariff] = useState<number>(0.22);
  const [exportTariff, setExportTariff] = useState<number>(0.07);
  const [activeTab, setActiveTab] = useState<'financials' | 'monte_carlo' | 'loss_waterfall'>('financials');

  // Baseline energy calculation: ~1,750 kWh/kWp/year in prime solar regions
  const baseAnnualGenerationKwh = Math.round(systemCapacityDcKw * 1750 * (isTracking ? 1.22 : 1.0) * (isBifacial ? 1 + bifacialGainPercent / 100 : 1.0));

  // Compute Financials
  const financials = useMemo(() => {
    return calculateProjectFinancials({
      systemCapacityDcKw,
      annualGenerationYear1Kwh: baseAnnualGenerationKwh,
      batteryCapacityKwh,
      isTracking,
      isBifacial,
      electricityRetailRatePerKwh: retailTariff,
      exportFeedInTariffPerKwh: exportTariff,
      selfConsumptionPercent: 72,
      discountRatePercent: discountRate,
      inflationRatePercent: 2.0,
      projectLifetimeYears: 25,
      moduleDegradationYear1Percent: 1.5,
      annualDegradationPercent: 0.45,
      inverterReplacementYear: 12,
      inverterReplacementCostPerKw: 60,
    });
  }, [systemCapacityDcKw, baseAnnualGenerationKwh, batteryCapacityKwh, isTracking, isBifacial, retailTariff, exportTariff, discountRate]);

  // Compute Monte Carlo
  const monteCarlo = useMemo(() => {
    return runMonteCarloSimulation({
      baseAnnualYieldKwh: baseAnnualGenerationKwh,
      interannualVariabilityPercent: 4.5,
      transpositionModelUncertaintyPercent: 2.5,
      soilingUncertaintyPercent: 1.8,
      measurementCalibrationUncertaintyPercent: 1.2,
      iterations: 2500,
    });
  }, [baseAnnualGenerationKwh]);

  // Compute Loss Waterfall
  const lossWaterfall = useMemo(() => {
    const nominalStcEnergyKwh = systemCapacityDcKw * 2100;
    return calculateLossWaterfall({
      nominalStcEnergyKwh,
      tiltGainPercent: isTracking ? 22.4 : 14.2,
      bifacialGainPercent: isBifacial ? bifacialGainPercent : 0,
      iamReflectionLossPercent: 2.4,
      shadingLossPercent: 1.8,
      soilingLossPercent: 2.2,
      thermalDeratingLossPercent: 6.5,
      lidAndDegradationLossPercent: 1.5,
      dcWiringMismatchLossPercent: 1.2,
      inverterConversionLossPercent: 1.8,
      inverterClippingLossPercent: 0.6,
      acWiringTransformerLossPercent: 1.0,
    });
  }, [systemCapacityDcKw, isTracking, isBifacial, bifacialGainPercent]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="w-full max-w-5xl bg-[#101820] border border-[#34576C]/60 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#34576C]/40 bg-[#172735]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-[#E9A83B]/20 text-[#E9A83B]">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold tracking-wide uppercase text-white font-mono">
                Economics, LCOE & Monte Carlo Risk Analytics
              </h2>
              <p className="text-xs text-[#94a3b8] font-mono">
                IEA/NREL LCOE Formulation • P50/P90 Bankability • 25-Year Cash Flow Projection
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#94a3b8] hover:text-white hover:bg-[#101820] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Strip */}
        <div className="flex items-center gap-2 px-6 pt-3 bg-[#172735]/40 border-b border-[#34576C]/40 text-xs font-mono">
          <button
            onClick={() => setActiveTab('financials')}
            className={`px-4 py-2 border-b-2 font-medium transition-colors ${
              activeTab === 'financials'
                ? 'border-[#53B6CA] text-white font-bold'
                : 'border-transparent text-[#94a3b8] hover:text-white'
            }`}
          >
            LCOE & Financial Model
          </button>
          <button
            onClick={() => setActiveTab('monte_carlo')}
            className={`px-4 py-2 border-b-2 font-medium transition-colors ${
              activeTab === 'monte_carlo'
                ? 'border-[#53B6CA] text-white font-bold'
                : 'border-transparent text-[#94a3b8] hover:text-white'
            }`}
          >
            Monte Carlo Uncertainty (P50/P90)
          </button>
          <button
            onClick={() => setActiveTab('loss_waterfall')}
            className={`px-4 py-2 border-b-2 font-medium transition-colors ${
              activeTab === 'loss_waterfall'
                ? 'border-[#53B6CA] text-white font-bold'
                : 'border-transparent text-[#94a3b8] hover:text-white'
            }`}
          >
            IEC 61724 Loss Waterfall
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 font-mono text-xs text-[#EDF2F3] space-y-6">
          {activeTab === 'financials' && (
            <div className="space-y-6">
              {/* Top KPI Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-[#172735]/40 border border-[#34576C]/40 rounded-lg">
                  <span className="text-[10px] text-[#94a3b8] block uppercase">Levelized Cost of Energy</span>
                  <div className="flex items-baseline">
                    <span className="text-2xl font-bold text-[#53B6CA] tabular-nums">
                      ${financials.lcoeDollarsPerMwh.toFixed(1)}
                    </span>
                    <span className="text-xs text-[#94a3b8] ml-1">/MWh</span>
                  </div>
                  <span className="text-[10px] text-[#94a3b8]">
                    ${(financials.lcoeDollarsPerMwh / 10).toFixed(2)}¢ / kWh
                  </span>
                </div>

                <div className="p-3 bg-[#172735]/40 border border-[#34576C]/40 rounded-lg">
                  <span className="text-[10px] text-[#94a3b8] block uppercase">Internal Rate of Return</span>
                  <div className="flex items-baseline">
                    <span className="text-2xl font-bold text-[#E9A83B] tabular-nums">
                      {financials.irrPercent.toFixed(1)}%
                    </span>
                    <span className="text-xs text-[#94a3b8] ml-1">IRR</span>
                  </div>
                  <span className="text-[10px] text-[#94a3b8]">
                    Discount Rate: {discountRate}%
                  </span>
                </div>

                <div className="p-3 bg-[#172735]/40 border border-[#34576C]/40 rounded-lg">
                  <span className="text-[10px] text-[#94a3b8] block uppercase">Net Present Value (NPV)</span>
                  <div className="flex items-baseline">
                    <span className="text-2xl font-bold text-white tabular-nums">
                      ${(financials.npvDollars / 1000).toLocaleString(undefined, { maximumFractionDigits: 0 })}k
                    </span>
                  </div>
                  <span className="text-[10px] text-[#53B6CA]">
                    Payback: {financials.simplePaybackYears} yrs
                  </span>
                </div>

                <div className="p-3 bg-[#172735]/40 border border-[#34576C]/40 rounded-lg">
                  <span className="text-[10px] text-[#94a3b8] block uppercase">Total CAPEX</span>
                  <div className="flex items-baseline">
                    <span className="text-2xl font-bold text-white tabular-nums">
                      ${(financials.capex.totalCapex / 1000).toLocaleString(undefined, { maximumFractionDigits: 0 })}k
                    </span>
                  </div>
                  <span className="text-[10px] text-[#94a3b8]">
                    ${financials.capex.capexPerWattDc.toFixed(2)} / W_dc
                  </span>
                </div>
              </div>

              {/* CAPEX Cost Breakdown Table */}
              <div className="p-4 bg-[#172735]/20 border border-[#34576C]/40 rounded-lg space-y-3">
                <span className="text-[11px] font-semibold text-[#53B6CA] uppercase tracking-wider block">
                  Capital Expenditure (CAPEX) Itemized Breakdown
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                  <div className="p-2 bg-[#101820] rounded border border-[#34576C]/30">
                    <span className="text-[#94a3b8] block">PV Modules:</span>
                    <strong className="text-white tabular-nums">${financials.capex.modulesCost.toLocaleString()}</strong>
                  </div>
                  <div className="p-2 bg-[#101820] rounded border border-[#34576C]/30">
                    <span className="text-[#94a3b8] block">Inverters & Skid:</span>
                    <strong className="text-white tabular-nums">${financials.capex.invertersCost.toLocaleString()}</strong>
                  </div>
                  <div className="p-2 bg-[#101820] rounded border border-[#34576C]/30">
                    <span className="text-[#94a3b8] block">Racking & Tracking:</span>
                    <strong className="text-white tabular-nums">${financials.capex.rackingCost.toLocaleString()}</strong>
                  </div>
                  <div className="p-2 bg-[#101820] rounded border border-[#34576C]/30">
                    <span className="text-[#94a3b8] block">Electrical BOS & Cables:</span>
                    <strong className="text-white tabular-nums">${financials.capex.electricalBosCost.toLocaleString()}</strong>
                  </div>
                  <div className="p-2 bg-[#101820] rounded border border-[#34576C]/30">
                    <span className="text-[#94a3b8] block">Civil & Mechanical Labor:</span>
                    <strong className="text-white tabular-nums">${financials.capex.civilLaborCost.toLocaleString()}</strong>
                  </div>
                  <div className="p-2 bg-[#101820] rounded border border-[#34576C]/30">
                    <span className="text-[#94a3b8] block">BESS Storage Bank:</span>
                    <strong className="text-white tabular-nums">${financials.capex.batteryStorageCost.toLocaleString()}</strong>
                  </div>
                  <div className="p-2 bg-[#101820] rounded border border-[#34576C]/30">
                    <span className="text-[#94a3b8] block">Interconnection & Permits:</span>
                    <strong className="text-white tabular-nums">${financials.capex.permittingGridTieCost.toLocaleString()}</strong>
                  </div>
                  <div className="p-2 bg-[#101820] rounded border border-[#34576C]/30">
                    <span className="text-[#94a3b8] block">Annual OPEX (Year 1):</span>
                    <strong className="text-[#53B6CA] tabular-nums">${financials.annualOpexYear1.toLocaleString()} / yr</strong>
                  </div>
                </div>
              </div>

              {/* 25-Year Degradation Cash Flow Table (Sample Years 1, 5, 10, 15, 20, 25) */}
              <div className="p-4 bg-[#172735]/20 border border-[#34576C]/40 rounded-lg space-y-2">
                <span className="text-[11px] font-semibold text-[#53B6CA] uppercase tracking-wider block">
                  Asset Lifecycle Cash Flow & Degradation Schedule (0.45%/yr)
                </span>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-[11px]">
                    <thead>
                      <tr className="border-b border-[#34576C]/60 text-[#94a3b8]">
                        <th className="py-1.5 px-2">Year</th>
                        <th className="py-1.5 px-2">Degradation</th>
                        <th className="py-1.5 px-2">Generation</th>
                        <th className="py-1.5 px-2">Gross Revenue</th>
                        <th className="py-1.5 px-2">OPEX & Reserve</th>
                        <th className="py-1.5 px-2">Net Cash Flow</th>
                        <th className="py-1.5 px-2">Cumulative</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#34576C]/20">
                      {financials.cashFlowSchedule
                        .filter((cf) => [1, 2, 5, 10, 12, 15, 20, 25].includes(cf.year))
                        .map((cf) => (
                          <tr key={cf.year} className="hover:bg-[#172735]/40 tabular-nums">
                            <td className="py-1.5 px-2 font-bold text-white">Year {cf.year}</td>
                            <td className="py-1.5 px-2 text-[#94a3b8]">{(cf.degradationFactor * 100).toFixed(1)}%</td>
                            <td className="py-1.5 px-2 text-white">{(cf.annualGenerationKwh / 1000).toFixed(0)} MWh</td>
                            <td className="py-1.5 px-2 text-[#53B6CA]">${cf.grossRevenueSavings.toLocaleString()}</td>
                            <td className="py-1.5 px-2 text-[#94a3b8]">
                              ${(cf.opexCost + cf.inverterReplacementCost).toLocaleString()}
                              {cf.inverterReplacementCost > 0 && ' (Inv Rep)'}
                            </td>
                            <td className="py-1.5 px-2 font-bold text-white">${cf.netCashFlow.toLocaleString()}</td>
                            <td
                              className={`py-1.5 px-2 font-bold ${
                                cf.cumulativeCashFlow >= 0 ? 'text-[#53B6CA]' : 'text-[#D95D57]'
                              }`}
                            >
                              ${cf.cumulativeCashFlow.toLocaleString()}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'monte_carlo' && (
            <div className="space-y-6">
              <div className="p-4 bg-[#172735]/40 border border-[#34576C]/40 rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="font-bold text-white text-sm">Monte Carlo Solar Yield Risk Assessment</h3>
                    <p className="text-[#94a3b8] text-[11px]">
                      2,500 synthetic iterations combining GHI interannual variability, transposition model error, and soiling
                    </p>
                  </div>
                  <div className="px-2.5 py-1 bg-[#101820] border border-[#34576C]/60 rounded text-[#53B6CA] text-[11px]">
                    Composite Uncertainty: <strong>±{monteCarlo.compositeUncertaintyPercent}%</strong> (1σ)
                  </div>
                </div>

                {/* Exceedance Probabilities Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
                  <div className="p-3 bg-[#101820] rounded border border-[#34576C]/40">
                    <span className="text-[10px] text-[#94a3b8] block uppercase">P50 (Median Expected)</span>
                    <span className="text-xl font-bold text-white tabular-nums">
                      {(monteCarlo.p50YieldKwh / 1000).toFixed(0)} MWh
                    </span>
                    <span className="text-[10px] text-[#53B6CA] block">50% Exceedance Prob.</span>
                  </div>

                  <div className="p-3 bg-[#101820] rounded border border-[#34576C]/40">
                    <span className="text-[10px] text-[#94a3b8] block uppercase">P75 (Moderate Risk)</span>
                    <span className="text-xl font-bold text-[#53B6CA] tabular-nums">
                      {(monteCarlo.p75YieldKwh / 1000).toFixed(0)} MWh
                    </span>
                    <span className="text-[10px] text-[#94a3b8] block">75% Exceedance Prob.</span>
                  </div>

                  <div className="p-3 bg-[#101820] rounded border border-[#34576C]/40">
                    <span className="text-[10px] text-[#94a3b8] block uppercase">P90 (Bankability Base)</span>
                    <span className="text-xl font-bold text-[#E9A83B] tabular-nums">
                      {(monteCarlo.p90YieldKwh / 1000).toFixed(0)} MWh
                    </span>
                    <span className="text-[10px] text-[#E9A83B] block">P90/P50: {monteCarlo.p90ToP50Ratio}</span>
                  </div>

                  <div className="p-3 bg-[#101820] rounded border border-[#34576C]/40">
                    <span className="text-[10px] text-[#94a3b8] block uppercase">P99 (Extreme Downside)</span>
                    <span className="text-xl font-bold text-[#D95D57] tabular-nums">
                      {(monteCarlo.p99YieldKwh / 1000).toFixed(0)} MWh
                    </span>
                    <span className="text-[10px] text-[#D95D57] block">99% Exceedance Prob.</span>
                  </div>
                </div>

                {/* Probability Distribution SVG */}
                <div className="p-3 bg-[#101820] rounded border border-[#34576C]/40">
                  <span className="text-[10px] text-[#94a3b8] block uppercase mb-2">
                    Gaussian Probability Density Function & Exceedance Profile
                  </span>
                  <div className="h-44 flex items-end gap-1 pt-6 px-4">
                    {monteCarlo.distribution.map((d, idx) => (
                      <div
                        key={idx}
                        className="flex-1 flex flex-col items-center group relative h-full justify-end"
                      >
                        <div
                          className={`w-full rounded-t transition-all ${
                            d.yieldKwh < monteCarlo.p90YieldKwh
                              ? 'bg-[#D95D57]/60 group-hover:bg-[#D95D57]'
                              : d.yieldKwh < monteCarlo.p50YieldKwh
                              ? 'bg-[#E9A83B]/70 group-hover:bg-[#E9A83B]'
                              : 'bg-[#53B6CA]/70 group-hover:bg-[#53B6CA]'
                          }`}
                          style={{ height: `${Math.max(4, d.probabilityDensity * 4)}%` }}
                        />
                        {/* Tooltip */}
                        <div className="absolute bottom-full mb-1 hidden group-hover:block z-20 px-2 py-1 bg-[#101820] text-white text-[9px] rounded border border-[#34576C] whitespace-nowrap shadow-md pointer-events-none">
                          {(d.yieldKwh / 1000).toFixed(0)} MWh • Exceedance: {(d.exceedanceProbability * 100).toFixed(1)}%
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-between text-[10px] text-[#94a3b8] mt-2 pt-2 border-t border-[#34576C]/40">
                    <span className="text-[#D95D57]">P99 Downside</span>
                    <span className="text-[#E9A83B]">P90 Financing Base</span>
                    <span className="text-[#53B6CA]">P50 Median</span>
                    <span>Upside (1σ)</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'loss_waterfall' && (
            <div className="space-y-6">
              <div className="p-4 bg-[#172735]/40 border border-[#34576C]/40 rounded-lg">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-bold text-white text-sm">IEC 61724 Energy Derating Waterfall</h3>
                    <p className="text-[#94a3b8] text-[11px]">
                      From Theoretical STC Potential to Net AC Electricity Injection
                    </p>
                  </div>
                  <div className="px-3 py-1 bg-[#101820] border border-[#53B6CA]/50 rounded text-right">
                    <span className="text-[10px] text-[#94a3b8] block">PERFORMANCE RATIO</span>
                    <span className="text-base font-bold text-[#53B6CA] tabular-nums">
                      {lossWaterfall.performanceRatioPercent}% PR
                    </span>
                  </div>
                </div>

                {/* Waterfall Steps */}
                <div className="space-y-2">
                  {lossWaterfall.steps.map((st) => (
                    <div
                      key={st.id}
                      className="p-2.5 bg-[#101820] rounded border border-[#34576C]/30 flex items-center justify-between text-[11px]"
                    >
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-2.5 h-2.5 rounded-full ${
                            st.id === 'stc_nominal'
                              ? 'bg-white'
                              : st.isGain
                              ? 'bg-[#53B6CA]'
                              : 'bg-[#D95D57]'
                          }`}
                        />
                        <span className="font-semibold text-white">{st.name}</span>
                      </div>

                      <div className="flex items-center gap-6">
                        {st.id !== 'stc_nominal' && (
                          <span
                            className={`font-mono tabular-nums ${
                              st.isGain ? 'text-[#53B6CA]' : 'text-[#D95D57]'
                            }`}
                          >
                            {st.isGain ? `+${st.percentageOfNominal}%` : `${st.percentageOfNominal}%`}
                          </span>
                        )}
                        <span className="text-white font-bold tabular-nums min-w-24 text-right">
                          {(st.energyKwh / 1000).toLocaleString(undefined, { maximumFractionDigits: 0 })} MWh
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
