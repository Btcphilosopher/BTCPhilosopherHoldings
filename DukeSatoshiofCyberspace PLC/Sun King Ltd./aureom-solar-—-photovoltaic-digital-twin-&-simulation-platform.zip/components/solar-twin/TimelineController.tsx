'use client';

import React, { useState } from 'react';
import {
  Play,
  Pause,
  SkipForward,
  RotateCcw,
  Sun,
  Moon,
  Calendar,
  FastForward,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface TimelineControllerProps {
  currentSimDate: Date;
  onTimeChange: (newDate: Date) => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
  playbackSpeed: number;
  onSpeedChange: (speed: number) => void;
  solarElevation: number;
  isDaylight: boolean;
}

export function TimelineController({
  currentSimDate,
  onTimeChange,
  isPlaying,
  onTogglePlay,
  playbackSpeed,
  onSpeedChange,
  solarElevation,
  isDaylight,
}: TimelineControllerProps) {
  const [isDockCollapsed, setIsDockCollapsed] = useState(false);

  // Time calculations
  const hours = currentSimDate.getUTCHours();
  const minutes = currentSimDate.getUTCMinutes();
  const currentFractionalHour = hours + minutes / 60;

  // Handler for scrubbing the 24-hour slider
  const handleHourSliderChange = (newHourFraction: number) => {
    const updated = new Date(currentSimDate);
    const newHours = Math.floor(newHourFraction);
    const newMins = Math.floor((newHourFraction - newHours) * 60);
    updated.setUTCHours(newHours, newMins, 0, 0);
    onTimeChange(updated);
  };

  // Step 15 minutes forward
  const stepForward = () => {
    const updated = new Date(currentSimDate.getTime() + 15 * 60 * 1000);
    onTimeChange(updated);
  };

  // Seasonal presets
  const applySeasonPreset = (month: number, day: number) => {
    const updated = new Date(currentSimDate);
    updated.setUTCMonth(month, day);
    onTimeChange(updated);
  };

  return (
    <div className="absolute bottom-3 left-1/2 -translate-x-1/2 w-[95%] max-w-4xl z-30 pointer-events-auto select-none transition-transform duration-300">
      {/* Collapse / Expand Toggle Tab */}
      <div className="flex justify-center mb-1">
        <button
          onClick={() => setIsDockCollapsed(!isDockCollapsed)}
          className="flex items-center gap-1.5 px-3 py-0.5 bg-[#101820]/95 hover:bg-[#172735] text-[#94a3b8] hover:text-white rounded-t border-t border-x border-[#34576C]/40 text-[10px] font-mono tracking-wider uppercase transition-colors"
        >
          {isDockCollapsed ? (
            <>
              <ChevronUp className="w-3 h-3 text-[#53B6CA]" />
              <span>Show Simulation Timeline</span>
            </>
          ) : (
            <>
              <ChevronDown className="w-3 h-3 text-[#53B6CA]" />
              <span>Hide Controls</span>
            </>
          )}
        </button>
      </div>

      {/* Main Bottom Dock */}
      {!isDockCollapsed && (
        <div className="bg-[#101820]/95 backdrop-blur-md border border-[#34576C]/40 rounded-lg p-3 shadow-2xl text-xs font-mono text-[#EDF2F3] space-y-2.5">
          {/* Row 1: Playback Controls, Time Readout, Speed Multipliers, Seasonal Presets */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            {/* Play/Pause/Step */}
            <div className="flex items-center gap-2">
              <button
                onClick={onTogglePlay}
                className={`p-2 rounded text-[#101820] font-bold transition-all shadow-sm ${
                  isPlaying ? 'bg-[#53B6CA] hover:bg-[#429cb0]' : 'bg-[#E9A83B] hover:bg-[#d8962b]'
                }`}
                title={isPlaying ? 'Pause Simulation' : 'Play Simulation'}
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
              </button>

              <button
                onClick={stepForward}
                className="p-1.5 bg-[#172735] hover:bg-[#34576C] text-[#EDF2F3] rounded border border-[#34576C]/50 transition-colors"
                title="Step +15 Minutes"
              >
                <SkipForward className="w-3.5 h-3.5" />
              </button>

              {/* Time indicator */}
              <div className="flex items-center gap-2 px-2.5 py-1 bg-[#172735]/80 rounded border border-[#34576C]/40">
                {isDaylight ? (
                  <Sun className="w-3.5 h-3.5 text-[#E9A83B]" />
                ) : (
                  <Moon className="w-3.5 h-3.5 text-[#53B6CA]" />
                )}
                <span className="text-white font-semibold tabular-nums text-sm">
                  {currentSimDate.toTimeString().slice(0, 5)} UTC
                </span>
                <span className="text-[10px] text-[#94a3b8]">
                  ({solarElevation > 0 ? `+${solarElevation.toFixed(1)}°` : `${solarElevation.toFixed(1)}°`})
                </span>
              </div>
            </div>

            {/* Speed Multiplier Segmented Tabs */}
            <div className="flex items-center gap-1 p-0.5 bg-[#172735] rounded border border-[#34576C]/50 text-[11px]">
              <span className="text-[#94a3b8] px-1.5 text-[10px] hidden sm:inline">SPEED:</span>
              {[1, 60, 300, 1800, 3600].map((spd) => (
                <button
                  key={spd}
                  onClick={() => onSpeedChange(spd)}
                  className={`px-2 py-0.5 rounded transition-colors ${
                    playbackSpeed === spd
                      ? 'bg-[#53B6CA] text-[#101820] font-bold shadow-sm'
                      : 'text-[#94a3b8] hover:text-white'
                  }`}
                >
                  {spd === 1 ? '1x' : spd === 60 ? '1m/s' : spd === 300 ? '5m/s' : spd === 1800 ? '30m/s' : '1h/s'}
                </button>
              ))}
            </div>

            {/* Solstice / Equinox Seasonal Presets */}
            <div className="hidden md:flex items-center gap-1.5 text-[11px]">
              <Calendar className="w-3.5 h-3.5 text-[#94a3b8]" />
              <button
                onClick={() => applySeasonPreset(5, 21)}
                className="px-2 py-0.5 bg-[#172735] hover:bg-[#34576C] rounded border border-[#34576C]/40 text-[#94a3b8] hover:text-white"
                title="June 21 - Maximum solar altitude in Northern hemisphere"
              >
                Summer Solstice
              </button>
              <button
                onClick={() => applySeasonPreset(2, 20)}
                className="px-2 py-0.5 bg-[#172735] hover:bg-[#34576C] rounded border border-[#34576C]/40 text-[#94a3b8] hover:text-white"
                title="March 20 - Equinox"
              >
                Equinox
              </button>
              <button
                onClick={() => applySeasonPreset(11, 21)}
                className="px-2 py-0.5 bg-[#172735] hover:bg-[#34576C] rounded border border-[#34576C]/40 text-[#94a3b8] hover:text-white"
                title="Dec 21 - Minimum solar altitude & critical row shading"
              >
                Winter Solstice
              </button>
            </div>
          </div>

          {/* Row 2: 24-Hour Scrubbable Diurnal Slider with Day/Night Horizon */}
          <div className="space-y-1">
            <div className="relative flex items-center">
              <input
                type="range"
                min="0"
                max="23.95"
                step="0.05"
                value={currentFractionalHour}
                onChange={(e) => handleHourSliderChange(Number(e.target.value))}
                className="w-full accent-[#E9A83B] h-2 bg-[#172735] rounded cursor-pointer relative z-10"
              />
            </div>

            {/* Diurnal Hour Markings */}
            <div className="flex justify-between text-[9px] text-[#94a3b8] px-0.5 font-mono">
              <span>00:00 (Midnight)</span>
              <span>06:00 (Dawn)</span>
              <span>12:00 (Solar Noon)</span>
              <span>18:00 (Dusk)</span>
              <span>23:59</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
