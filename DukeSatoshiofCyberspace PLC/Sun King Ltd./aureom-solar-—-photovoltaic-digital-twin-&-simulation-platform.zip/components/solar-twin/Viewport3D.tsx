'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { createSolarCellTexture, createGroundTerrainTexture } from '@/lib/three/textures';
import { SolarPositionResult } from '@/lib/physics/solar-position';
import { Camera, Compass, Eye, Layers, Maximize2, RotateCcw, Sun, Thermometer, Zap, ShieldAlert, Cpu } from 'lucide-react';

export type ViewportMode = 'realistic' | 'irradiance' | 'thermal' | 'electrical' | 'shading' | 'grid';
export type CameraPreset = 'perspective' | 'nadir' | 'elevation' | 'tracker_axis' | 'macro';

interface Viewport3DProps {
  solarPos: SolarPositionResult;
  poaIrradiance: number;
  cellTemperatureC: number;
  thermalColorHex: string;
  trackerRotationDeg: number;
  arrayScale: 'single' | 'string' | 'commercial' | 'utility';
  activeMode: ViewportMode;
  onModeChange: (mode: ViewportMode) => void;
  acPowerKw: number;
  dcPowerKw: number;
}

export function Viewport3D({
  solarPos,
  poaIrradiance,
  cellTemperatureC,
  thermalColorHex,
  trackerRotationDeg,
  arrayScale,
  activeMode,
  onModeChange,
  acPowerKw,
  dcPowerKw,
}: Viewport3DProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const sunLightRef = useRef<THREE.DirectionalLight | null>(null);
  const sunMeshRef = useRef<THREE.Mesh | null>(null);
  const rowsGroupRef = useRef<THREE.Group | null>(null);
  const energyParticlesRef = useRef<THREE.Points | null>(null);
  const targetCameraPos = useRef<THREE.Vector3 | null>(null);
  const targetLookAt = useRef<THREE.Vector3 | null>(null);

  const [activePreset, setActivePreset] = useState<CameraPreset>('perspective');
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Initialize Three.js Scene
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = container.clientWidth;
    const height = container.clientHeight;

    // Scene setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color('#101820');
    // Horizon fog to blend terrain into deep graphite background
    scene.fog = new THREE.FogExp2('#101820', 0.012);

    // Camera setup
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(16, 12, 22);
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    rendererRef.current = renderer;
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.replaceChildren(renderer.domElement);

    // Controls setup
    const controls = new OrbitControls(camera, renderer.domElement);
    controlsRef.current = controls;
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2 - 0.03; // Don't allow camera to dip below ground
    controls.minDistance = 2;
    controls.maxDistance = 160;
    controls.target.set(0, 1.2, 0);

    // Studio Environment lighting rig
    const hemiLight = new THREE.HemisphereLight('#b8d5e5', '#16222f', 0.65);
    scene.add(hemiLight);

    // Directional Sun Light with shadows
    const sunLight = new THREE.DirectionalLight('#fff5e6', 2.2);
    sunLight.castShadow = !isSoftwareGl;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 1;
    sunLight.shadow.camera.far = 250;
    const shadowD = 28;
    sunLight.shadow.camera.left = -shadowD;
    sunLight.shadow.camera.right = shadowD;
    sunLight.shadow.camera.top = shadowD;
    sunLight.shadow.camera.bottom = -shadowD;
    sunLight.shadow.bias = -0.0004;
    sunLight.shadow.normalBias = 0.02;
    scene.add(sunLight);
    sunLightRef.current = sunLight;

    // Visible Sun Celestial Sphere
    const sunGeo = new THREE.SphereGeometry(2.5, 32, 16);
    const sunMat = new THREE.MeshBasicMaterial({ color: '#ffea9f' });
    const sunMesh = new THREE.Mesh(sunGeo, sunMat);
    scene.add(sunMesh);
    sunMeshRef.current = sunMesh;

    // Ground Plane with procedural soil/gravel texture
    const groundGeo = new THREE.PlaneGeometry(350, 350);
    const groundTex = createGroundTerrainTexture();
    const groundMat = new THREE.MeshStandardMaterial({
      map: groundTex,
      roughness: 0.92,
      metalness: 0.08,
      color: '#1a2734',
    });
    const groundMesh = new THREE.Mesh(groundGeo, groundMat);
    groundMesh.rotation.x = -Math.PI / 2;
    groundMesh.position.y = 0;
    groundMesh.receiveShadow = !isSoftwareGl;
    scene.add(groundMesh);

    // Inverter Transformer Skid & BESS Container structures on site
    const facilityGroup = new THREE.Group();
    // Central Inverter / MV Transformer Kiosk
    const inverterBox = new THREE.Mesh(
      new THREE.BoxGeometry(3.5, 2.6, 2.2),
      new THREE.MeshStandardMaterial({ color: '#2a3b4c', metalness: 0.6, roughness: 0.35 })
    );
    inverterBox.position.set(-14, 1.3, -4);
    inverterBox.castShadow = true;
    inverterBox.receiveShadow = true;
    facilityGroup.add(inverterBox);

    // Cooling louvers on inverter
    const louverGeo = new THREE.PlaneGeometry(1.8, 1.2);
    const louverMat = new THREE.MeshBasicMaterial({ color: '#101820' });
    const louver = new THREE.Mesh(louverGeo, louverMat);
    louver.position.set(-14, 1.4, -2.89);
    facilityGroup.add(louver);

    // BESS Container (40ft white/gray shipping container style)
    const bessBox = new THREE.Mesh(
      new THREE.BoxGeometry(8.0, 2.8, 2.4),
      new THREE.MeshStandardMaterial({ color: '#e2e8f0', metalness: 0.4, roughness: 0.4 })
    );
    bessBox.position.set(-14, 1.4, 4);
    bessBox.castShadow = true;
    bessBox.receiveShadow = true;
    facilityGroup.add(bessBox);

    // Weather Met Mast (Pyranometer station)
    const mastPole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.06, 0.08, 4.5, 12),
      new THREE.MeshStandardMaterial({ color: '#cbd5e1', metalness: 0.8, roughness: 0.2 })
    );
    mastPole.position.set(-12, 2.25, -10);
    facilityGroup.add(mastPole);

    const pyranometerArm = new THREE.Mesh(
      new THREE.BoxGeometry(0.8, 0.05, 0.05),
      new THREE.MeshStandardMaterial({ color: '#94a3b8' })
    );
    pyranometerArm.position.set(-12, 4.3, -10);
    facilityGroup.add(pyranometerArm);

    scene.add(facilityGroup);

    // Animated Grid/Power Flow Particle System
    const particleCount = 180;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    for (let p = 0; p < particleCount; p++) {
      particlePositions[p * 3] = -14 + (Math.random() - 0.5) * 4;
      particlePositions[p * 3 + 1] = 0.4 + Math.random() * 2.2;
      particlePositions[p * 3 + 2] = -4 + Math.random() * 8;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: '#53B6CA',
      size: 0.35,
      transparent: true,
      opacity: 0.0,
      blending: THREE.AdditiveBlending,
    });
    const energyParticles = new THREE.Points(particleGeo, particleMat);
    scene.add(energyParticles);
    energyParticlesRef.current = energyParticles;

    // Group for solar array rows
    const rowsGroup = new THREE.Group();
    scene.add(rowsGroup);
    rowsGroupRef.current = rowsGroup;

    // Animation loop
    let frameId = 0;
    const clock = new THREE.Clock();

    const tick = () => {
      const delta = clock.getDelta();

      // Camera transition smoothing
      if (targetCameraPos.current && targetLookAt.current && cameraRef.current && controlsRef.current) {
        cameraRef.current.position.lerp(targetCameraPos.current, 0.08);
        controlsRef.current.target.lerp(targetLookAt.current, 0.08);

        if (cameraRef.current.position.distanceTo(targetCameraPos.current) < 0.1) {
          targetCameraPos.current = null;
          targetLookAt.current = null;
        }
      }

      // Animate energy particles in GRID mode
      if (energyParticlesRef.current) {
        const positions = energyParticlesRef.current.geometry.attributes.position.array as Float32Array;
        for (let i = 0; i < particleCount; i++) {
          positions[i * 3 + 2] += (0.04 + Math.sin(i) * 0.02);
          if (positions[i * 3 + 2] > 6) {
            positions[i * 3 + 2] = -6;
          }
        }
        energyParticlesRef.current.geometry.attributes.position.needsUpdate = true;
      }

      controls.update();
      renderer.render(scene, camera);
      frameId = requestAnimationFrame(tick);
    };

    frameId = requestAnimationFrame(tick);

    // Resize handling
    const handleResize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      groundTex.dispose();
    };
  }, []);

  // Update Solar Position (Sun light and visual sphere coordinates)
  useEffect(() => {
    if (!sunLightRef.current || !sunMeshRef.current || !sceneRef.current) return;

    const { elevation, azimuth, isDaylight } = solarPos;
    const distance = 160;

    // Convert astronomical spherical coordinates to Cartesian coordinates:
    // Azimuth: 0 = North (+Z), 90 = East (+X), 180 = South (-Z), 270 = West (-X)
    const elevRad = Math.max(-5, elevation) * (Math.PI / 180);
    const azRad = azimuth * (Math.PI / 180);

    const x = distance * Math.cos(elevRad) * Math.sin(azRad);
    const y = Math.max(-20, distance * Math.sin(elevRad));
    const z = -distance * Math.cos(elevRad) * Math.cos(azRad);

    sunLightRef.current.position.set(x, y, z);
    sunMeshRef.current.position.set(x * 0.95, y * 0.95, z * 0.95);

    // Adjust light intensity and warmth based on solar elevation
    if (!isDaylight || elevation <= 0) {
      // Twilight / Night
      sunLightRef.current.intensity = 0.05;
      sunLightRef.current.color.set('#203045');
      sunMeshRef.current.visible = false;
      if (sceneRef.current.fog instanceof THREE.FogExp2) {
        sceneRef.current.fog.color.set('#0a0f16');
      }
      sceneRef.current.background = new THREE.Color('#0a0f16');
    } else if (elevation < 12) {
      // Golden hour sunrise/sunset
      sunLightRef.current.intensity = 1.4;
      sunLightRef.current.color.set('#ffaa44');
      (sunMeshRef.current.material as THREE.MeshBasicMaterial).color.set('#ff8822');
      sunMeshRef.current.visible = true;
      if (sceneRef.current.fog instanceof THREE.FogExp2) {
        sceneRef.current.fog.color.set('#1a1a24');
      }
      sceneRef.current.background = new THREE.Color('#141c28');
    } else {
      // Bright daylight
      sunLightRef.current.intensity = 2.4;
      sunLightRef.current.color.set('#fff8ee');
      (sunMeshRef.current.material as THREE.MeshBasicMaterial).color.set('#ffe894');
      sunMeshRef.current.visible = true;
      if (sceneRef.current.fog instanceof THREE.FogExp2) {
        sceneRef.current.fog.color.set('#101820');
      }
      sceneRef.current.background = new THREE.Color('#101820');
    }
  }, [solarPos]);

  // Rebuild 3D Array Geometry when scale changes or view mode changes
  useEffect(() => {
    if (!rowsGroupRef.current) return;
    const rowsGroup = rowsGroupRef.current;
    rowsGroup.clear();

    // Determine row configuration based on array scale
    let rowCount = 1;
    let modulesPerRow = 1;
    let rowPitch = 6.0;

    switch (arrayScale) {
      case 'single':
        rowCount = 1;
        modulesPerRow = 1;
        break;
      case 'string':
        rowCount = 1;
        modulesPerRow = 12;
        break;
      case 'commercial':
        rowCount = 4;
        modulesPerRow = 16;
        rowPitch = 5.5;
        break;
      case 'utility':
        rowCount = 8;
        modulesPerRow = 24;
        rowPitch = 6.8;
        break;
    }

    const cellTexture = createSolarCellTexture();

    // Determine module surface appearance based on visualization mode
    let moduleMaterial: THREE.Material;

    if (activeMode === 'realistic') {
      moduleMaterial = new THREE.MeshPhysicalMaterial({
        map: cellTexture,
        metalness: 0.45,
        roughness: 0.18,
        clearcoat: 1.0,
        clearcoatRoughness: 0.1,
        reflectivity: 0.85,
        color: '#1a304a',
      });
    } else if (activeMode === 'thermal') {
      moduleMaterial = new THREE.MeshStandardMaterial({
        color: new THREE.Color(thermalColorHex),
        roughness: 0.4,
        metalness: 0.2,
      });
    } else if (activeMode === 'irradiance') {
      // Color-map based on POA flux (0 - 1200 W/m^2)
      const ratio = Math.min(1, Math.max(0, poaIrradiance / 1100));
      const irrColor = new THREE.Color();
      // Viridis-style gradient: Indigo -> Cyan -> Amber -> Bright Yellow
      irrColor.setHSL(0.66 - ratio * 0.52, 0.9, 0.45 + ratio * 0.25);
      moduleMaterial = new THREE.MeshStandardMaterial({
        color: irrColor,
        roughness: 0.35,
        metalness: 0.1,
      });
    } else if (activeMode === 'electrical') {
      moduleMaterial = new THREE.MeshStandardMaterial({
        map: cellTexture,
        color: '#2a5a75',
        emissive: new THREE.Color('#53B6CA'),
        emissiveIntensity: 0.25,
        roughness: 0.3,
      });
    } else if (activeMode === 'shading') {
      moduleMaterial = new THREE.MeshStandardMaterial({
        map: cellTexture,
        color: '#1e2d3d',
        roughness: 0.5,
      });
    } else {
      // grid mode
      moduleMaterial = new THREE.MeshStandardMaterial({
        map: cellTexture,
        color: '#1c344d',
        roughness: 0.25,
      });
    }

    // Aluminum frame material
    const frameMaterial = new THREE.MeshStandardMaterial({
      color: '#8a99a8',
      metalness: 0.85,
      roughness: 0.25,
    });

    // Galvanized steel racking material
    const steelMaterial = new THREE.MeshStandardMaterial({
      color: '#475569',
      metalness: 0.8,
      roughness: 0.4,
    });

    const moduleWidth = 2.28;
    const moduleHeight = 1.14;
    const moduleDepth = 0.04;

    // Create each row as a distinct physical torque-tube assembly
    for (let r = 0; r < rowCount; r++) {
      const rowZ = (r - (rowCount - 1) / 2) * rowPitch;
      const rowAssembly = new THREE.Group();
      rowAssembly.position.set(0, 1.6, rowZ); // Torque tube axis at 1.6m elevation

      // Torque tube (long cylinder spanning entire row)
      const rowLength = modulesPerRow * (moduleHeight + 0.04);
      const tubeGeo = new THREE.CylinderGeometry(0.08, 0.08, rowLength + 0.8, 16);
      const tubeMesh = new THREE.Mesh(tubeGeo, steelMaterial);
      tubeMesh.rotation.z = Math.PI / 2;
      tubeMesh.castShadow = true;
      rowAssembly.add(tubeMesh);

      // Slew drive motor enclosure at center of row
      const motorBox = new THREE.Mesh(
        new THREE.BoxGeometry(0.4, 0.45, 0.4),
        new THREE.MeshStandardMaterial({ color: '#27384a', metalness: 0.9, roughness: 0.2 })
      );
      motorBox.castShadow = true;
      rowAssembly.add(motorBox);

      // Rotating sub-group for tracker rotation
      const rotGroup = new THREE.Group();

      // Add individual photovoltaic modules along the torque tube
      for (let m = 0; m < modulesPerRow; m++) {
        const modX = (m - (modulesPerRow - 1) / 2) * (moduleHeight + 0.04);
        const moduleGroup = new THREE.Group();
        moduleGroup.position.set(modX, 0.08, 0);

        // 1. Silicon wafer & glass face
        const glassGeo = new THREE.BoxGeometry(moduleHeight - 0.02, 0.015, moduleWidth - 0.02);
        const glassMesh = new THREE.Mesh(glassGeo, moduleMaterial);
        glassMesh.castShadow = true;
        glassMesh.receiveShadow = true;
        moduleGroup.add(glassMesh);

        // 2. Anodized aluminum perimeter frame
        const frameGeo = new THREE.BoxGeometry(moduleHeight, moduleDepth, moduleWidth);
        const frameMesh = new THREE.Mesh(frameGeo, frameMaterial);
        frameMesh.position.y = -0.015;
        frameMesh.castShadow = true;
        moduleGroup.add(frameMesh);

        // 3. Rear junction box
        const jboxGeo = new THREE.BoxGeometry(0.12, 0.03, 0.12);
        const jboxMesh = new THREE.Mesh(jboxGeo, new THREE.MeshBasicMaterial({ color: '#111822' }));
        jboxMesh.position.set(0, -0.04, 0);
        moduleGroup.add(jboxMesh);

        // 4. Purlin brackets clamping module to torque tube
        const bracketGeo = new THREE.BoxGeometry(0.04, 0.1, 0.25);
        const bracketMesh = new THREE.Mesh(bracketGeo, steelMaterial);
        bracketMesh.position.set(0, -0.06, 0);
        moduleGroup.add(bracketMesh);

        rotGroup.add(moduleGroup);
      }

      // Apply Tracker Rotation around North-South axis
      rotGroup.rotation.x = trackerRotationDeg * (Math.PI / 180);
      rowAssembly.add(rotGroup);

      // Support Pylons (H-beam posts driven into ground every 4 modules)
      const pylonSpacing = 4 * (moduleHeight + 0.04);
      const pylonCount = Math.max(2, Math.ceil(rowLength / pylonSpacing));
      for (let p = 0; p < pylonCount; p++) {
        const px = (p - (pylonCount - 1) / 2) * pylonSpacing;
        const postGeo = new THREE.CylinderGeometry(0.07, 0.09, 1.6, 8);
        const postMesh = new THREE.Mesh(postGeo, steelMaterial);
        postMesh.position.set(px, -0.8, 0);
        postMesh.castShadow = true;
        rowAssembly.add(postMesh);
      }

      rowsGroup.add(rowAssembly);
    }

    // Toggle particle opacity in grid mode
    if (energyParticlesRef.current) {
      (energyParticlesRef.current.material as THREE.PointsMaterial).opacity =
        activeMode === 'grid' ? 0.85 : 0.0;
    }
  }, [arrayScale, activeMode, thermalColorHex, poaIrradiance, trackerRotationDeg]);

  // Camera preset handler
  const setCameraView = useCallback((preset: CameraPreset) => {
    setActivePreset(preset);
    let targetPos = new THREE.Vector3(16, 12, 22);
    let lookTarget = new THREE.Vector3(0, 1.2, 0);

    switch (preset) {
      case 'perspective':
        targetPos = new THREE.Vector3(18, 14, 24);
        lookTarget = new THREE.Vector3(0, 1.5, 0);
        break;
      case 'nadir': // True 90° Top View
        targetPos = new THREE.Vector3(0, 36, 0.01);
        lookTarget = new THREE.Vector3(0, 0, 0);
        break;
      case 'elevation': // South elevation view
        targetPos = new THREE.Vector3(0, 2.5, 28);
        lookTarget = new THREE.Vector3(0, 1.5, 0);
        break;
      case 'tracker_axis': // Look straight along torque tube
        targetPos = new THREE.Vector3(-24, 2.8, 0);
        lookTarget = new THREE.Vector3(12, 1.6, 0);
        break;
      case 'macro': // Close-up module inspection
        targetPos = new THREE.Vector3(2.5, 2.2, 2.8);
        lookTarget = new THREE.Vector3(0, 1.6, 0);
        break;
    }

    targetCameraPos.current = targetPos;
    targetLookAt.current = lookTarget;
  }, []);

  return (
    <div className="relative w-full h-full bg-[#101820] overflow-hidden select-none">
      {/* 3D Canvas Mounting Container */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top Overlay: Active Mode & Coordinate Badge */}
      <div className="absolute top-3 left-4 z-10 flex items-center gap-3 pointer-events-none">
        <div className="px-2.5 py-1 bg-[#101820]/90 backdrop-blur-md border border-[#34576C]/40 rounded text-xs font-mono tracking-tight text-[#EDF2F3] shadow-md flex items-center gap-2">
          <Layers className="w-3.5 h-3.5 text-[#53B6CA]" />
          <span>VIEWPORT: {activeMode.toUpperCase()}</span>
          <span className="text-[#34576C]">|</span>
          <span className="text-[#E9A83B]">SUN EL: {solarPos.elevation.toFixed(1)}°</span>
          <span className="text-[#34576C]">|</span>
          <span className="text-[#53B6CA]">AZ: {solarPos.azimuth.toFixed(1)}°</span>
          {trackerRotationDeg !== 0 && (
            <>
              <span className="text-[#34576C]">|</span>
              <span className="text-[#EDF2F3]">TRACKER: {trackerRotationDeg > 0 ? `+${trackerRotationDeg}° W` : `${trackerRotationDeg}° E`}</span>
            </>
          )}
        </div>
      </div>

      {/* Top Right: Viewport Mode Switcher Buttons */}
      <div className="absolute top-3 right-4 z-10 flex items-center gap-1.5 p-1 bg-[#101820]/90 backdrop-blur-md border border-[#34576C]/40 rounded shadow-md pointer-events-auto">
        {(
          [
            { id: 'realistic', label: 'Realistic', icon: Eye },
            { id: 'irradiance', label: 'Irradiance', icon: Sun },
            { id: 'thermal', label: 'Thermal', icon: Thermometer },
            { id: 'electrical', label: 'Electrical', icon: Zap },
            { id: 'shading', label: 'Shading', icon: ShieldAlert },
            { id: 'grid', label: 'Grid Flow', icon: Cpu },
          ] as const
        ).map((mode) => {
          const Icon = mode.icon;
          const isActive = activeMode === mode.id;
          return (
            <button
              key={mode.id}
              onClick={() => onModeChange(mode.id)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-all ${
                isActive
                  ? 'bg-[#172735] text-[#53B6CA] border border-[#53B6CA]/50 shadow-sm'
                  : 'text-[#94a3b8] hover:text-[#EDF2F3] hover:bg-[#172735]/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{mode.label}</span>
            </button>
          );
        })}
      </div>

      {/* Bottom Right Floating Camera Controls Dock */}
      <div className="absolute bottom-4 right-4 z-10 flex items-center gap-1.5 p-1 bg-[#101820]/90 backdrop-blur-md border border-[#34576C]/40 rounded shadow-md pointer-events-auto text-xs font-mono">
        <button
          onClick={() => setCameraView('perspective')}
          title="Perspective Orbit (45°)"
          className={`px-2 py-1 rounded transition-colors ${
            activePreset === 'perspective' ? 'bg-[#34576C] text-white' : 'text-[#94a3b8] hover:text-white'
          }`}
        >
          Perspective
        </button>
        <button
          onClick={() => setCameraView('nadir')}
          title="Nadir / Top Plan View (90°)"
          className={`px-2 py-1 rounded transition-colors ${
            activePreset === 'nadir' ? 'bg-[#34576C] text-white' : 'text-[#94a3b8] hover:text-white'
          }`}
        >
          Nadir
        </button>
        <button
          onClick={() => setCameraView('elevation')}
          title="South Elevation View"
          className={`px-2 py-1 rounded transition-colors ${
            activePreset === 'elevation' ? 'bg-[#34576C] text-white' : 'text-[#94a3b8] hover:text-white'
          }`}
        >
          Elevation
        </button>
        <button
          onClick={() => setCameraView('tracker_axis')}
          title="Tracker Torque Tube Axis View"
          className={`px-2 py-1 rounded transition-colors ${
            activePreset === 'tracker_axis' ? 'bg-[#34576C] text-white' : 'text-[#94a3b8] hover:text-white'
          }`}
        >
          Axis
        </button>
        <button
          onClick={() => setCameraView('macro')}
          title="Macro Inspection View"
          className={`px-2 py-1 rounded transition-colors ${
            activePreset === 'macro' ? 'bg-[#34576C] text-white' : 'text-[#94a3b8] hover:text-white'
          }`}
        >
          Macro
        </button>
        <button
          onClick={() => setCameraView('perspective')}
          title="Reset Camera"
          className="p-1 text-[#94a3b8] hover:text-[#E9A83B] transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Thermographic Color Legend (shown when in Thermal mode) */}
      {activeMode === 'thermal' && (
        <div className="absolute bottom-4 left-4 z-10 p-2.5 bg-[#101820]/90 backdrop-blur-md border border-[#34576C]/40 rounded text-xs font-mono shadow-md pointer-events-none">
          <div className="text-[11px] text-[#94a3b8] mb-1 font-semibold">CALIBRATED THERMAL SCALE (°C)</div>
          <div className="flex items-center gap-1">
            <span className="text-[#53B6CA] font-bold">20°C</span>
            <div className="w-32 h-2.5 rounded bg-gradient-to-r from-[#172735] via-[#53B6CA] via-[#E9A83B] to-[#D95D57]" />
            <span className="text-[#D95D57] font-bold">75°C</span>
          </div>
          <div className="text-[10px] text-[#E9A83B] mt-1">Current Cell: {cellTemperatureC}°C</div>
        </div>
      )}

      {/* Irradiance Color Legend (shown when in Irradiance mode) */}
      {activeMode === 'irradiance' && (
        <div className="absolute bottom-4 left-4 z-10 p-2.5 bg-[#101820]/90 backdrop-blur-md border border-[#34576C]/40 rounded text-xs font-mono shadow-md pointer-events-none">
          <div className="text-[11px] text-[#94a3b8] mb-1 font-semibold">PLANE-OF-ARRAY FLUX (W/m²)</div>
          <div className="flex items-center gap-1">
            <span className="text-[#53B6CA]">0</span>
            <div className="w-32 h-2.5 rounded bg-gradient-to-r from-blue-700 via-cyan-400 via-amber-400 to-yellow-300" />
            <span className="text-[#E9A83B]">1200</span>
          </div>
          <div className="text-[10px] text-[#EDF2F3] mt-1">POA: {poaIrradiance.toFixed(0)} W/m²</div>
        </div>
      )}
    </div>
  );
}
