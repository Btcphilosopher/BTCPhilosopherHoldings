import type {Metadata} from 'next';
import { Plus_Jakarta_Sans, JetBrains_Mono } from 'next/font/google';
import './globals.css';

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'AUREOM SOLAR — Photovoltaic Digital Twin & Simulation Platform',
  description: 'Industrial-grade solar photovoltaic digital twin, semiconductor physics engine, 3D array simulation, irradiance transposition, thermal modelling, and grid-storage optimization.',
  openGraph: {
    title: 'AUREOM SOLAR — Photovoltaic Digital Twin & Simulation Platform',
    description: 'Industrial-grade solar photovoltaic digital twin, semiconductor physics engine, 3D array simulation, irradiance transposition, thermal modelling, and grid-storage optimization.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'AUREOM SOLAR — Photovoltaic Digital Twin & Simulation Platform',
    description: 'Industrial-grade solar photovoltaic digital twin, semiconductor physics engine, 3D array simulation, irradiance transposition, thermal modelling, and grid-storage optimization.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`dark ${plusJakartaSans.variable} ${jetbrainsMono.variable}`}>
      <body className="bg-[#101820] text-[#EDF2F3] font-sans antialiased selection:bg-[#E9A83B]/20 selection:text-[#E9A83B]" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
