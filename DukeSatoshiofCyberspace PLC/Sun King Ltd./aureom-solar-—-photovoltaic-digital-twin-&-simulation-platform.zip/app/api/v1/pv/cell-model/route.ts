import { NextRequest, NextResponse } from 'next/server';
import { calculateModulePhysics, MODULE_PRESETS } from '@/lib/physics/single-diode';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      moduleId = 'topcon-580',
      effectiveIrradiance = 1000,
      cellTemperatureC = 25,
      customRs,
      customRsh,
      customN,
      shadedSubstringsCount = 0,
      shadedFraction = 0.3,
    } = body;

    const specs = MODULE_PRESETS[moduleId] || MODULE_PRESETS['topcon-580'];
    const result = calculateModulePhysics(specs, {
      effectiveIrradiance,
      cellTemperatureC,
      customRs,
      customRsh,
      customN,
      shadedSubstringsCount,
      shadedFraction,
    });

    return NextResponse.json({
      status: 'success',
      moduleSpecs: specs,
      results: {
        isc: result.isc,
        voc: result.voc,
        pmp: result.pmp,
        vmp: result.vmp,
        imp: result.imp,
        fillFactor: result.fillFactor,
        efficiency: result.efficiency,
        rs: result.rs,
        rsh: result.rsh,
        vtMod: result.vtMod,
      },
      ivCurve: result.ivCurve,
      pvCurve: result.pvCurve,
    });
  } catch (error: unknown) {
    const err = error as Error;
    return NextResponse.json({ status: 'error', message: err.message }, { status: 400 });
  }
}
