import { NextResponse } from 'next/server';

export async function GET() {
  const projects = [
    {
      id: 'proj_solaria_50mw',
      name: 'Solaria Nexus Utility Phase 1',
      location: 'Atacama Desert, Chile (-23.86°N, -69.14°E, 2300m)',
      scale: '50 MWp Utility SAT',
      technology: 'N-Type TOPCon 580W Bifacial',
      tracking: 'Horizontal Single-Axis Tracker (Backtracking)',
      bessCapacityKwh: 40000,
      annualYieldMwh: 124500,
      prPercent: 84.8,
      lcoeMwh: 28.4,
      status: 'Commissioned',
    },
    {
      id: 'proj_mojave_10mw',
      name: 'Mojave Industrial Solar & Storage',
      location: 'Barstow, California, USA (34.89°N, -117.02°E, 650m)',
      scale: '10 MWp Commercial SAT',
      technology: 'HJT 700W Ultra Bifacial',
      tracking: 'Horizontal Single-Axis Tracker',
      bessCapacityKwh: 15000,
      annualYieldMwh: 23600,
      prPercent: 83.2,
      lcoeMwh: 34.2,
      status: 'Operational',
    },
    {
      id: 'proj_bavaria_250kw',
      name: 'Bavaria Agrivoltaic & Commercial',
      location: 'Ingolstadt, Germany (48.76°N, 11.42°E, 374m)',
      scale: '250 kWp Fixed-Tilt Commercial',
      technology: 'TOPCon 580W Bifacial',
      tracking: 'Fixed Tilt 32° South',
      bessCapacityKwh: 200,
      annualYieldMwh: 285,
      prPercent: 81.6,
      lcoeMwh: 58.0,
      status: 'Active Digital Twin',
    },
  ];

  return NextResponse.json({
    brand: 'Aureom.AI',
    product: 'AUREOM SOLAR',
    version: '3.8-Enterprise',
    projects,
  });
}
