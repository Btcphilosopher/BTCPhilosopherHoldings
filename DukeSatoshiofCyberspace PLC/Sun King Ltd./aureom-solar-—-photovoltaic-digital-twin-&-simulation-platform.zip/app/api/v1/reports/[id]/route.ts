import { NextRequest, NextResponse } from 'next/server';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  return NextResponse.json({
    reportId: id,
    standard: 'IEC 61724-1 Photovoltaic System Performance Monitoring',
    projectName: 'AUREOM SOLAR Digital Twin Simulation',
    generatedAt: new Date().toISOString(),
    compliance: {
      singleDiodeModel: 'De Soto et al. (5-parameter)',
      transpositionModel: 'Hay-Davies / Perez POA',
      thermalModel: 'Faiman (1992) / Sandia SAPM',
      trackingEngine: 'N-S HSAT with Astronomical Backtracking (Passias-Källbäck)',
      bifacialModel: '2D View Factor with ground clearance integration',
    },
    performanceMetrics: {
      performanceRatio: 84.2,
      specificYieldKwhPerKwp: 1785.4,
      annualBifacialGainPercent: 11.6,
      availabilityPercent: 99.4,
      totalLossBudgetPercent: 15.8,
    },
    financialMetrics: {
      lcoeDollarsPerMwh: 31.8,
      irrPercent: 14.6,
      npvDollars: 4850000,
      simplePaybackYears: 6.8,
    },
  });
}
