import { NextRequest, NextResponse } from 'next/server';
import { calculateSolarPosition } from '@/lib/physics/solar-position';
import { calculateIrradiance } from '@/lib/physics/irradiance';
import { calculateThermalState } from '@/lib/physics/thermal';
import { calculateTrackerOrientation } from '@/lib/physics/tracking';
import { calculateBifacialGain } from '@/lib/physics/bifacial';
import { calculateModulePhysics, MODULE_PRESETS } from '@/lib/physics/single-diode';
import { calculateInverterState, INVERTER_PRESETS } from '@/lib/physics/inverter';
import { simulateBatteryStep, BATTERY_PRESETS } from '@/lib/physics/battery';
import { calculateGridBalance } from '@/lib/physics/grid-system';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      latitude = 34.05,
      longitude = -118.24,
      elevation = 150,
      timestamp = new Date().toISOString(),
      surfaceTilt = 25,
      surfaceAzimuth = 180,
      albedo = 0.25,
      modulePreset = 'topcon-580',
      modulesCount = 480,
      trackingMode = 'single_axis',
      inverterPreset = 'string-100kw',
      batteryPreset = 'lfp-100kwh',
      batterySoc = 65,
      batteryDispatch = 'self_consumption',
      facilityType = 'commercial_office',
      baseLoadKw = 45,
      ambientTemp = 25,
      windSpeed = 2.5,
      weatherScenario = 'clear',
    } = body;

    const date = new Date(timestamp);
    const solarPos = calculateSolarPosition({ latitude, longitude, elevation, date });

    const tracking = calculateTrackerOrientation({
      mode: trackingMode,
      solarPos,
      fixedTilt: surfaceTilt,
      fixedAzimuth: surfaceAzimuth,
      groundCoverageRatio: 0.35,
    });

    const irradiance = calculateIrradiance({
      solarPos,
      surfaceTilt: tracking.actualTilt,
      surfaceAzimuth: tracking.actualAzimuth,
      albedo,
      elevation,
      weatherScenario,
    });

    const moduleSpecs = MODULE_PRESETS[modulePreset] || MODULE_PRESETS['topcon-580'];

    const bifacial = calculateBifacialGain({
      frontPoa: irradiance.poaTotal,
      ghi: irradiance.ghi,
      dhi: irradiance.dhi,
      tilt: tracking.actualTilt,
      clearanceHeightMeters: 1.2,
      rowPitchMeters: 6.0,
      moduleWidthMeters: moduleSpecs.widthMeters,
      albedo,
      bifacialityFactor: moduleSpecs.bifacialityFactor,
    });

    const thermal = calculateThermalState(
      {
        mountingType: trackingMode === 'single_axis' ? 'single_axis_tracker' : 'open_rack',
        ambientTemperatureC: ambientTemp,
        poaIrradiance: bifacial.totalEffectiveIrradiance,
        windSpeedMs: windSpeed,
      },
      moduleSpecs.gammaPmp
    );

    const cellModel = calculateModulePhysics(moduleSpecs, {
      effectiveIrradiance: bifacial.totalEffectiveIrradiance,
      cellTemperatureC: thermal.cellTemperatureC,
    });

    const totalDcPowerKw = (cellModel.pmp * modulesCount) / 1000;
    const stringVoltage = cellModel.vmp * 24; // 24 modules per string

    const inverterSpecs = INVERTER_PRESETS[inverterPreset] || INVERTER_PRESETS['string-100kw'];
    const inverter = calculateInverterState({
      specs: inverterSpecs,
      dcInputPowerWatts: totalDcPowerKw * 1000,
      dcInputVoltageVolts: stringVoltage,
      ambientTemperatureC: ambientTemp,
    });

    const batterySpecs = BATTERY_PRESETS[batteryPreset] || BATTERY_PRESETS['lfp-100kwh'];
    const hourOfDay = date.getUTCHours() + date.getUTCMinutes() / 60;
    const battery = simulateBatteryStep({
      specs: batterySpecs,
      currentSocPercent: batterySoc,
      strategy: batteryDispatch,
      pvGenerationKw: inverter.acOutputPowerWatts / 1000,
      facilityLoadKw: baseLoadKw,
      timeOfDayHours: hourOfDay,
    });

    const grid = calculateGridBalance({
      pvAcPowerKw: inverter.acOutputPowerWatts / 1000,
      facilityType,
      baseLoadKw,
      timeOfDayHours: hourOfDay,
      batteryChargeKw: battery.chargePowerKw,
      batteryDischargeKw: battery.dischargePowerKw,
    });

    return NextResponse.json({
      status: 'success',
      timestamp: date.toISOString(),
      solarPosition: solarPos,
      tracking,
      irradiance,
      bifacial,
      thermal,
      cellModel: {
        pmpWatts: cellModel.pmp,
        vmpVolts: cellModel.vmp,
        impAmps: cellModel.imp,
        vocVolts: cellModel.voc,
        iscAmps: cellModel.isc,
        fillFactor: cellModel.fillFactor,
        efficiencyPercent: cellModel.efficiency,
      },
      array: {
        modulesCount,
        totalDcPowerKw,
        stringVoltageVolts: stringVoltage,
      },
      inverter: {
        acPowerKw: inverter.acOutputPowerWatts / 1000,
        efficiencyPercent: inverter.efficiencyPercent,
        isClipping: inverter.isClipping,
        clippingLossKw: inverter.clippingLossWatts / 1000,
      },
      battery,
      grid,
    });
  } catch (error: unknown) {
    const err = error as Error;
    return NextResponse.json({ status: 'error', message: err.message }, { status: 400 });
  }
}
