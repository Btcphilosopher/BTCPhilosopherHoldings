'use client';

import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { WorkstationHeader } from '@/components/solar-twin/WorkstationHeader';
import { TelemetryRibbon, LOCATION_PRESETS, LocationPreset } from '@/components/solar-twin/TelemetryRibbon';
import { LeftEngineeringPanel } from '@/components/solar-twin/LeftEngineeringPanel';
import { RightTelemetryPanel } from '@/components/solar-twin/RightTelemetryPanel';
import { Viewport3D, ViewportMode } from '@/components/solar-twin/Viewport3D';
import { TimelineController } from '@/components/solar-twin/TimelineController';
import { PhysicsCurveModal } from '@/components/solar-twin/PhysicsCurveModal';
import { SolarFarmScaleModal } from '@/components/solar-twin/SolarFarmScaleModal';
import { AnalyticsFinancialModal } from '@/components/solar-twin/AnalyticsFinancialModal';
import { ReportModal } from '@/components/solar-twin/ReportModal';

import { calculateSolarPosition, SolarPositionResult } from '@/lib/physics/solar-position';
import { calculateIrradiance, IrradianceResult } from '@/lib/physics/irradiance';
import { calculateThermalState, ThermalResult, MountingType } from '@/lib/physics/thermal';
import { calculateTrackerOrientation, TrackingMode, TrackingResult } from '@/lib/physics/tracking';
import { calculateBifacialGain, BifacialResult } from '@/lib/physics/bifacial';
import { calculateModulePhysics, MODULE_PRESETS, ModuleSpecs } from '@/lib/physics/single-diode';
import { calculateInverterState, INVERTER_PRESETS, InverterSpecs } from '@/lib/physics/inverter';
import { simulateBatteryStep, BATTERY_PRESETS, BatterySpecs, DispatchStrategy, BatteryDispatchResult } from '@/lib/physics/battery';
import { calculateGridBalance, GridBalanceResult, FacilityType } from '@/lib/physics/grid-system';

export default function SolarDigitalTwinWorkstation() {
  // Site & Geographical Configuration
  const [selectedLocation, setSelectedLocation] = useState<LocationPreset>(LOCATION_PRESETS['atacama']);
  const [weatherScenario, setWeatherScenario] = useState<'clear' | 'scattered' | 'overcast' | 'desert_extreme' | 'winter_clean'>('clear');

  // Simulation Clock & Playback
  // Initialize to solar noon (12:00 UTC) on June 21 (Summer Solstice)
  const [simDate, setSimDate] = useState<Date>(() => new Date(Date.UTC(2026, 5, 21, 12, 0, 0)));
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(60); // 60x = 1 sim minute per second

  // Array & Hardware Specifications
  const [selectedModule, setSelectedModule] = useState<ModuleSpecs>(MODULE_PRESETS['topcon-580']);
  const [modulesCount, setModulesCount] = useState<number>(192); // ~111 kWp array
  const [arrayScale, setArrayScale] = useState<'single' | 'string' | 'commercial' | 'utility'>('commercial');
  const [activeFidelity, setActiveFidelity] = useState<'cell' | 'module' | 'string' | 'array' | 'plant'>('string');

  // Racking & Tracking
  const [trackingMode, setTrackingMode] = useState<TrackingMode>('single_axis');
  const [tiltAngle, setTiltAngle] = useState<number>(25);
  const [azimuthAngle, setAzimuthAngle] = useState<number>(180);
  const [enableBacktracking, setEnableBacktracking] = useState<boolean>(true);
  const [mountingType, setMountingType] = useState<MountingType>('single_axis_tracker');
  const [rowPitchMeters, setRowPitchMeters] = useState<number>(5.5);
  const [clearanceHeightMeters, setClearanceHeightMeters] = useState<number>(1.2);

  // Inverter & Storage
  const [selectedInverter, setSelectedInverter] = useState<InverterSpecs>(INVERTER_PRESETS['string-100kw']);
  const [selectedBattery, setSelectedBattery] = useState<BatterySpecs>(BATTERY_PRESETS['lfp-100kwh']);
  const [batterySoc, setBatterySoc] = useState<number>(55);
  const [batteryDispatch, setBatteryDispatch] = useState<DispatchStrategy>('self_consumption');
  const [facilityType, setFacilityType] = useState<FacilityType>('commercial_office');
  const [baseLoadKw, setBaseLoadKw] = useState<number>(45);

  // Environmental Parameters
  const [ambientTempC, setAmbientTempC] = useState<number>(selectedLocation.typicalAmbTempC);
  const [windSpeedMs, setWindSpeedMs] = useState<number>(2.8);
  const [albedo, setAlbedo] = useState<number>(selectedLocation.albedo);

  // Viewport Settings
  const [activeViewportMode, setActiveViewportMode] = useState<ViewportMode>('realistic');
  const [isLeftPanelCollapsed, setIsLeftPanelCollapsed] = useState<boolean>(false);
  const [isRightPanelCollapsed, setIsRightPanelCollapsed] = useState<boolean>(false);

  // Modal Dialogs
  const [isPhysicsModalOpen, setIsPhysicsModalOpen] = useState<boolean>(false);
  const [isScaleModalOpen, setIsScaleModalOpen] = useState<boolean>(false);
  const [isFinancialsModalOpen, setIsFinancialsModalOpen] = useState<boolean>(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);

  // Daily cumulative yield accumulator
  const [dailyYieldKwh, setDailyYieldKwh] = useState<number>(342.5);

  // Update ambient temp and albedo when location preset changes
  const handleLocationChange = (loc: LocationPreset) => {
    setSelectedLocation(loc);
    setAmbientTempC(loc.typicalAmbTempC);
    setAlbedo(loc.albedo);
  };

  // Synchronize array scale selection
  const handleScaleChange = (scale: 'single' | 'string' | 'commercial' | 'utility') => {
    setArrayScale(scale);
    switch (scale) {
      case 'single':
        setModulesCount(1);
        setActiveFidelity('cell');
        break;
      case 'string':
        setModulesCount(24);
        setActiveFidelity('module');
        break;
      case 'commercial':
        setModulesCount(192);
        setActiveFidelity('string');
        break;
      case 'utility':
        setModulesCount(864);
        setActiveFidelity('plant');
        break;
    }
  };

  // ----------------------------------------------------
  // PHYSICAL COMPUTATION ENGINE (Computed synchronously)
  // ----------------------------------------------------

  // 1. Solar Ephemeris & Astronomical Position
  const solarPos: SolarPositionResult = useMemo(() => {
    return calculateSolarPosition({
      latitude: selectedLocation.latitude,
      longitude: selectedLocation.longitude,
      elevation: selectedLocation.elevation,
      date: simDate,
    });
  }, [selectedLocation, simDate]);

  // 2. Tracking Kinematics & Backtracking Angle
  const gcr = selectedModule.lengthMeters / rowPitchMeters;
  const tracking: TrackingResult = useMemo(() => {
    return calculateTrackerOrientation({
      mode: trackingMode,
      solarPos,
      fixedTilt: tiltAngle,
      fixedAzimuth: azimuthAngle,
      groundCoverageRatio: gcr,
      enableBacktracking,
    });
  }, [trackingMode, solarPos, tiltAngle, azimuthAngle, gcr, enableBacktracking]);

  // 3. Clear-Sky & Plane-of-Array (POA) Irradiance Transposition
  const irradiance: IrradianceResult = useMemo(() => {
    return calculateIrradiance({
      solarPos,
      surfaceTilt: tracking.actualTilt,
      surfaceAzimuth: tracking.actualAzimuth,
      albedo,
      elevation: selectedLocation.elevation,
      weatherScenario,
    });
  }, [solarPos, tracking, albedo, selectedLocation.elevation, weatherScenario]);

  // 4. Bifacial Rear-Side View Factor & Effective Irradiance
  const bifacial: BifacialResult = useMemo(() => {
    return calculateBifacialGain({
      frontPoa: irradiance.poaTotal,
      ghi: irradiance.ghi,
      dhi: irradiance.dhi,
      tilt: tracking.actualTilt,
      clearanceHeightMeters,
      rowPitchMeters,
      moduleWidthMeters: selectedModule.widthMeters,
      albedo,
      bifacialityFactor: selectedModule.bifacialityFactor,
    });
  }, [irradiance, tracking, clearanceHeightMeters, rowPitchMeters, selectedModule, albedo]);

  // 5. Thermal Digital Twin (Faiman / SAPM Model)
  const thermal: ThermalResult = useMemo(() => {
    return calculateThermalState(
      {
        mountingType,
        ambientTemperatureC: ambientTempC,
        poaIrradiance: bifacial.totalEffectiveIrradiance,
        windSpeedMs,
      },
      selectedModule.gammaPmp
    );
  }, [mountingType, ambientTempC, bifacial.totalEffectiveIrradiance, windSpeedMs, selectedModule.gammaPmp]);

  // 6. Semiconductor Photovoltaic Physics (Single-Diode Model)
  const cellPhysics = useMemo(() => {
    return calculateModulePhysics(selectedModule, {
      effectiveIrradiance: bifacial.totalEffectiveIrradiance,
      cellTemperatureC: thermal.cellTemperatureC,
    });
  }, [selectedModule, bifacial.totalEffectiveIrradiance, thermal.cellTemperatureC]);

  // Array Electrical Totals
  const totalDcPowerKw = (cellPhysics.pmp * modulesCount) / 1000;
  const stringVoltageVolts = cellPhysics.vmp * 24;

  // 7. Inverter Digital Twin & Saturation Clipping
  const inverter = useMemo(() => {
    return calculateInverterState({
      specs: selectedInverter,
      dcInputPowerWatts: totalDcPowerKw * 1000,
      dcInputVoltageVolts: stringVoltageVolts,
      ambientTemperatureC: ambientTempC,
    });
  }, [selectedInverter, totalDcPowerKw, stringVoltageVolts, ambientTempC]);

  const acPowerKw = inverter.acOutputPowerWatts / 1000;

  // 8. Battery Energy Storage System (BESS) Dispatch
  const hourFraction = simDate.getUTCHours() + simDate.getUTCMinutes() / 60;
  const batteryDispatchResult: BatteryDispatchResult = useMemo(() => {
    return simulateBatteryStep({
      specs: selectedBattery,
      currentSocPercent: batterySoc,
      strategy: batteryDispatch,
      pvGenerationKw: acPowerKw,
      facilityLoadKw: baseLoadKw,
      timeOfDayHours: hourFraction,
    });
  }, [selectedBattery, batterySoc, batteryDispatch, acPowerKw, baseLoadKw, hourFraction]);

  // 9. Grid Integration & Energy Conservation Balance
  const gridBalance: GridBalanceResult = useMemo(() => {
    return calculateGridBalance({
      pvAcPowerKw: acPowerKw,
      facilityType,
      baseLoadKw,
      timeOfDayHours: hourFraction,
      batteryChargeKw: batteryDispatchResult.chargePowerKw,
      batteryDischargeKw: batteryDispatchResult.dischargePowerKw,
    });
  }, [acPowerKw, facilityType, baseLoadKw, hourFraction, batteryDispatchResult]);

  // Performance Ratio Calculation (IEC 61724)
  const performanceRatioPercent = useMemo(() => {
    const nominalStcKw = (modulesCount * selectedModule.pmpRef) / 1000;
    if (nominalStcKw <= 0 || irradiance.poaTotal <= 10) return 84.5;
    const theoreticalPowerKw = nominalStcKw * (irradiance.poaTotal / 1000);
    return Math.min(96, Math.max(72, (acPowerKw / theoreticalPowerKw) * 100));
  }, [modulesCount, selectedModule.pmpRef, irradiance.poaTotal, acPowerKw]);

  // Simulation Clock Tick Loop
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      setSimDate((prev) => {
        // Advance clock according to playbackSpeed (e.g. 60x = 60 real seconds per tick)
        const stepSeconds = playbackSpeed * 0.1;
        const next = new Date(prev.getTime() + stepSeconds * 1000);

        // Accumulate daily yield incrementally
        if (acPowerKw > 0) {
          setDailyYieldKwh((old) => old + (acPowerKw * (stepSeconds / 3600)));
        }

        // Reset daily yield at midnight
        if (next.getUTCHours() === 0 && next.getUTCMinutes() === 0) {
          setDailyYieldKwh(0);
        }

        return next;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed, acPowerKw]);

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#101820] text-[#EDF2F3] select-none font-sans">
      {/* 1. Header (Strict Top Bar Contract) */}
      <WorkstationHeader
        onOpenPhysicsModal={() => setIsPhysicsModalOpen(true)}
        onOpenScaleModal={() => setIsScaleModalOpen(true)}
        onOpenFinancialsModal={() => setIsFinancialsModalOpen(true)}
        onOpenReportModal={() => setIsReportModalOpen(true)}
        activeView="workstation"
      />

      {/* 2. Top Telemetry & Location Status Ribbon */}
      <TelemetryRibbon
        selectedLocation={selectedLocation}
        onLocationChange={handleLocationChange}
        solarPos={solarPos}
        simDate={simDate}
        weatherScenario={weatherScenario}
        onWeatherChange={setWeatherScenario}
        isEnergyConserved={gridBalance.isEnergyConserved}
        isClipping={inverter.isClipping}
      />

      {/* 3. Main Workstation Body: Left Panel + Central 3D Viewport + Right Telemetry */}
      <main className="flex-1 flex overflow-hidden relative">
        {/* Left Engineering Panel */}
        <LeftEngineeringPanel
          selectedModule={selectedModule}
          onSelectModule={setSelectedModule}
          modulesCount={modulesCount}
          onModulesCountChange={setModulesCount}
          tiltAngle={tiltAngle}
          onTiltChange={setTiltAngle}
          azimuthAngle={azimuthAngle}
          onAzimuthChange={setAzimuthAngle}
          trackingMode={trackingMode}
          onTrackingModeChange={setTrackingMode}
          enableBacktracking={enableBacktracking}
          onToggleBacktracking={setEnableBacktracking}
          mountingType={mountingType}
          onMountingTypeChange={setMountingType}
          rowPitchMeters={rowPitchMeters}
          onRowPitchChange={setRowPitchMeters}
          clearanceHeightMeters={clearanceHeightMeters}
          onClearanceHeightChange={setClearanceHeightMeters}
          selectedInverter={selectedInverter}
          onSelectInverter={setSelectedInverter}
          selectedBattery={selectedBattery}
          onSelectBattery={setSelectedBattery}
          batteryDispatch={batteryDispatch}
          onBatteryDispatchChange={setBatteryDispatch}
          ambientTempC={ambientTempC}
          onAmbientTempChange={setAmbientTempC}
          windSpeedMs={windSpeedMs}
          onWindSpeedChange={setWindSpeedMs}
          albedo={albedo}
          onAlbedoChange={setAlbedo}
          isCollapsed={isLeftPanelCollapsed}
          onToggleCollapse={() => setIsLeftPanelCollapsed(!isLeftPanelCollapsed)}
        />

        {/* Central 3D Simulation Viewport (~60% of workstation) */}
        <section className="flex-1 relative h-full">
          <Viewport3D
            solarPos={solarPos}
            poaIrradiance={irradiance.poaTotal}
            cellTemperatureC={thermal.cellTemperatureC}
            thermalColorHex={thermal.thermographicColorHex}
            trackerRotationDeg={tracking.rotationAngle}
            arrayScale={arrayScale}
            activeMode={activeViewportMode}
            onModeChange={setActiveViewportMode}
            acPowerKw={acPowerKw}
            dcPowerKw={totalDcPowerKw}
          />

          {/* Unified Collapsible Bottom Timeline Dock */}
          <TimelineController
            currentSimDate={simDate}
            onTimeChange={setSimDate}
            isPlaying={isPlaying}
            onTogglePlay={() => setIsPlaying(!isPlaying)}
            playbackSpeed={playbackSpeed}
            onSpeedChange={setPlaybackSpeed}
            solarElevation={solarPos.elevation}
            isDaylight={solarPos.isDaylight}
          />
        </section>

        {/* Right Telemetry Panel */}
        <RightTelemetryPanel
          irradiance={irradiance}
          thermal={thermal}
          bifacialGainPercent={bifacial.bifacialGainPercent}
          dcPowerKw={totalDcPowerKw}
          acPowerKw={acPowerKw}
          inverterEfficiencyPercent={inverter.efficiencyPercent}
          isClipping={inverter.isClipping}
          clippingLossKw={inverter.clippingLossWatts / 1000}
          battery={batteryDispatchResult}
          grid={gridBalance}
          dailyYieldKwh={dailyYieldKwh}
          performanceRatioPercent={performanceRatioPercent}
          isCollapsed={isRightPanelCollapsed}
          onToggleCollapse={() => setIsRightPanelCollapsed(!isRightPanelCollapsed)}
        />
      </main>

      {/* 4. Deep Analysis Modals */}
      <PhysicsCurveModal
        isOpen={isPhysicsModalOpen}
        onClose={() => setIsPhysicsModalOpen(false)}
        initialModule={selectedModule}
      />

      <SolarFarmScaleModal
        isOpen={isScaleModalOpen}
        onClose={() => setIsScaleModalOpen(false)}
        currentScale={arrayScale}
        onSelectScale={handleScaleChange}
        activeFidelity={activeFidelity}
        onSelectFidelity={setActiveFidelity}
      />

      <AnalyticsFinancialModal
        isOpen={isFinancialsModalOpen}
        onClose={() => setIsFinancialsModalOpen(false)}
        systemCapacityDcKw={totalDcPowerKw}
        batteryCapacityKwh={selectedBattery.capacityKwh}
        isTracking={trackingMode === 'single_axis'}
        isBifacial={selectedModule.bifacialityFactor > 0}
        bifacialGainPercent={bifacial.bifacialGainPercent}
      />

      <ReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        location={selectedLocation}
        moduleSpecs={selectedModule}
        modulesCount={modulesCount}
        inverterSpecs={selectedInverter}
        batterySpecs={selectedBattery}
        trackingMode={trackingMode}
        tiltAngle={tiltAngle}
        azimuthAngle={azimuthAngle}
        performanceRatioPercent={performanceRatioPercent}
        dailyYieldKwh={dailyYieldKwh}
      />
    </div>
  );
}
