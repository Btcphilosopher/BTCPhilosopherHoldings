/**
 * AUREOM SOLAR — Grid Integration & Facility Energy Balance
 * Implements conservation of energy balance across PV generation,
 * facility electrical load, battery dispatch, and bidirectional grid tie.
 *
 * Law of Conservation of Energy:
 *   P_pv_ac + P_battery_discharge + P_grid_import =
 *   P_facility_load + P_battery_charge + P_grid_export + P_curtailed
 */

export type FacilityType = 'residential' | 'commercial_office' | 'industrial_plant';

export interface GridParameters {
  pvAcPowerKw: number;
  facilityType: FacilityType;
  baseLoadKw: number;
  timeOfDayHours: number; // 0.0 - 24.0
  batteryChargeKw: number;
  batteryDischargeKw: number;
  maxGridExportLimitKw?: number; // Inverter export curtailment cap
  importTariffPerKwh?: number; // e.g. $0.28 / kWh peak, $0.14 off-peak
  exportFeedInTariffPerKwh?: number; // e.g. $0.08 / kWh
}

export interface GridBalanceResult {
  facilityLoadKw: number;
  pvToLoadKw: number;
  pvToBatteryKw: number;
  pvToGridKw: number;
  batteryToLoadKw: number;
  batteryToGridKw: number;
  gridImportKw: number;
  gridExportKw: number;
  curtailedPowerKw: number;
  selfConsumptionRatioPercent: number; // % of PV used on-site (direct + battery)
  selfSufficiencyRatioPercent: number; // % of facility load supplied by on-site assets
  instantaneousNetCostPerHour: number; // $ / hr (+ cost, - revenue)
  isEnergyConserved: boolean;
}

export function calculateGridBalance(params: GridParameters): GridBalanceResult {
  const {
    pvAcPowerKw,
    facilityType,
    baseLoadKw,
    timeOfDayHours,
    batteryChargeKw,
    batteryDischargeKw,
    maxGridExportLimitKw = Infinity,
    importTariffPerKwh = 0.22,
    exportFeedInTariffPerKwh = 0.07,
  } = params;

  // Typical diurnal profile multiplier by facility archetype
  let loadMultiplier = 1.0;
  if (facilityType === 'residential') {
    // Morning peak (07:00-09:00) and evening peak (17:00-22:00)
    if (timeOfDayHours >= 6.5 && timeOfDayHours <= 9) loadMultiplier = 1.35;
    else if (timeOfDayHours >= 17 && timeOfDayHours <= 22) loadMultiplier = 1.85;
    else if (timeOfDayHours >= 23 || timeOfDayHours <= 5.5) loadMultiplier = 0.35;
    else loadMultiplier = 0.65;
  } else if (facilityType === 'commercial_office') {
    // Business hours peak (08:00 - 18:00), night baseload
    if (timeOfDayHours >= 8 && timeOfDayHours <= 18) loadMultiplier = 1.6;
    else loadMultiplier = 0.25;
  } else {
    // Industrial plant: steady continuous load with slight shift variations
    if (timeOfDayHours >= 6 && timeOfDayHours <= 22) loadMultiplier = 1.3;
    else loadMultiplier = 0.9;
  }

  const facilityLoadKw = baseLoadKw * loadMultiplier;

  // Power flow allocations
  // 1. Direct PV supply to facility load
  const pvToLoadKw = Math.min(pvAcPowerKw, facilityLoadKw);
  let remainingPvKw = pvAcPowerKw - pvToLoadKw;
  let remainingLoadKw = facilityLoadKw - pvToLoadKw;

  // 2. PV to battery charging
  const pvToBatteryKw = Math.min(remainingPvKw, batteryChargeKw);
  remainingPvKw -= pvToBatteryKw;

  // 3. Battery to remaining load
  const batteryToLoadKw = Math.min(remainingLoadKw, batteryDischargeKw);
  remainingLoadKw -= batteryToLoadKw;
  const remainingBatteryDischargeKw = batteryDischargeKw - batteryToLoadKw;

  // 4. Excess PV export to grid (subject to grid limit)
  let rawExportKw = remainingPvKw + remainingBatteryDischargeKw;
  let gridExportKw = Math.min(rawExportKw, maxGridExportLimitKw);
  let curtailedPowerKw = Math.max(0, rawExportKw - maxGridExportLimitKw);

  const pvToGridKw = Math.min(remainingPvKw, gridExportKw);
  const batteryToGridKw = Math.max(0, gridExportKw - pvToGridKw);

  // 5. Remaining unmet load covered by utility grid import
  const gridImportKw = remainingLoadKw;

  // Conservation check: Sources = Sinks
  const totalSources = pvAcPowerKw + batteryDischargeKw + gridImportKw;
  const totalSinks = facilityLoadKw + batteryChargeKw + gridExportKw + curtailedPowerKw;
  const isEnergyConserved = Math.abs(totalSources - totalSinks) < 0.05;

  // Metrics
  const totalPvUsedOnSite = pvToLoadKw + pvToBatteryKw;
  const selfConsumptionRatioPercent =
    pvAcPowerKw > 0 ? (totalPvUsedOnSite / pvAcPowerKw) * 100 : 100;

  const totalLoadSuppliedOnSite = pvToLoadKw + batteryToLoadKw;
  const selfSufficiencyRatioPercent =
    facilityLoadKw > 0 ? (totalLoadSuppliedOnSite / facilityLoadKw) * 100 : 100;

  const costImport = gridImportKw * importTariffPerKwh;
  const revenueExport = gridExportKw * exportFeedInTariffPerKwh;
  const instantaneousNetCostPerHour = costImport - revenueExport;

  return {
    facilityLoadKw: Number(facilityLoadKw.toFixed(2)),
    pvToLoadKw: Number(pvToLoadKw.toFixed(2)),
    pvToBatteryKw: Number(pvToBatteryKw.toFixed(2)),
    pvToGridKw: Number(pvToGridKw.toFixed(2)),
    batteryToLoadKw: Number(batteryToLoadKw.toFixed(2)),
    batteryToGridKw: Number(batteryToGridKw.toFixed(2)),
    gridImportKw: Number(gridImportKw.toFixed(2)),
    gridExportKw: Number(gridExportKw.toFixed(2)),
    curtailedPowerKw: Number(curtailedPowerKw.toFixed(2)),
    selfConsumptionRatioPercent: Math.min(100, Math.max(0, Number(selfConsumptionRatioPercent.toFixed(1)))),
    selfSufficiencyRatioPercent: Math.min(100, Math.max(0, Number(selfSufficiencyRatioPercent.toFixed(1)))),
    instantaneousNetCostPerHour: Number(instantaneousNetCostPerHour.toFixed(2)),
    isEnergyConserved,
  };
}
