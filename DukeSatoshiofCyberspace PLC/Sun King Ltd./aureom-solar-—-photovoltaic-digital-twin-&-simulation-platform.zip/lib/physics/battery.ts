/**
 * AUREOM SOLAR — Battery Energy Storage System (BESS) Digital Twin
 * Implements LFP and NMC battery storage dynamics, state-of-charge tracking,
 * C-rate power limits, round-trip efficiency, and dispatch strategies.
 */

export type BatteryChemistry = 'LFP' | 'NMC';
export type DispatchStrategy = 'self_consumption' | 'peak_shaving' | 'tou_arbitrage' | 'backup_reserve';

export interface BatterySpecs {
  id: string;
  name: string;
  chemistry: BatteryChemistry;
  capacityKwh: number; // Total nominal energy capacity (kWh)
  usableMinSoc: number; // e.g. 10% minimum state-of-charge
  usableMaxSoc: number; // e.g. 95% maximum state-of-charge
  maxChargeCRate: number; // e.g. 0.5C -> max charge kW = 0.5 * capacity
  maxDischargeCRate: number; // e.g. 1.0C
  roundTripEfficiencyPercent: number; // e.g. 92%
  cycleLifeTo80Percent: number; // e.g. 6000 cycles for LFP, 3500 for NMC
}

export const BATTERY_PRESETS: Record<string, BatterySpecs> = {
  'lfp-100kwh': {
    id: 'lfp-100kwh',
    name: 'Aureom TitanPack 100 kWh LFP',
    chemistry: 'LFP',
    capacityKwh: 100,
    usableMinSoc: 10,
    usableMaxSoc: 95,
    maxChargeCRate: 0.5,
    maxDischargeCRate: 1.0,
    roundTripEfficiencyPercent: 92.5,
    cycleLifeTo80Percent: 6500,
  },
  'lfp-2000kwh': {
    id: 'lfp-2000kwh',
    name: 'Aureom MegaBESS 2.0 MWh Utility LFP',
    chemistry: 'LFP',
    capacityKwh: 2000,
    usableMinSoc: 10,
    usableMaxSoc: 95,
    maxChargeCRate: 0.5,
    maxDischargeCRate: 1.0,
    roundTripEfficiencyPercent: 93.0,
    cycleLifeTo80Percent: 7000,
  },
  'nmc-20kwh': {
    id: 'nmc-20kwh',
    name: 'Aureom CompactNMC 20 kWh High-C',
    chemistry: 'NMC',
    capacityKwh: 20,
    usableMinSoc: 15,
    usableMaxSoc: 90,
    maxChargeCRate: 1.0,
    maxDischargeCRate: 2.0,
    roundTripEfficiencyPercent: 94.0,
    cycleLifeTo80Percent: 4000,
  },
};

export interface BatteryDispatchInput {
  specs: BatterySpecs;
  currentSocPercent: number; // 0 - 100%
  strategy: DispatchStrategy;
  pvGenerationKw: number;
  facilityLoadKw: number;
  timeOfDayHours: number; // 0.0 - 24.0
  gridElectricityPricePerKwh?: number;
  timeStepHours?: number; // e.g. 1.0 or 0.25 (15 min)
}

export interface BatteryDispatchResult {
  chargePowerKw: number; // kW power flowing into battery
  dischargePowerKw: number; // kW power discharging from battery
  netBatteryFlowKw: number; // positive = charging, negative = discharging
  newSocPercent: number;
  storedEnergyKwh: number;
  usableRemainingKwh: number;
  strategyActionSummary: string;
}

export function simulateBatteryStep(input: BatteryDispatchInput): BatteryDispatchResult {
  const {
    specs,
    currentSocPercent,
    strategy,
    pvGenerationKw,
    facilityLoadKw,
    timeOfDayHours,
    timeStepHours = 1.0,
  } = input;

  const oneWayEfficiency = Math.sqrt(specs.roundTripEfficiencyPercent / 100);
  const maxChargeKw = specs.capacityKwh * specs.maxChargeCRate;
  const maxDischargeKw = specs.capacityKwh * specs.maxDischargeCRate;

  const currentEnergyKwh = (currentSocPercent / 100) * specs.capacityKwh;
  const minAllowedEnergyKwh = (specs.usableMinSoc / 100) * specs.capacityKwh;
  const maxAllowedEnergyKwh = (specs.usableMaxSoc / 100) * specs.capacityKwh;

  const netPowerSurplusKw = pvGenerationKw - facilityLoadKw;

  let desiredChargeKw = 0;
  let desiredDischargeKw = 0;
  let strategyAction = 'Idle';

  switch (strategy) {
    case 'self_consumption': {
      if (netPowerSurplusKw > 0) {
        // Excess solar generation -> charge battery
        desiredChargeKw = Math.min(netPowerSurplusKw, maxChargeKw);
        strategyAction = 'Absorbing surplus PV generation';
      } else if (netPowerSurplusKw < 0) {
        // Load exceeds solar -> discharge to cover deficit
        const deficitKw = -netPowerSurplusKw;
        desiredDischargeKw = Math.min(deficitKw, maxDischargeKw);
        strategyAction = 'Discharging to cover facility load';
      }
      break;
    }

    case 'peak_shaving': {
      // Peak tariff period typically 16:00 to 20:00
      const isPeakHours = timeOfDayHours >= 16 && timeOfDayHours <= 20;
      if (isPeakHours && facilityLoadKw > 0) {
        desiredDischargeKw = Math.min(facilityLoadKw, maxDischargeKw);
        strategyAction = 'Peak shaving discharge during high-demand window';
      } else if (netPowerSurplusKw > 0) {
        desiredChargeKw = Math.min(netPowerSurplusKw, maxChargeKw);
        strategyAction = 'Charging from PV ahead of peak window';
      }
      break;
    }

    case 'tou_arbitrage': {
      // Off-peak low cost: 00:00 - 06:00 and peak solar: 11:00 - 14:00
      // High export peak: 17:00 - 21:00
      const isHighTariffPeriod = timeOfDayHours >= 17 && timeOfDayHours <= 21;
      const isSolarSurplusPeriod = timeOfDayHours >= 10 && timeOfDayHours <= 15;

      if (isHighTariffPeriod) {
        desiredDischargeKw = maxDischargeKw * 0.9;
        strategyAction = 'High tariff energy export / discharge';
      } else if (isSolarSurplusPeriod && netPowerSurplusKw > 0) {
        desiredChargeKw = Math.min(netPowerSurplusKw, maxChargeKw);
        strategyAction = 'Solar arbitrage charging';
      }
      break;
    }

    case 'backup_reserve': {
      // Maintain minimum 50% SOC
      const reserveSoc = 50;
      if (currentSocPercent < reserveSoc && netPowerSurplusKw > 0) {
        desiredChargeKw = Math.min(netPowerSurplusKw, maxChargeKw);
        strategyAction = 'Replenishing emergency backup reserve';
      } else if (netPowerSurplusKw > 0) {
        desiredChargeKw = Math.min(netPowerSurplusKw, maxChargeKw);
        strategyAction = 'Charging beyond backup threshold';
      } else if (netPowerSurplusKw < 0 && currentSocPercent > reserveSoc) {
        desiredDischargeKw = Math.min(-netPowerSurplusKw, maxDischargeKw);
        strategyAction = 'Discharging while protecting backup reserve';
      }
      break;
    }
  }

  // Constrain charge by maximum capacity room
  const availableChargeCapacityKwh = Math.max(0, maxAllowedEnergyKwh - currentEnergyKwh);
  const maxPossibleChargeKw = availableChargeCapacityKwh / (oneWayEfficiency * timeStepHours);
  const actualChargeKw = Math.min(desiredChargeKw, maxPossibleChargeKw);

  // Constrain discharge by remaining energy above minimum SOC
  const availableDischargeEnergyKwh = Math.max(0, currentEnergyKwh - minAllowedEnergyKwh);
  const maxPossibleDischargeKw = (availableDischargeEnergyKwh * oneWayEfficiency) / timeStepHours;
  const actualDischargeKw = Math.min(desiredDischargeKw, maxPossibleDischargeKw);

  // Compute energy change
  const energyAddedKwh = actualChargeKw * oneWayEfficiency * timeStepHours;
  const energyRemovedKwh = (actualDischargeKw / oneWayEfficiency) * timeStepHours;
  const newEnergyKwh = Math.max(
    minAllowedEnergyKwh,
    Math.min(maxAllowedEnergyKwh, currentEnergyKwh + energyAddedKwh - energyRemovedKwh)
  );
  const newSocPercent = (newEnergyKwh / specs.capacityKwh) * 100;

  const netBatteryFlowKw = actualChargeKw - actualDischargeKw;
  const usableRemainingKwh = Math.max(0, newEnergyKwh - minAllowedEnergyKwh);

  return {
    chargePowerKw: Number(actualChargeKw.toFixed(2)),
    dischargePowerKw: Number(actualDischargeKw.toFixed(2)),
    netBatteryFlowKw: Number(netBatteryFlowKw.toFixed(2)),
    newSocPercent: Number(newSocPercent.toFixed(1)),
    storedEnergyKwh: Number(newEnergyKwh.toFixed(1)),
    usableRemainingKwh: Number(usableRemainingKwh.toFixed(1)),
    strategyActionSummary: strategyAction,
  };
}
