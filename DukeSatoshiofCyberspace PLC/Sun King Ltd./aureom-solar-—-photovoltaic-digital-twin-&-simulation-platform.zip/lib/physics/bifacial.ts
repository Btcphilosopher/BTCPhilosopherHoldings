/**
 * AUREOM SOLAR — Bifacial Solar Modelling Engine
 * Implements 2D view-factor model for rear-side irradiance and bifacial gain.
 */

export interface BifacialInput {
  frontPoa: number; // W/m^2 front-side Plane-of-Array irradiance
  ghi: number; // W/m^2 Global Horizontal Irradiance
  dhi: number; // W/m^2 Diffuse Horizontal Irradiance
  tilt: number; // degrees
  clearanceHeightMeters: number; // Ground clearance height H (e.g. 1.0m - 1.8m)
  rowPitchMeters: number; // Pitch distance between rows (e.g. 5.5m - 8.0m)
  moduleWidthMeters: number; // Collector width W (e.g. 2.28m)
  albedo: number; // Ground albedo reflectance (0.15 - 0.85)
  bifacialityFactor: number; // Module bifaciality coefficient (e.g. 0.80 for TOPCon, 0.88 for HJT)
  rackingStructureLossPercent?: number; // Shading from torque tubes, purlins (typically 3 - 6%)
}

export interface BifacialResult {
  rearIrradiance: number; // W/m^2 rear-side incident irradiance
  effectiveRearIrradiance: number; // W/m^2 effective rear power after bifaciality factor & structure loss
  totalEffectiveIrradiance: number; // W/m^2 front + effective rear
  bifacialGainPercent: number; // % generation increase over monofacial
  groundViewFactor: number; // dimensionless view factor to ground
  skyViewFactor: number; // dimensionless view factor to sky
}

const DEG_TO_RAD = Math.PI / 180;

export function calculateBifacialGain(input: BifacialInput): BifacialResult {
  const {
    frontPoa,
    ghi,
    dhi,
    tilt,
    clearanceHeightMeters,
    rowPitchMeters,
    moduleWidthMeters,
    albedo,
    bifacialityFactor,
    rackingStructureLossPercent = 4.0,
  } = input;

  if (frontPoa <= 1 || bifacialityFactor <= 0) {
    return {
      rearIrradiance: 0,
      effectiveRearIrradiance: 0,
      totalEffectiveIrradiance: frontPoa,
      bifacialGainPercent: 0,
      groundViewFactor: 0,
      skyViewFactor: 0,
    };
  }

  const tiltRad = tilt * DEG_TO_RAD;

  // View factors for rear face:
  // Rear face looks primarily towards the ground under and between rows, plus horizon sky behind.
  // 1. Sky view factor for rear surface: (1 - cos(pi - tilt)) / 2 = (1 + cos(tilt)) / 2
  const skyViewFactor = Math.max(0, Math.min(1, (1 - Math.cos(tiltRad)) / 2));

  // 2. Ground view factor for rear surface: (1 + cos(tilt)) / 2
  // Height and pitch clearance factor modifies shadow illumination under the array
  const heightRatio = clearanceHeightMeters / moduleWidthMeters;
  const pitchRatio = rowPitchMeters / moduleWidthMeters;
  const heightCorrection = Math.min(1.2, 0.75 + 0.3 * Math.log10(Math.max(0.5, heightRatio + 0.5)));
  const pitchCorrection = Math.min(1.15, 0.8 + 0.15 * Math.log10(Math.max(1, pitchRatio)));

  const baseGroundView = (1 + Math.cos(tiltRad)) / 2;
  const groundViewFactor = Math.max(0, Math.min(1, baseGroundView * heightCorrection * pitchCorrection * 0.85));

  // Reflected ground irradiance received by rear face:
  // GHI * albedo * groundViewFactor
  const rearGroundReflected = ghi * albedo * groundViewFactor;

  // Diffuse sky irradiance received by rear face:
  // DHI * skyViewFactor * 0.5
  const rearSkyDiffuse = dhi * skyViewFactor * 0.45;

  const rearIrradiance = Math.max(0, rearGroundReflected + rearSkyDiffuse);

  // Apply racking structure shading loss & module bifaciality
  const structureFactor = (100 - rackingStructureLossPercent) / 100;
  const effectiveRearIrradiance = rearIrradiance * bifacialityFactor * structureFactor;

  const totalEffectiveIrradiance = frontPoa + effectiveRearIrradiance;
  const bifacialGainPercent = (effectiveRearIrradiance / frontPoa) * 100;

  return {
    rearIrradiance: Number(rearIrradiance.toFixed(1)),
    effectiveRearIrradiance: Number(effectiveRearIrradiance.toFixed(1)),
    totalEffectiveIrradiance: Number(totalEffectiveIrradiance.toFixed(1)),
    bifacialGainPercent: Number(bifacialGainPercent.toFixed(2)),
    groundViewFactor: Number(groundViewFactor.toFixed(3)),
    skyViewFactor: Number(skyViewFactor.toFixed(3)),
  };
}
