/**
 * AUREOM SOLAR — Thermal Digital Twin
 * Implements Faiman and Sandia (King) photovoltaic thermal models
 * to calculate cell temperature, module backsheet temperature,
 * thermal losses, and calibrated false-color thermography values.
 */

export type MountingType = 'open_rack' | 'roof_flush' | 'single_axis_tracker' | 'carport_canopy';

export interface ThermalParameters {
  mountingType: MountingType;
  ambientTemperatureC: number; // °C
  poaIrradiance: number; // W/m^2
  windSpeedMs: number; // m/s at 10m height
  cellToBacksheetDelta?: number; // °C (typically 2-3 °C at 1000 W/m^2)
  model?: 'faiman' | 'sapm';
}

export interface ThermalResult {
  cellTemperatureC: number;
  backsheetTemperatureC: number;
  thermalDeratingPercent: number; // % loss in power relative to 25°C STC
  convectiveCoolingLossWatts: number;
  thermographicColorHex: string; // RGB hex for 3D heatmap rendering
  normalizedHeatValue: number; // 0.0 to 1.0 (for shader uniforms)
}

// Empirical coefficients from King / Sandia SAPM & Faiman standards
const FAIMAN_COEFFS: Record<MountingType, { u0: number; u1: number }> = {
  open_rack: { u0: 25.0, u1: 6.84 },
  single_axis_tracker: { u0: 26.5, u1: 7.20 },
  carport_canopy: { u0: 22.0, u1: 5.50 },
  roof_flush: { u0: 15.0, u1: 3.00 },
};

const SAPM_COEFFS: Record<MountingType, { a: number; b: number; deltaT: number }> = {
  open_rack: { a: -3.47, b: -0.0594, deltaT: 3 },
  single_axis_tracker: { a: -3.56, b: -0.0750, deltaT: 3 },
  carport_canopy: { a: -3.35, b: -0.0520, deltaT: 3.5 },
  roof_flush: { a: -2.98, b: -0.0471, deltaT: 1 },
};

/**
 * Calculates PV cell operating temperature and thermal derating.
 */
export function calculateThermalState(params: ThermalParameters, gammaPmp: number = -0.30): ThermalResult {
  const {
    mountingType,
    ambientTemperatureC,
    poaIrradiance,
    windSpeedMs,
    model = 'faiman',
  } = params;

  let cellTemp = ambientTemperatureC;
  let backsheetTemp = ambientTemperatureC;

  if (poaIrradiance > 5) {
    if (model === 'faiman') {
      const { u0, u1 } = FAIMAN_COEFFS[mountingType];
      const heatFlux = u0 + u1 * windSpeedMs;
      const deltaTemp = poaIrradiance / Math.max(5, heatFlux);
      cellTemp = ambientTemperatureC + deltaTemp;
      backsheetTemp = cellTemp - 2.5 * (poaIrradiance / 1000);
    } else {
      const { a, b, deltaT } = SAPM_COEFFS[mountingType];
      const modTemp =
        ambientTemperatureC +
        poaIrradiance * Math.exp(a + b * windSpeedMs);
      cellTemp = modTemp + (poaIrradiance / 1000) * deltaT;
      backsheetTemp = modTemp;
    }
  }

  // Thermal derating relative to 25°C STC
  const deltaTFromStc = cellTemp - 25.0;
  const thermalDeratingPercent = (deltaTFromStc * gammaPmp); // negative value means loss

  // Convective cooling power estimate (W per m^2)
  const convectiveCoolingLossWatts = Math.max(0, (cellTemp - ambientTemperatureC) * 12.5);

  // Map cell temperature (20°C - 75°C) to calibrated thermographic false color (Ironbow / FLIR palette)
  // Low: Deep navy (#172735) -> Cyan (#53B6CA) -> Amber (#E9A83B) -> Infrared Crimson (#D95D57)
  const tMin = 20;
  const tMax = 75;
  const normalized = Math.max(0, Math.min(1, (cellTemp - tMin) / (tMax - tMin)));

  let hex = '#172735';
  if (normalized < 0.25) {
    // Deep navy to electrical cyan
    const r = Math.round(23 + (83 - 23) * (normalized / 0.25));
    const g = Math.round(39 + (182 - 39) * (normalized / 0.25));
    const b = Math.round(53 + (202 - 53) * (normalized / 0.25));
    hex = `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
  } else if (normalized < 0.65) {
    // Cyan to Solar amber
    const factor = (normalized - 0.25) / 0.40;
    const r = Math.round(83 + (233 - 83) * factor);
    const g = Math.round(182 + (168 - 182) * factor);
    const b = Math.round(202 + (59 - 202) * factor);
    hex = `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
  } else {
    // Amber to Alert red
    const factor = (normalized - 0.65) / 0.35;
    const r = Math.round(233 + (217 - 233) * factor);
    const g = Math.round(168 + (93 - 168) * factor);
    const b = Math.round(59 + (87 - 59) * factor);
    hex = `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
  }

  return {
    cellTemperatureC: Number(cellTemp.toFixed(1)),
    backsheetTemperatureC: Number(backsheetTemp.toFixed(1)),
    thermalDeratingPercent: Number(thermalDeratingPercent.toFixed(2)),
    convectiveCoolingLossWatts: Number(convectiveCoolingLossWatts.toFixed(1)),
    thermographicColorHex: hex,
    normalizedHeatValue: normalized,
  };
}
