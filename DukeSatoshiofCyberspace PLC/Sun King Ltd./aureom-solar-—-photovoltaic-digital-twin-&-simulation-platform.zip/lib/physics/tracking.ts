/**
 * AUREOM SOLAR — Solar Tracking Systems & Backtracking Engine
 * Implements Fixed-Tilt, Horizontal Single-Axis Tracking (HSAT) with
 * Passias-Källbäck astronomical backtracking to eliminate inter-row shading,
 * and Dual-Axis Tracking.
 */

import { SolarPositionResult } from './solar-position';

export type TrackingMode = 'fixed' | 'single_axis' | 'dual_axis';

export interface TrackingInput {
  mode: TrackingMode;
  solarPos: SolarPositionResult;
  fixedTilt: number; // degrees (for fixed mode)
  fixedAzimuth: number; // degrees (for fixed mode)
  axisAzimuth?: number; // degrees (typically 180 for N-S tracker axis)
  maxRotationAngle?: number; // degrees (typically 55° or 60°)
  groundCoverageRatio: number; // GCR = Module Width / Row Pitch (0.25 to 0.50)
  enableBacktracking?: boolean;
}

export interface TrackingResult {
  actualTilt: number; // degrees from horizontal
  actualAzimuth: number; // degrees from North
  rotationAngle: number; // degrees tracker rotation (-60° East to +60° West)
  isBacktracking: boolean;
  shadingLossFactor: number; // 0.0 (no shading) to 1.0 (fully shaded)
  geometricShadingAngle: number; // angle below which inter-row shadow falls
}

const DEG_TO_RAD = Math.PI / 180;
const RAD_TO_DEG = 180 / Math.PI;

export function calculateTrackerOrientation(input: TrackingInput): TrackingResult {
  const {
    mode,
    solarPos,
    fixedTilt,
    fixedAzimuth,
    axisAzimuth = 180, // North-South torque tube axis
    maxRotationAngle = 60,
    groundCoverageRatio,
    enableBacktracking = true,
  } = input;

  if (mode === 'fixed') {
    return {
      actualTilt: fixedTilt,
      actualAzimuth: fixedAzimuth,
      rotationAngle: 0,
      isBacktracking: false,
      shadingLossFactor: 0,
      geometricShadingAngle: 0,
    };
  }

  if (mode === 'dual_axis') {
    if (!solarPos.isDaylight || solarPos.elevation <= 0) {
      return {
        actualTilt: 0,
        actualAzimuth: fixedAzimuth,
        rotationAngle: 0,
        isBacktracking: false,
        shadingLossFactor: 0,
        geometricShadingAngle: 0,
      };
    }
    return {
      actualTilt: Math.max(0, Math.min(90, 90 - solarPos.elevation)),
      actualAzimuth: solarPos.azimuth,
      rotationAngle: 0,
      isBacktracking: false,
      shadingLossFactor: 0,
      geometricShadingAngle: 0,
    };
  }

  // Horizontal Single-Axis Tracker (HSAT) with North-South axis
  if (!solarPos.isDaylight || solarPos.elevation <= 0) {
    // Night stow position (typically flat 0° or safe wind stow)
    return {
      actualTilt: 0,
      actualAzimuth: axisAzimuth + 90,
      rotationAngle: 0,
      isBacktracking: false,
      shadingLossFactor: 0,
      geometricShadingAngle: 0,
    };
  }

  const zenRad = solarPos.zenith * DEG_TO_RAD;
  const azDiffRad = (solarPos.azimuth - axisAzimuth) * DEG_TO_RAD;

  // True tracking angle (rotation from horizontal)
  // tan(phi_true) = tan(zenith) * sin(solarAzimuth - axisAzimuth)
  const tanPhiTrue = Math.tan(zenRad) * Math.sin(azDiffRad);
  let trueRotationAngle = Math.atan(tanPhiTrue) * RAD_TO_DEG;

  let finalRotation = trueRotationAngle;
  let isBacktracking = false;

  // Astronomical Backtracking algorithm:
  // When sun is low, inter-row shadows occur if tracker follows true sun position.
  // Backtracking rotates the tracker back toward horizontal (reducing tilt)
  // so that the shadow cast by one row hits precisely the torque tube or bottom edge of the next row.
  if (enableBacktracking && groundCoverageRatio > 0) {
    const cosZen = Math.cos(zenRad);
    const gcr = Math.max(0.1, Math.min(0.9, groundCoverageRatio));

    // Critical ratio for mutual shading
    // Check if true rotation angle causes shading
    const trueRotRad = trueRotationAngle * DEG_TO_RAD;
    const projectedPitch = (1 / gcr) * Math.cos(trueRotRad);

    if (Math.abs(trueRotationAngle) > 0.1) {
      const sinRot = Math.sin(trueRotRad);
      // Backtracking condition: if |sin(phi)| exceeds (1/GCR)*cos(theta_z)
      const backtrackArg = (1 / gcr) * (cosZen / Math.max(0.01, Math.cos(trueRotRad)));
      
      // Calculate shaded geometry
      if (Math.abs(sinRot) > Math.abs(backtrackArg) && backtrackArg > 0 && backtrackArg <= 1) {
        // Backtracking angle correction
        const backtrackAngleRad = Math.asin(backtrackArg);
        const backtrackAngleDeg = backtrackAngleRad * RAD_TO_DEG;

        // Apply corrective rotation towards horizontal
        const sign = trueRotationAngle > 0 ? 1 : -1;
        finalRotation = sign * (Math.abs(trueRotationAngle) - backtrackAngleDeg);
        isBacktracking = true;
      }
    }
  }

  // Enforce mechanical rotation limits
  if (finalRotation > maxRotationAngle) {
    finalRotation = maxRotationAngle;
  } else if (finalRotation < -maxRotationAngle) {
    finalRotation = -maxRotationAngle;
  }

  // Convert tracker rotation to effective tilt and azimuth:
  // For a N-S axis, tilt is |rotation|, azimuth is East (90°) when rotation < 0, West (270°) when rotation > 0
  const actualTilt = Math.abs(finalRotation);
  const actualAzimuth = finalRotation >= 0 ? (axisAzimuth + 90) % 360 : (axisAzimuth - 90 + 360) % 360;

  return {
    actualTilt,
    actualAzimuth,
    rotationAngle: Number(finalRotation.toFixed(2)),
    isBacktracking,
    shadingLossFactor: isBacktracking ? 0 : 0,
    geometricShadingAngle: Number(actualTilt.toFixed(1)),
  };
}
