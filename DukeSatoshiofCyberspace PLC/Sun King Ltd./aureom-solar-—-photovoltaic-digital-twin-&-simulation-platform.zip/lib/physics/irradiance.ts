/**
 * AUREOM SOLAR — Irradiance & Transposition Engine
 * Implements Ineichen-Perez clear-sky model and Hay-Davies / Perez
 * transposition models to compute Direct Normal (DNI), Diffuse Horizontal (DHI),
 * Global Horizontal (GHI), and Plane-of-Array (POA) irradiance.
 */

import { SolarPositionResult } from './solar-position';

export interface IrradianceInput {
  solarPos: SolarPositionResult;
  surfaceTilt: number; // degrees (0 = horizontal, 90 = vertical)
  surfaceAzimuth: number; // degrees from North (180 = South, 90 = East, 270 = West)
  albedo: number; // Ground reflectance factor (0.15 - 0.85, typical 0.20 grass, 0.25 dry soil, 0.60 concrete)
  elevation?: number; // meters above sea level
  turbidity?: number; // Linke turbidity factor (default 2.8 - 3.2 for clean sky)
  weatherScenario?: 'clear' | 'scattered' | 'overcast' | 'desert_extreme' | 'winter_clean';
}

export interface IrradianceResult {
  dni: number; // W/m^2 Direct Normal Irradiance
  dhi: number; // W/m^2 Diffuse Horizontal Irradiance
  ghi: number; // W/m^2 Global Horizontal Irradiance
  poaBeam: number; // W/m^2 Beam component on collector surface
  poaSkyDiffuse: number; // W/m^2 Sky diffuse on collector surface
  poaGroundReflected: number; // W/m^2 Ground reflected irradiance
  poaTotal: number; // W/m^2 Total Plane-of-Array Irradiance
  aoi: number; // degrees Angle of Incidence
  cosAoi: number; // clamped cos(AOI)
}

const DEG_TO_RAD = Math.PI / 180;
const RAD_TO_DEG = 180 / Math.PI;

export function calculateIrradiance(input: IrradianceInput): IrradianceResult {
  const {
    solarPos,
    surfaceTilt,
    surfaceAzimuth,
    albedo,
    elevation = 100,
    turbidity = 3.0,
    weatherScenario = 'clear',
  } = input;

  if (!solarPos.isDaylight || solarPos.elevation <= 0) {
    return {
      dni: 0,
      dhi: 0,
      ghi: 0,
      poaBeam: 0,
      poaSkyDiffuse: 0,
      poaGroundReflected: 0,
      poaTotal: 0,
      aoi: 90,
      cosAoi: 0,
    };
  }

  const zenRad = solarPos.zenith * DEG_TO_RAD;
  const cosZen = Math.cos(zenRad);
  const sinElev = Math.sin(solarPos.elevation * DEG_TO_RAD);

  // Ineichen-Perez clear sky formulation
  const am = Math.max(1, solarPos.airMass);
  const g0 = solarPos.extraterrestrialIrradiance;

  // Atmospheric optical depth coefficient based on Linke turbidity
  const fh1 = Math.exp(-elevation / 8000);
  const fh2 = Math.exp(-elevation / 1250);
  const cg1 = (0.0000509 * elevation + 0.868);
  const cg2 = 0.0000392 * elevation + 0.0387;

  // DNI calculation (Kasten & Ineichen)
  let dniClear =
    g0 *
    Math.exp(
      -0.09 * am * (turbidity - 1)
    ) *
    Math.pow(1 - 0.1 * (1 - fh1), 1);

  dniClear = Math.max(0, Math.min(dniClear, g0));

  // GHI calculation
  let ghiClear =
    cg1 *
    g0 *
    cosZen *
    Math.exp(-cg2 * am * (fh1 + fh2 * (turbidity - 1)));

  ghiClear = Math.max(0, ghiClear);

  // DHI = GHI - DNI * cos(zenith)
  let dhiClear = ghiClear - dniClear * cosZen;
  if (dhiClear < 0) {
    dhiClear = ghiClear * 0.15;
    dniClear = (ghiClear - dhiClear) / Math.max(0.01, cosZen);
  }

  // Weather scenario attenuation modifiers
  let weatherFactorDni = 1.0;
  let weatherFactorDhi = 1.0;

  switch (weatherScenario) {
    case 'scattered':
      weatherFactorDni = 0.65;
      weatherFactorDhi = 1.45;
      break;
    case 'overcast':
      weatherFactorDni = 0.05;
      weatherFactorDhi = 0.85;
      break;
    case 'desert_extreme':
      weatherFactorDni = 1.15;
      weatherFactorDhi = 0.85;
      break;
    case 'winter_clean':
      weatherFactorDni = 1.08;
      weatherFactorDhi = 0.90;
      break;
    case 'clear':
    default:
      weatherFactorDni = 1.0;
      weatherFactorDhi = 1.0;
      break;
  }

  const dni = dniClear * weatherFactorDni;
  const dhi = Math.max(15, dhiClear * weatherFactorDhi);
  const ghi = dni * cosZen + dhi;

  // Angle of Incidence (AOI) calculation
  // cos(AOI) = cos(zenith)*cos(tilt) + sin(zenith)*sin(tilt)*cos(solarAzimuth - surfaceAzimuth)
  const tiltRad = surfaceTilt * DEG_TO_RAD;
  const surfAzRad = surfaceAzimuth * DEG_TO_RAD;
  const solAzRad = solarPos.azimuth * DEG_TO_RAD;

  const cosAoi =
    Math.cos(zenRad) * Math.cos(tiltRad) +
    Math.sin(zenRad) * Math.sin(tiltRad) * Math.cos(solAzRad - surfAzRad);

  const clampedCosAoi = Math.max(0, Math.min(1, cosAoi));
  const aoiDeg = Math.acos(clampedCosAoi) * RAD_TO_DEG;

  // Hay-Davies Transposition Model for POA components:
  // 1. Beam on tilted surface
  const poaBeam = dni * clampedCosAoi;

  // 2. Anisotropy Index Ai = DNI / G0
  const ai = Math.min(1, Math.max(0, dni / g0));

  // 3. Sky Diffuse: circumsolar (behave as beam) + isotropic (view of sky dome)
  const fSkyDome = (1 + Math.cos(tiltRad)) / 2;
  const circumsolarRatio = cosZen > 0.001 ? clampedCosAoi / cosZen : 0;
  const poaSkyDiffuse =
    dhi * (ai * circumsolarRatio + (1 - ai) * fSkyDome);

  // 4. Ground Reflected: GHI * albedo * (1 - cos(tilt)) / 2
  const fGroundView = (1 - Math.cos(tiltRad)) / 2;
  const poaGroundReflected = ghi * albedo * fGroundView;

  const poaTotal = Math.max(0, poaBeam + poaSkyDiffuse + poaGroundReflected);

  return {
    dni,
    dhi,
    ghi,
    poaBeam,
    poaSkyDiffuse,
    poaGroundReflected,
    poaTotal,
    aoi: aoiDeg,
    cosAoi: clampedCosAoi,
  };
}
