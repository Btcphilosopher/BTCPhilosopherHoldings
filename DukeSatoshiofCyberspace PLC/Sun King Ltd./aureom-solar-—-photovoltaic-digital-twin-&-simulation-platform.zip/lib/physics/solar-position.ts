/**
 * AUREOM SOLAR — Astronomical Solar Position Engine
 * Implements high-precision solar geometry based on Michalsky (1988),
 * Spencer (1971), and Kasten & Young (1989) formulations (pvlib/NREL SPA equivalent).
 */

export interface SolarPositionInput {
  latitude: number; // degrees north (-90 to +90)
  longitude: number; // degrees east (-180 to +180)
  elevation: number; // meters above sea level
  date: Date; // UTC date and time
}

export interface SolarPositionResult {
  zenith: number; // degrees (0 at zenith, 90 at horizon)
  elevation: number; // degrees (90 at zenith, 0 at horizon)
  azimuth: number; // degrees (0 = North, 90 = East, 180 = South, 270 = West)
  declination: number; // degrees
  hourAngle: number; // degrees
  equationOfTime: number; // minutes
  airMass: number; // dimensionless relative optical air mass
  extraterrestrialIrradiance: number; // W/m^2 on normal surface
  isDaylight: boolean;
}

const DEG_TO_RAD = Math.PI / 180;
const RAD_TO_DEG = 180 / Math.PI;
const SOLAR_CONSTANT = 1361.2; // W/m^2 (Gsc)

export function calculateSolarPosition(input: SolarPositionInput): SolarPositionResult {
  const { latitude, longitude, elevation, date } = input;

  // Day of the year (1 - 366)
  const startOfYear = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  const diffMs = date.getTime() - startOfYear.getTime();
  const dayOfYear = Math.floor(diffMs / (1000 * 60 * 60 * 24)) + 1;

  // Fractional year in radians (gamma)
  const hourUtc =
    date.getUTCHours() +
    date.getUTCMinutes() / 60 +
    date.getUTCSeconds() / 3600 +
    date.getUTCMilliseconds() / 3600000;

  const gamma = (2 * Math.PI / 365) * (dayOfYear - 1 + (hourUtc - 12) / 24);

  // Equation of Time (minutes) - Spencer formula
  const eot =
    229.18 *
    (0.000075 +
      0.001868 * Math.cos(gamma) -
      0.032077 * Math.sin(gamma) -
      0.014615 * Math.cos(2 * gamma) -
      0.040849 * Math.sin(2 * gamma));

  // Solar Declination (radians) - Spencer formula
  const declinationRad =
    0.006918 -
    0.399912 * Math.cos(gamma) +
    0.070257 * Math.sin(gamma) -
    0.006758 * Math.cos(2 * gamma) +
    0.000907 * Math.sin(2 * gamma) -
    0.002697 * Math.cos(3 * gamma) +
    0.00148 * Math.sin(3 * gamma);

  const declinationDeg = declinationRad * RAD_TO_DEG;

  // True Solar Time (minutes)
  const timeOffset = eot + 4 * longitude;
  const trueSolarTime = hourUtc * 60 + timeOffset;

  // Solar Hour Angle (degrees, 0 at solar noon, negative in morning)
  let hourAngle = (trueSolarTime / 4) - 180;
  while (hourAngle < -180) hourAngle += 360;
  while (hourAngle > 180) hourAngle -= 360;
  const hourAngleRad = hourAngle * DEG_TO_RAD;

  const latRad = latitude * DEG_TO_RAD;

  // Solar Zenith Angle (cos theta_z = sin lat * sin dec + cos lat * cos dec * cos hra)
  const cosZenith =
    Math.sin(latRad) * Math.sin(declinationRad) +
    Math.cos(latRad) * Math.cos(declinationRad) * Math.cos(hourAngleRad);

  const clampedCosZenith = Math.max(-1, Math.min(1, cosZenith));
  const zenithRad = Math.acos(clampedCosZenith);
  const zenithDeg = zenithRad * RAD_TO_DEG;
  const elevationDeg = 90 - zenithDeg;

  // Solar Azimuth (degrees from North)
  let azimuthDeg = 180;
  if (zenithDeg < 89.99 && zenithDeg > 0.01) {
    const sinElevation = Math.sin(elevationDeg * DEG_TO_RAD);
    const cosElevation = Math.cos(elevationDeg * DEG_TO_RAD);
    const cosAzimuth =
      (Math.sin(declinationRad) - Math.sin(latRad) * sinElevation) /
      (Math.cos(latRad) * cosElevation);
    const clampedCosAz = Math.max(-1, Math.min(1, cosAzimuth));
    const rawAzimuth = Math.acos(clampedCosAz) * RAD_TO_DEG;

    if (hourAngle > 0) {
      azimuthDeg = (360 - rawAzimuth) % 360;
    } else {
      azimuthDeg = rawAzimuth;
    }
  }

  // Refraction correction for low elevations
  let refractedElevation = elevationDeg;
  if (elevationDeg > -1 && elevationDeg < 85) {
    // Bennett formula (1982)
    const r =
      (1.02 /
        Math.tan((elevationDeg + 10.3 / (elevationDeg + 5.11)) * DEG_TO_RAD)) /
      60;
    refractedElevation = elevationDeg + r;
  }

  const finalZenithDeg = Math.max(0, 90 - refractedElevation);
  const isDaylight = refractedElevation > -0.833; // Standard geometric sunset

  // Relative optical air mass - Kasten & Young (1989)
  let airMass = 0;
  if (refractedElevation > 0) {
    const zen = Math.min(finalZenithDeg, 89.9);
    airMass =
      1.0 /
      (Math.cos(zen * DEG_TO_RAD) +
        0.50572 * Math.pow(96.07995 - zen, -1.6364));
    // Pressure correction by elevation
    const pressureRatio = Math.exp(-elevation / 8434.5);
    airMass *= pressureRatio;
  }

  // Extraterrestrial Normal Irradiance (G0)
  const g0 =
    SOLAR_CONSTANT *
    (1 +
      0.033 *
        Math.cos((2 * Math.PI * dayOfYear) / 365));

  return {
    zenith: finalZenithDeg,
    elevation: refractedElevation,
    azimuth: azimuthDeg,
    declination: declinationDeg,
    hourAngle,
    equationOfTime: eot,
    airMass: Math.max(1, airMass),
    extraterrestrialIrradiance: g0,
    isDaylight,
  };
}
