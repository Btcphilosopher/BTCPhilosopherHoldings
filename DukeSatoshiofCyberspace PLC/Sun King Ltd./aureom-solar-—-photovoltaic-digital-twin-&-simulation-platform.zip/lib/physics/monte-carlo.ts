/**
 * AUREOM SOLAR — Statistical & Monte Carlo Uncertainty Engine (Layer B)
 * Models inter-annual solar resource variability, transposition model uncertainty,
 * soiling randomness, and calculates bankability exceedance probabilities (P50, P75, P90, P99).
 */

export interface MonteCarloInput {
  baseAnnualYieldKwh: number;
  interannualVariabilityPercent?: number; // GHI interannual variability (typically 3.5% - 5.5%)
  transpositionModelUncertaintyPercent?: number; // Typically 2.0% - 3.0%
  soilingUncertaintyPercent?: number; // Typically 1.5% - 2.5%
  measurementCalibrationUncertaintyPercent?: number; // Typically 1.0% - 1.8%
  iterations?: number; // Number of Monte Carlo draws (default 2,500)
}

export interface ExceedanceDistributionPoint {
  yieldKwh: number;
  probabilityDensity: number;
  exceedanceProbability: number; // 0.0 to 1.0
}

export interface MonteCarloResult {
  p50YieldKwh: number; // Expected median yield
  p75YieldKwh: number;
  p90YieldKwh: number; // Primary debt service / project finance benchmark
  p99YieldKwh: number; // Severe conservative downside
  compositeUncertaintyPercent: number; // Combined standard deviation sigma
  distribution: ExceedanceDistributionPoint[];
  p90ToP50Ratio: number;
}

// Box-Muller transform for standard normal random numbers
function generateStandardNormal(): number {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

export function runMonteCarloSimulation(input: MonteCarloInput): MonteCarloResult {
  const {
    baseAnnualYieldKwh,
    interannualVariabilityPercent = 4.5,
    transpositionModelUncertaintyPercent = 2.5,
    soilingUncertaintyPercent = 1.8,
    measurementCalibrationUncertaintyPercent = 1.2,
    iterations = 2500,
  } = input;

  // Root-sum-square combination of independent uncertainty sources
  const compositeSigmaPercent = Math.sqrt(
    Math.pow(interannualVariabilityPercent, 2) +
    Math.pow(transpositionModelUncertaintyPercent, 2) +
    Math.pow(soilingUncertaintyPercent, 2) +
    Math.pow(measurementCalibrationUncertaintyPercent, 2)
  );

  const sigmaKwh = baseAnnualYieldKwh * (compositeSigmaPercent / 100);

  // Analytical Gaussian exceedance values for bankability
  // Z-scores: P50 (0), P75 (-0.6745), P90 (-1.2816), P99 (-2.3263)
  const p50YieldKwh = Math.round(baseAnnualYieldKwh);
  const p75YieldKwh = Math.round(baseAnnualYieldKwh - 0.6745 * sigmaKwh);
  const p90YieldKwh = Math.round(baseAnnualYieldKwh - 1.2816 * sigmaKwh);
  const p99YieldKwh = Math.round(baseAnnualYieldKwh - 2.3263 * sigmaKwh);

  // Generate smooth distribution curve across -3 sigma to +3 sigma (41 bins)
  const distribution: ExceedanceDistributionPoint[] = [];
  const minYield = baseAnnualYieldKwh - 3.2 * sigmaKwh;
  const maxYield = baseAnnualYieldKwh + 3.2 * sigmaKwh;
  const steps = 40;
  const stepSize = (maxYield - minYield) / steps;

  for (let i = 0; i <= steps; i++) {
    const yVal = minYield + i * stepSize;
    const z = (yVal - baseAnnualYieldKwh) / sigmaKwh;
    // Normal probability density function
    const pdf = (1 / (sigmaKwh * Math.sqrt(2 * Math.PI))) * Math.exp(-0.5 * z * z);
    // Complementary cumulative distribution (exceedance probability)
    // 0.5 * erfc(z / sqrt(2))
    const exceedance = 0.5 * (1 - erf(z / Math.SQRT2));

    distribution.push({
      yieldKwh: Math.round(yVal),
      probabilityDensity: pdf * sigmaKwh * 100, // scaled for chart display
      exceedanceProbability: Number(exceedance.toFixed(3)),
    });
  }

  return {
    p50YieldKwh,
    p75YieldKwh,
    p90YieldKwh,
    p99YieldKwh,
    compositeUncertaintyPercent: Number(compositeSigmaPercent.toFixed(2)),
    distribution,
    p90ToP50Ratio: Number((p90YieldKwh / p50YieldKwh).toFixed(3)),
  };
}

// Approximation of the error function
function erf(x: number): number {
  const sign = x >= 0 ? 1 : -1;
  const a = Math.abs(x);
  // Constants for Abramowitz and Stegun formula 7.1.26
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const t = 1.0 / (1.0 + p * a);
  const y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-a * a);
  return sign * y;
}
