/**
 * AUREOM SOLAR — IEC 61724 Energy Loss Waterfall & Performance Ratio Engine
 * Calculates the sequential energy deratings from Nominal STC irradiance to final AC Grid injection.
 */

export interface LossTreeInput {
  nominalStcEnergyKwh: number;
  tiltGainPercent: number; // e.g. +14.2%
  bifacialGainPercent: number; // e.g. +8.5%
  iamReflectionLossPercent: number; // e.g. 2.4% (Incident Angle Modifier)
  shadingLossPercent: number; // e.g. 1.8%
  soilingLossPercent: number; // e.g. 2.1%
  thermalDeratingLossPercent: number; // e.g. 6.8%
  lidAndDegradationLossPercent: number; // e.g. 1.5%
  dcWiringMismatchLossPercent: number; // e.g. 1.2%
  inverterConversionLossPercent: number; // e.g. 1.8%
  inverterClippingLossPercent: number; // e.g. 0.6%
  acWiringTransformerLossPercent: number; // e.g. 1.0%
  unavailabilityOutagePercent?: number; // e.g. 0.5%
}

export interface LossStep {
  id: string;
  name: string;
  energyKwh: number;
  deltaKwh: number;
  percentageOfNominal: number;
  isGain: boolean;
  category: 'optical' | 'thermal' | 'electrical' | 'system';
}

export interface LossTreeResult {
  steps: LossStep[];
  finalAcYieldKwh: number;
  performanceRatioPercent: number; // PR = Actual AC Energy / (Nominal STC Capacity * Peak Sun Hours)
  totalLossPercentage: number;
}

export function calculateLossWaterfall(input: LossTreeInput): LossTreeResult {
  const {
    nominalStcEnergyKwh,
    tiltGainPercent,
    bifacialGainPercent,
    iamReflectionLossPercent,
    shadingLossPercent,
    soilingLossPercent,
    thermalDeratingLossPercent,
    lidAndDegradationLossPercent,
    dcWiringMismatchLossPercent,
    inverterConversionLossPercent,
    inverterClippingLossPercent,
    acWiringTransformerLossPercent,
    unavailabilityOutagePercent = 0.5,
  } = input;

  const steps: LossStep[] = [];
  let currentEnergy = nominalStcEnergyKwh;

  steps.push({
    id: 'stc_nominal',
    name: 'Nominal STC Potential',
    energyKwh: Math.round(currentEnergy),
    deltaKwh: 0,
    percentageOfNominal: 100,
    isGain: false,
    category: 'optical',
  });

  // Tilt & Orientation Gain
  const tiltGainKwh = currentEnergy * (tiltGainPercent / 100);
  currentEnergy += tiltGainKwh;
  steps.push({
    id: 'tilt_transposition',
    name: 'Array Tilt & Orientation Gain',
    energyKwh: Math.round(currentEnergy),
    deltaKwh: Math.round(tiltGainKwh),
    percentageOfNominal: Number((tiltGainPercent).toFixed(1)),
    isGain: true,
    category: 'optical',
  });

  // Bifacial Rear-Side Gain
  const bifacialKwh = currentEnergy * (bifacialGainPercent / 100);
  currentEnergy += bifacialKwh;
  steps.push({
    id: 'bifacial_gain',
    name: 'Bifacial Rear-Side Albedo Gain',
    energyKwh: Math.round(currentEnergy),
    deltaKwh: Math.round(bifacialKwh),
    percentageOfNominal: Number((bifacialGainPercent).toFixed(1)),
    isGain: true,
    category: 'optical',
  });

  // IAM Optical Reflection Loss
  const iamLossKwh = currentEnergy * (iamReflectionLossPercent / 100);
  currentEnergy -= iamLossKwh;
  steps.push({
    id: 'iam_reflection',
    name: 'Angle-of-Incidence (IAM) Reflection Loss',
    energyKwh: Math.round(currentEnergy),
    deltaKwh: -Math.round(iamLossKwh),
    percentageOfNominal: -Number((iamReflectionLossPercent).toFixed(1)),
    isGain: false,
    category: 'optical',
  });

  // Shading Loss
  const shadingLossKwh = currentEnergy * (shadingLossPercent / 100);
  currentEnergy -= shadingLossKwh;
  steps.push({
    id: 'shading',
    name: 'Row-to-Row & Obstacle Shading',
    energyKwh: Math.round(currentEnergy),
    deltaKwh: -Math.round(shadingLossKwh),
    percentageOfNominal: -Number((shadingLossPercent).toFixed(1)),
    isGain: false,
    category: 'optical',
  });

  // Soiling & Snow Loss
  const soilingKwh = currentEnergy * (soilingLossPercent / 100);
  currentEnergy -= soilingKwh;
  steps.push({
    id: 'soiling',
    name: 'Soiling, Dust & Atmospheric Haze',
    energyKwh: Math.round(currentEnergy),
    deltaKwh: -Math.round(soilingKwh),
    percentageOfNominal: -Number((soilingLossPercent).toFixed(1)),
    isGain: false,
    category: 'optical',
  });

  // Thermal Loss
  const thermalKwh = currentEnergy * (thermalDeratingLossPercent / 100);
  currentEnergy -= thermalKwh;
  steps.push({
    id: 'thermal',
    name: 'Cell Operating Temperature Derating',
    energyKwh: Math.round(currentEnergy),
    deltaKwh: -Math.round(thermalKwh),
    percentageOfNominal: -Number((thermalDeratingLossPercent).toFixed(1)),
    isGain: false,
    category: 'thermal',
  });

  // LID and Module Degradation
  const lidKwh = currentEnergy * (lidAndDegradationLossPercent / 100);
  currentEnergy -= lidKwh;
  steps.push({
    id: 'lid_degradation',
    name: 'Light-Induced Degradation & Mismatch',
    energyKwh: Math.round(currentEnergy),
    deltaKwh: -Math.round(lidKwh),
    percentageOfNominal: -Number((lidAndDegradationLossPercent).toFixed(1)),
    isGain: false,
    category: 'electrical',
  });

  // DC Cable Ohmic Resistance Loss
  const dcCableKwh = currentEnergy * (dcWiringMismatchLossPercent / 100);
  currentEnergy -= dcCableKwh;
  steps.push({
    id: 'dc_cabling',
    name: 'DC Cable Ohmic & String Mismatch',
    energyKwh: Math.round(currentEnergy),
    deltaKwh: -Math.round(dcCableKwh),
    percentageOfNominal: -Number((dcWiringMismatchLossPercent).toFixed(1)),
    isGain: false,
    category: 'electrical',
  });

  // Inverter Conversion Loss
  const invLossKwh = currentEnergy * (inverterConversionLossPercent / 100);
  currentEnergy -= invLossKwh;
  steps.push({
    id: 'inverter_conversion',
    name: 'Inverter Efficiency Loss',
    energyKwh: Math.round(currentEnergy),
    deltaKwh: -Math.round(invLossKwh),
    percentageOfNominal: -Number((inverterConversionLossPercent).toFixed(1)),
    isGain: false,
    category: 'electrical',
  });

  // Inverter Clipping Loss
  const clipLossKwh = currentEnergy * (inverterClippingLossPercent / 100);
  currentEnergy -= clipLossKwh;
  steps.push({
    id: 'inverter_clipping',
    name: 'Inverter Power Saturation Clipping',
    energyKwh: Math.round(currentEnergy),
    deltaKwh: -Math.round(clipLossKwh),
    percentageOfNominal: -Number((inverterClippingLossPercent).toFixed(1)),
    isGain: false,
    category: 'electrical',
  });

  // AC Cabling, Transformer & Substation Outage Loss
  const acLossKwh = currentEnergy * ((acWiringTransformerLossPercent + unavailabilityOutagePercent) / 100);
  currentEnergy -= acLossKwh;
  steps.push({
    id: 'ac_transformer_grid',
    name: 'MV Transformer & Grid Interconnect',
    energyKwh: Math.round(currentEnergy),
    deltaKwh: -Math.round(acLossKwh),
    percentageOfNominal: -Number((acWiringTransformerLossPercent + unavailabilityOutagePercent).toFixed(1)),
    isGain: false,
    category: 'system',
  });

  const finalAcYieldKwh = Math.round(currentEnergy);
  const performanceRatioPercent = Number(((finalAcYieldKwh / nominalStcEnergyKwh) * 100).toFixed(1));
  const totalLossPercentage = Number((100 - performanceRatioPercent).toFixed(1));

  return {
    steps,
    finalAcYieldKwh,
    performanceRatioPercent,
    totalLossPercentage,
  };
}
