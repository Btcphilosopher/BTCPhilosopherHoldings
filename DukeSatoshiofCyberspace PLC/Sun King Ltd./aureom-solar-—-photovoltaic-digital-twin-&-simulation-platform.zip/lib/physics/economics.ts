/**
 * AUREOM SOLAR — Economics, Financial Modelling & Degradation Analysis
 * Implements standard NREL / IEA photovoltaic financial models:
 * Levelized Cost of Energy (LCOE), Net Present Value (NPV), Internal Rate of Return (IRR),
 * 25-40 year degradation cash flow schedules, and capital expense breakdowns.
 */

export interface FinancialAssumptions {
  systemCapacityDcKw: number;
  annualGenerationYear1Kwh: number;
  batteryCapacityKwh: number;
  isTracking: boolean;
  isBifacial: boolean;
  electricityRetailRatePerKwh: number; // e.g. $0.20 / kWh
  exportFeedInTariffPerKwh: number; // e.g. $0.07 / kWh
  selfConsumptionPercent: number; // e.g. 70%
  discountRatePercent: number; // e.g. 6.5% real discount rate
  inflationRatePercent: number; // e.g. 2.0%
  projectLifetimeYears: number; // e.g. 25 or 30 years
  moduleDegradationYear1Percent: number; // e.g. 1.5% LID
  annualDegradationPercent: number; // e.g. 0.45% / year
  inverterReplacementYear: number; // e.g. Year 12
  inverterReplacementCostPerKw: number; // e.g. $60 / kW
}

export interface CapexBreakdown {
  modulesCost: number;
  invertersCost: number;
  rackingCost: number;
  electricalBosCost: number;
  batteryStorageCost: number;
  civilLaborCost: number;
  permittingGridTieCost: number;
  totalCapex: number;
  capexPerWattDc: number; // $/W_dc
}

export interface CashFlowYear {
  year: number;
  degradationFactor: number;
  annualGenerationKwh: number;
  grossRevenueSavings: number;
  opexCost: number;
  inverterReplacementCost: number;
  netCashFlow: number;
  discountedCashFlow: number;
  cumulativeCashFlow: number;
}

export interface FinancialResult {
  capex: CapexBreakdown;
  annualOpexYear1: number;
  lcoeDollarsPerMwh: number;
  npvDollars: number;
  irrPercent: number;
  simplePaybackYears: number;
  discountedPaybackYears: number;
  lifetimeGenerationKwh: number;
  cashFlowSchedule: CashFlowYear[];
}

export function calculateProjectFinancials(assumptions: FinancialAssumptions): FinancialResult {
  const {
    systemCapacityDcKw,
    annualGenerationYear1Kwh,
    batteryCapacityKwh,
    isTracking,
    electricityRetailRatePerKwh,
    exportFeedInTariffPerKwh,
    selfConsumptionPercent,
    discountRatePercent,
    projectLifetimeYears = 25,
    moduleDegradationYear1Percent = 1.5,
    annualDegradationPercent = 0.45,
    inverterReplacementYear = 12,
    inverterReplacementCostPerKw = 60,
  } = assumptions;

  const kw = systemCapacityDcKw;
  const watts = kw * 1000;

  // Scale-dependent CAPEX benchmark per Watt DC ($/W)
  // Utility scale (>10MW): ~$0.85/W, Commercial (100kW): ~$1.35/W, Residential (8kW): ~$2.40/W
  let moduleCostPerWatt = 0.18;
  let inverterCostPerWatt = 0.08;
  let rackingCostPerWatt = isTracking ? 0.14 : 0.09;
  let electricalBosPerWatt = 0.15;
  let civilLaborPerWatt = 0.22;
  let permittingPerWatt = 0.08;

  if (kw <= 15) {
    // Residential scale
    moduleCostPerWatt = 0.35;
    inverterCostPerWatt = 0.18;
    rackingCostPerWatt = 0.22;
    electricalBosPerWatt = 0.38;
    civilLaborPerWatt = 0.75;
    permittingPerWatt = 0.32;
  } else if (kw <= 500) {
    // Commercial rooftop / C&I
    moduleCostPerWatt = 0.24;
    inverterCostPerWatt = 0.12;
    rackingCostPerWatt = isTracking ? 0.20 : 0.14;
    electricalBosPerWatt = 0.22;
    civilLaborPerWatt = 0.36;
    permittingPerWatt = 0.14;
  }

  const modulesCost = watts * moduleCostPerWatt;
  const invertersCost = watts * inverterCostPerWatt;
  const rackingCost = watts * rackingCostPerWatt;
  const electricalBosCost = watts * electricalBosPerWatt;
  const civilLaborCost = watts * civilLaborPerWatt;
  const permittingGridTieCost = watts * permittingPerWatt;
  const batteryStorageCost = batteryCapacityKwh * 320; // $320 / kWh installed LFP BESS

  const totalCapex =
    modulesCost +
    invertersCost +
    rackingCost +
    electricalBosCost +
    batteryStorageCost +
    civilLaborCost +
    permittingGridTieCost;

  const capexPerWattDc = totalCapex / Math.max(1, watts);

  // Annual OPEX: ~$12 / kW-year for utility, ~$22 / kW-year for residential
  const opexPerKw = kw > 500 ? 12.0 : 20.0;
  const annualOpexYear1 = kw * opexPerKw + (batteryCapacityKwh > 0 ? batteryCapacityKwh * 4 : 0);

  // Effective value per generated kWh
  const selfRatio = selfConsumptionPercent / 100;
  const blendedRatePerKwh =
    selfRatio * electricityRetailRatePerKwh +
    (1 - selfRatio) * exportFeedInTariffPerKwh;

  const discountRate = discountRatePercent / 100;
  const cashFlowSchedule: CashFlowYear[] = [];

  let cumulativeCashFlow = -totalCapex;
  let sumDiscountedCosts = totalCapex;
  let sumDiscountedGenerationKwh = 0;
  let simplePaybackYears = projectLifetimeYears;
  let discountedPaybackYears = projectLifetimeYears;
  let lifetimeGenerationKwh = 0;

  for (let year = 1; year <= projectLifetimeYears; year++) {
    // Degradation factor
    const degPercent =
      year === 1
        ? moduleDegradationYear1Percent
        : moduleDegradationYear1Percent + (year - 1) * annualDegradationPercent;
    const degradationFactor = Math.max(0.65, 1 - degPercent / 100);

    const yearGenKwh = annualGenerationYear1Kwh * degradationFactor;
    lifetimeGenerationKwh += yearGenKwh;

    const grossRevenueSavings = yearGenKwh * blendedRatePerKwh;
    const yearOpex = annualOpexYear1 * Math.pow(1.02, year - 1); // 2% inflation

    const invReplacement =
      year === inverterReplacementYear ? kw * inverterReplacementCostPerKw : 0;

    const netCashFlow = grossRevenueSavings - yearOpex - invReplacement;
    const discountFactor = Math.pow(1 + discountRate, year);
    const discountedCashFlow = netCashFlow / discountFactor;

    cumulativeCashFlow += netCashFlow;

    // Check simple payback
    if (cumulativeCashFlow >= 0 && simplePaybackYears === projectLifetimeYears) {
      const prevCum = cumulativeCashFlow - netCashFlow;
      const fraction = Math.abs(prevCum) / Math.max(1, netCashFlow);
      simplePaybackYears = Number(((year - 1) + fraction).toFixed(1));
    }

    sumDiscountedCosts += (yearOpex + invReplacement) / discountFactor;
    sumDiscountedGenerationKwh += yearGenKwh / discountFactor;

    cashFlowSchedule.push({
      year,
      degradationFactor: Number(degradationFactor.toFixed(3)),
      annualGenerationKwh: Math.round(yearGenKwh),
      grossRevenueSavings: Math.round(grossRevenueSavings),
      opexCost: Math.round(yearOpex),
      inverterReplacementCost: Math.round(invReplacement),
      netCashFlow: Math.round(netCashFlow),
      discountedCashFlow: Math.round(discountedCashFlow),
      cumulativeCashFlow: Math.round(cumulativeCashFlow),
    });
  }

  // NPV: sum of discounted cash flows minus initial CAPEX
  const npvDollars =
    cashFlowSchedule.reduce((sum, item) => sum + item.discountedCashFlow, 0) - totalCapex;

  // LCOE = (Total Life Cycle Cost in Present Value) / (Lifetime Generated Energy in Present Value)
  const lcoeDollarsPerKwh =
    sumDiscountedGenerationKwh > 0 ? sumDiscountedCosts / sumDiscountedGenerationKwh : 0.05;
  const lcoeDollarsPerMwh = lcoeDollarsPerKwh * 1000;

  // Approximate IRR using bisection search
  let irr = 0.08;
  let low = -0.5;
  let high = 0.5;
  for (let iter = 0; iter < 40; iter++) {
    const mid = (low + high) / 2;
    let npvAtMid = -totalCapex;
    for (const item of cashFlowSchedule) {
      npvAtMid += item.netCashFlow / Math.pow(1 + mid, item.year);
    }
    if (Math.abs(npvAtMid) < 50 || (high - low) < 0.0001) {
      irr = mid;
      break;
    }
    if (npvAtMid > 0) {
      low = mid;
    } else {
      high = mid;
    }
    irr = mid;
  }

  return {
    capex: {
      modulesCost: Math.round(modulesCost),
      invertersCost: Math.round(invertersCost),
      rackingCost: Math.round(rackingCost),
      electricalBosCost: Math.round(electricalBosCost),
      batteryStorageCost: Math.round(batteryStorageCost),
      civilLaborCost: Math.round(civilLaborCost),
      permittingGridTieCost: Math.round(permittingGridTieCost),
      totalCapex: Math.round(totalCapex),
      capexPerWattDc: Number(capexPerWattDc.toFixed(2)),
    },
    annualOpexYear1: Math.round(annualOpexYear1),
    lcoeDollarsPerMwh: Number(lcoeDollarsPerMwh.toFixed(1)),
    npvDollars: Math.round(npvDollars),
    irrPercent: Number((irr * 100).toFixed(1)),
    simplePaybackYears,
    discountedPaybackYears: Number((simplePaybackYears * 1.25).toFixed(1)),
    lifetimeGenerationKwh: Math.round(lifetimeGenerationKwh),
    cashFlowSchedule,
  };
}
