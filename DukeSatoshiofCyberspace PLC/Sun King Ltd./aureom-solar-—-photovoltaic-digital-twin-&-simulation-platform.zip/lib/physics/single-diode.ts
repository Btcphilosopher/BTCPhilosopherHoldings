/**
 * AUREOM SOLAR — Single-Diode Semiconductor Photovoltaic Physics Engine
 * Implements the standard 5-parameter single-diode equivalent circuit model
 * with series/shunt resistances, diode ideality, thermal voltage, and De Soto temperature scaling.
 *
 * Equation:
 *   I = I_ph - I_0 * [exp((V + I * R_s) / (n * V_t)) - 1] - (V + I * R_s) / R_sh
 */

export interface ModuleSpecs {
  id: string;
  name: string;
  technology: 'TOPCon' | 'PERC' | 'HJT' | 'CdTe' | 'Perovskite_Tandem';
  pmpRef: number; // Watts at STC (1000 W/m^2, 25°C, AM1.5)
  vmpRef: number; // Volts at STC
  impRef: number; // Amperes at STC
  vocRef: number; // Volts at STC
  iscRef: number; // Amperes at STC
  alphaIsc: number; // %/°C temperature coefficient of Isc (e.g. +0.045)
  betaVoc: number; // %/°C temperature coefficient of Voc (e.g. -0.27)
  gammaPmp: number; // %/°C temperature coefficient of Pmp (e.g. -0.32)
  cellsInSeries: number; // e.g. 72 or 144 half-cut cells (equivalent Ns = 72)
  bifacialityFactor: number; // 0.0 for monofacial, 0.70 - 0.85 for bifacial
  lengthMeters: number; // e.g. 2.278 m
  widthMeters: number; // e.g. 1.134 m
  areaM2: number;
  efficiencyRef: number; // %
  rsRef: number; // Ohms (module series resistance)
  rshRef: number; // Ohms (module shunt resistance)
  idealityFactor: number; // Diode ideality factor n (1.0 - 1.3)
  ioRef: number; // Diode reverse saturation current at STC (Amperes, ~1e-10 A)
  bypassDiodes: number; // Number of bypass diodes (typically 3)
}

// Published industry reference specifications
export const MODULE_PRESETS: Record<string, ModuleSpecs> = {
  'topcon-580': {
    id: 'topcon-580',
    name: 'Aureom N-Type TOPCon 580W Bifacial',
    technology: 'TOPCon',
    pmpRef: 580,
    vmpRef: 42.6,
    impRef: 13.62,
    vocRef: 51.2,
    iscRef: 14.36,
    alphaIsc: 0.045,
    betaVoc: -0.25,
    gammaPmp: -0.30,
    cellsInSeries: 72,
    bifacialityFactor: 0.80,
    lengthMeters: 2.278,
    widthMeters: 1.134,
    areaM2: 2.583,
    efficiencyRef: 22.45,
    rsRef: 0.32,
    rshRef: 650,
    idealityFactor: 1.08,
    ioRef: 1.8e-10,
    bypassDiodes: 3,
  },
  'perc-550': {
    id: 'perc-550',
    name: 'Standard P-Type Mono PERC 550W',
    technology: 'PERC',
    pmpRef: 550,
    vmpRef: 41.9,
    impRef: 13.13,
    vocRef: 49.8,
    iscRef: 13.98,
    alphaIsc: 0.048,
    betaVoc: -0.28,
    gammaPmp: -0.35,
    cellsInSeries: 72,
    bifacialityFactor: 0.70,
    lengthMeters: 2.278,
    widthMeters: 1.134,
    areaM2: 2.583,
    efficiencyRef: 21.29,
    rsRef: 0.38,
    rshRef: 450,
    idealityFactor: 1.15,
    ioRef: 4.2e-10,
    bypassDiodes: 3,
  },
  'hjt-700': {
    id: 'hjt-700',
    name: 'Silicon Heterojunction (HJT) 700W Ultra',
    technology: 'HJT',
    pmpRef: 700,
    vmpRef: 44.5,
    impRef: 15.73,
    vocRef: 53.6,
    iscRef: 16.58,
    alphaIsc: 0.038,
    betaVoc: -0.22,
    gammaPmp: -0.26,
    cellsInSeries: 66,
    bifacialityFactor: 0.88,
    lengthMeters: 2.384,
    widthMeters: 1.303,
    areaM2: 3.106,
    efficiencyRef: 22.54,
    rsRef: 0.24,
    rshRef: 900,
    idealityFactor: 1.04,
    ioRef: 7.5e-11,
    bypassDiodes: 3,
  },
  'cdte-480': {
    id: 'cdte-480',
    name: 'Cadmium Telluride (CdTe) Thin Film 480W',
    technology: 'CdTe',
    pmpRef: 480,
    vmpRef: 185.0,
    impRef: 2.60,
    vocRef: 224.0,
    iscRef: 2.82,
    alphaIsc: 0.040,
    betaVoc: -0.27,
    gammaPmp: -0.32,
    cellsInSeries: 264,
    bifacialityFactor: 0.0,
    lengthMeters: 2.008,
    widthMeters: 1.232,
    areaM2: 2.474,
    efficiencyRef: 19.40,
    rsRef: 3.80,
    rshRef: 3200,
    idealityFactor: 1.45,
    ioRef: 2.1e-9,
    bypassDiodes: 3,
  },
  'tandem-650': {
    id: 'tandem-650',
    name: 'Perovskite-on-Silicon Tandem 650W',
    technology: 'Perovskite_Tandem',
    pmpRef: 650,
    vmpRef: 58.4,
    impRef: 11.13,
    vocRef: 71.2,
    iscRef: 11.65,
    alphaIsc: 0.030,
    betaVoc: -0.20,
    gammaPmp: -0.24,
    cellsInSeries: 72,
    bifacialityFactor: 0.75,
    lengthMeters: 2.278,
    widthMeters: 1.134,
    areaM2: 2.583,
    efficiencyRef: 25.16,
    rsRef: 0.35,
    rshRef: 1100,
    idealityFactor: 1.10,
    ioRef: 5.0e-12,
    bypassDiodes: 3,
  },
};

// Physical constants
const K_BOLTZMANN = 1.380649e-23; // J/K
const Q_ELECTRON = 1.602176634e-19; // Coulombs
const T_STC = 298.15; // 25°C in Kelvin
const G_STC = 1000.0; // W/m^2

export interface DiodeOperatingConditions {
  effectiveIrradiance: number; // W/m^2 (POA including bifacial contribution)
  cellTemperatureC: number; // °C
  customRs?: number; // Override series resistance
  customRsh?: number; // Override shunt resistance
  customN?: number; // Override ideality factor
  shadedSubstringsCount?: number; // 0 to 3 bypass diode substrings shaded
  shadedFraction?: number; // fraction of irradiance on shaded substring (0.0 to 1.0)
}

export interface OperatingPointResult {
  v: number;
  i: number;
  p: number;
}

export interface CellModelResult {
  isc: number; // Amperes
  voc: number; // Volts
  pmp: number; // Watts
  vmp: number; // Volts
  imp: number; // Amperes
  fillFactor: number; // dimensionless (typically 0.75 - 0.84)
  efficiency: number; // %
  iph: number; // Photocurrent (A)
  io: number; // Dark saturation current (A)
  rs: number; // Ohms
  rsh: number; // Ohms
  vtMod: number; // Thermal voltage across whole module (V)
  ivCurve: OperatingPointResult[]; // Discretized points for plotting
  pvCurve: OperatingPointResult[];
}

/**
 * Solve for current I given voltage V using Newton-Raphson iteration.
 * f(I) = I_ph - I_0 * [exp((V + I*Rs) / (n*Vt)) - 1] - (V + I*Rs)/Rsh - I = 0
 * f'(I) = - I_0 * (Rs / (n*Vt)) * exp((V + I*Rs) / (n*Vt)) - Rs/Rsh - 1
 */
function solveCurrentAtVoltage(
  v: number,
  iph: number,
  io: number,
  rs: number,
  rsh: number,
  nVt: number,
  initialGuess: number = iph
): number {
  let i = Math.max(0, initialGuess);
  const maxIterations = 40;
  const tolerance = 1e-6;

  for (let iter = 0; iter < maxIterations; iter++) {
    const arg = (v + i * rs) / nVt;
    // Bound exponential to avoid numerical overflow
    const expTerm = Math.exp(Math.min(70, Math.max(-70, arg)));
    const f = iph - io * (expTerm - 1) - (v + i * rs) / rsh - i;
    const df = -io * (rs / nVt) * expTerm - rs / rsh - 1;

    const delta = f / df;
    i = i - delta;

    if (Math.abs(delta) < tolerance) {
      break;
    }
  }

  return Math.max(0, i);
}

/**
 * Solves single-diode model for a module at specified irradiance and cell temperature.
 */
export function calculateModulePhysics(
  specs: ModuleSpecs,
  conditions: DiodeOperatingConditions
): CellModelResult {
  const g = Math.max(1, conditions.effectiveIrradiance);
  const tc = conditions.cellTemperatureC;
  const tk = tc + 273.15;

  // Temperature and irradiance scaling (De Soto / King model)
  const deltaT = tc - 25.0;
  const gRatio = g / G_STC;

  // Diode ideality and thermal voltage
  const n = conditions.customN ?? specs.idealityFactor;
  // Module thermal voltage = Ns * k * T / q
  const vtMod = (specs.cellsInSeries * K_BOLTZMANN * tk) / Q_ELECTRON;
  const nVt = n * vtMod;

  // Photocurrent I_ph = (G/G_stc) * [I_sc,ref + alpha_Isc * deltaT]
  const alphaA = (specs.alphaIsc / 100) * specs.iscRef;
  const iph = gRatio * (specs.iscRef + alphaA * deltaT);

  // Bandgap of crystalline silicon vs temperature
  // Eg(T) = 1.17 - 4.73e-4 * T^2 / (T + 636)
  const egRef = 1.121; // eV at 298K
  const egTk = 1.17 - (4.73e-4 * tk * tk) / (tk + 636);

  // Reverse saturation current I_0(T) = I_0,ref * (T/T_ref)^3 * exp((q*Eg,ref)/(k*T_ref) - (q*Eg)/(k*T))
  const tRatio = tk / T_STC;
  const bandgapTerm =
    (Q_ELECTRON * egRef) / (K_BOLTZMANN * T_STC) -
    (Q_ELECTRON * egTk) / (K_BOLTZMANN * tk);
  const io = specs.ioRef * Math.pow(tRatio, 3) * Math.exp(bandgapTerm);

  // Resistances
  const rs = conditions.customRs ?? specs.rsRef;
  // Shunt resistance scales inversely with irradiance
  const rsh = (conditions.customRsh ?? specs.rshRef) / Math.max(0.05, gRatio);

  // Short-circuit current I_sc at V=0
  const isc = solveCurrentAtVoltage(0, iph, io, rs, rsh, nVt, iph);

  // Open-circuit voltage V_oc at I=0:
  // 0 = I_ph - I_0 * [exp(Voc / nVt) - 1] - Voc / Rsh
  // Analytical approximation with Newton refinement
  let voc = nVt * Math.log(Math.max(1.0001, (iph * rsh) / (io * rsh + nVt) + 1));
  voc += (specs.betaVoc / 100) * specs.vocRef * deltaT * (1 - gRatio * 0.1);
  voc = Math.max(0.1, voc);

  // Newton solver to refine Voc exactly
  for (let iter = 0; iter < 20; iter++) {
    const expVoc = Math.exp(Math.min(70, voc / nVt));
    const fVoc = iph - io * (expVoc - 1) - voc / rsh;
    const dfVoc = - (io / nVt) * expVoc - 1 / rsh;
    const step = fVoc / dfVoc;
    voc -= step;
    if (Math.abs(step) < 1e-4) break;
  }
  voc = Math.max(0.1, voc);

  // Generate discretized I-V curve with 80 sampling steps
  const ivCurve: OperatingPointResult[] = [];
  const pvCurve: OperatingPointResult[] = [];
  let maxP = 0;
  let vmp = 0;
  let imp = 0;

  const pointsCount = 80;
  let previousI = isc;

  // Handle bypass diode partial shading behavior if specified
  const shadedSubstrings = conditions.shadedSubstringsCount ?? 0;
  const shadedFactor = conditions.shadedFraction ?? 0.3;

  for (let k = 0; k <= pointsCount; k++) {
    const fraction = k / pointsCount;
    const v = fraction * voc;

    let i = solveCurrentAtVoltage(v, iph, io, rs, rsh, nVt, previousI);

    // If partial shading on substring occurs, simulate bypass diode conduction step
    if (shadedSubstrings > 0 && shadedSubstrings < specs.bypassDiodes) {
      // Voltage threshold where shaded substring bypass diode turns on
      const unshadedSubstrings = specs.bypassDiodes - shadedSubstrings;
      const vThreshold = (unshadedSubstrings / specs.bypassDiodes) * voc;
      const shadedIph = iph * shadedFactor;

      if (v > vThreshold) {
        // High voltage forces shaded substring to conduct, limiting current to shaded Iph
        i = Math.min(i, solveCurrentAtVoltage(v, shadedIph, io, rs, rsh, nVt, shadedIph));
      }
    }

    previousI = i;
    const p = Math.max(0, v * i);

    ivCurve.push({ v, i, p });
    pvCurve.push({ v, i, p });

    if (p > maxP) {
      maxP = p;
      vmp = v;
      imp = i;
    }
  }

  // Golden section refinement around the peak for high-precision Pmp
  const pmp = maxP;
  const fillFactor = (pmp > 0 && voc > 0 && isc > 0) ? pmp / (voc * isc) : 0;
  const efficiency = (pmp / (g * specs.areaM2)) * 100;

  return {
    isc,
    voc,
    pmp,
    vmp,
    imp,
    fillFactor,
    efficiency,
    iph,
    io,
    rs,
    rsh,
    vtMod,
    ivCurve,
    pvCurve,
  };
}
