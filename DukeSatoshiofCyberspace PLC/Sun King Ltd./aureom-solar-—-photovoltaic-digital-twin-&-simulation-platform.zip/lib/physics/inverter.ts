/**
 * AUREOM SOLAR — Inverter Digital Twin
 * Implements inverter efficiency curves (Sandia/CEC/Euro), MPPT tracking window limits,
 * DC-to-AC ratio oversizing, clipping losses, standby tare power, and thermal derating.
 */

export type InverterType = 'string' | 'central' | 'microinverter' | 'hybrid';

export interface InverterSpecs {
  id: string;
  name: string;
  type: InverterType;
  pacMaxWatts: number; // Maximum continuous AC power rating (W)
  pdcMaxWatts: number; // Maximum DC input power rating (W)
  vmpptMinVolts: number; // Minimum MPPT operating voltage (V)
  vmpptMaxVolts: number; // Maximum MPPT operating voltage (V)
  vdcAbsoluteMaxVolts: number; // Maximum permissible DC open circuit voltage (V)
  idcMaxAmps: number; // Maximum DC input current (A)
  efficiencyEuroPercent: number; // European weighted efficiency (%)
  efficiencyMaxPercent: number; // Maximum efficiency (%)
  standbyPowerWatts: number; // Night/standby tare consumption (W)
  nominalGridVoltage: number; // VAC (e.g. 400V 3-phase or 230V 1-phase)
  gridFrequencyHz: 50 | 60;
}

export const INVERTER_PRESETS: Record<string, InverterSpecs> = {
  'string-100kw': {
    id: 'string-100kw',
    name: 'Aureom MagnaString 100KTL-HV',
    type: 'string',
    pacMaxWatts: 100000,
    pdcMaxWatts: 150000,
    vmpptMinVolts: 500,
    vmpptMaxVolts: 1000,
    vdcAbsoluteMaxVolts: 1100,
    idcMaxAmps: 180,
    efficiencyEuroPercent: 98.4,
    efficiencyMaxPercent: 98.8,
    standbyPowerWatts: 35,
    nominalGridVoltage: 400,
    gridFrequencyHz: 50,
  },
  'central-3000kw': {
    id: 'central-3000kw',
    name: 'Aureom UtilityCentral 3125K-1500V',
    type: 'central',
    pacMaxWatts: 3125000,
    pdcMaxWatts: 4500000,
    vmpptMinVolts: 860,
    vmpptMaxVolts: 1300,
    vdcAbsoluteMaxVolts: 1500,
    idcMaxAmps: 3400,
    efficiencyEuroPercent: 98.7,
    efficiencyMaxPercent: 99.0,
    standbyPowerWatts: 450,
    nominalGridVoltage: 690,
    gridFrequencyHz: 50,
  },
  'hybrid-15kw': {
    id: 'hybrid-15kw',
    name: 'Aureom CommercialHybrid 15K-Storage',
    type: 'hybrid',
    pacMaxWatts: 15000,
    pdcMaxWatts: 22500,
    vmpptMinVolts: 200,
    vmpptMaxVolts: 850,
    vdcAbsoluteMaxVolts: 1000,
    idcMaxAmps: 32,
    efficiencyEuroPercent: 97.8,
    efficiencyMaxPercent: 98.3,
    standbyPowerWatts: 18,
    nominalGridVoltage: 400,
    gridFrequencyHz: 50,
  },
  'micro-500w': {
    id: 'micro-500w',
    name: 'Aureom MicroQuad 500W-IQ',
    type: 'microinverter',
    pacMaxWatts: 500,
    pdcMaxWatts: 750,
    vmpptMinVolts: 25,
    vmpptMaxVolts: 55,
    vdcAbsoluteMaxVolts: 65,
    idcMaxAmps: 15,
    efficiencyEuroPercent: 96.5,
    efficiencyMaxPercent: 97.2,
    standbyPowerWatts: 0.8,
    nominalGridVoltage: 230,
    gridFrequencyHz: 50,
  },
};

export interface InverterOperatingInput {
  specs: InverterSpecs;
  dcInputPowerWatts: number;
  dcInputVoltageVolts: number;
  ambientTemperatureC?: number;
}

export interface InverterOperatingResult {
  acOutputPowerWatts: number;
  efficiencyPercent: number;
  isClipping: boolean;
  clippingLossWatts: number;
  isMpptOutOfRange: boolean;
  isOverVoltageAlert: boolean;
  statusMessage: string;
}

/**
 * Calculates inverter AC output power, efficiency, clipping, and limits.
 */
export function calculateInverterState(input: InverterOperatingInput): InverterOperatingResult {
  const { specs, dcInputPowerWatts, dcInputVoltageVolts, ambientTemperatureC = 25 } = input;

  if (dcInputPowerWatts <= 1) {
    return {
      acOutputPowerWatts: -specs.standbyPowerWatts,
      efficiencyPercent: 0,
      isClipping: false,
      clippingLossWatts: 0,
      isMpptOutOfRange: false,
      isOverVoltageAlert: false,
      statusMessage: 'Standby / Sleep mode',
    };
  }

  // Check electrical voltage limits
  const isOverVoltageAlert = dcInputVoltageVolts > specs.vdcAbsoluteMaxVolts;
  const isMpptOutOfRange =
    dcInputVoltageVolts < specs.vmpptMinVolts || dcInputVoltageVolts > specs.vmpptMaxVolts;

  // Load ratio: P_dc / P_ac,max
  const loadRatio = dcInputPowerWatts / specs.pacMaxWatts;

  // Polynomial efficiency curve approximation matching CEC/Euro weighted curves
  // Peak efficiency typically occurs around 40-70% rated load
  let baseEff = specs.efficiencyEuroPercent;
  if (loadRatio < 0.05) {
    baseEff = specs.efficiencyEuroPercent * (loadRatio / 0.05) * 0.92;
  } else if (loadRatio < 0.20) {
    baseEff = specs.efficiencyEuroPercent * (0.93 + (loadRatio - 0.05) * 0.4);
  } else if (loadRatio <= 0.70) {
    baseEff = specs.efficiencyMaxPercent;
  } else {
    // Slight drop due to conduction heating losses at full load
    baseEff = specs.efficiencyMaxPercent - (loadRatio - 0.70) * 0.6;
  }

  // Thermal derating above 45°C ambient
  if (ambientTemperatureC > 45) {
    const tempDrop = (ambientTemperatureC - 45) * 0.25;
    baseEff = Math.max(90, baseEff - tempDrop);
  }

  const efficiency = Math.max(0, Math.min(99.5, baseEff));
  const rawAcPower = dcInputPowerWatts * (efficiency / 100);

  // Clipping check: AC output cannot exceed rated inverter capability
  const isClipping = rawAcPower > specs.pacMaxWatts;
  const acOutputPowerWatts = isClipping ? specs.pacMaxWatts : rawAcPower;
  const clippingLossWatts = isClipping ? rawAcPower - specs.pacMaxWatts : 0;

  let statusMessage = 'Nominal MPPT Operation';
  if (isOverVoltageAlert) {
    statusMessage = 'CRITICAL ALERT: DC Voltage exceeds maximum inverter rating!';
  } else if (isClipping) {
    statusMessage = `Inverter Clipping Active (${(clippingLossWatts / 1000).toFixed(1)} kW curtailed)`;
  } else if (isMpptOutOfRange) {
    statusMessage = 'Sub-optimal MPPT: DC Voltage outside tracking window';
  }

  return {
    acOutputPowerWatts: Number(acOutputPowerWatts.toFixed(1)),
    efficiencyPercent: Number(efficiency.toFixed(2)),
    isClipping,
    clippingLossWatts: Number(clippingLossWatts.toFixed(1)),
    isMpptOutOfRange,
    isOverVoltageAlert,
    statusMessage,
  };
}
