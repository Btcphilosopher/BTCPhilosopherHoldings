/**
 * AUREOM SOLAR — Procedural PBR Textures for Three.js
 * Generates high-fidelity solar cell wafers with busbars, anti-reflective coatings,
 * galvanized metal racking, and terrain textures directly via Canvas (Zero 404 dependencies).
 */

import * as THREE from 'three';

export function createSolarCellTexture(): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');

  if (!ctx) return new THREE.CanvasTexture(canvas);

  // Deep monocrystalline dark blue/black base
  ctx.fillStyle = '#0c1626';
  ctx.fillRect(0, 0, size, size);

  // Subtle crystallite wafer texture
  ctx.fillStyle = 'rgba(20, 35, 60, 0.4)';
  for (let i = 0; i < 400; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const w = 4 + Math.random() * 8;
    const h = 4 + Math.random() * 8;
    ctx.fillRect(x, y, w, h);
  }

  // Draw 6 x 10 cell gridlines with white EVA backsheet gaps
  const cols = 6;
  const rows = 12;
  const colWidth = size / cols;
  const rowHeight = size / rows;

  // Cell borders (white/silver gap)
  ctx.strokeStyle = 'rgba(235, 240, 245, 0.45)';
  ctx.lineWidth = 1.5;

  for (let c = 0; c <= cols; c++) {
    const x = c * colWidth;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, size);
    ctx.stroke();
  }

  for (let r = 0; r <= rows; r++) {
    const y = r * rowHeight;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(size, y);
    ctx.stroke();
  }

  // Draw 16 micro-busbars (thin vertical silver conductive wires across cells)
  ctx.strokeStyle = 'rgba(215, 225, 235, 0.7)';
  ctx.lineWidth = 1.0;
  for (let c = 0; c < cols; c++) {
    const cellStartX = c * colWidth;
    for (let b = 1; b <= 4; b++) {
      const bx = cellStartX + (colWidth * b) / 5;
      ctx.beginPath();
      ctx.moveTo(bx, 0);
      ctx.lineTo(bx, size);
      ctx.stroke();
    }
  }

  // Horizontal micro-fingers (subtle fine lines across each cell)
  ctx.strokeStyle = 'rgba(120, 150, 180, 0.15)';
  ctx.lineWidth = 0.5;
  for (let y = 4; y < size; y += 8) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(size, y);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

export function createGroundTerrainTexture(): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');

  if (!ctx) return new THREE.CanvasTexture(canvas);

  // Muted gravel & soil base (#18222b)
  ctx.fillStyle = '#18242f';
  ctx.fillRect(0, 0, size, size);

  // Noise patches of soil and crushed gravel
  for (let i = 0; i < 600; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const r = 2 + Math.random() * 5;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(35, 48, 60, 0.5)' : 'rgba(20, 30, 40, 0.6)';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Subtle maintenance road tire track lines
  ctx.strokeStyle = 'rgba(40, 55, 70, 0.3)';
  ctx.lineWidth = 24;
  ctx.beginPath();
  ctx.moveTo(0, size * 0.5);
  ctx.lineTo(size, size * 0.5);
  ctx.stroke();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(16, 16);
  return texture;
}
