import { Article } from './types';

export const INITIAL_ARTICLES: Article[] = [
  {
    id: 'art-1',
    slug: 'the-city-that-keeps-its-promises',
    title: 'The city that keeps its promises',
    author: 'Eleanor Hart',
    authorId: 'auth-1',
    category: 'Essays',
    priceSats: 250,
    isFree: false,
    publishedAt: 'November 2026',
    readTime: '6 min read',
    image: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?auto=format&fit=crop&w=1200&q=80',
    preview: 'There is an hour between midnight and the first pale wash of dawn when Manhattan belongs entirely to the ghost-trams and the steam fitters. In the neon hum of lower Broadway, stone gargoyles keep quiet counsel with the copper spires overhead.',
    content: `There is an hour between midnight and the first pale wash of dawn when Manhattan belongs entirely to the ghost-trams and the steam fitters. In the neon hum of lower Broadway, stone gargoyles keep quiet counsel with the copper spires overhead. 

We came to this island expecting permanence, seeking something carved in unyielding granite. Instead, we found a city built of light, paper, and promises whispered across tenement courtyards. Every yellow cab cutting through the November mist carries a passenger who left somewhere else behind.

The promise of the city is not that you will conquer it, but that it will hold your secret without judgment. When the old ferry slips creak against the pilings in Brooklyn, and the distant carnival lights of Coney Island pulse against the horizon like dying embers, you realize that memory here is just another form of architecture.

To live in the metropolis is to accept that nothing stays pristine, yet everything returns. The pavement remembers every rainstorm; the brownstones retain the warmth of coal fires burned a century ago. When we pay our respects to the night with a few quiet satoshis slipped across the digital wires, we are simply paying the toll on the ferry that crosses from what we were into what we might become.`,
    status: 'Published',
    revisionCount: 2,
  },
  {
    id: 'art-2',
    slug: 'letters-from-the-night-train',
    title: 'Letters from the night train',
    author: 'Daniel Moss',
    authorId: 'auth-2',
    category: 'Fiction',
    priceSats: 0,
    isFree: true,
    publishedAt: 'November 2026',
    readTime: '8 min read',
    image: 'https://images.unsplash.com/photo-1474487548417-781cb71495f3?auto=format&fit=crop&w=1200&q=80',
    preview: 'The diesel engine shuddered twice before settling into its rhythmic, hypnotic clatter. Outside the double-paned window, the endless Nebraska prairie rolled away under a vast bowl of violet sky.',
    content: `The diesel engine shuddered twice before settling into its rhythmic, hypnotic clatter. Outside the double-paned window, the endless Nebraska prairie rolled away under a vast bowl of violet sky.

Arthur had three envelopes in his coat pocket and a pocket watch that had belonged to his grandfather. Each envelope was addressed to a person he had not seen since the armistice, bearing news he had rehearsed a thousand times in the bunkhouses of Cheyenne.

"You're traveling light for November," the conductor said, punching a cardboard slip with a sharp, metallic snap.

"Only carrying what fits in my vest," Arthur replied, watching the amber light of a solitary farmhouse blink out against the horizon.

In the dining car, the coffee was bitter and tasted of tin, but it warmed the ribs. A woman across the aisle was reading a volume of Emily Dickinson with annotations written in violet ink. They did not speak, yet in the swaying silence of the carriage, their solitude seemed shared—two wayfarers suspended between the destinations they fled and the homes they hoped still existed.`,
    status: 'Published',
    revisionCount: 1,
  },
  {
    id: 'art-3',
    slug: 'a-room-of-borrowed-light',
    title: 'A room of borrowed light',
    author: 'Amelia Reed',
    authorId: 'auth-3',
    category: 'Culture',
    priceSats: 100,
    isFree: false,
    publishedAt: 'October 2026',
    readTime: '5 min read',
    image: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=1200&q=80',
    preview: 'The green banker’s lamp cast a pool of amber radiance across the walnut desk, carving out a private sanctuary from the encroaching twilight of the 1920s.',
    content: `The green banker’s lamp cast a pool of amber radiance across the walnut desk, carving out a private sanctuary from the encroaching twilight of the 1920s.

In rooms like this, surrounded by stacks of unbound journals and ivory paper smelling of rag and glue, writers have long sought to capture the fleeting texture of human attention. The lamp does not merely illuminate; it defines boundaries. Beyond its golden circle lies the roaring city of trolley cars and stock tickers; within it, time slows to the scratch of a steel nib.

We talk endlessly of new technologies—the wireless radio, the flickering silver screen, the high-speed ticker tape—yet the fundamental hunger remains remarkably ancient. We want an echo. We want to know that someone else sat in a quiet room at three in the morning and wondered why the stars seemed so indifferent to our sorrows.

When readers support independent writers with direct micropayments, they are keeping the lamp lit. No corporate aggregator, no advertising algorithm, just a direct covenant between reader and scribe across the electric ether.`,
    status: 'Published',
    revisionCount: 3,
  },
  {
    id: 'art-4',
    slug: 'symphony-of-the-iron-rails',
    title: 'Symphony of the iron rails',
    author: 'Julian Vance',
    authorId: 'auth-4',
    category: 'Poetry',
    priceSats: 150,
    isFree: false,
    publishedAt: 'November 2026',
    readTime: '4 min read',
    image: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=1200&q=80',
    preview: 'Black smoke curling against the harvest moon,\nA rhythmic heartbeat on the sleeping stone.\nThe steel divides the river from the dune,\nAnd leaves the traveler to walk alone.',
    content: `Black smoke curling against the harvest moon,
A rhythmic heartbeat on the sleeping stone.
The steel divides the river from the dune,
And leaves the traveler to walk alone.

O iron horse that drinks the prairie fire,
What ancient sorrow pulls you through the dark?
You carry letters born of wild desire,
And leave behind a glowing golden spark.

The telegraph wires hum a frozen tune,
While telegraph operators dream of sleep.
We barter silver under autumn’s moon,
And keep the silent pact we swore to keep.`,
    status: 'Published',
    revisionCount: 1,
  },
  {
    id: 'art-5',
    slug: 'the-architecture-of-silence',
    title: 'The architecture of silence',
    author: 'Clara Sterling',
    authorId: 'auth-5',
    category: 'Criticism',
    priceSats: 300,
    isFree: false,
    publishedAt: 'October 2026',
    readTime: '9 min read',
    image: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=1200&q=80',
    preview: 'In modern literary criticism, we frequently confuse noise with significance. We demand immediate proclamation, rapid hot-takes, and ceaseless commentary.',
    content: `In modern literary criticism, we frequently confuse noise with significance. We demand immediate proclamation, rapid hot-takes, and ceaseless commentary upon every passing cultural ripple.

Yet true art—whether in the modernist prose of Woolf or the spare, haunting verse of Frost—depends entirely upon the architecture of silence. The spaces between sentences are where the reader’s own imagination breathes.

When we examine the financial models that sustain independent publishing today, we find a parallel truth. Micropayments through Lightning rails restore dignity to the transaction. When a reader pays 300 sats for an essay, it is not a subscription trap or an ad-laden clickthrough; it is a deliberate, conscious valuation of contemplative thought.

We must protect the quiet rooms of literature from the cacophony of the attention economy.`,
    status: 'Published',
    revisionCount: 2,
  },
];
