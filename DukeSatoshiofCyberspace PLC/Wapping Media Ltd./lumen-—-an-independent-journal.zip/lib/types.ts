export type Category = 'Discover' | 'Fiction' | 'Essays' | 'Poetry' | 'Criticism' | 'Culture';

export interface Article {
  id: string;
  slug: string;
  title: string;
  author: string;
  authorId: string;
  category: Category;
  priceSats: number;
  isFree: boolean;
  publishedAt: string;
  readTime: string;
  image: string;
  preview: string;
  content: string;
  status: 'Draft' | 'Preview' | 'Published' | 'Revised' | 'Withdrawn';
  revisionCount: number;
}

export interface Invoice {
  id: string;
  articleId: string;
  articleTitle: string;
  amountSats: number;
  platformFeeSats: number;
  totalSats: number;
  paymentRequest: string;
  paymentHash: string;
  status: 'pending' | 'settled' | 'expired' | 'failed';
  createdAt: string;
  expiresAt: string;
  settledAt?: string;
  preimage?: string;
}

export interface Tip {
  id: string;
  authorId: string;
  authorName: string;
  amountSats: number;
  message?: string;
  createdAt: string;
  status: 'settled';
}

export interface LibraryItem {
  id: string;
  articleId: string;
  purchasedAt: string;
  priceSats: number;
  terms: string;
}

export interface Bookmark {
  articleId: string;
  savedAt: string;
}
