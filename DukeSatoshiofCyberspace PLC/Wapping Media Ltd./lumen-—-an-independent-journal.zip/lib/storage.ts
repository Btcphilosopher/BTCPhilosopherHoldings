import { Article, Invoice, LibraryItem, Tip, Bookmark } from './types';
import { INITIAL_ARTICLES } from './mockData';

const ARTICLES_KEY = 'lumen_articles_v1';
const LIBRARY_KEY = 'lumen_library_v1';
const INVOICES_KEY = 'lumen_invoices_v1';
const TIPS_KEY = 'lumen_tips_v1';
const BOOKMARKS_KEY = 'lumen_bookmarks_v1';

export function getStoredArticles(): Article[] {
  if (typeof window === 'undefined') return INITIAL_ARTICLES;
  try {
    const raw = localStorage.getItem(ARTICLES_KEY);
    if (!raw) {
      localStorage.setItem(ARTICLES_KEY, JSON.stringify(INITIAL_ARTICLES));
      return INITIAL_ARTICLES;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_ARTICLES;
  }
}

export function saveStoredArticles(articles: Article[]) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(ARTICLES_KEY, JSON.stringify(articles));
}

export function getStoredLibrary(): LibraryItem[] {
  if (typeof window === 'undefined') {
    // Default unlock the free one or seed sample
    return [{
      id: 'lib-init',
      articleId: 'art-2', // night train is free
      purchasedAt: new Date().toISOString(),
      priceSats: 0,
      terms: 'Free public access'
    }];
  }
  try {
    const raw = localStorage.getItem(LIBRARY_KEY);
    if (!raw) {
      const initial: LibraryItem[] = [{
        id: 'lib-init',
        articleId: 'art-2',
        purchasedAt: new Date().toISOString(),
        priceSats: 0,
        terms: 'Free public access'
      }];
      localStorage.setItem(LIBRARY_KEY, JSON.stringify(initial));
      return initial;
    }
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function addLibraryItem(item: LibraryItem) {
  if (typeof window === 'undefined') return;
  const current = getStoredLibrary();
  if (!current.some(i => i.articleId === item.articleId)) {
    const updated = [item, ...current];
    localStorage.setItem(LIBRARY_KEY, JSON.stringify(updated));
  }
}

export function getStoredInvoices(): Invoice[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(INVOICES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveInvoice(invoice: Invoice) {
  if (typeof window === 'undefined') return;
  const invoices = getStoredInvoices();
  const existingIndex = invoices.findIndex(i => i.id === invoice.id);
  if (existingIndex >= 0) {
    invoices[existingIndex] = invoice;
  } else {
    invoices.unshift(invoice);
  }
  localStorage.setItem(INVOICES_KEY, JSON.stringify(invoices));
}

export function getStoredTips(): Tip[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(TIPS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function addTip(tip: Tip) {
  if (typeof window === 'undefined') return;
  const tips = getStoredTips();
  localStorage.setItem(TIPS_KEY, JSON.stringify([tip, ...tips]));
}

export function getStoredBookmarks(): Bookmark[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(BOOKMARKS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function toggleBookmark(articleId: string): boolean {
  if (typeof window === 'undefined') return false;
  const bookmarks = getStoredBookmarks();
  const exists = bookmarks.some(b => b.articleId === articleId);
  let updated: Bookmark[];
  if (exists) {
    updated = bookmarks.filter(b => b.articleId !== articleId);
  } else {
    updated = [{ articleId, savedAt: new Date().toISOString() }, ...bookmarks];
  }
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(updated));
  return !exists;
}
