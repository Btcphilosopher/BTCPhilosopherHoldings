'import client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Zap, Edit3, Bookmark, Search, Menu, X, ShieldAlert } from 'lucide-react';
import { Category } from '@/lib/types';

interface HeaderProps {
  currentCategory: Category | 'Discover' | 'My Library';
  onSelectCategory: (cat: Category | 'Discover' | 'My Library') => void;
  onOpenWriter: () => void;
  onOpenPayments: () => void;
  onOpenSearch: () => void;
  purchasedCount: number;
}

export function Header({
  currentCategory,
  onSelectCategory,
  onOpenWriter,
  onOpenPayments,
  onOpenSearch,
  purchasedCount,
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: (Category | 'Discover' | 'My Library')[] = [
    'Discover',
    'Fiction',
    'Essays',
    'Poetry',
    'Criticism',
    'My Library',
  ];

  return (
    <header className="border-b border-[#f5ecd5]/20 bg-[#073e50]/95 backdrop-blur-md sticky top-0 z-40">
      {/* Top Banner Row matching reference */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 pb-2 flex flex-col md:flex-row items-center justify-between border-b border-[#f5ecd5]/10 text-xs tracking-widest text-[#f5ecd5]/80 uppercase">
        <div className="hidden md:block">AN INDEPENDENT JOURNAL</div>
        <div className="text-center my-1 md:my-0">
          <h1 className="font-masthead text-3xl sm:text-4xl tracking-wider text-[#f5ecd5] font-normal lowercase first-letter:uppercase">
            LUMEN
          </h1>
        </div>
        <div className="hidden md:flex items-center space-x-3">
          <span>LETTERS</span>
          <span className="text-[#e64b2e]">♦</span>
          <span>ARTS</span>
          <span className="text-[#e64b2e]">♦</span>
          <span>IDEAS</span>
        </div>
      </div>

      {/* Navigation and Right Actions */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center space-x-6 text-sm font-sans-ui font-medium">
          {navItems.map((item) => {
            const isActive = currentCategory === item;
            return (
              <button
                key={item}
                onClick={() => onSelectCategory(item)}
                className={`transition-colors relative py-1 ${
                  isActive
                    ? 'text-[#f5ecd5] font-semibold'
                    : 'text-[#f5ecd5]/70 hover:text-[#f5ecd5]'
                }`}
              >
                {item}
                {item === 'My Library' && purchasedCount > 0 && (
                  <span className="ml-1.5 px-1.5 py-0.5 text-[10px] rounded-full bg-[#e64b2e] text-[#f5ecd5]">
                    {purchasedCount}
                  </span>
                )}
                {isActive && (
                  <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#e64b2e]" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Mobile menu button */}
        <div className="flex md:hidden items-center">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="text-[#f5ecd5] p-2 hover:bg-[#052e3b] rounded"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Right Actions */}
        <div className="flex items-center space-x-3">
          <button
            onClick={onOpenSearch}
            className="p-2 text-[#f5ecd5]/80 hover:text-[#f5ecd5] transition-colors rounded hover:bg-[#052e3b]"
            title="Search articles"
          >
            <Search className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenWriter}
            className="hidden sm:inline-flex items-center space-x-1.5 px-3 py-1.5 border border-[#f5ecd5]/40 hover:border-[#f5ecd5] text-xs font-sans-ui tracking-wider uppercase text-[#f5ecd5] rounded transition-all hover:bg-[#052e3b]"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Write</span>
          </button>

          <button
            onClick={onOpenPayments}
            className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 bg-[#ffc629] text-[#052e3b] hover:bg-[#e6ab1b] text-xs font-sans-ui font-semibold tracking-wider uppercase rounded shadow-sm transition-all"
          >
            <Zap className="w-3.5 h-3.5 fill-current" />
            <span>Payments</span>
          </button>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#052e3b] border-b border-[#f5ecd5]/20 px-4 py-4 space-y-3 font-sans-ui">
          <div className="flex flex-col space-y-2">
            {navItems.map((item) => (
              <button
                key={item}
                onClick={() => {
                  onSelectCategory(item);
                  setMobileMenuOpen(false);
                }}
                className={`text-left py-2 px-3 rounded text-sm ${
                  currentCategory === item
                    ? 'bg-[#073e50] text-[#f5ecd5] font-semibold'
                    : 'text-[#f5ecd5]/80 hover:bg-[#073e50]'
                }`}
              >
                {item} {item === 'My Library' && purchasedCount > 0 && `(${purchasedCount})`}
              </button>
            ))}
            <button
              onClick={() => {
                onOpenWriter();
                setMobileMenuOpen(false);
              }}
              className="flex items-center space-x-2 text-left py-2 px-3 rounded text-sm text-[#f5ecd5]/80 hover:bg-[#073e50]"
            >
              <Edit3 className="w-4 h-4" />
              <span>Write & Publish</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
