'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';

interface HeroProps {
  onExplore: () => void;
}

export function Hero({ onExplore }: HeroProps) {
  return (
    <section className="relative overflow-hidden border-b border-[#f5ecd5]/20 bg-[#052e3b]/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left text column */}
        <div className="lg:col-span-5 space-y-6 z-10">
          <h2 className="font-masthead text-4xl sm:text-5xl lg:text-6xl italic font-normal text-[#f5ecd5] leading-tight">
            For the restless mind.
          </h2>
          <div className="space-y-2 text-[#f5ecd5]/90 text-lg font-serif leading-relaxed">
            <p>Independent voices. Enduring stories.</p>
            <p className="text-[#f5ecd5]/75 text-base font-sans-ui">
              Read freely, or support a writer with a few sats.
            </p>
          </div>
          <div className="pt-2">
            <button
              onClick={onExplore}
              className="inline-flex items-center space-x-2 bg-[#ffc629] text-[#052e3b] hover:bg-[#e6ab1b] font-sans-ui font-semibold px-6 py-3 rounded shadow transition-all transform hover:-translate-y-0.5 text-sm uppercase tracking-wider"
            >
              <span>Explore the journal</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right illustration column */}
        <div className="lg:col-span-7 relative">
          <div className="relative rounded-lg overflow-hidden border border-[#f5ecd5]/30 shadow-2xl bg-[#052e3b]">
            <div className="aspect-[16/9] relative w-full">
              <Image
                src="/assets/aistudio/d28a3158-60fd-470f-8e6c-927b9e90a4f3_d326b235.png"
                alt="Nocturnal American skyline with waterfront reflections and carnival lights"
                fill
                className="object-cover"
                priority
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#073e50]/40 via-transparent to-transparent pointer-events-none" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
