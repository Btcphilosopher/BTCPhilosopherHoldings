'use client';

import React from 'react';
import Image from 'next/image';
import { Article } from '@/lib/types';
import { BookOpen, CheckCircle } from 'lucide-react';

interface CurrentEditionProps {
  articles: Article[];
  selectedArticleId: string;
  onSelectForSupport: (article: Article) => void;
  onOpenReader: (article: Article) => void;
  purchasedArticleIds: string[];
}

export function CurrentEdition({
  articles,
  selectedArticleId,
  onSelectForSupport,
  onOpenReader,
  purchasedArticleIds,
}: CurrentEditionProps) {
  // We want to highlight the top 3 featured articles or filter by current edition
  const featured = articles.slice(0, 3);

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Section Header */}
      <div className="flex items-center justify-center space-x-4 mb-10">
        <div className="h-[1px] bg-[#f5ecd5]/30 flex-1 max-w-xs" />
        <div className="flex items-center space-x-2 text-xs font-sans-ui tracking-[0.2em] text-[#f5ecd5] uppercase">
          <span className="text-[#e64b2e]">♦</span>
          <span>The Current Edition</span>
          <span className="text-[#e64b2e]">♦</span>
        </div>
        <div className="h-[1px] bg-[#f5ecd5]/30 flex-1 max-w-xs" />
      </div>

      {/* 3-Column Article Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {featured.map((article) => {
          const isSelected = selectedArticleId === article.id;
          const isPurchased = article.isFree || purchasedArticleIds.includes(article.id);

          return (
            <div
              key={article.id}
              onClick={() => onSelectForSupport(article)}
              className={`group cursor-pointer bg-[#052e3b]/80 border transition-all duration-300 rounded-lg overflow-hidden flex flex-col justify-between p-4 ${
                isSelected
                  ? 'border-[#ffc629] ring-1 ring-[#ffc629] shadow-xl'
                  : 'border-[#f5ecd5]/20 hover:border-[#f5ecd5]/50'
              }`}
            >
              <div>
                {/* Article Image */}
                <div className="relative aspect-[16/10] w-full mb-4 rounded overflow-hidden bg-[#073e50]">
                  <Image
                    src={article.image}
                    alt={article.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  {isPurchased && !article.isFree && (
                    <div className="absolute top-2 right-2 bg-[#44745b] text-[#f5ecd5] px-2 py-0.5 rounded text-[11px] font-sans-ui flex items-center space-x-1 shadow">
                      <CheckCircle className="w-3 h-3" />
                      <span>Unlocked</span>
                    </div>
                  )}
                </div>

                {/* Category Label */}
                <div className="text-[11px] font-sans-ui tracking-widest text-[#e64b2e] uppercase font-semibold mb-1.5">
                  {article.category}
                </div>

                {/* Title */}
                <h3 className="font-masthead text-2xl italic font-normal text-[#f5ecd5] group-hover:text-[#ffc629] transition-colors leading-snug mb-2">
                  {article.title}
                </h3>

                {/* Author */}
                <p className="text-sm italic text-[#f5ecd5]/80 font-serif mb-4">
                  By {article.author}
                </p>
              </div>

              {/* Bottom Action Footer */}
              <div className="pt-4 border-t border-[#f5ecd5]/15 flex items-center justify-between">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenReader(article);
                  }}
                  className="inline-flex items-center space-x-1.5 text-xs font-sans-ui font-semibold text-[#052e3b] bg-[#ffc629] hover:bg-[#e6ab1b] px-3 py-1.5 rounded transition-colors"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>{article.isFree ? 'Read free' : `Read · ${article.priceSats} sats`}</span>
                </button>

                <span className="text-xs font-sans-ui text-[#f5ecd5]/60">
                  {article.readTime}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
