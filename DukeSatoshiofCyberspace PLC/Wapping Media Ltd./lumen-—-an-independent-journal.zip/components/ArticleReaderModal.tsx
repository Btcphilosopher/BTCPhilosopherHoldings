'use client';

import React, { useState } from 'react';
import { Article, LibraryItem, Tip } from '@/lib/types';
import { X, Bookmark, Share2, Zap, ShieldCheck, BookOpen, Heart, Check } from 'lucide-react';
import confetti from 'canvas-confetti';

interface ArticleReaderModalProps {
  article: Article;
  onClose: () => void;
  isUnlocked: boolean;
  onUnlockClick: () => void;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
  onTipAuthor: (tip: Tip) => void;
}

export function ArticleReaderModal({
  article,
  onClose,
  isUnlocked,
  onUnlockClick,
  isBookmarked,
  onToggleBookmark,
  onTipAuthor,
}: ArticleReaderModalProps) {
  const [textSize, setTextSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [tipAmount, setTipAmount] = useState<number>(100);
  const [customTip, setCustomTip] = useState<string>('');
  const [tipSent, setTipSent] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const canReadFull = article.isFree || isUnlocked;

  const handleSendTip = () => {
    const amount = customTip ? parseInt(customTip, 10) || 100 : tipAmount;
    const tip: Tip = {
      id: 'tip_' + Math.random().toString(36).substring(2, 8),
      authorId: article.authorId,
      authorName: article.author,
      amountSats: amount,
      createdAt: new Date().toISOString(),
      status: 'settled',
    };
    onTipAuthor(tip);
    setTipSent(true);
    confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    setTimeout(() => setTipSent(false), 3000);
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const textSizeClass =
    textSize === 'xlarge'
      ? 'text-2xl leading-relaxed'
      : textSize === 'large'
      ? 'text-xl leading-relaxed'
      : 'text-lg leading-relaxed';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#052e3b]/90 backdrop-blur-md overflow-y-auto p-2 sm:p-6">
      <div className="bg-[#073e50] border border-[#f5ecd5]/30 rounded-xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col text-[#f5ecd5] font-serif overflow-hidden my-auto">
        {/* Top Controls Bar */}
        <div className="px-6 py-3 border-b border-[#f5ecd5]/20 bg-[#052e3b] flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3 text-xs font-sans-ui text-[#f5ecd5]/75">
            <span className="text-[#e64b2e] uppercase tracking-wider font-semibold">
              {article.category}
            </span>
            <span>•</span>
            <span>{article.readTime}</span>
          </div>

          <div className="flex items-center space-x-4">
            {/* Font size adjustments */}
            <div className="hidden sm:flex items-center space-x-1 bg-[#073e50] border border-[#f5ecd5]/20 rounded p-1 text-xs font-sans-ui">
              <button
                onClick={() => setTextSize('normal')}
                className={`px-2 py-0.5 rounded ${textSize === 'normal' ? 'bg-[#ffc629] text-[#052e3b]' : 'text-[#f5ecd5]'}`}
              >
                A
              </button>
              <button
                onClick={() => setTextSize('large')}
                className={`px-2 py-0.5 rounded ${textSize === 'large' ? 'bg-[#ffc629] text-[#052e3b]' : 'text-[#f5ecd5]'}`}
              >
                A+
              </button>
              <button
                onClick={() => setTextSize('xlarge')}
                className={`px-2 py-0.5 rounded ${textSize === 'xlarge' ? 'bg-[#ffc629] text-[#052e3b]' : 'text-[#f5ecd5]'}`}
              >
                A++
              </button>
            </div>

            <button
              onClick={onToggleBookmark}
              className={`p-1.5 rounded transition-colors ${isBookmarked ? 'text-[#ffc629] bg-[#052e3b]' : 'text-[#f5ecd5]/70 hover:text-[#f5ecd5]'}`}
              title="Bookmark article"
            >
              <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
            </button>

            <button
              onClick={handleShare}
              className="p-1.5 text-[#f5ecd5]/70 hover:text-[#f5ecd5] rounded transition-colors"
              title="Copy link"
            >
              {copiedLink ? <Check className="w-4 h-4 text-[#44745b]" /> : <Share2 className="w-4 h-4" />}
            </button>

            <div className="h-4 w-[1px] bg-[#f5ecd5]/20" />

            <button
              onClick={onClose}
              className="text-[#f5ecd5]/70 hover:text-[#f5ecd5] p-1.5 rounded hover:bg-[#073e50]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Article Content */}
        <div className="p-6 sm:p-12 overflow-y-auto space-y-8">
          <div className="max-w-2xl mx-auto space-y-4 text-center">
            <h1 className="font-masthead text-3xl sm:text-5xl italic font-normal text-[#f5ecd5] leading-tight">
              {article.title}
            </h1>
            <p className="text-base sm:text-lg italic text-[#f5ecd5]/80 font-serif">
              By {article.author} · Published {article.publishedAt}
            </p>
          </div>

          <div className="max-w-2xl mx-auto space-y-6">
            {canReadFull ? (
              <div className={`space-y-6 text-[#f5ecd5]/95 font-serif ${textSizeClass}`}>
                {article.content.split('\n\n').map((paragraph, idx) => (
                  <p key={idx} className="leading-relaxed">
                    {paragraph}
                  </p>
                ))}
              </div>
            ) : (
              <div className="space-y-6">
                <div className={`space-y-6 text-[#f5ecd5]/95 font-serif opacity-90 ${textSizeClass}`}>
                  <p className="leading-relaxed italic border-l-2 border-[#e64b2e] pl-4">
                    {article.preview}
                  </p>
                </div>

                {/* Paywall Gate Box */}
                <div className="bg-[#052e3b] border-2 border-[#ffc629]/60 rounded-xl p-8 text-center space-y-6 shadow-2xl">
                  <div className="w-12 h-12 bg-[#ffc629] text-[#052e3b] rounded-full flex items-center justify-center mx-auto shadow">
                    <Zap className="w-6 h-6 fill-current" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-masthead text-2xl italic">Unlock Full Article</h3>
                    <p className="text-sm font-sans-ui text-[#f5ecd5]/80 max-w-md mx-auto">
                      Support {article.author} and gain permanent access to this piece for <span className="text-[#ffc629] font-semibold">{article.priceSats} sats</span> (approx. ${(article.priceSats * 0.00065).toFixed(2)} USD). Includes future author revisions.
                    </p>
                  </div>
                  <button
                    onClick={onUnlockClick}
                    className="inline-flex items-center space-x-2 bg-[#ffc629] text-[#052e3b] font-sans-ui font-semibold px-8 py-3 rounded text-sm uppercase tracking-wider shadow-lg hover:bg-[#e6ab1b] transition-all transform hover:-translate-y-0.5"
                  >
                    <Zap className="w-4 h-4 fill-current" />
                    <span>Pay {article.priceSats} sats with Lightning</span>
                  </button>
                </div>
              </div>
            )}

            {/* Author Tipping Section */}
            <div className="pt-10 border-t border-[#f5ecd5]/20 mt-12 space-y-4 bg-[#052e3b]/50 p-6 rounded-lg">
              <div className="flex items-center space-x-2">
                <Heart className="w-4 h-4 text-[#e64b2e] fill-current" />
                <h4 className="font-masthead text-xl italic">Send a tip to {article.author}</h4>
              </div>
              <p className="text-xs font-sans-ui text-[#f5ecd5]/75">
                Appreciate this piece? Send an independent Lightning tip directly to the author.
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                {[100, 500, 1000].map((sats) => (
                  <button
                    key={sats}
                    onClick={() => {
                      setTipAmount(sats);
                      setCustomTip('');
                    }}
                    className={`px-4 py-2 rounded text-xs font-sans-ui font-semibold transition-all ${
                      tipAmount === sats && !customTip
                        ? 'bg-[#ffc629] text-[#052e3b]'
                        : 'bg-[#073e50] border border-[#f5ecd5]/30 text-[#f5ecd5] hover:bg-[#083a4c]'
                    }`}
                  >
                    ⚡ {sats} sats
                  </button>
                ))}

                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    placeholder="Custom sats"
                    value={customTip}
                    onChange={(e) => setCustomTip(e.target.value)}
                    className="bg-[#073e50] border border-[#f5ecd5]/30 rounded px-3 py-1.5 text-xs font-sans-ui text-[#f5ecd5] w-28"
                  />
                  <button
                    onClick={handleSendTip}
                    disabled={tipSent}
                    className="bg-[#44745b] text-[#f5ecd5] hover:bg-[#345945] px-4 py-1.5 rounded text-xs font-sans-ui font-semibold transition-all"
                  >
                    {tipSent ? 'Tip Sent! ⚡' : 'Send Tip'}
                  </button>
                </div>
              </div>
              {tipSent && (
                <div className="text-xs text-[#ffc629] font-sans-ui animate-pulse">
                  ⚡ Lightning tip of {customTip || tipAmount} sats successfully credited to {article.author}!
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
