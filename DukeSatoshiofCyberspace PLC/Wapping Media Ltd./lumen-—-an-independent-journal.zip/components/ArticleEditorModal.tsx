'use client';

import React, { useState } from 'react';
import { Article, Category } from '@/lib/types';
import { X, Edit3, Plus, Save, ShieldCheck } from 'lucide-react';

interface ArticleEditorModalProps {
  onClose: () => void;
  onSaveArticle: (article: Article) => void;
}

export function ArticleEditorModal({ onClose, onSaveArticle }: ArticleEditorModalProps) {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('Eleanor Hart');
  const [category, setCategory] = useState<Category>('Essays');
  const [isFree, setIsFree] = useState(false);
  const [priceSats, setPriceSats] = useState(200);
  const [image, setImage] = useState('https://images.unsplash.com/photo-1514565131-fce0801e5785?auto=format&fit=crop&w=1200&q=80');
  const [preview, setPreview] = useState('');
  const [content, setContent] = useState('');
  const [status, setStatus] = useState<'Draft' | 'Published'>('Published');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !content) return;

    const newArticle: Article = {
      id: 'art_' + Math.random().toString(36).substring(2, 9),
      slug: title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
      title,
      author,
      authorId: 'auth-current',
      category,
      priceSats: isFree ? 0 : Number(priceSats),
      isFree,
      publishedAt: 'November 2026',
      readTime: Math.max(3, Math.round(content.split(' ').length / 180)) + ' min read',
      image,
      preview: preview || content.substring(0, 150) + '...',
      content,
      status: status,
      revisionCount: 1,
    };

    onSaveArticle(newArticle);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#052e3b]/90 backdrop-blur-md overflow-y-auto p-4">
      <div className="bg-[#073e50] border border-[#f5ecd5]/30 rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col text-[#f5ecd5] font-serif overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#f5ecd5]/20 bg-[#052e3b] flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Edit3 className="w-5 h-5 text-[#ffc629]" />
            <h3 className="font-masthead text-xl italic font-normal">Author Publishing Studio</h3>
          </div>
          <button onClick={onClose} className="text-[#f5ecd5]/70 hover:text-[#f5ecd5] p-1 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 font-sans-ui text-sm">
          <div className="space-y-1">
            <label className="text-xs uppercase tracking-wider text-[#f5ecd5]/70">Article Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. The midnight telegraph wires"
              className="w-full bg-[#052e3b] border border-[#f5ecd5]/30 rounded px-3 py-2 text-[#f5ecd5] font-serif text-lg focus:outline-none focus:border-[#ffc629]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs uppercase tracking-wider text-[#f5ecd5]/70">Author Name</label>
              <input
                type="text"
                required
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                className="w-full bg-[#052e3b] border border-[#f5ecd5]/30 rounded px-3 py-2 text-[#f5ecd5]"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs uppercase tracking-wider text-[#f5ecd5]/70">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Category)}
                className="w-full bg-[#052e3b] border border-[#f5ecd5]/30 rounded px-3 py-2 text-[#f5ecd5]"
              >
                <option value="Essays">Essays</option>
                <option value="Fiction">Fiction</option>
                <option value="Poetry">Poetry</option>
                <option value="Criticism">Criticism</option>
                <option value="Culture">Culture</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center bg-[#052e3b]/50 p-4 rounded border border-[#f5ecd5]/15">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="isFree"
                checked={isFree}
                onChange={(e) => setIsFree(e.target.checked)}
                className="w-4 h-4 rounded text-[#ffc629] bg-[#073e50] border-[#f5ecd5]/30"
              />
              <label htmlFor="isFree" className="text-xs font-semibold uppercase tracking-wider cursor-pointer">
                Free Article (No Paywall)
              </label>
            </div>

            {!isFree && (
              <div className="space-y-1">
                <label className="text-xs uppercase tracking-wider text-[#f5ecd5]/70">Price in Sats</label>
                <input
                  type="number"
                  min="10"
                  max="5000"
                  value={priceSats}
                  onChange={(e) => setPriceSats(Number(e.target.value))}
                  className="w-full bg-[#052e3b] border border-[#f5ecd5]/30 rounded px-3 py-1.5 text-[#f5ecd5]"
                />
              </div>
            )}
          </div>

          <div className="space-y-1">
            <label className="text-xs uppercase tracking-wider text-[#f5ecd5]/70">Cover Image URL</label>
            <input
              type="text"
              value={image}
              onChange={(e) => setImage(e.target.value)}
              className="w-full bg-[#052e3b] border border-[#f5ecd5]/30 rounded px-3 py-2 text-[#f5ecd5] text-xs font-mono"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs uppercase tracking-wider text-[#f5ecd5]/70">Public Preview excerpt</label>
            <textarea
              rows={2}
              value={preview}
              onChange={(e) => setPreview(e.target.value)}
              placeholder="Short teaser shown to unpaid readers..."
              className="w-full bg-[#052e3b] border border-[#f5ecd5]/30 rounded px-3 py-2 text-[#f5ecd5] text-xs"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs uppercase tracking-wider text-[#f5ecd5]/70">Full Article Content</label>
            <textarea
              rows={6}
              required
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Write your literary piece here..."
              className="w-full bg-[#052e3b] border border-[#f5ecd5]/30 rounded px-3 py-2 text-[#f5ecd5] font-serif text-sm"
            />
          </div>

          <div className="pt-4 border-t border-[#f5ecd5]/20 flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded text-xs uppercase tracking-wider text-[#f5ecd5]/70 hover:text-[#f5ecd5]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center space-x-2 bg-[#ffc629] text-[#052e3b] font-semibold px-6 py-2 rounded text-xs uppercase tracking-wider shadow hover:bg-[#e6ab1b] transition-all"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Publish Article</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
