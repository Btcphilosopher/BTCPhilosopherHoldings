'use client';

import React from 'react';
import { Invoice, Tip } from '@/lib/types';
import { X, Zap, ArrowUpRight, ShieldCheck, Download } from 'lucide-react';

interface PaymentsModalProps {
  onClose: () => void;
  invoices: Invoice[];
  tips: Tip[];
}

export function PaymentsModal({ onClose, invoices, tips }: PaymentsModalProps) {
  const settledInvoices = invoices.filter((i) => i.status === 'settled');
  const totalSatoshisSpent = settledInvoices.reduce((acc, i) => acc + i.totalSats, 0);
  const totalTipsSpent = tips.reduce((acc, t) => acc + t.amountSats, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#052e3b]/90 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-[#073e50] border border-[#f5ecd5]/30 rounded-xl shadow-2xl max-w-2xl w-full max-h-[85vh] flex flex-col text-[#f5ecd5] font-serif overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#f5ecd5]/20 bg-[#052e3b] flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Zap className="w-5 h-5 text-[#ffc629] fill-current" />
            <h3 className="font-masthead text-xl italic font-normal">Lightning Payments & Receipts</h3>
          </div>
          <button onClick={onClose} className="text-[#f5ecd5]/70 hover:text-[#f5ecd5] p-1 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 font-sans-ui text-sm">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-[#052e3b]/70 p-4 rounded border border-[#f5ecd5]/15 space-y-1">
              <div className="text-[11px] uppercase tracking-wider text-[#f5ecd5]/60">Total Spent on Articles</div>
              <div className="text-2xl font-masthead text-[#ffc629]">{totalSatoshisSpent} sats</div>
            </div>
            <div className="bg-[#052e3b]/70 p-4 rounded border border-[#f5ecd5]/15 space-y-1">
              <div className="text-[11px] uppercase tracking-wider text-[#f5ecd5]/60">Total Author Tips</div>
              <div className="text-2xl font-masthead text-[#e64b2e]">{totalTipsSpent} sats</div>
            </div>
            <div className="bg-[#052e3b]/70 p-4 rounded border border-[#f5ecd5]/15 space-y-1">
              <div className="text-[11px] uppercase tracking-wider text-[#f5ecd5]/60">Simulated Wallet Balance</div>
              <div className="text-2xl font-masthead text-[#44745b]">10,450 sats</div>
            </div>
          </div>

          {/* Settled Invoices List */}
          <div className="space-y-3">
            <h4 className="font-masthead text-lg italic text-[#f5ecd5]">Settled Article Purchases ({settledInvoices.length})</h4>
            {settledInvoices.length === 0 ? (
              <p className="text-xs text-[#f5ecd5]/60 italic font-serif">No paid articles purchased yet in this session.</p>
            ) : (
              <div className="space-y-2">
                {settledInvoices.map((inv) => (
                  <div key={inv.id} className="bg-[#052e3b]/50 p-3 rounded border border-[#f5ecd5]/15 flex items-center justify-between">
                    <div>
                      <div className="font-masthead text-base italic text-[#f5ecd5]">{inv.articleTitle}</div>
                      <div className="text-[11px] text-[#f5ecd5]/60">
                        ID: {inv.id} • {new Date(inv.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold text-[#ffc629]">{inv.totalSats} sats</div>
                      <div className="text-[10px] text-[#44745b] flex items-center space-x-0.5 justify-end">
                        <ShieldCheck className="w-3 h-3" />
                        <span>Settled</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Tips List */}
          {tips.length > 0 && (
            <div className="space-y-3 pt-4 border-t border-[#f5ecd5]/20">
              <h4 className="font-masthead text-lg italic text-[#f5ecd5]">Author Tips Sent ({tips.length})</h4>
              <div className="space-y-2">
                {tips.map((tip) => (
                  <div key={tip.id} className="bg-[#052e3b]/50 p-3 rounded border border-[#f5ecd5]/15 flex items-center justify-between">
                    <div>
                      <div className="text-sm font-semibold">Tip to {tip.authorName}</div>
                      <div className="text-[11px] text-[#f5ecd5]/60">{new Date(tip.createdAt).toLocaleDateString()}</div>
                    </div>
                    <div className="text-right text-[#e64b2e] font-semibold">{tip.amountSats} sats</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
