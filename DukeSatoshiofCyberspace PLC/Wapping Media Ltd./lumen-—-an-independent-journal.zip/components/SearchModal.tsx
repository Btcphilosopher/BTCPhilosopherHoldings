'use client';

import React, { useState } from 'react';
import { Article } from '@/lib/types';
import { X, Search, BookOpen } from 'lucide-react';

interface SearchModalProps {
  articles: Article[];
  onClose: () => void;
  onSelectArticle: (article: Article) => void;
}

export function SearchModal({ articles, onClose, onSelectArticle }: SearchModalProps) {
  const [query, setQuery] = useState('');

  const filtered = articles.filter(
    (a) =>
      a.title.toLowerCase().includes(query.toLowerCase()) ||
      a.author.toLowerCase().includes(query.toLowerCase()) ||
      a.category.toLowerCase().includes(query.toLowerCase()) ||
      a.content.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-[#052e3b]/90 backdrop-blur-md pt-20 p-4">
      <div className="bg-[#073e50] border border-[#f5ecd5]/30 rounded-xl shadow-2xl max-w-2xl w-full text-[#f5ecd5] font-serif overflow-hidden">
        {/* Search input header */}
        <div className="p-4 border-b border-[#f5ecd5]/20 bg-[#052e3b] flex items-center space-x-3">
          <Search className="w-5 h-5 text-[#f5ecd5]/60" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search articles by title, author, or keyword..."
            className="w-full bg-transparent text-[#f5ecd5] font-serif text-lg focus:outline-none placeholder-[#f5ecd5]/40"
          />
          <button onClick={onClose} className="text-[#f5ecd5]/70 hover:text-[#f5ecd5] p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results */}
        <div className="max-h-96 overflow-y-auto p-4 space-y-3 font-sans-ui text-sm">
          {filtered.length === 0 ? (
            <div className="text-center py-8 text-[#f5ecd5]/60 italic font-serif">
              No articles found matching &quot;{query}&quot;.
            </div>
          ) : (
            filtered.map((art) => (
              <div
                key={art.id}
                onClick={() => {
                  onSelectArticle(art);
                  onClose();
                }}
                className="bg-[#052e3b]/50 p-3.5 rounded border border-[#f5ecd5]/15 hover:border-[#ffc629] cursor-pointer transition-all flex items-center justify-between group"
              >
                <div className="space-y-1">
                  <div className="text-[10px] uppercase tracking-widest text-[#e64b2e] font-semibold">
                    {art.category} • By {art.author}
                  </div>
                  <h4 className="font-masthead text-lg italic text-[#f5ecd5] group-hover:text-[#ffc629]">
                    {art.title}
                  </h4>
                </div>
                <div className="text-xs text-[#f5ecd5]/70 flex items-center space-x-1">
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>{art.isFree ? 'Free' : `${art.priceSats} sats`}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
