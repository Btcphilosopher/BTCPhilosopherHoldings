'use client';

import React, { useState, useEffect } from 'react';
import { Article, Invoice, LibraryItem } from '@/lib/types';
import { Zap, Copy, Check, QrCode, RefreshCw, AlertTriangle, ShieldCheck, X } from 'lucide-react';
import confetti from 'canvas-confetti';

interface LightningInvoiceModalProps {
  article: Article;
  onClose: () => void;
  onPaymentSuccess: (item: LibraryItem) => void;
}

export function LightningInvoiceModal({
  article,
  onClose,
  onPaymentSuccess,
}: LightningInvoiceModalProps) {
  const [invoice, setInvoice] = useState<Invoice>(() => {
    const invId = 'inv_' + Math.random().toString(36).substring(2, 10);
    const mockBolt11 = `lnbc${article.priceSats}u1${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`;
    return {
      id: invId,
      articleId: article.id,
      articleTitle: article.title,
      amountSats: article.priceSats,
      platformFeeSats: 0,
      totalSats: article.priceSats,
      paymentRequest: mockBolt11,
      paymentHash: 'hash_' + Math.random().toString(36).substring(2, 15),
      status: 'pending',
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 900000).toISOString(),
    };
  });
  const [copied, setCopied] = useState(false);
  const [status, setStatus] = useState<'pending' | 'settled' | 'expired'>('pending');
  const [timeLeft, setTimeLeft] = useState(900); // 15 mins
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          setStatus('expired');
          clearInterval(timer);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleCopy = () => {
    if (!invoice) return;
    navigator.clipboard.writeText(invoice.paymentRequest);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSimulateSettlement = () => {
    if (!invoice) return;
    setStatus('settled');
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#ffc629', '#e64b2e', '#f5ecd5', '#073e50'],
    });

    const libraryItem: LibraryItem = {
      id: 'lib_' + Math.random().toString(36).substring(2, 8),
      articleId: article.id,
      purchasedAt: new Date().toISOString(),
      priceSats: article.priceSats,
      terms: 'Perpetual reader access including future revisions',
    };
    onPaymentSuccess(libraryItem);
  };

  const handleSimulateExpiry = () => {
    setStatus('expired');
  };

  const handleSimulateDuplicate = () => {
    setErrorMessage('Duplicate payment event detected. Reconciliation verified existing entitlement.');
  };

  const handleRegenerate = () => {
    setTimeLeft(900);
    setStatus('pending');
    setErrorMessage(null);
  };

  if (!invoice) return null;

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#052e3b]/80 backdrop-blur-sm p-4">
      <div className="bg-[#073e50] border border-[#f5ecd5]/30 rounded-xl shadow-2xl max-w-lg w-full overflow-hidden text-[#f5ecd5] font-serif">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-[#f5ecd5]/20 flex items-center justify-between bg-[#052e3b]">
          <div className="flex items-center space-x-2">
            <Zap className="w-5 h-5 text-[#ffc629] fill-current" />
            <h3 className="font-masthead text-xl italic font-normal">Lightning Checkout</h3>
          </div>
          <button
            onClick={onClose}
            className="text-[#f5ecd5]/70 hover:text-[#f5ecd5] p-1 rounded hover:bg-[#073e50]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6">
          {/* Article Summary */}
          <div className="bg-[#052e3b]/60 p-4 rounded-lg border border-[#f5ecd5]/15 space-y-1">
            <div className="text-xs font-sans-ui text-[#e64b2e] uppercase tracking-wider font-semibold">
              Unlocking Article
            </div>
            <h4 className="font-masthead text-lg italic text-[#f5ecd5]">
              {article.title}
            </h4>
            <div className="flex justify-between text-xs font-sans-ui text-[#f5ecd5]/75 pt-2 border-t border-[#f5ecd5]/10">
              <span>Author: {article.author}</span>
              <span className="font-semibold text-[#ffc629]">{article.priceSats} sats</span>
            </div>
          </div>

          {status === 'settled' ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 bg-[#44745b] text-[#f5ecd5] rounded-full flex items-center justify-center mx-auto shadow-lg">
                <ShieldCheck className="w-10 h-10" />
              </div>
              <h4 className="font-masthead text-2xl italic">Payment Settled Successfully</h4>
              <p className="text-sm font-sans-ui text-[#f5ecd5]/80 max-w-sm mx-auto">
                Your Lightning invoice has been verified by the gateway. Permanent access to <span className="italic">{article.title}</span> has been granted to your library.
              </p>
              <button
                onClick={onClose}
                className="bg-[#ffc629] text-[#052e3b] font-sans-ui font-semibold px-6 py-2.5 rounded text-xs uppercase tracking-wider shadow hover:bg-[#e6ab1b] transition-all"
              >
                Start Reading Now
              </button>
            </div>
          ) : status === 'expired' ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 bg-[#e64b2e] text-[#f5ecd5] rounded-full flex items-center justify-center mx-auto shadow-lg">
                <AlertTriangle className="w-10 h-10" />
              </div>
              <h4 className="font-masthead text-2xl italic">Invoice Expired</h4>
              <p className="text-sm font-sans-ui text-[#f5ecd5]/80 max-w-sm mx-auto">
                The time window for this Lightning invoice has elapsed without settlement.
              </p>
              <button
                onClick={handleRegenerate}
                className="inline-flex items-center space-x-2 bg-[#ffc629] text-[#052e3b] font-sans-ui font-semibold px-6 py-2.5 rounded text-xs uppercase tracking-wider shadow hover:bg-[#e6ab1b]"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Generate New Invoice</span>
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {/* QR Code Simulation */}
              <div className="flex flex-col items-center justify-center p-4 bg-[#faf5eb] rounded-lg text-[#052e3b]">
                <div className="w-48 h-48 bg-white border-2 border-[#052e3b] p-3 flex items-center justify-center relative shadow-inner">
                  {/* Simulated QR Pattern */}
                  <div className="grid grid-cols-6 gap-1 w-full h-full bg-[#052e3b] p-2">
                    {Array.from({ length: 36 }).map((_, i) => (
                      <div
                        key={i}
                        className={i % 2 === 0 || i % 5 === 0 ? 'bg-[#faf5eb]' : 'bg-[#052e3b]'}
                      />
                    ))}
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-[#052e3b] text-[#ffc629] p-2 rounded-full shadow">
                      <Zap className="w-6 h-6 fill-current" />
                    </div>
                  </div>
                </div>

                <div className="mt-3 text-center">
                  <div className="text-xs font-sans-ui font-bold uppercase text-[#052e3b]">
                    Scan with Lightning Wallet
                  </div>
                  <div className="text-xs font-sans-ui text-[#052e3b]/70 mt-0.5">
                    Expires in {minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
                  </div>
                </div>
              </div>

              {/* Bolt11 string copy */}
              <div className="space-y-2">
                <div className="text-xs font-sans-ui text-[#f5ecd5]/70 flex justify-between">
                  <span>Payment Request (BOLT11)</span>
                  <span>{invoice.amountSats} sats</span>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    readOnly
                    value={invoice.paymentRequest}
                    className="w-full bg-[#052e3b] border border-[#f5ecd5]/30 rounded px-3 py-2 text-xs font-mono text-[#f5ecd5]/90 truncate"
                  />
                  <button
                    onClick={handleCopy}
                    className="bg-[#ffc629] text-[#052e3b] px-3 py-2 rounded text-xs font-sans-ui font-semibold hover:bg-[#e6ab1b] flex items-center space-x-1 shrink-0"
                  >
                    {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
              </div>

              {errorMessage && (
                <div className="p-3 bg-[#e64b2e]/20 border border-[#e64b2e] rounded text-xs text-[#f5ecd5]">
                  {errorMessage}
                </div>
              )}

              {/* Simulator Action Panel */}
              <div className="pt-4 border-t border-[#f5ecd5]/20 space-y-2">
                <div className="text-[11px] font-sans-ui uppercase tracking-wider text-[#f5ecd5]/60">
                  Deterministic Lightning Simulator Controls
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleSimulateSettlement}
                    className="bg-[#44745b] text-[#f5ecd5] hover:bg-[#345945] py-2 px-3 rounded text-xs font-sans-ui font-semibold shadow transition-all"
                  >
                    ⚡ Simulate Payment Settled
                  </button>
                  <button
                    onClick={handleSimulateExpiry}
                    className="bg-[#052e3b] border border-[#f5ecd5]/30 text-[#f5ecd5] hover:bg-[#083a4c] py-2 px-3 rounded text-xs font-sans-ui transition-all"
                  >
                    Simulate Expiry
                  </button>
                  <button
                    onClick={handleSimulateDuplicate}
                    className="bg-[#052e3b] border border-[#f5ecd5]/30 text-[#f5ecd5] hover:bg-[#083a4c] py-2 px-3 rounded text-xs font-sans-ui transition-all"
                  >
                    Simulate Duplicate Event
                  </button>
                  <button
                    onClick={onClose}
                    className="bg-[#e64b2e] text-[#f5ecd5] hover:bg-[#c93b20] py-2 px-3 rounded text-xs font-sans-ui transition-all"
                  >
                    Cancel Checkout
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
