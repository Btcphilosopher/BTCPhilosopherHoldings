'use client';

import React from 'react';
import { Article } from '@/lib/types';
import { Zap } from 'lucide-react';

interface SupportSectionProps {
  selectedArticle: Article;
  onPayWithLightning: () => void;
  isUnlocked: boolean;
  onOpenReader: (article: Article) => void;
}

export function SupportSection({
  selectedArticle,
  onPayWithLightning,
  isUnlocked,
  onOpenReader,
}: SupportSectionProps) {
  return (
    <section className="bg-[#f2e6cb] text-[#052e3b] py-12 px-4 sm:px-6 lg:px-8 border-t border-b border-[#052e3b]/20 my-12">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left Messaging */}
        <div className="lg:col-span-6 space-y-3">
          <h3 className="font-masthead text-4xl sm:text-5xl italic font-normal text-[#052e3b]">
            Keep independent writing alive.
          </h3>
          <p className="text-lg font-serif italic text-[#052e3b]/85">
            One story. One reader. A little Lightning.
          </p>
        </div>

        {/* Right Payment Box */}
        <div className="lg:col-span-6 bg-[#faf5eb] border border-[#052e3b]/25 rounded-lg p-6 shadow-md">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-xs font-sans-ui font-semibold uppercase tracking-wider text-[#e64b2e]">
                {isUnlocked ? 'Unlocked Access' : 'Selected Article'}
              </div>
              <h4 className="font-masthead text-xl italic font-semibold text-[#052e3b] line-clamp-1">
                {selectedArticle.title}
              </h4>
              <div className="text-xs font-sans-ui text-[#052e3b]/75 space-x-2 pt-1">
                <span>Article {selectedArticle.priceSats} sats</span>
                <span>•</span>
                <span>Platform fee 0 sats</span>
                <span>•</span>
                <span className="font-semibold text-[#052e3b]">Total {selectedArticle.priceSats} sats</span>
              </div>
            </div>

            <div>
              {isUnlocked || selectedArticle.isFree ? (
                <button
                  onClick={() => onOpenReader(selectedArticle)}
                  className="inline-flex items-center space-x-2 bg-[#44745b] text-[#f5ecd5] hover:bg-[#345945] px-5 py-2.5 rounded font-sans-ui font-semibold text-xs uppercase tracking-wider shadow transition-all"
                >
                  <span>Read Full Article</span>
                </button>
              ) : (
                <button
                  onClick={onPayWithLightning}
                  className="inline-flex items-center space-x-2 bg-[#052e3b] text-[#f5ecd5] hover:bg-[#083a4c] px-5 py-2.5 rounded font-sans-ui font-semibold text-xs uppercase tracking-wider shadow transition-all transform hover:-translate-y-0.5"
                >
                  <Zap className="w-4 h-4 text-[#ffc629] fill-current" />
                  <span>Pay with Lightning</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Footer copyright note matching image */}
      <div className="max-w-7xl mx-auto mt-10 pt-4 border-t border-[#052e3b]/10 text-center text-xs font-sans-ui text-[#052e3b]/60 space-x-3">
        <span>Lumen</span>
        <span>•</span>
        <span>Independent publishing concept</span>
        <span>•</span>
        <span>Illustrative prices</span>
      </div>
    </section>
  );
}
