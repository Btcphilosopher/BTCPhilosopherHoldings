'use client';

import React, { useState, useEffect } from 'react';
import { Article, Category, Invoice, LibraryItem, Tip } from '@/lib/types';
import {
  getStoredArticles,
  saveStoredArticles,
  getStoredLibrary,
  addLibraryItem,
  getStoredInvoices,
  saveInvoice,
  getStoredTips,
  addTip,
  getStoredBookmarks,
  toggleBookmark,
} from '@/lib/storage';
import { Header } from '@/components/Header';
import { Hero } from '@/components/Hero';
import { CurrentEdition } from '@/components/CurrentEdition';
import { SupportSection } from '@/components/SupportSection';
import { LightningInvoiceModal } from '@/components/LightningInvoiceModal';
import { ArticleReaderModal } from '@/components/ArticleReaderModal';
import { ArticleEditorModal } from '@/components/ArticleEditorModal';
import { PaymentsModal } from '@/components/PaymentsModal';
import { SearchModal } from '@/components/SearchModal';
import { BookOpen, ShieldCheck, Zap, Heart, Trash2, ArrowRight } from 'lucide-react';

import { INITIAL_ARTICLES } from '@/lib/mockData';

export default function LumenHomePage() {
  const [articles, setArticles] = useState<Article[]>(() => getStoredArticles());
  const [library, setLibrary] = useState<LibraryItem[]>(() => getStoredLibrary());
  const [invoices, setInvoices] = useState<Invoice[]>(() => getStoredInvoices());
  const [tips, setTips] = useState<Tip[]>(() => getStoredTips());
  const [bookmarks, setBookmarks] = useState<string[]>(() => getStoredBookmarks().map((b) => b.articleId));

  const [currentCategory, setCurrentCategory] = useState<Category | 'Discover' | 'My Library'>('Discover');
  const [selectedArticleId, setSelectedArticleId] = useState<string>('art-1'); // Default to "The city that keeps its promises"

  // Modals state
  const [readerArticle, setReaderArticle] = useState<Article | null>(null);
  const [invoiceModalArticle, setInvoiceModalArticle] = useState<Article | null>(null);
  const [writerOpen, setWriterOpen] = useState(false);
  const [paymentsOpen, setPaymentsOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const purchasedArticleIds = library.map((l) => l.articleId);

  const handleSaveArticle = (newArt: Article) => {
    const updated = [newArt, ...articles];
    setArticles(updated);
    saveStoredArticles(updated);
    // Also unlock in library if author wrote it or if free
    if (newArt.isFree) {
      const item: LibraryItem = {
        id: 'lib_' + Math.random().toString(36).substring(2, 8),
        articleId: newArt.id,
        purchasedAt: new Date().toISOString(),
        priceSats: 0,
        terms: 'Author published item',
      };
      addLibraryItem(item);
      setLibrary(getStoredLibrary());
    }
  };

  const handlePaymentSuccess = (item: LibraryItem) => {
    addLibraryItem(item);
    setLibrary(getStoredLibrary());
    const updatedInvoices = getStoredInvoices();
    setInvoices(updatedInvoices);
  };

  const handleTipAuthor = (tip: Tip) => {
    addTip(tip);
    setTips(getStoredTips());
  };

  const handleToggleBookmark = (articleId: string) => {
    const isNowSaved = toggleBookmark(articleId);
    setBookmarks(getStoredBookmarks().map((b) => b.articleId));
  };

  const selectedArticle = articles.find((a) => a.id === selectedArticleId) || articles[0];
  const isSelectedUnlocked = selectedArticle?.isFree || purchasedArticleIds.includes(selectedArticle?.id);

  // Filtered articles for category views
  const filteredArticles =
    currentCategory === 'Discover'
      ? articles
      : currentCategory === 'My Library'
      ? articles.filter((a) => purchasedArticleIds.includes(a.id) || bookmarks.includes(a.id))
      : articles.filter((a) => a.category === currentCategory);

  return (
    <div className="min-h-screen bg-[#073e50] text-[#f5ecd5] font-serif flex flex-col justify-between selection:bg-[#ffc629] selection:text-[#052e3b]">
      {/* Header */}
      <Header
        currentCategory={currentCategory}
        onSelectCategory={setCurrentCategory}
        onOpenWriter={() => setWriterOpen(true)}
        onOpenPayments={() => setPaymentsOpen(true)}
        onOpenSearch={() => setSearchOpen(true)}
        purchasedCount={library.length}
      />

      <main className="flex-1">
        {currentCategory === 'Discover' ? (
          <>
            <Hero onExplore={() => {
              const el = document.getElementById('current-edition');
              el?.scrollIntoView({ behavior: 'smooth' });
            }} />

            <div id="current-edition">
              <CurrentEdition
                articles={articles}
                selectedArticleId={selectedArticleId}
                onSelectForSupport={(art) => setSelectedArticleId(art.id)}
                onOpenReader={(art) => setReaderArticle(art)}
                purchasedArticleIds={purchasedArticleIds}
              />
            </div>

            <SupportSection
              selectedArticle={selectedArticle}
              onPayWithLightning={() => setInvoiceModalArticle(selectedArticle)}
              isUnlocked={isSelectedUnlocked}
              onOpenReader={(art) => setReaderArticle(art)}
            />
          </>
        ) : currentCategory === 'My Library' ? (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
            <div className="border-b border-[#f5ecd5]/20 pb-4">
              <h2 className="font-masthead text-3xl sm:text-4xl italic font-normal">My Library & Bookmarks</h2>
              <p className="text-sm font-sans-ui text-[#f5ecd5]/75 mt-1">
                Your purchased articles, unlocked pieces, and saved readings.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {filteredArticles.length === 0 ? (
                <div className="col-span-3 text-center py-16 text-[#f5ecd5]/60 italic">
                  Your library is empty. Explore the journal and unlock or bookmark pieces.
                </div>
              ) : (
                filteredArticles.map((art) => (
                  <div
                    key={art.id}
                    onClick={() => setReaderArticle(art)}
                    className="group cursor-pointer bg-[#052e3b]/80 border border-[#f5ecd5]/20 hover:border-[#ffc629] rounded-lg p-5 flex flex-col justify-between transition-all"
                  >
                    <div>
                      <div className="text-[11px] font-sans-ui tracking-widest text-[#e64b2e] uppercase font-semibold mb-1">
                        {art.category}
                      </div>
                      <h3 className="font-masthead text-xl italic text-[#f5ecd5] group-hover:text-[#ffc629] mb-2">
                        {art.title}
                      </h3>
                      <p className="text-xs italic text-[#f5ecd5]/75 mb-4">By {art.author}</p>
                    </div>
                    <div className="pt-4 border-t border-[#f5ecd5]/15 flex items-center justify-between text-xs font-sans-ui">
                      <span className="text-[#44745b] font-semibold flex items-center space-x-1">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Unlocked Access</span>
                      </span>
                      <span className="text-[#ffc629] underline">Read →</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        ) : (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
            <div className="border-b border-[#f5ecd5]/20 pb-4">
              <h2 className="font-masthead text-3xl sm:text-4xl italic font-normal">{currentCategory}</h2>
              <p className="text-sm font-sans-ui text-[#f5ecd5]/75 mt-1">
                Independent {currentCategory.toLowerCase()} curated for the restless mind.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {filteredArticles.map((art) => {
                const isPurchased = art.isFree || purchasedArticleIds.includes(art.id);
                return (
                  <div
                    key={art.id}
                    onClick={() => setReaderArticle(art)}
                    className="group cursor-pointer bg-[#052e3b]/80 border border-[#f5ecd5]/20 hover:border-[#ffc629] rounded-lg p-5 flex flex-col justify-between transition-all"
                  >
                    <div>
                      <div className="text-[11px] font-sans-ui tracking-widest text-[#e64b2e] uppercase font-semibold mb-1">
                        {art.category}
                      </div>
                      <h3 className="font-masthead text-xl italic text-[#f5ecd5] group-hover:text-[#ffc629] mb-2">
                        {art.title}
                      </h3>
                      <p className="text-xs italic text-[#f5ecd5]/75 mb-4">By {art.author}</p>
                    </div>
                    <div className="pt-4 border-t border-[#f5ecd5]/15 flex items-center justify-between text-xs font-sans-ui">
                      <span className="text-[#ffc629] font-semibold">
                        {isPurchased ? 'Unlocked' : `${art.priceSats} sats`}
                      </span>
                      <span className="text-[#f5ecd5]/80 underline">Read →</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-[#052e3b] border-t border-[#f5ecd5]/20 py-8 px-4 sm:px-6 lg:px-8 mt-16 text-center text-xs font-sans-ui text-[#f5ecd5]/60 space-y-2">
        <div>LUMEN — An Independent Literary Journal</div>
        <div>Built with American modernist book traditions and Lightning micropayments.</div>
      </footer>

      {/* Modals */}
      {readerArticle && (
        <ArticleReaderModal
          article={readerArticle}
          onClose={() => setReaderArticle(null)}
          isUnlocked={readerArticle.isFree || purchasedArticleIds.includes(readerArticle.id)}
          onUnlockClick={() => {
            setReaderArticle(null);
            setInvoiceModalArticle(readerArticle);
          }}
          isBookmarked={bookmarks.includes(readerArticle.id)}
          onToggleBookmark={() => handleToggleBookmark(readerArticle.id)}
          onTipAuthor={handleTipAuthor}
        />
      )}

      {invoiceModalArticle && (
        <LightningInvoiceModal
          article={invoiceModalArticle}
          onClose={() => setInvoiceModalArticle(null)}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {writerOpen && (
        <ArticleEditorModal
          onClose={() => setWriterOpen(false)}
          onSaveArticle={handleSaveArticle}
        />
      )}

      {paymentsOpen && (
        <PaymentsModal
          onClose={() => setPaymentsOpen(false)}
          invoices={invoices}
          tips={tips}
        />
      )}

      {searchOpen && (
        <SearchModal
          articles={articles}
          onClose={() => setSearchOpen(false)}
          onSelectArticle={(art) => setReaderArticle(art)}
        />
      )}
    </div>
  );
}
