import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'LUMEN — An Independent Journal',
  description: 'An independent American literary journal with Lightning micropayments and essays, fiction, poetry, and criticism.',
  openGraph: {
    title: 'LUMEN — An Independent Journal',
    description: 'An independent American literary journal with Lightning micropayments and essays, fiction, poetry, and criticism.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'LUMEN — An Independent Journal',
    description: 'An independent American literary journal with Lightning micropayments and essays, fiction, poetry, and criticism.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="h-full">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400..800;1,400..800&family=Playfair+Display:ital,wght@0,400..900;1,400..900&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body suppressHydrationWarning className="bg-[#073e50] text-[#f5ecd5] font-serif antialiased min-h-full selection:bg-[#ffc629] selection:text-[#052e3b]">
        {children}
      </body>
    </html>
  );
}
