import hashlib
import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from adapters.base import BlenderAdapter, KritaAdapter, NukeAdapter, ResolveAdapter


class TestStudioWorksPipeline(unittest.TestCase):
    def test_adapter_implementation_flags(self):
        self.assertTrue(BlenderAdapter.implemented)
        self.assertFalse(KritaAdapter.implemented)
        self.assertFalse(NukeAdapter.implemented)
        self.assertFalse(ResolveAdapter.implemented)

        with self.assertRaises(NotImplementedError):
            KritaAdapter().open_working_file("/tmp/test.kra")
        with self.assertRaises(NotImplementedError):
            NukeAdapter().validate_scene(24, 1, 100)
        with self.assertRaises(NotImplementedError):
            ResolveAdapter().generate_preview("/tmp/out.mp4")

    def test_integer_frame_rate_conversion(self):
        source_frames = [120, 96, 144]
        ratio = 25 / 24
        converted = [max(1, round(f * ratio)) for f in source_frames]
        self.assertEqual(converted, [125, 100, 150])
        self.assertTrue(all(isinstance(f, int) for f in converted))

    def test_manifest_sha256_integrity(self):
        payload = b"AUREOM_BLEND_MANIFEST_V2: Pip_Fox_Rig.blend"
        digest = hashlib.sha256(payload).hexdigest()
        self.assertEqual(len(digest), 64)
        self.assertEqual(digest, hashlib.sha256(payload).hexdigest())


if __name__ == "__main__":
    unittest.main()
