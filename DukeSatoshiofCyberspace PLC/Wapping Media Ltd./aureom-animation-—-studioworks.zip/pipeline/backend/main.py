"""
Aureom Animation — StudioWorks FastAPI Reference Gateway
Mirrors the live Express REST & WebSocket contract for PostgreSQL + S3 deployments.
"""

from datetime import datetime, timezone
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI(title="Aureom StudioWorks Pipeline API", version="1.0.0")


class ProductionSummary(BaseModel):
    id: str
    code: str
    title: str
    fps: int
    status: str


class RenderLeaseRequest(BaseModel):
    worker_id: str


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "timestamp": datetime.now(timezone.utc).isoformat()}


@app.post("/api/pipeline/convert-fps")
def convert_integer_frames(frames: List[int], source_fps: int, target_fps: int) -> dict:
    if source_fps <= 0 or target_fps not in (24, 25, 30):
        raise HTTPException(status_code=400, detail="Supported target FPS values are 24, 25, and 30.")
    ratio = target_fps / source_fps
    converted = [max(1, round(f * ratio)) for f in frames]
    return {"source_fps": source_fps, "target_fps": target_fps, "frames": converted}


@app.post("/api/pipeline/worker/claim")
def claim_job(req: RenderLeaseRequest) -> dict:
    return {"worker_id": req.worker_id, "job": None}
