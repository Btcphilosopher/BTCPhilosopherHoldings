# Aureom Animation — StudioWorks Pipeline & Companion Artifacts

## Local Production Server & Live Web UI
- Runs on Node.js 22 + Express 5 + Angular 21 SSR (`npm run dev` on port `3000`, or `npm run build && npm run serve:ssr:app`).
- Persistent records stored in `data/studioworks.json`; content-addressed S3-compatible blobs in `data/objects/<sha256>`; FFmpeg-assembled animatics and local renders in `data/media/`.

## Companion Python / PostgreSQL / Blender Pipeline (`/pipeline`)
- **Blender 4.2+ Add-on**: `pipeline/blender/aureom_studio_addon.py` — installs into Blender (`Preferences > Add-ons > Install`) and connects to `/api/pipeline/manifest/CFX`, `/api/assets/:id/publish`, and `/api/reviews/:shotId/submit-preview`.
- **Isolated Local Render Worker**: `pipeline/worker/local_render_worker.py` — claims queued jobs via `/api/pipeline/worker/claim`, sends heartbeats, runs Blender in `--factory-startup` mode with sanitized environment/network limits, and registers validated outputs idempotently.
- **Adapter Interfaces**: `pipeline/adapters/base.py` — `BlenderAdapter` implemented; `KritaAdapter`, `NukeAdapter`, and `ResolveAdapter` explicitly marked unimplemented (`NotImplementedError`).
- **PostgreSQL Schema & Docker Compose**: `pipeline/db/migrations/001_initial_schema.sql` and `pipeline/docker-compose.yml`.

## Tests
- Backend & Pipeline Integration Suite: `npx vitest run src/server/__tests__/studioworks.spec.ts`
- Python Pipeline & Adapter Suite: `python3 -m unittest discover -s pipeline/tests`
