-- Aureom Animation — StudioWorks PostgreSQL Initial Migration (001)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE studios (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  legal_entity TEXT NOT NULL,
  default_currency CHAR(3) NOT NULL DEFAULT 'GBP',
  ai_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  revision INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE team_members (
  id TEXT PRIMARY KEY,
  studio_id TEXT NOT NULL REFERENCES studios(id),
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('Producer','Director','Supervisor','Artist','Reviewer','Finance','Administrator')),
  department TEXT NOT NULL,
  day_rate NUMERIC(10, 2) NOT NULL,
  weekly_capacity_hours INTEGER NOT NULL DEFAULT 40
);

CREATE TABLE productions (
  id TEXT PRIMARY KEY,
  studio_id TEXT NOT NULL REFERENCES studios(id),
  code TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  format TEXT NOT NULL,
  pipeline_mode TEXT NOT NULL CHECK (pipeline_mode IN ('3D','2D')),
  fps INTEGER NOT NULL CHECK (fps > 0),
  currency CHAR(3) NOT NULL DEFAULT 'GBP',
  status TEXT NOT NULL,
  delivery_deadline DATE NOT NULL,
  revision INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE sequences (
  id TEXT PRIMARY KEY,
  production_id TEXT NOT NULL REFERENCES productions(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  title TEXT NOT NULL,
  order_index INTEGER NOT NULL
);

CREATE TABLE shots (
  id TEXT PRIMARY KEY,
  production_id TEXT NOT NULL REFERENCES productions(id) ON DELETE CASCADE,
  sequence_id TEXT NOT NULL REFERENCES sequences(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  title TEXT NOT NULL,
  start_frame INTEGER NOT NULL,
  end_frame INTEGER NOT NULL,
  fps INTEGER NOT NULL,
  frame_count INTEGER NOT NULL CHECK (frame_count > 0),
  status TEXT NOT NULL,
  revision INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE assets (
  id TEXT PRIMARY KEY,
  production_id TEXT NOT NULL REFERENCES productions(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  working_file_path TEXT NOT NULL,
  rights_cleared BOOLEAN NOT NULL DEFAULT TRUE,
  revision INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE published_versions (
  id TEXT PRIMARY KEY,
  asset_id TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  version_number INTEGER NOT NULL,
  version_label TEXT NOT NULL,
  content_hash CHAR(64) NOT NULL,
  object_key TEXT NOT NULL,
  tool_name TEXT NOT NULL,
  tool_version TEXT NOT NULL,
  published_by TEXT NOT NULL,
  published_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (asset_id, version_number)
);

CREATE TABLE render_jobs (
  id TEXT PRIMARY KEY,
  production_id TEXT NOT NULL REFERENCES productions(id),
  shot_id TEXT NOT NULL REFERENCES shots(id),
  state TEXT NOT NULL CHECK (state IN ('Queued','Assigned','Running','Validating','Completed','Failed','Cancelled')),
  execution_mode TEXT NOT NULL CHECK (execution_mode IN ('Local Worker','Simulated Farm')),
  frame_start INTEGER NOT NULL,
  frame_end INTEGER NOT NULL,
  idempotency_key TEXT UNIQUE NOT NULL,
  worker_id TEXT,
  lease_expires_at TIMESTAMPTZ,
  attempt_count INTEGER NOT NULL DEFAULT 0,
  max_retries INTEGER NOT NULL DEFAULT 3,
  output_hash CHAR(64),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE budget_lines (
  id TEXT PRIMARY KEY,
  production_id TEXT NOT NULL REFERENCES productions(id) ON DELETE CASCADE,
  department TEXT NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'GBP',
  budget_amount NUMERIC(14, 2) NOT NULL,
  committed_amount NUMERIC(14, 2) NOT NULL,
  actual_amount NUMERIC(14, 2) NOT NULL,
  forecast_remaining_amount NUMERIC(14, 2) NOT NULL
);

CREATE TABLE delivery_packages (
  id TEXT PRIMARY KEY,
  production_id TEXT NOT NULL REFERENCES productions(id),
  package_name TEXT NOT NULL,
  version_label TEXT NOT NULL,
  lifecycle_state TEXT NOT NULL CHECK (lifecycle_state IN ('Generated','Passed Review','Accepted by Distributor')),
  media_checksum CHAR(64) NOT NULL,
  manifest_json JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE audit_log (
  id TEXT PRIMARY KEY,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  actor_id TEXT NOT NULL,
  actor_role TEXT NOT NULL,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  detail TEXT NOT NULL
);
