"""Adapter interfaces for Aureom Animation StudioWorks external DCC tools."""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class SceneValidationReport:
    valid: bool
    errors: List[str]
    warnings: List[str]
    fps: int
    frame_start: int
    frame_end: int


class ToolAdapter(ABC):
    tool_name: str
    implemented: bool = False

    @abstractmethod
    def open_working_file(self, file_path: str) -> None:
        raise NotImplementedError

    @abstractmethod
    def retrieve_approved_dependencies(self, dependency_manifests: List[dict]) -> List[str]:
        raise NotImplementedError

    @abstractmethod
    def validate_scene(self, expected_fps: int, frame_start: int, frame_end: int) -> SceneValidationReport:
        raise NotImplementedError

    @abstractmethod
    def save_working_revision(self, target_path: str) -> str:
        raise NotImplementedError

    @abstractmethod
    def generate_preview(self, output_path: str) -> str:
        raise NotImplementedError


class BlenderAdapter(ToolAdapter):
    tool_name = "Blender"
    implemented = True

    def open_working_file(self, file_path: str) -> None:
        import bpy  # type: ignore
        bpy.ops.wm.open_mainfile(filepath=file_path)

    def retrieve_approved_dependencies(self, dependency_manifests: List[dict]) -> List[str]:
        return [d["objectKey"] for d in dependency_manifests if "objectKey" in d]

    def validate_scene(self, expected_fps: int, frame_start: int, frame_end: int) -> SceneValidationReport:
        import bpy  # type: ignore
        scene = bpy.context.scene
        errors: List[str] = []
        warnings: List[str] = []
        if scene.render.fps != expected_fps:
            errors.append(f"Scene FPS {scene.render.fps} does not match production FPS {expected_fps}.")
        if scene.frame_start != frame_start or scene.frame_end != frame_end:
            errors.append(
                f"Scene range {scene.frame_start}-{scene.frame_end} differs from shot {frame_start}-{frame_end}."
            )
        for lib in bpy.data.libraries:
            if not bpy.path.abspath(lib.filepath):
                errors.append(f"Missing library dependency: {lib.filepath}")
        return SceneValidationReport(
            valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            fps=int(scene.render.fps),
            frame_start=int(scene.frame_start),
            frame_end=int(scene.frame_end),
        )

    def save_working_revision(self, target_path: str) -> str:
        import bpy  # type: ignore
        bpy.ops.wm.save_as_mainfile(filepath=target_path)
        return target_path

    def generate_preview(self, output_path: str) -> str:
        import bpy  # type: ignore
        bpy.context.scene.render.filepath = output_path
        bpy.ops.render.opengl(animation=True)
        return output_path


class KritaAdapter(ToolAdapter):
    tool_name = "Krita"
    implemented = False

    def open_working_file(self, file_path: str) -> None:
        raise NotImplementedError("KritaAdapter is an unimplemented interface stub in this release.")

    def retrieve_approved_dependencies(self, dependency_manifests: List[dict]) -> List[str]:
        raise NotImplementedError("KritaAdapter is an unimplemented interface stub in this release.")

    def validate_scene(self, expected_fps: int, frame_start: int, frame_end: int) -> SceneValidationReport:
        raise NotImplementedError("KritaAdapter is an unimplemented interface stub in this release.")

    def save_working_revision(self, target_path: str) -> str:
        raise NotImplementedError("KritaAdapter is an unimplemented interface stub in this release.")

    def generate_preview(self, output_path: str) -> str:
        raise NotImplementedError("KritaAdapter is an unimplemented interface stub in this release.")


class NukeAdapter(ToolAdapter):
    tool_name = "Nuke"
    implemented = False

    def open_working_file(self, file_path: str) -> None:
        raise NotImplementedError("NukeAdapter is an unimplemented interface stub in this release.")

    def retrieve_approved_dependencies(self, dependency_manifests: List[dict]) -> List[str]:
        raise NotImplementedError("NukeAdapter is an unimplemented interface stub in this release.")

    def validate_scene(self, expected_fps: int, frame_start: int, frame_end: int) -> SceneValidationReport:
        raise NotImplementedError("NukeAdapter is an unimplemented interface stub in this release.")

    def save_working_revision(self, target_path: str) -> str:
        raise NotImplementedError("NukeAdapter is an unimplemented interface stub in this release.")

    def generate_preview(self, output_path: str) -> str:
        raise NotImplementedError("NukeAdapter is an unimplemented interface stub in this release.")


class ResolveAdapter(ToolAdapter):
    tool_name = "DaVinci Resolve"
    implemented = False

    def open_working_file(self, file_path: str) -> None:
        raise NotImplementedError("ResolveAdapter is an unimplemented interface stub in this release.")

    def retrieve_approved_dependencies(self, dependency_manifests: List[dict]) -> List[str]:
        raise NotImplementedError("ResolveAdapter is an unimplemented interface stub in this release.")

    def validate_scene(self, expected_fps: int, frame_start: int, frame_end: int) -> SceneValidationReport:
        raise NotImplementedError("ResolveAdapter is an unimplemented interface stub in this release.")

    def save_working_revision(self, target_path: str) -> str:
        raise NotImplementedError("ResolveAdapter is an unimplemented interface stub in this release.")

    def generate_preview(self, output_path: str) -> str:
        raise NotImplementedError("ResolveAdapter is an unimplemented interface stub in this release.")
