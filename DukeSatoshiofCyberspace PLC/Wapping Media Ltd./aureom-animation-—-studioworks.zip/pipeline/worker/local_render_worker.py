"""
Aureom Animation — Isolated Local Render Worker
Polls StudioWorks /api/pipeline/worker/claim, maintains heartbeats,
runs untrusted scene workloads with --factory-startup and stripped credentials,
and verifies output frames with ffprobe before idempotent completion.
"""

import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request


class LocalRenderWorker:
    def __init__(self, api_url: str, worker_id: str, bearer_token: str):
        self.api_url = api_url.rstrip("/")
        self.worker_id = worker_id
        self.bearer_token = bearer_token

    def _post(self, path: str, payload: dict) -> dict:
        req = urllib.request.Request(
            f"{self.api_url}{path}",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.bearer_token}",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def send_heartbeat(self, status: str = "Online") -> dict:
        return self._post("/api/pipeline/worker/heartbeat", {"workerId": self.worker_id, "status": status})

    def claim_next_job(self) -> dict | None:
        res = self._post("/api/pipeline/worker/claim", {"workerId": self.worker_id})
        return res.get("job")

    def execute_isolated_render(self, job: dict) -> dict:
        """
        Executes Blender in --factory-startup mode if installed, otherwise delegates
        to the server's confined FFmpeg procedural render endpoint.
        Strips sensitive studio credentials from the subprocess environment.
        """
        blender_bin = shutil.which("blender")
        sanitized_env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": "/tmp"}

        if blender_bin and os.path.exists(job.get("blendPath", "")):
            subprocess.run(
                [
                    blender_bin,
                    "--background",
                    "--factory-startup",
                    job["blendPath"],
                    "--python-exit-code",
                    "1",
                    "-s",
                    str(job["frameStart"]),
                    "-e",
                    str(job["frameEnd"]),
                    "-a",
                ],
                env=sanitized_env,
                check=True,
                timeout=300,
            )

        # Register idempotent completion & ffprobe verification via API
        return self._post(f"/api/render-jobs/{job['id']}/run-local", {})

    def run_once(self) -> bool:
        self.send_heartbeat("Online")
        job = self.claim_next_job()
        if not job:
            return False
        self.send_heartbeat("Busy")
        self.execute_isolated_render(job)
        self.send_heartbeat("Online")
        return True


if __name__ == "__main__":
    url = os.environ.get("STUDIOWORKS_API_URL", "http://localhost:3000")
    wid = os.environ.get("WORKER_ID", "wrk_local_01")
    tok = os.environ.get("STUDIOWORKS_TOKEN", "")
    if not tok:
        print("Set STUDIOWORKS_TOKEN before starting worker.", file=sys.stderr)
        sys.exit(1)
    worker = LocalRenderWorker(url, wid, tok)
    while True:
        worked = worker.run_once()
        time.sleep(2 if worked else 5)
