import {createHash, randomUUID} from 'node:crypto';
import {existsSync, mkdirSync, readFileSync, statSync, writeFileSync} from 'node:fs';
import {extname, join, resolve, sep} from 'node:path';

export const ALLOWED_UPLOAD_EXTENSIONS = new Set([
  '.png',
  '.jpg',
  '.jpeg',
  '.webp',
  '.svg',
  '.mp4',
  '.webm',
  '.wav',
  '.mp3',
  '.blend',
  '.json',
  '.srt',
  '.txt',
  '.exr',
]);

export const MAX_UPLOAD_BYTES = 50 * 1024 * 1024; // 50 MB guardrail per file

export interface UploadSession {
  id: string;
  fileName: string;
  mimeType: string;
  expectedSize: number;
  expectedSha256?: string;
  receivedBytes: number;
  chunks: Map<number, Buffer>;
  createdAt: string;
}

export interface StoredObject {
  objectKey: string;
  contentHash: string;
  byteSize: number;
  fileName: string;
  mimeType: string;
  publicUrl: string;
  isDuplicate: boolean;
}

export class LocalObjectStore {
  private readonly baseDir: string;
  private readonly objectsDir: string;
  private readonly mediaDir: string;
  private readonly uploadSessions = new Map<string, UploadSession>();

  constructor(rootDir: string = resolve(process.cwd(), 'data')) {
    this.baseDir = rootDir;
    this.objectsDir = join(rootDir, 'objects');
    this.mediaDir = join(rootDir, 'media');
    mkdirSync(this.objectsDir, {recursive: true});
    mkdirSync(this.mediaDir, {recursive: true});
  }

  public getBaseDir(): string {
    return this.baseDir;
  }

  public getMediaDir(): string {
    return this.mediaDir;
  }

  public getObjectsDir(): string {
    return this.objectsDir;
  }

  public validateFileMeta(fileName: string, byteSize: number): {ok: true} | {ok: false; reason: string} {
    const cleanName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
    const ext = extname(cleanName).toLowerCase();
    if (!ALLOWED_UPLOAD_EXTENSIONS.has(ext)) {
      return {
        ok: false,
        reason: `Unsupported file extension '${ext || 'none'}'. Allowed: ${Array.from(ALLOWED_UPLOAD_EXTENSIONS).join(', ')}`,
      };
    }
    if (!Number.isFinite(byteSize) || byteSize <= 0 || byteSize > MAX_UPLOAD_BYTES) {
      return {
        ok: false,
        reason: `File size (${byteSize} bytes) must be between 1 byte and ${MAX_UPLOAD_BYTES} bytes.`,
      };
    }
    return {ok: true};
  }

  public computeSha256(buffer: Buffer): string {
    return createHash('sha256').update(buffer).digest('hex');
  }

  public storeImmutableBuffer(
    buffer: Buffer,
    fileName: string,
    mimeType: string,
    expectedSha256?: string,
  ): StoredObject {
    const validation = this.validateFileMeta(fileName, buffer.byteLength);
    if (!validation.ok) {
      throw new Error(validation.reason);
    }

    const contentHash = this.computeSha256(buffer);
    if (expectedSha256 && expectedSha256.toLowerCase() !== contentHash) {
      throw new Error(`Checksum mismatch: expected ${expectedSha256}, computed ${contentHash}`);
    }

    const ext = extname(fileName).toLowerCase() || '.bin';
    const objectKey = `sha256/${contentHash}${ext}`;
    const targetPath = this.resolveConfined(this.objectsDir, `${contentHash}${ext}`);
    const alreadyExists = existsSync(targetPath);
    if (!alreadyExists) {
      writeFileSync(targetPath, buffer);
    }

    return {
      objectKey,
      contentHash,
      byteSize: buffer.byteLength,
      fileName: fileName.replace(/[^a-zA-Z0-9._-]/g, '_'),
      mimeType,
      publicUrl: `/api/objects/${contentHash}${ext}`,
      isDuplicate: alreadyExists,
    };
  }

  public readObjectByFilename(safeName: string): {buffer: Buffer; path: string} | null {
    if (!/^[a-f0-9]{64}\.[a-z0-9]+$/i.test(safeName)) {
      return null;
    }
    const targetPath = this.resolveConfined(this.objectsDir, safeName);
    if (!existsSync(targetPath)) {
      return null;
    }
    return {buffer: readFileSync(targetPath), path: targetPath};
  }

  public resolveConfined(baseDir: string, relativePath: string): string {
    const normalizedBase = resolve(baseDir);
    const resolved = resolve(normalizedBase, relativePath);
    if (!resolved.startsWith(normalizedBase + sep)) {
      throw new Error('Path traversal rejected: target escapes confined storage directory.');
    }
    return resolved;
  }

  public initResumableUpload(params: {
    fileName: string;
    mimeType: string;
    expectedSize: number;
    expectedSha256?: string;
  }): UploadSession {
    const validation = this.validateFileMeta(params.fileName, params.expectedSize);
    if (!validation.ok) {
      throw new Error(validation.reason);
    }
    const session: UploadSession = {
      id: `upl_${randomUUID()}`,
      fileName: params.fileName.replace(/[^a-zA-Z0-9._-]/g, '_'),
      mimeType: params.mimeType || 'application/octet-stream',
      expectedSize: params.expectedSize,
      expectedSha256: params.expectedSha256,
      receivedBytes: 0,
      chunks: new Map(),
      createdAt: new Date().toISOString(),
    };
    this.uploadSessions.set(session.id, session);
    return session;
  }

  public appendUploadChunk(uploadId: string, chunkIndex: number, data: Buffer): UploadSession {
    const session = this.uploadSessions.get(uploadId);
    if (!session) {
      throw new Error('Upload session not found or expired.');
    }
    if (session.receivedBytes + data.byteLength > MAX_UPLOAD_BYTES) {
      throw new Error('Resumable upload exceeded maximum allowed file size.');
    }
    if (!session.chunks.has(chunkIndex)) {
      session.chunks.set(chunkIndex, data);
      session.receivedBytes += data.byteLength;
    }
    return session;
  }

  public completeResumableUpload(uploadId: string): StoredObject {
    const session = this.uploadSessions.get(uploadId);
    if (!session) {
      throw new Error('Upload session not found or expired.');
    }
    const orderedKeys = Array.from(session.chunks.keys()).sort((a, b) => a - b);
    const buffers = orderedKeys.map((idx) => session.chunks.get(idx)!);
    const combined = Buffer.concat(buffers);
    if (combined.byteLength === 0) {
      throw new Error('Cannot complete empty upload.');
    }
    const stored = this.storeImmutableBuffer(
      combined,
      session.fileName,
      session.mimeType,
      session.expectedSha256,
    );
    this.uploadSessions.delete(uploadId);
    return stored;
  }

  public writeGeneratedMediaFile(relativeName: string, buffer: Buffer): {url: string; contentHash: string; path: string} {
    const safeName = relativeName.replace(/[^a-zA-Z0-9._-]/g, '_');
    const targetPath = this.resolveConfined(this.mediaDir, safeName);
    writeFileSync(targetPath, buffer);
    return {
      url: `/api/media/${safeName}`,
      contentHash: this.computeSha256(buffer),
      path: targetPath,
    };
  }

  public resolveMediaPath(safeName: string): string | null {
    if (!/^[a-zA-Z0-9._-]+$/.test(safeName)) {
      return null;
    }
    const targetPath = this.resolveConfined(this.mediaDir, safeName);
    if (!existsSync(targetPath)) {
      return null;
    }
    const stats = statSync(targetPath);
    return stats.isFile() ? targetPath : null;
  }
}
