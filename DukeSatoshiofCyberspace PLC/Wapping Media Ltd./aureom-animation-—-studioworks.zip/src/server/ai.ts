import {GoogleGenAI, Type} from '@google/genai';
import type {StudioDatabaseState} from './types';

function createGeminiClient(): GoogleGenAI | null {
  const apiKey = (process.env['GEMINI_API_KEY'] || '').trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export async function suggestScriptBreakdownWithAi(params: {
  scriptText: string;
  productionTitle: string;
}): Promise<{
  proposedAssets: {name: string; category: string; rationale: string}[];
  proposedShots: {code: string; sequenceCode: string; summary: string; estimatedFrames: number}[];
}> {
  const ai = createGeminiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is not configured in server secrets.');
  }

  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: `Production: ${params.productionTitle}\n\nScript text:\n${params.scriptText}\n\nExtract proposed assets (Character, Environment, Prop) and proposed shots at 24fps.`,
    config: {
      systemInstruction:
        'You are an animation production coordinator assistant. Propose concise structured breakdown items for human producer confirmation.',
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          proposedAssets: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: {type: Type.STRING},
                category: {type: Type.STRING},
                rationale: {type: Type.STRING},
              },
            },
          },
          proposedShots: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                code: {type: Type.STRING},
                sequenceCode: {type: Type.STRING},
                summary: {type: Type.STRING},
                estimatedFrames: {type: Type.INTEGER},
              },
            },
          },
        },
      },
    },
  });

  const parsed = JSON.parse((response.text ?? '{}').trim()) as {
    proposedAssets?: {name: string; category: string; rationale: string}[];
    proposedShots?: {code: string; sequenceCode: string; summary: string; estimatedFrames: number}[];
  };
  return {
    proposedAssets: parsed.proposedAssets ?? [],
    proposedShots: parsed.proposedShots ?? [],
  };
}

export async function runStudioAiAssistant(params: {
  feature: 'Asset Tagging' | 'Record Search' | 'Review Summary' | 'Schedule Conflicts' | 'Production Report';
  promptInput: string;
  state: StudioDatabaseState;
}): Promise<string> {
  const ai = createGeminiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is not configured in server secrets.');
  }

  const contextSnapshot = {
    studio: params.state.studio.name,
    productions: params.state.productions.map((p) => ({
      code: p.code,
      title: p.title,
      status: p.status,
      deadline: p.deliveryDeadline,
      milestones: p.milestones,
    })),
    shotsCount: params.state.shots.length,
    blockedOrFlaggedTasks: params.state.shots.flatMap((s) =>
      s.tasks
        .filter((t) => t.blockerNote || t.upstreamFlagged)
        .map((t) => ({shot: s.code, dept: t.department, due: t.dueDate, reason: t.blockerNote || t.upstreamFlagReason})),
    ),
    unresolvedComments: params.state.reviews.flatMap((r) =>
      r.comments.filter((c) => !c.resolved).map((c) => ({shot: r.title, frame: c.frameNumber, note: c.body})),
    ),
    missingRights: params.state.rights.filter((r) => r.status !== 'Verified'),
  };

  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: `Task: ${params.feature}\nStudio Context:\n${JSON.stringify(contextSnapshot)}\n\nRequest:\n${params.promptInput}`,
    config: {
      systemInstruction:
        'You are an animation production manager assistant at Aureom Animation. Be concise, factual, grounded strictly in the provided production records, and never fabricate metrics.',
    },
  });

  return (response.text ?? '').trim();
}
