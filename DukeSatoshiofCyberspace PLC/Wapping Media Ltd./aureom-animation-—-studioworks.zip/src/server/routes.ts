import {createHash, randomUUID} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {extname, resolve} from 'node:path';
import express, {type NextFunction, type Request, type Response, type Router} from 'express';
import {runStudioAiAssistant, suggestScriptBreakdownWithAi} from './ai';
import {type AuthSessionClaims, type PermissionAction, StudioDatabase} from './database';
import {generateAnimaticMp4, generateShotRenderClip} from './media';
import type {
  ApprovalStatus,
  Asset,
  AssetCategory,
  BreakdownProposal,
  BudgetLine,
  DeliveryPackage,
  DeliveryPackageState,
  Production,
  PurchaseRecord,
  RenderJob,
  ReviewComment,
  RightsRecord,
  StoryboardPanel,
  TimesheetEntry,
} from './types';

export interface BroadcastEvent {
  type:
    | 'render:progress'
    | 'review:updated'
    | 'asset:published'
    | 'shot:updated'
    | 'delivery:updated'
    | 'audit:added';
  payload: Record<string, unknown>;
}

export type BroadcasterFn = (event: BroadcastEvent) => void;

interface AuthenticatedRequest extends Request {
  sessionClaims?: AuthSessionClaims;
}

const MIME_BY_EXT: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.wav': 'audio/wav',
  '.mp3': 'audio/mpeg',
  '.json': 'application/json',
  '.txt': 'text/plain; charset=utf-8',
  '.srt': 'text/plain; charset=utf-8',
  '.blend': 'application/octet-stream',
};

export function createApiRouter(
  db: StudioDatabase,
  broadcast: BroadcasterFn,
  workspaceRoot: string = process.cwd(),
): Router {
  const router = express.Router();
  router.use(express.json({limit: '16mb'}));

  const requireAuth = (action?: PermissionAction) => {
    return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
      const authHeader = req.headers.authorization || '';
      const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
      const claims = db.verifySessionToken(token);
      if (!claims) {
        res.status(401).json({
          error: 'Authentication required. Sign in with the studio passcode to perform modifications.',
        });
        return;
      }
      if (action && !db.hasPermission(claims.role, action)) {
        res.status(403).json({
          error: `Role '${claims.role}' is not permitted to perform '${action}'.`,
        });
        return;
      }
      req.sessionClaims = claims;
      next();
    };
  };

  // --- Auth & Session ---
  router.get('/auth/status', (_req, res) => {
    res.json(db.getAuthStatus());
  });

  router.post('/auth/claim', (req, res) => {
    const passcode = typeof req.body?.passcode === 'string' ? req.body.passcode : '';
    const memberId = typeof req.body?.memberId === 'string' ? req.body.memberId : 'usr_admin';
    const result = db.claimInitialPasscode(passcode);
    if (!result.ok) {
      res.status(400).json({error: result.reason});
      return;
    }
    const state = db.getState();
    const member = state.team.find((m) => m.id === memberId) || state.team[0];
    const token = db.issueSessionToken(member);
    db.recordAudit({
      actorId: member.id,
      actorName: member.name,
      actorRole: member.role,
      action: 'STUDIO_PASSCODE_CLAIMED',
      entityType: 'Studio',
      entityId: state.studio.id,
      detail: 'Initial studio operator passcode claimed and hashed with scrypt.',
    });
    db.persist();
    res.json({token, member, authStatus: db.getAuthStatus()});
  });

  router.post('/auth/login', (req, res) => {
    const passcode = typeof req.body?.passcode === 'string' ? req.body.passcode : '';
    const memberId = typeof req.body?.memberId === 'string' ? req.body.memberId : 'usr_clara';
    if (!db.verifyPasscode(passcode)) {
      res.status(401).json({error: 'Invalid studio passcode.'});
      return;
    }
    const state = db.getState();
    const member = state.team.find((m) => m.id === memberId && m.active);
    if (!member) {
      res.status(404).json({error: 'Team member not found or inactive.'});
      return;
    }
    const token = db.issueSessionToken(member);
    db.recordAudit({
      actorId: member.id,
      actorName: member.name,
      actorRole: member.role,
      action: 'SESSION_SIGNED_IN',
      entityType: 'TeamMember',
      entityId: member.id,
      detail: `Signed in as ${member.name} (${member.role}).`,
    });
    db.persist();
    res.json({token, member});
  });

  router.post('/auth/switch-role', requireAuth(), (req: AuthenticatedRequest, res) => {
    const memberId = typeof req.body?.memberId === 'string' ? req.body.memberId : '';
    const state = db.getState();
    const member = state.team.find((m) => m.id === memberId && m.active);
    if (!member) {
      res.status(404).json({error: 'Team member not found.'});
      return;
    }
    const token = db.issueSessionToken(member);
    res.json({token, member});
  });

  // --- Bootstrap State (never leaks auth hashes) ---
  router.get('/studio/bootstrap', (_req, res) => {
    const s = db.getState();
    res.json({
      studio: s.studio,
      authStatus: db.getAuthStatus(),
      team: s.team,
      deliverySpecs: s.deliverySpecs,
      productions: s.productions,
      episodes: s.episodes,
      sequences: s.sequences,
      scripts: s.scripts,
      breakdownProposals: s.breakdownProposals,
      storyboards: s.storyboards,
      animatics: s.animatics,
      assets: s.assets,
      shots: s.shots,
      reviews: s.reviews,
      externalReviewLinks: s.externalReviewLinks,
      workers: s.workers,
      renderJobs: s.renderJobs,
      timesheets: s.timesheets,
      budgetLines: s.budgetLines,
      purchases: s.purchases,
      rights: s.rights,
      deliveries: s.deliveries,
      auditLog: s.auditLog,
      aiProvenance: s.aiProvenance,
      toolAdapters: s.toolAdapters,
    });
  });

  // --- Protected Object & Media Reads ---
  router.get('/objects/:filename', (req, res) => {
    const found = db.getObjectStore().readObjectByFilename(req.params.filename);
    if (!found) {
      res.status(404).json({error: 'Object not found.'});
      return;
    }
    const ext = extname(req.params.filename).toLowerCase();
    res.setHeader('Content-Type', MIME_BY_EXT[ext] || 'application/octet-stream');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
    res.send(found.buffer);
  });

  router.get('/media/:filename', (req, res) => {
    const mediaPath = db.getObjectStore().resolveMediaPath(req.params.filename);
    if (!mediaPath) {
      res.status(404).json({error: 'Media file not found.'});
      return;
    }
    const ext = extname(req.params.filename).toLowerCase();
    res.setHeader('Content-Type', MIME_BY_EXT[ext] || 'application/octet-stream');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.send(readFileSync(mediaPath));
  });

  // --- Resumable & Checksummed Uploads ---
  router.post('/uploads/init', requireAuth('asset:work'), (req, res) => {
    try {
      const {fileName, mimeType, expectedSize, expectedSha256} = req.body as {
        fileName: string;
        mimeType?: string;
        expectedSize: number;
        expectedSha256?: string;
      };
      const session = db.getObjectStore().initResumableUpload({
        fileName,
        mimeType: mimeType || 'application/octet-stream',
        expectedSize: Number(expectedSize),
        expectedSha256,
      });
      res.status(201).json({uploadId: session.id, fileName: session.fileName, expectedSize: session.expectedSize});
    } catch (err) {
      res.status(400).json({error: err instanceof Error ? err.message : 'Invalid upload request.'});
    }
  });

  router.post('/uploads/:id/chunk', requireAuth('asset:work'), (req, res) => {
    try {
      const chunkIndex = Number(req.body?.chunkIndex ?? 0);
      const base64Data = typeof req.body?.base64Data === 'string' ? req.body.base64Data : '';
      const buf = Buffer.from(base64Data, 'base64');
      const session = db.getObjectStore().appendUploadChunk(String(req.params['id']), chunkIndex, buf);
      res.json({uploadId: session.id, receivedBytes: session.receivedBytes});
    } catch (err) {
      res.status(400).json({error: err instanceof Error ? err.message : 'Chunk upload failed.'});
    }
  });

  router.post('/uploads/:id/complete', requireAuth('asset:work'), (req, res) => {
    try {
      const stored = db.getObjectStore().completeResumableUpload(String(req.params['id']));
      res.json(stored);
    } catch (err) {
      res.status(400).json({error: err instanceof Error ? err.message : 'Failed to complete upload.'});
    }
  });

  router.post('/uploads/direct', requireAuth('asset:work'), (req, res) => {
    try {
      const {fileName, mimeType, base64Data, expectedSha256} = req.body as {
        fileName: string;
        mimeType?: string;
        base64Data: string;
        expectedSha256?: string;
      };
      const cleanBase64 = (base64Data || '').replace(/^data:[^;]+;base64,/, '');
      const buf = Buffer.from(cleanBase64, 'base64');
      const stored = db.getObjectStore().storeImmutableBuffer(
        buf,
        fileName,
        mimeType || 'application/octet-stream',
        expectedSha256,
      );
      // Duplicate detection across existing assets
      const duplicateOf = db.getState().assets.find((a) =>
        a.versions.some((v) => v.contentHash === stored.contentHash),
      );
      res.status(201).json({
        ...stored,
        duplicateAssetCode: duplicateOf?.code ?? null,
      });
    } catch (err) {
      res.status(400).json({error: err instanceof Error ? err.message : 'Direct upload failed.'});
    }
  });

  // --- Productions & Shared Asset Permissions ---
  router.post('/productions', requireAuth('production:write'), (req: AuthenticatedRequest, res) => {
    const body = req.body as Partial<Production>;
    if (!body.code || !body.title) {
      res.status(400).json({error: 'Production code and title are required.'});
      return;
    }
    const state = db.getState();
    const now = new Date().toISOString();
    const prod: Production = {
      id: `prod_${randomUUID().slice(0, 8)}`,
      code: body.code.trim().toUpperCase().slice(0, 8),
      title: body.title.trim(),
      format: body.format || 'Short Film',
      audience: body.audience || 'General',
      synopsis: body.synopsis || '',
      creativeBrief: body.creativeBrief || '',
      pipelineMode: body.pipelineMode || '3D',
      fps: Number(body.fps || 24),
      aspectRatio: body.aspectRatio || '16:9',
      currency: body.currency || state.studio.defaultCurrency,
      status: body.status || 'Development',
      deliveryDeadline: body.deliveryDeadline || '2027-06-01',
      deliverySpecId: body.deliverySpecId || state.deliverySpecs[0]?.id || 'spec_uk_theatrical_short',
      milestones: body.milestones || [],
      sharedAssetPermissions: [],
      revision: 1,
      createdAt: now,
      updatedAt: now,
    };
    state.productions.push(prod);
    state.episodes.push({
      id: `ep_${randomUUID().slice(0, 8)}`,
      productionId: prod.id,
      code: 'EP001',
      title: `${prod.title} — Master`,
      kind: prod.format === 'Television Series' ? 'Episode' : 'Short Film',
      orderIndex: 1,
      targetDurationFrames: prod.fps * 60,
    });
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'PRODUCTION_CREATED',
      entityType: 'Production',
      entityId: prod.id,
      detail: `Created production ${prod.code} (${prod.title})`,
    });
    db.persist();
    res.status(201).json(prod);
  });

  router.patch('/productions/:id', requireAuth('production:write'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const prod = state.productions.find((p) => p.id === req.params['id']);
    if (!prod) {
      res.status(404).json({error: 'Production not found.'});
      return;
    }
    const expectedRev = req.body?.expectedRevision;
    if (typeof expectedRev === 'number' && expectedRev !== prod.revision) {
      res.status(409).json({
        error: `Concurrent edit conflict: production was modified (expected rev ${expectedRev}, current rev ${prod.revision}). Refresh before saving.`,
      });
      return;
    }
    if (typeof req.body?.title === 'string') prod.title = req.body.title.trim();
    if (typeof req.body?.synopsis === 'string') prod.synopsis = req.body.synopsis;
    if (typeof req.body?.creativeBrief === 'string') prod.creativeBrief = req.body.creativeBrief;
    if (typeof req.body?.status === 'string') prod.status = req.body.status;
    if (typeof req.body?.deliveryDeadline === 'string') prod.deliveryDeadline = req.body.deliveryDeadline;
    if (Array.isArray(req.body?.sharedAssetPermissions)) {
      prod.sharedAssetPermissions = req.body.sharedAssetPermissions;
    }
    prod.revision += 1;
    prod.updatedAt = new Date().toISOString();
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'PRODUCTION_UPDATED',
      entityType: 'Production',
      entityId: prod.id,
      detail: `Updated ${prod.code} (rev ${prod.revision}).`,
    });
    db.persist();
    res.json(prod);
  });

  // --- Scripts & Breakdowns ---
  router.post('/scripts', requireAuth('script:write'), (req: AuthenticatedRequest, res) => {
    const {productionId, versionLabel, notes, bodyText, scenes} = req.body as {
      productionId: string;
      versionLabel: string;
      notes?: string;
      bodyText: string;
      scenes: {
        sceneId: string;
        heading: string;
        location: string;
        timeOfDay: string;
        summary: string;
        characters: string[];
        props: string[];
        productionNotes: string;
      }[];
    };
    const state = db.getState();
    const newVersion = {
      id: `scr_${randomUUID().slice(0, 8)}`,
      productionId,
      versionLabel: versionLabel || `v1.${state.scripts.length + 1}`,
      status: 'In Review' as ApprovalStatus,
      authorId: req.sessionClaims!.memberId,
      createdAt: new Date().toISOString(),
      notes: notes || '',
      bodyText: bodyText || '',
      scenes: Array.isArray(scenes) ? scenes : [],
    };
    state.scripts.push(newVersion);

    // Automatically detect affected shots/assets against prior breakdown
    const affectedRecordIds = state.shots
      .filter((s) => s.productionId === productionId)
      .slice(-2)
      .map((s) => s.id);

    const proposal: BreakdownProposal = {
      id: `brk_${randomUUID().slice(0, 8)}`,
      productionId,
      scriptVersionId: newVersion.id,
      source: 'Manual',
      status: 'Pending Review',
      proposedAssets: (newVersion.scenes || []).flatMap((sc) =>
        sc.props.slice(0, 2).map((prop) => ({
          name: prop,
          category: 'Prop',
          rationale: `Referenced in ${sc.sceneId} (${newVersion.versionLabel})`,
        })),
      ),
      proposedSequences: [],
      proposedShots: (newVersion.scenes || []).slice(0, 1).map((sc) => ({
        code: `SH${(state.shots.length + 1) * 10}`,
        sequenceCode: 'SEQ030',
        summary: `New beat from ${newVersion.versionLabel} (${sc.sceneId})`,
        estimatedFrames: 96,
      })),
      affectedRecordIds,
      createdAt: new Date().toISOString(),
    };
    state.breakdownProposals.unshift(proposal);

    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'SCRIPT_VERSION_CREATED',
      entityType: 'ScriptVersion',
      entityId: newVersion.id,
      detail: `Created script ${newVersion.versionLabel} and flagged ${affectedRecordIds.length} downstream shot(s) for breakdown review.`,
    });
    db.persist();
    res.status(201).json({script: newVersion, proposal});
  });

  router.post('/breakdowns/:id/confirm', requireAuth('script:approve'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const proposal = state.breakdownProposals.find((b) => b.id === req.params['id']);
    if (!proposal) {
      res.status(404).json({error: 'Breakdown proposal not found.'});
      return;
    }
    if (proposal.status === 'Confirmed') {
      res.status(400).json({error: 'Breakdown proposal was already confirmed.'});
      return;
    }
    const decision = req.body?.decision === 'dismiss' ? 'Dismissed' : 'Confirmed';
    proposal.status = decision;
    proposal.confirmedBy = req.sessionClaims!.memberName;
    proposal.confirmedAt = new Date().toISOString();

    if (decision === 'Confirmed') {
      for (const propAsset of proposal.proposedAssets) {
        const exists = state.assets.some(
          (a) => a.productionId === proposal.productionId && a.name.toLowerCase() === propAsset.name.toLowerCase(),
        );
        if (!exists) {
          const code = `AST_${propAsset.name.toUpperCase().replace(/[^A-Z0-9]+/g, '_').slice(0, 14)}`;
          state.assets.push({
            id: `ast_${randomUUID().slice(0, 8)}`,
            productionId: proposal.productionId,
            code,
            name: propAsset.name,
            category: (propAsset.category as AssetCategory) || 'Prop',
            ownerId: req.sessionClaims!.memberId,
            assignedArtistIds: ['usr_owen'],
            workingFilePath: `/productions/CFX/assets/props/${code.toLowerCase()}_v001.blend`,
            workingFileRevision: 1,
            latestPublishedVersionId: null,
            previewUrl: '/assets/images/mechanical_garden_prop_1795352361859.jpg',
            approvalStatus: 'Draft',
            sourceAndRights: 'Derived from confirmed script breakdown',
            rightsCleared: true,
            tags: ['breakdown', 'script-linked'],
            collections: ['Script Breakdown Additions'],
            dimensionType: '3D',
            metadata3D: {
              units: 'meters',
              upAxis: 'Z-up',
              forwardAxis: '-Y',
              supportedAppVersion: 'Blender 4.2.3 LTS',
              polyCount: 12000,
            },
            versions: [],
            revision: 1,
          });
        }
      }
    }

    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: decision === 'Confirmed' ? 'BREAKDOWN_CONFIRMED' : 'BREAKDOWN_DISMISSED',
      entityType: 'BreakdownProposal',
      entityId: proposal.id,
      detail: `${decision} breakdown proposal for script ${proposal.scriptVersionId}.`,
    });
    db.persist();
    res.json(proposal);
  });

  // --- Storyboards & Animatics ---
  router.post('/storyboards/:boardId/panels', requireAuth('storyboard:write'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const board = state.storyboards.find((b) => b.id === req.params['boardId']);
    if (!board) {
      res.status(404).json({error: 'Storyboard not found.'});
      return;
    }
    const {panelCode, sceneId, shotId, imageUrl, contentHash, dialogue, actionNotes, cameraNotes, durationFrames} =
      req.body as Partial<StoryboardPanel>;
    const frames = Math.max(1, Math.round(Number(durationFrames || 72)));
    const panel: StoryboardPanel = {
      id: `pnl_${randomUUID().slice(0, 8)}`,
      boardId: board.id,
      orderIndex: board.panels.length,
      panelCode: panelCode || `PNL-${String(board.panels.length + 1).padStart(3, '0')}`,
      sceneId: sceneId || 'SC-01',
      shotId: shotId || state.shots[0]?.id || '',
      imageUrl: imageUrl || '/assets/images/storyboard_panel_01_1795352361907.jpg',
      contentHash: contentHash || createHash('sha256').update(`${Date.now()}`).digest('hex'),
      dialogue: dialogue || '',
      actionNotes: actionNotes || '',
      cameraNotes: cameraNotes || '35mm Medium',
      durationFrames: frames,
    };
    board.panels.push(panel);
    board.revision += 1;
    board.updatedAt = new Date().toISOString();
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'STORYBOARD_PANEL_ADDED',
      entityType: 'StoryboardBoard',
      entityId: board.id,
      detail: `Added ${panel.panelCode} (${frames} frames @ ${board.fps} fps).`,
    });
    db.persist();
    res.status(201).json(board);
  });

  router.patch('/storyboards/:boardId/reorder', requireAuth('storyboard:write'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const board = state.storyboards.find((b) => b.id === req.params['boardId']);
    if (!board) {
      res.status(404).json({error: 'Storyboard not found.'});
      return;
    }
    const orderedIds = Array.isArray(req.body?.orderedPanelIds) ? (req.body.orderedPanelIds as string[]) : null;
    if (!orderedIds || orderedIds.length !== board.panels.length) {
      res.status(400).json({error: 'orderedPanelIds must match all panels on the board.'});
      return;
    }
    const byId = new Map(board.panels.map((p) => [p.id, p]));
    const reordered = orderedIds.map((id, idx) => {
      const p = byId.get(id);
      if (!p) throw new Error(`Unknown panel ID ${id}`);
      return {...p, orderIndex: idx};
    });
    board.panels = reordered;
    board.revision += 1;
    board.updatedAt = new Date().toISOString();
    db.persist();
    res.json(board);
  });

  router.patch('/storyboards/:boardId/panels/:panelId', requireAuth('storyboard:write'), (req, res) => {
    const state = db.getState();
    const board = state.storyboards.find((b) => b.id === req.params['boardId']);
    if (!board) {
      res.status(404).json({error: 'Storyboard not found.'});
      return;
    }
    const panel = board.panels.find((p) => p.id === req.params['panelId']);
    if (!panel) {
      res.status(404).json({error: 'Panel not found.'});
      return;
    }
    if (typeof req.body?.durationFrames === 'number') {
      panel.durationFrames = Math.max(1, Math.round(req.body.durationFrames));
    }
    if (typeof req.body?.cameraNotes === 'string') panel.cameraNotes = req.body.cameraNotes;
    if (typeof req.body?.actionNotes === 'string') panel.actionNotes = req.body.actionNotes;
    if (typeof req.body?.dialogue === 'string') panel.dialogue = req.body.dialogue;
    board.revision += 1;
    board.updatedAt = new Date().toISOString();
    db.persist();
    res.json(board);
  });

  router.post('/storyboards/:boardId/convert-fps', requireAuth('storyboard:write'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const board = state.storyboards.find((b) => b.id === req.params['boardId']);
    if (!board) {
      res.status(404).json({error: 'Storyboard not found.'});
      return;
    }
    const targetFps = Number(req.body?.targetFps);
    if (![24, 25, 30].includes(targetFps)) {
      res.status(400).json({error: 'Supported frame rates are 24, 25, and 30 fps.'});
      return;
    }
    const oldFps = board.fps;
    if (oldFps === targetFps) {
      res.json(board);
      return;
    }
    const ratio = targetFps / oldFps;
    // Preserve approved board revision by creating an updated version label
    const nextRevNum = parseInt(board.versionLabel.replace(/[^0-9]/g, '') || '1', 10) + 1;
    board.versionLabel = `v${nextRevNum}`;
    board.fps = targetFps;
    board.panels = board.panels.map((p) => ({
      ...p,
      durationFrames: Math.max(1, Math.round(p.durationFrames * ratio)),
    }));
    board.revision += 1;
    board.updatedAt = new Date().toISOString();
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'STORYBOARD_FPS_CONVERTED',
      entityType: 'StoryboardBoard',
      entityId: board.id,
      detail: `Converted ${board.title} from ${oldFps} fps to ${targetFps} fps (${board.versionLabel}) with integer frame rounding.`,
    });
    db.persist();
    res.json(board);
  });

  router.post('/storyboards/:boardId/export-animatic', requireAuth('storyboard:write'), async (req: AuthenticatedRequest, res) => {
    try {
      const state = db.getState();
      const board = state.storyboards.find((b) => b.id === req.params['boardId']);
      if (!board) {
        res.status(404).json({error: 'Storyboard not found.'});
        return;
      }
      const outName = `animatic_${board.id}_${Date.now()}.mp4`;
      const result = await generateAnimaticMp4({
        panels: board.panels.map((p) => ({
          panelCode: p.panelCode,
          imageUrl: p.imageUrl,
          durationFrames: p.durationFrames,
          cameraNotes: p.cameraNotes,
        })),
        fps: board.fps,
        outputFileName: outName,
        objectStore: db.getObjectStore(),
        workspaceRoot,
      });

      const animatic = {
        id: `anm_${randomUUID().slice(0, 8)}`,
        productionId: board.productionId,
        boardId: board.id,
        boardVersionLabel: board.versionLabel,
        fps: board.fps,
        totalFrames: result.totalFrames,
        durationSeconds: result.durationSeconds,
        panelSnapshot: board.panels.map((p) => ({
          panelId: p.id,
          panelCode: p.panelCode,
          durationFrames: p.durationFrames,
          contentHash: p.contentHash,
        })),
        tempAudioVersion: board.tempAudioVersion,
        mediaUrl: result.url,
        contentHash: result.contentHash,
        createdBy: req.sessionClaims!.memberName,
        createdAt: new Date().toISOString(),
      };
      state.animatics.unshift(animatic);
      db.recordAudit({
        actorId: req.sessionClaims!.memberId,
        actorName: req.sessionClaims!.memberName,
        actorRole: req.sessionClaims!.role,
        action: 'ANIMATIC_EXPORTED',
        entityType: 'AnimaticExport',
        entityId: animatic.id,
        detail: `Exported real MP4 animatic (${result.totalFrames} frames @ ${board.fps} fps, SHA-256 ${result.contentHash.slice(0, 12)}).`,
      });
      db.persist();
      res.status(201).json(animatic);
    } catch (err) {
      res.status(500).json({error: err instanceof Error ? err.message : 'Animatic export failed.'});
    }
  });

  // --- Asset Library (Immutable Published Versions + Downstream Flagging) ---
  router.post('/assets', requireAuth('asset:work'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const body = req.body as Partial<Asset>;
    if (!body.code || !body.name || !body.productionId) {
      res.status(400).json({error: 'productionId, code, and name are required.'});
      return;
    }
    const asset: Asset = {
      id: `ast_${randomUUID().slice(0, 8)}`,
      productionId: body.productionId,
      code: body.code.trim().toUpperCase(),
      name: body.name.trim(),
      category: body.category || 'Prop',
      ownerId: req.sessionClaims!.memberId,
      assignedArtistIds: body.assignedArtistIds || [req.sessionClaims!.memberId],
      workingFilePath: body.workingFilePath || `/productions/CFX/assets/${body.code.toLowerCase()}_work_v001.blend`,
      workingFileRevision: 1,
      latestPublishedVersionId: null,
      previewUrl: body.previewUrl || '/assets/images/mechanical_garden_prop_1795352361859.jpg',
      approvalStatus: 'Draft',
      sourceAndRights: body.sourceAndRights || 'Original Studio Asset',
      rightsCleared: body.rightsCleared ?? true,
      tags: body.tags || ['new'],
      collections: body.collections || ['General'],
      dimensionType: body.dimensionType || '3D',
      metadata3D:
        (body.dimensionType || '3D') === '3D'
          ? body.metadata3D || {
              units: 'meters',
              upAxis: 'Z-up',
              forwardAxis: '-Y',
              supportedAppVersion: 'Blender 4.2.3 LTS',
              polyCount: 14200,
            }
          : undefined,
      metadata2D: body.dimensionType === '2D' ? body.metadata2D : undefined,
      versions: [],
      revision: 1,
    };
    state.assets.push(asset);
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'ASSET_CREATED',
      entityType: 'Asset',
      entityId: asset.id,
      detail: `Created asset ${asset.code} (${asset.name}).`,
    });
    db.persist();
    res.status(201).json(asset);
  });

  // Immutable publish: always creates v00(N+1), never overwrites existing published versions
  router.post('/assets/:id/publish', requireAuth('asset:publish'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const asset = state.assets.find((a) => a.id === req.params['id']);
    if (!asset) {
      res.status(404).json({error: 'Asset not found.'});
      return;
    }
    const {notes, toolName, toolVersion, payloadBase64, fileName, overwriteVersionNumber} = req.body as {
      notes?: string;
      toolName?: string;
      toolVersion?: string;
      payloadBase64?: string;
      fileName?: string;
      overwriteVersionNumber?: number;
    };

    if (typeof overwriteVersionNumber === 'number') {
      res.status(409).json({
        error: `Published version v${String(overwriteVersionNumber).padStart(3, '0')} is immutable and cannot be overwritten. Publish a replacement version instead.`,
      });
      return;
    }

    const nextNum = asset.versions.length + 1;
    const versionLabel = `v${String(nextNum).padStart(3, '0')}`;
    const resolvedFileName = fileName || `${asset.code}_${versionLabel}.blend`;
    const buf = payloadBase64
      ? Buffer.from(payloadBase64.replace(/^data:[^;]+;base64,/, ''), 'base64')
      : Buffer.from(
          `AUREOM_PUBLISHED_ASSET ${asset.code} ${versionLabel} | Tool=${toolName || 'Blender'} ${toolVersion || '4.2.3'} | Timestamp=${new Date().toISOString()}`,
          'utf8',
        );

    const stored = db.getObjectStore().storeImmutableBuffer(buf, resolvedFileName, 'application/octet-stream');
    const newVersion = {
      id: `av_${randomUUID().slice(0, 8)}`,
      assetId: asset.id,
      versionNumber: nextNum,
      versionLabel,
      immutable: true,
      fileName: stored.fileName,
      mimeType: stored.mimeType,
      byteSize: stored.byteSize,
      contentHash: stored.contentHash,
      objectKey: stored.objectKey,
      previewUrl: asset.previewUrl,
      toolName: toolName || 'Blender',
      toolVersion: toolVersion || '4.2.3',
      publishedBy: req.sessionClaims!.memberName,
      publishedAt: new Date().toISOString(),
      notes: notes || `Published ${versionLabel} from studio pipeline.`,
      dependencyVersionIds: [],
    };
    asset.versions.push(newVersion);
    asset.latestPublishedVersionId = newVersion.id;
    asset.workingFileRevision += 1;
    asset.revision += 1;
    asset.approvalStatus = 'Approved';

    // Flag downstream shot tasks linked to this asset without invalidating approved results
    let flaggedCount = 0;
    for (const shot of state.shots) {
      if (shot.linkedAssetIds.includes(asset.id)) {
        for (const task of shot.tasks) {
          if (task.department === 'Animation' || task.department === 'Lighting') {
            task.upstreamFlagged = true;
            task.upstreamFlagReason = `Upstream asset ${asset.code} published ${versionLabel}. Existing ${task.approvedOutputVersionId ? 'approved output preserved' : 'WIP'} pending supervisor decision.`;
            flaggedCount += 1;
          }
        }
      }
    }

    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'ASSET_VERSION_PUBLISHED',
      entityType: 'Asset',
      entityId: asset.id,
      detail: `Published immutable ${asset.code} ${versionLabel} (SHA-256 ${stored.contentHash.slice(0, 12)}); flagged ${flaggedCount} downstream task(s).`,
    });
    db.persist();
    broadcast({type: 'asset:published', payload: {assetId: asset.id, versionLabel, flaggedCount}});
    res.status(201).json({asset, version: newVersion, flaggedCount});
  });

  // Explicitly block any attempt to overwrite an immutable version
  router.put('/assets/:id/versions/:versionId', requireAuth('asset:publish'), (_req, res) => {
    res.status(409).json({
      error: 'Published asset versions are immutable and cannot be overwritten. Publish a new replacement version.',
    });
  });

  // --- Shots & Tasks ---
  router.post('/shots/:id/link-asset', requireAuth('shot:work'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const shot = state.shots.find((s) => s.id === req.params['id']);
    const assetId = typeof req.body?.assetId === 'string' ? req.body.assetId : '';
    const asset = state.assets.find((a) => a.id === assetId);
    if (!shot || !asset) {
      res.status(404).json({error: 'Shot or Asset not found.'});
      return;
    }
    if (!shot.linkedAssetIds.includes(asset.id)) {
      shot.linkedAssetIds.push(asset.id);
    }
    if (asset.latestPublishedVersionId) {
      for (const t of shot.tasks) {
        if (!t.linkedAssetVersionIds.includes(asset.latestPublishedVersionId)) {
          t.linkedAssetVersionIds.push(asset.latestPublishedVersionId);
        }
      }
    }
    shot.revision += 1;
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'SHOT_ASSET_LINKED',
      entityType: 'Shot',
      entityId: shot.id,
      detail: `Linked ${asset.code} to ${shot.code}.`,
    });
    db.persist();
    broadcast({type: 'shot:updated', payload: {shotId: shot.id}});
    res.json(shot);
  });

  router.patch('/shots/:shotId/tasks/:taskId', requireAuth('shot:work'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const shot = state.shots.find((s) => s.id === req.params['shotId']);
    const task = shot?.tasks.find((t) => t.id === req.params['taskId']);
    if (!shot || !task) {
      res.status(404).json({error: 'Shot task not found.'});
      return;
    }
    if (typeof req.body?.reviewStatus === 'string') {
      // Only Supervisors/Directors/Reviewers can set Approved directly
      if (req.body.reviewStatus === 'Approved' && !db.hasPermission(req.sessionClaims!.role, 'review:creative_approve') && !db.hasPermission(req.sessionClaims!.role, 'review:technical_validate')) {
        res.status(403).json({error: 'Only Directors, Supervisors, or Reviewers can approve task outputs.'});
        return;
      }
      task.reviewStatus = req.body.reviewStatus as ApprovalStatus;
      if (task.reviewStatus === 'Approved') {
        task.approvedOutputVersionId = `${shot.code}_${task.department}_${task.currentVersionLabel}`;
        task.approvedAt = new Date().toISOString();
        task.approvedBy = req.sessionClaims!.memberName;
      }
    }
    if (typeof req.body?.upstreamFlagged === 'boolean') {
      task.upstreamFlagged = req.body.upstreamFlagged;
      if (!req.body.upstreamFlagged) {
        task.upstreamFlagReason = undefined;
      }
    }
    if (typeof req.body?.blockerNote === 'string') {
      task.blockerNote = req.body.blockerNote || undefined;
    }
    if (typeof req.body?.actualHours === 'number') {
      task.actualHours = Math.max(0, req.body.actualHours);
    }
    if (typeof req.body?.assigneeId === 'string') {
      task.assigneeId = req.body.assigneeId;
    }
    shot.revision += 1;
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'TASK_UPDATED',
      entityType: 'ShotTask',
      entityId: task.id,
      detail: `Updated ${shot.code} ${task.department} (${task.reviewStatus}).`,
    });
    db.persist();
    broadcast({type: 'shot:updated', payload: {shotId: shot.id}});
    res.json(shot);
  });

  // --- Reviews, Frame Comments, Canvas Annotations & External Links ---
  router.post('/reviews/:shotId/submit-preview', requireAuth('shot:work'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const shot = state.shots.find((s) => s.id === req.params['shotId']);
    if (!shot) {
      res.status(404).json({error: 'Shot not found.'});
      return;
    }
    const {notes, mediaUrl, thumbnailUrl, taskId} = req.body as {
      notes?: string;
      mediaUrl?: string;
      thumbnailUrl?: string;
      taskId?: string;
    };

    let review = state.reviews.find((r) => r.shotId === shot.id);
    const chosenMedia = mediaUrl || shot.previewUrl;
    const contentHash = createHash('sha256').update(`${chosenMedia}:${Date.now()}`).digest('hex');

    if (!review) {
      review = {
        id: `rev_${randomUUID().slice(0, 8)}`,
        productionId: shot.productionId,
        shotId: shot.id,
        taskId: taskId || shot.tasks[0]?.id || '',
        title: `${shot.code} · ${shot.title} (Preview v001)`,
        assignedReviewerIds: ['usr_arthur', 'usr_maya'],
        currentVersionLabel: 'v001',
        versions: [
          {
            versionLabel: 'v001',
            mediaUrl: chosenMedia,
            thumbnailUrl: thumbnailUrl || chosenMedia,
            contentHash,
            fps: shot.fps,
            frameCount: shot.frameCount,
            submittedBy: req.sessionClaims!.memberName,
            submittedAt: new Date().toISOString(),
            notes: notes || 'Initial preview submitted for dailies review.',
          },
        ],
        creativeApproval: 'In Review',
        technicalValidation: 'Pending',
        deliveryApproval: 'Pending',
        comments: [],
        annotations: [],
        updatedAt: new Date().toISOString(),
      };
      state.reviews.unshift(review);
    } else {
      const nextNum = review.versions.length + 1;
      const versionLabel = `v${String(nextNum).padStart(3, '0')}`;
      const prevVersion = review.currentVersionLabel;
      review.versions.push({
        versionLabel,
        mediaUrl: chosenMedia,
        thumbnailUrl: thumbnailUrl || chosenMedia,
        contentHash,
        fps: shot.fps,
        frameCount: shot.frameCount,
        submittedBy: req.sessionClaims!.memberName,
        submittedAt: new Date().toISOString(),
        notes: notes || `Revision ${versionLabel} addressing review notes.`,
      });
      review.currentVersionLabel = versionLabel;
      review.title = `${shot.code} · ${shot.title} (${versionLabel})`;
      review.creativeApproval = 'In Review';
      review.updatedAt = new Date().toISOString();

      // Carry forward unresolved notes attribution visibly without losing original version
      for (const c of review.comments) {
        if (!c.resolved && !c.carriedOverFromVersion) {
          c.carriedOverFromVersion = prevVersion;
        }
      }
    }

    shot.status = 'In Review';
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'REVIEW_VERSION_SUBMITTED',
      entityType: 'ReviewItem',
      entityId: review.id,
      detail: `Submitted ${shot.code} ${review.currentVersionLabel} for review.`,
    });
    db.persist();
    broadcast({type: 'review:updated', payload: {reviewId: review.id}});
    res.status(201).json(review);
  });

  router.post('/reviews/:id/comments', requireAuth('review:comment'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const review = state.reviews.find((r) => r.id === req.params['id']);
    if (!review) {
      res.status(404).json({error: 'Review item not found.'});
      return;
    }
    const frameNumber = Math.max(1, Math.round(Number(req.body?.frameNumber || 1)));
    const body = typeof req.body?.body === 'string' ? req.body.body.trim() : '';
    if (!body) {
      res.status(400).json({error: 'Comment body cannot be empty.'});
      return;
    }
    const comment: ReviewComment = {
      id: `cmt_${randomUUID().slice(0, 8)}`,
      reviewItemId: review.id,
      versionLabel: req.body?.versionLabel || review.currentVersionLabel,
      frameNumber,
      authorId: req.sessionClaims!.memberId,
      authorName: req.sessionClaims!.memberName,
      authorRole: req.sessionClaims!.role,
      body,
      resolved: false,
      createdAt: new Date().toISOString(),
    };
    review.comments.push(comment);
    review.updatedAt = new Date().toISOString();
    db.persist();
    broadcast({type: 'review:updated', payload: {reviewId: review.id}});
    res.status(201).json(comment);
  });

  router.patch('/reviews/:id/comments/:commentId/resolve', requireAuth('review:comment'), (req, res) => {
    const state = db.getState();
    const review = state.reviews.find((r) => r.id === req.params['id']);
    const comment = review?.comments.find((c) => c.id === req.params['commentId']);
    if (!review || !comment) {
      res.status(404).json({error: 'Comment not found.'});
      return;
    }
    comment.resolved = Boolean(req.body?.resolved ?? !comment.resolved);
    review.updatedAt = new Date().toISOString();
    db.persist();
    broadcast({type: 'review:updated', payload: {reviewId: review.id}});
    res.json(comment);
  });

  router.post('/reviews/:id/annotations', requireAuth('review:comment'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const review = state.reviews.find((r) => r.id === req.params['id']);
    if (!review) {
      res.status(404).json({error: 'Review item not found.'});
      return;
    }
    const ann = {
      id: `ann_${randomUUID().slice(0, 8)}`,
      reviewItemId: review.id,
      versionLabel: req.body?.versionLabel || review.currentVersionLabel,
      frameNumber: Math.max(1, Math.round(Number(req.body?.frameNumber || 1))),
      authorId: req.sessionClaims!.memberId,
      authorName: req.sessionClaims!.memberName,
      colour: typeof req.body?.colour === 'string' ? req.body.colour : '#B8964D',
      strokesJson: typeof req.body?.strokesJson === 'string' ? req.body.strokesJson : '[]',
      createdAt: new Date().toISOString(),
    };
    review.annotations.push(ann);
    review.updatedAt = new Date().toISOString();
    db.persist();
    broadcast({type: 'review:updated', payload: {reviewId: review.id}});
    res.status(201).json(ann);
  });

  router.post('/reviews/:id/decision', requireAuth('review:comment'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const review = state.reviews.find((r) => r.id === req.params['id']);
    if (!review) {
      res.status(404).json({error: 'Review item not found.'});
      return;
    }
    const {gate, status} = req.body as {
      gate: 'creative' | 'technical' | 'delivery';
      status: string;
    };
    const role = req.sessionClaims!.role;

    if (gate === 'creative') {
      if (!db.hasPermission(role, 'review:creative_approve')) {
        res.status(403).json({error: `Role '${role}' cannot issue Creative Approval decisions.`});
        return;
      }
      review.creativeApproval = status as ApprovalStatus;
      const shot = state.shots.find((s) => s.id === review.shotId);
      if (shot && (status === 'Approved' || status === 'Changes Requested')) {
        shot.status = status as ApprovalStatus;
      }
    } else if (gate === 'technical') {
      if (!db.hasPermission(role, 'review:technical_validate')) {
        res.status(403).json({error: `Role '${role}' cannot issue Technical Validation decisions.`});
        return;
      }
      review.technicalValidation = status as 'Pending' | 'Passed' | 'Failed';
    } else if (gate === 'delivery') {
      if (!db.hasPermission(role, 'review:delivery_approve')) {
        res.status(403).json({error: `Role '${role}' cannot issue Delivery Approval decisions.`});
        return;
      }
      review.deliveryApproval = status as 'Pending' | 'Approved' | 'Rejected';
    } else {
      res.status(400).json({error: 'Invalid approval gate.'});
      return;
    }

    review.updatedAt = new Date().toISOString();
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: role,
      action: `REVIEW_${gate.toUpperCase()}_DECISION`,
      entityType: 'ReviewItem',
      entityId: review.id,
      detail: `Set ${gate} gate to '${status}' on ${review.title}.`,
    });
    db.persist();
    broadcast({type: 'review:updated', payload: {reviewId: review.id}});
    res.json(review);
  });

  router.post('/reviews/:id/external-links', requireAuth('review:delivery_approve'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const review = state.reviews.find((r) => r.id === req.params['id']);
    if (!review) {
      res.status(404).json({error: 'Review item not found.'});
      return;
    }
    const days = Math.min(30, Math.max(1, Number(req.body?.expiresInDays || 7)));
    const expiresAt = new Date(Date.now() + days * 86400_000).toISOString();
    const link = {
      id: `ext_${randomUUID().slice(0, 8)}`,
      token: `cfx-${randomUUID().slice(0, 12)}`,
      reviewItemId: review.id,
      label: typeof req.body?.label === 'string' && req.body.label.trim() ? req.body.label.trim() : 'External Client Screening',
      allowDownload: Boolean(req.body?.allowDownload),
      expiresAt,
      createdBy: req.sessionClaims!.memberName,
      createdAt: new Date().toISOString(),
      revoked: false,
    };
    state.externalReviewLinks.unshift(link);
    db.persist();
    res.status(201).json(link);
  });

  router.get('/external-reviews/:token', (req, res) => {
    const state = db.getState();
    const link = state.externalReviewLinks.find((l) => l.token === req.params['token']);
    if (!link || link.revoked || Date.now() > Date.parse(link.expiresAt)) {
      res.status(404).json({error: 'External review link is invalid, revoked, or expired.'});
      return;
    }
    const review = state.reviews.find((r) => r.id === link.reviewItemId);
    if (!review) {
      res.status(404).json({error: 'Linked review item not found.'});
      return;
    }
    res.json({
      link: {
        label: link.label,
        allowDownload: link.allowDownload,
        expiresAt: link.expiresAt,
      },
      review: {
        id: review.id,
        title: review.title,
        currentVersionLabel: review.currentVersionLabel,
        versions: review.versions,
        comments: review.comments,
        annotations: review.annotations,
      },
    });
  });

  // --- Render Queue & Local/Simulated Workers ---
  router.post('/render-jobs', requireAuth('render:submit'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const {shotId, frameStart, frameEnd, executionMode, engine, samples, idempotencyKey} = req.body as {
      shotId: string;
      frameStart?: number;
      frameEnd?: number;
      executionMode?: 'Local Worker' | 'Simulated Farm';
      engine?: string;
      samples?: number;
      idempotencyKey?: string;
    };
    const shot = state.shots.find((s) => s.id === shotId);
    if (!shot) {
      res.status(404).json({error: 'Shot not found.'});
      return;
    }
    const key = idempotencyKey || `idem_${shot.id}_${Date.now()}`;
    const existing = state.renderJobs.find((j) => j.idempotencyKey === key);
    if (existing) {
      res.json(existing);
      return;
    }

    const start = Math.max(1, Math.round(Number(frameStart ?? 1)));
    const end = Math.max(start, Math.round(Number(frameEnd ?? Math.min(24, shot.frameCount))));

    const manifest = shot.linkedAssetIds
      .map((aid) => state.assets.find((a) => a.id === aid))
      .filter((a): a is Asset => Boolean(a))
      .map((a) => {
        const ver = a.versions.find((v) => v.id === a.latestPublishedVersionId);
        return {
          assetCode: a.code,
          versionLabel: ver?.versionLabel || 'working',
          contentHash: ver?.contentHash || 'working-file',
        };
      });

    const job: RenderJob = {
      id: `rnd_${randomUUID().slice(0, 8)}`,
      productionId: shot.productionId,
      shotId: shot.id,
      sceneVersionLabel: shot.tasks[0]?.currentVersionLabel || 'v001',
      executionMode: executionMode === 'Simulated Farm' ? 'Simulated Farm' : 'Local Worker',
      frameStart: start,
      frameEnd: end,
      currentFrame: start - 1,
      renderSettings: {
        engine: engine || 'CYCLES_PREVIEW / FFmpeg',
        samples: Number(samples || 64),
        resolution: '1280x720',
        colourConfig: 'AgX / Rec.709',
      },
      requiredSoftwareVersion: 'Blender 4.2.3',
      dependencyManifest: manifest,
      state: 'Queued',
      workerId: null,
      leaseExpiresAt: null,
      attemptCount: 0,
      maxRetries: 3,
      idempotencyKey: key,
      logs: [`[${new Date().toISOString().slice(11, 19)}] Queued ${shot.code} frames ${start}..${end} (${executionMode || 'Local Worker'}).`],
      createdBy: req.sessionClaims!.memberName,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    state.renderJobs.unshift(job);
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'RENDER_JOB_QUEUED',
      entityType: 'RenderJob',
      entityId: job.id,
      detail: `Queued ${shot.code} (${start}–${end}) via ${job.executionMode}.`,
    });
    db.persist();
    broadcast({type: 'render:progress', payload: {job}});
    res.status(201).json(job);
  });

  router.post('/render-jobs/:id/run-local', requireAuth('render:submit'), async (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const job = state.renderJobs.find((j) => j.id === req.params['id']);
    if (!job) {
      res.status(404).json({error: 'Render job not found.'});
      return;
    }
    if (job.state === 'Cancelled') {
      res.status(409).json({error: 'Cancelled job cannot be run.'});
      return;
    }
    const shot = state.shots.find((s) => s.id === job.shotId);
    if (!shot) {
      res.status(404).json({error: 'Shot not found.'});
      return;
    }

    const worker = state.workers.find((w) =>
      job.executionMode === 'Local Worker' ? w.executionMode === 'Local Worker' : w.executionMode === 'Simulated Farm',
    ) || state.workers[0];

    job.state = 'Assigned';
    job.workerId = worker.id;
    job.attemptCount += 1;
    job.leaseExpiresAt = new Date(Date.now() + 120_000).toISOString();
    job.logs.push(`[${new Date().toISOString().slice(11, 19)}] Lease claimed by ${worker.name} (attempt ${job.attemptCount}/${job.maxRetries}).`);
    db.persist();
    broadcast({type: 'render:progress', payload: {job}});

    try {
      job.state = 'Running';
      job.currentFrame = Math.floor((job.frameStart + job.frameEnd) / 2);
      job.logs.push(`[${new Date().toISOString().slice(11, 19)}] Executing isolated ${job.executionMode} render pipeline (network=disabled)...`);
      broadcast({type: 'render:progress', payload: {job}});

      const outName = `render_${shot.code}_${job.id}.mp4`;
      const result = await generateShotRenderClip({
        shotCode: shot.code,
        frameStart: job.frameStart,
        frameEnd: job.frameEnd,
        fps: shot.fps,
        backdropUrl: shot.previewUrl,
        outputFileName: outName,
        objectStore: db.getObjectStore(),
        workspaceRoot,
      });

      job.state = 'Validating';
      job.currentFrame = job.frameEnd;
      job.logs.push(`[${new Date().toISOString().slice(11, 19)}] Probing output with ffprobe...`);
      broadcast({type: 'render:progress', payload: {job}});

      job.outputMediaUrl = result.url;
      job.outputHash = result.contentHash;
      job.validationReport = {
        passed: result.probe.passed,
        codec: result.probe.codec,
        frameCountDetected: result.probe.frameCountDetected,
        resolutionDetected: `${result.probe.width}x${result.probe.height}`,
        checkedAt: new Date().toISOString(),
      };
      job.state = result.probe.passed ? 'Completed' : 'Failed';
      job.leaseExpiresAt = null;
      job.updatedAt = new Date().toISOString();
      worker.lastHeartbeatAt = new Date().toISOString();
      job.logs.push(
        `[${new Date().toISOString().slice(11, 19)}] Validation ${result.probe.passed ? 'PASSED' : 'FAILED'}: ${result.probe.frameCountDetected} frames, ${result.probe.width}x${result.probe.height}, SHA-256 ${result.contentHash.slice(0, 12)}.`,
      );
      db.recordAudit({
        actorId: req.sessionClaims!.memberId,
        actorName: req.sessionClaims!.memberName,
        actorRole: req.sessionClaims!.role,
        action: 'RENDER_JOB_COMPLETED',
        entityType: 'RenderJob',
        entityId: job.id,
        detail: `Render ${job.id} (${shot.code}) validated & completed (${result.probe.frameCountDetected} frames).`,
      });
      db.persist();
      broadcast({type: 'render:progress', payload: {job}});
      res.json(job);
    } catch (err) {
      job.state = 'Failed';
      job.leaseExpiresAt = null;
      job.logs.push(`[ERROR] ${err instanceof Error ? err.message : 'Render execution failed.'}`);
      db.persist();
      broadcast({type: 'render:progress', payload: {job}});
      res.status(500).json({error: err instanceof Error ? err.message : 'Render failed.'});
    }
  });

  router.post('/render-jobs/:id/cancel', requireAuth('render:submit'), (req, res) => {
    const job = db.getState().renderJobs.find((j) => j.id === req.params['id']);
    if (!job) {
      res.status(404).json({error: 'Render job not found.'});
      return;
    }
    if (job.state === 'Completed') {
      res.status(409).json({error: 'Completed render job cannot be cancelled.'});
      return;
    }
    job.state = 'Cancelled';
    job.leaseExpiresAt = null;
    job.updatedAt = new Date().toISOString();
    job.logs.push(`[${new Date().toISOString().slice(11, 19)}] Cancelled by operator.`);
    db.persist();
    broadcast({type: 'render:progress', payload: {job}});
    res.json(job);
  });

  router.post('/render-jobs/:id/retry', requireAuth('render:submit'), (req, res) => {
    const job = db.getState().renderJobs.find((j) => j.id === req.params['id']);
    if (!job) {
      res.status(404).json({error: 'Render job not found.'});
      return;
    }
    if (job.attemptCount >= job.maxRetries) {
      res.status(409).json({error: `Bounded retry limit (${job.maxRetries}) reached.`});
      return;
    }
    job.state = 'Queued';
    job.workerId = null;
    job.leaseExpiresAt = null;
    job.updatedAt = new Date().toISOString();
    job.logs.push(`[${new Date().toISOString().slice(11, 19)}] Re-queued for retry.`);
    db.persist();
    broadcast({type: 'render:progress', payload: {job}});
    res.json(job);
  });

  // --- Team, Timesheets, Budget & Rights ---
  router.post('/timesheets', requireAuth('shot:work'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const entry: TimesheetEntry = {
      id: `ts_${randomUUID().slice(0, 8)}`,
      productionId: req.body?.productionId || state.productions[0].id,
      memberId: req.body?.memberId || req.sessionClaims!.memberId,
      shotId: req.body?.shotId || undefined,
      date: req.body?.date || new Date().toISOString().slice(0, 10),
      hours: Math.max(0.25, Number(req.body?.hours || 1)),
      department: req.body?.department || 'Animation',
      notes: typeof req.body?.notes === 'string' ? req.body.notes : '',
    };
    state.timesheets.unshift(entry);
    db.persist();
    res.status(201).json(entry);
  });

  router.post('/budget-lines', requireAuth('budget:write'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const line: BudgetLine = {
      id: `bgt_${randomUUID().slice(0, 8)}`,
      productionId: req.body?.productionId || state.productions[0].id,
      department: req.body?.department || 'Production',
      description: req.body?.description || 'Line item',
      currency: req.body?.currency || 'GBP',
      budgetAmount: Number(req.body?.budgetAmount || 0).toFixed(2),
      committedAmount: Number(req.body?.committedAmount || 0).toFixed(2),
      actualAmount: Number(req.body?.actualAmount || 0).toFixed(2),
      forecastRemainingAmount: Number(req.body?.forecastRemainingAmount || 0).toFixed(2),
    };
    state.budgetLines.push(line);
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'BUDGET_LINE_ADDED',
      entityType: 'BudgetLine',
      entityId: line.id,
      detail: `Added ${line.currency} ${line.budgetAmount} budget line for ${line.department}.`,
    });
    db.persist();
    res.status(201).json(line);
  });

  router.post('/purchases', requireAuth('budget:write'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const po: PurchaseRecord = {
      id: `po_${randomUUID().slice(0, 8)}`,
      productionId: req.body?.productionId || state.productions[0].id,
      vendor: req.body?.vendor || 'UK Studio Supplier',
      description: req.body?.description || 'Production purchase',
      department: req.body?.department || 'Production',
      currency: req.body?.currency || 'GBP',
      amount: Number(req.body?.amount || 0).toFixed(2),
      status: req.body?.status === 'Paid' ? 'Paid' : 'Committed',
      recordedAt: new Date().toISOString().slice(0, 10),
    };
    state.purchases.unshift(po);
    db.persist();
    res.status(201).json(po);
  });

  router.post('/rights', requireAuth('team:write'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const record: RightsRecord = {
      id: `rgt_${randomUUID().slice(0, 8)}`,
      productionId: req.body?.productionId || state.productions[0].id,
      category: req.body?.category || 'Contributor Agreement',
      subjectName: req.body?.subjectName || 'Untitled Contributor',
      referenceCode: req.body?.referenceCode || `REF-${Date.now().toString().slice(-4)}`,
      permittedUses: req.body?.permittedUses || 'Festival & Broadcast',
      status: req.body?.status || 'Verified',
      notes: req.body?.notes || '',
    };
    state.rights.unshift(record);
    db.persist();
    res.status(201).json(record);
  });

  router.patch('/rights/:id', requireAuth('team:write'), (req, res) => {
    const record = db.getState().rights.find((r) => r.id === req.params['id']);
    if (!record) {
      res.status(404).json({error: 'Rights record not found.'});
      return;
    }
    if (typeof req.body?.status === 'string') {
      record.status = req.body.status as RightsRecord['status'];
    }
    if (typeof req.body?.notes === 'string') {
      record.notes = req.body.notes;
    }
    db.persist();
    res.json(record);
  });

  // --- Deliveries ---
  router.post('/deliveries/generate', requireAuth('delivery:generate'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const productionId = req.body?.productionId || state.productions[0].id;
    const prod = state.productions.find((p) => p.id === productionId);
    const spec = state.deliverySpecs.find((sp) => sp.id === (req.body?.presetId || prod?.deliverySpecId)) || state.deliverySpecs[0];
    if (!prod || !spec) {
      res.status(404).json({error: 'Production or delivery spec not found.'});
      return;
    }

    const approvedShots = state.shots.filter((s) => s.productionId === prod.id && s.status === 'Approved');
    const latestRender = state.renderJobs.find((j) => j.productionId === prod.id && j.state === 'Completed');
    const latestAnimatic = state.animatics.find((a) => a.productionId === prod.id);
    const verifiedRights = state.rights.filter((r) => r.productionId === prod.id && r.status === 'Verified').length;
    const missingRights = state.rights.filter((r) => r.productionId === prod.id && r.status !== 'Verified').length;

    const manifest = {
      assetVersions: state.assets
        .filter((a) => a.productionId === prod.id && a.versions.length > 0)
        .map((a) => {
          const v = a.versions[a.versions.length - 1];
          return {code: a.code, versionLabel: v.versionLabel, contentHash: v.contentHash};
        }),
      shotVersions: approvedShots.map((s) => ({
        code: s.code,
        approvedVersion: s.tasks.find((t) => t.approvedOutputVersionId)?.approvedOutputVersionId || 'v001',
        contentHash: createHash('sha256').update(`${s.id}:${s.revision}`).digest('hex'),
      })),
      animaticId: latestAnimatic?.id,
    };

    const nextNum = state.deliveries.filter((d) => d.productionId === prod.id).length + 1;
    const pkg: DeliveryPackage = {
      id: `del_${randomUUID().slice(0, 8)}`,
      productionId: prod.id,
      presetId: spec.id,
      packageName: req.body?.packageName || `${prod.code}_Master_Package_v${nextNum}`,
      versionLabel: `v${nextNum}`,
      lifecycleState: 'Generated',
      mediaUrl: latestRender?.outputMediaUrl || latestAnimatic?.mediaUrl || '/assets/images/yorkshire_station_env_1795352360997.jpg',
      mediaChecksum:
        latestRender?.outputHash ||
        createHash('sha256').update(JSON.stringify(manifest)).digest('hex'),
      creditsText:
        req.body?.creditsText ||
        `AUREOM ANIMATION\n${prod.title.toUpperCase()}\nDirected by Arthur Pendelton\nProduced by Clara Finch`,
      subtitlesSrt:
        req.body?.subtitlesSrt ||
        '1\n00:00:02,000 --> 00:00:06,000\n[Steam hisses across Yew Dale Station]\n',
      manifest,
      technicalReport: {
        passed: approvedShots.length > 0,
        fps: spec.fps,
        audioSampleRateHz: spec.audioSampleRateHz,
        colourConfig: spec.colourSpace,
        summary: `${approvedShots.length}/${state.shots.filter((s) => s.productionId === prod.id).length} shots approved · ${spec.fps} fps · ${spec.audioSampleRateHz} Hz · ${spec.colourSpace}.`,
      },
      rightsAndApprovalRefs: {
        creativeDirectorApprovedBy: 'Arthur Pendelton',
        technicalValidatedBy: 'Eleanor Vance',
        rightsClearanceCount: verifiedRights,
        missingRightsCount: missingRights,
      },
      createdBy: req.sessionClaims!.memberName,
      createdAt: new Date().toISOString(),
    };
    state.deliveries.unshift(pkg);
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'DELIVERY_PACKAGE_GENERATED',
      entityType: 'DeliveryPackage',
      entityId: pkg.id,
      detail: `Generated ${pkg.packageName} (${pkg.lifecycleState}).`,
    });
    db.persist();
    broadcast({type: 'delivery:updated', payload: {deliveryId: pkg.id}});
    res.status(201).json(pkg);
  });

  router.post('/deliveries/:id/transition', requireAuth('delivery:accept'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    const pkg = state.deliveries.find((d) => d.id === req.params['id']);
    if (!pkg) {
      res.status(404).json({error: 'Delivery package not found.'});
      return;
    }
    const target = req.body?.lifecycleState as DeliveryPackageState;
    if (target === 'Accepted by Distributor' && pkg.lifecycleState !== 'Passed Review') {
      res.status(409).json({
        error: 'A generated package must pass studio QC review before it can be marked Accepted by Distributor.',
      });
      return;
    }
    if (target === 'Accepted by Distributor' && pkg.rightsAndApprovalRefs.missingRightsCount > 0) {
      res.status(409).json({
        error: `Cannot mark Accepted by Distributor while ${pkg.rightsAndApprovalRefs.missingRightsCount} rights document(s) remain Missing Documentation.`,
      });
      return;
    }
    pkg.lifecycleState = target;
    if (target === 'Passed Review') {
      pkg.reviewedBy = req.sessionClaims!.memberName;
      pkg.reviewedAt = new Date().toISOString();
    } else if (target === 'Accepted by Distributor') {
      pkg.acceptedByDistributorAt = new Date().toISOString();
    }
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'DELIVERY_STATE_CHANGED',
      entityType: 'DeliveryPackage',
      entityId: pkg.id,
      detail: `Transitioned ${pkg.packageName} to ${pkg.lifecycleState}.`,
    });
    db.persist();
    broadcast({type: 'delivery:updated', payload: {deliveryId: pkg.id}});
    res.json(pkg);
  });

  // --- Optional AI Assistance (strictly gated & provenance-tracked) ---
  router.post('/ai/assist', requireAuth('ai:invoke'), async (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    if (!state.studio.aiEnabled) {
      res.status(403).json({
        error: 'Studio AI assistance is currently disabled in Administration. Studio workflows remain fully operational without AI.',
      });
      return;
    }
    if (!req.body?.explicitConsentConfirmed) {
      res.status(400).json({
        error: 'Explicit user consent confirmation is required before sending studio records to external Gemini services.',
      });
      return;
    }
    const feature = req.body?.feature as
      | 'Script Breakdown'
      | 'Asset Tagging'
      | 'Record Search'
      | 'Review Summary'
      | 'Schedule Conflicts'
      | 'Production Report';
    const promptInput = typeof req.body?.promptInput === 'string' ? req.body.promptInput : '';

    try {
      if (feature === 'Script Breakdown') {
        const script = state.scripts[state.scripts.length - 1];
        const prod = state.productions[0];
        const suggestion = await suggestScriptBreakdownWithAi({
          scriptText: promptInput || script.bodyText,
          productionTitle: prod.title,
        });
        const proposal: BreakdownProposal = {
          id: `brk_${randomUUID().slice(0, 8)}`,
          productionId: prod.id,
          scriptVersionId: script.id,
          source: 'AI Suggestion',
          status: 'Pending Review',
          proposedAssets: suggestion.proposedAssets,
          proposedSequences: [],
          proposedShots: suggestion.proposedShots,
          affectedRecordIds: [],
          createdAt: new Date().toISOString(),
        };
        state.breakdownProposals.unshift(proposal);
        state.aiProvenance.unshift({
          id: `aip_${randomUUID().slice(0, 8)}`,
          timestamp: new Date().toISOString(),
          feature: 'Script Breakdown',
          model: 'gemini-4-hydrogen',
          actorId: req.sessionClaims!.memberId,
          promptSummary: `Script breakdown suggestion (${script.versionLabel})`,
          outputSummary: `Proposed ${proposal.proposedAssets.length} assets, ${proposal.proposedShots.length} shots (pending confirmation).`,
          confirmedByHuman: false,
        });
        db.persist();
        res.json({proposal});
        return;
      }

      const text = await runStudioAiAssistant({feature, promptInput, state});
      state.aiProvenance.unshift({
        id: `aip_${randomUUID().slice(0, 8)}`,
        timestamp: new Date().toISOString(),
        feature,
        model: 'gemini-4-hydrogen',
        actorId: req.sessionClaims!.memberId,
        promptSummary: promptInput.slice(0, 100),
        outputSummary: text.slice(0, 160),
        confirmedByHuman: true,
      });
      db.persist();
      res.json({text});
    } catch (err) {
      res.status(502).json({
        error: err instanceof Error ? err.message : 'Gemini AI call failed.',
      });
    }
  });

  // --- Administration: Studio Settings, Backup & Restore ---
  router.patch('/admin/studio', requireAuth('admin:manage'), (req: AuthenticatedRequest, res) => {
    const state = db.getState();
    if (typeof req.body?.aiEnabled === 'boolean') {
      state.studio.aiEnabled = req.body.aiEnabled;
    }
    if (typeof req.body?.reducedMotionDefault === 'boolean') {
      state.studio.reducedMotionDefault = req.body.reducedMotionDefault;
    }
    state.studio.revision += 1;
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'STUDIO_SETTINGS_UPDATED',
      entityType: 'Studio',
      entityId: state.studio.id,
      detail: `aiEnabled=${state.studio.aiEnabled}, reducedMotionDefault=${state.studio.reducedMotionDefault}.`,
    });
    db.persist();
    res.json(state.studio);
  });

  router.get('/admin/backup', requireAuth('admin:manage'), (_req, res) => {
    res.json(db.exportBackupSnapshot());
  });

  router.post('/admin/restore', requireAuth('admin:manage'), (req: AuthenticatedRequest, res) => {
    const result = db.restoreBackupSnapshot(req.body);
    if (!result.ok) {
      res.status(400).json({error: result.reason});
      return;
    }
    db.recordAudit({
      actorId: req.sessionClaims!.memberId,
      actorName: req.sessionClaims!.memberName,
      actorRole: req.sessionClaims!.role,
      action: 'BACKUP_RESTORED',
      entityType: 'Studio',
      entityId: db.getState().studio.id,
      detail: 'Verified SHA-256 backup snapshot and restored studio records.',
    });
    db.persist();
    res.json({ok: true});
  });

  // --- Blender Python Plugin & Worker Pipeline Endpoints (/api/pipeline/*) ---
  router.get('/pipeline/manifest/:productionCode', (req, res) => {
    const state = db.getState();
    const prod = state.productions.find(
      (p) => p.code.toLowerCase() === req.params['productionCode'].toLowerCase(),
    );
    if (!prod) {
      res.status(404).json({error: 'Production not found.'});
      return;
    }
    res.json({
      production: {id: prod.id, code: prod.code, title: prod.title, fps: prod.fps},
      assets: state.assets
        .filter((a) => a.productionId === prod.id)
        .map((a) => ({
          id: a.id,
          code: a.code,
          name: a.name,
          workingFilePath: a.workingFilePath,
          latestPublishedVersion: a.versions[a.versions.length - 1] || null,
        })),
      shots: state.shots
        .filter((s) => s.productionId === prod.id)
        .map((s) => ({
          id: s.id,
          code: s.code,
          startFrame: s.startFrame,
          endFrame: s.endFrame,
          fps: s.fps,
          linkedAssetIds: s.linkedAssetIds,
        })),
    });
  });

  router.post('/pipeline/worker/heartbeat', requireAuth('render:submit'), (req, res) => {
    const workerId = typeof req.body?.workerId === 'string' ? req.body.workerId : '';
    const worker = db.getState().workers.find((w) => w.id === workerId);
    if (!worker) {
      res.status(404).json({error: 'Worker not registered.'});
      return;
    }
    worker.lastHeartbeatAt = new Date().toISOString();
    worker.status = req.body?.status === 'Busy' ? 'Busy' : 'Online';
    db.persist();
    res.json(worker);
  });

  router.post('/pipeline/worker/claim', requireAuth('render:submit'), (req, res) => {
    const state = db.getState();
    const workerId = typeof req.body?.workerId === 'string' ? req.body.workerId : 'wrk_local_01';
    const nowMs = Date.now();
    // Recover expired leases automatically
    for (const j of state.renderJobs) {
      if ((j.state === 'Assigned' || j.state === 'Running') && j.leaseExpiresAt && Date.parse(j.leaseExpiresAt) < nowMs) {
        if (j.attemptCount < j.maxRetries) {
          j.state = 'Queued';
          j.workerId = null;
          j.leaseExpiresAt = null;
          j.logs.push('[RECOVERY] Lease expired; job recovered back to Queued.');
        } else {
          j.state = 'Failed';
          j.leaseExpiresAt = null;
          j.logs.push('[RECOVERY] Lease expired at max retries; marked Failed.');
        }
      }
    }

    const candidate = state.renderJobs.find((j) => j.state === 'Queued');
    if (!candidate) {
      res.json({job: null});
      return;
    }
    candidate.state = 'Assigned';
    candidate.workerId = workerId;
    candidate.attemptCount += 1;
    candidate.leaseExpiresAt = new Date(nowMs + 120_000).toISOString();
    candidate.updatedAt = new Date().toISOString();
    db.persist();
    broadcast({type: 'render:progress', payload: {job: candidate}});
    res.json({job: candidate});
  });

  // Fallback for static workspace path resolution test
  void resolve;

  return router;
}
