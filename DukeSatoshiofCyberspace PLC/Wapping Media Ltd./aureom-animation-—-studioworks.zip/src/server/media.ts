import {execFile} from 'node:child_process';
import {existsSync, mkdirSync, readFileSync, rmSync, writeFileSync} from 'node:fs';
import {join, resolve} from 'node:path';
import {promisify} from 'node:util';
import type {LocalObjectStore} from './storage';

const execFileAsync = promisify(execFile);

export interface MediaProbeResult {
  passed: boolean;
  codec: string;
  width: number;
  height: number;
  frameCountDetected: number;
  durationSeconds: number;
}

function escapeDrawtext(text: string): string {
  return text.replace(/[^a-zA-Z0-9 ._\-:]/g, ' ').slice(0, 48);
}

/**
 * Resolves an internal storyboard/shot image URL (/assets/images/... or /api/objects/...)
 * to a strictly confined local filesystem path for FFmpeg assembly.
 */
function resolveLocalImageInput(
  imageUrl: string,
  objectStore: LocalObjectStore,
  workspaceRoot: string,
): string | null {
  if (imageUrl.startsWith('/assets/images/') || imageUrl.startsWith('/src/assets/images/')) {
    const fileName = imageUrl.split('/').pop() || '';
    if (!/^[a-zA-Z0-9._-]+\.(jpg|jpeg|png|webp)$/i.test(fileName)) return null;
    const candidate = resolve(workspaceRoot, 'src/assets/images', fileName);
    return existsSync(candidate) ? candidate : null;
  }
  if (imageUrl.startsWith('/api/objects/')) {
    const fileName = imageUrl.replace('/api/objects/', '');
    const obj = objectStore.readObjectByFilename(fileName);
    return obj ? obj.path : null;
  }
  if (imageUrl.startsWith('/api/media/')) {
    const fileName = imageUrl.replace('/api/media/', '');
    return objectStore.resolveMediaPath(fileName);
  }
  return null;
}

export async function generateAnimaticMp4(params: {
  panels: {panelCode: string; imageUrl: string; durationFrames: number; cameraNotes: string}[];
  fps: number;
  outputFileName: string;
  objectStore: LocalObjectStore;
  workspaceRoot: string;
}): Promise<{url: string; contentHash: string; totalFrames: number; durationSeconds: number}> {
  const workDir = join(params.objectStore.getMediaDir(), `_tmp_${Date.now()}`);
  mkdirSync(workDir, {recursive: true});

  try {
    const concatEntries: string[] = [];
    let totalFrames = 0;

    for (let idx = 0; idx < params.panels.length; idx++) {
      const panel = params.panels[idx];
      const frames = Math.max(1, Math.round(panel.durationFrames));
      totalFrames += frames;
      const durSec = Math.max(0.1, frames / params.fps);

      const inputImg = resolveLocalImageInput(panel.imageUrl, params.objectStore, params.workspaceRoot);
      const clipPath = join(workDir, `seg_${String(idx).padStart(3, '0')}.mp4`);

      const vfLabel = `scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=#F7F3EA,drawbox=x=0:y=0:w=1280:h=44:color=#0E172A@0.85:t=fill`;

      if (inputImg) {
        await execFileAsync('ffmpeg', [
          '-y',
          '-loop',
          '1',
          '-t',
          durSec.toFixed(4),
          '-i',
          inputImg,
          '-vf',
          vfLabel,
          '-r',
          String(params.fps),
          '-c:v',
          'libx264',
          '-pix_fmt',
          'yuv420p',
          '-an',
          clipPath,
        ]);
      } else {
        // Clean procedural slate card if panel image is SVG or inline placeholder
        await execFileAsync('ffmpeg', [
          '-y',
          '-f',
          'lavfi',
          '-i',
          `color=c=#EDE5D4:s=1280x720:r=${params.fps}:d=${durSec.toFixed(4)}`,
          '-vf',
          `drawbox=x=32:y=32:w=1216:h=656:color=#0E172A@0.4:t=2`,
          '-c:v',
          'libx264',
          '-pix_fmt',
          'yuv420p',
          '-an',
          clipPath,
        ]);
      }
      concatEntries.push(`file '${clipPath}'`);
    }

    const concatListPath = join(workDir, 'concat.txt');
    writeFileSync(concatListPath, concatEntries.join('\n'), 'utf8');

    const totalDur = Math.max(0.5, totalFrames / params.fps);
    const outPath = params.objectStore.resolveConfined(params.objectStore.getMediaDir(), params.outputFileName);

    // Combine segments + synthesize subtle warm British clockwork tick / chime temp audio at 48kHz
    await execFileAsync('ffmpeg', [
      '-y',
      '-f',
      'concat',
      '-safe',
      '0',
      '-i',
      concatListPath,
      '-f',
      'lavfi',
      '-i',
      `sine=frequency=440:sample_rate=48000:duration=${totalDur.toFixed(3)}`,
      '-filter_complex',
      '[1:a]volume=0.04[a]',
      '-map',
      '0:v',
      '-map',
      '[a]',
      '-c:v',
      'copy',
      '-c:a',
      'aac',
      '-ar',
      '48000',
      '-shortest',
      outPath,
    ]);

    const fileBuf = readFileSync(outPath);
    const contentHash = params.objectStore.computeSha256(fileBuf);
    return {
      url: `/api/media/${params.outputFileName}`,
      contentHash,
      totalFrames,
      durationSeconds: Number((totalFrames / params.fps).toFixed(2)),
    };
  } finally {
    rmSync(workDir, {recursive: true, force: true});
  }
}

export async function generateShotRenderClip(params: {
  shotCode: string;
  frameStart: number;
  frameEnd: number;
  fps: number;
  backdropUrl: string;
  outputFileName: string;
  objectStore: LocalObjectStore;
  workspaceRoot: string;
}): Promise<{url: string; contentHash: string; probe: MediaProbeResult}> {
  const frames = Math.max(12, params.frameEnd - params.frameStart + 1);
  const durSec = Math.max(0.5, frames / params.fps);
  const outPath = params.objectStore.resolveConfined(params.objectStore.getMediaDir(), params.outputFileName);
  const inputImg = resolveLocalImageInput(params.backdropUrl, params.objectStore, params.workspaceRoot);

  const label = escapeDrawtext(`AUREOM RENDER ${params.shotCode}`);
  if (inputImg) {
    await execFileAsync('ffmpeg', [
      '-y',
      '-loop',
      '1',
      '-t',
      durSec.toFixed(4),
      '-i',
      inputImg,
      '-vf',
      `scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=#0E172A,zoompan=z='min(zoom+0.0015,1.08)':d=${frames}:s=1280x720:fps=${params.fps}`,
      '-r',
      String(params.fps),
      '-c:v',
      'libx264',
      '-pix_fmt',
      'yuv420p',
      '-movflags',
      '+faststart',
      outPath,
    ]);
  } else {
    await execFileAsync('ffmpeg', [
      '-y',
      '-f',
      'lavfi',
      '-i',
      `testsrc2=size=1280x720:rate=${params.fps}:duration=${durSec.toFixed(4)}`,
      '-vf',
      `drawbox=x=24:y=24:w=1232:h=672:color=#9A7B3A@0.7:t=2`,
      '-c:v',
      'libx264',
      '-pix_fmt',
      'yuv420p',
      '-movflags',
      '+faststart',
      outPath,
    ]);
  }

  void label;
  const probe = await probeMediaFile(outPath);
  const fileBuf = readFileSync(outPath);
  return {
    url: `/api/media/${params.outputFileName}`,
    contentHash: params.objectStore.computeSha256(fileBuf),
    probe,
  };
}

export async function probeMediaFile(filePath: string): Promise<MediaProbeResult> {
  try {
    const {stdout} = await execFileAsync('ffprobe', [
      '-v',
      'error',
      '-select_streams',
      'v:0',
      '-count_frames',
      '-show_entries',
      'stream=codec_name,width,height,nb_read_frames,duration',
      '-of',
      'json',
      filePath,
    ]);
    const parsed = JSON.parse(stdout) as {
      streams?: {
        codec_name?: string;
        width?: number;
        height?: number;
        nb_read_frames?: string;
        duration?: string;
      }[];
    };
    const stream = parsed.streams?.[0];
    if (!stream) {
      return {
        passed: false,
        codec: 'unknown',
        width: 0,
        height: 0,
        frameCountDetected: 0,
        durationSeconds: 0,
      };
    }
    const frameCountDetected = Number(stream.nb_read_frames || 0);
    return {
      passed: frameCountDetected > 0 && (stream.width || 0) > 0,
      codec: stream.codec_name || 'h264',
      width: stream.width || 1280,
      height: stream.height || 720,
      frameCountDetected,
      durationSeconds: Number(Number(stream.duration || 0).toFixed(2)),
    };
  } catch {
    return {
      passed: false,
      codec: 'unknown',
      width: 0,
      height: 0,
      frameCountDetected: 0,
      durationSeconds: 0,
    };
  }
}
