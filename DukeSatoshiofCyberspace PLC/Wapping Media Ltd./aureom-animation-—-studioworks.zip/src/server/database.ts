import {createHmac, randomBytes, randomUUID, scryptSync, timingSafeEqual} from 'node:crypto';
import {existsSync, mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import {dirname, join, resolve} from 'node:path';
import {createSeedState} from './seed';
import {LocalObjectStore} from './storage';
import type {StudioDatabaseState, TeamMember, UserRole} from './types';

export type PermissionAction =
  | 'production:write'
  | 'script:write'
  | 'script:approve'
  | 'storyboard:write'
  | 'asset:work'
  | 'asset:publish'
  | 'shot:work'
  | 'review:comment'
  | 'review:creative_approve'
  | 'review:technical_validate'
  | 'review:delivery_approve'
  | 'render:submit'
  | 'render:admin'
  | 'budget:read'
  | 'budget:write'
  | 'team:write'
  | 'delivery:generate'
  | 'delivery:accept'
  | 'admin:manage'
  | 'ai:invoke';

const ROLE_PERMISSIONS: Record<UserRole, Set<PermissionAction>> = {
  Administrator: new Set<PermissionAction>([
    'production:write',
    'script:write',
    'script:approve',
    'storyboard:write',
    'asset:work',
    'asset:publish',
    'shot:work',
    'review:comment',
    'review:creative_approve',
    'review:technical_validate',
    'review:delivery_approve',
    'render:submit',
    'render:admin',
    'budget:read',
    'budget:write',
    'team:write',
    'delivery:generate',
    'delivery:accept',
    'admin:manage',
    'ai:invoke',
  ]),
  Producer: new Set<PermissionAction>([
    'production:write',
    'script:write',
    'script:approve',
    'storyboard:write',
    'asset:work',
    'asset:publish',
    'shot:work',
    'review:comment',
    'review:delivery_approve',
    'render:submit',
    'budget:read',
    'budget:write',
    'team:write',
    'delivery:generate',
    'delivery:accept',
    'ai:invoke',
  ]),
  Director: new Set<PermissionAction>([
    'production:write',
    'script:write',
    'script:approve',
    'storyboard:write',
    'review:comment',
    'review:creative_approve',
    'render:submit',
    'ai:invoke',
  ]),
  Supervisor: new Set<PermissionAction>([
    'production:write',
    'storyboard:write',
    'asset:work',
    'asset:publish',
    'shot:work',
    'review:comment',
    'review:technical_validate',
    'render:submit',
    'render:admin',
    'ai:invoke',
  ]),
  Artist: new Set<PermissionAction>([
    'storyboard:write',
    'asset:work',
    'asset:publish',
    'shot:work',
    'review:comment',
    'render:submit',
  ]),
  Reviewer: new Set<PermissionAction>([
    'review:comment',
    'review:creative_approve',
    'review:technical_validate',
    'review:delivery_approve',
    'ai:invoke',
  ]),
  Finance: new Set<PermissionAction>([
    'budget:read',
    'budget:write',
    'team:write',
  ]),
};

export interface AuthSessionClaims {
  memberId: string;
  memberName: string;
  role: UserRole;
  issuedAt: number;
  expiresAt: number;
}

export class StudioDatabase {
  private readonly dbFilePath: string;
  private readonly objectStore: LocalObjectStore;
  private state: StudioDatabaseState;
  private readonly sessionSecret: Buffer;

  constructor(dataDir: string = resolve(process.cwd(), 'data')) {
    mkdirSync(dataDir, {recursive: true});
    this.dbFilePath = join(dataDir, 'studioworks.json');
    this.objectStore = new LocalObjectStore(dataDir);

    const envSecret = process.env['STUDIO_SESSION_SECRET'];
    this.sessionSecret = envSecret && envSecret.length >= 16
      ? Buffer.from(envSecret, 'utf8')
      : randomBytes(32);

    if (existsSync(this.dbFilePath)) {
      const raw = readFileSync(this.dbFilePath, 'utf8');
      this.state = JSON.parse(raw) as StudioDatabaseState;
    } else {
      this.state = createSeedState(this.objectStore);
      this.persist();
    }
  }

  public getObjectStore(): LocalObjectStore {
    return this.objectStore;
  }

  public getState(): StudioDatabaseState {
    return this.state;
  }

  public persist(): void {
    mkdirSync(dirname(this.dbFilePath), {recursive: true});
    writeFileSync(this.dbFilePath, JSON.stringify(this.state, null, 2), 'utf8');
  }

  public hasPermission(role: UserRole, action: PermissionAction): boolean {
    return ROLE_PERMISSIONS[role]?.has(action) ?? false;
  }

  public getAuthStatus(): {
    envPasscodeConfigured: boolean;
    claimRequired: boolean;
    claimed: boolean;
  } {
    const envPass = (process.env['STUDIO_ADMIN_PASSCODE'] || '').trim();
    const envConfigured = envPass.length > 0;
    const claimed = envConfigured || Boolean(this.state.auth.adminPasscodeHash);
    return {
      envPasscodeConfigured: envConfigured,
      claimRequired: !claimed,
      claimed,
    };
  }

  public claimInitialPasscode(passcode: string): {ok: true} | {ok: false; reason: string} {
    const trimmed = passcode.trim();
    if (trimmed.length < 6) {
      return {ok: false, reason: 'Studio passcode must be at least 6 characters.'};
    }
    const status = this.getAuthStatus();
    if (status.envPasscodeConfigured) {
      return {ok: false, reason: 'Passcode is configured via STUDIO_ADMIN_PASSCODE environment variable.'};
    }
    if (this.state.auth.adminPasscodeHash) {
      return {ok: false, reason: 'Studio passcode has already been claimed.'};
    }
    const salt = randomBytes(16).toString('hex');
    const derived = scryptSync(trimmed, salt, 64).toString('hex');
    this.state.auth = {
      adminPasscodeHash: derived,
      adminPasscodeSalt: salt,
      claimedAt: new Date().toISOString(),
    };
    this.persist();
    return {ok: true};
  }

  public verifyPasscode(passcode: string): boolean {
    const trimmed = passcode.trim();
    if (!trimmed) return false;

    const envPass = (process.env['STUDIO_ADMIN_PASSCODE'] || '').trim();
    if (envPass.length > 0) {
      const a = Buffer.from(trimmed, 'utf8');
      const b = Buffer.from(envPass, 'utf8');
      return a.length === b.length && timingSafeEqual(a, b);
    }

    if (!this.state.auth.adminPasscodeHash || !this.state.auth.adminPasscodeSalt) {
      return false;
    }
    const derived = scryptSync(trimmed, this.state.auth.adminPasscodeSalt, 64);
    const expected = Buffer.from(this.state.auth.adminPasscodeHash, 'hex');
    return derived.length === expected.length && timingSafeEqual(derived, expected);
  }

  public issueSessionToken(member: TeamMember): string {
    const claims: AuthSessionClaims = {
      memberId: member.id,
      memberName: member.name,
      role: member.role,
      issuedAt: Date.now(),
      expiresAt: Date.now() + 1000 * 60 * 60 * 12,
    };
    const payload = Buffer.from(JSON.stringify(claims), 'utf8').toString('base64url');
    const sig = createHmac('sha256', this.sessionSecret).update(payload).digest('base64url');
    return `${payload}.${sig}`;
  }

  public verifySessionToken(token: string | undefined | null): AuthSessionClaims | null {
    if (!token || !token.includes('.')) return null;
    const [payload, sig] = token.split('.', 2);
    if (!payload || !sig) return null;
    const expectedSig = createHmac('sha256', this.sessionSecret).update(payload).digest('base64url');
    const a = Buffer.from(sig, 'utf8');
    const b = Buffer.from(expectedSig, 'utf8');
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
    try {
      const claims = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as AuthSessionClaims;
      if (Date.now() > claims.expiresAt) return null;
      return claims;
    } catch {
      return null;
    }
  }

  public recordAudit(params: {
    actorId: string;
    actorName: string;
    actorRole: UserRole;
    action: string;
    entityType: string;
    entityId: string;
    detail: string;
  }): void {
    this.state.auditLog.unshift({
      id: `aud_${randomUUID().slice(0, 8)}`,
      timestamp: new Date().toISOString(),
      ...params,
    });
    if (this.state.auditLog.length > 250) {
      this.state.auditLog = this.state.auditLog.slice(0, 250);
    }
  }

  public exportBackupSnapshot(): {
    exportedAt: string;
    schemaVersion: number;
    checksumSha256: string;
    payload: StudioDatabaseState;
  } {
    const serialized = JSON.stringify(this.state);
    const checksumSha256 = this.objectStore.computeSha256(Buffer.from(serialized, 'utf8'));
    return {
      exportedAt: new Date().toISOString(),
      schemaVersion: 1,
      checksumSha256,
      payload: JSON.parse(serialized) as StudioDatabaseState,
    };
  }

  public restoreBackupSnapshot(snapshot: {
    checksumSha256: string;
    payload: StudioDatabaseState;
  }): {ok: true} | {ok: false; reason: string} {
    if (!snapshot?.payload?.studio || !Array.isArray(snapshot.payload.productions)) {
      return {ok: false, reason: 'Invalid backup snapshot structure.'};
    }
    const serialized = JSON.stringify(snapshot.payload);
    const computed = this.objectStore.computeSha256(Buffer.from(serialized, 'utf8'));
    if (computed !== snapshot.checksumSha256) {
      return {
        ok: false,
        reason: `Backup integrity verification failed (expected ${snapshot.checksumSha256}, got ${computed}).`,
      };
    }
    // Preserve current auth claim if backup predated claim
    const currentAuth = this.state.auth;
    this.state = snapshot.payload;
    if (!this.state.auth?.adminPasscodeHash && currentAuth.adminPasscodeHash) {
      this.state.auth = currentAuth;
    }
    this.persist();
    return {ok: true};
  }

  public resetToSeed(): void {
    const currentAuth = this.state.auth;
    this.state = createSeedState(this.objectStore);
    this.state.auth = currentAuth;
    this.persist();
  }
}
