export type UserRole =
  | 'Producer'
  | 'Director'
  | 'Supervisor'
  | 'Artist'
  | 'Reviewer'
  | 'Finance'
  | 'Administrator';

export type ApprovalStatus =
  | 'Draft'
  | 'In Review'
  | 'Changes Requested'
  | 'Approved'
  | 'Locked';

export type PipelineMode = '3D' | '2D';

export type RenderJobState =
  | 'Queued'
  | 'Assigned'
  | 'Running'
  | 'Validating'
  | 'Completed'
  | 'Failed'
  | 'Cancelled';

export type DeliveryPackageState =
  | 'Generated'
  | 'Passed Review'
  | 'Accepted by Distributor';

export interface StudioProfile {
  id: string;
  name: string;
  legalEntity: string;
  location: string;
  defaultCurrency: 'GBP' | 'USD' | 'EUR';
  aiEnabled: boolean;
  aiExternalConsentRequired: boolean;
  reducedMotionDefault: boolean;
  revision: number;
}

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
  dayRateGbp: string;
  weeklyCapacityHours: number;
  availabilityNotes: string;
  unavailableDates: string[];
  active: boolean;
}

export interface ProductionMilestone {
  id: string;
  title: string;
  dueDate: string;
  ownerId: string;
  status: 'Upcoming' | 'At Risk' | 'Completed';
}

export interface DeliverySpec {
  id: string;
  name: string;
  resolution: string;
  fps: number;
  codec: string;
  colourSpace: string;
  audioSampleRateHz: number;
  audioChannels: string;
  subtitleFormat: string;
  version: number;
}

export interface SharedAssetPermission {
  assetId: string;
  targetProductionId: string;
  allowedVersionConstraint: string;
  permissionLevel: 'read-only' | 'link-approved';
  grantedBy: string;
  grantedAt: string;
}

export interface Production {
  id: string;
  code: string;
  title: string;
  format: 'Short Film' | 'Feature Film' | 'Television Series' | 'Advertisement' | 'Digital Series';
  audience: string;
  synopsis: string;
  creativeBrief: string;
  pipelineMode: PipelineMode;
  fps: number;
  aspectRatio: string;
  currency: 'GBP' | 'USD' | 'EUR';
  status: 'Development' | 'Pre-Production' | 'In Production' | 'Post-Production' | 'Delivered';
  deliveryDeadline: string;
  deliverySpecId: string;
  milestones: ProductionMilestone[];
  sharedAssetPermissions: SharedAssetPermission[];
  revision: number;
  createdAt: string;
  updatedAt: string;
}

export interface FilmOrEpisode {
  id: string;
  productionId: string;
  code: string;
  title: string;
  kind: 'Short Film' | 'Feature' | 'Episode';
  orderIndex: number;
  targetDurationFrames: number;
}

export interface Sequence {
  id: string;
  productionId: string;
  episodeId: string;
  code: string;
  title: string;
  orderIndex: number;
  synopsis: string;
}

export interface ScriptScene {
  sceneId: string;
  heading: string;
  location: string;
  timeOfDay: string;
  summary: string;
  characters: string[];
  props: string[];
  productionNotes: string;
}

export interface ScriptVersion {
  id: string;
  productionId: string;
  versionLabel: string;
  status: ApprovalStatus;
  authorId: string;
  createdAt: string;
  notes: string;
  bodyText: string;
  scenes: ScriptScene[];
}

export interface BreakdownProposal {
  id: string;
  productionId: string;
  scriptVersionId: string;
  source: 'Manual' | 'AI Suggestion';
  status: 'Pending Review' | 'Confirmed' | 'Dismissed';
  proposedAssets: {name: string; category: string; rationale: string}[];
  proposedSequences: {code: string; title: string; sceneId: string}[];
  proposedShots: {code: string; sequenceCode: string; summary: string; estimatedFrames: number}[];
  affectedRecordIds: string[];
  createdAt: string;
  confirmedBy?: string;
  confirmedAt?: string;
}

export interface StoryboardPanel {
  id: string;
  boardId: string;
  orderIndex: number;
  panelCode: string;
  sceneId: string;
  shotId: string;
  imageUrl: string;
  contentHash: string;
  dialogue: string;
  actionNotes: string;
  cameraNotes: string;
  durationFrames: number;
}

export interface StoryboardBoard {
  id: string;
  productionId: string;
  sequenceId: string;
  title: string;
  versionLabel: string;
  fps: number;
  status: ApprovalStatus;
  tempAudioLabel: string;
  tempAudioVersion: string;
  panels: StoryboardPanel[];
  revision: number;
  updatedAt: string;
}

export interface AnimaticExport {
  id: string;
  productionId: string;
  boardId: string;
  boardVersionLabel: string;
  fps: number;
  totalFrames: number;
  durationSeconds: number;
  panelSnapshot: {panelId: string; panelCode: string; durationFrames: number; contentHash: string}[];
  tempAudioVersion: string;
  mediaUrl: string;
  contentHash: string;
  createdBy: string;
  createdAt: string;
}

export type AssetCategory =
  | 'Character'
  | 'Environment'
  | 'Prop'
  | 'Rig'
  | 'Texture'
  | 'Material'
  | 'Reference Artwork'
  | 'Audio'
  | 'Reusable Effect';

export interface AssetVersion {
  id: string;
  assetId: string;
  versionNumber: number;
  versionLabel: string;
  immutable: boolean;
  fileName: string;
  mimeType: string;
  byteSize: number;
  contentHash: string;
  objectKey: string;
  previewUrl: string;
  toolName: string;
  toolVersion: string;
  publishedBy: string;
  publishedAt: string;
  notes: string;
  dependencyVersionIds: string[];
}

export interface Asset {
  id: string;
  productionId: string;
  code: string;
  name: string;
  category: AssetCategory;
  ownerId: string;
  assignedArtistIds: string[];
  workingFilePath: string;
  workingFileRevision: number;
  latestPublishedVersionId: string | null;
  previewUrl: string;
  approvalStatus: ApprovalStatus;
  sourceAndRights: string;
  rightsCleared: boolean;
  tags: string[];
  collections: string[];
  dimensionType: '3D' | '2D' | 'Audio';
  metadata3D?: {
    units: 'meters' | 'centimeters';
    upAxis: 'Z-up' | 'Y-up';
    forwardAxis: string;
    supportedAppVersion: string;
    polyCount: number;
    rigJointCount?: number;
  };
  metadata2D?: {
    widthPx: number;
    heightPx: number;
    colourProfile: string;
    expectedLayers: string[];
    sequenceTiming?: string;
  };
  versions: AssetVersion[];
  revision: number;
}

export interface ShotTask {
  id: string;
  shotId: string;
  productionId: string;
  department: string;
  orderIndex: number;
  assigneeId: string;
  dueDate: string;
  estimatedHours: number;
  actualHours: number;
  dependencyTaskIds: string[];
  linkedAssetVersionIds: string[];
  upstreamFlagged: boolean;
  upstreamFlagReason?: string;
  workingFilePath: string;
  currentVersionLabel: string;
  reviewStatus: ApprovalStatus;
  blockerNote?: string;
  approvedOutputVersionId?: string;
  approvedAt?: string;
  approvedBy?: string;
}

export interface Shot {
  id: string;
  productionId: string;
  sequenceId: string;
  code: string;
  title: string;
  pipelineMode: PipelineMode;
  startFrame: number;
  endFrame: number;
  fps: number;
  frameCount: number;
  status: ApprovalStatus;
  previewUrl: string;
  linkedAssetIds: string[];
  tasks: ShotTask[];
  revision: number;
}

export interface ReviewComment {
  id: string;
  reviewItemId: string;
  versionLabel: string;
  frameNumber: number;
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  body: string;
  resolved: boolean;
  carriedOverFromVersion?: string;
  createdAt: string;
}

export interface ReviewAnnotation {
  id: string;
  reviewItemId: string;
  versionLabel: string;
  frameNumber: number;
  authorId: string;
  authorName: string;
  colour: string;
  strokesJson: string;
  createdAt: string;
}

export interface ReviewMediaVersion {
  versionLabel: string;
  mediaUrl: string;
  thumbnailUrl: string;
  contentHash: string;
  fps: number;
  frameCount: number;
  submittedBy: string;
  submittedAt: string;
  notes: string;
}

export interface ReviewItem {
  id: string;
  productionId: string;
  shotId: string;
  taskId: string;
  title: string;
  assignedReviewerIds: string[];
  currentVersionLabel: string;
  versions: ReviewMediaVersion[];
  creativeApproval: ApprovalStatus;
  technicalValidation: 'Pending' | 'Passed' | 'Failed';
  deliveryApproval: 'Pending' | 'Approved' | 'Rejected';
  comments: ReviewComment[];
  annotations: ReviewAnnotation[];
  updatedAt: string;
}

export interface ExternalReviewLink {
  id: string;
  token: string;
  reviewItemId: string;
  label: string;
  allowDownload: boolean;
  expiresAt: string;
  createdBy: string;
  createdAt: string;
  revoked: boolean;
}

export interface RenderWorker {
  id: string;
  name: string;
  executionMode: 'Local Worker' | 'Simulated Farm' | 'Future Cloud Placeholder';
  capabilities: string[];
  blenderVersion: string;
  status: 'Online' | 'Busy' | 'Offline';
  lastHeartbeatAt: string;
  isolationPolicy: string;
  maxMemoryMb: number;
  maxCpuCores: number;
  networkRestricted: boolean;
}

export interface RenderJob {
  id: string;
  productionId: string;
  shotId: string;
  sceneVersionLabel: string;
  executionMode: 'Local Worker' | 'Simulated Farm';
  frameStart: number;
  frameEnd: number;
  currentFrame: number;
  renderSettings: {
    engine: string;
    samples: number;
    resolution: string;
    colourConfig: string;
  };
  requiredSoftwareVersion: string;
  dependencyManifest: {assetCode: string; versionLabel: string; contentHash: string}[];
  state: RenderJobState;
  workerId: string | null;
  leaseExpiresAt: string | null;
  attemptCount: number;
  maxRetries: number;
  idempotencyKey: string;
  outputMediaUrl?: string;
  outputHash?: string;
  validationReport?: {
    passed: boolean;
    codec: string;
    frameCountDetected: number;
    resolutionDetected: string;
    checkedAt: string;
  };
  logs: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface TimesheetEntry {
  id: string;
  productionId: string;
  memberId: string;
  shotId?: string;
  date: string;
  hours: number;
  department: string;
  notes: string;
}

export interface BudgetLine {
  id: string;
  productionId: string;
  department: string;
  description: string;
  currency: 'GBP' | 'USD' | 'EUR';
  budgetAmount: string;
  committedAmount: string;
  actualAmount: string;
  forecastRemainingAmount: string;
}

export interface PurchaseRecord {
  id: string;
  productionId: string;
  vendor: string;
  description: string;
  department: string;
  currency: 'GBP' | 'USD' | 'EUR';
  amount: string;
  status: 'Committed' | 'Paid';
  recordedAt: string;
}

export interface RightsRecord {
  id: string;
  productionId: string;
  category:
    | 'Contributor Agreement'
    | 'Asset Licence'
    | 'Music Permission'
    | 'Voice Performer Permission'
    | 'AI Likeness Consent';
  subjectName: string;
  referenceCode: string;
  permittedUses: string;
  status: 'Verified' | 'Missing Documentation' | 'Expired';
  expiresAt?: string;
  notes: string;
}

export interface DeliveryPackage {
  id: string;
  productionId: string;
  presetId: string;
  packageName: string;
  versionLabel: string;
  lifecycleState: DeliveryPackageState;
  mediaUrl: string;
  mediaChecksum: string;
  creditsText: string;
  subtitlesSrt: string;
  manifest: {
    assetVersions: {code: string; versionLabel: string; contentHash: string}[];
    shotVersions: {code: string; approvedVersion: string; contentHash: string}[];
    animaticId?: string;
  };
  technicalReport: {
    passed: boolean;
    fps: number;
    audioSampleRateHz: number;
    colourConfig: string;
    summary: string;
  };
  rightsAndApprovalRefs: {
    creativeDirectorApprovedBy: string;
    technicalValidatedBy: string;
    rightsClearanceCount: number;
    missingRightsCount: number;
  };
  createdBy: string;
  createdAt: string;
  reviewedBy?: string;
  reviewedAt?: string;
  acceptedByDistributorAt?: string;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  entityType: string;
  entityId: string;
  detail: string;
}

export interface AiProvenanceRecord {
  id: string;
  timestamp: string;
  feature:
    | 'Script Breakdown'
    | 'Asset Tagging'
    | 'Record Search'
    | 'Review Summary'
    | 'Schedule Conflicts'
    | 'Production Report';
  model: string;
  actorId: string;
  promptSummary: string;
  outputSummary: string;
  confirmedByHuman: boolean;
}

export interface ToolAdapterDescriptor {
  id: string;
  toolName: string;
  category: '3D Animation' | '2D Drawing' | 'Compositing' | 'Editorial';
  status: 'Implemented' | 'Interface Only (Unimplemented)';
  supportedExtensions: string[];
  pythonModule: string;
  notes: string;
}

export interface StudioDatabaseState {
  studio: StudioProfile;
  auth: {
    adminPasscodeHash: string | null;
    adminPasscodeSalt: string | null;
    claimedAt: string | null;
  };
  team: TeamMember[];
  deliverySpecs: DeliverySpec[];
  productions: Production[];
  episodes: FilmOrEpisode[];
  sequences: Sequence[];
  scripts: ScriptVersion[];
  breakdownProposals: BreakdownProposal[];
  storyboards: StoryboardBoard[];
  animatics: AnimaticExport[];
  assets: Asset[];
  shots: Shot[];
  reviews: ReviewItem[];
  externalReviewLinks: ExternalReviewLink[];
  workers: RenderWorker[];
  renderJobs: RenderJob[];
  timesheets: TimesheetEntry[];
  budgetLines: BudgetLine[];
  purchases: PurchaseRecord[];
  rights: RightsRecord[];
  deliveries: DeliveryPackage[];
  auditLog: AuditEvent[];
  aiProvenance: AiProvenanceRecord[];
  toolAdapters: ToolAdapterDescriptor[];
}
