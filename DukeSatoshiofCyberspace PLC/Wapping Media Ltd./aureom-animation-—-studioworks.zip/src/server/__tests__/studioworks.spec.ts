import {mkdtempSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import express from 'express';
import {afterAll, beforeAll, describe, expect, it} from 'vitest';
import {StudioDatabase} from '../database';
import {createApiRouter} from '../routes';

describe('Aureom StudioWorks Core Pipeline & Security', () => {
  let tmpDir: string;
  let db: StudioDatabase;
  let baseUrl: string;
  let server: ReturnType<express.Express['listen']>;

  let adminToken = '';
  let artistToken = '';
  let financeToken = '';
  let directorToken = '';

  beforeAll(async () => {
    tmpDir = mkdtempSync(join(tmpdir(), 'aureom-test-'));
    db = new StudioDatabase(tmpDir);
    const app = express();
    app.use('/api', createApiRouter(db, () => undefined, process.cwd()));

    await new Promise<void>((resolve) => {
      server = app.listen(0, () => {
        const addr = server.address();
        if (addr && typeof addr === 'object') {
          baseUrl = `http://127.0.0.1:${addr.port}`;
        }
        resolve();
      });
    });

    // Claim initial studio passcode
    const claimRes = await fetch(`${baseUrl}/api/auth/claim`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({passcode: 'yorkshire-fox-24fps', memberId: 'usr_admin'}),
    });
    expect(claimRes.status).toBe(200);
    adminToken = ((await claimRes.json()) as {token: string}).token;

    // Issue tokens for specific roles
    const loginRole = async (memberId: string) => {
      const r = await fetch(`${baseUrl}/api/auth/login`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({passcode: 'yorkshire-fox-24fps', memberId}),
      });
      expect(r.status).toBe(200);
      return ((await r.json()) as {token: string}).token;
    };

    artistToken = await loginRole('usr_owen');
    financeToken = await loginRole('usr_julian');
    directorToken = await loginRole('usr_arthur');
  });

  afterAll(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    rmSync(tmpDir, {recursive: true, force: true});
  });

  it('enforces server-side RBAC permissions across roles', async () => {
    // Unauthenticated mutation rejected
    const unauth = await fetch(`${baseUrl}/api/productions`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({code: 'TST', title: 'Unauthorized'}),
    });
    expect(unauth.status).toBe(401);

    // Artist cannot create budget lines
    const artistBudget = await fetch(`${baseUrl}/api/budget-lines`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${artistToken}`,
      },
      body: JSON.stringify({department: 'Art', budgetAmount: 1000}),
    });
    expect(artistBudget.status).toBe(403);

    // Finance cannot approve creative reviews
    const financeApprove = await fetch(`${baseUrl}/api/reviews/rev_sh050/decision`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${financeToken}`,
      },
      body: JSON.stringify({gate: 'creative', status: 'Approved'}),
    });
    expect(financeApprove.status).toBe(403);

    // Finance CAN add budget line
    const financeBudget = await fetch(`${baseUrl}/api/budget-lines`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${financeToken}`,
      },
      body: JSON.stringify({department: 'Festival Prints', budgetAmount: '1250.00'}),
    });
    expect(financeBudget.status).toBe(201);
  });

  it('enforces asset version immutability and flags downstream tasks without invalidating approved output', async () => {
    const overwriteAttempt = await fetch(`${baseUrl}/api/assets/ast_fox/versions/av_fox_v1`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${artistToken}`,
      },
      body: JSON.stringify({notes: 'overwrite'}),
    });
    expect(overwriteAttempt.status).toBe(409);

    const publishRes = await fetch(`${baseUrl}/api/assets/ast_fox/publish`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${artistToken}`,
      },
      body: JSON.stringify({notes: 'Tail secondary rig update'}),
    });
    expect(publishRes.status).toBe(201);
    const body = (await publishRes.json()) as {
      version: {versionLabel: string; immutable: boolean};
      flaggedCount: number;
    };
    expect(body.version.versionLabel).toBe('v003');
    expect(body.version.immutable).toBe(true);
    expect(body.flaggedCount).toBeGreaterThan(0);

    // Approved SH010 output remains intact despite upstream flag
    const sh010 = db.getState().shots.find((s) => s.id === 'shot_010')!;
    expect(sh010.tasks[1].approvedOutputVersionId).toBeTruthy();
  });

  it('converts storyboard FPS using deliberate integer frame rounding and preserves version history', async () => {
    const res = await fetch(`${baseUrl}/api/storyboards/brd_cfx_master/convert-fps`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${directorToken}`,
      },
      body: JSON.stringify({targetFps: 25}),
    });
    expect(res.status).toBe(200);
    const board = (await res.json()) as {fps: number; versionLabel: string; panels: {durationFrames: number}[]};
    expect(board.fps).toBe(25);
    expect(board.versionLabel).toBe('v3');
    expect(board.panels.every((p) => Number.isInteger(p.durationFrames))).toBe(true);
  });

  it('carries forward unresolved review feedback attribution when a new version is submitted', async () => {
    const res = await fetch(`${baseUrl}/api/reviews/shot_070/submit-preview`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${artistToken}`,
      },
      body: JSON.stringify({notes: 'Added 6f anticipation before paw contact'}),
    });
    expect(res.status).toBe(201);
    const rev = (await res.json()) as {
      currentVersionLabel: string;
      comments: {versionLabel: string; carriedOverFromVersion?: string; resolved: boolean}[];
    };
    expect(rev.currentVersionLabel).toBe('v002');
    const originalNote = rev.comments.find((c) => c.versionLabel === 'v001' && !c.resolved);
    expect(originalNote?.carriedOverFromVersion).toBe('v001');
  });

  it('enforces idempotent render submission and lease recovery for expired worker leases', async () => {
    const submit1 = await fetch(`${baseUrl}/api/render-jobs`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${artistToken}`,
      },
      body: JSON.stringify({shotId: 'shot_020', frameStart: 1, frameEnd: 24, idempotencyKey: 'idem_test_020'}),
    });
    expect(submit1.status).toBe(201);
    const job1 = (await submit1.json()) as {id: string};

    const submit2 = await fetch(`${baseUrl}/api/render-jobs`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${artistToken}`,
      },
      body: JSON.stringify({shotId: 'shot_020', frameStart: 1, frameEnd: 24, idempotencyKey: 'idem_test_020'}),
    });
    expect(submit2.status).toBe(200);
    const job2 = (await submit2.json()) as {id: string};
    expect(job2.id).toBe(job1.id);

    // Simulate expired lease recovery on worker claim
    const target = db.getState().renderJobs.find((j) => j.id === job1.id)!;
    target.state = 'Running';
    target.leaseExpiresAt = new Date(Date.now() - 60_000).toISOString();
    target.attemptCount = 1;

    const claimRes = await fetch(`${baseUrl}/api/pipeline/worker/claim`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${artistToken}`,
      },
      body: JSON.stringify({workerId: 'wrk_local_01'}),
    });
    expect(claimRes.status).toBe(200);
    const claimed = (await claimRes.json()) as {job: {id: string; attemptCount: number}};
    expect(claimed.job).toBeTruthy();
  });

  it('separates Generated delivery packages from Accepted by Distributor and enforces rights & review gates', async () => {
    const genRes = await fetch(`${baseUrl}/api/deliveries/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
      },
      body: JSON.stringify({productionId: 'prod_clockwork_fox'}),
    });
    expect(genRes.status).toBe(201);
    const pkg = (await genRes.json()) as {id: string; lifecycleState: string; manifest: {assetVersions: unknown[]}};
    expect(pkg.lifecycleState).toBe('Generated');
    expect(pkg.manifest.assetVersions.length).toBeGreaterThan(0);

    // Cannot jump straight to Accepted by Distributor
    const badTransition = await fetch(`${baseUrl}/api/deliveries/${pkg.id}/transition`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
      },
      body: JSON.stringify({lifecycleState: 'Accepted by Distributor'}),
    });
    expect(badTransition.status).toBe(409);
  });

  it('detects concurrent edit conflicts (409) and validates backup snapshot integrity', async () => {
    const staleUpdate = await fetch(`${baseUrl}/api/productions/prod_clockwork_fox`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
      },
      body: JSON.stringify({title: 'Stale Title', expectedRevision: 999}),
    });
    expect(staleUpdate.status).toBe(409);

    const backupRes = await fetch(`${baseUrl}/api/admin/backup`, {
      headers: {Authorization: `Bearer ${adminToken}`},
    });
    expect(backupRes.status).toBe(200);
    const snapshot = (await backupRes.json()) as {checksumSha256: string; payload: unknown};

    // Tampered snapshot rejected
    const badRestore = await fetch(`${baseUrl}/api/admin/restore`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
      },
      body: JSON.stringify({...snapshot, checksumSha256: '0'.repeat(64)}),
    });
    expect(badRestore.status).toBe(400);

    // Valid snapshot restored
    const okRestore = await fetch(`${baseUrl}/api/admin/restore`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
      },
      body: JSON.stringify(snapshot),
    });
    expect(okRestore.status).toBe(200);
  });
});
