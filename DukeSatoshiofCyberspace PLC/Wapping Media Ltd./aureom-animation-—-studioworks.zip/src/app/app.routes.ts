import {Routes} from '@angular/router';

export const routes: Routes = [
  {path: '', redirectTo: 'studio', pathMatch: 'full'},
  {
    path: 'studio',
    loadComponent: () => import('./pages/studio-home').then((m) => m.StudioHome),
  },
  {
    path: 'productions',
    loadComponent: () => import('./pages/productions').then((m) => m.ProductionsWorkspace),
  },
  {
    path: 'scripts',
    loadComponent: () => import('./pages/scripts').then((m) => m.ScriptsWorkspace),
  },
  {
    path: 'storyboards',
    loadComponent: () => import('./pages/storyboards').then((m) => m.StoryboardsWorkspace),
  },
  {
    path: 'assets',
    loadComponent: () => import('./pages/assets').then((m) => m.AssetsWorkspace),
  },
  {
    path: 'shots',
    loadComponent: () => import('./pages/shots').then((m) => m.ShotsWorkspace),
  },
  {
    path: 'reviews',
    loadComponent: () => import('./pages/reviews').then((m) => m.ReviewsWorkspace),
  },
  {
    path: 'render-farm',
    loadComponent: () => import('./pages/render-farm').then((m) => m.RenderFarmWorkspace),
  },
  {
    path: 'team',
    loadComponent: () => import('./pages/team').then((m) => m.TeamWorkspace),
  },
  {
    path: 'budget',
    loadComponent: () => import('./pages/budget').then((m) => m.BudgetWorkspace),
  },
  {
    path: 'deliveries',
    loadComponent: () => import('./pages/deliveries').then((m) => m.DeliveriesWorkspace),
  },
  {
    path: 'administration',
    loadComponent: () => import('./pages/administration').then((m) => m.AdministrationWorkspace),
  },
  {
    path: 'external-review/:token',
    loadComponent: () => import('./pages/external-review').then((m) => m.ExternalReviewPage),
  },
  {path: '**', redirectTo: 'studio'},
];
