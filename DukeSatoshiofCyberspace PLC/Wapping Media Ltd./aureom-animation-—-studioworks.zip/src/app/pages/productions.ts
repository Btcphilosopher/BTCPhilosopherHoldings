import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {StudioStore} from '../core/studio.store';
import {StatusTag} from '../shared/status-tag';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-productions-workspace',
  imports: [ReactiveFormsModule, MatIconModule, StatusTag],
  template: `
    @if (store.data(); as d) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="font-display text-2xl font-semibold text-[#0E172A]">Productions & Hierarchy</h1>
            <p class="text-xs text-[#64748B] mt-1">
              Studio → Production → Film/Episode → Sequence → Shot → Task → Published Version
            </p>
          </div>
          <button
            type="button"
            (click)="showCreate.set(!showCreate())"
            class="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">add</mat-icon>
            <span>{{ showCreate() ? 'Close Form' : 'New Production' }}</span>
          </button>
        </div>

        @if (showCreate()) {
          <form
            [formGroup]="createForm"
            (ngSubmit)="submitCreate()"
            class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4"
          >
            <h2 class="font-display text-lg font-semibold text-[#0E172A]">Create Production Record</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label for="prod-code" class="block text-xs font-medium text-[#334155] mb-1">Code</label>
                <input
                  id="prod-code"
                  formControlName="code"
                  type="text"
                  placeholder="e.g. BRK"
                  class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg"
                />
              </div>
              <div>
                <label for="prod-title" class="block text-xs font-medium text-[#334155] mb-1">Title</label>
                <input
                  id="prod-title"
                  formControlName="title"
                  type="text"
                  placeholder="Production title"
                  class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg"
                />
              </div>
              <div>
                <label for="prod-format" class="block text-xs font-medium text-[#334155] mb-1">Format</label>
                <select id="prod-format" formControlName="format" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg">
                  <option value="Short Film">Short Film</option>
                  <option value="Feature Film">Feature Film</option>
                  <option value="Television Series">Television Series</option>
                  <option value="Advertisement">Advertisement</option>
                  <option value="Digital Series">Digital Series</option>
                </select>
              </div>
              <div>
                <label for="prod-mode" class="block text-xs font-medium text-[#334155] mb-1">Pipeline Mode</label>
                <select id="prod-mode" formControlName="pipelineMode" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg">
                  <option value="3D">3D (Blender / Cycles)</option>
                  <option value="2D">2D (Rough / Cleanup / Colour)</option>
                </select>
              </div>
              <div>
                <label for="prod-fps" class="block text-xs font-medium text-[#334155] mb-1">Frame Rate (fps)</label>
                <input
                  id="prod-fps"
                  formControlName="fps"
                  type="number"
                  class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg font-mono-tabular"
                />
              </div>
              <div>
                <label for="prod-deadline" class="block text-xs font-medium text-[#334155] mb-1">Delivery Deadline</label>
                <input
                  id="prod-deadline"
                  formControlName="deliveryDeadline"
                  type="date"
                  class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg font-mono-tabular"
                />
              </div>
            </div>
            <div>
              <label for="prod-synopsis" class="block text-xs font-medium text-[#334155] mb-1">Synopsis & Creative Brief</label>
              <textarea
                id="prod-synopsis"
                formControlName="synopsis"
                rows="2"
                class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg"
              ></textarea>
            </div>
            <div class="flex justify-end gap-3">
              <button
                type="submit"
                [disabled]="createForm.invalid"
                class="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] disabled:opacity-50 rounded-lg"
              >
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">save</mat-icon>
                <span>Create Production</span>
              </button>
            </div>
          </form>
        }

        <!-- Production Cards -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          @for (prod of d.productions; track prod.id) {
            <div
              class="bg-[#FCFBF7] border rounded-xl p-6 space-y-4"
              [class]="prod.id === store.activeProductionId() ? 'border-[#1B4D3E]' : 'border-[#DDD3BC]'"
            >
              <div class="flex items-start justify-between gap-4">
                <div>
                  <div class="text-xs font-mono-tabular text-[#85682D]">
                    {{ prod.code }} · {{ prod.format }} · {{ prod.pipelineMode }} · {{ prod.fps }} fps · rev {{ prod.revision }}
                  </div>
                  <h2 class="font-display text-xl font-semibold text-[#0E172A] mt-1">{{ prod.title }}</h2>
                </div>
                <app-status-tag
                  [label]="prod.status"
                  [tone]="prod.status === 'In Production' ? 'active' : prod.status === 'Delivered' ? 'approved' : 'neutral'"
                />
              </div>

              <p class="text-sm text-[#334155] leading-relaxed">{{ prod.synopsis }}</p>

              <div class="grid grid-cols-2 gap-3 text-xs bg-white border border-[#E5DEC9] rounded-lg p-3">
                <div>
                  <span class="text-[#64748B]">Audience:</span>
                  <div class="font-medium text-[#0E172A] mt-0.5">{{ prod.audience }}</div>
                </div>
                <div>
                  <span class="text-[#64748B]">Delivery Target:</span>
                  <div class="font-mono-tabular font-medium text-[#0E172A] mt-0.5">{{ prod.deliveryDeadline }}</div>
                </div>
                <div class="col-span-2">
                  <span class="text-[#64748B]">Creative Brief:</span>
                  <div class="text-[#334155] mt-0.5">{{ prod.creativeBrief }}</div>
                </div>
              </div>

              <div class="flex items-center justify-between gap-4 pt-2 border-t border-[#E5DEC9]">
                <span class="text-xs text-[#64748B] font-mono-tabular">ID: {{ prod.id }}</span>
                <button
                  type="button"
                  (click)="store.activeProductionId.set(prod.id)"
                  class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors whitespace-nowrap shrink-0"
                  [class]="prod.id === store.activeProductionId() ? 'bg-[#1B4D3E] text-white border-[#1B4D3E]' : 'bg-white text-[#0E172A] border-[#DDD3BC] hover:bg-[#F7F3EA]'"
                >
                  <mat-icon class="!text-[15px] !w-[15px] !h-[15px]" aria-hidden="true">check</mat-icon>
                  <span>{{ prod.id === store.activeProductionId() ? 'Active Workspace' : 'Set Active' }}</span>
                </button>
              </div>
            </div>
          }
        </div>

        <!-- Hierarchy & Shared Asset Permissions -->
        <div class="grid grid-cols-1 xl:grid-cols-12 gap-6">
          <div class="xl:col-span-7 bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
            <h2 class="font-display text-lg font-semibold text-[#0E172A]">
              Production Hierarchy ({{ store.activeProduction()?.code }})
            </h2>
            <div class="space-y-3">
              @for (seq of store.activeSequences(); track seq.id) {
                <div class="bg-white border border-[#E5DEC9] rounded-lg p-4">
                  <div class="flex items-center justify-between gap-4">
                    <div class="font-medium text-sm text-[#0E172A]">
                      <span class="font-mono-tabular text-[#85682D] mr-2">{{ seq.code }}</span>
                      <span>{{ seq.title }}</span>
                    </div>
                    <span class="text-xs font-mono-tabular text-[#64748B]">
                      {{ shotsInSeq(seq.id).length }} shots
                    </span>
                  </div>
                  <p class="text-xs text-[#475569] mt-1">{{ seq.synopsis }}</p>
                  <div class="mt-3 flex flex-wrap gap-2">
                    @for (shot of shotsInSeq(seq.id); track shot.id) {
                      <span class="text-xs font-mono-tabular px-2 py-1 bg-[#F7F3EA] border border-[#DDD3BC] rounded text-[#0E172A]">
                        {{ shot.code }} ({{ shot.frameCount }}f)
                      </span>
                    }
                  </div>
                </div>
              }
            </div>
          </div>

          <div class="xl:col-span-5 bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
            <h2 class="font-display text-lg font-semibold text-[#0E172A]">Cross-Production Asset Permissions</h2>
            <p class="text-xs text-[#475569]">
              Shared assets require explicit permission records and semantic version constraints.
            </p>
            <div class="space-y-3">
              @for (perm of activeSharedPerms(); track perm.assetId) {
                <div class="bg-white border border-[#E5DEC9] rounded-lg p-3.5 text-xs space-y-1">
                  <div class="font-medium text-[#0E172A]">Asset: {{ perm.assetId }} → Target: {{ perm.targetProductionId }}</div>
                  <div class="text-[#475569] font-mono-tabular">
                    Constraint: {{ perm.allowedVersionConstraint }} · Access: {{ perm.permissionLevel }}
                  </div>
                  <div class="text-[#64748B]">Granted by {{ perm.grantedBy }}</div>
                </div>
              } @empty {
                <div class="text-xs text-[#64748B] py-4">No outbound shared asset grants for this production.</div>
              }
            </div>

            <div class="pt-3 border-t border-[#E5DEC9] space-y-2">
              <div class="text-xs font-semibold text-[#0E172A]">Delivery Specification</div>
              @if (activeDeliverySpec(); as spec) {
                <div class="text-xs text-[#334155] space-y-1 font-mono-tabular">
                  <div>{{ spec.name }} (v{{ spec.version }})</div>
                  <div>{{ spec.resolution }} · {{ spec.fps }} fps · {{ spec.codec }}</div>
                  <div>Colour: {{ spec.colourSpace }} · Audio: {{ spec.audioSampleRateHz }} Hz</div>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class ProductionsWorkspace {
  protected readonly store = inject(StudioStore);
  protected readonly showCreate = signal(false);

  protected readonly createForm = new FormGroup({
    code: new FormControl('', [Validators.required, Validators.maxLength(8)]),
    title: new FormControl('', [Validators.required]),
    format: new FormControl<'Short Film'>('Short Film'),
    pipelineMode: new FormControl<'3D' | '2D'>('3D'),
    fps: new FormControl(24, [Validators.required, Validators.min(12), Validators.max(60)]),
    deliveryDeadline: new FormControl('2027-04-30', [Validators.required]),
    synopsis: new FormControl(''),
  });

  protected readonly activeSharedPerms = computed(
    () => this.store.activeProduction()?.sharedAssetPermissions ?? [],
  );

  protected readonly activeDeliverySpec = computed(() => {
    const prod = this.store.activeProduction();
    const specs = this.store.data()?.deliverySpecs ?? [];
    return specs.find((s) => s.id === prod?.deliverySpecId) ?? specs[0] ?? null;
  });

  protected shotsInSeq(seqId: string) {
    return this.store.activeShots().filter((s) => s.sequenceId === seqId);
  }

  protected async submitCreate(): Promise<void> {
    if (this.createForm.invalid) return;
    const val = this.createForm.getRawValue();
    const created = await this.store.mutate('POST', '/api/productions', val, `Created production ${val.code}.`);
    if (created) {
      this.showCreate.set(false);
      this.createForm.reset({format: 'Short Film', pipelineMode: '3D', fps: 24, deliveryDeadline: '2027-04-30'});
    }
  }
}
