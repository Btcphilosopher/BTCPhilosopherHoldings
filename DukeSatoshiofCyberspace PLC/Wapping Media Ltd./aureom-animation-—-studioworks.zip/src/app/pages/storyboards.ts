import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {StudioStore} from '../core/studio.store';
import type {AnimaticExport, StoryboardPanel} from '../core/studio.models';
import {MediaFrame} from '../shared/media-frame';
import {StatusTag} from '../shared/status-tag';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-storyboards-workspace',
  imports: [ReactiveFormsModule, MatIconModule, MediaFrame, StatusTag],
  template: `
    @if (activeBoard(); as board) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="font-display text-2xl font-semibold text-[#0E172A]">{{ board.title }}</h1>
            <p class="text-xs text-[#64748B] mt-1 font-mono-tabular">
              Revision {{ board.versionLabel }} · {{ board.fps }} fps · {{ board.panels.length }} panels · {{ totalFrames() }} integer frames ({{ totalSeconds() }}s) · Temp Audio: {{ board.tempAudioLabel }}
            </p>
          </div>
          <div class="flex flex-wrap items-center gap-2">
            <button
              type="button"
              (click)="showUploadPanel.set(!showUploadPanel())"
              class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#0E172A] bg-white border border-[#DDD3BC] hover:bg-[#F7F3EA] rounded-lg whitespace-nowrap shrink-0"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">add_photo_alternate</mat-icon>
              <span>Add Panel</span>
            </button>
            <button
              type="button"
              (click)="exportAnimatic(board.id)"
              [disabled]="exporting()"
              class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] disabled:opacity-60 rounded-lg whitespace-nowrap shrink-0"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">movie</mat-icon>
              <span>{{ exporting() ? 'Rendering MP4 Animatic...' : 'Export MP4 Animatic' }}</span>
            </button>
          </div>
        </div>

        <!-- Deliberate Frame-Rate Conversion & Animatic Controls -->
        <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
          <div class="flex flex-wrap items-center gap-3">
            <span class="text-xs font-semibold text-[#0E172A]">Frame-Rate Conversion Workflow:</span>
            <select
              [value]="targetFps()"
              (change)="onTargetFpsChange($event)"
              aria-label="Target frame rate"
              class="px-3 py-1.5 text-xs font-mono-tabular bg-white border border-[#DDD3BC] rounded-lg"
            >
              <option value="24">24 fps (Theatrical)</option>
              <option value="25">25 fps (UK Broadcast PAL)</option>
              <option value="30">30 fps (Web / NTSC)</option>
            </select>
            <button
              type="button"
              (click)="convertBoardFps(board.id)"
              [disabled]="targetFps() === board.fps"
              class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#0E172A] bg-white border border-[#9A7B3A] disabled:opacity-40 rounded-lg"
            >
              <mat-icon class="!text-[15px] !w-[15px] !h-[15px]" aria-hidden="true">speed</mat-icon>
              <span>Convert to {{ targetFps() }} fps (Creates New Board Version)</span>
            </button>
          </div>

          <app-status-tag [label]="board.status" [tone]="board.status === 'Approved' ? 'approved' : 'active'" />
        </div>

        @if (showUploadPanel()) {
          <form
            [formGroup]="panelForm"
            (ngSubmit)="submitNewPanel(board.id)"
            class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4"
          >
            <h2 class="font-display text-lg font-semibold text-[#0E172A]">Add Storyboard Panel</h2>
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label for="pnl-code" class="block text-xs font-medium text-[#334155] mb-1">Panel Code</label>
                <input id="pnl-code" formControlName="panelCode" type="text" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg font-mono-tabular" />
              </div>
              <div>
                <label for="pnl-scene" class="block text-xs font-medium text-[#334155] mb-1">Scene ID</label>
                <input id="pnl-scene" formControlName="sceneId" type="text" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg font-mono-tabular" />
              </div>
              <div>
                <label for="pnl-dur" class="block text-xs font-medium text-[#334155] mb-1">Duration (Frames)</label>
                <input id="pnl-dur" formControlName="durationFrames" type="number" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg font-mono-tabular" />
              </div>
              <div>
                <label for="pnl-file" class="block text-xs font-medium text-[#334155] mb-1">Upload Image (Optional)</label>
                <input id="pnl-file" type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" (change)="onPanelImageSelected($event)" class="w-full text-xs text-[#475569] py-1.5" />
              </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label for="pnl-cam" class="block text-xs font-medium text-[#334155] mb-1">Camera Notes</label>
                <input id="pnl-cam" formControlName="cameraNotes" type="text" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg" />
              </div>
              <div>
                <label for="pnl-act" class="block text-xs font-medium text-[#334155] mb-1">Action / Dialogue Notes</label>
                <input id="pnl-act" formControlName="actionNotes" type="text" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg" />
              </div>
            </div>
            <div class="flex justify-end">
              <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] rounded-lg">
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">save</mat-icon>
                <span>Save Panel</span>
              </button>
            </div>
          </form>
        }

        <!-- Latest Animatic Player & Lineage -->
        @if (latestAnimatic(); as anm) {
          <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div class="lg:col-span-6">
              @if (anm.mediaUrl) {
                <video
                  [src]="anm.mediaUrl"
                  controls
                  class="w-full aspect-video rounded-lg bg-[#0E172A] border border-[#DDD3BC]"
                ></video>
              } @else {
                <div class="aspect-video rounded-lg bg-[#0E172A] text-[#F7F3EA] flex flex-col items-center justify-center p-6 text-center">
                  <mat-icon class="!text-[36px] !w-[36px] !h-[36px] text-[#B8964D] mb-2" aria-hidden="true">movie_edit</mat-icon>
                  <div class="text-sm font-medium">Seeded Animatic {{ anm.id }} ({{ anm.totalFrames }} frames &#64; {{ anm.fps }} fps)</div>
                  <p class="text-xs text-[#CBD5E1] mt-1">Click "Export MP4 Animatic" above to compile a playable H.264 MP4 from all current panels with FFmpeg.</p>
                </div>
              }
            </div>
            <div class="lg:col-span-6 space-y-3">
              <div class="text-xs font-medium text-[#85682D]">Animatic Lineage & Exact Timing Lock</div>
              <h2 class="font-display text-lg font-semibold text-[#0E172A]">
                {{ anm.id }} · Board {{ anm.boardVersionLabel }}
              </h2>
              <div class="grid grid-cols-2 gap-3 text-xs font-mono-tabular bg-white border border-[#E5DEC9] rounded-lg p-3">
                <div>Total Frames: <strong>{{ anm.totalFrames }}</strong></div>
                <div>Duration: <strong>{{ anm.durationSeconds }}s &#64; {{ anm.fps }} fps</strong></div>
                <div>Audio Track: <strong>{{ anm.tempAudioVersion }}</strong></div>
                <div>Panels Linked: <strong>{{ anm.panelSnapshot.length }}</strong></div>
                <div class="col-span-2 truncate">SHA-256: {{ anm.contentHash }}</div>
              </div>
              <div class="text-xs text-[#475569]">
                Compiled by {{ anm.createdBy }} · Preserves exact panel hashes and integer durations for editorial reference.
              </div>
            </div>
          </div>
        }

        <!-- Large Storyboard Panels Grid with Accessible Reorder & Timing -->
        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          @for (panel of board.panels; track panel.id; let idx = $index) {
            <article class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-4 flex flex-col justify-between space-y-3">
              <div class="space-y-3">
                <div class="flex items-center justify-between gap-2">
                  <span class="font-mono-tabular text-xs font-semibold text-[#0E172A]">
                    #{{ idx + 1 }} · {{ panel.panelCode }} · {{ panel.sceneId }}
                  </span>
                  <div class="flex items-center gap-1">
                    <button
                      type="button"
                      [disabled]="idx === 0"
                      (click)="movePanel(board.id, board.panels, idx, -1)"
                      aria-label="Move panel earlier"
                      class="p-1.5 rounded border border-[#DDD3BC] bg-white hover:bg-[#F7F3EA] disabled:opacity-35"
                    >
                      <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">arrow_upward</mat-icon>
                    </button>
                    <button
                      type="button"
                      [disabled]="idx === board.panels.length - 1"
                      (click)="movePanel(board.id, board.panels, idx, 1)"
                      aria-label="Move panel later"
                      class="p-1.5 rounded border border-[#DDD3BC] bg-white hover:bg-[#F7F3EA] disabled:opacity-35"
                    >
                      <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">arrow_downward</mat-icon>
                    </button>
                  </div>
                </div>

                <app-media-frame
                  [src]="panel.imageUrl"
                  [alt]="panel.panelCode + ' storyboard artwork'"
                  [fallbackTitle]="panel.panelCode"
                  containerClass="aspect-video rounded-lg"
                />

                <div class="text-xs text-[#0E172A] leading-relaxed">{{ panel.actionNotes }}</div>
                @if (panel.dialogue) {
                  <div class="text-xs italic text-[#475569]">{{ panel.dialogue }}</div>
                }
                <div class="text-xs text-[#64748B]">Camera: {{ panel.cameraNotes }}</div>
              </div>

              <div class="pt-3 border-t border-[#E5DEC9] flex items-center justify-between gap-2 text-xs font-mono-tabular">
                <span class="text-[#475569]">Duration: <strong>{{ panel.durationFrames }}f</strong> ({{ (panel.durationFrames / board.fps).toFixed(2) }}s)</span>
                <div class="flex items-center gap-1">
                  <button
                    type="button"
                    (click)="adjustFrames(board.id, panel, -12)"
                    class="px-2 py-1 bg-white border border-[#DDD3BC] rounded hover:bg-[#F7F3EA]"
                  >
                    -12f
                  </button>
                  <button
                    type="button"
                    (click)="adjustFrames(board.id, panel, 12)"
                    class="px-2 py-1 bg-white border border-[#DDD3BC] rounded hover:bg-[#F7F3EA]"
                  >
                    +12f
                  </button>
                </div>
              </div>
            </article>
          }
        </div>
      </div>
    }
  `,
})
export class StoryboardsWorkspace {
  protected readonly store = inject(StudioStore);
  protected readonly showUploadPanel = signal(false);
  protected readonly exporting = signal(false);
  protected readonly targetFps = signal(25);
  private uploadedImageUrl = signal<string>('');
  private uploadedHash = signal<string>('');

  protected readonly panelForm = new FormGroup({
    panelCode: new FormControl('PNL-013', [Validators.required]),
    sceneId: new FormControl('SC-03', [Validators.required]),
    durationFrames: new FormControl(72, [Validators.required, Validators.min(1)]),
    cameraNotes: new FormControl('35mm Gentle Push In'),
    actionNotes: new FormControl('Pip tilts his head toward the morning chime.'),
  });

  protected readonly activeBoard = computed(() => {
    const pid = this.store.activeProduction()?.id;
    return (this.store.data()?.storyboards ?? []).find((b) => b.productionId === pid) ?? null;
  });

  protected readonly totalFrames = computed(() =>
    (this.activeBoard()?.panels ?? []).reduce((acc, p) => acc + p.durationFrames, 0),
  );

  protected readonly totalSeconds = computed(() => {
    const b = this.activeBoard();
    if (!b || !b.fps) return '0.00';
    return (this.totalFrames() / b.fps).toFixed(2);
  });

  protected readonly latestAnimatic = computed<AnimaticExport | null>(() => {
    const b = this.activeBoard();
    if (!b) return null;
    return (this.store.data()?.animatics ?? []).find((a) => a.boardId === b.id) ?? null;
  });

  protected onTargetFpsChange(event: Event): void {
    const val = Number((event.target as HTMLSelectElement).value);
    if ([24, 25, 30].includes(val)) {
      this.targetFps.set(val);
    }
  }

  protected async onPanelImageSelected(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const base64Data = String(reader.result || '');
      const uploaded = await this.store.mutate<{publicUrl: string; contentHash: string}>(
        'POST',
        '/api/uploads/direct',
        {fileName: file.name, mimeType: file.type, base64Data},
        `Uploaded ${file.name} (SHA-256 verified).`,
      );
      if (uploaded) {
        this.uploadedImageUrl.set(uploaded.publicUrl);
        this.uploadedHash.set(uploaded.contentHash);
      }
    };
    reader.readAsDataURL(file);
  }

  protected async submitNewPanel(boardId: string): Promise<void> {
    if (this.panelForm.invalid) return;
    const v = this.panelForm.getRawValue();
    const res = await this.store.mutate(
      'POST',
      `/api/storyboards/${boardId}/panels`,
      {
        panelCode: v.panelCode,
        sceneId: v.sceneId,
        durationFrames: v.durationFrames,
        cameraNotes: v.cameraNotes,
        actionNotes: v.actionNotes,
        imageUrl: this.uploadedImageUrl() || '/assets/images/storyboard_panel_01_1795352361907.jpg',
        contentHash: this.uploadedHash() || undefined,
      },
      `Added storyboard panel ${v.panelCode}.`,
    );
    if (res) {
      this.showUploadPanel.set(false);
    }
  }

  protected async movePanel(
    boardId: string,
    panels: StoryboardPanel[],
    index: number,
    delta: number,
  ): Promise<void> {
    const nextIdx = index + delta;
    if (nextIdx < 0 || nextIdx >= panels.length) return;
    const copy = [...panels];
    const [moved] = copy.splice(index, 1);
    copy.splice(nextIdx, 0, moved);
    await this.store.mutate(
      'PATCH',
      `/api/storyboards/${boardId}/reorder`,
      {orderedPanelIds: copy.map((p) => p.id)},
      `Moved ${moved.panelCode} to position #${nextIdx + 1}.`,
    );
  }

  protected async adjustFrames(boardId: string, panel: StoryboardPanel, delta: number): Promise<void> {
    const next = Math.max(12, panel.durationFrames + delta);
    await this.store.mutate(
      'PATCH',
      `/api/storyboards/${boardId}/panels/${panel.id}`,
      {durationFrames: next},
      `Updated ${panel.panelCode} to ${next} frames.`,
    );
  }

  protected async convertBoardFps(boardId: string): Promise<void> {
    await this.store.mutate(
      'POST',
      `/api/storyboards/${boardId}/convert-fps`,
      {targetFps: this.targetFps()},
      `Converted storyboard timing to ${this.targetFps()} fps.`,
    );
  }

  protected async exportAnimatic(boardId: string): Promise<void> {
    this.exporting.set(true);
    try {
      await this.store.mutate(
        'POST',
        `/api/storyboards/${boardId}/export-animatic`,
        {},
        'Exported playable MP4 animatic with locked frame manifest.',
      );
    } finally {
      this.exporting.set(false);
    }
  }
}
