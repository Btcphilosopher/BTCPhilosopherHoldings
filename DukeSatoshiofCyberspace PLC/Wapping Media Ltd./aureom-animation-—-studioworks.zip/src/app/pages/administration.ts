import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {StudioStore} from '../core/studio.store';
import {StatusTag} from '../shared/status-tag';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-administration-workspace',
  imports: [MatIconModule, StatusTag],
  template: `
    @if (store.data(); as d) {
      <div class="space-y-6">
        <div>
          <h1 class="font-display text-2xl font-semibold text-[#0E172A]">Administration, Security & Pipeline</h1>
          <p class="text-xs text-[#64748B] mt-1">
            Role-scoped permissions, Blender & tool adapters, optional AI governance, backup restoration, and immutable audit history.
          </p>
        </div>

        <!-- Role Switcher & Session RBAC Verification -->
        <section class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
          <div class="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 class="font-display text-lg font-semibold text-[#0E172A]">Active Studio Operator & RBAC Role</h2>
              <p class="text-xs text-[#475569]">
                Every mutation enforces server-side Bearer authentication and role permissions (Producer, Director, Supervisor, Artist, Reviewer, Finance, Administrator).
              </p>
            </div>
            @if (!store.isSignedIn()) {
              <button
                type="button"
                (click)="store.authModalOpen.set(true)"
                class="px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] rounded-lg"
              >
                Sign In to Edit
              </button>
            } @else {
              <button
                type="button"
                (click)="store.signOut()"
                class="px-3 py-1.5 text-xs font-medium bg-white border border-[#DDD3BC] rounded-lg"
              >
                Sign Out ({{ store.currentUser()?.role }})
              </button>
            }
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            @for (member of d.team; track member.id) {
              <button
                type="button"
                (click)="store.switchRole(member.id)"
                class="text-left p-3 rounded-lg border transition-colors"
                [class]="store.currentUser()?.id === member.id ? 'bg-[#0E172A] text-white border-[#0E172A]' : 'bg-white text-[#0E172A] border-[#E5DEC9] hover:border-[#9A7B3A]'"
              >
                <div class="text-xs font-semibold">{{ member.name }}</div>
                <div class="text-[11px] opacity-80">{{ member.role }} · {{ member.department }}</div>
              </button>
            }
          </div>
        </section>

        <!-- Tool Adapters & Blender Plugin -->
        <section class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
          <h2 class="font-display text-lg font-semibold text-[#0E172A]">Animation Tool Adapters & Blender Plugin</h2>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            @for (adp of d.toolAdapters; track adp.id) {
              <div class="bg-white border border-[#E5DEC9] rounded-lg p-4 space-y-2 text-xs">
                <div class="flex items-center justify-between gap-2">
                  <span class="font-semibold text-sm text-[#0E172A]">{{ adp.toolName }} ({{ adp.category }})</span>
                  <app-status-tag
                    [label]="adp.status"
                    [tone]="adp.status === 'Implemented' ? 'approved' : 'neutral'"
                  />
                </div>
                <div class="font-mono-tabular text-[#64748B]">{{ adp.pythonModule }} · {{ adp.supportedExtensions.join(', ') }}</div>
                <div class="text-[#334155]">{{ adp.notes }}</div>
              </div>
            }
          </div>
        </section>

        <!-- Optional AI Assistance Governance & Console -->
        <section class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
          <div class="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 class="font-display text-lg font-semibold text-[#0E172A]">Optional AI Assistance (Studio Remains Fully Functional When Disabled)</h2>
              <p class="text-xs text-[#475569]">
                Disabled by default. Never silently submits unreleased media or scripts; requires explicit confirmation and records provenance.
              </p>
            </div>
            <button
              type="button"
              (click)="toggleAi(!d.studio.aiEnabled)"
              class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg border"
              [class]="d.studio.aiEnabled ? 'bg-[#1B4D3E] text-white border-[#1B4D3E]' : 'bg-white text-[#0E172A] border-[#DDD3BC]'"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">auto_awesome</mat-icon>
              <span>{{ d.studio.aiEnabled ? 'AI Enabled (Click to Disable)' : 'Enable Optional AI Tools' }}</span>
            </button>
          </div>

          @if (d.studio.aiEnabled) {
            <div class="bg-white border border-[#E5DEC9] rounded-lg p-4 space-y-3">
              <div class="flex flex-wrap items-center gap-2">
                <select
                  [value]="aiFeature()"
                  (change)="onAiFeatureChange($event)"
                  aria-label="AI feature"
                  class="px-3 py-2 text-xs bg-[#F7F3EA] border border-[#DDD3BC] rounded-lg"
                >
                  <option value="Review Summary">Summarise Review Feedback</option>
                  <option value="Schedule Conflicts">Identify Schedule Conflicts</option>
                  <option value="Production Report">Draft Production Report</option>
                  <option value="Asset Tagging">Suggest Asset Tags</option>
                  <option value="Record Search">Search Production Records</option>
                </select>
                <input
                  type="text"
                  [value]="aiPrompt()"
                  (input)="onAiPromptInput($event)"
                  placeholder="Question or prompt..."
                  class="flex-1 min-w-[220px] px-3 py-2 text-xs bg-[#F7F3EA] border border-[#DDD3BC] rounded-lg"
                />
                <button
                  type="button"
                  (click)="runAi()"
                  [disabled]="aiBusy()"
                  class="px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] rounded-lg"
                >
                  {{ aiBusy() ? 'Running...' : 'Confirm & Run' }}
                </button>
              </div>
              @if (aiOutput()) {
                <pre class="p-3 bg-[#F7F3EA] border border-[#E5DEC9] rounded text-xs text-[#0E172A] whitespace-pre-wrap">{{ aiOutput() }}</pre>
              }
            </div>
          }
        </section>

        <!-- Backup & Tested Restoration + Audit History -->
        <div class="grid grid-cols-1 xl:grid-cols-12 gap-6">
          <section class="xl:col-span-5 bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
            <h2 class="font-display text-lg font-semibold text-[#0E172A]">Backup & Verified Restoration</h2>
            <p class="text-xs text-[#475569]">
              Exports a SHA-256 checksummed JSON snapshot of all production records and validates checksum integrity before restoring.
            </p>
            <div class="flex flex-wrap gap-2">
              <button
                type="button"
                (click)="exportBackup()"
                class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-[#1B4D3E] rounded-lg"
              >
                <mat-icon class="!text-[15px] !w-[15px] !h-[15px]" aria-hidden="true">download</mat-icon>
                <span>Export & Verify Snapshot</span>
              </button>
              <label class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-white border border-[#DDD3BC] rounded-lg cursor-pointer hover:bg-[#F7F3EA]">
                <mat-icon class="!text-[15px] !w-[15px] !h-[15px]" aria-hidden="true">restore</mat-icon>
                <span>Restore from Snapshot</span>
                <input type="file" accept=".json,application/json" class="hidden" (change)="restoreFromFile($event)" />
              </label>
            </div>
            @if (backupInfo()) {
              <div class="text-xs font-mono-tabular bg-white border border-[#E5DEC9] rounded p-3 text-[#334155]">
                {{ backupInfo() }}
              </div>
            }
          </section>

          <section class="xl:col-span-7 bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
            <h2 class="font-display text-lg font-semibold text-[#0E172A]">Immutable Audit Log</h2>
            <div class="max-h-72 overflow-y-auto divide-y divide-[#EFE8D8] text-xs">
              @for (ev of d.auditLog; track ev.id) {
                <div class="py-2.5 flex items-start justify-between gap-4">
                  <div>
                    <span class="font-mono-tabular font-semibold text-[#0E172A]">{{ ev.action }}</span>
                    <span class="text-[#475569] ml-2">{{ ev.detail }}</span>
                    <div class="text-[11px] text-[#64748B]">{{ ev.actorName }} ({{ ev.actorRole }})</div>
                  </div>
                  <span class="font-mono-tabular text-[11px] text-[#64748B] shrink-0">{{ ev.timestamp.slice(0, 19) }}</span>
                </div>
              }
            </div>
          </section>
        </div>
      </div>
    }
  `,
})
export class AdministrationWorkspace {
  protected readonly store = inject(StudioStore);
  protected readonly aiFeature = signal('Review Summary');
  protected readonly aiPrompt = signal('Summarise unresolved dailies feedback for The Clockwork Fox.');
  protected readonly aiBusy = signal(false);
  protected readonly aiOutput = signal<string | null>(null);
  protected readonly backupInfo = signal<string | null>(null);

  protected async toggleAi(enable: boolean): Promise<void> {
    await this.store.mutate(
      'PATCH',
      '/api/admin/studio',
      {aiEnabled: enable},
      enable ? 'Optional AI assistance enabled.' : 'Optional AI assistance disabled.',
    );
  }

  protected onAiFeatureChange(event: Event): void {
    this.aiFeature.set((event.target as HTMLSelectElement).value);
  }

  protected onAiPromptInput(event: Event): void {
    this.aiPrompt.set((event.target as HTMLInputElement).value);
  }

  protected async runAi(): Promise<void> {
    this.aiBusy.set(true);
    try {
      const res = await this.store.mutate<{text?: string}>(
        'POST',
        '/api/ai/assist',
        {
          feature: this.aiFeature(),
          promptInput: this.aiPrompt(),
          explicitConsentConfirmed: true,
        },
      );
      if (res?.text) {
        this.aiOutput.set(res.text);
      }
    } finally {
      this.aiBusy.set(false);
    }
  }

  protected async exportBackup(): Promise<void> {
    const snap = await this.store.getAuthed<{exportedAt: string; checksumSha256: string}>('/api/admin/backup');
    if (!snap) return;
    this.backupInfo.set(`Verified snapshot exported ${snap.exportedAt} · SHA-256 ${snap.checksumSha256}`);
    const blob = new Blob([JSON.stringify(snap, null, 2)], {type: 'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aureom_studioworks_backup_${snap.exportedAt.slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  protected async restoreFromFile(event: Event): Promise<void> {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) return;
    const text = await file.text();
    try {
      const parsed = JSON.parse(text);
      const res = await this.store.mutate<{ok: boolean}>(
        'POST',
        '/api/admin/restore',
        parsed,
        'Backup checksum verified and studio records restored.',
      );
      if (res?.ok) {
        this.backupInfo.set(`Restored snapshot from ${file.name} (checksum verified).`);
      }
    } catch {
      this.backupInfo.set('Invalid JSON backup file.');
    }
  }
}
