import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {StudioStore} from '../core/studio.store';
import {StatusTag} from '../shared/status-tag';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-scripts-workspace',
  imports: [ReactiveFormsModule, MatIconModule, StatusTag],
  template: `
    @if (store.data(); as d) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="font-display text-2xl font-semibold text-[#0E172A]">Scripts & Breakdowns</h1>
            <p class="text-xs text-[#64748B] mt-1">
              Versioned screenplay revisions, scene breakdowns, downstream impact tracking, and human-confirmed plan updates.
            </p>
          </div>
          <div class="flex flex-wrap items-center gap-2">
            <button
              type="button"
              (click)="requestAiBreakdown()"
              [disabled]="!d.studio.aiEnabled || aiBusy()"
              class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border rounded-lg transition-colors whitespace-nowrap shrink-0"
              [class]="d.studio.aiEnabled ? 'bg-white text-[#0E172A] border-[#9A7B3A] hover:bg-[#F7F3EA]' : 'bg-[#EDE5D4]/60 text-[#64748B] border-[#DDD3BC] cursor-not-allowed'"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">auto_awesome</mat-icon>
              <span>{{ d.studio.aiEnabled ? (aiBusy() ? 'Analysing Script...' : 'Suggest AI Breakdown') : 'AI Disabled in Admin' }}</span>
            </button>
            <button
              type="button"
              (click)="showNewRevision.set(!showNewRevision())"
              class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg whitespace-nowrap shrink-0"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">edit_note</mat-icon>
              <span>{{ showNewRevision() ? 'Cancel Revision' : 'New Script Revision' }}</span>
            </button>
          </div>
        </div>

        @if (showNewRevision()) {
          <form
            [formGroup]="revisionForm"
            (ngSubmit)="submitRevision()"
            class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4"
          >
            <h2 class="font-display text-lg font-semibold text-[#0E172A]">Publish New Script Revision</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label for="scr-ver" class="block text-xs font-medium text-[#334155] mb-1">Version Label</label>
                <input id="scr-ver" formControlName="versionLabel" type="text" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg font-mono-tabular" />
              </div>
              <div>
                <label for="scr-notes" class="block text-xs font-medium text-[#334155] mb-1">Revision Notes</label>
                <input id="scr-notes" formControlName="notes" type="text" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg" />
              </div>
            </div>
            <div>
              <label for="scr-body" class="block text-xs font-medium text-[#334155] mb-1">Screenplay Text</label>
              <textarea id="scr-body" formControlName="bodyText" rows="5" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg font-mono"></textarea>
            </div>
            <div class="flex justify-end">
              <button
                type="submit"
                [disabled]="revisionForm.invalid"
                class="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg"
              >
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">publish</mat-icon>
                <span>Save Revision & Generate Breakdown Proposal</span>
              </button>
            </div>
          </form>
        }

        <div class="grid grid-cols-1 xl:grid-cols-12 gap-6">
          <!-- Script Version Selector & Screenplay -->
          <div class="xl:col-span-7 bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
            <div class="flex flex-wrap items-center justify-between gap-3 border-b border-[#E5DEC9] pb-3">
              <div class="flex items-center gap-2">
                @for (scr of prodScripts(); track scr.id) {
                  <button
                    type="button"
                    (click)="selectedScriptId.set(scr.id)"
                    class="px-3 py-1.5 text-xs font-mono-tabular font-medium rounded-lg border transition-colors"
                    [class]="selectedScript().id === scr.id ? 'bg-[#0E172A] text-white border-[#0E172A]' : 'bg-white text-[#334155] border-[#DDD3BC] hover:bg-[#F7F3EA]'"
                  >
                    {{ scr.versionLabel }}
                  </button>
                }
              </div>
              @if (selectedScript(); as cur) {
                <app-status-tag [label]="cur.status" [tone]="cur.status === 'Approved' ? 'approved' : 'active'" />
              }
            </div>

            @if (selectedScript(); as scr) {
              <div class="text-xs text-[#64748B]">
                Created {{ scr.createdAt.slice(0, 10) }} · {{ scr.notes }}
              </div>
              <pre class="p-4 bg-white border border-[#E5DEC9] rounded-lg text-xs text-[#0E172A] whitespace-pre-wrap font-mono leading-relaxed">{{ scr.bodyText }}</pre>

              <div class="space-y-3 pt-2">
                <h3 class="font-display text-base font-semibold text-[#0E172A]">Scene Breakdown</h3>
                @for (sc of scr.scenes; track sc.sceneId) {
                  <div class="bg-white border border-[#E5DEC9] rounded-lg p-4 space-y-2">
                    <div class="flex items-center justify-between gap-2">
                      <div class="font-semibold text-sm text-[#0E172A]">
                        <span class="font-mono-tabular text-[#85682D] mr-2">{{ sc.sceneId }}</span>
                        <span>{{ sc.heading }}</span>
                      </div>
                      <span class="text-xs text-[#64748B]">{{ sc.location }} · {{ sc.timeOfDay }}</span>
                    </div>
                    <p class="text-xs text-[#334155]">{{ sc.summary }}</p>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#475569] pt-1">
                      <div><strong>Characters:</strong> {{ sc.characters.join(', ') }}</div>
                      <div><strong>Props:</strong> {{ sc.props.join(', ') }}</div>
                    </div>
                    <div class="text-xs text-[#1B4D3E]"><strong>Notes:</strong> {{ sc.productionNotes }}</div>
                  </div>
                }
              </div>
            }
          </div>

          <!-- Breakdown Proposals & Script Change Impact -->
          <div class="xl:col-span-5 space-y-4">
            <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
              <h2 class="font-display text-lg font-semibold text-[#0E172A]">Breakdown Proposals & Impact Review</h2>
              <p class="text-xs text-[#475569]">
                Script edits never overwrite the shot plan automatically. Producers or Directors must review and confirm proposed assets and affected shots.
              </p>

              @for (prop of prodBreakdowns(); track prop.id) {
                <div class="bg-white border border-[#E5DEC9] rounded-lg p-4 space-y-3">
                  <div class="flex items-center justify-between gap-2">
                    <div class="text-xs font-medium text-[#0E172A]">
                      {{ prop.source }} · Script {{ prop.scriptVersionId }}
                    </div>
                    <app-status-tag
                      [label]="prop.status"
                      [tone]="prop.status === 'Confirmed' ? 'approved' : prop.status === 'Pending Review' ? 'warning' : 'neutral'"
                    />
                  </div>

                  @if (prop.proposedAssets.length > 0) {
                    <div class="text-xs space-y-1">
                      <div class="font-semibold text-[#334155]">Proposed Assets</div>
                      @for (pa of prop.proposedAssets; track pa.name) {
                        <div class="text-[#475569]">• {{ pa.name }} ({{ pa.category }}) — {{ pa.rationale }}</div>
                      }
                    </div>
                  }

                  @if (prop.proposedShots.length > 0) {
                    <div class="text-xs space-y-1">
                      <div class="font-semibold text-[#334155]">Proposed Shots</div>
                      @for (ps of prop.proposedShots; track ps.code) {
                        <div class="text-[#475569] font-mono-tabular">
                          • {{ ps.code }} ({{ ps.sequenceCode }}, {{ ps.estimatedFrames }}f) — {{ ps.summary }}
                        </div>
                      }
                    </div>
                  }

                  @if (prop.affectedRecordIds.length > 0) {
                    <div class="text-xs text-amber-900 bg-amber-50 border border-amber-200 rounded p-2">
                      Affected records flagged: {{ prop.affectedRecordIds.join(', ') }}
                    </div>
                  }

                  @if (prop.status === 'Pending Review') {
                    <div class="flex items-center gap-2 pt-1">
                      <button
                        type="button"
                        (click)="decideBreakdown(prop.id, 'confirm')"
                        class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg"
                      >
                        <mat-icon class="!text-[15px] !w-[15px] !h-[15px]" aria-hidden="true">check</mat-icon>
                        <span>Confirm into Plan</span>
                      </button>
                      <button
                        type="button"
                        (click)="decideBreakdown(prop.id, 'dismiss')"
                        class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#334155] bg-[#F7F3EA] border border-[#DDD3BC] rounded-lg"
                      >
                        <mat-icon class="!text-[15px] !w-[15px] !h-[15px]" aria-hidden="true">close</mat-icon>
                        <span>Dismiss</span>
                      </button>
                    </div>
                  } @else if (prop.confirmedBy) {
                    <div class="text-xs text-[#64748B]">
                      {{ prop.status }} by {{ prop.confirmedBy }}
                    </div>
                  }
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class ScriptsWorkspace {
  protected readonly store = inject(StudioStore);
  protected readonly selectedScriptId = signal<string>('');
  protected readonly showNewRevision = signal(false);
  protected readonly aiBusy = signal(false);

  protected readonly revisionForm = new FormGroup({
    versionLabel: new FormControl('v1.3', [Validators.required]),
    notes: new FormControl('Added close-up of brass pocket-watch chime gear', [Validators.required]),
    bodyText: new FormControl(
      'SC-03 INT. CONSERVATORY SUNDIAL - MORNING\nPip retrieves the tarnished brass pocket-watch winding key and engages the master gearwork escapement.',
      [Validators.required],
    ),
  });

  protected readonly prodScripts = computed(() => {
    const pid = this.store.activeProduction()?.id;
    return (this.store.data()?.scripts ?? []).filter((s) => s.productionId === pid);
  });

  protected readonly selectedScript = computed(() => {
    const list = this.prodScripts();
    const id = this.selectedScriptId();
    return list.find((s) => s.id === id) ?? list[list.length - 1] ?? null;
  });

  protected readonly prodBreakdowns = computed(() => {
    const pid = this.store.activeProduction()?.id;
    return (this.store.data()?.breakdownProposals ?? []).filter((b) => b.productionId === pid);
  });

  protected async submitRevision(): Promise<void> {
    const pid = this.store.activeProduction()?.id;
    if (!pid || this.revisionForm.invalid) return;
    const val = this.revisionForm.getRawValue();
    const res = await this.store.mutate(
      'POST',
      '/api/scripts',
      {
        productionId: pid,
        versionLabel: val.versionLabel,
        notes: val.notes,
        bodyText: val.bodyText,
        scenes: [
          {
            sceneId: 'SC-03',
            heading: 'INT. CONSERVATORY SUNDIAL - MORNING',
            location: 'Hidden Glasshouse',
            timeOfDay: 'Morning',
            summary: val.notes || 'Updated scene beat',
            characters: ['Pip the Red Fox', 'Stationmaster Bram'],
            props: ['Brass Winding Key', 'Master Escapement Gear'],
            productionNotes: 'Flagged for storyboard & prop alignment.',
          },
        ],
      },
      `Published script ${val.versionLabel} and created breakdown proposal.`,
    );
    if (res) {
      this.showNewRevision.set(false);
    }
  }

  protected async decideBreakdown(id: string, decision: 'confirm' | 'dismiss'): Promise<void> {
    await this.store.mutate(
      'POST',
      `/api/breakdowns/${id}/confirm`,
      {decision},
      decision === 'confirm' ? 'Confirmed breakdown items into asset plan.' : 'Dismissed breakdown proposal.',
    );
  }

  protected async requestAiBreakdown(): Promise<void> {
    const scr = this.selectedScript();
    if (!scr) return;
    this.aiBusy.set(true);
    try {
      await this.store.mutate(
        'POST',
        '/api/ai/assist',
        {
          feature: 'Script Breakdown',
          promptInput: scr.bodyText,
          explicitConsentConfirmed: true,
        },
        'AI breakdown suggestion added for Producer confirmation.',
      );
    } finally {
      this.aiBusy.set(false);
    }
  }
}
