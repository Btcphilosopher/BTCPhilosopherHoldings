import {ChangeDetectionStrategy, Component, computed, inject} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {RouterLink} from '@angular/router';
import {StudioStore} from '../core/studio.store';
import {MediaFrame} from '../shared/media-frame';
import {StatusTag} from '../shared/status-tag';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-studio-home',
  imports: [RouterLink, MatIconModule, StatusTag, MediaFrame],
  template: `
    @if (store.data(); as d) {
      <div class="space-y-8">
        <!-- Studio Editorial Header -->
        <section class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 lg:p-8">
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            <div class="lg:col-span-7 flex flex-col justify-between space-y-5">
              <div>
                <p class="text-xs font-medium text-[#85682D] tracking-wide mb-2">
                  {{ d.studio.legalEntity }} · {{ d.studio.location }}
                </p>
                <h1 class="font-display text-3xl lg:text-4xl font-semibold text-[#0E172A] leading-tight text-balance">
                  {{ activeProd()?.title || 'Studio Production Desk' }}
                </h1>
                <p class="mt-3 text-sm text-[#334155] leading-relaxed max-w-2xl">
                  {{ activeProd()?.synopsis }}
                </p>
              </div>

              <div class="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-[#475569] border-t border-[#E5DEC9] pt-4 font-mono-tabular">
                <span>Code: <strong class="text-[#0E172A]">{{ activeProd()?.code }}</strong></span>
                <span>Format: <strong class="text-[#0E172A]">{{ activeProd()?.format }}</strong></span>
                <span>Timing: <strong class="text-[#0E172A]">{{ activeProd()?.fps }} fps · {{ totalFrames() }} frames</strong></span>
                <span>Deadline: <strong class="text-[#0E172A]">{{ activeProd()?.deliveryDeadline }}</strong></span>
              </div>

              <div class="flex flex-wrap items-center gap-3 pt-1">
                <a
                  routerLink="/shots"
                  class="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">movie_filter</mat-icon>
                  <span>Open Shot Board</span>
                </a>
                <a
                  routerLink="/reviews"
                  class="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-[#0E172A] bg-white border border-[#DDD3BC] hover:bg-[#F7F3EA] rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">rate_review</mat-icon>
                  <span>Dailies Review ({{ pendingReviews().length }})</span>
                </a>
              </div>
            </div>

            <div class="lg:col-span-5">
              <app-media-frame
                src="/assets/images/yorkshire_station_env_1795352360997.jpg"
                alt="The Clockwork Fox Yorkshire railway station key art"
                fallbackTitle="The Clockwork Fox — Key Art"
                containerClass="h-full min-h-[220px] rounded-lg"
              />
            </div>
          </div>
        </section>

        <!-- 4-Column Studio Overview Strip -->
        <section class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5">
            <div class="text-xs text-[#64748B]">Active Productions</div>
            <div class="mt-2 font-display text-2xl font-semibold text-[#0E172A] tabular-nums">
              {{ d.productions.length }}
            </div>
            <div class="mt-1 text-xs text-[#475569]">
              {{ activeProd()?.code }} in production · THL in prep
            </div>
          </div>

          <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5">
            <div class="text-xs text-[#64748B]">Shots Approved</div>
            <div class="mt-2 font-display text-2xl font-semibold text-[#0E172A] tabular-nums">
              {{ approvedShotsCount() }} / {{ store.activeShots().length }}
            </div>
            <div class="mt-1 text-xs text-[#475569] tabular-nums">
              {{ totalFrames() }} frames locked at {{ activeProd()?.fps }} fps
            </div>
          </div>

          <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5">
            <div class="text-xs text-[#64748B]">Open Review Requests</div>
            <div class="mt-2 font-display text-2xl font-semibold text-[#0E172A] tabular-nums">
              {{ pendingReviews().length }}
            </div>
            <div class="mt-1 text-xs text-[#475569]">
              {{ unresolvedNotesCount() }} unresolved frame notes
            </div>
          </div>

          <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5">
            <div class="text-xs text-[#64748B]">Render Farm Queue</div>
            <div class="mt-2 font-display text-2xl font-semibold text-[#0E172A] tabular-nums">
              {{ completedRendersCount() }} done · {{ queuedRendersCount() }} queued
            </div>
            <div class="mt-1 text-xs text-[#475569]">
              {{ onlineWorkersCount() }} workers online
            </div>
          </div>
        </section>

        <!-- Main Operational Split: Milestones + Assigned Work / Render & Delivery -->
        <section class="grid grid-cols-1 xl:grid-cols-12 gap-6">
          <!-- Upcoming Milestones & Delivery Deadlines -->
          <div class="xl:col-span-6 bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
            <div class="flex items-center justify-between gap-4">
              <h2 class="font-display text-lg font-semibold text-[#0E172A]">Milestones & Delivery Deadlines</h2>
              <a routerLink="/productions" class="text-xs font-medium text-[#1B4D3E] hover:underline whitespace-nowrap shrink-0">
                Production Plan
              </a>
            </div>
            <div class="overflow-x-auto">
              <table class="w-full text-left border-collapse text-sm">
                <thead>
                  <tr class="border-b border-[#E5DEC9] text-xs text-[#64748B]">
                    <th class="py-2 pr-3 font-medium">Milestone</th>
                    <th class="py-2 px-3 font-medium">Due Date</th>
                    <th class="py-2 pl-3 font-medium text-right">State</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#EFE8D8]">
                  @for (ms of activeProd()?.milestones || []; track ms.id) {
                    <tr>
                      <td class="py-3 pr-3 font-medium text-[#0E172A]">{{ ms.title }}</td>
                      <td class="py-3 px-3 font-mono-tabular text-xs text-[#475569]">{{ ms.dueDate }}</td>
                      <td class="py-3 pl-3 text-right">
                        <app-status-tag
                          [label]="ms.status"
                          [tone]="ms.status === 'Completed' ? 'approved' : ms.status === 'At Risk' ? 'warning' : 'neutral'"
                        />
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>

          <!-- Review Requests & Render Activity -->
          <div class="xl:col-span-6 bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
            <div class="flex items-center justify-between gap-4">
              <h2 class="font-display text-lg font-semibold text-[#0E172A]">Review Requests & Render Activity</h2>
              <a routerLink="/render-farm" class="text-xs font-medium text-[#1B4D3E] hover:underline whitespace-nowrap shrink-0">
                Render Queue
              </a>
            </div>

            <div class="space-y-3">
              @for (rev of store.activeReviews(); track rev.id) {
                <div class="flex items-center justify-between gap-4 py-2.5 border-b border-[#EFE8D8]">
                  <div class="min-w-0">
                    <a [routerLink]="['/reviews']" class="text-sm font-medium text-[#0E172A] hover:text-[#1B4D3E] truncate block">
                      {{ rev.title }}
                    </a>
                    <div class="text-xs text-[#64748B] font-mono-tabular mt-0.5">
                      {{ rev.currentVersionLabel }} · Tech: {{ rev.technicalValidation }} · Delivery: {{ rev.deliveryApproval }}
                    </div>
                  </div>
                  <app-status-tag
                    [label]="rev.creativeApproval"
                    [tone]="rev.creativeApproval === 'Approved' ? 'approved' : rev.creativeApproval === 'Changes Requested' ? 'warning' : 'active'"
                  />
                </div>
              }

              @for (job of store.activeRenderJobs().slice(0, 3); track job.id) {
                <div class="flex items-center justify-between gap-4 py-2.5 border-b border-[#EFE8D8] last:border-b-0">
                  <div class="min-w-0">
                    <div class="text-sm font-medium text-[#0E172A]">
                      Render {{ job.id }} · {{ job.executionMode }}
                    </div>
                    <div class="text-xs text-[#64748B] font-mono-tabular mt-0.5">
                      Frames {{ job.frameStart }}–{{ job.frameEnd }} · {{ job.renderSettings.resolution }}
                    </div>
                  </div>
                  <app-status-tag
                    [label]="job.state"
                    [tone]="job.state === 'Completed' ? 'approved' : job.state === 'Failed' ? 'danger' : job.state === 'Running' ? 'active' : 'neutral'"
                  />
                </div>
              }
            </div>
          </div>
        </section>

        <!-- Assigned Work & 12-Step Demonstration Tracker -->
        <section class="grid grid-cols-1 xl:grid-cols-12 gap-6">
          <div class="xl:col-span-6 bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
            <div class="flex items-center justify-between gap-4">
              <h2 class="font-display text-lg font-semibold text-[#0E172A]">Active Department Tasks</h2>
              <a routerLink="/shots" class="text-xs font-medium text-[#1B4D3E] hover:underline whitespace-nowrap shrink-0">
                All 12 Shots
              </a>
            </div>
            <div class="overflow-x-auto">
              <table class="w-full text-left border-collapse text-sm">
                <thead>
                  <tr class="border-b border-[#E5DEC9] text-xs text-[#64748B]">
                    <th class="py-2 pr-3 font-medium">Shot / Dept</th>
                    <th class="py-2 px-3 font-medium">Due</th>
                    <th class="py-2 px-3 font-medium text-right">Est / Act</th>
                    <th class="py-2 pl-3 font-medium text-right">Status</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#EFE8D8]">
                  @for (row of highlightedTasks(); track row.taskId) {
                    <tr>
                      <td class="py-2.5 pr-3">
                        <div class="font-medium text-[#0E172A]">{{ row.shotCode }} · {{ row.department }}</div>
                        @if (row.upstreamFlagged) {
                          <div class="text-xs text-amber-800">Upstream asset revision flagged</div>
                        } @else if (row.blockerNote) {
                          <div class="text-xs text-red-800">{{ row.blockerNote }}</div>
                        }
                      </td>
                      <td class="py-2.5 px-3 font-mono-tabular text-xs text-[#475569]">{{ row.dueDate }}</td>
                      <td class="py-2.5 px-3 font-mono-tabular text-xs text-right text-[#475569]">
                        {{ row.estimatedHours }}h / {{ row.actualHours }}h
                      </td>
                      <td class="py-2.5 pl-3 text-right">
                        <app-status-tag
                          [label]="row.reviewStatus"
                          [tone]="row.reviewStatus === 'Approved' ? 'approved' : row.reviewStatus === 'In Review' ? 'active' : 'neutral'"
                        />
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>

          <!-- 12-Step Clockwork Fox End-to-End Pipeline Walkthrough -->
          <div class="xl:col-span-6 bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
            <div class="flex items-center justify-between gap-4">
              <div>
                <h2 class="font-display text-lg font-semibold text-[#0E172A]">The Clockwork Fox — Pipeline Walkthrough</h2>
                <p class="text-xs text-[#64748B] mt-0.5">Live state of all 12 studio demonstration milestones</p>
              </div>
              <a
                routerLink="/deliveries"
                class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg whitespace-nowrap shrink-0"
              >
                <mat-icon class="!text-[15px] !w-[15px] !h-[15px]" aria-hidden="true">inventory_2</mat-icon>
                <span>Deliveries</span>
              </a>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              @for (step of demoChecklist(); track step.num) {
                <a
                  [routerLink]="step.route"
                  class="flex items-center justify-between gap-2 p-2.5 bg-white border border-[#E5DEC9] rounded-lg hover:border-[#9A7B3A] transition-colors"
                >
                  <div class="min-w-0">
                    <span class="font-mono-tabular text-[#85682D] mr-1.5">{{ step.num }}.</span>
                    <span class="font-medium text-[#0E172A] truncate">{{ step.label }}</span>
                  </div>
                  <mat-icon
                    class="!text-[16px] !w-[16px] !h-[16px] shrink-0"
                    [class]="step.done ? 'text-[#1B4D3E]' : 'text-[#9A7B3A]'"
                    aria-hidden="true"
                  >
                    {{ step.done ? 'check_circle' : 'arrow_forward' }}
                  </mat-icon>
                </a>
              }
            </div>
          </div>
        </section>
      </div>
    }
  `,
})
export class StudioHome {
  protected readonly store = inject(StudioStore);

  protected readonly activeProd = this.store.activeProduction;

  protected readonly totalFrames = computed(() =>
    this.store.activeShots().reduce((acc, s) => acc + s.frameCount, 0),
  );

  protected readonly approvedShotsCount = computed(
    () => this.store.activeShots().filter((s) => s.status === 'Approved').length,
  );

  protected readonly pendingReviews = computed(() =>
    this.store.activeReviews().filter((r) => r.creativeApproval !== 'Approved'),
  );

  protected readonly unresolvedNotesCount = computed(() =>
    this.store.activeReviews().reduce(
      (acc, r) => acc + r.comments.filter((c) => !c.resolved).length,
      0,
    ),
  );

  protected readonly completedRendersCount = computed(
    () => this.store.activeRenderJobs().filter((j) => j.state === 'Completed').length,
  );

  protected readonly queuedRendersCount = computed(
    () => this.store.activeRenderJobs().filter((j) => j.state === 'Queued' || j.state === 'Running').length,
  );

  protected readonly onlineWorkersCount = computed(
    () => (this.store.data()?.workers ?? []).filter((w) => w.status === 'Online').length,
  );

  protected readonly highlightedTasks = computed(() => {
    const out: {
      taskId: string;
      shotCode: string;
      department: string;
      dueDate: string;
      estimatedHours: number;
      actualHours: number;
      reviewStatus: string;
      upstreamFlagged: boolean;
      blockerNote?: string;
    }[] = [];
    for (const shot of this.store.activeShots()) {
      for (const t of shot.tasks) {
        if (t.upstreamFlagged || t.blockerNote || t.reviewStatus === 'In Review') {
          out.push({
            taskId: t.id,
            shotCode: shot.code,
            department: t.department,
            dueDate: t.dueDate,
            estimatedHours: t.estimatedHours,
            actualHours: t.actualHours,
            reviewStatus: t.reviewStatus,
            upstreamFlagged: t.upstreamFlagged,
            blockerNote: t.blockerNote,
          });
        }
      }
    }
    return out.slice(0, 7);
  });

  protected readonly demoChecklist = computed(() => {
    const d = this.store.data();
    const hasAnimaticMp4 = (d?.animatics ?? []).some((a) => Boolean(a.mediaUrl));
    const hasApprovedReview = (d?.reviews ?? []).some((r) => r.creativeApproval === 'Approved');
    const hasCompletedRender = (d?.renderJobs ?? []).some((j) => j.state === 'Completed' && j.validationReport?.passed);
    const hasDelivery = (d?.deliveries ?? []).length > 0;
    return [
      {num: '01', label: 'Create Production', route: '/productions', done: (d?.productions.length ?? 0) > 0},
      {num: '02', label: 'Break Down Script', route: '/scripts', done: (d?.breakdownProposals.length ?? 0) > 0},
      {num: '03', label: 'Sequence Storyboard', route: '/storyboards', done: (d?.storyboards[0]?.panels.length ?? 0) >= 12},
      {num: '04', label: 'Export MP4 Animatic', route: '/storyboards', done: hasAnimaticMp4},
      {num: '05', label: 'Publish Blender Asset', route: '/assets', done: (d?.assets[0]?.versions.length ?? 0) >= 2},
      {num: '06', label: 'Link Asset to Shot', route: '/shots', done: (d?.shots[0]?.linkedAssetIds.length ?? 0) > 0},
      {num: '07', label: 'Submit Preview', route: '/reviews', done: (d?.reviews.length ?? 0) > 0},
      {num: '08', label: 'Request Changes & Revise', route: '/reviews', done: (d?.reviews[0]?.versions.length ?? 0) >= 2},
      {num: '09', label: 'Approve Revised Shot', route: '/reviews', done: hasApprovedReview},
      {num: '10', label: 'Run Local Render', route: '/render-farm', done: hasCompletedRender},
      {num: '11', label: 'Validate Render Output', route: '/render-farm', done: hasCompletedRender},
      {num: '12', label: 'Assemble Delivery', route: '/deliveries', done: hasDelivery},
    ];
  });
}
