import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {Router} from '@angular/router';
import {StudioStore} from '../core/studio.store';
import type {Shot, ShotTask} from '../core/studio.models';
import {MediaFrame} from '../shared/media-frame';
import {StatusTag} from '../shared/status-tag';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-shots-workspace',
  imports: [MatIconModule, MediaFrame, StatusTag],
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-2xl font-semibold text-[#0E172A]">Shot Production</h1>
          <p class="text-xs text-[#64748B] mt-1">
            3D: Layout → Animation → Effects → Lighting → Rendering → Compositing → Editorial · 2D: Layout → Rough → Cleanup → Colour → Comp → Editorial
          </p>
        </div>

        <!-- View Switcher: Board | List | Calendar | Timeline -->
        <div class="flex items-center gap-1 p-1 bg-[#EDE5D4] rounded-lg">
          @for (mode of viewModes; track mode) {
            <button
              type="button"
              (click)="viewMode.set(mode)"
              class="px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap"
              [class]="viewMode() === mode ? 'bg-white text-[#0E172A] shadow-sm' : 'text-[#475569] hover:text-[#0E172A]'"
            >
              {{ mode }}
            </button>
          }
        </div>
      </div>

      <!-- Board View -->
      @if (viewMode() === 'Board') {
        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          @for (shot of store.activeShots(); track shot.id) {
            <article class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-4 space-y-3">
              <div class="flex items-start justify-between gap-2">
                <div>
                  <div class="text-xs font-mono-tabular text-[#85682D]">
                    {{ shot.code }} · {{ shot.startFrame }}–{{ shot.endFrame }} ({{ shot.frameCount }}f &#64; {{ shot.fps }}fps)
                  </div>
                  <h2 class="font-display text-base font-semibold text-[#0E172A]">{{ shot.title }}</h2>
                </div>
                <app-status-tag
                  [label]="shot.status"
                  [tone]="shot.status === 'Approved' ? 'approved' : shot.status === 'In Review' ? 'active' : 'neutral'"
                />
              </div>

              <app-media-frame
                [src]="shot.previewUrl"
                [alt]="shot.code"
                [fallbackTitle]="shot.code"
                containerClass="aspect-video rounded-lg"
              />

              <!-- Department Pipeline Strip -->
              <div class="space-y-1.5">
                @for (task of shot.tasks; track task.id) {
                  <div class="flex items-center justify-between gap-2 px-2.5 py-1.5 bg-white border border-[#E5DEC9] rounded text-xs">
                    <div class="min-w-0">
                      <span class="font-medium text-[#0E172A]">{{ task.department }}</span>
                      <span class="text-[#64748B] font-mono-tabular ml-1.5">{{ task.currentVersionLabel }}</span>
                      @if (task.upstreamFlagged) {
                        <span class="block text-[11px] text-amber-800 font-medium">Upstream change flagged</span>
                      }
                      @if (task.blockerNote) {
                        <span class="block text-[11px] text-red-800">{{ task.blockerNote }}</span>
                      }
                    </div>
                    <div class="flex items-center gap-1.5 shrink-0">
                      @if (task.upstreamFlagged) {
                        <button
                          type="button"
                          (click)="clearUpstreamFlag(shot.id, task)"
                          class="px-2 py-1 text-[11px] font-medium bg-amber-50 border border-amber-300 text-amber-900 rounded hover:bg-amber-100"
                        >
                          Clear Flag
                        </button>
                      }
                      <span class="font-mono-tabular text-[11px] text-[#475569]">{{ task.reviewStatus }}</span>
                    </div>
                  </div>
                }
              </div>

              <div class="pt-2 border-t border-[#E5DEC9] flex flex-wrap items-center justify-between gap-2">
                <button
                  type="button"
                  (click)="linkAsset(shot)"
                  class="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium bg-white border border-[#DDD3BC] rounded-lg hover:bg-[#F7F3EA]"
                >
                  <mat-icon class="!text-[14px] !w-[14px] !h-[14px]" aria-hidden="true">link</mat-icon>
                  <span>Link Asset ({{ shot.linkedAssetIds.length }})</span>
                </button>
                <button
                  type="button"
                  (click)="submitPreview(shot)"
                  class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg"
                >
                  <mat-icon class="!text-[14px] !w-[14px] !h-[14px]" aria-hidden="true">rate_review</mat-icon>
                  <span>Submit Preview</span>
                </button>
              </div>
            </article>
          }
        </div>
      }

      <!-- List View -->
      @if (viewMode() === 'List') {
        <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5 overflow-x-auto">
          <table class="w-full text-left border-collapse text-sm">
            <thead>
              <tr class="border-b border-[#E5DEC9] text-xs text-[#64748B]">
                <th class="py-2 pr-3 font-medium">Shot</th>
                <th class="py-2 px-3 font-medium">Frames</th>
                <th class="py-2 px-3 font-medium">Department Tasks</th>
                <th class="py-2 px-3 font-medium text-right">Est / Actual</th>
                <th class="py-2 pl-3 font-medium text-right">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#EFE8D8]">
              @for (shot of store.activeShots(); track shot.id) {
                <tr>
                  <td class="py-3 pr-3">
                    <div class="font-semibold text-[#0E172A]">{{ shot.code }} — {{ shot.title }}</div>
                    <div class="text-xs text-[#64748B]">{{ shot.linkedAssetIds.length }} linked assets</div>
                  </td>
                  <td class="py-3 px-3 font-mono-tabular text-xs text-[#475569]">
                    {{ shot.startFrame }}–{{ shot.endFrame }} ({{ shot.frameCount }}f)
                  </td>
                  <td class="py-3 px-3 text-xs text-[#334155]">
                    {{ approvedTaskCount(shot) }}/{{ shot.tasks.length }} approved
                  </td>
                  <td class="py-3 px-3 font-mono-tabular text-xs text-right text-[#475569]">
                    {{ totalEst(shot) }}h / {{ totalActual(shot) }}h
                  </td>
                  <td class="py-3 pl-3 text-right">
                    <app-status-tag
                      [label]="shot.status"
                      [tone]="shot.status === 'Approved' ? 'approved' : shot.status === 'In Review' ? 'active' : 'neutral'"
                    />
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }

      <!-- Calendar View -->
      @if (viewMode() === 'Calendar') {
        <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
          <h2 class="font-display text-lg font-semibold text-[#0E172A]">Upcoming Department Due Dates</h2>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            @for (group of calendarGroups(); track group.date) {
              <div class="bg-white border border-[#E5DEC9] rounded-lg p-4 space-y-2">
                <div class="font-mono-tabular text-xs font-semibold text-[#85682D] border-b border-[#EFE8D8] pb-1.5">
                  {{ group.date }}
                </div>
                @for (item of group.items; track item.taskId) {
                  <div class="text-xs flex items-center justify-between gap-2">
                    <span class="text-[#0E172A] font-medium">{{ item.shotCode }} · {{ item.department }}</span>
                    <span class="text-[#64748B]">{{ item.reviewStatus }}</span>
                  </div>
                }
              </div>
            }
          </div>
        </div>
      }

      <!-- Timeline View -->
      @if (viewMode() === 'Timeline') {
        <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
          <div class="flex items-center justify-between gap-4">
            <h2 class="font-display text-lg font-semibold text-[#0E172A]">Editorial Frame Timeline (1,440 Frames · 60.00s)</h2>
            <span class="font-mono-tabular text-xs text-[#64748B]">24 fps locked</span>
          </div>
          <div class="space-y-2.5">
            @for (shot of store.activeShots(); track shot.id) {
              <div class="space-y-1">
                <div class="flex items-center justify-between text-xs font-mono-tabular">
                  <span class="font-semibold text-[#0E172A]">{{ shot.code }} · {{ shot.title }}</span>
                  <span class="text-[#475569]">f{{ shot.startFrame }}–f{{ shot.endFrame }} ({{ shot.frameCount }}f)</span>
                </div>
                <div class="w-full h-5 bg-[#EDE5D4] rounded overflow-hidden relative">
                  <div
                    class="h-full rounded transition-all"
                    [style.margin-left.%]="(shot.startFrame / 1440) * 100"
                    [style.width.%]="(shot.frameCount / 1440) * 100"
                    [class]="shot.status === 'Approved' ? 'bg-[#1B4D3E]' : shot.status === 'In Review' ? 'bg-[#9A7B3A]' : 'bg-[#0E172A]'"
                  ></div>
                </div>
              </div>
            }
          </div>
        </div>
      }
    </div>
  `,
})
export class ShotsWorkspace {
  protected readonly store = inject(StudioStore);
  private readonly router = inject(Router);
  protected readonly viewModes = ['Board', 'List', 'Calendar', 'Timeline'] as const;
  protected readonly viewMode = signal<'Board' | 'List' | 'Calendar' | 'Timeline'>('Board');

  protected approvedTaskCount(shot: Shot): number {
    return shot.tasks.filter((t) => t.reviewStatus === 'Approved').length;
  }

  protected totalEst(shot: Shot): number {
    return shot.tasks.reduce((a, t) => a + t.estimatedHours, 0);
  }

  protected totalActual(shot: Shot): number {
    return shot.tasks.reduce((a, t) => a + t.actualHours, 0);
  }

  protected readonly calendarGroups = computed(() => {
    const map = new Map<string, {taskId: string; shotCode: string; department: string; reviewStatus: string}[]>();
    for (const s of this.store.activeShots()) {
      for (const t of s.tasks) {
        const list = map.get(t.dueDate) ?? [];
        list.push({taskId: t.id, shotCode: s.code, department: t.department, reviewStatus: t.reviewStatus});
        map.set(t.dueDate, list);
      }
    }
    return Array.from(map.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(0, 9)
      .map(([date, items]) => ({date, items}));
  });

  protected async clearUpstreamFlag(shotId: string, task: ShotTask): Promise<void> {
    await this.store.mutate(
      'PATCH',
      `/api/shots/${shotId}/tasks/${task.id}`,
      {upstreamFlagged: false},
      `Supervisor acknowledged upstream revision on ${task.department}; approved output retained.`,
    );
  }

  protected async linkAsset(shot: Shot): Promise<void> {
    const firstAsset = this.store.activeAssets()[0];
    if (!firstAsset) return;
    await this.store.mutate(
      'POST',
      `/api/shots/${shot.id}/link-asset`,
      {assetId: firstAsset.id},
      `Linked ${firstAsset.code} to ${shot.code}.`,
    );
  }

  protected async submitPreview(shot: Shot): Promise<void> {
    const res = await this.store.mutate(
      'POST',
      `/api/reviews/${shot.id}/submit-preview`,
      {notes: `Submitted preview for ${shot.code} from Shot Production board.`},
      `Submitted ${shot.code} preview to Dailies Review.`,
    );
    if (res) {
      void this.router.navigate(['/reviews']);
    }
  }
}
