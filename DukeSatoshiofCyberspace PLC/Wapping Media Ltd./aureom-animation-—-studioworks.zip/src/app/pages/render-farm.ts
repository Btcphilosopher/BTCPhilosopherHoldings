import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {StudioStore} from '../core/studio.store';
import {StatusTag} from '../shared/status-tag';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-render-farm-workspace',
  imports: [ReactiveFormsModule, MatIconModule, StatusTag],
  template: `
    @if (store.data(); as d) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="font-display text-2xl font-semibold text-[#0E172A]">Render Queue & Workers</h1>
            <p class="text-xs text-[#64748B] mt-1">
              Queued → Assigned → Running → Validating → Completed · Leases, idempotency keys, bounded retries & untrusted workload isolation.
            </p>
          </div>
          <button
            type="button"
            (click)="showSubmit.set(!showSubmit())"
            class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg whitespace-nowrap shrink-0"
          >
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">queue_play_next</mat-icon>
            <span>{{ showSubmit() ? 'Close' : 'Submit Render Job' }}</span>
          </button>
        </div>

        @if (showSubmit()) {
          <form
            [formGroup]="jobForm"
            (ngSubmit)="submitJob()"
            class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4"
          >
            <h2 class="font-display text-lg font-semibold text-[#0E172A]">Submit Scene to Render Queue</h2>
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label for="rf-shot" class="block text-xs font-medium text-[#334155] mb-1">Shot</label>
                <select id="rf-shot" formControlName="shotId" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg">
                  @for (s of store.activeShots(); track s.id) {
                    <option [value]="s.id">{{ s.code }} — {{ s.title }}</option>
                  }
                </select>
              </div>
              <div>
                <label for="rf-mode" class="block text-xs font-medium text-[#334155] mb-1">Execution Mode</label>
                <select id="rf-mode" formControlName="executionMode" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg">
                  <option value="Local Worker">Local Worker (Real FFmpeg/Blender)</option>
                  <option value="Simulated Farm">Simulated Farm Node</option>
                </select>
              </div>
              <div>
                <label for="rf-start" class="block text-xs font-medium text-[#334155] mb-1">Frame Start</label>
                <input id="rf-start" formControlName="frameStart" type="number" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg font-mono-tabular" />
              </div>
              <div>
                <label for="rf-end" class="block text-xs font-medium text-[#334155] mb-1">Frame End</label>
                <input id="rf-end" formControlName="frameEnd" type="number" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg font-mono-tabular" />
              </div>
            </div>
            <div class="flex justify-end">
              <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] rounded-lg">
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">send</mat-icon>
                <span>Enqueue Render</span>
              </button>
            </div>
          </form>
        }

        <!-- Worker Fleet: Clearly Separated Local vs Simulated vs Cloud Placeholder -->
        <section class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5 space-y-3">
          <h2 class="font-display text-lg font-semibold text-[#0E172A]">Worker Fleet & Isolation Policy</h2>
          <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
            @for (w of d.workers; track w.id) {
              <div class="bg-white border border-[#E5DEC9] rounded-lg p-4 space-y-2 text-xs">
                <div class="flex items-start justify-between gap-2">
                  <div>
                    <div class="font-mono-tabular text-[#85682D] font-semibold">{{ w.executionMode }}</div>
                    <div class="font-medium text-sm text-[#0E172A]">{{ w.name }}</div>
                  </div>
                  <app-status-tag
                    [label]="w.status"
                    [tone]="w.status === 'Online' ? 'approved' : w.status === 'Busy' ? 'active' : 'neutral'"
                  />
                </div>
                <div class="text-[#475569]">{{ w.capabilities.join(' · ') }}</div>
                <div class="text-[#334155] bg-[#F7F3EA] p-2 rounded border border-[#E5DEC9]">
                  <strong>Isolation:</strong> {{ w.isolationPolicy }} · RAM {{ w.maxMemoryMb }}MB · Net: {{ w.networkRestricted ? 'Disabled' : 'Open' }}
                </div>
              </div>
            }
          </div>
        </section>

        <!-- Render Jobs List -->
        <section class="space-y-4">
          @for (job of store.activeRenderJobs(); track job.id) {
            <article class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5 space-y-4">
              <div class="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div class="font-mono-tabular text-xs text-[#85682D]">
                    {{ job.id }} · {{ job.executionMode }} · Idempotency: {{ job.idempotencyKey }}
                  </div>
                  <h3 class="font-display text-lg font-semibold text-[#0E172A]">
                    Shot {{ job.shotId }} ({{ job.sceneVersionLabel }}) · Frames {{ job.frameStart }}–{{ job.frameEnd }}
                  </h3>
                  <div class="text-xs text-[#475569] mt-0.5 font-mono-tabular">
                    {{ job.renderSettings.engine }} · {{ job.renderSettings.resolution }} · {{ job.renderSettings.colourConfig }} · Attempt {{ job.attemptCount }}/{{ job.maxRetries }}
                  </div>
                </div>

                <div class="flex flex-wrap items-center gap-2">
                  <app-status-tag
                    [label]="job.state"
                    [tone]="job.state === 'Completed' ? 'approved' : job.state === 'Failed' || job.state === 'Cancelled' ? 'danger' : job.state === 'Running' || job.state === 'Validating' ? 'active' : 'neutral'"
                  />
                  @if (job.state === 'Queued') {
                    <button
                      type="button"
                      (click)="runLocal(job.id)"
                      [disabled]="runningJobId() === job.id"
                      class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg"
                    >
                      <mat-icon class="!text-[15px] !w-[15px] !h-[15px]" aria-hidden="true">play_arrow</mat-icon>
                      <span>{{ runningJobId() === job.id ? 'Executing...' : 'Execute & Validate Now' }}</span>
                    </button>
                    <button
                      type="button"
                      (click)="cancelJob(job.id)"
                      class="px-3 py-1.5 text-xs font-medium bg-white border border-[#DDD3BC] rounded-lg hover:bg-[#F7F3EA]"
                    >
                      Cancel
                    </button>
                  }
                  @if (job.state === 'Failed' || job.state === 'Cancelled') {
                    <button
                      type="button"
                      (click)="retryJob(job.id)"
                      class="px-3 py-1.5 text-xs font-medium bg-white border border-[#9A7B3A] rounded-lg"
                    >
                      Retry Job
                    </button>
                  }
                </div>
              </div>

              <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
                <div class="lg:col-span-7 bg-[#0E172A] text-[#E2E8F0] rounded-lg p-3.5 font-mono text-xs space-y-1 max-h-44 overflow-y-auto">
                  @for (line of job.logs; track $index) {
                    <div>{{ line }}</div>
                  }
                </div>

                <div class="lg:col-span-5 space-y-2">
                  @if (job.validationReport; as rep) {
                    <div class="bg-white border border-[#E5DEC9] rounded-lg p-3 text-xs font-mono-tabular space-y-1">
                      <div class="font-semibold text-[#1B4D3E]">
                        Validation {{ rep.passed ? 'PASSED' : 'FAILED' }} ({{ rep.codec }})
                      </div>
                      <div>Frames: {{ rep.frameCountDetected }} · Res: {{ rep.resolutionDetected }}</div>
                      <div class="truncate text-[#64748B]">SHA-256: {{ job.outputHash }}</div>
                    </div>
                  }
                  @if (job.outputMediaUrl && job.outputMediaUrl.endsWith('.mp4')) {
                    <video [src]="job.outputMediaUrl" controls class="w-full aspect-video rounded-lg bg-black border border-[#DDD3BC]"></video>
                  }
                </div>
              </div>
            </article>
          }
        </section>
      </div>
    }
  `,
})
export class RenderFarmWorkspace {
  protected readonly store = inject(StudioStore);
  protected readonly showSubmit = signal(false);
  protected readonly runningJobId = signal<string | null>(null);

  protected readonly jobForm = new FormGroup({
    shotId: new FormControl('shot_010', [Validators.required]),
    executionMode: new FormControl<'Local Worker' | 'Simulated Farm'>('Local Worker'),
    frameStart: new FormControl(1, [Validators.required, Validators.min(1)]),
    frameEnd: new FormControl(36, [Validators.required, Validators.min(1)]),
  });

  protected async submitJob(): Promise<void> {
    if (this.jobForm.invalid) return;
    const v = this.jobForm.getRawValue();
    const res = await this.store.mutate('POST', '/api/render-jobs', v, 'Enqueued render job.');
    if (res) {
      this.showSubmit.set(false);
    }
  }

  protected async runLocal(jobId: string): Promise<void> {
    this.runningJobId.set(jobId);
    try {
      await this.store.mutate(
        'POST',
        `/api/render-jobs/${jobId}/run-local`,
        {},
        'Render completed and validated with ffprobe.',
      );
    } finally {
      this.runningJobId.set(null);
    }
  }

  protected async cancelJob(jobId: string): Promise<void> {
    await this.store.mutate('POST', `/api/render-jobs/${jobId}/cancel`, {}, 'Render job cancelled.');
  }

  protected async retryJob(jobId: string): Promise<void> {
    await this.store.mutate('POST', `/api/render-jobs/${jobId}/retry`, {}, 'Render job re-queued.');
  }
}
