import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {StudioStore} from '../core/studio.store';
import type {DeliveryPackageState} from '../core/studio.models';
import {StatusTag} from '../shared/status-tag';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-deliveries-workspace',
  imports: [MatIconModule, StatusTag],
  template: `
    @if (store.data(); as d) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="font-display text-2xl font-semibold text-[#0E172A]">Editorial, Audio & Deliveries</h1>
            <p class="text-xs text-[#64748B] mt-1">
              Versioned delivery presets, checksummed master packages, credits, SRT subtitles, and strict Generated vs Reviewed vs Accepted lifecycle.
            </p>
          </div>
          <button
            type="button"
            (click)="generatePackage()"
            [disabled]="generating()"
            class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg whitespace-nowrap shrink-0"
          >
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">inventory_2</mat-icon>
            <span>{{ generating() ? 'Assembling Package...' : 'Assemble Delivery Package' }}</span>
          </button>
        </div>

        <!-- Versioned Delivery Presets -->
        <section class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5 space-y-3">
          <h2 class="font-display text-base font-semibold text-[#0E172A]">Versioned Delivery Presets</h2>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            @for (spec of d.deliverySpecs; track spec.id) {
              <div class="bg-white border border-[#E5DEC9] rounded-lg p-4 text-xs space-y-1 font-mono-tabular">
                <div class="font-sans font-semibold text-sm text-[#0E172A]">{{ spec.name }} (v{{ spec.version }})</div>
                <div class="text-[#334155]">{{ spec.resolution }} · {{ spec.fps }} fps · {{ spec.codec }}</div>
                <div class="text-[#475569]">Colour: {{ spec.colourSpace }} · Audio: {{ spec.audioSampleRateHz }} Hz {{ spec.audioChannels }}</div>
                <div class="text-[#64748B]">Subtitles: {{ spec.subtitleFormat }}</div>
              </div>
            }
          </div>
        </section>

        <!-- Delivery Packages -->
        <section class="space-y-4">
          @for (pkg of d.deliveries; track pkg.id) {
            <article class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
              <div class="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div class="font-mono-tabular text-xs text-[#85682D]">
                    {{ pkg.packageName }} ({{ pkg.versionLabel }}) · Created {{ pkg.createdAt.slice(0, 10) }} by {{ pkg.createdBy }}
                  </div>
                  <h3 class="font-display text-xl font-semibold text-[#0E172A] mt-0.5">
                    Checksum: <span class="font-mono-tabular text-sm">{{ pkg.mediaChecksum.slice(0, 20) }}...</span>
                  </h3>
                </div>

                <div class="flex flex-wrap items-center gap-2">
                  <app-status-tag
                    [label]="pkg.lifecycleState"
                    [tone]="pkg.lifecycleState === 'Accepted by Distributor' ? 'approved' : pkg.lifecycleState === 'Passed Review' ? 'active' : 'neutral'"
                  />
                  @if (pkg.lifecycleState === 'Generated') {
                    <button
                      type="button"
                      (click)="transition(pkg.id, 'Passed Review')"
                      class="px-3 py-1.5 text-xs font-semibold bg-white border border-[#1B4D3E] text-[#1B4D3E] rounded-lg hover:bg-[#F7F3EA]"
                    >
                      Pass Studio Review
                    </button>
                  }
                  @if (pkg.lifecycleState === 'Passed Review') {
                    <button
                      type="button"
                      (click)="transition(pkg.id, 'Accepted by Distributor')"
                      class="px-3 py-1.5 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg"
                    >
                      Mark Accepted by Distributor
                    </button>
                  }
                </div>
              </div>

              <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 text-xs">
                <div class="bg-white border border-[#E5DEC9] rounded-lg p-4 space-y-2">
                  <div class="font-semibold text-[#0E172A]">Exact Version Manifest</div>
                  <div class="font-mono-tabular space-y-1 text-[#475569]">
                    @for (av of pkg.manifest.assetVersions; track av.code) {
                      <div>{{ av.code }} {{ av.versionLabel }} ({{ av.contentHash.slice(0, 10) }})</div>
                    }
                    <div class="pt-1 border-t border-[#EFE8D8]">
                      {{ pkg.manifest.shotVersions.length }} approved shots locked
                    </div>
                  </div>
                </div>

                <div class="bg-white border border-[#E5DEC9] rounded-lg p-4 space-y-2">
                  <div class="font-semibold text-[#0E172A]">Technical Validation & Rights</div>
                  <div class="text-[#334155]">{{ pkg.technicalReport.summary }}</div>
                  <div class="font-mono-tabular text-[#475569]">
                    Director: {{ pkg.rightsAndApprovalRefs.creativeDirectorApprovedBy }}<br />
                    QC: {{ pkg.rightsAndApprovalRefs.technicalValidatedBy }}<br />
                    Rights: {{ pkg.rightsAndApprovalRefs.rightsClearanceCount }} verified, {{ pkg.rightsAndApprovalRefs.missingRightsCount }} pending
                  </div>
                </div>

                <div class="bg-white border border-[#E5DEC9] rounded-lg p-4 space-y-2">
                  <div class="font-semibold text-[#0E172A]">Credits & Subtitles (SRT)</div>
                  <pre class="text-[11px] font-mono text-[#475569] whitespace-pre-wrap">{{ pkg.creditsText }}</pre>
                  <pre class="text-[11px] font-mono text-[#64748B] whitespace-pre-wrap border-t border-[#EFE8D8] pt-2">{{ pkg.subtitlesSrt }}</pre>
                </div>
              </div>
            </article>
          }
        </section>
      </div>
    }
  `,
})
export class DeliveriesWorkspace {
  protected readonly store = inject(StudioStore);
  protected readonly generating = signal(false);

  protected async generatePackage(): Promise<void> {
    this.generating.set(true);
    try {
      await this.store.mutate(
        'POST',
        '/api/deliveries/generate',
        {productionId: this.store.activeProduction()?.id},
        'Assembled checksummed delivery package (state: Generated).',
      );
    } finally {
      this.generating.set(false);
    }
  }

  protected async transition(id: string, lifecycleState: DeliveryPackageState): Promise<void> {
    await this.store.mutate(
      'POST',
      `/api/deliveries/${id}/transition`,
      {lifecycleState},
      `Delivery package updated to ${lifecycleState}.`,
    );
  }
}
