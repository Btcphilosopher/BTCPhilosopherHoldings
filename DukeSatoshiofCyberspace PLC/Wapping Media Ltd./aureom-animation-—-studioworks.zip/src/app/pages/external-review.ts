import {HttpClient} from '@angular/common/http';
import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {firstValueFrom} from 'rxjs';
import type {ReviewComment, ReviewMediaVersion} from '../core/studio.models';

interface ExternalReviewPayload {
  link: {label: string; allowDownload: boolean; expiresAt: string};
  review: {
    id: string;
    title: string;
    currentVersionLabel: string;
    versions: ReviewMediaVersion[];
    comments: ReviewComment[];
  };
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-external-review-page',
  template: `
    <div class="max-w-4xl mx-auto p-6 space-y-6">
      @if (errorMsg(); as err) {
        <div class="bg-red-50 border border-red-300 rounded-xl p-6 text-sm text-red-900">
          {{ err }}
        </div>
      } @else if (payload(); as p) {
        <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
          <div class="flex flex-wrap items-center justify-between gap-4 border-b border-[#E5DEC9] pb-4">
            <div>
              <div class="text-xs font-mono-tabular text-[#85682D]">External Screening · {{ p.link.label }}</div>
              <h1 class="font-display text-2xl font-semibold text-[#0E172A]">{{ p.review.title }}</h1>
            </div>
            <div class="text-xs font-mono-tabular text-[#475569]">
              Expires {{ p.link.expiresAt.slice(0, 10) }} · Downloads: {{ p.link.allowDownload ? 'Permitted' : 'Disabled' }}
            </div>
          </div>

          @if (latestMedia(p.review.versions); as media) {
            <img
              [src]="media.mediaUrl"
              [alt]="p.review.title"
              referrerpolicy="no-referrer"
              class="w-full aspect-video object-cover rounded-lg border border-[#DDD3BC]"
            />
            @if (p.link.allowDownload) {
              <a [href]="media.mediaUrl" download class="inline-block px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] rounded-lg">
                Download Approved Screening Media
              </a>
            }
          }

          <div class="space-y-2 pt-2">
            <h2 class="font-display text-base font-semibold text-[#0E172A]">Screening Notes</h2>
            @for (c of p.review.comments; track c.id) {
              <div class="p-3 bg-white border border-[#E5DEC9] rounded-lg text-xs">
                <span class="font-mono-tabular font-semibold text-[#1B4D3E]">F{{ c.frameNumber }}</span>
                <span class="ml-2 text-[#0E172A]">{{ c.body }}</span>
              </div>
            }
          </div>
        </div>
      }
    </div>
  `,
})
export class ExternalReviewPage implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly http = inject(HttpClient);
  protected readonly payload = signal<ExternalReviewPayload | null>(null);
  protected readonly errorMsg = signal<string | null>(null);

  public async ngOnInit(): Promise<void> {
    const token = this.route.snapshot.paramMap.get('token') || '';
    try {
      const res = await firstValueFrom(
        this.http.get<ExternalReviewPayload>(`/api/external-reviews/${encodeURIComponent(token)}`),
      );
      this.payload.set(res);
    } catch {
      this.errorMsg.set('This external screening link is invalid, revoked, or expired.');
    }
  }

  protected latestMedia(versions: ReviewMediaVersion[]): ReviewMediaVersion | null {
    return versions[versions.length - 1] ?? null;
  }
}
