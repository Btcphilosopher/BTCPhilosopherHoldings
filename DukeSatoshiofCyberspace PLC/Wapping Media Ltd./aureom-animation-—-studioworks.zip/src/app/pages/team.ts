import {ChangeDetectionStrategy, Component, computed, inject} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {StudioStore} from '../core/studio.store';
import {StatusTag} from '../shared/status-tag';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-team-workspace',
  imports: [ReactiveFormsModule, MatIconModule, StatusTag],
  template: `
    @if (store.data(); as d) {
      <div class="space-y-6">
        <div>
          <h1 class="font-display text-2xl font-semibold text-[#0E172A]">Team, Timesheets & Rights</h1>
          <p class="text-xs text-[#64748B] mt-1">
            Assignments, crew availability, timesheets, contributor agreements, music licences, and missing documentation flags.
          </p>
        </div>

        <!-- Missing Rights Alert Banner (if any) -->
        @if (missingRights().length > 0) {
          <div class="bg-amber-50 border border-amber-300 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
            <div class="text-xs text-amber-950">
              <strong>Rights Clearance Alert:</strong> {{ missingRights().length }} agreement(s) require signed documentation before distributor acceptance.
              Note: StudioWorks tracks compliance documentation and does not independently establish legal ownership.
            </div>
          </div>
        }

        <!-- Crew Availability Table -->
        <section class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
          <h2 class="font-display text-lg font-semibold text-[#0E172A]">Studio Crew & Availability</h2>
          <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-sm">
              <thead>
                <tr class="border-b border-[#E5DEC9] text-xs text-[#64748B]">
                  <th class="py-2 pr-3 font-medium">Member</th>
                  <th class="py-2 px-3 font-medium">Role / Dept</th>
                  <th class="py-2 px-3 font-medium text-right">Weekly Cap</th>
                  <th class="py-2 px-3 font-medium text-right">Day Rate</th>
                  <th class="py-2 pl-3 font-medium">Availability & Leave Dates</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#EFE8D8]">
                @for (m of d.team; track m.id) {
                  <tr>
                    <td class="py-3 pr-3">
                      <div class="font-medium text-[#0E172A]">{{ m.name }}</div>
                      <div class="text-xs text-[#64748B]">{{ m.email }}</div>
                    </td>
                    <td class="py-3 px-3 text-xs text-[#334155]">{{ m.role }} · {{ m.department }}</td>
                    <td class="py-3 px-3 font-mono-tabular text-xs text-right text-[#475569]">{{ m.weeklyCapacityHours }}h</td>
                    <td class="py-3 px-3 font-mono-tabular text-xs text-right text-[#0E172A]">£{{ m.dayRateGbp }}</td>
                    <td class="py-3 pl-3 text-xs text-[#475569]">
                      <div>{{ m.availabilityNotes }}</div>
                      @if (m.unavailableDates.length > 0) {
                        <div class="font-mono-tabular text-[11px] text-amber-800 mt-0.5">
                          Unavailable: {{ m.unavailableDates.join(', ') }}
                        </div>
                      }
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </section>

        <!-- Timesheets & Rights Split -->
        <div class="grid grid-cols-1 xl:grid-cols-12 gap-6">
          <!-- Timesheets -->
          <section class="xl:col-span-6 bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
            <h2 class="font-display text-lg font-semibold text-[#0E172A]">Timesheet Log</h2>

            <form [formGroup]="timesheetForm" (ngSubmit)="logTimesheet()" class="grid grid-cols-1 sm:grid-cols-4 gap-2 bg-white border border-[#E5DEC9] rounded-lg p-3">
              <select formControlName="department" class="px-2.5 py-1.5 text-xs bg-[#F7F3EA] border border-[#DDD3BC] rounded">
                <option value="Animation">Animation</option>
                <option value="Lighting">Lighting</option>
                <option value="Layout">Layout</option>
                <option value="Production">Production</option>
              </select>
              <input formControlName="hours" type="number" step="0.5" placeholder="Hours" class="px-2.5 py-1.5 text-xs bg-[#F7F3EA] border border-[#DDD3BC] rounded font-mono-tabular" />
              <input formControlName="notes" type="text" placeholder="Task notes" class="px-2.5 py-1.5 text-xs bg-[#F7F3EA] border border-[#DDD3BC] rounded" />
              <button type="submit" class="inline-flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-[#1B4D3E] rounded">
                <mat-icon class="!text-[14px] !w-[14px] !h-[14px]" aria-hidden="true">schedule</mat-icon>
                <span>Log Hours</span>
              </button>
            </form>

            <div class="divide-y divide-[#EFE8D8]">
              @for (ts of d.timesheets; track ts.id) {
                <div class="py-2.5 flex items-center justify-between gap-4 text-xs">
                  <div>
                    <div class="font-medium text-[#0E172A]">{{ memberName(ts.memberId) }} · {{ ts.department }}</div>
                    <div class="text-[#475569]">{{ ts.notes }}</div>
                  </div>
                  <div class="font-mono-tabular text-right shrink-0">
                    <div class="font-semibold text-[#0E172A]">{{ ts.hours }}h</div>
                    <div class="text-[#64748B]">{{ ts.date }}</div>
                  </div>
                </div>
              }
            </div>
          </section>

          <!-- Rights & Permissions -->
          <section class="xl:col-span-6 bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
            <h2 class="font-display text-lg font-semibold text-[#0E172A]">Contributor Agreements & Licences</h2>
            <div class="space-y-3">
              @for (r of d.rights; track r.id) {
                <div class="bg-white border border-[#E5DEC9] rounded-lg p-4 space-y-2 text-xs">
                  <div class="flex items-start justify-between gap-2">
                    <div>
                      <div class="font-mono-tabular text-[#85682D]">{{ r.category }} · {{ r.referenceCode }}</div>
                      <div class="font-semibold text-sm text-[#0E172A]">{{ r.subjectName }}</div>
                    </div>
                    <app-status-tag
                      [label]="r.status"
                      [tone]="r.status === 'Verified' ? 'approved' : r.status === 'Missing Documentation' ? 'warning' : 'danger'"
                    />
                  </div>
                  <div class="text-[#334155]">Permitted uses: {{ r.permittedUses }}</div>
                  <div class="text-[#64748B]">{{ r.notes }}</div>
                  @if (r.status !== 'Verified') {
                    <button
                      type="button"
                      (click)="markVerified(r.id)"
                      class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-[#1B4D3E] rounded-lg"
                    >
                      <mat-icon class="!text-[14px] !w-[14px] !h-[14px]" aria-hidden="true">verified</mat-icon>
                      <span>Record Signed Clearance</span>
                    </button>
                  }
                </div>
              }
            </div>
          </section>
        </div>
      </div>
    }
  `,
})
export class TeamWorkspace {
  protected readonly store = inject(StudioStore);

  protected readonly timesheetForm = new FormGroup({
    department: new FormControl('Animation', [Validators.required]),
    hours: new FormControl(4, [Validators.required, Validators.min(0.25)]),
    notes: new FormControl('Shot cleanup & polish', [Validators.required]),
  });

  protected readonly missingRights = computed(() =>
    (this.store.data()?.rights ?? []).filter((r) => r.status !== 'Verified'),
  );

  protected memberName(id: string): string {
    return this.store.data()?.team.find((m) => m.id === id)?.name ?? id;
  }

  protected async logTimesheet(): Promise<void> {
    if (this.timesheetForm.invalid) return;
    const v = this.timesheetForm.getRawValue();
    await this.store.mutate(
      'POST',
      '/api/timesheets',
      {
        productionId: this.store.activeProduction()?.id,
        department: v.department,
        hours: v.hours,
        notes: v.notes,
      },
      `Logged ${v.hours}h to ${v.department}.`,
    );
  }

  protected async markVerified(rightsId: string): Promise<void> {
    await this.store.mutate(
      'PATCH',
      `/api/rights/${rightsId}`,
      {status: 'Verified', notes: 'Signed Equity performer release verified and archived.'},
      'Rights record marked Verified.',
    );
  }
}
