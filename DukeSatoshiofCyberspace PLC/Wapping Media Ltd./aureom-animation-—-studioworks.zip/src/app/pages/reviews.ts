import {
  ChangeDetectionStrategy,
  Component,
  computed,
  type ElementRef,
  inject,
  OnDestroy,
  signal,
  viewChild,
} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {StudioStore} from '../core/studio.store';
import type {ReviewComment, ReviewItem} from '../core/studio.models';
import {StatusTag} from '../shared/status-tag';

interface StrokePoint {
  x: number;
  y: number;
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-reviews-workspace',
  imports: [MatIconModule, StatusTag],
  host: {
    '(window:keydown)': 'handleKey($event)',
  },
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-2xl font-semibold text-[#0E172A]">Media Review & Dailies</h1>
          <p class="text-xs text-[#64748B] mt-1">
            Frame stepping (←/→), playback speed, frame-locked notes, drawing annotations, version comparison, and separate approval gates.
          </p>
        </div>
        <div class="flex flex-wrap items-center gap-2">
          @for (rev of store.activeReviews(); track rev.id) {
            <button
              type="button"
              (click)="selectReview(rev)"
              class="px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors"
              [class]="activeReview().id === rev.id ? 'bg-[#0E172A] text-white border-[#0E172A]' : 'bg-white text-[#334155] border-[#DDD3BC] hover:bg-[#F7F3EA]'"
            >
              {{ rev.title }}
            </button>
          }
        </div>
      </div>

      @if (activeReview(); as rev) {
        <div class="grid grid-cols-1 xl:grid-cols-12 gap-6">
          <!-- Review Player + Canvas Drawing Overlay -->
          <div class="xl:col-span-8 bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5 space-y-4">
            <div class="flex flex-wrap items-center justify-between gap-3">
              <div class="flex items-center gap-2">
                <span class="font-mono-tabular text-xs font-semibold text-[#0E172A]">
                  Version {{ activeVersionLabel() }}
                </span>
                <span class="text-xs text-[#64748B]">·</span>
                <span class="font-mono-tabular text-xs text-[#475569]">
                  Frame {{ currentFrame() }} / {{ totalFrames() }} &#64; {{ activeMediaVersion()?.fps || 24 }} fps
                </span>
              </div>

              <div class="flex items-center gap-2">
                <button
                  type="button"
                  (click)="compareMode.set(!compareMode())"
                  [disabled]="rev.versions.length < 2"
                  class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-white border border-[#DDD3BC] rounded-lg disabled:opacity-40 hover:bg-[#F7F3EA]"
                >
                  <mat-icon class="!text-[15px] !w-[15px] !h-[15px]" aria-hidden="true">compare</mat-icon>
                  <span>{{ compareMode() ? 'Single View' : 'Compare Versions' }}</span>
                </button>
                <button
                  type="button"
                  (click)="submitRevision(rev)"
                  class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg"
                >
                  <mat-icon class="!text-[15px] !w-[15px] !h-[15px]" aria-hidden="true">upgrade</mat-icon>
                  <span>Publish Revision</span>
                </button>
              </div>
            </div>

            <!-- Viewport: Single Annotated Frame OR Side-by-Side Comparison -->
            @if (compareMode() && rev.versions.length >= 2) {
              <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                @for (ver of rev.versions.slice(-2); track ver.versionLabel) {
                  <div class="bg-[#0E172A] rounded-lg p-2 space-y-1">
                    <div class="text-xs font-mono-tabular text-[#F7F3EA] px-1">
                      {{ ver.versionLabel }} · {{ ver.submittedBy }}
                    </div>
                    <img
                      [src]="ver.mediaUrl"
                      [alt]="ver.versionLabel"
                      referrerpolicy="no-referrer"
                      class="w-full aspect-video object-cover rounded"
                    />
                  </div>
                }
              </div>
            } @else {
              <div class="relative w-full aspect-video bg-[#0E172A] rounded-lg overflow-hidden border border-[#DDD3BC]">
                <img
                  [src]="activeMediaVersion()?.mediaUrl"
                  [alt]="rev.title"
                  referrerpolicy="no-referrer"
                  class="w-full h-full object-cover select-none pointer-events-none"
                />
                <canvas
                  #drawCanvas
                  width="960"
                  height="540"
                  (pointerdown)="startStroke($event)"
                  (pointermove)="moveStroke($event)"
                  (pointerup)="endStroke()"
                  (pointerleave)="endStroke()"
                  class="absolute inset-0 w-full h-full cursor-crosshair touch-none"
                ></canvas>
                <div class="absolute bottom-3 left-3 px-2.5 py-1 bg-[#0E172A]/85 text-[#F7F3EA] font-mono-tabular text-xs rounded">
                  F{{ currentFrame() }} · {{ activeVersionLabel() }} · {{ playbackSpeed() }}x
                </div>
              </div>
            }

            <!-- Transport, Frame Stepping & Drawing Controls -->
            <div class="flex flex-wrap items-center justify-between gap-3 pt-1">
              <div class="flex flex-wrap items-center gap-1.5">
                <button type="button" (click)="stepFrame(-5)" class="px-2.5 py-1.5 text-xs font-mono-tabular bg-white border border-[#DDD3BC] rounded-lg hover:bg-[#F7F3EA]">-5f</button>
                <button type="button" (click)="stepFrame(-1)" class="px-2.5 py-1.5 text-xs font-mono-tabular bg-white border border-[#DDD3BC] rounded-lg hover:bg-[#F7F3EA]">-1f</button>
                <button
                  type="button"
                  (click)="togglePlay()"
                  class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-[#0E172A] rounded-lg"
                >
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">{{ playing() ? 'pause' : 'play_arrow' }}</mat-icon>
                  <span>{{ playing() ? 'Pause' : 'Play' }}</span>
                </button>
                <button type="button" (click)="stepFrame(1)" class="px-2.5 py-1.5 text-xs font-mono-tabular bg-white border border-[#DDD3BC] rounded-lg hover:bg-[#F7F3EA]">+1f</button>
                <button type="button" (click)="stepFrame(5)" class="px-2.5 py-1.5 text-xs font-mono-tabular bg-white border border-[#DDD3BC] rounded-lg hover:bg-[#F7F3EA]">+5f</button>
                <select
                  [value]="playbackSpeed()"
                  (change)="onSpeedChange($event)"
                  aria-label="Playback speed"
                  class="px-2.5 py-1.5 text-xs font-mono-tabular bg-white border border-[#DDD3BC] rounded-lg"
                >
                  <option value="0.25">0.25x</option>
                  <option value="0.5">0.5x</option>
                  <option value="1">1x</option>
                  <option value="2">2x</option>
                </select>
              </div>

              <div class="flex items-center gap-2">
                <button type="button" (click)="clearLocalStrokes()" class="px-2.5 py-1.5 text-xs bg-white border border-[#DDD3BC] rounded-lg hover:bg-[#F7F3EA]">
                  Clear Sketch
                </button>
                <button
                  type="button"
                  (click)="saveAnnotation(rev.id)"
                  [disabled]="draftStrokes().length === 0"
                  class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-[#0E172A] bg-white border border-[#9A7B3A] rounded-lg disabled:opacity-40"
                >
                  <mat-icon class="!text-[15px] !w-[15px] !h-[15px]" aria-hidden="true">brush</mat-icon>
                  <span>Save Frame Drawing</span>
                </button>
              </div>
            </div>

            <!-- Frame Scrubber -->
            <input
              type="range"
              [min]="1"
              [max]="totalFrames()"
              [value]="currentFrame()"
              (input)="onScrub($event)"
              aria-label="Frame scrubber"
              class="w-full accent-[#1B4D3E]"
            />

            <!-- Separate Approval Gates: Creative | Technical | Delivery -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 border-t border-[#E5DEC9]">
              <div class="bg-white border border-[#E5DEC9] rounded-lg p-3 space-y-2">
                <div class="flex items-center justify-between gap-2">
                  <span class="text-xs font-semibold text-[#0E172A]">Creative Approval</span>
                  <app-status-tag
                    [label]="rev.creativeApproval"
                    [tone]="rev.creativeApproval === 'Approved' ? 'approved' : rev.creativeApproval === 'Changes Requested' ? 'warning' : 'active'"
                  />
                </div>
                <div class="flex gap-1.5">
                  <button type="button" (click)="decide(rev.id, 'creative', 'Approved')" class="flex-1 px-2 py-1 text-xs font-medium bg-[#1B4D3E] text-white rounded">Approve</button>
                  <button type="button" (click)="decide(rev.id, 'creative', 'Changes Requested')" class="flex-1 px-2 py-1 text-xs font-medium bg-amber-50 border border-amber-300 text-amber-900 rounded">Changes</button>
                </div>
              </div>

              <div class="bg-white border border-[#E5DEC9] rounded-lg p-3 space-y-2">
                <div class="flex items-center justify-between gap-2">
                  <span class="text-xs font-semibold text-[#0E172A]">Technical Validation</span>
                  <app-status-tag
                    [label]="rev.technicalValidation"
                    [tone]="rev.technicalValidation === 'Passed' ? 'approved' : rev.technicalValidation === 'Failed' ? 'danger' : 'neutral'"
                  />
                </div>
                <div class="flex gap-1.5">
                  <button type="button" (click)="decide(rev.id, 'technical', 'Passed')" class="flex-1 px-2 py-1 text-xs font-medium bg-[#1B4D3E] text-white rounded">Pass QC</button>
                  <button type="button" (click)="decide(rev.id, 'technical', 'Failed')" class="flex-1 px-2 py-1 text-xs font-medium bg-red-50 border border-red-300 text-red-900 rounded">Fail</button>
                </div>
              </div>

              <div class="bg-white border border-[#E5DEC9] rounded-lg p-3 space-y-2">
                <div class="flex items-center justify-between gap-2">
                  <span class="text-xs font-semibold text-[#0E172A]">Delivery Approval</span>
                  <app-status-tag
                    [label]="rev.deliveryApproval"
                    [tone]="rev.deliveryApproval === 'Approved' ? 'approved' : rev.deliveryApproval === 'Rejected' ? 'danger' : 'neutral'"
                  />
                </div>
                <div class="flex gap-1.5">
                  <button type="button" (click)="decide(rev.id, 'delivery', 'Approved')" class="flex-1 px-2 py-1 text-xs font-medium bg-[#1B4D3E] text-white rounded">Approve</button>
                  <button type="button" (click)="decide(rev.id, 'delivery', 'Rejected')" class="flex-1 px-2 py-1 text-xs font-medium bg-red-50 border border-red-300 text-red-900 rounded">Reject</button>
                </div>
              </div>
            </div>
          </div>

          <!-- Frame Comments & External Screening Links -->
          <div class="xl:col-span-4 space-y-4">
            <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5 space-y-4">
              <div class="flex items-center justify-between gap-2">
                <h2 class="font-display text-lg font-semibold text-[#0E172A]">Frame Notes</h2>
                <div class="flex items-center gap-1 p-0.5 bg-[#EDE5D4] rounded">
                  <button type="button" (click)="noteFilter.set('all')" class="px-2 py-0.5 text-xs rounded" [class]="noteFilter() === 'all' ? 'bg-white text-[#0E172A]' : 'text-[#475569]'">All</button>
                  <button type="button" (click)="noteFilter.set('open')" class="px-2 py-0.5 text-xs rounded" [class]="noteFilter() === 'open' ? 'bg-white text-[#0E172A]' : 'text-[#475569]'">Open</button>
                </div>
              </div>

              <div class="space-y-2.5 max-h-[340px] overflow-y-auto pr-1">
                @for (c of filteredComments(); track c.id) {
                  <div class="bg-white border border-[#E5DEC9] rounded-lg p-3 space-y-1.5 text-xs">
                    <div class="flex items-center justify-between gap-2">
                      <button type="button" (click)="jumpToFrame(c.frameNumber)" class="font-mono-tabular font-semibold text-[#1B4D3E] hover:underline">
                        F{{ c.frameNumber }} · {{ c.versionLabel }}
                      </button>
                      <button type="button" (click)="toggleResolve(rev.id, c)" class="text-[11px] underline text-[#475569]">
                        {{ c.resolved ? 'Resolved' : 'Mark Resolved' }}
                      </button>
                    </div>
                    <div class="text-[#0E172A]">{{ c.body }}</div>
                    <div class="text-[11px] text-[#64748B]">
                      {{ c.authorName }} ({{ c.authorRole }})
                      @if (c.carriedOverFromVersion) {
                        <span> · Carried from {{ c.carriedOverFromVersion }}</span>
                      }
                    </div>
                  </div>
                }
              </div>

              <div class="space-y-2 pt-2 border-t border-[#E5DEC9]">
                <textarea
                  [value]="draftComment()"
                  (input)="onCommentInput($event)"
                  rows="2"
                  placeholder="Add note on frame {{ currentFrame() }}..."
                  class="w-full px-3 py-2 text-xs bg-white border border-[#DDD3BC] rounded-lg"
                ></textarea>
                <button
                  type="button"
                  (click)="postComment(rev.id)"
                  class="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg"
                >
                  <mat-icon class="!text-[15px] !w-[15px] !h-[15px]" aria-hidden="true">add_comment</mat-icon>
                  <span>Attach Note to Frame {{ currentFrame() }} ({{ activeVersionLabel() }})</span>
                </button>
              </div>
            </div>

            <!-- External Expiring Review Links -->
            <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5 space-y-3">
              <h2 class="font-display text-base font-semibold text-[#0E172A]">External Screening Links</h2>
              <div class="flex items-center justify-between gap-2 text-xs">
                <label class="inline-flex items-center gap-2 text-[#334155]">
                  <input type="checkbox" [checked]="allowExternalDownload()" (change)="onDownloadToggle($event)" />
                  <span>Allow Media Download</span>
                </label>
                <button
                  type="button"
                  (click)="createExternalLink(rev.id)"
                  class="px-3 py-1.5 text-xs font-semibold bg-white border border-[#DDD3BC] rounded-lg hover:bg-[#F7F3EA]"
                >
                  Generate Expiring Link
                </button>
              </div>
              <div class="space-y-2">
                @for (lnk of externalLinksForReview(rev.id); track lnk.id) {
                  <div class="bg-white border border-[#E5DEC9] rounded p-2.5 text-xs space-y-1">
                    <div class="font-medium text-[#0E172A]">{{ lnk.label }}</div>
                    <div class="font-mono-tabular text-[11px] text-[#475569]">
                      /external-review/{{ lnk.token }} · Download: {{ lnk.allowDownload ? 'Allowed' : 'Disabled' }}
                    </div>
                    <div class="text-[11px] text-[#64748B]">Expires {{ lnk.expiresAt.slice(0, 10) }}</div>
                  </div>
                }
              </div>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class ReviewsWorkspace implements OnDestroy {
  protected readonly store = inject(StudioStore);
  protected readonly canvasRef = viewChild<ElementRef<HTMLCanvasElement>>('drawCanvas');

  protected readonly selectedReviewId = signal<string>('');
  protected readonly currentFrame = signal<number>(58);
  protected readonly playing = signal<boolean>(false);
  protected readonly playbackSpeed = signal<number>(1);
  protected readonly compareMode = signal<boolean>(false);
  protected readonly noteFilter = signal<'all' | 'open'>('all');
  protected readonly draftComment = signal<string>('');
  protected readonly allowExternalDownload = signal<boolean>(false);
  protected readonly draftStrokes = signal<StrokePoint[][]>([]);

  private activeStroke: StrokePoint[] | null = null;
  private playTimer: ReturnType<typeof setInterval> | null = null;

  protected readonly activeReview = computed(() => {
    const list = this.store.activeReviews();
    const id = this.selectedReviewId();
    return list.find((r) => r.id === id) ?? list[0] ?? null;
  });

  protected readonly activeVersionLabel = computed(
    () => this.activeReview()?.currentVersionLabel ?? 'v001',
  );

  protected readonly activeMediaVersion = computed(() => {
    const rev = this.activeReview();
    if (!rev) return null;
    return rev.versions.find((v) => v.versionLabel === rev.currentVersionLabel) ?? rev.versions[rev.versions.length - 1] ?? null;
  });

  protected readonly totalFrames = computed(() => this.activeMediaVersion()?.frameCount ?? 120);

  protected readonly filteredComments = computed(() => {
    const rev = this.activeReview();
    if (!rev) return [];
    return this.noteFilter() === 'open'
      ? rev.comments.filter((c) => !c.resolved)
      : rev.comments;
  });

  public ngOnDestroy(): void {
    this.stopPlayback();
  }

  protected handleKey(event: KeyboardEvent): void {
    const tag = (event.target as HTMLElement)?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    if (event.key === 'ArrowLeft') {
      event.preventDefault();
      this.stepFrame(-1);
    } else if (event.key === 'ArrowRight') {
      event.preventDefault();
      this.stepFrame(1);
    } else if (event.key === ' ') {
      event.preventDefault();
      this.togglePlay();
    }
  }

  protected selectReview(rev: ReviewItem): void {
    this.stopPlayback();
    this.selectedReviewId.set(rev.id);
    this.currentFrame.set(1);
    this.clearLocalStrokes();
    this.redrawCanvas();
  }

  protected stepFrame(delta: number): void {
    const max = this.totalFrames();
    const next = Math.min(max, Math.max(1, this.currentFrame() + delta));
    this.currentFrame.set(next);
    setTimeout(() => this.redrawCanvas(), 0);
  }

  protected jumpToFrame(frame: number): void {
    this.currentFrame.set(Math.max(1, Math.min(this.totalFrames(), frame)));
    setTimeout(() => this.redrawCanvas(), 0);
  }

  protected onScrub(event: Event): void {
    this.currentFrame.set(Number((event.target as HTMLInputElement).value));
    this.redrawCanvas();
  }

  protected onSpeedChange(event: Event): void {
    this.playbackSpeed.set(Number((event.target as HTMLSelectElement).value));
    if (this.playing()) {
      this.stopPlayback();
      this.startPlayback();
    }
  }

  protected togglePlay(): void {
    if (this.playing()) {
      this.stopPlayback();
    } else {
      this.startPlayback();
    }
  }

  private startPlayback(): void {
    this.playing.set(true);
    const fps = (this.activeMediaVersion()?.fps || 24) * this.playbackSpeed();
    const intervalMs = Math.max(16, Math.round(1000 / fps));
    this.playTimer = setInterval(() => {
      const next = this.currentFrame() >= this.totalFrames() ? 1 : this.currentFrame() + 1;
      this.currentFrame.set(next);
      this.redrawCanvas();
    }, intervalMs);
  }

  private stopPlayback(): void {
    this.playing.set(false);
    if (this.playTimer) {
      clearInterval(this.playTimer);
      this.playTimer = null;
    }
  }

  protected startStroke(event: PointerEvent): void {
    const canvas = this.canvasRef()?.nativeElement;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const pt = {
      x: (event.clientX - rect.left) / rect.width,
      y: (event.clientY - rect.top) / rect.height,
    };
    this.activeStroke = [pt];
  }

  protected moveStroke(event: PointerEvent): void {
    if (!this.activeStroke) return;
    const canvas = this.canvasRef()?.nativeElement;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    this.activeStroke.push({
      x: (event.clientX - rect.left) / rect.width,
      y: (event.clientY - rect.top) / rect.height,
    });
    this.redrawCanvas();
  }

  protected endStroke(): void {
    if (!this.activeStroke) return;
    if (this.activeStroke.length > 1) {
      const finished = this.activeStroke;
      this.draftStrokes.update((s) => [...s, finished]);
    }
    this.activeStroke = null;
    this.redrawCanvas();
  }

  protected clearLocalStrokes(): void {
    this.draftStrokes.set([]);
    this.activeStroke = null;
    this.redrawCanvas();
  }

  private redrawCanvas(): void {
    const canvas = this.canvasRef()?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const rev = this.activeReview();
    const saved =
      rev?.annotations
        .filter(
          (a) =>
            a.versionLabel === this.activeVersionLabel() &&
            a.frameNumber === this.currentFrame(),
        )
        .flatMap((a) => {
          try {
            return JSON.parse(a.strokesJson) as StrokePoint[][];
          } catch {
            return [];
          }
        }) ?? [];

    const drawSet = (strokes: StrokePoint[][], colour: string) => {
      ctx.strokeStyle = colour;
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      for (const stroke of strokes) {
        if (stroke.length < 2) continue;
        ctx.beginPath();
        ctx.moveTo(stroke[0].x * canvas.width, stroke[0].y * canvas.height);
        for (let i = 1; i < stroke.length; i++) {
          ctx.lineTo(stroke[i].x * canvas.width, stroke[i].y * canvas.height);
        }
        ctx.stroke();
      }
    };

    drawSet(saved, '#B8964D');
    drawSet(this.draftStrokes(), '#22C55E');
    if (this.activeStroke) {
      drawSet([this.activeStroke], '#22C55E');
    }
  }

  protected async saveAnnotation(reviewId: string): Promise<void> {
    if (this.draftStrokes().length === 0) return;
    const res = await this.store.mutate(
      'POST',
      `/api/reviews/${reviewId}/annotations`,
      {
        versionLabel: this.activeVersionLabel(),
        frameNumber: this.currentFrame(),
        colour: '#B8964D',
        strokesJson: JSON.stringify(this.draftStrokes()),
      },
      `Saved frame drawing on F${this.currentFrame()}.`,
    );
    if (res) {
      this.draftStrokes.set([]);
      setTimeout(() => this.redrawCanvas(), 0);
    }
  }

  protected onCommentInput(event: Event): void {
    this.draftComment.set((event.target as HTMLTextAreaElement).value);
  }

  protected async postComment(reviewId: string): Promise<void> {
    const body = this.draftComment().trim();
    if (!body) return;
    const res = await this.store.mutate(
      'POST',
      `/api/reviews/${reviewId}/comments`,
      {
        versionLabel: this.activeVersionLabel(),
        frameNumber: this.currentFrame(),
        body,
      },
      `Attached note to F${this.currentFrame()} (${this.activeVersionLabel()}).`,
    );
    if (res) {
      this.draftComment.set('');
    }
  }

  protected async toggleResolve(reviewId: string, c: ReviewComment): Promise<void> {
    await this.store.mutate(
      'PATCH',
      `/api/reviews/${reviewId}/comments/${c.id}/resolve`,
      {resolved: !c.resolved},
    );
  }

  protected async decide(reviewId: string, gate: 'creative' | 'technical' | 'delivery', status: string): Promise<void> {
    await this.store.mutate(
      'POST',
      `/api/reviews/${reviewId}/decision`,
      {gate, status},
      `Updated ${gate} decision to ${status}.`,
    );
  }

  protected async submitRevision(rev: ReviewItem): Promise<void> {
    await this.store.mutate(
      'POST',
      `/api/reviews/${rev.shotId}/submit-preview`,
      {notes: `Revision addressing frame notes on ${rev.currentVersionLabel}.`},
      'Published new review version (unresolved notes carried forward).',
    );
  }

  protected onDownloadToggle(event: Event): void {
    this.allowExternalDownload.set((event.target as HTMLInputElement).checked);
  }

  protected async createExternalLink(reviewId: string): Promise<void> {
    await this.store.mutate(
      'POST',
      `/api/reviews/${reviewId}/external-links`,
      {
        label: 'External Screening Link',
        allowDownload: this.allowExternalDownload(),
        expiresInDays: 7,
      },
      'Created expiring external review link.',
    );
  }

  protected externalLinksForReview(reviewId: string) {
    return (this.store.data()?.externalReviewLinks ?? []).filter((l) => l.reviewItemId === reviewId);
  }
}
