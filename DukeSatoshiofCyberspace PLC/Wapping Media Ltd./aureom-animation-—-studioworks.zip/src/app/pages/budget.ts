import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {StudioStore} from '../core/studio.store';
import {StatusTag} from '../shared/status-tag';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-budget-workspace',
  imports: [ReactiveFormsModule, MatIconModule, StatusTag],
  template: `
    @if (store.data(); as d) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="font-display text-2xl font-semibold text-[#0E172A]">Production Budget & Expenditure</h1>
            <p class="text-xs text-[#64748B] mt-1">
              Decimal GBP ledger distinguishing Approved Budget, Committed Expenditure, Recorded Actuals, and Forecast Remaining Cost.
            </p>
          </div>
          <button
            type="button"
            (click)="showPurchaseForm.set(!showPurchaseForm())"
            class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg whitespace-nowrap shrink-0"
          >
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">receipt_long</mat-icon>
            <span>{{ showPurchaseForm() ? 'Close' : 'Record Purchase' }}</span>
          </button>
        </div>

        <!-- 4-Column Financial Distinction Strip -->
        <section class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5">
            <div class="text-xs text-[#64748B]">Approved Budget (GBP)</div>
            <div class="mt-2 font-display text-2xl font-semibold text-[#0E172A] tabular-nums">£{{ totals().budget }}</div>
          </div>
          <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5">
            <div class="text-xs text-[#64748B]">Committed Expenditure</div>
            <div class="mt-2 font-display text-2xl font-semibold text-[#0E172A] tabular-nums">£{{ totals().committed }}</div>
          </div>
          <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5">
            <div class="text-xs text-[#64748B]">Recorded Actuals</div>
            <div class="mt-2 font-display text-2xl font-semibold text-[#1B4D3E] tabular-nums">£{{ totals().actual }}</div>
          </div>
          <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5">
            <div class="text-xs text-[#64748B]">Forecast Remaining</div>
            <div class="mt-2 font-display text-2xl font-semibold text-[#85682D] tabular-nums">£{{ totals().forecast }}</div>
          </div>
        </section>

        @if (showPurchaseForm()) {
          <form [formGroup]="purchaseForm" (ngSubmit)="submitPurchase()" class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
            <h2 class="font-display text-lg font-semibold text-[#0E172A]">Record Purchase Order</h2>
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
              <input formControlName="vendor" type="text" placeholder="Supplier / Vendor" class="px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg" />
              <input formControlName="description" type="text" placeholder="Description" class="px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg" />
              <input formControlName="amount" type="number" step="0.01" placeholder="Amount (GBP)" class="px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg font-mono-tabular" />
              <select formControlName="status" class="px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg">
                <option value="Committed">Committed</option>
                <option value="Paid">Paid</option>
              </select>
            </div>
            <div class="flex justify-end">
              <button type="submit" class="px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] rounded-lg">Save Purchase</button>
            </div>
          </form>
        }

        <!-- Department Budget Breakdown -->
        <section class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
          <h2 class="font-display text-lg font-semibold text-[#0E172A]">Department Cost Ledger</h2>
          <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-sm">
              <thead>
                <tr class="border-b border-[#E5DEC9] text-xs text-[#64748B]">
                  <th class="py-2 pr-3 font-medium">Department</th>
                  <th class="py-2 px-3 font-medium">Scope</th>
                  <th class="py-2 px-3 font-medium text-right">Currency</th>
                  <th class="py-2 px-3 font-medium text-right">Budget</th>
                  <th class="py-2 px-3 font-medium text-right">Committed</th>
                  <th class="py-2 px-3 font-medium text-right">Actual</th>
                  <th class="py-2 pl-3 font-medium text-right">Forecast Rem.</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#EFE8D8]">
                @for (line of prodLines(); track line.id) {
                  <tr>
                    <td class="py-3 pr-3 font-medium text-[#0E172A]">{{ line.department }}</td>
                    <td class="py-3 px-3 text-xs text-[#475569]">{{ line.description }}</td>
                    <td class="py-3 px-3 font-mono-tabular text-xs text-right text-[#64748B]">{{ line.currency }}</td>
                    <td class="py-3 px-3 font-mono-tabular text-xs text-right text-[#0E172A]">{{ line.budgetAmount }}</td>
                    <td class="py-3 px-3 font-mono-tabular text-xs text-right text-[#334155]">{{ line.committedAmount }}</td>
                    <td class="py-3 px-3 font-mono-tabular text-xs text-right text-[#1B4D3E] font-medium">{{ line.actualAmount }}</td>
                    <td class="py-3 pl-3 font-mono-tabular text-xs text-right text-[#85682D]">{{ line.forecastRemainingAmount }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </section>

        <!-- Purchase Records -->
        <section class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4">
          <h2 class="font-display text-lg font-semibold text-[#0E172A]">Purchase Orders & Invoices</h2>
          <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-sm">
              <thead>
                <tr class="border-b border-[#E5DEC9] text-xs text-[#64748B]">
                  <th class="py-2 pr-3 font-medium">Vendor</th>
                  <th class="py-2 px-3 font-medium">Description</th>
                  <th class="py-2 px-3 font-medium">Recorded</th>
                  <th class="py-2 px-3 font-medium text-right">Amount</th>
                  <th class="py-2 pl-3 font-medium text-right">Status</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#EFE8D8]">
                @for (po of d.purchases; track po.id) {
                  <tr>
                    <td class="py-3 pr-3 font-medium text-[#0E172A]">{{ po.vendor }}</td>
                    <td class="py-3 px-3 text-xs text-[#475569]">{{ po.description }}</td>
                    <td class="py-3 px-3 font-mono-tabular text-xs text-[#64748B]">{{ po.recordedAt }}</td>
                    <td class="py-3 px-3 font-mono-tabular text-xs text-right text-[#0E172A]">{{ po.currency }} {{ po.amount }}</td>
                    <td class="py-3 pl-3 text-right">
                      <app-status-tag [label]="po.status" [tone]="po.status === 'Paid' ? 'approved' : 'active'" />
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </section>
      </div>
    }
  `,
})
export class BudgetWorkspace {
  protected readonly store = inject(StudioStore);
  protected readonly showPurchaseForm = signal(false);

  protected readonly purchaseForm = new FormGroup({
    vendor: new FormControl('', [Validators.required]),
    description: new FormControl('', [Validators.required]),
    amount: new FormControl(500, [Validators.required, Validators.min(1)]),
    status: new FormControl<'Committed' | 'Paid'>('Committed'),
  });

  protected readonly prodLines = computed(() => {
    const pid = this.store.activeProduction()?.id;
    return (this.store.data()?.budgetLines ?? []).filter((l) => l.productionId === pid);
  });

  protected readonly totals = computed(() => {
    let budget = 0;
    let committed = 0;
    let actual = 0;
    let forecast = 0;
    for (const l of this.prodLines()) {
      budget += Number(l.budgetAmount);
      committed += Number(l.committedAmount);
      actual += Number(l.actualAmount);
      forecast += Number(l.forecastRemainingAmount);
    }
    return {
      budget: budget.toFixed(2),
      committed: committed.toFixed(2),
      actual: actual.toFixed(2),
      forecast: forecast.toFixed(2),
    };
  });

  protected async submitPurchase(): Promise<void> {
    if (this.purchaseForm.invalid) return;
    const v = this.purchaseForm.getRawValue();
    const res = await this.store.mutate(
      'POST',
      '/api/purchases',
      {
        productionId: this.store.activeProduction()?.id,
        department: 'Audio, Foley & Mastering',
        currency: 'GBP',
        ...v,
      },
      'Recorded production purchase.',
    );
    if (res) {
      this.showPurchaseForm.set(false);
    }
  }
}
