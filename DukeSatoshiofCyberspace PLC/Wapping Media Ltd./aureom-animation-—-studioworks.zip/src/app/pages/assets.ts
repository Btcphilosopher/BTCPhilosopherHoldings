import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {StudioStore} from '../core/studio.store';
import type {Asset} from '../core/studio.models';
import {MediaFrame} from '../shared/media-frame';
import {StatusTag} from '../shared/status-tag';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-assets-workspace',
  imports: [ReactiveFormsModule, MatIconModule, MediaFrame, StatusTag],
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-2xl font-semibold text-[#0E172A]">Asset Library</h1>
          <p class="text-xs text-[#64748B] mt-1">
            Editable working files vs immutable SHA-256 published versions, 3D/2D specs, rights, and duplicate detection.
          </p>
        </div>
        <button
          type="button"
          (click)="showCreate.set(!showCreate())"
          class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg whitespace-nowrap shrink-0"
        >
          <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">add_box</mat-icon>
          <span>{{ showCreate() ? 'Close' : 'New Asset' }}</span>
        </button>
      </div>

      <!-- Search, Category Filter & Duplicate Hash Checker -->
      <div class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div class="flex flex-wrap items-center gap-3 flex-1 min-w-[260px]">
          <input
            type="text"
            [value]="searchQuery()"
            (input)="onSearch($event)"
            placeholder="Search by code, name, or tag..."
            class="px-3 py-2 text-xs bg-white border border-[#DDD3BC] rounded-lg w-64"
          />
          <div class="flex items-center gap-1 p-1 bg-[#EDE5D4] rounded-lg">
            @for (cat of categories; track cat) {
              <button
                type="button"
                (click)="categoryFilter.set(cat)"
                class="px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap"
                [class]="categoryFilter() === cat ? 'bg-white text-[#0E172A] shadow-sm' : 'text-[#475569] hover:text-[#0E172A]'"
              >
                {{ cat }}
              </button>
            }
          </div>
        </div>

        <label class="inline-flex items-center gap-2 px-3 py-2 text-xs font-medium bg-white border border-[#DDD3BC] rounded-lg cursor-pointer hover:bg-[#F7F3EA]">
          <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#1B4D3E]" aria-hidden="true">fingerprint</mat-icon>
          <span>Check File Duplicate (SHA-256)</span>
          <input type="file" class="hidden" (change)="checkDuplicateFile($event)" />
        </label>
      </div>

      @if (duplicateNotice()) {
        <div class="p-3 bg-white border border-[#9A7B3A] rounded-lg text-xs text-[#0E172A] font-mono-tabular">
          {{ duplicateNotice() }}
        </div>
      }

      @if (showCreate()) {
        <form
          [formGroup]="createForm"
          (ngSubmit)="createAsset()"
          class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-6 space-y-4"
        >
          <h2 class="font-display text-lg font-semibold text-[#0E172A]">Register New Studio Asset</h2>
          <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label for="asset-code" class="block text-xs font-medium text-[#334155] mb-1">Asset Code</label>
              <input id="asset-code" formControlName="code" type="text" placeholder="AST_KEY_PROP" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg font-mono-tabular" />
            </div>
            <div>
              <label for="asset-name" class="block text-xs font-medium text-[#334155] mb-1">Name</label>
              <input id="asset-name" formControlName="name" type="text" placeholder="Miniature Winding Key" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg" />
            </div>
            <div>
              <label for="asset-category" class="block text-xs font-medium text-[#334155] mb-1">Category</label>
              <select id="asset-category" formControlName="category" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg">
                <option value="Character">Character</option>
                <option value="Environment">Environment</option>
                <option value="Prop">Prop</option>
                <option value="Rig">Rig</option>
                <option value="Texture">Texture</option>
                <option value="Reference Artwork">Reference Artwork</option>
                <option value="Audio">Audio</option>
              </select>
            </div>
            <div>
              <label for="asset-dim" class="block text-xs font-medium text-[#334155] mb-1">Dimension Type</label>
              <select id="asset-dim" formControlName="dimensionType" class="w-full px-3 py-2 text-sm bg-white border border-[#DDD3BC] rounded-lg">
                <option value="3D">3D (Blender)</option>
                <option value="2D">2D (Raster / Layered)</option>
              </select>
            </div>
          </div>
          <div class="flex justify-end">
            <button type="submit" [disabled]="createForm.invalid" class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#1B4D3E] rounded-lg">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">save</mat-icon>
              <span>Create Asset</span>
            </button>
          </div>
        </form>
      }

      <!-- Asset Cards Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        @for (asset of filteredAssets(); track asset.id) {
          <article class="bg-[#FCFBF7] border border-[#DDD3BC] rounded-xl p-5 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-12 gap-4 items-start">
              <div class="sm:col-span-5">
                <app-media-frame
                  [src]="asset.previewUrl"
                  [alt]="asset.name"
                  [fallbackTitle]="asset.code"
                  containerClass="aspect-[4/3] rounded-lg"
                />
              </div>
              <div class="sm:col-span-7 space-y-2">
                <div class="flex items-start justify-between gap-2">
                  <div>
                    <div class="text-xs font-mono-tabular text-[#85682D]">{{ asset.code }} · {{ asset.category }}</div>
                    <h2 class="font-display text-lg font-semibold text-[#0E172A]">{{ asset.name }}</h2>
                  </div>
                  <app-status-tag
                    [label]="asset.approvalStatus"
                    [tone]="asset.approvalStatus === 'Approved' ? 'approved' : 'neutral'"
                  />
                </div>

                <div class="text-xs text-[#475569]">
                  Tags: {{ asset.tags.join(' · ') }}
                </div>
                <div class="text-xs text-[#334155]">
                  Rights: {{ asset.sourceAndRights }}
                </div>

                @if (asset.metadata3D; as m3) {
                  <div class="text-xs font-mono-tabular bg-white border border-[#E5DEC9] rounded p-2 text-[#334155]">
                    3D: {{ m3.units }} · {{ m3.upAxis }} · {{ m3.supportedAppVersion }} · {{ m3.polyCount }} polys
                    @if (m3.rigJointCount) { · {{ m3.rigJointCount }} joints }
                  </div>
                }
                @if (asset.metadata2D; as m2) {
                  <div class="text-xs font-mono-tabular bg-white border border-[#E5DEC9] rounded p-2 text-[#334155]">
                    2D: {{ m2.widthPx }}×{{ m2.heightPx }} px · {{ m2.colourProfile }} · Layers: {{ m2.expectedLayers.join(', ') }}
                  </div>
                }
              </div>
            </div>

            <!-- Working File vs Immutable Published Versions -->
            <div class="bg-white border border-[#E5DEC9] rounded-lg p-3.5 space-y-2.5">
              <div class="flex flex-wrap items-center justify-between gap-2">
                <div class="text-xs font-mono-tabular text-[#475569] truncate max-w-[380px]">
                  Working File (rev {{ asset.workingFileRevision }}): {{ asset.workingFilePath }}
                </div>
                <button
                  type="button"
                  (click)="publishVersion(asset)"
                  class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-[#1B4D3E] hover:bg-[#143B2F] rounded-lg whitespace-nowrap shrink-0"
                >
                  <mat-icon class="!text-[15px] !w-[15px] !h-[15px]" aria-hidden="true">publish</mat-icon>
                  <span>Publish Immutable Version</span>
                </button>
              </div>

              @if (asset.versions.length > 0) {
                <div class="divide-y divide-[#EFE8D8] border-t border-[#EFE8D8] pt-2">
                  @for (ver of asset.versions; track ver.id) {
                    <div class="py-1.5 flex items-center justify-between gap-2 text-xs">
                      <div class="min-w-0">
                        <span class="font-mono-tabular font-semibold text-[#0E172A]">{{ ver.versionLabel }}</span>
                        <span class="text-[#64748B] ml-2">Immutable · {{ ver.toolName }} {{ ver.toolVersion }} · {{ ver.publishedBy }}</span>
                        <div class="text-[#475569] truncate">{{ ver.notes }}</div>
                      </div>
                      <span class="font-mono-tabular text-[11px] text-[#64748B] shrink-0">
                        {{ ver.contentHash.slice(0, 12) }}
                      </span>
                    </div>
                  }
                </div>
              } @else {
                <div class="text-xs text-[#64748B]">No immutable published versions yet.</div>
              }
            </div>
          </article>
        }
      </div>
    </div>
  `,
})
export class AssetsWorkspace {
  protected readonly store = inject(StudioStore);
  protected readonly searchQuery = signal('');
  protected readonly categoryFilter = signal('All');
  protected readonly showCreate = signal(false);
  protected readonly duplicateNotice = signal<string | null>(null);

  protected readonly categories = ['All', 'Character', 'Environment', 'Prop', 'Reference Artwork'];

  protected readonly createForm = new FormGroup({
    code: new FormControl('', [Validators.required]),
    name: new FormControl('', [Validators.required]),
    category: new FormControl('Prop'),
    dimensionType: new FormControl<'3D' | '2D'>('3D'),
  });

  protected readonly filteredAssets = computed(() => {
    const q = this.searchQuery().toLowerCase().trim();
    const cat = this.categoryFilter();
    return this.store.activeAssets().filter((a) => {
      const catOk = cat === 'All' || a.category === cat;
      const qOk =
        !q ||
        a.code.toLowerCase().includes(q) ||
        a.name.toLowerCase().includes(q) ||
        a.tags.some((t) => t.toLowerCase().includes(q));
      return catOk && qOk;
    });
  });

  protected onSearch(event: Event): void {
    this.searchQuery.set((event.target as HTMLInputElement).value);
  }

  protected async createAsset(): Promise<void> {
    const pid = this.store.activeProduction()?.id;
    if (!pid || this.createForm.invalid) return;
    const v = this.createForm.getRawValue();
    const res = await this.store.mutate(
      'POST',
      '/api/assets',
      {productionId: pid, ...v},
      `Created asset ${v.code}.`,
    );
    if (res) {
      this.showCreate.set(false);
      this.createForm.reset({category: 'Prop', dimensionType: '3D'});
    }
  }

  protected async publishVersion(asset: Asset): Promise<void> {
    await this.store.mutate(
      'POST',
      `/api/assets/${asset.id}/publish`,
      {
        toolName: 'Blender',
        toolVersion: '4.2.3',
        notes: `Published replacement immutable version from studio asset desk.`,
      },
      `Published new immutable version for ${asset.code} and flagged downstream tasks.`,
    );
  }

  protected async checkDuplicateFile(event: Event): Promise<void> {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const base64Data = String(reader.result || '');
      const res = await this.store.mutate<{contentHash: string; isDuplicate: boolean; duplicateAssetCode: string | null}>(
        'POST',
        '/api/uploads/direct',
        {fileName: file.name, mimeType: file.type || 'application/octet-stream', base64Data},
      );
      if (res) {
        this.duplicateNotice.set(
          res.duplicateAssetCode
            ? `Duplicate detected: SHA-256 ${res.contentHash.slice(0, 16)} matches existing asset ${res.duplicateAssetCode}.`
            : `Unique object stored: SHA-256 ${res.contentHash.slice(0, 16)} (no existing asset match).`,
        );
      }
    };
    reader.readAsDataURL(file);
  }
}
