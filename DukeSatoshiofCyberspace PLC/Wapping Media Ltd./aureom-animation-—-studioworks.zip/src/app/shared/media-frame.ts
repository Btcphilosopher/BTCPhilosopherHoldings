import {ChangeDetectionStrategy, Component, input, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-media-frame',
  imports: [MatIconModule],
  template: `
    <div class="relative overflow-hidden bg-[#EDE5D4] border border-[#DDD3BC]" [class]="containerClass()">
      @if (src() && !failed()) {
        <img
          [src]="src()"
          [alt]="alt()"
          referrerpolicy="no-referrer"
          (error)="failed.set(true)"
          class="w-full h-full object-cover block"
        />
      } @else {
        <div class="w-full h-full flex flex-col items-center justify-center p-4 text-center bg-gradient-to-br from-[#F7F3EA] to-[#E5DEC9] text-[#334155]">
          <mat-icon class="!text-[28px] !w-[28px] !h-[28px] text-[#9A7B3A] mb-1.5" aria-hidden="true">movie_creation</mat-icon>
          <span class="text-xs font-medium leading-snug">{{ fallbackTitle() || alt() }}</span>
        </div>
      }
    </div>
  `,
})
export class MediaFrame {
  public readonly src = input<string | null | undefined>('');
  public readonly alt = input.required<string>();
  public readonly fallbackTitle = input<string>('');
  public readonly containerClass = input<string>('aspect-video rounded-lg');
  protected readonly failed = signal<boolean>(false);
}
