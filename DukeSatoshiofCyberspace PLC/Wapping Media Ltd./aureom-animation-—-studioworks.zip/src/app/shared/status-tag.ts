import {ChangeDetectionStrategy, Component, computed, input} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-status-tag',
  imports: [MatIconModule],
  template: `
    <span
      class="inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium rounded border whitespace-nowrap shrink-0"
      [class]="styleClasses()"
    >
      <mat-icon class="!text-[14px] !w-[14px] !h-[14px] leading-none" aria-hidden="true">{{ iconName() }}</mat-icon>
      <span>{{ label() }}</span>
    </span>
  `,
})
export class StatusTag {
  public readonly label = input.required<string>();
  public readonly tone = input<'approved' | 'warning' | 'danger' | 'neutral' | 'active'>('neutral');

  protected readonly styleClasses = computed(() => {
    switch (this.tone()) {
      case 'approved':
        return 'bg-[#1B4D3E]/10 text-[#143B2F] border-[#1B4D3E]/25';
      case 'active':
        return 'bg-[#9A7B3A]/12 text-[#6B5322] border-[#9A7B3A]/30';
      case 'warning':
        return 'bg-amber-50 text-amber-900 border-amber-300';
      case 'danger':
        return 'bg-red-50 text-red-900 border-red-300';
      default:
        return 'bg-[#F7F3EA] text-[#334155] border-[#DDD3BC]';
    }
  });

  protected readonly iconName = computed(() => {
    switch (this.tone()) {
      case 'approved':
        return 'check_circle';
      case 'active':
        return 'play_circle';
      case 'warning':
        return 'warning';
      case 'danger':
        return 'error';
      default:
        return 'radio_button_unchecked';
    }
  });
}
