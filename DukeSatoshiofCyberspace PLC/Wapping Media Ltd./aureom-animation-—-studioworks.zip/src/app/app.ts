import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {Router, RouterLink, RouterLinkActive, RouterOutlet} from '@angular/router';
import {StudioStore} from './core/studio.store';

interface NavEntry {
  label: string;
  route: string;
  icon: string;
  shortcut: string;
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, ReactiveFormsModule, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
  host: {
    '[class.reduced-motion]': 'store.reducedMotion()',
    '(window:keydown)': 'onGlobalKeydown($event)',
  },
})
export class App implements OnInit {
  protected readonly store = inject(StudioStore);
  private readonly router = inject(Router);
  protected readonly drawerOpen = signal(false);

  protected readonly navItems: NavEntry[] = [
    {label: 'Studio', route: '/studio', icon: 'dashboard', shortcut: 'Alt+1'},
    {label: 'Productions', route: '/productions', icon: 'theaters', shortcut: 'Alt+2'},
    {label: 'Scripts', route: '/scripts', icon: 'description', shortcut: 'Alt+3'},
    {label: 'Storyboards', route: '/storyboards', icon: 'view_carousel', shortcut: 'Alt+4'},
    {label: 'Assets', route: '/assets', icon: 'category', shortcut: 'Alt+5'},
    {label: 'Shots', route: '/shots', icon: 'movie_filter', shortcut: 'Alt+6'},
    {label: 'Reviews', route: '/reviews', icon: 'rate_review', shortcut: 'Alt+7'},
    {label: 'Render Farm', route: '/render-farm', icon: 'dns', shortcut: 'Alt+8'},
    {label: 'Team', route: '/team', icon: 'groups', shortcut: 'Alt+9'},
    {label: 'Budget', route: '/budget', icon: 'account_balance', shortcut: 'Alt+0'},
    {label: 'Deliveries', route: '/deliveries', icon: 'inventory_2', shortcut: 'Alt+-'},
    {label: 'Administration', route: '/administration', icon: 'admin_panel_settings', shortcut: 'Alt+='},
  ];

  protected readonly authForm = new FormGroup({
    passcode: new FormControl('', [Validators.required, Validators.minLength(6)]),
    memberId: new FormControl('usr_clara', [Validators.required]),
  });

  public ngOnInit(): void {
    void this.store.initialize();
  }

  protected onProductionChange(event: Event): void {
    const pid = (event.target as HTMLSelectElement).value;
    if (pid) {
      this.store.activeProductionId.set(pid);
    }
  }

  protected async submitAuth(): Promise<void> {
    if (this.authForm.invalid) return;
    const {passcode, memberId} = this.authForm.getRawValue();
    const pass = passcode || '';
    const mid = memberId || 'usr_clara';
    const ok = this.store.authStatus().claimRequired
      ? await this.store.claimPasscode(pass, mid)
      : await this.store.login(pass, mid);
    if (ok) {
      this.authForm.patchValue({passcode: ''});
    }
  }

  protected onGlobalKeydown(event: KeyboardEvent): void {
    const tag = (event.target as HTMLElement)?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

    if (event.key === '?') {
      event.preventDefault();
      this.store.shortcutsModalOpen.update((v) => !v);
      return;
    }
    if (event.key === 'Escape') {
      this.store.authModalOpen.set(false);
      this.store.shortcutsModalOpen.set(false);
      this.drawerOpen.set(false);
      return;
    }
    if (event.altKey) {
      const idxMap: Record<string, number> = {
        '1': 0, '2': 1, '3': 2, '4': 3, '5': 4, '6': 5,
        '7': 6, '8': 7, '9': 8, '0': 9, '-': 10, '=': 11,
      };
      const idx = idxMap[event.key];
      if (typeof idx === 'number' && this.navItems[idx]) {
        event.preventDefault();
        void this.router.navigate([this.navItems[idx].route]);
      }
    }
  }
}
