import {isPlatformBrowser} from '@angular/common';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {computed, inject, Injectable, PLATFORM_ID, signal} from '@angular/core';
import {firstValueFrom} from 'rxjs';
import type {
  AuthStatus,
  StudioBootstrapPayload,
  TeamMember,
} from './studio.models';

@Injectable({providedIn: 'root'})
export class StudioStore {
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);

  // In-memory Bearer token only (never written to localStorage/sessionStorage)
  private authToken = signal<string | null>(null);
  private socket: WebSocket | null = null;

  public readonly loading = signal<boolean>(true);
  public readonly errorBanner = signal<string | null>(null);
  public readonly toastMessage = signal<string | null>(null);
  public readonly reducedMotion = signal<boolean>(false);
  public readonly wsConnected = signal<boolean>(false);

  public readonly data = signal<StudioBootstrapPayload | null>(null);
  public readonly currentUser = signal<TeamMember | null>(null);
  public readonly activeProductionId = signal<string>('prod_clockwork_fox');
  public readonly authModalOpen = signal<boolean>(false);
  public readonly shortcutsModalOpen = signal<boolean>(false);

  public readonly isSignedIn = computed(() => Boolean(this.authToken() && this.currentUser()));
  public readonly authStatus = computed<AuthStatus>(
    () => this.data()?.authStatus ?? {envPasscodeConfigured: false, claimRequired: false, claimed: false},
  );
  public readonly activeProduction = computed(() => {
    const d = this.data();
    if (!d) return null;
    return d.productions.find((p) => p.id === this.activeProductionId()) ?? d.productions[0] ?? null;
  });

  public readonly activeSequences = computed(() => {
    const d = this.data();
    const pid = this.activeProduction()?.id;
    if (!d || !pid) return [];
    return d.sequences.filter((s) => s.productionId === pid);
  });

  public readonly activeShots = computed(() => {
    const d = this.data();
    const pid = this.activeProduction()?.id;
    if (!d || !pid) return [];
    return d.shots.filter((s) => s.productionId === pid);
  });

  public readonly activeAssets = computed(() => {
    const d = this.data();
    const pid = this.activeProduction()?.id;
    if (!d || !pid) return [];
    return d.assets.filter((a) => a.productionId === pid);
  });

  public readonly activeReviews = computed(() => {
    const d = this.data();
    const pid = this.activeProduction()?.id;
    if (!d || !pid) return [];
    return d.reviews.filter((r) => r.productionId === pid);
  });

  public readonly activeRenderJobs = computed(() => {
    const d = this.data();
    const pid = this.activeProduction()?.id;
    if (!d || !pid) return [];
    return d.renderJobs.filter((j) => j.productionId === pid);
  });

  public async initialize(): Promise<void> {
    await this.refresh();
    if (isPlatformBrowser(this.platformId)) {
      this.connectWebSocket();
    }
  }

  public async refresh(): Promise<void> {
    this.loading.set(true);
    try {
      const payload = await firstValueFrom(
        this.http.get<StudioBootstrapPayload>('/api/studio/bootstrap'),
      );
      this.data.set(payload);
      if (payload.studio?.reducedMotionDefault) {
        this.reducedMotion.set(true);
      }
      if (!payload.productions.some((p) => p.id === this.activeProductionId()) && payload.productions[0]) {
        this.activeProductionId.set(payload.productions[0].id);
      }
      this.errorBanner.set(null);
    } catch (err) {
      this.errorBanner.set(this.extractError(err));
    } finally {
      this.loading.set(false);
    }
  }

  private connectWebSocket(): void {
    if (this.socket) return;
    try {
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${proto}//${window.location.host}/api/live`);
      this.socket = ws;
      ws.onopen = () => this.wsConnected.set(true);
      ws.onclose = () => {
        this.wsConnected.set(false);
        this.socket = null;
      };
      ws.onmessage = () => {
        void this.refresh();
      };
    } catch {
      this.wsConnected.set(false);
    }
  }

  public notify(message: string): void {
    this.toastMessage.set(message);
    setTimeout(() => {
      if (this.toastMessage() === message) {
        this.toastMessage.set(null);
      }
    }, 4500);
  }

  public clearError(): void {
    this.errorBanner.set(null);
  }

  public toggleReducedMotion(): void {
    this.reducedMotion.update((v) => !v);
  }

  private authHeaders(): HttpHeaders {
    const token = this.authToken();
    return token ? new HttpHeaders({Authorization: `Bearer ${token}`}) : new HttpHeaders();
  }

  public async claimPasscode(passcode: string, memberId: string): Promise<boolean> {
    try {
      const res = await firstValueFrom(
        this.http.post<{token: string; member: TeamMember}>('/api/auth/claim', {passcode, memberId}),
      );
      this.authToken.set(res.token);
      this.currentUser.set(res.member);
      this.authModalOpen.set(false);
      await this.refresh();
      this.notify(`Studio passcode set. Signed in as ${res.member.name} (${res.member.role}).`);
      return true;
    } catch (err) {
      this.errorBanner.set(this.extractError(err));
      return false;
    }
  }

  public async login(passcode: string, memberId: string): Promise<boolean> {
    try {
      const res = await firstValueFrom(
        this.http.post<{token: string; member: TeamMember}>('/api/auth/login', {passcode, memberId}),
      );
      this.authToken.set(res.token);
      this.currentUser.set(res.member);
      this.authModalOpen.set(false);
      await this.refresh();
      this.notify(`Signed in as ${res.member.name} (${res.member.role}).`);
      return true;
    } catch (err) {
      this.errorBanner.set(this.extractError(err));
      return false;
    }
  }

  public async switchRole(memberId: string): Promise<void> {
    if (!this.isSignedIn()) {
      this.authModalOpen.set(true);
      return;
    }
    try {
      const res = await firstValueFrom(
        this.http.post<{token: string; member: TeamMember}>(
          '/api/auth/switch-role',
          {memberId},
          {headers: this.authHeaders()},
        ),
      );
      this.authToken.set(res.token);
      this.currentUser.set(res.member);
      this.notify(`Switched role to ${res.member.name} (${res.member.role}).`);
    } catch (err) {
      this.errorBanner.set(this.extractError(err));
    }
  }

  public signOut(): void {
    this.authToken.set(null);
    this.currentUser.set(null);
    this.notify('Signed out of editing session.');
  }

  public async mutate<T>(
    method: 'POST' | 'PATCH' | 'PUT',
    url: string,
    body: unknown,
    successNotice?: string,
  ): Promise<T | null> {
    if (!this.isSignedIn()) {
      this.authModalOpen.set(true);
      this.errorBanner.set('Sign in with the studio operator passcode to save changes.');
      return null;
    }
    try {
      const options = {headers: this.authHeaders()};
      const obs =
        method === 'POST'
          ? this.http.post<T>(url, body, options)
          : method === 'PATCH'
            ? this.http.patch<T>(url, body, options)
            : this.http.put<T>(url, body, options);
      const result = await firstValueFrom(obs);
      await this.refresh();
      if (successNotice) {
        this.notify(successNotice);
      }
      this.errorBanner.set(null);
      return result;
    } catch (err) {
      this.errorBanner.set(this.extractError(err));
      return null;
    }
  }

  public async getAuthed<T>(url: string): Promise<T | null> {
    if (!this.isSignedIn()) {
      this.authModalOpen.set(true);
      return null;
    }
    try {
      return await firstValueFrom(this.http.get<T>(url, {headers: this.authHeaders()}));
    } catch (err) {
      this.errorBanner.set(this.extractError(err));
      return null;
    }
  }

  private extractError(err: unknown): string {
    if (err && typeof err === 'object' && 'error' in err) {
      const inner = (err as {error?: {error?: string; message?: string}}).error;
      if (inner?.error) return inner.error;
      if (inner?.message) return inner.message;
    }
    if (err instanceof Error) return err.message;
    return 'Request failed.';
  }
}
