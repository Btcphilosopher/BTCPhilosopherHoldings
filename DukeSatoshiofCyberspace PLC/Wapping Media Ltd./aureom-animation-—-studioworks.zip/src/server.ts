import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {createServer} from 'node:http';
import {join} from 'node:path';
import {WebSocket, WebSocketServer} from 'ws';
import {StudioDatabase} from './server/database';
import {type BroadcastEvent, createApiRouter} from './server/routes';

const browserDistFolder = join(import.meta.dirname, '../browser');
const assetsImagesFolder = join(process.cwd(), 'src/assets/images');

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({noServer: true});
const angularApp = new AngularNodeAppEngine();

const db = new StudioDatabase(join(process.cwd(), 'data'));

const clients = new Set<WebSocket>();
wss.on('connection', (ws) => {
  clients.add(ws);
  ws.send(JSON.stringify({type: 'connected', timestamp: new Date().toISOString()}));
  ws.on('close', () => {
    clients.delete(ws);
  });
});

function broadcast(event: BroadcastEvent): void {
  const payload = JSON.stringify(event);
  for (const ws of clients) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
    }
  }
}

// WebSocket upgrade middleware BEFORE Angular SSR catch-all
app.use('/api', (req, _res, next) => {
  if (req.path === '/live' && req.headers.upgrade?.toLowerCase() === 'websocket') {
    wss.handleUpgrade(req, req.socket, Buffer.alloc(0), (ws) => {
      wss.emit('connection', ws, req);
    });
    return;
  }
  next();
});

app.use('/api', createApiRouter(db, broadcast, process.cwd()));

// Serve generated assets cleanly in dev & SSR
app.use('/assets/images', express.static(assetsImagesFolder, {maxAge: '1d'}));
app.use('/src/assets/images', express.static(assetsImagesFolder, {maxAge: '1d'}));

app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  server.listen(port, () => {
    console.log(`Aureom StudioWorks listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
