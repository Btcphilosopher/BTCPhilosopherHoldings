package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.FoxContentRepository
import com.example.data.repository.FoxPreferencesRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("FOX TV", appName)
    }

    @Test
    fun `verify fox content catalogue and live channels`() {
        val hero = FoxContentRepository.heroShow
        assertNotNull(hero)
        assertEquals("Shadow City", hero.title)

        val channels = FoxContentRepository.liveChannels
        assertTrue("Live channels should have at least 5 channels", channels.size >= 5)

        val searchResults = FoxContentRepository.searchAll("Shadow")
        assertTrue("Search should find Shadow City", searchResults.any { it.title.contains("Shadow City") })
    }

    @Test
    fun `verify my list and profile state`() {
        val initialInList = FoxPreferencesRepository.isInMyList("test_item_id")
        assertFalse(initialInList)

        FoxPreferencesRepository.toggleMyList("test_item_id")
        assertTrue(FoxPreferencesRepository.isInMyList("test_item_id"))

        FoxPreferencesRepository.toggleMyList("test_item_id")
        assertFalse(FoxPreferencesRepository.isInMyList("test_item_id"))
    }
}
