package com.example.data.repository

import com.example.data.model.SubscriptionTier
import com.example.data.model.UserProfile
import com.example.data.model.WatchProgress
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PlaybackEvent(
    val timestamp: String,
    val eventType: String,
    val details: String,
    val bitrate: String = "12.4 Mbps"
)

object FoxPreferencesRepository {

    val defaultProfiles = listOf(
        UserProfile("prof_1", "Primary Account", 0xFF0062FF, isKidsMode = false, hasPinProtection = false),
        UserProfile("prof_2", "Family Living Room", 0xFF00C853, isKidsMode = false, hasPinProtection = false),
        UserProfile("prof_3", "FOX Kids & Animation", 0xFFFF9100, isKidsMode = true, hasPinProtection = true, pinCode = "1234"),
        UserProfile("prof_4", "Sports Fan", 0xFFFFD600, isKidsMode = false, hasPinProtection = false)
    )

    private val _profiles = MutableStateFlow(defaultProfiles)
    val profiles: StateFlow<List<UserProfile>> = _profiles.asStateFlow()

    private val _activeProfile = MutableStateFlow(defaultProfiles[0])
    val activeProfile: StateFlow<UserProfile> = _activeProfile.asStateFlow()

    private val _myList = MutableStateFlow<Set<String>>(setOf("fox_hero_shadow_city", "fox_the_cleaning_lady", "fox_masterchef"))
    val myList: StateFlow<Set<String>> = _myList.asStateFlow()

    private val _continueWatching = MutableStateFlow<List<WatchProgress>>(
        listOf(
            WatchProgress("fox_hero_shadow_city", "Shadow City", "", 32 * 60 * 1000L, 58 * 60 * 1000L, "S1:E3 Crossfire Protocol"),
            WatchProgress("fox_rescue_hisurf", "Rescue: HI-Surf", "", 24 * 60 * 1000L, 44 * 60 * 1000L, "S1:E1 Mauka to Makai"),
            WatchProgress("fox_masterchef", "MasterChef: Generations", "", 18 * 60 * 1000L, 45 * 60 * 1000L, "S14:E4 Mystery Box Challenge")
        )
    )
    val continueWatching: StateFlow<List<WatchProgress>> = _continueWatching.asStateFlow()

    private val _subscriptionTier = MutableStateFlow(SubscriptionTier.TV_PROVIDER_LINKED)
    val subscriptionTier: StateFlow<SubscriptionTier> = _subscriptionTier.asStateFlow()

    private val _isTvMode = MutableStateFlow(false)
    val isTvMode: StateFlow<Boolean> = _isTvMode.asStateFlow()

    private val _isPersonalisationEnabled = MutableStateFlow(true)
    val isPersonalisationEnabled: StateFlow<Boolean> = _isPersonalisationEnabled.asStateFlow()

    private val _connectedDevices = MutableStateFlow(
        listOf(
            "Sony BRAVIA Google TV 65\" (Living Room)",
            "Samsung Galaxy Tab S9 Ultra (Master Bedroom)",
            "Pixel 9 Pro (Active Mobile)"
        )
    )
    val connectedDevices: StateFlow<List<String>> = _connectedDevices.asStateFlow()

    private val _playbackEvents = MutableStateFlow<List<PlaybackEvent>>(
        listOf(
            PlaybackEvent("12:04:11", "PLAYBACK_START", "Stream: HLS Adaptive 1080p60", "12.4 Mbps"),
            PlaybackEvent("12:04:13", "BUFFERING_RESOLVED", "Buffer size 4.2 MB in 180ms", "12.4 Mbps"),
            PlaybackEvent("12:08:45", "BITRATE_RAMP_UP", "Switched from 720p to 1080p HDR", "14.8 Mbps")
        )
    )
    val playbackEvents: StateFlow<List<PlaybackEvent>> = _playbackEvents.asStateFlow()

    fun switchProfile(profile: UserProfile) {
        _activeProfile.value = profile
    }

    fun toggleMyList(mediaId: String) {
        val current = _myList.value.toMutableSet()
        if (current.contains(mediaId)) {
            current.remove(mediaId)
        } else {
            current.add(mediaId)
        }
        _myList.value = current
    }

    fun isInMyList(mediaId: String): Boolean {
        return _myList.value.contains(mediaId)
    }

    fun updateWatchProgress(mediaId: String, title: String, positionMs: Long, durationMs: Long, epInfo: String? = null) {
        val existing = _continueWatching.value.toMutableList()
        val index = existing.indexOfFirst { it.mediaId == mediaId }
        val newProgress = WatchProgress(mediaId, title, "", positionMs, durationMs, epInfo)
        if (index >= 0) {
            existing[index] = newProgress
        } else {
            existing.add(0, newProgress)
        }
        _continueWatching.value = existing
    }

    fun setSubscriptionTier(tier: SubscriptionTier) {
        _subscriptionTier.value = tier
    }

    fun toggleTvMode() {
        _isTvMode.value = !_isTvMode.value
    }

    fun setTvMode(enabled: Boolean) {
        _isTvMode.value = enabled
    }

    fun togglePersonalisation() {
        _isPersonalisationEnabled.value = !_isPersonalisationEnabled.value
    }

    fun logPlaybackEvent(eventType: String, details: String, bitrate: String = "12.4 Mbps") {
        val current = _playbackEvents.value.toMutableList()
        val timeString = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        current.add(0, PlaybackEvent(timeString, eventType, details, bitrate))
        if (current.size > 25) {
            current.removeAt(current.lastIndex)
        }
        _playbackEvents.value = current
    }

    fun removeDevice(device: String) {
        val list = _connectedDevices.value.toMutableList()
        list.remove(device)
        _connectedDevices.value = list
    }
}
