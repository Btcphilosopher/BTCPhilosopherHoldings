package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Category
import com.example.data.model.MediaItem
import com.example.data.repository.FoxContentRepository
import com.example.data.repository.FoxPreferencesRepository
import com.example.ui.components.ContentCard
import com.example.ui.components.QualityBadge
import com.example.ui.theme.FoxBorder
import com.example.ui.theme.FoxBrandBlue
import com.example.ui.theme.FoxMidnightNavy
import com.example.ui.theme.FoxSportsGold
import com.example.ui.theme.FoxSurfaceCard
import com.example.ui.theme.FoxSurfaceElevated
import com.example.ui.theme.FoxTextMuted
import com.example.ui.theme.FoxTextPrimary
import com.example.ui.theme.FoxTextSecondary

@Composable
fun ShowsScreen(
    onPlayMedia: (title: String, url: String, isLive: Boolean, epInfo: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf<Category?>(null) }
    var selectedShowForDetail by remember { mutableStateOf<MediaItem?>(null) }

    val categories = listOf(
        null to "All Shows",
        Category.DRAMA to "Drama & Crime",
        Category.COMEDY to "Comedy",
        Category.ANIMATION to "Animation",
        Category.REALITY to "Reality & Competition",
        Category.SPORTS to "Sports Originals"
    )

    val shows = remember(selectedCategory) {
        if (selectedCategory == null) {
            FoxContentRepository.allShows
        } else {
            FoxContentRepository.getShowsByCategory(selectedCategory!!)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(FoxMidnightNavy)
            .testTag("shows_screen")
    ) {
        // Genre Filters Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(FoxSurfaceCard)
                .padding(vertical = 10.dp)
        ) {
            Text(
                text = "ON-DEMAND SHOWS & SERIES",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { (cat, label) ->
                    val isSelected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) FoxBrandBlue else FoxSurfaceElevated)
                            .border(1.dp, if (isSelected) FoxSportsGold else FoxBorder, RoundedCornerShape(16.dp))
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) Color.White else FoxTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Grid of Shows
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 140.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(shows, key = { it.id }) { show ->
                ContentCard(
                    item = show,
                    cardWidth = 160.dp,
                    cardHeight = 220.dp,
                    onClick = { selectedShowForDetail = show }
                )
            }
        }
    }

    // Show Detail Modal
    selectedShowForDetail?.let { show ->
        ShowDetailDialog(
            show = show,
            onDismiss = { selectedShowForDetail = null },
            onPlay = { epTitle, streamUrl ->
                selectedShowForDetail = null
                onPlayMedia(show.title, streamUrl, false, epTitle)
            }
        )
    }
}

@Composable
fun ShowDetailDialog(
    show: MediaItem,
    onDismiss: () -> Unit,
    onPlay: (epTitle: String, streamUrl: String) -> Unit
) {
    val myList by FoxPreferencesRepository.myList.collectAsState()
    val inList = myList.contains(show.id)
    var selectedSeason by remember { mutableIntStateOf(1) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxSize(0.90f)
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, FoxBorder, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = FoxMidnightNavy)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header Bar with Close Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(FoxSurfaceCard)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = show.title.uppercase(),
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }
                }

                // Scrollable Content
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    item {
                        // Badges & metadata
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            QualityBadge(text = show.rating)
                            QualityBadge(text = "${show.releaseYear}")
                            QualityBadge(text = "${show.seasonsCount} Seasons", isGold = true)
                            if (show.isOriginal) {
                                QualityBadge(text = "FOX ORIGINAL", isBlue = true)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = show.synopsis,
                            color = FoxTextSecondary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        if (show.cast.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "STARRING: ${show.cast.joinToString(", ")}",
                                color = FoxSportsGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Action Buttons
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    val firstEp = show.episodes.firstOrNull()
                                    onPlay(firstEp?.title ?: "S1:E1", firstEp?.streamUrl ?: show.videoStreamUrl)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = FoxBrandBlue),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play")
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("PLAY S1:E1", fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { FoxPreferencesRepository.toggleMyList(show.id) },
                                shape = RoundedCornerShape(6.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, FoxBorder)
                            ) {
                                Icon(
                                    imageVector = if (inList) Icons.Default.Check else Icons.Default.Add,
                                    contentDescription = "List",
                                    tint = if (inList) FoxSportsGold else Color.White
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (inList) "IN MY LIST" else "ADD TO MY LIST",
                                    color = Color.White
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Episodes Section Header
                        Text(
                            text = "EPISODES",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    // Episode List
                    if (show.episodes.isNotEmpty()) {
                        items(show.episodes) { ep ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(FoxSurfaceCard)
                                    .border(1.dp, FoxBorder, RoundedCornerShape(8.dp))
                                    .clickable { onPlay(ep.title, ep.streamUrl) }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(FoxBrandBlue),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${ep.episodeNumber}",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "E${ep.episodeNumber}: ${ep.title}",
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = ep.synopsis,
                                        color = FoxTextSecondary,
                                        fontSize = 11.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "${ep.durationMinutes} min",
                                        color = FoxTextMuted,
                                        fontSize = 10.sp
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Play Episode",
                                    tint = FoxSportsGold,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    } else {
                        item {
                            Text(
                                text = "Full series episodes available on broadcast schedule.",
                                color = FoxTextMuted,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
