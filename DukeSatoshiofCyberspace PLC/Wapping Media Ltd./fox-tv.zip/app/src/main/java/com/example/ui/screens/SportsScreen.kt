package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsFootball
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.SportsFixture
import com.example.data.repository.FoxContentRepository
import com.example.ui.components.LiveBadge
import com.example.ui.components.QualityBadge
import com.example.ui.theme.FoxBorder
import com.example.ui.theme.FoxBrandBlue
import com.example.ui.theme.FoxMidnightNavy
import com.example.ui.theme.FoxSportsGold
import com.example.ui.theme.FoxSurfaceCard
import com.example.ui.theme.FoxSurfaceElevated
import com.example.ui.theme.FoxTextMuted
import com.example.ui.theme.FoxTextPrimary
import com.example.ui.theme.FoxTextSecondary

@Composable
fun SportsScreen(
    onPlayGame: (title: String, url: String, isLive: Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedLeague by remember { mutableStateOf("All") }
    val leagues = listOf("All", "NFL", "MLB on FOX", "College Football", "NASCAR on FOX")

    val fixtures = remember(selectedLeague) {
        if (selectedLeague == "All") {
            FoxContentRepository.sportsFixtures
        } else {
            FoxContentRepository.sportsFixtures.filter { it.league.contains(selectedLeague, ignoreCase = true) }
        }
    }

    val liveGame = fixtures.firstOrNull { it.isLive }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(FoxMidnightNavy)
            .testTag("sports_screen"),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // FOX Sports Hero Visual Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.fox_sports_banner_1793634259304),
                    contentDescription = "FOX Sports",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    FoxMidnightNavy.copy(alpha = 0.5f),
                                    FoxMidnightNavy
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    QualityBadge(text = "LIVE ON FOX & FS1", isGold = true)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "FOX SPORTS CENTER",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Live coverage, real-time scores, and game day replays",
                        color = FoxTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // League Filter Pills
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(leagues) { lg ->
                    val isSelected = selectedLeague == lg
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) FoxSportsGold else FoxSurfaceElevated)
                            .border(1.dp, if (isSelected) Color.White else FoxBorder, RoundedCornerShape(16.dp))
                            .clickable { selectedLeague = lg }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = lg,
                            color = if (isSelected) FoxMidnightNavy else FoxTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Scoreboard & Fixture Cards
        item {
            Text(
                text = "LIVE SCORES & FIXTURES",
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }

        items(fixtures, key = { it.id }) { fixture ->
            SportsFixtureCard(
                fixture = fixture,
                onWatch = {
                    onPlayGame("${fixture.teamHome} vs ${fixture.teamAway}", fixture.streamUrl, fixture.isLive)
                },
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
fun SportsFixtureCard(
    fixture: SportsFixture,
    onWatch: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(FoxSurfaceCard)
            .border(1.dp, if (fixture.isLive) FoxSportsGold else FoxBorder, RoundedCornerShape(8.dp))
            .padding(14.dp)
            .testTag("sports_card_${fixture.id}")
    ) {
        // Top status line
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                QualityBadge(text = fixture.league, isGold = true)
                Spacer(modifier = Modifier.width(6.dp))
                if (fixture.isLive) {
                    LiveBadge()
                    Spacer(modifier = Modifier.width(6.dp))
                }
                Text(
                    text = fixture.periodOrStatus,
                    color = if (fixture.isLive) Color(0xFFFF5252) else FoxSportsGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = fixture.channelName,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Teams & Scores
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                // Team Home
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = fixture.teamHome,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (fixture.scoreHome != null) {
                        Text(
                            text = "${fixture.scoreHome}",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Team Away
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = fixture.teamAway,
                        color = FoxTextSecondary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (fixture.scoreAway != null) {
                        Text(
                            text = "${fixture.scoreAway}",
                            color = FoxTextSecondary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }

        if (fixture.headline.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = fixture.headline,
                color = FoxTextMuted,
                fontSize = 11.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Watch button
        Button(
            onClick = onWatch,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (fixture.isLive) FoxBrandBlue else FoxSurfaceElevated,
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(38.dp)
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "Watch",
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (fixture.isLive) "WATCH LIVE ON ${fixture.channelName}" else "WATCH REPLAY & HIGHLIGHTS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
