package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// FOX TV Signature Color Palette
val FoxMidnightNavy = Color(0xFF030C1A)
val FoxDeepBlue = Color(0xFF071833)
val FoxSurfaceCard = Color(0xFF0E2244)
val FoxSurfaceElevated = Color(0xFF142E5C)
val FoxBorder = Color(0xFF1F3D73)

val FoxBrandBlue = Color(0xFF0062FF)
val FoxBrightBlue = Color(0xFF2979FF)
val FoxCyanAccent = Color(0xFF00E5FF)

val FoxLiveRed = Color(0xFFE50914)
val FoxLiveRedGlow = Color(0xFFFF334B)

val FoxSportsGold = Color(0xFFFFB703)
val FoxSportsGoldBright = Color(0xFFFFD166)

val FoxTextPrimary = Color(0xFFFFFFFF)
val FoxTextSecondary = Color(0xFFB0BDD4)
val FoxTextMuted = Color(0xFF6B7E9E)

val FoxBackgroundDark = Color(0xFF020710)
val FoxSurfaceDark = Color(0xFF091426)
