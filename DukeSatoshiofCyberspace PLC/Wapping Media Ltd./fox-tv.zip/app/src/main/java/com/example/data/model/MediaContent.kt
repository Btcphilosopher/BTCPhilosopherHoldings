package com.example.data.model

data class MediaItem(
    val id: String,
    val title: String,
    val synopsis: String,
    val category: Category,
    val genre: String,
    val rating: String, // e.g. TV-14, TV-MA, TV-PG
    val releaseYear: Int,
    val durationMinutes: Int = 45,
    val backdropUrl: String = "",
    val posterUrl: String = "",
    val videoStreamUrl: String, // Genuine HLS or MP4 stream
    val isLive: Boolean = false,
    val isOriginal: Boolean = false,
    val seasonsCount: Int = 1,
    val episodes: List<Episode> = emptyList(),
    val cast: List<String> = emptyList(),
    val tags: List<String> = emptyList()
)

enum class Category {
    DRAMA,
    COMEDY,
    REALITY,
    ANIMATION,
    SPORTS,
    NEWS,
    CRIME,
    DOCUMENTARY,
    SPECIAL
}

data class Episode(
    val episodeNumber: Int,
    val seasonNumber: Int,
    val title: String,
    val synopsis: String,
    val durationMinutes: Int,
    val streamUrl: String,
    val thumbnail: String = ""
)

data class LiveChannel(
    val id: String,
    val channelNumber: String,
    val name: String,
    val callSign: String,
    val category: String, // Entertainment, News, Sports, Weather, Local
    val logoText: String,
    val streamUrl: String,
    val resolution: String = "1080p 60fps",
    val bitRate: String = "8.5 Mbps",
    val isHd: Boolean = true,
    val currentProgram: EpgProgram,
    val upcomingPrograms: List<EpgProgram> = emptyList()
)

data class EpgProgram(
    val id: String,
    val title: String,
    val description: String,
    val startTimeFormatted: String,
    val endTimeFormatted: String,
    val durationMinutes: Int,
    val progressPercentage: Float = 0.45f,
    val rating: String = "TV-14",
    val liveTag: Boolean = true,
    val streamUrl: String = ""
)

data class NewsArticle(
    val id: String,
    val headline: String,
    val summary: String,
    val body: String,
    val category: String, // Politics, US, World, Business, Tech, Opinion
    val author: String,
    val timestamp: String,
    val isBreaking: Boolean = false,
    val videoUrl: String? = null,
    val imageUrl: String = ""
)

data class SportsFixture(
    val id: String,
    val league: String, // NFL, MLB, MLS, College Football, NASCAR
    val teamHome: String,
    val teamAway: String,
    val scoreHome: Int? = null,
    val scoreAway: Int? = null,
    val periodOrStatus: String, // "4th Qtr 2:14", "Final", "Today 8:00 PM ET", "Live"
    val channelName: String = "FOX",
    val isLive: Boolean = false,
    val streamUrl: String,
    val venue: String = "",
    val headline: String = ""
)

data class UserProfile(
    val id: String,
    val name: String,
    val avatarColorHex: Long,
    val isKidsMode: Boolean = false,
    val hasPinProtection: Boolean = false,
    val pinCode: String = "1234",
    val favoriteGenres: List<String> = listOf("Drama", "Sports")
)

data class WatchProgress(
    val mediaId: String,
    val title: String,
    val posterUrl: String,
    val lastPositionMs: Long,
    val totalDurationMs: Long,
    val episodeInfo: String? = null
) {
    val progressFraction: Float
        get() = if (totalDurationMs > 0) (lastPositionMs.toFloat() / totalDurationMs).coerceIn(0f, 1f) else 0f
}

enum class SubscriptionTier(val title: String, val price: String, val badge: String) {
    FREE_AD_SUPPORTED("FOX Basic (Ad-Supported)", "Free", "FREE"),
    FOX_ALL_ACCESS("FOX+ All-Access Pass", "$9.99/mo", "PREMIUM"),
    TV_PROVIDER_LINKED("Pay-TV / Cable Auth", "Included with Cable", "VERIFIED")
}
