package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.data.model.MediaItem
import com.example.data.repository.FoxContentRepository
import com.example.data.repository.FoxPreferencesRepository
import com.example.ui.components.FoxBottomBar
import com.example.ui.components.FoxTab
import com.example.ui.components.FoxTopBar
import com.example.ui.components.TvRemoteOverlay
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LiveTvScreen
import com.example.ui.screens.NewsScreen
import com.example.ui.screens.PlayerScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.ShowDetailDialog
import com.example.ui.screens.ShowsScreen
import com.example.ui.screens.SportsScreen
import com.example.ui.theme.FoxMidnightNavy
import com.example.ui.theme.FoxTvTheme

data class ActivePlayback(
    val title: String,
    val streamUrl: String,
    val isLive: Boolean,
    val subtitleInfo: String = "1080p 60fps • 5.1 Dolby Audio",
    val initialPositionMs: Long = 0L
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FoxTvTheme {
                FoxTvApp()
            }
        }
    }
}

@Composable
fun FoxTvApp() {
    var currentTab by remember { mutableStateOf(FoxTab.HOME) }
    var activePlayback by remember { mutableStateOf<ActivePlayback?>(null) }
    var selectedShowForDetail by remember { mutableStateOf<MediaItem?>(null) }

    val activeProfile by FoxPreferencesRepository.activeProfile.collectAsState()
    val isTvMode by FoxPreferencesRepository.isTvMode.collectAsState()

    // Handle back button: if playing, close player; if on subtab, return to HOME
    BackHandler(enabled = activePlayback != null || currentTab != FoxTab.HOME) {
        if (activePlayback != null) {
            activePlayback = null
        } else if (currentTab != FoxTab.HOME) {
            currentTab = FoxTab.HOME
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FoxMidnightNavy)
            .testTag("fox_app_root")
    ) {
        if (activePlayback != null) {
            // Full screen television player
            val playback = activePlayback!!
            PlayerScreen(
                title = playback.title,
                streamUrl = playback.streamUrl,
                isLive = playback.isLive,
                subtitleInfo = playback.subtitleInfo,
                initialPositionMs = playback.initialPositionMs,
                onClose = { activePlayback = null },
                onNextEpisode = {
                    // Quick next stream demo
                    activePlayback = ActivePlayback(
                        title = "${playback.title} (Part 2)",
                        streamUrl = playback.streamUrl,
                        isLive = playback.isLive,
                        subtitleInfo = "Next Segment • 1080p"
                    )
                }
            )
        } else {
            // Main Network Application Navigation
            Scaffold(
                topBar = {
                    FoxTopBar(
                        currentTab = currentTab,
                        onTabSelected = { currentTab = it },
                        isTvMode = isTvMode,
                        onToggleTvMode = { FoxPreferencesRepository.toggleTvMode() },
                        activeProfile = activeProfile
                    )
                },
                bottomBar = {
                    FoxBottomBar(
                        currentTab = currentTab,
                        onTabSelected = { currentTab = it }
                    )
                },
                containerColor = FoxMidnightNavy
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    Crossfade(
                        targetState = currentTab,
                        label = "tab_crossfade"
                    ) { tab ->
                        when (tab) {
                            FoxTab.HOME -> HomeScreen(
                                onPlayMedia = { title, url, isLive, epInfo ->
                                    activePlayback = ActivePlayback(title, url, isLive, epInfo)
                                },
                                onShowDetail = { selectedShowForDetail = it }
                            )

                            FoxTab.LIVE_TV -> LiveTvScreen(
                                onPlayChannel = { channel ->
                                    activePlayback = ActivePlayback(
                                        title = channel.name,
                                        streamUrl = channel.streamUrl,
                                        isLive = true,
                                        subtitleInfo = "${channel.currentProgram.title} • ${channel.resolution}"
                                    )
                                }
                            )

                            FoxTab.SHOWS -> ShowsScreen(
                                onPlayMedia = { title, url, isLive, epInfo ->
                                    activePlayback = ActivePlayback(title, url, isLive, epInfo)
                                }
                            )

                            FoxTab.SPORTS -> SportsScreen(
                                onPlayGame = { title, url, isLive ->
                                    activePlayback = ActivePlayback(
                                        title = title,
                                        streamUrl = url,
                                        isLive = isLive,
                                        subtitleInfo = "FOX Sports Broadcast • Live"
                                    )
                                }
                            )

                            FoxTab.NEWS -> NewsScreen(
                                onPlayLiveNews = { title, url ->
                                    activePlayback = ActivePlayback(
                                        title = title,
                                        streamUrl = url,
                                        isLive = true,
                                        subtitleInfo = "FOX News Live • Breaking Coverage"
                                    )
                                }
                            )

                            FoxTab.SEARCH -> SearchScreen(
                                onPlayMedia = { title, url, isLive, epInfo ->
                                    activePlayback = ActivePlayback(title, url, isLive, epInfo)
                                }
                            )

                            FoxTab.PROFILE -> ProfileScreen(
                                onPlayMedia = { title, url, isLive, epInfo ->
                                    activePlayback = ActivePlayback(title, url, isLive, epInfo)
                                }
                            )

                            FoxTab.ADMIN -> AdminDashboardScreen()
                        }
                    }

                    // 10-foot Television Remote Overlay (when TV mode is active)
                    TvRemoteOverlay(
                        isTvMode = isTvMode,
                        onCloseTvMode = { FoxPreferencesRepository.setTvMode(false) },
                        onChannelChange = { ch ->
                            activePlayback = ActivePlayback(
                                title = ch.name,
                                streamUrl = ch.streamUrl,
                                isLive = true,
                                subtitleInfo = "${ch.currentProgram.title} • Live"
                            )
                        },
                        onSelectAction = {
                            val hero = FoxContentRepository.heroShow
                            activePlayback = ActivePlayback(hero.title, hero.videoStreamUrl, false, "Season 1 • Episode 1")
                        },
                        onNavigateTab = { tab ->
                            currentTab = tab
                        }
                    )
                }
            }

            // Global Show Detail Modal (accessible from any screen)
            selectedShowForDetail?.let { show ->
                ShowDetailDialog(
                    show = show,
                    onDismiss = { selectedShowForDetail = null },
                    onPlay = { epTitle, streamUrl ->
                        selectedShowForDetail = null
                        activePlayback = ActivePlayback(show.title, streamUrl, false, epTitle)
                    }
                )
            }
        }
    }
}
