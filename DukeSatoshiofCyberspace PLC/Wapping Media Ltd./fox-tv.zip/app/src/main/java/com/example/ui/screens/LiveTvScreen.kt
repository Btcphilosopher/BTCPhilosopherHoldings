package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LiveChannel
import com.example.data.repository.FoxContentRepository
import com.example.ui.components.LiveBadge
import com.example.ui.components.QualityBadge
import com.example.ui.theme.FoxBorder
import com.example.ui.theme.FoxBrandBlue
import com.example.ui.theme.FoxMidnightNavy
import com.example.ui.theme.FoxSportsGold
import com.example.ui.theme.FoxSurfaceCard
import com.example.ui.theme.FoxSurfaceElevated
import com.example.ui.theme.FoxTextMuted
import com.example.ui.theme.FoxTextPrimary
import com.example.ui.theme.FoxTextSecondary

@Composable
fun LiveTvScreen(
    onPlayChannel: (channel: LiveChannel) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf("All") }
    var favoriteChannelIds by remember { mutableStateOf(setOf("fox_network_east", "fox_sports_1")) }
    var selectedChannelForDetail by remember { mutableStateOf<LiveChannel?>(null) }
    var reminderSetPrograms by remember { mutableStateOf(setOf<String>()) }

    val categories = listOf("All", "Entertainment", "Sports", "News", "Weather", "Local", "★ Favorites")

    val filteredChannels = remember(selectedCategory, favoriteChannelIds) {
        val all = FoxContentRepository.liveChannels
        when (selectedCategory) {
            "All" -> all
            "★ Favorites" -> all.filter { favoriteChannelIds.contains(it.id) }
            else -> all.filter { it.category.equals(selectedCategory, ignoreCase = true) }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(FoxMidnightNavy)
            .testTag("live_tv_screen")
    ) {
        // EPG Header & Category Filters
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(FoxSurfaceCard)
                .padding(top = 12.dp, bottom = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "ELECTRONIC PROGRAM GUIDE",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    LiveBadge()
                }

                Text(
                    text = "TIMEZONE: ET (EASTERN)",
                    color = FoxSportsGold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Category Filter Pills
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) FoxBrandBlue else FoxSurfaceElevated)
                            .border(1.dp, if (isSelected) FoxSportsGold else FoxBorder, RoundedCornerShape(16.dp))
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .testTag("live_cat_$cat")
                    ) {
                        Text(
                            text = cat,
                            color = if (isSelected) Color.White else FoxTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Time Slots Header Timeline (Current, +30m, +1h, +1.5h)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF061324))
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.width(90.dp)) {
                    Text("CHANNEL", color = FoxTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("NOW ON AIR", color = FoxSportsGold, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                    Text("COMING UP NEXT", color = FoxTextMuted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // Channels and Programmes EPG List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(filteredChannels, key = { it.id }) { channel ->
                val isFav = favoriteChannelIds.contains(channel.id)
                val isSelected = selectedChannelForDetail?.id == channel.id

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isSelected) FoxSurfaceElevated else Color.Transparent)
                        .border(width = 0.5.dp, color = FoxBorder)
                        .clickable { selectedChannelForDetail = channel }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .testTag("epg_channel_row_${channel.channelNumber}")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Channel Logo & Number Column
                        Column(
                            modifier = Modifier
                                .width(90.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(FoxSurfaceCard)
                                .border(1.dp, FoxBorder, RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "CH ${channel.channelNumber}",
                                    color = FoxSportsGold,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Icon(
                                    imageVector = if (isFav) Icons.Default.Star else Icons.Outlined.StarBorder,
                                    contentDescription = "Favorite",
                                    tint = if (isFav) FoxSportsGold else FoxTextMuted,
                                    modifier = Modifier
                                        .size(14.dp)
                                        .clickable {
                                            favoriteChannelIds = if (isFav) {
                                                favoriteChannelIds - channel.id
                                            } else {
                                                favoriteChannelIds + channel.id
                                            }
                                        }
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = channel.logoText,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )

                            Text(
                                text = channel.callSign,
                                color = FoxTextSecondary,
                                fontSize = 9.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        // Current Airing Programme Details
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = channel.currentProgram.title,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    QualityBadge(text = channel.currentProgram.rating)
                                }

                                Text(
                                    text = "${channel.currentProgram.startTimeFormatted} - ${channel.currentProgram.endTimeFormatted}",
                                    color = FoxTextSecondary,
                                    fontSize = 10.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = channel.currentProgram.description,
                                color = FoxTextSecondary,
                                fontSize = 11.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            // Live Progress Bar
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                LinearProgressIndicator(
                                    progress = { channel.currentProgram.progressPercentage },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(3.dp)
                                        .clip(RoundedCornerShape(2.dp)),
                                    color = FoxBrandBlue,
                                    trackColor = Color.White.copy(alpha = 0.15f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${channel.resolution} • ${channel.bitRate}",
                                    color = FoxTextMuted,
                                    fontSize = 9.sp
                                )
                            }

                            // Next upcoming show teaser
                            if (channel.upcomingPrograms.isNotEmpty()) {
                                val next = channel.upcomingPrograms.first()
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "NEXT: ${next.startTimeFormatted} • ${next.title}",
                                        color = FoxTextMuted,
                                        fontSize = 10.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    val hasReminder = reminderSetPrograms.contains(next.id)
                                    IconButton(
                                        onClick = {
                                            reminderSetPrograms = if (hasReminder) {
                                                reminderSetPrograms - next.id
                                            } else {
                                                reminderSetPrograms + next.id
                                            }
                                        },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Notifications,
                                            contentDescription = "Set Reminder",
                                            tint = if (hasReminder) FoxSportsGold else FoxTextMuted,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Quick Watch Live Action Button
                        Button(
                            onClick = { onPlayChannel(channel) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = FoxBrandBlue,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .height(38.dp)
                                .testTag("watch_live_btn_${channel.channelNumber}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Watch",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "WATCH",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
