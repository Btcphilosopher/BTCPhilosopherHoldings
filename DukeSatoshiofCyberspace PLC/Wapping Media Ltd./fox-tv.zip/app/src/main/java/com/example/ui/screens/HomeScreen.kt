package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Category
import com.example.data.model.MediaItem
import com.example.data.repository.FoxContentRepository
import com.example.data.repository.FoxPreferencesRepository
import com.example.ui.components.ContentRail
import com.example.ui.components.LiveBadge
import com.example.ui.components.QualityBadge
import com.example.ui.theme.FoxBorder
import com.example.ui.theme.FoxBrandBlue
import com.example.ui.theme.FoxMidnightNavy
import com.example.ui.theme.FoxSportsGold
import com.example.ui.theme.FoxSurfaceCard
import com.example.ui.theme.FoxTextMuted
import com.example.ui.theme.FoxTextPrimary
import com.example.ui.theme.FoxTextSecondary

@Composable
fun HomeScreen(
    onPlayMedia: (title: String, url: String, isLive: Boolean, epInfo: String) -> Unit,
    onShowDetail: (MediaItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val myList by FoxPreferencesRepository.myList.collectAsState()
    val continueWatching by FoxPreferencesRepository.continueWatching.collectAsState()
    val hero = FoxContentRepository.heroShow
    val inMyList = myList.contains(hero.id)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(FoxMidnightNavy)
            .verticalScroll(scrollState)
            .testTag("home_screen_scroll")
    ) {
        // Large Editorial Hero Area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(380.dp)
        ) {
            // Hero Backdrop Image (authentic generated key visual)
            Image(
                painter = painterResource(id = R.drawable.fox_hero_banner_1793634245562),
                contentDescription = hero.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Cinematic Gradient Vignette (bottom and left dark fade)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                FoxMidnightNavy.copy(alpha = 0.5f),
                                FoxMidnightNavy.copy(alpha = 0.95f),
                                FoxMidnightNavy
                            )
                        )
                    )
            )

            // Hero Editorial Details
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Network badge & tags
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    QualityBadge(text = "FOX ORIGINAL", isBlue = true)
                    QualityBadge(text = hero.rating)
                    QualityBadge(text = "4K UHD", isGold = true)
                    QualityBadge(text = "5.1 SURROUND")
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = hero.title,
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = hero.synopsis,
                    color = FoxTextSecondary,
                    fontSize = 12.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 16.sp,
                    modifier = Modifier.fillMaxWidth(0.92f)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Hero Action Buttons (Play, Watch Live, Add to My List, Details)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            onPlayMedia(hero.title, hero.videoStreamUrl, false, "Season 1 • Episode 1")
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FoxBrandBlue,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("hero_play_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "PLAY S1:E1",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            FoxPreferencesRepository.toggleMyList(hero.id)
                        },
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color.White
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, FoxBorder),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("hero_add_list_button")
                    ) {
                        Icon(
                            imageVector = if (inMyList) Icons.Default.Check else Icons.Default.Add,
                            contentDescription = "My List",
                            tint = if (inMyList) FoxSportsGold else Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (inMyList) "IN LIST" else "MY LIST",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(FoxSurfaceCard)
                            .border(1.dp, FoxBorder, RoundedCornerShape(6.dp))
                            .clickable { onShowDetail(hero) }
                            .padding(horizontal = 10.dp, vertical = 9.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Details",
                            tint = FoxTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Live Right Now Banner (Prominent television network feature)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF2A0808),
                            FoxSurfaceCard,
                            Color(0xFF091426)
                        )
                    )
                )
                .border(1.dp, Color(0xFF6B1D1D), RoundedCornerShape(8.dp))
                .clickable {
                    val liveCh = FoxContentRepository.liveChannels.first()
                    onPlayMedia(liveCh.name, liveCh.streamUrl, true, liveCh.currentProgram.title)
                }
                .padding(14.dp)
                .testTag("home_live_now_card")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    LiveBadge()
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "ON AIR: FOX Network Primetime",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Shadow City (Live Broadcast) • 1080p 60fps HDR",
                            color = FoxTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(FoxBrandBlue)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "WATCH LIVE",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Programme Rails
        // 1. Continue Watching
        if (continueWatching.isNotEmpty()) {
            val continueItems = continueWatching.mapNotNull { cw ->
                FoxContentRepository.allShows.find { it.id == cw.mediaId || it.title == cw.title }
            }
            if (continueItems.isNotEmpty()) {
                ContentRail(
                    title = "Continue Watching",
                    subtitle = "Resume where you left off",
                    items = continueItems,
                    onItemClick = { item ->
                        val cw = continueWatching.find { it.mediaId == item.id || it.title == item.title }
                        onPlayMedia(
                            item.title,
                            item.videoStreamUrl,
                            item.isLive,
                            cw?.episodeInfo ?: "Episode 1"
                        )
                    }
                )
            }
        }

        // 2. Popular on FOX
        ContentRail(
            title = "Popular on FOX",
            badgeText = "TOP 10",
            items = FoxContentRepository.allShows.take(5),
            onItemClick = onShowDetail
        )

        // 3. FOX Originals
        ContentRail(
            title = "FOX Originals",
            subtitle = "Exclusive Network Series",
            items = FoxContentRepository.allShows.filter { it.isOriginal },
            onItemClick = onShowDetail
        )

        // 4. Drama & Thrillers
        ContentRail(
            title = "Drama & Crime",
            items = FoxContentRepository.getShowsByCategory(Category.DRAMA),
            onItemClick = onShowDetail
        )

        // 5. Animation Domination
        ContentRail(
            title = "Animation Domination",
            subtitle = "Sunday Night Legends",
            items = FoxContentRepository.getShowsByCategory(Category.ANIMATION),
            onItemClick = onShowDetail
        )

        // 6. Reality & Game Shows
        ContentRail(
            title = "Reality & Competition",
            items = FoxContentRepository.getShowsByCategory(Category.REALITY),
            onItemClick = onShowDetail
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}
