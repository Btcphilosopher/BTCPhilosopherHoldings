package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.FoxContentRepository
import com.example.data.repository.FoxPreferencesRepository
import com.example.ui.components.QualityBadge
import com.example.ui.theme.FoxBorder
import com.example.ui.theme.FoxBrandBlue
import com.example.ui.theme.FoxMidnightNavy
import com.example.ui.theme.FoxSportsGold
import com.example.ui.theme.FoxSurfaceCard
import com.example.ui.theme.FoxSurfaceElevated
import com.example.ui.theme.FoxTextMuted
import com.example.ui.theme.FoxTextPrimary
import com.example.ui.theme.FoxTextSecondary

@Composable
fun AdminDashboardScreen(
    modifier: Modifier = Modifier
) {
    val playbackEvents by FoxPreferencesRepository.playbackEvents.collectAsState()
    var publishedOverrides by remember { mutableStateOf(mapOf<String, Boolean>()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(FoxMidnightNavy)
            .testTag("admin_dashboard_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Operational Overview KPIs
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(FoxSurfaceCard)
                    .border(1.dp, FoxBorder, RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "FOX STREAMING OPERATIONS CONSOLE",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                    QualityBadge(text = "ALL SYSTEMS NORMAL", isGold = true)
                }

                Spacer(modifier = Modifier.height(14.dp))

                // KPI Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KpiBox(label = "DAILY ACTIVE USERS", value = "14.2M", modifier = Modifier.weight(1f))
                    KpiBox(label = "CONCURRENT STREAMS", value = "2.84M", modifier = Modifier.weight(1f))
                    KpiBox(label = "AVG VIEW TIME", value = "58.4m", modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KpiBox(label = "BUFFERING RATIO", value = "0.14%", modifier = Modifier.weight(1f))
                    KpiBox(label = "AD FILL RATE", value = "99.4%", modifier = Modifier.weight(1f))
                    KpiBox(label = "CDN AVAILABILITY", value = "99.99%", modifier = Modifier.weight(1f))
                }
            }
        }

        // Live Channels Broadcast Health
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(FoxSurfaceCard)
                    .border(1.dp, FoxBorder, RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Tv, contentDescription = "TV", tint = FoxSportsGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("LIVE CHANNELS INGESTION & ENCODER STATUS", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                FoxContentRepository.liveChannels.forEach { ch ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(FoxSurfaceElevated)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(ch.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(ch.resolution, color = FoxTextSecondary, fontSize = 10.sp)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Active", tint = Color(0xFF00E676), modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("HEALTHY (${ch.bitRate})", color = Color(0xFF00E676), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Content Management: Catalog Publishing
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(FoxSurfaceCard)
                    .border(1.dp, FoxBorder, RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Text("CMS: PROGRAMME PUBLISHING & METADATA", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                FoxContentRepository.allShows.take(5).forEach { show ->
                    val isPublished = publishedOverrides[show.id] ?: true
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(FoxSurfaceElevated)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(show.title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("${show.category.name} • ${show.rating} • ${show.seasonsCount} Seasons", color = FoxTextSecondary, fontSize = 9.sp)
                        }

                        Button(
                            onClick = {
                                publishedOverrides = publishedOverrides + (show.id to !isPublished)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPublished) FoxBrandBlue else Color.DarkGray
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text(
                                text = if (isPublished) "PUBLISHED" else "UNPUBLISHED",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Live Telemetry Event Log
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(FoxSurfaceCard)
                    .border(1.dp, FoxBorder, RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Speed, contentDescription = "Telemetry", tint = FoxSportsGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("REAL-TIME STREAMING TELEMETRY STREAM", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                playbackEvents.forEach { ev ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(ev.timestamp, color = FoxSportsGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(ev.eventType, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Text(ev.details, color = FoxTextSecondary, fontSize = 9.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun KpiBox(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(FoxSurfaceElevated)
            .border(1.dp, FoxBorder, RoundedCornerShape(6.dp))
            .padding(8.dp)
    ) {
        Column {
            Text(label, color = FoxTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, color = FoxSportsGold, fontSize = 15.sp, fontWeight = FontWeight.Black)
        }
    }
}
