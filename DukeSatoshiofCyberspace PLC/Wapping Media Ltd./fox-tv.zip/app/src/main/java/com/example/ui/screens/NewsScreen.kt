package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.NewsArticle
import com.example.data.repository.FoxContentRepository
import com.example.ui.components.LiveBadge
import com.example.ui.components.QualityBadge
import com.example.ui.theme.FoxBorder
import com.example.ui.theme.FoxBrandBlue
import com.example.ui.theme.FoxLiveRed
import com.example.ui.theme.FoxMidnightNavy
import com.example.ui.theme.FoxSportsGold
import com.example.ui.theme.FoxSurfaceCard
import com.example.ui.theme.FoxSurfaceElevated
import com.example.ui.theme.FoxTextMuted
import com.example.ui.theme.FoxTextPrimary
import com.example.ui.theme.FoxTextSecondary

@Composable
fun NewsScreen(
    onPlayLiveNews: (title: String, url: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf("All") }
    var selectedArticleForRead by remember { mutableStateOf<NewsArticle?>(null) }
    val categories = listOf("All", "Politics", "Business", "World", "Technology", "Opinion")

    val articles = remember(selectedCategory) {
        if (selectedCategory == "All") {
            FoxContentRepository.newsArticles
        } else {
            FoxContentRepository.newsArticles.filter { it.category.equals(selectedCategory, ignoreCase = true) }
        }
    }

    val breakingNews = FoxContentRepository.newsArticles.firstOrNull { it.isBreaking }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(FoxMidnightNavy)
            .testTag("news_screen")
    ) {
        // News Section Header & Live Stream Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(FoxSurfaceCard)
                .padding(vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "FOX NEWS DIGITAL",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    LiveBadge(text = "LIVE FEED")
                }

                // Quick Launch Live News
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(FoxLiveRed)
                        .clickable {
                            val liveCh = FoxContentRepository.liveChannels.first { it.id == "fox_news_live" }
                            onPlayLiveNews("FOX News Live", liveCh.streamUrl)
                        }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                        .testTag("watch_live_news_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = "Watch Live",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "WATCH FNC LIVE",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Categories horizontal bar
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) FoxBrandBlue else FoxSurfaceElevated)
                            .border(1.dp, if (isSelected) FoxSportsGold else FoxBorder, RoundedCornerShape(16.dp))
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = cat,
                            color = if (isSelected) Color.White else FoxTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        // News Feed List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Breaking News Alert Banner
            if (breakingNews != null) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF2E0909))
                            .border(1.5.dp, FoxLiveRed, RoundedCornerShape(8.dp))
                            .clickable { selectedArticleForRead = breakingNews }
                            .padding(14.dp)
                            .testTag("breaking_news_banner")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LiveBadge(text = "BREAKING NEWS")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = breakingNews.timestamp,
                                color = FoxSportsGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = breakingNews.headline,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 20.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = breakingNews.summary,
                            color = FoxTextSecondary,
                            fontSize = 12.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Standard Article Cards
            items(articles, key = { it.id }) { article ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(FoxSurfaceCard)
                        .border(1.dp, FoxBorder, RoundedCornerShape(8.dp))
                        .clickable { selectedArticleForRead = article }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            QualityBadge(text = article.category.uppercase(), isGold = article.category == "Politics")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = article.timestamp,
                                color = FoxTextMuted,
                                fontSize = 10.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = article.headline,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = article.summary,
                            color = FoxTextSecondary,
                            fontSize = 11.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "BY ${article.author.uppercase()}",
                            color = FoxSportsGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    if (article.videoUrl != null) {
                        Spacer(modifier = Modifier.width(10.dp))
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(FoxBrandBlue)
                                .clickable {
                                    onPlayLiveNews(article.headline, article.videoUrl)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Watch Report",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // Article Reader Dialog
    selectedArticleForRead?.let { article ->
        ArticleReaderDialog(
            article = article,
            onDismiss = { selectedArticleForRead = null },
            onWatchVideo = {
                if (article.videoUrl != null) {
                    selectedArticleForRead = null
                    onPlayLiveNews(article.headline, article.videoUrl)
                }
            }
        )
    }
}

@Composable
fun ArticleReaderDialog(
    article: NewsArticle,
    onDismiss: () -> Unit,
    onWatchVideo: () -> Unit
) {
    val context = LocalContext.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxSize(0.90f)
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, FoxBorder, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = FoxMidnightNavy)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header with Close and Share
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(FoxSurfaceCard)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        QualityBadge(text = article.category.uppercase())
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "FOX NEWS REPORT",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                val shareIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, "${article.headline}\n\nRead on FOX News: ${article.summary}")
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Article"))
                            }
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.White)
                        }

                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                }

                // Article Body
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    item {
                        if (article.isBreaking) {
                            LiveBadge(text = "BREAKING COVERAGE")
                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        Text(
                            text = article.headline,
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            lineHeight = 26.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = article.author,
                                color = FoxSportsGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "• ${article.timestamp}",
                                color = FoxTextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        if (article.videoUrl != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(FoxBrandBlue)
                                    .clickable(onClick = onWatchVideo)
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Watch", tint = Color.White)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("WATCH VIDEO REPORT (HLS)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                        }

                        Text(
                            text = article.body,
                            color = FoxTextSecondary,
                            fontSize = 14.sp,
                            lineHeight = 22.sp
                        )

                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "FOX News Network, LLC. All rights reserved.",
                            color = FoxTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
