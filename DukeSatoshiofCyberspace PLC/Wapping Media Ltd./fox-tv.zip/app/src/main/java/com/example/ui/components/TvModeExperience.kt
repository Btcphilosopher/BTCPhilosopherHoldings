package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LiveChannel
import com.example.data.repository.FoxContentRepository
import com.example.ui.theme.FoxBorder
import com.example.ui.theme.FoxBrandBlue
import com.example.ui.theme.FoxMidnightNavy
import com.example.ui.theme.FoxSportsGold
import com.example.ui.theme.FoxSurfaceCard
import com.example.ui.theme.FoxSurfaceElevated
import com.example.ui.theme.FoxTextMuted
import com.example.ui.theme.FoxTextPrimary
import com.example.ui.theme.FoxTextSecondary

@Composable
fun TvRemoteOverlay(
    isTvMode: Boolean,
    onCloseTvMode: () -> Unit,
    onChannelChange: (LiveChannel) -> Unit,
    onSelectAction: () -> Unit,
    onNavigateTab: (FoxTab) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!isTvMode) return

    var currentChannelIndex by remember { mutableIntStateOf(0) }
    var isExpanded by remember { mutableStateOf(true) }
    val channels = FoxContentRepository.liveChannels

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(12.dp)
            .testTag("tv_remote_overlay"),
        contentAlignment = Alignment.BottomEnd
    ) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = FoxMidnightNavy.copy(alpha = 0.96f)),
            modifier = Modifier
                .border(1.5.dp, FoxSportsGold, RoundedCornerShape(12.dp))
                .width(if (isExpanded) 220.dp else 140.dp)
        ) {
            Column(
                modifier = Modifier.padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header with Toggle Minimize & Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tv, contentDescription = "TV", tint = FoxSportsGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("10' TV REMOTE", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Row {
                        IconButton(onClick = { isExpanded = !isExpanded }, modifier = Modifier.size(24.dp)) {
                            Text(if (isExpanded) "–" else "+", color = FoxSportsGold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = onCloseTvMode, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(14.dp))
                        }
                    }
                }

                if (isExpanded) {
                    Spacer(modifier = Modifier.height(8.dp))

                    // Current Channel Indicator & Fast Channel Switcher
                    val curCh = channels[currentChannelIndex % channels.size]
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(FoxSurfaceElevated)
                            .padding(6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("CH ${curCh.channelNumber} • ${curCh.name}", color = FoxSportsGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(curCh.currentProgram.title, color = Color.White, fontSize = 9.sp, maxLines = 1)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // D-Pad Controller
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Up Button
                        RemoteDpadButton(icon = Icons.Default.KeyboardArrowUp) {
                            // Up
                        }

                        // Middle Row: Left, OK / SELECT, Right
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RemoteDpadButton(icon = Icons.Default.KeyboardArrowLeft) {
                                // Left
                            }

                            // OK / SELECT center button
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(FoxBrandBlue)
                                    .border(1.5.dp, FoxSportsGold, CircleShape)
                                    .clickable(onClick = onSelectAction)
                                    .testTag("remote_ok_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("OK", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                            }

                            RemoteDpadButton(icon = Icons.Default.KeyboardArrowRight) {
                                // Right
                            }
                        }

                        // Down Button
                        RemoteDpadButton(icon = Icons.Default.KeyboardArrowDown) {
                            // Down
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // TV Specific Quick Buttons (CH+, CH-, GUIDE, BACK)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Channel Up
                        RemotePillButton(label = "CH +") {
                            currentChannelIndex = (currentChannelIndex + 1) % channels.size
                            onChannelChange(channels[currentChannelIndex])
                        }

                        // Channel Down
                        RemotePillButton(label = "CH –") {
                            currentChannelIndex = if (currentChannelIndex - 1 < 0) channels.size - 1 else currentChannelIndex - 1
                            onChannelChange(channels[currentChannelIndex])
                        }

                        // Guide shortcut
                        RemotePillButton(label = "GUIDE") {
                            onNavigateTab(FoxTab.LIVE_TV)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RemoteDpadButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(FoxSurfaceCard)
            .border(1.dp, FoxBorder, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun RemotePillButton(
    label: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(FoxSurfaceElevated)
            .border(1.dp, FoxBorder, RoundedCornerShape(4.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = label, color = FoxSportsGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}
