package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsFootball
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Newspaper
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserProfile
import com.example.ui.theme.FoxBorder
import com.example.ui.theme.FoxBrandBlue
import com.example.ui.theme.FoxMidnightNavy
import com.example.ui.theme.FoxSportsGold
import com.example.ui.theme.FoxSurfaceCard
import com.example.ui.theme.FoxTextMuted
import com.example.ui.theme.FoxTextPrimary
import com.example.ui.theme.FoxTextSecondary

enum class FoxTab(val title: String) {
    HOME("Home"),
    LIVE_TV("Live TV"),
    SHOWS("Shows"),
    SPORTS("Sports"),
    NEWS("News"),
    SEARCH("Search"),
    PROFILE("Profile"),
    ADMIN("CMS & Ops")
}

@Composable
fun FoxTopBar(
    currentTab: FoxTab,
    onTabSelected: (FoxTab) -> Unit,
    isTvMode: Boolean,
    onToggleTvMode: () -> Unit,
    activeProfile: UserProfile,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(FoxMidnightNavy.copy(alpha = 0.95f))
            .statusBarsPadding()
            .border(width = 0.5.dp, color = FoxBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand Logo
            FoxBrandLogo(
                modifier = Modifier
                    .testTag("fox_logo_button")
                    .clickable { onTabSelected(FoxTab.HOME) }
            )

            // Right side utility actions: TV Mode button & Profile avatar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // TV Mode Toggle button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isTvMode) FoxSportsGold else FoxSurfaceCard)
                        .border(1.dp, if (isTvMode) FoxSportsGold else FoxBorder, RoundedCornerShape(6.dp))
                        .clickable(onClick = onToggleTvMode)
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                        .testTag("tv_mode_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tv,
                            contentDescription = "Toggle TV Mode",
                            tint = if (isTvMode) FoxMidnightNavy else FoxTextPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isTvMode) "10-FOOT TV ON" else "TV MODE",
                            color = if (isTvMode) FoxMidnightNavy else FoxTextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Search Icon
                IconButton(
                    onClick = { onTabSelected(FoxTab.SEARCH) },
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("top_search_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = if (currentTab == FoxTab.SEARCH) FoxSportsGold else FoxTextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Profile Avatar / switcher trigger
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color(activeProfile.avatarColorHex))
                        .border(1.5.dp, if (currentTab == FoxTab.PROFILE) FoxSportsGold else Color.White, CircleShape)
                        .clickable { onTabSelected(FoxTab.PROFILE) }
                        .testTag("top_profile_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = activeProfile.name.take(1).uppercase(),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Horizontal Category Tabs (Editorial Network Header)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FoxTab.entries.forEach { tab ->
                val isSelected = currentTab == tab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .testTag("nav_tab_${tab.name.lowercase()}"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = tab.title,
                            color = when {
                                isSelected -> FoxSportsGold
                                tab == FoxTab.LIVE_TV -> Color(0xFFFF5252)
                                else -> FoxTextSecondary
                            },
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold
                        )
                        if (isSelected) {
                            Spacer(modifier = Modifier.height(3.dp))
                            Box(
                                modifier = Modifier
                                    .width(18.dp)
                                    .height(2.dp)
                                    .clip(CircleShape)
                                    .background(FoxSportsGold)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FoxBottomBar(
    currentTab: FoxTab,
    onTabSelected: (FoxTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(FoxMidnightNavy)
            .border(width = 0.5.dp, color = FoxBorder)
            .navigationBarsPadding()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val primaryTabs = listOf(
            Triple(FoxTab.HOME, "Home", Icons.Outlined.Home),
            Triple(FoxTab.LIVE_TV, "Live TV", Icons.Default.LiveTv),
            Triple(FoxTab.SHOWS, "Shows", Icons.Default.VideoLibrary),
            Triple(FoxTab.SPORTS, "Sports", Icons.Default.SportsFootball),
            Triple(FoxTab.NEWS, "News", Icons.Outlined.Newspaper),
            Triple(FoxTab.PROFILE, "Account", Icons.Default.AccountCircle)
        )

        primaryTabs.forEach { (tab, label, icon) ->
            val isSelected = currentTab == tab
            Column(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onTabSelected(tab) }
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                    .testTag("bottom_tab_${tab.name.lowercase()}"),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isSelected) FoxSportsGold else FoxTextMuted,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = label,
                    color = if (isSelected) FoxSportsGold else FoxTextMuted,
                    fontSize = 10.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}
