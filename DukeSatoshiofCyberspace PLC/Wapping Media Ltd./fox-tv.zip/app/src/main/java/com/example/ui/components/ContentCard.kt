package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaItem
import com.example.ui.theme.FoxBorder
import com.example.ui.theme.FoxBrandBlue
import com.example.ui.theme.FoxSportsGold
import com.example.ui.theme.FoxSurfaceCard
import com.example.ui.theme.FoxSurfaceElevated
import com.example.ui.theme.FoxTextMuted
import com.example.ui.theme.FoxTextPrimary
import com.example.ui.theme.FoxTextSecondary

@Composable
fun ContentCard(
    item: MediaItem,
    modifier: Modifier = Modifier,
    cardWidth: Dp = 150.dp,
    cardHeight: Dp = 210.dp,
    isFocused: Boolean = false,
    progressFraction: Float? = null,
    onClick: () -> Unit
) {
    val focusBorderColor = if (isFocused) FoxSportsGold else FoxBorder
    val focusBorderWidth = if (isFocused) 2.5.dp else 1.dp

    Column(
        modifier = modifier
            .width(cardWidth)
            .testTag("content_card_${item.id}")
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .width(cardWidth)
                .height(cardHeight)
                .clip(RoundedCornerShape(8.dp))
                .border(focusBorderWidth, focusBorderColor, RoundedCornerShape(8.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            FoxSurfaceElevated,
                            FoxSurfaceCard,
                            Color(0xFF06142A)
                        )
                    )
                )
        ) {
            // Subtle graphic backdrop
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp)
            ) {
                // Large subtle FOX watermark or initials
                Text(
                    text = item.title.take(1),
                    color = Color.White.copy(alpha = 0.08f),
                    fontSize = 72.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.align(Alignment.Center)
                )

                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (item.isLive) {
                            LiveBadge()
                        } else if (item.isOriginal) {
                            QualityBadge(text = "ORIGINAL", isBlue = true)
                        } else {
                            QualityBadge(text = item.rating)
                        }

                        QualityBadge(text = "${item.durationMinutes}m")
                    }

                    // Bottom info block
                    Column {
                        Text(
                            text = item.genre.uppercase(),
                            color = FoxSportsGold,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = item.title,
                            color = FoxTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Play overlay on focus/tap
            if (isFocused) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.35f)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(FoxBrandBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }

            // Watch progress bar if present
            if (progressFraction != null && progressFraction > 0f) {
                LinearProgressIndicator(
                    progress = { progressFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .align(Alignment.BottomCenter),
                    color = FoxBrandBlue,
                    trackColor = Color.White.copy(alpha = 0.2f)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = item.title,
            color = if (isFocused) FoxSportsGold else FoxTextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = "${item.category.name} • ${item.releaseYear}",
            color = FoxTextMuted,
            fontSize = 10.sp,
            maxLines = 1
        )
    }
}
