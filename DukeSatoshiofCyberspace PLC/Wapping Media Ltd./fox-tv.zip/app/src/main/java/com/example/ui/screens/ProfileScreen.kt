package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.SubscriptionTier
import com.example.data.model.UserProfile
import com.example.data.repository.FoxContentRepository
import com.example.data.repository.FoxPreferencesRepository
import com.example.ui.components.QualityBadge
import com.example.ui.theme.FoxBorder
import com.example.ui.theme.FoxBrandBlue
import com.example.ui.theme.FoxLiveRed
import com.example.ui.theme.FoxMidnightNavy
import com.example.ui.theme.FoxSportsGold
import com.example.ui.theme.FoxSurfaceCard
import com.example.ui.theme.FoxSurfaceElevated
import com.example.ui.theme.FoxTextMuted
import com.example.ui.theme.FoxTextPrimary
import com.example.ui.theme.FoxTextSecondary

@Composable
fun ProfileScreen(
    onPlayMedia: (title: String, url: String, isLive: Boolean, epInfo: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val profiles by FoxPreferencesRepository.profiles.collectAsState()
    val activeProfile by FoxPreferencesRepository.activeProfile.collectAsState()
    val myList by FoxPreferencesRepository.myList.collectAsState()
    val subscriptionTier by FoxPreferencesRepository.subscriptionTier.collectAsState()
    val connectedDevices by FoxPreferencesRepository.connectedDevices.collectAsState()

    var showPinDialogForProfile by remember { mutableStateOf<UserProfile?>(null) }
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }
    var showProviderModal by remember { mutableStateOf(false) }

    val myShows = remember(myList) {
        FoxContentRepository.allShows.filter { myList.contains(it.id) }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(FoxMidnightNavy)
            .testTag("profile_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Section 1: Household Profiles
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(FoxSurfaceCard)
                    .border(1.dp, FoxBorder, RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "HOUSEHOLD PROFILES & PARENTAL CONTROLS",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(profiles) { prof ->
                        val isActive = prof.id == activeProfile.id
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    if (prof.hasPinProtection && !isActive) {
                                        showPinDialogForProfile = prof
                                    } else {
                                        FoxPreferencesRepository.switchProfile(prof)
                                    }
                                }
                                .padding(4.dp)
                                .testTag("profile_avatar_${prof.id}")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(Color(prof.avatarColorHex))
                                    .border(
                                        width = if (isActive) 2.5.dp else 1.dp,
                                        color = if (isActive) FoxSportsGold else Color.White.copy(alpha = 0.5f),
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (prof.hasPinProtection) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "PIN Protected",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                } else {
                                    Text(
                                        text = prof.name.take(1).uppercase(),
                                        color = Color.White,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = prof.name,
                                color = if (isActive) FoxSportsGold else FoxTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium
                            )

                            if (prof.isKidsMode) {
                                Text(
                                    text = "KIDS (TV-Y/PG)",
                                    color = Color(0xFFFFB703),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section 2: Subscription & Cable Provider Entitlements
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(FoxSurfaceCard)
                    .border(1.dp, FoxBorder, RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SUBSCRIPTION & ENTITLEMENTS",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Active Plan: ${subscriptionTier.title}",
                            color = FoxSportsGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    QualityBadge(text = subscriptionTier.badge, isGold = true)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    SubscriptionTier.entries.forEach { tier ->
                        val isSelected = subscriptionTier == tier
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) FoxBrandBlue else FoxSurfaceElevated)
                                .border(1.dp, if (isSelected) FoxSportsGold else FoxBorder, RoundedCornerShape(6.dp))
                                .clickable {
                                    if (tier == SubscriptionTier.TV_PROVIDER_LINKED) {
                                        showProviderModal = true
                                    } else {
                                        FoxPreferencesRepository.setSubscriptionTier(tier)
                                    }
                                }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = tier.name.replace("_", " "),
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = tier.price,
                                    color = if (isSelected) Color.White else FoxTextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section 3: My List (Saved Programmes)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(FoxSurfaceCard)
                    .border(1.dp, FoxBorder, RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MY LIST (${myShows.size})",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Saved across all devices",
                        color = FoxTextMuted,
                        fontSize = 10.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (myShows.isEmpty()) {
                    Text(
                        text = "Your list is empty. Tap 'Add to My List' on any show to watch later.",
                        color = FoxTextMuted,
                        fontSize = 11.sp
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        myShows.forEach { show ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(FoxSurfaceElevated)
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = show.title,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${show.category.name} • ${show.rating}",
                                        color = FoxTextSecondary,
                                        fontSize = 10.sp
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Button(
                                        onClick = { onPlayMedia(show.title, show.videoStreamUrl, false, "Episode 1") },
                                        colors = ButtonDefaults.buttonColors(containerColor = FoxBrandBlue),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("PLAY", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }

                                    IconButton(
                                        onClick = { FoxPreferencesRepository.toggleMyList(show.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Remove", tint = FoxTextMuted, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 4: Authorized Connected Devices
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(FoxSurfaceCard)
                    .border(1.dp, FoxBorder, RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "ACTIVE SESSIONS & CONNECTED DEVICES",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    connectedDevices.forEach { device ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(FoxSurfaceElevated)
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Tv, contentDescription = "Device", tint = FoxSportsGold, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(device, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            }
                            IconButton(
                                onClick = { FoxPreferencesRepository.removeDevice(device) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Revoke", tint = FoxLiveRed, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    // PIN Protection Dialog
    showPinDialogForProfile?.let { prof ->
        Dialog(onDismissRequest = {
            showPinDialogForProfile = null
            pinInput = ""
            pinError = false
        }) {
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = FoxMidnightNavy),
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .border(1.dp, FoxSportsGold, RoundedCornerShape(10.dp))
                    .padding(16.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Lock, contentDescription = "Lock", tint = FoxSportsGold, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("ENTER PARENTAL PIN", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("Default PIN is 1234", color = FoxTextMuted, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = {
                            if (it.length <= 4) pinInput = it
                            pinError = false
                        },
                        placeholder = { Text("4-digit PIN", color = FoxTextMuted) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = FoxSportsGold,
                            unfocusedBorderColor = FoxBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.width(160.dp)
                    )

                    if (pinError) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Incorrect PIN. Please try again.", color = FoxLiveRed, fontSize = 11.sp)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                if (pinInput == prof.pinCode) {
                                    FoxPreferencesRepository.switchProfile(prof)
                                    showPinDialogForProfile = null
                                    pinInput = ""
                                } else {
                                    pinError = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FoxBrandBlue)
                        ) {
                            Text("UNLOCK", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                showPinDialogForProfile = null
                                pinInput = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FoxSurfaceCard)
                        ) {
                            Text("CANCEL")
                        }
                    }
                }
            }
        }
    }

    // Pay-TV Provider Selector Modal
    if (showProviderModal) {
        Dialog(onDismissRequest = { showProviderModal = false }) {
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = FoxMidnightNavy),
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .border(1.dp, FoxBorder, RoundedCornerShape(10.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Text("SELECT YOUR TV PROVIDER", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("Sign in with your television provider for 24/7 FOX live network streaming.", color = FoxTextSecondary, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    val providers = listOf("Xfinity (Comcast)", "Spectrum (Charter)", "DIRECTV / DIRECTV STREAM", "YouTube TV", "Hulu + Live TV", "Dish Network", "Cox Communications", "Verizon Fios")
                    providers.forEach { p ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(FoxSurfaceElevated)
                                .clickable {
                                    FoxPreferencesRepository.setSubscriptionTier(SubscriptionTier.TV_PROVIDER_LINKED)
                                    showProviderModal = false
                                }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(p, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Icon(Icons.Default.Check, contentDescription = "Select", tint = FoxSportsGold, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}
