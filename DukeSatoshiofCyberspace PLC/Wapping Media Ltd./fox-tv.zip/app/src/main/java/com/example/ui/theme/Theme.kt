package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val FoxColorScheme = darkColorScheme(
    primary = FoxBrandBlue,
    onPrimary = FoxTextPrimary,
    primaryContainer = FoxSurfaceElevated,
    onPrimaryContainer = FoxTextPrimary,
    secondary = FoxBrightBlue,
    onSecondary = FoxTextPrimary,
    secondaryContainer = FoxSurfaceCard,
    onSecondaryContainer = FoxTextSecondary,
    tertiary = FoxSportsGold,
    onTertiary = FoxMidnightNavy,
    error = FoxLiveRed,
    onError = FoxTextPrimary,
    background = FoxBackgroundDark,
    onBackground = FoxTextPrimary,
    surface = FoxMidnightNavy,
    onSurface = FoxTextPrimary,
    surfaceVariant = FoxSurfaceCard,
    onSurfaceVariant = FoxTextSecondary,
    outline = FoxBorder
)

@Composable
fun FoxTvTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = FoxColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    FoxTvTheme(content = content)
}
