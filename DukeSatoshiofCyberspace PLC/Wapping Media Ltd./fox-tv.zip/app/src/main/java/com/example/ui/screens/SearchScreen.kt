package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaItem
import com.example.data.repository.FoxContentRepository
import com.example.data.repository.FoxPreferencesRepository
import com.example.ui.components.QualityBadge
import com.example.ui.theme.FoxBorder
import com.example.ui.theme.FoxBrandBlue
import com.example.ui.theme.FoxMidnightNavy
import com.example.ui.theme.FoxSportsGold
import com.example.ui.theme.FoxSurfaceCard
import com.example.ui.theme.FoxSurfaceElevated
import com.example.ui.theme.FoxTextMuted
import com.example.ui.theme.FoxTextPrimary
import com.example.ui.theme.FoxTextSecondary

@Composable
fun SearchScreen(
    onPlayMedia: (title: String, url: String, isLive: Boolean, epInfo: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") }
    val isPersonalisationEnabled by FoxPreferencesRepository.isPersonalisationEnabled.collectAsState()

    val trendingTags = listOf("Shadow City", "Rescue HI-Surf", "NFL on FOX", "MasterChef", "Family Guy", "The Cleaning Lady")
    val filters = listOf("All", "Shows", "Sports", "Live Channels")

    val searchResults = remember(searchQuery, selectedFilter) {
        if (searchQuery.isBlank()) {
            emptyList()
        } else {
            FoxContentRepository.searchAll(searchQuery)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(FoxMidnightNavy)
            .testTag("search_screen")
    ) {
        // Search Input Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(FoxSurfaceCard)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search shows, sports, channels, actors...", color = FoxTextMuted, fontSize = 13.sp) },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = FoxSportsGold)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = Color.White)
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FoxSportsGold,
                    unfocusedBorderColor = FoxBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    cursorColor = FoxSportsGold
                ),
                shape = RoundedCornerShape(8.dp),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("global_search_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Filter Chips
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filters) { f ->
                    val isSelected = selectedFilter == f
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) FoxBrandBlue else FoxSurfaceElevated)
                            .border(1.dp, if (isSelected) FoxSportsGold else FoxBorder, RoundedCornerShape(14.dp))
                            .clickable { selectedFilter = f }
                            .padding(horizontal = 12.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = f,
                            color = if (isSelected) Color.White else FoxTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Search Content or Recommendations
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (searchQuery.isBlank()) {
                // Trending Queries Section
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TrendingUp, contentDescription = "Trending", tint = FoxSportsGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("TRENDING SEARCHES ON FOX", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(trendingTags) { tag ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(FoxSurfaceCard)
                                    .border(1.dp, FoxBorder, RoundedCornerShape(6.dp))
                                    .clickable { searchQuery = tag }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(tag, color = FoxTextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Explainable Personalised Recommendations
                item {
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("PERSONALIZED RECOMMENDATIONS", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Powered by viewing habits & profile telemetry", color = FoxTextMuted, fontSize = 10.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (isPersonalisationEnabled) "ON" else "OFF", color = FoxSportsGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(4.dp))
                            Switch(
                                checked = isPersonalisationEnabled,
                                onCheckedChange = { FoxPreferencesRepository.togglePersonalisation() },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = FoxBrandBlue,
                                    uncheckedThumbColor = Color.Gray,
                                    uncheckedTrackColor = FoxBorder
                                )
                            )
                        }
                    }
                }

                if (isPersonalisationEnabled) {
                    val recommended = FoxContentRepository.allShows.take(4)
                    items(recommended) { item ->
                        SearchResultRow(
                            item = item,
                            recommendationReason = when (item.category.name) {
                                "DRAMA" -> "Because you watched Shadow City"
                                "REALITY" -> "Popular with Gordon Ramsay fans"
                                "ANIMATION" -> "Sunday Animation Domination top pick"
                                else -> "Trending in your area"
                            },
                            onPlay = { onPlayMedia(item.title, item.videoStreamUrl, item.isLive, "Episode 1") }
                        )
                    }
                } else {
                    item {
                        Text(
                            text = "Personalised recommendations are turned off. Enable the toggle above to receive tailored recommendations based on watch history.",
                            color = FoxTextMuted,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                }
            } else {
                // Search Results
                item {
                    Text(
                        text = "SEARCH RESULTS (${searchResults.size})",
                        color = FoxSportsGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (searchResults.isEmpty()) {
                    item {
                        Text("No programmes found matching '$searchQuery'. Try searching for 'Drama', 'NFL', 'Comedy', or actor names.", color = FoxTextMuted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 20.dp))
                    }
                } else {
                    items(searchResults, key = { it.id }) { item ->
                        SearchResultRow(
                            item = item,
                            onPlay = { onPlayMedia(item.title, item.videoStreamUrl, item.isLive, "Episode 1") }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SearchResultRow(
    item: MediaItem,
    recommendationReason: String? = null,
    onPlay: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(FoxSurfaceCard)
            .border(1.dp, FoxBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onPlay)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            if (recommendationReason != null) {
                Text(
                    text = "★ $recommendationReason",
                    color = FoxSportsGold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = item.title,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                QualityBadge(text = item.rating)
            }

            Text(
                text = item.synopsis,
                color = FoxTextSecondary,
                fontSize = 11.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "${item.category.name} • ${item.releaseYear} • ${item.durationMinutes} min",
                color = FoxTextMuted,
                fontSize = 10.sp
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(FoxBrandBlue),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White, modifier = Modifier.size(20.dp))
        }
    }
}
