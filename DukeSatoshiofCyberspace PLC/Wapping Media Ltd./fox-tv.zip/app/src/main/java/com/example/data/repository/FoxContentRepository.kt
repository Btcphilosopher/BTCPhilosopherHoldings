package com.example.data.repository

import com.example.data.model.Category
import com.example.data.model.EpgProgram
import com.example.data.model.Episode
import com.example.data.model.LiveChannel
import com.example.data.model.MediaItem
import com.example.data.model.NewsArticle
import com.example.data.model.SportsFixture

object FoxContentRepository {

    // Reliable public media test streams (HLS & MP4)
    private const val STREAM_HLS_1 = "https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_16x9/bipbop_16x9_variant.m3u8"
    private const val STREAM_HLS_2 = "https://bitmovin-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8"
    private const val STREAM_MP4_ACTION = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"
    private const val STREAM_MP4_DRAMA = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
    private const val STREAM_MP4_SPORTS = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"
    private const val STREAM_MP4_COMEDY = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
    private const val STREAM_MP4_DOC = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"

    val heroShow = MediaItem(
        id = "fox_hero_shadow_city",
        title = "Shadow City",
        synopsis = "In the heart of Chicago, an elite team of detectives led by Elias Thorne confronts a syndicate operating in the highest corridors of power. Justice comes with a steep price.",
        category = Category.DRAMA,
        genre = "Crime Drama",
        rating = "TV-MA",
        releaseYear = 2026,
        durationMinutes = 58,
        videoStreamUrl = STREAM_MP4_ACTION,
        isLive = false,
        isOriginal = true,
        seasonsCount = 3,
        cast = listOf("Damon Harper", "Sarah Vance", "Elias Thorne", "Maya Patel", "Leo Ruiz"),
        episodes = listOf(
            Episode(1, 1, "The Midnight Grid", "A suspicious blackout across downtown Chicago exposes a high-profile cover-up.", 55, STREAM_MP4_ACTION),
            Episode(2, 1, "Silent Wire", "Detective Thorne uncovers encrypted ledger files linking city officials to maritime shipments.", 52, STREAM_MP4_DRAMA),
            Episode(3, 1, "Crossfire Protocol", "Federal marshals intervene as Vance closes in on a rogue informant.", 58, STREAM_HLS_1),
            Episode(4, 1, "Dead Drop", "An encrypted USB drive recovered from Lake Michigan triggers an internal affairs leak.", 61, STREAM_MP4_ACTION)
        ),
        tags = listOf("4K UHD", "5.1 Surround", "HDR10", "Trending #1")
    )

    val heroSports = MediaItem(
        id = "fox_hero_sports_nfl",
        title = "NFL on FOX: Prime Time Collision",
        synopsis = "Live coverage from Arrowhead Stadium. High-stakes Thursday night clash between conference rivals with playoff implications on the line.",
        category = Category.SPORTS,
        genre = "American Football",
        rating = "TV-PG",
        releaseYear = 2026,
        durationMinutes = 180,
        videoStreamUrl = STREAM_MP4_SPORTS,
        isLive = true,
        isOriginal = true,
        tags = listOf("LIVE 4K", "Dolby Atmos", "Instant Replay", "FOX Sports exclusive")
    )

    val allShows: List<MediaItem> = listOf(
        heroShow,
        MediaItem(
            id = "fox_rescue_hisurf",
            title = "Rescue: HI-Surf",
            synopsis = "Pulse-pounding lifeguard drama following the heavy-water lifeguards who patrol and protect the North Shore of O'ahu.",
            category = Category.DRAMA,
            genre = "Action Drama",
            rating = "TV-14",
            releaseYear = 2025,
            durationMinutes = 44,
            videoStreamUrl = STREAM_MP4_DRAMA,
            isOriginal = true,
            seasonsCount = 2,
            cast = listOf("Robbie Magasiva", "Arielle Kebbel", "Adam Demos", "Kekoa Kekumano"),
            episodes = listOf(
                Episode(1, 1, "Mauka to Makai", "The winter swell brings legendary twenty-foot waves to the Banzai Pipeline.", 44, STREAM_MP4_DRAMA),
                Episode(2, 1, "Riptide Rescue", "A jet ski malfunction puts two junior guards in grave danger.", 43, STREAM_HLS_1)
            ),
            tags = listOf("Popular", "Action", "Seasons 1-2")
        ),
        MediaItem(
            id = "fox_the_cleaning_lady",
            title = "The Cleaning Lady",
            synopsis = "A whip-smart Cambodian doctor comes to the U.S. for medical treatment to save her ailing son, navigating an underworld syndicate with cunning resilience.",
            category = Category.DRAMA,
            genre = "Crime Thriller",
            rating = "TV-14",
            releaseYear = 2024,
            durationMinutes = 45,
            videoStreamUrl = STREAM_HLS_2,
            isOriginal = true,
            seasonsCount = 4,
            cast = listOf("Élodie Yung", "Martha Millan", "Sebastien LaSalle", "Faith Bryant"),
            tags = listOf("Critically Acclaimed", "Full Series")
        ),
        MediaItem(
            id = "fox_masterchef",
            title = "MasterChef: Generations",
            synopsis = "Chef Gordon Ramsay and judges put four generations of culinary hopefuls through grueling pressure tests to find America's next master chef.",
            category = Category.REALITY,
            genre = "Culinary Competition",
            rating = "TV-PG",
            releaseYear = 2025,
            durationMinutes = 45,
            videoStreamUrl = STREAM_MP4_COMEDY,
            isOriginal = true,
            seasonsCount = 14,
            cast = listOf("Gordon Ramsay", "Aarón Sánchez", "Joe Bastianich"),
            tags = listOf("New Episodes", "Food", "Top 10")
        ),
        MediaItem(
            id = "fox_animal_control",
            title = "Animal Control",
            synopsis = "Joel McHale stars as an opinionated, eccentric Animal Control officer who may struggle with humans, but has a knack for animals.",
            category = Category.COMEDY,
            genre = "Workplace Comedy",
            rating = "TV-14",
            releaseYear = 2025,
            durationMinutes = 22,
            videoStreamUrl = STREAM_MP4_COMEDY,
            isOriginal = true,
            seasonsCount = 3,
            cast = listOf("Joel McHale", "Michael Rowland", "Vella Lovell", "Ravi Patel"),
            tags = listOf("Comedy", "Fan Favorite")
        ),
        MediaItem(
            id = "fox_family_guy",
            title = "Family Guy",
            synopsis = "The irreverent adventures of the dysfunctional Griffin family in Quahog, Rhode Island, led by bumbling Peter and the maniacal Stewie.",
            category = Category.ANIMATION,
            genre = "Adult Animation",
            rating = "TV-14",
            releaseYear = 2026,
            durationMinutes = 22,
            videoStreamUrl = STREAM_MP4_COMEDY,
            isOriginal = false,
            seasonsCount = 23,
            cast = listOf("Seth MacFarlane", "Alex Borstein", "Seth Green", "Mila Kunis"),
            tags = listOf("Animation Domination", "Sunday Block")
        ),
        MediaItem(
            id = "fox_the_simpsons",
            title = "The Simpsons",
            synopsis = "The legendary satirical depiction of American life epitomized by the Simpson family in Springfield.",
            category = Category.ANIMATION,
            genre = "Animated Sitcom",
            rating = "TV-PG",
            releaseYear = 2026,
            durationMinutes = 22,
            videoStreamUrl = STREAM_MP4_COMEDY,
            isOriginal = false,
            seasonsCount = 36,
            cast = listOf("Dan Castellaneta", "Julie Kavner", "Nancy Cartwright", "Hank Azaria"),
            tags = listOf("Classic", "Animation Domination")
        ),
        MediaItem(
            id = "fox_gordon_ramsay_kitchen_nightmares",
            title = "Kitchen Nightmares",
            synopsis = "Chef Ramsay travels across America visiting struggling restaurants to revamp their menus, kitchens, and team culture in one frantic week.",
            category = Category.REALITY,
            genre = "Reality / Makeover",
            rating = "TV-14",
            releaseYear = 2025,
            durationMinutes = 44,
            videoStreamUrl = STREAM_MP4_DOC,
            isOriginal = true,
            seasonsCount = 9,
            cast = listOf("Gordon Ramsay"),
            tags = listOf("Binge Worthy", "Reality")
        ),
        MediaItem(
            id = "fox_the_floor",
            title = "The Floor",
            synopsis = "Rob Lowe hosts this ultimate trivia battle where 81 players conquer trivia territory on a giant interactive LED floor for $250,000.",
            category = Category.REALITY,
            genre = "Game Show",
            rating = "TV-PG",
            releaseYear = 2025,
            durationMinutes = 43,
            videoStreamUrl = STREAM_MP4_COMEDY,
            isOriginal = true,
            seasonsCount = 3,
            cast = listOf("Rob Lowe"),
            tags = listOf("Game Show", "Family Friendly")
        ),
        MediaItem(
            id = "fox_special_forces",
            title = "Special Forces: World's Toughest Test",
            synopsis = "Celebrity recruits endure harsh wilderness training under the demanding supervision of ex-Special Forces operatives.",
            category = Category.REALITY,
            genre = "Survival Competition",
            rating = "TV-14",
            releaseYear = 2025,
            durationMinutes = 48,
            videoStreamUrl = STREAM_MP4_ACTION,
            isOriginal = true,
            seasonsCount = 3,
            tags = listOf("High Intensity", "Reality")
        ),
        MediaItem(
            id = "fox_bobs_burgers",
            title = "Bob's Burgers",
            synopsis = "Bob Belcher and his quirky family run a struggling burger joint with big heart, relentless optimism, and witty banter.",
            category = Category.ANIMATION,
            genre = "Adult Animation",
            rating = "TV-PG",
            releaseYear = 2026,
            durationMinutes = 22,
            videoStreamUrl = STREAM_MP4_COMEDY,
            isOriginal = false,
            seasonsCount = 15,
            tags = listOf("Animation Domination", "Comedy")
        )
    )

    val liveChannels: List<LiveChannel> = listOf(
        LiveChannel(
            id = "fox_network_east",
            channelNumber = "02",
            name = "FOX Network (East)",
            callSign = "WNYW-FOX",
            category = "Entertainment",
            logoText = "FOX",
            streamUrl = STREAM_HLS_1,
            resolution = "1080p 60fps HDR",
            bitRate = "12.4 Mbps",
            currentProgram = EpgProgram(
                id = "epg_primetime_1",
                title = "Shadow City (Live Broadcast)",
                description = "Episode 4: Dead Drop. Chicago detectives scramble when an internal affairs breach endangers an undercover operative.",
                startTimeFormatted = "08:00 PM",
                endTimeFormatted = "09:00 PM",
                durationMinutes = 60,
                progressPercentage = 0.52f,
                rating = "TV-MA",
                liveTag = true,
                streamUrl = STREAM_HLS_1
            ),
            upcomingPrograms = listOf(
                EpgProgram("epg_primetime_2", "Rescue: HI-Surf", "North Shore guards scramble to rescue surfers trapped in pipeline cavern.", "09:00 PM", "10:00 PM", 60, 0f, "TV-14"),
                EpgProgram("epg_primetime_3", "FOX 5 News at 10", "Breaking tri-state news, radar meteorology and sports roundup.", "10:00 PM", "11:00 PM", 60, 0f, "TV-PG")
            )
        ),
        LiveChannel(
            id = "fox_sports_1",
            channelNumber = "04",
            name = "FS1 (FOX Sports 1)",
            callSign = "FS1",
            category = "Sports",
            logoText = "FS1",
            streamUrl = STREAM_MP4_SPORTS,
            resolution = "1080p 60fps Ultra",
            bitRate = "15.0 Mbps",
            currentProgram = EpgProgram(
                id = "epg_sports_1",
                title = "NFL on FOX: Thursday Night Live",
                description = "Live game coverage with Kevin Burkhardt and Tom Brady in the booth.",
                startTimeFormatted = "07:30 PM",
                endTimeFormatted = "11:00 PM",
                durationMinutes = 210,
                progressPercentage = 0.65f,
                rating = "TV-PG",
                liveTag = true,
                streamUrl = STREAM_MP4_SPORTS
            ),
            upcomingPrograms = listOf(
                EpgProgram("epg_sports_2", "FOX NFL Postgame Show", "Highlights, locker room reactions, and coach interviews.", "11:00 PM", "11:45 PM", 45, 0f, "TV-PG"),
                EpgProgram("epg_sports_3", "The Herd with Colin Cowherd", "Sports opinion, debate and special guests.", "11:45 PM", "01:00 AM", 75, 0f, "TV-PG")
            )
        ),
        LiveChannel(
            id = "fox_news_live",
            channelNumber = "05",
            name = "FOX News Channel",
            callSign = "FNC",
            category = "News",
            logoText = "FOX NEWS",
            streamUrl = STREAM_HLS_2,
            resolution = "1080p 60fps",
            bitRate = "9.2 Mbps",
            currentProgram = EpgProgram(
                id = "epg_news_1",
                title = "Special Report with Bret Baier",
                description = "Live political reporting from Washington D.C., Capitol Hill updates and All-Star panel analysis.",
                startTimeFormatted = "06:00 PM",
                endTimeFormatted = "07:00 PM",
                durationMinutes = 60,
                progressPercentage = 0.40f,
                rating = "TV-G",
                liveTag = true,
                streamUrl = STREAM_HLS_2
            ),
            upcomingPrograms = listOf(
                EpgProgram("epg_news_2", "The Ingraham Angle", "Cut through Washington bureaucracy with hard-hitting analysis.", "07:00 PM", "08:00 PM", 60, 0f, "TV-PG"),
                EpgProgram("epg_news_3", "Jesse Watters Primetime", "Interviews with major newsmakers and deep-dive commentary.", "08:00 PM", "09:00 PM", 60, 0f, "TV-PG")
            )
        ),
        LiveChannel(
            id = "fox_business",
            channelNumber = "06",
            name = "FOX Business Network",
            callSign = "FBN",
            category = "News",
            logoText = "FOX BIZ",
            streamUrl = STREAM_MP4_ACTION,
            resolution = "1080p",
            bitRate = "8.0 Mbps",
            currentProgram = EpgProgram(
                id = "epg_biz_1",
                title = "The Claman Countdown",
                description = "Wall Street closing bell countdown, tech earnings analysis, and CEO interviews.",
                startTimeFormatted = "04:00 PM",
                endTimeFormatted = "05:00 PM",
                durationMinutes = 60,
                progressPercentage = 0.80f,
                rating = "TV-G",
                liveTag = true,
                streamUrl = STREAM_MP4_ACTION
            ),
            upcomingPrograms = listOf(
                EpgProgram("epg_biz_2", "Kudlow", "Larry Kudlow provides common-sense economic analysis and market outlook.", "05:00 PM", "06:00 PM", 60, 0f, "TV-G")
            )
        ),
        LiveChannel(
            id = "fox_weather",
            channelNumber = "07",
            name = "FOX Weather",
            callSign = "WX-LIVE",
            category = "Weather",
            logoText = "FOX WX",
            streamUrl = STREAM_HLS_1,
            resolution = "1080p 60fps",
            bitRate = "7.5 Mbps",
            currentProgram = EpgProgram(
                id = "epg_wx_1",
                title = "America's Weather Center Live",
                description = "Live 3D radar tracking severe storms across the Midwest and coastal forecasts.",
                startTimeFormatted = "07:00 PM",
                endTimeFormatted = "09:00 PM",
                durationMinutes = 120,
                progressPercentage = 0.30f,
                rating = "TV-G",
                liveTag = true,
                streamUrl = STREAM_HLS_1
            ),
            upcomingPrograms = listOf(
                EpgProgram("epg_wx_2", "FOX Weather Nightly Outlook", "National forecasts and agricultural outlook.", "09:00 PM", "11:00 PM", 120, 0f, "TV-G")
            )
        ),
        LiveChannel(
            id = "fox_sports_2",
            channelNumber = "08",
            name = "FS2 (FOX Sports 2)",
            callSign = "FS2",
            category = "Sports",
            logoText = "FS2",
            streamUrl = STREAM_MP4_ACTION,
            resolution = "1080p",
            bitRate = "9.0 Mbps",
            currentProgram = EpgProgram(
                id = "epg_fs2_1",
                title = "NASCAR Cup Series Qualifying",
                description = "Pole qualifying speeds live from Daytona International Speedway.",
                startTimeFormatted = "06:30 PM",
                endTimeFormatted = "08:30 PM",
                durationMinutes = 120,
                progressPercentage = 0.50f,
                rating = "TV-PG",
                liveTag = true,
                streamUrl = STREAM_MP4_ACTION
            ),
            upcomingPrograms = listOf(
                EpgProgram("epg_fs2_2", "MLS Highlights: Goals of the Week", "All top strikes and defensive saves.", "08:30 PM", "09:30 PM", 60, 0f, "TV-G")
            )
        ),
        LiveChannel(
            id = "fox_la_11",
            channelNumber = "11",
            name = "FOX 11 Los Angeles",
            callSign = "KTTV",
            category = "Local",
            logoText = "FOX 11",
            streamUrl = STREAM_HLS_2,
            resolution = "1080p 60fps",
            bitRate = "10.0 Mbps",
            currentProgram = EpgProgram(
                id = "epg_kttv_1",
                title = "Good Day LA Evening Edition",
                description = "Southern California traffic, Hollywood entertainment headlines and regional weather.",
                startTimeFormatted = "07:00 PM",
                endTimeFormatted = "08:00 PM",
                durationMinutes = 60,
                progressPercentage = 0.35f,
                rating = "TV-PG",
                liveTag = true,
                streamUrl = STREAM_HLS_2
            ),
            upcomingPrograms = listOf(
                EpgProgram("epg_kttv_2", "FOX 11 News at 10", "Investigative reports and local city council findings.", "10:00 PM", "11:00 PM", 60, 0f, "TV-PG")
            )
        )
    )

    val newsArticles: List<NewsArticle> = listOf(
        NewsArticle(
            id = "news_breaking_1",
            headline = "Senate Passes Comprehensive Infrastructure & Energy Modernization Bill",
            summary = "Bipartisan agreement reached on 500-billion-dollar clean grid and bridge resilience package following marathon session.",
            body = "WASHINGTON — After a continuous 36-hour weekend debate, the United States Senate reached a bipartisan breakthrough on the Energy and Transport Modernization Act.\n\nThe legislation allocates dedicated federal resources toward reinforcing electrical grid security against extreme weather events, modernizing inland waterways, and accelerating commercial hydrogen logistics hubs.\n\nCongressional leadership commended committee chairs from both parties for prioritizing long-term national economic resilience over partisan disputes.",
            category = "Politics",
            author = "Edward Ross, Washington Bureau",
            timestamp = "14 MIN AGO",
            isBreaking = true,
            videoUrl = STREAM_HLS_1
        ),
        NewsArticle(
            id = "news_biz_2",
            headline = "Tech Sector Rallies as Cloud Computing & AI Infrastructure Spending Surges",
            summary = "Major indices touch fresh records fueled by enterprise AI software adoption and semiconductor revenue forecasts.",
            body = "NEW YORK — Trading floors saw broad gains across technology and industrial sectors Monday morning. Analysts pointed to double-digit revenue expansions reported by enterprise cloud infrastructure operators, reinforcing that commercial automation investments remain resilient amidst interest rate stabilization.",
            category = "Business",
            author = "Sarah Sterling, Chief Financial Analyst",
            timestamp = "42 MIN AGO",
            isBreaking = false,
            videoUrl = STREAM_MP4_ACTION
        ),
        NewsArticle(
            id = "news_world_3",
            headline = "Pacific Maritime Agreement Secures Commercial Shipping Corridors",
            summary = "Twelve nations sign multilateral maritime security pact ensuring open transit and satellite navigation safeguards.",
            body = "SINGAPORE — Defense and commerce ministers completed negotiations on the Pacific Commercial Transit Accord today, standardizing automated vessel communication and response protocols for international maritime shipping routes.",
            category = "World",
            author = "James Vance, International Desk",
            timestamp = "2 HOURS AGO",
            isBreaking = false
        ),
        NewsArticle(
            id = "news_tech_4",
            headline = "Next-Generation Satellite Communications Network Reaches Full Global Orbit",
            summary = "Low-Earth orbit constellation activates high-bandwidth emergency connectivity for aviation and remote telemetry.",
            body = "CAPE CANAVERAL — The final orbital cluster of high-throughput communication satellites separated successfully this morning. Commercial flights and maritime vessels will gain sub-20ms latency tracking even across polar flight corridors.",
            category = "Technology",
            author = "Elena Cho, Tech & Space Reporter",
            timestamp = "3 HOURS AGO",
            isBreaking = false
        )
    )

    val sportsFixtures: List<SportsFixture> = listOf(
        SportsFixture(
            id = "sport_nfl_1",
            league = "NFL",
            teamHome = "Kansas City Chiefs",
            teamAway = "Philadelphia Eagles",
            scoreHome = 24,
            scoreAway = 21,
            periodOrStatus = "4th Qtr 3:45",
            channelName = "FOX",
            isLive = true,
            streamUrl = STREAM_MP4_SPORTS,
            venue = "Arrowhead Stadium",
            headline = "Mahomes drives into red zone; Chiefs protecting 3-point lead late in 4th quarter"
        ),
        SportsFixture(
            id = "sport_nfl_2",
            league = "NFL",
            teamHome = "Dallas Cowboys",
            teamAway = "San Francisco 49ers",
            scoreHome = 17,
            scoreAway = 14,
            periodOrStatus = "3rd Qtr 8:12",
            channelName = "FS1",
            isLive = true,
            streamUrl = STREAM_HLS_1,
            venue = "AT&T Stadium",
            headline = "Defensive clash in Arlington: Cowboys intercept on 20-yard line"
        ),
        SportsFixture(
            id = "sport_mlb_1",
            league = "MLB on FOX",
            teamHome = "Los Angeles Dodgers",
            teamAway = "New York Yankees",
            scoreHome = 5,
            scoreAway = 3,
            periodOrStatus = "Final",
            channelName = "FOX",
            isLive = false,
            streamUrl = STREAM_MP4_ACTION,
            venue = "Dodger Stadium",
            headline = "Ohtani launches 440-foot home run as Dodgers clinch series opener"
        ),
        SportsFixture(
            id = "sport_cfb_1",
            league = "College Football",
            teamHome = "Ohio State Buckeyes",
            teamAway = "Michigan Wolverines",
            scoreHome = null,
            scoreAway = null,
            periodOrStatus = "Saturday 12:00 PM ET",
            channelName = "BIG NOON SATURDAY on FOX",
            isLive = false,
            streamUrl = STREAM_HLS_2,
            venue = "Ohio Stadium, Columbus",
            headline = "Rivalry Week: #2 Ohio State hosts #5 Michigan with national championship berth on the line"
        ),
        SportsFixture(
            id = "sport_nascar_1",
            league = "NASCAR on FOX",
            teamHome = "Daytona 500",
            teamAway = "Pole Position",
            scoreHome = null,
            scoreAway = null,
            periodOrStatus = "Sunday 2:30 PM ET",
            channelName = "FOX",
            isLive = false,
            streamUrl = STREAM_MP4_SPORTS,
            venue = "Daytona International Speedway",
            headline = "The Great American Race: 40 drivers take the green flag in Florida"
        )
    )

    fun getShowsByCategory(category: Category): List<MediaItem> {
        return allShows.filter { it.category == category }
    }

    fun searchAll(query: String): List<MediaItem> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return allShows
        return allShows.filter {
            it.title.lowercase().contains(q) ||
            it.synopsis.lowercase().contains(q) ||
            it.genre.lowercase().contains(q) ||
            it.cast.any { actor -> actor.lowercase().contains(q) } ||
            it.tags.any { tag -> tag.lowercase().contains(q) }
        }
    }
}
