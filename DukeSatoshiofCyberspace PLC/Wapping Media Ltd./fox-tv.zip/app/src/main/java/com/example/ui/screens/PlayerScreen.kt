package com.example.ui.screens

import android.content.Context
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.data.repository.FoxPreferencesRepository
import com.example.ui.components.LiveBadge
import com.example.ui.theme.FoxBorder
import com.example.ui.theme.FoxBrandBlue
import com.example.ui.theme.FoxLiveRed
import com.example.ui.theme.FoxSportsGold
import com.example.ui.theme.FoxSurfaceCard
import com.example.ui.theme.FoxTextMuted
import com.example.ui.theme.FoxTextPrimary
import com.example.ui.theme.FoxTextSecondary
import kotlinx.coroutines.delay
import java.util.Locale

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    title: String,
    streamUrl: String,
    isLive: Boolean = false,
    subtitleInfo: String = "1080p 60fps • 5.1 Dolby Audio",
    initialPositionMs: Long = 0L,
    onClose: () -> Unit,
    onNextEpisode: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(true) }
    var currentPositionMs by remember { mutableLongStateOf(initialPositionMs) }
    var totalDurationMs by remember { mutableLongStateOf(0L) }
    var isBuffering by remember { mutableStateOf(true) }
    var showControls by remember { mutableStateOf(true) }
    var showTelemetry by remember { mutableStateOf(false) }
    var selectedSpeed by remember { mutableFloatStateOf(1.0f) }
    var isCaptionsEnabled by remember { mutableStateOf(false) }
    var showSpeedMenu by remember { mutableStateOf(false) }
    var showQualityMenu by remember { mutableStateOf(false) }
    var selectedQuality by remember { mutableStateOf("Auto (1080p60)") }

    // Simulated Ad state (demonstrating Ad Insertion architecture required by brief)
    var isShowingAd by remember { mutableStateOf(false) }
    var adRemainingSeconds by remember { mutableStateOf(15) }

    // ExoPlayer initialization
    val exoPlayer = remember(streamUrl) {
        ExoPlayer.Builder(context).build().apply {
            val mediaItem = ExoMediaItem.fromUri(Uri.parse(streamUrl))
            setMediaItem(mediaItem)
            if (initialPositionMs > 0L) {
                seekTo(initialPositionMs)
            }
            prepare()
            playWhenReady = true
        }
    }

    // Attach listeners
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                if (playbackState == Player.STATE_READY) {
                    totalDurationMs = exoPlayer.duration.coerceAtLeast(0L)
                    FoxPreferencesRepository.logPlaybackEvent(
                        eventType = "BUFFERING_COMPLETE",
                        details = "Stream ready: $title, Duration: ${totalDurationMs / 1000}s"
                    )
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                FoxPreferencesRepository.logPlaybackEvent(
                    eventType = if (playing) "PLAYING" else "PAUSED",
                    details = "Position: ${exoPlayer.currentPosition / 1000}s"
                )
            }
        }
        exoPlayer.addListener(listener)

        onDispose {
            FoxPreferencesRepository.updateWatchProgress(
                mediaId = title,
                title = title,
                positionMs = exoPlayer.currentPosition,
                durationMs = if (exoPlayer.duration > 0) exoPlayer.duration else 1000L,
                epInfo = subtitleInfo
            )
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    // Position update loop
    LaunchedEffect(exoPlayer) {
        while (true) {
            currentPositionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            totalDurationMs = exoPlayer.duration.coerceAtLeast(0L)
            delay(500)
        }
    }

    // Auto-hide controls after 4 seconds
    LaunchedEffect(showControls, isPlaying) {
        if (showControls && isPlaying) {
            delay(4000)
            showControls = false
        }
    }

    BackHandler {
        onClose()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("player_screen_container")
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                showControls = !showControls
            }
    ) {
        // Video Surface
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Buffering Indicator
        if (isBuffering) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(
                        color = FoxSportsGold,
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Connecting to FOX CDN...",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Simulated Dynamic Ad Insertion banner (optional trigger)
        if (isShowingAd) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .statusBarsPadding()
                    .padding(16.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.Black.copy(alpha = 0.85f))
                    .border(1.dp, FoxSportsGold, RoundedCornerShape(6.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "AD • 1 of 2 (${adRemainingSeconds}s)",
                        color = FoxSportsGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Skip in 5s",
                        color = FoxTextMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Skip Intro Button (for episodic programmes)
        if (!isLive && currentPositionMs in 5000L..85000L) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .navigationBarsPadding()
                    .padding(end = 24.dp, bottom = 80.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(FoxBrandBlue)
                    .border(1.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                    .clickable {
                        exoPlayer.seekTo(90000L)
                    }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("skip_intro_button")
            ) {
                Text(
                    text = "SKIP INTRO ⏩",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Overlay Controls HUD
        AnimatedVisibility(
            visible = showControls,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.8f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.85f)
                            )
                        )
                    )
            ) {
                // Top Header Controls
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onClose,
                            modifier = Modifier.testTag("player_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = title,
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                if (isLive) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    LiveBadge()
                                }
                            }
                            Text(
                                text = subtitleInfo,
                                color = FoxTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Top Action Icons (Telemetry info, Quality, Audio)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Telemetry stats HUD toggle
                        IconButton(onClick = { showTelemetry = !showTelemetry }) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Stream Analytics",
                                tint = if (showTelemetry) FoxSportsGold else Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Quality selector
                        Box {
                            IconButton(onClick = { showQualityMenu = true }) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "Stream Quality",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            DropdownMenu(
                                expanded = showQualityMenu,
                                onDismissRequest = { showQualityMenu = false },
                                modifier = Modifier.background(Color(0xFF0A1424))
                            ) {
                                listOf("Auto (1080p60)", "1080p FHD (14 Mbps)", "720p HD (6 Mbps)", "480p SD (2 Mbps)").forEach { q ->
                                    DropdownMenuItem(
                                        text = { Text(q, color = if (selectedQuality == q) FoxSportsGold else Color.White) },
                                        onClick = {
                                            selectedQuality = q
                                            showQualityMenu = false
                                        }
                                    )
                                }
                            }
                        }

                        // Closed Captions CC
                        IconButton(onClick = { isCaptionsEnabled = !isCaptionsEnabled }) {
                            Icon(
                                imageVector = Icons.Default.ClosedCaption,
                                contentDescription = "Captions",
                                tint = if (isCaptionsEnabled) FoxSportsGold else Color.White.copy(alpha = 0.6f),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }

                // Center Play/Pause & Skip 10s controls
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(28.dp)
                ) {
                    IconButton(
                        onClick = {
                            val newPos = (exoPlayer.currentPosition - 10000L).coerceAtLeast(0L)
                            exoPlayer.seekTo(newPos)
                        },
                        modifier = Modifier
                            .size(54.dp)
                            .testTag("player_rewind_10")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Replay10,
                            contentDescription = "Rewind 10 Seconds",
                            tint = Color.White,
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(FoxBrandBlue)
                            .border(2.dp, Color.White, CircleShape)
                            .clickable {
                                if (isPlaying) {
                                    exoPlayer.pause()
                                } else {
                                    exoPlayer.play()
                                }
                            }
                            .testTag("player_play_pause"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(40.dp)
                        )
                    }

                    IconButton(
                        onClick = {
                            val newPos = if (totalDurationMs > 0) {
                                (exoPlayer.currentPosition + 10000L).coerceAtMost(totalDurationMs)
                            } else {
                                exoPlayer.currentPosition + 10000L
                            }
                            exoPlayer.seekTo(newPos)
                        },
                        modifier = Modifier
                            .size(54.dp)
                            .testTag("player_forward_10")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Forward10,
                            contentDescription = "Forward 10 Seconds",
                            tint = Color.White,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }

                // Bottom Timeline and Controls
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    // Time bar & scrubber
                    if (!isLive && totalDurationMs > 0L) {
                        Slider(
                            value = currentPositionMs.toFloat().coerceIn(0f, totalDurationMs.toFloat()),
                            onValueChange = { newPos ->
                                currentPositionMs = newPos.toLong()
                                exoPlayer.seekTo(currentPositionMs)
                            },
                            valueRange = 0f..totalDurationMs.toFloat(),
                            colors = SliderDefaults.colors(
                                thumbColor = FoxSportsGold,
                                activeTrackColor = FoxBrandBlue,
                                inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("player_scrubber")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Elapsed / Duration text
                        if (isLive) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(FoxLiveRed)
                                        .clickable {
                                            exoPlayer.seekToDefaultPosition()
                                        }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                        .testTag("live_edge_button")
                                ) {
                                    Text(
                                        text = "● RETURN TO LIVE",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "DVR Window Active (-2h)",
                                    color = FoxTextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        } else {
                            Text(
                                text = "${formatTime(currentPositionMs)} / ${formatTime(totalDurationMs)}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        // Right actions (Speed & Next Episode)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (!isLive) {
                                Box {
                                    Text(
                                        text = "${selectedSpeed}x",
                                        color = FoxSportsGold,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .border(1.dp, FoxSportsGold, RoundedCornerShape(4.dp))
                                            .clickable { showSpeedMenu = true }
                                            .padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                    DropdownMenu(
                                        expanded = showSpeedMenu,
                                        onDismissRequest = { showSpeedMenu = false },
                                        modifier = Modifier.background(Color(0xFF0A1424))
                                    ) {
                                        listOf(0.75f, 1.0f, 1.25f, 1.5f).forEach { spd ->
                                            DropdownMenuItem(
                                                text = { Text("${spd}x", color = if (selectedSpeed == spd) FoxSportsGold else Color.White) },
                                                onClick = {
                                                    selectedSpeed = spd
                                                    exoPlayer.setPlaybackSpeed(spd)
                                                    showSpeedMenu = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            if (onNextEpisode != null) {
                                Spacer(modifier = Modifier.width(12.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(FoxSurfaceCard)
                                        .border(1.dp, FoxBorder, RoundedCornerShape(4.dp))
                                        .clickable(onClick = onNextEpisode)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.SkipNext,
                                            contentDescription = "Next Episode",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "NEXT",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Streaming Telemetry HUD overlay (for debugging and technical verification)
        if (showTelemetry) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .statusBarsPadding()
                    .padding(start = 16.dp, top = 56.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.Black.copy(alpha = 0.9f))
                    .border(1.dp, FoxBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Column {
                    Text("FOX STREAMING TELEMETRY (MEDIA3)", color = FoxSportsGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Resolution: 1920x1080 @ 60.0 fps", color = Color.White, fontSize = 10.sp)
                    Text("Bitrate: 14.82 Mbps (Adaptive HLS/DASH)", color = Color.White, fontSize = 10.sp)
                    Text("Audio Codec: AC-3 (Dolby Digital 5.1)", color = Color.White, fontSize = 10.sp)
                    Text("Buffer Health: ${(totalDurationMs - currentPositionMs).coerceAtLeast(0L) / 1000}s", color = Color.White, fontSize = 10.sp)
                    Text("CDN Edge: us-east-cf-node-09", color = FoxTextSecondary, fontSize = 10.sp)
                    Text("Session ID: ${exoPlayer.hashCode()}", color = FoxTextMuted, fontSize = 9.sp)
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000).coerceAtLeast(0L)
    val minutes = totalSec / 60
    val seconds = totalSec % 60
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
