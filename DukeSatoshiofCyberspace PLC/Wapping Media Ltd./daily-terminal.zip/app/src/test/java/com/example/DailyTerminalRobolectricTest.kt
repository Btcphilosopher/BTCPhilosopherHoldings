package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.ingestion.FeedIngestionService
import com.example.data.local.DailyTerminalDatabase
import com.example.data.local.SeedData
import com.example.data.local.VenuePreferencesStore
import com.example.data.model.ContentRightsMode
import com.example.data.model.DateFilterOption
import com.example.data.model.NewsSection
import com.example.data.model.SourceHealthStatus
import com.example.data.model.VenueConfig
import com.example.data.repository.NewsRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DailyTerminalRobolectricTest {

    private lateinit var db: DailyTerminalDatabase
    private lateinit var repository: NewsRepository
    private lateinit var prefsStore: VenuePreferencesStore
    private lateinit var dataStoreScope: kotlinx.coroutines.CoroutineScope

    @Before
    fun setup() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, DailyTerminalDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val dao = db.dao()
        val nowMs = System.currentTimeMillis()
        dao.insertPublishers(SeedData.buildSeedPublishers())
        dao.insertFeedSources(SeedData.buildSeedFeeds(nowMs))
        dao.insertClusters(SeedData.buildSeedClusters(nowMs))
        dao.insertArticles(SeedData.buildSeedArticles(nowMs))
        dao.insertArticleVersions(SeedData.buildSeedVersions(nowMs))
        dao.insertRefreshJobs(SeedData.buildSeedRefreshJobs(nowMs))

        dataStoreScope = kotlinx.coroutines.CoroutineScope(
            kotlinx.coroutines.Dispatchers.IO + kotlinx.coroutines.SupervisorJob()
        )
        val testPrefsFile = java.io.File(context.filesDir, "test_prefs_${java.util.UUID.randomUUID()}.preferences_pb")
        val testDataStore = androidx.datastore.preferences.core.PreferenceDataStoreFactory.create(
            scope = dataStoreScope,
            produceFile = { testPrefsFile }
        )
        prefsStore = VenuePreferencesStore(context, testDataStore)
        val ingestion = FeedIngestionService(dao)
        repository = NewsRepository(dao, prefsStore, ingestion)
    }

    @After
    fun tearDown() {
        db.close()
        dataStoreScope.coroutineContext[kotlinx.coroutines.Job]?.cancel()
    }

    @Test
    fun `fixture feed ingestion deduplicates repeated entries and preserves version history on headline update`() = runBlocking {
        // Seed had civic-2026-lib-012 titled "...across six boroughs"; fixture updates it to "...across seven boroughs"
        // plus contains a duplicate of civic-2026-rail-001 and a brand-new ferry story.
        val result = repository.importSingleFeedById("feed_civic_review", VenueConfig())
        assertFalse(result.failed)
        assertTrue("Expected at least 1 new article inserted", result.inserted >= 1)
        assertTrue("Expected duplicate entry to be skipped", result.deduplicated >= 1)
        assertTrue("Expected updated headline to increment version", result.updated >= 1)

        val versions = repository.observeVersionsForArticle("art_civic_evening_libraries").first()
        assertTrue("Expected version history preserved after headline change", versions.isNotEmpty())
        assertTrue(versions.first().title.contains("seven boroughs"))
    }

    @Test
    fun `kiosk session reset clears saved items and reading history cleanly`() = runBlocking {
        val session1 = prefsStore.ensureInitializedSession()
        repository.toggleSaveArticle(session1, "art_railway_cities")
        repository.recordReadingHistory(session1, "art_north_sea")

        assertEquals(listOf("art_railway_cities"), repository.observeSavedArticleIds(session1).first())
        assertEquals(listOf("art_north_sea"), repository.observeHistoryArticleIds(session1).first())

        val session2 = repository.resetKioskSession(session1)
        assertNotEquals(session1, session2)
        assertTrue(repository.observeSavedArticleIds(session1).first().isEmpty())
        assertTrue(repository.observeHistoryArticleIds(session1).first().isEmpty())
        assertTrue(repository.observeSavedArticleIds(session2).first().isEmpty())
    }

    @Test
    fun `search enforces content indexing permissions and section filters`() = runBlocking {
        val articles = repository.activeArticlesFlow.first()
        // Mark one article as disallowed from search indexing
        val target = articles.first { it.id == "art_materials_lab" }
        db.dao().upsertArticle(target.copy(allowSearchIndex = false))

        val updated = repository.activeArticlesFlow.first()
        val results = repository.filterPermittedSearchResults(
            articles = updated,
            query = "materials laboratory",
            section = NewsSection.SCIENCE,
            publisherFilter = null,
            dateFilter = DateFilterOption.ALL,
            languageFilter = null,
            articleTypeFilter = null,
        )
        assertTrue("Non-indexable article must not appear in search results", results.isEmpty())

        // Link-only article should not match body/excerpt words it isn't licensed to index
        val linkOnlyResults = repository.filterPermittedSearchResults(
            articles = updated,
            query = "pension",
            section = NewsSection.BUSINESS,
            publisherFilter = "Market Ledger",
            dateFilter = DateFilterOption.ALL,
            languageFilter = "en",
            articleTypeFilter = null,
        )
        assertEquals(1, linkOnlyResults.size)
        assertEquals(ContentRightsMode.HEADLINE_AND_LINK.name, linkOnlyResults.first().contentRightsMode)
    }

    @Test
    fun `editorial cluster split and merge update articles and record audit logs`() = runBlocking {
        repository.splitArticleFromCluster("art_world_rail_hubs", "Continental Rail Comparison")
        val splitArticle = db.dao().getArticleById("art_world_rail_hubs")!!
        val splitClusterId = splitArticle.clusterId!!
        assertNotEquals("cluster_railways", splitClusterId)

        repository.mergeClusters(splitClusterId, "cluster_railways")
        val mergedArticle = db.dao().getArticleById("art_world_rail_hubs")!!
        assertEquals("cluster_railways", mergedArticle.clusterId)

        val logs = repository.auditLogsFlow.first()
        assertTrue(logs.any { it.actionType == "CLUSTER_SPLIT" })
        assertTrue(logs.any { it.actionType == "CLUSTER_MERGED" })
    }

    @Test
    fun `admin passcode verification accepts valid pin and rejects wrong pin`() = runBlocking {
        assertTrue(repository.verifyAdminPin("2468"))
        assertFalse(repository.verifyAdminPin("0000"))
    }

    @Test
    fun `unavailable and stale sources coexist with healthy edition without breaking front page`() = runBlocking {
        val feeds = repository.feedSourcesFlow.first()
        assertTrue(feeds.any { it.healthStatus == SourceHealthStatus.UNAVAILABLE.name })
        assertTrue(feeds.any { it.healthStatus == SourceHealthStatus.STALE.name })
        val articles = repository.activeArticlesFlow.first()
        assertTrue(articles.any { it.id == "art_railway_cities" })
    }
}
