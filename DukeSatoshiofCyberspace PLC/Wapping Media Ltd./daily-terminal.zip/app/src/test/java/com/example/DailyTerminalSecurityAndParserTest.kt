package com.example

import com.example.data.ingestion.FeedParseOutcome
import com.example.data.ingestion.FeedParser
import com.example.data.ingestion.LocalFixtureFeeds
import com.example.data.ingestion.RankingEngine
import com.example.data.local.SeedData
import com.example.data.model.ContentRightsMode
import com.example.data.model.ReadingTimeCalculator
import com.example.data.model.SourceHealthStatus
import com.example.data.model.VenueConfig
import com.example.security.FeedUrlValidator
import com.example.security.HtmlSanitizer
import com.example.security.QrCodeGenerator
import com.example.security.UrlValidationResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DailyTerminalSecurityAndParserTest {

    @Test
    fun `unsafe and private network URLs are rejected by SSRF validator`() {
        val unsafeUrls = listOf(
            "http://example.com/rss.xml",
            "https://localhost/feed.xml",
            "https://127.0.0.1/feed.xml",
            "https://169.254.169.254/latest/meta-data",
            "https://10.0.0.5/internal.xml",
            "https://192.168.1.1/rss.xml",
            "https://172.16.0.4/atom.xml",
            "https://user:pass@example.com/rss.xml",
            "file:///etc/passwd",
            "https://metadata.google.internal/computeMetadata",
        )
        unsafeUrls.forEach { url ->
            val result = FeedUrlValidator.validateRemoteFeedUrl(url, resolveDns = false)
            assertTrue("Expected $url to be rejected", result is UrlValidationResult.Rejected)
        }

        val valid = FeedUrlValidator.validateRemoteFeedUrl(
            "https://civicreview.example/rss.xml?utm_source=test&section=britain",
            resolveDns = false
        )
        assertTrue(valid is UrlValidationResult.Valid)
        assertEquals(
            "https://civicreview.example/rss.xml?section=britain",
            (valid as UrlValidationResult.Valid).normalizedUrl
        )
    }

    @Test
    fun `malicious HTML payloads are stripped cleanly`() {
        val malicious = """
            <p>Library reading rooms expand hours.</p>
            <script>alert('xss')</script>
            <img src="x" onerror="fetch('https://evil.test')" />
            <a href="javascript:stealCookies()">Click</a>
            <iframe src="https://evil.test/frame"></iframe>
        """.trimIndent()
        val sanitized = HtmlSanitizer.sanitizeToPlainText(malicious)
        assertTrue(sanitized.contains("Library reading rooms expand hours."))
        assertFalse(sanitized.contains("alert"))
        assertFalse(sanitized.contains("onerror"))
        assertFalse(sanitized.contains("javascript:"))
        assertFalse(sanitized.contains("<script"))
        assertFalse(sanitized.contains("<iframe"))
    }

    @Test
    fun `RSS and Atom fixture feeds parse safely and reject XXE or malformed XML`() {
        val rssOutcome = FeedParser.parseXml(LocalFixtureFeeds.CIVIC_REVIEW_DEMO_RSS)
        assertTrue(rssOutcome is FeedParseOutcome.Success)
        val rssItems = (rssOutcome as FeedParseOutcome.Success).items
        assertEquals(4, rssItems.size)
        // Verify XSS inside Civic Review fixture description was stripped
        assertFalse(rssItems[2].excerpt.contains("<script"))

        val atomOutcome = FeedParser.parseXml(LocalFixtureFeeds.INDUSTRY_JOURNAL_DEMO_ATOM)
        assertTrue(atomOutcome is FeedParseOutcome.Success)
        assertEquals(2, (atomOutcome as FeedParseOutcome.Success).items.size)

        val xxeXml = """
            <?xml version="1.0"?>
            <!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
            <rss version="2.0"><channel><item><title>&xxe;</title></item></channel></rss>
        """.trimIndent()
        assertTrue(FeedParser.parseXml(xxeXml) is FeedParseOutcome.Failure)

        val malformed = "<rss><channel><item><title>Broken"
        assertTrue(FeedParser.parseXml(malformed) is FeedParseOutcome.Failure)
    }

    @Test
    fun `reading time calculator never invents full length for excerpt or link-only articles`() {
        assertNull(ReadingTimeCalculator.estimateMinutesOrNull(ContentRightsMode.HEADLINE_AND_LINK, "Long text ".repeat(100)))
        assertNull(ReadingTimeCalculator.estimateMinutesOrNull(ContentRightsMode.HEADLINE_AND_EXCERPT, "Long text ".repeat(100)))
        val fullMins = ReadingTimeCalculator.estimateMinutesOrNull(
            ContentRightsMode.LICENSED_FULL_TEXT,
            "word ".repeat(630)
        )
        assertEquals(3, fullMins)
    }

    @Test
    fun `stale source receives negative ranking adjustment with clear explanation`() {
        val nowMs = System.currentTimeMillis()
        val articles = SeedData.buildSeedArticles(nowMs)
        val staleArticle = articles.first { it.id == "art_parliament_committee" }
        val healthMap = mapOf("feed_parliament_digest" to SourceHealthStatus.STALE)
        val result = RankingEngine.computeRanking(
            article = staleArticle,
            venueConfig = VenueConfig(),
            feedHealthMap = healthMap,
            seenPublishersCount = 0,
            nowMs = nowMs,
        )
        assertTrue(result.explanation.contains("Stale Source (-10)"))
    }

    @Test
    fun `QR code generator produces valid square matrix with finder patterns`() {
        val matrix = QrCodeGenerator.encodeToMatrix("https://civicreview.example/britain/next-chapter-railway-cities")
        val size = matrix.size
        assertTrue(size >= 21)
        assertEquals(size, matrix[0].size)
        // Top-left finder outer corner dark
        assertTrue(matrix[0][0])
        assertTrue(matrix[6][6])
        assertFalse(matrix[1][1])
        // Top-right finder dark corner
        assertTrue(matrix[0][size - 1])
        // Bottom-left finder dark corner
        assertTrue(matrix[size - 1][0])
    }
}
