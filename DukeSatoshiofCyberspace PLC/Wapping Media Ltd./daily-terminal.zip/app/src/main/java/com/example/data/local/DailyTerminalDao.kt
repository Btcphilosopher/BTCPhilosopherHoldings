package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyTerminalDao {
    // Publishers & Feeds
    @Query("SELECT * FROM publishers ORDER BY name ASC")
    fun observePublishers(): Flow<List<PublisherEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPublishers(publishers: List<PublisherEntity>)

    @Query("SELECT * FROM feed_sources ORDER BY publisherName ASC")
    fun observeFeedSources(): Flow<List<FeedSourceEntity>>

    @Query("SELECT * FROM feed_sources")
    suspend fun getAllFeedSourcesOnce(): List<FeedSourceEntity>

    @Query("SELECT * FROM feed_sources WHERE id = :id LIMIT 1")
    suspend fun getFeedSourceById(id: String): FeedSourceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFeedSources(feeds: List<FeedSourceEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFeedSource(feed: FeedSourceEntity)

    // Articles & Versions
    @Query("SELECT * FROM articles WHERE status != 'WITHDRAWN' ORDER BY manualLeadOverride DESC, rankingScore DESC, publishedAtMs DESC")
    fun observeActiveArticles(): Flow<List<ArticleEntity>>

    @Query("SELECT * FROM articles ORDER BY ingestedAtMs DESC")
    fun observeAllArticlesForAdmin(): Flow<List<ArticleEntity>>

    @Query("SELECT * FROM articles")
    suspend fun getAllArticlesOnce(): List<ArticleEntity>

    @Query("SELECT * FROM articles WHERE id = :id LIMIT 1")
    fun observeArticleById(id: String): Flow<ArticleEntity?>

    @Query("SELECT * FROM articles WHERE id = :id LIMIT 1")
    suspend fun getArticleById(id: String): ArticleEntity?

    @Query("SELECT * FROM articles WHERE canonicalUrl = :canonicalUrl LIMIT 1")
    suspend fun findByCanonicalUrl(canonicalUrl: String): ArticleEntity?

    @Query("SELECT * FROM articles WHERE sourceGuid = :sourceGuid LIMIT 1")
    suspend fun findBySourceGuid(sourceGuid: String): ArticleEntity?

    @Query("SELECT * FROM articles WHERE contentFingerprint = :fingerprint LIMIT 1")
    suspend fun findByFingerprint(fingerprint: String): ArticleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArticles(articles: List<ArticleEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertArticle(article: ArticleEntity)

    @Update
    suspend fun updateArticle(article: ArticleEntity)

    @Query("UPDATE articles SET manualLeadOverride = 0 WHERE manualLeadOverride = 1")
    suspend fun clearManualLeadOverrides()

    @Query("UPDATE articles SET manualLeadOverride = 1, slotRole = 'LEAD' WHERE id = :articleId")
    suspend fun setManualLeadOverride(articleId: String)

    @Query("UPDATE articles SET status = :status WHERE id = :articleId")
    suspend fun updateArticleStatus(articleId: String, status: String)

    @Query("UPDATE articles SET clusterId = :targetClusterId WHERE clusterId = :sourceClusterId")
    suspend fun reassignArticlesCluster(sourceClusterId: String, targetClusterId: String)

    @Query("UPDATE articles SET clusterId = :newClusterId WHERE id = :articleId")
    suspend fun assignArticleToCluster(articleId: String, newClusterId: String?)

    @Query("SELECT * FROM article_versions WHERE articleId = :articleId ORDER BY versionNumber DESC")
    fun observeVersionsForArticle(articleId: String): Flow<List<ArticleVersionEntity>>

    @Query("SELECT MAX(versionNumber) FROM article_versions WHERE articleId = :articleId")
    suspend fun getLatestVersionNumber(articleId: String): Int?

    @Insert
    suspend fun insertArticleVersion(version: ArticleVersionEntity)

    @Insert
    suspend fun insertArticleVersions(versions: List<ArticleVersionEntity>)

    // Clusters
    @Query("SELECT * FROM story_clusters ORDER BY updatedAtMs DESC")
    fun observeClusters(): Flow<List<StoryClusterEntity>>

    @Query("SELECT * FROM story_clusters")
    suspend fun getAllClustersOnce(): List<StoryClusterEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCluster(cluster: StoryClusterEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClusters(clusters: List<StoryClusterEntity>)

    @Query("DELETE FROM story_clusters WHERE id = :clusterId")
    suspend fun deleteCluster(clusterId: String)

    // Editorial placements & Edition snapshots
    @Query("SELECT * FROM editorial_placements WHERE id = 'default' LIMIT 1")
    fun observeDefaultPlacement(): Flow<EditorialPlacementEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPlacement(placement: EditorialPlacementEntity)

    @Query("SELECT * FROM edition_snapshots ORDER BY builtAtMs DESC")
    fun observeEditionSnapshots(): Flow<List<EditionSnapshotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEditionSnapshot(snapshot: EditionSnapshotEntity)

    // Refresh jobs
    @Query("SELECT * FROM refresh_jobs ORDER BY finishedAtMs DESC LIMIT 40")
    fun observeRefreshJobs(): Flow<List<RefreshJobEntity>>

    @Insert
    suspend fun insertRefreshJob(job: RefreshJobEntity)

    @Insert
    suspend fun insertRefreshJobs(jobs: List<RefreshJobEntity>)

    // Anonymous Session-scoped Saved Items & Reading History
    @Query("SELECT articleId FROM saved_items WHERE sessionId = :sessionId ORDER BY savedAtMs DESC")
    fun observeSavedArticleIds(sessionId: String): Flow<List<String>>

    @Query("SELECT COUNT(*) FROM saved_items WHERE sessionId = :sessionId AND articleId = :articleId")
    suspend fun isArticleSavedInSession(sessionId: String, articleId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveItem(item: SavedItemEntity)

    @Query("DELETE FROM saved_items WHERE sessionId = :sessionId AND articleId = :articleId")
    suspend fun removeSavedItem(sessionId: String, articleId: String)

    @Query("DELETE FROM saved_items WHERE sessionId = :sessionId")
    suspend fun clearSavedItemsForSession(sessionId: String)

    @Query("SELECT articleId FROM reading_history WHERE sessionId = :sessionId ORDER BY openedAtMs DESC")
    fun observeHistoryArticleIds(sessionId: String): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun recordHistory(entry: ReadingHistoryEntity)

    @Query("DELETE FROM reading_history WHERE sessionId = :sessionId")
    suspend fun clearHistoryForSession(sessionId: String)

    // Audit Log
    @Query("SELECT * FROM audit_logs ORDER BY createdAtMs DESC LIMIT 100")
    fun observeAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert
    suspend fun insertAuditLog(log: AuditLogEntity)

    @Insert
    suspend fun insertAuditLogs(logs: List<AuditLogEntity>)
}
