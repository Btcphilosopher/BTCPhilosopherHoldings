package com.example.security

import java.net.InetAddress
import java.net.URI

sealed class UrlValidationResult {
    data class Valid(val normalizedUrl: String, val host: String) : UrlValidationResult()
    data class Rejected(val reason: String) : UrlValidationResult()
}

object FeedUrlValidator {
    private val trackingParams = setOf(
        "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
        "fbclid", "gclid", "mc_cid", "mc_eid", "ref"
    )

    private val blockedHosts = setOf(
        "localhost",
        "localhost.localdomain",
        "metadata.google.internal",
        "metadata",
        "169.254.169.254",
        "0.0.0.0",
        "::1",
    )

    fun validateRemoteFeedUrl(
        rawUrl: String,
        resolveDns: Boolean = false,
        allowLocalFixtureScheme: Boolean = false
    ): UrlValidationResult {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) {
            return UrlValidationResult.Rejected("URL must not be empty.")
        }
        if (allowLocalFixtureScheme && trimmed.startsWith("fixture://")) {
            return UrlValidationResult.Valid(trimmed, "local-fixture")
        }
        if (trimmed.length > 2048) {
            return UrlValidationResult.Rejected("URL exceeds maximum allowed length.")
        }

        val uri = try {
            URI(trimmed)
        } catch (e: Exception) {
            return UrlValidationResult.Rejected("Malformed URI syntax.")
        }

        val scheme = uri.scheme?.lowercase() ?: ""
        if (scheme != "https") {
            return UrlValidationResult.Rejected("Only HTTPS feed endpoints are permitted (found '$scheme').")
        }

        if (!uri.userInfo.isNullOrBlank()) {
            return UrlValidationResult.Rejected("Embedded credentials in URL are prohibited.")
        }

        val host = uri.host?.lowercase()?.trimEnd('.') ?: ""
        if (host.isBlank()) {
            return UrlValidationResult.Rejected("Feed URL is missing a valid host.")
        }

        if (host in blockedHosts ||
            host.endsWith(".local") ||
            host.endsWith(".internal") ||
            host.endsWith(".localhost")
        ) {
            return UrlValidationResult.Rejected("Private or internal hostnames are blocked: $host")
        }

        if (isPrivateOrReservedIpLiteral(host)) {
            return UrlValidationResult.Rejected("Private, loopback, or link-local IP addresses are blocked.")
        }

        if (resolveDns) {
            try {
                val addresses = InetAddress.getAllByName(host)
                if (addresses.isEmpty()) {
                    return UrlValidationResult.Rejected("Could not resolve host $host.")
                }
                for (addr in addresses) {
                    if (isUnsafeInetAddress(addr)) {
                        return UrlValidationResult.Rejected("Host $host resolves to a private or reserved network address.")
                    }
                }
            } catch (e: Exception) {
                return UrlValidationResult.Rejected("DNS resolution failed for $host.")
            }
        }

        return UrlValidationResult.Valid(canonicalizeUrl(trimmed), host)
    }

    fun isUnsafeInetAddress(address: InetAddress): Boolean {
        if (address.isAnyLocalAddress ||
            address.isLoopbackAddress ||
            address.isLinkLocalAddress ||
            address.isSiteLocalAddress ||
            address.isMulticastAddress
        ) {
            return true
        }
        val bytes = address.address
        // Check IPv4 CGNAT 100.64.0.0/10 and 0.0.0.0/8 and IPv6 ULA fc00::/7
        if (bytes.size == 4) {
            val b0 = bytes[0].toInt() and 0xFF
            val b1 = bytes[1].toInt() and 0xFF
            if (b0 == 0 || b0 == 10 || b0 == 127) return true
            if (b0 == 100 && b1 in 64..127) return true
            if (b0 == 169 && b1 == 254) return true
            if (b0 == 172 && b1 in 16..31) return true
            if (b0 == 192 && b1 == 168) return true
            if (b0 >= 224) return true
        } else if (bytes.size == 16) {
            val b0 = bytes[0].toInt() and 0xFF
            // Unique local fc00::/7 or link-local fe80::/10
            if ((b0 and 0xFE) == 0xFC) return true
            if (b0 == 0xFE && ((bytes[1].toInt() and 0xC0) == 0x80)) return true
        }
        return false
    }

    private fun isPrivateOrReservedIpLiteral(host: String): Boolean {
        val cleaned = host.removePrefix("[").removeSuffix("]")
        // Quick IPv4 literal check without triggering DNS
        val ipv4Regex = Regex("""^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$""")
        val match = ipv4Regex.matchEntire(cleaned)
        if (match != null) {
            val octets = match.groupValues.drop(1).mapNotNull { it.toIntOrNull() }
            if (octets.size != 4 || octets.any { it > 255 }) return true
            val (b0, b1, _, _) = octets
            return b0 == 0 ||
                b0 == 10 ||
                b0 == 127 ||
                (b0 == 100 && b1 in 64..127) ||
                (b0 == 169 && b1 == 254) ||
                (b0 == 172 && b1 in 16..31) ||
                (b0 == 192 && b1 == 168) ||
                b0 >= 224
        }
        // Quick IPv6 literal check
        if (cleaned.contains(":")) {
            val lower = cleaned.lowercase()
            if (lower == "::1" || lower == "::" || lower.startsWith("fc") ||
                lower.startsWith("fd") || lower.startsWith("fe80") ||
                lower.startsWith("::ffff:127.") || lower.startsWith("::ffff:10.") ||
                lower.startsWith("::ffff:192.168.") || lower.startsWith("::ffff:169.254.")
            ) {
                return true
            }
        }
        return false
    }

    fun canonicalizeUrl(rawUrl: String): String {
        return try {
            val uri = URI(rawUrl.trim())
            val scheme = (uri.scheme ?: "https").lowercase()
            val host = (uri.host ?: "").lowercase()
            val port = if ((scheme == "https" && uri.port == 443) || uri.port == -1) "" else ":${uri.port}"
            val path = (uri.rawPath ?: "").trimEnd('/').ifEmpty { "/" }
            val query = uri.rawQuery
                ?.split("&")
                ?.filter { pair ->
                    val key = pair.substringBefore("=").lowercase()
                    key.isNotBlank() && key !in trackingParams
                }
                ?.sorted()
                ?.joinToString("&")
                ?.takeIf { it.isNotBlank() }

            buildString {
                append(scheme).append("://").append(host).append(port).append(path)
                if (query != null) append("?").append(query)
            }
        } catch (_: Exception) {
            rawUrl.trim()
        }
    }

    fun redactUrlForLogs(url: String): String {
        return try {
            val uri = URI(url)
            val host = uri.host ?: "unknown-host"
            val path = uri.rawPath ?: "/"
            val suffix = if (uri.rawQuery != null) "?[REDACTED]" else ""
            "${uri.scheme ?: "https"}://$host$path$suffix"
        } catch (_: Exception) {
            "[INVALID_URL]"
        }
    }
}
