package com.example.data.model

import java.util.Locale
import kotlin.math.ceil

enum class NewsSection(val label: String) {
    FRONT_PAGE("Front Page"),
    BRITAIN("Britain"),
    WORLD("World"),
    BUSINESS("Business"),
    SCIENCE("Science"),
    CULTURE("Culture"),
    SPORT("Sport"),
    LOCAL("Local"),
}

enum class SidebarFeedMode(val label: String) {
    TOP_STORIES("Top stories"),
    LATEST_UPDATES("Latest updates"),
    SAVED_READING("Saved reading"),
    LOCAL_BRIEFING("Local briefing"),
    READING_HISTORY("Reading history"),
}

enum class ContentRightsMode(val label: String, val badge: String) {
    HEADLINE_AND_LINK("Headline & source link only", "Link only"),
    HEADLINE_AND_EXCERPT("Headline with permitted excerpt", "Excerpt only"),
    LICENSED_FULL_TEXT("Licensed full-text reading", "Full text"),
}

enum class ImagePermission {
    PERMITTED,
    RESTRICTED_OMIT,
}

enum class SourceAdapterType(val label: String) {
    LOCAL_FIXTURE("Local Fixture"),
    RSS("RSS 2.0"),
    ATOM("Atom 1.0"),
    LICENSED_API("Licensed API"),
    MANUAL_CURATION("Manual Curated"),
}

enum class SourceHealthStatus(val label: String) {
    HEALTHY("Healthy"),
    STALE("Stale"),
    DEGRADED("Degraded"),
    UNAVAILABLE("Unavailable"),
}

enum class ArticleStatus(val label: String) {
    PUBLISHED("Published"),
    UPDATED("Updated"),
    WITHDRAWN("Withdrawn"),
    UNAVAILABLE("Unavailable"),
}

enum class TextScaleOption(val label: String, val scale: Float) {
    COMPACT("Compact", 0.92f),
    STANDARD("Standard", 1.0f),
    LARGE("Large", 1.15f),
    EXTRA_LARGE("Extra Large", 1.30f);

    fun next(): TextScaleOption {
        val all = entries
        return all[(ordinal + 1) % all.size]
    }
}

enum class DateFilterOption(val label: String) {
    ALL("Any date"),
    TODAY("Last 24h"),
    LAST_7_DAYS("Last 7 days"),
}

object ReadingTimeCalculator {
    /**
     * Only estimate reading time when full licensed body text is available.
     * Never pretend to know the full article length when only headline/excerpt exists.
     */
    fun estimateMinutesOrNull(
        rightsMode: ContentRightsMode,
        fullText: String?,
    ): Int? {
        if (rightsMode != ContentRightsMode.LICENSED_FULL_TEXT) return null
        val text = fullText?.trim().orEmpty()
        if (text.isEmpty()) return null
        val wordCount = text.split(Regex("""\s+""")).count { it.isNotBlank() }
        if (wordCount < 40) return null
        return maxOf(1, ceil(wordCount / 210.0).toInt())
    }

    fun formatMetadataLine(
        publisherName: String,
        articleType: String,
        rightsMode: ContentRightsMode,
        fullText: String?,
    ): String {
        val mins = estimateMinutesOrNull(rightsMode, fullText)
        val lengthLabel = when {
            mins != null -> "$mins min read"
            rightsMode == ContentRightsMode.HEADLINE_AND_EXCERPT -> "Excerpt only"
            rightsMode == ContentRightsMode.HEADLINE_AND_LINK -> "Source link only"
            else -> "Licensed text"
        }
        return "$publisherName  •  $articleType  •  $lengthLabel"
    }
}

data class VenueConfig(
    val venueName: String = "DEMO NEWSROOM",
    val defaultCityOrRegion: String = "London",
    val kioskModeEnabled: Boolean = true,
    val inactivityTimeoutSeconds: Int = 180,
    val textScale: TextScaleOption = TextScaleOption.STANDARD,
    val aiSummaryAllowedGlobal: Boolean = true,
)

data class BriefingItem(
    val articleId: String,
    val title: String,
    val publisherName: String,
    val articleType: String,
    val excerpt: String,
    val canonicalUrl: String,
    val rightsMode: ContentRightsMode,
    val uncertaintyNote: String? = null,
)

sealed interface BriefingUiState {
    data object Idle : BriefingUiState
    data object Loading : BriefingUiState
    data class Streaming(val text: String, val citations: List<BriefingItem>) : BriefingUiState
    data class Success(
        val headline: String,
        val summaryText: String,
        val citations: List<BriefingItem>,
        val isAiGenerated: Boolean,
        val reviewedByEditor: Boolean,
        val generatedAtLabel: String,
    ) : BriefingUiState
    data class Error(val message: String) : BriefingUiState
}

fun formatTimeShort(epochMs: Long): String {
    val formatter = java.text.SimpleDateFormat("HH:mm", Locale.UK)
    return formatter.format(java.util.Date(epochMs))
}

fun formatDateTimeEdition(epochMs: Long): String {
    val formatter = java.text.SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.UK)
    return formatter.format(java.util.Date(epochMs))
}

fun formatEditionDayLabel(epochMs: Long): String {
    val formatter = java.text.SimpleDateFormat("EEEE 'EDITION'", Locale.UK)
    return formatter.format(java.util.Date(epochMs)).uppercase(Locale.UK)
}
