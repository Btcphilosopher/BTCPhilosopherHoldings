package com.example.data.ingestion

import com.example.data.local.ArticleEntity
import com.example.data.model.ContentRightsMode
import com.example.data.model.SourceHealthStatus
import com.example.data.model.VenueConfig
import kotlin.math.max

data class RankedScoreResult(
    val score: Double,
    val explanation: String,
)

object RankingEngine {
    /**
     * Explainable ranking based on configurable factors:
     * - Manual editorial lead override
     * - Editorial priority (0..100 -> up to +34)
     * - Recency decay (up to +26)
     * - Local relevance for venue city (+14)
     * - Source diversity & duplicate cluster suppression (-8 if repeated publisher/cluster)
     * - Stale source or link-only rights transparency adjustment
     */
    fun computeRanking(
        article: ArticleEntity,
        venueConfig: VenueConfig,
        feedHealthMap: Map<String, SourceHealthStatus>,
        seenPublishersCount: Int,
        nowMs: Long = System.currentTimeMillis(),
    ): RankedScoreResult {
        val parts = mutableListOf<String>()
        var score = 0.0

        if (article.manualLeadOverride) {
            score += 40.0
            parts += "Manual Lead (+40)"
        }

        val priorityPoints = (article.editorialPriority.coerceIn(0, 100) / 100.0) * 34.0
        score += priorityPoints
        parts += "Editorial Priority (+${"%.0f".format(priorityPoints)})"

        val ageHours = max(0.0, (nowMs - article.publishedAtMs) / 3_600_000.0)
        val recencyPoints = max(2.0, 26.0 - ageHours * 1.8)
        score += recencyPoints
        parts += "Recency (+${"%.1f".format(recencyPoints)})"

        val matchesVenueCity = article.region.equals(venueConfig.defaultCityOrRegion, ignoreCase = true)
        if (article.isLocallyRelevant && matchesVenueCity) {
            score += 14.0
            parts += "Local Relevance ${venueConfig.defaultCityOrRegion} (+14)"
        } else if (article.isLocallyRelevant) {
            score += 6.0
            parts += "Regional Relevance (+6)"
        }

        val diversityBonus = max(0.0, 14.0 - (seenPublishersCount * 4.5))
        score += diversityBonus
        parts += if (seenPublishersCount == 0) {
            "Source Diversity (+${"%.1f".format(diversityBonus)})"
        } else {
            "Duplicate/Source Spacing (+${"%.1f".format(diversityBonus)})"
        }

        val health = feedHealthMap[article.sourceFeedId] ?: SourceHealthStatus.HEALTHY
        if (health == SourceHealthStatus.STALE) {
            score -= 10.0
            parts += "Stale Source (-10)"
        } else if (health == SourceHealthStatus.UNAVAILABLE) {
            score -= 18.0
            parts += "Source Unavailable (-18)"
        }

        if (article.contentRightsMode == ContentRightsMode.HEADLINE_AND_LINK.name) {
            score -= 4.0
            parts += "Link-Only Rights (-4)"
        }

        return RankedScoreResult(
            score = kotlin.math.round(score * 10.0) / 10.0,
            explanation = parts.joinToString(" • "),
        )
    }

    fun rerankEdition(
        articles: List<ArticleEntity>,
        venueConfig: VenueConfig,
        feedHealthMap: Map<String, SourceHealthStatus>,
        nowMs: Long = System.currentTimeMillis(),
    ): List<ArticleEntity> {
        val publisherCounts = mutableMapOf<String, Int>()
        // Initial pass sorted by manual override, priority, recency to distribute diversity cleanly
        val preSorted = articles.sortedWith(
            compareByDescending<ArticleEntity> { it.manualLeadOverride }
                .thenByDescending { it.editorialPriority }
                .thenByDescending { it.publishedAtMs }
        )

        return preSorted.map { article ->
            val count = publisherCounts.getOrDefault(article.publisherId, 0)
            publisherCounts[article.publisherId] = count + 1
            val ranked = computeRanking(article, venueConfig, feedHealthMap, count, nowMs)
            article.copy(
                rankingScore = ranked.score,
                rankingExplanation = ranked.explanation,
            )
        }.sortedWith(
            compareByDescending<ArticleEntity> { it.manualLeadOverride }
                .thenByDescending { it.rankingScore }
        )
    }
}
