package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Merge
import androidx.compose.material.icons.automirrored.outlined.CallSplit
import androidx.compose.material.icons.outlined.Newspaper
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.ArticleEntity
import com.example.data.local.StoryClusterEntity
import com.example.data.model.BriefingUiState
import com.example.data.model.ContentRightsMode
import com.example.data.model.formatDateTimeEdition
import com.example.ui.components.NewspaperRule
import com.example.ui.components.SectionKickerHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmberNotice
import com.example.ui.theme.AmberTint
import com.example.ui.theme.CreamPaper
import com.example.ui.theme.DeepInk
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestGreenTint
import com.example.ui.theme.NewsprintInset
import com.example.ui.theme.NewsprintRule
import com.example.ui.theme.OxbloodRed
import com.example.ui.theme.OxbloodTint
import com.example.ui.theme.SlateInk

@Composable
fun BriefingScreen(
    briefingState: BriefingUiState,
    aiAllowedGlobal: Boolean,
    adminUnlocked: Boolean,
    onSelectEditorialMode: () -> Unit,
    onSelectAiMode: () -> Unit,
    onToggleReviewed: () -> Unit,
    onListenBriefing: (String, String) -> Unit,
    onOpenArticle: (String) -> Unit,
    onBack: () -> Unit,
) {
    BackHandler { onBack() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(modifier = Modifier.widthIn(max = 760.dp).fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                TextButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DeepInk)
                    Spacer(Modifier.width(6.dp))
                    Text("Back to edition", color = DeepInk)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onSelectEditorialMode,
                        border = BorderStroke(1.dp, ForestGreen),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("briefing_editorial_mode_button"),
                    ) {
                        Icon(Icons.Outlined.Newspaper, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Editorial Excerpts")
                    }
                    Button(
                        onClick = onSelectAiMode,
                        enabled = aiAllowedGlobal,
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen, contentColor = CreamPaper),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("briefing_ai_mode_button"),
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("AI Summary (Gemini)")
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            SectionKickerHeader(title = "FIVE-MINUTE BRIEFING", accentColor = OxbloodRed)
            Spacer(Modifier.height(10.dp))

            when (briefingState) {
                BriefingUiState.Idle, BriefingUiState.Loading -> {
                    Surface(
                        color = CreamPaper,
                        border = BorderStroke(1.dp, NewsprintRule),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier.padding(24.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp), color = ForestGreen, strokeWidth = 2.5.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = "Assembling briefing strictly from permitted source excerpts...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = DeepInk,
                            )
                        }
                    }
                }
                is BriefingUiState.Streaming -> {
                    StatusPill(
                        text = "AI-GENERATED SUMMARY (STREAMING FROM PERMITTED SOURCES)",
                        bgColor = AmberTint,
                        fgColor = AmberNotice,
                    )
                    Spacer(Modifier.height(10.dp))
                    Surface(
                        color = CreamPaper,
                        border = BorderStroke(1.dp, NewsprintRule),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            text = briefingState.text,
                            style = MaterialTheme.typography.bodyLarge,
                            color = DeepInk,
                            modifier = Modifier.padding(16.dp),
                        )
                    }
                }
                is BriefingUiState.Error -> {
                    Surface(
                        color = OxbloodTint,
                        border = BorderStroke(1.dp, OxbloodRed),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Briefing Notice", style = MaterialTheme.typography.titleMedium, color = OxbloodRed)
                            Spacer(Modifier.height(4.dp))
                            Text(briefingState.message, style = MaterialTheme.typography.bodyMedium, color = DeepInk)
                            Spacer(Modifier.height(10.dp))
                            OutlinedButton(onClick = onSelectEditorialMode, modifier = Modifier.minimumInteractiveComponentSize()) {
                                Text("Switch to Editorial Excerpts")
                            }
                        }
                    }
                }
                is BriefingUiState.Success -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (briefingState.isAiGenerated) {
                                StatusPill(
                                    text = "AI-GENERATED SUMMARY • GEMINI",
                                    bgColor = AmberTint,
                                    fgColor = AmberNotice,
                                )
                            } else {
                                StatusPill(
                                    text = "EDITORIAL SELECTION",
                                    bgColor = ForestGreenTint,
                                    fgColor = ForestGreen,
                                )
                            }
                            StatusPill(
                                text = if (briefingState.reviewedByEditor) "REVIEWED FOR TERMINAL" else "UNREVIEWED DRAFT",
                                bgColor = if (briefingState.reviewedByEditor) ForestGreenTint else NewsprintInset,
                                fgColor = if (briefingState.reviewedByEditor) ForestGreen else SlateInk,
                                icon = if (briefingState.reviewedByEditor) {
                                    { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ForestGreen, modifier = Modifier.size(13.dp)) }
                                } else null,
                            )
                        }
                        OutlinedButton(
                            onClick = { onListenBriefing(briefingState.headline, briefingState.summaryText) },
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp), tint = ForestGreen)
                            Spacer(Modifier.width(5.dp))
                            Text("Listen", color = ForestGreen)
                        }
                    }

                    if (adminUnlocked) {
                        TextButton(onClick = onToggleReviewed, modifier = Modifier.minimumInteractiveComponentSize()) {
                            Text(
                                text = if (briefingState.reviewedByEditor) "Mark as unreviewed draft" else "Approve briefing for shared terminals",
                                color = ForestGreen,
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Text(briefingState.headline, style = MaterialTheme.typography.displayMedium, color = DeepInk)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Assembled ${briefingState.generatedAtLabel} • Only sources whose permissions allow excerpts/summarization are included.",
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateInk,
                    )
                    Spacer(Modifier.height(14.dp))

                    Surface(
                        color = CreamPaper,
                        border = BorderStroke(1.dp, NewsprintRule),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            text = briefingState.summaryText,
                            style = MaterialTheme.typography.bodyLarge,
                            color = DeepInk,
                            modifier = Modifier.padding(18.dp),
                        )
                    }

                    Spacer(Modifier.height(18.dp))
                    SectionKickerHeader(title = "SOURCE CITATIONS & ORIGINAL LINKS", accentColor = DeepInk)
                    Spacer(Modifier.height(8.dp))
                    briefingState.citations.forEach { item ->
                        Surface(
                            color = CreamPaper,
                            border = BorderStroke(1.dp, NewsprintRule),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                                .clickable { onOpenArticle(item.articleId) },
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "${item.publisherName} • ${item.articleType}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = OxbloodRed,
                                )
                                Text(item.title, style = MaterialTheme.typography.titleLarge, color = DeepInk)
                                item.uncertaintyNote?.let { note ->
                                    Spacer(Modifier.height(3.dp))
                                    Text(note, style = MaterialTheme.typography.bodySmall, color = SlateInk)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CompareCoverageScreen(
    clusters: List<StoryClusterEntity>,
    articles: List<ArticleEntity>,
    focusedClusterId: String?,
    adminUnlocked: Boolean,
    onOpenArticle: (String) -> Unit,
    onMergeClusters: (String, String) -> Unit,
    onSplitArticle: (String, String) -> Unit,
    onBack: () -> Unit,
) {
    BackHandler { onBack() }
    var selectedMergeSource by remember { mutableStateOf<String?>(null) }

    val orderedClusters = remember(clusters, focusedClusterId) {
        if (focusedClusterId == null) clusters
        else clusters.sortedByDescending { it.id == focusedClusterId }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(modifier = Modifier.widthIn(max = 820.dp).fillMaxWidth()) {
            TextButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DeepInk)
                Spacer(Modifier.width(6.dp))
                Text("Back to edition", color = DeepInk)
            }
            Spacer(Modifier.height(6.dp))
            SectionKickerHeader(title = "COMPARE COVERAGE", accentColor = OxbloodRed)
            Spacer(Modifier.height(6.dp))
            Text(
                text = "One story, several perspectives",
                style = MaterialTheme.typography.displayMedium,
                color = DeepInk,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "Articles below are grouped because they appear to concern the same event or topic. Publication count does not establish factual truth, and clustering does not imply agreement.",
                style = MaterialTheme.typography.bodyMedium,
                color = SlateInk,
            )
            Spacer(Modifier.height(16.dp))

            orderedClusters.forEach { cluster ->
                val members = articles.filter { it.clusterId == cluster.id }
                if (members.isNotEmpty()) {
                    Surface(
                        color = CreamPaper,
                        border = BorderStroke(
                            1.dp,
                            if (cluster.id == focusedClusterId) ForestGreen else NewsprintRule
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 14.dp),
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(cluster.topicLabel, style = MaterialTheme.typography.headlineLarge, color = DeepInk)
                                    Text(cluster.contextNote, style = MaterialTheme.typography.bodySmall, color = SlateInk)
                                }
                                if (adminUnlocked) {
                                    if (selectedMergeSource == null) {
                                        TextButton(
                                            onClick = { selectedMergeSource = cluster.id },
                                            modifier = Modifier.minimumInteractiveComponentSize(),
                                        ) {
                                            Icon(Icons.Default.Merge, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Merge")
                                        }
                                    } else if (selectedMergeSource != cluster.id) {
                                        Button(
                                            onClick = {
                                                onMergeClusters(selectedMergeSource!!, cluster.id)
                                                selectedMergeSource = null
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                            modifier = Modifier.minimumInteractiveComponentSize(),
                                        ) {
                                            Text("Merge into this")
                                        }
                                    }
                                }
                            }

                            Spacer(Modifier.height(10.dp))
                            NewspaperRule()
                            members.forEachIndexed { idx, art ->
                                val rights = ContentRightsMode.entries.firstOrNull { it.name == art.contentRightsMode }
                                    ?: ContentRightsMode.HEADLINE_AND_LINK
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onOpenArticle(art.id) }
                                        .padding(vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        ) {
                                            Text(art.publisherName, style = MaterialTheme.typography.labelLarge, color = ForestGreen)
                                            Text("•  ${art.articleType}", style = MaterialTheme.typography.labelSmall, color = SlateInk)
                                            StatusPill(text = rights.badge, bgColor = NewsprintInset, fgColor = SlateInk)
                                        }
                                        Spacer(Modifier.height(3.dp))
                                        Text(art.title, style = MaterialTheme.typography.titleLarge, color = DeepInk)
                                        Text(
                                            text = "Published ${formatDateTimeEdition(art.publishedAtMs)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = SlateInk,
                                        )
                                    }
                                    if (adminUnlocked && members.size > 1) {
                                        TextButton(
                                            onClick = { onSplitArticle(art.id, art.title.take(55)) },
                                            modifier = Modifier.minimumInteractiveComponentSize(),
                                        ) {
                                            Icon(Icons.AutoMirrored.Outlined.CallSplit, contentDescription = "Split from cluster", modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Split")
                                        }
                                    }
                                }
                                if (idx < members.lastIndex) NewspaperRule(color = NewsprintRule.copy(alpha = 0.6f))
                            }
                        }
                    }
                }
            }
        }
    }
}
