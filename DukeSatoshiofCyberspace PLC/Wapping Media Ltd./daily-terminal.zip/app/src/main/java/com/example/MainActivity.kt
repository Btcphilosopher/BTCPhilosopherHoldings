package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.audio.AudioPlaybackStatus
import com.example.data.model.SourceHealthStatus
import com.example.security.configureAppCheck
import com.example.ui.components.AdminAuthDialog
import com.example.ui.components.AudioPlaybackBar
import com.example.ui.components.MastheadBanner
import com.example.ui.components.QrHandoffDialog
import com.example.ui.components.SectionNavBar
import com.example.ui.components.TopUtilityStrip
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.ArticleReaderScreen
import com.example.ui.screens.BriefingScreen
import com.example.ui.screens.CompareCoverageScreen
import com.example.ui.screens.FrontPageScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.theme.CreamPaper
import com.example.ui.theme.DailyTerminalTheme
import com.example.ui.theme.DeepInk
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestGreenTint
import com.example.ui.theme.NewsprintRule
import com.example.ui.theme.WarmIvory
import com.example.ui.viewmodel.DailyTerminalViewModel
import com.example.ui.viewmodel.TerminalRoute

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure Firebase App Check with launch intent before UI or ViewModel creation
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            val vm: DailyTerminalViewModel = viewModel()
            DailyTerminalApp(viewModel = vm)
        }
    }
}

@Composable
fun DailyTerminalApp(viewModel: DailyTerminalViewModel) {
    val venueConfig by viewModel.venueConfig.collectAsStateWithLifecycle()
    val route by viewModel.route.collectAsStateWithLifecycle()
    val selectedSection by viewModel.selectedSection.collectAsStateWithLifecycle()
    val selectedSidebarMode by viewModel.selectedSidebarMode.collectAsStateWithLifecycle()
    val orderedSections by viewModel.orderedSections.collectAsStateWithLifecycle()
    val activeArticles by viewModel.activeArticles.collectAsStateWithLifecycle()
    val allAdminArticles by viewModel.allAdminArticles.collectAsStateWithLifecycle()
    val feedSources by viewModel.feedSources.collectAsStateWithLifecycle()
    val clusters by viewModel.clusters.collectAsStateWithLifecycle()
    val savedIds by viewModel.savedArticleIds.collectAsStateWithLifecycle()
    val historyIds by viewModel.historyArticleIds.collectAsStateWithLifecycle()
    val audioState by viewModel.audioState.collectAsStateWithLifecycle()
    val lastRefreshMs by viewModel.lastRefreshMs.collectAsStateWithLifecycle()
    val isOffline by viewModel.isOffline.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()
    val inactivityRemaining by viewModel.inactivityRemainingSec.collectAsStateWithLifecycle()
    val newEditionBanner by viewModel.newEditionBanner.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    val qrHandoffArticle by viewModel.qrHandoffArticle.collectAsStateWithLifecycle()
    val activeSessionId by viewModel.activeSessionId.collectAsStateWithLifecycle()
    val searchFilters by viewModel.searchFilters.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val briefingState by viewModel.briefingState.collectAsStateWithLifecycle()
    val adminUnlocked by viewModel.adminUnlocked.collectAsStateWithLifecycle()
    val showAdminAuthDialog by viewModel.showAdminAuthDialog.collectAsStateWithLifecycle()
    val adminAuthError by viewModel.adminAuthError.collectAsStateWithLifecycle()
    val refreshJobs by viewModel.refreshJobs.collectAsStateWithLifecycle()
    val snapshots by viewModel.snapshots.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()

    val unavailableFeedCount = remember(feedSources) {
        feedSources.count { it.healthStatus == SourceHealthStatus.UNAVAILABLE.name }
    }
    val staleFeedCount = remember(feedSources) {
        feedSources.count { it.healthStatus == SourceHealthStatus.STALE.name }
    }

    DailyTerminalTheme(textScaleFactor = venueConfig.textScale.scale) {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(onPress = {
                        viewModel.registerUserInteraction()
                        tryAwaitRelease()
                    })
                },
            containerColor = WarmIvory,
            contentWindowInsets = WindowInsets.safeDrawing,
        ) { innerPadding ->
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .background(WarmIvory)
                    .padding(innerPadding),
            ) {
                val isCompact = maxWidth < 840.dp

                Column(modifier = Modifier.fillMaxSize()) {
                    TopUtilityStrip(
                        venueConfig = venueConfig,
                        lastRefreshMs = lastRefreshMs,
                        isOffline = isOffline,
                        unavailableFeedCount = unavailableFeedCount,
                        staleFeedCount = staleFeedCount,
                        inactivityRemainingSec = inactivityRemaining,
                        audioState = audioState,
                        isRefreshing = isRefreshing,
                        isCompact = isCompact,
                        onSearchClick = { viewModel.openSearch() },
                        onCycleTextScale = { viewModel.cycleTextScale() },
                        onAudioToggle = {
                            if (audioState.status is AudioPlaybackStatus.Playing) {
                                viewModel.audioController.stopImmediately()
                            } else {
                                activeArticles.firstOrNull()?.let { viewModel.audioController.playArticle(it) }
                            }
                        },
                        onRefreshClick = { viewModel.refreshEditionNow() },
                        onEndSessionClick = { viewModel.endSessionAndReset() },
                        onAdminClick = { viewModel.requestAdminAccess() },
                    )

                    // Masthead & Section bar on Front Page (preserving the exact broadsheet look)
                    if (route is TerminalRoute.FrontPage) {
                        MastheadBanner(isCompact = isCompact)
                        SectionNavBar(
                            sections = orderedSections,
                            selectedSection = selectedSection,
                            onSelectSection = { viewModel.selectSection(it) },
                        )
                    }

                    // Discreet "New edition available" pill (never abruptly replaces active reader view)
                    AnimatedVisibility(visible = newEditionBanner != null) {
                        newEditionBanner?.let { banner ->
                            Surface(
                                color = ForestGreenTint,
                                border = BorderStroke(1.dp, ForestGreen),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(banner, color = ForestGreen)
                                    Button(
                                        onClick = { viewModel.applyNewEditionBanner() },
                                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                        modifier = Modifier.minimumInteractiveComponentSize(),
                                    ) {
                                        Text("Load new edition")
                                    }
                                }
                            }
                        }
                    }

                    // Status notice banner
                    AnimatedVisibility(visible = statusBanner != null) {
                        statusBanner?.let { msg ->
                            Surface(
                                color = CreamPaper,
                                border = BorderStroke(1.dp, NewsprintRule),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        text = msg,
                                        color = DeepInk,
                                        modifier = Modifier.weight(1f),
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    TextButton(
                                        onClick = { viewModel.dismissStatusBanner() },
                                        modifier = Modifier.minimumInteractiveComponentSize(),
                                    ) {
                                        Text("Dismiss", color = ForestGreen)
                                    }
                                }
                            }
                        }
                    }

                    AudioPlaybackBar(
                        audioState = audioState,
                        onPause = { viewModel.audioController.pause() },
                        onResume = { viewModel.audioController.resume() },
                        onStop = { viewModel.audioController.stopImmediately() },
                        onChangeSpeed = { viewModel.audioController.setSpeed(it) },
                    )

                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        when (val current = route) {
                            TerminalRoute.FrontPage -> {
                                FrontPageScreen(
                                    articles = activeArticles,
                                    feedSources = feedSources,
                                    clusters = clusters,
                                    selectedSection = selectedSection,
                                    selectedSidebarMode = selectedSidebarMode,
                                    savedArticleIds = savedIds,
                                    historyArticleIds = historyIds,
                                    venueConfig = venueConfig,
                                    lastRefreshMs = lastRefreshMs,
                                    onSelectSidebarMode = { viewModel.selectSidebarMode(it) },
                                    onOpenArticle = { viewModel.openArticle(it) },
                                    onToggleSave = { viewModel.toggleSaveArticle(it) },
                                    onOpenBriefing = { viewModel.openBriefing(aiMode = false) },
                                    onOpenCompareCoverage = { viewModel.openCompareCoverage(it) },
                                    onAdminClick = { viewModel.requestAdminAccess() },
                                )
                            }
                            is TerminalRoute.Reader -> {
                                val articleFlow = remember(current.articleId) {
                                    viewModel.observeArticle(current.articleId)
                                }
                                val versionsFlow = remember(current.articleId) {
                                    viewModel.observeVersions(current.articleId)
                                }
                                val article by articleFlow.collectAsState(initial = activeArticles.firstOrNull { it.id == current.articleId })
                                val versions by versionsFlow.collectAsState(initial = emptyList())
                                val related = remember(activeArticles, article) {
                                    val cid = article?.clusterId
                                    if (cid == null) emptyList()
                                    else activeArticles.filter { it.clusterId == cid && it.id != article?.id }
                                }
                                ArticleReaderScreen(
                                    article = article,
                                    versions = versions,
                                    relatedArticles = related,
                                    isSaved = current.articleId in savedIds,
                                    onBack = { viewModel.navigateBackToFrontPage() },
                                    onCycleTextScale = { viewModel.cycleTextScale() },
                                    onToggleSave = { viewModel.toggleSaveArticle(it) },
                                    onListenClick = { viewModel.audioController.playArticle(it) },
                                    onQrHandoffClick = { viewModel.openQrHandoff(it) },
                                    onOpenRelatedArticle = { viewModel.openArticle(it) },
                                    onOpenCompareCoverage = { viewModel.openCompareCoverage(it) },
                                )
                            }
                            TerminalRoute.Briefing -> {
                                BriefingScreen(
                                    briefingState = briefingState,
                                    aiAllowedGlobal = venueConfig.aiSummaryAllowedGlobal,
                                    adminUnlocked = adminUnlocked,
                                    onSelectEditorialMode = { viewModel.loadEditorialBriefing() },
                                    onSelectAiMode = { viewModel.generateAiBriefing() },
                                    onToggleReviewed = { viewModel.toggleBriefingReviewed() },
                                    onListenBriefing = { t, b -> viewModel.audioController.playBriefing(t, b) },
                                    onOpenArticle = { viewModel.openArticle(it) },
                                    onBack = { viewModel.navigateBackToFrontPage() },
                                )
                            }
                            is TerminalRoute.CompareCoverage -> {
                                CompareCoverageScreen(
                                    clusters = clusters,
                                    articles = activeArticles,
                                    focusedClusterId = current.focusedClusterId,
                                    adminUnlocked = adminUnlocked,
                                    onOpenArticle = { viewModel.openArticle(it) },
                                    onMergeClusters = { src, dst -> viewModel.mergeClusters(src, dst) },
                                    onSplitArticle = { id, label -> viewModel.splitArticleFromCluster(id, label) },
                                    onBack = { viewModel.navigateBackToFrontPage() },
                                )
                            }
                            TerminalRoute.Search -> {
                                SearchScreen(
                                    filters = searchFilters,
                                    results = searchResults,
                                    allArticles = activeArticles,
                                    venueCity = venueConfig.defaultCityOrRegion,
                                    onUpdateFilters = { viewModel.updateSearchFilters(it) },
                                    onClearFilters = { viewModel.clearSearchFilters() },
                                    onOpenArticle = { viewModel.openArticle(it) },
                                    onBack = { viewModel.navigateBackToFrontPage() },
                                )
                            }
                            TerminalRoute.Admin -> {
                                if (!adminUnlocked) {
                                    viewModel.navigateBackToFrontPage()
                                } else {
                                    AdminScreen(
                                        feedSources = feedSources,
                                        articles = allAdminArticles,
                                        refreshJobs = refreshJobs,
                                        snapshots = snapshots,
                                        auditLogs = auditLogs,
                                        orderedSections = orderedSections,
                                        venueConfig = venueConfig,
                                        onImportFixture = { viewModel.importDemoFixtureFeed() },
                                        onRefreshAll = { viewModel.refreshEditionNow() },
                                        onAddFeed = { pub, fn, url, ad, sec, r, img, ai, aud, cb ->
                                            viewModel.addOrUpdateFeedSource(
                                                publisherName = pub,
                                                feedName = fn,
                                                endpointUrl = url,
                                                adapterType = ad,
                                                section = sec,
                                                language = "en",
                                                region = venueConfig.defaultCityOrRegion,
                                                rightsMode = r,
                                                imagePermission = img,
                                                allowCache = true,
                                                allowSearchIndex = true,
                                                allowAiSummary = ai,
                                                allowAudioTts = aud,
                                                onResult = cb,
                                            )
                                        },
                                        onAddManualEntry = { t, sf, b, p, s, r, cb ->
                                            viewModel.addManualEntry(
                                                title = t,
                                                standfirst = sf,
                                                bodyText = b,
                                                publisherName = p,
                                                author = "Newsroom Editor",
                                                section = s,
                                                articleType = "Curated",
                                                canonicalUrl = "",
                                                rightsMode = r,
                                                onResult = cb,
                                            )
                                        },
                                        onSetLeadOverride = { viewModel.setLeadStoryOverride(it) },
                                        onWithdrawOrRestore = { id, w -> viewModel.withdrawOrRestoreArticle(id, w) },
                                        onMoveSectionEarlier = { viewModel.moveSectionEarlier(it) },
                                        onCaptureSnapshot = { viewModel.captureEditionSnapshot(it) },
                                        onUpdateVenueConfig = { viewModel.updateVenueConfig(it) },
                                        onLockAndExit = { viewModel.lockAdminWorkspace() },
                                        onBack = { viewModel.navigateBackToFrontPage() },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        qrHandoffArticle?.let { article ->
            QrHandoffDialog(
                article = article,
                sessionId = activeSessionId,
                onDismiss = { viewModel.closeQrHandoff() },
            )
        }

        if (showAdminAuthDialog) {
            AdminAuthDialog(
                errorText = adminAuthError,
                onSubmitPin = { viewModel.submitAdminPin(it) },
                onDismiss = { viewModel.dismissAdminAuthDialog() },
            )
        }
    }
}
