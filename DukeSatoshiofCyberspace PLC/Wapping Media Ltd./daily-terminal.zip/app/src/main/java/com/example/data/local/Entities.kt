package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "publishers")
data class PublisherEntity(
    @PrimaryKey val id: String,
    val name: String,
    val domain: String,
    val attributionRequired: Boolean,
    val defaultLanguage: String,
    val isLocalOutlet: Boolean,
    val cityOrRegion: String,
)

@Entity(tableName = "feed_sources")
data class FeedSourceEntity(
    @PrimaryKey val id: String,
    val publisherId: String,
    val publisherName: String,
    val feedName: String,
    val endpointUrl: String,
    val adapterType: String, // SourceAdapterType.name
    val enabledSectionsCsv: String,
    val language: String,
    val region: String,
    val refreshIntervalMinutes: Int,
    val attributionRequirement: String,
    val contentRightsMode: String, // ContentRightsMode.name
    val imagePermission: String, // ImagePermission.name
    val allowCache: Boolean,
    val allowSearchIndex: Boolean,
    val allowAiSummary: Boolean,
    val allowAudioTts: Boolean,
    val healthStatus: String, // SourceHealthStatus.name
    val lastSuccessfulRefreshMs: Long,
    val lastAttemptMs: Long,
    val lastError: String?,
    val etag: String?,
    val lastModifiedHeader: String?,
    val isActive: Boolean = true,
)

@Entity(
    tableName = "articles",
    indices = [
        Index(value = ["canonicalUrl"]),
        Index(value = ["sourceGuid"]),
        Index(value = ["contentFingerprint"]),
        Index(value = ["clusterId"]),
        Index(value = ["section"]),
    ]
)
data class ArticleEntity(
    @PrimaryKey val id: String,
    val sourceFeedId: String,
    val publisherId: String,
    val publisherName: String,
    val canonicalUrl: String,
    val sourceGuid: String,
    val contentFingerprint: String,
    val title: String,
    val standfirst: String,
    val excerpt: String,
    val fullText: String?,
    val author: String?,
    val articleType: String,
    val section: String, // NewsSection.name
    val language: String,
    val region: String,
    val isLocallyRelevant: Boolean,
    val isLocalOutlet: Boolean,
    val publishedAtMs: Long,
    val modifiedAtMs: Long?,
    val ingestedAtMs: Long,
    val retrievedAtMs: Long,
    val contentRightsMode: String, // ContentRightsMode.name
    val imagePermission: String, // ImagePermission.name
    val localDrawableName: String?,
    val remoteImageUrl: String?,
    val imageAttribution: String?,
    val allowCache: Boolean,
    val allowSearchIndex: Boolean,
    val allowAiSummary: Boolean,
    val allowAudioTts: Boolean,
    val status: String, // ArticleStatus.name
    val clusterId: String?,
    val editorialPriority: Int, // 0..100
    val manualLeadOverride: Boolean,
    val rankingScore: Double,
    val rankingExplanation: String,
    val slotRole: String = "STANDARD", // LEAD, SECONDARY, EXPLORE, STANDARD
)

@Entity(
    tableName = "article_versions",
    indices = [Index(value = ["articleId"])]
)
data class ArticleVersionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val articleId: String,
    val versionNumber: Int,
    val title: String,
    val standfirst: String,
    val contentHash: String,
    val recordedAtMs: Long,
    val changeNote: String,
)

@Entity(tableName = "story_clusters")
data class StoryClusterEntity(
    @PrimaryKey val id: String,
    val topicLabel: String,
    val contextNote: String,
    val updatedAtMs: Long,
)

@Entity(tableName = "editorial_placements")
data class EditorialPlacementEntity(
    @PrimaryKey val id: String,
    val section: String,
    val leadArticleId: String?,
    val sectionOrderCsv: String,
    val placedBy: String,
    val placedAtMs: Long,
)

@Entity(tableName = "edition_snapshots")
data class EditionSnapshotEntity(
    @PrimaryKey val id: String,
    val editionLabel: String,
    val venueName: String,
    val cityOrRegion: String,
    val builtAtMs: Long,
    val leadArticleId: String,
    val rankedArticleIdsCsv: String,
    val sectionOrderCsv: String,
    val notes: String,
)

@Entity(tableName = "refresh_jobs")
data class RefreshJobEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val feedId: String,
    val feedName: String,
    val startedAtMs: Long,
    val finishedAtMs: Long,
    val status: String, // SUCCESS, NOT_MODIFIED, FAILED
    val itemsFetched: Int,
    val itemsDeduplicated: Int,
    val itemsUpdated: Int,
    val errorMessage: String?,
)

@Entity(tableName = "saved_items")
data class SavedItemEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val articleId: String,
    val savedAtMs: Long,
)

@Entity(tableName = "reading_history")
data class ReadingHistoryEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val articleId: String,
    val openedAtMs: Long,
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val actorRole: String,
    val actionType: String,
    val targetId: String,
    val summary: String,
    val createdAtMs: Long,
)
