package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.TextScaleOption
import com.example.data.model.VenueConfig
import com.example.security.HtmlSanitizer
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

private val Context.venueDataStore: DataStore<Preferences> by preferencesDataStore(name = "daily_terminal_prefs")

class VenuePreferencesStore(
    private val context: Context,
    private val dataStore: DataStore<Preferences> = context.venueDataStore,
) {
    private object Keys {
        val VENUE_NAME = stringPreferencesKey("venue_name")
        val CITY_REGION = stringPreferencesKey("city_region")
        val KIOSK_MODE = booleanPreferencesKey("kiosk_mode")
        val INACTIVITY_TIMEOUT_SEC = intPreferencesKey("inactivity_timeout_sec")
        val TEXT_SCALE = stringPreferencesKey("text_scale")
        val AI_SUMMARY_ALLOWED = booleanPreferencesKey("ai_summary_allowed")
        val SESSION_ID = stringPreferencesKey("active_session_id")
        val ADMIN_PIN_HASH = stringPreferencesKey("admin_pin_hash")
        val LAST_EDITION_REFRESH_MS = longPreferencesKey("last_edition_refresh_ms")
    }

    companion object {
        // Default demo newsroom PIN: "2468" (stored salted/hashed)
        private const val SALT = "dt_newsroom_v1_"
        val DEFAULT_PIN_HASH = HtmlSanitizer.computeSha256Hex("${SALT}2468")
    }

    val venueConfigFlow: Flow<VenueConfig> = dataStore.data.map { prefs ->
        val scaleName = prefs[Keys.TEXT_SCALE] ?: TextScaleOption.STANDARD.name
        val scale = TextScaleOption.entries.firstOrNull { it.name == scaleName } ?: TextScaleOption.STANDARD
        VenueConfig(
            venueName = prefs[Keys.VENUE_NAME] ?: "DEMO NEWSROOM",
            defaultCityOrRegion = prefs[Keys.CITY_REGION] ?: "London",
            kioskModeEnabled = prefs[Keys.KIOSK_MODE] ?: true,
            inactivityTimeoutSeconds = prefs[Keys.INACTIVITY_TIMEOUT_SEC] ?: 180,
            textScale = scale,
            aiSummaryAllowedGlobal = prefs[Keys.AI_SUMMARY_ALLOWED] ?: true,
        )
    }

    val activeSessionIdFlow: Flow<String> = dataStore.data.map { prefs ->
        prefs[Keys.SESSION_ID] ?: "kiosk_session_initial"
    }

    val lastEditionRefreshMsFlow: Flow<Long> = dataStore.data.map { prefs ->
        prefs[Keys.LAST_EDITION_REFRESH_MS] ?: System.currentTimeMillis()
    }

    suspend fun ensureInitializedSession(): String {
        val current = dataStore.data.first()[Keys.SESSION_ID]
        if (!current.isNullOrBlank()) return current
        val created = "session_${UUID.randomUUID().toString().take(8)}"
        dataStore.edit { prefs ->
            prefs[Keys.SESSION_ID] = created
            if (prefs[Keys.ADMIN_PIN_HASH] == null) {
                prefs[Keys.ADMIN_PIN_HASH] = DEFAULT_PIN_HASH
            }
            if (prefs[Keys.LAST_EDITION_REFRESH_MS] == null) {
                prefs[Keys.LAST_EDITION_REFRESH_MS] = System.currentTimeMillis()
            }
        }
        return created
    }

    suspend fun rotateSessionId(): String {
        val next = "session_${UUID.randomUUID().toString().take(8)}"
        dataStore.edit { prefs ->
            prefs[Keys.SESSION_ID] = next
        }
        return next
    }

    suspend fun updateVenueConfig(config: VenueConfig) {
        dataStore.edit { prefs ->
            prefs[Keys.VENUE_NAME] = config.venueName.trim().ifEmpty { "DEMO NEWSROOM" }
            prefs[Keys.CITY_REGION] = config.defaultCityOrRegion.trim().ifEmpty { "London" }
            prefs[Keys.KIOSK_MODE] = config.kioskModeEnabled
            prefs[Keys.INACTIVITY_TIMEOUT_SEC] = config.inactivityTimeoutSeconds.coerceIn(30, 1800)
            prefs[Keys.TEXT_SCALE] = config.textScale.name
            prefs[Keys.AI_SUMMARY_ALLOWED] = config.aiSummaryAllowedGlobal
        }
    }

    suspend fun cycleTextScale(): TextScaleOption {
        var nextScale = TextScaleOption.STANDARD
        dataStore.edit { prefs ->
            val currentName = prefs[Keys.TEXT_SCALE] ?: TextScaleOption.STANDARD.name
            val current = TextScaleOption.entries.firstOrNull { it.name == currentName } ?: TextScaleOption.STANDARD
            nextScale = current.next()
            prefs[Keys.TEXT_SCALE] = nextScale.name
        }
        return nextScale
    }

    suspend fun updateLastRefreshMs(epochMs: Long) {
        dataStore.edit { prefs ->
            prefs[Keys.LAST_EDITION_REFRESH_MS] = epochMs
        }
    }

    suspend fun verifyAdminPin(pin: String): Boolean {
        val storedHash = dataStore.data.first()[Keys.ADMIN_PIN_HASH] ?: DEFAULT_PIN_HASH
        val candidateHash = HtmlSanitizer.computeSha256Hex("$SALT${pin.trim()}")
        return candidateHash == storedHash
    }
}
