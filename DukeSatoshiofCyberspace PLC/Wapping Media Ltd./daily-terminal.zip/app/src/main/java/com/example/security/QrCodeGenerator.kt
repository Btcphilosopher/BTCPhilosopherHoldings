package com.example.security

import android.graphics.Bitmap
import android.graphics.Color

/**
 * Pure-Kotlin ISO/IEC 18004 QR Code encoder (Byte mode, Error Correction Level M, Versions 1..5).
 * Produces standard scannable QR matrices for personal-device handoff links without external deps.
 */
object QrCodeGenerator {

    private data class VersionSpec(
        val version: Int,
        val size: Int,
        val dataCodewords: Int,
        val ecCodewordsPerBlock: Int,
        val numBlocks: Int,
        val alignmentCenter: Int? // single non-6 center if present
    )

    // ISO 18004 Level M capacities for Versions 1..5
    private val versions = listOf(
        VersionSpec(1, 21, 16, 10, 1, null),
        VersionSpec(2, 25, 28, 16, 1, 18),
        VersionSpec(3, 29, 44, 26, 1, 22),
        VersionSpec(4, 33, 64, 18, 2, 26),
        VersionSpec(5, 37, 86, 24, 2, 30),
    )

    private val gfExp = IntArray(512)
    private val gfLog = IntArray(256)

    init {
        var x = 1
        for (i in 0 until 255) {
            gfExp[i] = x
            gfLog[x] = i
            x = x shl 1
            if ((x and 0x100) != 0) {
                x = x xor 0x11D
            }
        }
        for (i in 255 until 512) {
            gfExp[i] = gfExp[i - 255]
        }
    }

    fun encodeToMatrix(content: String): Array<BooleanArray> {
        val bytes = content.toByteArray(Charsets.UTF_8)
        val spec = versions.firstOrNull { bytes.size + 2 <= it.dataCodewords }
            ?: versions.last()
        val maxPayload = spec.dataCodewords - 2
        val payload = if (bytes.size > maxPayload) bytes.copyOf(maxPayload) else bytes

        val bits = ArrayList<Int>(spec.dataCodewords * 8)
        // Mode indicator: Byte = 0100
        appendBits(bits, 0b0100, 4)
        // Character count indicator (8 bits for versions 1..9)
        appendBits(bits, payload.size, 8)
        for (b in payload) {
            appendBits(bits, b.toInt() and 0xFF, 8)
        }
        val totalDataBits = spec.dataCodewords * 8
        val terminatorLen = minOf(4, totalDataBits - bits.size)
        appendBits(bits, 0, terminatorLen)
        while (bits.size % 8 != 0) bits.add(0)

        val dataBytes = IntArray(spec.dataCodewords)
        var idx = 0
        while (idx < bits.size / 8) {
            var v = 0
            for (bit in 0 until 8) {
                v = (v shl 1) or bits[idx * 8 + bit]
            }
            dataBytes[idx] = v
            idx++
        }
        val padBytes = intArrayOf(0xEC, 0x11)
        var padIdx = 0
        while (idx < spec.dataCodewords) {
            dataBytes[idx++] = padBytes[padIdx % 2]
            padIdx++
        }

        // Split into blocks, compute Reed-Solomon EC codewords, and interleave
        val blockSize = spec.dataCodewords / spec.numBlocks
        val dataBlocks = Array(spec.numBlocks) { b ->
            dataBytes.copyOfRange(b * blockSize, (b + 1) * blockSize)
        }
        val ecBlocks = Array(spec.numBlocks) { b ->
            computeReedSolomon(dataBlocks[b], spec.ecCodewordsPerBlock)
        }

        val finalStream = ArrayList<Int>(spec.dataCodewords + spec.numBlocks * spec.ecCodewordsPerBlock)
        for (i in 0 until blockSize) {
            for (b in 0 until spec.numBlocks) finalStream.add(dataBlocks[b][i])
        }
        for (i in 0 until spec.ecCodewordsPerBlock) {
            for (b in 0 until spec.numBlocks) finalStream.add(ecBlocks[b][i])
        }

        val size = spec.size
        val modules = Array(size) { BooleanArray(size) }
        val isFunction = Array(size) { BooleanArray(size) }

        placeFinderPattern(modules, isFunction, 0, 0)
        placeFinderPattern(modules, isFunction, size - 7, 0)
        placeFinderPattern(modules, isFunction, 0, size - 7)
        placeSeparators(isFunction, size)
        placeTimingPatterns(modules, isFunction, size)
        spec.alignmentCenter?.let { center ->
            placeAlignmentPattern(modules, isFunction, center, center)
        }
        // Dark module
        modules[size - 8][8] = true
        isFunction[size - 8][8] = true
        // Reserve format info cells
        reserveFormatInfo(isFunction, size)

        // Place data bits in zigzag
        val streamBits = IntArray(finalStream.size * 8)
        for (i in finalStream.indices) {
            val byteVal = finalStream[i]
            for (bit in 0 until 8) {
                streamBits[i * 8 + bit] = (byteVal ushr (7 - bit)) and 1
            }
        }
        placeDataBits(modules, isFunction, streamBits, size)

        // Evaluate mask patterns 0..7 and pick lowest penalty
        var bestMask = 0
        var bestPenalty = Int.MAX_VALUE
        for (mask in 0..7) {
            val candidate = Array(size) { r -> modules[r].clone() }
            applyMask(candidate, isFunction, mask, size)
            placeFormatInfo(candidate, mask, size)
            val penalty = computePenalty(candidate, size)
            if (penalty < bestPenalty) {
                bestPenalty = penalty
                bestMask = mask
            }
        }

        applyMask(modules, isFunction, bestMask, size)
        placeFormatInfo(modules, bestMask, size)
        return modules
    }

    fun renderBitmap(
        content: String,
        pixelSize: Int = 360,
        darkColor: Int = Color.parseColor("#11181C"),
        lightColor: Int = Color.parseColor("#FAF6EE")
    ): Bitmap {
        val matrix = encodeToMatrix(content)
        val n = matrix.size
        val quietZone = 2
        val total = n + quietZone * 2
        val scale = maxOf(1, pixelSize / total)
        val bmpSize = total * scale
        val bitmap = Bitmap.createBitmap(bmpSize, bmpSize, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(bmpSize * bmpSize) { lightColor }
        for (r in 0 until n) {
            for (c in 0 until n) {
                if (matrix[r][c]) {
                    val startY = (r + quietZone) * scale
                    val startX = (c + quietZone) * scale
                    for (dy in 0 until scale) {
                        val rowOffset = (startY + dy) * bmpSize + startX
                        for (dx in 0 until scale) {
                            pixels[rowOffset + dx] = darkColor
                        }
                    }
                }
            }
        }
        bitmap.setPixels(pixels, 0, bmpSize, 0, 0, bmpSize, bmpSize)
        return bitmap
    }

    private fun appendBits(list: MutableList<Int>, value: Int, bitCount: Int) {
        for (i in bitCount - 1 downTo 0) {
            list.add((value ushr i) and 1)
        }
    }

    private fun gfMul(a: Int, b: Int): Int {
        if (a == 0 || b == 0) return 0
        return gfExp[gfLog[a] + gfLog[b]]
    }

    private fun computeReedSolomon(data: IntArray, ecCount: Int): IntArray {
        var gen = intArrayOf(1)
        for (i in 0 until ecCount) {
            val next = IntArray(gen.size + 1)
            val factor = gfExp[i]
            for (j in gen.indices) {
                next[j] = next[j] xor gen[j]
                next[j + 1] = next[j + 1] xor gfMul(gen[j], factor)
            }
            gen = next
        }
        val rem = IntArray(ecCount)
        for (b in data) {
            val factor = b xor rem[0]
            System.arraycopy(rem, 1, rem, 0, ecCount - 1)
            rem[ecCount - 1] = 0
            for (i in 0 until ecCount) {
                rem[i] = rem[i] xor gfMul(gen[i + 1], factor)
            }
        }
        return rem
    }

    private fun placeFinderPattern(
        modules: Array<BooleanArray>,
        isFunc: Array<BooleanArray>,
        top: Int,
        left: Int
    ) {
        for (r in 0 until 7) {
            for (c in 0 until 7) {
                val dark = r == 0 || r == 6 || c == 0 || c == 6 || (r in 2..4 && c in 2..4)
                modules[top + r][left + c] = dark
                isFunc[top + r][left + c] = true
            }
        }
    }

    private fun placeSeparators(isFunc: Array<BooleanArray>, size: Int) {
        for (i in 0 until 8) {
            isFunc[7][i] = true
            isFunc[i][7] = true
            isFunc[7][size - 1 - i] = true
            isFunc[i][size - 8] = true
            isFunc[size - 8][i] = true
            isFunc[size - 1 - i][7] = true
        }
    }

    private fun placeTimingPatterns(
        modules: Array<BooleanArray>,
        isFunc: Array<BooleanArray>,
        size: Int
    ) {
        for (i in 8 until size - 8) {
            val dark = i % 2 == 0
            modules[6][i] = dark
            isFunc[6][i] = true
            modules[i][6] = dark
            isFunc[i][6] = true
        }
    }

    private fun placeAlignmentPattern(
        modules: Array<BooleanArray>,
        isFunc: Array<BooleanArray>,
        centerR: Int,
        centerC: Int
    ) {
        for (dr in -2..2) {
            for (dc in -2..2) {
                val dark = kotlin.math.max(kotlin.math.abs(dr), kotlin.math.abs(dc)) != 1
                modules[centerR + dr][centerC + dc] = dark
                isFunc[centerR + dr][centerC + dc] = true
            }
        }
    }

    private fun reserveFormatInfo(isFunc: Array<BooleanArray>, size: Int) {
        for (i in 0..8) {
            if (i != 6) {
                isFunc[8][i] = true
                isFunc[i][8] = true
            }
        }
        for (i in size - 8 until size) {
            isFunc[8][i] = true
            isFunc[i][8] = true
        }
    }

    private fun placeDataBits(
        modules: Array<BooleanArray>,
        isFunc: Array<BooleanArray>,
        bits: IntArray,
        size: Int
    ) {
        var bitIdx = 0
        var upward = true
        var col = size - 1
        while (col > 0) {
            if (col == 6) col--
            val rows = if (upward) (size - 1 downTo 0) else (0 until size)
            for (r in rows) {
                for (dx in 0..1) {
                    val c = col - dx
                    if (!isFunc[r][c]) {
                        modules[r][c] = if (bitIdx < bits.size) bits[bitIdx] == 1 else false
                        bitIdx++
                    }
                }
            }
            upward = !upward
            col -= 2
        }
    }

    private fun applyMask(
        modules: Array<BooleanArray>,
        isFunc: Array<BooleanArray>,
        mask: Int,
        size: Int
    ) {
        for (r in 0 until size) {
            for (c in 0 until size) {
                if (!isFunc[r][c]) {
                    val invert = when (mask) {
                        0 -> (r + c) % 2 == 0
                        1 -> r % 2 == 0
                        2 -> c % 3 == 0
                        3 -> (r + c) % 3 == 0
                        4 -> (r / 2 + c / 3) % 2 == 0
                        5 -> (r * c) % 2 + (r * c) % 3 == 0
                        6 -> ((r * c) % 2 + (r * c) % 3) % 2 == 0
                        7 -> ((r + c) % 2 + (r * c) % 3) % 2 == 0
                        else -> false
                    }
                    if (invert) modules[r][c] = !modules[r][c]
                }
            }
        }
    }

    private fun placeFormatInfo(modules: Array<BooleanArray>, mask: Int, size: Int) {
        // Error correction level M = 00
        val data = (0b00 shl 3) or mask
        var rem = data shl 10
        val poly = 0b10100110111
        for (i in 4 downTo 0) {
            if ((rem ushr (i + 10)) != 0) {
                rem = rem xor (poly shl i)
            }
        }
        val formatBits = ((data shl 10) or rem) xor 0b101010000010010
        for (i in 0..5) {
            val bit = ((formatBits ushr i) and 1) == 1
            modules[8][i] = bit
            modules[size - 1 - i][8] = bit
        }
        modules[8][7] = ((formatBits ushr 6) and 1) == 1
        modules[size - 7][8] = ((formatBits ushr 6) and 1) == 1
        modules[8][8] = ((formatBits ushr 7) and 1) == 1
        modules[8][size - 8] = ((formatBits ushr 7) and 1) == 1
        modules[7][8] = ((formatBits ushr 8) and 1) == 1
        modules[8][size - 7] = ((formatBits ushr 8) and 1) == 1
        for (i in 9..14) {
            val bit = ((formatBits ushr i) and 1) == 1
            modules[14 - i][8] = bit
            modules[8][size - 15 + i] = bit
        }
    }

    private fun computePenalty(modules: Array<BooleanArray>, size: Int): Int {
        var penalty = 0
        for (r in 0 until size) {
            var runColor = modules[r][0]
            var runLen = 1
            for (c in 1 until size) {
                if (modules[r][c] == runColor) {
                    runLen++
                } else {
                    if (runLen >= 5) penalty += 3 + (runLen - 5)
                    runColor = modules[r][c]
                    runLen = 1
                }
            }
            if (runLen >= 5) penalty += 3 + (runLen - 5)
        }
        for (c in 0 until size) {
            var runColor = modules[0][c]
            var runLen = 1
            for (r in 1 until size) {
                if (modules[r][c] == runColor) {
                    runLen++
                } else {
                    if (runLen >= 5) penalty += 3 + (runLen - 5)
                    runColor = modules[r][c]
                    runLen = 1
                }
            }
            if (runLen >= 5) penalty += 3 + (runLen - 5)
        }
        return penalty
    }
}
