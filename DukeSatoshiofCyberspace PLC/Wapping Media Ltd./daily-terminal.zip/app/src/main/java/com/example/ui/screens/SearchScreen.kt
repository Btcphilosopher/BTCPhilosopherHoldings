package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.ArticleEntity
import com.example.data.model.ContentRightsMode
import com.example.data.model.DateFilterOption
import com.example.data.model.NewsSection
import com.example.data.model.ReadingTimeCalculator
import com.example.data.model.formatDateTimeEdition
import com.example.ui.components.SectionKickerHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.CreamPaper
import com.example.ui.theme.DeepInk
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestGreenTint
import com.example.ui.theme.NewsprintInset
import com.example.ui.theme.NewsprintRule
import com.example.ui.theme.SlateInk
import com.example.ui.viewmodel.SearchFilterState

@Composable
fun SearchScreen(
    filters: SearchFilterState,
    results: List<ArticleEntity>,
    allArticles: List<ArticleEntity>,
    venueCity: String,
    onUpdateFilters: ((SearchFilterState) -> SearchFilterState) -> Unit,
    onClearFilters: () -> Unit,
    onOpenArticle: (String) -> Unit,
    onBack: () -> Unit,
) {
    BackHandler { onBack() }

    val publishers = remember(allArticles) {
        allArticles.map { it.publisherName }.distinct().sorted()
    }
    val articleTypes = remember(allArticles) {
        allArticles.map { it.articleType }.distinct().sorted()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(modifier = Modifier.widthIn(max = 820.dp).fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DeepInk)
                    Spacer(Modifier.width(6.dp))
                    Text("Back to edition", color = DeepInk)
                }
                TextButton(onClick = onClearFilters, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Text("Reset filters", color = ForestGreen)
                }
            }

            SectionKickerHeader(title = "ARCHIVE & EDITION SEARCH", accentColor = ForestGreen)
            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = filters.query,
                onValueChange = { q -> onUpdateFilters { it.copy(query = q) } },
                label = { Text("Search permitted indexed articles (e.g. railways, wind, library)") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (filters.query.isNotEmpty()) {
                        IconButton(onClick = { onUpdateFilters { it.copy(query = "") } }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_query_input"),
            )

            Spacer(Modifier.height(10.dp))
            // Section filter chips
            Text("Section", style = MaterialTheme.typography.labelSmall, color = SlateInk)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(
                    selected = filters.section == null,
                    onClick = { onUpdateFilters { it.copy(section = null) } },
                    label = { Text("All Sections") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ForestGreen,
                        selectedLabelColor = CreamPaper,
                    ),
                )
                NewsSection.entries.filter { it != NewsSection.FRONT_PAGE }.forEach { sec ->
                    FilterChip(
                        selected = filters.section == sec,
                        onClick = {
                            onUpdateFilters { cur -> cur.copy(section = if (cur.section == sec) null else sec) }
                        },
                        label = { Text(sec.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ForestGreen,
                            selectedLabelColor = CreamPaper,
                        ),
                    )
                }
            }

            // Publisher & Date filter chips
            Text("Publisher & Date", style = MaterialTheme.typography.labelSmall, color = SlateInk)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                DateFilterOption.entries.forEach { d ->
                    FilterChip(
                        selected = filters.dateFilter == d,
                        onClick = { onUpdateFilters { it.copy(dateFilter = d) } },
                        label = { Text(d.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ForestGreen,
                            selectedLabelColor = CreamPaper,
                        ),
                    )
                }
                publishers.forEach { pub ->
                    FilterChip(
                        selected = filters.publisher == pub,
                        onClick = {
                            onUpdateFilters { cur -> cur.copy(publisher = if (cur.publisher == pub) null else pub) }
                        },
                        label = { Text(pub) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ForestGreen,
                            selectedLabelColor = CreamPaper,
                        ),
                    )
                }
            }

            // Article Type & Language
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(
                    selected = filters.language == "en",
                    onClick = {
                        onUpdateFilters { cur -> cur.copy(language = if (cur.language == "en") null else "en") }
                    },
                    label = { Text("English (EN)") },
                )
                articleTypes.forEach { t ->
                    FilterChip(
                        selected = filters.articleType == t,
                        onClick = {
                            onUpdateFilters { cur -> cur.copy(articleType = if (cur.articleType == t) null else t) }
                        },
                        label = { Text(t) },
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Text(
                text = "${results.size} matching ${if (results.size == 1) "article" else "articles"}",
                style = MaterialTheme.typography.labelMedium,
                color = SlateInk,
            )
            Spacer(Modifier.height(8.dp))

            if (results.isEmpty()) {
                Surface(
                    color = CreamPaper,
                    border = BorderStroke(1.dp, NewsprintRule),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text("No matching stories found", style = MaterialTheme.typography.headlineMedium, color = DeepInk)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Try broadening your query or clearing section/publisher filters. Only stories whose licensing permits search indexing are shown.",
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateInk,
                        )
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(onClick = onClearFilters, modifier = Modifier.minimumInteractiveComponentSize()) {
                            Text("Clear all filters")
                        }
                    }
                }
            } else {
                results.forEach { art ->
                    val rights = ContentRightsMode.entries.firstOrNull { it.name == art.contentRightsMode }
                        ?: ContentRightsMode.HEADLINE_AND_LINK
                    Surface(
                        color = CreamPaper,
                        border = BorderStroke(1.dp, NewsprintRule),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .clickable { onOpenArticle(art.id) }
                            .testTag("search_result_${art.id}"),
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = ReadingTimeCalculator.formatMetadataLine(
                                        art.publisherName,
                                        art.articleType,
                                        rights,
                                        art.fullText,
                                    ),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ForestGreen,
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (art.isLocalOutlet) {
                                        StatusPill("LOCAL OUTLET", ForestGreenTint, ForestGreen)
                                    } else if (art.isLocallyRelevant) {
                                        StatusPill("LOCAL RELEVANCE (${venueCity.uppercase()})", NewsprintInset, DeepInk)
                                    }
                                    StatusPill(rights.badge, NewsprintInset, SlateInk)
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(art.title, style = MaterialTheme.typography.headlineLarge, color = DeepInk)
                            Spacer(Modifier.height(4.dp))
                            Text(art.standfirst, style = MaterialTheme.typography.bodyMedium, color = SlateInk)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Published ${formatDateTimeEdition(art.publishedAtMs)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = SlateInk,
                            )
                        }
                    }
                }
            }
        }
    }
}
