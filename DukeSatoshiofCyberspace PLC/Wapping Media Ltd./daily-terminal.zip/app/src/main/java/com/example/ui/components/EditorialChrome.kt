package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.PowerSettingsNew
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.audio.AudioControllerState
import com.example.data.audio.AudioPlaybackStatus
import com.example.data.local.ArticleEntity
import com.example.data.model.ImagePermission
import com.example.data.model.NewsSection
import com.example.data.model.TextScaleOption
import com.example.data.model.VenueConfig
import com.example.data.model.formatEditionDayLabel
import com.example.data.model.formatTimeShort
import com.example.security.QrCodeGenerator
import com.example.ui.theme.AmberNotice
import com.example.ui.theme.AmberTint
import com.example.ui.theme.CreamPaper
import com.example.ui.theme.DeepInk
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.NewsprintInset
import com.example.ui.theme.NewsprintRule
import com.example.ui.theme.OxbloodRed
import com.example.ui.theme.OxbloodTint
import com.example.ui.theme.SlateInk
import com.example.ui.theme.StrongRule
import com.example.ui.theme.WarmIvory

@Composable
fun NewspaperRule(
    modifier: Modifier = Modifier,
    color: Color = NewsprintRule,
    thickness: androidx.compose.ui.unit.Dp = 1.dp,
) {
    HorizontalDivider(modifier = modifier, thickness = thickness, color = color)
}

@Composable
fun SectionKickerHeader(
    title: String,
    accentColor: Color = OxbloodRed,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelMedium,
            color = accentColor,
            modifier = Modifier.semantics { heading() },
        )
        Spacer(Modifier.width(10.dp))
        NewspaperRule(modifier = Modifier.weight(1f), color = NewsprintRule)
    }
}

@Composable
fun TopUtilityStrip(
    venueConfig: VenueConfig,
    lastRefreshMs: Long,
    isOffline: Boolean,
    unavailableFeedCount: Int,
    staleFeedCount: Int,
    inactivityRemainingSec: Int,
    audioState: AudioControllerState,
    isRefreshing: Boolean,
    isCompact: Boolean,
    onSearchClick: () -> Unit,
    onCycleTextScale: () -> Unit,
    onAudioToggle: () -> Unit,
    onRefreshClick: () -> Unit,
    onEndSessionClick: () -> Unit,
    onAdminClick: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            // Left: Edition day & status indicators
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f, fill = false),
            ) {
                Text(
                    text = formatEditionDayLabel(lastRefreshMs),
                    style = MaterialTheme.typography.labelMedium,
                    color = DeepInk,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (!isCompact) {
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "•  ${venueConfig.defaultCityOrRegion.uppercase()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = SlateInk,
                        maxLines = 1,
                    )
                }
                if (isOffline) {
                    Spacer(Modifier.width(8.dp))
                    StatusPill(
                        text = "OFFLINE CACHE",
                        bgColor = OxbloodTint,
                        fgColor = OxbloodRed,
                        icon = {
                            Icon(
                                Icons.Outlined.CloudOff,
                                contentDescription = "Offline cached edition",
                                tint = OxbloodRed,
                                modifier = Modifier.size(13.dp),
                            )
                        }
                    )
                } else if (unavailableFeedCount > 0 || staleFeedCount > 0) {
                    Spacer(Modifier.width(8.dp))
                    val label = if (unavailableFeedCount > 0) {
                        "$unavailableFeedCount SOURCE DOWN"
                    } else {
                        "$staleFeedCount STALE"
                    }
                    StatusPill(
                        text = label,
                        bgColor = AmberTint,
                        fgColor = AmberNotice,
                        icon = {
                            Icon(
                                Icons.Default.WarningAmber,
                                contentDescription = "Source health notice",
                                tint = AmberNotice,
                                modifier = Modifier.size(13.dp),
                            )
                        }
                    )
                }
            }

            // Center: Venue label on wide screens
            if (!isCompact) {
                Text(
                    text = venueConfig.venueName.uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    color = SlateInk,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
            }

            // Right: Actual update timestamp + utility controls (48dp touch targets)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.End,
            ) {
                Text(
                    text = "Updated ${formatTimeShort(lastRefreshMs)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateInk,
                    maxLines = 1,
                )
                Spacer(Modifier.width(4.dp))
                IconButton(
                    onClick = onRefreshClick,
                    enabled = !isRefreshing,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("refresh_edition_button"),
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh news feeds",
                        tint = if (isRefreshing) ForestGreen else DeepInk,
                        modifier = Modifier.size(20.dp),
                    )
                }
                IconButton(
                    onClick = onSearchClick,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("open_search_button"),
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search articles",
                        tint = DeepInk,
                        modifier = Modifier.size(21.dp),
                    )
                }
                TextButton(
                    onClick = onCycleTextScale,
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("text_size_button"),
                ) {
                    Text(
                        text = when (venueConfig.textScale) {
                            TextScaleOption.COMPACT -> "Aa-"
                            TextScaleOption.STANDARD -> "Aa"
                            TextScaleOption.LARGE -> "Aa+"
                            TextScaleOption.EXTRA_LARGE -> "Aa++"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        color = DeepInk,
                    )
                }
                IconButton(
                    onClick = onAudioToggle,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("audio_toggle_button"),
                ) {
                    val isPlaying = audioState.status is AudioPlaybackStatus.Playing
                    Icon(
                        imageVector = if (isPlaying) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                        contentDescription = if (isPlaying) "Stop audio reading" else "Audio status",
                        tint = if (isPlaying) ForestGreen else DeepInk,
                        modifier = Modifier.size(20.dp),
                    )
                }
                if (venueConfig.kioskModeEnabled) {
                    OutlinedButton(
                        onClick = onEndSessionClick,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        border = BorderStroke(1.dp, OxbloodRed.copy(alpha = 0.55f)),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("end_session_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.PowerSettingsNew,
                            contentDescription = "End shared kiosk session",
                            tint = OxbloodRed,
                            modifier = Modifier.size(16.dp),
                        )
                        if (!isCompact) {
                            Spacer(Modifier.width(5.dp))
                            Text(
                                text = "End session (${inactivityRemainingSec}s)",
                                style = MaterialTheme.typography.labelSmall,
                                color = OxbloodRed,
                            )
                        }
                    }
                }
                if (!venueConfig.kioskModeEnabled) {
                    IconButton(
                        onClick = onAdminClick,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("admin_lock_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.AdminPanelSettings,
                            contentDescription = "Newsroom administration",
                            tint = DeepInk,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
            }
        }
        NewspaperRule(color = StrongRule, thickness = 1.dp)
    }
}

@Composable
fun StatusPill(
    text: String,
    bgColor: Color,
    fgColor: Color,
    icon: (@Composable () -> Unit)? = null,
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(bgColor)
            .border(1.dp, fgColor.copy(alpha = 0.35f), RoundedCornerShape(3.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            icon()
            Spacer(Modifier.width(4.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = fgColor,
            maxLines = 1,
        )
    }
}

@Composable
fun MastheadBanner(
    isCompact: Boolean,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = if (isCompact) 8.dp else 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = "THE DAILY TERMINAL",
            style = if (isCompact) {
                MaterialTheme.typography.displayLarge.copy(
                    fontSize = MaterialTheme.typography.displayLarge.fontSize * 0.72f,
                    lineHeight = MaterialTheme.typography.displayLarge.lineHeight * 0.75f,
                )
            } else {
                MaterialTheme.typography.displayLarge
            },
            color = DeepInk,
            textAlign = TextAlign.Center,
            modifier = Modifier.semantics { heading() },
        )
        Spacer(Modifier.height(4.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.widthIn(max = 460.dp),
        ) {
            NewspaperRule(modifier = Modifier.weight(1f), color = StrongRule.copy(alpha = 0.6f))
            Text(
                text = "A wider view of the world",
                style = MaterialTheme.typography.titleSmall,
                color = DeepInk,
                modifier = Modifier.padding(horizontal = 14.dp),
            )
            NewspaperRule(modifier = Modifier.weight(1f), color = StrongRule.copy(alpha = 0.6f))
        }
    }
}

@Composable
fun SectionNavBar(
    sections: List<NewsSection>,
    selectedSection: NewsSection,
    onSelectSection: (NewsSection) -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        NewspaperRule(color = StrongRule, thickness = 1.dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            sections.forEachIndexed { idx, section ->
                val isSelected = section == selectedSection
                Box(
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) ForestGreen else Color.Transparent)
                        .clickable { onSelectSection(section) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                        .testTag("section_tab_${section.name.lowercase()}"),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = section.label,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        ),
                        color = if (isSelected) CreamPaper else DeepInk,
                        maxLines = 1,
                    )
                }
                if (idx < sections.lastIndex) {
                    Text(
                        text = "|",
                        style = MaterialTheme.typography.bodySmall,
                        color = NewsprintRule,
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
            }
        }
        NewspaperRule(color = NewsprintRule, thickness = 1.dp)
    }
}

@Composable
fun ArticleThumbnailImage(
    article: ArticleEntity,
    modifier: Modifier = Modifier,
    contentDescription: String = article.title,
) {
    if (article.imagePermission != ImagePermission.PERMITTED.name) {
        return
    }
    val drawableRes = remember(article.localDrawableName) {
        when (article.localDrawableName) {
            "img_railway_cities" -> R.drawable.img_railway_cities
            "img_north_sea_wind" -> R.drawable.img_north_sea_wind
            "img_materials_lab" -> R.drawable.img_materials_lab
            "img_explore_architecture" -> R.drawable.img_explore_architecture
            "img_explore_books" -> R.drawable.img_explore_books
            "img_explore_bakery" -> R.drawable.img_explore_bakery
            "img_westminster_etching" -> R.drawable.img_westminster_etching
            else -> null
        }
    }
    if (drawableRes != null) {
        Image(
            painter = painterResource(id = drawableRes),
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier
                .clip(RoundedCornerShape(2.dp))
                .border(1.dp, NewsprintRule, RoundedCornerShape(2.dp)),
        )
    } else if (!article.remoteImageUrl.isNullOrBlank()) {
        AsyncImage(
            model = article.remoteImageUrl,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier
                .clip(RoundedCornerShape(2.dp))
                .border(1.dp, NewsprintRule, RoundedCornerShape(2.dp)),
        )
    }
}

@Composable
fun SaveStoryButton(
    isSaved: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(1.dp, if (isSaved) ForestGreen else NewsprintRule),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = if (isSaved) ForestGreen.copy(alpha = 0.12f) else CreamPaper,
            contentColor = if (isSaved) ForestGreen else DeepInk,
        ),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
        modifier = modifier.minimumInteractiveComponentSize(),
    ) {
        Icon(
            imageVector = if (isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
            contentDescription = if (isSaved) "Remove saved story" else "Save story to session",
            modifier = Modifier.size(17.dp),
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = if (isSaved) "Saved" else "Save",
            style = MaterialTheme.typography.labelLarge,
        )
    }
}

@Composable
fun AudioPlaybackBar(
    audioState: AudioControllerState,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit,
    onChangeSpeed: (Float) -> Unit,
) {
    val status = audioState.status
    if (status is AudioPlaybackStatus.Idle) return

    Surface(
        color = NewsprintInset,
        border = BorderStroke(1.dp, StrongRule.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                val (headline, sub) = when (status) {
                    is AudioPlaybackStatus.Playing -> "Listening: ${status.title}" to "${status.publisher} • ${status.speed}x speed"
                    is AudioPlaybackStatus.Paused -> "Paused: ${status.title}" to "${status.publisher} • Tap Play to resume"
                    is AudioPlaybackStatus.BlockedByRights -> "Audio Restricted" to status.reason
                    is AudioPlaybackStatus.Unavailable -> "Audio Adapter Notice" to status.reason
                    AudioPlaybackStatus.Idle -> "" to ""
                }
                Text(
                    text = headline,
                    style = MaterialTheme.typography.labelLarge,
                    color = DeepInk,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = sub,
                    style = MaterialTheme.typography.bodySmall,
                    color = SlateInk,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (status is AudioPlaybackStatus.Playing || status is AudioPlaybackStatus.Paused) {
                    val speeds = listOf(0.85f, 1.0f, 1.25f, 1.5f)
                    val nextSpeed = speeds[(speeds.indexOfFirst { kotlin.math.abs(it - audioState.speed) < 0.05f } + 1) % speeds.size]
                    TextButton(
                        onClick = { onChangeSpeed(nextSpeed) },
                        modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                        Text("${audioState.speed}x", style = MaterialTheme.typography.labelLarge, color = ForestGreen)
                    }
                    IconButton(
                        onClick = if (status is AudioPlaybackStatus.Playing) onPause else onResume,
                        modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                        Icon(
                            imageVector = if (status is AudioPlaybackStatus.Playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (status is AudioPlaybackStatus.Playing) "Pause narration" else "Resume narration",
                            tint = ForestGreen,
                        )
                    }
                }
                IconButton(
                    onClick = onStop,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("audio_stop_button"),
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Stop audio narration",
                        tint = OxbloodRed,
                    )
                }
            }
        }
    }
}

@Composable
fun QrHandoffDialog(
    article: ArticleEntity,
    sessionId: String,
    onDismiss: () -> Unit,
) {
    val handoffUrl = remember(article.id, sessionId) {
        "${article.canonicalUrl}?handoff=${sessionId.takeLast(6)}"
    }
    val qrBitmap: Bitmap = remember(handoffUrl) {
        QrCodeGenerator.renderBitmap(handoffUrl, pixelSize = 360)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = WarmIvory,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.QrCode2, contentDescription = null, tint = ForestGreen)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Continue on your personal device",
                    style = MaterialTheme.typography.headlineMedium,
                    color = DeepInk,
                )
            }
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = "Scan with your phone camera to open the canonical publisher link. No personal account is stored on this shared terminal.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SlateInk,
                )
                Spacer(Modifier.height(14.dp))
                Image(
                    bitmap = qrBitmap.asImageBitmap(),
                    contentDescription = "QR code for ${article.title}",
                    modifier = Modifier
                        .size(210.dp)
                        .border(1.dp, NewsprintRule, RoundedCornerShape(4.dp))
                        .padding(6.dp),
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = article.publisherName,
                    style = MaterialTheme.typography.labelMedium,
                    color = OxbloodRed,
                )
                Text(
                    text = handoffUrl,
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateInk,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen, contentColor = CreamPaper),
                modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
                Text("Done")
            }
        },
    )
}

@Composable
fun AdminAuthDialog(
    errorText: String?,
    onSubmitPin: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = WarmIvory,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = OxbloodRed)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Newsroom Administration",
                    style = MaterialTheme.typography.headlineMedium,
                    color = DeepInk,
                )
            }
        },
        text = {
            Column {
                Text(
                    text = "Enter the newsroom passcode to manage feeds, content permissions, story clusters, and kiosk settings. (Demo PIN: 2468)",
                    style = MaterialTheme.typography.bodySmall,
                    color = SlateInk,
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 12) pin = it },
                    label = { Text("Passcode") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_pin_input"),
                )
                if (!errorText.isNullOrBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = errorText,
                        style = MaterialTheme.typography.bodySmall,
                        color = OxbloodRed,
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmitPin(pin) },
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen, contentColor = CreamPaper),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("admin_pin_submit"),
            ) {
                Text("Unlock")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
                Text("Cancel", color = DeepInk)
            }
        },
    )
}
