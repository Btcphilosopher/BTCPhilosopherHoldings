package com.example.data.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.local.ArticleEntity
import com.example.data.model.ContentRightsMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

private const val TAG = "ArticleAudioController"

sealed interface AudioPlaybackStatus {
    data object Idle : AudioPlaybackStatus
    data class Playing(val title: String, val publisher: String, val speed: Float) : AudioPlaybackStatus
    data class Paused(val title: String, val publisher: String, val speed: Float) : AudioPlaybackStatus
    data class BlockedByRights(val reason: String) : AudioPlaybackStatus
    data class Unavailable(val reason: String) : AudioPlaybackStatus
}

data class AudioControllerState(
    val status: AudioPlaybackStatus = AudioPlaybackStatus.Idle,
    val speed: Float = 1.0f,
    val ttsReady: Boolean = false,
    val activeArticleId: String? = null,
)

class ArticleAudioController(context: Context) {
    private val appContext = context.applicationContext
    private val _state = MutableStateFlow(AudioControllerState())
    val state: StateFlow<AudioControllerState> = _state.asStateFlow()

    private var tts: TextToSpeech? = null
    private var lastTextToSpeak: String? = null
    private var lastTitle: String = ""
    private var lastPublisher: String = ""

    init {
        try {
            tts = TextToSpeech(appContext) { initStatus ->
                if (initStatus == TextToSpeech.SUCCESS) {
                    val langResult = tts?.setLanguage(Locale.UK)
                    val ready = langResult != TextToSpeech.LANG_MISSING_DATA &&
                        langResult != TextToSpeech.LANG_NOT_SUPPORTED
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) {
                            _state.value = _state.value.copy(
                                status = AudioPlaybackStatus.Idle,
                                activeArticleId = null,
                            )
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            _state.value = _state.value.copy(
                                status = AudioPlaybackStatus.Unavailable("Audio playback failed."),
                                activeArticleId = null,
                            )
                        }
                    })
                    _state.value = _state.value.copy(ttsReady = ready)
                } else {
                    _state.value = _state.value.copy(
                        ttsReady = false,
                        status = AudioPlaybackStatus.Unavailable("Device Text-to-Speech engine unavailable."),
                    )
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "TextToSpeech initialization unavailable in this environment", e)
            _state.value = _state.value.copy(
                ttsReady = false,
                status = AudioPlaybackStatus.Unavailable("Speech synthesis unavailable on this device."),
            )
        }
    }

    fun playArticle(article: ArticleEntity) {
        if (!article.allowAudioTts || article.contentRightsMode == ContentRightsMode.HEADLINE_AND_LINK.name) {
            _state.value = _state.value.copy(
                status = AudioPlaybackStatus.BlockedByRights(
                    "Audio narration is not permitted under ${article.publisherName}’s content licence."
                ),
                activeArticleId = article.id,
            )
            return
        }

        val text = buildString {
            append(article.title).append(". ")
            append("From ").append(article.publisherName).append(". ")
            if (article.contentRightsMode == ContentRightsMode.LICENSED_FULL_TEXT.name && !article.fullText.isNullOrBlank()) {
                append(article.fullText.take(3800))
            } else {
                append(article.excerpt)
            }
        }
        speakInternal(
            itemId = article.id,
            title = article.title,
            publisher = article.publisherName,
            text = text,
        )
    }

    fun playBriefing(title: String, bodyText: String) {
        speakInternal(
            itemId = "briefing",
            title = title,
            publisher = "The Daily Terminal",
            text = bodyText.take(3800),
        )
    }

    private fun speakInternal(itemId: String, title: String, publisher: String, text: String) {
        lastTextToSpeak = text
        lastTitle = title
        lastPublisher = publisher
        val engine = tts
        val currentSpeed = _state.value.speed
        if (engine == null || !_state.value.ttsReady) {
            _state.value = _state.value.copy(
                status = AudioPlaybackStatus.Unavailable(
                    "Device TTS voice pack unavailable in this emulator; playback adapter ready."
                ),
                activeArticleId = itemId,
            )
            return
        }
        engine.setSpeechRate(currentSpeed)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dt_${System.currentTimeMillis()}")
        _state.value = _state.value.copy(
            status = AudioPlaybackStatus.Playing(title, publisher, currentSpeed),
            activeArticleId = itemId,
        )
    }

    fun pause() {
        val current = _state.value.status
        if (current is AudioPlaybackStatus.Playing) {
            tts?.stop()
            _state.value = _state.value.copy(
                status = AudioPlaybackStatus.Paused(current.title, current.publisher, current.speed)
            )
        }
    }

    fun resume() {
        val current = _state.value.status
        val text = lastTextToSpeak ?: return
        if (current is AudioPlaybackStatus.Paused) {
            speakInternal(_state.value.activeArticleId ?: "resumed", lastTitle, lastPublisher, text)
        }
    }

    fun setSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.75f, 1.75f)
        _state.value = _state.value.copy(speed = clamped)
        val current = _state.value.status
        if (current is AudioPlaybackStatus.Playing && lastTextToSpeak != null) {
            speakInternal(_state.value.activeArticleId ?: "speed", lastTitle, lastPublisher, lastTextToSpeak!!)
        }
    }

    fun stopImmediately() {
        runCatching { tts?.stop() }
        lastTextToSpeak = null
        _state.value = _state.value.copy(
            status = AudioPlaybackStatus.Idle,
            activeArticleId = null,
        )
    }

    fun shutdown() {
        stopImmediately()
        runCatching { tts?.shutdown() }
        tts = null
    }
}
