package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.BriefingRepository
import com.example.data.audio.ArticleAudioController
import com.example.data.audio.AudioControllerState
import com.example.data.ingestion.FeedIngestionService
import com.example.data.local.ArticleEntity
import com.example.data.local.ArticleVersionEntity
import com.example.data.local.AuditLogEntity
import com.example.data.local.DailyTerminalDatabase
import com.example.data.local.EditionSnapshotEntity
import com.example.data.local.EditorialPlacementEntity
import com.example.data.local.FeedSourceEntity
import com.example.data.local.RefreshJobEntity
import com.example.data.local.StoryClusterEntity
import com.example.data.local.VenuePreferencesStore
import com.example.data.model.BriefingUiState
import com.example.data.model.ContentRightsMode
import com.example.data.model.DateFilterOption
import com.example.data.model.ImagePermission
import com.example.data.model.NewsSection
import com.example.data.model.SidebarFeedMode
import com.example.data.model.SourceAdapterType
import com.example.data.model.SourceHealthStatus
import com.example.data.model.VenueConfig
import com.example.data.repository.NewsRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface TerminalRoute {
    data object FrontPage : TerminalRoute
    data class Reader(val articleId: String) : TerminalRoute
    data object Briefing : TerminalRoute
    data class CompareCoverage(val focusedClusterId: String? = null) : TerminalRoute
    data object Search : TerminalRoute
    data object Admin : TerminalRoute
}

data class SearchFilterState(
    val query: String = "",
    val section: NewsSection? = null,
    val publisher: String? = null,
    val dateFilter: DateFilterOption = DateFilterOption.ALL,
    val language: String? = null,
    val articleType: String? = null,
)

class DailyTerminalViewModel(application: Application) : AndroidViewModel(application) {
    private val db = DailyTerminalDatabase.getInstance(application)
    private val dao = db.dao()
    private val prefsStore = VenuePreferencesStore(application)
    private val ingestionService = FeedIngestionService(dao)
    private val repository = NewsRepository(dao, prefsStore, ingestionService)
    private val briefingRepository = BriefingRepository()
    val audioController = ArticleAudioController(application)

    private val _route = MutableStateFlow<TerminalRoute>(TerminalRoute.FrontPage)
    val route: StateFlow<TerminalRoute> = _route.asStateFlow()

    private val _selectedSection = MutableStateFlow(NewsSection.FRONT_PAGE)
    val selectedSection: StateFlow<NewsSection> = _selectedSection.asStateFlow()

    private val _selectedSidebarMode = MutableStateFlow(SidebarFeedMode.TOP_STORIES)
    val selectedSidebarMode: StateFlow<SidebarFeedMode> = _selectedSidebarMode.asStateFlow()

    private val _searchFilters = MutableStateFlow(SearchFilterState())
    val searchFilters: StateFlow<SearchFilterState> = _searchFilters.asStateFlow()

    private val _briefingState = MutableStateFlow<BriefingUiState>(BriefingUiState.Idle)
    val briefingState: StateFlow<BriefingUiState> = _briefingState.asStateFlow()

    private val _briefingReviewed = MutableStateFlow(true)
    val briefingReviewed: StateFlow<Boolean> = _briefingReviewed.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _newEditionBanner = MutableStateFlow<String?>(null)
    val newEditionBanner: StateFlow<String?> = _newEditionBanner.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _isOffline = MutableStateFlow(false)
    val isOffline: StateFlow<Boolean> = _isOffline.asStateFlow()

    private val _qrHandoffArticle = MutableStateFlow<ArticleEntity?>(null)
    val qrHandoffArticle: StateFlow<ArticleEntity?> = _qrHandoffArticle.asStateFlow()

    // Admin authentication state
    private val _adminUnlocked = MutableStateFlow(false)
    val adminUnlocked: StateFlow<Boolean> = _adminUnlocked.asStateFlow()

    private val _showAdminAuthDialog = MutableStateFlow(false)
    val showAdminAuthDialog: StateFlow<Boolean> = _showAdminAuthDialog.asStateFlow()

    private val _adminAuthError = MutableStateFlow<String?>(null)
    val adminAuthError: StateFlow<String?> = _adminAuthError.asStateFlow()

    private var failedPinAttempts = 0
    private var pinLockoutUntilMs = 0L

    // Kiosk inactivity countdown
    private val _inactivityRemainingSec = MutableStateFlow(180)
    val inactivityRemainingSec: StateFlow<Int> = _inactivityRemainingSec.asStateFlow()
    private var lastInteractionMs = System.currentTimeMillis()
    private var briefingJob: Job? = null

    val venueConfig: StateFlow<VenueConfig> = repository.venueConfigFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), VenueConfig())

    val activeSessionId: StateFlow<String> = repository.activeSessionIdFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "kiosk_session_initial")

    val lastRefreshMs: StateFlow<Long> = repository.lastRefreshMsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), System.currentTimeMillis())

    val activeArticles: StateFlow<List<ArticleEntity>> = repository.activeArticlesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAdminArticles: StateFlow<List<ArticleEntity>> = repository.allAdminArticlesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val feedSources: StateFlow<List<FeedSourceEntity>> = repository.feedSourcesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val clusters: StateFlow<List<StoryClusterEntity>> = repository.clustersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val placement: StateFlow<EditorialPlacementEntity?> = repository.placementFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val snapshots: StateFlow<List<EditionSnapshotEntity>> = repository.snapshotsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val refreshJobs: StateFlow<List<RefreshJobEntity>> = repository.refreshJobsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntity>> = repository.auditLogsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val savedArticleIds: StateFlow<Set<String>> = activeSessionId
        .flatMapLatest { sid -> repository.observeSavedArticleIds(sid) }
        .combine(flowOf(Unit)) { ids, _ -> ids.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val historyArticleIds: StateFlow<List<String>> = activeSessionId
        .flatMapLatest { sid -> repository.observeHistoryArticleIds(sid) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val audioState: StateFlow<AudioControllerState> = audioController.state

    val orderedSections: StateFlow<List<NewsSection>> = placement
        .combine(flowOf(Unit)) { p, _ ->
            val raw = p?.sectionOrderCsv?.split(",")?.mapNotNull { name ->
                NewsSection.entries.firstOrNull { it.name == name.trim() }
            }.orEmpty()
            if (raw.size == NewsSection.entries.size) raw else NewsSection.entries
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), NewsSection.entries)

    val searchResults: StateFlow<List<ArticleEntity>> = combine(
        activeArticles,
        searchFilters,
    ) { articles, filters ->
        repository.filterPermittedSearchResults(
            articles = articles,
            query = filters.query,
            section = filters.section,
            publisherFilter = filters.publisher,
            dateFilter = filters.dateFilter,
            languageFilter = filters.language,
            articleTypeFilter = filters.articleType,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.ensureSeededAndSessionReady()
            checkConnectivity()
        }
        // Inactivity monitor loop for shared coffee-shop kiosk reset
        viewModelScope.launch {
            while (true) {
                delay(1000L)
                checkConnectivity()
                val cfg = venueConfig.value
                if (cfg.kioskModeEnabled) {
                    val elapsedSec = ((System.currentTimeMillis() - lastInteractionMs) / 1000L).toInt()
                    val remaining = maxOf(0, cfg.inactivityTimeoutSeconds - elapsedSec)
                    _inactivityRemainingSec.value = remaining
                    if (remaining == 0) {
                        val hasSessionActivity = savedArticleIds.value.isNotEmpty() ||
                            historyArticleIds.value.isNotEmpty() ||
                            _route.value != TerminalRoute.FrontPage ||
                            _adminUnlocked.value
                        if (hasSessionActivity) {
                            endSessionAndReset("Kiosk session timed out after inactivity; previous reader state cleared.")
                        } else {
                            registerUserInteraction()
                        }
                    }
                }
            }
        }
    }

    fun registerUserInteraction() {
        lastInteractionMs = System.currentTimeMillis()
        _inactivityRemainingSec.value = venueConfig.value.inactivityTimeoutSeconds
    }

    fun selectSection(section: NewsSection) {
        registerUserInteraction()
        _selectedSection.value = section
        if (_selectedSidebarMode.value == SidebarFeedMode.SAVED_READING ||
            _selectedSidebarMode.value == SidebarFeedMode.READING_HISTORY
        ) {
            _selectedSidebarMode.value = SidebarFeedMode.TOP_STORIES
        }
        if (_route.value != TerminalRoute.FrontPage) {
            _route.value = TerminalRoute.FrontPage
        }
    }

    fun selectSidebarMode(mode: SidebarFeedMode) {
        registerUserInteraction()
        _selectedSidebarMode.value = mode
        if (mode == SidebarFeedMode.LOCAL_BRIEFING) {
            _selectedSection.value = NewsSection.LOCAL
        } else if (mode == SidebarFeedMode.TOP_STORIES && _selectedSection.value == NewsSection.LOCAL) {
            _selectedSection.value = NewsSection.FRONT_PAGE
        }
        _route.value = TerminalRoute.FrontPage
    }

    fun openArticle(articleId: String) {
        registerUserInteraction()
        _route.value = TerminalRoute.Reader(articleId)
        viewModelScope.launch {
            repository.recordReadingHistory(activeSessionId.value, articleId)
        }
    }

    fun openBriefing(aiMode: Boolean = false) {
        registerUserInteraction()
        _route.value = TerminalRoute.Briefing
        if (aiMode) {
            generateAiBriefing()
        } else {
            loadEditorialBriefing()
        }
    }

    fun loadEditorialBriefing() {
        briefingJob?.cancel()
        _briefingState.value = briefingRepository.buildEditorialBriefing(
            articles = activeArticles.value,
            reviewedByEditor = _briefingReviewed.value,
        )
    }

    fun generateAiBriefing() {
        briefingJob?.cancel()
        briefingJob = viewModelScope.launch {
            briefingRepository.streamAiBriefing(
                articles = activeArticles.value,
                aiAllowedGlobal = venueConfig.value.aiSummaryAllowedGlobal,
            ).collect { state ->
                _briefingState.value = state
            }
        }
    }

    fun toggleBriefingReviewed() {
        if (!_adminUnlocked.value) return
        _briefingReviewed.value = !_briefingReviewed.value
        val cur = _briefingState.value
        if (cur is BriefingUiState.Success) {
            _briefingState.value = cur.copy(reviewedByEditor = _briefingReviewed.value)
        }
    }

    fun openCompareCoverage(clusterId: String? = null) {
        registerUserInteraction()
        _route.value = TerminalRoute.CompareCoverage(clusterId)
    }

    fun openSearch() {
        registerUserInteraction()
        _route.value = TerminalRoute.Search
    }

    fun navigateBackToFrontPage() {
        registerUserInteraction()
        _route.value = TerminalRoute.FrontPage
    }

    fun observeArticle(articleId: String): Flow<ArticleEntity?> =
        repository.observeArticleById(articleId)

    fun observeVersions(articleId: String): Flow<List<ArticleVersionEntity>> =
        repository.observeVersionsForArticle(articleId)

    fun toggleSaveArticle(articleId: String) {
        registerUserInteraction()
        viewModelScope.launch {
            val saved = repository.toggleSaveArticle(activeSessionId.value, articleId)
            _statusBanner.value = if (saved) {
                "Saved to this session's reading list (clears on session end)."
            } else {
                "Removed from saved reading."
            }
        }
    }

    fun cycleTextScale() {
        registerUserInteraction()
        viewModelScope.launch {
            val next = repository.cycleTextScale()
            _statusBanner.value = "Text size: ${next.label}"
        }
    }

    fun openQrHandoff(article: ArticleEntity) {
        registerUserInteraction()
        _qrHandoffArticle.value = article
    }

    fun closeQrHandoff() {
        registerUserInteraction()
        _qrHandoffArticle.value = null
    }

    fun dismissStatusBanner() {
        _statusBanner.value = null
    }

    fun applyNewEditionBanner() {
        _newEditionBanner.value = null
        _route.value = TerminalRoute.FrontPage
        _selectedSection.value = NewsSection.FRONT_PAGE
        _selectedSidebarMode.value = SidebarFeedMode.TOP_STORIES
    }

    fun refreshEditionNow() {
        registerUserInteraction()
        if (_isRefreshing.value) return
        viewModelScope.launch {
            _isRefreshing.value = true
            val summary = repository.refreshFeeds(venueConfig.value)
            _isRefreshing.value = false
            val isReading = _route.value is TerminalRoute.Reader
            if (isReading && (summary.newArticlesInserted > 0 || summary.articlesUpdated > 0)) {
                _newEditionBanner.value =
                    "New edition available (+${summary.newArticlesInserted} new, ${summary.articlesUpdated} updated)"
            } else {
                _statusBanner.value = buildString {
                    append("Checked ${summary.feedsChecked} feeds: ")
                    append("+${summary.newArticlesInserted} new, ${summary.articlesUpdated} updated, ")
                    append("${summary.duplicatesSkipped} duplicates skipped")
                    if (summary.feedsFailed > 0) append(" (${summary.feedsFailed} source unavailable)")
                }
            }
        }
    }

    fun importDemoFixtureFeed(feedId: String = "feed_civic_review") {
        registerUserInteraction()
        viewModelScope.launch {
            _isRefreshing.value = true
            val res = repository.importSingleFeedById(feedId, venueConfig.value)
            _isRefreshing.value = false
            _statusBanner.value = if (res.failed) {
                "Source import failed: ${res.note}"
            } else {
                "Imported fixture feed: +${res.inserted} new, ${res.updated} updated, ${res.deduplicated} duplicates skipped."
            }
        }
    }

    fun updateSearchFilters(transform: (SearchFilterState) -> SearchFilterState) {
        registerUserInteraction()
        _searchFilters.value = transform(_searchFilters.value)
    }

    fun clearSearchFilters() {
        registerUserInteraction()
        _searchFilters.value = SearchFilterState()
    }

    // Kiosk reset: immediately stop audio, clear anonymous saved/history, rotate session, return Home
    fun endSessionAndReset(customBanner: String = "Session ended — saved items and reading history cleared.") {
        audioController.stopImmediately()
        briefingJob?.cancel()
        _briefingState.value = BriefingUiState.Idle
        _qrHandoffArticle.value = null
        _adminUnlocked.value = false
        _showAdminAuthDialog.value = false
        _searchFilters.value = SearchFilterState()
        _selectedSection.value = NewsSection.FRONT_PAGE
        _selectedSidebarMode.value = SidebarFeedMode.TOP_STORIES
        _route.value = TerminalRoute.FrontPage
        viewModelScope.launch {
            repository.resetKioskSession(activeSessionId.value)
            registerUserInteraction()
            _statusBanner.value = customBanner
        }
    }

    // Admin Gate & Operations
    fun requestAdminAccess() {
        registerUserInteraction()
        if (_adminUnlocked.value) {
            _route.value = TerminalRoute.Admin
        } else {
            _adminAuthError.value = null
            _showAdminAuthDialog.value = true
        }
    }

    fun dismissAdminAuthDialog() {
        _showAdminAuthDialog.value = false
        _adminAuthError.value = null
    }

    fun submitAdminPin(pin: String) {
        registerUserInteraction()
        val now = System.currentTimeMillis()
        if (now < pinLockoutUntilMs) {
            val sec = ((pinLockoutUntilMs - now) / 1000L) + 1
            _adminAuthError.value = "Too many attempts. Try again in ${sec}s."
            return
        }
        viewModelScope.launch {
            if (repository.verifyAdminPin(pin)) {
                failedPinAttempts = 0
                _adminUnlocked.value = true
                _showAdminAuthDialog.value = false
                _adminAuthError.value = null
                _route.value = TerminalRoute.Admin
            } else {
                failedPinAttempts++
                if (failedPinAttempts >= 5) {
                    pinLockoutUntilMs = System.currentTimeMillis() + 30_000L
                    _adminAuthError.value = "Locked for 30s after 5 failed attempts."
                } else {
                    _adminAuthError.value = "Incorrect newsroom passcode (${5 - failedPinAttempts} remaining)."
                }
            }
        }
    }

    fun lockAdminWorkspace() {
        _adminUnlocked.value = false
        if (_route.value == TerminalRoute.Admin) {
            _route.value = TerminalRoute.FrontPage
        }
    }

    fun addOrUpdateFeedSource(
        id: String? = null,
        publisherName: String,
        feedName: String,
        endpointUrl: String,
        adapterType: SourceAdapterType,
        section: NewsSection,
        language: String,
        region: String,
        rightsMode: ContentRightsMode,
        imagePermission: ImagePermission,
        allowCache: Boolean,
        allowSearchIndex: Boolean,
        allowAiSummary: Boolean,
        allowAudioTts: Boolean,
        onResult: (Result<FeedSourceEntity>) -> Unit,
    ) {
        if (!_adminUnlocked.value) return
        viewModelScope.launch {
            val res = repository.addOrUpdateFeedSource(
                id, publisherName, feedName, endpointUrl, adapterType, section,
                language, region, rightsMode, imagePermission,
                allowCache, allowSearchIndex, allowAiSummary, allowAudioTts,
            )
            onResult(res)
        }
    }

    fun addManualEntry(
        title: String,
        standfirst: String,
        bodyText: String,
        publisherName: String,
        author: String?,
        section: NewsSection,
        articleType: String,
        canonicalUrl: String,
        rightsMode: ContentRightsMode,
        onResult: (Result<ArticleEntity>) -> Unit,
    ) {
        if (!_adminUnlocked.value) return
        viewModelScope.launch {
            val res = repository.addManualCuratedArticle(
                title, standfirst, bodyText, publisherName, author,
                section, articleType, canonicalUrl, rightsMode, venueConfig.value,
            )
            onResult(res)
        }
    }

    fun setLeadStoryOverride(articleId: String) {
        if (!_adminUnlocked.value) return
        viewModelScope.launch {
            repository.setLeadStoryOverride(articleId, venueConfig.value)
            _statusBanner.value = "Front-page lead story updated."
        }
    }

    fun moveSectionEarlier(section: NewsSection) {
        if (!_adminUnlocked.value) return
        val current = orderedSections.value.toMutableList()
        val idx = current.indexOf(section)
        if (idx > 1) { // keep FRONT_PAGE first
            current[idx] = current[idx - 1]
            current[idx - 1] = section
            viewModelScope.launch { repository.updateSectionOrder(current) }
        }
    }

    fun captureEditionSnapshot(label: String) {
        if (!_adminUnlocked.value) return
        viewModelScope.launch {
            repository.captureEditionSnapshot(venueConfig.value, label)
            _statusBanner.value = "Edition snapshot recorded."
        }
    }

    fun mergeClusters(sourceId: String, targetId: String) {
        if (!_adminUnlocked.value) return
        viewModelScope.launch {
            repository.mergeClusters(sourceId, targetId)
            _statusBanner.value = "Merged clusters."
        }
    }

    fun splitArticleFromCluster(articleId: String, newTopicLabel: String) {
        if (!_adminUnlocked.value) return
        viewModelScope.launch {
            repository.splitArticleFromCluster(articleId, newTopicLabel)
            _statusBanner.value = "Split story into new cluster."
        }
    }

    fun withdrawOrRestoreArticle(articleId: String, withdraw: Boolean) {
        if (!_adminUnlocked.value) return
        viewModelScope.launch {
            repository.withdrawOrRestoreArticle(articleId, withdraw)
        }
    }

    fun updateVenueConfig(config: VenueConfig) {
        if (!_adminUnlocked.value) return
        viewModelScope.launch {
            repository.updateVenueConfig(config)
            _statusBanner.value = "Venue settings saved."
        }
    }

    private fun checkConnectivity() {
        val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNetwork = cm?.activeNetwork
        val caps = cm?.getNetworkCapabilities(activeNetwork)
        val online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        _isOffline.value = !online
    }

    override fun onCleared() {
        audioController.shutdown()
        super.onCleared()
    }
}
