package com.example.security

import java.security.MessageDigest

object HtmlSanitizer {
    private val dangerousBlockRegex = Regex(
        """(?is)<(script|style|iframe|object|embed|svg|form|noscript|template)[^>]*>.*?</\1\s*>"""
    )
    private val selfClosingDangerousRegex = Regex(
        """(?is)<(script|iframe|object|embed|svg|meta|link|base)[^>]*/?>"""
    )
    private val eventHandlerRegex = Regex("""(?is)\bon\w+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)""")
    private val javascriptUriRegex = Regex("""(?is)(href|src)\s*=\s*["']?\s*(javascript|vbscript|data)\s*:[^"'>\s]*["']?""")
    private val paragraphBreakRegex = Regex("""(?is)</?(p|div|br|li|h[1-6]|blockquote)[^>]*>""")
    private val anyTagRegex = Regex("""(?is)<[^>]+>""")
    private val multiSpaceRegex = Regex("""[ \t\x0B\f\r]+""")
    private val multiNewlineRegex = Regex("""\n{3,}""")

    fun sanitizeToPlainText(rawHtml: String, maxChars: Int = 25_000): String {
        if (rawHtml.isBlank()) return ""
        var cleaned = rawHtml.take(maxChars * 2)
        cleaned = dangerousBlockRegex.replace(cleaned, " ")
        cleaned = selfClosingDangerousRegex.replace(cleaned, " ")
        cleaned = eventHandlerRegex.replace(cleaned, " ")
        cleaned = javascriptUriRegex.replace(cleaned, " ")
        cleaned = paragraphBreakRegex.replace(cleaned, "\n\n")
        cleaned = anyTagRegex.replace(cleaned, " ")
        cleaned = decodeBasicEntities(cleaned)
        cleaned = cleaned.lines().joinToString("\n") { line ->
            multiSpaceRegex.replace(line, " ").trim()
        }
        cleaned = multiNewlineRegex.replace(cleaned, "\n\n").trim()
        return if (cleaned.length > maxChars) cleaned.take(maxChars).trimEnd() + "..." else cleaned
    }

    fun sanitizeSingleLine(raw: String, maxChars: Int = 300): String {
        return sanitizeToPlainText(raw, maxChars)
            .replace("\n", " ")
            .replace(multiSpaceRegex, " ")
            .trim()
            .take(maxChars)
    }

    private fun decodeBasicEntities(input: String): String {
        return input
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
            .replace("&nbsp;", " ")
            .replace("&mdash;", "—")
            .replace("&ndash;", "–")
            .replace("&lsquo;", "‘")
            .replace("&rsquo;", "’")
            .replace("&ldquo;", "“")
            .replace("&rdquo;", "”")
            .replace("&hellip;", "…")
    }

    fun computeSha256Hex(vararg parts: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        parts.forEach { part ->
            digest.update(part.trim().lowercase().toByteArray(Charsets.UTF_8))
            digest.update(0)
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
