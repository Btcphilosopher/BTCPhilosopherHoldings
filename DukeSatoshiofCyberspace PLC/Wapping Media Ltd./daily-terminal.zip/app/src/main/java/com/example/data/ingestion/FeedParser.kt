package com.example.data.ingestion

import com.example.security.FeedUrlValidator
import com.example.security.HtmlSanitizer
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

data class ParsedFeedItem(
    val sourceGuid: String,
    val canonicalUrl: String,
    val title: String,
    val standfirst: String,
    val excerpt: String,
    val bodyText: String?,
    val author: String?,
    val articleType: String,
    val categoryHint: String?,
    val publishedAtMs: Long,
    val updatedAtMs: Long?,
    val imageUrl: String?,
)

sealed class FeedParseOutcome {
    data class Success(val items: List<ParsedFeedItem>, val feedFormat: String) : FeedParseOutcome()
    data class Failure(val reason: String) : FeedParseOutcome()
}

object FeedParser {
    private val rfc822Patterns = listOf(
        "EEE, dd MMM yyyy HH:mm:ss Z",
        "EEE, dd MMM yyyy HH:mm:ss zzz",
        "dd MMM yyyy HH:mm:ss Z",
    )
    private val iso8601Patterns = listOf(
        "yyyy-MM-dd'T'HH:mm:ssXXX",
        "yyyy-MM-dd'T'HH:mm:ss'Z'",
        "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
        "yyyy-MM-dd HH:mm:ss",
    )

    fun parseXml(rawXml: String, nowMs: Long = System.currentTimeMillis()): FeedParseOutcome {
        val trimmed = rawXml.trim()
        if (trimmed.isEmpty()) {
            return FeedParseOutcome.Failure("Feed response body was empty.")
        }
        if (trimmed.contains("<!ENTITY", ignoreCase = true) || trimmed.contains("<!DOCTYPE", ignoreCase = true)) {
            return FeedParseOutcome.Failure("Rejected XML containing DOCTYPE or ENTITY declarations for security.")
        }

        return try {
            val factory = XmlPullParserFactory.newInstance().apply {
                isNamespaceAware = true
                setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
                runCatching { setFeature(XmlPullParser.FEATURE_PROCESS_DOCDECL, false) }
            }
            val parser = factory.newPullParser()
            parser.setInput(StringReader(trimmed))

            val items = mutableListOf<ParsedFeedItem>()
            var format = "UNKNOWN"
            var eventType = parser.eventType
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG) {
                    val tag = parser.name.lowercase(Locale.ROOT)
                    when (tag) {
                        "rss" -> format = "RSS 2.0"
                        "feed" -> format = "Atom 1.0"
                        "item" -> {
                            if (format == "UNKNOWN") format = "RSS 2.0"
                            parseRssItem(parser, nowMs)?.let { items.add(it) }
                        }
                        "entry" -> {
                            if (format == "UNKNOWN") format = "Atom 1.0"
                            parseAtomEntry(parser, nowMs)?.let { items.add(it) }
                        }
                    }
                }
                eventType = parser.next()
            }
            if (format == "UNKNOWN") {
                FeedParseOutcome.Failure("Document is neither a valid RSS 2.0 nor Atom 1.0 feed.")
            } else {
                FeedParseOutcome.Success(items, format)
            }
        } catch (e: Exception) {
            FeedParseOutcome.Failure("Malformed XML feed: ${e.message ?: "parse error"}")
        }
    }

    private fun parseRssItem(parser: XmlPullParser, nowMs: Long): ParsedFeedItem? {
        var title = ""
        var link = ""
        var guid = ""
        var description = ""
        var contentEncoded = ""
        var author: String? = null
        var category: String? = null
        var pubDate: Long? = null
        var imageUrl: String? = null

        val startDepth = parser.depth
        var event = parser.next()
        while (event != XmlPullParser.END_DOCUMENT && !(event == XmlPullParser.END_TAG && parser.depth == startDepth)) {
            if (event == XmlPullParser.START_TAG) {
                val localName = parser.name.lowercase(Locale.ROOT)
                val prefix = parser.prefix?.lowercase(Locale.ROOT) ?: ""
                when {
                    localName == "title" -> title = HtmlSanitizer.sanitizeSingleLine(readTextSafe(parser), 220)
                    localName == "link" -> link = readTextSafe(parser).trim()
                    localName == "guid" -> guid = readTextSafe(parser).trim()
                    localName == "description" -> description = HtmlSanitizer.sanitizeToPlainText(readTextSafe(parser), 4000)
                    localName == "encoded" || (prefix == "content" && localName == "encoded") ->
                        contentEncoded = HtmlSanitizer.sanitizeToPlainText(readTextSafe(parser), 20_000)
                    localName == "author" || localName == "creator" ->
                        author = HtmlSanitizer.sanitizeSingleLine(readTextSafe(parser), 100).ifBlank { null }
                    localName == "category" ->
                        if (category == null) category = HtmlSanitizer.sanitizeSingleLine(readTextSafe(parser), 60).ifBlank { null }
                    localName == "pubdate" -> pubDate = parseDate(readTextSafe(parser))
                    localName == "enclosure" || (prefix == "media" && localName == "content") -> {
                        val urlAttr = parser.getAttributeValue(null, "url")?.trim()
                        val typeAttr = parser.getAttributeValue(null, "type")?.lowercase(Locale.ROOT) ?: ""
                        if (!urlAttr.isNullOrBlank() && (typeAttr.isEmpty() || typeAttr.startsWith("image/"))) {
                            if (FeedUrlValidator.validateRemoteFeedUrl(urlAttr) is com.example.security.UrlValidationResult.Valid) {
                                imageUrl = urlAttr
                            }
                        }
                        skipSubtree(parser)
                    }
                    else -> skipSubtree(parser)
                }
            }
            event = parser.next()
        }
        if (event == XmlPullParser.END_DOCUMENT) {
            throw IllegalStateException("Unexpected end of document inside RSS <item>.")
        }

        if (title.isBlank() || (link.isBlank() && guid.isBlank())) return null
        val canonicalUrl = FeedUrlValidator.canonicalizeUrl(link.ifBlank { guid })
        val effectiveGuid = guid.ifBlank { canonicalUrl }
        val cleanBody = contentEncoded.ifBlank { description }.ifBlank { null }
        val excerpt = description.ifBlank { cleanBody?.take(280) ?: title }.take(340)
        val standfirst = excerpt.substringBefore(". ").let {
            if (it.length in 24..160) "$it." else excerpt.take(150)
        }

        return ParsedFeedItem(
            sourceGuid = effectiveGuid,
            canonicalUrl = canonicalUrl,
            title = title,
            standfirst = standfirst,
            excerpt = excerpt,
            bodyText = cleanBody,
            author = author,
            articleType = "Report",
            categoryHint = category,
            publishedAtMs = pubDate ?: nowMs,
            updatedAtMs = null,
            imageUrl = imageUrl,
        )
    }

    private fun parseAtomEntry(parser: XmlPullParser, nowMs: Long): ParsedFeedItem? {
        var title = ""
        var link = ""
        var id = ""
        var summary = ""
        var content = ""
        var author: String? = null
        var category: String? = null
        var publishedMs: Long? = null
        var updatedMs: Long? = null

        val startDepth = parser.depth
        var event = parser.next()
        while (event != XmlPullParser.END_DOCUMENT && !(event == XmlPullParser.END_TAG && parser.depth == startDepth)) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name.lowercase(Locale.ROOT)) {
                    "title" -> title = HtmlSanitizer.sanitizeSingleLine(readTextSafe(parser), 220)
                    "id" -> id = readTextSafe(parser).trim()
                    "link" -> {
                        val rel = parser.getAttributeValue(null, "rel")?.lowercase(Locale.ROOT)
                        val href = parser.getAttributeValue(null, "href")?.trim().orEmpty()
                        if (href.isNotBlank() && (rel == null || rel == "alternate")) {
                            link = href
                        }
                        skipSubtree(parser)
                    }
                    "summary" -> summary = HtmlSanitizer.sanitizeToPlainText(readTextSafe(parser), 4000)
                    "content" -> content = HtmlSanitizer.sanitizeToPlainText(readTextSafe(parser), 20_000)
                    "author" -> {
                        author = readAtomAuthor(parser)
                    }
                    "category" -> {
                        val term = parser.getAttributeValue(null, "term")
                        if (category == null && !term.isNullOrBlank()) {
                            category = HtmlSanitizer.sanitizeSingleLine(term, 60)
                        }
                        skipSubtree(parser)
                    }
                    "published" -> publishedMs = parseDate(readTextSafe(parser))
                    "updated" -> updatedMs = parseDate(readTextSafe(parser))
                    else -> skipSubtree(parser)
                }
            }
            event = parser.next()
        }
        if (event == XmlPullParser.END_DOCUMENT) {
            throw IllegalStateException("Unexpected end of document inside Atom <entry>.")
        }

        if (title.isBlank() || (link.isBlank() && id.isBlank())) return null
        val canonicalUrl = FeedUrlValidator.canonicalizeUrl(link.ifBlank { id })
        val effectiveGuid = id.ifBlank { canonicalUrl }
        val cleanBody = content.ifBlank { summary }.ifBlank { null }
        val excerpt = summary.ifBlank { cleanBody?.take(280) ?: title }.take(340)
        val standfirst = excerpt.substringBefore(". ").let {
            if (it.length in 24..160) "$it." else excerpt.take(150)
        }

        return ParsedFeedItem(
            sourceGuid = effectiveGuid,
            canonicalUrl = canonicalUrl,
            title = title,
            standfirst = standfirst,
            excerpt = excerpt,
            bodyText = cleanBody,
            author = author,
            articleType = "Dispatch",
            categoryHint = category,
            publishedAtMs = publishedMs ?: updatedMs ?: nowMs,
            updatedAtMs = updatedMs,
            imageUrl = null,
        )
    }

    private fun readAtomAuthor(parser: XmlPullParser): String? {
        var name: String? = null
        val startDepth = parser.depth
        var event = parser.next()
        while (event != XmlPullParser.END_DOCUMENT && !(event == XmlPullParser.END_TAG && parser.depth == startDepth)) {
            if (event == XmlPullParser.START_TAG && parser.name.equals("name", ignoreCase = true)) {
                name = HtmlSanitizer.sanitizeSingleLine(readTextSafe(parser), 100).ifBlank { null }
            } else if (event == XmlPullParser.START_TAG) {
                skipSubtree(parser)
            }
            event = parser.next()
        }
        if (event == XmlPullParser.END_DOCUMENT) {
            throw IllegalStateException("Unexpected end of document inside Atom <author>.")
        }
        return name
    }

    private fun readTextSafe(parser: XmlPullParser): String {
        val sb = StringBuilder()
        val startDepth = parser.depth
        var event = parser.next()
        while (event != XmlPullParser.END_DOCUMENT && !(event == XmlPullParser.END_TAG && parser.depth == startDepth)) {
            if (event == XmlPullParser.TEXT || event == XmlPullParser.CDSECT) {
                sb.append(parser.text)
            } else if (event == XmlPullParser.START_TAG) {
                // Capture nested HTML fragments cleanly before stripping tags in HtmlSanitizer
                sb.append("<").append(parser.name).append(">")
                sb.append(readTextSafe(parser))
                sb.append("</").append(parser.name).append(">")
            }
            event = parser.next()
        }
        if (event == XmlPullParser.END_DOCUMENT) {
            throw IllegalStateException("Unexpected end of document while reading XML text.")
        }
        return sb.toString()
    }

    private fun skipSubtree(parser: XmlPullParser) {
        var depth = 1
        while (depth > 0) {
            when (parser.next()) {
                XmlPullParser.END_TAG -> depth--
                XmlPullParser.START_TAG -> depth++
                XmlPullParser.END_DOCUMENT -> return
            }
        }
    }

    private fun parseDate(raw: String): Long? {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return null
        for (pattern in rfc822Patterns + iso8601Patterns) {
            try {
                val sdf = SimpleDateFormat(pattern, Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }
                return sdf.parse(trimmed)?.time
            } catch (_: Exception) {
            }
        }
        return null
    }
}
