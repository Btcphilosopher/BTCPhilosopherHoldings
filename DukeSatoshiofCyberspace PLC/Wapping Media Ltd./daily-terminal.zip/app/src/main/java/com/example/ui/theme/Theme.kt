package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val DailyTerminalColorScheme = lightColorScheme(
    primary = ForestGreen,
    onPrimary = CreamPaper,
    primaryContainer = ForestGreenTint,
    onPrimaryContainer = ForestGreen,
    secondary = OxbloodRed,
    onSecondary = CreamPaper,
    secondaryContainer = OxbloodTint,
    onSecondaryContainer = OxbloodRed,
    tertiary = StrongRule,
    onTertiary = CreamPaper,
    background = WarmIvory,
    onBackground = DeepInk,
    surface = WarmIvory,
    onSurface = DeepInk,
    surfaceVariant = NewsprintInset,
    onSurfaceVariant = SlateInk,
    surfaceContainerLowest = CreamPaper,
    surfaceContainerLow = WarmIvory,
    surfaceContainer = NewsprintInset,
    surfaceContainerHigh = SelectedSidebarBg,
    outline = NewsprintRule,
    outlineVariant = NewsprintRule,
    error = OxbloodRed,
    onError = CreamPaper,
    errorContainer = OxbloodTint,
    onErrorContainer = OxbloodRed,
)

private val DailyTerminalShapes = Shapes(
    extraSmall = RoundedCornerShape(2.dp),
    small = RoundedCornerShape(4.dp),
    medium = RoundedCornerShape(6.dp),
    large = RoundedCornerShape(8.dp),
    extraLarge = RoundedCornerShape(10.dp),
)

@Composable
fun DailyTerminalTheme(
    textScaleFactor: Float = 1.0f,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DailyTerminalColorScheme,
        typography = buildDailyTerminalTypography(textScaleFactor),
        shapes = DailyTerminalShapes,
        content = content,
    )
}
