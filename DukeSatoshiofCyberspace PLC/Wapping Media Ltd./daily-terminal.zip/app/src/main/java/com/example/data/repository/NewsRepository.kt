package com.example.data.repository

import com.example.data.ingestion.FeedIngestionService
import com.example.data.ingestion.IngestionBatchSummary
import com.example.data.ingestion.RankingEngine
import com.example.data.local.ArticleEntity
import com.example.data.local.ArticleVersionEntity
import com.example.data.local.AuditLogEntity
import com.example.data.local.DailyTerminalDao
import com.example.data.local.DailyTerminalDatabase
import com.example.data.local.EditionSnapshotEntity
import com.example.data.local.EditorialPlacementEntity
import com.example.data.local.FeedSourceEntity
import com.example.data.local.PublisherEntity
import com.example.data.local.ReadingHistoryEntity
import com.example.data.local.RefreshJobEntity
import com.example.data.local.SavedItemEntity
import com.example.data.local.StoryClusterEntity
import com.example.data.local.VenuePreferencesStore
import com.example.data.model.ArticleStatus
import com.example.data.model.ContentRightsMode
import com.example.data.model.DateFilterOption
import com.example.data.model.ImagePermission
import com.example.data.model.NewsSection
import com.example.data.model.SourceAdapterType
import com.example.data.model.SourceHealthStatus
import com.example.data.model.TextScaleOption
import com.example.data.model.VenueConfig
import com.example.security.FeedUrlValidator
import com.example.security.HtmlSanitizer
import com.example.security.UrlValidationResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.UUID

class NewsRepository(
    private val dao: DailyTerminalDao,
    private val prefsStore: VenuePreferencesStore,
    private val ingestionService: FeedIngestionService,
) {
    val activeArticlesFlow: Flow<List<ArticleEntity>> = dao.observeActiveArticles()
    val allAdminArticlesFlow: Flow<List<ArticleEntity>> = dao.observeAllArticlesForAdmin()
    val feedSourcesFlow: Flow<List<FeedSourceEntity>> = dao.observeFeedSources()
    val publishersFlow: Flow<List<PublisherEntity>> = dao.observePublishers()
    val clustersFlow: Flow<List<StoryClusterEntity>> = dao.observeClusters()
    val placementFlow: Flow<EditorialPlacementEntity?> = dao.observeDefaultPlacement()
    val snapshotsFlow: Flow<List<EditionSnapshotEntity>> = dao.observeEditionSnapshots()
    val refreshJobsFlow: Flow<List<RefreshJobEntity>> = dao.observeRefreshJobs()
    val auditLogsFlow: Flow<List<AuditLogEntity>> = dao.observeAuditLogs()

    val venueConfigFlow: Flow<VenueConfig> = prefsStore.venueConfigFlow
    val activeSessionIdFlow: Flow<String> = prefsStore.activeSessionIdFlow
    val lastRefreshMsFlow: Flow<Long> = prefsStore.lastEditionRefreshMsFlow

    suspend fun ensureSeededAndSessionReady(): String {
        DailyTerminalDatabase.seedIfEmpty(dao)
        return prefsStore.ensureInitializedSession()
    }

    fun observeSavedArticleIds(sessionId: String): Flow<List<String>> =
        dao.observeSavedArticleIds(sessionId)

    fun observeHistoryArticleIds(sessionId: String): Flow<List<String>> =
        dao.observeHistoryArticleIds(sessionId)

    fun observeArticleById(id: String): Flow<ArticleEntity?> =
        dao.observeArticleById(id)

    fun observeVersionsForArticle(articleId: String): Flow<List<ArticleVersionEntity>> =
        dao.observeVersionsForArticle(articleId)

    suspend fun toggleSaveArticle(sessionId: String, articleId: String): Boolean {
        val count = dao.isArticleSavedInSession(sessionId, articleId)
        return if (count > 0) {
            dao.removeSavedItem(sessionId, articleId)
            false
        } else {
            dao.saveItem(
                SavedItemEntity(
                    id = "${sessionId}_$articleId",
                    sessionId = sessionId,
                    articleId = articleId,
                    savedAtMs = System.currentTimeMillis(),
                )
            )
            true
        }
    }

    suspend fun recordReadingHistory(sessionId: String, articleId: String) {
        dao.recordHistory(
            ReadingHistoryEntity(
                id = "${sessionId}_$articleId",
                sessionId = sessionId,
                articleId = articleId,
                openedAtMs = System.currentTimeMillis(),
            )
        )
    }

    suspend fun resetKioskSession(currentSessionId: String): String {
        dao.clearSavedItemsForSession(currentSessionId)
        dao.clearHistoryForSession(currentSessionId)
        return prefsStore.rotateSessionId()
    }

    suspend fun cycleTextScale(): TextScaleOption = prefsStore.cycleTextScale()

    suspend fun verifyAdminPin(pin: String): Boolean = prefsStore.verifyAdminPin(pin)

    suspend fun updateVenueConfig(config: VenueConfig) {
        prefsStore.updateVenueConfig(config)
        dao.insertAuditLog(
            AuditLogEntity(
                actorRole = "Administrator",
                actionType = "VENUE_CONFIG_UPDATED",
                targetId = "venue",
                summary = "Updated venue to '${config.venueName}' (${config.defaultCityOrRegion}), kiosk=${config.kioskModeEnabled}, timeout=${config.inactivityTimeoutSeconds}s.",
                createdAtMs = System.currentTimeMillis(),
            )
        )
    }

    suspend fun refreshFeeds(venueConfig: VenueConfig): IngestionBatchSummary {
        val summary = ingestionService.refreshAllActiveFeeds(venueConfig)
        prefsStore.updateLastRefreshMs(System.currentTimeMillis())
        return summary
    }

    suspend fun importSingleFeedById(feedId: String, venueConfig: VenueConfig): FeedIngestionService.SingleFeedResult {
        val feed = dao.getFeedSourceById(feedId)
            ?: return FeedIngestionService.SingleFeedResult(failed = true, note = "Feed not found.")
        val result = ingestionService.ingestSingleFeed(feed)
        val allFeeds = dao.getAllFeedSourcesOnce()
        val healthMap = allFeeds.associate {
            it.id to (SourceHealthStatus.entries.firstOrNull { h -> h.name == it.healthStatus }
                ?: SourceHealthStatus.HEALTHY)
        }
        val reranked = RankingEngine.rerankEdition(dao.getAllArticlesOnce(), venueConfig, healthMap)
        dao.insertArticles(reranked)
        prefsStore.updateLastRefreshMs(System.currentTimeMillis())
        return result
    }

    suspend fun addOrUpdateFeedSource(
        id: String?,
        publisherName: String,
        feedName: String,
        endpointUrl: String,
        adapterType: SourceAdapterType,
        section: NewsSection,
        language: String,
        region: String,
        rightsMode: ContentRightsMode,
        imagePermission: ImagePermission,
        allowCache: Boolean,
        allowSearchIndex: Boolean,
        allowAiSummary: Boolean,
        allowAudioTts: Boolean,
    ): Result<FeedSourceEntity> {
        val isRemote = adapterType == SourceAdapterType.RSS ||
            adapterType == SourceAdapterType.ATOM ||
            adapterType == SourceAdapterType.LICENSED_API

        if (isRemote) {
            val validation = FeedUrlValidator.validateRemoteFeedUrl(
                rawUrl = endpointUrl,
                resolveDns = false,
                allowLocalFixtureScheme = true,
            )
            if (validation is UrlValidationResult.Rejected) {
                return Result.failure(IllegalArgumentException(validation.reason))
            }
        }

        val nowMs = System.currentTimeMillis()
        val cleanPublisher = HtmlSanitizer.sanitizeSingleLine(publisherName, 80).ifBlank { "Independent Desk" }
        val cleanFeed = HtmlSanitizer.sanitizeSingleLine(feedName, 100).ifBlank { "$cleanPublisher Feed" }
        val feedId = id ?: "feed_${UUID.randomUUID().toString().take(8)}"
        val pubId = "pub_${cleanPublisher.lowercase().replace(Regex("""\W+"""), "_")}"

        val entity = FeedSourceEntity(
            id = feedId,
            publisherId = pubId,
            publisherName = cleanPublisher,
            feedName = cleanFeed,
            endpointUrl = endpointUrl.trim(),
            adapterType = adapterType.name,
            enabledSectionsCsv = section.name,
            language = language.ifBlank { "en" },
            region = region.ifBlank { "UK" },
            refreshIntervalMinutes = 20,
            attributionRequirement = "Attribution required to $cleanPublisher.",
            contentRightsMode = rightsMode.name,
            imagePermission = imagePermission.name,
            allowCache = allowCache && rightsMode != ContentRightsMode.HEADLINE_AND_LINK,
            allowSearchIndex = allowSearchIndex,
            allowAiSummary = allowAiSummary && rightsMode != ContentRightsMode.HEADLINE_AND_LINK,
            allowAudioTts = allowAudioTts && rightsMode != ContentRightsMode.HEADLINE_AND_LINK,
            healthStatus = SourceHealthStatus.HEALTHY.name,
            lastSuccessfulRefreshMs = nowMs,
            lastAttemptMs = nowMs,
            lastError = null,
            etag = null,
            lastModifiedHeader = null,
            isActive = true,
        )
        dao.upsertFeedSource(entity)
        dao.insertAuditLog(
            AuditLogEntity(
                actorRole = "Administrator",
                actionType = if (id == null) "FEED_CREATED" else "FEED_UPDATED",
                targetId = feedId,
                summary = "$cleanPublisher ($feedId): rights=${rightsMode.name}, img=${imagePermission.name}, adapter=${adapterType.name}",
                createdAtMs = nowMs,
            )
        )
        return Result.success(entity)
    }

    suspend fun addManualCuratedArticle(
        title: String,
        standfirst: String,
        bodyText: String,
        publisherName: String,
        author: String?,
        section: NewsSection,
        articleType: String,
        canonicalUrl: String,
        rightsMode: ContentRightsMode,
        venueConfig: VenueConfig,
    ): Result<ArticleEntity> {
        val cleanTitle = HtmlSanitizer.sanitizeSingleLine(title, 200)
        if (cleanTitle.isBlank()) {
            return Result.failure(IllegalArgumentException("Headline cannot be empty."))
        }
        val cleanUrl = if (canonicalUrl.isBlank()) {
            "https://dailyterminal.press/curated/${UUID.randomUUID().toString().take(8)}"
        } else {
            when (val res = FeedUrlValidator.validateRemoteFeedUrl(canonicalUrl, resolveDns = false)) {
                is UrlValidationResult.Valid -> res.normalizedUrl
                is UrlValidationResult.Rejected -> return Result.failure(IllegalArgumentException(res.reason))
            }
        }
        val nowMs = System.currentTimeMillis()
        val cleanBody = HtmlSanitizer.sanitizeToPlainText(bodyText)
        val cleanStandfirst = HtmlSanitizer.sanitizeSingleLine(standfirst, 220)
            .ifBlank { cleanBody.take(140) }
        val excerpt = cleanBody.take(320).ifBlank { cleanStandfirst }
        val articleId = "art_curated_${UUID.randomUUID().toString().take(8)}"
        val fingerprint = HtmlSanitizer.computeSha256Hex(cleanTitle, excerpt)

        val article = ArticleEntity(
            id = articleId,
            sourceFeedId = "feed_culture_ledger",
            publisherId = "pub_curated",
            publisherName = HtmlSanitizer.sanitizeSingleLine(publisherName, 60).ifBlank { "Editorial Desk" },
            canonicalUrl = cleanUrl,
            sourceGuid = articleId,
            contentFingerprint = fingerprint,
            title = cleanTitle,
            standfirst = cleanStandfirst,
            excerpt = if (rightsMode == ContentRightsMode.HEADLINE_AND_LINK) {
                "Publisher permissions restrict this entry to headline and canonical source link."
            } else {
                excerpt
            },
            fullText = if (rightsMode == ContentRightsMode.LICENSED_FULL_TEXT) cleanBody else null,
            author = author?.takeIf { it.isNotBlank() },
            articleType = articleType.ifBlank { "Curated" },
            section = section.name,
            language = "en",
            region = venueConfig.defaultCityOrRegion,
            isLocallyRelevant = section == NewsSection.LOCAL,
            isLocalOutlet = false,
            publishedAtMs = nowMs,
            modifiedAtMs = null,
            ingestedAtMs = nowMs,
            retrievedAtMs = nowMs,
            contentRightsMode = rightsMode.name,
            imagePermission = ImagePermission.RESTRICTED_OMIT.name,
            localDrawableName = null,
            remoteImageUrl = null,
            imageAttribution = null,
            allowCache = rightsMode != ContentRightsMode.HEADLINE_AND_LINK,
            allowSearchIndex = true,
            allowAiSummary = rightsMode != ContentRightsMode.HEADLINE_AND_LINK,
            allowAudioTts = rightsMode != ContentRightsMode.HEADLINE_AND_LINK,
            status = ArticleStatus.PUBLISHED.name,
            clusterId = null,
            editorialPriority = 85,
            manualLeadOverride = false,
            rankingScore = 85.0,
            rankingExplanation = "Manual Editorial Entry (+85)",
            slotRole = "STANDARD",
        )
        dao.upsertArticle(article)
        dao.insertArticleVersion(
            ArticleVersionEntity(
                articleId = articleId,
                versionNumber = 1,
                title = cleanTitle,
                standfirst = cleanStandfirst,
                contentHash = fingerprint,
                recordedAtMs = nowMs,
                changeNote = "Manually curated editorial entry.",
            )
        )
        dao.insertAuditLog(
            AuditLogEntity(
                actorRole = "Administrator",
                actionType = "MANUAL_ENTRY_CREATED",
                targetId = articleId,
                summary = "Published curated entry '$cleanTitle' in ${section.label}.",
                createdAtMs = nowMs,
            )
        )
        return Result.success(article)
    }

    suspend fun setLeadStoryOverride(articleId: String, venueConfig: VenueConfig) {
        val nowMs = System.currentTimeMillis()
        dao.clearManualLeadOverrides()
        dao.setManualLeadOverride(articleId)
        val currentPlacement = dao.observeDefaultPlacement().first()
        dao.upsertPlacement(
            EditorialPlacementEntity(
                id = "default",
                section = NewsSection.FRONT_PAGE.name,
                leadArticleId = articleId,
                sectionOrderCsv = currentPlacement?.sectionOrderCsv
                    ?: NewsSection.entries.joinToString(",") { it.name },
                placedBy = "Administrator",
                placedAtMs = nowMs,
            )
        )
        val allFeeds = dao.getAllFeedSourcesOnce()
        val healthMap = allFeeds.associate {
            it.id to (SourceHealthStatus.entries.firstOrNull { h -> h.name == it.healthStatus }
                ?: SourceHealthStatus.HEALTHY)
        }
        dao.insertArticles(RankingEngine.rerankEdition(dao.getAllArticlesOnce(), venueConfig, healthMap))
        dao.insertAuditLog(
            AuditLogEntity(
                actorRole = "Administrator",
                actionType = "LEAD_OVERRIDE",
                targetId = articleId,
                summary = "Set manual front-page lead story to $articleId.",
                createdAtMs = nowMs,
            )
        )
    }

    suspend fun updateSectionOrder(orderedSections: List<NewsSection>) {
        val nowMs = System.currentTimeMillis()
        val current = dao.observeDefaultPlacement().first()
        dao.upsertPlacement(
            EditorialPlacementEntity(
                id = "default",
                section = NewsSection.FRONT_PAGE.name,
                leadArticleId = current?.leadArticleId,
                sectionOrderCsv = orderedSections.joinToString(",") { it.name },
                placedBy = "Administrator",
                placedAtMs = nowMs,
            )
        )
        dao.insertAuditLog(
            AuditLogEntity(
                actorRole = "Administrator",
                actionType = "SECTION_ORDER_CHANGED",
                targetId = "navigation",
                summary = "Reordered sections: ${orderedSections.joinToString(" | ") { it.label }}",
                createdAtMs = nowMs,
            )
        )
    }

    suspend fun captureEditionSnapshot(venueConfig: VenueConfig, label: String) {
        val nowMs = System.currentTimeMillis()
        val articles = dao.getAllArticlesOnce().filter { it.status != ArticleStatus.WITHDRAWN.name }
        val sorted = articles.sortedByDescending { it.rankingScore }
        val leadId = sorted.firstOrNull { it.manualLeadOverride }?.id ?: sorted.firstOrNull()?.id ?: ""
        val placement = dao.observeDefaultPlacement().first()
        dao.insertEditionSnapshot(
            EditionSnapshotEntity(
                id = "snap_${UUID.randomUUID().toString().take(8)}",
                editionLabel = label.ifBlank { "Snapshot ${com.example.data.model.formatTimeShort(nowMs)}" },
                venueName = venueConfig.venueName,
                cityOrRegion = venueConfig.defaultCityOrRegion,
                builtAtMs = nowMs,
                leadArticleId = leadId,
                rankedArticleIdsCsv = sorted.take(12).joinToString(",") { it.id },
                sectionOrderCsv = placement?.sectionOrderCsv ?: NewsSection.entries.joinToString(",") { it.name },
                notes = "Captured by Administrator for reproducible edition audit.",
            )
        )
        dao.insertAuditLog(
            AuditLogEntity(
                actorRole = "Administrator",
                actionType = "EDITION_SNAPSHOT",
                targetId = leadId,
                summary = "Saved reproducible front-page snapshot '$label'.",
                createdAtMs = nowMs,
            )
        )
    }

    suspend fun mergeClusters(sourceClusterId: String, targetClusterId: String) {
        if (sourceClusterId == targetClusterId) return
        val nowMs = System.currentTimeMillis()
        dao.reassignArticlesCluster(sourceClusterId, targetClusterId)
        dao.deleteCluster(sourceClusterId)
        dao.insertAuditLog(
            AuditLogEntity(
                actorRole = "Administrator",
                actionType = "CLUSTER_MERGED",
                targetId = targetClusterId,
                summary = "Merged cluster $sourceClusterId into $targetClusterId.",
                createdAtMs = nowMs,
            )
        )
    }

    suspend fun splitArticleFromCluster(articleId: String, newTopicLabel: String) {
        val nowMs = System.currentTimeMillis()
        val newClusterId = "cluster_${UUID.randomUUID().toString().take(8)}"
        dao.upsertCluster(
            StoryClusterEntity(
                id = newClusterId,
                topicLabel = HtmlSanitizer.sanitizeSingleLine(newTopicLabel, 90).ifBlank { "Split Topic Cluster" },
                contextNote = "Manually split from an earlier story cluster by editorial desk.",
                updatedAtMs = nowMs,
            )
        )
        dao.assignArticleToCluster(articleId, newClusterId)
        dao.insertAuditLog(
            AuditLogEntity(
                actorRole = "Administrator",
                actionType = "CLUSTER_SPLIT",
                targetId = articleId,
                summary = "Split article $articleId into new cluster '$newTopicLabel'.",
                createdAtMs = nowMs,
            )
        )
    }

    suspend fun withdrawOrRestoreArticle(articleId: String, withdraw: Boolean) {
        val nowMs = System.currentTimeMillis()
        val status = if (withdraw) ArticleStatus.WITHDRAWN.name else ArticleStatus.PUBLISHED.name
        dao.updateArticleStatus(articleId, status)
        dao.insertAuditLog(
            AuditLogEntity(
                actorRole = "Administrator",
                actionType = if (withdraw) "ARTICLE_WITHDRAWN" else "ARTICLE_RESTORED",
                targetId = articleId,
                summary = if (withdraw) "Withdrew article $articleId from public display." else "Restored article $articleId.",
                createdAtMs = nowMs,
            )
        )
    }

    fun filterPermittedSearchResults(
        articles: List<ArticleEntity>,
        query: String,
        section: NewsSection?,
        publisherFilter: String?,
        dateFilter: DateFilterOption,
        languageFilter: String?,
        articleTypeFilter: String?,
        nowMs: Long = System.currentTimeMillis(),
    ): List<ArticleEntity> {
        val q = query.trim().lowercase()
        val cutoffMs = when (dateFilter) {
            DateFilterOption.ALL -> 0L
            DateFilterOption.TODAY -> nowMs - 24 * 3600_000L
            DateFilterOption.LAST_7_DAYS -> nowMs - 7 * 24 * 3600_000L
        }

        return articles.filter { article ->
            if (article.status == ArticleStatus.WITHDRAWN.name) return@filter false
            if (!article.allowSearchIndex) return@filter false
            if (section != null && section != NewsSection.FRONT_PAGE && article.section != section.name) return@filter false
            if (!publisherFilter.isNullOrBlank() && article.publisherName != publisherFilter) return@filter false
            if (article.publishedAtMs < cutoffMs) return@filter false
            if (!languageFilter.isNullOrBlank() && !article.language.equals(languageFilter, ignoreCase = true)) return@filter false
            if (!articleTypeFilter.isNullOrBlank() && !article.articleType.equals(articleTypeFilter, ignoreCase = true)) return@filter false

            if (q.isEmpty()) return@filter true
            val searchableBody = when (article.contentRightsMode) {
                ContentRightsMode.LICENSED_FULL_TEXT.name -> "${article.title} ${article.standfirst} ${article.excerpt} ${article.fullText.orEmpty()} ${article.publisherName}"
                ContentRightsMode.HEADLINE_AND_EXCERPT.name -> "${article.title} ${article.standfirst} ${article.excerpt} ${article.publisherName}"
                else -> "${article.title} ${article.publisherName}"
            }.lowercase()
            searchableBody.contains(q)
        }
    }
}
