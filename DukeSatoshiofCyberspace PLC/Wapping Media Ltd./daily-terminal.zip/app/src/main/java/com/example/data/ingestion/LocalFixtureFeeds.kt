package com.example.data.ingestion

object LocalFixtureFeeds {
    /**
     * Built-in demonstration RSS/Atom feeds allowing offline verification of:
     * 1. Valid RSS/Atom parsing
     * 2. Duplicate entry suppression (repeated GUID / canonical URL)
     * 3. Non-destructive headline updates preserving article version history
     * 4. HTML script/XSS sanitization on untrusted feed descriptions
     */
    fun getFixtureXml(endpointUrl: String): String? {
        return when (endpointUrl) {
            "fixture://civic_review_rss.xml" -> CIVIC_REVIEW_DEMO_RSS
            "fixture://industry_journal_atom.xml" -> INDUSTRY_JOURNAL_DEMO_ATOM
            "fixture://science_ledger_rss.xml" -> SCIENCE_LEDGER_DEMO_RSS
            "fixture://local_journal_rss.xml" -> LOCAL_JOURNAL_DEMO_RSS
            "fixture://world_dispatch_atom.xml" -> WORLD_DISPATCH_DEMO_ATOM
            "fixture://market_ledger_rss.xml" -> MARKET_LEDGER_DEMO_RSS
            "fixture://culture_ledger_rss.xml" -> CULTURE_LEDGER_DEMO_RSS
            "fixture://parliament_digest_rss.xml" -> PARLIAMENT_DIGEST_DEMO_RSS
            else -> null
        }
    }

    val CIVIC_REVIEW_DEMO_RSS = """
        <?xml version="1.0" encoding="UTF-8"?>
        <rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/">
          <channel>
            <title>Civic Review — National &amp; Urban Desk</title>
            <link>https://civicreview.example</link>
            <item>
              <guid>civic-2026-rail-001</guid>
              <title>The next chapter for Britain’s railway cities</title>
              <link>https://civicreview.example/britain/next-chapter-railway-cities?utm_source=rss</link>
              <category>Britain</category>
              <description>How transport, housing and public space could reshape everyday urban life.</description>
            </item>
            <item>
              <guid>civic-2026-rail-001</guid>
              <title>The next chapter for Britain’s railway cities</title>
              <link>https://civicreview.example/britain/next-chapter-railway-cities</link>
              <category>Britain</category>
              <description>How transport, housing and public space could reshape everyday urban life.</description>
            </item>
            <item>
              <guid>civic-2026-lib-012</guid>
              <title>Civic library trusts extend evening reading hours across seven boroughs</title>
              <link>https://civicreview.example/britain/library-trusts-evening-hours</link>
              <category>Britain</category>
              <author>Eleanor Whitmore</author>
              <description><![CDATA[<p>Metropolitan library branches in London, Leeds, Bristol and Sheffield will keep central reading rooms open until 21:00 on weekdays.</p><script>alert('xss')</script>]]></description>
              <content:encoded><![CDATA[<p>Seven metropolitan library trusts confirmed an autumn expansion of quiet evening reading rooms following strong attendance from shift workers, students and older residents.</p><p>Curated morning print terminals and reference desks will remain staff-supported throughout the extended hours, with strict no-tracking public access rules.</p>]]></content:encoded>
            </item>
            <item>
              <guid>civic-2026-ferry-019</guid>
              <title>Regional river ferries pilot integrated rail-and-bus day passes</title>
              <link>https://civicreview.example/britain/river-ferries-integrated-passes</link>
              <category>Britain</category>
              <author>Graham Halstead</author>
              <description><![CDATA[<p>Commuter pier operators along the Thames, Mersey and Clyde are testing single-tap paper and smart tickets linked to morning rail arrivals.</p>]]></description>
              <content:encoded><![CDATA[<p>Commuter pier operators along the Thames, Mersey and Clyde have begun testing integrated day tickets linking early morning regional trains with river crossings.</p><p>Transport researchers noted that clearer interchange signage at riverside stations improved off-peak ridership by fourteen percent during the six-week trial, though weather delays during winter tides remain an operational hurdle.</p>]]></content:encoded>
            </item>
          </channel>
        </rss>
    """.trimIndent()

    val INDUSTRY_JOURNAL_DEMO_ATOM = """
        <?xml version="1.0" encoding="UTF-8"?>
        <feed xmlns="http://www.w3.org/2005/Atom">
          <title>Industry Journal — Energy &amp; Infrastructure</title>
          <entry>
            <id>ind-2026-wind-002</id>
            <title>The changing economics of the North Sea</title>
            <link rel="alternate" href="https://industryjournal.example/business/north-sea-economics" />
            <category term="Business" />
            <summary>Rising vessel costs, grid bottlenecks and port upgrades are reshaping offshore wind finance.</summary>
          </entry>
          <entry>
            <id>ind-2026-grid-021</id>
            <title>Substation transformers face two-year European manufacturing queue</title>
            <link rel="alternate" href="https://industryjournal.example/business/transformer-supply-queue" />
            <category term="Business" />
            <author><name>Graham MacLeod</name></author>
            <summary>Transmission engineers warn copper winding capacity and heavy haulage permits are dictating grid build timelines.</summary>
            <content>Utility planners across Britain and northern Europe report that high-voltage autotransformers now carry twenty-four-month delivery schedules. Domestic apprenticeship programmes at Midlands electrical works are expanding to ease testing backlogs before winter grid connections.</content>
          </entry>
        </feed>
    """.trimIndent()

    val SCIENCE_LEDGER_DEMO_RSS = """
        <?xml version="1.0" encoding="UTF-8"?>
        <rss version="2.0">
          <channel>
            <title>Science Ledger</title>
            <item>
              <guid>sci-2026-lab-003</guid>
              <title>Inside the new materials laboratory</title>
              <link>https://scienceledger.example/science/materials-laboratory</link>
              <category>Science</category>
              <description>An open-access cleanroom helps domestic researchers test compound semiconductor wafers.</description>
            </item>
          </channel>
        </rss>
    """.trimIndent()

    val LOCAL_JOURNAL_DEMO_RSS = """
        <?xml version="1.0" encoding="UTF-8"?>
        <rss version="2.0">
          <channel>
            <title>Local Journal</title>
            <item>
              <guid>loc-2026-food-006</guid>
              <title>Food &amp; neighbourhoods</title>
              <link>https://localjournal.example/local/food-and-neighbourhoods</link>
              <category>Local</category>
              <description>The cafés, bakeries and local spots bringing people together.</description>
            </item>
          </channel>
        </rss>
    """.trimIndent()

    val WORLD_DISPATCH_DEMO_ATOM = """
        <?xml version="1.0" encoding="UTF-8"?>
        <feed xmlns="http://www.w3.org/2005/Atom">
          <title>World Dispatch</title>
          <entry>
            <id>wd-2026-rail-007</id>
            <title>European rail hubs offer lessons for British station districts</title>
            <link rel="alternate" href="https://worlddispatch.example/europe/station-district-lessons" />
            <category term="World" />
            <summary>In Utrecht and Basel, unified municipal transport boards hold long-term leasehold stakes in station-adjacent housing.</summary>
          </entry>
        </feed>
    """.trimIndent()

    val MARKET_LEDGER_DEMO_RSS = """
        <?xml version="1.0" encoding="UTF-8"?>
        <rss version="2.0">
          <channel>
            <title>Market Ledger</title>
            <item>
              <guid>ml-2026-rail-008</guid>
              <title>Station-quarter land values draw institutional pension interest</title>
              <link>https://marketledger.example/property/station-quarter-pension-capital</link>
              <category>Business</category>
              <description>Institutional funds assess long-dated municipal leases near upgraded rail interchanges.</description>
            </item>
          </channel>
        </rss>
    """.trimIndent()

    val CULTURE_LEDGER_DEMO_RSS = """
        <?xml version="1.0" encoding="UTF-8"?>
        <rss version="2.0">
          <channel>
            <title>Culture Ledger</title>
            <item>
              <guid>cul-2026-books-005</guid>
              <title>The weekend reading list</title>
              <link>https://cultureledger.example/books/weekend-reading-list</link>
              <category>Culture</category>
              <description>Three new books to savour, from fiction to ideas.</description>
            </item>
          </channel>
        </rss>
    """.trimIndent()

    val PARLIAMENT_DIGEST_DEMO_RSS = """
        <?xml version="1.0" encoding="UTF-8"?>
        <rss version="2.0">
          <channel>
            <title>Parliamentary Digest</title>
            <item>
              <guid>pd-2026-013</guid>
              <title>Committee urges unified rail and bus reliability reporting</title>
              <link>https://parliamentdigest.example/britain/unified-rail-reliability-metrics</link>
              <category>Britain</category>
              <description>Transport committee clerks confirm freight capacity audits will be reviewed when sittings resume.</description>
            </item>
          </channel>
        </rss>
    """.trimIndent()
}
