package com.example.data.ingestion

import android.util.Log
import com.example.data.local.ArticleEntity
import com.example.data.local.ArticleVersionEntity
import com.example.data.local.AuditLogEntity
import com.example.data.local.DailyTerminalDao
import com.example.data.local.FeedSourceEntity
import com.example.data.local.RefreshJobEntity
import com.example.data.local.StoryClusterEntity
import com.example.data.model.ArticleStatus
import com.example.data.model.ContentRightsMode
import com.example.data.model.ImagePermission
import com.example.data.model.NewsSection
import com.example.data.model.SourceAdapterType
import com.example.data.model.SourceHealthStatus
import com.example.data.model.VenueConfig
import com.example.security.FeedUrlValidator
import com.example.security.HtmlSanitizer
import com.example.security.UrlValidationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

private const val TAG = "FeedIngestionService"
private const val MAX_RESPONSE_BYTES = 2 * 1024 * 1024L // 2 MB cap
private const val MAX_REDIRECTS = 3
private const val HOST_RATE_LIMIT_MS = 1500L

data class IngestionBatchSummary(
    val feedsChecked: Int,
    val feedsFailed: Int,
    val newArticlesInserted: Int,
    val articlesUpdated: Int,
    val duplicatesSkipped: Int,
    val notes: List<String>,
)

class FeedIngestionService(
    private val dao: DailyTerminalDao,
) {
    private val lastHostFetchMs = ConcurrentHashMap<String, Long>()

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .followRedirects(false) // Manual redirect validation against SSRF
        .followSslRedirects(false)
        .build()

    suspend fun refreshAllActiveFeeds(venueConfig: VenueConfig): IngestionBatchSummary =
        withContext(Dispatchers.IO) {
            val feeds = dao.getAllFeedSourcesOnce().filter { it.isActive }
            var failed = 0
            var inserted = 0
            var updated = 0
            var deduped = 0
            val notes = mutableListOf<String>()

            for (feed in feeds) {
                val res = ingestSingleFeed(feed)
                if (res.failed) {
                    failed++
                    notes += "${feed.publisherName}: ${res.note}"
                } else {
                    inserted += res.inserted
                    updated += res.updated
                    deduped += res.deduplicated
                    if (res.inserted > 0 || res.updated > 0) {
                        notes += "${feed.publisherName}: +${res.inserted} new, ${res.updated} updated, ${res.deduplicated} deduped"
                    }
                }
            }

            // Recompute explainable rankings after ingestion
            val allFeeds = dao.getAllFeedSourcesOnce()
            val healthMap = allFeeds.associate {
                it.id to (SourceHealthStatus.entries.firstOrNull { h -> h.name == it.healthStatus }
                    ?: SourceHealthStatus.HEALTHY)
            }
            val reranked = RankingEngine.rerankEdition(
                articles = dao.getAllArticlesOnce(),
                venueConfig = venueConfig,
                feedHealthMap = healthMap,
            )
            dao.insertArticles(reranked)

            IngestionBatchSummary(
                feedsChecked = feeds.size,
                feedsFailed = failed,
                newArticlesInserted = inserted,
                articlesUpdated = updated,
                duplicatesSkipped = deduped,
                notes = notes,
            )
        }

    data class SingleFeedResult(
        val inserted: Int = 0,
        val updated: Int = 0,
        val deduplicated: Int = 0,
        val failed: Boolean = false,
        val note: String = "",
    )

    suspend fun ingestSingleFeed(feed: FeedSourceEntity): SingleFeedResult = withContext(Dispatchers.IO) {
        val startedMs = System.currentTimeMillis()
        if (feed.adapterType == SourceAdapterType.MANUAL_CURATION.name) {
            dao.insertRefreshJob(
                RefreshJobEntity(
                    feedId = feed.id,
                    feedName = feed.feedName,
                    startedAtMs = startedMs,
                    finishedAtMs = System.currentTimeMillis(),
                    status = "SUCCESS",
                    itemsFetched = 0,
                    itemsDeduplicated = 0,
                    itemsUpdated = 0,
                    errorMessage = null,
                )
            )
            return@withContext SingleFeedResult(note = "Manual curation feed unchanged.")
        }

        val xmlPayload: String?
        var newEtag = feed.etag
        var newLastModified = feed.lastModifiedHeader

        if (feed.endpointUrl.startsWith("fixture://")) {
            xmlPayload = LocalFixtureFeeds.getFixtureXml(feed.endpointUrl)
            if (xmlPayload == null) {
                return@withContext recordFailure(feed, startedMs, "Local fixture not found.")
            }
        } else {
            val fetchResult = fetchRemoteWithRetries(feed)
            when (fetchResult) {
                is RemoteFetchResult.NotModified -> {
                    val nowMs = System.currentTimeMillis()
                    dao.upsertFeedSource(
                        feed.copy(
                            healthStatus = SourceHealthStatus.HEALTHY.name,
                            lastSuccessfulRefreshMs = nowMs,
                            lastAttemptMs = nowMs,
                            lastError = null,
                        )
                    )
                    dao.insertRefreshJob(
                        RefreshJobEntity(
                            feedId = feed.id,
                            feedName = feed.feedName,
                            startedAtMs = startedMs,
                            finishedAtMs = nowMs,
                            status = "NOT_MODIFIED",
                            itemsFetched = 0,
                            itemsDeduplicated = 0,
                            itemsUpdated = 0,
                            errorMessage = null,
                        )
                    )
                    return@withContext SingleFeedResult(note = "304 Not Modified")
                }
                is RemoteFetchResult.Error -> {
                    return@withContext recordFailure(feed, startedMs, fetchResult.reason)
                }
                is RemoteFetchResult.Success -> {
                    xmlPayload = fetchResult.body
                    newEtag = fetchResult.etag ?: feed.etag
                    newLastModified = fetchResult.lastModified ?: feed.lastModifiedHeader
                }
            }
        }

        val parsed = FeedParser.parseXml(xmlPayload, startedMs)
        if (parsed is FeedParseOutcome.Failure) {
            return@withContext recordFailure(feed, startedMs, parsed.reason)
        }
        val items = (parsed as FeedParseOutcome.Success).items

        var inserted = 0
        var updated = 0
        var deduplicated = 0

        for (item in items) {
            val outcome = upsertParsedItemWithDedupAndHistory(feed, item, startedMs)
            when (outcome) {
                UpsertOutcome.INSERTED -> inserted++
                UpsertOutcome.UPDATED -> updated++
                UpsertOutcome.DEDUPLICATED -> deduplicated++
            }
        }

        val finishedMs = System.currentTimeMillis()
        val isStaleFixture = feed.id == "feed_parliament_digest"
        dao.upsertFeedSource(
            feed.copy(
                healthStatus = if (isStaleFixture) SourceHealthStatus.STALE.name else SourceHealthStatus.HEALTHY.name,
                lastSuccessfulRefreshMs = if (isStaleFixture) feed.lastSuccessfulRefreshMs else finishedMs,
                lastAttemptMs = finishedMs,
                lastError = if (isStaleFixture) feed.lastError else null,
                etag = newEtag,
                lastModifiedHeader = newLastModified,
            )
        )
        dao.insertRefreshJob(
            RefreshJobEntity(
                feedId = feed.id,
                feedName = feed.feedName,
                startedAtMs = startedMs,
                finishedAtMs = finishedMs,
                status = "SUCCESS",
                itemsFetched = items.size,
                itemsDeduplicated = deduplicated,
                itemsUpdated = updated,
                errorMessage = null,
            )
        )
        if (inserted > 0 || updated > 0) {
            dao.insertAuditLog(
                AuditLogEntity(
                    actorRole = "Ingestion Worker",
                    actionType = "FEED_INGESTED",
                    targetId = feed.id,
                    summary = "${feed.publisherName}: +$inserted new, $updated updated, $deduplicated deduplicated (${parsed.feedFormat}).",
                    createdAtMs = finishedMs,
                )
            )
        }
        SingleFeedResult(inserted = inserted, updated = updated, deduplicated = deduplicated, note = "OK")
    }

    private enum class UpsertOutcome { INSERTED, UPDATED, DEDUPLICATED }

    private suspend fun upsertParsedItemWithDedupAndHistory(
        feed: FeedSourceEntity,
        item: ParsedFeedItem,
        nowMs: Long,
    ): UpsertOutcome {
        val fingerprint = HtmlSanitizer.computeSha256Hex(
            item.title,
            item.excerpt.take(180),
        )

        // Enforce source content permissions strictly on ingestion
        val rights = ContentRightsMode.entries.firstOrNull { it.name == feed.contentRightsMode }
            ?: ContentRightsMode.HEADLINE_AND_LINK
        val permittedExcerpt = when (rights) {
            ContentRightsMode.HEADLINE_AND_LINK -> "Publisher permissions restrict this feed to headline and canonical source link only."
            ContentRightsMode.HEADLINE_AND_EXCERPT -> item.excerpt
            ContentRightsMode.LICENSED_FULL_TEXT -> item.excerpt
        }
        val permittedFullText = if (rights == ContentRightsMode.LICENSED_FULL_TEXT) {
            item.bodyText ?: item.excerpt
        } else {
            null
        }
        val permittedRemoteImg = if (feed.imagePermission == ImagePermission.PERMITTED.name) {
            item.imageUrl
        } else {
            null
        }

        // Check deduplication across sourceGuid, canonicalUrl, and contentFingerprint
        val existing = dao.findBySourceGuid(item.sourceGuid)
            ?: dao.findByCanonicalUrl(item.canonicalUrl)
            ?: dao.findByFingerprint(fingerprint)

        if (existing != null) {
            val titleChanged = existing.title != item.title
            val hasRicherNewBody = !permittedFullText.isNullOrBlank() &&
                permittedFullText.length > (existing.fullText?.length ?: 0) + 40
            val contentChanged = existing.contentFingerprint != fingerprint && hasRicherNewBody
            if (titleChanged || contentChanged) {
                val nextVersion = (dao.getLatestVersionNumber(existing.id) ?: 1) + 1
                dao.insertArticleVersion(
                    ArticleVersionEntity(
                        articleId = existing.id,
                        versionNumber = nextVersion,
                        title = item.title,
                        standfirst = item.standfirst,
                        contentHash = fingerprint,
                        recordedAtMs = nowMs,
                        changeNote = "Feed update detected from ${feed.publisherName}; prior version preserved.",
                    )
                )
                dao.upsertArticle(
                    existing.copy(
                        title = item.title,
                        standfirst = item.standfirst,
                        excerpt = permittedExcerpt,
                        fullText = permittedFullText ?: existing.fullText,
                        contentFingerprint = fingerprint,
                        modifiedAtMs = item.updatedAtMs ?: nowMs,
                        retrievedAtMs = nowMs,
                        status = ArticleStatus.UPDATED.name,
                    )
                )
                return UpsertOutcome.UPDATED
            }
            return UpsertOutcome.DEDUPLICATED
        }

        val mappedSection = mapSection(item.categoryHint, feed.enabledSectionsCsv)
        val clusterId = findOrCreateClusterForTitle(item.title, nowMs)
        val articleId = "art_${UUID.randomUUID().toString().take(8)}"
        val newArticle = ArticleEntity(
            id = articleId,
            sourceFeedId = feed.id,
            publisherId = feed.publisherId,
            publisherName = feed.publisherName,
            canonicalUrl = item.canonicalUrl,
            sourceGuid = item.sourceGuid,
            contentFingerprint = fingerprint,
            title = item.title,
            standfirst = item.standfirst,
            excerpt = permittedExcerpt,
            fullText = permittedFullText,
            author = item.author,
            articleType = item.articleType,
            section = mappedSection.name,
            language = feed.language,
            region = feed.region,
            isLocallyRelevant = mappedSection == NewsSection.LOCAL || feed.region.equals("London", ignoreCase = true),
            isLocalOutlet = feed.id == "feed_local_journal",
            publishedAtMs = item.publishedAtMs,
            modifiedAtMs = item.updatedAtMs,
            ingestedAtMs = nowMs,
            retrievedAtMs = nowMs,
            contentRightsMode = rights.name,
            imagePermission = feed.imagePermission,
            localDrawableName = null,
            remoteImageUrl = permittedRemoteImg,
            imageAttribution = if (permittedRemoteImg != null) feed.publisherName else null,
            allowCache = feed.allowCache,
            allowSearchIndex = feed.allowSearchIndex,
            allowAiSummary = feed.allowAiSummary && rights != ContentRightsMode.HEADLINE_AND_LINK,
            allowAudioTts = feed.allowAudioTts && rights != ContentRightsMode.HEADLINE_AND_LINK,
            status = ArticleStatus.PUBLISHED.name,
            clusterId = clusterId,
            editorialPriority = 75,
            manualLeadOverride = false,
            rankingScore = 75.0,
            rankingExplanation = "Freshly ingested from ${feed.publisherName}",
            slotRole = "STANDARD",
        )
        dao.upsertArticle(newArticle)
        dao.insertArticleVersion(
            ArticleVersionEntity(
                articleId = articleId,
                versionNumber = 1,
                title = newArticle.title,
                standfirst = newArticle.standfirst,
                contentHash = fingerprint,
                recordedAtMs = nowMs,
                changeNote = "Initial ingestion from ${feed.feedName}.",
            )
        )
        return UpsertOutcome.INSERTED
    }

    private suspend fun findOrCreateClusterForTitle(title: String, nowMs: Long): String? {
        val lower = title.lowercase()
        val existingClusters = dao.getAllClustersOnce()
        val matched = when {
            lower.contains("rail") || lower.contains("ferr") || lower.contains("station") || lower.contains("transport") ->
                existingClusters.firstOrNull { it.id == "cluster_railways" }
            lower.contains("wind") || lower.contains("north sea") || lower.contains("grid") || lower.contains("transformer") ->
                existingClusters.firstOrNull { it.id == "cluster_north_sea" }
            lower.contains("wafer") || lower.contains("semiconductor") || lower.contains("laboratory") ->
                existingClusters.firstOrNull { it.id == "cluster_materials" }
            lower.contains("library") || lower.contains("bakery") || lower.contains("neighbourhood") ->
                existingClusters.firstOrNull { it.id == "cluster_urban_highstreet" }
            else -> null
        }
        if (matched != null) return matched.id

        // Check keyword overlap with existing cluster topic labels
        val words = lower.split(Regex("""\W+""")).filter { it.length >= 5 }.toSet()
        for (cluster in existingClusters) {
            val clusterWords = cluster.topicLabel.lowercase().split(Regex("""\W+""")).filter { it.length >= 5 }.toSet()
            if (words.intersect(clusterWords).size >= 2) return cluster.id
        }

        val newId = "cluster_${UUID.randomUUID().toString().take(8)}"
        dao.upsertCluster(
            StoryClusterEntity(
                id = newId,
                topicLabel = title.take(60),
                contextNote = "Automatically grouped topic cluster; available for editorial merge/split.",
                updatedAtMs = nowMs,
            )
        )
        return newId
    }

    private fun mapSection(hint: String?, enabledCsv: String): NewsSection {
        if (!hint.isNullOrBlank()) {
            val found = NewsSection.entries.firstOrNull {
                it.label.equals(hint.trim(), ignoreCase = true) ||
                    it.name.equals(hint.trim(), ignoreCase = true)
            }
            if (found != null) return found
        }
        val firstEnabled = enabledCsv.split(",").firstOrNull()?.trim()
        return NewsSection.entries.firstOrNull { it.name == firstEnabled } ?: NewsSection.BRITAIN
    }

    private sealed class RemoteFetchResult {
        data class Success(val body: String, val etag: String?, val lastModified: String?) : RemoteFetchResult()
        data object NotModified : RemoteFetchResult()
        data class Error(val reason: String) : RemoteFetchResult()
    }

    private suspend fun fetchRemoteWithRetries(feed: FeedSourceEntity): RemoteFetchResult {
        var currentUrl = feed.endpointUrl
        var redirects = 0
        var lastError = "Request failed."

        for (attempt in 0..2) {
            if (attempt > 0) delay(500L * attempt)
            when (val validation = FeedUrlValidator.validateRemoteFeedUrl(currentUrl, resolveDns = true)) {
                is UrlValidationResult.Rejected -> {
                    Log.w(TAG, "Blocked unsafe feed URL ${FeedUrlValidator.redactUrlForLogs(currentUrl)}: ${validation.reason}")
                    return RemoteFetchResult.Error(validation.reason)
                }
                is UrlValidationResult.Valid -> {
                    // Per-host rate limit
                    val now = System.currentTimeMillis()
                    val last = lastHostFetchMs[validation.host] ?: 0L
                    val waitMs = HOST_RATE_LIMIT_MS - (now - last)
                    if (waitMs > 0) delay(waitMs)
                    lastHostFetchMs[validation.host] = System.currentTimeMillis()

                    val reqBuilder = Request.Builder()
                        .url(currentUrl)
                        .header("User-Agent", "TheDailyTerminal/1.0 (+shared-reading-kiosk)")
                        .header("Accept", "application/rss+xml, application/atom+xml, application/xml, text/xml")
                    feed.etag?.let { reqBuilder.header("If-None-Match", it) }
                    feed.lastModifiedHeader?.let { reqBuilder.header("If-Modified-Since", it) }

                    try {
                        okHttpClient.newCall(reqBuilder.build()).execute().use { response ->
                            if (response.code == 304) {
                                return RemoteFetchResult.NotModified
                            }
                            if (response.code in 300..399) {
                                val location = response.header("Location")
                                if (location.isNullOrBlank() || redirects >= MAX_REDIRECTS) {
                                    return RemoteFetchResult.Error("Redirect limit exceeded or missing Location header.")
                                }
                                redirects++
                                currentUrl = location
                                return@use
                            }
                            if (!response.isSuccessful) {
                                lastError = "HTTP ${response.code} ${response.message}"
                                if (response.code in 400..499 && response.code != 429) {
                                    return RemoteFetchResult.Error(lastError)
                                }
                            } else {
                                val body = response.body ?: return RemoteFetchResult.Error("Empty response body.")
                                val contentLength = body.contentLength()
                                if (contentLength > MAX_RESPONSE_BYTES) {
                                    return RemoteFetchResult.Error("Feed payload exceeded 2 MB safety limit.")
                                }
                                val text = body.string()
                                if (text.toByteArray(Charsets.UTF_8).size > MAX_RESPONSE_BYTES) {
                                    return RemoteFetchResult.Error("Feed payload exceeded 2 MB safety limit.")
                                }
                                return RemoteFetchResult.Success(
                                    body = text,
                                    etag = response.header("ETag"),
                                    lastModified = response.header("Last-Modified"),
                                )
                            }
                        }
                    } catch (e: IOException) {
                        lastError = "Network error: ${e.message ?: "timeout"}"
                        Log.w(TAG, "Attempt ${attempt + 1} failed for ${FeedUrlValidator.redactUrlForLogs(currentUrl)}: $lastError")
                    }
                }
            }
        }
        return RemoteFetchResult.Error(lastError)
    }

    private suspend fun recordFailure(
        feed: FeedSourceEntity,
        startedMs: Long,
        reason: String,
    ): SingleFeedResult {
        val nowMs = System.currentTimeMillis()
        dao.upsertFeedSource(
            feed.copy(
                healthStatus = SourceHealthStatus.UNAVAILABLE.name,
                lastAttemptMs = nowMs,
                lastError = reason,
            )
        )
        dao.insertRefreshJob(
            RefreshJobEntity(
                feedId = feed.id,
                feedName = feed.feedName,
                startedAtMs = startedMs,
                finishedAtMs = nowMs,
                status = "FAILED",
                itemsFetched = 0,
                itemsDeduplicated = 0,
                itemsUpdated = 0,
                errorMessage = reason,
            )
        )
        dao.insertAuditLog(
            AuditLogEntity(
                actorRole = "Ingestion Worker",
                actionType = "SOURCE_REFRESH_FAILED",
                targetId = feed.id,
                summary = "${feed.publisherName} failed: $reason",
                createdAtMs = nowMs,
            )
        )
        return SingleFeedResult(failed = true, note = reason)
    }
}
