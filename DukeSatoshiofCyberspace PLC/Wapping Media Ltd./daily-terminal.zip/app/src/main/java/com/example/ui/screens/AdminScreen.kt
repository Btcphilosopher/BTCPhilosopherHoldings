package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.ArticleEntity
import com.example.data.local.AuditLogEntity
import com.example.data.local.EditionSnapshotEntity
import com.example.data.local.FeedSourceEntity
import com.example.data.local.RefreshJobEntity
import com.example.data.model.ArticleStatus
import com.example.data.model.ContentRightsMode
import com.example.data.model.ImagePermission
import com.example.data.model.NewsSection
import com.example.data.model.SourceAdapterType
import com.example.data.model.SourceHealthStatus
import com.example.data.model.VenueConfig
import com.example.data.model.formatDateTimeEdition
import com.example.ui.components.NewspaperRule
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmberNotice
import com.example.ui.theme.AmberTint
import com.example.ui.theme.CreamPaper
import com.example.ui.theme.DeepInk
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.ForestGreenTint
import com.example.ui.theme.NewsprintInset
import com.example.ui.theme.NewsprintRule
import com.example.ui.theme.OxbloodRed
import com.example.ui.theme.OxbloodTint
import com.example.ui.theme.SlateInk

@Composable
fun AdminScreen(
    feedSources: List<FeedSourceEntity>,
    articles: List<ArticleEntity>,
    refreshJobs: List<RefreshJobEntity>,
    snapshots: List<EditionSnapshotEntity>,
    auditLogs: List<AuditLogEntity>,
    orderedSections: List<NewsSection>,
    venueConfig: VenueConfig,
    onImportFixture: () -> Unit,
    onRefreshAll: () -> Unit,
    onAddFeed: (
        publisherName: String,
        feedName: String,
        endpointUrl: String,
        adapterType: SourceAdapterType,
        section: NewsSection,
        rightsMode: ContentRightsMode,
        imagePerm: ImagePermission,
        allowAi: Boolean,
        allowAudio: Boolean,
        onResult: (Result<FeedSourceEntity>) -> Unit,
    ) -> Unit,
    onAddManualEntry: (
        title: String,
        standfirst: String,
        body: String,
        publisher: String,
        section: NewsSection,
        rightsMode: ContentRightsMode,
        onResult: (Result<ArticleEntity>) -> Unit,
    ) -> Unit,
    onSetLeadOverride: (String) -> Unit,
    onWithdrawOrRestore: (String, Boolean) -> Unit,
    onMoveSectionEarlier: (NewsSection) -> Unit,
    onCaptureSnapshot: (String) -> Unit,
    onUpdateVenueConfig: (VenueConfig) -> Unit,
    onLockAndExit: () -> Unit,
    onBack: () -> Unit,
) {
    BackHandler { onBack() }
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Sources", "Editorial", "Venue", "Audit")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(modifier = Modifier.widthIn(max = 900.dp).fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DeepInk)
                    Spacer(Modifier.width(6.dp))
                    Text("Back to edition", color = DeepInk)
                }
                OutlinedButton(
                    onClick = onLockAndExit,
                    border = BorderStroke(1.dp, OxbloodRed),
                    modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = OxbloodRed, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Lock Admin", color = OxbloodRed)
                }
            }

            Text("Newsroom Administration", style = MaterialTheme.typography.displayMedium, color = DeepInk)
            Spacer(Modifier.height(8.dp))

            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = CreamPaper,
                contentColor = ForestGreen,
            ) {
                tabs.forEachIndexed { idx, title ->
                    Tab(
                        selected = selectedTab == idx,
                        onClick = { selectedTab = idx },
                        text = { Text(title, style = MaterialTheme.typography.labelLarge) },
                    )
                }
            }
            Spacer(Modifier.height(14.dp))

            when (selectedTab) {
                0 -> AdminSourcesTab(
                    feedSources = feedSources,
                    refreshJobs = refreshJobs,
                    onImportFixture = onImportFixture,
                    onRefreshAll = onRefreshAll,
                    onAddFeed = onAddFeed,
                )
                1 -> AdminEditorialTab(
                    articles = articles,
                    orderedSections = orderedSections,
                    snapshots = snapshots,
                    onAddManualEntry = onAddManualEntry,
                    onSetLeadOverride = onSetLeadOverride,
                    onWithdrawOrRestore = onWithdrawOrRestore,
                    onMoveSectionEarlier = onMoveSectionEarlier,
                    onCaptureSnapshot = onCaptureSnapshot,
                )
                2 -> AdminVenueTab(
                    venueConfig = venueConfig,
                    onSave = onUpdateVenueConfig,
                )
                3 -> AdminAuditTab(auditLogs = auditLogs)
            }
        }
    }
}

@Composable
private fun AdminSourcesTab(
    feedSources: List<FeedSourceEntity>,
    refreshJobs: List<RefreshJobEntity>,
    onImportFixture: () -> Unit,
    onRefreshAll: () -> Unit,
    onAddFeed: (
        String, String, String, SourceAdapterType, NewsSection,
        ContentRightsMode, ImagePermission, Boolean, Boolean,
        (Result<FeedSourceEntity>) -> Unit,
    ) -> Unit,
) {
    var pubName by remember { mutableStateOf("") }
    var feedName by remember { mutableStateOf("") }
    var endpoint by remember { mutableStateOf("") }
    var adapter by remember { mutableStateOf(SourceAdapterType.RSS) }
    var rights by remember { mutableStateOf(ContentRightsMode.HEADLINE_AND_EXCERPT) }
    var imagePerm by remember { mutableStateOf(ImagePermission.RESTRICTED_OMIT) }
    var allowAi by remember { mutableStateOf(false) }
    var allowAudio by remember { mutableStateOf(false) }
    var feedback by remember { mutableStateOf<String?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onImportFixture,
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen, contentColor = CreamPaper),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("admin_import_fixture_button"),
            ) {
                Text("Import Fixture Feed (Dedup Demo)")
            }
            OutlinedButton(
                onClick = onRefreshAll,
                modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Refresh All Feeds")
            }
        }

        Surface(
            color = CreamPaper,
            border = BorderStroke(1.dp, NewsprintRule),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Configure Live or Fixture Feed Source", style = MaterialTheme.typography.headlineMedium, color = DeepInk)
                OutlinedTextField(
                    value = pubName,
                    onValueChange = { pubName = it },
                    label = { Text("Publisher Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = feedName,
                    onValueChange = { feedName = it },
                    label = { Text("Feed Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = endpoint,
                    onValueChange = { endpoint = it },
                    label = { Text("HTTPS Endpoint URL (private IPs & HTTP blocked)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("admin_feed_url_input"),
                )
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(SourceAdapterType.RSS, SourceAdapterType.ATOM, SourceAdapterType.LICENSED_API).forEach { a ->
                        FilterChip(selected = adapter == a, onClick = { adapter = a }, label = { Text(a.label) })
                    }
                }
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ContentRightsMode.entries.forEach { r ->
                        FilterChip(selected = rights == r, onClick = { rights = r }, label = { Text(r.badge) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = imagePerm == ImagePermission.PERMITTED, onCheckedChange = {
                        imagePerm = if (it) ImagePermission.PERMITTED else ImagePermission.RESTRICTED_OMIT
                    })
                    Text("Images Permitted", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.width(12.dp))
                    Checkbox(checked = allowAi, onCheckedChange = { allowAi = it })
                    Text("Allow AI Summary", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.width(12.dp))
                    Checkbox(checked = allowAudio, onCheckedChange = { allowAudio = it })
                    Text("Allow Audio TTS", style = MaterialTheme.typography.bodySmall)
                }
                feedback?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = OxbloodRed)
                }
                Button(
                    onClick = {
                        onAddFeed(
                            pubName, feedName, endpoint, adapter, NewsSection.WORLD,
                            rights, imagePerm, allowAi, allowAudio
                        ) { res ->
                            feedback = res.fold(
                                onSuccess = {
                                    pubName = ""
                                    feedName = ""
                                    endpoint = ""
                                    "Saved feed '${it.feedName}'."
                                },
                                onFailure = { err -> err.message ?: "Validation rejected URL." }
                            )
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("admin_save_feed_button"),
                ) {
                    Text("Add Feed Source")
                }
            }
        }

        Text("Feed Health & Permissions (${feedSources.size})", style = MaterialTheme.typography.headlineMedium, color = DeepInk)
        feedSources.forEach { f ->
            val bg = when (f.healthStatus) {
                SourceHealthStatus.UNAVAILABLE.name -> OxbloodTint
                SourceHealthStatus.STALE.name -> AmberTint
                else -> ForestGreenTint
            }
            val fg = when (f.healthStatus) {
                SourceHealthStatus.UNAVAILABLE.name -> OxbloodRed
                SourceHealthStatus.STALE.name -> AmberNotice
                else -> ForestGreen
            }
            Surface(
                color = CreamPaper,
                border = BorderStroke(1.dp, NewsprintRule),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("${f.publisherName} — ${f.feedName}", style = MaterialTheme.typography.titleMedium, color = DeepInk, modifier = Modifier.weight(1f))
                        StatusPill(f.healthStatus, bg, fg)
                    }
                    Text(
                        text = "${f.adapterType} • Rights: ${f.contentRightsMode} • Last OK: ${formatDateTimeEdition(f.lastSuccessfulRefreshMs)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = SlateInk,
                    )
                    f.lastError?.let { err ->
                        Text(err, style = MaterialTheme.typography.bodySmall, color = OxbloodRed)
                    }
                }
            }
        }

        if (refreshJobs.isNotEmpty()) {
            Text("Recent Ingestion Jobs", style = MaterialTheme.typography.headlineMedium, color = DeepInk)
            refreshJobs.take(8).forEach { job ->
                Text(
                    text = "${formatDateTimeEdition(job.finishedAtMs)} • ${job.feedName}: ${job.status} (+${job.itemsFetched} fetched, ${job.itemsDeduplicated} deduped)${job.errorMessage?.let { " — $it" } ?: ""}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (job.status == "FAILED") OxbloodRed else SlateInk,
                )
            }
        }
    }
}

@Composable
private fun AdminEditorialTab(
    articles: List<ArticleEntity>,
    orderedSections: List<NewsSection>,
    snapshots: List<EditionSnapshotEntity>,
    onAddManualEntry: (String, String, String, String, NewsSection, ContentRightsMode, (Result<ArticleEntity>) -> Unit) -> Unit,
    onSetLeadOverride: (String) -> Unit,
    onWithdrawOrRestore: (String, Boolean) -> Unit,
    onMoveSectionEarlier: (NewsSection) -> Unit,
    onCaptureSnapshot: (String) -> Unit,
) {
    var title by remember { mutableStateOf("") }
    var standfirst by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var publisher by remember { mutableStateOf("Editorial Desk") }
    var section by remember { mutableStateOf(NewsSection.BRITAIN) }
    var notice by remember { mutableStateOf<String?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Manual Curated Entry
        Surface(
            color = CreamPaper,
            border = BorderStroke(1.dp, NewsprintRule),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Publish Manual Curated Entry", style = MaterialTheme.typography.headlineMedium, color = DeepInk)
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Headline") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = standfirst, onValueChange = { standfirst = it }, label = { Text("Standfirst") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Licensed Editorial Body") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = publisher, onValueChange = { publisher = it }, label = { Text("Publisher Attribution") }, modifier = Modifier.fillMaxWidth())
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NewsSection.entries.filter { it != NewsSection.FRONT_PAGE }.forEach { s ->
                        FilterChip(selected = section == s, onClick = { section = s }, label = { Text(s.label) })
                    }
                }
                notice?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = ForestGreen) }
                Button(
                    onClick = {
                        onAddManualEntry(title, standfirst, body, publisher, section, ContentRightsMode.LICENSED_FULL_TEXT) { res ->
                            notice = res.fold(
                                onSuccess = {
                                    title = ""; standfirst = ""; body = ""
                                    "Published '${it.title}'."
                                },
                                onFailure = { it.message ?: "Error" }
                            )
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                    modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                    Text("Publish Entry")
                }
            }
        }

        // Section Order & Edition Snapshot
        Surface(
            color = CreamPaper,
            border = BorderStroke(1.dp, NewsprintRule),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Section Order & Snapshots", style = MaterialTheme.typography.headlineMedium, color = DeepInk)
                    OutlinedButton(
                        onClick = { onCaptureSnapshot("Edition Snapshot") },
                        modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Save Snapshot")
                    }
                }
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    orderedSections.forEach { sec ->
                        Surface(color = NewsprintInset, border = BorderStroke(1.dp, NewsprintRule), shape = RoundedCornerShape(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                Text(sec.label, style = MaterialTheme.typography.labelSmall)
                                if (sec != NewsSection.FRONT_PAGE && orderedSections.indexOf(sec) > 1) {
                                    TextButton(onClick = { onMoveSectionEarlier(sec) }) {
                                        Icon(Icons.Default.ArrowUpward, contentDescription = "Move earlier", modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                }
                snapshots.take(3).forEach { snap ->
                    Text(
                        text = "${snap.editionLabel} (${formatDateTimeEdition(snap.builtAtMs)}) — Lead: ${snap.leadArticleId}",
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateInk,
                    )
                }
            }
        }

        // Explainable Ranking & Lead Override / Moderation
        Text("Explainable Ranking & Moderation", style = MaterialTheme.typography.headlineMedium, color = DeepInk)
        articles.forEach { art ->
            val isWithdrawn = art.status == ArticleStatus.WITHDRAWN.name
            Surface(
                color = if (isWithdrawn) OxbloodTint else CreamPaper,
                border = BorderStroke(1.dp, NewsprintRule),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("${art.title} (${art.publisherName})", style = MaterialTheme.typography.titleMedium, color = DeepInk, modifier = Modifier.weight(1f))
                        Text("Score ${art.rankingScore}", style = MaterialTheme.typography.labelLarge, color = ForestGreen)
                    }
                    Text(art.rankingExplanation, style = MaterialTheme.typography.labelSmall, color = SlateInk)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { onSetLeadOverride(art.id) },
                            enabled = !art.manualLeadOverride && !isWithdrawn,
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Text(if (art.manualLeadOverride) "Current Lead" else "Set as Lead")
                        }
                        TextButton(
                            onClick = { onWithdrawOrRestore(art.id, !isWithdrawn) },
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Text(if (isWithdrawn) "Restore" else "Withdraw", color = OxbloodRed)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminVenueTab(
    venueConfig: VenueConfig,
    onSave: (VenueConfig) -> Unit,
) {
    var venueName by remember(venueConfig) { mutableStateOf(venueConfig.venueName) }
    var city by remember(venueConfig) { mutableStateOf(venueConfig.defaultCityOrRegion) }
    var kioskMode by remember(venueConfig) { mutableStateOf(venueConfig.kioskModeEnabled) }
    var timeoutSec by remember(venueConfig) { mutableIntStateOf(venueConfig.inactivityTimeoutSeconds) }
    var aiAllowed by remember(venueConfig) { mutableStateOf(venueConfig.aiSummaryAllowedGlobal) }

    Surface(
        color = CreamPaper,
        border = BorderStroke(1.dp, NewsprintRule),
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Shared Terminal & Venue Settings", style = MaterialTheme.typography.headlineMedium, color = DeepInk)
            OutlinedTextField(
                value = venueName,
                onValueChange = { venueName = it },
                label = { Text("Venue Display Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = city,
                onValueChange = { city = it },
                label = { Text("Default City / Region (without GPS)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Coffee-Shop Kiosk Mode", style = MaterialTheme.typography.titleMedium)
                    Text("Enables inactivity reset, 'End session' control, and hides admin button from top bar.", style = MaterialTheme.typography.bodySmall, color = SlateInk)
                }
                Switch(checked = kioskMode, onCheckedChange = { kioskMode = it })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Inactivity Timeout:", style = MaterialTheme.typography.bodyMedium)
                listOf(60, 180, 300, 600).forEach { sec ->
                    FilterChip(
                        selected = timeoutSec == sec,
                        onClick = { timeoutSec = sec },
                        label = { Text("${sec / 60}m") },
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Allow AI Briefing Summaries", style = MaterialTheme.typography.titleMedium)
                    Text("Permits Gemini summarization on sources whose licensing allows AI processing.", style = MaterialTheme.typography.bodySmall, color = SlateInk)
                }
                Switch(checked = aiAllowed, onCheckedChange = { aiAllowed = it })
            }
            Button(
                onClick = {
                    onSave(
                        venueConfig.copy(
                            venueName = venueName,
                            defaultCityOrRegion = city,
                            kioskModeEnabled = kioskMode,
                            inactivityTimeoutSeconds = timeoutSec,
                            aiSummaryAllowedGlobal = aiAllowed,
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
                Text("Save Venue Configuration")
            }
        }
    }
}

@Composable
private fun AdminAuditTab(auditLogs: List<AuditLogEntity>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Immutable Editorial & Security Audit Log", style = MaterialTheme.typography.headlineMedium, color = DeepInk)
        auditLogs.forEach { log ->
            Surface(
                color = CreamPaper,
                border = BorderStroke(1.dp, NewsprintRule),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "${formatDateTimeEdition(log.createdAtMs)} • ${log.actionType} (${log.actorRole})",
                        style = MaterialTheme.typography.labelSmall,
                        color = OxbloodRed,
                    )
                    Text(log.summary, style = MaterialTheme.typography.bodySmall, color = DeepInk)
                }
            }
        }
    }
}
