package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

val MastheadSerifFamily = FontFamily(
    Font(R.font.playfair_display, FontWeight.Normal),
    Font(R.font.playfair_display, FontWeight.SemiBold),
    Font(R.font.playfair_display, FontWeight.Bold),
)

val EditorialSerifFamily = FontFamily(
    Font(R.font.newsreader, FontWeight.Normal),
    Font(R.font.newsreader, FontWeight.Medium),
    Font(R.font.newsreader, FontWeight.SemiBold),
    Font(R.font.newsreader, FontWeight.Bold),
    Font(R.font.newsreader, FontWeight.Normal, FontStyle.Italic),
)

val UtilitySansFamily = FontFamily(
    Font(R.font.ibm_plex_sans, FontWeight.Normal),
    Font(R.font.ibm_plex_sans, FontWeight.Medium),
    Font(R.font.ibm_plex_sans, FontWeight.SemiBold),
    Font(R.font.ibm_plex_sans, FontWeight.Bold),
)

fun buildDailyTerminalTypography(scaleFactor: Float = 1.0f): Typography {
    fun scaled(size: Float) = (size * scaleFactor).sp

    return Typography(
        // Masthead title
        displayLarge = TextStyle(
            fontFamily = MastheadSerifFamily,
            fontWeight = FontWeight.Bold,
            fontSize = scaled(40f),
            lineHeight = scaled(44f),
            letterSpacing = 0.8.sp,
        ),
        // Lead broadsheet headline
        displayMedium = TextStyle(
            fontFamily = MastheadSerifFamily,
            fontWeight = FontWeight.Bold,
            fontSize = scaled(30f),
            lineHeight = scaled(34f),
            letterSpacing = (-0.3).sp,
        ),
        // Secondary headline
        headlineLarge = TextStyle(
            fontFamily = MastheadSerifFamily,
            fontWeight = FontWeight.Bold,
            fontSize = scaled(22f),
            lineHeight = scaled(26f),
            letterSpacing = (-0.2).sp,
        ),
        // Card / column headline
        headlineMedium = TextStyle(
            fontFamily = MastheadSerifFamily,
            fontWeight = FontWeight.Bold,
            fontSize = scaled(18f),
            lineHeight = scaled(22f),
        ),
        // Sub-headline / rail title
        titleLarge = TextStyle(
            fontFamily = EditorialSerifFamily,
            fontWeight = FontWeight.Bold,
            fontSize = scaled(17f),
            lineHeight = scaled(22f),
        ),
        // Sidebar nav / section bar
        titleMedium = TextStyle(
            fontFamily = EditorialSerifFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = scaled(15f),
            lineHeight = scaled(20f),
        ),
        // Standfirst italic / deck
        titleSmall = TextStyle(
            fontFamily = EditorialSerifFamily,
            fontWeight = FontWeight.Normal,
            fontStyle = FontStyle.Italic,
            fontSize = scaled(15f),
            lineHeight = scaled(21f),
        ),
        // Primary reader body text
        bodyLarge = TextStyle(
            fontFamily = EditorialSerifFamily,
            fontWeight = FontWeight.Normal,
            fontSize = scaled(17f),
            lineHeight = scaled(26f),
        ),
        // Card summary / secondary copy
        bodyMedium = TextStyle(
            fontFamily = EditorialSerifFamily,
            fontWeight = FontWeight.Normal,
            fontSize = scaled(14f),
            lineHeight = scaled(20f),
        ),
        // Utility strip / restrained sans metadata
        bodySmall = TextStyle(
            fontFamily = UtilitySansFamily,
            fontWeight = FontWeight.Normal,
            fontSize = scaled(12.5f),
            lineHeight = scaled(17f),
        ),
        // Buttons & navigation chips
        labelLarge = TextStyle(
            fontFamily = UtilitySansFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = scaled(13.5f),
            lineHeight = scaled(18f),
        ),
        // Section kicker labels (THE BIG READ, YOUR EDITION)
        labelMedium = TextStyle(
            fontFamily = UtilitySansFamily,
            fontWeight = FontWeight.Bold,
            fontSize = scaled(11.5f),
            lineHeight = scaled(15f),
            letterSpacing = 0.9.sp,
        ),
        // Fine metadata / timestamps
        labelSmall = TextStyle(
            fontFamily = UtilitySansFamily,
            fontWeight = FontWeight.Medium,
            fontSize = scaled(11f),
            lineHeight = scaled(14f),
            letterSpacing = 0.3.sp,
        ),
    )
}

val Typography = buildDailyTerminalTypography(1.0f)
