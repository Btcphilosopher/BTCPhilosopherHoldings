package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary newsprint & ink palette matching The Daily Terminal broadsheet aesthetic
val WarmIvory = Color(0xFFF6F1E7)
val CreamPaper = Color(0xFFFAF6EE)
val NewsprintInset = Color(0xFFEFE8DA)
val SelectedSidebarBg = Color(0xFFE3DFD3)

val DeepInk = Color(0xFF11181C)
val CharcoalInk = Color(0xFF232B30)
val SlateInk = Color(0xFF4D5559)
val MutedInk = Color(0xFF6B7275)

val NewsprintRule = Color(0xFFCFC6B4)
val StrongRule = Color(0xFF2A3135)

// Editorial accents
val ForestGreen = Color(0xFF154734)
val ForestGreenPressed = Color(0xFF0F3527)
val ForestGreenTint = Color(0xFFE3ECE7)

val OxbloodRed = Color(0xFF7A1E1E)
val OxbloodTint = Color(0xFFF5E6E4)

val AmberNotice = Color(0xFF8A5A10)
val AmberTint = Color(0xFFF6ECD9)
