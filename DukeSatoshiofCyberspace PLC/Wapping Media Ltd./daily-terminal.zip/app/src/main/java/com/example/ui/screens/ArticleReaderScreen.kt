package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.ArticleEntity
import com.example.data.local.ArticleVersionEntity
import com.example.data.model.ArticleStatus
import com.example.data.model.ContentRightsMode
import com.example.data.model.ReadingTimeCalculator
import com.example.data.model.formatDateTimeEdition
import com.example.ui.components.ArticleThumbnailImage
import com.example.ui.components.NewspaperRule
import com.example.ui.components.SaveStoryButton
import com.example.ui.components.SectionKickerHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.CreamPaper
import com.example.ui.theme.DeepInk
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.NewsprintInset
import com.example.ui.theme.NewsprintRule
import com.example.ui.theme.OxbloodRed
import com.example.ui.theme.OxbloodTint
import com.example.ui.theme.SlateInk

@Composable
fun ArticleReaderScreen(
    article: ArticleEntity?,
    versions: List<ArticleVersionEntity>,
    relatedArticles: List<ArticleEntity>,
    isSaved: Boolean,
    onBack: () -> Unit,
    onCycleTextScale: () -> Unit,
    onToggleSave: (String) -> Unit,
    onListenClick: (ArticleEntity) -> Unit,
    onQrHandoffClick: (ArticleEntity) -> Unit,
    onOpenRelatedArticle: (String) -> Unit,
    onOpenCompareCoverage: (String?) -> Unit,
) {
    BackHandler { onBack() }
    val uriHandler = LocalUriHandler.current
    var showVersions by remember { mutableStateOf(false) }

    if (article == null) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Article unavailable", style = MaterialTheme.typography.headlineLarge, color = DeepInk)
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Text("Return to edition")
                }
            }
        }
        return
    }

    val rights = ContentRightsMode.entries.firstOrNull { it.name == article.contentRightsMode }
        ?: ContentRightsMode.HEADLINE_AND_LINK
    val minutes = ReadingTimeCalculator.estimateMinutesOrNull(rights, article.fullText)
    val isWithdrawn = article.status == ArticleStatus.WITHDRAWN.name || article.status == ArticleStatus.UNAVAILABLE.name

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // Reader Action Bar
        Surface(
            color = CreamPaper,
            border = BorderStroke(1.dp, NewsprintRule),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                TextButton(
                    onClick = onBack,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("reader_back_button"),
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to edition", tint = DeepInk)
                    Spacer(Modifier.width(6.dp))
                    Text("Back to edition", style = MaterialTheme.typography.labelLarge, color = DeepInk)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(
                        onClick = onCycleTextScale,
                        modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                        Text("Aa", style = MaterialTheme.typography.labelLarge, color = DeepInk)
                    }
                    OutlinedButton(
                        onClick = { onListenClick(article) },
                        shape = RoundedCornerShape(4.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("reader_listen_button"),
                    ) {
                        Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "Listen to article", modifier = Modifier.size(16.dp), tint = ForestGreen)
                        Spacer(Modifier.width(4.dp))
                        Text("Listen", style = MaterialTheme.typography.labelLarge, color = ForestGreen)
                    }
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton(
                        onClick = { onQrHandoffClick(article) },
                        shape = RoundedCornerShape(4.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("reader_qr_button"),
                    ) {
                        Icon(Icons.Default.QrCode2, contentDescription = "QR handoff to personal device", modifier = Modifier.size(16.dp), tint = DeepInk)
                        Spacer(Modifier.width(4.dp))
                        Text("QR", style = MaterialTheme.typography.labelLarge, color = DeepInk)
                    }
                    Spacer(Modifier.width(6.dp))
                    SaveStoryButton(
                        isSaved = isSaved,
                        onClick = { onToggleSave(article.id) },
                        modifier = Modifier.testTag("reader_save_button"),
                    )
                }
            }
        }

        // Focused Broadsheet Column (maxWidth 720.dp for optimal reading line length)
        Column(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 20.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = article.publisherName.uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    color = OxbloodRed,
                )
                Text("•", color = SlateInk)
                Text(
                    text = article.articleType.uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    color = SlateInk,
                )
                Text("•", color = SlateInk)
                Text(
                    text = if (minutes != null) "$minutes min read" else rights.badge,
                    style = MaterialTheme.typography.labelMedium,
                    color = ForestGreen,
                )
            }

            Spacer(Modifier.height(10.dp))
            Text(
                text = article.title,
                style = MaterialTheme.typography.displayMedium,
                color = DeepInk,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = article.standfirst,
                style = MaterialTheme.typography.titleSmall,
                color = SlateInk,
            )

            Spacer(Modifier.height(12.dp))
            NewspaperRule()
            Spacer(Modifier.height(10.dp))

            // Attribution & Explicit Timestamps (publication, modification, retrieval)
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                if (!article.author.isNullOrBlank()) {
                    Text(
                        text = "By ${article.author} — ${article.publisherName}",
                        style = MaterialTheme.typography.labelLarge,
                        color = DeepInk,
                    )
                } else {
                    Text(
                        text = "Published by ${article.publisherName}",
                        style = MaterialTheme.typography.labelLarge,
                        color = DeepInk,
                    )
                }
                Text(
                    text = buildString {
                        append("Published ${formatDateTimeEdition(article.publishedAtMs)}")
                        article.modifiedAtMs?.let { append("  •  Updated ${formatDateTimeEdition(it)}") }
                        append("  •  Retrieved ${formatDateTimeEdition(article.retrievedAtMs)}")
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateInk,
                )
            }

            Spacer(Modifier.height(14.dp))
            if (article.localDrawableName != null || article.remoteImageUrl != null) {
                ArticleThumbnailImage(
                    article = article,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f),
                )
                article.imageAttribution?.let { attr ->
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Image credit: $attr",
                        style = MaterialTheme.typography.labelSmall,
                        color = SlateInk,
                    )
                }
                Spacer(Modifier.height(14.dp))
            }

            // Content Rights Disclosure & Body Rendering
            if (isWithdrawn) {
                Surface(
                    color = OxbloodTint,
                    border = BorderStroke(1.dp, OxbloodRed),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text = "This article has been withdrawn or marked unavailable by the publisher or editorial desk.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = OxbloodRed,
                        modifier = Modifier.padding(14.dp),
                    )
                }
            } else {
                when (rights) {
                    ContentRightsMode.LICENSED_FULL_TEXT -> {
                        val paragraphs = (article.fullText ?: article.excerpt).split("\n\n")
                        paragraphs.forEach { para ->
                            if (para.isNotBlank()) {
                                Text(
                                    text = para.trim(),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = DeepInk,
                                    modifier = Modifier.padding(bottom = 14.dp),
                                )
                            }
                        }
                    }
                    ContentRightsMode.HEADLINE_AND_EXCERPT -> {
                        Text(
                            text = article.excerpt,
                            style = MaterialTheme.typography.bodyLarge,
                            color = DeepInk,
                            modifier = Modifier.padding(bottom = 14.dp),
                        )
                        RightsNoticeCard(
                            title = "Licensed excerpt only",
                            body = "${article.publisherName} permits headline and summary display on shared terminals. Read the complete article directly at the publisher.",
                            canonicalUrl = article.canonicalUrl,
                            onOpenSource = { runCatching { uriHandler.openUri(article.canonicalUrl) } },
                        )
                    }
                    ContentRightsMode.HEADLINE_AND_LINK -> {
                        RightsNoticeCard(
                            title = "Headline & canonical link only",
                            body = "${article.publisherName} does not syndicate excerpts or full text to third-party terminals. Use the original link below or scan the QR code to read on your device.",
                            canonicalUrl = article.canonicalUrl,
                            onOpenSource = { runCatching { uriHandler.openUri(article.canonicalUrl) } },
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            // Canonical Original-Source Link (always preserved)
            Surface(
                color = CreamPaper,
                border = BorderStroke(1.dp, NewsprintRule),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "ORIGINAL SOURCE ATTRIBUTION",
                            style = MaterialTheme.typography.labelSmall,
                            color = SlateInk,
                        )
                        Text(
                            text = article.canonicalUrl,
                            style = MaterialTheme.typography.bodySmall,
                            color = ForestGreen,
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = { runCatching { uriHandler.openUri(article.canonicalUrl) } },
                        modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Open")
                    }
                }
            }

            // Version History (preserving headline/content updates without overwriting history)
            if (versions.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .clickable { showVersions = !showVersions }
                        .padding(vertical = 6.dp)
                        .testTag("toggle_version_history"),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Default.History, contentDescription = null, tint = SlateInk, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "Article revision history (${versions.size} recorded ${if (versions.size == 1) "version" else "versions"})",
                        style = MaterialTheme.typography.labelLarge,
                        color = DeepInk,
                    )
                }
                AnimatedVisibility(visible = showVersions) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(top = 6.dp),
                    ) {
                        versions.forEach { v ->
                            Surface(
                                color = NewsprintInset,
                                border = BorderStroke(1.dp, NewsprintRule),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = "Revision ${v.versionNumber} • ${formatDateTimeEdition(v.recordedAtMs)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = OxbloodRed,
                                    )
                                    Text(
                                        text = v.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = DeepInk,
                                    )
                                    Text(
                                        text = v.changeNote,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SlateInk,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Related Coverage from Same Cluster
            if (relatedArticles.isNotEmpty()) {
                Spacer(Modifier.height(22.dp))
                SectionKickerHeader(title = "RELATED COVERAGE FROM OTHER PUBLISHERS", accentColor = OxbloodRed)
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "These articles appear to concern the same topic. Grouping does not imply agreement.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SlateInk,
                )
                Spacer(Modifier.height(10.dp))
                relatedArticles.forEach { rel ->
                    Surface(
                        color = CreamPaper,
                        border = BorderStroke(1.dp, NewsprintRule),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .clickable { onOpenRelatedArticle(rel.id) },
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = "${rel.publisherName} • ${rel.articleType}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = ForestGreen,
                                )
                                StatusPill(
                                    text = ContentRightsMode.entries.firstOrNull { it.name == rel.contentRightsMode }?.badge ?: "Link",
                                    bgColor = NewsprintInset,
                                    fgColor = SlateInk,
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = rel.title,
                                style = MaterialTheme.typography.titleLarge,
                                color = DeepInk,
                            )
                            Text(
                                text = "Published ${formatDateTimeEdition(rel.publishedAtMs)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = SlateInk,
                            )
                        }
                    }
                }
                TextButton(
                    onClick = { onOpenCompareCoverage(article.clusterId) },
                    modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                    Text("Compare all perspectives on this topic ->", color = ForestGreen)
                }
            }
        }
    }
}

@Composable
private fun RightsNoticeCard(
    title: String,
    body: String,
    canonicalUrl: String,
    onOpenSource: () -> Unit,
) {
    Surface(
        color = NewsprintInset,
        border = BorderStroke(1.dp, NewsprintRule),
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium, color = OxbloodRed)
            Spacer(Modifier.height(4.dp))
            Text(text = body, style = MaterialTheme.typography.bodyMedium, color = DeepInk)
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = onOpenSource,
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen, contentColor = CreamPaper),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
                Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Read original at publisher")
            }
        }
    }
}
