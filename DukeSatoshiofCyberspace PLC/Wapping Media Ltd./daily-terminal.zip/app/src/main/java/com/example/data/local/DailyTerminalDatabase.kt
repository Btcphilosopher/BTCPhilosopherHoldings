package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        PublisherEntity::class,
        FeedSourceEntity::class,
        ArticleEntity::class,
        ArticleVersionEntity::class,
        StoryClusterEntity::class,
        EditorialPlacementEntity::class,
        EditionSnapshotEntity::class,
        RefreshJobEntity::class,
        SavedItemEntity::class,
        ReadingHistoryEntity::class,
        AuditLogEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class DailyTerminalDatabase : RoomDatabase() {
    abstract fun dao(): DailyTerminalDao

    companion object {
        @Volatile
        private var INSTANCE: DailyTerminalDatabase? = null

        fun getInstance(context: Context): DailyTerminalDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(appContext: Context): DailyTerminalDatabase {
            lateinit var dbInstance: DailyTerminalDatabase
            dbInstance = Room.databaseBuilder(
                appContext,
                DailyTerminalDatabase::class.java,
                "daily_terminal.db",
            )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            seedIfEmpty(dbInstance.dao())
                        }
                    }
                })
                .build()
            return dbInstance
        }

        suspend fun seedIfEmpty(dao: DailyTerminalDao) {
            if (dao.getAllFeedSourcesOnce().isNotEmpty()) return
            val nowMs = System.currentTimeMillis()
            dao.insertPublishers(SeedData.buildSeedPublishers())
            dao.insertFeedSources(SeedData.buildSeedFeeds(nowMs))
            dao.insertClusters(SeedData.buildSeedClusters(nowMs))
            dao.insertArticles(SeedData.buildSeedArticles(nowMs))
            dao.insertArticleVersions(SeedData.buildSeedVersions(nowMs))
            dao.insertRefreshJobs(SeedData.buildSeedRefreshJobs(nowMs))
            dao.upsertPlacement(SeedData.buildSeedPlacements(nowMs))
            SeedData.buildSeedSnapshots(nowMs).forEach { dao.insertEditionSnapshot(it) }
            dao.insertAuditLogs(SeedData.buildSeedAuditLogs(nowMs))
        }
    }
}
