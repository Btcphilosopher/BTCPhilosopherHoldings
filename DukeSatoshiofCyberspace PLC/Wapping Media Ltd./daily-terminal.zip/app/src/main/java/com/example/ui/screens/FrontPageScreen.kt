package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Newspaper
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.automirrored.outlined.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.ArticleEntity
import com.example.data.local.FeedSourceEntity
import com.example.data.local.StoryClusterEntity
import com.example.data.model.ContentRightsMode
import com.example.data.model.NewsSection
import com.example.data.model.ReadingTimeCalculator
import com.example.data.model.SidebarFeedMode
import com.example.data.model.SourceHealthStatus
import com.example.data.model.VenueConfig
import com.example.data.model.formatTimeShort
import com.example.ui.components.ArticleThumbnailImage
import com.example.ui.components.NewspaperRule
import com.example.ui.components.SaveStoryButton
import com.example.ui.components.SectionKickerHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmberNotice
import com.example.ui.theme.AmberTint
import com.example.ui.theme.CreamPaper
import com.example.ui.theme.DeepInk
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.NewsprintInset
import com.example.ui.theme.NewsprintRule
import com.example.ui.theme.OxbloodRed
import com.example.ui.theme.OxbloodTint
import com.example.ui.theme.SelectedSidebarBg
import com.example.ui.theme.SlateInk
import com.example.ui.theme.StrongRule
import com.example.ui.theme.WarmIvory

@Composable
fun FrontPageScreen(
    articles: List<ArticleEntity>,
    feedSources: List<FeedSourceEntity>,
    clusters: List<StoryClusterEntity>,
    selectedSection: NewsSection,
    selectedSidebarMode: SidebarFeedMode,
    savedArticleIds: Set<String>,
    historyArticleIds: List<String>,
    venueConfig: VenueConfig,
    lastRefreshMs: Long,
    onSelectSidebarMode: (SidebarFeedMode) -> Unit,
    onOpenArticle: (String) -> Unit,
    onToggleSave: (String) -> Unit,
    onOpenBriefing: () -> Unit,
    onOpenCompareCoverage: (String?) -> Unit,
    onAdminClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val displayedArticles = remember(
        articles,
        selectedSection,
        selectedSidebarMode,
        savedArticleIds,
        historyArticleIds,
        venueConfig.defaultCityOrRegion,
    ) {
        when (selectedSidebarMode) {
            SidebarFeedMode.SAVED_READING -> articles.filter { it.id in savedArticleIds }
            SidebarFeedMode.READING_HISTORY -> {
                val map = articles.associateBy { it.id }
                historyArticleIds.mapNotNull { map[it] }
            }
            SidebarFeedMode.LATEST_UPDATES -> articles.sortedByDescending { it.modifiedAtMs ?: it.publishedAtMs }
            SidebarFeedMode.LOCAL_BRIEFING -> articles.filter {
                it.section == NewsSection.LOCAL.name || it.isLocallyRelevant || it.isLocalOutlet
            }.sortedByDescending {
                (if (it.region.equals(venueConfig.defaultCityOrRegion, ignoreCase = true)) 20.0 else 0.0) + it.rankingScore
            }
            SidebarFeedMode.TOP_STORIES -> {
                if (selectedSection == NewsSection.FRONT_PAGE) {
                    articles
                } else if (selectedSection == NewsSection.LOCAL) {
                    articles.filter {
                        it.section == NewsSection.LOCAL.name || it.isLocallyRelevant || it.isLocalOutlet
                    }
                } else {
                    articles.filter { it.section == selectedSection.name }
                }
            }
        }
    }

    val unavailableSources = remember(feedSources) {
        feedSources.filter { it.healthStatus == SourceHealthStatus.UNAVAILABLE.name }
    }
    val staleSources = remember(feedSources) {
        feedSources.filter { it.healthStatus == SourceHealthStatus.STALE.name }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isWideBroadsheet = maxWidth >= 840.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
        ) {
            if (isWideBroadsheet) {
                WideBroadsheetBody(
                    allArticles = articles,
                    displayedArticles = displayedArticles,
                    clusters = clusters,
                    unavailableSources = unavailableSources,
                    staleSources = staleSources,
                    selectedSection = selectedSection,
                    selectedSidebarMode = selectedSidebarMode,
                    savedArticleIds = savedArticleIds,
                    venueConfig = venueConfig,
                    lastRefreshMs = lastRefreshMs,
                    onSelectSidebarMode = onSelectSidebarMode,
                    onOpenArticle = onOpenArticle,
                    onToggleSave = onToggleSave,
                    onOpenBriefing = onOpenBriefing,
                    onOpenCompareCoverage = onOpenCompareCoverage,
                )
            } else {
                CompactNewspaperBody(
                    allArticles = articles,
                    displayedArticles = displayedArticles,
                    clusters = clusters,
                    unavailableSources = unavailableSources,
                    staleSources = staleSources,
                    selectedSection = selectedSection,
                    selectedSidebarMode = selectedSidebarMode,
                    savedArticleIds = savedArticleIds,
                    venueConfig = venueConfig,
                    lastRefreshMs = lastRefreshMs,
                    onSelectSidebarMode = onSelectSidebarMode,
                    onOpenArticle = onOpenArticle,
                    onToggleSave = onToggleSave,
                    onOpenBriefing = onOpenBriefing,
                    onOpenCompareCoverage = onOpenCompareCoverage,
                )
            }

            BroadsheetFooterStrip(
                lastRefreshMs = lastRefreshMs,
                unavailableCount = unavailableSources.size,
                onAdminClick = onAdminClick,
            )
        }
    }
}

@Composable
private fun WideBroadsheetBody(
    allArticles: List<ArticleEntity>,
    displayedArticles: List<ArticleEntity>,
    clusters: List<StoryClusterEntity>,
    unavailableSources: List<FeedSourceEntity>,
    staleSources: List<FeedSourceEntity>,
    selectedSection: NewsSection,
    selectedSidebarMode: SidebarFeedMode,
    savedArticleIds: Set<String>,
    venueConfig: VenueConfig,
    lastRefreshMs: Long,
    onSelectSidebarMode: (SidebarFeedMode) -> Unit,
    onOpenArticle: (String) -> Unit,
    onToggleSave: (String) -> Unit,
    onOpenBriefing: () -> Unit,
    onOpenCompareCoverage: (String?) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.Top,
    ) {
        // LEFT COLUMN (~210dp): YOUR EDITION + Five-minute briefing etching card
        Column(modifier = Modifier.width(210.dp)) {
            YourEditionSidebar(
                selectedMode = selectedSidebarMode,
                savedCount = savedArticleIds.size,
                onSelectMode = onSelectSidebarMode,
            )
            Spacer(Modifier.height(14.dp))
            FiveMinuteBriefingCard(onStartReading = onOpenBriefing)
        }

        Spacer(Modifier.width(14.dp))
        VerticalDivider(modifier = Modifier.height(680.dp), thickness = 1.dp, color = NewsprintRule)
        Spacer(Modifier.width(14.dp))

        // CENTER EDITORIAL AREA
        Column(modifier = Modifier.weight(1f)) {
            val sectionHeader = when {
                selectedSidebarMode != SidebarFeedMode.TOP_STORIES -> selectedSidebarMode.label
                selectedSection == NewsSection.FRONT_PAGE -> "THE BIG READ"
                else -> selectedSection.label
            }
            SectionKickerHeader(title = sectionHeader, accentColor = OxbloodRed)
            Spacer(Modifier.height(10.dp))

            if (displayedArticles.isEmpty()) {
                EmptyDeskState(
                    mode = selectedSidebarMode,
                    section = selectedSection,
                    onReset = { onSelectSidebarMode(SidebarFeedMode.TOP_STORIES) },
                )
            } else {
                val lead = displayedArticles.first()
                val secondaryPool = displayedArticles.drop(1)
                val rightSecondary = secondaryPool.take(2)
                val explorePool = if (selectedSection == NewsSection.FRONT_PAGE && selectedSidebarMode == SidebarFeedMode.TOP_STORIES) {
                    val explicitExplore = allArticles.filter { it.slotRole == "EXPLORE" && it.id != lead.id }
                    if (explicitExplore.isNotEmpty()) explicitExplore.take(3) else secondaryPool.drop(2).take(3)
                } else {
                    secondaryPool.drop(2)
                }

                // Lead + 2 Secondary column grid matching the attached broadsheet mockup
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    LeadStoryCard(
                        article = lead,
                        isSaved = lead.id in savedArticleIds,
                        venueCity = venueConfig.defaultCityOrRegion,
                        onOpen = { onOpenArticle(lead.id) },
                        onToggleSave = { onToggleSave(lead.id) },
                        modifier = Modifier.weight(1.35f),
                    )
                    if (rightSecondary.isNotEmpty()) {
                        Spacer(Modifier.width(14.dp))
                        VerticalDivider(modifier = Modifier.height(410.dp), thickness = 1.dp, color = NewsprintRule)
                        Spacer(Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            rightSecondary.forEachIndexed { index, sec ->
                                SecondaryStoryCard(
                                    article = sec,
                                    onOpen = { onOpenArticle(sec.id) },
                                )
                                if (index < rightSecondary.lastIndex) {
                                    Spacer(Modifier.height(12.dp))
                                    NewspaperRule()
                                    Spacer(Modifier.height(12.dp))
                                }
                            }
                        }
                    }
                }

                if (explorePool.isNotEmpty()) {
                    Spacer(Modifier.height(18.dp))
                    SectionKickerHeader(title = "MORE TO EXPLORE", accentColor = DeepInk)
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        explorePool.take(3).forEach { cardArticle ->
                            MoreToExploreCard(
                                article = cardArticle,
                                onOpen = { onOpenArticle(cardArticle.id) },
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.width(14.dp))
        VerticalDivider(modifier = Modifier.height(680.dp), thickness = 1.dp, color = NewsprintRule)
        Spacer(Modifier.width(14.dp))

        // RIGHT RAIL (~235dp): Latest updates (honest refresh status) + Compare coverage
        Column(modifier = Modifier.width(235.dp)) {
            LatestUpdatesRail(
                articles = allArticles,
                unavailableSources = unavailableSources,
                staleSources = staleSources,
                lastRefreshMs = lastRefreshMs,
                onOpenArticle = onOpenArticle,
            )
            Spacer(Modifier.height(16.dp))
            NewspaperRule(color = StrongRule.copy(alpha = 0.7f))
            Spacer(Modifier.height(12.dp))
            CompareCoverageRail(
                articles = allArticles,
                clusters = clusters,
                onViewSources = { onOpenCompareCoverage(clusters.firstOrNull()?.id) },
            )
        }
    }
}

@Composable
private fun CompactNewspaperBody(
    allArticles: List<ArticleEntity>,
    displayedArticles: List<ArticleEntity>,
    clusters: List<StoryClusterEntity>,
    unavailableSources: List<FeedSourceEntity>,
    staleSources: List<FeedSourceEntity>,
    selectedSection: NewsSection,
    selectedSidebarMode: SidebarFeedMode,
    savedArticleIds: Set<String>,
    venueConfig: VenueConfig,
    lastRefreshMs: Long,
    onSelectSidebarMode: (SidebarFeedMode) -> Unit,
    onOpenArticle: (String) -> Unit,
    onToggleSave: (String) -> Unit,
    onOpenBriefing: () -> Unit,
    onOpenCompareCoverage: (String?) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        // Horizontal "Your Edition" shelf pills for comfortable touch reach on handheld screens
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            SidebarFeedMode.entries.forEach { mode ->
                val isSelected = mode == selectedSidebarMode
                val label = if (mode == SidebarFeedMode.SAVED_READING && savedArticleIds.isNotEmpty()) {
                    "${mode.label} (${savedArticleIds.size})"
                } else {
                    mode.label
                }
                Surface(
                    color = if (isSelected) SelectedSidebarBg else CreamPaper,
                    border = BorderStroke(1.dp, if (isSelected) ForestGreen else NewsprintRule),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .clickable { onSelectSidebarMode(mode) }
                        .testTag("sidebar_mode_${mode.name.lowercase()}"),
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (isSelected) ForestGreen else DeepInk,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    )
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        val sectionHeader = when {
            selectedSidebarMode != SidebarFeedMode.TOP_STORIES -> selectedSidebarMode.label
            selectedSection == NewsSection.FRONT_PAGE -> "THE BIG READ"
            else -> selectedSection.label
        }
        SectionKickerHeader(title = sectionHeader, accentColor = OxbloodRed)
        Spacer(Modifier.height(10.dp))

        if (displayedArticles.isEmpty()) {
            EmptyDeskState(
                mode = selectedSidebarMode,
                section = selectedSection,
                onReset = { onSelectSidebarMode(SidebarFeedMode.TOP_STORIES) },
            )
        } else {
            val lead = displayedArticles.first()
            LeadStoryCard(
                article = lead,
                isSaved = lead.id in savedArticleIds,
                venueCity = venueConfig.defaultCityOrRegion,
                onOpen = { onOpenArticle(lead.id) },
                onToggleSave = { onToggleSave(lead.id) },
            )

            val rest = displayedArticles.drop(1)
            if (rest.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                NewspaperRule()
                Spacer(Modifier.height(14.dp))
                rest.take(3).forEachIndexed { idx, item ->
                    SecondaryStoryCard(
                        article = item,
                        onOpen = { onOpenArticle(item.id) },
                    )
                    if (idx < minOf(2, rest.lastIndex)) {
                        Spacer(Modifier.height(14.dp))
                        NewspaperRule()
                        Spacer(Modifier.height(14.dp))
                    }
                }
            }

            val explorePool = if (selectedSection == NewsSection.FRONT_PAGE && selectedSidebarMode == SidebarFeedMode.TOP_STORIES) {
                allArticles.filter { it.slotRole == "EXPLORE" && it.id != lead.id }.take(3)
            } else {
                rest.drop(3)
            }
            if (explorePool.isNotEmpty()) {
                Spacer(Modifier.height(18.dp))
                SectionKickerHeader(title = "MORE TO EXPLORE", accentColor = DeepInk)
                Spacer(Modifier.height(10.dp))
                explorePool.forEachIndexed { idx, cardArticle ->
                    MoreToExploreCard(
                        article = cardArticle,
                        onOpen = { onOpenArticle(cardArticle.id) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    if (idx < explorePool.lastIndex) {
                        Spacer(Modifier.height(14.dp))
                        NewspaperRule()
                        Spacer(Modifier.height(14.dp))
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        NewspaperRule(color = StrongRule)
        Spacer(Modifier.height(14.dp))

        FiveMinuteBriefingCard(onStartReading = onOpenBriefing)

        Spacer(Modifier.height(16.dp))
        LatestUpdatesRail(
            articles = allArticles,
            unavailableSources = unavailableSources,
            staleSources = staleSources,
            lastRefreshMs = lastRefreshMs,
            onOpenArticle = onOpenArticle,
        )

        Spacer(Modifier.height(16.dp))
        NewspaperRule(color = StrongRule.copy(alpha = 0.6f))
        Spacer(Modifier.height(12.dp))
        CompareCoverageRail(
            articles = allArticles,
            clusters = clusters,
            onViewSources = { onOpenCompareCoverage(clusters.firstOrNull()?.id) },
        )
    }
}

@Composable
private fun YourEditionSidebar(
    selectedMode: SidebarFeedMode,
    savedCount: Int,
    onSelectMode: (SidebarFeedMode) -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "YOUR EDITION",
            style = MaterialTheme.typography.labelMedium,
            color = DeepInk,
        )
        Spacer(Modifier.height(10.dp))
        val items: List<Triple<SidebarFeedMode, ImageVector, String>> = listOf(
            Triple(SidebarFeedMode.TOP_STORIES, Icons.Outlined.Newspaper, "Top stories"),
            Triple(SidebarFeedMode.LATEST_UPDATES, Icons.Outlined.Schedule, "Latest updates"),
            Triple(
                SidebarFeedMode.SAVED_READING,
                Icons.Outlined.BookmarkBorder,
                if (savedCount > 0) "Saved reading ($savedCount)" else "Saved reading",
            ),
            Triple(SidebarFeedMode.LOCAL_BRIEFING, Icons.Outlined.LocationOn, "Local briefing"),
            Triple(SidebarFeedMode.READING_HISTORY, Icons.Outlined.History, "Reading history"),
        )
        items.forEachIndexed { idx, (mode, icon, label) ->
            val selected = mode == selectedMode
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (selected) SelectedSidebarBg else Color.Transparent)
                    .clickable { onSelectMode(mode) }
                    .padding(horizontal = 8.dp, vertical = 10.dp)
                    .testTag("sidebar_mode_${mode.name.lowercase()}"),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (selected) ForestGreen else DeepInk,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = label,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    ),
                    color = DeepInk,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = null,
                    tint = SlateInk,
                    modifier = Modifier.size(16.dp),
                )
            }
            if (idx < items.lastIndex && !selected) {
                NewspaperRule(color = NewsprintRule.copy(alpha = 0.6f))
            }
        }
    }
}

@Composable
private fun FiveMinuteBriefingCard(onStartReading: () -> Unit) {
    Surface(
        color = CreamPaper,
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(1.dp, NewsprintRule),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Image(
                painter = painterResource(id = R.drawable.img_westminster_etching),
                contentDescription = "Pen-and-ink engraving of the Palace of Westminster",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(4f / 3f)
                    .clip(RoundedCornerShape(2.dp)),
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "A five-minute briefing",
                style = MaterialTheme.typography.headlineMedium,
                color = DeepInk,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "The day's essential stories, expertly curated for a quick, informed read.",
                style = MaterialTheme.typography.bodyMedium,
                color = SlateInk,
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = onStartReading,
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen, contentColor = CreamPaper),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .testTag("start_briefing_button"),
            ) {
                Text("Start reading", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.width(6.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun LeadStoryCard(
    article: ArticleEntity,
    isSaved: Boolean,
    venueCity: String,
    onOpen: () -> Unit,
    onToggleSave: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val rights = ContentRightsMode.entries.firstOrNull { it.name == article.contentRightsMode }
        ?: ContentRightsMode.HEADLINE_AND_LINK
    val metaLine = ReadingTimeCalculator.formatMetadataLine(
        publisherName = article.publisherName,
        articleType = article.articleType,
        rightsMode = rights,
        fullText = article.fullText,
    )

    Column(
        modifier = modifier
            .clickable { onOpen() }
            .testTag("lead_story_card"),
    ) {
        ArticleThumbnailImage(
            article = article,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9.5f),
        )
        Spacer(Modifier.height(10.dp))
        LocalDistinctionBadges(article = article, venueCity = venueCity)
        Text(
            text = article.title,
            style = MaterialTheme.typography.displayMedium,
            color = DeepInk,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = article.standfirst,
            style = MaterialTheme.typography.titleSmall,
            color = SlateInk,
        )
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = metaLine,
                style = MaterialTheme.typography.bodySmall,
                color = SlateInk,
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                SaveStoryButton(
                    isSaved = isSaved,
                    onClick = onToggleSave,
                    modifier = Modifier.testTag("lead_save_button"),
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = onOpen,
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen, contentColor = CreamPaper),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("lead_read_button"),
                ) {
                    Text("Read story", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.width(5.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(15.dp))
                }
            }
        }
    }
}

@Composable
private fun SecondaryStoryCard(
    article: ArticleEntity,
    onOpen: () -> Unit,
) {
    val rights = ContentRightsMode.entries.firstOrNull { it.name == article.contentRightsMode }
        ?: ContentRightsMode.HEADLINE_AND_LINK
    val metaLine = ReadingTimeCalculator.formatMetadataLine(
        publisherName = article.publisherName,
        articleType = article.articleType,
        rightsMode = rights,
        fullText = article.fullText,
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpen() }
            .padding(vertical = 2.dp)
            .testTag("article_card_${article.id}"),
    ) {
        if (article.localDrawableName != null || article.remoteImageUrl != null) {
            ArticleThumbnailImage(
                article = article,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f),
            )
            Spacer(Modifier.height(8.dp))
        }
        Text(
            text = article.title,
            style = MaterialTheme.typography.headlineLarge,
            color = DeepInk,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = metaLine,
            style = MaterialTheme.typography.bodySmall,
            color = SlateInk,
        )
        if (rights == ContentRightsMode.HEADLINE_AND_LINK) {
            Spacer(Modifier.height(4.dp))
            StatusPill(text = "Publisher link only", bgColor = NewsprintInset, fgColor = SlateInk)
        }
    }
}

@Composable
private fun MoreToExploreCard(
    article: ArticleEntity,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val rights = ContentRightsMode.entries.firstOrNull { it.name == article.contentRightsMode }
        ?: ContentRightsMode.HEADLINE_AND_LINK
    val metaLine = ReadingTimeCalculator.formatMetadataLine(
        publisherName = article.publisherName,
        articleType = article.articleType,
        rightsMode = rights,
        fullText = article.fullText,
    )
    Column(
        modifier = modifier
            .clickable { onOpen() }
            .testTag("explore_card_${article.id}"),
    ) {
        if (article.localDrawableName != null || article.remoteImageUrl != null) {
            ArticleThumbnailImage(
                article = article,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 10f),
            )
            Spacer(Modifier.height(8.dp))
        }
        Text(
            text = article.title,
            style = MaterialTheme.typography.headlineMedium,
            color = DeepInk,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = article.standfirst,
            style = MaterialTheme.typography.bodyMedium,
            color = SlateInk,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = metaLine,
            style = MaterialTheme.typography.bodySmall,
            color = SlateInk,
        )
    }
}

@Composable
private fun LatestUpdatesRail(
    articles: List<ArticleEntity>,
    unavailableSources: List<FeedSourceEntity>,
    staleSources: List<FeedSourceEntity>,
    lastRefreshMs: Long,
    onOpenArticle: (String) -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(OxbloodRed)
            )
            Spacer(Modifier.width(7.dp))
            // Never falsely claim "live" when periodically refreshed; show actual update time
            Text(
                text = "LATEST UPDATES  •  ${formatTimeShort(lastRefreshMs)}",
                style = MaterialTheme.typography.labelMedium,
                color = DeepInk,
            )
        }
        Spacer(Modifier.height(10.dp))

        if (unavailableSources.isNotEmpty()) {
            Surface(
                color = OxbloodTint,
                border = BorderStroke(1.dp, OxbloodRed.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                        text = "Source unavailable: ${unavailableSources.joinToString { it.publisherName }}",
                        style = MaterialTheme.typography.labelSmall,
                        color = OxbloodRed,
                    )
                    Text(
                        text = unavailableSources.first().lastError ?: "Upstream feed failed; rest of edition unaffected.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DeepInk,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        if (staleSources.isNotEmpty()) {
            Surface(
                color = AmberTint,
                border = BorderStroke(1.dp, AmberNotice.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = "Stale feed: ${staleSources.first().publisherName} (last updated ${formatTimeShort(staleSources.first().lastSuccessfulRefreshMs)})",
                    style = MaterialTheme.typography.labelSmall,
                    color = AmberNotice,
                    modifier = Modifier.padding(8.dp),
                )
            }
            Spacer(Modifier.height(8.dp))
        }

        val updates = remember(articles) {
            articles.sortedByDescending { it.modifiedAtMs ?: it.publishedAtMs }.take(4)
        }
        updates.forEachIndexed { idx, item ->
            val timeLabel = formatTimeShort(item.modifiedAtMs ?: item.publishedAtMs)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clickable { onOpenArticle(item.id) }
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.Top,
            ) {
                Text(
                    text = timeLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateInk,
                    modifier = Modifier.width(42.dp),
                )
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = DeepInk,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
            }
            if (idx < updates.lastIndex) {
                NewspaperRule(color = NewsprintRule.copy(alpha = 0.6f))
            }
        }
    }
}

@Composable
private fun CompareCoverageRail(
    articles: List<ArticleEntity>,
    clusters: List<StoryClusterEntity>,
    onViewSources: () -> Unit,
) {
    val leadCluster = clusters.firstOrNull()
    val clusterArticles = remember(articles, leadCluster) {
        if (leadCluster == null) emptyList()
        else articles.filter { it.clusterId == leadCluster.id }.distinctBy { it.publisherId }.take(3)
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "COMPARE COVERAGE",
            style = MaterialTheme.typography.labelMedium,
            color = DeepInk,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "One story, several perspectives",
            style = MaterialTheme.typography.headlineMedium,
            color = DeepInk,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = "Grouped by topic only — does not imply agreement.",
            style = MaterialTheme.typography.bodySmall,
            color = SlateInk,
        )
        Spacer(Modifier.height(10.dp))

        clusterArticles.forEachIndexed { idx, art ->
            val icon = when (art.publisherName) {
                "World Dispatch" -> Icons.Outlined.Public
                "Market Ledger" -> Icons.AutoMirrored.Outlined.TrendingUp
                else -> Icons.Outlined.Newspaper
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(icon, contentDescription = null, tint = DeepInk, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = art.publisherName,
                        style = MaterialTheme.typography.titleMedium,
                        color = DeepInk,
                        maxLines = 1,
                    )
                    Text(
                        text = "${art.articleType} • ${formatTimeShort(art.publishedAtMs)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = SlateInk,
                    )
                }
            }
            if (idx < clusterArticles.lastIndex) {
                NewspaperRule(color = NewsprintRule.copy(alpha = 0.55f))
            }
        }

        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = onViewSources,
            border = BorderStroke(1.dp, NewsprintRule),
            shape = RoundedCornerShape(4.dp),
            colors = ButtonDefaults.outlinedButtonColors(containerColor = CreamPaper, contentColor = DeepInk),
            modifier = Modifier
                .fillMaxWidth()
                .minimumInteractiveComponentSize()
                .testTag("view_sources_button"),
        ) {
            Text("View sources", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.width(6.dp))
            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(15.dp))
        }
    }
}

@Composable
private fun LocalDistinctionBadges(
    article: ArticleEntity,
    venueCity: String,
) {
    if (!article.isLocalOutlet && !article.isLocallyRelevant) return
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.padding(bottom = 6.dp),
    ) {
        if (article.isLocalOutlet) {
            StatusPill(
                text = "LOCAL OUTLET (${article.region.uppercase()})",
                bgColor = ForestGreen.copy(alpha = 0.12f),
                fgColor = ForestGreen,
            )
        } else if (article.isLocallyRelevant) {
            StatusPill(
                text = "RELEVANT TO ${venueCity.uppercase()}",
                bgColor = NewsprintInset,
                fgColor = DeepInk,
            )
        }
    }
}

@Composable
private fun EmptyDeskState(
    mode: SidebarFeedMode,
    section: NewsSection,
    onReset: () -> Unit,
) {
    Surface(
        color = CreamPaper,
        border = BorderStroke(1.dp, NewsprintRule),
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = when (mode) {
                    SidebarFeedMode.SAVED_READING -> "No saved stories in this reading session"
                    SidebarFeedMode.READING_HISTORY -> "No articles opened in this reading session yet"
                    else -> "No stories available in ${section.label}"
                },
                style = MaterialTheme.typography.headlineMedium,
                color = DeepInk,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Tap Save on any story while browsing to keep a temporary reading list for this session.",
                style = MaterialTheme.typography.bodyMedium,
                color = SlateInk,
            )
            Spacer(Modifier.height(14.dp))
            OutlinedButton(
                onClick = onReset,
                modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
                Text("Return to Top stories")
            }
        }
    }
}

@Composable
private fun BroadsheetFooterStrip(
    lastRefreshMs: Long,
    unavailableCount: Int,
    onAdminClick: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
    ) {
        NewspaperRule(color = NewsprintRule)
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f),
            ) {
                Icon(
                    imageVector = Icons.Outlined.Info,
                    contentDescription = null,
                    tint = SlateInk,
                    modifier = Modifier.size(15.dp),
                )
                Spacer(Modifier.width(6.dp))
                val healthNote = if (unavailableCount > 0) " • $unavailableCount feed unavailable" else ""
                Text(
                    text = "Updated ${formatTimeShort(lastRefreshMs)} • Sources clearly labelled • Tap a headline to read$healthNote",
                    style = MaterialTheme.typography.bodySmall,
                    color = SlateInk,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Demonstration publications shown",
                    style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                    color = SlateInk,
                )
                Spacer(Modifier.width(10.dp))
                TextButton(
                    onClick = onAdminClick,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("footer_admin_button"),
                ) {
                    Text(
                        text = "Newsroom Admin",
                        style = MaterialTheme.typography.labelSmall,
                        color = SlateInk,
                    )
                }
            }
        }
    }
}
