package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.adapters.*
import com.example.data.local.CinemaDatabase
import com.example.data.repository.AuthenticatedStaff
import com.example.data.repository.CheckoutProcessingResult
import com.example.data.repository.ReservationRepository
import com.example.domain.model.*
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CinemaTerminalIntegrationTest {

    private lateinit var db: CinemaDatabase
    private lateinit var clock: ControllableClockProvider
    private lateinit var repo: ReservationRepository

    private val staffAttendant = AuthenticatedStaff("STF-1", "Jordan", StaffRole.STAFF)
    private val staffSupervisor = AuthenticatedStaff("SUP-1", "Elena", StaffRole.SUPERVISOR)
    private val staffManager = AuthenticatedStaff("MGR-1", "Marcus", StaffRole.MANAGER)

    @Before
    fun setup() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, CinemaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        clock = ControllableClockProvider(1_794_900_000_000L)
        repo = ReservationRepository(
            dao = db.cinemaDao(),
            clock = clock,
            membershipAdapter = DemoMembershipAdapter(),
            paymentAdapter = SimulatedPaymentTerminalAdapter(clock),
            printerAdapter = SimulatedThermalPrinterAdapter(),
            notificationAdapter = DemoNotificationAdapter()
        )
        repo.initializeSeedData()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `concurrent seat selection allows only one winner`() = runTest {
        val screeningId = "scr_od_cc_1915"
        val results = listOf(
            async { repo.holdSeat(screeningId, "F7", "SESSION_A") },
            async { repo.holdSeat(screeningId, "F7", "SESSION_B") }
        ).awaitAll()

        val successes = results.count { it is OperationResult.Success }
        val failures = results.count { it is OperationResult.Failure }
        assertEquals(1, successes)
        assertEquals(1, failures)

        val lock = db.cinemaDao().getSeatLock(screeningId, "F7")
        assertNotNull(lock)
        assertEquals("HOLD", lock?.lockType)
    }

    @Test
    fun `hold expiry releases seat after timeout using server clock`() = runTest {
        val screeningId = "scr_od_cc_1915"
        val holdRes = repo.holdSeat(screeningId, "F8", "SESSION_A")
        assertTrue(holdRes is OperationResult.Success)

        // Advance clock past 272s hold duration
        clock.advanceBy(300_000L)
        val pruned = repo.runMaintenanceTick()
        assertTrue(pruned >= 1)

        // Session B can now acquire F8 cleanly
        val secondRes = repo.holdSeat(screeningId, "F8", "SESSION_B")
        assertTrue(secondRes is OperationResult.Success)
    }

    @Test
    fun `screening change releases obsolete holds`() = runTest {
        val res = repo.holdSeat("scr_od_cc_1915", "E4", "SESSION_A")
        assertTrue(res is OperationResult.Success)
        repo.releaseSessionHolds("SESSION_A", "scr_od_cc_1915")
        val lock = db.cinemaDao().getSeatLock("scr_od_cc_1915", "E4")
        assertNull(lock)
    }

    @Test
    fun `accessible spaces and companion seats are modeled distinctly`() = runTest {
        val seats = db.cinemaDao().observeSeatDefinitions("aud_cc_6").first()
        val j3 = seats.first { it.seatCode == "J3" }
        val j4 = seats.first { it.seatCode == "J4" }
        val f7 = seats.first { it.seatCode == "F7" }

        assertEquals("ACCESSIBLE_WHEELCHAIR", j3.seatType)
        assertEquals("J4", j3.pairedAccessibleSeatCode)
        assertEquals("COMPANION", j4.seatType)
        assertEquals("J3", j4.pairedAccessibleSeatCode)
        assertEquals("STANDARD", f7.seatType)
    }

    @Test
    fun `server calculated pricing matches screenshot demonstration total 36_80 USD`() = runTest {
        val screeningId = "scr_od_cc_1915"
        repo.holdSeat(screeningId, "F7", "SESSION_A", TicketCategory.ADULT)
        repo.holdSeat(screeningId, "F8", "SESSION_A", TicketCategory.ADULT)

        val pricing = repo.calculateServerPricing(screeningId, "SESSION_A", emptyMap(), null)
        assertEquals(3200L, pricing.ticketSubtotalCents)
        assertEquals(200L, pricing.bookingFeeCents)
        assertEquals(280L, pricing.taxCents)
        assertEquals(3680L, pricing.grandTotalCents)
        assertEquals("USD", pricing.currency)
    }

    @Test
    fun `discount precedence applies percentage before flat discount and waives fee`() = runTest {
        val screening = db.cinemaDao().getScreeningById("scr_od_cc_1915")!!
        val hybridMember = MembershipAccount(
            accountId = "MEM-HYBRID",
            maskedMemberNumber = "•••• 9999",
            tierName = "Hybrid Demo",
            displayAlias = "Hybrid",
            ticketDiscountBps = 1000, // 10% of 3200 = 320
            flatOrderDiscountCents = 500L, // + 500 = 820 total discount
            waivesBookingFee = true,
            freeSmallPopcornEligible = false
        )
        val pricing = PricingEngine.calculate(
            screening = screening,
            seatCategories = listOf(TicketCategory.ADULT, TicketCategory.ADULT),
            concessions = emptyList(),
            membership = hybridMember
        )
        assertEquals(820L, pricing.membershipDiscountCents)
        assertEquals(0L, pricing.bookingFeeCents)
        assertEquals(200L, pricing.bookingFeeWaivedCents)
        // Discounted ticket subtotal = 2380 -> 8.75% tax = (2380*875 + 5000)/10000 = 208
        assertEquals(208L, pricing.taxCents)
        assertEquals(2380L + 208L, pricing.grandTotalCents)
    }

    @Test
    fun `duplicate checkout requests with same idempotency key do not double charge or duplicate bookings`() = runTest {
        val screeningId = "scr_od_cc_1915"
        repo.holdSeat(screeningId, "F7", "SESSION_A", TicketCategory.ADULT)
        repo.holdSeat(screeningId, "F8", "SESSION_A", TicketCategory.ADULT)

        val idempKey = "IDEMP-TEST-001"
        val first = repo.processCheckout(
            idempotencyKey = idempKey,
            sessionId = "SESSION_A",
            screeningId = screeningId,
            concessionQuantities = emptyMap(),
            membership = null,
            collectionLocation = "Lobby Express Counter A",
            notificationChannel = null,
            notificationTarget = null,
            simulatedOutcome = PaymentOutcome.APPROVED
        )
        val second = repo.processCheckout(
            idempotencyKey = idempKey,
            sessionId = "SESSION_A",
            screeningId = screeningId,
            concessionQuantities = emptyMap(),
            membership = null,
            collectionLocation = "Lobby Express Counter A",
            notificationChannel = null,
            notificationTarget = null,
            simulatedOutcome = PaymentOutcome.APPROVED
        )

        assertTrue(first is CheckoutProcessingResult.Completed)
        assertTrue(second is CheckoutProcessingResult.Completed)
        val b1 = (first as CheckoutProcessingResult.Completed).bundle.booking.bookingRef
        val b2 = (second as CheckoutProcessingResult.Completed).bundle.booking.bookingRef
        assertEquals(b1, b2)
        assertEquals(1, db.cinemaDao().observeBookings().first().size)
    }

    @Test
    fun `payment callback signature verification rejects tampered payload`() {
        val adapter = SimulatedPaymentTerminalAdapter(clock)
        assertFalse(
            adapter.verifyCallbackSignature(
                transactionId = "PAY-1",
                idempotencyKey = "KEY-1",
                amountCents = 3680L,
                status = PaymentStatus.CAPTURED,
                signatureToken = "TAMPERED_SIG"
            )
        )
    }

    @Test
    fun `uncertain payment preserves protected seats past hold expiry and reconciles cleanly`() = runTest {
        val screeningId = "scr_od_cc_1915"
        repo.holdSeat(screeningId, "F7", "SESSION_A", TicketCategory.ADULT)

        val res = repo.processCheckout(
            idempotencyKey = "IDEMP-UNCERTAIN-1",
            sessionId = "SESSION_A",
            screeningId = screeningId,
            concessionQuantities = emptyMap(),
            membership = null,
            collectionLocation = "Lobby Express Counter A",
            notificationChannel = null,
            notificationTarget = null,
            simulatedOutcome = PaymentOutcome.UNCERTAIN
        )
        assertTrue(res is CheckoutProcessingResult.UncertainPayment)
        val txId = (res as CheckoutProcessingResult.UncertainPayment).transactionId

        // Advance clock beyond hold timeout -> seats must NOT be released while payment is uncertain!
        clock.advanceBy(600_000L)
        repo.runMaintenanceTick()
        val lock = db.cinemaDao().getSeatLock(screeningId, "F7")
        assertNotNull(lock)

        // Reconcile to capture & complete booking
        val recon = repo.reconcileUncertainPayment(txId, reverseInsteadOfCapture = false, staffManager)
        assertTrue(recon is OperationResult.Success)
        val finalLock = db.cinemaDao().getSeatLock(screeningId, "F7")
        assertEquals("SOLD", finalLock?.lockType)
    }

    @Test
    fun `printer failure permits controlled reprint without re-charging and repeat admission scan is caught`() = runTest {
        repo.setPrinterOnline(false, staffManager)
        val screeningId = "scr_od_cc_1915"
        repo.holdSeat(screeningId, "F7", "SESSION_A", TicketCategory.ADULT)

        val res = repo.processCheckout(
            idempotencyKey = "IDEMP-PRINT-1",
            sessionId = "SESSION_A",
            screeningId = screeningId,
            concessionQuantities = emptyMap(),
            membership = null,
            collectionLocation = "Lobby Express Counter A",
            notificationChannel = null,
            notificationTarget = null,
            simulatedOutcome = PaymentOutcome.APPROVED
        ) as CheckoutProcessingResult.Completed

        assertEquals(PrintStatus.PRINT_FAILED.name, res.bundle.booking.printStatus)
        assertNotNull(res.printerWarning)

        // Restore printer and reprint without new payment
        repo.setPrinterOnline(true, staffManager)
        val reprinted = repo.reprintBooking(res.bundle.booking.bookingRef)
        assertTrue(reprinted is OperationResult.Success)
        assertEquals(PrintStatus.REPRINTED.name, (reprinted as OperationResult.Success).data.booking.printStatus)
        assertEquals(1, db.cinemaDao().observePaymentTransactions().first().size)

        // Secure booking lookup requires matching PIN
        val badLookup = repo.lookupBooking(res.bundle.booking.bookingRef, "0000")
        assertTrue(badLookup is OperationResult.Failure)
        val goodLookup = repo.lookupBooking(res.bundle.booking.bookingRef, res.bundle.booking.verificationCode)
        assertTrue(goodLookup is OperationResult.Success)

        // Admission & Repeat Scan detection
        val qr = res.bundle.tickets.first().qrToken
        assertFalse(qr.contains("SESSION_A"))
        val admit1 = repo.admitTicket(qr, staffAttendant)
        assertTrue(admit1 is OperationResult.Success)
        val admit2 = repo.admitTicket(qr, staffAttendant)
        assertTrue(admit2 is OperationResult.Failure)
        assertEquals("REPEAT_SCAN", (admit2 as OperationResult.Failure).code)

        // RBAC permissions: Attendant cannot refund; Supervisor can refund & audit log records it
        val forbiddenRefund = repo.refundBooking(res.bundle.booking.bookingRef, "Test", staffAttendant)
        assertTrue(forbiddenRefund is OperationResult.Failure)
        val allowedRefund = repo.refundBooking(res.bundle.booking.bookingRef, "Customer changed plans", staffSupervisor)
        assertTrue(allowedRefund is OperationResult.Success)
        val logs = db.cinemaDao().observeAuditLogs().first()
        assertTrue(logs.any { it.actionType == "BOOKING_REFUNDED" })
    }
}
