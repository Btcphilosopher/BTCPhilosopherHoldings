package com.example

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w1280dp-h800dp-land")
class CinemaTerminalUiTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun fullKioskJourney_selectF7AndF8_payAndIssueTickets_thenReset() {
        // Wait for Room seed data to populate UI
        composeTestRule.waitUntil(timeoutMillis = 8000L) {
            composeTestRule.onAllNodesWithTag("seat_tile_F7").fetchSemanticsNodes().isNotEmpty()
        }
        composeTestRule.waitForIdle()

        // 1. Hold seats F7 and F8
        composeTestRule.onNodeWithTag("seat_tile_F7").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("seat_tile_F8").performScrollTo().performClick()
        composeTestRule.waitUntil(timeoutMillis = 5000L) {
            composeTestRule.onAllNodesWithText("$36.80 USD").fetchSemanticsNodes().isNotEmpty()
        }
        composeTestRule.waitForIdle()

        // Verify $36.80 USD total and selected seats
        composeTestRule.onNodeWithText("$36.80 USD").assertIsDisplayed()
        composeTestRule.onNodeWithTag("your_visit_seats_label").assertTextContains("F7, F8", substring = true)

        // 2. Continue to Extras, then proceed to Payment
        composeTestRule.onNodeWithTag("continue_to_extras_button").performScrollTo().performClick()
        composeTestRule.waitUntil(timeoutMillis = 5000L) {
            composeTestRule.onAllNodesWithTag("extras_continue_to_pay_button").fetchSemanticsNodes().isNotEmpty()
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("extras_continue_to_pay_button").performScrollTo().performClick()

        composeTestRule.waitUntil(timeoutMillis = 5000L) {
            composeTestRule.onAllNodesWithTag("pay_approve_button").fetchSemanticsNodes().isNotEmpty()
        }
        composeTestRule.waitForIdle()

        // 3. Complete simulated approved payment
        composeTestRule.onNodeWithTag("pay_approve_button").performScrollTo().performClick()
        composeTestRule.waitUntil(timeoutMillis = 5000L) {
            composeTestRule.onAllNodesWithText("DEMO — NOT VALID FOR ADMISSION").fetchSemanticsNodes().isNotEmpty()
        }
        composeTestRule.waitForIdle()

        // Verify ticket issued
        composeTestRule.onNodeWithText("DEMO — NOT VALID FOR ADMISSION").assertIsDisplayed()
        composeTestRule.onNodeWithTag("ticket_booking_reference").assertIsDisplayed()

        // 4. Reset kiosk for next customer
        composeTestRule.onNodeWithTag("done_reset_kiosk_button").performScrollTo().performClick()
        composeTestRule.waitUntil(timeoutMillis = 5000L) {
            composeTestRule.onAllNodesWithTag("seat_tile_F7").fetchSemanticsNodes().isNotEmpty()
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("seat_tile_F7").assertIsDisplayed()
    }
}
