package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.FilmEntity
import com.example.data.local.ScreeningEntity
import com.example.domain.model.*
import com.example.ui.components.FilmPosterArt
import com.example.ui.theme.*
import com.example.ui.viewmodel.KioskUiState

@Composable
fun FilmAndSeatWorkspace(
    state: KioskUiState,
    isCompactWidth: Boolean,
    onSelectFilmAndScreening: (String, String?) -> Unit,
    onDateFilterChange: (String) -> Unit,
    onFormatFilterChange: (String) -> Unit,
    onShowComingSoonChange: (Boolean) -> Unit,
    onSeatToggle: (String) -> Unit,
    onSeatCategoryChange: (String, TicketCategory) -> Unit,
    onAllSeatsCategoryChange: (TicketCategory) -> Unit,
    onExtendHold: () -> Unit,
    onOpenTextSeatSelector: () -> Unit,
    onContinueToExtras: () -> Unit,
    onSkipExtras: () -> Unit,
    onOpenMembership: () -> Unit,
    onClearMembership: () -> Unit,
    onOpenFindBooking: () -> Unit,
    onOpenRefundTerms: () -> Unit
) {
    if (isCompactWidth) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(KioskBlack)
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FilmCatalogColumn(
                state = state,
                onSelectFilmAndScreening = onSelectFilmAndScreening,
                onDateFilterChange = onDateFilterChange,
                onFormatFilterChange = onFormatFilterChange,
                onShowComingSoonChange = onShowComingSoonChange,
                onOpenFindBooking = onOpenFindBooking
            )
            SeatMapWorkspaceCard(
                state = state,
                onSeatToggle = onSeatToggle,
                onSeatCategoryChange = onSeatCategoryChange,
                onAllSeatsCategoryChange = onAllSeatsCategoryChange,
                onExtendHold = onExtendHold,
                onOpenTextSeatSelector = onOpenTextSeatSelector
            )
            OrderSummaryAndMembershipColumn(
                state = state,
                onContinueToExtras = onContinueToExtras,
                onSkipExtras = onSkipExtras,
                onOpenMembership = onOpenMembership,
                onClearMembership = onClearMembership,
                onOpenRefundTerms = onOpenRefundTerms
            )
        }
    } else {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(KioskBlack)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Left Column: Now Showing & Showtimes
            Box(
                modifier = Modifier
                    .weight(0.28f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState())
            ) {
                FilmCatalogColumn(
                    state = state,
                    onSelectFilmAndScreening = onSelectFilmAndScreening,
                    onDateFilterChange = onDateFilterChange,
                    onFormatFilterChange = onFormatFilterChange,
                    onShowComingSoonChange = onShowComingSoonChange,
                    onOpenFindBooking = onOpenFindBooking
                )
            }

            // Center Column: Crisp White Seat Map Workspace
            Box(
                modifier = Modifier
                    .weight(0.47f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState())
            ) {
                SeatMapWorkspaceCard(
                    state = state,
                    onSeatToggle = onSeatToggle,
                    onSeatCategoryChange = onSeatCategoryChange,
                    onAllSeatsCategoryChange = onAllSeatsCategoryChange,
                    onExtendHold = onExtendHold,
                    onOpenTextSeatSelector = onOpenTextSeatSelector
                )
            }

            // Right Column: Order Summary ("Your visit") + Membership Card
            Box(
                modifier = Modifier
                    .weight(0.25f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState())
            ) {
                OrderSummaryAndMembershipColumn(
                    state = state,
                    onContinueToExtras = onContinueToExtras,
                    onSkipExtras = onSkipExtras,
                    onOpenMembership = onOpenMembership,
                    onClearMembership = onClearMembership,
                    onOpenRefundTerms = onOpenRefundTerms
                )
            }
        }
    }
}

@Composable
private fun FilmCatalogColumn(
    state: KioskUiState,
    onSelectFilmAndScreening: (String, String?) -> Unit,
    onDateFilterChange: (String) -> Unit,
    onFormatFilterChange: (String) -> Unit,
    onShowComingSoonChange: (Boolean) -> Unit,
    onOpenFindBooking: () -> Unit
) {
    val strings = state.strings
    val visibleFilms = remember(state.films, state.showComingSoon, state.screenings, state.selectedDateFilter, state.selectedFormatFilter, state.accessibility) {
        state.films.filter { film ->
            if (film.isComingSoon != state.showComingSoon) return@filter false
            if (state.accessibility.filterClosedCaption && !film.accessibilityFeaturesCsv.contains("Closed Caption", ignoreCase = true)) {
                return@filter false
            }
            if (state.accessibility.filterAudioDescription && !film.accessibilityFeaturesCsv.contains("Audio Description", ignoreCase = true)) {
                return@filter false
            }
            if (!film.isComingSoon && state.selectedFormatFilter != "All") {
                val hasMatchingScreening = state.screenings.any {
                    it.filmId == film.id &&
                        it.dateDisplayLabel == state.selectedDateFilter &&
                        it.format.equals(state.selectedFormatFilter, ignoreCase = true)
                }
                if (!hasMatchingScreening) return@filter false
            }
            true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(KioskCharcoal, RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Now Showing / Coming Soon Toggle Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (state.showComingSoon) strings.comingSoon else strings.nowShowing,
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                    fontFamily = DisplayFontFamily,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = strings.illustrativeFilms,
                    color = TextOnDarkSecondary,
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.sp
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                FilterChip(
                    selected = !state.showComingSoon,
                    onClick = { onShowComingSoonChange(false) },
                    label = { Text("Now", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CinemaRed,
                        selectedLabelColor = Color.White,
                        labelColor = TextOnDarkSecondary
                    ),
                    modifier = Modifier.testTag("tab_now_showing")
                )
                FilterChip(
                    selected = state.showComingSoon,
                    onClick = { onShowComingSoonChange(true) },
                    label = { Text("Soon", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CinemaRed,
                        selectedLabelColor = Color.White,
                        labelColor = TextOnDarkSecondary
                    ),
                    modifier = Modifier.testTag("tab_coming_soon")
                )
            }
        }

        // Date & Format Filters
        if (!state.showComingSoon) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("Today", "Tomorrow").forEach { dateLabel ->
                    val active = state.selectedDateFilter == dateLabel
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (active) Color.White else KioskCharcoalElevated)
                            .border(1.dp, if (active) Color.White else KioskCharcoalBorder, RoundedCornerShape(8.dp))
                            .clickable { onDateFilterChange(dateLabel) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("date_filter_$dateLabel")
                    ) {
                        Text(
                            text = dateLabel,
                            color = if (active) KioskBlack else Color.White,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                listOf("All", "Standard", "IMAX").forEach { fmt ->
                    val active = state.selectedFormatFilter == fmt
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (active) CinemaRed.copy(alpha = 0.25f) else KioskCharcoalElevated)
                            .border(1.dp, if (active) CinemaRed else KioskCharcoalBorder, RoundedCornerShape(8.dp))
                            .clickable { onFormatFilterChange(fmt) }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("format_filter_$fmt")
                    ) {
                        Text(
                            text = fmt,
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }

        // Film Cards
        visibleFilms.forEach { film ->
            val isSelected = state.selectedFilm?.id == film.id && !film.isComingSoon
            val filmScreenings = state.screenings.filter {
                it.filmId == film.id &&
                    (film.isComingSoon || it.dateDisplayLabel == state.selectedDateFilter) &&
                    (state.selectedFormatFilter == "All" || it.format.equals(state.selectedFormatFilter, ignoreCase = true))
            }
            FilmCatalogCard(
                film = film,
                screenings = filmScreenings,
                isSelected = isSelected,
                selectedScreeningId = state.selectedScreening?.id,
                onSelectFilm = { onSelectFilmAndScreening(film.id, filmScreenings.firstOrNull()?.id) },
                onSelectScreening = { scrId -> onSelectFilmAndScreening(film.id, scrId) }
            )
        }

        // Find My Booking quick action
        OutlinedButton(
            onClick = onOpenFindBooking,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, KioskCharcoalBorder),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = KioskCharcoalElevated,
                contentColor = Color.White
            ),
            modifier = Modifier
                .fillMaxWidth()
                .minimumInteractiveComponentSize()
                .testTag("find_my_booking_button")
        ) {
            Icon(Icons.Filled.ConfirmationNumber, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(strings.findMyBooking, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun FilmCatalogCard(
    film: FilmEntity,
    screenings: List<ScreeningEntity>,
    isSelected: Boolean,
    selectedScreeningId: String?,
    onSelectFilm: () -> Unit,
    onSelectScreening: (String) -> Unit
) {
    val runtimeFormatted = "${film.runtimeMinutes / 60}h %02dm".format(film.runtimeMinutes % 60)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) Color(0xFF1A1B21) else KioskCharcoalElevated)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) CinemaRed else KioskCharcoalBorder,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onSelectFilm)
            .padding(10.dp)
            .testTag("film_card_${film.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilmPosterArt(
                posterKey = film.posterKey,
                title = film.title,
                modifier = Modifier
                    .width(64.dp)
                    .height(82.dp)
            )
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = film.title,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(CinemaRed),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Check, contentDescription = "Selected film", tint = Color.White, modifier = Modifier.size(14.dp))
                        }
                    } else {
                        Icon(
                            Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Select ${film.title}",
                            tint = TextOnDarkSecondary
                        )
                    }
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "${film.classification} • $runtimeFormatted",
                    color = TextOnDarkSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
                if (film.isComingSoon) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "${film.releaseLabel} • ${film.admissionPolicy}",
                        color = Color(0xFFFBBF24),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 2
                    )
                } else if (isSelected) {
                    Spacer(Modifier.height(6.dp))
                    val activeScr = screenings.firstOrNull { it.id == selectedScreeningId } ?: screenings.firstOrNull()
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(KioskBlack)
                            .border(1.dp, KioskCharcoalBorder, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${activeScr?.format ?: "Standard"} • Reserved seating",
                            color = TextOnDarkSecondary,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }

        if (isSelected && screenings.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                screenings.forEach { scr ->
                    val scrSelected = scr.id == selectedScreeningId
                    val isCancelled = scr.status != "ACTIVE"
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                when {
                                    isCancelled -> Color(0xFF374151)
                                    scrSelected -> CinemaRed
                                    else -> KioskBlack
                                }
                            )
                            .border(
                                1.dp,
                                if (scrSelected) CinemaRed else KioskCharcoalBorder,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { onSelectScreening(scr.id) }
                            .minimumInteractiveComponentSize()
                            .padding(horizontal = 10.dp, vertical = 7.dp)
                            .testTag("showtime_pill_${scr.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isCancelled) "${scr.localTimeLabel} (X)" else scr.localTimeLabel,
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (scrSelected) FontWeight.Bold else FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SeatMapWorkspaceCard(
    state: KioskUiState,
    onSeatToggle: (String) -> Unit,
    onSeatCategoryChange: (String, TicketCategory) -> Unit,
    onAllSeatsCategoryChange: (TicketCategory) -> Unit,
    onExtendHold: () -> Unit,
    onOpenTextSeatSelector: () -> Unit
) {
    val strings = state.strings
    val filmTitle = state.selectedFilm?.title ?: "Orbital Dawn"
    val screening = state.selectedScreening
    val auditoriumName = state.selectedAuditorium?.name ?: "Auditorium 6"
    var showCategoryEditor by remember { mutableStateOf(false) }

    Surface(
        color = WorkspaceWhite,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header + Text Alternative Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.chooseYourSeats,
                        color = TextOnLightPrimary,
                        style = MaterialTheme.typography.headlineMedium,
                        fontFamily = DisplayFontFamily,
                        fontWeight = FontWeight.ExtraBold
                    )
                    val subtitle = if (screening != null) {
                        "$filmTitle • ${screening.dateDisplayLabel}, ${screening.localTimeLabel} • $auditoriumName"
                    } else {
                        filmTitle
                    }
                    Text(
                        text = subtitle,
                        color = TextOnLightSecondary,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.testTag("seat_map_screening_subtitle")
                    )
                }

                OutlinedButton(
                    onClick = onOpenTextSeatSelector,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    border = BorderStroke(1.dp, SummaryGreyBorder),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("text_seat_selector_button")
                ) {
                    Icon(Icons.Filled.FormatListBulleted, contentDescription = null, tint = TextOnLightPrimary, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("List view", color = TextOnLightPrimary, style = MaterialTheme.typography.labelMedium)
                }
            }

            // Screening Cancelled Alert
            if (screening?.status == "CANCELLED") {
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = CinemaRedSoft,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, CinemaRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "This screening has been cancelled. Select another showtime on the left.",
                        color = CinemaRedDark,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // Hold Expiry Warning Banner
            if (state.showHoldExpiryWarning && state.holdSecondsRemaining != null) {
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = Color(0xFFFEF3C7),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFFD97706)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Hold expires in ${state.holdSecondsRemaining}s",
                            color = Color(0xFF92400E),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        TextButton(onClick = onExtendHold, modifier = Modifier.testTag("extend_hold_button")) {
                            Text("Extend (+2 min)", color = CinemaRedDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Curved SCREEN Arc
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.84f)
                    .height(30.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val path = Path().apply {
                        moveTo(0f, size.height * 0.72f)
                        quadraticTo(size.width / 2f, size.height * 0.12f, size.width, size.height * 0.72f)
                    }
                    drawPath(
                        path = path,
                        color = Color(0xFFD1D5DB),
                        style = Stroke(width = 16.dp.toPx(), cap = StrokeCap.Butt)
                    )
                }
                Text(
                    text = strings.screenLabel,
                    color = TextOnLightPrimary,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 3.sp
                )
            }

            Spacer(Modifier.height(8.dp))

            // Auditorium Seat Rows (A..J excluding I)
            val rowsByLabel = remember(state.seatMap) {
                state.seatMap.groupBy { it.rowLabel }
            }
            val rowOrder = listOf("A", "B", "C", "D", "E", "F", "G", "H", "J")

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(5.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                rowOrder.forEach { rowLabel ->
                    val rowSeats = rowsByLabel[rowLabel].orEmpty().sortedBy { it.seatNumber }
                    if (rowSeats.isNotEmpty()) {
                        val leftSeats = rowSeats.filter { it.seatNumber <= 5 }
                        val rightSeats = rowSeats.filter { it.seatNumber >= 6 }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = rowLabel,
                                color = TextOnLightPrimary,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.width(20.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                leftSeats.forEach { seat ->
                                    SeatTile(
                                        seat = seat,
                                        highContrast = state.accessibility.highContrastMode,
                                        onClick = { onSeatToggle(seat.seatCode) }
                                    )
                                }
                            }
                            Spacer(Modifier.width(18.dp)) // Center aisle
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                rightSeats.forEach { seat ->
                                    SeatTile(
                                        seat = seat,
                                        highContrast = state.accessibility.highContrastMode,
                                        onClick = { onSeatToggle(seat.seatCode) }
                                    )
                                }
                            }
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = rowLabel,
                                color = TextOnLightPrimary,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.width(20.dp)
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Legend Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LegendChip(color = Color.White, borderColor = SeatAvailableBorder, label = strings.available)
                LegendChip(color = CinemaRed, borderColor = CinemaRed, label = strings.selected)
                LegendChip(color = SeatUnavailableFill, borderColor = SeatUnavailableFill, label = strings.unavailable)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(width = 24.dp, height = 18.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(SeatAccessibleFill)
                            .border(1.dp, SeatAccessibleBorder, RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Accessible, contentDescription = null, tint = SeatAccessibleIcon, modifier = Modifier.size(13.dp))
                    }
                    Spacer(Modifier.width(5.dp))
                    Text(strings.accessibleSpace, color = TextOnLightSecondary, style = MaterialTheme.typography.bodySmall)
                }
            }

            Spacer(Modifier.height(10.dp))

            // Bottom Selected Summary Pill Bar
            Surface(
                color = SummaryGrey,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, SummaryGreyBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val selectedCodes = state.heldSeats.joinToString(", ") { it.seatCode }.ifEmpty { "None" }
                        val ticketSummary = buildTicketCategorySummary(state.heldSeats)

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f)
                                .clickable(enabled = state.heldSeats.isNotEmpty()) { showCategoryEditor = !showCategoryEditor }
                                .testTag("selected_seats_summary_bar")
                        ) {
                            Text(
                                text = "Selected: $selectedCodes",
                                color = TextOnLightPrimary,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "  |  $ticketSummary",
                                color = TextOnLightSecondary,
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (state.heldSeats.isNotEmpty()) {
                                Spacer(Modifier.width(6.dp))
                                Icon(
                                    imageVector = if (showCategoryEditor) Icons.Filled.ExpandLess else Icons.Filled.Edit,
                                    contentDescription = "Change ticket types",
                                    tint = CinemaRed,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Info, contentDescription = null, tint = TextOnLightSecondary, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(
                                text = strings.accessibleSpacesMarked,
                                color = TextOnLightSecondary,
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Expandable Ticket Category Editor (Adult / Child / Senior / Student)
                    if (showCategoryEditor && state.heldSeats.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        HorizontalDivider(color = SummaryGreyBorder)
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Set all:", style = MaterialTheme.typography.labelSmall, color = TextOnLightSecondary)
                            TicketCategory.entries.forEach { cat ->
                                AssistChip(
                                    onClick = { onAllSeatsCategoryChange(cat) },
                                    label = { Text(cat.displayName, fontSize = 11.sp) },
                                    modifier = Modifier.testTag("set_all_category_${cat.name}")
                                )
                            }
                        }
                        state.heldSeats.forEach { seat ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Seat ${seat.seatCode} (${if (seat.seatType == SeatType.ACCESSIBLE_WHEELCHAIR) "Wheelchair" else if (seat.seatType == SeatType.COMPANION) "Companion" else "Standard"})",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextOnLightPrimary
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    TicketCategory.entries.forEach { cat ->
                                        val isActive = seat.ticketCategory == cat
                                        FilterChip(
                                            selected = isActive,
                                            onClick = { onSeatCategoryChange(seat.seatCode, cat) },
                                            label = { Text(cat.displayName, fontSize = 10.sp) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SeatTile(
    seat: SeatDisplayItem,
    highContrast: Boolean,
    onClick: () -> Unit
) {
    val isAccessible = seat.seatType == SeatType.ACCESSIBLE_WHEELCHAIR
    val isCompanion = seat.seatType == SeatType.COMPANION

    val bgColor = when (seat.status) {
        SeatStatus.HELD_BY_THIS_SESSION -> if (highContrast) HighContrastRed else CinemaRed
        SeatStatus.HELD_BY_OTHER_SESSION -> SeatOtherHoldFill
        SeatStatus.SOLD, SeatStatus.UNAVAILABLE -> SeatUnavailableFill
        SeatStatus.AVAILABLE -> when {
            isAccessible || isCompanion -> SeatAccessibleFill
            else -> Color.White
        }
    }
    val borderColor = when (seat.status) {
        SeatStatus.HELD_BY_THIS_SESSION -> if (highContrast) HighContrastBlack else CinemaRedDark
        SeatStatus.HELD_BY_OTHER_SESSION -> Color(0xFFB45309)
        SeatStatus.SOLD, SeatStatus.UNAVAILABLE -> SeatUnavailableFill
        SeatStatus.AVAILABLE -> when {
            isAccessible || isCompanion -> SeatAccessibleBorder
            highContrast -> HighContrastBlack
            else -> SeatAvailableBorder
        }
    }
    val contentColor = when (seat.status) {
        SeatStatus.HELD_BY_THIS_SESSION, SeatStatus.SOLD, SeatStatus.UNAVAILABLE -> Color.White
        SeatStatus.HELD_BY_OTHER_SESSION -> Color.Black
        SeatStatus.AVAILABLE -> if (isAccessible || isCompanion) SeatAccessibleIcon else TextOnLightPrimary
    }

    val typeDescription = when (seat.seatType) {
        SeatType.ACCESSIBLE_WHEELCHAIR -> "Wheelchair accessible space"
        SeatType.COMPANION -> "Companion seat paired with ${seat.pairedAccessibleSeatCode}"
        SeatType.STANDARD -> "Standard seat"
    }
    val statusDescription = when (seat.status) {
        SeatStatus.AVAILABLE -> "Available"
        SeatStatus.HELD_BY_THIS_SESSION -> "Selected by you"
        SeatStatus.HELD_BY_OTHER_SESSION -> "Held by another customer"
        SeatStatus.SOLD -> "Sold"
        SeatStatus.UNAVAILABLE -> "Unavailable"
    }

    Box(
        modifier = Modifier
            .size(width = 34.dp, height = 28.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(width = if (highContrast) 1.5.dp else 1.dp, color = borderColor, shape = RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .semantics {
                contentDescription = "Seat ${seat.seatCode}, $typeDescription, $statusDescription"
            }
            .testTag("seat_tile_${seat.seatCode}"),
        contentAlignment = Alignment.Center
    ) {
        when {
            isAccessible -> {
                Icon(
                    imageVector = Icons.Filled.Accessible,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            isCompanion -> {
                Icon(
                    imageVector = Icons.Filled.People,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(15.dp)
                )
            }
            else -> {
                Text(
                    text = "${seat.seatNumber}",
                    color = contentColor,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = if (seat.status == SeatStatus.HELD_BY_THIS_SESSION) FontWeight.ExtraBold else FontWeight.SemiBold,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun LegendChip(color: Color, borderColor: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(width = 24.dp, height = 18.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(color)
                .border(1.dp, borderColor, RoundedCornerShape(4.dp))
        )
        Spacer(Modifier.width(5.dp))
        Text(label, color = TextOnLightSecondary, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun OrderSummaryAndMembershipColumn(
    state: KioskUiState,
    onContinueToExtras: () -> Unit,
    onSkipExtras: () -> Unit,
    onOpenMembership: () -> Unit,
    onClearMembership: () -> Unit,
    onOpenRefundTerms: () -> Unit
) {
    val strings = state.strings
    val screening = state.selectedScreening
    val film = state.selectedFilm
    val auditorium = state.selectedAuditorium
    val pricing = state.pricing
    val hasSeats = state.heldSeats.isNotEmpty()

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Pale-grey "Your visit" Order Summary Card
        Surface(
            color = SummaryGrey,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, SummaryGreyBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = strings.yourVisit,
                    color = TextOnLightPrimary,
                    style = MaterialTheme.typography.headlineSmall,
                    fontFamily = DisplayFontFamily,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(Modifier.height(10.dp))

                Row(verticalAlignment = Alignment.Top) {
                    FilmPosterArt(
                        posterKey = film?.posterKey ?: "orbital_dawn",
                        title = film?.title ?: "Orbital Dawn",
                        modifier = Modifier
                            .width(54.dp)
                            .height(72.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = film?.title ?: "Orbital Dawn",
                            color = TextOnLightPrimary,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        if (screening != null) {
                            Text(
                                text = "${screening.dateDisplayLabel} • ${screening.localTimeLabel}",
                                color = TextOnLightPrimary,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "${auditorium?.name ?: "Auditorium"} • ${screening.format}",
                                color = TextOnLightSecondary,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        val seatSummary = if (hasSeats) {
                            "Seats ${state.heldSeats.joinToString(", ") { it.seatCode }}"
                        } else {
                            "Select seats on the map"
                        }
                        Text(
                            text = seatSummary,
                            color = if (hasSeats) TextOnLightPrimary else CinemaRed,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.testTag("your_visit_seats_label")
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = SummaryGreyBorder)
                Spacer(Modifier.height(10.dp))

                if (hasSeats) {
                    pricing.ticketLineItems.forEach { item ->
                        SummaryPriceRow(
                            label = "${item.quantity} ${item.category.displayName.lowercase()} ${if (item.quantity == 1) "ticket" else "tickets"}",
                            amount = formatMinorUnits(item.totalCents, pricing.currency)
                        )
                    }
                    if (pricing.membershipDiscountCents > 0L) {
                        SummaryPriceRow(
                            label = pricing.membershipDiscountReason ?: "Membership discount",
                            amount = "-${formatMinorUnits(pricing.membershipDiscountCents, pricing.currency)}",
                            amountColor = StatusSuccess
                        )
                    }
                    SummaryPriceRow(
                        label = strings.bookingFeeLabel,
                        amount = if (pricing.bookingFeeCents == 0L && pricing.bookingFeeWaivedCents > 0L) "Waived"
                        else formatMinorUnits(pricing.bookingFeeCents, pricing.currency)
                    )
                    if (pricing.concessionSubtotalCents > 0L) {
                        SummaryPriceRow(
                            label = "Extras & concessions",
                            amount = formatMinorUnits(pricing.concessionSubtotalCents, pricing.currency)
                        )
                    }
                    SummaryPriceRow(
                        label = strings.illustrativeTaxLabel,
                        amount = formatMinorUnits(pricing.taxCents, pricing.currency)
                    )
                } else {
                    Text(
                        text = "Tap any white or accessible seat tile to hold tickets. Tap F7 & F8 for the 2-adult demo.",
                        color = TextOnLightSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(Modifier.height(10.dp))
                HorizontalDivider(color = SummaryGreyBorder)
                Spacer(Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.totalLabel,
                        color = TextOnLightPrimary,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${formatMinorUnits(pricing.grandTotalCents, pricing.currency)} ${pricing.currency}",
                        color = TextOnLightPrimary,
                        style = MaterialTheme.typography.titleLarge,
                        fontFamily = DisplayFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.testTag("your_visit_total_amount")
                    )
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    text = strings.illustrativePricesCaption,
                    color = TextOnLightSecondary,
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.sp
                )
                Text(
                    text = "Refund & cancellation terms",
                    color = CinemaRed,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier
                        .padding(top = 4.dp)
                        .clickable(onClick = onOpenRefundTerms)
                )

                Spacer(Modifier.height(12.dp))

                Button(
                    onClick = onContinueToExtras,
                    enabled = hasSeats && screening?.status == "ACTIVE",
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CinemaRed,
                        contentColor = Color.White,
                        disabledContainerColor = Color(0xFFD1D5DB),
                        disabledContentColor = Color(0xFF6B7280)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("continue_to_extras_button")
                ) {
                    Text(strings.continueToExtras, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                }

                Spacer(Modifier.height(8.dp))

                OutlinedButton(
                    onClick = onSkipExtras,
                    enabled = hasSeats && screening?.status == "ACTIVE",
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, TextOnLightPrimary.copy(alpha = if (hasSeats) 0.55f else 0.2f)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Color.White,
                        contentColor = TextOnLightPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("skip_extras_button")
                ) {
                    Text(strings.skipExtras, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Pale-grey Membership Card
        Surface(
            color = SummaryGrey,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, SummaryGreyBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(CinemaRed),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = state.brandConfig.brandBadgeText,
                            color = Color.White,
                            fontFamily = DisplayFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = state.brandConfig.membershipProgramLabel,
                            color = TextOnLightPrimary,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold
                        )
                        val mem = state.membership
                        Text(
                            text = if (mem == null) state.brandConfig.membershipSubtitle
                            else "${mem.tierName} • ${mem.displayAlias}",
                            color = if (mem == null) TextOnLightSecondary else StatusSuccess,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = if (mem == null) FontWeight.Normal else FontWeight.SemiBold
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                if (state.membership == null) {
                    OutlinedButton(
                        onClick = onOpenMembership,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, TextOnLightPrimary.copy(alpha = 0.5f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color.White,
                            contentColor = TextOnLightPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("add_membership_button")
                    ) {
                        Text(strings.addMembership, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = onOpenMembership,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Switch", fontWeight = FontWeight.SemiBold)
                        }
                        TextButton(onClick = onClearMembership) {
                            Text("Remove", color = CinemaRed)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SummaryPriceRow(
    label: String,
    amount: String,
    amountColor: Color = TextOnLightPrimary
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextOnLightPrimary, style = MaterialTheme.typography.bodyMedium)
        Text(amount, color = amountColor, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
}

private fun buildTicketCategorySummary(heldSeats: List<SeatDisplayItem>): String {
    if (heldSeats.isEmpty()) return "0 tickets"
    val grouped = heldSeats.groupingBy { it.ticketCategory }.eachCount()
    return grouped.entries.joinToString(", ") { (cat, count) ->
        "$count ${cat.displayName.lowercase()} ${if (count == 1) "ticket" else "tickets"}"
    }
}
