package com.example.data.repository

import com.example.data.adapters.*
import com.example.data.local.*
import com.example.domain.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

data class SeatUpdateEvent(
    val screeningId: String,
    val seatCode: String,
    val message: String,
    val timestampEpochMs: Long
)

data class BookingBundle(
    val booking: BookingEntity,
    val tickets: List<TicketEntity>,
    val concessions: List<ConcessionOrderItemEntity>,
    val payment: PaymentTransactionEntity?
)

data class AuthenticatedStaff(
    val staffId: String,
    val displayName: String,
    val role: StaffRole
)

class ReservationRepository(
    private val dao: CinemaDao,
    val clock: ClockProvider = SystemClockProvider(),
    private val membershipAdapter: MembershipAdapter = DemoMembershipAdapter(),
    private val paymentAdapter: PaymentTerminalAdapter = SimulatedPaymentTerminalAdapter(clock),
    private val printerAdapter: TicketPrinterAdapter = SimulatedThermalPrinterAdapter(),
    private val notificationAdapter: NotificationAdapter = DemoNotificationAdapter()
) {
    private val _seatEvents = MutableSharedFlow<SeatUpdateEvent>(extraBufferCapacity = 32)
    val seatEvents: SharedFlow<SeatUpdateEvent> = _seatEvents.asSharedFlow()

    private val staffCredentials = mapOf(
        "2410" to AuthenticatedStaff("STF-104", "Jordan (Attendant)", StaffRole.STAFF),
        "3615" to AuthenticatedStaff("SUP-209", "Elena (Supervisor)", StaffRole.SUPERVISOR),
        "4820" to AuthenticatedStaff("MGR-001", "Marcus (Manager)", StaffRole.MANAGER)
    )

    val cinemas: Flow<List<CinemaEntity>> = dao.observeCinemas()
    val films: Flow<List<FilmEntity>> = dao.observeFilms()
    val allScreenings: Flow<List<ScreeningEntity>> = dao.observeAllScreenings()
    val concessions: Flow<List<ConcessionProductEntity>> = dao.observeConcessions()
    val kioskConfig: Flow<KioskConfigEntity?> = dao.observeKioskConfig()
    val paymentTransactions: Flow<List<PaymentTransactionEntity>> = dao.observePaymentTransactions()
    val bookings: Flow<List<BookingEntity>> = dao.observeBookings()
    val auditLogs: Flow<List<AuditLogEntity>> = dao.observeAuditLogs()

    fun observeAuditoriums(cinemaId: String): Flow<List<AuditoriumEntity>> =
        dao.observeAuditoriums(cinemaId)

    fun observeSeatDefinitions(auditoriumId: String): Flow<List<SeatDefinitionEntity>> =
        dao.observeSeatDefinitions(auditoriumId)

    fun observeSeatLocks(screeningId: String): Flow<List<SeatLockEntity>> =
        dao.observeSeatLocksForScreening(screeningId)

    suspend fun initializeSeedData() {
        SeedDataInitializer.seedIfEmpty(dao, clock.nowMs())
    }

    /**
     * Background worker loop equivalent to server-side Celery/RQ expiry & reconciliation daemon.
     */
    fun startBackgroundWorker(scope: CoroutineScope): Job {
        return scope.launch {
            while (isActive) {
                runMaintenanceTick()
                delay(2000L)
            }
        }
    }

    suspend fun runMaintenanceTick(): Int {
        val now = clock.nowMs()
        return dao.pruneExpiredHoldsAtomically(now)
    }

    suspend fun holdSeat(
        screeningId: String,
        seatCode: String,
        sessionId: String,
        category: TicketCategory = TicketCategory.ADULT
    ): OperationResult<SeatHoldEntity> {
        val now = clock.nowMs()
        val config = dao.getKioskConfig()
        val durationSec = config?.holdDurationSeconds ?: 272
        val existingHolds = dao.getSessionLocks(screeningId, sessionId)
        // Keep session expiry aligned across seats in the same basket if already holding
        val targetExpiry = existingHolds.firstOrNull()?.expiresAtEpochMs
            ?.takeIf { it > now }
            ?: (now + durationSec * 1000L)
        val holdId = "HLD-${UUID.randomUUID().toString().take(8).uppercase()}"

        val screening = dao.getScreeningById(screeningId)
            ?: return OperationResult.Failure("SCREENING_MISSING", "Selected screening could not be found.")
        if (screening.status != "ACTIVE") {
            return OperationResult.Failure("SCREENING_CANCELLED", "This screening has been cancelled. Please choose another showtime.")
        }
        if (now < screening.salesOpenEpochMs || now > screening.salesCloseEpochMs) {
            return OperationResult.Failure("SALES_CLOSED", "Ticket sales are not open for this screening.")
        }

        val acquired = runCatching {
            dao.acquireSeatHoldAtomically(
                screeningId = screeningId,
                seatCode = seatCode,
                sessionId = sessionId,
                ticketCategory = category.name,
                holdId = holdId,
                nowMs = now,
                expiresAtEpochMs = targetExpiry
            )
        }.getOrElse { false }

        return if (acquired) {
            _seatEvents.tryEmit(SeatUpdateEvent(screeningId, seatCode, "Seat $seatCode held", now))
            val hold = dao.getActiveSessionHolds(screeningId, sessionId)
                .firstOrNull { it.seatCode == seatCode }
                ?: SeatHoldEntity(holdId, screeningId, seatCode, sessionId, category.name, now, targetExpiry, "ACTIVE")
            OperationResult.Success(hold)
        } else {
            val currentLock = dao.getSeatLock(screeningId, seatCode)
            val msg = when {
                currentLock?.lockType == "SOLD" -> "Seat $seatCode has already been purchased."
                currentLock?.lockType == "HOLD" && currentLock.ownerSessionId != sessionId ->
                    "Seat $seatCode was just taken by another customer session."
                else -> "Seat $seatCode is currently unavailable."
            }
            OperationResult.Failure("SEAT_CONFLICT", msg)
        }
    }

    suspend fun releaseSeat(
        screeningId: String,
        seatCode: String,
        sessionId: String
    ): OperationResult<Unit> {
        val released = dao.releaseSeatHoldAtomically(screeningId, seatCode, sessionId)
        return if (released) {
            _seatEvents.tryEmit(SeatUpdateEvent(screeningId, seatCode, "Seat $seatCode released", clock.nowMs()))
            OperationResult.Success(Unit)
        } else {
            OperationResult.Failure("RELEASE_DENIED", "Seat $seatCode could not be released right now.")
        }
    }

    suspend fun updateHeldSeatCategory(
        screeningId: String,
        seatCode: String,
        sessionId: String,
        category: TicketCategory
    ) {
        dao.updateActiveHoldCategory(screeningId, seatCode, sessionId, category.name)
        dao.updateSeatLockCategory(screeningId, seatCode, sessionId, category.name)
    }

    suspend fun extendSessionHolds(
        screeningId: String,
        sessionId: String,
        extraSeconds: Int = 120
    ): OperationResult<Long> {
        val now = clock.nowMs()
        dao.pruneExpiredHoldsAtomically(now)
        val activeHolds = dao.getActiveSessionHolds(screeningId, sessionId)
        if (activeHolds.isEmpty()) {
            return OperationResult.Failure("HOLD_EXPIRED", "Your seat hold has expired. Please re-select available seats.")
        }
        val config = dao.getKioskConfig()
        val maxExt = config?.maxHoldExtensions ?: 2
        if (activeHolds.any { it.extensionCount >= maxExt }) {
            return OperationResult.Failure("EXTENSION_LIMIT", "Maximum hold extensions reached for this session.")
        }
        val currentExpiry = activeHolds.maxOf { it.expiresAtEpochMs }
        val newExpiry = maxOf(currentExpiry, now) + extraSeconds * 1000L
        dao.extendSessionLockExpiry(screeningId, sessionId, newExpiry)
        dao.extendActiveHoldsExpiry(screeningId, sessionId, newExpiry)
        return OperationResult.Success(newExpiry)
    }

    suspend fun releaseSessionHolds(sessionId: String, screeningIdFilter: String? = null) {
        if (screeningIdFilter != null) {
            dao.releaseAllSessionHoldsAtomically(sessionId, screeningIdFilter)
        } else {
            dao.releaseAnyUnprotectedSessionHolds(sessionId)
        }
    }

    suspend fun simulateCompetingSessionHold(
        screeningId: String,
        preferredSeatCode: String = "F7"
    ): OperationResult<String> {
        val competitorId = "COMPETITOR_KIOSK_02"
        val result = holdSeat(screeningId, preferredSeatCode, competitorId, TicketCategory.ADULT)
        return when (result) {
            is OperationResult.Success -> OperationResult.Success(
                "Session B ($competitorId) locked seat $preferredSeatCode."
            )
            is OperationResult.Failure -> OperationResult.Failure(
                "COMPETITOR_BLOCKED",
                "Session B attempted to lock $preferredSeatCode: ${result.userMessage}"
            )
        }
    }

    suspend fun calculateServerPricing(
        screeningId: String,
        sessionId: String,
        concessionQuantities: Map<String, Int>,
        membership: MembershipAccount?
    ): PricingBreakdown {
        val screening = dao.getScreeningById(screeningId) ?: return PricingBreakdown()
        val locks = dao.getSessionLocks(screeningId, sessionId)
        val categories = locks.map {
            runCatching { TicketCategory.valueOf(it.ticketCategory) }.getOrDefault(TicketCategory.ADULT)
        }
        val concessionPairs = concessionQuantities.mapNotNull { (id, qty) ->
            if (qty <= 0) null
            else dao.getConcessionById(id)?.let { it to qty }
        }
        return PricingEngine.calculate(screening, categories, concessionPairs, membership)
    }

    suspend fun lookupMembership(identifier: String): MembershipLookupResult {
        val config = dao.getKioskConfig()
        val serviceOnline = config?.membershipServiceOnline ?: true
        return membershipAdapter.lookup(identifier, serviceOnline)
    }

    /**
     * Full idempotent checkout pipeline:
     * 1. Check idempotency key for existing booking or completed payment.
     * 2. Validate authoritative screening status, active seat holds, and concession stock.
     * 3. Protect held seats during payment processing so background worker does not release them mid-flight!
     * 4. Call PaymentTerminalAdapter, verify callback signature.
     * 5. Handle APPROVED, DECLINED, CANCELLED, UNCERTAIN, and ISSUANCE_FAILED explicitly.
     */
    suspend fun processCheckout(
        idempotencyKey: String,
        sessionId: String,
        screeningId: String,
        concessionQuantities: Map<String, Int>,
        membership: MembershipAccount?,
        collectionLocation: String,
        notificationChannel: String?,
        notificationTarget: String?,
        simulatedOutcome: PaymentOutcome
    ): CheckoutProcessingResult {
        val now = clock.nowMs()

        // Step 1: Idempotency short-circuit for duplicate requests
        val existingBooking = dao.getBookingByIdempotencyKey(idempotencyKey)
        if (existingBooking != null) {
            val tickets = dao.getTicketsForBooking(existingBooking.bookingRef)
            val concessions = dao.getConcessionItemsForBooking(existingBooking.bookingRef)
            val tx = dao.getPaymentById(existingBooking.paymentTransactionId)
            return CheckoutProcessingResult.Completed(
                BookingBundle(existingBooking, tickets, concessions, tx),
                printerWarning = if (existingBooking.printStatus == PrintStatus.PRINT_FAILED.name) {
                    "Tickets issued; printer offline. Use Reprint without re-charging."
                } else null,
                notificationResult = null
            )
        }

        // Check if there was a captured payment with failed issuance for this idempotency key (recovery path!)
        val priorPayment = dao.getPaymentByIdempotencyKey(idempotencyKey)
        if (priorPayment != null && priorPayment.status == PaymentStatus.CAPTURED.name && priorPayment.linkedBookingRef == null) {
            return retryIssuanceFromCapturedPayment(
                paymentTx = priorPayment,
                sessionId = sessionId,
                screeningId = screeningId,
                concessionQuantities = concessionQuantities,
                membership = membership,
                collectionLocation = collectionLocation,
                notificationChannel = notificationChannel,
                notificationTarget = notificationTarget
            )
        }

        // Step 2: Validate screening & holds
        dao.pruneExpiredHoldsAtomically(now)
        val screening = dao.getScreeningById(screeningId)
            ?: return CheckoutProcessingResult.Error("SCREENING_NOT_FOUND", "Screening no longer exists.")
        if (screening.status != "ACTIVE") {
            return CheckoutProcessingResult.Error("SCREENING_CANCELLED", "This screening was cancelled. Your card has not been charged.")
        }
        val locks = dao.getSessionLocks(screeningId, sessionId)
        if (locks.isEmpty()) {
            return CheckoutProcessingResult.Error("HOLD_EXPIRED", "Your seat hold has expired. Please select seats again.")
        }

        // Validate concession availability separately
        val concessionProducts = concessionQuantities.mapNotNull { (id, qty) ->
            if (qty <= 0) null
            else {
                val prod = dao.getConcessionById(id)
                if (prod == null || !prod.isAvailable || prod.stockCount < qty) {
                    return CheckoutProcessingResult.Error(
                        "CONCESSION_UNAVAILABLE",
                        "${prod?.name ?: "An extra item"} is no longer available in that quantity. Update extras or skip extras to keep your seats."
                    )
                }
                prod to qty
            }
        }

        val seatCategories = locks.map {
            runCatching { TicketCategory.valueOf(it.ticketCategory) }.getOrDefault(TicketCategory.ADULT)
        }
        val pricing = PricingEngine.calculate(screening, seatCategories, concessionProducts, membership)

        // Step 3: Protect holds during payment processing!
        val provisionalPaymentId = "PAY-LOCK-${idempotencyKey.takeLast(8)}"
        dao.protectLocksForPayment(screeningId, sessionId, provisionalPaymentId)

        val config = dao.getKioskConfig()
        val gatewayOnline = config?.paymentGatewayOnline ?: true
        val gatewayResult = paymentAdapter.processPayment(
            PaymentRequest(
                idempotencyKey = idempotencyKey,
                sessionId = sessionId,
                screeningId = screeningId,
                amountCents = pricing.grandTotalCents,
                currency = pricing.currency,
                simulatedOutcome = simulatedOutcome
            ),
            gatewayOnline = gatewayOnline
        )

        // Verify callback authenticity
        val verified = paymentAdapter.verifyCallbackSignature(
            gatewayResult.transactionId,
            gatewayResult.idempotencyKey,
            pricing.grandTotalCents,
            gatewayResult.status,
            gatewayResult.signatureToken
        )
        if (!verified) {
            dao.unprotectLocksForPayment(provisionalPaymentId)
            return CheckoutProcessingResult.Error(
                "CALLBACK_VERIFICATION_FAILED",
                "Payment callback signature verification failed. No booking created."
            )
        }

        val txEntity = PaymentTransactionEntity(
            transactionId = gatewayResult.transactionId,
            idempotencyKey = idempotencyKey,
            sessionId = sessionId,
            screeningId = screeningId,
            amountCents = pricing.grandTotalCents,
            currency = pricing.currency,
            status = gatewayResult.status.name,
            providerReference = gatewayResult.providerReference,
            signatureToken = gatewayResult.signatureToken,
            outcomeReason = gatewayResult.message,
            createdAtEpochMs = now,
            updatedAtEpochMs = now,
            needsReconciliation = (gatewayResult.status == PaymentStatus.UNCERTAIN)
        )
        if (dao.getPaymentByIdempotencyKey(idempotencyKey) == null) {
            dao.insertPaymentTransaction(txEntity)
        } else {
            dao.updatePaymentTransaction(txEntity)
        }

        return when (gatewayResult.status) {
            PaymentStatus.DECLINED, PaymentStatus.CANCELLED -> {
                dao.unprotectLocksForPayment(provisionalPaymentId)
                CheckoutProcessingResult.PaymentNotCompleted(
                    status = gatewayResult.status,
                    message = gatewayResult.message
                )
            }
            PaymentStatus.UNCERTAIN -> {
                // Keep seats protected (DO NOT release blindly while payment outcome is unresolved!)
                CheckoutProcessingResult.UncertainPayment(
                    transactionId = txEntity.transactionId,
                    message = "Payment status uncertain after terminal interruption. Your seats are protected pending reconciliation."
                )
            }
            PaymentStatus.CAPTURED -> {
                if (simulatedOutcome == PaymentOutcome.ISSUANCE_FAILED) {
                    // Simulate downstream failure AFTER payment capture: keep payment + seats protected for recovery!
                    dao.updatePaymentTransaction(txEntity.copy(needsReconciliation = true, outcomeReason = "Payment captured; ticket issuance timed out (awaiting recovery)."))
                    CheckoutProcessingResult.IssuanceRecoveryRequired(
                        transactionId = txEntity.transactionId,
                        message = "Payment of ${formatMinorUnits(pricing.grandTotalCents, pricing.currency)} was confirmed, but ticket issuance failed. Retry issuance without paying again."
                    )
                } else {
                    commitBookingFromCapturedPayment(
                        txEntity = txEntity,
                        screening = screening,
                        locks = locks,
                        concessionProducts = concessionProducts,
                        pricing = pricing,
                        membership = membership,
                        collectionLocation = collectionLocation,
                        notificationChannel = notificationChannel,
                        notificationTarget = notificationTarget,
                        now = now
                    )
                }
            }
            else -> {
                dao.unprotectLocksForPayment(provisionalPaymentId)
                CheckoutProcessingResult.Error("UNEXPECTED_PAYMENT_STATE", gatewayResult.message)
            }
        }
    }

    suspend fun retryIssuanceFromCapturedPayment(
        paymentTx: PaymentTransactionEntity,
        sessionId: String,
        screeningId: String,
        concessionQuantities: Map<String, Int>,
        membership: MembershipAccount?,
        collectionLocation: String,
        notificationChannel: String?,
        notificationTarget: String?
    ): CheckoutProcessingResult {
        val now = clock.nowMs()
        val screening = dao.getScreeningById(screeningId)
            ?: return CheckoutProcessingResult.Error("SCREENING_MISSING", "Screening not found.")
        val locks = dao.getSessionLocks(screeningId, sessionId)
        if (locks.isEmpty()) {
            return CheckoutProcessingResult.Error("LOCKS_MISSING", "Protected seat locks not found; please contact staff for refund.")
        }
        val concessionProducts = concessionQuantities.mapNotNull { (id, qty) ->
            if (qty <= 0) null else dao.getConcessionById(id)?.let { it to qty }
        }
        val categories = locks.map {
            runCatching { TicketCategory.valueOf(it.ticketCategory) }.getOrDefault(TicketCategory.ADULT)
        }
        val pricing = PricingEngine.calculate(screening, categories, concessionProducts, membership)
        return commitBookingFromCapturedPayment(
            txEntity = paymentTx,
            screening = screening,
            locks = locks,
            concessionProducts = concessionProducts,
            pricing = pricing,
            membership = membership,
            collectionLocation = collectionLocation,
            notificationChannel = notificationChannel,
            notificationTarget = notificationTarget,
            now = now
        )
    }

    private suspend fun commitBookingFromCapturedPayment(
        txEntity: PaymentTransactionEntity,
        screening: ScreeningEntity,
        locks: List<SeatLockEntity>,
        concessionProducts: List<Pair<ConcessionProductEntity, Int>>,
        pricing: PricingBreakdown,
        membership: MembershipAccount?,
        collectionLocation: String,
        notificationChannel: String?,
        notificationTarget: String?,
        now: Long
    ): CheckoutProcessingResult {
        val cinema = dao.getCinemaById(screening.cinemaId)
        val auditorium = dao.getAuditoriumById(screening.auditoriumId)
        val film = dao.getFilmById(screening.filmId)

        val bookingRef = "KIO-${(1000..9999).random()}-${UUID.randomUUID().toString().take(3).uppercase()}"
        val verificationPin = "${(1000..9999).random()}"

        val seatDefs = locks.associate { lock ->
            lock.seatCode to dao.getSeatDefinition(screening.auditoriumId, lock.seatCode)
        }

        val tickets = locks.sortedBy { it.seatCode }.mapIndexed { idx, lock ->
            val cat = runCatching { TicketCategory.valueOf(lock.ticketCategory) }.getOrDefault(TicketCategory.ADULT)
            val unitPrice = when (cat) {
                TicketCategory.ADULT -> screening.adultPriceCents
                TicketCategory.CHILD -> screening.childPriceCents
                TicketCategory.SENIOR -> screening.seniorPriceCents
                TicketCategory.STUDENT -> screening.studentPriceCents
            }
            val ticketId = "$bookingRef-T${idx + 1}"
            TicketEntity(
                ticketId = ticketId,
                bookingRef = bookingRef,
                screeningId = screening.id,
                seatCode = lock.seatCode,
                seatType = seatDefs[lock.seatCode]?.seatType ?: SeatType.STANDARD.name,
                ticketCategory = cat.name,
                unitPriceCents = unitPrice,
                qrToken = QrTokenSigner.generateToken(bookingRef, ticketId, screening.id),
                admissionStatus = AdmissionStatus.ISSUED.name,
                admittedAtEpochMs = null,
                admittedByStaffId = null,
                reissueCount = 0
            )
        }

        val concessionItems = concessionProducts.mapIndexed { idx, (prod, qty) ->
            ConcessionOrderItemEntity(
                id = "$bookingRef-C${idx + 1}",
                bookingRef = bookingRef,
                productId = prod.id,
                productName = prod.name,
                sizeLabel = prod.sizeLabel,
                quantity = qty,
                unitPriceCents = prod.priceCents,
                totalCents = prod.priceCents * qty,
                collectionLocation = prod.collectionLocation,
                fulfillmentStatus = FulfillmentStatus.PENDING.name
            )
        }

        val notifResult = if (!notificationChannel.isNullOrBlank() && !notificationTarget.isNullOrBlank()) {
            notificationAdapter.sendConfirmation(
                channel = notificationChannel,
                rawDestination = notificationTarget,
                bookingRef = bookingRef,
                screeningSummary = "${film?.title ?: "Film"} • ${screening.dateDisplayLabel} ${screening.localTimeLabel}"
            )
        } else null

        val booking = BookingEntity(
            bookingRef = bookingRef,
            verificationCode = verificationPin,
            idempotencyKey = txEntity.idempotencyKey,
            sessionId = txEntity.sessionId,
            screeningId = screening.id,
            cinemaName = "${cinema?.name ?: "Cinema"} • ${cinema?.city ?: ""}",
            auditoriumName = auditorium?.name ?: "Auditorium",
            filmTitle = film?.title ?: "Film",
            screeningDateTimeLabel = "${screening.dateDisplayLabel}, ${screening.localTimeLabel} • ${screening.format}",
            membershipAccountId = membership?.accountId,
            membershipDiscountCents = pricing.membershipDiscountCents,
            bookingFeeCents = pricing.bookingFeeCents,
            taxCents = pricing.taxCents,
            totalCents = pricing.grandTotalCents,
            currency = pricing.currency,
            paymentTransactionId = txEntity.transactionId,
            status = BookingStatus.CONFIRMED.name,
            ticketFulfillmentStatus = FulfillmentStatus.ISSUED.name,
            concessionFulfillmentStatus = if (concessionItems.isEmpty()) FulfillmentStatus.NOT_APPLICABLE.name else FulfillmentStatus.ISSUED.name,
            printStatus = PrintStatus.NOT_PRINTED.name,
            printAttempts = 0,
            collectionLocation = collectionLocation,
            notificationChannel = notifResult?.channel,
            maskedNotificationTarget = notifResult?.maskedTarget,
            createdAtEpochMs = now
        )

        dao.commitBookingAndTicketsAtomically(
            booking = booking,
            tickets = tickets,
            concessionItems = concessionItems,
            paymentTx = txEntity,
            heldSeats = locks,
            nowMs = now
        )

        // Step 6: Attempt hardware ticket print separately from booking commit!
        val config = dao.getKioskConfig()
        val printOutcome = printerAdapter.printTickets(bookingRef, tickets.size, config?.printerOnline ?: true)
        val updatedBooking = dao.getBookingByRef(bookingRef)!!.copy(
            printStatus = if (printOutcome.success) PrintStatus.PRINTED.name else PrintStatus.PRINT_FAILED.name,
            printAttempts = 1
        )
        dao.updateBooking(updatedBooking)

        val savedConcessions = dao.getConcessionItemsForBooking(bookingRef)
        return CheckoutProcessingResult.Completed(
            bundle = BookingBundle(updatedBooking, tickets, savedConcessions, dao.getPaymentById(txEntity.transactionId)),
            printerWarning = if (!printOutcome.success) printOutcome.message else null,
            notificationResult = notifResult
        )
    }

    suspend fun reprintBooking(bookingRef: String): OperationResult<BookingBundle> {
        val booking = dao.getBookingByRef(bookingRef)
            ?: return OperationResult.Failure("NOT_FOUND", "Booking $bookingRef not found.")
        if (booking.status == BookingStatus.REFUNDED.name || booking.status == BookingStatus.CANCELLED.name) {
            return OperationResult.Failure("BOOKING_INACTIVE", "Cannot print tickets for a ${booking.status.lowercase()} booking.")
        }
        val tickets = dao.getTicketsForBooking(bookingRef)
        val config = dao.getKioskConfig()
        val printResult = printerAdapter.printTickets(bookingRef, tickets.size, config?.printerOnline ?: true)
        val newStatus = if (printResult.success) PrintStatus.REPRINTED.name else PrintStatus.PRINT_FAILED.name
        val updated = booking.copy(
            printStatus = newStatus,
            printAttempts = booking.printAttempts + 1
        )
        dao.updateBooking(updated)
        return if (printResult.success) {
            OperationResult.Success(
                BookingBundle(
                    updated,
                    tickets,
                    dao.getConcessionItemsForBooking(bookingRef),
                    dao.getPaymentById(booking.paymentTransactionId)
                )
            )
        } else {
            OperationResult.Failure("PRINTER_OFFLINE", printResult.message)
        }
    }

    /**
     * Secure booking retrieval requiring BOTH bookingRef and verificationCode.
     */
    suspend fun lookupBooking(bookingRef: String, verificationCode: String): OperationResult<BookingBundle> {
        val ref = bookingRef.trim().uppercase()
        val pin = verificationCode.trim()
        if (ref.isBlank() || pin.isBlank()) {
            return OperationResult.Failure("MISSING_FIELDS", "Enter both your booking reference and 4-digit verification code.")
        }
        val booking = dao.getBookingByRef(ref)
            ?: return OperationResult.Failure("INVALID_CREDENTIALS", "No booking matched that reference and verification code.")
        if (booking.verificationCode != pin) {
            return OperationResult.Failure("INVALID_CREDENTIALS", "No booking matched that reference and verification code.")
        }
        return OperationResult.Success(
            BookingBundle(
                booking = booking,
                tickets = dao.getTicketsForBooking(ref),
                concessions = dao.getConcessionItemsForBooking(ref),
                payment = dao.getPaymentById(booking.paymentTransactionId)
            )
        )
    }

    // --- Staff & Administration Workspace (Authenticated + RBAC + Audited) ---

    fun authenticateStaff(pin: String): AuthenticatedStaff? = staffCredentials[pin.trim()]

    suspend fun admitTicket(qrTokenOrId: String, staff: AuthenticatedStaff): OperationResult<TicketEntity> {
        val now = clock.nowMs()
        val ticket = dao.getTicketByQrToken(qrTokenOrId.trim())
            ?: return OperationResult.Failure("INVALID_QR", "Unrecognized ticket QR token.")
        val booking = dao.getBookingByRef(ticket.bookingRef)
            ?: return OperationResult.Failure("BOOKING_MISSING", "Parent booking not found.")
        val screening = dao.getScreeningById(ticket.screeningId)
            ?: return OperationResult.Failure("SCREENING_MISSING", "Screening not found.")

        if (!QrTokenSigner.verifyToken(ticket.qrToken, ticket.screeningId)) {
            return OperationResult.Failure("SIGNATURE_INVALID", "QR signature verification failed.")
        }
        if (screening.status != "ACTIVE") {
            return OperationResult.Failure("SCREENING_CANCELLED", "Admission denied: screening was cancelled.")
        }
        if (ticket.admissionStatus == AdmissionStatus.REFUNDED.name || ticket.admissionStatus == AdmissionStatus.CANCELLED.name) {
            return OperationResult.Failure("TICKET_VOID", "Admission denied: ticket status is ${ticket.admissionStatus}.")
        }
        if (ticket.admissionStatus == AdmissionStatus.ADMITTED.name) {
            return OperationResult.Failure(
                "REPEAT_SCAN",
                "REPEAT SCAN ALERT: Seat ${ticket.seatCode} (${booking.bookingRef}) was already admitted."
            )
        }

        val updatedTicket = ticket.copy(
            admissionStatus = AdmissionStatus.ADMITTED.name,
            admittedAtEpochMs = now,
            admittedByStaffId = staff.staffId
        )
        dao.updateTicket(updatedTicket)
        dao.insertAuditLog(
            AuditLogEntity(
                id = "AUD-$now-${ticket.ticketId}",
                timestampEpochMs = now,
                actorStaffId = staff.staffId,
                actorRole = staff.role.name,
                actionType = "TICKET_ADMITTED",
                targetId = ticket.ticketId,
                details = "Admitted ${ticket.seatCode} for ${booking.bookingRef}"
            )
        )
        return OperationResult.Success(updatedTicket)
    }

    suspend fun reverseTicketAdmission(ticketId: String, staff: AuthenticatedStaff): OperationResult<TicketEntity> {
        if (staff.role.level < StaffRole.SUPERVISOR.level) {
            return OperationResult.Failure("FORBIDDEN", "Supervisor or Manager permission required to reverse admission.")
        }
        val tickets = dao.getTicketByQrToken(ticketId)
        val target = tickets ?: return OperationResult.Failure("NOT_FOUND", "Ticket not found by QR token.")
        if (target.admissionStatus != AdmissionStatus.ADMITTED.name) {
            return OperationResult.Failure("NOT_ADMITTED", "Ticket is currently ${target.admissionStatus}.")
        }
        val now = clock.nowMs()
        val updated = target.copy(admissionStatus = AdmissionStatus.REVERSED.name)
        dao.updateTicket(updated)
        dao.insertAuditLog(
            AuditLogEntity(
                id = "AUD-$now-${target.ticketId}-REV",
                timestampEpochMs = now,
                actorStaffId = staff.staffId,
                actorRole = staff.role.name,
                actionType = "ADMISSION_REVERSED",
                targetId = target.ticketId,
                details = "Admission reversed for seat ${target.seatCode} (${target.bookingRef})"
            )
        )
        return OperationResult.Success(updated)
    }

    suspend fun reissueTicket(bookingRef: String, staff: AuthenticatedStaff): OperationResult<BookingBundle> {
        if (staff.role.level < StaffRole.SUPERVISOR.level) {
            return OperationResult.Failure("FORBIDDEN", "Supervisor or Manager permission required to reissue tickets.")
        }
        val booking = dao.getBookingByRef(bookingRef)
            ?: return OperationResult.Failure("NOT_FOUND", "Booking not found.")
        val tickets = dao.getTicketsForBooking(bookingRef)
        val now = clock.nowMs()
        val reissued = tickets.map { t ->
            t.copy(
                qrToken = QrTokenSigner.generateToken(bookingRef, "${t.ticketId}-R${t.reissueCount + 1}", t.screeningId),
                reissueCount = t.reissueCount + 1
            )
        }
        reissued.forEach { dao.updateTicket(it) }
        dao.insertAuditLog(
            AuditLogEntity(
                id = "AUD-$now-$bookingRef-REISSUE",
                timestampEpochMs = now,
                actorStaffId = staff.staffId,
                actorRole = staff.role.name,
                actionType = "TICKETS_REISSUED",
                targetId = bookingRef,
                details = "Generated fresh QR tokens for ${reissued.size} ticket(s)."
            )
        )
        return OperationResult.Success(
            BookingBundle(booking, reissued, dao.getConcessionItemsForBooking(bookingRef), dao.getPaymentById(booking.paymentTransactionId))
        )
    }

    suspend fun refundBooking(bookingRef: String, reason: String, staff: AuthenticatedStaff): OperationResult<Unit> {
        if (staff.role.level < StaffRole.SUPERVISOR.level) {
            return OperationResult.Failure("FORBIDDEN", "Supervisor or Manager permission required for refunds.")
        }
        val booking = dao.getBookingByRef(bookingRef)
            ?: return OperationResult.Failure("NOT_FOUND", "Booking not found.")
        dao.getPaymentById(booking.paymentTransactionId)?.let { tx ->
            paymentAdapter.reverseOrRefund(tx.providerReference, tx.amountCents)
        }
        val ok = dao.refundBookingAtomically(bookingRef, staff.staffId, staff.role.name, reason, clock.nowMs())
        return if (ok) OperationResult.Success(Unit)
        else OperationResult.Failure("REFUND_FAILED", "Booking could not be refunded (may already be refunded).")
    }

    suspend fun toggleSeatMaintenance(
        auditoriumId: String,
        seatCode: String,
        blocked: Boolean,
        staff: AuthenticatedStaff
    ): OperationResult<Unit> {
        if (staff.role.level < StaffRole.STAFF.level) {
            return OperationResult.Failure("FORBIDDEN", "Authentication required.")
        }
        dao.setSeatMaintenanceBlocked(auditoriumId, seatCode, blocked)
        val now = clock.nowMs()
        dao.insertAuditLog(
            AuditLogEntity(
                id = "AUD-$now-$seatCode",
                timestampEpochMs = now,
                actorStaffId = staff.staffId,
                actorRole = staff.role.name,
                actionType = "SEAT_OVERRIDE",
                targetId = "$auditoriumId:$seatCode",
                details = if (blocked) "Marked maintenance unavailable" else "Restored seat to available"
            )
        )
        return OperationResult.Success(Unit)
    }

    suspend fun cancelScreening(screeningId: String, staff: AuthenticatedStaff): OperationResult<Unit> {
        if (staff.role.level < StaffRole.MANAGER.level) {
            return OperationResult.Failure("FORBIDDEN", "Manager permission required to cancel a screening.")
        }
        dao.updateScreeningStatus(screeningId, "CANCELLED")
        val now = clock.nowMs()
        dao.insertAuditLog(
            AuditLogEntity(
                id = "AUD-$now-$screeningId",
                timestampEpochMs = now,
                actorStaffId = staff.staffId,
                actorRole = staff.role.name,
                actionType = "SCREENING_CANCELLED",
                targetId = screeningId,
                details = "Screening cancelled by ${staff.displayName}"
            )
        )
        return OperationResult.Success(Unit)
    }

    suspend fun restoreScreening(screeningId: String, staff: AuthenticatedStaff): OperationResult<Unit> {
        if (staff.role.level < StaffRole.MANAGER.level) {
            return OperationResult.Failure("FORBIDDEN", "Manager permission required.")
        }
        dao.updateScreeningStatus(screeningId, "ACTIVE")
        val now = clock.nowMs()
        dao.insertAuditLog(
            AuditLogEntity(
                id = "AUD-$now-$screeningId-REST",
                timestampEpochMs = now,
                actorStaffId = staff.staffId,
                actorRole = staff.role.name,
                actionType = "SCREENING_RESTORED",
                targetId = screeningId,
                details = "Screening restored to ACTIVE"
            )
        )
        return OperationResult.Success(Unit)
    }

    suspend fun updateScreeningPricing(
        screeningId: String,
        adultPriceCents: Long,
        bookingFeeCents: Long,
        taxRateBps: Int,
        staff: AuthenticatedStaff
    ): OperationResult<Unit> {
        if (staff.role.level < StaffRole.MANAGER.level) {
            return OperationResult.Failure("FORBIDDEN", "Manager permission required to change prices.")
        }
        dao.updateScreeningPricing(screeningId, adultPriceCents, bookingFeeCents, taxRateBps)
        val now = clock.nowMs()
        dao.insertAuditLog(
            AuditLogEntity(
                id = "AUD-$now-$screeningId-PRC",
                timestampEpochMs = now,
                actorStaffId = staff.staffId,
                actorRole = staff.role.name,
                actionType = "PRICE_CHANGE",
                targetId = screeningId,
                details = "Updated adult=$adultPriceCents¢ fee=$bookingFeeCents¢ tax=${taxRateBps}bps"
            )
        )
        return OperationResult.Success(Unit)
    }

    suspend fun updateConcessionStock(
        productId: String,
        stockCount: Int,
        isAvailable: Boolean,
        staff: AuthenticatedStaff
    ): OperationResult<Unit> {
        dao.setConcessionStock(productId, stockCount, isAvailable)
        val now = clock.nowMs()
        dao.insertAuditLog(
            AuditLogEntity(
                id = "AUD-$now-$productId",
                timestampEpochMs = now,
                actorStaffId = staff.staffId,
                actorRole = staff.role.name,
                actionType = "CONCESSION_STOCK_UPDATE",
                targetId = productId,
                details = "Stock set to $stockCount (available=$isAvailable)"
            )
        )
        return OperationResult.Success(Unit)
    }

    suspend fun setPrinterOnline(online: Boolean, staff: AuthenticatedStaff? = null) {
        val current = dao.getKioskConfig() ?: return
        val updated = current.copy(
            printerOnline = online,
            printerStatusMessage = if (online) "Thermal Ticket Printer Online (Paper 88%)" else "Printer Error: Thermal Paper Jam / Offline"
        )
        dao.upsertKioskConfig(updated)
        if (staff != null) {
            val now = clock.nowMs()
            dao.insertAuditLog(
                AuditLogEntity(
                    id = "AUD-$now-PRT",
                    timestampEpochMs = now,
                    actorStaffId = staff.staffId,
                    actorRole = staff.role.name,
                    actionType = "PRINTER_HEALTH_TOGGLE",
                    targetId = "KIO-PRT-01",
                    details = "Printer online=$online"
                )
            )
        }
    }

    suspend fun setMembershipServiceOnline(online: Boolean) {
        val current = dao.getKioskConfig() ?: return
        dao.upsertKioskConfig(current.copy(membershipServiceOnline = online))
    }

    suspend fun reconcileUncertainPayment(
        transactionId: String,
        reverseInsteadOfCapture: Boolean,
        staff: AuthenticatedStaff? = null
    ): OperationResult<String> {
        val tx = dao.getPaymentById(transactionId)
            ?: return OperationResult.Failure("TX_MISSING", "Transaction $transactionId not found.")
        val now = clock.nowMs()
        return if (reverseInsteadOfCapture) {
            paymentAdapter.reverseOrRefund(tx.providerReference, tx.amountCents)
            dao.updatePaymentTransaction(
                tx.copy(
                    status = PaymentStatus.REVERSED.name,
                    needsReconciliation = false,
                    updatedAtEpochMs = now,
                    outcomeReason = "Authorization reversed during reconciliation; protected seats released."
                )
            )
            dao.unprotectLocksForPayment(tx.transactionId)
            dao.unprotectSessionLocks(tx.screeningId, tx.sessionId)
            dao.releaseAnyUnprotectedSessionHolds(tx.sessionId)
            if (staff != null) {
                dao.insertAuditLog(
                    AuditLogEntity(
                        id = "AUD-$now-$transactionId-REV",
                        timestampEpochMs = now,
                        actorStaffId = staff.staffId,
                        actorRole = staff.role.name,
                        actionType = "PAYMENT_REVERSED",
                        targetId = transactionId,
                        details = "Reversed uncertain payment and released seat holds"
                    )
                )
            }
            OperationResult.Success("Payment $transactionId reversed and protected seats released.")
        } else {
            val recon = paymentAdapter.reconcileTransaction(tx.transactionId, tx.amountCents, tx.idempotencyKey)
            dao.updatePaymentTransaction(
                tx.copy(
                    status = recon.status.name,
                    providerReference = recon.providerReference,
                    signatureToken = recon.signatureToken,
                    needsReconciliation = false,
                    updatedAtEpochMs = now,
                    outcomeReason = recon.message
                )
            )
            // Complete booking if seats are still held for this session
            val locks = dao.getSessionLocks(tx.screeningId, tx.sessionId)
            val screening = dao.getScreeningById(tx.screeningId)
            if (locks.isNotEmpty() && screening != null && tx.linkedBookingRef == null) {
                val categories = locks.map { runCatching { TicketCategory.valueOf(it.ticketCategory) }.getOrDefault(TicketCategory.ADULT) }
                val pricing = PricingEngine.calculate(screening, categories, emptyList(), null)
                val res = commitBookingFromCapturedPayment(
                    txEntity = dao.getPaymentById(tx.transactionId)!!,
                    screening = screening,
                    locks = locks,
                    concessionProducts = emptyList(),
                    pricing = pricing,
                    membership = null,
                    collectionLocation = "Lobby Express Counter A",
                    notificationChannel = null,
                    notificationTarget = null,
                    now = now
                )
                if (res is CheckoutProcessingResult.Completed) {
                    return OperationResult.Success("Reconciled & issued booking ${res.bundle.booking.bookingRef}.")
                }
            }
            OperationResult.Success("Payment $transactionId reconciled (${recon.status.name}).")
        }
    }
}

sealed class CheckoutProcessingResult {
    data class Completed(
        val bundle: BookingBundle,
        val printerWarning: String?,
        val notificationResult: NotificationDispatchResult?
    ) : CheckoutProcessingResult()

    data class PaymentNotCompleted(val status: PaymentStatus, val message: String) : CheckoutProcessingResult()
    data class UncertainPayment(val transactionId: String, val message: String) : CheckoutProcessingResult()
    data class IssuanceRecoveryRequired(val transactionId: String, val message: String) : CheckoutProcessingResult()
    data class Error(val code: String, val message: String) : CheckoutProcessingResult()
}
