package com.example.data.adapters

import com.example.data.local.ConcessionProductEntity
import com.example.data.local.ScreeningEntity
import com.example.domain.model.*
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

interface ClockProvider {
    fun nowMs(): Long
}

class SystemClockProvider : ClockProvider {
    override fun nowMs(): Long = System.currentTimeMillis()
}

class ControllableClockProvider(private var currentMs: Long) : ClockProvider {
    override fun nowMs(): Long = currentMs
    fun advanceBy(deltaMs: Long) {
        currentMs += deltaMs
    }
    fun setNow(epochMs: Long) {
        currentMs = epochMs
    }
}

object PricingEngine {
    /**
     * Authoritative minor-unit server pricing calculation with deterministic discount precedence:
     * 1. Compute ticket base subtotal by ticket category.
     * 2. Apply membership percentage ticket discount (if any), then flat membership discount (capped at remaining ticket subtotal).
     * 3. Apply booking fees (and waive booking fee if membership grants fee waiver).
     * 4. Compute illustrative ticket tax on discounted ticket subtotal (half-up rounding).
     * 5. Compute concession subtotal + concession tax independently.
     */
    fun calculate(
        screening: ScreeningEntity,
        seatCategories: List<TicketCategory>,
        concessions: List<Pair<ConcessionProductEntity, Int>>,
        membership: MembershipAccount?
    ): PricingBreakdown {
        val grouped = seatCategories.groupingBy { it }.eachCount()
        val ticketLineItems = TicketCategory.entries.mapNotNull { cat ->
            val qty = grouped[cat] ?: 0
            if (qty <= 0) null
            else {
                val unit = when (cat) {
                    TicketCategory.ADULT -> screening.adultPriceCents
                    TicketCategory.CHILD -> screening.childPriceCents
                    TicketCategory.SENIOR -> screening.seniorPriceCents
                    TicketCategory.STUDENT -> screening.studentPriceCents
                }
                TicketLineItem(cat, qty, unit, unit * qty)
            }
        }

        val ticketSubtotal = ticketLineItems.sumOf { it.totalCents }
        val totalTicketCount = seatCategories.size

        // Discount precedence: % discount on tickets first, then flat order discount
        var membershipDiscount = 0L
        var discountReason: String? = null
        if (membership != null && ticketSubtotal > 0L) {
            val pctDiscount = if (membership.ticketDiscountBps > 0) {
                (ticketSubtotal * membership.ticketDiscountBps + 5000L) / 10000L
            } else 0L
            val remainingAfterPct = (ticketSubtotal - pctDiscount).coerceAtLeast(0L)
            val flatDiscount = membership.flatOrderDiscountCents.coerceAtMost(remainingAfterPct)
            membershipDiscount = pctDiscount + flatDiscount
            if (membershipDiscount > 0L) {
                discountReason = "${membership.tierName} benefit applied"
            }
        }

        val discountedTicketSubtotal = (ticketSubtotal - membershipDiscount).coerceAtLeast(0L)
        val rawBookingFee = screening.bookingFeePerTicketCents * totalTicketCount
        val waivedBookingFee = if (membership?.waivesBookingFee == true) rawBookingFee else 0L
        val netBookingFee = (rawBookingFee - waivedBookingFee).coerceAtLeast(0L)

        val ticketTax = if (discountedTicketSubtotal > 0L) {
            (discountedTicketSubtotal * screening.taxRateBps + 5000L) / 10000L
        } else 0L

        val concessionLineItems = concessions.filter { it.second > 0 }.map { (prod, qty) ->
            val lineTotal = prod.priceCents * qty
            val lineTax = (lineTotal * prod.taxRateBps + 5000L) / 10000L
            ConcessionLineItem(
                productId = prod.id,
                name = prod.name,
                sizeLabel = prod.sizeLabel,
                quantity = qty,
                unitPriceCents = prod.priceCents,
                totalCents = lineTotal,
                taxCents = lineTax,
                collectionLocation = prod.collectionLocation
            )
        }
        val concessionSubtotal = concessionLineItems.sumOf { it.totalCents }
        val concessionTax = concessionLineItems.sumOf { it.taxCents }

        val totalTax = ticketTax + concessionTax
        val grandTotal = discountedTicketSubtotal + netBookingFee + concessionSubtotal + totalTax

        return PricingBreakdown(
            ticketLineItems = ticketLineItems,
            ticketSubtotalCents = ticketSubtotal,
            membershipDiscountCents = membershipDiscount,
            membershipDiscountReason = discountReason,
            bookingFeeCents = netBookingFee,
            bookingFeeWaivedCents = waivedBookingFee,
            concessionLineItems = concessionLineItems,
            concessionSubtotalCents = concessionSubtotal,
            taxCents = totalTax,
            grandTotalCents = grandTotal,
            currency = screening.currency
        )
    }
}

interface MembershipAdapter {
    suspend fun lookup(identifier: String, serviceOnline: Boolean): MembershipLookupResult
}

class DemoMembershipAdapter : MembershipAdapter {
    private val sampleAccounts = mapOf(
        "CLUB-1001" to MembershipAccount(
            accountId = "MEM-1001",
            maskedMemberNumber = "•••• 1001",
            tierName = "Gold Circle (Demo)",
            displayAlias = "Member •••• 1001",
            ticketDiscountBps = 1500, // 15%
            flatOrderDiscountCents = 0L,
            waivesBookingFee = true,
            freeSmallPopcornEligible = true
        ),
        "CLUB-2002" to MembershipAccount(
            accountId = "MEM-2002",
            maskedMemberNumber = "•••• 2002",
            tierName = "Silver Pass (Demo)",
            displayAlias = "Member •••• 2002",
            ticketDiscountBps = 0,
            flatOrderDiscountCents = 300L,
            waivesBookingFee = false,
            freeSmallPopcornEligible = false
        ),
        "CLUB-3003" to MembershipAccount(
            accountId = "MEM-3003",
            maskedMemberNumber = "•••• 3003",
            tierName = "Insiders Tier (Demo)",
            displayAlias = "Member •••• 3003",
            ticketDiscountBps = 1000,
            flatOrderDiscountCents = 0L,
            waivesBookingFee = false,
            freeSmallPopcornEligible = true
        )
    )

    override suspend fun lookup(identifier: String, serviceOnline: Boolean): MembershipLookupResult {
        val normalized = identifier.trim().uppercase()
        if (!serviceOnline || normalized == "ERR-UNAVAIL") {
            return MembershipLookupResult.ServiceUnavailable(
                "Membership service is temporarily unavailable. You can continue with Guest Checkout."
            )
        }
        val mappedKey = when (normalized) {
            "1001", "CLUB-1001" -> "CLUB-1001"
            "2002", "CLUB-2002" -> "CLUB-2002"
            "3003", "CLUB-3003" -> "CLUB-3003"
            else -> normalized
        }
        val found = sampleAccounts[mappedKey]
        return if (found != null) {
            MembershipLookupResult.Found(found)
        } else {
            MembershipLookupResult.NotFound(identifier)
        }
    }
}

interface PaymentTerminalAdapter {
    suspend fun processPayment(request: PaymentRequest, gatewayOnline: Boolean): PaymentGatewayResult
    fun verifyCallbackSignature(
        transactionId: String,
        idempotencyKey: String,
        amountCents: Long,
        status: PaymentStatus,
        signatureToken: String
    ): Boolean
    suspend fun reconcileTransaction(transactionId: String, amountCents: Long, idempotencyKey: String): PaymentGatewayResult
    suspend fun reverseOrRefund(providerReference: String, amountCents: Long): Boolean
}

class SimulatedPaymentTerminalAdapter(
    private val clock: ClockProvider
) : PaymentTerminalAdapter {
    // Demo-only HMAC secret for verifying simulated terminal callback payloads
    private val terminalSigningSecret = "DEMO_TERMINAL_HMAC_KEY_LOCAL_ONLY"

    override suspend fun processPayment(request: PaymentRequest, gatewayOnline: Boolean): PaymentGatewayResult {
        val txId = "PAY-${request.idempotencyKey.takeLast(8).uppercase()}-${clock.nowMs() % 10000}"
        val providerRef = "SIM-AUTH-${clock.nowMs() % 1_000_000}"

        if (!gatewayOnline) {
            val sig = signCallback(txId, request.idempotencyKey, request.amountCents, PaymentStatus.UNCERTAIN)
            return PaymentGatewayResult(
                transactionId = txId,
                idempotencyKey = request.idempotencyKey,
                status = PaymentStatus.UNCERTAIN,
                providerReference = providerRef,
                callbackVerified = true,
                signatureToken = sig,
                message = "Payment terminal gateway unreachable. Transaction held for safe reconciliation."
            )
        }

        val status = when (request.simulatedOutcome) {
            PaymentOutcome.APPROVED, PaymentOutcome.ISSUANCE_FAILED -> PaymentStatus.CAPTURED
            PaymentOutcome.DECLINED -> PaymentStatus.DECLINED
            PaymentOutcome.CANCELLED -> PaymentStatus.CANCELLED
            PaymentOutcome.UNCERTAIN -> PaymentStatus.UNCERTAIN
        }
        val message = when (request.simulatedOutcome) {
            PaymentOutcome.APPROVED -> "Simulated terminal approved & captured ${formatMinorUnits(request.amountCents, request.currency)}."
            PaymentOutcome.ISSUANCE_FAILED -> "Payment captured, simulating downstream ticket-issuance timeout."
            PaymentOutcome.DECLINED -> "Simulated card declined (insufficient funds). Your seat hold is still active."
            PaymentOutcome.CANCELLED -> "Customer cancelled at payment terminal. Your seat hold is preserved."
            PaymentOutcome.UNCERTAIN -> "Terminal connection interrupted after authorization. Outcome requires reconciliation."
        }
        val sig = signCallback(txId, request.idempotencyKey, request.amountCents, status)
        return PaymentGatewayResult(
            transactionId = txId,
            idempotencyKey = request.idempotencyKey,
            status = status,
            providerReference = providerRef,
            callbackVerified = true,
            signatureToken = sig,
            message = message
        )
    }

    override fun verifyCallbackSignature(
        transactionId: String,
        idempotencyKey: String,
        amountCents: Long,
        status: PaymentStatus,
        signatureToken: String
    ): Boolean {
        val expected = signCallback(transactionId, idempotencyKey, amountCents, status)
        return MessageDigest.isEqual(expected.toByteArray(), signatureToken.toByteArray())
    }

    override suspend fun reconcileTransaction(
        transactionId: String,
        amountCents: Long,
        idempotencyKey: String
    ): PaymentGatewayResult {
        val sig = signCallback(transactionId, idempotencyKey, amountCents, PaymentStatus.CAPTURED)
        return PaymentGatewayResult(
            transactionId = transactionId,
            idempotencyKey = idempotencyKey,
            status = PaymentStatus.CAPTURED,
            providerReference = "RECON-${transactionId.takeLast(6)}",
            callbackVerified = true,
            signatureToken = sig,
            message = "Reconciliation confirmed capture with simulated terminal."
        )
    }

    override suspend fun reverseOrRefund(providerReference: String, amountCents: Long): Boolean = true

    private fun signCallback(txId: String, key: String, amountCents: Long, status: PaymentStatus): String {
        val payload = "$txId|$key|$amountCents|${status.name}"
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(terminalSigningSecret.toByteArray(), "HmacSHA256"))
        return mac.doFinal(payload.toByteArray()).joinToString("") { "%02x".format(it) }.take(24)
    }
}

interface TicketPrinterAdapter {
    suspend fun printTickets(bookingRef: String, ticketCount: Int, printerOnline: Boolean): PrintDispatchResult
}

class SimulatedThermalPrinterAdapter : TicketPrinterAdapter {
    override suspend fun printTickets(
        bookingRef: String,
        ticketCount: Int,
        printerOnline: Boolean
    ): PrintDispatchResult {
        return if (printerOnline) {
            PrintDispatchResult(
                success = true,
                printerId = "KIO-PRT-01",
                message = "Printed $ticketCount ticket(s) for $bookingRef on thermal printer KIO-PRT-01."
            )
        } else {
            PrintDispatchResult(
                success = false,
                printerId = "KIO-PRT-01",
                message = "Thermal printer KIO-PRT-01 is offline or out of paper. Tickets were created safely — reprint without re-charging."
            )
        }
    }
}

interface NotificationAdapter {
    suspend fun sendConfirmation(
        channel: String,
        rawDestination: String,
        bookingRef: String,
        screeningSummary: String
    ): NotificationDispatchResult
}

class DemoNotificationAdapter : NotificationAdapter {
    override suspend fun sendConfirmation(
        channel: String,
        rawDestination: String,
        bookingRef: String,
        screeningSummary: String
    ): NotificationDispatchResult {
        val trimmed = rawDestination.trim()
        if (trimmed.isEmpty()) {
            return NotificationDispatchResult(false, channel, "", "No notification target provided.")
        }
        val masked = if (trimmed.contains("@")) {
            val parts = trimmed.split("@")
            val user = parts.firstOrNull().orEmpty()
            val prefix = user.take(2)
            "$prefix***@${parts.getOrElse(1) { "example.com" }}"
        } else {
            "•••-•••-${trimmed.takeLast(4)}"
        }
        return NotificationDispatchResult(
            sent = true,
            channel = channel,
            maskedTarget = masked,
            summary = "Simulated $channel receipt sent to $masked for $bookingRef ($screeningSummary)."
        )
    }
}

object QrTokenSigner {
    private const val QR_SIGNING_SECRET = "DEMO_QR_OFFLINE_VERIFY_SECRET_V1"

    /**
     * Produces an opaque, privacy-preserving signed ticket token with ZERO personal data.
     */
    fun generateToken(bookingRef: String, ticketId: String, screeningId: String): String {
        val payload = "$bookingRef|$ticketId|$screeningId"
        val sig = sign(payload).take(12).uppercase()
        return "TKT|$bookingRef|$ticketId|$sig"
    }

    fun verifyToken(qrToken: String, expectedScreeningId: String): Boolean {
        val parts = qrToken.split("|")
        if (parts.size != 4 || parts[0] != "TKT") return false
        val bookingRef = parts[1]
        val ticketId = parts[2]
        val providedSig = parts[3]
        val expectedSig = sign("$bookingRef|$ticketId|$expectedScreeningId").take(12).uppercase()
        return MessageDigest.isEqual(providedSig.toByteArray(), expectedSig.toByteArray())
    }

    private fun sign(payload: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(QR_SIGNING_SECRET.toByteArray(), "HmacSHA256"))
        return mac.doFinal(payload.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}
