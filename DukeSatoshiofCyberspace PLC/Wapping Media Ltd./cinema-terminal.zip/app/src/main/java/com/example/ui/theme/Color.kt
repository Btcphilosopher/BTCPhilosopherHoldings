package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Kiosk Core Palette (faithful to mockup)
val KioskBlack = Color(0xFF0A0B0E)
val KioskCharcoal = Color(0xFF141519)
val KioskCharcoalElevated = Color(0xFF1E2027)
val KioskCharcoalBorder = Color(0xFF2D303A)

val CinemaRed = Color(0xFFE51923)
val CinemaRedDark = Color(0xFFB9121B)
val CinemaRedSoft = Color(0xFFFFEBEC)

val WorkspaceWhite = Color(0xFFFFFFFF)
val SummaryGrey = Color(0xFFF3F4F6)
val SummaryGreyBorder = Color(0xFFE2E4E9)

val SeatAvailableBorder = Color(0xFF9CA3AF)
val SeatUnavailableFill = Color(0xFF6B7280)
val SeatOtherHoldFill = Color(0xFFF59E0B)
val SeatAccessibleFill = Color(0xFFEBF3FF)
val SeatAccessibleBorder = Color(0xFF3B82F6)
val SeatAccessibleIcon = Color(0xFF1D4ED8)

val TextOnDarkPrimary = Color(0xFFFFFFFF)
val TextOnDarkSecondary = Color(0xFFB3B7C3)
val TextOnLightPrimary = Color(0xFF111318)
val TextOnLightSecondary = Color(0xFF525866)

val StatusSuccess = Color(0xFF16A34A)
val StatusWarning = Color(0xFFD97706)
val StatusError = Color(0xFFDC2626)

// High-Contrast Overrides
val HighContrastBlack = Color(0xFF000000)
val HighContrastWhite = Color(0xFFFFFFFF)
val HighContrastRed = Color(0xFFFF1F2D)
val HighContrastYellow = Color(0xFFFFD600)
val HighContrastBlue = Color(0xFF0052CC)
