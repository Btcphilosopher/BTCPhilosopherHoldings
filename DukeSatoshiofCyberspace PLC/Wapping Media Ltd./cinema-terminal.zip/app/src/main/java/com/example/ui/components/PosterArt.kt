package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DisplayFontFamily
import java.security.MessageDigest

@Composable
fun FilmPosterArt(
    posterKey: String,
    title: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF0F131E))
            .semantics { contentDescription = "$title poster artwork" }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            when (posterKey) {
                "orbital_dawn" -> {
                    // Deep space -> glowing golden-blue orbital horizon
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF060B19), Color(0xFF13294B), Color(0xFF3E6C94), Color(0xFFF59E0B)),
                            startY = 0f,
                            endY = h
                        )
                    )
                    // Stars
                    val starOffsets = listOf(
                        0.15f to 0.14f, 0.78f to 0.10f, 0.62f to 0.22f,
                        0.28f to 0.27f, 0.85f to 0.30f, 0.42f to 0.12f
                    )
                    starOffsets.forEach { (sx, sy) ->
                        drawCircle(Color.White.copy(alpha = 0.75f), radius = w * 0.012f, center = Offset(w * sx, h * sy))
                    }
                    // Sun flare on limb
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFFFFF7D6), Color(0xFFFBBF24), Color.Transparent),
                            center = Offset(w * 0.68f, h * 0.68f),
                            radius = w * 0.55f
                        ),
                        center = Offset(w * 0.68f, h * 0.68f),
                        radius = w * 0.55f
                    )
                    // Planet arc
                    drawCircle(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF1E3A5F), Color(0xFF0A1220))
                        ),
                        radius = w * 0.85f,
                        center = Offset(w * 0.5f, h * 1.38f)
                    )
                    // Astronaut helmet silhouette in foreground
                    drawCircle(
                        color = Color(0xFF0D111A),
                        radius = w * 0.24f,
                        center = Offset(w * 0.36f, h * 0.40f)
                    )
                    // Helmet visor gold-cyan reflection
                    drawOval(
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFFFDE68A), Color(0xFF60A5FA))
                        ),
                        topLeft = Offset(w * 0.26f, h * 0.28f),
                        size = Size(w * 0.26f, h * 0.20f)
                    )
                    // Shoulders
                    drawOval(
                        color = Color(0xFF111827),
                        topLeft = Offset(w * 0.06f, h * 0.55f),
                        size = Size(w * 0.62f, h * 0.45f)
                    )
                }

                "last_avenue" -> {
                    // Moody evening Manhattan street glow
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF0B1021), Color(0xFF281B2D), Color(0xFF4C2827))
                        )
                    )
                    // City buildings silhouettes
                    drawRect(Color(0xFF0A0D16), Offset(0f, h * 0.15f), Size(w * 0.25f, h * 0.85f))
                    drawRect(Color(0xFF0F131E), Offset(w * 0.70f, h * 0.10f), Size(w * 0.30f, h * 0.90f))
                    // Warm bokeh street lights
                    drawCircle(Color(0xFFFBBF24).copy(alpha = 0.55f), w * 0.10f, Offset(w * 0.34f, h * 0.48f))
                    drawCircle(Color(0xFFF59E0B).copy(alpha = 0.35f), w * 0.16f, Offset(w * 0.64f, h * 0.42f))
                    // Two silhouettes facing each other
                    drawCircle(Color(0xFF090B10), w * 0.12f, Offset(w * 0.36f, h * 0.36f))
                    drawCircle(Color(0xFF090B10), w * 0.11f, Offset(w * 0.62f, h * 0.39f))
                    drawRect(Color(0xFF090B10), Offset(w * 0.20f, h * 0.46f), Size(w * 0.26f, h * 0.54f))
                    drawRect(Color(0xFF090B10), Offset(w * 0.54f, h * 0.48f), Size(w * 0.26f, h * 0.52f))
                }

                "wild_summer" -> {
                    // Warm golden-orange sunset sky over canyon road
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFFFB923C), Color(0xFFFBBF24), Color(0xFFFEF3C7))
                        )
                    )
                    // Sun
                    drawCircle(Color(0xFFFFFBEB), w * 0.20f, Offset(w * 0.5f, h * 0.52f))
                    // Mountains
                    val leftMtn = Path().apply {
                        moveTo(0f, h * 0.65f)
                        lineTo(w * 0.35f, h * 0.44f)
                        lineTo(w * 0.65f, h * 0.65f)
                        close()
                    }
                    val rightMtn = Path().apply {
                        moveTo(w * 0.38f, h * 0.65f)
                        lineTo(w * 0.78f, h * 0.42f)
                        lineTo(w, h * 0.62f)
                        lineTo(w, h * 0.65f)
                        close()
                    }
                    drawPath(leftMtn, Color(0xFF9A3412))
                    drawPath(rightMtn, Color(0xFF7C2D12))
                    // Highway perspective
                    drawRect(Color(0xFF292524), Offset(0f, h * 0.65f), Size(w, h * 0.35f))
                    val road = Path().apply {
                        moveTo(w * 0.44f, h * 0.65f)
                        lineTo(w * 0.56f, h * 0.65f)
                        lineTo(w * 0.85f, h)
                        lineTo(w * 0.15f, h)
                        close()
                    }
                    drawPath(road, Color(0xFF44403C))
                    // Vintage station wagon silhouette
                    drawRoundRect(
                        color = Color(0xFF1C1917),
                        topLeft = Offset(w * 0.36f, h * 0.72f),
                        size = Size(w * 0.28f, h * 0.13f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                    )
                    drawCircle(Color(0xFFEF4444), w * 0.025f, Offset(w * 0.40f, h * 0.79f))
                    drawCircle(Color(0xFFEF4444), w * 0.025f, Offset(w * 0.60f, h * 0.79f))
                }

                "glass_meridian" -> {
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF042F2E), Color(0xFF0F766E), Color(0xFF99F6E4))
                        )
                    )
                    drawCircle(Color.White.copy(alpha = 0.22f), w * 0.35f, Offset(w * 0.5f, h * 0.42f))
                }

                else -> {
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF1E1B4B), Color(0xFF312E81), Color(0xFF6366F1))
                        )
                    )
                    drawCircle(Color(0xFFA5B4FC).copy(alpha = 0.3f), w * 0.3f, Offset(w * 0.65f, h * 0.38f))
                }
            }
            // Subtle bottom vignette for crisp title readability
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.78f)),
                    startY = h * 0.50f,
                    endY = h
                )
            )
        }

        Text(
            text = title.uppercase(),
            color = Color.White,
            fontFamily = DisplayFontFamily,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 10.sp,
            lineHeight = 11.sp,
            textAlign = TextAlign.Center,
            maxLines = 2,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 4.dp, vertical = 6.dp)
        )
    }
}

/**
 * Deterministic 21x21 QR-style matrix generated from the opaque signed ticket token.
 * Contains NO personal data; encodes only the signed ticket reference token.
 */
@Composable
fun TicketQrMatrix(
    qrToken: String,
    modifier: Modifier = Modifier
) {
    val digest = MessageDigest.getInstance("SHA-256").digest(qrToken.toByteArray())
    Box(
        modifier = modifier
            .background(Color.White, RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFFD1D5DB), RoundedCornerShape(10.dp))
            .padding(10.dp)
            .semantics { contentDescription = "Ticket entry QR code for token $qrToken" }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val grid = 21
            val cellW = size.width / grid
            val cellH = size.height / grid

            fun drawFinder(startCol: Int, startRow: Int) {
                for (r in 0 until 7) {
                    for (c in 0 until 7) {
                        val isBorder = r == 0 || r == 6 || c == 0 || c == 6
                        val isInner = r in 2..4 && c in 2..4
                        if (isBorder || isInner) {
                            drawRect(
                                color = Color.Black,
                                topLeft = Offset((startCol + c) * cellW, (startRow + r) * cellH),
                                size = Size(cellW + 0.5f, cellH + 0.5f)
                            )
                        }
                    }
                }
            }

            drawFinder(0, 0)
            drawFinder(grid - 7, 0)
            drawFinder(0, grid - 7)

            for (r in 0 until grid) {
                for (c in 0 until grid) {
                    val inFinder = (r < 8 && c < 8) || (r < 8 && c >= grid - 8) || (r >= grid - 8 && c < 8)
                    if (!inFinder) {
                        val idx = (r * grid + c)
                        val b = digest[idx % digest.size].toInt() and 0xFF
                        val bit = ((b shr (idx % 7)) and 1) == 1 || (r == 6 && c % 2 == 0) || (c == 6 && r % 2 == 0)
                        if (bit) {
                            drawRect(
                                color = Color.Black,
                                topLeft = Offset(c * cellW, r * cellH),
                                size = Size(cellW + 0.5f, cellH + 0.5f)
                            )
                        }
                    }
                }
            }
        }
    }
}
