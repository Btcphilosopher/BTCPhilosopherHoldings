package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CinemaDao {
    // --- Reactive Observations ---
    @Query("SELECT * FROM cinemas ORDER BY name ASC")
    fun observeCinemas(): Flow<List<CinemaEntity>>

    @Query("SELECT * FROM auditoriums WHERE cinemaId = :cinemaId")
    fun observeAuditoriums(cinemaId: String): Flow<List<AuditoriumEntity>>

    @Query("SELECT * FROM films ORDER BY isComingSoon ASC, title ASC")
    fun observeFilms(): Flow<List<FilmEntity>>

    @Query("SELECT * FROM screenings WHERE cinemaId = :cinemaId ORDER BY startEpochMs ASC")
    fun observeScreeningsForCinema(cinemaId: String): Flow<List<ScreeningEntity>>

    @Query("SELECT * FROM screenings ORDER BY startEpochMs ASC")
    fun observeAllScreenings(): Flow<List<ScreeningEntity>>

    @Query("SELECT * FROM seat_definitions WHERE auditoriumId = :auditoriumId ORDER BY rowLabel ASC, seatNumber ASC")
    fun observeSeatDefinitions(auditoriumId: String): Flow<List<SeatDefinitionEntity>>

    @Query("SELECT * FROM seat_locks WHERE screeningId = :screeningId")
    fun observeSeatLocksForScreening(screeningId: String): Flow<List<SeatLockEntity>>

    @Query("SELECT * FROM concession_products ORDER BY category ASC, priceCents ASC")
    fun observeConcessions(): Flow<List<ConcessionProductEntity>>

    @Query("SELECT * FROM kiosk_config WHERE id = 1")
    fun observeKioskConfig(): Flow<KioskConfigEntity?>

    @Query("SELECT * FROM payment_transactions ORDER BY createdAtEpochMs DESC")
    fun observePaymentTransactions(): Flow<List<PaymentTransactionEntity>>

    @Query("SELECT * FROM bookings ORDER BY createdAtEpochMs DESC")
    fun observeBookings(): Flow<List<BookingEntity>>

    @Query("SELECT * FROM audit_logs ORDER BY timestampEpochMs DESC LIMIT 200")
    fun observeAuditLogs(): Flow<List<AuditLogEntity>>

    // --- Direct Queries ---
    @Query("SELECT COUNT(*) FROM cinemas")
    suspend fun getCinemaCount(): Int

    @Query("SELECT * FROM cinemas WHERE id = :id")
    suspend fun getCinemaById(id: String): CinemaEntity?

    @Query("SELECT * FROM auditoriums WHERE id = :id")
    suspend fun getAuditoriumById(id: String): AuditoriumEntity?

    @Query("SELECT * FROM films WHERE id = :id")
    suspend fun getFilmById(id: String): FilmEntity?

    @Query("SELECT * FROM screenings WHERE id = :id")
    suspend fun getScreeningById(id: String): ScreeningEntity?

    @Query("SELECT * FROM seat_definitions WHERE auditoriumId = :auditoriumId AND seatCode = :seatCode")
    suspend fun getSeatDefinition(auditoriumId: String, seatCode: String): SeatDefinitionEntity?

    @Query("SELECT * FROM seat_locks WHERE screeningId = :screeningId AND seatCode = :seatCode")
    suspend fun getSeatLock(screeningId: String, seatCode: String): SeatLockEntity?

    @Query("SELECT * FROM seat_locks WHERE screeningId = :screeningId AND ownerSessionId = :sessionId AND lockType = 'HOLD'")
    suspend fun getSessionLocks(screeningId: String, sessionId: String): List<SeatLockEntity>

    @Query("SELECT * FROM seat_holds WHERE holdId = :holdId")
    suspend fun getHoldById(holdId: String): SeatHoldEntity?

    @Query("SELECT * FROM seat_holds WHERE screeningId = :screeningId AND sessionId = :sessionId AND status = 'ACTIVE'")
    suspend fun getActiveSessionHolds(screeningId: String, sessionId: String): List<SeatHoldEntity>

    @Query("SELECT * FROM concession_products WHERE id = :id")
    suspend fun getConcessionById(id: String): ConcessionProductEntity?

    @Query("SELECT * FROM kiosk_config WHERE id = 1")
    suspend fun getKioskConfig(): KioskConfigEntity?

    @Query("SELECT * FROM payment_transactions WHERE idempotencyKey = :idempotencyKey")
    suspend fun getPaymentByIdempotencyKey(idempotencyKey: String): PaymentTransactionEntity?

    @Query("SELECT * FROM payment_transactions WHERE transactionId = :txId")
    suspend fun getPaymentById(txId: String): PaymentTransactionEntity?

    @Query("SELECT * FROM payment_transactions WHERE needsReconciliation = 1")
    suspend fun getPaymentsNeedingReconciliation(): List<PaymentTransactionEntity>

    @Query("SELECT * FROM bookings WHERE bookingRef = :bookingRef")
    suspend fun getBookingByRef(bookingRef: String): BookingEntity?

    @Query("SELECT * FROM bookings WHERE idempotencyKey = :idempotencyKey")
    suspend fun getBookingByIdempotencyKey(idempotencyKey: String): BookingEntity?

    @Query("SELECT * FROM tickets WHERE bookingRef = :bookingRef ORDER BY seatCode ASC")
    suspend fun getTicketsForBooking(bookingRef: String): List<TicketEntity>

    @Query("SELECT * FROM tickets WHERE qrToken = :qrToken")
    suspend fun getTicketByQrToken(qrToken: String): TicketEntity?

    @Query("SELECT * FROM concession_order_items WHERE bookingRef = :bookingRef")
    suspend fun getConcessionItemsForBooking(bookingRef: String): List<ConcessionOrderItemEntity>

    // --- Mutating Primitives ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCinemas(items: List<CinemaEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditoriums(items: List<AuditoriumEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFilms(items: List<FilmEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScreenings(items: List<ScreeningEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSeatDefinitions(items: List<SeatDefinitionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConcessions(items: List<ConcessionProductEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertKioskConfig(config: KioskConfigEntity)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertSeatLockOrThrow(lock: SeatLockEntity)

    @Update
    suspend fun updateSeatLock(lock: SeatLockEntity)

    @Query("DELETE FROM seat_locks WHERE screeningId = :screeningId AND seatCode = :seatCode")
    suspend fun deleteSeatLock(screeningId: String, seatCode: String)

    @Query("DELETE FROM seat_locks WHERE lockType = 'HOLD' AND protectedForPaymentId IS NULL AND expiresAtEpochMs IS NOT NULL AND expiresAtEpochMs <= :nowMs")
    suspend fun deleteExpiredUnprotectedHolds(nowMs: Long): Int

    @Query("UPDATE seat_holds SET status = 'EXPIRED' WHERE status = 'ACTIVE' AND expiresAtEpochMs <= :nowMs AND holdId NOT IN (SELECT COALESCE(holdId, '') FROM seat_locks WHERE protectedForPaymentId IS NOT NULL)")
    suspend fun markExpiredHoldRecords(nowMs: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSeatHold(hold: SeatHoldEntity)

    @Query("UPDATE seat_holds SET status = :status WHERE holdId = :holdId")
    suspend fun updateHoldStatus(holdId: String, status: String)

    @Query("UPDATE seat_holds SET ticketCategory = :category WHERE screeningId = :screeningId AND seatCode = :seatCode AND sessionId = :sessionId AND status = 'ACTIVE'")
    suspend fun updateActiveHoldCategory(screeningId: String, seatCode: String, sessionId: String, category: String)

    @Query("UPDATE seat_locks SET ticketCategory = :category WHERE screeningId = :screeningId AND seatCode = :seatCode AND ownerSessionId = :sessionId AND lockType = 'HOLD'")
    suspend fun updateSeatLockCategory(screeningId: String, seatCode: String, sessionId: String, category: String)

    @Query("UPDATE seat_locks SET expiresAtEpochMs = :newExpiryMs WHERE screeningId = :screeningId AND ownerSessionId = :sessionId AND lockType = 'HOLD'")
    suspend fun extendSessionLockExpiry(screeningId: String, sessionId: String, newExpiryMs: Long)

    @Query("UPDATE seat_holds SET expiresAtEpochMs = :newExpiryMs, extensionCount = extensionCount + 1 WHERE screeningId = :screeningId AND sessionId = :sessionId AND status = 'ACTIVE'")
    suspend fun extendActiveHoldsExpiry(screeningId: String, sessionId: String, newExpiryMs: Long)

    @Query("UPDATE seat_locks SET protectedForPaymentId = :paymentId WHERE screeningId = :screeningId AND ownerSessionId = :sessionId AND lockType = 'HOLD'")
    suspend fun protectLocksForPayment(screeningId: String, sessionId: String, paymentId: String)

    @Query("UPDATE seat_locks SET protectedForPaymentId = NULL WHERE protectedForPaymentId = :paymentId AND lockType = 'HOLD'")
    suspend fun unprotectLocksForPayment(paymentId: String)

    @Query("UPDATE seat_locks SET protectedForPaymentId = NULL WHERE screeningId = :screeningId AND ownerSessionId = :sessionId AND lockType = 'HOLD'")
    suspend fun unprotectSessionLocks(screeningId: String, sessionId: String)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertPaymentTransaction(tx: PaymentTransactionEntity)

    @Update
    suspend fun updatePaymentTransaction(tx: PaymentTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertBooking(booking: BookingEntity)

    @Update
    suspend fun updateBooking(booking: BookingEntity)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertTickets(tickets: List<TicketEntity>)

    @Update
    suspend fun updateTicket(ticket: TicketEntity)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertConcessionOrderItems(items: List<ConcessionOrderItemEntity>)

    @Query("UPDATE concession_products SET stockCount = stockCount - :qty, isAvailable = CASE WHEN (stockCount - :qty) > 0 THEN 1 ELSE 0 END WHERE id = :productId AND stockCount >= :qty")
    suspend fun decrementConcessionStock(productId: String, qty: Int): Int

    @Query("UPDATE concession_products SET stockCount = :stockCount, isAvailable = :isAvailable WHERE id = :productId")
    suspend fun setConcessionStock(productId: String, stockCount: Int, isAvailable: Boolean)

    @Query("UPDATE seat_definitions SET isMaintenanceBlocked = :blocked WHERE auditoriumId = :auditoriumId AND seatCode = :seatCode")
    suspend fun setSeatMaintenanceBlocked(auditoriumId: String, seatCode: String, blocked: Boolean)

    @Query("UPDATE screenings SET status = :status WHERE id = :screeningId")
    suspend fun updateScreeningStatus(screeningId: String, status: String)

    @Query("UPDATE screenings SET adultPriceCents = :adultPriceCents, bookingFeePerTicketCents = :bookingFeeCents, taxRateBps = :taxRateBps WHERE id = :screeningId")
    suspend fun updateScreeningPricing(screeningId: String, adultPriceCents: Long, bookingFeeCents: Long, taxRateBps: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)

    // --- Transactional Operations ---
    @Transaction
    suspend fun pruneExpiredHoldsAtomically(nowMs: Long): Int {
        val deleted = deleteExpiredUnprotectedHolds(nowMs)
        markExpiredHoldRecords(nowMs)
        return deleted
    }

    @Transaction
    suspend fun acquireSeatHoldAtomically(
        screeningId: String,
        seatCode: String,
        sessionId: String,
        ticketCategory: String,
        holdId: String,
        nowMs: Long,
        expiresAtEpochMs: Long
    ): Boolean {
        pruneExpiredHoldsAtomically(nowMs)
        val screening = getScreeningById(screeningId) ?: return false
        if (screening.status != "ACTIVE") return false
        if (nowMs < screening.salesOpenEpochMs || nowMs > screening.salesCloseEpochMs) return false
        val seatDef = getSeatDefinition(screening.auditoriumId, seatCode) ?: return false
        if (seatDef.isMaintenanceBlocked) return false

        val existing = getSeatLock(screeningId, seatCode)
        if (existing != null) {
            return existing.lockType == "HOLD" && existing.ownerSessionId == sessionId
        }

        insertSeatLockOrThrow(
            SeatLockEntity(
                screeningId = screeningId,
                seatCode = seatCode,
                lockType = "HOLD",
                ownerSessionId = sessionId,
                holdId = holdId,
                bookingRef = null,
                ticketCategory = ticketCategory,
                createdAtEpochMs = nowMs,
                expiresAtEpochMs = expiresAtEpochMs,
                protectedForPaymentId = null
            )
        )
        insertSeatHold(
            SeatHoldEntity(
                holdId = holdId,
                screeningId = screeningId,
                seatCode = seatCode,
                sessionId = sessionId,
                ticketCategory = ticketCategory,
                createdAtEpochMs = nowMs,
                expiresAtEpochMs = expiresAtEpochMs,
                status = "ACTIVE",
                extensionCount = 0
            )
        )
        return true
    }

    @Transaction
    suspend fun releaseSeatHoldAtomically(
        screeningId: String,
        seatCode: String,
        sessionId: String
    ): Boolean {
        val existing = getSeatLock(screeningId, seatCode) ?: return false
        if (existing.lockType != "HOLD" || existing.ownerSessionId != sessionId) return false
        if (existing.protectedForPaymentId != null) return false
        deleteSeatLock(screeningId, seatCode)
        existing.holdId?.let { updateHoldStatus(it, "RELEASED") }
        return true
    }

    @Transaction
    suspend fun releaseAllSessionHoldsAtomically(
        sessionId: String,
        screeningIdFilter: String? = null
    ) {
        val allHolds = if (screeningIdFilter != null) {
            getSessionLocks(screeningIdFilter, sessionId)
        } else {
            emptyList()
        }
        allHolds.forEach { lock ->
            if (lock.protectedForPaymentId == null) {
                deleteSeatLock(lock.screeningId, lock.seatCode)
                lock.holdId?.let { updateHoldStatus(it, "RELEASED") }
            }
        }
    }

    @Transaction
    suspend fun releaseAnyUnprotectedSessionHolds(sessionId: String) {
        val holds = getActiveHoldsBySession(sessionId)
        holds.forEach { lock ->
            if (lock.protectedForPaymentId == null && lock.lockType == "HOLD") {
                deleteSeatLock(lock.screeningId, lock.seatCode)
                lock.holdId?.let { updateHoldStatus(it, "RELEASED") }
            }
        }
    }

    @Query("SELECT * FROM seat_locks WHERE ownerSessionId = :sessionId AND lockType = 'HOLD'")
    suspend fun getActiveHoldsBySession(sessionId: String): List<SeatLockEntity>

    @Transaction
    suspend fun commitBookingAndTicketsAtomically(
        booking: BookingEntity,
        tickets: List<TicketEntity>,
        concessionItems: List<ConcessionOrderItemEntity>,
        paymentTx: PaymentTransactionEntity,
        heldSeats: List<SeatLockEntity>,
        nowMs: Long
    ): Boolean {
        // Verify idempotency first
        if (getBookingByIdempotencyKey(booking.idempotencyKey) != null) {
            return true
        }
        // Verify every seat lock is still held by this session and convert to SOLD
        for (lock in heldSeats) {
            val current = getSeatLock(lock.screeningId, lock.seatCode)
            if (current == null || current.lockType != "HOLD" || current.ownerSessionId != booking.sessionId) {
                throw IllegalStateException("Seat ${lock.seatCode} is no longer held by session ${booking.sessionId}")
            }
            if (current.protectedForPaymentId == null && (current.expiresAtEpochMs ?: 0L) <= nowMs) {
                throw IllegalStateException("Seat hold for ${lock.seatCode} expired before booking commit")
            }
            updateSeatLock(
                current.copy(
                    lockType = "SOLD",
                    bookingRef = booking.bookingRef,
                    expiresAtEpochMs = null,
                    protectedForPaymentId = null
                )
            )
            current.holdId?.let { updateHoldStatus(it, "CONVERTED_TO_TICKET") }
        }
        // Decrement concession stock independently; if a concession item is out of stock, mark concession status partial/failed
        var allConcessionsFulfilled = true
        val finalConcessionItems = concessionItems.map { item ->
            val updated = decrementConcessionStock(item.productId, item.quantity)
            if (updated > 0) {
                item.copy(fulfillmentStatus = "ISSUED")
            } else {
                allConcessionsFulfilled = false
                item.copy(fulfillmentStatus = "FAILED")
            }
        }
        val finalBooking = booking.copy(
            concessionFulfillmentStatus = when {
                concessionItems.isEmpty() -> "NOT_APPLICABLE"
                allConcessionsFulfilled -> "ISSUED"
                else -> "FAILED"
            },
            status = if (concessionItems.isEmpty() || allConcessionsFulfilled) "CONFIRMED" else "PARTIALLY_FULFILLED"
        )
        insertBooking(finalBooking)
        insertTickets(tickets)
        if (finalConcessionItems.isNotEmpty()) {
            insertConcessionOrderItems(finalConcessionItems)
        }
        updatePaymentTransaction(
            paymentTx.copy(
                linkedBookingRef = finalBooking.bookingRef,
                needsReconciliation = false,
                updatedAtEpochMs = nowMs
            )
        )
        return true
    }

    @Transaction
    suspend fun refundBookingAtomically(
        bookingRef: String,
        staffId: String,
        staffRole: String,
        reason: String,
        nowMs: Long
    ): Boolean {
        val booking = getBookingByRef(bookingRef) ?: return false
        if (booking.status == "REFUNDED" || booking.status == "CANCELLED") return false

        val tickets = getTicketsForBooking(bookingRef)
        tickets.forEach { t ->
            deleteSeatLock(t.screeningId, t.seatCode)
            updateTicket(t.copy(admissionStatus = "REFUNDED"))
        }
        updateBooking(
            booking.copy(
                status = "REFUNDED",
                ticketFulfillmentStatus = "REFUNDED",
                concessionFulfillmentStatus = if (booking.concessionFulfillmentStatus == "NOT_APPLICABLE") "NOT_APPLICABLE" else "REFUNDED"
            )
        )
        getPaymentById(booking.paymentTransactionId)?.let { tx ->
            updatePaymentTransaction(tx.copy(status = "REFUNDED", updatedAtEpochMs = nowMs, outcomeReason = reason))
        }
        insertAuditLog(
            AuditLogEntity(
                id = "AUD-${nowMs}-${bookingRef}",
                timestampEpochMs = nowMs,
                actorStaffId = staffId,
                actorRole = staffRole,
                actionType = "BOOKING_REFUNDED",
                targetId = bookingRef,
                details = reason
            )
        )
        return true
    }
}
