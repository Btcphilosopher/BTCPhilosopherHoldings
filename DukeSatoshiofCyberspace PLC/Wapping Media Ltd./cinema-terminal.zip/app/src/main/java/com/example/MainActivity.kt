package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.domain.model.CheckoutStep
import com.example.ui.components.KioskBottomFooter
import com.example.ui.components.KioskTopHeaderAndHero
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.KioskUiState
import com.example.ui.viewmodel.KioskViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: KioskViewModel = viewModel()
            val state by viewModel.uiState.collectAsStateWithLifecycle()

            CinemaTerminalTheme(
                highContrastMode = state.accessibility.highContrastMode,
                largeTextMode = state.accessibility.largeTextMode
            ) {
                CinemaKioskApp(state = state, viewModel = viewModel)
            }
        }
    }
}

@Composable
fun CinemaKioskApp(
    state: KioskUiState,
    viewModel: KioskViewModel
) {
    // Handle system back cleanly during multi-step kiosk flow
    BackHandler(enabled = state.currentStep == CheckoutStep.EXTRAS || state.currentStep == CheckoutStep.PAY_AND_COLLECT) {
        when (state.currentStep) {
            CheckoutStep.EXTRAS -> viewModel.navigateToStep(CheckoutStep.SELECT_SEATS)
            CheckoutStep.PAY_AND_COLLECT -> viewModel.navigateToStep(CheckoutStep.EXTRAS)
            else -> {}
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(KioskBlack)
    ) {
        val isCompactWidth = maxWidth < 860.dp
        val cinemaLabel = state.selectedCinema?.let { "${it.name} • ${it.city}" } ?: "Century City • Los Angeles"
        val cartCount = state.heldSeats.size + state.concessionQuantities.values.sum()

        Column(modifier = Modifier.fillMaxSize()) {
            KioskTopHeaderAndHero(
                brandConfig = state.brandConfig,
                cinemaLabel = cinemaLabel,
                language = state.language,
                strings = state.strings,
                currentStep = state.currentStep,
                cartCount = cartCount,
                hasMembership = state.membership != null,
                isCompactWidth = isCompactWidth,
                onChangeLocationClick = { viewModel.setShowLocationDialog(true) },
                onSelectLanguage = { viewModel.setLanguage(it) },
                onAccessibilityClick = { viewModel.setShowAccessibilityDialog(true) },
                onCartClick = {
                    if (state.heldSeats.isNotEmpty()) {
                        viewModel.navigateToStep(CheckoutStep.PAY_AND_COLLECT)
                    }
                },
                onFindBookingClick = { viewModel.setShowFindBookingDialog(true) },
                onStepClick = { step -> viewModel.navigateToStep(step) },
                onSecretStaffTrigger = { viewModel.setShowStaffAuthDialog(true) }
            )

            // Plain-language recoverable error / status banner
            val banner = state.banner
            if (state.accessibility.reducedMotionMode) {
                if (banner != null) {
                    KioskBannerStrip(
                        message = banner.message,
                        isError = banner.isError,
                        isWarning = banner.isWarning,
                        onDismiss = { viewModel.dismissBanner() }
                    )
                }
            } else {
                AnimatedVisibility(visible = banner != null) {
                    banner?.let {
                        KioskBannerStrip(
                            message = it.message,
                            isError = it.isError,
                            isWarning = it.isWarning,
                            onDismiss = { viewModel.dismissBanner() }
                        )
                    }
                }
            }

            // Main Kiosk Step Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (state.currentStep) {
                    CheckoutStep.FILM_AND_TIME, CheckoutStep.SELECT_SEATS -> {
                        FilmAndSeatWorkspace(
                            state = state,
                            isCompactWidth = isCompactWidth,
                            onSelectFilmAndScreening = { f, s -> viewModel.selectFilmAndScreening(f, s) },
                            onDateFilterChange = { viewModel.setDateFilter(it) },
                            onFormatFilterChange = { viewModel.setFormatFilter(it) },
                            onShowComingSoonChange = { viewModel.setShowComingSoon(it) },
                            onSeatToggle = { viewModel.toggleSeat(it) },
                            onSeatCategoryChange = { code, cat -> viewModel.updateSeatCategory(code, cat) },
                            onAllSeatsCategoryChange = { cat -> viewModel.setAllHeldSeatsCategory(cat) },
                            onExtendHold = { viewModel.extendHold() },
                            onOpenTextSeatSelector = { viewModel.setShowTextSeatSelector(true) },
                            onContinueToExtras = { viewModel.navigateToStep(CheckoutStep.EXTRAS) },
                            onSkipExtras = { viewModel.skipExtrasToPayment() },
                            onOpenMembership = { viewModel.setShowMembershipDialog(true) },
                            onClearMembership = { viewModel.clearMembership() },
                            onOpenFindBooking = { viewModel.setShowFindBookingDialog(true) },
                            onOpenRefundTerms = { viewModel.setShowRefundTermsDialog(true) }
                        )
                    }

                    CheckoutStep.EXTRAS -> {
                        ExtrasScreen(
                            state = state,
                            isCompactWidth = isCompactWidth,
                            onQuantityChange = { id, delta -> viewModel.updateConcessionQuantity(id, delta) },
                            onCollectionLocationChange = { viewModel.setCollectionLocation(it) },
                            onBackToSeats = { viewModel.navigateToStep(CheckoutStep.SELECT_SEATS) },
                            onSkipExtras = { viewModel.skipExtrasToPayment() },
                            onContinueToPay = { viewModel.navigateToStep(CheckoutStep.PAY_AND_COLLECT) }
                        )
                    }

                    CheckoutStep.PAY_AND_COLLECT -> {
                        PayAndCollectScreen(
                            state = state,
                            isCompactWidth = isCompactWidth,
                            onBackToExtras = { viewModel.navigateToStep(CheckoutStep.EXTRAS) },
                            onBackToSeats = { viewModel.navigateToStep(CheckoutStep.SELECT_SEATS) },
                            onSubmitPayment = { outcome, ch, tgt -> viewModel.submitPayment(outcome, ch, tgt) },
                            onRecoverUncertainPayment = { rev -> viewModel.recoverUncertainPayment(rev) },
                            onRetryIssuance = { viewModel.retryIssuanceWithoutRecharging() },
                            onOpenRefundTerms = { viewModel.setShowRefundTermsDialog(true) }
                        )
                    }

                    CheckoutStep.TICKET_COLLECTION -> {
                        TicketCollectionScreen(
                            state = state,
                            onToggleSimulatedPrinter = { online -> viewModel.toggleSimulatedPrinterFailure(online) },
                            onReprintTickets = { ref -> viewModel.reprintCompletedBooking(ref) },
                            onDoneResetKiosk = { viewModel.resetKioskSession("Ready for the next guest.") }
                        )
                    }
                }
            }

            KioskBottomFooter(
                brandConfig = state.brandConfig,
                strings = state.strings,
                sessionTimerSeconds = state.inactivitySecondsRemaining,
                holdTimerSeconds = state.holdSecondsRemaining,
                isCompactWidth = isCompactWidth,
                onAssistanceClick = { viewModel.setShowAssistanceDialog(true) },
                onAccessibilityClick = { viewModel.setShowAccessibilityDialog(true) },
                onStartOverClick = { viewModel.setShowStartOverDialog(true) },
                onSecretStaffTrigger = { viewModel.setShowStaffAuthDialog(true) }
            )
        }

        KioskModalsHost(state = state, viewModel = viewModel)
    }
}

@Composable
private fun KioskBannerStrip(
    message: String,
    isError: Boolean,
    isWarning: Boolean,
    onDismiss: () -> Unit
) {
    val bg = when {
        isError -> CinemaRedDark
        isWarning -> Color(0xFFB45309)
        else -> Color(0xFF15803D)
    }
    Surface(
        color = bg,
        shape = RoundedCornerShape(0.dp),
        border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.2f)),
        modifier = Modifier.fillMaxWidth().testTag("kiosk_status_banner")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(
                    imageVector = if (isError || isWarning) Icons.Filled.Warning else Icons.Filled.Info,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(message, color = Color.White, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Dismiss banner", tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }
    }
}
