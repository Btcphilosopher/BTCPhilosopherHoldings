package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val KioskLightColorScheme = lightColorScheme(
    primary = CinemaRed,
    onPrimary = Color.White,
    primaryContainer = CinemaRedSoft,
    onPrimaryContainer = CinemaRedDark,
    secondary = KioskCharcoal,
    onSecondary = Color.White,
    secondaryContainer = SummaryGrey,
    onSecondaryContainer = TextOnLightPrimary,
    tertiary = SeatAccessibleIcon,
    onTertiary = Color.White,
    tertiaryContainer = SeatAccessibleFill,
    onTertiaryContainer = SeatAccessibleIcon,
    background = KioskBlack,
    onBackground = TextOnDarkPrimary,
    surface = WorkspaceWhite,
    onSurface = TextOnLightPrimary,
    surfaceVariant = SummaryGrey,
    onSurfaceVariant = TextOnLightSecondary,
    outline = SummaryGreyBorder,
    error = StatusError,
    onError = Color.White
)

private val KioskHighContrastColorScheme = lightColorScheme(
    primary = HighContrastRed,
    onPrimary = HighContrastWhite,
    primaryContainer = HighContrastYellow,
    onPrimaryContainer = HighContrastBlack,
    secondary = HighContrastBlack,
    onSecondary = HighContrastWhite,
    secondaryContainer = HighContrastWhite,
    onSecondaryContainer = HighContrastBlack,
    tertiary = HighContrastBlue,
    onTertiary = HighContrastWhite,
    tertiaryContainer = SeatAccessibleFill,
    onTertiaryContainer = HighContrastBlack,
    background = HighContrastBlack,
    onBackground = HighContrastWhite,
    surface = HighContrastWhite,
    onSurface = HighContrastBlack,
    surfaceVariant = Color(0xFFE5E7EB),
    onSurfaceVariant = HighContrastBlack,
    outline = HighContrastBlack,
    error = Color(0xFFB00020),
    onError = HighContrastWhite
)

@Composable
fun CinemaTerminalTheme(
    highContrastMode: Boolean = false,
    largeTextMode: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (highContrastMode) KioskHighContrastColorScheme else KioskLightColorScheme
    val typography = buildKioskTypography(largeText = largeTextMode)
    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        content = content
    )
}
