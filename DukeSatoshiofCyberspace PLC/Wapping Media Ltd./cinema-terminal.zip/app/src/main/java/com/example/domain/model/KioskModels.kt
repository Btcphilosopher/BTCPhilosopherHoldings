package com.example.domain.model

import java.text.NumberFormat
import java.util.Currency
import java.util.Locale

data class BrandConfig(
    val brandBadgeText: String = "amc",
    val brandTitle: String = "AMC CINEMA",
    val conceptDisclaimer: String = "INDEPENDENT UI CONCEPT • DEMO FILMS, TIMES & PRICES",
    val membershipProgramLabel: String = "Cinema Club • Demo",
    val membershipSubtitle: String = "Sign in or scan your demo membership.",
    val demoTicketBanner: String = "DEMO — NOT VALID FOR ADMISSION",
    val isReplaceableConcept: Boolean = true
)

enum class CheckoutStep(val stepNumber: Int) {
    FILM_AND_TIME(1),
    SELECT_SEATS(2),
    EXTRAS(3),
    PAY_AND_COLLECT(4),
    TICKET_COLLECTION(5)
}

enum class KioskLanguage(val code: String, val displayName: String) {
    ENGLISH("en", "English"),
    SPANISH("es", "Español"),
    FRENCH("fr", "Français")
}

enum class SeatType {
    STANDARD,
    ACCESSIBLE_WHEELCHAIR,
    COMPANION
}

enum class SeatStatus {
    AVAILABLE,
    HELD_BY_THIS_SESSION,
    HELD_BY_OTHER_SESSION,
    SOLD,
    UNAVAILABLE
}

enum class TicketCategory(val displayName: String) {
    ADULT("Adult"),
    CHILD("Child"),
    SENIOR("Senior"),
    STUDENT("Student")
}

enum class FilmFormat(val displayLabel: String) {
    STANDARD("Standard"),
    IMAX("IMAX"),
    DOLBY_CINEMA("Dolby Cinema"),
    REALD_3D("RealD 3D")
}

enum class ScreeningStatus {
    ACTIVE,
    CANCELLED
}

enum class PaymentOutcome {
    APPROVED,
    DECLINED,
    CANCELLED,
    UNCERTAIN,
    ISSUANCE_FAILED
}

enum class PaymentStatus {
    PENDING,
    AUTHORIZED,
    CAPTURED,
    DECLINED,
    CANCELLED,
    UNCERTAIN,
    REVERSED,
    REFUNDED
}

enum class BookingStatus {
    PENDING_ISSUANCE,
    CONFIRMED,
    PARTIALLY_FULFILLED,
    ADMITTED,
    CANCELLED,
    REFUNDED
}

enum class FulfillmentStatus {
    PENDING,
    ISSUED,
    FAILED,
    NOT_APPLICABLE,
    REFUNDED
}

enum class PrintStatus {
    NOT_PRINTED,
    PRINTED,
    PRINT_FAILED,
    REPRINTED
}

enum class AdmissionStatus {
    ISSUED,
    ADMITTED,
    REVERSED,
    REFUNDED,
    CANCELLED
}

enum class StaffRole(val level: Int, val label: String) {
    STAFF(1, "Kiosk Attendant"),
    SUPERVISOR(2, "Floor Supervisor"),
    MANAGER(3, "Cinema Manager")
}

data class AccessibilityPreferences(
    val largeTextMode: Boolean = false,
    val highContrastMode: Boolean = false,
    val reducedMotionMode: Boolean = false,
    val textSeatSelectionMode: Boolean = false,
    val filterWheelchairOnly: Boolean = false,
    val filterClosedCaption: Boolean = false,
    val filterAudioDescription: Boolean = false
)

data class TicketLineItem(
    val category: TicketCategory,
    val quantity: Int,
    val unitPriceCents: Long,
    val totalCents: Long
)

data class ConcessionLineItem(
    val productId: String,
    val name: String,
    val sizeLabel: String,
    val quantity: Int,
    val unitPriceCents: Long,
    val totalCents: Long,
    val taxCents: Long,
    val collectionLocation: String
)

data class PricingBreakdown(
    val ticketLineItems: List<TicketLineItem> = emptyList(),
    val ticketSubtotalCents: Long = 0L,
    val membershipDiscountCents: Long = 0L,
    val membershipDiscountReason: String? = null,
    val bookingFeeCents: Long = 0L,
    val bookingFeeWaivedCents: Long = 0L,
    val concessionLineItems: List<ConcessionLineItem> = emptyList(),
    val concessionSubtotalCents: Long = 0L,
    val taxCents: Long = 0L,
    val grandTotalCents: Long = 0L,
    val currency: String = "USD",
    val refundPolicySummary: String = "Refundable up to 30 minutes before screening start. Booking fees may be non-refundable after print."
)

data class MembershipAccount(
    val accountId: String,
    val maskedMemberNumber: String,
    val tierName: String,
    val displayAlias: String,
    val ticketDiscountBps: Int, // e.g., 1500 = 15%
    val flatOrderDiscountCents: Long,
    val waivesBookingFee: Boolean,
    val freeSmallPopcornEligible: Boolean,
    val sampleDisclaimer: String = "Sample demo membership benefit — not connected to official AMC Stubs APIs."
)

sealed class MembershipLookupResult {
    data class Found(val account: MembershipAccount) : MembershipLookupResult()
    data class NotFound(val query: String) : MembershipLookupResult()
    data class ServiceUnavailable(val message: String) : MembershipLookupResult()
}

data class SeatDisplayItem(
    val seatCode: String,
    val rowLabel: String,
    val seatNumber: Int,
    val blockSide: String,
    val seatType: SeatType,
    val status: SeatStatus,
    val ticketCategory: TicketCategory = TicketCategory.ADULT,
    val pairedAccessibleSeatCode: String? = null,
    val holdExpiresAtEpochMs: Long? = null
)

data class PaymentRequest(
    val idempotencyKey: String,
    val sessionId: String,
    val screeningId: String,
    val amountCents: Long,
    val currency: String,
    val simulatedOutcome: PaymentOutcome
)

data class PaymentGatewayResult(
    val transactionId: String,
    val idempotencyKey: String,
    val status: PaymentStatus,
    val providerReference: String,
    val callbackVerified: Boolean,
    val signatureToken: String,
    val message: String
)

data class PrintDispatchResult(
    val success: Boolean,
    val printerId: String,
    val message: String
)

data class NotificationDispatchResult(
    val sent: Boolean,
    val channel: String,
    val maskedTarget: String,
    val summary: String
)

sealed class OperationResult<out T> {
    data class Success<T>(val data: T) : OperationResult<T>()
    data class Failure(val code: String, val userMessage: String, val recoverable: Boolean = true) : OperationResult<Nothing>()
}

fun formatMinorUnits(cents: Long, currencyCode: String = "USD"): String {
    val format = NumberFormat.getCurrencyInstance(Locale.US)
    runCatching { format.currency = Currency.getInstance(currencyCode) }
    return format.format(cents / 100.0)
}
