package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.ConcessionProductEntity
import com.example.domain.model.formatMinorUnits
import com.example.ui.theme.*
import com.example.ui.viewmodel.KioskUiState

@Composable
fun ExtrasScreen(
    state: KioskUiState,
    isCompactWidth: Boolean,
    onQuantityChange: (String, Int) -> Unit,
    onCollectionLocationChange: (String) -> Unit,
    onBackToSeats: () -> Unit,
    onSkipExtras: () -> Unit,
    onContinueToPay: () -> Unit
) {
    var selectedCategory by remember { mutableStateOf("ALL") }
    val categories = listOf("ALL" to "All Extras", "COMBO" to "Combos", "POPCORN" to "Popcorn", "DRINK" to "Drinks", "SNACK" to "Snacks")
    val filteredProducts = remember(state.concessions, selectedCategory) {
        if (selectedCategory == "ALL") state.concessions else state.concessions.filter { it.category == selectedCategory }
    }
    val pickupLocations = listOf("Lobby Express Counter A", "Lobby Express Counter B", "Auditorium 6 Pickup Shelf")

    val mainContent: @Composable (Modifier) -> Unit = { mod ->
        Surface(
            color = WorkspaceWhite,
            shape = RoundedCornerShape(16.dp),
            modifier = mod
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Add snacks, drinks & combos",
                            color = TextOnLightPrimary,
                            style = MaterialTheme.typography.headlineMedium,
                            fontFamily = DisplayFontFamily,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Concession stock is tracked separately from your held seats (${state.heldSeats.joinToString(", ") { it.seatCode }}).",
                            color = TextOnLightSecondary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    TextButton(
                        onClick = onBackToSeats,
                        modifier = Modifier.testTag("extras_back_to_seats")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = CinemaRed)
                        Spacer(Modifier.width(4.dp))
                        Text("Back to seats", color = CinemaRed, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Category filter row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { (key, label) ->
                        FilterChip(
                            selected = selectedCategory == key,
                            onClick = { selectedCategory = key },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CinemaRed,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("extras_category_$key")
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredProducts, key = { it.id }) { prod ->
                        ConcessionProductCard(
                            product = prod,
                            quantity = state.concessionQuantities[prod.id] ?: 0,
                            currency = state.pricing.currency,
                            onDelta = { d -> onQuantityChange(prod.id, d) }
                        )
                    }
                }
            }
        }
    }

    val summaryPanel: @Composable () -> Unit = {
        Surface(
            color = SummaryGrey,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, SummaryGreyBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Order & Pickup Summary",
                    color = TextOnLightPrimary,
                    style = MaterialTheme.typography.titleLarge,
                    fontFamily = DisplayFontFamily,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "${state.selectedFilm?.title ?: ""} • ${state.selectedScreening?.dateDisplayLabel ?: ""}, ${state.selectedScreening?.localTimeLabel ?: ""}",
                    color = TextOnLightSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    text = "Seats: ${state.heldSeats.joinToString(", ") { it.seatCode }}",
                    color = TextOnLightPrimary,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )

                HorizontalDivider(color = SummaryGreyBorder)

                Text("Collection Counter", style = MaterialTheme.typography.labelLarge, color = TextOnLightPrimary)
                pickupLocations.forEach { loc ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        RadioButton(
                            selected = state.collectionLocation == loc,
                            onClick = { onCollectionLocationChange(loc) },
                            colors = RadioButtonDefaults.colors(selectedColor = CinemaRed)
                        )
                        Text(loc, style = MaterialTheme.typography.bodySmall, color = TextOnLightPrimary)
                    }
                }

                HorizontalDivider(color = SummaryGreyBorder)

                SummaryPriceRow("Tickets", formatMinorUnits(state.pricing.ticketSubtotalCents - state.pricing.membershipDiscountCents, state.pricing.currency))
                SummaryPriceRow("Booking fee", formatMinorUnits(state.pricing.bookingFeeCents, state.pricing.currency))
                if (state.pricing.concessionSubtotalCents > 0L) {
                    SummaryPriceRow("Extras", formatMinorUnits(state.pricing.concessionSubtotalCents, state.pricing.currency))
                }
                SummaryPriceRow("Illustrative tax", formatMinorUnits(state.pricing.taxCents, state.pricing.currency))
                HorizontalDivider(color = SummaryGreyBorder)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextOnLightPrimary)
                    Text(
                        text = "${formatMinorUnits(state.pricing.grandTotalCents, state.pricing.currency)} ${state.pricing.currency}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextOnLightPrimary,
                        modifier = Modifier.testTag("extras_total_amount")
                    )
                }

                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = onContinueToPay,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaRed, contentColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("extras_continue_to_pay_button")
                ) {
                    Text(state.strings.continueToPay, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                }
                OutlinedButton(
                    onClick = onSkipExtras,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, TextOnLightPrimary.copy(alpha = 0.5f)),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White, contentColor = TextOnLightPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("extras_skip_button")
                ) {
                    Text(state.strings.skipExtras, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (isCompactWidth) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(KioskBlack)
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            mainContent(Modifier.fillMaxWidth().heightIn(max = 560.dp))
            summaryPanel()
        }
    } else {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(KioskBlack)
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            mainContent(Modifier.weight(0.68f).fillMaxHeight())
            Box(
                modifier = Modifier
                    .weight(0.32f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState())
            ) {
                summaryPanel()
            }
        }
    }
}

@Composable
private fun ConcessionProductCard(
    product: ConcessionProductEntity,
    quantity: Int,
    currency: String,
    onDelta: (Int) -> Unit
) {
    val soldOut = !product.isAvailable || product.stockCount <= 0
    Surface(
        color = if (quantity > 0) CinemaRedSoft.copy(alpha = 0.45f) else SummaryGrey,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (quantity > 0) CinemaRed else SummaryGreyBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextOnLightPrimary)
                    Surface(color = KioskCharcoal, shape = RoundedCornerShape(6.dp)) {
                        Text(
                            text = product.sizeLabel,
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    if (product.comboDetails != null) {
                        Surface(color = StatusSuccess.copy(alpha = 0.15f), shape = RoundedCornerShape(6.dp)) {
                            Text(
                                text = product.comboDetails,
                                color = StatusSuccess,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(2.dp))
                Text(product.description, style = MaterialTheme.typography.bodySmall, color = TextOnLightSecondary)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "${formatMinorUnits(product.priceCents, currency)}  •  ${if (soldOut) "Out of stock" else "${product.stockCount} in stock"}  •  ${product.collectionLocation}",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (soldOut) StatusError else TextOnLightPrimary,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = { onDelta(-1) },
                    enabled = quantity > 0,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("concession_minus_${product.id}")
                ) {
                    Icon(Icons.Filled.RemoveCircleOutline, contentDescription = "Remove ${product.name}", tint = if (quantity > 0) CinemaRed else Color.Gray)
                }
                Text(
                    text = "$quantity",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextOnLightPrimary
                )
                IconButton(
                    onClick = { onDelta(1) },
                    enabled = !soldOut && quantity < product.stockCount,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("concession_plus_${product.id}")
                ) {
                    Icon(Icons.Filled.AddCircle, contentDescription = "Add ${product.name}", tint = if (!soldOut) CinemaRed else Color.Gray)
                }
            }
        }
    }
}
