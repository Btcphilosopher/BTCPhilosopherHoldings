package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.data.repository.*
import com.example.domain.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

data class KioskBanner(
    val message: String,
    val isError: Boolean = false,
    val isWarning: Boolean = false
)

data class KioskUiState(
    val brandConfig: BrandConfig = BrandConfig(),
    val language: KioskLanguage = KioskLanguage.ENGLISH,
    val strings: LocalizedStrings = stringsFor(KioskLanguage.ENGLISH),
    val accessibility: AccessibilityPreferences = AccessibilityPreferences(),
    val sessionId: String = "KIO-SESS-001",
    val currentStep: CheckoutStep = CheckoutStep.SELECT_SEATS,
    val cinemas: List<CinemaEntity> = emptyList(),
    val selectedCinema: CinemaEntity? = null,
    val auditoriums: List<AuditoriumEntity> = emptyList(),
    val films: List<FilmEntity> = emptyList(),
    val screenings: List<ScreeningEntity> = emptyList(),
    val selectedFilm: FilmEntity? = null,
    val selectedScreening: ScreeningEntity? = null,
    val selectedAuditorium: AuditoriumEntity? = null,
    val selectedDateFilter: String = "Today",
    val selectedFormatFilter: String = "All",
    val showComingSoon: Boolean = false,
    val seatMap: List<SeatDisplayItem> = emptyList(),
    val heldSeats: List<SeatDisplayItem> = emptyList(),
    val concessions: List<ConcessionProductEntity> = emptyList(),
    val concessionQuantities: Map<String, Int> = emptyMap(),
    val collectionLocation: String = "Lobby Express Counter A",
    val membership: MembershipAccount? = null,
    val membershipLookupError: String? = null,
    val membershipServiceUnavailable: Boolean = false,
    val pricing: PricingBreakdown = PricingBreakdown(),
    val holdSecondsRemaining: Int? = null,
    val showHoldExpiryWarning: Boolean = false,
    val inactivitySecondsRemaining: Int = 272,
    val showInactivityWarning: Boolean = false,
    val isProcessingPayment: Boolean = false,
    val uncertainTransactionId: String? = null,
    val issuanceRecoveryTransactionId: String? = null,
    val paymentStatusMessage: String? = null,
    val completedBooking: BookingBundle? = null,
    val printerWarning: String? = null,
    val notificationSummary: String? = null,
    val foundBooking: BookingBundle? = null,
    val findBookingError: String? = null,
    val banner: KioskBanner? = null,
    val kioskConfig: KioskConfigEntity? = null,
    val allBookings: List<BookingEntity> = emptyList(),
    val allPayments: List<PaymentTransactionEntity> = emptyList(),
    val auditLogs: List<AuditLogEntity> = emptyList(),
    val authenticatedStaff: AuthenticatedStaff? = null,
    val staffActionFeedback: String? = null,
    val activeCheckoutIdempotencyKey: String = UUID.randomUUID().toString(),
    // Modal state
    val showLocationDialog: Boolean = false,
    val showAccessibilityDialog: Boolean = false,
    val showTextSeatSelector: Boolean = false,
    val showMembershipDialog: Boolean = false,
    val showFindBookingDialog: Boolean = false,
    val showAssistanceDialog: Boolean = false,
    val showStartOverDialog: Boolean = false,
    val showStaffAuthDialog: Boolean = false,
    val showStaffPortal: Boolean = false,
    val showRefundTermsDialog: Boolean = false
)

class KioskViewModel(application: Application) : AndroidViewModel(application) {
    private val database = CinemaDatabase.getInstance(application)
    val repository = ReservationRepository(database.cinemaDao())

    private val _sessionId = MutableStateFlow("KIO-SESS-${UUID.randomUUID().toString().take(6).uppercase()}")
    private val _selectedCinemaId = MutableStateFlow("cin_century_city")
    private val _selectedFilmId = MutableStateFlow("film_orbital_dawn")
    private val _selectedScreeningId = MutableStateFlow("scr_od_cc_1915")
    private val _dateFilter = MutableStateFlow("Today")
    private val _formatFilter = MutableStateFlow("All")
    private val _showComingSoon = MutableStateFlow(false)
    private val _step = MutableStateFlow(CheckoutStep.SELECT_SEATS)
    private val _language = MutableStateFlow(KioskLanguage.ENGLISH)
    private val _accessibility = MutableStateFlow(AccessibilityPreferences())
    private val _concessionQty = MutableStateFlow<Map<String, Int>>(emptyMap())
    private val _collectionLocation = MutableStateFlow("Lobby Express Counter A")
    private val _membership = MutableStateFlow<MembershipAccount?>(null)
    private val _pricing = MutableStateFlow(PricingBreakdown())
    private val _inactivitySec = MutableStateFlow(272)

    private val _ephemeralState = MutableStateFlow(EphemeralUiFlags())

    private data class EphemeralUiFlags(
        val membershipLookupError: String? = null,
        val membershipUnavailable: Boolean = false,
        val isProcessingPayment: Boolean = false,
        val uncertainTxId: String? = null,
        val issuanceRecoveryTxId: String? = null,
        val paymentStatusMessage: String? = null,
        val completedBooking: BookingBundle? = null,
        val printerWarning: String? = null,
        val notificationSummary: String? = null,
        val foundBooking: BookingBundle? = null,
        val findBookingError: String? = null,
        val banner: KioskBanner? = null,
        val authenticatedStaff: AuthenticatedStaff? = null,
        val staffActionFeedback: String? = null,
        val idempotencyKey: String = UUID.randomUUID().toString(),
        val showLocationDialog: Boolean = false,
        val showAccessibilityDialog: Boolean = false,
        val showTextSeatSelector: Boolean = false,
        val showMembershipDialog: Boolean = false,
        val showFindBookingDialog: Boolean = false,
        val showAssistanceDialog: Boolean = false,
        val showStartOverDialog: Boolean = false,
        val showStaffAuthDialog: Boolean = false,
        val showStaffPortal: Boolean = false,
        val showRefundTermsDialog: Boolean = false
    )

    private val _nowTickMs = MutableStateFlow(repository.clock.nowMs())

    private val _uiState = MutableStateFlow(KioskUiState())
    val uiState: StateFlow<KioskUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeSeedData()
            repository.startBackgroundWorker(this)
        }

        // Countdown ticker for hold expiry & kiosk inactivity timeout
        viewModelScope.launch {
            while (isActive) {
                delay(1000L)
                _nowTickMs.value = repository.clock.nowMs()
                val flags = _ephemeralState.value
                val inModalOrStaff = flags.showStaffPortal || _step.value == CheckoutStep.TICKET_COLLECTION
                if (!inModalOrStaff && !flags.isProcessingPayment) {
                    val next = (_inactivitySec.value - 1).coerceAtLeast(0)
                    _inactivitySec.value = next
                    if (next == 0) {
                        resetKioskSession(reason = "Session automatically reset due to kiosk inactivity.")
                    }
                }
            }
        }

        // Real-time seat conflict / update stream
        viewModelScope.launch {
            repository.seatEvents.collect { event ->
                if (event.screeningId == _selectedScreeningId.value) {
                    recalculatePricing()
                }
            }
        }

        // Combine database reactive flows + UI state
        viewModelScope.launch {
            val baseCatalogFlow = combine(
                repository.cinemas,
                repository.films,
                repository.allScreenings,
                repository.concessions,
                repository.kioskConfig
            ) { cinemas, films, screenings, concessions, config ->
                CatalogSnapshot(cinemas, films, screenings, concessions, config)
            }

            val selectionFlow = combine(
                _selectedCinemaId,
                _selectedFilmId,
                _selectedScreeningId,
                _dateFilter,
                _formatFilter
            ) { cinemaId, filmId, screeningId, date, format ->
                SelectionSnapshot(cinemaId, filmId, screeningId, date, format)
            }

            val seatDefsFlow = _selectedScreeningId.flatMapLatest { scrId ->
                repository.allScreenings.map { list -> list.firstOrNull { it.id == scrId } }
            }.flatMapLatest { scr ->
                if (scr == null) flowOf(emptyList())
                else repository.observeSeatDefinitions(scr.auditoriumId)
            }

            val seatLocksFlow = _selectedScreeningId.flatMapLatest { scrId ->
                repository.observeSeatLocks(scrId)
            }

            val auditoriumsFlow = _selectedCinemaId.flatMapLatest { cId ->
                repository.observeAuditoriums(cId)
            }

            val adminFlow = combine(
                repository.bookings,
                repository.paymentTransactions,
                repository.auditLogs
            ) { b, p, a -> Triple(b, p, a) }

            combine(
                baseCatalogFlow,
                selectionFlow,
                seatDefsFlow,
                seatLocksFlow,
                auditoriumsFlow
            ) { catalog, sel, defs, locks, auds ->
                CombinedCore(catalog, sel, defs, locks, auds)
            }.combine(
                combine(
                    _sessionId,
                    _step,
                    _language,
                    _accessibility,
                    _concessionQty
                ) { sid, step, lang, acc, conc ->
                    SessionPrefs(sid, step, lang, acc, conc)
                }
            ) { core, prefs ->
                core to prefs
            }.combine(
                combine(
                    _membership,
                    _pricing,
                    _ephemeralState,
                    _nowTickMs,
                    _inactivitySec
                ) { mem, prc, eph, now, inact ->
                    RuntimeState(mem, prc, eph, now, inact)
                }
            ) { (core, prefs), runtime ->
                Pair(Triple(core, prefs, runtime), Unit)
            }.combine(adminFlow) { (triple, _), admin ->
                val (core, prefs, runtime) = triple
                val (catalog, sel, defs, locks, auds) = core
                val selectedCinema = catalog.cinemas.firstOrNull { it.id == sel.cinemaId } ?: catalog.cinemas.firstOrNull()
                val cinemaScreenings = catalog.screenings.filter { it.cinemaId == (selectedCinema?.id ?: sel.cinemaId) }
                val selectedFilm = catalog.films.firstOrNull { it.id == sel.filmId } ?: catalog.films.firstOrNull()
                val selectedScreening = cinemaScreenings.firstOrNull { it.id == sel.screeningId }
                    ?: cinemaScreenings.firstOrNull { it.filmId == selectedFilm?.id }
                    ?: cinemaScreenings.firstOrNull()
                val selectedAud = auds.firstOrNull { it.id == selectedScreening?.auditoriumId }

                val lockByCode = locks.associateBy { it.seatCode }
                val seatItems = defs.map { def ->
                    val lock = lockByCode[def.seatCode]
                    val seatType = runCatching { SeatType.valueOf(def.seatType) }.getOrDefault(SeatType.STANDARD)
                    val isExpiredHold = lock != null && lock.lockType == "HOLD" &&
                        lock.protectedForPaymentId == null &&
                        (lock.expiresAtEpochMs ?: Long.MAX_VALUE) <= runtime.nowMs
                    val effectiveStatus = when {
                        def.isMaintenanceBlocked -> SeatStatus.UNAVAILABLE
                        lock == null || isExpiredHold -> SeatStatus.AVAILABLE
                        lock.lockType == "SOLD" -> SeatStatus.SOLD
                        lock.ownerSessionId == prefs.sessionId -> SeatStatus.HELD_BY_THIS_SESSION
                        else -> SeatStatus.HELD_BY_OTHER_SESSION
                    }
                    val cat = lock?.let {
                        runCatching { TicketCategory.valueOf(it.ticketCategory) }.getOrDefault(TicketCategory.ADULT)
                    } ?: TicketCategory.ADULT
                    SeatDisplayItem(
                        seatCode = def.seatCode,
                        rowLabel = def.rowLabel,
                        seatNumber = def.seatNumber,
                        blockSide = def.blockSide,
                        seatType = seatType,
                        status = effectiveStatus,
                        ticketCategory = cat,
                        pairedAccessibleSeatCode = def.pairedAccessibleSeatCode,
                        holdExpiresAtEpochMs = lock?.expiresAtEpochMs
                    )
                }

                val heldSeats = seatItems.filter { it.status == SeatStatus.HELD_BY_THIS_SESSION }
                val minExpiry = heldSeats.mapNotNull { it.holdExpiresAtEpochMs }.minOrNull()
                val holdSecRemaining = minExpiry?.let { ((it - runtime.nowMs) / 1000L).toInt().coerceAtLeast(0) }
                val configTimeout = catalog.config?.inactivityTimeoutSeconds ?: 300

                KioskUiState(
                    language = prefs.language,
                    strings = stringsFor(prefs.language),
                    accessibility = prefs.accessibility,
                    sessionId = prefs.sessionId,
                    currentStep = prefs.step,
                    cinemas = catalog.cinemas,
                    selectedCinema = selectedCinema,
                    auditoriums = auds,
                    films = catalog.films,
                    screenings = cinemaScreenings,
                    selectedFilm = selectedFilm,
                    selectedScreening = selectedScreening,
                    selectedAuditorium = selectedAud,
                    selectedDateFilter = sel.dateFilter,
                    selectedFormatFilter = sel.formatFilter,
                    showComingSoon = _showComingSoon.value,
                    seatMap = seatItems,
                    heldSeats = heldSeats,
                    concessions = catalog.concessions,
                    concessionQuantities = prefs.concessionQuantities,
                    collectionLocation = _collectionLocation.value,
                    membership = runtime.membership,
                    membershipLookupError = runtime.ephemeral.membershipLookupError,
                    membershipServiceUnavailable = runtime.ephemeral.membershipUnavailable,
                    pricing = runtime.pricing,
                    holdSecondsRemaining = holdSecRemaining,
                    showHoldExpiryWarning = holdSecRemaining != null && holdSecRemaining in 1..60,
                    inactivitySecondsRemaining = runtime.inactivitySec,
                    showInactivityWarning = runtime.inactivitySec in 1..30 && configTimeout > 30,
                    isProcessingPayment = runtime.ephemeral.isProcessingPayment,
                    uncertainTransactionId = runtime.ephemeral.uncertainTxId,
                    issuanceRecoveryTransactionId = runtime.ephemeral.issuanceRecoveryTxId,
                    paymentStatusMessage = runtime.ephemeral.paymentStatusMessage,
                    completedBooking = runtime.ephemeral.completedBooking,
                    printerWarning = runtime.ephemeral.printerWarning,
                    notificationSummary = runtime.ephemeral.notificationSummary,
                    foundBooking = runtime.ephemeral.foundBooking,
                    findBookingError = runtime.ephemeral.findBookingError,
                    banner = runtime.ephemeral.banner,
                    kioskConfig = catalog.config,
                    allBookings = admin.first,
                    allPayments = admin.second,
                    auditLogs = admin.third,
                    authenticatedStaff = runtime.ephemeral.authenticatedStaff,
                    staffActionFeedback = runtime.ephemeral.staffActionFeedback,
                    activeCheckoutIdempotencyKey = runtime.ephemeral.idempotencyKey,
                    showLocationDialog = runtime.ephemeral.showLocationDialog,
                    showAccessibilityDialog = runtime.ephemeral.showAccessibilityDialog,
                    showTextSeatSelector = runtime.ephemeral.showTextSeatSelector,
                    showMembershipDialog = runtime.ephemeral.showMembershipDialog,
                    showFindBookingDialog = runtime.ephemeral.showFindBookingDialog,
                    showAssistanceDialog = runtime.ephemeral.showAssistanceDialog,
                    showStartOverDialog = runtime.ephemeral.showStartOverDialog,
                    showStaffAuthDialog = runtime.ephemeral.showStaffAuthDialog,
                    showStaffPortal = runtime.ephemeral.showStaffPortal,
                    showRefundTermsDialog = runtime.ephemeral.showRefundTermsDialog
                )
            }.collect { state ->
                _uiState.value = state
            }
        }
    }

    private data class CatalogSnapshot(
        val cinemas: List<CinemaEntity>,
        val films: List<FilmEntity>,
        val screenings: List<ScreeningEntity>,
        val concessions: List<ConcessionProductEntity>,
        val config: KioskConfigEntity?
    )

    private data class SelectionSnapshot(
        val cinemaId: String,
        val filmId: String,
        val screeningId: String,
        val dateFilter: String,
        val formatFilter: String
    )

    private data class CombinedCore(
        val catalog: CatalogSnapshot,
        val selection: SelectionSnapshot,
        val seatDefs: List<SeatDefinitionEntity>,
        val seatLocks: List<SeatLockEntity>,
        val auditoriums: List<AuditoriumEntity>
    )

    private data class SessionPrefs(
        val sessionId: String,
        val step: CheckoutStep,
        val language: KioskLanguage,
        val accessibility: AccessibilityPreferences,
        val concessionQuantities: Map<String, Int>
    )

    private data class RuntimeState(
        val membership: MembershipAccount?,
        val pricing: PricingBreakdown,
        val ephemeral: EphemeralUiFlags,
        val nowMs: Long,
        val inactivitySec: Int
    )

    fun registerUserInteraction() {
        val defaultTimeout = _uiState.value.kioskConfig?.inactivityTimeoutSeconds ?: 300
        _inactivitySec.value = defaultTimeout.coerceAtLeast(60)
    }

    fun dismissBanner() {
        _ephemeralState.update { it.copy(banner = null) }
    }

    fun setLanguage(lang: KioskLanguage) {
        registerUserInteraction()
        _language.value = lang
    }

    fun updateAccessibility(transform: (AccessibilityPreferences) -> AccessibilityPreferences) {
        registerUserInteraction()
        _accessibility.update(transform)
    }

    fun selectCinema(cinemaId: String) {
        registerUserInteraction()
        viewModelScope.launch {
            repository.releaseSessionHolds(_sessionId.value)
            _selectedCinemaId.value = cinemaId
            val screenings = repository.allScreenings.first().filter { it.cinemaId == cinemaId }
            val nextScreening = screenings.firstOrNull { it.filmId == _selectedFilmId.value } ?: screenings.firstOrNull()
            if (nextScreening != null) {
                _selectedFilmId.value = nextScreening.filmId
                _selectedScreeningId.value = nextScreening.id
            }
            _ephemeralState.update { it.copy(showLocationDialog = false, banner = null) }
            recalculatePricing()
        }
    }

    fun setDateFilter(dateLabel: String) {
        registerUserInteraction()
        _dateFilter.value = dateLabel
        viewModelScope.launch {
            val screenings = repository.allScreenings.first()
                .filter { it.cinemaId == _selectedCinemaId.value && it.dateDisplayLabel == dateLabel }
            val currentFilmMatch = screenings.firstOrNull { it.filmId == _selectedFilmId.value }
                ?: screenings.firstOrNull()
            if (currentFilmMatch != null && currentFilmMatch.id != _selectedScreeningId.value) {
                selectFilmAndScreening(currentFilmMatch.filmId, currentFilmMatch.id)
            }
        }
    }

    fun setFormatFilter(format: String) {
        registerUserInteraction()
        _formatFilter.value = format
    }

    fun setShowComingSoon(comingSoon: Boolean) {
        registerUserInteraction()
        _showComingSoon.value = comingSoon
    }

    fun selectFilmAndScreening(filmId: String, screeningId: String? = null) {
        registerUserInteraction()
        viewModelScope.launch {
            val allScreenings = repository.allScreenings.first()
                .filter { it.cinemaId == _selectedCinemaId.value && it.filmId == filmId }
            val targetScreening = if (screeningId != null) {
                allScreenings.firstOrNull { it.id == screeningId }
            } else {
                allScreenings.firstOrNull { it.dateDisplayLabel == _dateFilter.value } ?: allScreenings.firstOrNull()
            }

            if (targetScreening == null) {
                val film = _uiState.value.films.firstOrNull { it.id == filmId }
                _ephemeralState.update {
                    it.copy(
                        banner = KioskBanner(
                            "${film?.title ?: "This film"} is coming soon — ticket sales are not open yet.",
                            isWarning = true
                        )
                    )
                }
                return@launch
            }

            if (targetScreening.id != _selectedScreeningId.value) {
                // Release obsolete holds when switching screening or film!
                repository.releaseSessionHolds(_sessionId.value, _selectedScreeningId.value)
            }
            _selectedFilmId.value = filmId
            _selectedScreeningId.value = targetScreening.id
            if (_step.value == CheckoutStep.FILM_AND_TIME) {
                _step.value = CheckoutStep.SELECT_SEATS
            }
            _ephemeralState.update { it.copy(banner = null, idempotencyKey = UUID.randomUUID().toString()) }
            recalculatePricing()
        }
    }

    fun toggleSeat(seatCode: String) {
        registerUserInteraction()
        viewModelScope.launch {
            val state = _uiState.value
            val screening = state.selectedScreening ?: return@launch
            val seat = state.seatMap.firstOrNull { it.seatCode == seatCode } ?: return@launch
            if (seat.status == SeatStatus.HELD_BY_THIS_SESSION) {
                repository.releaseSeat(screening.id, seatCode, state.sessionId)
            } else if (seat.status == SeatStatus.AVAILABLE) {
                val res = repository.holdSeat(screening.id, seatCode, state.sessionId, TicketCategory.ADULT)
                if (res is OperationResult.Failure) {
                    _ephemeralState.update { it.copy(banner = KioskBanner(res.userMessage, isError = true)) }
                } else {
                    _ephemeralState.update { it.copy(banner = null, idempotencyKey = UUID.randomUUID().toString()) }
                }
            } else {
                val reason = when (seat.status) {
                    SeatStatus.HELD_BY_OTHER_SESSION -> "Seat $seatCode is currently held by another customer."
                    SeatStatus.SOLD -> "Seat $seatCode is already sold."
                    else -> "Seat $seatCode is unavailable."
                }
                _ephemeralState.update { it.copy(banner = KioskBanner(reason, isWarning = true)) }
            }
            recalculatePricing()
        }
    }

    fun updateSeatCategory(seatCode: String, category: TicketCategory) {
        registerUserInteraction()
        viewModelScope.launch {
            val scrId = _selectedScreeningId.value
            repository.updateHeldSeatCategory(scrId, seatCode, _sessionId.value, category)
            _ephemeralState.update { it.copy(idempotencyKey = UUID.randomUUID().toString()) }
            recalculatePricing()
        }
    }

    fun setAllHeldSeatsCategory(category: TicketCategory) {
        registerUserInteraction()
        viewModelScope.launch {
            val scrId = _selectedScreeningId.value
            _uiState.value.heldSeats.forEach { seat ->
                repository.updateHeldSeatCategory(scrId, seat.seatCode, _sessionId.value, category)
            }
            _ephemeralState.update { it.copy(idempotencyKey = UUID.randomUUID().toString()) }
            recalculatePricing()
        }
    }

    fun extendHold() {
        registerUserInteraction()
        viewModelScope.launch {
            val res = repository.extendSessionHolds(_selectedScreeningId.value, _sessionId.value, 120)
            when (res) {
                is OperationResult.Success -> {
                    _ephemeralState.update { it.copy(banner = KioskBanner("Seat hold extended by 2 minutes.")) }
                }
                is OperationResult.Failure -> {
                    _ephemeralState.update { it.copy(banner = KioskBanner(res.userMessage, isWarning = true)) }
                }
            }
        }
    }

    fun navigateToStep(target: CheckoutStep) {
        registerUserInteraction()
        val state = _uiState.value
        if ((target == CheckoutStep.EXTRAS || target == CheckoutStep.PAY_AND_COLLECT) && state.heldSeats.isEmpty()) {
            _ephemeralState.update {
                it.copy(banner = KioskBanner("Please select at least one seat before continuing.", isWarning = true))
            }
            return
        }
        _step.value = target
        _ephemeralState.update { it.copy(banner = null) }
        recalculatePricing()
    }

    fun skipExtrasToPayment() {
        registerUserInteraction()
        if (_uiState.value.heldSeats.isEmpty()) {
            _ephemeralState.update {
                it.copy(banner = KioskBanner("Select seats first before continuing to payment.", isWarning = true))
            }
            return
        }
        _concessionQty.value = emptyMap()
        _step.value = CheckoutStep.PAY_AND_COLLECT
        recalculatePricing()
    }

    fun updateConcessionQuantity(productId: String, delta: Int) {
        registerUserInteraction()
        val prod = _uiState.value.concessions.firstOrNull { it.id == productId } ?: return
        val current = _concessionQty.value[productId] ?: 0
        val next = (current + delta).coerceAtLeast(0).coerceAtMost(prod.stockCount)
        _concessionQty.update { map ->
            val mutable = map.toMutableMap()
            if (next == 0) mutable.remove(productId) else mutable[productId] = next
            mutable
        }
        _ephemeralState.update { it.copy(idempotencyKey = UUID.randomUUID().toString()) }
        recalculatePricing()
    }

    fun setCollectionLocation(location: String) {
        registerUserInteraction()
        _collectionLocation.value = location
    }

    fun lookupMembership(identifier: String) {
        registerUserInteraction()
        viewModelScope.launch {
            when (val res = repository.lookupMembership(identifier)) {
                is MembershipLookupResult.Found -> {
                    _membership.value = res.account
                    _ephemeralState.update {
                        it.copy(
                            membershipLookupError = null,
                            membershipUnavailable = false,
                            showMembershipDialog = false,
                            idempotencyKey = UUID.randomUUID().toString(),
                            banner = KioskBanner("${res.account.tierName} applied.")
                        )
                    }
                    recalculatePricing()
                }
                is MembershipLookupResult.NotFound -> {
                    _ephemeralState.update {
                        it.copy(
                            membershipLookupError = "No demo membership matched \"${res.query}\". Try CLUB-1001, CLUB-2002, or continue as guest.",
                            membershipUnavailable = false
                        )
                    }
                }
                is MembershipLookupResult.ServiceUnavailable -> {
                    _ephemeralState.update {
                        it.copy(
                            membershipLookupError = res.message,
                            membershipUnavailable = true
                        )
                    }
                }
            }
        }
    }

    fun clearMembership() {
        registerUserInteraction()
        _membership.value = null
        recalculatePricing()
    }

    fun submitPayment(
        outcome: PaymentOutcome,
        notificationChannel: String?,
        notificationTarget: String?
    ) {
        registerUserInteraction()
        viewModelScope.launch {
            val state = _uiState.value
            val screening = state.selectedScreening ?: return@launch
            _ephemeralState.update { it.copy(isProcessingPayment = true, paymentStatusMessage = null, banner = null) }

            val result = repository.processCheckout(
                idempotencyKey = state.activeCheckoutIdempotencyKey,
                sessionId = state.sessionId,
                screeningId = screening.id,
                concessionQuantities = state.concessionQuantities,
                membership = state.membership,
                collectionLocation = state.collectionLocation,
                notificationChannel = notificationChannel,
                notificationTarget = notificationTarget,
                simulatedOutcome = outcome
            )

            when (result) {
                is CheckoutProcessingResult.Completed -> {
                    _ephemeralState.update {
                        it.copy(
                            isProcessingPayment = false,
                            completedBooking = result.bundle,
                            printerWarning = result.printerWarning,
                            notificationSummary = result.notificationResult?.summary,
                            uncertainTxId = null,
                            issuanceRecoveryTxId = null
                        )
                    }
                    _step.value = CheckoutStep.TICKET_COLLECTION
                }
                is CheckoutProcessingResult.PaymentNotCompleted -> {
                    _ephemeralState.update {
                        it.copy(
                            isProcessingPayment = false,
                            paymentStatusMessage = result.message,
                            idempotencyKey = UUID.randomUUID().toString(),
                            banner = KioskBanner(result.message, isWarning = true)
                        )
                    }
                }
                is CheckoutProcessingResult.UncertainPayment -> {
                    _ephemeralState.update {
                        it.copy(
                            isProcessingPayment = false,
                            uncertainTxId = result.transactionId,
                            paymentStatusMessage = result.message,
                            banner = KioskBanner(result.message, isWarning = true)
                        )
                    }
                }
                is CheckoutProcessingResult.IssuanceRecoveryRequired -> {
                    _ephemeralState.update {
                        it.copy(
                            isProcessingPayment = false,
                            issuanceRecoveryTxId = result.transactionId,
                            paymentStatusMessage = result.message,
                            banner = KioskBanner(result.message, isError = true)
                        )
                    }
                }
                is CheckoutProcessingResult.Error -> {
                    _ephemeralState.update {
                        it.copy(
                            isProcessingPayment = false,
                            paymentStatusMessage = result.message,
                            banner = KioskBanner(result.message, isError = true)
                        )
                    }
                }
            }
        }
    }

    fun recoverUncertainPayment(reverseInsteadOfComplete: Boolean) {
        val txId = _ephemeralState.value.uncertainTxId ?: return
        viewModelScope.launch {
            _ephemeralState.update { it.copy(isProcessingPayment = true) }
            val res = repository.reconcileUncertainPayment(txId, reverseInsteadOfComplete)
            when (res) {
                is OperationResult.Success -> {
                    // Check if booking was completed during reconciliation
                    val bookings = repository.bookings.first()
                    val matched = bookings.firstOrNull { it.paymentTransactionId == txId }
                    if (matched != null) {
                        val lookup = repository.lookupBooking(matched.bookingRef, matched.verificationCode)
                        if (lookup is OperationResult.Success) {
                            _ephemeralState.update {
                                it.copy(
                                    isProcessingPayment = false,
                                    uncertainTxId = null,
                                    completedBooking = lookup.data,
                                    banner = KioskBanner(res.data)
                                )
                            }
                            _step.value = CheckoutStep.TICKET_COLLECTION
                            return@launch
                        }
                    }
                    _ephemeralState.update {
                        it.copy(
                            isProcessingPayment = false,
                            uncertainTxId = null,
                            paymentStatusMessage = res.data,
                            idempotencyKey = UUID.randomUUID().toString(),
                            banner = KioskBanner(res.data)
                        )
                    }
                }
                is OperationResult.Failure -> {
                    _ephemeralState.update {
                        it.copy(isProcessingPayment = false, banner = KioskBanner(res.userMessage, isError = true))
                    }
                }
            }
        }
    }

    fun retryIssuanceWithoutRecharging() {
        val state = _uiState.value
        val screening = state.selectedScreening ?: return
        viewModelScope.launch {
            _ephemeralState.update { it.copy(isProcessingPayment = true) }
            // Calls processCheckout with the SAME idempotencyKey -> resumes from captured payment without re-charging!
            val result = repository.processCheckout(
                idempotencyKey = state.activeCheckoutIdempotencyKey,
                sessionId = state.sessionId,
                screeningId = screening.id,
                concessionQuantities = state.concessionQuantities,
                membership = state.membership,
                collectionLocation = state.collectionLocation,
                notificationChannel = null,
                notificationTarget = null,
                simulatedOutcome = PaymentOutcome.APPROVED
            )
            if (result is CheckoutProcessingResult.Completed) {
                _ephemeralState.update {
                    it.copy(
                        isProcessingPayment = false,
                        issuanceRecoveryTxId = null,
                        completedBooking = result.bundle,
                        printerWarning = result.printerWarning,
                        banner = KioskBanner("Ticket issuance recovered cleanly — no duplicate charge!")
                    )
                }
                _step.value = CheckoutStep.TICKET_COLLECTION
            } else {
                _ephemeralState.update {
                    it.copy(isProcessingPayment = false, banner = KioskBanner("Recovery failed; please contact staff.", isError = true))
                }
            }
        }
    }

    fun toggleSimulatedPrinterFailure(online: Boolean) {
        viewModelScope.launch {
            repository.setPrinterOnline(online, _ephemeralState.value.authenticatedStaff)
            val msg = if (online) "Printer restored online." else "Simulated printer paper jam active."
            _ephemeralState.update { it.copy(banner = KioskBanner(msg, isWarning = !online)) }
        }
    }

    fun reprintCompletedBooking(bookingRef: String) {
        registerUserInteraction()
        viewModelScope.launch {
            when (val res = repository.reprintBooking(bookingRef)) {
                is OperationResult.Success -> {
                    _ephemeralState.update {
                        it.copy(
                            completedBooking = if (it.completedBooking?.booking?.bookingRef == bookingRef) res.data else it.completedBooking,
                            foundBooking = if (it.foundBooking?.booking?.bookingRef == bookingRef) res.data else it.foundBooking,
                            printerWarning = null,
                            banner = KioskBanner("Reprinted tickets for $bookingRef (no additional charge).")
                        )
                    }
                }
                is OperationResult.Failure -> {
                    _ephemeralState.update {
                        it.copy(
                            printerWarning = res.userMessage,
                            banner = KioskBanner(res.userMessage, isError = true)
                        )
                    }
                }
            }
        }
    }

    fun lookupBooking(bookingRef: String, verificationCode: String) {
        registerUserInteraction()
        viewModelScope.launch {
            when (val res = repository.lookupBooking(bookingRef, verificationCode)) {
                is OperationResult.Success -> {
                    _ephemeralState.update {
                        it.copy(foundBooking = res.data, findBookingError = null)
                    }
                }
                is OperationResult.Failure -> {
                    _ephemeralState.update {
                        it.copy(foundBooking = null, findBookingError = res.userMessage)
                    }
                }
            }
        }
    }

    fun simulateCompetingSession(seatCode: String = "F7") {
        registerUserInteraction()
        viewModelScope.launch {
            val res = repository.simulateCompetingSessionHold(_selectedScreeningId.value, seatCode)
            when (res) {
                is OperationResult.Success -> _ephemeralState.update { it.copy(banner = KioskBanner(res.data, isWarning = true)) }
                is OperationResult.Failure -> _ephemeralState.update { it.copy(banner = KioskBanner(res.userMessage, isError = true)) }
            }
        }
    }

    fun simulateHoldExpiry() {
        registerUserInteraction()
        viewModelScope.launch {
            // Release current holds as expired for demo or fast-forward via repository
            val scrId = _selectedScreeningId.value
            repository.releaseSessionHolds(_sessionId.value, scrId)
            recalculatePricing()
            _ephemeralState.update {
                it.copy(banner = KioskBanner("Simulated hold expiry: unconfirmed seats were released back to inventory.", isWarning = true))
            }
        }
    }

    /**
     * Resets public kiosk state for the next customer:
     * - Releases any unprotected session holds
     * - Clears PII, membership, notification info, completed booking, staff session
     * - Preserves any unsettled transactions securely in Room DB for reconciliation!
     */
    fun resetKioskSession(reason: String? = null) {
        viewModelScope.launch {
            val oldSession = _sessionId.value
            repository.releaseSessionHolds(oldSession)
            val newSession = "KIO-SESS-${UUID.randomUUID().toString().take(6).uppercase()}"
            _sessionId.value = newSession
            _membership.value = null
            _concessionQty.value = emptyMap()
            _collectionLocation.value = "Lobby Express Counter A"
            _step.value = CheckoutStep.SELECT_SEATS
            _selectedCinemaId.value = "cin_century_city"
            _selectedFilmId.value = "film_orbital_dawn"
            _selectedScreeningId.value = "scr_od_cc_1915"
            _dateFilter.value = "Today"
            _formatFilter.value = "All"
            _showComingSoon.value = false
            val defaultTimeout = _uiState.value.kioskConfig?.inactivityTimeoutSeconds ?: 300
            _inactivitySec.value = defaultTimeout
            _ephemeralState.value = EphemeralUiFlags(
                banner = reason?.let { KioskBanner(it) }
            )
            recalculatePricing()
        }
    }

    // --- Dialog Toggles ---
    fun setShowLocationDialog(show: Boolean) { registerUserInteraction(); _ephemeralState.update { it.copy(showLocationDialog = show) } }
    fun setShowAccessibilityDialog(show: Boolean) { registerUserInteraction(); _ephemeralState.update { it.copy(showAccessibilityDialog = show) } }
    fun setShowTextSeatSelector(show: Boolean) { registerUserInteraction(); _ephemeralState.update { it.copy(showTextSeatSelector = show) } }
    fun setShowMembershipDialog(show: Boolean) { registerUserInteraction(); _ephemeralState.update { it.copy(showMembershipDialog = show, membershipLookupError = null) } }
    fun setShowFindBookingDialog(show: Boolean) { registerUserInteraction(); _ephemeralState.update { it.copy(showFindBookingDialog = show, foundBooking = null, findBookingError = null) } }
    fun setShowAssistanceDialog(show: Boolean) { registerUserInteraction(); _ephemeralState.update { it.copy(showAssistanceDialog = show) } }
    fun setShowStartOverDialog(show: Boolean) { registerUserInteraction(); _ephemeralState.update { it.copy(showStartOverDialog = show) } }
    fun setShowStaffAuthDialog(show: Boolean) { _ephemeralState.update { it.copy(showStaffAuthDialog = show, staffActionFeedback = null) } }
    fun setShowRefundTermsDialog(show: Boolean) { registerUserInteraction(); _ephemeralState.update { it.copy(showRefundTermsDialog = show) } }

    // --- Staff & Administration Actions ---
    fun loginStaff(pin: String) {
        val staff = repository.authenticateStaff(pin)
        if (staff != null) {
            _ephemeralState.update {
                it.copy(
                    authenticatedStaff = staff,
                    showStaffAuthDialog = false,
                    showStaffPortal = true,
                    staffActionFeedback = "Signed in as ${staff.displayName} (${staff.role.label})."
                )
            }
        } else {
            _ephemeralState.update { it.copy(staffActionFeedback = "Invalid staff PIN. Try 2410 (Staff), 3615 (Supervisor), or 4820 (Manager).") }
        }
    }

    fun logoutStaff() {
        _ephemeralState.update { it.copy(authenticatedStaff = null, showStaffPortal = false, staffActionFeedback = null) }
    }

    fun staffAdmitQr(qrToken: String) {
        val staff = _ephemeralState.value.authenticatedStaff ?: return
        viewModelScope.launch {
            when (val res = repository.admitTicket(qrToken, staff)) {
                is OperationResult.Success -> _ephemeralState.update {
                    it.copy(staffActionFeedback = "ADMITTED: Seat ${res.data.seatCode} (${res.data.bookingRef}) verified & checked in.")
                }
                is OperationResult.Failure -> _ephemeralState.update {
                    it.copy(staffActionFeedback = res.userMessage)
                }
            }
        }
    }

    fun staffReverseAdmission(qrToken: String) {
        val staff = _ephemeralState.value.authenticatedStaff ?: return
        viewModelScope.launch {
            when (val res = repository.reverseTicketAdmission(qrToken, staff)) {
                is OperationResult.Success -> _ephemeralState.update {
                    it.copy(staffActionFeedback = "Admission reversed for seat ${res.data.seatCode}.")
                }
                is OperationResult.Failure -> _ephemeralState.update {
                    it.copy(staffActionFeedback = res.userMessage)
                }
            }
        }
    }

    fun staffRefundBooking(bookingRef: String, reason: String) {
        val staff = _ephemeralState.value.authenticatedStaff ?: return
        viewModelScope.launch {
            when (val res = repository.refundBooking(bookingRef, reason, staff)) {
                is OperationResult.Success -> _ephemeralState.update {
                    it.copy(staffActionFeedback = "Refunded booking $bookingRef and released seats.")
                }
                is OperationResult.Failure -> _ephemeralState.update {
                    it.copy(staffActionFeedback = res.userMessage)
                }
            }
        }
    }

    fun staffReissueBooking(bookingRef: String) {
        val staff = _ephemeralState.value.authenticatedStaff ?: return
        viewModelScope.launch {
            when (val res = repository.reissueTicket(bookingRef, staff)) {
                is OperationResult.Success -> _ephemeralState.update {
                    it.copy(staffActionFeedback = "Reissued fresh QR tokens for $bookingRef.")
                }
                is OperationResult.Failure -> _ephemeralState.update {
                    it.copy(staffActionFeedback = res.userMessage)
                }
            }
        }
    }

    fun staffToggleSeatMaintenance(auditoriumId: String, seatCode: String, blocked: Boolean) {
        val staff = _ephemeralState.value.authenticatedStaff ?: return
        viewModelScope.launch {
            val res = repository.toggleSeatMaintenance(auditoriumId, seatCode, blocked, staff)
            val msg = if (res is OperationResult.Success) "Updated seat $seatCode maintenance=$blocked." else (res as OperationResult.Failure).userMessage
            _ephemeralState.update { it.copy(staffActionFeedback = msg) }
        }
    }

    fun staffToggleScreeningStatus(screening: ScreeningEntity) {
        val staff = _ephemeralState.value.authenticatedStaff ?: return
        viewModelScope.launch {
            val res = if (screening.status == "ACTIVE") repository.cancelScreening(screening.id, staff)
            else repository.restoreScreening(screening.id, staff)
            val msg = if (res is OperationResult.Success) "Updated screening ${screening.localTimeLabel} status." else (res as OperationResult.Failure).userMessage
            _ephemeralState.update { it.copy(staffActionFeedback = msg) }
        }
    }

    fun staffUpdatePricing(screeningId: String, adultPriceCents: Long, feeCents: Long, taxBps: Int) {
        val staff = _ephemeralState.value.authenticatedStaff ?: return
        viewModelScope.launch {
            val res = repository.updateScreeningPricing(screeningId, adultPriceCents, feeCents, taxBps, staff)
            val msg = if (res is OperationResult.Success) "Updated pricing for $screeningId." else (res as OperationResult.Failure).userMessage
            _ephemeralState.update { it.copy(staffActionFeedback = msg) }
            recalculatePricing()
        }
    }

    fun staffUpdateConcessionStock(productId: String, stock: Int) {
        val staff = _ephemeralState.value.authenticatedStaff ?: return
        viewModelScope.launch {
            repository.updateConcessionStock(productId, stock, stock > 0, staff)
            _ephemeralState.update { it.copy(staffActionFeedback = "Updated stock for $productId to $stock.") }
        }
    }

    fun staffReconcilePayment(txId: String, reverse: Boolean) {
        val staff = _ephemeralState.value.authenticatedStaff ?: return
        viewModelScope.launch {
            val res = repository.reconcileUncertainPayment(txId, reverse, staff)
            val msg = when (res) {
                is OperationResult.Success -> res.data
                is OperationResult.Failure -> res.userMessage
            }
            _ephemeralState.update { it.copy(staffActionFeedback = msg) }
        }
    }

    private fun recalculatePricing() {
        viewModelScope.launch {
            _pricing.value = repository.calculateServerPricing(
                screeningId = _selectedScreeningId.value,
                sessionId = _sessionId.value,
                concessionQuantities = _concessionQty.value,
                membership = _membership.value
            )
        }
    }
}
