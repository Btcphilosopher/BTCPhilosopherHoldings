package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "cinemas")
data class CinemaEntity(
    @PrimaryKey val id: String,
    val name: String,
    val city: String,
    val timezoneId: String,
    val address: String,
    val auditoriumCount: Int
)

@Entity(
    tableName = "auditoriums",
    indices = [Index(value = ["cinemaId"])]
)
data class AuditoriumEntity(
    @PrimaryKey val id: String,
    val cinemaId: String,
    val name: String,
    val rowLabelsCsv: String,
    val seatsPerRow: Int,
    val aisleAfterSeat: Int,
    val hasWheelchairAccess: Boolean,
    val hasClosedCaption: Boolean,
    val hasAudioDescription: Boolean
)

@Entity(tableName = "films")
data class FilmEntity(
    @PrimaryKey val id: String,
    val title: String,
    val synopsis: String,
    val runtimeMinutes: Int,
    val classification: String,
    val jurisdiction: String,
    val language: String,
    val subtitleInfo: String,
    val posterKey: String,
    val availableFormatsCsv: String,
    val accessibilityFeaturesCsv: String,
    val admissionPolicy: String,
    val isComingSoon: Boolean,
    val releaseLabel: String
)

@Entity(
    tableName = "screenings",
    indices = [Index(value = ["filmId"]), Index(value = ["cinemaId"]), Index(value = ["screeningDateIso"])]
)
data class ScreeningEntity(
    @PrimaryKey val id: String,
    val filmId: String,
    val cinemaId: String,
    val auditoriumId: String,
    val screeningDateIso: String,
    val dateDisplayLabel: String,
    val localTimeLabel: String,
    val startEpochMs: Long,
    val salesOpenEpochMs: Long,
    val salesCloseEpochMs: Long,
    val format: String,
    val isReservedSeating: Boolean,
    val status: String,
    val adultPriceCents: Long,
    val childPriceCents: Long,
    val seniorPriceCents: Long,
    val studentPriceCents: Long,
    val bookingFeePerTicketCents: Long,
    val taxRateBps: Int,
    val currency: String
)

@Entity(
    tableName = "seat_definitions",
    indices = [Index(value = ["auditoriumId", "seatCode"], unique = true)]
)
data class SeatDefinitionEntity(
    @PrimaryKey val id: String,
    val auditoriumId: String,
    val rowLabel: String,
    val seatNumber: Int,
    val seatCode: String,
    val blockSide: String,
    val seatType: String,
    val isMaintenanceBlocked: Boolean,
    val pairedAccessibleSeatCode: String?
)

/**
 * Authoritative exclusivity table preventing two sessions from holding or purchasing
 * the same seat in the same screening via a UNIQUE database constraint on (screeningId, seatCode).
 */
@Entity(
    tableName = "seat_locks",
    primaryKeys = ["screeningId", "seatCode"],
    indices = [
        Index(value = ["ownerSessionId"]),
        Index(value = ["expiresAtEpochMs"])
    ]
)
data class SeatLockEntity(
    val screeningId: String,
    val seatCode: String,
    val lockType: String, // "HOLD" or "SOLD"
    val ownerSessionId: String,
    val holdId: String?,
    val bookingRef: String?,
    val ticketCategory: String,
    val createdAtEpochMs: Long,
    val expiresAtEpochMs: Long?,
    val protectedForPaymentId: String? = null
)

@Entity(
    tableName = "seat_holds",
    indices = [Index(value = ["screeningId", "sessionId"]), Index(value = ["status"])]
)
data class SeatHoldEntity(
    @PrimaryKey val holdId: String,
    val screeningId: String,
    val seatCode: String,
    val sessionId: String,
    val ticketCategory: String,
    val createdAtEpochMs: Long,
    val expiresAtEpochMs: Long,
    val status: String, // "ACTIVE", "EXPIRED", "RELEASED", "CONVERTED_TO_TICKET"
    val extensionCount: Int = 0
)

@Entity(tableName = "concession_products")
data class ConcessionProductEntity(
    @PrimaryKey val id: String,
    val category: String,
    val name: String,
    val description: String,
    val sizeLabel: String,
    val priceCents: Long,
    val taxRateBps: Int,
    val stockCount: Int,
    val isAvailable: Boolean,
    val collectionLocation: String,
    val comboDetails: String?
)

@Entity(
    tableName = "payment_transactions",
    indices = [Index(value = ["idempotencyKey"], unique = true), Index(value = ["sessionId"])]
)
data class PaymentTransactionEntity(
    @PrimaryKey val transactionId: String,
    val idempotencyKey: String,
    val sessionId: String,
    val screeningId: String,
    val amountCents: Long,
    val currency: String,
    val status: String,
    val providerReference: String,
    val signatureToken: String,
    val outcomeReason: String,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long,
    val needsReconciliation: Boolean,
    val linkedBookingRef: String? = null
)

@Entity(
    tableName = "bookings",
    indices = [Index(value = ["screeningId"]), Index(value = ["idempotencyKey"], unique = true)]
)
data class BookingEntity(
    @PrimaryKey val bookingRef: String,
    val verificationCode: String,
    val idempotencyKey: String,
    val sessionId: String,
    val screeningId: String,
    val cinemaName: String,
    val auditoriumName: String,
    val filmTitle: String,
    val screeningDateTimeLabel: String,
    val membershipAccountId: String?,
    val membershipDiscountCents: Long,
    val bookingFeeCents: Long,
    val taxCents: Long,
    val totalCents: Long,
    val currency: String,
    val paymentTransactionId: String,
    val status: String,
    val ticketFulfillmentStatus: String,
    val concessionFulfillmentStatus: String,
    val printStatus: String,
    val printAttempts: Int,
    val collectionLocation: String,
    val notificationChannel: String?,
    val maskedNotificationTarget: String?,
    val createdAtEpochMs: Long
)

@Entity(
    tableName = "tickets",
    indices = [Index(value = ["bookingRef"]), Index(value = ["qrToken"], unique = true)]
)
data class TicketEntity(
    @PrimaryKey val ticketId: String,
    val bookingRef: String,
    val screeningId: String,
    val seatCode: String,
    val seatType: String,
    val ticketCategory: String,
    val unitPriceCents: Long,
    val qrToken: String,
    val admissionStatus: String,
    val admittedAtEpochMs: Long?,
    val admittedByStaffId: String?,
    val reissueCount: Int
)

@Entity(
    tableName = "concession_order_items",
    indices = [Index(value = ["bookingRef"])]
)
data class ConcessionOrderItemEntity(
    @PrimaryKey val id: String,
    val bookingRef: String,
    val productId: String,
    val productName: String,
    val sizeLabel: String,
    val quantity: Int,
    val unitPriceCents: Long,
    val totalCents: Long,
    val collectionLocation: String,
    val fulfillmentStatus: String
)

@Entity(tableName = "kiosk_config")
data class KioskConfigEntity(
    @PrimaryKey val id: Int = 1,
    val inactivityTimeoutSeconds: Int,
    val holdDurationSeconds: Int,
    val maxHoldExtensions: Int,
    val printerOnline: Boolean,
    val printerStatusMessage: String,
    val membershipServiceOnline: Boolean,
    val paymentGatewayOnline: Boolean,
    val demoModeEnabled: Boolean
)

@Entity(
    tableName = "audit_logs",
    indices = [Index(value = ["timestampEpochMs"])]
)
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val timestampEpochMs: Long,
    val actorStaffId: String,
    val actorRole: String,
    val actionType: String,
    val targetId: String,
    val details: String
)
