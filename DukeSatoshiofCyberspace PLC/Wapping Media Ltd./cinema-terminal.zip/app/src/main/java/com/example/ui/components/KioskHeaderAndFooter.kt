package com.example.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.BrandConfig
import com.example.domain.model.CheckoutStep
import com.example.domain.model.KioskLanguage
import com.example.domain.model.LocalizedStrings
import com.example.ui.theme.*

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun KioskTopHeaderAndHero(
    brandConfig: BrandConfig,
    cinemaLabel: String,
    language: KioskLanguage,
    strings: LocalizedStrings,
    currentStep: CheckoutStep,
    cartCount: Int,
    hasMembership: Boolean,
    isCompactWidth: Boolean,
    onChangeLocationClick: () -> Unit,
    onSelectLanguage: (KioskLanguage) -> Unit,
    onAccessibilityClick: () -> Unit,
    onCartClick: () -> Unit,
    onFindBookingClick: () -> Unit,
    onStepClick: (CheckoutStep) -> Unit,
    onSecretStaffTrigger: () -> Unit
) {
    var langExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(KioskBlack, KioskCharcoal)
                )
            )
            .statusBarsPadding()
    ) {
        // Top Utility Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = if (isCompactWidth) 12.dp else 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Brand Badge + Cinema Location
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f, fill = false)
            ) {
                // Circular Red Brand Badge (long-press opens hidden Staff Auth gate — invisible in guest mode)
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(CinemaRed)
                        .combinedClickable(
                            onClick = {},
                            onLongClick = onSecretStaffTrigger
                        )
                        .semantics { contentDescription = "${brandConfig.brandTitle} emblem" }
                        .testTag("brand_emblem"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = brandConfig.brandBadgeText,
                        color = Color.White,
                        fontFamily = DisplayFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp
                    )
                }

                Spacer(Modifier.width(12.dp))
                Text(
                    text = brandConfig.brandTitle,
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                    fontFamily = DisplayFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1
                )

                if (!isCompactWidth) {
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 14.dp)
                            .width(1.dp)
                            .height(22.dp)
                            .background(KioskCharcoalBorder)
                    )
                    Icon(
                        imageVector = Icons.Filled.LocationOn,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = cinemaLabel,
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.width(8.dp))
                    TextButton(
                        onClick = onChangeLocationClick,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("change_location_button")
                    ) {
                        Text(
                            text = strings.changeLocation,
                            color = CinemaRed,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Right Controls: Language, Accessibility, Cart, Find Booking / Guest Checkout
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box {
                    OutlinedButton(
                        onClick = { langExpanded = true },
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, KioskCharcoalBorder),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = KioskCharcoalElevated,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("language_selector_button")
                    ) {
                        Text(
                            text = language.displayName,
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White
                        )
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Select language", tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(
                        expanded = langExpanded,
                        onDismissRequest = { langExpanded = false }
                    ) {
                        KioskLanguage.entries.forEach { lang ->
                            DropdownMenuItem(
                                text = { Text(lang.displayName, fontWeight = if (lang == language) FontWeight.Bold else FontWeight.Normal) },
                                onClick = {
                                    langExpanded = false
                                    onSelectLanguage(lang)
                                }
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onAccessibilityClick,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .border(1.dp, KioskCharcoalBorder, CircleShape)
                        .testTag("accessibility_header_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.AccessibilityNew,
                        contentDescription = strings.accessibleViewingOptions,
                        tint = Color.White
                    )
                }

                if (!isCompactWidth) {
                    Box(
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .clickable(onClick = onCartClick)
                            .padding(horizontal = 6.dp)
                            .testTag("header_cart_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        BadgedBox(
                            badge = {
                                if (cartCount > 0) {
                                    Badge(containerColor = CinemaRed, contentColor = Color.White) {
                                        Text("$cartCount", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ShoppingCart,
                                contentDescription = "Selected items: $cartCount",
                                tint = Color.White
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = onFindBookingClick,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.5f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("find_booking_header_button")
                    ) {
                        Text(
                            text = if (hasMembership) strings.findMyBooking else strings.guestCheckout,
                            style = MaterialTheme.typography.labelLarge,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Compact location strip for narrow screens
        if (isCompactWidth) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LocationOn, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(cinemaLabel, color = Color.White, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = onChangeLocationClick, contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Text(strings.changeLocation, color = CinemaRed, fontWeight = FontWeight.Bold)
                    }
                }
                TextButton(onClick = onFindBookingClick) {
                    Text(strings.findMyBooking, color = Color.White, style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        HorizontalDivider(color = KioskCharcoalBorder, thickness = 1.dp)

        // Hero & 4-step Progress Strip
        if (isCompactWidth) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(
                    text = strings.heroHeadline,
                    color = Color.White,
                    style = MaterialTheme.typography.headlineSmall,
                    fontFamily = DisplayFontFamily,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = strings.heroSupporting,
                    color = TextOnDarkSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(10.dp))
                ProgressStepperRow(currentStep = currentStep, strings = strings, compact = true, onStepClick = onStepClick)
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.heroHeadline,
                        color = Color.White,
                        style = MaterialTheme.typography.displaySmall,
                        fontFamily = DisplayFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = strings.heroSupporting,
                        color = TextOnDarkSecondary,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.width(16.dp))
                ProgressStepperRow(currentStep = currentStep, strings = strings, compact = false, onStepClick = onStepClick)
            }
        }
    }
}

@Composable
private fun ProgressStepperRow(
    currentStep: CheckoutStep,
    strings: LocalizedStrings,
    compact: Boolean,
    onStepClick: (CheckoutStep) -> Unit
) {
    val steps = listOf(
        CheckoutStep.FILM_AND_TIME to strings.step1FilmTime,
        CheckoutStep.SELECT_SEATS to strings.step2SelectSeats,
        CheckoutStep.EXTRAS to strings.step3Extras,
        CheckoutStep.PAY_AND_COLLECT to strings.step4PayCollect
    )

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(if (compact) 4.dp else 8.dp)
    ) {
        steps.forEachIndexed { idx, (step, label) ->
            val isCompleted = currentStep.stepNumber > step.stepNumber
            val isActive = currentStep == step || (currentStep == CheckoutStep.TICKET_COLLECTION && step == CheckoutStep.PAY_AND_COLLECT)

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(
                        when {
                            isActive -> CinemaRed
                            else -> Color.Transparent
                        }
                    )
                    .clickable(enabled = step.stepNumber <= currentStep.stepNumber && currentStep != CheckoutStep.TICKET_COLLECTION) {
                        onStepClick(step)
                    }
                    .padding(
                        horizontal = if (isActive) (if (compact) 8.dp else 12.dp) else 4.dp,
                        vertical = 6.dp
                    )
                    .testTag("step_indicator_${step.stepNumber}")
            ) {
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isCompleted -> Color.White
                                isActive -> Color.White
                                else -> KioskCharcoalElevated
                            }
                        )
                        .border(
                            1.dp,
                            if (isCompleted || isActive) Color.White else KioskCharcoalBorder,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = "Completed",
                            tint = KioskBlack,
                            modifier = Modifier.size(14.dp)
                        )
                    } else {
                        Text(
                            text = "${step.stepNumber}",
                            color = if (isActive) CinemaRed else TextOnDarkSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
                Spacer(Modifier.width(6.dp))
                Text(
                    text = if (compact) label.split(" ").first() else label,
                    color = if (isActive || isCompleted) Color.White else TextOnDarkSecondary,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                    maxLines = 1
                )
            }

            if (idx < steps.lastIndex) {
                Box(
                    modifier = Modifier
                        .width(if (compact) 8.dp else 18.dp)
                        .height(1.dp)
                        .background(KioskCharcoalBorder)
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun KioskBottomFooter(
    brandConfig: BrandConfig,
    strings: LocalizedStrings,
    sessionTimerSeconds: Int,
    holdTimerSeconds: Int?,
    isCompactWidth: Boolean,
    onAssistanceClick: () -> Unit,
    onAccessibilityClick: () -> Unit,
    onStartOverClick: () -> Unit,
    onSecretStaffTrigger: () -> Unit
) {
    val activeSec = holdTimerSeconds ?: sessionTimerSeconds
    val mm = activeSec / 60
    val ss = activeSec % 60
    val formattedTime = "%02d:%02d".format(mm, ss)

    Surface(
        color = KioskBlack,
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
    ) {
        Column {
            HorizontalDivider(color = KioskCharcoalBorder, thickness = 1.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = if (isCompactWidth) 10.dp else 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(if (isCompactWidth) 6.dp else 14.dp)
                ) {
                    FooterActionButton(
                        icon = Icons.AutoMirrored.Filled.HelpOutline,
                        label = strings.needAssistance,
                        onClick = onAssistanceClick,
                        testTag = "footer_assistance_button"
                    )
                    if (!isCompactWidth) {
                        FooterDivider()
                        FooterActionButton(
                            icon = Icons.Filled.Accessible,
                            label = strings.accessibleViewingOptions,
                            onClick = onAccessibilityClick,
                            testTag = "footer_accessibility_button"
                        )
                    }
                    FooterDivider()
                    FooterActionButton(
                        icon = Icons.Filled.Refresh,
                        label = strings.startOver,
                        onClick = onStartOverClick,
                        testTag = "footer_start_over_button"
                    )
                }

                if (!isCompactWidth) {
                    Text(
                        text = brandConfig.conceptDisclaimer,
                        color = TextOnDarkSecondary.copy(alpha = 0.72f),
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        modifier = Modifier.combinedClickable(
                            onClick = {},
                            onLongClick = onSecretStaffTrigger
                        )
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Filled.Lock, contentDescription = null, tint = TextOnDarkSecondary, modifier = Modifier.size(16.dp))
                    if (!isCompactWidth) {
                        Text(strings.secureCheckout, color = Color.White, style = MaterialTheme.typography.labelMedium)
                        FooterDivider()
                    }
                    Text(
                        text = "Session $formattedTime",
                        color = if (activeSec <= 60) CinemaRed else Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = MonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.testTag("footer_session_timer")
                    )
                }
            }
        }
    }
}

@Composable
private fun FooterDivider() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .height(16.dp)
            .background(KioskCharcoalBorder)
    )
}

@Composable
private fun FooterActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .minimumInteractiveComponentSize()
            .padding(horizontal = 6.dp, vertical = 6.dp)
            .testTag(testTag)
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.White, style = MaterialTheme.typography.labelMedium, maxLines = 1)
    }
}
