package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        CinemaEntity::class,
        AuditoriumEntity::class,
        FilmEntity::class,
        ScreeningEntity::class,
        SeatDefinitionEntity::class,
        SeatLockEntity::class,
        SeatHoldEntity::class,
        ConcessionProductEntity::class,
        PaymentTransactionEntity::class,
        BookingEntity::class,
        TicketEntity::class,
        ConcessionOrderItemEntity::class,
        KioskConfigEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CinemaDatabase : RoomDatabase() {
    abstract fun cinemaDao(): CinemaDao

    companion object {
        @Volatile
        private var INSTANCE: CinemaDatabase? = null

        /**
         * Documented migration template for future schema upgrades without losing booking/audit history.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Example schema evolution placeholder for v2 kiosk telemetry fields
            }
        }

        fun getInstance(context: Context): CinemaDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    CinemaDatabase::class.java,
                    "cinema_terminal.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}

object SeedDataInitializer {
    suspend fun seedIfEmpty(dao: CinemaDao, nowMs: Long) {
        if (dao.getCinemaCount() > 0) return

        val cinemas = listOf(
            CinemaEntity(
                id = "cin_century_city",
                name = "Century City",
                city = "Los Angeles",
                timezoneId = "America/Los_Angeles",
                address = "10250 Santa Monica Blvd, Los Angeles, CA",
                auditoriumCount = 15
            ),
            CinemaEntity(
                id = "cin_lincoln_square",
                name = "Lincoln Square",
                city = "New York",
                timezoneId = "America/New_York",
                address = "1998 Broadway, New York, NY",
                auditoriumCount = 13
            ),
            CinemaEntity(
                id = "cin_river_east",
                name = "River East",
                city = "Chicago",
                timezoneId = "America/Chicago",
                address = "322 E Illinois St, Chicago, IL",
                auditoriumCount = 18
            )
        )
        dao.insertCinemas(cinemas)

        val rows = "A,B,C,D,E,F,G,H,J"
        val auditoriums = listOf(
            AuditoriumEntity("aud_cc_6", "cin_century_city", "Auditorium 6", rows, 10, 5, true, true, true),
            AuditoriumEntity("aud_cc_3", "cin_century_city", "Auditorium 3 • IMAX", rows, 10, 5, true, true, true),
            AuditoriumEntity("aud_cc_2", "cin_century_city", "Auditorium 2 • Dolby", rows, 10, 5, true, true, false),
            AuditoriumEntity("aud_ls_4", "cin_lincoln_square", "Auditorium 4", rows, 10, 5, true, true, true),
            AuditoriumEntity("aud_re_8", "cin_river_east", "Auditorium 8", rows, 10, 5, true, true, true)
        )
        dao.insertAuditoriums(auditoriums)

        // Build seat maps for every auditorium matching the mockup layout:
        // Rows A..J (excluding I), seats 1..5 left | aisle | 6..10 right
        // Row J has wheelchair spaces at J3 & J7, and companion seats at J4 & J8
        val seatDefs = mutableListOf<SeatDefinitionEntity>()
        val rowList = rows.split(",")
        for (aud in auditoriums) {
            for (r in rowList) {
                for (num in 1..10) {
                    val code = "$r$num"
                    val block = if (num <= 5) "LEFT" else "RIGHT"
                    val (seatType, paired) = when {
                        r == "J" && num == 3 -> "ACCESSIBLE_WHEELCHAIR" to "J4"
                        r == "J" && num == 7 -> "ACCESSIBLE_WHEELCHAIR" to "J8"
                        r == "J" && num == 4 -> "COMPANION" to "J3"
                        r == "J" && num == 8 -> "COMPANION" to "J7"
                        else -> "STANDARD" to null
                    }
                    seatDefs.add(
                        SeatDefinitionEntity(
                            id = "${aud.id}_$code",
                            auditoriumId = aud.id,
                            rowLabel = r,
                            seatNumber = num,
                            seatCode = code,
                            blockSide = block,
                            seatType = seatType,
                            isMaintenanceBlocked = false,
                            pairedAccessibleSeatCode = paired
                        )
                    )
                }
            }
        }
        dao.insertSeatDefinitions(seatDefs)

        val films = listOf(
            FilmEntity(
                id = "film_orbital_dawn",
                title = "Orbital Dawn",
                synopsis = "When an orbital relay loses contact above the twilight terminator, flight commander Elena Vance has one orbit to stabilize the station before solar storm arrival.",
                runtimeMinutes = 128,
                classification = "PG-13",
                jurisdiction = "MPAA (US)",
                language = "English",
                subtitleInfo = "Open Captions & Closed Caption Devices",
                posterKey = "orbital_dawn",
                availableFormatsCsv = "Standard,IMAX",
                accessibilityFeaturesCsv = "Wheelchair Access,Companion Seating,Closed Caption,Audio Description",
                admissionPolicy = "Configurable demo policy: Parental guidance suggested for guests under 13.",
                isComingSoon = false,
                releaseLabel = "Now Showing"
            ),
            FilmEntity(
                id = "film_last_avenue",
                title = "The Last Avenue",
                synopsis = "Across one rain-swept autumn night in downtown Manhattan, two musicians cross paths between closing sets and unfinished letters.",
                runtimeMinutes = 112,
                classification = "PG-13",
                jurisdiction = "MPAA (US)",
                language = "English",
                subtitleInfo = "English SDH / Spanish Subtitles (select shows)",
                posterKey = "last_avenue",
                availableFormatsCsv = "Standard,Dolby Cinema",
                accessibilityFeaturesCsv = "Wheelchair Access,Companion Seating,Closed Caption",
                admissionPolicy = "Configurable demo policy: Standard rated admission.",
                isComingSoon = false,
                releaseLabel = "Now Showing"
            ),
            FilmEntity(
                id = "film_wild_summer",
                title = "Wild Summer",
                synopsis = "Three cousins restore a vintage station wagon and follow forgotten canyon highways toward the Pacific before autumn begins.",
                runtimeMinutes = 98,
                classification = "PG",
                jurisdiction = "MPAA (US)",
                language = "English",
                subtitleInfo = "Spanish Subtitles Available",
                posterKey = "wild_summer",
                availableFormatsCsv = "Standard",
                accessibilityFeaturesCsv = "Wheelchair Access,Companion Seating,Closed Caption,Audio Description",
                admissionPolicy = "Configurable demo policy: General family admission.",
                isComingSoon = false,
                releaseLabel = "Now Showing"
            ),
            FilmEntity(
                id = "film_glass_meridian",
                title = "Glass Meridian",
                synopsis = "An oceanographer uncovers an acoustic anomaly beneath an Arctic research shelf. Advance tickets open next Friday.",
                runtimeMinutes = 135,
                classification = "PG-13",
                jurisdiction = "MPAA (US)",
                language = "English",
                subtitleInfo = "Closed Caption",
                posterKey = "glass_meridian",
                availableFormatsCsv = "IMAX,Dolby Cinema",
                accessibilityFeaturesCsv = "Wheelchair Access,Audio Description",
                admissionPolicy = "Advance sales not yet open.",
                isComingSoon = true,
                releaseLabel = "Opens Nov 24"
            ),
            FilmEntity(
                id = "film_cobalt_station",
                title = "Cobalt Station",
                synopsis = "A night-shift rail dispatcher races to divert an automated freight consist through mountain switchbacks.",
                runtimeMinutes = 118,
                classification = "R",
                jurisdiction = "MPAA (US)",
                language = "English",
                subtitleInfo = "Closed Caption",
                posterKey = "cobalt_station",
                availableFormatsCsv = "Standard,Dolby Cinema",
                accessibilityFeaturesCsv = "Wheelchair Access,Closed Caption",
                admissionPolicy = "Configurable demo policy: ID verification required at theater entry (17+).",
                isComingSoon = true,
                releaseLabel = "Opens Dec 4"
            )
        )
        dao.insertFilms(films)

        val salesOpen = nowMs - 86_400_000L
        val salesClose = nowMs + 7 * 86_400_000L
        val futureOpen = nowMs + 5 * 86_400_000L
        val futureClose = nowMs + 20 * 86_400_000L

        val screenings = listOf(
            // Century City - Orbital Dawn (Today)
            ScreeningEntity("scr_od_cc_1630", "film_orbital_dawn", "cin_century_city", "aud_cc_6", "2026-11-16", "Today", "4:30 PM", nowMs + 3_600_000L, salesOpen, salesClose, "Standard", true, "ACTIVE", 1600L, 1100L, 1250L, 1350L, 100L, 875, "USD"),
            ScreeningEntity("scr_od_cc_1915", "film_orbital_dawn", "cin_century_city", "aud_cc_6", "2026-11-16", "Today", "7:15 PM", nowMs + 7_200_000L, salesOpen, salesClose, "Standard", true, "ACTIVE", 1600L, 1100L, 1250L, 1350L, 100L, 875, "USD"),
            ScreeningEntity("scr_od_cc_2145", "film_orbital_dawn", "cin_century_city", "aud_cc_3", "2026-11-16", "Today", "9:45 PM", nowMs + 14_400_000L, salesOpen, salesClose, "IMAX", true, "ACTIVE", 2100L, 1500L, 1650L, 1750L, 150L, 875, "USD"),
            // Century City - Orbital Dawn (Tomorrow)
            ScreeningEntity("scr_od_cc_tmr_1915", "film_orbital_dawn", "cin_century_city", "aud_cc_6", "2026-11-17", "Tomorrow", "7:15 PM", nowMs + 93_600_000L, salesOpen, salesClose, "Standard", true, "ACTIVE", 1600L, 1100L, 1250L, 1350L, 100L, 875, "USD"),

            // Century City - The Last Avenue
            ScreeningEntity("scr_la_cc_1715", "film_last_avenue", "cin_century_city", "aud_cc_2", "2026-11-16", "Today", "5:15 PM", nowMs + 4_500_000L, salesOpen, salesClose, "Dolby Cinema", true, "ACTIVE", 1950L, 1400L, 1550L, 1650L, 125L, 875, "USD"),
            ScreeningEntity("scr_la_cc_2000", "film_last_avenue", "cin_century_city", "aud_cc_6", "2026-11-16", "Today", "8:00 PM", nowMs + 10_800_000L, salesOpen, salesClose, "Standard", true, "ACTIVE", 1600L, 1100L, 1250L, 1350L, 100L, 875, "USD"),
            ScreeningEntity("scr_la_cc_tmr_1830", "film_last_avenue", "cin_century_city", "aud_cc_2", "2026-11-17", "Tomorrow", "6:30 PM", nowMs + 91_000_000L, salesOpen, salesClose, "Standard", true, "ACTIVE", 1600L, 1100L, 1250L, 1350L, 100L, 875, "USD"),

            // Century City - Wild Summer
            ScreeningEntity("scr_ws_cc_1545", "film_wild_summer", "cin_century_city", "aud_cc_6", "2026-11-16", "Today", "3:45 PM", nowMs + 2_400_000L, salesOpen, salesClose, "Standard", true, "ACTIVE", 1450L, 1000L, 1150L, 1250L, 100L, 875, "USD"),
            ScreeningEntity("scr_ws_cc_1830", "film_wild_summer", "cin_century_city", "aud_cc_2", "2026-11-16", "Today", "6:30 PM", nowMs + 6_300_000L, salesOpen, salesClose, "Standard", true, "ACTIVE", 1600L, 1100L, 1250L, 1350L, 100L, 875, "USD"),

            // Coming soon (sales window not yet open)
            ScreeningEntity("scr_gm_cc_soon", "film_glass_meridian", "cin_century_city", "aud_cc_3", "2026-11-24", "Nov 24", "7:00 PM", nowMs + 8 * 86_400_000L, futureOpen, futureClose, "IMAX", true, "ACTIVE", 2100L, 1500L, 1650L, 1750L, 150L, 875, "USD"),

            // Lincoln Square - New York
            ScreeningEntity("scr_od_ls_1915", "film_orbital_dawn", "cin_lincoln_square", "aud_ls_4", "2026-11-16", "Today", "7:15 PM", nowMs + 7_200_000L, salesOpen, salesClose, "Standard", true, "ACTIVE", 1800L, 1250L, 1400L, 1500L, 125L, 888, "USD"),
            ScreeningEntity("scr_la_ls_2030", "film_last_avenue", "cin_lincoln_square", "aud_ls_4", "2026-11-16", "Today", "8:30 PM", nowMs + 11_800_000L, salesOpen, salesClose, "Standard", true, "ACTIVE", 1800L, 1250L, 1400L, 1500L, 125L, 888, "USD"),

            // River East - Chicago
            ScreeningEntity("scr_od_re_1915", "film_orbital_dawn", "cin_river_east", "aud_re_8", "2026-11-16", "Today", "7:15 PM", nowMs + 7_200_000L, salesOpen, salesClose, "Standard", true, "ACTIVE", 1550L, 1050L, 1200L, 1300L, 100L, 1025, "USD"),
            ScreeningEntity("scr_ws_re_1800", "film_wild_summer", "cin_river_east", "aud_re_8", "2026-11-16", "Today", "6:00 PM", nowMs + 5_400_000L, salesOpen, salesClose, "Standard", true, "ACTIVE", 1450L, 1000L, 1150L, 1250L, 100L, 1025, "USD")
        )
        dao.insertScreenings(screenings)

        // Pre-seed sold seats matching the mockup (D5 and D9 unavailable/sold in Orbital Dawn 7:15 PM)
        dao.insertSeatLockOrThrow(
            SeatLockEntity("scr_od_cc_1915", "D5", "SOLD", "seed_prior_customer_1", null, "KIO-SEED-101", "ADULT", nowMs - 600_000L, null)
        )
        dao.insertSeatLockOrThrow(
            SeatLockEntity("scr_od_cc_1915", "D9", "SOLD", "seed_prior_customer_2", null, "KIO-SEED-102", "ADULT", nowMs - 500_000L, null)
        )

        val concessions = listOf(
            ConcessionProductEntity("con_pop_sm", "POPCORN", "Cinema Buttered Popcorn", "Freshly popped golden kernels with layered butter", "Small", 650L, 875, 45, true, "Lobby Express Counter A", null),
            ConcessionProductEntity("con_pop_md", "POPCORN", "Cinema Buttered Popcorn", "Freshly popped golden kernels with layered butter", "Medium", 850L, 875, 40, true, "Lobby Express Counter A", null),
            ConcessionProductEntity("con_pop_lg", "POPCORN", "Cinema Buttered Popcorn", "Shareable tub with complimentary refill", "Large", 1000L, 875, 32, true, "Lobby Express Counter A", null),
            ConcessionProductEntity("con_drk_rg", "DRINK", "Fountain Beverage", "Coca-Cola Freestyle selection", "Regular 22oz", 550L, 875, 60, true, "Lobby Express Counter A", null),
            ConcessionProductEntity("con_drk_lg", "DRINK", "Fountain Beverage", "Coca-Cola Freestyle selection", "Large 32oz", 675L, 875, 55, true, "Lobby Express Counter A", null),
            ConcessionProductEntity("con_snk_cnd", "SNACK", "Theatre Candy Box", "Classic chocolate or sour fruit theater box", "Standard Box", 500L, 875, 38, true, "Auditorium 6 Pickup Shelf", null),
            ConcessionProductEntity("con_snk_prz", "SNACK", "Warm Pretzel Bites", "Salted soft pretzel bites with warm cheddar dip", "Sharing Cup", 750L, 875, 18, true, "Lobby Express Counter B", null),
            ConcessionProductEntity("con_cmb_duo", "COMBO", "Blockbuster Duo Combo", "1 Large Popcorn + 2 Large Fountain Beverages", "Combo Deal", 1950L, 875, 25, true, "Lobby Express Counter A", "Saves $4.00 vs separate items")
        )
        dao.insertConcessions(concessions)

        dao.upsertKioskConfig(
            KioskConfigEntity(
                id = 1,
                inactivityTimeoutSeconds = 300, // 5 minutes
                holdDurationSeconds = 272, // 04:32 matching screenshot!
                maxHoldExtensions = 2,
                printerOnline = true,
                printerStatusMessage = "Thermal Ticket Printer Online (Paper 88%)",
                membershipServiceOnline = true,
                paymentGatewayOnline = true,
                demoModeEnabled = true
            )
        )
    }
}
