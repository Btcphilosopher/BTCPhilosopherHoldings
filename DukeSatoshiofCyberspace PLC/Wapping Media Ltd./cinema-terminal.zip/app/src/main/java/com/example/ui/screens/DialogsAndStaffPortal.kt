package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.domain.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.KioskUiState
import com.example.ui.viewmodel.KioskViewModel

@Composable
fun KioskModalsHost(
    state: KioskUiState,
    viewModel: KioskViewModel
) {
    if (state.showLocationDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowLocationDialog(false) },
            title = { Text("Select Cinema Location", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.cinemas.forEach { cinema ->
                        val active = cinema.id == state.selectedCinema?.id
                        Surface(
                            color = if (active) CinemaRedSoft else SummaryGrey,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (active) CinemaRed else SummaryGreyBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectCinema(cinema.id) }
                                .testTag("cinema_option_${cinema.id}")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("${cinema.name} • ${cinema.city}", fontWeight = FontWeight.Bold, color = TextOnLightPrimary)
                                Text("${cinema.address} (${cinema.timezoneId}) • ${cinema.auditoriumCount} screens", style = MaterialTheme.typography.bodySmall, color = TextOnLightSecondary)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.setShowLocationDialog(false) }) {
                    Text("Close")
                }
            }
        )
    }

    if (state.showAccessibilityDialog) {
        val acc = state.accessibility
        AlertDialog(
            onDismissRequest = { viewModel.setShowAccessibilityDialog(false) },
            title = { Text("Accessibility & Viewing Options", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                    AccessibilitySwitchRow("Large-text mode", acc.largeTextMode) {
                        viewModel.updateAccessibility { it.copy(largeTextMode = !it.largeTextMode) }
                    }
                    AccessibilitySwitchRow("High-contrast mode", acc.highContrastMode) {
                        viewModel.updateAccessibility { it.copy(highContrastMode = !it.highContrastMode) }
                    }
                    AccessibilitySwitchRow("Reduced-motion mode", acc.reducedMotionMode) {
                        viewModel.updateAccessibility { it.copy(reducedMotionMode = !it.reducedMotionMode) }
                    }
                    HorizontalDivider()
                    AccessibilitySwitchRow("Filter: Closed Caption films", acc.filterClosedCaption) {
                        viewModel.updateAccessibility { it.copy(filterClosedCaption = !it.filterClosedCaption) }
                    }
                    AccessibilitySwitchRow("Filter: Audio Description", acc.filterAudioDescription) {
                        viewModel.updateAccessibility { it.copy(filterAudioDescription = !it.filterAudioDescription) }
                    }
                    OutlinedButton(
                        onClick = {
                            viewModel.setShowAccessibilityDialog(false)
                            viewModel.setShowTextSeatSelector(true)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Open Text / Keyboard Seat Selector")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.setShowAccessibilityDialog(false) },
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaRed)
                ) {
                    Text("Done")
                }
            }
        )
    }

    if (state.showTextSeatSelector) {
        Dialog(onDismissRequest = { viewModel.setShowTextSeatSelector(false) }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = WorkspaceWhite,
                modifier = Modifier.fillMaxWidth().heightIn(max = 560.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Text-Based Seat Selection", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        "Accessible alternative for screen readers & keyboard navigation.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextOnLightSecondary
                    )
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(state.seatMap, key = { it.seatCode }) { seat ->
                            val typeLabel = when (seat.seatType) {
                                SeatType.ACCESSIBLE_WHEELCHAIR -> "Wheelchair Space (paired with ${seat.pairedAccessibleSeatCode})"
                                SeatType.COMPANION -> "Companion Seat (next to ${seat.pairedAccessibleSeatCode})"
                                SeatType.STANDARD -> "Standard Seat"
                            }
                            val statusLabel = when (seat.status) {
                                SeatStatus.AVAILABLE -> "Available"
                                SeatStatus.HELD_BY_THIS_SESSION -> "Selected (Held by you)"
                                SeatStatus.HELD_BY_OTHER_SESSION -> "Held by another customer"
                                SeatStatus.SOLD -> "Sold"
                                SeatStatus.UNAVAILABLE -> "Unavailable"
                            }
                            Surface(
                                color = if (seat.status == SeatStatus.HELD_BY_THIS_SESSION) CinemaRedSoft else SummaryGrey,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, if (seat.status == SeatStatus.HELD_BY_THIS_SESSION) CinemaRed else SummaryGreyBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.toggleSeat(seat.seatCode) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Seat ${seat.seatCode} • $typeLabel", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                        Text(statusLabel, style = MaterialTheme.typography.bodySmall, color = TextOnLightSecondary)
                                    }
                                    if (seat.status == SeatStatus.AVAILABLE || seat.status == SeatStatus.HELD_BY_THIS_SESSION) {
                                        Text(
                                            text = if (seat.status == SeatStatus.HELD_BY_THIS_SESSION) "Release" else "Select",
                                            color = CinemaRed,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { viewModel.setShowTextSeatSelector(false) },
                        colors = ButtonDefaults.buttonColors(containerColor = CinemaRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Done")
                    }
                }
            }
        }
    }

    if (state.showMembershipDialog) {
        var memberInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { viewModel.setShowMembershipDialog(false) },
            title = { Text("${state.brandConfig.membershipProgramLabel} Lookup", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Enter a fictional demo membership ID. This replaceable adapter is NOT connected to official AMC Stubs APIs. Failed lookups never block guest checkout.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextOnLightSecondary
                    )
                    OutlinedTextField(
                        value = memberInput,
                        onValueChange = { memberInput = it },
                        label = { Text("Demo Member ID (e.g., CLUB-1001)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("membership_input")
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("CLUB-1001", "CLUB-2002", "ERR-UNAVAIL").forEach { sample ->
                            AssistChip(
                                onClick = { memberInput = sample },
                                label = { Text(sample, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                    if (state.membershipLookupError != null) {
                        Text(state.membershipLookupError, color = StatusError, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.lookupMembership(memberInput) },
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaRed),
                    modifier = Modifier.testTag("membership_lookup_submit")
                ) {
                    Text("Look Up")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setShowMembershipDialog(false) }) {
                    Text("Continue as Guest")
                }
            }
        )
    }

    if (state.showFindBookingDialog) {
        var refInput by remember { mutableStateOf("") }
        var pinInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { viewModel.setShowFindBookingDialog(false) },
            title = { Text("Find My Booking", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Enter both your booking reference and 4-digit verification PIN.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextOnLightSecondary
                    )
                    OutlinedTextField(
                        value = refInput,
                        onValueChange = { refInput = it },
                        label = { Text("Booking Reference (e.g., KIO-1234-ABC)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("find_booking_ref_input")
                    )
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { pinInput = it },
                        label = { Text("4-Digit Verification PIN") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("find_booking_pin_input")
                    )
                    if (state.findBookingError != null) {
                        Text(state.findBookingError, color = StatusError, style = MaterialTheme.typography.bodySmall)
                    }
                    state.foundBooking?.let { bundle ->
                        Surface(color = SummaryGrey, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("${bundle.booking.filmTitle} • ${bundle.booking.status}", fontWeight = FontWeight.Bold)
                                Text(bundle.booking.screeningDateTimeLabel, style = MaterialTheme.typography.bodySmall)
                                Text("Seats: ${bundle.tickets.joinToString(", ") { "${it.seatCode} (${it.admissionStatus})" }}", style = MaterialTheme.typography.bodySmall)
                                OutlinedButton(
                                    onClick = { viewModel.reprintCompletedBooking(bundle.booking.bookingRef) },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Reprint Tickets")
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.lookupBooking(refInput, pinInput) },
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaRed),
                    modifier = Modifier.testTag("find_booking_submit_button")
                ) {
                    Text("Verify & Retrieve")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setShowFindBookingDialog(false) }) {
                    Text("Close")
                }
            }
        )
    }

    if (state.showAssistanceDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowAssistanceDialog(false) },
            title = { Text("Kiosk Assistance & Demo Scenarios", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        "An attendant has been notified at Guest Services Desk A. For accessibility help, open Viewing Options from the header or footer.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    HorizontalDivider()
                    Text("Interactive Failure & Concurrency Demo Tools:", style = MaterialTheme.typography.labelLarge)
                    OutlinedButton(
                        onClick = {
                            viewModel.simulateCompetingSession("F7")
                            viewModel.setShowAssistanceDialog(false)
                        },
                        modifier = Modifier.fillMaxWidth().testTag("demo_compete_f7_button")
                    ) {
                        Text("Simulate Session B Competing for F7")
                    }
                    OutlinedButton(
                        onClick = {
                            viewModel.simulateHoldExpiry()
                            viewModel.setShowAssistanceDialog(false)
                        },
                        modifier = Modifier.fillMaxWidth().testTag("demo_expire_holds_button")
                    ) {
                        Text("Simulate Hold Expiry")
                    }
                    OutlinedButton(
                        onClick = {
                            val currentOnline = state.kioskConfig?.printerOnline ?: true
                            viewModel.toggleSimulatedPrinterFailure(!currentOnline)
                            viewModel.setShowAssistanceDialog(false)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val online = state.kioskConfig?.printerOnline ?: true
                        Text(if (online) "Simulate Printer Offline" else "Restore Printer Online")
                    }
                    OutlinedButton(
                        onClick = {
                            viewModel.setShowAssistanceDialog(false)
                            viewModel.setShowStaffAuthDialog(true)
                        },
                        modifier = Modifier.fillMaxWidth().testTag("open_staff_auth_button")
                    ) {
                        Text("Staff Sign-In (PIN Required)")
                    }
                }
            },
            confirmButton = {
                Button(onClick = { viewModel.setShowAssistanceDialog(false) }, colors = ButtonDefaults.buttonColors(containerColor = CinemaRed)) {
                    Text("Close")
                }
            }
        )
    }

    if (state.showStartOverDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowStartOverDialog(false) },
            title = { Text("Start Over?", fontWeight = FontWeight.Bold) },
            text = {
                Text("This will release your current unconfirmed seat holds and clear membership/session details for the next guest. Any unsettled payments needing reconciliation remain preserved on the server.")
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.resetKioskSession("Kiosk reset for next customer.") },
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaRed),
                    modifier = Modifier.testTag("confirm_start_over_button")
                ) {
                    Text("Yes, Start Over")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setShowStartOverDialog(false) }) {
                    Text("Keep My Selection")
                }
            }
        )
    }

    if (state.showInactivityWarning) {
        AlertDialog(
            onDismissRequest = { viewModel.registerUserInteraction() },
            title = { Text("Are you still there?", fontWeight = FontWeight.Bold) },
            text = {
                Text("For guest privacy, this kiosk will automatically reset in ${state.inactivitySecondsRemaining} seconds.")
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.registerUserInteraction() },
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaRed)
                ) {
                    Text("Continue Session")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.resetKioskSession() }) {
                    Text("Reset Now")
                }
            }
        )
    }

    if (state.showRefundTermsDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowRefundTermsDialog(false) },
            title = { Text("Refund & Cancellation Policy", fontWeight = FontWeight.Bold) },
            text = {
                Text("Demo Terms: Tickets are refundable up to 30 minutes prior to the scheduled screening start time. Booking fees may be non-refundable once tickets are printed. If a screening is cancelled or a printer failure occurs, full assistance and free reprinting are provided at the kiosk or Guest Services.")
            },
            confirmButton = {
                Button(onClick = { viewModel.setShowRefundTermsDialog(false) }, colors = ButtonDefaults.buttonColors(containerColor = CinemaRed)) {
                    Text("Understood")
                }
            }
        )
    }

    if (state.showStaffAuthDialog) {
        var pin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { viewModel.setShowStaffAuthDialog(false) },
            title = { Text("Staff & Administration Sign-In", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Demo PINs: 2410 (Attendant), 3615 (Supervisor), 4820 (Manager)",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextOnLightSecondary
                    )
                    OutlinedTextField(
                        value = pin,
                        onValueChange = { pin = it },
                        label = { Text("Staff PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("staff_pin_input")
                    )
                    if (state.staffActionFeedback != null) {
                        Text(state.staffActionFeedback, color = StatusError, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.loginStaff(pin) },
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaRed),
                    modifier = Modifier.testTag("staff_login_submit")
                ) {
                    Text("Authenticate")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setShowStaffAuthDialog(false) }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (state.showStaffPortal && state.authenticatedStaff != null) {
        StaffAdministrationPortalDialog(state = state, viewModel = viewModel)
    }
}

@Composable
private fun AccessibilitySwitchRow(label: String, checked: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = { onToggle() })
    }
}

@Composable
private fun StaffAdministrationPortalDialog(
    state: KioskUiState,
    viewModel: KioskViewModel
) {
    val staff = state.authenticatedStaff ?: return
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Admission", "Bookings", "Seats & Shows", "Prices & Stock", "Payments & HW", "Audit Log")

    Dialog(
        onDismissRequest = { viewModel.logoutStaff() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = WorkspaceWhite,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxSize(0.94f)
                .padding(8.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Staff & Administration Workspace", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                        Text(
                            "Signed in: ${staff.displayName} • Role: ${staff.role.label}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextOnLightSecondary
                        )
                    }
                    Button(
                        onClick = { viewModel.logoutStaff() },
                        colors = ButtonDefaults.buttonColors(containerColor = KioskBlack)
                    ) {
                        Text("Lock & Return to Guest Mode")
                    }
                }

                if (state.staffActionFeedback != null) {
                    Spacer(Modifier.height(8.dp))
                    Surface(color = SummaryGrey, shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, SummaryGreyBorder), modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = state.staffActionFeedback,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))
                ScrollableTabRow(selectedTabIndex = selectedTab) {
                    tabs.forEachIndexed { idx, label ->
                        Tab(
                            selected = selectedTab == idx,
                            onClick = { selectedTab = idx },
                            text = { Text(label, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))

                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    when (selectedTab) {
                        0 -> {
                            var qrInput by remember { mutableStateOf("") }
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Ticket QR Scanner & Admission", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                OutlinedTextField(
                                    value = qrInput,
                                    onValueChange = { qrInput = it },
                                    label = { Text("Scan or paste QR Token (TKT|...)") },
                                    modifier = Modifier.fillMaxWidth().testTag("staff_qr_input")
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { viewModel.staffAdmitQr(qrInput) },
                                        colors = ButtonDefaults.buttonColors(containerColor = CinemaRed),
                                        modifier = Modifier.testTag("staff_admit_button")
                                    ) {
                                        Text("Validate & Admit")
                                    }
                                    OutlinedButton(
                                        onClick = { viewModel.staffReverseAdmission(qrInput) }
                                    ) {
                                        Text("Reverse Admission (Supervisor+)")
                                    }
                                }
                            }
                        }
                        1 -> {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(state.allBookings, key = { it.bookingRef }) { b ->
                                    Surface(color = SummaryGrey, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text("${b.bookingRef} (PIN ${b.verificationCode}) • ${b.status}", fontWeight = FontWeight.Bold)
                                            Text("${b.filmTitle} • ${b.screeningDateTimeLabel} • Total ${formatMinorUnits(b.totalCents, b.currency)}", style = MaterialTheme.typography.bodySmall)
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                OutlinedButton(onClick = { viewModel.staffReissueBooking(b.bookingRef) }) {
                                                    Text("Reissue QR")
                                                }
                                                OutlinedButton(onClick = { viewModel.staffRefundBooking(b.bookingRef, "Staff-initiated refund") }) {
                                                    Text("Refund (Supervisor+)")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        2 -> {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                item {
                                    Text("Screenings (Manager can Cancel / Restore)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                                items(state.screenings, key = { it.id }) { scr ->
                                    Surface(color = SummaryGrey, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                        Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                            Column {
                                                Text("${scr.dateDisplayLabel} ${scr.localTimeLabel} • ${scr.format} (${scr.status})", fontWeight = FontWeight.Bold)
                                                Text("ID: ${scr.id} • Aud: ${scr.auditoriumId}", style = MaterialTheme.typography.bodySmall)
                                            }
                                            OutlinedButton(onClick = { viewModel.staffToggleScreeningStatus(scr) }) {
                                                Text(if (scr.status == "ACTIVE") "Cancel Show" else "Restore")
                                            }
                                        }
                                    }
                                }
                                item {
                                    Spacer(Modifier.height(8.dp))
                                    Text("Seat Maintenance Overrides (Current Auditorium)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                                items(state.seatMap.take(20), key = { it.seatCode }) { seat ->
                                    val audId = state.selectedAuditorium?.id ?: "aud_cc_6"
                                    val blocked = seat.status == SeatStatus.UNAVAILABLE
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("${seat.seatCode} (${seat.seatType}) — ${seat.status}")
                                        OutlinedButton(onClick = { viewModel.staffToggleSeatMaintenance(audId, seat.seatCode, !blocked) }) {
                                            Text(if (blocked) "Unblock" else "Block Maint.")
                                        }
                                    }
                                }
                            }
                        }
                        3 -> {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                item {
                                    Text("Current Screening Pricing (Manager Only)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    val scr = state.selectedScreening
                                    if (scr != null) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedButton(onClick = {
                                                viewModel.staffUpdatePricing(scr.id, scr.adultPriceCents + 100L, scr.bookingFeePerTicketCents, scr.taxRateBps)
                                            }) {
                                                Text("+$1.00 Adult (${formatMinorUnits(scr.adultPriceCents)})")
                                            }
                                            OutlinedButton(onClick = {
                                                viewModel.staffUpdatePricing(scr.id, 1600L, 100L, 875)
                                            }) {
                                                Text("Reset Demo ($16.00)")
                                            }
                                        }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Text("Concession Stock", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                                items(state.concessions, key = { it.id }) { prod ->
                                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                        Text("${prod.name} (${prod.sizeLabel}) • Stock: ${prod.stockCount}")
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            OutlinedButton(onClick = { viewModel.staffUpdateConcessionStock(prod.id, prod.stockCount + 10) }) { Text("+10") }
                                            OutlinedButton(onClick = { viewModel.staffUpdateConcessionStock(prod.id, 0) }) { Text("Zero") }
                                        }
                                    }
                                }
                            }
                        }
                        4 -> {
                            val config = state.kioskConfig
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                item {
                                    Surface(color = SummaryGrey, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text("Hardware & External Service Adapters", fontWeight = FontWeight.Bold)
                                            Text(config?.printerStatusMessage ?: "Printer status unknown", style = MaterialTheme.typography.bodySmall)
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                OutlinedButton(onClick = { viewModel.toggleSimulatedPrinterFailure(!(config?.printerOnline ?: true)) }) {
                                                    Text(if (config?.printerOnline == true) "Set Printer Offline" else "Restore Printer")
                                                }
                                                OutlinedButton(onClick = { /* Membership service toggle handled in demo */ }) {
                                                    Text("Timeout: ${config?.inactivityTimeoutSeconds ?: 300}s")
                                                }
                                            }
                                        }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Text("Payment Transactions & Exceptions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                                items(state.allPayments, key = { it.transactionId }) { tx ->
                                    Surface(color = SummaryGrey, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text("${tx.transactionId} • ${tx.status} • ${formatMinorUnits(tx.amountCents, tx.currency)}", fontWeight = FontWeight.Bold)
                                            Text(tx.outcomeReason, style = MaterialTheme.typography.bodySmall)
                                            if (tx.needsReconciliation) {
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    Button(onClick = { viewModel.staffReconcilePayment(tx.transactionId, false) }) {
                                                        Text("Capture & Issue")
                                                    }
                                                    OutlinedButton(onClick = { viewModel.staffReconcilePayment(tx.transactionId, true) }) {
                                                        Text("Reverse & Release")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else -> {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(state.auditLogs, key = { it.id }) { log ->
                                    Surface(color = SummaryGrey, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text("${log.actionType} • ${log.targetId}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                            Text("${log.actorStaffId} (${log.actorRole}): ${log.details}", style = MaterialTheme.typography.bodySmall, color = TextOnLightSecondary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
