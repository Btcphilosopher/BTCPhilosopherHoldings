package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.*
import com.example.ui.components.TicketQrMatrix
import com.example.ui.theme.*
import com.example.ui.viewmodel.KioskUiState

@Composable
fun PayAndCollectScreen(
    state: KioskUiState,
    isCompactWidth: Boolean,
    onBackToExtras: () -> Unit,
    onBackToSeats: () -> Unit,
    onSubmitPayment: (PaymentOutcome, String?, String?) -> Unit,
    onRecoverUncertainPayment: (Boolean) -> Unit,
    onRetryIssuance: () -> Unit,
    onOpenRefundTerms: () -> Unit
) {
    var notifyChannel by remember { mutableStateOf("NONE") }
    var notifyTarget by remember { mutableStateOf("") }
    val pricing = state.pricing

    val orderReviewCard: @Composable (Modifier) -> Unit = { mod ->
        Surface(
            color = SummaryGrey,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, SummaryGreyBorder),
            modifier = mod
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Order Review",
                        style = MaterialTheme.typography.headlineSmall,
                        fontFamily = DisplayFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextOnLightPrimary
                    )
                    TextButton(onClick = onBackToExtras) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = CinemaRed)
                        Spacer(Modifier.width(4.dp))
                        Text("Edit extras", color = CinemaRed, fontWeight = FontWeight.Bold)
                    }
                }

                Text(
                    text = "${state.selectedFilm?.title ?: ""} • ${state.selectedScreening?.dateDisplayLabel ?: ""}, ${state.selectedScreening?.localTimeLabel ?: ""}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextOnLightPrimary
                )
                Text(
                    text = "${state.selectedCinema?.name ?: ""} • ${state.selectedAuditorium?.name ?: ""} • ${state.selectedScreening?.format ?: ""}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextOnLightSecondary
                )
                Text(
                    text = "Seats: ${state.heldSeats.joinToString(", ") { "${it.seatCode} (${it.ticketCategory.displayName})" }}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = TextOnLightPrimary
                )

                HorizontalDivider(color = SummaryGreyBorder)

                pricing.ticketLineItems.forEach { item ->
                    SummaryPriceRow(
                        "${item.quantity} × ${item.category.displayName} (${formatMinorUnits(item.unitPriceCents, pricing.currency)})",
                        formatMinorUnits(item.totalCents, pricing.currency)
                    )
                }
                if (pricing.membershipDiscountCents > 0L) {
                    SummaryPriceRow(
                        pricing.membershipDiscountReason ?: "Membership discount",
                        "-${formatMinorUnits(pricing.membershipDiscountCents, pricing.currency)}",
                        amountColor = StatusSuccess
                    )
                }
                SummaryPriceRow("Booking fee", formatMinorUnits(pricing.bookingFeeCents, pricing.currency))
                pricing.concessionLineItems.forEach { item ->
                    SummaryPriceRow(
                        "${item.quantity} × ${item.name} (${item.sizeLabel})",
                        formatMinorUnits(item.totalCents, pricing.currency)
                    )
                }
                SummaryPriceRow("Illustrative tax", formatMinorUnits(pricing.taxCents, pricing.currency))

                HorizontalDivider(color = SummaryGreyBorder)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Due", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextOnLightPrimary)
                    Text(
                        "${formatMinorUnits(pricing.grandTotalCents, pricing.currency)} ${pricing.currency}",
                        style = MaterialTheme.typography.headlineSmall,
                        fontFamily = DisplayFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextOnLightPrimary,
                        modifier = Modifier.testTag("checkout_total_due")
                    )
                }

                Text(
                    text = pricing.refundPolicySummary,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextOnLightSecondary
                )
                TextButton(onClick = onOpenRefundTerms, contentPadding = PaddingValues(0.dp)) {
                    Text("View full refund & cancellation terms", color = CinemaRed, style = MaterialTheme.typography.labelMedium)
                }

                HorizontalDivider(color = SummaryGreyBorder)
                Text(
                    text = "Optional Digital Receipt (Demo Adapter — cleared on reset)",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextOnLightPrimary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("NONE" to "Print only", "EMAIL" to "Email", "SMS" to "SMS").forEach { (key, label) ->
                        FilterChip(
                            selected = notifyChannel == key,
                            onClick = { notifyChannel = key },
                            label = { Text(label) }
                        )
                    }
                }
                if (notifyChannel != "NONE") {
                    OutlinedTextField(
                        value = notifyTarget,
                        onValueChange = { notifyTarget = it },
                        label = { Text(if (notifyChannel == "EMAIL") "Email address" else "Mobile number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Text(
                    text = "Idempotency Key: ${state.activeCheckoutIdempotencyKey.take(12)}…",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextOnLightSecondary
                )
            }
        }
    }

    val paymentTerminalCard: @Composable (Modifier) -> Unit = { mod ->
        Surface(
            color = WorkspaceWhite,
            shape = RoundedCornerShape(16.dp),
            modifier = mod
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    color = Color(0xFFFEF3C7),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFFD97706)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.CreditCardOff, contentDescription = null, tint = Color(0xFF92400E))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "SIMULATED PAYMENT TERMINAL — DO NOT ENTER REAL CARD NUMBERS",
                            color = Color(0xFF92400E),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                Text(
                    text = "Complete payment at terminal",
                    style = MaterialTheme.typography.headlineSmall,
                    fontFamily = DisplayFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextOnLightPrimary
                )
                Text(
                    text = "Amounts are computed server-side (${formatMinorUnits(pricing.grandTotalCents, pricing.currency)} ${pricing.currency}). Seat holds remain protected during terminal authorization.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextOnLightSecondary
                )

                // Recovery banner for Uncertain / Interrupted payment
                if (state.uncertainTransactionId != null) {
                    Surface(
                        color = Color(0xFFFEF3C7),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.5.dp, Color(0xFFD97706)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "Interrupted Transaction (${state.uncertainTransactionId})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF92400E)
                            )
                            Text(
                                text = state.paymentStatusMessage ?: "Payment outcome is uncertain. Seats remain protected pending reconciliation.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF78350F)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { onRecoverUncertainPayment(false) },
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                                    modifier = Modifier.weight(1f).testTag("reconcile_confirm_button")
                                ) {
                                    Text("Reconcile & Issue Tickets", fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { onRecoverUncertainPayment(true) },
                                    modifier = Modifier.weight(1f).testTag("reconcile_reverse_button")
                                ) {
                                    Text("Reverse & Release Seats")
                                }
                            }
                        }
                    }
                }

                // Recovery banner for Payment Captured + Ticket Issuance Failure
                if (state.issuanceRecoveryTransactionId != null) {
                    Surface(
                        color = CinemaRedSoft,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.5.dp, CinemaRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "Issuance Recovery Required (${state.issuanceRecoveryTransactionId})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = CinemaRedDark
                            )
                            Text(
                                text = state.paymentStatusMessage ?: "Payment succeeded, but ticket issuance failed. Retry safely using the same idempotency key.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextOnLightPrimary
                            )
                            Button(
                                onClick = onRetryIssuance,
                                colors = ButtonDefaults.buttonColors(containerColor = CinemaRed),
                                modifier = Modifier.fillMaxWidth().testTag("retry_issuance_button")
                            ) {
                                Text("Retry Ticket Issuance (No Extra Charge)", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                if (state.paymentStatusMessage != null && state.uncertainTransactionId == null && state.issuanceRecoveryTransactionId == null) {
                    Surface(
                        color = CinemaRedSoft,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, CinemaRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = state.paymentStatusMessage,
                            color = CinemaRedDark,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                val ch = if (notifyChannel == "NONE") null else notifyChannel
                val tgt = if (notifyChannel == "NONE") null else notifyTarget

                Button(
                    onClick = { onSubmitPayment(PaymentOutcome.APPROVED, ch, tgt) },
                    enabled = !state.isProcessingPayment && state.uncertainTransactionId == null && state.issuanceRecoveryTransactionId == null,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaRed, contentColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("pay_approve_button")
                ) {
                    Icon(Icons.Filled.Contactless, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = if (state.isProcessingPayment) "Authorizing..." else "Tap / Pay ${formatMinorUnits(pricing.grandTotalCents, pricing.currency)} (Approve)",
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                HorizontalDivider(color = SummaryGreyBorder)
                Text(
                    text = "Simulate Terminal Outcomes & Failure Recovery:",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextOnLightSecondary
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { onSubmitPayment(PaymentOutcome.DECLINED, ch, tgt) },
                        enabled = !state.isProcessingPayment,
                        modifier = Modifier.weight(1f).testTag("pay_decline_button")
                    ) {
                        Text("Simulate Decline")
                    }
                    OutlinedButton(
                        onClick = { onSubmitPayment(PaymentOutcome.CANCELLED, ch, tgt) },
                        enabled = !state.isProcessingPayment,
                        modifier = Modifier.weight(1f).testTag("pay_cancel_button")
                    ) {
                        Text("Cancel at Terminal")
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { onSubmitPayment(PaymentOutcome.UNCERTAIN, ch, tgt) },
                        enabled = !state.isProcessingPayment,
                        modifier = Modifier.weight(1f).testTag("pay_uncertain_button")
                    ) {
                        Text("Interrupted / Uncertain")
                    }
                    OutlinedButton(
                        onClick = { onSubmitPayment(PaymentOutcome.ISSUANCE_FAILED, ch, tgt) },
                        enabled = !state.isProcessingPayment,
                        modifier = Modifier.weight(1f).testTag("pay_issuance_fail_button")
                    ) {
                        Text("Paid + Issuance Fail")
                    }
                }

                TextButton(onClick = onBackToSeats) {
                    Text("Change seats", color = TextOnLightSecondary)
                }
            }
        }
    }

    if (isCompactWidth) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(KioskBlack)
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            orderReviewCard(Modifier.fillMaxWidth())
            paymentTerminalCard(Modifier.fillMaxWidth())
        }
    } else {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(KioskBlack)
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            orderReviewCard(Modifier.weight(0.42f).fillMaxHeight())
            paymentTerminalCard(Modifier.weight(0.58f).fillMaxHeight())
        }
    }
}

@Composable
fun TicketCollectionScreen(
    state: KioskUiState,
    onToggleSimulatedPrinter: (Boolean) -> Unit,
    onReprintTickets: (String) -> Unit,
    onDoneResetKiosk: () -> Unit
) {
    val bundle = state.completedBooking ?: return
    val booking = bundle.booking
    val tickets = bundle.tickets
    val printerOnline = state.kioskConfig?.printerOnline ?: true

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(KioskBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Surface(
            color = WorkspaceWhite,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 920.dp).fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Mandatory Demo Banner
                Surface(
                    color = CinemaRed,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = state.brandConfig.demoTicketBanner,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = DisplayFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Booking Confirmed",
                            style = MaterialTheme.typography.headlineMedium,
                            fontFamily = DisplayFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextOnLightPrimary
                        )
                        Text(
                            text = "Reference: ${booking.bookingRef}   •   Verification PIN: ${booking.verificationCode}",
                            style = MaterialTheme.typography.titleSmall,
                            fontFamily = MonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            color = CinemaRed,
                            modifier = Modifier.testTag("ticket_booking_reference")
                        )
                    }
                    Surface(
                        color = SummaryGrey,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, SummaryGreyBorder)
                    ) {
                        Text(
                            text = "Print: ${booking.printStatus} (${booking.printAttempts}x)",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextOnLightPrimary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                if (state.printerWarning != null || booking.printStatus == PrintStatus.PRINT_FAILED.name) {
                    Surface(
                        color = Color(0xFFFEF3C7),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.5.dp, Color(0xFFD97706)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "Printer Failure — Tickets Safely Created",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF92400E)
                            )
                            Text(
                                text = state.printerWarning ?: "Thermal printer offline. Your booking is saved and paid. Restore printer and reprint without charging again.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF78350F)
                            )
                        }
                    }
                }

                if (state.notificationSummary != null) {
                    Surface(
                        color = Color(0xFFDCFCE7),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = state.notificationSummary,
                            color = Color(0xFF166534),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                // Booking Details + QR Ticket Cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(booking.filmTitle, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextOnLightPrimary)
                        Text(booking.screeningDateTimeLabel, style = MaterialTheme.typography.bodyMedium, color = TextOnLightPrimary)
                        Text("${booking.cinemaName} • ${booking.auditoriumName}", style = MaterialTheme.typography.bodyMedium, color = TextOnLightSecondary)
                        Text(
                            "Seats: ${tickets.joinToString(", ") { "${it.seatCode} (${it.ticketCategory})" }}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = TextOnLightPrimary
                        )
                        Text(
                            "Paid: ${formatMinorUnits(booking.totalCents, booking.currency)} ${booking.currency} (${booking.paymentTransactionId})",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextOnLightSecondary
                        )
                        if (bundle.concessions.isNotEmpty()) {
                            HorizontalDivider(color = SummaryGreyBorder)
                            Text(
                                "Concessions Pickup (${booking.collectionLocation}):",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextOnLightPrimary
                            )
                            bundle.concessions.forEach { c ->
                                Text(
                                    "• ${c.quantity}× ${c.productName} (${c.sizeLabel}) — ${c.fulfillmentStatus}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextOnLightPrimary
                                )
                            }
                        }
                    }

                    // Protected QR Tokens (Zero PII!)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val firstQr = tickets.firstOrNull()?.qrToken ?: "TKT|DEMO"
                        TicketQrMatrix(
                            qrToken = firstQr,
                            modifier = Modifier.size(132.dp)
                        )
                        Text(
                            text = firstQr,
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = MonoFontFamily,
                            color = TextOnLightSecondary
                        )
                        Text(
                            text = "Opaque signed token (no PII)",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextOnLightSecondary
                        )
                    }
                }

                HorizontalDivider(color = SummaryGreyBorder)

                // Printer Failure Simulation + Controlled Reprint Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { onToggleSimulatedPrinter(!printerOnline) },
                        modifier = Modifier.testTag("toggle_printer_failure_button")
                    ) {
                        Icon(
                            if (printerOnline) Icons.Filled.PrintDisabled else Icons.Filled.Print,
                            contentDescription = null
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(if (printerOnline) "Simulate Printer Failure" else "Restore Printer Online")
                    }

                    OutlinedButton(
                        onClick = { onReprintTickets(booking.bookingRef) },
                        modifier = Modifier.testTag("reprint_tickets_button")
                    ) {
                        Icon(Icons.Filled.Print, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Reprint Tickets (No Charge)")
                    }

                    Spacer(Modifier.weight(1f))

                    Button(
                        onClick = onDoneResetKiosk,
                        colors = ButtonDefaults.buttonColors(containerColor = CinemaRed, contentColor = Color.White),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .height(50.dp)
                            .testTag("done_reset_kiosk_button")
                    ) {
                        Text("Done — Reset Kiosk", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
