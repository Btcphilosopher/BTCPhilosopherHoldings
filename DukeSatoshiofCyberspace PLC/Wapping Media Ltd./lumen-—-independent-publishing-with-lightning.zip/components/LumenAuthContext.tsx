'use client';

import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { User } from '@/lib/server/types';

interface AuthorProfileData {
  bio: string;
  publication_name: string;
  lightning_destination: string | null;
  destination_verified: number;
}

interface DemoAccountOption {
  email: string;
  display_name: string;
  role: string;
}

interface AuthContextValue {
  user: User | null;
  profile: AuthorProfileData | null;
  providerMode: 'simulator' | 'live';
  adminConfigured: boolean;
  demoAccounts: DemoAccountOption[];
  loading: boolean;
  refreshAuth: () => Promise<void>;
  switchDemoAccount: (email: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function LumenAuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<AuthorProfileData | null>(null);
  const [providerMode, setProviderMode] = useState<'simulator' | 'live'>('simulator');
  const [adminConfigured, setAdminConfigured] = useState(false);
  const [demoAccounts, setDemoAccounts] = useState<DemoAccountOption[]>([]);
  const [loading, setLoading] = useState(true);

  const refreshAuth = useCallback(async () => {
    try {
      const res = await fetch('/api/v1/auth', { cache: 'no-store' });
      if (!res.ok) return;
      const data = (await res.json()) as {
        user: User | null;
        profile: AuthorProfileData | null;
        provider_mode: 'simulator' | 'live';
        admin_configured: boolean;
        demo_accounts: DemoAccountOption[];
      };
      setUser(data.user);
      setProfile(data.profile);
      setProviderMode(data.provider_mode);
      setAdminConfigured(data.admin_configured);
      setDemoAccounts(data.demo_accounts || []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshAuth();
  }, [refreshAuth]);

  const switchDemoAccount = useCallback(
    async (email: string) => {
      const res = await fetch('/api/v1/auth', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'lumen-ui',
        },
        body: JSON.stringify({ action: 'demo_switch', email }),
      });
      if (res.ok) {
        await refreshAuth();
      }
    },
    [refreshAuth]
  );

  const logout = useCallback(async () => {
    await fetch('/api/v1/auth', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'lumen-ui',
      },
      body: JSON.stringify({ action: 'logout' }),
    });
    setUser(null);
    setProfile(null);
    await refreshAuth();
  }, [refreshAuth]);

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        providerMode,
        adminConfigured,
        demoAccounts,
        loading,
        refreshAuth,
        switchDemoAccount,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useLumenAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useLumenAuth must be used inside LumenAuthProvider');
  }
  return ctx;
}
