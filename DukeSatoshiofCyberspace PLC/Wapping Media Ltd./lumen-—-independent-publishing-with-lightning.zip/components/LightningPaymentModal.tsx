'use client';

import React, { useCallback, useEffect, useState } from 'react';
import QRCode from 'qrcode';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Copy,
  ExternalLink,
  RefreshCw,
  ShieldCheck,
  Wallet,
  X,
  Zap,
} from 'lucide-react';
import { useLumenAuth } from './LumenAuthContext';
import { PaymentIntentRecord } from '@/lib/server/types';

export interface PaymentModalRequest {
  kind: 'article_purchase' | 'author_tip';
  articleId?: string;
  articleTitle?: string;
  recipientUserId: string;
  recipientName: string;
  priceSats?: number;
  customerFeeSats?: number;
  includesFutureRevisions?: boolean;
  refundTerms?: string;
  initialTipSats?: number;
}

export function LightningPaymentModal({
  request,
  onClose,
  onSettled,
}: {
  request: PaymentModalRequest | null;
  onClose: () => void;
  onSettled?: (intent: PaymentIntentRecord) => void;
}) {
  if (!request) return null;
  const key = `${request.kind}:${request.articleId || ''}:${request.recipientUserId}:${request.initialTipSats || ''}`;
  return (
    <LightningPaymentModalInner
      key={key}
      request={request}
      onClose={onClose}
      onSettled={onSettled}
    />
  );
}

function LightningPaymentModalInner({
  request,
  onClose,
  onSettled,
}: {
  request: PaymentModalRequest;
  onClose: () => void;
  onSettled?: (intent: PaymentIntentRecord) => void;
}) {
  const { user, demoAccounts, switchDemoAccount, refreshAuth, providerMode } = useLumenAuth();
  const [tipAmount, setTipAmount] = useState<number>(request.initialTipSats || 100);
  const [customTipText, setCustomTipText] = useState<string>('');
  const [tipNote, setTipNote] = useState<string>('');
  const [shortExpiryDemo, setShortExpiryDemo] = useState(false);
  const [simulateFailureDemo, setSimulateFailureDemo] = useState(false);

  const [intent, setIntent] = useState<PaymentIntentRecord | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [lastEventId, setLastEventId] = useState<string | null>(null);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(0);

  // Generate real QR code whenever invoice changes
  useEffect(() => {
    const bolt11 = intent?.invoice?.bolt11;
    if (!bolt11) return;
    let active = true;
    QRCode.toDataURL(bolt11.toUpperCase(), {
      width: 220,
      margin: 1,
      color: { dark: '#0D2636', light: '#FAF7EF' },
    })
      .then((url) => {
        if (active) setQrDataUrl(url);
      })
      .catch(() => {
        if (active) setQrDataUrl('');
      });
    return () => {
      active = false;
    };
  }, [intent?.invoice?.bolt11]);

  // Live countdown timer + server expiry sync
  useEffect(() => {
    if (!intent || intent.status !== 'awaiting_payment') {
      return;
    }
    const tick = () => {
      const diff = Math.max(
        0,
        Math.floor((new Date(intent.expires_at).getTime() - Date.now()) / 1000)
      );
      setSecondsRemaining(diff);
      if (diff === 0) {
        fetch(`/api/v1/payment-intents/${intent.id}`, { cache: 'no-store' })
          .then((r) => r.json())
          .then((d: { payment_intent?: PaymentIntentRecord }) => {
            if (d.payment_intent) setIntent(d.payment_intent);
          })
          .catch(() => {});
      }
    };
    const raf = requestAnimationFrame(tick);
    const timer = setInterval(tick, 1000);
    return () => {
      cancelAnimationFrame(raf);
      clearInterval(timer);
    };
  }, [intent]);

  const handleCreateInvoice = useCallback(async () => {
    if (!request) return;
    setBusy(true);
    setError(null);
    setStatusMessage('');
    try {
      const expirySeconds = shortExpiryDemo ? 6 : 900;
      const endpoint =
        request.kind === 'article_purchase' ? '/api/v1/purchases' : '/api/v1/tips';
      const payload =
        request.kind === 'article_purchase'
          ? {
              article_id: request.articleId,
              expiry_seconds: expirySeconds,
              simulate_fulfillment_failure: simulateFailureDemo,
            }
          : {
              recipient_user_id: request.recipientUserId,
              article_id: request.articleId || null,
              amount_sats: tipAmount,
              note: tipNote,
              expiry_seconds: expirySeconds,
            };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'lumen-ui',
        },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as {
        payment_intent?: PaymentIntentRecord;
        error?: string;
      };
      if (!res.ok || !data.payment_intent) {
        throw new Error(data.error || 'Could not create Lightning invoice');
      }
      setIntent(data.payment_intent);
      setStatusMessage('Invoice created. Awaiting Lightning payment.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Invoice creation failed');
    } finally {
      setBusy(false);
    }
  }, [request, shortExpiryDemo, simulateFailureDemo, tipAmount, tipNote]);

  const handleSimulateSettlement = async (replayDuplicate = false) => {
    if (!intent) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch('/api/v1/payments/simulator/trigger', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'lumen-ui',
        },
        body: JSON.stringify({
          payment_intent_id: intent.id,
          event_status: 'settled',
          provider_event_id: replayDuplicate && lastEventId ? lastEventId : undefined,
        }),
      });
      const data = (await res.json()) as {
        ok?: boolean;
        duplicate?: boolean;
        outcome?: string;
        provider_event_id?: string;
        payment_intent?: PaymentIntentRecord;
        error?: string;
      };
      if (!res.ok || !data.payment_intent) {
        throw new Error(data.error || 'Settlement simulation failed');
      }
      if (data.provider_event_id && !replayDuplicate) {
        setLastEventId(data.provider_event_id);
      }
      setIntent(data.payment_intent);
      await refreshAuth();

      if (data.duplicate) {
        setStatusMessage(
          'Duplicate webhook event ignored idempotently — no duplicate purchase or author credit was created.'
        );
      } else if (data.outcome === 'settled_fulfillment_pending_retry') {
        setStatusMessage(
          'Payment settled, but entitlement fulfillment simulated a temporary worker failure. Payment is safely retained for recovery in Moderation / Admin.'
        );
      } else if (data.outcome === 'late_settlement_reconciliation_required') {
        setStatusMessage(
          'Settlement arrived after invoice expiry and was recorded as reconciliation-required without losing funds.'
        );
      } else {
        setStatusMessage(
          request?.kind === 'article_purchase'
            ? 'Payment verified and settled. Article access has been unlocked.'
            : 'Tip verified and settled. Thank you for supporting independent writing.'
        );
        onSettled?.(data.payment_intent);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to process event');
    } finally {
      setBusy(false);
    }
  };

  const handleWebLnPay = async () => {
    if (!intent?.invoice?.bolt11) return;
    const w = window as unknown as {
      webln?: { enable: () => Promise<void>; sendPayment: (pr: string) => Promise<unknown> };
    };
    if (!w.webln) {
      setError('No compatible WebLN browser wallet extension detected.');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await w.webln.enable();
      await w.webln.sendPayment(intent.invoice.bolt11);
      // Confirm settlement strictly via server poll, never blindly trusting browser return
      const pollRes = await fetch(`/api/v1/payment-intents/${intent.id}`, {
        cache: 'no-store',
      });
      const data = (await pollRes.json()) as { payment_intent?: PaymentIntentRecord };
      if (data.payment_intent) {
        setIntent(data.payment_intent);
        if (data.payment_intent.status === 'settled') {
          onSettled?.(data.payment_intent);
        } else {
          setStatusMessage('Wallet submitted payment; awaiting server settlement confirmation.');
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Wallet payment cancelled or failed');
    } finally {
      setBusy(false);
    }
  };

  const copyBolt11 = async () => {
    if (!intent?.invoice?.bolt11) return;
    await navigator.clipboard.writeText(intent.invoice.bolt11);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!request) return null;

  const isPurchase = request.kind === 'article_purchase';
  const displayAmount = isPurchase ? request.priceSats || 0 : tipAmount;
  const platformFee = isPurchase ? request.customerFeeSats || 0 : 0;
  const displayTotal = displayAmount + platformFee;
  const mins = Math.floor(secondsRemaining / 60);
  const secs = String(secondsRemaining % 60).padStart(2, '0');

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="lumen-payment-dialog-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#091B27]/75 backdrop-blur-xs overflow-y-auto"
    >
      <div className="w-full max-w-lg bg-[#FAF7EF] dark:bg-[#0D2636] text-[#0D2636] dark:text-[#F4EFE3] border border-[#D6CEBC] dark:border-[#F6F1E4]/25 shadow-2xl overflow-hidden my-auto">
        {/* Top bar */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#0C2332] text-[#F6F1E4] border-b border-[#F6F1E4]/15">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-[#E5A929]" aria-hidden="true" />
            <h2
              id="lumen-payment-dialog-title"
              className="font-[family-name:var(--font-playfair)] text-lg font-medium"
            >
              {isPurchase ? 'Unlock article with Lightning' : 'Tip the author'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close payment window"
            className="p-1.5 rounded hover:bg-[#F6F1E4]/10 text-[#F6F1E4]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-5 max-h-[82vh] overflow-y-auto">
          {/* Require account notice for durable purchases/tips */}
          {!user ? (
            <div className="p-4 border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#F6F1E4] dark:bg-[#091B27] space-y-3">
              <p className="text-sm font-medium">
                Sign in so your {isPurchase ? 'unlocked article remains in your library' : 'tip receipt is recorded'} across sessions.
              </p>
              <div className="flex flex-wrap gap-2">
                {demoAccounts.slice(0, 2).map((acct) => (
                  <button
                    key={acct.email}
                    type="button"
                    onClick={() => switchDemoAccount(acct.email)}
                    className="px-3 py-2 text-xs font-medium bg-[#0D2636] text-[#F6F1E4] hover:bg-[#173D52] transition-colors"
                  >
                    Sign in as {acct.display_name}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <>
              {/* Clear itemized summary */}
              <div className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#F6F1E4] dark:bg-[#091B27] p-4 space-y-2.5 text-sm">
                {request.articleTitle && (
                  <div className="flex justify-between gap-4">
                    <span className="text-[#465B68] dark:text-[#F4EFE3]/70">Article</span>
                    <span className="font-medium text-right">{request.articleTitle}</span>
                  </div>
                )}
                <div className="flex justify-between gap-4">
                  <span className="text-[#465B68] dark:text-[#F4EFE3]/70">Recipient</span>
                  <span className="font-medium">{request.recipientName}</span>
                </div>

                {!isPurchase && !intent && (
                  <div className="pt-2 border-t border-[#D6CEBC] dark:border-[#F6F1E4]/15 space-y-2">
                    <span className="block text-xs text-[#465B68] dark:text-[#F4EFE3]/70">
                      Choose a tip amount (separate from article access):
                    </span>
                    <div className="grid grid-cols-4 gap-2">
                      {[100, 500, 1000].map((amt) => (
                        <button
                          key={amt}
                          type="button"
                          onClick={() => {
                            setTipAmount(amt);
                            setCustomTipText('');
                          }}
                          className={`py-2 text-xs font-[family-name:var(--font-mono-sats)] tabular-sats border transition-colors ${
                            tipAmount === amt && !customTipText
                              ? 'bg-[#E5A929] border-[#E5A929] text-[#0D2636] font-semibold'
                              : 'border-[#D6CEBC] dark:border-[#F6F1E4]/25 hover:border-[#0D2636]'
                          }`}
                        >
                          {amt.toLocaleString()}
                        </button>
                      ))}
                      <input
                        type="number"
                        min={1}
                        step={1}
                        placeholder="Custom"
                        aria-label="Custom tip in sats"
                        value={customTipText}
                        onChange={(e) => {
                          setCustomTipText(e.target.value);
                          const parsed = parseInt(e.target.value, 10);
                          if (Number.isInteger(parsed) && parsed > 0) {
                            setTipAmount(parsed);
                          }
                        }}
                        className="px-2 py-2 text-xs font-[family-name:var(--font-mono-sats)] bg-white dark:bg-[#0D2636] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                      />
                    </div>
                  </div>
                )}

                <div className="pt-2 border-t border-[#D6CEBC] dark:border-[#F6F1E4]/15 space-y-1.5 font-[family-name:var(--font-mono-sats)] text-xs tabular-sats">
                  <div className="flex justify-between">
                    <span>{isPurchase ? 'Article access' : 'Reader tip'}</span>
                    <span>{displayAmount.toLocaleString()} sats</span>
                  </div>
                  <div className="flex justify-between text-[#465B68] dark:text-[#F4EFE3]/70">
                    <span>Additional platform fee</span>
                    <span>{platformFee} sats</span>
                  </div>
                  <div className="flex justify-between font-semibold text-sm pt-1 border-t border-[#D6CEBC]/70 dark:border-[#F6F1E4]/15">
                    <span>Total</span>
                    <span>{displayTotal.toLocaleString()} sats</span>
                  </div>
                  <div className="flex justify-between text-[#465B68] dark:text-[#F4EFE3]/70">
                    <span>Network routing fee</span>
                    <span>Wallet-determined</span>
                  </div>
                </div>

                {isPurchase && (
                  <div className="pt-2 border-t border-[#D6CEBC] dark:border-[#F6F1E4]/15 text-xs text-[#465B68] dark:text-[#F4EFE3]/75 space-y-1">
                    <p>
                      <strong>Revision policy:</strong>{' '}
                      {request.includesFutureRevisions !== false
                        ? 'Includes all future revisions to this edition.'
                        : 'Unlocks the current edition snapshot; later revised editions may be offered separately.'}
                    </p>
                    <p>
                      <strong>Collection &amp; refunds:</strong> Platform-collected by Lumen (10% author commission recorded separately).{' '}
                      {request.refundTerms ||
                        'Lightning payments are final and cannot be reversed via card chargeback; reviewed refunds are issued as separate outgoing payouts.'}
                    </p>
                  </div>
                )}
              </div>

              {/* Pre-invoice simulator options */}
              {!intent && providerMode === 'simulator' && (
                <div className="p-3 border border-[#D6CEBC] dark:border-[#F6F1E4]/20 text-xs space-y-2">
                  <p className="font-medium text-[#465B68] dark:text-[#F4EFE3]/80">
                    Demonstration test options (simulator mode)
                  </p>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={shortExpiryDemo}
                      onChange={(e) => setShortExpiryDemo(e.target.checked)}
                    />
                    <span>Use 6-second expiry to test expired invoice &amp; retry flow</span>
                  </label>
                  {isPurchase && (
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={simulateFailureDemo}
                        onChange={(e) => setSimulateFailureDemo(e.target.checked)}
                      />
                      <span>Simulate temporary entitlement failure after settlement</span>
                    </label>
                  )}
                </div>
              )}

              {/* Create invoice CTA */}
              {!intent && (
                <button
                  type="button"
                  disabled={busy || displayAmount <= 0}
                  onClick={handleCreateInvoice}
                  className="w-full py-3 px-4 bg-[#0D2636] text-[#F6F1E4] hover:bg-[#173D52] disabled:opacity-50 font-medium text-sm flex items-center justify-center gap-2 transition-colors"
                >
                  <Zap className="w-4 h-4 text-[#E5A929]" aria-hidden="true" />
                  {busy
                    ? 'Creating invoice...'
                    : `Create Lightning invoice (${displayTotal.toLocaleString()} sats)`}
                </button>
              )}

              {/* Active Invoice View */}
              {intent && intent.invoice && (
                <div className="space-y-4">
                  <div
                    aria-live="polite"
                    className={`p-3 border text-xs flex items-center justify-between gap-3 ${
                      intent.status === 'settled'
                        ? 'border-emerald-700/40 bg-emerald-50 text-emerald-950 dark:bg-emerald-950/40 dark:text-emerald-100'
                        : intent.status === 'expired' || intent.status === 'reconciliation_required'
                          ? 'border-amber-700/40 bg-amber-50 text-amber-950 dark:bg-amber-950/40 dark:text-amber-100'
                          : 'border-[#D6CEBC] bg-[#F6F1E4] dark:bg-[#091B27]'
                    }`}
                  >
                    <div className="flex items-center gap-2 font-medium">
                      {intent.status === 'settled' ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
                      ) : intent.status === 'expired' ? (
                        <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
                      ) : (
                        <Clock className="w-4 h-4 text-[#CE9118] shrink-0" />
                      )}
                      <span>
                        Status:{' '}
                        {intent.status === 'awaiting_payment'
                          ? 'Awaiting payment'
                          : intent.status === 'reconciliation_required'
                            ? 'Reconciliation required'
                            : intent.status.charAt(0).toUpperCase() + intent.status.slice(1)}
                        {intent.fulfillment_status === 'failed_retryable' &&
                          ' (Entitlement pending recovery)'}
                      </span>
                    </div>
                    {intent.status === 'awaiting_payment' && (
                      <span className="font-[family-name:var(--font-mono-sats)] tabular-sats">
                        Expires in {mins}:{secs}
                      </span>
                    )}
                  </div>

                  {intent.status !== 'settled' && (
                    <div className="flex flex-col sm:flex-row gap-4 items-center border border-[#D6CEBC] dark:border-[#F6F1E4]/20 p-4 bg-[#FAF7EF] dark:bg-[#091B27]">
                      {qrDataUrl && (
                        <img
                          src={qrDataUrl}
                          alt="BOLT11 Lightning invoice QR code"
                          className="w-40 h-40 border border-[#D6CEBC] shrink-0"
                        />
                      )}
                      <div className="flex-1 min-w-0 space-y-2.5 w-full">
                        <p className="text-xs font-medium text-[#465B68] dark:text-[#F4EFE3]/75">
                          BOLT11 Invoice ({intent.provider} mode · demo fixture)
                        </p>
                        <code className="block w-full p-2 text-[11px] font-[family-name:var(--font-mono-sats)] break-all bg-white dark:bg-[#0D2636] border border-[#D6CEBC] dark:border-[#F6F1E4]/20 max-h-20 overflow-y-auto">
                          {intent.invoice.bolt11}
                        </code>
                        <div className="flex flex-wrap gap-2">
                          <button
                            type="button"
                            onClick={copyBolt11}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs border border-[#0D2636] dark:border-[#F6F1E4]/40 hover:bg-[#0D2636]/5"
                          >
                            <Copy className="w-3.5 h-3.5" />
                            {copied ? 'Copied' : 'Copy invoice'}
                          </button>
                          <a
                            href={`lightning:${intent.invoice.bolt11}`}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs border border-[#0D2636] dark:border-[#F6F1E4]/40 hover:bg-[#0D2636]/5"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            Open wallet
                          </a>
                          <button
                            type="button"
                            onClick={handleWebLnPay}
                            disabled={busy || intent.status === 'expired'}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs border border-[#0D2636] dark:border-[#F6F1E4]/40 hover:bg-[#0D2636]/5 disabled:opacity-50"
                          >
                            <Wallet className="w-3.5 h-3.5" />
                            WebLN
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Simulator Settlement & Idempotency Actions */}
                  {providerMode === 'simulator' && (
                    <div className="p-3.5 border border-[#E5A929]/50 bg-[#E5A929]/10 space-y-2.5">
                      <div className="flex items-center gap-2 text-xs font-semibold">
                        <ShieldCheck className="w-4 h-4 text-[#CE9118]" />
                        <span>Simulator Verification Actions (Authenticated Webhook)</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {(intent.status === 'awaiting_payment' || intent.status === 'expired') && (
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => handleSimulateSettlement(false)}
                            className="px-3.5 py-2 text-xs font-semibold bg-[#E5A929] text-[#0D2636] hover:bg-[#CE9118] disabled:opacity-50"
                          >
                            {intent.status === 'expired'
                              ? 'Simulate late settlement (post-expiry)'
                              : 'Simulate verified settlement'}
                          </button>
                        )}
                        {lastEventId && (
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => handleSimulateSettlement(true)}
                            className="px-3 py-2 text-xs border border-[#0D2636] dark:border-[#F6F1E4]/40 hover:bg-[#0D2636]/5"
                          >
                            Replay duplicate settlement event
                          </button>
                        )}
                        {intent.status === 'expired' && (
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => {
                              setIntent(null);
                              setShortExpiryDemo(false);
                              setStatusMessage('');
                            }}
                            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-[#0D2636] text-[#F6F1E4]"
                          >
                            <RefreshCw className="w-3.5 h-3.5" />
                            Retry with new invoice
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {statusMessage && (
                <p className="text-xs text-[#0D2636] dark:text-[#F4EFE3] bg-[#ECE4D0] dark:bg-[#091B27] p-3 border border-[#D6CEBC] dark:border-[#F6F1E4]/20">
                  {statusMessage}
                </p>
              )}

              {error && (
                <p role="alert" className="text-xs text-red-800 dark:text-red-300 bg-red-50 dark:bg-red-950/40 p-3 border border-red-300 dark:border-red-800">
                  {error}
                </p>
              )}

              <p className="text-[11px] text-[#465B68] dark:text-[#F4EFE3]/65">
                Lumen never requests seed phrases or private keys. Access controls cannot prevent a reader from copying content displayed on screen.
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
