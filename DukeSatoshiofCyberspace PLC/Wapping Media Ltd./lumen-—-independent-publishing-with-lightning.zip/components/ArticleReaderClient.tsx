'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  Bookmark,
  Check,
  HeartHandshake,
  Lock,
  Moon,
  Sun,
  UserCheck,
  UserPlus,
  Zap,
} from 'lucide-react';
import { ArticleDetail, ContentBlock } from '@/lib/server/types';
import { SiteHeader } from './SiteHeader';
import { SiteFooter } from './SiteFooter';
import { EditorialBlocks } from './EditorialBlocks';
import { LightningPaymentModal, PaymentModalRequest } from './LightningPaymentModal';
import { useLumenAuth } from './LumenAuthContext';

export function ArticleReaderClient({
  initialArticle,
}: {
  initialArticle: ArticleDetail;
}) {
  const router = useRouter();
  const { user } = useLumenAuth();
  const [article, setArticle] = useState<ArticleDetail>(initialArticle);
  const [textSize, setTextSize] = useState<'sm' | 'md' | 'lg'>('md');
  const [darkTheme, setDarkTheme] = useState(false);
  const [progress, setProgress] = useState(0);
  const [paymentRequest, setPaymentRequest] = useState<PaymentModalRequest | null>(null);
  const [tipSuccess, setTipSuccess] = useState<string | null>(null);

  useEffect(() => {
    const id = requestAnimationFrame(() => {
      setDarkTheme(document.documentElement.classList.contains('dark'));
    });
    return () => cancelAnimationFrame(id);
  }, []);

  useEffect(() => {
    const onScroll = () => {
      const docHeight =
        document.documentElement.scrollHeight - document.documentElement.clientHeight;
      if (docHeight <= 0) {
        setProgress(100);
        return;
      }
      setProgress(Math.min(100, Math.max(0, Math.round((window.scrollY / docHeight) * 100))));
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const toggleTheme = () => {
    const next = !darkTheme;
    setDarkTheme(next);
    document.documentElement.classList.toggle('dark', next);
  };

  const toggleBookmark = async () => {
    if (!user) {
      router.push('/account');
      return;
    }
    const res = await fetch('/api/v1/me/library', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'lumen-ui',
      },
      body: JSON.stringify({ action: 'toggle_bookmark', article_id: article.id }),
    });
    if (res.ok) {
      const data = (await res.json()) as { bookmarked: boolean };
      setArticle((prev) => ({ ...prev, viewer_bookmarked: data.bookmarked }));
    }
  };

  const toggleFollow = async () => {
    if (!user) {
      router.push('/account');
      return;
    }
    const res = await fetch('/api/v1/me/library', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'lumen-ui',
      },
      body: JSON.stringify({
        action: 'toggle_follow',
        author_user_id: article.author.id,
      }),
    });
    if (res.ok) {
      const data = (await res.json()) as { following: boolean };
      setArticle((prev) => ({ ...prev, viewer_following_author: data.following }));
    }
  };

  const unlockFromServer = async () => {
    const res = await fetch(`/api/v1/articles/${article.id}/content`, {
      cache: 'no-store',
    });
    if (res.ok) {
      const data = (await res.json()) as {
        body_blocks: ContentBlock[];
        revision_policy_notice: string;
      };
      setArticle((prev) => ({
        ...prev,
        viewer_has_access: true,
        body_blocks: data.body_blocks,
        revision_policy_notice: data.revision_policy_notice,
      }));
    }
  };

  const proseSizeClass =
    textSize === 'sm'
      ? 'text-base'
      : textSize === 'lg'
        ? 'text-[1.22rem]'
        : 'text-[1.09rem]';

  const openPurchase = () => {
    setPaymentRequest({
      kind: 'article_purchase',
      articleId: article.id,
      articleTitle: article.title,
      recipientUserId: article.author.id,
      recipientName: article.author.display_name,
      priceSats: article.offer.price_sats,
      customerFeeSats: article.offer.customer_fee_sats,
      includesFutureRevisions: article.offer.includes_future_revisions,
      refundTerms: article.offer.refund_terms,
    });
  };

  const openTip = (amount = 100) => {
    setPaymentRequest({
      kind: 'author_tip',
      articleId: article.id,
      articleTitle: article.title,
      recipientUserId: article.author.id,
      recipientName: article.author.display_name,
      initialTipSats: amount,
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F1E4] text-[#0D2636] dark:bg-[#091B27] dark:text-[#F4EFE3]">
      <SiteHeader activeTopic={article.topic} />

      {/* Thin reading progress bar */}
      <div className="sticky top-0 z-30 h-1 w-full bg-[#ECE4D0] dark:bg-[#0D2636]">
        <div
          className="h-full bg-[#E5A929] transition-transform duration-150 origin-left"
          style={{ transform: `scaleX(${progress / 100})` }}
          role="progressbar"
          aria-valuenow={progress}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label="Reading progress"
        />
      </div>

      {/* Reader Utility Ribbon */}
      <div className="border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636]/70">
        <div className="max-w-[1220px] mx-auto px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3 text-[#465B68] dark:text-[#F4EFE3]/75 font-[family-name:var(--font-sans-ui)]">
            <Link href="/" className="hover:underline">
              Discover
            </Link>
            <span aria-hidden="true">/</span>
            <Link href={`/topics/${article.topic}`} className="capitalize hover:underline">
              {article.topic}
            </Link>
            <span aria-hidden="true">·</span>
            <span>Edition v{article.current_revision_number}</span>
          </div>

          <div className="flex items-center gap-3">
            {/* Text size control */}
            <div
              className="inline-flex items-center border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
              role="group"
              aria-label="Reading text size"
            >
              {(['sm', 'md', 'lg'] as const).map((size) => (
                <button
                  key={size}
                  type="button"
                  onClick={() => setTextSize(size)}
                  className={`px-2.5 py-1 uppercase text-[11px] font-[family-name:var(--font-sans-ui)] ${
                    textSize === size
                      ? 'bg-[#0D2636] text-[#F6F1E4] dark:bg-[#E5A929] dark:text-[#0D2636]'
                      : 'hover:bg-[#ECE4D0] dark:hover:bg-[#091B27]'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={toggleTheme}
              aria-label={darkTheme ? 'Switch to light reading theme' : 'Switch to dark reading theme'}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 border border-[#D6CEBC] dark:border-[#F6F1E4]/25 hover:border-[#0D2636] dark:hover:border-[#E5A929]"
            >
              {darkTheme ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
              <span>{darkTheme ? 'Ivory' : 'Ink'}</span>
            </button>

            <button
              type="button"
              onClick={toggleBookmark}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 border border-[#D6CEBC] dark:border-[#F6F1E4]/25 hover:border-[#0D2636]"
            >
              <Bookmark
                className={`w-3.5 h-3.5 ${
                  article.viewer_bookmarked ? 'fill-[#E5A929] text-[#E5A929]' : ''
                }`}
              />
              <span>{article.viewer_bookmarked ? 'Saved' : 'Save'}</span>
            </button>
          </div>
        </div>
      </div>

      <main className="flex-1 max-w-[1220px] w-full mx-auto px-4 sm:px-6 py-10 grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Main Editorial Prose Column */}
        <article className="lg:col-span-8">
          <div className="max-w-[68ch] mx-auto lg:mx-0">
            <div className="flex flex-wrap items-center gap-2 text-xs uppercase tracking-[0.18em] font-[family-name:var(--font-sans-ui)] text-[#CE9118]">
              <span>{article.topic}</span>
              <span aria-hidden="true">·</span>
              <span className="text-[#465B68] dark:text-[#F4EFE3]/70">
                {article.reading_time_minutes} min read
              </span>
              {article.is_author_owner && (
                <>
                  <span aria-hidden="true">·</span>
                  <Link href={`/write/${article.id}`} className="underline">
                    Edit story
                  </Link>
                </>
              )}
            </div>

            <h1
              className="font-[family-name:var(--font-playfair)] text-3xl sm:text-5xl font-medium leading-[1.12] mt-3"
              style={{ textWrap: 'balance' }}
            >
              {article.title}
            </h1>

            <p className="text-lg sm:text-xl text-[#465B68] dark:text-[#F4EFE3]/80 mt-4 leading-relaxed">
              {article.subtitle}
            </p>

            {/* Author Byline + Follow */}
            <div className="mt-6 py-4 border-y border-[#D6CEBC] dark:border-[#F6F1E4]/20 flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="text-sm font-medium">
                  By{' '}
                  <Link
                    href={`/authors/${article.author.handle}`}
                    className="underline decoration-[#E5A929] underline-offset-4"
                  >
                    {article.author.display_name}
                  </Link>
                  <span className="text-[#465B68] dark:text-[#F4EFE3]/70">
                    {' '}
                    · {article.author.publication_name}
                  </span>
                </p>
                {article.published_at && (
                  <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/65 mt-0.5">
                    Published {new Date(article.published_at).toLocaleDateString('en-US', {
                      month: 'long',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </p>
                )}
              </div>

              <button
                type="button"
                onClick={toggleFollow}
                className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium border transition-colors ${
                  article.viewer_following_author
                    ? 'bg-[#0D2636] text-[#F6F1E4] border-[#0D2636] dark:bg-[#E5A929] dark:text-[#0D2636]'
                    : 'border-[#0D2636] dark:border-[#F6F1E4]/35 hover:bg-[#0D2636]/5'
                }`}
              >
                {article.viewer_following_author ? (
                  <>
                    <UserCheck className="w-3.5 h-3.5" />
                    <span>Following</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>Follow author</span>
                  </>
                )}
              </button>
            </div>

            {/* Cover Photography */}
            <figure className="my-8">
              <div className="overflow-hidden border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#0D2636]">
                <img
                  src={article.cover_image_url}
                  alt={article.cover_image_alt}
                  referrerPolicy="no-referrer"
                  className="w-full aspect-[16/10] object-cover"
                />
              </div>
              <figcaption className="text-xs italic text-[#465B68] dark:text-[#F4EFE3]/70 mt-2">
                {article.cover_image_alt}
              </figcaption>
            </figure>

            {/* Body Prose (Full if unlocked/free; Server-enforced Preview if paid & locked) */}
            <div className={proseSizeClass}>
              {article.viewer_has_access && article.body_blocks ? (
                <EditorialBlocks blocks={article.body_blocks} />
              ) : (
                <div className="space-y-6">
                  {article.preview_paragraphs.map((para, idx) => (
                    <p
                      key={idx}
                      className={`leading-[1.78] ${idx === 0 ? 'editorial-drop-cap' : ''}`}
                    >
                      {para}
                    </p>
                  ))}

                  {/* Deliberate Editorial Paywall Curtain */}
                  <div className="mt-8 p-6 sm:p-8 border border-[#0D2636]/30 dark:border-[#F6F1E4]/25 bg-[#FAF7EF] dark:bg-[#0D2636] space-y-4">
                    <div className="flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-[#CE9118] font-[family-name:var(--font-sans-ui)]">
                      <Lock className="w-3.5 h-3.5" />
                      <span>Continue reading this paid edition</span>
                    </div>
                    <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
                      Unlock “{article.title}” for {article.offer.price_sats} sats
                    </h2>
                    <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/80 leading-relaxed">
                      The remainder of this essay is delivered from the server only after a verified Lightning settlement. {article.revision_policy_notice}
                    </p>
                    <div className="flex flex-wrap items-center gap-3 pt-1">
                      <button
                        type="button"
                        onClick={openPurchase}
                        className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#E5A929] hover:bg-[#CE9118] text-[#0D2636] text-xs font-semibold transition-colors"
                      >
                        <Zap className="w-4 h-4" />
                        <span>Buy article access ({article.offer.price_sats} sats)</span>
                      </button>
                      <span className="text-xs text-[#465B68] dark:text-[#F4EFE3]/65 font-[family-name:var(--font-mono-sats)] tabular-sats">
                        Platform fee {article.offer.customer_fee_sats} sats · Total{' '}
                        {article.offer.price_sats + article.offer.customer_fee_sats} sats
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {tipSuccess && (
              <div className="mt-8 p-4 border border-emerald-700/40 bg-emerald-50 dark:bg-emerald-950/40 text-xs">
                {tipSuccess}
              </div>
            )}
          </div>
        </article>

        {/* Payment & Tipping Sidebar (Desktop sticky; Mobile cleanly below preview) */}
        <aside className="lg:col-span-4 space-y-6">
          <div className="lg:sticky lg:top-8 border border-[#D6CEBC] dark:border-[#F6F1E4]/25 bg-[#FAF7EF] dark:bg-[#0D2636] p-6 space-y-5">
            <div className="space-y-1">
              <p className="text-[11px] uppercase tracking-[0.2em] text-[#465B68] dark:text-[#F4EFE3]/70 font-[family-name:var(--font-sans-ui)]">
                Edition Details
              </p>
              <h2 className="font-[family-name:var(--font-playfair)] text-xl font-medium">
                {article.title}
              </h2>
              <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75">
                Author: {article.author.display_name}
              </p>
            </div>

            {/* Article Purchase Breakdown */}
            <div className="pt-4 border-t border-[#D6CEBC] dark:border-[#F6F1E4]/20 space-y-3">
              <p className="text-xs font-semibold uppercase tracking-wider font-[family-name:var(--font-sans-ui)]">
                Article Access
              </p>

              {article.offer.is_paid ? (
                <>
                  <dl className="space-y-1.5 text-xs font-[family-name:var(--font-mono-sats)] tabular-sats">
                    <div className="flex justify-between">
                      <dt className="text-[#465B68] dark:text-[#F4EFE3]/70">Access price</dt>
                      <dd>{article.offer.price_sats} sats</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-[#465B68] dark:text-[#F4EFE3]/70">Platform fee</dt>
                      <dd>{article.offer.customer_fee_sats} sats</dd>
                    </div>
                    <div className="flex justify-between font-semibold pt-1 border-t border-[#D6CEBC]/70 dark:border-[#F6F1E4]/15">
                      <dt>Total</dt>
                      <dd>
                        {article.offer.price_sats + article.offer.customer_fee_sats} sats
                      </dd>
                    </div>
                    <div className="flex justify-between text-[#465B68] dark:text-[#F4EFE3]/70">
                      <dt>Invoice expiry</dt>
                      <dd>15 min</dd>
                    </div>
                    <div className="flex justify-between text-[#465B68] dark:text-[#F4EFE3]/70">
                      <dt>Payment status</dt>
                      <dd>{article.viewer_has_access ? 'Unlocked' : 'Locked'}</dd>
                    </div>
                  </dl>

                  <p className="text-[11px] text-[#465B68] dark:text-[#F4EFE3]/70 leading-relaxed">
                    {article.revision_policy_notice}
                  </p>

                  {article.viewer_has_access ? (
                    <div className="py-2.5 px-3 bg-emerald-800/10 border border-emerald-700/30 text-emerald-900 dark:text-emerald-200 text-xs flex items-center gap-2">
                      <Check className="w-4 h-4 shrink-0" />
                      <span>Full edition unlocked in your library</span>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={openPurchase}
                      className="w-full py-2.5 px-4 bg-[#E5A929] hover:bg-[#CE9118] text-[#0D2636] text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                    >
                      <Zap className="w-4 h-4" />
                      <span>Buy article access</span>
                    </button>
                  )}
                </>
              ) : (
                <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/75">
                  Free edition — open to all readers without an account.
                </p>
              )}
            </div>

            {/* Separate Tip the Author Action */}
            <div className="pt-4 border-t border-[#D6CEBC] dark:border-[#F6F1E4]/20 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold uppercase tracking-wider font-[family-name:var(--font-sans-ui)]">
                  Tip the Author
                </p>
                <span className="text-[11px] text-[#465B68] dark:text-[#F4EFE3]/65">
                  Optional · Separate
                </span>
              </div>
              <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/75">
                Support {article.author.display_name} directly. Tipping does not unlock paid articles.
              </p>
              <div className="grid grid-cols-3 gap-2">
                {[100, 500, 1000].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => openTip(amt)}
                    className="py-2 text-xs font-[family-name:var(--font-mono-sats)] tabular-sats border border-[#0D2636]/30 dark:border-[#F6F1E4]/30 hover:border-[#E5A929] hover:bg-[#E5A929]/15 transition-colors"
                  >
                    {amt.toLocaleString()}
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={() => openTip(100)}
                className="w-full py-2 px-4 border border-[#0D2636] dark:border-[#F6F1E4]/35 hover:bg-[#0D2636]/5 text-xs font-medium flex items-center justify-center gap-2 transition-colors"
              >
                <HeartHandshake className="w-3.5 h-3.5 text-[#CE9118]" />
                <span>Send custom tip</span>
              </button>
            </div>
          </div>
        </aside>
      </main>

      <SiteFooter />

      <LightningPaymentModal
        request={paymentRequest}
        onClose={() => setPaymentRequest(null)}
        onSettled={(settledIntent) => {
          if (settledIntent.kind === 'article_purchase') {
            unlockFromServer();
          } else if (settledIntent.kind === 'author_tip') {
            setTipSuccess(
              `Settled a ${settledIntent.total_sats} sat tip for ${article.author.display_name}.`
            );
          }
        }}
      />
    </div>
  );
}
