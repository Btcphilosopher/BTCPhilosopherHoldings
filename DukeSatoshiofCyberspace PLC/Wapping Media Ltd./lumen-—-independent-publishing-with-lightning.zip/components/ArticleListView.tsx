'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { ArticleSummary } from '@/lib/server/types';
import { SiteHeader } from './SiteHeader';
import { SiteFooter } from './SiteFooter';
import { Search } from 'lucide-react';

export function ArticleListView({
  eyebrow,
  title,
  description,
  activeTopic,
  articles,
  showSearchForm = false,
  initialQuery = '',
  emptyMessage = 'No published essays match this view yet.',
}: {
  eyebrow: string;
  title: string;
  description: string;
  activeTopic?: string;
  articles: ArticleSummary[];
  showSearchForm?: boolean;
  initialQuery?: string;
  emptyMessage?: string;
}) {
  const [query, setQuery] = useState(initialQuery);
  const [results, setResults] = useState<ArticleSummary[]>(articles);
  const [searching, setSearching] = useState(false);

  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSearching(true);
    try {
      const res = await fetch(
        `/api/v1/articles?q=${encodeURIComponent(query.trim())}`,
        { cache: 'no-store' }
      );
      if (res.ok) {
        const data = (await res.json()) as { articles: ArticleSummary[] };
        setResults(data.articles);
      }
    } finally {
      setSearching(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F1E4] text-[#0D2636] dark:bg-[#091B27] dark:text-[#F4EFE3]">
      <SiteHeader activeTopic={activeTopic} />

      <main className="flex-1 max-w-[1220px] w-full mx-auto px-4 sm:px-6 py-10 space-y-8">
        <div className="border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 pb-6 space-y-3">
          <p className="text-[11px] uppercase tracking-[0.22em] text-[#CE9118] font-[family-name:var(--font-sans-ui)]">
            {eyebrow}
          </p>
          <h1 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl font-medium">
            {title}
          </h1>
          <p className="text-sm sm:text-base text-[#465B68] dark:text-[#F4EFE3]/75 max-w-2xl">
            {description}
          </p>

          {showSearchForm && (
            <form onSubmit={handleSearchSubmit} className="pt-3 flex flex-wrap gap-3 max-w-xl">
              <div className="relative flex-1 min-w-[220px]">
                <Search className="w-4 h-4 text-[#465B68] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="search"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search by title, author name, or topic..."
                  className="w-full pl-9 pr-3 py-2 text-sm bg-[#FAF7EF] dark:bg-[#0D2636] border border-[#D6CEBC] dark:border-[#F6F1E4]/25 focus:outline-none focus:border-[#E5A929]"
                />
              </div>
              <button
                type="submit"
                disabled={searching}
                className="px-5 py-2 text-xs font-medium bg-[#0D2636] text-[#F6F1E4] hover:bg-[#173D52] disabled:opacity-50"
              >
                {searching ? 'Searching...' : 'Search'}
              </button>
            </form>
          )}
        </div>

        {results.length === 0 ? (
          <div className="py-12 border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] px-6 text-center space-y-3">
            <p className="font-[family-name:var(--font-playfair)] italic text-xl">
              {emptyMessage}
            </p>
            <Link
              href="/"
              className="inline-block text-xs underline decoration-[#E5A929] underline-offset-4"
            >
              Return to Discovery
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {results.map((art) => (
              <article
                key={art.id}
                className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] flex flex-col justify-between"
              >
                <div>
                  <Link href={`/articles/${art.slug}`} className="block bg-[#0D2636]">
                    <img
                      src={art.cover_image_url}
                      alt={art.cover_image_alt}
                      referrerPolicy="no-referrer"
                      className="w-full aspect-[16/10] object-cover"
                    />
                  </Link>
                  <div className="p-5 space-y-2">
                    <div className="flex items-center gap-2 text-[11px] uppercase tracking-wider text-[#465B68] dark:text-[#F4EFE3]/70 font-[family-name:var(--font-sans-ui)]">
                      <span className="text-[#CE9118] font-semibold">{art.topic}</span>
                      <span aria-hidden="true">·</span>
                      <span>{art.reading_time_minutes} min</span>
                    </div>
                    <h2 className="font-[family-name:var(--font-playfair)] text-xl font-medium leading-snug">
                      <Link
                        href={`/articles/${art.slug}`}
                        className="hover:underline decoration-[#E5A929] underline-offset-4"
                      >
                        {art.title}
                      </Link>
                    </h2>
                    <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/75">
                      By{' '}
                      <Link
                        href={`/authors/${art.author.handle}`}
                        className="hover:underline"
                      >
                        {art.author.display_name}
                      </Link>
                    </p>
                    <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/80 line-clamp-2 pt-1">
                      {art.subtitle}
                    </p>
                  </div>
                </div>

                <div className="px-5 py-3.5 border-t border-[#D6CEBC] dark:border-[#F6F1E4]/15 flex items-center justify-between text-xs">
                  <span className="font-[family-name:var(--font-mono-sats)] tabular-sats font-medium">
                    {art.offer.is_paid
                      ? art.viewer_has_access
                        ? 'Unlocked'
                        : `${art.offer.price_sats} sats`
                      : 'Free'}
                  </span>
                  <Link
                    href={`/articles/${art.slug}`}
                    className="font-medium underline decoration-[#E5A929] underline-offset-4"
                  >
                    {art.offer.is_paid && !art.viewer_has_access ? 'Read preview →' : 'Read →'}
                  </Link>
                </div>
              </article>
            ))}
          </div>
        )}
      </main>

      <SiteFooter />
    </div>
  );
}
