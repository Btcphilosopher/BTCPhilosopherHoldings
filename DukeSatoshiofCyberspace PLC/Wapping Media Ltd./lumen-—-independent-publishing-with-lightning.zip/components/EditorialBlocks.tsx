'use client';

import React from 'react';
import { ContentBlock, TextRun } from '@/lib/server/types';

function RenderRuns({ runs }: { runs?: TextRun[] }) {
  if (!runs || runs.length === 0) return null;
  return (
    <>
      {runs.map((run, idx) => {
        let el: React.ReactNode = run.text;
        if (run.code) {
          el = (
            <code className="font-[family-name:var(--font-mono-sats)] text-[0.9em] px-1 py-0.5 rounded bg-[#ECE4D0] dark:bg-[#0D2636]">
              {el}
            </code>
          );
        }
        if (run.bold) {
          el = <strong className="font-semibold">{el}</strong>;
        }
        if (run.italic) {
          el = <em className="italic">{el}</em>;
        }
        if (run.link) {
          el = (
            <a
              href={run.link}
              target="_blank"
              rel="noopener noreferrer nofollow"
              className="underline decoration-[#E5A929] underline-offset-4 hover:text-[#CE9118]"
            >
              {el}
            </a>
          );
        }
        return <React.Fragment key={idx}>{el}</React.Fragment>;
      })}
    </>
  );
}

export function EditorialBlocks({
  blocks,
  dropCapFirst = true,
}: {
  blocks: ContentBlock[];
  dropCapFirst?: boolean;
}) {
  const firstParagraphIndex = blocks.findIndex((b) => b.type === 'paragraph');

  return (
    <div className="space-y-6">
      {blocks.map((block, idx) => {
        if (block.type === 'heading') {
          if (block.level === 3) {
            return (
              <h3
                key={idx}
                className="font-[family-name:var(--font-playfair)] text-xl font-semibold pt-2 text-[#0D2636] dark:text-[#F4EFE3]"
              >
                <RenderRuns runs={block.runs} />
              </h3>
            );
          }
          return (
            <h2
              key={idx}
              className="font-[family-name:var(--font-playfair)] text-2xl sm:text-3xl font-medium pt-4 text-[#0D2636] dark:text-[#F4EFE3]"
            >
              <RenderRuns runs={block.runs} />
            </h2>
          );
        }

        if (block.type === 'quote') {
          return (
            <blockquote
              key={idx}
              className="my-8 py-5 border-y border-[#D6CEBC] dark:border-[#F6F1E4]/20 text-center px-4"
            >
              <p className="font-[family-name:var(--font-playfair)] italic text-xl sm:text-2xl leading-relaxed text-[#0D2636] dark:text-[#F4EFE3]">
                “<RenderRuns runs={block.runs} />”
              </p>
            </blockquote>
          );
        }

        if (block.type === 'list') {
          const Tag = block.ordered ? 'ol' : 'ul';
          return (
            <Tag
              key={idx}
              className={`space-y-2.5 pl-6 ${
                block.ordered ? 'list-decimal' : 'list-disc'
              } marker:text-[#E5A929]`}
            >
              {(block.items || []).map((item, j) => (
                <li key={j} className="leading-[1.75]">
                  {item}
                </li>
              ))}
            </Tag>
          );
        }

        if (block.type === 'image' && block.url) {
          return (
            <figure key={idx} className="my-8">
              <div className="overflow-hidden border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#0D2636]">
                <img
                  src={block.url}
                  alt={block.alt || 'Editorial figure'}
                  referrerPolicy="no-referrer"
                  className="w-full h-auto max-h-[420px] object-cover"
                />
              </div>
              {block.caption && (
                <figcaption className="text-xs italic text-[#465B68] dark:text-[#F4EFE3]/70 mt-2">
                  {block.caption}
                </figcaption>
              )}
            </figure>
          );
        }

        const useDropCap = dropCapFirst && idx === firstParagraphIndex;

        return (
          <p
            key={idx}
            className={`leading-[1.78] ${useDropCap ? 'editorial-drop-cap' : ''}`}
          >
            {block.runs ? <RenderRuns runs={block.runs} /> : block.text}
          </p>
        );
      })}
    </div>
  );
}
