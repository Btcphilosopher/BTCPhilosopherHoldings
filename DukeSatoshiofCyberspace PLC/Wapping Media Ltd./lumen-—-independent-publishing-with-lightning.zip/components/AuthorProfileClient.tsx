'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { HeartHandshake, UserCheck, UserPlus } from 'lucide-react';
import { ArticleSummary } from '@/lib/server/types';
import { SiteHeader } from './SiteHeader';
import { SiteFooter } from './SiteFooter';
import { LightningPaymentModal, PaymentModalRequest } from './LightningPaymentModal';
import { useLumenAuth } from './LumenAuthContext';

export function AuthorProfileClient({
  author,
  articles,
}: {
  author: {
    id: string;
    handle: string;
    display_name: string;
    bio: string;
    publication_name: string;
    followers_count: number;
    viewer_following: boolean;
  };
  articles: ArticleSummary[];
}) {
  const router = useRouter();
  const { user } = useLumenAuth();
  const [following, setFollowing] = useState(author.viewer_following);
  const [followersCount, setFollowersCount] = useState(author.followers_count);
  const [tipRequest, setTipRequest] = useState<PaymentModalRequest | null>(null);

  const handleToggleFollow = async () => {
    if (!user) {
      router.push('/account');
      return;
    }
    const res = await fetch('/api/v1/me/library', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'lumen-ui',
      },
      body: JSON.stringify({ action: 'toggle_follow', author_user_id: author.id }),
    });
    if (res.ok) {
      const data = (await res.json()) as { following: boolean };
      setFollowing(data.following);
      setFollowersCount((c) => (data.following ? c + 1 : Math.max(0, c - 1)));
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F1E4] text-[#0D2636] dark:bg-[#091B27] dark:text-[#F4EFE3]">
      <SiteHeader />

      <main className="flex-1 max-w-[1220px] w-full mx-auto px-4 sm:px-6 py-10 space-y-10">
        <section className="border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 pb-8 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <p className="text-[11px] uppercase tracking-[0.22em] text-[#CE9118] font-[family-name:var(--font-sans-ui)]">
              {author.publication_name} · @{author.handle}
            </p>
            <h1 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl font-medium">
              {author.display_name}
            </h1>
            <p className="text-base text-[#465B68] dark:text-[#F4EFE3]/80 leading-relaxed">
              {author.bio || 'Independent contributor on Lumen.'}
            </p>
            <p className="text-xs font-[family-name:var(--font-mono-sats)] text-[#465B68] dark:text-[#F4EFE3]/70 tabular-sats">
              {articles.length} published {articles.length === 1 ? 'essay' : 'essays'} ·{' '}
              {followersCount} {followersCount === 1 ? 'follower' : 'followers'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={handleToggleFollow}
              className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-medium border transition-colors ${
                following
                  ? 'bg-[#0D2636] text-[#F6F1E4] border-[#0D2636]'
                  : 'border-[#0D2636] dark:border-[#F6F1E4]/35 hover:bg-[#0D2636]/5'
              }`}
            >
              {following ? <UserCheck className="w-3.5 h-3.5" /> : <UserPlus className="w-3.5 h-3.5" />}
              <span>{following ? 'Following' : 'Follow writer'}</span>
            </button>

            <button
              type="button"
              onClick={() =>
                setTipRequest({
                  kind: 'author_tip',
                  recipientUserId: author.id,
                  recipientName: author.display_name,
                  initialTipSats: 500,
                })
              }
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold bg-[#E5A929] hover:bg-[#CE9118] text-[#0D2636] transition-colors"
            >
              <HeartHandshake className="w-3.5 h-3.5" />
              <span>Tip {author.display_name}</span>
            </button>
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
            Published Essays
          </h2>
          <div className="divide-y divide-[#D6CEBC] dark:divide-[#F6F1E4]/20">
            {articles.map((art) => (
              <article key={art.id} className="py-5 flex flex-col sm:flex-row justify-between gap-4">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 text-xs text-[#465B68] dark:text-[#F4EFE3]/70">
                    <span className="uppercase tracking-wider text-[#CE9118] font-semibold">
                      {art.topic}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{art.reading_time_minutes} min read</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-[family-name:var(--font-mono-sats)] tabular-sats">
                      {art.offer.is_paid ? `${art.offer.price_sats} sats` : 'Free'}
                    </span>
                  </div>
                  <h3 className="font-[family-name:var(--font-playfair)] text-xl font-medium">
                    <Link
                      href={`/articles/${art.slug}`}
                      className="hover:underline decoration-[#E5A929] underline-offset-4"
                    >
                      {art.title}
                    </Link>
                  </h3>
                  <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75">{art.subtitle}</p>
                </div>
                <Link
                  href={`/articles/${art.slug}`}
                  className="self-start px-4 py-2 text-xs font-medium border border-[#0D2636] dark:border-[#F6F1E4]/35 hover:bg-[#0D2636]/5 whitespace-nowrap"
                >
                  {art.offer.is_paid && !art.viewer_has_access ? 'Read preview' : 'Read'}
                </Link>
              </article>
            ))}
          </div>
        </section>
      </main>

      <SiteFooter />

      <LightningPaymentModal
        request={tipRequest}
        onClose={() => setTipRequest(null)}
      />
    </div>
  );
}
