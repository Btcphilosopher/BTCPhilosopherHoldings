'use client';

import React from 'react';
import Link from 'next/link';

export function SiteFooter() {
  return (
    <footer className="bg-[#F6F1E4] dark:bg-[#091B27] text-[#0D2636] dark:text-[#F4EFE3] border-t border-[#D6CEBC] dark:border-[#F6F1E4]/20 mt-12">
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6 py-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <p className="font-[family-name:var(--font-playfair)] italic text-lg">
            lumen · Independent publishing with Lightning
          </p>
          <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/70 mt-1">
            Demonstration edition · Platform-collection accounting · Prices and balances shown are simulated fixtures unless live testnet is enabled.
          </p>
        </div>

        <nav
          aria-label="Footer navigation"
          className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs font-[family-name:var(--font-sans-ui)] text-[#465B68] dark:text-[#F4EFE3]/75"
        >
          <Link href="/" className="hover:text-[#0D2636] dark:hover:text-white whitespace-nowrap">
            Discover
          </Link>
          <Link href="/topics" className="hover:text-[#0D2636] dark:hover:text-white whitespace-nowrap">
            Topics
          </Link>
          <Link href="/earnings" className="hover:text-[#0D2636] dark:hover:text-white whitespace-nowrap">
            Author earnings
          </Link>
          <Link href="/payments" className="hover:text-[#0D2636] dark:hover:text-white whitespace-nowrap">
            Payments &amp; refunds
          </Link>
          <Link href="/admin" className="hover:text-[#0D2636] dark:hover:text-white whitespace-nowrap">
            Moderation
          </Link>
        </nav>
      </div>
    </footer>
  );
}
