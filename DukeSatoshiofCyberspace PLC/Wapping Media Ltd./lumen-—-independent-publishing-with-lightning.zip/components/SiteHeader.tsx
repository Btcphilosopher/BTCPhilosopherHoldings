'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Menu, Search, X, Zap } from 'lucide-react';
import { useLumenAuth } from './LumenAuthContext';

const PRIMARY_NAV = [
  { href: '/', label: 'Discover' },
  { href: '/following', label: 'Following' },
  { href: '/topics', label: 'Topics' },
  { href: '/library', label: 'My library' },
  { href: '/write', label: 'Write a story' },
  { href: '/account', label: 'Account' },
];

export const TOPICS_NAV = [
  { slug: 'for-you', label: 'For you', href: '/' },
  { slug: 'technology', label: 'Technology', href: '/topics/technology' },
  { slug: 'culture', label: 'Culture', href: '/topics/culture' },
  { slug: 'science', label: 'Science', href: '/topics/science' },
  { slug: 'economics', label: 'Economics', href: '/topics/economics' },
  { slug: 'design', label: 'Design', href: '/topics/design' },
];

export function SiteHeader({ activeTopic }: { activeTopic?: string }) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, providerMode } = useLumenAuth();
  const [searchText, setSearchText] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchText.trim();
    if (q) {
      router.push(`/search?q=${encodeURIComponent(q)}`);
    } else {
      router.push('/search');
    }
  };

  return (
    <header className="bg-[#0C2332] text-[#F6F1E4] border-b border-[#F6F1E4]/20">
      {/* Upper archival masthead line matching reference */}
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6 pt-3 pb-2 flex items-center justify-between gap-4 border-b border-[#F6F1E4]/15">
        <span className="hidden md:inline-block text-[11px] tracking-[0.22em] uppercase text-[#F6F1E4]/75 font-[family-name:var(--font-sans-ui)] whitespace-nowrap">
          An Independent Journal
        </span>
        <Link
          href="/"
          className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl font-semibold tracking-tight text-[#F6F1E4] whitespace-nowrap shrink-0 mx-auto md:mx-0"
        >
          lumen
        </Link>
        <span className="hidden md:inline-block text-[11px] tracking-[0.22em] uppercase text-[#F6F1E4]/75 font-[family-name:var(--font-sans-ui)] whitespace-nowrap">
          Letters · Arts · Ideas
        </span>
      </div>

      {/* Primary single-row navigation + explicit balance/payments indicator */}
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-between gap-6 border-b border-[#F6F1E4]/15">
        <nav
          aria-label="Primary navigation"
          className="hidden lg:flex items-center gap-7 text-sm font-[family-name:var(--font-source-serif)]"
        >
          {PRIMARY_NAV.map((item) => {
            const isActive =
              item.href === '/'
                ? pathname === '/'
                : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`py-1 whitespace-nowrap shrink-0 transition-colors border-b-2 ${
                  isActive
                    ? 'border-[#E5A929] text-[#F6F1E4]'
                    : 'border-transparent text-[#F6F1E4]/80 hover:text-[#F6F1E4]'
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="flex lg:hidden items-center gap-3">
          <button
            type="button"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            className="p-2 min-h-[40px] min-w-[40px] flex items-center justify-center rounded border border-[#F6F1E4]/25 text-[#F6F1E4]"
          >
            {mobileOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
          <span className="text-sm text-[#F6F1E4]/80">Menu</span>
        </div>

        {/* Right: Explicit Balance / Payments control */}
        <div className="flex items-center gap-3 shrink-0">
          {user && (
            <Link
              href="/write"
              className="hidden sm:inline-flex items-center px-3 py-1.5 text-xs font-medium border border-[#F6F1E4]/40 rounded hover:bg-[#F6F1E4]/10 transition-colors whitespace-nowrap shrink-0 font-[family-name:var(--font-sans-ui)]"
            >
              Studio
            </Link>
          )}
          <Link
            href="/payments"
            title={
              providerMode === 'simulator'
                ? 'Simulated demonstration balance (invoices do not read external wallet balances)'
                : 'Lightning payments and invoices'
            }
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded border border-[#E5A929]/50 bg-[#091B27] text-[#F6F1E4] hover:border-[#E5A929] transition-colors whitespace-nowrap shrink-0 font-[family-name:var(--font-mono-sats)] tabular-sats"
          >
            <Zap className="w-3.5 h-3.5 text-[#E5A929]" aria-hidden="true" />
            {user && providerMode === 'simulator' ? (
              <span>Demo balance: {user.demo_balance_sats.toLocaleString()} sats</span>
            ) : (
              <span>Payments</span>
            )}
          </Link>
        </div>
      </div>

      {/* Mobile Nav Drawer */}
      {mobileOpen && (
        <nav
          aria-label="Mobile navigation"
          className="lg:hidden px-4 py-3 bg-[#091B27] border-b border-[#F6F1E4]/15 grid grid-cols-2 gap-2 text-sm"
        >
          {PRIMARY_NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className="py-2 px-3 rounded hover:bg-[#F6F1E4]/10 text-[#F6F1E4]"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      )}

      {/* Topic Navigation + Search Strip */}
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6 py-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs">
        <nav
          aria-label="Topic navigation"
          className="flex items-center gap-5 overflow-x-auto py-1 font-[family-name:var(--font-sans-ui)]"
        >
          {TOPICS_NAV.map((t) => {
            const isTopicActive =
              activeTopic === t.slug ||
              (t.slug === 'for-you' && pathname === '/' && !activeTopic);
            return (
              <Link
                key={t.slug}
                href={t.href}
                className={`whitespace-nowrap shrink-0 transition-colors ${
                  isTopicActive
                    ? 'text-[#E5A929] font-semibold'
                    : 'text-[#F6F1E4]/75 hover:text-[#F6F1E4]'
                }`}
              >
                {t.label}
              </Link>
            );
          })}
        </nav>

        <form onSubmit={handleSearch} className="flex items-center gap-2 shrink-0">
          <label htmlFor="header-search" className="sr-only">
            Search articles by title, author, or topic
          </label>
          <div className="relative flex items-center">
            <Search
              className="w-3.5 h-3.5 text-[#F6F1E4]/60 absolute left-2.5 pointer-events-none"
              aria-hidden="true"
            />
            <input
              id="header-search"
              type="search"
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              placeholder="Search title, author, topic..."
              className="w-52 sm:w-60 pl-8 pr-3 py-1 text-xs rounded bg-[#091B27] border border-[#F6F1E4]/20 text-[#F6F1E4] placeholder:text-[#F6F1E4]/45 focus:outline-none focus:border-[#E5A929]"
            />
          </div>
        </form>
      </div>
    </header>
  );
}
