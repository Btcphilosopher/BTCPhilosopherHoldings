'use client';

import React, { useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ArrowRight, Bookmark, Check, HeartHandshake, LockOpen, Zap } from 'lucide-react';
import { ArticleSummary } from '@/lib/server/types';
import { SiteHeader } from './SiteHeader';
import { SiteFooter } from './SiteFooter';
import { LightningPaymentModal, PaymentModalRequest } from './LightningPaymentModal';
import { useLumenAuth } from './LumenAuthContext';

const TOPIC_FILTERS = [
  { slug: 'all', label: 'For you' },
  { slug: 'technology', label: 'Technology' },
  { slug: 'culture', label: 'Culture' },
  { slug: 'science', label: 'Science' },
  { slug: 'economics', label: 'Economics' },
  { slug: 'design', label: 'Design' },
];

export function DiscoveryHomeClient({
  initialArticles,
}: {
  initialArticles: ArticleSummary[];
}) {
  const router = useRouter();
  const { user } = useLumenAuth();
  const [articles, setArticles] = useState<ArticleSummary[]>(initialArticles);
  const [activeTopic, setActiveTopic] = useState<string>('all');
  const [paymentRequest, setPaymentRequest] = useState<PaymentModalRequest | null>(null);

  const featured = useMemo(() => {
    const ranked = articles.filter((a) => a.featured_rank !== null).slice(0, 3);
    return ranked.length > 0 ? ranked : articles.slice(0, 3);
  }, [articles]);

  const defaultSelected = useMemo(() => {
    return (
      featured.find((a) => a.offer.is_paid && !a.viewer_has_access) ||
      featured.find((a) => a.offer.is_paid) ||
      featured[0]
    );
  }, [featured]);

  const [selectedId, setSelectedId] = useState<string | null>(
    defaultSelected?.id || null
  );

  const selectedArticle = useMemo(
    () => articles.find((a) => a.id === selectedId) || defaultSelected || null,
    [articles, selectedId, defaultSelected]
  );

  const filteredFeed = useMemo(() => {
    if (activeTopic === 'all') return articles;
    return articles.filter((a) => a.topic === activeTopic);
  }, [articles, activeTopic]);

  const refreshArticles = async () => {
    const res = await fetch('/api/v1/articles', { cache: 'no-store' });
    if (res.ok) {
      const data = (await res.json()) as { articles: ArticleSummary[] };
      setArticles(data.articles);
    }
  };

  const toggleBookmark = async (articleId: string) => {
    if (!user) {
      router.push('/account');
      return;
    }
    const res = await fetch('/api/v1/me/library', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'lumen-ui',
      },
      body: JSON.stringify({ action: 'toggle_bookmark', article_id: articleId }),
    });
    if (res.ok) {
      const data = (await res.json()) as { bookmarked: boolean };
      setArticles((prev) =>
        prev.map((a) =>
          a.id === articleId ? { ...a, viewer_bookmarked: data.bookmarked } : a
        )
      );
    }
  };

  const openPurchaseFor = (art: ArticleSummary) => {
    setPaymentRequest({
      kind: 'article_purchase',
      articleId: art.id,
      articleTitle: art.title,
      recipientUserId: art.author.id,
      recipientName: art.author.display_name,
      priceSats: art.offer.price_sats,
      customerFeeSats: art.offer.customer_fee_sats,
      includesFutureRevisions: art.offer.includes_future_revisions,
      refundTerms: art.offer.refund_terms,
    });
  };

  const openTipFor = (art: ArticleSummary, amount = 100) => {
    setPaymentRequest({
      kind: 'author_tip',
      articleId: art.id,
      articleTitle: art.title,
      recipientUserId: art.author.id,
      recipientName: art.author.display_name,
      initialTipSats: amount,
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F1E4] text-[#0D2636] dark:bg-[#091B27] dark:text-[#F4EFE3]">
      <SiteHeader />

      {/* HERO + THE CURRENT EDITION (Faithful to reference dark ink-navy upper composition) */}
      <section className="bg-[#0C2332] text-[#F6F1E4]">
        {/* Hero Banner */}
        <div className="relative overflow-hidden border-b border-[#F6F1E4]/15">
          <img
            src="/images/articles/hero-skyline.svg"
            alt="Nocturnal harbor skyline illuminated in warm amber"
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover object-right opacity-85 pointer-events-none"
          />
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-r from-[#0C2332] via-[#0C2332]/90 to-[#0C2332]/25"
          />
          <div className="relative max-w-[1220px] mx-auto px-4 sm:px-6 py-12 sm:py-16 lg:py-20">
            <div className="max-w-xl space-y-5">
              <h1
                className="font-[family-name:var(--font-playfair)] italic font-medium leading-[1.08] tracking-tight text-[#F6F1E4]"
                style={{ fontSize: 'clamp(2.3rem, 4.4vw, 3.6rem)', textWrap: 'balance' }}
              >
                Good writing. Worth a few sats.
              </h1>
              <p className="text-base sm:text-lg text-[#F6F1E4]/85 leading-relaxed max-w-md">
                Read freely. Unlock something remarkable. Support the writers you love.
              </p>
              <div className="pt-2 flex flex-wrap items-center gap-4">
                <a
                  href="#current-edition"
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#F6F1E4] text-[#0D2636] hover:bg-[#EFE8D6] font-medium text-sm transition-colors whitespace-nowrap"
                >
                  <span>Explore the journal</span>
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </a>
                <Link
                  href="/write"
                  className="inline-flex items-center px-4 py-2.5 border border-[#F6F1E4]/35 text-[#F6F1E4] hover:border-[#E5A929] text-sm transition-colors whitespace-nowrap"
                >
                  Publish an essay
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* THE CURRENT EDITION 3-up Showcase */}
        <div id="current-edition" className="max-w-[1220px] mx-auto px-4 sm:px-6 py-8 sm:py-10">
          <div className="flex items-center gap-4 mb-7">
            <div className="flex-1 h-px bg-[#F6F1E4]/25" />
            <div className="flex items-center gap-2.5 text-xs tracking-[0.26em] uppercase font-[family-name:var(--font-sans-ui)] text-[#F6F1E4]/90 whitespace-nowrap">
              <span className="text-[#E5A929]" aria-hidden="true">♦</span>
              <span>The Current Edition</span>
              <span className="text-[#E5A929]" aria-hidden="true">♦</span>
            </div>
            <div className="flex-1 h-px bg-[#F6F1E4]/25" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 md:divide-x md:divide-[#F6F1E4]/20 gap-8 md:gap-0">
            {featured.map((article, idx) => {
              const isSelected = selectedArticle?.id === article.id;
              return (
                <article
                  key={article.id}
                  className={`flex flex-col justify-between ${
                    idx === 0
                      ? 'md:pr-6'
                      : idx === 1
                        ? 'md:px-6'
                        : 'md:pl-6'
                  }`}
                >
                  <div>
                    <Link
                      href={`/articles/${article.slug}`}
                      className="block overflow-hidden border border-[#F6F1E4]/25 bg-[#091B27] mb-3.5 group"
                    >
                      <img
                        src={article.cover_image_url}
                        alt={article.cover_image_alt}
                        referrerPolicy="no-referrer"
                        className="w-full aspect-[16/10] object-cover group-hover:scale-[1.02] transition-transform duration-300"
                      />
                    </Link>

                    <div className="flex items-center gap-2 text-[11px] tracking-[0.18em] uppercase font-[family-name:var(--font-sans-ui)] text-[#E5A929]">
                      <span>{article.topic}</span>
                      <span aria-hidden="true">·</span>
                      <span className="text-[#F6F1E4]/70">{article.reading_time_minutes} min read</span>
                    </div>

                    <h2 className="font-[family-name:var(--font-playfair)] italic text-xl sm:text-2xl font-medium text-[#F6F1E4] mt-1.5 leading-snug">
                      <Link
                        href={`/articles/${article.slug}`}
                        className="hover:underline decoration-[#E5A929] underline-offset-4"
                      >
                        {article.title}
                      </Link>
                    </h2>

                    <p className="text-sm italic text-[#F6F1E4]/80 mt-1">
                      By{' '}
                      <Link
                        href={`/authors/${article.author.handle}`}
                        className="hover:text-[#E5A929] underline-offset-2 hover:underline"
                      >
                        {article.author.display_name}
                      </Link>
                    </p>
                  </div>

                  <div className="mt-4 flex items-center justify-between gap-3">
                    {!article.offer.is_paid ? (
                      <Link
                        href={`/articles/${article.slug}`}
                        className="inline-flex items-center justify-center px-4 py-2 text-xs font-medium bg-[#F6F1E4] text-[#0D2636] hover:bg-[#EFE8D6] transition-colors whitespace-nowrap"
                      >
                        Free to read
                      </Link>
                    ) : article.viewer_has_access ? (
                      <Link
                        href={`/articles/${article.slug}`}
                        className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium bg-[#F6F1E4] text-[#0D2636] hover:bg-[#EFE8D6] transition-colors whitespace-nowrap"
                      >
                        <LockOpen className="w-3.5 h-3.5 text-emerald-700" aria-hidden="true" />
                        <span>Unlocked · Read</span>
                      </Link>
                    ) : (
                      <Link
                        href={`/articles/${article.slug}`}
                        className="inline-flex items-center justify-center px-4 py-2 text-xs font-semibold bg-[#E5A929] text-[#0D2636] hover:bg-[#CE9118] transition-colors whitespace-nowrap font-[family-name:var(--font-mono-sats)] tabular-sats"
                      >
                        Read · {article.offer.price_sats} sats
                      </Link>
                    )}

                    <button
                      type="button"
                      onClick={() => setSelectedId(article.id)}
                      className={`text-xs transition-colors whitespace-nowrap ${
                        isSelected
                          ? 'text-[#E5A929] underline underline-offset-4'
                          : 'text-[#F6F1E4]/65 hover:text-[#F6F1E4]'
                      }`}
                    >
                      {isSelected ? 'Selected' : 'Select'}
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      {/* BOTTOM IVORY PAYMENT CALLOUT BAR (Faithful to reference bottom strip, explicitly identifying selected article & recipient) */}
      {selectedArticle && (
        <section
          aria-label="Selected article payment bar"
          className="bg-[#EFE8D6] dark:bg-[#0D2636] border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20"
        >
          <div className="max-w-[1220px] mx-auto px-4 sm:px-6 py-6 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div>
              <h2 className="font-[family-name:var(--font-playfair)] italic text-2xl sm:text-3xl font-medium text-[#0D2636] dark:text-[#F4EFE3]">
                Keep independent writing alive.
              </h2>
              <p className="text-sm italic text-[#465B68] dark:text-[#F4EFE3]/75 mt-1">
                One story. One reader. A little Lightning.
              </p>
            </div>

            <div className="border border-[#0D2636]/40 dark:border-[#F6F1E4]/30 bg-[#F6F1E4] dark:bg-[#091B27] px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 lg:min-w-[540px]">
              <div className="space-y-0.5 min-w-0">
                <p className="text-sm font-medium truncate">
                  <span className="font-semibold">
                    {selectedArticle.offer.is_paid && !selectedArticle.viewer_has_access
                      ? 'Unlock:'
                      : 'Selected:'}
                  </span>{' '}
                  <span className="italic font-[family-name:var(--font-playfair)]">
                    {selectedArticle.title}
                  </span>
                </p>
                <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/75 font-[family-name:var(--font-mono-sats)] tabular-sats">
                  Recipient: {selectedArticle.author.display_name} ·{' '}
                  {selectedArticle.offer.is_paid ? (
                    <>
                      Article {selectedArticle.offer.price_sats} sats · Platform fee{' '}
                      {selectedArticle.offer.customer_fee_sats} sats · Total{' '}
                      {selectedArticle.offer.price_sats +
                        selectedArticle.offer.customer_fee_sats}{' '}
                      sats
                    </>
                  ) : (
                    'Free edition (0 sats)'
                  )}
                </p>
              </div>

              {selectedArticle.offer.is_paid && !selectedArticle.viewer_has_access ? (
                <button
                  type="button"
                  onClick={() => openPurchaseFor(selectedArticle)}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-[#0D2636] text-[#F6F1E4] hover:bg-[#173D52] text-xs font-medium whitespace-nowrap shrink-0 transition-colors"
                >
                  <span>Pay with Lightning</span>
                  <Zap className="w-3.5 h-3.5 text-[#E5A929]" aria-hidden="true" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => openTipFor(selectedArticle, 100)}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-[#0D2636] text-[#F6F1E4] hover:bg-[#173D52] text-xs font-medium whitespace-nowrap shrink-0 transition-colors"
                >
                  <span>Tip {selectedArticle.author.display_name}</span>
                  <Zap className="w-3.5 h-3.5 text-[#E5A929]" aria-hidden="true" />
                </button>
              )}
            </div>
          </div>
        </section>
      )}

      {/* MAIN EDITORIAL ARCHIVE + STICKY PAYMENT SIDEBAR */}
      <main className="flex-1 max-w-[1220px] w-full mx-auto px-4 sm:px-6 py-10 grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Left: Topic Filters & Editorial Feed */}
        <div className="lg:col-span-8 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 pb-3">
            <div className="flex flex-wrap items-center gap-2" role="tablist" aria-label="Filter stories by topic">
              {TOPIC_FILTERS.map((t) => (
                <button
                  key={t.slug}
                  type="button"
                  role="tab"
                  aria-selected={activeTopic === t.slug}
                  onClick={() => setActiveTopic(t.slug)}
                  className={`px-3 py-1.5 text-xs font-[family-name:var(--font-sans-ui)] transition-colors whitespace-nowrap ${
                    activeTopic === t.slug
                      ? 'bg-[#0D2636] text-[#F6F1E4] dark:bg-[#E5A929] dark:text-[#0D2636] font-medium'
                      : 'text-[#465B68] dark:text-[#F4EFE3]/75 hover:text-[#0D2636] dark:hover:text-white'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
            <Link
              href="/search"
              className="text-xs text-[#465B68] dark:text-[#F4EFE3]/75 hover:underline underline-offset-4"
            >
              Advanced search →
            </Link>
          </div>

          <div className="divide-y divide-[#D6CEBC] dark:divide-[#F6F1E4]/20">
            {filteredFeed.map((article) => {
              const isSelected = selectedArticle?.id === article.id;
              return (
                <article
                  key={article.id}
                  className={`py-6 first:pt-2 grid grid-cols-1 sm:grid-cols-12 gap-5 items-start ${
                    isSelected ? 'bg-[#FAF7EF]/70 dark:bg-[#0D2636]/40 -mx-3 px-3' : ''
                  }`}
                >
                  <div className="sm:col-span-8 space-y-2">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-[#465B68] dark:text-[#F4EFE3]/70 font-[family-name:var(--font-sans-ui)]">
                      <Link
                        href={`/topics/${article.topic}`}
                        className="uppercase tracking-wider font-medium text-[#0D2636] dark:text-[#E5A929]"
                      >
                        {article.topic}
                      </Link>
                      <span aria-hidden="true">·</span>
                      <Link
                        href={`/authors/${article.author.handle}`}
                        className="hover:underline"
                      >
                        {article.author.display_name}
                      </Link>
                      <span aria-hidden="true">·</span>
                      <span>{article.reading_time_minutes} min read</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-[family-name:var(--font-mono-sats)] tabular-sats">
                        {article.offer.is_paid
                          ? article.viewer_has_access
                            ? 'Unlocked'
                            : `${article.offer.price_sats} sats`
                          : 'Free'}
                      </span>
                    </div>

                    <h3 className="font-[family-name:var(--font-playfair)] text-2xl font-medium leading-snug">
                      <Link
                        href={`/articles/${article.slug}`}
                        className="hover:underline decoration-[#E5A929] underline-offset-4"
                      >
                        {article.title}
                      </Link>
                    </h3>

                    <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/80 leading-relaxed">
                      {article.subtitle}
                    </p>

                    <div className="pt-2 flex flex-wrap items-center gap-4 text-xs">
                      <Link
                        href={`/articles/${article.slug}`}
                        className="font-medium underline decoration-[#0D2636]/40 dark:decoration-[#F4EFE3]/40 underline-offset-4 hover:decoration-[#E5A929]"
                      >
                        {article.offer.is_paid && !article.viewer_has_access
                          ? 'Read preview'
                          : 'Read full story'}
                      </Link>
                      <button
                        type="button"
                        onClick={() => setSelectedId(article.id)}
                        className="text-[#465B68] dark:text-[#F4EFE3]/75 hover:text-[#0D2636] dark:hover:text-white"
                      >
                        {isSelected ? 'Selected in sidebar' : 'Select in sidebar'}
                      </button>
                      <button
                        type="button"
                        onClick={() => toggleBookmark(article.id)}
                        className="inline-flex items-center gap-1 text-[#465B68] dark:text-[#F4EFE3]/75 hover:text-[#0D2636] dark:hover:text-white"
                      >
                        <Bookmark
                          className={`w-3.5 h-3.5 ${
                            article.viewer_bookmarked ? 'fill-[#E5A929] text-[#E5A929]' : ''
                          }`}
                          aria-hidden="true"
                        />
                        <span>{article.viewer_bookmarked ? 'Saved' : 'Save'}</span>
                      </button>
                    </div>
                  </div>

                  <Link
                    href={`/articles/${article.slug}`}
                    className="sm:col-span-4 block overflow-hidden border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#0D2636]"
                  >
                    <img
                      src={article.cover_image_url}
                      alt={article.cover_image_alt}
                      referrerPolicy="no-referrer"
                      className="w-full aspect-[4/3] object-cover"
                    />
                  </Link>
                </article>
              );
            })}
          </div>
        </div>

        {/* Right: Payment & Tipping Sidebar */}
        <aside className="lg:col-span-4 space-y-6">
          {selectedArticle && (
            <div className="lg:sticky lg:top-6 border border-[#D6CEBC] dark:border-[#F6F1E4]/25 bg-[#FAF7EF] dark:bg-[#0D2636] p-6 space-y-5">
              <div>
                <p className="text-[11px] uppercase tracking-[0.2em] text-[#465B68] dark:text-[#F4EFE3]/70 font-[family-name:var(--font-sans-ui)]">
                  Selected Edition
                </p>
                <h3 className="font-[family-name:var(--font-playfair)] text-xl font-medium mt-1">
                  {selectedArticle.title}
                </h3>
                <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75 mt-1">
                  Recipient: {selectedArticle.author.display_name} ({selectedArticle.author.publication_name})
                </p>
              </div>

              {/* Separate Article Purchase Block */}
              <div className="pt-4 border-t border-[#D6CEBC] dark:border-[#F6F1E4]/20 space-y-3">
                <p className="text-xs font-semibold uppercase tracking-wider text-[#0D2636] dark:text-[#E5A929] font-[family-name:var(--font-sans-ui)]">
                  Article Access
                </p>
                {selectedArticle.offer.is_paid ? (
                  <>
                    <dl className="space-y-1.5 text-xs font-[family-name:var(--font-mono-sats)] tabular-sats">
                      <div className="flex justify-between">
                        <dt className="text-[#465B68] dark:text-[#F4EFE3]/70">Article access</dt>
                        <dd>{selectedArticle.offer.price_sats} sats</dd>
                      </div>
                      <div className="flex justify-between">
                        <dt className="text-[#465B68] dark:text-[#F4EFE3]/70">Platform fee</dt>
                        <dd>{selectedArticle.offer.customer_fee_sats} sats</dd>
                      </div>
                      <div className="flex justify-between font-semibold pt-1 border-t border-[#D6CEBC]/70 dark:border-[#F6F1E4]/15">
                        <dt>Total</dt>
                        <dd>
                          {selectedArticle.offer.price_sats +
                            selectedArticle.offer.customer_fee_sats}{' '}
                          sats
                        </dd>
                      </div>
                      <div className="flex justify-between text-[#465B68] dark:text-[#F4EFE3]/70">
                        <dt>Routing fee</dt>
                        <dd>Wallet-determined</dd>
                      </div>
                    </dl>

                    <p className="text-[11px] text-[#465B68] dark:text-[#F4EFE3]/70 leading-relaxed">
                      {selectedArticle.offer.includes_future_revisions
                        ? 'Includes future revisions to this edition. '
                        : 'Covers current edition only. '}
                      Platform-collected by Lumen; writer payable is credited separately.
                    </p>

                    {selectedArticle.viewer_has_access ? (
                      <Link
                        href={`/articles/${selectedArticle.slug}`}
                        className="w-full py-2.5 px-4 bg-emerald-800 text-[#F6F1E4] text-xs font-medium flex items-center justify-center gap-2"
                      >
                        <Check className="w-4 h-4" />
                        <span>Access unlocked · Read story</span>
                      </Link>
                    ) : (
                      <button
                        type="button"
                        onClick={() => openPurchaseFor(selectedArticle)}
                        className="w-full py-2.5 px-4 bg-[#E5A929] hover:bg-[#CE9118] text-[#0D2636] text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                      >
                        <Zap className="w-4 h-4" aria-hidden="true" />
                        <span>Buy article access ({selectedArticle.offer.price_sats} sats)</span>
                      </button>
                    )}
                  </>
                ) : (
                  <div className="space-y-3">
                    <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/75">
                      This story is free to read. No payment is required.
                    </p>
                    <Link
                      href={`/articles/${selectedArticle.slug}`}
                      className="w-full py-2.5 px-4 bg-[#0D2636] text-[#F6F1E4] hover:bg-[#173D52] text-xs font-medium flex items-center justify-center"
                    >
                      Open free article
                    </Link>
                  </div>
                )}
              </div>

              {/* Separate Author Tip Block */}
              <div className="pt-4 border-t border-[#D6CEBC] dark:border-[#F6F1E4]/20 space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold uppercase tracking-wider text-[#0D2636] dark:text-[#E5A929] font-[family-name:var(--font-sans-ui)]">
                    Tip the Author
                  </p>
                  <span className="text-[11px] text-[#465B68] dark:text-[#F4EFE3]/65">
                    Separate from access
                  </span>
                </div>
                <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/75">
                  Send a voluntary tip to {selectedArticle.author.display_name}. Tipping does not purchase paid article access.
                </p>
                <div className="grid grid-cols-3 gap-2">
                  {[100, 500, 1000].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => openTipFor(selectedArticle, amt)}
                      className="py-2 text-xs font-[family-name:var(--font-mono-sats)] tabular-sats border border-[#0D2636]/30 dark:border-[#F6F1E4]/30 hover:border-[#E5A929] hover:bg-[#E5A929]/15 transition-colors"
                    >
                      {amt.toLocaleString()}
                    </button>
                  ))}
                </div>
                <button
                  type="button"
                  onClick={() => openTipFor(selectedArticle, 250)}
                  className="w-full py-2 px-4 border border-[#0D2636] dark:border-[#F6F1E4]/40 hover:bg-[#0D2636]/5 text-xs font-medium flex items-center justify-center gap-2 transition-colors"
                >
                  <HeartHandshake className="w-3.5 h-3.5 text-[#CE9118]" aria-hidden="true" />
                  <span>Tip {selectedArticle.author.display_name}</span>
                </button>
              </div>
            </div>
          )}
        </aside>
      </main>

      <SiteFooter />

      <LightningPaymentModal
        request={paymentRequest}
        onClose={() => setPaymentRequest(null)}
        onSettled={() => {
          refreshArticles();
        }}
      />
    </div>
  );
}
