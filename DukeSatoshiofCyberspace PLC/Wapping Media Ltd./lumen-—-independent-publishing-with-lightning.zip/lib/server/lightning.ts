import crypto from 'node:crypto';
import {
  CreateInvoiceInput,
  CreateInvoiceResult,
  DirectToAuthorFutureAdapter,
  PaymentProviderAdapter,
  PayoutExecutionInput,
  PayoutExecutionResult,
  PayoutProviderAdapter,
  ProviderInvoiceStatus,
  VerifiedProviderEvent,
} from './types';

const globalForWebhookSecret = globalThis as unknown as {
  __lumenWebhookSecret?: string;
};

export function getWebhookSecret(): string {
  if (process.env.LIGHTNING_WEBHOOK_SECRET && process.env.LIGHTNING_WEBHOOK_SECRET.length >= 16) {
    return process.env.LIGHTNING_WEBHOOK_SECRET;
  }
  if (!globalForWebhookSecret.__lumenWebhookSecret) {
    globalForWebhookSecret.__lumenWebhookSecret = crypto.randomBytes(32).toString('hex');
  }
  return globalForWebhookSecret.__lumenWebhookSecret;
}

export function signSimulatorEvent(rawBody: string): string {
  return crypto
    .createHmac('sha256', getWebhookSecret())
    .update(rawBody)
    .digest('hex');
}

/**
 * Deterministic Local Lightning Simulator
 * Generates valid-looking BOLT11-format test invoices, enforces integer msat conversion,
 * and signs/verifies authenticated provider webhook events via HMAC-SHA256.
 */
export class DeterministicSimulatorProvider implements PaymentProviderAdapter {
  readonly providerName = 'simulator';
  readonly isLive = false;
  readonly accountId = 'lumen-platform-sim-acct-01';

  async createInvoice(input: CreateInvoiceInput): Promise<CreateInvoiceResult> {
    if (!Number.isInteger(input.amountSats) || input.amountSats <= 0) {
      throw new Error('Invoice amount must be a positive integer in sats');
    }
    const amountMsat = input.amountSats * 1000;
    const seed = `${input.paymentIntentId}:${amountMsat}:${input.memo}`;
    const paymentHash = crypto.createHash('sha256').update(seed).digest('hex');
    const providerInvoiceId = `sim_inv_${paymentHash.slice(0, 20)}`;
    const checksum = crypto
      .createHash('sha256')
      .update(`${paymentHash}:${Date.now()}`)
      .digest('hex')
      .slice(0, 48);
    // Standard BOLT11-shaped test invoice string for QR & wallet inspection
    const bolt11 = `lnsb${input.amountSats}n1p${paymentHash.slice(0, 32)}pp5${checksum}`;
    const expiresAt = new Date(Date.now() + input.expirySeconds * 1000).toISOString();

    return {
      provider: this.providerName,
      providerAccount: this.accountId,
      providerInvoiceId,
      paymentHash,
      bolt11,
      amountSats: input.amountSats,
      amountMsat,
      expiresAt,
    };
  }

  async getInvoiceStatus(_providerInvoiceId: string): Promise<ProviderInvoiceStatus> {
    // In simulator mode, authoritative invoice state is persisted in the DB and transitioned
    // via signed provider events or expiry checks.
    throw new Error('Simulator status lookup must read authoritative ledger/invoice record');
  }

  async verifyProviderEvent(
    rawBody: string,
    signatureHeader: string | null
  ): Promise<VerifiedProviderEvent> {
    if (!signatureHeader) {
      throw new Error('Missing X-Lumen-Signature header');
    }
    const expected = signSimulatorEvent(rawBody);
    const actualBuf = Buffer.from(signatureHeader.trim(), 'utf8');
    const expectedBuf = Buffer.from(expected, 'utf8');
    if (actualBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(actualBuf, expectedBuf)) {
      throw new Error('Invalid provider webhook signature');
    }

    const payload = JSON.parse(rawBody) as {
      provider_event_id?: string;
      provider_invoice_id?: string;
      payment_hash?: string;
      payment_intent_id?: string;
      provider_account?: string;
      amount_sats?: number;
      status?: 'settled' | 'expired' | 'cancelled';
      occurred_at?: string;
    };

    if (
      !payload.provider_event_id ||
      !payload.provider_invoice_id ||
      !payload.payment_hash ||
      !payload.payment_intent_id ||
      !payload.provider_account ||
      !Number.isInteger(payload.amount_sats) ||
      !payload.status
    ) {
      throw new Error('Malformed provider event payload');
    }

    if (payload.provider_account !== this.accountId) {
      throw new Error('Provider account mismatch');
    }

    return {
      provider: this.providerName,
      providerAccount: payload.provider_account,
      providerEventId: payload.provider_event_id,
      providerInvoiceId: payload.provider_invoice_id,
      paymentHash: payload.payment_hash,
      paymentIntentId: payload.payment_intent_id,
      amountSats: payload.amount_sats as number,
      status: payload.status,
      occurredAt: payload.occurred_at || new Date().toISOString(),
    };
  }
}

/**
 * Documented External Lightning Provider Integration (LNbits REST API v1)
 * Kept disabled unless LIGHTNING_LIVE_ENABLED="true" and LNBITS_* env vars are supplied.
 */
export class LnbitsTestnetProvider implements PaymentProviderAdapter {
  readonly providerName = 'lnbits';
  readonly isLive = true;

  private getConfig() {
    const enabled = process.env.LIGHTNING_LIVE_ENABLED === 'true';
    const baseUrl = process.env.LNBITS_BASE_URL;
    const invoiceKey = process.env.LNBITS_INVOICE_KEY;
    if (!enabled || !baseUrl || !invoiceKey) {
      throw new Error('LNbits testnet provider is disabled. Configure LIGHTNING_LIVE_ENABLED=true, LNBITS_BASE_URL, and LNBITS_INVOICE_KEY.');
    }
    return { baseUrl: baseUrl.replace(/\/$/, ''), invoiceKey };
  }

  async createInvoice(input: CreateInvoiceInput): Promise<CreateInvoiceResult> {
    const { baseUrl, invoiceKey } = this.getConfig();
    if (!Number.isInteger(input.amountSats) || input.amountSats <= 0) {
      throw new Error('Invoice amount must be a positive integer in sats');
    }
    const res = await fetch(`${baseUrl}/api/v1/payments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Api-Key': invoiceKey,
      },
      body: JSON.stringify({
        out: false,
        amount: input.amountSats,
        memo: input.memo,
        expiry: input.expirySeconds,
        unit: 'sat',
        extra: { payment_intent_id: input.paymentIntentId },
      }),
    });
    if (!res.ok) {
      throw new Error(`LNbits create invoice failed (${res.status})`);
    }
    const data = (await res.json()) as {
      payment_hash: string;
      payment_request: string;
    };
    return {
      provider: this.providerName,
      providerAccount: baseUrl,
      providerInvoiceId: data.payment_hash,
      paymentHash: data.payment_hash,
      bolt11: data.payment_request,
      amountSats: input.amountSats,
      amountMsat: input.amountSats * 1000,
      expiresAt: new Date(Date.now() + input.expirySeconds * 1000).toISOString(),
    };
  }

  async getInvoiceStatus(providerInvoiceId: string): Promise<ProviderInvoiceStatus> {
    const { baseUrl, invoiceKey } = this.getConfig();
    const res = await fetch(`${baseUrl}/api/v1/payments/${encodeURIComponent(providerInvoiceId)}`, {
      headers: { 'X-Api-Key': invoiceKey },
    });
    if (!res.ok) {
      throw new Error(`LNbits status check failed (${res.status})`);
    }
    const data = (await res.json()) as {
      paid: boolean;
      details?: { amount?: number; bolt11?: string };
    };
    const msat = Math.abs(Math.trunc(data.details?.amount || 0));
    return {
      provider: this.providerName,
      providerAccount: baseUrl,
      providerInvoiceId,
      paymentHash: providerInvoiceId,
      amountSats: Math.floor(msat / 1000),
      status: data.paid ? 'settled' : 'awaiting_payment',
      settledAt: data.paid ? new Date().toISOString() : null,
    };
  }

  async verifyProviderEvent(
    rawBody: string,
    signatureHeader: string | null
  ): Promise<VerifiedProviderEvent> {
    const { baseUrl } = this.getConfig();
    const secret = getWebhookSecret();
    if (!signatureHeader) {
      throw new Error('Missing webhook signature');
    }
    const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
    const a = Buffer.from(signatureHeader.trim());
    const b = Buffer.from(expected);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      throw new Error('Invalid LNbits webhook signature');
    }
    const body = JSON.parse(rawBody) as {
      payment_hash: string;
      amount: number;
      extra?: { payment_intent_id?: string };
    };
    const amountSats = Math.floor(Math.abs(Math.trunc(body.amount)) / 1000);
    return {
      provider: this.providerName,
      providerAccount: baseUrl,
      providerEventId: `lnbits_${body.payment_hash}`,
      providerInvoiceId: body.payment_hash,
      paymentHash: body.payment_hash,
      paymentIntentId: body.extra?.payment_intent_id || '',
      amountSats,
      status: 'settled',
      occurredAt: new Date().toISOString(),
    };
  }
}

export function getActivePaymentProvider(): PaymentProviderAdapter {
  const configured = process.env.LIGHTNING_PROVIDER || 'simulator';
  const liveEnabled = process.env.LIGHTNING_LIVE_ENABLED === 'true';
  if (configured === 'lnbits' && liveEnabled) {
    return new LnbitsTestnetProvider();
  }
  return new DeterministicSimulatorProvider();
}

export function getPaymentProviderByName(name: string): PaymentProviderAdapter {
  if (name === 'lnbits' && process.env.LIGHTNING_LIVE_ENABLED === 'true') {
    return new LnbitsTestnetProvider();
  }
  if (name === 'simulator') {
    return new DeterministicSimulatorProvider();
  }
  throw new Error(`Provider '${name}' is unavailable or disabled`);
}

/**
 * Payout Provider Adapter (separate from customer invoice collection)
 */
export class DeterministicSimulatorPayoutAdapter implements PayoutProviderAdapter {
  readonly providerName = 'simulator_payout';

  async executePayout(input: PayoutExecutionInput): Promise<PayoutExecutionResult> {
    if (!Number.isInteger(input.amountSats) || input.amountSats <= 0) {
      return {
        provider: this.providerName,
        providerPayoutId: `sim_po_err_${input.payoutId.slice(0, 8)}`,
        status: 'failed',
        networkFeeSats: 0,
        message: 'Payout amount must be a positive integer',
      };
    }

    // If destination starts with 'unknown@', simulate an unknown/pending outcome requiring reconciliation
    if (input.destination.toLowerCase().startsWith('unknown@')) {
      return {
        provider: this.providerName,
        providerPayoutId: `sim_po_pending_${input.idempotencyKey.slice(0, 12)}`,
        status: 'pending_reconciliation',
        networkFeeSats: 0,
        message: 'Provider timed out before confirming route settlement. Reconcile before retrying.',
      };
    }

    return {
      provider: this.providerName,
      providerPayoutId: `sim_po_${input.idempotencyKey.slice(0, 16)}`,
      status: 'completed',
      networkFeeSats: 1,
      message: 'Simulated outgoing Lightning payout settled',
    };
  }

  async reconcilePayout(providerPayoutId: string): Promise<PayoutExecutionResult> {
    return {
      provider: this.providerName,
      providerPayoutId,
      status: 'completed',
      networkFeeSats: 1,
      message: 'Reconciled with simulator ledger: outgoing transfer settled',
    };
  }
}

export function validateLightningDestination(destination: string): boolean {
  const trimmed = destination.trim();
  if (!trimmed || trimmed.length > 200) return false;
  // Lightning Address (user@domain.tld)
  const lnAddress = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  // LNURL bech32
  const lnurl = /^lnurl1[023456789ac-hj-np-z]{20,}$/i;
  return lnAddress.test(trimmed) || lnurl.test(trimmed);
}

export type { DirectToAuthorFutureAdapter };
