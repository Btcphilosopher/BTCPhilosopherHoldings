import { NextRequest, NextResponse } from 'next/server';
import { getDb } from './db';
import { getSessionFromRequest, verifyMutationOrigin } from './crypto';
import { User } from './types';

export function jsonNoStore(data: unknown, status = 200) {
  return NextResponse.json(data, {
    status,
    headers: {
      'Cache-Control': 'private, no-store, no-cache, must-revalidate',
    },
  });
}

export function getUserById(userId: string): User | null {
  const db = getDb();
  const row = db
    .prepare(
      `SELECT id, email, display_name, handle, role, demo_balance_sats, created_at
       FROM users WHERE id = ?`
    )
    .get(userId) as User | undefined;
  return row || null;
}

export async function requireAuth(req: NextRequest): Promise<
  | { ok: true; user: User }
  | { ok: false; response: NextResponse }
> {
  const session = await getSessionFromRequest(req);
  if (!session) {
    return {
      ok: false,
      response: jsonNoStore({ error: 'Authentication required' }, 401),
    };
  }
  const user = getUserById(session.userId);
  if (!user) {
    return {
      ok: false,
      response: jsonNoStore({ error: 'Session user not found' }, 401),
    };
  }
  return { ok: true, user };
}

export function checkCsrf(req: NextRequest): NextResponse | null {
  if (!verifyMutationOrigin(req)) {
    return jsonNoStore({ error: 'Invalid request origin' }, 403);
  }
  return null;
}
