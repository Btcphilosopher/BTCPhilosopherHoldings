import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { hashPassword } from './crypto';
import { estimateReadingMinutes } from './sanitize';

const DATA_DIR = path.resolve(process.cwd(), process.env.LUMEN_DATA_DIR || './data');
const DB_PATH = path.resolve(DATA_DIR, 'lumen.db');

const globalForDb = globalThis as unknown as {
  __lumenDb?: DatabaseSync;
};

export function getDb(): DatabaseSync {
  if (globalForDb.__lumenDb) {
    return globalForDb.__lumenDb;
  }
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const db = new DatabaseSync(DB_PATH);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  initSchema(db);
  seedDatabaseIfEmpty(db);
  globalForDb.__lumenDb = db;
  return db;
}

export function withTransaction<T>(db: DatabaseSync, fn: () => T): T {
  db.exec('BEGIN IMMEDIATE;');
  try {
    const result = fn();
    db.exec('COMMIT;');
    return result;
  } catch (err) {
    try {
      db.exec('ROLLBACK;');
    } catch {
      // Ignore rollback errors if already rolled back
    }
    throw err;
  }
}

function initSchema(db: DatabaseSync) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS system_config (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      display_name TEXT NOT NULL,
      handle TEXT NOT NULL UNIQUE,
      role TEXT NOT NULL CHECK (role IN ('reader', 'author', 'admin')),
      demo_balance_sats INTEGER NOT NULL DEFAULT 5000 CHECK (demo_balance_sats >= 0),
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS author_profiles (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      bio TEXT NOT NULL DEFAULT '',
      publication_name TEXT NOT NULL DEFAULT '',
      lightning_destination TEXT,
      destination_verified INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS publications (
      id TEXT PRIMARY KEY,
      owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      slug TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      tagline TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS articles (
      id TEXT PRIMARY KEY,
      author_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      publication_id TEXT NOT NULL REFERENCES publications(id) ON DELETE CASCADE,
      slug TEXT NOT NULL UNIQUE,
      topic TEXT NOT NULL CHECK (topic IN ('technology', 'culture', 'science', 'economics', 'design')),
      status TEXT NOT NULL CHECK (status IN ('draft', 'preview', 'published', 'revised', 'withdrawn')),
      cover_image_url TEXT NOT NULL,
      cover_image_alt TEXT NOT NULL,
      featured_rank INTEGER,
      current_revision_id TEXT,
      current_offer_id TEXT,
      view_count INTEGER NOT NULL DEFAULT 0,
      published_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS article_revisions (
      id TEXT PRIMARY KEY,
      article_id TEXT NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
      revision_number INTEGER NOT NULL,
      title TEXT NOT NULL,
      subtitle TEXT NOT NULL,
      body_markdown TEXT NOT NULL,
      preview_paragraph_count INTEGER NOT NULL DEFAULT 2 CHECK (preview_paragraph_count BETWEEN 1 AND 6),
      reading_time_minutes INTEGER NOT NULL DEFAULT 4,
      change_note TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      UNIQUE (article_id, revision_number)
    );

    CREATE TABLE IF NOT EXISTS media_assets (
      id TEXT PRIMARY KEY,
      owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      object_key TEXT NOT NULL UNIQUE,
      public_url TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      sha256 TEXT NOT NULL,
      alt_text TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS follows (
      follower_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      author_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL,
      PRIMARY KEY (follower_user_id, author_user_id)
    );

    CREATE TABLE IF NOT EXISTS bookmarks (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      article_id TEXT NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL,
      PRIMARY KEY (user_id, article_id)
    );

    CREATE TABLE IF NOT EXISTS article_offers (
      id TEXT PRIMARY KEY,
      article_id TEXT NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
      is_paid INTEGER NOT NULL DEFAULT 0,
      price_sats INTEGER NOT NULL DEFAULT 0 CHECK (price_sats >= 0),
      customer_fee_sats INTEGER NOT NULL DEFAULT 0 CHECK (customer_fee_sats >= 0),
      commission_bps INTEGER NOT NULL DEFAULT 1000 CHECK (commission_bps >= 0 AND commission_bps <= 5000),
      fee_policy_version TEXT NOT NULL,
      includes_future_revisions INTEGER NOT NULL DEFAULT 1,
      refund_terms TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS payment_intents (
      id TEXT PRIMARY KEY,
      kind TEXT NOT NULL CHECK (kind IN ('article_purchase', 'author_tip')),
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      article_id TEXT REFERENCES articles(id) ON DELETE SET NULL,
      recipient_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      offer_id TEXT REFERENCES article_offers(id) ON DELETE SET NULL,
      revision_id TEXT REFERENCES article_revisions(id) ON DELETE SET NULL,
      amount_sats INTEGER NOT NULL CHECK (amount_sats > 0),
      customer_fee_sats INTEGER NOT NULL DEFAULT 0 CHECK (customer_fee_sats >= 0),
      total_sats INTEGER NOT NULL CHECK (total_sats > 0),
      commission_sats INTEGER NOT NULL DEFAULT 0 CHECK (commission_sats >= 0),
      author_payable_sats INTEGER NOT NULL DEFAULT 0 CHECK (author_payable_sats >= 0),
      fee_policy_version TEXT NOT NULL,
      includes_future_revisions INTEGER NOT NULL DEFAULT 1,
      status TEXT NOT NULL CHECK (status IN ('created', 'awaiting_payment', 'settled', 'expired', 'cancelled', 'reconciliation_required')),
      fulfillment_status TEXT NOT NULL CHECK (fulfillment_status IN ('not_applicable', 'pending', 'fulfilled', 'failed_retryable')),
      simulate_fulfillment_failure INTEGER NOT NULL DEFAULT 0,
      provider TEXT NOT NULL,
      provider_account TEXT NOT NULL,
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      settled_at TEXT
    );

    CREATE TABLE IF NOT EXISTS lightning_invoices (
      id TEXT PRIMARY KEY,
      payment_intent_id TEXT NOT NULL UNIQUE REFERENCES payment_intents(id) ON DELETE CASCADE,
      provider TEXT NOT NULL,
      provider_invoice_id TEXT NOT NULL UNIQUE,
      payment_hash TEXT NOT NULL,
      bolt11 TEXT NOT NULL,
      amount_sats INTEGER NOT NULL CHECK (amount_sats > 0),
      amount_msat INTEGER NOT NULL CHECK (amount_msat > 0),
      status TEXT NOT NULL CHECK (status IN ('created', 'awaiting_payment', 'settled', 'expired', 'cancelled', 'reconciliation_required')),
      expires_at TEXT NOT NULL,
      settled_at TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS payment_events (
      id TEXT PRIMARY KEY,
      provider TEXT NOT NULL,
      provider_event_id TEXT NOT NULL,
      payment_intent_id TEXT NOT NULL REFERENCES payment_intents(id) ON DELETE CASCADE,
      provider_invoice_id TEXT NOT NULL,
      event_status TEXT NOT NULL,
      amount_sats INTEGER NOT NULL,
      raw_payload_redacted TEXT NOT NULL,
      received_at TEXT NOT NULL,
      UNIQUE (provider, provider_event_id)
    );

    CREATE TABLE IF NOT EXISTS purchases (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      article_id TEXT NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
      offer_id TEXT NOT NULL REFERENCES article_offers(id),
      revision_id TEXT NOT NULL REFERENCES article_revisions(id),
      payment_intent_id TEXT NOT NULL UNIQUE REFERENCES payment_intents(id),
      price_sats INTEGER NOT NULL,
      customer_fee_sats INTEGER NOT NULL,
      total_sats INTEGER NOT NULL,
      commission_sats INTEGER NOT NULL,
      author_payable_sats INTEGER NOT NULL,
      fee_policy_version TEXT NOT NULL,
      includes_future_revisions INTEGER NOT NULL DEFAULT 1,
      status TEXT NOT NULL CHECK (status IN ('active', 'refunded')),
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS entitlements (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      article_id TEXT NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
      purchase_id TEXT NOT NULL UNIQUE REFERENCES purchases(id) ON DELETE CASCADE,
      locked_revision_id TEXT NOT NULL REFERENCES article_revisions(id),
      includes_future_revisions INTEGER NOT NULL DEFAULT 1,
      granted_at TEXT NOT NULL,
      revoked_at TEXT,
      UNIQUE (user_id, article_id)
    );

    CREATE TABLE IF NOT EXISTS tips (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      recipient_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      article_id TEXT REFERENCES articles(id) ON DELETE SET NULL,
      payment_intent_id TEXT NOT NULL UNIQUE REFERENCES payment_intents(id),
      amount_sats INTEGER NOT NULL CHECK (amount_sats > 0),
      commission_sats INTEGER NOT NULL DEFAULT 0,
      author_payable_sats INTEGER NOT NULL CHECK (author_payable_sats >= 0),
      note TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL CHECK (status IN ('settled', 'refunded')),
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ledger_entries (
      id TEXT PRIMARY KEY,
      entry_type TEXT NOT NULL CHECK (entry_type IN ('customer_payment', 'author_payable', 'platform_revenue', 'provider_charge', 'network_fee', 'refund', 'payout')),
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      article_id TEXT REFERENCES articles(id) ON DELETE SET NULL,
      payment_intent_id TEXT REFERENCES payment_intents(id) ON DELETE SET NULL,
      related_id TEXT,
      amount_sats INTEGER NOT NULL,
      direction TEXT NOT NULL CHECK (direction IN ('credit', 'debit')),
      description TEXT NOT NULL,
      is_demo INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS refund_requests (
      id TEXT PRIMARY KEY,
      purchase_id TEXT NOT NULL UNIQUE REFERENCES purchases(id),
      requester_user_id TEXT NOT NULL REFERENCES users(id),
      reviewer_user_id TEXT REFERENCES users(id),
      requested_amount_sats INTEGER NOT NULL CHECK (requested_amount_sats > 0),
      reason TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('pending_review', 'approved_settled', 'rejected', 'payout_failed')),
      resolution_note TEXT NOT NULL DEFAULT '',
      outgoing_reference TEXT,
      created_at TEXT NOT NULL,
      resolved_at TEXT
    );

    CREATE TABLE IF NOT EXISTS payouts (
      id TEXT PRIMARY KEY,
      author_user_id TEXT NOT NULL REFERENCES users(id),
      idempotency_key TEXT NOT NULL UNIQUE,
      destination TEXT NOT NULL,
      amount_sats INTEGER NOT NULL CHECK (amount_sats > 0),
      network_fee_sats INTEGER NOT NULL DEFAULT 0,
      provider TEXT NOT NULL,
      provider_payout_id TEXT,
      status TEXT NOT NULL CHECK (status IN ('requested', 'pending_reconciliation', 'completed', 'failed')),
      message TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      completed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      actor_user_id TEXT,
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT NOT NULL,
      details_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);
}

function seedDatabaseIfEmpty(db: DatabaseSync) {
  const existing = db.prepare('SELECT COUNT(*) AS cnt FROM users').get() as { cnt: number };
  if (existing.cnt > 0) {
    return;
  }

  const now = new Date().toISOString();
  const demoPassHash = hashPassword('demo1234');

  const users = [
    {
      id: 'usr_reader_demo',
      email: 'reader@lumen.press',
      display_name: 'Clara Beaumont',
      handle: 'reader',
      role: 'reader',
      balance: 2500,
    },
    {
      id: 'usr_eleanor',
      email: 'eleanor@lumen.press',
      display_name: 'Eleanor Hart',
      handle: 'eleanor',
      role: 'author',
      balance: 4000,
    },
    {
      id: 'usr_daniel',
      email: 'daniel@lumen.press',
      display_name: 'Daniel Moss',
      handle: 'daniel',
      role: 'author',
      balance: 3200,
    },
    {
      id: 'usr_amelia',
      email: 'amelia@lumen.press',
      display_name: 'Amelia Reed',
      handle: 'amelia',
      role: 'author',
      balance: 2800,
    },
    {
      id: 'usr_julian',
      email: 'julian@lumen.press',
      display_name: 'Dr. Julian Vance',
      handle: 'julian',
      role: 'author',
      balance: 1500,
    },
    {
      id: 'usr_clara_econ',
      email: 'clara@lumen.press',
      display_name: 'Clara Lindqvist',
      handle: 'claralindqvist',
      role: 'author',
      balance: 1900,
    },
    {
      id: 'usr_soren',
      email: 'soren@lumen.press',
      display_name: 'Soren Lind',
      handle: 'soren',
      role: 'author',
      balance: 1700,
    },
  ];

  const insertUser = db.prepare(
    `INSERT INTO users (id, email, password_hash, display_name, handle, role, demo_balance_sats, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insertProfile = db.prepare(
    `INSERT INTO author_profiles (user_id, bio, publication_name, lightning_destination, destination_verified, updated_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  );
  const insertPub = db.prepare(
    `INSERT INTO publications (id, owner_user_id, slug, name, tagline, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  );

  const authorBios: Record<string, { bio: string; pub: string; ln: string }> = {
    usr_reader_demo: {
      bio: 'Curious reader and patron of independent essays.',
      pub: 'Reader Notes',
      ln: '',
    },
    usr_eleanor: {
      bio: 'Essayist writing on libraries, attention, civic architecture, and durable software.',
      pub: 'The Marginalia',
      ln: 'eleanor@lumen.example',
    },
    usr_daniel: {
      bio: 'Systems researcher examining protocol ownership, open silicon, and local-first tools.',
      pub: 'Substrate',
      ln: 'daniel@lumen.example',
    },
    usr_amelia: {
      bio: 'Cultural critic and novelist exploring craft, cadence, and quiet urban life.',
      pub: 'Evening Letter',
      ln: 'amelia@lumen.example',
    },
    usr_julian: {
      bio: 'Observational astronomer and historian of scientific instruments.',
      pub: 'Meridian Log',
      ln: 'julian@lumen.example',
    },
    usr_clara_econ: {
      bio: 'Monetary historian studying settlement systems, micro-commerce, and public goods.',
      pub: 'Clearance & Coin',
      ln: 'clara@lumen.example',
    },
    usr_soren: {
      bio: 'Book designer and typographer writing about paper, lead type, and digital legibility.',
      pub: 'Specimen Sheet',
      ln: 'soren@lumen.example',
    },
  };

  for (const u of users) {
    insertUser.run(u.id, u.email, demoPassHash, u.display_name, u.handle, u.role, u.balance, now);
    const meta = authorBios[u.id];
    insertProfile.run(
      u.id,
      meta.bio,
      meta.pub,
      meta.ln || null,
      meta.ln ? 1 : 0,
      now
    );
    insertPub.run(
      `pub_${u.handle}`,
      u.id,
      u.handle,
      meta.pub,
      meta.bio,
      now
    );
  }

  const seedArticles = [
    {
      id: 'art_personal_library',
      author_id: 'usr_eleanor',
      pub_id: 'pub_eleanor',
      slug: 'the-quiet-return-of-the-personal-library',
      topic: 'culture',
      title: 'The quiet return of the personal library',
      subtitle: 'Why thoughtful readers are building private archives again in an age of ephemeral feeds.',
      cover: '/images/articles/personal-library.svg',
      alt: 'Warm reading room library with cedar bookshelves and brass banker lamp',
      featured_rank: 1,
      is_paid: 1,
      price_sats: 250,
      preview_count: 2,
      includes_future_revisions: 1,
      published_at: '2026-11-22T09:00:00Z',
      body: `Across small apartments and cedar-lined studies, a quiet rebellion has been underway. Readers tired of disappearing bookmarks, algorithmic clutter, and rented subscriptions are returning to the discipline of keeping a personal library—both on wooden shelves and in durable local folders.

To own an essay or a book outright changes how you read it. You linger longer on a difficult paragraph. You write in the margin with a soft pencil, knowing the text will still be in the exact same room ten winters from now.

## Ownership as an intellectual habit

When every piece of writing lives behind an advertising funnel or an expiring platform feed, attention fractures into brief, anxious glances. A library asks for a different posture altogether: patience, indexing, and return.

> A personal library is not a monument to what you have finished; it is a conversation waiting for your next quiet evening.

In my own study, the transition began with a simple ledger of essays I wished to revisit. Whenever a piece changed how I thought about cities or software, I printed it on cotton paper or saved a clean archival copy locally. Gradually, I noticed that paying a modest direct price—a few hundred satoshis rather than a vague monthly bundle—created an honest covenant between writer and reader.

## What endures when the feed goes dark

- Keep canonical plain-text or Markdown copies of the essays that shaped your thinking.
- Annotate provenance: who wrote it, when it was revised, and why it mattered at the time.
- Support writers per piece or per edition so independent criticism never depends on outrage metrics.

![Reading lamp illuminating an open folio](/images/articles/personal-library.svg "Fig. 1 — Quiet evening reading desk")

Nothing in software can stop a determined reader from copying words on their screen, and no honest library pretends otherwise. Instead, modest direct payments treat the reader as a patron: you pay a small, transparent sum to unlock the complete edition, and the writer earns the freedom to spend three weeks getting a single argument right.`,
    },
    {
      id: 'art_future_computing',
      author_id: 'usr_daniel',
      pub_id: 'pub_daniel',
      slug: 'who-owns-the-future-of-computing',
      topic: 'technology',
      title: 'Who owns the future of computing?',
      subtitle: 'Local-first tools, open protocols, and the quiet tug-of-war over where our work actually lives.',
      cover: '/images/articles/future-computing.svg',
      alt: 'Traveler aboard a warm-lit night train crossing twilight plains',
      featured_rank: 2,
      is_paid: 0,
      price_sats: 0,
      preview_count: 2,
      includes_future_revisions: 1,
      published_at: '2026-11-24T14:30:00Z',
      body: `On a late November train out of Penn Station, watching the carriage lights flicker against dark river water, I noticed three engineers across the aisle unable to open their own design documents because the tunnel had dropped their cellular signal.

That ordinary inconvenience reveals the central bargain of modern computing: we traded sovereign files for effortless synchronization, and in the process forgot what it felt like to hold the deed to our own tools.

## Three layers of computational autonomy

1. **Storage**: Can you read your archive thirty years from now without asking a vendor for an API token?
2. **Identity**: Do your readers and collaborators follow your cryptographic handle, or are they leased to you by a feed broker?
3. **Settlement**: Can a small publisher collect fifty cents from a reader across the ocean without forfeiting forty percent to minimum card fees?

> When software charges rent on memory, even ordinary thought becomes a subscription liability.

The good news is that the tide is turning back toward legible, composable systems. SQLite files sit happily on a laptop disk. Open formats like Markdown survive every fashion cycle. And micropayment rails such as Lightning allow a two-hundred-satoshi essay to settle cleanly without surveillance advertising.

## Designing software that stays small

The most durable tools in our industry share an unhurried restraint. They publish clear APIs, avoid opaque lock-in, and keep human-scale economics intact so a single programmer or essayist can maintain a studio for decades.`,
    },
    {
      id: 'art_slower_progress',
      author_id: 'usr_amelia',
      pub_id: 'pub_amelia',
      slug: 'a-slower-kind-of-progress',
      topic: 'culture',
      title: 'A slower kind of progress',
      subtitle: 'On craftsmanship, unhurried essays, and why speed is rarely the right measure of cultural work.',
      cover: '/images/articles/slower-progress.svg',
      alt: 'Reader seated beside a glowing amber table lamp and rain-streaked parlor window',
      featured_rank: 3,
      is_paid: 1,
      price_sats: 100,
      preview_count: 2,
      includes_future_revisions: 1,
      published_at: '2026-11-21T17:15:00Z',
      body: `Every Tuesday evening in winter, the brass lamp in the corner parlor clicks on at four-thirty, casting an amber circle across the oak table while rain beads on the windowpane. Inside that circle, time moves at the speed of sentences rather than notifications.

We have spent twenty years celebrating frictionless publishing, yet almost nobody mentions what friction protects. A little friction filters out half-formed reflexes and leaves room for revision, doubt, and second drafts.

## The discipline of the second draft

Great essays rarely arrive in a single afternoon. They need a walk around the block, a contradictory book pulled from the middle shelf, and an evening where the writer deletes the cleverest paragraph because it wasn't true.

> Speed flatters the publisher; patience respects the reader.

When readers pay even a hundred satoshis for an essay, an invisible contract forms: the writer promises not to waste the reader's evening with filler, and the reader grants the writer permission to publish once a month instead of twice a day.

## Notes from the studio

- Write for the reader who turns off notifications after dinner.
- Edit aloud; the ear catches cadence defects the eye forgives.
- Treat every revision as a stewardship obligation toward people who bought the first edition.`,
    },
    {
      id: 'art_coastal_observatory',
      author_id: 'usr_julian',
      pub_id: 'pub_julian',
      slug: 'notes-from-the-coastal-observatory',
      topic: 'science',
      title: 'Notes from the coastal observatory',
      subtitle: 'How nineteenth-century tidal clocks and modern radio arrays measure patience across generations.',
      cover: '/images/articles/science-observatory.svg',
      alt: 'Coastal astronomical dome overlooking dark sea under crescent moon',
      featured_rank: null,
      is_paid: 0,
      price_sats: 0,
      preview_count: 2,
      includes_future_revisions: 1,
      published_at: '2026-11-20T11:00:00Z',
      body: `High on the slate headland above St. Ives, the brass meridian circle still points due south through salt mist and Atlantic wind. Its keeper logs barometric pressure and star transits in linen notebooks whose bindings match volumes started in 1894.

Long-horizon science depends on continuity that outlives grant cycles. An instrument built to last a century teaches humility to every technician who oils its gears.

## Calibrating against deep time

When modern astronomers calibrate millisecond pulsars, they rely on the same quiet virtues practiced by coastal keepers: meticulous timestamps, honest uncertainty margins, and open notebooks anyone can verify.

- Never discard raw observations when upgrading a model.
- Record calibration drift alongside every measurement.
- Publish methods clearly enough that an apprentice fifty years later can reproduce the chain.`,
    },
    {
      id: 'art_ledger_commons',
      author_id: 'usr_clara_econ',
      pub_id: 'pub_claralindqvist',
      slug: 'the-ledger-and-the-commons',
      topic: 'economics',
      title: 'The ledger and the commons',
      subtitle: 'Integer accounting, micropayment fees, and why small transactions change what gets written.',
      cover: '/images/articles/economics-mint.svg',
      alt: 'Architectural stone arches framing balanced brass scales',
      featured_rank: null,
      is_paid: 1,
      price_sats: 150,
      preview_count: 2,
      includes_future_revisions: 1,
      published_at: '2026-11-19T08:45:00Z',
      body: `Before card networks imposed thirty-cent fixed minimums on every digital checkout, nobody imagined a world where selling a single essay for fifteen cents would be economically absurd. Yet that threshold quietly shaped the entire web.

When small unit sales fail to clear payment overhead, publishers are forced toward two extremes: massive ad-driven scale or rigid monthly subscriptions. Neither model serves the writer who produces six extraordinary pieces a year.

## Why integer accounting matters

A credible publishing ledger never rounds away a satoshi with floating-point approximations. Every customer payment, platform commission, author payable, and refund must reconcile down to the last integer unit.

> Transparent books are the quiet foundation of trust between independent studios and their patrons.

In a platform-collected model, clarity begins with naming roles honestly: the platform collects the invoice, snaps a versioned fee policy to the purchase record, credits the author's payable ledger, and exposes a complete statement before a single payout is requested.

## Looking toward direct settlement

As Lightning routing matures, non-custodial direct-to-author invoices can complement platform settlement—provided the software never blurs the legal and accounting boundary between the two.`,
    },
    {
      id: 'art_type_permanence',
      author_id: 'usr_soren',
      pub_id: 'pub_soren',
      slug: 'type-paper-and-permanence',
      topic: 'design',
      title: 'Type, paper, and permanence',
      subtitle: 'What broadsheet newspapers and bookmakers can still teach digital reading interfaces.',
      cover: '/images/articles/design-atelier.svg',
      alt: 'Editorial broadsheet layout desk with warm paper sheets and ink rules',
      featured_rank: null,
      is_paid: 0,
      price_sats: 0,
      preview_count: 2,
      includes_future_revisions: 1,
      published_at: '2026-11-18T16:00:00Z',
      body: `Pick up a well-printed morning broadsheet and notice what is absent: no bouncing badges, no glowing telemetry dots, no competing popups fighting for your eye while you read the third sentence.

Bookmakers solved the geometry of reading five hundred years ago. A comfortable measure of sixty-five to seventy-five characters, generous margins, warm uncoated paper tones, and crisp hairline rules invite sustained thought.

## Three rules for calm editorial screens

1. **Paper over glare**: Warm ivory surfaces soften contrast fatigue without sacrificing crispness.
2. **Restraint in ornament**: Let typography and photography carry the hierarchy instead of stacked boxes.
3. **Respect the reader's place**: When someone opens a long essay, clear the stage so only the prose and a quiet reading control remain.`,
    },
    {
      id: 'art_protocols_patient',
      author_id: 'usr_eleanor',
      pub_id: 'pub_eleanor',
      slug: 'protocols-for-patient-readers',
      topic: 'technology',
      title: 'Protocols for patient readers',
      subtitle: 'Designing idempotent payment verification and archival editions for independent periodicals.',
      cover: '/images/articles/hero-skyline.svg',
      alt: 'Nocturnal harbor skyline illuminated in amber light',
      featured_rank: null,
      is_paid: 1,
      price_sats: 300,
      preview_count: 2,
      includes_future_revisions: 0,
      published_at: '2026-11-16T12:00:00Z',
      body: `Digital publishing fails most awkwardly at the threshold where money meets access. A reader scans an invoice, their phone vibrates, and the browser tab either unlocks smoothly or stalls in limbo.

Reliable editorial commerce treats payment verification as a server-side state machine, never a hopeful redirect. Every invoice carries an explicit expiry, a verified provider signature, and an idempotent fulfillment lock.

## Why edition snapshots matter

When an offer specifies whether later revisions are included, both reader and writer know what is promised. Locking the purchased revision preserves historical integrity while letting authors publish expanded second editions cleanly.

- Confirm settlement exclusively through authenticated provider webhooks or server-side status queries.
- Separate entitlement fulfillment from payment recording so temporary failures recover cleanly without double-charging.`,
    },
  ];

  const insertArticle = db.prepare(
    `INSERT INTO articles (id, author_user_id, publication_id, slug, topic, status, cover_image_url, cover_image_alt, featured_rank, current_revision_id, current_offer_id, view_count, published_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, 'published', ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insertRevision = db.prepare(
    `INSERT INTO article_revisions (id, article_id, revision_number, title, subtitle, body_markdown, preview_paragraph_count, reading_time_minutes, change_note, created_at)
     VALUES (?, ?, 1, ?, ?, ?, ?, ?, 'Initial published edition', ?)`
  );
  const insertOffer = db.prepare(
    `INSERT INTO article_offers (id, article_id, is_paid, price_sats, customer_fee_sats, commission_bps, fee_policy_version, includes_future_revisions, refund_terms, created_at)
     VALUES (?, ?, ?, ?, 0, 1000, 'fee-policy-2026-v1', ?, ?, ?)`
  );

  for (const a of seedArticles) {
    const revId = `rev_${a.id}_1`;
    const offerId = `off_${a.id}_1`;
    const readMins = estimateReadingMinutes(a.body);
    const refundTerms = a.is_paid
      ? 'Lightning payments are final and cannot be reversed like card chargebacks. Reviewed refunds may be issued via separate outgoing payout within 7 days if access fails to unlock or content was withdrawn.'
      : 'Free edition — no payment required.';

    insertArticle.run(
      a.id,
      a.author_id,
      a.pub_id,
      a.slug,
      a.topic,
      a.cover,
      a.alt,
      a.featured_rank,
      revId,
      offerId,
      a.featured_rank ? 180 - a.featured_rank * 25 : 42,
      a.published_at,
      a.published_at,
      a.published_at
    );
    insertRevision.run(
      revId,
      a.id,
      a.title,
      a.subtitle,
      a.body,
      a.preview_count,
      readMins,
      a.published_at
    );
    insertOffer.run(
      offerId,
      a.id,
      a.is_paid,
      a.price_sats,
      a.includes_future_revisions,
      refundTerms,
      a.published_at
    );
  }

  // Seed default reader follow & bookmark so Following & My Library feel alive immediately
  db.prepare(
    `INSERT INTO follows (follower_user_id, author_user_id, created_at) VALUES (?, ?, ?)`
  ).run('usr_reader_demo', 'usr_daniel', now);

  db.prepare(
    `INSERT INTO bookmarks (user_id, article_id, created_at) VALUES (?, ?, ?)`
  ).run('usr_reader_demo', 'art_future_computing', now);

  db.prepare(
    `INSERT INTO audit_logs (id, actor_user_id, action, entity_type, entity_id, details_json, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(
    'aud_seed_init',
    null,
    'seed_database',
    'system',
    'lumen',
    JSON.stringify({ note: 'Demonstration catalog seeded (prices and balances are simulation fixtures).' }),
    now
  );
}
