import crypto from 'node:crypto';
import { getDb, withTransaction } from './db';
import {
  DeterministicSimulatorPayoutAdapter,
  getActivePaymentProvider,
  getPaymentProviderByName,
  validateLightningDestination,
} from './lightning';
import { PaymentIntentRecord, VerifiedProviderEvent } from './types';

export const CURRENT_FEE_POLICY_VERSION = 'fee-policy-2026-v1';
export const DEFAULT_CUSTOMER_FEE_SATS = 0;
export const DEFAULT_PURCHASE_COMMISSION_BPS = 1000; // 10.00% platform commission deducted from author proceeds
export const DEFAULT_TIP_COMMISSION_BPS = 0; // 0% commission on tips
export const MIN_PAYOUT_SATS = 50;
export const MAX_SINGLE_PAYOUT_SATS = 50000;
export const DEFAULT_INVOICE_EXPIRY_SECONDS = 900; // 15 minutes
export const MAX_ACTIVE_PENDING_INTENTS = 5;

export function computePurchaseAccounting(
  priceSats: number,
  customerFeeSats = DEFAULT_CUSTOMER_FEE_SATS,
  commissionBps = DEFAULT_PURCHASE_COMMISSION_BPS
) {
  if (!Number.isInteger(priceSats) || priceSats <= 0) {
    throw new Error('Price must be a positive integer in sats');
  }
  if (!Number.isInteger(customerFeeSats) || customerFeeSats < 0) {
    throw new Error('Customer fee must be a non-negative integer');
  }
  if (!Number.isInteger(commissionBps) || commissionBps < 0 || commissionBps > 5000) {
    throw new Error('Commission basis points must be an integer between 0 and 5000');
  }
  const totalSats = priceSats + customerFeeSats;
  // Integer floor division in sats: never floating point
  const commissionSats = Math.floor((priceSats * commissionBps) / 10000);
  const authorPayableSats = priceSats - commissionSats;
  return {
    priceSats,
    customerFeeSats,
    totalSats,
    commissionSats,
    authorPayableSats,
  };
}

export function computeTipAccounting(amountSats: number) {
  if (!Number.isInteger(amountSats) || amountSats < 1 || amountSats > 1000000) {
    throw new Error('Tip amount must be an integer between 1 and 1,000,000 sats');
  }
  const commissionSats = Math.floor((amountSats * DEFAULT_TIP_COMMISSION_BPS) / 10000);
  const authorPayableSats = amountSats - commissionSats;
  return {
    amountSats,
    customerFeeSats: 0,
    totalSats: amountSats,
    commissionSats,
    authorPayableSats,
  };
}

export function expireStaleInvoices(): number {
  const db = getDb();
  const now = new Date().toISOString();
  const res = withTransaction(db, () => {
    const expiredIntents = db
      .prepare(
        `UPDATE payment_intents
         SET status = 'expired'
         WHERE status IN ('created', 'awaiting_payment') AND expires_at <= ?`
      )
      .run(now);
    db.prepare(
      `UPDATE lightning_invoices
       SET status = 'expired'
       WHERE status IN ('created', 'awaiting_payment') AND expires_at <= ?`
    ).run(now);
    return Number(expiredIntents.changes || 0);
  });
  return res;
}

export async function createArticlePurchaseIntent(params: {
  userId: string;
  articleId: string;
  expirySeconds?: number;
  simulateFulfillmentFailure?: boolean;
}): Promise<PaymentIntentRecord> {
  expireStaleInvoices();
  const db = getDb();

  const article = db
    .prepare(
      `SELECT a.id, a.slug, a.author_user_id, a.status, a.current_revision_id, a.current_offer_id,
              r.title AS article_title,
              o.is_paid, o.price_sats, o.customer_fee_sats, o.commission_bps, o.fee_policy_version, o.includes_future_revisions
       FROM articles a
       JOIN article_revisions r ON r.id = a.current_revision_id
       JOIN article_offers o ON o.id = a.current_offer_id
       WHERE a.id = ?`
    )
    .get(params.articleId) as
    | {
        id: string;
        slug: string;
        author_user_id: string;
        status: string;
        current_revision_id: string;
        current_offer_id: string;
        article_title: string;
        is_paid: number;
        price_sats: number;
        customer_fee_sats: number;
        commission_bps: number;
        fee_policy_version: string;
        includes_future_revisions: number;
      }
    | undefined;

  if (!article || (article.status !== 'published' && article.status !== 'revised')) {
    throw new Error('Article is not available for purchase');
  }
  if (!article.is_paid || article.price_sats <= 0) {
    throw new Error('This article is free to read and does not require a purchase');
  }

  const existingEntitlement = db
    .prepare(
      `SELECT id FROM entitlements WHERE user_id = ? AND article_id = ? AND revoked_at IS NULL`
    )
    .get(params.userId, article.id);
  if (existingEntitlement) {
    throw new Error('You already own access to this article');
  }

  const activeCount = db
    .prepare(
      `SELECT COUNT(*) AS cnt FROM payment_intents
       WHERE user_id = ? AND status IN ('created', 'awaiting_payment')`
    )
    .get(params.userId) as { cnt: number };
  if (activeCount.cnt >= MAX_ACTIVE_PENDING_INTENTS) {
    throw new Error(
      `Too many active pending invoices (${MAX_ACTIVE_PENDING_INTENTS} max). Pay, cancel, or wait for expiry before creating another.`
    );
  }

  const accounting = computePurchaseAccounting(
    article.price_sats,
    article.customer_fee_sats,
    article.commission_bps
  );

  const intentId = `pi_${crypto.randomUUID()}`;
  const expirySeconds = Math.max(5, Math.min(params.expirySeconds ?? DEFAULT_INVOICE_EXPIRY_SECONDS, 3600));
  const provider = getActivePaymentProvider();

  const invoice = await provider.createInvoice({
    paymentIntentId: intentId,
    amountSats: accounting.totalSats,
    memo: `Lumen unlock: ${article.article_title}`,
    expirySeconds,
  });

  const now = new Date().toISOString();
  const invoiceDbId = `inv_${crypto.randomUUID()}`;

  withTransaction(db, () => {
    db.prepare(
      `INSERT INTO payment_intents (
        id, kind, user_id, article_id, recipient_user_id, offer_id, revision_id,
        amount_sats, customer_fee_sats, total_sats, commission_sats, author_payable_sats,
        fee_policy_version, includes_future_revisions, status, fulfillment_status,
        simulate_fulfillment_failure, provider, provider_account, created_at, expires_at
      ) VALUES (?, 'article_purchase', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'awaiting_payment', 'pending', ?, ?, ?, ?, ?)`
    ).run(
      intentId,
      params.userId,
      article.id,
      article.author_user_id,
      article.current_offer_id,
      article.current_revision_id,
      accounting.priceSats,
      accounting.customerFeeSats,
      accounting.totalSats,
      accounting.commissionSats,
      accounting.authorPayableSats,
      article.fee_policy_version,
      article.includes_future_revisions,
      params.simulateFulfillmentFailure ? 1 : 0,
      invoice.provider,
      invoice.providerAccount,
      now,
      invoice.expiresAt
    );

    db.prepare(
      `INSERT INTO lightning_invoices (
        id, payment_intent_id, provider, provider_invoice_id, payment_hash, bolt11,
        amount_sats, amount_msat, status, expires_at, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'awaiting_payment', ?, ?)`
    ).run(
      invoiceDbId,
      intentId,
      invoice.provider,
      invoice.providerInvoiceId,
      invoice.paymentHash,
      invoice.bolt11,
      invoice.amountSats,
      invoice.amountMsat,
      invoice.expiresAt,
      now
    );

    db.prepare(
      `INSERT INTO audit_logs (id, actor_user_id, action, entity_type, entity_id, details_json, created_at)
       VALUES (?, ?, 'create_purchase_invoice', 'payment_intent', ?, ?, ?)`
    ).run(
      `aud_${crypto.randomUUID()}`,
      params.userId,
      intentId,
      JSON.stringify({
        article_id: article.id,
        total_sats: accounting.totalSats,
        provider: invoice.provider,
      }),
      now
    );
  });

  const record = getPaymentIntentById(intentId);
  if (!record) throw new Error('Failed to load created payment intent');
  return record;
}

export async function createAuthorTipIntent(params: {
  userId: string;
  recipientUserId: string;
  articleId?: string | null;
  amountSats: number;
  note?: string;
  expirySeconds?: number;
}): Promise<PaymentIntentRecord> {
  expireStaleInvoices();
  const db = getDb();

  const recipient = db
    .prepare(`SELECT id, display_name FROM users WHERE id = ?`)
    .get(params.recipientUserId) as { id: string; display_name: string } | undefined;
  if (!recipient) {
    throw new Error('Recipient author not found');
  }

  const activeCount = db
    .prepare(
      `SELECT COUNT(*) AS cnt FROM payment_intents
       WHERE user_id = ? AND status IN ('created', 'awaiting_payment')`
    )
    .get(params.userId) as { cnt: number };
  if (activeCount.cnt >= MAX_ACTIVE_PENDING_INTENTS) {
    throw new Error(
      `Too many active pending invoices (${MAX_ACTIVE_PENDING_INTENTS} max). Please complete or cancel an active invoice first.`
    );
  }

  const accounting = computeTipAccounting(params.amountSats);
  const intentId = `pi_${crypto.randomUUID()}`;
  const expirySeconds = Math.max(5, Math.min(params.expirySeconds ?? DEFAULT_INVOICE_EXPIRY_SECONDS, 3600));
  const provider = getActivePaymentProvider();

  const invoice = await provider.createInvoice({
    paymentIntentId: intentId,
    amountSats: accounting.totalSats,
    memo: `Lumen tip for ${recipient.display_name}`,
    expirySeconds,
  });

  const now = new Date().toISOString();
  const invoiceDbId = `inv_${crypto.randomUUID()}`;

  withTransaction(db, () => {
    db.prepare(
      `INSERT INTO payment_intents (
        id, kind, user_id, article_id, recipient_user_id, offer_id, revision_id,
        amount_sats, customer_fee_sats, total_sats, commission_sats, author_payable_sats,
        fee_policy_version, includes_future_revisions, status, fulfillment_status,
        simulate_fulfillment_failure, provider, provider_account, created_at, expires_at
      ) VALUES (?, 'author_tip', ?, ?, ?, NULL, NULL, ?, ?, ?, ?, ?, ?, 0, 'awaiting_payment', 'pending', 0, ?, ?, ?, ?)`
    ).run(
      intentId,
      params.userId,
      params.articleId || null,
      recipient.id,
      accounting.amountSats,
      accounting.customerFeeSats,
      accounting.totalSats,
      accounting.commissionSats,
      accounting.authorPayableSats,
      CURRENT_FEE_POLICY_VERSION,
      invoice.provider,
      invoice.providerAccount,
      now,
      invoice.expiresAt
    );

    db.prepare(
      `INSERT INTO lightning_invoices (
        id, payment_intent_id, provider, provider_invoice_id, payment_hash, bolt11,
        amount_sats, amount_msat, status, expires_at, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'awaiting_payment', ?, ?)`
    ).run(
      invoiceDbId,
      intentId,
      invoice.provider,
      invoice.providerInvoiceId,
      invoice.paymentHash,
      invoice.bolt11,
      invoice.amountSats,
      invoice.amountMsat,
      invoice.expiresAt,
      now
    );

    db.prepare(
      `INSERT INTO audit_logs (id, actor_user_id, action, entity_type, entity_id, details_json, created_at)
       VALUES (?, ?, 'create_tip_invoice', 'payment_intent', ?, ?, ?)`
    ).run(
      `aud_${crypto.randomUUID()}`,
      params.userId,
      intentId,
      JSON.stringify({
        recipient_user_id: recipient.id,
        total_sats: accounting.totalSats,
        note_length: (params.note || '').length,
      }),
      now
    );
  });

  const record = getPaymentIntentById(intentId);
  if (!record) throw new Error('Failed to load created tip intent');
  return record;
}

export function getPaymentIntentById(intentId: string): PaymentIntentRecord | null {
  expireStaleInvoices();
  const db = getDb();
  const row = db
    .prepare(
      `SELECT pi.*,
              r.title AS article_title,
              a.slug AS article_slug,
              u.display_name AS recipient_name,
              u.handle AS recipient_handle,
              p.id AS purchase_id
       FROM payment_intents pi
       LEFT JOIN articles a ON a.id = pi.article_id
       LEFT JOIN article_revisions r ON r.id = a.current_revision_id
       LEFT JOIN users u ON u.id = pi.recipient_user_id
       LEFT JOIN purchases p ON p.payment_intent_id = pi.id
       WHERE pi.id = ?`
    )
    .get(intentId) as Record<string, unknown> | undefined;

  if (!row) return null;

  const inv = db
    .prepare(`SELECT * FROM lightning_invoices WHERE payment_intent_id = ?`)
    .get(intentId) as Record<string, unknown> | undefined;

  return {
    id: row.id as string,
    kind: row.kind as PaymentIntentRecord['kind'],
    user_id: row.user_id as string,
    article_id: (row.article_id as string) || null,
    recipient_user_id: row.recipient_user_id as string,
    offer_id: (row.offer_id as string) || null,
    revision_id: (row.revision_id as string) || null,
    amount_sats: Number(row.amount_sats),
    customer_fee_sats: Number(row.customer_fee_sats),
    total_sats: Number(row.total_sats),
    commission_sats: Number(row.commission_sats),
    author_payable_sats: Number(row.author_payable_sats),
    fee_policy_version: row.fee_policy_version as string,
    includes_future_revisions: Boolean(row.includes_future_revisions),
    status: row.status as PaymentIntentRecord['status'],
    fulfillment_status: row.fulfillment_status as PaymentIntentRecord['fulfillment_status'],
    simulate_fulfillment_failure: Boolean(row.simulate_fulfillment_failure),
    provider: row.provider as string,
    provider_account: row.provider_account as string,
    created_at: row.created_at as string,
    expires_at: row.expires_at as string,
    settled_at: (row.settled_at as string) || null,
    article_title: (row.article_title as string) || undefined,
    article_slug: (row.article_slug as string) || undefined,
    recipient_name: (row.recipient_name as string) || undefined,
    recipient_handle: (row.recipient_handle as string) || undefined,
    purchase_id: (row.purchase_id as string) || null,
    invoice: inv
      ? {
          id: inv.id as string,
          payment_intent_id: inv.payment_intent_id as string,
          provider: inv.provider as string,
          provider_invoice_id: inv.provider_invoice_id as string,
          payment_hash: inv.payment_hash as string,
          bolt11: inv.bolt11 as string,
          amount_sats: Number(inv.amount_sats),
          amount_msat: Number(inv.amount_msat),
          status: inv.status as PaymentIntentRecord['status'],
          expires_at: inv.expires_at as string,
          settled_at: (inv.settled_at as string) || null,
          created_at: inv.created_at as string,
        }
      : undefined,
  };
}

/**
 * Processes a verified provider event idempotently inside a serialized DB transaction.
 * Enforces payment reference, invoice identity, expected amount, provider account,
 * duplicate event deduplication, expired-invoice handling, and fulfillment recovery.
 */
export function processVerifiedProviderEvent(event: VerifiedProviderEvent): {
  duplicate: boolean;
  intent: PaymentIntentRecord;
  outcome: string;
} {
  const db = getDb();

  const outcome = withTransaction(db, () => {
    const existingEvent = db
      .prepare(
        `SELECT id FROM payment_events WHERE provider = ? AND provider_event_id = ?`
      )
      .get(event.provider, event.providerEventId);

    if (existingEvent) {
      return { duplicate: true, outcome: 'duplicate_event_ignored' };
    }

    const intent = db
      .prepare(`SELECT * FROM payment_intents WHERE id = ?`)
      .get(event.paymentIntentId) as Record<string, unknown> | undefined;

    if (!intent) {
      throw new Error('Referenced payment intent not found');
    }

    const invoice = db
      .prepare(`SELECT * FROM lightning_invoices WHERE payment_intent_id = ?`)
      .get(event.paymentIntentId) as Record<string, unknown> | undefined;

    if (!invoice) {
      throw new Error('Invoice record missing for payment intent');
    }

    if (invoice.provider_invoice_id !== event.providerInvoiceId) {
      throw new Error('Invoice identity mismatch');
    }
    if (invoice.payment_hash !== event.paymentHash) {
      throw new Error('Payment hash mismatch');
    }
    if (intent.provider_account !== event.providerAccount) {
      throw new Error('Provider account mismatch');
    }
    if (Number(intent.total_sats) !== event.amountSats) {
      throw new Error('Settled amount does not match expected total_sats');
    }

    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO payment_events (
        id, provider, provider_event_id, payment_intent_id, provider_invoice_id,
        event_status, amount_sats, raw_payload_redacted, received_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      `pe_${crypto.randomUUID()}`,
      event.provider,
      event.providerEventId,
      event.paymentIntentId,
      event.providerInvoiceId,
      event.status,
      event.amountSats,
      JSON.stringify({
        provider: event.provider,
        provider_event_id: event.providerEventId,
        status: event.status,
        amount_sats: event.amountSats,
      }),
      now
    );

    if (event.status === 'expired' || event.status === 'cancelled') {
      if (intent.status !== 'settled') {
        db.prepare(`UPDATE payment_intents SET status = ? WHERE id = ?`).run(
          event.status,
          event.paymentIntentId
        );
        db.prepare(`UPDATE lightning_invoices SET status = ? WHERE id = ?`).run(
          event.status,
          invoice.id as string
        );
      }
      return { duplicate: false, outcome: `marked_${event.status}` };
    }

    // Settlement event
    const wasExpired =
      intent.status === 'expired' || (intent.expires_at as string) <= now;

    // If intent already settled and fulfilled, ignore safely
    if (intent.status === 'settled' && intent.fulfillment_status === 'fulfilled') {
      return { duplicate: false, outcome: 'already_settled_fulfilled' };
    }

    // Record customer payment settlement regardless of temporary fulfillment failure or late expiry
    const newIntentStatus = wasExpired ? 'reconciliation_required' : 'settled';

    db.prepare(
      `UPDATE payment_intents
       SET status = ?, settled_at = COALESCE(settled_at, ?)
       WHERE id = ?`
    ).run(newIntentStatus, event.occurredAt, event.paymentIntentId);

    db.prepare(
      `UPDATE lightning_invoices
       SET status = ?, settled_at = COALESCE(settled_at, ?)
       WHERE id = ?`
    ).run(newIntentStatus, event.occurredAt, invoice.id as string);

    // Record customer_payment ledger entry once
    const existingCustLedger = db
      .prepare(
        `SELECT id FROM ledger_entries WHERE payment_intent_id = ? AND entry_type = 'customer_payment'`
      )
      .get(event.paymentIntentId);

    if (!existingCustLedger) {
      db.prepare(
        `INSERT INTO ledger_entries (
          id, entry_type, user_id, article_id, payment_intent_id, related_id,
          amount_sats, direction, description, is_demo, created_at
        ) VALUES (?, 'customer_payment', ?, ?, ?, ?, ?, 'credit', ?, 1, ?)`
      ).run(
        `led_${crypto.randomUUID()}`,
        intent.user_id as string,
        (intent.article_id as string) || null,
        event.paymentIntentId,
        invoice.id as string,
        Number(intent.total_sats),
        `Customer payment settled (${intent.kind})`,
        now
      );

      // Deduct demo balance in simulator mode if sufficient (never fail settlement if external simulator wallet paid)
      if (event.provider === 'simulator') {
        db.prepare(
          `UPDATE users
           SET demo_balance_sats = MAX(0, demo_balance_sats - ?)
           WHERE id = ?`
        ).run(Number(intent.total_sats), intent.user_id as string);
      }
    }

    if (wasExpired) {
      db.prepare(
        `INSERT INTO audit_logs (id, actor_user_id, action, entity_type, entity_id, details_json, created_at)
         VALUES (?, ?, 'late_settlement_reconciliation_required', 'payment_intent', ?, ?, ?)`
      ).run(
        `aud_${crypto.randomUUID()}`,
        intent.user_id as string,
        event.paymentIntentId,
        JSON.stringify({ reason: 'Settlement arrived after invoice expiry; queued for reconciliation' }),
        now
      );
      return { duplicate: false, outcome: 'late_settlement_reconciliation_required' };
    }

    // Simulated temporary fulfillment failure path (Demo step 14)
    if (Boolean(intent.simulate_fulfillment_failure)) {
      db.prepare(
        `UPDATE payment_intents SET fulfillment_status = 'failed_retryable' WHERE id = ?`
      ).run(event.paymentIntentId);
      db.prepare(
        `INSERT INTO audit_logs (id, actor_user_id, action, entity_type, entity_id, details_json, created_at)
         VALUES (?, ?, 'fulfillment_temporary_failure', 'payment_intent', ?, ?, ?)`
      ).run(
        `aud_${crypto.randomUUID()}`,
        intent.user_id as string,
        event.paymentIntentId,
        JSON.stringify({
          reason: 'Simulated transient entitlement worker failure after settlement; payment retained for retry',
        }),
        now
      );
      return { duplicate: false, outcome: 'settled_fulfillment_pending_retry' };
    }

    fulfillSettledIntentTx(db, event.paymentIntentId, now);
    return { duplicate: false, outcome: 'settled_and_fulfilled' };
  });

  const updated = getPaymentIntentById(event.paymentIntentId);
  if (!updated) throw new Error('Payment intent vanished');
  return {
    duplicate: outcome.duplicate,
    intent: updated,
    outcome: outcome.outcome,
  };
}

/**
 * Idempotent fulfillment helper called inside an active transaction.
 */
function fulfillSettledIntentTx(
  db: ReturnType<typeof getDb>,
  paymentIntentId: string,
  now: string
) {
  const intent = db
    .prepare(`SELECT * FROM payment_intents WHERE id = ?`)
    .get(paymentIntentId) as Record<string, unknown>;

  if (intent.kind === 'article_purchase') {
    const existingPurchase = db
      .prepare(`SELECT id FROM purchases WHERE payment_intent_id = ?`)
      .get(paymentIntentId) as { id: string } | undefined;

    let purchaseId = existingPurchase?.id;
    if (!purchaseId) {
      purchaseId = `pur_${crypto.randomUUID()}`;
      db.prepare(
        `INSERT INTO purchases (
          id, user_id, article_id, offer_id, revision_id, payment_intent_id,
          price_sats, customer_fee_sats, total_sats, commission_sats, author_payable_sats,
          fee_policy_version, includes_future_revisions, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)`
      ).run(
        purchaseId,
        intent.user_id as string,
        intent.article_id as string,
        intent.offer_id as string,
        intent.revision_id as string,
        paymentIntentId,
        Number(intent.amount_sats),
        Number(intent.customer_fee_sats),
        Number(intent.total_sats),
        Number(intent.commission_sats),
        Number(intent.author_payable_sats),
        intent.fee_policy_version as string,
        Number(intent.includes_future_revisions),
        now
      );
    }

    // Grant durable entitlement (unique on user_id + article_id)
    db.prepare(
      `INSERT INTO entitlements (
        id, user_id, article_id, purchase_id, locked_revision_id, includes_future_revisions, granted_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(user_id, article_id) DO UPDATE SET
        purchase_id = excluded.purchase_id,
        revoked_at = NULL`
    ).run(
      `ent_${crypto.randomUUID()}`,
      intent.user_id as string,
      intent.article_id as string,
      purchaseId,
      intent.revision_id as string,
      Number(intent.includes_future_revisions),
      now
    );
  } else if (intent.kind === 'author_tip') {
    const existingTip = db
      .prepare(`SELECT id FROM tips WHERE payment_intent_id = ?`)
      .get(paymentIntentId);
    if (!existingTip) {
      db.prepare(
        `INSERT INTO tips (
          id, user_id, recipient_user_id, article_id, payment_intent_id,
          amount_sats, commission_sats, author_payable_sats, note, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, '', 'settled', ?)`
      ).run(
        `tip_${crypto.randomUUID()}`,
        intent.user_id as string,
        intent.recipient_user_id as string,
        (intent.article_id as string) || null,
        paymentIntentId,
        Number(intent.amount_sats),
        Number(intent.commission_sats),
        Number(intent.author_payable_sats),
        now
      );
    }
  }

  // Record author_payable and platform_revenue once per intent
  const existingPayable = db
    .prepare(
      `SELECT id FROM ledger_entries WHERE payment_intent_id = ? AND entry_type = 'author_payable'`
    )
    .get(paymentIntentId);

  if (!existingPayable) {
    db.prepare(
      `INSERT INTO ledger_entries (
        id, entry_type, user_id, article_id, payment_intent_id, related_id,
        amount_sats, direction, description, is_demo, created_at
      ) VALUES (?, 'author_payable', ?, ?, ?, ?, ?, 'credit', ?, 1, ?)`
    ).run(
      `led_${crypto.randomUUID()}`,
      intent.recipient_user_id as string,
      (intent.article_id as string) || null,
      paymentIntentId,
      paymentIntentId,
      Number(intent.author_payable_sats),
      intent.kind === 'author_tip'
        ? 'Author payable from reader tip'
        : 'Author payable from article purchase',
      now
    );

    if (Number(intent.commission_sats) > 0) {
      db.prepare(
        `INSERT INTO ledger_entries (
          id, entry_type, user_id, article_id, payment_intent_id, related_id,
          amount_sats, direction, description, is_demo, created_at
        ) VALUES (?, 'platform_revenue', NULL, ?, ?, ?, ?, 'credit', ?, 1, ?)`
      ).run(
        `led_${crypto.randomUUID()}`,
        (intent.article_id as string) || null,
        paymentIntentId,
        paymentIntentId,
        Number(intent.commission_sats),
        `Platform commission (${intent.fee_policy_version})`,
        now
      );
    }
  }

  db.prepare(
    `UPDATE payment_intents
     SET status = 'settled', fulfillment_status = 'fulfilled', simulate_fulfillment_failure = 0
     WHERE id = ?`
  ).run(paymentIntentId);

  db.prepare(
    `UPDATE lightning_invoices SET status = 'settled' WHERE payment_intent_id = ?`
  ).run(paymentIntentId);
}

/**
 * Reconciles any settled or late-settled payment intents whose fulfillment is still pending/failed.
 */
export function reconcilePendingFulfillments(actorUserId?: string): {
  recoveredCount: number;
  recoveredIds: string[];
} {
  const db = getDb();
  const candidates = db
    .prepare(
      `SELECT id FROM payment_intents
       WHERE (status = 'settled' AND fulfillment_status IN ('pending', 'failed_retryable'))
          OR status = 'reconciliation_required'`
    )
    .all() as { id: string }[];

  const recoveredIds: string[] = [];
  const now = new Date().toISOString();

  for (const c of candidates) {
    withTransaction(db, () => {
      fulfillSettledIntentTx(db, c.id, now);
      db.prepare(
        `INSERT INTO audit_logs (id, actor_user_id, action, entity_type, entity_id, details_json, created_at)
         VALUES (?, ?, 'reconcile_entitlement', 'payment_intent', ?, ?, ?)`
      ).run(
        `aud_${crypto.randomUUID()}`,
        actorUserId || null,
        c.id,
        JSON.stringify({ recovered: true }),
        now
      );
    });
    recoveredIds.push(c.id);
  }

  return { recoveredCount: recoveredIds.length, recoveredIds };
}

/**
 * Queries a live external provider if configured (LNbits) to confirm status server-side.
 */
export async function pollExternalInvoiceStatus(paymentIntentId: string): Promise<PaymentIntentRecord | null> {
  const intent = getPaymentIntentById(paymentIntentId);
  if (!intent || !intent.invoice) return intent;
  if (intent.status === 'settled' || intent.provider === 'simulator') {
    return intent;
  }
  const provider = getPaymentProviderByName(intent.provider);
  const status = await provider.getInvoiceStatus(intent.invoice.provider_invoice_id);
  if (status.status === 'settled') {
    const result = processVerifiedProviderEvent({
      provider: status.provider,
      providerAccount: status.providerAccount,
      providerEventId: `poll_${status.providerInvoiceId}`,
      providerInvoiceId: status.providerInvoiceId,
      paymentHash: status.paymentHash,
      paymentIntentId: intent.id,
      amountSats: status.amountSats,
      status: 'settled',
      occurredAt: status.settledAt || new Date().toISOString(),
    });
    return result.intent;
  }
  return intent;
}

export function getAuthorStatement(authorUserId: string) {
  const db = getDb();
  const purchaseStats = db
    .prepare(
      `SELECT COUNT(*) AS count,
              COALESCE(SUM(total_sats), 0) AS gross_sats,
              COALESCE(SUM(commission_sats), 0) AS commission_sats,
              COALESCE(SUM(author_payable_sats), 0) AS net_sats
       FROM purchases p
       JOIN articles a ON a.id = p.article_id
       WHERE a.author_user_id = ? AND p.status = 'active'`
    )
    .get(authorUserId) as {
    count: number;
    gross_sats: number;
    commission_sats: number;
    net_sats: number;
  };

  const tipStats = db
    .prepare(
      `SELECT COUNT(*) AS count,
              COALESCE(SUM(amount_sats), 0) AS gross_sats,
              COALESCE(SUM(author_payable_sats), 0) AS net_sats
       FROM tips
       WHERE recipient_user_id = ? AND status = 'settled'`
    )
    .get(authorUserId) as {
    count: number;
    gross_sats: number;
    net_sats: number;
  };

  const refundStats = db
    .prepare(
      `SELECT COUNT(*) AS count, COALESCE(SUM(p.author_payable_sats), 0) AS refunded_author_sats,
              COALESCE(SUM(p.total_sats), 0) AS refunded_gross_sats
       FROM purchases p
       JOIN articles a ON a.id = p.article_id
       WHERE a.author_user_id = ? AND p.status = 'refunded'`
    )
    .get(authorUserId) as {
    count: number;
    refunded_author_sats: number;
    refunded_gross_sats: number;
  };

  const payoutStats = db
    .prepare(
      `SELECT COALESCE(SUM(CASE WHEN status = 'completed' THEN amount_sats ELSE 0 END), 0) AS paid_out_sats,
              COALESCE(SUM(CASE WHEN status IN ('requested', 'pending_reconciliation') THEN amount_sats ELSE 0 END), 0) AS pending_payout_sats
       FROM payouts
       WHERE author_user_id = ?`
    )
    .get(authorUserId) as {
    paid_out_sats: number;
    pending_payout_sats: number;
  };

  const totalEarnedSats = Number(purchaseStats.net_sats) + Number(tipStats.net_sats);
  const availablePayableSats = Math.max(
    0,
    totalEarnedSats - Number(payoutStats.paid_out_sats) - Number(payoutStats.pending_payout_sats)
  );

  const recentPurchases = db
    .prepare(
      `SELECT p.id, p.total_sats, p.commission_sats, p.author_payable_sats, p.fee_policy_version, p.status, p.created_at,
              r.title AS article_title, a.slug AS article_slug, u.display_name AS reader_name
       FROM purchases p
       JOIN articles a ON a.id = p.article_id
       JOIN article_revisions r ON r.id = p.revision_id
       JOIN users u ON u.id = p.user_id
       WHERE a.author_user_id = ?
       ORDER BY p.created_at DESC
       LIMIT 30`
    )
    .all(authorUserId);

  const recentTips = db
    .prepare(
      `SELECT t.id, t.amount_sats, t.author_payable_sats, t.note, t.created_at,
              u.display_name AS reader_name, r.title AS article_title
       FROM tips t
       JOIN users u ON u.id = t.user_id
       LEFT JOIN articles a ON a.id = t.article_id
       LEFT JOIN article_revisions r ON r.id = a.current_revision_id
       WHERE t.recipient_user_id = ?
       ORDER BY t.created_at DESC
       LIMIT 30`
    )
    .all(authorUserId);

  const payouts = db
    .prepare(`SELECT * FROM payouts WHERE author_user_id = ? ORDER BY created_at DESC LIMIT 30`)
    .all(authorUserId);

  return {
    is_demo: true,
    accounting_model: 'platform_collection',
    currency: 'sats',
    article_purchases_count: Number(purchaseStats.count),
    article_purchases_gross_sats: Number(purchaseStats.gross_sats),
    platform_commission_sats: Number(purchaseStats.commission_sats),
    article_purchases_net_sats: Number(purchaseStats.net_sats),
    settled_tips_count: Number(tipStats.count),
    settled_tips_sats: Number(tipStats.net_sats),
    refunds_count: Number(refundStats.count),
    refunded_gross_sats: Number(refundStats.refunded_gross_sats),
    paid_out_sats: Number(payoutStats.paid_out_sats),
    pending_payout_sats: Number(payoutStats.pending_payout_sats),
    amount_payable_sats: availablePayableSats,
    recent_purchases: recentPurchases,
    recent_tips: recentTips,
    payouts,
  };
}

export function createRefundRequest(params: {
  purchaseId: string;
  userId: string;
  reason: string;
}) {
  const db = getDb();
  const purchase = db
    .prepare(`SELECT * FROM purchases WHERE id = ? AND user_id = ?`)
    .get(params.purchaseId, params.userId) as Record<string, unknown> | undefined;

  if (!purchase) {
    throw new Error('Purchase not found for this account');
  }
  if (purchase.status === 'refunded') {
    throw new Error('This purchase has already been refunded');
  }

  const existing = db
    .prepare(`SELECT id FROM refund_requests WHERE purchase_id = ?`)
    .get(params.purchaseId);
  if (existing) {
    throw new Error('A refund request already exists for this purchase');
  }

  const id = `ref_${crypto.randomUUID()}`;
  const now = new Date().toISOString();
  withTransaction(db, () => {
    db.prepare(
      `INSERT INTO refund_requests (
        id, purchase_id, requester_user_id, requested_amount_sats, reason, status, created_at
      ) VALUES (?, ?, ?, ?, ?, 'pending_review', ?)`
    ).run(
      id,
      params.purchaseId,
      params.userId,
      Number(purchase.total_sats),
      params.reason.trim().slice(0, 500),
      now
    );
    db.prepare(
      `INSERT INTO audit_logs (id, actor_user_id, action, entity_type, entity_id, details_json, created_at)
       VALUES (?, ?, 'request_refund', 'refund_request', ?, ?, ?)`
    ).run(
      `aud_${crypto.randomUUID()}`,
      params.userId,
      id,
      JSON.stringify({ purchase_id: params.purchaseId, amount_sats: Number(purchase.total_sats) }),
      now
    );
  });

  return db.prepare(`SELECT * FROM refund_requests WHERE id = ?`).get(id);
}

export function reviewRefundRequest(params: {
  refundId: string;
  reviewerUserId: string;
  decision: 'approve' | 'reject';
  note?: string;
}) {
  const db = getDb();
  const reqRow = db
    .prepare(`SELECT * FROM refund_requests WHERE id = ?`)
    .get(params.refundId) as Record<string, unknown> | undefined;

  if (!reqRow) throw new Error('Refund request not found');
  if (reqRow.status !== 'pending_review') {
    throw new Error('Refund request has already been resolved');
  }

  const purchase = db
    .prepare(`SELECT * FROM purchases WHERE id = ?`)
    .get(reqRow.purchase_id as string) as Record<string, unknown>;

  const now = new Date().toISOString();
  withTransaction(db, () => {
    if (params.decision === 'reject') {
      db.prepare(
        `UPDATE refund_requests
         SET status = 'rejected', reviewer_user_id = ?, resolution_note = ?, resolved_at = ?
         WHERE id = ?`
      ).run(params.reviewerUserId, (params.note || 'Rejected by moderation review').slice(0, 300), now, params.refundId);
      return;
    }

    const cappedAmount = Math.min(
      Number(reqRow.requested_amount_sats),
      Number(purchase.total_sats)
    );
    const outgoingRef = `sim_refund_${crypto.randomUUID().slice(0, 12)}`;

    db.prepare(`UPDATE purchases SET status = 'refunded' WHERE id = ?`).run(
      purchase.id as string
    );
    db.prepare(
      `UPDATE entitlements SET revoked_at = ? WHERE purchase_id = ?`
    ).run(now, purchase.id as string);

    db.prepare(
      `UPDATE users SET demo_balance_sats = demo_balance_sats + ? WHERE id = ?`
    ).run(cappedAmount, purchase.user_id as string);

    db.prepare(
      `INSERT INTO ledger_entries (
        id, entry_type, user_id, article_id, payment_intent_id, related_id,
        amount_sats, direction, description, is_demo, created_at
      ) VALUES (?, 'refund', ?, ?, ?, ?, ?, 'debit', ?, 1, ?)`
    ).run(
      `led_${crypto.randomUUID()}`,
      purchase.user_id as string,
      purchase.article_id as string,
      purchase.payment_intent_id as string,
      params.refundId,
      cappedAmount,
      `Reviewed refund outgoing credit (${outgoingRef})`,
      now
    );

    db.prepare(
      `UPDATE refund_requests
       SET status = 'approved_settled', reviewer_user_id = ?, resolution_note = ?, outgoing_reference = ?, resolved_at = ?
       WHERE id = ?`
    ).run(
      params.reviewerUserId,
      (params.note || 'Approved and refunded via separate outgoing simulator transfer').slice(0, 300),
      outgoingRef,
      now,
      params.refundId
    );

    db.prepare(
      `INSERT INTO audit_logs (id, actor_user_id, action, entity_type, entity_id, details_json, created_at)
       VALUES (?, ?, 'approve_refund', 'refund_request', ?, ?, ?)`
    ).run(
      `aud_${crypto.randomUUID()}`,
      params.reviewerUserId,
      params.refundId,
      JSON.stringify({ outgoing_reference: outgoingRef, amount_sats: cappedAmount }),
      now
    );
  });

  return db.prepare(`SELECT * FROM refund_requests WHERE id = ?`).get(params.refundId);
}

export async function requestAuthorPayout(params: {
  authorUserId: string;
  destination: string;
  amountSats: number;
  idempotencyKey: string;
}) {
  const db = getDb();
  if (!Number.isInteger(params.amountSats)) {
    throw new Error('Payout amount must be an integer in sats');
  }
  if (params.amountSats < MIN_PAYOUT_SATS || params.amountSats > MAX_SINGLE_PAYOUT_SATS) {
    throw new Error(
      `Payout amount must be between ${MIN_PAYOUT_SATS} and ${MAX_SINGLE_PAYOUT_SATS} sats`
    );
  }
  if (!validateLightningDestination(params.destination)) {
    throw new Error('Destination must be a valid Lightning Address (user@domain) or LNURL');
  }

  const existingIdempotent = db
    .prepare(`SELECT * FROM payouts WHERE idempotency_key = ?`)
    .get(params.idempotencyKey);
  if (existingIdempotent) {
    return existingIdempotent;
  }

  const statement = getAuthorStatement(params.authorUserId);
  if (params.amountSats > statement.amount_payable_sats) {
    throw new Error(
      `Requested ${params.amountSats} sats exceeds available payable balance (${statement.amount_payable_sats} sats)`
    );
  }

  const payoutId = `po_${crypto.randomUUID()}`;
  const now = new Date().toISOString();

  withTransaction(db, () => {
    db.prepare(
      `INSERT INTO payouts (
        id, author_user_id, idempotency_key, destination, amount_sats,
        network_fee_sats, provider, status, message, created_at
      ) VALUES (?, ?, ?, ?, ?, 0, 'simulator_payout', 'requested', 'Queued for payout adapter', ?)`
    ).run(
      payoutId,
      params.authorUserId,
      params.idempotencyKey,
      params.destination.trim(),
      params.amountSats,
      now
    );
  });

  const adapter = new DeterministicSimulatorPayoutAdapter();
  const result = await adapter.executePayout({
    payoutId,
    idempotencyKey: params.idempotencyKey,
    destination: params.destination.trim(),
    amountSats: params.amountSats,
    memo: 'Lumen author earnings payout',
  });

  const completedAt = result.status === 'completed' ? new Date().toISOString() : null;
  withTransaction(db, () => {
    db.prepare(
      `UPDATE payouts
       SET status = ?, provider_payout_id = ?, network_fee_sats = ?, message = ?, completed_at = ?
       WHERE id = ?`
    ).run(
      result.status,
      result.providerPayoutId,
      result.networkFeeSats,
      result.message,
      completedAt,
      payoutId
    );

    if (result.status === 'completed') {
      db.prepare(
        `INSERT INTO ledger_entries (
          id, entry_type, user_id, article_id, payment_intent_id, related_id,
          amount_sats, direction, description, is_demo, created_at
        ) VALUES (?, 'payout', ?, NULL, NULL, ?, ?, 'debit', ?, 1, ?)`
      ).run(
        `led_${crypto.randomUUID()}`,
        params.authorUserId,
        payoutId,
        params.amountSats,
        `Author payout to ${params.destination.trim()}`,
        completedAt
      );
    }

    db.prepare(
      `INSERT INTO audit_logs (id, actor_user_id, action, entity_type, entity_id, details_json, created_at)
       VALUES (?, ?, 'execute_payout', 'payout', ?, ?, ?)`
    ).run(
      `aud_${crypto.randomUUID()}`,
      params.authorUserId,
      payoutId,
      JSON.stringify({
        status: result.status,
        amount_sats: params.amountSats,
        provider_payout_id: result.providerPayoutId,
      }),
      new Date().toISOString()
    );
  });

  return db.prepare(`SELECT * FROM payouts WHERE id = ?`).get(payoutId);
}

export async function reconcilePayout(payoutId: string, actorUserId: string) {
  const db = getDb();
  const payout = db.prepare(`SELECT * FROM payouts WHERE id = ?`).get(payoutId) as
    | Record<string, unknown>
    | undefined;
  if (!payout) throw new Error('Payout not found');
  if (payout.status !== 'pending_reconciliation') {
    return payout;
  }
  const adapter = new DeterministicSimulatorPayoutAdapter();
  const res = await adapter.reconcilePayout((payout.provider_payout_id as string) || payoutId);
  const now = new Date().toISOString();

  withTransaction(db, () => {
    db.prepare(
      `UPDATE payouts
       SET status = ?, network_fee_sats = ?, message = ?, completed_at = ?
       WHERE id = ?`
    ).run(res.status, res.networkFeeSats, res.message, now, payoutId);

    if (res.status === 'completed') {
      db.prepare(
        `INSERT INTO ledger_entries (
          id, entry_type, user_id, article_id, payment_intent_id, related_id,
          amount_sats, direction, description, is_demo, created_at
        ) VALUES (?, 'payout', ?, NULL, NULL, ?, ?, 'debit', ?, 1, ?)`
      ).run(
        `led_${crypto.randomUUID()}`,
        payout.author_user_id as string,
        payoutId,
        Number(payout.amount_sats),
        `Reconciled author payout to ${payout.destination as string}`,
        now
      );
    }

    db.prepare(
      `INSERT INTO audit_logs (id, actor_user_id, action, entity_type, entity_id, details_json, created_at)
       VALUES (?, ?, 'reconcile_payout', 'payout', ?, ?, ?)`
    ).run(
      `aud_${crypto.randomUUID()}`,
      actorUserId,
      payoutId,
      JSON.stringify({ status: res.status }),
      now
    );
  });

  return db.prepare(`SELECT * FROM payouts WHERE id = ?`).get(payoutId);
}
