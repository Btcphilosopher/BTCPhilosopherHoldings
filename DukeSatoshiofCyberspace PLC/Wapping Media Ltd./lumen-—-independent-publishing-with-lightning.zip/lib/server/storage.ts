import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const DATA_DIR = path.resolve(process.cwd(), process.env.LUMEN_DATA_DIR || './data');
const MEDIA_DIR = path.resolve(DATA_DIR, 'media');

const ALLOWED_IMAGE_MIMES = new Map<string, string>([
  ['image/png', '.png'],
  ['image/jpeg', '.jpg'],
  ['image/webp', '.webp'],
]);

const MAX_UPLOAD_BYTES = 2 * 1024 * 1024; // 2 MB strict upload cap

function ensureMediaDir() {
  if (!fs.existsSync(MEDIA_DIR)) {
    fs.mkdirSync(MEDIA_DIR, { recursive: true });
  }
}

function verifyMagicBytes(buffer: Buffer, mimeType: string): boolean {
  if (buffer.length < 12) return false;
  if (mimeType === 'image/png') {
    return (
      buffer[0] === 0x89 &&
      buffer[1] === 0x50 &&
      buffer[2] === 0x4e &&
      buffer[3] === 0x47
    );
  }
  if (mimeType === 'image/jpeg') {
    return buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
  }
  if (mimeType === 'image/webp') {
    return (
      buffer.subarray(0, 4).toString('ascii') === 'RIFF' &&
      buffer.subarray(8, 12).toString('ascii') === 'WEBP'
    );
  }
  return false;
}

export interface StoredMediaResult {
  objectKey: string;
  publicUrl: string;
  mimeType: string;
  sizeBytes: number;
  sha256: string;
}

export async function storeMediaUpload(
  fileBuffer: Buffer,
  mimeType: string
): Promise<StoredMediaResult> {
  const ext = ALLOWED_IMAGE_MIMES.get(mimeType);
  if (!ext) {
    throw new Error('Only PNG, JPEG, and WebP images are permitted');
  }
  if (fileBuffer.length === 0 || fileBuffer.length > MAX_UPLOAD_BYTES) {
    throw new Error('Image size must be between 1 byte and 2 MB');
  }
  if (!verifyMagicBytes(fileBuffer, mimeType)) {
    throw new Error('File contents do not match declared image MIME type');
  }

  ensureMediaDir();
  const sha256 = crypto.createHash('sha256').update(fileBuffer).digest('hex');
  const id = crypto.randomUUID();
  const objectKey = `${id}${ext}`;
  const targetPath = path.resolve(MEDIA_DIR, objectKey);

  // Strict path confinement check
  if (!targetPath.startsWith(MEDIA_DIR + path.sep)) {
    throw new Error('Invalid storage key path');
  }

  fs.writeFileSync(targetPath, fileBuffer);

  return {
    objectKey,
    publicUrl: `/api/v1/media/${objectKey}`,
    mimeType,
    sizeBytes: fileBuffer.length,
    sha256,
  };
}

export function readStoredMedia(objectKey: string): { buffer: Buffer; mimeType: string } | null {
  if (!/^[a-f0-9-]+\.(png|jpg|webp)$/i.test(objectKey)) {
    return null;
  }
  ensureMediaDir();
  const targetPath = path.resolve(MEDIA_DIR, objectKey);
  if (!targetPath.startsWith(MEDIA_DIR + path.sep) || !fs.existsSync(targetPath)) {
    return null;
  }
  const ext = path.extname(objectKey).toLowerCase();
  const mimeType =
    ext === '.png' ? 'image/png' : ext === '.jpg' ? 'image/jpeg' : 'image/webp';
  return {
    buffer: fs.readFileSync(targetPath),
    mimeType,
  };
}
