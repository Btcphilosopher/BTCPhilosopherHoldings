import crypto from 'node:crypto';
import { cookies } from 'next/headers';
import { NextRequest } from 'next/server';

const globalForCrypto = globalThis as unknown as {
  __lumenEphemeralSecret?: string;
};

function getSessionSecret(): string {
  if (process.env.LUMEN_SESSION_SECRET && process.env.LUMEN_SESSION_SECRET.length >= 16) {
    return process.env.LUMEN_SESSION_SECRET;
  }
  if (!globalForCrypto.__lumenEphemeralSecret) {
    globalForCrypto.__lumenEphemeralSecret = crypto.randomBytes(32).toString('hex');
  }
  return globalForCrypto.__lumenEphemeralSecret;
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt:${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
  const [, salt, originalHex] = parts;
  const derived = crypto.scryptSync(password, salt, 64);
  const original = Buffer.from(originalHex, 'hex');
  if (derived.length !== original.length) return false;
  return crypto.timingSafeEqual(derived, original);
}

export interface SessionPayload {
  userId: string;
  role: 'reader' | 'author' | 'admin';
  exp: number;
}

export function signSessionToken(payload: Omit<SessionPayload, 'exp'>, ttlSeconds = 60 * 60 * 24 * 7): string {
  const full: SessionPayload = {
    ...payload,
    exp: Math.floor(Date.now() / 1000) + ttlSeconds,
  };
  const encoded = Buffer.from(JSON.stringify(full), 'utf8').toString('base64url');
  const sig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(encoded)
    .digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifySessionToken(token: string | undefined | null): SessionPayload | null {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  const expectedSig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(encoded)
    .digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expectedBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
    return null;
  }
  try {
    const parsed = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as SessionPayload;
    if (!parsed.userId || !parsed.exp || parsed.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export const SESSION_COOKIE_NAME = 'lumen_session';

export async function getSessionFromRequest(req?: NextRequest): Promise<SessionPayload | null> {
  if (req) {
    const authHeader = req.headers.get('authorization');
    if (authHeader && authHeader.toLowerCase().startsWith('bearer ')) {
      const bearer = authHeader.slice(7).trim();
      const verified = verifySessionToken(bearer);
      if (verified) return verified;
    }
    const cookieVal = req.cookies.get(SESSION_COOKIE_NAME)?.value;
    if (cookieVal) return verifySessionToken(cookieVal);
  }
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value;
  return verifySessionToken(token);
}

/**
 * CSRF & Same-Origin guard for cookie-authenticated mutations.
 */
export function verifyMutationOrigin(req: NextRequest): boolean {
  const origin = req.headers.get('origin');
  const xRequestedWith = req.headers.get('x-requested-with');
  if (xRequestedWith === 'lumen-ui') return true;
  if (!origin) return true; // Same-origin server calls or curl tests with explicit cookie
  try {
    const originHost = new URL(origin).host;
    const forwardedHost = req.headers.get('x-forwarded-host') || req.headers.get('host');
    if (!forwardedHost) return true;
    return originHost === forwardedHost;
  } catch {
    return false;
  }
}

/**
 * Simple sliding-window rate limiter to prevent invoice-creation & auth abuse.
 */
const globalRateState = globalThis as unknown as {
  __lumenRateBuckets?: Map<string, number[]>;
};

export function checkRateLimit(key: string, maxRequests: number, windowMs: number): boolean {
  if (!globalRateState.__lumenRateBuckets) {
    globalRateState.__lumenRateBuckets = new Map();
  }
  const now = Date.now();
  const timestamps = (globalRateState.__lumenRateBuckets.get(key) || []).filter(
    (ts) => now - ts < windowMs
  );
  if (timestamps.length >= maxRequests) {
    globalRateState.__lumenRateBuckets.set(key, timestamps);
    return false;
  }
  timestamps.push(now);
  globalRateState.__lumenRateBuckets.set(key, timestamps);
  return true;
}

export function redactSensitiveForLogs(obj: Record<string, unknown>): Record<string, unknown> {
  const redacted: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    const lower = k.toLowerCase();
    if (
      lower.includes('secret') ||
      lower.includes('password') ||
      lower.includes('token') ||
      lower.includes('bolt11') ||
      lower.includes('preimage')
    ) {
      redacted[k] = '[REDACTED]';
    } else {
      redacted[k] = v;
    }
  }
  return redacted;
}
