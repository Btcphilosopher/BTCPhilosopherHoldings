import { ContentBlock, TextRun } from './types';

const ALLOWED_LINK_PROTOCOLS = new Set(['http:', 'https:']);

/**
 * Strips raw HTML tags and unsafe URL schemes from untrusted editorial input.
 * Content is always parsed into structured AST blocks (never rendered via innerHTML).
 */
export function stripDangerousHtml(raw: string): string {
  return raw
    .replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?>[\s\S]*?<\/style>/gi, '')
    .replace(/<iframe[\s\S]*?>[\s\S]*?<\/iframe>/gi, '')
    .replace(/<object[\s\S]*?>[\s\S]*?<\/object>/gi, '')
    .replace(/<embed[\s\S]*?>/gi, '')
    .replace(/<[^>]+>/g, '');
}

export function validateSafeUrl(rawUrl: string, allowRelative = true): string | null {
  const trimmed = rawUrl.trim();
  if (!trimmed) return null;
  if (allowRelative && trimmed.startsWith('/') && !trimmed.startsWith('//')) {
    return trimmed;
  }
  try {
    const parsed = new URL(trimmed);
    if (ALLOWED_LINK_PROTOCOLS.has(parsed.protocol)) {
      return parsed.toString();
    }
    return null;
  } catch {
    return null;
  }
}

export function parseInlineRuns(text: string): TextRun[] {
  const cleaned = stripDangerousHtml(text);
  const runs: TextRun[] = [];
  // Match links [label](url), bold **text**, italic *text*, inline code `code`
  const tokenRegex = /\[([^\]]+)\]\(([^)]+)\)|\*\*([^*]+)\*\*|\*([^*]+)\*|`([^`]+)`/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = tokenRegex.exec(cleaned)) !== null) {
    if (match.index > lastIndex) {
      runs.push({ text: cleaned.slice(lastIndex, match.index) });
    }
    if (match[1] !== undefined && match[2] !== undefined) {
      const safeHref = validateSafeUrl(match[2], true);
      if (safeHref) {
        runs.push({ text: match[1], link: safeHref });
      } else {
        runs.push({ text: match[1] });
      }
    } else if (match[3] !== undefined) {
      runs.push({ text: match[3], bold: true });
    } else if (match[4] !== undefined) {
      runs.push({ text: match[4], italic: true });
    } else if (match[5] !== undefined) {
      runs.push({ text: match[5], code: true });
    }
    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < cleaned.length) {
    runs.push({ text: cleaned.slice(lastIndex) });
  }

  return runs.length > 0 ? runs : [{ text: cleaned }];
}

export function parseSafeMarkdown(markdown: string): ContentBlock[] {
  const safeText = stripDangerousHtml(markdown).replace(/\r\n/g, '\n');
  const lines = safeText.split('\n');
  const blocks: ContentBlock[] = [];

  let i = 0;
  while (i < lines.length) {
    const line = lines[i].trim();
    if (!line) {
      i++;
      continue;
    }

    // Headings
    if (line.startsWith('### ')) {
      blocks.push({
        type: 'heading',
        level: 3,
        text: line.slice(4).trim(),
        runs: parseInlineRuns(line.slice(4).trim()),
      });
      i++;
      continue;
    }
    if (line.startsWith('## ') || line.startsWith('# ')) {
      const content = line.replace(/^#{1,2}\s+/, '').trim();
      blocks.push({
        type: 'heading',
        level: 2,
        text: content,
        runs: parseInlineRuns(content),
      });
      i++;
      continue;
    }

    // Image: ![alt](url "caption")
    const imgMatch = line.match(/^!\[([^\]]*)\]\(([^\s)]+)(?:\s+"([^"]*)")?\)$/);
    if (imgMatch) {
      const safeUrl = validateSafeUrl(imgMatch[2], true);
      if (safeUrl) {
        blocks.push({
          type: 'image',
          url: safeUrl,
          alt: imgMatch[1].trim() || 'Editorial figure',
          caption: imgMatch[3]?.trim() || undefined,
        });
      }
      i++;
      continue;
    }

    // Blockquote
    if (line.startsWith('> ')) {
      const quoteLines: string[] = [];
      while (i < lines.length && lines[i].trim().startsWith('> ')) {
        quoteLines.push(lines[i].trim().slice(2).trim());
        i++;
      }
      const joined = quoteLines.join(' ');
      blocks.push({
        type: 'quote',
        text: joined,
        runs: parseInlineRuns(joined),
      });
      continue;
    }

    // Unordered list
    if (line.startsWith('- ') || line.startsWith('* ')) {
      const items: string[] = [];
      while (
        i < lines.length &&
        (lines[i].trim().startsWith('- ') || lines[i].trim().startsWith('* '))
      ) {
        items.push(lines[i].trim().slice(2).trim());
        i++;
      }
      blocks.push({ type: 'list', ordered: false, items });
      continue;
    }

    // Ordered list
    if (/^\d+\.\s+/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\d+\.\s+/.test(lines[i].trim())) {
        items.push(lines[i].trim().replace(/^\d+\.\s+/, '').trim());
        i++;
      }
      blocks.push({ type: 'list', ordered: true, items });
      continue;
    }

    // Paragraph (coalesce contiguous non-special lines)
    const paraLines: string[] = [line];
    i++;
    while (i < lines.length) {
      const next = lines[i].trim();
      if (
        !next ||
        next.startsWith('#') ||
        next.startsWith('> ') ||
        next.startsWith('- ') ||
        next.startsWith('* ') ||
        /^\d+\.\s+/.test(next) ||
        /^!\[/.test(next)
      ) {
        break;
      }
      paraLines.push(next);
      i++;
    }
    const paraText = paraLines.join(' ');
    blocks.push({
      type: 'paragraph',
      text: paraText,
      runs: parseInlineRuns(paraText),
    });
  }

  return blocks;
}

export function extractPreviewParagraphs(
  markdown: string,
  previewParagraphCount: number
): string[] {
  const blocks = parseSafeMarkdown(markdown);
  const paragraphs = blocks
    .filter((b) => b.type === 'paragraph' && b.text)
    .map((b) => b.text as string);
  const count = Math.max(1, Math.min(previewParagraphCount, 6));
  return paragraphs.slice(0, count);
}

export function estimateReadingMinutes(markdown: string): number {
  const words = stripDangerousHtml(markdown)
    .trim()
    .split(/\s+/)
    .filter(Boolean).length;
  return Math.max(2, Math.ceil(words / 210));
}
