export type LifecycleStatus =
  | 'draft'
  | 'preview'
  | 'published'
  | 'revised'
  | 'withdrawn';

export type TopicSlug =
  | 'technology'
  | 'culture'
  | 'science'
  | 'economics'
  | 'design';

export type InvoiceStatus =
  | 'created'
  | 'awaiting_payment'
  | 'settled'
  | 'expired'
  | 'cancelled'
  | 'reconciliation_required';

export type PaymentIntentKind = 'article_purchase' | 'author_tip';

export type LedgerEntryType =
  | 'customer_payment'
  | 'author_payable'
  | 'platform_revenue'
  | 'provider_charge'
  | 'network_fee'
  | 'refund'
  | 'payout';

export interface User {
  id: string;
  email: string;
  display_name: string;
  handle: string;
  role: 'reader' | 'author' | 'admin';
  demo_balance_sats: number;
  created_at: string;
}

export interface AuthorProfile {
  user_id: string;
  handle: string;
  display_name: string;
  bio: string;
  publication_name: string;
  lightning_destination: string | null;
  destination_verified: boolean;
  followers_count?: number;
}

export interface Publication {
  id: string;
  owner_user_id: string;
  slug: string;
  name: string;
  tagline: string;
  created_at: string;
}

export interface ArticleOffer {
  id: string;
  article_id: string;
  is_paid: boolean;
  price_sats: number;
  customer_fee_sats: number;
  commission_bps: number;
  fee_policy_version: string;
  includes_future_revisions: boolean;
  refund_terms: string;
  created_at: string;
}

export interface ArticleSummary {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  topic: TopicSlug;
  status: LifecycleStatus;
  cover_image_url: string;
  cover_image_alt: string;
  reading_time_minutes: number;
  featured_rank: number | null;
  published_at: string | null;
  updated_at: string;
  author: {
    id: string;
    handle: string;
    display_name: string;
    publication_name: string;
    bio: string;
  };
  offer: ArticleOffer;
  current_revision_number: number;
  preview_excerpt: string;
  viewer_has_access: boolean;
  viewer_bookmarked: boolean;
  viewer_following_author: boolean;
}

export interface ArticleDetail extends ArticleSummary {
  preview_paragraphs: string[];
  body_blocks: ContentBlock[] | null;
  revision_policy_notice: string;
  revisions_count: number;
  is_author_owner: boolean;
}

export interface ContentBlock {
  type: 'heading' | 'paragraph' | 'list' | 'quote' | 'image';
  level?: 2 | 3;
  ordered?: boolean;
  items?: string[];
  text?: string;
  runs?: TextRun[];
  url?: string;
  alt?: string;
  caption?: string;
}

export interface TextRun {
  text: string;
  bold?: boolean;
  italic?: boolean;
  code?: boolean;
  link?: string;
}

export interface ArticleRevision {
  id: string;
  article_id: string;
  revision_number: number;
  title: string;
  subtitle: string;
  body_markdown: string;
  preview_paragraph_count: number;
  change_note: string;
  created_at: string;
}

export interface PaymentIntentRecord {
  id: string;
  kind: PaymentIntentKind;
  user_id: string;
  article_id: string | null;
  recipient_user_id: string;
  offer_id: string | null;
  revision_id: string | null;
  amount_sats: number;
  customer_fee_sats: number;
  total_sats: number;
  commission_sats: number;
  author_payable_sats: number;
  fee_policy_version: string;
  includes_future_revisions: boolean;
  status: InvoiceStatus;
  fulfillment_status: 'not_applicable' | 'pending' | 'fulfilled' | 'failed_retryable';
  simulate_fulfillment_failure: boolean;
  provider: string;
  provider_account: string;
  created_at: string;
  expires_at: string;
  settled_at: string | null;
  invoice?: LightningInvoiceRecord;
  article_title?: string;
  article_slug?: string;
  recipient_name?: string;
  recipient_handle?: string;
  purchase_id?: string | null;
}

export interface LightningInvoiceRecord {
  id: string;
  payment_intent_id: string;
  provider: string;
  provider_invoice_id: string;
  payment_hash: string;
  bolt11: string;
  amount_sats: number;
  amount_msat: number;
  status: InvoiceStatus;
  expires_at: string;
  settled_at: string | null;
  created_at: string;
}

export interface CreateInvoiceInput {
  paymentIntentId: string;
  amountSats: number;
  memo: string;
  expirySeconds: number;
}

export interface CreateInvoiceResult {
  provider: string;
  providerAccount: string;
  providerInvoiceId: string;
  paymentHash: string;
  bolt11: string;
  amountSats: number;
  amountMsat: number;
  expiresAt: string;
}

export interface ProviderInvoiceStatus {
  provider: string;
  providerAccount: string;
  providerInvoiceId: string;
  paymentHash: string;
  amountSats: number;
  status: InvoiceStatus;
  settledAt: string | null;
}

export interface VerifiedProviderEvent {
  provider: string;
  providerAccount: string;
  providerEventId: string;
  providerInvoiceId: string;
  paymentHash: string;
  paymentIntentId: string;
  amountSats: number;
  status: 'settled' | 'expired' | 'cancelled';
  occurredAt: string;
}

export interface PaymentProviderAdapter {
  readonly providerName: string;
  readonly isLive: boolean;
  createInvoice(input: CreateInvoiceInput): Promise<CreateInvoiceResult>;
  getInvoiceStatus(providerInvoiceId: string): Promise<ProviderInvoiceStatus>;
  verifyProviderEvent(
    rawBody: string,
    signatureHeader: string | null
  ): Promise<VerifiedProviderEvent>;
}

export interface PayoutExecutionInput {
  payoutId: string;
  idempotencyKey: string;
  destination: string;
  amountSats: number;
  memo: string;
}

export interface PayoutExecutionResult {
  provider: string;
  providerPayoutId: string;
  status: 'completed' | 'pending_reconciliation' | 'failed';
  networkFeeSats: number;
  message: string;
}

export interface PayoutProviderAdapter {
  readonly providerName: string;
  executePayout(input: PayoutExecutionInput): Promise<PayoutExecutionResult>;
  reconcilePayout(providerPayoutId: string): Promise<PayoutExecutionResult>;
}

/**
 * Future Direct-to-Author non-custodial interface (kept strictly separate from
 * platform-collection custodial accounting assumptions).
 */
export interface DirectToAuthorFutureAdapter {
  readonly mode: 'direct_to_author_non_custodial';
  resolveAuthorLnurlPay(lightningAddress: string): Promise<{ callbackUrl: string; minSendableMsat: number; maxSendableMsat: number }>;
  requestDirectInvoice(callbackUrl: string, amountMsat: number, comment?: string): Promise<{ bolt11: string; verifyUrl?: string }>;
}
