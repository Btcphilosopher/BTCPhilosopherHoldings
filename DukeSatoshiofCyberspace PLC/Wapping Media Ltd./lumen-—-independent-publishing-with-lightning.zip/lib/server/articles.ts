import crypto from 'node:crypto';
import { getDb, withTransaction } from './db';
import {
  CURRENT_FEE_POLICY_VERSION,
  DEFAULT_CUSTOMER_FEE_SATS,
  DEFAULT_PURCHASE_COMMISSION_BPS,
} from './accounting';
import {
  estimateReadingMinutes,
  extractPreviewParagraphs,
  parseSafeMarkdown,
  stripDangerousHtml,
  validateSafeUrl,
} from './sanitize';
import {
  ArticleDetail,
  ArticleRevision,
  ArticleSummary,
  LifecycleStatus,
  TopicSlug,
} from './types';

function slugify(input: string): string {
  const base = input
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 64);
  return base || `story-${Date.now()}`;
}

function mapRowToSummary(
  row: Record<string, unknown>,
  viewerUserId: string | null
): ArticleSummary {
  const db = getDb();
  const isPaid = Boolean(row.is_paid);
  const isOwner = viewerUserId !== null && row.author_user_id === viewerUserId;
  let hasEntitlement = false;
  let bookmarked = false;
  let followingAuthor = false;

  if (viewerUserId) {
    hasEntitlement = Boolean(
      db
        .prepare(
          `SELECT id FROM entitlements WHERE user_id = ? AND article_id = ? AND revoked_at IS NULL`
        )
        .get(viewerUserId, row.id as string)
    );
    bookmarked = Boolean(
      db
        .prepare(`SELECT 1 FROM bookmarks WHERE user_id = ? AND article_id = ?`)
        .get(viewerUserId, row.id as string)
    );
    followingAuthor = Boolean(
      db
        .prepare(
          `SELECT 1 FROM follows WHERE follower_user_id = ? AND author_user_id = ?`
        )
        .get(viewerUserId, row.author_user_id as string)
    );
  }

  const previewParagraphs = extractPreviewParagraphs(
    row.body_markdown as string,
    Number(row.preview_paragraph_count || 2)
  );

  return {
    id: row.id as string,
    slug: row.slug as string,
    title: row.title as string,
    subtitle: row.subtitle as string,
    topic: row.topic as TopicSlug,
    status: row.status as LifecycleStatus,
    cover_image_url: row.cover_image_url as string,
    cover_image_alt: row.cover_image_alt as string,
    reading_time_minutes: Number(row.reading_time_minutes || 4),
    featured_rank:
      row.featured_rank !== null && row.featured_rank !== undefined
        ? Number(row.featured_rank)
        : null,
    published_at: (row.published_at as string) || null,
    updated_at: row.updated_at as string,
    author: {
      id: row.author_user_id as string,
      handle: row.author_handle as string,
      display_name: row.author_name as string,
      publication_name: (row.publication_name as string) || 'Independent',
      bio: (row.author_bio as string) || '',
    },
    offer: {
      id: row.offer_id as string,
      article_id: row.id as string,
      is_paid: isPaid,
      price_sats: Number(row.price_sats || 0),
      customer_fee_sats: Number(row.customer_fee_sats || 0),
      commission_bps: Number(row.commission_bps || 1000),
      fee_policy_version: row.fee_policy_version as string,
      includes_future_revisions: Boolean(row.includes_future_revisions),
      refund_terms: row.refund_terms as string,
      created_at: row.offer_created_at as string,
    },
    current_revision_number: Number(row.revision_number || 1),
    preview_excerpt: previewParagraphs[0] || (row.subtitle as string),
    viewer_has_access: !isPaid || isOwner || hasEntitlement,
    viewer_bookmarked: bookmarked,
    viewer_following_author: followingAuthor,
  };
}

const BASE_ARTICLE_SELECT = `
  SELECT a.id, a.author_user_id, a.publication_id, a.slug, a.topic, a.status,
         a.cover_image_url, a.cover_image_alt, a.featured_rank, a.view_count,
         a.published_at, a.updated_at, a.current_revision_id, a.current_offer_id,
         r.revision_number, r.title, r.subtitle, r.body_markdown, r.preview_paragraph_count, r.reading_time_minutes,
         o.id AS offer_id, o.is_paid, o.price_sats, o.customer_fee_sats, o.commission_bps,
         o.fee_policy_version, o.includes_future_revisions, o.refund_terms, o.created_at AS offer_created_at,
         u.handle AS author_handle, u.display_name AS author_name,
         ap.bio AS author_bio, COALESCE(pub.name, ap.publication_name) AS publication_name
  FROM articles a
  JOIN article_revisions r ON r.id = a.current_revision_id
  JOIN article_offers o ON o.id = a.current_offer_id
  JOIN users u ON u.id = a.author_user_id
  LEFT JOIN author_profiles ap ON ap.user_id = u.id
  LEFT JOIN publications pub ON pub.id = a.publication_id
`;

export function listPublicArticles(params: {
  topic?: string | null;
  search?: string | null;
  followingForUserId?: string | null;
  authorHandle?: string | null;
  viewerUserId: string | null;
}): ArticleSummary[] {
  const db = getDb();
  const where: string[] = [`a.status IN ('published', 'revised')`];
  const args: (string | number)[] = [];

  if (params.topic && params.topic !== 'for-you' && params.topic !== 'all') {
    where.push(`a.topic = ?`);
    args.push(params.topic);
  }
  if (params.authorHandle) {
    where.push(`u.handle = ?`);
    args.push(params.authorHandle);
  }
  if (params.followingForUserId) {
    where.push(
      `a.author_user_id IN (SELECT author_user_id FROM follows WHERE follower_user_id = ?)`
    );
    args.push(params.followingForUserId);
  }
  if (params.search && params.search.trim()) {
    // Strictly searches title, subtitle, topic, and author name — never paid body_markdown
    const q = `%${params.search.trim().toLowerCase()}%`;
    where.push(
      `(LOWER(r.title) LIKE ? OR LOWER(r.subtitle) LIKE ? OR LOWER(a.topic) LIKE ? OR LOWER(u.display_name) LIKE ?)`
    );
    args.push(q, q, q, q);
  }

  const sql = `${BASE_ARTICLE_SELECT}
    WHERE ${where.join(' AND ')}
    ORDER BY COALESCE(a.featured_rank, 9999) ASC, a.published_at DESC`;

  const rows = db.prepare(sql).all(...args) as Record<string, unknown>[];
  return rows.map((r) => mapRowToSummary(r, params.viewerUserId));
}

export function getArticleDetail(params: {
  idOrSlug: string;
  viewerUserId: string | null;
  viewerRole?: string | null;
  incrementView?: boolean;
}): ArticleDetail | null {
  const db = getDb();
  const row = db
    .prepare(`${BASE_ARTICLE_SELECT} WHERE a.id = ? OR a.slug = ?`)
    .get(params.idOrSlug, params.idOrSlug) as Record<string, unknown> | undefined;

  if (!row) return null;

  const isOwner = params.viewerUserId !== null && row.author_user_id === params.viewerUserId;
  const isAdmin = params.viewerRole === 'admin';

  // Drafts and withdrawn articles are strictly restricted to owner or admin
  if ((row.status === 'draft' || row.status === 'withdrawn') && !isOwner && !isAdmin) {
    return null;
  }

  if (params.incrementView && (row.status === 'published' || row.status === 'revised')) {
    db.prepare(`UPDATE articles SET view_count = view_count + 1 WHERE id = ?`).run(
      row.id as string
    );
  }

  const summary = mapRowToSummary(row, params.viewerUserId);
  const canReadFull = summary.viewer_has_access || isAdmin;

  let bodyMarkdownForViewer = row.body_markdown as string;
  let revisionPolicyNotice = summary.offer.includes_future_revisions
    ? 'Includes all future revisions to this edition.'
    : `Covers edition v${summary.current_revision_number}; future revised editions may require a separate unlock.`;

  if (params.viewerUserId && !isOwner && summary.offer.is_paid) {
    const ent = db
      .prepare(
        `SELECT locked_revision_id, includes_future_revisions FROM entitlements
         WHERE user_id = ? AND article_id = ? AND revoked_at IS NULL`
      )
      .get(params.viewerUserId, row.id as string) as
      | { locked_revision_id: string; includes_future_revisions: number }
      | undefined;

    if (ent && !ent.includes_future_revisions && ent.locked_revision_id !== row.current_revision_id) {
      const lockedRev = db
        .prepare(`SELECT body_markdown, revision_number FROM article_revisions WHERE id = ?`)
        .get(ent.locked_revision_id) as
        | { body_markdown: string; revision_number: number }
        | undefined;
      if (lockedRev) {
        bodyMarkdownForViewer = lockedRev.body_markdown;
        revisionPolicyNotice = `Showing edition v${lockedRev.revision_number} as purchased under your original offer.`;
      }
    }
  }

  const previewParagraphs = extractPreviewParagraphs(
    row.body_markdown as string,
    Number(row.preview_paragraph_count || 2)
  );

  const revisionsCountRow = db
    .prepare(`SELECT COUNT(*) AS cnt FROM article_revisions WHERE article_id = ?`)
    .get(row.id as string) as { cnt: number };

  return {
    ...summary,
    viewer_has_access: canReadFull,
    preview_paragraphs: previewParagraphs,
    // CRITICAL ACCESS CONTROL: never serialize full body_blocks to unauthorized callers
    body_blocks: canReadFull ? parseSafeMarkdown(bodyMarkdownForViewer) : null,
    revision_policy_notice: revisionPolicyNotice,
    revisions_count: Number(revisionsCountRow.cnt),
    is_author_owner: isOwner,
  };
}

export function listAuthorDashboardArticles(authorUserId: string) {
  const db = getDb();
  const rows = db
    .prepare(
      `${BASE_ARTICLE_SELECT}
       WHERE a.author_user_id = ?
       ORDER BY a.updated_at DESC`
    )
    .all(authorUserId) as Record<string, unknown>[];

  return rows.map((row) => {
    const stats = db
      .prepare(
        `SELECT
          (SELECT COUNT(*) FROM payment_intents pi WHERE pi.article_id = ? AND pi.kind = 'article_purchase') AS purchase_attempts,
          (SELECT COUNT(*) FROM purchases p WHERE p.article_id = ? AND p.status = 'active') AS settled_purchases,
          (SELECT COALESCE(SUM(p.author_payable_sats), 0) FROM purchases p WHERE p.article_id = ? AND p.status = 'active') AS purchase_revenue_sats,
          (SELECT COALESCE(SUM(t.author_payable_sats), 0) FROM tips t WHERE t.article_id = ? AND t.status = 'settled') AS tip_revenue_sats`
      )
      .get(row.id as string, row.id as string, row.id as string, row.id as string) as {
      purchase_attempts: number;
      settled_purchases: number;
      purchase_revenue_sats: number;
      tip_revenue_sats: number;
    };

    return {
      ...mapRowToSummary(row, authorUserId),
      view_count: Number(row.view_count || 0),
      purchase_attempts: Number(stats.purchase_attempts || 0),
      settled_purchases: Number(stats.settled_purchases || 0),
      purchase_revenue_sats: Number(stats.purchase_revenue_sats || 0),
      tip_revenue_sats: Number(stats.tip_revenue_sats || 0),
      body_markdown: row.body_markdown as string,
      preview_paragraph_count: Number(row.preview_paragraph_count || 2),
    };
  });
}

export function getArticleRevisions(articleId: string): ArticleRevision[] {
  const db = getDb();
  return db
    .prepare(
      `SELECT id, article_id, revision_number, title, subtitle, body_markdown, preview_paragraph_count, change_note, created_at
       FROM article_revisions
       WHERE article_id = ?
       ORDER BY revision_number DESC`
    )
    .all(articleId) as unknown as ArticleRevision[];
}

export function createDraftArticle(params: {
  authorUserId: string;
  title: string;
  subtitle: string;
  topic: TopicSlug;
  bodyMarkdown: string;
  coverImageUrl?: string;
  coverImageAlt?: string;
  isPaid: boolean;
  priceSats: number;
  previewParagraphCount: number;
  includesFutureRevisions: boolean;
}) {
  const db = getDb();
  const title = stripDangerousHtml(params.title).trim();
  const subtitle = stripDangerousHtml(params.subtitle).trim();
  if (!title) throw new Error('Title is required');

  const safeCover =
    validateSafeUrl(params.coverImageUrl || '/images/articles/design-atelier.svg', true) ||
    '/images/articles/design-atelier.svg';

  const pub = db
    .prepare(`SELECT id FROM publications WHERE owner_user_id = ? LIMIT 1`)
    .get(params.authorUserId) as { id: string } | undefined;

  let publicationId = pub?.id;
  const now = new Date().toISOString();

  const articleId = `art_${crypto.randomUUID().slice(0, 12)}`;
  const revId = `rev_${crypto.randomUUID().slice(0, 12)}`;
  const offerId = `off_${crypto.randomUUID().slice(0, 12)}`;
  const slug = `${slugify(title)}-${articleId.slice(-5)}`;
  const cleanPrice = params.isPaid ? Math.max(1, Math.trunc(params.priceSats)) : 0;
  const previewCount = Math.max(1, Math.min(6, Math.trunc(params.previewParagraphCount || 2)));
  const readingMins = estimateReadingMinutes(params.bodyMarkdown);

  withTransaction(db, () => {
    if (!publicationId) {
      const user = db
        .prepare(`SELECT handle, display_name FROM users WHERE id = ?`)
        .get(params.authorUserId) as { handle: string; display_name: string };
      publicationId = `pub_${user.handle}`;
      db.prepare(
        `INSERT INTO publications (id, owner_user_id, slug, name, tagline, created_at)
         VALUES (?, ?, ?, ?, '', ?)`
      ).run(publicationId, params.authorUserId, user.handle, `${user.display_name}'s Journal`, now);
    }

    db.prepare(
      `INSERT INTO articles (
        id, author_user_id, publication_id, slug, topic, status,
        cover_image_url, cover_image_alt, current_revision_id, current_offer_id,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, 'draft', ?, ?, ?, ?, ?, ?)`
    ).run(
      articleId,
      params.authorUserId,
      publicationId,
      slug,
      params.topic,
      safeCover,
      stripDangerousHtml(params.coverImageAlt || title).trim(),
      revId,
      offerId,
      now,
      now
    );

    db.prepare(
      `INSERT INTO article_revisions (
        id, article_id, revision_number, title, subtitle, body_markdown,
        preview_paragraph_count, reading_time_minutes, change_note, created_at
      ) VALUES (?, ?, 1, ?, ?, ?, ?, ?, 'Initial draft', ?)`
    ).run(
      revId,
      articleId,
      title,
      subtitle,
      stripDangerousHtml(params.bodyMarkdown),
      previewCount,
      readingMins,
      now
    );

    db.prepare(
      `INSERT INTO article_offers (
        id, article_id, is_paid, price_sats, customer_fee_sats, commission_bps,
        fee_policy_version, includes_future_revisions, refund_terms, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      offerId,
      articleId,
      params.isPaid ? 1 : 0,
      cleanPrice,
      DEFAULT_CUSTOMER_FEE_SATS,
      DEFAULT_PURCHASE_COMMISSION_BPS,
      CURRENT_FEE_POLICY_VERSION,
      params.includesFutureRevisions ? 1 : 0,
      params.isPaid
        ? 'Lightning payments are final and cannot be reversed like card chargebacks. Reviewed refunds may be issued via separate outgoing payout within 7 days if access fails or content is withdrawn.'
        : 'Free edition — no payment required.',
      now
    );
  });

  return { id: articleId, slug };
}

export function saveArticleRevision(params: {
  articleId: string;
  authorUserId: string;
  title: string;
  subtitle: string;
  topic: TopicSlug;
  bodyMarkdown: string;
  coverImageUrl?: string;
  coverImageAlt?: string;
  isPaid: boolean;
  priceSats: number;
  previewParagraphCount: number;
  includesFutureRevisions: boolean;
  changeNote?: string;
  createSnapshot?: boolean;
}) {
  const db = getDb();
  const article = db
    .prepare(`SELECT * FROM articles WHERE id = ?`)
    .get(params.articleId) as Record<string, unknown> | undefined;

  if (!article) throw new Error('Article not found');
  if (article.author_user_id !== params.authorUserId) {
    throw new Error('Forbidden: only the author may edit this article');
  }

  const title = stripDangerousHtml(params.title).trim();
  const subtitle = stripDangerousHtml(params.subtitle).trim();
  if (!title) throw new Error('Title is required');

  const safeCover =
    validateSafeUrl(
      params.coverImageUrl || (article.cover_image_url as string),
      true
    ) || (article.cover_image_url as string);

  const now = new Date().toISOString();
  const cleanPrice = params.isPaid ? Math.max(1, Math.trunc(params.priceSats)) : 0;
  const previewCount = Math.max(1, Math.min(6, Math.trunc(params.previewParagraphCount || 2)));
  const cleanBody = stripDangerousHtml(params.bodyMarkdown);
  const readingMins = estimateReadingMinutes(cleanBody);

  withTransaction(db, () => {
    const currentRev = db
      .prepare(`SELECT * FROM article_revisions WHERE id = ?`)
      .get(article.current_revision_id as string) as Record<string, unknown>;

    let nextRevId = currentRev.id as string;

    if (params.createSnapshot || article.status === 'published' || article.status === 'revised') {
      const nextNum = Number(currentRev.revision_number) + 1;
      nextRevId = `rev_${crypto.randomUUID().slice(0, 12)}`;
      db.prepare(
        `INSERT INTO article_revisions (
          id, article_id, revision_number, title, subtitle, body_markdown,
          preview_paragraph_count, reading_time_minutes, change_note, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        nextRevId,
        params.articleId,
        nextNum,
        title,
        subtitle,
        cleanBody,
        previewCount,
        readingMins,
        (params.changeNote || 'Saved revision').slice(0, 200),
        now
      );
    } else {
      db.prepare(
        `UPDATE article_revisions
         SET title = ?, subtitle = ?, body_markdown = ?, preview_paragraph_count = ?, reading_time_minutes = ?
         WHERE id = ?`
      ).run(title, subtitle, cleanBody, previewCount, readingMins, nextRevId);
    }

    const offerId = `off_${crypto.randomUUID().slice(0, 12)}`;
    db.prepare(
      `INSERT INTO article_offers (
        id, article_id, is_paid, price_sats, customer_fee_sats, commission_bps,
        fee_policy_version, includes_future_revisions, refund_terms, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      offerId,
      params.articleId,
      params.isPaid ? 1 : 0,
      cleanPrice,
      DEFAULT_CUSTOMER_FEE_SATS,
      DEFAULT_PURCHASE_COMMISSION_BPS,
      CURRENT_FEE_POLICY_VERSION,
      params.includesFutureRevisions ? 1 : 0,
      params.isPaid
        ? 'Lightning payments are final and cannot be reversed like card chargebacks. Reviewed refunds may be issued via separate outgoing payout within 7 days if access fails or content is withdrawn.'
        : 'Free edition — no payment required.',
      now
    );

    const nextStatus =
      article.status === 'published' || article.status === 'revised'
        ? 'revised'
        : (article.status as string);

    db.prepare(
      `UPDATE articles
       SET topic = ?, cover_image_url = ?, cover_image_alt = ?,
           current_revision_id = ?, current_offer_id = ?, status = ?, updated_at = ?
       WHERE id = ?`
    ).run(
      params.topic,
      safeCover,
      stripDangerousHtml(params.coverImageAlt || title).trim(),
      nextRevId,
      offerId,
      nextStatus,
      now,
      params.articleId
    );
  });

  return { articleId: params.articleId };
}

export function transitionArticleStatus(params: {
  articleId: string;
  actorUserId: string;
  actorRole: string;
  targetStatus: LifecycleStatus;
}) {
  const db = getDb();
  const article = db
    .prepare(`SELECT * FROM articles WHERE id = ?`)
    .get(params.articleId) as Record<string, unknown> | undefined;

  if (!article) throw new Error('Article not found');
  if (article.author_user_id !== params.actorUserId && params.actorRole !== 'admin') {
    throw new Error('Forbidden: only the author or an administrator may change publication status');
  }

  const now = new Date().toISOString();
  const publishedAt =
    params.targetStatus === 'published' && !article.published_at
      ? now
      : (article.published_at as string | null);

  withTransaction(db, () => {
    db.prepare(
      `UPDATE articles SET status = ?, published_at = ?, updated_at = ? WHERE id = ?`
    ).run(params.targetStatus, publishedAt, now, params.articleId);

    db.prepare(
      `INSERT INTO audit_logs (id, actor_user_id, action, entity_type, entity_id, details_json, created_at)
       VALUES (?, ?, 'transition_article_status', 'article', ?, ?, ?)`
    ).run(
      `aud_${crypto.randomUUID()}`,
      params.actorUserId,
      params.articleId,
      JSON.stringify({ from: article.status, to: params.targetStatus }),
      now
    );
  });

  return { id: params.articleId, status: params.targetStatus };
}
