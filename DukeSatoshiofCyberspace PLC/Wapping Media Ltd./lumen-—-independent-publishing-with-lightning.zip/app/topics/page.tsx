import React from 'react';
import Link from 'next/link';
import { listPublicArticles } from '@/lib/server/articles';
import { getSessionFromRequest } from '@/lib/server/crypto';
import { SiteHeader } from '@/components/SiteHeader';
import { SiteFooter } from '@/components/SiteFooter';

export const dynamic = 'force-dynamic';

const TOPICS = [
  {
    slug: 'technology',
    name: 'Technology',
    summary: 'Open protocols, local-first tools, computing autonomy, and durable software.',
  },
  {
    slug: 'culture',
    name: 'Culture',
    summary: 'Libraries, literary criticism, slow craft, and civic architecture.',
  },
  {
    slug: 'science',
    name: 'Science',
    summary: 'Long-horizon observation, scientific instruments, and empirical notebooks.',
  },
  {
    slug: 'economics',
    name: 'Economics',
    summary: 'Micropayments, integer accounting, public goods, and publishing economics.',
  },
  {
    slug: 'design',
    name: 'Design',
    summary: 'Typography, broadsheet layouts, print heritage, and calm digital reading.',
  },
];

export default async function TopicsIndexPage() {
  const session = await getSessionFromRequest();
  const articles = listPublicArticles({ viewerUserId: session?.userId || null });

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F1E4] text-[#0D2636] dark:bg-[#091B27] dark:text-[#F4EFE3]">
      <SiteHeader activeTopic="topics" />

      <main className="flex-1 max-w-[1220px] w-full mx-auto px-4 sm:px-6 py-10 space-y-8">
        <div className="border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 pb-6 space-y-2">
          <p className="text-[11px] uppercase tracking-[0.22em] text-[#CE9118] font-[family-name:var(--font-sans-ui)]">
            Editorial Departments
          </p>
          <h1 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl font-medium">
            Topics
          </h1>
          <p className="text-sm sm:text-base text-[#465B68] dark:text-[#F4EFE3]/75 max-w-2xl">
            Browse Lumen’s transparent topic departments. No opaque algorithmic ranking — essays appear chronologically within each department.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {TOPICS.map((t) => {
            const count = articles.filter((a) => a.topic === t.slug).length;
            return (
              <Link
                key={t.slug}
                href={`/topics/${t.slug}`}
                className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] p-6 hover:border-[#E5A929] transition-colors flex flex-col justify-between gap-4"
              >
                <div>
                  <p className="text-xs font-[family-name:var(--font-mono-sats)] text-[#CE9118] tabular-sats">
                    {count} {count === 1 ? 'essay' : 'essays'}
                  </p>
                  <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium mt-1">
                    {t.name}
                  </h2>
                  <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75 mt-2">
                    {t.summary}
                  </p>
                </div>
                <span className="text-xs font-medium underline decoration-[#E5A929] underline-offset-4">
                  Explore {t.name} →
                </span>
              </Link>
            );
          })}
        </div>
      </main>

      <SiteFooter />
    </div>
  );
}
