import React from 'react';
import { notFound } from 'next/navigation';
import { listPublicArticles } from '@/lib/server/articles';
import { getSessionFromRequest } from '@/lib/server/crypto';
import { ArticleListView } from '@/components/ArticleListView';

export const dynamic = 'force-dynamic';

const TOPIC_META: Record<string, { title: string; description: string }> = {
  technology: {
    title: 'Technology',
    description: 'Essays on open protocols, local-first software, and the ownership of computing.',
  },
  culture: {
    title: 'Culture',
    description: 'Reflections on personal libraries, reading habits, and unhurried craft.',
  },
  science: {
    title: 'Science',
    description: 'Field notes from coastal observatories, metrology, and empirical inquiry.',
  },
  economics: {
    title: 'Economics',
    description: 'Studies in integer accounting, micropayments, and independent publishing models.',
  },
  design: {
    title: 'Design',
    description: 'Typography, broadsheet composition, and quiet digital environments.',
  },
};

export default async function TopicDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const meta = TOPIC_META[slug];
  if (!meta) notFound();

  const session = await getSessionFromRequest();
  const articles = listPublicArticles({
    topic: slug,
    viewerUserId: session?.userId || null,
  });

  return (
    <ArticleListView
      eyebrow="Department"
      title={meta.title}
      description={meta.description}
      activeTopic={slug}
      articles={articles}
    />
  );
}
