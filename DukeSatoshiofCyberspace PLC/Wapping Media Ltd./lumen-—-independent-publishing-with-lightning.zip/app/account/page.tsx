'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { SiteHeader } from '@/components/SiteHeader';
import { SiteFooter } from '@/components/SiteFooter';
import { useLumenAuth } from '@/components/LumenAuthContext';

export default function AccountPage() {
  const {
    user,
    profile,
    demoAccounts,
    adminConfigured,
    refreshAuth,
    switchDemoAccount,
    logout,
  } = useLumenAuth();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [handle, setHandle] = useState('');

  const [editName, setEditName] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editPubName, setEditPubName] = useState('');
  const [editLnDest, setEditLnDest] = useState('');
  const [adminPasscode, setAdminPasscode] = useState('');

  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const raf = requestAnimationFrame(() => {
      if (user) {
        setEditName(user.display_name);
      }
      if (profile) {
        setEditBio(profile.bio || '');
        setEditPubName(profile.publication_name || '');
        setEditLnDest(profile.lightning_destination || '');
      }
    });
    return () => cancelAnimationFrame(raf);
  }, [user, profile]);

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);
    const res = await fetch('/api/v1/auth', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'lumen-ui',
      },
      body: JSON.stringify({
        action: mode,
        email,
        password,
        display_name: displayName,
        handle,
      }),
    });
    const data = (await res.json()) as { error?: string };
    if (!res.ok) {
      setError(data.error || 'Authentication failed');
      return;
    }
    setMessage(mode === 'login' ? 'Signed in.' : 'Account created.');
    await refreshAuth();
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);
    const res = await fetch('/api/v1/auth', {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'lumen-ui',
      },
      body: JSON.stringify({
        display_name: editName,
        bio: editBio,
        publication_name: editPubName,
        lightning_destination: editLnDest,
      }),
    });
    const data = (await res.json()) as { error?: string };
    if (!res.ok) {
      setError(data.error || 'Profile update failed');
      return;
    }
    setMessage('Account and payout profile updated.');
    await refreshAuth();
  };

  const handleClaimAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);
    const res = await fetch('/api/v1/auth', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'lumen-ui',
      },
      body: JSON.stringify({ action: 'claim_admin', passcode: adminPasscode }),
    });
    const data = (await res.json()) as { error?: string };
    if (!res.ok) {
      setError(data.error || 'Admin verification failed');
      return;
    }
    setMessage('Administrator role enabled for this session.');
    setAdminPasscode('');
    await refreshAuth();
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F1E4] text-[#0D2636] dark:bg-[#091B27] dark:text-[#F4EFE3]">
      <SiteHeader />

      <main className="flex-1 max-w-[1220px] w-full mx-auto px-4 sm:px-6 py-10 space-y-10">
        <div className="border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 pb-6 space-y-2">
          <p className="text-[11px] uppercase tracking-[0.22em] text-[#CE9118] font-[family-name:var(--font-sans-ui)]">
            Identity &amp; Settings
          </p>
          <h1 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl font-medium">
            Account
          </h1>
          <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75">
            Sign in for durable article entitlements, writing studio access, and author payouts. Free articles require no account.
          </p>
        </div>

        {message && (
          <p className="p-3 text-xs border border-emerald-700/40 bg-emerald-50 dark:bg-emerald-950/40">
            {message}
          </p>
        )}
        {error && (
          <p className="p-3 text-xs border border-red-400 bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-200">
            {error}
          </p>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left: Current session or Sign In / Register */}
          <div className="lg:col-span-7 space-y-6">
            {user ? (
              <div className="border border-[#D6CEBC] dark:border-[#F6F1E4]/25 bg-[#FAF7EF] dark:bg-[#0D2636] p-6 space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#D6CEBC] dark:border-[#F6F1E4]/15 pb-4">
                  <div>
                    <p className="text-xs text-[#CE9118] uppercase tracking-wider font-[family-name:var(--font-sans-ui)]">
                      Signed in · {user.role}
                    </p>
                    <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
                      {user.display_name} (@{user.handle})
                    </h2>
                    <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/70">{user.email}</p>
                  </div>
                  <button
                    type="button"
                    onClick={logout}
                    className="px-4 py-2 text-xs font-medium border border-[#0D2636] dark:border-[#F6F1E4]/35 hover:bg-[#0D2636]/5"
                  >
                    Log out
                  </button>
                </div>

                <form onSubmit={handleSaveProfile} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium mb-1">Display name</label>
                      <input
                        type="text"
                        required
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="w-full px-3 py-2 text-sm bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium mb-1">Publication name</label>
                      <input
                        type="text"
                        value={editPubName}
                        onChange={(e) => setEditPubName(e.target.value)}
                        className="w-full px-3 py-2 text-sm bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium mb-1">Editorial bio</label>
                    <textarea
                      rows={3}
                      value={editBio}
                      onChange={(e) => setEditBio(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium mb-1">
                      Author Lightning payout destination (Lightning Address or LNURL)
                    </label>
                    <input
                      type="text"
                      value={editLnDest}
                      onChange={(e) => setEditLnDest(e.target.value)}
                      placeholder="name@domain.example"
                      className="w-full px-3 py-2 text-sm font-[family-name:var(--font-mono-sats)] bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-[#0D2636] text-[#F6F1E4] hover:bg-[#173D52] text-xs font-medium"
                  >
                    Save account settings
                  </button>
                </form>

                {/* Admin Bootstrap / Claim */}
                {user.role !== 'admin' && (
                  <form
                    onSubmit={handleClaimAdmin}
                    className="pt-5 border-t border-[#D6CEBC] dark:border-[#F6F1E4]/15 space-y-3"
                  >
                    <p className="text-xs font-semibold">
                      {adminConfigured
                        ? 'Unlock Moderation Administration'
                        : 'First-Run Administrator Setup'}
                    </p>
                    <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/70">
                      {adminConfigured
                        ? 'Enter the administrator passcode to access moderation and reconciliation controls.'
                        : 'No administrator passcode is set yet. Choose a passcode (min 8 chars) to claim initial moderation administration.'}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <input
                        type="password"
                        minLength={8}
                        required
                        value={adminPasscode}
                        onChange={(e) => setAdminPasscode(e.target.value)}
                        placeholder="Administrator passcode (min 8 chars)"
                        className="px-3 py-2 text-xs bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25 flex-1 min-w-[220px]"
                      />
                      <button
                        type="submit"
                        className="px-4 py-2 text-xs font-medium border border-[#0D2636] dark:border-[#F6F1E4]/35 hover:bg-[#0D2636]/5"
                      >
                        {adminConfigured ? 'Verify admin' : 'Claim admin'}
                      </button>
                    </div>
                  </form>
                )}

                {user.role === 'admin' && (
                  <div className="pt-4 border-t border-[#D6CEBC] dark:border-[#F6F1E4]/15">
                    <Link
                      href="/admin"
                      className="inline-block px-4 py-2 bg-[#E5A929] text-[#0D2636] text-xs font-semibold"
                    >
                      Open Moderation Administration →
                    </Link>
                  </div>
                )}
              </div>
            ) : (
              <div className="border border-[#D6CEBC] dark:border-[#F6F1E4]/25 bg-[#FAF7EF] dark:bg-[#0D2636] p-6 space-y-5">
                <div className="flex gap-4 border-b border-[#D6CEBC] dark:border-[#F6F1E4]/15 pb-3 text-sm">
                  <button
                    type="button"
                    onClick={() => setMode('login')}
                    className={`font-medium ${
                      mode === 'login' ? 'underline decoration-[#E5A929] underline-offset-4' : 'text-[#465B68]'
                    }`}
                  >
                    Sign in
                  </button>
                  <button
                    type="button"
                    onClick={() => setMode('register')}
                    className={`font-medium ${
                      mode === 'register' ? 'underline decoration-[#E5A929] underline-offset-4' : 'text-[#465B68]'
                    }`}
                  >
                    Create account
                  </button>
                </div>

                <form onSubmit={handleAuthSubmit} className="space-y-4">
                  {mode === 'register' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-medium mb-1">Display name</label>
                        <input
                          type="text"
                          required
                          value={displayName}
                          onChange={(e) => setDisplayName(e.target.value)}
                          className="w-full px-3 py-2 text-sm bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium mb-1">Handle</label>
                        <input
                          type="text"
                          required
                          value={handle}
                          onChange={(e) => setHandle(e.target.value)}
                          placeholder="e.g. clara"
                          className="w-full px-3 py-2 text-sm bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                        />
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-medium mb-1">Email</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="reader@lumen.press"
                      className="w-full px-3 py-2 text-sm bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium mb-1">Password</label>
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                    />
                  </div>

                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-[#0D2636] text-[#F6F1E4] hover:bg-[#173D52] text-xs font-medium"
                  >
                    {mode === 'login' ? 'Sign in' : 'Create account'}
                  </button>
                </form>
              </div>
            )}
          </div>

          {/* Right: Demonstration Account Switcher */}
          <aside className="lg:col-span-5 space-y-4">
            <div className="border border-[#D6CEBC] dark:border-[#F6F1E4]/25 bg-[#FAF7EF] dark:bg-[#0D2636] p-6 space-y-4">
              <p className="text-[11px] uppercase tracking-[0.2em] text-[#CE9118] font-[family-name:var(--font-sans-ui)]">
                Demonstration Fixture Accounts
              </p>
              <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/75 leading-relaxed">
                Switch between seeded reader and writer personas (all demo passwords: <code className="font-mono">demo1234</code>) to inspect purchases, library persistence across logout/login, and author statements.
              </p>
              <div className="space-y-2">
                {demoAccounts.map((acct) => (
                  <button
                    key={acct.email}
                    type="button"
                    onClick={async () => {
                      await switchDemoAccount(acct.email);
                      setMessage(`Switched active session to ${acct.display_name}.`);
                    }}
                    className={`w-full text-left px-4 py-2.5 border text-xs flex items-center justify-between transition-colors ${
                      user?.email === acct.email
                        ? 'border-[#E5A929] bg-[#E5A929]/15 font-semibold'
                        : 'border-[#D6CEBC] dark:border-[#F6F1E4]/20 hover:border-[#0D2636]'
                    }`}
                  >
                    <span>{acct.display_name}</span>
                    <span className="text-[#465B68] dark:text-[#F4EFE3]/65">{acct.email}</span>
                  </button>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </main>

      <SiteFooter />
    </div>
  );
}
