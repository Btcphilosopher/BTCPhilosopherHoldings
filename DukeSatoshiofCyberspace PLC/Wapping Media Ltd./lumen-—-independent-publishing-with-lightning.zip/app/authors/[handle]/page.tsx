import React from 'react';
import { notFound } from 'next/navigation';
import { listPublicArticles } from '@/lib/server/articles';
import { getSessionFromRequest } from '@/lib/server/crypto';
import { getDb } from '@/lib/server/db';
import { AuthorProfileClient } from '@/components/AuthorProfileClient';

export const dynamic = 'force-dynamic';

export default async function AuthorPage({
  params,
}: {
  params: Promise<{ handle: string }>;
}) {
  const { handle } = await params;
  const session = await getSessionFromRequest();
  const db = getDb();

  const row = db
    .prepare(
      `SELECT u.id, u.handle, u.display_name, ap.bio, ap.publication_name
       FROM users u
       LEFT JOIN author_profiles ap ON ap.user_id = u.id
       WHERE u.handle = ?`
    )
    .get(handle) as
    | {
        id: string;
        handle: string;
        display_name: string;
        bio: string | null;
        publication_name: string | null;
      }
    | undefined;

  if (!row) notFound();

  const followers = db
    .prepare(`SELECT COUNT(*) AS cnt FROM follows WHERE author_user_id = ?`)
    .get(row.id) as { cnt: number };

  const viewerFollowing = session
    ? Boolean(
        db
          .prepare(
            `SELECT 1 FROM follows WHERE follower_user_id = ? AND author_user_id = ?`
          )
          .get(session.userId, row.id)
      )
    : false;

  const articles = listPublicArticles({
    authorHandle: handle,
    viewerUserId: session?.userId || null,
  });

  return (
    <AuthorProfileClient
      author={{
        id: row.id,
        handle: row.handle,
        display_name: row.display_name,
        bio: row.bio || '',
        publication_name: row.publication_name || 'Independent',
        followers_count: Number(followers.cnt),
        viewer_following: viewerFollowing,
      }}
      articles={articles}
    />
  );
}
