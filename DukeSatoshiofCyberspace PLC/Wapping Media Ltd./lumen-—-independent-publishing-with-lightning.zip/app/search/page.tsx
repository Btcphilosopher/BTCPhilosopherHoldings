import React from 'react';
import { listPublicArticles } from '@/lib/server/articles';
import { getSessionFromRequest } from '@/lib/server/crypto';
import { ArticleListView } from '@/components/ArticleListView';

export const dynamic = 'force-dynamic';

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;
  const session = await getSessionFromRequest();
  const articles = listPublicArticles({
    search: q || '',
    viewerUserId: session?.userId || null,
  });

  return (
    <ArticleListView
      eyebrow="Catalog Search"
      title={q ? `Search: “${q}”` : 'Search Lumen'}
      description="Search published essays by title, subtitle, author, or topic. Private drafts and paid full bodies are excluded from search indexes."
      articles={articles}
      showSearchForm={true}
      initialQuery={q || ''}
      emptyMessage="No published essays matched your search query."
    />
  );
}
