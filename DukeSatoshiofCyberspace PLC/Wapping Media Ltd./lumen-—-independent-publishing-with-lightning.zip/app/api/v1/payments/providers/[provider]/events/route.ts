import { NextRequest } from 'next/server';
import { processVerifiedProviderEvent } from '@/lib/server/accounting';
import { jsonNoStore } from '@/lib/server/http';
import { getPaymentProviderByName } from '@/lib/server/lightning';

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ provider: string }> }
) {
  const { provider } = await context.params;
  const rawBody = await req.text();
  const signature = req.headers.get('x-lumen-signature');

  try {
    const adapter = getPaymentProviderByName(provider);
    const verified = await adapter.verifyProviderEvent(rawBody, signature);
    const result = processVerifiedProviderEvent(verified);
    return jsonNoStore({
      ok: true,
      duplicate: result.duplicate,
      outcome: result.outcome,
      payment_intent: result.intent,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Provider event verification failed';
    const status = msg.toLowerCase().includes('signature') ? 401 : 400;
    return jsonNoStore({ error: msg }, status);
  }
}
