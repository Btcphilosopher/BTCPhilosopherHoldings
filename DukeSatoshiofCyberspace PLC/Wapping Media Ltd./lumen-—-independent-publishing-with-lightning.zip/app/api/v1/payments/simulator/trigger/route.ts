import crypto from 'node:crypto';
import { NextRequest } from 'next/server';
import {
  getPaymentIntentById,
  processVerifiedProviderEvent,
} from '@/lib/server/accounting';
import { checkCsrf, jsonNoStore, requireAuth } from '@/lib/server/http';
import {
  DeterministicSimulatorProvider,
  signSimulatorEvent,
} from '@/lib/server/lightning';

/**
 * Simulator-only server endpoint that signs and verifies an authentic simulator webhook
 * event for a payment intent (never trusts raw client "I paid" claims without server verification).
 */
export async function POST(req: NextRequest) {
  const csrfErr = checkCsrf(req);
  if (csrfErr) return csrfErr;

  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  if (process.env.LIGHTNING_LIVE_ENABLED === 'true') {
    return jsonNoStore(
      { error: 'Simulator trigger is disabled while live Lightning mode is active' },
      403
    );
  }

  const body = (await req.json()) as {
    payment_intent_id?: string;
    event_status?: 'settled' | 'expired' | 'cancelled';
    provider_event_id?: string;
  };

  if (!body.payment_intent_id) {
    return jsonNoStore({ error: 'payment_intent_id is required' }, 400);
  }

  const intent = getPaymentIntentById(body.payment_intent_id);
  if (!intent || !intent.invoice) {
    return jsonNoStore({ error: 'Payment intent or invoice not found' }, 404);
  }

  if (intent.user_id !== auth.user.id && auth.user.role !== 'admin') {
    return jsonNoStore({ error: 'Forbidden' }, 403);
  }
  if (intent.provider !== 'simulator') {
    return jsonNoStore({ error: 'Only simulator intents can be simulated' }, 400);
  }

  const eventId = body.provider_event_id || `sim_evt_${crypto.randomUUID()}`;
  const status = body.event_status || 'settled';

  const rawPayload = JSON.stringify({
    provider_event_id: eventId,
    provider_invoice_id: intent.invoice.provider_invoice_id,
    payment_hash: intent.invoice.payment_hash,
    payment_intent_id: intent.id,
    provider_account: intent.provider_account,
    amount_sats: intent.total_sats,
    status,
    occurred_at: new Date().toISOString(),
  });

  const signature = signSimulatorEvent(rawPayload);
  const adapter = new DeterministicSimulatorProvider();
  const verified = await adapter.verifyProviderEvent(rawPayload, signature);
  const result = processVerifiedProviderEvent(verified);

  return jsonNoStore({
    ok: true,
    duplicate: result.duplicate,
    outcome: result.outcome,
    provider_event_id: eventId,
    payment_intent: result.intent,
  });
}
