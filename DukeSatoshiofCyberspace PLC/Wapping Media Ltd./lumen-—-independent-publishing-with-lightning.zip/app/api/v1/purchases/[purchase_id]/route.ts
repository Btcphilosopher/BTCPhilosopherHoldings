import { NextRequest } from 'next/server';
import { getDb } from '@/lib/server/db';
import { jsonNoStore, requireAuth } from '@/lib/server/http';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ purchase_id: string }> }
) {
  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  const { purchase_id } = await context.params;
  const db = getDb();
  const row = db
    .prepare(
      `SELECT p.*, r.title AS article_title, a.slug AS article_slug, u.display_name AS author_name
       FROM purchases p
       JOIN articles a ON a.id = p.article_id
       JOIN article_revisions r ON r.id = p.revision_id
       JOIN users u ON u.id = a.author_user_id
       WHERE p.id = ?`
    )
    .get(purchase_id) as Record<string, unknown> | undefined;

  if (!row) {
    return jsonNoStore({ error: 'Purchase not found' }, 404);
  }
  if (row.user_id !== auth.user.id && auth.user.role !== 'admin') {
    return jsonNoStore({ error: 'Forbidden' }, 403);
  }

  return jsonNoStore({ purchase: row });
}
