import { NextRequest } from 'next/server';
import { createArticlePurchaseIntent } from '@/lib/server/accounting';
import { checkRateLimit } from '@/lib/server/crypto';
import { checkCsrf, jsonNoStore, requireAuth } from '@/lib/server/http';

export async function POST(req: NextRequest) {
  const csrfErr = checkCsrf(req);
  if (csrfErr) return csrfErr;

  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  if (!checkRateLimit(`invoice:${auth.user.id}`, 15, 60_000)) {
    return jsonNoStore(
      { error: 'Invoice creation rate limit exceeded. Please wait before creating another invoice.' },
      429
    );
  }

  const body = (await req.json()) as {
    article_id?: string;
    expiry_seconds?: number;
    simulate_fulfillment_failure?: boolean;
  };

  if (!body.article_id) {
    return jsonNoStore({ error: 'article_id is required' }, 400);
  }

  try {
    const intent = await createArticlePurchaseIntent({
      userId: auth.user.id,
      articleId: body.article_id,
      expirySeconds: body.expiry_seconds,
      simulateFulfillmentFailure: Boolean(body.simulate_fulfillment_failure),
    });
    return jsonNoStore({ payment_intent: intent }, 201);
  } catch (err) {
    return jsonNoStore(
      { error: err instanceof Error ? err.message : 'Unable to create purchase invoice' },
      400
    );
  }
}
