import crypto from 'node:crypto';
import { NextRequest } from 'next/server';
import { getDb, withTransaction } from '@/lib/server/db';
import {
  checkRateLimit,
  getSessionFromRequest,
  hashPassword,
  SESSION_COOKIE_NAME,
  signSessionToken,
  verifyPassword,
} from '@/lib/server/crypto';
import { checkCsrf, getUserById, jsonNoStore, requireAuth } from '@/lib/server/http';
import { validateLightningDestination } from '@/lib/server/lightning';
import { stripDangerousHtml } from '@/lib/server/sanitize';

function setSessionCookie(
  res: ReturnType<typeof jsonNoStore>,
  token: string
) {
  res.cookies.set(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'none',
    partitioned: true,
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  });
  return res;
}

export async function GET(req: NextRequest) {
  const db = getDb();
  const session = await getSessionFromRequest(req);
  const currentUser = session ? getUserById(session.userId) : null;

  let profile: Record<string, unknown> | null = null;
  if (currentUser) {
    profile = (db
      .prepare(
        `SELECT bio, publication_name, lightning_destination, destination_verified
         FROM author_profiles WHERE user_id = ?`
      )
      .get(currentUser.id) as Record<string, unknown>) || null;
  }

  const adminPassConfigured = Boolean(
    process.env.LUMEN_ADMIN_PASSCODE && process.env.LUMEN_ADMIN_PASSCODE.length > 0
  );
  const adminClaimedRow = db
    .prepare(`SELECT value FROM system_config WHERE key = 'admin_passcode_hash'`)
    .get() as { value: string } | undefined;

  const demoAccounts = [
    { email: 'reader@lumen.press', display_name: 'Clara Beaumont (Reader)', role: 'reader' },
    { email: 'eleanor@lumen.press', display_name: 'Eleanor Hart (Author)', role: 'author' },
    { email: 'daniel@lumen.press', display_name: 'Daniel Moss (Author)', role: 'author' },
    { email: 'amelia@lumen.press', display_name: 'Amelia Reed (Author)', role: 'author' },
  ];

  return jsonNoStore({
    user: currentUser,
    profile,
    provider_mode: process.env.LIGHTNING_LIVE_ENABLED === 'true' ? 'live' : 'simulator',
    admin_configured: adminPassConfigured || Boolean(adminClaimedRow),
    demo_accounts: demoAccounts,
  });
}

export async function POST(req: NextRequest) {
  const csrfErr = checkCsrf(req);
  if (csrfErr) return csrfErr;

  const ip = req.headers.get('x-forwarded-for') || 'local';
  if (!checkRateLimit(`auth:${ip}`, 30, 60_000)) {
    return jsonNoStore({ error: 'Too many authentication attempts. Please wait a minute.' }, 429);
  }

  const body = (await req.json()) as {
    action?: string;
    email?: string;
    password?: string;
    display_name?: string;
    handle?: string;
    passcode?: string;
  };

  const db = getDb();
  const action = body.action || 'login';

  if (action === 'logout') {
    const res = jsonNoStore({ ok: true, user: null });
    res.cookies.delete(SESSION_COOKIE_NAME);
    return res;
  }

  if (action === 'demo_switch') {
    const email = (body.email || '').trim().toLowerCase();
    const row = db
      .prepare(
        `SELECT id, email, display_name, handle, role, demo_balance_sats, created_at
         FROM users WHERE email = ?`
      )
      .get(email) as {
      id: string;
      email: string;
      display_name: string;
      handle: string;
      role: 'reader' | 'author' | 'admin';
      demo_balance_sats: number;
      created_at: string;
    } | undefined;
    if (!row) {
      return jsonNoStore({ error: 'Demo account not found' }, 404);
    }
    const token = signSessionToken({ userId: row.id, role: row.role });
    return setSessionCookie(jsonNoStore({ user: row, token }), token);
  }

  if (action === 'login') {
    const email = (body.email || '').trim().toLowerCase();
    const password = body.password || '';
    const row = db
      .prepare(`SELECT * FROM users WHERE email = ?`)
      .get(email) as Record<string, unknown> | undefined;
    if (!row || !verifyPassword(password, row.password_hash as string)) {
      return jsonNoStore({ error: 'Invalid email or password' }, 401);
    }
    const user = getUserById(row.id as string)!;
    const token = signSessionToken({ userId: user.id, role: user.role });
    return setSessionCookie(jsonNoStore({ user, token }), token);
  }

  if (action === 'register') {
    const email = (body.email || '').trim().toLowerCase();
    const password = body.password || '';
    const displayName = stripDangerousHtml(body.display_name || '').trim();
    const handleRaw = (body.handle || email.split('@')[0] || 'writer')
      .toLowerCase()
      .replace(/[^a-z0-9_-]/g, '');

    if (!email || !email.includes('@') || password.length < 6 || !displayName) {
      return jsonNoStore(
        { error: 'Valid email, display name, and password (min 6 chars) are required' },
        400
      );
    }

    const exists = db
      .prepare(`SELECT id FROM users WHERE email = ? OR handle = ?`)
      .get(email, handleRaw);
    if (exists) {
      return jsonNoStore({ error: 'Email or handle is already registered' }, 409);
    }

    const userId = `usr_${crypto.randomUUID().slice(0, 12)}`;
    const now = new Date().toISOString();
    const passHash = hashPassword(password);

    withTransaction(db, () => {
      db.prepare(
        `INSERT INTO users (id, email, password_hash, display_name, handle, role, demo_balance_sats, created_at)
         VALUES (?, ?, ?, ?, ?, 'author', 2500, ?)`
      ).run(userId, email, passHash, displayName, handleRaw, now);
      db.prepare(
        `INSERT INTO author_profiles (user_id, bio, publication_name, lightning_destination, destination_verified, updated_at)
         VALUES (?, '', ?, NULL, 0, ?)`
      ).run(userId, `${displayName}'s Journal`, now);
      db.prepare(
        `INSERT INTO publications (id, owner_user_id, slug, name, tagline, created_at)
         VALUES (?, ?, ?, ?, '', ?)`
      ).run(`pub_${handleRaw}`, userId, handleRaw, `${displayName}'s Journal`, now);
    });

    const user = getUserById(userId)!;
    const token = signSessionToken({ userId: user.id, role: user.role });
    return setSessionCookie(jsonNoStore({ user, token }, 201), token);
  }

  if (action === 'claim_admin') {
    const auth = await requireAuth(req);
    if (!auth.ok) return auth.response;

    const passcode = (body.passcode || '').trim();
    if (passcode.length < 8) {
      return jsonNoStore({ error: 'Admin passcode must be at least 8 characters' }, 400);
    }

    const envPass = process.env.LUMEN_ADMIN_PASSCODE;
    if (envPass && envPass.length > 0) {
      if (passcode !== envPass) {
        return jsonNoStore({ error: 'Invalid administrator passcode' }, 403);
      }
    } else {
      const existingClaim = db
        .prepare(`SELECT value FROM system_config WHERE key = 'admin_passcode_hash'`)
        .get() as { value: string } | undefined;

      if (!existingClaim) {
        // First-run atomic admin claim
        const hashed = hashPassword(passcode);
        db.prepare(
          `INSERT INTO system_config (key, value, updated_at) VALUES ('admin_passcode_hash', ?, ?)`
        ).run(hashed, new Date().toISOString());
      } else if (!verifyPassword(passcode, existingClaim.value)) {
        return jsonNoStore({ error: 'Invalid administrator passcode' }, 403);
      }
    }

    db.prepare(`UPDATE users SET role = 'admin' WHERE id = ?`).run(auth.user.id);
    const updated = getUserById(auth.user.id)!;
    const token = signSessionToken({ userId: updated.id, role: 'admin' });
    return setSessionCookie(jsonNoStore({ user: updated, token }), token);
  }

  return jsonNoStore({ error: 'Unsupported auth action' }, 400);
}

export async function PATCH(req: NextRequest) {
  const csrfErr = checkCsrf(req);
  if (csrfErr) return csrfErr;

  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  const body = (await req.json()) as {
    display_name?: string;
    bio?: string;
    publication_name?: string;
    lightning_destination?: string;
  };

  const db = getDb();
  const now = new Date().toISOString();
  const displayName = body.display_name
    ? stripDangerousHtml(body.display_name).trim().slice(0, 80)
    : auth.user.display_name;
  const bio = stripDangerousHtml(body.bio || '').trim().slice(0, 500);
  const pubName = stripDangerousHtml(body.publication_name || '').trim().slice(0, 100);
  const lnDest = (body.lightning_destination || '').trim();

  if (lnDest && !validateLightningDestination(lnDest)) {
    return jsonNoStore(
      { error: 'Lightning destination must be a valid Lightning Address (user@domain) or LNURL' },
      400
    );
  }

  withTransaction(db, () => {
    db.prepare(`UPDATE users SET display_name = ? WHERE id = ?`).run(
      displayName,
      auth.user.id
    );
    db.prepare(
      `INSERT INTO author_profiles (user_id, bio, publication_name, lightning_destination, destination_verified, updated_at)
       VALUES (?, ?, ?, ?, ?, ?)
       ON CONFLICT(user_id) DO UPDATE SET
         bio = excluded.bio,
         publication_name = excluded.publication_name,
         lightning_destination = excluded.lightning_destination,
         destination_verified = excluded.destination_verified,
         updated_at = excluded.updated_at`
    ).run(auth.user.id, bio, pubName, lnDest || null, lnDest ? 1 : 0, now);

    if (pubName) {
      db.prepare(`UPDATE publications SET name = ? WHERE owner_user_id = ?`).run(
        pubName,
        auth.user.id
      );
    }
  });

  return jsonNoStore({ ok: true, user: getUserById(auth.user.id) });
}
