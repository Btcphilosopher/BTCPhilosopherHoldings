import { NextRequest } from 'next/server';
import {
  getPaymentIntentById,
  pollExternalInvoiceStatus,
} from '@/lib/server/accounting';
import { jsonNoStore, requireAuth } from '@/lib/server/http';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ payment_intent_id: string }> }
) {
  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  const { payment_intent_id } = await context.params;
  let intent = getPaymentIntentById(payment_intent_id);
  if (!intent) {
    return jsonNoStore({ error: 'Payment intent not found' }, 404);
  }

  if (intent.user_id !== auth.user.id && auth.user.role !== 'admin') {
    return jsonNoStore({ error: 'Forbidden' }, 403);
  }

  if (intent.provider !== 'simulator' && intent.status === 'awaiting_payment') {
    intent = await pollExternalInvoiceStatus(payment_intent_id);
  }

  return jsonNoStore({ payment_intent: intent });
}
