import { NextRequest } from 'next/server';
import { getAuthorStatement } from '@/lib/server/accounting';
import { jsonNoStore, requireAuth } from '@/lib/server/http';

export async function GET(req: NextRequest) {
  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  const statement = getAuthorStatement(auth.user.id);
  return jsonNoStore({ statement });
}
