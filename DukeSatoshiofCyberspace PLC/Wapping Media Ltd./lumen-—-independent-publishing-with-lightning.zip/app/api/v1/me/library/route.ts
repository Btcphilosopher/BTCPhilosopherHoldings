import { NextRequest } from 'next/server';
import { getDb } from '@/lib/server/db';
import { listPublicArticles } from '@/lib/server/articles';
import { checkCsrf, jsonNoStore, requireAuth } from '@/lib/server/http';

export async function GET(req: NextRequest) {
  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  const db = getDb();
  const purchasedRows = db
    .prepare(
      `SELECT e.article_id, e.granted_at, p.id AS purchase_id, p.total_sats, p.includes_future_revisions
       FROM entitlements e
       JOIN purchases p ON p.id = e.purchase_id
       WHERE e.user_id = ? AND e.revoked_at IS NULL
       ORDER BY e.granted_at DESC`
    )
    .all(auth.user.id) as {
    article_id: string;
    granted_at: string;
    purchase_id: string;
    total_sats: number;
    includes_future_revisions: number;
  }[];

  const bookmarkedRows = db
    .prepare(`SELECT article_id, created_at FROM bookmarks WHERE user_id = ? ORDER BY created_at DESC`)
    .all(auth.user.id) as { article_id: string; created_at: string }[];

  const followingRows = db
    .prepare(
      `SELECT u.id, u.handle, u.display_name, ap.publication_name, ap.bio
       FROM follows f
       JOIN users u ON u.id = f.author_user_id
       LEFT JOIN author_profiles ap ON ap.user_id = u.id
       WHERE f.follower_user_id = ?
       ORDER BY f.created_at DESC`
    )
    .all(auth.user.id);

  const allPublic = listPublicArticles({ viewerUserId: auth.user.id });
  const byId = new Map(allPublic.map((a) => [a.id, a]));

  const purchased = purchasedRows
    .map((r) => {
      const art = byId.get(r.article_id);
      if (!art) return null;
      return {
        ...art,
        purchase_id: r.purchase_id,
        granted_at: r.granted_at,
        paid_sats: r.total_sats,
      };
    })
    .filter(Boolean);

  const saved = bookmarkedRows
    .map((r) => byId.get(r.article_id))
    .filter(Boolean);

  return jsonNoStore({
    purchased,
    saved,
    following: followingRows,
  });
}

export async function POST(req: NextRequest) {
  const csrfErr = checkCsrf(req);
  if (csrfErr) return csrfErr;

  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  const body = (await req.json()) as {
    action?: 'toggle_bookmark' | 'toggle_follow';
    article_id?: string;
    author_user_id?: string;
  };

  const db = getDb();
  const now = new Date().toISOString();

  if (body.action === 'toggle_bookmark' && body.article_id) {
    const exists = db
      .prepare(`SELECT 1 FROM bookmarks WHERE user_id = ? AND article_id = ?`)
      .get(auth.user.id, body.article_id);
    if (exists) {
      db.prepare(`DELETE FROM bookmarks WHERE user_id = ? AND article_id = ?`).run(
        auth.user.id,
        body.article_id
      );
      return jsonNoStore({ bookmarked: false });
    } else {
      db.prepare(
        `INSERT INTO bookmarks (user_id, article_id, created_at) VALUES (?, ?, ?)`
      ).run(auth.user.id, body.article_id, now);
      return jsonNoStore({ bookmarked: true });
    }
  }

  if (body.action === 'toggle_follow' && body.author_user_id) {
    if (body.author_user_id === auth.user.id) {
      return jsonNoStore({ error: 'Cannot follow your own account' }, 400);
    }
    const exists = db
      .prepare(`SELECT 1 FROM follows WHERE follower_user_id = ? AND author_user_id = ?`)
      .get(auth.user.id, body.author_user_id);
    if (exists) {
      db.prepare(
        `DELETE FROM follows WHERE follower_user_id = ? AND author_user_id = ?`
      ).run(auth.user.id, body.author_user_id);
      return jsonNoStore({ following: false });
    } else {
      db.prepare(
        `INSERT INTO follows (follower_user_id, author_user_id, created_at) VALUES (?, ?, ?)`
      ).run(auth.user.id, body.author_user_id, now);
      return jsonNoStore({ following: true });
    }
  }

  return jsonNoStore({ error: 'Invalid library action' }, 400);
}
