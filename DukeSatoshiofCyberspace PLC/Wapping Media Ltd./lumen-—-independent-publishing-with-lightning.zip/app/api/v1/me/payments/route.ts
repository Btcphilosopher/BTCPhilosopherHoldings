import { NextRequest } from 'next/server';
import { expireStaleInvoices } from '@/lib/server/accounting';
import { getDb } from '@/lib/server/db';
import { jsonNoStore, requireAuth } from '@/lib/server/http';

export async function GET(req: NextRequest) {
  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  expireStaleInvoices();
  const db = getDb();

  const paymentIntents = db
    .prepare(
      `SELECT pi.*, li.provider_invoice_id, li.payment_hash, li.bolt11,
              r.title AS article_title, a.slug AS article_slug,
              u.display_name AS recipient_name, u.handle AS recipient_handle
       FROM payment_intents pi
       LEFT JOIN lightning_invoices li ON li.payment_intent_id = pi.id
       LEFT JOIN articles a ON a.id = pi.article_id
       LEFT JOIN article_revisions r ON r.id = a.current_revision_id
       LEFT JOIN users u ON u.id = pi.recipient_user_id
       WHERE pi.user_id = ?
       ORDER BY pi.created_at DESC
       LIMIT 50`
    )
    .all(auth.user.id);

  const purchases = db
    .prepare(
      `SELECT p.*, r.title AS article_title, a.slug AS article_slug,
              u.display_name AS author_name, rr.status AS refund_status, rr.id AS refund_request_id
       FROM purchases p
       JOIN articles a ON a.id = p.article_id
       JOIN article_revisions r ON r.id = p.revision_id
       JOIN users u ON u.id = a.author_user_id
       LEFT JOIN refund_requests rr ON rr.purchase_id = p.id
       WHERE p.user_id = ?
       ORDER BY p.created_at DESC
       LIMIT 50`
    )
    .all(auth.user.id);

  const tips = db
    .prepare(
      `SELECT t.*, u.display_name AS recipient_name, u.handle AS recipient_handle,
              r.title AS article_title, a.slug AS article_slug
       FROM tips t
       JOIN users u ON u.id = t.recipient_user_id
       LEFT JOIN articles a ON a.id = t.article_id
       LEFT JOIN article_revisions r ON r.id = a.current_revision_id
       WHERE t.user_id = ?
       ORDER BY t.created_at DESC
       LIMIT 50`
    )
    .all(auth.user.id);

  return jsonNoStore({
    is_demo: true,
    demo_balance_sats: auth.user.demo_balance_sats,
    payment_intents: paymentIntents,
    purchases,
    tips,
  });
}
