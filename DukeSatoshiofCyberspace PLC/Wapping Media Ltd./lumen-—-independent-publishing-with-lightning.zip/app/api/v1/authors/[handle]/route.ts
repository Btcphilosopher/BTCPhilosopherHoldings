import { NextRequest } from 'next/server';
import { listPublicArticles } from '@/lib/server/articles';
import { getSessionFromRequest } from '@/lib/server/crypto';
import { getDb } from '@/lib/server/db';
import { jsonNoStore } from '@/lib/server/http';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ handle: string }> }
) {
  const { handle } = await context.params;
  const session = await getSessionFromRequest(req);
  const db = getDb();

  const author = db
    .prepare(
      `SELECT u.id, u.handle, u.display_name, u.created_at,
              ap.bio, ap.publication_name
       FROM users u
       LEFT JOIN author_profiles ap ON ap.user_id = u.id
       WHERE u.handle = ?`
    )
    .get(handle) as Record<string, unknown> | undefined;

  if (!author) {
    return jsonNoStore({ error: 'Author not found' }, 404);
  }

  const followersCount = db
    .prepare(`SELECT COUNT(*) AS cnt FROM follows WHERE author_user_id = ?`)
    .get(author.id as string) as { cnt: number };

  const viewerFollowing = session
    ? Boolean(
        db
          .prepare(
            `SELECT 1 FROM follows WHERE follower_user_id = ? AND author_user_id = ?`
          )
          .get(session.userId, author.id as string)
      )
    : false;

  const articles = listPublicArticles({
    authorHandle: handle,
    viewerUserId: session?.userId || null,
  });

  return jsonNoStore({
    author: {
      id: author.id,
      handle: author.handle,
      display_name: author.display_name,
      bio: author.bio || '',
      publication_name: author.publication_name || 'Independent',
      followers_count: Number(followersCount.cnt),
      viewer_following: viewerFollowing,
      created_at: author.created_at,
    },
    articles,
  });
}
