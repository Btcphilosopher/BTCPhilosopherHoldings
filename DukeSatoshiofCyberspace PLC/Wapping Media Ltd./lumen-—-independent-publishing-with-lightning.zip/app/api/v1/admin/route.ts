import { NextRequest } from 'next/server';
import {
  expireStaleInvoices,
  reconcilePayout,
  reconcilePendingFulfillments,
  reviewRefundRequest,
} from '@/lib/server/accounting';
import { transitionArticleStatus } from '@/lib/server/articles';
import { getDb } from '@/lib/server/db';
import { checkCsrf, jsonNoStore, requireAuth } from '@/lib/server/http';
import { LifecycleStatus } from '@/lib/server/types';

export async function GET(req: NextRequest) {
  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  if (auth.user.role !== 'admin') {
    return jsonNoStore({ error: 'Administrator role required' }, 403);
  }

  expireStaleInvoices();
  const db = getDb();

  const articles = db
    .prepare(
      `SELECT a.id, a.slug, a.topic, a.status, a.published_at, r.title, u.display_name AS author_name
       FROM articles a
       JOIN article_revisions r ON r.id = a.current_revision_id
       JOIN users u ON u.id = a.author_user_id
       ORDER BY a.updated_at DESC
       LIMIT 50`
    )
    .all();

  const refundRequests = db
    .prepare(
      `SELECT rr.*, r.title AS article_title, u.display_name AS requester_name
       FROM refund_requests rr
       JOIN purchases p ON p.id = rr.purchase_id
       JOIN articles a ON a.id = p.article_id
       JOIN article_revisions r ON r.id = p.revision_id
       JOIN users u ON u.id = rr.requester_user_id
       ORDER BY rr.created_at DESC`
    )
    .all();

  const pendingFulfillments = db
    .prepare(
      `SELECT pi.*, r.title AS article_title, u.display_name AS buyer_name
       FROM payment_intents pi
       LEFT JOIN articles a ON a.id = pi.article_id
       LEFT JOIN article_revisions r ON r.id = a.current_revision_id
       JOIN users u ON u.id = pi.user_id
       WHERE (pi.status = 'settled' AND pi.fulfillment_status IN ('pending', 'failed_retryable'))
          OR pi.status = 'reconciliation_required'
       ORDER BY pi.created_at DESC`
    )
    .all();

  const payouts = db
    .prepare(
      `SELECT p.*, u.display_name AS author_name, u.handle AS author_handle
       FROM payouts p
       JOIN users u ON u.id = p.author_user_id
       ORDER BY p.created_at DESC
       LIMIT 30`
    )
    .all();

  const auditLogs = db
    .prepare(
      `SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 40`
    )
    .all();

  return jsonNoStore({
    articles,
    refund_requests: refundRequests,
    pending_fulfillments: pendingFulfillments,
    payouts,
    audit_logs: auditLogs,
  });
}

export async function POST(req: NextRequest) {
  const csrfErr = checkCsrf(req);
  if (csrfErr) return csrfErr;

  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  if (auth.user.role !== 'admin') {
    return jsonNoStore({ error: 'Administrator role required' }, 403);
  }

  const body = (await req.json()) as {
    action?: string;
    refund_id?: string;
    decision?: 'approve' | 'reject';
    note?: string;
    payout_id?: string;
    article_id?: string;
    status?: LifecycleStatus;
  };

  try {
    if (body.action === 'reconcile_fulfillments') {
      const res = reconcilePendingFulfillments(auth.user.id);
      return jsonNoStore({ ok: true, ...res });
    }

    if (body.action === 'review_refund' && body.refund_id && body.decision) {
      const updated = reviewRefundRequest({
        refundId: body.refund_id,
        reviewerUserId: auth.user.id,
        decision: body.decision,
        note: body.note,
      });
      return jsonNoStore({ ok: true, refund_request: updated });
    }

    if (body.action === 'reconcile_payout' && body.payout_id) {
      const updated = await reconcilePayout(body.payout_id, auth.user.id);
      return jsonNoStore({ ok: true, payout: updated });
    }

    if (body.action === 'moderate_article' && body.article_id && body.status) {
      const updated = transitionArticleStatus({
        articleId: body.article_id,
        actorUserId: auth.user.id,
        actorRole: auth.user.role,
        targetStatus: body.status,
      });
      return jsonNoStore({ ok: true, article: updated });
    }

    return jsonNoStore({ error: 'Invalid admin action' }, 400);
  } catch (err) {
    return jsonNoStore(
      { error: err instanceof Error ? err.message : 'Admin operation failed' },
      400
    );
  }
}
