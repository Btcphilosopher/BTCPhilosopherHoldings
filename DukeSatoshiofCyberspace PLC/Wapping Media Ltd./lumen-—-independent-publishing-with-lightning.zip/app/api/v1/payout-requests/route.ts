import crypto from 'node:crypto';
import { NextRequest } from 'next/server';
import { requestAuthorPayout } from '@/lib/server/accounting';
import { getDb } from '@/lib/server/db';
import { checkCsrf, jsonNoStore, requireAuth } from '@/lib/server/http';

export async function GET(req: NextRequest) {
  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  const db = getDb();
  const payouts = db
    .prepare(`SELECT * FROM payouts WHERE author_user_id = ? ORDER BY created_at DESC`)
    .all(auth.user.id);
  return jsonNoStore({ payouts });
}

export async function POST(req: NextRequest) {
  const csrfErr = checkCsrf(req);
  if (csrfErr) return csrfErr;

  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  const body = (await req.json()) as {
    destination?: string;
    amount_sats?: number;
    idempotency_key?: string;
  };

  if (!body.destination || !Number.isInteger(body.amount_sats)) {
    return jsonNoStore(
      { error: 'destination and integer amount_sats are required' },
      400
    );
  }

  try {
    const payout = await requestAuthorPayout({
      authorUserId: auth.user.id,
      destination: body.destination,
      amountSats: Number(body.amount_sats),
      idempotencyKey: body.idempotency_key || `po_key_${crypto.randomUUID()}`,
    });
    return jsonNoStore({ payout }, 201);
  } catch (err) {
    return jsonNoStore(
      { error: err instanceof Error ? err.message : 'Unable to process payout request' },
      400
    );
  }
}
