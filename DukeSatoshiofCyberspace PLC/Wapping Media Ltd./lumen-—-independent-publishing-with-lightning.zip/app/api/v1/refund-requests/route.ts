import { NextRequest } from 'next/server';
import { createRefundRequest } from '@/lib/server/accounting';
import { getDb } from '@/lib/server/db';
import { checkCsrf, jsonNoStore, requireAuth } from '@/lib/server/http';

export async function GET(req: NextRequest) {
  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  const db = getDb();
  const rows = db
    .prepare(
      `SELECT rr.*, r.title AS article_title
       FROM refund_requests rr
       JOIN purchases p ON p.id = rr.purchase_id
       JOIN articles a ON a.id = p.article_id
       JOIN article_revisions r ON r.id = p.revision_id
       WHERE rr.requester_user_id = ?
       ORDER BY rr.created_at DESC`
    )
    .all(auth.user.id);

  return jsonNoStore({ refund_requests: rows });
}

export async function POST(req: NextRequest) {
  const csrfErr = checkCsrf(req);
  if (csrfErr) return csrfErr;

  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  const body = (await req.json()) as {
    purchase_id?: string;
    reason?: string;
  };

  if (!body.purchase_id || !body.reason?.trim()) {
    return jsonNoStore({ error: 'purchase_id and reason are required' }, 400);
  }

  try {
    const created = createRefundRequest({
      purchaseId: body.purchase_id,
      userId: auth.user.id,
      reason: body.reason,
    });
    return jsonNoStore({ refund_request: created }, 201);
  } catch (err) {
    return jsonNoStore(
      { error: err instanceof Error ? err.message : 'Unable to submit refund request' },
      400
    );
  }
}
