import { NextRequest } from 'next/server';
import { createAuthorTipIntent } from '@/lib/server/accounting';
import { checkRateLimit } from '@/lib/server/crypto';
import { checkCsrf, jsonNoStore, requireAuth } from '@/lib/server/http';

export async function POST(req: NextRequest) {
  const csrfErr = checkCsrf(req);
  if (csrfErr) return csrfErr;

  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  if (!checkRateLimit(`invoice:${auth.user.id}`, 15, 60_000)) {
    return jsonNoStore(
      { error: 'Invoice creation rate limit exceeded. Please wait before creating another invoice.' },
      429
    );
  }

  const body = (await req.json()) as {
    recipient_user_id?: string;
    article_id?: string | null;
    amount_sats?: number;
    note?: string;
    expiry_seconds?: number;
  };

  if (!body.recipient_user_id || !Number.isInteger(body.amount_sats)) {
    return jsonNoStore(
      { error: 'recipient_user_id and integer amount_sats are required' },
      400
    );
  }

  try {
    const intent = await createAuthorTipIntent({
      userId: auth.user.id,
      recipientUserId: body.recipient_user_id,
      articleId: body.article_id || null,
      amountSats: Number(body.amount_sats),
      note: body.note,
      expirySeconds: body.expiry_seconds,
    });
    return jsonNoStore({ payment_intent: intent }, 201);
  } catch (err) {
    return jsonNoStore(
      { error: err instanceof Error ? err.message : 'Unable to create tip invoice' },
      400
    );
  }
}
