import { NextRequest } from 'next/server';
import { getArticleDetail, saveArticleRevision } from '@/lib/server/articles';
import { getSessionFromRequest } from '@/lib/server/crypto';
import { checkCsrf, jsonNoStore, requireAuth } from '@/lib/server/http';
import { TopicSlug } from '@/lib/server/types';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ article_id: string }> }
) {
  const { article_id } = await context.params;
  const session = await getSessionFromRequest(req);
  const trackView = req.nextUrl.searchParams.get('track_view') === '1';

  const article = getArticleDetail({
    idOrSlug: article_id,
    viewerUserId: session?.userId || null,
    viewerRole: session?.role || null,
    incrementView: trackView,
  });

  if (!article) {
    return jsonNoStore({ error: 'Article not found' }, 404);
  }

  return jsonNoStore({ article });
}

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ article_id: string }> }
) {
  const csrfErr = checkCsrf(req);
  if (csrfErr) return csrfErr;

  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  const { article_id } = await context.params;
  const body = (await req.json()) as {
    title?: string;
    subtitle?: string;
    topic?: TopicSlug;
    body_markdown?: string;
    cover_image_url?: string;
    cover_image_alt?: string;
    is_paid?: boolean;
    price_sats?: number;
    preview_paragraph_count?: number;
    includes_future_revisions?: boolean;
  };

  try {
    const result = saveArticleRevision({
      articleId: article_id,
      authorUserId: auth.user.id,
      title: body.title || 'Untitled essay',
      subtitle: body.subtitle || '',
      topic: body.topic || 'culture',
      bodyMarkdown: body.body_markdown || '',
      coverImageUrl: body.cover_image_url,
      coverImageAlt: body.cover_image_alt,
      isPaid: Boolean(body.is_paid),
      priceSats: Number.isInteger(body.price_sats) ? Number(body.price_sats) : 100,
      previewParagraphCount: Number(body.preview_paragraph_count || 2),
      includesFutureRevisions: body.includes_future_revisions !== false,
      createSnapshot: false,
    });
    return jsonNoStore(result);
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unable to save draft';
    const status = msg.startsWith('Forbidden') ? 403 : 400;
    return jsonNoStore({ error: msg }, status);
  }
}
