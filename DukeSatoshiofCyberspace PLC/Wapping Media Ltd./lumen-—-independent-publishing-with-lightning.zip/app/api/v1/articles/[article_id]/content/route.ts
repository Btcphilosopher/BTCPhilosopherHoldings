import { NextRequest } from 'next/server';
import { getArticleDetail } from '@/lib/server/articles';
import { getSessionFromRequest } from '@/lib/server/crypto';
import { jsonNoStore } from '@/lib/server/http';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ article_id: string }> }
) {
  const { article_id } = await context.params;
  const session = await getSessionFromRequest(req);

  const article = getArticleDetail({
    idOrSlug: article_id,
    viewerUserId: session?.userId || null,
    viewerRole: session?.role || null,
    incrementView: false,
  });

  if (!article) {
    return jsonNoStore({ error: 'Article not found' }, 404);
  }

  if (!article.viewer_has_access || !article.body_blocks) {
    return jsonNoStore(
      {
        error: 'Payment required to access full article content',
        code: 'PAYMENT_REQUIRED',
        offer: {
          price_sats: article.offer.price_sats,
          customer_fee_sats: article.offer.customer_fee_sats,
          total_sats: article.offer.price_sats + article.offer.customer_fee_sats,
          fee_policy_version: article.offer.fee_policy_version,
        },
      },
      402
    );
  }

  return jsonNoStore({
    article_id: article.id,
    revision_number: article.current_revision_number,
    revision_policy_notice: article.revision_policy_notice,
    body_blocks: article.body_blocks,
  });
}
