import { NextRequest } from 'next/server';
import { transitionArticleStatus } from '@/lib/server/articles';
import { checkCsrf, jsonNoStore, requireAuth } from '@/lib/server/http';
import { LifecycleStatus } from '@/lib/server/types';

const ALLOWED_TARGETS = new Set<LifecycleStatus>([
  'draft',
  'preview',
  'published',
  'revised',
  'withdrawn',
]);

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ article_id: string }> }
) {
  const csrfErr = checkCsrf(req);
  if (csrfErr) return csrfErr;

  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  const { article_id } = await context.params;
  const body = (await req.json()) as { status?: LifecycleStatus };
  const targetStatus = body.status || 'published';

  if (!ALLOWED_TARGETS.has(targetStatus)) {
    return jsonNoStore({ error: 'Invalid lifecycle status' }, 400);
  }

  try {
    const res = transitionArticleStatus({
      articleId: article_id,
      actorUserId: auth.user.id,
      actorRole: auth.user.role,
      targetStatus,
    });
    return jsonNoStore(res);
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unable to update status';
    return jsonNoStore({ error: msg }, msg.startsWith('Forbidden') ? 403 : 400);
  }
}
