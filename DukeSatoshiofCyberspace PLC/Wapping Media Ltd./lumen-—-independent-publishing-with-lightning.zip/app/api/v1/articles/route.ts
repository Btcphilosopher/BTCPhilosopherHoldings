import { NextRequest } from 'next/server';
import {
  createDraftArticle,
  listAuthorDashboardArticles,
  listPublicArticles,
} from '@/lib/server/articles';
import { getSessionFromRequest } from '@/lib/server/crypto';
import { checkCsrf, jsonNoStore, requireAuth } from '@/lib/server/http';
import { TopicSlug } from '@/lib/server/types';

const VALID_TOPICS = new Set<TopicSlug>([
  'technology',
  'culture',
  'science',
  'economics',
  'design',
]);

export async function GET(req: NextRequest) {
  const session = await getSessionFromRequest(req);
  const sp = req.nextUrl.searchParams;
  const mine = sp.get('mine') === '1';

  if (mine) {
    if (!session) {
      return jsonNoStore({ error: 'Authentication required' }, 401);
    }
    const items = listAuthorDashboardArticles(session.userId);
    return jsonNoStore({ articles: items });
  }

  const topic = sp.get('topic');
  const search = sp.get('q');
  const authorHandle = sp.get('author');
  const followingOnly = sp.get('following') === '1';

  if (followingOnly && !session) {
    return jsonNoStore({ articles: [], requires_auth: true });
  }

  const articles = listPublicArticles({
    topic,
    search,
    authorHandle,
    followingForUserId: followingOnly ? session?.userId : null,
    viewerUserId: session?.userId || null,
  });

  return jsonNoStore({ articles });
}

export async function POST(req: NextRequest) {
  const csrfErr = checkCsrf(req);
  if (csrfErr) return csrfErr;

  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  const body = (await req.json()) as {
    title?: string;
    subtitle?: string;
    topic?: TopicSlug;
    body_markdown?: string;
    cover_image_url?: string;
    cover_image_alt?: string;
    is_paid?: boolean;
    price_sats?: number;
    preview_paragraph_count?: number;
    includes_future_revisions?: boolean;
  };

  const topic = body.topic && VALID_TOPICS.has(body.topic) ? body.topic : 'culture';

  try {
    const created = createDraftArticle({
      authorUserId: auth.user.id,
      title: body.title || 'Untitled essay',
      subtitle: body.subtitle || '',
      topic,
      bodyMarkdown: body.body_markdown || '',
      coverImageUrl: body.cover_image_url,
      coverImageAlt: body.cover_image_alt,
      isPaid: Boolean(body.is_paid),
      priceSats: Number.isInteger(body.price_sats) ? Number(body.price_sats) : 100,
      previewParagraphCount: Number(body.preview_paragraph_count || 2),
      includesFutureRevisions: body.includes_future_revisions !== false,
    });
    return jsonNoStore(created, 201);
  } catch (err) {
    return jsonNoStore(
      { error: err instanceof Error ? err.message : 'Unable to create draft' },
      400
    );
  }
}
