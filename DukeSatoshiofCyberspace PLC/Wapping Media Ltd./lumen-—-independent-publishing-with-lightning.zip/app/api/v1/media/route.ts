import crypto from 'node:crypto';
import { NextRequest } from 'next/server';
import { getDb } from '@/lib/server/db';
import { checkCsrf, jsonNoStore, requireAuth } from '@/lib/server/http';
import { stripDangerousHtml } from '@/lib/server/sanitize';
import { storeMediaUpload } from '@/lib/server/storage';

export async function POST(req: NextRequest) {
  const csrfErr = checkCsrf(req);
  if (csrfErr) return csrfErr;

  const auth = await requireAuth(req);
  if (!auth.ok) return auth.response;

  const formData = await req.formData();
  const file = formData.get('file');
  const altText = stripDangerousHtml(String(formData.get('alt_text') || '')).trim();

  if (!(file instanceof File)) {
    return jsonNoStore({ error: 'Image file is required' }, 400);
  }

  try {
    const buffer = Buffer.from(await file.arrayBuffer());
    const stored = await storeMediaUpload(buffer, file.type);
    const db = getDb();
    const id = `med_${crypto.randomUUID()}`;
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO media_assets (id, owner_user_id, object_key, public_url, mime_type, size_bytes, sha256, alt_text, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      auth.user.id,
      stored.objectKey,
      stored.publicUrl,
      stored.mimeType,
      stored.sizeBytes,
      stored.sha256,
      altText || 'Uploaded editorial illustration',
      now
    );

    return jsonNoStore(
      {
        media: {
          id,
          object_key: stored.objectKey,
          public_url: stored.publicUrl,
          mime_type: stored.mimeType,
          size_bytes: stored.sizeBytes,
          alt_text: altText || 'Uploaded editorial illustration',
        },
      },
      201
    );
  } catch (err) {
    return jsonNoStore(
      { error: err instanceof Error ? err.message : 'Image upload failed' },
      400
    );
  }
}
