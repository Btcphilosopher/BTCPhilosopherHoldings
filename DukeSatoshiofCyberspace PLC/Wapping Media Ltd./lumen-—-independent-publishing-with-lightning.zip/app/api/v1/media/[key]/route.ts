import { NextRequest, NextResponse } from 'next/server';
import { readStoredMedia } from '@/lib/server/storage';

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ key: string }> }
) {
  const { key } = await context.params;
  const media = readStoredMedia(key);
  if (!media) {
    return NextResponse.json({ error: 'Media asset not found' }, { status: 404 });
  }
  return new NextResponse(new Uint8Array(media.buffer), {
    status: 200,
    headers: {
      'Content-Type': media.mimeType,
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'public, max-age=86400',
    },
  });
}
