'use client';

import React, { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { SiteHeader } from '@/components/SiteHeader';
import { SiteFooter } from '@/components/SiteFooter';
import { useLumenAuth } from '@/components/LumenAuthContext';

interface AdminData {
  articles: Array<{
    id: string;
    slug: string;
    title: string;
    author_name: string;
    topic: string;
    status: string;
  }>;
  refund_requests: Array<{
    id: string;
    article_title: string;
    requester_name: string;
    requested_amount_sats: number;
    reason: string;
    status: string;
    outgoing_reference: string | null;
  }>;
  pending_fulfillments: Array<{
    id: string;
    kind: string;
    article_title?: string;
    buyer_name: string;
    total_sats: number;
    status: string;
    fulfillment_status: string;
  }>;
  payouts: Array<{
    id: string;
    author_name: string;
    destination: string;
    amount_sats: number;
    status: string;
    message: string;
  }>;
  audit_logs: Array<{
    id: string;
    action: string;
    entity_type: string;
    entity_id: string;
    details_json: string;
    created_at: string;
  }>;
}

export default function AdminPage() {
  const { user, loading: authLoading } = useLumenAuth();
  const [data, setData] = useState<AdminData | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadAdmin = useCallback(async () => {
    const res = await fetch('/api/v1/admin', { cache: 'no-store' });
    if (res.ok) {
      setData(await res.json());
    }
  }, []);

  useEffect(() => {
    if (user?.role !== 'admin') return;
    let active = true;
    fetch('/api/v1/admin', { cache: 'no-store' })
      .then((res) => (res.ok ? res.json() : null))
      .then((body) => {
        if (active && body) setData(body);
      });
    return () => {
      active = false;
    };
  }, [user]);

  const runAction = async (payload: Record<string, unknown>, successMsg: string) => {
    setError(null);
    setMessage(null);
    const res = await fetch('/api/v1/admin', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'lumen-ui',
      },
      body: JSON.stringify(payload),
    });
    const body = (await res.json()) as { error?: string; recoveredCount?: number };
    if (!res.ok) {
      setError(body.error || 'Operation failed');
      return;
    }
    setMessage(
      body.recoveredCount !== undefined
        ? `${successMsg} (${body.recoveredCount} recovered)`
        : successMsg
    );
    await loadAdmin();
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F1E4] text-[#0D2636] dark:bg-[#091B27] dark:text-[#F4EFE3]">
      <SiteHeader />

      <main className="flex-1 max-w-[1220px] w-full mx-auto px-4 sm:px-6 py-10 space-y-10">
        <div className="border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 pb-6 space-y-2">
          <p className="text-[11px] uppercase tracking-[0.22em] text-[#CE9118] font-[family-name:var(--font-sans-ui)]">
            Operations &amp; Stewardship
          </p>
          <h1 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl font-medium">
            Moderation administration
          </h1>
          <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75">
            Role-restricted governance for entitlement recovery, reviewed refunds, payout reconciliation, and content moderation.
          </p>
        </div>

        {!authLoading && user?.role !== 'admin' ? (
          <div className="max-w-lg border border-[#D6CEBC] dark:border-[#F6F1E4]/25 bg-[#FAF7EF] dark:bg-[#0D2636] p-8 space-y-4">
            <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
              Administrator role required
            </h2>
            <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75">
              Visit Account to sign in and claim or verify administrator access using your configured passcode.
            </p>
            <Link
              href="/account"
              className="inline-block px-5 py-2.5 bg-[#0D2636] text-[#F6F1E4] text-xs font-medium"
            >
              Go to Account settings
            </Link>
          </div>
        ) : !data ? (
          <p className="text-sm text-[#465B68]">Loading administration console...</p>
        ) : (
          <div className="space-y-10">
            {message && (
              <p className="p-3 text-xs border border-emerald-700/40 bg-emerald-50 dark:bg-emerald-950/40">
                {message}
              </p>
            )}
            {error && (
              <p className="p-3 text-xs border border-red-400 bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-200">
                {error}
              </p>
            )}

            {/* 1. Pending Entitlement / Late Settlement Recovery */}
            <section className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
                    Fulfillment &amp; Settlement Recovery ({data.pending_fulfillments.length})
                  </h2>
                  <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/75">
                    Settled payments whose entitlement creation failed transiently or arrived after expiry are retained safely for retry.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    runAction(
                      { action: 'reconcile_fulfillments' },
                      'Reconciliation pass complete'
                    )
                  }
                  className="px-4 py-2 text-xs font-semibold bg-[#E5A929] text-[#0D2636] hover:bg-[#CE9118]"
                >
                  Reconcile &amp; retry fulfillment
                </button>
              </div>

              {data.pending_fulfillments.length > 0 && (
                <div className="divide-y divide-[#D6CEBC] dark:divide-[#F6F1E4]/15 text-xs">
                  {data.pending_fulfillments.map((pf) => (
                    <div key={pf.id} className="py-3 flex justify-between gap-4">
                      <span>
                        {pf.buyer_name} — {pf.article_title || pf.kind} ({pf.total_sats} sats)
                      </span>
                      <span className="font-[family-name:var(--font-mono-sats)]">
                        {pf.status} / {pf.fulfillment_status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* 2. Reviewed Refunds */}
            <section className="space-y-4">
              <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
                Refund Requests ({data.refund_requests.length})
              </h2>
              <div className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] divide-y divide-[#D6CEBC] dark:divide-[#F6F1E4]/15 text-xs">
                {data.refund_requests.length === 0 ? (
                  <p className="p-4 text-[#465B68]">No refund requests queued.</p>
                ) : (
                  data.refund_requests.map((rr) => (
                    <div key={rr.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <p className="font-medium">
                          {rr.article_title} · {rr.requested_amount_sats} sats ({rr.requester_name})
                        </p>
                        <p className="text-[#465B68] dark:text-[#F4EFE3]/70">
                          Reason: {rr.reason} · Status: {rr.status}
                          {rr.outgoing_reference ? ` · Ref: ${rr.outgoing_reference}` : ''}
                        </p>
                      </div>
                      {rr.status === 'pending_review' && (
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              runAction(
                                { action: 'review_refund', refund_id: rr.id, decision: 'approve' },
                                'Refund approved and outgoing credit issued'
                              )
                            }
                            className="px-3 py-1.5 bg-[#0D2636] text-[#F6F1E4]"
                          >
                            Approve refund
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              runAction(
                                { action: 'review_refund', refund_id: rr.id, decision: 'reject' },
                                'Refund rejected'
                              )
                            }
                            className="px-3 py-1.5 border border-[#0D2636]"
                          >
                            Reject
                          </button>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </section>

            {/* 3. Payout Reconciliation */}
            <section className="space-y-4">
              <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
                Author Payouts ({data.payouts.length})
              </h2>
              <div className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] divide-y divide-[#D6CEBC] dark:divide-[#F6F1E4]/15 text-xs">
                {data.payouts.length === 0 ? (
                  <p className="p-4 text-[#465B68]">No payouts requested yet.</p>
                ) : (
                  data.payouts.map((po) => (
                    <div key={po.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <p className="font-medium">
                          {po.author_name} → {po.destination} ({po.amount_sats} sats)
                        </p>
                        <p className="text-[#465B68] dark:text-[#F4EFE3]/70">
                          Status: {po.status} · {po.message}
                        </p>
                      </div>
                      {po.status === 'pending_reconciliation' && (
                        <button
                          type="button"
                          onClick={() =>
                            runAction(
                              { action: 'reconcile_payout', payout_id: po.id },
                              'Payout reconciled'
                            )
                          }
                          className="px-3 py-1.5 bg-[#E5A929] text-[#0D2636] font-semibold"
                        >
                          Reconcile payout
                        </button>
                      )}
                    </div>
                  ))
                )}
              </div>
            </section>

            {/* 4. Moderation & Audit Trail */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <section className="space-y-3">
                <h2 className="font-[family-name:var(--font-playfair)] text-xl font-medium">
                  Content Moderation
                </h2>
                <div className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] divide-y divide-[#D6CEBC] dark:divide-[#F6F1E4]/15 text-xs">
                  {data.articles.map((art) => (
                    <div key={art.id} className="p-3.5 flex items-center justify-between gap-3">
                      <div>
                        <p className="font-medium">{art.title}</p>
                        <p className="text-[#465B68] dark:text-[#F4EFE3]/70">
                          {art.author_name} · {art.status}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        {art.status !== 'withdrawn' ? (
                          <button
                            type="button"
                            onClick={() =>
                              runAction(
                                { action: 'moderate_article', article_id: art.id, status: 'withdrawn' },
                                'Article withdrawn'
                              )
                            }
                            className="px-2.5 py-1 border border-red-400 text-red-800 dark:text-red-300"
                          >
                            Withdraw
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() =>
                              runAction(
                                { action: 'moderate_article', article_id: art.id, status: 'published' },
                                'Article restored'
                              )
                            }
                            className="px-2.5 py-1 border border-[#0D2636]"
                          >
                            Restore
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              <section className="space-y-3">
                <h2 className="font-[family-name:var(--font-playfair)] text-xl font-medium">
                  Audit Log
                </h2>
                <div className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] divide-y divide-[#D6CEBC] dark:divide-[#F6F1E4]/15 text-xs max-h-96 overflow-y-auto">
                  {data.audit_logs.map((log) => (
                    <div key={log.id} className="p-3 space-y-0.5">
                      <p className="font-medium font-[family-name:var(--font-mono-sats)]">
                        {log.action} · {log.entity_type}
                      </p>
                      <p className="text-[#465B68] dark:text-[#F4EFE3]/70 break-all">
                        {log.details_json}
                      </p>
                    </div>
                  ))}
                </div>
              </section>
            </div>
          </div>
        )}
      </main>

      <SiteFooter />
    </div>
  );
}
