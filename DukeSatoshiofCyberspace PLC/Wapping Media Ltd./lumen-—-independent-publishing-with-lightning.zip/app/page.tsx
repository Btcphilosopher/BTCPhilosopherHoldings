import React from 'react';
import { listPublicArticles } from '@/lib/server/articles';
import { getSessionFromRequest } from '@/lib/server/crypto';
import { DiscoveryHomeClient } from '@/components/DiscoveryHomeClient';

export const dynamic = 'force-dynamic';

export default async function HomePage() {
  const session = await getSessionFromRequest();
  const articles = listPublicArticles({
    viewerUserId: session?.userId || null,
  });

  return <DiscoveryHomeClient initialArticles={articles} />;
}
