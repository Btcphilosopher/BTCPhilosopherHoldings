'use client';

import React, { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { SiteHeader } from '@/components/SiteHeader';
import { SiteFooter } from '@/components/SiteFooter';
import { useLumenAuth } from '@/components/LumenAuthContext';

interface AuthorStatement {
  is_demo: boolean;
  accounting_model: string;
  article_purchases_count: number;
  article_purchases_gross_sats: number;
  platform_commission_sats: number;
  article_purchases_net_sats: number;
  settled_tips_count: number;
  settled_tips_sats: number;
  refunds_count: number;
  refunded_gross_sats: number;
  paid_out_sats: number;
  pending_payout_sats: number;
  amount_payable_sats: number;
  recent_purchases: Array<{
    id: string;
    article_title: string;
    reader_name: string;
    total_sats: number;
    commission_sats: number;
    author_payable_sats: number;
    status: string;
    created_at: string;
  }>;
  recent_tips: Array<{
    id: string;
    reader_name: string;
    article_title?: string;
    amount_sats: number;
    created_at: string;
  }>;
  payouts: Array<{
    id: string;
    destination: string;
    amount_sats: number;
    network_fee_sats: number;
    status: string;
    message: string;
    created_at: string;
  }>;
}

export default function EarningsPage() {
  const { user, profile, loading: authLoading } = useLumenAuth();
  const [statement, setStatement] = useState<AuthorStatement | null>(null);
  const [destination, setDestination] = useState('');
  const [payoutAmount, setPayoutAmount] = useState('100');
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadStatement = useCallback(async () => {
    const res = await fetch('/api/v1/me/author-statement', { cache: 'no-store' });
    if (res.ok) {
      const data = (await res.json()) as { statement: AuthorStatement };
      setStatement(data.statement);
    }
  }, []);

  useEffect(() => {
    if (!user) return;
    let active = true;
    fetch('/api/v1/me/author-statement', { cache: 'no-store' })
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { statement?: AuthorStatement } | null) => {
        if (active && data?.statement) setStatement(data.statement);
      });
    const raf = requestAnimationFrame(() => {
      if (profile?.lightning_destination && !destination) {
        setDestination(profile.lightning_destination);
      }
    });
    return () => {
      active = false;
      cancelAnimationFrame(raf);
    };
  }, [user, profile, destination]);

  const submitPayout = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    setMessage(null);
    try {
      const res = await fetch('/api/v1/payout-requests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'lumen-ui',
        },
        body: JSON.stringify({
          destination: destination.trim(),
          amount_sats: parseInt(payoutAmount, 10),
          idempotency_key: `ui_po_${Date.now()}`,
        }),
      });
      const data = (await res.json()) as {
        payout?: { status: string; message: string };
        error?: string;
      };
      if (!res.ok) {
        throw new Error(data.error || 'Payout request failed');
      }
      setMessage(
        `Payout ${data.payout?.status}: ${data.payout?.message || 'Recorded'}`
      );
      await loadStatement();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Payout request error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F1E4] text-[#0D2636] dark:bg-[#091B27] dark:text-[#F4EFE3]">
      <SiteHeader />

      <main className="flex-1 max-w-[1220px] w-full mx-auto px-4 sm:px-6 py-10 space-y-10">
        <div className="border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div className="space-y-2">
            <p className="text-[11px] uppercase tracking-[0.22em] text-[#CE9118] font-[family-name:var(--font-sans-ui)]">
              Platform-Collection Statement (Demonstration)
            </p>
            <h1 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl font-medium">
              Author earnings
            </h1>
            <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75 max-w-2xl">
              Lumen collects Lightning payments on behalf of writers, snapshots platform commission per offer, and records net amounts payable in integer sats.
            </p>
          </div>
          {user && (
            <Link
              href="/write"
              className="px-4 py-2 text-xs font-medium bg-[#0D2636] text-[#F6F1E4] whitespace-nowrap"
            >
              Writing studio →
            </Link>
          )}
        </div>

        {!authLoading && !user ? (
          <div className="max-w-lg border border-[#D6CEBC] dark:border-[#F6F1E4]/25 bg-[#FAF7EF] dark:bg-[#0D2636] p-8 space-y-4">
            <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
              Sign in as an author
            </h2>
            <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75">
              Switch to Eleanor Hart or another author account to inspect author statements and payouts.
            </p>
            <Link
              href="/account"
              className="inline-block px-5 py-2.5 bg-[#0D2636] text-[#F6F1E4] text-xs font-medium"
            >
              Open Account switcher
            </Link>
          </div>
        ) : !statement ? (
          <p className="text-sm text-[#465B68]">Loading author statement...</p>
        ) : (
          <div className="space-y-10">
            {/* Summary Statement Metrics */}
            <section className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {[
                { label: 'Article purchases (gross)', value: `${statement.article_purchases_gross_sats} sats` },
                { label: 'Platform commission', value: `${statement.platform_commission_sats} sats` },
                { label: 'Settled tips', value: `${statement.settled_tips_sats} sats` },
                { label: 'Refunds', value: `${statement.refunded_gross_sats} sats` },
                { label: 'Paid out', value: `${statement.paid_out_sats} sats` },
                { label: 'Amount payable', value: `${statement.amount_payable_sats} sats`, highlight: true },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className={`p-4 border ${
                    stat.highlight
                      ? 'border-[#E5A929] bg-[#E5A929]/15'
                      : 'border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636]'
                  }`}
                >
                  <p className="text-[11px] uppercase tracking-wider text-[#465B68] dark:text-[#F4EFE3]/70 font-[family-name:var(--font-sans-ui)]">
                    {stat.label}
                  </p>
                  <p className="font-[family-name:var(--font-mono-sats)] tabular-sats text-lg font-semibold mt-1">
                    {stat.value}
                  </p>
                </div>
              ))}
            </section>

            {/* Request Payout Form */}
            <section className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] p-6 space-y-4">
              <div className="space-y-1">
                <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
                  Request Payout
                </h2>
                <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/75">
                  Limits: 50 – 50,000 sats per transfer. Destinations must be a verified Lightning Address or LNURL. Tip: enter <code className="font-mono">unknown@lumen.example</code> to test pending payout reconciliation in Admin.
                </p>
              </div>

              <form onSubmit={submitPayout} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                <div>
                  <label className="block text-xs font-medium mb-1">
                    Lightning Address or LNURL
                  </label>
                  <input
                    type="text"
                    required
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    placeholder="eleanor@lumen.example"
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium mb-1">
                    Amount (integer sats)
                  </label>
                  <input
                    type="number"
                    required
                    min={50}
                    max={50000}
                    step={1}
                    value={payoutAmount}
                    onChange={(e) => setPayoutAmount(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-[family-name:var(--font-mono-sats)] bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                  />
                </div>
                <button
                  type="submit"
                  disabled={submitting || statement.amount_payable_sats < 50}
                  className="py-2.5 px-5 bg-[#0D2636] text-[#F6F1E4] hover:bg-[#173D52] disabled:opacity-50 text-xs font-medium"
                >
                  {submitting ? 'Submitting payout...' : 'Request payout'}
                </button>
              </form>

              {message && (
                <p className="text-xs p-3 border border-emerald-700/40 bg-emerald-50 dark:bg-emerald-950/40">
                  {message}
                </p>
              )}
              {error && (
                <p className="text-xs p-3 border border-red-400 bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-200">
                  {error}
                </p>
              )}
            </section>

            {/* Statement Ledger Tables */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <section className="space-y-3">
                <h2 className="font-[family-name:var(--font-playfair)] text-xl font-medium">
                  Settled Article Sales
                </h2>
                <div className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] divide-y divide-[#D6CEBC] dark:divide-[#F6F1E4]/15 text-xs">
                  {statement.recent_purchases.length === 0 ? (
                    <p className="p-4 text-[#465B68]">No article purchases recorded yet.</p>
                  ) : (
                    statement.recent_purchases.map((p) => (
                      <div key={p.id} className="p-4 flex justify-between gap-4">
                        <div>
                          <p className="font-medium">{p.article_title}</p>
                          <p className="text-[#465B68] dark:text-[#F4EFE3]/70">
                            Reader: {p.reader_name} · Status: {p.status}
                          </p>
                        </div>
                        <div className="text-right font-[family-name:var(--font-mono-sats)] tabular-sats">
                          <p className="font-semibold">+{p.author_payable_sats} sats</p>
                          <p className="text-[#465B68]">
                            ({p.total_sats} gross − {p.commission_sats} fee)
                          </p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </section>

              <section className="space-y-3">
                <h2 className="font-[family-name:var(--font-playfair)] text-xl font-medium">
                  Settled Tips &amp; Payouts
                </h2>
                <div className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] divide-y divide-[#D6CEBC] dark:divide-[#F6F1E4]/15 text-xs">
                  {statement.recent_tips.map((t) => (
                    <div key={t.id} className="p-4 flex justify-between gap-4">
                      <div>
                        <p className="font-medium">Tip from {t.reader_name}</p>
                        {t.article_title && (
                          <p className="text-[#465B68] dark:text-[#F4EFE3]/70">
                            {t.article_title}
                          </p>
                        )}
                      </div>
                      <span className="font-[family-name:var(--font-mono-sats)] tabular-sats font-semibold">
                        +{t.amount_sats} sats
                      </span>
                    </div>
                  ))}
                  {statement.payouts.map((po) => (
                    <div key={po.id} className="p-4 flex justify-between gap-4 bg-[#F6F1E4]/50 dark:bg-[#091B27]/50">
                      <div>
                        <p className="font-medium">Payout → {po.destination}</p>
                        <p className="text-[#465B68] dark:text-[#F4EFE3]/70">
                          Status: {po.status} · {po.message}
                        </p>
                      </div>
                      <span className="font-[family-name:var(--font-mono-sats)] tabular-sats font-semibold">
                        −{po.amount_sats} sats
                      </span>
                    </div>
                  ))}
                  {statement.recent_tips.length === 0 && statement.payouts.length === 0 && (
                    <p className="p-4 text-[#465B68]">No tips or payouts recorded yet.</p>
                  )}
                </div>
              </section>
            </div>
          </div>
        )}
      </main>

      <SiteFooter />
    </div>
  );
}
