'use client';

import React, { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { SiteHeader } from '@/components/SiteHeader';
import { SiteFooter } from '@/components/SiteFooter';
import { useLumenAuth } from '@/components/LumenAuthContext';

interface PaymentHistoryData {
  is_demo: boolean;
  demo_balance_sats: number;
  payment_intents: Array<{
    id: string;
    kind: string;
    total_sats: number;
    status: string;
    fulfillment_status: string;
    provider: string;
    article_title?: string;
    article_slug?: string;
    recipient_name?: string;
    created_at: string;
    expires_at: string;
    settled_at: string | null;
  }>;
  purchases: Array<{
    id: string;
    article_title: string;
    article_slug: string;
    author_name: string;
    total_sats: number;
    fee_policy_version: string;
    includes_future_revisions: number;
    status: string;
    refund_status: string | null;
    created_at: string;
  }>;
  tips: Array<{
    id: string;
    recipient_name: string;
    article_title?: string;
    amount_sats: number;
    created_at: string;
  }>;
}

export default function PaymentsPage() {
  const { user, loading: authLoading } = useLumenAuth();
  const [data, setData] = useState<PaymentHistoryData | null>(null);
  const [refundReason, setRefundReason] = useState<Record<string, string>>({});
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadPayments = useCallback(async () => {
    const res = await fetch('/api/v1/me/payments', { cache: 'no-store' });
    if (res.ok) {
      setData(await res.json());
    }
  }, []);

  useEffect(() => {
    if (!user) return;
    let active = true;
    fetch('/api/v1/me/payments', { cache: 'no-store' })
      .then((res) => (res.ok ? res.json() : null))
      .then((body) => {
        if (active && body) setData(body);
      });
    return () => {
      active = false;
    };
  }, [user]);

  const submitRefund = async (purchaseId: string) => {
    setError(null);
    setMessage(null);
    const reason = (refundReason[purchaseId] || '').trim() || 'Requested editorial refund review';
    const res = await fetch('/api/v1/refund-requests', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'lumen-ui',
      },
      body: JSON.stringify({ purchase_id: purchaseId, reason }),
    });
    const body = (await res.json()) as { error?: string };
    if (!res.ok) {
      setError(body.error || 'Could not submit refund request');
      return;
    }
    setMessage('Refund request submitted for moderation review.');
    await loadPayments();
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F1E4] text-[#0D2636] dark:bg-[#091B27] dark:text-[#F4EFE3]">
      <SiteHeader />

      <main className="flex-1 max-w-[1220px] w-full mx-auto px-4 sm:px-6 py-10 space-y-10">
        <div className="border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div className="space-y-2">
            <p className="text-[11px] uppercase tracking-[0.22em] text-[#CE9118] font-[family-name:var(--font-sans-ui)]">
              Ledger &amp; Receipts
            </p>
            <h1 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl font-medium">
              Payment history
            </h1>
            <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75 max-w-2xl">
              Lightning payments settle through Lumen’s platform-collection adapter and are not reversible via card chargebacks. Reviewed refunds are issued as separate outgoing payments.
            </p>
          </div>
          {user && (
            <Link
              href="/earnings"
              className="px-4 py-2 text-xs font-medium border border-[#0D2636] dark:border-[#F6F1E4]/35 hover:bg-[#0D2636]/5 whitespace-nowrap"
            >
              View author earnings →
            </Link>
          )}
        </div>

        {!authLoading && !user ? (
          <div className="max-w-lg border border-[#D6CEBC] dark:border-[#F6F1E4]/25 bg-[#FAF7EF] dark:bg-[#0D2636] p-8 space-y-4">
            <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
              Sign in to inspect payment records
            </h2>
            <Link
              href="/account"
              className="inline-block px-5 py-2.5 bg-[#0D2636] text-[#F6F1E4] text-xs font-medium"
            >
              Sign in or choose demo account
            </Link>
          </div>
        ) : !data ? (
          <p className="text-sm text-[#465B68]">Loading payment ledger...</p>
        ) : (
          <div className="space-y-10">
            {message && (
              <p className="p-3 text-xs border border-emerald-700/40 bg-emerald-50 dark:bg-emerald-950/40">
                {message}
              </p>
            )}
            {error && (
              <p className="p-3 text-xs border border-red-400 bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-200">
                {error}
              </p>
            )}

            {/* Purchases & Refund Workflow */}
            <section className="space-y-4">
              <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
                Article Purchases ({data.purchases.length})
              </h2>
              {data.purchases.length === 0 ? (
                <p className="text-sm text-[#465B68]">No settled article purchases yet.</p>
              ) : (
                <div className="divide-y divide-[#D6CEBC] dark:divide-[#F6F1E4]/20 border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636]">
                  {data.purchases.map((p) => (
                    <div key={p.id} className="p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                      <div className="space-y-1">
                        <Link
                          href={`/articles/${p.article_slug}`}
                          className="font-[family-name:var(--font-playfair)] text-lg font-medium hover:underline decoration-[#E5A929]"
                        >
                          {p.article_title}
                        </Link>
                        <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/75 font-[family-name:var(--font-mono-sats)] tabular-sats">
                          Author: {p.author_name} · Total: {p.total_sats} sats (demo) · Policy: {p.fee_policy_version} · Status: {p.status}
                        </p>
                      </div>

                      {p.status === 'active' && !p.refund_status ? (
                        <div className="flex flex-wrap items-center gap-2">
                          <input
                            type="text"
                            placeholder="Reason for refund review..."
                            value={refundReason[p.id] || ''}
                            onChange={(e) =>
                              setRefundReason((prev) => ({ ...prev, [p.id]: e.target.value }))
                            }
                            className="px-3 py-1.5 text-xs bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                          />
                          <button
                            type="button"
                            onClick={() => submitRefund(p.id)}
                            className="px-3 py-1.5 text-xs border border-[#0D2636] dark:border-[#F6F1E4]/35 hover:bg-[#0D2636]/5"
                          >
                            Request refund
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs font-[family-name:var(--font-mono-sats)] text-[#CE9118]">
                          Refund: {p.refund_status || p.status}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* Tips Sent */}
            <section className="space-y-4">
              <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
                Tips Sent ({data.tips.length})
              </h2>
              {data.tips.length === 0 ? (
                <p className="text-sm text-[#465B68]">No reader tips sent yet.</p>
              ) : (
                <div className="divide-y divide-[#D6CEBC] dark:divide-[#F6F1E4]/20 border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636]">
                  {data.tips.map((t) => (
                    <div key={t.id} className="p-4 flex justify-between items-center text-sm">
                      <div>
                        <p className="font-medium">Tip to {t.recipient_name}</p>
                        {t.article_title && (
                          <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/70">
                            On: {t.article_title}
                          </p>
                        )}
                      </div>
                      <span className="font-[family-name:var(--font-mono-sats)] tabular-sats font-medium">
                        {t.amount_sats} sats
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* All Invoices / Payment Intents */}
            <section className="space-y-4">
              <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
                Invoice Attempts ({data.payment_intents.length})
              </h2>
              <div className="overflow-x-auto border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636]">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 font-[family-name:var(--font-sans-ui)] uppercase tracking-wider text-[#465B68]">
                    <tr>
                      <th className="py-3 px-4">Type</th>
                      <th className="py-3 px-4">Target</th>
                      <th className="py-3 px-4">Total</th>
                      <th className="py-3 px-4">Invoice Status</th>
                      <th className="py-3 px-4">Fulfillment</th>
                      <th className="py-3 px-4">Provider</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#D6CEBC]/70 dark:divide-[#F6F1E4]/15 font-[family-name:var(--font-mono-sats)] tabular-sats">
                    {data.payment_intents.map((pi) => (
                      <tr key={pi.id}>
                        <td className="py-3 px-4">
                          {pi.kind === 'article_purchase' ? 'Purchase' : 'Tip'}
                        </td>
                        <td className="py-3 px-4 font-sans">
                          {pi.article_title || pi.recipient_name || pi.id}
                        </td>
                        <td className="py-3 px-4">{pi.total_sats} sats</td>
                        <td className="py-3 px-4">{pi.status}</td>
                        <td className="py-3 px-4">{pi.fulfillment_status}</td>
                        <td className="py-3 px-4">{pi.provider}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        )}
      </main>

      <SiteFooter />
    </div>
  );
}
