import React from 'react';
import Link from 'next/link';
import { listPublicArticles } from '@/lib/server/articles';
import { getSessionFromRequest } from '@/lib/server/crypto';
import { ArticleListView } from '@/components/ArticleListView';
import { SiteHeader } from '@/components/SiteHeader';
import { SiteFooter } from '@/components/SiteFooter';

export const dynamic = 'force-dynamic';

export default async function FollowingPage() {
  const session = await getSessionFromRequest();

  if (!session) {
    return (
      <div className="min-h-screen flex flex-col bg-[#F6F1E4] text-[#0D2636] dark:bg-[#091B27] dark:text-[#F4EFE3]">
        <SiteHeader />
        <main className="flex-1 max-w-[1220px] w-full mx-auto px-4 sm:px-6 py-16">
          <div className="max-w-lg border border-[#D6CEBC] dark:border-[#F6F1E4]/25 bg-[#FAF7EF] dark:bg-[#0D2636] p-8 space-y-4">
            <h1 className="font-[family-name:var(--font-playfair)] text-3xl font-medium">
              Following Feed
            </h1>
            <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75">
              Sign in to read a clean chronological stream from the writers you follow.
            </p>
            <Link
              href="/account"
              className="inline-block px-5 py-2.5 bg-[#0D2636] text-[#F6F1E4] text-xs font-medium"
            >
              Sign in or switch demo account
            </Link>
          </div>
        </main>
        <SiteFooter />
      </div>
    );
  }

  const articles = listPublicArticles({
    followingForUserId: session.userId,
    viewerUserId: session.userId,
  });

  return (
    <ArticleListView
      eyebrow="Subscribed Writers"
      title="Following"
      description="Chronological essays from authors you follow — free from algorithmic boosting."
      articles={articles}
      emptyMessage="You are not following any writers yet, or they have not published yet."
    />
  );
}
