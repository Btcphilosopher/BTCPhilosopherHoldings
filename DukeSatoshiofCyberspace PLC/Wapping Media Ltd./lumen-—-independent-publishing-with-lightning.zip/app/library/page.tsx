'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { Bookmark, LockOpen, Users } from 'lucide-react';
import { SiteHeader } from '@/components/SiteHeader';
import { SiteFooter } from '@/components/SiteFooter';
import { useLumenAuth } from '@/components/LumenAuthContext';
import { ArticleSummary } from '@/lib/server/types';

interface PurchasedItem extends ArticleSummary {
  purchase_id: string;
  granted_at: string;
  paid_sats: number;
}

export default function LibraryPage() {
  const { user, loading: authLoading } = useLumenAuth();
  const [purchased, setPurchased] = useState<PurchasedItem[]>([]);
  const [saved, setSaved] = useState<ArticleSummary[]>([]);
  const [following, setFollowing] = useState<
    { id: string; handle: string; display_name: string; publication_name: string }[]
  >([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    let active = true;
    fetch('/api/v1/me/library', { cache: 'no-store' })
      .then((r) => r.json())
      .then((data) => {
        if (!active) return;
        setPurchased(data.purchased || []);
        setSaved(data.saved || []);
        setFollowing(data.following || []);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [user]);

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F1E4] text-[#0D2636] dark:bg-[#091B27] dark:text-[#F4EFE3]">
      <SiteHeader />

      <main className="flex-1 max-w-[1220px] w-full mx-auto px-4 sm:px-6 py-10 space-y-10">
        <div className="border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 pb-6 space-y-2">
          <p className="text-[11px] uppercase tracking-[0.22em] text-[#CE9118] font-[family-name:var(--font-sans-ui)]">
            Personal Archive
          </p>
          <h1 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl font-medium">
            My library
          </h1>
          <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75">
            Purchased editions remain tied to your account across sessions, alongside your saved essays and followed writers.
          </p>
        </div>

        {!authLoading && !user ? (
          <div className="max-w-lg border border-[#D6CEBC] dark:border-[#F6F1E4]/25 bg-[#FAF7EF] dark:bg-[#0D2636] p-8 space-y-4">
            <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
              Sign in to view your library
            </h2>
            <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75">
              Durable purchased articles and bookmarks are stored per account.
            </p>
            <Link
              href="/account"
              className="inline-block px-5 py-2.5 bg-[#0D2636] text-[#F6F1E4] text-xs font-medium"
            >
              Go to Account
            </Link>
          </div>
        ) : loading ? (
          <p className="text-sm text-[#465B68]">Loading your library...</p>
        ) : (
          <div className="space-y-12">
            {/* Purchased Editions */}
            <section className="space-y-4">
              <div className="flex items-center gap-2 border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 pb-2">
                <LockOpen className="w-4 h-4 text-[#CE9118]" />
                <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
                  Purchased Articles ({purchased.length})
                </h2>
              </div>

              {purchased.length === 0 ? (
                <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/70">
                  You have not unlocked any paid editions yet. Explore{' '}
                  <Link href="/" className="underline decoration-[#E5A929]">
                    The Current Edition
                  </Link>
                  .
                </p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {purchased.map((art) => (
                    <article
                      key={art.id}
                      className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] p-5 flex flex-col justify-between gap-4"
                    >
                      <div className="space-y-1.5">
                        <p className="text-[11px] uppercase tracking-wider text-[#CE9118] font-[family-name:var(--font-sans-ui)]">
                          {art.topic} · Unlocked ({art.paid_sats} sats)
                        </p>
                        <h3 className="font-[family-name:var(--font-playfair)] text-xl font-medium">
                          <Link
                            href={`/articles/${art.slug}`}
                            className="hover:underline decoration-[#E5A929]"
                          >
                            {art.title}
                          </Link>
                        </h3>
                        <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/75">
                          By {art.author.display_name}
                        </p>
                      </div>
                      <Link
                        href={`/articles/${art.slug}`}
                        className="inline-flex items-center justify-center py-2 px-4 bg-[#0D2636] text-[#F6F1E4] text-xs font-medium hover:bg-[#173D52]"
                      >
                        Read unlocked edition
                      </Link>
                    </article>
                  ))}
                </div>
              )}
            </section>

            {/* Saved Bookmarks */}
            <section className="space-y-4">
              <div className="flex items-center gap-2 border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 pb-2">
                <Bookmark className="w-4 h-4 text-[#CE9118]" />
                <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
                  Saved Bookmarks ({saved.length})
                </h2>
              </div>

              {saved.length === 0 ? (
                <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/70">
                  No saved bookmarks yet.
                </p>
              ) : (
                <div className="divide-y divide-[#D6CEBC] dark:divide-[#F6F1E4]/20 border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636]">
                  {saved.map((art) => (
                    <div
                      key={art.id}
                      className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div>
                        <Link
                          href={`/articles/${art.slug}`}
                          className="font-[family-name:var(--font-playfair)] text-lg font-medium hover:underline decoration-[#E5A929]"
                        >
                          {art.title}
                        </Link>
                        <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/70">
                          {art.author.display_name} ·{' '}
                          {art.offer.is_paid
                            ? art.viewer_has_access
                              ? 'Unlocked'
                              : `${art.offer.price_sats} sats`
                            : 'Free'}
                        </p>
                      </div>
                      <Link
                        href={`/articles/${art.slug}`}
                        className="text-xs font-medium underline decoration-[#E5A929] underline-offset-4 whitespace-nowrap"
                      >
                        Open →
                      </Link>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* Followed Writers */}
            <section className="space-y-4">
              <div className="flex items-center gap-2 border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 pb-2">
                <Users className="w-4 h-4 text-[#CE9118]" />
                <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
                  Followed Writers ({following.length})
                </h2>
              </div>

              {following.length === 0 ? (
                <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/70">
                  You are not following any writers yet.
                </p>
              ) : (
                <div className="flex flex-wrap gap-4">
                  {following.map((author) => (
                    <Link
                      key={author.id}
                      href={`/authors/${author.handle}`}
                      className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] px-4 py-3 hover:border-[#E5A929]"
                    >
                      <p className="font-medium text-sm">{author.display_name}</p>
                      <p className="text-xs text-[#465B68] dark:text-[#F4EFE3]/70">
                        {author.publication_name}
                      </p>
                    </Link>
                  ))}
                </div>
              )}
            </section>
          </div>
        )}
      </main>

      <SiteFooter />
    </div>
  );
}
