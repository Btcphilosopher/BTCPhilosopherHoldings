import React from 'react';
import { notFound } from 'next/navigation';
import { getArticleDetail } from '@/lib/server/articles';
import { getSessionFromRequest } from '@/lib/server/crypto';
import { ArticleReaderClient } from '@/components/ArticleReaderClient';

export const dynamic = 'force-dynamic';

export default async function ArticlePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await getSessionFromRequest();

  const article = getArticleDetail({
    idOrSlug: slug,
    viewerUserId: session?.userId || null,
    viewerRole: session?.role || null,
    incrementView: true,
  });

  if (!article) {
    notFound();
  }

  return <ArticleReaderClient initialArticle={article} />;
}
