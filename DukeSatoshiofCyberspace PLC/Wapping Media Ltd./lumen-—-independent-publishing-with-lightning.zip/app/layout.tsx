import type { Metadata } from 'next';
import { Playfair_Display, Source_Serif_4, IBM_Plex_Mono, Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css';

const playfair = Playfair_Display({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-playfair',
  display: 'swap',
});

const sourceSerif = Source_Serif_4({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  style: ['normal', 'italic'],
  variable: '--font-source-serif',
  display: 'swap',
});

const ibmMono = IBM_Plex_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-ibm-mono',
  display: 'swap',
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-plus-jakarta',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Lumen — Independent Publishing with Lightning',
  description: 'Good writing. Worth a few sats. Read freely, unlock remarkable stories, and support independent writers.',
  openGraph: {
    title: 'Lumen — Independent Publishing with Lightning',
    description: 'Good writing. Worth a few sats. Read freely, unlock remarkable stories, and support independent writers.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Lumen — Independent Publishing with Lightning',
    description: 'Good writing. Worth a few sats. Read freely, unlock remarkable stories, and support independent writers.',
  },
};

import { LumenAuthProvider } from '@/components/LumenAuthContext';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      className={`${playfair.variable} ${sourceSerif.variable} ${ibmMono.variable} ${plusJakarta.variable}`}
      suppressHydrationWarning
    >
      <body className="min-h-screen bg-[#F6F1E4] text-[#0D2636] dark:bg-[#091B27] dark:text-[#F4EFE3] antialiased selection:bg-[#E5A929]/30">
        <LumenAuthProvider>{children}</LumenAuthProvider>
      </body>
    </html>
  );
}
