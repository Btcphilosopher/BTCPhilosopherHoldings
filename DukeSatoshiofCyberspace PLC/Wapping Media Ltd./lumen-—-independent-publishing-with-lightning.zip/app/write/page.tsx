'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { PenLine, Plus } from 'lucide-react';
import { SiteHeader } from '@/components/SiteHeader';
import { SiteFooter } from '@/components/SiteFooter';
import { useLumenAuth } from '@/components/LumenAuthContext';
import { ArticleSummary } from '@/lib/server/types';

interface DashboardArticle extends ArticleSummary {
  view_count: number;
  purchase_attempts: number;
  settled_purchases: number;
  purchase_revenue_sats: number;
  tip_revenue_sats: number;
}

export default function WriteDashboardPage() {
  const { user, loading: authLoading } = useLumenAuth();
  const [articles, setArticles] = useState<DashboardArticle[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    let active = true;
    fetch('/api/v1/articles?mine=1', { cache: 'no-store' })
      .then((r) => r.json())
      .then((data) => {
        if (active) setArticles(data.articles || []);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [user]);

  const totals = articles.reduce(
    (acc, a) => ({
      views: acc.views + a.view_count,
      attempts: acc.attempts + a.purchase_attempts,
      settled: acc.settled + a.settled_purchases,
      revenue: acc.revenue + a.purchase_revenue_sats + a.tip_revenue_sats,
    }),
    { views: 0, attempts: 0, settled: 0, revenue: 0 }
  );

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F1E4] text-[#0D2636] dark:bg-[#091B27] dark:text-[#F4EFE3]">
      <SiteHeader />

      <main className="flex-1 max-w-[1220px] w-full mx-auto px-4 sm:px-6 py-10 space-y-10">
        <div className="border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div className="space-y-2">
            <p className="text-[11px] uppercase tracking-[0.22em] text-[#CE9118] font-[family-name:var(--font-sans-ui)]">
              Author Studio
            </p>
            <h1 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl font-medium">
              Writing dashboard
            </h1>
            <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75">
              Draft, preview, publish, and revise editions. Page views, purchase attempts, settled sales, and net author revenue are reported separately without fabrication.
            </p>
          </div>
          {user && (
            <div className="flex items-center gap-3">
              <Link
                href="/earnings"
                className="px-4 py-2.5 text-xs font-medium border border-[#0D2636] dark:border-[#F6F1E4]/35 hover:bg-[#0D2636]/5 whitespace-nowrap"
              >
                Earnings statement
              </Link>
              <Link
                href="/write/new"
                className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold bg-[#E5A929] text-[#0D2636] hover:bg-[#CE9118] whitespace-nowrap"
              >
                <Plus className="w-4 h-4" />
                <span>New story</span>
              </Link>
            </div>
          )}
        </div>

        {!authLoading && !user ? (
          <div className="max-w-lg border border-[#D6CEBC] dark:border-[#F6F1E4]/25 bg-[#FAF7EF] dark:bg-[#0D2636] p-8 space-y-4">
            <h2 className="font-[family-name:var(--font-playfair)] text-2xl font-medium">
              Sign in to write and publish
            </h2>
            <p className="text-sm text-[#465B68] dark:text-[#F4EFE3]/75">
              Switch to Eleanor Hart, Daniel Moss, or create a new writer account to draft and publish stories.
            </p>
            <Link
              href="/account"
              className="inline-block px-5 py-2.5 bg-[#0D2636] text-[#F6F1E4] text-xs font-medium"
            >
              Sign in or switch demo account
            </Link>
          </div>
        ) : loading ? (
          <p className="text-sm text-[#465B68]">Loading your stories...</p>
        ) : (
          <div className="space-y-8">
            {/* Separated Publication Statistics */}
            <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { label: 'Recorded page views', value: totals.views.toLocaleString() },
                { label: 'Purchase attempts', value: totals.attempts.toLocaleString() },
                { label: 'Settled purchases', value: totals.settled.toLocaleString() },
                { label: 'Author revenue (net)', value: `${totals.revenue.toLocaleString()} sats` },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="p-4 border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636]"
                >
                  <p className="text-[11px] uppercase tracking-wider text-[#465B68] dark:text-[#F4EFE3]/70 font-[family-name:var(--font-sans-ui)]">
                    {stat.label}
                  </p>
                  <p className="font-[family-name:var(--font-mono-sats)] tabular-sats text-xl font-semibold mt-1">
                    {stat.value}
                  </p>
                </div>
              ))}
            </section>

            {/* Stories List */}
            {articles.length === 0 ? (
              <div className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] p-8 text-center space-y-3">
                <p className="font-[family-name:var(--font-playfair)] italic text-xl">
                  You haven’t drafted any essays yet.
                </p>
                <Link
                  href="/write/new"
                  className="inline-block px-5 py-2.5 bg-[#0D2636] text-[#F6F1E4] text-xs font-medium"
                >
                  Start your first essay
                </Link>
              </div>
            ) : (
              <div className="overflow-x-auto border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636]">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 font-[family-name:var(--font-sans-ui)] uppercase tracking-wider text-[#465B68]">
                    <tr>
                      <th className="py-3 px-4">Title &amp; Topic</th>
                      <th className="py-3 px-4">Lifecycle</th>
                      <th className="py-3 px-4">Pricing</th>
                      <th className="py-3 px-4">Views</th>
                      <th className="py-3 px-4">Attempts / Sales</th>
                      <th className="py-3 px-4">Net Revenue</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#D6CEBC]/70 dark:divide-[#F6F1E4]/15">
                    {articles.map((art) => (
                      <tr key={art.id}>
                        <td className="py-3.5 px-4">
                          <p className="font-[family-name:var(--font-playfair)] text-base font-medium">
                            {art.title}
                          </p>
                          <p className="text-[#465B68] dark:text-[#F4EFE3]/70 capitalize">
                            {art.topic} · Rev v{art.current_revision_number}
                          </p>
                        </td>
                        <td className="py-3.5 px-4 capitalize font-medium">{art.status}</td>
                        <td className="py-3.5 px-4 font-[family-name:var(--font-mono-sats)] tabular-sats">
                          {art.offer.is_paid ? `${art.offer.price_sats} sats` : 'Free'}
                        </td>
                        <td className="py-3.5 px-4 font-[family-name:var(--font-mono-sats)] tabular-sats">
                          {art.view_count}
                        </td>
                        <td className="py-3.5 px-4 font-[family-name:var(--font-mono-sats)] tabular-sats">
                          {art.purchase_attempts} / {art.settled_purchases}
                        </td>
                        <td className="py-3.5 px-4 font-[family-name:var(--font-mono-sats)] tabular-sats">
                          {art.purchase_revenue_sats + art.tip_revenue_sats} sats
                        </td>
                        <td className="py-3.5 px-4 text-right whitespace-nowrap space-x-3">
                          <Link
                            href={`/write/${art.id}`}
                            className="inline-flex items-center gap-1 underline decoration-[#E5A929] underline-offset-4 font-medium"
                          >
                            <PenLine className="w-3.5 h-3.5" />
                            <span>Edit</span>
                          </Link>
                          {(art.status === 'published' || art.status === 'revised' || art.status === 'preview') && (
                            <Link
                              href={`/articles/${art.slug}`}
                              className="text-[#465B68] dark:text-[#F4EFE3]/75 hover:underline"
                            >
                              View
                            </Link>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </main>

      <SiteFooter />
    </div>
  );
}
