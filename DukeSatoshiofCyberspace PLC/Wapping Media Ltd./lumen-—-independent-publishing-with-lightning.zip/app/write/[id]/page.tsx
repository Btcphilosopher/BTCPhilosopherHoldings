'use client';

import React, { use, useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  Eye,
  Heading2,
  ImagePlus,
  Link2,
  List,
  Quote,
  Save,
  Send,
  Upload,
} from 'lucide-react';
import { SiteHeader } from '@/components/SiteHeader';
import { SiteFooter } from '@/components/SiteFooter';
import { useLumenAuth } from '@/components/LumenAuthContext';
import { EditorialBlocks } from '@/components/EditorialBlocks';
import { ArticleRevision, ContentBlock, LifecycleStatus, TopicSlug } from '@/lib/server/types';

function previewClientParse(markdown: string): ContentBlock[] {
  // Lightweight safe preview parser mirroring server blocks (without raw HTML)
  const clean = markdown.replace(/<[^>]+>/g, '').replace(/\r\n/g, '\n');
  const lines = clean.split('\n');
  const blocks: ContentBlock[] = [];
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) continue;
    if (line.startsWith('## ') || line.startsWith('# ')) {
      blocks.push({ type: 'heading', level: 2, runs: [{ text: line.replace(/^#+\s+/, '') }] });
    } else if (line.startsWith('### ')) {
      blocks.push({ type: 'heading', level: 3, runs: [{ text: line.slice(4) }] });
    } else if (line.startsWith('> ')) {
      blocks.push({ type: 'quote', runs: [{ text: line.slice(2) }] });
    } else if (line.startsWith('- ')) {
      blocks.push({ type: 'list', ordered: false, items: [line.slice(2)] });
    } else {
      const img = line.match(/^!\[([^\]]*)\]\(([^\s)]+)/);
      if (img) {
        blocks.push({ type: 'image', alt: img[1] || 'Figure', url: img[2] });
      } else {
        blocks.push({ type: 'paragraph', text: line, runs: [{ text: line }] });
      }
    }
  }
  return blocks;
}

export default function StoryEditorPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const router = useRouter();
  const { user, loading: authLoading } = useLumenAuth();
  const isNew = id === 'new';

  const [articleId, setArticleId] = useState<string | null>(isNew ? null : id);
  const [slug, setSlug] = useState<string>('');
  const [status, setStatus] = useState<LifecycleStatus>('draft');
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [topic, setTopic] = useState<TopicSlug>('culture');
  const [coverUrl, setCoverUrl] = useState('/images/articles/design-atelier.svg');
  const [coverAlt, setCoverAlt] = useState('Editorial illustration');
  const [bodyMarkdown, setBodyMarkdown] = useState(
    'Open with a compelling scene.\n\nWrite your second paragraph here.\n\n## Section heading\n\nContinue your argument with clarity and restraint.'
  );
  const [isPaid, setIsPaid] = useState(false);
  const [priceSats, setPriceSats] = useState(250);
  const [previewCount, setPreviewCount] = useState(2);
  const [includesFutureRevisions, setIncludesFutureRevisions] = useState(true);
  const [changeNote, setChangeNote] = useState('');

  const [revisions, setRevisions] = useState<ArticleRevision[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const [autosaveState, setAutosaveState] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [dirty, setDirty] = useState(false);

  const loadExisting = useCallback(async (targetId: string) => {
    const [artRes, revRes] = await Promise.all([
      fetch(`/api/v1/articles/${targetId}`, { cache: 'no-store' }),
      fetch(`/api/v1/articles/${targetId}/revisions`, { cache: 'no-store' }),
    ]);
    if (artRes.ok) {
      const data = await artRes.json();
      const art = data.article;
      setSlug(art.slug);
      setStatus(art.status);
      setTitle(art.title);
      setSubtitle(art.subtitle);
      setTopic(art.topic);
      setCoverUrl(art.cover_image_url);
      setCoverAlt(art.cover_image_alt);
      setIsPaid(art.offer.is_paid);
      setPriceSats(art.offer.price_sats || 250);
      setIncludesFutureRevisions(art.offer.includes_future_revisions);
    }
    if (revRes.ok) {
      const rData = (await revRes.json()) as { revisions: ArticleRevision[] };
      setRevisions(rData.revisions || []);
      if (rData.revisions && rData.revisions[0]) {
        setBodyMarkdown(rData.revisions[0].body_markdown);
        setPreviewCount(rData.revisions[0].preview_paragraph_count);
      }
    }
  }, []);

  useEffect(() => {
    if (isNew || !user) return;
    let active = true;
    Promise.all([
      fetch(`/api/v1/articles/${id}`, { cache: 'no-store' }),
      fetch(`/api/v1/articles/${id}/revisions`, { cache: 'no-store' }),
    ]).then(async ([artRes, revRes]) => {
      if (!active) return;
      if (artRes.ok) {
        const data = await artRes.json();
        const art = data.article;
        setSlug(art.slug);
        setStatus(art.status);
        setTitle(art.title);
        setSubtitle(art.subtitle);
        setTopic(art.topic);
        setCoverUrl(art.cover_image_url);
        setCoverAlt(art.cover_image_alt);
        setIsPaid(art.offer.is_paid);
        setPriceSats(art.offer.price_sats || 250);
        setIncludesFutureRevisions(art.offer.includes_future_revisions);
      }
      if (revRes.ok) {
        const rData = (await revRes.json()) as { revisions: ArticleRevision[] };
        setRevisions(rData.revisions || []);
        if (rData.revisions && rData.revisions[0]) {
          setBodyMarkdown(rData.revisions[0].body_markdown);
          setPreviewCount(rData.revisions[0].preview_paragraph_count);
        }
      }
    });
    return () => {
      active = false;
    };
  }, [isNew, id, user]);

  const handleSave = useCallback(
    async (createSnapshot = false) => {
      if (!user) return;
      setError(null);
      setAutosaveState('Saving...');
      try {
        if (!articleId) {
          const res = await fetch('/api/v1/articles', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-Requested-With': 'lumen-ui',
            },
            body: JSON.stringify({
              title: title || 'Untitled essay',
              subtitle,
              topic,
              body_markdown: bodyMarkdown,
              cover_image_url: coverUrl,
              cover_image_alt: coverAlt,
              is_paid: isPaid,
              price_sats: Number(priceSats),
              preview_paragraph_count: Number(previewCount),
              includes_future_revisions: includesFutureRevisions,
            }),
          });
          const data = (await res.json()) as { id?: string; slug?: string; error?: string };
          if (!res.ok || !data.id) throw new Error(data.error || 'Failed to create draft');
          setArticleId(data.id);
          setSlug(data.slug || '');
          setDirty(false);
          setAutosaveState(`Saved at ${new Date().toLocaleTimeString()}`);
          router.replace(`/write/${data.id}`);
          return data.id;
        } else if (createSnapshot) {
          const res = await fetch(`/api/v1/articles/${articleId}/revisions`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-Requested-With': 'lumen-ui',
            },
            body: JSON.stringify({
              title,
              subtitle,
              topic,
              body_markdown: bodyMarkdown,
              cover_image_url: coverUrl,
              cover_image_alt: coverAlt,
              is_paid: isPaid,
              price_sats: Number(priceSats),
              preview_paragraph_count: Number(previewCount),
              includes_future_revisions: includesFutureRevisions,
              change_note: changeNote || 'Revision snapshot',
            }),
          });
          const data = (await res.json()) as { error?: string };
          if (!res.ok) throw new Error(data.error || 'Failed to create revision');
          setDirty(false);
          setChangeNote('');
          setAutosaveState(`Revision snapshot saved at ${new Date().toLocaleTimeString()}`);
          await loadExisting(articleId);
          return articleId;
        } else {
          const res = await fetch(`/api/v1/articles/${articleId}`, {
            method: 'PATCH',
            headers: {
              'Content-Type': 'application/json',
              'X-Requested-With': 'lumen-ui',
            },
            body: JSON.stringify({
              title,
              subtitle,
              topic,
              body_markdown: bodyMarkdown,
              cover_image_url: coverUrl,
              cover_image_alt: coverAlt,
              is_paid: isPaid,
              price_sats: Number(priceSats),
              preview_paragraph_count: Number(previewCount),
              includes_future_revisions: includesFutureRevisions,
            }),
          });
          const data = (await res.json()) as { error?: string };
          if (!res.ok) throw new Error(data.error || 'Autosave failed');
          setDirty(false);
          setAutosaveState(`Autosaved at ${new Date().toLocaleTimeString()}`);
          return articleId;
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Save error');
        setAutosaveState('Save failed');
        return null;
      }
    },
    [
      user,
      articleId,
      title,
      subtitle,
      topic,
      bodyMarkdown,
      coverUrl,
      coverAlt,
      isPaid,
      priceSats,
      previewCount,
      includesFutureRevisions,
      changeNote,
      router,
      loadExisting,
    ]
  );

  // Draft autosave every 4 seconds when dirty and existing draft
  useEffect(() => {
    if (!dirty || !articleId || !user) return;
    const t = setTimeout(() => {
      handleSave(false);
    }, 3500);
    return () => clearTimeout(t);
  }, [dirty, articleId, user, handleSave]);

  const handleLifecycle = async (targetStatus: LifecycleStatus) => {
    const savedId = await handleSave(targetStatus === 'revised');
    const idToUse = savedId || articleId;
    if (!idToUse) return;
    const res = await fetch(`/api/v1/articles/${idToUse}/publish`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'lumen-ui',
      },
      body: JSON.stringify({ status: targetStatus }),
    });
    const data = (await res.json()) as { status?: LifecycleStatus; error?: string };
    if (!res.ok) {
      setError(data.error || 'Lifecycle transition failed');
      return;
    }
    setStatus(data.status || targetStatus);
    setAutosaveState(`Status updated to ${targetStatus}`);
    await loadExisting(idToUse);
  };

  const handleUploadImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    const fd = new FormData();
    fd.append('file', file);
    fd.append('alt_text', coverAlt || title || 'Uploaded figure');
    const res = await fetch('/api/v1/media', {
      method: 'POST',
      headers: { 'X-Requested-With': 'lumen-ui' },
      body: fd,
    });
    const data = (await res.json()) as {
      media?: { public_url: string; alt_text: string };
      error?: string;
    };
    if (!res.ok || !data.media) {
      setError(data.error || 'Image upload failed');
      return;
    }
    setBodyMarkdown((prev) => `${prev}\n\n![${data.media!.alt_text}](${data.media!.public_url})`);
    setDirty(true);
  };

  const insertSnippet = (snippet: string) => {
    setBodyMarkdown((prev) => `${prev}\n\n${snippet}`);
    setDirty(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F1E4] text-[#0D2636] dark:bg-[#091B27] dark:text-[#F4EFE3]">
      <SiteHeader />

      <main className="flex-1 max-w-[1220px] w-full mx-auto px-4 sm:px-6 py-8 space-y-6">
        <div className="border-b border-[#D6CEBC] dark:border-[#F6F1E4]/20 pb-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Link href="/write" className="text-xs underline underline-offset-4">
              ← Studio
            </Link>
            <span className="text-xs uppercase tracking-wider text-[#CE9118] font-[family-name:var(--font-sans-ui)]">
              Status: {status}
            </span>
            {autosaveState && (
              <span className="text-xs text-[#465B68] dark:text-[#F4EFE3]/70">
                {autosaveState}
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setShowPreview(!showPreview)}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs border border-[#0D2636] dark:border-[#F6F1E4]/35"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>{showPreview ? 'Edit prose' : 'Preview'}</span>
            </button>
            <button
              type="button"
              onClick={() => handleSave(false)}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs border border-[#0D2636] dark:border-[#F6F1E4]/35"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save draft</span>
            </button>
            {status === 'draft' && (
              <button
                type="button"
                onClick={() => handleLifecycle('preview')}
                className="px-3 py-2 text-xs border border-[#0D2636] dark:border-[#F6F1E4]/35"
              >
                Mark Preview
              </button>
            )}
            <button
              type="button"
              onClick={() =>
                handleLifecycle(
                  status === 'published' || status === 'revised' ? 'revised' : 'published'
                )
              }
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-[#E5A929] text-[#0D2636] hover:bg-[#CE9118]"
            >
              <Send className="w-3.5 h-3.5" />
              <span>
                {status === 'published' || status === 'revised'
                  ? 'Publish revision'
                  : 'Publish'}
              </span>
            </button>
            {(status === 'published' || status === 'revised') && (
              <button
                type="button"
                onClick={() => handleLifecycle('withdrawn')}
                className="px-3 py-2 text-xs text-red-800 dark:text-red-300 border border-red-400"
              >
                Withdraw
              </button>
            )}
          </div>
        </div>

        {error && (
          <p className="p-3 text-xs border border-red-400 bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-200">
            {error}
          </p>
        )}

        {!authLoading && !user ? (
          <div className="p-8 border border-[#D6CEBC] bg-[#FAF7EF] dark:bg-[#0D2636]">
            <p className="text-sm">Please sign in from Account to edit stories.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Main Editor / Live Sanitized Preview */}
            <div className="lg:col-span-8 space-y-5">
              {showPreview ? (
                <div className="border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] p-8 space-y-6">
                  <p className="text-xs uppercase tracking-widest text-[#CE9118]">
                    Sanitized Preview ({isPaid ? `Paid: ${priceSats} sats` : 'Free'})
                  </p>
                  <h1 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl font-medium">
                    {title || 'Untitled essay'}
                  </h1>
                  <p className="text-lg text-[#465B68] dark:text-[#F4EFE3]/80">{subtitle}</p>
                  <EditorialBlocks blocks={previewClientParse(bodyMarkdown)} />
                </div>
              ) : (
                <div className="space-y-4">
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => {
                      setTitle(e.target.value);
                      setDirty(true);
                    }}
                    placeholder="Essay headline..."
                    className="w-full px-4 py-3 font-[family-name:var(--font-playfair)] text-2xl sm:text-3xl bg-[#FAF7EF] dark:bg-[#0D2636] border border-[#D6CEBC] dark:border-[#F6F1E4]/25 focus:outline-none focus:border-[#E5A929]"
                  />

                  <input
                    type="text"
                    value={subtitle}
                    onChange={(e) => {
                      setSubtitle(e.target.value);
                      setDirty(true);
                    }}
                    placeholder="Concise deck / subtitle..."
                    className="w-full px-4 py-2.5 text-base bg-[#FAF7EF] dark:bg-[#0D2636] border border-[#D6CEBC] dark:border-[#F6F1E4]/25 focus:outline-none focus:border-[#E5A929]"
                  />

                  {/* Formatting Toolbar */}
                  <div className="flex flex-wrap items-center gap-2 p-2 border border-[#D6CEBC] dark:border-[#F6F1E4]/20 bg-[#FAF7EF] dark:bg-[#0D2636] text-xs">
                    <button
                      type="button"
                      onClick={() => insertSnippet('## Section heading')}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 hover:bg-[#ECE4D0] dark:hover:bg-[#091B27]"
                    >
                      <Heading2 className="w-3.5 h-3.5" />
                      <span>Heading</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => insertSnippet('- List item one\n- List item two')}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 hover:bg-[#ECE4D0] dark:hover:bg-[#091B27]"
                    >
                      <List className="w-3.5 h-3.5" />
                      <span>List</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => insertSnippet('> A memorable pull quote belongs here.')}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 hover:bg-[#ECE4D0] dark:hover:bg-[#091B27]"
                    >
                      <Quote className="w-3.5 h-3.5" />
                      <span>Quote</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => insertSnippet('[Link label](https://example.org)')}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 hover:bg-[#ECE4D0] dark:hover:bg-[#091B27]"
                    >
                      <Link2 className="w-3.5 h-3.5" />
                      <span>Link</span>
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        insertSnippet(
                          '![Describe the image cleanly](/images/articles/personal-library.svg "Fig. 1 — Caption")'
                        )
                      }
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 hover:bg-[#ECE4D0] dark:hover:bg-[#091B27]"
                    >
                      <ImagePlus className="w-3.5 h-3.5" />
                      <span>Image</span>
                    </button>
                    <label className="inline-flex items-center gap-1 px-2.5 py-1.5 hover:bg-[#ECE4D0] dark:hover:bg-[#091B27] cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Upload PNG/JPG</span>
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/webp"
                        onChange={handleUploadImage}
                        className="sr-only"
                      />
                    </label>
                  </div>

                  <textarea
                    rows={18}
                    value={bodyMarkdown}
                    onChange={(e) => {
                      setBodyMarkdown(e.target.value);
                      setDirty(true);
                    }}
                    placeholder="Write in clean Markdown. Unsafe HTML tags and script attributes are stripped automatically on save."
                    className="w-full p-4 text-base leading-relaxed bg-[#FAF7EF] dark:bg-[#0D2636] border border-[#D6CEBC] dark:border-[#F6F1E4]/25 focus:outline-none focus:border-[#E5A929]"
                  />
                </div>
              )}
            </div>

            {/* Right: Publishing & Offer Configuration */}
            <aside className="lg:col-span-4 space-y-6">
              <div className="border border-[#D6CEBC] dark:border-[#F6F1E4]/25 bg-[#FAF7EF] dark:bg-[#0D2636] p-5 space-y-4 text-xs">
                <h2 className="font-[family-name:var(--font-playfair)] text-xl font-medium">
                  Edition &amp; Access Settings
                </h2>

                <div>
                  <label className="block font-medium mb-1">Topic department</label>
                  <select
                    value={topic}
                    onChange={(e) => {
                      setTopic(e.target.value as TopicSlug);
                      setDirty(true);
                    }}
                    className="w-full px-3 py-2 bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                  >
                    <option value="technology">Technology</option>
                    <option value="culture">Culture</option>
                    <option value="science">Science</option>
                    <option value="economics">Economics</option>
                    <option value="design">Design</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium mb-1">Cover image URL</label>
                  <input
                    type="text"
                    value={coverUrl}
                    onChange={(e) => {
                      setCoverUrl(e.target.value);
                      setDirty(true);
                    }}
                    className="w-full px-3 py-2 bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                  />
                </div>

                <div>
                  <label className="block font-medium mb-1">Cover alt text (required)</label>
                  <input
                    type="text"
                    value={coverAlt}
                    onChange={(e) => {
                      setCoverAlt(e.target.value);
                      setDirty(true);
                    }}
                    className="w-full px-3 py-2 bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                  />
                </div>

                <div className="pt-3 border-t border-[#D6CEBC] dark:border-[#F6F1E4]/15 space-y-3">
                  <label className="flex items-center gap-2 font-medium cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isPaid}
                      onChange={(e) => {
                        setIsPaid(e.target.checked);
                        setDirty(true);
                      }}
                    />
                    <span>Paid edition (Lightning paywall)</span>
                  </label>

                  {isPaid && (
                    <>
                      <div>
                        <label className="block font-medium mb-1">Price (integer sats)</label>
                        <input
                          type="number"
                          min={1}
                          step={1}
                          value={priceSats}
                          onChange={(e) => {
                            setPriceSats(parseInt(e.target.value || '100', 10));
                            setDirty(true);
                          }}
                          className="w-full px-3 py-2 font-[family-name:var(--font-mono-sats)] bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                        />
                      </div>

                      <div>
                        <label className="block font-medium mb-1">
                          Free preview paragraphs (1–6)
                        </label>
                        <input
                          type="number"
                          min={1}
                          max={6}
                          value={previewCount}
                          onChange={(e) => {
                            setPreviewCount(parseInt(e.target.value || '2', 10));
                            setDirty(true);
                          }}
                          className="w-full px-3 py-2 font-[family-name:var(--font-mono-sats)] bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                        />
                      </div>

                      <label className="flex items-start gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={includesFutureRevisions}
                          onChange={(e) => {
                            setIncludesFutureRevisions(e.target.checked);
                            setDirty(true);
                          }}
                          className="mt-0.5"
                        />
                        <span>
                          Include future revisions for existing buyers (communicated before payment)
                        </span>
                      </label>
                    </>
                  )}
                </div>

                {articleId && (
                  <div className="pt-3 border-t border-[#D6CEBC] dark:border-[#F6F1E4]/15 space-y-2">
                    <label className="block font-medium">Revision change note</label>
                    <input
                      type="text"
                      value={changeNote}
                      onChange={(e) => setChangeNote(e.target.value)}
                      placeholder="e.g. Expanded section 2"
                      className="w-full px-3 py-2 bg-white dark:bg-[#091B27] border border-[#D6CEBC] dark:border-[#F6F1E4]/25"
                    />
                    <button
                      type="button"
                      onClick={() => handleSave(true)}
                      className="w-full py-2 border border-[#0D2636] dark:border-[#F6F1E4]/35 hover:bg-[#0D2636]/5 font-medium"
                    >
                      Save revision snapshot
                    </button>
                  </div>
                )}

                {slug && (status === 'published' || status === 'revised' || status === 'preview') && (
                  <Link
                    href={`/articles/${slug}`}
                    className="block text-center py-2 underline decoration-[#E5A929] underline-offset-4"
                  >
                    Open published reader view →
                  </Link>
                )}
              </div>

              {/* Revision History */}
              {revisions.length > 0 && (
                <div className="border border-[#D6CEBC] dark:border-[#F6F1E4]/25 bg-[#FAF7EF] dark:bg-[#0D2636] p-5 space-y-3 text-xs">
                  <h3 className="font-[family-name:var(--font-playfair)] text-lg font-medium">
                    Revision History ({revisions.length})
                  </h3>
                  <ul className="divide-y divide-[#D6CEBC] dark:divide-[#F6F1E4]/15">
                    {revisions.map((rev) => (
                      <li key={rev.id} className="py-2 flex justify-between gap-2">
                        <div>
                          <p className="font-medium">v{rev.revision_number} · {rev.change_note}</p>
                          <p className="text-[#465B68] dark:text-[#F4EFE3]/65">
                            {new Date(rev.created_at).toLocaleString()}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setBodyMarkdown(rev.body_markdown);
                            setTitle(rev.title);
                            setSubtitle(rev.subtitle);
                            setDirty(true);
                          }}
                          className="underline text-[#CE9118] self-start"
                        >
                          Load
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </aside>
          </div>
        )}
      </main>

      <SiteFooter />
    </div>
  );
}
