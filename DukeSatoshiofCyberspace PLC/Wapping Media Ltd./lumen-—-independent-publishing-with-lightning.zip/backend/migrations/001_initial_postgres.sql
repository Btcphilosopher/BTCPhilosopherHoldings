-- Lumen Independent Publishing with Lightning
-- PostgreSQL Initial Migration (001)
-- All monetary columns use INTEGER/BIGINT sats (never floating-point).

BEGIN;

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  handle TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK (role IN ('reader', 'author', 'admin')),
  demo_balance_sats BIGINT NOT NULL DEFAULT 5000 CHECK (demo_balance_sats >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS author_profiles (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  bio TEXT NOT NULL DEFAULT '',
  publication_name TEXT NOT NULL DEFAULT '',
  lightning_destination TEXT,
  destination_verified BOOLEAN NOT NULL DEFAULT FALSE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS publications (
  id TEXT PRIMARY KEY,
  owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  tagline TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS articles (
  id TEXT PRIMARY KEY,
  author_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  publication_id TEXT NOT NULL REFERENCES publications(id) ON DELETE CASCADE,
  slug TEXT NOT NULL UNIQUE,
  topic TEXT NOT NULL CHECK (topic IN ('technology', 'culture', 'science', 'economics', 'design')),
  status TEXT NOT NULL CHECK (status IN ('draft', 'preview', 'published', 'revised', 'withdrawn')),
  cover_image_url TEXT NOT NULL,
  cover_image_alt TEXT NOT NULL,
  featured_rank INTEGER,
  current_revision_id TEXT,
  current_offer_id TEXT,
  view_count INTEGER NOT NULL DEFAULT 0,
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS article_revisions (
  id TEXT PRIMARY KEY,
  article_id TEXT NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
  revision_number INTEGER NOT NULL,
  title TEXT NOT NULL,
  subtitle TEXT NOT NULL,
  body_markdown TEXT NOT NULL,
  preview_paragraph_count INTEGER NOT NULL DEFAULT 2 CHECK (preview_paragraph_count BETWEEN 1 AND 6),
  reading_time_minutes INTEGER NOT NULL DEFAULT 4,
  change_note TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (article_id, revision_number)
);

CREATE TABLE IF NOT EXISTS media_assets (
  id TEXT PRIMARY KEY,
  owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  object_key TEXT NOT NULL UNIQUE,
  public_url TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  sha256 TEXT NOT NULL,
  alt_text TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS follows (
  follower_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  author_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (follower_user_id, author_user_id)
);

CREATE TABLE IF NOT EXISTS bookmarks (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  article_id TEXT NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, article_id)
);

CREATE TABLE IF NOT EXISTS article_offers (
  id TEXT PRIMARY KEY,
  article_id TEXT NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
  is_paid BOOLEAN NOT NULL DEFAULT FALSE,
  price_sats BIGINT NOT NULL DEFAULT 0 CHECK (price_sats >= 0),
  customer_fee_sats BIGINT NOT NULL DEFAULT 0 CHECK (customer_fee_sats >= 0),
  commission_bps INTEGER NOT NULL DEFAULT 1000 CHECK (commission_bps >= 0 AND commission_bps <= 5000),
  fee_policy_version TEXT NOT NULL,
  includes_future_revisions BOOLEAN NOT NULL DEFAULT TRUE,
  refund_terms TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payment_intents (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('article_purchase', 'author_tip')),
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  article_id TEXT REFERENCES articles(id) ON DELETE SET NULL,
  recipient_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  offer_id TEXT REFERENCES article_offers(id) ON DELETE SET NULL,
  revision_id TEXT REFERENCES article_revisions(id) ON DELETE SET NULL,
  amount_sats BIGINT NOT NULL CHECK (amount_sats > 0),
  customer_fee_sats BIGINT NOT NULL DEFAULT 0 CHECK (customer_fee_sats >= 0),
  total_sats BIGINT NOT NULL CHECK (total_sats > 0),
  commission_sats BIGINT NOT NULL DEFAULT 0 CHECK (commission_sats >= 0),
  author_payable_sats BIGINT NOT NULL DEFAULT 0 CHECK (author_payable_sats >= 0),
  fee_policy_version TEXT NOT NULL,
  includes_future_revisions BOOLEAN NOT NULL DEFAULT TRUE,
  status TEXT NOT NULL CHECK (status IN ('created', 'awaiting_payment', 'settled', 'expired', 'cancelled', 'reconciliation_required')),
  fulfillment_status TEXT NOT NULL CHECK (fulfillment_status IN ('not_applicable', 'pending', 'fulfilled', 'failed_retryable')),
  simulate_fulfillment_failure BOOLEAN NOT NULL DEFAULT FALSE,
  provider TEXT NOT NULL,
  provider_account TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at TIMESTAMPTZ NOT NULL,
  settled_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS lightning_invoices (
  id TEXT PRIMARY KEY,
  payment_intent_id TEXT NOT NULL UNIQUE REFERENCES payment_intents(id) ON DELETE CASCADE,
  provider TEXT NOT NULL,
  provider_invoice_id TEXT NOT NULL UNIQUE,
  payment_hash TEXT NOT NULL,
  bolt11 TEXT NOT NULL,
  amount_sats BIGINT NOT NULL CHECK (amount_sats > 0),
  amount_msat BIGINT NOT NULL CHECK (amount_msat > 0),
  status TEXT NOT NULL CHECK (status IN ('created', 'awaiting_payment', 'settled', 'expired', 'cancelled', 'reconciliation_required')),
  expires_at TIMESTAMPTZ NOT NULL,
  settled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payment_events (
  id TEXT PRIMARY KEY,
  provider TEXT NOT NULL,
  provider_event_id TEXT NOT NULL,
  payment_intent_id TEXT NOT NULL REFERENCES payment_intents(id) ON DELETE CASCADE,
  provider_invoice_id TEXT NOT NULL,
  event_status TEXT NOT NULL,
  amount_sats BIGINT NOT NULL,
  raw_payload_redacted TEXT NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (provider, provider_event_id)
);

CREATE TABLE IF NOT EXISTS purchases (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  article_id TEXT NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
  offer_id TEXT NOT NULL REFERENCES article_offers(id),
  revision_id TEXT NOT NULL REFERENCES article_revisions(id),
  payment_intent_id TEXT NOT NULL UNIQUE REFERENCES payment_intents(id),
  price_sats BIGINT NOT NULL,
  customer_fee_sats BIGINT NOT NULL,
  total_sats BIGINT NOT NULL,
  commission_sats BIGINT NOT NULL,
  author_payable_sats BIGINT NOT NULL,
  fee_policy_version TEXT NOT NULL,
  includes_future_revisions BOOLEAN NOT NULL DEFAULT TRUE,
  status TEXT NOT NULL CHECK (status IN ('active', 'refunded')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS entitlements (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  article_id TEXT NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
  purchase_id TEXT NOT NULL UNIQUE REFERENCES purchases(id) ON DELETE CASCADE,
  locked_revision_id TEXT NOT NULL REFERENCES article_revisions(id),
  includes_future_revisions BOOLEAN NOT NULL DEFAULT TRUE,
  granted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  revoked_at TIMESTAMPTZ,
  UNIQUE (user_id, article_id)
);

CREATE TABLE IF NOT EXISTS tips (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  article_id TEXT REFERENCES articles(id) ON DELETE SET NULL,
  payment_intent_id TEXT NOT NULL UNIQUE REFERENCES payment_intents(id),
  amount_sats BIGINT NOT NULL CHECK (amount_sats > 0),
  commission_sats BIGINT NOT NULL DEFAULT 0,
  author_payable_sats BIGINT NOT NULL CHECK (author_payable_sats >= 0),
  note TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL CHECK (status IN ('settled', 'refunded')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ledger_entries (
  id TEXT PRIMARY KEY,
  entry_type TEXT NOT NULL CHECK (entry_type IN ('customer_payment', 'author_payable', 'platform_revenue', 'provider_charge', 'network_fee', 'refund', 'payout')),
  user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  article_id TEXT REFERENCES articles(id) ON DELETE SET NULL,
  payment_intent_id TEXT REFERENCES payment_intents(id) ON DELETE SET NULL,
  related_id TEXT,
  amount_sats BIGINT NOT NULL,
  direction TEXT NOT NULL CHECK (direction IN ('credit', 'debit')),
  description TEXT NOT NULL,
  is_demo BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS refund_requests (
  id TEXT PRIMARY KEY,
  purchase_id TEXT NOT NULL UNIQUE REFERENCES purchases(id),
  requester_user_id TEXT NOT NULL REFERENCES users(id),
  reviewer_user_id TEXT REFERENCES users(id),
  requested_amount_sats BIGINT NOT NULL CHECK (requested_amount_sats > 0),
  reason TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending_review', 'approved_settled', 'rejected', 'payout_failed')),
  resolution_note TEXT NOT NULL DEFAULT '',
  outgoing_reference TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  resolved_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS payouts (
  id TEXT PRIMARY KEY,
  author_user_id TEXT NOT NULL REFERENCES users(id),
  idempotency_key TEXT NOT NULL UNIQUE,
  destination TEXT NOT NULL,
  amount_sats BIGINT NOT NULL CHECK (amount_sats > 0),
  network_fee_sats BIGINT NOT NULL DEFAULT 0,
  provider TEXT NOT NULL,
  provider_payout_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('requested', 'pending_reconciliation', 'completed', 'failed')),
  message TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  actor_user_id TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  details_json TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_articles_topic_status ON articles (topic, status);
CREATE INDEX IF NOT EXISTS idx_payment_intents_user_status ON payment_intents (user_id, status);
CREATE INDEX IF NOT EXISTS idx_ledger_entries_user ON ledger_entries (user_id, created_at DESC);

COMMIT;
