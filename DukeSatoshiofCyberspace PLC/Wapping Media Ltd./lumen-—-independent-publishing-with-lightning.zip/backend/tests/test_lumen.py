"""Lumen backend verification suite (compatible with both pytest and python -m unittest)."""
from __future__ import annotations

import json
import os
import sqlite3
import sys
import unittest
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.accounting import (  # noqa: E402
    compute_purchase_accounting,
    process_refund_approval,
    process_verified_event,
    reconcile_pending_fulfillments,
    reconcile_pending_payout,
)
from app.lightning import DeterministicSimulatorProvider, validate_lightning_destination  # noqa: E402
from app.sanitize import strip_dangerous_html, validate_safe_url  # noqa: E402
from app.worker import run_reconciliation_cycle  # noqa: E402


def create_memory_db() -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE users (id TEXT PRIMARY KEY, email TEXT, password_hash TEXT, display_name TEXT, handle TEXT, role TEXT, demo_balance_sats INTEGER, created_at TEXT);
        CREATE TABLE articles (id TEXT PRIMARY KEY, author_user_id TEXT, slug TEXT, topic TEXT, status TEXT, current_revision_id TEXT, current_offer_id TEXT);
        CREATE TABLE article_revisions (id TEXT PRIMARY KEY, article_id TEXT, revision_number INTEGER, title TEXT, body_markdown TEXT);
        CREATE TABLE article_offers (id TEXT PRIMARY KEY, article_id TEXT, is_paid INTEGER, price_sats INTEGER, customer_fee_sats INTEGER, commission_bps INTEGER, fee_policy_version TEXT, includes_future_revisions INTEGER);
        CREATE TABLE payment_intents (id TEXT PRIMARY KEY, kind TEXT, user_id TEXT, article_id TEXT, recipient_user_id TEXT, offer_id TEXT, revision_id TEXT, amount_sats INTEGER, customer_fee_sats INTEGER, total_sats INTEGER, commission_sats INTEGER, author_payable_sats INTEGER, fee_policy_version TEXT, includes_future_revisions INTEGER, status TEXT, fulfillment_status TEXT, simulate_fulfillment_failure INTEGER, provider TEXT, provider_account TEXT, created_at TEXT, expires_at TEXT, settled_at TEXT);
        CREATE TABLE lightning_invoices (id TEXT PRIMARY KEY, payment_intent_id TEXT UNIQUE, provider TEXT, provider_invoice_id TEXT UNIQUE, payment_hash TEXT, bolt11 TEXT, amount_sats INTEGER, amount_msat INTEGER, status TEXT, expires_at TEXT, settled_at TEXT, created_at TEXT);
        CREATE TABLE payment_events (id TEXT PRIMARY KEY, provider TEXT, provider_event_id TEXT, payment_intent_id TEXT, provider_invoice_id TEXT, event_status TEXT, amount_sats INTEGER, raw_payload_redacted TEXT, received_at TEXT, UNIQUE(provider, provider_event_id));
        CREATE TABLE purchases (id TEXT PRIMARY KEY, user_id TEXT, article_id TEXT, offer_id TEXT, revision_id TEXT, payment_intent_id TEXT UNIQUE, price_sats INTEGER, customer_fee_sats INTEGER, total_sats INTEGER, commission_sats INTEGER, author_payable_sats INTEGER, fee_policy_version TEXT, includes_future_revisions INTEGER, status TEXT, created_at TEXT);
        CREATE TABLE entitlements (id TEXT PRIMARY KEY, user_id TEXT, article_id TEXT, purchase_id TEXT UNIQUE, locked_revision_id TEXT, includes_future_revisions INTEGER, granted_at TEXT, revoked_at TEXT, UNIQUE(user_id, article_id));
        CREATE TABLE tips (id TEXT PRIMARY KEY, user_id TEXT, recipient_user_id TEXT, article_id TEXT, payment_intent_id TEXT UNIQUE, amount_sats INTEGER, commission_sats INTEGER, author_payable_sats INTEGER, note TEXT, status TEXT, created_at TEXT);
        CREATE TABLE ledger_entries (id TEXT PRIMARY KEY, entry_type TEXT, user_id TEXT, article_id TEXT, payment_intent_id TEXT, related_id TEXT, amount_sats INTEGER, direction TEXT, description TEXT, is_demo INTEGER, created_at TEXT);
        CREATE TABLE refund_requests (id TEXT PRIMARY KEY, purchase_id TEXT UNIQUE, requester_user_id TEXT, reviewer_user_id TEXT, requested_amount_sats INTEGER, reason TEXT, status TEXT, resolution_note TEXT, outgoing_reference TEXT, created_at TEXT, resolved_at TEXT);
        CREATE TABLE payouts (id TEXT PRIMARY KEY, author_user_id TEXT, idempotency_key TEXT UNIQUE, destination TEXT, amount_sats INTEGER, network_fee_sats INTEGER, provider TEXT, provider_payout_id TEXT, status TEXT, message TEXT, created_at TEXT, completed_at TEXT);
        """
    )
    now = datetime.now(timezone.utc).isoformat()
    conn.execute("INSERT INTO users VALUES ('u_reader', 'r@x.com', 'h', 'Reader', 'reader', 'reader', 2500, ?)", (now,))
    conn.execute("INSERT INTO users VALUES ('u_author', 'a@x.com', 'h', 'Eleanor Hart', 'eleanor', 'author', 4000, ?)", (now,))
    conn.execute("INSERT INTO users VALUES ('u_admin', 'adm@x.com', 'h', 'Admin', 'admin', 'admin', 0, ?)", (now,))
    conn.execute("INSERT INTO articles VALUES ('art_1', 'u_author', 'personal-library', 'culture', 'published', 'rev_1', 'off_1')")
    conn.execute("INSERT INTO article_revisions VALUES ('rev_1', 'art_1', 1, 'The quiet return of the personal library', 'Secret full body')")
    conn.execute("INSERT INTO article_offers VALUES ('off_1', 'art_1', 1, 250, 0, 1000, 'fee-policy-2026-v1', 1)")
    return conn


class TestLumenPaymentsAndSecurity(unittest.TestCase):
    def setUp(self) -> None:
        self.conn = create_memory_db()
        self.sim = DeterministicSimulatorProvider("test-webhook-secret-123456")

    def tearDown(self) -> None:
        self.conn.close()

    def _seed_intent(self, intent_id: str, expires_delta_sec: int = 900, sim_fail: int = 0) -> tuple[str, str]:
        inv = self.sim.create_invoice(intent_id, 250, "Test unlock", expires_delta_sec)
        now = datetime.now(timezone.utc)
        exp = (now + timedelta(seconds=expires_delta_sec)).isoformat()
        self.conn.execute(
            """INSERT INTO payment_intents VALUES (
                 ?, 'article_purchase', 'u_reader', 'art_1', 'u_author', 'off_1', 'rev_1',
                 250, 0, 250, 25, 225, 'fee-policy-2026-v1', 1, 'awaiting_payment', 'pending', ?, 'simulator', ?, ?, ?, NULL
               )""",
            (intent_id, sim_fail, self.sim.account_id, now.isoformat(), exp),
        )
        self.conn.execute(
            """INSERT INTO lightning_invoices VALUES (
                 ?, ?, 'simulator', ?, ?, ?, 250, 250000, 'awaiting_payment', ?, NULL, ?
               )""",
            (f"inv_{intent_id}", intent_id, inv.provider_invoice_id, inv.payment_hash, inv.bolt11, exp, now.isoformat()),
        )
        return inv.provider_invoice_id, inv.payment_hash

    def test_01_integer_monetary_arithmetic(self) -> None:
        acc = compute_purchase_accounting(250, 0, 1000)
        self.assertEqual(acc.total_sats, 250)
        self.assertEqual(acc.commission_sats, 25)
        self.assertEqual(acc.author_payable_sats, 225)
        with self.assertRaises(TypeError):
            compute_purchase_accounting(250.5)  # type: ignore[arg-type]

    def test_02_event_authentication_rejects_bad_signature(self) -> None:
        inv_id, ph = self._seed_intent("pi_auth_1")
        body = json.dumps({
            "provider_event_id": "evt_1",
            "provider_invoice_id": inv_id,
            "payment_hash": ph,
            "payment_intent_id": "pi_auth_1",
            "provider_account": self.sim.account_id,
            "amount_sats": 250,
            "status": "settled",
        })
        with self.assertRaises(ValueError):
            self.sim.verify_provider_event(body, "deadbeef")

    def test_03_duplicate_settlement_is_idempotent(self) -> None:
        inv_id, ph = self._seed_intent("pi_dup_1")
        body = json.dumps({
            "provider_event_id": "evt_dup_1",
            "provider_invoice_id": inv_id,
            "payment_hash": ph,
            "payment_intent_id": "pi_dup_1",
            "provider_account": self.sim.account_id,
            "amount_sats": 250,
            "status": "settled",
        })
        sig = self.sim.sign_event(body)
        ev = self.sim.verify_provider_event(body, sig)

        first = process_verified_event(self.conn, ev)
        second = process_verified_event(self.conn, ev)
        self.assertFalse(first["duplicate"])
        self.assertTrue(second["duplicate"])

        purchases = self.conn.execute("SELECT COUNT(*) AS c FROM purchases").fetchone()["c"]
        payables = self.conn.execute(
            "SELECT COUNT(*) AS c FROM ledger_entries WHERE entry_type='author_payable'"
        ).fetchone()["c"]
        self.assertEqual(purchases, 1)
        self.assertEqual(payables, 1)

    def test_04_invoice_expiry_and_late_settlement_reconciliation(self) -> None:
        inv_id, ph = self._seed_intent("pi_exp_1", expires_delta_sec=-10)
        summary = run_reconciliation_cycle(self.conn)
        self.assertEqual(summary["expired_invoices"], 1)

        body = json.dumps({
            "provider_event_id": "evt_late_1",
            "provider_invoice_id": inv_id,
            "payment_hash": ph,
            "payment_intent_id": "pi_exp_1",
            "provider_account": self.sim.account_id,
            "amount_sats": 250,
            "status": "settled",
        })
        ev = self.sim.verify_provider_event(body, self.sim.sign_event(body))
        res = process_verified_event(self.conn, ev)
        self.assertEqual(res["outcome"], "late_settlement_reconciliation_required")

        recovered = reconcile_pending_fulfillments(self.conn)
        self.assertEqual(recovered, 1)
        ent = self.conn.execute(
            "SELECT * FROM entitlements WHERE user_id='u_reader' AND article_id='art_1'"
        ).fetchone()
        self.assertIsNotNone(ent)

    def test_05_fulfillment_failure_recovery(self) -> None:
        inv_id, ph = self._seed_intent("pi_fail_1", sim_fail=1)
        body = json.dumps({
            "provider_event_id": "evt_fail_1",
            "provider_invoice_id": inv_id,
            "payment_hash": ph,
            "payment_intent_id": "pi_fail_1",
            "provider_account": self.sim.account_id,
            "amount_sats": 250,
            "status": "settled",
        })
        ev = self.sim.verify_provider_event(body, self.sim.sign_event(body))
        res = process_verified_event(self.conn, ev)
        self.assertEqual(res["outcome"], "settled_fulfillment_pending_retry")
        self.assertIsNone(
            self.conn.execute("SELECT id FROM entitlements WHERE user_id='u_reader'").fetchone()
        )

        recovered = reconcile_pending_fulfillments(self.conn)
        self.assertEqual(recovered, 1)
        self.assertIsNotNone(
            self.conn.execute("SELECT id FROM entitlements WHERE user_id='u_reader'").fetchone()
        )

    def test_06_refund_workflow_and_payout_reconciliation(self) -> None:
        inv_id, ph = self._seed_intent("pi_ref_1")
        body = json.dumps({
            "provider_event_id": "evt_ref_1",
            "provider_invoice_id": inv_id,
            "payment_hash": ph,
            "payment_intent_id": "pi_ref_1",
            "provider_account": self.sim.account_id,
            "amount_sats": 250,
            "status": "settled",
        })
        ev = self.sim.verify_provider_event(body, self.sim.sign_event(body))
        process_verified_event(self.conn, ev)

        pur = self.conn.execute("SELECT id FROM purchases LIMIT 1").fetchone()
        self.conn.execute(
            """INSERT INTO refund_requests VALUES (
                 'rr_1', ?, 'u_reader', NULL, 999, 'Accidental double buy', 'pending_review', '', NULL, '2026-11-27', NULL
               )""",
            (pur["id"],),
        )
        # Capped at original purchase total_sats (250, never 999)
        ref_res = process_refund_approval(self.conn, "rr_1", "u_admin", approve=True)
        self.assertEqual(ref_res["status"], "approved_settled")
        self.assertEqual(ref_res["amount_sats"], 250)

        ent = self.conn.execute("SELECT revoked_at FROM entitlements LIMIT 1").fetchone()
        self.assertIsNotNone(ent["revoked_at"])

        # Payout reconciliation
        self.assertTrue(validate_lightning_destination("eleanor@lumen.example"))
        self.assertFalse(validate_lightning_destination("javascript:alert(1)"))
        self.conn.execute(
            """INSERT INTO payouts VALUES (
                 'po_1', 'u_author', 'idem_1', 'unknown@lumen.example', 100, 0, 'simulator_payout', 'sim_po_1', 'pending_reconciliation', 'pending', '2026-11-27', NULL
               )"""
        )
        po_res = reconcile_pending_payout(self.conn, "po_1")
        self.assertEqual(po_res["status"], "completed")

    def test_07_content_sanitization(self) -> None:
        dirty = '<script>alert(1)</script><p onclick="evil()">Hello</p><iframe src="https://evil.test"></iframe>'
        clean = strip_dangerous_html(dirty)
        self.assertNotIn("<script", clean.lower())
        self.assertNotIn("onclick", clean.lower())
        self.assertNotIn("<iframe", clean.lower())
        self.assertEqual(clean, "Hello")
        self.assertIsNone(validate_safe_url("javascript:alert(1)"))
        self.assertEqual(validate_safe_url("https://lumen.press/essay"), "https://lumen.press/essay")


if __name__ == "__main__":
    unittest.main()
