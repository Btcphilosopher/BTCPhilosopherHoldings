"""Background reconciliation and notification worker for Lumen."""
from __future__ import annotations

import logging
import os
import sqlite3
import time
from datetime import datetime, timezone

from .accounting import reconcile_pending_fulfillments, reconcile_pending_payout

logger = logging.getLogger("lumen.worker")


def run_reconciliation_cycle(conn: sqlite3.Connection) -> dict:
    now = datetime.now(timezone.utc).isoformat()
    with conn:
        cur = conn.execute(
            """UPDATE payment_intents
               SET status = 'expired'
               WHERE status IN ('created', 'awaiting_payment') AND expires_at <= ?""",
            (now,),
        )
        conn.execute(
            """UPDATE lightning_invoices
               SET status = 'expired'
               WHERE status IN ('created', 'awaiting_payment') AND expires_at <= ?""",
            (now,),
        )
        expired_count = cur.rowcount

    recovered = reconcile_pending_fulfillments(conn)

    pending_payouts = conn.execute(
        "SELECT id FROM payouts WHERE status = 'pending_reconciliation'"
    ).fetchall()
    reconciled_payouts = 0
    for row in pending_payouts:
        reconcile_pending_payout(conn, row["id"])
        reconciled_payouts += 1

    return {
        "expired_invoices": expired_count,
        "recovered_fulfillments": recovered,
        "reconciled_payouts": reconciled_payouts,
    }


def main() -> None:
    db_path = os.getenv("LUMEN_SQLITE_PATH", "./data/lumen.db")
    interval = int(os.getenv("WORKER_POLL_SECONDS", "15"))
    logger.info("Lumen reconciliation worker started (interval=%ss)", interval)
    while True:
        try:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            summary = run_reconciliation_cycle(conn)
            conn.close()
            if any(summary.values()):
                logger.info("Reconciliation cycle: %s", summary)
        except Exception as exc:  # pragma: no cover
            logger.error("Worker cycle failed: %s", exc)
        time.sleep(interval)


if __name__ == "__main__":
    main()
