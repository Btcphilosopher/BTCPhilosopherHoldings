"""HTML/Markdown sanitization for Lumen editorial content."""
from __future__ import annotations

import re
from urllib.parse import urlparse

SCRIPT_STYLE_RE = re.compile(
    r"<(script|style|iframe|object|embed)[\s\S]*?>[\s\S]*?</\1>", re.IGNORECASE
)
ANY_TAG_RE = re.compile(r"<[^>]+>")


def strip_dangerous_html(raw: str) -> str:
    no_blocks = SCRIPT_STYLE_RE.sub("", raw)
    return ANY_TAG_RE.sub("", no_blocks)


def validate_safe_url(raw_url: str, allow_relative: bool = True) -> str | None:
    trimmed = raw_url.strip()
    if not trimmed:
        return None
    if allow_relative and trimmed.startswith("/") and not trimmed.startswith("//"):
        return trimmed
    parsed = urlparse(trimmed)
    if parsed.scheme in ("http", "https") and parsed.netloc:
        return trimmed
    return None
