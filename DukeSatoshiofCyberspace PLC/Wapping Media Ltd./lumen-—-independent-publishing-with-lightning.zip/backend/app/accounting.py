"""Integer-only monetary accounting, idempotent settlement, refunds, and payout reconciliation."""
from __future__ import annotations

import json
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

from .lightning import VerifiedEvent, validate_lightning_destination

CURRENT_FEE_POLICY_VERSION = "fee-policy-2026-v1"
DEFAULT_PURCHASE_COMMISSION_BPS = 1000  # 10% deducted from author proceeds
MIN_PAYOUT_SATS = 50
MAX_SINGLE_PAYOUT_SATS = 50000


@dataclass(frozen=True)
class PurchaseAccounting:
    price_sats: int
    customer_fee_sats: int
    total_sats: int
    commission_sats: int
    author_payable_sats: int


def compute_purchase_accounting(
    price_sats: int, customer_fee_sats: int = 0, commission_bps: int = DEFAULT_PURCHASE_COMMISSION_BPS
) -> PurchaseAccounting:
    for val in (price_sats, customer_fee_sats, commission_bps):
        if not isinstance(val, int) or isinstance(val, bool):
            raise TypeError("Monetary amounts must be strict integers (never float)")
    if price_sats <= 0:
        raise ValueError("price_sats must be positive")
    if customer_fee_sats < 0:
        raise ValueError("customer_fee_sats cannot be negative")
    if commission_bps < 0 or commission_bps > 5000:
        raise ValueError("commission_bps must be between 0 and 5000")

    total_sats = price_sats + customer_fee_sats
    commission_sats = (price_sats * commission_bps) // 10000
    author_payable_sats = price_sats - commission_sats
    return PurchaseAccounting(
        price_sats=price_sats,
        customer_fee_sats=customer_fee_sats,
        total_sats=total_sats,
        commission_sats=commission_sats,
        author_payable_sats=author_payable_sats,
    )


def process_verified_event(conn: sqlite3.Connection, event: VerifiedEvent) -> dict:
    """Process a verified provider event idempotently inside a database transaction."""
    now = datetime.now(timezone.utc).isoformat()
    with conn:
        dup = conn.execute(
            "SELECT id FROM payment_events WHERE provider = ? AND provider_event_id = ?",
            (event.provider, event.provider_event_id),
        ).fetchone()
        if dup:
            return {"duplicate": True, "outcome": "duplicate_event_ignored"}

        intent = conn.execute(
            "SELECT * FROM payment_intents WHERE id = ?", (event.payment_intent_id,)
        ).fetchone()
        if not intent:
            raise ValueError("Payment intent not found")

        invoice = conn.execute(
            "SELECT * FROM lightning_invoices WHERE payment_intent_id = ?",
            (event.payment_intent_id,),
        ).fetchone()
        if not invoice:
            raise ValueError("Invoice not found")

        if invoice["provider_invoice_id"] != event.provider_invoice_id:
            raise ValueError("Invoice identity mismatch")
        if invoice["payment_hash"] != event.payment_hash:
            raise ValueError("Payment hash mismatch")
        if intent["provider_account"] != event.provider_account:
            raise ValueError("Provider account mismatch")
        if int(intent["total_sats"]) != event.amount_sats:
            raise ValueError("Amount mismatch")

        conn.execute(
            """INSERT INTO payment_events (
                 id, provider, provider_event_id, payment_intent_id,
                 provider_invoice_id, event_status, amount_sats, raw_payload_redacted, received_at
               ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                f"pe_{uuid.uuid4()}",
                event.provider,
                event.provider_event_id,
                event.payment_intent_id,
                event.provider_invoice_id,
                event.status,
                event.amount_sats,
                json.dumps({"event_id": event.provider_event_id, "status": event.status}),
                now,
            ),
        )

        if event.status in ("expired", "cancelled"):
            if intent["status"] != "settled":
                conn.execute(
                    "UPDATE payment_intents SET status = ? WHERE id = ?",
                    (event.status, event.payment_intent_id),
                )
                conn.execute(
                    "UPDATE lightning_invoices SET status = ? WHERE id = ?",
                    (event.status, invoice["id"]),
                )
            return {"duplicate": False, "outcome": f"marked_{event.status}"}

        was_expired = intent["status"] == "expired" or intent["expires_at"] <= now
        new_status = "reconciliation_required" if was_expired else "settled"
        conn.execute(
            "UPDATE payment_intents SET status = ?, settled_at = COALESCE(settled_at, ?) WHERE id = ?",
            (new_status, event.occurred_at, event.payment_intent_id),
        )
        conn.execute(
            "UPDATE lightning_invoices SET status = ?, settled_at = COALESCE(settled_at, ?) WHERE id = ?",
            (new_status, event.occurred_at, invoice["id"]),
        )

        existing_cust = conn.execute(
            "SELECT id FROM ledger_entries WHERE payment_intent_id = ? AND entry_type = 'customer_payment'",
            (event.payment_intent_id,),
        ).fetchone()
        if not existing_cust:
            conn.execute(
                """INSERT INTO ledger_entries (
                     id, entry_type, user_id, article_id, payment_intent_id, related_id,
                     amount_sats, direction, description, is_demo, created_at
                   ) VALUES (?, 'customer_payment', ?, ?, ?, ?, ?, 'credit', ?, 1, ?)""",
                (
                    f"led_{uuid.uuid4()}",
                    intent["user_id"],
                    intent["article_id"],
                    event.payment_intent_id,
                    invoice["id"],
                    int(intent["total_sats"]),
                    f"Customer payment settled ({intent['kind']})",
                    now,
                ),
            )

        if was_expired:
            return {"duplicate": False, "outcome": "late_settlement_reconciliation_required"}

        if bool(intent["simulate_fulfillment_failure"]):
            conn.execute(
                "UPDATE payment_intents SET fulfillment_status = 'failed_retryable' WHERE id = ?",
                (event.payment_intent_id,),
            )
            return {"duplicate": False, "outcome": "settled_fulfillment_pending_retry"}

        _fulfill_intent(conn, event.payment_intent_id, now)
        return {"duplicate": False, "outcome": "settled_and_fulfilled"}


def _fulfill_intent(conn: sqlite3.Connection, payment_intent_id: str, now: str) -> None:
    intent = conn.execute(
        "SELECT * FROM payment_intents WHERE id = ?", (payment_intent_id,)
    ).fetchone()
    if intent["kind"] == "article_purchase":
        existing_pur = conn.execute(
            "SELECT id FROM purchases WHERE payment_intent_id = ?", (payment_intent_id,)
        ).fetchone()
        purchase_id = existing_pur["id"] if existing_pur else f"pur_{uuid.uuid4()}"
        if not existing_pur:
            conn.execute(
                """INSERT INTO purchases (
                     id, user_id, article_id, offer_id, revision_id, payment_intent_id,
                     price_sats, customer_fee_sats, total_sats, commission_sats, author_payable_sats,
                     fee_policy_version, includes_future_revisions, status, created_at
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)""",
                (
                    purchase_id,
                    intent["user_id"],
                    intent["article_id"],
                    intent["offer_id"],
                    intent["revision_id"],
                    payment_intent_id,
                    int(intent["amount_sats"]),
                    int(intent["customer_fee_sats"]),
                    int(intent["total_sats"]),
                    int(intent["commission_sats"]),
                    int(intent["author_payable_sats"]),
                    intent["fee_policy_version"],
                    int(intent["includes_future_revisions"]),
                    now,
                ),
            )
        conn.execute(
            """INSERT INTO entitlements (
                 id, user_id, article_id, purchase_id, locked_revision_id, includes_future_revisions, granted_at
               ) VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(user_id, article_id) DO UPDATE SET
                 purchase_id = excluded.purchase_id,
                 revoked_at = NULL""",
            (
                f"ent_{uuid.uuid4()}",
                intent["user_id"],
                intent["article_id"],
                purchase_id,
                intent["revision_id"],
                int(intent["includes_future_revisions"]),
                now,
            ),
        )
    elif intent["kind"] == "author_tip":
        existing_tip = conn.execute(
            "SELECT id FROM tips WHERE payment_intent_id = ?", (payment_intent_id,)
        ).fetchone()
        if not existing_tip:
            conn.execute(
                """INSERT INTO tips (
                     id, user_id, recipient_user_id, article_id, payment_intent_id,
                     amount_sats, commission_sats, author_payable_sats, note, status, created_at
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, '', 'settled', ?)""",
                (
                    f"tip_{uuid.uuid4()}",
                    intent["user_id"],
                    intent["recipient_user_id"],
                    intent["article_id"],
                    payment_intent_id,
                    int(intent["amount_sats"]),
                    int(intent["commission_sats"]),
                    int(intent["author_payable_sats"]),
                    now,
                ),
            )

    existing_pay = conn.execute(
        "SELECT id FROM ledger_entries WHERE payment_intent_id = ? AND entry_type = 'author_payable'",
        (payment_intent_id,),
    ).fetchone()
    if not existing_pay:
        conn.execute(
            """INSERT INTO ledger_entries (
                 id, entry_type, user_id, article_id, payment_intent_id, related_id,
                 amount_sats, direction, description, is_demo, created_at
               ) VALUES (?, 'author_payable', ?, ?, ?, ?, ?, 'credit', ?, 1, ?)""",
            (
                f"led_{uuid.uuid4()}",
                intent["recipient_user_id"],
                intent["article_id"],
                payment_intent_id,
                payment_intent_id,
                int(intent["author_payable_sats"]),
                "Author payable",
                now,
            ),
        )
        if int(intent["commission_sats"]) > 0:
            conn.execute(
                """INSERT INTO ledger_entries (
                     id, entry_type, user_id, article_id, payment_intent_id, related_id,
                     amount_sats, direction, description, is_demo, created_at
                   ) VALUES (?, 'platform_revenue', NULL, ?, ?, ?, ?, 'credit', ?, 1, ?)""",
                (
                    f"led_{uuid.uuid4()}",
                    intent["article_id"],
                    payment_intent_id,
                    payment_intent_id,
                    int(intent["commission_sats"]),
                    f"Platform commission ({intent['fee_policy_version']})",
                    now,
                ),
            )

    conn.execute(
        """UPDATE payment_intents
           SET status = 'settled', fulfillment_status = 'fulfilled', simulate_fulfillment_failure = 0
           WHERE id = ?""",
        (payment_intent_id,),
    )
    conn.execute(
        "UPDATE lightning_invoices SET status = 'settled' WHERE payment_intent_id = ?",
        (payment_intent_id,),
    )


def reconcile_pending_fulfillments(conn: sqlite3.Connection) -> int:
    now = datetime.now(timezone.utc).isoformat()
    rows = conn.execute(
        """SELECT id FROM payment_intents
           WHERE (status = 'settled' AND fulfillment_status IN ('pending', 'failed_retryable'))
              OR status = 'reconciliation_required'"""
    ).fetchall()
    recovered = 0
    with conn:
        for row in rows:
            _fulfill_intent(conn, row["id"], now)
            recovered += 1
    return recovered


def process_refund_approval(
    conn: sqlite3.Connection, refund_id: str, reviewer_id: str, approve: bool
) -> dict:
    now = datetime.now(timezone.utc).isoformat()
    with conn:
        rr = conn.execute(
            "SELECT * FROM refund_requests WHERE id = ?", (refund_id,)
        ).fetchone()
        if not rr:
            raise ValueError("Refund request not found")
        if rr["status"] != "pending_review":
            raise ValueError("Refund request already resolved")
        if not approve:
            conn.execute(
                "UPDATE refund_requests SET status = 'rejected', reviewer_user_id = ?, resolved_at = ? WHERE id = ?",
                (reviewer_id, now, refund_id),
            )
            return {"status": "rejected"}

        purchase = conn.execute(
            "SELECT * FROM purchases WHERE id = ?", (rr["purchase_id"],)
        ).fetchone()
        capped = min(int(rr["requested_amount_sats"]), int(purchase["total_sats"]))
        out_ref = f"sim_refund_{uuid.uuid4().hex[:12]}"
        conn.execute(
            "UPDATE purchases SET status = 'refunded' WHERE id = ?", (purchase["id"],)
        )
        conn.execute(
            "UPDATE entitlements SET revoked_at = ? WHERE purchase_id = ?",
            (now, purchase["id"]),
        )
        conn.execute(
            """INSERT INTO ledger_entries (
                 id, entry_type, user_id, article_id, payment_intent_id, related_id,
                 amount_sats, direction, description, is_demo, created_at
               ) VALUES (?, 'refund', ?, ?, ?, ?, ?, 'debit', ?, 1, ?)""",
            (
                f"led_{uuid.uuid4()}",
                purchase["user_id"],
                purchase["article_id"],
                purchase["payment_intent_id"],
                refund_id,
                capped,
                f"Reviewed refund ({out_ref})",
                now,
            ),
        )
        conn.execute(
            """UPDATE refund_requests
               SET status = 'approved_settled', reviewer_user_id = ?, outgoing_reference = ?, resolved_at = ?
               WHERE id = ?""",
            (reviewer_id, out_ref, now, refund_id),
        )
        return {"status": "approved_settled", "amount_sats": capped, "outgoing_reference": out_ref}


def reconcile_pending_payout(conn: sqlite3.Connection, payout_id: str) -> dict:
    now = datetime.now(timezone.utc).isoformat()
    with conn:
        po = conn.execute("SELECT * FROM payouts WHERE id = ?", (payout_id,)).fetchone()
        if not po:
            raise ValueError("Payout not found")
        if not validate_lightning_destination(po["destination"]):
            raise ValueError("Invalid payout destination")
        if po["status"] != "pending_reconciliation":
            return {"status": po["status"]}
        conn.execute(
            """UPDATE payouts
               SET status = 'completed', network_fee_sats = 1, message = 'Reconciled payout settled', completed_at = ?
               WHERE id = ?""",
            (now, payout_id),
        )
        conn.execute(
            """INSERT INTO ledger_entries (
                 id, entry_type, user_id, article_id, payment_intent_id, related_id,
                 amount_sats, direction, description, is_demo, created_at
               ) VALUES (?, 'payout', ?, NULL, NULL, ?, ?, 'debit', ?, 1, ?)""",
            (
                f"led_{uuid.uuid4()}",
                po["author_user_id"],
                payout_id,
                int(po["amount_sats"]),
                f"Reconciled payout to {po['destination']}",
                now,
            ),
        )
        return {"status": "completed"}
