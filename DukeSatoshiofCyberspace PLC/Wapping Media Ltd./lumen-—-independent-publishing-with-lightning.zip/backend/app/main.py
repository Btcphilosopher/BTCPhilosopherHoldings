"""FastAPI Modular Monolith for Lumen Independent Publishing with Lightning."""
from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from typing import Iterator

from fastapi import Depends, FastAPI, Header, HTTPException, Request, Response
from pydantic import BaseModel, Field

from .accounting import compute_purchase_accounting, process_refund_approval, process_verified_event
from .lightning import DeterministicSimulatorProvider
from .sanitize import strip_dangerous_html

app = FastAPI(
    title="Lumen Publishing & Lightning API",
    version="1.0.0",
    description="Modular monolith backend for independent publishing, integer-sat accounting, and Lightning settlement.",
)


@contextmanager
def get_conn() -> Iterator[sqlite3.Connection]:
    db_path = os.getenv("LUMEN_SQLITE_PATH", "./data/lumen.db")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    try:
        yield conn
    finally:
        conn.close()


def require_user_id(x_lumen_user_id: str | None = Header(default=None)) -> str:
    if not x_lumen_user_id:
        raise HTTPException(status_code=401, detail="Authentication required")
    return x_lumen_user_id


class DraftCreateRequest(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    subtitle: str = Field(default="", max_length=400)
    topic: str = Field(pattern="^(technology|culture|science|economics|design)$")
    body_markdown: str = Field(default="")
    is_paid: bool = False
    price_sats: int = Field(default=0, ge=0)
    includes_future_revisions: bool = True


class PurchaseRequest(BaseModel):
    article_id: str


class TipRequest(BaseModel):
    recipient_user_id: str
    article_id: str | None = None
    amount_sats: int = Field(ge=1, le=1_000_000)


class RefundRequestBody(BaseModel):
    purchase_id: str
    reason: str = Field(min_length=3, max_length=500)


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "provider": os.getenv("LIGHTNING_PROVIDER", "simulator"),
        "live_enabled": os.getenv("LIGHTNING_LIVE_ENABLED", "false") == "true",
    }


@app.get("/v1/articles")
def list_articles(topic: str | None = None, q: str | None = None) -> dict:
    with get_conn() as conn:
        clauses = ["a.status IN ('published', 'revised')"]
        params: list[str] = []
        if topic and topic != "for-you":
            clauses.append("a.topic = ?")
            params.append(topic)
        if q:
            like = f"%{q.strip().lower()}%"
            clauses.append("(LOWER(r.title) LIKE ? OR LOWER(u.display_name) LIKE ? OR LOWER(a.topic) LIKE ?)")
            params.extend([like, like, like])
        rows = conn.execute(
            f"""SELECT a.id, a.slug, a.topic, a.status, r.title, r.subtitle,
                       u.display_name AS author_name, o.is_paid, o.price_sats
                FROM articles a
                JOIN article_revisions r ON r.id = a.current_revision_id
                JOIN article_offers o ON o.id = a.current_offer_id
                JOIN users u ON u.id = a.author_user_id
                WHERE {' AND '.join(clauses)}
                ORDER BY COALESCE(a.featured_rank, 9999) ASC, a.published_at DESC""",
            params,
        ).fetchall()
        return {"articles": [dict(r) for r in rows]}


@app.get("/v1/articles/{article_id}")
def get_article_metadata(article_id: str) -> dict:
    with get_conn() as conn:
        row = conn.execute(
            """SELECT a.id, a.slug, a.topic, a.status, r.title, r.subtitle,
                      o.is_paid, o.price_sats, o.customer_fee_sats, o.includes_future_revisions
               FROM articles a
               JOIN article_revisions r ON r.id = a.current_revision_id
               JOIN article_offers o ON o.id = a.current_offer_id
               WHERE (a.id = ? OR a.slug = ?) AND a.status IN ('published', 'revised')""",
            (article_id, article_id),
        ).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Article not found")
        return {"article": dict(row)}


@app.get("/v1/articles/{article_id}/content")
def get_article_content(
    article_id: str,
    response: Response,
    x_lumen_user_id: str | None = Header(default=None),
) -> dict:
    response.headers["Cache-Control"] = "private, no-store"
    with get_conn() as conn:
        row = conn.execute(
            """SELECT a.id, a.author_user_id, a.status, r.body_markdown, o.is_paid, o.price_sats
               FROM articles a
               JOIN article_revisions r ON r.id = a.current_revision_id
               JOIN article_offers o ON o.id = a.current_offer_id
               WHERE a.id = ? OR a.slug = ?""",
            (article_id, article_id),
        ).fetchone()
        if not row or row["status"] not in ("published", "revised"):
            raise HTTPException(status_code=404, detail="Article not found")
        if bool(row["is_paid"]):
            if not x_lumen_user_id:
                raise HTTPException(status_code=402, detail="Payment required")
            if row["author_user_id"] != x_lumen_user_id:
                ent = conn.execute(
                    "SELECT id FROM entitlements WHERE user_id = ? AND article_id = ? AND revoked_at IS NULL",
                    (x_lumen_user_id, row["id"]),
                ).fetchone()
                if not ent:
                    raise HTTPException(status_code=402, detail="Payment required")
        return {"article_id": row["id"], "body_markdown": strip_dangerous_html(row["body_markdown"])}


@app.post("/v1/payments/providers/{provider}/events")
async def receive_provider_event(
    provider: str,
    request: Request,
    x_lumen_signature: str | None = Header(default=None),
) -> dict:
    if provider != "simulator":
        raise HTTPException(status_code=400, detail="Unsupported provider in local mode")
    secret = os.getenv("LIGHTNING_WEBHOOK_SECRET", "lumen-dev-webhook-secret-change-me")
    adapter = DeterministicSimulatorProvider(secret)
    raw_body = (await request.body()).decode("utf-8")
    try:
        verified = adapter.verify_provider_event(raw_body, x_lumen_signature)
    except ValueError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc

    with get_conn() as conn:
        return process_verified_event(conn, verified)


@app.get("/v1/me/author-statement")
def get_my_author_statement(user_id: str = Depends(require_user_id)) -> dict:
    with get_conn() as conn:
        purchases = conn.execute(
            """SELECT COUNT(*) AS cnt,
                      COALESCE(SUM(total_sats), 0) AS gross_sats,
                      COALESCE(SUM(commission_sats), 0) AS commission_sats,
                      COALESCE(SUM(author_payable_sats), 0) AS net_sats
               FROM purchases p
               JOIN articles a ON a.id = p.article_id
               WHERE a.author_user_id = ? AND p.status = 'active'""",
            (user_id,),
        ).fetchone()
        tips = conn.execute(
            "SELECT COALESCE(SUM(author_payable_sats), 0) AS net_sats FROM tips WHERE recipient_user_id = ? AND status = 'settled'",
            (user_id,),
        ).fetchone()
        return {
            "accounting_model": "platform_collection",
            "article_purchases_gross_sats": int(purchases["gross_sats"]),
            "platform_commission_sats": int(purchases["commission_sats"]),
            "settled_tips_sats": int(tips["net_sats"]),
            "amount_payable_sats": int(purchases["net_sats"]) + int(tips["net_sats"]),
        }
