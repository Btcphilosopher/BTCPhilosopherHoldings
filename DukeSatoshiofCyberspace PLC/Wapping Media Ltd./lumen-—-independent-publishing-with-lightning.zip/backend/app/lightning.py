"""Typed Lightning payment provider and payout adapters for Lumen (Python backend)."""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Literal, Protocol


@dataclass(frozen=True)
class InvoiceResult:
    provider: str
    provider_account: str
    provider_invoice_id: str
    payment_hash: str
    bolt11: str
    amount_sats: int
    amount_msat: int
    expires_at: str


@dataclass(frozen=True)
class VerifiedEvent:
    provider: str
    provider_account: str
    provider_event_id: str
    provider_invoice_id: str
    payment_hash: str
    payment_intent_id: str
    amount_sats: int
    status: Literal["settled", "expired", "cancelled"]
    occurred_at: str


class PaymentProviderAdapter(Protocol):
    provider_name: str
    is_live: bool

    def create_invoice(
        self, payment_intent_id: str, amount_sats: int, memo: str, expiry_seconds: int
    ) -> InvoiceResult: ...

    def get_invoice_status(self, provider_invoice_id: str) -> dict: ...

    def verify_provider_event(
        self, raw_body: str, signature_header: str | None
    ) -> VerifiedEvent: ...


class DirectToAuthorFutureAdapter(Protocol):
    """Separate interface for future non-custodial direct-to-author invoices."""

    def resolve_author_lnurl_pay(self, lightning_address: str) -> dict: ...
    def request_direct_invoice(self, callback_url: str, amount_msat: int) -> dict: ...


class DeterministicSimulatorProvider:
    provider_name = "simulator"
    is_live = False
    account_id = "lumen-platform-sim-acct-01"

    def __init__(self, webhook_secret: str):
        if len(webhook_secret) < 16:
            raise ValueError("Webhook secret must be at least 16 characters")
        self._secret = webhook_secret

    def create_invoice(
        self, payment_intent_id: str, amount_sats: int, memo: str, expiry_seconds: int = 900
    ) -> InvoiceResult:
        if not isinstance(amount_sats, int) or isinstance(amount_sats, bool) or amount_sats <= 0:
            raise ValueError("Invoice amount_sats must be a positive integer")
        amount_msat = amount_sats * 1000
        seed = f"{payment_intent_id}:{amount_msat}:{memo}".encode("utf-8")
        payment_hash = hashlib.sha256(seed).hexdigest()
        provider_invoice_id = f"sim_inv_{payment_hash[:20]}"
        checksum = hashlib.sha256(f"{payment_hash}:{expiry_seconds}".encode("utf-8")).hexdigest()[:48]
        bolt11 = f"lnsb{amount_sats}n1p{payment_hash[:32]}pp5{checksum}"
        expires_at = (datetime.now(timezone.utc) + timedelta(seconds=expiry_seconds)).isoformat()
        return InvoiceResult(
            provider=self.provider_name,
            provider_account=self.account_id,
            provider_invoice_id=provider_invoice_id,
            payment_hash=payment_hash,
            bolt11=bolt11,
            amount_sats=amount_sats,
            amount_msat=amount_msat,
            expires_at=expires_at,
        )

    def sign_event(self, raw_body: str) -> str:
        return hmac.new(
            self._secret.encode("utf-8"), raw_body.encode("utf-8"), hashlib.sha256
        ).hexdigest()

    def verify_provider_event(
        self, raw_body: str, signature_header: str | None
    ) -> VerifiedEvent:
        if not signature_header:
            raise ValueError("Missing X-Lumen-Signature header")
        expected = self.sign_event(raw_body)
        if not hmac.compare_digest(signature_header.strip(), expected):
            raise ValueError("Invalid provider webhook signature")

        payload = json.loads(raw_body)
        amount_sats = payload.get("amount_sats")
        if not isinstance(amount_sats, int) or isinstance(amount_sats, bool) or amount_sats <= 0:
            raise ValueError("Expected integer positive amount_sats")
        if payload.get("provider_account") != self.account_id:
            raise ValueError("Provider account mismatch")
        status = payload.get("status")
        if status not in ("settled", "expired", "cancelled"):
            raise ValueError("Unsupported event status")

        return VerifiedEvent(
            provider=self.provider_name,
            provider_account=payload["provider_account"],
            provider_event_id=payload["provider_event_id"],
            provider_invoice_id=payload["provider_invoice_id"],
            payment_hash=payload["payment_hash"],
            payment_intent_id=payload["payment_intent_id"],
            amount_sats=amount_sats,
            status=status,
            occurred_at=payload.get("occurred_at") or datetime.now(timezone.utc).isoformat(),
        )


def validate_lightning_destination(destination: str) -> bool:
    trimmed = destination.strip()
    if not trimmed or len(trimmed) > 200:
        return False
    ln_addr = re.compile(r"^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")
    lnurl = re.compile(r"^lnurl1[023456789ac-hj-np-z]{20,}$", re.IGNORECASE)
    return bool(ln_addr.match(trimmed) or lnurl.match(trimmed))
