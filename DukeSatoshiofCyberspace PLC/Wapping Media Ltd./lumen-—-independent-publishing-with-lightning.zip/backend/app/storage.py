"""S3-compatible object storage adapter for Lumen editorial media assets."""
from __future__ import annotations

import hashlib
import os
import uuid
from dataclasses import dataclass

ALLOWED_MIMES = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/webp": ".webp",
}
MAX_BYTES = 2 * 1024 * 1024


@dataclass(frozen=True)
class StoredObject:
    object_key: str
    mime_type: str
    size_bytes: int
    sha256: str


def validate_image_bytes(data: bytes, mime_type: str) -> str:
    ext = ALLOWED_MIMES.get(mime_type)
    if not ext:
        raise ValueError("Unsupported image MIME type")
    if not (0 < len(data) <= MAX_BYTES):
        raise ValueError("Image size must be <= 2 MB")
    if mime_type == "image/png" and not data.startswith(b"\x89PNG"):
        raise ValueError("Invalid PNG signature")
    if mime_type == "image/jpeg" and not data.startswith(b"\xff\xd8\xff"):
        raise ValueError("Invalid JPEG signature")
    if mime_type == "image/webp" and not (data[:4] == b"RIFF" and data[8:12] == b"WEBP"):
        raise ValueError("Invalid WebP signature")
    return ext


class S3MediaStorage:
    def __init__(self) -> None:
        self.endpoint_url = os.getenv("S3_ENDPOINT_URL", "http://localhost:9000")
        self.bucket = os.getenv("S3_BUCKET", "lumen-media")
        self.region = os.getenv("S3_REGION", "us-east-1")

    def upload(self, data: bytes, mime_type: str) -> StoredObject:
        import boto3  # type: ignore

        ext = validate_image_bytes(data, mime_type)
        key = f"{uuid.uuid4()}{ext}"
        digest = hashlib.sha256(data).hexdigest()
        client = boto3.client(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=os.getenv("S3_ACCESS_KEY"),
            aws_secret_access_key=os.getenv("S3_SECRET_KEY"),
            region_name=self.region,
        )
        client.put_object(
            Bucket=self.bucket,
            Key=key,
            Body=data,
            ContentType=mime_type,
        )
        return StoredObject(
            object_key=key,
            mime_type=mime_type,
            size_bytes=len(data),
            sha256=digest,
        )
