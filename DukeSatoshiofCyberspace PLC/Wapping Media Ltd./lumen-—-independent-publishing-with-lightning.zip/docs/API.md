# Lumen — API Documentation (`/v1/*`)

All endpoints return JSON with `Cache-Control: private, no-store` on authenticated or paywalled payloads. Monetary fields are strict integers in satoshis (`sats`) or millisatoshis (`msat`).

## Articles & Publishing
- `GET /v1/articles?topic=&q=&following=&author=&mine=` — List published articles (safe excerpts only; never leaks paid body or private drafts).
- `GET /v1/articles/{article_id}` — Fetch article metadata + preview paragraphs (paid `body_blocks` omitted unless unlocked/owner).
- `GET /v1/articles/{article_id}/content` — Server-enforced full article content (`402 Payment Required` when unpaid/unauthenticated).
- `POST /v1/articles` — Create draft article (authenticated).
- `PATCH /v1/articles/{article_id}` — Autosave draft (author owner only).
- `POST /v1/articles/{article_id}/revisions` — Save new immutable `ArticleRevision` snapshot (author owner only).
- `POST /v1/articles/{article_id}/publish` — Transition lifecycle (`draft` → `preview` → `published` → `revised` | `withdrawn`).

## Purchases, Tips & Lightning Invoices
- `POST /v1/purchases` — Create an `article_purchase` `PaymentIntent` + `LightningInvoice` (rate-limited, bounded active attempts).
- `GET /v1/purchases/{purchase_id}` — Fetch purchase receipt (buyer or admin only).
- `POST /v1/tips` — Create a separate `author_tip` `PaymentIntent` + `LightningInvoice` (never unlocks paid articles).
- `GET /v1/payment-intents/{payment_intent_id}` — Poll current intent/invoice status and expiry.
- `POST /v1/payments/providers/{provider}/events` — Authenticated webhook receiver verifying HMAC-SHA256 `X-Lumen-Signature` and processing idempotently.

## Reader, Author & Operations
- `GET /v1/me/library` & `POST /v1/me/library` — Purchased articles, bookmarks, and author follows.
- `GET /v1/me/payments` — Reader payment intents, purchases, tips, and refund statuses.
- `GET /v1/me/author-statement` — Author earnings statement (gross sales, commission, settled tips, refunds, payouts, payable balance).
- `POST /v1/refund-requests` — Submit reviewed refund request (capped at purchase total, duplicate-guarded).
- `POST /v1/payout-requests` — Request idempotent outgoing author payout (50–50,000 sats, destination validated).
- `GET /v1/admin` & `POST /v1/admin` — Role-restricted moderation, refund review, fulfillment recovery, and payout reconciliation.
