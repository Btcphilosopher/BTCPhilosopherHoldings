/**
 * End-to-End Integration Verification for Lumen (Node 22 native fetch)
 * Exercises all 14 demonstration steps against the live Next.js server on port 3000.
 * Run: node e2e/lumen_e2e.mjs
 */
import assert from 'node:assert/strict';

const BASE = process.env.E2E_BASE_URL || 'http://127.0.0.1:3000';

class CookieClient {
  constructor() {
    this.cookie = '';
  }

  async req(path, options = {}) {
    const headers = {
      'X-Requested-With': 'lumen-ui',
      ...(options.headers || {}),
    };
    if (this.cookie) {
      headers['Cookie'] = this.cookie;
    }
    const res = await fetch(`${BASE}${path}`, {
      ...options,
      headers,
    });
    const setCookie = res.headers.get('set-cookie');
    if (setCookie) {
      const pair = setCookie.split(';')[0];
      if (pair.startsWith('lumen_session=')) {
        this.cookie = pair.endsWith('=') ? '' : pair;
      }
    }
    const text = await res.text();
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      // HTML or plain text
    }
    return { status: res.status, headers: res.headers, text, json };
  }
}

async function run() {
  const client = new CookieClient();

  // 1. Open reference-based homepage
  const home = await client.req('/');
  assert.equal(home.status, 200);
  assert.ok(home.text.includes('Good writing. Worth a few sats.'));
  assert.ok(home.text.includes('The quiet return of the personal library'));

  // 2. Read a free article (Daniel Moss - Who owns the future of computing?)
  const freePage = await client.req('/articles/who-owns-the-future-of-computing');
  assert.equal(freePage.status, 200);
  assert.ok(freePage.text.includes('Three layers of computational autonomy'));

  // 3 & 4. Open a paid preview & verify full body is NOT leaked before purchase
  const paidMeta = await client.req('/v1/articles/the-quiet-return-of-the-personal-library');
  assert.equal(paidMeta.status, 200);
  assert.equal(paidMeta.json.article.offer.price_sats, 250);
  assert.equal(paidMeta.json.article.viewer_has_access, false);
  assert.equal(paidMeta.json.article.body_blocks, null);

  const lockedContent = await client.req('/v1/articles/art_personal_library/content');
  assert.equal(lockedContent.status, 402);
  assert.equal(lockedContent.headers.get('cache-control'), 'private, no-store, no-cache, must-revalidate');

  // Sign in as reader demo account
  const login = await client.req('/v1/auth', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'demo_switch', email: 'reader@lumen.press' }),
  });
  assert.equal(login.status, 200);

  // 5. Create simulated 250-sat invoice
  const purRes = await client.req('/v1/purchases', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ article_id: 'art_personal_library' }),
  });
  assert.equal(purRes.status, 201);
  const pi = purRes.json.payment_intent;
  assert.equal(pi.total_sats, 250);
  assert.equal(pi.status, 'awaiting_payment');

  // 6 & 13. Simulate settlement + replay duplicate settlement event
  const settle1 = await client.req('/v1/payments/simulator/trigger', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ payment_intent_id: pi.id, event_status: 'settled' }),
  });
  assert.equal(settle1.status, 200);
  assert.equal(settle1.json.duplicate, false);
  assert.equal(settle1.json.payment_intent.status, 'settled');

  const settleDup = await client.req('/v1/payments/simulator/trigger', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      payment_intent_id: pi.id,
      event_status: 'settled',
      provider_event_id: settle1.json.provider_event_id,
    }),
  });
  assert.equal(settleDup.status, 200);
  assert.equal(settleDup.json.duplicate, true);

  // 7. Unlock the article from server
  const unlockedContent = await client.req('/v1/articles/art_personal_library/content');
  assert.equal(unlockedContent.status, 200);
  assert.ok(Array.isArray(unlockedContent.json.body_blocks));

  // 8 & 9. Log out, verify locked again, log back in, verify in purchased library
  await client.req('/v1/auth', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'logout' }),
  });
  const afterLogout = await client.req('/v1/articles/art_personal_library/content');
  assert.equal(afterLogout.status, 402);

  await client.req('/v1/auth', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'demo_switch', email: 'reader@lumen.press' }),
  });
  const lib = await client.req('/v1/me/library');
  assert.equal(lib.status, 200);
  assert.ok(lib.json.purchased.some((a) => a.id === 'art_personal_library'));

  // 10. Send a separate simulated tip (100 sats to Eleanor Hart)
  const tipRes = await client.req('/v1/tips', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      recipient_user_id: 'usr_eleanor',
      article_id: 'art_personal_library',
      amount_sats: 100,
    }),
  });
  assert.equal(tipRes.status, 201);
  const tipSettle = await client.req('/v1/payments/simulator/trigger', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      payment_intent_id: tipRes.json.payment_intent.id,
      event_status: 'settled',
    }),
  });
  assert.equal(tipSettle.status, 200);

  // 11. View Eleanor Hart's author statement
  await client.req('/v1/auth', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'demo_switch', email: 'eleanor@lumen.press' }),
  });
  const stmtRes = await client.req('/v1/me/author-statement');
  assert.equal(stmtRes.status, 200);
  assert.ok(stmtRes.json.statement.article_purchases_gross_sats >= 250);
  assert.ok(stmtRes.json.statement.settled_tips_sats >= 100);

  // 12. Handle expired invoice on Amelia Reed's 100-sat article
  await client.req('/v1/auth', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'demo_switch', email: 'reader@lumen.press' }),
  });
  const expIntent = await client.req('/v1/purchases', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ article_id: 'art_slower_progress', expiry_seconds: 5 }),
  });
  assert.equal(expIntent.status, 201);
  const expTrigger = await client.req('/v1/payments/simulator/trigger', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      payment_intent_id: expIntent.json.payment_intent.id,
      event_status: 'expired',
    }),
  });
  assert.equal(expTrigger.json.payment_intent.status, 'expired');

  // 14. Recover from settlement followed by temporary fulfillment failure
  const failIntent = await client.req('/v1/purchases', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      article_id: 'art_ledger_commons',
      simulate_fulfillment_failure: true,
    }),
  });
  assert.equal(failIntent.status, 201);
  const failSettle = await client.req('/v1/payments/simulator/trigger', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      payment_intent_id: failIntent.json.payment_intent.id,
      event_status: 'settled',
    }),
  });
  assert.equal(failSettle.json.outcome, 'settled_fulfillment_pending_retry');

  // Claim admin and run reconciliation recovery
  const claim = await client.req('/v1/auth', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'claim_admin', passcode: 'lumen-admin-test-pass' }),
  });
  assert.equal(claim.status, 200);

  const rec = await client.req('/v1/admin', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'reconcile_fulfillments' }),
  });
  assert.equal(rec.status, 200);
  assert.ok(rec.json.recoveredCount >= 1);

  const recoveredContent = await client.req('/v1/articles/art_ledger_commons/content');
  assert.equal(recoveredContent.status, 200);

  console.log('ALL 14 LUMEN E2E DEMONSTRATION CHECKS PASSED');
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
