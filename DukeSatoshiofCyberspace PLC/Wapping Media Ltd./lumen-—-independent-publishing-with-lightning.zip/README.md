# Lumen — Independent Publishing with Lightning

**Good writing. Worth a few sats.**
Read freely. Unlock something remarkable. Support the writers you love.

## Architecture Overview
Lumen is structured as a modular monolith with clear boundaries between editorial publishing, server-enforced paywall access, integer-sat double-entry ledger accounting, and Lightning payment adapters:

- **Web Frontend & BFF (`/app`, `/components`, `/lib/server`)**: Next.js 15 App Router + TypeScript + Tailwind CSS v4.
- **Python Modular Monolith (`/backend/app`)**: FastAPI REST service (`main.py`), Lightning provider adapter (`lightning.py`), integer accounting engine (`accounting.py`), HTML/Markdown sanitizer (`sanitize.py`), S3-compatible media storage (`storage.py`), and background reconciliation worker (`worker.py`).
- **Database Migrations (`/backend/migrations/001_initial_postgres.sql`)**: PostgreSQL DDL with `BIGINT`/`INTEGER` monetary columns, uniqueness constraints on `(provider, provider_event_id)`, `(user_id, article_id)`, and `idempotency_key`. In single-container preview mode, Next.js runs directly against `node:sqlite` (`./data/lumen.db`) using the identical relational schema.

## Capability Status Matrix
- **Implemented (Live & Verified)**:
  - Reference-faithful editorial Discovery homepage, Topic pages, Search, Author profiles, Following feed, My library, Payment history, Author earnings, Writing dashboard, Story editor (headings, paragraphs, lists, quotes, links, image upload with alt text, autosave, revisions, lifecycle transitions, sanitization), Account & Demo switcher, Moderation Admin console.
  - Server-enforced paywall (`GET /v1/articles/{id}/content` returns `402` unless entitled; full paid bodies excluded from HTML, search, and unauthorized JSON).
  - Integer-only sats/msat accounting, snapshotted fee policies (`fee-policy-2026-v1`), BOLT11 QR codes, expiry countdowns, HMAC-verified webhook processing, idempotent duplicate event deduplication, temporary fulfillment failure recovery, reviewed refunds, and payout reconciliation.
- **Simulated (Default Local Mode)**:
  - `DeterministicSimulatorProvider` and `DeterministicSimulatorPayoutAdapter` generate deterministic BOLT11-shaped test invoices, signed HMAC-SHA256 webhooks, and simulated demo balances (`LIGHTNING_LIVE_ENABLED=false`).
- **Externally Integrated (Disabled by Default)**:
  - `LnbitsTestnetProvider` (LNbits REST API v1) and `S3MediaStorage` (boto3 / MinIO) are implemented and gated behind environment configuration (`LIGHTNING_LIVE_ENABLED=true`, `LNBITS_*`, `S3_*`).
- **Deferred (Interface Boundary Only)**:
  - `DirectToAuthorFutureAdapter` (non-custodial LNURL-pay direct splits) is cleanly separated as an interface for future release without mixing platform-collection accounting.

## Local Development
### Single-Process Preview (Next.js + SQLite)
```bash
npm install
npm run dev
```
Open `http://localhost:3000`.

### Full Docker Compose Stack (PostgreSQL + MinIO + FastAPI + Worker + Next.js)
```bash
cp .env.example .env
docker compose up --build
```

## Running Tests
```bash
# Python backend tests (works with pytest or standard unittest)
python3 -m unittest discover -s backend/tests -v

# Live End-to-End 14-step verification (with Next.js server running on port 3000)
node e2e/lumen_e2e.mjs
```

## Pre-Live Jurisdiction & Compliance Checklist
Before enabling `LIGHTNING_LIVE_ENABLED=true` in production:
1. Identify the operating legal entity and jurisdiction for platform-collected custodial funds.
2. Confirm money-transmission / e-money / payment-intermediary licensing rules applicable to holding `author_payable` balances.
3. Publish jurisdiction-specific Terms of Service, Privacy Policy, VAT/sales-tax handling, and Lightning refund disclosures.
4. Configure external secrets (`LUMEN_SESSION_SECRET`, `LIGHTNING_WEBHOOK_SECRET`, `LNBITS_*`, `DATABASE_URL`, automated PostgreSQL backups) strictly outside source control.
