import { Injectable, signal, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';

export type AppView =
  | 'PUBLIC_PLAYER'
  | 'CONTROL_ROOM'
  | 'MIXER'
  | 'SCHEDULE'
  | 'LIBRARY'
  | 'PRESENTER'
  | 'ENGINEERING'
  | 'ANALYTICS';

export interface StationInfo {
  id: string;
  name: string;
  tagline: string;
  genre: string;
  bitrate: string;
  listeners: number;
  status: string;
  loudness: number;
  truePeak: number;
}

export interface TrackItem {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number;
  genre: string;
  year: number;
  bpm: number;
  key: string;
  integratedLUFS: number;
  shortTermLUFS: number;
  truePeak: number;
  lra: number;
  measured: boolean;
  energy: number;
  category: string;
  artwork: string;
}

export interface ListenerRequest {
  id: string;
  songTitle: string;
  artist: string;
  requesterName: string;
  message: string;
  timestamp: string;
  status: 'pending' | 'approved' | 'rejected' | 'on_air';
}

@Injectable({
  providedIn: 'root',
})
export class RadioStateService {
  private http = inject(HttpClient);

  // Active Navigation View
  readonly activeView = signal<AppView>('PUBLIC_PLAYER');

  // Active Station & Telemetry
  readonly activeStationId = signal<string>('northstar-main');
  readonly stations = signal<StationInfo[]>([]);
  readonly nowPlaying = signal<TrackItem | null>(null);
  readonly nextItem = signal<{ type: string; title: string; artist: string; duration: number } | null>(null);
  readonly streamProfile = signal<'HQ' | 'STANDARD' | 'MOBILE' | 'LOSSLESS'>('HQ');
  readonly listenerCount = signal<number>(18421);
  readonly activeChannelName = signal<string>('NORTHSTAR RADIO MAIN');

  // Playout Mode
  readonly playoutMode = signal<'AUTOMATION' | 'LIVE_DJ' | 'HYBRID' | 'EMERGENCY'>('AUTOMATION');

  // Listener Requests
  readonly requests = signal<ListenerRequest[]>([]);

  private platformId = inject(PLATFORM_ID);

  constructor() {
    this.fetchNowPlaying();
    this.fetchStations();
    this.fetchRequests();

    // Periodic telemetry update (only in browser to avoid SSR errors)
    if (isPlatformBrowser(this.platformId)) {
      setInterval(() => {
        this.fetchNowPlaying();
      }, 5000);
    }
  }

  setView(view: AppView) {
    this.activeView.set(view);
  }

  setStation(id: string) {
    this.activeStationId.set(id);
    const found = this.stations().find((s) => s.id === id);
    if (found) {
      this.activeChannelName.set(found.name);
    }
  }

  setStreamProfile(profile: 'HQ' | 'STANDARD' | 'MOBILE' | 'LOSSLESS') {
    this.streamProfile.set(profile);
  }

  setPlayoutMode(mode: 'AUTOMATION' | 'LIVE_DJ' | 'HYBRID' | 'EMERGENCY') {
    this.playoutMode.set(mode);
  }

  fetchNowPlaying() {
    this.http.get<any>('/api/v1/now-playing').subscribe({
      next: (res) => {
        if (res.nowPlaying) {
          this.nowPlaying.set(res.nowPlaying);
        }
        if (res.next) {
          this.nextItem.set(res.next);
        }
        if (res.telemetry?.listenersCount) {
          this.listenerCount.set(res.telemetry.listenersCount);
        }
      },
      error: (err) => console.warn('Now playing fetch offline:', err),
    });
  }

  fetchStations() {
    this.http.get<any>('/api/v1/stations').subscribe({
      next: (res) => {
        if (res.stations) {
          this.stations.set(res.stations);
        }
      },
      error: (err) => console.warn('Stations fetch offline:', err),
    });
  }

  fetchRequests() {
    this.http.get<any>('/api/v1/requests').subscribe({
      next: (res) => {
        if (res.requests) {
          this.requests.set(res.requests);
        }
      },
      error: (err) => console.warn('Requests fetch offline:', err),
    });
  }

  submitRequest(songTitle: string, artist: string, requesterName: string, message: string) {
    this.http
      .post<any>('/api/v1/requests', { songTitle, artist, requesterName, message })
      .subscribe({
        next: () => this.fetchRequests(),
        error: (err) => console.error('Submit request failed:', err),
      });
  }

  updateRequestStatus(id: string, status: 'approved' | 'rejected' | 'on_air') {
    this.http
      .post<any>(`/api/v1/requests/${id}/status`, { status })
      .subscribe({
        next: () => this.fetchRequests(),
        error: (err) => console.error('Update request status failed:', err),
      });
  }
}
