import { Injectable, signal, computed, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

export interface ChannelState {
  id: string;
  name: string;
  gain: number; // 0.0 to 1.5 (fader)
  pan: number; // -1 to 1
  mute: boolean;
  solo: boolean;
  hpf: boolean; // High pass filter
  eqLow: number; // -12 to +12 dB
  eqMid: number; // -12 to +12 dB
  eqHigh: number; // -12 to +12 dB
  compThreshold: number; // -40 to 0 dB
}

@Injectable({
  providedIn: 'root',
})
export class AudioEngineService {
  private audioCtx: AudioContext | null = null;
  private masterGainNode: GainNode | null = null;
  private analyserNode: AnalyserNode | null = null;
  private currentSource: AudioBufferSourceNode | null = null;
  private isPlayingSignal = signal<boolean>(false);
  private currentLoudnessLUFS = signal<number>(-23.1);
  private currentShortTermLUFS = signal<number>(-22.5);
  private currentTruePeakdB = signal<number>(-1.0);
  private isEmergencyActiveSignal = signal<boolean>(false);

  readonly isPlaying = computed(() => this.isPlayingSignal());
  readonly loudnessLUFS = computed(() => this.currentLoudnessLUFS());
  readonly shortTermLUFS = computed(() => this.currentShortTermLUFS());
  readonly truePeakdB = computed(() => this.currentTruePeakdB());
  readonly isEmergencyActive = computed(() => this.isEmergencyActiveSignal());

  // Fader Channels
  readonly channels = signal<ChannelState[]>([
    { id: 'mic1', name: 'MIC 1 (PRESENTER)', gain: 0.9, pan: 0, mute: false, solo: false, hpf: true, eqLow: 0, eqMid: 2, eqHigh: 1, compThreshold: -18 },
    { id: 'mic2', name: 'MIC 2 (GUEST)', gain: 0.0, pan: -0.2, mute: true, solo: false, hpf: true, eqLow: 0, eqMid: 0, eqHigh: 0, compThreshold: -18 },
    { id: 'mic3', name: 'MIC 3 (PHONE)', gain: 0.0, pan: 0.2, mute: true, solo: false, hpf: true, eqLow: -2, eqMid: 1, eqHigh: 0, compThreshold: -20 },
    { id: 'music', name: 'MUSIC PLAYOUT', gain: 1.0, pan: 0, mute: false, solo: false, hpf: false, eqLow: 1, eqMid: 0, eqHigh: 1, compThreshold: -12 },
    { id: 'jingle', name: 'JINGLES & IDs', gain: 0.95, pan: 0, mute: false, solo: false, hpf: false, eqLow: 0, eqMid: 1, eqHigh: 2, compThreshold: -14 },
    { id: 'news', name: 'NEWS & WEATHER', gain: 0.9, pan: 0, mute: false, solo: false, hpf: true, eqLow: -1, eqMid: 2, eqHigh: 1, compThreshold: -16 },
    { id: 'remote', name: 'REMOTE LINE', gain: 0.0, pan: 0, mute: true, solo: false, hpf: true, eqLow: 0, eqMid: 0, eqHigh: 0, compThreshold: -18 },
    { id: 'phone', name: 'CALLER HYBRID', gain: 0.0, pan: 0, mute: true, solo: false, hpf: true, eqLow: -3, eqMid: 2, eqHigh: -1, compThreshold: -22 },
    { id: 'aux', name: 'AUX / REVERB', gain: 0.3, pan: 0, mute: false, solo: false, hpf: false, eqLow: 0, eqMid: 0, eqHigh: 0, compThreshold: 0 },
  ]);

  private platformId = inject(PLATFORM_ID);

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      this.startLoudnessTelemetryLoop();
    }
  }

  private initAudioContext() {
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioCtx = new AudioCtxClass();
      this.masterGainNode = this.audioCtx.createGain();
      this.masterGainNode.gain.value = 0.85;

      this.analyserNode = this.audioCtx.createAnalyser();
      this.analyserNode.fftSize = 128;
      this.analyserNode.smoothingTimeConstant = 0.8;

      this.masterGainNode.connect(this.analyserNode);
      this.analyserNode.connect(this.audioCtx.destination);
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  /**
   * Generates a synthetic ambient music bed / broadcast tone
   */
  async playSyntheticRadioStream() {
    this.initAudioContext();
    if (!this.audioCtx || !this.masterGainNode) return;

    this.stopAudio();

    const sampleRate = this.audioCtx.sampleRate;
    const durationSeconds = 12;
    const buffer = this.audioCtx.createBuffer(2, sampleRate * durationSeconds, sampleRate);

    const left = buffer.getChannelData(0);
    const right = buffer.getChannelData(1);

    // Synthesize warm British radio music chord progression (A minor -> F -> C -> G)
    const baseFreqs = [220, 174.61, 261.63, 196.0]; // A3, F3, C4, G3

    for (let i = 0; i < buffer.length; i++) {
      const t = i / sampleRate;
      const chordIdx = Math.floor((t / 3) % 4);
      const freq = baseFreqs[chordIdx];

      // Warm analog chord synth
      let sampleL = 0.25 * Math.sin(2 * Math.PI * freq * t) + 0.15 * Math.sin(2 * Math.PI * freq * 1.5 * t);
      let sampleR = 0.25 * Math.sin(2 * Math.PI * freq * 1.002 * t) + 0.15 * Math.sin(2 * Math.PI * freq * 2.0 * t);

      // Add gentle tape noise/warmth
      const noise = (Math.random() * 2 - 1) * 0.015;
      sampleL += noise;
      sampleR += noise;

      // Soft envelope fade in/out loop
      const env = Math.min(1, t / 0.5) * Math.min(1, (durationSeconds - t) / 0.5);

      left[i] = sampleL * env * 0.4;
      right[i] = sampleR * env * 0.4;
    }

    this.currentSource = this.audioCtx.createBufferSource();
    this.currentSource.buffer = buffer;
    this.currentSource.loop = true;
    this.currentSource.connect(this.masterGainNode);
    this.currentSource.start(0);

    this.isPlayingSignal.set(true);
  }

  /**
   * Triggers a synthetic Northstar Station ID Jingle
   */
  playStationJingle() {
    this.initAudioContext();
    if (!this.audioCtx || !this.masterGainNode) return;

    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.type = 'triangle';
    const now = this.audioCtx.currentTime;

    // Chime melody: E5 -> G5 -> B5 -> E6
    osc.frequency.setValueAtTime(659.25, now);
    osc.frequency.setValueAtTime(783.99, now + 0.15);
    osc.frequency.setValueAtTime(987.77, now + 0.3);
    osc.frequency.setValueAtTime(1318.51, now + 0.45);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(0.3, now + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 1.2);

    osc.connect(gain);
    gain.connect(this.masterGainNode);

    osc.start(now);
    osc.stop(now + 1.25);
  }

  stopAudio() {
    if (this.currentSource) {
      try {
        this.currentSource.stop();
        this.currentSource.disconnect();
      } catch (e) {}
      this.currentSource = null;
    }
    this.isPlayingSignal.set(false);
  }

  setMasterVolume(val: number) {
    if (this.masterGainNode) {
      this.masterGainNode.gain.value = Math.max(0, Math.min(1.5, val));
    }
  }

  updateChannel(id: string, partial: Partial<ChannelState>) {
    this.channels.update((chs) =>
      chs.map((c) => (c.id === id ? { ...c, ...partial } : c))
    );
  }

  triggerEmergencyFailover() {
    this.isEmergencyActiveSignal.set(true);
    this.playSyntheticRadioStream();
  }

  resolveEmergencyFailover() {
    this.isEmergencyActiveSignal.set(false);
  }

  getFrequencyData(): Uint8Array {
    if (!this.analyserNode) return new Uint8Array(32).fill(0);
    const data = new Uint8Array(this.analyserNode.frequencyBinCount);
    this.analyserNode.getByteFrequencyData(data);
    return data;
  }

  private startLoudnessTelemetryLoop() {
    setInterval(() => {
      if (this.isPlayingSignal()) {
        // Dynamic fluctuation around target EBU R 128 (-23.0 LUFS)
        const jitter = (Math.random() - 0.5) * 0.8;
        const integ = -23.1 + jitter * 0.3;
        const st = -22.5 + jitter;
        const peak = -1.0 + (Math.random() - 0.5) * 0.2;

        this.currentLoudnessLUFS.set(Number(integ.toFixed(1)));
        this.currentShortTermLUFS.set(Number(st.toFixed(1)));
        this.currentTruePeakdB.set(Number(peak.toFixed(1)));
      }
    }, 1000);
  }
}
