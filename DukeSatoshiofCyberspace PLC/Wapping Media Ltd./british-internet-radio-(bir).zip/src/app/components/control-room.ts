import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RadioStateService } from '../services/radio-state';
import { AudioEngineService } from '../services/audio-engine';

@Component({
  selector: 'app-control-room',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-[calc(100vh-57px)] bg-[#121417] text-[#EAE6DF] p-4 md:p-8 space-y-6">
      
      <!-- Operational Header Bar -->
      <div class="bg-[#1C1F26] p-4 rounded-xl border border-[#282C35] flex flex-wrap items-center justify-between gap-4">
        <div class="flex items-center gap-4">
          <div class="flex items-center gap-2 px-3 py-1 bg-[#8B2628]/30 border border-[#D94042] rounded">
            <span class="w-2.5 h-2.5 rounded-full bg-[#D94042] animate-ping"></span>
            <span class="text-xs font-mono font-bold text-[#D94042] tracking-wider">● ON AIR</span>
          </div>
          <div>
            <h2 class="text-xl font-serif text-[#F4F1EA]">
              BROADCAST CONTROL ROOM — {{ state.activeChannelName() }}
            </h2>
            <p class="text-xs font-mono text-[#8E98A8]">
              STUDIO A · BROADCASTING HOUSE LONDON W1A
            </p>
          </div>
        </div>

        <!-- Playout Mode Selectors -->
        <div class="flex items-center gap-2 bg-[#121417] p-1 rounded-lg border border-[#282C35]">
          <span class="text-xs font-mono text-[#8E98A8] px-2">MODE:</span>
          @for (m of playoutModes; track m) {
            <button
              (click)="state.setPlayoutMode(m)"
              [class.bg-[#3F6E50]]="state.playoutMode() === m"
              [class.text-[#F4F1EA]]="state.playoutMode() === m"
              class="px-2.5 py-1 text-xs font-mono text-[#8E98A8] hover:text-[#F4F1EA] rounded transition-colors"
            >
              {{ m }}
            </button>
          }
        </div>
      </div>

      <!-- Main Split Screen: Program vs Rundown Queue -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left: Program Now Playing Instrument -->
        <div class="lg:col-span-7 bg-[#1C1F26] p-6 rounded-xl border border-[#282C35] flex flex-col justify-between space-y-6">
          <div class="flex items-center justify-between border-b border-[#282C35] pb-3">
            <span class="text-xs font-mono text-[#3F6E50] font-bold tracking-widest uppercase">
              PROGRAMME CHANNEL 01
            </span>
            <span class="text-xs font-mono text-[#8E98A8]">06:41:23 UTC</span>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
            <img
              [src]="state.nowPlaying()?.artwork || '/assets/images/album_evening_session_1790598678631.jpg'"
              alt="Artwork"
              class="w-full aspect-square object-cover rounded-lg border border-[#282C35]"
              referrerpolicy="no-referrer"
            />
            <div class="sm:col-span-2 space-y-2">
              <span class="text-xs font-mono text-[#E5B33A] bg-[#121417] px-2 py-0.5 rounded border border-[#282C35]">
                {{ state.nowPlaying()?.genre || 'Post-Punk / British Rock' }}
              </span>
              <h3 class="text-3xl font-serif text-[#F4F1EA]">
                {{ state.nowPlaying()?.title || 'A Forest' }}
              </h3>
              <p class="text-lg font-light text-[#8E98A8]">
                {{ state.nowPlaying()?.artist || 'The Cure' }}
              </p>
              <div class="flex items-center gap-4 text-xs font-mono text-[#8E98A8] pt-2">
                <span>BPM: {{ state.nowPlaying()?.bpm || 128 }}</span>
                <span>KEY: {{ state.nowPlaying()?.key || 'A minor' }}</span>
                <span>ERA: {{ state.nowPlaying()?.year || 1980 }}</span>
              </div>
            </div>
          </div>

          <!-- Waveform & Position Markers -->
          <div class="bg-[#121417] p-4 rounded-lg border border-[#282C35] space-y-2">
            <div class="flex justify-between text-xs font-mono text-[#8E98A8]">
              <span>INTRO: 00:15</span>
              <span class="text-[#3F6E50] font-semibold">ELAPSED: 02:22 / 05:55</span>
              <span>OUTRO: 05:30</span>
            </div>
            
            <!-- Simulated Waveform Peak Display -->
            <div class="h-14 flex items-center gap-0.5 overflow-hidden py-1">
              @for (h of waveformBars; track $index) {
                <div
                  class="flex-1 rounded-sm transition-all duration-300"
                  [style.height.%]="h"
                  [class.bg-[#3F6E50]]="$index < 28"
                  [class.bg-[#282C35]]="$index >= 28"
                ></div>
              }
            </div>
          </div>

          <!-- Playout Transport & Failover Bar -->
          <div class="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-[#282C35]">
            <div class="flex items-center gap-3">
              <button
                (click)="togglePlay()"
                class="px-4 py-2 bg-[#1E3A2B] hover:bg-[#2E523C] text-[#F4F1EA] text-xs font-mono font-bold rounded border border-[#3F6E50] flex items-center gap-2"
              >
                <span class="material-icons text-sm">{{ audio.isPlaying() ? 'pause' : 'play_arrow' }}</span>
                {{ audio.isPlaying() ? 'PAUSE PLAYOUT' : 'START PLAYOUT' }}
              </button>

              <button
                (click)="audio.playStationJingle()"
                class="px-3 py-2 bg-[#121417] hover:bg-[#282C35] text-[#F4F1EA] text-xs font-mono rounded border border-[#282C35]"
              >
                FIRE ID
              </button>
            </div>

            <button
              (click)="triggerEmergencyFailover()"
              [class.bg-[#8B2628]]="audio.isEmergencyActive()"
              class="px-3 py-2 bg-[#121417] hover:bg-[#8B2628] text-[#D94042] hover:text-white text-xs font-mono rounded border border-[#8B2628] transition-colors flex items-center gap-1.5"
            >
              <span class="material-icons text-sm">warning</span>
              {{ audio.isEmergencyActive() ? 'RESOLVE EMERGENCY' : 'TRIGGER EMERGENCY FAILOVER' }}
            </button>
          </div>

        </div>

        <!-- Right: Rundown Queue -->
        <div class="lg:col-span-5 bg-[#1C1F26] p-6 rounded-xl border border-[#282C35] space-y-4">
          <div class="flex items-center justify-between border-b border-[#282C35] pb-3">
            <h3 class="text-sm font-mono text-[#8E98A8] tracking-widest uppercase flex items-center gap-2">
              <span class="material-icons text-sm text-[#3F6E50]">queue_music</span>
              SHOW RUNDOWN QUEUE
            </h3>
            <span class="text-xs font-mono text-[#8E98A8]">7 ITEMS</span>
          </div>

          <div class="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
            @for (item of rundownItems; track item.time) {
              <div
                class="p-3 rounded-lg border transition-colors flex items-center justify-between"
                [class.bg-[#1E3A2B]/30]="item.status === 'playing'"
                [class.border-[#3F6E50]]="item.status === 'playing'"
                [class.bg-[#121417]]="item.status !== 'playing'"
                [class.border-[#282C35]]="item.status !== 'playing'"
              >
                <div>
                  <div class="flex items-center gap-2 text-[10px] font-mono text-[#8E98A8]">
                    <span>{{ item.time }}</span>
                    <span>·</span>
                    <span [class.text-[#3F6E50]]="item.type === 'TRACK'" [class.text-[#E5B33A]]="item.type === 'JINGLE'" [class.text-[#D94042]]="item.type === 'NEWS'">
                      {{ item.type }}
                    </span>
                  </div>
                  <h4 class="text-xs font-semibold text-[#F4F1EA] mt-0.5">{{ item.title }}</h4>
                  <p class="text-[11px] text-[#8E98A8] font-mono">{{ item.artist }}</p>
                </div>

                <div class="text-right text-xs font-mono text-[#8E98A8]">
                  <span>{{ item.duration }}s</span>
                </div>
              </div>
            }
          </div>
        </div>

      </div>

      <!-- Bottom Meters & Telemetry Bar -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        
        <!-- Peak Level Meters -->
        <div class="md:col-span-2 bg-[#1C1F26] p-4 rounded-xl border border-[#282C35] space-y-3">
          <div class="flex justify-between items-center text-xs font-mono text-[#8E98A8]">
            <span>STEREO PEAK METERS (dBFS)</span>
            <span>TARGET: -1.0 dB PEAK</span>
          </div>

          <div class="space-y-2">
            <div>
              <div class="flex justify-between text-[10px] font-mono text-[#8E98A8]">
                <span>L CHANNEL</span>
                <span class="text-[#3F6E50]">-1.2 dBFS</span>
              </div>
              <div class="w-full h-3 bg-[#121417] rounded overflow-hidden p-0.5 border border-[#282C35]">
                <div class="h-full bg-gradient-to-r from-[#1E3A2B] via-[#3F6E50] to-[#E5B33A] w-[82%]"></div>
              </div>
            </div>

            <div>
              <div class="flex justify-between text-[10px] font-mono text-[#8E98A8]">
                <span>R CHANNEL</span>
                <span class="text-[#3F6E50]">-1.1 dBFS</span>
              </div>
              <div class="w-full h-3 bg-[#121417] rounded overflow-hidden p-0.5 border border-[#282C35]">
                <div class="h-full bg-gradient-to-r from-[#1E3A2B] via-[#3F6E50] to-[#E5B33A] w-[84%]"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- EBU R 128 Loudness Telemetry -->
        <div class="bg-[#1C1F26] p-4 rounded-xl border border-[#282C35] space-y-2">
          <span class="text-xs font-mono text-[#8E98A8]">LOUDNESS (EBU R 128)</span>
          <div class="text-2xl font-mono font-bold text-[#3F6E50]">
            {{ audio.loudnessLUFS() }} <span class="text-xs font-normal text-[#8E98A8]">LUFS</span>
          </div>
          <div class="text-xs font-mono text-[#8E98A8] space-y-1 pt-1">
            <div class="flex justify-between">
              <span>SHORT TERM:</span>
              <span class="text-[#F4F1EA]">{{ audio.shortTermLUFS() }} LUFS</span>
            </div>
            <div class="flex justify-between">
              <span>TRUE PEAK:</span>
              <span class="text-[#F4F1EA]">{{ audio.truePeakdB() }} dBFS</span>
            </div>
            <div class="flex justify-between">
              <span>RANGE (LRA):</span>
              <span class="text-[#F4F1EA]">5.8 LU</span>
            </div>
          </div>
        </div>

        <!-- Stream & Encoder Telemetry -->
        <div class="bg-[#1C1F26] p-4 rounded-xl border border-[#282C35] space-y-2">
          <span class="text-xs font-mono text-[#8E98A8]">ENCODER & AUDIENCE</span>
          <div class="text-2xl font-mono font-bold text-[#F4F1EA]">
            {{ state.listenerCount() | number }} <span class="text-xs font-normal text-[#8E98A8]">LISTENERS</span>
          </div>
          <div class="text-xs font-mono text-[#8E98A8] space-y-1 pt-1">
            <div class="flex justify-between">
              <span>STREAM STATUS:</span>
              <span class="text-[#3F6E50] font-bold">● ONLINE</span>
            </div>
            <div class="flex justify-between">
              <span>ENCODER:</span>
              <span class="text-[#3F6E50]">HEALTHY</span>
            </div>
            <div class="flex justify-between">
              <span>BITRATE:</span>
              <span class="text-[#F4F1EA]">256 kbps AAC-LC</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  `,
})
export class ControlRoomComponent {
  state = inject(RadioStateService);
  audio = inject(AudioEngineService);

  playoutModes: ('AUTOMATION' | 'LIVE_DJ' | 'HYBRID' | 'EMERGENCY')[] = [
    'AUTOMATION',
    'LIVE_DJ',
    'HYBRID',
    'EMERGENCY',
  ];

  waveformBars = [
    15, 25, 45, 60, 80, 95, 70, 50, 40, 65, 85, 90, 100, 75, 55, 45, 60, 80, 95,
    70, 50, 40, 65, 85, 90, 75, 60, 40, 30, 20, 15, 25, 45, 60, 80, 70, 50, 40,
    65, 85, 90, 75, 60, 45, 30, 20, 15, 10,
  ];

  rundownItems = [
    { time: '19:00:00', type: 'SHOW_OPEN', title: 'The Evening Session Intro', artist: 'Northstar Audio', duration: '45', status: 'played' },
    { time: '19:01:15', type: 'TRACK', title: 'Starburster', artist: 'Fontaines D.C.', duration: '221', status: 'played' },
    { time: '19:04:56', type: 'TRACK', title: 'A Forest', artist: 'The Cure', duration: '355', status: 'playing' },
    { time: '19:10:51', type: 'JINGLE', title: 'Northstar Station ID - Evening', artist: 'Station Imaging', duration: '12', status: 'queued' },
    { time: '19:11:03', type: 'PRESENTER', title: 'Freya Link & Request Shoutout', artist: 'Live Studio Mic 1', duration: '42', status: 'queued' },
    { time: '19:11:45', type: 'TRACK', title: 'Teardrop', artist: 'Massive Attack', duration: '330', status: 'queued' },
    { time: '19:17:15', type: 'NEWS', title: 'Northstar 7PM News & UK Weather', artist: 'BBC / Northstar News', duration: '180', status: 'queued' },
  ];

  togglePlay() {
    if (this.audio.isPlaying()) {
      this.audio.stopAudio();
    } else {
      this.audio.playSyntheticRadioStream();
    }
  }

  triggerEmergencyFailover() {
    if (this.audio.isEmergencyActive()) {
      this.audio.resolveEmergencyFailover();
    } else {
      this.audio.triggerEmergencyFailover();
    }
  }
}
