import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  ViewChild,
  inject,
  signal,
  AfterViewInit,
  OnDestroy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RadioStateService } from '../services/radio-state';
import { AudioEngineService } from '../services/audio-engine';

@Component({
  selector: 'app-public-player',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-[calc(100vh-57px)] bg-[#121417] text-[#EAE6DF] px-4 md:px-12 py-8 max-w-7xl mx-auto flex flex-col justify-between">
      
      <!-- Top Brand Announcement & Status Bar -->
      <div class="flex flex-col md:flex-row md:items-end justify-between border-b border-[#282C35] pb-6 gap-4">
        <div>
          <span class="text-xs font-mono tracking-widest text-[#8E98A8] uppercase">BROADCAST SERVICE 01</span>
          <h1 class="text-3xl md:text-5xl font-serif tracking-tight text-[#F4F1EA] mt-1">
            NORTHSTAR RADIO
          </h1>
          <p class="text-xs font-mono tracking-widest text-[#3F6E50] mt-1">
            BRITAIN, IN SOUND.
          </p>
        </div>

        <div class="flex items-center gap-4 text-xs font-mono">
          <div class="flex items-center gap-2 bg-[#1C1F26] px-3 py-1.5 rounded border border-[#282C35]">
            <span class="w-2 h-2 rounded-full bg-[#3F6E50] animate-meter-pulse"></span>
            <span class="text-[#F4F1EA]">STREAM: {{ state.streamProfile() }}</span>
          </div>
          <div class="flex items-center gap-2 bg-[#1C1F26] px-3 py-1.5 rounded border border-[#282C35]">
            <span class="text-[#8E98A8]">LATENCY:</span>
            <span class="text-[#F4F1EA]">4.8s</span>
          </div>
          <div class="flex items-center gap-2 bg-[#1C1F26] px-3 py-1.5 rounded border border-[#282C35]">
            <span class="text-[#8E98A8]">EBU R128:</span>
            <span class="text-[#3F6E50] font-semibold">{{ audio.loudnessLUFS() }} LUFS</span>
          </div>
        </div>
      </div>

      <!-- Main On-Air Display Instrument -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 my-8 items-center">
        
        <!-- Left: Album Art & Record Sleeve -->
        <div class="lg:col-span-5 flex flex-col items-center">
          <div class="relative w-full max-w-md aspect-square bg-[#1C1F26] rounded-xl overflow-hidden border border-[#282C35] shadow-2xl group">
            <img
              [src]="state.nowPlaying()?.artwork || '/assets/images/album_evening_session_1790598678631.jpg'"
              [alt]="state.nowPlaying()?.title || 'Northstar On Air'"
              class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              referrerpolicy="no-referrer"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-[#121417]/90 via-transparent to-transparent"></div>
            
            <div class="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs font-mono text-[#EAE6DF]">
              <span class="bg-[#121417]/80 px-2.5 py-1 rounded border border-[#282C35]">
                {{ state.nowPlaying()?.genre || 'Post-Punk / British Rock' }}
              </span>
              <span class="text-[#3F6E50] font-bold">
                {{ state.nowPlaying()?.year || 1980 }}
              </span>
            </div>
          </div>
        </div>

        <!-- Right: Now Playing Instrument & Audio Visualization -->
        <div class="lg:col-span-7 flex flex-col justify-between space-y-6">
          
          <!-- Program & Track Header -->
          <div>
            <div class="flex items-center gap-3 text-xs font-mono text-[#8E98A8]">
              <span class="text-[#D94042] font-semibold flex items-center gap-1">
                <span class="w-2 h-2 rounded-full bg-[#D94042] animate-ping"></span>
                ● ON AIR
              </span>
              <span>·</span>
              <span>THE EVENING SESSION</span>
              <span>·</span>
              <span>PRESENTER: FREYA LINDQVIST</span>
            </div>

            <h2 class="text-3xl md:text-5xl font-serif font-normal text-[#F4F1EA] mt-3">
              {{ state.nowPlaying()?.title || 'A Forest' }}
            </h2>
            <p class="text-xl md:text-2xl font-light text-[#8E98A8] mt-1">
              {{ state.nowPlaying()?.artist || 'The Cure' }}
            </p>
          </div>

          <!-- Real-Time Spectrum Canvas -->
          <div class="bg-[#1C1F26] p-4 rounded-xl border border-[#282C35] relative">
            <div class="flex justify-between items-center text-[11px] font-mono text-[#8E98A8] mb-2">
              <span>SPECTRUM ANALYSER (20 Hz - 20 kHz)</span>
              <span>EBU R 128 TARGET: -23 LUFS</span>
            </div>
            <canvas #spectrumCanvas class="w-full h-24 rounded bg-[#121417] border border-[#282C35]"></canvas>
          </div>

          <!-- Progress Bar -->
          <div>
            <div class="flex justify-between text-xs font-mono text-[#8E98A8] mb-1.5">
              <span>02:22</span>
              <span class="text-[#F4F1EA] font-semibold">05:55</span>
            </div>
            <div class="w-full h-2 bg-[#282C35] rounded-full overflow-hidden">
              <div class="h-full bg-[#3F6E50] w-[40%] transition-all duration-300"></div>
            </div>
          </div>

          <!-- Player Controls & Stream Quality -->
          <div class="flex flex-wrap items-center justify-between gap-4 pt-2">
            <div class="flex items-center gap-4">
              <button
                (click)="togglePlay()"
                class="w-14 h-14 rounded-full bg-[#3F6E50] hover:bg-[#2E523C] text-[#F4F1EA] flex items-center justify-center transition-all shadow-lg active:scale-95"
                [title]="audio.isPlaying() ? 'Pause Radio Stream' : 'Play Radio Stream'"
              >
                <span class="material-icons text-3xl">
                  {{ audio.isPlaying() ? 'pause' : 'play_arrow' }}
                </span>
              </button>

              <button
                (click)="triggerJingle()"
                class="px-4 py-2 text-xs font-mono bg-[#1C1F26] hover:bg-[#282C35] text-[#F4F1EA] border border-[#282C35] rounded-lg transition-colors flex items-center gap-1.5"
              >
                <span class="material-icons text-sm text-[#E5B33A]">graphic_eq</span>
                STATION ID
              </button>
            </div>

            <!-- Quality Profile Selector -->
            <div class="flex items-center gap-1 bg-[#1C1F26] p-1 rounded-lg border border-[#282C35]">
              @for (q of qualityProfiles; track q) {
                <button
                  (click)="state.setStreamProfile(q)"
                  [class.bg-[#3F6E50]]="state.streamProfile() === q"
                  [class.text-[#F4F1EA]]="state.streamProfile() === q"
                  class="px-2.5 py-1 text-[11px] font-mono text-[#8E98A8] hover:text-[#F4F1EA] rounded transition-colors"
                >
                  {{ q }}
                </button>
              }
            </div>
          </div>

          <!-- Upcoming Queue Breakdown -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div class="bg-[#1C1F26] p-3.5 rounded-lg border border-[#282C35]">
              <span class="text-[10px] font-mono text-[#8E98A8] uppercase tracking-wider">NEXT</span>
              <p class="text-sm font-semibold text-[#F4F1EA] mt-0.5 truncate">
                {{ state.nextItem()?.title || 'NORTHSTAR STATION ID' }}
              </p>
              <span class="text-xs text-[#8E98A8] font-mono">12s · STATION IMAGING</span>
            </div>

            <div class="bg-[#1C1F26] p-3.5 rounded-lg border border-[#282C35]">
              <span class="text-[10px] font-mono text-[#8E98A8] uppercase tracking-wider">FOLLOWING</span>
              <p class="text-sm font-semibold text-[#F4F1EA] mt-0.5 truncate">
                Radiohead — Everything In Its Right Place
              </p>
              <span class="text-xs text-[#8E98A8] font-mono">04:11 · MUSIC PLAYOUT</span>
            </div>
          </div>

        </div>
      </div>

      <!-- Bottom Interactive Tabs: EPG Guide & Listener Request Form -->
      <div class="border-t border-[#282C35] pt-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- Today's Broadcast Programme Guide (EPG) -->
        <div class="lg:col-span-7">
          <h3 class="text-sm font-mono text-[#8E98A8] tracking-widest uppercase mb-4 flex items-center gap-2">
            <span class="material-icons text-sm text-[#3F6E50]">schedule</span>
            TODAY'S PROGRAMME GUIDE (EPG)
          </h3>

          <div class="space-y-2.5">
            <div class="flex items-center justify-between p-3 bg-[#1C1F26] rounded-lg border border-[#282C35]">
              <div class="flex items-center gap-4">
                <span class="font-mono text-xs text-[#8E98A8]">06:00 – 09:00</span>
                <div>
                  <h4 class="text-sm font-semibold text-[#F4F1EA]">NORTHSTAR BREAKFAST</h4>
                  <p class="text-xs text-[#8E98A8]">Gideon Vance · British news, culture & morning record selections</p>
                </div>
              </div>
              <span class="text-[11px] font-mono text-[#8E98A8] bg-[#121417] px-2 py-0.5 rounded">PASSED</span>
            </div>

            <div class="flex items-center justify-between p-3 bg-[#1E3A2B]/40 rounded-lg border border-[#3F6E50]">
              <div class="flex items-center gap-4">
                <span class="font-mono text-xs text-[#3F6E50] font-bold">19:00 – 22:00</span>
                <div>
                  <h4 class="text-sm font-semibold text-[#F4F1EA]">THE EVENING SESSION</h4>
                  <p class="text-xs text-[#8E98A8]">Freya Lindqvist · Live studio guests, new releases & sessions</p>
                </div>
              </div>
              <span class="text-[11px] font-mono text-[#F4F1EA] bg-[#3F6E50] px-2 py-0.5 rounded font-bold animate-pulse">ON AIR</span>
            </div>

            <div class="flex items-center justify-between p-3 bg-[#1C1F26] rounded-lg border border-[#282C35]">
              <div class="flex items-center gap-4">
                <span class="font-mono text-xs text-[#8E98A8]">22:00 – 02:00</span>
                <div>
                  <h4 class="text-sm font-semibold text-[#F4F1EA]">NIGHT MUSIC</h4>
                  <p class="text-xs text-[#8E98A8]">Dominic Vance · Ambient, electronic & nocturnal soundscapes</p>
                </div>
              </div>
              <span class="text-[11px] font-mono text-[#8E98A8] bg-[#121417] px-2 py-0.5 rounded">UPCOMING</span>
            </div>
          </div>
        </div>

        <!-- Listener Song Request & Dedication Form -->
        <div class="lg:col-span-5 bg-[#1C1F26] p-5 rounded-xl border border-[#282C35]">
          <h3 class="text-sm font-mono text-[#8E98A8] tracking-widest uppercase mb-3 flex items-center gap-2">
            <span class="material-icons text-sm text-[#E5B33A]">send</span>
            SUBMIT A SONG REQUEST / DEDICATION
          </h3>

          <form (submit)="onRequestSubmit($event)" class="space-y-3">
            <div>
              <label class="block text-xs font-mono text-[#8E98A8] mb-1">SONG TITLE & ARTIST</label>
              <input
                type="text"
                [(ngModel)]="requestSong"
                name="requestSong"
                placeholder="e.g. Glory Box — Portishead"
                class="w-full bg-[#121417] border border-[#282C35] rounded px-3 py-1.5 text-xs text-[#F4F1EA] focus:outline-none focus:border-[#3F6E50]"
                required
              />
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-xs font-mono text-[#8E98A8] mb-1">YOUR NAME & LOCATION</label>
                <input
                  type="text"
                  [(ngModel)]="requestName"
                  name="requestName"
                  placeholder="e.g. Alastair from Bristol"
                  class="w-full bg-[#121417] border border-[#282C35] rounded px-3 py-1.5 text-xs text-[#F4F1EA] focus:outline-none focus:border-[#3F6E50]"
                  required
                />
              </div>
              <div>
                <label class="block text-xs font-mono text-[#8E98A8] mb-1">MESSAGE / DEDICATION</label>
                <input
                  type="text"
                  [(ngModel)]="requestMessage"
                  name="requestMessage"
                  placeholder="e.g. For the late drive..."
                  class="w-full bg-[#121417] border border-[#282C35] rounded px-3 py-1.5 text-xs text-[#F4F1EA] focus:outline-none focus:border-[#3F6E50]"
                />
              </div>
            </div>

            <button
              type="submit"
              class="w-full py-2 bg-[#1E3A2B] hover:bg-[#2E523C] text-[#F4F1EA] text-xs font-mono font-semibold rounded border border-[#3F6E50] transition-colors"
            >
              TRANSMIT REQUEST TO STUDIO PRODUCER
            </button>
          </form>

          @if (submittedSuccess()) {
            <p class="text-xs font-mono text-[#3F6E50] mt-2">
              ✓ Request transmitted to Northstar Studio desk.
            </p>
          }
        </div>

      </div>

    </div>
  `,
})
export class PublicPlayerComponent implements AfterViewInit, OnDestroy {
  state = inject(RadioStateService);
  audio = inject(AudioEngineService);

  qualityProfiles: ('HQ' | 'STANDARD' | 'MOBILE' | 'LOSSLESS')[] = [
    'HQ',
    'STANDARD',
    'MOBILE',
    'LOSSLESS',
  ];

  requestSong = '';
  requestName = '';
  requestMessage = '';
  submittedSuccess = signal(false);

  @ViewChild('spectrumCanvas') canvasRef!: ElementRef<HTMLCanvasElement>;
  private animFrameId: number | null = null;

  ngAfterViewInit() {
    this.drawSpectrum();
  }

  ngOnDestroy() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }
  }

  togglePlay() {
    if (this.audio.isPlaying()) {
      this.audio.stopAudio();
    } else {
      this.audio.playSyntheticRadioStream();
    }
  }

  triggerJingle() {
    this.audio.playStationJingle();
  }

  onRequestSubmit(e: Event) {
    e.preventDefault();
    if (!this.requestSong || !this.requestName) return;

    this.state.submitRequest(
      this.requestSong,
      '',
      this.requestName,
      this.requestMessage
    );

    this.requestSong = '';
    this.requestName = '';
    this.requestMessage = '';
    this.submittedSuccess.set(true);

    setTimeout(() => this.submittedSuccess.set(false), 4000);
  }

  private drawSpectrum() {
    const canvas = this.canvasRef?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;

    const render = () => {
      const data = this.audio.getFrequencyData();
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const barWidth = (canvas.width / data.length) * 2;
      let x = 0;

      for (let i = 0; i < data.length; i++) {
        const barHeight = (data[i] / 255) * canvas.height;

        // Gradient from British Racing Green to Brass
        const grad = ctx.createLinearGradient(0, canvas.height, 0, 0);
        grad.addColorStop(0, '#1E3A2B');
        grad.addColorStop(0.7, '#3F6E50');
        grad.addColorStop(1, '#C69214');

        ctx.fillStyle = this.audio.isPlaying() ? grad : '#282C35';
        ctx.fillRect(x, canvas.height - barHeight, barWidth - 1, barHeight);

        x += barWidth;
      }

      this.animFrameId = requestAnimationFrame(render);
    };

    render();
  }
}
