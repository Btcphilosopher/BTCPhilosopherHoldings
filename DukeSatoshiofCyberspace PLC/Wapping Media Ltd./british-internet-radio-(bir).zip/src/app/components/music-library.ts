import { ChangeDetectionStrategy, Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { AudioEngineService } from '../services/audio-engine';

@Component({
  selector: 'app-music-library',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-[calc(100vh-57px)] bg-[#121417] text-[#EAE6DF] p-4 md:p-8 space-y-6">
      
      <!-- Library Top Bar -->
      <div class="bg-[#1C1F26] p-4 rounded-xl border border-[#282C35] flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 class="text-xl font-serif text-[#F4F1EA] flex items-center gap-2">
            <span class="material-icons text-[#3F6E50]">library_music</span>
            NORTHSTAR MUSIC & AUDIO ASSET LIBRARY
          </h2>
          <p class="text-xs font-mono text-[#8E98A8]">
            EBU ADM LOUDNESS METADATA · MEASURED ACOUSTIC INTELLIGENCE
          </p>
        </div>

        <!-- Search Bar -->
        <div class="w-full md:w-80">
          <input
            type="text"
            [(ngModel)]="searchQuery"
            (ngModelChange)="onSearch()"
            placeholder="Search artist, title, genre..."
            class="w-full bg-[#121417] border border-[#282C35] rounded-lg px-3.5 py-1.5 text-xs text-[#F4F1EA] focus:outline-none focus:border-[#3F6E50]"
          />
        </div>
      </div>

      <!-- Main Layout: Sidebar Categories vs Asset Table -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left Sidebar Navigation -->
        <div class="lg:col-span-3 bg-[#1C1F26] p-4 rounded-xl border border-[#282C35] space-y-2">
          <span class="text-[10px] font-mono text-[#8E98A8] tracking-widest uppercase block mb-2 px-2">
            LIBRARY SECTIONS
          </span>

          @for (cat of categories; track cat.id) {
            <button
              (click)="selectCategory(cat.id)"
              [class.bg-[#3F6E50]]="selectedCategory() === cat.id"
              [class.text-[#F4F1EA]]="selectedCategory() === cat.id"
              [class.bg-[#121417]]="selectedCategory() !== cat.id"
              [class.text-[#8E98A8]]="selectedCategory() !== cat.id"
              class="w-full text-left px-3 py-2 rounded text-xs font-mono font-semibold flex items-center justify-between hover:text-[#F4F1EA] transition-colors"
            >
              <span class="flex items-center gap-2">
                <span class="material-icons text-sm">{{ cat.icon }}</span>
                {{ cat.name }}
              </span>
              <span class="text-[10px] opacity-75">{{ cat.count }}</span>
            </button>
          }
        </div>

        <!-- Right Main Data Table -->
        <div class="lg:col-span-9 bg-[#1C1F26] p-5 rounded-xl border border-[#282C35] space-y-4">
          <div class="flex items-center justify-between border-b border-[#282C35] pb-3">
            <h3 class="text-xs font-mono text-[#8E98A8] tracking-widest uppercase">
              AUDIO ASSETS ({{ tracks().length }} ITEMS)
            </h3>
            <span class="text-xs font-mono text-[#3F6E50]">EBU R 128 VERIFIED</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs font-mono">
              <thead class="bg-[#121417] text-[#8E98A8] border-b border-[#282C35]">
                <tr>
                  <th class="p-3">ASSET</th>
                  <th class="p-3">ARTIST</th>
                  <th class="p-3">ALBUM</th>
                  <th class="p-3">BPM / KEY</th>
                  <th class="p-3">LOUDNESS</th>
                  <th class="p-3">TYPE</th>
                  <th class="p-3 text-right">ACTIONS</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#282C35]">
                @for (track of tracks(); track track.id) {
                  <tr class="hover:bg-[#121417]/50 transition-colors">
                    <td class="p-3 flex items-center gap-3">
                      <img
                        [src]="track.artwork || '/assets/images/album_evening_session_1790598678631.jpg'"
                        alt=""
                        class="w-10 h-10 object-cover rounded border border-[#282C35]"
                        referrerpolicy="no-referrer"
                      />
                      <div>
                        <span class="font-bold text-[#F4F1EA] block text-sm font-sans">{{ track.title }}</span>
                        <span class="text-[10px] text-[#8E98A8]">{{ track.genre }}</span>
                      </div>
                    </td>
                    <td class="p-3 text-[#F4F1EA] font-semibold">{{ track.artist }}</td>
                    <td class="p-3 text-[#8E98A8]">{{ track.album }}</td>
                    <td class="p-3 text-[#F4F1EA]">
                      {{ track.bpm }} BPM · {{ track.key }}
                    </td>
                    <td class="p-3 text-[#3F6E50] font-bold">
                      {{ track.integratedLUFS }} LUFS
                      <span class="text-[9px] text-[#8E98A8] block font-normal">
                        {{ track.measured ? 'MEASURED' : 'INFERRED' }}
                      </span>
                    </td>
                    <td class="p-3">
                      <span
                        class="px-2 py-0.5 text-[10px] font-bold rounded uppercase"
                        [class.bg-[#1E3A2B]]="track.category === 'music'"
                        [class.text-[#3F6E50]]="track.category === 'music'"
                        [class.bg-[#C69214]/20]="track.category !== 'music'"
                        [class.text-[#E5B33A]]="track.category !== 'music'"
                      >
                        {{ track.category }}
                      </span>
                    </td>
                    <td class="p-3 text-right">
                      <div class="flex items-center justify-end gap-2">
                        <button
                          (click)="audio.playSyntheticRadioStream()"
                          class="p-1.5 bg-[#121417] hover:bg-[#282C35] text-[#F4F1EA] rounded border border-[#282C35]"
                          title="Preview Track"
                        >
                          <span class="material-icons text-sm">play_arrow</span>
                        </button>
                        <button
                          (click)="audio.playStationJingle()"
                          class="p-1.5 bg-[#1E3A2B] hover:bg-[#2E523C] text-[#F4F1EA] rounded border border-[#3F6E50]"
                          title="Add to Playout Queue"
                        >
                          <span class="material-icons text-sm">add_to_queue</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>

        </div>

      </div>

    </div>
  `,
})
export class MusicLibraryComponent implements OnInit {
  audio = inject(AudioEngineService);
  private http = inject(HttpClient);

  tracks = signal<any[]>([]);
  selectedCategory = signal<string>('all');
  searchQuery = '';

  categories = [
    { id: 'all', name: 'ALL MUSIC', icon: 'music_note', count: 420 },
    { id: 'music', name: 'NEW MUSIC', icon: 'new_releases', count: 180 },
    { id: 'jingle', name: 'JINGLES & IDs', icon: 'graphic_eq', count: 45 },
    { id: 'sweeper', name: 'SWEEPERS', icon: 'waves', count: 30 },
    { id: 'archive', name: 'ARCHIVE', icon: 'inventory_2', count: 850 },
  ];

  ngOnInit() {
    this.fetchTracks();
  }

  selectCategory(id: string) {
    this.selectedCategory.set(id);
    this.fetchTracks();
  }

  onSearch() {
    this.fetchTracks();
  }

  fetchTracks() {
    let url = `/api/v1/tracks?search=${encodeURIComponent(this.searchQuery)}`;
    if (this.selectedCategory() !== 'all') {
      url += `&category=${this.selectedCategory()}`;
    }

    this.http.get<any>(url).subscribe({
      next: (res) => {
        if (res.tracks) {
          this.tracks.set(res.tracks);
        }
      },
      error: (err) => console.error('Fetch tracks failed:', err),
    });
  }
}
