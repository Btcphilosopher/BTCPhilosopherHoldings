import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { RadioStateService } from '../services/radio-state';
import { AudioEngineService } from '../services/audio-engine';

@Component({
  selector: 'app-presenter-console',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-[calc(100vh-57px)] bg-[#121417] text-[#EAE6DF] p-4 md:p-8 space-y-6">
      
      <!-- Presenter Title Bar & Mic Live Master -->
      <div class="bg-[#1C1F26] p-4 rounded-xl border border-[#282C35] flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 class="text-xl font-serif text-[#F4F1EA] flex items-center gap-2">
            <span class="material-icons text-[#D94042]">mic</span>
            PRESENTER CONSOLE & ON-AIR TALK DESK
          </h2>
          <p class="text-xs font-mono text-[#8E98A8]">
            STUDIO MIC 1 · FREYA LINDQVIST · THE EVENING SESSION
          </p>
        </div>

        <div class="flex items-center gap-4">
          <!-- Mic Live Toggle -->
          <button
            (click)="toggleMicLive()"
            [class.bg-[#8B2628]]="micLive()"
            [class.text-[#F4F1EA]]="micLive()"
            [class.border-[#D94042]]="micLive()"
            [class.bg-[#121417]]="!micLive()"
            [class.text-[#8E98A8]]="!micLive()"
            class="px-5 py-2.5 rounded-lg border border-[#282C35] text-xs font-mono font-bold flex items-center gap-2 transition-all shadow-lg"
          >
            <span class="w-2.5 h-2.5 rounded-full" [class.bg-[#D94042]]="micLive()" [class.animate-ping]="micLive()" [class.bg-[#4A5260]]="!micLive()"></span>
            {{ micLive() ? 'MIC 1 LIVE ON AIR' : 'START MIC 1 TALK' }}
          </button>

          <div class="bg-[#121417] px-3.5 py-2 rounded border border-[#282C35] text-xs font-mono">
            <span class="text-[#8E98A8] block text-[10px]">TALK TIMER</span>
            <span class="text-[#F4F1EA] font-bold text-sm">{{ talkTimer() }}</span>
          </div>
        </div>
      </div>

      <!-- Main Grid: AI Script Generator vs Request Moderation -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left: AI Script & Bulletin Generator (Gemini 3.8 Flash) -->
        <div class="lg:col-span-7 bg-[#1C1F26] p-6 rounded-xl border border-[#282C35] space-y-4">
          <div class="flex items-center justify-between border-b border-[#282C35] pb-3">
            <h3 class="text-xs font-mono text-[#3F6E50] tracking-widest uppercase flex items-center gap-2">
              <span class="material-icons text-sm">auto_awesome</span>
              GEMINI 3.8 SCRIPT & BULLETIN GENERATOR
            </h3>
            <span class="text-[11px] font-mono text-[#8E98A8]">AUTORADIOPHONE v3.6</span>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              (click)="generateScript('WEATHER')"
              class="p-2.5 bg-[#121417] hover:bg-[#282C35] text-xs font-mono rounded border border-[#282C35] text-center transition-colors"
            >
              UK WEATHER
            </button>
            <button
              (click)="generateScript('NEWS')"
              class="p-2.5 bg-[#121417] hover:bg-[#282C35] text-xs font-mono rounded border border-[#282C35] text-center transition-colors"
            >
              NEWS BULLETIN
            </button>
            <button
              (click)="generateScript('TRAFFIC')"
              class="p-2.5 bg-[#121417] hover:bg-[#282C35] text-xs font-mono rounded border border-[#282C35] text-center transition-colors"
            >
              UK TRAFFIC
            </button>
            <button
              (click)="generateScript('TRACK_INTRO')"
              class="p-2.5 bg-[#121417] hover:bg-[#282C35] text-xs font-mono rounded border border-[#282C35] text-center transition-colors"
            >
              TRACK BACK-SELL
            </button>
          </div>

          <!-- Script Output Area -->
          <div class="bg-[#121417] p-4 rounded-lg border border-[#282C35] space-y-2 min-h-[200px] flex flex-col justify-between">
            @if (isGeneratingScript()) {
              <div class="flex items-center justify-center py-12 text-xs font-mono text-[#3F6E50] animate-pulse">
                Generating broadcast script with Gemini 3.8 Flash...
              </div>
            } @else {
              <div class="text-xs font-mono text-[#EAE6DF] whitespace-pre-wrap leading-relaxed">
                {{ currentScript() }}
              </div>
              <div class="flex justify-between items-center text-[10px] font-mono text-[#8E98A8] pt-2 border-t border-[#282C35]">
                <span>PROMPT: BROADCASSER INTRO</span>
                <button
                  (click)="synthesizeVoice()"
                  class="px-2.5 py-1 bg-[#1E3A2B] hover:bg-[#2E523C] text-[#F4F1EA] rounded border border-[#3F6E50] flex items-center gap-1"
                >
                  <span class="material-icons text-xs">volume_up</span>
                  TTS VOICE SYNTH
                </button>
              </div>
            }
          </div>
        </div>

        <!-- Right: Listener Request Moderation Queue -->
        <div class="lg:col-span-5 bg-[#1C1F26] p-6 rounded-xl border border-[#282C35] space-y-4">
          <div class="flex items-center justify-between border-b border-[#282C35] pb-3">
            <h3 class="text-xs font-mono text-[#8E98A8] tracking-widest uppercase flex items-center gap-2">
              <span class="material-icons text-sm text-[#E5B33A]">forum</span>
              LISTENER REQUEST MODERATION
            </h3>
            <span class="text-xs font-mono text-[#8E98A8]">{{ state.requests().length }} PENDING</span>
          </div>

          <div class="space-y-3 max-h-[380px] overflow-y-auto pr-1">
            @for (req of state.requests(); track req.id) {
              <div class="p-3 bg-[#121417] rounded-lg border border-[#282C35] space-y-2">
                <div class="flex items-center justify-between text-xs font-mono">
                  <span class="font-bold text-[#F4F1EA]">{{ req.songTitle }}</span>
                  <span class="text-[#8E98A8]">{{ req.timestamp }}</span>
                </div>
                <p class="text-xs text-[#3F6E50] font-mono">From: {{ req.requesterName }}</p>
                <p class="text-xs italic text-[#8E98A8] bg-[#1C1F26] p-2 rounded">"{{ req.message }}"</p>

                <div class="flex items-center gap-2 pt-1">
                  <button
                    (click)="state.updateRequestStatus(req.id, 'approved')"
                    [class.bg-[#3F6E50]]="req.status === 'approved'"
                    class="px-2.5 py-1 text-[10px] font-mono font-bold bg-[#1E3A2B] hover:bg-[#2E523C] text-[#F4F1EA] rounded border border-[#3F6E50]"
                  >
                    APPROVE
                  </button>
                  <button
                    (click)="state.updateRequestStatus(req.id, 'rejected')"
                    class="px-2.5 py-1 text-[10px] font-mono font-bold bg-[#121417] hover:bg-[#8B2628] text-[#8E98A8] hover:text-[#F4F1EA] rounded border border-[#282C35]"
                  >
                    REJECT
                  </button>
                  <button
                    (click)="state.updateRequestStatus(req.id, 'on_air')"
                    class="px-2.5 py-1 text-[10px] font-mono font-bold bg-[#C69214] hover:bg-[#E5B33A] text-[#121417] rounded"
                  >
                    SEND TO AIR
                  </button>
                </div>
              </div>
            }
          </div>
        </div>

      </div>

    </div>
  `,
})
export class PresenterConsoleComponent {
  state = inject(RadioStateService);
  audio = inject(AudioEngineService);
  private http = inject(HttpClient);

  micLive = signal(false);
  talkTimer = signal('00:00');
  private timerInterval: any = null;
  private talkSeconds = 0;

  isGeneratingScript = signal(false);
  currentScript = signal(
    `Good evening and welcome back to The Evening Session on Northstar Radio — Britain, In Sound. Up next, we have post-punk classic A Forest by The Cure, followed by new music from Fontaines D.C. Stay with us through the night.`
  );

  toggleMicLive() {
    this.micLive.update((v) => !v);
    if (this.micLive()) {
      this.talkSeconds = 0;
      this.timerInterval = setInterval(() => {
        this.talkSeconds++;
        const mins = String(Math.floor(this.talkSeconds / 60)).padStart(2, '0');
        const secs = String(this.talkSeconds % 60).padStart(2, '0');
        this.talkTimer.set(`${mins}:${secs}`);
      }, 1000);
    } else {
      if (this.timerInterval) clearInterval(this.timerInterval);
      this.talkTimer.set('00:00');
    }
  }

  generateScript(type: string) {
    this.isGeneratingScript.set(true);
    this.http
      .post<any>('/api/v1/gemini/generate-script', {
        type,
        topic: 'A Forest by The Cure',
        presenterName: 'Freya Lindqvist',
      })
      .subscribe({
        next: (res) => {
          this.currentScript.set(res.script || 'Script unavailable');
          this.isGeneratingScript.set(false);
        },
        error: (err) => {
          console.error('Script generation error:', err);
          this.isGeneratingScript.set(false);
        },
      });
  }

  synthesizeVoice() {
    this.http
      .post<any>('/api/v1/gemini/tts', { text: this.currentScript(), voice: 'Kore' })
      .subscribe({
        next: () => {
          this.audio.playStationJingle();
        },
        error: (err) => console.error('Voice synth error:', err),
      });
  }
}
