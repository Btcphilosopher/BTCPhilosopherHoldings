import { ChangeDetectionStrategy, Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { RadioStateService } from '../services/radio-state';

@Component({
  selector: 'app-analytics-view',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-[calc(100vh-57px)] bg-[#121417] text-[#EAE6DF] p-4 md:p-8 space-y-6">
      
      <!-- Analytics Title Bar -->
      <div class="bg-[#1C1F26] p-4 rounded-xl border border-[#282C35] flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 class="text-xl font-serif text-[#F4F1EA] flex items-center gap-2">
            <span class="material-icons text-[#3F6E50]">bar_chart</span>
            AUDIENCE ANALYTICS & PROGRAMME ENERGY CURVE
          </h2>
          <p class="text-xs font-mono text-[#8E98A8]">
            UNITED KINGDOM BROADCAST REACH · STREAM RETENTION METRICS
          </p>
        </div>

        <div class="flex items-center gap-4 text-xs font-mono">
          <div class="bg-[#121417] px-3.5 py-1.5 rounded border border-[#282C35]">
            <span class="text-[#8E98A8]">ACTIVE LISTENERS:</span>
            <span class="text-[#3F6E50] font-bold ml-1.5">{{ state.listenerCount() | number }}</span>
          </div>
          <div class="bg-[#121417] px-3.5 py-1.5 rounded border border-[#282C35]">
            <span class="text-[#8E98A8]">PEAK TODAY:</span>
            <span class="text-[#F4F1EA] font-bold ml-1.5">24,190</span>
          </div>
        </div>
      </div>

      <!-- Regional Distribution Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left: UK Audience Map Breakdown -->
        <div class="lg:col-span-7 bg-[#1C1F26] p-6 rounded-xl border border-[#282C35] space-y-4">
          <h3 class="text-xs font-mono text-[#8E98A8] tracking-widest uppercase flex items-center gap-2">
            <span class="material-icons text-sm text-[#3F6E50]">map</span>
            UK REGIONAL AUDIENCE DISTRIBUTION
          </h3>

          <div class="space-y-3">
            @for (reg of regionalData(); track reg.city) {
              <div class="space-y-1">
                <div class="flex justify-between text-xs font-mono">
                  <span class="text-[#F4F1EA] font-semibold">{{ reg.city }}</span>
                  <span class="text-[#8E98A8]">{{ reg.listeners | number }} ({{ reg.percentage }}%)</span>
                </div>
                <div class="w-full h-2.5 bg-[#121417] rounded overflow-hidden p-0.5 border border-[#282C35]">
                  <div
                    class="h-full bg-gradient-to-r from-[#1E3A2B] to-[#3F6E50] rounded-sm transition-all duration-500"
                    [style.width.%]="reg.percentage"
                  ></div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Right: Stream Quality Breakdown & Retention -->
        <div class="lg:col-span-5 bg-[#1C1F26] p-6 rounded-xl border border-[#282C35] space-y-4">
          <h3 class="text-xs font-mono text-[#8E98A8] tracking-widest uppercase flex items-center gap-2">
            <span class="material-icons text-sm text-[#E5B33A]">graphic_eq</span>
            STREAM PROFILE CONSUMPTION
          </h3>

          <div class="space-y-3">
            @for (prof of qualityData(); track prof.profile) {
              <div class="p-3 bg-[#121417] rounded-lg border border-[#282C35] flex items-center justify-between text-xs font-mono">
                <span class="text-[#F4F1EA] font-bold">{{ prof.profile }}</span>
                <span class="text-[#3F6E50] font-bold">{{ prof.percentage }}%</span>
              </div>
            }
          </div>

          <div class="pt-3 border-t border-[#282C35] space-y-1 text-xs font-mono text-[#8E98A8]">
            <div class="flex justify-between">
              <span>AVERAGE SESSION DURATION:</span>
              <span class="text-[#F4F1EA]">48.5 MINS</span>
            </div>
            <div class="flex justify-between">
              <span>BUFFER RETRY RATE:</span>
              <span class="text-[#3F6E50]">0.02%</span>
            </div>
          </div>
        </div>

      </div>

      <!-- Programme Energy Curve Visualization -->
      <div class="bg-[#1C1F26] p-6 rounded-xl border border-[#282C35] space-y-4">
        <h3 class="text-xs font-mono text-[#8E98A8] tracking-widest uppercase flex items-center gap-2">
          <span class="material-icons text-sm text-[#3F6E50]">show_chart</span>
          PROGRAMME ENERGY CURVE (24-HOUR BROADCAST SCHEDULING)
        </h3>

        <!-- Energy Curve Graph Bars -->
        <div class="h-32 bg-[#121417] rounded-lg border border-[#282C35] p-4 flex items-end justify-between gap-2">
          @for (e of energyCurve; track $index) {
            <div class="flex-1 flex flex-col items-center gap-1">
              <div
                class="w-full bg-[#3F6E50] rounded-t transition-all duration-300"
                [style.height.%]="e.energy"
              ></div>
              <span class="text-[9px] font-mono text-[#8E98A8] truncate">{{ e.time }}</span>
            </div>
          }
        </div>
      </div>

    </div>
  `,
})
export class AnalyticsViewComponent implements OnInit {
  state = inject(RadioStateService);
  private http = inject(HttpClient);

  regionalData = signal<any[]>([]);
  qualityData = signal<any[]>([]);

  energyCurve = [
    { time: '06:00', energy: 85 },
    { time: '08:00', energy: 95 },
    { time: '10:00', energy: 65 },
    { time: '12:00', energy: 75 },
    { time: '14:00', energy: 60 },
    { time: '16:00', energy: 80 },
    { time: '19:00', energy: 90 },
    { time: '21:00', energy: 70 },
    { time: '23:00', energy: 40 },
    { time: '02:00', energy: 25 },
  ];

  ngOnInit() {
    this.http.get<any>('/api/v1/analytics').subscribe({
      next: (res) => {
        if (res.regionalDistribution) {
          this.regionalData.set(res.regionalDistribution);
        }
        if (res.qualityBreakdown) {
          this.qualityData.set(res.qualityBreakdown);
        }
      },
      error: (err) => console.error('Analytics fetch error:', err),
    });
  }
}
