import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RadioStateService } from '../services/radio-state';

@Component({
  selector: 'app-schedule-clock',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-[calc(100vh-57px)] bg-[#121417] text-[#EAE6DF] p-4 md:p-8 space-y-6">
      
      <!-- Title Bar -->
      <div class="bg-[#1C1F26] p-4 rounded-xl border border-[#282C35] flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 class="text-xl font-serif text-[#F4F1EA] flex items-center gap-2">
            <span class="material-icons text-[#3F6E50]">schedule</span>
            RADIO PROGRAMME CLOCK & INTELLIGENT SCHEDULER
          </h2>
          <p class="text-xs font-mono text-[#8E98A8]">
            HOURLY BROADCAST ROTATION & EDITORIAL RULE ENGINE
          </p>
        </div>

        <div class="flex items-center gap-2 bg-[#121417] p-1 rounded-lg border border-[#282C35]">
          <span class="text-xs font-mono text-[#8E98A8] px-2">ACTIVE CLOCK:</span>
          <span class="text-xs font-mono text-[#3F6E50] font-bold px-2">THE EVENING SESSION (FLAGSHIP 19:00)</span>
        </div>
      </div>

      <!-- Main Grid: Hourly Radial Clock vs Rotation Rules -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left: Hourly Radial Breakdown -->
        <div class="lg:col-span-6 bg-[#1C1F26] p-6 rounded-xl border border-[#282C35] space-y-4">
          <h3 class="text-sm font-mono text-[#8E98A8] tracking-widest uppercase flex items-center gap-2">
            <span class="material-icons text-sm text-[#3F6E50]">pie_chart</span>
            60-MINUTE BROADCAST WHEEL
          </h3>

          <div class="space-y-2">
            @for (segment of clockSegments; track segment.time) {
              <div class="flex items-center justify-between p-2.5 bg-[#121417] rounded-lg border border-[#282C35]">
                <div class="flex items-center gap-3">
                  <span class="font-mono text-xs text-[#3F6E50] font-bold">{{ segment.time }}</span>
                  <span
                    class="px-2 py-0.5 text-[10px] font-mono font-bold rounded"
                    [class.bg-[#3F6E50]]="segment.type === 'TRACK'"
                    [class.text-[#F4F1EA]]="segment.type === 'TRACK'"
                    [class.bg-[#E5B33A]]="segment.type === 'JINGLE'"
                    [class.text-[#121417]]="segment.type === 'JINGLE'"
                    [class.bg-[#D94042]]="segment.type === 'NEWS'"
                    [class.text-[#F4F1EA]]="segment.type === 'NEWS'"
                    [class.bg-[#4A5260]]="segment.type === 'PRESENTER' || segment.type === 'OPEN'"
                  >
                    {{ segment.type }}
                  </span>
                  <span class="text-xs font-semibold text-[#F4F1EA]">{{ segment.label }}</span>
                </div>
                <span class="text-xs font-mono text-[#8E98A8]">{{ segment.duration }}</span>
              </div>
            }
          </div>
        </div>

        <!-- Right: Intelligent Scheduler Rules Engine -->
        <div class="lg:col-span-6 bg-[#1C1F26] p-6 rounded-xl border border-[#282C35] space-y-5">
          <h3 class="text-sm font-mono text-[#8E98A8] tracking-widest uppercase flex items-center gap-2">
            <span class="material-icons text-sm text-[#E5B33A]">tune</span>
            ROTATION & SELECTION RULES
          </h3>

          <div class="space-y-3">
            @for (rule of rules; track rule.id) {
              <div class="p-3.5 bg-[#121417] rounded-lg border border-[#282C35] flex items-center justify-between">
                <div>
                  <h4 class="text-xs font-bold text-[#F4F1EA]">{{ rule.title }}</h4>
                  <p class="text-[11px] text-[#8E98A8] mt-0.5">{{ rule.description }}</p>
                </div>
                <button
                  (click)="toggleRule(rule.id)"
                  [class.bg-[#3F6E50]]="rule.enabled"
                  [class.text-[#F4F1EA]]="rule.enabled"
                  [class.bg-[#282C35]]="!rule.enabled"
                  [class.text-[#8E98A8]]="!rule.enabled"
                  class="px-3 py-1 text-xs font-mono font-semibold rounded transition-colors"
                >
                  {{ rule.enabled ? 'ACTIVE' : 'OFF' }}
                </button>
              </div>
            }
          </div>

          <div class="pt-2 border-t border-[#282C35] flex justify-between items-center text-xs font-mono text-[#8E98A8]">
            <span>AUTOMATED SCHEDULER: RUNNING</span>
            <span class="text-[#3F6E50]">✓ 24-HOUR RUNDOWN GENERATED</span>
          </div>
        </div>

      </div>

    </div>
  `,
})
export class ScheduleClockComponent {
  state = inject(RadioStateService);

  clockSegments = [
    { time: ':00', type: 'OPEN', label: 'THE EVENING SESSION OPEN', duration: '01:00' },
    { time: ':01', type: 'JINGLE', label: 'NORTHSTAR STATION ID', duration: '00:12' },
    { time: ':02', type: 'TRACK', label: 'STARBURSTER (FONTAINES D.C.)', duration: '03:41' },
    { time: ':06', type: 'PRESENTER', label: 'FREYA LINDQVIST INTRO & LINK', duration: '00:45' },
    { time: ':09', type: 'TRACK', label: 'A FOREST (THE CURE)', duration: '05:55' },
    { time: ':13', type: 'NEWS', label: 'NATIONAL HEADLINES & UK WEATHER', duration: '03:00' },
    { time: ':16', type: 'TRACK', label: 'TEARDROP (MASSIVE ATTACK)', duration: '05:30' },
    { time: ':20', type: 'COMMERCIAL', label: 'CULTURE & EXHIBITION TRAILERS', duration: '01:30' },
    { time: ':23', type: 'TRACK', label: 'ARCHANGEL (BURIAL)', duration: '03:58' },
    { time: ':27', type: 'JINGLE', label: 'NORTHSTAR STATION ID', duration: '00:08' },
  ];

  rules = [
    { id: 'r1', title: 'NO REPEATED ARTIST', description: 'Minimum 180 minutes spacing between tracks by the same artist.', enabled: true },
    { id: 'r2', title: 'NO REPEATED TRACK', description: 'Strict 24-hour separation before repeating any song title.', enabled: true },
    { id: 'r3', title: 'ERA BALANCE CONSTRAINT', description: 'Ensure 30% 1980s-90s, 30% 2000s-10s, 40% contemporary 2020s releases.', enabled: true },
    { id: 'r4', title: 'ENERGY CURVE FLOW', description: 'Construct a smooth energy progression (High -> Mid -> Low -> High).', enabled: true },
    { id: 'r5', title: 'TOP OF HOUR NEWS BOUNDARY', description: 'Hard stop precisely at :00 for national news bulletin.', enabled: true },
  ];

  toggleRule(id: string) {
    this.rules = this.rules.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r));
  }
}
