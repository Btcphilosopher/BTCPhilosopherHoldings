import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AudioEngineService } from '../services/audio-engine';

@Component({
  selector: 'app-mastering-loudness',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-[calc(100vh-57px)] bg-[#121417] text-[#EAE6DF] p-4 md:p-8 space-y-6">
      
      <!-- Title & Profile Selector -->
      <div class="bg-[#1C1F26] p-4 rounded-xl border border-[#282C35] flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 class="text-xl font-serif text-[#F4F1EA] flex items-center gap-2">
            <span class="material-icons text-[#3F6E50]">graphic_eq</span>
            EBU R 128 LOUDNESS & MASTERING ENGINE
          </h2>
          <p class="text-xs font-mono text-[#8E98A8]">
            BROADCAST DYNAMICS, SPECTRAL BALANCE & TRUE PEAK CONTROL
          </p>
        </div>

        <div class="flex items-center gap-2 bg-[#121417] p-1 rounded-lg border border-[#282C35]">
          <span class="text-xs font-mono text-[#8E98A8] px-2">TARGET STANDARD:</span>
          @for (p of profiles; track p.id) {
            <button
              (click)="selectedProfile.set(p.id)"
              [class.bg-[#3F6E50]]="selectedProfile() === p.id"
              [class.text-[#F4F1EA]]="selectedProfile() === p.id"
              class="px-2.5 py-1 text-xs font-mono text-[#8E98A8] hover:text-[#F4F1EA] rounded transition-colors"
            >
              {{ p.name }}
            </button>
          }
        </div>
      </div>

      <!-- Mastering Signal Chain Workflow -->
      <div class="bg-[#1C1F26] p-6 rounded-xl border border-[#282C35] space-y-4">
        <h3 class="text-xs font-mono text-[#8E98A8] tracking-widest uppercase">
          MASTERING SIGNAL PROCESSING CHAIN
        </h3>

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-6 gap-3 text-center">
          
          <div class="bg-[#121417] p-3 rounded-lg border border-[#282C35]">
            <span class="text-[10px] font-mono text-[#8E98A8] block">STAGE 01</span>
            <h4 class="text-xs font-bold text-[#F4F1EA] mt-1">INPUT STAGE</h4>
            <span class="text-[10px] font-mono text-[#3F6E50] block mt-1">ACTIVE (+0 dB)</span>
          </div>

          <div class="bg-[#121417] p-3 rounded-lg border border-[#282C35]">
            <span class="text-[10px] font-mono text-[#8E98A8] block">STAGE 02</span>
            <h4 class="text-xs font-bold text-[#F4F1EA] mt-1">PARAMETRIC EQ</h4>
            <span class="text-[10px] font-mono text-[#3F6E50] block mt-1">LINEAR PHASE</span>
          </div>

          <div class="bg-[#121417] p-3 rounded-lg border border-[#282C35]">
            <span class="text-[10px] font-mono text-[#8E98A8] block">STAGE 03</span>
            <h4 class="text-xs font-bold text-[#F4F1EA] mt-1">MULTIBAND COMP</h4>
            <span class="text-[10px] font-mono text-[#3F6E50] block mt-1">4-BAND RMS</span>
          </div>

          <div class="bg-[#121417] p-3 rounded-lg border border-[#282C35]">
            <span class="text-[10px] font-mono text-[#8E98A8] block">STAGE 04</span>
            <h4 class="text-xs font-bold text-[#F4F1EA] mt-1">LOUDNESS NORM</h4>
            <span class="text-[10px] font-mono text-[#3F6E50] block mt-1">-23.0 LUFS TARGET</span>
          </div>

          <div class="bg-[#121417] p-3 rounded-lg border border-[#282C35]">
            <span class="text-[10px] font-mono text-[#8E98A8] block">STAGE 05</span>
            <h4 class="text-xs font-bold text-[#F4F1EA] mt-1">TRUE PEAK LIMITER</h4>
            <span class="text-[10px] font-mono text-[#3F6E50] block mt-1">-1.0 dBFS CEILING</span>
          </div>

          <div class="bg-[#1E3A2B] p-3 rounded-lg border border-[#3F6E50]">
            <span class="text-[10px] font-mono text-[#3F6E50] block">STAGE 06</span>
            <h4 class="text-xs font-bold text-[#F4F1EA] mt-1">ENCODER FEED</h4>
            <span class="text-[10px] font-mono text-[#F4F1EA] block mt-1">256 kbps AAC-LC</span>
          </div>

        </div>
      </div>

      <!-- Real-Time Loudness Telemetry Gauge Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        
        <div class="bg-[#1C1F26] p-5 rounded-xl border border-[#282C35] space-y-2 text-center">
          <span class="text-xs font-mono text-[#8E98A8]">INTEGRATED LOUDNESS</span>
          <div class="text-4xl font-mono font-bold text-[#3F6E50]">
            {{ audio.loudnessLUFS() }}
          </div>
          <span class="text-xs font-mono text-[#8E98A8] block">LUFS (EBU R 128 TARGET: -23.0)</span>
          <div class="w-full h-2 bg-[#121417] rounded-full overflow-hidden mt-2">
            <div class="h-full bg-[#3F6E50] w-[77%]"></div>
          </div>
        </div>

        <div class="bg-[#1C1F26] p-5 rounded-xl border border-[#282C35] space-y-2 text-center">
          <span class="text-xs font-mono text-[#8E98A8]">SHORT-TERM LOUDNESS</span>
          <div class="text-4xl font-mono font-bold text-[#F4F1EA]">
            {{ audio.shortTermLUFS() }}
          </div>
          <span class="text-xs font-mono text-[#8E98A8] block">LUFS (3 SECOND WINDOW)</span>
          <div class="w-full h-2 bg-[#121417] rounded-full overflow-hidden mt-2">
            <div class="h-full bg-[#3F6E50] w-[80%]"></div>
          </div>
        </div>

        <div class="bg-[#1C1F26] p-5 rounded-xl border border-[#282C35] space-y-2 text-center">
          <span class="text-xs font-mono text-[#8E98A8]">TRUE PEAK LEVEL</span>
          <div class="text-4xl font-mono font-bold text-[#E5B33A]">
            {{ audio.truePeakdB() }}
          </div>
          <span class="text-xs font-mono text-[#8E98A8] block">dBFS (CEILING: -1.0 dBFS)</span>
          <div class="w-full h-2 bg-[#121417] rounded-full overflow-hidden mt-2">
            <div class="h-full bg-[#E5B33A] w-[90%]"></div>
          </div>
        </div>

        <div class="bg-[#1C1F26] p-5 rounded-xl border border-[#282C35] space-y-2 text-center">
          <span class="text-xs font-mono text-[#8E98A8]">LOUDNESS RANGE (LRA)</span>
          <div class="text-4xl font-mono font-bold text-[#F4F1EA]">
            5.8
          </div>
          <span class="text-xs font-mono text-[#8E98A8] block">LU (DYNAMIC RANGE SPREAD)</span>
          <div class="w-full h-2 bg-[#121417] rounded-full overflow-hidden mt-2">
            <div class="h-full bg-[#3F6E50] w-[55%]"></div>
          </div>
        </div>

      </div>

    </div>
  `,
})
export class MasteringLoudnessComponent {
  audio = inject(AudioEngineService);

  profiles = [
    { id: 'ebu-r128', name: 'EBU R 128 (-23 LUFS)' },
    { id: 'ebu-3401', name: 'EBU TECH 3401 RADIO' },
    { id: 'aes-td1004', name: 'AES WEB PODCAST (-16 LUFS)' },
  ];

  selectedProfile = signal('ebu-r128');
}
