import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AudioEngineService } from '../services/audio-engine';

@Component({
  selector: 'app-radio-desk-mixer',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-[calc(100vh-57px)] bg-[#121417] text-[#EAE6DF] p-4 md:p-8 space-y-6">
      
      <!-- Desk Title Bar -->
      <div class="bg-[#1C1F26] p-4 rounded-xl border border-[#282C35] flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 class="text-xl font-serif text-[#F4F1EA] flex items-center gap-2">
            <span class="material-icons text-[#3F6E50]">equalizer</span>
            NORTHSTAR DIGITAL BROADCAST CONSOLE
          </h2>
          <p class="text-xs font-mono text-[#8E98A8]">
            9-CHANNEL BROADCAST MIXER · EBU R 128 BUS PROCESSING
          </p>
        </div>

        <div class="flex items-center gap-4 text-xs font-mono">
          <div class="bg-[#121417] px-3 py-1.5 rounded border border-[#282C35] text-[#3F6E50]">
            MASTER LOUDNESS: {{ audio.loudnessLUFS() }} LUFS
          </div>
          <div class="bg-[#121417] px-3 py-1.5 rounded border border-[#282C35] text-[#F4F1EA]">
            LIMITER: ACTIVE (-1.0 dBFS)
          </div>
        </div>
      </div>

      <!-- Fader Channels Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 xl:grid-cols-9 gap-4 overflow-x-auto pb-4">
        
        @for (ch of audio.channels(); track ch.id) {
          <div
            class="bg-[#1C1F26] p-3.5 rounded-xl border border-[#282C35] flex flex-col justify-between space-y-3 min-w-[150px] shadow-lg"
            [class.border-[#3F6E50]]="!ch.mute && ch.gain > 0"
            [class.bg-[#1E3A2B]/10]="!ch.mute && ch.gain > 0"
          >
            <!-- Channel Header -->
            <div class="border-b border-[#282C35] pb-2 text-center">
              <span class="text-[10px] font-mono text-[#8E98A8] uppercase tracking-wider block">
                CH {{ $index + 1 }}
              </span>
              <h3 class="text-xs font-bold text-[#F4F1EA] truncate mt-0.5">
                {{ ch.name }}
              </h3>
            </div>

            <!-- Gain & High Pass Filter -->
            <div class="space-y-2 bg-[#121417] p-2 rounded border border-[#282C35] text-center">
              <div class="flex items-center justify-between text-[10px] font-mono text-[#8E98A8]">
                <span>HPF 80Hz</span>
                <button
                  (click)="toggleHPF(ch.id, ch.hpf)"
                  [class.bg-[#3F6E50]]="ch.hpf"
                  [class.text-[#F4F1EA]]="ch.hpf"
                  class="px-1.5 py-0.5 rounded text-[9px] font-mono border border-[#282C35]"
                >
                  {{ ch.hpf ? 'ON' : 'OFF' }}
                </button>
              </div>

              <!-- EQ 3-Band Control -->
              <div class="space-y-1 pt-1">
                <span class="text-[9px] font-mono text-[#8E98A8] block">3-BAND EQ</span>
                <div class="grid grid-cols-3 gap-1 text-[9px] font-mono">
                  <div class="bg-[#1C1F26] p-1 rounded">
                    <span class="text-[#8E98A8]">LOW</span>
                    <p class="text-[#F4F1EA] font-semibold">{{ ch.eqLow > 0 ? '+' : '' }}{{ ch.eqLow }}</p>
                  </div>
                  <div class="bg-[#1C1F26] p-1 rounded">
                    <span class="text-[#8E98A8]">MID</span>
                    <p class="text-[#F4F1EA] font-semibold">{{ ch.eqMid > 0 ? '+' : '' }}{{ ch.eqMid }}</p>
                  </div>
                  <div class="bg-[#1C1F26] p-1 rounded">
                    <span class="text-[#8E98A8]">HIGH</span>
                    <p class="text-[#F4F1EA] font-semibold">{{ ch.eqHigh > 0 ? '+' : '' }}{{ ch.eqHigh }}</p>
                  </div>
                </div>
              </div>
            </div>

            <!-- Compressor & Pan -->
            <div class="bg-[#121417] p-2 rounded border border-[#282C35] space-y-1.5 text-center text-[10px] font-mono">
              <div class="flex justify-between text-[#8E98A8]">
                <span>COMP THRESH</span>
                <span class="text-[#3F6E50]">{{ ch.compThreshold }} dB</span>
              </div>
              <div class="flex justify-between text-[#8E98A8]">
                <span>PAN</span>
                <span class="text-[#F4F1EA]">{{ ch.pan === 0 ? 'C' : (ch.pan < 0 ? 'L' + (-ch.pan*100) : 'R' + (ch.pan*100)) }}</span>
              </div>
            </div>

            <!-- Meter Display Bar -->
            <div class="h-28 bg-[#121417] rounded border border-[#282C35] flex items-end p-1 justify-center relative">
              <!-- Channel Meter Level -->
              <div
                class="w-4 rounded-sm transition-all duration-150"
                [style.height.%]="ch.mute ? 0 : ch.gain * 65 + (audio.isPlaying() ? 15 : 0)"
                [class.bg-[#3F6E50]]="ch.gain <= 1.0"
                [class.bg-[#E5B33A]]="ch.gain > 1.0"
              ></div>
              <div class="absolute inset-y-1 left-1 text-[8px] font-mono text-[#8E98A8] flex flex-col justify-between">
                <span>0</span>
                <span>-12</span>
                <span>-24</span>
                <span>-48</span>
              </div>
            </div>

            <!-- Channel Fader Slider -->
            <div class="space-y-1">
              <div class="flex justify-between text-[10px] font-mono text-[#8E98A8]">
                <span>FADER</span>
                <span class="text-[#F4F1EA] font-bold">{{ Math.round(ch.gain * 100) }}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1.5"
                step="0.05"
                [value]="ch.gain"
                (input)="onGainChange(ch.id, $event)"
                class="w-full h-2 bg-[#121417] rounded-lg appearance-none cursor-pointer accent-[#3F6E50]"
              />
            </div>

            <!-- MUTE & SOLO buttons -->
            <div class="grid grid-cols-2 gap-1.5">
              <button
                (click)="toggleMute(ch.id, ch.mute)"
                [class.bg-[#8B2628]]="ch.mute"
                [class.text-[#F4F1EA]]="ch.mute"
                [class.bg-[#121417]]="!ch.mute"
                [class.text-[#8E98A8]]="!ch.mute"
                class="py-1.5 text-[10px] font-mono font-bold rounded border border-[#282C35] transition-colors"
              >
                MUTE
              </button>
              <button
                (click)="toggleSolo(ch.id, ch.solo)"
                [class.bg-[#C69214]]="ch.solo"
                [class.text-[#121417]]="ch.solo"
                [class.bg-[#121417]]="!ch.solo"
                [class.text-[#8E98A8]]="!ch.solo"
                class="py-1.5 text-[10px] font-mono font-bold rounded border border-[#282C35] transition-colors"
              >
                SOLO
              </button>
            </div>

          </div>
        }

      </div>

      <!-- Master Output Processing Channel -->
      <div class="bg-[#1C1F26] p-5 rounded-xl border border-[#282C35] grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
        <div>
          <h3 class="text-sm font-mono text-[#3F6E50] tracking-widest uppercase">
            PROGRAMME MASTER BUS
          </h3>
          <p class="text-xs text-[#8E98A8] mt-1">
            EBU R 128 Loudness Processing · True Peak Limiter @ -1.0 dBFS
          </p>
        </div>

        <!-- Master Volume Control -->
        <div class="space-y-1">
          <div class="flex justify-between text-xs font-mono text-[#8E98A8]">
            <span>MASTER GAIN</span>
            <span class="text-[#F4F1EA] font-bold">85%</span>
          </div>
          <input
            type="range"
            min="0"
            max="1.5"
            step="0.05"
            value="0.85"
            (input)="onMasterGainChange($event)"
            class="w-full h-2.5 bg-[#121417] rounded-lg appearance-none cursor-pointer accent-[#3F6E50]"
          />
        </div>

        <div class="flex items-center justify-end gap-3">
          <button
            (click)="audio.playSyntheticRadioStream()"
            class="px-4 py-2 bg-[#1E3A2B] hover:bg-[#2E523C] text-[#F4F1EA] text-xs font-mono font-bold rounded border border-[#3F6E50]"
          >
            TEST MASTER BUS
          </button>
        </div>
      </div>

    </div>
  `,
})
export class RadioDeskMixerComponent {
  audio = inject(AudioEngineService);
  Math = Math;

  toggleHPF(id: string, current: boolean) {
    this.audio.updateChannel(id, { hpf: !current });
  }

  toggleMute(id: string, current: boolean) {
    this.audio.updateChannel(id, { mute: !current });
  }

  toggleSolo(id: string, current: boolean) {
    this.audio.updateChannel(id, { solo: !current });
  }

  onGainChange(id: string, e: Event) {
    const val = parseFloat((e.target as HTMLInputElement).value);
    this.audio.updateChannel(id, { gain: val });
  }

  onMasterGainChange(e: Event) {
    const val = parseFloat((e.target as HTMLInputElement).value);
    this.audio.setMasterVolume(val);
  }
}
