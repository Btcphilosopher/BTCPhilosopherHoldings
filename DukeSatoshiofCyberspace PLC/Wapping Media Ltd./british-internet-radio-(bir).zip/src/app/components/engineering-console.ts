import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AudioEngineService } from '../services/audio-engine';

@Component({
  selector: 'app-engineering-console',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-[calc(100vh-57px)] bg-[#121417] text-[#EAE6DF] p-4 md:p-8 space-y-6">
      
      <!-- Engineering Title Bar -->
      <div class="bg-[#1C1F26] p-4 rounded-xl border border-[#282C35] flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 class="text-xl font-serif text-[#F4F1EA] flex items-center gap-2">
            <span class="material-icons text-[#3F6E50]">settings_applications</span>
            ENGINEERING & STREAM INFRASTRUCTURE CONSOLE
          </h2>
          <p class="text-xs font-mono text-[#8E98A8]">
            STUDIO ORIGIN · AAC/FLAC ENCODER MATRIX · CDN DELIVERY TOPOLOGY
          </p>
        </div>

        <div class="flex items-center gap-3">
          <button
            (click)="testFailover()"
            class="px-3.5 py-1.5 bg-[#8B2628] hover:bg-[#D94042] text-[#F4F1EA] text-xs font-mono font-bold rounded border border-[#D94042] transition-colors"
          >
            SIMULATE PRIMARY ENCODER FAILURE
          </button>
        </div>
      </div>

      <!-- Infrastructure Network Topology Flow -->
      <div class="bg-[#1C1F26] p-6 rounded-xl border border-[#282C35] space-y-4">
        <h3 class="text-xs font-mono text-[#8E98A8] tracking-widest uppercase">
          BROADCAST PIPELINE TOPOLOGY & HEALTH
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-5 gap-4 items-center text-center font-mono text-xs">
          
          <div class="bg-[#121417] p-4 rounded-lg border border-[#3F6E50]">
            <span class="text-[#3F6E50] font-bold block text-[10px]">STAGE 01</span>
            <h4 class="text-sm font-bold text-[#F4F1EA] mt-1">LONDON STUDIO A</h4>
            <span class="text-[#8E98A8] block mt-1">MIC & PLAYOUT BUS</span>
            <span class="text-[#3F6E50] block mt-2">● LATENCY: 0.1 ms</span>
          </div>

          <div class="hidden md:block text-[#3F6E50]">➔</div>

          <div class="bg-[#121417] p-4 rounded-lg border" [class.border-[#3F6E50]]="!primaryFailed()" [class.border-[#D94042]]="primaryFailed()">
            <span class="font-bold block text-[10px]" [class.text-[#3F6E50]]="!primaryFailed()" [class.text-[#D94042]]="primaryFailed()">STAGE 02</span>
            <h4 class="text-sm font-bold text-[#F4F1EA] mt-1">PRIMARY ENCODER</h4>
            <span class="text-[#8E98A8] block mt-1">AAC-LC 256kbps 48kHz</span>
            <span class="block mt-2 font-bold" [class.text-[#3F6E50]]="!primaryFailed()" [class.text-[#D94042]]="primaryFailed()">
              {{ primaryFailed() ? '✖ FAILED (FAILOVER)' : '● HEALTHY (ACTIVE)' }}
            </span>
          </div>

          <div class="hidden md:block text-[#3F6E50]">➔</div>

          <div class="bg-[#121417] p-4 rounded-lg border border-[#3F6E50]">
            <span class="text-[#3F6E50] font-bold block text-[10px]">STAGE 03</span>
            <h4 class="text-sm font-bold text-[#F4F1EA] mt-1">UK CDN EDGE</h4>
            <span class="text-[#8E98A8] block mt-1">LONDON / MANCHESTER</span>
            <span class="text-[#3F6E50] block mt-2">● 18,421 CLIENTS</span>
          </div>

        </div>
      </div>

      <!-- Telemetry Cards & QC Results -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <div class="bg-[#1C1F26] p-5 rounded-xl border border-[#282C35] space-y-3">
          <h3 class="text-xs font-mono text-[#8E98A8]">ENCODER TELEMETRY</h3>
          <div class="space-y-2 text-xs font-mono">
            <div class="flex justify-between">
              <span class="text-[#8E98A8]">BITRATE:</span>
              <span class="text-[#F4F1EA] font-bold">256.4 kbps</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#8E98A8]">BUFFER AGE:</span>
              <span class="text-[#F4F1EA]">120 ms</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#8E98A8]">CPU LOAD:</span>
              <span class="text-[#3F6E50]">14.2%</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#8E98A8]">PACKET LOSS:</span>
              <span class="text-[#3F6E50]">0.00%</span>
            </div>
          </div>
        </div>

        <div class="bg-[#1C1F26] p-5 rounded-xl border border-[#282C35] space-y-3">
          <h3 class="text-xs font-mono text-[#8E98A8]">QUALITY CONTROL (QC) VALIDATOR</h3>
          <div class="space-y-2 text-xs font-mono">
            <div class="flex justify-between">
              <span class="text-[#8E98A8]">SAMPLE RATE:</span>
              <span class="text-[#3F6E50] font-bold">✓ 48.0 kHz PASS</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#8E98A8]">SILENCE DETECTOR:</span>
              <span class="text-[#3F6E50] font-bold">✓ NO DROP PASS</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#8E98A8]">EBU LOUDNESS:</span>
              <span class="text-[#3F6E50] font-bold">✓ -23 LUFS PASS</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#8E98A8]">TRUE PEAK CEILING:</span>
              <span class="text-[#3F6E50] font-bold">✓ -1.0 dBFS PASS</span>
            </div>
          </div>
        </div>

        <div class="bg-[#1C1F26] p-5 rounded-xl border border-[#282C35] space-y-3">
          <h3 class="text-xs font-mono text-[#8E98A8]">REDUNDANCY STATUS</h3>
          <div class="space-y-2 text-xs font-mono">
            <div class="flex justify-between">
              <span class="text-[#8E98A8]">SECONDARY ORIGIN:</span>
              <span class="text-[#E5B33A]">STANDBY (HOT)</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#8E98A8]">EMERGENCY LOOP:</span>
              <span class="text-[#3F6E50]">READY</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#8E98A8]">AUTOSWITCH TIME:</span>
              <span class="text-[#F4F1EA]">250 ms</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  `,
})
export class EngineeringConsoleComponent {
  audio = inject(AudioEngineService);
  primaryFailed = signal(false);

  testFailover() {
    this.primaryFailed.set(true);
    this.audio.triggerEmergencyFailover();

    setTimeout(() => {
      this.primaryFailed.set(false);
      this.audio.resolveEmergencyFailover();
    }, 6000);
  }
}
