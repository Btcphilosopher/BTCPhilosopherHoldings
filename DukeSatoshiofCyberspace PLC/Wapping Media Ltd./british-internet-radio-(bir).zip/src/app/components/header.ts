import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RadioStateService } from '../services/radio-state';
import { AudioEngineService } from '../services/audio-engine';

@Component({
  selector: 'app-header',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="w-full bg-[#121417] border-b border-[#282C35] px-4 md:px-8 py-3.5 flex items-center justify-between select-none z-50">
      <!-- Zone 1: Single text element wordmark -->
      <div class="flex items-center gap-4">
        <a 
          (click)="state.setView('PUBLIC_PLAYER')" 
          class="cursor-pointer text-lg font-extrabold tracking-widest text-[#F4F1EA] hover:text-[#3F6E50] transition-colors flex items-center gap-2.5"
        >
          <span class="w-2.5 h-2.5 rounded-full bg-[#3F6E50] animate-meter-pulse"></span>
          NORTHSTAR<span class="font-light text-[#8E98A8]">RADIO</span>
        </a>
        <span class="hidden lg:inline-block text-xs font-mono text-[#8E98A8] border-l border-[#282C35] pl-4">
          BIR OPERATING SYSTEM v3.6
        </span>
      </div>

      <!-- Zone 2: Navigation Links -->
      <nav class="hidden md:flex items-center gap-1 bg-[#1C1F26] p-1 rounded-lg border border-[#282C35]">
        <button
          (click)="state.setView('PUBLIC_PLAYER')"
          [class.bg-[#282C35]]="state.activeView() === 'PUBLIC_PLAYER'"
          [class.text-[#F4F1EA]]="state.activeView() === 'PUBLIC_PLAYER'"
          class="px-3 py-1.5 text-xs font-medium text-[#8E98A8] hover:text-[#F4F1EA] rounded transition-colors whitespace-nowrap"
        >
          LISTEN LIVE
        </button>
        <button
          (click)="state.setView('CONTROL_ROOM')"
          [class.bg-[#282C35]]="state.activeView() === 'CONTROL_ROOM'"
          [class.text-[#F4F1EA]]="state.activeView() === 'CONTROL_ROOM'"
          class="px-3 py-1.5 text-xs font-medium text-[#8E98A8] hover:text-[#F4F1EA] rounded transition-colors whitespace-nowrap flex items-center gap-1.5"
        >
          <span class="w-1.5 h-1.5 rounded-full bg-[#3F6E50]"></span>
          ON-AIR DESK
        </button>
        <button
          (click)="state.setView('MIXER')"
          [class.bg-[#282C35]]="state.activeView() === 'MIXER'"
          [class.text-[#F4F1EA]]="state.activeView() === 'MIXER'"
          class="px-3 py-1.5 text-xs font-medium text-[#8E98A8] hover:text-[#F4F1EA] rounded transition-colors whitespace-nowrap"
        >
          MIXER
        </button>
        <button
          (click)="state.setView('LIBRARY')"
          [class.bg-[#282C35]]="state.activeView() === 'LIBRARY'"
          [class.text-[#F4F1EA]]="state.activeView() === 'LIBRARY'"
          class="px-3 py-1.5 text-xs font-medium text-[#8E98A8] hover:text-[#F4F1EA] rounded transition-colors whitespace-nowrap"
        >
          LIBRARY
        </button>
        <button
          (click)="state.setView('SCHEDULE')"
          [class.bg-[#282C35]]="state.activeView() === 'SCHEDULE'"
          [class.text-[#F4F1EA]]="state.activeView() === 'SCHEDULE'"
          class="px-3 py-1.5 text-xs font-medium text-[#8E98A8] hover:text-[#F4F1EA] rounded transition-colors whitespace-nowrap"
        >
          SCHEDULE
        </button>
        <button
          (click)="state.setView('PRESENTER')"
          [class.bg-[#282C35]]="state.activeView() === 'PRESENTER'"
          [class.text-[#F4F1EA]]="state.activeView() === 'PRESENTER'"
          class="px-3 py-1.5 text-xs font-medium text-[#8E98A8] hover:text-[#F4F1EA] rounded transition-colors whitespace-nowrap"
        >
          PRESENTER
        </button>
        <button
          (click)="state.setView('ENGINEERING')"
          [class.bg-[#282C35]]="state.activeView() === 'ENGINEERING'"
          [class.text-[#F4F1EA]]="state.activeView() === 'ENGINEERING'"
          class="px-3 py-1.5 text-xs font-medium text-[#8E98A8] hover:text-[#F4F1EA] rounded transition-colors whitespace-nowrap"
        >
          ENGINEERING
        </button>
        <button
          (click)="state.setView('ANALYTICS')"
          [class.bg-[#282C35]]="state.activeView() === 'ANALYTICS'"
          [class.text-[#F4F1EA]]="state.activeView() === 'ANALYTICS'"
          class="px-3 py-1.5 text-xs font-medium text-[#8E98A8] hover:text-[#F4F1EA] rounded transition-colors whitespace-nowrap"
        >
          ANALYTICS
        </button>
      </nav>

      <!-- Zone 3: Primary Action -->
      <div class="flex items-center gap-3">
        <div class="hidden sm:flex items-center gap-2 text-[11px] font-mono text-[#8E98A8] bg-[#1C1F26] px-2.5 py-1 rounded border border-[#282C35]">
          <span class="text-[#3F6E50]">● {{ audio.loudnessLUFS() }} LUFS</span>
          <span>·</span>
          <span>{{ state.listenerCount() | number }} LISTENERS</span>
        </div>

        <button
          (click)="state.setView(state.activeView() === 'PUBLIC_PLAYER' ? 'CONTROL_ROOM' : 'PUBLIC_PLAYER')"
          class="px-3.5 py-2 text-xs font-semibold tracking-wider text-[#F4F1EA] bg-[#1E3A2B] hover:bg-[#2E523C] border border-[#3F6E50] rounded-md transition-colors whitespace-nowrap flex items-center gap-2"
        >
          <span class="material-icons text-sm text-[#3F6E50]">
            {{ state.activeView() === 'PUBLIC_PLAYER' ? 'tune' : 'radio' }}
          </span>
          {{ state.activeView() === 'PUBLIC_PLAYER' ? 'CONTROL ROOM' : 'PUBLIC PLAYER' }}
        </button>
      </div>
    </header>
  `,
})
export class HeaderComponent {
  state = inject(RadioStateService);
  audio = inject(AudioEngineService);
}
