import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RadioStateService } from './services/radio-state';
import { HeaderComponent } from './components/header';
import { PublicPlayerComponent } from './components/public-player';
import { ControlRoomComponent } from './components/control-room';
import { RadioDeskMixerComponent } from './components/radio-desk-mixer';
import { MasteringLoudnessComponent } from './components/mastering-loudness';
import { ScheduleClockComponent } from './components/schedule-clock';
import { MusicLibraryComponent } from './components/music-library';
import { PresenterConsoleComponent } from './components/presenter-console';
import { EngineeringConsoleComponent } from './components/engineering-console';
import { AnalyticsViewComponent } from './components/analytics-view';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    HeaderComponent,
    PublicPlayerComponent,
    ControlRoomComponent,
    RadioDeskMixerComponent,
    MasteringLoudnessComponent,
    ScheduleClockComponent,
    MusicLibraryComponent,
    PresenterConsoleComponent,
    EngineeringConsoleComponent,
    AnalyticsViewComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  state = inject(RadioStateService);
}
