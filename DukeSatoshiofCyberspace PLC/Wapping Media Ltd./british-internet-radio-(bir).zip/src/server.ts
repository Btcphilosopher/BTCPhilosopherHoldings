import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Initialize Gemini 3.6 AI SDK on server side
const ai = new GoogleGenAI({
  apiKey: process.env['GEMINI_API_KEY'] || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Mock Database for NORTHSTAR RADIO (BIR)
const STATIONS = [
  {
    id: 'northstar-main',
    name: 'NORTHSTAR RADIO MAIN',
    tagline: 'BRITAIN, IN SOUND.',
    genre: 'Eclectic British Music & Culture',
    bitrate: '256 kbps AAC-LC',
    listeners: 18421,
    status: 'ONLINE',
    loudness: -23.1,
    truePeak: -1.0,
  },
  {
    id: 'northstar-classical',
    name: 'NORTHSTAR CLASSICAL',
    tagline: 'BRITISH ORCHESTRAL & CONTEMPORARY CLASSICAL',
    genre: 'Classical & Film Scores',
    bitrate: '320 kbps FLAC',
    listeners: 6210,
    status: 'ONLINE',
    loudness: -24.0,
    truePeak: -1.2,
  },
  {
    id: 'northstar-night',
    name: 'NORTHSTAR NIGHT',
    tagline: 'AMBIENT, ELECTRONIC & DOWNTEMPO',
    genre: 'Ambient & Deep Electronic',
    bitrate: '256 kbps AAC-LC',
    listeners: 4890,
    status: 'ONLINE',
    loudness: -23.5,
    truePeak: -1.0,
  },
  {
    id: 'northstar-news',
    name: 'NORTHSTAR NEWS & TALK',
    tagline: 'NATIONAL BROADCASTS, DESPATCHES & ANALYSIS',
    genre: 'News & Culture',
    bitrate: '128 kbps AAC-LC',
    listeners: 3120,
    status: 'ONLINE',
    loudness: -22.8,
    truePeak: -0.8,
  },
];

const MUSIC_LIBRARY = [
  {
    id: 'trk-001',
    title: 'A Forest',
    artist: 'The Cure',
    album: 'Seventeen Seconds',
    duration: 355,
    genre: 'Post-Punk / British Rock',
    year: 1980,
    bpm: 128,
    key: 'A minor',
    integratedLUFS: -23.1,
    shortTermLUFS: -22.4,
    truePeak: -1.0,
    lra: 5.8,
    measured: true,
    energy: 0.78,
    category: 'music',
    artwork: '/assets/images/album_evening_session_1790598678631.jpg',
  },
  {
    id: 'trk-002',
    title: 'Everything In Its Right Place',
    artist: 'Radiohead',
    album: 'Kid A',
    duration: 251,
    genre: 'Experimental / Electronic',
    year: 2000,
    bpm: 124,
    key: 'F major',
    integratedLUFS: -22.8,
    shortTermLUFS: -22.0,
    truePeak: -0.9,
    lra: 6.2,
    measured: true,
    energy: 0.65,
    category: 'music',
    artwork: '/assets/images/album_night_music_1790598690194.jpg',
  },
  {
    id: 'trk-003',
    title: 'Teardrop',
    artist: 'Massive Attack',
    album: 'Mezzanine',
    duration: 330,
    genre: 'Trip Hop / Bristol Sound',
    year: 1998,
    bpm: 77,
    key: 'A major',
    integratedLUFS: -23.4,
    shortTermLUFS: -23.0,
    truePeak: -1.2,
    lra: 4.5,
    measured: true,
    energy: 0.52,
    category: 'music',
    artwork: '/assets/images/album_morning_edition_1790598702041.jpg',
  },
  {
    id: 'trk-004',
    title: 'Archangel',
    artist: 'Burial',
    album: 'Untrue',
    duration: 238,
    genre: 'Future Garage / South London',
    year: 2007,
    bpm: 135,
    key: 'C minor',
    integratedLUFS: -23.0,
    shortTermLUFS: -22.1,
    truePeak: -1.1,
    lra: 5.0,
    measured: true,
    energy: 0.70,
    category: 'music',
    artwork: '/assets/images/album_night_music_1790598690194.jpg',
  },
  {
    id: 'trk-005',
    title: 'Metal & Dust',
    artist: 'London Grammar',
    album: 'If You Wait',
    duration: 208,
    genre: 'Indie Pop / Vocal',
    year: 2013,
    bpm: 120,
    key: 'G minor',
    integratedLUFS: -22.9,
    shortTermLUFS: -21.8,
    truePeak: -0.8,
    lra: 7.1,
    measured: true,
    energy: 0.60,
    category: 'music',
    artwork: '/assets/images/album_evening_session_1790598678631.jpg',
  },
  {
    id: 'trk-006',
    title: 'Starburster',
    artist: 'Fontaines D.C.',
    album: 'Romance',
    duration: 221,
    genre: 'Post-Punk / Alternative',
    year: 2024,
    bpm: 104,
    key: 'D minor',
    integratedLUFS: -22.6,
    shortTermLUFS: -21.5,
    truePeak: -0.7,
    lra: 6.8,
    measured: true,
    energy: 0.88,
    category: 'music',
    artwork: '/assets/images/album_evening_session_1790598678631.jpg',
  },
  {
    id: 'trk-007',
    title: 'Avril 14th',
    artist: 'Aphex Twin',
    album: 'Drukqs',
    duration: 125,
    genre: 'Modern Classical / Ambient',
    year: 2001,
    bpm: 80,
    key: 'A-flat major',
    integratedLUFS: -24.2,
    shortTermLUFS: -23.8,
    truePeak: -1.5,
    lra: 8.0,
    measured: true,
    energy: 0.35,
    category: 'music',
    artwork: '/assets/images/album_night_music_1790598690194.jpg',
  },
  {
    id: 'jng-001',
    title: 'Northstar Station Identification (Top of Hour)',
    artist: 'Northstar Audio Engineering',
    album: 'Station Imaging Vol. 1',
    duration: 12,
    genre: 'Station Imaging',
    year: 2026,
    bpm: 120,
    key: 'E minor',
    integratedLUFS: -23.0,
    shortTermLUFS: -22.8,
    truePeak: -1.0,
    lra: 2.1,
    measured: true,
    energy: 0.90,
    category: 'jingle',
    artwork: '/assets/images/northstar_station_hero_1790598668323.jpg',
  },
  {
    id: 'jng-002',
    title: 'The Evening Session Sweeper',
    artist: 'Northstar Audio Engineering',
    album: 'Station Imaging Vol. 1',
    duration: 8,
    genre: 'Station Sweeper',
    year: 2026,
    bpm: 124,
    key: 'A minor',
    integratedLUFS: -23.0,
    shortTermLUFS: -22.5,
    truePeak: -1.0,
    lra: 1.8,
    measured: true,
    energy: 0.85,
    category: 'sweeper',
    artwork: '/assets/images/northstar_station_hero_1790598668323.jpg',
  },
];

const SHOWS = [
  {
    id: 'show-breakfast',
    title: 'NORTHSTAR BREAKFAST',
    presenter: 'Gideon Vance',
    time: '06:00 – 09:00',
    description: 'National awakening with new British music, headlines, culture and weather reports.',
    image: '/assets/images/album_morning_edition_1790598702041.jpg',
  },
  {
    id: 'show-morning',
    title: 'THE MORNING EDITION',
    presenter: 'Clara Higgins',
    time: '09:00 – 12:00',
    description: 'In-depth music journalism, acoustic sessions and deep discography cuts.',
    image: '/assets/images/album_morning_edition_1790598702041.jpg',
  },
  {
    id: 'show-afternoon',
    title: 'LONDON AFTERNOON',
    presenter: 'Marcus Thorne',
    time: '12:00 – 15:00',
    description: 'Electronic, dub, synth, and modern soul curated from London studios.',
    image: '/assets/images/album_evening_session_1790598678631.jpg',
  },
  {
    id: 'show-evening',
    title: 'THE EVENING SESSION',
    presenter: 'Freya Lindqvist',
    time: '19:00 – 22:00',
    description: 'The flagship broadcast: new releases, live studio sessions and exclusive interviews.',
    image: '/assets/images/album_evening_session_1790598678631.jpg',
  },
  {
    id: 'show-night',
    title: 'NIGHT MUSIC',
    presenter: 'Dominic Vance',
    time: '22:00 – 02:00',
    description: 'Immersive soundscapes, deep ambient, tape loops and nocturnal explorations.',
    image: '/assets/images/album_night_music_1790598690194.jpg',
  },
];

// Listener Requests Queue
const LISTENER_REQUESTS = [
  {
    id: 'req-101',
    songTitle: 'Glory Box',
    artist: 'Portishead',
    requesterName: 'Alastair from Bristol',
    message: 'For the drive through the Clifton Suspension Bridge tonight.',
    timestamp: '19:24',
    status: 'pending',
  },
  {
    id: 'req-102',
    songTitle: 'Starburster',
    artist: 'Fontaines D.C.',
    requesterName: 'Sian from Cardiff',
    message: 'Play it loud for the night shift crew in the workshop!',
    timestamp: '19:38',
    status: 'approved',
  },
  {
    id: 'req-103',
    songTitle: 'Avril 14th',
    artist: 'Aphex Twin',
    requesterName: 'Eleanor from Edinburgh',
    message: 'A moment of calm while watching the rain over Arthur Seat.',
    timestamp: '19:42',
    status: 'approved',
  },
];

// API ROUTE: Now Playing
app.get('/api/v1/now-playing', (req, res) => {
  const currentTrack = MUSIC_LIBRARY[0];
  const nextTrack = MUSIC_LIBRARY[7]; // Station ID

  res.json({
    station: STATIONS[0],
    currentProgram: {
      title: 'THE EVENING SESSION',
      presenter: 'Freya Lindqvist',
      startTime: '19:00',
      endTime: '22:00',
      energyLevel: 'HIGH',
    },
    nowPlaying: {
      ...currentTrack,
      elapsedSeconds: 142,
      totalSeconds: currentTrack.duration,
      percentage: Math.round((142 / currentTrack.duration) * 100),
    },
    next: {
      type: 'STATION_ID',
      title: nextTrack.title,
      artist: nextTrack.artist,
      duration: 12,
    },
    following: {
      type: 'PRESENTER_LINK',
      title: 'Freya Lindqvist — Session Links',
      artist: 'Live Studio Mic 1',
      duration: 45,
    },
    telemetry: {
      status: 'ONLINE',
      encoderHealth: 'HEALTHY',
      loudnessLUFS: -23.1,
      shortTermLUFS: -22.4,
      truePeakdBFS: -1.0,
      lraDB: 5.8,
      bitrateKbps: 256,
      codec: 'AAC-LC / 48kHz / Stereo',
      latencySeconds: 4.8,
      listenersCount: 18421,
      activeEncoders: ['primary-london-01', 'secondary-manchester-02'],
      failoverMode: 'AUTOMATED_PRIMARY',
    },
  });
});

// API ROUTE: Schedule
app.get('/api/v1/schedule', (req, res) => {
  res.json({
    date: '2026-09-28',
    station: 'NORTHSTAR RADIO MAIN',
    shows: SHOWS,
    rundown: [
      { time: '19:00:00', type: 'SHOW_OPEN', title: 'The Evening Session Intro', source: 'PLAYOUT_A' },
      { time: '19:01:15', type: 'TRACK', title: 'Starburster', artist: 'Fontaines D.C.', duration: 221 },
      { time: '19:04:56', type: 'JINGLE', title: 'Northstar ID - Evening', duration: 8 },
      { time: '19:05:04', type: 'PRESENTER', title: 'Freya Link & Request Shoutout', duration: 42 },
      { time: '19:05:46', type: 'TRACK', title: 'A Forest', artist: 'The Cure', duration: 355 },
      { time: '19:11:41', type: 'TRACK', title: 'Teardrop', artist: 'Massive Attack', duration: 330 },
      { time: '19:17:11', type: 'NEWS_BULLETIN', title: 'Northstar 7PM News & UK Weather', duration: 180 },
    ],
  });
});

// API ROUTE: Stations
app.get('/api/v1/stations', (req, res) => {
  res.json({ stations: STATIONS });
});

// API ROUTE: Library / Tracks
app.get('/api/v1/tracks', (req, res) => {
  const { category, search } = req.query;
  let tracks = [...MUSIC_LIBRARY];

  if (category && typeof category === 'string') {
    tracks = tracks.filter((t) => t.category === category);
  }
  if (search && typeof search === 'string') {
    const q = search.toLowerCase();
    tracks = tracks.filter(
      (t) => t.title.toLowerCase().includes(q) || t.artist.toLowerCase().includes(q)
    );
  }

  res.json({ tracks, total: tracks.length });
});

// API ROUTE: Stream Status & Telemetry
app.get('/api/v1/stream/status', (req, res) => {
  res.json({
    primaryEncoder: { name: 'London Studio Origin 01', status: 'HEALTHY', cpu: 14.2, memMB: 480, fps: 50 },
    secondaryEncoder: { name: 'Manchester Backup Origin 02', status: 'STANDBY', cpu: 8.1, memMB: 310, fps: 50 },
    cdnEndpoints: [
      { location: 'London (UK-South)', activeConnections: 11200, status: 'OPTIMAL', latencyMs: 14 },
      { location: 'Manchester (UK-North)', activeConnections: 4810, status: 'OPTIMAL', latencyMs: 18 },
      { location: 'Edinburgh (UK-Scotland)', activeConnections: 2411, status: 'OPTIMAL', latencyMs: 22 },
    ],
    loudnessProfile: {
      targetIntegratedLUFS: -23.0,
      targetTruePeakdBFS: -1.0,
      standard: 'EBU R 128 / EBU Tech 3401',
    },
  });
});

// API ROUTE: Analytics
app.get('/api/v1/analytics', (req, res) => {
  res.json({
    activeListeners: 18421,
    peakToday: 24190,
    avgSessionMinutes: 48.5,
    regionalDistribution: [
      { city: 'London & Home Counties', percentage: 42, listeners: 7736 },
      { city: 'Greater Manchester & North West', percentage: 18, listeners: 3315 },
      { city: 'Edinburgh & Glasgow', percentage: 14, listeners: 2578 },
      { city: 'Midlands (Birmingham)', percentage: 11, listeners: 2026 },
      { city: 'Wales & South West (Cardiff/Bristol)', percentage: 9, listeners: 1657 },
      { city: 'Northern Ireland (Belfast)', percentage: 6, listeners: 1105 },
    ],
    qualityBreakdown: [
      { profile: 'HQ (256kbps AAC-LC)', percentage: 62 },
      { profile: 'Standard (128kbps AAC-LC)', percentage: 25 },
      { profile: 'Lossless (FLAC)', percentage: 8 },
      { profile: 'Mobile (64kbps HE-AAC)', percentage: 5 },
    ],
  });
});

// API ROUTE: Requests & Moderation
app.get('/api/v1/requests', (req, res) => {
  res.json({ requests: LISTENER_REQUESTS });
});

app.post('/api/v1/requests', (req, res) => {
  const { songTitle, artist, requesterName, message } = req.body;
  const newReq = {
    id: `req-${Date.now()}`,
    songTitle: songTitle || 'Untitled Track',
    artist: artist || 'Unknown Artist',
    requesterName: requesterName || 'Anonymous Listener',
    message: message || '',
    timestamp: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
    status: 'pending',
  };
  LISTENER_REQUESTS.unshift(newReq);
  res.json({ success: true, request: newReq });
});

app.post('/api/v1/requests/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const reqItem = LISTENER_REQUESTS.find((r) => r.id === id);
  if (reqItem) {
    reqItem.status = status;
    res.json({ success: true, request: reqItem });
  } else {
    res.status(404).json({ error: 'Request not found' });
  }
});

// API ROUTE: Gemini Script Generator
app.post('/api/v1/gemini/generate-script', async (req, res) => {
  try {
    const { type, topic, presenterName } = req.body;
    const presenter = presenterName || 'Freya Lindqvist';

    let prompt = '';
    if (type === 'WEATHER') {
      prompt = `Write a succinct 30-second British radio weather bulletin for Northstar Radio presented by ${presenter}. Include realistic forecast details for London, Manchester, Edinburgh, Cardiff, and Belfast. Professional, cultured, authoritative British tone. Plain text formatted for reading on air.`;
    } else if (type === 'NEWS') {
      prompt = `Write a 60-second national British news bulletin for Northstar Radio. Top story on UK tech innovation, music culture, and UK transport infrastructure. Clear, concise, authoritative BBC-style tone.`;
    } else if (type === 'TRAFFIC') {
      prompt = `Write a 30-second UK traffic and travel report for Northstar Radio covering the M25, M6, M8 near Glasgow and A1(M). Professional, broadcast-ready tone.`;
    } else {
      prompt = `Write an engaging 20-second radio presenter back-sell for track "${topic || 'A Forest by The Cure'}" on Northstar Radio presented by ${presenter}. Mentions Britain in Sound and upcoming music.`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are the head scriptwriter for Northstar Radio, Britain in Sound. Your writing is cultured, articulate, distinctly British, restrained, and broadcast-ready.',
      },
    });

    res.json({
      script: response.text || 'Broadcast script unavailable.',
      presenter,
      type,
    });
  } catch (err: any) {
    console.error('Gemini script generation error:', err);
    res.status(500).json({ error: err.message || 'Script generation failed' });
  }
});

// API ROUTE: Gemini TTS Voice Synth
app.post('/api/v1/gemini/tts', async (req, res) => {
  try {
    const { text, voice } = req.body;
    if (!text) {
      res.status(400).json({ error: 'Text parameter required' });
      return;
    }

    const voiceName = voice || 'Kore'; // Prebuilt voice

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text,
              speechMetadata: {
                style: 'Clear, authoritative British broadcasting presenter',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      res.json({ audioBase64: base64Audio, mimeType: 'audio/pcm', sampleRate: 24000 });
      return;
    } else {
      res.status(500).json({ error: 'No audio returned from TTS model' });
      return;
    }
  } catch (err: any) {
    console.error('Gemini TTS error:', err);
    res.status(500).json({ error: err.message || 'Voice synthesis failed' });
    return;
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Northstar Radio (BIR) Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
