export type FacilityLocation = 'LONDON' | 'SALFORD' | 'CARDIFF' | 'GLASGOW' | 'BELFAST';

export type SignalTally = 'PROGRAM' | 'PREVIEW' | 'STANDBY' | 'OFF';

export type SignalType = 'CAMERA' | 'REMOTE_OB' | 'SATELLITE' | 'VTR' | 'REPLAY' | 'GRAPHICS' | 'TEST_PATTERN' | 'STUDIO_FEED';

export interface BroadcastSource {
  id: string;
  name: string;
  code: string;
  type: SignalType;
  location: FacilityLocation;
  format: string; // '1080p50 10-bit', '2160p50 HLG HDR'
  colorSpace: string; // 'Rec.709' | 'Rec.2020 HLG'
  multicastIp: string; // '239.255.10.12:5004'
  st2110Standard: {
    video: string; // ST 2110-20
    audio: string; // ST 2110-30 (8 ch 24-bit 48kHz)
    ancillary: string; // ST 2110-40 (OP-47 / EBU-TT subtitles)
  };
  ptpLock: boolean;
  ptpOffsetNs: number;
  latencyMs: number;
  packetLossPercent: number;
  tally: SignalTally;
  previewThumbnail: string; // Synthetic visual SVG / pattern
  description: string;
  audioPeakDb: number;
  audioRmsDb: number;
  active: boolean;
}

export interface BroadcastDestination {
  id: string;
  name: string;
  code: string;
  type: 'VISION_MIXER' | 'AUDIO_MIXER' | 'MULTIVIEWER' | 'RECORDING' | 'MCR_TX' | 'STREAM_ENCODER' | 'ARCHIVE_INGEST';
  routedSourceId: string;
  format: string;
  status: 'ONLINE' | 'STANDBY' | 'DEGRADED' | 'FAULT';
}

export interface GalleryTransition {
  type: 'CUT' | 'MIX' | 'DIP' | 'WIPE' | 'DVE_PIP';
  durationFrames: number; // 25 fps basis (e.g. 12, 25, 50 frames)
  inProgress: boolean;
  progressPercent: number; // 0 to 100
}

export interface GraphicsOverlay {
  id: string;
  type: 'LOWER_THIRD' | 'BREAKING_TICKER' | 'BUG_DOG' | 'FULLSCREEN_GRAPHIC' | 'SCOREBUG' | 'WEATHER_MAP';
  active: boolean;
  data: {
    title?: string;
    subtitle?: string;
    location?: string;
    tickerText?: string;
    scoreHome?: string;
    scoreAway?: string;
    temperature?: string;
    weatherCondition?: string;
    rawJson?: string;
  };
}

export interface AudioChannelStrip {
  id: string;
  name: string;
  sourceLabel: string;
  faderDb: number; // -Infinity to +10 dB (0 dB unity)
  pan: number; // -100 to +100
  mute: boolean;
  solo: boolean;
  peakDb: number;
  rmsDb: number;
  eqHighDb: number;
  eqMidDb: number;
  eqLowDb: number;
  compThresholdDb: number;
  compRatio: number;
  assignedGroup: 'PGM' | 'AUX1' | 'AUX2' | 'MONITOR';
}

export interface LoudnessMeasurements {
  integratedLufs: number; // Target -23.0 LUFS (EBU R128)
  shortTermLufs: number; // 3-second window
  momentaryLufs: number; // 400ms window
  loudnessRangeLra: number; // LU
  truePeakDbtp: number; // Max -1.0 dBTP (EBU R128 limit)
  dialogueLufs: number;
  complianceStatus: 'COMPLIANT' | 'WARNING_HIGH' | 'WARNING_LOW' | 'NON_COMPLIANT';
  measurementHistory: { time: string; momentary: number; shortTerm: number; truePeak: number }[];
}

export interface NewsAssignment {
  id: string;
  storyTitle: string;
  slug: string;
  location: FacilityLocation | string;
  reporter: string;
  cameraCrew: string;
  editor: string;
  deadlineTime: string;
  priority: 'ROUTINE' | 'PRIORITY' | 'URGENT' | 'BREAKING';
  status: 'NEW' | 'ASSIGNED' | 'SHOOTING' | 'EDITING' | 'READY' | 'LIVE' | 'ARCHIVED';
  legalStatus: 'CLEARED' | 'PENDING_OFCOM' | 'RESTRICTED';
  rightsScope: 'UK_ALL_MEDIA' | 'UK_TERRESTRIAL_ONLY' | 'WORLDWIDE_PSB';
  linkedAssetIds: string[];
}

export interface ScriptBlock {
  id: string;
  type: 'ANCHOR' | 'VO' | 'SOT' | 'PKG' | 'LIVE' | 'GFX' | 'FULLSCREEN';
  speakerOrCue: string;
  text: string;
  estimatedDurationSec: number;
  mediaAssetId?: string;
  graphicsTemplate?: string;
  notes?: string;
}

export interface NewsStory {
  id: string;
  title: string;
  slug: string;
  status: 'DRAFT' | 'APPROVED' | 'READY_RUNDOWN' | 'ON_AIR' | 'TRANSMITTED';
  category: 'DOMESTIC' | 'POLITICS' | 'INTERNATIONAL' | 'ECONOMY' | 'SCIENCE' | 'CULTURE' | 'SPORT';
  author: string;
  wordsCount: number;
  estimatedDurationSec: number;
  scriptBlocks: ScriptBlock[];
  createdTime: string;
  lastUpdated: string;
}

export interface RundownItem {
  id: string;
  itemNumber: string; // '01', '02.1'
  storyId?: string;
  title: string;
  slug: string;
  segmentType: 'OPEN' | 'HEADLINES' | 'STORY' | 'LIVE_HIT' | 'WEATHER' | 'SPORT' | 'COMMERCIAL_BREAK' | 'CLOSING';
  plannedStartTime: string; // '18:00:00'
  plannedDurationSec: number;
  actualDurationSec?: number;
  sourceCode: string; // 'CAM_01', 'VTR_02', 'REMOTE_MAN'
  scriptSlug: string;
  graphicsCue: string;
  audioSetup: string;
  floatItem: boolean; // if floated, not counted in rundown timing
  status: 'PENDING' | 'CUED' | 'ON_AIR' | 'COMPLETED' | 'SKIPPED';
  tally: SignalTally;
}

export interface BroadcastRundown {
  id: string;
  programmeTitle: string; // e.g. "BRITANNIA NEWS AT SIX"
  serviceCode: string; // "BBCOS-1"
  scheduledStartTime: string; // "18:00:00"
  scheduledEndTime: string; // "18:30:00"
  totalPlannedDurationSec: number; // 1800 sec
  actualBroadcastStart?: string;
  currentItemIndex: number;
  timingOffsetSec: number; // Positive = Over/Behind, Negative = Under/Ahead
  timingStatus: 'ON_TIME' | 'AHEAD' | 'BEHIND';
  items: RundownItem[];
}

export interface MediaAsset {
  id: string;
  urn: string; // 'urn:bbcos:mam:2026:asset-8849'
  title: string;
  slug: string;
  category: 'NEWS' | 'SPORT' | 'DOCUMENTARY' | 'DRAMA' | 'ARCHIVE' | 'STILLS' | 'GRAPHICS' | 'PROMO';
  format: 'XAVC-I 100 1080p50' | 'ProRes 422 HQ 1080p50' | 'DNxHD 120' | 'AVC-Intra 100' | 'H.264 Proxy';
  aspectRatio: '16:9' | '4:3';
  frameRate: '50.00 fps' | '25.00 fps';
  durationTimecode: string; // '00:02:14:18'
  durationFrames: number;
  inTimecode: string; // '10:00:00:00'
  outTimecode: string; // '10:02:14:18'
  audioTracks: {
    track: number;
    label: string; // 'Ch 1: Presenter Mic', 'Ch 2: Atmos Stereo L', 'Ch 3: Atmos Stereo R'
    sampleRate: '48.0 kHz 24-bit';
  }[];
  checksumSha256: string;
  qcStatus: 'PASS' | 'WARNING' | 'FAIL';
  qcDetails: {
    blackFrames: number;
    freezeFrames: number;
    audioSilence: boolean;
    ebuLoudness: string;
    truePeak: string;
    colorGamutIllegal: boolean;
    ofcomFlashingChecked: boolean;
  };
  provenance: {
    ingestDate: string;
    ingestLocation: FacilityLocation;
    cameraUnit: string;
    operator: string;
    originalSource: string;
  };
  rights: {
    territory: string;
    expiryDate: string;
    usageRestrictions: string;
    talentCleared: boolean;
    musicCleared: boolean;
  };
  subtitlesAvailable: boolean;
  thumbnailUrl: string;
  tags: string[];
}

export interface PlayoutScheduleItem {
  id: string;
  timeSlot: string; // '18:00:00'
  programmeTitle: string;
  episodeTitle?: string;
  durationTimecode: string;
  mediaAssetId: string;
  service: 'BRITANNIA 1 HD' | 'BRITANNIA 2' | 'BRITANNIA NEWS 24' | 'BRITANNIA SCOTLAND';
  primaryChainStatus: 'ONLINE' | 'STANDBY' | 'FAULT';
  backupChainStatus: 'SYNCED' | 'STANDBY';
  secondaryEvents: {
    optOutTrigger: boolean;
    dskBug: string;
    subtitlesTrack: string;
    audioDescription: boolean;
  };
  state: 'TRANSMITTED' | 'ON_AIR' | 'NEXT' | 'SCHEDULED';
}

export interface UKTransmitterSite {
  id: string;
  siteName: string;
  region: 'LONDON' | 'NORTH_WEST' | 'MIDLANDS' | 'SCOTLAND' | 'WALES' | 'NORTHERN_IRELAND' | 'YORKSHIRE';
  mux: 'PSB1 (BBCOS-A)' | 'PSB2 (D3&4)' | 'PSB3 (HD)';
  frequencyMhz: number;
  erpKw: number;
  coveragePopMillion: number;
  status: 'OPERATIONAL' | 'STANDBY_GENERATOR' | 'MAINTENANCE' | 'OFF_AIR';
  feedSource: 'PRIMARY_IP_FIBRE' | 'SATELLITE_BACKUP';
}

export interface StreamingProfile {
  id: string;
  name: string;
  resolution: string; // '1920x1080'
  frameRate: string; // '50p'
  videoBitrateKbps: number;
  audioBitrateKbps: number;
  codec: 'HEVC / H.265' | 'AVC / H.264' | 'AV1';
  targetLatencyMode: 'LOW_LATENCY_CMAF (1.5s)' | 'STANDARD_HLS (6.0s)' | 'DASH (10.0s)';
  activeViewers: number;
  healthPercent: number;
}

export interface SubtitleCue {
  id: string;
  startTimecode: string;
  endTimecode: string;
  speaker: string;
  color: 'YELLOW' | 'WHITE' | 'CYAN' | 'GREEN';
  text: string;
  position: 'BOTTOM_CENTRE' | 'TOP_CENTRE' | 'BOTTOM_LEFT';
}

export interface SportsReplayAngle {
  id: string;
  name: string;
  cameraSource: string;
  liveBufferLengthSec: number;
  markInSec: number;
  markOutSec: number;
  speedMultiplier: number; // 0.25, 0.50, 0.75, 1.00
  isCueing: boolean;
}

export interface SystemIncident {
  id: string;
  timestamp: string;
  severity: 'CRITICAL' | 'MAJOR' | 'WARNING' | 'INFO';
  subsystem: 'INGEST' | 'PTP_CLOCK' | 'ROUTING' | 'VISION_MIXER' | 'AUDIO' | 'PLAYOUT' | 'TX_TRANSMITTER' | 'STREAMING' | 'SUBTITLES';
  message: string;
  impact: string;
  automatedRemediation: string;
  resolved: boolean;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  operatorId: string;
  workstation: string;
  subsystem: string;
  action: string;
  details: string;
}

export interface EngineeringTelemetry {
  ptpMasterGrandmaster: string;
  ptpSyncStatus: 'LOCKED' | 'HOLD_OVER' | 'FREE_RUN';
  ptpOffsetMeanNs: number;
  networkThroughputGbps: number;
  st2110PacketDropRate: number;
  serverCpuUsagePercent: number;
  serverGpuUsagePercent: number;
  storageIops: number;
  storageFreeTb: number;
  playoutRedundancyMode: 'HITLESS_2022_7' | 'AUTOMATIC_FAILOVER';
  mcrOnAirConfidence: number; // 0 to 100%
}
