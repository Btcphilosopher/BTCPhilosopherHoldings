import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderBarComponent } from './components/header-bar/header-bar';
import { NavRailComponent, BroadcastViewMode } from './components/nav-rail/nav-rail';
import { OverviewViewComponent } from './components/views/overview-view';
import { GalleryViewComponent } from './components/views/gallery-view';
import { NewsroomViewComponent } from './components/views/newsroom-view';
import { RundownViewComponent } from './components/views/rundown-view';
import { MultiviewerViewComponent } from './components/views/multiviewer-view';
import { RoutingViewComponent } from './components/views/routing-view';
import { AudioLoudnessViewComponent } from './components/views/audio-loudness-view';
import { MamViewComponent } from './components/views/mam-view';
import { PlayoutMcrViewComponent } from './components/views/playout-mcr-view';
import { TransmissionViewComponent } from './components/views/transmission-view';
import { SportsReplayViewComponent } from './components/views/sports-replay-view';
import { AccessibilityViewComponent } from './components/views/accessibility-view';
import { TelemetryViewComponent } from './components/views/telemetry-view';
import { AiAssistantModalComponent } from './components/ai-assistant-modal/ai-assistant-modal';
import { BroadcastStateService } from './services/broadcast-state.service';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    HeaderBarComponent,
    NavRailComponent,
    OverviewViewComponent,
    GalleryViewComponent,
    NewsroomViewComponent,
    RundownViewComponent,
    MultiviewerViewComponent,
    RoutingViewComponent,
    AudioLoudnessViewComponent,
    MamViewComponent,
    PlayoutMcrViewComponent,
    TransmissionViewComponent,
    SportsReplayViewComponent,
    AccessibilityViewComponent,
    TelemetryViewComponent,
    AiAssistantModalComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  state = inject(BroadcastStateService);
  currentView = signal<BroadcastViewMode>('overview');
  showAiModal = signal<boolean>(false);

  setView(view: BroadcastViewMode) {
    this.currentView.set(view);
  }
}
