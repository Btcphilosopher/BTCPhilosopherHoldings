import { Injectable, computed, signal } from '@angular/core';
import {
  AudioChannelStrip,
  AuditLogEntry,
  BroadcastDestination,
  BroadcastRundown,
  BroadcastSource,
  EngineeringTelemetry,
  FacilityLocation,
  LoudnessMeasurements,
  MediaAsset,
  NewsAssignment,
  NewsStory,
  PlayoutScheduleItem,
  SportsReplayAngle,
  StreamingProfile,
  SubtitleCue,
  SystemIncident,
  UKTransmitterSite,
} from '../models/broadcast.models';

@Injectable({
  providedIn: 'root',
})
export class BroadcastStateService {
  // -------------------------------------------------------------
  // 1. Time, Master Clock & Telemetry Signals
  // -------------------------------------------------------------
  readonly masterTime = signal<Date>(new Date());
  readonly masterTimecode = signal<string>('18:04:32:14');
  readonly selectedFacility = signal<FacilityLocation>('LONDON');
  readonly currentOperator = signal<string>('ENG-LEAD-482 (J. Davies)');

  // -------------------------------------------------------------
  // 2. Broadcast Sources & Routing Matrix
  // -------------------------------------------------------------
  readonly sources = signal<BroadcastSource[]>([
    {
      id: 'src_cam_01',
      name: 'STUDIO A - CAM 01 (MAIN PRESENTER)',
      code: 'CAM 01',
      type: 'CAMERA',
      location: 'LONDON',
      format: '1080p50 10-bit 4:2:2',
      colorSpace: 'Rec.709',
      multicastIp: '239.255.10.11:5004',
      st2110Standard: {
        video: 'SMPTE ST 2110-20',
        audio: 'SMPTE ST 2110-30 (8ch 24/48)',
        ancillary: 'SMPTE ST 2110-40 (OP-47)',
      },
      ptpLock: true,
      ptpOffsetNs: 12,
      latencyMs: 1.4,
      packetLossPercent: 0.0,
      tally: 'PROGRAM',
      previewThumbnail: 'studio_anchor',
      description: 'Studio A Main pedestal camera on teleprompter rig',
      audioPeakDb: -14.2,
      audioRmsDb: -23.1,
      active: true,
    },
    {
      id: 'src_cam_02',
      name: 'STUDIO A - CAM 02 (CO-HOST / WIDE)',
      code: 'CAM 02',
      type: 'CAMERA',
      location: 'LONDON',
      format: '1080p50 10-bit 4:2:2',
      colorSpace: 'Rec.709',
      multicastIp: '239.255.10.12:5004',
      st2110Standard: {
        video: 'SMPTE ST 2110-20',
        audio: 'SMPTE ST 2110-30 (8ch 24/48)',
        ancillary: 'SMPTE ST 2110-40 (OP-47)',
      },
      ptpLock: true,
      ptpOffsetNs: 18,
      latencyMs: 1.4,
      packetLossPercent: 0.0,
      tally: 'PREVIEW',
      previewThumbnail: 'studio_wide',
      description: 'Studio A jib camera with motorized tracking',
      audioPeakDb: -16.4,
      audioRmsDb: -25.2,
      active: true,
    },
    {
      id: 'src_cam_03',
      name: 'STUDIO A - CAM 03 (INTERVIEW GUEST)',
      code: 'CAM 03',
      type: 'CAMERA',
      location: 'LONDON',
      format: '1080p50 10-bit 4:2:2',
      colorSpace: 'Rec.709',
      multicastIp: '239.255.10.13:5004',
      st2110Standard: {
        video: 'SMPTE ST 2110-20',
        audio: 'SMPTE ST 2110-30 (8ch 24/48)',
        ancillary: 'SMPTE ST 2110-40 (OP-47)',
      },
      ptpLock: true,
      ptpOffsetNs: 14,
      latencyMs: 1.5,
      packetLossPercent: 0.0,
      tally: 'STANDBY',
      previewThumbnail: 'studio_guest',
      description: 'Studio A guest soft-light prime camera',
      audioPeakDb: -18.1,
      audioRmsDb: -26.4,
      active: true,
    },
    {
      id: 'src_cam_04',
      name: 'STUDIO A - CAM 04 (WALL GFX SCREEN)',
      code: 'CAM 04',
      type: 'CAMERA',
      location: 'LONDON',
      format: '1080p50 10-bit 4:2:2',
      colorSpace: 'Rec.709',
      multicastIp: '239.255.10.14:5004',
      st2110Standard: {
        video: 'SMPTE ST 2110-20',
        audio: 'SMPTE ST 2110-30',
        ancillary: 'SMPTE ST 2110-40',
      },
      ptpLock: true,
      ptpOffsetNs: 9,
      latencyMs: 1.3,
      packetLossPercent: 0.0,
      tally: 'STANDBY',
      previewThumbnail: 'studio_wall',
      description: 'Robotic track camera facing high-res video wall',
      audioPeakDb: -22.0,
      audioRmsDb: -30.0,
      active: true,
    },
    {
      id: 'src_rem_01',
      name: 'REMOTE OB 01 (WESTMINSTER GREEN)',
      code: 'REMOTE LON',
      type: 'REMOTE_OB',
      location: 'LONDON',
      format: '1080p50 10-bit H.265 SRT',
      colorSpace: 'Rec.709',
      multicastIp: '239.255.20.101:5004',
      st2110Standard: {
        video: 'SMPTE ST 2110-20 (via Gateway)',
        audio: 'SMPTE ST 2110-30',
        ancillary: 'SMPTE ST 2110-40',
      },
      ptpLock: true,
      ptpOffsetNs: 45,
      latencyMs: 18.2,
      packetLossPercent: 0.02,
      tally: 'STANDBY',
      previewThumbnail: 'remote_parliament',
      description: 'Live reporter unit College Green, Westminster',
      audioPeakDb: -15.8,
      audioRmsDb: -23.8,
      active: true,
    },
    {
      id: 'src_rem_02',
      name: 'REMOTE OB 02 (SALFORD MEDIACITY)',
      code: 'REMOTE MAN',
      type: 'REMOTE_OB',
      location: 'SALFORD',
      format: '1080p50 10-bit IP Fibre',
      colorSpace: 'Rec.709',
      multicastIp: '239.255.20.102:5004',
      st2110Standard: {
        video: 'SMPTE ST 2110-20 (Uncompressed)',
        audio: 'SMPTE ST 2110-30',
        ancillary: 'SMPTE ST 2110-40',
      },
      ptpLock: true,
      ptpOffsetNs: 22,
      latencyMs: 4.8,
      packetLossPercent: 0.0,
      tally: 'STANDBY',
      previewThumbnail: 'remote_salford',
      description: 'North West regional newsroom live duplex link',
      audioPeakDb: -14.9,
      audioRmsDb: -23.0,
      active: true,
    },
    {
      id: 'src_rem_03',
      name: 'REMOTE OB 03 (CARDIFF CENTRAL SQUARE)',
      code: 'REMOTE WALES',
      type: 'REMOTE_OB',
      location: 'CARDIFF',
      format: '1080p50 10-bit IP Fibre',
      colorSpace: 'Rec.709',
      multicastIp: '239.255.20.103:5004',
      st2110Standard: {
        video: 'SMPTE ST 2110-20',
        audio: 'SMPTE ST 2110-30',
        ancillary: 'SMPTE ST 2110-40',
      },
      ptpLock: true,
      ptpOffsetNs: 26,
      latencyMs: 5.4,
      packetLossPercent: 0.0,
      tally: 'STANDBY',
      previewThumbnail: 'remote_cardiff',
      description: 'Wales National Broadcast Studio direct line',
      audioPeakDb: -16.0,
      audioRmsDb: -24.1,
      active: true,
    },
    {
      id: 'src_vtr_01',
      name: 'CLIP SERVER A (VTR 01 - PKG PRIMARY)',
      code: 'VTR 01',
      type: 'VTR',
      location: 'LONDON',
      format: '1080p50 XAVC-I 100',
      colorSpace: 'Rec.709',
      multicastIp: '239.255.30.1:5004',
      st2110Standard: {
        video: 'SMPTE ST 2110-20',
        audio: 'SMPTE ST 2110-30 (16ch)',
        ancillary: 'SMPTE ST 2110-40',
      },
      ptpLock: true,
      ptpOffsetNs: 8,
      latencyMs: 0.8,
      packetLossPercent: 0.0,
      tally: 'STANDBY',
      previewThumbnail: 'vtr_package',
      description: 'Video server channel A playing edited news packages',
      audioPeakDb: -12.0,
      audioRmsDb: -22.8,
      active: true,
    },
    {
      id: 'src_vtr_02',
      name: 'CLIP SERVER B (VTR 02 - B-ROLL / SOT)',
      code: 'VTR 02',
      type: 'VTR',
      location: 'LONDON',
      format: '1080p50 ProRes 422',
      colorSpace: 'Rec.709',
      multicastIp: '239.255.30.2:5004',
      st2110Standard: {
        video: 'SMPTE ST 2110-20',
        audio: 'SMPTE ST 2110-30',
        ancillary: 'SMPTE ST 2110-40',
      },
      ptpLock: true,
      ptpOffsetNs: 7,
      latencyMs: 0.8,
      packetLossPercent: 0.0,
      tally: 'STANDBY',
      previewThumbnail: 'vtr_broll',
      description: 'Video server channel B soundbites and overlays',
      audioPeakDb: -13.5,
      audioRmsDb: -23.2,
      active: true,
    },
    {
      id: 'src_rep_01',
      name: 'EVS / REPLAY SERVER CH A (SLO-MO)',
      code: 'REPLAY A',
      type: 'REPLAY',
      location: 'LONDON',
      format: '1080p50 DNxHD 185x',
      colorSpace: 'Rec.709',
      multicastIp: '239.255.35.1:5004',
      st2110Standard: {
        video: 'SMPTE ST 2110-20',
        audio: 'SMPTE ST 2110-30',
        ancillary: 'SMPTE ST 2110-40',
      },
      ptpLock: true,
      ptpOffsetNs: 11,
      latencyMs: 0.9,
      packetLossPercent: 0.0,
      tally: 'STANDBY',
      previewThumbnail: 'replay_sport',
      description: 'Circular buffer multi-angle sports replay channel',
      audioPeakDb: -18.0,
      audioRmsDb: -26.0,
      active: true,
    },
    {
      id: 'src_gfx_01',
      name: 'CHYRON / VIZRT LIVE GFX ENGINE',
      code: 'LIVE GFX',
      type: 'GRAPHICS',
      location: 'LONDON',
      format: '1080p50 Fill+Key (ST 2110)',
      colorSpace: 'Rec.709',
      multicastIp: '239.255.40.1:5004',
      st2110Standard: {
        video: 'SMPTE ST 2110-20',
        audio: 'SMPTE ST 2110-30',
        ancillary: 'SMPTE ST 2110-40',
      },
      ptpLock: true,
      ptpOffsetNs: 6,
      latencyMs: 1.1,
      packetLossPercent: 0.0,
      tally: 'PROGRAM',
      previewThumbnail: 'gfx_lowerthird',
      description: 'Real-time 3D broadcast graphics renderer',
      audioPeakDb: -20.0,
      audioRmsDb: -30.0,
      active: true,
    },
    {
      id: 'src_bars_01',
      name: 'TEST GENERATOR (EBU COLOR BARS + 1kHz)',
      code: 'TEST BARS',
      type: 'TEST_PATTERN',
      location: 'LONDON',
      format: '1080p50 100% 75% EBU Bars',
      colorSpace: 'Rec.709',
      multicastIp: '239.255.50.1:5004',
      st2110Standard: {
        video: 'SMPTE ST 2110-20',
        audio: 'SMPTE ST 2110-30 (1kHz -18dBFS)',
        ancillary: 'SMPTE ST 2110-40',
      },
      ptpLock: true,
      ptpOffsetNs: 2,
      latencyMs: 0.2,
      packetLossPercent: 0.0,
      tally: 'STANDBY',
      previewThumbnail: 'test_bars',
      description: 'Master engineering reference signal generator',
      audioPeakDb: -18.0,
      audioRmsDb: -18.0,
      active: true,
    },
  ]);

  readonly destinations = signal<BroadcastDestination[]>([
    {
      id: 'dst_vm_pgm',
      name: 'GALLERY VISION MIXER - PGM BUS',
      code: 'VM PGM',
      type: 'VISION_MIXER',
      routedSourceId: 'src_cam_01',
      format: '1080p50 10-bit',
      status: 'ONLINE',
    },
    {
      id: 'dst_vm_pvw',
      name: 'GALLERY VISION MIXER - PVW BUS',
      code: 'VM PVW',
      type: 'VISION_MIXER',
      routedSourceId: 'src_cam_02',
      format: '1080p50 10-bit',
      status: 'ONLINE',
    },
    {
      id: 'dst_mv_01',
      name: 'PRODUCTION GALLERY MULTIVIEWER 01',
      code: 'MV G1',
      type: 'MULTIVIEWER',
      routedSourceId: 'src_cam_01',
      format: '2160p50 Quad-split',
      status: 'ONLINE',
    },
    {
      id: 'dst_mcr_tx',
      name: 'MASTER CONTROL TRANSMISSION CHAIN A',
      code: 'MCR TX-1',
      type: 'MCR_TX',
      routedSourceId: 'src_cam_01',
      format: '1080p50 HD-SDI / 2110',
      status: 'ONLINE',
    },
    {
      id: 'dst_rec_01',
      name: 'MAM COMPLIANCE RECORDER CH 1',
      code: 'COMP REC',
      type: 'RECORDING',
      routedSourceId: 'src_cam_01',
      format: '1080p50 H.264 Compliance',
      status: 'ONLINE',
    },
    {
      id: 'dst_enc_ott',
      name: 'DASH/HLS STREAM ENCODER PRIMARY',
      code: 'OTT ENC-1',
      type: 'STREAM_ENCODER',
      routedSourceId: 'src_cam_01',
      format: 'HEVC 1080p50 CMAF',
      status: 'ONLINE',
    },
  ]);

  // -------------------------------------------------------------
  // 3. Vision Mixer & Gallery Production Control
  // -------------------------------------------------------------
  readonly programSourceId = signal<string>('src_cam_01');
  readonly previewSourceId = signal<string>('src_cam_02');
  readonly transitionMode = signal<'CUT' | 'MIX' | 'DIP' | 'WIPE' | 'DVE_PIP'>('MIX');
  readonly transitionRateFrames = signal<number>(25); // 25 frames = 1.0 sec at 50i/50p
  readonly tBarPosition = signal<number>(0); // 0 (PGM) to 100 (PVW transitioned)
  readonly isAutoTransitioning = signal<boolean>(false);

  // Keyers & Graphics Overlays
  readonly dsk1BugActive = signal<boolean>(true); // DOG / Bug e.g. "BRITANNIA 1 HD"
  readonly dsk2LowerThirdActive = signal<boolean>(true); // Lower Third
  readonly dsk3BreakingActive = signal<boolean>(false); // Breaking News Ticker
  readonly dsk4PipActive = signal<boolean>(false); // Picture-in-Picture Box

  readonly lowerThirdData = signal({
    name: 'SARAH JENNINGS',
    role: 'Chief Political Correspondent',
    location: 'WESTMINSTER, LONDON',
  });

  readonly breakingTickerText = signal<string>(
    'BREAKING: TREASURY CONFIRMS MULTI-BILLION TRANSPORT INVESTMENT PLAN FOR NORTHERN RAIL NETWORK • COMMONS VOTE EXPECTED AT 21:00 BST • LIVE COVERAGE CONTINUES ON BBCOS',
  );

  readonly programSource = computed(() => {
    return this.sources().find((s) => s.id === this.programSourceId()) || this.sources()[0];
  });

  readonly previewSource = computed(() => {
    return this.sources().find((s) => s.id === this.previewSourceId()) || this.sources()[1];
  });

  // -------------------------------------------------------------
  // 4. Gallery Audio Mixer & EBU R128 Loudness
  // -------------------------------------------------------------
  readonly audioChannels = signal<AudioChannelStrip[]>([
    {
      id: 'ach_1',
      name: 'MIC 1 (PRESENTER A)',
      sourceLabel: 'STUDIO A PED 1',
      faderDb: 0.0,
      pan: 0,
      mute: false,
      solo: false,
      peakDb: -14.2,
      rmsDb: -22.8,
      eqHighDb: 1.0,
      eqMidDb: -1.5,
      eqLowDb: -2.0,
      compThresholdDb: -18.0,
      compRatio: 3.5,
      assignedGroup: 'PGM',
    },
    {
      id: 'ach_2',
      name: 'MIC 2 (CO-HOST B)',
      sourceLabel: 'STUDIO A JIB',
      faderDb: -2.0,
      pan: -15,
      mute: false,
      solo: false,
      peakDb: -16.4,
      rmsDb: -24.6,
      eqHighDb: 0.5,
      eqMidDb: 0.0,
      eqLowDb: -1.0,
      compThresholdDb: -18.0,
      compRatio: 3.0,
      assignedGroup: 'PGM',
    },
    {
      id: 'ach_3',
      name: 'MIC 3 (GUEST DESK)',
      sourceLabel: 'STUDIO A SOFT',
      faderDb: -4.0,
      pan: 20,
      mute: false,
      solo: false,
      peakDb: -18.8,
      rmsDb: -26.2,
      eqHighDb: 0.0,
      eqMidDb: 1.0,
      eqLowDb: 0.0,
      compThresholdDb: -20.0,
      compRatio: 2.5,
      assignedGroup: 'PGM',
    },
    {
      id: 'ach_4',
      name: 'REMOTE 1 (WESTMINSTER)',
      sourceLabel: 'COLLEGE GREEN OB',
      faderDb: -1.5,
      pan: 0,
      mute: false,
      solo: false,
      peakDb: -15.1,
      rmsDb: -23.4,
      eqHighDb: 1.5,
      eqMidDb: -0.5,
      eqLowDb: -4.0,
      compThresholdDb: -16.0,
      compRatio: 4.0,
      assignedGroup: 'PGM',
    },
    {
      id: 'ach_5',
      name: 'REMOTE 2 (SALFORD)',
      sourceLabel: 'MEDIACITY DUPLEX',
      faderDb: -3.0,
      pan: 0,
      mute: false,
      solo: false,
      peakDb: -16.0,
      rmsDb: -24.0,
      eqHighDb: 0.0,
      eqMidDb: 0.0,
      eqLowDb: -2.0,
      compThresholdDb: -18.0,
      compRatio: 3.0,
      assignedGroup: 'PGM',
    },
    {
      id: 'ach_6',
      name: 'VTR 01 (PKG PRIMARY)',
      sourceLabel: 'CLIP SERVER A',
      faderDb: 0.0,
      pan: 0,
      mute: false,
      solo: false,
      peakDb: -12.4,
      rmsDb: -22.9,
      eqHighDb: 0.0,
      eqMidDb: 0.0,
      eqLowDb: 0.0,
      compThresholdDb: -14.0,
      compRatio: 2.0,
      assignedGroup: 'PGM',
    },
    {
      id: 'ach_7',
      name: 'VTR 02 (B-ROLL / SOT)',
      sourceLabel: 'CLIP SERVER B',
      faderDb: -6.0,
      pan: 0,
      mute: false,
      solo: false,
      peakDb: -20.5,
      rmsDb: -28.1,
      eqHighDb: 0.0,
      eqMidDb: 0.0,
      eqLowDb: 0.0,
      compThresholdDb: -16.0,
      compRatio: 2.0,
      assignedGroup: 'PGM',
    },
    {
      id: 'ach_8',
      name: 'MUSIC STING / BED',
      sourceLabel: 'GALLERY SPOTON',
      faderDb: -14.0,
      pan: 0,
      mute: false,
      solo: false,
      peakDb: -22.0,
      rmsDb: -29.4,
      eqHighDb: -1.0,
      eqMidDb: -2.0,
      eqLowDb: 0.0,
      compThresholdDb: -20.0,
      compRatio: 2.0,
      assignedGroup: 'PGM',
    },
    {
      id: 'ach_9',
      name: 'STUDIO ATMOS STEREO',
      sourceLabel: 'ROOF BOUNDARY PAIR',
      faderDb: -18.0,
      pan: 0,
      mute: false,
      solo: false,
      peakDb: -28.0,
      rmsDb: -36.0,
      eqHighDb: -3.0,
      eqMidDb: 0.0,
      eqLowDb: -6.0,
      compThresholdDb: -24.0,
      compRatio: 1.5,
      assignedGroup: 'PGM',
    },
    {
      id: 'ach_10',
      name: 'COMM / TALKBACK DUCK',
      sourceLabel: 'DIRECTOR TALKBACK',
      faderDb: -99.0,
      pan: 0,
      mute: true,
      solo: false,
      peakDb: -99.0,
      rmsDb: -99.0,
      eqHighDb: 0.0,
      eqMidDb: 3.0,
      eqLowDb: -12.0,
      compThresholdDb: -12.0,
      compRatio: 8.0,
      assignedGroup: 'MONITOR',
    },
  ]);

  readonly masterFaderDb = signal<number>(0.0);
  readonly loudness = signal<LoudnessMeasurements>({
    integratedLufs: -23.0,
    shortTermLufs: -22.8,
    momentaryLufs: -23.2,
    loudnessRangeLra: 4.8,
    truePeakDbtp: -1.2,
    dialogueLufs: -23.1,
    complianceStatus: 'COMPLIANT',
    measurementHistory: [],
  });

  // -------------------------------------------------------------
  // 5. Newsroom Computer System (NRCS) & Assignments
  // -------------------------------------------------------------
  readonly assignments = signal<NewsAssignment[]>([
    {
      id: 'asg_01',
      storyTitle: 'Northern Rail & Infrastructure Electrification Strategy',
      slug: 'NORTH-RAIL-REVAMP',
      location: 'SALFORD',
      reporter: 'David H. Thompson',
      cameraCrew: 'Unit NW-04 (B. Carter / G. Wright)',
      editor: 'E. Jenkins',
      deadlineTime: '17:45:00',
      priority: 'BREAKING',
      status: 'READY',
      legalStatus: 'CLEARED',
      rightsScope: 'UK_ALL_MEDIA',
      linkedAssetIds: ['mam_asset_01', 'mam_asset_02'],
    },
    {
      id: 'asg_02',
      storyTitle: 'Westminster Cabinet Energy Security & Offshore Wind Bill',
      slug: 'WESTMINSTER-ENERGY',
      location: 'LONDON',
      reporter: 'Sarah Jennings',
      cameraCrew: 'Unit LDN-02 (A. Hughes)',
      editor: 'M. Patel',
      deadlineTime: '18:10:00',
      priority: 'PRIORITY',
      status: 'LIVE',
      legalStatus: 'CLEARED',
      rightsScope: 'WORLDWIDE_PSB',
      linkedAssetIds: ['mam_asset_03'],
    },
    {
      id: 'asg_03',
      storyTitle: 'Cardiff Innovation Hub: Green Hydrogen Transit Fleet',
      slug: 'WALES-HYDROGEN',
      location: 'CARDIFF',
      reporter: 'Gareth Evans',
      cameraCrew: 'Unit WAL-01 (D. Price)',
      editor: 'K. Owen',
      deadlineTime: '18:25:00',
      priority: 'ROUTINE',
      status: 'SHOOTING',
      legalStatus: 'CLEARED',
      rightsScope: 'UK_ALL_MEDIA',
      linkedAssetIds: ['mam_asset_04'],
    },
    {
      id: 'asg_04',
      storyTitle: 'Highland Renewable Grid Expansion & Fishery Consultation',
      slug: 'SCOT-GRID-EXP',
      location: 'GLASGOW',
      reporter: 'Fiona MacLeod',
      cameraCrew: 'Unit SCOT-03 (J. Campbell)',
      editor: 'S. Ross',
      deadlineTime: '18:40:00',
      priority: 'ROUTINE',
      status: 'EDITING',
      legalStatus: 'PENDING_OFCOM',
      rightsScope: 'UK_ALL_MEDIA',
      linkedAssetIds: ['mam_asset_05'],
    },
    {
      id: 'asg_05',
      storyTitle: 'Belfast Digital Tech Corridor & Cyber Hub Inauguration',
      slug: 'NI-CYBER-CENTRE',
      location: 'BELFAST',
      reporter: 'Patrick O’Donnell',
      cameraCrew: 'Unit NI-02 (C. Murphy)',
      editor: 'L. Kelly',
      deadlineTime: '18:50:00',
      priority: 'ROUTINE',
      status: 'ASSIGNED',
      legalStatus: 'CLEARED',
      rightsScope: 'UK_ALL_MEDIA',
      linkedAssetIds: ['mam_asset_06'],
    },
  ]);

  readonly activeStory = signal<NewsStory>({
    id: 'story_01',
    title: 'Northern Rail Multi-Billion Investment Announcement',
    slug: 'UK-RAIL-INFRASTRUCTURE',
    status: 'READY_RUNDOWN',
    category: 'DOMESTIC',
    author: 'David H. Thompson (Transport Correspondent)',
    wordsCount: 285,
    estimatedDurationSec: 104,
    createdTime: '2026-09-28 14:30:00',
    lastUpdated: '2026-09-28 17:52:10',
    scriptBlocks: [
      {
        id: 'blk_1',
        type: 'ANCHOR',
        speakerOrCue: 'ANCHOR (STUDIO A - CAM 01)',
        text: 'Good evening. A major transport announcement this evening with a twelve-billion-pound investment programme aimed at full rail electrification and high-frequency connectivity across Northern England.',
        estimatedDurationSec: 14,
        notes: 'Camera 1 direct to lens on teleprompter',
      },
      {
        id: 'blk_2',
        type: 'VO',
        speakerOrCue: 'VO (OVER VT 01 - B-ROLL TRACKS)',
        text: 'The plan guarantees continuous overhead electrification from Liverpool Lime Street through Manchester Piccadilly and onwards to Leeds and York by the close of the decade.',
        estimatedDurationSec: 18,
        mediaAssetId: 'mam_asset_01',
        notes: 'Roll VT 01 sound under atmos -14dB',
      },
      {
        id: 'blk_3',
        type: 'SOT',
        speakerOrCue: 'SOT (CHANCELLOR AT COMMONS)',
        text: '"This is the single most extensive modernisation of our regional rail corridors since the Victorian era, cutting journey times and boosting regional productivity by hundreds of millions annually."',
        estimatedDurationSec: 22,
        mediaAssetId: 'mam_asset_02',
        graphicsTemplate: 'LOWER_THIRD_CHANCELLOR',
      },
      {
        id: 'blk_4',
        type: 'LIVE',
        speakerOrCue: 'LIVE (REMOTE MAN - DAVID THOMPSON)',
        text: 'David Thompson is at Manchester Piccadilly for us tonight. David, passenger groups have reacted with broad optimism, but what is the realistic timeline for commuter benefits?',
        estimatedDurationSec: 35,
        notes: 'Cue 2-box DVE layout: CAM 01 + REMOTE MAN',
      },
      {
        id: 'blk_5',
        type: 'GFX',
        speakerOrCue: 'FULLSCREEN GFX (TIMELINE MAP)',
        text: 'Key route delivery: Manchester-Leeds Phase 1 (2027), Trans-Pennine express upgrades (2028), Full freight bypass integration (2029).',
        estimatedDurationSec: 15,
        graphicsTemplate: 'FULLSCREEN_MAP_RAIL',
      },
    ],
  });

  // -------------------------------------------------------------
  // 6. Rundown Automation Engine
  // -------------------------------------------------------------
  readonly rundown = signal<BroadcastRundown>({
    id: 'rd_20260928_1800',
    programmeTitle: 'BRITANNIA NEWS AT SIX',
    serviceCode: 'BBCOS-1 HD',
    scheduledStartTime: '18:00:00',
    scheduledEndTime: '18:30:00',
    totalPlannedDurationSec: 1800,
    actualBroadcastStart: '18:00:00',
    currentItemIndex: 2,
    timingOffsetSec: 8, // +8 sec (slightly over/behind)
    timingStatus: 'BEHIND',
    items: [
      {
        id: 'rdi_01',
        itemNumber: '01.0',
        title: 'PROGRAMME TITLES & OPENING STING',
        slug: 'OPEN-TITLES',
        segmentType: 'OPEN',
        plannedStartTime: '18:00:00',
        plannedDurationSec: 24,
        actualDurationSec: 24,
        sourceCode: 'VTR 01',
        scriptSlug: 'PROG-OPEN',
        graphicsCue: 'TITLES_3D_BUG',
        audioSetup: 'SURROUND 5.1 MUSIC',
        floatItem: false,
        status: 'COMPLETED',
        tally: 'OFF',
      },
      {
        id: 'rdi_02',
        itemNumber: '02.0',
        title: 'HEADLINES SUMMARY: RAIL, ENERGY, COMMONS',
        slug: 'HEADLINES',
        segmentType: 'HEADLINES',
        plannedStartTime: '18:00:24',
        plannedDurationSec: 68,
        actualDurationSec: 70,
        sourceCode: 'CAM 01',
        scriptSlug: 'HL-SUMMARY',
        graphicsCue: 'HL_SIDEBAR_TICKER',
        audioSetup: 'MIC 1 + BED DUCK',
        floatItem: false,
        status: 'COMPLETED',
        tally: 'OFF',
      },
      {
        id: 'rdi_03',
        itemNumber: '03.0',
        storyId: 'story_01',
        title: 'NORTHERN RAILWAY MULTI-BILLION INVESTMENT',
        slug: 'NORTH-RAIL-REVAMP',
        segmentType: 'STORY',
        plannedStartTime: '18:01:32',
        plannedDurationSec: 195,
        sourceCode: 'CAM 01',
        scriptSlug: 'UK-RAIL-INFRASTRUCTURE',
        graphicsCue: 'LOWER_THIRD_RAIL',
        audioSetup: 'MIC 1 + VTR 01',
        floatItem: false,
        status: 'ON_AIR',
        tally: 'PROGRAM',
      },
      {
        id: 'rdi_04',
        itemNumber: '04.0',
        title: 'LIVE HIT: MANCHESTER PICCADILLY COMMUTER REACTION',
        slug: 'LIVE-MANCHESTER',
        segmentType: 'LIVE_HIT',
        plannedStartTime: '18:04:47',
        plannedDurationSec: 150,
        sourceCode: 'REMOTE MAN',
        scriptSlug: 'MAN-DUPLEX',
        graphicsCue: '2BOX_DVE_LABEL',
        audioSetup: 'REMOTE 2 CH-5',
        floatItem: false,
        status: 'CUED',
        tally: 'PREVIEW',
      },
      {
        id: 'rdi_05',
        itemNumber: '05.0',
        title: 'WESTMINSTER ENERGY BILL & COMMONS VOTE',
        slug: 'WESTMINSTER-ENERGY',
        segmentType: 'STORY',
        plannedStartTime: '18:07:17',
        plannedDurationSec: 210,
        sourceCode: 'REMOTE LON',
        scriptSlug: 'COMMONS-ENERGY',
        graphicsCue: 'GFX_COMMONS_LOWER',
        audioSetup: 'REMOTE 1 CH-4',
        floatItem: false,
        status: 'PENDING',
        tally: 'STANDBY',
      },
      {
        id: 'rdi_06',
        itemNumber: '06.0',
        title: 'UK NATIONS ROUNDUP: CARDIFF & EDINBURGH BRIEFS',
        slug: 'NATIONS-ROUNDUP',
        segmentType: 'STORY',
        plannedStartTime: '18:10:47',
        plannedDurationSec: 160,
        sourceCode: 'VTR 02',
        scriptSlug: 'NATIONS-BRIEFS',
        graphicsCue: 'NATIONS_SPLIT_MAP',
        audioSetup: 'VTR 02 CH-7',
        floatItem: false,
        status: 'PENDING',
        tally: 'STANDBY',
      },
      {
        id: 'rdi_07',
        itemNumber: '07.0',
        title: 'NATIONAL WEATHER OUTLOOK & ATLANTIC FRONT',
        slug: 'UK-WEATHER',
        segmentType: 'WEATHER',
        plannedStartTime: '18:13:27',
        plannedDurationSec: 120,
        sourceCode: 'CAM 04',
        scriptSlug: 'WX-CHROMA',
        graphicsCue: 'WEATHER_MAP_ANIM',
        audioSetup: 'MIC 3 (WX PRESENTER)',
        floatItem: false,
        status: 'PENDING',
        tally: 'STANDBY',
      },
      {
        id: 'rdi_08',
        itemNumber: '08.0',
        title: 'SPORT: PREMIER LEAGUE FIXTURES & SIX NATIONS',
        slug: 'SPORT-BULLETIN',
        segmentType: 'SPORT',
        plannedStartTime: '18:15:27',
        plannedDurationSec: 240,
        sourceCode: 'REPLAY A',
        scriptSlug: 'SPORT-SUMMARY',
        graphicsCue: 'SCOREBOARD_LOWER',
        audioSetup: 'MIC 2 + REPLAY CH-8',
        floatItem: false,
        status: 'PENDING',
        tally: 'STANDBY',
      },
      {
        id: 'rdi_09',
        itemNumber: '09.0',
        title: 'CLOSING SLATE & JUNCTION IDENT INTO REGIONAL OPT-OUT',
        slug: 'CLOSE-JUNCTION',
        segmentType: 'CLOSING',
        plannedStartTime: '18:19:27',
        plannedDurationSec: 45,
        sourceCode: 'LIVE GFX',
        scriptSlug: 'REGIONAL-OPT-CUE',
        graphicsCue: 'JUNCTION_OPT_IDENTS',
        audioSetup: 'PROGRAMME OUTRO STING',
        floatItem: false,
        status: 'PENDING',
        tally: 'STANDBY',
      },
    ],
  });

  // -------------------------------------------------------------
  // 7. Media Asset Management (MAM) Library
  // -------------------------------------------------------------
  readonly mamAssets = signal<MediaAsset[]>([
    {
      id: 'mam_asset_01',
      urn: 'urn:bbcos:mam:2026:asset-8841',
      title: 'Trans-Pennine High Speed Rail Stock Ingest & Overhead Lines',
      slug: 'RAIL-NORTH-BROLL',
      category: 'NEWS',
      format: 'XAVC-I 100 1080p50',
      aspectRatio: '16:9',
      frameRate: '50.00 fps',
      durationTimecode: '00:03:15:10',
      durationFrames: 4885,
      inTimecode: '10:00:00:00',
      outTimecode: '10:03:15:10',
      audioTracks: [
        { track: 1, label: 'Ch 1: Ambient Track FX Stereo L', sampleRate: '48.0 kHz 24-bit' },
        { track: 2, label: 'Ch 2: Ambient Track FX Stereo R', sampleRate: '48.0 kHz 24-bit' },
        { track: 3, label: 'Ch 3: Guide Commentary', sampleRate: '48.0 kHz 24-bit' },
        { track: 4, label: 'Ch 4: Timecode LTC', sampleRate: '48.0 kHz 24-bit' },
      ],
      checksumSha256: 'a7b8e9c0128456f913d80a32e185cba908d132ef48c081923057193bca1094ef',
      qcStatus: 'PASS',
      qcDetails: {
        blackFrames: 0,
        freezeFrames: 0,
        audioSilence: false,
        ebuLoudness: '-23.0 LUFS',
        truePeak: '-1.4 dBTP',
        colorGamutIllegal: false,
        ofcomFlashingChecked: true,
      },
      provenance: {
        ingestDate: '2026-09-28 15:12:00',
        ingestLocation: 'SALFORD',
        cameraUnit: 'Sony FX9 / 4K sensor 10-bit',
        operator: 'B. Carter',
        originalSource: 'CFexpress B Card Slot 1',
      },
      rights: {
        territory: 'UK & Worldwide Digital PSB',
        expiryDate: '2030-12-31',
        usageRestrictions: 'News & Current Affairs Editorial Only',
        talentCleared: true,
        musicCleared: true,
      },
      subtitlesAvailable: true,
      thumbnailUrl: 'https://picsum.photos/seed/railway_modern/400/225',
      tags: ['Rail', 'Transport', 'Manchester', 'Infrastructure', 'Electric'],
    },
    {
      id: 'mam_asset_02',
      urn: 'urn:bbcos:mam:2026:asset-8842',
      title: 'Chancellor Commons Statement at Dispatch Box SOT',
      slug: 'COMMONS-CHANCELLOR-SOT',
      category: 'NEWS',
      format: 'ProRes 422 HQ 1080p50',
      aspectRatio: '16:9',
      frameRate: '50.00 fps',
      durationTimecode: '00:01:42:00',
      durationFrames: 2550,
      inTimecode: '14:20:00:00',
      outTimecode: '14:21:42:00',
      audioTracks: [
        { track: 1, label: 'Ch 1: Commons Feed Clean Clean Voice', sampleRate: '48.0 kHz 24-bit' },
        { track: 2, label: 'Ch 2: Chamber Atmos Ambient L', sampleRate: '48.0 kHz 24-bit' },
      ],
      checksumSha256: '9f8e7d6c5b4a3210ef8765432109876543210abcdef0123456789abcdef01234',
      qcStatus: 'PASS',
      qcDetails: {
        blackFrames: 0,
        freezeFrames: 0,
        audioSilence: false,
        ebuLoudness: '-22.8 LUFS',
        truePeak: '-1.1 dBTP',
        colorGamutIllegal: false,
        ofcomFlashingChecked: true,
      },
      provenance: {
        ingestDate: '2026-09-28 14:25:00',
        ingestLocation: 'LONDON',
        cameraUnit: 'Parliamentary Broadcasting Pool',
        operator: 'PPU Line 4',
        originalSource: 'Fibre Ingest Port 12',
      },
      rights: {
        territory: 'Public Record Parliamentary License',
        expiryDate: 'PERPETUAL',
        usageRestrictions: 'Must maintain parliamentary context rule',
        talentCleared: true,
        musicCleared: true,
      },
      subtitlesAvailable: true,
      thumbnailUrl: 'https://picsum.photos/seed/parliament_commons/400/225',
      tags: ['Parliament', 'Chancellor', 'Treasury', 'Politics', 'Commons'],
    },
    {
      id: 'mam_asset_03',
      urn: 'urn:bbcos:mam:2026:asset-8843',
      title: 'North Sea Offshore Wind Array & Subsea Interconnector',
      slug: 'OFFSHORE-WIND-ENERGY',
      category: 'DOCUMENTARY',
      format: 'XAVC-I 100 1080p50',
      aspectRatio: '16:9',
      frameRate: '50.00 fps',
      durationTimecode: '00:04:10:20',
      durationFrames: 6270,
      inTimecode: '09:00:00:00',
      outTimecode: '09:04:10:20',
      audioTracks: [
        { track: 1, label: 'Ch 1: Drone Atmos Audio', sampleRate: '48.0 kHz 24-bit' },
        { track: 2, label: 'Ch 2: Engineer Interview Mono', sampleRate: '48.0 kHz 24-bit' },
      ],
      checksumSha256: 'c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f80123456789abcdef0123456789abcdef',
      qcStatus: 'PASS',
      qcDetails: {
        blackFrames: 0,
        freezeFrames: 0,
        audioSilence: false,
        ebuLoudness: '-23.1 LUFS',
        truePeak: '-1.5 dBTP',
        colorGamutIllegal: false,
        ofcomFlashingChecked: true,
      },
      provenance: {
        ingestDate: '2026-09-27 11:30:00',
        ingestLocation: 'GLASGOW',
        cameraUnit: 'RED V-Raptor 8K scaled to 1080p',
        operator: 'H. MacIntyre',
        originalSource: 'Fibre S3 Direct Bucket',
      },
      rights: {
        territory: 'Worldwide All Rights',
        expiryDate: '2035-06-30',
        usageRestrictions: 'None',
        talentCleared: true,
        musicCleared: true,
      },
      subtitlesAvailable: false,
      thumbnailUrl: 'https://picsum.photos/seed/wind_turbines/400/225',
      tags: ['Energy', 'Renewables', 'Scotland', 'Wind Farm', 'Climate'],
    },
    {
      id: 'mam_asset_04',
      urn: 'urn:bbcos:mam:2026:asset-8844',
      title: 'Premier League Match Highlights: Arsenal vs Manchester City',
      slug: 'SPORT-EPL-ROUND28',
      category: 'SPORT',
      format: 'ProRes 422 HQ 1080p50',
      aspectRatio: '16:9',
      frameRate: '50.00 fps',
      durationTimecode: '00:05:40:00',
      durationFrames: 8500,
      inTimecode: '16:00:00:00',
      outTimecode: '16:05:40:00',
      audioTracks: [
        { track: 1, label: 'Ch 1: Live Stadium FX Stereo L', sampleRate: '48.0 kHz 24-bit' },
        { track: 2, label: 'Ch 2: Live Stadium FX Stereo R', sampleRate: '48.0 kHz 24-bit' },
        { track: 3, label: 'Ch 3: Clean Commentary Lead', sampleRate: '48.0 kHz 24-bit' },
        { track: 4, label: 'Ch 4: Co-Commentary', sampleRate: '48.0 kHz 24-bit' },
      ],
      checksumSha256: '11223344556677889900aabbccddeeff11223344556677889900aabbccddeeff',
      qcStatus: 'PASS',
      qcDetails: {
        blackFrames: 0,
        freezeFrames: 0,
        audioSilence: false,
        ebuLoudness: '-23.0 LUFS',
        truePeak: '-1.0 dBTP',
        colorGamutIllegal: false,
        ofcomFlashingChecked: true,
      },
      provenance: {
        ingestDate: '2026-09-28 16:45:00',
        ingestLocation: 'LONDON',
        cameraUnit: 'OB Super-Slo 8-camera Rig',
        operator: 'Live Sports Ingest MCR',
        originalSource: 'EVS IPDP Line 1',
      },
      rights: {
        territory: 'UK Terrestrial & Catch-up (48hr holdback)',
        expiryDate: '2026-09-30 23:59:59',
        usageRestrictions: 'Must credit Premier League broadcast pool',
        talentCleared: true,
        musicCleared: true,
      },
      subtitlesAvailable: true,
      thumbnailUrl: 'https://picsum.photos/seed/football_stadium/400/225',
      tags: ['Sport', 'Football', 'Premier League', 'Goals', 'Highlights'],
    },
    {
      id: 'mam_asset_05',
      urn: 'urn:bbcos:mam:2026:asset-8845',
      title: 'Historical Archive: 1982 Falklands Taskforce Return Portsmouth',
      slug: 'ARCHIVE-1982-HERMES',
      category: 'ARCHIVE',
      format: 'AVC-Intra 100',
      aspectRatio: '4:3',
      frameRate: '25.00 fps',
      durationTimecode: '00:08:20:12',
      durationFrames: 12512,
      inTimecode: '00:00:00:00',
      outTimecode: '00:08:20:12',
      audioTracks: [
        { track: 1, label: 'Ch 1: 1-inch C-Format Restored Mono', sampleRate: '48.0 kHz 24-bit' },
      ],
      checksumSha256: '5566778899aabbccddeeff00112233445566778899aabbccddeeff0011223344',
      qcStatus: 'WARNING',
      qcDetails: {
        blackFrames: 2,
        freezeFrames: 0,
        audioSilence: false,
        ebuLoudness: '-24.2 LUFS',
        truePeak: '-2.1 dBTP',
        colorGamutIllegal: false,
        ofcomFlashingChecked: true,
      },
      provenance: {
        ingestDate: '2026-08-14 09:15:00',
        ingestLocation: 'LONDON',
        cameraUnit: 'Archival Quadruplex 2-inch Transfer Suite',
        operator: 'R. Simmons (Archivist)',
        originalSource: 'Tape Vault B-39',
      },
      rights: {
        territory: 'Britannia Archives PSB Trust',
        expiryDate: 'PERPETUAL',
        usageRestrictions: 'Historical PSB Educational use',
        talentCleared: true,
        musicCleared: true,
      },
      subtitlesAvailable: true,
      thumbnailUrl: 'https://picsum.photos/seed/naval_ship_archive/400/225',
      tags: ['Archive', 'History', 'Portsmouth', 'Military', 'Restored'],
    },
  ]);

  readonly selectedAssetId = signal<string>('mam_asset_01');
  readonly selectedAsset = computed(() => {
    return this.mamAssets().find((a) => a.id === this.selectedAssetId()) || this.mamAssets()[0];
  });

  // -------------------------------------------------------------
  // 8. Playout Automation & Master Control Room (MCR)
  // -------------------------------------------------------------
  readonly playoutSchedule = signal<PlayoutScheduleItem[]>([
    {
      id: 'pl_01',
      timeSlot: '17:30:00',
      programmeTitle: 'POINTLESS: REGIONAL CELEBRITY SPECIAL',
      episodeTitle: 'Series 32, Episode 4',
      durationTimecode: '00:29:50:00',
      mediaAssetId: 'mam_asset_03',
      service: 'BRITANNIA 1 HD',
      primaryChainStatus: 'ONLINE',
      backupChainStatus: 'SYNCED',
      secondaryEvents: {
        optOutTrigger: false,
        dskBug: 'BUG_BRITANNIA_1',
        subtitlesTrack: 'SUB_EN_01',
        audioDescription: true,
      },
      state: 'TRANSMITTED',
    },
    {
      id: 'pl_02',
      timeSlot: '18:00:00',
      programmeTitle: 'BRITANNIA NEWS AT SIX (LIVE)',
      episodeTitle: 'Transmission Live from London Studio A',
      durationTimecode: '00:30:00:00',
      mediaAssetId: 'mam_asset_01',
      service: 'BRITANNIA 1 HD',
      primaryChainStatus: 'ONLINE',
      backupChainStatus: 'SYNCED',
      secondaryEvents: {
        optOutTrigger: true,
        dskBug: 'BUG_NEWS_LIVE',
        subtitlesTrack: 'LIVE_STENOGRAPHY',
        audioDescription: false,
      },
      state: 'ON_AIR',
    },
    {
      id: 'pl_03',
      timeSlot: '18:30:00',
      programmeTitle: 'REGIONAL NEWSROOM OPTS (LONDON / SALFORD / CARDIFF)',
      episodeTitle: 'Regional News Magazines',
      durationTimecode: '00:28:30:00',
      mediaAssetId: 'mam_asset_02',
      service: 'BRITANNIA 1 HD',
      primaryChainStatus: 'ONLINE',
      backupChainStatus: 'SYNCED',
      secondaryEvents: {
        optOutTrigger: true,
        dskBug: 'REGIONAL_DOG',
        subtitlesTrack: 'SUB_REGIONAL',
        audioDescription: false,
      },
      state: 'NEXT',
    },
    {
      id: 'pl_04',
      timeSlot: '19:00:00',
      programmeTitle: 'THE ONE SHOW LIVE',
      episodeTitle: 'Daily Magazine with Live Music',
      durationTimecode: '00:30:00:00',
      mediaAssetId: 'mam_asset_04',
      service: 'BRITANNIA 1 HD',
      primaryChainStatus: 'STANDBY',
      backupChainStatus: 'SYNCED',
      secondaryEvents: {
        optOutTrigger: false,
        dskBug: 'BUG_BRITANNIA_1',
        subtitlesTrack: 'LIVE_SUB',
        audioDescription: true,
      },
      state: 'SCHEDULED',
    },
    {
      id: 'pl_05',
      timeSlot: '19:30:00',
      programmeTitle: 'EASTENDERS',
      episodeTitle: 'Albert Square Episode 6890',
      durationTimecode: '00:29:40:00',
      mediaAssetId: 'mam_asset_05',
      service: 'BRITANNIA 1 HD',
      primaryChainStatus: 'STANDBY',
      backupChainStatus: 'STANDBY',
      secondaryEvents: {
        optOutTrigger: false,
        dskBug: 'BUG_BRITANNIA_1',
        subtitlesTrack: 'SUB_EN_PREP',
        audioDescription: true,
      },
      state: 'SCHEDULED',
    },
  ]);

  readonly mcrEmergencySlateActive = signal<boolean>(false);
  readonly mcrPrimaryChainActive = signal<boolean>(true); // true = Primary, false = Backup Failover

  // -------------------------------------------------------------
  // 9. UK Transmission & Terrestrial DTT / IP Streaming
  // -------------------------------------------------------------
  readonly transmitters = signal<UKTransmitterSite[]>([
    {
      id: 'tx_cp',
      siteName: 'CRYSTAL PALACE (GREATER LONDON)',
      region: 'LONDON',
      mux: 'PSB1 (BBCOS-A)',
      frequencyMhz: 490.0,
      erpKw: 200,
      coveragePopMillion: 12.4,
      status: 'OPERATIONAL',
      feedSource: 'PRIMARY_IP_FIBRE',
    },
    {
      id: 'tx_wh',
      siteName: 'WINTER HILL (NORTH WEST & GREATER MANCHESTER)',
      region: 'NORTH_WEST',
      mux: 'PSB1 (BBCOS-A)',
      frequencyMhz: 562.0,
      erpKw: 100,
      coveragePopMillion: 6.8,
      status: 'OPERATIONAL',
      feedSource: 'PRIMARY_IP_FIBRE',
    },
    {
      id: 'tx_bh',
      siteName: 'BLACK HILL (CENTRAL SCOTLAND)',
      region: 'SCOTLAND',
      mux: 'PSB1 (BBCOS-A)',
      frequencyMhz: 626.0,
      erpKw: 100,
      coveragePopMillion: 2.9,
      status: 'OPERATIONAL',
      feedSource: 'PRIMARY_IP_FIBRE',
    },
    {
      id: 'tx_wv',
      siteName: 'WENVOE (CARDIFF & SOUTH WALES)',
      region: 'WALES',
      mux: 'PSB1 (BBCOS-A)',
      frequencyMhz: 546.0,
      erpKw: 100,
      coveragePopMillion: 2.1,
      status: 'OPERATIONAL',
      feedSource: 'PRIMARY_IP_FIBRE',
    },
    {
      id: 'tx_dv',
      siteName: 'DIVIS (GREATER BELFAST & NORTHERN IRELAND)',
      region: 'NORTHERN_IRELAND',
      mux: 'PSB1 (BBCOS-A)',
      frequencyMhz: 522.0,
      erpKw: 100,
      coveragePopMillion: 1.5,
      status: 'OPERATIONAL',
      feedSource: 'SATELLITE_BACKUP',
    },
    {
      id: 'tx_sm',
      siteName: 'SUTTON COLDFIELD (BIRMINGHAM & MIDLANDS)',
      region: 'MIDLANDS',
      mux: 'PSB1 (BBCOS-A)',
      frequencyMhz: 650.0,
      erpKw: 200,
      coveragePopMillion: 5.3,
      status: 'OPERATIONAL',
      feedSource: 'PRIMARY_IP_FIBRE',
    },
  ]);

  readonly streamingProfiles = signal<StreamingProfile[]>([
    {
      id: 'prof_4k',
      name: '2160p50 UHD HDR (DASH/CMAF)',
      resolution: '3840x2160',
      frameRate: '50p',
      videoBitrateKbps: 18500,
      audioBitrateKbps: 448,
      codec: 'HEVC / H.265',
      targetLatencyMode: 'LOW_LATENCY_CMAF (1.5s)',
      activeViewers: 342000,
      healthPercent: 99.8,
    },
    {
      id: 'prof_1080p',
      name: '1080p50 HD High (HLS / DASH)',
      resolution: '1920x1080',
      frameRate: '50p',
      videoBitrateKbps: 6200,
      audioBitrateKbps: 256,
      codec: 'AVC / H.264',
      targetLatencyMode: 'LOW_LATENCY_CMAF (1.5s)',
      activeViewers: 1485000,
      healthPercent: 100.0,
    },
    {
      id: 'prof_720p',
      name: '720p50 HD Med (HLS / DASH)',
      resolution: '1280x720',
      frameRate: '50p',
      videoBitrateKbps: 3400,
      audioBitrateKbps: 192,
      codec: 'AVC / H.264',
      targetLatencyMode: 'STANDARD_HLS (6.0s)',
      activeViewers: 820000,
      healthPercent: 100.0,
    },
    {
      id: 'prof_540p',
      name: '540p25 Mobile / Low Bandwidth',
      resolution: '960x540',
      frameRate: '25p',
      videoBitrateKbps: 1400,
      audioBitrateKbps: 128,
      codec: 'AVC / H.264',
      targetLatencyMode: 'STANDARD_HLS (6.0s)',
      activeViewers: 310000,
      healthPercent: 100.0,
    },
  ]);

  // -------------------------------------------------------------
  // 10. Subtitles & Accessibility
  // -------------------------------------------------------------
  readonly liveSubtitleStreamActive = signal<boolean>(true);
  readonly audioDescriptionActive = signal<boolean>(false);
  readonly bslSignerPipActive = signal<boolean>(false);

  readonly subtitleCues = signal<SubtitleCue[]>([
    {
      id: 'sub_01',
      startTimecode: '18:01:32:00',
      endTimecode: '18:01:38:14',
      speaker: 'PRESENTER',
      color: 'YELLOW',
      text: 'Good evening. A major transport announcement this evening.',
      position: 'BOTTOM_CENTRE',
    },
    {
      id: 'sub_02',
      startTimecode: '18:01:38:15',
      endTimecode: '18:01:46:00',
      speaker: 'PRESENTER',
      color: 'YELLOW',
      text: 'With a £12 billion investment programme aimed at full rail electrification.',
      position: 'BOTTOM_CENTRE',
    },
    {
      id: 'sub_03',
      startTimecode: '18:01:46:01',
      endTimecode: '18:01:54:12',
      speaker: 'VOICE OVER',
      color: 'WHITE',
      text: 'Connecting Liverpool, Manchester, Leeds and York by the end of the decade.',
      position: 'BOTTOM_CENTRE',
    },
    {
      id: 'sub_04',
      startTimecode: '18:01:54:13',
      endTimecode: '18:02:05:00',
      speaker: 'CHANCELLOR',
      color: 'CYAN',
      text: '"This is the single most extensive modernisation of our regional rail corridors since Victorian times."',
      position: 'BOTTOM_CENTRE',
    },
  ]);

  // -------------------------------------------------------------
  // 11. Sports Replay & Scoreboard
  // -------------------------------------------------------------
  readonly sportsScore = signal({
    homeTeam: 'ARSENAL',
    awayTeam: 'MAN CITY',
    homeScore: 2,
    awayScore: 1,
    matchMinute: "78'",
    competition: 'PREMIER LEAGUE',
  });

  readonly replayAngles = signal<SportsReplayAngle[]>([
    {
      id: 'rep_ang_1',
      name: 'ANGLE 1: HIGH MAIN 18-YARD',
      cameraSource: 'src_cam_01',
      liveBufferLengthSec: 600,
      markInSec: 540,
      markOutSec: 558,
      speedMultiplier: 0.5,
      isCueing: false,
    },
    {
      id: 'rep_ang_2',
      name: 'ANGLE 2: GOALMOUTH SUPER-SLO',
      cameraSource: 'src_cam_02',
      liveBufferLengthSec: 600,
      markInSec: 545,
      markOutSec: 555,
      speedMultiplier: 0.25,
      isCueing: true,
    },
    {
      id: 'rep_ang_3',
      name: 'ANGLE 3: REVERSE PENALTY BOX',
      cameraSource: 'src_cam_03',
      liveBufferLengthSec: 600,
      markInSec: 542,
      markOutSec: 556,
      speedMultiplier: 0.5,
      isCueing: false,
    },
  ]);

  // -------------------------------------------------------------
  // 12. Engineering Telemetry, Digital Twin & Incidents
  // -------------------------------------------------------------
  readonly telemetry = signal<EngineeringTelemetry>({
    ptpMasterGrandmaster: 'IEEE 1588-2008 PTP GM (LONDON PTP-01 GPS LOCKED)',
    ptpSyncStatus: 'LOCKED',
    ptpOffsetMeanNs: 14.2,
    networkThroughputGbps: 184.6,
    st2110PacketDropRate: 0.0,
    serverCpuUsagePercent: 28.4,
    serverGpuUsagePercent: 34.1,
    storageIops: 24800,
    storageFreeTb: 482.5,
    playoutRedundancyMode: 'HITLESS_2022_7',
    mcrOnAirConfidence: 100,
  });

  readonly incidents = signal<SystemIncident[]>([
    {
      id: 'inc_01',
      timestamp: '17:15:22',
      severity: 'WARNING',
      subsystem: 'ROUTING',
      message: 'ST 2110 Stream jitter threshold exceeded on Secondary Trunk Manchester Link',
      impact: 'Zero packet loss under SMPTE 2022-7 hitless protection',
      automatedRemediation: 'Re-synchronized PTP boundary clock on Salford node',
      resolved: true,
    },
  ]);

  readonly auditLog = signal<AuditLogEntry[]>([
    {
      id: 'log_01',
      timestamp: '18:00:00.040',
      operatorId: 'AUTOMATION-MCR',
      workstation: 'MCR-NODE-01',
      subsystem: 'PLAYOUT',
      action: 'PLAYOUT_TRIGGER_ON_AIR',
      details: 'Started Britannia News At Six (ID: rd_20260928_1800)',
    },
    {
      id: 'log_02',
      timestamp: '18:01:32.120',
      operatorId: 'VISION-DIR-04',
      workstation: 'GALLERY-A-DESK',
      subsystem: 'VISION_MIXER',
      action: 'TAKE_CUT',
      details: 'CAM 01 (Presenter) taken to PROGRAM bus',
    },
    {
      id: 'log_03',
      timestamp: '18:01:34.000',
      operatorId: 'GFX-OP-02',
      workstation: 'VIZRT-ENGINE-01',
      subsystem: 'GRAPHICS',
      action: 'DSK_KEY_ON',
      details: 'Lower Third Sarah Jennings keyed over Program Feed',
    },
  ]);

  constructor() {
    // Start master broadcast clock loop (25 fps / 40ms simulation)
    if (typeof window !== 'undefined') {
      setInterval(() => {
        this.tickBroadcastClock();
      }, 1000);

      // Micro-tick for audio meter physics & timecode frames (every 100ms)
      setInterval(() => {
        this.tickAudioAndTelemetry();
      }, 100);
    }
  }

  // -------------------------------------------------------------
  // Master Clock & Telemetry Loop
  // -------------------------------------------------------------
  private frameCount = 14;
  private secondsCount = 32;
  private minutesCount = 4;
  private hoursCount = 18;

  private tickBroadcastClock() {
    const now = new Date();
    this.masterTime.set(now);
  }

  private tickAudioAndTelemetry() {
    this.frameCount = (this.frameCount + 1) % 25;
    if (this.frameCount === 0) {
      this.secondsCount = (this.secondsCount + 1) % 60;
      if (this.secondsCount === 0) {
        this.minutesCount = (this.minutesCount + 1) % 60;
      }
    }

    const tc = `${String(this.hoursCount).padStart(2, '0')}:${String(this.minutesCount).padStart(2, '0')}:${String(this.secondsCount).padStart(2, '0')}:${String(this.frameCount).padStart(2, '0')}`;
    this.masterTimecode.set(tc);

    // Dynamic subtle fluctuations in audio meters
    const isMcrEmergency = this.mcrEmergencySlateActive();
    this.audioChannels.update((channels) => {
      return channels.map((ch, idx) => {
        if (ch.mute || isMcrEmergency) {
          return { ...ch, peakDb: -99, rmsDb: -99 };
        }
        // Organic voice/music modulation
        const wobble = Math.sin(Date.now() / 200 + idx) * 2.5;
        const targetPeak = ch.assignedGroup === 'PGM' && !ch.mute ? Math.min(-6, ch.faderDb - 14 + wobble) : -40;
        const targetRms = targetPeak - 9;
        return {
          ...ch,
          peakDb: Number(targetPeak.toFixed(1)),
          rmsDb: Number(targetRms.toFixed(1)),
        };
      });
    });

    // Calculate Master Loudness according to EBU R128 (-23.0 LUFS target)
    if (!isMcrEmergency) {
      const mom = Number((-23.0 + Math.sin(Date.now() / 800) * 0.8).toFixed(1));
      const shortTerm = Number((-23.0 + Math.sin(Date.now() / 2400) * 0.4).toFixed(1));
      const truePeak = Number((-1.2 + Math.random() * 0.2).toFixed(1));

      this.loudness.update((l) => ({
        ...l,
        integratedLufs: -23.0,
        shortTermLufs: shortTerm,
        momentaryLufs: mom,
        truePeakDbtp: truePeak,
        dialogueLufs: -23.1,
        complianceStatus: Math.abs(shortTerm - -23.0) < 1.0 ? 'COMPLIANT' : 'WARNING_HIGH',
      }));
    } else {
      this.loudness.update((l) => ({
        ...l,
        integratedLufs: -99,
        shortTermLufs: -99,
        momentaryLufs: -99,
        truePeakDbtp: -99,
        complianceStatus: 'NON_COMPLIANT',
      }));
    }
  }

  // -------------------------------------------------------------
  // Vision Mixer Actions
  // -------------------------------------------------------------
  cutToSource(sourceId: string) {
    const src = this.sources().find((s) => s.id === sourceId);
    if (!src) return;

    const prevPgm = this.programSourceId();
    this.programSourceId.set(sourceId);
    this.previewSourceId.set(prevPgm);

    this.updateSourceTallies(sourceId, prevPgm);
    this.recordAuditLog('VISION_MIXER', 'CUT_TO_SOURCE', `Switched Program to ${src.code} (${src.name})`);
  }

  setPreviewSource(sourceId: string) {
    const src = this.sources().find((s) => s.id === sourceId);
    if (!src) return;

    this.previewSourceId.set(sourceId);
    this.updateSourceTallies(this.programSourceId(), sourceId);
    this.recordAuditLog('VISION_MIXER', 'SET_PREVIEW', `Selected ${src.code} on Preview bus`);
  }

  triggerAutoTransition() {
    if (this.isAutoTransitioning()) return;

    this.isAutoTransitioning.set(true);
    const pgm = this.programSourceId();
    const pvw = this.previewSourceId();

    const durationMs = (this.transitionRateFrames() / 25) * 1000;
    const startTime = Date.now();

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(100, Math.round((elapsed / durationMs) * 100));
      this.tBarPosition.set(progress);

      if (progress >= 100) {
        clearInterval(interval);
        this.programSourceId.set(pvw);
        this.previewSourceId.set(pgm);
        this.tBarPosition.set(0);
        this.isAutoTransitioning.set(false);
        this.updateSourceTallies(pvw, pgm);
        this.recordAuditLog(
          'VISION_MIXER',
          'AUTO_TRANSITION_COMPLETE',
          `${this.transitionMode()} ${this.transitionRateFrames()}f transition completed from ${pgm} to ${pvw}`,
        );
      }
    }, 40);
  }

  setManualTBar(position: number) {
    const clamped = Math.max(0, Math.min(100, position));
    this.tBarPosition.set(clamped);

    if (clamped >= 100) {
      const pgm = this.programSourceId();
      const pvw = this.previewSourceId();
      this.programSourceId.set(pvw);
      this.previewSourceId.set(pgm);
      this.tBarPosition.set(0);
      this.updateSourceTallies(pvw, pgm);
    }
  }

  toggleDsk(dskNumber: 1 | 2 | 3 | 4) {
    if (dskNumber === 1) this.dsk1BugActive.update((v) => !v);
    if (dskNumber === 2) this.dsk2LowerThirdActive.update((v) => !v);
    if (dskNumber === 3) this.dsk3BreakingActive.update((v) => !v);
    if (dskNumber === 4) this.dsk4PipActive.update((v) => !v);

    this.recordAuditLog('VISION_MIXER', 'TOGGLE_KEYER', `Keyer DSK-${dskNumber} state toggled`);
  }

  private updateSourceTallies(pgmId: string, pvwId: string) {
    this.sources.update((sources) => {
      return sources.map((s) => {
        if (s.id === pgmId) return { ...s, tally: 'PROGRAM' };
        if (s.id === pvwId) return { ...s, tally: 'PREVIEW' };
        return { ...s, tally: 'STANDBY' };
      });
    });
  }

  // -------------------------------------------------------------
  // Audio Mixer Actions
  // -------------------------------------------------------------
  setChannelFader(channelId: string, faderDb: number) {
    this.audioChannels.update((channels) => {
      return channels.map((ch) => (ch.id === channelId ? { ...ch, faderDb } : ch));
    });
  }

  toggleChannelMute(channelId: string) {
    this.audioChannels.update((channels) => {
      return channels.map((ch) => (ch.id === channelId ? { ...ch, mute: !ch.mute } : ch));
    });
  }

  toggleChannelSolo(channelId: string) {
    this.audioChannels.update((channels) => {
      return channels.map((ch) => (ch.id === channelId ? { ...ch, solo: !ch.solo } : ch));
    });
  }

  // -------------------------------------------------------------
  // Rundown & Newsroom Actions
  // -------------------------------------------------------------
  cueRundownItem(index: number) {
    this.rundown.update((rd) => {
      const items = rd.items.map((item, i) => {
        if (i === index) return { ...item, status: 'CUED' as const };
        if (item.status === 'CUED') return { ...item, status: 'PENDING' as const };
        return item;
      });
      return { ...rd, items };
    });
    this.recordAuditLog('RUNDOWN', 'CUE_ITEM', `Cued item index ${index} in rundown`);
  }

  takeNextRundownItem() {
    this.rundown.update((rd) => {
      const nextIdx = (rd.currentItemIndex + 1) % rd.items.length;
      const items = rd.items.map((item, i) => {
        if (i === rd.currentItemIndex) return { ...item, status: 'COMPLETED' as const, tally: 'OFF' as const };
        if (i === nextIdx) {
          // If item has an associated source, route it
          return { ...item, status: 'ON_AIR' as const, tally: 'PROGRAM' as const };
        }
        return item;
      });

      const nextItem = items[nextIdx];
      // Switch vision mixer if matching source
      const matchingSource = this.sources().find(
        (s) => s.code === nextItem.sourceCode || s.name.includes(nextItem.sourceCode),
      );
      if (matchingSource) {
        this.programSourceId.set(matchingSource.id);
        this.updateSourceTallies(matchingSource.id, this.previewSourceId());
      }

      return {
        ...rd,
        currentItemIndex: nextIdx,
        items,
      };
    });

    this.recordAuditLog('RUNDOWN', 'TAKE_NEXT', `Stepped rundown to item ${this.rundown().currentItemIndex + 1}`);
  }

  toggleFloatItem(itemId: string) {
    this.rundown.update((rd) => {
      const items = rd.items.map((item) => (item.id === itemId ? { ...item, floatItem: !item.floatItem } : item));
      return { ...rd, items };
    });
  }

  updateScriptBlock(blockId: string, newText: string) {
    this.activeStory.update((story) => {
      const blocks = story.scriptBlocks.map((b) => (b.id === blockId ? { ...b, text: newText } : b));
      const totalWords = blocks.reduce((acc, b) => acc + b.text.split(/\s+/).length, 0);
      const estSec = Math.round((totalWords / 130) * 60); // 130 words per minute broadcast read rate
      return {
        ...story,
        scriptBlocks: blocks,
        wordsCount: totalWords,
        estimatedDurationSec: estSec,
        lastUpdated: new Date().toISOString().replace('T', ' ').substring(0, 19),
      };
    });
  }

  // -------------------------------------------------------------
  // Routing Matrix Cross-point Switch
  // -------------------------------------------------------------
  routeMatrixCrossPoint(destinationId: string, sourceId: string) {
    this.destinations.update((dests) => {
      return dests.map((dst) => (dst.id === destinationId ? { ...dst, routedSourceId: sourceId } : dst));
    });

    if (destinationId === 'dst_vm_pgm') {
      this.programSourceId.set(sourceId);
      this.updateSourceTallies(sourceId, this.previewSourceId());
    } else if (destinationId === 'dst_vm_pvw') {
      this.previewSourceId.set(sourceId);
      this.updateSourceTallies(this.programSourceId(), sourceId);
    }

    const src = this.sources().find((s) => s.id === sourceId);
    const dst = this.destinations().find((d) => d.id === destinationId);
    this.recordAuditLog('ROUTER', 'CROSSPOINT_LATCH', `Routed ${src?.code || sourceId} -> ${dst?.code || destinationId}`);
  }

  // -------------------------------------------------------------
  // Playout & MCR Controls
  // -------------------------------------------------------------
  toggleMcrEmergencySlate() {
    this.mcrEmergencySlateActive.update((v) => !v);
    const state = this.mcrEmergencySlateActive();
    this.recordAuditLog(
      'MCR',
      state ? 'EMERGENCY_SLATE_ENGAGED' : 'EMERGENCY_SLATE_DISENGAGED',
      state ? 'Master Control switched Transmission to Emergency Slate Generator' : 'Resumed live program feed',
    );
  }

  toggleMcrHitlessFailover() {
    this.mcrPrimaryChainActive.update((v) => !v);
    const isPrimary = this.mcrPrimaryChainActive();
    this.recordAuditLog(
      'MCR',
      'CHAIN_SWITCHOVER',
      `Playout transmission switched to ${isPrimary ? 'PRIMARY CHAIN A' : 'BACKUP REDUNDANT CHAIN B'}`,
    );
  }

  // -------------------------------------------------------------
  // Fault Injection & Simulation Engine
  // -------------------------------------------------------------
  injectSimulatedFault(faultType: 'CAMERA_FIBRE_CUT' | 'PRIMARY_ENCODER_FAIL' | 'PTP_DRIFT' | 'AUDIO_LINE_NOISE') {
    if (faultType === 'CAMERA_FIBRE_CUT') {
      this.sources.update((sources) => {
        return sources.map((s) => (s.id === 'src_cam_02' ? { ...s, active: false, latencyMs: 999 } : s));
      });
      this.addIncident('ROUTING', 'CRITICAL', 'Camera 02 Salford trunk fiber link carrier lost', 'Primary camera offline, switched fallback to Jib');
    } else if (faultType === 'PRIMARY_ENCODER_FAIL') {
      this.mcrPrimaryChainActive.set(false);
      this.addIncident('PLAYOUT', 'MAJOR', 'Primary Playout Node A hardware watch-dog timeout', 'SMPTE 2022-7 Hitless failover activated Backup Node B in 0.4ms');
    } else if (faultType === 'PTP_DRIFT') {
      this.telemetry.update((t) => ({ ...t, ptpSyncStatus: 'HOLD_OVER', ptpOffsetMeanNs: 840.5 }));
      this.addIncident('PTP_CLOCK', 'WARNING', 'PTP Grandmaster 01 GPS unlocked - shifted to rubidium holdover', 'Timing within EBU SMPTE 2110 1us safety margin');
    } else if (faultType === 'AUDIO_LINE_NOISE') {
      this.audioChannels.update((chs) => {
        return chs.map((c) => (c.id === 'ach_4' ? { ...c, mute: true } : c));
      });
      this.addIncident('AUDIO', 'WARNING', 'Remote OB 1 Westminster line degradation detected', 'Automated ducking and safety mute engaged');
    }
  }

  restoreAllFaults() {
    this.sources.update((sources) => {
      return sources.map((s) => ({ ...s, active: true, latencyMs: s.id === 'src_rem_01' ? 18.2 : 1.4 }));
    });
    this.mcrPrimaryChainActive.set(true);
    this.telemetry.update((t) => ({ ...t, ptpSyncStatus: 'LOCKED', ptpOffsetMeanNs: 14.2 }));
    this.audioChannels.update((chs) => chs.map((c) => ({ ...c, mute: c.id === 'ach_10' })));
    this.incidents.update((incs) => incs.map((i) => ({ ...i, resolved: true })));
    this.recordAuditLog('DIAGNOSTICS', 'SYSTEM_RESET', 'All simulated faults cleared. Systems nominal.');
  }

  private addIncident(subsystem: SystemIncident['subsystem'], severity: SystemIncident['severity'], message: string, remediation: string) {
    const inc: SystemIncident = {
      id: `inc_${Date.now()}`,
      timestamp: new Date().toTimeString().split(' ')[0],
      severity,
      subsystem,
      message,
      impact: 'Service protected by BBCOS redundancy fabric',
      automatedRemediation: remediation,
      resolved: false,
    };
    this.incidents.update((list) => [inc, ...list]);
    this.recordAuditLog(subsystem, `INCIDENT_${severity}`, `${message} -> ${remediation}`);
  }

  private recordAuditLog(subsystem: string, action: string, details: string) {
    const entry: AuditLogEntry = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toTimeString().split(' ')[0] + '.' + String(this.frameCount * 40).padStart(3, '0'),
      operatorId: this.currentOperator(),
      workstation: `${this.selectedFacility()}-ENG-WS`,
      subsystem,
      action,
      details,
    };
    this.auditLog.update((logs) => [entry, ...logs.slice(0, 99)]);
  }
}
