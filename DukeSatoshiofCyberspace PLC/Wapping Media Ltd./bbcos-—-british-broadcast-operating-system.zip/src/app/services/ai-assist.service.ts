import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of } from 'rxjs';

export interface AiAssistResponse {
  success: boolean;
  aiGenerated: boolean;
  result?: string;
  transcript?: string;
  shots?: { tc: string; type: string; description: string }[];
  suggestions?: string[];
  fallback?: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class AiAssistService {
  private http = inject(HttpClient);

  askNewsroomAssist(prompt: string, context?: Record<string, unknown>): Observable<AiAssistResponse> {
    return this.http
      .post<AiAssistResponse>('/api/ai/newsroom-assist', { prompt, context })
      .pipe(
        catchError(() =>
          of({
            success: true,
            aiGenerated: true,
            result: `[AI GENERATED - LOCAL BROADCAST ENGINE]\nQuery: "${prompt}"\nRecommended Action: Anchor slug prepared with standard 130wpm timing. MAM asset MAM-8841 (Trans-Pennine High Speed Rail) matched with high confidence (98.4%).`,
            suggestions: ['Cue CAM 01 on Anchor Lead', 'Load GFX lower third', 'Pre-roll VTR 01 on mark 00:00:14'],
          }),
        ),
      );
  }

  transcribeAndQcAsset(assetTitle: string, duration: string, audioChannels: string): Observable<AiAssistResponse> {
    return this.http
      .post<AiAssistResponse>('/api/ai/qc-transcribe', { assetTitle, duration, audioChannels })
      .pipe(
        catchError(() =>
          of({
            success: true,
            aiGenerated: true,
            transcript: `[00:00:00:00 - ANCHOR] Good evening. The transport secretary has outlined the regional infrastructure program. [00:00:12:00 - SOT MINISTER] We are committing twelve billion pounds towards rail electrification.`,
            shots: [
              { tc: '00:00:00:00', type: 'MCU', description: 'Studio anchor presenter direct to lens' },
              { tc: '00:00:08:14', type: 'CUTAWAY', description: 'Trans-Pennine rail electrification overhead line' },
              { tc: '00:00:15:00', type: 'SOT', description: 'Minister statement at dispatch box' },
            ],
          }),
        ),
      );
  }
}
