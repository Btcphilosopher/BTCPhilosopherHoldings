import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

export type BroadcastViewMode =
  | 'overview'
  | 'gallery'
  | 'newsroom'
  | 'rundown'
  | 'multiviewer'
  | 'routing'
  | 'audio'
  | 'mam'
  | 'playout'
  | 'transmission'
  | 'sports'
  | 'accessibility'
  | 'telemetry';

@Component({
  selector: 'app-nav-rail',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <nav class="w-16 bg-[#090d13] border-r border-[#21262d] flex flex-col items-center py-2.5 gap-1 select-none z-20 shrink-0 h-full overflow-y-auto">
      @for (item of navItems; track item.id) {
        <button
          (click)="viewSelected.emit(item.id)"
          [class.bg-[#1f6feb]/20]="activeView() === item.id"
          [class.text-[#58a6ff]]="activeView() === item.id"
          [class.border-[#1f6feb]/50]="activeView() === item.id"
          [class.text-[#8b949e]]="activeView() !== item.id"
          [class.border-transparent]="activeView() !== item.id"
          class="w-12 h-12 rounded-lg flex flex-col items-center justify-center p-1 border transition-all hover:bg-[#161b22] hover:text-white group relative"
          [title]="item.label + ' (' + item.category + ')'">
          <mat-icon class="!text-[20px] !w-[20px] !h-[20px] transition-transform group-hover:scale-110">{{ item.icon }}</mat-icon>
          <span class="text-[9px] font-mono font-semibold tracking-tight mt-0.5 leading-tight truncate w-full text-center">
            {{ item.shortLabel }}
          </span>

          @if (activeView() === item.id) {
            <span class="absolute -left-0.5 top-2 bottom-2 w-1 bg-[#58a6ff] rounded-r"></span>
          }
        </button>
      }
    </nav>
  `,
})
export class NavRailComponent {
  activeView = input.required<BroadcastViewMode>();
  viewSelected = output<BroadcastViewMode>();

  readonly navItems: { id: BroadcastViewMode; label: string; shortLabel: string; icon: string; category: string }[] = [
    { id: 'overview', label: 'Broadcast Fabric Overview', shortLabel: 'CHAIN', icon: 'account_tree', category: 'SYSTEM' },
    { id: 'gallery', label: 'Production Gallery & Vision Mixer', shortLabel: 'GALLERY', icon: 'videocam', category: 'PRODUCTION' },
    { id: 'newsroom', label: 'Newsroom & Script Editor', shortLabel: 'NEWS', icon: 'edit_note', category: 'EDITORIAL' },
    { id: 'rundown', label: 'Broadcast Rundown & Prompter', shortLabel: 'RUNDOWN', icon: 'list_alt', category: 'EDITORIAL' },
    { id: 'multiviewer', label: '12-Tile Master Multiviewer', shortLabel: 'MULTI-V', icon: 'grid_view', category: 'MONITORING' },
    { id: 'routing', label: 'SMPTE ST 2110 Matrix Router', shortLabel: 'ROUTER', icon: 'hub', category: 'SIGNALS' },
    { id: 'audio', label: 'Audio Console & EBU R128 Loudness', shortLabel: 'AUDIO', icon: 'equalizer', category: 'AUDIO' },
    { id: 'mam', label: 'Media Asset Management (MAM)', shortLabel: 'MAM', icon: 'video_library', category: 'MEDIA' },
    { id: 'playout', label: 'Master Control & Playout (MCR)', shortLabel: 'MCR/TX', icon: 'podcasts', category: 'PLAYOUT' },
    { id: 'transmission', label: 'UK DTT Freeview & Streaming', shortLabel: 'DISTRIB', icon: 'cell_tower', category: 'TRANSMISSION' },
    { id: 'sports', label: 'Sports Production & Replay', shortLabel: 'REPLAY', icon: 'sports_soccer', category: 'LIVE' },
    { id: 'accessibility', label: 'Subtitles, AD & Sign Language', shortLabel: 'ACCESS', icon: 'closed_caption', category: 'ACCESSIBILITY' },
    { id: 'telemetry', label: 'Digital Twin & Failure Simulator', shortLabel: 'ENG-OPS', icon: 'troubleshoot', category: 'ENGINEERING' },
  ];
}
