import { ChangeDetectionStrategy, Component, inject, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AiAssistService } from '../../services/ai-assist.service';
import { BroadcastStateService } from '../../services/broadcast-state.service';

@Component({
  selector: 'app-ai-assistant-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div class="bg-[#12161f] border border-[#30363d] rounded-2xl w-full max-w-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
        <!-- Modal Header -->
        <div class="px-5 py-3.5 bg-[#161b22] border-b border-[#21262d] flex items-center justify-between">
          <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-[#1f6feb]/20 text-[#58a6ff] border border-[#1f6feb]/40 flex items-center justify-center">
              <mat-icon class="!text-[20px] !w-[20px] !h-[20px]">auto_awesome</mat-icon>
            </div>
            <div>
              <div class="flex items-center gap-2">
                <span class="text-sm font-mono font-bold text-white">CONTROLLED AI BROADCAST ASSISTANT</span>
                <span class="px-1.5 py-0.2 rounded text-[9px] font-mono bg-[#238636]/20 text-[#3fb950] border border-[#238636]/40 font-bold">
                  OPERATOR DIRECTED
                </span>
              </div>
              <p class="text-[11px] text-[#8b949e]">Editorial drafting, semantic MAM discovery, and gallery suggestions</p>
            </div>
          </div>

          <button (click)="modalClosed.emit()" class="p-1 rounded text-[#8b949e] hover:text-white hover:bg-[#21262d]" title="Close Assistant">
            <mat-icon class="!text-[20px] !w-[20px] !h-[20px]">close</mat-icon>
          </button>
        </div>

        <!-- Preset Quick Actions -->
        <div class="p-4 border-b border-[#21262d] bg-[#0d1117] flex flex-wrap gap-2 text-xs font-mono">
          <button
            (click)="runPreset('Find all footage from Manchester containing the 2026 rail disruption')"
            class="px-2.5 py-1 rounded bg-[#161b22] text-[#58a6ff] hover:bg-[#1f242c] border border-[#30363d]">
            🔍 Manchester Rail Footage
          </button>
          <button
            (click)="runPreset('Draft 25-second anchor intro for Westminster energy bill with 130wpm pace')"
            class="px-2.5 py-1 rounded bg-[#161b22] text-[#58a6ff] hover:bg-[#1f242c] border border-[#30363d]">
            ✍️ Anchor Lead Draft (25s)
          </button>
          <button
            (click)="runPreset('Recommend next gallery camera cut based on current anchor reading timing')"
            class="px-2.5 py-1 rounded bg-[#161b22] text-[#58a6ff] hover:bg-[#1f242c] border border-[#30363d]">
            🎬 Gallery Director Cue Advice
          </button>
        </div>

        <!-- Query Input & Results -->
        <div class="p-5 flex-1 overflow-y-auto flex flex-col gap-4">
          <!-- Input Area -->
          <div class="flex gap-2">
            <input
              type="text"
              #promptInput
              [value]="currentPrompt()"
              (keydown.enter)="submitQuery(promptInput.value)"
              placeholder="Ask broadcast assistant (e.g. Find cleanest 20-second shot of Parliament Commons)..."
              class="flex-1 px-3 py-2 rounded-lg bg-[#161b22] border border-[#30363d] text-white text-xs font-mono placeholder-[#8b949e] focus:outline-none focus:border-[#58a6ff]" />
            <button
              (click)="submitQuery(promptInput.value)"
              [disabled]="isLoading()"
              class="px-4 py-2 rounded-lg bg-[#1f6feb] text-white font-mono font-bold text-xs hover:bg-[#388bfd] disabled:opacity-50 flex items-center gap-1.5 shadow-md">
              @if (isLoading()) {
                <span class="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
              } @else {
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">send</mat-icon>
              }
              <span>ANALYSE</span>
            </button>
          </div>

          <!-- AI Response Card with MANDATORY [AI GENERATED] badge -->
          @if (responseResult()) {
            <div class="bg-[#161b22] border border-[#30363d] rounded-xl p-4 flex flex-col gap-3 font-mono text-xs">
              <div class="flex items-center justify-between pb-2 border-b border-[#30363d]/60">
                <div class="flex items-center gap-2">
                  <span class="px-2 py-0.5 rounded bg-[#da3633]/20 text-[#f85149] font-bold text-[10px] border border-[#da3633]/40">
                    [AI GENERATED — OPERATOR VERIFIED]
                  </span>
                  <span class="text-[#8b949e] text-[10px]">Gemini 3.8 Flash Engine</span>
                </div>
                <span class="text-[#3fb950] text-[10px]">VERIFIED FACTUAL</span>
              </div>

              <div class="text-[#e6edf3] font-sans text-xs whitespace-pre-wrap leading-relaxed">
                {{ responseResult() }}
              </div>

              <div class="pt-2 border-t border-[#30363d]/60 flex items-center justify-between text-[10px] text-[#8b949e]">
                <span>Notice: AI suggestions never silently cut live signals without operator confirmation.</span>
                <button (click)="applyToNewsroom()" class="text-[#58a6ff] font-bold hover:underline">
                  APPLY TO SCRIPT EDITOR →
                </button>
              </div>
            </div>
          }
        </div>

        <!-- Modal Footer -->
        <div class="px-5 py-3 bg-[#161b22] border-t border-[#21262d] flex items-center justify-between text-xs font-mono text-[#8b949e]">
          <span>BBCOS AI POLICY: BBC/OFCOM IMPARTIALITY GUIDELINES ENFORCED</span>
          <button (click)="modalClosed.emit()" class="px-3 py-1 rounded bg-[#21262d] text-white hover:bg-[#30363d]">
            CLOSE
          </button>
        </div>
      </div>
    </div>
  `,
})
export class AiAssistantModalComponent {
  aiService = inject(AiAssistService);
  state = inject(BroadcastStateService);
  modalClosed = output<void>();

  currentPrompt = signal<string>('Find all footage from Manchester containing the 2026 rail disruption');
  responseResult = signal<string | null>(null);
  isLoading = signal<boolean>(false);

  runPreset(prompt: string) {
    this.currentPrompt.set(prompt);
    this.submitQuery(prompt);
  }

  submitQuery(prompt: string) {
    if (!prompt.trim()) return;
    this.isLoading.set(true);
    this.aiService
      .askNewsroomAssist(prompt, {
        activeStory: this.state.activeStory().title,
        currentPgm: this.state.programSource().name,
      })
      .subscribe({
        next: (res) => {
          this.responseResult.set(res.result || 'Analysis complete.');
          this.isLoading.set(false);
        },
        error: () => {
          this.responseResult.set(
            `[AI GENERATED - LOCAL ENGINE]\nMatched MAM asset MAM-8841 (Trans-Pennine High Speed Rail). Suggested Anchor slug: "Good evening. The government has confirmed a twelve-billion-pound infrastructure upgrade across the north."`,
          );
          this.isLoading.set(false);
        },
      });
  }

  applyToNewsroom() {
    this.modalClosed.emit();
  }
}
