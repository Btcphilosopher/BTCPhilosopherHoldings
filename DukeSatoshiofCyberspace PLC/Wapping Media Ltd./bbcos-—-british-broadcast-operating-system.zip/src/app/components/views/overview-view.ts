import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastStateService } from '../../services/broadcast-state.service';

@Component({
  selector: 'app-overview-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col p-4 gap-4 overflow-y-auto bg-[#0b0e14]">
      <!-- Title & Headline Status -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-[#21262d]">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-base font-bold font-mono text-white tracking-wide">BROADCAST SIGNAL FABRIC & END-TO-END CHAIN</h1>
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#238636]/20 text-[#3fb950] border border-[#238636]/40">ALL FLOWS NOMINAL</span>
          </div>
          <p class="text-xs text-[#8b949e] font-sans mt-0.5">
            Every signal, frame, audio channel, event, and metadata is strictly traceable from acquisition to UK audience distribution.
          </p>
        </div>

        <!-- Quick Telemetry Stats -->
        <div class="flex items-center gap-3">
          <div class="px-3 py-1.5 rounded bg-[#161b22] border border-[#30363d] font-mono text-xs">
            <span class="text-[#8b949e]">TX SERVICE:</span>
            <span class="text-white font-bold ml-1">BRITANNIA 1 HD</span>
          </div>
          <div class="px-3 py-1.5 rounded bg-[#161b22] border border-[#30363d] font-mono text-xs">
            <span class="text-[#8b949e]">OTT REACH:</span>
            <span class="text-[#58a6ff] font-bold ml-1">2,957,000 CONCURRENT</span>
          </div>
        </div>
      </div>

      <!-- End-to-End Visual Broadcast Graph -->
      <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-4 shadow-md">
        <div class="flex items-center justify-between mb-3">
          <div class="text-xs font-mono font-semibold text-[#8b949e] uppercase flex items-center gap-2">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#58a6ff]">account_tree</mat-icon>
            <span>End-to-End Traceable Architecture</span>
          </div>
          <div class="text-[11px] font-mono text-[#8b949e]">
            Click any node below to inspect real-time stream parameters
          </div>
        </div>

        <!-- Horizontal Flow Ribbon -->
        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
          @for (step of chainSteps; track step.id) {
            <button
              (click)="selectedStep.set(step)"
              [class.bg-[#1f6feb]/20]="selectedStep().id === step.id"
              [class.border-[#1f6feb]]="selectedStep().id === step.id"
              [class.bg-[#161b22]]="selectedStep().id !== step.id"
              [class.border-[#30363d]]="selectedStep().id !== step.id"
              class="p-2.5 rounded-lg border text-left transition-all hover:bg-[#1f242c] flex flex-col justify-between h-24 relative group">
              
              <div class="flex items-center justify-between w-full">
                <span class="text-[10px] font-mono font-bold text-[#8b949e]">{{ step.stepNumber }}</span>
                <span class="w-2 h-2 rounded-full" [class.bg-[#3fb950]]="step.status === 'OK'" [class.bg-[#d29922]]="step.status === 'WARN'"></span>
              </div>

              <div>
                <div class="text-xs font-mono font-bold text-white group-hover:text-[#58a6ff] transition-colors leading-tight">
                  {{ step.name }}
                </div>
                <div class="text-[10px] text-[#8b949e] font-sans truncate mt-0.5">
                  {{ step.shortSpec }}
                </div>
              </div>

              @if (selectedStep().id === step.id) {
                <div class="absolute -bottom-1 left-4 right-4 h-0.5 bg-[#58a6ff] rounded-full"></div>
              }
            </button>
          }
        </div>
      </div>

      <!-- Two Column Inspector & Real-time Live Signal Matrix -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 flex-1">
        <!-- Left: Selected Node Deep Traceability Inspector -->
        <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
              <div class="flex items-center gap-2 font-mono text-xs font-bold text-white">
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#58a6ff]">search</mat-icon>
                <span>NODE INSPECTOR: {{ selectedStep().name }}</span>
              </div>
              <span class="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-[#238636]/20 text-[#3fb950]">
                TRACE ID: {{ selectedStep().traceId }}
              </span>
            </div>

            <div class="mt-3 space-y-2.5 text-xs font-mono">
              <div class="bg-[#161b22] p-2 rounded border border-[#30363d]/60">
                <div class="text-[10px] text-[#8b949e]">DESCRIPTION</div>
                <div class="text-[#e6edf3] font-sans text-xs mt-0.5">{{ selectedStep().description }}</div>
              </div>

              <div class="grid grid-cols-2 gap-2">
                <div class="bg-[#161b22] p-2 rounded border border-[#30363d]/60">
                  <div class="text-[10px] text-[#8b949e]">SMPTE STANDARD</div>
                  <div class="text-[#58a6ff] font-bold">{{ selectedStep().standard }}</div>
                </div>
                <div class="bg-[#161b22] p-2 rounded border border-[#30363d]/60">
                  <div class="text-[10px] text-[#8b949e]">LATENCY</div>
                  <div class="text-[#3fb950] font-bold">{{ selectedStep().latency }}</div>
                </div>
              </div>

              <div class="bg-[#161b22] p-2 rounded border border-[#30363d]/60">
                <div class="text-[10px] text-[#8b949e]">PAYLOAD & IP MULTICAST FLOW</div>
                <div class="text-white text-[11px] truncate mt-0.5">{{ selectedStep().ipFlow }}</div>
              </div>

              <div class="bg-[#161b22] p-2 rounded border border-[#30363d]/60">
                <div class="text-[10px] text-[#8b949e]">PROVENANCE & INTEGRITY HASH</div>
                <div class="text-[#8b949e] text-[10px] font-mono break-all mt-0.5">{{ selectedStep().hash }}</div>
              </div>
            </div>
          </div>

          <div class="pt-3 border-t border-[#21262d] flex items-center justify-between text-[11px] font-mono text-[#8b949e]">
            <span>ENGINEERING STATE: NOMINAL</span>
            <span class="text-white">VERIFIED 25fps</span>
          </div>
        </div>

        <!-- Centre & Right: Active Sources & Transmission Fabric -->
        <div class="lg:col-span-2 bg-[#12161f] border border-[#21262d] rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
              <div class="flex items-center gap-2 font-mono text-xs font-bold text-white">
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#f85149]">sensors</mat-icon>
                <span>LIVE SIGNAL FABRIC MATRIX (SMPTE ST 2110 IP STUDIO)</span>
              </div>
              <div class="text-[10px] font-mono text-[#8b949e]">
                12 ACTIVE FLOWS • PTP LOCKED
              </div>
            </div>

            <!-- Signal Table -->
            <div class="mt-3 overflow-x-auto">
              <table class="w-full text-left font-mono text-xs border-collapse">
                <thead>
                  <tr class="text-[10px] text-[#8b949e] border-b border-[#30363d]/60">
                    <th class="pb-1.5">TALLY</th>
                    <th class="pb-1.5">CODE</th>
                    <th class="pb-1.5">NAME</th>
                    <th class="pb-1.5">FACILITY</th>
                    <th class="pb-1.5">FORMAT</th>
                    <th class="pb-1.5">MULTICAST IP</th>
                    <th class="pb-1.5 text-right">LATENCY</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#21262d]/40">
                  @for (src of state.sources(); track src.id) {
                    <tr class="hover:bg-[#161b22] transition-colors">
                      <td class="py-1.5">
                        <span class="px-1.5 py-0.5 rounded text-[9px] font-bold"
                          [class.bg-[#da3633]]="src.tally === 'PROGRAM'"
                          [class.text-white]="src.tally === 'PROGRAM'"
                          [class.bg-[#238636]]="src.tally === 'PREVIEW'"
                          [class.text-white]="src.tally === 'PREVIEW'"
                          [class.bg-[#21262d]]="src.tally === 'STANDBY' || src.tally === 'OFF'"
                          [class.text-[#8b949e]]="src.tally === 'STANDBY' || src.tally === 'OFF'">
                          {{ src.tally }}
                        </span>
                      </td>
                      <td class="py-1.5 font-bold text-white">{{ src.code }}</td>
                      <td class="py-1.5 text-[#e6edf3] truncate max-w-[140px]">{{ src.name }}</td>
                      <td class="py-1.5 text-[#8b949e]">{{ src.location }}</td>
                      <td class="py-1.5 text-[#58a6ff]">{{ src.format }}</td>
                      <td class="py-1.5 text-[#8b949e] text-[11px]">{{ src.multicastIp }}</td>
                      <td class="py-1.5 text-right text-[#3fb950] font-semibold">{{ src.latencyMs }}ms</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>

          <!-- Bottom Summary Bar -->
          <div class="pt-3 border-t border-[#21262d] grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
            <div class="p-2 rounded bg-[#161b22] border border-[#30363d]/40">
              <span class="text-[10px] text-[#8b949e] block">PTP JITTER</span>
              <span class="text-[#58a6ff] font-bold">12 ns (IEEE 1588)</span>
            </div>
            <div class="p-2 rounded bg-[#161b22] border border-[#30363d]/40">
              <span class="text-[10px] text-[#8b949e] block">PACKET LOSS</span>
              <span class="text-[#3fb950] font-bold">0.000% (Hitless 2022-7)</span>
            </div>
            <div class="p-2 rounded bg-[#161b22] border border-[#30363d]/40">
              <span class="text-[10px] text-[#8b949e] block">DTT MUX STATUS</span>
              <span class="text-white font-bold">6 SITES 100% OK</span>
            </div>
            <div class="p-2 rounded bg-[#161b22] border border-[#30363d]/40">
              <span class="text-[10px] text-[#8b949e] block">R128 INTEGRATED</span>
              <span class="text-[#3fb950] font-bold">-23.0 LUFS</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class OverviewViewComponent {
  state = inject(BroadcastStateService);

  readonly chainSteps = [
    {
      id: 'step_acq',
      stepNumber: '01',
      name: 'ACQUISITION',
      shortSpec: '4K/HD Cameras & OBs',
      status: 'OK',
      traceId: 'FLOW-ACQ-8910',
      description: 'Studio A pedestals, Salford & Westminster OB units capturing 1080p50 10-bit 4:2:2 uncompressed.',
      standard: 'SMPTE ST 2110-20/30/40',
      latency: '1.4 ms',
      ipFlow: '239.255.10.11:5004 (Video) + 239.255.10.12:5004 (Audio)',
      hash: 'sha256:7f49c0d12e8b456a19f0293847291a2b',
    },
    {
      id: 'step_ing',
      stepNumber: '02',
      name: 'MEDIA INGEST',
      shortSpec: 'Auto-QC & Proxy',
      status: 'OK',
      traceId: 'INGEST-CLUSTER-04',
      description: 'Automated file ingest, checksum verification, video black/freeze detection, and proxy generation.',
      standard: 'AS-11 UK DPP / ProRes HQ',
      latency: 'Instantaneous + Async QC',
      ipFlow: 's3://bbcos-ingest-london/raw/2026/09/28/',
      hash: 'sha256:a7b8e9c0128456f913d80a32e185cba9',
    },
    {
      id: 'step_mam',
      stepNumber: '03',
      name: 'MAM ASSETS',
      shortSpec: 'Provenance & Rights',
      status: 'OK',
      traceId: 'URN-BBCOS-MAM-8841',
      description: 'Centralized media repository with 16-channel audio tagging, Ofcom flash compliance, and metadata ledger.',
      standard: 'EBU Core / SMPTE 2071',
      latency: 'Sub-millisecond indexing',
      ipFlow: 'urn:bbcos:mam:2026:asset-8841',
      hash: 'sha256:9f8e7d6c5b4a3210ef87654321098765',
    },
    {
      id: 'step_nrcs',
      stepNumber: '04',
      name: 'NEWSROOM',
      shortSpec: 'Assignments & Script',
      status: 'OK',
      traceId: 'NRCS-STORY-01',
      description: 'Journalist assignment board, 2-column broadcast script editor with 130wpm timing and teleprompter slugs.',
      standard: 'MOS Protocol v4.0 / JSON',
      latency: 'Zero editor drift',
      ipFlow: 'mos://nrcs.london.bbcos.internal/roStory',
      hash: 'sha256:3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f80',
    },
    {
      id: 'step_gal',
      stepNumber: '05',
      name: 'GALLERY MIXER',
      shortSpec: 'Vision & 10ch Audio',
      status: 'OK',
      traceId: 'GALLERY-A-VM01',
      description: 'Vision mixer with Cut, Mix, Dip, Wipe, DSK bugs, and 10-channel audio console locked to -23 LUFS.',
      standard: 'SMPTE 2110 / EBU R128',
      latency: '0.8 ms (1 Frame)',
      ipFlow: '239.255.10.100:5004 (PGM BUS)',
      hash: 'sha256:5566778899aabbccddeeff0011223344',
    },
    {
      id: 'step_mcr',
      stepNumber: '06',
      name: 'MASTER CONTROL',
      shortSpec: 'Playout & Continuity',
      status: 'OK',
      traceId: 'MCR-NODE-TX1',
      description: 'Deterministic 24/7 automation, hitless SMPTE 2022-7 failover, and automated opt-out junction switching.',
      standard: 'SCTE-35 / EBU R128',
      latency: 'Frame-deterministic sync',
      ipFlow: '239.255.99.1:5004 (Master TX-A)',
      hash: 'sha256:11223344556677889900aabbccddeeff',
    },
    {
      id: 'step_tx',
      stepNumber: '07',
      name: 'TRANSMISSION',
      shortSpec: 'DTT & Low Latency OTT',
      status: 'OK',
      traceId: 'TX-DTT-PSB1',
      description: 'DVB-T2 Freeview multiplex distribution to Crystal Palace, Winter Hill, Wenvoe, Black Hill, and Divis.',
      standard: 'DVB-T2 / DASH-CMAF LL',
      latency: '1.2s LL-CMAF / Direct RF',
      ipFlow: 'udp://239.255.200.1:1234 (DVB MUX-A)',
      hash: 'sha256:eeff00112233445566778899aabbccdd',
    },
    {
      id: 'step_aud',
      stepNumber: '08',
      name: 'AUDIENCE & ACCESS',
      shortSpec: 'Subtitles & Companion',
      status: 'OK',
      traceId: 'AUDIENCE-HBBTV-SYNC',
      description: 'Live EBU-TT subtitles, Audio Description, BSL signer PIP, and HbbTV DVB-CSS companion screen synchronization.',
      standard: 'EBU-TT / DVB-CSS / HbbTV 2',
      latency: 'Synchronized to audio clock',
      ipFlow: 'wss://companion.bbcos.tv/sync/feed',
      hash: 'sha256:c0d1e2f3a4b5c6d7e8f90123456789ab',
    },
  ];

  readonly selectedStep = signal(this.chainSteps[0]);
}
