import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastStateService } from '../../services/broadcast-state.service';
import { NewsAssignment, ScriptBlock } from '../../models/broadcast.models';

@Component({
  selector: 'app-newsroom-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col p-4 gap-4 overflow-y-auto bg-[#0b0e14]">
      <!-- Header Bar: Mode Toggle (Assignment Desk vs Script Editor vs Prompter) -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#21262d]">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-base font-bold font-mono text-white tracking-wide">NEWSROOM COMPUTER SYSTEM (NRCS)</h1>
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#1f6feb]/20 text-[#58a6ff] border border-[#1f6feb]/40">
              MOS PROTOCOL INTEGRATED
            </span>
          </div>
          <p class="text-xs text-[#8b949e] font-sans mt-0.5">
            Editorial assignments, two-column split broadcast scripts, 130wpm pace estimation, and teleprompter sync.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <div class="flex bg-[#161b22] border border-[#30363d] rounded p-0.5 text-xs font-mono">
            <button
              (click)="activeSubTab.set('assignments')"
              [class.bg-[#1f6feb]]="activeSubTab() === 'assignments'"
              [class.text-white]="activeSubTab() === 'assignments'"
              [class.text-[#8b949e]]="activeSubTab() !== 'assignments'"
              class="px-3 py-1 rounded font-semibold transition-colors">
              ASSIGNMENTS DESK
            </button>
            <button
              (click)="activeSubTab.set('script')"
              [class.bg-[#1f6feb]]="activeSubTab() === 'script'"
              [class.text-white]="activeSubTab() === 'script'"
              [class.text-[#8b949e]]="activeSubTab() !== 'script'"
              class="px-3 py-1 rounded font-semibold transition-colors">
              STORY SCRIPT EDITOR
            </button>
            <button
              (click)="activeSubTab.set('prompter')"
              [class.bg-[#da3633]]="activeSubTab() === 'prompter'"
              [class.text-white]="activeSubTab() === 'prompter'"
              [class.text-[#8b949e]]="activeSubTab() !== 'prompter'"
              class="px-3 py-1 rounded font-semibold transition-colors flex items-center gap-1">
              <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">tv</mat-icon>
              <span>TELEPROMPTER</span>
            </button>
          </div>
        </div>
      </div>

      <!-- VIEW 1: ASSIGNMENT DESK KANBAN -->
      @if (activeSubTab() === 'assignments') {
        <div class="flex-1 flex flex-col gap-3">
          <div class="flex items-center justify-between">
            <span class="text-xs font-mono text-[#8b949e]">UK NATIONAL & REGIONAL FIELD ASSIGNMENTS</span>
            <div class="text-xs font-mono text-white">5 ACTIVE ASSIGNMENTS</div>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3 flex-1 items-start">
            @for (stage of stages; track stage.key) {
              <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-3 flex flex-col gap-2 min-h-[350px]">
                <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
                  <span class="text-xs font-mono font-bold text-white">{{ stage.label }}</span>
                  <span class="px-1.5 py-0.5 rounded text-[10px] font-mono bg-[#161b22] text-[#8b949e]">
                    {{ getAssignmentsForStage(stage.key).length }}
                  </span>
                </div>

                <div class="flex flex-col gap-2 flex-1">
                  @for (asg of getAssignmentsForStage(stage.key); track asg.id) {
                    <div class="bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-xs font-sans shadow-sm hover:border-[#58a6ff] transition-all cursor-pointer">
                      <div class="flex items-center justify-between mb-1">
                        <span class="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded"
                          [class.bg-[#da3633]/20]="asg.priority === 'BREAKING'"
                          [class.text-[#f85149]]="asg.priority === 'BREAKING'"
                          [class.bg-[#d29922]/20]="asg.priority === 'PRIORITY'"
                          [class.text-[#d29922]]="asg.priority === 'PRIORITY'"
                          [class.bg-[#21262d]]="asg.priority === 'ROUTINE'"
                          [class.text-[#8b949e]]="asg.priority === 'ROUTINE'">
                          {{ asg.priority }}
                        </span>
                        <span class="text-[10px] font-mono text-[#58a6ff] font-bold">{{ asg.location }}</span>
                      </div>

                      <div class="font-bold text-white text-xs line-clamp-2 mt-1">
                        {{ asg.storyTitle }}
                      </div>

                      <div class="mt-2 pt-2 border-t border-[#30363d]/40 flex flex-col gap-0.5 text-[11px] text-[#8b949e]">
                        <div class="flex items-center gap-1">
                          <mat-icon class="!text-[12px] !w-[12px] !h-[12px]">person</mat-icon>
                          <span class="truncate">{{ asg.reporter }}</span>
                        </div>
                        <div class="flex items-center gap-1">
                          <mat-icon class="!text-[12px] !w-[12px] !h-[12px]">schedule</mat-icon>
                          <span>Deadline: {{ asg.deadlineTime }}</span>
                        </div>
                      </div>

                      <div class="mt-2 flex items-center justify-between text-[10px] font-mono">
                        <span class="text-[#3fb950] font-semibold">{{ asg.legalStatus }}</span>
                        <button (click)="loadStoryForEdit()" class="text-[#58a6ff] hover:underline">
                          EDIT SCRIPT →
                        </button>
                      </div>
                    </div>
                  }
                </div>
              </div>
            }
          </div>
        </div>
      }

      <!-- VIEW 2: TWO-COLUMN SCRIPT EDITOR -->
      @if (activeSubTab() === 'script') {
        <div class="flex-1 flex flex-col lg:flex-row gap-4">
          <!-- Left Main: Script Blocks -->
          <div class="flex-1 bg-[#12161f] border border-[#21262d] rounded-xl p-4 flex flex-col gap-3">
            <!-- Story Meta Bar -->
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#21262d]">
              <div>
                <div class="flex items-center gap-2">
                  <span class="text-xs font-mono font-bold text-[#58a6ff]">{{ state.activeStory().slug }}</span>
                  <span class="text-xs font-mono px-2 py-0.5 rounded bg-[#238636]/20 text-[#3fb950] border border-[#238636]/40">
                    {{ state.activeStory().status }}
                  </span>
                </div>
                <h2 class="text-base font-bold text-white mt-1">{{ state.activeStory().title }}</h2>
                <div class="text-xs text-[#8b949e] mt-0.5 font-sans">
                  By {{ state.activeStory().author }} • Last updated: {{ state.activeStory().lastUpdated }}
                </div>
              </div>

              <!-- Metrics -->
              <div class="flex items-center gap-3 font-mono text-xs">
                <div class="px-2.5 py-1 rounded bg-[#161b22] border border-[#30363d]">
                  <span class="text-[#8b949e]">WORDS: </span>
                  <span class="text-white font-bold">{{ state.activeStory().wordsCount }}</span>
                </div>
                <div class="px-2.5 py-1 rounded bg-[#161b22] border border-[#30363d]">
                  <span class="text-[#8b949e]">EST. READ: </span>
                  <span class="text-[#3fb950] font-bold">{{ formatDuration(state.activeStory().estimatedDurationSec) }}</span>
                </div>
                <button
                  (click)="pushToRundown()"
                  class="px-3 py-1.5 rounded bg-[#1f6feb] text-white hover:bg-[#388bfd] font-mono font-bold text-xs flex items-center gap-1 shadow-md">
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">send</mat-icon>
                  <span>SEND TO RUNDOWN</span>
                </button>
              </div>
            </div>

            <!-- Two-Column Broadcast Script Rows -->
            <div class="flex-1 flex flex-col gap-2.5 overflow-y-auto">
              <div class="grid grid-cols-12 gap-2 text-[10px] font-mono font-bold text-[#8b949e] px-2 uppercase">
                <div class="col-span-4">CUE / VIDEO / AUDIO / GFX</div>
                <div class="col-span-8">PRESENTER / SPOKEN SCRIPT (130 WPM PACE)</div>
              </div>

              @for (block of state.activeStory().scriptBlocks; track block.id) {
                <div class="grid grid-cols-12 gap-3 p-3 rounded-lg bg-[#161b22] border border-[#30363d] hover:border-[#58a6ff]/60 transition-all text-xs font-mono">
                  <!-- Left Column: Technical Cues & Speaker -->
                  <div class="col-span-4 border-r border-[#30363d]/60 pr-3 flex flex-col justify-between">
                    <div>
                      <div class="flex items-center gap-1.5">
                        <span class="px-1.5 py-0.5 rounded text-[10px] font-bold"
                          [class.bg-[#da3633]/20]="block.type === 'ANCHOR'"
                          [class.text-[#f85149]]="block.type === 'ANCHOR'"
                          [class.bg-[#1f6feb]/20]="block.type === 'VO' || block.type === 'PKG'"
                          [class.text-[#58a6ff]]="block.type === 'VO' || block.type === 'PKG'"
                          [class.bg-[#d29922]/20]="block.type === 'SOT'"
                          [class.text-[#d29922]]="block.type === 'SOT'"
                          [class.bg-[#a371f7]/20]="block.type === 'GFX'"
                          [class.text-[#a371f7]]="block.type === 'GFX'">
                          {{ block.type }}
                        </span>
                        <span class="text-[#e6edf3] font-bold text-xs truncate">{{ block.speakerOrCue }}</span>
                      </div>

                      @if (block.mediaAssetId) {
                        <div class="mt-2 text-[10px] text-[#58a6ff] bg-[#0d1117] p-1 rounded border border-[#30363d] flex items-center gap-1">
                          <mat-icon class="!text-[12px] !w-[12px] !h-[12px]">movie</mat-icon>
                          <span class="truncate">MAM: {{ block.mediaAssetId }}</span>
                        </div>
                      }

                      @if (block.notes) {
                        <div class="mt-1 text-[10px] text-[#8b949e] italic">
                          Note: {{ block.notes }}
                        </div>
                      }
                    </div>

                    <div class="text-[10px] text-[#8b949e] mt-2">
                      Est: {{ block.estimatedDurationSec }}s
                    </div>
                  </div>

                  <!-- Right Column: Spoken Script -->
                  <div class="col-span-8 flex flex-col justify-between">
                    <textarea
                      rows="3"
                      [value]="block.text"
                      (input)="onScriptTextChange(block.id, $event)"
                      class="w-full bg-transparent text-[#e6edf3] font-sans text-sm leading-relaxed p-1 rounded focus:bg-[#0d1117] focus:outline-none focus:ring-1 focus:ring-[#58a6ff] resize-none"></textarea>

                    <div class="flex items-center justify-between pt-1 text-[10px] text-[#8b949e]">
                      <span>Words: {{ getWordCount(block.text) }}</span>
                      <span class="text-[#3fb950]">Teleprompter Slug Ready</span>
                    </div>
                  </div>
                </div>
              }
            </div>

            <!-- Add Script Block Trigger -->
            <div class="flex items-center gap-2 pt-2 border-t border-[#21262d]">
              <span class="text-xs font-mono text-[#8b949e]">INSERT BLOCK:</span>
              <button (click)="addBlock('ANCHOR')" class="px-2 py-1 rounded bg-[#161b22] text-[#f85149] font-mono text-xs border border-[#30363d] hover:bg-[#21262d]">+ ANCHOR</button>
              <button (click)="addBlock('VO')" class="px-2 py-1 rounded bg-[#161b22] text-[#58a6ff] font-mono text-xs border border-[#30363d] hover:bg-[#21262d]">+ VO</button>
              <button (click)="addBlock('SOT')" class="px-2 py-1 rounded bg-[#161b22] text-[#d29922] font-mono text-xs border border-[#30363d] hover:bg-[#21262d]">+ SOT</button>
              <button (click)="addBlock('LIVE')" class="px-2 py-1 rounded bg-[#161b22] text-[#3fb950] font-mono text-xs border border-[#30363d] hover:bg-[#21262d]">+ LIVE HIT</button>
              <button (click)="addBlock('GFX')" class="px-2 py-1 rounded bg-[#161b22] text-[#a371f7] font-mono text-xs border border-[#30363d] hover:bg-[#21262d]">+ GFX FULL</button>
            </div>
          </div>

          <!-- Right Sidebar: Linked MAM Media & News Fact Checker -->
          <div class="w-full lg:w-72 bg-[#12161f] border border-[#21262d] rounded-xl p-3 flex flex-col gap-3">
            <div class="text-xs font-mono font-bold text-white uppercase pb-1 border-b border-[#21262d]">
              LINKED MAM ASSETS
            </div>

            <div class="flex flex-col gap-2">
              @for (asset of state.mamAssets().slice(0, 2); track asset.id) {
                <div class="bg-[#161b22] border border-[#30363d] rounded p-2 text-xs font-mono">
                  <div class="flex items-center justify-between text-[10px] text-[#58a6ff]">
                    <span>{{ asset.slug }}</span>
                    <span class="text-[#3fb950]">{{ asset.durationTimecode }}</span>
                  </div>
                  <div class="text-white text-xs font-sans font-semibold mt-1 truncate">
                    {{ asset.title }}
                  </div>
                  <div class="text-[10px] text-[#8b949e] mt-1">QC: {{ asset.qcStatus }} • {{ asset.format }}</div>
                </div>
              }
            </div>

            <div class="text-xs font-mono font-bold text-white uppercase pt-2 pb-1 border-b border-[#21262d]">
              OFCOM COMPLIANCE CHECK
            </div>
            <div class="bg-[#161b22] p-2.5 rounded border border-[#30363d] text-xs font-mono text-[#8b949e] space-y-1.5">
              <div class="flex items-center justify-between">
                <span>Impartiality:</span>
                <span class="text-[#3fb950] font-bold">BALANCED</span>
              </div>
              <div class="flex items-center justify-between">
                <span>Copyright Rights:</span>
                <span class="text-[#3fb950] font-bold">CLEARED (UK)</span>
              </div>
              <div class="flex items-center justify-between">
                <span>Flash Rate Safety:</span>
                <span class="text-[#3fb950] font-bold">PASSED</span>
              </div>
            </div>
          </div>
        </div>
      }

      <!-- VIEW 3: TELEPROMPTER VIEW -->
      @if (activeSubTab() === 'prompter') {
        <div class="flex-1 bg-black border-2 border-[#30363d] rounded-2xl p-8 flex flex-col justify-between relative overflow-hidden shadow-2xl">
          <!-- Prompter Top HUD -->
          <div class="flex items-center justify-between pb-4 border-b border-white/20 font-mono text-sm z-10">
            <div class="flex items-center gap-3">
              <span class="w-3 h-3 rounded-full bg-[#da3633] animate-pulse"></span>
              <span class="text-white font-bold tracking-widest">STUDIO A AUTOCUE • TELEPROMPTER 01</span>
            </div>
            <div class="flex items-center gap-4 text-white">
              <span>TC: {{ state.masterTimecode() }}</span>
              <span class="text-[#58a6ff]">SPEED: 130 WPM</span>
            </div>
          </div>

          <!-- Prompter High Legibility Text Stream -->
          <div class="flex-1 py-8 overflow-y-auto max-w-4xl mx-auto flex flex-col gap-6 text-white font-sans">
            @for (block of state.activeStory().scriptBlocks; track block.id) {
              <div class="border-b border-white/10 pb-4">
                <div class="font-mono text-xs font-bold text-[#58a6ff] tracking-widest mb-1 uppercase">
                  [{{ block.speakerOrCue }}]
                </div>
                <div class="text-2xl sm:text-3xl font-bold leading-relaxed tracking-wide text-[#f0f6fc]">
                  {{ block.text }}
                </div>
              </div>
            }
          </div>

          <!-- Prompter Bottom Bar -->
          <div class="pt-4 border-t border-white/20 flex items-center justify-between font-mono text-xs text-[#8b949e]">
            <span>CAMERA 01 RIG • PEDESTAL 1 GLASS</span>
            <span class="text-[#3fb950]">TALENT SCRIPT LOCKED</span>
          </div>
        </div>
      }
    </div>
  `,
})
export class NewsroomViewComponent {
  state = inject(BroadcastStateService);
  activeSubTab = signal<'assignments' | 'script' | 'prompter'>('script');

  readonly stages: { key: NewsAssignment['status']; label: string }[] = [
    { key: 'NEW', label: 'NEW' },
    { key: 'ASSIGNED', label: 'ASSIGNED' },
    { key: 'SHOOTING', label: 'SHOOTING' },
    { key: 'EDITING', label: 'EDITING' },
    { key: 'READY', label: 'READY' },
  ];

  getAssignmentsForStage(status: NewsAssignment['status']) {
    return this.state.assignments().filter((a) => a.status === status);
  }

  loadStoryForEdit() {
    this.activeSubTab.set('script');
  }

  onScriptTextChange(blockId: string, event: Event) {
    const val = (event.target as HTMLTextAreaElement).value;
    this.state.updateScriptBlock(blockId, val);
  }

  getWordCount(text: string) {
    return text.trim() ? text.trim().split(/\s+/).length : 0;
  }

  formatDuration(sec: number) {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  addBlock(type: ScriptBlock['type']) {
    const newBlock: ScriptBlock = {
      id: `blk_${Date.now()}`,
      type,
      speakerOrCue: `${type} (STUDIO)`,
      text: 'Enter script or technical cue text here...',
      estimatedDurationSec: 15,
    };
    this.state.activeStory.update((story) => ({
      ...story,
      scriptBlocks: [...story.scriptBlocks, newBlock],
    }));
  }

  pushToRundown() {
    this.state.activeStory.update((s) => ({ ...s, status: 'READY_RUNDOWN' }));
  }
}
