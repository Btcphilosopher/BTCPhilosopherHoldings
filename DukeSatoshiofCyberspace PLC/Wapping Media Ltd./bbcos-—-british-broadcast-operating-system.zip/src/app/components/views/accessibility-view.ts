import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastStateService } from '../../services/broadcast-state.service';

@Component({
  selector: 'app-accessibility-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col p-4 gap-4 overflow-y-auto bg-[#0b0e14]">
      <!-- Header Bar -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#21262d]">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#58a6ff]">closed_caption</mat-icon>
            <h1 class="text-base font-bold font-mono text-white tracking-wide">
              SUBTITLES, AUDIO DESCRIPTION & ACCESSIBILITY ENGINE
            </h1>
          </div>
          <p class="text-xs text-[#8b949e] font-sans mt-0.5">
            EBU-TT / Teletext 888 live stenography, Audio Description (AD) ducking timeline, and BSL sign language feed.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <button
            (click)="toggleBslPip()"
            [class.bg-[#1f6feb]]="state.bslSignerPipActive()"
            [class.text-white]="state.bslSignerPipActive()"
            [class.bg-[#161b22]]="!state.bslSignerPipActive()"
            [class.text-[#8b949e]]="!state.bslSignerPipActive()"
            class="px-3 py-1.5 rounded border border-[#30363d] font-bold flex items-center gap-1.5">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">sign_language</mat-icon>
            <span>BSL SIGNER PiP: {{ state.bslSignerPipActive() ? 'ON' : 'OFF' }}</span>
          </button>
        </div>
      </div>

      <!-- Live Subtitle Stream & Teletext 888 Monitor -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1 items-stretch">
        <!-- Left: Live Subtitle Cues Ledger (Cols 1-7) -->
        <div class="lg:col-span-7 bg-[#12161f] border border-[#21262d] rounded-xl p-4 shadow-md flex flex-col justify-between gap-3 font-mono text-xs">
          <div>
            <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
              <span class="font-bold text-white uppercase flex items-center gap-2">
                <span>EBU-TT LIVE STENOGRAPHY FEED (OP-47)</span>
              </span>
              <span class="text-[10px] text-[#3fb950] font-bold">LIVE STENOGRAPHER: ACTIVE</span>
            </div>

            <!-- Cues List -->
            <div class="mt-3 space-y-2">
              @for (cue of state.subtitleCues(); track cue.id) {
                <div class="bg-[#161b22] border border-[#30363d] rounded-lg p-3 flex flex-col gap-1 shadow-sm">
                  <div class="flex items-center justify-between text-[10px]">
                    <div class="flex items-center gap-2">
                      <span class="px-1.5 py-0.2 rounded font-bold"
                        [class.bg-[#d29922]/20]="cue.color === 'YELLOW'"
                        [class.text-[#d29922]]="cue.color === 'YELLOW'"
                        [class.bg-[#388bfd]/20]="cue.color === 'CYAN'"
                        [class.text-[#58a6ff]]="cue.color === 'CYAN'"
                        [class.bg-[#21262d]]="cue.color === 'WHITE'"
                        [class.text-white]="cue.color === 'WHITE'">
                        {{ cue.speaker }}
                      </span>
                      <span class="text-[#8b949e]">{{ cue.position }}</span>
                    </div>

                    <span class="text-white">{{ cue.startTimecode }} → {{ cue.endTimecode }}</span>
                  </div>

                  <div class="text-sm font-sans font-semibold text-white mt-1">
                    {{ cue.text }}
                  </div>
                </div>
              }
            </div>

            <!-- Stenography Quick Input Bar -->
            <div class="mt-3 pt-3 border-t border-[#21262d] flex gap-2">
              <input
                type="text"
                placeholder="Type live subtitle caption..."
                class="flex-1 px-3 py-1.5 rounded bg-[#161b22] border border-[#30363d] text-white text-xs placeholder-[#8b949e] focus:outline-none focus:border-[#58a6ff]" />
              <button class="px-3 py-1.5 rounded bg-[#1f6feb] text-white font-bold text-xs hover:bg-[#388bfd]">
                PUSH CUE
              </button>
            </div>
          </div>

          <div class="pt-2 border-t border-[#21262d] flex items-center justify-between text-[10px] text-[#8b949e]">
            <span>FORMAT: EBU-TT / W3C TTML / OP-47</span>
            <span class="text-[#3fb950]">SYNCHRONIZED WITH AUDIO CLOCK</span>
          </div>
        </div>

        <!-- Right: Audio Description Script & Compliance (Cols 8-12) -->
        <div class="lg:col-span-5 bg-[#12161f] border border-[#21262d] rounded-xl p-4 shadow-md flex flex-col justify-between gap-3 font-mono text-xs">
          <div>
            <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
              <span class="font-bold text-white uppercase">AUDIO DESCRIPTION (AD) TIMELINE</span>
              <span class="text-[#58a6ff] text-[10px] font-bold">SYNTH VOICE CH 16</span>
            </div>

            <div class="mt-3 space-y-2 text-[11px]">
              <div class="bg-[#161b22] border border-[#30363d] rounded p-2.5 space-y-1">
                <div class="flex items-center justify-between text-[10px] text-[#8b949e]">
                  <span class="text-[#58a6ff] font-bold">TC: 18:00:24:00 (Dur: 03s)</span>
                  <span class="text-[#3fb950]">VO DUCK -6dB</span>
                </div>
                <div class="text-white font-sans text-xs">
                  "The presenter sits at a wide mahogany desk in the studio with graphics screens behind."
                </div>
              </div>

              <div class="bg-[#161b22] border border-[#30363d] rounded p-2.5 space-y-1">
                <div class="flex items-center justify-between text-[10px] text-[#8b949e]">
                  <span class="text-[#58a6ff] font-bold">TC: 18:01:32:00 (Dur: 04s)</span>
                  <span class="text-[#3fb950]">VO DUCK -6dB</span>
                </div>
                <div class="text-white font-sans text-xs">
                  "Aerial footage shows high-speed trains passing beneath yellow overhead power lines in a rural valley."
                </div>
              </div>
            </div>

            <!-- Accessibility Status Check -->
            <div class="mt-4 pt-3 border-t border-[#21262d]">
              <div class="text-[10px] font-bold text-white uppercase mb-2">OFCOM ACCESSIBILITY MANDATE TARGETS</div>
              <div class="space-y-1 text-[10px]">
                <div class="flex items-center justify-between text-[#8b949e]">
                  <span>Subtitles Delivery:</span>
                  <span class="text-[#3fb950] font-bold">100.0% (Target 90%)</span>
                </div>
                <div class="flex items-center justify-between text-[#8b949e]">
                  <span>Audio Description:</span>
                  <span class="text-[#3fb950] font-bold">22.4% (Target 10%)</span>
                </div>
                <div class="flex items-center justify-between text-[#8b949e]">
                  <span>Signing (BSL):</span>
                  <span class="text-[#3fb950] font-bold">6.8% (Target 5%)</span>
                </div>
              </div>
            </div>
          </div>

          <div class="pt-2 border-t border-[#21262d] flex items-center justify-between text-[10px] text-[#8b949e]">
            <span>COMPLIANCE: OFCOM CODE ON ACCESSIBILITY</span>
            <span class="text-[#3fb950]">FULLY COMPLIANT</span>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class AccessibilityViewComponent {
  state = inject(BroadcastStateService);

  toggleBslPip() {
    this.state.bslSignerPipActive.update((v) => !v);
  }
}
