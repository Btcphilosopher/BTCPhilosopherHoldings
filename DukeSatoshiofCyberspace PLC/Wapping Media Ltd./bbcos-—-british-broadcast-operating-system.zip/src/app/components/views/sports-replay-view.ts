import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastStateService } from '../../services/broadcast-state.service';

@Component({
  selector: 'app-sports-replay-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col p-4 gap-4 overflow-y-auto bg-[#0b0e14]">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#21262d]">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#58a6ff]">sports_soccer</mat-icon>
            <h1 class="text-base font-bold font-mono text-white tracking-wide">
              LIVE SPORTS PRODUCTION & EVS-STYLE REPLAY SERVER
            </h1>
          </div>
          <p class="text-xs text-[#8b949e] font-sans mt-0.5">
            Circular continuous rolling buffer (-10:00 to NOW), variable speed slow-motion (25-100%), and live scorebug controller.
          </p>
        </div>

        <!-- Live Scoreboard Controller -->
        <div class="flex items-center gap-2 bg-[#161b22] border border-[#30363d] px-3 py-1.5 rounded-lg font-mono text-xs shadow-sm">
          <span class="text-[#58a6ff] font-bold">{{ state.sportsScore().competition }}</span>
          <div class="flex items-center gap-2 text-white font-bold px-2 py-0.5 rounded bg-[#0d1117] border border-[#30363d]">
            <span>{{ state.sportsScore().homeTeam }}</span>
            <span class="text-[#3fb950] text-sm">{{ state.sportsScore().homeScore }} - {{ state.sportsScore().awayScore }}</span>
            <span>{{ state.sportsScore().awayTeam }}</span>
            <span class="text-[#f85149] text-[10px] ml-1">({{ state.sportsScore().matchMinute }})</span>
          </div>
          <button (click)="incrementHomeGoal()" class="px-1.5 py-0.5 rounded bg-[#1f6feb] text-white hover:bg-[#388bfd] font-bold text-[10px]">
            +HOME
          </button>
          <button (click)="incrementAwayGoal()" class="px-1.5 py-0.5 rounded bg-[#1f6feb] text-white hover:bg-[#388bfd] font-bold text-[10px]">
            +AWAY
          </button>
        </div>
      </div>

      <!-- Main Replay Quad Grid & Operator Console -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 flex-1 items-stretch">
        <!-- Replay Angles Grid (Cols 1-2) -->
        <div class="lg:col-span-2 bg-[#12161f] border border-[#21262d] rounded-xl p-4 shadow-md flex flex-col justify-between gap-3">
          <div>
            <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
              <span class="text-xs font-mono font-bold text-white uppercase">4-CAMERA CONTINUOUS REPLAY BUFFER (-10:00 TO NOW)</span>
              <span class="text-[10px] font-mono text-[#3fb950]">CIRCULAR INGEST BUFFER 100% OK</span>
            </div>

            <!-- Angles 3-Split Preview -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mt-3">
              @for (ang of state.replayAngles(); track ang.id) {
                <button
                  (click)="selectedAngleId.set(ang.id)"
                  [class.border-2]="true"
                  [class.border-[#58a6ff]]="selectedAngleId() === ang.id"
                  [class.border-[#30363d]]="selectedAngleId() !== ang.id"
                  class="bg-[#161b22] rounded-lg p-2 flex flex-col justify-between cursor-pointer hover:border-[#58a6ff]/80 transition-all shadow-sm text-left">
                  
                  <div class="flex items-center justify-between text-[10px] font-mono w-full">
                    <span class="font-bold text-white truncate">{{ ang.name }}</span>
                    <span class="text-[#3fb950] font-bold">{{ ang.speedMultiplier * 100 }}%</span>
                  </div>

                  <!-- Synthetic Angle Canvas -->
                  <div class="relative w-full aspect-video bg-[#090d13] rounded mt-1.5 overflow-hidden flex flex-col items-center justify-center border border-white/5">
                    <mat-icon class="!text-[24px] !w-[24px] !h-[24px] text-[#58a6ff]">slow_motion_video</mat-icon>
                    <span class="text-[9px] font-mono text-[#8b949e] mt-1">{{ ang.cameraSource }}</span>
                    
                    @if (ang.isCueing) {
                      <div class="absolute top-1 left-1 bg-[#da3633] px-1.5 py-0.2 rounded text-[8px] font-mono text-white font-bold">
                        CUED
                      </div>
                    }
                  </div>

                  <div class="flex items-center justify-between mt-1.5 text-[9px] font-mono text-[#8b949e] w-full">
                    <span>IN: -00:{{ 600 - ang.markInSec }}s</span>
                    <span>OUT: -00:{{ 600 - ang.markOutSec }}s</span>
                  </div>
                </button>
              }
            </div>

            <!-- Rolling Buffer Scrub Bar -->
            <div class="mt-4 pt-3 border-t border-[#21262d] flex flex-col gap-1.5 font-mono text-xs">
              <div class="flex items-center justify-between text-[10px] text-[#8b949e]">
                <span>-10:00 BUFFER START</span>
                <span class="text-[#58a6ff] font-bold">SCRUB POINT: -00:42s</span>
                <span class="text-[#3fb950] font-bold">LIVE EDGE (00:00)</span>
              </div>
              <input
                type="range"
                min="0"
                max="600"
                value="558"
                class="w-full accent-[#da3633] cursor-pointer bg-[#21262d] h-2 rounded-lg" />
            </div>
          </div>

          <!-- Stinger Transition to Program Button -->
          <div class="pt-2 border-t border-[#21262d] flex items-center justify-between">
            <span class="text-[10px] font-mono text-[#8b949e]">STINGER WIPE: 3D REPLAY STING A</span>
            <button
              (click)="triggerReplayTake()"
              class="px-4 py-2 rounded-lg bg-[#da3633] text-white hover:bg-[#f85149] font-mono font-bold text-xs flex items-center gap-1.5 shadow-md">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">replay</mat-icon>
              <span>TAKE REPLAY TO PROGRAM (STINGER)</span>
            </button>
          </div>
        </div>

        <!-- Replay Speed & Jog Wheel Controller Console (Col 3) -->
        <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-4 shadow-md flex flex-col justify-between gap-3 text-xs font-mono">
          <div>
            <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
              <span class="font-bold text-white uppercase">REPLAY OPERATOR CONSOLE</span>
              <span class="text-[#58a6ff]">EVS LSM/IPDP</span>
            </div>

            <!-- Variable Speed Buttons -->
            <div class="mt-3 space-y-1.5">
              <span class="text-[10px] text-[#8b949e] uppercase block">PLAYBACK SPEED MULTIPLIER:</span>
              <div class="grid grid-cols-2 gap-1.5">
                @for (spd of [0.25, 0.50, 0.75, 1.00]; track spd) {
                  <button
                    (click)="selectedSpeed.set(spd)"
                    [class.bg-[#1f6feb]]="selectedSpeed() === spd"
                    [class.text-white]="selectedSpeed() === spd"
                    [class.bg-[#161b22]]="selectedSpeed() !== spd"
                    [class.text-[#8b949e]]="selectedSpeed() !== spd"
                    class="py-2 rounded font-bold border border-[#30363d] hover:brightness-125">
                    {{ spd * 100 }}% {{ spd === 0.25 ? '(SUPER-SLO)' : '' }}
                  </button>
                }
              </div>
            </div>

            <!-- Clip Mark Controls -->
            <div class="mt-4 space-y-1.5">
              <span class="text-[10px] text-[#8b949e] uppercase block">CLIP MARKING:</span>
              <div class="grid grid-cols-2 gap-2">
                <button class="py-2.5 rounded bg-[#21262d] text-white hover:bg-[#30363d] font-bold border border-[#30363d]">
                  [ MARK IN
                </button>
                <button class="py-2.5 rounded bg-[#21262d] text-white hover:bg-[#30363d] font-bold border border-[#30363d]">
                  MARK OUT ]
                </button>
              </div>
            </div>

            <!-- Return to Live -->
            <div class="mt-4">
              <button
                (click)="state.cutToSource('src_cam_01')"
                class="w-full py-2.5 rounded bg-[#238636] text-white hover:bg-[#2ea043] font-bold border border-[#2ea043] flex items-center justify-center gap-1">
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">live_tv</mat-icon>
                <span>RETURN DIRECT TO LIVE</span>
              </button>
            </div>
          </div>

          <div class="pt-2 border-t border-[#21262d] flex items-center justify-between text-[10px] text-[#8b949e]">
            <span>SERVER: LONDON REPLAY 01</span>
            <span class="text-[#3fb950]">CLIP BUFFER SYNCED</span>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class SportsReplayViewComponent {
  state = inject(BroadcastStateService);
  selectedAngleId = signal<string>('rep_ang_2');
  selectedSpeed = signal<number>(0.25);

  incrementHomeGoal() {
    this.state.sportsScore.update((s) => ({ ...s, homeScore: s.homeScore + 1 }));
  }

  incrementAwayGoal() {
    this.state.sportsScore.update((s) => ({ ...s, awayScore: s.awayScore + 1 }));
  }

  triggerReplayTake() {
    this.state.cutToSource('src_rep_01');
  }
}
