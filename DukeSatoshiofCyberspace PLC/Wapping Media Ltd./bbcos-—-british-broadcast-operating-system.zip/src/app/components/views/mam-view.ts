import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastStateService } from '../../services/broadcast-state.service';

@Component({
  selector: 'app-mam-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col p-4 gap-4 overflow-y-auto bg-[#0b0e14]">
      <!-- Header Bar -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#21262d]">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#58a6ff]">video_library</mat-icon>
            <h1 class="text-base font-bold font-mono text-white tracking-wide">
              MEDIA ASSET MANAGEMENT (MAM) & AS-11/DPP INGEST
            </h1>
          </div>
          <p class="text-xs text-[#8b949e] font-sans mt-0.5">
            Frame-accurate player, jog/shuttle, subclip markers, automated QC engine, and broadcast provenance chain.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <input
            type="text"
            placeholder="Search MAM assets, tags, urns..."
            class="px-3 py-1 rounded bg-[#161b22] border border-[#30363d] text-xs font-mono text-white placeholder-[#8b949e] focus:outline-none focus:border-[#58a6ff] w-48 sm:w-64" />
        </div>
      </div>

      <!-- 3-Column Professional Media Suite (Browser | Player | Metadata & QC) -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1 items-stretch">
        <!-- Left: Category Browser & Asset Grid (Cols 1-3) -->
        <div class="lg:col-span-3 bg-[#12161f] border border-[#21262d] rounded-xl p-3 flex flex-col gap-3">
          <div class="text-xs font-mono font-bold text-white uppercase pb-1 border-b border-[#21262d] flex items-center justify-between">
            <span>MEDIA REPOSITORY</span>
            <span class="text-[10px] text-[#8b949e]">{{ state.mamAssets().length }} ITEMS</span>
          </div>

          <!-- Categories -->
          <div class="flex flex-wrap gap-1 text-[10px] font-mono">
            @for (cat of ['ALL', 'NEWS', 'SPORT', 'DOCUMENTARY', 'ARCHIVE']; track cat) {
              <button
                (click)="selectedCategory.set(cat)"
                [class.bg-[#1f6feb]]="selectedCategory() === cat"
                [class.text-white]="selectedCategory() === cat"
                [class.bg-[#161b22]]="selectedCategory() !== cat"
                [class.text-[#8b949e]]="selectedCategory() !== cat"
                class="px-2 py-0.5 rounded border border-[#30363d] font-semibold">
                {{ cat }}
              </button>
            }
          </div>

          <!-- Asset List -->
          <div class="flex-1 overflow-y-auto flex flex-col gap-2">
            @for (asset of filteredAssets(); track asset.id) {
              <button
                (click)="state.selectedAssetId.set(asset.id)"
                [class.bg-[#1f6feb]/15]="state.selectedAssetId() === asset.id"
                [class.border-[#1f6feb]]="state.selectedAssetId() === asset.id"
                [class.bg-[#161b22]]="state.selectedAssetId() !== asset.id"
                [class.border-[#30363d]]="state.selectedAssetId() !== asset.id"
                class="p-2 rounded-lg border text-xs font-mono cursor-pointer hover:border-[#58a6ff] transition-all flex flex-col gap-1 text-left w-full">
                
                <div class="flex items-center justify-between w-full">
                  <span class="text-[9px] font-bold px-1 py-0.2 rounded bg-[#21262d] text-[#58a6ff]">{{ asset.category }}</span>
                  <span class="text-[9px] font-bold text-[#3fb950]">{{ asset.qcStatus }}</span>
                </div>

                <div class="font-bold text-white text-xs truncate mt-0.5 w-full" [title]="asset.title">
                  {{ asset.title }}
                </div>

                <div class="flex items-center justify-between text-[10px] text-[#8b949e] mt-0.5 w-full">
                  <span>{{ asset.durationTimecode }}</span>
                  <span class="text-[9px]">{{ asset.format }}</span>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- Centre: Frame-Accurate Media Player & Transport (Cols 4-8) -->
        <div class="lg:col-span-5 bg-[#12161f] border border-[#21262d] rounded-xl p-3 flex flex-col justify-between gap-3">
          <div>
            <!-- Video Player Window -->
            <div class="relative w-full aspect-video bg-black rounded-lg overflow-hidden flex items-center justify-center border border-[#30363d]">
              <img
                [src]="state.selectedAsset().thumbnailUrl"
                [alt]="state.selectedAsset().title"
                referrerpolicy="no-referrer"
                class="w-full h-full object-cover opacity-80" />

              <!-- Overlay HUD -->
              <div class="absolute top-2 left-2 bg-black/75 px-2 py-0.5 rounded font-mono text-xs text-white border border-white/10">
                TC: <span class="text-[#58a6ff] font-bold">{{ isPlaying() ? state.masterTimecode() : state.selectedAsset().durationTimecode }}</span>
              </div>

              <div class="absolute top-2 right-2 bg-black/75 px-2 py-0.5 rounded font-mono text-[10px] text-white border border-white/10">
                {{ state.selectedAsset().format }} • 50.00 fps
              </div>

              <!-- Center Play Icon if Paused -->
              @if (!isPlaying()) {
                <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div class="w-12 h-12 rounded-full bg-black/60 border border-white/30 flex items-center justify-center text-white">
                    <mat-icon class="!text-[28px] !w-[28px] !h-[28px]">play_arrow</mat-icon>
                  </div>
                </div>
              }
            </div>

            <!-- Scrubber Timeline & Audio Waveform -->
            <div class="mt-3 flex flex-col gap-1">
              <div class="h-8 bg-[#090d13] rounded border border-[#30363d] relative overflow-hidden flex items-center px-2">
                <!-- Synthetic Waveform Bars -->
                <div class="w-full h-4 flex items-center justify-between gap-0.5 opacity-60">
                  @for (bar of waveformBars; track $index) {
                    <div class="flex-1 bg-[#58a6ff] rounded-xs" [style.height.%]="bar"></div>
                  }
                </div>
                <!-- Playhead -->
                <div class="absolute top-0 bottom-0 w-0.5 bg-[#da3633]" [style.left.%]="playheadPos()"></div>
              </div>

              <div class="flex items-center justify-between text-[10px] font-mono text-[#8b949e]">
                <span>IN: {{ state.selectedAsset().inTimecode }}</span>
                <span>DURATION: {{ state.selectedAsset().durationTimecode }}</span>
                <span>OUT: {{ state.selectedAsset().outTimecode }}</span>
              </div>
            </div>
          </div>

          <!-- Professional Transport Controls: JOG, SHUTTLE, MARK IN/OUT -->
          <div class="bg-[#161b22] p-2.5 rounded-lg border border-[#30363d] flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
            <div class="flex items-center gap-1">
              <!-- Mark In / Out -->
              <button class="px-2 py-1 rounded bg-[#21262d] text-white hover:bg-[#30363d] border border-[#30363d] font-bold">
                [ MARK IN
              </button>
              <button class="px-2 py-1 rounded bg-[#21262d] text-white hover:bg-[#30363d] border border-[#30363d] font-bold">
                MARK OUT ]
              </button>
            </div>

            <div class="flex items-center gap-1">
              <!-- Frame step back -->
              <button (click)="stepFrame(-1)" class="p-1 rounded bg-[#21262d] text-white hover:bg-[#30363d] border border-[#30363d]" title="Step Back 1 Frame">
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">chevron_left</mat-icon>
              </button>

              <!-- Play / Pause -->
              <button
                (click)="togglePlay()"
                [class.bg-[#1f6feb]]="!isPlaying()"
                [class.bg-[#da3633]]="isPlaying()"
                class="px-3 py-1 rounded text-white font-bold flex items-center gap-1 shadow-sm">
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">{{ isPlaying() ? 'pause' : 'play_arrow' }}</mat-icon>
                <span>{{ isPlaying() ? 'PAUSE' : 'PLAY' }}</span>
              </button>

              <!-- Frame step forward -->
              <button (click)="stepFrame(1)" class="p-1 rounded bg-[#21262d] text-white hover:bg-[#30363d] border border-[#30363d]" title="Step Forward 1 Frame">
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">chevron_right</mat-icon>
              </button>
            </div>

            <!-- Shuttle Speed Selector -->
            <div class="flex items-center gap-1 text-[10px]">
              <span class="text-[#8b949e]">SHUTTLE:</span>
              <button class="px-1.5 py-0.5 rounded bg-[#21262d] text-white border border-[#30363d]">1x</button>
              <button class="px-1.5 py-0.5 rounded bg-[#21262d] text-white border border-[#30363d]">2x</button>
              <button class="px-1.5 py-0.5 rounded bg-[#21262d] text-white border border-[#30363d]">4x</button>
            </div>
          </div>
        </div>

        <!-- Right: Technical QC, Provenance & Rights Ledger (Cols 9-12) -->
        <div class="lg:col-span-4 bg-[#12161f] border border-[#21262d] rounded-xl p-3 flex flex-col justify-between gap-3 text-xs font-mono">
          <div>
            <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
              <span class="font-bold text-white uppercase">AUTOMATED TECHNICAL QC</span>
              <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                [class.bg-[#238636]/20]="state.selectedAsset().qcStatus === 'PASS'"
                [class.text-[#3fb950]]="state.selectedAsset().qcStatus === 'PASS'"
                [class.bg-[#d29922]/20]="state.selectedAsset().qcStatus === 'WARNING'"
                [class.text-[#d29922]]="state.selectedAsset().qcStatus === 'WARNING'">
                QC: {{ state.selectedAsset().qcStatus }}
              </span>
            </div>

            <!-- QC Parameters Grid -->
            <div class="mt-2.5 space-y-1.5 text-[11px]">
              <div class="flex items-center justify-between bg-[#161b22] p-1.5 rounded border border-[#30363d]/60">
                <span class="text-[#8b949e]">EBU R128 Loudness:</span>
                <span class="text-[#3fb950] font-bold">{{ state.selectedAsset().qcDetails.ebuLoudness }}</span>
              </div>
              <div class="flex items-center justify-between bg-[#161b22] p-1.5 rounded border border-[#30363d]/60">
                <span class="text-[#8b949e]">Max True Peak:</span>
                <span class="text-[#3fb950] font-bold">{{ state.selectedAsset().qcDetails.truePeak }}</span>
              </div>
              <div class="flex items-center justify-between bg-[#161b22] p-1.5 rounded border border-[#30363d]/60">
                <span class="text-[#8b949e]">Black Frame Errors:</span>
                <span class="text-white font-bold">{{ state.selectedAsset().qcDetails.blackFrames }}</span>
              </div>
              <div class="flex items-center justify-between bg-[#161b22] p-1.5 rounded border border-[#30363d]/60">
                <span class="text-[#8b949e]">Freeze Frame Errors:</span>
                <span class="text-white font-bold">{{ state.selectedAsset().qcDetails.freezeFrames }}</span>
              </div>
              <div class="flex items-center justify-between bg-[#161b22] p-1.5 rounded border border-[#30363d]/60">
                <span class="text-[#8b949e]">Ofcom Flashing Pattern:</span>
                <span class="text-[#3fb950] font-bold">PASSED (HARDING FPA)</span>
              </div>
            </div>

            <!-- Provenance & Rights -->
            <div class="mt-3 pt-2 border-t border-[#21262d]">
              <div class="text-[10px] font-bold text-white uppercase mb-1">PROVENANCE & RIGHTS</div>
              <div class="bg-[#161b22] p-2 rounded border border-[#30363d]/60 space-y-1 text-[10px]">
                <div><span class="text-[#8b949e]">Ingest Node:</span> <span class="text-white">{{ state.selectedAsset().provenance.ingestLocation }}</span></div>
                <div><span class="text-[#8b949e]">Camera Unit:</span> <span class="text-white">{{ state.selectedAsset().provenance.cameraUnit }}</span></div>
                <div><span class="text-[#8b949e]">Operator:</span> <span class="text-white">{{ state.selectedAsset().provenance.operator }}</span></div>
                <div><span class="text-[#8b949e]">Rights Scope:</span> <span class="text-[#58a6ff]">{{ state.selectedAsset().rights.territory }}</span></div>
                <div class="truncate"><span class="text-[#8b949e]">SHA-256:</span> <span class="text-[#8b949e]">{{ state.selectedAsset().checksumSha256 }}</span></div>
              </div>
            </div>
          </div>

          <!-- Export AS-11 DPP Master -->
          <div class="pt-2 border-t border-[#21262d]">
            <button class="w-full py-2 rounded bg-[#1f6feb] text-white hover:bg-[#388bfd] font-mono font-bold text-xs flex items-center justify-center gap-1.5 shadow-md">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">file_download</mat-icon>
              <span>DELIVER AS-11 / UK DPP MASTER</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class MamViewComponent {
  state = inject(BroadcastStateService);
  selectedCategory = signal<string>('ALL');
  isPlaying = signal<boolean>(false);
  playheadPos = signal<number>(35);

  readonly waveformBars = [
    20, 35, 60, 45, 80, 95, 70, 40, 55, 85, 90, 65, 30, 45, 75, 85, 60, 40, 70, 90,
    50, 65, 80, 40, 30, 60, 75, 90, 85, 55, 45, 65, 80, 70, 50, 40, 60, 75, 85, 40
  ];

  filteredAssets() {
    const cat = this.selectedCategory();
    if (cat === 'ALL') return this.state.mamAssets();
    return this.state.mamAssets().filter((a) => a.category === cat);
  }

  togglePlay() {
    this.isPlaying.update((v) => !v);
  }

  stepFrame(delta: number) {
    this.playheadPos.update((p) => Math.max(0, Math.min(100, p + delta * 0.5)));
  }
}
