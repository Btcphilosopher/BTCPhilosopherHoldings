import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastStateService } from '../../services/broadcast-state.service';

@Component({
  selector: 'app-multiviewer-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col p-3 gap-3 overflow-y-auto bg-[#07090e]">
      <!-- Header: Multiviewer Layout Mode -->
      <div class="flex items-center justify-between pb-2 border-b border-[#21262d] shrink-0">
        <div class="flex items-center gap-3">
          <div class="flex items-center gap-2">
            <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#58a6ff]">grid_view</mat-icon>
            <h1 class="text-xs font-mono font-bold text-white uppercase tracking-wider">
              12-TILE MASTER GALLERY MULTIVIEWER (SMPTE ST 2110-20 QUAD/SPLIT)
            </h1>
          </div>
          <span class="px-2 py-0.5 rounded text-[9px] font-mono bg-[#161b22] text-[#3fb950] border border-[#30363d]">
            4K UHD QUAD-OUTPUT (LONDON GALLERY 1)
          </span>
        </div>

        <div class="flex items-center gap-2 text-xs font-mono text-[#8b949e]">
          <span>TC: <span class="text-white font-bold">{{ state.masterTimecode() }}</span></span>
          <span class="text-[#3fb950]">● PTP GRANDMASTER LOCK</span>
        </div>
      </div>

      <!-- 12-Tile Multiviewer Grid (4 columns, 3 rows) -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 flex-1 items-stretch">
        @for (src of state.sources(); track src.id) {
          <div
            [class.border-2]="true"
            [class.border-[#da3633]]="src.tally === 'PROGRAM'"
            [class.border-[#238636]]="src.tally === 'PREVIEW'"
            [class.border-[#30363d]]="src.tally !== 'PROGRAM' && src.tally !== 'PREVIEW'"
            class="bg-[#12161f] rounded-lg p-1.5 flex flex-col justify-between shadow-md relative overflow-hidden group hover:brightness-110 transition-all">
            
            <!-- Tile Top Bar -->
            <div class="flex items-center justify-between px-1.5 py-0.5 rounded bg-black/70 backdrop-blur text-[10px] font-mono z-10">
              <div class="flex items-center gap-1.5 font-bold"
                [class.text-[#f85149]]="src.tally === 'PROGRAM'"
                [class.text-[#3fb950]]="src.tally === 'PREVIEW'"
                [class.text-white]="src.tally !== 'PROGRAM' && src.tally !== 'PREVIEW'">
                <span class="w-1.5 h-1.5 rounded-full"
                  [class.bg-[#da3633]]="src.tally === 'PROGRAM'"
                  [class.bg-[#238636]]="src.tally === 'PREVIEW'"
                  [class.bg-[#484f58]]="src.tally !== 'PROGRAM' && src.tally !== 'PREVIEW'"></span>
                <span>{{ src.code }}</span>
              </div>
              <span class="text-[#8b949e] truncate max-w-[120px]">{{ src.name }}</span>
            </div>

            <!-- Video Simulation Canvas -->
            <div class="relative w-full aspect-video bg-[#05070a] rounded mt-1 overflow-hidden flex items-center justify-center border border-white/5">
              <!-- Background Visual -->
              <div class="absolute inset-0 bg-gradient-to-br from-[#161d2b] to-[#0a0f17] flex flex-col items-center justify-center text-center p-2">
                <mat-icon class="!text-[24px] !w-[24px] !h-[24px] text-[#58a6ff]/70 mb-1">
                  {{ src.type === 'CAMERA' ? 'videocam' : src.type === 'REMOTE_OB' ? 'satellite_alt' : src.type === 'VTR' ? 'movie' : 'stream' }}
                </mat-icon>
                <div class="text-xs font-mono font-bold text-white truncate max-w-full">
                  {{ src.code }}
                </div>
                <div class="text-[9px] font-mono text-[#8b949e] mt-0.5">
                  {{ src.location }} • {{ src.latencyMs }}ms
                </div>
              </div>

              <!-- Mini Audio VU Level in Tile -->
              <div class="absolute bottom-1 right-1 bg-black/80 px-1 py-0.5 rounded flex items-center gap-0.5 text-[8px] font-mono text-[#3fb950]">
                <span>L</span>
                <div class="w-8 h-1 bg-[#21262d] rounded overflow-hidden">
                  <div class="h-full bg-[#238636] rounded" style="width: 75%"></div>
                </div>
                <span>R</span>
                <div class="w-8 h-1 bg-[#21262d] rounded overflow-hidden">
                  <div class="h-full bg-[#238636] rounded" style="width: 72%"></div>
                </div>
              </div>

              <!-- Quick Hover Overlay Controls -->
              <div class="absolute inset-0 bg-black/75 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <button
                  (click)="state.cutToSource(src.id)"
                  class="px-2 py-1 rounded bg-[#da3633] text-white font-mono font-bold text-[10px] shadow-sm hover:brightness-125">
                  CUT PGM
                </button>
                <button
                  (click)="state.setPreviewSource(src.id)"
                  class="px-2 py-1 rounded bg-[#238636] text-white font-mono font-bold text-[10px] shadow-sm hover:brightness-125">
                  SET PVW
                </button>
              </div>
            </div>

            <!-- Tile Bottom Bar -->
            <div class="flex items-center justify-between px-1 pt-1 text-[9px] font-mono text-[#8b949e]">
              <span>{{ src.format }}</span>
              <span class="text-white font-bold">{{ src.st2110Standard.video }}</span>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class MultiviewerViewComponent {
  state = inject(BroadcastStateService);
}
