import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastStateService } from '../../services/broadcast-state.service';

@Component({
  selector: 'app-telemetry-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col p-4 gap-4 overflow-y-auto bg-[#0b0e14]">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#21262d]">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#58a6ff]">troubleshoot</mat-icon>
            <h1 class="text-base font-bold font-mono text-white tracking-wide">
              FACILITY DIGITAL TWIN, ENGINEERING TELEMETRY & FAILURE SIMULATOR
            </h1>
          </div>
          <p class="text-xs text-[#8b949e] font-sans mt-0.5">
            Spatial facility digital twin, PTP nanosecond sync, hardware telemetry, fault injection, and immutable audit logs.
          </p>
        </div>

        <!-- Failure Simulator Reset -->
        <div class="flex items-center gap-2 font-mono text-xs">
          <button
            (click)="state.restoreAllFaults()"
            class="px-3 py-1.5 rounded bg-[#238636] text-white hover:bg-[#2ea043] font-bold border border-[#2ea043] flex items-center gap-1.5 shadow-sm">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">restart_alt</mat-icon>
            <span>RESET ALL SIMULATED FAULTS</span>
          </button>
        </div>
      </div>

      <!-- Top Row: Interactive Fault Injection Console -->
      <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-4 shadow-md flex flex-col gap-3 font-mono text-xs">
        <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
          <div class="flex items-center gap-2 font-bold text-white uppercase">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#f85149]">flash_on</mat-icon>
            <span>ENGINEERING FAULT INJECTION & REDUNDANCY TESTBED</span>
          </div>
          <span class="text-[10px] text-[#8b949e]">Click any fault below to test automated system failover</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          <button
            (click)="state.injectSimulatedFault('CAMERA_FIBRE_CUT')"
            class="p-2.5 rounded-lg bg-[#161b22] border border-[#30363d] hover:border-[#f85149] text-left transition-all group flex flex-col justify-between">
            <div>
              <div class="text-white font-bold text-xs group-hover:text-[#f85149]">FAULT: CAMERA FIBRE CUT</div>
              <div class="text-[10px] text-[#8b949e] mt-1 font-sans">Simulate Salford trunk fiber disconnection</div>
            </div>
            <span class="text-[9px] text-[#f85149] mt-2 font-bold">TRIGGER FAULT →</span>
          </button>

          <button
            (click)="state.injectSimulatedFault('PRIMARY_ENCODER_FAIL')"
            class="p-2.5 rounded-lg bg-[#161b22] border border-[#30363d] hover:border-[#f85149] text-left transition-all group flex flex-col justify-between">
            <div>
              <div class="text-white font-bold text-xs group-hover:text-[#f85149]">FAULT: PRIMARY PLAYOUT CRASH</div>
              <div class="text-[10px] text-[#8b949e] mt-1 font-sans">Test hitless SMPTE 2022-7 backup failover</div>
            </div>
            <span class="text-[9px] text-[#f85149] mt-2 font-bold">TRIGGER FAULT →</span>
          </button>

          <button
            (click)="state.injectSimulatedFault('PTP_DRIFT')"
            class="p-2.5 rounded-lg bg-[#161b22] border border-[#30363d] hover:border-[#f85149] text-left transition-all group flex flex-col justify-between">
            <div>
              <div class="text-white font-bold text-xs group-hover:text-[#f85149]">FAULT: PTP CLOCK JITTER</div>
              <div class="text-[10px] text-[#8b949e] mt-1 font-sans">Force grandmaster into rubidium holdover</div>
            </div>
            <span class="text-[9px] text-[#f85149] mt-2 font-bold">TRIGGER FAULT →</span>
          </button>

          <button
            (click)="state.injectSimulatedFault('AUDIO_LINE_NOISE')"
            class="p-2.5 rounded-lg bg-[#161b22] border border-[#30363d] hover:border-[#f85149] text-left transition-all group flex flex-col justify-between">
            <div>
              <div class="text-white font-bold text-xs group-hover:text-[#f85149]">FAULT: AUDIO LINE DEGRADATION</div>
              <div class="text-[10px] text-[#8b949e] mt-1 font-sans">Test automated ducking and safety mute</div>
            </div>
            <span class="text-[9px] text-[#f85149] mt-2 font-bold">TRIGGER FAULT →</span>
          </button>
        </div>
      </div>

      <!-- Facility Digital Twin & Spatial Health Map -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <!-- UK Broadcast Centres Spatial Twin -->
        <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-4 shadow-md flex flex-col justify-between font-mono text-xs">
          <div>
            <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
              <span class="font-bold text-white uppercase flex items-center gap-2">
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#58a6ff]">apartment</mat-icon>
                <span>UK BROADCAST FACILITY NODES (DIGITAL TWIN)</span>
              </span>
              <span class="text-[10px] text-[#3fb950] font-bold">5 SITES SYNCHRONIZED</span>
            </div>

            <div class="mt-3 space-y-2">
              @for (hub of facilityHubs; track hub.code) {
                <div class="bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 flex items-center justify-between shadow-sm">
                  <div>
                    <div class="flex items-center gap-2">
                      <span class="w-2 h-2 rounded-full bg-[#3fb950]"></span>
                      <span class="font-bold text-white text-xs">{{ hub.name }}</span>
                      <span class="text-[10px] text-[#58a6ff]">({{ hub.code }})</span>
                    </div>
                    <div class="text-[10px] text-[#8b949e] mt-0.5">{{ hub.spec }}</div>
                  </div>

                  <div class="text-right">
                    <span class="text-white font-bold text-xs">{{ hub.load }}</span>
                    <div class="text-[9px] text-[#3fb950]">PTP LOCKED</div>
                  </div>
                </div>
              }
            </div>
          </div>

          <div class="pt-2 border-t border-[#21262d] flex items-center justify-between text-[10px] text-[#8b949e]">
            <span>CORE INTERCONNECT: 400GbE DWDM RING</span>
            <span class="text-[#3fb950]">LATENCY &lt;6ms UK-WIDE</span>
          </div>
        </div>

        <!-- Real-time Hardware Telemetry & Metrics -->
        <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-4 shadow-md flex flex-col justify-between font-mono text-xs">
          <div>
            <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
              <span class="font-bold text-white uppercase flex items-center gap-2">
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#58a6ff]">speed</mat-icon>
                <span>HARDWARE & STREAM TELEMETRY</span>
              </span>
              <span class="text-[10px] text-[#58a6ff]">{{ state.telemetry().ptpSyncStatus }}</span>
            </div>

            <div class="mt-3 grid grid-cols-2 gap-2 text-xs">
              <div class="bg-[#161b22] p-2 rounded border border-[#30363d]">
                <span class="text-[10px] text-[#8b949e] block">PTP OFFSET MEAN</span>
                <span class="text-white font-bold text-sm">{{ state.telemetry().ptpOffsetMeanNs }} ns</span>
                <span class="text-[9px] text-[#3fb950] block mt-0.5">IEEE 1588-2008</span>
              </div>

              <div class="bg-[#161b22] p-2 rounded border border-[#30363d]">
                <span class="text-[10px] text-[#8b949e] block">NETWORK THROUGHPUT</span>
                <span class="text-[#58a6ff] font-bold text-sm">{{ state.telemetry().networkThroughputGbps }} Gbps</span>
                <span class="text-[9px] text-[#8b949e] block mt-0.5">Aggregated 100GbE</span>
              </div>

              <div class="bg-[#161b22] p-2 rounded border border-[#30363d]">
                <span class="text-[10px] text-[#8b949e] block">SERVER CPU & GPU</span>
                <span class="text-white font-bold text-sm">{{ state.telemetry().serverCpuUsagePercent }}% / {{ state.telemetry().serverGpuUsagePercent }}%</span>
                <span class="text-[9px] text-[#3fb950] block mt-0.5">Transcoder Cluster</span>
              </div>

              <div class="bg-[#161b22] p-2 rounded border border-[#30363d]">
                <span class="text-[10px] text-[#8b949e] block">MAM STORAGE FREE</span>
                <span class="text-white font-bold text-sm">{{ state.telemetry().storageFreeTb }} TB</span>
                <span class="text-[9px] text-[#58a6ff] block mt-0.5">{{ state.telemetry().storageIops }} IOPS</span>
              </div>
            </div>
          </div>

          <div class="pt-2 border-t border-[#21262d] flex items-center justify-between text-[10px] text-[#8b949e]">
            <span>GRANDMASTER: {{ state.telemetry().ptpMasterGrandmaster }}</span>
          </div>
        </div>
      </div>

      <!-- Immutable Broadcast Audit Log & System Incidents -->
      <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-4 shadow-md flex-1 flex flex-col font-mono text-xs">
        <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
          <span class="font-bold text-white uppercase flex items-center gap-2">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#58a6ff]">history</mat-icon>
            <span>IMMUTABLE BROADCAST AUDIT TRAIL & EVENT LOG</span>
          </span>
          <span class="text-[10px] text-[#8b949e]">REPLAYABLE EVENT STREAM</span>
        </div>

        <div class="overflow-y-auto flex-1 mt-3 space-y-1.5 max-h-48">
          @for (log of state.auditLog(); track log.id) {
            <div class="bg-[#161b22] border border-[#30363d]/60 rounded p-2 flex items-center justify-between text-[11px] hover:bg-[#1f242c]">
              <div class="flex items-center gap-3">
                <span class="text-[#8b949e] font-bold">{{ log.timestamp }}</span>
                <span class="px-1.5 py-0.2 rounded bg-[#21262d] text-[#58a6ff] font-bold">{{ log.subsystem }}</span>
                <span class="text-white font-semibold">{{ log.action }}</span>
                <span class="text-[#8b949e] font-sans truncate max-w-md">{{ log.details }}</span>
              </div>
              <span class="text-[10px] text-[#8b949e]">{{ log.operatorId }} ({{ log.workstation }})</span>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class TelemetryViewComponent {
  state = inject(BroadcastStateService);

  readonly facilityHubs = [
    { code: 'LONDON', name: 'London Broadcast Centre (W1A)', spec: '3 Galleries, Master MCR, 12 Edit Suites', load: '32% Load' },
    { code: 'SALFORD', name: 'Salford MediaCity UK', spec: 'North West Hub, 2 Live Studios, Sports Ingest', load: '24% Load' },
    { code: 'CARDIFF', name: 'Cardiff Central Square', spec: 'Wales National Centre, Drama & Senedd Link', load: '18% Load' },
    { code: 'GLASGOW', name: 'Glasgow Pacific Quay', spec: 'Scotland National Centre, Highlands Ingest', load: '21% Load' },
    { code: 'BELFAST', name: 'Belfast Blackstaff House', spec: 'Northern Ireland Newsroom & Regional Link', load: '15% Load' },
  ];
}
