import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastStateService } from '../../services/broadcast-state.service';

@Component({
  selector: 'app-gallery-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col p-3 gap-3 overflow-y-auto bg-[#090d13]">
      <!-- Top Title & Gallery Mode Bar -->
      <div class="flex items-center justify-between pb-2 border-b border-[#21262d] shrink-0">
        <div class="flex items-center gap-3">
          <div class="flex items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-full bg-[#da3633] animate-pulse"></span>
            <h1 class="text-sm font-mono font-bold text-white uppercase tracking-wider">
              PRODUCTION GALLERY A — VISION MIXER & MASTER MONITOR
            </h1>
          </div>
          <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-[#161b22] text-[#58a6ff] border border-[#30363d]">
            1080p50 10-BIT REC.709
          </span>
        </div>

        <div class="flex items-center gap-2 text-xs font-mono">
          <div class="px-2.5 py-1 rounded bg-[#161b22] border border-[#30363d] text-[#8b949e]">
            TRANSITION RATE: <span class="text-white font-bold">{{ state.transitionRateFrames() }}f ({{ (state.transitionRateFrames() / 25).toFixed(1) }}s)</span>
          </div>
          <div class="px-2.5 py-1 rounded bg-[#161b22] border border-[#30363d] text-[#8b949e]">
            DSK ACTIVE: <span class="text-[#3fb950] font-bold">{{ activeDskCount() }}</span>
          </div>
        </div>
      </div>

      <!-- Main Dual Monitors: PROGRAM (RED) & PREVIEW (GREEN) -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-3 shrink-0">
        <!-- PREVIEW MONITOR -->
        <div class="bg-[#12161f] rounded-xl border-2 border-[#238636] p-2 flex flex-col justify-between relative shadow-lg overflow-hidden group">
          <!-- Top Header inside Monitor -->
          <div class="flex items-center justify-between px-2 py-1 bg-[#161b22]/90 backdrop-blur rounded text-xs font-mono font-bold text-[#3fb950] z-10">
            <div class="flex items-center gap-2">
              <span class="w-2 h-2 rounded-full bg-[#3fb950]"></span>
              <span>PREVIEW (PVW)</span>
            </div>
            <span class="text-white bg-[#238636]/30 px-2 py-0.5 rounded border border-[#238636]/60">
              {{ state.previewSource().code }} — {{ state.previewSource().name }}
            </span>
          </div>

          <!-- Video Canvas / Screen Simulation -->
          <div class="relative w-full aspect-video bg-[#05070a] rounded-lg mt-1.5 overflow-hidden flex items-center justify-center border border-[#21262d]">
            <div class="absolute inset-0 bg-gradient-to-tr from-[#1a2333] via-[#0f1724] to-[#070b12] flex flex-col items-center justify-center p-6 text-center">
              <div class="w-16 h-16 rounded-full bg-[#161b22]/80 border border-[#30363d] flex items-center justify-center text-[#58a6ff] mb-2 shadow-inner">
                <mat-icon class="!text-[32px] !w-[32px] !h-[32px]">videocam</mat-icon>
              </div>
              <div class="text-base font-mono font-bold text-white tracking-wide">
                {{ state.previewSource().name }}
              </div>
              <div class="text-xs font-mono text-[#8b949e] mt-1">
                {{ state.previewSource().format }} • {{ state.previewSource().multicastIp }}
              </div>
              <div class="mt-2 text-[10px] font-mono px-2 py-0.5 rounded bg-[#238636]/20 text-[#3fb950] border border-[#238636]/40">
                PTP LOCKED ({{ state.previewSource().latencyMs }}ms)
              </div>
            </div>

            <!-- Safe Area Grid Marks -->
            <div class="absolute inset-4 border border-dashed border-white/10 pointer-events-none"></div>
            <div class="absolute inset-8 border border-dashed border-white/5 pointer-events-none"></div>
          </div>

          <!-- Monitor Bottom Bar -->
          <div class="flex items-center justify-between px-2 pt-1.5 text-[11px] font-mono text-[#8b949e]">
            <span>FORMAT: {{ state.previewSource().format }}</span>
            <span class="text-[#3fb950]">NEXT IN LINE</span>
          </div>
        </div>

        <!-- PROGRAM MONITOR (ON AIR) -->
        <div class="bg-[#12161f] rounded-xl border-2 border-[#da3633] p-2 flex flex-col justify-between relative shadow-lg overflow-hidden group">
          <!-- Top Header inside Monitor -->
          <div class="flex items-center justify-between px-2 py-1 bg-[#da3633] rounded text-xs font-mono font-bold text-white z-10 shadow-sm">
            <div class="flex items-center gap-2">
              <span class="w-2 h-2 rounded-full bg-white animate-ping"></span>
              <span>PROGRAM (PGM) — TRANSMITTING</span>
            </div>
            <span class="bg-black/30 px-2 py-0.5 rounded">
              {{ state.programSource().code }} — {{ state.programSource().name }}
            </span>
          </div>

          <!-- Video Canvas / Screen Simulation with Real Overlays -->
          <div class="relative w-full aspect-video bg-[#05070a] rounded-lg mt-1.5 overflow-hidden flex items-center justify-center border border-[#21262d]">
            <!-- Synthetic Live Camera Background -->
            <div class="absolute inset-0 bg-gradient-to-br from-[#1c2438] via-[#101726] to-[#080d17] flex flex-col items-center justify-center p-6 text-center">
              @if (state.mcrEmergencySlateActive()) {
                <div class="w-full h-full bg-[#1a0f12] flex flex-col items-center justify-center p-6 border-4 border-[#da3633]">
                  <mat-icon class="!text-[48px] !w-[48px] !h-[48px] text-[#f85149] mb-2">warning</mat-icon>
                  <h2 class="text-xl font-bold font-mono text-white">BRITANNIA BROADCASTING</h2>
                  <p class="text-sm font-mono text-[#f85149] font-bold mt-1">PROGRAMMES INTERRUPTED — TRANSMISSION BREAKDOWN</p>
                  <p class="text-xs font-mono text-[#8b949e] mt-2">Master Control Emergency Slate (1080p50 / EBU-1004)</p>
                </div>
              } @else {
                <div class="w-20 h-20 rounded-full bg-[#1f293d] border-2 border-[#58a6ff]/40 flex items-center justify-center text-[#58a6ff] mb-2 shadow-2xl relative">
                  <mat-icon class="!text-[40px] !w-[40px] !h-[40px]">live_tv</mat-icon>
                  <span class="absolute -top-1 -right-1 w-3.5 h-3.5 bg-[#da3633] rounded-full border-2 border-black"></span>
                </div>
                <div class="text-lg font-mono font-bold text-white tracking-wide">
                  {{ state.programSource().name }}
                </div>
                <div class="text-xs font-mono text-[#58a6ff] mt-1">
                  {{ state.programSource().description }}
                </div>
              }
            </div>

            <!-- DSK 1: Channel Bug / DOG (Top Right) -->
            @if (state.dsk1BugActive() && !state.mcrEmergencySlateActive()) {
              <div class="absolute top-4 right-5 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded border border-white/20 flex items-center gap-1.5 z-20 shadow-md">
                <span class="w-2 h-2 rounded-full bg-[#f85149]"></span>
                <span class="font-mono font-bold text-xs text-white tracking-wider">BRITANNIA 1 HD</span>
              </div>
            }

            <!-- DSK 2: Lower Third Strap (Bottom Left) -->
            @if (state.dsk2LowerThirdActive() && !state.mcrEmergencySlateActive()) {
              <div class="absolute bottom-10 left-5 max-w-[80%] z-20 transition-all">
                <div class="bg-[#1f6feb] text-white font-mono font-bold text-xs px-3 py-1 tracking-wider uppercase inline-block rounded-t shadow-md">
                  {{ state.lowerThirdData().name }}
                </div>
                <div class="bg-black/90 backdrop-blur-md text-[#e6edf3] font-sans text-xs px-3 py-1.5 rounded-b rounded-r border-l-4 border-[#1f6feb] shadow-xl flex items-center justify-between gap-4">
                  <span>{{ state.lowerThirdData().role }}</span>
                  <span class="text-[10px] font-mono text-[#58a6ff]">{{ state.lowerThirdData().location }}</span>
                </div>
              </div>
            }

            <!-- DSK 3: Breaking News Ticker (Bottom Bar) -->
            @if (state.dsk3BreakingActive() && !state.mcrEmergencySlateActive()) {
              <div class="absolute bottom-0 inset-x-0 h-7 bg-[#da3633] text-white font-mono text-[11px] font-bold flex items-center px-3 z-30 shadow-lg overflow-hidden whitespace-nowrap">
                <span class="bg-black text-white px-2 py-0.5 rounded text-[9px] uppercase font-bold mr-2">BREAKING</span>
                <div class="animate-marquee font-mono truncate">
                  {{ state.breakingTickerText() }}
                </div>
              </div>
            }

            <!-- Live Audio PPM Meter Overlay in Program Corner -->
            <div class="absolute top-4 left-4 bg-black/70 backdrop-blur-sm p-1.5 rounded border border-white/10 flex items-center gap-1.5 font-mono text-[9px] z-20">
              <span class="text-[#8b949e]">PPM</span>
              <div class="w-16 h-2 bg-[#21262d] rounded-full overflow-hidden flex">
                <div class="h-full bg-gradient-to-r from-[#238636] via-[#d29922] to-[#da3633] rounded-full transition-all"
                  [style.width.%]="audioBarWidth()"></div>
              </div>
              <span class="text-white font-bold">{{ state.loudness().shortTermLufs }} LUFS</span>
            </div>
          </div>

          <!-- Monitor Bottom Bar -->
          <div class="flex items-center justify-between px-2 pt-1.5 text-[11px] font-mono text-[#8b949e]">
            <span>SMPTE ST 2110-20 UNCOMPRESSED</span>
            <span class="text-[#f85149] font-bold">LIVE ON TRANSMISSION</span>
          </div>
        </div>
      </div>

      <!-- Vision Mixer Control Surface (Buses, Keyers, Transitions, T-Bar) -->
      <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-3 shadow-md flex flex-col gap-3">
        <!-- Keyers & DSK Control Bar -->
        <div class="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#21262d]">
          <div class="flex items-center gap-2 text-xs font-mono font-bold text-white">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#58a6ff]">layers</mat-icon>
            <span>DOWNSTREAM KEYERS (DSK / GFX)</span>
          </div>

          <div class="flex items-center gap-2">
            <button
              (click)="state.toggleDsk(1)"
              [class.bg-[#1f6feb]]="state.dsk1BugActive()"
              [class.text-white]="state.dsk1BugActive()"
              [class.bg-[#161b22]]="!state.dsk1BugActive()"
              [class.text-[#8b949e]]="!state.dsk1BugActive()"
              class="px-2.5 py-1 rounded text-xs font-mono font-bold border border-[#30363d] transition-all">
              DSK 1: DOG BUG
            </button>

            <button
              (click)="state.toggleDsk(2)"
              [class.bg-[#1f6feb]]="state.dsk2LowerThirdActive()"
              [class.text-white]="state.dsk2LowerThirdActive()"
              [class.bg-[#161b22]]="!state.dsk2LowerThirdActive()"
              [class.text-[#8b949e]]="!state.dsk2LowerThirdActive()"
              class="px-2.5 py-1 rounded text-xs font-mono font-bold border border-[#30363d] transition-all">
              DSK 2: LOWER THIRD
            </button>

            <button
              (click)="state.toggleDsk(3)"
              [class.bg-[#da3633]]="state.dsk3BreakingActive()"
              [class.text-white]="state.dsk3BreakingActive()"
              [class.bg-[#161b22]]="!state.dsk3BreakingActive()"
              [class.text-[#8b949e]]="!state.dsk3BreakingActive()"
              class="px-2.5 py-1 rounded text-xs font-mono font-bold border border-[#30363d] transition-all">
              DSK 3: BREAKING TICKER
            </button>

            <button
              (click)="state.toggleDsk(4)"
              [class.bg-[#1f6feb]]="state.dsk4PipActive()"
              [class.text-white]="state.dsk4PipActive()"
              [class.bg-[#161b22]]="!state.dsk4PipActive()"
              [class.text-[#8b949e]]="!state.dsk4PipActive()"
              class="px-2.5 py-1 rounded text-xs font-mono font-bold border border-[#30363d] transition-all">
              DSK 4: 2-BOX PiP
            </button>
          </div>
        </div>

        <!-- Vision Mixer Bus Rows & Transition Engine -->
        <div class="grid grid-cols-1 lg:grid-cols-4 gap-4">
          <!-- Left: PROGRAM & PREVIEW Bus Push-buttons -->
          <div class="lg:col-span-3 flex flex-col gap-3">
            <!-- PROGRAM BUS -->
            <div>
              <div class="flex items-center justify-between mb-1.5">
                <span class="text-[11px] font-mono font-bold text-[#f85149] uppercase flex items-center gap-1.5">
                  <span class="w-2 h-2 rounded-full bg-[#da3633]"></span>
                  PROGRAM BUS (PGM / ON AIR)
                </span>
                <span class="text-[10px] font-mono text-[#8b949e]">CLICK TO CUT DIRECTLY</span>
              </div>
              <div class="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                @for (src of state.sources(); track src.id) {
                  <button
                    (click)="state.cutToSource(src.id)"
                    [class.bg-[#da3633]]="state.programSourceId() === src.id"
                    [class.text-white]="state.programSourceId() === src.id"
                    [class.border-[#f85149]]="state.programSourceId() === src.id"
                    [class.bg-[#161b22]]="state.programSourceId() !== src.id"
                    [class.text-[#c9d1d9]]="state.programSourceId() !== src.id"
                    [class.border-[#30363d]]="state.programSourceId() !== src.id"
                    class="py-2.5 px-2 rounded border font-mono font-bold text-xs flex flex-col items-center justify-center transition-all hover:brightness-125 shadow-sm active:scale-95">
                    <span class="text-xs">{{ src.code }}</span>
                    <span class="text-[9px] opacity-75 font-normal truncate max-w-full mt-0.5">{{ src.location }}</span>
                  </button>
                }
              </div>
            </div>

            <!-- PREVIEW BUS -->
            <div>
              <div class="flex items-center justify-between mb-1.5">
                <span class="text-[11px] font-mono font-bold text-[#3fb950] uppercase flex items-center gap-1.5">
                  <span class="w-2 h-2 rounded-full bg-[#238636]"></span>
                  PREVIEW BUS (PVW / PRESET)
                </span>
                <span class="text-[10px] font-mono text-[#8b949e]">CLICK TO ARM PREVIEW</span>
              </div>
              <div class="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                @for (src of state.sources(); track src.id) {
                  <button
                    (click)="state.setPreviewSource(src.id)"
                    [class.bg-[#238636]]="state.previewSourceId() === src.id"
                    [class.text-white]="state.previewSourceId() === src.id"
                    [class.border-[#3fb950]]="state.previewSourceId() === src.id"
                    [class.bg-[#161b22]]="state.previewSourceId() !== src.id"
                    [class.text-[#c9d1d9]]="state.previewSourceId() !== src.id"
                    [class.border-[#30363d]]="state.previewSourceId() !== src.id"
                    class="py-2.5 px-2 rounded border font-mono font-bold text-xs flex flex-col items-center justify-center transition-all hover:brightness-125 shadow-sm active:scale-95">
                    <span class="text-xs">{{ src.code }}</span>
                    <span class="text-[9px] opacity-75 font-normal truncate max-w-full mt-0.5">{{ src.location }}</span>
                  </button>
                }
              </div>
            </div>
          </div>

          <!-- Right: Transition Block & Interactive T-Bar -->
          <div class="bg-[#161b22] border border-[#30363d] rounded-lg p-3 flex flex-col justify-between">
            <div>
              <div class="text-[11px] font-mono font-bold text-white uppercase mb-2 text-center pb-1 border-b border-[#30363d]">
                TRANSITION ENGINE
              </div>

              <!-- Transition Type Buttons -->
              <div class="grid grid-cols-2 gap-1.5 mb-3">
                <button
                  (click)="state.transitionMode.set('MIX')"
                  [class.bg-[#1f6feb]]="state.transitionMode() === 'MIX'"
                  [class.text-white]="state.transitionMode() === 'MIX'"
                  [class.bg-[#21262d]]="state.transitionMode() !== 'MIX'"
                  [class.text-[#8b949e]]="state.transitionMode() !== 'MIX'"
                  class="py-1 rounded text-xs font-mono font-bold border border-[#30363d]">
                  MIX (DISSOLVE)
                </button>

                <button
                  (click)="state.transitionMode.set('DIP')"
                  [class.bg-[#1f6feb]]="state.transitionMode() === 'DIP'"
                  [class.text-white]="state.transitionMode() === 'DIP'"
                  [class.bg-[#21262d]]="state.transitionMode() !== 'DIP'"
                  [class.text-[#8b949e]]="state.transitionMode() !== 'DIP'"
                  class="py-1 rounded text-xs font-mono font-bold border border-[#30363d]">
                  DIP TO BLACK
                </button>

                <button
                  (click)="state.transitionMode.set('WIPE')"
                  [class.bg-[#1f6feb]]="state.transitionMode() === 'WIPE'"
                  [class.text-white]="state.transitionMode() === 'WIPE'"
                  [class.bg-[#21262d]]="state.transitionMode() !== 'WIPE'"
                  [class.text-[#8b949e]]="state.transitionMode() !== 'WIPE'"
                  class="py-1 rounded text-xs font-mono font-bold border border-[#30363d]">
                  WIPE
                </button>

                <button
                  (click)="state.transitionMode.set('DVE_PIP')"
                  [class.bg-[#1f6feb]]="state.transitionMode() === 'DVE_PIP'"
                  [class.text-white]="state.transitionMode() === 'DVE_PIP'"
                  [class.bg-[#21262d]]="state.transitionMode() !== 'DVE_PIP'"
                  [class.text-[#8b949e]]="state.transitionMode() !== 'DVE_PIP'"
                  class="py-1 rounded text-xs font-mono font-bold border border-[#30363d]">
                  DVE PiP
                </button>
              </div>

              <!-- Main Execution: CUT & AUTO Buttons -->
              <div class="grid grid-cols-2 gap-2 mb-3">
                <button
                  (click)="state.cutToSource(state.previewSourceId())"
                  class="py-3.5 rounded-lg bg-[#21262d] text-white hover:bg-[#30363d] active:scale-95 font-mono font-bold text-sm border border-[#30363d] shadow-md transition-all">
                  CUT
                </button>

                <button
                  (click)="state.triggerAutoTransition()"
                  [disabled]="state.isAutoTransitioning()"
                  [class.animate-pulse]="state.isAutoTransitioning()"
                  class="py-3.5 rounded-lg bg-[#da3633] text-white hover:bg-[#f85149] active:scale-95 font-mono font-bold text-sm border border-[#f85149] shadow-md transition-all disabled:opacity-50">
                  AUTO ({{ state.transitionRateFrames() }}f)
                </button>
              </div>

              <!-- Interactive T-Bar Slider -->
              <div class="flex flex-col gap-1">
                <div class="flex items-center justify-between text-[10px] font-mono text-[#8b949e]">
                  <span>T-BAR MANUAL FADER</span>
                  <span class="text-white font-bold">{{ state.tBarPosition() }}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  [value]="state.tBarPosition()"
                  (input)="onTBarChange($event)"
                  class="w-full accent-[#58a6ff] cursor-pointer bg-[#21262d] h-2 rounded-lg" />
              </div>
            </div>

            <!-- Rate Frame Selector -->
            <div class="flex items-center justify-between pt-2 border-t border-[#30363d] text-[10px] font-mono text-[#8b949e]">
              <span>RATE:</span>
              <div class="flex gap-1">
                @for (rate of [12, 25, 50]; track rate) {
                  <button
                    (click)="state.transitionRateFrames.set(rate)"
                    [class.bg-[#1f6feb]]="state.transitionRateFrames() === rate"
                    [class.text-white]="state.transitionRateFrames() === rate"
                    [class.bg-[#21262d]]="state.transitionRateFrames() !== rate"
                    class="px-1.5 py-0.5 rounded border border-[#30363d]">
                    {{ rate }}f
                  </button>
                }
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class GalleryViewComponent {
  state = inject(BroadcastStateService);

  activeDskCount() {
    let count = 0;
    if (this.state.dsk1BugActive()) count++;
    if (this.state.dsk2LowerThirdActive()) count++;
    if (this.state.dsk3BreakingActive()) count++;
    if (this.state.dsk4PipActive()) count++;
    return count;
  }

  audioBarWidth() {
    const lufs = this.state.loudness().shortTermLufs;
    const pct = Math.max(0, Math.min(100, ((lufs + 40) / 30) * 100));
    return pct;
  }

  onTBarChange(event: Event) {
    const target = event.target as HTMLInputElement;
    this.state.setManualTBar(Number(target.value));
  }
}
