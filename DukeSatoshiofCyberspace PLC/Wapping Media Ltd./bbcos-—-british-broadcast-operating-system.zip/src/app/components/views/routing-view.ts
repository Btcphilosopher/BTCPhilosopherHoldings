import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastStateService } from '../../services/broadcast-state.service';
import { BroadcastSource } from '../../models/broadcast.models';

@Component({
  selector: 'app-routing-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col p-4 gap-4 overflow-y-auto bg-[#0b0e14]">
      <!-- Header Bar -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#21262d]">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#58a6ff]">hub</mat-icon>
            <h1 class="text-base font-bold font-mono text-white tracking-wide">
              SMPTE ST 2110 IP ROUTING MATRIX & NMOS IS-04 / IS-05 FABRIC
            </h1>
          </div>
          <p class="text-xs text-[#8b949e] font-sans mt-0.5">
            Software-defined IP cross-point routing matrix. ST 2110-20 (Video), ST 2110-30 (Audio), ST 2110-40 (Ancillary Subtitles).
          </p>
        </div>

        <div class="flex items-center gap-3 text-xs font-mono">
          <span class="text-[#3fb950] font-bold">● NMOS REGISTRY ONLINE</span>
          <span class="text-white px-2 py-0.5 rounded bg-[#161b22] border border-[#30363d]">100GbE FABRIC</span>
        </div>
      </div>

      <!-- IP Routing Cross-Point Matrix Table -->
      <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-4 shadow-md flex flex-col gap-3">
        <div class="flex items-center justify-between">
          <div class="text-xs font-mono font-bold text-white uppercase flex items-center gap-2">
            <span>CROSS-POINT MATRIX SWITCHING</span>
            <span class="text-[10px] text-[#8b949e] font-normal">(Click any circle to latch route)</span>
          </div>
          <div class="text-[10px] font-mono text-[#8b949e]">
            RED = PGM TALLY • GREEN = PVW TALLY • BLUE = LATCHED
          </div>
        </div>

        <!-- Cross-point Grid -->
        <div class="overflow-x-auto">
          <table class="w-full text-center font-mono text-xs border-collapse">
            <thead>
              <tr class="bg-[#161b22] text-[10px] text-[#8b949e] border-b border-[#30363d]">
                <th class="py-2.5 px-3 text-left">DESTINATION (RECEIVER)</th>
                @for (src of state.sources(); track src.id) {
                  <th class="py-2.5 px-2 whitespace-nowrap" [title]="src.name">
                    <div class="font-bold text-white">{{ src.code }}</div>
                    <div class="text-[8px] opacity-75">{{ src.location }}</div>
                  </th>
                }
              </tr>
            </thead>
            <tbody class="divide-y divide-[#21262d]">
              @for (dst of state.destinations(); track dst.id) {
                <tr class="hover:bg-[#161b22]/50 transition-colors">
                  <!-- Destination Name -->
                  <td class="py-2.5 px-3 text-left font-bold text-white flex items-center justify-between">
                    <span>{{ dst.code }}</span>
                    <span class="text-[10px] text-[#8b949e] font-normal hidden sm:inline">{{ dst.name }}</span>
                  </td>

                  <!-- Source Crosspoint Buttons -->
                  @for (src of state.sources(); track src.id) {
                    <td class="py-2.5 px-2">
                      <button
                        (click)="state.routeMatrixCrossPoint(dst.id, src.id)"
                        [class.bg-[#da3633]]="dst.routedSourceId === src.id && dst.id === 'dst_vm_pgm'"
                        [class.bg-[#238636]]="dst.routedSourceId === src.id && dst.id === 'dst_vm_pvw'"
                        [class.bg-[#1f6feb]]="dst.routedSourceId === src.id && dst.id !== 'dst_vm_pgm' && dst.id !== 'dst_vm_pvw'"
                        [class.bg-[#21262d]]="dst.routedSourceId !== src.id"
                        [class.border-[#58a6ff]]="dst.routedSourceId === src.id"
                        class="w-6 h-6 rounded-full border border-[#30363d] transition-all hover:scale-110 active:scale-95 flex items-center justify-center mx-auto shadow-sm"
                        [title]="'Route ' + src.code + ' to ' + dst.code">
                        @if (dst.routedSourceId === src.id) {
                          <span class="w-2 h-2 rounded-full bg-white shadow-inner"></span>
                        }
                      </button>
                    </td>
                  }
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Signal Path Tracer & Stream Dissector -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        @for (dst of state.destinations().slice(0, 3); track dst.id) {
          @let activeSrc = getSource(dst.routedSourceId);
          <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-3 flex flex-col justify-between text-xs font-mono">
            <div>
              <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
                <span class="font-bold text-white">{{ dst.code }}</span>
                <span class="px-1.5 py-0.5 rounded text-[10px] bg-[#238636]/20 text-[#3fb950]">{{ dst.status }}</span>
              </div>

              <div class="mt-2.5 space-y-1.5 text-[11px]">
                <div class="flex items-center justify-between">
                  <span class="text-[#8b949e]">Routed Source:</span>
                  <span class="text-[#58a6ff] font-bold">{{ activeSrc?.code }} ({{ activeSrc?.name }})</span>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-[#8b949e]">Video (ST 2110-20):</span>
                  <span class="text-white">{{ activeSrc?.format }}</span>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-[#8b949e]">Audio (ST 2110-30):</span>
                  <span class="text-white">8 Ch 24-bit 48kHz</span>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-[#8b949e]">Ancillary (ST 2110-40):</span>
                  <span class="text-white">OP-47 Subtitles</span>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-[#8b949e]">Multicast Stream:</span>
                  <span class="text-[#8b949e]">{{ activeSrc?.multicastIp }}</span>
                </div>
              </div>
            </div>

            <div class="pt-2 border-t border-[#21262d] flex items-center justify-between text-[10px] text-[#8b949e]">
              <span>PTP OFFSET: {{ activeSrc?.ptpOffsetNs }} ns</span>
              <span class="text-[#3fb950]">HITLESS REDUNDANT</span>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class RoutingViewComponent {
  state = inject(BroadcastStateService);

  getSource(id: string): BroadcastSource | undefined {
    return this.state.sources().find((s) => s.id === id);
  }
}
