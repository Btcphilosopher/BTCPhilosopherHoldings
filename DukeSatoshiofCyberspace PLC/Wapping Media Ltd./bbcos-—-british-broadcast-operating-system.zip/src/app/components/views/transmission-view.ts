import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastStateService } from '../../services/broadcast-state.service';

@Component({
  selector: 'app-transmission-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col p-4 gap-4 overflow-y-auto bg-[#0b0e14]">
      <!-- Header Bar -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#21262d]">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#58a6ff]">cell_tower</mat-icon>
            <h1 class="text-base font-bold font-mono text-white tracking-wide">
              UK TRANSMISSION & MULTI-REGION DISTRIBUTION ENGINE
            </h1>
          </div>
          <p class="text-xs text-[#8b949e] font-sans mt-0.5">
            DVB-T2 Freeview terrestrial network, Low-Latency CMAF streaming ladder, and HbbTV Connected TV sync.
          </p>
        </div>

        <div class="flex items-center gap-3 text-xs font-mono">
          <div class="px-2.5 py-1 rounded bg-[#161b22] border border-[#30363d] text-white">
            TOTAL OTT CONCURRENT: <span class="text-[#58a6ff] font-bold">2,957,000</span>
          </div>
          <div class="px-2.5 py-1 rounded bg-[#238636]/20 border border-[#238636]/40 text-[#3fb950] font-bold">
            DTT PSB1: 98.5% UK REACH
          </div>
        </div>
      </div>

      <!-- Two Column Layout: Terrestrial DTT vs OTT Streaming & Low Latency Lab -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 flex-1 items-stretch">
        <!-- Left: UK Terrestrial DTT Transmitter Network -->
        <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-4 shadow-md flex flex-col justify-between gap-3">
          <div>
            <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
              <div class="text-xs font-mono font-bold text-white uppercase flex items-center gap-2">
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#58a6ff]">broadcast_on_personal</mat-icon>
                <span>DVB-T2 FREEVIEW MAIN TRANSMITTER SITES</span>
              </div>
              <span class="text-[10px] font-mono text-[#3fb950]">6 MAIN SITES ALL NOMINAL</span>
            </div>

            <div class="mt-3 space-y-2 font-mono text-xs">
              @for (tx of state.transmitters(); track tx.id) {
                <div class="bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 flex items-center justify-between shadow-sm hover:border-[#58a6ff]/50 transition-all">
                  <div>
                    <div class="flex items-center gap-2">
                      <span class="w-2 h-2 rounded-full bg-[#3fb950]"></span>
                      <span class="font-bold text-white text-xs">{{ tx.siteName }}</span>
                    </div>
                    <div class="text-[10px] text-[#8b949e] mt-0.5">
                      {{ tx.region }} • {{ tx.frequencyMhz }} MHz (ERP: {{ tx.erpKw }} kW) • Feed: {{ tx.feedSource }}
                    </div>
                  </div>

                  <div class="text-right">
                    <div class="text-[#58a6ff] font-bold text-xs">{{ tx.coveragePopMillion }}M Pop</div>
                    <span class="text-[9px] px-1.5 py-0.2 rounded bg-[#238636]/20 text-[#3fb950] font-bold">
                      {{ tx.status }}
                    </span>
                  </div>
                </div>
              }
            </div>
          </div>

          <div class="pt-2 border-t border-[#21262d] flex items-center justify-between text-[10px] font-mono text-[#8b949e]">
            <span>MUX: PSB1 (BBCOS-A) • 24.13 Mbps</span>
            <span class="text-[#3fb950]">TERRESTRIAL RF NOMINAL</span>
          </div>
        </div>

        <!-- Right: ABR Streaming Ladder & Low Latency CMAF Lab -->
        <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-4 shadow-md flex flex-col justify-between gap-3">
          <div>
            <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
              <div class="text-xs font-mono font-bold text-white uppercase flex items-center gap-2">
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#58a6ff]">stream</mat-icon>
                <span>ADAPTIVE BITRATE (ABR) STREAMING LADDER</span>
              </div>
              <span class="text-[10px] font-mono text-[#58a6ff]">DASH / HLS / CMAF</span>
            </div>

            <!-- Streaming Profiles -->
            <div class="mt-3 space-y-2 font-mono text-xs">
              @for (prof of state.streamingProfiles(); track prof.id) {
                <div class="bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 flex items-center justify-between shadow-sm">
                  <div>
                    <div class="font-bold text-white text-xs flex items-center gap-2">
                      <span>{{ prof.name }}</span>
                      <span class="text-[10px] text-[#58a6ff]">{{ prof.codec }}</span>
                    </div>
                    <div class="text-[10px] text-[#8b949e] mt-0.5">
                      {{ prof.videoBitrateKbps }} kbps Video • {{ prof.audioBitrateKbps }} kbps Audio • {{ prof.targetLatencyMode }}
                    </div>
                  </div>

                  <div class="text-right">
                    <div class="text-white font-bold text-xs">{{ (prof.activeViewers / 1000).toFixed(0) }}k Viewers</div>
                    <div class="text-[10px] text-[#3fb950] font-bold">{{ prof.healthPercent }}% Quality</div>
                  </div>
                </div>
              }
            </div>

            <!-- Low Latency Simulation Lab -->
            <div class="mt-4 pt-3 border-t border-[#21262d]">
              <div class="text-xs font-mono font-bold text-white uppercase mb-2">
                LOW-LATENCY CHUNK BUFFER SIMULATOR
              </div>
              <div class="grid grid-cols-3 gap-2 text-center font-mono text-xs">
                <div class="bg-[#161b22] p-2 rounded border border-[#30363d]">
                  <span class="text-[10px] text-[#8b949e] block">LL-CMAF (CHUNKED)</span>
                  <span class="text-[#3fb950] font-bold text-sm">1.4 sec</span>
                  <span class="text-[8px] text-[#8b949e] block mt-0.5">Live Sports / News</span>
                </div>
                <div class="bg-[#161b22] p-2 rounded border border-[#30363d]">
                  <span class="text-[10px] text-[#8b949e] block">STANDARD HLS</span>
                  <span class="text-[#58a6ff] font-bold text-sm">5.8 sec</span>
                  <span class="text-[8px] text-[#8b949e] block mt-0.5">Connected TV</span>
                </div>
                <div class="bg-[#161b22] p-2 rounded border border-[#30363d]">
                  <span class="text-[10px] text-[#8b949e] block">DASH BROADCAST</span>
                  <span class="text-white font-bold text-sm">9.6 sec</span>
                  <span class="text-[8px] text-[#8b949e] block mt-0.5">Maximum Buffer</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Connected TV Sync -->
          <div class="pt-2 border-t border-[#21262d] flex items-center justify-between text-[10px] font-mono text-[#8b949e]">
            <span>HbbTV 2.0 / DVB-CSS COMPANION SYNC</span>
            <span class="text-[#3fb950]">AUDIO WATERMARK ACTIVE</span>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class TransmissionViewComponent {
  state = inject(BroadcastStateService);
}
