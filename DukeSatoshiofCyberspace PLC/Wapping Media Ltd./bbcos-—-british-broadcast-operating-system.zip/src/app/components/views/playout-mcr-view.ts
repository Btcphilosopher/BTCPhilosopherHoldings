import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastStateService } from '../../services/broadcast-state.service';

@Component({
  selector: 'app-playout-mcr-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col p-4 gap-4 overflow-y-auto bg-[#0b0e14]">
      <!-- Header: MCR Status & Chain Controls -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#21262d]">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#58a6ff]">podcasts</mat-icon>
            <h1 class="text-base font-bold font-mono text-white tracking-wide">
              MASTER CONTROL ROOM (MCR) & 24/7 PLAYOUT AUTOMATION
            </h1>
          </div>
          <p class="text-xs text-[#8b949e] font-sans mt-0.5">
            Deterministic playout, SMPTE 2022-7 hitless primary/backup chain, automated continuity junctions, SCTE-35 triggers.
          </p>
        </div>

        <!-- MCR Redundancy Controls -->
        <div class="flex items-center gap-2 font-mono text-xs">
          <!-- Hitless Redundancy Switch -->
          <button
            (click)="state.toggleMcrHitlessFailover()"
            [class.bg-[#238636]/20]="state.mcrPrimaryChainActive()"
            [class.text-[#3fb950]]="state.mcrPrimaryChainActive()"
            [class.border-[#238636]]="state.mcrPrimaryChainActive()"
            [class.bg-[#d29922]/20]="!state.mcrPrimaryChainActive()"
            [class.text-[#d29922]]="!state.mcrPrimaryChainActive()"
            [class.border-[#d29922]]="!state.mcrPrimaryChainActive()"
            class="px-3 py-1.5 rounded border font-bold flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full" [class.bg-[#3fb950]]="state.mcrPrimaryChainActive()" [class.bg-[#d29922]]="!state.mcrPrimaryChainActive()"></span>
            <span>{{ state.mcrPrimaryChainActive() ? 'PRIMARY CHAIN A ACTIVE' : 'BACKUP CHAIN B ACTIVE' }}</span>
          </button>

          <!-- Emergency Slate -->
          <button
            (click)="state.toggleMcrEmergencySlate()"
            [class.bg-[#da3633]]="state.mcrEmergencySlateActive()"
            [class.text-white]="state.mcrEmergencySlateActive()"
            [class.bg-[#21262d]]="!state.mcrEmergencySlateActive()"
            [class.text-[#f85149]]="!state.mcrEmergencySlateActive()"
            class="px-3 py-1.5 rounded font-bold border border-[#30363d] flex items-center gap-1">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">warning</mat-icon>
            <span>{{ state.mcrEmergencySlateActive() ? 'DISENGAGE BREAKDOWN' : 'EMERGENCY BREAKDOWN' }}</span>
          </button>
        </div>
      </div>

      <!-- Transmission Timeline Schedule -->
      <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-4 shadow-md flex flex-col gap-3">
        <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
          <div class="text-xs font-mono font-bold text-white uppercase flex items-center gap-2">
            <span>AUTOMATED 24/7 PLAYOUT SCHEDULE — BRITANNIA 1 HD</span>
          </div>
          <div class="text-[10px] font-mono text-[#8b949e]">
            FRAME-ACCURATE DETERMINISTIC PLAYOUT
          </div>
        </div>

        <div class="space-y-2.5 font-mono text-xs">
          @for (item of state.playoutSchedule(); track item.id) {
            <div
              [class.border-l-4]="true"
              [class.border-l-[#da3633]]="item.state === 'ON_AIR'"
              [class.bg-[#da3633]/10]="item.state === 'ON_AIR'"
              [class.border-l-[#3fb950]]="item.state === 'NEXT'"
              [class.bg-[#161b22]]="item.state !== 'ON_AIR'"
              class="p-3 rounded-r-lg border border-[#30363d] flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm hover:border-[#58a6ff]/50 transition-all">
              
              <!-- Left: Time & Programme Title -->
              <div class="flex items-center gap-3">
                <span class="px-2 py-1 rounded bg-[#0d1117] text-white font-bold text-xs border border-[#30363d]">
                  {{ item.timeSlot }}
                </span>

                <div>
                  <div class="font-bold text-white text-sm">{{ item.programmeTitle }}</div>
                  <div class="text-[10px] text-[#8b949e] font-sans">{{ item.episodeTitle }} • Dur: {{ item.durationTimecode }}</div>
                </div>
              </div>

              <!-- Centre: Secondary Events -->
              <div class="flex items-center gap-2 text-[10px]">
                @if (item.secondaryEvents.optOutTrigger) {
                  <span class="px-1.5 py-0.5 rounded bg-[#1f6feb]/20 text-[#58a6ff] border border-[#1f6feb]/40">OPT-OUT CUE</span>
                }
                @if (item.secondaryEvents.audioDescription) {
                  <span class="px-1.5 py-0.5 rounded bg-[#238636]/20 text-[#3fb950] border border-[#238636]/40">AD TRACK</span>
                }
                <span class="px-1.5 py-0.5 rounded bg-[#21262d] text-[#8b949e]">{{ item.secondaryEvents.subtitlesTrack }}</span>
              </div>

              <!-- Right: Status Badge -->
              <div class="flex items-center gap-2">
                <span class="px-2 py-1 rounded text-xs font-bold"
                  [class.bg-[#da3633]]="item.state === 'ON_AIR'"
                  [class.text-white]="item.state === 'ON_AIR'"
                  [class.bg-[#238636]]="item.state === 'NEXT'"
                  [class.text-white]="item.state === 'NEXT'"
                  [class.bg-[#21262d]]="item.state === 'TRANSMITTED' || item.state === 'SCHEDULED'"
                  [class.text-[#8b949e]]="item.state === 'TRANSMITTED' || item.state === 'SCHEDULED'">
                  {{ item.state }}
                </span>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Bottom: Continuity Engine & Junction Automation Simulator -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <!-- Presentation Continuity Junction Sequence -->
        <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-4 flex flex-col justify-between text-xs font-mono">
          <div>
            <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
              <span class="font-bold text-white uppercase">CONTINUITY JUNCTION AUTOMATION</span>
              <span class="text-[#3fb950] text-[10px] font-bold">NEXT AT 18:30:00</span>
            </div>

            <div class="mt-3 space-y-2 text-[11px]">
              <div class="flex items-center gap-2 p-2 rounded bg-[#161b22] border border-[#30363d]/60">
                <span class="w-4 h-4 rounded-full bg-[#1f6feb] text-white flex items-center justify-center text-[9px] font-bold">1</span>
                <span class="text-white font-bold">Programme End (18:29:40)</span>
                <span class="text-[#8b949e] ml-auto">Credits Squeeze</span>
              </div>
              <div class="flex items-center gap-2 p-2 rounded bg-[#161b22] border border-[#30363d]/60">
                <span class="w-4 h-4 rounded-full bg-[#1f6feb] text-white flex items-center justify-center text-[9px] font-bold">2</span>
                <span class="text-white font-bold">Announcer Voiceover (18:29:45)</span>
                <span class="text-[#58a6ff] ml-auto">"Coming up next..."</span>
              </div>
              <div class="flex items-center gap-2 p-2 rounded bg-[#161b22] border border-[#30363d]/60">
                <span class="w-4 h-4 rounded-full bg-[#1f6feb] text-white flex items-center justify-center text-[9px] font-bold">3</span>
                <span class="text-white font-bold">Channel Ident (18:29:55)</span>
                <span class="text-[#8b949e] ml-auto">Britannia 1 Idents 'Circles'</span>
              </div>
              <div class="flex items-center gap-2 p-2 rounded bg-[#161b22] border border-[#30363d]/60">
                <span class="w-4 h-4 rounded-full bg-[#3fb950] text-black flex items-center justify-center text-[9px] font-bold">4</span>
                <span class="text-[#3fb950] font-bold">Regional News Opt-In (18:30:00)</span>
                <span class="text-[#3fb950] ml-auto">SCTE-35 Trigger OK</span>
              </div>
            </div>
          </div>

          <div class="pt-2 border-t border-[#21262d] text-[10px] text-[#8b949e] flex items-center justify-between">
            <span>ANN: J. CARTER (LIVE BOOTH 2)</span>
            <span class="text-white">AUTO-FIRE READY</span>
          </div>
        </div>

        <!-- MCR Signal Confidence & Audio Telemetry -->
        <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-4 flex flex-col justify-between text-xs font-mono">
          <div>
            <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
              <span class="font-bold text-white uppercase">MCR TRANSMISSION HEALTH & REDUNDANCY</span>
              <span class="text-[#3fb950] text-[10px] font-bold">CONFIDENCE: 100%</span>
            </div>

            <div class="mt-3 space-y-2 text-[11px]">
              <div class="flex items-center justify-between p-2 rounded bg-[#161b22] border border-[#30363d]/60">
                <span class="text-[#8b949e]">Primary Encoder Node A:</span>
                <span class="text-[#3fb950] font-bold">ONLINE (1080p50 HEVC)</span>
              </div>
              <div class="flex items-center justify-between p-2 rounded bg-[#161b22] border border-[#30363d]/60">
                <span class="text-[#8b949e]">Backup Encoder Node B:</span>
                <span class="text-[#58a6ff] font-bold">HOT STANDBY (0.4ms Switch)</span>
              </div>
              <div class="flex items-center justify-between p-2 rounded bg-[#161b22] border border-[#30363d]/60">
                <span class="text-[#8b949e]">DTT Freeview Multiplex Ingest:</span>
                <span class="text-[#3fb950] font-bold">LOCKED 24.13 Mbps</span>
              </div>
              <div class="flex items-center justify-between p-2 rounded bg-[#161b22] border border-[#30363d]/60">
                <span class="text-[#8b949e]">EBU R128 Transmission Loudness:</span>
                <span class="text-[#3fb950] font-bold">-23.0 LUFS (OK)</span>
              </div>
            </div>
          </div>

          <div class="pt-2 border-t border-[#21262d] text-[10px] text-[#8b949e] flex items-center justify-between">
            <span>TRANSMISSION HUB: LONDON W1A</span>
            <span class="text-[#3fb950]">PSB REGIONAL CARRIER LOCKED</span>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class PlayoutMcrViewComponent {
  state = inject(BroadcastStateService);
}
