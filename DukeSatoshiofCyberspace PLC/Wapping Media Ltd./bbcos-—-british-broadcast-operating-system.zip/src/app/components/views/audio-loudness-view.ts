import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastStateService } from '../../services/broadcast-state.service';

@Component({
  selector: 'app-audio-loudness-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col p-4 gap-4 overflow-y-auto bg-[#0b0e14]">
      <!-- Header: Audio Console & EBU R128 Compliance Banner -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#21262d]">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#58a6ff]">equalizer</mat-icon>
            <h1 class="text-base font-bold font-mono text-white tracking-wide">
              10-CHANNEL AUDIO CONSOLE & EBU R128 LOUDNESS MONITOR
            </h1>
          </div>
          <p class="text-xs text-[#8b949e] font-sans mt-0.5">
            EBU R128 UK Delivery Standard. Target: -23.0 LUFS (±0.5 LU) • Max True Peak: -1.0 dBTP • 48 kHz 24-bit.
          </p>
        </div>

        <!-- Compliance Badge -->
        <div class="flex items-center gap-2">
          <div class="px-3 py-1.5 rounded bg-[#238636]/20 border border-[#238636]/40 font-mono text-xs text-[#3fb950] font-bold flex items-center gap-1.5">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">verified</mat-icon>
            <span>EBU R128 COMPLIANT (-23.0 LUFS)</span>
          </div>
        </div>
      </div>

      <!-- Top Row: Comprehensive EBU R128 Loudness Dashboard -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <!-- Integrated LUFS -->
        <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[10px] font-mono text-[#8b949e]">INTEGRATED (I)</span>
          <div class="text-xl font-mono font-bold text-[#3fb950] my-1">
            {{ state.loudness().integratedLufs }} <span class="text-xs font-normal text-[#8b949e]">LUFS</span>
          </div>
          <span class="text-[9px] font-mono text-[#8b949e]">TARGET: -23.0 LUFS</span>
        </div>

        <!-- Short Term LUFS -->
        <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[10px] font-mono text-[#8b949e]">SHORT TERM (3s)</span>
          <div class="text-xl font-mono font-bold text-white my-1">
            {{ state.loudness().shortTermLufs }} <span class="text-xs font-normal text-[#8b949e]">LUFS</span>
          </div>
          <span class="text-[9px] font-mono text-[#3fb950]">IN TOLERANCE</span>
        </div>

        <!-- Momentary LUFS -->
        <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[10px] font-mono text-[#8b949e]">MOMENTARY (400ms)</span>
          <div class="text-xl font-mono font-bold text-[#58a6ff] my-1">
            {{ state.loudness().momentaryLufs }} <span class="text-xs font-normal text-[#8b949e]">LUFS</span>
          </div>
          <span class="text-[9px] font-mono text-[#8b949e]">WINDOW: 400ms</span>
        </div>

        <!-- Loudness Range (LRA) -->
        <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[10px] font-mono text-[#8b949e]">LOUDNESS RANGE (LRA)</span>
          <div class="text-xl font-mono font-bold text-white my-1">
            {{ state.loudness().loudnessRangeLra }} <span class="text-xs font-normal text-[#8b949e]">LU</span>
          </div>
          <span class="text-[9px] font-mono text-[#8b949e]">DYNAMIC RANGE OK</span>
        </div>

        <!-- True Peak (dBTP) -->
        <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[10px] font-mono text-[#8b949e]">MAX TRUE PEAK</span>
          <div class="text-xl font-mono font-bold text-[#3fb950] my-1">
            {{ state.loudness().truePeakDbtp }} <span class="text-xs font-normal text-[#8b949e]">dBTP</span>
          </div>
          <span class="text-[9px] font-mono text-[#8b949e]">LIMIT: -1.0 dBTP</span>
        </div>

        <!-- Dialogue Level -->
        <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-3 flex flex-col justify-between">
          <span class="text-[10px] font-mono text-[#8b949e]">DIALOGUE LEVEL</span>
          <div class="text-xl font-mono font-bold text-white my-1">
            {{ state.loudness().dialogueLufs }} <span class="text-xs font-normal text-[#8b949e]">LUFS</span>
          </div>
          <span class="text-[9px] font-mono text-[#3fb950]">ANCHOR MIC BALANCED</span>
        </div>
      </div>

      <!-- Main Audio Console: 10 Channel Strips -->
      <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-4 shadow-md flex-1 flex flex-col gap-3">
        <div class="flex items-center justify-between pb-2 border-b border-[#21262d]">
          <div class="text-xs font-mono font-bold text-white uppercase">
            GALLERY PRODUCTION AUDIO MIXER STRIPS
          </div>
          <div class="text-[10px] font-mono text-[#8b949e]">
            SMPTE ST 2110-30 MULTICHANNEL ESSENCE
          </div>
        </div>

        <!-- 10 Vertical Channel Strips -->
        <div class="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-2 flex-1 items-stretch">
          @for (ch of state.audioChannels(); track ch.id) {
            <div
              [class.bg-[#161b22]]="!ch.mute"
              [class.bg-[#1a0f12]]="ch.mute"
              class="border border-[#30363d] rounded-lg p-2 flex flex-col justify-between text-xs font-mono shadow-sm">
              
              <!-- Channel Header -->
              <div class="text-center pb-1 border-b border-[#30363d]/60">
                <div class="font-bold text-white text-[11px] truncate" [title]="ch.name">{{ ch.name }}</div>
                <div class="text-[8px] text-[#8b949e] truncate">{{ ch.sourceLabel }}</div>
              </div>

              <!-- Mute & Solo Buttons -->
              <div class="grid grid-cols-2 gap-1 my-2">
                <button
                  (click)="state.toggleChannelMute(ch.id)"
                  [class.bg-[#da3633]]="ch.mute"
                  [class.text-white]="ch.mute"
                  [class.bg-[#21262d]]="!ch.mute"
                  [class.text-[#8b949e]]="!ch.mute"
                  class="py-1 rounded text-[10px] font-bold border border-[#30363d] hover:brightness-125">
                  MUTE
                </button>

                <button
                  (click)="state.toggleChannelSolo(ch.id)"
                  [class.bg-[#d29922]]="ch.solo"
                  [class.text-black]="ch.solo"
                  [class.bg-[#21262d]]="!ch.solo"
                  [class.text-[#8b949e]]="!ch.solo"
                  class="py-1 rounded text-[10px] font-bold border border-[#30363d] hover:brightness-125">
                  SOLO
                </button>
              </div>

              <!-- LED Bargraph Meter & Fader (Vertical) -->
              <div class="flex items-center justify-center gap-2 my-2 flex-1 min-h-[140px]">
                <!-- Meter Bargraph -->
                <div class="w-3 h-full bg-[#0d1117] rounded-full overflow-hidden flex flex-col-reverse p-0.5 border border-[#30363d]">
                  <div class="w-full bg-gradient-to-t from-[#238636] via-[#d29922] to-[#da3633] rounded-full transition-all duration-75"
                    [style.height.%]="getMeterHeight(ch.peakDb)"></div>
                </div>

                <!-- Vertical Fader Slider -->
                <div class="flex flex-col items-center justify-between h-full py-1">
                  <span class="text-[9px] text-[#8b949e]">+10</span>
                  <input
                    type="range"
                    min="-40"
                    max="10"
                    step="0.5"
                    [value]="ch.faderDb"
                    (input)="onFaderChange(ch.id, $event)"
                    orient="vertical"
                    class="accent-[#58a6ff] cursor-pointer h-24 w-4 bg-[#21262d] rounded" />
                  <span class="text-[9px] text-[#8b949e]">-∞</span>
                </div>
              </div>

              <!-- Value Readout & Assigned Group -->
              <div class="pt-1.5 border-t border-[#30363d]/60 text-center">
                <div class="font-bold text-white text-[10px]">
                  {{ ch.faderDb > -40 ? (ch.faderDb > 0 ? '+' + ch.faderDb : ch.faderDb) + ' dB' : '-∞ dB' }}
                </div>
                <div class="text-[8px] text-[#58a6ff] mt-0.5 font-semibold">{{ ch.assignedGroup }}</div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class AudioLoudnessViewComponent {
  state = inject(BroadcastStateService);

  getMeterHeight(peakDb: number) {
    if (peakDb <= -60) return 0;
    return Math.max(0, Math.min(100, ((peakDb + 60) / 60) * 100));
  }

  onFaderChange(channelId: string, event: Event) {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.setChannelFader(channelId, val);
  }
}
