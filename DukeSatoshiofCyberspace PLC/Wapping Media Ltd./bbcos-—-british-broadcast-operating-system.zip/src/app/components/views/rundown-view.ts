import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastStateService } from '../../services/broadcast-state.service';

@Component({
  selector: 'app-rundown-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full flex flex-col p-4 gap-4 overflow-y-auto bg-[#0b0e14]">
      <!-- Header: Programme Rundown Timing & Back-timing Status -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-[#21262d]">
        <div>
          <div class="flex items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-full bg-[#da3633] animate-pulse"></span>
            <h1 class="text-base font-bold font-mono text-white tracking-wide">
              {{ state.rundown().programmeTitle }} ({{ state.rundown().serviceCode }})
            </h1>
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#da3633]/20 text-[#f85149] border border-[#da3633]/40">
              TRANSMITTING LIVE
            </span>
          </div>
          <p class="text-xs text-[#8b949e] font-sans mt-0.5">
            Deterministic timed rundown. Scheduled: {{ state.rundown().scheduledStartTime }} – {{ state.rundown().scheduledEndTime }} (30m 00s).
          </p>
        </div>

        <!-- Master Back-Timing & Pacing Block -->
        <div class="flex items-center gap-3">
          <!-- Offset Calculator Display -->
          <div class="px-3 py-1.5 rounded bg-[#161b22] border border-[#30363d] font-mono text-xs flex items-center gap-2">
            <span class="text-[#8b949e]">PACING:</span>
            <span class="font-bold px-1.5 py-0.5 rounded text-xs"
              [class.bg-[#da3633]/20]="state.rundown().timingStatus === 'BEHIND'"
              [class.text-[#f85149]]="state.rundown().timingStatus === 'BEHIND'"
              [class.bg-[#3fb950]/20]="state.rundown().timingStatus === 'ON_TIME'"
              [class.text-[#3fb950]]="state.rundown().timingStatus === 'ON_TIME'"
              [class.bg-[#d29922]/20]="state.rundown().timingStatus === 'AHEAD'"
              [class.text-[#d29922]]="state.rundown().timingStatus === 'AHEAD'">
              +00:08 BEHIND
            </span>
          </div>

          <!-- Transport Execution Controls -->
          <button
            (click)="state.takeNextRundownItem()"
            class="px-4 py-2 rounded-lg bg-[#da3633] text-white hover:bg-[#f85149] active:scale-95 font-mono font-bold text-xs flex items-center gap-1.5 shadow-lg border border-[#f85149] transition-all">
            <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">play_arrow</mat-icon>
            <span>TAKE NEXT ITEM</span>
          </button>
        </div>
      </div>

      <!-- Live Rundown Progress Bar -->
      <div class="bg-[#12161f] border border-[#21262d] rounded-xl p-3 flex flex-col gap-2 shadow-sm">
        <div class="flex items-center justify-between text-xs font-mono">
          <span class="text-[#8b949e]">PROGRAMME TIMELINE (18:00:00 - 18:30:00)</span>
          <span class="text-white font-bold">ITEM {{ state.rundown().currentItemIndex + 1 }} OF {{ state.rundown().items.length }}</span>
        </div>
        <div class="w-full h-3 bg-[#161b22] rounded-full overflow-hidden flex border border-[#30363d]/60">
          <div class="h-full bg-gradient-to-r from-[#1f6feb] to-[#58a6ff] transition-all duration-500 rounded-full"
            [style.width.%]="getProgressPercent()"></div>
        </div>
      </div>

      <!-- Main Rundown Table -->
      <div class="bg-[#12161f] border border-[#21262d] rounded-xl overflow-hidden shadow-md flex-1 flex flex-col">
        <div class="overflow-x-auto flex-1">
          <table class="w-full text-left font-mono text-xs border-collapse">
            <thead>
              <tr class="bg-[#161b22] text-[10px] text-[#8b949e] border-b border-[#30363d] uppercase tracking-wider">
                <th class="py-2 px-3">#</th>
                <th class="py-2 px-3">STATUS</th>
                <th class="py-2 px-3">START</th>
                <th class="py-2 px-3">DUR</th>
                <th class="py-2 px-3">TITLE & STORY SLUG</th>
                <th class="py-2 px-3">SRC</th>
                <th class="py-2 px-3">GFX CUE</th>
                <th class="py-2 px-3">AUDIO SETUP</th>
                <th class="py-2 px-3 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#21262d]">
              @for (item of state.rundown().items; track item.id; let idx = $index) {
                <tr
                  [class.bg-[#da3633]/15]="item.status === 'ON_AIR'"
                  [class.border-l-4]="item.status === 'ON_AIR'"
                  [class.border-l-[#da3633]]="item.status === 'ON_AIR'"
                  [class.bg-[#238636]/10]="item.status === 'CUED'"
                  [class.opacity-50]="item.floatItem"
                  class="hover:bg-[#161b22]/70 transition-colors">
                  
                  <!-- Index -->
                  <td class="py-2.5 px-3 font-bold text-[#8b949e]">
                    {{ item.itemNumber }}
                  </td>

                  <!-- Status Tally -->
                  <td class="py-2.5 px-3">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                      [class.bg-[#da3633]]="item.status === 'ON_AIR'"
                      [class.text-white]="item.status === 'ON_AIR'"
                      [class.bg-[#238636]]="item.status === 'CUED'"
                      [class.text-white]="item.status === 'CUED'"
                      [class.bg-[#21262d]]="item.status === 'COMPLETED' || item.status === 'PENDING'"
                      [class.text-[#8b949e]]="item.status === 'COMPLETED' || item.status === 'PENDING'">
                      {{ item.status }}
                    </span>
                  </td>

                  <!-- Planned Start Time -->
                  <td class="py-2.5 px-3 font-semibold text-white">
                    {{ item.plannedStartTime }}
                  </td>

                  <!-- Duration -->
                  <td class="py-2.5 px-3 text-[#58a6ff]">
                    {{ formatDuration(item.plannedDurationSec) }}
                  </td>

                  <!-- Title & Slug -->
                  <td class="py-2.5 px-3">
                    <div class="font-bold text-white text-xs">{{ item.title }}</div>
                    <div class="text-[10px] text-[#8b949e]">{{ item.slug }} • {{ item.scriptSlug }}</div>
                  </td>

                  <!-- Source Code -->
                  <td class="py-2.5 px-3 font-bold text-[#3fb950]">
                    {{ item.sourceCode }}
                  </td>

                  <!-- Graphics Cue -->
                  <td class="py-2.5 px-3 text-[#a371f7] text-[11px]">
                    {{ item.graphicsCue }}
                  </td>

                  <!-- Audio Setup -->
                  <td class="py-2.5 px-3 text-[#8b949e] text-[11px]">
                    {{ item.audioSetup }}
                  </td>

                  <!-- Actions (Cue, Float) -->
                  <td class="py-2.5 px-3 text-right">
                    <div class="flex items-center justify-end gap-1.5">
                      <button
                        (click)="state.cueRundownItem(idx)"
                        [disabled]="item.status === 'ON_AIR' || item.status === 'COMPLETED'"
                        class="px-2 py-1 rounded bg-[#21262d] text-white hover:bg-[#30363d] disabled:opacity-30 text-[10px] font-bold border border-[#30363d]">
                        CUE
                      </button>

                      <button
                        (click)="state.toggleFloatItem(item.id)"
                        [class.text-[#f85149]]="item.floatItem"
                        [class.text-[#8b949e]]="!item.floatItem"
                        class="px-2 py-1 rounded bg-[#161b22] hover:bg-[#21262d] text-[10px] font-bold border border-[#30363d]">
                        {{ item.floatItem ? 'UNFLOAT' : 'FLOAT' }}
                      </button>
                    </div>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>

        <!-- Table Footer -->
        <div class="p-3 bg-[#161b22] border-t border-[#21262d] flex flex-wrap items-center justify-between text-xs font-mono text-[#8b949e]">
          <div class="flex items-center gap-4">
            <span>TOTAL ITEMS: {{ state.rundown().items.length }}</span>
            <span>FLOATED ITEMS: 0</span>
            <span class="text-white font-bold">TOTAL PROGRAMME RUNTIME: 30:08</span>
          </div>
          <div class="text-[#3fb950] font-semibold">
            SYNCHRONIZED WITH GALLERY VISION MIXER
          </div>
        </div>
      </div>
    </div>
  `,
})
export class RundownViewComponent {
  state = inject(BroadcastStateService);

  formatDuration(sec: number) {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  getProgressPercent() {
    const total = this.state.rundown().items.length;
    const current = this.state.rundown().currentItemIndex;
    return Math.round(((current + 1) / total) * 100);
  }
}
