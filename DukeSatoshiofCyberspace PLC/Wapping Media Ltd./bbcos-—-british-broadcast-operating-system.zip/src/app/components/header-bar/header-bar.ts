import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastStateService } from '../../services/broadcast-state.service';
import { FacilityLocation } from '../../models/broadcast.models';

@Component({
  selector: 'app-header-bar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <header class="h-14 bg-[#0d1117] border-b border-[#21262d] px-4 flex items-center justify-between select-none z-30 shrink-0">
      <!-- Left: Identity & Facility Hub -->
      <div class="flex items-center gap-4">
        <div class="flex items-center gap-2.5">
          <div class="w-7 h-7 rounded bg-[#1f242c] border border-[#30363d] flex items-center justify-center font-mono font-bold text-xs text-[#58a6ff] tracking-tighter shadow-sm">
            BB
          </div>
          <div>
            <div class="flex items-center gap-2">
              <span class="font-bold text-xs tracking-wider text-white uppercase font-mono">BBCOS</span>
              <span class="text-[10px] px-1.5 py-0.5 rounded bg-[#21262d] text-[#8b949e] font-mono border border-[#30363d]">v2026.4</span>
            </div>
            <p class="text-[10px] text-[#8b949e] font-medium leading-none mt-0.5 hidden sm:block">British Broadcast Operating System</p>
          </div>
        </div>

        <div class="h-6 w-[1px] bg-[#21262d]"></div>

        <!-- Facility Selector -->
        <div class="flex items-center gap-1.5">
          <mat-icon class="text-[#8b949e] !text-[16px] !w-[16px] !h-[16px]">location_on</mat-icon>
          <div class="flex items-center bg-[#161b22] border border-[#30363d] rounded p-0.5 text-xs font-mono">
            @for (fac of facilities; track fac.key) {
              <button
                (click)="setFacility(fac.key)"
                [class.bg-[#1f6feb]]="state.selectedFacility() === fac.key"
                [class.text-white]="state.selectedFacility() === fac.key"
                [class.text-[#8b949e]]="state.selectedFacility() !== fac.key"
                class="px-2 py-0.5 rounded text-[11px] font-semibold transition-colors hover:text-white"
                [title]="fac.desc">
                {{ fac.label }}
              </button>
            }
          </div>
        </div>
      </div>

      <!-- Centre: Master Broadcast Clock, Timecode, PTP Sync -->
      <div class="flex items-center gap-5">
        <!-- PTP Master Sync -->
        <div class="hidden md:flex items-center gap-2 px-2.5 py-1 rounded bg-[#161b22] border border-[#30363d]">
          <div class="relative flex items-center justify-center">
            <span class="w-2 h-2 rounded-full" [class.bg-[#238636]]="state.telemetry().ptpSyncStatus === 'LOCKED'" [class.bg-[#d29922]]="state.telemetry().ptpSyncStatus === 'HOLD_OVER'"></span>
            @if (state.telemetry().ptpSyncStatus === 'LOCKED') {
              <span class="absolute w-3 h-3 rounded-full bg-[#238636]/40 animate-ping"></span>
            }
          </div>
          <div class="text-[10px] font-mono leading-tight">
            <div class="text-[#8b949e] flex items-center gap-1">
              <span>PTP IEEE 1588</span>
              <span class="text-white font-bold">{{ state.telemetry().ptpSyncStatus }}</span>
            </div>
            <div class="text-[#58a6ff]">{{ state.telemetry().ptpOffsetMeanNs }} ns offset</div>
          </div>
        </div>

        <!-- Master Timecode (25fps SMPTE) -->
        <div class="flex items-center gap-2 px-3 py-1 rounded bg-[#090d13] border border-[#30363d] shadow-inner">
          <mat-icon class="text-[#f85149] !text-[16px] !w-[16px] !h-[16px]">schedule</mat-icon>
          <div class="font-mono text-base font-bold text-[#e6edf3] tracking-widest leading-none">
            {{ state.masterTimecode() }}
          </div>
          <span class="text-[9px] font-mono text-[#8b949e] uppercase px-1 py-0.2 rounded bg-[#161b22]">25 FPS</span>
        </div>

        <!-- EBU R128 Compliance -->
        <div class="hidden lg:flex items-center gap-2 px-2.5 py-1 rounded bg-[#161b22] border border-[#30363d]">
          <div class="w-2 h-2 rounded-full" [class.bg-[#238636]]="state.loudness().complianceStatus === 'COMPLIANT'" [class.bg-[#d29922]]="state.loudness().complianceStatus !== 'COMPLIANT'"></div>
          <div class="text-[10px] font-mono leading-tight">
            <div class="text-[#8b949e]">EBU R128 LOUDNESS</div>
            <div class="text-white font-bold">{{ state.loudness().integratedLufs }} LUFS</div>
          </div>
        </div>
      </div>

      <!-- Right: ON AIR Tally, Emergency Slate, AI Assistant -->
      <div class="flex items-center gap-3">
        <!-- Live ON AIR Tally -->
        <div class="flex items-center gap-2 px-3 py-1 rounded font-mono font-bold text-xs uppercase tracking-wider shadow-sm transition-all"
          [class.bg-[#da3633]]="!state.mcrEmergencySlateActive()"
          [class.text-white]="!state.mcrEmergencySlateActive()"
          [class.border-[#f85149]]="!state.mcrEmergencySlateActive()"
          [class.bg-[#30363d]]="state.mcrEmergencySlateActive()"
          [class.text-[#8b949e]]="state.mcrEmergencySlateActive()">
          <span class="w-2 h-2 rounded-full bg-white" [class.animate-pulse]="!state.mcrEmergencySlateActive()"></span>
          <span>{{ state.mcrEmergencySlateActive() ? 'EMERGENCY SLATE' : 'ON AIR' }}</span>
        </div>

        <!-- Emergency Slate Override Button -->
        <button
          (click)="state.toggleMcrEmergencySlate()"
          [class.bg-[#da3633]]="state.mcrEmergencySlateActive()"
          [class.text-white]="state.mcrEmergencySlateActive()"
          [class.bg-[#21262d]]="!state.mcrEmergencySlateActive()"
          [class.text-[#f85149]]="!state.mcrEmergencySlateActive()"
          class="flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-mono font-semibold border border-[#30363d] hover:brightness-125 transition-all"
          title="Master Control Emergency Breakdown / Slate Generator">
          <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">warning</mat-icon>
          <span class="hidden sm:inline">EMERGENCY</span>
        </button>

        <!-- Controlled AI Assistant Button -->
        <button
          (click)="openAiAssistant.emit()"
          class="flex items-center gap-1.5 px-3 py-1 rounded bg-[#1f6feb]/20 text-[#58a6ff] hover:bg-[#1f6feb]/30 border border-[#1f6feb]/40 text-xs font-mono font-semibold transition-all">
          <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">auto_awesome</mat-icon>
          <span class="hidden sm:inline">AI ASSIST</span>
        </button>
      </div>
    </header>
  `,
})
export class HeaderBarComponent {
  state = inject(BroadcastStateService);
  openAiAssistant = output<void>();

  readonly facilities: { key: FacilityLocation; label: string; desc: string }[] = [
    { key: 'LONDON', label: 'LON', desc: 'London Broadcast Centre (W1A)' },
    { key: 'SALFORD', label: 'MAN', desc: 'Salford MediaCity UK' },
    { key: 'CARDIFF', label: 'CDF', desc: 'Cardiff Central Square' },
    { key: 'GLASGOW', label: 'GLA', desc: 'Glasgow Pacific Quay' },
    { key: 'BELFAST', label: 'BFS', desc: 'Belfast Blackstaff' },
  ];

  setFacility(loc: FacilityLocation) {
    this.state.selectedFacility.set(loc);
  }
}
