"""Structured events with bounded queues, rate limiting and dropped counters.

Logging must never become a denial-of-service condition. The :class:`EventBus`
therefore:

* bounds its queue (oldest events are kept; new events are dropped when full),
* applies a token-bucket rate limit per event *kind*,
* counts every dropped event by reason so loss is visible, not silent.

Packet payloads are never captured; events carry header-level fields only, and
those pass through a :class:`~cipher_events.redact.Redactor` before leaving
the process.
"""

from __future__ import annotations

import json
import os
import threading
import time
from collections import deque
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Optional

from .redact import Redactor


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


@dataclass
class Event:
    kind: str  # e.g. "deploy", "packet", "audit", "dynamic_set", "alert"
    component: str  # emitting component, e.g. "cipher_state.engine"
    status: str  # ok | error | info | warning | dropped | accepted | rejected
    message: str = ""
    policy_id: Optional[str] = None
    policy_revision: Optional[int] = None
    rule_id: Optional[str] = None
    action: Optional[str] = None
    network: dict[str, Any] = field(default_factory=dict)  # src, dst, proto, sport, dport, iif, oif
    error: Optional[str] = None
    details: dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=utcnow_iso)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        return {k: v for k, v in d.items() if v not in (None, {}, "")}


class TokenBucket:
    def __init__(self, rate: float, burst: int, clock: Callable[[], float] = time.monotonic):
        self.rate = float(rate)
        self.burst = float(burst)
        self.tokens = float(burst)
        self.clock = clock
        self.last = clock()

    def allow(self, cost: float = 1.0) -> bool:
        now = self.clock()
        self.tokens = min(self.burst, self.tokens + (now - self.last) * self.rate)
        self.last = now
        if self.tokens >= cost:
            self.tokens -= cost
            return True
        return False


class JsonlSink:
    """Append-only JSON-lines file with size-based rotation and retention."""

    def __init__(self, path: str, max_bytes: int = 16 * 1024 * 1024, backups: int = 5, retention_days: Optional[int] = 30):
        self.path = path
        self.max_bytes = max_bytes
        self.backups = backups
        self.retention_days = retention_days
        self._lock = threading.Lock()
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)

    def _rotate(self) -> None:
        for i in range(self.backups - 1, 0, -1):
            src = f"{self.path}.{i}"
            if os.path.exists(src):
                os.replace(src, f"{self.path}.{i + 1}")
        if os.path.exists(self.path):
            os.replace(self.path, f"{self.path}.1")
        last = f"{self.path}.{self.backups + 1}"
        if os.path.exists(last):
            os.unlink(last)

    def enforce_retention(self, now: Optional[float] = None) -> int:
        if self.retention_days is None:
            return 0
        now = now or time.time()
        removed = 0
        for i in range(1, self.backups + 2):
            p = f"{self.path}.{i}"
            if os.path.exists(p) and now - os.path.getmtime(p) > self.retention_days * 86400:
                os.unlink(p)
                removed += 1
        return removed

    def write(self, record: dict[str, Any]) -> None:
        line = json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n"
        with self._lock:
            if os.path.exists(self.path) and os.path.getsize(self.path) + len(line) > self.max_bytes:
                self._rotate()
                self.enforce_retention()
            fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o640)
            try:
                os.write(fd, line.encode())
            finally:
                os.close(fd)


class EventBus:
    def __init__(
        self,
        *,
        max_queue: int = 10_000,
        rate_per_kind: float = 200.0,
        burst_per_kind: int = 400,
        redactor: Optional[Redactor] = None,
        sinks: Optional[list[Callable[[dict[str, Any]], None]]] = None,
        clock: Callable[[], float] = time.monotonic,
    ):
        self.max_queue = max_queue
        self.queue: deque[dict[str, Any]] = deque()
        self.rate = rate_per_kind
        self.burst = burst_per_kind
        self.redactor = redactor or Redactor()
        self.sinks = list(sinks or [])
        self.clock = clock
        self._buckets: dict[str, TokenBucket] = {}
        self._lock = threading.Lock()
        self.published = 0
        self.dropped: dict[str, int] = {"rate_limited": 0, "queue_full": 0, "sink_error": 0}

    def publish(self, event: Event) -> bool:
        """Queue an event. Returns False (and counts the drop) if it was shed."""
        with self._lock:
            bucket = self._buckets.get(event.kind)
            if bucket is None:
                bucket = self._buckets[event.kind] = TokenBucket(self.rate, self.burst, self.clock)
            if not bucket.allow():
                self.dropped["rate_limited"] += 1
                return False
            if len(self.queue) >= self.max_queue:
                self.dropped["queue_full"] += 1
                return False
            self.queue.append(self.redactor.redact_event(event.to_dict()))
            self.published += 1
            return True

    def drain(self, max_items: Optional[int] = None) -> list[dict[str, Any]]:
        out = []
        with self._lock:
            while self.queue and (max_items is None or len(out) < max_items):
                out.append(self.queue.popleft())
        for rec in out:
            for sink in self.sinks:
                try:
                    sink(rec)
                except Exception:  # noqa: BLE001 - a sink failure must not stop enforcement
                    self.dropped["sink_error"] += 1
        return out

    def counters(self) -> dict[str, Any]:
        with self._lock:
            return {"published": self.published, "queued": len(self.queue), "dropped": dict(self.dropped)}
