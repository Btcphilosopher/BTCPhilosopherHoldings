"""Tamper-evident, append-only audit log.

Every record contains ``prev`` (hash of the previous record) and ``hash``
(SHA-256 over the canonical record including ``prev``). Any edit, deletion or
reordering of past records breaks the chain and is detected by
:func:`verify_chain`. This provides *evidence* of tampering, not prevention:
an attacker with root can rewrite the whole file, so ship the log off-host
(e.g. via journald forwarding) where that matters.

Audited: policy validation/apply/verify/commit, confirmations, rollbacks,
restores, drift detection, administrative requests (allowed and denied),
dynamic-set changes and connection-state interventions.
"""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
import threading
from typing import Any, Iterator, Optional

from .events import utcnow_iso
from .redact import Redactor

GENESIS = "0" * 64


def _canonical(rec: dict[str, Any]) -> bytes:
    return json.dumps(rec, sort_keys=True, separators=(",", ":")).encode()


class AuditLog:
    def __init__(self, path: str, redactor: Optional[Redactor] = None, fsync: bool = True):
        self.path = path
        self.redactor = redactor or Redactor("none")
        self.fsync = fsync
        self._lock = threading.Lock()
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)

    def _last_hash(self) -> str:
        if not os.path.exists(self.path) or os.path.getsize(self.path) == 0:
            return GENESIS
        with open(self.path, "rb") as fh:
            fh.seek(0, os.SEEK_END)
            size = fh.tell()
            back = min(size, 65536)
            fh.seek(size - back)
            tail = fh.read().splitlines()
        for line in reversed(tail):
            if line.strip():
                try:
                    return json.loads(line)["hash"]
                except (ValueError, KeyError):
                    raise RuntimeError(f"audit log {self.path} has a corrupt final record") from None
        return GENESIS

    def record(self, action: str, *, actor: str, outcome: str, **details: Any) -> dict[str, Any]:
        with self._lock:
            fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o640)
            try:
                fcntl.flock(fd, fcntl.LOCK_EX)
                rec: dict[str, Any] = {
                    "ts": utcnow_iso(),
                    "action": action,
                    "actor": actor,
                    "outcome": outcome,
                    "details": self.redactor.redact_details(details),
                    "prev": self._last_hash(),
                }
                rec["hash"] = hashlib.sha256(_canonical(rec)).hexdigest()
                os.write(fd, _canonical(rec) + b"\n")
                if self.fsync:
                    os.fsync(fd)
            finally:
                fcntl.flock(fd, fcntl.LOCK_UN)
                os.close(fd)
        return rec

    def records(self) -> Iterator[dict[str, Any]]:
        if not os.path.exists(self.path):
            return
        with open(self.path) as fh:
            for line in fh:
                if line.strip():
                    yield json.loads(line)


def verify_chain(path: str) -> tuple[bool, int, Optional[str]]:
    """Returns ``(ok, records_checked, problem)``."""
    prev = GENESIS
    n = 0
    if not os.path.exists(path):
        return True, 0, None
    with open(path) as fh:
        for lineno, line in enumerate(fh, 1):
            if not line.strip():
                continue
            try:
                rec = json.loads(line)
            except ValueError:
                return False, n, f"line {lineno}: not JSON"
            claimed = rec.pop("hash", None)
            if rec.get("prev") != prev:
                return False, n, f"line {lineno}: chain broken (prev mismatch)"
            if hashlib.sha256(_canonical(rec)).hexdigest() != claimed:
                return False, n, f"line {lineno}: record hash mismatch (modified)"
            prev = claimed
            n += 1
    return True, n, None
