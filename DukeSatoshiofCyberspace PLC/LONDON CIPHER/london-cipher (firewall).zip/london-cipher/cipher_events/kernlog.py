"""Parse netfilter log lines produced by LONDON CIPHER rules into events.

Rules log with the prefix ``lc:<rule-id>:<tag> `` where tag is ``A`` (accept),
``D`` (drop / default drop) or ``R`` (reject). The kernel appends header
fields (``IN= OUT= SRC= DST= PROTO= SPT= DPT=``). Only these header fields are
extracted; nothing from the payload is captured (the kernel log contains none
unless ``log flags`` request it, which the compiler never does).

Sources: an iterable of text lines, e.g. ``journalctl -k -f -o cat`` output or
``/dev/kmsg``. Reading is bounded by the :class:`~cipher_events.events.EventBus`
rate limiter, so a log flood cannot exhaust memory.
"""

from __future__ import annotations

import re
from typing import Iterable, Iterator, Optional

from .events import Event

_PREFIX_RE = re.compile(r"lc:(?P<rule>[a-z0-9][a-z0-9.\-]{0,63}):(?P<tag>[ADR]) ")
_FIELD_RE = re.compile(r"\b(IN|OUT|SRC|DST|PROTO|SPT|DPT|TYPE|CODE)=(\S*)")
_TAGS = {"A": "accept", "D": "drop", "R": "reject"}
_MAX_LINE = 4096


def parse_line(line: str, policy_id: Optional[str] = None, revision: Optional[int] = None) -> Optional[Event]:
    line = line[:_MAX_LINE]
    m = _PREFIX_RE.search(line)
    if not m:
        return None
    fields = dict(_FIELD_RE.findall(line[m.end():]))
    rule = m.group("rule")
    if rule.startswith("default-"):
        rule = "default." + rule[len("default-"):]
    net: dict = {}
    for key, name in (("IN", "iif"), ("OUT", "oif"), ("SRC", "src"), ("DST", "dst")):
        if fields.get(key):
            net[name] = fields[key]
    if fields.get("PROTO"):
        net["proto"] = fields["PROTO"].lower()
    for key, name in (("SPT", "sport"), ("DPT", "dport"), ("TYPE", "icmp_type"), ("CODE", "icmp_code")):
        if fields.get(key, "").isdigit():
            net[name] = int(fields[key])
    return Event(
        kind="packet",
        component="kernel.nftables",
        status="logged",
        rule_id=rule,
        action=_TAGS[m.group("tag")],
        network=net,
        policy_id=policy_id,
        policy_revision=revision,
    )


def parse_stream(lines: Iterable[str], **kw) -> Iterator[Event]:
    for line in lines:
        ev = parse_line(line, **kw)
        if ev is not None:
            yield ev
