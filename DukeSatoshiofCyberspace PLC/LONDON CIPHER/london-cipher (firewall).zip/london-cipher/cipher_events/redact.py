"""Privacy controls for event data.

Modes for IP addresses in ``network`` fields:

``none``      keep addresses verbatim (default for audit of administrative actions)
``truncate``  zero host bits beyond a prefix (IPv4 /24, IPv6 /48 by default)
``hash``      keyed HMAC-SHA256 pseudonym (stable per key, not reversible
              without the key; the key is read from a file and never logged)

Secrets: any ``details`` key whose name suggests a credential is replaced by
``"[redacted]"`` regardless of mode.
"""

from __future__ import annotations

import hashlib
import hmac
import ipaddress
import re
from typing import Any, Optional

SECRET_KEY_RE = re.compile(r"(secret|password|passwd|token|key|credential|hmac|signature)", re.I)
_ADDR_FIELDS = ("src", "dst", "source", "destination", "peer")


class Redactor:
    def __init__(self, mode: str = "none", v4_prefix: int = 24, v6_prefix: int = 48, key: Optional[bytes] = None):
        if mode not in ("none", "truncate", "hash"):
            raise ValueError(f"unknown redaction mode {mode!r}")
        if mode == "hash" and not key:
            raise ValueError("hash redaction requires a key")
        self.mode = mode
        self.v4_prefix = v4_prefix
        self.v6_prefix = v6_prefix
        self.key = key

    @classmethod
    def from_key_file(cls, mode: str, path: Optional[str], **kw) -> "Redactor":
        key = None
        if path:
            with open(path, "rb") as fh:
                key = fh.read().strip()
        return cls(mode, key=key, **kw)

    def redact_ip(self, value: str) -> str:
        if self.mode == "none":
            return value
        try:
            ip = ipaddress.ip_address(value)
        except ValueError:
            return "[invalid]"
        if self.mode == "truncate":
            plen = self.v4_prefix if ip.version == 4 else self.v6_prefix
            return str(ipaddress.ip_network(f"{ip}/{plen}", strict=False))
        digest = hmac.new(self.key or b"", ip.packed, hashlib.sha256).hexdigest()[:16]
        return f"h:{digest}"

    def redact_details(self, details: dict[str, Any]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for k, v in details.items():
            if SECRET_KEY_RE.search(k) and not k.endswith(("_count", "_present", "sha256", "digest")):
                out[k] = "[redacted]"
            elif isinstance(v, dict):
                out[k] = self.redact_details(v)
            else:
                out[k] = v
        return out

    def redact_event(self, rec: dict[str, Any]) -> dict[str, Any]:
        rec = dict(rec)
        net = rec.get("network")
        if net:
            net = dict(net)
            for f in _ADDR_FIELDS:
                if f in net and isinstance(net[f], str):
                    net[f] = self.redact_ip(net[f])
            rec["network"] = net
        if rec.get("details"):
            rec["details"] = self.redact_details(rec["details"])
        return rec
