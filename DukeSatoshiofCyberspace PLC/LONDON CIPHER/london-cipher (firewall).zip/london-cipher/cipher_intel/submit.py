"""How optional components hand membership changes to enforcement.

Feeds, DNS resolution and detection adapters never write rules. They can only
*propose a new membership* for a dynamic set that the active policy already
declares, through one narrow call — ``dynamic_set_update`` — which the engine
bounds (``max_elements``, family, source type, TTL caps), verifies and audits.
"""

from __future__ import annotations

from typing import Any, Optional, Protocol


class Submitter(Protocol):
    def __call__(
        self,
        name: str,
        values: list[str],
        *,
        source: str,
        provenance: dict[str, Any],
        ttl_seconds: Optional[int] = None,
        element_ttls: Optional[list[int]] = None,
    ) -> dict[str, Any]: ...


class EngineSubmitter:
    """Direct submission to an in-process engine (tests, laboratory)."""

    def __init__(self, engine, actor: str):
        self.engine = engine
        self.actor = actor

    def __call__(self, name, values, *, source, provenance, ttl_seconds=None, element_ttls=None):
        return self.engine.update_dynamic_set(name, values, source=source, actor=self.actor, provenance=provenance, ttl_seconds=ttl_seconds, element_ttls=element_ttls)


class SocketSubmitter:
    """Submission through the admin socket (production; requires the admin role)."""

    def __init__(self, client):
        self.client = client

    def __call__(self, name, values, *, source, provenance, ttl_seconds=None, element_ttls=None):
        args: dict[str, Any] = {"name": name, "values": values, "source": source, "provenance": provenance}
        if ttl_seconds is not None:
            args["ttl_seconds"] = ttl_seconds
        if element_ttls is not None:
            args["element_ttls"] = element_ttls
        return self.client.call("dynamic_set_update", **args)
