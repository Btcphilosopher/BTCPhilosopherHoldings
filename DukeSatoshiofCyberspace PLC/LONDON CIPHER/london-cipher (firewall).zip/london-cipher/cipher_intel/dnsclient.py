"""Minimal, bounded DNS stub client (A/AAAA only) that reports TTLs.

``socket.getaddrinfo`` hides the TTL and the resolver used, both of which must
be recorded for a controlled hostname-to-address service, so this module
speaks the DNS wire format (RFC 1035) directly to one *configured* resolver.

Hardening: random 16-bit IDs and source ports, response ID/question/source
checks, compression-pointer loop limits, bounded message sizes, TCP fallback
on truncation. It is a stub client, not a validating resolver: DNSSEC is not
checked, so the configured resolver must be trusted (e.g. a local validating
resolver on 127.0.0.1).
"""

from __future__ import annotations

import ipaddress
import secrets
import socket
import struct
from dataclasses import dataclass

QTYPES = {"A": 1, "AAAA": 28}
MAX_UDP = 4096
MAX_POINTERS = 32


class DnsError(Exception):
    pass


@dataclass(frozen=True)
class Answer:
    address: str
    ttl: int


def _encode_name(name: str) -> bytes:
    name = name.rstrip(".")
    if not name or len(name) > 253:
        raise DnsError(f"invalid hostname {name!r}")
    out = b""
    for label in name.split("."):
        raw = label.encode("idna")
        if not 0 < len(raw) <= 63:
            raise DnsError(f"invalid label in {name!r}")
        out += bytes([len(raw)]) + raw
    return out + b"\x00"


def build_query(name: str, qtype: str, qid: int) -> bytes:
    header = struct.pack(">HHHHHH", qid, 0x0100, 1, 0, 0, 0)  # RD set
    return header + _encode_name(name) + struct.pack(">HH", QTYPES[qtype], 1)


def _skip_name(msg: bytes, off: int) -> int:
    jumps = 0
    while True:
        if off >= len(msg):
            raise DnsError("truncated name")
        ln = msg[off]
        if ln == 0:
            return off + 1
        if ln & 0xC0 == 0xC0:
            jumps += 1
            if jumps > MAX_POINTERS:
                raise DnsError("compression loop")
            return off + 2
        off += 1 + ln


def _read_name(msg: bytes, off: int) -> str:
    labels, jumps = [], 0
    while True:
        if off >= len(msg):
            raise DnsError("truncated name")
        ln = msg[off]
        if ln == 0:
            return ".".join(labels).lower()
        if ln & 0xC0 == 0xC0:
            jumps += 1
            if jumps > MAX_POINTERS or off + 1 >= len(msg):
                raise DnsError("compression loop")
            off = ((ln & 0x3F) << 8) | msg[off + 1]
            continue
        labels.append(msg[off + 1 : off + 1 + ln].decode("ascii", "replace"))
        off += 1 + ln


def parse_response(msg: bytes, qid: int, name: str, qtype: str) -> tuple[list[Answer], bool]:
    """Returns (answers, truncated). Raises DnsError on mismatch or error rcode."""
    if len(msg) < 12:
        raise DnsError("short response")
    rid, flags, qd, an, _, _ = struct.unpack(">HHHHHH", msg[:12])
    if rid != qid:
        raise DnsError("response id mismatch")
    if not flags & 0x8000:
        raise DnsError("not a response")
    truncated = bool(flags & 0x0200)
    rcode = flags & 0x000F
    if rcode == 3:
        return [], truncated  # NXDOMAIN: empty answer
    if rcode != 0:
        raise DnsError(f"resolver returned rcode {rcode}")
    if qd != 1:
        raise DnsError("unexpected question count")
    off = 12
    if _read_name(msg, off) != name.rstrip(".").lower():
        raise DnsError("question name mismatch")
    off = _skip_name(msg, off)
    qt, _ = struct.unpack(">HH", msg[off : off + 4])
    if qt != QTYPES[qtype]:
        raise DnsError("question type mismatch")
    off += 4
    out: list[Answer] = []
    for _ in range(min(an, 256)):
        off = _skip_name(msg, off)
        if off + 10 > len(msg):
            raise DnsError("truncated record")
        rtype, rclass, ttl, rdlen = struct.unpack(">HHIH", msg[off : off + 10])
        off += 10
        rdata = msg[off : off + rdlen]
        if len(rdata) != rdlen:
            raise DnsError("truncated rdata")
        off += rdlen
        if rclass != 1:
            continue
        if rtype == 1 and qtype == "A" and rdlen == 4:
            out.append(Answer(str(ipaddress.IPv4Address(rdata)), min(ttl, 2**31 - 1)))
        elif rtype == 28 and qtype == "AAAA" and rdlen == 16:
            out.append(Answer(str(ipaddress.IPv6Address(rdata)), min(ttl, 2**31 - 1)))
    return out, truncated


def query(resolver: str, name: str, qtype: str, *, port: int = 53, timeout: float = 2.0) -> list[Answer]:
    ip = ipaddress.ip_address(resolver)
    fam = socket.AF_INET if ip.version == 4 else socket.AF_INET6
    qid = secrets.randbelow(65536)
    q = build_query(name, qtype, qid)
    s = socket.socket(fam, socket.SOCK_DGRAM)
    s.settimeout(timeout)
    try:
        s.sendto(q, (resolver, port))
        while True:
            data, addr = s.recvfrom(MAX_UDP)
            if ipaddress.ip_address(addr[0]) == ip and addr[1] == port:
                break
    except socket.timeout:
        raise DnsError(f"resolver {resolver} timed out") from None
    finally:
        s.close()
    answers, truncated = parse_response(data, qid, name, qtype)
    if not truncated:
        return answers
    t = socket.socket(fam, socket.SOCK_STREAM)
    t.settimeout(timeout)
    try:
        t.connect((resolver, port))
        t.sendall(struct.pack(">H", len(q)) + q)
        hdr = t.recv(2)
        (ln,) = struct.unpack(">H", hdr)
        buf = b""
        while len(buf) < ln:
            chunk = t.recv(ln - len(buf))
            if not chunk:
                break
            buf += chunk
    except (OSError, struct.error) as exc:
        raise DnsError(f"TCP fallback failed: {exc}") from None
    finally:
        t.close()
    return parse_response(buf, qid, name, qtype)[0]


def resolve(resolver: str, name: str, family: str, *, port: int = 53, timeout: float = 2.0) -> list[Answer]:
    return query(resolver, name, "A" if family == "ipv4" else "AAAA", port=port, timeout=timeout)


def build_response(query_msg: bytes, answers: list[tuple[str, int]], *, rcode: int = 0, truncated: bool = False) -> bytes:
    """Construct a response (used by the local test resolver fixture)."""
    qid = struct.unpack(">H", query_msg[:2])[0]
    qend = _skip_name(query_msg, 12) + 4
    question = query_msg[12:qend]
    flags = 0x8180 | rcode | (0x0200 if truncated else 0)
    body = b""
    for addr, ttl in answers:
        ipobj = ipaddress.ip_address(addr)
        rtype = 1 if ipobj.version == 4 else 28
        body += b"\xc0\x0c" + struct.pack(">HHIH", rtype, 1, ttl, len(ipobj.packed)) + ipobj.packed
    return struct.pack(">HHHHHH", qid, flags, 1, len(answers), 0, 0) + question + body


def local_test_resolver(records: dict[tuple[str, str], list[tuple[str, int]]], host: str = "127.0.0.1"):
    """Start a UDP fake resolver on an ephemeral port (tests only). Returns (port, stop)."""
    import threading

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind((host, 0))
    s.settimeout(0.2)
    stop = threading.Event()

    def loop():
        while not stop.is_set():
            try:
                data, addr = s.recvfrom(MAX_UDP)
            except socket.timeout:
                continue
            try:
                name = _read_name(data, 12)
                qt = struct.unpack(">H", data[_skip_name(data, 12) : _skip_name(data, 12) + 2])[0]
                qtype = "A" if qt == 1 else "AAAA"
                recs = records.get((name, qtype))
                resp = build_response(data, recs or [], rcode=0 if recs is not None else 3)
                s.sendto(resp, addr)
            except Exception:  # noqa: BLE001 - fixture
                continue
        s.close()

    threading.Thread(target=loop, daemon=True).start()
    return s.getsockname()[1], stop.set

