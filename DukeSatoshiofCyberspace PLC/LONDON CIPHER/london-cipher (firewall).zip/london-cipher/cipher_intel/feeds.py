"""Threat-intelligence feed adapters with staged activation and rollback.

A feed can only change the *membership* of one feed-sourced dynamic set the
policy already declares; the policy decides what membership means (usually a
drop rule). Reputation membership is not attribution: a listed address is
"reported by <feed> at <time>", nothing more.

Pipeline::

    fetch (bounded bytes, HTTPS with certificate verification or local file)
      -> authenticate (SHA-256 pin and/or HMAC-SHA256 with a key file)
      -> parse + validate (plain or CSV, strict networks, error budget)
      -> filter (family, allowlist exceptions carved out precisely)
      -> limits (max_entries, growth ratio vs. the active version)
      -> stage (versioned, with provenance)  -> [operator review]
      -> activate (atomic set replacement)   -> rollback to any kept version

A feed that unexpectedly expands beyond its limits is rejected and the active
version stays in force.
"""

from __future__ import annotations

import hashlib
import hmac
import ipaddress
import json
import os
import ssl
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from cipher_state.store import atomic_write

from .submit import Submitter

KEEP_VERSIONS = 10


class FeedError(Exception):
    pass


@dataclass
class FeedConfig:
    name: str
    set_name: str
    family: str  # ipv4 | ipv6
    url: str  # https://... or file:///...
    format: str = "plain"  # plain | csv
    csv_column: int = 0
    max_bytes: int = 8 * 1024 * 1024
    max_entries: int = 50_000
    max_growth_ratio: float = 1.5  # new/active entries; None-equivalent when no active version
    min_growth_floor: int = 100  # growth check ignored below this size
    max_invalid_ratio: float = 0.01
    max_age_seconds: int = 7 * 86400  # active data older than this is expired
    sha256: Optional[str] = None
    hmac_key_file: Optional[str] = None
    hmac_signature_url: Optional[str] = None
    allowlist: list[str] = field(default_factory=list)
    timeout: float = 30.0

    def __post_init__(self) -> None:
        scheme = urllib.parse.urlparse(self.url).scheme
        if scheme not in ("https", "file"):
            raise ValueError("feeds must use https:// (verified TLS) or file://")
        if self.family not in ("ipv4", "ipv6"):
            raise ValueError("family must be ipv4 or ipv6")
        if self.format not in ("plain", "csv"):
            raise ValueError("format must be plain or csv")


def _fetch(url: str, max_bytes: int, timeout: float) -> bytes:
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme == "file":
        with open(urllib.parse.unquote(parsed.path), "rb") as fh:
            data = fh.read(max_bytes + 1)
    else:
        ctx = ssl.create_default_context()
        req = urllib.request.Request(url, headers={"User-Agent": "london-cipher-feed/0.1"})
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:  # noqa: S310 - https only
            data = resp.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise FeedError(f"feed exceeds {max_bytes} bytes")
    return data


def parse_feed(data: bytes, fmt: str, column: int = 0) -> tuple[list[ipaddress._BaseNetwork], int, int]:
    """Returns (networks, lines_considered, invalid_count)."""
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        raise FeedError("feed is not UTF-8") from None
    nets, considered, invalid = [], 0, 0
    for line in text.splitlines():
        line = line.split("#", 1)[0].split(";", 1)[0].strip()
        if not line:
            continue
        if fmt == "csv":
            parts = [p.strip().strip('"') for p in line.split(",")]
            if len(parts) <= column:
                invalid += 1
                considered += 1
                continue
            line = parts[column]
            if line.lower() in ("ip", "address", "network", "cidr"):
                continue
        considered += 1
        try:
            nets.append(ipaddress.ip_network(line, strict=True))
        except ValueError:
            invalid += 1
    return nets, considered, invalid


def apply_allowlist(nets: list, allow: list) -> tuple[list, int]:
    """Remove allowlisted space precisely (splitting broader entries)."""
    out, removed = [], 0
    for n in nets:
        pieces = [n]
        for a in allow:
            if a.version != n.version:
                continue
            nxt = []
            for p in pieces:
                if p.subnet_of(a):
                    removed += 1
                    continue
                if a.subnet_of(p):
                    nxt.extend(p.address_exclude(a))
                    removed += 1
                else:
                    nxt.append(p)
            pieces = nxt
        out.extend(pieces)
    return out, removed


class FeedManager:
    def __init__(self, cfg: FeedConfig, store_dir: str, submit: Submitter, clock: Callable[[], float] = time.time, fetch=_fetch):
        self.cfg = cfg
        self.dir = os.path.join(store_dir, cfg.name)
        os.makedirs(self.dir, mode=0o700, exist_ok=True)
        self.submit = submit
        self.clock = clock
        self.fetch = fetch

    # -- persistence ------------------------------------------------------------
    def _path(self, name: str) -> str:
        return os.path.join(self.dir, name)

    def _read(self, name: str) -> Optional[dict[str, Any]]:
        p = self._path(name)
        if not os.path.exists(p):
            return None
        with open(p) as fh:
            return json.load(fh)

    def _write(self, name: str, obj: dict[str, Any]) -> None:
        atomic_write(self._path(name), json.dumps(obj, sort_keys=True).encode())

    def versions(self) -> list[str]:
        return sorted(n[:-5] for n in os.listdir(self.dir) if n.startswith("v-") and n.endswith(".json"))

    def active(self) -> Optional[dict[str, Any]]:
        ptr = self._read("active.json")
        return self._read(f"{ptr['version']}.json") if ptr else None

    # -- pipeline ------------------------------------------------------------------
    def _authenticate(self, data: bytes) -> dict[str, Any]:
        digest = hashlib.sha256(data).hexdigest()
        auth: dict[str, Any] = {"sha256": digest, "methods": []}
        if self.cfg.sha256:
            if not hmac.compare_digest(digest, self.cfg.sha256.lower()):
                raise FeedError("feed SHA-256 does not match the configured pin")
            auth["methods"].append("sha256-pin")
        if self.cfg.hmac_key_file:
            if not self.cfg.hmac_signature_url:
                raise FeedError("hmac_key_file requires hmac_signature_url")
            with open(self.cfg.hmac_key_file, "rb") as fh:
                key = fh.read().strip()
            sig = self.fetch(self.cfg.hmac_signature_url, 1024, self.cfg.timeout).decode().strip()
            want = hmac.new(key, data, hashlib.sha256).hexdigest()
            if not hmac.compare_digest(sig.lower(), want):
                raise FeedError("feed HMAC signature verification failed")
            auth["methods"].append("hmac-sha256")
        if not auth["methods"]:
            auth["methods"].append("tls-transport-only" if self.cfg.url.startswith("https") else "local-file")
        return auth

    def stage(self) -> dict[str, Any]:
        """Fetch, authenticate, validate and stage a new version (no enforcement change)."""
        now = self.clock()
        data = self.fetch(self.cfg.url, self.cfg.max_bytes, self.cfg.timeout)
        auth = self._authenticate(data)
        nets, considered, invalid = parse_feed(data, self.cfg.format, self.cfg.csv_column)
        if considered and invalid / considered > self.cfg.max_invalid_ratio:
            raise FeedError(f"{invalid}/{considered} malformed entries exceed the error budget ({self.cfg.max_invalid_ratio:.1%})")
        want_v = 4 if self.cfg.family == "ipv4" else 6
        other_family = sum(1 for n in nets if n.version != want_v)
        nets = [n for n in nets if n.version == want_v]
        allow = [ipaddress.ip_network(a, strict=True) for a in self.cfg.allowlist]
        nets, allow_removed = apply_allowlist(nets, allow)
        nets = list(ipaddress.collapse_addresses(nets))
        if len(nets) > self.cfg.max_entries:
            raise FeedError(f"feed has {len(nets)} entries; configured limit is {self.cfg.max_entries}")
        act = self.active()
        if act:
            prev = len(act["entries"])
            if len(nets) > max(self.cfg.min_growth_floor, prev * self.cfg.max_growth_ratio):
                raise FeedError(f"feed grew from {prev} to {len(nets)} entries, beyond the allowed ratio {self.cfg.max_growth_ratio}; rejected")
        version = f"v-{int(now * 1000):016d}"
        rec = {
            "version": version,
            "feed": self.cfg.name,
            "set": self.cfg.set_name,
            "source": self.cfg.url,
            "fetched_at": now,
            "auth": auth,
            "entries": [str(n) for n in nets],
            "stats": {"considered": considered, "invalid": invalid, "other_family": other_family, "allowlist_removed": allow_removed},
            "status": "staged",
        }
        self._write(f"{version}.json", rec)
        for old in self.versions()[:-KEEP_VERSIONS]:
            os.unlink(self._path(f"{old}.json"))
        return {k: v for k, v in rec.items() if k != "entries"} | {"count": len(nets)}

    def activate(self, version: Optional[str] = None, actor: str = "system:feed") -> dict[str, Any]:
        """Submit a staged version as the set's membership (atomic in the backend)."""
        version = version or self.versions()[-1]
        rec = self._read(f"{version}.json")
        if rec is None:
            raise FeedError(f"no such version {version}")
        if self.clock() - rec["fetched_at"] > self.cfg.max_age_seconds:
            raise FeedError("version is older than max_age_seconds; refusing to activate stale data")
        prov = {"feed": self.cfg.name, "version": version, "source": rec["source"], "fetched_at": rec["fetched_at"], "sha256": rec["auth"]["sha256"], "auth": rec["auth"]["methods"], "activated_by": actor}
        self.submit(self.cfg.set_name, rec["entries"], source="feed", provenance=prov)
        prev = self._read("active.json")
        self._write("active.json", {"version": version, "previous": prev["version"] if prev else None, "activated_at": self.clock()})
        return {"activated": version, "count": len(rec["entries"]), "previous": prev["version"] if prev else None}

    def rollback(self, actor: str = "operator") -> dict[str, Any]:
        ptr = self._read("active.json")
        if not ptr or not ptr.get("previous"):
            raise FeedError("no previous version to roll back to")
        return self.activate(ptr["previous"], actor=f"{actor}:rollback")

    def expire_if_stale(self) -> Optional[dict[str, Any]]:
        """Empty the set when the active data is older than max_age_seconds."""
        act = self.active()
        if act and self.clock() - act["fetched_at"] > self.cfg.max_age_seconds:
            self.submit(self.cfg.set_name, [], source="feed", provenance={"feed": self.cfg.name, "reason": "expired"})
            os.unlink(self._path("active.json"))
            return {"expired": act["version"]}
        return None
