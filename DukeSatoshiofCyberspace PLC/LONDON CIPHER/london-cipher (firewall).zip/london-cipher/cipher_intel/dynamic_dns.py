"""Controlled hostname-to-address service for DNS-sourced dynamic sets.

For each dynamic set with ``source: dns`` the operator lists hostnames. The
service resolves them through one configured resolver and atomically replaces
the set's members, recording for every update: resolver, resolution time,
TTL, address set, update status and the failure behaviour applied.

Limits of IP-based enforcement (also in docs/dns-and-dynamic-destinations.md):

* IP addresses are shared: CDNs and cloud front-ends serve many unrelated
  names from one address, so allowing ``updates.example.com`` may also allow
  every other service on the same addresses. This is *not* domain-level
  control.
* Clients may resolve differently (other resolvers, encrypted DNS such as DoH
  or DoT, cached answers). Nothing here filters encrypted DNS or inspects
  TLS SNI/ECH; addresses obtained elsewhere may not be in the set.
* Between a DNS change and the next refresh, the set can be stale.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from .dnsclient import DnsError, resolve
from .submit import Submitter


@dataclass
class DnsSetConfig:
    set_name: str
    family: str  # ipv4 | ipv6 (must equal the policy's dynamic set family)
    hostnames: list[str]
    resolver: str
    resolver_port: int = 53
    min_ttl: int = 30
    max_ttl: int = 3600
    #: on failure: keep last good members until max_stale seconds, then
    #: apply ``stale_action``: "keep" (fail open on the old data) or "empty"
    #: (fail closed: the set is emptied, so allow-rules referencing it stop matching)
    max_stale: int = 6 * 3600
    stale_action: str = "empty"

    def __post_init__(self) -> None:
        if self.stale_action not in ("keep", "empty"):
            raise ValueError("stale_action must be keep or empty")
        if not (1 <= self.min_ttl <= self.max_ttl <= 86400):
            raise ValueError("require 1 <= min_ttl <= max_ttl <= 86400")
        if not self.hostnames or len(self.hostnames) > 256:
            raise ValueError("1..256 hostnames per set")


@dataclass
class DnsSetState:
    addresses: list[str] = field(default_factory=list)
    last_success: Optional[float] = None
    next_refresh: float = 0.0
    history: list[dict[str, Any]] = field(default_factory=list)


class DnsSetUpdater:
    def __init__(self, cfg: DnsSetConfig, submit: Submitter, clock: Callable[[], float] = time.time, resolver_fn=resolve):
        self.cfg = cfg
        self.submit = submit
        self.clock = clock
        self.resolve = resolver_fn
        self.state = DnsSetState()

    def _record(self, rec: dict[str, Any]) -> dict[str, Any]:
        self.state.history.append(rec)
        del self.state.history[:-100]
        return rec

    def refresh(self) -> dict[str, Any]:
        now = self.clock()
        addrs: set[str] = set()
        ttls: list[int] = []
        per_host: dict[str, Any] = {}
        errors: dict[str, str] = {}
        for h in self.cfg.hostnames:
            try:
                answers = self.resolve(self.cfg.resolver, h, self.cfg.family, port=self.cfg.resolver_port)
                per_host[h] = [{"address": a.address, "ttl": a.ttl} for a in answers]
                for a in answers:
                    addrs.add(a.address)
                    ttls.append(a.ttl)
            except DnsError as exc:
                errors[h] = str(exc)
        ttl = max(self.cfg.min_ttl, min([self.cfg.max_ttl, *ttls])) if ttls else self.cfg.min_ttl
        base = {"set": self.cfg.set_name, "resolver": f"{self.cfg.resolver}:{self.cfg.resolver_port}", "resolved_at": now, "ttl": ttl, "hosts": per_host}
        if errors:
            # Any failure: do not publish a partial set (it could silently drop
            # destinations). Apply the configured failure behaviour instead.
            age = now - (self.state.last_success or 0)
            if self.state.last_success is not None and age <= self.cfg.max_stale:
                status = "failed-kept-previous"
            elif self.cfg.stale_action == "empty":
                self.submit(self.cfg.set_name, [], source="dns", provenance={"reason": "dns failure beyond max_stale", "errors": errors})
                self.state.addresses = []
                status = "failed-emptied"
            else:
                status = "failed-kept-stale"
            self.state.next_refresh = now + self.cfg.min_ttl
            return self._record(dict(base, status=status, errors=errors, addresses=self.state.addresses))
        new = sorted(addrs, key=lambda a: (":" in a, a))
        prov = {"resolver": base["resolver"], "resolved_at": now, "ttl": ttl, "hostnames": self.cfg.hostnames}
        if new != self.state.addresses or self.state.last_success is None:
            self.submit(self.cfg.set_name, new, source="dns", provenance=prov)
            status = "updated"
        else:
            status = "unchanged"
        self.state.addresses = new
        self.state.last_success = now
        self.state.next_refresh = now + ttl
        return self._record(dict(base, status=status, addresses=new))

    def due(self) -> bool:
        return self.clock() >= self.state.next_refresh
