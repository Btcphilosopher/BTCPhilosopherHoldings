"""Optional intelligence inputs: DNS-derived destinations and threat feeds.

Both can only change membership of dynamic sets that the active policy
declares, via the bounded, audited ``dynamic_set_update`` operation.
"""

from .dynamic_dns import DnsSetConfig, DnsSetUpdater
from .feeds import FeedConfig, FeedError, FeedManager
from .submit import EngineSubmitter, SocketSubmitter

__all__ = ["DnsSetConfig", "DnsSetUpdater", "FeedConfig", "FeedError", "FeedManager", "EngineSubmitter", "SocketSubmitter"]
