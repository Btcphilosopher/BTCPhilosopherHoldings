"""``cipher-intel`` — run DNS-set refreshes and feed staging/activation.

Configuration (YAML, strictly loaded)::

    admin_socket: /run/london-cipher/admin.sock
    store_dir: /var/lib/london-cipher-intel
    dns_sets:
      - {set_name: update_servers, family: ipv4, resolver: 127.0.0.53,
         hostnames: [updates.example.com]}
    feeds:
      - {name: example, set_name: reputation_v4, family: ipv4,
         url: https://feeds.example.net/v4.txt, max_entries: 20000}

The process talks to enforcement only through the admin socket's
``dynamic_set_update`` operation (admin role required).
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from typing import Optional

from cipher_admin.client import AdminClient
from cipher_policy.loader import load_policy_text

from .dynamic_dns import DnsSetConfig, DnsSetUpdater
from .feeds import FeedConfig, FeedManager
from .submit import SocketSubmitter


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="cipher-intel")
    ap.add_argument("--config", required=True)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("dns-refresh")
    p.add_argument("--loop", action="store_true", help="keep refreshing as TTLs expire")
    for name in ("stage", "activate", "rollback"):
        p = sub.add_parser(f"feed-{name}")
        p.add_argument("feed")
        if name == "activate":
            p.add_argument("--version")
    a = ap.parse_args(argv)
    with open(a.config, "rb") as fh:
        cfg = load_policy_text(fh.read())
    submit = SocketSubmitter(AdminClient(cfg.get("admin_socket", "/run/london-cipher/admin.sock")))
    if a.cmd == "dns-refresh":
        updaters = [DnsSetUpdater(DnsSetConfig(**d), submit) for d in cfg.get("dns_sets", [])]
        while True:
            for u in updaters:
                if u.due():
                    print(json.dumps(u.refresh(), default=str), flush=True)
            if not a.loop:
                return 0
            time.sleep(1)
    feeds = {f["name"]: FeedConfig(**f) for f in cfg.get("feeds", [])}
    if a.feed not in feeds:
        print(f"unknown feed {a.feed!r}", file=sys.stderr)
        return 2
    mgr = FeedManager(feeds[a.feed], cfg.get("store_dir", "/var/lib/london-cipher-intel"), submit)
    if a.cmd == "feed-stage":
        out = mgr.stage()
    elif a.cmd == "feed-activate":
        out = mgr.activate(a.version)
    else:
        out = mgr.rollback()
    print(json.dumps(out, indent=1, default=str))
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
