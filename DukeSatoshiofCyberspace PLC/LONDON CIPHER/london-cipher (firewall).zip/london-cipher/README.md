# LONDON CIPHER — Sentinel Firewall

A security-focused, policy-driven **Linux host firewall** written in Python in
the SilicaFlux style: modular packages, typed interfaces, code first, every
behaviour backed by a test. Python manages policy, validation, orchestration,
events and administration. **Packets are filtered by the kernel's nftables**,
never by a Python loop.

> Scope note: this is a carefully engineered host firewall with optional
> gateway features. It makes no claim to be "the best firewall"; see
> [docs/performance.md](docs/performance.md) for what was measured, where,
> and the regressions found.

## What it does

| Capability | Where |
|---|---|
| Versioned declarative policy (YAML/JSON), strict validation, conflict analysis | `cipher_policy/` |
| Deterministic compiler → backend-neutral IR, review listing, semantic diff | `cipher_compiler/`, `cipher_types/ir.py` |
| nftables backend: atomic replace of a dedicated table, dry-run, read-back verification, drift fingerprint, coexistence report | `cipher_backend/nftables.py` |
| Validate → Compile → Review → Apply → Verify → Commit; write-ahead journal; last-known-good; timed rollback; restart recovery | `cipher_state/` |
| Structured events, bounded queues with dropped counters, redaction, hash-chained audit log, kernel-log parser | `cipher_events/` |
| Privilege separation: unprivileged CLI → admin daemon (SO_PEERCRED + roles) → narrow privileged helper | `cipher_cli/`, `cipher_admin/` |
| Optional: DNS-derived destination sets, threat feeds (staged, bounded, reversible) | `cipher_intel/` |
| Optional: Suricata alert ingestion → proposals → bounded, expiring blocks (alert-only by default) | `cipher_detect/` |
| Optional: advisory anomaly research (aggregated features, time-split validation, drift, provenance) | `cipher_research/` |
| Isolated namespace laboratory asserting real packet outcomes | `lab/`, `tests/integration/` |

## First acceptance milestone — status

> *Install a validated policy inside an isolated network namespace,
> demonstrate allowed and denied traffic, update it atomically, recover from a
> failed change and preserve the correct state after restart.*

Implemented and exercised by `tests/integration/test_lab_milestone.py`
against real TCP/UDP/ICMP packets in network namespaces, including a real
helper daemon that is `SIGKILL`ed and restarted. Results of the run that
accompanies this source tree are in `results/test-summary.json`.

**IPv6 caveat for that run:** the kernel of the build environment had IPv6
compiled out (`/proc/net/if_inet6` absent). IPv6 rules were compiled, loaded
into nftables and verified, but the IPv6 *packet* tests were **skipped and
reported as skipped**, not passed. Run `scripts/run-tests.sh` on an
IPv6-capable host to execute them.

## Quick start (development)

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install --require-hashes -r requirements-dev.lock && pip install --no-deps -e .

cipher validate examples/policies/developer-workstation.yaml
cipher compile  examples/policies/developer-workstation.yaml            # review listing
cipher compile  --format nft-json examples/policies/application-server.yaml
cipher diff     old.yaml new.yaml
cipher parity   examples/policies/segmented-lab-gateway.yaml             # IPv4/IPv6 parity

scripts/run-tests.sh            # unit tests; + laboratory tests when run as root
```

## Production install

```bash
sudo scripts/install.sh            # installs software, users, units; enables nothing
sudo systemctl enable --now london-cipher-restore london-cipher-helper london-cipher-admind
sudo usermod -aG cipher-users,cipher-ops alice
cipher apply --confirm-timeout 120 /etc/london-cipher/policy.yaml   # then, from a NEW session:
cipher confirm
```

Removal: `sudo scripts/uninstall.sh` (keeps the active ruleset unless
`--remove-ruleset`; keeps configuration/state unless `--purge`).

## Repository layout

```
cipher_types/      shared enums, errors, IR            cipher_events/   events, audit, redaction
cipher_policy/     loader, validator, model, analysis  cipher_admin/    admin daemon, helper, authz
cipher_compiler/   compiler, review listing, diff      cipher_cli/      `cipher` command
cipher_backend/    backend interface, nftables, memory cipher_intel/    DNS sets, threat feeds
cipher_state/      store, journal, deployment engine   cipher_detect/   detection responses
cipher_research/   advisory anomaly analysis           lab/             namespace laboratory
tests/unit, tests/integration, tests/fixtures          bench/           benchmarks
packaging/         systemd, sysusers, tmpfiles, etc    scripts/         install, uninstall, tests
examples/policies/ workstation, app server, gateway    docs/            design and operations
results/           machine-readable test and benchmark results of the accompanying run
```

## Documentation

* [Architecture](docs/architecture.md)
* [Policy language](docs/policy-language.md)
* [Deployment safety and rollback](docs/deployment-safety.md)
* [Stateful semantics](docs/stateful-semantics.md)
* [IPv6 and essential services](docs/ipv6-and-essential-services.md)
* [Privilege separation](docs/privilege-separation.md)
* [Events, auditing and privacy](docs/events-and-audit.md)
* [Limits and DoS resilience](docs/limits-and-dos.md)
* [DNS and dynamic destinations](docs/dns-and-dynamic-destinations.md)
* [Threat intelligence and detection](docs/threat-intel-and-detection.md)
* [Research module (ML)](docs/research-ml.md)
* [Laboratory and testing](docs/laboratory.md)
* [Performance](docs/performance.md)
* [nftables backend](docs/backends/nftables.md)

## What it does not do

* It does not inspect payloads, and filtering encrypted connections does not
  mean their contents are inspected.
* It does not identify applications. Port numbers are not application identity,
  and process-aware rules need a separate mechanism that is not implemented.
* It does not provide domain-level control from DNS sets. It cannot filter
  encrypted DNS or encrypted client metadata (ECH).
* It does not detect malware, intrusions or zero-days. Detection belongs to the
  upstream detector; this firewall can only act on approved, bounded proposals.
* A host firewall cannot protect a saturated uplink.
* It does not terminate existing connections when a deny rule is added, unless
  you run the audited `cipher conntrack-delete`.
