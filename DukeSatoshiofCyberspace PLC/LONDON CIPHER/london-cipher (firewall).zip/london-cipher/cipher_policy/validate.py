"""Strict policy validation: plain data -> :class:`cipher_policy.model.Policy`.

The validator is the only gate between configuration and enforcement. It
collects *all* findings (rather than stopping at the first) so an operator
sees every problem at once, and raises :class:`cipher_types.PolicyError` if any
finding is an error. Nothing is sent to a backend unless this succeeds.

Rejected classes of input include: unknown keys (typos must not silently
disable intent), host bits set in networks, malformed ports, ICMP types used
with the wrong family, ports without a protocol, ambiguous combinations
(``services`` together with ``protocol``), dangling references, duplicate
identifiers, rules that can never match, IPv4/IPv6 divergence that has not
been declared explicitly, and rules made unreachable by an earlier rule with a
different action.
"""

from __future__ import annotations

import ipaddress
from datetime import datetime, timezone
from typing import Any, Callable, Iterable, Optional

from cipher_types import (
    IFACE_RE,
    NAME_RE,
    RULE_ID_RE,
    SCHEMA_VERSION,
    Action,
    CtState,
    DefaultAction,
    Family,
    Hook,
    Issue,
    PolicyError,
    Protocol,
    Severity,
)
from cipher_types.ir import PortRange

from .loader import load_policy_text
from .model import (
    AddressSet,
    AdminAccess,
    Defaults,
    DynamicSet,
    Endpoint,
    Essential,
    Logging,
    Masquerade,
    Nat,
    Network,
    Policy,
    PolicyMeta,
    PortForward,
    Rule,
    Service,
    ServiceSet,
    StateHandling,
    Zone,
    net_family,
)

# Bounded sizes (DoS resilience: policy size is bounded, see docs/limits.md).
MAX_RULES = 4096
MAX_NETWORKS_TOTAL = 200_000
MAX_LIST = 10_000
MAX_DYNAMIC_ELEMENTS = 262_144
MAX_TEXT = 500

ICMP_TYPES = frozenset(
    {
        "echo-reply",
        "destination-unreachable",
        "source-quench",
        "redirect",
        "echo-request",
        "router-advertisement",
        "router-solicitation",
        "time-exceeded",
        "parameter-problem",
        "timestamp-request",
        "timestamp-reply",
        "info-request",
        "info-reply",
        "address-mask-request",
        "address-mask-reply",
    }
)

ICMPV6_TYPES = frozenset(
    {
        "destination-unreachable",
        "packet-too-big",
        "time-exceeded",
        "parameter-problem",
        "echo-request",
        "echo-reply",
        "mld-listener-query",
        "mld-listener-report",
        "mld-listener-done",
        "mld2-listener-report",
        "nd-router-solicit",
        "nd-router-advert",
        "nd-neighbor-solicit",
        "nd-neighbor-advert",
        "nd-redirect",
        "router-renumbering",
    }
)

LOG_LEVELS = frozenset({"emerg", "alert", "crit", "err", "warn", "notice", "info", "debug"})


class _V:
    """Issue collector plus typed field readers."""

    def __init__(self) -> None:
        self.issues: list[Issue] = []
        self.network_count = 0

    # -- reporting -------------------------------------------------------
    def error(self, path: str, code: str, msg: str) -> None:
        self.issues.append(Issue(Severity.ERROR, code, path, msg))

    def warn(self, path: str, code: str, msg: str) -> None:
        self.issues.append(Issue(Severity.WARNING, code, path, msg))

    @property
    def failed(self) -> bool:
        return any(i.severity is Severity.ERROR for i in self.issues)

    # -- structure -------------------------------------------------------
    def mapping(self, value: Any, path: str) -> Optional[dict]:
        if value is None:
            return None
        if not isinstance(value, dict):
            self.error(path, "type.mapping", f"expected a mapping, got {type(value).__name__}")
            return None
        for k in value:
            if not isinstance(k, str):
                self.error(path, "type.key", f"mapping keys must be strings, got {k!r}")
        return value

    def keys(self, d: dict, path: str, allowed: Iterable[str], required: Iterable[str] = ()) -> None:
        allowed = set(allowed) | set(required)
        for k in d:
            if isinstance(k, str) and k not in allowed:
                self.error(f"{path}/{k}", "key.unknown", f"unknown key {k!r} (allowed: {', '.join(sorted(allowed))})")
        for k in required:
            if k not in d:
                self.error(f"{path}/{k}", "key.missing", f"required key {k!r} is missing")

    def list_(self, value: Any, path: str, max_len: int = MAX_LIST) -> list:
        if value is None:
            return []
        if not isinstance(value, list):
            self.error(path, "type.list", f"expected a list, got {type(value).__name__}")
            return []
        if len(value) > max_len:
            self.error(path, "limit.list", f"list has {len(value)} items; limit is {max_len}")
            return []
        return value

    def string(
        self,
        value: Any,
        path: str,
        *,
        regex=None,
        max_len: int = MAX_TEXT,
        min_len: int = 0,
        what: str = "value",
    ) -> Optional[str]:
        if not isinstance(value, str):
            self.error(path, "type.string", f"expected a string {what}, got {type(value).__name__}")
            return None
        if len(value) > max_len:
            self.error(path, "limit.string", f"{what} longer than {max_len} characters")
            return None
        if len(value.strip()) < min_len:
            self.error(path, "value.empty", f"{what} must have at least {min_len} non-space characters")
            return None
        if any(ord(c) < 32 for c in value):
            self.error(path, "value.control", f"{what} contains control characters")
            return None
        if regex is not None and not regex.match(value):
            self.error(path, "value.format", f"invalid {what} {value!r} (must match {regex.pattern})")
            return None
        return value

    def integer(self, value: Any, path: str, lo: int, hi: int) -> Optional[int]:
        if isinstance(value, bool) or not isinstance(value, int):
            self.error(path, "type.integer", f"expected an integer, got {value!r}")
            return None
        if not lo <= value <= hi:
            self.error(path, "value.range", f"{value} is outside {lo}..{hi}")
            return None
        return value

    def boolean(self, value: Any, path: str) -> Optional[bool]:
        if not isinstance(value, bool):
            self.error(path, "type.boolean", f"expected true or false, got {value!r}")
            return None
        return value

    def choice(self, value: Any, path: str, choices: Iterable[str]) -> Optional[str]:
        choices = list(choices)
        if not isinstance(value, str) or value not in choices:
            self.error(path, "value.choice", f"expected one of {', '.join(choices)}, got {value!r}")
            return None
        return value

    # -- network values --------------------------------------------------
    def network(self, value: Any, path: str) -> Optional[Network]:
        if not isinstance(value, str):
            self.error(path, "type.network", f"expected a network string, got {value!r}")
            return None
        try:
            net = ipaddress.ip_network(value, strict=True)
        except ValueError as exc:
            self.error(path, "value.network", f"invalid network {value!r}: {exc}")
            return None
        self.network_count += 1
        if self.network_count > MAX_NETWORKS_TOTAL:
            if self.network_count == MAX_NETWORKS_TOTAL + 1:
                self.error(path, "limit.networks", f"more than {MAX_NETWORKS_TOTAL} networks in policy")
            return None
        if net.prefixlen == 0:
            self.warn(path, "value.any_network", f"{net} matches every address of its family; omit the field to mean 'any'")
        return net

    def networks(self, value: Any, path: str) -> tuple[Network, ...]:
        out = []
        for i, item in enumerate(self.list_(value, path)):
            n = self.network(item, f"{path}/{i}")
            if n is not None:
                out.append(n)
        return tuple(out)

    def address(self, value: Any, path: str):
        if not isinstance(value, str):
            self.error(path, "type.address", f"expected an IP address string, got {value!r}")
            return None
        try:
            return ipaddress.ip_address(value)
        except ValueError as exc:
            self.error(path, "value.address", f"invalid IP address {value!r}: {exc}")
            return None

    def port(self, value: Any, path: str) -> Optional[int]:
        return self.integer(value, path, 1, 65535)

    def ports(self, value: Any, path: str) -> tuple[PortRange, ...]:
        if isinstance(value, (int, str)) and not isinstance(value, bool):
            value = [value]
        out: list[PortRange] = []
        for i, item in enumerate(self.list_(value, path)):
            p = f"{path}/{i}"
            if isinstance(item, bool):
                self.error(p, "value.port", f"invalid port {item!r}")
            elif isinstance(item, int):
                if self.port(item, p) is not None:
                    out.append(PortRange(item, item))
            elif isinstance(item, str) and item.count("-") == 1:
                lo_s, hi_s = item.split("-")
                if not (lo_s.isdigit() and hi_s.isdigit()):
                    self.error(p, "value.port", f"invalid port range {item!r}")
                    continue
                lo, hi = int(lo_s), int(hi_s)
                if not (1 <= lo <= hi <= 65535):
                    self.error(p, "value.port", f"invalid port range {item!r} (need 1 <= low <= high <= 65535)")
                    continue
                out.append(PortRange(lo, hi))
            elif isinstance(item, str) and item.isdigit():
                if self.port(int(item), p) is not None:
                    out.append(PortRange(int(item), int(item)))
            else:
                self.error(p, "value.port", f"invalid port {item!r} (use an integer or 'low-high')")
        return tuple(sorted(set(out)))

    def ifaces(self, value: Any, path: str) -> tuple[str, ...]:
        if isinstance(value, str):
            value = [value]
        out = []
        for i, item in enumerate(self.list_(value, path)):
            s = self.string(item, f"{path}/{i}", regex=IFACE_RE, what="interface name")
            if s is not None:
                out.append(s)
        return tuple(dict.fromkeys(out))

    def names(self, value: Any, path: str, what: str) -> tuple[str, ...]:
        if isinstance(value, str):
            value = [value]
        out = []
        for i, item in enumerate(self.list_(value, path)):
            s = self.string(item, f"{path}/{i}", regex=NAME_RE, what=what)
            if s is not None:
                out.append(s)
        return tuple(dict.fromkeys(out))

    def timestamp(self, value: Any, path: str) -> Optional[datetime]:
        if not isinstance(value, str):
            self.error(path, "type.timestamp", "expiry must be an ISO 8601 string with a timezone, e.g. 2026-12-31T23:59:00Z")
            return None
        try:
            ts = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            self.error(path, "value.timestamp", f"invalid ISO 8601 timestamp {value!r}")
            return None
        if ts.tzinfo is None:
            self.error(path, "value.timestamp_tz", "expiry must include a timezone (e.g. 'Z' or '+00:00')")
            return None
        return ts.astimezone(timezone.utc)


# ---------------------------------------------------------------------------
# Section parsers
# ---------------------------------------------------------------------------


def _parse_meta(v: _V, d: Any) -> Optional[PolicyMeta]:
    m = v.mapping(d, "/policy")
    if m is None:
        v.error("/policy", "key.missing", "the 'policy' section (id, revision) is required")
        return None
    v.keys(m, "/policy", ["description"], ["id", "revision"])
    pid = v.string(m.get("id"), "/policy/id", regex=RULE_ID_RE, what="policy id") if "id" in m else None
    rev = v.integer(m.get("revision"), "/policy/revision", 1, 2**53) if "revision" in m else None
    desc = v.string(m.get("description", ""), "/policy/description", max_len=2000) or ""
    if pid is None or rev is None:
        return None
    return PolicyMeta(pid, rev, desc)


def _parse_defaults(v: _V, d: Any) -> Optional[Defaults]:
    m = v.mapping(d, "/defaults")
    if m is None:
        v.error("/defaults", "key.missing", "explicit default policies (input, output, forward) are required")
        return None
    v.keys(m, "/defaults", [], ["input", "output", "forward"])
    vals = {}
    for k in ("input", "output", "forward"):
        if k in m:
            c = v.choice(m[k], f"/defaults/{k}", [a.value for a in DefaultAction])
            vals[k] = DefaultAction(c) if c else None
    if len(vals) != 3 or None in vals.values():
        return None
    return Defaults(**vals)


def _parse_zones(v: _V, d: Any, interfaces: dict[str, str]) -> dict[str, Zone]:
    m = v.mapping(d, "/zones") or {}
    zones: dict[str, Zone] = {}
    for name, body in m.items():
        p = f"/zones/{name}"
        if v.string(name, p, regex=NAME_RE, what="zone name") is None:
            continue
        b = v.mapping(body if body is not None else {}, p) or {}
        v.keys(b, p, ["networks", "description"])
        nets = v.networks(b.get("networks"), f"{p}/networks")
        desc = v.string(b.get("description", ""), f"{p}/description") or ""
        ifaces = tuple(sorted(i for i, z in interfaces.items() if z == name))
        zones[name] = Zone(name, ifaces, nets, desc)
    for iface, zone in interfaces.items():
        if zone not in zones:
            v.error(f"/interfaces/{iface}/zone", "ref.zone", f"interface {iface!r} refers to undefined zone {zone!r}")
    return zones


def _parse_interfaces(v: _V, d: Any) -> dict[str, str]:
    m = v.mapping(d, "/interfaces") or {}
    out: dict[str, str] = {}
    for name, body in m.items():
        p = f"/interfaces/{name}"
        if v.string(name, p, regex=IFACE_RE, what="interface name") is None:
            continue
        b = v.mapping(body, p)
        if b is None:
            v.error(p, "key.missing", "interface needs a 'zone'")
            continue
        v.keys(b, p, ["description"], ["zone"])
        z = v.string(b.get("zone"), f"{p}/zone", regex=NAME_RE, what="zone name") if "zone" in b else None
        if z is not None:
            out[name] = z
    return out


def _parse_address_sets(v: _V, d: Any) -> dict[str, AddressSet]:
    m = v.mapping(d, "/address_sets") or {}
    out = {}
    for name, body in m.items():
        p = f"/address_sets/{name}"
        if v.string(name, p, regex=NAME_RE, what="address set name") is None:
            continue
        b = v.mapping(body, p) or {}
        v.keys(b, p, ["description"], ["addresses"])
        nets = v.networks(b.get("addresses"), f"{p}/addresses")
        if b.get("addresses") == []:
            v.error(f"{p}/addresses", "value.empty", "address set must contain at least one network")
        out[name] = AddressSet(name, nets, v.string(b.get("description", ""), f"{p}/description") or "")
    return out


def _parse_service(v: _V, d: Any, p: str) -> Optional[Service]:
    b = v.mapping(d, p)
    if b is None:
        return None
    v.keys(b, p, ["ports", "icmp_types"], ["protocol"])
    proto_s = v.choice(b.get("protocol"), f"{p}/protocol", [x.value for x in Protocol]) if "protocol" in b else None
    if proto_s is None:
        return None
    proto = Protocol(proto_s)
    ports = v.ports(b.get("ports"), f"{p}/ports") if "ports" in b else ()
    icmp = _parse_icmp_types(v, b.get("icmp_types"), f"{p}/icmp_types", proto) if "icmp_types" in b else ()
    if proto.has_ports and "icmp_types" in b:
        v.error(f"{p}/icmp_types", "combo.icmp_types", f"icmp_types cannot be used with protocol {proto.value}")
    if not proto.has_ports and "ports" in b:
        v.error(f"{p}/ports", "combo.ports", f"ports cannot be used with protocol {proto.value}")
    return Service(proto, ports, icmp)


def _parse_icmp_types(v: _V, value: Any, path: str, proto: Optional[Protocol]) -> tuple[str, ...]:
    if isinstance(value, str):
        value = [value]
    allowed = ICMP_TYPES if proto is Protocol.ICMP else ICMPV6_TYPES if proto is Protocol.ICMPV6 else None
    out = []
    for i, t in enumerate(v.list_(value, path)):
        if not isinstance(t, str):
            v.error(f"{path}/{i}", "type.string", f"expected an ICMP type name, got {t!r}")
            continue
        if allowed is None:
            v.error(f"{path}/{i}", "combo.icmp_types", "icmp_types requires protocol icmp or icmpv6")
            continue
        if t not in allowed:
            v.error(f"{path}/{i}", "value.icmp_type", f"unknown {proto.value} type {t!r}")
            continue
        out.append(t)
    return tuple(sorted(set(out)))


def _parse_service_sets(v: _V, d: Any) -> dict[str, ServiceSet]:
    m = v.mapping(d, "/service_sets") or {}
    out = {}
    for name, body in m.items():
        p = f"/service_sets/{name}"
        if v.string(name, p, regex=NAME_RE, what="service set name") is None:
            continue
        b = v.mapping(body, p) or {}
        v.keys(b, p, ["description"], ["services"])
        svcs = []
        for i, s in enumerate(v.list_(b.get("services"), f"{p}/services")):
            svc = _parse_service(v, s, f"{p}/services/{i}")
            if svc is not None:
                if svc.protocol.has_ports and not svc.ports:
                    v.error(f"{p}/services/{i}/ports", "value.empty", "tcp/udp services must list ports")
                svcs.append(svc)
        if not svcs and "services" in b:
            v.error(f"{p}/services", "value.empty", "service set must contain at least one service")
        out[name] = ServiceSet(name, tuple(svcs), v.string(b.get("description", ""), f"{p}/description") or "")
    return out


def _parse_dynamic_sets(v: _V, d: Any) -> dict[str, DynamicSet]:
    m = v.mapping(d, "/dynamic_sets") or {}
    out = {}
    for name, body in m.items():
        p = f"/dynamic_sets/{name}"
        if v.string(name, p, regex=NAME_RE, what="dynamic set name") is None:
            continue
        b = v.mapping(body, p) or {}
        v.keys(b, p, ["description", "timeout_seconds"], ["family", "source", "max_elements"])
        fam = v.choice(b.get("family"), f"{p}/family", ["ipv4", "ipv6"]) if "family" in b else None
        src = v.choice(b.get("source"), f"{p}/source", ["dns", "feed", "detection"]) if "source" in b else None
        mx = v.integer(b.get("max_elements"), f"{p}/max_elements", 1, MAX_DYNAMIC_ELEMENTS) if "max_elements" in b else None
        timeout = None
        if "timeout_seconds" in b:
            timeout = v.integer(b["timeout_seconds"], f"{p}/timeout_seconds", 1, 30 * 86400)
        if src == "detection" and "timeout_seconds" not in b:
            v.error(f"{p}/timeout_seconds", "key.missing", "detection-sourced sets must declare timeout_seconds (blocks must expire)")
        if src != "detection" and "timeout_seconds" in b:
            v.error(f"{p}/timeout_seconds", "combo.timeout", "timeout_seconds is only supported for detection-sourced sets")
        if fam and src and mx:
            out[name] = DynamicSet(name, Family(fam), src, mx, timeout, v.string(b.get("description", ""), f"{p}/description") or "")
    return out


def _parse_endpoint(v: _V, d: Any, p: str) -> Endpoint:
    b = v.mapping(d, p)
    if b is None:
        return Endpoint()
    v.keys(b, p, ["zone", "addresses", "sets"])
    zone = v.string(b["zone"], f"{p}/zone", regex=NAME_RE, what="zone name") if "zone" in b else None
    nets = v.networks(b.get("addresses"), f"{p}/addresses")
    sets = v.names(b.get("sets"), f"{p}/sets", "set name")
    if "addresses" in b and b["addresses"] == []:
        v.error(f"{p}/addresses", "value.empty", "addresses must not be empty (omit the key to mean 'any')")
    return Endpoint(zone, nets, sets)


def _parse_state(v: _V, d: Any) -> StateHandling:
    b = v.mapping(d, "/state")
    if b is None:
        return StateHandling()
    v.keys(b, "/state", ["established_related", "invalid"])
    er = v.choice(b.get("established_related", "accept"), "/state/established_related", ["accept", "evaluate"]) or "accept"
    inv = v.choice(b.get("invalid", "drop"), "/state/invalid", ["drop", "evaluate"]) or "drop"
    return StateHandling(er, inv)  # type: ignore[arg-type]


_ESSENTIAL_BOOLS = (
    "loopback_antispoof",
    "icmpv6_neighbor_discovery",
    "icmpv6_errors",
    "icmpv4_errors",
    "slaac",
    "dhcpv4_client",
    "dhcpv6_client",
)


def _parse_essential(v: _V, d: Any) -> Essential:
    b = v.mapping(d, "/essential")
    if b is None:
        return Essential()
    v.keys(b, "/essential", list(_ESSENTIAL_BOOLS) + ["loopback", "dns_servers", "ntp_servers", "admin_access"])
    kw: dict[str, Any] = {}
    if "loopback" in b:
        kw["loopback"] = v.choice(b["loopback"], "/essential/loopback", ["accept", "evaluate"]) or "accept"
    for k in _ESSENTIAL_BOOLS:
        if k in b:
            val = v.boolean(b[k], f"/essential/{k}")
            if val is not None:
                kw[k] = val
    for k in ("dns_servers", "ntp_servers"):
        addrs = []
        for i, a in enumerate(v.list_(b.get(k), f"/essential/{k}", 64)):
            ip = v.address(a, f"/essential/{k}/{i}")
            if ip is not None:
                addrs.append(ip)
        kw[k] = tuple(dict.fromkeys(addrs))
    if "admin_access" in b:
        p = "/essential/admin_access"
        a = v.mapping(b["admin_access"], p) or {}
        v.keys(a, p, ["protocol"], ["ports", "source", "justification"])
        ports = v.ports(a.get("ports"), f"{p}/ports")
        if not ports:
            v.error(f"{p}/ports", "value.empty", "admin_access requires at least one port")
        proto = Protocol(v.choice(a.get("protocol", "tcp"), f"{p}/protocol", ["tcp", "udp"]) or "tcp")
        src = _parse_endpoint(v, a.get("source"), f"{p}/source")
        if src.is_any:
            v.error(f"{p}/source", "value.admin_any", "admin_access must be restricted to a zone, address list or set")
        j = v.string(a.get("justification"), f"{p}/justification", min_len=3, what="justification")
        kw["admin_access"] = AdminAccess(ports, src, j or "", proto)
    return Essential(**kw)


def _parse_logging(v: _V, d: Any) -> Logging:
    b = v.mapping(d, "/logging")
    if b is None:
        return Logging()
    v.keys(b, "/logging", ["rate", "per", "burst", "level", "log_default_drop"])
    kw: dict[str, Any] = {}
    if "rate" in b:
        kw["rate"] = v.integer(b["rate"], "/logging/rate", 1, 10_000) or 5
    if "burst" in b:
        kw["burst"] = v.integer(b["burst"], "/logging/burst", 1, 100_000) or 10
    if "per" in b:
        kw["per"] = v.choice(b["per"], "/logging/per", ["second", "minute", "hour"]) or "second"
    if "level" in b:
        kw["level"] = v.choice(b["level"], "/logging/level", sorted(LOG_LEVELS)) or "info"
    if "log_default_drop" in b:
        val = v.boolean(b["log_default_drop"], "/logging/log_default_drop")
        kw["log_default_drop"] = True if val is None else val
    return Logging(**kw)


_RULE_KEYS = [
    "family",
    "source",
    "destination",
    "in_interface",
    "out_interface",
    "protocol",
    "ports",
    "source_ports",
    "services",
    "icmp_types",
    "ct_state",
    "log",
    "expires",
    "enabled",
]


def _parse_rule(v: _V, d: Any, p: str) -> Optional[Rule]:
    b = v.mapping(d, p)
    if b is None:
        return None
    v.keys(b, p, _RULE_KEYS, ["id", "chain", "action", "justification"])
    rid = v.string(b.get("id"), f"{p}/id", regex=RULE_ID_RE, what="rule id") if "id" in b else None
    chain_s = v.choice(b.get("chain"), f"{p}/chain", [h.value for h in Hook]) if "chain" in b else None
    action_s = v.choice(b.get("action"), f"{p}/action", [a.value for a in Action]) if "action" in b else None
    just = v.string(b.get("justification"), f"{p}/justification", min_len=3, what="justification") if "justification" in b else None
    fam_s = v.choice(b.get("family", "any"), f"{p}/family", [f.value for f in Family]) or "any"
    proto = None
    if "protocol" in b:
        ps = v.choice(b["protocol"], f"{p}/protocol", [x.value for x in Protocol])
        proto = Protocol(ps) if ps else None
    ports = v.ports(b.get("ports"), f"{p}/ports") if "ports" in b else ()
    sports = v.ports(b.get("source_ports"), f"{p}/source_ports") if "source_ports" in b else ()
    services = v.names(b.get("services"), f"{p}/services", "service set name") if "services" in b else ()
    icmp = _parse_icmp_types(v, b.get("icmp_types"), f"{p}/icmp_types", proto) if "icmp_types" in b else ()
    ct: tuple[str, ...] = ()
    if "ct_state" in b:
        raw = b["ct_state"]
        if isinstance(raw, str):
            raw = [raw]
        vals = []
        for i, s in enumerate(v.list_(raw, f"{p}/ct_state", 5)):
            c = v.choice(s, f"{p}/ct_state/{i}", [x.value for x in CtState])
            if c:
                vals.append(c)
        ct = tuple(sorted(set(vals)))
        if not ct:
            v.error(f"{p}/ct_state", "value.empty", "ct_state must not be empty")
    log = v.boolean(b.get("log", False), f"{p}/log") or False
    enabled = v.boolean(b.get("enabled", True), f"{p}/enabled")
    expires = v.timestamp(b["expires"], f"{p}/expires") if "expires" in b else None
    src = _parse_endpoint(v, b.get("source"), f"{p}/source")
    dst = _parse_endpoint(v, b.get("destination"), f"{p}/destination")
    iif = v.ifaces(b.get("in_interface"), f"{p}/in_interface") if "in_interface" in b else ()
    oif = v.ifaces(b.get("out_interface"), f"{p}/out_interface") if "out_interface" in b else ()

    # --- combination rules -------------------------------------------
    if services and (proto is not None or ports or icmp):
        v.error(p, "combo.services", "'services' cannot be combined with protocol/ports/icmp_types (ambiguous)")
    if (ports or sports) and proto is None and not services:
        v.error(p, "combo.ports_without_protocol", "ports require 'protocol: tcp' or 'protocol: udp'")
    if (ports or sports) and proto is not None and not proto.has_ports:
        v.error(p, "combo.ports", f"ports cannot be used with protocol {proto.value}")
    if icmp and proto is None:
        v.error(f"{p}/icmp_types", "combo.icmp_types", "icmp_types requires protocol icmp or icmpv6")
    if action_s == "accept" and "invalid" in ct:
        v.error(f"{p}/ct_state", "combo.accept_invalid", "accepting ct_state invalid is not supported")
    if chain_s == "input" and (oif or dst.zone):
        v.error(p, "combo.chain", "input rules cannot match out_interface or destination.zone")
    if chain_s == "output" and (iif or src.zone):
        v.error(p, "combo.chain", "output rules cannot match in_interface or source.zone")

    if None in (rid, chain_s, action_s, just) or enabled is None:
        return None
    return Rule(
        id=rid,  # type: ignore[arg-type]
        chain=Hook(chain_s),
        action=Action(action_s),
        justification=just,  # type: ignore[arg-type]
        family=Family(fam_s),
        source=src,
        destination=dst,
        in_interfaces=iif,
        out_interfaces=oif,
        protocol=proto,
        ports=ports,
        source_ports=sports,
        services=services,
        icmp_types=icmp,
        ct_states=ct,
        log=log,
        expires=expires,
        enabled=enabled,
    )


def _parse_nat(v: _V, d: Any) -> Nat:
    b = v.mapping(d, "/nat")
    if b is None:
        return Nat()
    v.keys(b, "/nat", ["masquerade", "port_forwards"])
    masq = []
    for i, m in enumerate(v.list_(b.get("masquerade"), "/nat/masquerade", 256)):
        p = f"/nat/masquerade/{i}"
        mb = v.mapping(m, p) or {}
        v.keys(mb, p, ["family", "source"], ["id", "out_interface", "justification"])
        mid = v.string(mb.get("id"), f"{p}/id", regex=RULE_ID_RE, what="nat id") if "id" in mb else None
        oif = v.ifaces(mb.get("out_interface"), f"{p}/out_interface")
        if not oif:
            v.error(f"{p}/out_interface", "value.empty", "masquerade requires out_interface")
        fam = v.choice(mb.get("family", "ipv4"), f"{p}/family", ["ipv4", "ipv6", "any"]) or "ipv4"
        src = _parse_endpoint(v, mb.get("source"), f"{p}/source")
        j = v.string(mb.get("justification"), f"{p}/justification", min_len=3, what="justification") if "justification" in mb else None
        if mid and j and oif:
            masq.append(Masquerade(mid, oif, Family(fam), src, j))
    fwds = []
    for i, f in enumerate(v.list_(b.get("port_forwards"), "/nat/port_forwards", 1024)):
        p = f"/nat/port_forwards/{i}"
        fb = v.mapping(f, p) or {}
        v.keys(fb, p, ["destination"], ["id", "in_interface", "protocol", "port", "to_address", "to_port", "justification"])
        fid = v.string(fb.get("id"), f"{p}/id", regex=RULE_ID_RE, what="nat id") if "id" in fb else None
        iif = v.ifaces(fb.get("in_interface"), f"{p}/in_interface")
        if not iif:
            v.error(f"{p}/in_interface", "value.empty", "port forward requires in_interface")
        proto = v.choice(fb.get("protocol"), f"{p}/protocol", ["tcp", "udp"]) if "protocol" in fb else None
        port = v.port(fb.get("port"), f"{p}/port") if "port" in fb else None
        to_port = v.port(fb.get("to_port"), f"{p}/to_port") if "to_port" in fb else None
        to_addr = v.address(fb.get("to_address"), f"{p}/to_address") if "to_address" in fb else None
        dst = _parse_endpoint(v, fb.get("destination"), f"{p}/destination")
        j = v.string(fb.get("justification"), f"{p}/justification", min_len=3, what="justification") if "justification" in fb else None
        if None not in (fid, proto, port, to_port, to_addr, j) and iif:
            fwds.append(PortForward(fid, iif, Protocol(proto), port, to_addr, to_port, j, dst))  # type: ignore[arg-type]
    return Nat(tuple(masq), tuple(fwds))


# ---------------------------------------------------------------------------
# Semantic checks
# ---------------------------------------------------------------------------


def endpoint_families(ep: Endpoint, policy_sets: dict, dyn_sets: dict, zones: dict) -> Optional[set[Family]]:
    """Address families an endpoint constrains to, or ``None`` if unconstrained."""
    fams: set[Family] = set()
    constrained = False
    for n in ep.networks:
        constrained = True
        fams.add(net_family(n))
    for s in ep.sets:
        constrained = True
        if s in policy_sets:
            fams.update(net_family(n) for n in policy_sets[s].networks)
        elif s in dyn_sets:
            fams.add(dyn_sets[s].family)
    if ep.zone and ep.zone in zones and zones[ep.zone].networks:
        constrained = True
        zfams = {net_family(n) for n in zones[ep.zone].networks}
        fams = fams & zfams if (ep.networks or ep.sets) else zfams
    return fams if constrained else None


def _check_refs_and_families(v: _V, pol_parts: dict) -> None:
    zones = pol_parts["zones"]
    asets = pol_parts["address_sets"]
    ssets = pol_parts["service_sets"]
    dsets = pol_parts["dynamic_sets"]

    for name in set(asets) & set(dsets):
        v.error(f"/dynamic_sets/{name}", "dup.set", f"set name {name!r} is used by both address_sets and dynamic_sets")

    def check_ep(ep: Endpoint, p: str) -> None:
        if ep.zone is not None:
            if ep.zone not in zones:
                v.error(f"{p}/zone", "ref.zone", f"undefined zone {ep.zone!r}")
            elif not zones[ep.zone].interfaces and not zones[ep.zone].networks:
                v.error(f"{p}/zone", "ref.zone_empty", f"zone {ep.zone!r} has no interfaces or networks; it would match nothing")
        for s in ep.sets:
            if s not in asets and s not in dsets:
                v.error(f"{p}/sets", "ref.set", f"undefined address or dynamic set {s!r}")

    seen_ids: dict[str, str] = {}

    def check_id(rid: str, p: str) -> None:
        if rid in seen_ids:
            v.error(f"{p}/id", "dup.id", f"duplicate identifier {rid!r} (first used at {seen_ids[rid]})")
        else:
            seen_ids[rid] = p

    for i, r in enumerate(pol_parts["rules"]):
        p = f"/rules/{i}"
        check_id(r.id, p)
        check_ep(r.source, f"{p}/source")
        check_ep(r.destination, f"{p}/destination")
        for s in r.services:
            if s not in ssets:
                v.error(f"{p}/services", "ref.service", f"undefined service set {s!r}")
        # --- family resolution -------------------------------------------
        effective = set(r.family.expand())
        for ep in (r.source, r.destination):
            # Inline addresses of the other family contradict an explicit family.
            # Named sets and zones may be dual-stack: an explicit family selects
            # the matching members (and family.empty catches "none match").
            inline = {net_family(n) for n in ep.networks}
            if r.family is not Family.ANY and inline - {r.family}:
                v.error(p, "family.mixed", f"rule family is {r.family.value} but inline addresses include {sorted(x.value for x in inline - {r.family})}")
            f = endpoint_families(ep, asets, dsets, zones)
            if f is not None:
                effective &= f
        proto_fams: set[Family] = set()
        protos = [r.protocol] if r.protocol else [svc.protocol for s in r.services if s in ssets for svc in ssets[s].services]
        if protos and all(pp in (Protocol.ICMP, Protocol.ICMPV6) for pp in protos):
            proto_fams = {Family.IPV4 if pp is Protocol.ICMP else Family.IPV6 for pp in protos}
            effective &= proto_fams
        if not effective:
            v.error(p, "family.empty", "rule can never match: its address and protocol constraints select no address family")
        elif r.family is Family.ANY and len(effective) == 1:
            only = next(iter(effective)).value
            v.error(
                p,
                "family.divergence",
                f"rule declares family 'any' but can only match {only}; declare 'family: {only}' explicitly so IPv4/IPv6 divergence is intentional",
            )
        elif r.protocol is Protocol.ICMP and r.family is Family.IPV6:
            v.error(p, "family.protocol", "protocol icmp is IPv4-only; use icmpv6 for IPv6")
        elif r.protocol is Protocol.ICMPV6 and r.family is Family.IPV4:
            v.error(p, "family.protocol", "protocol icmpv6 is IPv6-only; use icmp for IPv4")

    for i, m in enumerate(pol_parts["nat"].masquerade):
        check_id(m.id, f"/nat/masquerade/{i}")
        check_ep(m.source, f"/nat/masquerade/{i}/source")
    for i, f in enumerate(pol_parts["nat"].port_forwards):
        check_id(f.id, f"/nat/port_forwards/{i}")
        check_ep(f.destination, f"/nat/port_forwards/{i}/destination")
    adm = pol_parts["essential"].admin_access
    if adm is not None:
        check_ep(adm.source, "/essential/admin_access/source")


def build_policy(data: dict, *, now: Optional[datetime] = None, strict_conflicts: bool = True) -> tuple[Policy, list[Issue]]:
    """Validate plain data and build a :class:`Policy`.

    Returns ``(policy, warnings)``; raises :class:`PolicyError` on any error.
    """
    from .analysis import analyse_conflicts

    v = _V()
    if not isinstance(data, dict):
        raise PolicyError([Issue(Severity.ERROR, "load.root", "/", "policy root must be a mapping")])
    v.keys(
        data,
        "",
        [
            "interfaces",
            "zones",
            "address_sets",
            "service_sets",
            "dynamic_sets",
            "rules",
            "state",
            "essential",
            "logging",
            "nat",
        ],
        ["schema_version", "policy", "defaults"],
    )
    sv = data.get("schema_version")
    if sv != SCHEMA_VERSION:
        v.error("/schema_version", "schema.version", f"unsupported schema_version {sv!r}; this release supports {SCHEMA_VERSION}")
    meta = _parse_meta(v, data.get("policy"))
    defaults = _parse_defaults(v, data.get("defaults"))
    interfaces = _parse_interfaces(v, data.get("interfaces"))
    zones = _parse_zones(v, data.get("zones"), interfaces)
    asets = _parse_address_sets(v, data.get("address_sets"))
    ssets = _parse_service_sets(v, data.get("service_sets"))
    dsets = _parse_dynamic_sets(v, data.get("dynamic_sets"))
    raw_rules = v.list_(data.get("rules"), "/rules", MAX_RULES)
    rules = [r for i, rr in enumerate(raw_rules) if (r := _parse_rule(v, rr, f"/rules/{i}")) is not None]
    parts = {
        "zones": zones,
        "address_sets": asets,
        "service_sets": ssets,
        "dynamic_sets": dsets,
        "rules": rules,
        "nat": _parse_nat(v, data.get("nat")),
        "essential": _parse_essential(v, data.get("essential")),
    }
    state = _parse_state(v, data.get("state"))
    logging_ = _parse_logging(v, data.get("logging"))
    if not v.failed:
        _check_refs_and_families(v, parts)
    if v.failed or meta is None or defaults is None:
        raise PolicyError(v.issues)

    policy = Policy(
        schema_version=SCHEMA_VERSION,
        meta=meta,
        defaults=defaults,
        zones=zones,
        address_sets=asets,
        service_sets=ssets,
        dynamic_sets=dsets,
        rules=tuple(rules),
        state=state,
        essential=parts["essential"],
        logging=logging_,
        nat=parts["nat"],
        interfaces=interfaces,
    )
    now = now or datetime.now(timezone.utc)
    for i, r in enumerate(policy.rules):
        if r.expires is not None and r.expires <= now:
            v.warn(f"/rules/{i}/expires", "rule.expired", f"rule {r.id!r} expired at {r.expires.isoformat()} and will not be compiled")
        if not r.enabled:
            v.warn(f"/rules/{i}/enabled", "rule.disabled", f"rule {r.id!r} is disabled and will not be compiled")
    for issue in analyse_conflicts(policy, now):
        if issue.severity is Severity.ERROR and not strict_conflicts:
            issue = Issue(Severity.WARNING, issue.code, issue.path, issue.message)
        v.issues.append(issue)
    if v.failed:
        raise PolicyError(v.issues)
    return policy, [i for i in v.issues if i.severity is Severity.WARNING]


def validate_text(text: str | bytes, *, fmt: Optional[str] = None, now: Optional[datetime] = None) -> tuple[Policy, list[Issue]]:
    """Load and validate a policy document in one step."""
    return build_policy(load_policy_text(text, fmt), now=now)


Validator = Callable[[str], tuple[Policy, list[Issue]]]
