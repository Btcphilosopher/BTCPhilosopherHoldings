"""Hardened policy document loading (YAML or JSON).

Configuration is data, never code:

* YAML is parsed with a restricted ``SafeLoader`` subclass that additionally
  rejects aliases/anchors (no exponential "billion laughs" expansion), custom
  tags, and duplicate mapping keys (silent last-wins would make a policy
  ambiguous).
* JSON is parsed with a duplicate-key check and a nesting limit.
* Documents larger than :data:`MAX_POLICY_BYTES` are rejected before parsing.

Nothing in a policy is ever evaluated, templated or passed to a shell.
"""

from __future__ import annotations

import json
from typing import Any

import yaml

from cipher_types import Issue, PolicyError, Severity

MAX_POLICY_BYTES = 4 * 1024 * 1024
MAX_DEPTH = 32


def _err(code: str, msg: str, path: str = "/") -> PolicyError:
    return PolicyError([Issue(Severity.ERROR, code, path, msg)])


class _StrictLoader(yaml.SafeLoader):
    """SafeLoader without aliases, duplicate keys or non-core tags."""

    def compose_node(self, parent, index):  # type: ignore[override]
        if self.check_event(yaml.events.AliasEvent):
            event = self.peek_event()
            raise yaml.constructor.ConstructorError(
                None, None, "YAML aliases/anchors are not permitted in policies", event.start_mark
            )
        return super().compose_node(parent, index)

    def construct_mapping(self, node, deep=False):  # type: ignore[override]
        if not isinstance(node, yaml.MappingNode):
            raise yaml.constructor.ConstructorError(
                None, None, f"expected a mapping, found {node.id}", node.start_mark
            )
        seen: set[Any] = set()
        for key_node, _ in node.value:
            if key_node.tag == "tag:yaml.org,2002:merge":
                raise yaml.constructor.ConstructorError(
                    None, None, "YAML merge keys (<<) are not permitted", key_node.start_mark
                )
            key = self.construct_object(key_node, deep=True)
            if key in seen:
                raise yaml.constructor.ConstructorError(
                    None, None, f"duplicate key {key!r}", key_node.start_mark
                )
            seen.add(key)
        return super().construct_mapping(node, deep=deep)


# Timestamps are kept as strings so that expiry parsing is explicit and always
# timezone-checked by the validator rather than YAML's implicit resolver.
for _first, _resolvers in list(_StrictLoader.yaml_implicit_resolvers.items()):
    _StrictLoader.yaml_implicit_resolvers[_first] = [
        (tag, rx) for tag, rx in _resolvers if tag != "tag:yaml.org,2002:timestamp"
    ]


def _unknown_tag(loader, tag_suffix, node):  # pragma: no cover - exercised via tests
    raise yaml.constructor.ConstructorError(
        None, None, f"YAML tag {node.tag!r} is not permitted", node.start_mark
    )


_StrictLoader.add_multi_constructor("!", _unknown_tag)
_StrictLoader.add_multi_constructor("tag:yaml.org,2002:python", _unknown_tag)


def _depth(obj: Any, level: int = 0) -> int:
    if level > MAX_DEPTH:
        return level
    if isinstance(obj, dict):
        return max([level] + [_depth(v, level + 1) for v in obj.values()])
    if isinstance(obj, list):
        return max([level] + [_depth(v, level + 1) for v in obj])
    return level


def _json_pairs(pairs):
    out: dict[str, Any] = {}
    for k, v in pairs:
        if k in out:
            raise ValueError(f"duplicate key {k!r}")
        out[k] = v
    return out


def load_policy_text(text: str | bytes, fmt: str | None = None) -> dict[str, Any]:
    """Parse a policy document into plain Python data.

    ``fmt`` may be ``"yaml"``, ``"json"`` or ``None`` (auto-detect: a document
    whose first non-space character is ``{`` is JSON).
    """
    if isinstance(text, bytes):
        if len(text) > MAX_POLICY_BYTES:
            raise _err("load.too_large", f"policy exceeds {MAX_POLICY_BYTES} bytes")
        try:
            text = text.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise _err("load.encoding", f"policy is not valid UTF-8: {exc}") from None
    if len(text.encode("utf-8")) > MAX_POLICY_BYTES:
        raise _err("load.too_large", f"policy exceeds {MAX_POLICY_BYTES} bytes")
    if "\x00" in text:
        raise _err("load.nul", "policy contains NUL bytes")
    if fmt is None:
        fmt = "json" if text.lstrip().startswith("{") else "yaml"
    try:
        if fmt == "json":
            data = json.loads(text, object_pairs_hook=_json_pairs)
        elif fmt == "yaml":
            docs = list(yaml.load_all(text, Loader=_StrictLoader))  # noqa: S506 - strict SafeLoader
            if len(docs) != 1:
                raise _err("load.documents", f"expected exactly one YAML document, found {len(docs)}")
            data = docs[0]
        else:
            raise _err("load.format", f"unknown policy format {fmt!r}")
    except PolicyError:
        raise
    except (yaml.YAMLError, ValueError) as exc:
        raise _err("load.syntax", f"cannot parse policy: {exc}") from None
    if not isinstance(data, dict):
        raise _err("load.root", "policy root must be a mapping")
    if _depth(data) > MAX_DEPTH:
        raise _err("load.depth", f"policy nesting exceeds {MAX_DEPTH} levels")
    return data


def load_policy_file(path: str) -> tuple[str, dict[str, Any]]:
    """Read and parse a policy file. Returns ``(raw_text, data)``."""
    with open(path, "rb") as fh:
        raw = fh.read(MAX_POLICY_BYTES + 1)
    fmt = "json" if path.endswith(".json") else None
    data = load_policy_text(raw, fmt)
    return raw.decode("utf-8"), data
