"""Typed, immutable policy model produced by :mod:`cipher_policy.validate`.

Instances of these classes are only ever created by the validator, so code
that receives a :class:`Policy` may assume every invariant documented in
``docs/policy-language.md`` holds.
"""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal, Optional, Union

from cipher_types import Action, DefaultAction, Family, Hook, Protocol
from cipher_types.ir import PortRange

Network = Union[ipaddress.IPv4Network, ipaddress.IPv6Network]
IPAddr = Union[ipaddress.IPv4Address, ipaddress.IPv6Address]


def net_family(n: Union[Network, IPAddr]) -> Family:
    return Family.IPV4 if n.version == 4 else Family.IPV6


@dataclass(frozen=True)
class PolicyMeta:
    id: str
    revision: int
    description: str = ""


@dataclass(frozen=True)
class Zone:
    name: str
    interfaces: tuple[str, ...]
    networks: tuple[Network, ...] = ()
    description: str = ""


@dataclass(frozen=True)
class AddressSet:
    name: str
    networks: tuple[Network, ...]
    description: str = ""


@dataclass(frozen=True)
class Service:
    protocol: Protocol
    ports: tuple[PortRange, ...] = ()
    icmp_types: tuple[str, ...] = ()


@dataclass(frozen=True)
class ServiceSet:
    name: str
    services: tuple[Service, ...]
    description: str = ""


@dataclass(frozen=True)
class DynamicSet:
    """A set whose elements come from a controlled runtime source.

    The policy decides *what happens* to members (via rules); the source
    (DNS resolver, threat feed, detection adapter) can only change membership,
    bounded by ``max_elements``.
    """

    name: str
    family: Family  # ipv4 or ipv6, never any
    source: Literal["dns", "feed", "detection"]
    max_elements: int
    timeout_seconds: Optional[int] = None
    description: str = ""


@dataclass(frozen=True)
class Endpoint:
    zone: Optional[str] = None
    networks: tuple[Network, ...] = ()
    sets: tuple[str, ...] = ()

    @property
    def is_any(self) -> bool:
        return self.zone is None and not self.networks and not self.sets


@dataclass(frozen=True)
class Rule:
    id: str
    chain: Hook
    action: Action
    justification: str
    family: Family = Family.ANY
    source: Endpoint = field(default_factory=Endpoint)
    destination: Endpoint = field(default_factory=Endpoint)
    in_interfaces: tuple[str, ...] = ()
    out_interfaces: tuple[str, ...] = ()
    protocol: Optional[Protocol] = None
    ports: tuple[PortRange, ...] = ()
    source_ports: tuple[PortRange, ...] = ()
    services: tuple[str, ...] = ()
    icmp_types: tuple[str, ...] = ()
    ct_states: tuple[str, ...] = ()
    log: bool = False
    expires: Optional[datetime] = None
    enabled: bool = True

    def is_active(self, now: datetime) -> bool:
        return self.enabled and (self.expires is None or self.expires > now)


@dataclass(frozen=True)
class Defaults:
    input: DefaultAction
    output: DefaultAction
    forward: DefaultAction

    def for_hook(self, hook: Hook) -> DefaultAction:
        return getattr(self, hook.value)


@dataclass(frozen=True)
class StateHandling:
    #: ``accept`` installs an early "ct state established,related accept";
    #: ``evaluate`` sends return traffic through the ordinary rules.
    established_related: Literal["accept", "evaluate"] = "accept"
    #: ``drop`` installs an early "ct state invalid drop".
    invalid: Literal["drop", "evaluate"] = "drop"


@dataclass(frozen=True)
class AdminAccess:
    ports: tuple[PortRange, ...]
    source: Endpoint
    justification: str
    protocol: Protocol = Protocol.TCP


@dataclass(frozen=True)
class Essential:
    loopback: Literal["accept", "evaluate"] = "accept"
    loopback_antispoof: bool = True
    icmpv6_neighbor_discovery: bool = True
    icmpv6_errors: bool = True
    icmpv4_errors: bool = True
    slaac: bool = True
    dhcpv4_client: bool = False
    dhcpv6_client: bool = False
    dns_servers: tuple[IPAddr, ...] = ()
    ntp_servers: tuple[IPAddr, ...] = ()
    admin_access: Optional[AdminAccess] = None


@dataclass(frozen=True)
class Logging:
    rate: int = 5
    per: Literal["second", "minute", "hour"] = "second"
    burst: int = 10
    level: str = "info"
    log_default_drop: bool = True


@dataclass(frozen=True)
class Masquerade:
    id: str
    out_interfaces: tuple[str, ...]
    family: Family
    source: Endpoint
    justification: str


@dataclass(frozen=True)
class PortForward:
    id: str
    in_interfaces: tuple[str, ...]
    protocol: Protocol
    port: int
    to_address: IPAddr
    to_port: int
    justification: str
    destination: Endpoint = field(default_factory=Endpoint)


@dataclass(frozen=True)
class Nat:
    masquerade: tuple[Masquerade, ...] = ()
    port_forwards: tuple[PortForward, ...] = ()

    @property
    def enabled(self) -> bool:
        return bool(self.masquerade or self.port_forwards)


@dataclass(frozen=True)
class Policy:
    schema_version: int
    meta: PolicyMeta
    defaults: Defaults
    zones: dict[str, Zone]
    address_sets: dict[str, AddressSet]
    service_sets: dict[str, ServiceSet]
    dynamic_sets: dict[str, DynamicSet]
    rules: tuple[Rule, ...]
    state: StateHandling = field(default_factory=StateHandling)
    essential: Essential = field(default_factory=Essential)
    logging: Logging = field(default_factory=Logging)
    nat: Nat = field(default_factory=Nat)
    interfaces: dict[str, str] = field(default_factory=dict)  # iface -> zone
