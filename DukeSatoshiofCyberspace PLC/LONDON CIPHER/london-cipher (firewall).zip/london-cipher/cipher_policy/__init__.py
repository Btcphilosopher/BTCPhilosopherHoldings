"""Declarative policy language: loading, validation, typed model, analysis.

Public entry points::

    from cipher_policy import validate_text, load_policy_file, build_policy
    policy, warnings = validate_text(open("policy.yaml").read())

See ``docs/policy-language.md`` for the full schema and semantics.
"""

from .loader import MAX_POLICY_BYTES, load_policy_file, load_policy_text
from .model import Policy
from .validate import build_policy, validate_text

__all__ = [
    "MAX_POLICY_BYTES",
    "Policy",
    "build_policy",
    "load_policy_file",
    "load_policy_text",
    "validate_text",
]
