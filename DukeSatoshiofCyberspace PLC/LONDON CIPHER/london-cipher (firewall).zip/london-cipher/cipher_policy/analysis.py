"""Static conflict analysis: shadowed and redundant rules.

Rule semantics are *first match wins* within a chain (``docs/policy-language.md``).
A later rule B is **shadowed** by an earlier rule A in the same chain when every
packet B could match is provably also matched by A. Then:

* if A and B have different actions -> error ``conflict.shadowed`` (the author
  almost certainly intended B to take effect, and it never will);
* if they have the same action -> warning ``conflict.redundant``.

The analysis is *sound but incomplete*: it only reports coverage it can prove
from static data (inline networks, static address sets, interfaces, ports,
ICMP types, ct states). Membership of dynamic sets is unknown at validation
time, so a dynamic set is only considered covered by the same dynamic set.
"""

from __future__ import annotations

import functools
import ipaddress
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from cipher_types import Family, Issue, Protocol, Severity
from cipher_types.ir import PortRange

from .model import Endpoint, Policy, Rule, net_family

#: Above this many active rules in one chain the quadratic analysis is skipped
#: (and a warning says so) to keep validation time bounded.
MAX_ANALYSED_RULES_PER_CHAIN = 1500


@dataclass(frozen=True)
class NetSpace:
    networks: tuple  # ip_network objects of one family
    dynamic: frozenset[str]
    complex_key: Optional[str] = None  # set when constraint is an intersection

    def covers(self, other: "NetSpace") -> bool:
        return _netspace_covers(self, other)

    def _covers(self, other: "NetSpace") -> bool:
        if self.complex_key or other.complex_key:
            return self == other
        if not other.dynamic <= self.dynamic:
            return False
        return all(any(n.subnet_of(m) for m in self.networks if m.version == n.version) for n in other.networks)


@functools.lru_cache(maxsize=65536)
def _netspace_covers(a: NetSpace, b: NetSpace) -> bool:
    return a._covers(b)


@dataclass(frozen=True)
class Space:
    family: Family
    iif: Optional[frozenset[str]]
    oif: Optional[frozenset[str]]
    src: Optional[NetSpace]
    dst: Optional[NetSpace]
    proto: Optional[Protocol]
    dports: Optional[tuple[PortRange, ...]]
    sports: Optional[tuple[PortRange, ...]]
    icmp: Optional[frozenset[str]]
    ct: Optional[frozenset[str]]


def _iface_covers(a: Optional[frozenset[str]], b: Optional[frozenset[str]]) -> bool:
    if a is None:
        return True
    if b is None:
        return False
    for name in b:
        base = name[:-1] if name.endswith("*") else name
        if not any(pat == name or (pat.endswith("*") and base.startswith(pat[:-1])) for pat in a):
            return False
    return True


def _ports_cover(a: Optional[tuple[PortRange, ...]], b: Optional[tuple[PortRange, ...]]) -> bool:
    if a is None:
        return True
    if b is None:
        return False
    return all(any(x.contains(y) for x in a) for y in b)


def _opt_set_covers(a, b) -> bool:
    if a is None:
        return True
    if b is None:
        return False
    return b <= a


def _net_cover(a: Optional[NetSpace], b: Optional[NetSpace]) -> bool:
    if a is None:
        return True
    if b is None:
        return False
    return a.covers(b)


def covers(a: Space, b: Space) -> bool:
    # Cheapest discriminating checks first; network containment last.
    if a.family != b.family:
        return False
    if a.proto is not None and a.proto != b.proto:
        return False
    return (
        _ports_cover(a.dports, b.dports)
        and _ports_cover(a.sports, b.sports)
        and _opt_set_covers(a.icmp, b.icmp)
        and _opt_set_covers(a.ct, b.ct)
        and _iface_covers(a.iif, b.iif)
        and _iface_covers(a.oif, b.oif)
        and _net_cover(a.src, b.src)
        and _net_cover(a.dst, b.dst)
    )


def _endpoint_space(policy: Policy, ep: Endpoint, fam: Family) -> tuple[Optional[NetSpace], Optional[frozenset[str]], bool]:
    """Returns (net constraint, interfaces from zone, possible)."""
    nets = [n for n in ep.networks if net_family(n) is fam]
    dyn: set[str] = set()
    explicit = bool(ep.networks or ep.sets)
    for s in ep.sets:
        if s in policy.address_sets:
            nets.extend(n for n in policy.address_sets[s].networks if net_family(n) is fam)
        elif s in policy.dynamic_sets and policy.dynamic_sets[s].family is fam:
            dyn.add(s)
    zone_ifaces = None
    zone_nets: list = []
    if ep.zone:
        z = policy.zones[ep.zone]
        zone_ifaces = frozenset(z.interfaces) if z.interfaces else None
        zone_nets = [n for n in z.networks if net_family(n) is fam]
        if z.networks and not zone_nets:
            return None, zone_ifaces, False
    if explicit and not nets and not dyn:
        return None, zone_ifaces, False
    collapsed = tuple(ipaddress.collapse_addresses(nets)) if nets else ()
    if explicit and zone_nets:
        key = repr((sorted(map(str, collapsed)), sorted(dyn), sorted(map(str, zone_nets))))
        return NetSpace(collapsed, frozenset(dyn), key), zone_ifaces, True
    if explicit:
        return NetSpace(collapsed, frozenset(dyn)), zone_ifaces, True
    if zone_nets:
        return NetSpace(tuple(ipaddress.collapse_addresses(zone_nets)), frozenset()), zone_ifaces, True
    return None, zone_ifaces, True


def _merge_ifaces(explicit: tuple[str, ...], zone: Optional[frozenset[str]]) -> Optional[frozenset[str]]:
    if explicit and zone is not None:
        if any(x.endswith("*") for x in explicit) or any(x.endswith("*") for x in zone):
            # Intersection of wildcard patterns is not computed; use an opaque
            # key so this constraint only ever equals an identical one (sound).
            return frozenset({"\x00" + repr((sorted(explicit), sorted(zone)))})
        return frozenset(explicit) & zone
    if explicit:
        return frozenset(explicit)
    return zone


def rule_spaces(policy: Policy, r: Rule) -> list[Space]:
    parts: list[tuple[Optional[Protocol], Optional[tuple], Optional[frozenset]]] = []
    if r.services:
        for s in r.services:
            for svc in policy.service_sets[s].services:
                parts.append((svc.protocol, svc.ports or None, frozenset(svc.icmp_types) or None))
    else:
        parts.append((r.protocol, r.ports or None, frozenset(r.icmp_types) or None))
    out = []
    for fam in r.family.expand():
        src, src_if, ok1 = _endpoint_space(policy, r.source, fam)
        dst, dst_if, ok2 = _endpoint_space(policy, r.destination, fam)
        if not (ok1 and ok2):
            continue
        iif = _merge_ifaces(r.in_interfaces, src_if if r.chain.value != "output" else None)
        oif = _merge_ifaces(r.out_interfaces, dst_if if r.chain.value != "input" else None)
        for proto, ports, icmp in parts:
            if proto is Protocol.ICMP and fam is not Family.IPV4:
                continue
            if proto is Protocol.ICMPV6 and fam is not Family.IPV6:
                continue
            out.append(
                Space(
                    fam,
                    iif,
                    oif,
                    src,
                    dst,
                    proto,
                    tuple(ports) if ports else None,
                    tuple(r.source_ports) if r.source_ports else None,
                    icmp,
                    frozenset(r.ct_states) if r.ct_states else None,
                )
            )
    return out


def _envelope(sp: Space) -> tuple:
    if sp.dports is None:
        return (sp.family, sp.proto, 0, 65536)
    return (sp.family, sp.proto, min(p.low for p in sp.dports), max(p.high for p in sp.dports))


def analyse_conflicts(policy: Policy, now: datetime) -> list[Issue]:
    issues: list[Issue] = []
    index = {r.id: i for i, r in enumerate(policy.rules)}
    by_chain: dict[str, list[Rule]] = {}
    for r in policy.rules:
        if r.is_active(now):
            by_chain.setdefault(r.chain.value, []).append(r)
    for chain, rules in by_chain.items():
        if len(rules) > MAX_ANALYSED_RULES_PER_CHAIN:
            issues.append(
                Issue(
                    Severity.WARNING,
                    "conflict.analysis_skipped",
                    "/rules",
                    f"chain {chain} has {len(rules)} active rules; shadow analysis is limited to {MAX_ANALYSED_RULES_PER_CHAIN}",
                )
            )
            continue
        spaces = [(r, rule_spaces(policy, r)) for r in rules]
        # Integer envelopes per space for a cheap necessary-condition filter.
        env = [[_envelope(x) for x in sp] for _, sp in spaces]
        for j, (rb, sb) in enumerate(spaces):
            if not sb:
                continue
            fb, pb, lob, hib = env[j][0]
            for i in range(j):
                for fa, pa, loa, hia in env[i]:
                    if loa <= lob and hia >= hib and fa is fb and (pa is None or pa is pb):
                        break
                else:
                    continue
                ra, sa = spaces[i]
                if all(any(covers(a, b) for a in sa) for b in sb):
                    same = ra.action == rb.action
                    issues.append(
                        Issue(
                            Severity.WARNING if same else Severity.ERROR,
                            "conflict.redundant" if same else "conflict.shadowed",
                            f"/rules/{index[rb.id]}",
                            (
                                f"rule {rb.id!r} is redundant: earlier rule {ra.id!r} already matches all its traffic with the same action"
                                if same
                                else f"rule {rb.id!r} ({rb.action.value}) can never match: earlier rule {ra.id!r} matches all its traffic with action {ra.action.value}"
                            ),
                        )
                    )
                    break
    return issues
