"""Deterministic in-memory (optionally file-persisted) backend.

Used by unit tests to exercise orchestration logic — failure injection,
process termination and restart — without kernel access. It implements the
same contract as the real backend: atomic replace, read-back verification
and a fingerprint that changes when "external" modifications occur.

It does not filter packets. Packet outcomes are only asserted in the
namespace laboratory against the real nftables backend.
"""

from __future__ import annotations

import hashlib
import json
import os
from typing import Any, Optional

from cipher_types import BackendError, VerificationError
from cipher_types.ir import IRRuleset, IRSet, canonical_json, rule_key

from .base import Capabilities, ConflictReport, ConntrackFilter, DynamicElement, EnforcementBackend, InstalledState


class MemoryBackend(EnforcementBackend):
    name = "memory"

    def __init__(self, persist_path: Optional[str] = None, features: Optional[set[str]] = None):
        self.persist_path = persist_path
        self.features = features or {"json", "atomic_replace", "named_sets", "log", "nat", "timeout_sets", "conntrack_delete"}
        # failure injection switches (tests)
        self.fail_check = False
        self.fail_apply = False
        self.fail_apply_once = False
        self.corrupt_after_apply = False
        self.fail_verify = False
        self.apply_count = 0
        self.conntrack_deleted: list[ConntrackFilter] = []
        self.conflict_report = ConflictReport()
        self._state: Optional[dict[str, Any]] = None
        self._load()

    # -- persistence -----------------------------------------------------------
    def _load(self) -> None:
        if self.persist_path and os.path.exists(self.persist_path):
            with open(self.persist_path) as fh:
                self._state = json.load(fh)

    def _save(self) -> None:
        if self.persist_path:
            tmp = self.persist_path + ".tmp"
            with open(tmp, "w") as fh:
                json.dump(self._state, fh)
            os.replace(tmp, self.persist_path)

    # -- contract ------------------------------------------------------------------
    def capabilities(self) -> Capabilities:
        return Capabilities("memory", "1", frozenset(self.features))

    def render(self, ruleset: IRRuleset, dynamic=None) -> str:
        return canonical_json(ruleset)

    def check(self, ruleset: IRRuleset, dynamic=None) -> None:
        if self.fail_check:
            raise BackendError("injected dry-run failure")

    def apply(self, ruleset: IRRuleset, dynamic=None) -> None:
        if self.fail_apply or self.fail_apply_once:
            self.fail_apply_once = False
            raise BackendError("injected transaction failure (nothing applied)")
        self.apply_count += 1
        dyn = {k: [e.value for e in v] for k, v in (dynamic or {}).items()}
        self._state = {
            "policy_id": ruleset.policy_id,
            "revision": ruleset.revision,
            "digest": ruleset.digest,
            "ir": canonical_json(ruleset),
            "chains": {c.name: [rule_key(r) for r in c.rules] for c in ruleset.chains},
            "policies": {c.name: c.policy for c in ruleset.chains},
            "dynamic": dyn,
        }
        if self.corrupt_after_apply:
            self._state["chains"]["input"] = self._state["chains"].get("input", [])[:-1]
        self._save()

    def remove(self) -> bool:
        present = self._state is not None
        self._state = None
        if self.persist_path and os.path.exists(self.persist_path):
            os.unlink(self.persist_path)
        return present

    def inspect(self) -> InstalledState:
        if self._state is None:
            return InstalledState(present=False)
        s = self._state
        fp_src = {k: v for k, v in s.items() if k != "dynamic"}
        return InstalledState(
            present=True,
            policy_id=s["policy_id"],
            revision=s["revision"],
            digest_prefix=s["digest"][:32],
            fingerprint=hashlib.sha256(json.dumps(fp_src, sort_keys=True).encode()).hexdigest(),
            chains={k: {"comments": v, "policy": s["policies"].get(k)} for k, v in s["chains"].items()},
        )

    def verify(self, ruleset: IRRuleset) -> InstalledState:
        if self.fail_verify:
            raise VerificationError("injected verification failure")
        st = self.inspect()
        if not st.present:
            raise VerificationError("nothing installed")
        if self._state["digest"] != ruleset.digest:  # type: ignore[index]
            raise VerificationError("installed digest differs")
        expected = {c.name: [rule_key(r) for r in c.rules] for c in ruleset.chains}
        if self._state["chains"] != expected:  # type: ignore[index]
            raise VerificationError("installed rule sequence differs")
        return st

    def conflicts(self) -> ConflictReport:
        return self.conflict_report

    def update_dynamic_set(self, ruleset: IRRuleset, irset: IRSet, elements: list[DynamicElement]) -> None:
        if self._state is None:
            raise BackendError("nothing installed")
        if len(elements) > irset.max_elements:
            raise BackendError("too many elements")
        self._state["dynamic"][irset.name] = sorted(e.value for e in elements)
        self._save()

    def read_dynamic_set(self, ruleset: IRRuleset, irset: IRSet) -> list[str]:
        if self._state is None:
            return []
        return list(self._state["dynamic"].get(irset.name, []))

    def conntrack_delete(self, flt: ConntrackFilter) -> int:
        self.conntrack_deleted.append(flt)
        return 1

    # -- test helpers -------------------------------------------------------------------
    def tamper(self) -> None:
        """Simulate an external tool editing the managed namespace."""
        if self._state is None:
            raise BackendError("nothing installed")
        self._state["chains"].setdefault("input", []).insert(0, "foreign-rule")
        self._save()

    @property
    def installed_revision(self) -> Optional[int]:
        return None if self._state is None else self._state["revision"]
