"""Typed enforcement-backend interface.

A backend turns an :class:`~cipher_types.ir.IRRuleset` into kernel state. It
must honour the IR semantics documented in :mod:`cipher_types.ir` and the
contract below; policy semantics never change per backend.

Contract
--------
``check``      validate an artefact without changing enforcement.
``apply``      replace the managed namespace *atomically* (all or nothing).
``verify``     read back installed state and prove it equals the IR; raise
               :class:`~cipher_types.VerificationError` otherwise.
``inspect``    report what is installed now (or absence).
``remove``     delete only the managed namespace.
``conflicts``  report other firewall managers / foreign hooks; never modify them.
``update_dynamic_set`` atomically replace the members of a dynamic set.
``conntrack_delete``   remove matching connection-tracking entries.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any, Optional, Sequence

from cipher_types import CapabilityError
from cipher_types.ir import IRRuleset, IRSet


@dataclass(frozen=True)
class Capabilities:
    backend: str
    version: str
    features: frozenset[str]
    details: dict[str, Any] = field(default_factory=dict)

    def require(self, needed: Sequence[str]) -> None:
        missing = sorted(set(needed) - self.features)
        if missing:
            raise CapabilityError(
                f"backend {self.backend} {self.version} lacks required capabilities: {', '.join(missing)}"
            )


@dataclass
class InstalledState:
    present: bool
    policy_id: Optional[str] = None
    revision: Optional[int] = None
    digest_prefix: Optional[str] = None
    fingerprint: Optional[str] = None
    chains: dict[str, dict[str, Any]] = field(default_factory=dict)
    sets: dict[str, list[str]] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "present": self.present,
            "policy_id": self.policy_id,
            "revision": self.revision,
            "digest_prefix": self.digest_prefix,
            "fingerprint": self.fingerprint,
            "chains": self.chains,
        }


@dataclass
class ConflictReport:
    managers: list[str] = field(default_factory=list)
    foreign_base_chains: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    @property
    def has_managers(self) -> bool:
        return bool(self.managers)

    def to_dict(self) -> dict[str, Any]:
        return {"managers": self.managers, "foreign_base_chains": self.foreign_base_chains, "notes": self.notes}


@dataclass(frozen=True)
class DynamicElement:
    """A member of a dynamic set; ``timeout`` seconds remaining (timeout sets only)."""

    value: str
    timeout: Optional[int] = None


@dataclass(frozen=True)
class ConntrackFilter:
    family: str  # ipv4 | ipv6
    source: Optional[str] = None
    destination: Optional[str] = None
    protocol: Optional[str] = None  # tcp | udp
    dport: Optional[int] = None


class EnforcementBackend(abc.ABC):
    name: str = "abstract"

    @abc.abstractmethod
    def capabilities(self) -> Capabilities: ...

    @abc.abstractmethod
    def render(self, ruleset: IRRuleset, dynamic: Optional[dict[str, list[DynamicElement]]] = None) -> str:
        """Deterministic backend artefact (for review, dry-run and apply)."""

    @abc.abstractmethod
    def check(self, ruleset: IRRuleset, dynamic: Optional[dict[str, list[DynamicElement]]] = None) -> None: ...

    @abc.abstractmethod
    def apply(self, ruleset: IRRuleset, dynamic: Optional[dict[str, list[DynamicElement]]] = None) -> None: ...

    @abc.abstractmethod
    def inspect(self) -> InstalledState: ...

    @abc.abstractmethod
    def verify(self, ruleset: IRRuleset) -> InstalledState: ...

    @abc.abstractmethod
    def remove(self) -> bool: ...

    @abc.abstractmethod
    def conflicts(self) -> ConflictReport: ...

    @abc.abstractmethod
    def update_dynamic_set(self, ruleset: IRRuleset, irset: IRSet, elements: list[DynamicElement]) -> None: ...

    @abc.abstractmethod
    def read_dynamic_set(self, ruleset: IRRuleset, irset: IRSet) -> list[str]: ...

    @abc.abstractmethod
    def conntrack_delete(self, flt: ConntrackFilter) -> int: ...

    def required_features(self, ruleset: IRRuleset) -> list[str]:
        return list(ruleset.features)
