"""Enforcement backends.

* :class:`NftablesBackend` - Linux nftables via libnftables JSON (production).
* :class:`MemoryBackend` - deterministic test double (no packet filtering).

New backends implement :class:`EnforcementBackend`; policy semantics are fixed
by the IR and must not vary between backends.
"""

from .base import (
    Capabilities,
    ConflictReport,
    ConntrackFilter,
    DynamicElement,
    EnforcementBackend,
    InstalledState,
)
from .memory import MemoryBackend
from .nftables import NftablesBackend
from .runner import CommandRunner, netns_prefix

__all__ = [
    "Capabilities",
    "CommandRunner",
    "ConflictReport",
    "ConntrackFilter",
    "DynamicElement",
    "EnforcementBackend",
    "InstalledState",
    "MemoryBackend",
    "NftablesBackend",
    "netns_prefix",
]
