"""Linux nftables enforcement backend (libnftables JSON via the ``nft`` tool).

Interface verified against libnftables-json(5) and exercised against
nftables 1.0.9 in the isolated laboratory (see docs/backends/nftables.md).

Design:

* All changes are submitted as one JSON batch on stdin to ``nft -j -f -``.
  nftables applies a batch as a single kernel transaction: either every
  command succeeds or none takes effect. Each deploy is
  ``add table; delete table; add table; <sets>; <chains>; <rules>; <meta>``
  so the managed table is replaced atomically and no other table is touched.
* Dry-run uses ``nft -c`` (check mode) with the identical payload.
* Every generated rule carries a comment ``lc:<origin>:<rule-key>`` and the
  table carries a metadata rule ``lc-meta;p=<policy>;r=<revision>;d=<digest>``
  in a non-hooked chain. Verification reads the table back and compares
  hooks, priorities, policies, the exact ordered comment sequence of every
  chain and the contents of static sets.
* A fingerprint (SHA-256 of the normalised listing, excluding counters,
  handles and dynamic-set members) detects external modification.
"""

from __future__ import annotations

import hashlib
import ipaddress
import json
import platform
import re
from typing import Any, Optional

from cipher_types import TABLE_NAME, BackendError, VerificationError
from cipher_types.ir import (
    IRChain,
    IRRule,
    IRRuleset,
    IRSet,
    MAddr,
    MCtState,
    MHopLimit,
    MIcmp,
    MIface,
    ML4,
    MNfproto,
    MPort,
    PortRange,
    rule_key,
)

from .base import Capabilities, ConflictReport, ConntrackFilter, DynamicElement, EnforcementBackend, InstalledState
from .runner import CommandRunner

META_CHAIN = "lc_meta"
FAMILY = "inet"
MIN_NFT = (0, 9, 3)
_L4 = {"tcp": "tcp", "udp": "udp", "icmp": "icmp", "icmpv6": "ipv6-icmp"}
_COMMENT_MAX = 127


def _ver_tuple(s: str) -> tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", s)[:3])


def _match(left: dict, right: Any, op: str = "==") -> dict:
    return {"match": {"op": op, "left": left, "right": right}}


def _rhs(values: list) -> Any:
    return values[0] if len(values) == 1 else {"set": values}


def _net_elem(cidr: str) -> Any:
    n = ipaddress.ip_network(cidr)
    if n.prefixlen == n.max_prefixlen:
        return str(n.network_address)
    return {"prefix": {"addr": str(n.network_address), "len": n.prefixlen}}


def _port_elem(p: PortRange) -> Any:
    return p.low if p.low == p.high else {"range": [p.low, p.high]}


def _comment(origin: str, r: IRRule, suffix: str = "") -> str:
    # Rule ids are unique across user/nat rules; generated ids are namespaced
    # (essential.*, default.*), so the origin need not be repeated.
    c = f"lc:{rule_key(r)}{suffix}"
    return c[:_COMMENT_MAX]


def match_expr(m) -> dict:
    if isinstance(m, MNfproto):
        return _match({"meta": {"key": "nfproto"}}, m.family)
    if isinstance(m, MIface):
        return _match({"meta": {"key": m.direction}}, _rhs(list(m.names)), "!=" if m.negate else "==")
    if isinstance(m, MAddr):
        left = {"payload": {"protocol": "ip" if m.family == "ipv4" else "ip6", "field": m.field}}
        if m.set_name:
            return _match(left, f"@{m.set_name}")
        return _match(left, _rhs([_net_elem(n) for n in m.networks]))
    if isinstance(m, ML4):
        return _match({"meta": {"key": "l4proto"}}, _L4[m.protocol])
    if isinstance(m, MPort):
        return _match({"payload": {"protocol": m.protocol, "field": m.field}}, _rhs([_port_elem(p) for p in m.ports]))
    if isinstance(m, MIcmp):
        return _match({"payload": {"protocol": m.protocol, "field": "type"}}, _rhs(list(m.types)))
    if isinstance(m, MCtState):
        states = list(m.states)
        return _match({"ct": {"key": "state"}}, states[0] if len(states) == 1 else states, "in")
    if isinstance(m, MHopLimit):
        return _match({"payload": {"protocol": "ip6", "field": "hoplimit"}}, m.value)
    raise BackendError(f"nftables backend cannot render match {type(m).__name__}")


def _is_tcp_rule(r: IRRule) -> bool:
    return any((isinstance(m, MPort) and m.protocol == "tcp") or (isinstance(m, ML4) and m.protocol == "tcp") for m in r.matches)


def _verdict(r: IRRule) -> list[dict]:
    if r.verdict == "accept":
        return [{"accept": None}]
    if r.verdict == "drop":
        return [{"drop": None}]
    if r.verdict == "reject":
        if _is_tcp_rule(r):
            return [{"reject": {"type": "tcp reset"}}]
        return [{"reject": {"type": "icmpx", "expr": "port-unreachable"}}]
    return []


def _nat_stmt(r: IRRule) -> list[dict]:
    n = r.nat
    if n is None:
        return []
    if n.kind == "masquerade":
        return [{"masquerade": None}]
    body: dict[str, Any] = {"family": "ip" if n.family == "ipv4" else "ip6", "addr": n.addr}
    if n.port is not None:
        body["port"] = n.port
    return [{n.kind: body}]


def expand_rule(r: IRRule) -> list[tuple[list[dict], str]]:
    """One IR rule -> one or two nftables rules (log rule precedes verdict rule)."""
    matches = [match_expr(m) for m in r.matches]
    out = []
    if r.log is not None:
        lim = {"limit": {"rate": r.log.rate, "per": r.log.per, "burst": r.log.burst}}
        log = {"log": {"prefix": r.log.prefix, "level": r.log.level}}
        out.append((matches + [lim, log], _comment(r.origin, r, ":log")))
    tail = _nat_stmt(r) + _verdict(r)
    if tail:
        out.append((matches + [{"counter": None}] + tail, _comment(r.origin, r)))
    return out


def meta_comment(rs: IRRuleset) -> str:
    return f"lc-meta;p={rs.policy_id};r={rs.revision};d={rs.digest[:32]}"


def expected_comments(chain: IRChain) -> list[str]:
    return [c for r in chain.rules for _, c in expand_rule(r)]


def render_commands(rs: IRRuleset, dynamic: Optional[dict[str, list[DynamicElement]]] = None) -> list[dict]:
    t = {"family": FAMILY, "table": rs.table}
    cmds: list[dict] = [
        {"metainfo": {"json_schema_version": 1}},
        {"add": {"table": {"family": FAMILY, "name": rs.table}}},
        {"delete": {"table": {"family": FAMILY, "name": rs.table}}},
        {"add": {"table": {"family": FAMILY, "name": rs.table}}},
    ]
    for s in rs.sets:
        body: dict[str, Any] = dict(t, name=s.name, type=s.nft_type)
        if s.timeout:
            body["flags"] = ["timeout"]
        else:
            body["flags"] = ["interval"]
        if s.dynamic:
            body["size"] = s.max_elements
            elems = (dynamic or {}).get(s.name)
            if elems:
                body["elem"] = _dyn_elems(s, elems)
        elif s.elements:
            body["elem"] = [_net_elem(e) for e in s.elements]
        cmds.append({"add": {"set": body}})
    for c in rs.chains:
        body = dict(t, name=c.name)
        if c.hook:
            body.update(type=c.kind, hook=c.hook, prio=c.priority, policy=c.policy)
        cmds.append({"add": {"chain": body}})
    for c in rs.chains:
        for expr, comment in (x for r in c.rules for x in expand_rule(r)):
            cmds.append({"add": {"rule": dict(t, chain=c.name, expr=expr, comment=comment)}})
    cmds.append({"add": {"chain": dict(t, name=META_CHAIN)}})
    cmds.append({"add": {"rule": dict(t, chain=META_CHAIN, expr=[{"counter": None}], comment=meta_comment(rs))}})
    return cmds


def _dyn_elems(s: IRSet, elems: list[DynamicElement]) -> list[Any]:
    if len(elems) > s.max_elements:
        raise BackendError(f"dynamic set {s.name} would hold {len(elems)} elements; limit is {s.max_elements}")
    out = []
    for e in sorted(elems, key=lambda e: e.value):
        n = ipaddress.ip_network(e.value)
        if (n.version == 4) != (s.family == "ipv4"):
            raise BackendError(f"element {e.value} does not match family of set {s.name}")
        if s.timeout:
            if e.timeout is None or e.timeout <= 0:
                continue
            out.append({"elem": {"val": str(n.network_address), "timeout": int(e.timeout)}})
        else:
            out.append(_net_elem(str(n)))
    return out


def _elem_to_networks(e: Any) -> list[str]:
    if isinstance(e, dict) and "elem" in e:
        e = e["elem"]["val"]
    if isinstance(e, str):
        return [str(ipaddress.ip_network(e))]
    if isinstance(e, dict) and "prefix" in e:
        return [str(ipaddress.ip_network(f"{e['prefix']['addr']}/{e['prefix']['len']}"))]
    if isinstance(e, dict) and "range" in e:
        a, b = (ipaddress.ip_address(x) for x in e["range"])
        return [str(n) for n in ipaddress.summarize_address_range(a, b)]
    raise VerificationError(f"unrecognised set element {e!r}")


def _collapse(items: list[str]) -> list[str]:
    nets = [ipaddress.ip_network(x) for x in items]
    out: list[str] = []
    for v in (4, 6):
        out.extend(str(n) for n in ipaddress.collapse_addresses([n for n in nets if n.version == v]))
    return out


class NftablesBackend(EnforcementBackend):
    name = "nftables"

    def __init__(self, runner: Optional[CommandRunner] = None, table: str = TABLE_NAME, nft: str = "nft"):
        self.runner = runner or CommandRunner()
        self.table = table
        self.nft = nft

    # -- helpers --------------------------------------------------------------
    def _nft(self, args: list[str], stdin: Optional[str] = None, check: bool = True):
        return self.runner.run([self.nft, *args], stdin=stdin, check=check)

    def _submit(self, cmds: list[dict], check_only: bool = False) -> None:
        payload = json.dumps({"nftables": cmds}, separators=(",", ":"))
        args = ["-c", "-j", "-f", "-"] if check_only else ["-j", "-f", "-"]
        res = self._nft(args, stdin=payload, check=False)
        if res.returncode != 0:
            what = "dry-run" if check_only else "transaction"
            raise BackendError(f"nftables {what} rejected: {res.stderr.strip()[:4000]}")

    def _list_table(self) -> Optional[list[dict]]:
        res = self._nft(["-j", "list", "table", FAMILY, self.table], check=False)
        if res.returncode != 0:
            if "No such file or directory" in res.stderr or "does not exist" in res.stderr:
                return None
            raise BackendError(f"cannot list table: {res.stderr.strip()[:2000]}")
        try:
            return json.loads(res.stdout)["nftables"]
        except (ValueError, KeyError) as exc:
            raise BackendError(f"unparseable nft JSON output: {exc}") from None

    # -- capabilities -------------------------------------------------------------
    def capabilities(self) -> Capabilities:
        res = self._nft(["--version"], check=False)
        if res.returncode != 0:
            raise BackendError("nft is not usable")
        m = re.search(r"v?(\d+\.\d+(?:\.\d+)?)", res.stdout)
        version = m.group(1) if m else "unknown"
        feats = {"named_sets", "log", "atomic_replace"}
        details: dict[str, Any] = {"nft_version": version, "kernel": platform.release()}
        if _ver_tuple(version) >= MIN_NFT:
            j = self._nft(["-j", "list", "tables"], check=False)
            if j.returncode == 0 and j.stdout.strip().startswith("{"):
                feats.add("json")
        kernel = _ver_tuple(platform.release())
        if kernel >= (5, 2):
            feats.add("nat")  # inet-family NAT (Linux >= 5.2)
        if kernel >= (4, 0):
            feats.add("timeout_sets")
        from .runner import resolve

        if resolve("conntrack"):
            feats.add("conntrack_delete")
        return Capabilities("nftables", version, frozenset(feats), details)

    def required_features(self, ruleset: IRRuleset) -> list[str]:
        return sorted(set(ruleset.features) | {"json", "atomic_replace"})

    # -- deploy -----------------------------------------------------------------------
    def render(self, ruleset: IRRuleset, dynamic=None) -> str:
        return json.dumps({"nftables": render_commands(ruleset, dynamic)}, indent=1, sort_keys=False)

    def check(self, ruleset: IRRuleset, dynamic=None) -> None:
        self._submit(render_commands(ruleset, dynamic), check_only=True)

    def apply(self, ruleset: IRRuleset, dynamic=None) -> None:
        self._submit(render_commands(ruleset, dynamic))

    def remove(self) -> bool:
        if self._list_table() is None:
            return False
        self._submit([{"delete": {"table": {"family": FAMILY, "name": self.table}}}])
        return True

    # -- read back ------------------------------------------------------------------
    def inspect(self) -> InstalledState:
        objs = self._list_table()
        if objs is None:
            return InstalledState(present=False)
        st = InstalledState(present=True)
        dyn_sets: set[str] = set()
        norm: list[Any] = []
        for o in objs:
            if "metainfo" in o:
                continue
            if "chain" in o:
                c = o["chain"]
                st.chains[c["name"]] = {
                    "type": c.get("type"),
                    "hook": c.get("hook"),
                    "prio": c.get("prio"),
                    "policy": c.get("policy"),
                    "comments": [],
                }
                norm.append({"chain": {k: v for k, v in c.items() if k != "handle"}})
            elif "set" in o:
                s = o["set"]
                elems: list[str] = []
                for e in s.get("elem", []):
                    elems.extend(_elem_to_networks(e))
                st.sets[s["name"]] = _collapse(elems)
                dynamic = s["name"].startswith("dyn_")
                if dynamic:
                    dyn_sets.add(s["name"])
                body = {k: v for k, v in s.items() if k not in ("handle",) and not (dynamic and k == "elem")}
                norm.append({"set": body})
            elif "rule" in o:
                r = o["rule"]
                comment = r.get("comment")
                if r["chain"] == META_CHAIN and comment and comment.startswith("lc-meta;"):
                    kv = dict(p.split("=", 1) for p in comment.split(";")[1:] if "=" in p)
                    st.policy_id = kv.get("p")
                    st.revision = int(kv["r"]) if kv.get("r", "").isdigit() else None
                    st.digest_prefix = kv.get("d")
                if r["chain"] in st.chains:
                    st.chains[r["chain"]]["comments"].append(comment)
                expr = [({"counter": None} if "counter" in e else e) for e in r.get("expr", [])]
                norm.append({"rule": {"chain": r["chain"], "comment": comment, "expr": expr}})
        st.fingerprint = hashlib.sha256(json.dumps(norm, sort_keys=True).encode()).hexdigest()
        return st

    def verify(self, ruleset: IRRuleset) -> InstalledState:
        st = self.inspect()
        problems: list[str] = []
        if not st.present:
            raise VerificationError(f"table inet {self.table} is not installed")
        if st.policy_id != ruleset.policy_id or st.revision != ruleset.revision:
            problems.append(f"metadata reports {st.policy_id} rev {st.revision}, expected {ruleset.policy_id} rev {ruleset.revision}")
        if st.digest_prefix != ruleset.digest[:32]:
            problems.append("metadata digest does not match compiled policy")
        expected_chains = {c.name for c in ruleset.chains} | {META_CHAIN}
        if set(st.chains) != expected_chains:
            problems.append(f"chains {sorted(st.chains)} differ from expected {sorted(expected_chains)}")
        for c in ruleset.chains:
            got = st.chains.get(c.name)
            if got is None:
                continue
            if c.hook and (got["hook"] != c.hook or got["type"] != c.kind or got["prio"] != c.priority or got["policy"] != c.policy):
                problems.append(f"chain {c.name}: hook/type/priority/policy mismatch ({got['hook']}/{got['type']}/{got['prio']}/{got['policy']})")
            exp = expected_comments(c)
            if got["comments"] != exp:
                problems.append(f"chain {c.name}: installed rule sequence differs from compiled ({len(got['comments'])} vs {len(exp)} rules)")
        if st.chains.get(META_CHAIN, {}).get("comments") != [meta_comment(ruleset)]:
            problems.append("metadata chain was modified")
        expected_sets = {s.name for s in ruleset.sets}
        if set(st.sets) != expected_sets:
            problems.append(f"sets {sorted(st.sets)} differ from expected {sorted(expected_sets)}")
        for s in ruleset.sets:
            if not s.dynamic and s.name in st.sets and st.sets[s.name] != _collapse(list(s.elements)):
                problems.append(f"set {s.name}: installed elements differ from compiled")
        if problems:
            raise VerificationError("; ".join(problems))
        return st

    # -- coexistence ---------------------------------------------------------------
    def conflicts(self) -> ConflictReport:
        rep = ConflictReport()
        res = self._nft(["-j", "list", "ruleset"], check=False)
        if res.returncode != 0:
            rep.notes.append(f"cannot list ruleset: {res.stderr.strip()[:500]}")
            return rep
        try:
            objs = json.loads(res.stdout)["nftables"]
        except (ValueError, KeyError):
            rep.notes.append("unparseable ruleset listing")
            return rep
        managers: set[str] = set()
        for o in objs:
            if "table" in o:
                name = o["table"]["name"]
                if name == "firewalld":
                    managers.add("firewalld (nftables table inet firewalld)")
            if "chain" in o:
                c = o["chain"]
                if c["table"] == self.table and c["family"] == FAMILY:
                    continue
                if c["name"].startswith("ufw"):
                    managers.add("ufw (iptables-nft chains ufw-*)")
                if c["name"].upper().startswith("DOCKER"):
                    managers.add("docker (iptables-nft DOCKER chains)")
                if "hook" in c:
                    rep.foreign_base_chains.append(
                        f"{c['family']} {c['table']} {c['name']} hook={c['hook']} prio={c.get('prio')} policy={c.get('policy', 'accept')}"
                    )
        rep.managers = sorted(managers)
        if rep.foreign_base_chains:
            rep.notes.append(
                "Other base chains are evaluated independently: a packet accepted by LONDON CIPHER can still be dropped by them."
            )
        return rep

    # -- dynamic sets ----------------------------------------------------------------
    def update_dynamic_set(self, ruleset: IRRuleset, irset: IRSet, elements: list[DynamicElement]) -> None:
        if not irset.dynamic:
            raise BackendError(f"set {irset.name} is not dynamic")
        ref = {"family": FAMILY, "table": self.table, "name": irset.name}
        cmds: list[dict] = [{"metainfo": {"json_schema_version": 1}}, {"flush": {"set": dict(ref)}}]
        elems = _dyn_elems(irset, elements)
        if elems:
            cmds.append({"add": {"element": dict(ref, elem=elems)}})
        self._submit(cmds)

    def read_dynamic_set(self, ruleset: IRRuleset, irset: IRSet) -> list[str]:
        res = self._nft(["-j", "list", "set", FAMILY, self.table, irset.name], check=False)
        if res.returncode != 0:
            raise BackendError(f"cannot list set {irset.name}: {res.stderr.strip()[:500]}")
        out: list[str] = []
        for o in json.loads(res.stdout)["nftables"]:
            if "set" in o:
                for e in o["set"].get("elem", []):
                    out.extend(_elem_to_networks(e))
        return _collapse(out)

    # -- connection tracking ----------------------------------------------------------
    def conntrack_delete(self, flt: ConntrackFilter) -> int:
        argv = ["conntrack", "-D", "-f", flt.family]
        if flt.source:
            argv += ["-s", str(ipaddress.ip_address(flt.source))]
        if flt.destination:
            argv += ["-d", str(ipaddress.ip_address(flt.destination))]
        if flt.protocol:
            if flt.protocol not in ("tcp", "udp"):
                raise BackendError("conntrack protocol must be tcp or udp")
            argv += ["-p", flt.protocol]
            if flt.dport:
                argv += ["--dport", str(int(flt.dport))]
        if len(argv) == 4:
            raise BackendError("refusing to flush the entire connection tracking table; give at least one selector")
        res = self.runner.run(argv, check=False)
        m = re.search(r"(\d+) flow entries have been deleted", res.stderr + res.stdout)
        if m:
            return int(m.group(1))
        if res.returncode != 0:
            raise BackendError(f"conntrack failed: {res.stderr.strip()[:500]}")
        return 0
