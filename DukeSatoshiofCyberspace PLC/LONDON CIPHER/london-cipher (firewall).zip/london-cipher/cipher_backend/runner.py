"""Bounded subprocess execution for enforcement tools.

Rules enforced here (and relied on by every backend):

* Commands are argument vectors; ``shell=True`` is never used, so no value
  from a policy can be interpreted by a shell.
* Executables are resolved once, against a fixed trusted ``PATH``, to absolute
  paths. Untrusted environment variables are not inherited.
* Every call has a timeout; output size is bounded.
* Structured payloads (nftables JSON) travel on stdin, never in argv.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from typing import Optional, Sequence

from cipher_types import BackendError

TRUSTED_PATH = "/usr/sbin:/usr/bin:/sbin:/bin"
MAX_OUTPUT = 64 * 1024 * 1024
NETNS_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")


@dataclass(frozen=True)
class Result:
    argv: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str


def resolve(tool: str) -> Optional[str]:
    """Absolute path of ``tool`` on the trusted PATH (or ``None``)."""
    if os.path.isabs(tool):
        return tool if os.access(tool, os.X_OK) else None
    return shutil.which(tool, path=TRUSTED_PATH)


def netns_prefix(name: str) -> tuple[str, ...]:
    """Argument prefix that runs a command inside a named network namespace.

    Used by the isolated laboratory and by deployments that manage a
    namespace rather than the host. The name is strictly validated.
    """
    if not NETNS_RE.match(name):
        raise ValueError(f"invalid network namespace name {name!r}")
    ip = resolve("ip")
    if ip is None:
        raise BackendError("'ip' (iproute2) is required for network namespace operation")
    return (ip, "netns", "exec", name)


class CommandRunner:
    def __init__(self, prefix: Sequence[str] = (), timeout: float = 30.0):
        self.prefix = tuple(prefix)
        self.timeout = timeout

    def run(self, argv: Sequence[str], *, stdin: Optional[str] = None, timeout: Optional[float] = None, check: bool = False) -> Result:
        if isinstance(argv, (str, bytes)) or not all(isinstance(a, str) for a in argv):
            raise TypeError("argv must be a sequence of str")
        for a in argv:
            if "\x00" in a:
                raise ValueError("NUL byte in argument")
        exe = resolve(argv[0])
        if exe is None:
            raise BackendError(f"required tool {argv[0]!r} not found on {TRUSTED_PATH}")
        full = self.prefix + (exe,) + tuple(argv[1:])
        env = {"PATH": TRUSTED_PATH, "LANG": "C", "LC_ALL": "C"}
        try:
            proc = subprocess.run(  # noqa: S603 - argv list, no shell
                full,
                input=stdin,
                capture_output=True,
                text=True,
                timeout=timeout or self.timeout,
                env=env,
                close_fds=True,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            raise BackendError(f"{argv[0]} timed out after {exc.timeout}s") from None
        except OSError as exc:
            raise BackendError(f"cannot execute {argv[0]}: {exc}") from None
        out, err = proc.stdout[:MAX_OUTPUT], proc.stderr[:MAX_OUTPUT]
        res = Result(full, proc.returncode, out, err)
        if check and proc.returncode != 0:
            raise BackendError(f"{argv[0]} failed (exit {proc.returncode}): {err.strip()[:2000]}")
        return res
