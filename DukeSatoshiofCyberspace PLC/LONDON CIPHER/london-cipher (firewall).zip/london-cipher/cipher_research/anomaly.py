"""Traffic anomaly analysis (research module; advisory only).

Scope and guarantees:

* **Not in the enforcement path.** This package imports nothing from the
  engine, backend or admin plane and has no way to change policy. Its output
  is an *advisory* report for humans.
* **Aggregated features, no payloads.** Inputs are firewall log events
  (header fields only) aggregated per source per time window.
* **Baseline model.** Robust z-scores (median / MAD) per feature, with the
  threshold calibrated on a later, time-separated validation slice to a
  target false-positive rate.
* **Time-separated validation.** Train, validation and test slices are split
  strictly by time; no window appears in two slices.
* **False-positive analysis, drift monitoring (PSI) and provenance** are part
  of every report.
* Results on synthetic data are labelled ``synthetic_data: true`` and say so:
  they show the pipeline works, not that it protects real networks.
"""

from __future__ import annotations

import hashlib
import json
import math
import platform
import random
import statistics
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable, Optional

FEATURES = ("events", "drops", "distinct_dports", "distinct_dsts", "drop_ratio")
VERSION = "cipher_research/0.1"
SYNTHETIC_WARNING = "Synthetic benchmark results demonstrate the pipeline only; they are not evidence of real-world protection."


@dataclass(frozen=True)
class Row:
    window_start: int
    source: str
    features: dict[str, float]
    label: Optional[int] = None  # 1 anomalous, 0 benign, None unknown


def _ts(v: Any) -> int:
    if isinstance(v, (int, float)):
        return int(v)
    return int(datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp())


def aggregate(events: Iterable[dict[str, Any]], window_seconds: int = 60) -> list[Row]:
    """Aggregate packet events (as produced by cipher_events.kernlog) per source and window."""
    buckets: dict[tuple[int, str], dict[str, Any]] = {}
    for ev in events:
        net = ev.get("network") or {}
        src = net.get("src")
        if not src:
            continue
        w = _ts(ev["timestamp"]) // window_seconds * window_seconds
        b = buckets.setdefault((w, src), {"events": 0, "drops": 0, "dports": set(), "dsts": set(), "labels": []})
        b["events"] += 1
        if ev.get("action") in ("drop", "reject"):
            b["drops"] += 1
        if "dport" in net:
            b["dports"].add(net["dport"])
        if "dst" in net:
            b["dsts"].add(net["dst"])
        if "label" in ev:
            b["labels"].append(int(ev["label"]))
    rows = []
    for (w, src), b in sorted(buckets.items()):
        f = {
            "events": float(b["events"]),
            "drops": float(b["drops"]),
            "distinct_dports": float(len(b["dports"])),
            "distinct_dsts": float(len(b["dsts"])),
            "drop_ratio": b["drops"] / b["events"],
        }
        rows.append(Row(w, src, f, max(b["labels"]) if b["labels"] else None))
    return rows


def time_split(rows: list[Row], train: float = 0.6, val: float = 0.2) -> tuple[list[Row], list[Row], list[Row]]:
    windows = sorted({r.window_start for r in rows})
    if len(windows) < 3:
        raise ValueError("need at least three distinct windows for a time-separated split")
    a = windows[max(1, int(len(windows) * train)) - 1]
    b = windows[max(int(len(windows) * (train + val)) - 1, windows.index(a) + 1)]
    tr = [r for r in rows if r.window_start <= a]
    va = [r for r in rows if a < r.window_start <= b]
    te = [r for r in rows if r.window_start > b]
    return tr, va, te


@dataclass
class RobustZModel:
    median: dict[str, float] = field(default_factory=dict)
    scale: dict[str, float] = field(default_factory=dict)
    threshold: float = math.inf
    target_fpr: float = 0.01

    def fit(self, rows: list[Row]) -> "RobustZModel":
        benign = [r for r in rows if r.label != 1]
        if len(benign) < 10:
            raise ValueError("at least 10 benign training rows required")
        for f in FEATURES:
            xs = [r.features[f] for r in benign]
            med = statistics.median(xs)
            mad = statistics.median(abs(x - med) for x in xs)
            self.median[f] = med
            self.scale[f] = 1.4826 * mad if mad > 0 else max(1e-3, statistics.pstdev(xs) or 1.0)
        return self

    def score(self, r: Row) -> tuple[float, str]:
        best, which = 0.0, FEATURES[0]
        for f in FEATURES:
            z = (r.features[f] - self.median[f]) / self.scale[f]  # one-sided: unusually high activity
            if z > best:
                best, which = z, f
        return best, which

    def calibrate(self, rows: list[Row]) -> float:
        benign = sorted(self.score(r)[0] for r in rows if r.label != 1)
        if not benign:
            raise ValueError("calibration slice has no benign rows")
        k = min(len(benign) - 1, math.ceil((1 - self.target_fpr) * len(benign)) - 1)
        self.threshold = benign[max(0, k)] + 1e-9
        return self.threshold


def psi(expected: list[float], actual: list[float], bins: int = 10) -> float:
    """Population Stability Index of ``actual`` against ``expected`` (quantile bins)."""
    if not expected or not actual:
        return 0.0
    qs = sorted(expected)
    edges = sorted({qs[min(len(qs) - 1, int(i * len(qs) / bins))] for i in range(1, bins)})

    def hist(xs):
        counts = [0] * (len(edges) + 1)
        for x in xs:
            i = 0
            while i < len(edges) and x > edges[i]:
                i += 1
            counts[i] += 1
        return [max(c / len(xs), 1e-4) for c in counts]

    e, a = hist(expected), hist(actual)
    return sum((ai - ei) * math.log(ai / ei) for ei, ai in zip(e, a))


def drift_report(train: list[Row], recent: list[Row]) -> dict[str, Any]:
    out = {}
    for f in FEATURES:
        v = psi([r.features[f] for r in train], [r.features[f] for r in recent])
        out[f] = {"psi": round(v, 4), "status": "stable" if v < 0.1 else "moderate" if v < 0.25 else "significant"}
    return out


def dataset_digest(rows: list[Row]) -> str:
    blob = json.dumps([asdict(r) for r in rows], sort_keys=True).encode()
    return hashlib.sha256(blob).hexdigest()


def evaluate(rows: list[Row], *, target_fpr: float = 0.01, synthetic: bool, train_frac: float = 0.6, val_frac: float = 0.2) -> dict[str, Any]:
    tr, va, te = time_split(rows, train_frac, val_frac)
    model = RobustZModel(target_fpr=target_fpr).fit(tr)
    model.calibrate(va)
    tp = fp = tn = fn = 0
    false_pos = []
    for r in te:
        s, feat = model.score(r)
        pred = int(s >= model.threshold)
        if r.label is None:
            continue
        if pred and r.label:
            tp += 1
        elif pred and not r.label:
            fp += 1
            false_pos.append({"window_start": r.window_start, "source": r.source, "score": round(s, 3), "feature": feat, "features": r.features})
        elif not pred and r.label:
            fn += 1
        else:
            tn += 1
    fpr = fp / (fp + tn) if fp + tn else 0.0
    tpr = tp / (tp + fn) if tp + fn else 0.0
    prec = tp / (tp + fp) if tp + fp else 0.0
    report = {
        "advisory_only": True,
        "synthetic_data": synthetic,
        "model": {"type": "robust-z (median/MAD), one-sided", "threshold": round(model.threshold, 4), "target_fpr": target_fpr, "median": model.median, "scale": model.scale},
        "split": {
            "train": [tr[0].window_start, tr[-1].window_start, len(tr)],
            "validation": [va[0].window_start, va[-1].window_start, len(va)] if va else [None, None, 0],
            "test": [te[0].window_start, te[-1].window_start, len(te)] if te else [None, None, 0],
        },
        "metrics": {"tp": tp, "fp": fp, "tn": tn, "fn": fn, "tpr": round(tpr, 4), "fpr": round(fpr, 4), "precision": round(prec, 4)},
        "false_positive_analysis": {"count": fp, "top": sorted(false_pos, key=lambda x: -x["score"])[:10], "by_feature": _count_by(false_pos, "feature")},
        "drift": drift_report(tr, te),
        "provenance": {
            "dataset_sha256": dataset_digest(rows),
            "rows": len(rows),
            "code_version": VERSION,
            "python": platform.python_version(),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "parameters": {"train_frac": train_frac, "val_frac": val_frac, "target_fpr": target_fpr},
        },
    }
    if synthetic:
        report["warning"] = SYNTHETIC_WARNING
    return report


def _count_by(items: list[dict], key: str) -> dict[str, int]:
    out: dict[str, int] = {}
    for i in items:
        out[i[key]] = out.get(i[key], 0) + 1
    return out


def advisories(model: RobustZModel, rows: list[Row]) -> list[dict[str, Any]]:
    """Advisory findings for humans. Never actionable by the enforcement path."""
    out = []
    for r in rows:
        s, feat = model.score(r)
        if s >= model.threshold:
            out.append({"advisory": True, "source": r.source, "window_start": r.window_start, "score": round(s, 3), "dominant_feature": feat, "note": "statistical outlier versus baseline; requires human review"})
    return out


def synthesize(seed: int = 7, hours: int = 24, sources: int = 40, scan_rate: float = 0.02) -> list[dict[str, Any]]:
    """Deterministic SYNTHETIC event stream with labelled port-scan windows."""
    rng = random.Random(seed)
    t0 = 1_780_000_000
    events = []
    common = [22, 53, 80, 123, 443, 8080]
    for minute in range(hours * 60):
        base = t0 + minute * 60
        for s in range(sources):
            src = f"10.50.{s // 250}.{s % 250 + 1}"
            scanning = rng.random() < scan_rate
            n = rng.randint(1, 6)
            for _ in range(n):
                events.append({"timestamp": base + rng.randint(0, 59), "action": "drop" if rng.random() < 0.15 else "accept", "network": {"src": src, "dst": "10.50.255.1", "dport": rng.choice(common)}, "label": 0})
            if scanning:
                for p in rng.sample(range(1, 65535), rng.randint(20, 120)):
                    events.append({"timestamp": base + rng.randint(0, 59), "action": "drop", "network": {"src": src, "dst": f"10.50.255.{rng.randint(1, 20)}", "dport": p}, "label": 1})
    return events
