"""Optional research module: traffic anomaly analysis (advisory only, never enforcing)."""

from .anomaly import FEATURES, RobustZModel, Row, advisories, aggregate, drift_report, evaluate, psi, synthesize, time_split

__all__ = ["FEATURES", "RobustZModel", "Row", "advisories", "aggregate", "drift_report", "evaluate", "psi", "synthesize", "time_split"]
