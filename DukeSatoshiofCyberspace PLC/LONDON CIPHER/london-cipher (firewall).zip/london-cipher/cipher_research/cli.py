"""``cipher-research`` — reproducible anomaly-analysis experiments (advisory only).

    cipher-research synthesize --out events.jsonl [--seed 7]
    cipher-research evaluate --events events.jsonl [--synthetic] --report report.json
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Optional

from .anomaly import aggregate, evaluate, synthesize


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="cipher-research")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("synthesize")
    p.add_argument("--out", required=True)
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--hours", type=int, default=24)
    p = sub.add_parser("evaluate")
    p.add_argument("--events", required=True)
    p.add_argument("--synthetic", action="store_true", help="input is synthetic (labels the report)")
    p.add_argument("--window", type=int, default=60)
    p.add_argument("--target-fpr", type=float, default=0.01)
    p.add_argument("--report", required=True)
    a = ap.parse_args(argv)
    if a.cmd == "synthesize":
        with open(a.out, "w") as fh:
            for ev in synthesize(seed=a.seed, hours=a.hours):
                fh.write(json.dumps(ev) + "\n")
        return 0
    with open(a.events) as fh:
        events = [json.loads(line) for line in fh if line.strip()]
    rep = evaluate(aggregate(events, a.window), target_fpr=a.target_fpr, synthetic=a.synthetic)
    with open(a.report, "w") as fh:
        json.dump(rep, fh, indent=1, default=str)
    print(json.dumps(rep["metrics"]))
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
