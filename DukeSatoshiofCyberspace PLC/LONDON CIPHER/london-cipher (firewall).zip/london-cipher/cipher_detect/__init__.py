"""Optional detection integrations (alert ingestion -> proposals -> approved enforcement).

The four stages are deliberately separate objects:

1. **Alert ingestion** (:func:`parse_eve_line`) — Suricata EVE JSON alerts.
2. **Detection confidence** (:func:`confidence_of`) — derived from the
   detector's own severity; LONDON CIPHER does not detect anything itself.
3. **Proposed response** (:class:`Proposal`) — "block source X for T seconds".
4. **Approved enforcement change** (:class:`ResponseManager`) — only proposals
   approved by an operator, or by an explicitly enabled, bounded auto-block
   policy, change a detection-sourced dynamic set. Blocks expire; every block
   can be revoked; all blocks can be rolled back at once.

The default mode is ``alert-only``. Basic packet filtering does not detect
malware, intrusions or zero-days; any such claim belongs to the upstream
detector and its rules, not to this firewall.
"""

from .response import AutoBlockPolicy, Proposal, ResponseManager, confidence_of, parse_eve_line

__all__ = ["AutoBlockPolicy", "Proposal", "ResponseManager", "confidence_of", "parse_eve_line"]
