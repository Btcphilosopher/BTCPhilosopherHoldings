"""Suricata EVE alert ingestion and bounded, reversible responses."""

from __future__ import annotations

import ipaddress
import json
import time
from collections import deque
from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Optional

from cipher_intel.submit import Submitter

MAX_LINE = 64 * 1024
CONFIDENCE = {1: 0.9, 2: 0.6, 3: 0.3}  # Suricata severity 1 (highest) .. 3


@dataclass(frozen=True)
class Alert:
    timestamp: str
    src_ip: str
    dest_ip: str
    proto: str
    signature_id: int
    signature: str
    severity: int
    dest_port: Optional[int] = None


def parse_eve_line(line: str) -> Optional[Alert]:
    """Parse one EVE JSON line; returns None for non-alerts or malformed input."""
    if len(line) > MAX_LINE:
        return None
    try:
        ev = json.loads(line)
    except ValueError:
        return None
    if not isinstance(ev, dict) or ev.get("event_type") != "alert" or not isinstance(ev.get("alert"), dict):
        return None
    try:
        a = ev["alert"]
        src = str(ipaddress.ip_address(ev["src_ip"]))
        dst = str(ipaddress.ip_address(ev["dest_ip"]))
        sev = int(a.get("severity", 3))
        return Alert(str(ev.get("timestamp", "")), src, dst, str(ev.get("proto", "")).lower(), int(a.get("signature_id", 0)), str(a.get("signature", ""))[:256], max(1, min(sev, 3)), ev.get("dest_port"))
    except (KeyError, ValueError, TypeError):
        return None


def confidence_of(alert: Alert) -> float:
    """Confidence is the *detector's* severity mapped to [0,1]; not attribution."""
    return CONFIDENCE.get(alert.severity, 0.3)


@dataclass
class Proposal:
    id: int
    address: str
    reason: str
    confidence: float
    ttl_seconds: int
    created_at: float
    alerts: list[int] = field(default_factory=list)
    status: str = "proposed"  # proposed | approved | auto-approved | rejected | revoked | expired | suppressed


@dataclass
class AutoBlockPolicy:
    """Explicitly enabled, bounded automatic blocking. Disabled by default."""

    enabled: bool = False
    min_confidence: float = 0.9
    ttl_seconds: int = 3600
    max_active_blocks: int = 100
    max_new_blocks_per_hour: int = 20
    allowlist: list[str] = field(default_factory=list)  # never blocked (management, resolvers, gateways)

    def __post_init__(self) -> None:
        if not (60 <= self.ttl_seconds <= 7 * 86400):
            raise ValueError("auto-block ttl must be between 60 s and 7 days (blocks must expire)")
        if not (1 <= self.max_active_blocks <= 10_000):
            raise ValueError("max_active_blocks out of range")


class ResponseManager:
    def __init__(self, set_name: str, submit: Optional[Submitter], policy: Optional[AutoBlockPolicy] = None, clock: Callable[[], float] = time.time, proposal_ttl: int = 3600):
        self.set_name = set_name
        self.submit = submit
        self.policy = policy or AutoBlockPolicy()
        self.clock = clock
        self.proposal_ttl = proposal_ttl
        self.proposals: dict[int, Proposal] = {}
        self.active: dict[str, float] = {}  # address -> expires_at
        self.recent_blocks: deque[float] = deque()
        self._next = 1
        self.alert_count = 0
        self.log: list[dict[str, Any]] = []
        self._allow = [ipaddress.ip_network(a, strict=False) for a in self.policy.allowlist]

    @property
    def mode(self) -> str:
        return "auto-block" if self.policy.enabled and self.submit is not None else "alert-only"

    def _allowlisted(self, addr: str) -> bool:
        ip = ipaddress.ip_address(addr)
        return any(ip in n for n in self._allow)

    def ingest(self, alert: Alert) -> Proposal:
        self.alert_count += 1
        now = self.clock()
        conf = confidence_of(alert)
        for p in self.proposals.values():
            if p.address == alert.src_ip and p.status == "proposed":
                p.alerts.append(alert.signature_id)
                p.confidence = max(p.confidence, conf)
                return self._maybe_auto(p)
        p = Proposal(self._next, alert.src_ip, f"sid {alert.signature_id}: {alert.signature}", conf, self.policy.ttl_seconds, now, [alert.signature_id])
        self._next += 1
        if self._allowlisted(p.address):
            p.status = "suppressed"
        self.proposals[p.id] = p
        return self._maybe_auto(p)

    def _maybe_auto(self, p: Proposal) -> Proposal:
        if self.mode != "auto-block" or p.status != "proposed" or p.confidence < self.policy.min_confidence:
            return p
        now = self.clock()
        while self.recent_blocks and now - self.recent_blocks[0] > 3600:
            self.recent_blocks.popleft()
        if len(self.recent_blocks) >= self.policy.max_new_blocks_per_hour:
            self.log.append({"proposal": p.id, "auto": "skipped", "reason": "hourly auto-block budget exhausted"})
            return p
        if len(self.active) >= self.policy.max_active_blocks and p.address not in self.active:
            self.log.append({"proposal": p.id, "auto": "skipped", "reason": "max_active_blocks reached"})
            return p
        self._enforce(p, "auto-approved", actor="system:auto-block")
        return p

    def approve(self, proposal_id: int, actor: str) -> Proposal:
        p = self.proposals[proposal_id]
        if p.status != "proposed":
            raise ValueError(f"proposal {proposal_id} is {p.status}")
        if self.submit is None:
            raise ValueError("no enforcement submitter configured (alert-only deployment)")
        if self._allowlisted(p.address):
            raise ValueError("address is allowlisted")
        if len(self.active) >= self.policy.max_active_blocks and p.address not in self.active:
            raise ValueError("max_active_blocks reached")
        self._enforce(p, "approved", actor=actor)
        return p

    def reject(self, proposal_id: int, actor: str) -> Proposal:
        p = self.proposals[proposal_id]
        p.status = "rejected"
        self.log.append({"proposal": p.id, "rejected_by": actor})
        return p

    def _enforce(self, p: Proposal, status: str, actor: str) -> None:
        now = self.clock()
        self.active[p.address] = now + p.ttl_seconds
        self._publish(actor, {"proposal": p.id, "reason": p.reason, "confidence": p.confidence})
        p.status = status
        self.recent_blocks.append(now)

    def _publish(self, actor: str, why: dict[str, Any]) -> None:
        now = self.clock()
        self.active = {a: e for a, e in self.active.items() if e > now}
        addrs = sorted(self.active)
        ttls = [max(1, int(self.active[a] - now)) for a in addrs]
        assert self.submit is not None
        self.submit(self.set_name, addrs, source="detection", provenance=dict(why, actor=actor, mode=self.mode), element_ttls=ttls)
        self.log.append(dict(why, actor=actor, active=len(addrs)))

    def revoke(self, address: str, actor: str) -> None:
        if address in self.active:
            del self.active[address]
            self._publish(actor, {"revoked": address})
            for p in self.proposals.values():
                if p.address == address and p.status in ("approved", "auto-approved"):
                    p.status = "revoked"

    def rollback_all(self, actor: str) -> None:
        self.active.clear()
        self._publish(actor, {"rollback": "all"})
        for p in self.proposals.values():
            if p.status in ("approved", "auto-approved"):
                p.status = "revoked"

    def expire(self) -> list[str]:
        now = self.clock()
        gone = [a for a, e in self.active.items() if e <= now]
        for a in gone:
            del self.active[a]
        for p in self.proposals.values():
            if p.status == "proposed" and now - p.created_at > self.proposal_ttl:
                p.status = "expired"
        return gone

    def summary(self) -> dict[str, Any]:
        return {
            "mode": self.mode,
            "alerts": self.alert_count,
            "active_blocks": len(self.active),
            "proposals": [asdict(p) for p in self.proposals.values()],
        }
