"""DNS sets, threat feeds, detection responses (local fixtures only; no network)."""

import os

import pytest
import yaml

from cipher_detect import AutoBlockPolicy, ResponseManager, parse_eve_line
from cipher_intel import DnsSetConfig, DnsSetUpdater, EngineSubmitter, FeedConfig, FeedError, FeedManager
from cipher_intel.dnsclient import DnsError, build_query, local_test_resolver, parse_response, resolve
from tests.conftest import policy_dict

FIX = os.path.join(os.path.dirname(os.path.dirname(__file__)), "fixtures")


class Recorder:
    def __init__(self):
        self.calls = []

    def __call__(self, name, values, *, source, provenance, ttl_seconds=None, element_ttls=None):
        self.calls.append({"name": name, "values": list(values), "source": source, "provenance": provenance, "element_ttls": element_ttls})
        return {"count": len(values)}


# -- DNS --------------------------------------------------------------------------


def test_dns_client_against_local_resolver():
    port, stop = local_test_resolver({("svc.example.test", "A"): [("192.0.2.10", 300), ("192.0.2.11", 60)]})
    try:
        ans = resolve("127.0.0.1", "svc.example.test", "ipv4", port=port)
        assert sorted((a.address, a.ttl) for a in ans) == [("192.0.2.10", 300), ("192.0.2.11", 60)]
        assert resolve("127.0.0.1", "missing.example.test", "ipv4", port=port) == []
    finally:
        stop()


def test_dns_response_validation():
    q = build_query("a.test", "A", 1234)
    from cipher_intel.dnsclient import build_response

    resp = build_response(q, [("192.0.2.1", 5)])
    with pytest.raises(DnsError):
        parse_response(resp, 999, "a.test", "A")  # id mismatch
    with pytest.raises(DnsError):
        parse_response(resp, 1234, "b.test", "A")  # question mismatch
    loop = bytearray(resp)
    loop[12:14] = b"\xc0\x0c"  # self-referential pointer
    with pytest.raises(DnsError):
        parse_response(bytes(loop), 1234, "a.test", "A")
    with pytest.raises(DnsError):
        build_query("x" * 300, "A", 1)


def test_dns_set_updater_records_and_failure_behaviour():
    clock = {"t": 1000.0}
    rec = Recorder()
    port, stop = local_test_resolver({("svc.example.test", "A"): [("192.0.2.10", 120)]})
    try:
        cfg = DnsSetConfig("upd", "ipv4", ["svc.example.test"], "127.0.0.1", resolver_port=port, min_ttl=30, max_ttl=600, max_stale=100, stale_action="empty")
        u = DnsSetUpdater(cfg, rec, clock=lambda: clock["t"])
        r = u.refresh()
        assert r["status"] == "updated" and r["addresses"] == ["192.0.2.10"] and r["ttl"] == 120
        assert r["resolver"] == f"127.0.0.1:{port}" and r["resolved_at"] == 1000.0
        assert rec.calls[-1]["provenance"]["ttl"] == 120
        assert not u.due()
        clock["t"] += 121
        assert u.due() and u.refresh()["status"] == "unchanged"
        assert len(rec.calls) == 1
    finally:
        stop()
    # resolver unreachable: keep previous within max_stale, then fail closed
    def unreachable(*a, **k):
        raise DnsError("resolver 127.0.0.1 timed out")

    u.resolve = unreachable
    clock["t"] += 10
    assert u.refresh()["status"] == "failed-kept-previous"
    clock["t"] += 500
    assert u.refresh()["status"] == "failed-emptied"
    assert rec.calls[-1]["values"] == []


# -- Feeds ---------------------------------------------------------------------------


def feed_cfg(path, **kw):
    return FeedConfig(name="rep", set_name="rep4", family="ipv4", url=f"file://{path}", **kw)


def test_feed_stage_activate_rollback(tmp_path):
    rec = Recorder()
    mgr = FeedManager(feed_cfg(os.path.join(FIX, "feed-basic.txt"), allowlist=["203.0.113.128/25"]), str(tmp_path), rec)
    st = mgr.stage()
    assert st["stats"]["other_family"] == 1 and st["stats"]["allowlist_removed"] == 1
    assert rec.calls == []  # staging never changes enforcement
    v1 = mgr.versions()[-1]
    out = mgr.activate()
    entries = rec.calls[-1]["values"]
    assert "203.0.113.0/25" in entries and not any(e.startswith("203.0.113.128") for e in entries)
    assert "198.51.100.0/28" in entries and "198.51.100.7/32" not in entries  # collapsed
    assert rec.calls[-1]["source"] == "feed" and rec.calls[-1]["provenance"]["sha256"]
    assert out["activated"] == v1
    import time

    time.sleep(0.002)
    mgr.cfg.url = f"file://{os.path.join(FIX, 'feed.csv')}"
    mgr.cfg.format = "csv"
    mgr.stage()
    mgr.activate()
    assert sorted(rec.calls[-1]["values"]) == ["192.0.2.77/32", "198.51.100.9/32"]
    mgr.rollback()
    assert rec.calls[-1]["values"] == entries


def test_feed_rejections(tmp_path):
    rec = Recorder()
    with pytest.raises(FeedError):
        FeedManager(feed_cfg(os.path.join(FIX, "feed-malformed.txt")), str(tmp_path), rec).stage()
    with pytest.raises(FeedError):
        FeedManager(feed_cfg(os.path.join(FIX, "feed-basic.txt"), sha256="0" * 64), str(tmp_path), rec).stage()
    with pytest.raises(FeedError):
        FeedManager(feed_cfg(os.path.join(FIX, "feed-basic.txt"), max_entries=2), str(tmp_path), rec).stage()
    with pytest.raises(FeedError):
        FeedManager(feed_cfg(os.path.join(FIX, "feed-basic.txt"), max_bytes=10), str(tmp_path), rec).stage()
    with pytest.raises(ValueError):
        FeedConfig(name="x", set_name="y", family="ipv4", url="http://insecure.example/feed")
    assert rec.calls == []


def test_feed_growth_limit(tmp_path):
    small = tmp_path / "small.txt"
    small.write_text("\n".join(f"198.51.100.{i}" for i in range(1, 5)))
    big = tmp_path / "big.txt"
    big.write_text("\n".join(f"10.{i // 256}.{i % 256}.1" for i in range(500)))
    rec = Recorder()
    mgr = FeedManager(feed_cfg(small, min_growth_floor=10), str(tmp_path / "store"), rec)
    mgr.stage()
    mgr.activate()
    mgr.cfg.url = f"file://{big}"
    with pytest.raises(FeedError) as e:
        mgr.stage()
    assert "grew" in str(e.value)


def test_feed_hmac_and_expiry(tmp_path):
    import hashlib
    import hmac

    data = open(os.path.join(FIX, "feed-basic.txt"), "rb").read()
    key = tmp_path / "k"
    key.write_bytes(b"secret-key")
    sig = tmp_path / "sig"
    sig.write_text(hmac.new(b"secret-key", data, hashlib.sha256).hexdigest())
    clock = {"t": 1000.0}
    rec = Recorder()
    cfg = feed_cfg(os.path.join(FIX, "feed-basic.txt"), hmac_key_file=str(key), hmac_signature_url=f"file://{sig}", max_age_seconds=100)
    mgr = FeedManager(cfg, str(tmp_path / "s"), rec, clock=lambda: clock["t"])
    assert "hmac-sha256" in mgr.stage()["auth"]["methods"]
    mgr.activate()
    clock["t"] += 200
    assert mgr.expire_if_stale()["expired"]
    assert rec.calls[-1]["values"] == []
    sig.write_text("0" * 64)
    with pytest.raises(FeedError):
        mgr.stage()


def test_feed_into_engine_bounded(make_engine, tmp_path):
    eng, be = make_engine()
    d = policy_dict(
        dynamic_sets={"rep4": {"family": "ipv4", "source": "feed", "max_elements": 4}},
        rules=[{"id": "rep-drop", "chain": "input", "action": "drop", "family": "ipv4", "source": {"sets": ["rep4"]}, "justification": "reputation"}],
    )
    eng.apply(yaml.safe_dump(d), actor="t")
    mgr = FeedManager(feed_cfg(os.path.join(FIX, "feed-basic.txt")), str(tmp_path / "f"), EngineSubmitter(eng, "system:feed"))
    mgr.stage()
    mgr.activate()
    assert be._state["dynamic"]["dyn_rep4"]
    audit = [r for r in eng.audit.records() if r["action"] == "dynamic_set"]
    assert audit[-1]["details"]["provenance"]["feed"] == "rep"


# -- Detection -------------------------------------------------------------------------


def alerts():
    with open(os.path.join(FIX, "eve-alerts.jsonl")) as fh:
        return [a for a in (parse_eve_line(line) for line in fh) if a]


def test_eve_parsing():
    al = alerts()
    assert [a.src_ip for a in al] == ["203.0.113.50", "198.51.100.20", "10.77.0.10"]
    assert al[0].severity == 1 and al[0].dest_port == 22


def test_alert_only_by_default():
    rm = ResponseManager("blk", submit=None)
    for a in alerts():
        rm.ingest(a)
    assert rm.mode == "alert-only" and not rm.active
    assert {p.status for p in rm.proposals.values()} == {"proposed"}


def test_auto_block_bounded_and_reversible():
    clock = {"t": 0.0}
    rec = Recorder()
    pol = AutoBlockPolicy(enabled=True, min_confidence=0.9, ttl_seconds=600, max_active_blocks=5, max_new_blocks_per_hour=1, allowlist=["10.77.0.0/24"])
    rm = ResponseManager("blk", rec, pol, clock=lambda: clock["t"])
    ps = [rm.ingest(a) for a in alerts()]
    assert ps[0].status == "auto-approved"  # high severity scanner
    assert ps[1].status == "proposed"  # low confidence: proposal only
    assert ps[2].status == "suppressed"  # management network never auto-blocked
    assert rec.calls[-1]["values"] == ["203.0.113.50"] and rec.calls[-1]["element_ttls"] == [600]
    # hourly budget: a second high-confidence source is not auto-blocked
    from cipher_detect.response import Alert

    p = rm.ingest(Alert("t", "203.0.113.51", "10.77.0.1", "tcp", 1, "x", 1))
    assert p.status == "proposed"
    rm.approve(p.id, actor="uid:1000(alice)")
    assert sorted(rec.calls[-1]["values"]) == ["203.0.113.50", "203.0.113.51"]
    rm.revoke("203.0.113.50", actor="alice")
    assert rec.calls[-1]["values"] == ["203.0.113.51"]
    clock["t"] += 601
    assert rm.expire() == ["203.0.113.51"]
    rm.rollback_all("alice")
    assert rec.calls[-1]["values"] == []
    with pytest.raises(ValueError):
        AutoBlockPolicy(enabled=True, ttl_seconds=0)


def test_detection_set_in_engine_uses_timeouts(make_engine):
    eng, be = make_engine()
    d = policy_dict(
        dynamic_sets={"blk": {"family": "ipv4", "source": "detection", "max_elements": 10, "timeout_seconds": 300}},
        rules=[{"id": "blk-drop", "chain": "input", "action": "drop", "family": "ipv4", "source": {"sets": ["blk"]}, "justification": "detections"}],
    )
    eng.apply(yaml.safe_dump(d), actor="t")
    out = eng.update_dynamic_set("blk", ["203.0.113.50"], source="detection", actor="t", provenance={}, element_ttls=[99999])
    assert out["count"] == 1
    stored = eng.store.read_dynamic("blk")
    assert stored["elements"][0]["expires_at"] - eng.clock() == 300  # capped by policy
    from cipher_types import StateError

    with pytest.raises(StateError):
        eng.update_dynamic_set("blk", ["203.0.113.0/24"], source="detection", actor="t", provenance={}, ttl_seconds=10)
    with pytest.raises(StateError):
        eng.update_dynamic_set("blk", ["203.0.113.9"], source="detection", actor="t", provenance={})
