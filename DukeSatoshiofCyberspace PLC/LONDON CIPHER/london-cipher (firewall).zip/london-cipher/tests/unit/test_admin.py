"""Admin plane: schemas, roles, socket round trips, privilege boundaries."""

import os
import threading

import pytest

from cipher_admin.admind import AdminDaemon
from cipher_admin.authz import PeerCredentials, RoleMap
from cipher_admin.client import AdminClient, RemoteError
from cipher_admin.config import AdminConfig, HelperConfig
from cipher_admin.helper import Helper
from cipher_admin.schema import validate_args
from cipher_types import AuthorizationError, LimitExceeded, ProtocolError
from tests.conftest import policy_text


def test_schema_rejects_unknown_and_bad_types():
    with pytest.raises(ProtocolError):
        validate_args("apply", {"policy_text": "x", "shell": "rm -rf /"})
    with pytest.raises(ProtocolError):
        validate_args("apply", {"policy_text": 5})
    with pytest.raises(ProtocolError):
        validate_args("apply", {"policy_text": "x", "confirm_timeout": True})
    with pytest.raises(ProtocolError):
        validate_args("nft_raw", {})
    with pytest.raises(ProtocolError):
        validate_args("conntrack_delete", {"family": "ipv4", "reason": "r", "protocol": "icmp"})
    with pytest.raises(ProtocolError):
        validate_args("dynamic_set_update", {"name": "Bad Name", "values": [], "source": "dns", "provenance": {}})
    with pytest.raises(ProtocolError):
        validate_args("status", {"actor": "root; drop table"})
    assert validate_args("apply", {"policy_text": "x", "confirm_timeout": 30})


def test_role_map():
    rm = RoleMap.from_config({"roles": {"viewer": {"users": [1001]}, "operator": {"users": [1002]}, "admin": {"users": [1003]}}})
    v, o, a, n = (PeerCredentials(1, u, 60000) for u in (1001, 1002, 1003, 1004))
    assert rm.authorize(v, "status") == "viewer"
    with pytest.raises(AuthorizationError):
        rm.authorize(v, "apply")
    assert rm.authorize(o, "apply") == "operator"
    with pytest.raises(AuthorizationError):
        rm.authorize(o, "conntrack_delete")
    assert rm.authorize(a, "conntrack_delete") == "admin"
    with pytest.raises(AuthorizationError):
        rm.authorize(n, "status")
    assert rm.authorize(PeerCredentials(1, 0, 0), "remove") == "admin"
    with pytest.raises(AuthorizationError):
        rm.authorize(a, "exec_shell")


def test_config_validation(tmp_path):
    with pytest.raises(ValueError):
        AdminConfig.load(None, socket_mode=0o666)
    p = tmp_path / "h.yaml"
    p.write_text("state_dir: /tmp/x\nunknown: 1\n")
    with pytest.raises(ValueError):
        HelperConfig.load(str(p))


@pytest.fixture
def helper_stack(tmp_path, make_engine):
    eng, be = make_engine()
    cfg = HelperConfig(state_dir=str(tmp_path / "state"), socket=str(tmp_path / "helper.sock"), allowed_uids=[os.getuid()], delegate_uids=[], tick_interval=0.1)
    h = Helper(eng, cfg)
    h.server.start()
    yield h, eng, be, cfg
    h.server.stop()


def test_helper_socket_round_trip(helper_stack):
    h, eng, be, cfg = helper_stack
    c = AdminClient(cfg.socket)
    assert c.call("ping") == {"pong": True}
    plan = c.call("plan", policy_text=policy_text())
    assert plan["revision"] == 1 and "listing" in plan
    res = c.call("apply", policy_text=policy_text())
    assert res["status"] == "active"
    assert c.call("status")["state"] == "active"
    with pytest.raises(RemoteError) as e:
        c.call("apply", policy_text="not: [valid")
    assert e.value.code == "policy.invalid"
    with pytest.raises(RemoteError) as e:
        c.call("apply", policy_text=policy_text(), shell="x")
    assert e.value.code == "admin.protocol"
    assert (os.stat(cfg.socket).st_mode & 0o777) == 0o600


def test_helper_rejects_unlisted_uid(helper_stack):
    h, eng, be, cfg = helper_stack
    with pytest.raises(AuthorizationError):
        h.handle(PeerCredentials(1, 4242, 4242), {"op": "status", "args": {}, "request_id": ""})


def test_helper_actor_only_trusted_from_delegate(helper_stack):
    h, eng, be, cfg = helper_stack
    cfg.allowed_uids = [0]
    cfg.delegate_uids = [999]
    assert h._actor(PeerCredentials(1, 999, 999), {"actor": "uid:1000(alice)"}).startswith("uid:1000(alice) via uid:999")
    assert h._actor(PeerCredentials(1, 0, 0), {"actor": "uid:1000(alice)"}).startswith("uid:0")


class FakeHelper:
    def __init__(self):
        self.calls = []

    def call(self, op, **args):
        self.calls.append((op, args))
        return {"ok": op}


def test_admind_authorizes_audits_and_forwards(tmp_path):
    cfg = AdminConfig(socket=str(tmp_path / "admin.sock"), socket_group=None, audit_log=str(tmp_path / "admin.jsonl"), requests_per_minute=60, burst=3)
    rm = RoleMap.from_config({"roles": {"viewer": {"users": [2001]}, "operator": {"users": [2002]}}})
    fh = FakeHelper()
    d = AdminDaemon(cfg, roles=rm, helper=fh)
    viewer, op = PeerCredentials(1, 2001, 2001), PeerCredentials(1, 2002, 2002)
    assert d.handle(viewer, {"op": "status", "args": {}, "request_id": "r1"}) == {"ok": "status"}
    with pytest.raises(AuthorizationError):
        d.handle(viewer, {"op": "apply", "args": {"policy_text": "x"}, "request_id": "r2"})
    with pytest.raises(AuthorizationError):
        d.handle(op, {"op": "apply", "args": {"policy_text": "x", "actor": "uid:0(root)"}, "request_id": "r3"})
    d.handle(op, {"op": "apply", "args": {"policy_text": "x"}, "request_id": "r4"})
    assert fh.calls[-1] == ("apply", {"actor": "uid:2002(2002)", "policy_text": "x"}) or fh.calls[-1][1]["actor"].startswith("uid:2002(")
    with pytest.raises(LimitExceeded):
        for _ in range(10):
            d.handle(op, {"op": "status", "args": {}, "request_id": "x"})
    outcomes = [r["outcome"] for r in d.audit.records()]
    assert "denied" in outcomes and "allowed" in outcomes and "rate-limited" in outcomes


def test_server_bounded_concurrency(tmp_path):
    from cipher_admin.server import UnixJsonServer

    gate = threading.Event()

    def slow(creds, req):
        gate.wait(5)
        return "done"

    srv = UnixJsonServer(str(tmp_path / "s.sock"), slow, max_concurrent=1)
    srv.start()
    try:
        t = threading.Thread(target=lambda: AdminClient(srv.path).call("ping"))
        t.start()
        import time

        time.sleep(0.3)
        with pytest.raises(RemoteError) as e:
            AdminClient(srv.path, timeout=5).call("ping")
        assert e.value.code == "busy"
        gate.set()
        t.join()
    finally:
        srv.stop()


def test_server_refuses_to_replace_non_socket(tmp_path):
    from cipher_admin.server import UnixJsonServer

    p = tmp_path / "file"
    p.write_text("important")
    with pytest.raises(RuntimeError):
        UnixJsonServer(str(p), lambda c, r: None).bind()
    assert p.read_text() == "important"
