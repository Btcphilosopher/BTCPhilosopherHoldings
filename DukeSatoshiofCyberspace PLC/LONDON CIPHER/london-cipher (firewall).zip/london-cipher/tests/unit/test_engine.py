"""Safe-deployment engine tests (memory backend; packet outcomes are lab tests)."""

import json
import os
import subprocess
import sys
import textwrap

import pytest

from cipher_backend import ConflictReport, ConntrackFilter, MemoryBackend
from cipher_events import verify_chain
from cipher_state import Engine, StateStore
from cipher_types import BackendError, ConflictError, LimitExceeded, PolicyError, StateError
from tests.conftest import ROOT, policy_dict, policy_text


def rev(n, **kw):
    d = policy_dict(**kw)
    d["policy"]["revision"] = n
    return d


def text_of(d):
    import yaml

    return yaml.safe_dump(d, sort_keys=False)


def test_apply_reports_active_only_after_verification(make_engine):
    eng, be = make_engine()
    res = eng.apply(policy_text(), actor="test")
    assert res["status"] == "active" and res["revision"] == 1
    st = eng.status()
    assert st["state"] == "active" and st["lkg"]["revision"] == 1
    assert be.apply_count == 1


def test_syntax_rejection_changes_nothing(make_engine):
    eng, be = make_engine()
    eng.apply(policy_text(), actor="t")
    with pytest.raises(PolicyError):
        eng.apply("schema_version: 1\npolicy: {id: x, revision: 2}\nrules: [", actor="t")
    with pytest.raises(PolicyError):
        eng.apply(text_of(rev(2, rules=[{"id": "x", "chain": "input", "action": "accept", "ports": [1], "justification": "bad"}])), actor="t")
    assert be.apply_count == 1
    assert eng.status()["state"] == "active"
    assert eng.status()["lkg"]["revision"] == 1


def test_dry_run_failure_changes_nothing(make_engine):
    eng, be = make_engine()
    eng.apply(policy_text(), actor="t")
    be.fail_check = True
    with pytest.raises(BackendError):
        eng.apply(text_of(rev(2)), actor="t")
    assert be.apply_count == 1 and be.installed_revision == 1


def test_backend_transaction_failure_restores_previous(make_engine):
    eng, be = make_engine()
    eng.apply(policy_text(), actor="t")
    be.fail_apply_once = True
    with pytest.raises(BackendError) as e:
        eng.apply(text_of(rev(2)), actor="t")
    assert "previous state was restored" in str(e.value)
    assert be.installed_revision == 1
    assert eng.status()["state"] == "active"
    assert eng.store.read_journal() is None


def test_verification_failure_after_apply_rolls_back(make_engine):
    eng, be = make_engine()
    eng.apply(policy_text(), actor="t")
    be.corrupt_after_apply = True
    # Every install (including the restore) is corrupted: the engine must report a
    # critical failure rather than claim success.
    with pytest.raises(StateError) as e:
        eng.apply(text_of(rev(2)), actor="t")
    assert "CRITICAL" in str(e.value)
    assert eng.status()["state"] == "drifted"
    be.corrupt_after_apply = False
    eng.rollback(actor="t")
    assert be.installed_revision == 1 and eng.status()["state"] == "active"


def test_verification_failure_rolls_back_cleanly(make_engine):
    eng, be = make_engine()
    eng.apply(policy_text(), actor="t")
    orig_verify = be.verify
    calls = {"n": 0}

    def flaky_verify(rs):
        calls["n"] += 1
        if calls["n"] == 1:
            from cipher_types import VerificationError

            raise VerificationError("installed state differs")
        return orig_verify(rs)

    be.verify = flaky_verify
    with pytest.raises(BackendError):
        eng.apply(text_of(rev(2)), actor="t")
    assert be.installed_revision == 1
    assert eng.status()["state"] == "active"


def test_first_apply_failure_removes_partial_state(make_engine):
    eng, be = make_engine()
    be.fail_verify = True
    with pytest.raises(BackendError) as e:
        eng.apply(policy_text(), actor="t")
    assert "restored (none)" in str(e.value)
    assert not be.inspect().present
    assert eng.status()["state"] == "unmanaged"


def test_first_apply_backend_failure_leaves_unmanaged(make_engine):
    eng, be = make_engine()
    be.fail_apply_once = True
    with pytest.raises(BackendError):
        eng.apply(policy_text(), actor="t")
    assert not be.inspect().present
    assert eng.status()["state"] == "unmanaged"


def test_timed_rollback_on_missing_confirmation(make_engine, clock):
    eng, be = make_engine()
    eng.apply(policy_text(), actor="t")
    res = eng.apply(text_of(rev(2)), actor="t", confirm_timeout=30)
    assert res["status"] == "pending-confirmation"
    assert be.installed_revision == 2
    assert eng.status()["state"] == "pending-confirmation"
    clock.advance(29)
    assert eng.tick() is None
    clock.advance(2)
    out = eng.tick()
    assert out["event"] == "timed-rollback"
    assert be.installed_revision == 1
    assert eng.status()["state"] == "active"


def test_confirm_commits(make_engine, clock):
    eng, be = make_engine()
    eng.apply(policy_text(), actor="t")
    eng.apply(text_of(rev(2)), actor="t", confirm_timeout=30)
    clock.advance(10)
    assert eng.confirm(actor="t")["status"] == "active"
    clock.advance(100)
    assert eng.tick() is None
    assert be.installed_revision == 2 and eng.status()["lkg"]["revision"] == 2


def test_confirm_after_deadline_rolls_back(make_engine, clock):
    eng, be = make_engine()
    eng.apply(policy_text(), actor="t")
    eng.apply(text_of(rev(2)), actor="t", confirm_timeout=10)
    clock.advance(11)
    with pytest.raises(StateError):
        eng.confirm(actor="t")
    assert be.installed_revision == 1


def test_no_new_apply_while_pending(make_engine):
    eng, _ = make_engine()
    eng.apply(policy_text(), actor="t", confirm_timeout=30)
    with pytest.raises(StateError):
        eng.apply(text_of(rev(2)), actor="t")


def test_unconfirmed_change_rolled_back_on_restart(make_engine, tmp_path, clock):
    eng, be = make_engine()
    eng.apply(policy_text(), actor="t")
    eng.apply(text_of(rev(2)), actor="t", confirm_timeout=300)
    # simulate restart: new engine, new backend object reading persisted "kernel"
    be2 = MemoryBackend(persist_path=str(tmp_path / "kernel.json"))
    eng2 = Engine(be2, StateStore(str(tmp_path / "state")), clock=clock)
    out = eng2.recover()
    assert out["action"] == "rolled-back-unconfirmed"
    assert be2.installed_revision == 1


def test_interrupted_operation_recovered_from_journal(make_engine, tmp_path, clock):
    eng, be = make_engine()
    eng.apply(policy_text(), actor="t")

    def die(point):
        if point == "after_backend_apply":
            raise KeyboardInterrupt("simulated termination")

    eng.faults = die
    with pytest.raises(KeyboardInterrupt):
        eng.apply(text_of(rev(2)), actor="t")
    assert eng.store.read_journal()["op"] == "apply"
    eng2 = Engine(MemoryBackend(persist_path=str(tmp_path / "kernel.json")), StateStore(str(tmp_path / "state")), clock=clock)
    out = eng2.recover()
    assert out["action"] == "restored-after-interruption"
    assert eng2.backend.installed_revision == 1
    assert eng2.status()["state"] == "active"


@pytest.mark.parametrize("point", ["after_journal", "after_backend_apply", "after_verify"])
def test_real_process_termination(tmp_path, point):
    """SIGKILL-equivalent (os._exit) at each step in a real child process."""
    state, kernel = tmp_path / "state", tmp_path / "kernel.json"
    p1, p2 = tmp_path / "p1.yaml", tmp_path / "p2.yaml"
    p1.write_text(policy_text())
    p2.write_text(text_of(rev(2)))
    script = textwrap.dedent(
        f"""
        import os, sys
        sys.path.insert(0, {ROOT!r})
        from cipher_backend import MemoryBackend
        from cipher_state import Engine, StateStore
        def fault(p):
            if p == {point!r} and os.environ.get("ARM") == "1":
                os._exit(137)
        eng = Engine(MemoryBackend(persist_path={str(kernel)!r}), StateStore({str(state)!r}), faults=fault)
        print(eng.apply(open(sys.argv[1]).read(), actor="t")["status"])
        """
    )
    env = dict(os.environ)
    subprocess.run([sys.executable, "-c", script, str(p1)], check=True, env=env, capture_output=True)
    env["ARM"] = "1"
    r = subprocess.run([sys.executable, "-c", script, str(p2)], env=env, capture_output=True)
    assert r.returncode == 137
    eng = Engine(MemoryBackend(persist_path=str(kernel)), StateStore(str(state)))
    out = eng.recover()
    assert out["action"] in ("restored-after-interruption", "verified")
    assert eng.backend.installed_revision == 1
    assert eng.status()["state"] == "active"
    assert eng.status()["lkg"]["revision"] == 1


def test_restart_reinstalls_lkg_when_table_missing(make_engine, tmp_path, clock):
    eng, be = make_engine()
    eng.apply(policy_text(), actor="t")
    be.remove()  # e.g. reboot cleared kernel state
    eng2 = Engine(MemoryBackend(persist_path=str(tmp_path / "kernel.json")), StateStore(str(tmp_path / "state")), clock=clock)
    out = eng2.recover()
    assert out["action"] == "reinstalled"
    assert eng2.backend.installed_revision == 1
    assert eng2.status()["state"] == "active"


def test_external_modification_detected_not_fought(make_engine):
    eng, be = make_engine()
    eng.apply(policy_text(), actor="t")
    be.tamper()
    st = eng.status()
    assert st["state"] == "drifted"
    assert eng.recover()["action"] == "drift-detected"
    assert be.apply_count == 1  # recovery did not silently compete
    eng.repair(actor="op")
    assert eng.status()["state"] == "active"


def test_revision_rules(make_engine):
    eng, _ = make_engine()
    eng.apply(text_of(rev(5)), actor="t")
    with pytest.raises(PolicyError) as e:
        eng.apply(text_of(rev(4)), actor="t")
    assert "revision.regression" in str(e.value)
    d = rev(5)
    d["rules"][0]["ports"] = [2222]
    with pytest.raises(PolicyError) as e:
        eng.apply(text_of(d), actor="t")
    assert "revision.reuse" in str(e.value)
    assert eng.apply(text_of(rev(5)), actor="t")["status"] == "active"  # idempotent re-apply


def test_conflicting_manager_refused(make_engine):
    eng, be = make_engine()
    be.conflict_report = ConflictReport(managers=["firewalld (nftables table inet firewalld)"])
    with pytest.raises(ConflictError):
        eng.apply(policy_text(), actor="t")
    assert be.apply_count == 0
    assert eng.apply(policy_text(), actor="t", allow_conflicts=True)["status"] == "active"


def test_capability_check(make_engine, tmp_path):
    be = MemoryBackend(features={"json", "atomic_replace", "named_sets", "log"})
    eng, _ = make_engine(backend=be)
    d = policy_dict(nat={"masquerade": [{"id": "m", "out_interface": "eth0", "justification": "lab egress"}]})
    from cipher_types import CapabilityError

    with pytest.raises(CapabilityError):
        eng.apply(text_of(d), actor="t")


def test_dynamic_set_update_bounded(make_engine):
    eng, be = make_engine()
    d = policy_dict(
        dynamic_sets={"upd": {"family": "ipv4", "source": "dns", "max_elements": 3}},
        rules=[{"id": "egress", "chain": "output", "action": "accept", "family": "ipv4", "destination": {"sets": ["upd"]}, "protocol": "tcp", "ports": [443], "justification": "updates"}],
    )
    eng.apply(text_of(d), actor="t")
    out = eng.update_dynamic_set("upd", ["192.0.2.1", "192.0.2.2"], source="dns", actor="t", provenance={"resolver": "x"})
    assert out["count"] == 2
    assert be.read_dynamic_set(None, eng.plan(text_of(d)).ruleset.set("dyn_upd")) == ["192.0.2.1/32", "192.0.2.2/32"]
    with pytest.raises(LimitExceeded):
        eng.update_dynamic_set("upd", [f"192.0.2.{i}" for i in range(10)], source="dns", actor="t", provenance={})
    with pytest.raises(StateError):
        eng.update_dynamic_set("upd", ["192.0.2.9"], source="feed", actor="t", provenance={})
    with pytest.raises(StateError):
        eng.update_dynamic_set("upd", ["2001:db8::1"], source="dns", actor="t", provenance={})
    with pytest.raises(StateError):
        eng.update_dynamic_set("nope", ["192.0.2.9"], source="dns", actor="t", provenance={})
    # members survive a policy re-apply (restored from the store)
    eng.apply(text_of(dict(d, policy={"id": "unit", "revision": 2})), actor="t")
    assert be._state["dynamic"]["dyn_upd"] == ["192.0.2.1/32", "192.0.2.2/32"]


def test_rule_expiry_tick(make_engine, clock):
    from datetime import datetime, timezone

    eng, be = make_engine()
    exp = datetime.fromtimestamp(clock() + 60, tz=timezone.utc).isoformat()
    d = policy_dict()
    d["rules"].append({"id": "temp", "chain": "input", "action": "accept", "protocol": "tcp", "ports": [8443], "expires": exp, "justification": "temporary access"})
    eng.apply(text_of(d), actor="t")
    assert "temp" in json.dumps(be._state["chains"])
    clock.advance(30)
    assert eng.tick() is None
    clock.advance(31)
    out = eng.tick()
    assert out["event"] == "expiry" and out["excluded"][0][0] == "temp"
    assert "temp" not in json.dumps(be._state["chains"])
    assert eng.status()["state"] == "active"


def test_conntrack_delete_audited(make_engine, tmp_path):
    eng, be = make_engine()
    eng.conntrack_delete(ConntrackFilter("ipv4", source="192.0.2.1"), actor="op", reason="revoke")
    recs = list(eng.audit.records())
    assert [r["outcome"] for r in recs if r["action"] == "conntrack_delete"] == ["requested", "ok"]


def test_audit_chain_covers_operations(make_engine, tmp_path, clock):
    eng, be = make_engine()
    eng.apply(policy_text(), actor="alice")
    eng.apply(text_of(rev(2)), actor="alice", confirm_timeout=10)
    clock.advance(11)
    eng.tick()
    actions = [(r["action"], r["outcome"]) for r in eng.audit.records()]
    assert ("commit", "ok") in actions and ("apply", "pending-confirmation") in actions and ("rollback", "ok") in actions
    ok, n, _ = verify_chain(str(tmp_path / "audit.jsonl"))
    assert ok and n == len(actions)


def test_remove(make_engine):
    eng, be = make_engine()
    eng.apply(policy_text(), actor="t")
    assert eng.remove(actor="t")["removed"] is True
    assert eng.status()["state"] == "unmanaged"
