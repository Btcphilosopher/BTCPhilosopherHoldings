import json
from datetime import datetime, timedelta, timezone

from cipher_backend.nftables import expected_comments, meta_comment, render_commands
from cipher_compiler import compile_policy, diff_rulesets, review_listing
from cipher_policy.validate import build_policy
from cipher_types.ir import MAddr, MIface, MNfproto, MPort
from tests.conftest import policy_dict

NOW = datetime(2026, 11, 18, tzinfo=timezone.utc)


def comp(d, now=NOW):
    pol, _ = build_policy(d, now=now)
    return compile_policy(pol, now=now)


def user_rules(rs, chain="input"):
    return [r for r in rs.chain(chain).rules if r.origin == "user"]


def test_deterministic_output():
    a = comp(policy_dict())
    b = comp(policy_dict())
    assert a.ruleset.digest == b.ruleset.digest
    assert json.dumps(render_commands(a.ruleset)) == json.dumps(render_commands(b.ruleset))
    assert review_listing(a.ruleset) == review_listing(b.ruleset)


def test_digest_changes_with_content():
    d = policy_dict()
    d["rules"][0]["ports"] = [2222]
    assert comp(d).ruleset.digest != comp(policy_dict()).ruleset.digest


def test_chain_order_essentials_first_then_user_then_default_log():
    rs = comp(policy_dict()).ruleset
    origins = [r.origin for r in rs.chain("input").rules]
    first_user = origins.index("user")
    assert all(o == "essential" for o in origins[:first_user])
    assert origins[-1] == "default"
    assert [r.rule_id for r in rs.chain("input").rules[:3]] == [
        "essential.loopback-antispoof",
        "essential.loopback-antispoof",
        "essential.loopback",
    ]


def test_explicit_default_policies():
    rs = comp(policy_dict()).ruleset
    assert {c.name: c.policy for c in rs.chains} == {"input": "drop", "output": "accept", "forward": "drop"}


def test_family_split_with_named_sets():
    rs = comp(policy_dict()).ruleset
    ssh = [r for r in user_rules(rs) if r.rule_id == "ssh"]
    assert [r.part for r in ssh] == ["ipv4/tcp", "ipv6/tcp"]
    assert ssh[0].matches[0] == MAddr("ipv4", "saddr", set_name="as_admins_v4")
    assert rs.set("as_admins_v4").elements == ("192.0.2.0/28",)
    assert rs.set("as_admins_v6").elements == ("2001:db8::/64",)


def test_family_agnostic_rule_is_single_inet_rule():
    rs = comp(policy_dict()).ruleset
    web = [r for r in user_rules(rs) if r.rule_id == "web"]
    assert [r.part for r in web] == ["inet/tcp", "inet/udp"]
    assert web[0].matches == (MPort("tcp", "dport", web[0].matches[0].ports),)
    assert [str(p) for p in web[0].matches[0].ports] == ["80", "443"]


def test_union_of_inline_and_sets_collapsed():
    d = policy_dict(rules=[{"id": "u", "chain": "input", "action": "accept", "family": "ipv4", "source": {"addresses": ["198.51.101.0/24"], "sets": ["web4"]}, "justification": "union"}])
    r = user_rules(comp(d).ruleset)[0]
    addr = [m for m in r.matches if isinstance(m, MAddr)][0]
    assert addr.networks == ("198.51.100.0/23",)


def test_zone_with_networks_adds_interface_and_network_matches():
    d = policy_dict(rules=[{"id": "z", "chain": "input", "action": "accept", "source": {"zone": "mgmt"}, "protocol": "tcp", "ports": [9000], "justification": "zone"}])
    rules = user_rules(comp(d).ruleset)
    assert [r.part for r in rules] == ["ipv4/tcp", "ipv6/tcp"]
    assert MIface("iifname", ("eth1",)) in rules[0].matches
    assert MAddr("ipv4", "saddr", ("10.9.0.0/24",)) in rules[0].matches


def test_explicit_family_without_addresses_uses_nfproto():
    d = policy_dict(rules=[{"id": "v6", "chain": "input", "action": "accept", "family": "ipv6", "protocol": "udp", "ports": [500], "justification": "ike v6"}])
    r = user_rules(comp(d).ruleset)[0]
    assert r.matches[0] == MNfproto("ipv6")


def test_expired_and_disabled_rules_excluded_with_next_expiry():
    later = (NOW + timedelta(days=1)).isoformat()
    d = policy_dict(
        rules=[
            {"id": "old", "chain": "input", "action": "accept", "protocol": "tcp", "ports": [1], "expires": "2026-01-01T00:00:00Z", "justification": "x x x"},
            {"id": "off", "chain": "input", "action": "accept", "protocol": "tcp", "ports": [2], "enabled": False, "justification": "x x x"},
            {"id": "soon", "chain": "input", "action": "accept", "protocol": "tcp", "ports": [3], "expires": later, "justification": "x x x"},
        ]
    )
    rs = comp(d).ruleset
    assert [x[0] for x in rs.excluded_rules] == ["old", "off"]
    assert [r.rule_id for r in user_rules(rs)] == ["soon"]
    assert rs.next_expiry == datetime.fromisoformat(later).isoformat()
    # After expiry the rule disappears and the digest changes.
    rs2 = comp(d, now=NOW + timedelta(days=2)).ruleset
    assert [r.rule_id for r in user_rules(rs2)] == []
    assert rs2.digest != rs.digest


def test_logging_rule_renders_two_nft_rules():
    d = policy_dict(rules=[{"id": "lg", "chain": "input", "action": "drop", "protocol": "tcp", "ports": [23], "log": True, "justification": "log telnet"}])
    rs = comp(d).ruleset
    comments = expected_comments(rs.chain("input"))
    assert "lc:lg[inet/tcp]:log" in comments and "lc:lg[inet/tcp]" in comments
    assert comments.index("lc:lg[inet/tcp]:log") + 1 == comments.index("lc:lg[inet/tcp]")
    cmds = render_commands(rs)
    log_rule = [c for c in cmds if "rule" in c.get("add", {}) and c["add"]["rule"]["comment"] == "lc:lg[inet/tcp]:log"][0]
    exprs = log_rule["add"]["rule"]["expr"]
    assert {"limit": {"rate": 5, "per": "second", "burst": 10}} in exprs
    assert {"log": {"prefix": "lc:lg:D ", "level": "info"}} in exprs


def test_dynamic_sets_declared_and_referenced():
    d = policy_dict(
        dynamic_sets={"upd": {"family": "ipv4", "source": "dns", "max_elements": 16}},
        rules=[{"id": "egress", "chain": "output", "action": "accept", "family": "ipv4", "destination": {"sets": ["upd"]}, "protocol": "tcp", "ports": [443], "justification": "updates"}],
    )
    rs = comp(d).ruleset
    s = rs.set("dyn_upd")
    assert s.dynamic and s.max_elements == 16
    r = user_rules(rs, "output")[0]
    assert MAddr("ipv4", "daddr", set_name="dyn_upd") in r.matches
    # dynamic elements do not change the digest
    assert rs.with_dynamic_elements({"dyn_upd": ("1.2.3.4/32",)}).with_digest().digest == rs.digest


def test_parity_report():
    res = comp(policy_dict())
    assert res.parity["both"] == ["ssh", "web"]


def test_nat_chains():
    d = policy_dict(
        nat={
            "masquerade": [{"id": "out", "out_interface": "eth0", "family": "ipv4", "source": {"addresses": ["10.10.0.0/24"]}, "justification": "lab egress"}],
            "port_forwards": [{"id": "pf", "in_interface": "eth0", "protocol": "tcp", "port": 8080, "to_address": "10.10.0.5", "to_port": 80, "justification": "lab web"}],
        }
    )
    rs = comp(d).ruleset
    assert "nat" in rs.features
    pre, post = rs.chain("nat_prerouting"), rs.chain("nat_postrouting")
    assert pre.hook == "prerouting" and pre.priority == -100 and pre.kind == "nat"
    assert pre.rules[0].nat.kind == "dnat" and pre.rules[0].nat.port == 80
    assert post.rules[0].nat.kind == "masquerade"


def test_render_structure_is_atomic_replace():
    rs = comp(policy_dict()).ruleset
    cmds = render_commands(rs)
    assert cmds[1] == {"add": {"table": {"family": "inet", "name": "london_cipher"}}}
    assert cmds[2] == {"delete": {"table": {"family": "inet", "name": "london_cipher"}}}
    assert cmds[3] == {"add": {"table": {"family": "inet", "name": "london_cipher"}}}
    kinds = [next(iter(c["add"])) for c in cmds[4:] if "add" in c]
    # sets before chains before rules
    assert kinds.index("chain") > max(i for i, k in enumerate(kinds) if k == "set")
    assert all(len(c["add"]["rule"]["comment"]) <= 127 for c in cmds if "rule" in c.get("add", {}))
    assert len(meta_comment(rs)) <= 127
    # every command targets only the managed table
    for c in cmds[1:]:
        body = next(iter(next(iter(c.values())).values()))
        assert body.get("table", body.get("name")) == "london_cipher"


def test_reject_uses_tcp_reset_for_tcp():
    d = policy_dict(rules=[{"id": "rj", "chain": "input", "action": "reject", "protocol": "tcp", "ports": [25], "justification": "reject smtp"}, {"id": "rj2", "chain": "input", "action": "reject", "protocol": "udp", "ports": [25], "justification": "reject"}])
    cmds = render_commands(comp(d).ruleset)
    by_comment = {c["add"]["rule"]["comment"]: c["add"]["rule"]["expr"] for c in cmds if "rule" in c.get("add", {})}
    assert by_comment["lc:rj[inet/tcp]"][-1] == {"reject": {"type": "tcp reset"}}
    assert by_comment["lc:rj2[inet/udp]"][-1] == {"reject": {"type": "icmpx", "expr": "port-unreachable"}}


def test_diff_semantics():
    old = comp(policy_dict()).ruleset
    d = policy_dict()
    d["policy"]["revision"] = 2
    d["defaults"]["output"] = "drop"
    d["rules"][0]["ports"] = [2222]
    d["rules"].append({"id": "new-rule", "chain": "input", "action": "drop", "protocol": "udp", "ports": [9], "justification": "discard"})
    new = comp(d).ruleset
    diff = diff_rulesets(old, new)
    assert "output: accept -> drop" in diff.policy_changes
    assert "input:ssh[ipv4/tcp]" in diff.changed
    assert "input:new-rule[inet/udp]" in diff.added
    assert diff.unified.startswith("--- installed (rev 1)")
    assert not diff_rulesets(old, old).changed and diff_rulesets(old, old).empty


def test_essential_services_output_rules():
    d = policy_dict(essential={"dns_servers": ["192.0.2.53", "2001:db8::53"], "ntp_servers": ["192.0.2.123"], "dhcpv4_client": True})
    rs = comp(d).ruleset
    ids = [r.rule_id + "[" + r.part + "]" for r in rs.chain("output").rules]
    assert "essential.dns[ipv4/udp]" in ids and "essential.dns[ipv6/tcp]" in ids
    assert "essential.ntp[ipv4/udp]" in ids
    assert "essential.dhcpv4-client[ipv4]" in ids


def test_state_handling_evaluate_omits_early_rules():
    d = policy_dict(state={"established_related": "evaluate", "invalid": "evaluate"})
    ids = [r.rule_id for r in comp(d).ruleset.chain("input").rules]
    assert "essential.ct-established" not in ids and "essential.ct-invalid" not in ids
