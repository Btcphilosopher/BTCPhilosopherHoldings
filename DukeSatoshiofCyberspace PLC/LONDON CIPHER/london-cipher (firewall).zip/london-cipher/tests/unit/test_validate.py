import copy
import glob
import os
from datetime import datetime, timezone

import pytest

from cipher_policy.validate import build_policy
from cipher_types import Family, PolicyError, Severity
from tests.conftest import BASE, EXAMPLES, policy_dict

NOW = datetime(2026, 11, 18, tzinfo=timezone.utc)


def errors_of(data):
    with pytest.raises(PolicyError) as e:
        build_policy(data, now=NOW)
    return {i.code for i in e.value.issues if i.severity is Severity.ERROR}


def with_rules(*rules, **kw):
    return policy_dict(rules=list(rules), **kw)


def rule(**kw):
    r = {"id": "r1", "chain": "input", "action": "accept", "justification": "test rule"}
    r.update(kw)
    return r


def test_base_policy_valid():
    pol, warnings = build_policy(copy.deepcopy(BASE), now=NOW)
    assert pol.meta.id == "unit"
    assert [r.id for r in pol.rules] == ["ssh", "web"]
    assert pol.zones["mgmt"].interfaces == ("eth1",)


@pytest.mark.parametrize("path", sorted(glob.glob(os.path.join(EXAMPLES, "*.yaml"))))
def test_examples_validate(path):
    from cipher_policy import load_policy_file

    _, data = load_policy_file(path)
    build_policy(data, now=NOW)


def test_unknown_keys_rejected():
    assert "key.unknown" in errors_of(policy_dict(rulez=[]))
    assert "key.unknown" in errors_of(with_rules(rule(protcol="tcp")))


def test_defaults_required_and_explicit():
    d = policy_dict()
    del d["defaults"]["forward"]
    assert "key.missing" in errors_of(d)
    assert "value.choice" in errors_of(policy_dict(defaults={"input": "reject", "output": "accept", "forward": "drop"}))


def test_host_bits_and_bad_networks():
    assert "value.network" in errors_of(with_rules(rule(source={"addresses": ["10.0.0.1/24"]}, family="ipv4")))
    assert "value.network" in errors_of(with_rules(rule(source={"addresses": ["10.0.0.300"]}, family="ipv4")))
    assert "type.network" in errors_of(with_rules(rule(source={"addresses": [17]}, family="ipv4")))


@pytest.mark.parametrize("ports", [[0], [70000], ["10-5"], ["abc"], [True], ["1-2-3"]])
def test_bad_ports(ports):
    assert errors_of(with_rules(rule(protocol="tcp", ports=ports))) & {"value.port", "value.range"}


def test_ports_need_protocol():
    assert "combo.ports_without_protocol" in errors_of(with_rules(rule(ports=[22])))
    assert "combo.ports" in errors_of(with_rules(rule(protocol="icmp", family="ipv4", ports=[22])))


def test_services_ambiguous_with_protocol():
    assert "combo.services" in errors_of(with_rules(rule(services=["web"], protocol="tcp")))


def test_icmp_family_rules():
    assert "family.divergence" in errors_of(with_rules(rule(protocol="icmp", icmp_types=["echo-request"])))
    assert "family.empty" in errors_of(with_rules(rule(protocol="icmp", family="ipv6")))
    assert "value.icmp_type" in errors_of(with_rules(rule(protocol="icmpv6", family="ipv6", icmp_types=["router-advertisement"])))
    pol, _ = build_policy(with_rules(rule(protocol="icmpv6", family="ipv6", icmp_types=["echo-request"])), now=NOW)
    assert pol.rules[0].family is Family.IPV6


def test_family_divergence_must_be_explicit():
    # IPv4-only sources with family any -> must say so explicitly
    assert "family.divergence" in errors_of(with_rules(rule(source={"sets": ["web4"]}, protocol="tcp", ports=[1])))
    pol, _ = build_policy(with_rules(rule(source={"sets": ["web4"]}, protocol="tcp", ports=[1], family="ipv4")), now=NOW)
    assert pol.rules[0].family is Family.IPV4


def test_family_mixed_content_rejected():
    r = rule(source={"addresses": ["192.0.2.0/24", "2001:db8::/32"]}, family="ipv4", protocol="tcp", ports=[1])
    assert "family.mixed" in errors_of(with_rules(r))


def test_explicit_family_selects_members_of_dual_stack_set():
    pol, _ = build_policy(with_rules(rule(source={"sets": ["admins"]}, family="ipv6", protocol="tcp", ports=[1])), now=NOW)
    assert pol.rules[0].family is Family.IPV6
    # a v6 rule over an IPv4-only set can never match
    assert "family.empty" in errors_of(with_rules(rule(source={"sets": ["web4"]}, family="ipv6", protocol="tcp", ports=[1])))


def test_family_impossible_rejected():
    r = rule(source={"addresses": ["10.0.0.0/8"]}, destination={"addresses": ["2001:db8::/32"]})
    assert "family.empty" in errors_of(with_rules(r))


def test_dangling_references():
    assert "ref.set" in errors_of(with_rules(rule(source={"sets": ["nope"]})))
    assert "ref.zone" in errors_of(with_rules(rule(source={"zone": "nope"})))
    assert "ref.service" in errors_of(with_rules(rule(services=["nope"])))
    assert "ref.zone" in errors_of(policy_dict(interfaces={"eth9": {"zone": "ghost"}}))


def test_empty_zone_reference_rejected():
    d = with_rules(rule(source={"zone": "empty"}))
    d["zones"]["empty"] = {}
    assert "ref.zone_empty" in errors_of(d)


def test_duplicate_ids():
    assert "dup.id" in errors_of(with_rules(rule(id="a", protocol="tcp", ports=[1]), rule(id="a", protocol="tcp", ports=[2])))


def test_rule_id_format():
    assert "value.format" in errors_of(with_rules(rule(id="Bad ID")))
    assert "value.format" in errors_of(with_rules(rule(id="essential.x")))  # dots reserved


def test_accept_invalid_state_rejected():
    assert "combo.accept_invalid" in errors_of(with_rules(rule(ct_state=["invalid"])))


def test_chain_interface_constraints():
    assert "combo.chain" in errors_of(with_rules(rule(chain="output", in_interface="eth0")))
    assert "combo.chain" in errors_of(with_rules(rule(chain="input", out_interface="eth0")))
    assert "combo.chain" in errors_of(with_rules(rule(chain="output", source={"zone": "lan"})))


def test_expiry_requires_timezone_and_marks_expired():
    assert "value.timestamp_tz" in errors_of(with_rules(rule(protocol="tcp", ports=[1], expires="2026-01-01T00:00:00")))
    pol, warnings = build_policy(with_rules(rule(protocol="tcp", ports=[1], expires="2026-01-01T00:00:00Z")), now=NOW)
    assert any(w.code == "rule.expired" for w in warnings)
    assert not pol.rules[0].is_active(NOW)


def test_justification_required():
    r = rule(protocol="tcp", ports=[1])
    del r["justification"]
    assert "key.missing" in errors_of(with_rules(r))
    assert "value.empty" in errors_of(with_rules(rule(justification="  ")))


def test_shadowed_rule_conflict_is_error():
    rules = [
        rule(id="allow-all-tcp", protocol="tcp"),
        rule(id="deny-ssh", action="drop", protocol="tcp", ports=[22]),
    ]
    assert "conflict.shadowed" in errors_of(with_rules(*rules))


def test_shadow_with_networks_and_sets():
    rules = [
        rule(id="deny-net", action="drop", family="ipv4", source={"addresses": ["198.51.100.0/23"]}),
        rule(id="allow-sub", family="ipv4", source={"sets": ["web4"]}, protocol="tcp", ports=[80]),
    ]
    assert "conflict.shadowed" in errors_of(with_rules(*rules))


def test_partial_overlap_not_flagged():
    rules = [
        rule(id="a", protocol="tcp", ports=["20-25"]),
        rule(id="b", action="drop", protocol="tcp", ports=["24-30"]),
    ]
    pol, warnings = build_policy(with_rules(*rules), now=NOW)
    assert not [w for w in warnings if w.code.startswith("conflict")]


def test_redundant_rule_warning():
    rules = [rule(id="a", protocol="tcp", ports=["1-100"]), rule(id="b", protocol="tcp", ports=[22])]
    _, warnings = build_policy(with_rules(*rules), now=NOW)
    assert any(w.code == "conflict.redundant" for w in warnings)


def test_interface_wildcard_shadow():
    rules = [rule(id="a", action="drop", in_interface="eth*"), rule(id="b", in_interface="eth0", protocol="tcp", ports=[1])]
    assert "conflict.shadowed" in errors_of(with_rules(*rules))


def test_admin_access_must_be_restricted():
    d = policy_dict(essential={"admin_access": {"ports": [22], "source": {}, "justification": "x y z"}})
    assert "value.admin_any" in errors_of(d)


def test_dynamic_sets():
    d = policy_dict(dynamic_sets={"blk": {"family": "ipv4", "source": "detection", "max_elements": 10}})
    assert "key.missing" in errors_of(d)
    d = policy_dict(dynamic_sets={"upd": {"family": "ipv4", "source": "dns", "max_elements": 10, "timeout_seconds": 5}})
    assert "combo.timeout" in errors_of(d)
    d = policy_dict(
        dynamic_sets={"upd": {"family": "ipv4", "source": "dns", "max_elements": 10}},
        rules=[rule(chain="output", family="ipv4", destination={"sets": ["upd"]}, protocol="tcp", ports=[443])],
    )
    pol, _ = build_policy(d, now=NOW)
    assert pol.dynamic_sets["upd"].family is Family.IPV4


def test_schema_version_checked():
    assert "schema.version" in errors_of(policy_dict(schema_version=2))


def test_all_errors_collected():
    d = with_rules(rule(id="BAD"), rule(id="ok2", ports=[0]))
    with pytest.raises(PolicyError) as e:
        build_policy(d, now=NOW)
    assert len([i for i in e.value.issues if i.severity is Severity.ERROR]) >= 2


def test_nat_validation():
    d = policy_dict(nat={"port_forwards": [{"id": "pf", "in_interface": "eth0", "protocol": "tcp", "port": 8080, "to_address": "10.0.0.5", "to_port": 80, "justification": "lab web"}]})
    pol, _ = build_policy(d, now=NOW)
    assert pol.nat.port_forwards[0].to_port == 80
    d["nat"]["port_forwards"][0]["to_address"] = "10.0.0.500"
    assert "value.address" in errors_of(d)
