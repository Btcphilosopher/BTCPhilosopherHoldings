import json
import os

from cipher_cli.main import main
from tests.conftest import EXAMPLES, policy_text

WS = os.path.join(EXAMPLES, "developer-workstation.yaml")


def test_validate_ok(capsys):
    assert main(["validate", WS]) == 0
    assert "OK: developer-workstation" in capsys.readouterr().out


def test_validate_rejects_with_exit_1(tmp_path, capsys):
    p = tmp_path / "bad.yaml"
    p.write_text(policy_text().replace("ports:\n  - 22", "ports:\n  - 0"))
    assert main(["--json", "validate", str(p)]) == 1
    out = json.loads(capsys.readouterr().out)
    assert out["valid"] is False and out["issues"]


def test_compile_formats(capsys):
    assert main(["compile", WS]) == 0
    assert "chain input" in capsys.readouterr().out
    assert main(["compile", "--format", "nft-json", WS]) == 0
    assert json.loads(capsys.readouterr().out)["nftables"][1]["add"]["table"]["name"] == "london_cipher"
    assert main(["compile", "--format", "ir", WS]) == 0
    assert json.loads(capsys.readouterr().out)["_t"] == "IRRuleset"


def test_diff_and_parity(tmp_path, capsys):
    p2 = tmp_path / "ws2.yaml"
    p2.write_text(open(WS).read().replace("revision: 1", "revision: 2").replace("ports: [5353]", "ports: [5353, 5354]"))
    assert main(["diff", WS, str(p2)]) == 0
    out = capsys.readouterr().out
    assert "changed: input:mdns-office[inet/udp]" in out
    assert main(["parity", WS]) == 0
    assert "ipv4_only: ping-v4" in capsys.readouterr().out


def test_admin_command_without_daemon_fails_cleanly(tmp_path, capsys):
    assert main(["--socket", str(tmp_path / "none.sock"), "status"]) == 3
    assert "cannot connect" in capsys.readouterr().err
