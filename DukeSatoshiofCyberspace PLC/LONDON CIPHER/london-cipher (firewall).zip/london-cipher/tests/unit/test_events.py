import json

import pytest

from cipher_events import AuditLog, Event, EventBus, JsonlSink, Redactor, TokenBucket, parse_line, verify_chain


class Clock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t


def test_token_bucket():
    c = Clock()
    b = TokenBucket(rate=2, burst=3, clock=c)
    assert [b.allow() for _ in range(4)] == [True, True, True, False]
    c.t = 1.0
    assert b.allow() and b.allow() and not b.allow()


def test_bus_rate_limit_and_queue_bounds_are_counted():
    c = Clock()
    bus = EventBus(max_queue=5, rate_per_kind=1, burst_per_kind=3, clock=c)
    results = [bus.publish(Event("packet", "k", "logged")) for _ in range(10)]
    assert results.count(True) == 3
    assert bus.counters()["dropped"]["rate_limited"] == 7
    for _ in range(5):
        bus.publish(Event(f"k{_}", "x", "ok"))
    bus.publish(Event("k9", "x", "ok"))
    bus.publish(Event("k10", "x", "ok"))
    assert bus.counters()["queued"] == 5
    assert bus.counters()["dropped"]["queue_full"] >= 1


def test_bus_sink_failure_does_not_raise():
    def bad(_):
        raise RuntimeError("disk full")

    bus = EventBus(sinks=[bad])
    bus.publish(Event("deploy", "x", "ok"))
    assert len(bus.drain()) == 1
    assert bus.counters()["dropped"]["sink_error"] == 1


def test_redaction_modes():
    assert Redactor("truncate").redact_ip("192.0.2.77") == "192.0.2.0/24"
    assert Redactor("truncate").redact_ip("2001:db8:1:2::5") == "2001:db8:1::/48"
    h = Redactor("hash", key=b"k1")
    assert h.redact_ip("192.0.2.1") == h.redact_ip("192.0.2.1") != Redactor("hash", key=b"k2").redact_ip("192.0.2.1")
    assert h.redact_ip("192.0.2.1").startswith("h:")
    with pytest.raises(ValueError):
        Redactor("hash")
    rec = Redactor("truncate").redact_event({"network": {"src": "10.1.2.3", "dport": 22}, "details": {"api_token": "abc", "policy_sha256": "x"}})
    assert rec["network"] == {"src": "10.1.2.0/24", "dport": 22}
    assert rec["details"]["api_token"] == "[redacted]" and rec["details"]["policy_sha256"] == "x"


def test_audit_chain_and_tamper_detection(tmp_path):
    p = str(tmp_path / "audit.jsonl")
    log = AuditLog(p, fsync=False)
    for i in range(5):
        log.record("apply", actor="alice", outcome="ok", n=i, password="hunter2")
    ok, n, problem = verify_chain(p)
    assert ok and n == 5 and problem is None
    assert all(r["details"]["password"] == "[redacted]" for r in log.records())
    lines = open(p).read().splitlines()
    rec = json.loads(lines[2])
    rec["actor"] = "mallory"
    lines[2] = json.dumps(rec, sort_keys=True, separators=(",", ":"))
    open(p, "w").write("\n".join(lines) + "\n")
    ok, n, problem = verify_chain(p)
    assert not ok and "modified" in problem
    # deletion of a record also breaks the chain
    fresh = str(tmp_path / "audit2.jsonl")
    log2 = AuditLog(fresh, fsync=False)
    for i in range(4):
        log2.record("apply", actor="alice", outcome="ok", n=i)
    kept = open(fresh).read().splitlines()
    open(fresh, "w").write("\n".join(kept[:1] + kept[2:]) + "\n")
    ok, _, problem = verify_chain(fresh)
    assert not ok and "chain broken" in problem


def test_jsonl_sink_rotation(tmp_path):
    p = str(tmp_path / "ev.jsonl")
    s = JsonlSink(p, max_bytes=200, backups=2)
    for i in range(50):
        s.write({"i": i, "pad": "x" * 20})
    import os

    assert os.path.exists(p + ".1") and os.path.exists(p + ".2") and not os.path.exists(p + ".3")


def test_kernel_log_parsing():
    line = "[12.3] lc:ssh-admin:A IN=eth0 OUT= MAC=aa SRC=192.0.2.5 DST=192.0.2.1 LEN=60 PROTO=TCP SPT=40000 DPT=22 WINDOW=0"
    ev = parse_line(line, policy_id="p", revision=3)
    assert ev.rule_id == "ssh-admin" and ev.action == "accept"
    assert ev.network == {"iif": "eth0", "src": "192.0.2.5", "dst": "192.0.2.1", "proto": "tcp", "sport": 40000, "dport": 22}
    d = parse_line("lc:default-input:D IN=eth0 OUT= SRC=::1 DST=::2 PROTO=ICMPv6 TYPE=128 CODE=0")
    assert d.rule_id == "default.input" and d.action == "drop" and d.network["icmp_type"] == 128
    assert parse_line("unrelated kernel message") is None
    assert parse_line("x" * 100000) is None
