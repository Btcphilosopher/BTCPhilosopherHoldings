import ast
import os

import pytest

from cipher_research import RobustZModel, advisories, aggregate, drift_report, evaluate, psi, synthesize, time_split
from cipher_research.anomaly import SYNTHETIC_WARNING


@pytest.fixture(scope="module")
def rows():
    return aggregate(synthesize(seed=3, hours=6, sources=20), 60)


def test_time_split_is_strictly_ordered(rows):
    tr, va, te = time_split(rows)
    assert max(r.window_start for r in tr) < min(r.window_start for r in va)
    assert max(r.window_start for r in va) < min(r.window_start for r in te)
    assert len(tr) + len(va) + len(te) == len(rows)


def test_evaluation_report_is_reproducible_and_labelled(rows):
    a = evaluate(rows, synthetic=True)
    b = evaluate(rows, synthetic=True)
    assert a["metrics"] == b["metrics"]
    assert a["provenance"]["dataset_sha256"] == b["provenance"]["dataset_sha256"]
    assert a["advisory_only"] is True and a["synthetic_data"] is True and a["warning"] == SYNTHETIC_WARNING
    m = a["metrics"]
    assert m["tp"] + m["fn"] > 0 and m["fp"] + m["tn"] > 0
    assert set(a["drift"]) == {"events", "drops", "distinct_dports", "distinct_dsts", "drop_ratio"}
    assert "top" in a["false_positive_analysis"]


def test_psi_detects_shift():
    base = [float(i % 10) for i in range(1000)]
    assert psi(base, base) < 0.01
    assert psi(base, [x + 8 for x in base]) > 0.25


def test_drift_report_status(rows):
    tr, _, te = time_split(rows)
    rep = drift_report(tr, te)
    assert all(v["status"] in ("stable", "moderate", "significant") for v in rep.values())


def test_advisories_are_advisory(rows):
    tr, va, te = time_split(rows)
    m = RobustZModel().fit(tr)
    m.calibrate(va)
    adv = advisories(m, te)
    assert adv and all(a["advisory"] is True for a in adv)


def test_research_module_cannot_reach_enforcement():
    """Static guarantee: no import of engine, backend or admin from the research package."""
    pkg = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "cipher_research")
    for name in os.listdir(pkg):
        if name.endswith(".py"):
            tree = ast.parse(open(os.path.join(pkg, name)).read())
            for node in ast.walk(tree):
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    mods = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module or ""]
                    for m in mods:
                        assert not m.startswith(("cipher_state", "cipher_backend", "cipher_admin", "subprocess")), (name, m)
