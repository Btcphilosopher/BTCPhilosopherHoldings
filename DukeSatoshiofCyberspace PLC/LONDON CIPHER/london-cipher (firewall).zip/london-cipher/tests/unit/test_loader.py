import json

import pytest

from cipher_policy.loader import MAX_POLICY_BYTES, load_policy_text
from cipher_types import PolicyError


def codes(exc):
    return {i.code for i in exc.value.issues}


def test_yaml_and_json_load():
    assert load_policy_text("a: 1\nb: [x]\n") == {"a": 1, "b": ["x"]}
    assert load_policy_text('{"a": 1}') == {"a": 1}


def test_duplicate_keys_rejected_yaml():
    with pytest.raises(PolicyError) as e:
        load_policy_text("a: 1\na: 2\n")
    assert "duplicate key" in str(e.value)


def test_duplicate_keys_rejected_json():
    with pytest.raises(PolicyError):
        load_policy_text('{"a": 1, "a": 2}')


def test_aliases_rejected():
    with pytest.raises(PolicyError) as e:
        load_policy_text("a: &x [1,2]\nb: *x\n")
    assert "aliases" in str(e.value)


def test_merge_keys_rejected():
    with pytest.raises(PolicyError):
        load_policy_text("base: {x: 1}\nc:\n  <<: {x: 2}\n")


def test_python_tags_rejected():
    with pytest.raises(PolicyError):
        load_policy_text("a: !!python/object/apply:os.system ['true']\n")
    with pytest.raises(PolicyError):
        load_policy_text("a: !custom 1\n")


def test_size_limit():
    big = "a: '" + "x" * (MAX_POLICY_BYTES + 10) + "'\n"
    with pytest.raises(PolicyError) as e:
        load_policy_text(big)
    assert codes(e) == {"load.too_large"}


def test_multiple_documents_rejected():
    with pytest.raises(PolicyError):
        load_policy_text("a: 1\n---\nb: 2\n")


def test_root_must_be_mapping():
    with pytest.raises(PolicyError):
        load_policy_text("- 1\n- 2\n")


def test_timestamps_stay_strings():
    d = load_policy_text("t: 2026-12-31T00:00:00Z\n")
    assert d["t"] == "2026-12-31T00:00:00Z"


def test_nul_and_encoding():
    with pytest.raises(PolicyError):
        load_policy_text("a: 1\x00")
    with pytest.raises(PolicyError):
        load_policy_text(b"\xff\xfe")


def test_depth_limit():
    deep = json.dumps(json.loads("[" * 40 + "]" * 40))
    with pytest.raises(PolicyError):
        load_policy_text('{"a": ' + deep + "}")
