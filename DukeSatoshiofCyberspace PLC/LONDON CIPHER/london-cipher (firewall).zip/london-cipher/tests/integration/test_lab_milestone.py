"""First acceptance milestone, verified by real packet outcomes.

    Install a validated policy inside an isolated network namespace,
    demonstrate allowed and denied traffic, update it atomically, recover from
    a failed change and preserve the correct state after restart.

Runs only inside the namespace laboratory (lab/netlab.py). Requires root,
nftables, iproute2 and conntrack-tools; skipped otherwise. Nothing is changed
in the host's own network namespace.
"""

from __future__ import annotations

import json
import os
import signal
import threading
import time

import pytest
import yaml

from cipher_admin.client import AdminClient
from cipher_backend import CommandRunner, ConntrackFilter, NftablesBackend, netns_prefix
from cipher_backend.nftables import render_commands
from cipher_events import AuditLog, verify_chain
from cipher_state import Engine, StateStore
from cipher_types import BackendError, PolicyError
from lab.netlab import Lab, lab_available

pytestmark = pytest.mark.lab

OK, AVAILABLE_WHY = lab_available()
if not OK:
    pytest.skip(f"laboratory unavailable: {AVAILABLE_WHY}", allow_module_level=True)

HERE = os.path.dirname(os.path.abspath(__file__))
POL = os.path.join(os.path.dirname(os.path.dirname(HERE)), "lab", "policies")
H4, H6 = "10.77.0.1", "fd77::1"


def ptext(name: str) -> str:
    with open(os.path.join(POL, name)) as fh:
        return fh.read()


def with_revision(text: str, rev: int, svc9090: bool) -> str:
    d = yaml.safe_load(text)
    d["policy"]["revision"] = rev
    if not svc9090:
        d["rules"] = [r for r in d["rules"] if r["id"] != "svc-9090"]
    return yaml.safe_dump(d, sort_keys=False)


@pytest.fixture(scope="module")
def lab():
    lb = Lab().up()
    lb.serve("host", tcp=[2222, 8080, 9090], udp=[5300])
    lb.serve("ok", tcp=[7000], udp=[])
    lb.serve("outer", tcp=[8080, 9000], udp=[])
    lb.serve("inner", tcp=[8080], udp=[])
    yield lb
    lb.down()


@pytest.fixture
def engine(lab, tmp_path):
    backend = NftablesBackend(CommandRunner(netns_prefix(lab.ns["host"])))
    backend.remove()
    eng = Engine(backend, StateStore(str(tmp_path / "state")), audit=AuditLog(str(tmp_path / "audit.jsonl")))
    yield eng
    backend.remove()


def assert_rev1_traffic_v6(lab):
    assert lab.tcp("ok", H6, 8080) == "open"
    assert lab.udp("ok", H6, 5300) == "open"
    assert lab.ping("ok", H6)
    assert lab.tcp("deny", H6, 8080) == "refused"
    assert not lab.ping("deny", H6)
    assert lab.tcp("mgmt", H6, 2222) == "open"
    assert lab.tcp("ok", H6, 2222, timeout=1) == "timeout"


def assert_rev1_traffic(lab):
    # allowed client: app, UDP service, ping
    assert lab.tcp("ok", H4, 8080) == "open"
    assert lab.udp("ok", H4, 5300) == "open"
    assert lab.ping("ok", H4)
    # denied client: explicit reject (fast) on app, default drop elsewhere
    assert lab.tcp("deny", H4, 8080) == "refused"
    assert lab.udp("deny", H4, 5300, timeout=1) == "timeout"
    assert not lab.ping("deny", H4)
    # management: admin port only
    assert lab.tcp("mgmt", H4, 2222) == "open"
    assert lab.tcp("mgmt", H4, 8080, timeout=1) == "timeout"
    assert lab.tcp("ok", H4, 2222, timeout=1) == "timeout"
    # rev2-only service closed
    assert lab.tcp("ok", H4, 9090, timeout=1) == "timeout"


def test_install_and_allowed_denied_traffic(lab, engine):
    # Before installation the lab is open (no firewall): sanity check of the probes.
    assert lab.tcp("deny", H4, 8080) == "open"
    res = engine.apply(ptext("host-rev1.yaml"), actor="lab")
    assert res["status"] == "active"
    st = engine.status()
    assert st["state"] == "active" and st["installed"]["revision"] == 1
    assert_rev1_traffic(lab)
    # return traffic for host-initiated connections (output accept + established)
    assert lab.tcp("host", "10.77.0.20", 7000) == "open"
    # loopback explicitly accepted
    assert lab.tcp("host", "127.0.0.1", 8080) == "open"


def require_ipv6(lab):
    if not lab.ipv6:
        pytest.skip("IPv6 PACKET TESTS NOT EXECUTED: the kernel in this environment has IPv6 disabled "
                    "(/proc/net/if_inet6 absent). IPv6 rules were still compiled, loaded and verified.")


def test_ipv6_allowed_denied_traffic(lab, engine):
    require_ipv6(lab)
    engine.apply(ptext("host-rev1.yaml"), actor="lab")
    # IPv6 connectivity at all under input policy drop proves neighbour discovery is permitted
    assert_rev1_traffic_v6(lab)
    assert lab.tcp("host", "fd77::20", 7000) == "open"
    assert lab.tcp("host", "::1", 8080) == "open"


def test_ipv6_rules_loaded_even_without_ipv6_stack(lab, engine):
    """The inet table carries IPv6 rules regardless; verify they are installed."""
    engine.apply(ptext("host-rev1.yaml"), actor="lab")
    listing = lab.nft("host", "list", "table", "inet", "london_cipher").stdout
    for needle in ("ip6 saddr @as_clients_v6", "nd-neighbor-solicit", "ip6 hoplimit 255", "ip6 saddr @as_mgmt_v6 tcp dport 2222"):
        assert needle in listing, needle


def test_atomic_update_without_disruption(lab, engine):
    engine.apply(ptext("host-rev1.yaml"), actor="lab")
    results: list[str] = []
    stop = threading.Event()

    def prober():
        while not stop.is_set():
            results.append(lab.tcp("ok", H4, 8080, timeout=2))

    t = threading.Thread(target=prober)
    t.start()
    try:
        base = ptext("host-rev2.yaml")
        for rev in range(2, 12):
            out = engine.apply(with_revision(base, rev, svc9090=(rev % 2 == 0)), actor="lab")
            assert out["status"] == "active"
    finally:
        stop.set()
        t.join()
    assert results and all(r == "open" for r in results), results
    # final revision 11 has svc-9090 removed; revision 10 had it
    assert lab.tcp("ok", H4, 9090, timeout=1) == "timeout"
    engine.apply(with_revision(ptext("host-rev2.yaml"), 12, svc9090=True), actor="lab")
    assert lab.tcp("ok", H4, 9090) == "open"
    assert lab.tcp("deny", H4, 9090, timeout=1) == "timeout"
    assert engine.status()["installed"]["revision"] == 12


class FailingNftables(NftablesBackend):
    """Submits a real batch that nft/the kernel rejects part-way through (once)."""

    armed = True

    def apply(self, ruleset, dynamic=None):
        if not self.armed:
            return super().apply(ruleset, dynamic)
        self.armed = False
        cmds = render_commands(ruleset, dynamic)
        cmds.append({"add": {"rule": {"family": "inet", "table": ruleset.table, "chain": "input", "expr": [{"match": {"op": "==", "left": {"payload": {"protocol": "ip", "field": "saddr"}}, "right": "@set_that_does_not_exist"}}, {"accept": None}]}}})
        self._submit(cmds)


def test_kernel_rejected_change_is_atomic_and_recovered(lab, engine, tmp_path):
    engine.apply(ptext("host-rev1.yaml"), actor="lab")
    before = engine.backend.inspect().fingerprint
    bad = FailingNftables(CommandRunner(netns_prefix(lab.ns["host"])))
    # 1. kernel-level atomicity: the batch starts with "delete table", yet nothing changes
    rs2 = engine.plan(ptext("host-rev2.yaml")).ruleset
    with pytest.raises(BackendError):
        bad.apply(rs2)
    assert engine.backend.inspect().fingerprint == before
    assert_rev1_traffic(lab)
    bad.armed = True
    # 2. engine-level recovery: failure reported, previous state verified/restored
    eng2 = Engine(bad, engine.store, audit=engine.audit)
    with pytest.raises(BackendError) as e:
        eng2.apply(ptext("host-rev2.yaml"), actor="lab")
    assert "previous state was restored" in str(e.value)
    assert engine.status()["state"] == "active"
    assert engine.status()["installed"]["revision"] == 1
    assert_rev1_traffic(lab)


def test_invalid_policy_never_reaches_kernel(lab, engine):
    engine.apply(ptext("host-rev1.yaml"), actor="lab")
    before = engine.backend.inspect().fingerprint
    bad = ptext("host-rev2.yaml").replace("ports: [9090]", "ports: [90900]")
    with pytest.raises(PolicyError):
        engine.apply(bad, actor="lab")
    with pytest.raises(PolicyError):
        engine.apply("schema_version: 1\npolicy: [", actor="lab")
    assert engine.backend.inspect().fingerprint == before


def test_external_modification_detected_and_repaired(lab, engine):
    engine.apply(ptext("host-rev1.yaml"), actor="lab")
    lab.nft("host", "insert", "rule", "inet", "london_cipher", "input", "tcp", "dport", "9090", "accept")
    assert lab.tcp("deny", H4, 9090) == "open"  # the foreign rule really took effect
    st = engine.status()
    assert st["state"] == "drifted"
    assert engine.recover()["action"] == "drift-detected"
    assert lab.tcp("deny", H4, 9090) == "open"  # detection did not silently fight
    engine.repair(actor="lab")
    assert engine.status()["state"] == "active"
    assert lab.tcp("deny", H4, 9090, timeout=1) == "timeout"


def test_other_firewall_tables_reported(lab, engine):
    lab.nft("host", "add", "table", "inet", "someone_else")
    lab.nft("host", "add", "chain", "inet", "someone_else", "in", "{ type filter hook input priority -10; policy accept; }")
    try:
        plan = engine.plan(ptext("host-rev1.yaml"))
        assert any("someone_else" in c for c in plan.conflicts["foreign_base_chains"])
        engine.apply(ptext("host-rev1.yaml"), actor="lab")
        # the foreign table is untouched by our atomic replace
        assert lab.nft("host", "list", "table", "inet", "someone_else").returncode == 0
    finally:
        lab.nft("host", "delete", "table", "inet", "someone_else", check=False)


def test_existing_flows_and_audited_conntrack_removal(lab, engine):
    engine.apply(ptext("host-rev1.yaml"), actor="lab")
    hold = lab.spawn("ok", ["python3", "-I", os.path.join(os.path.dirname(POL), "probe.py"), "hold", H4, "8080", "--duration", "6", "--interval", "0.2"])
    assert json.loads(hold.stdout.readline())["event"] == "connected"
    # revision without app access for clients: new connections denied, existing flow continues
    d = yaml.safe_load(ptext("host-rev1.yaml"))
    d["policy"]["revision"] = 2
    d["rules"] = [r for r in d["rules"] if r["id"] != "app-clients"]
    engine.apply(yaml.safe_dump(d), actor="lab")
    t_policy = time.monotonic()
    assert lab.tcp("ok", H4, 8080, timeout=1) == "timeout"
    time.sleep(1.0)
    out = engine.conntrack_delete(ConntrackFilter("ipv4", source="10.77.0.20", protocol="tcp", dport=8080), actor="lab", reason="revoke existing session")
    assert out["deleted"] >= 1
    lines = [json.loads(x) for x in hold.stdout.read().splitlines() if x.strip()]
    hold.wait(timeout=15)
    exchanges = [x for x in lines if x["event"] == "exchange"]
    assert exchanges
    before_delete = exchanges[: max(1, len(exchanges) // 4)]
    assert all(x["ok"] for x in before_delete), "established flow should survive the policy change"
    assert not exchanges[-1]["ok"], "flow should stop after its conntrack entry is removed"
    recs = [r for r in engine.audit.records() if r["action"] == "conntrack_delete"]
    assert [r["outcome"] for r in recs] == ["requested", "ok"]
    _ = t_policy


# --------------------------------------------------------------------------
# Real daemon: timed rollback, process termination and restart
# --------------------------------------------------------------------------


@pytest.fixture
def daemon(lab, tmp_path):
    state, logs = str(tmp_path / "state"), str(tmp_path / "logs")
    os.makedirs(logs)
    sock = str(tmp_path / "helper.sock")
    NftablesBackend(CommandRunner(netns_prefix(lab.ns["host"]))).remove()
    ctx = {"lab": lab, "state": state, "logs": logs, "sock": sock}

    def start():
        ctx["proc"] = lab.start_helper("host", state, sock, logs)
        return AdminClient(sock, timeout=60)

    def kill9():
        ctx["proc"].send_signal(signal.SIGKILL)
        ctx["proc"].wait(timeout=10)
        if os.path.exists(sock):
            os.unlink(sock)

    ctx["start"], ctx["kill9"] = start, kill9
    yield ctx
    if ctx.get("proc") and ctx["proc"].poll() is None:
        ctx["proc"].terminate()
        ctx["proc"].wait(timeout=10)
    NftablesBackend(CommandRunner(netns_prefix(lab.ns["host"]))).remove()


def wait_for(fn, timeout=15.0, interval=0.2):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        v = fn()
        if v:
            return v
        time.sleep(interval)
    return fn()


def test_timed_rollback_after_lost_management_access(daemon):
    lab, c = daemon["lab"], daemon["start"]()
    assert c.call("apply", policy_text=ptext("host-rev1.yaml"))["status"] == "active"
    assert lab.tcp("mgmt", H4, 2222) == "open"
    res = c.call("apply", policy_text=ptext("host-lockout.yaml"), confirm_timeout=5)
    assert res["status"] == "pending-confirmation"
    # the administrator can no longer open a management session to confirm
    assert lab.tcp("mgmt", H4, 2222, timeout=1) == "timeout"
    if lab.ipv6:
        assert lab.tcp("mgmt", H6, 2222, timeout=1) == "timeout"
    st = wait_for(lambda: (s := c.call("status"))["state"] == "active" and s["installed"]["revision"] == 1 and s)
    assert st, "helper timer did not roll back the unconfirmed change"
    assert lab.tcp("mgmt", H4, 2222) == "open"
    if lab.ipv6:
        assert lab.tcp("mgmt", H6, 2222) == "open"
    assert_rev1_traffic(lab)
    ok, n, _ = verify_chain(os.path.join(daemon["logs"], "audit.jsonl"))
    assert ok and n > 0
    actions = [json.loads(line)["action"] for line in open(os.path.join(daemon["logs"], "audit.jsonl"))]
    assert "rollback" in actions


def test_process_termination_during_pending_change(daemon):
    lab, c = daemon["lab"], daemon["start"]()
    c.call("apply", policy_text=ptext("host-rev1.yaml"))
    c.call("apply", policy_text=ptext("host-rev2.yaml"), confirm_timeout=600)
    assert lab.tcp("ok", H4, 9090) == "open"  # rev2 is in the kernel, uncommitted
    daemon["kill9"]()
    assert lab.tcp("ok", H4, 9090) == "open"  # kernel state survives the process
    c = daemon["start"]()
    st = c.call("status")
    assert st["last_recovery"]["action"] == "rolled-back-unconfirmed"
    assert st["state"] == "active" and st["installed"]["revision"] == 1
    assert_rev1_traffic(lab)


def test_restart_preserves_committed_state(daemon):
    lab, c = daemon["lab"], daemon["start"]()
    c.call("apply", policy_text=ptext("host-rev1.yaml"))
    c.call("apply", policy_text=ptext("host-rev2.yaml"))
    fp = c.call("status")["installed"]["fingerprint"]
    # plain restart: verified, not re-applied
    daemon["kill9"]()
    c = daemon["start"]()
    st = c.call("status")
    assert st["last_recovery"]["action"] == "verified"
    assert st["state"] == "active" and st["installed"]["fingerprint"] == fp
    # reboot-like restart: kernel ruleset lost, helper reinstalls the last-known-good
    daemon["kill9"]()
    lab.nft("host", "delete", "table", "inet", "london_cipher")
    assert lab.tcp("deny", H4, 9090) == "open"
    c = daemon["start"]()
    st = c.call("status")
    assert st["last_recovery"]["action"] == "reinstalled"
    assert st["state"] == "active" and st["installed"]["revision"] == 2
    assert lab.tcp("ok", H4, 9090) == "open"
    assert lab.tcp("deny", H4, 9090, timeout=1) == "timeout"
    assert lab.tcp("mgmt", H4, 2222) == "open"


# --------------------------------------------------------------------------
# Gateway capability (separately tested): forwarding, masquerade, port forward
# --------------------------------------------------------------------------


def test_gateway_forwarding_and_nat(lab, tmp_path):
    backend = NftablesBackend(CommandRunner(netns_prefix(lab.ns["gw"])))
    eng = Engine(backend, StateStore(str(tmp_path / "gw")))
    try:
        # without NAT, outer has no IPv4 route back to the inside network
        assert lab.tcp("inner", "10.79.0.2", 8080, timeout=1) == "timeout"
        assert eng.apply(ptext("gateway.yaml"), actor="lab")["status"] == "active"
        assert lab.tcp("inner", "10.79.0.2", 8080) == "open"  # forward + masquerade
        assert lab.tcp("inner", "10.79.0.2", 9000, timeout=1) == "timeout"  # not permitted
        assert lab.tcp("outer", "10.79.0.1", 8081, expect=8080) == "open"  # port forward to inner:8080
        assert lab.tcp("outer", "10.79.0.1", 22, timeout=1) == "timeout"  # gateway input drop
        if lab.ipv6:
            assert lab.tcp("inner", "fd79::2", 8080) == "open"  # routed IPv6, no NAT
            assert lab.tcp("inner", "fd79::2", 9000, timeout=1) == "timeout"
            assert lab.tcp("outer", "fd78::2", 8080, timeout=1) == "timeout"  # no inbound v6 forward
    finally:
        backend.remove()


# --------------------------------------------------------------------------
# Optional capabilities against real packets: DNS-derived egress, detection blocks
# --------------------------------------------------------------------------


def _egress_policy(rev: int = 1) -> str:
    d = yaml.safe_load(ptext("host-rev1.yaml"))
    d["policy"] = {"id": "lab-egress", "revision": rev}
    d["defaults"]["output"] = "drop"
    d["dynamic_sets"] = {
        "partners": {"family": "ipv4", "source": "dns", "max_elements": 8},
        "blocked_now": {"family": "ipv4", "source": "detection", "max_elements": 8, "timeout_seconds": 120},
    }
    d["rules"].insert(0, {"id": "detected-drop", "chain": "input", "action": "drop", "family": "ipv4", "source": {"sets": ["blocked_now"]}, "justification": "approved detection blocks"})
    d["rules"].append({"id": "egress-partners", "chain": "output", "action": "accept", "family": "ipv4", "destination": {"sets": ["partners"]}, "protocol": "tcp", "ports": [7000], "justification": "only resolved partner hosts"})
    return yaml.safe_dump(d, sort_keys=False)


def test_dns_derived_egress_set(lab, engine):
    from cipher_intel import DnsSetConfig, DnsSetUpdater, EngineSubmitter
    from cipher_intel.dnsclient import local_test_resolver

    engine.apply(_egress_policy(), actor="lab")
    assert lab.tcp("host", "10.77.0.20", 7000, timeout=1) == "timeout"  # egress denied: set empty
    port, stop = local_test_resolver({("partner.lab.test", "A"): [("10.77.0.20", 60)]})
    try:
        u = DnsSetUpdater(DnsSetConfig("partners", "ipv4", ["partner.lab.test"], "127.0.0.1", resolver_port=port), EngineSubmitter(engine, "system:dns"))
        assert u.refresh()["status"] == "updated"
    finally:
        stop()
    assert lab.tcp("host", "10.77.0.20", 7000) == "open"
    # inbound replies on established flows still work; loopback still works under output drop
    assert lab.tcp("ok", H4, 8080) == "open"
    assert lab.tcp("host", "127.0.0.1", 8080) == "open"
    # membership survives a policy revision (restored from the store, applied atomically)
    engine.apply(_egress_policy(2), actor="lab")
    assert lab.tcp("host", "10.77.0.20", 7000) == "open"
    assert "10.77.0.20" in lab.nft("host", "list", "set", "inet", "london_cipher", "dyn_partners").stdout


def test_detection_block_set_expires_in_kernel(lab, engine):
    engine.apply(_egress_policy(), actor="lab")
    assert lab.tcp("ok", H4, 8080) == "open"
    engine.update_dynamic_set("blocked_now", ["10.77.0.20"], source="detection", actor="lab", provenance={"proposal": 1}, element_ttls=[3])
    listing = lab.nft("host", "list", "set", "inet", "london_cipher", "dyn_blocked_now").stdout
    assert "10.77.0.20" in listing and "expires" in listing
    assert lab.tcp("ok", H4, 8080, timeout=1) == "timeout"
    time.sleep(3.5)
    assert lab.tcp("ok", H4, 8080) == "open"  # the kernel expired the block on its own


def test_cli_admind_helper_end_to_end(daemon, tmp_path):
    """Full privilege-separated path: `cipher` CLI -> cipher-admind -> cipher-helper -> kernel."""
    import subprocess
    import sys

    lab = daemon["lab"]
    daemon["start"]()
    admin_sock = str(tmp_path / "admin.sock")
    root = os.path.dirname(os.path.dirname(HERE))
    env = dict(os.environ, PYTHONPATH=root)
    admind = subprocess.Popen(
        [sys.executable, "-m", "cipher_admin.admind", "--socket", admin_sock, "--helper-socket", daemon["sock"], "--audit-log", str(tmp_path / "admin-audit.jsonl")],
        env=env, cwd=root, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
    )
    try:
        assert wait_for(lambda: os.path.exists(admin_sock), timeout=10)

        def cli(*args):
            r = subprocess.run([sys.executable, "-m", "cipher_cli", "--socket", admin_sock, "--json", *args], env=env, cwd=root, capture_output=True, text=True, timeout=120)
            return r.returncode, (json.loads(r.stdout) if r.stdout.strip() else None), r.stderr

        rc, out, err = cli("apply", "--yes", "--confirm-timeout", "30", os.path.join(POL, "host-rev1.yaml"))
        assert rc == 0, err
        assert out["status"] == "pending-confirmation"
        assert lab.tcp("ok", H4, 8080) == "open"
        rc, out, _ = cli("confirm")
        assert rc == 0 and out["status"] == "active"
        rc, out, _ = cli("status")
        assert rc == 0 and out["state"] == "active" and out["lkg"]["revision"] == 1
        rc, out, err = cli("apply", "--yes", os.path.join(POL, "host-rev1.yaml").replace("rev1", "rev2"))
        assert rc == 0 and out["status"] == "active", err
        assert lab.tcp("ok", H4, 9090) == "open"
        bad = tmp_path / "bad.yaml"
        bad.write_text(ptext("host-rev2.yaml").replace("revision: 2", "revision: 3").replace("ports: [9090]", "ports: [0]"))
        rc, _, err = cli("apply", "--yes", str(bad))
        assert rc == 1 and "policy" in err.lower()
        rc, out, _ = cli("rollback", "--reason", "e2e")
        assert rc == 0 and out["restored"] == "lkg"
        audit = [json.loads(line) for line in open(tmp_path / "admin-audit.jsonl")]
        assert {"allowed"} <= {a["outcome"] for a in audit}
        assert all(a["actor"].startswith("uid:0(") for a in audit)
        assert verify_chain(str(tmp_path / "admin-audit.jsonl"))[0]
    finally:
        admind.terminate()
        admind.wait(timeout=10)
