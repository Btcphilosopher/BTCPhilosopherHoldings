"""Shared fixtures for unit and integration tests."""

from __future__ import annotations

import copy
import os
import sys

import pytest
import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from cipher_backend import MemoryBackend  # noqa: E402
from cipher_events import AuditLog, EventBus  # noqa: E402
from cipher_state import Engine, StateStore  # noqa: E402

BASE = {
    "schema_version": 1,
    "policy": {"id": "unit", "revision": 1},
    "interfaces": {"eth0": {"zone": "lan"}, "eth1": {"zone": "mgmt"}},
    "zones": {"lan": {}, "mgmt": {"networks": ["10.9.0.0/24", "fd00:9::/64"]}},
    "address_sets": {"admins": {"addresses": ["192.0.2.0/28", "2001:db8::/64"]}, "web4": {"addresses": ["198.51.100.0/24"]}},
    "service_sets": {"web": {"services": [{"protocol": "tcp", "ports": [80, 443]}, {"protocol": "udp", "ports": [443]}]}},
    "defaults": {"input": "drop", "output": "accept", "forward": "drop"},
    "rules": [
        {"id": "ssh", "chain": "input", "action": "accept", "source": {"sets": ["admins"]}, "protocol": "tcp", "ports": [22], "justification": "admin ssh"},
        {"id": "web", "chain": "input", "action": "accept", "services": ["web"], "justification": "public web"},
    ],
}


def policy_dict(**overrides):
    d = copy.deepcopy(BASE)
    for k, v in overrides.items():
        d[k] = v
    return d


def policy_text(**overrides) -> str:
    return yaml.safe_dump(policy_dict(**overrides), sort_keys=False)


class FakeClock:
    def __init__(self, t: float = 1_800_000_000.0):
        self.t = t

    def __call__(self) -> float:
        return self.t

    def advance(self, s: float) -> None:
        self.t += s


@pytest.fixture
def clock():
    return FakeClock()


@pytest.fixture
def make_engine(tmp_path, clock):
    def _make(backend=None, **kw):
        backend = backend or MemoryBackend(persist_path=str(tmp_path / "kernel.json"))
        eng = Engine(
            backend,
            StateStore(str(tmp_path / "state")),
            audit=AuditLog(str(tmp_path / "audit.jsonl"), fsync=False),
            bus=EventBus(),
            clock=clock,
            **kw,
        )
        return eng, backend

    return _make


EXAMPLES = os.path.join(ROOT, "examples", "policies")
