"""Crash-safe persistent state for deployments.

Layout under ``state_dir`` (mode 0700, owned by the privileged helper)::

    lock                 advisory lock serialising all mutating operations
    lkg/policy.txt       last-known-good policy (verbatim text)
    lkg/record.json      its deployment record
    pending/policy.txt   applied-but-unconfirmed policy (timed rollback armed)
    pending/record.json  includes the confirmation deadline
    journal.json         write-ahead intent for an in-flight operation
    dynamic/<set>.json   current members (+ provenance) of dynamic sets
    history/*.json       bounded history of deployment records

All writes use write-to-temp + fsync + rename + directory fsync, so after a
crash every file is either the old or the new version, never torn.
"""

from __future__ import annotations

import fcntl
import json
import os
import time
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from typing import Any, Iterator, Optional

from cipher_types import StateError

HISTORY_LIMIT = 50


@dataclass
class DeploymentRecord:
    policy_id: str
    revision: int
    digest: str
    policy_sha256: str
    actor: str
    applied_at: float
    source: str  # apply | rollback | restore | expiry
    fingerprint: Optional[str] = None
    committed_at: Optional[float] = None
    deadline: Optional[float] = None
    previous_digest: Optional[str] = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "DeploymentRecord":
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in known})


def _fsync_dir(path: str) -> None:
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def atomic_write(path: str, data: bytes, mode: int = 0o600) -> None:
    d = os.path.dirname(os.path.abspath(path))
    os.makedirs(d, mode=0o700, exist_ok=True)
    tmp = f"{path}.tmp.{os.getpid()}"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode)
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(tmp, path)
    _fsync_dir(d)


class StateStore:
    def __init__(self, state_dir: str):
        self.dir = os.path.abspath(state_dir)
        os.makedirs(self.dir, mode=0o700, exist_ok=True)
        for sub in ("lkg", "pending", "dynamic", "history"):
            os.makedirs(os.path.join(self.dir, sub), mode=0o700, exist_ok=True)

    def _p(self, *parts: str) -> str:
        return os.path.join(self.dir, *parts)

    @contextmanager
    def locked(self, timeout: float = 30.0) -> Iterator[None]:
        fd = os.open(self._p("lock"), os.O_RDWR | os.O_CREAT, 0o600)
        deadline = time.monotonic() + timeout
        try:
            while True:
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    if time.monotonic() > deadline:
                        raise StateError("another LONDON CIPHER operation holds the state lock") from None
                    time.sleep(0.05)
            yield
        finally:
            try:
                fcntl.flock(fd, fcntl.LOCK_UN)
            finally:
                os.close(fd)

    # -- json helpers ---------------------------------------------------------
    def _read_json(self, *parts: str) -> Optional[dict[str, Any]]:
        p = self._p(*parts)
        if not os.path.exists(p):
            return None
        try:
            with open(p) as fh:
                return json.load(fh)
        except ValueError as exc:
            raise StateError(f"corrupt state file {p}: {exc}") from None

    def _write_json(self, obj: Any, *parts: str) -> None:
        atomic_write(self._p(*parts), json.dumps(obj, indent=1, sort_keys=True).encode())

    def _remove(self, *parts: str) -> None:
        p = self._p(*parts)
        if os.path.exists(p):
            os.unlink(p)
            _fsync_dir(os.path.dirname(p))

    # -- slots (lkg / pending) ------------------------------------------------
    def read_slot(self, slot: str) -> Optional[tuple[str, DeploymentRecord]]:
        rec = self._read_json(slot, "record.json")
        if rec is None:
            return None
        p = self._p(slot, "policy.txt")
        if not os.path.exists(p):
            raise StateError(f"{slot} record exists without its policy text")
        with open(p, encoding="utf-8") as fh:
            return fh.read(), DeploymentRecord.from_dict(rec)

    def write_slot(self, slot: str, text: str, record: DeploymentRecord) -> None:
        # policy first, then record: a record is only ever visible with its text
        atomic_write(self._p(slot, "policy.txt"), text.encode("utf-8"))
        self._write_json(record.to_dict(), slot, "record.json")

    def clear_slot(self, slot: str) -> None:
        self._remove(slot, "record.json")
        self._remove(slot, "policy.txt")

    # -- journal ------------------------------------------------------------------
    def read_journal(self) -> Optional[dict[str, Any]]:
        return self._read_json("journal.json")

    def write_journal(self, entry: dict[str, Any]) -> None:
        self._write_json(dict(entry, written_at=time.time()), "journal.json")

    def clear_journal(self) -> None:
        self._remove("journal.json")

    # -- history --------------------------------------------------------------------
    def append_history(self, record: DeploymentRecord) -> None:
        name = f"{int(record.applied_at * 1000):016d}-{record.revision}-{record.source}.json"
        self._write_json(record.to_dict(), "history", name)
        files = sorted(os.listdir(self._p("history")))
        for old in files[:-HISTORY_LIMIT]:
            os.unlink(self._p("history", old))

    def history(self) -> list[DeploymentRecord]:
        out = []
        for name in sorted(os.listdir(self._p("history"))):
            if name.endswith(".json"):
                d = self._read_json("history", name)
                if d:
                    out.append(DeploymentRecord.from_dict(d))
        return out

    # -- dynamic sets ------------------------------------------------------------------
    def read_dynamic(self, name: str) -> Optional[dict[str, Any]]:
        return self._read_json("dynamic", f"{name}.json")

    def write_dynamic(self, name: str, data: dict[str, Any]) -> None:
        self._write_json(data, "dynamic", f"{name}.json")

    def dynamic_names(self) -> list[str]:
        return sorted(n[:-5] for n in os.listdir(self._p("dynamic")) if n.endswith(".json"))
