"""Safe deployment engine: Validate -> Compile -> Review -> Apply -> Verify -> Commit.

Guarantees (each is exercised by tests; see docs/deployment-safety.md):

1. **Nothing reaches enforcement unless validation and compilation succeed and
   the backend's dry-run accepts the artefact.**
2. **Atomic install.** The backend replaces the managed namespace in one
   transaction; a rejected transaction leaves the previous ruleset in place,
   which the engine then *verifies* (and restores if needed).
3. **Never "active" before verification.** A policy is reported active only
   after the installed state has been read back and matched to the compiled IR.
4. **Write-ahead journal.** Intent is persisted before the kernel is touched.
   If the process dies mid-operation, :meth:`Engine.recover` finds the journal
   and restores the last-known-good (LKG) policy.
5. **Timed rollback.** With ``confirm_timeout`` the new policy is installed but
   not committed. Unless :meth:`confirm` is called before the deadline,
   :meth:`tick` (driven by the helper's timer thread) restores the LKG. An
   unconfirmed change found at startup is also rolled back.
6. **LKG only advances on commit.** Rollback always targets a policy that was
   previously verified *and* committed (or the absence of any managed table).

What it cannot recover from (requires out-of-band access) is documented in
docs/deployment-safety.md: e.g. a committed policy that itself locks
administrators out, a helper that never runs again, or foreign rules outside
the managed namespace.
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Optional

from cipher_backend.base import ConntrackFilter, DynamicElement, EnforcementBackend
from cipher_compiler import CompileResult, RulesetDiff, compile_policy, diff_rulesets, review_listing
from cipher_events import AuditLog, Event, EventBus
from cipher_policy import validate_text
from cipher_policy.model import Policy
from cipher_types import (
    TABLE_NAME,
    BackendError,
    CipherError,
    ConflictError,
    Issue,
    LimitExceeded,
    PolicyError,
    Severity,
    StateError,
    VerificationError,
)
from cipher_types.ir import IRRuleset

from .store import DeploymentRecord, StateStore

MAX_CONFIRM_TIMEOUT = 3600
MIN_CONFIRM_TIMEOUT = 5


def _collapsed(values: list[str]) -> list[str]:
    import ipaddress

    nets = [ipaddress.ip_network(v) for v in values]
    out: list[str] = []
    for ver in (4, 6):
        out.extend(str(n) for n in ipaddress.collapse_addresses(n for n in nets if n.version == ver))
    return out


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


@dataclass
class Plan:
    policy: Policy
    compiled: CompileResult
    diff: RulesetDiff
    warnings: list[Issue]
    conflicts: dict[str, Any]
    capabilities: dict[str, Any]
    artefact: str

    @property
    def ruleset(self) -> IRRuleset:
        return self.compiled.ruleset

    def to_dict(self, include_artefact: bool = False) -> dict[str, Any]:
        d = {
            "policy_id": self.ruleset.policy_id,
            "revision": self.ruleset.revision,
            "digest": self.ruleset.digest,
            "warnings": [w.to_dict() for w in self.warnings],
            "diff": self.diff.to_dict(),
            "summary": self.diff.summary(),
            "conflicts": self.conflicts,
            "capabilities": self.capabilities,
            "parity": self.compiled.parity,
            "excluded_rules": [list(x) for x in self.ruleset.excluded_rules],
            "listing": review_listing(self.ruleset),
        }
        if include_artefact:
            d["artefact"] = self.artefact
        return d


class Engine:
    def __init__(
        self,
        backend: EnforcementBackend,
        store: StateStore,
        *,
        audit: Optional[AuditLog] = None,
        bus: Optional[EventBus] = None,
        clock: Callable[[], float] = time.time,
        faults: Optional[Callable[[str], None]] = None,
        conflict_policy: str = "refuse-managers",
        table: str = TABLE_NAME,
    ):
        if conflict_policy not in ("refuse-managers", "warn"):
            raise ValueError("conflict_policy must be 'refuse-managers' or 'warn'")
        self.backend = backend
        self.store = store
        self.audit = audit
        self.bus = bus or EventBus()
        self.clock = clock
        self.faults = faults or (lambda point: None)
        self.conflict_policy = conflict_policy
        self.table = table
        self._cache: dict[str, tuple[datetime, Optional[datetime], tuple[Policy, CompileResult, list[Issue]]]] = {}

    # -- small helpers -----------------------------------------------------------
    def _now_dt(self) -> datetime:
        return datetime.fromtimestamp(self.clock(), tz=timezone.utc)

    def _audit(self, action: str, actor: str, outcome: str, **details: Any) -> None:
        if self.audit is not None:
            self.audit.record(action, actor=actor, outcome=outcome, **details)

    def _event(self, stage: str, status: str, message: str = "", rs: Optional[IRRuleset] = None, **details: Any) -> None:
        self.bus.publish(
            Event(
                kind="deploy",
                component="cipher_state.engine",
                status=status,
                message=message,
                policy_id=rs.policy_id if rs else None,
                policy_revision=rs.revision if rs else None,
                details=dict(details, stage=stage),
            )
        )

    def _compile_text(self, text: str) -> tuple[Policy, CompileResult, list[Issue]]:
        """Validate + compile, memoised per policy text.

        A cached result is reused only while it is provably identical: the
        clock is at or after the time it was compiled and before the next
        rule expiry it contains (expiry is the only time dependence).
        """
        now = self._now_dt()
        key = _sha(text)
        hit = self._cache.get(key)
        if hit is not None:
            compiled_at, valid_until, value = hit
            if compiled_at <= now and (valid_until is None or now < valid_until):
                return value
        policy, warnings = validate_text(text, now=now)
        result = compile_policy(policy, now=now, table=self.table)
        value = (policy, result, warnings + result.warnings)
        nxt = result.ruleset.next_expiry
        if len(self._cache) >= 8:
            self._cache.pop(next(iter(self._cache)))
        self._cache[key] = (now, datetime.fromisoformat(nxt) if nxt else None, value)
        return value

    def _dynamic_for(self, rs: IRRuleset) -> dict[str, list[DynamicElement]]:
        now = self.clock()
        out: dict[str, list[DynamicElement]] = {}
        for s in rs.sets:
            if not s.dynamic:
                continue
            data = self.store.read_dynamic(s.name[len("dyn_"):])
            if not data or data.get("source") != s.source:
                continue
            elems = []
            for e in data.get("elements", []):
                exp = e.get("expires_at")
                if exp is not None and exp <= now:
                    continue
                elems.append(DynamicElement(e["value"], int(exp - now) if exp is not None else None))
            out[s.name] = elems[: s.max_elements]
        return out

    def _current_slot(self) -> Optional[tuple[str, str, DeploymentRecord]]:
        """The policy that *should* be installed now: pending if any, else LKG."""
        p = self.store.read_slot("pending")
        if p:
            return ("pending", *p)
        l = self.store.read_slot("lkg")
        if l:
            return ("lkg", *l)
        return None

    def _check_capabilities(self, rs: IRRuleset) -> dict[str, Any]:
        caps = self.backend.capabilities()
        caps.require(self.backend.required_features(rs))
        return {"backend": caps.backend, "version": caps.version, "features": sorted(caps.features)}

    def _check_conflicts(self, allow_conflicts: bool) -> dict[str, Any]:
        rep = self.backend.conflicts()
        if rep.has_managers and self.conflict_policy == "refuse-managers" and not allow_conflicts:
            raise ConflictError(
                "other firewall managers are active: "
                + ", ".join(rep.managers)
                + ". LONDON CIPHER will not compete with them; disable them or pass allow_conflicts explicitly."
            )
        return rep.to_dict()

    # -- planning -----------------------------------------------------------------
    def plan(self, text: str, *, allow_conflicts: bool = False) -> Plan:
        """Validate, compile, capability-check, conflict-check, dry-run and diff.

        Never changes enforcement.
        """
        policy, result, warnings = self._compile_text(text)
        rs = result.ruleset
        caps = self._check_capabilities(rs)
        conflicts = self._check_conflicts(allow_conflicts)
        dyn = self._dynamic_for(rs)
        self.backend.check(rs, dyn)
        current = None
        cur = self._current_slot()
        if cur:
            try:
                _, cur_res, _ = self._compile_text(cur[1])
                current = cur_res.ruleset
            except PolicyError:
                current = None
        return Plan(policy, result, diff_rulesets(current, rs), warnings, conflicts, caps, self.backend.render(rs, dyn))

    def _check_revision(self, rs: IRRuleset) -> None:
        lkg = self.store.read_slot("lkg")
        if not lkg:
            return
        rec = lkg[1]
        if rec.policy_id != rs.policy_id:
            return
        if rs.revision < rec.revision:
            raise PolicyError([Issue(Severity.ERROR, "revision.regression", "/policy/revision", f"revision {rs.revision} is older than the committed revision {rec.revision}; use rollback to return to an earlier policy")])
        if rs.revision == rec.revision and rs.digest != rec.digest:
            raise PolicyError([Issue(Severity.ERROR, "revision.reuse", "/policy/revision", f"revision {rs.revision} is already committed with different content; increment the revision")])

    # -- install / restore primitives ----------------------------------------
    def _install(self, rs: IRRuleset) -> str:
        """Apply and verify; returns the installed fingerprint."""
        dyn = self._dynamic_for(rs)
        self.backend.apply(rs, dyn)
        self.faults("after_backend_apply")
        st = self.backend.verify(rs)
        return st.fingerprint or ""

    def _restore_lkg(self, actor: str, reason: str) -> dict[str, Any]:
        lkg = self.store.read_slot("lkg")
        try:
            if lkg:
                text, rec = lkg
                _, res, _ = self._compile_text(text)
                fp = self._install(res.ruleset)
                rec.fingerprint = fp
                rec.extra["next_expiry"] = res.ruleset.next_expiry
                rec.digest = res.ruleset.digest
                self.store.write_slot("lkg", text, rec)
                outcome = {"restored": "lkg", "policy_id": rec.policy_id, "revision": rec.revision}
            else:
                self.backend.remove()
                if self.backend.inspect().present:
                    raise VerificationError("managed table still present after removal")
                outcome = {"restored": "none", "note": "no committed policy existed; managed table removed"}
        except CipherError as exc:
            self._audit("rollback", actor, "critical-failure", reason=reason, error=str(exc))
            self._event("rollback", "error", f"rollback failed: {exc}")
            raise StateError(
                f"CRITICAL: rollback failed ({exc}). Enforcement state is unknown; use out-of-band access "
                "and see docs/deployment-safety.md#manual-recovery"
            ) from exc
        self.store.clear_slot("pending")
        self.store.clear_journal()
        self._audit("rollback", actor, "ok", reason=reason, **outcome)
        self._event("rollback", "ok", reason, **outcome)
        return outcome

    # -- public operations ---------------------------------------------------------
    def apply(self, text: str, *, actor: str, confirm_timeout: Optional[int] = None, allow_conflicts: bool = False) -> dict[str, Any]:
        if confirm_timeout is not None and not (MIN_CONFIRM_TIMEOUT <= confirm_timeout <= MAX_CONFIRM_TIMEOUT):
            raise LimitExceeded(f"confirm_timeout must be between {MIN_CONFIRM_TIMEOUT} and {MAX_CONFIRM_TIMEOUT} seconds")
        with self.store.locked():
            if self.store.read_journal():
                raise StateError("an interrupted operation is recorded in the journal; run recovery first")
            if self.store.read_slot("pending"):
                raise StateError("a change is awaiting confirmation; confirm or roll it back first")
            try:
                plan = self.plan(text, allow_conflicts=allow_conflicts)
                self._check_revision(plan.ruleset)
            except CipherError as exc:
                self._audit("apply", actor, "rejected", stage="plan", error=str(exc), policy_sha256=_sha(text))
                self._event("plan", "rejected", str(exc))
                raise
            rs = plan.ruleset
            lkg = self.store.read_slot("lkg")
            prev_digest = lkg[1].digest if lkg else None
            self.store.write_journal({"op": "apply", "phase": "installing", "target_digest": rs.digest, "previous_digest": prev_digest, "actor": actor})
            self.faults("after_journal")
            try:
                fp = self._install(rs)
            except (BackendError, VerificationError) as exc:
                self._audit("apply", actor, "failed", stage="install", error=str(exc), revision=rs.revision, digest=rs.digest)
                self._event("install", "error", str(exc), rs)
                restored = self._restore_lkg(actor, f"apply of revision {rs.revision} failed: {exc}")
                raise BackendError(f"apply failed and previous state was restored ({restored['restored']}): {exc}") from exc
            now = self.clock()
            record = DeploymentRecord(
                policy_id=rs.policy_id,
                revision=rs.revision,
                digest=rs.digest,
                policy_sha256=_sha(text),
                actor=actor,
                applied_at=now,
                source="apply",
                fingerprint=fp,
                previous_digest=prev_digest,
                extra={"next_expiry": rs.next_expiry},
            )
            self.faults("after_verify")
            if confirm_timeout:
                record.deadline = now + confirm_timeout
                # pending slot is durable before the journal is cleared, so a
                # crash between the two is still recovered (journal -> LKG).
                self.store.write_slot("pending", text, record)
                self.store.clear_journal()
                self._audit("apply", actor, "pending-confirmation", revision=rs.revision, digest=rs.digest, deadline=record.deadline, summary=plan.diff.summary())
                self._event("verify", "ok", "installed and verified; awaiting confirmation", rs, deadline=record.deadline)
                return {"status": "pending-confirmation", "policy_id": rs.policy_id, "revision": rs.revision, "digest": rs.digest, "deadline": record.deadline, "seconds_remaining": confirm_timeout, "summary": plan.diff.summary(), "warnings": [w.to_dict() for w in plan.warnings]}
            self._commit(text, record, actor)
            self._event("commit", "ok", "installed, verified and committed", rs)
            return {"status": "active", "policy_id": rs.policy_id, "revision": rs.revision, "digest": rs.digest, "fingerprint": fp, "summary": plan.diff.summary(), "warnings": [w.to_dict() for w in plan.warnings]}

    def _commit(self, text: str, record: DeploymentRecord, actor: str) -> None:
        record.committed_at = self.clock()
        record.deadline = None
        self.store.write_slot("lkg", text, record)
        self.store.clear_slot("pending")
        self.store.clear_journal()
        self.store.append_history(record)
        self._audit("commit", actor, "ok", policy_id=record.policy_id, revision=record.revision, digest=record.digest)

    def confirm(self, *, actor: str) -> dict[str, Any]:
        with self.store.locked():
            pending = self.store.read_slot("pending")
            if not pending:
                raise StateError("no change is awaiting confirmation")
            text, rec = pending
            if rec.deadline is not None and self.clock() >= rec.deadline:
                outcome = self._restore_lkg("system:timer", "confirmation arrived after the deadline")
                raise StateError(f"confirmation deadline passed; change was rolled back ({outcome['restored']})")
            _, res, _ = self._compile_text(text)
            try:
                st = self.backend.verify(res.ruleset)
            except VerificationError as exc:
                self._audit("confirm", actor, "refused", error=str(exc))
                outcome = self._restore_lkg(actor, f"pending policy no longer verifies: {exc}")
                raise StateError(f"pending policy no longer verifies; rolled back ({outcome['restored']})") from exc
            rec.fingerprint = st.fingerprint
            self._commit(text, rec, actor)
            self._audit("confirm", actor, "ok", revision=rec.revision)
            return {"status": "active", "policy_id": rec.policy_id, "revision": rec.revision, "digest": rec.digest}

    def rollback(self, *, actor: str, reason: str = "operator request") -> dict[str, Any]:
        with self.store.locked():
            return self._restore_lkg(actor, reason)

    def tick(self) -> Optional[dict[str, Any]]:
        """Timer work: confirmation deadlines and rule expiry. Safe to call often."""
        with self.store.locked():
            pending = self.store.read_slot("pending")
            if pending:
                _, rec = pending
                if rec.deadline is not None and self.clock() >= rec.deadline:
                    out = self._restore_lkg("system:timer", f"revision {rec.revision} not confirmed before deadline")
                    return {"event": "timed-rollback", **out}
                return None
            lkg = self.store.read_slot("lkg")
            if lkg and not self.store.read_journal():
                text, rec = lkg
                nxt = rec.extra.get("next_expiry")
                if nxt and self._now_dt() >= datetime.fromisoformat(nxt):
                    _, res, _ = self._compile_text(text)
                    self.store.write_journal({"op": "expiry", "phase": "installing", "target_digest": res.ruleset.digest})
                    try:
                        fp = self._install(res.ruleset)
                    except (BackendError, VerificationError) as exc:
                        self._audit("expiry", "system:timer", "failed", error=str(exc))
                        out = self._restore_lkg("system:timer", f"expiry recompile failed: {exc}")
                        return {"event": "expiry-failed", **out}
                    rec.digest, rec.fingerprint = res.ruleset.digest, fp
                    rec.extra["next_expiry"] = res.ruleset.next_expiry
                    rec.source = "expiry"
                    rec.applied_at = self.clock()
                    self.store.write_slot("lkg", text, rec)
                    self.store.clear_journal()
                    self._audit("expiry", "system:timer", "ok", excluded=[list(x) for x in res.ruleset.excluded_rules])
                    return {"event": "expiry", "excluded": [list(x) for x in res.ruleset.excluded_rules]}
        return None

    def recover(self, *, actor: str = "system:startup") -> dict[str, Any]:
        """Startup recovery. Call before serving requests.

        * journal present  -> process died mid-operation -> restore LKG
        * pending present  -> unconfirmed change survived a restart -> restore LKG
        * LKG present but managed table missing (e.g. after reboot) -> reinstall LKG
        * LKG present but installed state differs -> report ``drifted`` (and
          repair only when ``repair_drift`` is requested by the operator)
        """
        with self.store.locked():
            journal = self.store.read_journal()
            if journal:
                out = self._restore_lkg(actor, f"interrupted operation found at startup: {journal.get('op')}/{journal.get('phase')}")
                return {"action": "restored-after-interruption", **out}
            if self.store.read_slot("pending"):
                out = self._restore_lkg(actor, "unconfirmed change found at startup")
                return {"action": "rolled-back-unconfirmed", **out}
            lkg = self.store.read_slot("lkg")
            if not lkg:
                return {"action": "none", "note": "no committed policy"}
            text, rec = lkg
            st = self.backend.inspect()
            if not st.present:
                out = self._restore_lkg(actor, "managed table missing at startup (reboot or external removal)")
                return {"action": "reinstalled", **out}
            _, res, _ = self._compile_text(text)
            try:
                self.backend.verify(res.ruleset)
            except VerificationError as exc:
                self._audit("drift", actor, "detected", error=str(exc))
                return {"action": "drift-detected", "error": str(exc)}
            return {"action": "verified", "policy_id": rec.policy_id, "revision": rec.revision}

    def repair(self, *, actor: str) -> dict[str, Any]:
        """Operator-requested re-installation of the LKG over a drifted table."""
        with self.store.locked():
            return self._restore_lkg(actor, "operator-requested repair")

    def status(self) -> dict[str, Any]:
        cur = self._current_slot()
        installed = self.backend.inspect()
        out: dict[str, Any] = {"installed": installed.to_dict(), "journal": self.store.read_journal(), "events": self.bus.counters()}
        lkg = self.store.read_slot("lkg")
        out["lkg"] = lkg[1].to_dict() if lkg else None
        if cur is None:
            out["state"] = "unmanaged" if not installed.present else "unexpected-table"
            return out
        slot, text, rec = cur
        if slot == "pending":
            out["pending"] = dict(rec.to_dict(), seconds_remaining=max(0, round((rec.deadline or 0) - self.clock(), 1)))
        try:
            _, res, _ = self._compile_text(text)
            self.backend.verify(res.ruleset)
            fp_ok = rec.fingerprint is None or installed.fingerprint == rec.fingerprint
            out["state"] = ("pending-confirmation" if slot == "pending" else "active") if fp_ok else "drifted"
            if not fp_ok:
                out["problem"] = "installed fingerprint differs from the verified deployment"
        except VerificationError as exc:
            out["state"] = "missing" if not installed.present else "drifted"
            out["problem"] = str(exc)
        except PolicyError as exc:
            out["state"] = "unverifiable"
            out["problem"] = str(exc)
        return out

    def remove(self, *, actor: str) -> dict[str, Any]:
        """Remove the managed namespace and forget committed state (uninstall)."""
        with self.store.locked():
            removed = self.backend.remove()
            self.store.clear_slot("pending")
            self.store.clear_slot("lkg")
            self.store.clear_journal()
            self._audit("remove", actor, "ok", table_removed=removed)
            return {"removed": removed}

    # -- dynamic sets ----------------------------------------------------------------
    def update_dynamic_set(
        self,
        name: str,
        values: list[str],
        *,
        source: str,
        actor: str,
        provenance: dict[str, Any],
        ttl_seconds: Optional[int] = None,
        element_ttls: Optional[list[int]] = None,
    ) -> dict[str, Any]:
        """Atomically replace a dynamic set's members (bounded by the policy).

        Timeout (detection) sets need a lifetime per element: either one
        ``ttl_seconds`` for all, or ``element_ttls`` parallel to ``values``.
        Every lifetime is capped by the set's declared ``timeout_seconds``.
        """
        import ipaddress

        with self.store.locked():
            cur = self._current_slot()
            if cur is None:
                raise StateError("no policy installed")
            _, res, _ = self._compile_text(cur[1])
            rs = res.ruleset
            try:
                irset = rs.set(f"dyn_{name}")
            except KeyError:
                raise StateError(f"active policy declares no dynamic set {name!r}") from None
            if irset.source != source:
                raise StateError(f"dynamic set {name!r} accepts source {irset.source!r}, not {source!r}")
            if len(values) > irset.max_elements:
                self._audit("dynamic_set", actor, "rejected", set=name, reason="limit", count=len(values), limit=irset.max_elements)
                raise LimitExceeded(f"{len(values)} elements exceed the policy limit of {irset.max_elements} for set {name!r}")
            if element_ttls is not None and len(element_ttls) != len(values):
                raise StateError("element_ttls must be parallel to values")
            ttl_of: dict[str, int] = {}
            norm: list[str] = []
            for i, v in enumerate(values):
                n = ipaddress.ip_network(v, strict=True)
                if (n.version == 4) != (irset.family == "ipv4"):
                    raise StateError(f"{v} does not match family {irset.family} of set {name!r}")
                if irset.timeout and n.prefixlen != n.max_prefixlen:
                    raise StateError("timeout sets hold single addresses only")
                norm.append(str(n))
                if irset.timeout:
                    t = element_ttls[i] if element_ttls is not None else ttl_seconds
                    if not t or t <= 0:
                        raise StateError("detection-sourced sets require a positive ttl for every element")
                    ttl_of[str(n)] = int(t)
            norm = sorted(set(norm))
            now = self.clock()
            cap = self._set_timeout_cap(cur[1], name) if irset.timeout else None
            if cap:
                ttl_of = {k: min(v, cap) for k, v in ttl_of.items()}
            elems = [DynamicElement(v, ttl_of.get(v)) for v in norm]
            previous = self.store.read_dynamic(name)
            self.backend.update_dynamic_set(rs, irset, elems)
            installed = self.backend.read_dynamic_set(rs, irset)
            if not irset.timeout and _collapsed(installed) != _collapsed(norm):
                self._audit("dynamic_set", actor, "verify-failed", set=name)
                if previous:
                    prev_elems = [DynamicElement(e["value"], None) for e in previous.get("elements", [])]
                    self.backend.update_dynamic_set(rs, irset, prev_elems)
                raise VerificationError(f"dynamic set {name!r} contents did not verify after update")
            self.store.write_dynamic(
                name,
                {
                    "source": source,
                    "elements": [{"value": v, "expires_at": (now + ttl_of[v]) if v in ttl_of else None} for v in norm],
                    "provenance": provenance,
                    "updated_at": now,
                    "previous_count": len(previous.get("elements", [])) if previous else 0,
                },
            )
            self._audit("dynamic_set", actor, "ok", set=name, source=source, count=len(norm), provenance=provenance)
            return {"set": name, "count": len(norm), "status": "updated"}

    def _set_timeout_cap(self, text: str, name: str) -> Optional[int]:
        policy, _ = validate_text(text, now=self._now_dt())
        d = policy.dynamic_sets.get(name)
        return d.timeout_seconds if d else None

    # -- connection state -------------------------------------------------------------
    def conntrack_delete(self, flt: ConntrackFilter, *, actor: str, reason: str) -> dict[str, Any]:
        self._audit("conntrack_delete", actor, "requested", filter=flt.__dict__, reason=reason)
        n = self.backend.conntrack_delete(flt)
        self._audit("conntrack_delete", actor, "ok", filter=flt.__dict__, deleted=n, reason=reason)
        return {"deleted": n}
