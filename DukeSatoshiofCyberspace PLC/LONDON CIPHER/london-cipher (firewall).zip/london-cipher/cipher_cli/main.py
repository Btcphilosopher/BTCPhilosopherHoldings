"""``cipher`` — unprivileged command-line interface.

Local, unprivileged commands (no socket, no root):
    validate, compile, diff, parity, audit-verify

Administrative commands (via the admin socket; authorised by OS identity):
    plan, apply, confirm, rollback, status, history, repair, conntrack-delete

Exit codes: 0 success, 1 policy rejected, 2 usage error, 3 operation failed,
4 state not verified / attention needed, 5 aborted by operator.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from typing import Any, Optional

from cipher_admin.client import AdminClient, RemoteError
from cipher_compiler import compile_policy, diff_rulesets, review_listing
from cipher_events import verify_chain
from cipher_policy import load_policy_file
from cipher_policy.validate import build_policy
from cipher_types import CipherError, PolicyError
from cipher_types.ir import to_jsonable

DEFAULT_SOCKET = os.environ.get("LONDON_CIPHER_SOCKET", "/run/london-cipher/admin.sock")
EXIT_OK, EXIT_POLICY, EXIT_USAGE, EXIT_FAIL, EXIT_ATTENTION, EXIT_ABORT = 0, 1, 2, 3, 4, 5


def _now(a) -> datetime:
    if getattr(a, "now", None):
        ts = datetime.fromisoformat(a.now.replace("Z", "+00:00"))
        if ts.tzinfo is None:
            raise SystemExit("--now requires a timezone")
        return ts
    return datetime.now(timezone.utc)


def _out(a, obj: Any, text: Optional[str] = None) -> None:
    if getattr(a, "json", False) or text is None:
        print(json.dumps(obj, indent=1, sort_keys=True, default=str))
    else:
        print(text)


def _load(path: str, a):
    raw, data = load_policy_file(path)
    policy, warnings = build_policy(data, now=_now(a))
    return raw, policy, warnings


def cmd_validate(a) -> int:
    _, policy, warnings = _load(a.policy, a)
    _out(a, {"valid": True, "policy_id": policy.meta.id, "revision": policy.meta.revision, "warnings": [w.to_dict() for w in warnings]},
         "\n".join([f"OK: {policy.meta.id} revision {policy.meta.revision} ({len(policy.rules)} rules)"] + [f"  {w}" for w in warnings]))
    return EXIT_OK


def cmd_compile(a) -> int:
    _, policy, _ = _load(a.policy, a)
    res = compile_policy(policy, now=_now(a))
    if a.format == "listing":
        sys.stdout.write(review_listing(res.ruleset))
    elif a.format == "ir":
        print(json.dumps(to_jsonable(res.ruleset), indent=1, sort_keys=True))
    else:
        from cipher_backend.nftables import render_commands

        print(json.dumps({"nftables": render_commands(res.ruleset)}, indent=1))
    return EXIT_OK


def cmd_diff(a) -> int:
    _, old, _ = _load(a.old, a)
    _, new, _ = _load(a.new, a)
    d = diff_rulesets(compile_policy(old, now=_now(a)).ruleset, compile_policy(new, now=_now(a)).ruleset)
    _out(a, d.to_dict(), f"{d.summary()}\n{d.unified}")
    return EXIT_OK


def cmd_parity(a) -> int:
    _, policy, _ = _load(a.policy, a)
    res = compile_policy(policy, now=_now(a))
    lines = [f"{k}: {', '.join(v) or '-'}" for k, v in res.parity.items()]
    _out(a, res.parity, "\n".join(lines))
    return EXIT_OK


def cmd_audit_verify(a) -> int:
    ok, n, problem = verify_chain(a.path)
    _out(a, {"ok": ok, "records": n, "problem": problem}, f"{'OK' if ok else 'TAMPERED'}: {n} records verified" + (f"; {problem}" if problem else ""))
    return EXIT_OK if ok else EXIT_ATTENTION


def _client(a) -> AdminClient:
    return AdminClient(a.socket)


def cmd_plan(a) -> int:
    with open(a.policy, encoding="utf-8") as fh:
        text = fh.read()
    plan = _client(a).call("plan", policy_text=text, allow_conflicts=a.allow_conflicts)
    _out(a, plan, f"{plan['policy_id']} revision {plan['revision']}: {plan['summary']}\n{plan['diff']['unified']}")
    return EXIT_OK


def cmd_apply(a) -> int:
    with open(a.policy, encoding="utf-8") as fh:
        text = fh.read()
    c = _client(a)
    plan = c.call("plan", policy_text=text, allow_conflicts=a.allow_conflicts)
    print(f"Proposed: {plan['policy_id']} revision {plan['revision']} — {plan['summary']}", file=sys.stderr)
    if plan["diff"]["unified"]:
        print(plan["diff"]["unified"], file=sys.stderr)
    for w in plan["warnings"]:
        print(f"warning: {w['path']}: {w['message']}", file=sys.stderr)
    if plan["conflicts"].get("foreign_base_chains"):
        print("note: other base chains exist and are evaluated independently:", file=sys.stderr)
        for fc in plan["conflicts"]["foreign_base_chains"]:
            print(f"  {fc}", file=sys.stderr)
    if not a.yes:
        if not sys.stdin.isatty():
            print("refusing to apply without --yes when stdin is not a terminal", file=sys.stderr)
            return EXIT_ABORT
        if input("Apply this change? [y/N] ").strip().lower() not in ("y", "yes"):
            return EXIT_ABORT
    res = c.call("apply", policy_text=text, confirm_timeout=a.confirm_timeout, allow_conflicts=a.allow_conflicts)
    if res["status"] == "pending-confirmation":
        _out(a, res, f"INSTALLED AND VERIFIED, NOT COMMITTED: revision {res['revision']}.\n"
             f"Run 'cipher confirm' within {res['seconds_remaining']}s from a NEW session, or it will be rolled back automatically.")
    else:
        _out(a, res, f"ACTIVE (verified, committed): {res['policy_id']} revision {res['revision']} digest {res['digest'][:16]}")
    return EXIT_OK


def cmd_simple(op: str):
    def run(a) -> int:
        args: dict[str, Any] = {}
        if op == "rollback":
            args["reason"] = a.reason
        res = _client(a).call(op, **args)
        if op == "status":
            state = res.get("state")
            text = f"state: {state}"
            if res.get("lkg"):
                text += f"\ncommitted: {res['lkg']['policy_id']} revision {res['lkg']['revision']}"
            if res.get("pending"):
                text += f"\npending: revision {res['pending']['revision']} ({res['pending']['seconds_remaining']}s to confirm)"
            if res.get("problem"):
                text += f"\nproblem: {res['problem']}"
            _out(a, res, text)
            return EXIT_OK if state in ("active", "pending-confirmation", "unmanaged") else EXIT_ATTENTION
        _out(a, res, json.dumps(res, indent=1, default=str))
        return EXIT_OK

    return run


def cmd_conntrack(a) -> int:
    res = _client(a).call("conntrack_delete", family=a.family, source=a.source, destination=a.destination, protocol=a.protocol, dport=a.dport, reason=a.reason)
    _out(a, res, f"deleted {res['deleted']} connection-tracking entries")
    return EXIT_OK


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="cipher", description="LONDON CIPHER — Sentinel Firewall")
    ap.add_argument("--socket", default=DEFAULT_SOCKET, help="admin socket path")
    ap.add_argument("--json", action="store_true", help="machine-readable output")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def pol(p, name="policy"):
        p.add_argument(name)
        p.add_argument("--now", help="evaluate expiry as of this ISO 8601 time")
        return p

    pol(sub.add_parser("validate", help="validate a policy (local, unprivileged)")).set_defaults(fn=cmd_validate)
    p = pol(sub.add_parser("compile", help="compile a policy (local, unprivileged)"))
    p.add_argument("--format", choices=["listing", "ir", "nft-json"], default="listing")
    p.set_defaults(fn=cmd_compile)
    p = sub.add_parser("diff", help="diff two policy files (local)")
    p.add_argument("old")
    p.add_argument("new")
    p.add_argument("--now")
    p.set_defaults(fn=cmd_diff)
    pol(sub.add_parser("parity", help="IPv4/IPv6 parity report (local)")).set_defaults(fn=cmd_parity)
    p = sub.add_parser("audit-verify", help="verify an audit log hash chain (local)")
    p.add_argument("path")
    p.set_defaults(fn=cmd_audit_verify)

    p = sub.add_parser("plan", help="dry-run against the installed state")
    p.add_argument("policy")
    p.add_argument("--allow-conflicts", action="store_true")
    p.set_defaults(fn=cmd_plan)
    p = sub.add_parser("apply", help="apply a policy (validate, compile, diff, apply, verify, commit)")
    p.add_argument("policy")
    p.add_argument("--confirm-timeout", type=int, help="arm timed rollback; requires 'cipher confirm'")
    p.add_argument("--yes", action="store_true", help="do not prompt")
    p.add_argument("--allow-conflicts", action="store_true")
    p.set_defaults(fn=cmd_apply)
    for op in ("confirm", "status", "history", "repair"):
        sub.add_parser(op).set_defaults(fn=cmd_simple(op))
    p = sub.add_parser("rollback")
    p.add_argument("--reason", default="operator request")
    p.set_defaults(fn=cmd_simple("rollback"))
    p = sub.add_parser("conntrack-delete", help="audited removal of connection-tracking entries")
    p.add_argument("--family", choices=["ipv4", "ipv6"], required=True)
    p.add_argument("--source")
    p.add_argument("--destination")
    p.add_argument("--protocol", choices=["tcp", "udp"])
    p.add_argument("--dport", type=int)
    p.add_argument("--reason", required=True)
    p.set_defaults(fn=cmd_conntrack)
    return ap


def main(argv: Optional[list[str]] = None) -> int:
    ap = build_parser()
    a = ap.parse_args(argv)
    try:
        return a.fn(a)
    except PolicyError as exc:
        if a.json:
            print(json.dumps({"valid": False, "issues": [i.to_dict() for i in exc.issues]}, indent=1))
        else:
            print("POLICY REJECTED", file=sys.stderr)
            for i in exc.issues:
                print(f"  {i}", file=sys.stderr)
        return EXIT_POLICY
    except RemoteError as exc:
        print(f"error [{exc.code}]: {exc}", file=sys.stderr)
        return EXIT_POLICY if exc.code.startswith(("policy", "revision")) else EXIT_FAIL
    except (CipherError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_FAIL


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
