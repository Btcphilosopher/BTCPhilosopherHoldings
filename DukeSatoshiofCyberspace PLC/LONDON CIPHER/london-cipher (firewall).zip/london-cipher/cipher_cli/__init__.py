"""Command-line interface (``cipher``)."""

from .main import build_parser, main

__all__ = ["build_parser", "main"]
