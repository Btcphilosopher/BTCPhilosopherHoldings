"""Human-readable review listing and diffs of compiled rulesets.

The listing is a *review* format: it resembles nftables syntax so operators
can read it, but it is never executed. The nftables backend renders the IR to
the structured libnftables JSON format separately.
"""

from __future__ import annotations

import difflib
from dataclasses import dataclass, field
from typing import Optional

from cipher_types.ir import (
    IRChain,
    IRRule,
    IRRuleset,
    MAddr,
    MCtState,
    MHopLimit,
    MIcmp,
    MIface,
    ML4,
    MNfproto,
    MPort,
    rule_key,
)


def _vals(items) -> str:
    items = [str(i) for i in items]
    return items[0] if len(items) == 1 else "{ " + ", ".join(items) + " }"


def describe_match(m) -> str:
    if isinstance(m, MNfproto):
        return f"meta nfproto {m.family}"
    if isinstance(m, MIface):
        op = "!= " if m.negate else ""
        return f"{m.direction} {op}{_vals(repr(n).replace(chr(39), chr(34)) for n in m.names)}"
    if isinstance(m, MAddr):
        proto = "ip" if m.family == "ipv4" else "ip6"
        rhs = f"@{m.set_name}" if m.set_name else _vals(m.networks)
        return f"{proto} {m.field} {rhs}"
    if isinstance(m, ML4):
        return f"meta l4proto {m.protocol}"
    if isinstance(m, MPort):
        return f"{m.protocol} {m.field} {_vals(m.ports)}"
    if isinstance(m, MIcmp):
        return f"{m.protocol} type {_vals(m.types)}"
    if isinstance(m, MCtState):
        return f"ct state {','.join(m.states)}"
    if isinstance(m, MHopLimit):
        return f"ip6 hoplimit {m.value}"
    raise TypeError(f"unknown match {m!r}")  # pragma: no cover


def describe_rule(r: IRRule) -> str:
    parts = [describe_match(m) for m in r.matches]
    if r.log is not None:
        parts.append(f'log(prefix "{r.log.prefix.strip()}" limit {r.log.rate}/{r.log.per} burst {r.log.burst})')
    if r.nat is not None:
        n = r.nat
        if n.kind == "masquerade":
            parts.append("masquerade")
        else:
            tgt = n.addr if n.port is None else (f"[{n.addr}]:{n.port}" if n.family == "ipv6" else f"{n.addr}:{n.port}")
            parts.append(f"{n.kind} {n.family or ''} to {tgt}".replace("  ", " "))
    if r.verdict:
        parts.append(r.verdict)
    return " ".join(parts) if parts else "(no-op)"


def review_listing(rs: IRRuleset, *, include_dynamic_elements: bool = False) -> str:
    lines = [
        "# LONDON CIPHER review listing (not executable)",
        f"# table inet {rs.table} | policy {rs.policy_id} revision {rs.revision}",
        f"# digest {rs.digest}",
    ]
    if rs.excluded_rules:
        for rid, why in rs.excluded_rules:
            lines.append(f"# excluded rule {rid}: {why}")
    if rs.next_expiry:
        lines.append(f"# next rule expiry {rs.next_expiry}")
    for s in rs.sets:
        if s.dynamic:
            desc = f"dynamic source={s.source} max={s.max_elements}" + (" timeout" if s.timeout else "")
            elems = f" {{ {', '.join(s.elements)} }}" if include_dynamic_elements and s.elements else ""
            lines.append(f"set {s.name} {s.nft_type} [{desc}]{elems}")
        else:
            lines.append(f"set {s.name} {s.nft_type} {{ {', '.join(s.elements)} }}")
    for c in rs.chains:
        lines.append(f"chain {c.name} ({c.kind} hook {c.hook} priority {c.priority} policy {c.policy})")
        for i, r in enumerate(c.rules, 1):
            lines.append(f"  {i:>3} {rule_key(r):<40} {describe_rule(r)}")
    return "\n".join(lines) + "\n"


@dataclass
class RulesetDiff:
    unified: str
    added: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)
    changed: list[str] = field(default_factory=list)
    moved: list[str] = field(default_factory=list)
    policy_changes: list[str] = field(default_factory=list)
    set_changes: list[str] = field(default_factory=list)

    @property
    def empty(self) -> bool:
        return not (self.added or self.removed or self.changed or self.moved or self.policy_changes or self.set_changes)

    def summary(self) -> str:
        if self.empty:
            return "no changes"
        out = []
        for label, items in (
            ("default policy", self.policy_changes),
            ("added", self.added),
            ("removed", self.removed),
            ("changed", self.changed),
            ("reordered", self.moved),
            ("sets", self.set_changes),
        ):
            if items:
                out.append(f"{label}: {', '.join(items)}")
        return "; ".join(out)

    def to_dict(self) -> dict:
        return {
            "added": self.added,
            "removed": self.removed,
            "changed": self.changed,
            "moved": self.moved,
            "policy_changes": self.policy_changes,
            "set_changes": self.set_changes,
            "unified": self.unified,
        }


def _chain_map(rs: Optional[IRRuleset]) -> dict[str, IRChain]:
    return {c.name: c for c in rs.chains} if rs else {}


def diff_rulesets(old: Optional[IRRuleset], new: IRRuleset) -> RulesetDiff:
    """Semantic (by stable rule id) and textual diff between two rulesets."""
    old_text = review_listing(old) if old else ""
    unified = "".join(
        difflib.unified_diff(
            old_text.splitlines(keepends=True),
            review_listing(new).splitlines(keepends=True),
            fromfile=f"installed (rev {old.revision})" if old else "installed (none)",
            tofile=f"proposed (rev {new.revision})",
        )
    )
    d = RulesetDiff(unified)
    oc, nc = _chain_map(old), _chain_map(new)
    for name in sorted(set(oc) | set(nc)):
        o, n = oc.get(name), nc.get(name)
        if o is None:
            d.policy_changes.append(f"{name}: (none) -> {n.policy}")  # type: ignore[union-attr]
        elif n is None:
            d.policy_changes.append(f"{name}: {o.policy} -> (removed)")
        elif o.policy != n.policy:
            d.policy_changes.append(f"{name}: {o.policy} -> {n.policy}")
        okeys = [f"{name}:{rule_key(r)}" for r in (o.rules if o else ())]
        nkeys = [f"{name}:{rule_key(r)}" for r in (n.rules if n else ())]
        orules = {f"{name}:{rule_key(r)}": r for r in (o.rules if o else ())}
        nrules = {f"{name}:{rule_key(r)}": r for r in (n.rules if n else ())}
        for k in nkeys:
            if k not in orules:
                d.added.append(k)
            elif orules[k] != nrules[k]:
                d.changed.append(k)
        for k in okeys:
            if k not in nrules:
                d.removed.append(k)
        common_o = [k for k in okeys if k in nrules]
        common_n = [k for k in nkeys if k in orules]
        if common_o != common_n:
            d.moved.extend(k for k, j in zip(common_n, common_o) if k != j)
    os_ = {s.name: s for s in (old.sets if old else ())}
    ns_ = {s.name: s for s in new.sets}
    for name in sorted(set(os_) | set(ns_)):
        a, b = os_.get(name), ns_.get(name)
        if a is None:
            d.set_changes.append(f"+{name}")
        elif b is None:
            d.set_changes.append(f"-{name}")
        elif (a.elements != b.elements and not a.dynamic) or a.family != b.family or a.dynamic != b.dynamic or a.max_elements != b.max_elements:
            d.set_changes.append(f"~{name}")
    return d
