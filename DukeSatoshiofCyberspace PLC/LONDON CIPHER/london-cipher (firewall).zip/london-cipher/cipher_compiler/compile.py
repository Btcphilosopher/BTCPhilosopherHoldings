"""Policy -> IR compiler.

Deterministic: the same policy, ``now`` and table name always yield an
identical :class:`IRRuleset` (and therefore identical digest and backend
output). Ordering never depends on dict iteration of untrusted input beyond
the author's own declared order of rules.

Chain layout (filter, every chain explicit; see docs/stateful-semantics.md)::

    input:   loopback anti-spoof -> loopback accept -> ct invalid drop
             -> ct established,related accept -> essential services
             -> admin access -> user rules (in order) -> [rate-limited log]
             -> chain policy
    output:  loopback accept -> ct invalid drop -> ct established,related
             accept -> essential services -> user rules -> [log] -> policy
    forward: ct invalid drop -> ct established,related accept
             -> user rules -> [log] -> policy

When ``state.established_related`` is ``evaluate`` the early accept is not
installed and return traffic must be permitted by explicit rules; likewise
``state.invalid: evaluate`` omits the early invalid drop.
"""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Iterable, Optional

from cipher_types import TABLE_NAME, Action, Family, Hook, Issue, Protocol, Severity
from cipher_types.ir import (
    IRChain,
    IRRule,
    IRRuleset,
    IRSet,
    MAddr,
    MCtState,
    MHopLimit,
    MIcmp,
    MIface,
    ML4,
    MNfproto,
    MPort,
    PortRange,
    SLog,
    SNat,
)
from cipher_policy.model import Endpoint, Policy, Rule, net_family

FILTER_PRIORITY = 0
DSTNAT_PRIORITY = -100
SRCNAT_PRIORITY = 100

ND_TYPES_IN = ("nd-neighbor-advert", "nd-neighbor-solicit")
ND_TYPES_OUT = ("mld-listener-report", "mld2-listener-report", "nd-neighbor-advert", "nd-neighbor-solicit", "nd-router-solicit")
ICMPV6_ERRORS = ("destination-unreachable", "packet-too-big", "parameter-problem", "time-exceeded")
ICMPV4_ERRORS = ("destination-unreachable", "parameter-problem", "time-exceeded")
LOOPBACK_V4 = "127.0.0.0/8"
LOOPBACK_V6 = "::1/128"
LINK_LOCAL_V6 = "fe80::/10"

_FAM = {Family.IPV4: "ipv4", Family.IPV6: "ipv6"}


@dataclass
class CompileResult:
    ruleset: IRRuleset
    warnings: list[Issue] = field(default_factory=list)
    parity: dict[str, list[str]] = field(default_factory=dict)


class _Builder:
    def __init__(self, policy: Policy, now: datetime, table: str):
        self.p = policy
        self.now = now
        self.table = table
        self.sets: dict[str, IRSet] = {}
        self.warnings: list[Issue] = []
        self.parity: dict[str, list[str]] = {"ipv4_only": [], "ipv6_only": [], "both": []}
        lg = policy.logging
        self._log = lambda rid, tag: SLog(prefix=_log_prefix(rid, tag), level=lg.level, rate=lg.rate, per=lg.per, burst=lg.burst)
        for d in sorted(policy.dynamic_sets.values(), key=lambda d: d.name):
            name = f"dyn_{d.name}"
            self.sets[name] = IRSet(
                name=name,
                family=_FAM[d.family],  # type: ignore[arg-type]
                dynamic=True,
                source=d.source,
                timeout=d.timeout_seconds is not None,
                max_elements=d.max_elements,
            )

    # -- address handling ---------------------------------------------------
    def _static_set(self, name: str, fam: Family) -> Optional[str]:
        nets = [n for n in self.p.address_sets[name].networks if net_family(n) is fam]
        if not nets:
            return None
        sname = f"as_{name}_{'v4' if fam is Family.IPV4 else 'v6'}"
        if sname not in self.sets:
            elems = tuple(str(n) for n in ipaddress.collapse_addresses(nets))
            self.sets[sname] = IRSet(name=sname, family=_FAM[fam], elements=elems)  # type: ignore[arg-type]
        return sname

    def _addr_alternatives(self, ep: Endpoint, fam: Family, fld: str) -> Optional[list[Optional[MAddr]]]:
        """Union alternatives for an endpoint's explicit addresses.

        Returns ``[None]`` when unconstrained, ``None`` when the endpoint
        constrains addresses but none exist in ``fam`` (rule part impossible).
        """
        f = _FAM[fam]
        if not ep.networks and not ep.sets:
            return [None]
        inline = [n for n in ep.networks if net_family(n) is fam]
        static_sets = [s for s in ep.sets if s in self.p.address_sets]
        dyn = [s for s in ep.sets if s in self.p.dynamic_sets and self.p.dynamic_sets[s].family is fam]
        alts: list[Optional[MAddr]] = []
        if len(static_sets) == 1 and not inline:
            sname = self._static_set(static_sets[0], fam)
            if sname:
                alts.append(MAddr(f, fld, set_name=sname))  # type: ignore[arg-type]
        else:
            nets = list(inline)
            for s in static_sets:
                nets.extend(n for n in self.p.address_sets[s].networks if net_family(n) is fam)
            if nets:
                alts.append(MAddr(f, fld, networks=tuple(str(n) for n in ipaddress.collapse_addresses(nets))))  # type: ignore[arg-type]
        for s in dyn:
            alts.append(MAddr(f, fld, set_name=f"dyn_{s}"))  # type: ignore[arg-type]
        return alts or None

    def _zone_match(self, zone: Optional[str], fam: Optional[Family], direction: str, fld: str):
        """Returns (iface match or None, zone-network match or None, possible)."""
        if zone is None:
            return None, None, True
        z = self.p.zones[zone]
        im = MIface(direction, tuple(z.interfaces)) if z.interfaces else None  # type: ignore[arg-type]
        if not z.networks:
            return im, None, True
        if fam is None:
            return im, None, False  # caller must split by family
        nets = [n for n in z.networks if net_family(n) is fam]
        if not nets:
            return im, None, False
        return im, MAddr(_FAM[fam], fld, networks=tuple(str(n) for n in ipaddress.collapse_addresses(nets))), True  # type: ignore[arg-type]

    # -- rule expansion -------------------------------------------------------
    def _proto_parts(self, r: Rule) -> list[tuple[Optional[Protocol], tuple[PortRange, ...], tuple[str, ...]]]:
        if r.services:
            parts = []
            for s in r.services:
                for svc in self.p.service_sets[s].services:
                    parts.append((svc.protocol, svc.ports, svc.icmp_types))
            # merge identical-protocol port lists for compactness, stable order
            merged: dict[tuple, list] = {}
            for proto, ports, icmp in parts:
                key = (proto, bool(ports), icmp)
                merged.setdefault(key, []).extend(ports)
            return [(k[0], tuple(sorted(set(v))), k[2]) for k, v in merged.items()]
        return [(r.protocol, r.ports, r.icmp_types)]

    def _l4_matches(self, proto, ports, sports, icmp) -> list:
        out: list = []
        if proto is None:
            return out
        if proto.has_ports:
            if sports:
                out.append(MPort(proto.value, "sport", tuple(sports)))  # type: ignore[arg-type]
            if ports:
                out.append(MPort(proto.value, "dport", tuple(ports)))  # type: ignore[arg-type]
            if not ports and not sports:
                out.append(ML4(proto.value))  # type: ignore[arg-type]
        else:
            if icmp:
                out.append(MIcmp(proto.value, tuple(icmp)))  # type: ignore[arg-type]
            else:
                out.append(ML4(proto.value))  # type: ignore[arg-type]
        return out

    def expand_rule(self, r: Rule, origin: str = "user") -> list[IRRule]:
        src, dst = r.source, r.destination
        has_addr = bool(src.networks or src.sets or dst.networks or dst.sets)
        zone_nets = any(z and self.p.zones[z].networks for z in (src.zone, dst.zone))
        fams: list[Optional[Family]]
        if r.family is Family.ANY and not has_addr and not zone_nets:
            fams = [None]
        else:
            fams = list(r.family.expand())
        out: list[IRRule] = []
        compiled_fams: set[str] = set()
        for fam in fams:
            for proto, ports, icmp in self._proto_parts(r):
                if proto is Protocol.ICMP and fam is Family.IPV6 or proto is Protocol.ICMPV6 and fam is Family.IPV4:
                    continue
                pfam = fam
                if fam is None and proto in (Protocol.ICMP, Protocol.ICMPV6):
                    pfam = Family.IPV4 if proto is Protocol.ICMP else Family.IPV6
                if pfam is None:
                    src_alts: list = [None]
                    dst_alts: list = [None]
                else:
                    sa = self._addr_alternatives(src, pfam, "saddr")
                    da = self._addr_alternatives(dst, pfam, "daddr")
                    if sa is None or da is None:
                        continue
                    src_alts, dst_alts = sa, da
                s_if, s_zn, ok1 = self._zone_match(src.zone, pfam, "iifname", "saddr")
                d_if, d_zn, ok2 = self._zone_match(dst.zone, pfam, "oifname", "daddr")
                if not (ok1 and ok2):
                    continue
                for sa_m in src_alts:
                    for da_m in dst_alts:
                        m: list = []
                        if pfam is not None and sa_m is None and da_m is None and s_zn is None and d_zn is None and proto not in (Protocol.ICMP, Protocol.ICMPV6):
                            m.append(MNfproto(_FAM[pfam]))  # type: ignore[arg-type]
                        if r.in_interfaces:
                            m.append(MIface("iifname", tuple(r.in_interfaces)))
                        if s_if is not None:
                            m.append(s_if)
                        if r.out_interfaces:
                            m.append(MIface("oifname", tuple(r.out_interfaces)))
                        if d_if is not None:
                            m.append(d_if)
                        for x in (s_zn, sa_m, d_zn, da_m):
                            if x is not None:
                                m.append(x)
                        m.extend(self._l4_matches(proto, ports, r.source_ports, icmp))
                        if r.ct_states:
                            m.append(MCtState(tuple(r.ct_states)))
                        part = "/".join(x for x in ((_FAM[pfam] if pfam else "inet"), proto.value if proto else "") if x)
                        out.append(
                            IRRule(
                                rule_id=r.id,
                                origin=origin,  # type: ignore[arg-type]
                                matches=tuple(m),
                                part=part,
                                verdict=r.action.value,  # type: ignore[arg-type]
                                log=self._log(r.id, r.action.value[0].upper()) if r.log else None,
                            )
                        )
                        compiled_fams.add(_FAM[pfam] if pfam else "both")
        if origin == "user":
            if compiled_fams == {"ipv4"}:
                self.parity["ipv4_only"].append(r.id)
            elif compiled_fams == {"ipv6"}:
                self.parity["ipv6_only"].append(r.id)
            elif compiled_fams:
                self.parity["both"].append(r.id)
        if not out:
            self.warnings.append(Issue(Severity.WARNING, "compile.empty_rule", f"rule:{r.id}", f"rule {r.id!r} compiled to no enforcement rules"))
        return out

    # -- essential rules ------------------------------------------------------
    def _ess(self, rid: str, matches: Iterable, verdict="accept", part: str = "") -> IRRule:
        return IRRule(f"essential.{rid}", "essential", tuple(matches), part=part, verdict=verdict)

    def state_rules(self, hook: Hook) -> list[IRRule]:
        out = []
        st = self.p.state
        if st.invalid == "drop":
            out.append(self._ess("ct-invalid", [MCtState(("invalid",))], "drop"))
        if st.established_related == "accept":
            out.append(self._ess("ct-established", [MCtState(("established", "related"))]))
        return out

    def input_essentials(self) -> list[IRRule]:
        e = self.p.essential
        out: list[IRRule] = []
        if e.loopback_antispoof:
            out.append(self._ess("loopback-antispoof", [MIface("iifname", ("lo",), negate=True), MAddr("ipv4", "saddr", (LOOPBACK_V4,))], "drop", "ipv4"))
            out.append(self._ess("loopback-antispoof", [MIface("iifname", ("lo",), negate=True), MAddr("ipv6", "saddr", (LOOPBACK_V6,))], "drop", "ipv6"))
        if e.loopback == "accept":
            out.append(self._ess("loopback", [MIface("iifname", ("lo",))]))
        out.extend(self.state_rules(Hook.INPUT))
        if e.icmpv6_neighbor_discovery:
            nd = list(ND_TYPES_IN) + (["nd-router-advert"] if e.slaac else [])
            out.append(self._ess("icmpv6-nd", [MIcmp("icmpv6", tuple(sorted(nd))), MHopLimit(255)], part="ipv6"))
            out.append(self._ess("icmpv6-mld", [MAddr("ipv6", "saddr", (LINK_LOCAL_V6,)), MIcmp("icmpv6", ("mld-listener-query",))], part="ipv6"))
        if e.icmpv6_errors:
            out.append(self._ess("icmpv6-errors", [MIcmp("icmpv6", ICMPV6_ERRORS), MCtState(("related",))], part="ipv6"))
        if e.icmpv4_errors:
            out.append(self._ess("icmpv4-errors", [MIcmp("icmp", ICMPV4_ERRORS), MCtState(("related",))], part="ipv4"))
        if e.dhcpv4_client:
            out.append(self._ess("dhcpv4-client", [MNfproto("ipv4"), MPort("udp", "sport", (PortRange(67, 67),)), MPort("udp", "dport", (PortRange(68, 68),))], part="ipv4"))
        if e.dhcpv6_client:
            out.append(self._ess("dhcpv6-client", [MAddr("ipv6", "saddr", (LINK_LOCAL_V6,)), MPort("udp", "sport", (PortRange(547, 547),)), MPort("udp", "dport", (PortRange(546, 546),))], part="ipv6"))
        if e.admin_access is not None:
            a = e.admin_access
            pseudo = Rule(
                id="admin-access",
                chain=Hook.INPUT,
                action=Action.ACCEPT,
                justification=a.justification,
                source=a.source,
                protocol=a.protocol,
                ports=a.ports,
            )
            for ir in self.expand_rule(pseudo, origin="essential"):
                out.append(IRRule("essential.admin-access", "essential", ir.matches, part=ir.part, verdict="accept"))
        return out

    def output_essentials(self) -> list[IRRule]:
        e = self.p.essential
        out: list[IRRule] = []
        if e.loopback == "accept":
            out.append(self._ess("loopback", [MIface("oifname", ("lo",))]))
        out.extend(self.state_rules(Hook.OUTPUT))
        if e.icmpv6_neighbor_discovery:
            out.append(self._ess("icmpv6-nd", [MIcmp("icmpv6", ND_TYPES_OUT)], part="ipv6"))
        if e.icmpv6_errors:
            out.append(self._ess("icmpv6-errors", [MIcmp("icmpv6", ICMPV6_ERRORS), MCtState(("related",))], part="ipv6"))
        if e.icmpv4_errors:
            out.append(self._ess("icmpv4-errors", [MIcmp("icmp", ICMPV4_ERRORS), MCtState(("related",))], part="ipv4"))
        if e.dhcpv4_client:
            out.append(self._ess("dhcpv4-client", [MNfproto("ipv4"), MPort("udp", "sport", (PortRange(68, 68),)), MPort("udp", "dport", (PortRange(67, 67),))], part="ipv4"))
        if e.dhcpv6_client:
            out.append(self._ess("dhcpv6-client", [MNfproto("ipv6"), MPort("udp", "sport", (PortRange(546, 546),)), MPort("udp", "dport", (PortRange(547, 547),))], part="ipv6"))
        for svc, servers, protos in (("dns", e.dns_servers, ("udp", "tcp")), ("ntp", e.ntp_servers, ("udp",))):
            port = 53 if svc == "dns" else 123
            for fam in (Family.IPV4, Family.IPV6):
                addrs = tuple(sorted(f"{a}/{a.max_prefixlen}" for a in servers if (a.version == 4) == (fam is Family.IPV4)))
                if not addrs:
                    continue
                for proto in protos:
                    out.append(self._ess(svc, [MAddr(_FAM[fam], "daddr", addrs), MPort(proto, "dport", (PortRange(port, port),))], part=f"{_FAM[fam]}/{proto}"))  # type: ignore[arg-type]
        return out

    def default_log(self, hook: Hook) -> list[IRRule]:
        if self.p.logging.log_default_drop and self.p.defaults.for_hook(hook).value == "drop":
            return [IRRule(f"default.{hook.value}", "default", (), log=self._log(f"default-{hook.value}", "D"))]
        return []

    # -- NAT ------------------------------------------------------------------
    def nat_chains(self) -> list[IRChain]:
        nat = self.p.nat
        if not nat.enabled:
            return []
        pre: list[IRRule] = []
        post: list[IRRule] = []
        for fwd in nat.port_forwards:
            fam = Family.IPV4 if fwd.to_address.version == 4 else Family.IPV6
            alts = self._addr_alternatives(fwd.destination, fam, "daddr") or []
            for alt in alts:
                m: list = [MIface("iifname", fwd.in_interfaces)]
                m.append(alt if alt is not None else MNfproto(_FAM[fam]))  # type: ignore[arg-type]
                m.append(MPort(fwd.protocol.value, "dport", (PortRange(fwd.port, fwd.port),)))  # type: ignore[arg-type]
                pre.append(IRRule(fwd.id, "nat", tuple(m), part=_FAM[fam], nat=SNat("dnat", _FAM[fam], str(fwd.to_address), fwd.to_port)))  # type: ignore[arg-type]
        for mq in nat.masquerade:
            for fam in mq.family.expand():
                alts = self._addr_alternatives(mq.source, fam, "saddr")
                if alts is None:
                    continue
                for alt in alts:
                    m = [MIface("oifname", mq.out_interfaces)]
                    m.append(alt if alt is not None else MNfproto(_FAM[fam]))  # type: ignore[arg-type]
                    post.append(IRRule(mq.id, "nat", tuple(m), part=_FAM[fam], nat=SNat("masquerade")))
        return [
            IRChain("nat_prerouting", "nat", "prerouting", DSTNAT_PRIORITY, "accept", tuple(pre)),
            IRChain("nat_postrouting", "nat", "postrouting", SRCNAT_PRIORITY, "accept", tuple(post)),
        ]


def _log_prefix(rule_id: str, tag: str) -> str:
    """Kernel log prefix: ``lc:<rule-id>:<A|D|R> `` (<= 64 bytes, parseable)."""
    return f"lc:{rule_id}:{tag} "


def compile_policy(policy: Policy, *, now: Optional[datetime] = None, table: str = TABLE_NAME) -> CompileResult:
    now = now or datetime.now(timezone.utc)
    b = _Builder(policy, now, table)
    excluded: list[tuple[str, str]] = []
    per_hook: dict[Hook, list[IRRule]] = {h: [] for h in Hook}
    for r in policy.rules:
        if not r.enabled:
            excluded.append((r.id, "disabled"))
            continue
        if r.expires is not None and r.expires <= now:
            excluded.append((r.id, f"expired {r.expires.isoformat()}"))
            continue
        per_hook[r.chain].extend(b.expand_rule(r))

    chains = [
        IRChain("input", "filter", "input", FILTER_PRIORITY, policy.defaults.input.value, tuple(b.input_essentials() + per_hook[Hook.INPUT] + b.default_log(Hook.INPUT))),  # type: ignore[arg-type]
        IRChain("output", "filter", "output", FILTER_PRIORITY, policy.defaults.output.value, tuple(b.output_essentials() + per_hook[Hook.OUTPUT] + b.default_log(Hook.OUTPUT))),  # type: ignore[arg-type]
        IRChain("forward", "filter", "forward", FILTER_PRIORITY, policy.defaults.forward.value, tuple(b.state_rules(Hook.FORWARD) + per_hook[Hook.FORWARD] + b.default_log(Hook.FORWARD))),  # type: ignore[arg-type]
    ]
    chains.extend(b.nat_chains())

    features = set()
    if policy.nat.enabled:
        features.add("nat")
    if any(s.timeout for s in b.sets.values()):
        features.add("timeout_sets")
    if any(r.log for c in chains for r in c.rules):
        features.add("log")
    if b.sets:
        features.add("named_sets")

    future = [r.expires for r in policy.rules if r.enabled and r.expires is not None and r.expires > now]
    rs = IRRuleset(
        table=table,
        policy_id=policy.meta.id,
        revision=policy.meta.revision,
        chains=tuple(chains),
        sets=tuple(sorted(b.sets.values(), key=lambda s: s.name)),
        features=tuple(sorted(features)),
        excluded_rules=tuple(excluded),
        next_expiry=min(future).isoformat() if future else None,
    ).with_digest()
    return CompileResult(rs, b.warnings, b.parity)
