#!/usr/bin/env python3
"""Summarise JUnit XML files in a results directory as JSON (with environment)."""

from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone


def tool_version(argv: list[str]) -> str | None:
    if shutil.which(argv[0]) is None:
        return None
    try:
        return subprocess.run(argv, capture_output=True, text=True, timeout=10).stdout.strip().splitlines()[0]
    except (OSError, IndexError, subprocess.TimeoutExpired):
        return None


def summarize(path: str) -> dict:
    root = ET.parse(path).getroot()
    suites = root.findall("testsuite") if root.tag == "testsuites" else [root]
    out = {"tests": 0, "failures": 0, "errors": 0, "skipped": 0, "time_s": 0.0, "cases": []}
    for s in suites:
        for k in ("tests", "failures", "errors", "skipped"):
            out[k] += int(s.get(k, 0))
        out["time_s"] += float(s.get("time", 0))
        for c in s.findall("testcase"):
            status = "passed"
            detail = None
            for tag in ("failure", "error", "skipped"):
                el = c.find(tag)
                if el is not None:
                    status = {"failure": "failed", "error": "error", "skipped": "skipped"}[tag]
                    detail = (el.get("message") or "")[:500]
            case = {"name": f"{c.get('classname')}::{c.get('name')}", "status": status, "time_s": float(c.get("time", 0))}
            if detail:
                case["detail"] = detail
            out["cases"].append(case)
    out["passed"] = out["tests"] - out["failures"] - out["errors"] - out["skipped"]
    out["time_s"] = round(out["time_s"], 3)
    return out


def main() -> int:
    d = sys.argv[1] if len(sys.argv) > 1 else "results"
    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "environment": {
            "python": platform.python_version(),
            "kernel": platform.release(),
            "machine": platform.machine(),
            "nft": tool_version(["nft", "--version"]),
            "ipv6_kernel_support": os.path.exists("/proc/net/if_inet6"),
            "euid": os.geteuid(),
        },
        "suites": {},
    }
    for name in sorted(os.listdir(d)):
        if name.startswith("junit-") and name.endswith(".xml"):
            report["suites"][name[6:-4]] = summarize(os.path.join(d, name))
    print(json.dumps(report, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
