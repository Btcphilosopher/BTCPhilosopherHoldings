#!/usr/bin/env bash
# LONDON CIPHER — removal.
#
#   sudo scripts/uninstall.sh [--prefix /opt/london-cipher] [--remove-ruleset] [--purge] [--dry-run]
#
# Default: stop and remove services and software, KEEP the active ruleset
# (the host stays protected by the last policy until reboot), keep /etc and
# /var/lib state.
#
#   --remove-ruleset  also delete the managed table `inet london_cipher`
#                     (ONLY that table; this may open the host — be sure)
#   --purge           also delete /etc/london-cipher, state, logs, users/groups files
set -euo pipefail

PREFIX=/opt/london-cipher
RM_RULES=0
PURGE=0
DRY=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --prefix) PREFIX="$2"; shift 2 ;;
    --remove-ruleset) RM_RULES=1; shift ;;
    --purge) PURGE=1; shift ;;
    --dry-run) DRY=1; shift ;;
    -h|--help) sed -n '2,15p' "$0"; exit 0 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
done
run() { if [[ $DRY -eq 1 ]]; then printf 'DRY-RUN:'; printf ' %q' "$@"; echo; else "$@"; fi; }
[[ $EUID -eq 0 || $DRY -eq 1 ]] || { echo "uninstall.sh must run as root" >&2; exit 1; }

UNITS=(london-cipher-admind.service london-cipher-helper.service london-cipher-restore.service)
for u in "${UNITS[@]}"; do
  run systemctl disable --now "$u" 2>/dev/null || true
  run rm -f "/etc/systemd/system/$u"
done
run systemctl daemon-reload || true

if [[ $RM_RULES -eq 1 ]]; then
  if nft list table inet london_cipher >/dev/null 2>&1; then
    echo "==> deleting managed table inet london_cipher (other tables untouched)"
    run nft delete table inet london_cipher
  fi
else
  echo "Keeping table inet london_cipher in the kernel (use --remove-ruleset to delete it)."
fi

run rm -rf "$PREFIX"
run rm -f /usr/lib/tmpfiles.d/london-cipher.conf
if [[ $PURGE -eq 1 ]]; then
  run rm -rf /etc/london-cipher /var/lib/london-cipher /var/log/london-cipher /run/london-cipher /var/lib/london-cipher-intel
  run rm -f /usr/lib/sysusers.d/london-cipher.conf
  echo "Users/groups (cipher, cipher-users, cipher-view, cipher-ops, cipher-admin) are left in place; remove with userdel/groupdel if desired."
fi
echo "Done."
