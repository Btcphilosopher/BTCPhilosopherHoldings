#!/usr/bin/env bash
# LONDON CIPHER — installation.
#
#   sudo scripts/install.sh [--prefix /opt/london-cipher] [--enable] [--dry-run]
#
# What it does:
#   * creates a virtualenv under PREFIX and installs pinned, hash-checked
#     dependencies (requirements.lock), then this package (no other deps);
#   * creates service user/groups (sysusers.d) and runtime dirs (tmpfiles.d);
#   * installs configs to /etc/london-cipher ONLY if absent (never overwrites);
#   * installs systemd units; enables/starts them only with --enable.
#
# What it never does: apply a policy, flush or modify existing firewall rules,
# or change sysctls. Apply your first policy with:
#   cipher apply --confirm-timeout 120 /etc/london-cipher/policy.yaml
set -euo pipefail

PREFIX=/opt/london-cipher
ENABLE=0
DRY=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --prefix) PREFIX="$2"; shift 2 ;;
    --enable) ENABLE=1; shift ;;
    --dry-run) DRY=1; shift ;;
    -h|--help) sed -n '2,20p' "$0"; exit 0 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
done

SRC="$(cd "$(dirname "$0")/.." && pwd)"
run() { if [[ $DRY -eq 1 ]]; then printf 'DRY-RUN:'; printf ' %q' "$@"; echo; else "$@"; fi; }

[[ $EUID -eq 0 || $DRY -eq 1 ]] || { echo "install.sh must run as root" >&2; exit 1; }
command -v nft >/dev/null || { echo "nftables (nft) is required" >&2; exit 1; }
python3 - <<'PY' || { echo "Python >= 3.10 is required" >&2; exit 1; }
import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)
PY

echo "==> virtualenv in $PREFIX"
run mkdir -p "$PREFIX"
run python3 -m venv "$PREFIX/venv"
run "$PREFIX/venv/bin/pip" install --quiet --require-hashes -r "$SRC/requirements.lock"
run "$PREFIX/venv/bin/pip" install --quiet --no-deps "$SRC"
run mkdir -p "$PREFIX/docs" "$PREFIX/examples"
run cp -r "$SRC/docs/." "$PREFIX/docs/"
run cp -r "$SRC/examples/." "$PREFIX/examples/"

echo "==> users, groups and runtime directories"
run install -m 0644 "$SRC/packaging/sysusers.d/london-cipher.conf" /usr/lib/sysusers.d/london-cipher.conf
run install -m 0644 "$SRC/packaging/tmpfiles.d/london-cipher.conf" /usr/lib/tmpfiles.d/london-cipher.conf
run systemd-sysusers /usr/lib/sysusers.d/london-cipher.conf
run systemd-tmpfiles --create /usr/lib/tmpfiles.d/london-cipher.conf

echo "==> configuration (existing files are kept)"
run install -d -m 0755 /etc/london-cipher
# helper.yaml is read by root; admin.yaml by the unprivileged 'cipher' user.
for spec in helper.yaml:root admin.yaml:cipher; do
  f="${spec%%:*}"; grp="${spec##*:}"
  if [[ -e "/etc/london-cipher/$f" ]]; then
    echo "    keeping existing /etc/london-cipher/$f"
  else
    run install -m 0640 -o root -g "$grp" "$SRC/packaging/etc/$f" "/etc/london-cipher/$f"
  fi
done
if [[ $DRY -eq 0 ]]; then
  CIPHER_UID="$(id -u cipher)"
  # admind's uid is the only delegate trusted to pass caller identity
  sed -i "s/^delegate_uids: \[\]/delegate_uids: [${CIPHER_UID}]/" /etc/london-cipher/helper.yaml
fi

echo "==> systemd units"
for u in london-cipher-helper.service london-cipher-admind.service london-cipher-restore.service; do
  sed "s#/opt/london-cipher#${PREFIX}#g" "$SRC/packaging/systemd/$u" > "/tmp/$u.$$"
  run install -m 0644 "/tmp/$u.$$" "/etc/systemd/system/$u"
  rm -f "/tmp/$u.$$"
done
run systemctl daemon-reload

for m in firewalld ufw; do
  if systemctl is-active --quiet "$m" 2>/dev/null; then
    echo "WARNING: $m is active. LONDON CIPHER refuses to compete with it (conflict_policy: refuse-managers)." >&2
  fi
done

if [[ $ENABLE -eq 1 ]]; then
  run systemctl enable --now london-cipher-restore.service london-cipher-helper.service london-cipher-admind.service
else
  echo "Units installed but not enabled. Enable with:"
  echo "  systemctl enable --now london-cipher-restore london-cipher-helper london-cipher-admind"
fi
echo "Add administrators to 'cipher-users' plus one role group (cipher-view|cipher-ops|cipher-admin)."
echo "Done."
