#!/usr/bin/env bash
# Run the test suites and write machine-readable results to results/.
#
#   scripts/run-tests.sh            unit tests (+ laboratory tests if root and available)
#   scripts/run-tests.sh --unit     unit tests only
#
# Outputs: results/junit-unit.xml, results/junit-lab.xml, results/test-summary.json
set -uo pipefail
cd "$(dirname "$0")/.."
mkdir -p results
export PYTHONDONTWRITEBYTECODE=1

python3 -m pytest tests/unit -q -p no:cacheprovider --junitxml=results/junit-unit.xml
UNIT=$?
LAB=skipped
if [[ "${1:-}" != "--unit" ]]; then
  if [[ $EUID -eq 0 ]]; then
    python3 -m pytest tests/integration -q -rs -p no:cacheprovider --junitxml=results/junit-lab.xml
    LAB=$?
  else
    echo "laboratory tests need root; skipped" >&2
  fi
fi
python3 scripts/summarize_results.py results > results/test-summary.json
cat results/test-summary.json
[[ $UNIT -eq 0 && ( "$LAB" == "skipped" || "$LAB" -eq 0 ) ]]
