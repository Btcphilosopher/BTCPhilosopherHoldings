"""Shared, dependency-free types for LONDON CIPHER — Sentinel Firewall.

Every other package depends on this one; this package depends on nothing but
the standard library. It defines:

* enumerations for the closed vocabularies used by policy and IR,
* naming rules (regular expressions) that bound every identifier which can
  reach an enforcement backend,
* the exception hierarchy,
* the backend-neutral intermediate representation (see :mod:`cipher_types.ir`).
"""

from __future__ import annotations

import enum
import re
from dataclasses import dataclass, field
from typing import Iterable

__all__ = [
    "SCHEMA_VERSION",
    "TABLE_NAME",
    "RULE_ID_RE",
    "NAME_RE",
    "IFACE_RE",
    "Action",
    "DefaultAction",
    "Hook",
    "Family",
    "Protocol",
    "CtState",
    "Severity",
    "Issue",
    "CipherError",
    "PolicyError",
    "CompileError",
    "CapabilityError",
    "BackendError",
    "VerificationError",
    "StateError",
    "ConflictError",
    "AuthorizationError",
    "ProtocolError",
    "LimitExceeded",
]

#: Version of the declarative policy schema understood by this release.
SCHEMA_VERSION = 1

#: The dedicated nftables table managed by LONDON CIPHER. Nothing outside this
#: table is created, modified or deleted by the nftables backend.
TABLE_NAME = "london_cipher"

#: Stable rule identifiers. Dots are reserved for generated (essential.*,
#: default.*) rules so user identifiers can never collide with them.
RULE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,47}$")

#: Names of zones, address sets, service sets and dynamic sets.
NAME_RE = re.compile(r"^[a-z][a-z0-9_]{0,39}$")

#: Linux interface names (IFNAMSIZ = 16 including NUL). A single trailing ``*``
#: wildcard is permitted, matching nftables ``iifname "eth*"`` semantics.
IFACE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:@-]{0,14}\*?$")


class _StrEnum(str, enum.Enum):
    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.value


class Action(_StrEnum):
    """Terminal rule actions. Every user rule ends evaluation."""

    ACCEPT = "accept"
    DROP = "drop"
    REJECT = "reject"


class DefaultAction(_StrEnum):
    """Chain default policies. nftables base chains support accept or drop."""

    ACCEPT = "accept"
    DROP = "drop"


class Hook(_StrEnum):
    INPUT = "input"
    OUTPUT = "output"
    FORWARD = "forward"


class Family(_StrEnum):
    ANY = "any"
    IPV4 = "ipv4"
    IPV6 = "ipv6"

    def expand(self) -> tuple["Family", ...]:
        if self is Family.ANY:
            return (Family.IPV4, Family.IPV6)
        return (self,)


class Protocol(_StrEnum):
    TCP = "tcp"
    UDP = "udp"
    ICMP = "icmp"
    ICMPV6 = "icmpv6"

    @property
    def has_ports(self) -> bool:
        return self in (Protocol.TCP, Protocol.UDP)


class CtState(_StrEnum):
    NEW = "new"
    ESTABLISHED = "established"
    RELATED = "related"
    INVALID = "invalid"
    UNTRACKED = "untracked"


class Severity(_StrEnum):
    ERROR = "error"
    WARNING = "warning"


@dataclass(frozen=True)
class Issue:
    """A validation or compilation finding, addressed by a JSON-pointer-like path."""

    severity: Severity
    code: str
    path: str
    message: str

    def to_dict(self) -> dict:
        return {
            "severity": self.severity.value,
            "code": self.code,
            "path": self.path,
            "message": self.message,
        }

    def __str__(self) -> str:
        return f"{self.severity.value}: {self.path}: {self.message} [{self.code}]"


class CipherError(Exception):
    """Base class for all LONDON CIPHER errors."""

    code = "cipher.error"


@dataclass
class _IssueCarrier:
    issues: list[Issue] = field(default_factory=list)


class PolicyError(CipherError):
    """Raised when a policy document is rejected. Carries every finding."""

    code = "policy.invalid"

    def __init__(self, issues: Iterable[Issue]):
        self.issues = list(issues)
        errors = [i for i in self.issues if i.severity is Severity.ERROR]
        head = "; ".join(str(i) for i in errors[:5])
        more = f" (+{len(errors) - 5} more)" if len(errors) > 5 else ""
        super().__init__(f"policy rejected with {len(errors)} error(s): {head}{more}")


class CompileError(CipherError):
    code = "compile.failed"


class CapabilityError(CipherError):
    code = "backend.capability"


class BackendError(CipherError):
    code = "backend.failed"


class VerificationError(CipherError):
    code = "backend.verification"


class StateError(CipherError):
    code = "state.error"


class ConflictError(CipherError):
    code = "backend.conflict"


class AuthorizationError(CipherError):
    code = "admin.unauthorized"


class ProtocolError(CipherError):
    code = "admin.protocol"


class LimitExceeded(CipherError):
    code = "limit.exceeded"
