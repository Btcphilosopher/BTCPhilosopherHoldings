"""Backend-neutral intermediate representation (IR).

The compiler lowers a validated :class:`cipher_policy.model.Policy` into these
frozen dataclasses. Enforcement backends consume only the IR, never the policy
document, so a new backend can be added without touching policy semantics.

Semantics encoded by the IR (all backends must preserve them):

* A ruleset owns exactly one namespace (``table``) and never touches others.
* Chains are evaluated rule by rule, in tuple order; the first rule whose
  matches all succeed and which carries a terminal ``verdict`` ends evaluation.
* ``log`` on a rule is non-terminal and rate limited; it is emitted for the
  same packets the rule matches, subject to the limiter.
* When no rule matches, the chain ``policy`` applies.
* Matches inside a rule are conjunctive. Values inside one match are
  disjunctive (e.g. a set of ports).
* ``digest`` identifies the compiled policy (it excludes elements of dynamic
  sets, which change without a policy revision).
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field, fields, is_dataclass
from typing import Any, Literal, Optional, Union

AddrFamily = Literal["ipv4", "ipv6"]


@dataclass(frozen=True, order=True)
class PortRange:
    low: int
    high: int

    def __post_init__(self) -> None:
        if not (0 < self.low <= self.high <= 65535):
            raise ValueError(f"invalid port range {self.low}-{self.high}")

    def contains(self, other: "PortRange") -> bool:
        return self.low <= other.low and other.high <= self.high

    def __str__(self) -> str:
        return str(self.low) if self.low == self.high else f"{self.low}-{self.high}"


# --------------------------------------------------------------------------
# Matches
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class MNfproto:
    """Restrict a rule to one address family (``meta nfproto``)."""

    family: AddrFamily


@dataclass(frozen=True)
class MIface:
    direction: Literal["iifname", "oifname"]
    names: tuple[str, ...]
    negate: bool = False


@dataclass(frozen=True)
class MAddr:
    """Source or destination address match.

    Exactly one of ``networks`` (inline, canonical CIDR strings) or
    ``set_name`` (a named IR set of the same family) is populated.
    """

    family: AddrFamily
    field: Literal["saddr", "daddr"]
    networks: tuple[str, ...] = ()
    set_name: Optional[str] = None


@dataclass(frozen=True)
class ML4:
    protocol: Literal["tcp", "udp", "icmp", "icmpv6"]


@dataclass(frozen=True)
class MPort:
    protocol: Literal["tcp", "udp"]
    field: Literal["sport", "dport"]
    ports: tuple[PortRange, ...]


@dataclass(frozen=True)
class MIcmp:
    protocol: Literal["icmp", "icmpv6"]
    types: tuple[str, ...]


@dataclass(frozen=True)
class MCtState:
    states: tuple[str, ...]


@dataclass(frozen=True)
class MHopLimit:
    """IPv6 hop limit equality (RFC 4861 requires 255 for neighbour discovery)."""

    value: int


Match = Union[MNfproto, MIface, MAddr, ML4, MPort, MIcmp, MCtState, MHopLimit]


# --------------------------------------------------------------------------
# Statements
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class SLog:
    prefix: str
    level: str
    rate: int
    per: str
    burst: int


@dataclass(frozen=True)
class SNat:
    kind: Literal["masquerade", "snat", "dnat"]
    family: Optional[AddrFamily] = None
    addr: Optional[str] = None
    port: Optional[int] = None


@dataclass(frozen=True)
class IRRule:
    rule_id: str
    origin: Literal["essential", "user", "default", "nat"]
    matches: tuple[Match, ...]
    part: str = ""
    verdict: Optional[Literal["accept", "drop", "reject"]] = None
    log: Optional[SLog] = None
    nat: Optional[SNat] = None


@dataclass(frozen=True)
class IRChain:
    name: str
    kind: Literal["filter", "nat"]
    hook: Optional[str]
    priority: int
    policy: Optional[Literal["accept", "drop"]]
    rules: tuple[IRRule, ...] = ()


@dataclass(frozen=True)
class IRSet:
    name: str
    family: AddrFamily
    elements: tuple[str, ...] = ()
    dynamic: bool = False
    source: str = "static"
    timeout: bool = False
    max_elements: int = 65536

    @property
    def nft_type(self) -> str:
        return "ipv4_addr" if self.family == "ipv4" else "ipv6_addr"


@dataclass(frozen=True)
class IRRuleset:
    table: str
    policy_id: str
    revision: int
    chains: tuple[IRChain, ...]
    sets: tuple[IRSet, ...] = ()
    features: tuple[str, ...] = ()
    excluded_rules: tuple[tuple[str, str], ...] = ()
    next_expiry: Optional[str] = None
    digest: str = field(default="", compare=False)

    def chain(self, name: str) -> IRChain:
        for c in self.chains:
            if c.name == name:
                return c
        raise KeyError(name)

    def set(self, name: str) -> IRSet:
        for s in self.sets:
            if s.name == name:
                return s
        raise KeyError(name)

    def with_digest(self) -> "IRRuleset":
        from dataclasses import replace

        return replace(self, digest=compute_digest(self))

    def with_dynamic_elements(self, elements: dict[str, tuple[str, ...]]) -> "IRRuleset":
        """Return a copy whose dynamic sets carry ``elements`` (digest unchanged)."""
        from dataclasses import replace

        new_sets = []
        for s in self.sets:
            if s.dynamic and s.name in elements:
                new_sets.append(replace(s, elements=tuple(elements[s.name])))
            else:
                new_sets.append(s)
        return replace(self, sets=tuple(new_sets))


def rule_key(r: "IRRule") -> str:
    """Stable display/verification key of an IR rule: ``<rule-id>[<part>]``."""
    return f"{r.rule_id}[{r.part}]" if r.part else r.rule_id


def to_jsonable(obj: Any) -> Any:
    """Canonical, type-tagged JSON form of IR objects."""
    if is_dataclass(obj) and not isinstance(obj, type):
        out: dict[str, Any] = {"_t": type(obj).__name__}
        for f in fields(obj):
            out[f.name] = to_jsonable(getattr(obj, f.name))
        return out
    if isinstance(obj, (list, tuple)):
        return [to_jsonable(x) for x in obj]
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in sorted(obj.items())}
    return obj


def canonical_json(obj: Any) -> str:
    return json.dumps(to_jsonable(obj), sort_keys=True, separators=(",", ":"))


def compute_digest(rs: IRRuleset) -> str:
    """SHA-256 over the canonical IR, excluding dynamic set elements and the digest."""
    data = to_jsonable(rs)
    data.pop("digest", None)
    for s in data["sets"]:
        if s["dynamic"]:
            s["elements"] = []
    blob = json.dumps(data, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(blob).hexdigest()


__all__ = [
    "PortRange",
    "MNfproto",
    "MIface",
    "MAddr",
    "ML4",
    "MPort",
    "MIcmp",
    "MCtState",
    "MHopLimit",
    "Match",
    "SLog",
    "SNat",
    "IRRule",
    "IRChain",
    "IRSet",
    "IRRuleset",
    "to_jsonable",
    "rule_key",
    "canonical_json",
    "compute_digest",
    "asdict",
]
