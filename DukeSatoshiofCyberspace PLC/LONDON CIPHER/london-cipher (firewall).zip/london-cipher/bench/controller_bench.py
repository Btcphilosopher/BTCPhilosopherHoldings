#!/usr/bin/env python3
"""Controller (Python) performance — separate from kernel packet processing.

Measures, on synthetic policies of increasing size:

* validation time (incl. shadow analysis), compile time, render size;
* nftables transaction time: LONDON CIPHER engine apply (validate + compile +
  dry-run + apply + verify + commit) versus the *direct backend baseline*
  (``nft -j -f`` of the identical JSON, nothing else);
* verification time and large-set behaviour (1k..100k elements);
* event-processing overhead (kernel-log parsing + bounded bus);
* recovery time (restore last-known-good; reinstall after table loss).

Kernel operations run inside a throwaway network namespace (root required);
without root only the pure-Python measurements are taken.

    sudo python3 bench/controller_bench.py --out results/bench-controller.json
"""

from __future__ import annotations

import argparse
import json
import os
import statistics
import subprocess
import sys
import tempfile
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import yaml  # noqa: E402

from bench.envinfo import environment  # noqa: E402
from cipher_backend import CommandRunner, NftablesBackend, netns_prefix  # noqa: E402
from cipher_backend.nftables import render_commands  # noqa: E402
from cipher_compiler import compile_policy  # noqa: E402
from cipher_events import EventBus, parse_line  # noqa: E402
from cipher_policy import validate_text  # noqa: E402
from cipher_state import Engine, StateStore  # noqa: E402


def synth_policy(n_rules: int, set_size: int = 16, revision: int = 1) -> str:
    """n_rules non-overlapping accept rules (distinct ports) plus one address set."""
    addrs = [f"10.{(i >> 16) & 255}.{(i >> 8) & 255}.{i & 255}/32" for i in range(1, set_size + 1)]
    rules = [
        {"id": f"r{i}", "chain": "input", "action": "accept", "family": "ipv4", "source": {"sets": ["clients"]}, "protocol": "tcp", "ports": [1024 + i], "justification": "synthetic benchmark rule"}
        for i in range(n_rules)
    ]
    d = {
        "schema_version": 1,
        "policy": {"id": "bench", "revision": revision},
        "address_sets": {"clients": {"addresses": addrs}},
        "defaults": {"input": "drop", "output": "accept", "forward": "drop"},
        "rules": rules,
    }
    return yaml.safe_dump(d, sort_keys=False)


def timed(fn, repeat: int = 3):
    xs = []
    out = None
    for _ in range(repeat):
        t0 = time.perf_counter()
        out = fn()
        xs.append(time.perf_counter() - t0)
    return out, {"median_ms": round(statistics.median(xs) * 1000, 2), "min_ms": round(min(xs) * 1000, 2), "runs": repeat}


def python_only(sizes: list[int]) -> list[dict]:
    rows = []
    for n in sizes:
        text = synth_policy(n)
        (pol, _), t_val = timed(lambda: validate_text(text), 3)
        res, t_comp = timed(lambda: compile_policy(pol), 3)
        payload = json.dumps({"nftables": render_commands(res.ruleset)})
        rows.append({"rules": n, "validate": t_val, "compile": t_comp, "nft_json_bytes": len(payload)})
        print(f"  rules={n:5d} validate={t_val['median_ms']}ms compile={t_comp['median_ms']}ms json={len(payload)}B", flush=True)
    return rows


def event_overhead(n: int = 50_000) -> dict:
    line = "lc:ssh:D IN=eth0 OUT= SRC=192.0.2.5 DST=192.0.2.1 LEN=60 PROTO=TCP SPT=40000 DPT=22"
    t0 = time.perf_counter()
    for _ in range(n):
        parse_line(line)
    parse_s = time.perf_counter() - t0
    bus = EventBus(rate_per_kind=1e9, burst_per_kind=10**9, max_queue=n + 1)
    ev = parse_line(line)
    t0 = time.perf_counter()
    for _ in range(n):
        bus.publish(ev)
    pub_s = time.perf_counter() - t0
    shed = EventBus(rate_per_kind=100, burst_per_kind=100, max_queue=1000)
    t0 = time.perf_counter()
    for _ in range(n):
        shed.publish(ev)
    shed_s = time.perf_counter() - t0
    return {
        "events": n,
        "parse_per_s": round(n / parse_s),
        "publish_per_s": round(n / pub_s),
        "publish_when_rate_limited_per_s": round(n / shed_s),
        "rate_limited_dropped": shed.counters()["dropped"]["rate_limited"],
    }


def kernel(sizes: list[int], set_sizes: list[int]) -> dict:
    ns = f"lcbench{os.getpid()}"
    subprocess.run(["ip", "netns", "add", ns], check=True)
    try:
        runner = CommandRunner(netns_prefix(ns))
        be = NftablesBackend(runner)
        out: dict = {"apply": [], "large_sets": [], "recovery": {}}
        for n in sizes:
            with tempfile.TemporaryDirectory() as td:
                be.remove()
                eng = Engine(be, StateStore(td))
                rev = [0]

                def engine_apply():
                    rev[0] += 1
                    return eng.apply(synth_policy(n, revision=rev[0]), actor="bench")

                _, t_engine = timed(engine_apply, 3)
                rs = eng.plan(synth_policy(n, revision=rev[0])).ruleset
                payload = json.dumps({"nftables": render_commands(rs)})
                _, t_direct = timed(lambda: runner.run(["nft", "-j", "-f", "-"], stdin=payload, check=True), 3)
                _, t_verify = timed(lambda: be.verify(rs), 3)
                out["apply"].append({"rules": n, "engine_apply_end_to_end": t_engine, "direct_nft_baseline": t_direct, "verify": t_verify})
                print(f"  rules={n:5d} engine={t_engine['median_ms']}ms direct-nft={t_direct['median_ms']}ms verify={t_verify['median_ms']}ms", flush=True)
        for size in [s for s in set_sizes if s <= 10_000]:
            # static address sets are bounded by the policy list limit (10,000 per list)
            with tempfile.TemporaryDirectory() as td:
                be.remove()
                eng = Engine(be, StateStore(td))
                text = synth_policy(10, set_size=size)
                _, t = timed(lambda: eng.apply(text, actor="bench"), 1)
                rs = eng.plan(text).ruleset
                _, tv = timed(lambda: be.verify(rs), 1)
                out["large_sets"].append({"kind": "static", "set_elements": size, "engine_apply_end_to_end": t, "verify": tv})
                print(f"  static set={size:6d} apply={t['median_ms']}ms verify={tv['median_ms']}ms", flush=True)
        for size in set_sizes:
            # larger memberships use feed-sourced dynamic sets (atomic flush+add)
            with tempfile.TemporaryDirectory() as td:
                be.remove()
                eng = Engine(be, StateStore(td))
                d = yaml.safe_load(synth_policy(10))
                d["dynamic_sets"] = {"feed": {"family": "ipv4", "source": "feed", "max_elements": max(set_sizes)}}
                d["rules"].insert(0, {"id": "feed-drop", "chain": "input", "action": "drop", "family": "ipv4", "source": {"sets": ["feed"]}, "justification": "bench"})
                eng.apply(yaml.safe_dump(d), actor="bench")
                vals = [f"100.{(i >> 16) & 255}.{(i >> 8) & 255}.{i & 255}" for i in range(size)]
                _, t = timed(lambda: eng.update_dynamic_set("feed", vals, source="feed", actor="bench", provenance={}), 1)
                out["large_sets"].append({"kind": "dynamic-feed", "set_elements": size, "update_and_verify": t})
                print(f"  dynamic set={size:6d} update+verify={t['median_ms']}ms", flush=True)
        with tempfile.TemporaryDirectory() as td:
            be.remove()
            eng = Engine(be, StateStore(td))
            eng.apply(synth_policy(500), actor="bench")
            eng.apply(synth_policy(500, revision=2), actor="bench", confirm_timeout=60)
            _, t_rb = timed(lambda: eng.rollback(actor="bench", reason="benchmark"), 1)
            be.remove()
            _, t_re = timed(lambda: eng.recover(actor="bench"), 1)
            out["recovery"] = {"rules": 500, "rollback_to_lkg": t_rb, "reinstall_after_table_loss": t_re}
            print(f"  recovery rollback={t_rb['median_ms']}ms reinstall={t_re['median_ms']}ms", flush=True)
        return out
    finally:
        subprocess.run(["ip", "netns", "del", ns])


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "bench-controller.json"))
    ap.add_argument("--sizes", default="10,100,1000,4000")
    ap.add_argument("--set-sizes", default="1000,10000,100000")
    a = ap.parse_args()
    sizes = [int(x) for x in a.sizes.split(",")]
    report = {"benchmark": "controller", "environment": environment(), "method": __doc__.strip()}
    print("python-only:")
    report["python"] = python_only(sizes)
    report["events"] = event_overhead()
    print("events:", report["events"])
    if os.geteuid() == 0:
        print("kernel (namespace):")
        report["kernel"] = kernel(sizes, [int(x) for x in a.set_sizes.split(",")])
    else:
        report["kernel"] = "skipped: requires root"
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    with open(a.out, "w") as fh:
        json.dump(report, fh, indent=1)
    print(f"wrote {a.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
