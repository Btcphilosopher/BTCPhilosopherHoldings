"""Record the conditions every benchmark result depends on."""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
from datetime import datetime, timezone


def _out(argv: list[str]) -> str | None:
    if shutil.which(argv[0]) is None:
        return None
    try:
        return subprocess.run(argv, capture_output=True, text=True, timeout=10).stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        return None


def environment() -> dict:
    cpu = None
    lscpu = _out(["lscpu"]) or ""
    for line in lscpu.splitlines():
        if line.startswith("Model name:"):
            cpu = line.split(":", 1)[1].strip()
    mem_kb = None
    try:
        with open("/proc/meminfo") as fh:
            for line in fh:
                if line.startswith("MemTotal:"):
                    mem_kb = int(line.split()[1])
    except OSError:
        pass
    virt = _out(["systemd-detect-virt"])
    return {
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "cpu_model": cpu,
        "cpu_count": os.cpu_count(),
        "memory_mib": mem_kb // 1024 if mem_kb else None,
        "virtualization": virt or "unknown (systemd-detect-virt unavailable)",
        "kernel": platform.release(),
        "python": platform.python_version(),
        "nft": _out(["nft", "--version"]),
        "iperf3": (_out(["iperf3", "--version"]) or "").splitlines()[0] if shutil.which("iperf3") else None,
        "ipv6_kernel_support": os.path.exists("/proc/net/if_inet6"),
        "note": "Single-run measurements in a shared virtual machine; treat as indicative, rerun on target hardware.",
    }
