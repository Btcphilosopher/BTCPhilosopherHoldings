#!/usr/bin/env python3
"""Kernel packet-processing performance in the namespace laboratory.

Client namespace "ok" -> protected host "host" over a veth/bridge path.
Scenarios (each with F "filler" rules that never match, evaluated before the
application rule, to expose per-rule costs):

* ``none``          no ruleset at all (path baseline)
* ``cipher``        LONDON CIPHER lab policy (host-rev1 + iperf port + F fillers),
                    compiled and installed by the engine
* ``handwritten``   an idiomatic hand-written nftables ruleset with the same
                    semantics, fillers expressed as ONE anonymous-set lookup
                    (direct backend baseline)

Metrics: TCP throughput and sender/receiver CPU (iperf3 -J), established-flow
request/response latency (Python ping-pong), new-connection rate (Python
connect/close loop). Results are single runs on the recorded machine.

    sudo python3 bench/dataplane_bench.py --out results/bench-dataplane.json
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
import textwrap
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import yaml  # noqa: E402

from bench.envinfo import environment  # noqa: E402
from cipher_backend import CommandRunner, NftablesBackend, netns_prefix  # noqa: E402
from cipher_state import Engine, StateStore  # noqa: E402
from lab.netlab import Lab  # noqa: E402

RR_SCRIPT = textwrap.dedent(
    """
    import socket, time, json, statistics
    s = socket.create_connection(("10.77.0.1", 8080), timeout=5); s.recv(64)
    lat = []
    for i in range(N):
        t0 = time.perf_counter(); s.sendall(b"x\\n"); s.recv(64); lat.append(time.perf_counter() - t0)
    print(json.dumps({"median_us": round(statistics.median(lat) * 1e6, 1), "p99_us": round(sorted(lat)[int(len(lat) * 0.99)] * 1e6, 1)}))
    """
)
CONN_SCRIPT = textwrap.dedent(
    """
    import socket, time, json
    t0 = time.perf_counter(); ok = 0
    for i in range(N):
        s = socket.socket(); s.settimeout(2)
        try:
            s.connect(("10.77.0.1", 8080)); ok += 1
        except OSError:
            pass
        s.close()
    dt = time.perf_counter() - t0
    print(json.dumps({"connections": ok, "per_s": round(ok / dt, 1)}))
    """
)


def cipher_policy(fillers: int) -> str:
    with open(os.path.join(ROOT, "lab", "policies", "host-rev1.yaml")) as fh:
        d = yaml.safe_load(fh)
    filler_rules = [
        {"id": f"filler-{i}", "chain": "input", "action": "accept", "family": "ipv4", "source": {"addresses": ["192.0.2.1/32"]}, "protocol": "tcp", "ports": [20000 + i], "justification": "benchmark filler (never matches)"}
        for i in range(fillers)
    ]
    iperf = {"id": "iperf", "chain": "input", "action": "accept", "source": {"sets": ["clients"]}, "protocol": "tcp", "ports": [5201], "justification": "benchmark traffic"}
    d["rules"] = filler_rules + [iperf] + d["rules"]
    return yaml.safe_dump(d, sort_keys=False)


def handwritten(fillers: int) -> str:
    filler = f"ip saddr 192.0.2.1 tcp dport {{ 20000-{20000 + fillers - 1} }} accept" if fillers else ""
    return textwrap.dedent(
        f"""
        table inet bench_handwritten {{
          chain input {{
            type filter hook input priority 0; policy drop;
            iifname "lo" accept
            ct state invalid drop
            ct state established,related accept
            icmpv6 type {{ nd-neighbor-solicit, nd-neighbor-advert, nd-router-advert }} ip6 hoplimit 255 accept
            ip saddr 10.77.0.10 tcp dport 2222 accept
            ip6 saddr fd77::10 tcp dport 2222 accept
            {filler}
            ip saddr 10.77.0.20 tcp dport {{ 5201, 8080 }} accept
            ip6 saddr fd77::20 tcp dport {{ 5201, 8080 }} accept
            ip saddr 10.77.0.30 tcp dport 8080 reject with tcp reset
            ip saddr {{ 10.77.0.10, 10.77.0.20 }} icmp type echo-request accept
          }}
        }}
        """
    )


def measure(lab: Lab, seconds: int) -> dict:
    srv = lab.spawn("host", ["iperf3", "-s", "-1", "-J"])
    time.sleep(0.5)
    cli = lab.exec("ok", ["iperf3", "-c", "10.77.0.1", "-t", str(seconds), "-J"], check=False, timeout=seconds + 30)
    srv.wait(timeout=30)
    out: dict = {}
    try:
        j = json.loads(cli.stdout)
        out["throughput_gbit_s"] = round(j["end"]["sum_received"]["bits_per_second"] / 1e9, 3)
        out["cpu_sender_pct"] = round(j["end"]["cpu_utilization_percent"]["host_total"], 1)
        out["cpu_receiver_pct"] = round(j["end"]["cpu_utilization_percent"]["remote_total"], 1)
        out["retransmits"] = j["end"]["sum_sent"].get("retransmits")
    except (ValueError, KeyError) as exc:
        out["iperf_error"] = f"{exc}: {cli.stderr[:300]}"
    rr = lab.exec("ok", [sys.executable, "-I", "-c", "N=3000\n" + RR_SCRIPT], timeout=120)
    out["rr_latency"] = json.loads(rr.stdout)
    cr = lab.exec("ok", [sys.executable, "-I", "-c", "N=3000\n" + CONN_SCRIPT], timeout=300)
    out["new_connections"] = json.loads(cr.stdout)
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "bench-dataplane.json"))
    ap.add_argument("--fillers", default="0,1000")
    ap.add_argument("--seconds", type=int, default=5)
    a = ap.parse_args()
    if os.geteuid() != 0:
        print("requires root (network namespaces)", file=sys.stderr)
        return 2
    report: dict = {"benchmark": "dataplane", "environment": environment(), "method": __doc__.strip(), "packet_size": "iperf3 default TCP (MSS-sized segments over veth MTU 1500)", "results": []}
    with Lab(gateway=False) as lab:
        lab.serve("host", tcp=[8080], udp=[])
        be = NftablesBackend(CommandRunner(netns_prefix(lab.ns["host"])))
        for f in [int(x) for x in a.fillers.split(",")]:
            for scen in ("none", "cipher", "handwritten"):
                lab.nft("host", "flush", "ruleset")
                rule_count = 0
                if scen == "cipher":
                    with tempfile.TemporaryDirectory() as td:
                        res = Engine(be, StateStore(td)).apply(cipher_policy(f), actor="bench")
                        assert res["status"] == "active"
                    rule_count = len(be.inspect().chains["input"]["comments"])
                elif scen == "handwritten":
                    with tempfile.NamedTemporaryFile("w", suffix=".nft", delete=False) as fh:
                        fh.write(handwritten(f))
                    lab.nft("host", "-f", fh.name)
                    os.unlink(fh.name)
                    rule_count = sum(1 for line in handwritten(f).splitlines() if line.strip().endswith(("accept", "drop", "reset")))
                m = measure(lab, a.seconds)
                row = {"scenario": scen, "filler_rules": f if scen != "none" else 0, "input_chain_rules": rule_count, **m}
                report["results"].append(row)
                print(json.dumps(row), flush=True)
        lab.nft("host", "flush", "ruleset")
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    with open(a.out, "w") as fh:
        json.dump(report, fh, indent=1)
    print(f"wrote {a.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
