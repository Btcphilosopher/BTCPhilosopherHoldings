#!/usr/bin/env python3
"""Packet-outcome probes for the isolated laboratory (stdlib only).

Run inside a namespace with ``ip netns exec <ns> python3 -I probe.py ...``.

  serve --tcp 2222,8080 --udp 5300     dual-stack listeners ("ok:<port>")
  tcp HOST PORT [--timeout S]          -> {"result": open|refused|timeout|error}
  udp HOST PORT [--timeout S]          -> {"result": open|timeout|error}
  hold HOST PORT --duration S          long-lived TCP flow; reports per-message outcome

Results are single-line JSON on stdout so the harness can assert on them.
"""

from __future__ import annotations

import argparse
import json
import socket
import sys
import threading
import time


def _listen(kind: int, port: int) -> socket.socket:
    """Dual-stack listener; IPv4-only when the kernel has no IPv6."""
    try:
        s = socket.socket(socket.AF_INET6, kind)
        s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
        addr = "::"
    except OSError:
        s = socket.socket(socket.AF_INET, kind)
        addr = "0.0.0.0"
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((addr, port))
    return s


def _serve_tcp(port: int) -> None:
    s = _listen(socket.SOCK_STREAM, port)
    s.listen(128)

    def client(c: socket.socket) -> None:
        try:
            c.settimeout(120)
            c.sendall(f"ok:{port}\n".encode())
            while True:
                data = c.recv(4096)
                if not data:
                    break
                c.sendall(data)
        except OSError:
            pass
        finally:
            c.close()

    while True:
        c, _ = s.accept()
        threading.Thread(target=client, args=(c,), daemon=True).start()


def _serve_udp(port: int) -> None:
    s = _listen(socket.SOCK_DGRAM, port)
    while True:
        data, addr = s.recvfrom(2048)
        s.sendto(f"ok:{port}:".encode() + data[:64], addr)


def _family(host: str) -> int:
    return socket.AF_INET6 if ":" in host else socket.AF_INET


def tcp(host: str, port: int, timeout: float, expect: int | None = None) -> dict:
    t0 = time.monotonic()
    s = socket.socket(_family(host), socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect((host, port))
        banner = s.recv(64).decode(errors="replace").strip()
        return {"result": "open" if banner == f"ok:{expect or port}" else "error", "banner": banner, "elapsed": round(time.monotonic() - t0, 3)}
    except socket.timeout:
        return {"result": "timeout", "elapsed": round(time.monotonic() - t0, 3)}
    except ConnectionRefusedError:
        return {"result": "refused", "elapsed": round(time.monotonic() - t0, 3)}
    except OSError as exc:
        return {"result": "error", "error": str(exc), "elapsed": round(time.monotonic() - t0, 3)}
    finally:
        s.close()


def udp(host: str, port: int, timeout: float) -> dict:
    t0 = time.monotonic()
    s = socket.socket(_family(host), socket.SOCK_DGRAM)
    s.settimeout(timeout)
    try:
        s.sendto(b"probe", (host, port))
        data, _ = s.recvfrom(2048)
        return {"result": "open" if data.startswith(f"ok:{port}:".encode()) else "error", "elapsed": round(time.monotonic() - t0, 3)}
    except socket.timeout:
        return {"result": "timeout", "elapsed": round(time.monotonic() - t0, 3)}
    except ConnectionRefusedError:
        return {"result": "refused", "elapsed": round(time.monotonic() - t0, 3)}
    except OSError as exc:
        return {"result": "error", "error": str(exc)}
    finally:
        s.close()


def hold(host: str, port: int, duration: float, interval: float) -> None:
    """Keep one TCP connection open; print one JSON line per exchange."""
    s = socket.socket(_family(host), socket.SOCK_STREAM)
    s.settimeout(2)
    s.connect((host, port))
    s.recv(64)
    print(json.dumps({"event": "connected"}), flush=True)
    end = time.monotonic() + duration
    n = 0
    while time.monotonic() < end:
        n += 1
        msg = f"m{n}\n".encode()
        try:
            s.sendall(msg)
            got = s.recv(64)
            ok = got == msg
        except OSError:
            ok = False
        print(json.dumps({"event": "exchange", "n": n, "ok": ok, "t": round(time.monotonic(), 3)}), flush=True)
        time.sleep(interval)
    s.close()


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("serve")
    p.add_argument("--tcp", default="")
    p.add_argument("--udp", default="")
    for name in ("tcp", "udp"):
        p = sub.add_parser(name)
        p.add_argument("host")
        p.add_argument("port", type=int)
        p.add_argument("--timeout", type=float, default=1.5)
        p.add_argument("--expect", type=int, help="expected server port in banner (port forwarding)")
    p = sub.add_parser("hold")
    p.add_argument("host")
    p.add_argument("port", type=int)
    p.add_argument("--duration", type=float, default=10)
    p.add_argument("--interval", type=float, default=0.25)
    a = ap.parse_args()
    if a.cmd == "serve":
        threads = [threading.Thread(target=_serve_tcp, args=(int(x),), daemon=True) for x in a.tcp.split(",") if x]
        threads += [threading.Thread(target=_serve_udp, args=(int(x),), daemon=True) for x in a.udp.split(",") if x]
        for t in threads:
            t.start()
        print(json.dumps({"event": "serving"}), flush=True)
        while True:
            time.sleep(3600)
    elif a.cmd == "tcp":
        print(json.dumps(tcp(a.host, a.port, a.timeout, a.expect)))
    elif a.cmd == "udp":
        print(json.dumps(udp(a.host, a.port, a.timeout)))
    elif a.cmd == "hold":
        hold(a.host, a.port, a.duration, a.interval)
    return 0


if __name__ == "__main__":
    sys.exit(main())
