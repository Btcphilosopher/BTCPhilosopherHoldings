"""Isolated network-namespace laboratory.

Safety properties (enforced in code, not just convention):

* Every interface is created *inside* a laboratory namespace (``ip -n``);
  the host's own namespace gains no links, addresses, routes or rules.
* Namespace names are unique (``lc<tag>-<role>``) and the lab refuses to start
  if any already exist, so it never adopts or deletes something it did not
  create.
* Teardown deletes only the namespaces it created; deleting a namespace
  destroys its interfaces and its nftables ruleset.
* Forwarding sysctls are enabled only inside the gateway namespace.

Topology::

    mgmt  10.77.0.10  fd77::10 ─┐
    ok    10.77.0.20  fd77::20 ─┼── br0 (ns "sw") ── lan0 host 10.77.0.1 fd77::1  [firewall under test]
    deny  10.77.0.30  fd77::30 ─┘

    inner 10.78.0.2 fd78::2 ── in0 gw 10.78.0.1 fd78::1 | out0 10.79.0.1 fd79::1 ── outer 10.79.0.2 fd79::2
                                [routed gateway under test; outer has no route back to 10.78/24]
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from typing import Optional

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PROBE = os.path.join(HERE, "probe.py")

LAN_NODES = {
    "host": ("10.77.0.1", "fd77::1"),
    "mgmt": ("10.77.0.10", "fd77::10"),
    "ok": ("10.77.0.20", "fd77::20"),
    "deny": ("10.77.0.30", "fd77::30"),
}


class LabError(RuntimeError):
    pass


def lab_available() -> tuple[bool, str]:
    if os.geteuid() != 0:
        return False, "requires root (network namespaces)"
    for tool in ("ip", "nft", "ping"):
        if shutil.which(tool) is None:
            return False, f"{tool} not installed"
    r = subprocess.run(["ip", "netns", "add", f"lcprobe{os.getpid()}"], capture_output=True)
    if r.returncode != 0:
        return False, f"cannot create namespaces: {r.stderr.decode().strip()}"
    subprocess.run(["ip", "netns", "del", f"lcprobe{os.getpid()}"], capture_output=True)
    return True, "ok"


def ipv6_available() -> bool:
    """True if the running kernel provides IPv6 (some kernels boot with it disabled)."""
    return os.path.exists("/proc/net/if_inet6")


def _run(argv: list[str], check: bool = True, timeout: float = 30, **kw) -> subprocess.CompletedProcess:
    r = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, **kw)
    if check and r.returncode != 0:
        raise LabError(f"{' '.join(argv)} failed: {r.stderr.strip()}")
    return r


class Lab:
    def __init__(self, tag: Optional[str] = None, gateway: bool = True):
        self.tag = tag or f"{os.getpid() % 100000:05d}"
        self.gateway = gateway
        roles = ["sw", *LAN_NODES] + (["gw", "inner", "outer"] if gateway else [])
        self.ns = {r: f"lc{self.tag}-{r}" for r in roles}
        self.procs: list[subprocess.Popen] = []
        self.created: list[str] = []
        #: IPv6 packet tests are only meaningful when the kernel supports IPv6.
        #: When it does not, tests must *skip and report* rather than pass.
        self.ipv6 = ipv6_available()

    # -- lifecycle --------------------------------------------------------------
    def up(self) -> "Lab":
        existing = set(_run(["ip", "netns", "list"]).stdout.split())
        clash = [n for n in self.ns.values() if n in existing]
        if clash:
            raise LabError(f"namespaces already exist (refusing to adopt): {clash}")
        try:
            for name in self.ns.values():
                _run(["ip", "netns", "add", name])
                self.created.append(name)
                self.ip(name, "link", "set", "lo", "up")
            sw = self.ns["sw"]
            self.ip(sw, "link", "add", "br0", "type", "bridge")
            self.ip(sw, "link", "set", "br0", "up")
            for role, (v4, v6) in LAN_NODES.items():
                port = f"p-{role}"
                self.ip(sw, "link", "add", port, "type", "veth", "peer", "name", "lan0", "netns", self.ns[role])
                self.ip(sw, "link", "set", port, "master", "br0", "up")
                n = self.ns[role]
                self.ip(n, "addr", "add", f"{v4}/24", "dev", "lan0")
                if self.ipv6:
                    self.ip(n, "-6", "addr", "add", f"{v6}/64", "dev", "lan0", "nodad")
                self.ip(n, "link", "set", "lan0", "up")
            if self.gateway:
                gw, inner, outer = self.ns["gw"], self.ns["inner"], self.ns["outer"]
                self.ip(gw, "link", "add", "in0", "type", "veth", "peer", "name", "lan0", "netns", inner)
                self.ip(gw, "link", "add", "out0", "type", "veth", "peer", "name", "wan0", "netns", outer)
                for n, dev, v4, v6 in (
                    (gw, "in0", "10.78.0.1/24", "fd78::1/64"),
                    (gw, "out0", "10.79.0.1/24", "fd79::1/64"),
                    (inner, "lan0", "10.78.0.2/24", "fd78::2/64"),
                    (outer, "wan0", "10.79.0.2/24", "fd79::2/64"),
                ):
                    self.ip(n, "addr", "add", v4, "dev", dev)
                    if self.ipv6:
                        self.ip(n, "-6", "addr", "add", v6, "dev", dev, "nodad")
                    self.ip(n, "link", "set", dev, "up")
                self.ip(inner, "route", "add", "default", "via", "10.78.0.1")
                self.exec("gw", ["sysctl", "-qw", "net.ipv4.ip_forward=1"])
                if self.ipv6:
                    self.ip(inner, "-6", "route", "add", "default", "via", "fd78::1")
                    self.ip(outer, "-6", "route", "add", "fd78::/64", "via", "fd79::1")
                    self.exec("gw", ["sysctl", "-qw", "net.ipv6.conf.all.forwarding=1"])
            time.sleep(0.3)
        except Exception:
            self.down()
            raise
        return self

    def down(self) -> None:
        for p in self.procs:
            if p.poll() is None:
                p.kill()
                try:
                    p.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    pass
        self.procs.clear()
        for name in reversed(self.created):
            subprocess.run(["ip", "netns", "del", name], capture_output=True)
        self.created.clear()

    def __enter__(self) -> "Lab":
        return self.up()

    def __exit__(self, *exc) -> None:
        self.down()

    # -- execution ----------------------------------------------------------------
    def ip(self, ns: str, *args: str) -> None:
        _run(["ip", "-n", ns, *args])

    def argv(self, role: str, argv: list[str]) -> list[str]:
        return ["ip", "netns", "exec", self.ns[role], *argv]

    def exec(self, role: str, argv: list[str], check: bool = True, timeout: float = 30) -> subprocess.CompletedProcess:
        return _run(self.argv(role, argv), check=check, timeout=timeout)

    def spawn(self, role: str, argv: list[str], **kw) -> subprocess.Popen:
        p = subprocess.Popen(self.argv(role, argv), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, **kw)
        self.procs.append(p)
        return p

    # -- probes -----------------------------------------------------------------------
    def serve(self, role: str, tcp: list[int], udp: list[int]) -> subprocess.Popen:
        p = self.spawn(role, [sys.executable, "-I", PROBE, "serve", "--tcp", ",".join(map(str, tcp)), "--udp", ",".join(map(str, udp))])
        line = p.stdout.readline()  # type: ignore[union-attr]
        if "serving" not in line:
            raise LabError(f"probe server failed: {line} {p.stderr.read() if p.stderr else ''}")
        time.sleep(0.2)
        return p

    def tcp(self, src: str, host: str, port: int, timeout: float = 1.5, expect: Optional[int] = None) -> str:
        argv = [sys.executable, "-I", PROBE, "tcp", host, str(port), "--timeout", str(timeout)]
        if expect:
            argv += ["--expect", str(expect)]
        r = self.exec(src, argv, timeout=timeout + 10)
        return json.loads(r.stdout)["result"]

    def udp(self, src: str, host: str, port: int, timeout: float = 1.5) -> str:
        r = self.exec(src, [sys.executable, "-I", PROBE, "udp", host, str(port), "--timeout", str(timeout)], timeout=timeout + 10)
        return json.loads(r.stdout)["result"]

    def ping(self, src: str, host: str, timeout: int = 1) -> bool:
        argv = ["ping", "-n", "-c", "1", "-W", str(timeout)]
        if ":" in host:
            argv.insert(1, "-6")
        return self.exec(src, argv + [host], check=False, timeout=timeout + 10).returncode == 0

    def nft(self, role: str, *args: str, check: bool = True) -> subprocess.CompletedProcess:
        return self.exec(role, ["nft", *args], check=check)

    def helper_cmd(self, state_dir: str, socket_path: str, logdir: str, tick: float = 0.2) -> list[str]:
        return [
            sys.executable,
            "-m",
            "cipher_admin.helper",
            "serve",
            "--state-dir",
            state_dir,
            "--socket",
            socket_path,
            "--audit-log",
            os.path.join(logdir, "audit.jsonl"),
            "--event-log",
            os.path.join(logdir, "events.jsonl"),
            "--allowed-uid",
            "0",
            "--tick",
            str(tick),
        ]

    def start_helper(self, role: str, state_dir: str, socket_path: str, logdir: str, tick: float = 0.2) -> subprocess.Popen:
        env = dict(os.environ, PYTHONPATH=ROOT)
        p = subprocess.Popen(self.argv(role, self.helper_cmd(state_dir, socket_path, logdir, tick)), stdout=subprocess.DEVNULL, stderr=open(os.path.join(logdir, "helper.stderr"), "a"), env=env, cwd=ROOT)
        self.procs.append(p)
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            if os.path.exists(socket_path):
                return p
            if p.poll() is not None:
                raise LabError(f"helper exited early (code {p.returncode}); see {logdir}/helper.stderr")
            time.sleep(0.05)
        raise LabError("helper did not create its socket")
