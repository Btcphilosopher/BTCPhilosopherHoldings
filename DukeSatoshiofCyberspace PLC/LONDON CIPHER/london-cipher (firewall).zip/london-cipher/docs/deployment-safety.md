# Deployment safety and rollback

## Pipeline

```
Validate → Compile → Capability check → Conflict check → Dry-run (nft -c)
        → Review diff → [journal] → Apply (one nft transaction) → Verify (read-back)
        → Commit (last-known-good)   or   Pending (timed rollback armed)
```

* Nothing reaches the kernel unless validation, compilation, capability
  checks and the backend dry-run succeed.
* **Atomic apply.** The managed table is replaced with
  `add table; delete table; add table; …` in one nftables transaction.
  The laboratory test `test_kernel_rejected_change_is_atomic_and_recovered`
  submits a real batch that the kernel rejects *after* its `delete table`
  command and shows the old ruleset (fingerprint and traffic) unchanged.
* **Never active before verification.** Status `active` is reported only after
  the installed table has been read back and matched to the compiled IR
  (chains, hooks, priorities, policies, the exact ordered rule sequence, static
  set contents, metadata digest).
* **Revisions** must increase for a given policy id; reusing a revision with
  different content is rejected; re-applying identical content is idempotent.

## Last-known-good (LKG)

The LKG is the most recent policy that was installed, verified *and*
committed. Rollback always targets it (or, if none exists, the absence of the
managed table). The LKG only changes on commit.

## Timed rollback

`cipher apply --confirm-timeout N` installs and verifies the policy but does
not commit it. Unless `cipher confirm` arrives within `N` seconds (5–3600),
the helper's timer (1 s resolution by default) reinstalls the LKG. Confirm
from a **new** session: an existing SSH session survives on conntrack state
even when new management connections are blocked.

## What is recovered automatically

| Failure | Recovery | Test |
|---|---|---|
| Invalid policy (syntax, semantics) | rejected; kernel untouched | `test_syntax_rejection_changes_nothing`, lab `test_invalid_policy_never_reaches_kernel` |
| Dry-run rejected | kernel untouched | `test_dry_run_failure_changes_nothing` |
| Kernel rejects the transaction | previous ruleset still in force; verified/restored | `test_backend_transaction_failure_restores_previous`, lab atomicity test |
| Installed state fails verification | LKG reinstalled and verified | `test_verification_failure_rolls_back_cleanly` |
| Helper killed mid-apply (journal present) | LKG restored at next start | `test_real_process_termination[*]` (real `os._exit` in a child process) |
| Helper killed while a change is pending | unconfirmed change rolled back at next start | lab `test_process_termination_during_pending_change` (real SIGKILL) |
| Administrator loses connectivity after a change | timed rollback | lab `test_timed_rollback_after_lost_management_access` |
| Reboot / table lost | LKG reinstalled by restore service or helper start | lab `test_restart_preserves_committed_state` |
| External edit of the managed table | detected (`drifted`), **not** silently fought; `cipher repair` reinstalls | lab `test_external_modification_detected_and_repaired` |
| Restore itself fails | reported as CRITICAL; never claimed successful | `test_verification_failure_after_apply_rolls_back` |

## What requires out-of-band access (console, BMC, hypervisor)

* A **committed** policy that locks administrators out (it was confirmed, so
  it is the LKG). Always confirm from a fresh connection.
* The helper never running again (service disabled, binary removed, disk
  full preventing state writes) while a lockout policy is pending.
* A host that is down or a kernel that panics.
* Rules **outside** the managed table (other tables, iptables-legacy,
  firewalld) that drop management traffic; LONDON CIPHER reports foreign base
  chains but never modifies them.
* A wall-clock jump far beyond the deadline is harmless (rollback happens
  early); a large backwards jump delays rollback. Prefer NTP-disciplined clocks.
* Loss of the uplink or management network itself.

## Manual recovery

```bash
# inspect
nft list table inet london_cipher
cipher-helper status --config /etc/london-cipher/helper.yaml
# reinstall last-known-good
cipher-helper recover --config /etc/london-cipher/helper.yaml
# last resort (opens the host if nothing else filters): remove ONLY the managed table
nft delete table inet london_cipher
```
