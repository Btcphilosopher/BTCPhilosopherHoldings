# Events, auditing and privacy

## Structured events (`cipher_events.Event`)

Fields: `timestamp`, `kind`, `component`, `status`, `message`, `policy_id`,
`policy_revision`, `rule_id`, `action`, `network` (`src`, `dst`, `proto`,
`sport`, `dport`, `iif`, `oif`, `icmp_type`), `error`, `details`.

Sources:

* the engine (deploy stages, rollback, expiry, dynamic sets);
* the kernel log of rule hits: rules with `log: true` and default drops emit
  `lc:<rule-id>:<A|D|R> ` prefixed lines, rate-limited in the kernel by
  `limit rate R/per burst B`; `cipher_events.kernlog` parses header fields
  only. **No payload is captured** (the compiler never sets log flags that
  would include data).

## Bounded, observable loss

`EventBus` applies a per-kind token bucket and a bounded queue; every shed
event increments `dropped.rate_limited` or `dropped.queue_full`, and sink
failures increment `dropped.sink_error`. `cipher status` returns these
counters, so lost events are visible. The bus never blocks enforcement.

## Privacy and retention

* Redaction modes for addresses: `none`, `truncate` (/24, /48), `hash` (keyed
  HMAC pseudonyms; key from a file).
* Credential-like keys are always redacted.
* `JsonlSink` rotates by size (`max_bytes`, `backups`) and deletes rotated
  files older than `retention_days`.

## Audit trail

`AuditLog` is append-only JSON lines; each record holds `prev` and `hash`
(SHA-256 chain), written under `flock` and `fsync`ed. `cipher audit-verify
FILE` detects modified, deleted or reordered records. This is evidence, not
prevention: ship the log off-host where that matters.

Audited: plan rejections, apply (rejected / failed / pending / committed),
confirm, rollback (incl. critical failures), expiry recompiles, drift
detection, repair, removal, dynamic-set updates (with provenance), conntrack
removals (request and result), helper requests from unauthorised uids, admin
requests allowed / denied / rate-limited and their results.
