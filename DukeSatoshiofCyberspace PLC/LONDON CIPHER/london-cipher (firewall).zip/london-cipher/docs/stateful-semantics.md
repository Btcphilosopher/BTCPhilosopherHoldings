# Stateful semantics

All state comes from the kernel's connection tracking (`nf_conntrack`). There
is no Python connection tracker.

## Fixed evaluation order

**input:** loopback anti-spoof (127.0.0.0/8, ::1 not via `lo` → drop) →
`iifname lo` accept → `ct state invalid` drop → `ct state established,related`
accept → ICMPv6 ND (hop limit 255) → MLD queries from link-local → ICMPv6
errors (`related`) → ICMPv4 errors (`related`) → DHCP client replies →
admin access → user rules → rate-limited default-drop log → policy.

**output:** `oifname lo` accept → invalid drop → established/related accept →
ND/MLD transmit → ICMP errors (`related`) → DHCP client → DNS/NTP servers →
user rules → log → policy.

**forward:** invalid drop → established/related accept → user rules → log → policy.

Each essential element can be disabled in `essential:`; the
established/invalid shortcuts are controlled by `state:`.

## Behaviour by connection state

| State | Behaviour (defaults) |
|---|---|
| **new** | evaluated by user rules; first match wins; otherwise chain policy |
| **established** | accepted early (return traffic needs no rule) |
| **related** | accepted early (FTP data, ICMP errors for known flows) |
| **invalid** | dropped early; accepting `invalid` is not supported |
| **untracked** | evaluated like new |
| **return traffic** | established → accepted; this is why `output: drop` hosts still answer permitted inbound connections (lab-tested) |
| **timeouts** | kernel conntrack timeouts (`net.netfilter.nf_conntrack_*_timeout_*`); not changed by LONDON CIPHER |

With `state.established_related: evaluate` the early accept is removed and
every packet, including replies, must be permitted by rules.

## Policy changes and existing flows

A new deny rule **does not terminate existing connections**: their packets
are `established` and accepted before user rules are consulted. This is shown
by the lab test `test_existing_flows_and_audited_conntrack_removal`, which
holds a TCP session open across a policy change that denies new connections.

To end existing flows, use the audited, selector-bound removal:

```bash
cipher conntrack-delete --family ipv4 --source 10.77.0.20 --protocol tcp --dport 8080 --reason "revoke"
```

It refuses to flush the whole table, requires the `admin` role and writes two
audit records (requested, result). After removal, the next packet of the flow
is evaluated as a new connection and is dropped by the new policy (lab-tested).
