# Policy language (schema_version 1)

Policies are YAML or JSON documents. They are data: nothing is evaluated,
templated or passed to a shell. The loader rejects YAML aliases/anchors,
merge keys, custom tags, duplicate keys, multiple documents, NUL bytes,
non-UTF-8 input, nesting deeper than 32 and documents larger than 4 MiB.

## Top level

| key | required | meaning |
|---|---|---|
| `schema_version` | yes | must be `1` |
| `policy` | yes | `id` (`[a-z0-9][a-z0-9-]{0,47}`), `revision` (integer ≥ 1), `description` |
| `defaults` | yes | `input`, `output`, `forward`: `accept` or `drop` — always explicit |
| `interfaces` | no | `name: {zone: <zone>}`; a trailing `*` wildcard is allowed (`eth*`) |
| `zones` | no | `name: {networks: [...], description}`; interfaces come from `interfaces` |
| `address_sets` | no | `name: {addresses: [cidr...]}` — mixed IPv4/IPv6 allowed |
| `service_sets` | no | `name: {services: [{protocol, ports \| icmp_types}]}` |
| `dynamic_sets` | no | `name: {family, source: dns\|feed\|detection, max_elements, timeout_seconds}` |
| `state` | no | `established_related: accept\|evaluate`, `invalid: drop\|evaluate` |
| `essential` | no | loopback, ICMPv6 ND/errors, DHCP, SLAAC, DNS/NTP servers, `admin_access` |
| `logging` | no | `rate`, `per`, `burst`, `level`, `log_default_drop` |
| `rules` | no | ordered list (below) |
| `nat` | no | `masquerade`, `port_forwards` (gateway capability) |

Unknown keys anywhere are errors (a typo must not silently drop intent).

## Rules

```yaml
- id: app-clients            # stable identifier, unique across rules and NAT entries
  chain: input               # input | output | forward
  action: accept             # accept | drop | reject   (all terminal)
  family: any                # any | ipv4 | ipv6
  source:      {zone: lab, addresses: [...], sets: [...]}
  destination: {zone: ..., addresses: [...], sets: [...]}
  in_interface: [lan0]       # not allowed on output
  out_interface: [wan0]      # not allowed on input
  protocol: tcp              # tcp | udp | icmp | icmpv6
  ports: [8080, "9000-9010"] # destination ports (tcp/udp only)
  source_ports: [...]
  services: [web]            # instead of protocol/ports (never both)
  icmp_types: [echo-request]
  ct_state: [new]            # new established related invalid untracked
  log: true                  # rate-limited, non-terminal log before the verdict
  expires: 2026-12-31T23:59:00Z   # timezone mandatory
  enabled: true
  justification: Why this rule exists (required, human-readable)
```

### Semantics

* **Ordering:** within a chain, essential rules come first (fixed order, see
  `docs/stateful-semantics.md`), then user rules in document order, then an
  optional rate-limited log of default drops, then the chain's default policy.
* **First match wins.** All three actions are terminal. `reject` sends TCP RST
  for TCP rules and ICMP(v6) port-unreachable otherwise.
* **Within a rule** all conditions must hold (AND). **Within one field** any
  value may match (OR); `addresses` and `sets` of one endpoint form a union.
* **Zones:** `source.zone` matches the ingress interface(s) of the zone and,
  if the zone lists networks, also requires the source address to be in them;
  `destination.zone` likewise for egress interface / destination address.
* **Families:** a rule with `family: any` that can only ever match one family
  (e.g. IPv4-only addresses) is rejected — declare the family explicitly so
  IPv4/IPv6 divergence is always intentional. An explicit family selects the
  matching members of dual-stack sets and zones. Inline addresses of the
  other family are an error. `cipher parity` lists v4-only/v6-only rules.
* **Expiry:** expired or disabled rules are excluded at compile time; the
  helper's timer recompiles and atomically reinstalls when the next expiry
  passes. Expiry never re-orders other rules.
* **Conflicts:** if every packet a rule could match is provably matched by an
  earlier rule in the same chain, the later rule is unreachable. With a
  *different* action this is an error (`conflict.shadowed`); with the same
  action a warning (`conflict.redundant`). Analysis is sound but incomplete:
  dynamic-set membership is unknown and only identical dynamic sets are
  considered covering. Above 1500 active rules per chain the analysis is
  skipped with a warning.

### Rejected before enforcement (examples)

Host bits set (`10.0.0.1/24`), ports outside 1–65535 or reversed ranges,
ports without a protocol, `services` with `protocol`, ICMP types with the wrong
protocol, `icmp` with `family: ipv6`, accepting `ct_state: invalid`,
interfaces on the wrong chain, dangling zone/set/service references, zones
with no interfaces or networks used in rules, duplicate identifiers, expiry
without timezone, missing justification, admin access open to "any",
detection sets without a timeout, revision regression or reuse with
different content.

## Dynamic sets

Declared by the policy; populated at runtime by a controlled source.
`max_elements` is enforced by the engine and by the kernel set `size`.
Detection-sourced sets must declare `timeout_seconds`; every element expires
in the kernel and its lifetime is capped at that value.

## NAT (gateway capability)

`masquerade` entries apply in `postrouting` (priority srcnat);
`port_forwards` DNAT in `prerouting` (priority dstnat). A port forward does
not open the filter: add an explicit `forward` rule for the translated
destination. Kernel forwarding sysctls are not changed by LONDON CIPHER.
