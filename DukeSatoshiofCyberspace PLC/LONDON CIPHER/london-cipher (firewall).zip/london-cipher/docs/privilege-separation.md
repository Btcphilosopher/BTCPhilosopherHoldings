# Privilege separation

| Component | Identity | Can | Cannot |
|---|---|---|---|
| `cipher` CLI | any user | validate, compile, diff, parity, verify audit logs locally; send requests to admin.sock | touch the kernel |
| `cipher-admind` | user `cipher`, no capabilities, `RestrictAddressFamilies=AF_UNIX`, `IPAddressDeny=any` | authenticate callers (SO_PEERCRED), authorise by role, rate-limit, audit, forward | change enforcement itself; listen on a network |
| `cipher-helper` | root with `CapabilityBoundingSet=CAP_NET_ADMIN`, `AF_UNIX AF_NETLINK` only, strict sandbox | the closed op set: plan, apply, confirm, rollback, repair, status, history, dynamic_set_update, conntrack_delete, remove | run arbitrary commands, accept nft text, paths or shell fragments |

## Identity and roles

Identity is read from the kernel (`SO_PEERCRED`), never from request data.
Clients may not send an `actor`; the admin daemon adds it, and the helper only
honours it from configured `delegate_uids`.

| Role | Operations |
|---|---|
| viewer | ping, status, plan, history |
| operator | + apply, confirm, rollback |
| admin | + repair, dynamic_set_update, conntrack_delete, remove |

uid 0 is always admin. Groups: `cipher-users` (socket access), `cipher-view`,
`cipher-ops`, `cipher-admin` (roles).

## Defences in the helper

* strict per-operation argument schemas (unknown keys, wrong types and
  out-of-range values are rejected);
* re-validation and re-compilation of every policy (an unprivileged
  compilation is never trusted);
* command execution only via `CommandRunner`: argv lists, absolute tools from
  a fixed PATH, no shell, scrubbed environment, timeouts, JSON on stdin;
* bounded frames (5 MiB), bounded concurrency (busy error), socket files
  refused if a non-socket already exists at the path.

## Remote administration

Not implemented, and there is no network listener. If added, it must be a
separate component that is off by default and explicitly configured, uses
authenticated encryption (mutual TLS or SSH-forwarded Unix socket) and maps
authenticated identities onto the same roles.

## Secrets

Configuration contains no secrets except optional key-file *paths* (HMAC for
feeds, keyed hashing for redaction); key contents are never logged. Detail
keys that look like credentials (`*token*`, `*password*`, `*secret*`, …) are
replaced by `[redacted]` in events and audit records.
