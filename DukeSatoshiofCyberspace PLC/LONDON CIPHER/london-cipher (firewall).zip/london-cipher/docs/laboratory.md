# Laboratory and testing

## Unit tests (`tests/unit`, no privileges)

Loader hardening, validation (every rejection class), conflict analysis,
compiler determinism and layout, nftables JSON rendering, deployment engine
with failure injection (dry-run failure, transaction failure, verification
failure, critical restore failure, journal recovery, **real child-process
termination at three points**, restart, external modification, revision
rules, conflicts, capabilities, dynamic sets, expiry), events, audit chain,
redaction, admin schemas/roles/sockets/concurrency, CLI, DNS client and
updater, feeds, detection, research.

## Laboratory (`lab/`, `tests/integration`, root)

`lab/netlab.py` builds namespaces `lc<tag>-*`. All links are created
**inside** them, nothing is added to the host namespace, existing namespaces
are never adopted, and teardown deletes only what was created.

```
mgmt 10.77.0.10 ─┐
ok   10.77.0.20 ─┼─ bridge (ns sw) ─ host 10.77.0.1   [firewall under test]
deny 10.77.0.30 ─┘
inner 10.78.0.2 ─ gw (in0 | out0) ─ outer 10.79.0.2   [routed gateway, NAT]
```

`lab/probe.py` provides TCP/UDP servers and clients. Assertions are on
**packet outcomes** (`open`, `refused` = reject, `timeout` = drop), plus
`ping`. Generated configuration is never the thing being checked.

| Test | Demonstrates |
|---|---|
| `test_install_and_allowed_denied_traffic` | install + allowed/denied TCP, UDP, ICMP; reject vs drop; return traffic; loopback |
| `test_atomic_update_without_disruption` | 10 updates while a client continuously connects: zero failures |
| `test_kernel_rejected_change_is_atomic_and_recovered` | real kernel rejection after `delete table`: no change; engine recovery |
| `test_invalid_policy_never_reaches_kernel` | fingerprint unchanged |
| `test_external_modification_detected_and_repaired` | foreign rule takes effect, is detected, not fought, repaired on request |
| `test_other_firewall_tables_reported` | foreign base chain reported; foreign table untouched |
| `test_existing_flows_and_audited_conntrack_removal` | existing flow survives a deny; audited conntrack removal ends it |
| `test_timed_rollback_after_lost_management_access` | real helper daemon timer restores management access |
| `test_process_termination_during_pending_change` | SIGKILL with pending change → rollback on restart |
| `test_restart_preserves_committed_state` | plain restart verifies; table loss → reinstall |
| `test_gateway_forwarding_and_nat` | forward filter, masquerade, port forward, gateway input drop |
| `test_dns_derived_egress_set` | DNS-sourced set opens egress; survives re-apply |
| `test_detection_block_set_expires_in_kernel` | block takes effect and expires in the kernel |
| `test_cli_admind_helper_end_to_end` | `cipher` CLI → admin daemon → helper → kernel: apply/confirm/status/reject/rollback, audit chain |
| `test_ipv6_*` | IPv6 packet outcomes (skipped, with reason, when the kernel lacks IPv6) |

## Running

```bash
scripts/run-tests.sh          # writes results/junit-*.xml and results/test-summary.json
```

The lab must never be pointed at a production namespace; it only uses
namespaces it created.
