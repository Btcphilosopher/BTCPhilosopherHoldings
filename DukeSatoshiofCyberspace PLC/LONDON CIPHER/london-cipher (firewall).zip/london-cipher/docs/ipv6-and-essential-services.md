# IPv6 and essential network services

IPv6 is first-class: the backend uses an `inet` table, so every chain sees both
families, and every rule is compiled per family from the same policy.

## Divergence control

* A `family: any` rule that can only match one family is **rejected**, so the
  author must write `family: ipv4` or `family: ipv6` explicitly.
* `cipher parity POLICY` lists rules applied to both families, IPv4 only or
  IPv6 only (also in each `plan`).
* IPv6 is never disabled and control traffic is never broadly blocked to make
  a test pass.

## Explicit essential rules

| Setting (default) | Rule |
|---|---|
| `icmpv6_neighbor_discovery` (true) | input: NS/NA (+RA if `slaac`) with `ip6 hoplimit 255` (RFC 4861); MLD query from `fe80::/10`; output: NS/NA/RS, MLD reports |
| `slaac` (true) | accept router advertisements (hop limit 255) |
| `icmpv6_errors` (true) | destination-unreachable, packet-too-big, time-exceeded, parameter-problem for `related` flows (PMTUD, RFC 4890) |
| `icmpv4_errors` (true) | destination-unreachable, time-exceeded, parameter-problem for `related` flows |
| `dhcpv4_client` (false) | in: udp 67→68; out: udp 68→67 |
| `dhcpv6_client` (false) | in: from `fe80::/10` udp 547→546; out: udp 546→547 |
| `dns_servers` | out: udp+tcp 53 to each listed server, per family |
| `ntp_servers` | out: udp 123 to each listed server |
| `admin_access` | in: listed ports from a restricted endpoint (never "any") |
| `loopback` (accept) | `lo` accepted on input and output; anti-spoof drops loopback sources on other interfaces |

## Laboratory status

The lab has IPv6 tests for ND under default drop, TCP, UDP, ICMPv6 echo and
denied clients (`test_ipv6_allowed_denied_traffic`), plus IPv6 gateway
assertions. They run only on a kernel with IPv6. On the kernel used for the
accompanying run, IPv6 was compiled out. Those tests were reported as
**skipped**, and only `test_ipv6_rules_loaded_even_without_ipv6_stack` (rules
loaded and verified) ran.
