# Performance evaluation

Raw data: `results/bench-controller.json`, `results/bench-dataplane.json`
(produced by `bench/controller_bench.py` and `bench/dataplane_bench.py`).
These are **single runs** on the machine below. They are indicative for that
environment only. Rerun on your target hardware before relying on any number.
No universal ranking or "best firewall" claim is made or supported.

| | Accompanying run |
|---|---|
| CPU | Intel Xeon @ 2.10 GHz, 2 vCPU (container in a shared VM) |
| Memory | 8 GiB |
| Kernel | 6.18.44 (IPv6 compiled out) |
| nftables | 1.0.9 |
| Python | 3.13.18 |
| Path | veth pairs over a Linux bridge, all in network namespaces, MTU 1500 |
| Traffic | iperf3 3.16 default TCP, 5 s; Python TCP request/response and connect loops |

## Controller (Python) — separate from packet processing

Synthetic policies: N non-overlapping IPv4 TCP accept rules + one 16-member set.

| Rules | validate (incl. conflict analysis) | compile | nft JSON | engine apply end-to-end | direct `nft -j -f` of same JSON | verify (read-back) |
|---:|---:|---:|---:|---:|---:|---:|
| 10 | 8.9 ms | 0.7 ms | 11 KB | 71 ms | 16 ms | 5.6 ms |
| 100 | 55 ms | 2.6 ms | 45 KB | 163 ms | 20 ms | 10.6 ms |
| 1000 | 664 ms | 38 ms | 380 KB | 1.30 s | 56 ms | 46 ms |
| 4000 | 2.13 s* | 104 ms | 1.5 MB | 4.68 s | 168 ms | 250 ms |

\* conflict analysis is skipped above 1500 rules per chain (with a warning).

**Regression versus the direct backend baseline (reported honestly):** an
end-to-end apply costs 4–28× a bare `nft -f` of the identical payload. The
gap is validation (including quadratic shadow analysis), compilation, dry-run,
read-back verification, the diff against the installed revision, and durable
(fsynced) state writes. The kernel transaction itself is the same.
Optimisation done during this work: conflict-analysis pre-filtering and
memoised compilation of unchanged policies. Before them, 1000-rule applies
took about 16 s.

Large sets:

| Set | Size | Time |
|---|---:|---:|
| static address set (policy) | 1,000 | apply 159 ms, verify 7 ms |
| static address set (policy) | 10,000 (policy list limit) | apply 668 ms, verify 9 ms |
| dynamic feed set (update + read-back verify) | 1,000 | 52 ms |
| dynamic feed set | 10,000 | 374 ms |
| dynamic feed set | 100,000 | 5.15 s |

Recovery (500-rule policy): rollback to LKG 72 ms; reinstall after table loss
98 ms. Both benefit from the compile cache, and both exclude the timer
resolution (default 1 s) that decides *when* a timed rollback starts.

Event processing: kernel-log parsing ~128k lines/s; bus publish ~141k
events/s; with the rate limiter shedding, ~2.4M publish attempts/s (drops
counted).

## Kernel packet processing (namespace laboratory)

Client `ok` → protected host over veth/bridge. "Fillers" are rules that never
match, evaluated before the application rule.

| Scenario | Input-chain rules | Throughput | RR latency median / p99 | New conns/s |
|---|---:|---:|---:|---:|
| no ruleset | 0 | 14.29 Gbit/s | 42 / 81 µs | 172 |
| LONDON CIPHER (lab policy) | 22 | 14.01 Gbit/s | 33 / 59 µs | 209 |
| hand-written idiomatic nft | 10 | 14.35 Gbit/s | 40 / 86 µs | 195 |
| no ruleset (repeat) | 0 | 15.56 Gbit/s | 36 / 63 µs | 172 |
| LONDON CIPHER + 1000 fillers | 1022 | 14.21 Gbit/s | 43 / 90 µs | 325 |
| hand-written + 1000 fillers (one set lookup) | 11 | 14.70 Gbit/s | 37 / 98 µs | 195 |

Interpretation and limitations:

* **Throughput and latency of established flows** do not depend on rule count
  here, because established packets are accepted by the fifth rule. The two
  no-ruleset runs differ by about 9 % (14.3 vs 15.6 Gbit/s), so differences
  between scenarios are within run-to-run noise in this environment.
* **The new-connection test does not resolve per-rule cost.** It is limited
  by the userspace Python client and the thread-per-connection probe server.
  Its spread (172–325/s) is noise, not a ranking. Measuring rule-walk cost
  needs a kernel packet generator (pktgen, trafgen) or a C client on
  dedicated cores. That was not available here.
* **Known structural regression:** the compiler emits one nftables rule per
  rule/family/protocol part. A hand-written ruleset can merge equivalent rules
  into one set or verdict-map lookup (11 rules versus 1022 above). For large
  policies that is an expected per-new-connection cost. Rule merging is the
  first optimisation to add, and it must preserve first-match semantics.
* CPU: iperf3 sender ~88–94 %, receiver ~30–33 % in every scenario
  (`results/bench-dataplane.json`). The test is sender-bound on 2 vCPUs.

## Reproducing

```bash
sudo python3 bench/controller_bench.py --out results/bench-controller.json
sudo python3 bench/dataplane_bench.py  --out results/bench-dataplane.json --fillers 0,1000 --seconds 5
```
