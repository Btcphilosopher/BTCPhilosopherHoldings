# DNS and dynamic destinations

`cipher_intel.dynamic_dns` resolves configured hostnames through **one
configured resolver** (own minimal A/AAAA stub client, so TTL and resolver are
known) and replaces the members of a `source: dns` dynamic set atomically.

Every refresh records: resolver (`ip:port`), resolution time, TTL (clamped to
`min_ttl..max_ttl`), the address set per hostname, status (`updated`,
`unchanged`, `failed-kept-previous`, `failed-emptied`, `failed-kept-stale`)
and errors.

## Atomicity

* A partial result is never published: if any hostname fails, the configured
  failure behaviour applies to the whole set.
* The set is replaced with one nftables transaction (`flush set` + `add
  element`), then read back and verified; on mismatch the previous members are
  restored.
* Members are persisted with provenance and re-installed inside the same
  atomic transaction as any later policy revision (lab-tested).

## Failure behaviour

Within `max_stale` seconds of the last success the previous members stay in
force. After that, `stale_action: empty` (default, fail closed: allow rules
that reference the set stop matching) or `keep` (fail open on old data).

## Limits (important)

* **Shared addresses.** CDNs and cloud front-ends serve many unrelated names
  from the same IPs. Allowing `updates.example.com` by address may also allow
  any other service on those addresses. This is **not domain-level control**.
* **Divergent resolution.** Applications may use other resolvers, cached
  answers or encrypted DNS (DoH/DoT/DoQ). LONDON CIPHER does not filter
  encrypted DNS, does not read TLS SNI and cannot see ECH-protected names.
  Blocking DoH by port is not reliable either, because DoH uses port 443.
* **Staleness** between DNS changes and the next refresh.
* The stub client does not validate DNSSEC; use a trusted (ideally local,
  validating) resolver.
