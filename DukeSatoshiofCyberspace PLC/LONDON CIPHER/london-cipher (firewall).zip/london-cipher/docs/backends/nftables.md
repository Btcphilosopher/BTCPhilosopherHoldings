# nftables backend

Interface: libnftables JSON (libnftables-json(5)), submitted as one batch on
stdin to `nft -j -f -` (dry-run: `nft -c -j -f -`). The JSON constructs used
(table/chain/set/rule objects; `match` with `==`, `!=`, `in`; `payload`,
`meta`, `ct`; `prefix`, `range`, anonymous `set`; `counter`, `limit`, `log`,
`reject` (`tcp reset` / `icmpx`), `masquerade`, `dnat`; sets with `interval`
or `timeout` flags and `size`; elements with `timeout`) were checked against
the manual page and exercised on nftables 1.0.9 / Linux 6.18 in the lab.

## Namespace

Only `table inet london_cipher` is created, replaced or deleted (unless
configured otherwise). Contents:

* sets `as_<name>_v4|v6` (static, `interval`) and `dyn_<name>` (dynamic, `size`,
  `timeout` for detection sets);
* base chains `input`, `output`, `forward` (filter, priority 0, explicit
  policy) and, when NAT is used, `nat_prerouting` (dstnat −100) and
  `nat_postrouting` (srcnat 100);
* a non-hooked chain `lc_meta` with one rule whose comment is
  `lc-meta;p=<policy>;r=<revision>;d=<digest prefix>`.

Every rule carries a comment `lc:<rule-id>[<part>]` (and `:log` for its log
twin). Verification compares the exact ordered comment sequence per chain.

## Capabilities

`json` (nft ≥ 0.9.3 with JSON support), `atomic_replace`, `named_sets`, `log`,
`timeout_sets`, `nat` (inet NAT, Linux ≥ 5.2), `conntrack_delete`
(conntrack-tools). A policy that needs a missing capability is refused before
any change.

## Coexistence

Base chains of other tables on the same hooks are evaluated independently:
a packet accepted here can still be dropped there. `plan`/`apply` report every
foreign base chain. Known managers (firewalld tables, ufw chains, Docker
chains) make `apply` refuse unless `--allow-conflicts` is passed (configurable
`conflict_policy`). LONDON CIPHER never modifies foreign tables.

## Fingerprint

SHA-256 of the normalised table listing (handles removed, counters zeroed,
dynamic-set members excluded). Recorded at each verified deployment; a
difference means external modification (`drifted`).
