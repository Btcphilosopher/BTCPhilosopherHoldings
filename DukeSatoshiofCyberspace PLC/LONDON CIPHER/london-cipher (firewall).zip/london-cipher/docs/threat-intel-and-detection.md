# Threat intelligence and detection integrations

Neither feeds nor detectors can write rules. Each can only propose new
*membership* for a dynamic set that the active policy declares, through the
bounded, audited `dynamic_set_update` operation (admin role). The policy
decides what membership means.

## Threat feeds (`cipher_intel.feeds`)

| Control | Implementation |
|---|---|
| Source authentication | HTTPS with certificate verification (plain HTTP refused); optional SHA-256 pin; optional HMAC-SHA256 signature with a key file |
| Format validation | plain or CSV; strict CIDR parsing; error budget (`max_invalid_ratio`) |
| Size limits | `max_bytes` before parsing, `max_entries` after collapsing |
| Unexpected expansion | rejected if entries exceed `max(min_growth_floor, active × max_growth_ratio)` |
| Allowlist exceptions | allowlisted space removed precisely (broader entries are split) |
| Expiry | stale versions are not activated; `expire_if_stale` empties the set |
| Provenance | source, fetch time, SHA-256, auth methods, version id, actor |
| Staged activation | `stage` never touches enforcement; `activate` is a separate step |
| Rollback | previous version re-activated; last 10 versions kept |

**Reputation is not attribution.** A listed address means "reported by feed
X at time T". It does not establish who controls the address or what they did.
Policies typically use feed sets for `drop`, with logging.

Tests use only local fixtures (`tests/fixtures/`).

## Detection (`cipher_detect`)

1. **Ingestion:** Suricata EVE JSON `alert` events (malformed or oversized
   lines ignored).
2. **Confidence:** the detector's own severity mapped to 0.9 / 0.6 / 0.3.
3. **Proposal:** "block source X for T seconds" (aggregates repeated alerts).
4. **Approved change:** operator approval, or, if and only if
   `AutoBlockPolicy.enabled`, automatic approval above `min_confidence`,
   within `max_active_blocks` and `max_new_blocks_per_hour`, never for
   allowlisted networks, always with expiry (60 s–7 d, also capped by the
   policy set's `timeout_seconds`, enforced by the kernel).

Default mode is **alert-only**. Every block can be revoked individually, all
blocks can be rolled back at once, and blocks expire in the kernel without
any controller action (lab-tested).

Basic packet filtering does not detect malware, intrusions or zero-day
exploits. Detection quality is entirely the upstream detector's.
