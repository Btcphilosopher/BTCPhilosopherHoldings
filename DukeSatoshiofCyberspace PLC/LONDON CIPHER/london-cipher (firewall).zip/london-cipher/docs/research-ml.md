# Research module: traffic anomaly analysis

`cipher_research` is optional and **advisory only**. It imports nothing from
the engine, backend or admin plane (enforced by a static test) and cannot
change policy, disable administrative access or block anything.

* **Features:** per source, per time window: events, drops, distinct
  destination ports, distinct destinations, drop ratio, all aggregated from
  firewall log events (header fields). No payload collection.
* **Baseline model:** one-sided robust z-score (median / MAD) per feature.
* **Time-separated validation:** train, validation and test slices split by
  window time with no overlap. The threshold is calibrated on validation to a
  target false-positive rate.
* **False-positive analysis:** confusion counts, FPR/TPR/precision, top false
  positives with their dominant feature.
* **Drift monitoring:** Population Stability Index per feature between
  training and recent data (stable < 0.1 ≤ moderate < 0.25 ≤ significant).
* **Provenance:** dataset SHA-256, row count, split boundaries, parameters,
  code version, Python version, creation time.
* **Reproducible:** deterministic synthetic generator (seeded). The same input
  gives the same metrics (tested).

```bash
cipher-research synthesize --out /tmp/events.jsonl --seed 7
cipher-research evaluate --events /tmp/events.jsonl --synthetic --report /tmp/report.json
```

Reports on synthetic data carry `"synthetic_data": true` and the warning:
*Synthetic benchmark results demonstrate the pipeline only; they are not
evidence of real-world protection.* A sample report from the accompanying run
is `results/research-synthetic-report.json`.
