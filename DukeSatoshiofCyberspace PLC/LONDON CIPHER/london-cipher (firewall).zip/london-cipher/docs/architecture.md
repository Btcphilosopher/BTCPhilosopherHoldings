# Architecture

## Principle

Python owns *decisions about policy*; the kernel owns *packets*. No packet is
ever handed to a Python userspace loop. Connection tracking is the kernel's
(`nf_conntrack`); there is no Python connection tracker that could disagree
with enforcement.

## Packages and dependency direction

```
cipher_types  <- cipher_policy <- cipher_compiler <- cipher_backend <- cipher_state <- cipher_admin <- cipher_cli
      ^                                                    ^               ^
      +---------------- cipher_events ---------------------+---------------+
optional:  cipher_intel, cipher_detect  -> (dynamic_set_update only)
           cipher_research              -> nothing in the enforcement path (statically tested)
```

* **cipher_types** — enums, naming rules (regexes bounding every identifier
  that reaches a backend), exception hierarchy, and the backend-neutral IR.
* **cipher_policy** — hardened loader (no aliases, tags, duplicate keys),
  strict validator producing an immutable typed model, static conflict
  analysis.
* **cipher_compiler** — deterministic lowering to IR; review listing; diff.
* **cipher_backend** — `EnforcementBackend` ABC; `NftablesBackend`;
  `MemoryBackend` test double; bounded `CommandRunner` (argv only, trusted
  PATH, timeouts, payloads on stdin).
* **cipher_state** — crash-safe store, journal, `Engine` implementing the
  safe-deployment pipeline.
* **cipher_events** — events, rate-limited bus with dropped counters,
  JSON-lines sinks with rotation/retention, hash-chained audit log, redaction,
  kernel-log parser.
* **cipher_admin** — Unix-socket servers, peer-credential authz, strict op
  schemas, admin daemon, privileged helper.
* **cipher_cli** — the `cipher` command.

## Adding a backend

Implement `cipher_backend.base.EnforcementBackend` against the IR contract in
`cipher_types/ir.py`: first-match chains, conjunctive matches, disjunctive
values within a match, non-terminal rate-limited logging, explicit chain
policies, atomic replace, read-back verification. Policy semantics must not
change; the compiler and validator are shared. `MemoryBackend` shows the
minimum surface; `tests/unit/test_engine.py` is the orchestration contract.

## Process model (production)

```
cipher (any user in cipher-users)
   │  /run/london-cipher/admin.sock  (0660, group cipher-users)
   ▼
cipher-admind  (user cipher, no capabilities, AF_UNIX only)
   │  authz by SO_PEERCRED + role groups, rate limit, audit
   │  /run/london-cipher/helper.sock (0660, group cipher)
   ▼
cipher-helper  (root with CapabilityBoundingSet=CAP_NET_ADMIN)
   re-validates + compiles, nft JSON transaction, verify, journal, timers
```

`london-cipher-restore.service` runs `cipher-helper recover` before
`network-pre.target` so the last-known-good policy is in force before
interfaces come up.
