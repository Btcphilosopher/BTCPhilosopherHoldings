"""Administration plane: local Unix-socket admin daemon and privileged helper.

Process model (docs/privilege-separation.md)::

    cipher (CLI, any user) --admin.sock--> cipher-admind (user 'cipher', no caps)
                                              | authz by SO_PEERCRED + roles, audit, rate limit
                                              v
                                   --helper.sock--> cipher-helper (CAP_NET_ADMIN only)
                                                       re-validates, compiles, applies, verifies
"""

from .authz import OP_ROLES, PeerCredentials, RoleMap
from .client import AdminClient, RemoteError

__all__ = ["AdminClient", "OP_ROLES", "PeerCredentials", "RemoteError", "RoleMap"]
