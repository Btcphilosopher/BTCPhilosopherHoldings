"""Bounded, threaded Unix-domain socket server shared by admind and the helper.

* Only ``AF_UNIX`` stream sockets are created; there is no network listener.
* The socket file is created with a restrictive umask, then chmod/chown'd.
* Concurrency is bounded by a semaphore; excess connections get an immediate
  ``busy`` error rather than queueing without limit.
* Each connection carries exactly one request and one response.
"""

from __future__ import annotations

import grp
import logging
import os
import socket
import stat
import threading
from typing import Any, Callable, Optional

from cipher_types import CipherError, ProtocolError

from .authz import PeerCredentials, peer_credentials
from .protocol import error_response, recv_msg, send_msg

log = logging.getLogger("london_cipher.server")

Handler = Callable[[PeerCredentials, dict[str, Any]], Any]


class UnixJsonServer:
    def __init__(
        self,
        path: str,
        handler: Handler,
        *,
        mode: int = 0o600,
        group: Optional[str] = None,
        max_concurrent: int = 8,
        timeout: float = 120.0,
    ):
        self.path = path
        self.handler = handler
        self.mode = mode
        self.group = group
        self.timeout = timeout
        self._sem = threading.BoundedSemaphore(max_concurrent)
        self._stop = threading.Event()
        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None

    def bind(self) -> None:
        d = os.path.dirname(os.path.abspath(self.path))
        os.makedirs(d, mode=0o755, exist_ok=True)
        if os.path.exists(self.path):
            st = os.lstat(self.path)
            if not stat.S_ISSOCK(st.st_mode):
                raise RuntimeError(f"{self.path} exists and is not a socket; refusing to replace it")
            os.unlink(self.path)
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        old = os.umask(0o177)
        try:
            s.bind(self.path)
        finally:
            os.umask(old)
        if self.group:
            os.chown(self.path, -1, grp.getgrnam(self.group).gr_gid)
        os.chmod(self.path, self.mode)
        s.listen(64)
        s.settimeout(0.5)
        self._sock = s

    def _serve_conn(self, conn: socket.socket) -> None:
        try:
            conn.settimeout(self.timeout)
            creds = peer_credentials(conn)
            try:
                req = recv_msg(conn)
                if not isinstance(req, dict) or not isinstance(req.get("op"), str):
                    raise ProtocolError("request must be an object with an 'op' string")
                args = req.get("args", {})
                if not isinstance(args, dict):
                    raise ProtocolError("'args' must be an object")
                result = self.handler(creds, {"op": req["op"], "args": args, "request_id": str(req.get("request_id", ""))[:64]})
                resp = {"ok": True, "result": result}
            except CipherError as exc:
                resp = error_response(exc.code, str(exc))
            except Exception as exc:  # noqa: BLE001 - never leak tracebacks to clients
                log.exception("internal error handling request")
                resp = error_response("internal", f"internal error: {type(exc).__name__}")
            send_msg(conn, resp)
        except (OSError, ProtocolError) as exc:
            log.debug("connection error: %s", exc)
        finally:
            conn.close()
            self._sem.release()

    def serve_forever(self) -> None:
        if self._sock is None:
            self.bind()
        assert self._sock is not None
        while not self._stop.is_set():
            try:
                conn, _ = self._sock.accept()
            except socket.timeout:
                continue
            except OSError:
                if self._stop.is_set():
                    break
                raise
            if not self._sem.acquire(blocking=False):
                try:
                    conn.settimeout(2)
                    send_msg(conn, error_response("busy", "too many concurrent administrative requests"))
                except OSError:
                    pass
                conn.close()
                continue
            threading.Thread(target=self._serve_conn, args=(conn,), daemon=True).start()

    def start(self) -> None:
        self.bind()
        self._thread = threading.Thread(target=self.serve_forever, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._sock is not None:
            self._sock.close()
        if self._thread is not None:
            self._thread.join(timeout=5)
        try:
            os.unlink(self.path)
        except FileNotFoundError:
            pass
