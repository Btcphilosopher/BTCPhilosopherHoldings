"""Client for the local admin / helper sockets."""

from __future__ import annotations

import socket
import uuid
from typing import Any

from cipher_types import CipherError, ProtocolError

from .protocol import recv_msg, send_msg


class RemoteError(CipherError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


class AdminClient:
    def __init__(self, path: str, timeout: float = 120.0):
        self.path = path
        self.timeout = timeout

    def call(self, op: str, **args: Any) -> Any:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(self.timeout)
        try:
            try:
                s.connect(self.path)
            except OSError as exc:
                raise ProtocolError(f"cannot connect to {self.path}: {exc}") from None
            send_msg(s, {"op": op, "args": args, "request_id": uuid.uuid4().hex})
            resp = recv_msg(s)
        finally:
            s.close()
        if not isinstance(resp, dict):
            raise ProtocolError("malformed response")
        if resp.get("ok"):
            return resp.get("result")
        err = resp.get("error") or {}
        raise RemoteError(str(err.get("code", "error")), str(err.get("message", "unknown error")))
