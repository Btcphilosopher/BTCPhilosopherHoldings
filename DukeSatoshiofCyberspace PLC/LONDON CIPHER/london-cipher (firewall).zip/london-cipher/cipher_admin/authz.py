"""Operating-system identity and role-based authorisation for local admin.

Identity comes from the kernel (``SO_PEERCRED`` on the Unix socket), never
from anything the client sends. Roles are ordered ``viewer < operator <
admin``; each operation requires a minimum role.

Role configuration (``/etc/london-cipher/admin.yaml``)::

    roles:
      viewer:   {users: [], groups: [cipher-view]}
      operator: {users: [], groups: [cipher-ops]}
      admin:    {users: [root], groups: [cipher-admin]}

uid 0 is always ``admin`` (root can bypass any local control anyway).
"""

from __future__ import annotations

import grp
import os
import pwd
import socket
import struct
from dataclasses import dataclass, field
from typing import Any, Optional

from cipher_types import AuthorizationError

ROLE_ORDER = {"viewer": 1, "operator": 2, "admin": 3}

OP_ROLES = {
    "ping": "viewer",
    "status": "viewer",
    "plan": "viewer",
    "history": "viewer",
    "apply": "operator",
    "confirm": "operator",
    "rollback": "operator",
    "repair": "admin",
    "dynamic_set_update": "admin",
    "conntrack_delete": "admin",
    "remove": "admin",
}


@dataclass(frozen=True)
class PeerCredentials:
    pid: int
    uid: int
    gid: int

    @property
    def username(self) -> str:
        try:
            return pwd.getpwuid(self.uid).pw_name
        except KeyError:
            return str(self.uid)

    @property
    def actor(self) -> str:
        return f"uid:{self.uid}({self.username})"


def peer_credentials(sock: socket.socket) -> PeerCredentials:
    raw = sock.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize("3i"))
    pid, uid, gid = struct.unpack("3i", raw)
    return PeerCredentials(pid, uid, gid)


def _user_groups(uid: int, gid: int) -> set[int]:
    gids = {gid}
    try:
        name = pwd.getpwuid(uid).pw_name
        gids.update(os.getgrouplist(name, gid))
    except KeyError:
        pass
    return gids


@dataclass
class RoleMap:
    uids: dict[str, set[int]] = field(default_factory=lambda: {r: set() for r in ROLE_ORDER})
    gids: dict[str, set[int]] = field(default_factory=lambda: {r: set() for r in ROLE_ORDER})

    @classmethod
    def from_config(cls, cfg: Optional[dict[str, Any]]) -> "RoleMap":
        rm = cls()
        roles = (cfg or {}).get("roles", {})
        if not isinstance(roles, dict):
            raise ValueError("roles must be a mapping")
        for role, spec in roles.items():
            if role not in ROLE_ORDER:
                raise ValueError(f"unknown role {role!r}")
            for u in (spec or {}).get("users", []):
                rm.uids[role].add(u if isinstance(u, int) else pwd.getpwnam(u).pw_uid)
            for g in (spec or {}).get("groups", []):
                try:
                    rm.gids[role].add(g if isinstance(g, int) else grp.getgrnam(g).gr_gid)
                except KeyError:
                    continue  # group not present on this host: grants nothing
        return rm

    def role_of(self, creds: PeerCredentials) -> Optional[str]:
        if creds.uid == 0:
            return "admin"
        groups = _user_groups(creds.uid, creds.gid)
        best: Optional[str] = None
        for role in ROLE_ORDER:
            if creds.uid in self.uids[role] or groups & self.gids[role]:
                if best is None or ROLE_ORDER[role] > ROLE_ORDER[best]:
                    best = role
        return best

    def authorize(self, creds: PeerCredentials, op: str) -> str:
        need = OP_ROLES.get(op)
        if need is None:
            raise AuthorizationError(f"unknown operation {op!r}")
        role = self.role_of(creds)
        if role is None or ROLE_ORDER[role] < ROLE_ORDER[need]:
            raise AuthorizationError(f"{creds.actor} (role {role or 'none'}) may not perform {op!r}; requires {need}")
        return role
