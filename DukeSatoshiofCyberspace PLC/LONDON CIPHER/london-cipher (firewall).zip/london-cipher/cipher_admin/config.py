"""Daemon configuration (strictly validated, no expressions)."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Optional

from cipher_policy.loader import load_policy_text

DEFAULT_STATE_DIR = "/var/lib/london-cipher"
DEFAULT_RUN_DIR = "/run/london-cipher"
DEFAULT_LOG_DIR = "/var/log/london-cipher"


def _load(path: Optional[str]) -> dict[str, Any]:
    if not path:
        return {}
    with open(path, "rb") as fh:
        return load_policy_text(fh.read())


def _check_keys(d: dict, allowed: set[str], what: str) -> None:
    extra = set(d) - allowed
    if extra:
        raise ValueError(f"unknown {what} configuration keys: {', '.join(sorted(extra))}")


@dataclass
class HelperConfig:
    state_dir: str = DEFAULT_STATE_DIR
    socket: str = f"{DEFAULT_RUN_DIR}/helper.sock"
    #: Leave None under systemd: the socket inherits the service's primary
    #: group (Group=cipher), so no CAP_CHOWN is needed.
    socket_group: Optional[str] = None
    socket_mode: int = 0o600
    audit_log: str = f"{DEFAULT_LOG_DIR}/audit.jsonl"
    event_log: str = f"{DEFAULT_LOG_DIR}/events.jsonl"
    allowed_uids: list[int] = field(default_factory=lambda: [0])
    delegate_uids: list[int] = field(default_factory=list)  # admind service user(s)
    tick_interval: float = 1.0
    conflict_policy: str = "refuse-managers"
    netns: Optional[str] = None
    redaction: str = "none"
    redaction_key_file: Optional[str] = None

    @classmethod
    def load(cls, path: Optional[str], **overrides: Any) -> "HelperConfig":
        d = _load(path)
        _check_keys(d, set(cls.__dataclass_fields__), "helper")
        d.update({k: v for k, v in overrides.items() if v is not None})
        cfg = cls(**d)
        if cfg.tick_interval <= 0 or cfg.tick_interval > 60:
            raise ValueError("tick_interval must be in (0, 60]")
        if cfg.socket_mode & 0o007:
            raise ValueError("helper socket must not be accessible to 'other' users")
        if cfg.conflict_policy not in ("refuse-managers", "warn"):
            raise ValueError("conflict_policy must be refuse-managers or warn")
        if not os.path.isabs(cfg.state_dir) or not os.path.isabs(cfg.socket):
            raise ValueError("state_dir and socket must be absolute paths")
        return cfg


@dataclass
class AdminConfig:
    socket: str = f"{DEFAULT_RUN_DIR}/admin.sock"
    socket_group: Optional[str] = None  # inherit the service group (cipher-users)
    socket_mode: int = 0o660
    helper_socket: str = f"{DEFAULT_RUN_DIR}/helper.sock"
    audit_log: str = f"{DEFAULT_LOG_DIR}/admin-audit.jsonl"
    roles: dict[str, Any] = field(default_factory=dict)
    requests_per_minute: int = 60
    burst: int = 20
    max_concurrent: int = 8

    @classmethod
    def load(cls, path: Optional[str], **overrides: Any) -> "AdminConfig":
        d = _load(path)
        _check_keys(d, set(cls.__dataclass_fields__), "admin")
        d.update({k: v for k, v in overrides.items() if v is not None})
        cfg = cls(**d)
        if not (1 <= cfg.requests_per_minute <= 6000):
            raise ValueError("requests_per_minute out of range")
        if cfg.socket_mode & 0o007:
            raise ValueError("admin socket must not be accessible to 'other' users")
        return cfg
