"""Strict argument schemas for administrative operations.

Every operation's arguments are checked for exact keys, types and bounds
before they reach the engine. Unknown keys are rejected.
"""

from __future__ import annotations

import json
import re
from typing import Any

from cipher_policy import MAX_POLICY_BYTES
from cipher_types import ProtocolError

ACTOR_RE = re.compile(r"^(uid:\d{1,10}\([A-Za-z0-9._-]{0,64}\)|system:[a-z-]{1,32})$")
NAME_RE = re.compile(r"^[a-z][a-z0-9_]{0,39}$")
_TEXT_MAX = 500

# (type, required, extra-check)
_SPECS: dict[str, dict[str, tuple[type | tuple[type, ...], bool]]] = {
    "ping": {},
    "status": {},
    "history": {},
    "plan": {"policy_text": (str, True), "allow_conflicts": (bool, False)},
    "apply": {"policy_text": (str, True), "confirm_timeout": ((int, type(None)), False), "allow_conflicts": (bool, False)},
    "confirm": {},
    "rollback": {"reason": (str, False)},
    "repair": {},
    "remove": {},
    "dynamic_set_update": {
        "name": (str, True),
        "values": (list, True),
        "source": (str, True),
        "provenance": (dict, True),
        "ttl_seconds": ((int, type(None)), False),
        "element_ttls": ((list, type(None)), False),
    },
    "conntrack_delete": {
        "family": (str, True),
        "source": ((str, type(None)), False),
        "destination": ((str, type(None)), False),
        "protocol": ((str, type(None)), False),
        "dport": ((int, type(None)), False),
        "reason": (str, True),
    },
}


def validate_args(op: str, args: dict[str, Any]) -> dict[str, Any]:
    spec = _SPECS.get(op)
    if spec is None:
        raise ProtocolError(f"unknown operation {op!r}")
    allowed = set(spec) | {"actor"}
    extra = set(args) - allowed
    if extra:
        raise ProtocolError(f"unexpected argument(s) for {op}: {', '.join(sorted(extra))}")
    for key, (typ, required) in spec.items():
        if key not in args:
            if required:
                raise ProtocolError(f"missing argument {key!r} for {op}")
            continue
        val = args[key]
        if isinstance(val, bool) and typ is not bool and (typ == int or (isinstance(typ, tuple) and int in typ)):
            raise ProtocolError(f"argument {key!r} must be an integer")
        if not isinstance(val, typ):
            raise ProtocolError(f"argument {key!r} has wrong type")
    if "policy_text" in args and len(args["policy_text"].encode("utf-8")) > MAX_POLICY_BYTES:
        raise ProtocolError("policy_text too large")
    for key in ("reason",):
        if key in args and len(args[key]) > _TEXT_MAX:
            raise ProtocolError(f"{key} longer than {_TEXT_MAX} characters")
    if op == "dynamic_set_update":
        if not NAME_RE.match(args["name"]):
            raise ProtocolError("invalid set name")
        if args["source"] not in ("dns", "feed", "detection"):
            raise ProtocolError("invalid source")
        if len(args["values"]) > 262_144 or not all(isinstance(v, str) and len(v) <= 64 for v in args["values"]):
            raise ProtocolError("values must be at most 262144 address strings")
        ttls = args.get("element_ttls")
        if ttls is not None and (len(ttls) != len(args["values"]) or not all(isinstance(t, int) and not isinstance(t, bool) and 0 < t <= 30 * 86400 for t in ttls)):
            raise ProtocolError("element_ttls must be positive integers parallel to values")
        if len(json.dumps(args["provenance"])) > 16_384:
            raise ProtocolError("provenance too large")
    if op == "conntrack_delete":
        if args["family"] not in ("ipv4", "ipv6"):
            raise ProtocolError("family must be ipv4 or ipv6")
        if args.get("protocol") not in (None, "tcp", "udp"):
            raise ProtocolError("protocol must be tcp or udp")
        if args.get("dport") is not None and not (1 <= args["dport"] <= 65535):
            raise ProtocolError("dport out of range")
    if "actor" in args and (not isinstance(args["actor"], str) or not ACTOR_RE.match(args["actor"])):
        raise ProtocolError("invalid actor")
    return args
