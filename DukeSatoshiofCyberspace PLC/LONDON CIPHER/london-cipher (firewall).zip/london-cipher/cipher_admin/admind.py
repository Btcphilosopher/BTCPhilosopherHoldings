"""Unprivileged administration daemon (``cipher-admind``).

Runs as the ``cipher`` service user with no capabilities. It authenticates
local callers by kernel peer credentials, authorises each operation by role,
rate-limits callers, audits every request (allowed or denied) and forwards
permitted requests to the privileged helper, passing the caller identity as
``actor``. The helper trusts that ``actor`` only because this daemon's uid is
configured as a delegate.

There is deliberately no network listener. Remote administration, if ever
added, must be a separate, explicitly configured component using
authenticated encryption and the same role model (docs/privilege-separation.md).
"""

from __future__ import annotations

import argparse
import logging
import signal
import sys
import threading
from typing import Any, Optional

from cipher_events import AuditLog, TokenBucket
from cipher_types import AuthorizationError, LimitExceeded

from .authz import PeerCredentials, RoleMap
from .client import AdminClient
from .config import AdminConfig
from .schema import validate_args
from .server import UnixJsonServer

log = logging.getLogger("london_cipher.admind")


class AdminDaemon:
    def __init__(self, cfg: AdminConfig, roles: Optional[RoleMap] = None, helper: Optional[AdminClient] = None):
        self.cfg = cfg
        self.roles = roles or RoleMap.from_config({"roles": cfg.roles})
        self.helper = helper or AdminClient(cfg.helper_socket)
        self.audit = AuditLog(cfg.audit_log)
        self._buckets: dict[int, TokenBucket] = {}
        self._lock = threading.Lock()
        self.server = UnixJsonServer(cfg.socket, self.handle, mode=cfg.socket_mode, group=cfg.socket_group, max_concurrent=cfg.max_concurrent)

    def _rate_ok(self, uid: int) -> bool:
        with self._lock:
            b = self._buckets.get(uid)
            if b is None:
                if len(self._buckets) > 10_000:
                    self._buckets.clear()
                b = self._buckets[uid] = TokenBucket(self.cfg.requests_per_minute / 60.0, self.cfg.burst)
            return b.allow()

    def handle(self, creds: PeerCredentials, req: dict[str, Any]) -> Any:
        op, args = req["op"], dict(req["args"])
        if not self._rate_ok(creds.uid):
            self.audit.record("admin_request", actor=creds.actor, outcome="rate-limited", op=op)
            raise LimitExceeded("administrative request rate exceeded; retry later")
        try:
            role = self.roles.authorize(creds, op)
            if "actor" in args:
                raise AuthorizationError("clients may not assert an actor; identity comes from the socket")
            validate_args(op, args)
        except Exception as exc:
            self.audit.record("admin_request", actor=creds.actor, outcome="denied", op=op, error=str(exc))
            raise
        self.audit.record("admin_request", actor=creds.actor, outcome="allowed", op=op, role=role, request_id=req.get("request_id"))
        try:
            result = self.helper.call(op, actor=creds.actor, **args)
        except Exception as exc:
            self.audit.record("admin_result", actor=creds.actor, outcome="error", op=op, error=str(exc)[:1000])
            raise
        self.audit.record("admin_result", actor=creds.actor, outcome="ok", op=op)
        return result

    def run(self) -> None:
        self.server.serve_forever()

    def stop(self, *_: Any) -> None:
        self.server._stop.set()


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="cipher-admind", description="LONDON CIPHER local administration daemon")
    ap.add_argument("--config")
    ap.add_argument("--socket")
    ap.add_argument("--helper-socket")
    ap.add_argument("--audit-log")
    ap.add_argument("--socket-group")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO)
    cfg = AdminConfig.load(a.config, socket=a.socket, helper_socket=a.helper_socket, audit_log=a.audit_log, socket_group=a.socket_group)
    d = AdminDaemon(cfg)
    signal.signal(signal.SIGTERM, d.stop)
    signal.signal(signal.SIGINT, d.stop)
    d.run()
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
