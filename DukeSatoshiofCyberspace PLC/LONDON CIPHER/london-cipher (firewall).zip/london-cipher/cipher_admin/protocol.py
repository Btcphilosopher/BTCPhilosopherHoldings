"""Length-prefixed JSON framing for local Unix-domain sockets.

Frame: 4-byte big-endian unsigned length, then UTF-8 JSON. Requests and
responses are bounded (:data:`MAX_FRAME`) and every socket operation has a
timeout, so a slow or malicious local peer cannot pin memory or threads.

Request::   {"op": "<name>", "args": {...}, "request_id": "<opaque>"}
Response::  {"ok": true, "result": ...} | {"ok": false, "error": {"code", "message"}}
"""

from __future__ import annotations

import json
import socket
import struct
from typing import Any

from cipher_types import ProtocolError

MAX_FRAME = 5 * 1024 * 1024
_HDR = struct.Struct(">I")


def _recv_exact(sock: socket.socket, n: int) -> bytes:
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(min(65536, n - len(buf)))
        if not chunk:
            raise ProtocolError("connection closed mid-frame")
        buf.extend(chunk)
    return bytes(buf)


def send_msg(sock: socket.socket, obj: Any) -> None:
    data = json.dumps(obj, separators=(",", ":")).encode("utf-8")
    if len(data) > MAX_FRAME:
        raise ProtocolError(f"message of {len(data)} bytes exceeds {MAX_FRAME}")
    sock.sendall(_HDR.pack(len(data)) + data)


def recv_msg(sock: socket.socket, max_bytes: int = MAX_FRAME) -> Any:
    (n,) = _HDR.unpack(_recv_exact(sock, _HDR.size))
    if n > max_bytes:
        raise ProtocolError(f"frame of {n} bytes exceeds limit {max_bytes}")
    try:
        return json.loads(_recv_exact(sock, n).decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise ProtocolError(f"malformed frame: {exc}") from None


def error_response(code: str, message: str) -> dict[str, Any]:
    return {"ok": False, "error": {"code": code, "message": message}}
