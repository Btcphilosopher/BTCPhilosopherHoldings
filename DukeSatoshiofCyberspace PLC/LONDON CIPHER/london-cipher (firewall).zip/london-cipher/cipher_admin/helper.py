"""Privileged enforcement helper (``cipher-helper``).

The only LONDON CIPHER component that needs ``CAP_NET_ADMIN``. It:

* accepts connections only from configured uids (root and the admin daemon's
  service user), identified by ``SO_PEERCRED``;
* offers a *closed* set of operations with strict argument schemas — it never
  accepts backend commands, shell fragments or file paths from clients;
* re-validates and re-compiles every policy itself (it does not trust a
  compilation done by an unprivileged process);
* runs the timer that enforces confirmation deadlines and rule expiry;
* performs startup recovery before accepting requests.

Run under systemd with ``CapabilityBoundingSet=CAP_NET_ADMIN`` (see
packaging/systemd/london-cipher-helper.service).
"""

from __future__ import annotations

import argparse
import json
import logging
import signal
import sys
import threading
from typing import Any, Optional

from cipher_backend import CommandRunner, ConntrackFilter, NftablesBackend, netns_prefix
from cipher_events import AuditLog, EventBus, JsonlSink, Redactor
from cipher_state import Engine, StateStore
from cipher_types import AuthorizationError

from .authz import PeerCredentials
from .config import HelperConfig
from .schema import validate_args
from .server import UnixJsonServer

log = logging.getLogger("london_cipher.helper")


class Helper:
    def __init__(self, engine: Engine, cfg: HelperConfig):
        self.engine = engine
        self.cfg = cfg
        self._stop = threading.Event()
        self.server = UnixJsonServer(cfg.socket, self.handle, mode=cfg.socket_mode, group=cfg.socket_group)
        self.timer_errors = 0
        self.last_recovery: Optional[dict[str, Any]] = None

    # -- request handling --------------------------------------------------------
    def _actor(self, creds: PeerCredentials, args: dict[str, Any]) -> str:
        if creds.uid not in self.cfg.allowed_uids and creds.uid not in self.cfg.delegate_uids:
            raise AuthorizationError(f"{creds.actor} is not permitted to use the privileged helper")
        if creds.uid in self.cfg.delegate_uids and "actor" in args:
            return f"{args['actor']} via {creds.actor}"
        return creds.actor

    def handle(self, creds: PeerCredentials, req: dict[str, Any]) -> Any:
        op = req["op"]
        args = dict(req["args"])
        try:
            actor = self._actor(creds, args)
        except AuthorizationError:
            if self.engine.audit:
                self.engine.audit.record("helper_request", actor=creds.actor, outcome="denied", op=op)
            raise
        validate_args(op, args)
        args.pop("actor", None)
        e = self.engine
        if op == "ping":
            return {"pong": True}
        if op == "status":
            st = e.status()
            st["last_recovery"] = self.last_recovery
            st["timer_errors"] = self.timer_errors
            return st
        if op == "history":
            return [r.to_dict() for r in e.store.history()]
        if op == "plan":
            return e.plan(args["policy_text"], allow_conflicts=args.get("allow_conflicts", False)).to_dict()
        if op == "apply":
            return e.apply(args["policy_text"], actor=actor, confirm_timeout=args.get("confirm_timeout"), allow_conflicts=args.get("allow_conflicts", False))
        if op == "confirm":
            return e.confirm(actor=actor)
        if op == "rollback":
            return e.rollback(actor=actor, reason=args.get("reason", "operator request"))
        if op == "repair":
            return e.repair(actor=actor)
        if op == "remove":
            return e.remove(actor=actor)
        if op == "dynamic_set_update":
            return e.update_dynamic_set(args["name"], args["values"], source=args["source"], actor=actor, provenance=args["provenance"], ttl_seconds=args.get("ttl_seconds"), element_ttls=args.get("element_ttls"))
        if op == "conntrack_delete":
            flt = ConntrackFilter(args["family"], args.get("source"), args.get("destination"), args.get("protocol"), args.get("dport"))
            return e.conntrack_delete(flt, actor=actor, reason=args["reason"])
        raise AuthorizationError(f"operation {op!r} is not offered by the helper")

    # -- timer -----------------------------------------------------------------------
    def _timer(self) -> None:
        while not self._stop.wait(self.cfg.tick_interval):
            try:
                result = self.engine.tick()
                if result:
                    log.warning("timer: %s", json.dumps(result))
            except Exception:  # noqa: BLE001 - keep the timer alive; failures are audited
                self.timer_errors += 1
                log.exception("timer tick failed")
            self.engine.bus.drain()

    def recover(self) -> dict[str, Any]:
        try:
            self.last_recovery = self.engine.recover()
        except Exception as exc:  # noqa: BLE001 - serve anyway so status is inspectable
            log.exception("startup recovery failed")
            self.last_recovery = {"action": "failed", "error": str(exc)}
        log.info("recovery: %s", json.dumps(self.last_recovery))
        return self.last_recovery

    def run(self) -> None:
        self.recover()
        self.server.bind()
        t = threading.Thread(target=self._timer, daemon=True)
        t.start()
        try:
            self.server.serve_forever()
        finally:
            self._stop.set()
            self.server.stop()

    def stop(self, *_: Any) -> None:
        self._stop.set()
        self.server._stop.set()


def build_engine(cfg: HelperConfig) -> Engine:
    prefix = netns_prefix(cfg.netns) if cfg.netns else ()
    backend = NftablesBackend(CommandRunner(prefix))
    redactor = Redactor.from_key_file(cfg.redaction, cfg.redaction_key_file)
    bus = EventBus(redactor=redactor, sinks=[JsonlSink(cfg.event_log).write])
    return Engine(backend, StateStore(cfg.state_dir), audit=AuditLog(cfg.audit_log), bus=bus, conflict_policy=cfg.conflict_policy)


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="cipher-helper", description="LONDON CIPHER privileged enforcement helper")
    ap.add_argument("command", choices=["serve", "recover", "status"])
    ap.add_argument("--config")
    ap.add_argument("--state-dir")
    ap.add_argument("--socket")
    ap.add_argument("--socket-group")
    ap.add_argument("--audit-log")
    ap.add_argument("--event-log")
    ap.add_argument("--netns", help="manage the ruleset of this network namespace (laboratory)")
    ap.add_argument("--allowed-uid", type=int, action="append", dest="allowed_uids")
    ap.add_argument("--delegate-uid", type=int, action="append", dest="delegate_uids")
    ap.add_argument("--tick", type=float, dest="tick_interval")
    ap.add_argument("--conflict-policy", choices=["refuse-managers", "warn"])
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    cfg = HelperConfig.load(
        a.config,
        state_dir=a.state_dir,
        socket=a.socket,
        socket_group=a.socket_group,
        audit_log=a.audit_log,
        event_log=a.event_log,
        netns=a.netns,
        allowed_uids=a.allowed_uids,
        delegate_uids=a.delegate_uids,
        tick_interval=a.tick_interval,
        conflict_policy=a.conflict_policy,
    )
    engine = build_engine(cfg)
    if a.command == "recover":
        print(json.dumps(engine.recover(), indent=1))
        return 0
    if a.command == "status":
        print(json.dumps(engine.status(), indent=1, default=str))
        return 0
    helper = Helper(engine, cfg)
    signal.signal(signal.SIGTERM, helper.stop)
    signal.signal(signal.SIGINT, helper.stop)
    helper.run()
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
