import Database from 'better-sqlite3';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

export const DATA_DIR = path.resolve(process.cwd(), 'data');
export const BACKUP_DIR = path.resolve(DATA_DIR, 'backups');
export const DB_PATH = path.resolve(DATA_DIR, 'sterling_ledger.db');

let dbInstance: Database.Database | null = null;

export function getDb(): Database.Database {
  if (!dbInstance) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    dbInstance = openAndMigrateDb(DB_PATH);
  }
  return dbInstance;
}

export function resetDbConnection(): Database.Database {
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
  }
  return getDb();
}

export function openAndMigrateDb(filePath: string): Database.Database {
  const db = new Database(filePath);
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = FULL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    CREATE TABLE IF NOT EXISTS ledger_accounts (
      id TEXT PRIMARY KEY,
      account_code TEXT NOT NULL UNIQUE,
      account_class TEXT NOT NULL CHECK (account_class IN (
        'ISSUED_SUPPLY','REDEEMED_UNITS','SETTLEMENT_CONTROL','PENDING_CONVERSION',
        'RESERVED_ESCROW','REDEMPTION_ESCROW','FEE_CONTROL','WALLET_CUSTOMER','WALLET_MERCHANT'
      )),
      normal_side TEXT NOT NULL CHECK (normal_side IN ('DEBIT','CREDIT')),
      pip_id TEXT,
      available_pence INTEGER NOT NULL DEFAULT 0 CHECK (available_pence >= 0),
      reserved_pence INTEGER NOT NULL DEFAULT 0 CHECK (reserved_pence >= 0),
      status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','FROZEN','RECOVERY_LOCKED')),
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS journal_entries (
      id TEXT PRIMARY KEY,
      tx_type TEXT NOT NULL,
      reference TEXT NOT NULL,
      idempotency_key TEXT UNIQUE,
      reversal_of_entry_id TEXT REFERENCES journal_entries(id),
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS journal_postings (
      id TEXT PRIMARY KEY,
      entry_id TEXT NOT NULL REFERENCES journal_entries(id),
      account_id TEXT NOT NULL REFERENCES ledger_accounts(id),
      direction TEXT NOT NULL CHECK (direction IN ('DEBIT','CREDIT')),
      amount_pence INTEGER NOT NULL CHECK (amount_pence > 0)
    );

    CREATE INDEX IF NOT EXISTS idx_postings_entry ON journal_postings(entry_id);
    CREATE INDEX IF NOT EXISTS idx_postings_account ON journal_postings(account_id);

    CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY,
      state TEXT NOT NULL CHECK (state IN ('DRAFT','REVIEWED','AUTHORISED','SUBMITTED','FINALISED','REJECTED','REVERSED')),
      payment_kind TEXT NOT NULL CHECK (payment_kind IN ('P2P','MERCHANT','SCHEDULED')),
      payer_wallet_id TEXT NOT NULL REFERENCES ledger_accounts(id),
      payee_wallet_id TEXT NOT NULL REFERENCES ledger_accounts(id),
      payer_pip_id TEXT NOT NULL,
      payee_pip_id TEXT NOT NULL,
      amount_pence INTEGER NOT NULL CHECK (amount_pence > 0),
      fee_pence INTEGER NOT NULL DEFAULT 0 CHECK (fee_pence >= 0),
      currency TEXT NOT NULL DEFAULT 'GBP' CHECK (currency = 'GBP'),
      payment_reference TEXT NOT NULL,
      payment_request_id TEXT,
      idempotency_key TEXT NOT NULL UNIQUE,
      authorisation_hash TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      scheduled_for TEXT,
      reservation_entry_id TEXT REFERENCES journal_entries(id),
      final_entry_id TEXT REFERENCES journal_entries(id),
      rejection_reason TEXT,
      refunded_pence INTEGER NOT NULL DEFAULT 0 CHECK (refunded_pence >= 0),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS payment_requests (
      id TEXT PRIMARY KEY,
      merchant_wallet_id TEXT NOT NULL REFERENCES ledger_accounts(id),
      merchant_name TEXT NOT NULL,
      merchant_category TEXT NOT NULL,
      amount_pence INTEGER NOT NULL CHECK (amount_pence > 0),
      currency TEXT NOT NULL DEFAULT 'GBP' CHECK (currency = 'GBP'),
      reference TEXT NOT NULL,
      single_use INTEGER NOT NULL DEFAULT 1,
      status TEXT NOT NULL CHECK (status IN ('ACTIVE','USED','EXPIRED','CANCELLED')),
      signature_hmac TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      paid_payment_id TEXT REFERENCES payments(id),
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS issuance_redemption_requests (
      id TEXT PRIMARY KEY,
      kind TEXT NOT NULL CHECK (kind IN ('ISSUANCE','REDEMPTION')),
      state TEXT NOT NULL CHECK (state IN (
        'REQUESTED','VALIDATED','APPROVED','SETTLEMENT_EVIDENCE_VERIFIED',
        'POSTED','RECONCILED','FAILED_PAYOUT_REVERSED','REJECTED'
      )),
      amount_pence INTEGER NOT NULL CHECK (amount_pence > 0),
      currency TEXT NOT NULL DEFAULT 'GBP' CHECK (currency = 'GBP'),
      requested_by TEXT NOT NULL,
      validated_by TEXT,
      approver1_id TEXT,
      approver2_id TEXT,
      settlement_evidence_ref TEXT UNIQUE,
      external_payout_ref TEXT UNIQUE,
      journal_entry_id TEXT REFERENCES journal_entries(id),
      reversal_entry_id TEXT REFERENCES journal_entries(id),
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS conversion_requests (
      id TEXT PRIMARY KEY,
      direction TEXT NOT NULL CHECK (direction IN ('DEPOSIT_TO_CBDC','CBDC_TO_DEPOSIT')),
      stage TEXT NOT NULL CHECK (stage IN (
        'REQUESTED','EXTERNAL_SETTLEMENT_VERIFIED','CORE_POSTED',
        'CUSTOMER_NOTIFIED','RECONCILED','FAILED_REVERSED'
      )),
      wallet_id TEXT NOT NULL REFERENCES ledger_accounts(id),
      pip_id TEXT NOT NULL,
      bank_account_mask TEXT NOT NULL,
      bank_sort_code TEXT NOT NULL,
      amount_pence INTEGER NOT NULL CHECK (amount_pence > 0),
      external_settlement_ref TEXT UNIQUE,
      journal_entry_id TEXT REFERENCES journal_entries(id),
      idempotency_key TEXT NOT NULL UNIQUE,
      failure_reason TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS policy_versions (
      version INTEGER PRIMARY KEY,
      effective_at TEXT NOT NULL,
      label TEXT NOT NULL,
      holding_limit_pence INTEGER,
      tx_limit_pence INTEGER,
      remuneration_enabled INTEGER NOT NULL DEFAULT 0,
      remuneration_rate_bps INTEGER NOT NULL DEFAULT 0,
      fee_bps INTEGER NOT NULL DEFAULT 0,
      eligible_tiers_json TEXT NOT NULL,
      allowed_funding_sources_json TEXT NOT NULL,
      allowed_merchant_categories_json TEXT NOT NULL,
      recovery_model TEXT NOT NULL,
      prototype_assumptions_json TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS replay_nonces (
      nonce TEXT PRIMARY KEY,
      created_at TEXT NOT NULL
    );

    -- SEPARATED PIP IDENTITY PLANE (never joined with core ledger for public analytics)
    CREATE TABLE IF NOT EXISTS pip_customers (
      id TEXT PRIMARY KEY,
      pip_id TEXT NOT NULL CHECK (pip_id IN ('PIP_A','PIP_B')),
      pip_name TEXT NOT NULL,
      wallet_id TEXT NOT NULL UNIQUE,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL,
      synthetic_identity_ref TEXT NOT NULL,
      identity_hash TEXT NOT NULL,
      tier TEXT NOT NULL,
      kyc_status TEXT NOT NULL,
      recovery_status TEXT NOT NULL DEFAULT 'NONE',
      accessibility_high_contrast INTEGER NOT NULL DEFAULT 0,
      accessibility_large_text INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS pip_devices (
      id TEXT PRIMARY KEY,
      customer_id TEXT NOT NULL REFERENCES pip_customers(id) ON DELETE CASCADE,
      device_label TEXT NOT NULL,
      platform TEXT NOT NULL,
      key_alias TEXT NOT NULL,
      attestation_status TEXT NOT NULL,
      last_seen_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS fraud_cases (
      id TEXT PRIMARY KEY,
      payment_id TEXT,
      wallet_id TEXT NOT NULL,
      signal_type TEXT NOT NULL,
      signal_summary TEXT NOT NULL,
      severity TEXT NOT NULL CHECK (severity IN ('LOW','MEDIUM','HIGH')),
      status TEXT NOT NULL CHECK (status IN ('SIGNAL_RECORDED','UNDER_REVIEW','CUSTOMER_CONTACTED','CLEARED','BLOCKED_RESOLVED')),
      customer_message TEXT,
      reviewer_id TEXT,
      resolution_notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_events (
      id TEXT PRIMARY KEY,
      actor_role TEXT NOT NULL,
      actor_id TEXT NOT NULL,
      action TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id TEXT NOT NULL,
      details_redacted TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS offline_research_claims (
      id TEXT PRIMARY KEY,
      sender_wallet_id TEXT NOT NULL,
      receiver_wallet_id TEXT NOT NULL,
      amount_pence INTEGER NOT NULL CHECK (amount_pence > 0),
      hardware_counter INTEGER NOT NULL,
      secure_element_id TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('QUEUED_UNSETTLED','RECONCILED','DOUBLE_SPEND_DETECTED')),
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS system_state (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);

  seedInitialDataIfEmpty(db);
  return db;
}

function seedInitialDataIfEmpty(db: Database.Database): void {
  const countRow = db.prepare('SELECT COUNT(*) AS cnt FROM ledger_accounts').get() as { cnt: number };
  if (countRow.cnt > 0) {
    return;
  }

  const now = new Date().toISOString();
  const tx = db.transaction(() => {
    db.prepare('INSERT INTO system_state (key, value) VALUES (?, ?)').run(
      'hmac_key_v1',
      'sterling-research-key-v1-' + crypto.randomBytes(12).toString('hex')
    );
    db.prepare('INSERT INTO system_state (key, value) VALUES (?, ?)').run('active_hmac_key_version', 'hmac_key_v1');
    db.prepare('INSERT INTO system_state (key, value) VALUES (?, ?)').run('fault_drop_payment_response', 'false');
    db.prepare('INSERT INTO system_state (key, value) VALUES (?, ?)').run('fault_bank_payout_fail', 'false');
    db.prepare('INSERT INTO system_state (key, value) VALUES (?, ?)').run('rate_limit_rpm', '600');

    // Policy v1 (explicitly marked prototype assumptions — NOT hardcoded as settled BoE policy)
    db.prepare(`
      INSERT INTO policy_versions (
        version, effective_at, label, holding_limit_pence, tx_limit_pence,
        remuneration_enabled, remuneration_rate_bps, fee_bps,
        eligible_tiers_json, allowed_funding_sources_json, allowed_merchant_categories_json,
        recovery_model, prototype_assumptions_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      1,
      now,
      'Design Phase Baseline v1 (Consultation Illustrative Parameters)',
      2000000, // £20,000.00 illustrative holding limit (prototype assumption)
      500000,  // £5,000.00 per-transaction limit (prototype assumption)
      0,       // Non-remunerated per consultation proposal
      0,
      0,       // Zero core fee in baseline prototype
      JSON.stringify(['TIER_1_STANDARD', 'TIER_2_ENHANCED', 'MERCHANT_VERIFIED']),
      JSON.stringify(['COMMERCIAL_BANK_DEPOSIT_SIM', 'P2P_INCOMING', 'MERCHANT_REFUND']),
      JSON.stringify(['RETAIL_BOOKS_STATIONERY', 'GROCERIES_FOOD', 'TRANSPORT_TRANSIT', 'CIVIC_SERVICES']),
      'PIP_ASSISTED_WITH_COOLING_OFF',
      JSON.stringify({
        holdingLimitPence: 'Prototype assumption based on £10k–£20k consultation illustration; not settled policy.',
        txLimitPence: 'Prototype operational risk bound; configurable per versioned policy.',
        remunerationEnabled: 'Disabled (0 bps) per published BoE/HMT consultation alignment.',
        identityLinkage: 'Scoped identity_hash allows cross-PIP limit checking without exposing PII to Core Ledger.'
      })
    );

    // Control accounts
    const insertAcct = db.prepare(`
      INSERT INTO ledger_accounts (id, account_code, account_class, normal_side, pip_id, available_pence, reserved_pence, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, 0, 'ACTIVE', ?)
    `);

    insertAcct.run('CTRL_ISSUED_SUPPLY', 'CTRL-001-ISSUED', 'ISSUED_SUPPLY', 'DEBIT', null, 500000, now);
    insertAcct.run('CTRL_REDEEMED_UNITS', 'CTRL-002-REDEEMED', 'REDEEMED_UNITS', 'DEBIT', null, 0, now);
    insertAcct.run('CTRL_SETTLEMENT_POOL', 'CTRL-003-SETTLEMENT', 'SETTLEMENT_CONTROL', 'CREDIT', null, 387500, now);
    insertAcct.run('CTRL_PENDING_CONVERSION', 'CTRL-004-PENDING-CONV', 'PENDING_CONVERSION', 'CREDIT', null, 0, now);
    insertAcct.run('CTRL_RESERVED_ESCROW', 'CTRL-005-RESERVED-ESCROW', 'RESERVED_ESCROW', 'CREDIT', null, 0, now);
    insertAcct.run('CTRL_REDEMPTION_ESCROW', 'CTRL-006-REDEMP-ESCROW', 'REDEMPTION_ESCROW', 'CREDIT', null, 0, now);
    insertAcct.run('CTRL_FEE_COLLECTED', 'CTRL-007-FEES', 'FEE_CONTROL', 'CREDIT', null, 0, now);

    // Synthetic wallets across PIP_A and PIP_B (opaque IDs in Core Ledger)
    insertAcct.run('wal_pipa_alice', 'OPQ-A-7104', 'WALLET_CUSTOMER', 'CREDIT', 'PIP_A', 45000, now);
    insertAcct.run('wal_pipa_david', 'OPQ-A-7109', 'WALLET_CUSTOMER', 'CREDIT', 'PIP_A', 20000, now);
    insertAcct.run('wal_pipb_claire', 'OPQ-B-8402', 'WALLET_CUSTOMER', 'CREDIT', 'PIP_B', 32500, now);
    insertAcct.run('wal_pipb_merchant_books', 'OPQ-B-M901', 'WALLET_MERCHANT', 'CREDIT', 'PIP_B', 15000, now);

    const insertEntry = db.prepare(`
      INSERT INTO journal_entries (id, tx_type, reference, idempotency_key, reversal_of_entry_id, created_at)
      VALUES (?, ?, ?, ?, NULL, ?)
    `);
    const insertPosting = db.prepare(`
      INSERT INTO journal_postings (id, entry_id, account_id, direction, amount_pence)
      VALUES (?, ?, ?, ?, ?)
    `);

    // Seed issuance: DEBIT CTRL_ISSUED_SUPPLY 500,000 | CREDIT CTRL_SETTLEMENT_POOL 500,000
    insertEntry.run('je_seed_issuance_001', 'ISSUANCE', 'Seed Issuance RTGS-SIM-SEED-0001', 'seed-iss-001', now);
    insertPosting.run('jp_seed_1', 'je_seed_issuance_001', 'CTRL_ISSUED_SUPPLY', 'DEBIT', 500000);
    insertPosting.run('jp_seed_2', 'je_seed_issuance_001', 'CTRL_SETTLEMENT_POOL', 'CREDIT', 500000);

    // Initial issuance record referencing je_seed_issuance_001
    db.prepare(`
      INSERT INTO issuance_redemption_requests (
        id, kind, state, amount_pence, currency, requested_by, validated_by,
        approver1_id, approver2_id, settlement_evidence_ref, journal_entry_id, notes, created_at, updated_at
      ) VALUES (?, 'ISSUANCE', 'RECONCILED', 500000, 'GBP', 'issuer_ops_lead', 'ledger_validator_01',
        'issuer_authority_1', 'issuer_authority_2', 'RTGS-SIM-SEED-0001', 'je_seed_issuance_001',
        'Initial experimental sterling seed allocation for research sandbox', ?, ?)
    `).run('iss_seed_001', now, now);

    // Seed conversions to initial wallets: DEBIT CTRL_SETTLEMENT_POOL | CREDIT WALLET
    const seedAllocs: Array<[string, number, string]> = [
      ['wal_pipa_alice', 45000, 'je_seed_conv_alice'],
      ['wal_pipa_david', 20000, 'je_seed_conv_david'],
      ['wal_pipb_claire', 32500, 'je_seed_conv_claire'],
      ['wal_pipb_merchant_books', 15000, 'je_seed_conv_books'],
    ];

    seedAllocs.forEach(([walletId, amt, jeId], idx) => {
      insertEntry.run(jeId, 'CONVERSION_IN', `Seed deposit conversion for ${walletId}`, `seed-conv-${idx}`, now);
      insertPosting.run(`jp_sc_d_${idx}`, jeId, 'CTRL_SETTLEMENT_POOL', 'DEBIT', amt);
      insertPosting.run(`jp_sc_c_${idx}`, jeId, walletId, 'CREDIT', amt);
    });

    // PIP-separated synthetic customer PII records
    const insertCust = db.prepare(`
      INSERT INTO pip_customers (
        id, pip_id, pip_name, wallet_id, full_name, email, synthetic_identity_ref,
        identity_hash, tier, kyc_status, recovery_status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'VERIFIED_SYNTHETIC', 'NONE', ?)
    `);

    const hashId = (ref: string) => crypto.createHash('sha256').update(ref).digest('hex').slice(0, 24);

    insertCust.run('cust_alice', 'PIP_A', 'Thameside Digital Wallet', 'wal_pipa_alice', 'Alice Mercer (Synthetic)', 'alice.mercer@synthetic.example.uk', 'SYN-UK-88412A', hashId('SYN-UK-88412A'), 'TIER_1_STANDARD', now);
    insertCust.run('cust_david', 'PIP_A', 'Thameside Digital Wallet', 'wal_pipa_david', 'David Patel (Synthetic)', 'david.patel@synthetic.example.uk', 'SYN-UK-55190P', hashId('SYN-UK-55190P'), 'TIER_1_STANDARD', now);
    insertCust.run('cust_claire', 'PIP_B', 'Albion Civic Pay', 'wal_pipb_claire', 'Claire Bennett (Synthetic)', 'claire.bennett@synthetic.example.uk', 'SYN-UK-30291B', hashId('SYN-UK-30291B'), 'TIER_1_STANDARD', now);
    insertCust.run('cust_books', 'PIP_B', 'Albion Civic Pay', 'wal_pipb_merchant_books', 'Borough Bookshop Ltd (Synthetic)', 'treasury@boroughbooks.example.uk', 'SYN-MER-40199K', hashId('SYN-MER-40199K'), 'MERCHANT_VERIFIED', now);

    const insertDevice = db.prepare(`
      INSERT INTO pip_devices (id, customer_id, device_label, platform, key_alias, attestation_status, last_seen_at)
      VALUES (?, ?, ?, ?, ?, 'VERIFIED', ?)
    `);
    insertDevice.run('dev_alice_1', 'cust_alice', 'Pixel 8 Pro (Android Wallet)', 'ANDROID_COMPOSE_SIM', 'ks_alice_ed25519_01', now);
    insertDevice.run('dev_david_1', 'cust_david', 'Web Passkey Terminal', 'WEB_PASSKEY_SIM', 'wk_david_ecdsa_01', now);
    insertDevice.run('dev_claire_1', 'cust_claire', 'Galaxy S24 (Android Wallet)', 'ANDROID_COMPOSE_SIM', 'ks_claire_ed25519_01', now);
    insertDevice.run('dev_books_1', 'cust_books', 'Counter POS Terminal #1', 'WEB_PASSKEY_SIM', 'pos_books_ecdsa_01', now);

    // Seed one active Merchant Payment Request
    const expires = new Date(Date.now() + 3600 * 1000 * 12).toISOString();
    const prId = 'pr_books_seed_001';
    const hmacKey = (db.prepare('SELECT value FROM system_state WHERE key = ?').get('hmac_key_v1') as { value: string }).value;
    const sig = crypto
      .createHmac('sha256', hmacKey)
      .update(`${prId}|wal_pipb_merchant_books|1850|GBP|Order #BK-2041|${expires}`)
      .digest('hex');

    db.prepare(`
      INSERT INTO payment_requests (
        id, merchant_wallet_id, merchant_name, merchant_category, amount_pence,
        currency, reference, single_use, status, signature_hmac, expires_at, created_at
      ) VALUES (?, 'wal_pipb_merchant_books', 'Borough Bookshop Ltd', 'RETAIL_BOOKS_STATIONERY',
        1850, 'GBP', 'Order #BK-2041', 1, 'ACTIVE', ?, ?, ?)
    `).run(prId, sig, expires, now);

    db.prepare(`
      INSERT INTO audit_events (id, actor_role, actor_id, action, target_type, target_id, details_redacted, created_at)
      VALUES (?, 'SYSTEM', 'bootstrap', 'INITIALISE_SANDBOX_LEDGER', 'LEDGER', 'CORE', 'Seeded £5,000.00 synthetic supply across 2 PIPs and 4 wallets; invariants verified', ?)
    `).run('aud_seed_001', now);
  });

  tx();
}
