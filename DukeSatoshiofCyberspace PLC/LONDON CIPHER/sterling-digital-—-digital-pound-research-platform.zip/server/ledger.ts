import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import type Database from 'better-sqlite3';
import { BACKUP_DIR, DB_PATH, getDb, openAndMigrateDb, resetDbConnection } from './db.ts';
import type {
  ActorRole,
  ConversionRequest,
  IssuanceRedemptionRequest,
  LedgerAccount,
  MerchantPaymentRequest,
  PaymentRecord,
  PolicyConfig,
  ReconciliationReport,
} from '../src/types/cbdc.ts';

export class LedgerError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string, message: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export function assertPositiveIntPence(value: unknown, fieldName = 'amountPence'): number {
  if (typeof value !== 'number' || !Number.isInteger(value) || !Number.isSafeInteger(value) || value <= 0) {
    throw new LedgerError(400, 'INVALID_MONETARY_AMOUNT', `${fieldName} must be a strictly positive integer number of pence (no floats).`);
  }
  return value;
}

export function uid(prefix: string): string {
  return `${prefix}_${crypto.randomBytes(6).toString('hex')}`;
}

export function getActivePolicy(db: Database.Database = getDb()): PolicyConfig {
  const row = db.prepare('SELECT * FROM policy_versions ORDER BY version DESC LIMIT 1').get() as Record<string, unknown>;
  return {
    version: Number(row.version),
    effectiveAt: String(row.effective_at),
    label: String(row.label),
    holdingLimitPence: row.holding_limit_pence === null ? null : Number(row.holding_limit_pence),
    txLimitPence: row.tx_limit_pence === null ? null : Number(row.tx_limit_pence),
    remunerationEnabled: Boolean(row.remuneration_enabled),
    remunerationRateBps: Number(row.remuneration_rate_bps),
    feeBps: Number(row.fee_bps),
    eligibleTiers: JSON.parse(String(row.eligible_tiers_json)),
    allowedFundingSources: JSON.parse(String(row.allowed_funding_sources_json)),
    allowedMerchantCategories: JSON.parse(String(row.allowed_merchant_categories_json)),
    recoveryModel: String(row.recovery_model) as PolicyConfig['recoveryModel'],
    prototypeAssumptions: JSON.parse(String(row.prototype_assumptions_json)),
  };
}

function getActiveHmacKey(db: Database.Database): string {
  const ver = db.prepare('SELECT value FROM system_state WHERE key = ?').get('active_hmac_key_version') as { value: string };
  const secret = db.prepare('SELECT value FROM system_state WHERE key = ?').get(ver.value) as { value: string };
  return secret.value;
}

export function signPaymentRequest(
  db: Database.Database,
  id: string,
  merchantWalletId: string,
  amountPence: number,
  currency: string,
  reference: string,
  expiresAt: string
): string {
  const key = getActiveHmacKey(db);
  return crypto
    .createHmac('sha256', key)
    .update(`${id}|${merchantWalletId}|${amountPence}|${currency}|${reference}|${expiresAt}`)
    .digest('hex');
}

export function recordAudit(
  db: Database.Database,
  actorRole: string,
  actorId: string,
  action: string,
  targetType: string,
  targetId: string,
  detailsRedacted: string
): void {
  db.prepare(`
    INSERT INTO audit_events (id, actor_role, actor_id, action, target_type, target_id, details_redacted, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(uid('aud'), actorRole, actorId, action, targetType, targetId, detailsRedacted, new Date().toISOString());
}

/**
 * Atomic double-entry posting engine.
 * Verifies SUM(debits) === SUM(credits) and updates account balances in integer pence.
 * Prevents any account from going negative.
 */
function postBalancedEntry(
  db: Database.Database,
  params: {
    txType: string;
    reference: string;
    idempotencyKey?: string | null;
    reversalOfEntryId?: string | null;
    legs: Array<{ accountId: string; direction: 'DEBIT' | 'CREDIT'; amountPence: number }>;
  }
): string {
  const { txType, reference, idempotencyKey = null, reversalOfEntryId = null, legs } = params;
  if (legs.length < 2) {
    throw new LedgerError(500, 'UNBALANCED_ENTRY', 'Journal entry requires at least two postings.');
  }

  let totalDebits = 0;
  let totalCredits = 0;
  for (const leg of legs) {
    assertPositiveIntPence(leg.amountPence, 'posting.amountPence');
    if (leg.direction === 'DEBIT') totalDebits += leg.amountPence;
    else totalCredits += leg.amountPence;
  }

  if (totalDebits !== totalCredits) {
    throw new LedgerError(500, 'UNBALANCED_ENTRY', `Debits (${totalDebits}) do not equal Credits (${totalCredits}).`);
  }

  const entryId = uid('je');
  const now = new Date().toISOString();
  db.prepare(`
    INSERT INTO journal_entries (id, tx_type, reference, idempotency_key, reversal_of_entry_id, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(entryId, txType, reference, idempotencyKey, reversalOfEntryId, now);

  const getAcct = db.prepare('SELECT id, normal_side, available_pence FROM ledger_accounts WHERE id = ?');
  const updateAcct = db.prepare('UPDATE ledger_accounts SET available_pence = ? WHERE id = ?');
  const insertPosting = db.prepare(`
    INSERT INTO journal_postings (id, entry_id, account_id, direction, amount_pence)
    VALUES (?, ?, ?, ?, ?)
  `);

  for (const leg of legs) {
    const acct = getAcct.get(leg.accountId) as { id: string; normal_side: 'DEBIT' | 'CREDIT'; available_pence: number } | undefined;
    if (!acct) {
      throw new LedgerError(404, 'ACCOUNT_NOT_FOUND', `Ledger account ${leg.accountId} does not exist.`);
    }

    const delta = acct.normal_side === leg.direction ? leg.amountPence : -leg.amountPence;
    const nextBalance = acct.available_pence + delta;
    if (nextBalance < 0) {
      throw new LedgerError(409, 'INSUFFICIENT_FUNDS', `Insufficient available funds in account ${leg.accountId}.`);
    }

    updateAcct.run(nextBalance, leg.accountId);
    insertPosting.run(uid('jp'), entryId, leg.accountId, leg.direction, leg.amountPence);
  }

  return entryId;
}

export function computeReconciliation(db: Database.Database = getDb()): ReconciliationReport {
  const accounts = db.prepare('SELECT * FROM ledger_accounts').all() as Array<Record<string, unknown>>;
  const byId = new Map<string, number>();
  let walletAvailableSum = 0;
  let walletReservedSum = 0;

  for (const a of accounts) {
    const id = String(a.id);
    const avail = Number(a.available_pence);
    const res = Number(a.reserved_pence);
    byId.set(id, avail);
    if (a.account_class === 'WALLET_CUSTOMER' || a.account_class === 'WALLET_MERCHANT') {
      walletAvailableSum += avail;
      walletReservedSum += res;
    }
  }

  const issuedTotal = byId.get('CTRL_ISSUED_SUPPLY') ?? 0;
  const redeemedTotal = byId.get('CTRL_REDEEMED_UNITS') ?? 0;
  const netSupply = issuedTotal - redeemedTotal;

  const settlementPool = byId.get('CTRL_SETTLEMENT_POOL') ?? 0;
  const pendingConversion = byId.get('CTRL_PENDING_CONVERSION') ?? 0;
  const reservedEscrow = byId.get('CTRL_RESERVED_ESCROW') ?? 0;
  const redemptionEscrow = byId.get('CTRL_REDEMPTION_ESCROW') ?? 0;
  const feeControl = byId.get('CTRL_FEE_COLLECTED') ?? 0;

  const accountedLiabilities =
    settlementPool + pendingConversion + reservedEscrow + redemptionEscrow + feeControl + walletAvailableSum;
  const discrepancyPence = netSupply - accountedLiabilities;

  const sums = db
    .prepare(`
      SELECT
        COALESCE(SUM(CASE WHEN direction = 'DEBIT' THEN amount_pence ELSE 0 END), 0) AS debits,
        COALESCE(SUM(CASE WHEN direction = 'CREDIT' THEN amount_pence ELSE 0 END), 0) AS credits
      FROM journal_postings
    `)
    .get() as { debits: number; credits: number };

  const alerts: string[] = [];
  if (discrepancyPence !== 0) {
    alerts.push(`CRITICAL: Supply conservation discrepancy of ${discrepancyPence} pence detected.`);
  }
  if (sums.debits !== sums.credits) {
    alerts.push(`CRITICAL: Journal posting imbalance: debits=${sums.debits}, credits=${sums.credits}.`);
  }
  if (reservedEscrow !== walletReservedSum) {
    alerts.push(`WARNING: Escrow (${reservedEscrow}) differs from wallet reserved sum (${walletReservedSum}).`);
  }

  return {
    generatedAt: new Date().toISOString(),
    issuedTotalPence: issuedTotal,
    redeemedTotalPence: redeemedTotal,
    netSupplyPence: netSupply,
    settlementPoolPence: settlementPool,
    pendingConversionPence: pendingConversion,
    reservedEscrowPence: reservedEscrow,
    redemptionEscrowPence: redemptionEscrow,
    feeControlPence: feeControl,
    walletAvailableSumPence: walletAvailableSum,
    walletReservedSumPence: walletReservedSum,
    totalDebitsPence: sums.debits,
    totalCreditsPence: sums.credits,
    invariantSupplyBalanced: discrepancyPence === 0,
    invariantDoubleEntryBalanced: sums.debits === sums.credits,
    discrepancyPence,
    alerts,
  };
}

export function createWalletAndCustomer(
  actorRole: ActorRole,
  actorId: string,
  input: {
    pipId: 'PIP_A' | 'PIP_B';
    fullName: string;
    email: string;
    syntheticIdentityRef: string;
    tier: 'TIER_1_STANDARD' | 'TIER_2_ENHANCED' | 'MERCHANT_VERIFIED';
    accountClass?: 'WALLET_CUSTOMER' | 'WALLET_MERCHANT';
    deviceLabel?: string;
  }
): { wallet: LedgerAccount; customerId: string } {
  if (!['PIP_A', 'PIP_B', 'OPERATOR'].includes(actorRole)) {
    throw new LedgerError(403, 'FORBIDDEN', 'Only authorised Payment Interface Providers or Operators may onboard wallets.');
  }
  if (actorRole === 'PIP_A' && input.pipId !== 'PIP_A') {
    throw new LedgerError(403, 'CROSS_PROVIDER_DENIED', 'PIP_A cannot create wallets scoped to PIP_B.');
  }
  if (actorRole === 'PIP_B' && input.pipId !== 'PIP_B') {
    throw new LedgerError(403, 'CROSS_PROVIDER_DENIED', 'PIP_B cannot create wallets scoped to PIP_A.');
  }

  const db = getDb();
  const now = new Date().toISOString();
  const walletId = uid('wal_' + input.pipId.toLowerCase());
  const accountCode = `OPQ-${input.pipId === 'PIP_A' ? 'A' : 'B'}-${crypto.randomInt(1000, 9999)}`;
  const customerId = uid('cust');
  const acctClass = input.accountClass ?? (input.tier === 'MERCHANT_VERIFIED' ? 'WALLET_MERCHANT' : 'WALLET_CUSTOMER');
  const pipName = input.pipId === 'PIP_A' ? 'Thameside Digital Wallet' : 'Albion Civic Pay';
  const idHash = crypto.createHash('sha256').update(input.syntheticIdentityRef).digest('hex').slice(0, 24);

  const tx = db.transaction(() => {
    db.prepare(`
      INSERT INTO ledger_accounts (id, account_code, account_class, normal_side, pip_id, available_pence, reserved_pence, status, created_at)
      VALUES (?, ?, ?, 'CREDIT', ?, 0, 0, 'ACTIVE', ?)
    `).run(walletId, accountCode, acctClass, input.pipId, now);

    db.prepare(`
      INSERT INTO pip_customers (
        id, pip_id, pip_name, wallet_id, full_name, email, synthetic_identity_ref,
        identity_hash, tier, kyc_status, recovery_status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'VERIFIED_SYNTHETIC', 'NONE', ?)
    `).run(customerId, input.pipId, pipName, walletId, input.fullName, input.email, input.syntheticIdentityRef, idHash, input.tier, now);

    db.prepare(`
      INSERT INTO pip_devices (id, customer_id, device_label, platform, key_alias, attestation_status, last_seen_at)
      VALUES (?, ?, ?, 'ANDROID_COMPOSE_SIM', ?, 'VERIFIED', ?)
    `).run(uid('dev'), customerId, input.deviceLabel || 'Primary Mobile Wallet', `ks_${crypto.randomBytes(4).toString('hex')}`, now);

    recordAudit(db, actorRole, actorId, 'CREATE_WALLET', 'WALLET', walletId, `Onboarded ${acctClass} at ${input.pipId} (PII retained in PIP plane)`);
  });

  tx();
  const wallet = db.prepare('SELECT * FROM ledger_accounts WHERE id = ?').get(walletId) as Record<string, unknown>;
  return { wallet: mapAccount(wallet), customerId };
}

export function mapAccount(r: Record<string, unknown>): LedgerAccount {
  return {
    id: String(r.id),
    accountCode: String(r.account_code),
    accountClass: String(r.account_class) as LedgerAccount['accountClass'],
    normalSide: String(r.normal_side) as LedgerAccount['normalSide'],
    pipId: r.pip_id ? String(r.pip_id) : null,
    availablePence: Number(r.available_pence),
    reservedPence: Number(r.reserved_pence),
    status: String(r.status) as LedgerAccount['status'],
    createdAt: String(r.created_at),
  };
}

function checkHoldingLimitForPayee(db: Database.Database, payeeWalletId: string, incomingNetPence: number, policy: PolicyConfig): void {
  if (policy.holdingLimitPence === null) return;
  const acct = db.prepare('SELECT account_class, available_pence, reserved_pence FROM ledger_accounts WHERE id = ?').get(payeeWalletId) as
    | { account_class: string; available_pence: number; reserved_pence: number }
    | undefined;
  if (!acct) throw new LedgerError(404, 'WALLET_NOT_FOUND', `Wallet ${payeeWalletId} not found.`);
  if (acct.account_class === 'WALLET_MERCHANT') return; // Commercial merchants exempt from retail holding cap

  // Scoped identity-hash check across PIPs (explicit prototype tradeoff documented in Design Register)
  const cust = db.prepare('SELECT identity_hash FROM pip_customers WHERE wallet_id = ?').get(payeeWalletId) as { identity_hash: string } | undefined;
  let aggregateBalance = acct.available_pence + acct.reserved_pence;
  if (cust) {
    const linked = db
      .prepare(`
        SELECT COALESCE(SUM(la.available_pence + la.reserved_pence), 0) AS total
        FROM pip_customers pc
        JOIN ledger_accounts la ON la.id = pc.wallet_id
        WHERE pc.identity_hash = ? AND la.account_class = 'WALLET_CUSTOMER'
      `)
      .get(cust.identity_hash) as { total: number };
    aggregateBalance = linked.total;
  }

  if (aggregateBalance + incomingNetPence > policy.holdingLimitPence) {
    throw new LedgerError(
      422,
      'HOLDING_LIMIT_EXCEEDED',
      `Incoming £${(incomingNetPence / 100).toFixed(2)} would breach the configured £${(policy.holdingLimitPence / 100).toFixed(2)} retail holding limit (current £${(aggregateBalance / 100).toFixed(2)}).`
    );
  }
}

export function previewPayment(input: {
  payerWalletId: string;
  payeeWalletId: string;
  amountPence: number;
  paymentRequestId?: string | null;
  reference: string;
}): {
  valid: boolean;
  amountPence: number;
  feePence: number;
  netPayeePence: number;
  payerAvailablePence: number;
  payeeHoldingLimitPence: number | null;
  warnings: string[];
  authorisationPayloadHash: string;
} {
  const db = getDb();
  const amountPence = assertPositiveIntPence(input.amountPence);
  const policy = getActivePolicy(db);

  const payer = db.prepare('SELECT * FROM ledger_accounts WHERE id = ?').get(input.payerWalletId) as Record<string, unknown> | undefined;
  const payee = db.prepare('SELECT * FROM ledger_accounts WHERE id = ?').get(input.payeeWalletId) as Record<string, unknown> | undefined;
  if (!payer || !payee) throw new LedgerError(404, 'WALLET_NOT_FOUND', 'Payer or payee wallet not found.');
  if (input.payerWalletId === input.payeeWalletId) throw new LedgerError(400, 'SELF_PAYMENT_DISALLOWED', 'Payer and payee cannot be the same wallet.');
  if (payer.status !== 'ACTIVE') throw new LedgerError(403, 'WALLET_LOCKED', `Payer wallet status is ${payer.status}.`);
  if (payee.status !== 'ACTIVE') throw new LedgerError(403, 'WALLET_LOCKED', `Payee wallet status is ${payee.status}.`);

  const feePence = Math.floor((amountPence * policy.feeBps) / 10000);
  const netPayeePence = amountPence - feePence;

  if (policy.txLimitPence !== null && amountPence > policy.txLimitPence) {
    throw new LedgerError(422, 'TX_LIMIT_EXCEEDED', `Amount exceeds configured transaction limit of £${(policy.txLimitPence / 100).toFixed(2)}.`);
  }
  if (Number(payer.available_pence) < amountPence) {
    throw new LedgerError(409, 'INSUFFICIENT_FUNDS', 'Available balance is lower than requested payment amount.');
  }

  checkHoldingLimitForPayee(db, input.payeeWalletId, netPayeePence, policy);

  if (input.paymentRequestId) {
    const reqRow = db.prepare('SELECT * FROM payment_requests WHERE id = ?').get(input.paymentRequestId) as Record<string, unknown> | undefined;
    if (!reqRow) throw new LedgerError(404, 'PAYMENT_REQUEST_NOT_FOUND', 'Payment request not found.');
    if (reqRow.status !== 'ACTIVE') throw new LedgerError(409, 'PAYMENT_REQUEST_INACTIVE', `Payment request is ${reqRow.status} and cannot be reused.`);
    if (new Date(String(reqRow.expires_at)).getTime() < Date.now()) {
      throw new LedgerError(410, 'PAYMENT_REQUEST_EXPIRED', 'Merchant payment request has expired.');
    }
    if (Number(reqRow.amount_pence) !== amountPence || String(reqRow.merchant_wallet_id) !== input.payeeWalletId) {
      throw new LedgerError(400, 'REQUEST_TAMPERING_DETECTED', 'Amount or payee does not match signed merchant payment request.');
    }
    const expectedSig = signPaymentRequest(
      db,
      String(reqRow.id),
      String(reqRow.merchant_wallet_id),
      Number(reqRow.amount_pence),
      String(reqRow.currency),
      String(reqRow.reference),
      String(reqRow.expires_at)
    );
    if (expectedSig !== String(reqRow.signature_hmac)) {
      throw new LedgerError(400, 'SIGNATURE_INVALID', 'Payment request integrity verification failed.');
    }
  }

  const warnings: string[] = [];
  if (amountPence >= 250000) {
    warnings.push('Large transfer signal (> £2,500) will generate a monitoring review event.');
  }

  const authorisationPayloadHash = crypto
    .createHash('sha256')
    .update(`${input.payerWalletId}|${input.payeeWalletId}|${amountPence}|GBP|${input.reference}|${input.paymentRequestId ?? ''}`)
    .digest('hex');

  return {
    valid: true,
    amountPence,
    feePence,
    netPayeePence,
    payerAvailablePence: Number(payer.available_pence),
    payeeHoldingLimitPence: policy.holdingLimitPence,
    warnings,
    authorisationPayloadHash,
  };
}

/**
 * Execute Payment with strict serializable transaction (`BEGIN IMMEDIATE`),
 * idempotency replay protection, replay nonce check, two-phase Reserve -> Finalise journal postings,
 * and optional simulated dropped response (fault injection) while persisting final state!
 */
export function executePayment(
  actorRole: ActorRole,
  actorId: string,
  input: {
    payerWalletId: string;
    payeeWalletId: string;
    amountPence: number;
    paymentReference: string;
    paymentRequestId?: string | null;
    idempotencyKey: string;
    nonce?: string;
    scheduledFor?: string | null;
    paymentKind?: 'P2P' | 'MERCHANT' | 'SCHEDULED';
    simulateTimeoutAfterCommit?: boolean;
  }
): { payment: PaymentRecord; idempotentReplay: boolean } {
  const db = getDb();
  const amountPence = assertPositiveIntPence(input.amountPence);
  if (!input.idempotencyKey || input.idempotencyKey.trim().length < 4) {
    throw new LedgerError(400, 'MISSING_IDEMPOTENCY_KEY', 'A durable Idempotency-Key is required.');
  }

  // Idempotency check BEFORE executing state transitions
  const existing = db.prepare('SELECT * FROM payments WHERE idempotency_key = ?').get(input.idempotencyKey) as Record<string, unknown> | undefined;
  if (existing) {
    if (
      String(existing.payer_wallet_id) !== input.payerWalletId ||
      String(existing.payee_wallet_id) !== input.payeeWalletId ||
      Number(existing.amount_pence) !== amountPence
    ) {
      throw new LedgerError(409, 'IDEMPOTENCY_CONFLICT', 'Idempotency-Key already used for a different payment payload.');
    }
    return { payment: mapPayment(existing), idempotentReplay: true };
  }

  // Enforce ownership / provider scope
  const payerAcct = db.prepare('SELECT * FROM ledger_accounts WHERE id = ?').get(input.payerWalletId) as Record<string, unknown> | undefined;
  if (!payerAcct) throw new LedgerError(404, 'PAYER_NOT_FOUND', 'Payer wallet not found.');
  if (actorRole === 'PIP_A' && payerAcct.pip_id !== 'PIP_A') {
    throw new LedgerError(403, 'CROSS_PROVIDER_DENIED', 'PIP_A cannot debit wallets belonging to PIP_B.');
  }
  if (actorRole === 'PIP_B' && payerAcct.pip_id !== 'PIP_B') {
    throw new LedgerError(403, 'CROSS_PROVIDER_DENIED', 'PIP_B cannot debit wallets belonging to PIP_A.');
  }
  if (actorRole === 'ISSUER' || actorRole === 'AUDITOR') {
    throw new LedgerError(403, 'ROLE_SEPARATION', 'Issuers and Auditors cannot initiate consumer wallet payments.');
  }

  const runImmediate = db.transaction(() => {
    // Double-check idempotency inside write lock
    const insideExisting = db.prepare('SELECT * FROM payments WHERE idempotency_key = ?').get(input.idempotencyKey) as Record<string, unknown> | undefined;
    if (insideExisting) {
      return { payment: mapPayment(insideExisting), idempotentReplay: true };
    }

    if (input.nonce) {
      const seen = db.prepare('SELECT nonce FROM replay_nonces WHERE nonce = ?').get(input.nonce);
      if (seen) throw new LedgerError(409, 'REPLAY_DETECTED', 'Request nonce has already been consumed.');
      db.prepare('INSERT INTO replay_nonces (nonce, created_at) VALUES (?, ?)').run(input.nonce, new Date().toISOString());
    }

    const preview = previewPayment({
      payerWalletId: input.payerWalletId,
      payeeWalletId: input.payeeWalletId,
      amountPence,
      paymentRequestId: input.paymentRequestId,
      reference: input.paymentReference,
    });

    const payeeAcct = db.prepare('SELECT * FROM ledger_accounts WHERE id = ?').get(input.payeeWalletId) as Record<string, unknown>;
    const now = new Date().toISOString();
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();
    const paymentId = uid('pay');
    const kind = input.paymentKind ?? (input.scheduledFor ? 'SCHEDULED' : input.paymentRequestId ? 'MERCHANT' : 'P2P');

    // Scheduled instructions are explicitly distinct from executed payments
    if (kind === 'SCHEDULED' && input.scheduledFor && new Date(input.scheduledFor).getTime() > Date.now()) {
      db.prepare(`
        INSERT INTO payments (
          id, state, payment_kind, payer_wallet_id, payee_wallet_id, payer_pip_id, payee_pip_id,
          amount_pence, fee_pence, currency, payment_reference, payment_request_id, idempotency_key,
          authorisation_hash, expires_at, scheduled_for, created_at, updated_at
        ) VALUES (?, 'AUTHORISED', 'SCHEDULED', ?, ?, ?, ?, ?, ?, 'GBP', ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        paymentId,
        input.payerWalletId,
        input.payeeWalletId,
        String(payerAcct.pip_id ?? 'CORE'),
        String(payeeAcct.pip_id ?? 'CORE'),
        amountPence,
        preview.feePence,
        input.paymentReference,
        input.paymentRequestId ?? null,
        input.idempotencyKey,
        preview.authorisationPayloadHash,
        expiresAt,
        input.scheduledFor,
        now,
        now
      );
      recordAudit(db, actorRole, actorId, 'SCHEDULE_PAYMENT', 'PAYMENT', paymentId, `Scheduled future instruction for ${input.scheduledFor}; ledger funds NOT yet moved`);
      const row = db.prepare('SELECT * FROM payments WHERE id = ?').get(paymentId) as Record<string, unknown>;
      return { payment: mapPayment(row), idempotentReplay: false };
    }

    // Step 1: Reserve funds (Authorised -> Reserved Escrow)
    const reserveEntryId = postBalancedEntry(db, {
      txType: 'PAYMENT_RESERVE',
      reference: `Reserve for ${paymentId}: ${input.paymentReference}`,
      legs: [
        { accountId: input.payerWalletId, direction: 'DEBIT', amountPence },
        { accountId: 'CTRL_RESERVED_ESCROW', direction: 'CREDIT', amountPence },
      ],
    });
    db.prepare('UPDATE ledger_accounts SET reserved_pence = reserved_pence + ? WHERE id = ?').run(amountPence, input.payerWalletId);

    // Step 2: Finalise at exact SQLite commit point (Escrow -> Payee + optional Fee)
    const finalLegs: Array<{ accountId: string; direction: 'DEBIT' | 'CREDIT'; amountPence: number }> = [
      { accountId: 'CTRL_RESERVED_ESCROW', direction: 'DEBIT', amountPence },
      { accountId: input.payeeWalletId, direction: 'CREDIT', amountPence: preview.netPayeePence },
    ];
    if (preview.feePence > 0) {
      finalLegs.push({ accountId: 'CTRL_FEE_COLLECTED', direction: 'CREDIT', amountPence: preview.feePence });
    }

    const finalEntryId = postBalancedEntry(db, {
      txType: kind === 'MERCHANT' ? 'MERCHANT_PAYMENT_FINAL' : 'P2P_PAYMENT_FINAL',
      reference: `Finalise ${paymentId}: ${input.paymentReference}`,
      idempotencyKey: `pay-final-${input.idempotencyKey}`,
      legs: finalLegs,
    });
    db.prepare('UPDATE ledger_accounts SET reserved_pence = reserved_pence - ? WHERE id = ?').run(amountPence, input.payerWalletId);

    db.prepare(`
      INSERT INTO payments (
        id, state, payment_kind, payer_wallet_id, payee_wallet_id, payer_pip_id, payee_pip_id,
        amount_pence, fee_pence, currency, payment_reference, payment_request_id, idempotency_key,
        authorisation_hash, expires_at, scheduled_for, reservation_entry_id, final_entry_id, created_at, updated_at
      ) VALUES (?, 'FINALISED', ?, ?, ?, ?, ?, ?, ?, 'GBP', ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?)
    `).run(
      paymentId,
      kind,
      input.payerWalletId,
      input.payeeWalletId,
      String(payerAcct.pip_id ?? 'CORE'),
      String(payeeAcct.pip_id ?? 'CORE'),
      amountPence,
      preview.feePence,
      input.paymentReference,
      input.paymentRequestId ?? null,
      input.idempotencyKey,
      preview.authorisationPayloadHash,
      expiresAt,
      reserveEntryId,
      finalEntryId,
      now,
      now
    );

    if (input.paymentRequestId) {
      const pr = db.prepare('SELECT single_use FROM payment_requests WHERE id = ?').get(input.paymentRequestId) as { single_use: number };
      if (pr.single_use) {
        db.prepare(`UPDATE payment_requests SET status = 'USED', paid_payment_id = ? WHERE id = ?`).run(paymentId, input.paymentRequestId);
      }
    }

    // Monitoring signal if > £2,500 (separate from conclusions of wrongdoing)
    if (amountPence >= 250000) {
      db.prepare(`
        INSERT INTO fraud_cases (id, payment_id, wallet_id, signal_type, signal_summary, severity, status, created_at, updated_at)
        VALUES (?, ?, ?, 'HIGH_VALUE_THRESHOLD', ?, 'MEDIUM', 'SIGNAL_RECORDED', ?, ?)
      `).run(
        uid('frd'),
        paymentId,
        input.payerWalletId,
        `Payment of £${(amountPence / 100).toFixed(2)} exceeded £2,500 monitoring threshold (signal only; payment finalised under policy v${getActivePolicy(db).version}).`,
        now,
        now
      );
    }

    recordAudit(
      db,
      actorRole,
      actorId,
      'FINALISE_PAYMENT',
      'PAYMENT',
      paymentId,
      `Finalised ${amountPence}p from ${input.payerWalletId} to ${input.payeeWalletId}`
    );

    const row = db.prepare('SELECT * FROM payments WHERE id = ?').get(paymentId) as Record<string, unknown>;
    return { payment: mapPayment(row), idempotentReplay: false };
  });

  const result = runImmediate.immediate();

  // Fault injection: simulate network timeout AFTER ledger commit so retry/status query proves idempotency!
  const faultRow = db.prepare('SELECT value FROM system_state WHERE key = ?').get('fault_drop_payment_response') as { value: string };
  if (input.simulateTimeoutAfterCommit || faultRow.value === 'true') {
    if (faultRow.value === 'true') {
      db.prepare('UPDATE system_state SET value = ? WHERE key = ?').run('false', 'fault_drop_payment_response');
    }
    throw new LedgerError(
      504,
      'SIMULATED_GATEWAY_TIMEOUT',
      `Simulated lost response after ledger commit! Query GET /api/payments?idempotencyKey=${input.idempotencyKey} or retry safely with the same Idempotency-Key.`
    );
  }

  return result;
}

export function mapPayment(r: Record<string, unknown>): PaymentRecord {
  return {
    id: String(r.id),
    state: String(r.state) as PaymentRecord['state'],
    paymentKind: String(r.payment_kind) as PaymentRecord['paymentKind'],
    payerWalletId: String(r.payer_wallet_id),
    payeeWalletId: String(r.payee_wallet_id),
    payerPipId: String(r.payer_pip_id),
    payeePipId: String(r.payee_pip_id),
    amountPence: Number(r.amount_pence),
    feePence: Number(r.fee_pence),
    currency: 'GBP',
    paymentReference: String(r.payment_reference),
    paymentRequestId: r.payment_request_id ? String(r.payment_request_id) : null,
    idempotencyKey: String(r.idempotency_key),
    authorisationHash: String(r.authorisation_hash),
    expiresAt: String(r.expires_at),
    scheduledFor: r.scheduled_for ? String(r.scheduled_for) : null,
    reservationEntryId: r.reservation_entry_id ? String(r.reservation_entry_id) : null,
    finalEntryId: r.final_entry_id ? String(r.final_entry_id) : null,
    rejectionReason: r.rejection_reason ? String(r.rejection_reason) : null,
    refundedPence: Number(r.refunded_pence),
    createdAt: String(r.created_at),
    updatedAt: String(r.updated_at),
  };
}

export function createPaymentRequest(
  actorRole: ActorRole,
  actorId: string,
  input: {
    merchantWalletId: string;
    amountPence: number;
    reference: string;
    singleUse?: boolean;
    ttlSeconds?: number;
  }
): MerchantPaymentRequest {
  const db = getDb();
  const amountPence = assertPositiveIntPence(input.amountPence);
  const merchantAcct = db.prepare('SELECT * FROM ledger_accounts WHERE id = ?').get(input.merchantWalletId) as Record<string, unknown> | undefined;
  if (!merchantAcct || merchantAcct.account_class !== 'WALLET_MERCHANT') {
    throw new LedgerError(400, 'INVALID_MERCHANT_WALLET', 'Target wallet must be a verified merchant account.');
  }
  const cust = db.prepare('SELECT full_name FROM pip_customers WHERE wallet_id = ?').get(input.merchantWalletId) as { full_name: string } | undefined;
  const merchantName = cust ? cust.full_name.replace(' (Synthetic)', '') : 'Synthetic Merchant';
  const id = uid('pr');
  const now = new Date();
  const expiresAt = new Date(now.getTime() + (input.ttlSeconds ?? 900) * 1000).toISOString();
  const sig = signPaymentRequest(db, id, input.merchantWalletId, amountPence, 'GBP', input.reference, expiresAt);

  db.prepare(`
    INSERT INTO payment_requests (
      id, merchant_wallet_id, merchant_name, merchant_category, amount_pence,
      currency, reference, single_use, status, signature_hmac, expires_at, created_at
    ) VALUES (?, ?, ?, 'RETAIL_BOOKS_STATIONERY', ?, 'GBP', ?, ?, 'ACTIVE', ?, ?, ?)
  `).run(id, input.merchantWalletId, merchantName, amountPence, input.reference, input.singleUse === false ? 0 : 1, sig, expiresAt, now.toISOString());

  recordAudit(db, actorRole, actorId, 'CREATE_PAYMENT_REQUEST', 'PAYMENT_REQUEST', id, `Created ${amountPence}p request for ${input.merchantWalletId}`);
  const row = db.prepare('SELECT * FROM payment_requests WHERE id = ?').get(id) as Record<string, unknown>;
  return mapPaymentRequest(row);
}

export function mapPaymentRequest(r: Record<string, unknown>): MerchantPaymentRequest {
  return {
    id: String(r.id),
    merchantWalletId: String(r.merchant_wallet_id),
    merchantName: String(r.merchant_name),
    merchantCategory: String(r.merchant_category),
    amountPence: Number(r.amount_pence),
    currency: 'GBP',
    reference: String(r.reference),
    singleUse: Boolean(r.single_use),
    status: String(r.status) as MerchantPaymentRequest['status'],
    signatureHmac: String(r.signature_hmac),
    expiresAt: String(r.expires_at),
    paidPaymentId: r.paid_payment_id ? String(r.paid_payment_id) : null,
    createdAt: String(r.created_at),
  };
}

export function issueRefund(
  actorRole: ActorRole,
  actorId: string,
  input: {
    originalPaymentId: string;
    refundAmountPence: number;
    reason: string;
    idempotencyKey: string;
  }
): { refundPayment: PaymentRecord; originalPayment: PaymentRecord } {
  const db = getDb();
  const refundPence = assertPositiveIntPence(input.refundAmountPence, 'refundAmountPence');
  if (!['MERCHANT', 'PIP_B', 'PIP_A', 'OPERATOR'].includes(actorRole)) {
    throw new LedgerError(403, 'FORBIDDEN', 'Only merchant or provider operators can issue refunds.');
  }

  const run = db.transaction(() => {
    const existing = db.prepare('SELECT * FROM payments WHERE idempotency_key = ?').get(input.idempotencyKey) as Record<string, unknown> | undefined;
    const orig = db.prepare('SELECT * FROM payments WHERE id = ?').get(input.originalPaymentId) as Record<string, unknown> | undefined;
    if (!orig) throw new LedgerError(404, 'PAYMENT_NOT_FOUND', 'Original payment not found.');
    if (existing) {
      return { refundPayment: mapPayment(existing), originalPayment: mapPayment(orig) };
    }
    if (orig.state !== 'FINALISED') {
      throw new LedgerError(409, 'INVALID_PAYMENT_STATE', 'Only finalised payments can be refunded.');
    }

    const netReceived = Number(orig.amount_pence) - Number(orig.fee_pence);
    const alreadyRefunded = Number(orig.refunded_pence);
    if (alreadyRefunded + refundPence > netReceived) {
      throw new LedgerError(422, 'REFUND_LIMIT_EXCEEDED', `Refund exceeds remaining refundable amount (£${((netReceived - alreadyRefunded) / 100).toFixed(2)}).`);
    }

    const refundId = uid('ref');
    const now = new Date().toISOString();
    const entryId = postBalancedEntry(db, {
      txType: 'MERCHANT_REFUND',
      reference: `Refund of ${input.originalPaymentId}: ${input.reason}`,
      idempotencyKey: `refund-${input.idempotencyKey}`,
      reversalOfEntryId: orig.final_entry_id ? String(orig.final_entry_id) : null,
      legs: [
        { accountId: String(orig.payee_wallet_id), direction: 'DEBIT', amountPence: refundPence },
        { accountId: String(orig.payer_wallet_id), direction: 'CREDIT', amountPence: refundPence },
      ],
    });

    db.prepare('UPDATE payments SET refunded_pence = refunded_pence + ?, updated_at = ? WHERE id = ?').run(refundPence, now, input.originalPaymentId);

    const authHash = crypto.createHash('sha256').update(`${refundId}|${input.originalPaymentId}|${refundPence}`).digest('hex');
    db.prepare(`
      INSERT INTO payments (
        id, state, payment_kind, payer_wallet_id, payee_wallet_id, payer_pip_id, payee_pip_id,
        amount_pence, fee_pence, currency, payment_reference, payment_request_id, idempotency_key,
        authorisation_hash, expires_at, final_entry_id, created_at, updated_at
      ) VALUES (?, 'FINALISED', 'MERCHANT', ?, ?, ?, ?, ?, 0, 'GBP', ?, NULL, ?, ?, ?, ?, ?, ?)
    `).run(
      refundId,
      String(orig.payee_wallet_id),
      String(orig.payer_wallet_id),
      String(orig.payee_pip_id),
      String(orig.payer_pip_id),
      refundPence,
      `Refund for ${input.originalPaymentId}: ${input.reason}`,
      input.idempotencyKey,
      authHash,
      now,
      entryId,
      now,
      now
    );

    recordAudit(db, actorRole, actorId, 'ISSUE_REFUND', 'PAYMENT', refundId, `Refunded ${refundPence}p against ${input.originalPaymentId}`);
    const refRow = db.prepare('SELECT * FROM payments WHERE id = ?').get(refundId) as Record<string, unknown>;
    const updatedOrig = db.prepare('SELECT * FROM payments WHERE id = ?').get(input.originalPaymentId) as Record<string, unknown>;
    return { refundPayment: mapPayment(refRow), originalPayment: mapPayment(updatedOrig) };
  });

  return run.immediate();
}

/**
 * Issuance & Redemption State Machine:
 * Requested -> Validated -> Approved (Dual Approval) -> Settlement Evidence Verified -> Posted -> Reconciled
 */
export function createIssuanceOrRedemption(
  actorRole: ActorRole,
  actorId: string,
  kind: 'ISSUANCE' | 'REDEMPTION',
  amountPence: number,
  notes: string
): IssuanceRedemptionRequest {
  if (!['ISSUER', 'ISSUER_SECOND_APPROVER', 'OPERATOR'].includes(actorRole)) {
    throw new LedgerError(403, 'ISSUER_AUTHORITY_REQUIRED', 'Ordinary wallet or merchant credentials cannot initiate issuance or redemption.');
  }
  const amt = assertPositiveIntPence(amountPence);
  const db = getDb();
  const id = uid(kind === 'ISSUANCE' ? 'iss' : 'red');
  const now = new Date().toISOString();

  db.prepare(`
    INSERT INTO issuance_redemption_requests (
      id, kind, state, amount_pence, currency, requested_by, notes, created_at, updated_at
    ) VALUES (?, ?, 'REQUESTED', ?, 'GBP', ?, ?, ?, ?)
  `).run(id, kind, amt, actorId, notes, now, now);

  recordAudit(db, actorRole, actorId, `REQUEST_${kind}`, kind, id, `Requested ${kind} of ${amt}p`);
  return mapIssuance(db.prepare('SELECT * FROM issuance_redemption_requests WHERE id = ?').get(id) as Record<string, unknown>);
}

export function advanceIssuanceOrRedemption(
  actorRole: ActorRole,
  actorId: string,
  id: string,
  action: 'VALIDATE' | 'APPROVE_1' | 'APPROVE_2' | 'VERIFY_SETTLEMENT_AND_POST' | 'RECONCILE' | 'FAIL_EXTERNAL_PAYOUT',
  settlementEvidenceRef?: string
): IssuanceRedemptionRequest {
  if (!['ISSUER', 'ISSUER_SECOND_APPROVER', 'AUDITOR'].includes(actorRole)) {
    throw new LedgerError(403, 'ISSUER_AUTHORITY_REQUIRED', 'Issuance lifecycle restricted to authorised Issuer/Auditor credentials.');
  }

  const db = getDb();
  const run = db.transaction(() => {
    const row = db.prepare('SELECT * FROM issuance_redemption_requests WHERE id = ?').get(id) as Record<string, unknown> | undefined;
    if (!row) throw new LedgerError(404, 'REQUEST_NOT_FOUND', 'Issuance/Redemption request not found.');
    const curState = String(row.state);
    const kind = String(row.kind) as 'ISSUANCE' | 'REDEMPTION';
    const amt = Number(row.amount_pence);
    const now = new Date().toISOString();

    if (action === 'VALIDATE') {
      if (curState !== 'REQUESTED') throw new LedgerError(409, 'INVALID_TRANSITION', `Cannot validate from state ${curState}.`);
      if (kind === 'REDEMPTION') {
        const pool = db.prepare('SELECT available_pence FROM ledger_accounts WHERE id = ?').get('CTRL_SETTLEMENT_POOL') as { available_pence: number };
        if (pool.available_pence < amt) {
          throw new LedgerError(409, 'INSUFFICIENT_SETTLEMENT_POOL', 'Settlement control pool has insufficient funds for redemption.');
        }
      }
      db.prepare(`UPDATE issuance_redemption_requests SET state = 'VALIDATED', validated_by = ?, updated_at = ? WHERE id = ?`).run(actorId, now, id);
    } else if (action === 'APPROVE_1') {
      if (curState !== 'VALIDATED') throw new LedgerError(409, 'INVALID_TRANSITION', `Must be VALIDATED before first approval.`);
      db.prepare(`UPDATE issuance_redemption_requests SET approver1_id = ?, updated_at = ? WHERE id = ?`).run(actorId, now, id);
    } else if (action === 'APPROVE_2') {
      if (curState !== 'VALIDATED' || !row.approver1_id) throw new LedgerError(409, 'INVALID_TRANSITION', `First approval is required before second approval.`);
      if (String(row.approver1_id) === actorId) {
        throw new LedgerError(403, 'DUAL_APPROVAL_REQUIRED', 'Dual control violation: second approver must be a distinct issuer authority.');
      }
      db.prepare(`UPDATE issuance_redemption_requests SET state = 'APPROVED', approver2_id = ?, updated_at = ? WHERE id = ?`).run(actorId, now, id);
    } else if (action === 'VERIFY_SETTLEMENT_AND_POST') {
      if (curState !== 'APPROVED') throw new LedgerError(409, 'INVALID_TRANSITION', `Request must be dual-APPROVED before settlement verification and posting.`);
      const ref = settlementEvidenceRef?.trim();
      if (!ref) throw new LedgerError(400, 'MISSING_SETTLEMENT_EVIDENCE', 'Settlement evidence reference is required.');

      // Duplicate settlement message protection
      const dup = db.prepare('SELECT id FROM issuance_redemption_requests WHERE settlement_evidence_ref = ?').get(ref);
      if (dup) {
        throw new LedgerError(409, 'DUPLICATE_SETTLEMENT_EVIDENCE', `Settlement reference ${ref} already consumed; replay rejected.`);
      }

      let jeId: string;
      if (kind === 'ISSUANCE') {
        jeId = postBalancedEntry(db, {
          txType: 'ISSUANCE',
          reference: `Issuance ${id} (${ref})`,
          idempotencyKey: `iss-post-${id}`,
          legs: [
            { accountId: 'CTRL_ISSUED_SUPPLY', direction: 'DEBIT', amountPence: amt },
            { accountId: 'CTRL_SETTLEMENT_POOL', direction: 'CREDIT', amountPence: amt },
          ],
        });
      } else {
        // Redemption: stage into REDEMPTION_ESCROW first, then retire if external payout succeeds
        const faultFail = (db.prepare('SELECT value FROM system_state WHERE key = ?').get('fault_bank_payout_fail') as { value: string }).value === 'true';
        const escEntryId = postBalancedEntry(db, {
          txType: 'REDEMPTION_STAGE',
          reference: `Redemption escrow stage ${id}`,
          idempotencyKey: `red-stage-${id}`,
          legs: [
            { accountId: 'CTRL_SETTLEMENT_POOL', direction: 'DEBIT', amountPence: amt },
            { accountId: 'CTRL_REDEMPTION_ESCROW', direction: 'CREDIT', amountPence: amt },
          ],
        });

        if (faultFail) {
          db.prepare('UPDATE system_state SET value = ? WHERE key = ?').run('false', 'fault_bank_payout_fail');
          // External payout failed -> reverse escrow back to Settlement Pool; NEVER destroy claim!
          const revId = postBalancedEntry(db, {
            txType: 'REDEMPTION_PAYOUT_REVERSAL',
            reference: `External payout failed; restored ${id}`,
            reversalOfEntryId: escEntryId,
            legs: [
              { accountId: 'CTRL_REDEMPTION_ESCROW', direction: 'DEBIT', amountPence: amt },
              { accountId: 'CTRL_SETTLEMENT_POOL', direction: 'CREDIT', amountPence: amt },
            ],
          });
          db.prepare(`
            UPDATE issuance_redemption_requests
            SET state = 'FAILED_PAYOUT_REVERSED', settlement_evidence_ref = ?, journal_entry_id = ?, reversal_entry_id = ?, updated_at = ?
            WHERE id = ?
          `).run(ref, escEntryId, revId, now, id);
          recordAudit(db, actorRole, actorId, 'REDEMPTION_PAYOUT_FAILED_REVERSED', 'REDEMPTION', id, `External payout failed; funds restored to settlement pool`);
          return mapIssuance(db.prepare('SELECT * FROM issuance_redemption_requests WHERE id = ?').get(id) as Record<string, unknown>);
        }

        jeId = postBalancedEntry(db, {
          txType: 'REDEMPTION_RETIRE',
          reference: `Redemption retired ${id} (${ref})`,
          idempotencyKey: `red-retire-${id}`,
          legs: [
            { accountId: 'CTRL_REDEMPTION_ESCROW', direction: 'DEBIT', amountPence: amt },
            { accountId: 'CTRL_REDEEMED_UNITS', direction: 'CREDIT', amountPence: amt },
          ],
        });
      }

      db.prepare(`
        UPDATE issuance_redemption_requests
        SET state = 'POSTED', settlement_evidence_ref = ?, external_payout_ref = ?, journal_entry_id = ?, updated_at = ?
        WHERE id = ?
      `).run(ref, `EXT-${ref}`, jeId, now, id);
    } else if (action === 'RECONCILE') {
      if (curState !== 'POSTED') throw new LedgerError(409, 'INVALID_TRANSITION', 'Only POSTED requests can be marked RECONCILED.');
      const report = computeReconciliation(db);
      if (!report.invariantSupplyBalanced) {
        throw new LedgerError(500, 'RECONCILIATION_FAILED', 'Cannot reconcile while supply invariant is imbalanced.');
      }
      db.prepare(`UPDATE issuance_redemption_requests SET state = 'RECONCILED', updated_at = ? WHERE id = ?`).run(now, id);
    } else if (action === 'FAIL_EXTERNAL_PAYOUT') {
      if (curState !== 'APPROVED' || kind !== 'REDEMPTION') {
        throw new LedgerError(409, 'INVALID_TRANSITION', 'Simulated payout failure applies to APPROVED redemption requests.');
      }
      db.prepare(`UPDATE issuance_redemption_requests SET state = 'FAILED_PAYOUT_REVERSED', notes = notes || ' [External payout failed prior to retirement; no units destroyed]', updated_at = ? WHERE id = ?`).run(now, id);
    }

    recordAudit(db, actorRole, actorId, `ISSUANCE_${action}`, kind, id, `Action ${action} executed`);
    return mapIssuance(db.prepare('SELECT * FROM issuance_redemption_requests WHERE id = ?').get(id) as Record<string, unknown>);
  });

  return run.immediate();
}

export function mapIssuance(r: Record<string, unknown>): IssuanceRedemptionRequest {
  return {
    id: String(r.id),
    kind: String(r.kind) as 'ISSUANCE' | 'REDEMPTION',
    state: String(r.state) as IssuanceRedemptionRequest['state'],
    amountPence: Number(r.amount_pence),
    currency: 'GBP',
    requestedBy: String(r.requested_by),
    validatedBy: r.validated_by ? String(r.validated_by) : null,
    approver1Id: r.approver1_id ? String(r.approver1_id) : null,
    approver2Id: r.approver2_id ? String(r.approver2_id) : null,
    settlementEvidenceRef: r.settlement_evidence_ref ? String(r.settlement_evidence_ref) : null,
    externalPayoutRef: r.external_payout_ref ? String(r.external_payout_ref) : null,
    journalEntryId: r.journal_entry_id ? String(r.journal_entry_id) : null,
    reversalEntryId: r.reversal_entry_id ? String(r.reversal_entry_id) : null,
    notes: String(r.notes),
    createdAt: String(r.created_at),
    updatedAt: String(r.updated_at),
  };
}

/**
 * Simulated Commercial-Bank Conversion Gateway (1:1 nominal GBP deposit <-> digital pound)
 * Stages: Requested -> External Settlement Evidence -> Core Posting -> Customer Notified -> Reconciled
 */
export function executeConversion(
  actorRole: ActorRole,
  actorId: string,
  input: {
    direction: 'DEPOSIT_TO_CBDC' | 'CBDC_TO_DEPOSIT';
    walletId: string;
    amountPence: number;
    bankAccountMask: string;
    bankSortCode: string;
    idempotencyKey: string;
    simulateExternalFailure?: boolean;
  }
): { conversion: ConversionRequest; idempotentReplay: boolean } {
  const db = getDb();
  const amt = assertPositiveIntPence(input.amountPence);
  const existing = db.prepare('SELECT * FROM conversion_requests WHERE idempotency_key = ?').get(input.idempotencyKey) as Record<string, unknown> | undefined;
  if (existing) {
    return { conversion: mapConversion(existing), idempotentReplay: true };
  }

  const run = db.transaction(() => {
    const insideDup = db.prepare('SELECT * FROM conversion_requests WHERE idempotency_key = ?').get(input.idempotencyKey) as Record<string, unknown> | undefined;
    if (insideDup) return { conversion: mapConversion(insideDup), idempotentReplay: true };

    const acct = db.prepare('SELECT * FROM ledger_accounts WHERE id = ?').get(input.walletId) as Record<string, unknown> | undefined;
    if (!acct) throw new LedgerError(404, 'WALLET_NOT_FOUND', 'Wallet not found.');
    if (actorRole === 'PIP_A' && acct.pip_id !== 'PIP_A') throw new LedgerError(403, 'CROSS_PROVIDER_DENIED', 'Cross-provider conversion denied.');
    if (actorRole === 'PIP_B' && acct.pip_id !== 'PIP_B') throw new LedgerError(403, 'CROSS_PROVIDER_DENIED', 'Cross-provider conversion denied.');

    const convId = uid('conv');
    const now = new Date().toISOString();
    const extRef = `FPS-SIM-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
    const policy = getActivePolicy(db);

    if (input.direction === 'DEPOSIT_TO_CBDC') {
      checkHoldingLimitForPayee(db, input.walletId, amt, policy);
      if (input.simulateExternalFailure) {
        db.prepare(`
          INSERT INTO conversion_requests (
            id, direction, stage, wallet_id, pip_id, bank_account_mask, bank_sort_code,
            amount_pence, external_settlement_ref, journal_entry_id, idempotency_key, failure_reason, created_at, updated_at
          ) VALUES (?, ?, 'FAILED_REVERSED', ?, ?, ?, ?, ?, NULL, NULL, ?, 'Commercial bank debit rejected by simulated gateway; zero CBDC minted.', ?, ?)
        `).run(convId, input.direction, input.walletId, String(acct.pip_id ?? 'CORE'), input.bankAccountMask, input.bankSortCode, amt, input.idempotencyKey, now, now);
        return { conversion: mapConversion(db.prepare('SELECT * FROM conversion_requests WHERE id = ?').get(convId) as Record<string, unknown>), idempotentReplay: false };
      }

      const pool = db.prepare('SELECT available_pence FROM ledger_accounts WHERE id = ?').get('CTRL_SETTLEMENT_POOL') as { available_pence: number };
      if (pool.available_pence < amt) {
        throw new LedgerError(409, 'SETTLEMENT_POOL_DEPLETED', 'Settlement control pool requires additional authorised issuance before converting deposits.');
      }

      const jeId = postBalancedEntry(db, {
        txType: 'CONVERSION_IN',
        reference: `Bank deposit conversion ${extRef} -> ${input.walletId}`,
        idempotencyKey: `conv-in-${input.idempotencyKey}`,
        legs: [
          { accountId: 'CTRL_SETTLEMENT_POOL', direction: 'DEBIT', amountPence: amt },
          { accountId: input.walletId, direction: 'CREDIT', amountPence: amt },
        ],
      });

      db.prepare(`
        INSERT INTO conversion_requests (
          id, direction, stage, wallet_id, pip_id, bank_account_mask, bank_sort_code,
          amount_pence, external_settlement_ref, journal_entry_id, idempotency_key, created_at, updated_at
        ) VALUES (?, ?, 'RECONCILED', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(convId, input.direction, input.walletId, String(acct.pip_id ?? 'CORE'), input.bankAccountMask, input.bankSortCode, amt, extRef, jeId, input.idempotencyKey, now, now);
    } else {
      // CBDC_TO_DEPOSIT: move to pending conversion, check external bank credit; if external fails, reverse cleanly!
      const stageEntryId = postBalancedEntry(db, {
        txType: 'CONVERSION_OUT_STAGE',
        reference: `Conversion out staged ${convId}`,
        legs: [
          { accountId: input.walletId, direction: 'DEBIT', amountPence: amt },
          { accountId: 'CTRL_PENDING_CONVERSION', direction: 'CREDIT', amountPence: amt },
        ],
      });

      if (input.simulateExternalFailure) {
        const revId = postBalancedEntry(db, {
          txType: 'CONVERSION_OUT_REVERSAL',
          reference: `Bank credit failed; restored wallet ${input.walletId}`,
          reversalOfEntryId: stageEntryId,
          legs: [
            { accountId: 'CTRL_PENDING_CONVERSION', direction: 'DEBIT', amountPence: amt },
            { accountId: input.walletId, direction: 'CREDIT', amountPence: amt },
          ],
        });
        db.prepare(`
          INSERT INTO conversion_requests (
            id, direction, stage, wallet_id, pip_id, bank_account_mask, bank_sort_code,
            amount_pence, external_settlement_ref, journal_entry_id, idempotency_key, failure_reason, created_at, updated_at
          ) VALUES (?, ?, 'FAILED_REVERSED', ?, ?, ?, ?, ?, NULL, ?, ?, 'Simulated commercial bank credit failed; wallet balance fully restored.', ?, ?)
        `).run(convId, input.direction, input.walletId, String(acct.pip_id ?? 'CORE'), input.bankAccountMask, input.bankSortCode, amt, revId, input.idempotencyKey, now, now);
        return { conversion: mapConversion(db.prepare('SELECT * FROM conversion_requests WHERE id = ?').get(convId) as Record<string, unknown>), idempotentReplay: false };
      }

      const settleEntryId = postBalancedEntry(db, {
        txType: 'CONVERSION_OUT_SETTLED',
        reference: `Bank credit settled ${extRef}`,
        idempotencyKey: `conv-out-${input.idempotencyKey}`,
        legs: [
          { accountId: 'CTRL_PENDING_CONVERSION', direction: 'DEBIT', amountPence: amt },
          { accountId: 'CTRL_SETTLEMENT_POOL', direction: 'CREDIT', amountPence: amt },
        ],
      });

      db.prepare(`
        INSERT INTO conversion_requests (
          id, direction, stage, wallet_id, pip_id, bank_account_mask, bank_sort_code,
          amount_pence, external_settlement_ref, journal_entry_id, idempotency_key, created_at, updated_at
        ) VALUES (?, ?, 'RECONCILED', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(convId, input.direction, input.walletId, String(acct.pip_id ?? 'CORE'), input.bankAccountMask, input.bankSortCode, amt, extRef, settleEntryId, input.idempotencyKey, now, now);
    }

    recordAudit(db, actorRole, actorId, `CONVERSION_${input.direction}`, 'CONVERSION', convId, `${input.direction} of ${amt}p on ${input.walletId}`);
    return { conversion: mapConversion(db.prepare('SELECT * FROM conversion_requests WHERE id = ?').get(convId) as Record<string, unknown>), idempotentReplay: false };
  });

  return run.immediate();
}

export function mapConversion(r: Record<string, unknown>): ConversionRequest {
  return {
    id: String(r.id),
    direction: String(r.direction) as ConversionRequest['direction'],
    stage: String(r.stage) as ConversionRequest['stage'],
    walletId: String(r.wallet_id),
    pipId: String(r.pip_id),
    bankAccountMask: String(r.bank_account_mask),
    bankSortCode: String(r.bank_sort_code),
    amountPence: Number(r.amount_pence),
    externalSettlementRef: r.external_settlement_ref ? String(r.external_settlement_ref) : null,
    journalEntryId: r.journal_entry_id ? String(r.journal_entry_id) : null,
    idempotencyKey: String(r.idempotency_key),
    failureReason: r.failure_reason ? String(r.failure_reason) : null,
    createdAt: String(r.created_at),
    updatedAt: String(r.updated_at),
  };
}

export async function createDatabaseBackup(actorRole: ActorRole, actorId: string): Promise<{ filename: string; path: string; sizeBytes: number; reconciliation: ReconciliationReport }> {
  if (!['OPERATOR', 'AUDITOR', 'ISSUER'].includes(actorRole)) {
    throw new LedgerError(403, 'FORBIDDEN', 'Only Operators, Auditors, or Issuers may create ledger backups.');
  }
  const db = getDb();
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `sterling_backup_${stamp}.db`;
  const targetPath = path.resolve(BACKUP_DIR, filename);
  await db.backup(targetPath);
  const stat = fs.statSync(targetPath);
  const reconciliation = computeReconciliation(db);
  recordAudit(db, actorRole, actorId, 'CREATE_BACKUP', 'DATABASE', filename, `Created atomic SQLite backup (${stat.size} bytes)`);
  return { filename, path: targetPath, sizeBytes: stat.size, reconciliation };
}

export function restoreDatabaseBackup(actorRole: ActorRole, actorId: string, filename: string): { restoredFrom: string; reconciliation: ReconciliationReport } {
  if (!['OPERATOR', 'ISSUER'].includes(actorRole)) {
    throw new LedgerError(403, 'FORBIDDEN', 'Only Operators or Issuers may restore a database backup.');
  }
  const safeName = path.basename(filename);
  const sourcePath = path.resolve(BACKUP_DIR, safeName);
  if (!fs.existsSync(sourcePath)) {
    throw new LedgerError(404, 'BACKUP_NOT_FOUND', `Backup file ${safeName} not found.`);
  }

  // Validate backup integrity before replacing live DB
  const checkDb = openAndMigrateDb(sourcePath);
  const checkReport = computeReconciliation(checkDb);
  checkDb.close();
  if (!checkReport.invariantSupplyBalanced || !checkReport.invariantDoubleEntryBalanced) {
    throw new LedgerError(422, 'BACKUP_CORRUPTED', 'Backup failed accounting invariant validation; restore aborted.');
  }

  const currentDb = getDb();
  currentDb.close();
  fs.copyFileSync(sourcePath, DB_PATH);
  // Remove stale WAL/SHM files if present from pre-restore state
  for (const suffix of ['-wal', '-shm']) {
    if (fs.existsSync(DB_PATH + suffix)) fs.unlinkSync(DB_PATH + suffix);
  }
  const reopened = resetDbConnection();
  const reconciliation = computeReconciliation(reopened);
  recordAudit(reopened, actorRole, actorId, 'RESTORE_BACKUP', 'DATABASE', safeName, `Restored and verified ledger backup ${safeName}`);
  return { restoredFrom: safeName, reconciliation };
}
