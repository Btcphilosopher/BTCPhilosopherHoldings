import { execFile } from 'child_process';
import crypto from 'crypto';
import express from 'express';
import fs from 'fs';
import path from 'path';
import QRCode from 'qrcode';
import { promisify } from 'util';
import { z } from 'zod';
import { BACKUP_DIR, getDb } from './db.ts';
import {
  advanceIssuanceOrRedemption,
  computeReconciliation,
  createDatabaseBackup,
  createIssuanceOrRedemption,
  createPaymentRequest,
  createWalletAndCustomer,
  executeConversion,
  executePayment,
  getActivePolicy,
  issueRefund,
  LedgerError,
  mapAccount,
  mapConversion,
  mapIssuance,
  mapPayment,
  mapPaymentRequest,
  previewPayment,
  recordAudit,
  restoreDatabaseBackup,
  uid,
} from './ledger.ts';
import { runVerificationSuite } from './tests.ts';
import type { ActorRole } from '../src/types/cbdc.ts';

const execFileAsync = promisify(execFile);

const VALID_ROLES: ActorRole[] = [
  'ISSUER',
  'ISSUER_SECOND_APPROVER',
  'OPERATOR',
  'AUDITOR',
  'PIP_A',
  'PIP_B',
  'MERCHANT',
  'CONSUMER',
];

function getActor(req: express.Request): { role: ActorRole; id: string } {
  const rawRole = String(req.header('X-Actor-Role') || 'OPERATOR').toUpperCase();
  const role = (VALID_ROLES.includes(rawRole as ActorRole) ? rawRole : 'CONSUMER') as ActorRole;
  const id = String(req.header('X-Actor-Id') || 'sandbox_session_user');
  return { role, id };
}

// Simple in-memory sliding-window rate limiter & backpressure guard
const rateWindow = new Map<string, { count: number; resetAt: number }>();

function rateLimitMiddleware(req: express.Request, res: express.Response, next: express.NextFunction): void {
  const db = getDb();
  const rpmRow = db.prepare('SELECT value FROM system_state WHERE key = ?').get('rate_limit_rpm') as { value: string } | undefined;
  const maxRpm = rpmRow ? Number(rpmRow.value) : 600;
  const ip = req.ip || 'local';
  const now = Date.now();
  const entry = rateWindow.get(ip);
  if (!entry || entry.resetAt <= now) {
    rateWindow.set(ip, { count: 1, resetAt: now + 60_000 });
    next();
    return;
  }
  entry.count += 1;
  if (entry.count > maxRpm) {
    res.setHeader('Retry-After', '10');
    res.status(429).json({ code: 'RATE_LIMIT_EXCEEDED', message: `Backpressure active: exceeded ${maxRpm} requests/min.` });
    return;
  }
  next();
}

export function createApiRouter(): express.Router {
  const router = express.Router();
  router.use(rateLimitMiddleware);

  // Health monitoring
  router.get('/health', (_req, res) => {
    const db = getDb();
    const rec = computeReconciliation(db);
    const activeKey = db.prepare('SELECT value FROM system_state WHERE key = ?').get('active_hmac_key_version') as { value: string };
    res.json({
      status: rec.invariantSupplyBalanced && rec.invariantDoubleEntryBalanced ? 'HEALTHY' : 'DEGRADED',
      timestamp: new Date().toISOString(),
      persistence: 'SQLite WAL (synchronous=FULL)',
      activeHmacKeyVersion: activeKey.value,
      invariants: {
        supplyBalanced: rec.invariantSupplyBalanced,
        doubleEntryBalanced: rec.invariantDoubleEntryBalanced,
        discrepancyPence: rec.discrepancyPence,
      },
    });
  });

  // Overview snapshot (Core Ledger plane + separated PIP data for UI workbench)
  router.get('/snapshot', (req, res) => {
    const db = getDb();
    const { role } = getActor(req);
    const accounts = (db.prepare('SELECT * FROM ledger_accounts ORDER BY account_class, id').all() as Array<Record<string, unknown>>).map(mapAccount);
    const payments = (db.prepare('SELECT * FROM payments ORDER BY created_at DESC LIMIT 80').all() as Array<Record<string, unknown>>).map(mapPayment);
    const paymentRequests = (db.prepare('SELECT * FROM payment_requests ORDER BY created_at DESC LIMIT 40').all() as Array<Record<string, unknown>>).map(mapPaymentRequest);
    const issuanceRequests = (db.prepare('SELECT * FROM issuance_redemption_requests ORDER BY created_at DESC LIMIT 40').all() as Array<Record<string, unknown>>).map(mapIssuance);
    const conversions = (db.prepare('SELECT * FROM conversion_requests ORDER BY created_at DESC LIMIT 40').all() as Array<Record<string, unknown>>).map(mapConversion);
    const policy = getActivePolicy(db);
    const policyHistory = db.prepare('SELECT version, effective_at, label, holding_limit_pence, tx_limit_pence, remuneration_enabled, fee_bps FROM policy_versions ORDER BY version DESC').all();
    const reconciliation = computeReconciliation(db);
    const fraudCases = (db.prepare('SELECT * FROM fraud_cases ORDER BY created_at DESC LIMIT 40').all() as Array<Record<string, unknown>>).map((fc) => ({
      id: String(fc.id),
      paymentId: fc.payment_id ? String(fc.payment_id) : null,
      walletId: String(fc.wallet_id),
      signalType: String(fc.signal_type),
      signalSummary: String(fc.signal_summary),
      severity: String(fc.severity),
      status: String(fc.status),
      customerMessage: fc.customer_message ? String(fc.customer_message) : null,
      reviewerId: fc.reviewer_id ? String(fc.reviewer_id) : null,
      resolutionNotes: fc.resolution_notes ? String(fc.resolution_notes) : null,
      createdAt: String(fc.created_at),
      updatedAt: String(fc.updated_at),
    }));
    const auditEvents = (db.prepare('SELECT * FROM audit_events ORDER BY created_at DESC LIMIT 60').all() as Array<Record<string, unknown>>).map((ae) => ({
      id: String(ae.id),
      actorRole: String(ae.actor_role),
      actorId: String(ae.actor_id),
      action: String(ae.action),
      targetType: String(ae.target_type),
      targetId: String(ae.target_id),
      detailsRedacted: String(ae.details_redacted),
      createdAt: String(ae.created_at),
    }));
    const offlineClaims = db.prepare('SELECT * FROM offline_research_claims ORDER BY created_at DESC LIMIT 20').all();

    // Journal entries with postings
    const rawEntries = db.prepare('SELECT * FROM journal_entries ORDER BY created_at DESC LIMIT 40').all() as Array<Record<string, unknown>>;
    const getPostings = db.prepare('SELECT * FROM journal_postings WHERE entry_id = ?');
    const journalEntries = rawEntries.map((e) => ({
      id: String(e.id),
      txType: String(e.tx_type),
      reference: String(e.reference),
      idempotencyKey: e.idempotency_key ? String(e.idempotency_key) : null,
      reversalOfEntryId: e.reversal_of_entry_id ? String(e.reversal_of_entry_id) : null,
      createdAt: String(e.created_at),
      postings: (getPostings.all(String(e.id)) as Array<Record<string, unknown>>).map((p) => ({
        id: String(p.id),
        entryId: String(p.entry_id),
        accountId: String(p.account_id),
        direction: String(p.direction),
        amountPence: Number(p.amount_pence),
      })),
    }));

    // PIP customers (privacy-scoped for workbench inspection)
    const rawCustomers = db.prepare('SELECT * FROM pip_customers ORDER BY pip_id, full_name').all() as Array<Record<string, unknown>>;
    const getDevices = db.prepare('SELECT * FROM pip_devices WHERE customer_id = ?');
    const pipCustomers = rawCustomers.map((c) => ({
      id: String(c.id),
      pipId: String(c.pip_id),
      pipName: String(c.pip_name),
      walletId: String(c.wallet_id),
      fullName: String(c.full_name),
      email: String(c.email),
      syntheticIdentityRef: String(c.synthetic_identity_ref),
      tier: String(c.tier),
      kycStatus: String(c.kyc_status),
      recoveryStatus: String(c.recovery_status),
      accessibilityHighContrast: Boolean(c.accessibility_high_contrast),
      accessibilityLargeText: Boolean(c.accessibility_large_text),
      createdAt: String(c.created_at),
      devices: (getDevices.all(String(c.id)) as Array<Record<string, unknown>>).map((d) => ({
        id: String(d.id),
        deviceLabel: String(d.device_label),
        platform: String(d.platform),
        keyAlias: String(d.key_alias),
        attestationStatus: String(d.attestation_status),
        lastSeenAt: String(d.last_seen_at),
      })),
    }));

    const backups = fs.existsSync(BACKUP_DIR)
      ? fs
          .readdirSync(BACKUP_DIR)
          .filter((f) => f.endsWith('.db'))
          .map((f) => ({ filename: f, sizeBytes: fs.statSync(path.join(BACKUP_DIR, f)).size }))
          .reverse()
      : [];

    const sysRows = db.prepare('SELECT key, value FROM system_state').all() as Array<{ key: string; value: string }>;
    const systemState = Object.fromEntries(sysRows.map((r) => [r.key, r.key.startsWith('hmac_key_') ? '[REDACTED]' : r.value]));

    res.json({
      actorRole: role,
      accounts,
      payments,
      paymentRequests,
      issuanceRequests,
      conversions,
      policy,
      policyHistory,
      reconciliation,
      journalEntries,
      pipCustomers,
      fraudCases,
      auditEvents,
      offlineClaims,
      backups,
      systemState,
    });
  });

  // 1. POST /wallets
  router.post('/wallets', (req, res) => {
    const { role, id } = getActor(req);
    const schema = z.object({
      pipId: z.enum(['PIP_A', 'PIP_B']),
      fullName: z.string().min(2),
      email: z.string().email(),
      syntheticIdentityRef: z.string().min(3),
      tier: z.enum(['TIER_1_STANDARD', 'TIER_2_ENHANCED', 'MERCHANT_VERIFIED']).default('TIER_1_STANDARD'),
      accountClass: z.enum(['WALLET_CUSTOMER', 'WALLET_MERCHANT']).optional(),
      deviceLabel: z.string().optional(),
    });
    const parsed = schema.parse(req.body);
    const out = createWalletAndCustomer(role, id, parsed);
    res.status(201).json(out);
  });

  // 2. GET /wallets/:id/balance
  router.get('/wallets/:id/balance', (req, res) => {
    const db = getDb();
    const { role } = getActor(req);
    const acct = db.prepare('SELECT * FROM ledger_accounts WHERE id = ?').get(req.params.id) as Record<string, unknown> | undefined;
    if (!acct) throw new LedgerError(404, 'WALLET_NOT_FOUND', 'Wallet not found.');
    if ((role === 'PIP_A' && acct.pip_id !== 'PIP_A') || (role === 'PIP_B' && acct.pip_id !== 'PIP_B')) {
      throw new LedgerError(403, 'CROSS_PROVIDER_DENIED', `${role} cannot read balances scoped to ${acct.pip_id}.`);
    }
    res.json({
      walletId: String(acct.id),
      accountCode: String(acct.account_code),
      currency: 'GBP',
      availablePence: Number(acct.available_pence),
      reservedPence: Number(acct.reserved_pence),
      status: String(acct.status),
    });
  });

  // 3. GET /wallets/:id/transactions
  router.get('/wallets/:id/transactions', (req, res) => {
    const db = getDb();
    const { role } = getActor(req);
    const acct = db.prepare('SELECT * FROM ledger_accounts WHERE id = ?').get(req.params.id) as Record<string, unknown> | undefined;
    if (!acct) throw new LedgerError(404, 'WALLET_NOT_FOUND', 'Wallet not found.');
    if ((role === 'PIP_A' && acct.pip_id !== 'PIP_A') || (role === 'PIP_B' && acct.pip_id !== 'PIP_B')) {
      throw new LedgerError(403, 'CROSS_PROVIDER_DENIED', `${role} cannot read transactions scoped to ${acct.pip_id}.`);
    }
    const rows = db
      .prepare('SELECT * FROM payments WHERE payer_wallet_id = ? OR payee_wallet_id = ? ORDER BY created_at DESC LIMIT 50')
      .all(req.params.id, req.params.id) as Array<Record<string, unknown>>;
    res.json({ walletId: req.params.id, transactions: rows.map(mapPayment) });
  });

  // 4. POST /payments/preview
  router.post('/payments/preview', (req, res) => {
    const schema = z.object({
      payerWalletId: z.string(),
      payeeWalletId: z.string(),
      amountPence: z.number().int().positive(),
      paymentRequestId: z.string().nullable().optional(),
      reference: z.string().min(1).default('Digital Pound Transfer'),
    });
    const out = previewPayment(schema.parse(req.body));
    res.json(out);
  });

  // 5. POST /payments
  router.post('/payments', (req, res) => {
    const { role, id } = getActor(req);
    const schema = z.object({
      payerWalletId: z.string(),
      payeeWalletId: z.string(),
      amountPence: z.number().int().positive(),
      paymentReference: z.string().min(1),
      paymentRequestId: z.string().nullable().optional(),
      idempotencyKey: z.string().min(4).optional(),
      nonce: z.string().optional(),
      scheduledFor: z.string().nullable().optional(),
      paymentKind: z.enum(['P2P', 'MERCHANT', 'SCHEDULED']).optional(),
      simulateTimeoutAfterCommit: z.boolean().optional(),
    });
    const parsed = schema.parse(req.body);
    const idempotencyKey = parsed.idempotencyKey || req.header('Idempotency-Key') || '';
    const out = executePayment(role, id, { ...parsed, idempotencyKey });
    res.status(out.idempotentReplay ? 200 : 201).json(out);
  });

  // Query payment by idempotency key (for timeout recovery)
  router.get('/payments', (req, res) => {
    const db = getDb();
    const key = req.query.idempotencyKey ? String(req.query.idempotencyKey) : null;
    if (key) {
      const row = db.prepare('SELECT * FROM payments WHERE idempotency_key = ?').get(key) as Record<string, unknown> | undefined;
      if (!row) throw new LedgerError(404, 'PAYMENT_NOT_FOUND', 'No payment found for that idempotencyKey.');
      res.json(mapPayment(row));
      return;
    }
    const rows = db.prepare('SELECT * FROM payments ORDER BY created_at DESC LIMIT 50').all() as Array<Record<string, unknown>>;
    res.json({ payments: rows.map(mapPayment) });
  });

  // 6. GET /payments/:id
  router.get('/payments/:id', (req, res) => {
    const db = getDb();
    const row = db.prepare('SELECT * FROM payments WHERE id = ?').get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) throw new LedgerError(404, 'PAYMENT_NOT_FOUND', 'Payment not found.');
    res.json(mapPayment(row));
  });

  // Execute scheduled payment manually
  router.post('/payments/:id/execute-scheduled', (req, res) => {
    const db = getDb();
    const { role, id } = getActor(req);
    const row = db.prepare('SELECT * FROM payments WHERE id = ?').get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) throw new LedgerError(404, 'PAYMENT_NOT_FOUND', 'Scheduled payment not found.');
    if (row.state !== 'AUTHORISED' || row.payment_kind !== 'SCHEDULED') {
      throw new LedgerError(409, 'INVALID_STATE', 'Only AUTHORISED scheduled instructions can be executed.');
    }
    const exec = executePayment(role, id, {
      payerWalletId: String(row.payer_wallet_id),
      payeeWalletId: String(row.payee_wallet_id),
      amountPence: Number(row.amount_pence),
      paymentReference: String(row.payment_reference) + ' (Executed Schedule)',
      idempotencyKey: `exec-sched-${row.id}`,
      paymentKind: 'P2P',
    });
    db.prepare(`UPDATE payments SET state = 'FINALISED', final_entry_id = ?, updated_at = ? WHERE id = ?`).run(
      exec.payment.finalEntryId,
      new Date().toISOString(),
      req.params.id
    );
    res.json(exec);
  });

  // 7. POST /payment-requests
  router.post('/payment-requests', (req, res) => {
    const { role, id } = getActor(req);
    const schema = z.object({
      merchantWalletId: z.string(),
      amountPence: z.number().int().positive(),
      reference: z.string().min(1),
      singleUse: z.boolean().optional(),
      ttlSeconds: z.number().int().positive().optional(),
    });
    const pr = createPaymentRequest(role, id, schema.parse(req.body));
    res.status(201).json(pr);
  });

  router.get('/payment-requests/:id/qr', async (req, res) => {
    const db = getDb();
    const row = db.prepare('SELECT * FROM payment_requests WHERE id = ?').get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) throw new LedgerError(404, 'PAYMENT_REQUEST_NOT_FOUND', 'Payment request not found.');
    const payload = JSON.stringify({
      scheme: 'uk.sterling.digital.experimental',
      requestId: row.id,
      merchantWalletId: row.merchant_wallet_id,
      amountPence: row.amount_pence,
      currency: row.currency,
      reference: row.reference,
      expiresAt: row.expires_at,
      signatureHmac: row.signature_hmac,
    });
    const svg = await QRCode.toString(payload, { type: 'svg', margin: 1, color: { dark: '#0F213B', light: '#FAF8F3' } });
    res.json({ payload, svg });
  });

  // 8. POST /conversions
  router.post('/conversions', (req, res) => {
    const { role, id } = getActor(req);
    const schema = z.object({
      direction: z.enum(['DEPOSIT_TO_CBDC', 'CBDC_TO_DEPOSIT']),
      walletId: z.string(),
      amountPence: z.number().int().positive(),
      bankAccountMask: z.string().default('****4421'),
      bankSortCode: z.string().default('20-00-00'),
      idempotencyKey: z.string().min(4).optional(),
      simulateExternalFailure: z.boolean().optional(),
    });
    const parsed = schema.parse(req.body);
    const out = executeConversion(role, id, {
      ...parsed,
      idempotencyKey: parsed.idempotencyKey || req.header('Idempotency-Key') || uid('conv_key'),
    });
    res.status(out.idempotentReplay ? 200 : 201).json(out);
  });

  // 9. POST /refunds
  router.post('/refunds', (req, res) => {
    const { role, id } = getActor(req);
    const schema = z.object({
      originalPaymentId: z.string(),
      refundAmountPence: z.number().int().positive(),
      reason: z.string().min(1),
      idempotencyKey: z.string().min(4).optional(),
    });
    const parsed = schema.parse(req.body);
    const out = issueRefund(role, id, {
      ...parsed,
      idempotencyKey: parsed.idempotencyKey || req.header('Idempotency-Key') || uid('ref_key'),
    });
    res.status(201).json(out);
  });

  // 10. POST /issuer/issuance-requests
  router.post('/issuer/issuance-requests', (req, res) => {
    const { role, id } = getActor(req);
    const schema = z.object({
      amountPence: z.number().int().positive(),
      notes: z.string().default('Authorised experimental issuance tranche'),
    });
    const parsed = schema.parse(req.body);
    const out = createIssuanceOrRedemption(role, id, 'ISSUANCE', parsed.amountPence, parsed.notes);
    res.status(201).json(out);
  });

  // 11. POST /issuer/redemption-requests
  router.post('/issuer/redemption-requests', (req, res) => {
    const { role, id } = getActor(req);
    const schema = z.object({
      amountPence: z.number().int().positive(),
      notes: z.string().default('Experimental unit retirement against external payout'),
    });
    const parsed = schema.parse(req.body);
    const out = createIssuanceOrRedemption(role, id, 'REDEMPTION', parsed.amountPence, parsed.notes);
    res.status(201).json(out);
  });

  router.post('/issuer/requests/:id/transition', (req, res) => {
    const { role, id } = getActor(req);
    const schema = z.object({
      action: z.enum(['VALIDATE', 'APPROVE_1', 'APPROVE_2', 'VERIFY_SETTLEMENT_AND_POST', 'RECONCILE', 'FAIL_EXTERNAL_PAYOUT']),
      settlementEvidenceRef: z.string().optional(),
    });
    const parsed = schema.parse(req.body);
    const out = advanceIssuanceOrRedemption(role, id, req.params.id, parsed.action, parsed.settlementEvidenceRef);
    res.json(out);
  });

  // 12. GET /reconciliation/reports
  router.get('/reconciliation/reports', (req, res) => {
    const db = getDb();
    const { role } = getActor(req);
    if (!['AUDITOR', 'ISSUER', 'ISSUER_SECOND_APPROVER', 'OPERATOR'].includes(role)) {
      throw new LedgerError(403, 'FORBIDDEN', 'Reconciliation reports are restricted to Auditors, Issuers, and Operators.');
    }
    res.json(computeReconciliation(db));
  });

  // Policy versioning
  router.get('/policy', (_req, res) => {
    res.json(getActivePolicy());
  });

  router.post('/policy', (req, res) => {
    const { role, id } = getActor(req);
    if (!['ISSUER', 'OPERATOR'].includes(role)) {
      throw new LedgerError(403, 'FORBIDDEN', 'Only Issuer or Policy Operators may publish a new policy version.');
    }
    const db = getDb();
    const cur = getActivePolicy(db);
    const schema = z.object({
      label: z.string().min(3),
      holdingLimitPence: z.number().int().positive().nullable(),
      txLimitPence: z.number().int().positive().nullable(),
      remunerationEnabled: z.boolean().default(false),
      remunerationRateBps: z.number().int().min(0).max(1000).default(0),
      feeBps: z.number().int().min(0).max(500).default(0),
      recoveryModel: z.enum(['PIP_ASSISTED_WITH_COOLING_OFF', 'MULTI_FACTOR_DEVICE_REBIND']).default(cur.recoveryModel),
    });
    const parsed = schema.parse(req.body);
    const nextVersion = cur.version + 1;
    const now = new Date().toISOString();
    db.prepare(`
      INSERT INTO policy_versions (
        version, effective_at, label, holding_limit_pence, tx_limit_pence,
        remuneration_enabled, remuneration_rate_bps, fee_bps,
        eligible_tiers_json, allowed_funding_sources_json, allowed_merchant_categories_json,
        recovery_model, prototype_assumptions_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      nextVersion,
      now,
      parsed.label,
      parsed.holdingLimitPence,
      parsed.txLimitPence,
      parsed.remunerationEnabled ? 1 : 0,
      parsed.remunerationRateBps,
      parsed.feeBps,
      JSON.stringify(cur.eligibleTiers),
      JSON.stringify(cur.allowedFundingSources),
      JSON.stringify(cur.allowedMerchantCategories),
      parsed.recoveryModel,
      JSON.stringify(cur.prototypeAssumptions)
    );
    recordAudit(db, role, id, 'PUBLISH_POLICY_VERSION', 'POLICY', `v${nextVersion}`, `Published policy v${nextVersion}: ${parsed.label}`);
    res.status(201).json(getActivePolicy(db));
  });

  // PIP Consumer Device, Recovery & Accessibility workflows
  router.post('/pip/customers/:id/devices', (req, res) => {
    const db = getDb();
    const { role, id } = getActor(req);
    const cust = db.prepare('SELECT * FROM pip_customers WHERE id = ?').get(req.params.id) as Record<string, unknown> | undefined;
    if (!cust) throw new LedgerError(404, 'CUSTOMER_NOT_FOUND', 'Customer not found.');
    const action = String(req.body.action || 'REGISTER');
    if (action === 'REVOKE' && req.body.deviceId) {
      db.prepare(`UPDATE pip_devices SET attestation_status = 'REVOKED' WHERE id = ? AND customer_id = ?`).run(String(req.body.deviceId), req.params.id);
      recordAudit(db, role, id, 'REVOKE_DEVICE', 'PIP_DEVICE', String(req.body.deviceId), 'Device attestation revoked in PIP layer');
    } else {
      const devId = uid('dev');
      db.prepare(`INSERT INTO pip_devices (id, customer_id, device_label, platform, key_alias, attestation_status, last_seen_at) VALUES (?, ?, ?, 'ANDROID_COMPOSE_SIM', ?, 'VERIFIED', ?)`).run(
        devId,
        req.params.id,
        String(req.body.deviceLabel || 'Replacement Handset'),
        `ks_${crypto.randomBytes(4).toString('hex')}`,
        new Date().toISOString()
      );
      recordAudit(db, role, id, 'REGISTER_DEVICE', 'PIP_DEVICE', devId, 'Registered new hardware-bound key alias');
    }
    res.json({ ok: true });
  });

  router.post('/pip/customers/:id/recovery', (req, res) => {
    const db = getDb();
    const { role, id } = getActor(req);
    const cust = db.prepare('SELECT * FROM pip_customers WHERE id = ?').get(req.params.id) as Record<string, unknown> | undefined;
    if (!cust) throw new LedgerError(404, 'CUSTOMER_NOT_FOUND', 'Customer not found.');
    const action = String(req.body.action || 'REPORT_LOST_DEVICE');
    if (action === 'REPORT_LOST_DEVICE') {
      db.prepare(`UPDATE pip_customers SET recovery_status = 'LOST_DEVICE_LOCKED' WHERE id = ?`).run(req.params.id);
      db.prepare(`UPDATE ledger_accounts SET status = 'RECOVERY_LOCKED' WHERE id = ?`).run(String(cust.wallet_id));
      db.prepare(`UPDATE pip_devices SET attestation_status = 'REVOKED' WHERE customer_id = ?`).run(req.params.id);
      recordAudit(db, role, id, 'LOST_DEVICE_FREEZE', 'WALLET', String(cust.wallet_id), 'Revoked devices & placed wallet into RECOVERY_LOCKED');
    } else if (action === 'INITIATE_COOLING_OFF') {
      db.prepare(`UPDATE pip_customers SET recovery_status = 'RECOVERY_PENDING_COOLING_OFF' WHERE id = ?`).run(req.params.id);
      recordAudit(db, role, id, 'RECOVERY_COOLING_OFF', 'CUSTOMER', req.params.id, 'Started PIP-assisted recovery cooling-off window');
    } else if (action === 'COMPLETE_RECOVERY') {
      db.prepare(`UPDATE pip_customers SET recovery_status = 'NONE' WHERE id = ?`).run(req.params.id);
      db.prepare(`UPDATE ledger_accounts SET status = 'ACTIVE' WHERE id = ?`).run(String(cust.wallet_id));
      db.prepare(`INSERT INTO pip_devices (id, customer_id, device_label, platform, key_alias, attestation_status, last_seen_at) VALUES (?, ?, 'Recovered Primary Device', 'ANDROID_COMPOSE_SIM', ?, 'VERIFIED', ?)`).run(
        uid('dev'),
        req.params.id,
        `ks_rec_${crypto.randomBytes(4).toString('hex')}`,
        new Date().toISOString()
      );
      recordAudit(db, role, id, 'COMPLETE_ACCOUNT_RECOVERY', 'WALLET', String(cust.wallet_id), 'Completed PIP identity re-verification & activated new device');
    }
    res.json({ ok: true });
  });

  router.post('/pip/customers/:id/accessibility', (req, res) => {
    const db = getDb();
    db.prepare(`UPDATE pip_customers SET accessibility_high_contrast = ?, accessibility_large_text = ? WHERE id = ?`).run(
      req.body.highContrast ? 1 : 0,
      req.body.largeText ? 1 : 0,
      req.params.id
    );
    res.json({ ok: true });
  });

  // Fraud & proportionate case review
  router.post('/fraud-cases/:id/transition', (req, res) => {
    const db = getDb();
    const { role, id } = getActor(req);
    if (!['OPERATOR', 'PIP_A', 'PIP_B', 'AUDITOR'].includes(role)) {
      throw new LedgerError(403, 'FORBIDDEN', 'Unauthorized to review fraud monitoring cases.');
    }
    const schema = z.object({
      status: z.enum(['UNDER_REVIEW', 'CUSTOMER_CONTACTED', 'CLEARED', 'BLOCKED_RESOLVED']),
      customerMessage: z.string().optional(),
      resolutionNotes: z.string().optional(),
    });
    const parsed = schema.parse(req.body);
    const now = new Date().toISOString();
    db.prepare(`
      UPDATE fraud_cases SET status = ?, customer_message = COALESCE(?, customer_message),
      reviewer_id = ?, resolution_notes = COALESCE(?, resolution_notes), updated_at = ?
      WHERE id = ?
    `).run(parsed.status, parsed.customerMessage ?? null, id, parsed.resolutionNotes ?? null, now, req.params.id);
    recordAudit(db, role, id, 'REVIEW_FRAUD_CASE', 'FRAUD_CASE', req.params.id, `Transitioned monitoring signal to ${parsed.status}`);
    res.json({ ok: true });
  });

  // Offline Research Experiment (explicitly isolated)
  router.post('/offline-research/simulate', (req, res) => {
    const db = getDb();
    const { role, id } = getActor(req);
    const schema = z.object({
      senderWalletId: z.string(),
      receiverWalletId: z.string(),
      amountPence: z.number().int().positive(),
      hardwareCounter: z.number().int().positive(),
      secureElementId: z.string().default('SE-TEE-SIM-001'),
    });
    const parsed = schema.parse(req.body);
    const dupCounter = db
      .prepare('SELECT id FROM offline_research_claims WHERE secure_element_id = ? AND hardware_counter = ?')
      .get(parsed.secureElementId, parsed.hardwareCounter);
    const status = dupCounter ? 'DOUBLE_SPEND_DETECTED' : 'QUEUED_UNSETTLED';
    const claimId = uid('off');
    db.prepare(`
      INSERT INTO offline_research_claims (id, sender_wallet_id, receiver_wallet_id, amount_pence, hardware_counter, secure_element_id, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(claimId, parsed.senderWalletId, parsed.receiverWalletId, parsed.amountPence, parsed.hardwareCounter, parsed.secureElementId, status, new Date().toISOString());
    recordAudit(db, role, id, 'OFFLINE_EXPERIMENT_LOG', 'OFFLINE_CLAIM', claimId, `Status=${status}; NOT core-final`);
    res.status(201).json({ id: claimId, status });
  });

  // Operations: Key rotation, fault injection, backup/restore
  router.post('/ops/rotate-key', (req, res) => {
    const db = getDb();
    const { role, id } = getActor(req);
    if (!['OPERATOR', 'ISSUER'].includes(role)) throw new LedgerError(403, 'FORBIDDEN', 'Only Operators or Issuers can rotate signing keys.');
    const cur = (db.prepare('SELECT value FROM system_state WHERE key = ?').get('active_hmac_key_version') as { value: string }).value;
    const nextNum = Number(cur.replace('hmac_key_v', '')) + 1;
    const nextKeyName = `hmac_key_v${nextNum}`;
    db.prepare('INSERT OR REPLACE INTO system_state (key, value) VALUES (?, ?)').run(
      nextKeyName,
      `sterling-research-key-v${nextNum}-${crypto.randomBytes(12).toString('hex')}`
    );
    db.prepare('UPDATE system_state SET value = ? WHERE key = ?').run(nextKeyName, 'active_hmac_key_version');
    recordAudit(db, role, id, 'ROTATE_HMAC_KEY', 'SYSTEM', nextKeyName, `Rotated merchant request signing key to ${nextKeyName}`);
    res.json({ activeHmacKeyVersion: nextKeyName });
  });

  router.post('/ops/fault-injection', (req, res) => {
    const db = getDb();
    const { role, id } = getActor(req);
    if (!['OPERATOR'].includes(role)) throw new LedgerError(403, 'FORBIDDEN', 'Operator role required for fault injection.');
    if (typeof req.body.dropNextPaymentResponse === 'boolean') {
      db.prepare('UPDATE system_state SET value = ? WHERE key = ?').run(String(req.body.dropNextPaymentResponse), 'fault_drop_payment_response');
    }
    if (typeof req.body.failNextBankPayout === 'boolean') {
      db.prepare('UPDATE system_state SET value = ? WHERE key = ?').run(String(req.body.failNextBankPayout), 'fault_bank_payout_fail');
    }
    if (typeof req.body.rateLimitRpm === 'number' && req.body.rateLimitRpm >= 10) {
      db.prepare('UPDATE system_state SET value = ? WHERE key = ?').run(String(Math.floor(req.body.rateLimitRpm)), 'rate_limit_rpm');
    }
    recordAudit(db, role, id, 'UPDATE_FAULT_INJECTION', 'SYSTEM', 'FAULT_CONFIG', 'Updated fault injection / rate-limit configuration');
    res.json({ ok: true });
  });

  router.post('/ops/backups', async (req, res) => {
    const { role, id } = getActor(req);
    const out = await createDatabaseBackup(role, id);
    res.status(201).json(out);
  });

  router.post('/ops/restore', (req, res) => {
    const { role, id } = getActor(req);
    const out = restoreDatabaseBackup(role, id, String(req.body.filename || ''));
    res.json(out);
  });

  // Execute independent Python 3 reconciliation script
  router.post('/ops/run-python-reconcile', async (_req, res) => {
    const scriptPath = path.resolve(process.cwd(), 'platform/python-tools/reconcile.py');
    const { stdout } = await execFileAsync('python3', [scriptPath]);
    res.json(JSON.parse(stdout));
  });

  // Run full 13-case automated verification suite + Python HTTP load benchmark
  router.post('/ops/run-tests-and-benchmark', async (_req, res) => {
    const tests = await runVerificationSuite();
    const benchScript = path.resolve(process.cwd(), 'platform/python-tools/load_test.py');
    const port = process.env.PORT || '3000';
    const { stdout } = await execFileAsync('python3', [benchScript, `http://127.0.0.1:${port}/api`]);
    const benchmark = JSON.parse(stdout);
    res.json({ tests, benchmark });
  });

  // Export settlement CSV for Merchant
  router.get('/merchant/:walletId/settlement-csv', (req, res) => {
    const db = getDb();
    const rows = db
      .prepare('SELECT * FROM payments WHERE payee_wallet_id = ? OR payer_wallet_id = ? ORDER BY created_at DESC')
      .all(req.params.walletId, req.params.walletId) as Array<Record<string, unknown>>;
    const header = 'payment_id,state,kind,payer_wallet,payee_wallet,amount_pence,fee_pence,refunded_pence,reference,created_at\n';
    const csv =
      header +
      rows
        .map((r) =>
          [
            r.id,
            r.state,
            r.payment_kind,
            r.payer_wallet_id,
            r.payee_wallet_id,
            r.amount_pence,
            r.fee_pence,
            r.refunded_pence,
            `"${String(r.payment_reference).replace(/"/g, '""')}"`,
            r.created_at,
          ].join(',')
        )
        .join('\n');
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="settlement-${req.params.walletId}.csv"`);
    res.send(csv);
  });

  // Error handler
  router.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    if (err instanceof LedgerError) {
      res.status(err.status).json({ code: err.code, message: err.message });
      return;
    }
    if (err instanceof z.ZodError) {
      res.status(400).json({ code: 'VALIDATION_ERROR', message: err.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ') });
      return;
    }
    console.error(err);
    res.status(500).json({ code: 'INTERNAL_ERROR', message: err instanceof Error ? err.message : 'Unexpected error' });
  });

  return router;
}
