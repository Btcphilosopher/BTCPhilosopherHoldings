import crypto from 'crypto';
import fs from 'fs';
import {
  advanceIssuanceOrRedemption,
  computeReconciliation,
  createDatabaseBackup,
  createIssuanceOrRedemption,
  createPaymentRequest,
  createWalletAndCustomer,
  executeConversion,
  executePayment,
  getActivePolicy,
  issueRefund,
  LedgerError,
  previewPayment,
  restoreDatabaseBackup,
} from './ledger.ts';
import { getDb } from './db.ts';

export interface TestCaseResult {
  name: string;
  category: string;
  passed: boolean;
  detail: string;
  durationMs: number;
}

export async function runVerificationSuite(): Promise<{
  total: number;
  passed: number;
  failed: number;
  durationMs: number;
  results: TestCaseResult[];
}> {
  const suiteStart = performance.now();
  const results: TestCaseResult[] = [];
  const db = getDb();

  const runCase = async (name: string, category: string, fn: () => Promise<string> | string) => {
    const t0 = performance.now();
    try {
      const detail = await fn();
      results.push({ name, category, passed: true, detail, durationMs: Number((performance.now() - t0).toFixed(2)) });
    } catch (err) {
      results.push({
        name,
        category,
        passed: false,
        detail: err instanceof Error ? err.message : String(err),
        durationMs: Number((performance.now() - t0).toFixed(2)),
      });
    }
  };

  // 1. Monetary conservation & 2. Balanced postings
  await runCase('Monetary conservation & balanced journal postings', 'Core Invariants', () => {
    const rec = computeReconciliation(db);
    if (!rec.invariantSupplyBalanced || !rec.invariantDoubleEntryBalanced || rec.discrepancyPence !== 0) {
      throw new Error(`Imbalance detected: discrepancy=${rec.discrepancyPence}`);
    }
    return `Net supply £${(rec.netSupplyPence / 100).toFixed(2)} === liabilities; debits=credits=${rec.totalDebitsPence}p`;
  });

  // 3. Concurrent / overspend protection
  await runCase('Concurrent-spending & overdraft prevention', 'Ledger Correctness', () => {
    const acct = db.prepare('SELECT available_pence FROM ledger_accounts WHERE id = ?').get('wal_pipa_david') as { available_pence: number };
    const overAmount = acct.available_pence + 500;
    try {
      executePayment('PIP_A', 'test_runner', {
        payerWalletId: 'wal_pipa_david',
        payeeWalletId: 'wal_pipb_claire',
        amountPence: overAmount,
        paymentReference: 'Overspend test',
        idempotencyKey: `test-overspend-${crypto.randomUUID()}`,
      });
      throw new Error('Expected INSUFFICIENT_FUNDS error');
    } catch (e) {
      if (e instanceof LedgerError && e.code === 'INSUFFICIENT_FUNDS') {
        return `Rejected overdraft of ${overAmount}p cleanly (available ${acct.available_pence}p)`;
      }
      throw e;
    }
  });

  // 4. Issuance authority separation & dual control
  await runCase('Issuance authority & dual-approval enforcement', 'Issuance & Security', () => {
    let blockedWallet = false;
    try {
      createIssuanceOrRedemption('PIP_A', 'wallet_user', 'ISSUANCE', 1000, 'Unauthorized test');
    } catch (e) {
      if (e instanceof LedgerError && e.code === 'ISSUER_AUTHORITY_REQUIRED') blockedWallet = true;
    }
    if (!blockedWallet) throw new Error('Ordinary wallet role was allowed to request issuance!');

    const req = createIssuanceOrRedemption('ISSUER', 'issuer_alpha', 'ISSUANCE', 1000, 'Test dual control');
    advanceIssuanceOrRedemption('ISSUER', 'validator_1', req.id, 'VALIDATE');
    advanceIssuanceOrRedemption('ISSUER', 'issuer_alpha', req.id, 'APPROVE_1');

    let blockedSameApprover = false;
    try {
      advanceIssuanceOrRedemption('ISSUER_SECOND_APPROVER', 'issuer_alpha', req.id, 'APPROVE_2');
    } catch (e) {
      if (e instanceof LedgerError && e.code === 'DUAL_APPROVAL_REQUIRED') blockedSameApprover = true;
    }
    if (!blockedSameApprover) throw new Error('Single approver bypassed dual approval!');

    advanceIssuanceOrRedemption('ISSUER_SECOND_APPROVER', 'issuer_beta', req.id, 'APPROVE_2');
    const evRef = `TEST-RTGS-${crypto.randomUUID()}`;
    advanceIssuanceOrRedemption('ISSUER', 'issuer_alpha', req.id, 'VERIFY_SETTLEMENT_AND_POST', evRef);
    const finalReq = advanceIssuanceOrRedemption('AUDITOR', 'auditor_1', req.id, 'RECONCILE');

    return `Blocked wallet role & same-person dual approval; posted & reconciled ${finalReq.id}`;
  });

  // 5. Duplicate settlement evidence rejection
  await runCase('Duplicate settlement message replay protection', 'Issuance & Security', () => {
    const existing = db.prepare('SELECT settlement_evidence_ref FROM issuance_redemption_requests WHERE settlement_evidence_ref IS NOT NULL LIMIT 1').get() as {
      settlement_evidence_ref: string;
    };
    const req = createIssuanceOrRedemption('ISSUER', 'issuer_alpha', 'ISSUANCE', 500, 'Dup settlement test');
    advanceIssuanceOrRedemption('ISSUER', 'validator_1', req.id, 'VALIDATE');
    advanceIssuanceOrRedemption('ISSUER', 'issuer_alpha', req.id, 'APPROVE_1');
    advanceIssuanceOrRedemption('ISSUER_SECOND_APPROVER', 'issuer_beta', req.id, 'APPROVE_2');

    try {
      advanceIssuanceOrRedemption('ISSUER', 'issuer_alpha', req.id, 'VERIFY_SETTLEMENT_AND_POST', existing.settlement_evidence_ref);
      throw new Error('Duplicate settlement evidence was accepted!');
    } catch (e) {
      if (e instanceof LedgerError && e.code === 'DUPLICATE_SETTLEMENT_EVIDENCE') {
        return `Rejected replayed settlement evidence ${existing.settlement_evidence_ref}`;
      }
      throw e;
    }
  });

  // 6. Idempotent payments (including simulated timeout after commit)
  await runCase('Idempotent payment & timeout recovery without double-spend', 'Ledger Correctness', () => {
    const key = `test-idem-${crypto.randomUUID()}`;
    let timedOut = false;
    try {
      executePayment('PIP_A', 'test_runner', {
        payerWalletId: 'wal_pipa_alice',
        payeeWalletId: 'wal_pipa_david',
        amountPence: 100,
        paymentReference: 'Timeout recovery check',
        idempotencyKey: key,
        simulateTimeoutAfterCommit: true,
      });
    } catch (e) {
      if (e instanceof LedgerError && e.code === 'SIMULATED_GATEWAY_TIMEOUT') timedOut = true;
    }
    if (!timedOut) throw new Error('Expected simulated timeout');

    const replay = executePayment('PIP_A', 'test_runner', {
      payerWalletId: 'wal_pipa_alice',
      payeeWalletId: 'wal_pipa_david',
      amountPence: 100,
      paymentReference: 'Timeout recovery check',
      idempotencyKey: key,
    });
    if (!replay.idempotentReplay) throw new Error('Retry did not return idempotentReplay=true');
    return `Safe retry returned original payment ${replay.payment.id} without duplicate debit`;
  });

  // 7. Cross-provider permissions
  await runCase('Cross-provider debit permission boundary', 'Privacy & RBAC', () => {
    try {
      executePayment('PIP_A', 'rogue_pip_a', {
        payerWalletId: 'wal_pipb_claire',
        payeeWalletId: 'wal_pipa_alice',
        amountPence: 50,
        paymentReference: 'Cross-PIP hijack attempt',
        idempotencyKey: `test-xpip-${crypto.randomUUID()}`,
      });
      throw new Error('PIP_A was permitted to debit PIP_B wallet!');
    } catch (e) {
      if (e instanceof LedgerError && e.code === 'CROSS_PROVIDER_DENIED') {
        return 'Blocked PIP_A from initiating debit on PIP_B wallet';
      }
      throw e;
    }
  });

  // 8. Payment-request tampering & single-use enforcement
  await runCase('Merchant payment-request tampering & reuse prevention', 'Merchant Security', () => {
    const pr = createPaymentRequest('MERCHANT', 'merchant_pos', {
      merchantWalletId: 'wal_pipb_merchant_books',
      amountPence: 250,
      reference: 'Tamper check book',
      singleUse: true,
    });
    try {
      previewPayment({
        payerWalletId: 'wal_pipb_claire',
        payeeWalletId: 'wal_pipb_merchant_books',
        amountPence: 100, // tampered amount!
        paymentRequestId: pr.id,
        reference: pr.reference,
      });
      throw new Error('Tampered amount was accepted!');
    } catch (e) {
      if (!(e instanceof LedgerError && e.code === 'REQUEST_TAMPERING_DETECTED')) throw e;
    }

    executePayment('PIP_B', 'claire', {
      payerWalletId: 'wal_pipb_claire',
      payeeWalletId: 'wal_pipb_merchant_books',
      amountPence: 250,
      paymentReference: pr.reference,
      paymentRequestId: pr.id,
      idempotencyKey: `test-pr-pay-${crypto.randomUUID()}`,
    });

    try {
      previewPayment({
        payerWalletId: 'wal_pipa_alice',
        payeeWalletId: 'wal_pipb_merchant_books',
        amountPence: 250,
        paymentRequestId: pr.id,
        reference: pr.reference,
      });
      throw new Error('Single-use request was reused!');
    } catch (e) {
      if (e instanceof LedgerError && e.code === 'PAYMENT_REQUEST_INACTIVE') {
        return `Rejected altered amount and blocked reuse of single-use request ${pr.id}`;
      }
      throw e;
    }
  });

  // 9. Refund limits
  await runCase('Partial refund & cumulative refund limit enforcement', 'Merchant Security', () => {
    const pay = executePayment('PIP_A', 'alice', {
      payerWalletId: 'wal_pipa_alice',
      payeeWalletId: 'wal_pipb_merchant_books',
      amountPence: 400,
      paymentReference: 'Refund cap test',
      idempotencyKey: `test-ref-pay-${crypto.randomUUID()}`,
    }).payment;

    issueRefund('MERCHANT', 'books', {
      originalPaymentId: pay.id,
      refundAmountPence: 150,
      reason: 'Partial refund',
      idempotencyKey: `test-ref-1-${crypto.randomUUID()}`,
    });

    try {
      issueRefund('MERCHANT', 'books', {
        originalPaymentId: pay.id,
        refundAmountPence: 300, // 150 + 300 > 400
        reason: 'Excess refund',
        idempotencyKey: `test-ref-2-${crypto.randomUUID()}`,
      });
      throw new Error('Over-refund was permitted!');
    } catch (e) {
      if (e instanceof LedgerError && e.code === 'REFUND_LIMIT_EXCEEDED') {
        return `Permitted £1.50 partial refund and blocked excess £3.00 refund on £4.00 payment`;
      }
      throw e;
    }
  });

  // 10. Holding limits
  await runCase('Configurable retail holding limit enforcement', 'Policy Enforcement', () => {
    const policy = getActivePolicy(db);
    if (!policy.holdingLimitPence) return 'Holding limit currently disabled in policy';
    try {
      executeConversion('PIP_A', 'alice', {
        direction: 'DEPOSIT_TO_CBDC',
        walletId: 'wal_pipa_alice',
        amountPence: policy.holdingLimitPence + 100,
        bankAccountMask: '****4421',
        bankSortCode: '20-00-00',
        idempotencyKey: `test-hold-${crypto.randomUUID()}`,
      });
      throw new Error('Holding limit breach was allowed!');
    } catch (e) {
      if (e instanceof LedgerError && e.code === 'HOLDING_LIMIT_EXCEEDED') {
        return `Blocked conversion exceeding £${(policy.holdingLimitPence / 100).toFixed(2)} policy v${policy.version} cap`;
      }
      throw e;
    }
  });

  // 11. Failure recovery (external bank payout failure & redemption failure)
  await runCase('External bank failure reversal preserves customer claim', 'Failure Recovery', () => {
    const before = (db.prepare('SELECT available_pence FROM ledger_accounts WHERE id = ?').get('wal_pipa_alice') as { available_pence: number }).available_pence;
    const conv = executeConversion('PIP_A', 'alice', {
      direction: 'CBDC_TO_DEPOSIT',
      walletId: 'wal_pipa_alice',
      amountPence: 200,
      bankAccountMask: '****4421',
      bankSortCode: '20-00-00',
      idempotencyKey: `test-conv-fail-${crypto.randomUUID()}`,
      simulateExternalFailure: true,
    }).conversion;
    const after = (db.prepare('SELECT available_pence FROM ledger_accounts WHERE id = ?').get('wal_pipa_alice') as { available_pence: number }).available_pence;
    if (conv.stage !== 'FAILED_REVERSED' || before !== after) {
      throw new Error(`Claim not preserved: before=${before}, after=${after}, stage=${conv.stage}`);
    }
    return `Simulated commercial-bank failure cleanly reversed; Alice balance preserved at ${after}p`;
  });

  // 12. Privacy boundary check
  await runCase('Core Ledger PII separation check', 'Privacy & RBAC', () => {
    const ledgerCols = (db.prepare('PRAGMA table_info(ledger_accounts)').all() as Array<{ name: string }>).map((c) => c.name);
    const forbidden = ledgerCols.filter((c) => ['full_name', 'email', 'synthetic_identity_ref', 'address'].includes(c));
    if (forbidden.length > 0) throw new Error(`PII columns in core ledger: ${forbidden.join(', ')}`);
    return `Core ledger contains only opaque account codes (${ledgerCols.join(', ')}); PII isolated in PIP tables`;
  });

  // 13. Atomic backup & restore validation
  await runCase('Atomic backup & consistency-verified restore', 'Resilience', async () => {
    const backup = await createDatabaseBackup('OPERATOR', 'test_runner');
    if (!fs.existsSync(backup.path) || !backup.reconciliation.invariantSupplyBalanced) {
      throw new Error('Backup creation or invariant check failed');
    }
    const restored = restoreDatabaseBackup('OPERATOR', 'test_runner', backup.filename);
    if (!restored.reconciliation.invariantSupplyBalanced) {
      throw new Error('Restored database failed invariant check');
    }
    return `Backed up (${backup.sizeBytes} bytes), validated, and restored ${backup.filename} with 0p discrepancy`;
  });

  const passed = results.filter((r) => r.passed).length;
  return {
    total: results.length,
    passed,
    failed: results.length - passed,
    durationMs: Number((performance.now() - suiteStart).toFixed(2)),
    results,
  };
}
