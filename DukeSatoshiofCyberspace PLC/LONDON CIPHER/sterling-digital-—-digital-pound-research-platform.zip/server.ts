import express from 'express';
import fs from 'fs';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { getDb } from './server/db.ts';
import { createApiRouter } from './server/routes.ts';

async function startServer() {
  // Initialize ACID SQLite ledger & seed synthetic entities if empty
  getDb();

  const app = express();
  app.use(express.json({ limit: '1mb' }));

  const apiRouter = createApiRouter();
  app.use('/api', apiRouter);
  // Also expose exact documented OpenAPI contract paths at root for direct API clients
  for (const prefix of [
    '/wallets',
    '/payments',
    '/payment-requests',
    '/conversions',
    '/refunds',
    '/issuer',
    '/reconciliation',
  ]) {
    app.use(prefix, (req, res, next) => {
      req.url = prefix + (req.url === '/' ? '' : req.url);
      apiRouter(req, res, next);
    });
  }

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build output missing.');
      }
    });
  }

  const port = Number(process.env.PORT || 3000);
  app.listen(port, '0.0.0.0', () => {
    console.log(`STERLING DIGITAL research platform listening on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start Sterling Digital server:', err);
  process.exit(1);
});
