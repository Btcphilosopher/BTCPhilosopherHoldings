# STERLING DIGITAL — Threat Model, Architecture Decisions & Sovereign Governance Analysis

## 1. Architecture Decisions (ADRs)

- **ADR-01: Relational Double-Entry Core Ledger over Permissionless DLT**
  - The Bank of England Technology Working Paper notes that a central-bank-operated core does not require Byzantine fault-tolerant consensus. We use serializable ACID transactions (`BEGIN IMMEDIATE` in SQLite; `SERIALIZABLE` / `SELECT ... FOR UPDATE` in PostgreSQL) with integer pence (`BIGINT`), achieving deterministic finality at the exact database commit point.
- **ADR-02: Strict Separation of PIP Identity Plane and Core Ledger Plane**
  - Personal Identifiable Information (`full_name`, `email`, `synthetic_identity_ref`, KYC status, devices) lives strictly in `pip_customers` / `pip_a_identity` / `pip_b_identity`. The Core Ledger operates solely on opaque references (`wal_pipa_*`).
  - **Privacy Limitation Explicitly Documented**: Opaque account identifiers alone do not defeat traffic-analysis correlation at the Core Ledger layer; cryptographic unlinkability (blinded credentials / ZKPs) would be required for production.
- **ADR-03: Two-Stage Payment Execution & Explicit State Machine**
  - Payments transition `DRAFT -> REVIEWED -> AUTHORISED -> SUBMITTED -> FINALISED | REJECTED`. Funds move first to `CTRL_RESERVED_ESCROW` and commit to the payee only upon final validation, preventing partial or phantom credits.
- **ADR-04: Dual-Authority Issuance & Reversal-Safe Redemption**
  - Issuance requires two distinct Issuer Authorities (`approver1_id <> approver2_id`) and a unique `settlement_evidence_ref`. Redemption locks units in `CTRL_REDEMPTION_ESCROW` and only retires them to `CTRL_REDEEMED_UNITS` once external bank payout succeeds—reversing cleanly if payout fails so customer claims are never destroyed.

## 2. STRIDE Threat Model & Mitigations

| Threat | Attack Vector | Mitigation Implemented |
| :--- | :--- | :--- |
| **Spoofing** | Ordinary wallet token attempting `/issuer/issuance-requests` or `PIP_A` debiting `PIP_B` wallet | Role-based authorisation (`X-Actor-Role`) + strict `pip_id` scope verification + HTTP 403 rejection |
| **Tampering** | Consumer alters merchant QR amount or destination wallet | Server-generated HMAC-SHA256 signature over `id\|merchantWalletId\|amountPence\|currency\|reference\|expiresAt`, re-verified prior to posting |
| **Repudiation** | Disputed issuance or operator balance edit | Zero direct balance-edit endpoint; immutable `journal_entries` / `journal_postings` + append-only `audit_events` |
| **Information Disclosure** | Core Ledger or Auditor observing customer PII | Core Ledger schema excludes PII columns; Auditor sees redacted details; PIP-A cannot query PIP-B customers |
| **Denial of Service** | Flood of payment previews/submissions or lost gateway responses | Sliding-window rate limiting (`429 Retry-After`), strict idempotency keys (`Idempotency-Key`), and deterministic outcome queries (`GET /payments?idempotencyKey=...`) |
| **Elevation of Privilege** | Single rogue issuer minting supply; ML fraud scorer altering balances | Dual-control enforcement (`approver1 != approver2`); fraud signals kept strictly advisory in `fraud_cases` with zero balance-mutation authority |

## 3. Institutional Authority, Legislation & Assurance Required for a Real CBDC

1. **Primary Legislation & Parliamentary Mandate**: Statutory amendment to the Bank of England Act / Currency Acts establishing legal tender status, statutory privacy protections barring Bank/Government access to personal data, and explicit prohibition of state-directed programmable spending restrictions.
2. **Regulatory Perimeter (FCA / PRA)**: Licensing regime, capital adequacy, safeguarding rules, operational resilience (PS21/3), and Consumer Duty oversight for Payment Interface Providers (PIPs).
3. **External Infrastructure Integrations**: ISO 20022 integration with renewed Bank of England RTGS/CHAPS for wholesale settlement, Pay.UK / Faster Payments for commercial-bank deposit interoperability, and UK digital identity trust frameworks.
4. **Independent Assurance**: Formal cryptographic proofs, NCSC/CPA-grade penetration testing, continuous real-time reconciliation audits, and multi-region active-active disaster recovery across physically separated UK availability zones (local Docker containers do NOT constitute high availability).

## 4. Sovereign Cybersecurity Protocols & Cryptographic Standards

- **Transport & Mutual Authentication**: TLS 1.3 with Mutual TLS (mTLS) using ECDSA P-256/P-384 or Ed25519 certificates issued by a UK sovereign / regulated PKI between PIPs and Core Ledger.
- **Hardware Security & Key Custody**: FIPS 140-3 Level 3 Hardware Security Modules (HSMs) for Bank of England issuance signing keys, threshold multi-party ceremony (M-of-N) for root issuance authority, and automated key rotation with versioned key identifiers.
- **Consumer Device Security**: Hardware-backed Android Keystore (StrongBox / TEE) and Apple Secure Enclave binding wallet authorisation keys with FIDO2 / WebAuthn / OS biometric gates.
- **Algorithmic Agility & Post-Quantum Readiness**: Migration path toward NIST FIPS 203 (ML-KEM) for key encapsulation and FIPS 204 (ML-DSA) for long-lived audit and issuance signatures, alongside NCSC-aligned Zero Trust Network Architecture (ZTNA).
