#!/usr/bin/env python3
"""
STERLING DIGITAL — Independent Python Ledger Reconciliation & Invariant Verifier
Connects read-only to SQLite ledger database (or PostgreSQL via DSN) and verifies
all monetary conservation and double-entry accounting invariants in integer pence.
"""
import json
import os
import sqlite3
import sys
import time


def verify_sqlite_ledger(db_path: str) -> dict:
    started = time.perf_counter()
    if not os.path.exists(db_path):
        return {"ok": False, "error": f"Database not found at {db_path}"}

    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    accounts = cur.execute(
        "SELECT id, account_code, account_class, normal_side, available_pence, reserved_pence FROM ledger_accounts"
    ).fetchall()

    acct_map = {row["id"]: dict(row) for row in accounts}
    negative_balances = [
        a["id"] for a in acct_map.values() if a["available_pence"] < 0 or a["reserved_pence"] < 0
    ]

    wallet_available_sum = sum(
        a["available_pence"]
        for a in acct_map.values()
        if a["account_class"] in ("WALLET_CUSTOMER", "WALLET_MERCHANT")
    )
    wallet_reserved_sum = sum(
        a["reserved_pence"]
        for a in acct_map.values()
        if a["account_class"] in ("WALLET_CUSTOMER", "WALLET_MERCHANT")
    )

    issued = acct_map.get("CTRL_ISSUED_SUPPLY", {}).get("available_pence", 0)
    redeemed = acct_map.get("CTRL_REDEEMED_UNITS", {}).get("available_pence", 0)
    net_supply = issued - redeemed

    settlement_pool = acct_map.get("CTRL_SETTLEMENT_POOL", {}).get("available_pence", 0)
    pending_conv = acct_map.get("CTRL_PENDING_CONVERSION", {}).get("available_pence", 0)
    reserved_escrow = acct_map.get("CTRL_RESERVED_ESCROW", {}).get("available_pence", 0)
    redemption_escrow = acct_map.get("CTRL_REDEMPTION_ESCROW", {}).get("available_pence", 0)
    fee_control = acct_map.get("CTRL_FEE_COLLECTED", {}).get("available_pence", 0)

    total_liabilities = (
        settlement_pool + pending_conv + reserved_escrow + redemption_escrow + fee_control + wallet_available_sum
    )
    supply_discrepancy = net_supply - total_liabilities

    # Verify every journal entry independently sums DEBIT == CREDIT
    unbalanced_entries = cur.execute(
        """
        SELECT entry_id,
               SUM(CASE WHEN direction = 'DEBIT' THEN amount_pence ELSE 0 END) AS debits,
               SUM(CASE WHEN direction = 'CREDIT' THEN amount_pence ELSE 0 END) AS credits
        FROM journal_postings
        GROUP BY entry_id
        HAVING debits != credits
        """
    ).fetchall()

    totals = cur.execute(
        """
        SELECT COALESCE(SUM(CASE WHEN direction = 'DEBIT' THEN amount_pence ELSE 0 END), 0) AS debits,
               COALESCE(SUM(CASE WHEN direction = 'CREDIT' THEN amount_pence ELSE 0 END), 0) AS credits,
               COUNT(DISTINCT entry_id) AS entry_count,
               COUNT(*) AS posting_count
        FROM journal_postings
        """
    ).fetchone()

    # Verify Core Ledger privacy boundary: ensure ledger_accounts / journal_entries contain no PII columns
    ledger_cols = [
        r["name"] for r in cur.execute("PRAGMA table_info(ledger_accounts)").fetchall()
    ]
    pii_leak_cols = [c for c in ledger_cols if c in ("full_name", "email", "address", "ni_number")]

    conn.close()
    elapsed_ms = round((time.perf_counter() - started) * 1000, 3)

    ok = (
        len(negative_balances) == 0
        and supply_discrepancy == 0
        and len(unbalanced_entries) == 0
        and totals["debits"] == totals["credits"]
        and reserved_escrow == wallet_reserved_sum
        and len(pii_leak_cols) == 0
    )

    return {
        "ok": ok,
        "engine": "Python 3 Independent SQLite Verifier",
        "elapsedMs": elapsed_ms,
        "issuedPence": issued,
        "redeemedPence": redeemed,
        "netSupplyPence": net_supply,
        "settlementPoolPence": settlement_pool,
        "walletAvailableSumPence": wallet_available_sum,
        "walletReservedSumPence": wallet_reserved_sum,
        "totalDebitsPence": totals["debits"],
        "totalCreditsPence": totals["credits"],
        "journalEntriesVerified": totals["entry_count"],
        "journalPostingsVerified": totals["posting_count"],
        "supplyDiscrepancyPence": supply_discrepancy,
        "unbalancedEntryCount": len(unbalanced_entries),
        "negativeBalanceAccounts": negative_balances,
        "coreLedgerPiiColumns": pii_leak_cols,
    }


if __name__ == "__main__":
    default_db = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../data/sterling_ledger.db"))
    target = sys.argv[1] if len(sys.argv) > 1 else default_db
    report = verify_sqlite_ledger(target)
    print(json.dumps(report, indent=2))
    sys.exit(0 if report.get("ok") else 1)
