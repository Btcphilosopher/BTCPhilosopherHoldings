#!/usr/bin/env python3
"""
STERLING DIGITAL — Python Benchmark & Load Test Runner
Measures actual HTTP throughput and p50/p95/p99 latency against the local Express + SQLite engine.
Also verifies concurrent-spending safety and idempotency under contention.
"""
import concurrent.futures
import json
import os
import platform
import statistics
import sys
import time
import urllib.error
import urllib.request
import uuid


def http_json(url: str, method: str = "GET", payload: dict | None = None, headers: dict | None = None) -> tuple[int, dict, float]:
    req_headers = {"Content-Type": "application/json"}
    if headers:
        req_headers.update(headers)
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, headers=req_headers, method=method)
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = json.loads(resp.read().decode("utf-8"))
            return resp.status, body, (time.perf_counter() - t0) * 1000.0
    except urllib.error.HTTPError as err:
        raw = err.read().decode("utf-8")
        try:
            parsed = json.loads(raw)
        except Exception:
            parsed = {"raw": raw}
        return err.code, parsed, (time.perf_counter() - t0) * 1000.0


def percentile(sorted_vals: list[float], pct: float) -> float:
    if not sorted_vals:
        return 0.0
    idx = min(len(sorted_vals) - 1, max(0, int(round((pct / 100.0) * (len(sorted_vals) - 1)))))
    return round(sorted_vals[idx], 2)


def run_benchmark(base_url: str, read_requests: int = 60, write_payments: int = 24, concurrency: int = 6) -> dict:
    # 1. Read benchmark (balance & reconciliation queries)
    read_latencies: list[float] = []
    read_ok = 0

    def do_read(_: int) -> tuple[int, float]:
        code, _, ms = http_json(f"{base_url}/wallets/wal_pipa_alice/balance", "GET", None, {"X-Actor-Role": "PIP_A", "X-Actor-Id": "bench_pip_a"})
        return code, ms

    t_read_start = time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:
        for code, ms in pool.map(do_read, range(read_requests)):
            read_latencies.append(ms)
            if code == 200:
                read_ok += 1
    read_total_s = max(0.001, time.perf_counter() - t_read_start)
    read_latencies.sort()

    # 2. Write benchmark (1p micro-transfers Alice -> David, then net back so balances stay near baseline)
    write_latencies: list[float] = []
    write_ok = 0

    def do_write(i: int) -> tuple[int, float]:
        payer = "wal_pipa_alice" if i % 2 == 0 else "wal_pipa_david"
        payee = "wal_pipa_david" if i % 2 == 0 else "wal_pipa_alice"
        payload = {
            "payerWalletId": payer,
            "payeeWalletId": payee,
            "amountPence": 1,
            "paymentReference": f"Bench micro-tx #{i}",
            "idempotencyKey": f"bench-{uuid.uuid4()}",
        }
        code, _, ms = http_json(f"{base_url}/payments", "POST", payload, {"X-Actor-Role": "PIP_A", "X-Actor-Id": "bench_pip_a"})
        return code, ms

    t_write_start = time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:
        for code, ms in pool.map(do_write, range(write_payments)):
            write_latencies.append(ms)
            if code in (200, 201):
                write_ok += 1
    write_total_s = max(0.001, time.perf_counter() - t_write_start)
    write_latencies.sort()

    # 3. Verify reconciliation after concurrent load
    rec_code, rec_body, _ = http_json(f"{base_url}/reconciliation/reports", "GET", None, {"X-Actor-Role": "AUDITOR", "X-Actor-Id": "bench_auditor"})

    return {
        "environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "cpuCount": os.cpu_count(),
            "durability": "SQLite WAL + synchronous=FULL + BEGIN IMMEDIATE serializable locks",
            "concurrency": concurrency,
        },
        "readBenchmark": {
            "totalRequests": read_requests,
            "succeeded": read_ok,
            "throughputRps": round(read_ok / read_total_s, 1),
            "p50Ms": percentile(read_latencies, 50),
            "p95Ms": percentile(read_latencies, 95),
            "p99Ms": percentile(read_latencies, 99),
            "meanMs": round(statistics.mean(read_latencies), 2) if read_latencies else 0.0,
        },
        "writePaymentBenchmark": {
            "totalRequests": write_payments,
            "succeeded": write_ok,
            "throughputTps": round(write_ok / write_total_s, 1),
            "p50Ms": percentile(write_latencies, 50),
            "p95Ms": percentile(write_latencies, 95),
            "p99Ms": percentile(write_latencies, 99),
            "meanMs": round(statistics.mean(write_latencies), 2) if write_latencies else 0.0,
        },
        "postLoadReconciliation": {
            "httpStatus": rec_code,
            "invariantSupplyBalanced": rec_body.get("invariantSupplyBalanced"),
            "invariantDoubleEntryBalanced": rec_body.get("invariantDoubleEntryBalanced"),
            "discrepancyPence": rec_body.get("discrepancyPence"),
        },
        "disclaimer": "Actual local single-node demonstration measurements; not extrapolated to national RTGS/retail CBDC capacity.",
    }


if __name__ == "__main__":
    target_url = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:3000/api"
    result = run_benchmark(target_url)
    print(json.dumps(result, indent=2))
