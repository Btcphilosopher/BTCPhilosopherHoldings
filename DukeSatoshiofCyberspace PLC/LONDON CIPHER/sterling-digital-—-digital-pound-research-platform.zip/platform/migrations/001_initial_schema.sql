-- STERLING DIGITAL — PostgreSQL 16 Transactional Core Ledger & Separated PIP Schemas
-- Integer pence (BIGINT) throughout; zero floating-point monetary types.

CREATE SCHEMA IF NOT EXISTS core_ledger;
CREATE SCHEMA IF NOT EXISTS pip_a_identity;
CREATE SCHEMA IF NOT EXISTS pip_b_identity;
CREATE SCHEMA IF NOT EXISTS audit_plane;

CREATE TABLE core_ledger.ledger_accounts (
    id              TEXT PRIMARY KEY,
    account_code    TEXT NOT NULL UNIQUE,
    account_class   TEXT NOT NULL CHECK (account_class IN (
                        'ISSUED_SUPPLY','REDEEMED_UNITS','SETTLEMENT_CONTROL',
                        'PENDING_CONVERSION','RESERVED_ESCROW','REDEMPTION_ESCROW',
                        'FEE_CONTROL','WALLET_CUSTOMER','WALLET_MERCHANT'
                    )),
    normal_side     TEXT NOT NULL CHECK (normal_side IN ('DEBIT','CREDIT')),
    pip_id          TEXT,
    available_pence BIGINT NOT NULL DEFAULT 0 CHECK (available_pence >= 0),
    reserved_pence  BIGINT NOT NULL DEFAULT 0 CHECK (reserved_pence >= 0),
    status          TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','FROZEN','RECOVERY_LOCKED')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE core_ledger.journal_entries (
    id                    TEXT PRIMARY KEY,
    tx_type               TEXT NOT NULL,
    reference             TEXT NOT NULL,
    idempotency_key       TEXT UNIQUE,
    reversal_of_entry_id  TEXT REFERENCES core_ledger.journal_entries(id),
    created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE core_ledger.journal_postings (
    id            TEXT PRIMARY KEY,
    entry_id      TEXT NOT NULL REFERENCES core_ledger.journal_entries(id),
    account_id    TEXT NOT NULL REFERENCES core_ledger.ledger_accounts(id),
    direction     TEXT NOT NULL CHECK (direction IN ('DEBIT','CREDIT')),
    amount_pence  BIGINT NOT NULL CHECK (amount_pence > 0)
);

CREATE INDEX idx_postings_entry ON core_ledger.journal_postings(entry_id);
CREATE INDEX idx_postings_account ON core_ledger.journal_postings(account_id);

CREATE TABLE core_ledger.payments (
    id                    TEXT PRIMARY KEY,
    state                 TEXT NOT NULL CHECK (state IN ('DRAFT','REVIEWED','AUTHORISED','SUBMITTED','FINALISED','REJECTED','REVERSED')),
    payment_kind          TEXT NOT NULL CHECK (payment_kind IN ('P2P','MERCHANT','SCHEDULED')),
    payer_wallet_id       TEXT NOT NULL REFERENCES core_ledger.ledger_accounts(id),
    payee_wallet_id       TEXT NOT NULL REFERENCES core_ledger.ledger_accounts(id),
    payer_pip_id          TEXT NOT NULL,
    payee_pip_id          TEXT NOT NULL,
    amount_pence          BIGINT NOT NULL CHECK (amount_pence > 0),
    fee_pence             BIGINT NOT NULL DEFAULT 0 CHECK (fee_pence >= 0),
    currency              CHAR(3) NOT NULL DEFAULT 'GBP' CHECK (currency = 'GBP'),
    payment_reference     TEXT NOT NULL,
    payment_request_id    TEXT,
    idempotency_key       TEXT NOT NULL UNIQUE,
    authorisation_hash    TEXT NOT NULL,
    expires_at            TIMESTAMPTZ NOT NULL,
    scheduled_for         TIMESTAMPTZ,
    reservation_entry_id  TEXT REFERENCES core_ledger.journal_entries(id),
    final_entry_id        TEXT REFERENCES core_ledger.journal_entries(id),
    refunded_pence        BIGINT NOT NULL DEFAULT 0 CHECK (refunded_pence >= 0),
    created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE core_ledger.issuance_redemption_requests (
    id                      TEXT PRIMARY KEY,
    kind                    TEXT NOT NULL CHECK (kind IN ('ISSUANCE','REDEMPTION')),
    state                   TEXT NOT NULL CHECK (state IN (
                                'REQUESTED','VALIDATED','APPROVED','SETTLEMENT_EVIDENCE_VERIFIED',
                                'POSTED','RECONCILED','FAILED_PAYOUT_REVERSED','REJECTED'
                            )),
    amount_pence            BIGINT NOT NULL CHECK (amount_pence > 0),
    currency                CHAR(3) NOT NULL DEFAULT 'GBP' CHECK (currency = 'GBP'),
    requested_by            TEXT NOT NULL,
    validated_by            TEXT,
    approver1_id            TEXT,
    approver2_id            TEXT CHECK (approver2_id IS NULL OR approver2_id <> approver1_id),
    settlement_evidence_ref TEXT UNIQUE,
    external_payout_ref     TEXT UNIQUE,
    journal_entry_id        TEXT REFERENCES core_ledger.journal_entries(id),
    reversal_entry_id       TEXT REFERENCES core_ledger.journal_entries(id),
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Isolated PIP Identity Tables (Core Ledger queries cannot join PII without explicit PIP boundary)
CREATE TABLE pip_a_identity.customers (
    id                      TEXT PRIMARY KEY,
    wallet_id               TEXT NOT NULL UNIQUE,
    full_name               TEXT NOT NULL,
    email                   TEXT NOT NULL,
    synthetic_identity_ref  TEXT NOT NULL,
    identity_hash           TEXT NOT NULL,
    tier                    TEXT NOT NULL,
    recovery_status         TEXT NOT NULL DEFAULT 'NONE',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE pip_b_identity.customers (
    id                      TEXT PRIMARY KEY,
    wallet_id               TEXT NOT NULL UNIQUE,
    full_name               TEXT NOT NULL,
    email                   TEXT NOT NULL,
    synthetic_identity_ref  TEXT NOT NULL,
    identity_hash           TEXT NOT NULL,
    tier                    TEXT NOT NULL,
    recovery_status         TEXT NOT NULL DEFAULT 'NONE',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE audit_plane.audit_events (
    id                TEXT PRIMARY KEY,
    actor_role        TEXT NOT NULL,
    actor_id          TEXT NOT NULL,
    action            TEXT NOT NULL,
    target_type       TEXT NOT NULL,
    target_id         TEXT NOT NULL,
    details_redacted  TEXT NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
