package uk.digital.sterling.wallet

import android.content.Context
import android.nfc.NdefMessage
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * STERLING DIGITAL — Kotlin + Jetpack Compose Android Consumer Wallet
 *
 * Security & Architecture Boundaries:
 * - Uses Android Keystore / EncryptedSharedPreferences (Jetpack Security) for device-bound tokens.
 * - NFC adapter exchanges ONLY signed payment-request references (NDEF URI/JSON payload);
 *   authorisation and ledger settlement occur strictly over authenticated TLS PIP endpoints.
 * - Integer pence (Long) throughout; no floating-point monetary arithmetic.
 */
object InstitutionalPalette {
    val Navy = Color(0xFF0F213B)
    val Ivory = Color(0xFFFAF8F3)
    val Limestone = Color(0xFFF2EFE7)
    val MutedBrass = Color(0xFF9A7B3E)
    val SlateInk = Color(0xFF1C2536)
    val Hairline = Color(0xFFDDD7C8)
}

data class WalletUiState(
    val pipName: String = "Thameside Digital Wallet (PIP-A)",
    val walletId: String = "wal_pipa_alice",
    val availablePence: Long = 45000L,
    val reservedPence: Long = 0L,
    val nfcBoundaryNote: String = "NFC exchanges payment-request reference only; never settles locally.",
    val recentReferences: List<String> = listOf("Order #BK-2041 · £18.50", "P2P Transfer · £25.00")
)

interface NfcPaymentReferenceBoundary {
    fun parseNdefPaymentRequest(message: NdefMessage): String?
    fun simulateTapReference(requestId: String): String
}

class AndroidNfcBoundaryImpl : NfcPaymentReferenceBoundary {
    override fun parseNdefPaymentRequest(message: NdefMessage): String? {
        val record = message.records.firstOrNull() ?: return null
        val payload = String(record.payload, Charsets.UTF_8)
        return if (payload.contains("uk.sterling.digital.experimental")) payload else null
    }

    override fun simulateTapReference(requestId: String): String {
        return """{"scheme":"uk.sterling.digital.experimental","requestId":"$requestId"}"""
    }
}

class SecureCredentialStore(context: Context) {
    // Production target: androidx.security.crypto.EncryptedSharedPreferences + MasterKey.AES256_GCM
    private val prefs = context.getSharedPreferences("sterling_pip_keystore_ref", Context.MODE_PRIVATE)
    fun storeOpaqueSessionToken(token: String) = prefs.edit().putString("pip_session_token", token).apply()
    fun readOpaqueSessionToken(): String? = prefs.getString("pip_session_token", null)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = InstitutionalPalette.Navy,
                    secondary = InstitutionalPalette.MutedBrass,
                    background = InstitutionalPalette.Ivory,
                    surface = Color.White,
                    onBackground = InstitutionalPalette.SlateInk
                )
            ) {
                SterlingWalletScreen(WalletUiState())
            }
        }
    }
}

@Composable
fun SterlingWalletScreen(state: WalletUiState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(InstitutionalPalette.Ivory)
    ) {
        // Persistent Experimental Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstitutionalPalette.Navy)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Text(
                text = "EXPERIMENTAL — NO REAL MONEY · ${state.pipName}",
                color = InstitutionalPalette.Ivory,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 0.8.sp
            )
        }

        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(
                text = "Digital Pound Balance",
                fontSize = 13.sp,
                color = InstitutionalPalette.MutedBrass,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = formatPence(state.availablePence),
                fontSize = 36.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                color = InstitutionalPalette.Navy
            )
            Text(
                text = "Opaque Ledger Ref: ${state.walletId} · Reserved: ${formatPence(state.reservedPence)}",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                color = InstitutionalPalette.SlateInk
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = { /* Navigate to Authorise P2P / QR flow */ },
                    colors = ButtonDefaults.buttonColors(containerColor = InstitutionalPalette.Navy)
                ) {
                    Text("Send / Pay QR")
                }
                OutlinedButton(onClick = { /* Trigger NfcPaymentReferenceBoundary */ }) {
                    Text("NFC Tap Boundary")
                }
            }

            Divider(color = InstitutionalPalette.Hairline)

            Text(
                text = "Recent Activity",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = InstitutionalPalette.Navy
            )
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.recentReferences) { item ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White)
                            .border(1.dp, InstitutionalPalette.Hairline)
                            .padding(12.dp)
                    ) {
                        Text(item, fontSize = 13.sp, color = InstitutionalPalette.SlateInk)
                    }
                }
            }
        }
    }
}

private fun formatPence(pence: Long): String {
    val pounds = pence / 100
    val rem = kotlin.math.abs(pence % 100)
    return "£$pounds.${rem.toString().padStart(2, '0')}"
}
