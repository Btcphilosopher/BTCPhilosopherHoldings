use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};
use thiserror::Error;

/// Strict integer-pence GBP representation (zero floats).
pub type Pence = i64;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum NormalSide {
    Debit,
    Credit,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Direction {
    Debit,
    Credit,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum AccountClass {
    IssuedSupply,
    RedeemedUnits,
    SettlementControl,
    PendingConversion,
    ReservedEscrow,
    RedemptionEscrow,
    FeeControl,
    WalletCustomer,
    WalletMerchant,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LedgerAccount {
    pub id: String,
    pub account_class: AccountClass,
    pub normal_side: NormalSide,
    pub pip_id: Option<String>,
    pub available_pence: Pence,
    pub reserved_pence: Pence,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PostingLeg {
    pub account_id: String,
    pub direction: Direction,
    pub amount_pence: Pence,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JournalEntry {
    pub id: String,
    pub tx_type: String,
    pub idempotency_key: Option<String>,
    pub legs: Vec<PostingLeg>,
}

#[derive(Debug, Error, PartialEq, Eq)]
pub enum LedgerError {
    #[error("amount must be strictly positive integer pence")]
    NonPositiveAmount,
    #[error("journal entry unbalanced: debits={debits} credits={credits}")]
    UnbalancedEntry { debits: Pence, credits: Pence },
    #[error("account not found: {0}")]
    AccountNotFound(String),
    #[error("insufficient available funds in {0}")]
    InsufficientFunds(String),
    #[error("duplicate settlement evidence reference: {0}")]
    DuplicateSettlementEvidence(String),
    #[error("dual approval violation: second approver cannot match first")]
    DualApprovalViolation,
    #[error("cross-provider debit denied for {0}")]
    CrossProviderDenied(String),
}

pub struct CoreLedgerEngine {
    pub accounts: HashMap<String, LedgerAccount>,
    pub entries: Vec<JournalEntry>,
    pub idempotency_index: HashMap<String, String>,
    pub consumed_settlement_refs: HashSet<String>,
}

impl CoreLedgerEngine {
    pub fn new() -> Self {
        let mut accounts = HashMap::new();
        for (id, class, side) in [
            ("CTRL_ISSUED_SUPPLY", AccountClass::IssuedSupply, NormalSide::Debit),
            ("CTRL_REDEEMED_UNITS", AccountClass::RedeemedUnits, NormalSide::Debit),
            ("CTRL_SETTLEMENT_POOL", AccountClass::SettlementControl, NormalSide::Credit),
            ("CTRL_PENDING_CONVERSION", AccountClass::PendingConversion, NormalSide::Credit),
            ("CTRL_RESERVED_ESCROW", AccountClass::ReservedEscrow, NormalSide::Credit),
            ("CTRL_REDEMPTION_ESCROW", AccountClass::RedemptionEscrow, NormalSide::Credit),
            ("CTRL_FEE_COLLECTED", AccountClass::FeeControl, NormalSide::Credit),
        ] {
            accounts.insert(
                id.to_string(),
                LedgerAccount {
                    id: id.to_string(),
                    account_class: class,
                    normal_side: side,
                    pip_id: None,
                    available_pence: 0,
                    reserved_pence: 0,
                },
            );
        }
        Self {
            accounts,
            entries: Vec::new(),
            idempotency_index: HashMap::new(),
            consumed_settlement_refs: HashSet::new(),
        }
    }

    pub fn post_balanced_entry(
        &mut self,
        tx_type: &str,
        idempotency_key: Option<String>,
        legs: Vec<PostingLeg>,
    ) -> Result<String, LedgerError> {
        if let Some(ref key) = idempotency_key {
            if let Some(existing_id) = self.idempotency_index.get(key) {
                return Ok(existing_id.clone());
            }
        }

        let (mut debits, mut credits) = (0_i64, 0_i64);
        for leg in &legs {
            if leg.amount_pence <= 0 {
                return Err(LedgerError::NonPositiveAmount);
            }
            match leg.direction {
                Direction::Debit => debits = debits.checked_add(leg.amount_pence).ok_or(LedgerError::NonPositiveAmount)?,
                Direction::Credit => credits = credits.checked_add(leg.amount_pence).ok_or(LedgerError::NonPositiveAmount)?,
            }
        }
        if debits != credits {
            return Err(LedgerError::UnbalancedEntry { debits, credits });
        }

        // Validate all balances before mutating any state (atomic all-or-nothing)
        let mut pending_balances: HashMap<String, Pence> = HashMap::new();
        for leg in &legs {
            let acct = self
                .accounts
                .get(&leg.account_id)
                .ok_or_else(|| LedgerError::AccountNotFound(leg.account_id.clone()))?;
            let current = pending_balances.get(&leg.account_id).copied().unwrap_or(acct.available_pence);
            let delta = match (acct.normal_side, leg.direction) {
                (NormalSide::Debit, Direction::Debit) | (NormalSide::Credit, Direction::Credit) => leg.amount_pence,
                _ => -leg.amount_pence,
            };
            let next = current + delta;
            if next < 0 {
                return Err(LedgerError::InsufficientFunds(leg.account_id.clone()));
            }
            pending_balances.insert(leg.account_id.clone(), next);
        }

        for (acct_id, bal) in pending_balances {
            if let Some(acct) = self.accounts.get_mut(&acct_id) {
                acct.available_pence = bal;
            }
        }

        let entry_id = format!("je_{}", self.entries.len() + 1);
        if let Some(key) = idempotency_key.clone() {
            self.idempotency_index.insert(key, entry_id.clone());
        }
        self.entries.push(JournalEntry {
            id: entry_id.clone(),
            tx_type: tx_type.to_string(),
            idempotency_key,
            legs,
        });
        Ok(entry_id)
    }

    pub fn verify_supply_invariant(&self) -> Pence {
        let issued = self.accounts["CTRL_ISSUED_SUPPLY"].available_pence;
        let redeemed = self.accounts["CTRL_REDEEMED_UNITS"].available_pence;
        let net_supply = issued - redeemed;

        let liabilities: Pence = self
            .accounts
            .values()
            .filter(|a| !matches!(a.account_class, AccountClass::IssuedSupply | AccountClass::RedeemedUnits))
            .map(|a| a.available_pence)
            .sum();

        net_supply - liabilities
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn proves_supply_conservation_and_idempotency() {
        let mut engine = CoreLedgerEngine::new();
        engine.accounts.insert(
            "wal_a".into(),
            LedgerAccount {
                id: "wal_a".into(),
                account_class: AccountClass::WalletCustomer,
                normal_side: NormalSide::Credit,
                pip_id: Some("PIP_A".into()),
                available_pence: 0,
                reserved_pence: 0,
            },
        );
        engine
            .post_balanced_entry(
                "ISSUANCE",
                Some("iss-1".into()),
                vec![
                    PostingLeg { account_id: "CTRL_ISSUED_SUPPLY".into(), direction: Direction::Debit, amount_pence: 10_000 },
                    PostingLeg { account_id: "CTRL_SETTLEMENT_POOL".into(), direction: Direction::Credit, amount_pence: 10_000 },
                ],
            )
            .unwrap();
        let e1 = engine
            .post_balanced_entry(
                "CONVERSION_IN",
                Some("conv-1".into()),
                vec![
                    PostingLeg { account_id: "CTRL_SETTLEMENT_POOL".into(), direction: Direction::Debit, amount_pence: 2_500 },
                    PostingLeg { account_id: "wal_a".into(), direction: Direction::Credit, amount_pence: 2_500 },
                ],
            )
            .unwrap();
        let e2 = engine
            .post_balanced_entry(
                "CONVERSION_IN",
                Some("conv-1".into()),
                vec![
                    PostingLeg { account_id: "CTRL_SETTLEMENT_POOL".into(), direction: Direction::Debit, amount_pence: 2_500 },
                    PostingLeg { account_id: "wal_a".into(), direction: Direction::Credit, amount_pence: 2_500 },
                ],
            )
            .unwrap();
        assert_eq!(e1, e2);
        assert_eq!(engine.accounts["wal_a"].available_pence, 2_500);
        assert_eq!(engine.verify_supply_invariant(), 0);
    }
}
