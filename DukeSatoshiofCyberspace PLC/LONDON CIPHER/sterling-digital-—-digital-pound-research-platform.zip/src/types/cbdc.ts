export type CurrencyCode = 'GBP';

export type AccountClass =
  | 'ISSUED_SUPPLY'
  | 'REDEEMED_UNITS'
  | 'SETTLEMENT_CONTROL'
  | 'PENDING_CONVERSION'
  | 'RESERVED_ESCROW'
  | 'REDEMPTION_ESCROW'
  | 'FEE_CONTROL'
  | 'WALLET_CUSTOMER'
  | 'WALLET_MERCHANT';

export type NormalSide = 'DEBIT' | 'CREDIT';

export type ActorRole =
  | 'ISSUER'
  | 'ISSUER_SECOND_APPROVER'
  | 'OPERATOR'
  | 'AUDITOR'
  | 'PIP_A'
  | 'PIP_B'
  | 'MERCHANT'
  | 'CONSUMER';

export type PaymentState =
  | 'DRAFT'
  | 'REVIEWED'
  | 'AUTHORISED'
  | 'SUBMITTED'
  | 'FINALISED'
  | 'REJECTED'
  | 'REVERSED';

export type IssuanceState =
  | 'REQUESTED'
  | 'VALIDATED'
  | 'APPROVED'
  | 'SETTLEMENT_EVIDENCE_VERIFIED'
  | 'POSTED'
  | 'RECONCILED'
  | 'FAILED_PAYOUT_REVERSED'
  | 'REJECTED';

export type ConversionStage =
  | 'REQUESTED'
  | 'EXTERNAL_SETTLEMENT_VERIFIED'
  | 'CORE_POSTED'
  | 'CUSTOMER_NOTIFIED'
  | 'RECONCILED'
  | 'FAILED_REVERSED';

export interface PolicyConfig {
  version: number;
  effectiveAt: string;
  label: string;
  holdingLimitPence: number | null;
  txLimitPence: number | null;
  remunerationEnabled: boolean;
  remunerationRateBps: number;
  feeBps: number;
  eligibleTiers: string[];
  allowedFundingSources: string[];
  allowedMerchantCategories: string[];
  recoveryModel: 'PIP_ASSISTED_WITH_COOLING_OFF' | 'MULTI_FACTOR_DEVICE_REBIND';
  prototypeAssumptions: Record<string, string>;
}

export interface LedgerAccount {
  id: string;
  accountCode: string;
  accountClass: AccountClass;
  normalSide: NormalSide;
  pipId: string | null;
  availablePence: number;
  reservedPence: number;
  status: 'ACTIVE' | 'FROZEN' | 'RECOVERY_LOCKED';
  createdAt: string;
}

export interface JournalPosting {
  id: string;
  entryId: string;
  accountId: string;
  direction: 'DEBIT' | 'CREDIT';
  amountPence: number;
}

export interface JournalEntry {
  id: string;
  txType: string;
  reference: string;
  idempotencyKey: string | null;
  reversalOfEntryId: string | null;
  createdAt: string;
  postings: JournalPosting[];
}

export interface PaymentRecord {
  id: string;
  state: PaymentState;
  paymentKind: 'P2P' | 'MERCHANT' | 'SCHEDULED';
  payerWalletId: string;
  payeeWalletId: string;
  payerPipId: string;
  payeePipId: string;
  amountPence: number;
  feePence: number;
  currency: CurrencyCode;
  paymentReference: string;
  paymentRequestId: string | null;
  idempotencyKey: string;
  authorisationHash: string;
  expiresAt: string;
  scheduledFor: string | null;
  reservationEntryId: string | null;
  finalEntryId: string | null;
  rejectionReason: string | null;
  refundedPence: number;
  createdAt: string;
  updatedAt: string;
}

export interface MerchantPaymentRequest {
  id: string;
  merchantWalletId: string;
  merchantName: string;
  merchantCategory: string;
  amountPence: number;
  currency: CurrencyCode;
  reference: string;
  singleUse: boolean;
  status: 'ACTIVE' | 'USED' | 'EXPIRED' | 'CANCELLED';
  signatureHmac: string;
  expiresAt: string;
  paidPaymentId: string | null;
  createdAt: string;
}

export interface IssuanceRedemptionRequest {
  id: string;
  kind: 'ISSUANCE' | 'REDEMPTION';
  state: IssuanceState;
  amountPence: number;
  currency: CurrencyCode;
  requestedBy: string;
  validatedBy: string | null;
  approver1Id: string | null;
  approver2Id: string | null;
  settlementEvidenceRef: string | null;
  externalPayoutRef: string | null;
  journalEntryId: string | null;
  reversalEntryId: string | null;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface ConversionRequest {
  id: string;
  direction: 'DEPOSIT_TO_CBDC' | 'CBDC_TO_DEPOSIT';
  stage: ConversionStage;
  walletId: string;
  pipId: string;
  bankAccountMask: string;
  bankSortCode: string;
  amountPence: number;
  externalSettlementRef: string | null;
  journalEntryId: string | null;
  idempotencyKey: string;
  failureReason: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface PipDevice {
  id: string;
  deviceLabel: string;
  platform: 'ANDROID_COMPOSE_SIM' | 'WEB_PASSKEY_SIM';
  keyAlias: string;
  attestationStatus: 'VERIFIED' | 'REVOKED';
  lastSeenAt: string;
}

export interface PipCustomerRecord {
  id: string;
  pipId: 'PIP_A' | 'PIP_B';
  pipName: string;
  walletId: string;
  fullName: string;
  email: string;
  syntheticIdentityRef: string;
  tier: 'TIER_1_STANDARD' | 'TIER_2_ENHANCED' | 'MERCHANT_VERIFIED';
  kycStatus: 'VERIFIED_SYNTHETIC' | 'PENDING_REVIEW';
  recoveryStatus: 'NONE' | 'LOST_DEVICE_LOCKED' | 'RECOVERY_PENDING_COOLING_OFF';
  accessibilityHighContrast: boolean;
  accessibilityLargeText: boolean;
  devices: PipDevice[];
  createdAt: string;
}

export interface FraudCase {
  id: string;
  paymentId: string | null;
  walletId: string;
  signalType: string;
  signalSummary: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH';
  status: 'SIGNAL_RECORDED' | 'UNDER_REVIEW' | 'CUSTOMER_CONTACTED' | 'CLEARED' | 'BLOCKED_RESOLVED';
  customerMessage: string | null;
  reviewerId: string | null;
  resolutionNotes: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface AuditEvent {
  id: string;
  actorRole: string;
  actorId: string;
  action: string;
  targetType: string;
  targetId: string;
  detailsRedacted: string;
  createdAt: string;
}

export interface ReconciliationReport {
  generatedAt: string;
  issuedTotalPence: number;
  redeemedTotalPence: number;
  netSupplyPence: number;
  settlementPoolPence: number;
  pendingConversionPence: number;
  reservedEscrowPence: number;
  redemptionEscrowPence: number;
  feeControlPence: number;
  walletAvailableSumPence: number;
  walletReservedSumPence: number;
  totalDebitsPence: number;
  totalCreditsPence: number;
  invariantSupplyBalanced: boolean;
  invariantDoubleEntryBalanced: boolean;
  discrepancyPence: number;
  alerts: string[];
}

export interface DesignRegisterEntry {
  id: string;
  topic: string;
  category:
    | 'PUBLISHED_PROPOSAL'
    | 'UNRESOLVED_POLICY'
    | 'PROTOTYPE_ASSUMPTION'
    | 'IMPLEMENTED_FUNCTIONALITY'
    | 'FUTURE_INTEGRATION';
  summary: string;
  rationale: string;
  sourceTitle: string;
  sourceUrl: string;
  retrievedAt: string;
}
