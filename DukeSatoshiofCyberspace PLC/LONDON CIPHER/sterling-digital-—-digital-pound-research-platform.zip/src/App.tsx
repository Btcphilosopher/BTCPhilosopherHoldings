import { useCallback, useEffect, useState } from 'react';
import { BriefingRegisterView } from './components/BriefingRegisterView';
import { ConsumerWalletView } from './components/ConsumerWalletView';
import { LedgerIssuerView } from './components/LedgerIssuerView';
import { MerchantPortalView } from './components/MerchantPortalView';
import { OperationsTestsView } from './components/OperationsTestsView';
import { apiFetch, type PlatformSnapshot } from './lib/api';

type WorkspaceTab = 'briefing' | 'wallets' | 'merchant' | 'ledger' | 'operations';

const NAV_ITEMS: Array<{ id: WorkspaceTab; label: string }> = [
  { id: 'briefing', label: 'Briefing & Register' },
  { id: 'wallets', label: 'Consumer Wallets' },
  { id: 'merchant', label: 'Merchant Portal' },
  { id: 'ledger', label: 'Ledger & Issuer' },
  { id: 'operations', label: 'Operations & Tests' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('briefing');
  const [snapshot, setSnapshot] = useState<PlatformSnapshot | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadSnapshot = useCallback(async () => {
    try {
      const data = await apiFetch<PlatformSnapshot>('/snapshot', { role: 'OPERATOR' });
      setSnapshot(data);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to reach Sterling Digital ledger service.');
    }
  }, []);

  useEffect(() => {
    loadSnapshot();
  }, [loadSnapshot]);

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F3] text-[#1C2536]">
      {/* Persistent Experimental Notice */}
      <div className="bg-[#0F213B] text-[#FAF8F3] px-6 py-2 text-center text-xs font-medium tracking-wide border-b border-[#9A7B3E]/40">
        EXPERIMENTAL — NO REAL MONEY · SYNTHETIC IDENTITIES &amp; SIMULATED STERLING ONLY
      </div>

      {/* 3-Zone Top Bar Contract */}
      <header className="bg-white border-b border-[#DDD7C8]">
        <div className="max-w-[1360px] mx-auto px-6 py-4 flex items-center justify-between gap-8">
          <a
            href="#briefing"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('briefing');
            }}
            className="font-display text-xl font-semibold tracking-tight text-[#0F213B] whitespace-nowrap shrink-0"
          >
            Sterling Digital
          </a>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-[#4B5563]">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`whitespace-nowrap shrink-0 transition-colors pb-0.5 cursor-pointer ${
                  activeTab === item.id
                    ? 'text-[#0F213B] border-b-2 border-[#9A7B3E]'
                    : 'hover:text-[#0F213B]'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('operations')}
              className="px-4 py-2 text-xs font-medium bg-[#0F213B] text-[#FAF8F3] hover:bg-[#193257] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Guided Demo
            </button>
          </div>
        </div>

        {/* Mobile navigation strip */}
        <div className="md:hidden border-t border-[#DDD7C8] px-4 py-2 flex items-center gap-4 overflow-x-auto text-xs font-medium">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                activeTab === item.id ? 'text-[#0F213B] underline underline-offset-4' : 'text-[#4B5563]'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-[1360px] mx-auto px-6 py-8">
        {error && (
          <div className="mb-6 p-4 bg-[#FEF2F2] border border-[#FECACA] text-[#991B1B] text-sm flex items-center justify-between">
            <span>{error}</span>
            <button
              type="button"
              onClick={loadSnapshot}
              className="px-3 py-1 bg-white border border-[#991B1B] text-xs font-medium cursor-pointer"
            >
              Retry Connection
            </button>
          </div>
        )}

        {!snapshot ? (
          <div className="space-y-4">
            <div className="h-48 bg-white border border-[#DDD7C8] animate-pulse" />
            <div className="h-24 bg-white border border-[#DDD7C8] animate-pulse" />
          </div>
        ) : (
          <>
            {activeTab === 'briefing' && (
              <BriefingRegisterView snapshot={snapshot} onNavigate={setActiveTab} />
            )}
            {activeTab === 'wallets' && (
              <ConsumerWalletView snapshot={snapshot} onRefresh={loadSnapshot} />
            )}
            {activeTab === 'merchant' && (
              <MerchantPortalView snapshot={snapshot} onRefresh={loadSnapshot} />
            )}
            {activeTab === 'ledger' && (
              <LedgerIssuerView snapshot={snapshot} onRefresh={loadSnapshot} />
            )}
            {activeTab === 'operations' && (
              <OperationsTestsView snapshot={snapshot} onRefresh={loadSnapshot} />
            )}
          </>
        )}
      </main>

      {/* Quiet Institutional Footer */}
      <footer className="border-t border-[#DDD7C8] bg-white px-6 py-5 text-xs text-[#6E6758]">
        <div className="max-w-[1360px] mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <span>
            Sterling Digital · Experimental Retail CBDC Research Sandbox · Integer-Pence GBP Ledger
          </span>
          <span>
            Grounded in Bank of England &amp; HM Treasury Digital Pound Design Phase Documentation
          </span>
        </div>
      </footer>
    </div>
  );
}
