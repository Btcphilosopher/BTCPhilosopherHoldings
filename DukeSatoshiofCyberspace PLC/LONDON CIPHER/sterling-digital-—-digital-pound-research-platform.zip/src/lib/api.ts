import type {
  ActorRole,
  AuditEvent,
  ConversionRequest,
  FraudCase,
  IssuanceRedemptionRequest,
  JournalEntry,
  LedgerAccount,
  MerchantPaymentRequest,
  PaymentRecord,
  PipCustomerRecord,
  PolicyConfig,
  ReconciliationReport,
} from '../types/cbdc';

export interface PlatformSnapshot {
  actorRole: ActorRole;
  accounts: LedgerAccount[];
  payments: PaymentRecord[];
  paymentRequests: MerchantPaymentRequest[];
  issuanceRequests: IssuanceRedemptionRequest[];
  conversions: ConversionRequest[];
  policy: PolicyConfig;
  policyHistory: Array<{
    version: number;
    effective_at: string;
    label: string;
    holding_limit_pence: number | null;
    tx_limit_pence: number | null;
    remuneration_enabled: number;
    fee_bps: number;
  }>;
  reconciliation: ReconciliationReport;
  journalEntries: JournalEntry[];
  pipCustomers: PipCustomerRecord[];
  fraudCases: FraudCase[];
  auditEvents: AuditEvent[];
  offlineClaims: Array<{
    id: string;
    sender_wallet_id: string;
    receiver_wallet_id: string;
    amount_pence: number;
    hardware_counter: number;
    secure_element_id: string;
    status: string;
    created_at: string;
  }>;
  backups: Array<{ filename: string; sizeBytes: number }>;
  systemState: Record<string, string>;
}

export function formatGBP(pence: number): string {
  const sign = pence < 0 ? '-' : '';
  const abs = Math.abs(pence);
  const pounds = Math.floor(abs / 100);
  const rem = abs % 100;
  return `${sign}£${pounds.toLocaleString('en-GB')}.${String(rem).padStart(2, '0')}`;
}

export function parsePoundsToPence(input: string): number {
  const cleaned = input.trim().replace(/[£,\s]/g, '');
  if (!/^\d+(\.\d{1,2})?$/.test(cleaned)) {
    throw new Error('Enter a valid GBP amount up to 2 decimal places (e.g. 12.50).');
  }
  const [whole, frac = ''] = cleaned.split('.');
  return Number(whole) * 100 + Number(frac.padEnd(2, '0'));
}

export async function apiFetch<T>(
  path: string,
  options: {
    method?: string;
    body?: unknown;
    role?: ActorRole;
    actorId?: string;
    idempotencyKey?: string;
  } = {}
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'X-Actor-Role': options.role ?? 'OPERATOR',
    'X-Actor-Id': options.actorId ?? 'workbench_ui',
  };
  if (options.idempotencyKey) {
    headers['Idempotency-Key'] = options.idempotencyKey;
  }

  const res = await fetch(`/api${path}`, {
    method: options.method ?? 'GET',
    headers,
    body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
  });

  const text = await res.text();
  let data: unknown = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { message: text };
  }

  if (!res.ok) {
    const errObj = data as { code?: string; message?: string };
    const err = new Error(errObj.message || `HTTP ${res.status}`) as Error & { code?: string; status?: number };
    err.code = errObj.code || `HTTP_${res.status}`;
    err.status = res.status;
    throw err;
  }

  return data as T;
}
