import { useState } from 'react';
import { Nfc, QrCode, RefreshCw, ShieldAlert, Smartphone, ArrowUpRight, ArrowDownLeft, Accessibility } from 'lucide-react';
import { apiFetch, formatGBP, parsePoundsToPence, type PlatformSnapshot } from '../lib/api';
import type { ActorRole, PaymentRecord, PipCustomerRecord } from '../types/cbdc';

interface Props {
  snapshot: PlatformSnapshot;
  onRefresh: () => Promise<void>;
}

type WalletTab = 'send' | 'qr_nfc' | 'convert' | 'devices' | 'offline';

export function ConsumerWalletView({ snapshot, onRefresh }: Props) {
  const consumerCustomers = snapshot.pipCustomers.filter((c) => c.tier !== 'MERCHANT_VERIFIED');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(consumerCustomers[0]?.id ?? '');
  const [tab, setTab] = useState<WalletTab>('send');
  const [notice, setNotice] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  // Onboard new synthetic customer modal/inline state
  const [showOnboard, setShowOnboard] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPip, setNewPip] = useState<'PIP_A' | 'PIP_B'>('PIP_A');

  // Send & Schedule payment state (Draft -> Reviewed -> Authorised -> Submitted)
  const [payeeWalletId, setPayeeWalletId] = useState<string>(
    snapshot.accounts.find((a) => a.id === 'wal_pipb_claire')?.id ?? ''
  );
  const [sendAmountGbp, setSendAmountGbp] = useState('12.50');
  const [sendRef, setSendRef] = useState('Shared dinner split');
  const [isScheduled, setIsScheduled] = useState(false);
  const [scheduledFor, setScheduledFor] = useState(new Date(Date.now() + 3600_000).toISOString().slice(0, 16));
  const [simulateTimeout, setSimulateTimeout] = useState(false);
  const [pendingIdempotencyKey, setPendingIdempotencyKey] = useState<string | null>(null);
  const [previewData, setPreviewData] = useState<{
    valid: boolean;
    amountPence: number;
    feePence: number;
    netPayeePence: number;
    authorisationPayloadHash: string;
    warnings: string[];
  } | null>(null);

  // QR / NFC Pay state
  const [qrPayloadText, setQrPayloadText] = useState('');
  const [nfcSimulatedRef, setNfcSimulatedRef] = useState<string | null>(null);

  // Conversion In / Out state
  const [convDirection, setConvDirection] = useState<'DEPOSIT_TO_CBDC' | 'CBDC_TO_DEPOSIT'>('DEPOSIT_TO_CBDC');
  const [convAmountGbp, setConvAmountGbp] = useState('50.00');
  const [convSimulateFail, setConvSimulateFail] = useState(false);

  // Offline research experiment state
  const [offlineCounter, setOfflineCounter] = useState('1');
  const [offlineAmountGbp, setOfflineAmountGbp] = useState('5.00');

  const customer: PipCustomerRecord | undefined =
    consumerCustomers.find((c) => c.id === selectedCustomerId) ?? consumerCustomers[0];
  const account = snapshot.accounts.find((a) => a.id === customer?.walletId);

  const actorRole: ActorRole = customer?.pipId === 'PIP_B' ? 'PIP_B' : 'PIP_A';
  const walletPayments = snapshot.payments.filter(
    (p) => p.payerWalletId === customer?.walletId || p.payeeWalletId === customer?.walletId
  );

  const allPayeeTargets = snapshot.pipCustomers.filter((c) => c.walletId !== customer?.walletId);

  const handleOnboard = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setNotice(null);
    try {
      const ref = `SYN-UK-${Math.floor(10000 + Math.random() * 89999)}${newPip === 'PIP_A' ? 'A' : 'B'}`;
      const res = await apiFetch<{ wallet: { id: string }; customerId: string }>('/wallets', {
        method: 'POST',
        role: newPip,
        actorId: `onboard_${newPip.toLowerCase()}`,
        body: {
          pipId: newPip,
          fullName: `${newName.trim()} (Synthetic)`,
          email: newEmail.trim(),
          syntheticIdentityRef: ref,
          tier: 'TIER_1_STANDARD',
        },
      });
      await onRefresh();
      setSelectedCustomerId(res.customerId);
      setShowOnboard(false);
      setNewName('');
      setNewEmail('');
      setNotice({ kind: 'ok', text: `Onboarded synthetic wallet ${res.wallet.id} under ${newPip}.` });
    } catch (err) {
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'Onboarding failed' });
    } finally {
      setBusy(false);
    }
  };

  const handlePreview = async () => {
    if (!customer) return;
    setBusy(true);
    setNotice(null);
    try {
      const amountPence = parsePoundsToPence(sendAmountGbp);
      const res = await apiFetch<NonNullable<typeof previewData>>('/payments/preview', {
        method: 'POST',
        role: actorRole,
        actorId: customer.id,
        body: {
          payerWalletId: customer.walletId,
          payeeWalletId,
          amountPence,
          reference: sendRef,
        },
      });
      setPreviewData(res);
      setPendingIdempotencyKey(`pay-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);
    } catch (err) {
      setPreviewData(null);
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'Preview failed' });
    } finally {
      setBusy(false);
    }
  };

  const handleAuthoriseAndSubmit = async (overrideKey?: string) => {
    if (!customer) return;
    setBusy(true);
    setNotice(null);
    const idempotencyKey = overrideKey ?? pendingIdempotencyKey ?? `pay-${Date.now()}`;
    setPendingIdempotencyKey(idempotencyKey);
    try {
      const amountPence = parsePoundsToPence(sendAmountGbp);
      const res = await apiFetch<{ payment: PaymentRecord; idempotentReplay: boolean }>('/payments', {
        method: 'POST',
        role: actorRole,
        actorId: customer.id,
        idempotencyKey,
        body: {
          payerWalletId: customer.walletId,
          payeeWalletId,
          amountPence,
          paymentReference: sendRef,
          idempotencyKey,
          paymentKind: isScheduled ? 'SCHEDULED' : 'P2P',
          scheduledFor: isScheduled ? new Date(scheduledFor).toISOString() : null,
          simulateTimeoutAfterCommit: !overrideKey && simulateTimeout,
        },
      });
      await onRefresh();
      setPreviewData(null);
      setPendingIdempotencyKey(null);
      setSimulateTimeout(false);
      setNotice({
        kind: 'ok',
        text: res.idempotentReplay
          ? `Idempotent recovery succeeded: returned existing payment ${res.payment.id} (${res.payment.state}) without duplicate debit.`
          : `Payment ${res.payment.id} committed with state ${res.payment.state}.`,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Payment failed';
      setNotice({ kind: 'err', text: msg });
      await onRefresh();
    } finally {
      setBusy(false);
    }
  };

  const handleQueryByIdempotency = async () => {
    if (!pendingIdempotencyKey) return;
    setBusy(true);
    try {
      const p = await apiFetch<PaymentRecord>(`/payments?idempotencyKey=${encodeURIComponent(pendingIdempotencyKey)}`, {
        role: actorRole,
      });
      setNotice({
        kind: 'ok',
        text: `Authoritative ledger lookup: payment ${p.id} is ${p.state} (${formatGBP(p.amountPence)}). Safe to clear retry state.`,
      });
    } catch (err) {
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'Query failed' });
    } finally {
      setBusy(false);
    }
  };

  const handlePayQrPayload = async (rawPayload?: string) => {
    if (!customer) return;
    setBusy(true);
    setNotice(null);
    try {
      const parsed = JSON.parse(rawPayload ?? qrPayloadText) as {
        requestId: string;
        merchantWalletId: string;
        amountPence: number;
        reference: string;
      };
      // Step 1: Server preview validates HMAC signature, expiry, and single-use
      await apiFetch('/payments/preview', {
        method: 'POST',
        role: actorRole,
        actorId: customer.id,
        body: {
          payerWalletId: customer.walletId,
          payeeWalletId: parsed.merchantWalletId,
          amountPence: parsed.amountPence,
          paymentRequestId: parsed.requestId,
          reference: parsed.reference,
        },
      });
      // Step 2: Execute payment
      const res = await apiFetch<{ payment: PaymentRecord }>('/payments', {
        method: 'POST',
        role: actorRole,
        actorId: customer.id,
        body: {
          payerWalletId: customer.walletId,
          payeeWalletId: parsed.merchantWalletId,
          amountPence: parsed.amountPence,
          paymentReference: parsed.reference,
          paymentRequestId: parsed.requestId,
          paymentKind: 'MERCHANT',
          idempotencyKey: `qr-${parsed.requestId}-${Date.now()}`,
        },
      });
      await onRefresh();
      setNotice({
        kind: 'ok',
        text: `Merchant QR payment ${res.payment.id} finalised (${formatGBP(res.payment.amountPence)}).`,
      });
    } catch (err) {
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'QR payment failed' });
    } finally {
      setBusy(false);
    }
  };

  const handleConversion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customer) return;
    setBusy(true);
    setNotice(null);
    try {
      const amountPence = parsePoundsToPence(convAmountGbp);
      const res = await apiFetch<{ conversion: { id: string; stage: string; failureReason: string | null } }>('/conversions', {
        method: 'POST',
        role: actorRole,
        actorId: customer.id,
        body: {
          direction: convDirection,
          walletId: customer.walletId,
          amountPence,
          bankAccountMask: '****4421',
          bankSortCode: '20-00-00',
          simulateExternalFailure: convSimulateFail,
          idempotencyKey: `conv-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        },
      });
      await onRefresh();
      setNotice({
        kind: res.conversion.stage === 'FAILED_REVERSED' ? 'err' : 'ok',
        text: res.conversion.failureReason
          ? `Stage=${res.conversion.stage}: ${res.conversion.failureReason}`
          : `Conversion ${res.conversion.id} completed (${res.conversion.stage}).`,
      });
    } catch (err) {
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'Conversion failed' });
    } finally {
      setBusy(false);
    }
  };

  const handleDeviceAction = async (action: 'REGISTER' | 'REVOKE', deviceId?: string) => {
    if (!customer) return;
    setBusy(true);
    try {
      await apiFetch(`/pip/customers/${customer.id}/devices`, {
        method: 'POST',
        role: actorRole,
        body: { action, deviceId, deviceLabel: `Android StrongBox #${customer.devices.length + 1}` },
      });
      await onRefresh();
      setNotice({ kind: 'ok', text: action === 'REVOKE' ? 'Device key revoked.' : 'New device key bound.' });
    } catch (err) {
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'Device update failed' });
    } finally {
      setBusy(false);
    }
  };

  const handleRecoveryAction = async (action: 'REPORT_LOST_DEVICE' | 'INITIATE_COOLING_OFF' | 'COMPLETE_RECOVERY') => {
    if (!customer) return;
    setBusy(true);
    try {
      await apiFetch(`/pip/customers/${customer.id}/recovery`, {
        method: 'POST',
        role: actorRole,
        body: { action },
      });
      await onRefresh();
      setNotice({ kind: 'ok', text: `Recovery workflow updated: ${action}.` });
    } catch (err) {
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'Recovery action failed' });
    } finally {
      setBusy(false);
    }
  };

  const handleAccessibilityToggle = async (highContrast: boolean, largeText: boolean) => {
    if (!customer) return;
    await apiFetch(`/pip/customers/${customer.id}/accessibility`, {
      method: 'POST',
      role: actorRole,
      body: { highContrast, largeText },
    });
    await onRefresh();
  };

  const handleOfflineSimulate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customer) return;
    setBusy(true);
    try {
      const amountPence = parsePoundsToPence(offlineAmountGbp);
      const res = await apiFetch<{ id: string; status: string }>('/offline-research/simulate', {
        method: 'POST',
        role: actorRole,
        body: {
          senderWalletId: customer.walletId,
          receiverWalletId: 'wal_pipb_merchant_books',
          amountPence,
          hardwareCounter: Number(offlineCounter),
          secureElementId: `SE-${customer.id}`,
        },
      });
      await onRefresh();
      setNotice({
        kind: res.status === 'DOUBLE_SPEND_DETECTED' ? 'err' : 'ok',
        text: `Offline queued claim ${res.id} recorded with status: ${res.status} (NOT core-final).`,
      });
    } catch (err) {
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'Offline simulation failed' });
    } finally {
      setBusy(false);
    }
  };

  if (!customer || !account) {
    return <div className="p-8 bg-white border border-[#DDD7C8]">No synthetic consumer wallets available.</div>;
  }

  const walletSurfaceClass = customer.accessibilityHighContrast
    ? 'bg-[#0F213B] text-[#FAF8F3] border-[#9A7B3E]'
    : 'bg-white text-[#1C2536] border-[#DDD7C8]';
  const textSizeClass = customer.accessibilityLargeText ? 'text-base' : 'text-sm';

  return (
    <div className="space-y-6">
      {/* PIP & Customer Selector Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[#DDD7C8] pb-4">
        <div>
          <h2 className="text-2xl font-semibold text-[#0F213B]">
            Consumer Wallets across Independent Providers
          </h2>
          <p className="text-sm text-[#4B5563] mt-0.5">
            Personal identity records reside strictly inside PIP-A (Thameside Digital Wallet) or PIP-B (Albion Civic Pay).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {consumerCustomers.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => {
                setSelectedCustomerId(c.id);
                setPreviewData(null);
                setPendingIdempotencyKey(null);
              }}
              className={`px-3.5 py-2 text-xs font-medium border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                c.id === customer.id
                  ? 'bg-[#0F213B] text-[#FAF8F3] border-[#0F213B]'
                  : 'bg-white text-[#1C2536] border-[#DDD7C8] hover:bg-[#F2EFE7]'
              }`}
            >
              {c.fullName.replace(' (Synthetic)', '')} · {c.pipId === 'PIP_A' ? 'PIP-A' : 'PIP-B'}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setShowOnboard(!showOnboard)}
            className="px-3.5 py-2 text-xs font-medium border border-[#9A7B3E] text-[#0F213B] bg-[#FAF8F3] hover:bg-[#F2EFE7] whitespace-nowrap shrink-0 cursor-pointer"
          >
            {showOnboard ? 'Cancel Onboarding' : 'Add Synthetic Customer'}
          </button>
        </div>
      </div>

      {showOnboard && (
        <form onSubmit={handleOnboard} className="p-6 bg-white border border-[#DDD7C8] grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          <div>
            <label className="block text-xs font-medium text-[#364152] mb-1">Provider Scope</label>
            <select
              value={newPip}
              onChange={(e) => setNewPip(e.target.value as 'PIP_A' | 'PIP_B')}
              className="w-full border border-[#DDD7C8] px-3 py-2 text-sm bg-[#FAF8F3]"
            >
              <option value="PIP_A">PIP-A · Thameside Digital Wallet</option>
              <option value="PIP_B">PIP-B · Albion Civic Pay</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-[#364152] mb-1">Synthetic Full Name</label>
            <input
              required
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="e.g. Priya Sharma"
              className="w-full border border-[#DDD7C8] px-3 py-2 text-sm bg-[#FAF8F3]"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-[#364152] mb-1">Synthetic Email</label>
            <input
              required
              type="email"
              value={newEmail}
              onChange={(e) => setNewEmail(e.target.value)}
              placeholder="priya@synthetic.example.uk"
              className="w-full border border-[#DDD7C8] px-3 py-2 text-sm bg-[#FAF8F3]"
            />
          </div>
          <button
            type="submit"
            disabled={busy}
            className="px-4 py-2 bg-[#0F213B] text-[#FAF8F3] text-sm font-medium hover:bg-[#193257] cursor-pointer"
          >
            Create Scoped Wallet
          </button>
        </form>
      )}

      {notice && (
        <div
          className={`p-4 border text-sm flex items-center justify-between gap-4 ${
            notice.kind === 'ok'
              ? 'bg-[#F0FDF4] border-[#BBF7D0] text-[#166534]'
              : 'bg-[#FEF2F2] border-[#FECACA] text-[#991B1B]'
          }`}
        >
          <span>{notice.text}</span>
          {pendingIdempotencyKey && notice.kind === 'err' && (
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleQueryByIdempotency}
                className="px-3 py-1.5 bg-white border border-[#991B1B] text-xs font-medium cursor-pointer"
              >
                Query Outcome
              </button>
              <button
                type="button"
                onClick={() => handleAuthoriseAndSubmit(pendingIdempotencyKey)}
                className="px-3 py-1.5 bg-[#0F213B] text-white text-xs font-medium cursor-pointer"
              >
                Safe Retry (Same Key)
              </button>
            </div>
          )}
        </div>
      )}

      {/* Main Wallet Split: Left Account & Actions, Right Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className={`lg:col-span-7 border p-6 space-y-6 ${walletSurfaceClass} ${textSizeClass}`}>
          {/* Wallet Header & Balance */}
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 border-b border-[#DDD7C8]/60 pb-5">
            <div className="space-y-1">
              <div className="text-xs font-mono opacity-80">
                {customer.pipName} · {customer.syntheticIdentityRef} · {account.status}
              </div>
              <h3 className="text-xl font-semibold">{customer.fullName}</h3>
              <div className="text-xs font-mono opacity-75">
                Core Ledger Opaque Ref: {account.id} ({account.accountCode})
              </div>
            </div>
            <div className="sm:text-right">
              <div className="text-xs opacity-75">Available Digital Pound Balance</div>
              <div className="text-3xl font-mono font-semibold tabular-nums mt-0.5">
                {formatGBP(account.availablePence)}
              </div>
              <div className="text-xs font-mono opacity-75 tabular-nums mt-0.5">
                Reserved: {formatGBP(account.reservedPence)} · Limit:{' '}
                {snapshot.policy.holdingLimitPence ? formatGBP(snapshot.policy.holdingLimitPence) : 'Unbounded'}
              </div>
            </div>
          </div>

          {/* Accessibility & Support Strip */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs border-b border-[#DDD7C8]/60 pb-4">
            <div className="flex items-center gap-4">
              <span className="inline-flex items-center gap-1.5 font-medium">
                <Accessibility className="w-3.5 h-3.5 text-[#9A7B3E]" />
                Accessibility:
              </span>
              <label className="inline-flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={customer.accessibilityHighContrast}
                  onChange={(e) => handleAccessibilityToggle(e.target.checked, customer.accessibilityLargeText)}
                />
                <span>High Contrast</span>
              </label>
              <label className="inline-flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={customer.accessibilityLargeText}
                  onChange={(e) => handleAccessibilityToggle(customer.accessibilityHighContrast, e.target.checked)}
                />
                <span>Large Text</span>
              </label>
            </div>
            <span className="opacity-75">PIP Support Desk: Synthetic Test Environment · Zero Fees</span>
          </div>

          {/* Wallet Sub-Tabs */}
          <div className="flex flex-wrap gap-1 p-1 bg-[#F2EFE7] text-[#1C2536] border border-[#DDD7C8]">
            {(
              [
                ['send', 'Send & Schedule'],
                ['qr_nfc', 'QR & NFC Pay'],
                ['convert', 'Convert In / Out'],
                ['devices', 'Devices & Recovery'],
                ['offline', 'Offline Research'],
              ] as Array<[WalletTab, string]>
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setTab(id)}
                className={`px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  tab === id ? 'bg-[#0F213B] text-[#FAF8F3]' : 'text-[#364152] hover:text-[#0F213B]'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Tab 1: Send & Schedule */}
          {tab === 'send' && (
            <div className="space-y-4 text-[#1C2536]">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium mb-1">Recipient Wallet</label>
                  <select
                    value={payeeWalletId}
                    onChange={(e) => {
                      setPayeeWalletId(e.target.value);
                      setPreviewData(null);
                    }}
                    className="w-full border border-[#DDD7C8] px-3 py-2 text-sm bg-[#FAF8F3]"
                  >
                    {allPayeeTargets.map((t) => (
                      <option key={t.walletId} value={t.walletId}>
                        {t.fullName.replace(' (Synthetic)', '')} ({t.pipId} · {t.walletId})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium mb-1">Amount (GBP)</label>
                  <input
                    value={sendAmountGbp}
                    onChange={(e) => {
                      setSendAmountGbp(e.target.value);
                      setPreviewData(null);
                    }}
                    className="w-full border border-[#DDD7C8] px-3 py-2 text-sm font-mono bg-[#FAF8F3]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium mb-1">Payment Reference</label>
                <input
                  value={sendRef}
                  onChange={(e) => {
                    setSendRef(e.target.value);
                    setPreviewData(null);
                  }}
                  className="w-full border border-[#DDD7C8] px-3 py-2 text-sm bg-[#FAF8F3]"
                />
              </div>

              <div className="flex flex-wrap items-center gap-6 text-xs">
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isScheduled}
                    onChange={(e) => setIsScheduled(e.target.checked)}
                  />
                  <span>Schedule future instruction (does not move funds until executed)</span>
                </label>
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={simulateTimeout}
                    onChange={(e) => setSimulateTimeout(e.target.checked)}
                  />
                  <span>Simulate dropped response after ledger commit</span>
                </label>
              </div>

              {isScheduled && (
                <div>
                  <label className="block text-xs font-medium mb-1">Scheduled Execution Time</label>
                  <input
                    type="datetime-local"
                    value={scheduledFor}
                    onChange={(e) => setScheduledFor(e.target.value)}
                    className="border border-[#DDD7C8] px-3 py-2 text-sm font-mono bg-[#FAF8F3]"
                  />
                </div>
              )}

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  disabled={busy}
                  onClick={handlePreview}
                  className="px-4 py-2 border border-[#0F213B] text-[#0F213B] text-sm font-medium hover:bg-[#F2EFE7] cursor-pointer"
                >
                  1. Preview &amp; Validate
                </button>
                {previewData && (
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => handleAuthoriseAndSubmit()}
                    className="px-4 py-2 bg-[#0F213B] text-[#FAF8F3] text-sm font-medium hover:bg-[#193257] cursor-pointer"
                  >
                    2. Authorise &amp; Submit
                  </button>
                )}
              </div>

              {previewData && (
                <div className="p-4 bg-[#FAF8F3] border border-[#DDD7C8] space-y-1.5 text-xs">
                  <div className="font-semibold text-[#0F213B]">
                    Review Stage · Bound Authorisation Digest
                  </div>
                  <div className="font-mono text-[#364152] break-all">
                    Amount: {formatGBP(previewData.amountPence)} · Fee: {formatGBP(previewData.feePence)} · Net:{' '}
                    {formatGBP(previewData.netPayeePence)}
                  </div>
                  <div className="font-mono text-[11px] text-[#6E6758] break-all">
                    SHA-256 Binding: {previewData.authorisationPayloadHash}
                  </div>
                  {previewData.warnings.map((w, idx) => (
                    <div key={idx} className="text-[#92400E] font-medium">
                      Monitoring note: {w}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Tab 2: QR & NFC Pay */}
          {tab === 'qr_nfc' && (
            <div className="space-y-4 text-[#1C2536]">
              <div className="p-4 bg-[#FAF8F3] border border-[#DDD7C8] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#0F213B] inline-flex items-center gap-1.5">
                    <Nfc className="w-4 h-4 text-[#9A7B3E]" />
                    NFC Hardware Adapter Boundary (Simulated)
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const activePr = snapshot.paymentRequests.find((r) => r.status === 'ACTIVE');
                      if (!activePr) {
                        setNotice({ kind: 'err', text: 'Create an active payment request in Merchant Portal first.' });
                        return;
                      }
                      const payload = JSON.stringify({
                        scheme: 'uk.sterling.digital.experimental',
                        requestId: activePr.id,
                        merchantWalletId: activePr.merchantWalletId,
                        amountPence: activePr.amountPence,
                        currency: 'GBP',
                        reference: activePr.reference,
                        expiresAt: activePr.expiresAt,
                        signatureHmac: activePr.signatureHmac,
                      });
                      setNfcSimulatedRef(activePr.id);
                      setQrPayloadText(payload);
                    }}
                    className="px-3 py-1.5 bg-[#0F213B] text-[#FAF8F3] text-xs font-medium cursor-pointer"
                  >
                    Simulate NFC Tap Discovery
                  </button>
                </div>
                <p className="text-xs text-[#4B5563]">
                  Exchanges only a signed payment-request reference over NDEF/HCE. NFC discovery never authorises
                  or settles balances locally, and cannot read or provision arbitrary bank or transit cards.
                </p>
                {nfcSimulatedRef && (
                  <div className="text-xs font-mono text-[#166534]">
                    NFC boundary received reference {nfcSimulatedRef}; awaiting customer preview &amp; TLS authorisation.
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-medium mb-1">Active Merchant Payment Requests</label>
                <div className="space-y-2">
                  {snapshot.paymentRequests.filter((r) => r.status === 'ACTIVE').length === 0 && (
                    <div className="text-xs text-[#6E6758]">
                      No active merchant payment requests. Generate one in the Merchant Portal tab.
                    </div>
                  )}
                  {snapshot.paymentRequests
                    .filter((r) => r.status === 'ACTIVE')
                    .map((r) => {
                      const payload = JSON.stringify({
                        scheme: 'uk.sterling.digital.experimental',
                        requestId: r.id,
                        merchantWalletId: r.merchantWalletId,
                        amountPence: r.amountPence,
                        currency: 'GBP',
                        reference: r.reference,
                        expiresAt: r.expiresAt,
                        signatureHmac: r.signatureHmac,
                      });
                      return (
                        <div key={r.id} className="p-3 border border-[#DDD7C8] bg-[#FAF8F3] flex items-center justify-between gap-3">
                          <div className="text-xs">
                            <div className="font-semibold text-[#0F213B]">
                              {r.merchantName} · {formatGBP(r.amountPence)}
                            </div>
                            <div className="text-[#4B5563] font-mono">
                              {r.id} · {r.reference}
                            </div>
                          </div>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => handlePayQrPayload(payload)}
                            className="px-3 py-1.5 bg-[#0F213B] text-white text-xs font-medium whitespace-nowrap cursor-pointer"
                          >
                            Verify &amp; Pay
                          </button>
                        </div>
                      );
                    })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium mb-1 inline-flex items-center gap-1.5">
                  <QrCode className="w-3.5 h-3.5 text-[#9A7B3E]" />
                  Or Paste Signed QR JSON Payload (Tamper-Checked Server-Side)
                </label>
                <textarea
                  rows={3}
                  value={qrPayloadText}
                  onChange={(e) => setQrPayloadText(e.target.value)}
                  placeholder='{"requestId":"pr_...","merchantWalletId":"wal_pipb_merchant_books","amountPence":1850,...}'
                  className="w-full border border-[#DDD7C8] p-2.5 text-xs font-mono bg-[#FAF8F3]"
                />
                <button
                  type="button"
                  disabled={busy || !qrPayloadText.trim()}
                  onClick={() => handlePayQrPayload()}
                  className="mt-2 px-4 py-2 bg-[#0F213B] text-[#FAF8F3] text-xs font-medium cursor-pointer disabled:opacity-50"
                >
                  Verify Signature &amp; Authorise QR Payment
                </button>
              </div>
            </div>
          )}

          {/* Tab 3: Convert In / Out */}
          {tab === 'convert' && (
            <form onSubmit={handleConversion} className="space-y-4 text-[#1C2536]">
              <p className="text-xs text-[#4B5563]">
                Simulated Commercial-Bank Gateway (1:1 nominal GBP). Separates conversion request, external
                settlement evidence, core posting, notification, and reconciliation.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium mb-1">Conversion Direction</label>
                  <select
                    value={convDirection}
                    onChange={(e) => setConvDirection(e.target.value as 'DEPOSIT_TO_CBDC' | 'CBDC_TO_DEPOSIT')}
                    className="w-full border border-[#DDD7C8] px-3 py-2 text-sm bg-[#FAF8F3]"
                  >
                    <option value="DEPOSIT_TO_CBDC">Bank Deposit → Digital Pound (Convert In)</option>
                    <option value="CBDC_TO_DEPOSIT">Digital Pound → Bank Deposit (Convert Out)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium mb-1">Amount (GBP)</label>
                  <input
                    value={convAmountGbp}
                    onChange={(e) => setConvAmountGbp(e.target.value)}
                    className="w-full border border-[#DDD7C8] px-3 py-2 text-sm font-mono bg-[#FAF8F3]"
                  />
                </div>
              </div>
              <label className="inline-flex items-center gap-2 text-xs cursor-pointer">
                <input
                  type="checkbox"
                  checked={convSimulateFail}
                  onChange={(e) => setConvSimulateFail(e.target.checked)}
                />
                <span>Simulate external commercial-bank rail failure (verifies non-destructive reversal)</span>
              </label>
              <div>
                <button
                  type="submit"
                  disabled={busy}
                  className="px-4 py-2 bg-[#0F213B] text-[#FAF8F3] text-sm font-medium cursor-pointer"
                >
                  Execute Staged Conversion
                </button>
              </div>
            </form>
          )}

          {/* Tab 4: Devices & Recovery */}
          {tab === 'devices' && (
            <div className="space-y-5 text-[#1C2536]">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-semibold text-[#0F213B] inline-flex items-center gap-1.5">
                    <Smartphone className="w-4 h-4 text-[#9A7B3E]" />
                    Bound Hardware Devices (PIP Keystore Registry)
                  </h4>
                  <button
                    type="button"
                    onClick={() => handleDeviceAction('REGISTER')}
                    className="px-3 py-1.5 border border-[#0F213B] text-xs font-medium cursor-pointer"
                  >
                    Bind Replacement Device
                  </button>
                </div>
                <div className="divide-y divide-[#DDD7C8] border border-[#DDD7C8] bg-[#FAF8F3]">
                  {customer.devices.map((d) => (
                    <div key={d.id} className="p-3 flex items-center justify-between gap-3 text-xs">
                      <div>
                        <div className="font-medium text-[#0F213B]">
                          {d.deviceLabel} · {d.attestationStatus}
                        </div>
                        <div className="font-mono text-[#6E6758]">
                          {d.platform} · Key Alias: {d.keyAlias}
                        </div>
                      </div>
                      {d.attestationStatus === 'VERIFIED' && (
                        <button
                          type="button"
                          onClick={() => handleDeviceAction('REVOKE', d.id)}
                          className="px-2.5 py-1 border border-[#991B1B] text-[#991B1B] text-xs cursor-pointer"
                        >
                          Revoke Key
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-4 border border-[#DDD7C8] bg-[#FAF8F3] space-y-3">
                <div className="text-xs font-semibold text-[#0F213B] inline-flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-[#9A7B3E]" />
                  Lost-Device &amp; PIP-Assisted Recovery ({snapshot.policy.recoveryModel})
                </div>
                <p className="text-xs text-[#4B5563]">
                  Current recovery state: <span className="font-mono font-semibold">{customer.recoveryStatus}</span>.
                  Note: Pure bearer-key self-custody and administrator-assisted account recovery are mutually
                  exclusive governance tradeoffs; this PIP model enforces freeze, cooling-off, and identity re-attestation.
                </p>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => handleRecoveryAction('REPORT_LOST_DEVICE')}
                    className="px-3 py-1.5 bg-[#991B1B] text-white text-xs font-medium cursor-pointer"
                  >
                    1. Report Lost Device (Freeze Wallet)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRecoveryAction('INITIATE_COOLING_OFF')}
                    className="px-3 py-1.5 border border-[#0F213B] text-xs font-medium cursor-pointer"
                  >
                    2. Start Cooling-Off Review
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRecoveryAction('COMPLETE_RECOVERY')}
                    className="px-3 py-1.5 bg-[#166534] text-white text-xs font-medium cursor-pointer"
                  >
                    3. Re-Attest &amp; Reactivate Wallet
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Tab 5: Offline Research Module */}
          {tab === 'offline' && (
            <form onSubmit={handleOfflineSimulate} className="space-y-4 text-[#1C2536]">
              <div className="p-4 bg-[#FAF8F3] border border-[#DDD7C8] text-xs space-y-1.5">
                <div className="font-semibold text-[#0F213B]">
                  Isolated Offline Research Experiment (Outside Initial Acceptance Milestone)
                </div>
                <p className="text-[#4B5563]">
                  A queued offline instruction is NOT an offline-final core ledger settlement. Without tamper-resistant
                  Secure Element (SE/TEE) monotonic counters and deferred reconciliation bounds, offline claims carry
                  double-spending exposure. Reusing the same hardware counter triggers DOUBLE_SPEND_DETECTED on sync.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium mb-1">SE Monotonic Counter</label>
                  <input
                    type="number"
                    min={1}
                    value={offlineCounter}
                    onChange={(e) => setOfflineCounter(e.target.value)}
                    className="w-full border border-[#DDD7C8] px-3 py-2 text-sm font-mono bg-[#FAF8F3]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium mb-1">Offline Instruction Amount (GBP)</label>
                  <input
                    value={offlineAmountGbp}
                    onChange={(e) => setOfflineAmountGbp(e.target.value)}
                    className="w-full border border-[#DDD7C8] px-3 py-2 text-sm font-mono bg-[#FAF8F3]"
                  />
                </div>
              </div>
              <button type="submit" className="px-4 py-2 bg-[#0F213B] text-[#FAF8F3] text-xs font-medium cursor-pointer">
                Queue Offline Hardware Instruction
              </button>
              {snapshot.offlineClaims.length > 0 && (
                <div className="divide-y divide-[#DDD7C8] border border-[#DDD7C8] text-xs">
                  {snapshot.offlineClaims.slice(0, 5).map((oc) => (
                    <div key={oc.id} className="p-2.5 flex justify-between font-mono">
                      <span>
                        {oc.id} · Counter #{oc.hardware_counter} · {formatGBP(oc.amount_pence)}
                      </span>
                      <span className={oc.status === 'DOUBLE_SPEND_DETECTED' ? 'text-[#991B1B] font-semibold' : 'text-[#92400E]'}>
                        {oc.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </form>
          )}
        </div>

        {/* Right Column: Wallet Activity & Authoritative State */}
        <div className="lg:col-span-5 bg-white border border-[#DDD7C8] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[#DDD7C8] pb-3">
            <h3 className="text-base font-semibold text-[#0F213B]">Authoritative Activity</h3>
            <button
              type="button"
              onClick={onRefresh}
              className="inline-flex items-center gap-1 text-xs text-[#0F213B] hover:text-[#9A7B3E] cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Refresh</span>
            </button>
          </div>

          <div className="divide-y divide-[#DDD7C8]">
            {walletPayments.length === 0 && (
              <p className="py-6 text-xs text-[#6E6758]">No payment activity recorded for this wallet yet.</p>
            )}
            {walletPayments.slice(0, 10).map((p) => {
              const isOutgoing = p.payerWalletId === customer.walletId;
              return (
                <div key={p.id} className="py-3 flex items-start justify-between gap-3">
                  <div className="space-y-0.5 min-w-0">
                    <div className="flex items-center gap-1.5 text-sm font-medium text-[#0F213B]">
                      {isOutgoing ? (
                        <ArrowUpRight className="w-3.5 h-3.5 text-[#991B1B] shrink-0" />
                      ) : (
                        <ArrowDownLeft className="w-3.5 h-3.5 text-[#166534] shrink-0" />
                      )}
                      <span className="truncate">{p.paymentReference}</span>
                    </div>
                    <div className="text-xs font-mono text-[#6E6758]">
                      {p.id} · {p.paymentKind} · {p.state}
                    </div>
                    {p.state === 'AUTHORISED' && p.paymentKind === 'SCHEDULED' && isOutgoing && (
                      <button
                        type="button"
                        onClick={async () => {
                          await apiFetch(`/payments/${p.id}/execute-scheduled`, { method: 'POST', role: actorRole });
                          await onRefresh();
                        }}
                        className="mt-1 px-2.5 py-1 bg-[#0F213B] text-white text-xs cursor-pointer"
                      >
                        Execute Scheduled Instruction Now
                      </button>
                    )}
                  </div>
                  <div
                    className={`text-sm font-mono font-semibold tabular-nums shrink-0 ${
                      isOutgoing ? 'text-[#991B1B]' : 'text-[#166534]'
                    }`}
                  >
                    {isOutgoing ? '-' : '+'}
                    {formatGBP(p.amountPence)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
