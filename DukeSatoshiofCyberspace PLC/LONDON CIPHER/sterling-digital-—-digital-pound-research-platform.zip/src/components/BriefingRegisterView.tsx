import { useState } from 'react';
import { ExternalLink, ShieldCheck, Scale, FileText } from 'lucide-react';
import { DESIGN_REGISTER } from '../data/designRegister';
import { formatGBP, type PlatformSnapshot } from '../lib/api';
import type { DesignRegisterEntry } from '../types/cbdc';

interface Props {
  snapshot: PlatformSnapshot;
  onNavigate: (tab: 'briefing' | 'wallets' | 'merchant' | 'ledger' | 'operations') => void;
}

const CATEGORY_LABELS: Record<DesignRegisterEntry['category'] | 'ALL', string> = {
  ALL: 'All Entries',
  PUBLISHED_PROPOSAL: 'Published Proposals',
  UNRESOLVED_POLICY: 'Unresolved Policy',
  PROTOTYPE_ASSUMPTION: 'Prototype Assumptions',
  IMPLEMENTED_FUNCTIONALITY: 'Implemented',
  FUTURE_INTEGRATION: 'Future Integrations',
};

export function BriefingRegisterView({ snapshot, onNavigate }: Props) {
  const [filter, setFilter] = useState<DesignRegisterEntry['category'] | 'ALL'>('ALL');
  const [bannerBroken, setBannerBroken] = useState(false);
  const [emblemBroken, setEmblemBroken] = useState(false);

  const rec = snapshot.reconciliation;
  const filtered = filter === 'ALL' ? DESIGN_REGISTER : DESIGN_REGISTER.filter((d) => d.category === filter);

  return (
    <div className="space-y-10">
      {/* Institutional Hero Split */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch border border-[#DDD7C8] bg-white">
        <div className="lg:col-span-7 p-8 lg:p-10 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="flex items-center gap-3 text-xs tracking-wide text-[#6E6758]">
              <span>Bank of England &amp; HM Treasury Platform Model Study</span>
              <span aria-hidden="true">·</span>
              <span>Retrieval Date 2026-11-18</span>
            </div>
            <h1 className="text-3xl lg:text-4xl font-semibold text-[#0F213B] leading-tight text-balance">
              Sterling Digital Research Platform
            </h1>
            <p className="text-base text-[#364152] leading-relaxed max-w-2xl">
              An experimental retail central bank digital currency workbench separating an atomic,
              integer-pence core ledger from two independent Payment Interface Providers (PIPs),
              merchant acceptance terminals, and a simulated commercial-bank deposit gateway.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => onNavigate('wallets')}
              className="px-5 py-2.5 bg-[#0F213B] text-[#FAF8F3] text-sm font-medium hover:bg-[#193257] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Open Consumer Wallets
            </button>
            <button
              type="button"
              onClick={() => onNavigate('ledger')}
              className="px-5 py-2.5 border border-[#0F213B] text-[#0F213B] text-sm font-medium hover:bg-[#F2EFE7] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Inspect Core Ledger
            </button>
            <button
              type="button"
              onClick={() => onNavigate('operations')}
              className="px-5 py-2.5 border border-[#DDD7C8] text-[#364152] text-sm font-medium hover:bg-[#F2EFE7] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Run Tests &amp; Benchmark
            </button>
          </div>
        </div>

        <div className="lg:col-span-5 relative min-h-[260px] bg-[#0F213B] overflow-hidden">
          {!bannerBroken ? (
            <img
              src="/src/assets/images/sterling_institutional_banner_1795006657963.jpg"
              alt="Neoclassical London financial institution facade"
              referrerPolicy="no-referrer"
              onError={() => setBannerBroken(true)}
              className="w-full h-full object-cover opacity-90"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center p-8 text-[#FAF8F3]">
              <span className="font-display text-lg">Threadneedle Architectural Study</span>
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0F213B]/85 via-[#0F213B]/20 to-transparent flex items-end p-6">
            <div className="flex items-center gap-4">
              {!emblemBroken && (
                <img
                  src="/src/assets/images/sterling_brass_emblem_1795006655986.jpg"
                  alt="Sterling Digital brass guilloche emblem"
                  referrerPolicy="no-referrer"
                  onError={() => setEmblemBroken(true)}
                  className="w-14 h-14 object-cover border border-[#9A7B3E]/70 shrink-0"
                />
              )}
              <div className="text-[#FAF8F3]">
                <p className="text-xs text-[#E5D3A8]">Simulated Sterling · Synthetic Identities Only</p>
                <p className="text-sm font-medium mt-0.5">
                  No real money, legal tender, or Bank of England production API access.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4-Column Live Monetary Invariants Strip */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 border border-[#DDD7C8] bg-white divide-y sm:divide-y-0 sm:divide-x divide-[#DDD7C8]">
        <div className="p-6">
          <p className="text-xs text-[#6E6758]">Net Issued Supply</p>
          <p className="text-2xl font-mono font-semibold text-[#0F213B] mt-1.5 tabular-nums">
            {formatGBP(rec.netSupplyPence)}
          </p>
          <p className="text-xs text-[#6E6758] mt-1 font-mono tabular-nums">
            {rec.issuedTotalPence.toLocaleString()}p issued · {rec.redeemedTotalPence.toLocaleString()}p redeemed
          </p>
        </div>
        <div className="p-6">
          <p className="text-xs text-[#6E6758]">Outstanding Wallet Balances</p>
          <p className="text-2xl font-mono font-semibold text-[#0F213B] mt-1.5 tabular-nums">
            {formatGBP(rec.walletAvailableSumPence)}
          </p>
          <p className="text-xs text-[#6E6758] mt-1 font-mono tabular-nums">
            Across {snapshot.pipCustomers.length} synthetic accounts (PIP-A &amp; PIP-B)
          </p>
        </div>
        <div className="p-6">
          <p className="text-xs text-[#6E6758]">Settlement Control Pool</p>
          <p className="text-2xl font-mono font-semibold text-[#0F213B] mt-1.5 tabular-nums">
            {formatGBP(rec.settlementPoolPence)}
          </p>
          <p className="text-xs text-[#6E6758] mt-1 font-mono tabular-nums">
            Reserved escrow {formatGBP(rec.reservedEscrowPence)}
          </p>
        </div>
        <div className="p-6">
          <p className="text-xs text-[#6E6758]">Reconciliation Discrepancy</p>
          <p
            className={`text-2xl font-mono font-semibold mt-1.5 tabular-nums ${
              rec.discrepancyPence === 0 && rec.invariantDoubleEntryBalanced ? 'text-[#166534]' : 'text-[#991B1B]'
            }`}
          >
            {formatGBP(rec.discrepancyPence)}
          </p>
          <p className="text-xs text-[#364152] mt-1">
            {rec.invariantSupplyBalanced && rec.invariantDoubleEntryBalanced
              ? 'Supply & Double-Entry Invariants Balanced'
              : 'Invariant Alert Triggered'}
          </p>
        </div>
      </section>

      {/* Design Register */}
      <section className="space-y-5">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#DDD7C8] pb-4">
          <div>
            <h2 className="text-2xl font-semibold text-[#0F213B]">
              Design Register: Policy Grounding &amp; Prototype Boundaries
            </h2>
            <p className="text-sm text-[#4B5563] mt-1">
              Distinguishes published Bank of England and HM Treasury proposals from unresolved policy questions,
              prototype assumptions, implemented modules, and required future integrations.
            </p>
          </div>
          <div className="flex flex-wrap gap-1 p-1 bg-[#F2EFE7] border border-[#DDD7C8]">
            {(Object.keys(CATEGORY_LABELS) as Array<keyof typeof CATEGORY_LABELS>).map((key) => (
              <button
                key={key}
                type="button"
                onClick={() => setFilter(key)}
                className={`px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  filter === key
                    ? 'bg-[#0F213B] text-[#FAF8F3]'
                    : 'text-[#364152] hover:text-[#0F213B]'
                }`}
              >
                {CATEGORY_LABELS[key]}
              </button>
            ))}
          </div>
        </div>

        <div className="divide-y divide-[#DDD7C8] border border-[#DDD7C8] bg-white">
          {filtered.map((entry) => (
            <article key={entry.id} className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
              <div className="lg:col-span-3 space-y-1">
                <div className="text-xs font-mono text-[#9A7B3E] font-semibold">
                  {entry.id} · {CATEGORY_LABELS[entry.category]}
                </div>
                <h3 className="text-base font-semibold text-[#0F213B]">{entry.topic}</h3>
                <div className="text-xs text-[#6E6758]">Retrieved {entry.retrievedAt}</div>
              </div>
              <div className="lg:col-span-6 space-y-2">
                <p className="text-sm text-[#1C2536] leading-relaxed">{entry.summary}</p>
                <p className="text-xs text-[#4B5563] leading-relaxed">{entry.rationale}</p>
              </div>
              <div className="lg:col-span-3 lg:text-right">
                <a
                  href={entry.sourceUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-[#0F213B] hover:text-[#9A7B3E] underline underline-offset-4"
                >
                  <span>{entry.sourceTitle}</span>
                  <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Sovereign Architecture, Authority & Cybersecurity Summary */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="p-6 bg-white border border-[#DDD7C8] space-y-3">
          <div className="flex items-center gap-2 text-[#0F213B]">
            <Scale className="w-4 h-4 text-[#9A7B3E]" />
            <h3 className="text-base font-semibold">Institutional Authority &amp; Legislation</h3>
          </div>
          <p className="text-sm text-[#364152] leading-relaxed">
            Real issuance requires UK primary legislation granting legal tender status, statutory data-blindness
            protections barring Bank and government surveillance, FCA/PRA licensing of private PIPs, and RTGS
            ISO 20022 integration.
          </p>
        </div>

        <div className="p-6 bg-white border border-[#DDD7C8] space-y-3">
          <div className="flex items-center gap-2 text-[#0F213B]">
            <ShieldCheck className="w-4 h-4 text-[#9A7B3E]" />
            <h3 className="text-base font-semibold">Sovereign Cybersecurity Standards</h3>
          </div>
          <p className="text-sm text-[#364152] leading-relaxed">
            Production CBDC infrastructure requires Mutual TLS 1.3 via regulated PKI, FIPS 140-3 Level 3 HSM
            quorum custody for issuance keys, hardware-backed mobile enclaves (StrongBox/Secure Enclave), and a
            post-quantum migration path (ML-KEM / ML-DSA).
          </p>
        </div>

        <div className="p-6 bg-white border border-[#DDD7C8] space-y-3">
          <div className="flex items-center gap-2 text-[#0F213B]">
            <FileText className="w-4 h-4 text-[#9A7B3E]" />
            <h3 className="text-base font-semibold">Polyglot Repository Deliverables</h3>
          </div>
          <p className="text-sm text-[#364152] leading-relaxed">
            Live SQLite/Express engine on port 3000 accompanied by Rust core transaction crate, PostgreSQL 16
            DDL migrations, Kotlin/Jetpack Compose Android wallet, Python 3 reconciler &amp; load tester, OpenAPI
            3.1 contract, and Docker Compose config under <span className="font-mono text-xs">/platform</span>.
          </p>
        </div>
      </section>
    </div>
  );
}
