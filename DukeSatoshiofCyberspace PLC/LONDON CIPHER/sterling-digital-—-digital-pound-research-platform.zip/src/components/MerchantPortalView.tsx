import { useEffect, useState } from 'react';
import { Download, QrCode, RotateCcw } from 'lucide-react';
import { apiFetch, formatGBP, parsePoundsToPence, type PlatformSnapshot } from '../lib/api';
import type { MerchantPaymentRequest } from '../types/cbdc';

interface Props {
  snapshot: PlatformSnapshot;
  onRefresh: () => Promise<void>;
}

export function MerchantPortalView({ snapshot, onRefresh }: Props) {
  const merchants = snapshot.accounts.filter((a) => a.accountClass === 'WALLET_MERCHANT');
  const [merchantWalletId, setMerchantWalletId] = useState(merchants[0]?.id ?? 'wal_pipb_merchant_books');
  const [amountGbp, setAmountGbp] = useState('18.50');
  const [reference, setReference] = useState('Order #BK-2042 · Monetary History Hardcover');
  const [singleUse, setSingleUse] = useState(true);
  const [ttlSeconds, setTtlSeconds] = useState('900');

  const [selectedRequestId, setSelectedRequestId] = useState<string>(snapshot.paymentRequests[0]?.id ?? '');
  const [qrSvg, setQrSvg] = useState<string>('');
  const [qrPayload, setQrPayload] = useState<string>('');
  const [refundInputs, setRefundInputs] = useState<Record<string, string>>({});
  const [notice, setNotice] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);

  const merchantAccount = merchants.find((m) => m.id === merchantWalletId) ?? merchants[0];
  const merchantCust = snapshot.pipCustomers.find((c) => c.walletId === merchantWalletId);
  const requests = snapshot.paymentRequests.filter((r) => r.merchantWalletId === merchantWalletId);
  const merchantPayments = snapshot.payments.filter(
    (p) => p.payeeWalletId === merchantWalletId && p.state === 'FINALISED'
  );

  useEffect(() => {
    if (!selectedRequestId) return;
    apiFetch<{ payload: string; svg: string }>(`/payment-requests/${selectedRequestId}/qr`, { role: 'MERCHANT' })
      .then((res) => {
        setQrSvg(res.svg);
        setQrPayload(res.payload);
      })
      .catch(() => {
        setQrSvg('');
      });
  }, [selectedRequestId, snapshot.paymentRequests]);

  const handleCreateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setNotice(null);
    try {
      const amountPence = parsePoundsToPence(amountGbp);
      const pr = await apiFetch<MerchantPaymentRequest>('/payment-requests', {
        method: 'POST',
        role: 'MERCHANT',
        actorId: merchantWalletId,
        body: {
          merchantWalletId,
          amountPence,
          reference,
          singleUse,
          ttlSeconds: Number(ttlSeconds),
        },
      });
      await onRefresh();
      setSelectedRequestId(pr.id);
      setNotice({ kind: 'ok', text: `Created signed payment request ${pr.id} for ${formatGBP(pr.amountPence)}.` });
    } catch (err) {
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'Failed to create request' });
    }
  };

  const handleRefund = async (paymentId: string) => {
    setNotice(null);
    try {
      const rawAmt = refundInputs[paymentId] ?? '5.00';
      const refundAmountPence = parsePoundsToPence(rawAmt);
      await apiFetch('/refunds', {
        method: 'POST',
        role: 'MERCHANT',
        actorId: merchantWalletId,
        body: {
          originalPaymentId: paymentId,
          refundAmountPence,
          reason: 'Merchant portal approved return',
        },
      });
      await onRefresh();
      setNotice({ kind: 'ok', text: `Issued ${formatGBP(refundAmountPence)} refund against ${paymentId}.` });
    } catch (err) {
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'Refund failed' });
    }
  };

  const activeSelected = requests.find((r) => r.id === selectedRequestId) ?? requests[0];

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#DDD7C8] pb-4">
        <div>
          <h2 className="text-2xl font-semibold text-[#0F213B]">Merchant Acceptance &amp; Settlement Portal</h2>
          <p className="text-sm text-[#4B5563] mt-1">
            {merchantCust?.fullName.replace(' (Synthetic)', '') ?? 'Merchant'} · {merchantWalletId} · Balance{' '}
            <span className="font-mono font-semibold text-[#0F213B]">
              {formatGBP(merchantAccount?.availablePence ?? 0)}
            </span>
          </p>
        </div>
        <a
          href={`/api/merchant/${merchantWalletId}/settlement-csv`}
          className="inline-flex items-center gap-2 px-4 py-2 border border-[#0F213B] text-[#0F213B] text-xs font-medium hover:bg-[#F2EFE7] whitespace-nowrap shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Settlement CSV</span>
        </a>
      </div>

      {notice && (
        <div
          className={`p-4 border text-sm ${
            notice.kind === 'ok'
              ? 'bg-[#F0FDF4] border-[#BBF7D0] text-[#166534]'
              : 'bg-[#FEF2F2] border-[#FECACA] text-[#991B1B]'
          }`}
        >
          {notice.text}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Create Payment Request + QR Display */}
        <div className="lg:col-span-5 bg-white border border-[#DDD7C8] p-6 space-y-5">
          <h3 className="text-base font-semibold text-[#0F213B]">Create Signed Payment Request</h3>
          <form onSubmit={handleCreateRequest} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium mb-1">Amount (GBP)</label>
                <input
                  value={amountGbp}
                  onChange={(e) => setAmountGbp(e.target.value)}
                  className="w-full border border-[#DDD7C8] px-3 py-2 text-sm font-mono bg-[#FAF8F3]"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Expiry TTL (seconds)</label>
                <input
                  type="number"
                  min={60}
                  value={ttlSeconds}
                  onChange={(e) => setTtlSeconds(e.target.value)}
                  className="w-full border border-[#DDD7C8] px-3 py-2 text-sm font-mono bg-[#FAF8F3]"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Order Reference</label>
              <input
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                className="w-full border border-[#DDD7C8] px-3 py-2 text-sm bg-[#FAF8F3]"
              />
            </div>
            <label className="inline-flex items-center gap-2 text-xs cursor-pointer">
              <input type="checkbox" checked={singleUse} onChange={(e) => setSingleUse(e.target.checked)} />
              <span>Single-use request (prevents replay after settlement)</span>
            </label>
            <button
              type="submit"
              className="w-full px-4 py-2.5 bg-[#0F213B] text-[#FAF8F3] text-sm font-medium hover:bg-[#193257] cursor-pointer"
            >
              Generate HMAC-Signed QR Request
            </button>
          </form>

          {activeSelected && (
            <div className="border-t border-[#DDD7C8] pt-5 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-[#0F213B] inline-flex items-center gap-1.5">
                  <QrCode className="w-4 h-4 text-[#9A7B3E]" />
                  {activeSelected.id}
                </span>
                <span
                  className={`font-mono font-semibold ${
                    activeSelected.status === 'USED'
                      ? 'text-[#166534]'
                      : activeSelected.status === 'ACTIVE'
                      ? 'text-[#92400E]'
                      : 'text-[#991B1B]'
                  }`}
                >
                  {activeSelected.status === 'USED' ? 'PAID & CONSUMED' : activeSelected.status}
                </span>
              </div>
              {qrSvg && (
                <div
                  className="w-48 h-48 mx-auto border border-[#DDD7C8] p-2 bg-[#FAF8F3]"
                  dangerouslySetInnerHTML={{ __html: qrSvg }}
                />
              )}
              <p className="text-[11px] text-[#6E6758] text-center">
                A scanned QR code is not payment confirmation. Final status is read strictly from authoritative
                Core Ledger state.
              </p>
              <div className="p-2.5 bg-[#FAF8F3] border border-[#DDD7C8] text-[11px] font-mono break-all text-[#364152]">
                {qrPayload}
              </div>
            </div>
          )}
        </div>

        {/* Requests & Orders Reconciliation */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white border border-[#DDD7C8] p-6 space-y-4">
            <h3 className="text-base font-semibold text-[#0F213B]">Payment Requests Register</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-[#DDD7C8] text-left text-[#6E6758]">
                    <th className="py-2 pr-3 font-medium">Request ID</th>
                    <th className="py-2 pr-3 font-medium">Reference</th>
                    <th className="py-2 pr-3 font-medium text-right">Amount</th>
                    <th className="py-2 pr-3 font-medium">Status</th>
                    <th className="py-2 font-medium text-right">QR</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#DDD7C8]">
                  {requests.map((r) => (
                    <tr key={r.id} className="hover:bg-[#FAF8F3]">
                      <td className="py-2.5 pr-3 font-mono">{r.id}</td>
                      <td className="py-2.5 pr-3">{r.reference}</td>
                      <td className="py-2.5 pr-3 font-mono text-right tabular-nums">{formatGBP(r.amountPence)}</td>
                      <td className="py-2.5 pr-3 font-mono">{r.status}</td>
                      <td className="py-2.5 text-right">
                        <button
                          type="button"
                          onClick={() => setSelectedRequestId(r.id)}
                          className="text-[#0F213B] underline cursor-pointer"
                        >
                          Inspect
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white border border-[#DDD7C8] p-6 space-y-4">
            <h3 className="text-base font-semibold text-[#0F213B]">Captured Orders &amp; Partial Refunds</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-[#DDD7C8] text-left text-[#6E6758]">
                    <th className="py-2 pr-3 font-medium">Payment ID</th>
                    <th className="py-2 pr-3 font-medium">Reference</th>
                    <th className="py-2 pr-3 font-medium text-right">Captured</th>
                    <th className="py-2 pr-3 font-medium text-right">Refunded</th>
                    <th className="py-2 font-medium text-right">Issue Refund (GBP)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#DDD7C8]">
                  {merchantPayments.length === 0 && (
                    <tr>
                      <td colSpan={5} className="py-4 text-[#6E6758]">
                        No captured merchant sales yet. Pay a QR request from a Consumer Wallet.
                      </td>
                    </tr>
                  )}
                  {merchantPayments.map((p) => {
                    const remaining = p.amountPence - p.feePence - p.refundedPence;
                    return (
                      <tr key={p.id}>
                        <td className="py-2.5 pr-3 font-mono">{p.id}</td>
                        <td className="py-2.5 pr-3">{p.paymentReference}</td>
                        <td className="py-2.5 pr-3 font-mono text-right tabular-nums">{formatGBP(p.amountPence)}</td>
                        <td className="py-2.5 pr-3 font-mono text-right tabular-nums">{formatGBP(p.refundedPence)}</td>
                        <td className="py-2.5 text-right">
                          {remaining > 0 ? (
                            <div className="inline-flex items-center gap-1.5">
                              <input
                                value={refundInputs[p.id] ?? (remaining / 200).toFixed(2)}
                                onChange={(e) => setRefundInputs({ ...refundInputs, [p.id]: e.target.value })}
                                className="w-20 border border-[#DDD7C8] px-2 py-1 text-xs font-mono text-right"
                              />
                              <button
                                type="button"
                                onClick={() => handleRefund(p.id)}
                                className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#0F213B] text-white text-xs cursor-pointer"
                              >
                                <RotateCcw className="w-3 h-3" />
                                <span>Refund</span>
                              </button>
                            </div>
                          ) : (
                            <span className="text-[#6E6758] font-mono">Fully Refunded</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
