import { useState } from 'react';
import { CheckCircle2, Play, RotateCw, ServerCrash, Terminal, XCircle } from 'lucide-react';
import { apiFetch, formatGBP, type PlatformSnapshot } from '../lib/api';

interface Props {
  snapshot: PlatformSnapshot;
  onRefresh: () => Promise<void>;
}

interface DemoStepResult {
  step: number;
  title: string;
  status: 'PENDING' | 'RUNNING' | 'PASSED' | 'FAILED';
  detail: string;
}

const INITIAL_DEMO_STEPS: DemoStepResult[] = [
  { step: 1, title: 'Verify Core Ledger & two independent wallet providers (PIP-A, PIP-B)', status: 'PENDING', detail: '' },
  { step: 2, title: 'Onboard synthetic customer (PIP-A) & synthetic merchant (PIP-B)', status: 'PENDING', detail: '' },
  { step: 3, title: 'Request, dual-approve & post simulated issuance (£250.00)', status: 'PENDING', detail: '' },
  { step: 4, title: 'Fund synthetic customer via simulated commercial-bank deposit conversion (£150.00)', status: 'PENDING', detail: '' },
  { step: 5, title: 'Execute cross-provider P2P transfer (PIP-A -> PIP-B, £20.00)', status: 'PENDING', detail: '' },
  { step: 6, title: 'Create merchant QR payment request (£12.00) & pay from customer wallet', status: 'PENDING', detail: '' },
  { step: 7, title: 'Simulate lost gateway response (HTTP 504) & safely retry with same Idempotency-Key', status: 'PENDING', detail: '' },
  { step: 8, title: 'Issue partial refund (£4.00) from merchant to customer', status: 'PENDING', detail: '' },
  { step: 9, title: 'Redeem experimental supply (£50.00) with dual approval & settlement retirement', status: 'PENDING', detail: '' },
  { step: 10, title: 'Run Node & Python 3 independent reconciliation (verify 0p discrepancy)', status: 'PENDING', detail: '' },
  { step: 11, title: 'Verify ACID SQLite persistence & health endpoint', status: 'PENDING', detail: '' },
  { step: 12, title: 'Create atomic database backup, validate invariants, and restore', status: 'PENDING', detail: '' },
];

export function OperationsTestsView({ snapshot, onRefresh }: Props) {
  const [demoSteps, setDemoSteps] = useState<DemoStepResult[]>(INITIAL_DEMO_STEPS);
  const [demoRunning, setDemoRunning] = useState(false);

  const [testSuiteOutput, setTestSuiteOutput] = useState<{
    tests: {
      total: number;
      passed: number;
      failed: number;
      durationMs: number;
      results: Array<{ name: string; category: string; passed: boolean; detail: string; durationMs: number }>;
    };
    benchmark: {
      environment: Record<string, unknown>;
      readBenchmark: Record<string, number>;
      writePaymentBenchmark: Record<string, number>;
      postLoadReconciliation: Record<string, unknown>;
      disclaimer: string;
    };
  } | null>(null);
  const [testsRunning, setTestsRunning] = useState(false);
  const [pythonRecon, setPythonRecon] = useState<Record<string, unknown> | null>(null);
  const [notice, setNotice] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);

  const updateStep = (stepNum: number, patch: Partial<DemoStepResult>) => {
    setDemoSteps((prev) => prev.map((s) => (s.step === stepNum ? { ...s, ...patch } : s)));
  };

  const runFullGuidedDemo = async () => {
    setDemoRunning(true);
    setNotice(null);
    setDemoSteps(INITIAL_DEMO_STEPS);

    const runStep = async <T,>(stepNum: number, fn: () => Promise<{ detail: string; data: T }>): Promise<T> => {
      updateStep(stepNum, { status: 'RUNNING', detail: 'Executing against live API...' });
      try {
        const res = await fn();
        updateStep(stepNum, { status: 'PASSED', detail: res.detail });
        return res.data;
      } catch (err) {
        updateStep(stepNum, { status: 'FAILED', detail: err instanceof Error ? err.message : 'Step failed' });
        throw err;
      }
    };

    try {
      // Step 1
      await runStep(1, async () => {
        const h = await apiFetch<{ status: string; persistence: string }>('/health');
        return { detail: `Core Ledger ${h.status} (${h.persistence}); PIP_A & PIP_B active.`, data: h };
      });

      // Step 2
      const { custWalletId, merchWalletId } = await runStep(2, async () => {
        const suffix = Date.now().toString().slice(-5);
        const c = await apiFetch<{ wallet: { id: string } }>('/wallets', {
          method: 'POST',
          role: 'PIP_A',
          body: {
            pipId: 'PIP_A',
            fullName: `Demo Customer ${suffix} (Synthetic)`,
            email: `demo.cust.${suffix}@synthetic.example.uk`,
            syntheticIdentityRef: `SYN-DEMO-${suffix}A`,
            tier: 'TIER_1_STANDARD',
          },
        });
        const m = await apiFetch<{ wallet: { id: string } }>('/wallets', {
          method: 'POST',
          role: 'PIP_B',
          body: {
            pipId: 'PIP_B',
            fullName: `Demo Merchant ${suffix} Ltd (Synthetic)`,
            email: `demo.merch.${suffix}@synthetic.example.uk`,
            syntheticIdentityRef: `SYN-DEMO-${suffix}M`,
            tier: 'MERCHANT_VERIFIED',
          },
        });
        return {
          detail: `Created customer ${c.wallet.id} (PIP-A) and merchant ${m.wallet.id} (PIP-B).`,
          data: { custWalletId: c.wallet.id, merchWalletId: m.wallet.id },
        };
      });

      // Step 3
      await runStep(3, async () => {
        const iss = await apiFetch<{ id: string }>('/issuer/issuance-requests', {
          method: 'POST',
          role: 'ISSUER',
          body: { amountPence: 25000, notes: 'Guided demo issuance tranche' },
        });
        await apiFetch(`/issuer/requests/${iss.id}/transition`, { method: 'POST', role: 'ISSUER', actorId: 'val_1', body: { action: 'VALIDATE' } });
        await apiFetch(`/issuer/requests/${iss.id}/transition`, { method: 'POST', role: 'ISSUER', actorId: 'auth_1', body: { action: 'APPROVE_1' } });
        await apiFetch(`/issuer/requests/${iss.id}/transition`, { method: 'POST', role: 'ISSUER_SECOND_APPROVER', actorId: 'auth_2', body: { action: 'APPROVE_2' } });
        await apiFetch(`/issuer/requests/${iss.id}/transition`, {
          method: 'POST',
          role: 'ISSUER',
          body: { action: 'VERIFY_SETTLEMENT_AND_POST', settlementEvidenceRef: `DEMO-RTGS-${Date.now()}` },
        });
        await apiFetch(`/issuer/requests/${iss.id}/transition`, { method: 'POST', role: 'AUDITOR', body: { action: 'RECONCILE' } });
        return { detail: `Issuance ${iss.id} (£250.00) dual-approved, settled, and reconciled.`, data: iss.id };
      });

      // Step 4
      await runStep(4, async () => {
        const conv = await apiFetch<{ conversion: { id: string } }>('/conversions', {
          method: 'POST',
          role: 'PIP_A',
          body: { direction: 'DEPOSIT_TO_CBDC', walletId: custWalletId, amountPence: 15000, bankAccountMask: '****8812', bankSortCode: '20-00-00' },
        });
        return { detail: `Converted £150.00 bank deposit into ${custWalletId} (${conv.conversion.id}).`, data: conv };
      });

      // Step 5
      await runStep(5, async () => {
        const pay = await apiFetch<{ payment: { id: string } }>('/payments', {
          method: 'POST',
          role: 'PIP_A',
          body: {
            payerWalletId: custWalletId,
            payeeWalletId: 'wal_pipb_claire',
            amountPence: 2000,
            paymentReference: 'Demo cross-PIP P2P transfer',
            idempotencyKey: `demo-p2p-${Date.now()}`,
          },
        });
        return { detail: `Finalised cross-provider transfer ${pay.payment.id} (£20.00 PIP-A -> PIP-B).`, data: pay };
      });

      // Step 6
      const qrPayId = await runStep(6, async () => {
        const pr = await apiFetch<{ id: string }>('/payment-requests', {
          method: 'POST',
          role: 'MERCHANT',
          body: { merchantWalletId: merchWalletId, amountPence: 1200, reference: 'Demo QR Order', singleUse: true },
        });
        const pay = await apiFetch<{ payment: { id: string } }>('/payments', {
          method: 'POST',
          role: 'PIP_A',
          body: {
            payerWalletId: custWalletId,
            payeeWalletId: merchWalletId,
            amountPence: 1200,
            paymentReference: 'Demo QR Order',
            paymentRequestId: pr.id,
            idempotencyKey: `demo-qr-${Date.now()}`,
          },
        });
        return { detail: `Created QR request ${pr.id} and paid £12.00 via ${pay.payment.id}.`, data: pay.payment.id };
      });

      // Step 7
      await runStep(7, async () => {
        const retryKey = `demo-retry-${Date.now()}`;
        let gotTimeout = false;
        try {
          await apiFetch('/payments', {
            method: 'POST',
            role: 'PIP_A',
            body: {
              payerWalletId: custWalletId,
              payeeWalletId: merchWalletId,
              amountPence: 500,
              paymentReference: 'Demo timeout-recovery tx',
              idempotencyKey: retryKey,
              simulateTimeoutAfterCommit: true,
            },
          });
        } catch {
          gotTimeout = true;
        }
        const replay = await apiFetch<{ payment: { id: string }; idempotentReplay: boolean }>('/payments', {
          method: 'POST',
          role: 'PIP_A',
          body: {
            payerWalletId: custWalletId,
            payeeWalletId: merchWalletId,
            amountPence: 500,
            paymentReference: 'Demo timeout-recovery tx',
            idempotencyKey: retryKey,
          },
        });
        if (!gotTimeout || !replay.idempotentReplay) throw new Error('Retry did not verify idempotency');
        return { detail: `Timeout simulated; retry returned ${replay.payment.id} with idempotentReplay=true.`, data: replay };
      });

      // Step 8
      await runStep(8, async () => {
        const ref = await apiFetch<{ refundPayment: { id: string } }>('/refunds', {
          method: 'POST',
          role: 'MERCHANT',
          body: { originalPaymentId: qrPayId, refundAmountPence: 400, reason: 'Demo partial refund' },
        });
        return { detail: `Issued £4.00 partial refund (${ref.refundPayment.id}) against ${qrPayId}.`, data: ref };
      });

      // Step 9
      await runStep(9, async () => {
        const red = await apiFetch<{ id: string }>('/issuer/redemption-requests', {
          method: 'POST',
          role: 'ISSUER',
          body: { amountPence: 5000, notes: 'Guided demo redemption retirement' },
        });
        await apiFetch(`/issuer/requests/${red.id}/transition`, { method: 'POST', role: 'ISSUER', actorId: 'val_1', body: { action: 'VALIDATE' } });
        await apiFetch(`/issuer/requests/${red.id}/transition`, { method: 'POST', role: 'ISSUER', actorId: 'auth_1', body: { action: 'APPROVE_1' } });
        await apiFetch(`/issuer/requests/${red.id}/transition`, { method: 'POST', role: 'ISSUER_SECOND_APPROVER', actorId: 'auth_2', body: { action: 'APPROVE_2' } });
        await apiFetch(`/issuer/requests/${red.id}/transition`, {
          method: 'POST',
          role: 'ISSUER',
          body: { action: 'VERIFY_SETTLEMENT_AND_POST', settlementEvidenceRef: `DEMO-RED-${Date.now()}` },
        });
        await apiFetch(`/issuer/requests/${red.id}/transition`, { method: 'POST', role: 'AUDITOR', body: { action: 'RECONCILE' } });
        return { detail: `Redeemed & retired £50.00 (${red.id}) cleanly.`, data: red.id };
      });

      // Step 10
      await runStep(10, async () => {
        const py = await apiFetch<{ ok: boolean; supplyDiscrepancyPence: number; journalEntriesVerified: number }>('/ops/run-python-reconcile', {
          method: 'POST',
          role: 'AUDITOR',
        });
        setPythonRecon(py);
        if (!py.ok) throw new Error('Python reconciliation detected imbalance');
        return {
          detail: `Python 3 verifier checked ${py.journalEntriesVerified} journal entries: 0p discrepancy.`,
          data: py,
        };
      });

      // Step 11
      await runStep(11, async () => {
        const h = await apiFetch<{ invariants: { supplyBalanced: boolean; doubleEntryBalanced: boolean } }>('/health');
        return { detail: `SQLite WAL persisted; invariants healthy (${JSON.stringify(h.invariants)}).`, data: h };
      });

      // Step 12
      await runStep(12, async () => {
        const bk = await apiFetch<{ filename: string; sizeBytes: number }>('/ops/backups', { method: 'POST', role: 'OPERATOR' });
        const rst = await apiFetch<{ restoredFrom: string; reconciliation: { discrepancyPence: number } }>('/ops/restore', {
          method: 'POST',
          role: 'OPERATOR',
          body: { filename: bk.filename },
        });
        return {
          detail: `Created backup ${bk.filename} (${bk.sizeBytes} bytes), validated, and restored with ${rst.reconciliation.discrepancyPence}p discrepancy.`,
          data: rst,
        };
      });

      await onRefresh();
    } catch (err) {
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'Guided demonstration halted' });
    } finally {
      setDemoRunning(false);
    }
  };

  const handleRunTestsAndBenchmark = async () => {
    setTestsRunning(true);
    setNotice(null);
    try {
      const res = await apiFetch<NonNullable<typeof testSuiteOutput>>('/ops/run-tests-and-benchmark', {
        method: 'POST',
        role: 'OPERATOR',
      });
      setTestSuiteOutput(res);
      await onRefresh();
    } catch (err) {
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'Test & benchmark execution failed' });
    } finally {
      setTestsRunning(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#DDD7C8] pb-4">
        <div>
          <h2 className="text-2xl font-semibold text-[#0F213B]">
            Operations, Guided Demonstration &amp; Benchmarks
          </h2>
          <p className="text-sm text-[#4B5563] mt-1">
            End-to-end 12-step verification, automated security/invariant suite, Python 3 reconciliation, backups, and
            fraud monitoring.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={demoRunning}
            onClick={runFullGuidedDemo}
            className="inline-flex items-center gap-2 px-4 py-2 bg-[#0F213B] text-[#FAF8F3] text-xs font-medium hover:bg-[#193257] cursor-pointer disabled:opacity-50"
          >
            <Play className="w-3.5 h-3.5" />
            <span>{demoRunning ? 'Running 12-Step Demo...' : 'Execute 12-Step Demonstration'}</span>
          </button>
          <button
            type="button"
            disabled={testsRunning}
            onClick={handleRunTestsAndBenchmark}
            className="inline-flex items-center gap-2 px-4 py-2 border border-[#0F213B] text-[#0F213B] text-xs font-medium hover:bg-[#F2EFE7] cursor-pointer disabled:opacity-50"
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>{testsRunning ? 'Running Tests & Python Load...' : 'Run 12 Tests & Python Benchmark'}</span>
          </button>
        </div>
      </div>

      {notice && (
        <div
          className={`p-4 border text-sm ${
            notice.kind === 'ok'
              ? 'bg-[#F0FDF4] border-[#BBF7D0] text-[#166534]'
              : 'bg-[#FEF2F2] border-[#FECACA] text-[#991B1B]'
          }`}
        >
          {notice.text}
        </div>
      )}

      {/* 12-Step Guided Demonstration Checklist */}
      <section className="bg-white border border-[#DDD7C8] p-6 space-y-4">
        <h3 className="text-base font-semibold text-[#0F213B]">12-Step End-to-End Platform Demonstration</h3>
        <div className="divide-y divide-[#DDD7C8]">
          {demoSteps.map((s) => (
            <div key={s.step} className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <div className="flex items-start gap-2.5">
                <span className="font-mono font-semibold text-[#9A7B3E] w-6 shrink-0">
                  {String(s.step).padStart(2, '0')}.
                </span>
                <div>
                  <div className="font-medium text-[#0F213B]">{s.title}</div>
                  {s.detail && <div className="font-mono text-[#4B5563] mt-0.5">{s.detail}</div>}
                </div>
              </div>
              <div className="font-mono shrink-0 flex items-center gap-1.5">
                {s.status === 'PASSED' && <CheckCircle2 className="w-4 h-4 text-[#166534]" />}
                {s.status === 'FAILED' && <XCircle className="w-4 h-4 text-[#991B1B]" />}
                <span
                  className={
                    s.status === 'PASSED'
                      ? 'text-[#166534] font-semibold'
                      : s.status === 'FAILED'
                      ? 'text-[#991B1B] font-semibold'
                      : 'text-[#6E6758]'
                  }
                >
                  {s.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Automated Tests & Python Load Benchmark Results */}
      {testSuiteOutput && (
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7 bg-white border border-[#DDD7C8] p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-semibold text-[#0F213B]">
                Automated Verification Suite ({testSuiteOutput.tests.passed}/{testSuiteOutput.tests.total} Passed)
              </h3>
              <span className="font-mono text-xs text-[#6E6758]">{testSuiteOutput.tests.durationMs} ms</span>
            </div>
            <div className="divide-y divide-[#DDD7C8] text-xs">
              {testSuiteOutput.tests.results.map((r, i) => (
                <div key={i} className="py-2.5 flex items-start justify-between gap-3">
                  <div>
                    <div className="font-medium text-[#0F213B]">
                      {r.name} · <span className="text-[#6E6758]">{r.category}</span>
                    </div>
                    <div className="font-mono text-[#4B5563] mt-0.5">{r.detail}</div>
                  </div>
                  <span className={`font-mono shrink-0 ${r.passed ? 'text-[#166534]' : 'text-[#991B1B]'}`}>
                    {r.passed ? 'PASS' : 'FAIL'} ({r.durationMs}ms)
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5 bg-white border border-[#DDD7C8] p-6 space-y-4">
            <h3 className="text-base font-semibold text-[#0F213B]">Actual Measured Local Benchmark (Python 3)</h3>
            <div className="space-y-3 text-xs">
              <div className="p-3 bg-[#FAF8F3] border border-[#DDD7C8] font-mono space-y-1">
                <div className="font-semibold text-[#0F213B]">Read Balance Workload</div>
                <div>
                  Throughput: {testSuiteOutput.benchmark.readBenchmark.throughputRps} req/s · p50:{' '}
                  {testSuiteOutput.benchmark.readBenchmark.p50Ms}ms · p95:{' '}
                  {testSuiteOutput.benchmark.readBenchmark.p95Ms}ms · p99:{' '}
                  {testSuiteOutput.benchmark.readBenchmark.p99Ms}ms
                </div>
              </div>
              <div className="p-3 bg-[#FAF8F3] border border-[#DDD7C8] font-mono space-y-1">
                <div className="font-semibold text-[#0F213B]">Concurrent Write Payment Workload</div>
                <div>
                  Throughput: {testSuiteOutput.benchmark.writePaymentBenchmark.throughputTps} tx/s · p50:{' '}
                  {testSuiteOutput.benchmark.writePaymentBenchmark.p50Ms}ms · p95:{' '}
                  {testSuiteOutput.benchmark.writePaymentBenchmark.p95Ms}ms · p99:{' '}
                  {testSuiteOutput.benchmark.writePaymentBenchmark.p99Ms}ms
                </div>
              </div>
              <div className="p-3 bg-[#FAF8F3] border border-[#DDD7C8] font-mono space-y-1">
                <div className="font-semibold text-[#0F213B]">Hardware &amp; Durability Context</div>
                <div>Durability: {String(testSuiteOutput.benchmark.environment.durability)}</div>
                <div>
                  Concurrency: {String(testSuiteOutput.benchmark.environment.concurrency)} workers · Discrepancy:{' '}
                  {String(testSuiteOutput.benchmark.postLoadReconciliation.discrepancyPence)}p
                </div>
              </div>
              <p className="text-[#6E6758]">{testSuiteOutput.benchmark.disclaimer}</p>
            </div>
          </div>
        </section>
      )}

      {/* Resilience Controls, Fraud Cases & Audit Log */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-5 bg-white border border-[#DDD7C8] p-6 space-y-4">
          <h3 className="text-base font-semibold text-[#0F213B]">Resilience, Key Rotation &amp; Backups</h3>
          <div className="text-xs font-mono text-[#4B5563]">
            Active HMAC Key: {snapshot.systemState.active_hmac_key_version} · Rate Limit:{' '}
            {snapshot.systemState.rate_limit_rpm} req/min
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={async () => {
                await apiFetch('/ops/rotate-key', { method: 'POST', role: 'OPERATOR' });
                await onRefresh();
                setNotice({ kind: 'ok', text: 'Rotated merchant payment-request HMAC key.' });
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-[#0F213B] text-xs font-medium cursor-pointer"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Rotate Signing Key</span>
            </button>
            <button
              type="button"
              onClick={async () => {
                const py = await apiFetch<Record<string, unknown>>('/ops/run-python-reconcile', {
                  method: 'POST',
                  role: 'AUDITOR',
                });
                setPythonRecon(py);
              }}
              className="px-3 py-1.5 border border-[#0F213B] text-xs font-medium cursor-pointer"
            >
              Run Python Reconciler
            </button>
            <button
              type="button"
              onClick={async () => {
                await apiFetch('/ops/fault-injection', {
                  method: 'POST',
                  role: 'OPERATOR',
                  body: { failNextBankPayout: true },
                });
                await onRefresh();
                setNotice({ kind: 'ok', text: 'Armed next redemption external payout failure fault.' });
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-[#991B1B] text-[#991B1B] text-xs font-medium cursor-pointer"
            >
              <ServerCrash className="w-3.5 h-3.5" />
              <span>Arm Bank Payout Fault</span>
            </button>
            <button
              type="button"
              onClick={async () => {
                const bk = await apiFetch<{ filename: string }>('/ops/backups', { method: 'POST', role: 'OPERATOR' });
                await onRefresh();
                setNotice({ kind: 'ok', text: `Created atomic backup ${bk.filename}.` });
              }}
              className="px-3 py-1.5 bg-[#0F213B] text-white text-xs font-medium cursor-pointer"
            >
              Create Backup Snapshot
            </button>
          </div>

          {pythonRecon && (
            <pre className="p-3 bg-[#FAF8F3] border border-[#DDD7C8] text-[11px] font-mono overflow-x-auto">
              {JSON.stringify(pythonRecon, null, 2)}
            </pre>
          )}

          <div className="space-y-2 border-t border-[#DDD7C8] pt-3">
            <div className="text-xs font-semibold text-[#0F213B]">Available Atomic Backups</div>
            {snapshot.backups.length === 0 && <div className="text-xs text-[#6E6758]">No snapshots yet.</div>}
            {snapshot.backups.slice(0, 5).map((b) => (
              <div key={b.filename} className="flex items-center justify-between text-xs font-mono">
                <span>
                  {b.filename} ({Math.round(b.sizeBytes / 1024)} KB)
                </span>
                <button
                  type="button"
                  onClick={async () => {
                    await apiFetch('/ops/restore', {
                      method: 'POST',
                      role: 'OPERATOR',
                      body: { filename: b.filename },
                    });
                    await onRefresh();
                    setNotice({ kind: 'ok', text: `Restored and validated ${b.filename}.` });
                  }}
                  className="text-[#0F213B] underline cursor-pointer"
                >
                  Restore
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Fraud Signal Review Queue & Audit Events */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white border border-[#DDD7C8] p-6 space-y-3">
            <h3 className="text-base font-semibold text-[#0F213B]">
              Transaction Monitoring Signals &amp; Proportionate Review
            </h3>
            <p className="text-xs text-[#4B5563]">
              Monitoring rules record signals separately from conclusions of wrongdoing. Automated models never create
              money, alter balances, or approve interventions.
            </p>
            {snapshot.fraudCases.length === 0 && (
              <p className="text-xs text-[#6E6758]">
                No monitoring signals triggered (transfers exceeding £2,500 generate a review signal).
              </p>
            )}
            <div className="divide-y divide-[#DDD7C8]">
              {snapshot.fraudCases.slice(0, 5).map((fc) => (
                <div key={fc.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                  <div>
                    <div className="font-semibold text-[#0F213B]">
                      {fc.signalType} · {fc.status}
                    </div>
                    <div className="text-[#4B5563]">{fc.signalSummary}</div>
                  </div>
                  <div className="flex gap-1.5 shrink-0">
                    {fc.status !== 'CLEARED' && (
                      <button
                        type="button"
                        onClick={async () => {
                          await apiFetch(`/fraud-cases/${fc.id}/transition`, {
                            method: 'POST',
                            role: 'OPERATOR',
                            body: { status: 'CLEARED', resolutionNotes: 'Reviewed and cleared by compliance analyst' },
                          });
                          await onRefresh();
                        }}
                        className="px-2.5 py-1 bg-[#166534] text-white cursor-pointer"
                      >
                        Clear Signal
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white border border-[#DDD7C8] p-6 space-y-3">
            <h3 className="text-base font-semibold text-[#0F213B]">Immutable Redacted Audit Log</h3>
            <div className="max-h-64 overflow-y-auto divide-y divide-[#DDD7C8] text-xs">
              {snapshot.auditEvents.slice(0, 20).map((ae) => (
                <div key={ae.id} className="py-2 flex justify-between gap-4">
                  <div>
                    <span className="font-mono font-semibold text-[#0F213B]">{ae.action}</span>{' '}
                    <span className="text-[#6E6758]">
                      by {ae.actorRole} ({ae.actorId})
                    </span>
                    <div className="text-[#364152]">{ae.detailsRedacted}</div>
                  </div>
                  <span className="font-mono text-[#6E6758] shrink-0">
                    {ae.createdAt ? `${ae.createdAt.slice(11, 19)}Z` : '—'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
