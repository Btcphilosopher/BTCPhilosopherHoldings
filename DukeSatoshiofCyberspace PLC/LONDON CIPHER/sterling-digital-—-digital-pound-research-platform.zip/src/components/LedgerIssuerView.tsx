import { useState } from 'react';
import { Eye, Lock, ShieldCheck, Sliders } from 'lucide-react';
import { apiFetch, formatGBP, parsePoundsToPence, type PlatformSnapshot } from '../lib/api';

interface Props {
  snapshot: PlatformSnapshot;
  onRefresh: () => Promise<void>;
}

export function LedgerIssuerView({ snapshot, onRefresh }: Props) {
  const [issKind, setIssKind] = useState<'ISSUANCE' | 'REDEMPTION'>('ISSUANCE');
  const [issAmountGbp, setIssAmountGbp] = useState('1000.00');
  const [issNotes, setIssNotes] = useState('Routine experimental liquidity tranche');
  const [settlementRefs, setSettlementRefs] = useState<Record<string, string>>({});

  // Policy configuration editor
  const [policyLabel, setPolicyLabel] = useState('Research Policy Revision');
  const [holdingLimitGbp, setHoldingLimitGbp] = useState(
    snapshot.policy.holdingLimitPence ? (snapshot.policy.holdingLimitPence / 100).toFixed(2) : ''
  );
  const [txLimitGbp, setTxLimitGbp] = useState(
    snapshot.policy.txLimitPence ? (snapshot.policy.txLimitPence / 100).toFixed(2) : ''
  );
  const [feeBps, setFeeBps] = useState(String(snapshot.policy.feeBps));
  const [recoveryModel, setRecoveryModel] = useState(snapshot.policy.recoveryModel);

  const [notice, setNotice] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  const [subView, setSubView] = useState<'issuer' | 'ledger' | 'privacy' | 'policy'>('issuer');

  const handleCreateIssuance = async (e: React.FormEvent) => {
    e.preventDefault();
    setNotice(null);
    try {
      const amountPence = parsePoundsToPence(issAmountGbp);
      const endpoint = issKind === 'ISSUANCE' ? '/issuer/issuance-requests' : '/issuer/redemption-requests';
      const created = await apiFetch<{ id: string }>(endpoint, {
        method: 'POST',
        role: 'ISSUER',
        actorId: 'issuer_treasury_ops',
        body: { amountPence, notes: issNotes },
      });
      await onRefresh();
      setNotice({ kind: 'ok', text: `Created ${issKind} request ${created.id} in REQUESTED state.` });
    } catch (err) {
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'Request failed' });
    }
  };

  const handleTransition = async (
    id: string,
    action: 'VALIDATE' | 'APPROVE_1' | 'APPROVE_2' | 'VERIFY_SETTLEMENT_AND_POST' | 'RECONCILE' | 'FAIL_EXTERNAL_PAYOUT'
  ) => {
    setNotice(null);
    try {
      const role = action === 'APPROVE_2' ? 'ISSUER_SECOND_APPROVER' : action === 'RECONCILE' ? 'AUDITOR' : 'ISSUER';
      const actorId =
        action === 'APPROVE_1'
          ? 'issuer_authority_alpha'
          : action === 'APPROVE_2'
          ? 'issuer_authority_beta'
          : action === 'RECONCILE'
          ? 'independent_auditor_01'
          : 'issuer_validator_01';

      const settlementEvidenceRef =
        action === 'VERIFY_SETTLEMENT_AND_POST'
          ? settlementRefs[id] || `RTGS-SIM-${id.toUpperCase()}-${Date.now().toString().slice(-4)}`
          : undefined;

      await apiFetch(`/issuer/requests/${id}/transition`, {
        method: 'POST',
        role,
        actorId,
        body: { action, settlementEvidenceRef },
      });
      await onRefresh();
      setNotice({ kind: 'ok', text: `${id} transitioned via ${action}.` });
    } catch (err) {
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'Transition failed' });
    }
  };

  const handleRbacProbe = async () => {
    setNotice(null);
    try {
      await apiFetch('/issuer/issuance-requests', {
        method: 'POST',
        role: 'PIP_A',
        actorId: 'ordinary_wallet_user',
        body: { amountPence: 50000, notes: 'Unauthorised mint attempt' },
      });
      setNotice({ kind: 'err', text: 'WARNING: Wallet credential was unexpectedly permitted!' });
    } catch (err) {
      const e = err as Error & { code?: string; status?: number };
      setNotice({
        kind: 'ok',
        text: `RBAC Guard Verified (HTTP ${e.status ?? 403} ${e.code}): ${e.message}`,
      });
    }
  };

  const handlePublishPolicy = async (e: React.FormEvent) => {
    e.preventDefault();
    setNotice(null);
    try {
      const next = await apiFetch<{ version: number; label: string }>('/policy', {
        method: 'POST',
        role: 'ISSUER',
        actorId: 'policy_committee_sim',
        body: {
          label: policyLabel,
          holdingLimitPence: holdingLimitGbp.trim() ? parsePoundsToPence(holdingLimitGbp) : null,
          txLimitPence: txLimitGbp.trim() ? parsePoundsToPence(txLimitGbp) : null,
          remunerationEnabled: false,
          remunerationRateBps: 0,
          feeBps: Number(feeBps),
          recoveryModel,
        },
      });
      await onRefresh();
      setNotice({ kind: 'ok', text: `Published Policy v${next.version}: ${next.label}.` });
    } catch (err) {
      setNotice({ kind: 'err', text: err instanceof Error ? err.message : 'Policy update failed' });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#DDD7C8] pb-4">
        <div>
          <h2 className="text-2xl font-semibold text-[#0F213B]">Core Ledger, Issuer Authority &amp; Privacy</h2>
          <p className="text-sm text-[#4B5563] mt-1">
            Balanced double-entry accounting in integer pence, dual-control issuance/redemption, and structural PII
            isolation.
          </p>
        </div>

        <div className="flex flex-wrap gap-1 p-1 bg-[#F2EFE7] border border-[#DDD7C8]">
          {(
            [
              ['issuer', 'Issuance & Redemption'],
              ['ledger', 'Double-Entry Ledger'],
              ['privacy', 'Privacy Boundaries'],
              ['policy', 'Policy Governance'],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setSubView(id)}
              className={`px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                subView === id ? 'bg-[#0F213B] text-[#FAF8F3]' : 'text-[#364152] hover:text-[#0F213B]'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {notice && (
        <div
          className={`p-4 border text-sm ${
            notice.kind === 'ok'
              ? 'bg-[#F0FDF4] border-[#BBF7D0] text-[#166534]'
              : 'bg-[#FEF2F2] border-[#FECACA] text-[#991B1B]'
          }`}
        >
          {notice.text}
        </div>
      )}

      {/* 1. ISSUANCE & REDEMPTION */}
      {subView === 'issuer' && (
        <div className="space-y-6">
          <div className="bg-white border border-[#DDD7C8] p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h3 className="text-base font-semibold text-[#0F213B] inline-flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#9A7B3E]" />
                Initiate Issuance or Redemption (Issuer Authority Only)
              </h3>
              <button
                type="button"
                onClick={handleRbacProbe}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-[#991B1B] text-[#991B1B] text-xs font-medium hover:bg-[#FEF2F2] cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Test Ordinary Wallet Access (Expect 403)</span>
              </button>
            </div>

            <form onSubmit={handleCreateIssuance} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
              <div>
                <label className="block text-xs font-medium mb-1">Operation Kind</label>
                <select
                  value={issKind}
                  onChange={(e) => setIssKind(e.target.value as 'ISSUANCE' | 'REDEMPTION')}
                  className="w-full border border-[#DDD7C8] px-3 py-2 text-sm bg-[#FAF8F3]"
                >
                  <option value="ISSUANCE">Issuance (Create Units)</option>
                  <option value="REDEMPTION">Redemption (Retire Units)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Amount (GBP)</label>
                <input
                  value={issAmountGbp}
                  onChange={(e) => setIssAmountGbp(e.target.value)}
                  className="w-full border border-[#DDD7C8] px-3 py-2 text-sm font-mono bg-[#FAF8F3]"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Authority Reference / Notes</label>
                <input
                  value={issNotes}
                  onChange={(e) => setIssNotes(e.target.value)}
                  className="w-full border border-[#DDD7C8] px-3 py-2 text-sm bg-[#FAF8F3]"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2 bg-[#0F213B] text-[#FAF8F3] text-sm font-medium hover:bg-[#193257] cursor-pointer"
              >
                Submit Request
              </button>
            </form>
          </div>

          <div className="bg-white border border-[#DDD7C8] p-6 space-y-4">
            <h3 className="text-base font-semibold text-[#0F213B]">
              Dual-Approval Pipeline (Requested → Validated → Approved → Verified &amp; Posted → Reconciled)
            </h3>
            <div className="divide-y divide-[#DDD7C8]">
              {snapshot.issuanceRequests.map((req) => (
                <div key={req.id} className="py-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="text-sm font-semibold text-[#0F213B]">
                      {req.kind} · <span className="font-mono">{formatGBP(req.amountPence)}</span> · {req.state}
                    </div>
                    <div className="text-xs font-mono text-[#6E6758]">
                      {req.id} · Approver1: {req.approver1Id ?? 'pending'} · Approver2: {req.approver2Id ?? 'pending'} ·
                      Evidence: {req.settlementEvidenceRef ?? 'none'}
                    </div>
                    <div className="text-xs text-[#4B5563]">{req.notes}</div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    {req.state === 'REQUESTED' && (
                      <button
                        type="button"
                        onClick={() => handleTransition(req.id, 'VALIDATE')}
                        className="px-3 py-1.5 bg-[#0F213B] text-white text-xs font-medium cursor-pointer"
                      >
                        Validate
                      </button>
                    )}
                    {req.state === 'VALIDATED' && !req.approver1Id && (
                      <button
                        type="button"
                        onClick={() => handleTransition(req.id, 'APPROVE_1')}
                        className="px-3 py-1.5 bg-[#0F213B] text-white text-xs font-medium cursor-pointer"
                      >
                        Approve (Authority 1)
                      </button>
                    )}
                    {req.state === 'VALIDATED' && req.approver1Id && !req.approver2Id && (
                      <button
                        type="button"
                        onClick={() => handleTransition(req.id, 'APPROVE_2')}
                        className="px-3 py-1.5 bg-[#9A7B3E] text-white text-xs font-medium cursor-pointer"
                      >
                        Dual-Approve (Authority 2)
                      </button>
                    )}
                    {req.state === 'APPROVED' && (
                      <>
                        <input
                          placeholder="RTGS Settlement Ref"
                          value={settlementRefs[req.id] ?? ''}
                          onChange={(e) => setSettlementRefs({ ...settlementRefs, [req.id]: e.target.value })}
                          className="border border-[#DDD7C8] px-2.5 py-1 text-xs font-mono w-40"
                        />
                        <button
                          type="button"
                          onClick={() => handleTransition(req.id, 'VERIFY_SETTLEMENT_AND_POST')}
                          className="px-3 py-1.5 bg-[#166534] text-white text-xs font-medium cursor-pointer"
                        >
                          Verify Settlement &amp; Post
                        </button>
                        {req.kind === 'REDEMPTION' && (
                          <button
                            type="button"
                            onClick={() => handleTransition(req.id, 'FAIL_EXTERNAL_PAYOUT')}
                            className="px-3 py-1.5 border border-[#991B1B] text-[#991B1B] text-xs font-medium cursor-pointer"
                          >
                            Simulate Payout Failure
                          </button>
                        )}
                      </>
                    )}
                    {req.state === 'POSTED' && (
                      <button
                        type="button"
                        onClick={() => handleTransition(req.id, 'RECONCILE')}
                        className="px-3 py-1.5 border border-[#0F213B] text-[#0F213B] text-xs font-medium cursor-pointer"
                      >
                        Auditor Reconcile
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 2. DOUBLE-ENTRY LEDGER */}
      {subView === 'ledger' && (
        <div className="space-y-6">
          <div className="bg-white border border-[#DDD7C8] p-6 space-y-4">
            <h3 className="text-base font-semibold text-[#0F213B]">
              Core Ledger Chart of Accounts (Opaque Identifiers Only)
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-[#DDD7C8] text-left text-[#6E6758]">
                    <th className="py-2 pr-3 font-medium">Opaque ID</th>
                    <th className="py-2 pr-3 font-medium">Code</th>
                    <th className="py-2 pr-3 font-medium">Class</th>
                    <th className="py-2 pr-3 font-medium">Normal Side</th>
                    <th className="py-2 pr-3 font-medium">Scope</th>
                    <th className="py-2 pr-3 font-medium text-right">Available (GBP)</th>
                    <th className="py-2 pr-3 font-medium text-right">Integer Pence</th>
                    <th className="py-2 font-medium text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#DDD7C8]">
                  {snapshot.accounts.map((a) => (
                    <tr key={a.id} className="hover:bg-[#FAF8F3]">
                      <td className="py-2 pr-3 font-mono">{a.id}</td>
                      <td className="py-2 pr-3 font-mono text-[#6E6758]">{a.accountCode}</td>
                      <td className="py-2 pr-3">{a.accountClass}</td>
                      <td className="py-2 pr-3 font-mono">{a.normalSide}</td>
                      <td className="py-2 pr-3 font-mono">{a.pipId ?? 'CORE'}</td>
                      <td className="py-2 pr-3 font-mono text-right tabular-nums font-medium">
                        {formatGBP(a.availablePence)}
                      </td>
                      <td className="py-2 pr-3 font-mono text-right tabular-nums text-[#6E6758]">
                        {a.availablePence.toLocaleString()}p
                      </td>
                      <td className="py-2 font-mono text-right">{a.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white border border-[#DDD7C8] p-6 space-y-4">
            <h3 className="text-base font-semibold text-[#0F213B]">Immutable Balanced Journal Entries</h3>
            <div className="divide-y divide-[#DDD7C8]">
              {snapshot.journalEntries.slice(0, 15).map((je) => (
                <div key={je.id} className="py-3 space-y-1.5">
                  <div className="flex flex-wrap items-center justify-between text-xs">
                    <span className="font-mono font-semibold text-[#0F213B]">
                      {je.id} · {je.txType}
                    </span>
                    <span className="font-mono text-[#6E6758]">{je.createdAt}</span>
                  </div>
                  <div className="text-xs text-[#364152]">{je.reference}</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {je.postings.map((p) => (
                      <div key={p.id} className="text-xs font-mono bg-[#FAF8F3] px-2.5 py-1 border border-[#DDD7C8] flex justify-between">
                        <span>
                          {p.direction} {p.accountId}
                        </span>
                        <span className="tabular-nums">{formatGBP(p.amountPence)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 3. PRIVACY BOUNDARIES */}
      {subView === 'privacy' && (
        <div className="space-y-6">
          <div className="p-6 bg-white border border-[#DDD7C8] space-y-2">
            <h3 className="text-base font-semibold text-[#0F213B] inline-flex items-center gap-2">
              <Eye className="w-4 h-4 text-[#9A7B3E]" />
              Structural Privacy Separation &amp; Correlation Limitation Disclosure
            </h3>
            <p className="text-sm text-[#364152] leading-relaxed">
              Personal identity records (names, emails, synthetic NI identifiers, device keys) are stored solely in
              scoped PIP tables (<span className="font-mono text-xs">pip_customers</span>). The Core Ledger observes
              only opaque account codes (<span className="font-mono text-xs">OPQ-A-7104</span>). However, opaque
              identifiers alone do NOT prevent transaction-graph correlation at the Core Ledger layer; production
              privacy requires cryptographic unlinkability (e.g. blinded credentials or zero-knowledge proofs) backed
              by statutory data-blindness legislation.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="p-5 bg-white border border-[#DDD7C8] space-y-3">
              <h4 className="text-sm font-semibold text-[#0F213B]">Core Ledger Observes</h4>
              <div className="space-y-2 text-xs font-mono">
                {snapshot.accounts
                  .filter((a) => a.accountClass.startsWith('WALLET'))
                  .map((a) => (
                    <div key={a.id} className="p-2.5 bg-[#FAF8F3] border border-[#DDD7C8]">
                      <div>{a.id}</div>
                      <div className="text-[#6E6758]">
                        {a.accountCode} · {formatGBP(a.availablePence)} · NO PII
                      </div>
                    </div>
                  ))}
              </div>
            </div>

            <div className="p-5 bg-white border border-[#DDD7C8] space-y-3">
              <h4 className="text-sm font-semibold text-[#0F213B]">PIP-A (Thameside) Observes</h4>
              <div className="space-y-2 text-xs">
                {snapshot.pipCustomers
                  .filter((c) => c.pipId === 'PIP_A')
                  .map((c) => (
                    <div key={c.id} className="p-2.5 bg-[#FAF8F3] border border-[#DDD7C8]">
                      <div className="font-semibold text-[#0F213B]">{c.fullName}</div>
                      <div className="font-mono text-[#4B5563]">
                        {c.email} · {c.syntheticIdentityRef}
                      </div>
                      <div className="font-mono text-[#6E6758]">Wallet: {c.walletId}</div>
                    </div>
                  ))}
              </div>
            </div>

            <div className="p-5 bg-white border border-[#DDD7C8] space-y-3">
              <h4 className="text-sm font-semibold text-[#0F213B]">PIP-B (Albion Civic) Observes</h4>
              <div className="space-y-2 text-xs">
                {snapshot.pipCustomers
                  .filter((c) => c.pipId === 'PIP_B')
                  .map((c) => (
                    <div key={c.id} className="p-2.5 bg-[#FAF8F3] border border-[#DDD7C8]">
                      <div className="font-semibold text-[#0F213B]">{c.fullName}</div>
                      <div className="font-mono text-[#4B5563]">
                        {c.email} · {c.syntheticIdentityRef}
                      </div>
                      <div className="font-mono text-[#6E6758]">Wallet: {c.walletId}</div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. POLICY GOVERNANCE */}
      {subView === 'policy' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <form onSubmit={handlePublishPolicy} className="lg:col-span-6 bg-white border border-[#DDD7C8] p-6 space-y-4">
            <h3 className="text-base font-semibold text-[#0F213B] inline-flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#9A7B3E]" />
              Publish Versioned Policy Configuration (Active: v{snapshot.policy.version})
            </h3>
            <p className="text-xs text-[#4B5563]">
              Holding limits and transaction bounds are configurable prototype settings rather than hard-coded settled
              policy. Remuneration remains disabled (0 bps) per Bank of England consultation proposals, and no money
              expiry or state spending restrictions exist.
            </p>
            <div>
              <label className="block text-xs font-medium mb-1">Version Label</label>
              <input
                value={policyLabel}
                onChange={(e) => setPolicyLabel(e.target.value)}
                className="w-full border border-[#DDD7C8] px-3 py-2 text-sm bg-[#FAF8F3]"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium mb-1">Holding Limit (GBP, blank = none)</label>
                <input
                  value={holdingLimitGbp}
                  onChange={(e) => setHoldingLimitGbp(e.target.value)}
                  className="w-full border border-[#DDD7C8] px-3 py-2 text-sm font-mono bg-[#FAF8F3]"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Per-Tx Limit (GBP)</label>
                <input
                  value={txLimitGbp}
                  onChange={(e) => setTxLimitGbp(e.target.value)}
                  className="w-full border border-[#DDD7C8] px-3 py-2 text-sm font-mono bg-[#FAF8F3]"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium mb-1">Service Fee (bps, 0 = free)</label>
                <input
                  type="number"
                  min={0}
                  max={500}
                  value={feeBps}
                  onChange={(e) => setFeeBps(e.target.value)}
                  className="w-full border border-[#DDD7C8] px-3 py-2 text-sm font-mono bg-[#FAF8F3]"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Account Recovery Model</label>
                <select
                  value={recoveryModel}
                  onChange={(e) => setRecoveryModel(e.target.value as typeof recoveryModel)}
                  className="w-full border border-[#DDD7C8] px-3 py-2 text-sm bg-[#FAF8F3]"
                >
                  <option value="PIP_ASSISTED_WITH_COOLING_OFF">PIP Assisted + Cooling-Off</option>
                  <option value="MULTI_FACTOR_DEVICE_REBIND">Multi-Factor Device Rebind</option>
                </select>
              </div>
            </div>
            <button type="submit" className="px-4 py-2 bg-[#0F213B] text-white text-sm font-medium cursor-pointer">
              Publish Policy Version
            </button>
          </form>

          <div className="lg:col-span-6 bg-white border border-[#DDD7C8] p-6 space-y-4">
            <h3 className="text-base font-semibold text-[#0F213B]">Prototype Assumptions &amp; Version History</h3>
            <div className="space-y-2 text-xs">
              {Object.entries(snapshot.policy.prototypeAssumptions).map(([k, v]) => (
                <div key={k} className="p-3 bg-[#FAF8F3] border border-[#DDD7C8]">
                  <span className="font-mono font-semibold text-[#0F213B]">{k}: </span>
                  <span className="text-[#364152]">{v}</span>
                </div>
              ))}
            </div>
            <div className="divide-y divide-[#DDD7C8] border-t border-[#DDD7C8] pt-2 text-xs">
              {snapshot.policyHistory.map((ph) => (
                <div key={ph.version} className="py-2.5 flex justify-between gap-3">
                  <div>
                    <span className="font-mono font-semibold">v{ph.version}</span> · {ph.label}
                  </div>
                  <div className="font-mono text-[#6E6758] shrink-0">
                    Cap: {ph.holding_limit_pence ? formatGBP(ph.holding_limit_pence) : 'None'} · Fee: {ph.fee_bps}bps
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
