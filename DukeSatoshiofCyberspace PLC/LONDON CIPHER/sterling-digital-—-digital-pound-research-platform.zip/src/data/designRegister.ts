import type { DesignRegisterEntry } from '../types/cbdc';

export const DESIGN_REGISTER: DesignRegisterEntry[] = [
  {
    id: 'DR-01',
    topic: 'Platform Model (Public-Private Separation)',
    category: 'PUBLISHED_PROPOSAL',
    summary:
      'Bank of England operates the core ledger and settlement infrastructure; regulated private-sector Payment Interface Providers (PIPs) manage consumer relationships, wallets, KYC, and payment initiation.',
    rationale:
      'Joint Consultation Paper (Feb 2023) and Consultation Response (Jan 2024) confirmed the platform model over a direct state-run retail ledger to preserve competition and keep personal data out of the central bank.',
    sourceTitle: 'Bank of England & HM Treasury — The digital pound: Consultation Response (2024)',
    sourceUrl: 'https://www.bankofengland.co.uk/paper/2024/the-digital-pound-consultation-response',
    retrievedAt: '2026-11-18',
  },
  {
    id: 'DR-02',
    topic: 'No Final Decision to Issue & Primary Legislation Requirement',
    category: 'PUBLISHED_PROPOSAL',
    summary:
      'Neither the Bank of England nor HM Treasury has made a decision to issue a digital pound. Any future launch requires primary legislation and Parliamentary approval.',
    rationale:
      'Reinforced in the design phase progress updates and Digital Pound Lab programme: technical experimentation informs future blueprint decisions rather than pre-committing to issuance.',
    sourceTitle: 'Bank of England — The digital pound: Progress Update & Design Phase',
    sourceUrl: 'https://www.bankofengland.co.uk/the-digital-pound',
    retrievedAt: '2026-11-18',
  },
  {
    id: 'DR-03',
    topic: 'Individual Holding Limits & Automated Waterfall Sweeps',
    category: 'UNRESOLVED_POLICY',
    summary:
      'Consultations proposed introductory individual limits (£10,000–£20,000) to mitigate commercial bank disintermediation, with excess funds swept to a linked commercial bank account. Final calibration remains open.',
    rationale:
      'Must remain versioned and runtime-configurable. This platform models holding limits as a mutable policy setting (default £20,000 / 2,000,000 pence in v1) explicitly marked as a prototype parameter.',
    sourceTitle: 'Bank of England — The digital pound: Working Paper & Consultation (Feb 2023)',
    sourceUrl: 'https://www.bankofengland.co.uk/paper/2023/the-digital-pound-consultation-paper',
    retrievedAt: '2026-11-18',
  },
  {
    id: 'DR-04',
    topic: 'Zero Remuneration (Non-Interest Bearing)',
    category: 'PUBLISHED_PROPOSAL',
    summary:
      'Like physical banknotes, a digital pound would not pay interest so it serves as a means of payment rather than a savings vehicle competing with bank deposits.',
    rationale:
      'Policy configuration enforces remunerationEnabled=false by default while retaining a versioned configuration field so macroeconomic stress tests can simulate policy alternatives without rewriting ledger code.',
    sourceTitle: 'HM Treasury & Bank of England — Digital Pound Consultation Paper (2023)',
    sourceUrl: 'https://www.gov.uk/government/consultations/the-digital-pound-a-new-form-of-money-for-households-and-businesses',
    retrievedAt: '2026-11-18',
  },
  {
    id: 'DR-05',
    topic: 'Privacy Boundaries, Pseudonymity & Legislation',
    category: 'UNRESOLVED_POLICY',
    summary:
      'Government and Bank committed that primary legislation would bar Bank/government access to personal data. Exact cryptographic PETs (e.g. ZKP vs blinded credentials vs alias separation) remain under active research.',
    rationale:
      'This prototype enforces structural separation: PII resides solely in PIP-A / PIP-B schemas while the Core Ledger sees opaque account IDs. We explicitly document that opaque IDs alone do not prevent traffic correlation.',
    sourceTitle: 'Bank of England — Digital Pound Technology Working Paper & MIT DCI Research',
    sourceUrl: 'https://www.bankofengland.co.uk/paper/2023/the-digital-pound-technology-working-paper',
    retrievedAt: '2026-11-18',
  },
  {
    id: 'DR-06',
    topic: 'No Programmable Money / Government Spending Restrictions',
    category: 'PUBLISHED_PROPOSAL',
    summary:
      'The Bank and HM Treasury committed not to implement programmable restrictions or expiry dates controlled by the state or central bank on digital pound units.',
    rationale:
      'Ledger units are strictly fungible integer pence with no expiry or state spending rules. Optional conditional-payment workflows would be strictly user-authorised at the PIP layer.',
    sourceTitle: 'Bank of England — Design Notes & Consultation Response on Programmability',
    sourceUrl: 'https://www.bankofengland.co.uk/paper/2024/the-digital-pound-consultation-response',
    retrievedAt: '2026-11-18',
  },
  {
    id: 'DR-07',
    topic: 'Transactional Relational Core Ledger vs DLT',
    category: 'PROTOTYPE_ASSUMPTION',
    summary:
      'Implements an ACID serializable double-entry relational ledger in integer pence (with Rust core crate + SQLite live engine + PostgreSQL migration DDL) rather than a permissionless or consensus DLT.',
    rationale:
      'Matches the Bank’s Technology Working Paper observation that a central bank single-authority core does not require decentralised Byzantine consensus and achieves deterministic finality.',
    sourceTitle: 'Bank of England — The digital pound: Technology Working Paper (2023)',
    sourceUrl: 'https://www.bankofengland.co.uk/paper/2023/the-digital-pound-technology-working-paper',
    retrievedAt: '2026-11-18',
  },
  {
    id: 'DR-08',
    topic: 'Cross-Provider Holding Limit Enforcement Tradeoff',
    category: 'PROTOTYPE_ASSUMPTION',
    summary:
      'Cross-wallet limit checks can either leak identity linkage to the core ledger or rely on privacy-preserving attested limit tokens across PIPs. Prototype uses a scoped synthetic identity hash check at conversion/transfer time.',
    rationale:
      'Explicitly surfaced in Policy Governance so evaluators can inspect the privacy vs limit-enforcement tradeoff without silently centralising raw personal data in the Core Ledger.',
    sourceTitle: 'Bank of England — Digital Pound Design Notes & Lab Architecture',
    sourceUrl: 'https://www.bankofengland.co.uk/the-digital-pound',
    retrievedAt: '2026-11-18',
  },
  {
    id: 'DR-09',
    topic: 'Dual-Approval Issuance, Two-Stage Payments & Staged Conversion',
    category: 'IMPLEMENTED_FUNCTIONALITY',
    summary:
      'Full working implementation of balanced double-entry ledger, dual-authority issuance/redemption, two-phase reserve/finalise payments, HMAC-signed single-use merchant QR requests, idempotency, backup/restore, and Python reconciliation.',
    rationale:
      'Operational across the live TypeScript/SQLite engine and mirrored in the Rust core crate, PostgreSQL migrations, Kotlin/Compose Android reference app, and OpenAPI 3.1 contract.',
    sourceTitle: 'Sterling Digital — Platform Architecture Specification',
    sourceUrl: 'https://www.bankofengland.co.uk/the-digital-pound',
    retrievedAt: '2026-11-18',
  },
  {
    id: 'DR-10',
    topic: 'Offline Payments Research Boundary',
    category: 'IMPLEMENTED_FUNCTIONALITY',
    summary:
      'Isolated experimental module distinguishing queued offline instructions from locally settled hardware-backed claims, stating double-spend exposure and replay limits without overclaiming offline finality.',
    rationale:
      'Bank of England offline research notes highlight strict dependence on tamper-resistant Secure Elements (SE/TEE) and deferred reconciliation risk.',
    sourceTitle: 'Bank of England — Offline Payments Design Considerations',
    sourceUrl: 'https://www.bankofengland.co.uk/paper/2023/the-digital-pound-technology-working-paper',
    retrievedAt: '2026-11-18',
  },
  {
    id: 'DR-11',
    topic: 'RTGS / CHAPS & Faster Payments Interoperability',
    category: 'FUTURE_INTEGRATION',
    summary:
      'Production deployment would integrate with the Bank of England RTGS renewal (ISO 20022) and Faster Payments / Pay.UK rails for commercial-bank deposit conversion and settlement.',
    rationale:
      'Replaced here by a deterministic Simulated Commercial-Bank Gateway that models external settlement evidence, duplicate callbacks, payout failures, and stage recovery.',
    sourceTitle: 'Bank of England — RTGS Renewal Programme & National Payments Vision',
    sourceUrl: 'https://www.bankofengland.co.uk/payment-and-settlement/rtgs-renewal-programme',
    retrievedAt: '2026-11-18',
  },
  {
    id: 'DR-12',
    topic: 'FCA / PRA Regulatory Regime & Statutory Privacy Guarantee',
    category: 'FUTURE_INTEGRATION',
    summary:
      'Real-world PIP licensing, safeguarding, consumer duty, AML/CTF supervision, and statutory data-blindness mandates require UK Parliamentary legislation and FCA/PRA rulebooks.',
    rationale:
      'Synthetic identities and simulated sterling in this system do not constitute legal tender, regulated e-money, or authorised Bank of England payment services.',
    sourceTitle: 'HM Treasury — National Payments Vision & Legislative Framework',
    sourceUrl: 'https://www.gov.uk/government/publications/national-payments-vision',
    retrievedAt: '2026-11-18',
  },
];
