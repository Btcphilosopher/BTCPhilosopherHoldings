"""
benchmarks/benchmark_runner.py
───────────────────────────────
Direct (non-HTTP) benchmark suite.  Run with:

    cd lightning_rss
    python -m benchmarks.benchmark_runner

Measures
────────
  1. ChaCha20-Poly1305 encryption throughput (vary content size)
  2. Key derivation (HKDF) latency
  3. RSS XML generation time (public vs premium)
  4. Invoice creation latency (mock backend)
"""
from __future__ import annotations

import asyncio
import os
import sys
import time

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# ── Minimal settings bootstrap (no .env needed for benchmarks) ─────────────────
os.environ.setdefault("LIGHTNING_BACKEND", "mock")
import base64
os.environ.setdefault("MASTER_ENCRYPTION_KEY", base64.b64encode(os.urandom(32)).decode())


def print_section(title: str) -> None:
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


def print_row(label: str, value: str, unit: str = "") -> None:
    print(f"  {label:<40} {value:>12} {unit}")


# ── 1. Encryption benchmark ────────────────────────────────────────────────────

def bench_encryption() -> None:
    print_section("ChaCha20-Poly1305 Encryption Benchmark")
    from app.services.crypto import benchmark_encryption

    for size in [256, 1_024, 4_096, 16_384, 65_536]:
        content = "X" * size
        result = benchmark_encryption(content, iterations=1000)
        print(f"\n  Content size: {size:,} bytes")
        print_row("  Encrypt avg", f"{result['encrypt_avg_ms']:.4f}", "ms/op")
        print_row("  Decrypt avg", f"{result['decrypt_avg_ms']:.4f}", "ms/op")
        print_row("  Encrypt throughput", f"{result['throughput_enc_ops_per_sec']:,.0f}", "ops/s")
        print_row("  Decrypt throughput", f"{result['throughput_dec_ops_per_sec']:,.0f}", "ops/s")


# ── 2. Key derivation benchmark ────────────────────────────────────────────────

def bench_key_derivation() -> None:
    print_section("HKDF Key Derivation Benchmark")
    from app.services.crypto import derive_subscriber_key

    iterations = 1000
    raw_key = os.urandom(32)
    feed_id = "bench-feed-id-1234"

    start = time.perf_counter()
    for _ in range(iterations):
        derive_subscriber_key(raw_key, feed_id)
    elapsed = (time.perf_counter() - start) * 1000

    print_row("  Iterations", str(iterations))
    print_row("  Total time", f"{elapsed:.2f}", "ms")
    print_row("  Avg per derivation", f"{elapsed/iterations:.4f}", "ms")
    print_row("  Throughput", f"{iterations/(elapsed/1000):,.0f}", "ops/s")


# ── 3. RSS feed generation benchmark ──────────────────────────────────────────

def bench_rss_generation() -> None:
    print_section("RSS Feed Generation Benchmark")
    from datetime import datetime, timezone
    from unittest.mock import MagicMock
    from app.services.crypto import generate_feed_content_key, encrypt_content
    from app.services.rss_generator import generate_rss_feed
    from app.database import FeedType

    # Build mock feed + items
    feed = MagicMock()
    feed.id = "bench-feed-001"
    feed.title = "Benchmark Feed"
    feed.description = "A test feed"
    feed.link = "https://example.com"
    feed.language = "en"
    feed.feed_type = FeedType.PREMIUM
    feed.price_sats = 1000
    feed.subscription_days = 30

    full_article = "Lorem ipsum dolor sit amet. " * 200  # ~5.6KB per article
    key = generate_feed_content_key()

    items = []
    for i in range(20):
        item = MagicMock()
        item.id = f"item-{i:04d}"
        item.guid = f"https://example.com/article/{i}"
        item.title = f"Article {i}"
        item.link = f"https://example.com/article/{i}"
        item.author = "Test Author"
        item.summary = "Article teaser text."
        item.content_encrypted = encrypt_content(full_article, key)
        item.content_plain = None
        item.published_at = datetime.now(timezone.utc)
        items.append(item)

    base_url = "https://example.com"
    iterations = 100

    # Public (teaser-only) generation
    total_paywall = 0.0
    for _ in range(iterations):
        _, ms = generate_rss_feed(feed, items, base_url, feed_content_key=None)
        total_paywall += ms

    # Premium (decrypt-and-serve) generation
    total_premium = 0.0
    for _ in range(iterations):
        _, ms = generate_rss_feed(feed, items, base_url, feed_content_key=key)
        total_premium += ms

    print(f"\n  Feed: 20 items, ~{len(full_article):,} bytes/article")
    print_row("  Paywall view avg", f"{total_paywall/iterations:.2f}", "ms")
    print_row("  Premium view avg", f"{total_premium/iterations:.2f}", "ms")
    print_row("  Decryption overhead", f"{(total_premium - total_paywall)/iterations:.2f}", "ms")
    print_row("  Throughput (premium)", f"{iterations/(total_premium/1000):,.0f}", "feeds/s")


# ── 4. Lightning invoice benchmark (mock) ─────────────────────────────────────

async def bench_lightning() -> None:
    print_section("Lightning Invoice Creation Benchmark (mock backend)")
    from app.services.lightning import benchmark_invoice_creation

    result = await benchmark_invoice_creation(iterations=50)
    print_row("  Backend", result["backend"])
    print_row("  Iterations", str(result["iterations"]))
    print_row("  Avg latency", f"{result['avg_ms']:.2f}", "ms")
    print_row("  Min latency", f"{result['min_ms']:.2f}", "ms")
    print_row("  Max latency", f"{result['max_ms']:.2f}", "ms")
    print_row("  p95 latency", f"{result['p95_ms']:.2f}", "ms")


# ── Entry point ────────────────────────────────────────────────────────────────

async def main() -> None:
    print("\n⚡ Lightning RSS – Performance Benchmark Suite")
    print(f"   Python sys path: {sys.path[0]}")

    bench_encryption()
    bench_key_derivation()
    bench_rss_generation()
    await bench_lightning()

    print(f"\n{'='*60}")
    print("  Benchmark complete.")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    asyncio.run(main())
