"""
services/crypto.py
──────────────────
Encryption layer for premium RSS content.

Scheme
------
  Algorithm : ChaCha20-Poly1305  (AEAD, 256-bit key, 96-bit nonce)
  Rationale : faster than AES-GCM on hardware without AES-NI,
              256-bit security, built-in authentication tag.

Key hierarchy
─────────────
  MASTER_KEY  (32 bytes, from settings.MASTER_ENCRYPTION_KEY, never stored in DB)
      └─▶  FEED_CONTENT_KEY  (32 bytes, randomly generated per feed,
                               stored encrypted with MASTER_KEY in feeds.content_key_encrypted)
               └─▶  per-item encryption: FEED_CONTENT_KEY + random NONCE per item
                    stored as  base64(nonce[12] || ciphertext || tag[16])

Per-subscriber key delivery
────────────────────────────
  When a subscription becomes active, we derive a SUBSCRIBER_CONTENT_KEY by
  wrapping the FEED_CONTENT_KEY with a key derived from the subscriber's API key:
      subscriber_derived_key = HKDF(subscriber_api_key_raw, salt=feed_id, length=32)
      subscriber_content_key = ChaCha20Poly1305.encrypt(FEED_CONTENT_KEY,
                                                         key=subscriber_derived_key)
  Stored in subscriptions.subscriber_content_key.

  The premium feed endpoint returns items already decrypted server-side, so the
  subscriber never needs to manage keys directly.  For an E2E model (content
  opaque to server), the server would instead return the encrypted item blobs +
  the subscriber_content_key, leaving decryption to the client SDK.
"""
from __future__ import annotations

import base64
import hmac
import os
import time
from typing import Tuple

from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.backends import default_backend

from app.config import settings


# ── Key utilities ─────────────────────────────────────────────────────────────

def _master_key() -> bytes:
    """Decode the base64 master key from settings."""
    raw = base64.b64decode(settings.MASTER_ENCRYPTION_KEY)
    if len(raw) != 32:
        raise ValueError("MASTER_ENCRYPTION_KEY must be exactly 32 bytes (base64-encoded)")
    return raw


def generate_feed_content_key() -> bytes:
    """Generate a random 32-byte feed content key."""
    return os.urandom(32)


def encrypt_key_with_master(plaintext_key: bytes) -> str:
    """
    Wrap a feed content key with the master key using ChaCha20-Poly1305.
    Returns base64(nonce + ciphertext).
    """
    master = _master_key()
    nonce = os.urandom(12)
    aead = ChaCha20Poly1305(master)
    ct = aead.encrypt(nonce, plaintext_key, None)
    return base64.b64encode(nonce + ct).decode()


def decrypt_key_with_master(encrypted_b64: str) -> bytes:
    """
    Unwrap a feed content key using the master key.
    Raises ValueError on tampering / wrong key.
    """
    master = _master_key()
    raw = base64.b64decode(encrypted_b64)
    nonce, ct = raw[:12], raw[12:]
    aead = ChaCha20Poly1305(master)
    return aead.decrypt(nonce, ct, None)


def derive_subscriber_key(subscriber_api_key_raw: bytes, feed_id: str) -> bytes:
    """
    Derive a 32-byte key unique to (subscriber, feed) via HKDF-SHA256.
    Used to wrap the feed content key for a specific subscriber.
    """
    hkdf = HKDF(
        algorithm=SHA256(),
        length=32,
        salt=feed_id.encode(),
        info=b"lightning-rss-subscriber-key",
        backend=default_backend(),
    )
    return hkdf.derive(subscriber_api_key_raw)


def wrap_feed_key_for_subscriber(feed_content_key: bytes, subscriber_derived_key: bytes) -> str:
    """
    Encrypt the feed content key so it can be safely stored per-subscription.
    Returns base64(nonce + ciphertext).
    """
    nonce = os.urandom(12)
    aead = ChaCha20Poly1305(subscriber_derived_key)
    ct = aead.encrypt(nonce, feed_content_key, None)
    return base64.b64encode(nonce + ct).decode()


def unwrap_feed_key_for_subscriber(wrapped_b64: str, subscriber_derived_key: bytes) -> bytes:
    """Decrypt the per-subscription feed key."""
    raw = base64.b64decode(wrapped_b64)
    nonce, ct = raw[:12], raw[12:]
    aead = ChaCha20Poly1305(subscriber_derived_key)
    return aead.decrypt(nonce, ct, None)


# ── Content encryption ────────────────────────────────────────────────────────

def encrypt_content(plaintext: str, feed_content_key: bytes) -> str:
    """
    Encrypt a content string with ChaCha20-Poly1305.
    Returns base64(nonce[12] || ciphertext+tag).
    Each call uses a fresh random nonce (nonce reuse is catastrophic for AEAD).
    """
    nonce = os.urandom(12)
    aead = ChaCha20Poly1305(feed_content_key)
    ct = aead.encrypt(nonce, plaintext.encode(), None)
    return base64.b64encode(nonce + ct).decode()


def decrypt_content(encrypted_b64: str, feed_content_key: bytes) -> str:
    """
    Decrypt content produced by encrypt_content().
    Raises cryptography.exceptions.InvalidTag on authentication failure.
    """
    raw = base64.b64decode(encrypted_b64)
    nonce, ct = raw[:12], raw[12:]
    aead = ChaCha20Poly1305(feed_content_key)
    return aead.decrypt(nonce, ct, None).decode()


# ── Benchmark helper ──────────────────────────────────────────────────────────

def benchmark_encryption(content: str, iterations: int = 1000) -> dict:
    """
    Measure encryption + decryption throughput.
    Returns timing stats in milliseconds.
    """
    key = generate_feed_content_key()
    encrypted = encrypt_content(content, key)  # warmup

    # Encrypt
    start = time.perf_counter()
    for _ in range(iterations):
        encrypt_content(content, key)
    enc_total_ms = (time.perf_counter() - start) * 1000

    # Decrypt
    start = time.perf_counter()
    for _ in range(iterations):
        decrypt_content(encrypted, key)
    dec_total_ms = (time.perf_counter() - start) * 1000

    return {
        "iterations": iterations,
        "content_bytes": len(content.encode()),
        "encrypt_avg_ms": round(enc_total_ms / iterations, 4),
        "decrypt_avg_ms": round(dec_total_ms / iterations, 4),
        "encrypt_total_ms": round(enc_total_ms, 2),
        "decrypt_total_ms": round(dec_total_ms, 2),
        "throughput_enc_ops_per_sec": round(iterations / (enc_total_ms / 1000), 0),
        "throughput_dec_ops_per_sec": round(iterations / (dec_total_ms / 1000), 0),
    }


# ── API Key utilities ─────────────────────────────────────────────────────────

def generate_api_key() -> Tuple[str, bytes]:
    """
    Generate a secure API key.
    Returns (display_key, raw_bytes) where raw_bytes is used for HKDF.
    Format: lrss_<base64url(32 random bytes)>
    """
    raw = os.urandom(32)
    display = "lrss_" + base64.urlsafe_b64encode(raw).decode().rstrip("=")
    return display, raw


def api_key_to_raw(display_key: str) -> bytes:
    """Convert display API key back to raw bytes for key derivation."""
    b64 = display_key.removeprefix("lrss_")
    # Restore padding
    padding = 4 - len(b64) % 4
    if padding != 4:
        b64 += "=" * padding
    return base64.urlsafe_b64decode(b64)
