#!/usr/bin/env python3
"""
cli/publisher_cli.py
────────────────────
CLI tool for publishers to manage feeds, publish articles, and view analytics.

Usage
─────
  export LRSS_API_KEY=lrss_xxxx
  export LRSS_BASE_URL=http://localhost:8000

  python -m cli.publisher_cli register --name "My Blog" --email me@example.com
  python -m cli.publisher_cli feed create --title "Tech News" --type premium --price 2000
  python -m cli.publisher_cli feed list
  python -m cli.publisher_cli item add --feed <id> --title "Article" --file article.md
  python -m cli.publisher_cli subscriptions --feed <id>
"""
import json
import os
import sys
from pathlib import Path
from typing import Optional

import click
import httpx
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import print as rprint

console = Console()

BASE_URL = os.getenv("LRSS_BASE_URL", "http://localhost:8000")
API_KEY  = os.getenv("LRSS_API_KEY", "")


def _client(require_auth: bool = True) -> httpx.Client:
    headers = {"Content-Type": "application/json"}
    if require_auth:
        if not API_KEY:
            console.print("[red]❌  LRSS_API_KEY environment variable not set[/red]")
            sys.exit(1)
        headers["X-API-Key"] = API_KEY
    return httpx.Client(base_url=BASE_URL, headers=headers, timeout=30)


def _raise_for_status(resp: httpx.Response) -> dict:
    if resp.status_code >= 400:
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        console.print(f"[red]❌  HTTP {resp.status_code}: {detail}[/red]")
        sys.exit(1)
    return resp.json()


# ── Top-level CLI group ────────────────────────────────────────────────────────

@click.group()
def cli():
    """⚡ Lightning RSS – Publisher Management CLI"""
    pass


# ── Register ──────────────────────────────────────────────────────────────────

@cli.command()
@click.option("--name",  prompt="Publisher name",  help="Your name or organisation")
@click.option("--email", prompt="Email address",   help="Email for your account")
@click.option("--password", prompt=True, hide_input=True, confirmation_prompt=True)
def register(name: str, email: str, password: str):
    """Register a new publisher account."""
    with _client(require_auth=False) as client:
        resp = client.post("/api/v1/auth/publisher/register", json={
            "name": name, "email": email, "password": password
        })
    data = _raise_for_status(resp)
    api_key = data["api_key"]

    console.print(Panel(
        f"[bold green]✅  Publisher registered![/bold green]\n\n"
        f"ID:      {data['publisher']['id']}\n"
        f"Name:    {data['publisher']['name']}\n"
        f"Email:   {data['publisher']['email']}\n\n"
        f"[bold yellow]API Key (save this – shown only once):[/bold yellow]\n"
        f"[cyan]{api_key}[/cyan]\n\n"
        f"Run: [white]export LRSS_API_KEY={api_key}[/white]",
        title="Registration Successful",
    ))


# ── Feed management ────────────────────────────────────────────────────────────

@cli.group()
def feed():
    """Manage RSS feeds."""
    pass


@feed.command("create")
@click.option("--title",    required=True, help="Feed title")
@click.option("--description", default="", help="Feed description")
@click.option("--link",     default="", help="Website URL")
@click.option("--type",     "feed_type", default="public",
              type=click.Choice(["public", "premium"]), help="Feed type")
@click.option("--price",    "price_sats", default=1000, help="Price in satoshis/period")
@click.option("--days",     "subscription_days", default=30, help="Subscription period (days)")
def feed_create(title, description, link, feed_type, price_sats, subscription_days):
    """Create a new RSS feed."""
    with _client() as client:
        resp = client.post("/api/v1/feeds", json={
            "title": title,
            "description": description or None,
            "link": link or None,
            "feed_type": feed_type,
            "price_sats": price_sats,
            "subscription_days": subscription_days,
        })
    data = _raise_for_status(resp)

    console.print(Panel(
        f"[bold green]✅  Feed created![/bold green]\n\n"
        f"ID:          [cyan]{data['id']}[/cyan]\n"
        f"Title:       {data['title']}\n"
        f"Type:        {'🔒 premium' if data['feed_type'] == 'premium' else '🌐 public'}\n"
        f"Price:       {data['price_sats']} sats / {data['subscription_days']} days\n\n"
        f"RSS URL:  {BASE_URL}/api/v1/feeds/{data['id']}/rss\n"
        f"Atom URL: {BASE_URL}/api/v1/feeds/{data['id']}/atom",
        title="Feed Created",
    ))


@feed.command("list")
@click.option("--type", "feed_type", default=None, type=click.Choice(["public", "premium"]))
def feed_list(feed_type):
    """List all your feeds."""
    params = {}
    if feed_type:
        params["feed_type"] = feed_type

    with _client() as client:
        resp = client.get("/api/v1/feeds", params=params)
    data = _raise_for_status(resp)

    if not data:
        console.print("[yellow]No feeds found.[/yellow]")
        return

    table = Table(title="Your Feeds", show_header=True, header_style="bold magenta")
    table.add_column("ID", style="cyan", max_width=36)
    table.add_column("Title", style="white")
    table.add_column("Type", style="yellow")
    table.add_column("Price (sats)", justify="right")
    table.add_column("Period (days)", justify="right")
    table.add_column("Active", justify="center")

    for f in data:
        table.add_row(
            f["id"],
            f["title"],
            "🔒 premium" if f["feed_type"] == "premium" else "🌐 public",
            str(f["price_sats"]),
            str(f["subscription_days"]),
            "✅" if f["is_active"] else "❌",
        )

    console.print(table)


# ── Item management ────────────────────────────────────────────────────────────

@cli.group()
def item():
    """Manage feed items (articles)."""
    pass


@item.command("add")
@click.option("--feed",    "feed_id", required=True, help="Feed ID")
@click.option("--title",   required=True, help="Article title")
@click.option("--summary", default="", help="Public teaser (optional)")
@click.option("--content", default="", help="Full article content (inline)")
@click.option("--file",    "content_file", default=None,
              type=click.Path(exists=True), help="Read content from file")
@click.option("--guid",    default=None, help="Stable unique identifier (URL or UUID)")
@click.option("--author",  default="", help="Author name")
@click.option("--link",    default="", help="Article URL")
def item_add(feed_id, title, summary, content, content_file, guid, author, link):
    """Add an article to a feed."""
    if content_file:
        content = Path(content_file).read_text()
    if not content:
        content = click.edit("# Enter article content here\n")
        if not content:
            console.print("[red]No content provided.[/red]")
            return

    if not guid:
        import uuid
        guid = str(uuid.uuid4())

    with _client() as client:
        resp = client.post(f"/api/v1/feeds/{feed_id}/items", json={
            "guid": guid,
            "title": title,
            "summary": summary or None,
            "content": content,
            "author": author or None,
            "link": link or None,
        })
    data = _raise_for_status(resp)

    encrypted = data.get("is_encrypted", False)
    console.print(
        f"[green]✅  Item added:[/green] {data['id']}\n"
        f"   Title: {data['title']}\n"
        f"   Encrypted: {'🔐 yes' if encrypted else '🌐 no'}"
    )


# ── Subscriptions ──────────────────────────────────────────────────────────────

@cli.command()
@click.option("--feed", "feed_id", default=None, help="Filter by feed ID")
def subscriptions(feed_id):
    """View subscriptions for your feeds."""
    params = {}
    if feed_id:
        params["feed_id"] = feed_id

    with _client() as client:
        resp = client.get("/api/v1/subscriptions/admin", params=params)
    data = _raise_for_status(resp)

    if not data:
        console.print("[yellow]No active subscriptions.[/yellow]")
        return

    table = Table(title="Active Subscriptions", show_header=True, header_style="bold blue")
    table.add_column("Sub ID", style="cyan", max_width=12)
    table.add_column("Subscriber ID", max_width=12)
    table.add_column("Feed ID", max_width=12)
    table.add_column("Status")
    table.add_column("Expires At")

    for s in data:
        table.add_row(
            s["id"][:8] + "…",
            s["subscriber_id"][:8] + "…",
            s["feed_id"][:8] + "…",
            s["status"],
            s.get("expires_at", "N/A")[:19] if s.get("expires_at") else "N/A",
        )

    console.print(table)
    console.print(f"\n[bold]Total active: {len(data)}[/bold]")


# ── Entry point ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    cli()
