# ⚡ Lightning-Recurring RSS Feed System

A production-ready Python API that lets publishers monetise RSS/Atom feeds with
Bitcoin Lightning Network subscriptions. Subscribers pay recurring Lightning
payments to unlock premium content that is encrypted at rest and served only to
paying users.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          Client Layer                                    │
│  RSS Reader  │  CLI Publisher  │  Subscriber Client  │  Custom App       │
└──────┬───────┴────────┬────────┴────────┬────────────┴──────────────────┘
       │                │                 │
       ▼                ▼                 ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    FastAPI Application  (:8000)                          │
│                                                                          │
│  /auth  ──  /feeds  ──  /payments  ──  /subscriptions  ──  /benchmark   │
│                                                                          │
│  Middleware: API-Key auth │ CORS │ Rate-limit │ Request timing           │
└───────────┬─────────────────────────────────┬────────────────────────────┘
            │                                 │
     ┌──────▼──────┐                  ┌───────▼────────┐
     │  Services   │                  │  Services       │
     │  ─────────  │                  │  ─────────      │
     │  crypto.py  │                  │  lightning.py   │
     │  ChaCha20-  │                  │  ┌────────────┐ │
     │  Poly1305   │                  │  │  LNbits    │ │
     │  HKDF       │                  │  │  LND REST  │ │
     │             │                  │  │  CLN REST  │ │
     │  rss_gen.py │                  │  │  Mock      │ │
     │  feedgen    │                  │  └────────────┘ │
     └──────┬──────┘                  └───────┬─────────┘
            │                                 │
            ▼                                 ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                     SQLAlchemy (async) + SQLite / PostgreSQL             │
│                                                                          │
│  publishers │ subscribers │ feeds │ feed_items │ invoices │ subscriptions │
└─────────────────────────────────────────────────────────────────────────┘
```

### Key design decisions

| Concern | Decision | Rationale |
|---|---|---|
| Framework | FastAPI + async/await throughout | Auto OpenAPI, native async I/O |
| Encryption | ChaCha20-Poly1305 (256-bit key, 96-bit nonce) | Fast on non-AES hardware, authenticated |
| Key hierarchy | Master key → per-feed key → per-item nonce | Revoke a subscriber without re-encrypting content |
| Auth | HMAC-SHA256 of API key (constant-time compare) | bcrypt truncates at 72 bytes; API keys are 43 chars of base64url |
| Lightning | Pluggable backend (LNbits / LND / mock) | Swap without changing business logic |
| DB | SQLite for dev, PostgreSQL for production | Async drivers for both (aiosqlite / asyncpg) |
| Background | asyncio task loop (30s poll) | Replace with APScheduler / Celery for production |

---

## Quick Start

### 1. Install

```bash
git clone <repo>
cd lightning_rss
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
```

### 2. Configure (copy and edit)

```bash
cp .env.example .env
```

Minimal `.env` for local development with the mock Lightning backend:

```env
LIGHTNING_BACKEND=mock
DATABASE_URL=sqlite+aiosqlite:///./lightning_rss.db
DEBUG=true
# Generate once: python -c "import os,base64; print(base64.b64encode(os.urandom(32)).decode())"
MASTER_ENCRYPTION_KEY=<32-byte-base64>
SECRET_KEY=<hex-64-chars>
```

### 3. Run

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

OpenAPI docs: http://localhost:8000/docs

### 4. End-to-end demo (mock backend)

```bash
# In one terminal: start the server (step 3)

# In another terminal:
export LRSS_BASE_URL=http://localhost:8000

# Register a publisher
python -m cli.publisher_cli register --name "Tech News" --email pub@example.com --password secret123

export LRSS_API_KEY=lrss_<key-from-above>

# Create a premium feed
python -m cli.publisher_cli feed create \
    --title "Tech Insider" \
    --type premium \
    --price 1000 \
    --days 30

# Add articles (use the feed ID from above output)
python -m cli.publisher_cli item add \
    --feed <feed-id> \
    --title "Breaking: LN reaches 1M nodes" \
    --summary "Public teaser here." \
    --content "Full premium article content goes here."

# Run subscriber demo (auto-registers, pays via mock, reads feed)
python -m client.subscriber_client demo --feed-id <feed-id>
```

---

## API Reference

All authenticated endpoints require:
```
X-API-Key: lrss_<your-key>
```

### Authentication

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `POST` | `/api/v1/auth/publisher/register` | None | Register publisher, get API key |
| `GET`  | `/api/v1/auth/me/publisher` | Publisher | Get profile |
| `POST` | `/api/v1/auth/subscriber/register` | None | Register subscriber, get API key |
| `GET`  | `/api/v1/auth/me/subscriber` | Subscriber | Get profile |

### Feeds

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `POST`   | `/api/v1/feeds` | Publisher | Create feed (public or premium) |
| `GET`    | `/api/v1/feeds` | None | List all active feeds |
| `GET`    | `/api/v1/feeds/{id}` | None | Feed metadata |
| `PATCH`  | `/api/v1/feeds/{id}` | Publisher (owner) | Update feed |
| `DELETE` | `/api/v1/feeds/{id}` | Publisher (owner) | Deactivate feed |
| `POST`   | `/api/v1/feeds/{id}/items` | Publisher (owner) | Add article (encrypted for premium) |
| `GET`    | `/api/v1/feeds/{id}/rss` | Optional subscriber | RSS 2.0 (full or paywalled) |
| `GET`    | `/api/v1/feeds/{id}/atom` | Optional subscriber | Atom 1.0 (full or paywalled) |

**Create feed request**
```json
{
  "title": "Tech Insider",
  "description": "Premium technology analysis",
  "link": "https://techinsider.example.com",
  "feed_type": "premium",
  "price_sats": 2000,
  "subscription_days": 30
}
```

### Payments

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `POST` | `/api/v1/payments/invoice` | Subscriber | Create BOLT-11 invoice |
| `POST` | `/api/v1/payments/verify` | Subscriber | Check payment status, activate subscription |
| `GET`  | `/api/v1/payments/invoice/{id}` | Subscriber | Get invoice details |
| `POST` | `/api/v1/payments/webhook/lnbits` | Webhook secret | Receive LNbits payment notifications |

**Create invoice request**
```json
{ "feed_id": "uuid-of-the-feed" }
```

**Create invoice response**
```json
{
  "id": "...",
  "payment_hash": "abc123...",
  "payment_request": "lnbc1000n1p...",
  "amount_sats": 2000,
  "status": "pending",
  "expires_at": "2026-04-22T12:00:00Z"
}
```

**Verify payment response**
```json
{
  "payment_hash": "abc123...",
  "paid": true,
  "subscription_id": "...",
  "subscription_expires_at": "2026-04-22T12:00:00Z",
  "message": "Payment confirmed. Subscription is now active."
}
```

### Subscriptions

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `POST` | `/api/v1/subscribe/{feed_id}` | Subscriber | Shortcut: create invoice |
| `GET`  | `/api/v1/subscriptions` | Subscriber | List my subscriptions |
| `GET`  | `/api/v1/subscriptions/{feed_id}/status` | Subscriber | Subscription status + expiry |
| `GET`  | `/api/v1/subscriptions/admin` | Publisher | All subscribers across publisher's feeds |

### System

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `GET` | `/health` | None | Service health check |
| `GET` | `/benchmark/crypto` | None | ChaCha20-Poly1305 throughput benchmark |
| `GET` | `/docs` | None | Interactive Swagger UI |

---

## Encryption & Key Management

```
MASTER_KEY (env var, 32 bytes, never touches DB)
    │
    ├─ encrypt/wrap ──► FEED_CONTENT_KEY (32 bytes, random per feed)
    │                   stored as: base64(ChaCha20Poly1305(MASTER_KEY).encrypt(FEED_CONTENT_KEY))
    │                   in: feeds.content_key_encrypted
    │
    └── FEED_CONTENT_KEY
            │
            ├─ encrypt ──► per-item ciphertext
            │              stored as: base64(nonce[12] || ciphertext + tag[16])
            │              in: feed_items.content_encrypted
            │
            └─ HKDF(subscriber_api_key_raw, salt=feed_id) ──► subscriber_derived_key
                    │
                    └─ wrap ──► subscriber_content_key
                               stored in: subscriptions.subscriber_content_key
                               (allows per-user revocation without re-encryption)
```

**On every feed request:** The server decrypts the feed key in memory, decrypts each article, and streams the XML. The client receives plaintext. For a fully E2E encrypted model, return the subscriber_content_key + ciphertext blobs to the client instead.

**Key rotation:** Generate a new FEED_CONTENT_KEY, re-encrypt all items, re-wrap all active subscriber keys.

---

## Lightning Integration

### Selecting a backend

Set `LIGHTNING_BACKEND` in `.env`:

| Value | Description |
|-------|-------------|
| `mock` | In-process simulation; auto-pays after ~5s. Use for tests/demos. |
| `lnbits` | LNbits REST API. Easiest to self-host. |
| `lnd` | LND REST API. Requires TLS cert + macaroon paths. |

### LNbits setup

```env
LIGHTNING_BACKEND=lnbits
LNBITS_URL=https://your-lnbits.com
LNBITS_INVOICE_KEY=<read-key>
LNBITS_ADMIN_KEY=<admin-key>

# Point LNbits webhook at:
# POST https://your-api.com/api/v1/payments/webhook/lnbits
# Header: X-Webhook-Secret: <WEBHOOK_SECRET>
WEBHOOK_SECRET=<random-hex>
```

### Recurring payments

Lightning has no native recurring payments. This system implements them by:

1. Sending a new invoice URL in every subscription-expiry reminder email.
2. The background poller (`_poll_invoices_loop`) marks paid invoices and extends subscriptions.
3. A grace period (`SUBSCRIPTION_GRACE_PERIOD_HOURS=24`) allows late payments.

For LNURL-pay integration, add a `/.well-known/lnurlp/<username>` endpoint that returns a LUD-06 response with your server's callback URL.

---

## Benchmark Results (local, Python 3.12, SQLite)

```
ChaCha20-Poly1305 encryption
  256 B  article:   0.008 ms/enc  │  0.004 ms/dec  │ 126K enc/s
  1 KB   article:   0.010 ms/enc  │  0.006 ms/dec  │ 105K enc/s
  4 KB   article:   0.015 ms/enc  │  0.051 ms/dec  │  67K enc/s
  16 KB  article:   0.039 ms/enc  │  0.074 ms/dec  │  26K enc/s
  64 KB  article:   0.139 ms/enc  │  0.213 ms/dec  │   7K enc/s

HKDF key derivation:  0.018 ms/op  │  56K ops/s

RSS feed generation (20 items, 5.6 KB/article)
  Paywall view (no decryption):   0.65 ms
  Premium view (decrypt 20 items): 1.44 ms
  Decryption overhead:             0.80 ms
  Throughput (premium):            693 feeds/s

Mock Lightning invoice creation:  0.03 ms avg  │  0.07 ms p95
```

### Running benchmarks

```bash
# Internal benchmark (crypto + RSS + mock LN):
python -m benchmarks.benchmark_runner

# Crypto via API:
curl http://localhost:8000/benchmark/crypto?content_size=4096&iterations=1000

# HTTP load test (requires server running):
pip install locust
export SUBSCRIBER_API_KEY=lrss_... PUBLIC_FEED_ID=... PREMIUM_FEED_ID=...
locust -f benchmarks/locustfile.py --host http://localhost:8000
```

---

## Testing

```bash
# All tests
pytest tests/ -v --asyncio-mode=auto

# Individual classes
pytest tests/ -k "TestCrypto" -v --asyncio-mode=auto
pytest tests/ -k "TestPayments" -v --asyncio-mode=auto
pytest tests/ -k "TestRSSServing" -v --asyncio-mode=auto
```

24 tests cover: auth, feed CRUD, item encryption, payment lifecycle,
paywall enforcement, and crypto primitives.

---

## Project Structure

```
lightning_rss/
├── app/
│   ├── config.py               # Pydantic-settings (all env vars)
│   ├── database.py             # SQLAlchemy models + session factory
│   ├── main.py                 # FastAPI app, lifespan, background poller
│   ├── middleware/
│   │   └── auth.py             # API-key resolution, HMAC-SHA256 hashing
│   ├── models/
│   │   └── schemas.py          # Pydantic request/response models
│   ├── routers/
│   │   ├── auth.py             # Registration endpoints
│   │   ├── feeds.py            # Feed CRUD + RSS/Atom serving
│   │   ├── payments.py         # Invoice creation + verification + webhooks
│   │   └── subscriptions.py    # Subscription management
│   └── services/
│       ├── crypto.py           # ChaCha20-Poly1305, HKDF, key hierarchy
│       ├── lightning.py        # LNbits / LND / Mock backends
│       ├── rss_generator.py    # feedgen RSS/Atom builder
│       └── subscription_manager.py  # Payment → subscription lifecycle
├── benchmarks/
│   ├── benchmark_runner.py     # Standalone perf suite
│   └── locustfile.py           # Locust HTTP load test
├── cli/
│   └── publisher_cli.py        # Click CLI (register, feed, item, subs)
├── client/
│   └── subscriber_client.py    # Example async subscriber client
├── tests/
│   └── test_integration.py     # 24 integration tests (in-memory SQLite)
├── requirements.txt
└── README.md
```

---

## Scaling to Production

### Database
- Replace `sqlite+aiosqlite` with `postgresql+asyncpg`.
- Add a `key_prefix` column to the API key table for O(1) lookup (currently O(n) HMAC scan).
- Add DB connection pooling: `create_async_engine(..., pool_size=20, max_overflow=40)`.

### Lightning backend
- Use a dedicated LNbits wallet per publisher for accounting.
- Add webhook retry logic with exponential backoff.
- Store `WebhookEvent` records and deliver via a worker queue (ARQ / Celery).

### Caching
```
Redis cache strategy:
  GET /feeds/{id}/rss → cache 5 min (public), no-cache (premium + auth)
  GET /feeds          → cache 60 s
  Subscription check  → cache 30 s per (subscriber_id, feed_id)
```

### Horizontal scaling
- All state in PostgreSQL → stateless API pods.
- Session-affinity not required (no in-process state after startup).
- Run N Uvicorn workers per pod: `uvicorn app.main:app --workers 4`.
- Move the background invoice poller to a dedicated worker pod or APScheduler job to avoid running on every API replica.

### Security hardening
- Store the MASTER_ENCRYPTION_KEY in a secrets manager (AWS Secrets Manager, HashiCorp Vault).
- Use an HSM or KMS to wrap/unwrap feed content keys (swap `encrypt_key_with_master` for a KMS API call).
- Enable mTLS between API ↔ Lightning node.
- Add IP-based rate limiting (nginx or Cloudflare) in front of the API.
- Rotate feed content keys quarterly; re-encrypt items in a background migration job.
- Implement LNURL-auth for keyless subscriber authentication.

### Observability
```python
# Add to main.py:
from prometheus_fastapi_instrumentator import Instrumentator
Instrumentator().instrument(app).expose(app)
```
Key metrics to track:
- `invoice_creation_latency_ms` (histogram)
- `payment_verification_latency_ms` (histogram)
- `rss_feed_response_ms{feed_type}` (histogram)
- `active_subscriptions_total` (gauge)
- `crypto_ops_per_second` (gauge, from `/benchmark/crypto`)

---

## Bonus: LNURL-auth sketch

```python
# app/routers/lnurl.py  (extension point)
@router.get("/.well-known/lnurlp/{username}")
async def lnurlp(username: str, request: Request):
    """LUD-06 pay endpoint – returns metadata for Lightning wallets."""
    return {
        "tag": "payRequest",
        "callback": f"{request.base_url}api/v1/lnurl/callback/{username}",
        "minSendable": 1_000_000,   # 1000 sats in millisats
        "maxSendable": 1_000_000_000,
        "metadata": json.dumps([["text/plain", f"Subscribe to {username}'s feeds"]]),
    }
```

---
