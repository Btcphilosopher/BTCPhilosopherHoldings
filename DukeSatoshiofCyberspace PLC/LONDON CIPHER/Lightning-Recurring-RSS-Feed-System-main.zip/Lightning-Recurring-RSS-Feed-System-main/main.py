"""
main.py
───────
FastAPI application entry point.

Mounts all routers, configures lifespan (DB init, background tasks),
and exposes OpenAPI documentation.
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import settings
from app.database import init_db, AsyncSessionLocal
from app.routers.auth import router as auth_router
from app.routers.feeds import router as feeds_router
from app.routers.payments import router as payments_router
from app.routers.subscriptions import router as subscriptions_router
from app.services.subscription_manager import (
    poll_pending_invoices,
    expire_stale_subscriptions,
)

logging.basicConfig(
    level=logging.DEBUG if settings.DEBUG else logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s – %(message)s",
)
logger = logging.getLogger(__name__)


# ── Background tasks ───────────────────────────────────────────────────────────

async def _poll_invoices_loop(interval_seconds: int = 30) -> None:
    """
    Periodically check pending invoices against the Lightning backend.
    In production replace with APScheduler, Celery Beat, or an ARQ task queue.
    """
    logger.info(f"Invoice poller started (interval={interval_seconds}s)")
    while True:
        await asyncio.sleep(interval_seconds)
        try:
            async with AsyncSessionLocal() as db:
                settled = await poll_pending_invoices(db)
                expired = await expire_stale_subscriptions(db)
                await db.commit()
                if settled or expired:
                    logger.info(f"Poller: {settled} invoices settled, {expired} subscriptions expired")
        except Exception as exc:
            logger.exception(f"Invoice poller error: {exc}")


# ── Lifespan ───────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Startup: initialise DB, start background poller.
    Shutdown: cancel background tasks gracefully.
    """
    logger.info(f"Starting {settings.APP_NAME} v{settings.APP_VERSION}")
    await init_db()
    logger.info("Database initialised")

    # Start background poller
    poll_task = asyncio.create_task(_poll_invoices_loop(30))

    yield   # ← app runs here

    poll_task.cancel()
    try:
        await poll_task
    except asyncio.CancelledError:
        pass
    logger.info("Shutdown complete")


# ── FastAPI app ────────────────────────────────────────────────────────────────

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="""
## Lightning-Recurring RSS Feed System

Monetise RSS/Atom feeds with Bitcoin Lightning Network subscriptions.

### Authentication
All endpoints that require auth use an API key in the `X-API-Key` header:
```
X-API-Key: lrss_<your-key>
```
Keys are issued at registration and shown **once** – store them securely.

### Quick-start flow
1. **Publisher**: `POST /api/v1/auth/publisher/register` → get API key
2. **Publisher**: `POST /api/v1/feeds` → create premium feed
3. **Publisher**: `POST /api/v1/feeds/{id}/items` → publish articles
4. **Subscriber**: `POST /api/v1/auth/subscriber/register` → get API key
5. **Subscriber**: `POST /api/v1/subscribe/{feed_id}` → get Lightning invoice
6. **Subscriber**: Pay the BOLT-11 invoice with any Lightning wallet
7. **Subscriber**: `POST /api/v1/payments/verify` → confirm payment
8. **Subscriber**: `GET /api/v1/feeds/{feed_id}/rss` with `X-API-Key` header → full content
    """,
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)


# ── CORS ───────────────────────────────────────────────────────────────────────

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if settings.DEBUG else ["https://yourdomain.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Global exception handlers ──────────────────────────────────────────────────

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.exception(f"Unhandled exception: {exc}")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"error": "Internal server error", "detail": str(exc) if settings.DEBUG else None},
    )


# ── Routers ────────────────────────────────────────────────────────────────────

app.include_router(auth_router)
app.include_router(feeds_router)
app.include_router(payments_router)
app.include_router(subscriptions_router)


# ── Health check ───────────────────────────────────────────────────────────────

@app.get("/health", tags=["System"], summary="Health check")
async def health():
    return {
        "status": "ok",
        "version": settings.APP_VERSION,
        "lightning_backend": settings.LIGHTNING_BACKEND,
    }


@app.get("/", tags=["System"], include_in_schema=False)
async def root():
    return {"message": f"Welcome to {settings.APP_NAME}", "docs": "/docs"}


# ── Crypto benchmark endpoint ──────────────────────────────────────────────────

@app.get("/benchmark/crypto", tags=["System"], summary="Crypto performance benchmark")
async def crypto_benchmark(
    content_size: int = 1000,
    iterations: int = 500,
):
    """
    Measure ChaCha20-Poly1305 encryption/decryption throughput.
    Returns average latency per operation in milliseconds.
    """
    from app.services.crypto import benchmark_encryption
    content = "A" * content_size
    return benchmark_encryption(content, iterations)


# ── Entry point ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level="debug" if settings.DEBUG else "info",
    )
