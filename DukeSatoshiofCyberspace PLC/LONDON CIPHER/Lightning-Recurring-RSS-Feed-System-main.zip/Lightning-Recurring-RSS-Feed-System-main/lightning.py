"""
services/lightning.py
─────────────────────
Pluggable Lightning Network backend.

Supported backends
──────────────────
  mock   – deterministic fake invoices; useful for tests / CI
  lnbits – LNbits REST API  (https://lnbits.com)
  lnd    – LND REST API  (gRPC bindings require grpcio – left as extension note)
  cln    – Core Lightning REST plugin

All backends implement the same interface defined by LightningBackend.
Swap backends via settings.LIGHTNING_BACKEND without touching the rest of the codebase.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import os
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, Any

import httpx

from app.config import settings


# ── Data transfer objects ──────────────────────────────────────────────────────

@dataclass
class InvoiceData:
    payment_hash: str
    payment_request: str      # BOLT-11
    amount_sats: int
    description: str
    expires_at: datetime
    backend_id: str           # opaque ID from the backend (LNbits checking_id etc.)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class PaymentStatus:
    payment_hash: str
    paid: bool
    amount_sats: Optional[int] = None
    settled_at: Optional[datetime] = None
    error: Optional[str] = None


# ── Abstract interface ─────────────────────────────────────────────────────────

class LightningBackend(ABC):
    @abstractmethod
    async def create_invoice(
        self,
        amount_sats: int,
        description: str,
        expiry_seconds: int = 3600,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> InvoiceData:
        ...

    @abstractmethod
    async def check_payment(self, payment_hash: str) -> PaymentStatus:
        ...

    @abstractmethod
    async def get_balance(self) -> int:
        """Return wallet balance in satoshis."""
        ...


# ── Mock backend (no external deps) ───────────────────────────────────────────

class MockLightningBackend(LightningBackend):
    """
    Simulates Lightning behaviour in-process.
    • Invoices are created instantly.
    • Call mark_paid(payment_hash) to simulate a successful payment
      (useful in integration tests).
    • After MOCK_AUTO_PAY_DELAY_SECONDS, invoices auto-pay if
      MOCK_AUTO_PAY=True (handy for demos).
    """

    MOCK_AUTO_PAY: bool = True
    MOCK_AUTO_PAY_DELAY_SECONDS: int = 5
    _paid: Dict[str, float] = {}   # payment_hash → unix timestamp

    def _make_payment_hash(self, seed: bytes) -> str:
        return hashlib.sha256(seed).hexdigest()

    def _make_bolt11(self, amount_sats: int, payment_hash: str) -> str:
        return (
            f"lnbc{amount_sats}n1"
            f"p{payment_hash[:16]}"
            f"mock_invoice_not_for_real_use"
        )

    async def create_invoice(
        self,
        amount_sats: int,
        description: str,
        expiry_seconds: int = 3600,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> InvoiceData:
        await asyncio.sleep(0)   # yield to event loop to simulate async I/O
        seed = os.urandom(32)
        payment_hash = self._make_payment_hash(seed)
        bolt11 = self._make_bolt11(amount_sats, payment_hash)
        expires_at = datetime.now(timezone.utc) + timedelta(seconds=expiry_seconds)

        if self.MOCK_AUTO_PAY:
            # Schedule auto-pay
            asyncio.get_event_loop().call_later(
                self.MOCK_AUTO_PAY_DELAY_SECONDS,
                lambda ph=payment_hash: self._paid.update({ph: time.time()})
            )

        return InvoiceData(
            payment_hash=payment_hash,
            payment_request=bolt11,
            amount_sats=amount_sats,
            description=description,
            expires_at=expires_at,
            backend_id=f"mock_{payment_hash[:8]}",
        )

    async def check_payment(self, payment_hash: str) -> PaymentStatus:
        await asyncio.sleep(0)
        paid_ts = self._paid.get(payment_hash)
        if paid_ts:
            return PaymentStatus(
                payment_hash=payment_hash,
                paid=True,
                amount_sats=None,
                settled_at=datetime.fromtimestamp(paid_ts, tz=timezone.utc),
            )
        return PaymentStatus(payment_hash=payment_hash, paid=False)

    async def get_balance(self) -> int:
        return 1_000_000   # mock 1M sats

    def mark_paid(self, payment_hash: str) -> None:
        """Test helper – instantly mark an invoice as paid."""
        self._paid[payment_hash] = time.time()


# ── LNbits backend ─────────────────────────────────────────────────────────────

class LNbitsBackend(LightningBackend):
    """
    Integrates with an LNbits instance via its REST API.
    Docs: https://lnbits.com/api

    Required settings:
        LNBITS_URL         – e.g. https://legend.lnbits.com
        LNBITS_ADMIN_KEY   – full access; used for balance
        LNBITS_INVOICE_KEY – read / invoice access; used for invoice + check
    """

    def __init__(self) -> None:
        self.base_url = settings.LNBITS_URL.rstrip("/")
        self.admin_key = settings.LNBITS_ADMIN_KEY
        self.invoice_key = settings.LNBITS_INVOICE_KEY

    def _client(self, key: str) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            base_url=self.base_url,
            headers={"X-Api-Key": key, "Content-Type": "application/json"},
            timeout=15.0,
        )

    async def create_invoice(
        self,
        amount_sats: int,
        description: str,
        expiry_seconds: int = 3600,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> InvoiceData:
        payload: Dict[str, Any] = {
            "out": False,
            "amount": amount_sats,
            "memo": description,
            "expiry": expiry_seconds,
            "unit": "sat",
        }
        async with self._client(self.invoice_key) as client:
            resp = await client.post("/api/v1/payments", json=payload)
            resp.raise_for_status()
            data = resp.json()

        payment_hash = data["payment_hash"]
        payment_request = data["payment_request"]
        expires_at = datetime.now(timezone.utc) + timedelta(seconds=expiry_seconds)

        return InvoiceData(
            payment_hash=payment_hash,
            payment_request=payment_request,
            amount_sats=amount_sats,
            description=description,
            expires_at=expires_at,
            backend_id=data.get("checking_id", payment_hash),
        )

    async def check_payment(self, payment_hash: str) -> PaymentStatus:
        async with self._client(self.invoice_key) as client:
            resp = await client.get(f"/api/v1/payments/{payment_hash}")
            if resp.status_code == 404:
                return PaymentStatus(payment_hash=payment_hash, paid=False,
                                     error="Invoice not found")
            resp.raise_for_status()
            data = resp.json()

        paid: bool = data.get("paid", False)
        settled_at = None
        if paid and (ts := data.get("details", {}).get("time")):
            settled_at = datetime.fromtimestamp(ts, tz=timezone.utc)

        return PaymentStatus(
            payment_hash=payment_hash,
            paid=paid,
            amount_sats=data.get("details", {}).get("amount"),
            settled_at=settled_at,
        )

    async def get_balance(self) -> int:
        async with self._client(self.admin_key) as client:
            resp = await client.get("/api/v1/wallet")
            resp.raise_for_status()
            data = resp.json()
        # LNbits returns balance in millisatoshis
        return data["balance"] // 1000


# ── LND REST backend ───────────────────────────────────────────────────────────

class LNDBackend(LightningBackend):
    """
    LND REST API backend.
    Docs: https://lightning.engineering/api-docs/api/lnd/

    Required settings:
        LND_HOST              – host:port of LND REST (usually :8080)
        LND_MACAROON_PATH     – path to admin.macaroon
        LND_TLS_CERT_PATH     – path to tls.cert
    """

    def __init__(self) -> None:
        host = settings.LND_HOST
        if not host.startswith("http"):
            host = f"https://{host}"
        self.base_url = host
        with open(settings.LND_MACAROON_PATH, "rb") as f:
            self.macaroon_hex = f.read().hex()
        self.tls_cert = settings.LND_TLS_CERT_PATH

    def _client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            base_url=self.base_url,
            headers={"Grpc-Metadata-Macaroon": self.macaroon_hex},
            verify=self.tls_cert,
            timeout=30.0,
        )

    async def create_invoice(
        self,
        amount_sats: int,
        description: str,
        expiry_seconds: int = 3600,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> InvoiceData:
        payload = {
            "value": str(amount_sats),
            "memo": description,
            "expiry": str(expiry_seconds),
        }
        async with self._client() as client:
            resp = await client.post("/v1/invoices", json=payload)
            resp.raise_for_status()
            data = resp.json()

        # LND returns payment_hash as bytes (base64)
        payment_hash_b64: str = data["r_hash"]
        payment_hash_hex = base64.b64decode(payment_hash_b64).hex()
        payment_request: str = data["payment_request"]
        expires_at = datetime.now(timezone.utc) + timedelta(seconds=expiry_seconds)

        return InvoiceData(
            payment_hash=payment_hash_hex,
            payment_request=payment_request,
            amount_sats=amount_sats,
            description=description,
            expires_at=expires_at,
            backend_id=data.get("add_index", payment_hash_hex),
        )

    async def check_payment(self, payment_hash: str) -> PaymentStatus:
        # LND expects base64-encoded payment hash
        ph_b64 = base64.b64encode(bytes.fromhex(payment_hash)).decode()
        async with self._client() as client:
            resp = await client.get(f"/v1/invoice/{ph_b64}")
            if resp.status_code == 404:
                return PaymentStatus(payment_hash=payment_hash, paid=False,
                                     error="Invoice not found")
            resp.raise_for_status()
            data = resp.json()

        # LND states: OPEN=0, SETTLED=1, CANCELED=2, ACCEPTED=3
        settled = data.get("state") == "SETTLED"
        settled_at = None
        if settled and (ts := data.get("settle_date")):
            settled_at = datetime.fromtimestamp(int(ts), tz=timezone.utc)

        return PaymentStatus(
            payment_hash=payment_hash,
            paid=settled,
            amount_sats=int(data.get("value", 0)),
            settled_at=settled_at,
        )

    async def get_balance(self) -> int:
        async with self._client() as client:
            resp = await client.get("/v1/balance/channels")
            resp.raise_for_status()
            data = resp.json()
        return int(data.get("local_balance", {}).get("sat", 0))


# ── Factory ────────────────────────────────────────────────────────────────────

_backend_instance: Optional[LightningBackend] = None


def get_lightning_backend() -> LightningBackend:
    """
    Return the configured Lightning backend singleton.
    Call once at startup; reuse for all requests.
    """
    global _backend_instance
    if _backend_instance is None:
        backend_name = settings.LIGHTNING_BACKEND.lower()
        if backend_name == "lnbits":
            _backend_instance = LNbitsBackend()
        elif backend_name == "lnd":
            _backend_instance = LNDBackend()
        elif backend_name == "mock":
            _backend_instance = MockLightningBackend()
        else:
            raise ValueError(f"Unknown LIGHTNING_BACKEND: {backend_name}")
    return _backend_instance


# ── Benchmark helper ───────────────────────────────────────────────────────────

async def benchmark_invoice_creation(iterations: int = 10) -> dict:
    """
    Measure end-to-end invoice generation latency.
    Useful for tracking backend responsiveness.
    """
    backend = get_lightning_backend()
    latencies: list[float] = []

    for i in range(iterations):
        start = time.perf_counter()
        await backend.create_invoice(
            amount_sats=1000,
            description=f"benchmark-{i}",
            expiry_seconds=300,
        )
        latencies.append((time.perf_counter() - start) * 1000)

    return {
        "iterations": iterations,
        "backend": settings.LIGHTNING_BACKEND,
        "avg_ms": round(sum(latencies) / len(latencies), 2),
        "min_ms": round(min(latencies), 2),
        "max_ms": round(max(latencies), 2),
        "p95_ms": round(sorted(latencies)[int(len(latencies) * 0.95)], 2),
    }
