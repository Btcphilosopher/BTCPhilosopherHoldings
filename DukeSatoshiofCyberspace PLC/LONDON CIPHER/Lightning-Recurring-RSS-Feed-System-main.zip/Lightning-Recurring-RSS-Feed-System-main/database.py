"""
database.py – Async SQLAlchemy engine, session factory, and all ORM models.
"""
import uuid
from datetime import datetime, timezone
from typing import AsyncGenerator

from sqlalchemy import (
    Boolean, Column, DateTime, Float, ForeignKey,
    Integer, String, Text, UniqueConstraint, Enum as SAEnum
)
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase, relationship
import enum

from app.config import settings


# ── Engine & Session factory ────────────────────────────────────────────────
engine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.DB_ECHO,
    # SQLite-specific: allow concurrent access
    connect_args={"check_same_thread": False} if "sqlite" in settings.DATABASE_URL else {},
)

AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
    autocommit=False,
)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency – yields an async DB session."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def init_db() -> None:
    """Create all tables (run at startup)."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


# ── Helpers ─────────────────────────────────────────────────────────────────
def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def new_uuid() -> str:
    return str(uuid.uuid4())


# ── Base ─────────────────────────────────────────────────────────────────────
class Base(DeclarativeBase):
    pass


# ── Enums ────────────────────────────────────────────────────────────────────
class FeedType(str, enum.Enum):
    PUBLIC = "public"
    PREMIUM = "premium"


class InvoiceStatus(str, enum.Enum):
    PENDING = "pending"
    PAID = "paid"
    EXPIRED = "expired"
    CANCELLED = "cancelled"


class SubscriptionStatus(str, enum.Enum):
    ACTIVE = "active"
    EXPIRED = "expired"
    CANCELLED = "cancelled"
    PENDING = "pending"


# ── ORM Models ───────────────────────────────────────────────────────────────

class Publisher(Base):
    """
    A publisher owns feeds and receives payments.
    Identified by an API key (hashed).
    """
    __tablename__ = "publishers"

    id: str = Column(String(36), primary_key=True, default=new_uuid)
    name: str = Column(String(256), nullable=False)
    email: str = Column(String(256), unique=True, nullable=False)
    api_key_hash: str = Column(String(128), nullable=False)  # bcrypt hash
    lnbits_wallet_id: str = Column(String(256), nullable=True)
    lnbits_invoice_key: str = Column(String(256), nullable=True)
    is_active: bool = Column(Boolean, default=True)
    created_at: datetime = Column(DateTime(timezone=True), default=utcnow)

    feeds = relationship("Feed", back_populates="publisher", cascade="all, delete-orphan")


class Subscriber(Base):
    """
    A subscriber pays for premium feed access.
    Identified by an API key (hashed).
    """
    __tablename__ = "subscribers"

    id: str = Column(String(36), primary_key=True, default=new_uuid)
    username: str = Column(String(128), unique=True, nullable=False)
    email: str = Column(String(256), unique=True, nullable=False)
    api_key_hash: str = Column(String(128), nullable=False)
    # Optional: store subscriber's Lightning node pubkey for LNURL-auth
    lightning_pubkey: str = Column(String(128), nullable=True)
    is_active: bool = Column(Boolean, default=True)
    created_at: datetime = Column(DateTime(timezone=True), default=utcnow)

    subscriptions = relationship("Subscription", back_populates="subscriber")
    invoices = relationship("LightningInvoice", back_populates="subscriber")


class Feed(Base):
    """
    An RSS feed (public or premium).
    Premium feeds have encrypted content stored in FeedItem.
    """
    __tablename__ = "feeds"

    id: str = Column(String(36), primary_key=True, default=new_uuid)
    publisher_id: str = Column(String(36), ForeignKey("publishers.id"), nullable=False)
    title: str = Column(String(512), nullable=False)
    description: str = Column(Text, nullable=True)
    link: str = Column(String(1024), nullable=True)  # canonical website URL
    language: str = Column(String(16), default="en")
    feed_type: FeedType = Column(SAEnum(FeedType), default=FeedType.PUBLIC, nullable=False)

    # Pricing (satoshis per subscription period)
    price_sats: int = Column(Integer, default=1_000)
    subscription_days: int = Column(Integer, default=30)

    # Encryption: AES-256-GCM key for this feed's content, base64-encoded.
    # Stored encrypted with the server MASTER_ENCRYPTION_KEY.
    content_key_encrypted: str = Column(Text, nullable=True)

    is_active: bool = Column(Boolean, default=True)
    created_at: datetime = Column(DateTime(timezone=True), default=utcnow)
    updated_at: datetime = Column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    publisher = relationship("Publisher", back_populates="feeds")
    items = relationship("FeedItem", back_populates="feed", cascade="all, delete-orphan")
    subscriptions = relationship("Subscription", back_populates="feed")


class FeedItem(Base):
    """
    A single item/article in a feed.
    For premium feeds, `content_encrypted` holds ChaCha20-Poly1305 ciphertext.
    """
    __tablename__ = "feed_items"

    id: str = Column(String(36), primary_key=True, default=new_uuid)
    feed_id: str = Column(String(36), ForeignKey("feeds.id"), nullable=False)
    guid: str = Column(String(512), nullable=False)          # stable item identifier
    title: str = Column(String(512), nullable=False)
    link: str = Column(String(1024), nullable=True)
    summary: str = Column(Text, nullable=True)               # always public (teaser)

    # For premium feeds: full content is encrypted at rest
    content_encrypted: str = Column(Text, nullable=True)     # base64(nonce + ciphertext)
    # For public feeds: plaintext
    content_plain: str = Column(Text, nullable=True)

    author: str = Column(String(256), nullable=True)
    published_at: datetime = Column(DateTime(timezone=True), default=utcnow)
    updated_at: datetime = Column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    feed = relationship("Feed", back_populates="items")

    __table_args__ = (UniqueConstraint("feed_id", "guid", name="uq_feed_item_guid"),)


class LightningInvoice(Base):
    """
    Tracks a Lightning Network BOLT-11 invoice for a subscription payment.
    """
    __tablename__ = "lightning_invoices"

    id: str = Column(String(36), primary_key=True, default=new_uuid)
    subscriber_id: str = Column(String(36), ForeignKey("subscribers.id"), nullable=False)
    feed_id: str = Column(String(36), ForeignKey("feeds.id"), nullable=False)

    # Lightning fields
    payment_hash: str = Column(String(128), unique=True, nullable=False)
    payment_request: str = Column(Text, nullable=False)   # BOLT-11 invoice string
    amount_sats: int = Column(Integer, nullable=False)
    description: str = Column(String(512), nullable=True)

    # Lifecycle
    status: InvoiceStatus = Column(SAEnum(InvoiceStatus), default=InvoiceStatus.PENDING)
    expires_at: datetime = Column(DateTime(timezone=True), nullable=False)
    paid_at: datetime = Column(DateTime(timezone=True), nullable=True)

    # LNbits/backend specific
    backend_invoice_id: str = Column(String(256), nullable=True)  # external ID from backend

    created_at: datetime = Column(DateTime(timezone=True), default=utcnow)

    subscriber = relationship("Subscriber", back_populates="invoices")
    subscription = relationship("Subscription", back_populates="invoice", uselist=False)


class Subscription(Base):
    """
    Active or historical subscription of a subscriber to a feed.
    Becomes ACTIVE once the linked invoice is PAID.
    """
    __tablename__ = "subscriptions"

    id: str = Column(String(36), primary_key=True, default=new_uuid)
    subscriber_id: str = Column(String(36), ForeignKey("subscribers.id"), nullable=False)
    feed_id: str = Column(String(36), ForeignKey("feeds.id"), nullable=False)
    invoice_id: str = Column(String(36), ForeignKey("lightning_invoices.id"), nullable=True)

    status: SubscriptionStatus = Column(SAEnum(SubscriptionStatus), default=SubscriptionStatus.PENDING)
    starts_at: datetime = Column(DateTime(timezone=True), nullable=True)
    expires_at: datetime = Column(DateTime(timezone=True), nullable=True)

    # Per-subscription derived key (base64) used to encrypt the feed key for this user.
    # This allows revocation per subscriber without re-encrypting all content.
    subscriber_content_key: str = Column(Text, nullable=True)

    created_at: datetime = Column(DateTime(timezone=True), default=utcnow)
    updated_at: datetime = Column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    subscriber = relationship("Subscriber", back_populates="subscriptions")
    feed = relationship("Feed", back_populates="subscriptions")
    invoice = relationship("LightningInvoice", back_populates="subscription")

    __table_args__ = (UniqueConstraint("subscriber_id", "feed_id", "invoice_id", name="uq_sub"),)


class WebhookEvent(Base):
    """
    Outgoing webhook events (payment confirmations etc.)
    """
    __tablename__ = "webhook_events"

    id: str = Column(String(36), primary_key=True, default=new_uuid)
    event_type: str = Column(String(64), nullable=False)   # payment.confirmed, etc.
    payload: str = Column(Text, nullable=False)             # JSON
    target_url: str = Column(String(1024), nullable=True)
    delivered: bool = Column(Boolean, default=False)
    attempts: int = Column(Integer, default=0)
    created_at: datetime = Column(DateTime(timezone=True), default=utcnow)
    delivered_at: datetime = Column(DateTime(timezone=True), nullable=True)
