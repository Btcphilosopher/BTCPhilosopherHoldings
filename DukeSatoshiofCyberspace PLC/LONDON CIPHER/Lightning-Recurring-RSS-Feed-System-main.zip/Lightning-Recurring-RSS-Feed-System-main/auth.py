"""
middleware/auth.py
──────────────────
Authentication utilities and FastAPI dependencies.

Auth model
──────────
  All users (publishers & subscribers) authenticate via:
    Header: X-API-Key: lrss_<base64url(32 bytes)>

  API keys are stored as bcrypt hashes in the DB.
  The raw key bytes are used in HKDF to derive per-subscription content keys.

  For future LNURL-auth support, add a separate /auth/lnurl endpoint and
  store the Lightning pubkey in subscribers.lightning_pubkey.
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import secrets
from typing import Optional, Tuple

from fastapi import Depends, HTTPException, Header, Security, status
from fastapi.security import APIKeyHeader
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.database import Publisher, Subscriber, get_db
from app.services.crypto import generate_api_key, api_key_to_raw

logger = logging.getLogger(__name__)

api_key_scheme = APIKeyHeader(name=settings.API_KEY_HEADER, auto_error=False)

# Use a fixed HMAC secret to compute deterministic hashes.
# In production, set API_HMAC_SECRET in the environment.
_HMAC_SECRET: bytes = settings.SECRET_KEY.encode()


# ── API key hashing (HMAC-SHA256) ─────────────────────────────────────────────
# API keys are 32 random bytes – bcrypt is overkill and breaks at >72 bytes.
# HMAC-SHA256 is fast, constant-time comparable, and correct here.

def hash_api_key(raw_key: str) -> str:
    """HMAC-SHA256 hash an API key for DB storage."""
    return hmac.new(_HMAC_SECRET, raw_key.encode(), hashlib.sha256).hexdigest()


def verify_api_key(raw_key: str, hashed: str) -> bool:
    """Constant-time verify a raw API key against its stored hash."""
    expected = hash_api_key(raw_key)
    return secrets.compare_digest(expected, hashed)


def create_api_key_for_user() -> Tuple[str, str, bytes]:
    """
    Generate a new API key.
    Returns: (display_key, hashed_key, raw_bytes)
    """
    display_key, raw_bytes = generate_api_key()
    hashed = hash_api_key(display_key)
    return display_key, hashed, raw_bytes


# ── FastAPI dependencies ───────────────────────────────────────────────────────

async def get_current_publisher(
    api_key: Optional[str] = Security(api_key_scheme),
    db: AsyncSession = Depends(get_db),
) -> Publisher:
    """
    Resolve the authenticated Publisher from X-API-Key.
    Raises 401 if missing/invalid.
    """
    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing API key",
            headers={"WWW-Authenticate": f"ApiKey header={settings.API_KEY_HEADER}"},
        )
    publisher = await _resolve_publisher(db, api_key)
    if not publisher:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or inactive API key",
        )
    return publisher


async def get_current_subscriber(
    api_key: Optional[str] = Security(api_key_scheme),
    db: AsyncSession = Depends(get_db),
) -> Subscriber:
    """
    Resolve the authenticated Subscriber from X-API-Key.
    Raises 401 if missing/invalid.
    """
    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing API key",
            headers={"WWW-Authenticate": f"ApiKey header={settings.API_KEY_HEADER}"},
        )
    subscriber = await _resolve_subscriber(db, api_key)
    if not subscriber:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or inactive API key",
        )
    return subscriber


async def get_optional_subscriber(
    api_key: Optional[str] = Security(api_key_scheme),
    db: AsyncSession = Depends(get_db),
) -> Optional[Subscriber]:
    """
    Like get_current_subscriber but returns None instead of raising 401.
    Used for endpoints that serve public content when unauthenticated
    and premium content when authenticated.
    """
    if not api_key:
        return None
    return await _resolve_subscriber(db, api_key)


async def get_subscriber_with_key(
    api_key: Optional[str] = Security(api_key_scheme),
    db: AsyncSession = Depends(get_db),
) -> Tuple[Optional[Subscriber], Optional[bytes]]:
    """
    Return (subscriber, raw_api_key_bytes) for key-derivation flows.
    raw_bytes are used in HKDF to derive the subscriber's content key.
    """
    if not api_key:
        return None, None
    sub = await _resolve_subscriber(db, api_key)
    if not sub:
        return None, None
    raw = api_key_to_raw(api_key)
    return sub, raw


# ── Internals ──────────────────────────────────────────────────────────────────

async def _resolve_publisher(db: AsyncSession, api_key: str) -> Optional[Publisher]:
    result = await db.execute(select(Publisher).where(Publisher.is_active == True))
    publishers = result.scalars().all()
    for pub in publishers:
        if verify_api_key(api_key, pub.api_key_hash):
            return pub
    return None


async def _resolve_subscriber(db: AsyncSession, api_key: str) -> Optional[Subscriber]:
    result = await db.execute(select(Subscriber).where(Subscriber.is_active == True))
    subscribers = result.scalars().all()
    for sub in subscribers:
        if verify_api_key(api_key, sub.api_key_hash):
            return sub
    return None


# NOTE: The O(n) scan above is fine for small user bases.
# For production scale:
#   1. Hash the incoming key with SHA-256 first (no bcrypt).
#   2. Store SHA-256(api_key) as a lookup column.
#   3. Use an indexed WHERE clause.
# Or: store the first 8 chars as a non-secret prefix for a DB lookup hint.
