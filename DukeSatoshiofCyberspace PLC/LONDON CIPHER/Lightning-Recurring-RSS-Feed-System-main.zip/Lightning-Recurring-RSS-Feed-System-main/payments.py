"""
routers/payments.py
───────────────────
Lightning payment endpoints.

Routes
──────
POST  /api/v1/payments/invoice         – create invoice for a feed subscription
POST  /api/v1/payments/verify          – check if an invoice has been paid
GET   /api/v1/payments/invoice/{id}    – get invoice details
POST  /api/v1/payments/webhook/lnbits  – LNbits webhook receiver
GET   /api/v1/payments/benchmark       – invoice creation benchmark (dev only)
"""
import hashlib
import hmac
import json
import logging
import time
from typing import Optional

from fastapi import APIRouter, Body, Depends, Header, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.database import Feed, LightningInvoice, Subscriber, get_db, InvoiceStatus
from app.middleware.auth import get_current_subscriber, get_subscriber_with_key
from app.models.schemas import (
    InvoiceCreate, InvoiceOut, PaymentVerifyRequest, PaymentVerifyResponse
)
from app.services.lightning import get_lightning_backend, benchmark_invoice_creation
from app.services.subscription_manager import (
    create_subscription_invoice,
    verify_and_activate,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/payments", tags=["Payments"])


# ── Create invoice ─────────────────────────────────────────────────────────────

@router.post(
    "/invoice",
    response_model=InvoiceOut,
    status_code=status.HTTP_201_CREATED,
    summary="Create a Lightning invoice for a feed subscription",
)
async def create_invoice(
    body: InvoiceCreate,
    subscriber: Subscriber = Depends(get_current_subscriber),
    db: AsyncSession = Depends(get_db),
):
    """
    Creates a BOLT-11 invoice for subscribing to the given feed.

    Steps:
    1. Validate subscriber + feed exist and are active.
    2. Call Lightning backend to create invoice.
    3. Persist invoice row → return to client.

    The client should present `payment_request` as a QR code / copyable string
    for the subscriber to pay with their Lightning wallet.
    After payment, call POST /api/v1/payments/verify with the payment_hash.
    """
    t0 = time.perf_counter()

    # Load and validate feed
    feed_result = await db.execute(
        select(Feed).where(Feed.id == body.feed_id, Feed.is_active == True)
    )
    feed: Optional[Feed] = feed_result.scalar_one_or_none()
    if not feed:
        raise HTTPException(status_code=404, detail="Feed not found")

    if feed.feed_type.value == "public":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Feed is public – no payment required",
        )

    invoice = await create_subscription_invoice(
        db=db,
        subscriber=subscriber,
        feed=feed,
        amount_sats=body.amount_sats,
    )

    elapsed_ms = (time.perf_counter() - t0) * 1000
    logger.info(
        f"Invoice created: {invoice.payment_hash[:16]}... "
        f"feed={feed.id} subscriber={subscriber.id} "
        f"sats={invoice.amount_sats} latency={elapsed_ms:.1f}ms"
    )

    return InvoiceOut.model_validate(invoice)


# ── Verify / poll payment ─────────────────────────────────────────────────────

@router.post(
    "/verify",
    response_model=PaymentVerifyResponse,
    summary="Check if a Lightning payment has been confirmed",
)
async def verify_payment(
    body: PaymentVerifyRequest,
    subscriber_and_key: tuple = Depends(get_subscriber_with_key),
    db: AsyncSession = Depends(get_db),
):
    """
    Poll the Lightning backend for payment status.
    If paid, activates the subscription automatically.

    Clients should poll this endpoint (e.g. every 3s) after presenting
    the QR code, until `paid: true` is returned.

    For push-based flows, see the POST /webhook/lnbits endpoint.
    """
    subscriber, raw_api_key = subscriber_and_key

    if not subscriber:
        raise HTTPException(status_code=401, detail="Authentication required")

    invoice_result = await db.execute(
        select(LightningInvoice).where(
            LightningInvoice.payment_hash == body.payment_hash,
            LightningInvoice.subscriber_id == subscriber.id,
        )
    )
    invoice: Optional[LightningInvoice] = invoice_result.scalar_one_or_none()

    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")

    paid, subscription = await verify_and_activate(
        db=db,
        invoice=invoice,
        subscriber_api_key_raw=raw_api_key,
    )

    if paid and subscription:
        return PaymentVerifyResponse(
            payment_hash=body.payment_hash,
            paid=True,
            subscription_id=subscription.id,
            subscription_expires_at=subscription.expires_at,
            message="Payment confirmed. Subscription is now active.",
        )

    if invoice.status == InvoiceStatus.EXPIRED:
        return PaymentVerifyResponse(
            payment_hash=body.payment_hash,
            paid=False,
            message="Invoice expired. Please create a new invoice.",
        )

    return PaymentVerifyResponse(
        payment_hash=body.payment_hash,
        paid=False,
        message="Payment not yet received. Retry in a few seconds.",
    )


# ── Get invoice details ────────────────────────────────────────────────────────

@router.get(
    "/invoice/{invoice_id}",
    response_model=InvoiceOut,
    summary="Get invoice details",
)
async def get_invoice(
    invoice_id: str,
    subscriber: Subscriber = Depends(get_current_subscriber),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(LightningInvoice).where(
            LightningInvoice.id == invoice_id,
            LightningInvoice.subscriber_id == subscriber.id,
        )
    )
    invoice = result.scalar_one_or_none()
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return InvoiceOut.model_validate(invoice)


# ── LNbits webhook receiver ────────────────────────────────────────────────────

@router.post(
    "/webhook/lnbits",
    status_code=status.HTTP_200_OK,
    summary="Receive LNbits payment webhooks",
    include_in_schema=False,   # hide from public docs
)
async def lnbits_webhook(
    request: Request,
    db: AsyncSession = Depends(get_db),
    x_webhook_secret: Optional[str] = Header(None),
):
    """
    LNbits calls this URL when an invoice is settled.
    Configure in LNbits: Wallet → WebHook → set to <base_url>/api/v1/payments/webhook/lnbits

    We verify the request with a shared secret in X-Webhook-Secret header.
    """
    # Verify shared secret
    if x_webhook_secret != settings.WEBHOOK_SECRET:
        raise HTTPException(status_code=401, detail="Invalid webhook secret")

    body = await request.json()
    payment_hash: Optional[str] = body.get("payment_hash")

    if not payment_hash:
        return {"ok": False, "error": "missing payment_hash"}

    invoice_result = await db.execute(
        select(LightningInvoice).where(
            LightningInvoice.payment_hash == payment_hash,
            LightningInvoice.status == InvoiceStatus.PENDING,
        )
    )
    invoice = invoice_result.scalar_one_or_none()

    if not invoice:
        logger.info(f"Webhook: unknown or already processed invoice {payment_hash[:16]}...")
        return {"ok": True, "message": "already processed"}

    paid, subscription = await verify_and_activate(db=db, invoice=invoice)

    logger.info(
        f"Webhook processed: {payment_hash[:16]}... paid={paid} "
        f"sub_id={subscription.id if subscription else None}"
    )
    return {"ok": True, "paid": paid}


# ── Benchmark endpoint (dev only) ──────────────────────────────────────────────

@router.get(
    "/benchmark",
    summary="Benchmark Lightning invoice creation (dev only)",
    include_in_schema=settings.DEBUG,
)
async def benchmark_payments(iterations: int = 10):
    if not settings.DEBUG:
        raise HTTPException(status_code=404)
    return await benchmark_invoice_creation(iterations=iterations)
