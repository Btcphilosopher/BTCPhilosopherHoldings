"""
benchmarks/locustfile.py
────────────────────────
Locust load-testing configuration for the Lightning RSS API.

Usage
─────
  # Install: pip install locust
  # Run web UI:
  locust -f benchmarks/locustfile.py --host http://localhost:8000

  # Headless (CI):
  locust -f benchmarks/locustfile.py --host http://localhost:8000 \
         --headless -u 50 -r 10 --run-time 60s \
         --csv=results/bench

Scenarios
─────────
  PublicFeedUser   – anonymous reader polling public RSS feed
  PremiumFeedUser  – authenticated subscriber reading premium feed
  PublisherUser    – publisher creating feeds and adding items
"""
import os
import random
import string
import time
from locust import HttpUser, task, between, events


# ── Shared test data ────────────────────────────────────────────────────────────
#   Set these via environment variables before running:
#     SUBSCRIBER_API_KEY=lrss_xxx FEED_ID=<uuid> locust ...

SUBSCRIBER_API_KEY = os.getenv("SUBSCRIBER_API_KEY", "")
PUBLISHER_API_KEY  = os.getenv("PUBLISHER_API_KEY", "")
PUBLIC_FEED_ID     = os.getenv("PUBLIC_FEED_ID", "")
PREMIUM_FEED_ID    = os.getenv("PREMIUM_FEED_ID", "")


def _rand_str(n: int = 8) -> str:
    return "".join(random.choices(string.ascii_lowercase, k=n))


# ── User classes ────────────────────────────────────────────────────────────────

class PublicFeedUser(HttpUser):
    """
    Simulates an unauthenticated user browsing public RSS feeds.
    Expected: fast responses, no auth overhead.
    """
    wait_time = between(0.5, 2.0)

    @task(10)
    def fetch_public_rss(self):
        if not PUBLIC_FEED_ID:
            return
        start = time.perf_counter()
        with self.client.get(
            f"/api/v1/feeds/{PUBLIC_FEED_ID}/rss",
            catch_response=True,
            name="GET /feeds/[id]/rss (public)",
        ) as resp:
            if resp.status_code == 200:
                gen_ms = resp.headers.get("X-Feed-Generation-Ms")
                resp.success()
            else:
                resp.failure(f"HTTP {resp.status_code}")

    @task(2)
    def list_feeds(self):
        self.client.get("/api/v1/feeds", name="GET /feeds")

    @task(1)
    def health_check(self):
        self.client.get("/health", name="GET /health")


class PremiumFeedUser(HttpUser):
    """
    Simulates an authenticated subscriber with an active subscription.
    Tests decryption overhead in the feed serving path.
    """
    wait_time = between(1.0, 5.0)

    def on_start(self):
        if not SUBSCRIBER_API_KEY:
            self.environment.runner.quit()
        self.headers = {"X-API-Key": SUBSCRIBER_API_KEY}

    @task(10)
    def fetch_premium_rss(self):
        if not PREMIUM_FEED_ID:
            return
        with self.client.get(
            f"/api/v1/feeds/{PREMIUM_FEED_ID}/rss",
            headers=self.headers,
            catch_response=True,
            name="GET /feeds/[id]/rss (premium+auth)",
        ) as resp:
            if resp.status_code == 200:
                resp.success()
            else:
                resp.failure(f"HTTP {resp.status_code}")

    @task(3)
    def check_subscription_status(self):
        if not PREMIUM_FEED_ID:
            return
        self.client.get(
            f"/api/v1/subscriptions/{PREMIUM_FEED_ID}/status",
            headers=self.headers,
            name="GET /subscriptions/[id]/status",
        )

    @task(2)
    def list_subscriptions(self):
        self.client.get(
            "/api/v1/subscriptions",
            headers=self.headers,
            name="GET /subscriptions",
        )

    @task(1)
    def fetch_premium_atom(self):
        if not PREMIUM_FEED_ID:
            return
        self.client.get(
            f"/api/v1/feeds/{PREMIUM_FEED_ID}/atom",
            headers=self.headers,
            name="GET /feeds/[id]/atom (premium+auth)",
        )


class PublisherUser(HttpUser):
    """
    Simulates publishers adding content to feeds.
    Tests write throughput for content ingestion.
    """
    wait_time = between(2.0, 8.0)

    def on_start(self):
        if not PUBLISHER_API_KEY:
            self.environment.runner.quit()
        self.headers = {"X-API-Key": PUBLISHER_API_KEY}
        self.feed_id = PUBLIC_FEED_ID or PREMIUM_FEED_ID

    @task(5)
    def add_feed_item(self):
        if not self.feed_id:
            return
        slug = _rand_str()
        self.client.post(
            f"/api/v1/feeds/{self.feed_id}/items",
            headers=self.headers,
            json={
                "guid": f"https://example.com/article/{slug}",
                "title": f"Benchmark Article {slug}",
                "summary": "This is a teaser for the article.",
                "content": "Full article content. " * 100,
                "author": "Bench Bot",
            },
            name="POST /feeds/[id]/items",
        )

    @task(2)
    def list_my_feeds(self):
        self.client.get(
            "/api/v1/feeds",
            headers=self.headers,
            name="GET /feeds (publisher)",
        )


# ── Custom metrics reporting ────────────────────────────────────────────────────

@events.request.add_listener
def on_request(request_type, name, response_time, response_length, **kwargs):
    """
    Hook to capture per-request metrics.
    In production, forward to Prometheus / InfluxDB / Datadog.
    """
    pass  # plug in your metrics sink here
