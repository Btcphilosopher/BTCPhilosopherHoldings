"""
services/rss_generator.py
─────────────────────────
Generates standards-compliant RSS 2.0 / Atom feeds.

Public feeds    → full content in <content:encoded>
Premium feeds
  authenticated → decrypt on-the-fly, return full content
  unauthenticated → teaser only + paywall notice + subscription URL
"""
from __future__ import annotations

import time
from datetime import timezone
from typing import List, Optional, Tuple
from xml.etree import ElementTree as ET

from feedgen.feed import FeedGenerator

from app.database import Feed, FeedItem
from app.services.crypto import decrypt_content, decrypt_key_with_master


# Namespace for custom Lightning paywall extension
LIGHTNING_NS = "https://lightning-rss.io/ns/1.0"


def _item_id_from_request(base_url: str, feed_id: str, item_id: str) -> str:
    return f"{base_url}/feed/{feed_id}/item/{item_id}"


def _paywall_element(feed: Feed, base_url: str) -> ET.Element:
    """Build a <lightning:paywall> XML element for paywalled items."""
    el = ET.Element(f"{{{LIGHTNING_NS}}}paywall")
    el.set("price_sats", str(feed.price_sats))
    el.set("subscription_days", str(feed.subscription_days))
    ET.SubElement(el, f"{{{LIGHTNING_NS}}}subscribe_url").text = (
        f"{base_url}/api/v1/subscribe/{feed.id}"
    )
    return el


def generate_rss_feed(
    feed: Feed,
    items: List[FeedItem],
    base_url: str,
    feed_content_key: Optional[bytes] = None,  # None → paywalled view
    include_enclosures: bool = False,
) -> Tuple[bytes, float]:
    """
    Build an RSS 2.0 feed and return (xml_bytes, generation_time_ms).

    Parameters
    ----------
    feed              : ORM Feed instance
    items             : FeedItem rows (ordered by published_at DESC)
    base_url          : Server base URL used for self-links
    feed_content_key  : If provided, decrypt premium content and include it.
                        If None, premium items show teaser + paywall notice.
    include_enclosures: Reserved for media-RSS extensions.
    """
    t0 = time.perf_counter()

    fg = FeedGenerator()
    fg.id(f"{base_url}/feed/{feed.id}")
    fg.title(feed.title or "Untitled Feed")
    fg.description(feed.description or feed.title or "")
    fg.link(href=feed.link or f"{base_url}/feed/{feed.id}", rel="alternate")
    fg.link(href=f"{base_url}/api/v1/feed/{feed.id}/rss", rel="self")
    fg.language(feed.language or "en")
    fg.generator("Lightning RSS Feed System")

    # Add Lightning namespace (API varies by feedgen version)
    try:
        fg.register_namespace("lightning", LIGHTNING_NS)
    except AttributeError:
        pass  # older feedgen versions don't support this

    for item in items:
        fe = fg.add_entry(order="append")
        fe.id(item.guid or _item_id_from_request(base_url, feed.id, item.id))
        fe.title(item.title)
        if item.link:
            fe.link(href=item.link)
        if item.author:
            fe.author({"name": item.author})
        if item.published_at:
            pub = item.published_at
            if pub.tzinfo is None:
                pub = pub.replace(tzinfo=timezone.utc)
            fe.published(pub)
            fe.updated(pub)

        if feed_content_key and item.content_encrypted:
            # ── Authorised premium access ────────────────────────────────────
            try:
                full_content = decrypt_content(item.content_encrypted, feed_content_key)
                fe.content(full_content, type="html")
                fe.summary(item.summary or _truncate(full_content, 300))
            except Exception:
                # Decryption failed – fall through to teaser
                fe.summary(item.summary or "(content unavailable)")
        elif feed_content_key is None and item.content_encrypted:
            # ── Paywalled view ────────────────────────────────────────────────
            teaser = item.summary or "(premium content – subscribe to read)"
            paywall_notice = (
                f"{teaser}\n\n"
                f"⚡ This is premium content. Subscribe for "
                f"{feed.price_sats} sats/{feed.subscription_days} days at "
                f"{base_url}/api/v1/subscribe/{feed.id}"
            )
            fe.summary(paywall_notice)
            fe.content(paywall_notice, type="text")
        else:
            # ── Public item ───────────────────────────────────────────────────
            content = item.content_plain or item.summary or ""
            fe.content(content, type="html")
            fe.summary(item.summary or _truncate(content, 300))

    xml_bytes: bytes = fg.rss_str(pretty=True)
    elapsed_ms = (time.perf_counter() - t0) * 1000
    return xml_bytes, elapsed_ms


def generate_atom_feed(
    feed: Feed,
    items: List[FeedItem],
    base_url: str,
    feed_content_key: Optional[bytes] = None,
) -> Tuple[bytes, float]:
    """
    Build an Atom 1.0 feed. Same interface as generate_rss_feed.
    """
    t0 = time.perf_counter()

    fg = FeedGenerator()
    fg.id(f"{base_url}/feed/{feed.id}")
    fg.title(feed.title or "Untitled Feed")
    fg.description(feed.description or feed.title or "")
    fg.link(href=feed.link or f"{base_url}/feed/{feed.id}", rel="alternate")
    fg.link(href=f"{base_url}/api/v1/feed/{feed.id}/atom", rel="self")
    fg.language(feed.language or "en")

    for item in items:
        fe = fg.add_entry(order="append")
        fe.id(item.guid or _item_id_from_request(base_url, feed.id, item.id))
        fe.title(item.title)
        if item.link:
            fe.link(href=item.link)
        if item.author:
            fe.author({"name": item.author})
        if item.published_at:
            pub = item.published_at
            if pub.tzinfo is None:
                pub = pub.replace(tzinfo=timezone.utc)
            fe.published(pub)
            fe.updated(pub)

        if feed_content_key and item.content_encrypted:
            try:
                full_content = decrypt_content(item.content_encrypted, feed_content_key)
                fe.content(full_content, type="html")
            except Exception:
                fe.content(item.summary or "(decryption failed)", type="text")
        elif item.content_plain:
            fe.content(item.content_plain, type="html")
        else:
            fe.content(item.summary or "", type="text")

    xml_bytes: bytes = fg.atom_str(pretty=True)
    elapsed_ms = (time.perf_counter() - t0) * 1000
    return xml_bytes, elapsed_ms


# ── Helpers ────────────────────────────────────────────────────────────────────

def _truncate(text: str, max_chars: int) -> str:
    text = text.strip()
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rsplit(" ", 1)[0] + " …"
