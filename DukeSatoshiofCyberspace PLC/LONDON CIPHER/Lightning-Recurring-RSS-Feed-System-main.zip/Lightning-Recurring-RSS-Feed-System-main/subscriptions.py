"""
routers/subscriptions.py
────────────────────────
Subscription management.

Routes
──────
POST  /api/v1/subscribe/{feed_id}          – shortcut: create invoice for feed
GET   /api/v1/subscriptions                – list my subscriptions (subscriber)
GET   /api/v1/subscriptions/{feed_id}/status – subscription status for a feed
GET   /api/v1/subscriptions/admin          – all subscriptions for my feeds (publisher)
"""
from datetime import timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import (
    Feed, LightningInvoice, Publisher, Subscriber, Subscription,
    SubscriptionStatus, get_db, utcnow
)
from app.middleware.auth import (
    get_current_publisher,
    get_current_subscriber,
    get_subscriber_with_key,
)
from app.models.schemas import (
    InvoiceCreate, InvoiceOut, SubscriptionOut, SubscriptionStatusResponse
)
from app.services.subscription_manager import (
    check_subscription_active,
    create_subscription_invoice,
)

router = APIRouter(prefix="/api/v1", tags=["Subscriptions"])


# ── Subscribe (shortcut) ───────────────────────────────────────────────────────

@router.post(
    "/subscribe/{feed_id}",
    response_model=InvoiceOut,
    status_code=status.HTTP_201_CREATED,
    summary="Subscribe to a premium feed (generates Lightning invoice)",
)
async def subscribe_to_feed(
    feed_id: str,
    subscriber_and_key: tuple = Depends(get_subscriber_with_key),
    db: AsyncSession = Depends(get_db),
):
    """
    Convenience endpoint. Equivalent to POST /api/v1/payments/invoice with feed_id.

    Returns a BOLT-11 invoice. Pay it with any Lightning wallet, then call
    POST /api/v1/payments/verify to activate the subscription.
    """
    subscriber, _ = subscriber_and_key
    if not subscriber:
        raise HTTPException(status_code=401, detail="Authentication required")

    feed_result = await db.execute(
        select(Feed).where(Feed.id == feed_id, Feed.is_active == True)
    )
    feed: Optional[Feed] = feed_result.scalar_one_or_none()
    if not feed:
        raise HTTPException(status_code=404, detail="Feed not found")

    if feed.feed_type.value == "public":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Feed is public – no subscription needed",
        )

    invoice = await create_subscription_invoice(
        db=db,
        subscriber=subscriber,
        feed=feed,
    )
    return InvoiceOut.model_validate(invoice)


# ── List my subscriptions ──────────────────────────────────────────────────────

@router.get(
    "/subscriptions",
    response_model=List[SubscriptionOut],
    summary="List all subscriptions for the current subscriber",
)
async def list_my_subscriptions(
    subscriber: Subscriber = Depends(get_current_subscriber),
    db: AsyncSession = Depends(get_db),
    include_expired: bool = False,
):
    q = select(Subscription).where(Subscription.subscriber_id == subscriber.id)
    if not include_expired:
        q = q.where(Subscription.status == SubscriptionStatus.ACTIVE)
    q = q.order_by(Subscription.created_at.desc())

    result = await db.execute(q)
    return [SubscriptionOut.model_validate(s) for s in result.scalars().all()]


# ── Subscription status for a specific feed ────────────────────────────────────

@router.get(
    "/subscriptions/{feed_id}/status",
    response_model=SubscriptionStatusResponse,
    summary="Check subscription status for a specific feed",
)
async def subscription_status(
    feed_id: str,
    subscriber: Subscriber = Depends(get_current_subscriber),
    db: AsyncSession = Depends(get_db),
):
    """
    Returns whether the subscriber has an active subscription to the feed,
    along with expiry time and seconds remaining.
    """
    sub = await check_subscription_active(db, subscriber.id, feed_id)

    if not sub:
        return SubscriptionStatusResponse(
            feed_id=feed_id,
            subscriber_id=subscriber.id,
            is_active=False,
            status=SubscriptionStatus.EXPIRED,
            expires_at=None,
            seconds_remaining=None,
        )

    now = utcnow()
    seconds_remaining: Optional[int] = None
    if sub.expires_at:
        exp = sub.expires_at
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        delta = (exp - now).total_seconds()
        seconds_remaining = max(0, int(delta))

    return SubscriptionStatusResponse(
        feed_id=feed_id,
        subscriber_id=subscriber.id,
        is_active=sub.status == SubscriptionStatus.ACTIVE,
        status=sub.status,
        expires_at=sub.expires_at,
        seconds_remaining=seconds_remaining,
    )


# ── Publisher admin view ───────────────────────────────────────────────────────

@router.get(
    "/subscriptions/admin",
    response_model=List[SubscriptionOut],
    summary="List all subscribers across publisher's feeds (publisher auth)",
)
async def publisher_subscription_list(
    publisher: Publisher = Depends(get_current_publisher),
    db: AsyncSession = Depends(get_db),
    feed_id: Optional[str] = None,
):
    """List all active subscriptions across the publisher's feeds."""
    # Get all feed IDs owned by this publisher
    feed_result = await db.execute(
        select(Feed.id).where(
            Feed.publisher_id == publisher.id,
            Feed.is_active == True,
        )
    )
    feed_ids = [row[0] for row in feed_result.fetchall()]

    if not feed_ids:
        return []

    q = select(Subscription).where(
        Subscription.feed_id.in_([feed_id] if feed_id else feed_ids),
        Subscription.status == SubscriptionStatus.ACTIVE,
    ).order_by(Subscription.created_at.desc())

    result = await db.execute(q)
    return [SubscriptionOut.model_validate(s) for s in result.scalars().all()]
