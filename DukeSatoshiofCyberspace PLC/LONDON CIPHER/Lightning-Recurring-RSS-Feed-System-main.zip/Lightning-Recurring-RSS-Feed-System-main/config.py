"""
config.py – Centralised settings via pydantic-settings.
All values can be overridden via environment variables or a .env file.
"""
import os
import secrets
import base64
from functools import lru_cache
from typing import Literal
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # ── Application ────────────────────────────────────────────────────────────
    APP_NAME: str = "Lightning RSS Feed System"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    # ── Security ───────────────────────────────────────────────────────────────
    # Used for JWT signing.  Generate: python -c "import secrets; print(secrets.token_hex(32))"
    SECRET_KEY: str = secrets.token_hex(32)
    API_KEY_HEADER: str = "X-API-Key"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7   # 7 days

    # ── Database ───────────────────────────────────────────────────────────────
    # Switch to "postgresql+asyncpg://user:pass@host/db" for production.
    DATABASE_URL: str = "sqlite+aiosqlite:///./lightning_rss.db"
    DB_ECHO: bool = False          # Set True to log SQL queries

    # ── Lightning backend ──────────────────────────────────────────────────────
    LIGHTNING_BACKEND: Literal["lnbits", "lnd", "cln", "mock"] = "mock"

    # LNbits  (https://lnbits.com)
    LNBITS_URL: str = "http://localhost:5000"
    LNBITS_ADMIN_KEY: str = ""      # Full admin key
    LNBITS_INVOICE_KEY: str = ""    # Read/invoice key (less privileged)

    # LND  (gRPC)
    LND_HOST: str = "localhost:10009"
    LND_MACAROON_PATH: str = "/root/.lnd/data/chain/bitcoin/mainnet/admin.macaroon"
    LND_TLS_CERT_PATH: str = "/root/.lnd/tls.cert"

    # Core Lightning (CLN) – REST
    CLN_REST_URL: str = "http://localhost:3010"
    CLN_REST_MACAROON: str = ""

    # ── Encryption ─────────────────────────────────────────────────────────────
    # 32-byte master key, base64-encoded.
    # Generate: python -c "import os,base64; print(base64.b64encode(os.urandom(32)).decode())"
    MASTER_ENCRYPTION_KEY: str = base64.b64encode(os.urandom(32)).decode()

    # ── Subscription defaults ──────────────────────────────────────────────────
    DEFAULT_SUBSCRIPTION_DAYS: int = 30
    DEFAULT_FEED_PRICE_SATS: int = 1_000          # satoshis / period
    SUBSCRIPTION_GRACE_PERIOD_HOURS: int = 24     # grace after expiry
    INVOICE_EXPIRY_SECONDS: int = 3_600           # 1 hour

    # ── Rate limiting ──────────────────────────────────────────────────────────
    RATE_LIMIT_REQUESTS: int = 60
    RATE_LIMIT_WINDOW_SECONDS: int = 60

    # ── Webhook ────────────────────────────────────────────────────────────────
    WEBHOOK_SECRET: str = secrets.token_hex(16)

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
