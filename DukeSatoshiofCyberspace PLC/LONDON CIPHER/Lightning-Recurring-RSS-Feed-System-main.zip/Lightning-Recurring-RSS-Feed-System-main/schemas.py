"""
schemas.py – All Pydantic request/response models for the API.
"""
from __future__ import annotations

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, EmailStr, Field, field_validator
from app.database import FeedType, InvoiceStatus, SubscriptionStatus


# ── Shared / Base ────────────────────────────────────────────────────────────

class TimestampMixin(BaseModel):
    created_at: datetime
    updated_at: Optional[datetime] = None


# ── Publisher ────────────────────────────────────────────────────────────────

class PublisherCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=256)
    email: EmailStr
    password: str = Field(..., min_length=8, description="Used to derive the API key")

class PublisherOut(BaseModel):
    id: str
    name: str
    email: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class PublisherRegisterResponse(BaseModel):
    publisher: PublisherOut
    api_key: str = Field(..., description="Store this securely – shown only once")


# ── Subscriber ───────────────────────────────────────────────────────────────

class SubscriberCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=128)
    email: EmailStr
    password: str = Field(..., min_length=8)

class SubscriberOut(BaseModel):
    id: str
    username: str
    email: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class SubscriberRegisterResponse(BaseModel):
    subscriber: SubscriberOut
    api_key: str = Field(..., description="Store this securely – shown only once")


# ── Feed ─────────────────────────────────────────────────────────────────────

class FeedCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=512)
    description: Optional[str] = None
    link: Optional[str] = None
    language: str = Field(default="en", max_length=16)
    feed_type: FeedType = FeedType.PUBLIC
    price_sats: int = Field(default=1_000, ge=0, description="Satoshis per subscription period")
    subscription_days: int = Field(default=30, ge=1, le=365)

class FeedUpdate(BaseModel):
    title: Optional[str] = Field(None, max_length=512)
    description: Optional[str] = None
    price_sats: Optional[int] = Field(None, ge=1)
    subscription_days: Optional[int] = Field(None, ge=1, le=365)
    is_active: Optional[bool] = None

class FeedOut(BaseModel):
    id: str
    publisher_id: str
    title: str
    description: Optional[str]
    link: Optional[str]
    language: str
    feed_type: FeedType
    price_sats: int
    subscription_days: int
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


# ── Feed Items ────────────────────────────────────────────────────────────────

class FeedItemCreate(BaseModel):
    guid: str = Field(..., description="Stable unique identifier (URL or UUID)")
    title: str = Field(..., min_length=1, max_length=512)
    link: Optional[str] = None
    summary: Optional[str] = Field(None, description="Public teaser – always visible")
    content: str = Field(..., description="Full article content (will be encrypted for premium feeds)")
    author: Optional[str] = None
    published_at: Optional[datetime] = None

class FeedItemOut(BaseModel):
    id: str
    feed_id: str
    guid: str
    title: str
    link: Optional[str]
    summary: Optional[str]
    author: Optional[str]
    published_at: datetime
    is_encrypted: bool = False

    class Config:
        from_attributes = True

class FeedItemDecrypted(FeedItemOut):
    content: str   # Decrypted full content (only in premium responses)


# ── Lightning / Payments ─────────────────────────────────────────────────────

class InvoiceCreate(BaseModel):
    feed_id: str
    amount_sats: Optional[int] = Field(
        None,
        description="Override price in sats (defaults to feed's configured price)"
    )

class InvoiceOut(BaseModel):
    id: str
    subscriber_id: str
    feed_id: str
    payment_hash: str
    payment_request: str = Field(..., description="BOLT-11 invoice – scan with any Lightning wallet")
    amount_sats: int
    status: InvoiceStatus
    expires_at: datetime
    created_at: datetime

    class Config:
        from_attributes = True

class PaymentVerifyRequest(BaseModel):
    payment_hash: str = Field(..., description="Payment hash from the invoice")

class PaymentVerifyResponse(BaseModel):
    payment_hash: str
    paid: bool
    subscription_id: Optional[str] = None
    subscription_expires_at: Optional[datetime] = None
    message: str


# ── Subscriptions ─────────────────────────────────────────────────────────────

class SubscriptionOut(BaseModel):
    id: str
    subscriber_id: str
    feed_id: str
    status: SubscriptionStatus
    starts_at: Optional[datetime]
    expires_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True

class SubscriptionStatusResponse(BaseModel):
    feed_id: str
    subscriber_id: str
    is_active: bool
    status: SubscriptionStatus
    expires_at: Optional[datetime]
    seconds_remaining: Optional[int]


# ── RSS / Feed Response ───────────────────────────────────────────────────────

class RSSFeedResponse(BaseModel):
    """Metadata returned alongside the RSS XML."""
    feed_id: str
    title: str
    feed_type: FeedType
    item_count: int
    is_authenticated: bool
    has_active_subscription: bool


# ── Webhooks ──────────────────────────────────────────────────────────────────

class WebhookPayload(BaseModel):
    event: str                     # e.g. "payment.confirmed"
    payment_hash: str
    feed_id: str
    subscriber_id: str
    amount_sats: int
    timestamp: datetime


# ── Error Responses ───────────────────────────────────────────────────────────

class ErrorResponse(BaseModel):
    error: str
    detail: Optional[str] = None
    code: Optional[str] = None    # machine-readable error code

class HealthResponse(BaseModel):
    status: str
    version: str
    lightning_backend: str
    db_connected: bool
