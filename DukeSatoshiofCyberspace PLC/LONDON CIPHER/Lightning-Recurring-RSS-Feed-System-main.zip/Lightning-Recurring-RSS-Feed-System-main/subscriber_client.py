"""
client/subscriber_client.py
────────────────────────────
Example client demonstrating the full subscriber flow:

  1. Register a subscriber account
  2. Browse available premium feeds
  3. Request a Lightning invoice
  4. (Simulate) pay the invoice
  5. Verify payment → subscription activates
  6. Fetch and display the premium RSS feed

Run with:
    python -m client.subscriber_client --help
    python -m client.subscriber_client demo --base-url http://localhost:8000

For the demo to work end-to-end, start the server with LIGHTNING_BACKEND=mock.
"""
from __future__ import annotations

import asyncio
import sys
import time
from typing import Optional
from xml.etree import ElementTree as ET

import httpx
import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()


class LightningRSSClient:
    """Async client for the Lightning RSS API."""

    def __init__(self, base_url: str, api_key: Optional[str] = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self._client: Optional[httpx.AsyncClient] = None

    def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["X-API-Key"] = self.api_key
        return h

    async def __aenter__(self) -> "LightningRSSClient":
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self._headers(),
            timeout=30.0,
        )
        return self

    async def __aexit__(self, *args) -> None:
        if self._client:
            await self._client.aclose()

    def _check(self, resp: httpx.Response) -> dict:
        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise RuntimeError(f"HTTP {resp.status_code}: {detail}")
        return resp.json()

    # ── Auth ──────────────────────────────────────────────────────────────────

    async def register(self, username: str, email: str, password: str) -> dict:
        resp = await self._client.post("/api/v1/auth/subscriber/register", json={
            "username": username, "email": email, "password": password
        })
        return self._check(resp)

    # ── Feeds ─────────────────────────────────────────────────────────────────

    async def list_feeds(self, feed_type: Optional[str] = None) -> list:
        params = {}
        if feed_type:
            params["feed_type"] = feed_type
        resp = await self._client.get("/api/v1/feeds", params=params)
        return self._check(resp)

    # ── Subscribe ─────────────────────────────────────────────────────────────

    async def subscribe(self, feed_id: str) -> dict:
        resp = await self._client.post(f"/api/v1/subscribe/{feed_id}")
        return self._check(resp)

    # ── Verify payment ────────────────────────────────────────────────────────

    async def verify_payment(self, payment_hash: str) -> dict:
        resp = await self._client.post("/api/v1/payments/verify", json={
            "payment_hash": payment_hash
        })
        return self._check(resp)

    # ── Fetch RSS feed ────────────────────────────────────────────────────────

    async def fetch_rss(self, feed_id: str) -> bytes:
        resp = await self._client.get(
            f"/api/v1/feeds/{feed_id}/rss",
            headers={**self._headers(), "Accept": "application/rss+xml"},
        )
        if resp.status_code != 200:
            raise RuntimeError(f"HTTP {resp.status_code}: {resp.text}")
        return resp.content

    # ── Check subscription ────────────────────────────────────────────────────

    async def subscription_status(self, feed_id: str) -> dict:
        resp = await self._client.get(f"/api/v1/subscriptions/{feed_id}/status")
        return self._check(resp)

    # ── Poll until paid ───────────────────────────────────────────────────────

    async def wait_for_payment(
        self,
        payment_hash: str,
        timeout_seconds: int = 30,
        poll_interval: float = 2.0,
    ) -> dict:
        """Poll /payments/verify until paid=True or timeout."""
        deadline = time.monotonic() + timeout_seconds
        while time.monotonic() < deadline:
            result = await self.verify_payment(payment_hash)
            if result["paid"]:
                return result
            await asyncio.sleep(poll_interval)
        raise TimeoutError(f"Payment not confirmed within {timeout_seconds}s")


# ── RSS parsing helper ─────────────────────────────────────────────────────────

def parse_rss_items(xml_bytes: bytes) -> list[dict]:
    """Extract item titles and content from RSS XML."""
    items = []
    try:
        root = ET.fromstring(xml_bytes)
        # Handle both RSS 2.0 and Atom-style namespaces
        channel = root.find("channel")
        if channel is None:
            channel = root  # Atom
        for item_el in channel.findall("item"):
            title = item_el.findtext("title") or "(no title)"
            link  = item_el.findtext("link") or ""
            desc  = item_el.findtext("description") or ""
            # Try content:encoded
            content_el = item_el.find("{http://purl.org/rss/1.0/modules/content/}encoded")
            content = content_el.text if content_el is not None else desc
            items.append({"title": title, "link": link, "content": content})
    except ET.ParseError as e:
        console.print(f"[red]RSS parse error: {e}[/red]")
    return items


# ── CLI demo flow ──────────────────────────────────────────────────────────────

@click.group()
def cli():
    """⚡ Lightning RSS – Subscriber Client"""
    pass


@cli.command()
@click.option("--base-url", default="http://localhost:8000", help="API base URL")
@click.option("--feed-id", default=None, help="Feed ID to subscribe to (skip browse)")
async def demo(base_url: str, feed_id: Optional[str]):
    """
    Full end-to-end demo: register → browse → subscribe → pay → read.
    Requires the server to be running with LIGHTNING_BACKEND=mock.
    """
    import uuid
    rng = uuid.uuid4().hex[:6]
    username  = f"demo_user_{rng}"
    email     = f"demo_{rng}@example.com"
    password  = "demo_password_123"

    console.print(Panel(
        "[bold cyan]⚡ Lightning RSS – Subscriber Demo[/bold cyan]\n"
        "This demo will: register → browse feeds → subscribe → pay → read premium content.",
        title="Demo Starting",
    ))

    async with LightningRSSClient(base_url) as client:
        # Step 1: Register
        console.print("\n[bold]Step 1:[/bold] Registering subscriber…")
        reg = await client.register(username, email, password)
        api_key = reg["api_key"]
        console.print(f"  ✅  Registered as [cyan]{username}[/cyan]")
        console.print(f"  🔑  API Key: [dim]{api_key[:20]}…[/dim]")

        client.api_key = api_key
        client._client.headers.update({"X-API-Key": api_key})

        # Step 2: List premium feeds
        console.print("\n[bold]Step 2:[/bold] Browsing premium feeds…")
        feeds = await client.list_feeds(feed_type="premium")

        if not feeds and not feed_id:
            console.print("  [yellow]⚠  No premium feeds found. Create one via the CLI first.[/yellow]")
            console.print("  Tip: python -m cli.publisher_cli feed create --type premium --title 'My Blog'")
            return

        if feeds:
            table = Table(show_header=True, header_style="bold")
            table.add_column("ID", style="cyan")
            table.add_column("Title")
            table.add_column("Price (sats)", justify="right")
            table.add_column("Period")
            for f in feeds[:5]:
                table.add_row(
                    f["id"],
                    f["title"],
                    str(f["price_sats"]),
                    f"{f['subscription_days']}d",
                )
            console.print(table)

        target_feed_id = feed_id or feeds[0]["id"]
        console.print(f"  🎯  Target feed: [cyan]{target_feed_id}[/cyan]")

        # Step 3: Check if already subscribed
        status_data = await client.subscription_status(target_feed_id)
        if status_data["is_active"]:
            console.print("  ✅  Already have an active subscription!")
        else:
            # Step 4: Create invoice
            console.print("\n[bold]Step 3:[/bold] Creating Lightning invoice…")
            invoice = await client.subscribe(target_feed_id)
            console.print(f"  📄  Invoice created:")
            console.print(f"      Hash:    [yellow]{invoice['payment_hash'][:32]}…[/yellow]")
            console.print(f"      Amount:  [green]{invoice['amount_sats']} sats[/green]")
            console.print(f"      Expires: {invoice['expires_at'][:19]}")
            console.print(f"\n  BOLT-11 (scan with Lightning wallet):")
            console.print(f"  [dim]{invoice['payment_request'][:80]}…[/dim]")

            # Step 5: Wait for payment (mock backend auto-pays in ~5s)
            console.print("\n[bold]Step 4:[/bold] Waiting for payment…")
            console.print("  [dim](Mock backend will auto-pay in ~5 seconds)[/dim]")

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                transient=True,
            ) as progress:
                task = progress.add_task("Polling for payment confirmation…", total=None)
                try:
                    result = await client.wait_for_payment(
                        invoice["payment_hash"], timeout_seconds=30
                    )
                    progress.update(task, description="Payment confirmed!")
                except TimeoutError:
                    console.print("  [red]❌  Payment timed out.[/red]")
                    return

            console.print(f"  ✅  Payment confirmed!")
            console.print(f"  🎟  Subscription ID: {result['subscription_id']}")
            console.print(f"  ⏰  Expires: {result['subscription_expires_at']}")

        # Step 6: Fetch premium content
        console.print("\n[bold]Step 5:[/bold] Fetching premium RSS feed…")
        t0 = time.perf_counter()
        xml_bytes = await client.fetch_rss(target_feed_id)
        latency_ms = (time.perf_counter() - t0) * 1000

        console.print(f"  📡  Feed fetched in [green]{latency_ms:.1f}ms[/green] "
                      f"({len(xml_bytes):,} bytes)")

        items = parse_rss_items(xml_bytes)
        if items:
            console.print(f"\n  📰  Found [bold]{len(items)}[/bold] article(s):\n")
            for i, item in enumerate(items[:3], 1):
                content_preview = (item["content"] or "")[:200].strip()
                console.print(f"  [{i}] [bold]{item['title']}[/bold]")
                if item["link"]:
                    console.print(f"      🔗 {item['link']}")
                if content_preview:
                    console.print(f"      {content_preview}{'…' if len(item['content']) > 200 else ''}")
                console.print()
        else:
            console.print("  [yellow]Feed is empty – add items via the publisher CLI.[/yellow]")

    console.print(Panel(
        "[bold green]🎉  Demo complete![/bold green]\n\n"
        "The subscriber successfully:\n"
        "  1. Registered an account\n"
        "  2. Browsed premium feeds\n"
        "  3. Created a Lightning invoice\n"
        "  4. Confirmed payment (mock)\n"
        "  5. Read decrypted premium content",
        title="Done",
    ))


@cli.command()
@click.option("--base-url", default="http://localhost:8000", help="API base URL")
@click.option("--api-key", required=True, help="Subscriber API key")
@click.option("--feed-id", required=True, help="Feed ID")
@click.option("--output", default="-", help="Output file (- for stdout)")
def fetch(base_url: str, api_key: str, feed_id: str, output: str):
    """Fetch and display a feed (authenticated)."""
    async def _run():
        async with LightningRSSClient(base_url, api_key) as client:
            xml_bytes = await client.fetch_rss(feed_id)
            if output == "-":
                print(xml_bytes.decode())
            else:
                with open(output, "wb") as f:
                    f.write(xml_bytes)
                console.print(f"[green]Saved to {output}[/green]")
    asyncio.run(_run())


def _async_command(f):
    """Decorator to run async Click commands."""
    import functools
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        asyncio.run(f(*args, **kwargs))
    return wrapper


# Wrap async commands
demo.callback = _async_command(demo.callback) if demo.callback else None
# Re-register demo as sync wrapper
@cli.command("demo")
@click.option("--base-url", default="http://localhost:8000")
@click.option("--feed-id", default=None)
def demo_sync(base_url: str, feed_id: Optional[str]):
    """Full end-to-end demo flow."""
    asyncio.run(demo.callback(base_url=base_url, feed_id=feed_id) if demo.callback
                else _demo_impl(base_url, feed_id))


async def _demo_impl(base_url: str, feed_id: Optional[str]):
    # Re-use the demo coroutine directly
    import uuid
    rng = uuid.uuid4().hex[:6]
    username  = f"demo_user_{rng}"
    email     = f"demo_{rng}@example.com"
    password  = "demo_password_123"

    console.print(Panel(
        "[bold cyan]⚡ Lightning RSS – Subscriber Demo[/bold cyan]",
        title="Demo Starting",
    ))

    async with LightningRSSClient(base_url) as client:
        console.print("\n[bold]Registering subscriber…[/bold]")
        reg = await client.register(username, email, password)
        api_key = reg["api_key"]
        console.print(f"  ✅  Registered: {username}  |  Key: {api_key[:24]}…")
        client.api_key = api_key
        client._client.headers.update({"X-API-Key": api_key})

        feeds = await client.list_feeds("premium")
        if not feeds and not feed_id:
            console.print("  [yellow]No premium feeds. Create one first.[/yellow]")
            return

        target = feed_id or feeds[0]["id"]
        status_data = await client.subscription_status(target)

        if not status_data["is_active"]:
            invoice = await client.subscribe(target)
            console.print(f"  📄  Invoice: {invoice['amount_sats']} sats  |  Hash: {invoice['payment_hash'][:16]}…")
            console.print("  ⏳  Waiting for payment (mock auto-pays in ~5s)…")
            result = await client.wait_for_payment(invoice["payment_hash"])
            console.print(f"  ✅  Paid!  Subscription: {result['subscription_id']}")

        xml_bytes = await client.fetch_rss(target)
        items = parse_rss_items(xml_bytes)
        console.print(f"\n  📰  {len(items)} article(s) in premium feed:")
        for item in items[:3]:
            console.print(f"    • {item['title']}")


if __name__ == "__main__":
    cli()
