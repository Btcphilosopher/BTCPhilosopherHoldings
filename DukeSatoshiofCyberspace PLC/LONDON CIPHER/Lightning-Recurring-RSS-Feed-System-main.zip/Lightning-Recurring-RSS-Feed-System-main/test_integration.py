"""
tests/test_integration.py
──────────────────────────
Integration tests covering the full payment → subscription → feed flow.

Run with:
    cd lightning_rss
    pytest tests/ -v --asyncio-mode=auto
"""
import os
import base64
import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport

# Bootstrap env before importing app
os.environ["LIGHTNING_BACKEND"] = "mock"
os.environ["DATABASE_URL"] = "sqlite+aiosqlite:///:memory:"
os.environ["MASTER_ENCRYPTION_KEY"] = base64.b64encode(os.urandom(32)).decode()
os.environ["DEBUG"] = "true"

from app.main import app
from app.database import init_db, engine, Base


@pytest_asyncio.fixture(scope="session", autouse=True)
async def setup_db():
    await init_db()
    yield
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest_asyncio.fixture
async def client():
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://testserver",
    ) as c:
        yield c


# ── Helper fixtures ────────────────────────────────────────────────────────────

async def register_publisher(client: AsyncClient) -> dict:
    import uuid
    rng = uuid.uuid4().hex[:6]
    resp = await client.post("/api/v1/auth/publisher/register", json={
        "name": f"Test Publisher {rng}",
        "email": f"publisher_{rng}@test.com",
        "password": "securepassword123",
    })
    assert resp.status_code == 201, resp.text
    return resp.json()


async def register_subscriber(client: AsyncClient) -> dict:
    import uuid
    rng = uuid.uuid4().hex[:6]
    resp = await client.post("/api/v1/auth/subscriber/register", json={
        "username": f"subscriber_{rng}",
        "email": f"subscriber_{rng}@test.com",
        "password": "securepassword123",
    })
    assert resp.status_code == 201, resp.text
    return resp.json()


# ── Tests ──────────────────────────────────────────────────────────────────────

class TestHealth:
    async def test_health_endpoint(self, client):
        resp = await client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert data["lightning_backend"] == "mock"


class TestAuth:
    async def test_register_publisher(self, client):
        data = await register_publisher(client)
        assert "api_key" in data
        assert data["api_key"].startswith("lrss_")
        assert data["publisher"]["is_active"] is True

    async def test_register_subscriber(self, client):
        data = await register_subscriber(client)
        assert "api_key" in data
        assert data["api_key"].startswith("lrss_")

    async def test_register_duplicate_email(self, client):
        import uuid; rng = uuid.uuid4().hex[:6]
        payload = {"name": "Dup", "email": f"dup_{rng}@test.com", "password": "pass12345"}
        r1 = await client.post("/api/v1/auth/publisher/register", json=payload)
        assert r1.status_code == 201
        r2 = await client.post("/api/v1/auth/publisher/register", json=payload)
        assert r2.status_code == 409

    async def test_me_publisher_requires_auth(self, client):
        resp = await client.get("/api/v1/auth/me/publisher")
        assert resp.status_code == 401

    async def test_me_publisher_authenticated(self, client):
        reg = await register_publisher(client)
        resp = await client.get(
            "/api/v1/auth/me/publisher",
            headers={"X-API-Key": reg["api_key"]},
        )
        assert resp.status_code == 200
        assert resp.json()["email"] == reg["publisher"]["email"]


class TestFeeds:
    async def test_create_public_feed(self, client):
        pub = await register_publisher(client)
        resp = await client.post(
            "/api/v1/feeds",
            json={"title": "Public News", "feed_type": "public", "price_sats": 0, "subscription_days": 30},
            headers={"X-API-Key": pub["api_key"]},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["feed_type"] == "public"
        assert data["title"] == "Public News"

    async def test_create_premium_feed(self, client):
        pub = await register_publisher(client)
        resp = await client.post(
            "/api/v1/feeds",
            json={"title": "Premium Feed", "feed_type": "premium",
                  "price_sats": 1000, "subscription_days": 30},
            headers={"X-API-Key": pub["api_key"]},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["feed_type"] == "premium"
        assert data["price_sats"] == 1000

    async def test_create_feed_requires_auth(self, client):
        resp = await client.post(
            "/api/v1/feeds",
            json={"title": "Test", "feed_type": "public", "price_sats": 0, "subscription_days": 30},
        )
        assert resp.status_code == 401

    async def test_list_feeds(self, client):
        resp = await client.get("/api/v1/feeds")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)


class TestFeedItems:
    async def test_add_public_item(self, client):
        pub = await register_publisher(client)
        feed_resp = await client.post(
            "/api/v1/feeds",
            json={"title": "Public", "feed_type": "public", "price_sats": 0, "subscription_days": 30},
            headers={"X-API-Key": pub["api_key"]},
        )
        feed_id = feed_resp.json()["id"]

        item_resp = await client.post(
            f"/api/v1/feeds/{feed_id}/items",
            json={
                "guid": "https://example.com/article/1",
                "title": "Test Article",
                "summary": "A teaser.",
                "content": "<p>Full content here.</p>",
                "author": "Test Author",
            },
            headers={"X-API-Key": pub["api_key"]},
        )
        assert item_resp.status_code == 201
        item = item_resp.json()
        assert item["is_encrypted"] is False  # public feed → plaintext

    async def test_add_premium_item_is_encrypted(self, client):
        pub = await register_publisher(client)
        feed_resp = await client.post(
            "/api/v1/feeds",
            json={"title": "Premium", "feed_type": "premium",
                  "price_sats": 1000, "subscription_days": 30},
            headers={"X-API-Key": pub["api_key"]},
        )
        feed_id = feed_resp.json()["id"]

        item_resp = await client.post(
            f"/api/v1/feeds/{feed_id}/items",
            json={
                "guid": "https://example.com/premium/1",
                "title": "Secret Article",
                "summary": "Teaser only.",
                "content": "This is the secret content.",
            },
            headers={"X-API-Key": pub["api_key"]},
        )
        assert item_resp.status_code == 201
        assert item_resp.json()["is_encrypted"] is True


class TestRSSServing:
    async def _setup_feed_with_item(self, client):
        pub = await register_publisher(client)
        feed_resp = await client.post(
            "/api/v1/feeds",
            json={"title": "RSS Premium", "feed_type": "premium",
                  "price_sats": 500, "subscription_days": 7},
            headers={"X-API-Key": pub["api_key"]},
        )
        feed_id = feed_resp.json()["id"]
        await client.post(
            f"/api/v1/feeds/{feed_id}/items",
            json={
                "guid": f"https://example.com/rss-test/1",
                "title": "Gated Article",
                "summary": "Public teaser.",
                "content": "SECRET: Full premium content.",
            },
            headers={"X-API-Key": pub["api_key"]},
        )
        return feed_id

    async def test_public_rss_no_auth(self, client):
        pub = await register_publisher(client)
        feed_resp = await client.post(
            "/api/v1/feeds",
            json={"title": "Public RSS", "feed_type": "public",
                  "price_sats": 0, "subscription_days": 30},
            headers={"X-API-Key": pub["api_key"]},
        )
        feed_id = feed_resp.json()["id"]
        resp = await client.get(f"/api/v1/feeds/{feed_id}/rss")
        assert resp.status_code == 200
        assert b"<rss" in resp.content

    async def test_premium_feed_unauthenticated_returns_teaser(self, client):
        feed_id = await self._setup_feed_with_item(client)
        resp = await client.get(f"/api/v1/feeds/{feed_id}/rss")
        assert resp.status_code == 200
        xml = resp.content.decode()
        # Full secret content should NOT appear
        assert "SECRET:" not in xml
        # Teaser / paywall notice should appear
        assert "subscribe" in xml.lower() or "premium" in xml.lower() or "Public teaser" in xml

    async def test_premium_feed_authenticated_without_sub_returns_teaser(self, client):
        feed_id = await self._setup_feed_with_item(client)
        sub = await register_subscriber(client)
        resp = await client.get(
            f"/api/v1/feeds/{feed_id}/rss",
            headers={"X-API-Key": sub["api_key"]},
        )
        assert resp.status_code == 200
        assert "SECRET:" not in resp.content.decode()

    async def test_premium_feed_with_active_sub_returns_full_content(self, client):
        feed_id = await self._setup_feed_with_item(client)
        sub = await register_subscriber(client)
        sub_headers = {"X-API-Key": sub["api_key"]}

        # Create invoice
        inv_resp = await client.post(
            f"/api/v1/subscribe/{feed_id}",
            headers=sub_headers,
        )
        assert inv_resp.status_code == 201
        payment_hash = inv_resp.json()["payment_hash"]

        # Simulate payment (mock backend marks as paid after a tick)
        from app.services.lightning import get_lightning_backend
        backend = get_lightning_backend()
        backend.mark_paid(payment_hash)

        # Verify payment
        verify_resp = await client.post(
            "/api/v1/payments/verify",
            json={"payment_hash": payment_hash},
            headers=sub_headers,
        )
        assert verify_resp.json()["paid"] is True

        # Now fetch premium content
        feed_resp = await client.get(
            f"/api/v1/feeds/{feed_id}/rss",
            headers=sub_headers,
        )
        assert feed_resp.status_code == 200
        xml = feed_resp.content.decode()
        assert "SECRET: Full premium content." in xml


class TestPayments:
    async def test_create_invoice(self, client):
        pub = await register_publisher(client)
        feed_resp = await client.post(
            "/api/v1/feeds",
            json={"title": "Paid Feed", "feed_type": "premium",
                  "price_sats": 2000, "subscription_days": 30},
            headers={"X-API-Key": pub["api_key"]},
        )
        feed_id = feed_resp.json()["id"]

        sub = await register_subscriber(client)
        inv_resp = await client.post(
            "/api/v1/payments/invoice",
            json={"feed_id": feed_id},
            headers={"X-API-Key": sub["api_key"]},
        )
        assert inv_resp.status_code == 201
        inv = inv_resp.json()
        assert inv["amount_sats"] == 2000
        assert inv["status"] == "pending"
        assert inv["payment_request"].startswith("lnbc")

    async def test_verify_unpaid_invoice(self, client):
        pub = await register_publisher(client)
        feed_resp = await client.post(
            "/api/v1/feeds",
            json={"title": "Another Feed", "feed_type": "premium",
                  "price_sats": 500, "subscription_days": 30},
            headers={"X-API-Key": pub["api_key"]},
        )
        feed_id = feed_resp.json()["id"]

        sub = await register_subscriber(client)
        inv_resp = await client.post(
            "/api/v1/payments/invoice",
            json={"feed_id": feed_id},
            headers={"X-API-Key": sub["api_key"]},
        )
        payment_hash = inv_resp.json()["payment_hash"]

        verify_resp = await client.post(
            "/api/v1/payments/verify",
            json={"payment_hash": payment_hash},
            headers={"X-API-Key": sub["api_key"]},
        )
        assert verify_resp.status_code == 200
        assert verify_resp.json()["paid"] is False

    async def test_public_feed_invoice_rejected(self, client):
        pub = await register_publisher(client)
        feed_resp = await client.post(
            "/api/v1/feeds",
            json={"title": "Free Feed", "feed_type": "public",
                  "price_sats": 0, "subscription_days": 30},
            headers={"X-API-Key": pub["api_key"]},
        )
        feed_id = feed_resp.json()["id"]

        sub = await register_subscriber(client)
        inv_resp = await client.post(
            "/api/v1/payments/invoice",
            json={"feed_id": feed_id},
            headers={"X-API-Key": sub["api_key"]},
        )
        assert inv_resp.status_code == 400


class TestCrypto:
    def test_encrypt_decrypt_roundtrip(self):
        from app.services.crypto import (
            generate_feed_content_key, encrypt_content, decrypt_content
        )
        key = generate_feed_content_key()
        plaintext = "Hello Lightning! " * 100
        ciphertext = encrypt_content(plaintext, key)
        assert ciphertext != plaintext
        recovered = decrypt_content(ciphertext, key)
        assert recovered == plaintext

    def test_different_nonces_each_call(self):
        from app.services.crypto import generate_feed_content_key, encrypt_content
        key = generate_feed_content_key()
        ct1 = encrypt_content("same content", key)
        ct2 = encrypt_content("same content", key)
        # Nonces differ → ciphertexts differ (critical for AEAD security)
        assert ct1 != ct2

    def test_wrong_key_raises(self):
        from app.services.crypto import generate_feed_content_key, encrypt_content, decrypt_content
        from cryptography.exceptions import InvalidTag
        key1 = generate_feed_content_key()
        key2 = generate_feed_content_key()
        ct = encrypt_content("secret", key1)
        with pytest.raises((InvalidTag, Exception)):
            decrypt_content(ct, key2)

    def test_master_key_wrap_unwrap(self):
        from app.services.crypto import (
            generate_feed_content_key,
            encrypt_key_with_master,
            decrypt_key_with_master,
        )
        key = generate_feed_content_key()
        wrapped = encrypt_key_with_master(key)
        unwrapped = decrypt_key_with_master(wrapped)
        assert unwrapped == key

    def test_api_key_generation(self):
        from app.services.crypto import generate_api_key, api_key_to_raw
        display, raw = generate_api_key()
        assert display.startswith("lrss_")
        assert len(raw) == 32
        recovered = api_key_to_raw(display)
        assert recovered == raw
