"""
routers/feeds.py
────────────────
Feed CRUD and RSS/Atom serving endpoints.

Publishers manage feeds; subscribers consume them.

Routes
──────
POST   /api/v1/feeds                       – create feed (publisher)
GET    /api/v1/feeds                       – list all active feeds (public)
GET    /api/v1/feeds/{feed_id}             – feed metadata (public)
PATCH  /api/v1/feeds/{feed_id}             – update feed (publisher, owner only)
DELETE /api/v1/feeds/{feed_id}             – deactivate feed (publisher, owner only)

POST   /api/v1/feeds/{feed_id}/items       – add item to feed (publisher)

GET    /api/v1/feeds/{feed_id}/rss         – RSS 2.0  (public or gated)
GET    /api/v1/feeds/{feed_id}/atom        – Atom 1.0 (public or gated)
"""
import time
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.database import (
    Feed, FeedItem, FeedType, Publisher, Subscriber, get_db, utcnow
)
from app.middleware.auth import get_current_publisher, get_optional_subscriber
from app.models.schemas import FeedCreate, FeedItemCreate, FeedItemOut, FeedOut, FeedUpdate
from app.services.crypto import (
    decrypt_key_with_master,
    encrypt_content,
    encrypt_key_with_master,
    generate_feed_content_key,
)
from app.services.rss_generator import generate_atom_feed, generate_rss_feed
from app.services.subscription_manager import check_subscription_active

router = APIRouter(prefix="/api/v1/feeds", tags=["Feeds"])


# ── Create feed ────────────────────────────────────────────────────────────────

@router.post(
    "",
    response_model=FeedOut,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new RSS feed",
)
async def create_feed(
    body: FeedCreate,
    publisher: Publisher = Depends(get_current_publisher),
    db: AsyncSession = Depends(get_db),
):
    """
    Create a feed. Premium feeds automatically receive an AES-256 content key
    (ChaCha20-Poly1305) stored encrypted with the master server key.
    """
    content_key_encrypted = None
    if body.feed_type == FeedType.PREMIUM:
        raw_key = generate_feed_content_key()
        content_key_encrypted = encrypt_key_with_master(raw_key)

    feed = Feed(
        publisher_id=publisher.id,
        title=body.title,
        description=body.description,
        link=body.link,
        language=body.language,
        feed_type=body.feed_type,
        price_sats=body.price_sats,
        subscription_days=body.subscription_days,
        content_key_encrypted=content_key_encrypted,
    )
    db.add(feed)
    await db.flush()
    return FeedOut.model_validate(feed)


# ── List feeds (public) ────────────────────────────────────────────────────────

@router.get(
    "",
    response_model=List[FeedOut],
    summary="List all active feeds",
)
async def list_feeds(
    feed_type: Optional[FeedType] = None,
    skip: int = 0,
    limit: int = 50,
    db: AsyncSession = Depends(get_db),
):
    q = select(Feed).where(Feed.is_active == True)
    if feed_type:
        q = q.where(Feed.feed_type == feed_type)
    q = q.offset(skip).limit(limit)
    result = await db.execute(q)
    return [FeedOut.model_validate(f) for f in result.scalars().all()]


# ── Get feed metadata ─────────────────────────────────────────────────────────

@router.get(
    "/{feed_id}",
    response_model=FeedOut,
    summary="Get feed metadata",
)
async def get_feed(feed_id: str, db: AsyncSession = Depends(get_db)):
    feed = await _get_feed_or_404(db, feed_id)
    return FeedOut.model_validate(feed)


# ── Update feed ────────────────────────────────────────────────────────────────

@router.patch(
    "/{feed_id}",
    response_model=FeedOut,
    summary="Update feed (publisher owner only)",
)
async def update_feed(
    feed_id: str,
    body: FeedUpdate,
    publisher: Publisher = Depends(get_current_publisher),
    db: AsyncSession = Depends(get_db),
):
    feed = await _get_feed_or_404(db, feed_id)
    _assert_feed_owner(feed, publisher)

    for field, value in body.model_dump(exclude_none=True).items():
        setattr(feed, field, value)
    feed.updated_at = utcnow()
    await db.flush()
    return FeedOut.model_validate(feed)


# ── Delete / deactivate feed ───────────────────────────────────────────────────

@router.delete(
    "/{feed_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Deactivate feed (publisher owner only)",
)
async def delete_feed(
    feed_id: str,
    publisher: Publisher = Depends(get_current_publisher),
    db: AsyncSession = Depends(get_db),
):
    feed = await _get_feed_or_404(db, feed_id)
    _assert_feed_owner(feed, publisher)
    feed.is_active = False
    feed.updated_at = utcnow()
    await db.flush()


# ── Add item to feed ───────────────────────────────────────────────────────────

@router.post(
    "/{feed_id}/items",
    response_model=FeedItemOut,
    status_code=status.HTTP_201_CREATED,
    summary="Add an item to a feed",
)
async def add_feed_item(
    feed_id: str,
    body: FeedItemCreate,
    publisher: Publisher = Depends(get_current_publisher),
    db: AsyncSession = Depends(get_db),
):
    """
    Add an article to the feed.
    For premium feeds, the full content is encrypted at rest.
    The `summary` field is always stored unencrypted (public teaser).
    """
    feed = await _get_feed_or_404(db, feed_id)
    _assert_feed_owner(feed, publisher)

    content_encrypted = None
    content_plain = None

    if feed.feed_type == FeedType.PREMIUM and feed.content_key_encrypted:
        feed_key = decrypt_key_with_master(feed.content_key_encrypted)
        content_encrypted = encrypt_content(body.content, feed_key)
    else:
        content_plain = body.content

    item = FeedItem(
        feed_id=feed.id,
        guid=body.guid,
        title=body.title,
        link=body.link,
        summary=body.summary,
        content_encrypted=content_encrypted,
        content_plain=content_plain,
        author=body.author,
        published_at=body.published_at or utcnow(),
    )
    db.add(item)
    await db.flush()

    return FeedItemOut(
        id=item.id,
        feed_id=item.feed_id,
        guid=item.guid,
        title=item.title,
        link=item.link,
        summary=item.summary,
        author=item.author,
        published_at=item.published_at,
        is_encrypted=bool(item.content_encrypted),
    )


# ── RSS / Atom feed serving ────────────────────────────────────────────────────

@router.get(
    "/{feed_id}/rss",
    summary="Serve RSS 2.0 feed",
    response_class=Response,
)
async def serve_rss(
    feed_id: str,
    request: Request,
    subscriber: Optional[Subscriber] = Depends(get_optional_subscriber),
    db: AsyncSession = Depends(get_db),
):
    return await _serve_feed(
        feed_id=feed_id,
        request=request,
        subscriber=subscriber,
        db=db,
        fmt="rss",
    )


@router.get(
    "/{feed_id}/atom",
    summary="Serve Atom 1.0 feed",
    response_class=Response,
)
async def serve_atom(
    feed_id: str,
    request: Request,
    subscriber: Optional[Subscriber] = Depends(get_optional_subscriber),
    db: AsyncSession = Depends(get_db),
):
    return await _serve_feed(
        feed_id=feed_id,
        request=request,
        subscriber=subscriber,
        db=db,
        fmt="atom",
    )


# ── Feed serving logic ─────────────────────────────────────────────────────────

async def _serve_feed(
    feed_id: str,
    request: Request,
    subscriber: Optional[Subscriber],
    db: AsyncSession,
    fmt: str = "rss",
) -> Response:
    """
    Core feed-serving logic.

    Access matrix
    ─────────────
    Feed type │ Auth?   │ Active sub? │ Result
    ──────────┼─────────┼─────────────┼────────────────────────────
    public    │ any     │ any         │ full content
    premium   │ no      │ –           │ teasers + paywall notice
    premium   │ yes     │ no          │ teasers + paywall notice
    premium   │ yes     │ yes         │ full decrypted content
    """
    t0 = time.perf_counter()

    feed = await _get_feed_or_404(db, feed_id)

    # Load items ordered newest-first
    result = await db.execute(
        select(FeedItem)
        .where(FeedItem.feed_id == feed_id)
        .order_by(FeedItem.published_at.desc())
        .limit(50)
    )
    items = result.scalars().all()

    feed_content_key: Optional[bytes] = None

    if feed.feed_type == FeedType.PREMIUM:
        if subscriber:
            sub = await check_subscription_active(db, subscriber.id, feed_id)
            if sub and feed.content_key_encrypted:
                feed_content_key = decrypt_key_with_master(feed.content_key_encrypted)
        # else: key stays None → paywall view

    base_url = str(request.base_url).rstrip("/")

    if fmt == "atom":
        xml_bytes, gen_ms = generate_atom_feed(feed, items, base_url, feed_content_key)
        media_type = "application/atom+xml"
    else:
        xml_bytes, gen_ms = generate_rss_feed(feed, items, base_url, feed_content_key)
        media_type = "application/rss+xml"

    total_ms = (time.perf_counter() - t0) * 1000

    return Response(
        content=xml_bytes,
        media_type=media_type,
        headers={
            "X-Feed-Generation-Ms": f"{gen_ms:.2f}",
            "X-Total-Response-Ms": f"{total_ms:.2f}",
            "X-Feed-Type": feed.feed_type.value,
            "X-Authenticated": str(subscriber is not None).lower(),
            "X-Has-Subscription": str(feed_content_key is not None).lower(),
            "Cache-Control": "no-store" if feed.feed_type == FeedType.PREMIUM else "max-age=300",
        },
    )


# ── Helpers ────────────────────────────────────────────────────────────────────

async def _get_feed_or_404(db: AsyncSession, feed_id: str) -> Feed:
    result = await db.execute(
        select(Feed).where(Feed.id == feed_id, Feed.is_active == True)
    )
    feed = result.scalar_one_or_none()
    if not feed:
        raise HTTPException(status_code=404, detail="Feed not found")
    return feed


def _assert_feed_owner(feed: Feed, publisher: Publisher) -> None:
    if feed.publisher_id != publisher.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not own this feed",
        )
