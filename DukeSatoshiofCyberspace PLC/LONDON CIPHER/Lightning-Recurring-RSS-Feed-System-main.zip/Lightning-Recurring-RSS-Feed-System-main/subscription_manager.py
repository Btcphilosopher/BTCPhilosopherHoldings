"""
services/subscription_manager.py
─────────────────────────────────
Business logic for subscription lifecycle:
  create invoice → poll/verify payment → activate subscription → check access.
"""
from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone, timedelta
from typing import Optional, Tuple

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.database import (
    LightningInvoice, Subscription, Feed, Subscriber,
    InvoiceStatus, SubscriptionStatus, WebhookEvent, utcnow
)
from app.services.lightning import get_lightning_backend
from app.services.crypto import (
    decrypt_key_with_master,
    derive_subscriber_key,
    wrap_feed_key_for_subscriber,
    api_key_to_raw,
)

logger = logging.getLogger(__name__)


# ── Invoice creation ───────────────────────────────────────────────────────────

async def create_subscription_invoice(
    db: AsyncSession,
    subscriber: Subscriber,
    feed: Feed,
    amount_sats: Optional[int] = None,
) -> LightningInvoice:
    """
    Create a Lightning invoice for one subscription period.
    Returns the persisted LightningInvoice row.
    """
    sats = amount_sats or feed.price_sats
    description = f"Lightning RSS – {feed.title} ({feed.subscription_days}d subscription)"

    backend = get_lightning_backend()
    invoice_data = await backend.create_invoice(
        amount_sats=sats,
        description=description,
        expiry_seconds=settings.INVOICE_EXPIRY_SECONDS,
    )

    db_invoice = LightningInvoice(
        subscriber_id=subscriber.id,
        feed_id=feed.id,
        payment_hash=invoice_data.payment_hash,
        payment_request=invoice_data.payment_request,
        amount_sats=sats,
        description=description,
        status=InvoiceStatus.PENDING,
        expires_at=invoice_data.expires_at,
        backend_invoice_id=invoice_data.backend_id,
    )
    db.add(db_invoice)
    await db.flush()   # get the ID without committing

    return db_invoice


# ── Payment verification ───────────────────────────────────────────────────────

async def verify_and_activate(
    db: AsyncSession,
    invoice: LightningInvoice,
    subscriber_api_key_raw: Optional[bytes] = None,
) -> Tuple[bool, Optional[Subscription]]:
    """
    Check with the Lightning backend whether `invoice` has been paid.
    If paid, activate (or extend) the associated Subscription.

    Returns (was_paid, subscription_or_None).
    """
    if invoice.status == InvoiceStatus.PAID:
        # Already confirmed – return existing subscription
        sub = await _get_subscription_for_invoice(db, invoice)
        return True, sub

    if invoice.status == InvoiceStatus.EXPIRED:
        return False, None

    backend = get_lightning_backend()
    payment_status = await backend.check_payment(invoice.payment_hash)

    if not payment_status.paid:
        # Check expiry - normalize timezone comparison
        expires_at = invoice.expires_at
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > expires_at:
            invoice.status = InvoiceStatus.EXPIRED
            await db.flush()
        return False, None

    # ── Payment confirmed ──────────────────────────────────────────────────────
    invoice.status = InvoiceStatus.PAID
    invoice.paid_at = payment_status.settled_at or utcnow()
    await db.flush()

    subscription = await _activate_subscription(
        db=db,
        invoice=invoice,
        subscriber_api_key_raw=subscriber_api_key_raw,
    )

    # Fire webhook (best-effort)
    asyncio.create_task(
        _fire_webhook(db, invoice, subscription)
    )

    return True, subscription


async def _activate_subscription(
    db: AsyncSession,
    invoice: LightningInvoice,
    subscriber_api_key_raw: Optional[bytes] = None,
) -> Subscription:
    """
    Create or extend a Subscription row once payment is confirmed.
    Also computes the per-subscriber content key wrapper.
    """
    feed_result = await db.execute(select(Feed).where(Feed.id == invoice.feed_id))
    feed: Feed = feed_result.scalar_one()

    # Calculate period
    now = utcnow()
    expires_at = now + timedelta(days=feed.subscription_days)

    # Compute subscriber_content_key if feed is premium and we have the API key
    subscriber_content_key: Optional[str] = None
    if feed.content_key_encrypted and subscriber_api_key_raw:
        try:
            feed_key = decrypt_key_with_master(feed.content_key_encrypted)
            sub_derived = derive_subscriber_key(subscriber_api_key_raw, feed.id)
            subscriber_content_key = wrap_feed_key_for_subscriber(feed_key, sub_derived)
        except Exception as e:
            logger.warning(f"Could not compute subscriber content key: {e}")

    # Check for existing subscription to extend
    existing_result = await db.execute(
        select(Subscription).where(
            Subscription.subscriber_id == invoice.subscriber_id,
            Subscription.feed_id == invoice.feed_id,
            Subscription.status == SubscriptionStatus.ACTIVE,
        )
    )
    existing: Optional[Subscription] = existing_result.scalar_one_or_none()

    if existing:
        # Extend
        if existing.expires_at and existing.expires_at > now:
            existing.expires_at = existing.expires_at + timedelta(days=feed.subscription_days)
        else:
            existing.starts_at = now
            existing.expires_at = expires_at
        existing.updated_at = now
        if subscriber_content_key:
            existing.subscriber_content_key = subscriber_content_key
        await db.flush()
        return existing

    # Create new
    sub = Subscription(
        subscriber_id=invoice.subscriber_id,
        feed_id=invoice.feed_id,
        invoice_id=invoice.id,
        status=SubscriptionStatus.ACTIVE,
        starts_at=now,
        expires_at=expires_at,
        subscriber_content_key=subscriber_content_key,
    )
    db.add(sub)
    await db.flush()
    return sub


async def _get_subscription_for_invoice(
    db: AsyncSession,
    invoice: LightningInvoice,
) -> Optional[Subscription]:
    result = await db.execute(
        select(Subscription).where(Subscription.invoice_id == invoice.id)
    )
    return result.scalar_one_or_none()


# ── Access check ───────────────────────────────────────────────────────────────

async def check_subscription_active(
    db: AsyncSession,
    subscriber_id: str,
    feed_id: str,
) -> Optional[Subscription]:
    """
    Return the active subscription (within grace period) or None.
    SQLite strips timezone info; we normalise expires_at on the Python side.
    """
    result = await db.execute(
        select(Subscription).where(
            Subscription.subscriber_id == subscriber_id,
            Subscription.feed_id == feed_id,
            Subscription.status == SubscriptionStatus.ACTIVE,
        ).order_by(Subscription.expires_at.desc())
    )
    subs = result.scalars().all()

    grace = timedelta(hours=settings.SUBSCRIPTION_GRACE_PERIOD_HOURS)
    cutoff = utcnow() - grace

    for sub in subs:
        if sub.expires_at is None:
            continue
        exp = sub.expires_at
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        if exp >= cutoff:
            return sub

    return None


async def expire_stale_subscriptions(db: AsyncSession) -> int:
    """
    Mark subscriptions past their expiry + grace period as EXPIRED.
    Called by a background task / cron job.
    Returns number of rows updated.
    """
    grace = timedelta(hours=settings.SUBSCRIPTION_GRACE_PERIOD_HOURS)
    cutoff = utcnow() - grace

    result = await db.execute(
        select(Subscription).where(
            Subscription.status == SubscriptionStatus.ACTIVE,
            Subscription.expires_at < cutoff,
        )
    )
    subs = result.scalars().all()
    for sub in subs:
        sub.status = SubscriptionStatus.EXPIRED

    await db.flush()
    return len(subs)


# ── Polling task (simulate recurring payment reminders) ───────────────────────

async def poll_pending_invoices(db: AsyncSession) -> int:
    """
    Check all PENDING invoices against the Lightning backend.
    Run this periodically (e.g. every 30 seconds via APScheduler).
    Returns number of invoices settled.
    """
    result = await db.execute(
        select(LightningInvoice).where(
            LightningInvoice.status == InvoiceStatus.PENDING,
            LightningInvoice.expires_at >= utcnow(),
        )
    )
    pending = result.scalars().all()
    settled = 0
    for invoice in pending:
        paid, _ = await verify_and_activate(db, invoice)
        if paid:
            settled += 1
    return settled


# ── Webhook delivery ───────────────────────────────────────────────────────────

async def _fire_webhook(
    db: AsyncSession,
    invoice: LightningInvoice,
    subscription: Subscription,
) -> None:
    """
    Deliver a payment.confirmed webhook to any registered URL.
    (Webhook URL management left as an extension exercise.)
    """
    payload = {
        "event": "payment.confirmed",
        "payment_hash": invoice.payment_hash,
        "feed_id": invoice.feed_id,
        "subscriber_id": invoice.subscriber_id,
        "amount_sats": invoice.amount_sats,
        "subscription_expires_at": subscription.expires_at.isoformat()
            if subscription.expires_at else None,
        "timestamp": utcnow().isoformat(),
    }
    event = WebhookEvent(
        event_type="payment.confirmed",
        payload=json.dumps(payload),
        target_url=None,   # populate from publisher webhook config
    )
    db.add(event)
    await db.flush()

    # In production, use a task queue (Celery/ARQ) for reliable delivery.
    # Here we show a simple direct HTTP attempt.
    # target_urls = await get_publisher_webhook_urls(db, invoice.feed_id)
    # for url in target_urls:
    #     await _deliver_to_url(url, payload)
    logger.info(f"Webhook queued: payment.confirmed for invoice {invoice.id}")
