//! LONDON CIPHER — High-Performance Streaming & Integrity Verification Core
use aes_gcm::{
    aead::{Aead, KeyInit, Payload},
    Aes256Gcm, Nonce,
};
use sha2::{Digest, Sha256};
use std::io::{Read, Write};

pub const CHUNK_SIZE: usize = 64 * 1024 * 1024; // 64 MB streaming chunks

#[derive(Debug, Clone)]
pub struct StreamCommitment {
    pub chunk_count: u64,
    pub total_bytes: u64,
    pub merkle_root: [u8; 32],
}

pub struct StreamEncryptor {
    cipher: Aes256Gcm,
    hasher: Sha256,
}

impl StreamEncryptor {
    pub fn new(key: &[u8; 32]) -> Self {
        Self {
            cipher: Aes256Gcm::new(key.into()),
            hasher: Sha256::new(),
        }
    }

    pub fn encrypt_stream<R: Read, W: Write>(
        &mut self,
        mut reader: R,
        mut writer: W,
        nonce_base: &[u8; 12],
    ) -> Result<StreamCommitment, Box<dyn std::error::Error>> {
        let mut buffer = vec![0u8; CHUNK_SIZE];
        let mut chunk_index: u64 = 0;
        let mut total_bytes: u64 = 0;

        loop {
            let bytes_read = reader.read(&mut buffer)?;
            if bytes_read == 0 {
                break;
            }

            let mut chunk_nonce = *nonce_base;
            let index_bytes = chunk_index.to_be_bytes();
            for i in 0..8 {
                chunk_nonce[4 + i] ^= index_bytes[i];
            }

            let nonce = Nonce::from_slice(&chunk_nonce);
            let payload = Payload {
                msg: &buffer[..bytes_read],
                aad: b"LONDON_CIPHER_CHUNK_V1",
            };

            let ciphertext = self.cipher.encrypt(nonce, payload)
                .map_err(|e| format!("AEAD encryption failure: {:?}", e))?;

            self.hasher.update(&ciphertext);
            writer.write_all(&ciphertext)?;

            total_bytes += bytes_read as u64;
            chunk_index += 1;
        }

        let merkle_root: [u8; 32] = self.hasher.finalize_reset().into();

        Ok(StreamCommitment {
            chunk_count: chunk_index,
            total_bytes,
            merkle_root,
        })
    }
}
