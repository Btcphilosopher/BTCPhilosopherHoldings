//! LONDON CIPHER — Rust Security Core (cipher-core)
//! High-performance streaming encryption, chunk hashing, and settlement verification.

pub mod streaming;

pub use streaming::{StreamCommitment, StreamEncryptor, CHUNK_SIZE};

/// Validates that an encrypted payload matches its cryptographic commitment.
pub fn verify_payload_integrity(payload: &[u8], expected_sha256_hex: &str) -> bool {
    use sha2::{Digest, Sha256};
    let mut hasher = Sha256::new();
    hasher.update(payload);
    let digest = hasher.finalize();
    let computed_hex = hex::encode(digest);
    computed_hex.eq_ignore_ascii_case(expected_sha256_hex)
}
