// LONDON CIPHER — Lightning Network Infrastructure Engine
// Implements LightningNodeAdapter, InvoiceManager, PaymentVerifier, SettlementObserver

import { LightningChannel, LightningNodeStats, CipherPaymentCondition, CipherSettlementProof } from './types';
import { generateLightningPreimage, verifyPreimage } from './crypto-engine';

export const LONDON_CIPHER_NODE_ID = '03c89b4f74d0e82c1619ad83ef0ba7815cfb38379a1d953fb3042456f9166f0723';
export const LONDON_CIPHER_NODE_ALIAS = 'LON-CIPHER-01.MAYFAIR.UK';

// Mock active high-liquidity enterprise channels
export const INITIAL_LIGHTNING_CHANNELS: LightningChannel[] = [
  {
    channelId: '892401x1420x1',
    remoteNode: '03864ef025fde8fb587d989186ce6a4a186895ee44a926bfc370e2c366597a3f8f',
    remoteAlias: 'ACINQ-PARIS-ENTERPRISE',
    capacitySats: 250_000_000, // 2.5 BTC
    localBalanceSats: 180_450_000,
    remoteBalanceSats: 69_550_000,
    status: 'ACTIVE',
    routingFeePpm: 120,
  },
  {
    channelId: '893112x982x3',
    remoteNode: '026165850492521f4ac8abdde9c73f93e4968b89d4b9fec07c60eedb429abb36a3',
    remoteAlias: 'RIVER-INSTITUTIONAL-LND',
    capacitySats: 500_000_000, // 5.0 BTC
    localBalanceSats: 320_000_000,
    remoteBalanceSats: 180_000_000,
    status: 'ACTIVE',
    routingFeePpm: 85,
  },
  {
    channelId: '894005x201x0',
    remoteNode: '03cde60a6323f7122d517827849d3761582538f4bf86c7740e55c6246f49942035',
    remoteAlias: 'KRAKEN-LIGHTNING-GW01',
    capacitySats: 300_000_000,
    localBalanceSats: 110_500_000,
    remoteBalanceSats: 189_500_000,
    status: 'ACTIVE',
    routingFeePpm: 150,
  },
  {
    channelId: '895442x109x4',
    remoteNode: '02ad39d306a3e529d61a420ce2d6f70b428bdec4651320673e301680787a08b9d0',
    remoteAlias: 'GREENLIGHT-CORE-LONDON',
    capacitySats: 150_000_000,
    localBalanceSats: 142_000_000,
    remoteBalanceSats: 8_000_000,
    status: 'ACTIVE',
    routingFeePpm: 95,
  },
];

export const INITIAL_NODE_STATS: LightningNodeStats = {
  nodeAlias: LONDON_CIPHER_NODE_ALIAS,
  nodeId: LONDON_CIPHER_NODE_ID,
  network: 'MAINNET',
  channelsCount: 8,
  totalCapacityBtc: 14.85,
  inboundLiquiditySats: 647_050_000,
  outboundLiquiditySats: 837_950_000,
  settled24hCount: 1428,
  settled24hVolumeSats: 89_420_000,
  avgLatencyMs: 148,
  uptime: '99.994%',
};

export class LightningNodeAdapter {
  private static activeInvoices = new Map<string, { preimage: string; amountSats: number; condition: CipherPaymentCondition }>();

  /**
   * Generates a payment condition (BOLT-11 style invoice)
   */
  static async createInvoice(
    amountSats: number,
    description: string,
    expirySeconds = 3600
  ): Promise<{ condition: CipherPaymentCondition; preimageHex: string }> {
    const { preimageHex, paymentHashHex } = await generateLightningPreimage();
    const conditionId = `LND-COND-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;

    // Realistic BOLT-11 invoice representation
    const truncatedHash = paymentHashHex.slice(0, 16);
    const paymentRequest = `lnbc${amountSats}0n1p${truncatedHash}qqpp5${paymentHashHex.slice(0, 24)}s0londncipher9q${Math.random().toString(36).slice(2, 10)}`;

    const condition: CipherPaymentCondition = {
      conditionId,
      paymentHash: paymentHashHex,
      paymentRequest,
      amountSats,
      amountFiatMinor: Math.round(amountSats * 0.00065 * 100), // rough sat/gbp rate
      currency: 'GBP/SATS',
      expirySeconds,
      payeeNodeId: LONDON_CIPHER_NODE_ID,
      description,
    };

    this.activeInvoices.set(paymentHashHex, {
      preimage: preimageHex,
      amountSats,
      condition,
    });

    return { condition, preimageHex };
  }

  /**
   * Verifies HTLC settlement with the preimage
   */
  static async verifySettlement(
    paymentHash: string,
    preimage: string
  ): Promise<{ valid: boolean; proof?: CipherSettlementProof; error?: string }> {
    const isValid = await verifyPreimage(preimage, paymentHash);
    if (!isValid) {
      return { valid: false, error: 'Cryptographic preimage verification failed: SHA-256(preimage) does not match payment hash.' };
    }

    const proof: CipherSettlementProof = {
      proofId: `PRF-LN-${Date.now().toString(36).toUpperCase()}`,
      offerId: `OFFER-${paymentHash.slice(0, 8)}`,
      paymentHash,
      preimage,
      settledAt: new Date().toISOString(),
      rail: 'LIGHTNING',
      feePaidSats: Math.floor(Math.random() * 8) + 1,
      transactionRef: `HTLC-SETTLED-${paymentHash.slice(0, 12)}`,
      settlementSignature: `SIG-SECP256K1-${Math.random().toString(36).slice(2, 16).toUpperCase()}`,
    };

    return { valid: true, proof };
  }

  /**
   * Retrieves preimage for a simulated payment (to simulate buyer settlement)
   */
  static getInvoicePreimage(paymentHash: string): string | null {
    const item = this.activeInvoices.get(paymentHash);
    return item ? item.preimage : null;
  }
}
