// LONDON CIPHER — Initial Seed Data for Confidential Deal Room & Vault

import { CipherObject, CipherAuditEvent, CBDCTransaction } from './types';

export const INITIAL_DEAL_ROOM_OBJECTS: CipherObject[] = [
  {
    id: 'CO-PHOENIX-001',
    title: 'Project Phoenix — Acquisition Term Sheet (Binding Offer)',
    filename: '01_Project_Phoenix_Term_Sheet.pdf',
    originalSize: 1_842_110, // ~1.8 MB
    mimeType: 'application/pdf',
    algorithm: 'AES-256-GCM',
    encryptedFileHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    originalMetadataHash: '7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b',
    integrityCommitment: 'MKR-ROOT-88294aef91203d9821ef374c90ab21e',
    keyIdentifier: 'KEY-DEK-MAYFAIR-892',
    wrappedKeyPayload: 'f93c847a98214db28c11e739ad00192847291aeb739201948572019284710293',
    iv: 'a1b2c3d4e5f60718293a4b5c',
    authTag: '5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a',
    createdAt: '2026-09-29T14:32:00Z',
    owner: 'Rothschild & Co / Mayfair Partners LP',
    status: 'LOCKED',
    category: 'FINANCIAL',
    accessPolicy: {
      policyId: 'POL-PHOENIX-TS-01',
      accessModel: 'ONE_TIME_PURCHASE',
      priceGbp: 25.00,
      priceSats: 38500,
      validitySeconds: 86400,
      allowedRails: ['LIGHTNING', 'CBDC_GBP', 'BANK_CHAPS'],
      requireKycLevel: 'INSTITUTIONAL',
      maxDownloads: 5,
      revocationFlag: false,
      m2mCompatible: true,
    },
    plaintextSample: `CONFIDENTIAL // STRICTLY EMBARGOED
PROJECT PHOENIX: ACQUISITION OF AVIONICS DYNAMICS PLC
ISSUED BY: MAYFAIR STRATEGIC HOLDINGS (UK) LLP
DATE: 29 SEPTEMBER 2026

1. TRANSACTION OVERVIEW
Mayfair Strategic Holdings proposes an all-cash institutional acquisition of 100% of the share capital of Avionics Dynamics PLC at an enterprise valuation of £420,000,000.

2. FINANCING COMMITMENT & SETTLEMENT
Settlement shall be executed via Bank of England Real-Time Gross Settlement (RTGS) or London Cipher Institutional CBDC Settlement Rail with instantaneous delivery-versus-payment (DvP).

3. EXCLUSIVITY & GOVERNING LAW
This agreement is subject to 45-day binding exclusivity under English Law and the jurisdiction of the Commercial Court in London.`,
  },
  {
    id: 'CO-PHOENIX-002',
    title: 'Financial Projections & EBITDA Run-Rate (FY26–FY30)',
    filename: '02_Financial_Model_FY26_FY30.xlsx',
    originalSize: 4_281_050, // ~4.2 MB
    mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    algorithm: 'AES-256-GCM',
    encryptedFileHash: 'c4ca4238a0b923820dcc509a6f75849b294e5e4d201948572019284710293847',
    originalMetadataHash: '6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b',
    integrityCommitment: 'MKR-ROOT-492193cb8402aebc91209384910293a',
    keyIdentifier: 'KEY-DEK-CITY-771',
    wrappedKeyPayload: '8839201948572019284710293847291aeb739201948572019284710293f93c84',
    iv: 'b2c3d4e5f60718293a4b5c6d',
    authTag: '7d8e9f0a5d6e7f8a9b0c1d2e3f4a5b6c',
    createdAt: '2026-09-29T15:10:00Z',
    owner: 'PwC London Transaction Services',
    status: 'LOCKED',
    category: 'FINANCIAL',
    accessPolicy: {
      policyId: 'POL-PHOENIX-FM-02',
      accessModel: 'ONE_TIME_PURCHASE',
      priceGbp: 35.00,
      priceSats: 53900,
      validitySeconds: 86400,
      allowedRails: ['LIGHTNING', 'CBDC_GBP'],
      requireKycLevel: 'INSTITUTIONAL',
      maxDownloads: 3,
      revocationFlag: false,
      m2mCompatible: true,
    },
    plaintextSample: `AVIONICS DYNAMICS PLC — AUDITED FINANCIAL CONSOLIDATION
CURRENCY: GBP (£ MILLIONS)

Metric                  FY24A   FY25A   FY26E   FY27E   FY28E   FY29E   FY30E
-----------------------------------------------------------------------------
Gross Revenue            84.2   112.5   148.9   195.4   256.0   330.2   410.5
Cost of Goods Sold      (38.0)  (49.5)  (62.5)  (78.1)  (97.3) (122.1) (147.8)
Gross Margin %          54.9%   56.0%   58.0%   60.0%   62.0%   63.0%   64.0%
Operating Expenses      (22.1)  (28.4)  (35.7)  (43.0)  (51.2)  (62.7)  (73.9)
Adjusted EBITDA          24.1    34.6    50.7    74.3   107.5   145.4   188.8
EBITDA Margin %         28.6%   30.8%   34.0%   38.0%   42.0%   44.0%   46.0%
Net Free Cash Flow       18.4    26.2    39.5    58.9    84.2   115.0   149.2

Verified by: PwC UK Audit Senior Partner Ref #LON-TS-9942`,
  },
  {
    id: 'CO-PHOENIX-003',
    title: 'Legal Due Diligence & IP Ownership Title Opinion',
    filename: '03_Legal_Due_Diligence_Report.docx',
    originalSize: 3_120_800,
    mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    algorithm: 'AES-256-GCM',
    encryptedFileHash: 'd41d8cd98f00b204e9800998ecf8427e92427ae41e4649b934ca495991b7852b',
    originalMetadataHash: '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef',
    integrityCommitment: 'MKR-ROOT-11029384756acbe8920193847291aeb',
    keyIdentifier: 'KEY-DEK-LEGAL-409',
    wrappedKeyPayload: '1948572019284710293847291aeb739201948572019284710293f93c847a9821',
    iv: 'c3d4e5f60718293a4b5c6d7e',
    authTag: '9b0c1d2e3f4a5b6c7d8e9f0a5d6e7f8a',
    createdAt: '2026-09-29T16:00:00Z',
    owner: 'Clifford Chance LLP (London)',
    status: 'LOCKED',
    category: 'LEGAL',
    accessPolicy: {
      policyId: 'POL-PHOENIX-LEG-03',
      accessModel: 'ONE_TIME_PURCHASE',
      priceGbp: 20.00,
      priceSats: 30800,
      validitySeconds: 86400,
      allowedRails: ['LIGHTNING', 'CBDC_GBP'],
      requireKycLevel: 'INSTITUTIONAL',
      maxDownloads: 5,
      revocationFlag: false,
      m2mCompatible: true,
    },
    plaintextSample: `CLIFFORD CHANCE LLP — PRIVILEGED & CONFIDENTIAL
ADDRESSED TO: MAYFAIR STRATEGIC HOLDINGS (UK) LLP
RE: TITLE OPINION ON INTELLECTUAL PROPERTY & PATENTS OF AVIONICS DYNAMICS PLC

1. EXECUTIVE SUMMARY
We have conducted a full legal inquiry into the 14 European Patent Office (EPO) and UK Intellectual Property Office (UKIPO) patents held by the target.
All patents are unencumbered by third-party liens, charges or royalty-bearing licenses.

2. EXPORT CONTROL & NATIONAL SECURITY ACT 2021
The target’s dual-use navigation sensors fall under Schedule 2 of the UK Export Control Order.
Clearance filing has been drafted and is ready for submission to the Investment Security Unit (ISU).`,
  },
  {
    id: 'CO-PHOENIX-004',
    title: 'Proprietary Flight Test & Sensor Avionics Telemetry',
    filename: '04_Proprietary_Avionics_Telemetry.csv',
    originalSize: 8_940_300,
    mimeType: 'text/csv',
    algorithm: 'AES-256-GCM',
    encryptedFileHash: '984572019284710293847291aeb739201948572019284710293f93c847a98214',
    originalMetadataHash: 'ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d',
    integrityCommitment: 'MKR-ROOT-9938201948572019284710293847291',
    keyIdentifier: 'KEY-DEK-AVIONICS-912',
    wrappedKeyPayload: '7291aeb739201948572019284710293f93c847a98214db28c11e739ad001928',
    iv: 'd4e5f60718293a4b5c6d7e8f',
    authTag: '3f4a5b6c7d8e9f0a5d6e7f8a9b0c1d2e',
    createdAt: '2026-09-29T16:45:00Z',
    owner: 'Farnborough Aerospace Research Cluster',
    status: 'LOCKED',
    category: 'TELEMETRY',
    accessPolicy: {
      policyId: 'POL-PHOENIX-TEL-04',
      accessModel: 'PAY_PER_QUERY',
      priceGbp: 20.00,
      priceSats: 30800,
      validitySeconds: 86400,
      allowedRails: ['LIGHTNING', 'CBDC_GBP'],
      requireKycLevel: 'BASIC',
      maxDownloads: 10,
      revocationFlag: false,
      m2mCompatible: true,
    },
    plaintextSample: `timestamp_utc,altitude_ft,mach,pitch_deg,roll_deg,turbine_inlet_temp_c,thrust_kn,vibration_hz
2026-09-25T11:00:01.000Z,32000.4,0.84,1.42,-0.12,892.4,124.5,14.2
2026-09-25T11:00:01.100Z,32001.1,0.84,1.44,-0.11,892.6,124.6,14.3
2026-09-25T11:00:01.200Z,32002.3,0.84,1.41,-0.10,892.8,124.8,14.1
2026-09-25T11:00:01.300Z,32003.5,0.85,1.39,-0.08,893.1,125.1,14.5
2026-09-25T11:00:01.400Z,32004.8,0.85,1.38,-0.06,893.4,125.2,14.4`,
  },
];

export const INITIAL_AUDIT_EVENTS: CipherAuditEvent[] = [
  {
    eventId: 'AUD-001092',
    timestamp: '2026-09-29T14:32:00Z',
    action: 'FILE_ENCRYPTED',
    objectId: 'CO-PHOENIX-001',
    actor: 'client:rothschild-mayfair-01',
    details: 'Client-side AES-256-GCM encryption completed. 1,842,110 bytes authenticated. DEK wrapped with master KWK.',
    previousEventHash: '0000000000000000000000000000000000000000000000000000000000000000',
    eventHash: 'a19284710293847291aeb739201948572019284710293f93c847a98214db28c1',
  },
  {
    eventId: 'AUD-001093',
    timestamp: '2026-09-29T14:32:15Z',
    action: 'ACCESS_POLICY_CREATED',
    objectId: 'CO-PHOENIX-001',
    actor: 'policy-engine:lcp-v1.2',
    details: 'Access policy POL-PHOENIX-TS-01 bound to object. Price: £25.00 / 38,500 sats. Settlement rails: LIGHTNING, CBDC_GBP.',
    previousEventHash: 'a19284710293847291aeb739201948572019284710293f93c847a98214db28c1',
    eventHash: 'b284710293847291aeb739201948572019284710293f93c847a98214db28c11e',
  },
  {
    eventId: 'AUD-001094',
    timestamp: '2026-09-29T15:10:00Z',
    action: 'FILE_ENCRYPTED',
    objectId: 'CO-PHOENIX-002',
    actor: 'client:pwc-london-ts',
    details: 'Audited financial model encrypted locally. Zero-knowledge submission to London Cipher storage.',
    previousEventHash: 'b284710293847291aeb739201948572019284710293f93c847a98214db28c11e',
    eventHash: 'c3948572019284710293f93c847a98214db28c11e739ad00192847291aeb7392',
  },
  {
    eventId: 'AUD-001095',
    timestamp: '2026-09-29T16:45:00Z',
    action: 'ACCESS_POLICY_CREATED',
    objectId: 'CO-PHOENIX-004',
    actor: 'farnborough-cluster-node',
    details: 'High-frequency telemetry stream configured for Machine-to-Machine (M2M) automated settlement.',
    previousEventHash: 'c3948572019284710293f93c847a98214db28c11e739ad00192847291aeb7392',
    eventHash: 'd48572019284710293f93c847a98214db28c11e739ad00192847291aeb739201',
  },
];

export const INITIAL_CBDC_TXS: CBDCTransaction[] = [
  {
    txId: 'CBDC-TX-8921-BOE',
    currency: 'GBP',
    railName: 'Digital GBP Sandbox (Bank of England RTGS-Next)',
    senderAccount: 'GB44-BARC-2000-0192-8402-11',
    recipientAccount: 'GB00-LOND-CIPHER-ESCROW-001',
    amount: 100.00,
    fee: 0.05,
    status: 'SETTLED',
    isoMessageType: 'pacs.008.001.09',
    regulatoryAttestation: 'FCA/BOE-SANDBOX-AUTH-9941a8',
    timestamp: '2026-09-29T17:12:04Z',
    proofSignature: '840192847291aeb739201948572019284710293f93c847a98214db28c11e739a',
  },
  {
    txId: 'CBDC-TX-7712-ECB',
    currency: 'EUR',
    railName: 'Digital Euro Sandbox (ECB TIPS-Direct)',
    senderAccount: 'DE89-DBNK-1000-4820-9128-44',
    recipientAccount: 'GB00-LOND-CIPHER-ESCROW-001',
    amount: 250.00,
    fee: 0.06,
    status: 'SETTLED',
    isoMessageType: 'pacs.008.001.09',
    regulatoryAttestation: 'ECB-TIPS-SETTLE-4820bc',
    timestamp: '2026-09-29T18:04:22Z',
    proofSignature: '9201948572019284710293f93c847a98214db28c11e739ad00192847291aeb73',
  },
];
