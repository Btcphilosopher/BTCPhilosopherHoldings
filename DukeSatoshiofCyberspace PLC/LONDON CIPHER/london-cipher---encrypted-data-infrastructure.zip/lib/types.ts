// LONDON CIPHER — London Cipher Protocol (LCP) Type Definitions

export type EncryptionAlgorithm = 'AES-256-GCM' | 'ChaCha20-Poly1305';

export type PaymentRailType = 'LIGHTNING' | 'CBDC_GBP' | 'CBDC_EUR' | 'CBDC_USD' | 'STABLECOIN_USDC' | 'BANK_CHAPS';

export type AccessModel = 
  | 'ONE_TIME_PURCHASE'
  | 'TIME_LIMITED_24H'
  | 'SUBSCRIPTION_RECURRING'
  | 'PAY_PER_DOWNLOAD'
  | 'PAY_PER_QUERY'
  | 'MACHINE_TO_MACHINE';

export type ObjectStatus = 'ENCRYPTED' | 'LOCKED' | 'PAYMENT_PENDING' | 'SETTLED' | 'ACCESSIBLE' | 'REVOKED' | 'EXPIRED';

// Hash-Committed CipherObject (Section 6)
export interface CipherObject {
  id: string; // e.g., "CO-LON-8942-F2"
  title: string;
  filename: string;
  originalSize: number;
  mimeType: string;
  algorithm: EncryptionAlgorithm;
  encryptedFileHash: string; // SHA-256 of encrypted bytes
  originalMetadataHash: string; // SHA-256 of metadata commitment
  integrityCommitment: string; // Merkle root / HMAC commitment
  keyIdentifier: string; // Key ID reference (DEK reference)
  wrappedKeyPayload: string; // Encrypted DEK under Master Key Wrapping Key (KWK)
  iv: string; // Hex IV / Nonce used in authenticated encryption
  authTag: string; // Authenticated tag (128-bit)
  createdAt: string;
  owner: string;
  status: ObjectStatus;
  accessPolicy: CipherAccessPolicy;
  category: 'FINANCIAL' | 'LEGAL' | 'ENGINEERING' | 'TELEMETRY' | 'RESEARCH';
  // Optional in-memory ciphertext for live browser decryption demo
  encryptedDataB64?: string;
  plaintextSample?: string;
}

// Access Policy
export interface CipherAccessPolicy {
  policyId: string;
  accessModel: AccessModel;
  priceGbp: number;
  priceSats: number;
  validitySeconds: number; // e.g., 86400 for 24h
  allowedRails: PaymentRailType[];
  requireKycLevel: 'NONE' | 'BASIC' | 'INSTITUTIONAL';
  maxDownloads: number;
  revocationFlag: boolean;
  m2mCompatible: boolean;
}

// LCP Protocol Messages (Section 4)
export interface CipherAccessRequest {
  protocolVersion: 'LCP/1.2';
  requestId: string;
  objectId: string;
  requesterIdentity: string;
  requestedCapability: 'DECRYPT_ONCE' | 'LEASE_TEMPORARY' | 'STREAM_PAYLOAD';
  paymentRail: PaymentRailType;
  nonce: string;
  timestamp: string;
  clientPublicKey?: string;
}

export interface CipherAccessOffer {
  protocolVersion: 'LCP/1.2';
  offerId: string;
  requestId: string;
  objectId: string;
  priceGbp: number;
  priceSats: number;
  paymentRail: PaymentRailType;
  paymentCondition: CipherPaymentCondition;
  expiresAt: string;
  signature: string;
}

export interface CipherPaymentCondition {
  conditionId: string;
  paymentHash: string; // SHA-256 hash of preimage (HTLC)
  paymentRequest: string; // BOLT-11 invoice or CBDC authorization URI
  amountSats: number;
  amountFiatMinor: number; // in pence or cents
  currency: string;
  expirySeconds: number;
  payeeNodeId: string;
  description: string;
}

export interface CipherSettlementProof {
  proofId: string;
  offerId: string;
  paymentHash: string;
  preimage: string; // 32-byte hex secret that resolves SHA-256(preimage) == paymentHash
  settledAt: string;
  rail: PaymentRailType;
  feePaidSats?: number;
  transactionRef: string;
  settlementSignature: string;
}

export interface CipherAccessCapability {
  capabilityId: string;
  objectId: string;
  bearerToken: string; // High-entropy authorization bearer
  unwrappedKey: string; // Plaintext DEK in hex (released only after settlement)
  validUntil: string;
  permittedOperations: string[];
  issuedAt: string;
  issuerSignature: string;
}

export interface CipherReleaseEvent {
  eventId: string;
  objectId: string;
  capabilityId: string;
  releasedTo: string;
  settlementProofId: string;
  timestamp: string;
  status: 'SUCCESS' | 'REVOKED' | 'EXPIRED';
}

export interface CipherAuditEvent {
  eventId: string;
  timestamp: string;
  action: 
    | 'FILE_CREATED'
    | 'FILE_ENCRYPTED'
    | 'FILE_UPLOADED'
    | 'ACCESS_POLICY_CREATED'
    | 'PAYMENT_REQUEST_CREATED'
    | 'PAYMENT_RECEIVED'
    | 'PAYMENT_VERIFIED'
    | 'ACCESS_GRANTED'
    | 'KEY_RELEASED'
    | 'FILE_DOWNLOADED'
    | 'ACCESS_REVOKED'
    | 'ACCESS_EXPIRED'
    | 'DECRYPTION_COMPLETED';
  objectId: string;
  actor: string;
  details: string;
  paymentRail?: PaymentRailType;
  txReference?: string;
  previousEventHash: string; // Cryptographic audit chaining
  eventHash: string;
}

export interface LightningChannel {
  channelId: string;
  remoteNode: string;
  remoteAlias: string;
  capacitySats: number;
  localBalanceSats: number;
  remoteBalanceSats: number;
  status: 'ACTIVE' | 'PENDING' | 'OFFLINE';
  routingFeePpm: number;
}

export interface LightningNodeStats {
  nodeAlias: string;
  nodeId: string;
  network: 'MAINNET' | 'TESTNET' | 'SIGNET';
  channelsCount: number;
  totalCapacityBtc: number;
  inboundLiquiditySats: number;
  outboundLiquiditySats: number;
  settled24hCount: number;
  settled24hVolumeSats: number;
  avgLatencyMs: number;
  uptime: string;
}

export interface CBDCTransaction {
  txId: string;
  currency: 'GBP' | 'EUR' | 'USD' | 'JPY' | 'CNY';
  railName: string;
  senderAccount: string;
  recipientAccount: string;
  amount: number;
  fee: number;
  status: 'SETTLED' | 'PENDING' | 'REJECTED';
  isoMessageType: 'pacs.008.001.09' | 'camt.053.001.08';
  regulatoryAttestation: string;
  timestamp: string;
  proofSignature: string;
}

export interface PaymentRouterOption {
  rail: PaymentRailType;
  railLabel: string;
  currency: string;
  displayAmount: string;
  estimatedSettlementTime: string;
  networkFeeGbp: string;
  settlementFinality: 'INSTANT_CRYPTOGRAPHIC' | 'SUB_SECOND_CBDC' | 'T0_RTGS' | 'NEAR_INSTANT';
  recommended: boolean;
  description: string;
}
