'use client';

import React, { useState } from 'react';
import { 
  Lock, 
  Unlock, 
  ShieldCheck, 
  Zap, 
  Building2, 
  Search, 
  Filter, 
  Hash, 
  Clock, 
  Download, 
  Key, 
  FileText, 
  ArrowUpRight,
  ExternalLink,
  CheckCircle2,
  Copy
} from 'lucide-react';
import { CipherObject } from '@/lib/types';

interface CipherObjectsVaultProps {
  objects: CipherObject[];
  onSelectDealRoomObject: (objectId: string) => void;
  onOpenEncryption: () => void;
}

export function CipherObjectsVault({ objects, onSelectDealRoomObject, onOpenEncryption }: CipherObjectsVaultProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [activeObjectId, setActiveObjectId] = useState<string>(objects[0]?.id || '');
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const filteredObjects = objects.filter(obj => {
    const matchesSearch = obj.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          obj.filename.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          obj.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'ALL' || obj.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const activeObject = objects.find(o => o.id === activeObjectId) || objects[0];

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-white">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase bg-sky-950 text-sky-400 border border-sky-600/40">
              CRYPTOGRAPHIC IDENTITY REPOSITORY &bull; SECTION 6 &amp; 23
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            Hash-Committed Cipher Objects
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Cryptographically isolated data objects bound by hash commitments, authenticated encryption, and payment-gated capability releases.
          </p>
        </div>

        <button
          onClick={onOpenEncryption}
          className="px-4 py-2.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors self-start md:self-auto shadow-md"
        >
          <Lock className="w-4 h-4" />
          <span>Encrypt New Object</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-[#0b1220] p-4 rounded-xl border border-slate-800">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by object ID, filename, title..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#050810] border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-sky-500"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto">
          {['ALL', 'FINANCIAL', 'LEGAL', 'ENGINEERING', 'TELEMETRY'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-sky-600 text-white'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Catalog List (5 Cols) vs Deep Inspector (7 Cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Object List */}
        <div className="lg:col-span-5 space-y-3">
          {filteredObjects.map((obj) => {
            const isSelected = obj.id === activeObjectId;
            return (
              <div
                key={obj.id}
                onClick={() => setActiveObjectId(obj.id)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-[#0e172a] border-sky-500 shadow-lg shadow-sky-950/40'
                    : 'bg-[#090f1b] border-slate-800/90 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-sky-400">{obj.id}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                        {obj.category}
                      </span>
                    </div>
                    <div className="text-sm font-semibold text-white truncate max-w-[260px]">
                      {obj.title}
                    </div>
                    <div className="text-xs text-slate-400 font-mono">
                      {obj.filename} &bull; {(obj.originalSize / 1024 / 1024).toFixed(1)} MB
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-bold text-amber-400 font-mono">
                      £{obj.accessPolicy.priceGbp.toFixed(2)}
                    </span>
                    <div className="text-[10px] text-slate-400 font-mono">
                      {obj.accessPolicy.priceSats.toLocaleString()} sats
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>SHA-256: {obj.encryptedFileHash.slice(0, 14)}...</span>
                  <span className="text-emerald-400 font-semibold">{obj.algorithm}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Deep Cryptographic Object Inspector (Section 23) */}
        {activeObject && (
          <div className="lg:col-span-7 bg-[#0b1322] border border-slate-700/80 rounded-2xl p-6 sm:p-7 space-y-6 shadow-2xl">
            {/* Header */}
            <div className="flex items-start justify-between border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-sky-400">{activeObject.id}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-600/40">
                    HASH VERIFIED
                  </span>
                </div>
                <h2 className="text-xl font-bold text-white mt-1">
                  {activeObject.title}
                </h2>
                <div className="text-xs text-slate-400 font-mono mt-0.5">
                  Owner: <span className="text-slate-200">{activeObject.owner}</span> &bull; Created: {new Date(activeObject.createdAt).toLocaleDateString('en-GB')}
                </div>
              </div>

              <button
                onClick={() => onSelectDealRoomObject(activeObject.id)}
                className="px-3 py-1.5 bg-amber-950/80 hover:bg-amber-900 border border-amber-500/40 text-amber-300 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
              >
                <span>Settle in Deal Room</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Institutional Status Matrix (Section 23 layout) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
              <div className="p-3 bg-[#060a14] rounded-lg border border-slate-800 space-y-0.5">
                <div className="text-[10px] text-slate-500">OBJECT STATUS</div>
                <div className="text-amber-400 font-bold">ENCRYPTED</div>
              </div>

              <div className="p-3 bg-[#060a14] rounded-lg border border-slate-800 space-y-0.5">
                <div className="text-[10px] text-slate-500">ENCRYPTION ALGO</div>
                <div className="text-sky-400 font-bold">{activeObject.algorithm}</div>
              </div>

              <div className="p-3 bg-[#060a14] rounded-lg border border-slate-800 space-y-0.5">
                <div className="text-[10px] text-slate-500">INTEGRITY</div>
                <div className="text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  VERIFIED
                </div>
              </div>

              <div className="p-3 bg-[#060a14] rounded-lg border border-slate-800 space-y-0.5">
                <div className="text-[10px] text-slate-500">ACCESS LEASE</div>
                <div className="text-slate-200 font-bold">24 HOURS</div>
              </div>
            </div>

            {/* Cryptographic Hash Commitments */}
            <div className="space-y-3 font-mono text-xs">
              <div className="p-3 bg-[#050811] rounded-lg border border-slate-800 space-y-1">
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span className="text-slate-300 font-semibold">ENCRYPTED-FILE SHA-256 HASH:</span>
                  <button
                    onClick={() => copyToClipboard(activeObject.encryptedFileHash, 'filehash')}
                    className="text-sky-400 hover:text-sky-300 flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedField === 'filehash' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <div className="text-slate-300 break-all text-[11px]">
                  {activeObject.encryptedFileHash}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 bg-[#050811] rounded-lg border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 block">METADATA COMMITMENT:</span>
                  <div className="text-slate-300 break-all text-[11px]">
                    {activeObject.originalMetadataHash}
                  </div>
                </div>

                <div className="p-3 bg-[#050811] rounded-lg border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 block">KEY IDENTIFIER (DEK):</span>
                  <div className="text-amber-300 text-[11px] font-semibold">
                    {activeObject.keyIdentifier}
                  </div>
                </div>
              </div>

              {/* Wrapped DEK Payload */}
              <div className="p-3 bg-[#050811] rounded-lg border border-slate-800 space-y-1">
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span className="text-amber-400 font-semibold">LAYER B WRAPPED DEK PAYLOAD:</span>
                  <button
                    onClick={() => copyToClipboard(activeObject.wrappedKeyPayload, 'wrapped')}
                    className="text-sky-400 hover:text-sky-300 flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedField === 'wrapped' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <div className="text-slate-400 break-all text-[11px]">
                  {activeObject.wrappedKeyPayload}
                </div>
              </div>
            </div>

            {/* Policy & Permitted Settlement Rails */}
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
              <div className="text-xs font-semibold text-white uppercase tracking-wider">
                Cryptographic Access Policy: {activeObject.accessPolicy.policyId}
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                <div>
                  <span className="text-slate-400 block text-[11px]">PRICE (GBP / SATS):</span>
                  <span className="text-amber-400 font-bold text-sm">
                    £{activeObject.accessPolicy.priceGbp.toFixed(2)} ({activeObject.accessPolicy.priceSats.toLocaleString()} sats)
                  </span>
                </div>

                <div>
                  <span className="text-slate-400 block text-[11px]">AUTHORIZED RAILS:</span>
                  <span className="text-slate-200">
                    {activeObject.accessPolicy.allowedRails.join(', ')}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
