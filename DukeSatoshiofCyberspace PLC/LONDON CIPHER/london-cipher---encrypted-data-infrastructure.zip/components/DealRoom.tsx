'use client';

import React, { useState } from 'react';
import { 
  Landmark, 
  Lock, 
  Unlock, 
  Zap, 
  Building2, 
  CheckCircle2, 
  Clock, 
  FileText, 
  ShieldCheck, 
  Download, 
  Copy, 
  ArrowRight, 
  ExternalLink,
  RefreshCw,
  Hash,
  Eye,
  AlertCircle
} from 'lucide-react';
import { CipherObject, PaymentRailType, CipherAuditEvent } from '@/lib/types';
import { LightningNodeAdapter } from '@/lib/lightning-engine';
import { CBDCRailAdapter } from '@/lib/cbdc-engine';
import { decryptBytesAESGCM, str2buf, buf2str } from '@/lib/crypto-engine';

interface DealRoomProps {
  objects: CipherObject[];
  onAddAuditEvent: (event: CipherAuditEvent) => void;
  onObjectUnlocked?: (objectId: string) => void;
}

export function DealRoom({ objects, onAddAuditEvent, onObjectUnlocked }: DealRoomProps) {
  const [selectedObjectId, setSelectedObjectId] = useState<string>('CO-PHOENIX-001');
  const [paymentRail, setPaymentRail] = useState<PaymentRailType>('LIGHTNING');
  
  // Payment & Settlement State
  const [isGeneratingInvoice, setIsGeneratingInvoice] = useState(false);
  const [activeInvoice, setActiveInvoice] = useState<{
    paymentRequest: string;
    paymentHash: string;
    preimage: string;
    amountSats: number;
    amountGbp: number;
  } | null>(null);

  const [settlementStatus, setSettlementStatus] = useState<'IDLE' | 'INVOICE_READY' | 'SETTLING' | 'VERIFIED' | 'FAILED'>('IDLE');
  const [settlementProof, setSettlementProof] = useState<any>(null);
  const [unlockedKeys, setUnlockedKeys] = useState<Record<string, string>>({}); // objectId -> unwrapped DEK
  const [decryptedContents, setDecryptedContents] = useState<Record<string, string>>({});
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [packageMode, setPackageMode] = useState<boolean>(false);

  const selectedObject = objects.find(o => o.id === selectedObjectId) || objects[0];
  const isUnlocked = Boolean(unlockedKeys[selectedObjectId] || packageMode && Object.keys(unlockedKeys).length > 0);

  // Generate Payment Challenge
  const handleCreatePaymentChallenge = async () => {
    setIsGeneratingInvoice(true);
    setSettlementStatus('IDLE');
    setSettlementProof(null);

    const priceGbp = packageMode ? 100.00 : selectedObject.accessPolicy.priceGbp;
    const priceSats = packageMode ? 154000 : selectedObject.accessPolicy.priceSats;

    try {
      if (paymentRail === 'LIGHTNING') {
        const { condition, preimageHex } = await LightningNodeAdapter.createInvoice(
          priceSats,
          `LONDON CIPHER: ${packageMode ? 'Full M&A Deal Room Package' : selectedObject.title}`
        );

        setActiveInvoice({
          paymentRequest: condition.paymentRequest,
          paymentHash: condition.paymentHash,
          preimage: preimageHex,
          amountSats: condition.amountSats,
          amountGbp: priceGbp,
        });

        // Audit Event: Payment Request Created
        onAddAuditEvent({
          eventId: `AUD-${Date.now().toString(36).toUpperCase()}`,
          timestamp: new Date().toISOString(),
          action: 'PAYMENT_REQUEST_CREATED',
          objectId: packageMode ? 'BUNDLE-PROJECT-PHOENIX' : selectedObject.id,
          actor: 'buyer:mayfair-acquisitions-lp',
          details: `BOLT-11 invoice generated for ${condition.amountSats.toLocaleString()} sats. Payment hash: ${condition.paymentHash.slice(0, 16)}...`,
          paymentRail: 'LIGHTNING',
          previousEventHash: 'b284710293847291aeb739201948572019284710293f93c847a98214db28c11e',
          eventHash: condition.paymentHash,
        });

      } else {
        // CBDC Digital GBP
        const condition = await CBDCRailAdapter.createPaymentCondition(
          Math.round(priceGbp * 100),
          'GBP',
          'CBDC_GBP',
          `LONDON CIPHER CBDC: ${packageMode ? 'Full M&A Deal Room Package' : selectedObject.title}`
        );

        setActiveInvoice({
          paymentRequest: condition.paymentRequest,
          paymentHash: condition.paymentHash,
          preimage: `PREIMAGE-BOE-AUTH-${Math.random().toString(36).slice(2, 18)}`,
          amountSats: 0,
          amountGbp: priceGbp,
        });

        onAddAuditEvent({
          eventId: `AUD-${Date.now().toString(36).toUpperCase()}`,
          timestamp: new Date().toISOString(),
          action: 'PAYMENT_REQUEST_CREATED',
          objectId: packageMode ? 'BUNDLE-PROJECT-PHOENIX' : selectedObject.id,
          actor: 'buyer:mayfair-acquisitions-lp',
          details: `Digital GBP ISO 20022 pacs.008 payment challenge created. Amount: £${priceGbp.toFixed(2)}`,
          paymentRail: 'CBDC_GBP',
          previousEventHash: 'b284710293847291aeb739201948572019284710293f93c847a98214db28c11e',
          eventHash: condition.paymentHash,
        });
      }

      setSettlementStatus('INVOICE_READY');
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingInvoice(false);
    }
  };

  // Simulate Settlement Execution
  const handleExecuteSettlement = async () => {
    if (!activeInvoice) return;
    setSettlementStatus('SETTLING');

    // Simulate realistic network routing & preimage resolution latency (~400ms)
    setTimeout(async () => {
      try {
        let proofData: any = null;

        if (paymentRail === 'LIGHTNING') {
          const verification = await LightningNodeAdapter.verifySettlement(
            activeInvoice.paymentHash,
            activeInvoice.preimage
          );

          if (!verification.valid || !verification.proof) {
            setSettlementStatus('FAILED');
            return;
          }
          proofData = verification.proof;
        } else {
          // CBDC Settlement
          const cbdcResult = await CBDCRailAdapter.settle(
            {
              conditionId: `COND-${activeInvoice.paymentHash.slice(0, 8)}`,
              paymentHash: activeInvoice.paymentHash,
              paymentRequest: activeInvoice.paymentRequest,
              amountSats: 0,
              amountFiatMinor: Math.round(activeInvoice.amountGbp * 100),
              currency: 'GBP',
              expirySeconds: 1800,
              payeeNodeId: 'BOE-SANDBOX-NODE',
              description: 'M&A Settlement',
            },
            'CBDC_GBP'
          );
          proofData = cbdcResult.proof;
        }

        setSettlementProof(proofData);
        setSettlementStatus('VERIFIED');

        // Audit Event: Payment Verified
        onAddAuditEvent({
          eventId: `AUD-${Date.now().toString(36).toUpperCase()}`,
          timestamp: new Date().toISOString(),
          action: 'PAYMENT_VERIFIED',
          objectId: packageMode ? 'BUNDLE-PROJECT-PHOENIX' : selectedObject.id,
          actor: 'settlement-observer:london-node',
          details: `Settlement cryptographically proven on ${paymentRail}. Preimage validated: ${proofData.preimage.slice(0, 16)}...`,
          paymentRail,
          txReference: proofData.transactionRef,
          previousEventHash: activeInvoice.paymentHash,
          eventHash: proofData.settlementSignature,
        });

        // Layer B Execution: Release unwrapped DEK capability
        const simulatedReleasedDEK = '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef';

        if (packageMode) {
          const keys: Record<string, string> = {};
          const decContents: Record<string, string> = {};
          for (const obj of objects) {
            keys[obj.id] = simulatedReleasedDEK;
            decContents[obj.id] = obj.plaintextSample || 'CONFIDENTIAL ASSET CONTENT DECRYPTED LOCALLY';
            if (onObjectUnlocked) onObjectUnlocked(obj.id);
          }
          setUnlockedKeys(keys);
          setDecryptedContents(decContents);
        } else {
          setUnlockedKeys(prev => ({ ...prev, [selectedObject.id]: simulatedReleasedDEK }));
          setDecryptedContents(prev => ({
            ...prev,
            [selectedObject.id]: selectedObject.plaintextSample || 'CONFIDENTIAL ASSET CONTENT DECRYPTED LOCALLY',
          }));
          if (onObjectUnlocked) onObjectUnlocked(selectedObject.id);
        }

        // Audit Event: Key Released & Local Decryption Complete
        onAddAuditEvent({
          eventId: `AUD-${(Date.now() + 10).toString(36).toUpperCase()}`,
          timestamp: new Date().toISOString(),
          action: 'KEY_RELEASED',
          objectId: packageMode ? 'BUNDLE-PROJECT-PHOENIX' : selectedObject.id,
          actor: 'kms:hsm-lnd-01',
          details: `DEK capability released to buyer. Local AES-256-GCM authenticated decryption authorized.`,
          previousEventHash: proofData.settlementSignature,
          eventHash: `KEY-REL-${Date.now().toString(36)}`,
        });

      } catch (err) {
        console.error(err);
        setSettlementStatus('FAILED');
      }
    }, 450);
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleDownloadDecrypted = (obj: CipherObject) => {
    const text = decryptedContents[obj.id] || obj.plaintextSample || 'CONFIDENTIAL';
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `DECRYPTED_${obj.filename.replace(/\.enc$/, '')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-white">
      {/* Deal Room Header */}
      <div className="bg-[#0b1324] border border-slate-700/80 rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono tracking-wider uppercase bg-amber-950/80 text-amber-300 border border-amber-600/40">
                FLAGSHIP DEMONSTRATION &bull; SECTION 29
              </span>
              <span className="text-xs text-slate-400 font-mono">CONFIDENTIAL M&amp;A DEAL ROOM</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Project Phoenix — Acquisition Deal Room
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              High-stakes Mayfair &amp; City of London aerospace acquisition (£420M transaction).
              Every file is encrypted locally under AES-256-GCM. Decryption keys are held in escrow and conditionally released 
              only upon verifiable Lightning or Digital GBP settlement.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-700 text-xs font-mono space-y-1">
              <div className="text-slate-400">ESCROW STATUS:</div>
              <div className="text-amber-400 font-bold flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5" />
                <span>CRYPTOGRAPHICALLY GATED</span>
              </div>
            </div>
            <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-700 text-xs font-mono space-y-1">
              <div className="text-slate-400">SETTLEMENT RAILS:</div>
              <div className="text-sky-300 font-bold">LIGHTNING &bull; DIGITAL GBP</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Deal Room Layout: Document Browser vs Settlement Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Acquisition Document Package (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-sky-400" />
              <span>Encrypted Data Objects in Deal Room</span>
            </h2>

            {/* Toggle full package vs single file */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400">Scope:</span>
              <button
                onClick={() => setPackageMode(false)}
                className={`px-2.5 py-1 rounded text-xs font-medium ${!packageMode ? 'bg-sky-600 text-white' : 'bg-slate-800 text-slate-400'}`}
              >
                Single Item
              </button>
              <button
                onClick={() => setPackageMode(true)}
                className={`px-2.5 py-1 rounded text-xs font-medium flex items-center gap-1 ${packageMode ? 'bg-amber-600 text-white font-semibold' : 'bg-slate-800 text-slate-400'}`}
              >
                <span>Full Deal Room (£100)</span>
              </button>
            </div>
          </div>

          {/* Document Cards */}
          <div className="space-y-3">
            {objects.map((obj) => {
              const unlocked = Boolean(unlockedKeys[obj.id] || (packageMode && Object.keys(unlockedKeys).length > 0));
              const isSelected = selectedObjectId === obj.id && !packageMode;

              return (
                <div
                  key={obj.id}
                  onClick={() => {
                    if (!packageMode) setSelectedObjectId(obj.id);
                  }}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-900 border-sky-500 shadow-md shadow-sky-950/40'
                      : unlocked
                      ? 'bg-[#09151e] border-emerald-600/40 hover:border-emerald-500/60'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className={`p-2.5 rounded-lg border shrink-0 ${
                        unlocked 
                          ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-400' 
                          : 'bg-slate-800 border-slate-700 text-slate-300'
                      }`}>
                        {unlocked ? <Unlock className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold text-white">{obj.title}</span>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                            {obj.category}
                          </span>
                        </div>

                        <div className="text-xs text-slate-400 font-mono">
                          {obj.filename} &bull; {(obj.originalSize / 1024 / 1024).toFixed(1)} MB &bull; {obj.algorithm}
                        </div>

                        <div className="text-[11px] text-slate-500 font-mono truncate max-w-md">
                          SHA-256: <span className="text-slate-400">{obj.encryptedFileHash.slice(0, 24)}...</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      {unlocked ? (
                        <div className="space-y-1">
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-950/80 border border-emerald-600/40 px-2 py-0.5 rounded">
                            <CheckCircle2 className="w-3 h-3" /> Decrypted
                          </span>
                          <div className="text-[10px] text-slate-400 font-mono">Capability Released</div>
                        </div>
                      ) : (
                        <div className="space-y-1">
                          <div className="text-sm font-bold text-amber-400 font-mono">
                            £{obj.accessPolicy.priceGbp.toFixed(2)}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono">
                            {obj.accessPolicy.priceSats.toLocaleString()} sats
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* If Decrypted, show quick preview & download button */}
                  {unlocked && (
                    <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                      <span className="text-emerald-300/80 font-mono text-[11px] flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                        Plaintext authenticated via WebCrypto AES-GCM tag
                      </span>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDownloadDecrypted(obj);
                        }}
                        className="px-2.5 py-1 bg-emerald-900/60 hover:bg-emerald-800/80 text-emerald-200 border border-emerald-500/40 rounded text-[11px] font-medium flex items-center gap-1 transition-colors"
                      >
                        <Download className="w-3 h-3" />
                        Download Plaintext
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Decrypted Document Preview Area */}
          {isUnlocked && (
            <div className="p-5 rounded-2xl bg-[#09141f] border border-emerald-500/40 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Unlock className="w-4 h-4 text-emerald-400" />
                  <span className="text-sm font-bold text-white">
                    Decrypted Plaintext: {packageMode ? 'All Package Documents' : selectedObject.title}
                  </span>
                </div>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-600/40">
                  CONFIDENTIALITY PRESERVED IN TRANSIT
                </span>
              </div>

              <div className="bg-[#050b13] p-4 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 leading-relaxed max-h-72 overflow-y-auto whitespace-pre-wrap">
                {decryptedContents[selectedObjectId] || selectedObject.plaintextSample}
              </div>

              <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
                <span>LOCAL DECRYPTION KEY: <span className="text-amber-300">{unlockedKeys[selectedObjectId]?.slice(0, 16) || '0123456789abcdef'}...</span></span>
                <button
                  onClick={() => handleDownloadDecrypted(selectedObject)}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-sans font-medium flex items-center gap-1.5 transition-colors shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  Save Plaintext File
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Settlement & Key Release Engine (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#0a1120] border border-slate-700/80 rounded-2xl p-6 shadow-xl space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <div className="text-xs font-mono text-amber-400 uppercase tracking-wider">
                LAYER B — SETTLEMENT-GATED ACCESS
              </div>
              <h3 className="text-lg font-bold text-white mt-1">
                Cryptographic Access Condition
              </h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Money operates as a cryptographic access condition. The server releases the wrapped DEK only when 
                a valid settlement proof is verified.
              </p>
            </div>

            {/* Target Item & Price Summary */}
            <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2 font-mono text-xs">
              <div className="flex justify-between text-slate-400">
                <span>TARGET PAYLOAD:</span>
                <span className="text-white font-semibold truncate max-w-[200px]">
                  {packageMode ? 'Full M&A Package (4 Files)' : selectedObject.filename}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>AUTHORIZATION PRICE:</span>
                <span className="text-amber-400 font-bold text-sm">
                  {packageMode ? '£100.00 (154,000 sats)' : `£${selectedObject.accessPolicy.priceGbp.toFixed(2)} (${selectedObject.accessPolicy.priceSats.toLocaleString()} sats)`}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>ACCESS LEASE:</span>
                <span className="text-slate-300">24 Hours (Atomic Capability)</span>
              </div>
            </div>

            {/* Payment Rail Selection */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
                Select Settlement Rail
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setPaymentRail('LIGHTNING');
                    setSettlementStatus('IDLE');
                    setActiveInvoice(null);
                  }}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    paymentRail === 'LIGHTNING'
                      ? 'bg-amber-950/40 border-amber-500 text-white shadow-md'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs">
                    <Zap className="w-4 h-4" />
                    <span>Lightning</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">Instant HTLC (~150ms)</div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setPaymentRail('CBDC_GBP');
                    setSettlementStatus('IDLE');
                    setActiveInvoice(null);
                  }}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    paymentRail === 'CBDC_GBP'
                      ? 'bg-sky-950/40 border-sky-500 text-white shadow-md'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-sky-400 font-bold text-xs">
                    <Building2 className="w-4 h-4" />
                    <span>Digital GBP</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">BoE Sandbox (ISO 20022)</div>
                </button>
              </div>
            </div>

            {/* Step 1: Generate Invoice Button if IDLE */}
            {settlementStatus === 'IDLE' && !isUnlocked && (
              <button
                onClick={handleCreatePaymentChallenge}
                disabled={isGeneratingInvoice}
                className="w-full py-3 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold rounded-xl transition-all shadow-lg shadow-sky-950 flex items-center justify-center gap-2"
              >
                {isGeneratingInvoice ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Generating Cryptographic Payment Challenge...</span>
                  </>
                ) : (
                  <>
                    <span>Generate {paymentRail === 'LIGHTNING' ? 'Lightning BOLT-11 Invoice' : 'Digital GBP Payment Request'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            )}

            {/* Step 2: Invoice Ready & Payment Action */}
            {activeInvoice && settlementStatus !== 'VERIFIED' && (
              <div className="space-y-4 p-4 rounded-xl bg-slate-900/90 border border-slate-800">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-amber-400 font-semibold flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" />
                    AWAITING SETTLEMENT
                  </span>
                  <span className="text-slate-400">LCP Protocol v1.2</span>
                </div>

                {/* Simulated QR Code / Hash Box */}
                <div className="p-3 bg-[#050811] rounded-lg border border-slate-800 space-y-2">
                  <div className="text-[10px] text-slate-400 font-mono uppercase flex justify-between">
                    <span>Payment Request ({paymentRail}):</span>
                    <button
                      onClick={() => copyToClipboard(activeInvoice.paymentRequest, 'inv')}
                      className="text-sky-400 hover:text-sky-300 flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" />
                      <span>{copiedText === 'inv' ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                  <div className="font-mono text-[11px] text-slate-300 break-all bg-slate-950 p-2 rounded border border-slate-900">
                    {activeInvoice.paymentRequest}
                  </div>
                </div>

                <div className="text-xs font-mono space-y-1 text-slate-400">
                  <div className="flex justify-between">
                    <span>PAYMENT HASH (H):</span>
                    <span className="text-slate-300">{activeInvoice.paymentHash.slice(0, 16)}...</span>
                  </div>
                  <div className="flex justify-between">
                    <span>PREIMAGE SECRET (R):</span>
                    <span className="text-emerald-400">Locked in escrow (revealed on settle)</span>
                  </div>
                </div>

                {/* Simulated Payment Trigger */}
                <button
                  onClick={handleExecuteSettlement}
                  disabled={settlementStatus === 'SETTLING'}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-md shadow-emerald-950 flex items-center justify-center gap-2"
                >
                  {settlementStatus === 'SETTLING' ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Verifying HTLC Cryptographic Settlement...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 text-amber-300 fill-amber-300" />
                      <span>Simulate Buyer Settlement ({paymentRail === 'LIGHTNING' ? `${activeInvoice.amountSats.toLocaleString()} Sats` : `£${activeInvoice.amountGbp.toFixed(2)}`})</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* Step 3: Verified Settlement Proof Card */}
            {settlementProof && (
              <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/50 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold font-mono">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>SETTLEMENT VERIFIED &bull; CAPABILITY UNLOCKED</span>
                </div>

                <div className="space-y-1.5 text-[11px] font-mono text-slate-300 bg-[#050b13] p-3 rounded-lg border border-emerald-900/40">
                  <div className="flex justify-between">
                    <span className="text-slate-400">PROOF ID:</span>
                    <span className="text-white">{settlementProof.proofId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">PREIMAGE (R):</span>
                    <span className="text-emerald-300 font-bold truncate max-w-[200px]">{settlementProof.preimage}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">SETTLEMENT TIME:</span>
                    <span className="text-slate-300">148 ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">TX REF:</span>
                    <span className="text-slate-300">{settlementProof.transactionRef}</span>
                  </div>
                </div>

                <div className="text-[11px] text-emerald-300/90 leading-tight">
                  Cryptographic condition satisfied. Key-wrapping layer has released the plaintext DEK for client-side authenticated decryption.
                </div>
              </div>
            )}

            {/* Already Unlocked state */}
            {isUnlocked && settlementStatus !== 'INVOICE_READY' && (
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs space-y-3">
                <div className="text-slate-300 flex items-center gap-1.5 font-semibold">
                  <Unlock className="w-4 h-4 text-emerald-400" />
                  <span>Active Cryptographic Session</span>
                </div>
                <p className="text-slate-400 text-[11px]">
                  Decryption keys are active in browser memory. Plaintext never traversed unencrypted over the network.
                </p>
                <button
                  onClick={() => {
                    setUnlockedKeys({});
                    setDecryptedContents({});
                    setActiveInvoice(null);
                    setSettlementStatus('IDLE');
                  }}
                  className="text-[11px] text-amber-400 hover:text-amber-300 underline font-mono"
                >
                  Reset Deal Room Session (Lock All)
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
