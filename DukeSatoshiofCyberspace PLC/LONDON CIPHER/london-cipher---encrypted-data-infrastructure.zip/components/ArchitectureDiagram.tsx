'use client';

import React from 'react';
import { 
  Lock, 
  Unlock, 
  Zap, 
  Building2, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight, 
  Layers, 
  Key, 
  Server,
  AlertCircle
} from 'lucide-react';

export function ArchitectureDiagram() {
  return (
    <div className="bg-[#0b1324] border border-slate-700/80 rounded-2xl p-6 sm:p-8 space-y-8 shadow-2xl text-white">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase bg-amber-950 text-amber-300 border border-amber-600/40">
            SYSTEM ARCHITECTURE &bull; SECTION 2, 3 &amp; 32
          </span>
          <span className="text-xs text-slate-400 font-mono">INDEPENDENT SECURITY DOMAINS</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Double-Layer Security Model
        </h2>
        <p className="text-slate-300 text-sm max-w-3xl leading-relaxed">
          The Lightning Network and CBDC rails do not encrypt files. 
          Instead, London Cipher composes two strictly independent cryptographic layers:
          conventional modern authenticated encryption (Layer 1) and settlement-conditioned capability release (Layer 2).
        </p>
      </div>

      {/* Visual Flow diagram: Original File -> Local Encrypt -> Encrypted File -> Wrapped Key -> Policy -> Settlement -> Release -> Decrypt */}
      <div className="p-6 rounded-xl bg-[#060a14] border border-slate-800 space-y-6">
        <div className="text-xs font-mono font-bold text-sky-400 uppercase tracking-widest">
          END-TO-END CRYPTOGRAPHIC &amp; SETTLEMENT LIFECYCLE
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-2 text-center text-xs font-mono">
          <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 space-y-1">
            <span className="text-slate-400 text-[10px]">STEP 1</span>
            <div className="text-white font-bold">ORIGINAL FILE</div>
            <div className="text-[10px] text-slate-500 font-sans">Client machine</div>
          </div>

          <div className="p-3 bg-sky-950/60 rounded-lg border border-sky-600/40 space-y-1">
            <span className="text-sky-400 text-[10px]">STEP 2</span>
            <div className="text-sky-300 font-bold">LOCAL AES-GCM</div>
            <div className="text-[10px] text-slate-400 font-sans">Random DEK</div>
          </div>

          <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 space-y-1">
            <span className="text-slate-400 text-[10px]">STEP 3</span>
            <div className="text-white font-bold">CIPHER OBJECT</div>
            <div className="text-[10px] text-slate-500 font-sans">SHA-256 Hash</div>
          </div>

          <div className="p-3 bg-purple-950/60 rounded-lg border border-purple-600/40 space-y-1">
            <span className="text-purple-400 text-[10px]">STEP 4</span>
            <div className="text-purple-300 font-bold">KEY WRAPPING</div>
            <div className="text-[10px] text-slate-400 font-sans">Master KWK</div>
          </div>

          <div className="p-3 bg-amber-950/60 rounded-lg border border-amber-600/40 space-y-1">
            <span className="text-amber-400 text-[10px]">STEP 5</span>
            <div className="text-amber-300 font-bold">PAYMENT COND</div>
            <div className="text-[10px] text-slate-400 font-sans">BOLT-11 / CBDC</div>
          </div>

          <div className="p-3 bg-emerald-950/60 rounded-lg border border-emerald-600/40 space-y-1">
            <span className="text-emerald-400 text-[10px]">STEP 6</span>
            <div className="text-emerald-300 font-bold">SETTLEMENT</div>
            <div className="text-[10px] text-slate-400 font-sans">Preimage Match</div>
          </div>

          <div className="p-3 bg-sky-950/60 rounded-lg border border-sky-600/40 space-y-1">
            <span className="text-sky-400 text-[10px]">STEP 7</span>
            <div className="text-sky-300 font-bold">KEY RELEASE</div>
            <div className="text-[10px] text-slate-400 font-sans">Capability unwrapped</div>
          </div>

          <div className="p-3 bg-emerald-950/80 rounded-lg border border-emerald-500 space-y-1">
            <span className="text-emerald-400 text-[10px]">STEP 8</span>
            <div className="text-white font-bold">DECRYPTED</div>
            <div className="text-[10px] text-emerald-300 font-sans">Local Plaintext</div>
          </div>
        </div>
      </div>

      {/* Explicit Distinction of the 5 Independent Security Layers (Section 32) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Layer 1: Data Encryption */}
        <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
          <div className="flex items-center gap-2.5 text-sky-400 font-bold text-sm">
            <Lock className="w-5 h-5" />
            <span>LAYER 1 — DATA ENCRYPTION (AES-256-GCM)</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            The file payload itself is encrypted on the client using modern authenticated encryption (AES-256-GCM / ChaCha20-Poly1305). 
            Generates a high-entropy 256-bit random Data Encryption Key (DEK) and 96-bit nonce. 
            No plaintext ever leaves the client without authenticated encryption.
          </p>
        </div>

        {/* Layer 2: Settlement-Gated Access */}
        <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
          <div className="flex items-center gap-2.5 text-amber-400 font-bold text-sm">
            <Zap className="w-5 h-5" />
            <span>LAYER 2 — SETTLEMENT-GATED ACCESS (LCP)</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            The DEK is wrapped in escrow under a Master Key Wrapping Key (KWK). 
            Access policies enforce that the server or HSM will only derive, unwrap, and release the decryption capability 
            upon cryptographic proof of Lightning HTLC settlement or programmable CBDC authorization.
          </p>
        </div>
      </div>

      {/* Critical Security Tenet */}
      <div className="p-4 rounded-xl bg-[#070d18] border border-slate-800 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="text-xs text-slate-300 leading-relaxed font-mono">
          <strong className="text-white">SECURITY NON-REDUCTION PRINCIPLE:</strong> The two layers are mathematically decoupled.
          A breach of the Lightning node or invoice database reveals zero plaintext data.
          Similarly, possessing stolen ciphertext yields zero access to payment channels, routing funds, or node private keys.
        </div>
      </div>
    </div>
  );
}
