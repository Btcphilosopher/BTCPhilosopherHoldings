'use client';

import React, { useState } from 'react';
import { 
  Key, 
  ShieldCheck, 
  Lock, 
  Unlock, 
  RefreshCw, 
  AlertTriangle, 
  CheckCircle2, 
  Layers, 
  Server, 
  Cpu, 
  Clock 
} from 'lucide-react';

export function KeyManagementView() {
  const [hsmStatus, setHsmStatus] = useState<'HEALTHY' | 'ROTATING'>('HEALTHY');
  const [keyVersion, setKeyVersion] = useState<number>(3);
  const [lastRotated, setLastRotated] = useState<string>('2026-09-28 04:00 UTC');
  const [rotationLog, setRotationLog] = useState<string[]>([]);

  const handleRotateKWK = () => {
    setHsmStatus('ROTATING');
    setTimeout(() => {
      setKeyVersion(prev => prev + 1);
      setLastRotated(new Date().toISOString().replace('T', ' ').slice(0, 16) + ' UTC');
      setRotationLog(prev => [
        `Master KWK rotated to v${keyVersion + 1} inside HSM Slot #1. Zero-knowledge attestation re-signed.`,
        ...prev,
      ]);
      setHsmStatus('HEALTHY');
    }, 700);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-white">
      {/* Header */}
      <div className="bg-[#0b1324] border border-slate-700/80 rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase bg-purple-950 text-purple-300 border border-purple-600/40">
                CRYPTOGRAPHIC HIERARCHY &bull; SECTION 10
              </span>
              <span className="text-xs text-slate-400 font-mono">FIPS 140-3 LEVEL 3 HSM ABSTRACTION</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <Key className="w-7 h-7 text-purple-400" />
              <span>Key Management &amp; HSM Architecture</span>
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Strict cryptographic separation between Data Encryption Keys (DEK), Key Wrapping Keys (KWK), 
              payment authorization states, and user identity. Keys are never derived from payment identifiers or invoices.
            </p>
          </div>

          <button
            onClick={handleRotateKWK}
            disabled={hsmStatus === 'ROTATING'}
            className="px-4 py-2.5 bg-purple-700 hover:bg-purple-600 active:bg-purple-800 text-white rounded-xl text-xs font-semibold flex items-center gap-2 transition-all shadow-md self-start md:self-auto"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${hsmStatus === 'ROTATING' ? 'animate-spin' : ''}`} />
            <span>Rotate Master Key (KWK)</span>
          </button>
        </div>
      </div>

      {/* 5-Domain Separation Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 font-mono text-xs">
        <div className="p-4 rounded-xl bg-[#090f1b] border border-slate-800 space-y-2">
          <div className="text-slate-500 text-[10px]">DOMAIN 1</div>
          <div className="text-sm font-bold text-sky-400">DATA ENCRYPTION KEY</div>
          <p className="text-slate-400 text-[11px] font-sans leading-relaxed">
            Ephemeral 256-bit AES key per file. Generated in browser RAM; never stored in plaintext.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-[#090f1b] border border-slate-800 space-y-2">
          <div className="text-slate-500 text-[10px]">DOMAIN 2</div>
          <div className="text-sm font-bold text-purple-400">KEY WRAPPING KEY</div>
          <p className="text-slate-400 text-[11px] font-sans leading-relaxed">
            Master wrapping key residing in HSM slot. Encrypts and wraps DEKs using HKDF-SHA256 masks.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-[#090f1b] border border-slate-800 space-y-2">
          <div className="text-slate-500 text-[10px]">DOMAIN 3</div>
          <div className="text-sm font-bold text-amber-400">ACCESS CAPABILITY</div>
          <p className="text-slate-400 text-[11px] font-sans leading-relaxed">
            Cryptographic capability token granted upon settlement verification. Valid for specific lease window.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-[#090f1b] border border-slate-800 space-y-2">
          <div className="text-slate-500 text-[10px]">DOMAIN 4</div>
          <div className="text-sm font-bold text-emerald-400">PAYMENT PROOF</div>
          <p className="text-slate-400 text-[11px] font-sans leading-relaxed">
            HTLC preimage or CBDC authorization receipt. Operates strictly around the data, never as encryption key.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-[#090f1b] border border-slate-800 space-y-2">
          <div className="text-slate-500 text-[10px]">DOMAIN 5</div>
          <div className="text-sm font-bold text-indigo-400">IDENTITY &amp; AUDIT</div>
          <p className="text-slate-400 text-[11px] font-sans leading-relaxed">
            Actor public key and immutable hash-chained event logs without storing secret payloads.
          </p>
        </div>
      </div>

      {/* Visual Hierarchy Diagram & Hardware Security Module Status */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: HSM Slot Monitor */}
        <div className="lg:col-span-6 bg-[#0a101d] border border-slate-800 rounded-2xl p-6 space-y-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Server className="w-4 h-4 text-purple-400" />
              <span>HSM Cluster: LONDON-MAYFAIR-HSM01</span>
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
              {hsmStatus}
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between p-2.5 bg-[#050811] rounded border border-slate-800/80">
              <span className="text-slate-400">ACTIVE KWK VERSION:</span>
              <span className="text-white font-bold">v{keyVersion}.0</span>
            </div>

            <div className="flex justify-between p-2.5 bg-[#050811] rounded border border-slate-800/80">
              <span className="text-slate-400">LAST ROTATION:</span>
              <span className="text-slate-200">{lastRotated}</span>
            </div>

            <div className="flex justify-between p-2.5 bg-[#050811] rounded border border-slate-800/80">
              <span className="text-slate-400">ATTESTATION METHOD:</span>
              <span className="text-sky-400">Zero-Knowledge SGX / Nitro Enclave</span>
            </div>

            <div className="flex justify-between p-2.5 bg-[#050811] rounded border border-slate-800/80">
              <span className="text-slate-400">KEY REPLAY PROTECTION:</span>
              <span className="text-emerald-400">Cryptographic Nonce Cache (Active)</span>
            </div>
          </div>

          {rotationLog.length > 0 && (
            <div className="pt-2 border-t border-slate-800 space-y-1 text-[11px] font-mono text-slate-400">
              <span className="text-purple-400 font-bold">RECENT HSM LOG:</span>
              {rotationLog.map((log, i) => (
                <div key={i} className="text-slate-300">{log}</div>
              ))}
            </div>
          )}
        </div>

        {/* Right: Security Guarantee Checklist */}
        <div className="lg:col-span-6 bg-[#0a101d] border border-slate-800 rounded-2xl p-6 space-y-4 shadow-xl">
          <h2 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Cryptographic Guarantees (Section 10 &amp; 32)</span>
          </h2>

          <div className="space-y-3 text-xs text-slate-300">
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white">No Key Derivation from Payments:</strong> Encryption keys are never derived from invoice IDs, payment hashes, or Lightning metadata.
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white">Zero Plaintext in Logs:</strong> Decryption material is kept strictly in isolated memory buffers and purged immediately after unwrap.
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white">Layer Independence:</strong> Compromising the payment rail reveals no plaintext data; stealing ciphertext reveals no Lightning credentials.
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white">Strict Time-Locks &amp; Revocation:</strong> Access capabilities expire automatically after policy duration or upon explicit revocation broadcast.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
