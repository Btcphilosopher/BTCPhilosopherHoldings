'use client';

import React, { useState } from 'react';
import { 
  Zap, 
  Activity, 
  Layers, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowUpRight, 
  ArrowDownLeft, 
  RefreshCw, 
  Cpu, 
  Copy,
  Server,
  Radio,
  Sliders
} from 'lucide-react';
import { 
  INITIAL_LIGHTNING_CHANNELS, 
  INITIAL_NODE_STATS, 
  LONDON_CIPHER_NODE_ID, 
  LONDON_CIPHER_NODE_ALIAS,
  LightningNodeAdapter 
} from '@/lib/lightning-engine';
import { LightningChannel } from '@/lib/types';

export function LightningControlRoom() {
  const [channels, setChannels] = useState<LightningChannel[]>(INITIAL_LIGHTNING_CHANNELS);
  const [stats, setStats] = useState(INITIAL_NODE_STATS);
  const [copied, setCopied] = useState<string | null>(null);

  // Test invoice generator
  const [testAmountSats, setTestAmountSats] = useState<number>(25000);
  const [testMemo, setTestMemo] = useState<string>('LCP: Mayfair Research File Access');
  const [generatedInvoice, setGeneratedInvoice] = useState<{
    paymentRequest: string;
    paymentHash: string;
    preimage: string;
  } | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const handleGenerateInvoice = async () => {
    setIsGenerating(true);
    try {
      const { condition, preimageHex } = await LightningNodeAdapter.createInvoice(testAmountSats, testMemo);
      setGeneratedInvoice({
        paymentRequest: condition.paymentRequest,
        paymentHash: condition.paymentHash,
        preimage: preimageHex,
      });
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-white">
      {/* Node Header Banner */}
      <div className="bg-[#0b1324] border border-slate-700/80 rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase bg-amber-950 text-amber-300 border border-amber-600/40 flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-ping" />
                INSTITUTIONAL NODE MONITOR &bull; SECTION 24
              </span>
              <span className="text-xs text-slate-400 font-mono">LND / CLN PEER ENGINE</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <Zap className="w-7 h-7 text-amber-400" />
              <span>Lightning Settlement Control Room</span>
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Real-time telemetry for London Cipher&apos;s institutional payment node. 
              Atomic HTLC settlement enforces sub-second key release without custodial third-party trust.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 font-mono text-xs space-y-1.5">
            <div className="flex justify-between text-slate-400">
              <span>NODE ALIAS:</span>
              <span className="text-white font-bold">{stats.nodeAlias}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>NETWORK:</span>
              <span className="text-emerald-400 font-bold">{stats.network} (HIGH-LIQUIDITY)</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>UPTIME:</span>
              <span className="text-sky-400">{stats.uptime}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
        <div className="p-4 rounded-xl bg-[#090f1b] border border-slate-800 space-y-1">
          <div className="text-slate-400 text-[11px]">TOTAL CAPACITY</div>
          <div className="text-xl font-bold text-white">{stats.totalCapacityBtc} BTC</div>
          <div className="text-[10px] text-slate-500">Across {stats.channelsCount} enterprise channels</div>
        </div>

        <div className="p-4 rounded-xl bg-[#090f1b] border border-slate-800 space-y-1">
          <div className="text-slate-400 text-[11px]">AVG HTLC LATENCY</div>
          <div className="text-xl font-bold text-emerald-400">{stats.avgLatencyMs} ms</div>
          <div className="text-[10px] text-slate-500">Instant cryptographic finality</div>
        </div>

        <div className="p-4 rounded-xl bg-[#090f1b] border border-slate-800 space-y-1">
          <div className="text-slate-400 text-[11px]">24H SETTLED VOLUME</div>
          <div className="text-xl font-bold text-amber-400">{(stats.settled24hVolumeSats / 100_000_000).toFixed(2)} BTC</div>
          <div className="text-[10px] text-slate-500">{stats.settled24hCount.toLocaleString()} settlements verified</div>
        </div>

        <div className="p-4 rounded-xl bg-[#090f1b] border border-slate-800 space-y-1">
          <div className="text-slate-400 text-[11px]">INBOUND LIQUIDITY</div>
          <div className="text-xl font-bold text-sky-400">{(stats.inboundLiquiditySats / 100_000_000).toFixed(2)} BTC</div>
          <div className="text-[10px] text-slate-500">Dual-funded routing balance</div>
        </div>
      </div>

      {/* Channels & Invoice Generator Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Channels & Liquidity (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Radio className="w-4 h-4 text-amber-400" />
              <span>Enterprise Peer Channels</span>
            </h2>
            <span className="text-xs text-slate-400 font-mono">Routing Peers</span>
          </div>

          <div className="space-y-3">
            {channels.map((chan) => {
              const localPct = Math.round((chan.localBalanceSats / chan.capacitySats) * 100);
              const remotePct = 100 - localPct;

              return (
                <div key={chan.channelId} className="p-4 rounded-xl bg-[#090f1c] border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <div className="space-y-0.5">
                      <div className="text-white font-bold text-sm">{chan.remoteAlias}</div>
                      <div className="text-slate-500 text-[11px]">Channel: {chan.channelId}</div>
                    </div>

                    <div className="text-right">
                      <span className="text-emerald-400 text-[11px] font-semibold bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                        {chan.status}
                      </span>
                      <div className="text-slate-400 text-[10px] mt-0.5 font-mono">
                        {(chan.capacitySats / 100_000_000).toFixed(2)} BTC
                      </div>
                    </div>
                  </div>

                  {/* Liquidity Bar */}
                  <div className="space-y-1 font-mono text-[11px]">
                    <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden flex">
                      <div style={{ width: `${localPct}%` }} className="bg-sky-500 h-full" />
                      <div style={{ width: `${remotePct}%` }} className="bg-amber-500 h-full" />
                    </div>

                    <div className="flex justify-between text-slate-400 text-[10px]">
                      <span className="text-sky-300">Local (Outbound): {(chan.localBalanceSats / 100_000_000).toFixed(2)} BTC ({localPct}%)</span>
                      <span className="text-amber-300">Remote (Inbound): {(chan.remoteBalanceSats / 100_000_000).toFixed(2)} BTC ({remotePct}%)</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Invoice Simulator & Decoder (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#0a1120] border border-slate-700/80 rounded-2xl p-6 space-y-5 shadow-xl">
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Sliders className="w-4 h-4 text-amber-400" />
                <span>BOLT-11 Invoice Engine</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Generates a cryptographically bound invoice with preimage hash challenge for machine access.
              </p>
            </div>

            <div className="space-y-3 font-mono text-xs">
              <div>
                <label className="text-slate-400 block mb-1">AMOUNT (SATOSHIS):</label>
                <input
                  type="number"
                  value={testAmountSats}
                  onChange={(e) => setTestAmountSats(Number(e.target.value))}
                  className="w-full bg-[#050810] border border-slate-700 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">MEMO / ACCESS DESCRIPTION:</label>
                <input
                  type="text"
                  value={testMemo}
                  onChange={(e) => setTestMemo(e.target.value)}
                  className="w-full bg-[#050810] border border-slate-700 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-amber-500"
                />
              </div>

              <button
                onClick={handleGenerateInvoice}
                disabled={isGenerating}
                className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg font-sans font-semibold text-xs transition-colors flex items-center justify-center gap-2 shadow-md"
              >
                {isGenerating ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
                <span>Generate BOLT-11 Payment Challenge</span>
              </button>
            </div>

            {generatedInvoice && (
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3 font-mono text-xs">
                <div className="flex justify-between items-center text-slate-400 text-[10px]">
                  <span>BOLT-11 INVOICE:</span>
                  <button
                    onClick={() => copyToClipboard(generatedInvoice.paymentRequest, 'inv')}
                    className="text-sky-400 hover:text-sky-300 flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copied === 'inv' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <div className="text-slate-300 break-all text-[11px] bg-slate-950 p-2.5 rounded border border-slate-900">
                  {generatedInvoice.paymentRequest}
                </div>

                <div className="space-y-1 text-[11px] text-slate-400 border-t border-slate-800 pt-2">
                  <div className="flex justify-between">
                    <span>PAYMENT HASH (H):</span>
                    <span className="text-white">{generatedInvoice.paymentHash.slice(0, 14)}...</span>
                  </div>
                  <div className="flex justify-between">
                    <span>PREIMAGE SECRET (R):</span>
                    <span className="text-emerald-400">{generatedInvoice.preimage.slice(0, 14)}...</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
