'use client';

import React from 'react';
import { 
  ShieldCheck, 
  Zap, 
  Building2, 
  Lock, 
  ArrowRight, 
  Play, 
  CheckCircle2, 
  Globe, 
  Landmark, 
  HardDrive,
  Cpu,
  Layers
} from 'lucide-react';

interface HeroBannerProps {
  onOpenDealRoom: () => void;
  onOpenEncryption: () => void;
  setActiveTab: (tab: string) => void;
}

export function HeroBanner({ onOpenDealRoom, onOpenEncryption, setActiveTab }: HeroBannerProps) {
  return (
    <div className="relative overflow-hidden bg-[#070b12] text-white">
      {/* Background Graphic: Atmospheric London Twilight Panorama & Cryptographic Geodesic Mesh */}
      <div className="relative min-h-[580px] lg:min-h-[640px] flex items-center border-b border-slate-800/80">
        {/* Deep gradient background & London skyline silhouette SVG */}
        <div className="absolute inset-0 pointer-events-none select-none overflow-hidden">
          {/* Sky Gradient */}
          <div className="absolute inset-0 bg-gradient-to-b from-[#060913] via-[#091122] to-[#04070e]" />

          {/* Golden dusk ambient glow behind Westminster */}
          <div className="absolute right-[5%] bottom-[120px] w-[500px] h-[300px] bg-amber-500/10 rounded-full blur-[100px] pointer-events-none" />
          <div className="absolute right-[20%] top-[40px] w-[450px] h-[350px] bg-sky-500/10 rounded-full blur-[120px] pointer-events-none" />

          {/* SVG Illustration of London Skyline with Geodesic Cryptographic Dome */}
          <svg 
            className="absolute bottom-0 right-0 w-full lg:w-[65%] h-[380px] lg:h-[460px] opacity-80" 
            viewBox="0 0 1000 500" 
            preserveAspectRatio="xMaxYMax slice"
          >
            <defs>
              <linearGradient id="skylineGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1e293b" stopOpacity="0.8" />
                <stop offset="60%" stopColor="#0f172a" stopOpacity="0.95" />
                <stop offset="100%" stopColor="#030712" stopOpacity="1" />
              </linearGradient>

              <linearGradient id="domeGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#2563eb" stopOpacity="0.1" />
              </linearGradient>

              <radialGradient id="meshCenter" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#0284c7" stopOpacity="0" />
              </radialGradient>
            </defs>

            {/* Cryptographic Geodesic Network Sphere over London */}
            <g transform="translate(680, 220)">
              {/* Radial glow */}
              <circle cx="0" cy="0" r="140" fill="url(#meshCenter)" />
              {/* Latitude and Longitude Cryptographic Arcs */}
              <circle cx="0" cy="0" r="130" fill="none" stroke="#38bdf8" strokeWidth="1" strokeDasharray="4 4" opacity="0.4" />
              <circle cx="0" cy="0" r="100" fill="none" stroke="#38bdf8" strokeWidth="0.8" opacity="0.3" />
              <ellipse cx="0" cy="0" rx="130" ry="40" fill="none" stroke="#38bdf8" strokeWidth="1" strokeDasharray="6 3" opacity="0.5" />
              <ellipse cx="0" cy="0" rx="130" ry="80" fill="none" stroke="#38bdf8" strokeWidth="1" opacity="0.3" />
              <ellipse cx="0" cy="0" rx="40" ry="130" fill="none" stroke="#38bdf8" strokeWidth="0.8" opacity="0.3" />

              {/* Glowing Mesh Nodes */}
              <circle cx="-90" cy="-60" r="3.5" fill="#38bdf8" className="animate-pulse" />
              <circle cx="80" cy="-70" r="3" fill="#38bdf8" />
              <circle cx="-100" cy="40" r="3" fill="#38bdf8" />
              <circle cx="70" cy="50" r="3.5" fill="#38bdf8" className="animate-pulse" />
              <circle cx="0" cy="-110" r="4" fill="#67e8f9" />
              <circle cx="0" cy="110" r="3" fill="#38bdf8" />

              {/* Interconnecting Laser Lines */}
              <line x1="-90" y1="-60" x2="0" y2="-110" stroke="#38bdf8" strokeWidth="0.8" opacity="0.6" />
              <line x1="80" y1="-70" x2="0" y2="-110" stroke="#38bdf8" strokeWidth="0.8" opacity="0.6" />
              <line x1="-90" y1="-60" x2="-100" y2="40" stroke="#38bdf8" strokeWidth="0.8" opacity="0.5" />
              <line x1="80" y1="-70" x2="70" y2="50" stroke="#38bdf8" strokeWidth="0.8" opacity="0.5" />
              <line x1="-100" y1="40" x2="0" y2="110" stroke="#38bdf8" strokeWidth="0.8" opacity="0.5" />
              <line x1="70" y1="50" x2="0" y2="110" stroke="#38bdf8" strokeWidth="0.8" opacity="0.5" />

              {/* Center Padlock Hologram */}
              <g transform="translate(-18, -24) scale(1.5)">
                <rect x="4" y="10" width="16" height="12" rx="2" fill="#0369a1" stroke="#38bdf8" strokeWidth="1.5" />
                <path d="M7 10 V6 C7 3.5 9 1.5 12 1.5 C15 1.5 17 3.5 17 6 V10" fill="none" stroke="#bae6fd" strokeWidth="1.8" />
                <circle cx="12" cy="15" r="1.5" fill="#ffffff" />
                <line x1="12" y1="16.5" x2="12" y2="19" stroke="#ffffff" strokeWidth="1" />
              </g>
            </g>

            {/* London City Silhouette (Elizabeth Tower / Big Ben, Westminster Palace, The Shard, Gherkin) */}
            <g fill="url(#skylineGrad)">
              {/* Distant City Skyscrapers */}
              <polygon points="120,400 120,330 145,330 145,400" />
              <polygon points="150,400 150,300 185,270 210,300 210,400" />
              <polygon points="220,400 220,340 240,340 240,400" />
              <polygon points="250,400 250,290 280,260 300,400" />
              <polygon points="310,400 310,310 340,310 340,400" />
              
              {/* The Shard (Canary Wharf / London Bridge silhouette) */}
              <polygon points="400,400 440,190 445,190 480,400" opacity="0.8" />
              
              {/* Westminster Palace Body */}
              <rect x="520" y="320" width="280" height="80" rx="1" />
              <polygon points="530,320 540,280 550,320" />
              <polygon points="570,320 580,290 590,320" />
              <polygon points="610,320 620,285 630,320" />
              <polygon points="660,320 670,290 680,320" />
              <polygon points="720,320 730,285 740,320" />

              {/* Elizabeth Tower (Big Ben) */}
              <rect x="780" y="160" width="46" height="240" />
              {/* Clock Tower Roof / Spire */}
              <polygon points="776,160 803,80 830,160" />
              <line x1="803" y1="80" x2="803" y2="50" stroke="#fbbf24" strokeWidth="2" />
              <polygon points="786,160 786,130 820,130 820,160" fill="#334155" />
            </g>

            {/* Illuminated Clock Faces (Amber Warm Glow) */}
            <circle cx="803" cy="180" r="14" fill="#fef08a" stroke="#d97706" strokeWidth="2" />
            <circle cx="803" cy="180" r="11" fill="#fef3c7" opacity="0.9" />
            <line x1="803" y1="180" x2="803" y2="173" stroke="#451a03" strokeWidth="1.5" />
            <line x1="803" y1="180" x2="808" y2="182" stroke="#451a03" strokeWidth="1.2" />

            {/* Architectural Windows Glow on Palace of Westminster */}
            <g fill="#fde68a" opacity="0.6">
              <rect x="540" y="340" width="6" height="12" />
              <rect x="560" y="340" width="6" height="12" />
              <rect x="580" y="340" width="6" height="12" />
              <rect x="620" y="340" width="6" height="12" />
              <rect x="640" y="340" width="6" height="12" />
              <rect x="700" y="340" width="6" height="12" />
              <rect x="730" y="340" width="6" height="12" />
              <rect x="750" y="340" width="6" height="12" />
              <rect x="796" y="220" width="14" height="20" />
              <rect x="796" y="260" width="14" height="24" />
            </g>

            {/* Westminster Bridge Arches spanning the River Thames */}
            <path d="M0 400 L1000 400 L1000 430 L0 430 Z" fill="#0f172a" />
            <ellipse cx="200" cy="430" rx="70" ry="25" fill="#020617" />
            <ellipse cx="360" cy="430" rx="70" ry="25" fill="#020617" />
            <ellipse cx="520" cy="430" rx="70" ry="25" fill="#020617" />
            <ellipse cx="680" cy="430" rx="70" ry="25" fill="#020617" />
            <ellipse cx="840" cy="430" rx="70" ry="25" fill="#020617" />

            {/* Golden Bridge Lantern Lights */}
            <circle cx="130" cy="400" r="3" fill="#fef08a" />
            <circle cx="270" cy="400" r="3" fill="#fef08a" />
            <circle cx="440" cy="400" r="3" fill="#fef08a" />
            <circle cx="600" cy="400" r="3" fill="#fef08a" />
            <circle cx="760" cy="400" r="3" fill="#fef08a" />
            <circle cx="920" cy="400" r="3" fill="#fef08a" />

            {/* River Thames Water Reflection with Golden & Cyan Shimmers */}
            <rect x="0" y="430" width="1000" height="70" fill="#050914" />
            <path d="M 100 445 Q 160 447 220 445" stroke="#fde047" strokeWidth="1.5" opacity="0.3" />
            <path d="M 400 455 Q 460 458 520 455" stroke="#fde047" strokeWidth="2" opacity="0.4" />
            <path d="M 740 450 Q 800 453 860 450" stroke="#fde047" strokeWidth="2.5" opacity="0.5" />
            <path d="M 640 470 Q 720 473 800 470" stroke="#38bdf8" strokeWidth="1.5" opacity="0.4" />
          </svg>
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Headlines & Call to Actions */}
            <div className="lg:col-span-8 space-y-6">
              {/* Eyebrow matching the screenshot */}
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-sky-950/40 border border-sky-500/30 rounded text-[11px] font-mono tracking-[0.22em] uppercase text-sky-300">
                <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-ping" />
                SECURE FILES &bull; CONTROLLED TRANSFERS &bull; GLOBAL SETTLEMENTS
              </div>

              {/* Title */}
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.1] font-sans">
                London’s Next Generation <br />
                <span className="text-sky-400 drop-shadow-[0_0_25px_rgba(56,189,248,0.4)]">
                  Data &amp; Payment
                </span>{' '}
                Infrastructure
              </h1>

              {/* Subtitle / positioning */}
              <p className="max-w-2xl text-base sm:text-lg text-slate-300 font-normal leading-relaxed">
                London Cipher delivers cryptographically secure file encryption and controlled data transfer, 
                with Lightning Network settlement and future CBDC payment rails — built for a more secure, 
                connected financial world and the autonomous machine economy.
              </p>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-wrap items-center gap-4">
                <button
                  onClick={() => setActiveTab('deal-room')}
                  className="px-6 py-3.5 bg-sky-500 hover:bg-sky-400 active:bg-sky-600 text-white font-semibold rounded-lg shadow-lg shadow-sky-950/60 hover:shadow-sky-500/30 transition-all flex items-center gap-2.5 text-sm"
                >
                  <span>Launch Platform</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={onOpenDealRoom}
                  className="px-5 py-3.5 bg-amber-950/40 hover:bg-amber-900/60 border border-amber-500/40 text-amber-300 font-medium rounded-lg transition-all flex items-center gap-2 text-sm"
                >
                  <Landmark className="w-4 h-4 text-amber-400" />
                  <span>Confidential Deal Room Demo</span>
                </button>

                <button
                  onClick={onOpenEncryption}
                  className="px-4 py-3.5 bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/80 font-medium rounded-lg transition-all flex items-center gap-2 text-sm"
                >
                  <Lock className="w-4 h-4 text-slate-400" />
                  <span>Encrypt a Local File</span>
                </button>
              </div>

              {/* Core Principle highlight */}
              <div className="pt-4 border-t border-slate-800/80 flex items-center gap-3 text-xs text-slate-400 font-mono">
                <span className="text-sky-400 font-semibold">CORE INNOVATION:</span>
                <span>DATA &rarr; ENCRYPTION &rarr; CRYPTOGRAPHIC ACCESS CONTROL &rarr; PAYMENT &rarr; SECURE RELEASE</span>
              </div>
            </div>

            {/* Right Column: Ticker badges seen on right of screenshot */}
            <div className="lg:col-span-4 flex flex-col justify-center items-start lg:items-end space-y-4">
              <div className="bg-[#0b1324]/80 backdrop-blur-md border border-slate-700/70 p-4 rounded-xl shadow-xl max-w-xs space-y-3 font-mono text-xs">
                <div className="text-[10px] uppercase tracking-widest text-slate-400 border-b border-slate-800 pb-1.5 flex items-center justify-between">
                  <span>SYSTEM METRICS</span>
                  <span className="text-emerald-400">ONLINE</span>
                </div>
                <div className="space-y-1 text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">DATA CIPHER:</span>
                    <span className="text-white font-semibold">AES-256-GCM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">KEY DERIVATION:</span>
                    <span className="text-white font-semibold">HKDF-SHA256</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">SETTLEMENT RAIL:</span>
                    <span className="text-amber-400 font-semibold">LIGHTNING LND</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">CBDC ADAPTER:</span>
                    <span className="text-sky-400 font-semibold">DIGITAL GBP (BoE)</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2 text-right hidden lg:block">
                <div className="text-[11px] font-mono tracking-wider text-slate-400 uppercase">
                  ENCRYPTION &bull; LIGHTNING &bull; CBDC RAILS
                </div>
                <div className="text-[11px] font-mono tracking-wider text-slate-500 uppercase">
                  SECURE TRANSFERS &bull; INSTANT SETTLEMENT
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Trust Credentials Bar (From Screenshot) */}
      <div className="bg-[#040810] border-b border-slate-800/80 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-medium text-slate-300">
          <div className="flex items-center gap-2.5">
            <Building2 className="w-4 h-4 text-sky-400 shrink-0" />
            <div>
              <div className="text-white font-semibold">Based in London, UK</div>
              <div className="text-[11px] text-slate-400">Mayfair &bull; City of London &bull; E14</div>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <div className="text-white font-semibold">Enterprise Grade Security</div>
              <div className="text-[11px] text-slate-400">Layer A Crypto &times; Layer B Access</div>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <Layers className="w-4 h-4 text-amber-400 shrink-0" />
            <div>
              <div className="text-white font-semibold">Open Standards &amp; Interop</div>
              <div className="text-[11px] text-slate-400">LCP Protocol / BOLT-11 / ISO 20022</div>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <Globe className="w-4 h-4 text-indigo-400 shrink-0" />
            <div>
              <div className="text-white font-semibold">Global Settlement Rails</div>
              <div className="text-[11px] text-slate-400">Sub-second atomic key release</div>
            </div>
          </div>
        </div>
      </div>

      {/* "OUR PLATFORM — Security Meets Financial Innovation" (Matches bottom half of screenshot) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left: 4 Core Pillars */}
          <div className="lg:col-span-7 space-y-8">
            <div className="space-y-2">
              <span className="text-xs font-mono tracking-widest uppercase text-sky-400 font-semibold">
                OUR PLATFORM
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                Security Meets Financial Innovation
              </h2>
              <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
                London Cipher combines industry-leading authenticated encryption with cutting-edge payment rails, 
                giving institutions and autonomous agents complete cryptographic control over data and value.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Pillar 1 */}
              <div className="flex items-start gap-4 p-4 rounded-xl bg-slate-900/40 border border-slate-800 hover:border-sky-500/40 transition-colors">
                <div className="p-2.5 rounded-lg bg-sky-950/80 border border-sky-500/30 text-sky-400 shrink-0">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">End-to-End Encryption</h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Data is encrypted client-side using authenticated AES-256-GCM. Independent DEK generation ensures zero-knowledge privacy.
                  </p>
                </div>
              </div>

              {/* Pillar 2 */}
              <div className="flex items-start gap-4 p-4 rounded-xl bg-slate-900/40 border border-slate-800 hover:border-amber-500/40 transition-colors">
                <div className="p-2.5 rounded-lg bg-amber-950/80 border border-amber-500/30 text-amber-400 shrink-0">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Lightning Network Settlement</h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Fast, low-cost, global micro-settlements for datasets, streaming telemetry, and single-file access via HTLC preimage verification.
                  </p>
                </div>
              </div>

              {/* Pillar 3 */}
              <div className="flex items-start gap-4 p-4 rounded-xl bg-slate-900/40 border border-slate-800 hover:border-indigo-500/40 transition-colors">
                <div className="p-2.5 rounded-lg bg-indigo-950/80 border border-indigo-500/30 text-indigo-400 shrink-0">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">CBDC Payment Rails</h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Future-ready synthetic sandbox for Central Bank Digital Currencies (Digital GBP, Digital EUR) with ISO 20022 compliance.
                  </p>
                </div>
              </div>

              {/* Pillar 4 */}
              <div className="flex items-start gap-4 p-4 rounded-xl bg-slate-900/40 border border-slate-800 hover:border-emerald-500/40 transition-colors">
                <div className="p-2.5 rounded-lg bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Controlled Data Transfer</h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Granular access policies, time-based expiration, atomic key unwrapping, and immutable cryptographic audit trails.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: The Interactive Terminal / Card Preview (Matching Screenshot Mockup) */}
          <div className="lg:col-span-5">
            <div className="bg-[#0b1222] border border-slate-700/80 rounded-2xl p-5 shadow-2xl relative overflow-hidden">
              {/* Window Header */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4 text-xs font-mono text-slate-400">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500/70" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/70" />
                  <span className="ml-2 font-bold text-white tracking-widest">LONDON CIPHER CONSOLE</span>
                </div>
                <div className="text-[10px] bg-slate-800 text-sky-300 px-2 py-0.5 rounded font-mono">
                  NODE: ACTIVE
                </div>
              </div>

              {/* Main Card Content */}
              <div className="space-y-4">
                {/* File Header */}
                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded bg-sky-950 text-sky-400 border border-sky-800">
                      <HardDrive className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-white">Project_Phoenix.zip</div>
                      <div className="text-xs text-slate-400 font-mono">Encrypted &bull; 2.4 GB &bull; AES-256-GCM</div>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-700/50 px-2.5 py-1 rounded-full flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Verified
                  </span>
                </div>

                {/* Transfer Complete Banner */}
                <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/30 flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div>
                    <div className="text-sm font-bold text-white">Transfer Complete</div>
                    <div className="text-xs text-emerald-300/80 font-mono">Settled via Lightning Network &bull; 148 ms</div>
                  </div>
                </div>

                {/* Settlement Amount Row */}
                <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
                    <Zap className="w-4 h-4 text-amber-400" />
                    <span className="font-bold text-white">0.0042 BTC</span>
                    <span className="text-slate-500">=</span>
                    <span className="text-slate-300">£320.14</span>
                  </div>
                  <span className="text-xs font-medium text-amber-400 bg-amber-950/60 border border-amber-600/30 px-2.5 py-1 rounded">
                    Lightning Settled
                  </span>
                </div>

                {/* Interactive Action */}
                <div className="pt-2">
                  <button
                    onClick={() => setActiveTab('deal-room')}
                    className="w-full py-2.5 px-4 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-2 shadow-md shadow-sky-950"
                  >
                    <span>Inspect Transaction in Confidential Deal Room</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
