'use client';

import React, { useState } from 'react';
import { 
  Building2, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  FileText, 
  ArrowRight, 
  AlertCircle, 
  RefreshCw,
  Landmark,
  Coins
} from 'lucide-react';
import { CBDC_RAILS, CBDCRailAdapter } from '@/lib/cbdc-engine';
import { INITIAL_CBDC_TXS } from '@/lib/initial-data';
import { CBDCTransaction } from '@/lib/types';

export function CBDCControlRoom() {
  const [selectedRailKey, setSelectedRailKey] = useState<'CBDC_GBP' | 'CBDC_EUR' | 'CBDC_USD'>('CBDC_GBP');
  const [transactions, setTransactions] = useState<CBDCTransaction[]>(INITIAL_CBDC_TXS);
  
  // Interactive test settlement
  const [testAmountGbp, setTestAmountGbp] = useState<number>(50.00);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [activeIsoMessage, setActiveIsoMessage] = useState<string | null>(null);

  const activeRail = CBDC_RAILS[selectedRailKey];

  const handleTestSettle = async () => {
    setIsProcessing(true);
    try {
      const condition = await CBDCRailAdapter.createPaymentCondition(
        Math.round(testAmountGbp * 100),
        activeRail.currency,
        selectedRailKey,
        'Institutional Data Access Lease'
      );

      const result = await CBDCRailAdapter.settle(condition, selectedRailKey);
      
      setTransactions(prev => [result.transaction, ...prev]);

      // Sample ISO 20022 pacs.008 message XML payload
      const isoXml = `<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.09">
  <FIToFICstmrCdtTrf>
    <GrpHdr>
      <MsgId>${result.transaction.txId}</MsgId>
      <CreDtTm>${result.transaction.timestamp}</CreDtTm>
      <NbOfTxs>1</NbOfTxs>
      <SttlmInf>
        <SttlmMtd>CLRG</SttlmMtd>
        <ClrSys>
          <Prtry>${activeRail.centralBankAuthority}</Prtry>
        </ClrSys>
      </SttlmInf>
    </GrpHdr>
    <CdtTrfTxInf>
      <PmtId>
        <EndToEndId>LCP-DATA-LEASE-${Date.now().toString(36)}</EndToEndId>
        <TxId>${result.transaction.txId}</TxId>
      </PmtId>
      <IntrBkSttlmAmt Ccy="${activeRail.currency}">${testAmountGbp.toFixed(2)}</IntrBkSttlmAmt>
      <DbtrAcct><Id><IBAN>${result.transaction.senderAccount}</IBAN></Id></DbtrAcct>
      <CdtrAcct><Id><IBAN>${result.transaction.recipientAccount}</IBAN></Id></CdtrAcct>
      <RgltrRptg>
        <DbtCdtRptgInd>BOTH</DbtCdtRptgInd>
        <Authrty>${result.transaction.regulatoryAttestation}</Authrty>
      </RgltrRptg>
    </CdtTrfTxInf>
  </FIToFICstmrCdtTrf>
</Document>`;

      setActiveIsoMessage(isoXml);
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-white">
      {/* Disclaimer / Regulatory Notice banner */}
      <div className="bg-[#0e1726] border border-sky-500/40 rounded-xl p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
        <div className="text-xs text-slate-300 leading-relaxed">
          <span className="font-bold text-white uppercase tracking-wider font-mono">
            SYNTHETIC CENTRAL BANK SANDBOX ENVIRONMENT (SECTION 8 &amp; 25):
          </span>{' '}
          London Cipher maintains synthetic adapters for future programmable Central Bank Digital Currencies 
          (Digital GBP / Project Rosalind, Digital Euro / TIPS, and Digital USD RLN). 
          These environments are clearly distinguished from live production central-bank infrastructure.
        </div>
      </div>

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white flex items-center gap-3">
            <Building2 className="w-7 h-7 text-sky-400" />
            <span>Central Bank Digital Currency (CBDC) Control Room</span>
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Programmable fiat rails allowing enterprise customers and regulated institutions to settle file access conditions.
          </p>
        </div>

        {/* Rail selector tabs */}
        <div className="flex items-center gap-2 bg-[#090f1a] p-1.5 rounded-xl border border-slate-800">
          {(['CBDC_GBP', 'CBDC_EUR', 'CBDC_USD'] as const).map((rKey) => (
            <button
              key={rKey}
              onClick={() => setSelectedRailKey(rKey)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-colors ${
                selectedRailKey === rKey
                  ? 'bg-sky-600 text-white font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {CBDC_RAILS[rKey].currency} SANDBOX
            </button>
          ))}
        </div>
      </div>

      {/* Rail Profile Card */}
      <div className="bg-[#0b1322] border border-slate-700/80 rounded-2xl p-6 sm:p-7 space-y-5 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="space-y-1">
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-950 text-sky-400 border border-sky-700/50">
              SYNTHETIC ADAPTER &bull; {activeRail.isoStandard}
            </span>
            <h2 className="text-xl font-bold text-white">
              {activeRail.railName}
            </h2>
            <div className="text-xs text-slate-400 font-mono">
              Authority: <span className="text-slate-200">{activeRail.centralBankAuthority}</span>
            </div>
          </div>

          <div className="text-right font-mono text-xs space-y-1">
            <div className="text-slate-400">SETTLEMENT FINALITY:</div>
            <div className="text-emerald-400 font-bold">{activeRail.rtgsSettlementType}</div>
            <div className="text-slate-500 text-[11px]">&asymp; {activeRail.settlementLatencyAvgMs} ms avg latency</div>
          </div>
        </div>

        {/* Interactive Trial Settlement Trigger */}
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <Coins className="w-5 h-5 text-sky-400 shrink-0" />
            <div>
              <div className="text-xs font-semibold text-white">Execute Synthetic Settlement</div>
              <div className="text-[11px] text-slate-400">Simulate atomic Delivery-versus-Payment (DvP)</div>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="flex items-center gap-1 font-mono text-xs">
              <span className="text-slate-400">Amount:</span>
              <input
                type="number"
                value={testAmountGbp}
                onChange={(e) => setTestAmountGbp(Number(e.target.value))}
                className="w-24 bg-[#050810] border border-slate-700 rounded px-2 py-1 text-white text-xs font-mono"
              />
              <span className="text-slate-300 font-semibold">{activeRail.currency}</span>
            </div>

            <button
              onClick={handleTestSettle}
              disabled={isProcessing}
              className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 shadow-md shadow-sky-950"
            >
              {isProcessing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Landmark className="w-3.5 h-3.5" />}
              <span>Settle via RTGS</span>
            </button>
          </div>
        </div>

        {/* ISO 20022 Inspector */}
        {activeIsoMessage && (
          <div className="p-4 rounded-xl bg-[#050b14] border border-slate-800 space-y-2 font-mono text-xs">
            <div className="flex items-center justify-between text-slate-400 text-[11px]">
              <span className="text-sky-400 font-semibold">ISO 20022 pacs.008 XML Message Payload:</span>
              <span className="text-emerald-400">COMPLIANT</span>
            </div>
            <pre className="text-[11px] text-slate-300 p-3 bg-slate-950 rounded border border-slate-900 overflow-x-auto max-h-48 whitespace-pre">
              {activeIsoMessage}
            </pre>
          </div>
        )}
      </div>

      {/* Transaction History Ledger */}
      <div className="space-y-4">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Clock className="w-4 h-4 text-sky-400" />
          <span>Synthetic Central Bank Ledger Records</span>
        </h2>

        <div className="space-y-3 font-mono text-xs">
          {transactions.map((tx) => (
            <div key={tx.txId} className="p-4 rounded-xl bg-[#090f1b] border border-slate-800 space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white">{tx.txId}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                    {tx.status}
                  </span>
                  <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                    {tx.isoMessageType}
                  </span>
                </div>

                <div className="text-slate-300 font-bold">
                  {tx.amount.toFixed(2)} {tx.currency} (Fee: £{tx.fee.toFixed(2)})
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
                <div>Sender: <span className="text-slate-300">{tx.senderAccount}</span></div>
                <div>Recipient: <span className="text-slate-300">{tx.recipientAccount}</span></div>
                <div className="truncate">Attestation: <span className="text-sky-300">{tx.regulatoryAttestation}</span></div>
                <div>Settled At: <span className="text-slate-300">{new Date(tx.timestamp).toLocaleTimeString()} UTC</span></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
