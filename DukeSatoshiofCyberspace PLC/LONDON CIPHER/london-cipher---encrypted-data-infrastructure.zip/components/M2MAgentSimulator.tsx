'use client';

import React, { useState } from 'react';
import { 
  Cpu, 
  Zap, 
  Terminal, 
  CheckCircle2, 
  Play, 
  RefreshCw, 
  Lock, 
  Unlock, 
  ShieldCheck, 
  ArrowRight,
  Database
} from 'lucide-react';
import { CipherAuditEvent } from '@/lib/types';

interface M2MAgentSimulatorProps {
  onAddAuditEvent: (event: CipherAuditEvent) => void;
}

interface StepLog {
  time: string;
  type: 'REQUEST' | 'CHALLENGE_402' | 'PAYMENT_SENT' | 'HTLC_VERIFIED' | 'CAPABILITY_RELEASED' | 'DECRYPTED';
  message: string;
}

export function M2MAgentSimulator({ onAddAuditEvent }: M2MAgentSimulatorProps) {
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [logs, setLogs] = useState<StepLog[]>([]);
  const [receivedData, setReceivedData] = useState<string | null>(null);

  const runSimulation = () => {
    setIsRunning(true);
    setCurrentStep(1);
    setLogs([]);
    setReceivedData(null);

    const now = () => new Date().toISOString().slice(11, 23);

    // Step 1: Agent requests data
    setTimeout(() => {
      setLogs(prev => [
        ...prev,
        {
          time: now(),
          type: 'REQUEST',
          message: 'AGENT-AUTONOMOUS-QUANT-09 sends GET /v1/datasets/high-frequency-orderbook-lse',
        },
      ]);
      setCurrentStep(2);
    }, 400);

    // Step 2: 402 Payment Required + LCP Challenge
    setTimeout(() => {
      setLogs(prev => [
        ...prev,
        {
          time: now(),
          type: 'CHALLENGE_402',
          message: 'HTTP 402 PAYMENT REQUIRED. LCP Challenge emitted: 1,500 sats (~£0.98). PaymentHash: e3b0c44298fc1c14...',
        },
      ]);
      setCurrentStep(3);
    }, 900);

    // Step 3: Agent signs and pays Lightning HTLC
    setTimeout(() => {
      setLogs(prev => [
        ...prev,
        {
          time: now(),
          type: 'PAYMENT_SENT',
          message: 'Agent automated wallet dispatches 1,500 sats via Greenlight sub-node. Route hops: 2. Fee: 1 sat.',
        },
      ]);
      setCurrentStep(4);
    }, 1400);

    // Step 4: Settlement verification
    setTimeout(() => {
      const preimage = 'a98214db28c11e739ad00192847291aeb739201948572019284710293f93c847';
      setLogs(prev => [
        ...prev,
        {
          time: now(),
          type: 'HTLC_VERIFIED',
          message: `HTLC Preimage ${preimage.slice(0, 16)}... confirmed by London Cipher Node in 118 ms.`,
        },
      ]);

      onAddAuditEvent({
        eventId: `AUD-${Date.now().toString(36).toUpperCase()}`,
        timestamp: new Date().toISOString(),
        action: 'PAYMENT_VERIFIED',
        objectId: 'CO-PHOENIX-004',
        actor: 'agent:autonomous-quant-09',
        details: 'M2M autonomous micro-settlement. 1,500 sats verified for real-time telemetry stream.',
        paymentRail: 'LIGHTNING',
        previousEventHash: 'd48572019284710293f93c847a98214db28c11e739ad00192847291aeb739201',
        eventHash: `M2M-SETTLE-${Date.now().toString(36)}`,
      });

      setCurrentStep(5);
    }, 1900);

    // Step 5: Key Released & Local Decryption
    setTimeout(() => {
      setLogs(prev => [
        ...prev,
        {
          time: now(),
          type: 'CAPABILITY_RELEASED',
          message: 'Access capability token issued. DEK unwrapped. Payload decrypted in agent memory using AES-256-GCM.',
        },
      ]);

      setReceivedData(`[AGENT INGESTION COMPLETE]
ORDERBOOK_DEPTH_FEED_09:
BID: 142.85 (SIZE: 4,500) | ASK: 142.87 (SIZE: 8,200)
MICROSTRUCTURE ALPHA FACTOR: +1.482 sigma
EXECUTION RECOMMENDATION: BUY LSE:AVD.L`);

      setCurrentStep(6);
      setIsRunning(false);
    }, 2400);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-white">
      {/* Header */}
      <div className="bg-[#0b1324] border border-slate-700/80 rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase bg-emerald-950 text-emerald-300 border border-emerald-600/40">
                AUTONOMOUS MACHINE ECONOMY &bull; SECTION 19
              </span>
              <span className="text-xs text-slate-400 font-mono">AGENT-TO-AGENT PROTOCOL</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <Cpu className="w-7 h-7 text-emerald-400" />
              <span>Machine-to-Machine (M2M) Paid Data Exchange</span>
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Software and autonomous AI agents can query encrypted datasets, automatically satisfy 
              HTTP 402 cryptographic Lightning challenges, and receive decryption capabilities in milliseconds without human intervention.
            </p>
          </div>

          <button
            onClick={runSimulation}
            disabled={isRunning}
            className="px-5 py-3 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-semibold rounded-xl text-xs flex items-center gap-2 transition-all shadow-lg shadow-emerald-950"
          >
            {isRunning ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Agent Executing Protocol...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-white" />
                <span>Simulate AI Agent Micro-Purchase</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Protocol Visual Steps */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 font-mono text-xs">
        {[
          { num: 1, title: '1. QUERY DATASET', desc: 'AI Agent requests telemetry' },
          { num: 2, title: '2. 402 CHALLENGE', desc: 'Server returns LCP invoice' },
          { num: 3, title: '3. LIGHTNING PAY', desc: 'Agent settles 1,500 sats' },
          { num: 4, title: '4. VERIFY PREIMAGE', desc: 'Atomic HTLC resolution' },
          { num: 5, title: '5. DECRYPT & INGEST', desc: 'Capability unwrap in RAM' },
        ].map((s) => (
          <div
            key={s.num}
            className={`p-3.5 rounded-xl border transition-all ${
              currentStep === s.num
                ? 'bg-emerald-950/60 border-emerald-500 text-white shadow-md'
                : currentStep > s.num
                ? 'bg-[#09151e] border-emerald-800/60 text-slate-300'
                : 'bg-[#090f1b] border-slate-800 text-slate-500'
            }`}
          >
            <div className="flex items-center justify-between text-[11px] font-bold">
              <span>{s.title}</span>
              {currentStep > s.num && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
            </div>
            <div className="text-[10px] text-slate-400 mt-1 font-sans">{s.desc}</div>
          </div>
        ))}
      </div>

      {/* Terminal Output */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 bg-[#060a14] border border-slate-800 rounded-2xl p-5 space-y-3 font-mono text-xs shadow-2xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 text-slate-400">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span className="font-bold text-white">M2M EXECUTION TERMINAL</span>
            </div>
            <span className="text-[10px] bg-slate-900 px-2 py-0.5 rounded text-emerald-300">
              AGENT-ID: QUANT-09
            </span>
          </div>

          <div className="space-y-2 min-h-[220px] max-h-[320px] overflow-y-auto">
            {logs.length === 0 ? (
              <div className="text-slate-500 italic py-8 text-center">
                Click &ldquo;Simulate AI Agent Micro-Purchase&rdquo; to execute the automated LCP protocol lifecycle.
              </div>
            ) : (
              logs.map((log, i) => (
                <div key={i} className="flex items-start gap-2.5 leading-relaxed">
                  <span className="text-slate-500 select-none">[{log.time}]</span>
                  <span className={`font-semibold shrink-0 ${
                    log.type === 'REQUEST' ? 'text-sky-400' :
                    log.type === 'CHALLENGE_402' ? 'text-amber-400' :
                    log.type === 'PAYMENT_SENT' ? 'text-yellow-400' :
                    log.type === 'HTLC_VERIFIED' ? 'text-emerald-400' :
                    'text-purple-400'
                  }`}>
                    {log.type}:
                  </span>
                  <span className="text-slate-200">{log.message}</span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Decrypted Payload Ingested by Agent */}
        <div className="lg:col-span-4 bg-[#0a1120] border border-slate-700/80 rounded-2xl p-5 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2 text-xs font-bold text-white">
              <Database className="w-4 h-4 text-sky-400" />
              <span>Agent Memory Buffer</span>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
              {receivedData ? 'UNWRAPPED' : 'EMPTY'}
            </span>
          </div>

          {receivedData ? (
            <div className="p-3 bg-[#050811] rounded-xl border border-slate-800 font-mono text-[11px] text-emerald-300 leading-relaxed whitespace-pre-wrap">
              {receivedData}
            </div>
          ) : (
            <div className="text-xs text-slate-500 italic p-6 text-center">
              Agent has not yet decrypted telemetry. Run the simulation to trigger atomic payment and capability release.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
