'use client';

import React, { useState } from 'react';
import { 
  GitBranch, 
  Zap, 
  Building2, 
  Coins, 
  Landmark, 
  CheckCircle2, 
  Clock, 
  ArrowRight, 
  ShieldCheck, 
  TrendingUp,
  Sparkles
} from 'lucide-react';
import { CipherPaymentRouter } from '@/lib/payment-router';

export function PaymentRouterView() {
  const [inputPriceGbp, setInputPriceGbp] = useState<number>(25.00);

  const quotes = CipherPaymentRouter.quoteAll(inputPriceGbp);
  const recommendedRail = CipherPaymentRouter.getRecommendedRail(inputPriceGbp);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-white">
      {/* Header */}
      <div className="bg-[#0b1324] border border-slate-700/80 rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase bg-indigo-950 text-indigo-300 border border-indigo-600/40">
                UNIVERSAL ROUTER &bull; SECTION 9
              </span>
              <span className="text-xs text-slate-400 font-mono">MULTI-RAIL SETTLEMENT OPTIMIZER</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <GitBranch className="w-7 h-7 text-indigo-400" />
              <span>Universal Payment Router</span>
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Calculates optimal settlement paths across Bitcoin Lightning, Central Bank Digital Currencies (CBDC), 
              institutional stablecoins, and UK RTGS/CHAPS rails based on fee, latency, and finality guarantees.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2 font-mono text-xs">
            <div className="text-slate-400">TEST ACCESS PRICE:</div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold text-white">£</span>
              <input
                type="number"
                step="5"
                min="1"
                value={inputPriceGbp}
                onChange={(e) => setInputPriceGbp(Number(e.target.value))}
                className="w-28 bg-[#050810] border border-slate-700 rounded-lg px-3 py-1 text-sm font-bold text-amber-400 font-mono focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Recommended Strategy Badge */}
      <div className="p-4 rounded-xl bg-indigo-950/30 border border-indigo-500/30 flex items-center justify-between">
        <div className="flex items-center gap-2.5 text-xs">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <span className="text-slate-300">
            Automated Infrastructure Recommendation for <span className="text-white font-bold font-mono">£{inputPriceGbp.toFixed(2)}</span>:
          </span>
          <span className="text-emerald-400 font-bold font-mono uppercase">
            {recommendedRail}
          </span>
        </div>
        <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">
          Zero cryptocurrency speculation &bull; Pure cryptographic settlement
        </span>
      </div>

      {/* Comparison Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {quotes.map((quote) => {
          const isRecommended = quote.rail === recommendedRail;

          return (
            <div
              key={quote.rail}
              className={`p-6 rounded-2xl border transition-all space-y-5 relative ${
                isRecommended
                  ? 'bg-[#0c162c] border-sky-500 shadow-xl shadow-sky-950/40 ring-1 ring-sky-500/40'
                  : 'bg-[#090f1b] border-slate-800 hover:border-slate-700'
              }`}
            >
              {isRecommended && (
                <div className="absolute -top-3 right-4 bg-sky-500 text-white text-[10px] font-mono uppercase tracking-wider font-bold px-2.5 py-0.5 rounded-full shadow-md">
                  RECOMMENDED RAIL
                </div>
              )}

              {/* Title & Icon */}
              <div className="flex items-start gap-3">
                <div className={`p-3 rounded-xl border shrink-0 ${
                  quote.rail === 'LIGHTNING'
                    ? 'bg-amber-950/80 border-amber-500/40 text-amber-400'
                    : quote.rail.startsWith('CBDC')
                    ? 'bg-sky-950/80 border-sky-500/40 text-sky-400'
                    : 'bg-slate-800 border-slate-700 text-slate-300'
                }`}>
                  {quote.rail === 'LIGHTNING' ? (
                    <Zap className="w-5 h-5" />
                  ) : quote.rail.startsWith('CBDC') ? (
                    <Building2 className="w-5 h-5" />
                  ) : (
                    <Landmark className="w-5 h-5" />
                  )}
                </div>

                <div>
                  <h3 className="text-sm font-bold text-white">{quote.railLabel}</h3>
                  <div className="text-xs text-slate-400 font-mono mt-0.5">
                    Finality: <span className="text-slate-200">{quote.settlementFinality}</span>
                  </div>
                </div>
              </div>

              {/* Amount Display */}
              <div className="p-3 bg-[#050811] rounded-xl border border-slate-800/80 font-mono space-y-1">
                <div className="text-[10px] text-slate-400">SETTLEMENT AMOUNT:</div>
                <div className="text-base font-bold text-white">{quote.displayAmount}</div>
              </div>

              {/* Specs Matrix */}
              <div className="space-y-2 text-xs font-mono text-slate-300">
                <div className="flex justify-between border-b border-slate-800/60 pb-1.5">
                  <span className="text-slate-400">SETTLEMENT LATENCY:</span>
                  <span className="text-emerald-400 font-semibold">{quote.estimatedSettlementTime}</span>
                </div>

                <div className="flex justify-between border-b border-slate-800/60 pb-1.5">
                  <span className="text-slate-400">NETWORK ROUTING FEE:</span>
                  <span className="text-white font-semibold">{quote.networkFeeGbp}</span>
                </div>

                <div className="flex justify-between pb-1">
                  <span className="text-slate-400">KEY RELEASE:</span>
                  <span className="text-sky-300">Atomic HTLC</span>
                </div>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">
                {quote.description}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
