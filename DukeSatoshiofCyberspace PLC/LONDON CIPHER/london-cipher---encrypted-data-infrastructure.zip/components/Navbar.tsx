'use client';

import React from 'react';
import { 
  ShieldCheck, 
  Zap, 
  Building2, 
  Lock, 
  FileCode2, 
  GitBranch, 
  Cpu, 
  Activity, 
  Database,
  ArrowRight,
  Landmark
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenDealRoom: () => void;
  onOpenEncryption: () => void;
}

export function Navbar({ activeTab, setActiveTab, onOpenDealRoom, onOpenEncryption }: NavbarProps) {
  return (
    <header className="sticky top-0 z-50 bg-[#080c14]/90 backdrop-blur-md border-b border-slate-800/80 text-white">
      {/* Top institutional ticker strip */}
      <div className="bg-[#05080e] border-b border-slate-900 px-4 py-1 text-[11px] font-mono text-slate-400 flex items-center justify-between">
        <div className="flex items-center gap-4 overflow-x-auto no-scrollbar">
          <span className="flex items-center gap-1.5 text-emerald-400">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
            LONDON CIPHER PROTOCOL: LCP/1.2 ACTIVE
          </span>
          <span className="text-slate-600">|</span>
          <span>MAYFAIR NODE: <span className="text-slate-300 font-semibold">LON-CIPHER-01</span></span>
          <span className="text-slate-600">|</span>
          <span>LIGHTNING: <span className="text-amber-400">14.85 BTC CAPACITY</span></span>
          <span className="text-slate-600">|</span>
          <span>CBDC RAILS: <span className="text-sky-400">DIGITAL GBP / EUR / USD (SANDBOX)</span></span>
        </div>
        <div className="hidden md:flex items-center gap-3 text-slate-400">
          <span>CITY OF LONDON &bull; CANARY WHARF &bull; MAYFAIR</span>
          <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-sans">UK JURISDICTION</span>
        </div>
      </div>

      {/* Main navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Logo */}
        <div 
          onClick={() => setActiveTab('overview')}
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          {/* Hexagon Shield Monogram matching the screenshot */}
          <div className="relative w-9 h-9 flex items-center justify-center">
            <svg viewBox="0 0 100 100" className="w-full h-full text-sky-400 drop-shadow-[0_0_12px_rgba(56,189,248,0.4)]">
              <polygon points="50,4 94,27 94,73 50,96 6,73 6,27" fill="none" stroke="currentColor" strokeWidth="6" strokeLinejoin="round"/>
              <path d="M50 20 L76 34 L76 66 L50 80 L24 66 L24 34 Z" fill="none" stroke="#e2e8f0" strokeWidth="4" strokeLinejoin="round" opacity="0.8"/>
              <path d="M38 38 L38 62 L58 62" fill="none" stroke="#38bdf8" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M62 42 L48 42 L48 58 L62 58" fill="none" stroke="#94a3b8" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <div className="flex flex-col">
            <span className="font-bold text-lg tracking-[0.2em] text-white leading-tight font-sans">
              LONDON<span className="text-sky-400 ml-1.5 font-light">CIPHER</span>
            </span>
            <span className="text-[9px] uppercase tracking-[0.28em] text-slate-400 font-mono">
              Encrypted Data Infrastructure
            </span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-1.5">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
              activeTab === 'overview' ? 'text-white bg-slate-800/80 shadow-sm' : 'text-slate-300 hover:text-white hover:bg-slate-800/40'
            }`}
          >
            Overview
          </button>

          <button
            onClick={() => setActiveTab('deal-room')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors flex items-center gap-1.5 ${
              activeTab === 'deal-room' 
                ? 'text-amber-300 bg-amber-950/60 border border-amber-600/40 shadow-sm' 
                : 'text-amber-400/90 hover:text-amber-300 hover:bg-amber-950/30'
            }`}
          >
            <Landmark className="w-3.5 h-3.5" />
            <span>Deal Room</span>
            <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-mono">DEMO</span>
          </button>

          <button
            onClick={() => setActiveTab('vault')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
              activeTab === 'vault' ? 'text-white bg-slate-800/80' : 'text-slate-300 hover:text-white hover:bg-slate-800/40'
            }`}
          >
            Cipher Objects
          </button>

          <button
            onClick={() => setActiveTab('encryption')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
              activeTab === 'encryption' ? 'text-white bg-slate-800/80' : 'text-slate-300 hover:text-white hover:bg-slate-800/40'
            }`}
          >
            Encrypt File
          </button>

          <button
            onClick={() => setActiveTab('lightning')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors flex items-center gap-1 ${
              activeTab === 'lightning' ? 'text-amber-300 bg-slate-800/80' : 'text-slate-300 hover:text-amber-300 hover:bg-slate-800/40'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            Lightning
          </button>

          <button
            onClick={() => setActiveTab('cbdc')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors flex items-center gap-1 ${
              activeTab === 'cbdc' ? 'text-sky-300 bg-slate-800/80' : 'text-slate-300 hover:text-sky-300 hover:bg-slate-800/40'
            }`}
          >
            <Building2 className="w-3.5 h-3.5 text-sky-400" />
            CBDC Rails
          </button>

          <button
            onClick={() => setActiveTab('router')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
              activeTab === 'router' ? 'text-white bg-slate-800/80' : 'text-slate-300 hover:text-white hover:bg-slate-800/40'
            }`}
          >
            Router
          </button>

          <button
            onClick={() => setActiveTab('m2m')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors flex items-center gap-1 ${
              activeTab === 'm2m' ? 'text-emerald-300 bg-slate-800/80' : 'text-slate-300 hover:text-emerald-300 hover:bg-slate-800/40'
            }`}
          >
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
            M2M Agents
          </button>

          <button
            onClick={() => setActiveTab('audit')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
              activeTab === 'audit' ? 'text-white bg-slate-800/80' : 'text-slate-300 hover:text-white hover:bg-slate-800/40'
            }`}
          >
            Audit
          </button>

          <button
            onClick={() => setActiveTab('sdk')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors flex items-center gap-1 ${
              activeTab === 'sdk' ? 'text-white bg-slate-800/80' : 'text-slate-300 hover:text-white hover:bg-slate-800/40'
            }`}
          >
            <FileCode2 className="w-3.5 h-3.5 text-slate-400" />
            API & SDKs
          </button>
        </nav>

        {/* Right CTA */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenDealRoom}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-amber-300 bg-amber-950/40 hover:bg-amber-900/50 border border-amber-500/30 rounded transition-all shadow-sm"
          >
            <span>Confidential Deal Room</span>
          </button>

          <button
            onClick={() => setActiveTab('deal-room')}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 active:bg-sky-700 rounded transition-all shadow-md shadow-sky-950 hover:shadow-sky-500/20"
          >
            <span>Launch Platform</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Mobile/Tablet Submenu Bar */}
      <div className="lg:hidden flex items-center gap-1 px-4 py-2 bg-slate-950/70 border-t border-slate-900 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded ${activeTab === 'overview' ? 'text-white bg-slate-800' : 'text-slate-400'}`}
        >
          Overview
        </button>
        <button
          onClick={() => setActiveTab('deal-room')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded font-medium ${activeTab === 'deal-room' ? 'text-amber-300 bg-amber-950' : 'text-amber-400'}`}
        >
          Deal Room (Demo)
        </button>
        <button
          onClick={() => setActiveTab('encryption')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded ${activeTab === 'encryption' ? 'text-white bg-slate-800' : 'text-slate-400'}`}
        >
          Encrypt
        </button>
        <button
          onClick={() => setActiveTab('vault')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded ${activeTab === 'vault' ? 'text-white bg-slate-800' : 'text-slate-400'}`}
        >
          Cipher Objects
        </button>
        <button
          onClick={() => setActiveTab('lightning')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded ${activeTab === 'lightning' ? 'text-amber-300 bg-slate-800' : 'text-slate-400'}`}
        >
          Lightning
        </button>
        <button
          onClick={() => setActiveTab('cbdc')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded ${activeTab === 'cbdc' ? 'text-sky-300 bg-slate-800' : 'text-slate-400'}`}
        >
          CBDC
        </button>
        <button
          onClick={() => setActiveTab('m2m')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded ${activeTab === 'm2m' ? 'text-emerald-300 bg-slate-800' : 'text-slate-400'}`}
        >
          M2M
        </button>
        <button
          onClick={() => setActiveTab('sdk')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded ${activeTab === 'sdk' ? 'text-white bg-slate-800' : 'text-slate-400'}`}
        >
          SDKs
        </button>
      </div>
    </header>
  );
}
