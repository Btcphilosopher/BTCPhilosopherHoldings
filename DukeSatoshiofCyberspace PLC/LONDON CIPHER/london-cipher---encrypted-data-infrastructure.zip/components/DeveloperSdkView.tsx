'use client';

import React, { useState } from 'react';
import { 
  FileCode2, 
  Terminal, 
  Copy, 
  CheckCircle2, 
  ExternalLink, 
  Code, 
  Layers, 
  Cpu, 
  Server,
  Play,
  RefreshCw
} from 'lucide-react';
import { SDK_CODE_SNIPPETS } from '@/lib/sdk-code';

export function DeveloperSdkView() {
  const [activeSnippetId, setActiveSnippetId] = useState<string>('python-core');
  const [copied, setCopied] = useState<boolean>(false);
  
  // Interactive REST API Tester
  const [apiMethod, setApiMethod] = useState<'GET' | 'POST'>('GET');
  const [apiEndpoint, setApiEndpoint] = useState<string>('/api/v1/cipher-objects');
  const [apiResponse, setApiResponse] = useState<string | null>(null);
  const [isCallingApi, setIsCallingApi] = useState<boolean>(false);

  const activeSnippet = SDK_CODE_SNIPPETS.find(s => s.id === activeSnippetId) || SDK_CODE_SNIPPETS[0];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(activeSnippet.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRunApiTest = async () => {
    setIsCallingApi(true);
    try {
      const res = await fetch(apiEndpoint, {
        method: apiMethod,
        headers: { 'Content-Type': 'application/json' },
        ...(apiMethod === 'POST' ? { body: JSON.stringify({ priceGbp: 25.00 }) } : {}),
      });
      const data = await res.json();
      setApiResponse(JSON.stringify(data, null, 2));
    } catch (err: any) {
      setApiResponse(JSON.stringify({ error: err.message }, null, 2));
    } finally {
      setIsCallingApi(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-white">
      {/* Header */}
      <div className="bg-[#0b1324] border border-slate-700/80 rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase bg-sky-950 text-sky-400 border border-sky-600/40">
              DEVELOPER INFRASTRUCTURE &bull; SECTION 20, 21 &amp; 30
            </span>
            <span className="text-xs text-slate-400 font-mono">REST &bull; LCP PROTOCOL &bull; MULTI-LANG SDKs</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
            <FileCode2 className="w-7 h-7 text-sky-400" />
            <span>Developer API &amp; Multi-Language SDKs</span>
          </h1>
          <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
            Integrate London Cipher into institutional backend workflows. 
            Native implementations for Python, Rust (streaming AEAD), Kotlin (Enterprise &amp; Android), TypeScript, and R (risk simulation).
          </p>
        </div>
      </div>

      {/* Interactive REST API Playground */}
      <div className="bg-[#0a101d] border border-slate-800 rounded-2xl p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Terminal className="w-4 h-4 text-sky-400" />
            <span>Live REST API Explorer</span>
          </h2>
          <span className="text-xs text-slate-400 font-mono">v1 Public Endpoints</span>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          <select
            value={apiMethod}
            onChange={(e) => setApiMethod(e.target.value as any)}
            className="bg-[#050810] border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono font-bold text-sky-400 focus:outline-none"
          >
            <option value="GET">GET</option>
            <option value="POST">POST</option>
          </select>

          <select
            value={apiEndpoint}
            onChange={(e) => {
              setApiEndpoint(e.target.value);
              if (e.target.value === '/api/v1/payments/quote') {
                setApiMethod('POST');
              } else {
                setApiMethod('GET');
              }
            }}
            className="w-full bg-[#050810] border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-sky-500"
          >
            <option value="/api/v1/cipher-objects">/api/v1/cipher-objects (List hash-committed objects)</option>
            <option value="/api/v1/payments/quote">/api/v1/payments/quote (Multi-rail price quote)</option>
            <option value="/api/v1/audit">/api/v1/audit (Query immutable audit stream)</option>
          </select>

          <button
            onClick={handleRunApiTest}
            disabled={isCallingApi}
            className="px-4 py-2 bg-sky-600 hover:bg-sky-500 active:bg-sky-700 text-white rounded-lg text-xs font-semibold whitespace-nowrap flex items-center gap-1.5 transition-colors shadow-md"
          >
            {isCallingApi ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
            <span>Execute Request</span>
          </button>
        </div>

        {apiResponse && (
          <div className="p-3 bg-[#050811] rounded-xl border border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-400 font-mono uppercase block">RESPONSE BODY (JSON):</span>
            <pre className="text-[11px] font-mono text-emerald-300 overflow-x-auto max-h-48 p-2 whitespace-pre">
              {apiResponse}
            </pre>
          </div>
        )}
      </div>

      {/* Multi-Language Code Viewer (Section 30) */}
      <div className="bg-[#0a101d] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
        {/* Language Tabs */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-[#060a14] px-4 py-2 overflow-x-auto">
          <div className="flex items-center gap-2">
            {SDK_CODE_SNIPPETS.map((snippet) => (
              <button
                key={snippet.id}
                onClick={() => setActiveSnippetId(snippet.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-colors whitespace-nowrap ${
                  activeSnippetId === snippet.id
                    ? 'bg-sky-600 text-white font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {snippet.language.toUpperCase()} &bull; {snippet.filename.split('/').pop()}
              </button>
            ))}
          </div>

          <button
            onClick={handleCopyCode}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono rounded flex items-center gap-1.5 transition-colors shrink-0 ml-4"
          >
            {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Source'}</span>
          </button>
        </div>

        {/* Code Description Bar */}
        <div className="p-4 bg-[#080d19] border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="text-sm font-bold text-white">{activeSnippet.title}</div>
            <div className="text-xs text-slate-400 mt-0.5">{activeSnippet.description}</div>
          </div>
          <span className="text-[11px] font-mono text-sky-400 bg-sky-950 px-2 py-0.5 rounded border border-sky-800 self-start sm:self-auto">
            {activeSnippet.filename}
          </span>
        </div>

        {/* Code Container */}
        <div className="p-5 bg-[#04070f] overflow-x-auto max-h-[520px]">
          <pre className="font-mono text-xs text-slate-200 leading-relaxed whitespace-pre">
            {activeSnippet.code}
          </pre>
        </div>
      </div>
    </div>
  );
}
