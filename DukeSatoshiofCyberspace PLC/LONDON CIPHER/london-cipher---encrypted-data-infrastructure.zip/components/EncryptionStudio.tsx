'use client';

import React, { useState } from 'react';
import { 
  Lock, 
  Unlock, 
  Upload, 
  FileCheck, 
  Key, 
  Zap, 
  Building2, 
  CheckCircle2, 
  ShieldCheck, 
  Copy, 
  Download, 
  ArrowRight,
  RefreshCw,
  Cpu,
  Layers,
  Sparkles
} from 'lucide-react';
import { 
  generateDEK, 
  encryptBytesAESGCM, 
  decryptBytesAESGCM, 
  wrapKey, 
  sha256Hex, 
  str2buf, 
  buf2str, 
  buf2hex 
} from '@/lib/crypto-engine';
import { CipherObject, CipherAuditEvent, AccessModel } from '@/lib/types';

interface EncryptionStudioProps {
  onAddCipherObject: (obj: CipherObject) => void;
  onAddAuditEvent: (event: CipherAuditEvent) => void;
  onOpenDealRoom: () => void;
}

export function EncryptionStudio({ onAddCipherObject, onAddAuditEvent, onOpenDealRoom }: EncryptionStudioProps) {
  // Input file / text
  const [fileName, setFileName] = useState<string>('Proprietary_Alpha_Strategy.py');
  const [plaintextContent, setPlaintextContent] = useState<string>(
`# LONDON CIPHER — PROPRIETARY ALGORITHMIC ARBITRAGE MODEL
# Mayfair Quantitative Asset Management LLP (Strictly Privileged)

import numpy as np
import pandas as pd

class HighFrequencyArbitrage:
    """
    Sub-millisecond liquidity latency model across LSE, Euronext and CME.
    Encrypted for autonomous machine-to-machine distribution via Lightning micropayments.
    """
    def __init__(self, execution_speed_us=120):
        self.latency_us = execution_speed_us
        self.alpha_factor = 2.84
        
    def evaluate_spread(self, book_depth):
        # Confidential proprietary spread calculation
        return np.mean(book_depth) * self.alpha_factor`
  );

  // Policy configuration
  const [priceGbp, setPriceGbp] = useState<number>(15.00);
  const [accessModel, setAccessModel] = useState<AccessModel>('ONE_TIME_PURCHASE');
  const [category, setCategory] = useState<'FINANCIAL' | 'LEGAL' | 'ENGINEERING' | 'TELEMETRY' | 'RESEARCH'>('FINANCIAL');
  
  // Encryption status & result
  const [isEncrypting, setIsEncrypting] = useState<boolean>(false);
  const [encryptedResult, setEncryptedResult] = useState<{
    ciphertextHex: string;
    ivHex: string;
    authTagHex: string;
    rawDekHex: string;
    wrappedKeyHex: string;
    fileHash: string;
    metaHash: string;
    object: CipherObject;
  } | null>(null);

  // Test decryption verification
  const [testDecryptedText, setTestDecryptedText] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Handle local file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result;
      if (typeof content === 'string') {
        setPlaintextContent(content);
      }
    };
    reader.readAsText(file);
  };

  // Execute client-side AES-256-GCM encryption
  const handleEncrypt = async () => {
    setIsEncrypting(true);
    setTestDecryptedText(null);

    try {
      const dataBytes = str2buf(plaintextContent);
      
      // Step 1: Generate independent 256-bit DEK
      const { rawHex: dekHex } = await generateDEK();

      // Step 2: Encrypt with AES-256-GCM (produces ciphertext + 96-bit IV + 128-bit tag)
      const encResult = await encryptBytesAESGCM(dataBytes, dekHex);

      // Step 3: Wrap key under Master KWK (Layer B separation)
      const wrappedKeyHex = await wrapKey(dekHex);

      // Step 4: Compute metadata commitment hash
      const metaHash = await sha256Hex(fileName + category + priceGbp);

      // Step 5: Construct Hash-Committed CipherObject
      const objectId = `CO-LON-${Math.random().toString(36).slice(2, 6).toUpperCase()}-${Date.now().toString(36).slice(-4).toUpperCase()}`;

      const newCipherObject: CipherObject = {
        id: objectId,
        title: fileName.replace(/\.[^/.]+$/, '').replace(/_/g, ' '),
        filename: `${fileName}.enc`,
        originalSize: dataBytes.length,
        mimeType: 'text/plain',
        algorithm: 'AES-256-GCM',
        encryptedFileHash: encResult.fileHash,
        originalMetadataHash: metaHash,
        integrityCommitment: `MKR-ROOT-${Math.random().toString(36).slice(2, 12)}`,
        keyIdentifier: `KEY-DEK-${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
        wrappedKeyPayload: wrappedKeyHex,
        iv: encResult.ivHex,
        authTag: encResult.authTagHex,
        createdAt: new Date().toISOString(),
        owner: 'Institutional Client (Local Browser)',
        status: 'LOCKED',
        category,
        plaintextSample: plaintextContent,
        accessPolicy: {
          policyId: `POL-${Date.now().toString(36).toUpperCase()}`,
          accessModel,
          priceGbp,
          priceSats: Math.round(priceGbp * 1540),
          validitySeconds: accessModel === 'TIME_LIMITED_24H' ? 86400 : 0,
          allowedRails: ['LIGHTNING', 'CBDC_GBP'],
          requireKycLevel: 'BASIC',
          maxDownloads: 5,
          revocationFlag: false,
          m2mCompatible: true,
        },
      };

      setEncryptedResult({
        ...encResult,
        rawDekHex: dekHex,
        wrappedKeyHex,
        metaHash,
        object: newCipherObject,
      });

      // Save to platform state
      onAddCipherObject(newCipherObject);

      // Record immutable audit event
      onAddAuditEvent({
        eventId: `AUD-${Date.now().toString(36).toUpperCase()}`,
        timestamp: new Date().toISOString(),
        action: 'FILE_ENCRYPTED',
        objectId,
        actor: 'local-browser:webcrypto',
        details: `Client-side authenticated AES-256-GCM encryption. ${dataBytes.length} bytes encrypted. SHA-256 commitment: ${encResult.fileHash.slice(0, 16)}...`,
        previousEventHash: 'd48572019284710293f93c847a98214db28c11e739ad00192847291aeb739201',
        eventHash: encResult.fileHash,
      });

    } catch (err) {
      console.error('Encryption failed:', err);
    } finally {
      setIsEncrypting(false);
    }
  };

  // Test local decryption in browser
  const handleTestDecryption = async () => {
    if (!encryptedResult) return;
    try {
      const decryptedBytes = await decryptBytesAESGCM(
        encryptedResult.ciphertextHex,
        encryptedResult.rawDekHex,
        encryptedResult.ivHex,
        encryptedResult.authTagHex
      );
      setTestDecryptedText(buf2str(decryptedBytes));
    } catch (err) {
      console.error('Decryption failed:', err);
    }
  };

  const handleDownloadCiphertext = () => {
    if (!encryptedResult) return;
    const blob = new Blob([encryptedResult.ciphertextHex], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = encryptedResult.object.filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadManifest = () => {
    if (!encryptedResult) return;
    const manifest = {
      protocol: 'LCP/1.2',
      cipherObject: encryptedResult.object,
      hashCommitment: encryptedResult.fileHash,
      metadataCommitment: encryptedResult.metaHash,
      iv: encryptedResult.ivHex,
      authTag: encryptedResult.authTagHex,
      wrappedKey: encryptedResult.wrappedKeyHex,
    };
    const blob = new Blob([JSON.stringify(manifest, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${encryptedResult.object.filename}.manifest.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const copyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-white">
      {/* Studio Header */}
      <div className="bg-[#0b1222] border border-slate-700/80 rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase bg-sky-950 text-sky-400 border border-sky-600/40">
                LAYER A CRYPTOGRAPHY &bull; CLIENT-SIDE ZERO-KNOWLEDGE
              </span>
              <span className="text-xs text-slate-400 font-mono">STANDARDS-COMPLIANT AEAD</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Cryptographic Encryption &amp; Policy Studio
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Encrypt files in your browser before transfer using authenticated AES-256-GCM. 
              The London Cipher server never sees your plaintext file or raw decryption key.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onOpenDealRoom}
              className="px-4 py-2 bg-amber-950/60 hover:bg-amber-900/60 text-amber-300 border border-amber-500/40 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all"
            >
              <span>View Confidential Deal Room</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: File Input & Configuration (6 Cols) */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-[#0a101d] border border-slate-800 rounded-2xl p-6 space-y-5 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-sky-400" />
                <span>1. Select Plaintext Payload</span>
              </h2>

              <label className="cursor-pointer px-3 py-1 bg-slate-800 hover:bg-slate-700 text-sky-300 text-xs font-medium rounded flex items-center gap-1.5 transition-colors">
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Local File</span>
                <input type="file" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>

            {/* Filename & Category */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">
                  Filename
                </label>
                <input
                  type="text"
                  value={fileName}
                  onChange={(e) => setFileName(e.target.value)}
                  className="w-full bg-[#050810] border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">
                  Domain / Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full bg-[#050810] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-500"
                >
                  <option value="FINANCIAL">Financial Models &amp; M&amp;A</option>
                  <option value="LEGAL">Legal Opinions &amp; Contracts</option>
                  <option value="ENGINEERING">Engineering &amp; Avionics</option>
                  <option value="TELEMETRY">High-Frequency Telemetry</option>
                  <option value="RESEARCH">Scientific &amp; Medical Data</option>
                </select>
              </div>
            </div>

            {/* Plaintext Editor */}
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">
                Plaintext Content (Encrypted Locally in Browser Memory)
              </label>
              <textarea
                rows={8}
                value={plaintextContent}
                onChange={(e) => setPlaintextContent(e.target.value)}
                className="w-full bg-[#050810] border border-slate-700 rounded-lg p-3 text-xs font-mono text-slate-200 focus:outline-none focus:border-sky-500 leading-relaxed resize-y"
              />
              <span className="text-[11px] text-slate-500 font-mono">
                Length: {plaintextContent.length} characters ({str2buf(plaintextContent).length} bytes)
              </span>
            </div>

            {/* Section 2: Access Policy Configuration */}
            <div className="pt-4 border-t border-slate-800 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-400" />
                <span>2. Configure Payment-Gated Access Policy</span>
              </h3>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-medium text-slate-300 block mb-1">
                    Price in GBP (£)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.5"
                      min="0.5"
                      value={priceGbp}
                      onChange={(e) => setPriceGbp(Number(e.target.value))}
                      className="w-full bg-[#050810] border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-500"
                    />
                    <div className="text-[10px] text-amber-400 font-mono mt-1">
                      &asymp; {Math.round(priceGbp * 1540).toLocaleString()} satoshis
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-300 block mb-1">
                    Access Model
                  </label>
                  <select
                    value={accessModel}
                    onChange={(e) => setAccessModel(e.target.value as any)}
                    className="w-full bg-[#050810] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="ONE_TIME_PURCHASE">One-Time Purchase</option>
                    <option value="TIME_LIMITED_24H">Time-Limited (24h Lease)</option>
                    <option value="PAY_PER_DOWNLOAD">Pay-Per-Download</option>
                    <option value="PAY_PER_QUERY">Pay-Per-Query (API)</option>
                    <option value="MACHINE_TO_MACHINE">Machine-to-Machine (M2M Agent)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Encrypt Action Button */}
            <button
              onClick={handleEncrypt}
              disabled={isEncrypting}
              className="w-full py-3.5 bg-sky-600 hover:bg-sky-500 active:bg-sky-700 text-white font-semibold rounded-xl text-xs transition-all shadow-lg shadow-sky-950 flex items-center justify-center gap-2"
            >
              {isEncrypting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Executing WebCrypto AES-256-GCM...</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Encrypt &amp; Generate Hash-Committed CipherObject</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Cryptographic Output & Proofs (6 Cols) */}
        <div className="lg:col-span-6 space-y-6">
          {encryptedResult ? (
            <div className="bg-[#091220] border border-sky-500/40 rounded-2xl p-6 space-y-5 shadow-2xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  <span className="text-sm font-bold text-white">
                    Encrypted CipherObject Created
                  </span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-600/40">
                  {encryptedResult.object.id}
                </span>
              </div>

              {/* Cryptographic breakdown */}
              <div className="space-y-3 font-mono text-xs">
                {/* SHA-256 Hash Commitment */}
                <div className="p-3 bg-[#050811] rounded-lg border border-slate-800 space-y-1">
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span className="text-sky-300 font-semibold">1. CIPHERTEXT SHA-256 HASH COMMITMENT:</span>
                    <button
                      onClick={() => copyText(encryptedResult.fileHash, 'hash')}
                      className="text-slate-400 hover:text-white flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" />
                      <span>{copiedKey === 'hash' ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                  <div className="text-slate-200 break-all text-[11px]">
                    {encryptedResult.fileHash}
                  </div>
                </div>

                {/* IV & Auth Tag */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-2.5 bg-[#050811] rounded-lg border border-slate-800 space-y-1">
                    <span className="text-[10px] text-slate-400 block">IV / NONCE (96-BIT):</span>
                    <span className="text-slate-200 text-[11px] break-all">{encryptedResult.ivHex}</span>
                  </div>
                  <div className="p-2.5 bg-[#050811] rounded-lg border border-slate-800 space-y-1">
                    <span className="text-[10px] text-slate-400 block">AUTH TAG (128-BIT):</span>
                    <span className="text-slate-200 text-[11px] break-all">{encryptedResult.authTagHex}</span>
                  </div>
                </div>

                {/* Wrapped DEK (Layer B) */}
                <div className="p-3 bg-[#050811] rounded-lg border border-slate-800 space-y-1">
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span className="text-amber-400 font-semibold">2. WRAPPED DEK (LAYER B KEY-ESCROW):</span>
                    <button
                      onClick={() => copyText(encryptedResult.wrappedKeyHex, 'wrap')}
                      className="text-slate-400 hover:text-white flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" />
                      <span>{copiedKey === 'wrap' ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                  <div className="text-slate-300 break-all text-[11px]">
                    {encryptedResult.wrappedKeyHex}
                  </div>
                </div>
              </div>

              {/* Download buttons */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={handleDownloadCiphertext}
                  className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors border border-slate-700"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .enc Payload</span>
                </button>

                <button
                  onClick={handleDownloadManifest}
                  className="py-2.5 px-3 bg-sky-900/60 hover:bg-sky-800 text-sky-200 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors border border-sky-500/40"
                >
                  <FileCheck className="w-3.5 h-3.5" />
                  <span>Download .manifest.json</span>
                </button>
              </div>

              {/* Test local decryption */}
              <div className="pt-3 border-t border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-300">
                    Roundtrip Verification
                  </span>
                  <button
                    onClick={handleTestDecryption}
                    className="text-xs text-sky-400 hover:text-sky-300 flex items-center gap-1 font-mono underline"
                  >
                    <Unlock className="w-3 h-3" />
                    <span>Verify Decryption with Local DEK</span>
                  </button>
                </div>

                {testDecryptedText && (
                  <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/40 font-mono text-[11px] text-emerald-200 space-y-1">
                    <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Roundtrip Decryption Successful &bull; Tag Validated</span>
                    </div>
                    <div className="truncate max-w-md text-slate-300">
                      {testDecryptedText.slice(0, 100)}...
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-[#0a101d] border border-dashed border-slate-800 rounded-2xl p-10 flex flex-col items-center justify-center text-center space-y-4 min-h-[420px]">
              <div className="p-4 rounded-full bg-slate-900 border border-slate-800 text-slate-500">
                <Lock className="w-8 h-8" />
              </div>
              <div className="space-y-1 max-w-sm">
                <h3 className="text-sm font-semibold text-white">No Active Encrypted Object</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Enter your file or choose sample data on the left, then click &ldquo;Encrypt&rdquo; to generate a 
                  hash-committed CipherObject with independent DEK wrapping.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
