export interface CipherConfig {
  baseUrl: string;
  apiKey?: string;
}

export class LondonCipherClient {
  constructor(private config: CipherConfig) {}

  /**
   * Encrypts file buffer in client memory (Zero-Knowledge Architecture)
   */
  async encryptBuffer(data: Uint8Array): Promise<{
    ciphertext: Uint8Array;
    fileHash: string;
    iv: Uint8Array;
    tag: Uint8Array;
    dekHex: string;
  }> {
    const key = await crypto.subtle.generateKey(
      { name: "AES-GCM", length: 256 },
      true,
      ["encrypt", "decrypt"]
    );
    const rawKey = await crypto.subtle.exportKey("raw", key);
    const dekHex = Array.from(new Uint8Array(rawKey))
      .map(b => b.toString(16).padStart(2, "0"))
      .join("");

    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: iv as unknown as BufferSource, tagLength: 128 },
      key,
      data as unknown as BufferSource
    );

    const hashBuffer = await crypto.subtle.digest("SHA-256", encrypted);
    const fileHash = Array.from(new Uint8Array(hashBuffer))
      .map(b => b.toString(16).padStart(2, "0"))
      .join("");

    const encryptedBytes = new Uint8Array(encrypted);
    const ciphertext = encryptedBytes.slice(0, encryptedBytes.length - 16);
    const tag = encryptedBytes.slice(encryptedBytes.length - 16);

    return { ciphertext, fileHash, iv, tag, dekHex };
  }

  async requestAccess(objectId: string, rail: "LIGHTNING" | "CBDC_GBP") {
    const res = await fetch(`${this.config.baseUrl}/v1/cipher-objects/${objectId}/access`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rail }),
    });
    return await res.json();
  }
}
