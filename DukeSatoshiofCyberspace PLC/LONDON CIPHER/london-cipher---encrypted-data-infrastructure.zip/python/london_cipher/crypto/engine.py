"""
LONDON CIPHER — Core Cryptographic & Access Engine
Combines conventional modern encryption with Lightning Network settlement conditions.
"""

import os
import hashlib
from typing import Tuple, Dict, Any, Optional
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

class LondonCipherEngine:
    """
    Core Cryptographic Engine for London Cipher.
    Implements Layer A (AES-256-GCM Data Encryption)
    and Layer B (Settlement-Gated Key Wrapping).
    """

    def __init__(self, master_kwk: Optional[bytes] = None):
        # 256-bit Key Wrapping Key (KWK)
        self.master_kwk = master_kwk or os.urandom(32)

    def generate_dek(self) -> bytes:
        """Generates a strong random 256-bit Data Encryption Key (DEK)."""
        return AESGCM.generate_key(bit_length=256)

    def encrypt_file(self, file_path: str) -> Dict[str, Any]:
        """
        Encrypts arbitrary file payload using AES-256-GCM.
        Generates independent random DEK and 96-bit IV.
        Plaintext is never logged or exposed.
        """
        with open(file_path, "rb") as f:
            plaintext = f.read()

        dek = self.generate_dek()
        iv = os.urandom(12)  # 96-bit nonce
        aesgcm = AESGCM(dek)
        
        # Authenticated encryption (produces ciphertext + 128-bit tag)
        ciphertext = aesgcm.encrypt(iv, plaintext, associated_data=b"LONDON_CIPHER_V1")
        
        # Cryptographic file commitment
        file_hash = hashlib.sha256(ciphertext).hexdigest()
        meta_hash = hashlib.sha256(os.path.basename(file_path).encode()).hexdigest()
        
        # Wrap DEK under Key Wrapping Key (Layer B separation)
        wrapped_key = self.wrap_key(dek)

        return {
            "file_hash": file_hash,
            "metadata_hash": meta_hash,
            "algorithm": "AES-256-GCM",
            "iv": iv.hex(),
            "wrapped_key": wrapped_key.hex(),
            "ciphertext": ciphertext,
            "file_size": len(plaintext),
        }

    def decrypt_file(self, ciphertext: bytes, iv_hex: str, unwrapped_dek: bytes) -> bytes:
        """
        Decrypts authenticated ciphertext using released DEK.
        Fails cryptographically if ciphertext or tag was tampered with.
        """
        iv = bytes.fromhex(iv_hex)
        aesgcm = AESGCM(unwrapped_dek)
        return aesgcm.decrypt(iv, ciphertext, associated_data=b"LONDON_CIPHER_V1")

    def wrap_key(self, dek: bytes) -> bytes:
        """Wraps DEK using HKDF-derived key mask from master KWK."""
        salt = os.urandom(16)
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=len(dek),
            salt=salt,
            info=b"LONDON_CIPHER_KEY_WRAP",
        )
        mask = hkdf.derive(self.master_kwk)
        wrapped = bytes(a ^ b for a, b in zip(dek, mask))
        return salt + wrapped

    def unwrap_key(self, wrapped_payload: bytes) -> bytes:
        """Unwraps DEK after settlement authorization is verified."""
        salt = wrapped_payload[:16]
        wrapped = wrapped_payload[16:]
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=len(wrapped),
            salt=salt,
            info=b"LONDON_CIPHER_KEY_WRAP",
        )
        mask = hkdf.derive(self.master_kwk)
        return bytes(a ^ b for a, b in zip(wrapped, mask))

    def verify_integrity(self, ciphertext: bytes, expected_hash: str) -> bool:
        """Verifies hash commitment before attempting decryption."""
        computed = hashlib.sha256(ciphertext).hexdigest()
        return computed.lower() == expected_hash.lower()
