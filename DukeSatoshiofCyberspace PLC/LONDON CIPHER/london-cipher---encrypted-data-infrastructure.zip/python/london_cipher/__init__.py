"""
LONDON CIPHER — Official Python Package (london_cipher)
Combines conventional modern authenticated encryption with Lightning Network settlement and CBDC payment conditions.
"""

from .crypto.engine import LondonCipherEngine

__version__ = "1.2.0"
__all__ = ["LondonCipherEngine"]
