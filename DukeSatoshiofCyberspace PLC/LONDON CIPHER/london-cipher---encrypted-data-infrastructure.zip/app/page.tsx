'use client';

import React, { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { HeroBanner } from '@/components/HeroBanner';
import { DealRoom } from '@/components/DealRoom';
import { EncryptionStudio } from '@/components/EncryptionStudio';
import { CipherObjectsVault } from '@/components/CipherObjectsVault';
import { LightningControlRoom } from '@/components/LightningControlRoom';
import { CBDCControlRoom } from '@/components/CBDCControlRoom';
import { PaymentRouterView } from '@/components/PaymentRouterView';
import { M2MAgentSimulator } from '@/components/M2MAgentSimulator';
import { KeyManagementView } from '@/components/KeyManagementView';
import { AuditLogView } from '@/components/AuditLogView';
import { DeveloperSdkView } from '@/components/DeveloperSdkView';
import { ArchitectureDiagram } from '@/components/ArchitectureDiagram';
import { INITIAL_DEAL_ROOM_OBJECTS, INITIAL_AUDIT_EVENTS } from '@/lib/initial-data';
import { CipherObject, CipherAuditEvent } from '@/lib/types';
import { 
  Building2, 
  ShieldCheck, 
  Zap, 
  Lock, 
  FileCode2, 
  ArrowRight,
  ExternalLink,
  Linkedin,
  Twitter,
  Send,
  Landmark
} from 'lucide-react';

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [cipherObjects, setCipherObjects] = useState<CipherObject[]>(INITIAL_DEAL_ROOM_OBJECTS);
  const [auditEvents, setAuditEvents] = useState<CipherAuditEvent[]>(INITIAL_AUDIT_EVENTS);

  const handleAddCipherObject = (newObj: CipherObject) => {
    setCipherObjects(prev => [newObj, ...prev]);
    setActiveTab('vault');
  };

  const handleAddAuditEvent = (event: CipherAuditEvent) => {
    setAuditEvents(prev => [event, ...prev]);
  };

  const handleSelectDealRoomObject = (objectId: string) => {
    setActiveTab('deal-room');
  };

  return (
    <div className="min-h-screen bg-[#070b12] text-slate-100 flex flex-col font-sans selection:bg-sky-500 selection:text-white">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenDealRoom={() => setActiveTab('deal-room')}
        onOpenEncryption={() => setActiveTab('encryption')}
      />

      {/* Main Content Areas */}
      <main className="flex-1">
        {activeTab === 'overview' && (
          <div className="space-y-12">
            <HeroBanner
              onOpenDealRoom={() => setActiveTab('deal-room')}
              onOpenEncryption={() => setActiveTab('encryption')}
              setActiveTab={setActiveTab}
            />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 pb-16">
              {/* Architecture & Double-Layer Security Model */}
              <ArchitectureDiagram />

              {/* Startup Commercial Strategy & Products (Section 27) */}
              <div className="bg-[#0b1220] border border-slate-800 rounded-2xl p-8 space-y-6">
                <div className="space-y-1">
                  <span className="text-xs font-mono uppercase tracking-widest text-sky-400 font-semibold">
                    ENTERPRISE COMMERCIAL PRODUCTS &bull; SECTION 27
                  </span>
                  <h3 className="text-2xl font-bold text-white">
                    Built for Modern Enterprise &amp; Autonomous Commerce
                  </h3>
                  <p className="text-slate-400 text-sm max-w-2xl leading-relaxed">
                    London Cipher operates as an institutional cryptographic rail across law firms, financial institutions, 
                    aerospace engineers, and autonomous AI data agents.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
                    <div className="text-sky-400 font-bold text-sm">1. SECURE DATA VAULT</div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Privileged files whose access can be cryptographically controlled and economically authorized via Lightning.
                    </p>
                  </div>

                  <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
                    <div className="text-amber-400 font-bold text-sm">2. DATA MARKETPLACE</div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Monetize proprietary market data, scientific telemetry, and machine learning models with instant per-query settlement.
                    </p>
                  </div>

                  <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
                    <div className="text-emerald-400 font-bold text-sm">3. M2M MACHINE ECONOMY</div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Autonomous AI agents purchasing data in milliseconds with sub-penny routing fees and verifiable receipts.
                    </p>
                  </div>

                  <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
                    <div className="text-indigo-400 font-bold text-sm">4. INSTITUTIONAL RAILS</div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Programmable Central Bank Digital Currency (CBDC) adapters for digital GBP, EUR, and regulated liability networks.
                    </p>
                  </div>
                </div>
              </div>

              {/* Call to action for Deal Room Demo */}
              <div className="bg-gradient-to-r from-sky-950/60 via-slate-900 to-amber-950/40 border border-slate-700/80 rounded-2xl p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
                <div className="space-y-2">
                  <div className="inline-flex items-center gap-2 text-xs font-mono text-amber-300">
                    <Landmark className="w-4 h-4 text-amber-400" />
                    <span>FLAGSHIP M&amp;A DEMONSTRATION</span>
                  </div>
                  <h3 className="text-2xl font-bold text-white">
                    Experience the Project Phoenix Confidential Deal Room
                  </h3>
                  <p className="text-slate-300 text-sm max-w-xl">
                    Walk through an authentic £420M acquisition scenario. Test real local AES-256-GCM encryption, 
                    Lightning settlement verification, and atomic key release.
                  </p>
                </div>

                <button
                  onClick={() => setActiveTab('deal-room')}
                  className="px-6 py-3.5 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-bold rounded-xl text-sm transition-all flex items-center gap-2 shrink-0 shadow-lg shadow-amber-950/80"
                >
                  <span>Launch Deal Room</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'deal-room' && (
          <DealRoom
            objects={cipherObjects}
            onAddAuditEvent={handleAddAuditEvent}
          />
        )}

        {activeTab === 'encryption' && (
          <EncryptionStudio
            onAddCipherObject={handleAddCipherObject}
            onAddAuditEvent={handleAddAuditEvent}
            onOpenDealRoom={() => setActiveTab('deal-room')}
          />
        )}

        {activeTab === 'vault' && (
          <CipherObjectsVault
            objects={cipherObjects}
            onSelectDealRoomObject={handleSelectDealRoomObject}
            onOpenEncryption={() => setActiveTab('encryption')}
          />
        )}

        {activeTab === 'lightning' && <LightningControlRoom />}

        {activeTab === 'cbdc' && <CBDCControlRoom />}

        {activeTab === 'router' && <PaymentRouterView />}

        {activeTab === 'm2m' && (
          <M2MAgentSimulator onAddAuditEvent={handleAddAuditEvent} />
        )}

        {activeTab === 'keys' && <KeyManagementView />}

        {activeTab === 'audit' && <AuditLogView events={auditEvents} />}

        {activeTab === 'sdk' && <DeveloperSdkView />}
      </main>

      {/* Footer matching screenshot */}
      <footer className="bg-[#04070e] border-t border-slate-900 py-12 px-4 sm:px-6 lg:px-8 text-slate-400 text-xs font-sans">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            {/* Logo and Tagline */}
            <div className="flex items-center gap-3">
              <div className="relative w-8 h-8 flex items-center justify-center shrink-0">
                <svg viewBox="0 0 100 100" className="w-full h-full text-sky-400">
                  <polygon points="50,4 94,27 94,73 50,96 6,73 6,27" fill="none" stroke="currentColor" strokeWidth="6" strokeLinejoin="round"/>
                  <path d="M50 20 L76 34 L76 66 L50 80 L24 66 L24 34 Z" fill="none" stroke="#e2e8f0" strokeWidth="4" strokeLinejoin="round" opacity="0.8"/>
                  <path d="M38 38 L38 62 L58 62" fill="none" stroke="#38bdf8" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <div>
                <div className="font-bold text-sm tracking-widest text-white">
                  LONDON CIPHER
                </div>
                <div className="text-[11px] text-slate-500">
                  Secure Infrastructure for a Transparent Financial Future.
                </div>
              </div>
            </div>

            {/* Links */}
            <div className="flex flex-wrap items-center gap-6 text-slate-400 text-xs">
              <button onClick={() => setActiveTab('overview')} className="hover:text-white transition-colors">Home</button>
              <button onClick={() => setActiveTab('vault')} className="hover:text-white transition-colors">Product</button>
              <button onClick={() => setActiveTab('keys')} className="hover:text-white transition-colors">Security</button>
              <button onClick={() => setActiveTab('router')} className="hover:text-white transition-colors">Payments</button>
              <button onClick={() => setActiveTab('deal-room')} className="hover:text-white transition-colors">Use Cases</button>
              <button onClick={() => setActiveTab('sdk')} className="hover:text-white transition-colors">API &amp; SDKs</button>
            </div>

            {/* Social Icons */}
            <div className="flex items-center gap-4 text-slate-400">
              <span className="p-1.5 rounded hover:text-white cursor-pointer"><Linkedin className="w-4 h-4" /></span>
              <span className="p-1.5 rounded hover:text-white cursor-pointer"><Twitter className="w-4 h-4" /></span>
              <span className="p-1.5 rounded hover:text-white cursor-pointer"><Send className="w-4 h-4" /></span>
            </div>
          </div>

          <div className="border-t border-slate-900 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-[11px]">
            <div>
              &copy; 2026 London Cipher Limited. Registered in England &amp; Wales. 1 Canada Square, Canary Wharf &amp; Mayfair, London.
            </div>
            <div className="flex items-center gap-4 font-mono">
              <span>LCP/1.2 PROTOCOL</span>
              <span>&bull;</span>
              <span>AES-256-GCM</span>
              <span>&bull;</span>
              <span>FIPS 140-3 LEVEL 3</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
