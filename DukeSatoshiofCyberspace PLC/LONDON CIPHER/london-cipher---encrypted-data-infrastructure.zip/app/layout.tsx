import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'LONDON CIPHER — Encrypted Data Infrastructure for the Machine Economy',
  description: 'Cryptographically secure file encryption and controlled data transfer platform combining conventional modern cryptography with Lightning Network settlement and CBDC payment rails.',
  openGraph: {
    title: 'LONDON CIPHER — Encrypted Data Infrastructure',
    description: 'Cryptographically secure file encryption and controlled data transfer platform combining conventional modern cryptography with Lightning Network settlement and CBDC payment rails.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'LONDON CIPHER — Encrypted Data Infrastructure',
    description: 'Cryptographically secure file encryption and controlled data transfer platform combining conventional modern cryptography with Lightning Network settlement and CBDC payment rails.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
