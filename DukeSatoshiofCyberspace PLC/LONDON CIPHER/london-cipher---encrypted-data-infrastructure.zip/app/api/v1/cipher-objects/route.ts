import { NextRequest, NextResponse } from 'next/server';
import { INITIAL_DEAL_ROOM_OBJECTS } from '@/lib/initial-data';
import { CipherObject } from '@/lib/types';

// In-memory store for API demonstration
const cipherStore: CipherObject[] = [...INITIAL_DEAL_ROOM_OBJECTS];

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const category = searchParams.get('category');

  let results = cipherStore;
  if (category) {
    results = results.filter(o => o.category.toLowerCase() === category.toLowerCase());
  }

  return NextResponse.json({
    status: 'success',
    count: results.length,
    data: results,
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const newObject: CipherObject = {
      id: `CO-LON-${Date.now().toString(36).toUpperCase()}`,
      title: body.title || 'Untitled Cipher Object',
      filename: body.filename || 'payload.bin.enc',
      originalSize: body.originalSize || 1024,
      mimeType: body.mimeType || 'application/octet-stream',
      algorithm: body.algorithm || 'AES-256-GCM',
      encryptedFileHash: body.encryptedFileHash || 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      originalMetadataHash: body.originalMetadataHash || '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef',
      integrityCommitment: `MKR-ROOT-${Math.random().toString(36).slice(2, 12)}`,
      keyIdentifier: `KEY-DEK-${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
      wrappedKeyPayload: body.wrappedKeyPayload || 'wrapped_key_payload',
      iv: body.iv || '000000000000000000000000',
      authTag: body.authTag || '00000000000000000000000000000000',
      createdAt: new Date().toISOString(),
      owner: body.owner || 'API Anonymous Client',
      status: 'LOCKED',
      category: body.category || 'FINANCIAL',
      accessPolicy: body.accessPolicy || {
        policyId: `POL-${Date.now().toString(36)}`,
        accessModel: 'ONE_TIME_PURCHASE',
        priceGbp: 10.00,
        priceSats: 15400,
        validitySeconds: 86400,
        allowedRails: ['LIGHTNING', 'CBDC_GBP'],
        requireKycLevel: 'BASIC',
        maxDownloads: 5,
        revocationFlag: false,
        m2mCompatible: true,
      },
    };

    cipherStore.unshift(newObject);

    return NextResponse.json({
      status: 'created',
      message: 'CipherObject registered with hash commitment. Plaintext never touched server.',
      cipherObject: newObject,
    }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Invalid payload' }, { status: 400 });
  }
}
