import { NextRequest, NextResponse } from 'next/server';
import { CipherPaymentRouter } from '@/lib/payment-router';

export async function POST(req: NextRequest) {
  try {
    const { priceGbp } = await req.json();
    const amount = Number(priceGbp) || 25.00;
    const quotes = CipherPaymentRouter.quoteAll(amount);
    const recommended = CipherPaymentRouter.getRecommendedRail(amount);

    return NextResponse.json({
      priceGbp: amount,
      recommendedRail: recommended,
      quotes,
    });
  } catch (err: any) {
    return NextResponse.json({ error: 'Invalid quote request' }, { status: 400 });
  }
}
