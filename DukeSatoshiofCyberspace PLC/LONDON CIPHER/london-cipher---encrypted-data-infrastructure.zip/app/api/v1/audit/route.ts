import { NextResponse } from 'next/server';
import { INITIAL_AUDIT_EVENTS } from '@/lib/initial-data';

export async function GET() {
  return NextResponse.json({
    status: 'success',
    chainValidation: 'VERIFIED_MERKLE_ROOT',
    count: INITIAL_AUDIT_EVENTS.length,
    events: INITIAL_AUDIT_EVENTS,
  });
}
