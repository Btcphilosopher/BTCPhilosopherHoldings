package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.crypto.CryptoEngine
import com.example.crypto.KeyManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.nio.charset.StandardCharsets

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun testAppNameString() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("London Cipher", appName)
    }

    @Test
    fun testAesGcmEncryptionDecryption() {
        val key = CryptoEngine.generateRandomKey(256)
        val plaintext = "CONFIDENTIAL_LONDON_CIPHER_PAYLOAD_TEST_2026".toByteArray(StandardCharsets.UTF_8)
        val (ciphertextWithTag, iv, tag) = CryptoEngine.encryptAesGcm(plaintext, key)

        val decrypted = CryptoEngine.decryptAesGcm(ciphertextWithTag, key, iv)
        assertEquals("CONFIDENTIAL_LONDON_CIPHER_PAYLOAD_TEST_2026", String(decrypted, StandardCharsets.UTF_8))
    }

    @Test
    fun testPreimageVerification() {
        val (preimage, paymentHash) = CryptoEngine.generatePreimage()
        val isValid = CryptoEngine.verifySettlementPreimage(preimage, paymentHash)
        assertTrue("Preimage must verify against payment hash", isValid)
    }

    @Test
    fun testKeyWrappingAndUnwrapping() {
        val keyManager = KeyManager()
        val (dekId, rawDek) = keyManager.createDataEncryptionKey()
        val wrappedHex = keyManager.wrapDataKey(dekId)
        val unwrappedBytes = keyManager.unwrapDataKey(wrappedHex, dekId)

        assertEquals(CryptoEngine.toHex(rawDek), CryptoEngine.toHex(unwrappedBytes))
    }
}
