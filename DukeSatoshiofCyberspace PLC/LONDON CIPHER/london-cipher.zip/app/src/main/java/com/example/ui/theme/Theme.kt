package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = LondonCyan,
    onPrimary = ObsidianBg,
    primaryContainer = CanaryBlueDark,
    onPrimaryContainer = PlatinumWhite,
    secondary = BritishEmerald,
    onSecondary = ObsidianBg,
    secondaryContainer = BritishEmeraldDark,
    onSecondaryContainer = PlatinumWhite,
    tertiary = InstitutionalAmber,
    onTertiary = ObsidianBg,
    background = ObsidianBg,
    onBackground = PlatinumWhite,
    surface = GraphiteSurface,
    onSurface = PlatinumWhite,
    surfaceVariant = GraphiteSurfaceVariant,
    onSurfaceVariant = MutedSilver,
    outline = DarkBorder,
    error = RestrainedCrimson,
    onError = PlatinumWhite
)

private val LightColorScheme = lightColorScheme(
    primary = CanaryBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF1E3A8A),
    secondary = BritishEmeraldDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD1FAE5),
    onSecondaryContainer = Color(0xFF064E3B),
    tertiary = InstitutionalAmberDark,
    onTertiary = Color.White,
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    error = RestrainedCrimsonDark,
    onError = Color.White
)

@Composable
fun LondonCipherTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep distinctive institutional branding
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else DarkColorScheme // Prefer deep cybersecurity dark mode for institutional strength

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
