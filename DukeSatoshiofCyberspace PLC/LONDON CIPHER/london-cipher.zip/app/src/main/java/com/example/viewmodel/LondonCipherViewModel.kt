package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.crypto.AccessConditionType
import com.example.crypto.CryptoEngine
import com.example.crypto.EncryptionAlgorithm
import com.example.crypto.ManagedKeyRecord
import com.example.crypto.PaymentRailType
import com.example.data.AccessOfferEntity
import com.example.data.AppDatabase
import com.example.data.AuditEventEntity
import com.example.data.CipherObjectEntity
import com.example.data.LondonCipherRepository
import com.example.data.M2MTelemetryEntity
import com.example.data.SampleDataSeeder
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ConsoleTab(val title: String, val shortLabel: String) {
    DEAL_ROOM("Confidential Deal Room", "Deal Room"),
    OBJECTS_ENCRYPTION("Cipher Objects & Studio", "Encrypt"),
    LIGHTNING_CONTROL("Lightning Control Room", "Lightning"),
    CBDC_RAILS("CBDC Sandbox Rails", "CBDC Rails"),
    M2M_ECONOMY("M2M Agent Economy", "M2M Market"),
    KEY_VAULT("Key Vault & HSM", "Key Vault"),
    AUDIT_RISK("Audit & Risk Analytics", "Audit & Risk"),
    API_SDKS("Developer API & SDKs", "API & SDKs")
}

data class RiskAnalytics(
    val totalProtectedAssetsValueGbp: Double = 4850000.0,
    val totalSettlementsVerified: Int = 1428,
    val avgLightningSettlementMs: Long = 32L,
    val avgCbdcSettlementMs: Long = 185L,
    val settlementReliabilityPercent: Double = 99.94,
    val encryptionThroughputMbSec: Double = 540.0,
    val activeHsmKeys: Int = 16,
    val zeroKnowledgeCompliance: String = "100% Client-Side Authenticated"
)

class LondonCipherViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    val repository = LondonCipherRepository(database)

    val cipherObjects: StateFlow<List<CipherObjectEntity>> = repository.getAllCipherObjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditEvents: StateFlow<List<AuditEventEntity>> = repository.getAllAuditEvents()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val m2mTelemetry: StateFlow<List<M2MTelemetryEntity>> = repository.getRecentTelemetry()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedTab = MutableStateFlow(ConsoleTab.DEAL_ROOM)
    val selectedTab: StateFlow<ConsoleTab> = _selectedTab.asStateFlow()

    private val _selectedObject = MutableStateFlow<CipherObjectEntity?>(null)
    val selectedObject: StateFlow<CipherObjectEntity?> = _selectedObject.asStateFlow()

    private val _selectedOffers = MutableStateFlow<List<AccessOfferEntity>>(emptyList())
    val selectedOffers: StateFlow<List<AccessOfferEntity>> = _selectedOffers.asStateFlow()

    private val _managedKeys = MutableStateFlow<List<ManagedKeyRecord>>(emptyList())
    val managedKeys: StateFlow<List<ManagedKeyRecord>> = _managedKeys.asStateFlow()

    private val _riskAnalytics = MutableStateFlow(RiskAnalytics())
    val riskAnalytics: StateFlow<RiskAnalytics> = _riskAnalytics.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    init {
        viewModelScope.launch {
            SampleDataSeeder.seedInitialDataIfEmpty(database, repository.keyManager)
            refreshManagedKeys()
        }
    }

    fun selectTab(tab: ConsoleTab) {
        _selectedTab.value = tab
    }

    fun selectCipherObject(obj: CipherObjectEntity) {
        _selectedObject.value = obj
        viewModelScope.launch {
            repository.getOffersForObject(obj.id).collect { offers ->
                _selectedOffers.value = offers
            }
        }
    }

    fun clearSelectedObject() {
        _selectedObject.value = null
        _selectedOffers.value = emptyList()
    }

    fun refreshManagedKeys() {
        _managedKeys.value = repository.keyManager.getAllManagedKeys()
    }

    fun encryptAndPublishFile(
        title: String,
        desc: String,
        filename: String,
        content: String,
        algorithm: EncryptionAlgorithm,
        priceAmount: Double,
        conditionType: AccessConditionType,
        primaryRail: PaymentRailType
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val objectId = repository.encryptAndStoreFile(
                    title = title,
                    description = desc,
                    filename = filename,
                    content = content,
                    algorithm = algorithm,
                    priceAmount = priceAmount,
                    conditionType = conditionType,
                    primaryRail = primaryRail
                )
                refreshManagedKeys()
                _statusMessage.value = "Object $objectId successfully encrypted and published with payment access gate!"
            } catch (e: Exception) {
                _statusMessage.value = "Encryption failed: ${e.localizedMessage}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun settleAndRelease(offerId: String, objectId: String) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val success = repository.executeSettlementAndRelease(offerId)
                if (success) {
                    _statusMessage.value = "Settlement confirmed! Cryptographic access capability unsealed & released."
                    // Refresh selected object offers
                    repository.getOffersForObject(objectId).collect {
                        _selectedOffers.value = it
                    }
                } else {
                    _statusMessage.value = "Settlement verification failed: Invalid preimage."
                }
            } catch (e: Exception) {
                _statusMessage.value = "Error settling: ${e.localizedMessage}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun decryptLocally(objectId: String) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val decrypted = repository.decryptObjectLocally(objectId)
                if (decrypted != null) {
                    _statusMessage.value = "Client-side decryption successful! Integrity SHA-256 verified."
                    val updated = database.cipherDao().getCipherObjectById(objectId)
                    _selectedObject.value = updated
                } else {
                    _statusMessage.value = "Decryption failed: Key capability locked or checksum mismatch."
                }
            } catch (e: Exception) {
                _statusMessage.value = "Decryption error: ${e.localizedMessage}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun rotateKey(keyId: String) {
        viewModelScope.launch {
            try {
                repository.keyManager.rotateKey(keyId)
                refreshManagedKeys()
                _statusMessage.value = "Key $keyId rotated to new version in HSM."
            } catch (e: Exception) {
                _statusMessage.value = "Failed to rotate key: ${e.localizedMessage}"
            }
        }
    }

    fun revokeAccess(objectId: String, reason: String) {
        viewModelScope.launch {
            try {
                repository.revokeObjectAccess(objectId, reason)
                _statusMessage.value = "Access revoked for object $objectId."
            } catch (e: Exception) {
                _statusMessage.value = "Failed to revoke: ${e.localizedMessage}"
            }
        }
    }

    fun triggerM2MSimulation(
        datasetName: String,
        agentName: String,
        agentDid: String,
        priceAmount: Double,
        rail: PaymentRailType
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val token = repository.simulateM2MAgentPurchase(datasetName, agentName, agentDid, priceAmount, rail)
                _statusMessage.value = "Agent $agentName completed autonomous settlement! Token: $token"
            } catch (e: Exception) {
                _statusMessage.value = "M2M purchase failed: ${e.localizedMessage}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun verifyAuditLedgerIntegrity(): Boolean {
        val events = auditEvents.value
        if (events.isEmpty()) return true
        var prevHash = "0000000000000000000000000000000000000000000000000000000000000000"
        for (event in events.reversed()) {
            val expectedHash = CryptoEngine.computeAuditHash(event.eventId, event.timestamp, event.eventType, event.objectId, prevHash)
            if (!expectedHash.equals(event.currentHash, ignoreCase = true)) {
                _statusMessage.value = "Audit ledger tamper detected at event ${event.eventId}!"
                return false
            }
            prevHash = event.currentHash
        }
        _statusMessage.value = "All ${events.size} audit ledger blocks cryptographically validated & intact!"
        return true
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }
}
