package com.example.data

import com.example.crypto.AccessConditionType
import com.example.crypto.CryptoEngine
import com.example.crypto.EncryptionAlgorithm
import com.example.crypto.KeyManager
import com.example.crypto.PaymentRailType
import com.example.crypto.SettlementState
import com.example.payments.PaymentRequest
import com.example.payments.UniversalPaymentRouter
import kotlinx.coroutines.flow.Flow
import java.nio.charset.StandardCharsets
import java.util.UUID

class LondonCipherRepository(
    private val database: AppDatabase,
    val keyManager: KeyManager = KeyManager(),
    val paymentRouter: UniversalPaymentRouter = UniversalPaymentRouter()
) {

    fun getAllCipherObjects(): Flow<List<CipherObjectEntity>> = database.cipherDao().getAllCipherObjects()

    fun getOffersForObject(objectId: String): Flow<List<AccessOfferEntity>> = database.offerDao().getOffersForObject(objectId)

    fun getAllAuditEvents(): Flow<List<AuditEventEntity>> = database.auditDao().getAllAuditEvents()

    fun getRecentTelemetry(): Flow<List<M2MTelemetryEntity>> = database.telemetryDao().getRecentTelemetry()

    private suspend fun appendAuditEvent(eventType: String, objectId: String, actor: String, details: String) {
        val latest = database.auditDao().getLatestAuditEvent()
        val prevHash = latest?.currentHash ?: "0000000000000000000000000000000000000000000000000000000000000000"
        val eventId = "evt_${UUID.randomUUID().toString().take(10)}"
        val timestamp = System.currentTimeMillis()
        val currentHash = CryptoEngine.computeAuditHash(eventId, timestamp, eventType, objectId, prevHash)

        database.auditDao().insertAuditEvent(
            AuditEventEntity(
                eventId = eventId,
                timestamp = timestamp,
                eventType = eventType,
                objectId = objectId,
                actor = actor,
                details = details,
                prevHash = prevHash,
                currentHash = currentHash
            )
        )
    }

    suspend fun encryptAndStoreFile(
        title: String,
        description: String,
        filename: String,
        content: String,
        algorithm: EncryptionAlgorithm,
        priceAmount: Double,
        conditionType: AccessConditionType,
        primaryRail: PaymentRailType
    ): String {
        val (keyId, rawKeyBytes) = keyManager.createDataEncryptionKey()
        val plaintextBytes = content.toByteArray(StandardCharsets.UTF_8)
        val plaintextHash = CryptoEngine.sha256Hex(plaintextBytes)

        val (ciphertextWithTag, ivBytes, tagBytes) = if (algorithm == EncryptionAlgorithm.CHACHA20_POLY1305) {
            CryptoEngine.encryptChaCha20(plaintextBytes, rawKeyBytes)
        } else {
            CryptoEngine.encryptAesGcm(plaintextBytes, rawKeyBytes)
        }

        val cipherHex = CryptoEngine.toHex(ciphertextWithTag)
        val cipherHash = CryptoEngine.sha256Hex(ciphertextWithTag)
        val ivHex = CryptoEngine.toHex(ivBytes)
        val tagHex = CryptoEngine.toHex(tagBytes)
        val objectId = "obj_lc_${UUID.randomUUID().toString().take(12)}"
        val integrityCommitment = CryptoEngine.computeIntegrityCommitment(cipherHash, plaintextHash, conditionType.name, keyId)

        val entity = CipherObjectEntity(
            id = objectId,
            title = title,
            description = description,
            originalFilename = filename,
            originalSizeBytes = plaintextBytes.size.toLong(),
            mimeType = if (filename.endsWith(".pdf", true)) "application/pdf" else "application/octet-stream",
            plaintextSha256 = plaintextHash,
            ciphertextHex = cipherHex,
            ciphertextSha256 = cipherHash,
            ivHex = ivHex,
            tagHex = tagHex,
            algorithm = algorithm.identifier,
            keyId = keyId,
            ownerIdentity = "did:lc:org:london-capital-partners",
            createdAt = System.currentTimeMillis(),
            conditionType = conditionType.name,
            priceAmount = priceAmount,
            currency = "GBP",
            allowedRailsCsv = "LIGHTNING,CBDC_GBP_SANDBOX,STABLECOIN_USDC",
            validityDurationSeconds = 86400L,
            integrityCommitment = integrityCommitment,
            isDecryptedLocally = false,
            localDecryptedText = null
        )
        database.cipherDao().insertCipherObject(entity)

        appendAuditEvent(
            eventType = "FILE_ENCRYPTED",
            objectId = objectId,
            actor = "CLIENT_LOCAL_ENGINE",
            details = "Encrypted $filename (${plaintextBytes.size} bytes) via ${algorithm.identifier}. Plaintext SHA-256: ${plaintextHash.take(16)}..."
        )

        // Create Payment Offer on Primary Rail
        val railAdapter = paymentRouter.getRail(primaryRail)
        val payReq: PaymentRequest = railAdapter.createPayment(objectId, priceAmount, "GBP", title)

        val offerEntity = AccessOfferEntity(
            offerId = "off_${UUID.randomUUID().toString().take(10)}",
            objectId = objectId,
            requestId = "req_${UUID.randomUUID().toString().take(8)}",
            priceAmount = priceAmount,
            currency = "GBP",
            rail = primaryRail.name,
            invoiceReference = payReq.invoiceString,
            paymentHashHex = payReq.paymentHashHex,
            commitmentHash = CryptoEngine.sha256Hex("${payReq.paymentHashHex}:$priceAmount"),
            expiresAt = payReq.expiresAt,
            settlementState = SettlementState.WAITING_PAYMENT.name,
            preimageHex = payReq.secretPreimageHex
        )
        database.offerDao().insertOffer(offerEntity)

        appendAuditEvent(
            eventType = "ACCESS_OFFER_PUBLISHED",
            objectId = objectId,
            actor = "SETTLEMENT_GATING_NODE",
            details = "Access conditioned on £${"%.2f".format(priceAmount)} settlement via ${primaryRail.displayName}. Payment Hash: ${payReq.paymentHashHex.take(16)}..."
        )

        return objectId
    }

    suspend fun executeSettlementAndRelease(offerId: String): Boolean {
        val offer = database.offerDao().getOfferById(offerId) ?: return false
        val preimage = offer.preimageHex ?: return false

        // Verify cryptographic preimage
        val verified = CryptoEngine.verifySettlementPreimage(preimage, offer.paymentHashHex)
        if (!verified) return false

        // Issue capability
        val obj = database.cipherDao().getCipherObjectById(offer.objectId) ?: return false
        val capability = keyManager.issueAccessCapability(obj.id, obj.keyId, 86400L)

        // Update offer state
        val updatedOffer = offer.copy(
            settlementState = SettlementState.SETTLED.name,
            settledAt = System.currentTimeMillis()
        )
        database.offerDao().updateOffer(updatedOffer)

        // Record settlement proof
        val proofEntity = SettlementProofEntity(
            proofId = "proof_${UUID.randomUUID().toString().take(10)}",
            offerId = offerId,
            objectId = offer.objectId,
            paymentHashHex = offer.paymentHashHex,
            preimageHex = preimage,
            rail = offer.rail,
            settlementTimestamp = System.currentTimeMillis(),
            routingFeePence = 0.02,
            blockHeightOrTxId = "ln_settled_htlc_${preimage.take(12)}",
            cryptographicSignature = capability.signatureHex,
            isVerified = true
        )
        database.settlementDao().insertSettlementProof(proofEntity)

        appendAuditEvent(
            eventType = "PAYMENT_SETTLED_AND_VERIFIED",
            objectId = offer.objectId,
            actor = "PAYMENT_VERIFIER",
            details = "Cryptographic preimage verified against payment hash. Settlement proof committed."
        )

        appendAuditEvent(
            eventType = "CAPABILITY_UNWRAPPED_AND_RELEASED",
            objectId = offer.objectId,
            actor = "KEY_VAULT_HSM",
            details = "Access capability token ${capability.capabilityToken.take(18)}... released to purchaser. Wrapped DEK provided."
        )

        return true
    }

    suspend fun decryptObjectLocally(objectId: String): String? {
        val obj = database.cipherDao().getCipherObjectById(objectId) ?: return null
        val ciphertextWithTag = CryptoEngine.fromHex(obj.ciphertextHex)
        val ivBytes = CryptoEngine.fromHex(obj.ivHex)

        // Retrieve raw key from in-memory key manager / enclave
        val keyRecord = keyManager.getKeyRecord(obj.keyId)
        val rawKeyBytes = keyRecord?.rawKeyBytes ?: return null

        val plaintextBytes = if (obj.algorithm.contains("ChaCha", ignoreCase = true)) {
            CryptoEngine.decryptChaCha20(ciphertextWithTag, rawKeyBytes, ivBytes)
        } else {
            CryptoEngine.decryptAesGcm(ciphertextWithTag, rawKeyBytes, ivBytes)
        }

        val decryptedString = String(plaintextBytes, StandardCharsets.UTF_8)
        val verifiedHash = CryptoEngine.sha256Hex(plaintextBytes)
        val isChecksumValid = verifiedHash.equals(obj.plaintextSha256, ignoreCase = true)

        if (!isChecksumValid) {
            appendAuditEvent(
                eventType = "DECRYPTION_INTEGRITY_FAILED",
                objectId = objectId,
                actor = "CLIENT_VERIFIER",
                details = "Plaintext checksum mismatch! Decryption aborted."
            )
            return null
        }

        val updated = obj.copy(
            isDecryptedLocally = true,
            localDecryptedText = decryptedString
        )
        database.cipherDao().updateCipherObject(updated)

        appendAuditEvent(
            eventType = "DECRYPTION_COMPLETED",
            objectId = objectId,
            actor = "CLIENT_LOCAL_ENGINE",
            details = "Decryption successful at client boundary. Integrity verified (SHA-256 match)."
        )

        return decryptedString
    }

    suspend fun simulateM2MAgentPurchase(
        datasetName: String,
        agentName: String,
        agentDid: String,
        priceAmount: Double,
        rail: PaymentRailType
    ): String {
        val (preimage, paymentHash) = CryptoEngine.generatePreimage()
        val capToken = "cap_m2m_${UUID.randomUUID().toString().take(14)}"
        val latency = (20..65).random().toLong()

        val telemetry = M2MTelemetryEntity(
            id = UUID.randomUUID().toString(),
            agentName = agentName,
            agentDid = agentDid,
            datasetRequested = datasetName,
            costAmount = priceAmount,
            currency = "GBP",
            rail = rail.name,
            latencyMs = latency,
            timestamp = System.currentTimeMillis(),
            status = "SETTLED_AND_STREAMING",
            capabilityToken = capToken
        )
        database.telemetryDao().insertTelemetry(telemetry)

        appendAuditEvent(
            eventType = "M2M_AGENT_AUTONOMOUS_PURCHASE",
            objectId = "feed_m2m_stream",
            actor = agentName,
            details = "Autonomous agent purchased '$datasetName' for £${"%.2f".format(priceAmount)} via ${rail.displayName} in ${latency}ms."
        )

        return capToken
    }

    suspend fun revokeObjectAccess(objectId: String, reason: String) {
        val obj = database.cipherDao().getCipherObjectById(objectId) ?: return
        keyManager.revokeKey(obj.keyId, reason)

        appendAuditEvent(
            eventType = "ACCESS_REVOKED",
            objectId = objectId,
            actor = "SECURITY_ADMIN",
            details = "Access capability and wrapping key revoked. Reason: $reason"
        )
    }
}
