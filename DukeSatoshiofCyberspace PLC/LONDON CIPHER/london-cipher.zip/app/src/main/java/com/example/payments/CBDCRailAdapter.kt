package com.example.payments

import com.example.crypto.CryptoEngine
import com.example.crypto.PaymentRailType
import kotlinx.coroutines.delay
import java.util.UUID

/**
 * Provider-Neutral Central Bank Digital Currency (CBDC) Sandbox Adapter
 * Synthetic environment for programmable digital central bank money rails:
 * - Digital GBP (Bank of England Synthetic Programmable RTGS)
 * - Digital EUR (ECB Eurosystem Distributed Ledger Sandbox)
 * - Digital USD (FedNow / Programmable Digital Dollar Sandbox)
 *
 * NOTE: Clearly labeled as SYNTHETIC EXPERIMENTAL SANDBOX environment.
 */
data class CbdcSandboxEnvironment(
    val jurisdiction: String,
    val currencyCode: String,
    val centralBankAuthority: String,
    val settlementProtocol: String,
    val isSyntheticSandbox: Boolean = true,
    val multiSigQuorum: String = "2-of-3 Bank Node Consensus",
    val tokenStandard: String = "ISO-20022 / Digital Sterling Spec v1.4",
    val avgLatencyMs: Long = 180L
)

class CBDCRailAdapter(
    val environment: CbdcSandboxEnvironment
) : PaymentRail {

    override val railType: PaymentRailType = when (environment.currencyCode) {
        "EUR" -> PaymentRailType.CBDC_EUR_SANDBOX
        "USD" -> PaymentRailType.CBDC_USD_SANDBOX
        else -> PaymentRailType.CBDC_GBP_SANDBOX
    }

    override val railName: String = "Digital ${environment.currencyCode} (${environment.jurisdiction} Sandbox)"
    override val isSandbox: Boolean = true

    override suspend fun quote(amount: Double, currency: String): PaymentQuote {
        val fee = 0.005 // Fractional institutional fee
        return PaymentQuote(
            railType = railType,
            currency = environment.currencyCode,
            baseAmount = amount,
            networkFeeAmount = fee,
            totalAmount = amount + fee,
            estimatedSettlementMs = environment.avgLatencyMs,
            routingHops = 1,
            expirySeconds = 7200L,
            requiresBiometricOrAuth = true,
            railStatus = "SYNTHETIC SANDBOX — ${environment.centralBankAuthority}"
        )
    }

    override suspend fun createPayment(
        offerId: String,
        amount: Double,
        currency: String,
        description: String
    ): PaymentRequest {
        val (preimageHex, paymentHashHex) = CryptoEngine.generatePreimage()
        val paymentId = "cbdc_${environment.currencyCode.lowercase()}_${UUID.randomUUID().toString().take(10)}"
        val iso20022Ref = "pacs.008.001.08/${environment.currencyCode}/$paymentHashHex"

        return PaymentRequest(
            paymentId = paymentId,
            offerId = offerId,
            railType = railType,
            amount = amount,
            currency = environment.currencyCode,
            invoiceString = iso20022Ref,
            paymentHashHex = paymentHashHex,
            secretPreimageHex = preimageHex,
            createdAt = System.currentTimeMillis(),
            expiresAt = System.currentTimeMillis() + (7200 * 1000L)
        )
    }

    override suspend fun verifyPayment(
        paymentHashHex: String,
        preimageHex: String?
    ): PaymentVerificationResult {
        if (preimageHex == null) {
            return PaymentVerificationResult(
                isSettled = false,
                paymentHashHex = paymentHashHex,
                preimageHex = "",
                confirmedAt = 0L,
                txOrBlockRef = "",
                railType = railType,
                statusMessage = "Awaiting Central Bank consensus block seal"
            )
        }

        val isValid = CryptoEngine.verifySettlementPreimage(preimageHex, paymentHashHex)
        return PaymentVerificationResult(
            isSettled = isValid,
            paymentHashHex = paymentHashHex,
            preimageHex = preimageHex,
            confirmedAt = System.currentTimeMillis(),
            txOrBlockRef = "cbdc_rtgs_block_${UUID.randomUUID().toString().take(12)}",
            railType = railType,
            statusMessage = "Central Bank Programmable RTGS Settlement Confirmed"
        )
    }

    override suspend fun simulateInstantSettlement(paymentRequest: PaymentRequest): PaymentVerificationResult {
        delay(250)
        return PaymentVerificationResult(
            isSettled = true,
            paymentHashHex = paymentRequest.paymentHashHex,
            preimageHex = paymentRequest.secretPreimageHex,
            confirmedAt = System.currentTimeMillis(),
            txOrBlockRef = "cbdc_node_quorum_ack_${paymentRequest.paymentHashHex.take(14)}",
            railType = railType,
            statusMessage = "Settled via ${environment.centralBankAuthority} Sandbox Protocol"
        )
    }
}
