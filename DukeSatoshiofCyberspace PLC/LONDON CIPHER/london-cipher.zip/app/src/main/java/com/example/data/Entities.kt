package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.crypto.AccessConditionType
import com.example.crypto.EncryptionAlgorithm
import com.example.crypto.PaymentRailType
import com.example.crypto.SettlementState

@Entity(tableName = "cipher_objects")
data class CipherObjectEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val originalFilename: String,
    val originalSizeBytes: Long,
    val mimeType: String,
    val plaintextSha256: String,
    val ciphertextHex: String,
    val ciphertextSha256: String,
    val ivHex: String,
    val tagHex: String,
    val algorithm: String, // "AES-256-GCM" or "ChaCha20-Poly1305"
    val keyId: String,
    val ownerIdentity: String,
    val createdAt: Long,
    val conditionType: String,
    val priceAmount: Double,
    val currency: String,
    val allowedRailsCsv: String,
    val validityDurationSeconds: Long,
    val integrityCommitment: String,
    val isDecryptedLocally: Boolean = false,
    val localDecryptedText: String? = null
)

@Entity(tableName = "access_offers")
data class AccessOfferEntity(
    @PrimaryKey val offerId: String,
    val objectId: String,
    val requestId: String,
    val priceAmount: Double,
    val currency: String,
    val rail: String,
    val invoiceReference: String,
    val paymentHashHex: String,
    val commitmentHash: String,
    val expiresAt: Long,
    val settlementState: String,
    val preimageHex: String? = null,
    val settledAt: Long? = null
)

@Entity(tableName = "settlement_proofs")
data class SettlementProofEntity(
    @PrimaryKey val proofId: String,
    val offerId: String,
    val objectId: String,
    val paymentHashHex: String,
    val preimageHex: String,
    val rail: String,
    val settlementTimestamp: Long,
    val routingFeePence: Double,
    val blockHeightOrTxId: String,
    val cryptographicSignature: String,
    val isVerified: Boolean
)

@Entity(tableName = "audit_events")
data class AuditEventEntity(
    @PrimaryKey val eventId: String,
    val timestamp: Long,
    val eventType: String,
    val objectId: String,
    val actor: String,
    val details: String,
    val prevHash: String,
    val currentHash: String
)

@Entity(tableName = "m2m_telemetry")
data class M2MTelemetryEntity(
    @PrimaryKey val id: String,
    val agentName: String,
    val agentDid: String,
    val datasetRequested: String,
    val costAmount: Double,
    val currency: String,
    val rail: String,
    val latencyMs: Long,
    val timestamp: Long,
    val status: String,
    val capabilityToken: String
)
