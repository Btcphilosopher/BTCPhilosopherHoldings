package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CurrencyPound
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.crypto.AccessConditionType
import com.example.crypto.EncryptionAlgorithm
import com.example.crypto.PaymentRailType
import com.example.crypto.SettlementState
import com.example.data.AccessOfferEntity
import com.example.data.CipherObjectEntity
import com.example.ui.components.BadgeVariant
import com.example.ui.components.CryptographicBadge
import com.example.ui.components.HexViewer
import com.example.ui.theme.BritishEmerald
import com.example.ui.theme.CanaryBlue
import com.example.ui.theme.CodeBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.GraphiteSurfaceElevated
import com.example.ui.theme.GraphiteSurfaceVariant
import com.example.ui.theme.InstitutionalAmber
import com.example.ui.theme.LondonCyan
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlatinumWhite
import com.example.ui.theme.RestrainedCrimson
import com.example.viewmodel.LondonCipherViewModel

@Composable
fun DealRoomAndObjectsScreen(
    viewModel: LondonCipherViewModel,
    modifier: Modifier = Modifier
) {
    val cipherObjects by viewModel.cipherObjects.collectAsState()
    val selectedObject by viewModel.selectedObject.collectAsState()
    val selectedOffers by viewModel.selectedOffers.collectAsState()
    val isBusy by viewModel.isBusy.collectAsState()

    var activeSubTab by remember { mutableIntStateOf(0) } // 0: Deal Room & Objects, 1: Encrypt New Asset

    if (selectedObject != null) {
        CipherObjectDetailView(
            obj = selectedObject!!,
            offers = selectedOffers,
            onBack = { viewModel.clearSelectedObject() },
            onSettle = { offerId -> viewModel.settleAndRelease(offerId, selectedObject!!.id) },
            onDecrypt = { viewModel.decryptLocally(selectedObject!!.id) },
            onRevoke = { viewModel.revokeAccess(selectedObject!!.id, "Administrator revocation") },
            isBusy = isBusy
        )
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(ObsidianBg)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            TabRow(
                selectedTabIndex = activeSubTab,
                containerColor = GraphiteSurface,
                contentColor = LondonCyan,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[activeSubTab]),
                        color = LondonCyan
                    )
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
            ) {
                Tab(
                    selected = activeSubTab == 0,
                    onClick = { activeSubTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Confidential Deal Room", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                )
                Tab(
                    selected = activeSubTab == 1,
                    onClick = { activeSubTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Encrypt & Publish", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                )
            }

            Spacer(Modifier.height(12.dp))

            if (activeSubTab == 0) {
                DealRoomListView(
                    objects = cipherObjects,
                    onSelect = { viewModel.selectCipherObject(it) }
                )
            } else {
                EncryptNewAssetForm(
                    onPublish = { title, desc, filename, text, algo, price, condition, rail ->
                        viewModel.encryptAndPublishFile(title, desc, filename, text, algo, price, condition, rail)
                        activeSubTab = 0
                    },
                    isBusy = isBusy
                )
            }
        }
    }
}

@Composable
fun DealRoomListView(
    objects: List<CipherObjectEntity>,
    onSelect: (CipherObjectEntity) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            // Deal Room Header Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(GraphiteSurface)
                    .border(1.dp, LondonCyan.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(BritishEmerald)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "LONDON CONFIDENTIAL DEAL ROOM // M&A ACQUISITION",
                                color = LondonCyan,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                        CryptographicBadge("ZERO-KNOWLEDGE REST", BadgeVariant.CYAN)
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Gated Access Package for London Capital Partners Acquisition",
                        style = MaterialTheme.typography.titleMedium,
                        color = PlatinumWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Files are encrypted at the client boundary using authenticated AES-256-GCM / ChaCha20-Poly1305. Access capabilities are unlocked strictly upon verified Lightning HTLC or CBDC RTGS settlement.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedSilver
                    )
                }
            }
        }

        items(objects, key = { it.id }) { obj ->
            CipherObjectCard(obj = obj, onClick = { onSelect(obj) })
        }
    }
}

@Composable
fun CipherObjectCard(
    obj: CipherObjectEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("cipher_card_${obj.id}"),
        colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(ObsidianBg)
                            .border(1.dp, DarkBorder, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (obj.isDecryptedLocally) Icons.Default.LockOpen else Icons.Default.Lock,
                            contentDescription = null,
                            tint = if (obj.isDecryptedLocally) BritishEmerald else LondonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(Modifier.width(12.dp))

                    Column {
                        Text(
                            text = obj.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = PlatinumWhite,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = obj.originalFilename,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = MutedSilver
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "£${"%.2f".format(obj.priceAmount)}",
                        style = MaterialTheme.typography.titleLarge,
                        color = InstitutionalAmber,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = obj.conditionType.replace("_", " "),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = MutedSilver
                    )
                }
            }

            Spacer(Modifier.height(10.dp))
            Text(
                text = obj.description,
                style = MaterialTheme.typography.bodyMedium,
                color = PlatinumWhite.copy(alpha = 0.85f),
                maxLines = 2
            )

            Spacer(Modifier.height(12.dp))
            Divider(color = DarkBorder.copy(alpha = 0.6f))
            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CryptographicBadge(obj.algorithm, BadgeVariant.CYAN)
                    if (obj.isDecryptedLocally) {
                        CryptographicBadge("DECRYPTED LOCALLY", BadgeVariant.EMERALD, hasDot = true)
                    } else {
                        CryptographicBadge("LOCKED // PAYMENT GATED", BadgeVariant.AMBER, hasDot = true)
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "INSPECT OBJECT",
                        color = LondonCyan,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.Visibility,
                        contentDescription = null,
                        tint = LondonCyan,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CipherObjectDetailView(
    obj: CipherObjectEntity,
    offers: List<AccessOfferEntity>,
    onBack: () -> Unit,
    onSettle: (String) -> Unit,
    onDecrypt: () -> Unit,
    onRevoke: () -> Unit,
    isBusy: Boolean
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(GraphiteSurface)
                        .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PlatinumWhite)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CryptographicBadge("OBJECT ID: ${obj.id.take(12)}...", BadgeVariant.MUTED)
                    if (obj.isDecryptedLocally) {
                        CryptographicBadge("UNWRAPPED & DECRYPTED", BadgeVariant.EMERALD, hasDot = true)
                    } else {
                        CryptographicBadge("CAPABILITY LOCKED", BadgeVariant.AMBER, hasDot = true)
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = obj.title,
                        style = MaterialTheme.typography.titleLarge,
                        color = PlatinumWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = obj.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedSilver
                    )

                    Spacer(Modifier.height(14.dp))
                    Divider(color = DarkBorder)
                    Spacer(Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("ORIGINAL ASSET", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MutedSilver)
                            Text(obj.originalFilename, color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Column {
                            Text("PAYLOAD SIZE", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MutedSilver)
                            Text("${obj.originalSizeBytes} bytes", color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Column {
                            Text("ENCRYPTION LAYER", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MutedSilver)
                            Text(obj.algorithm, color = LondonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "CRYPTOGRAPHIC INTEGRITY & COMMITMENT",
                color = LondonCyan,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            HexViewer("Ciphertext Hash (SHA-256)", obj.ciphertextSha256)
        }

        item {
            HexViewer("Ciphertext Payload (Authenticated Hex)", obj.ciphertextHex, maxLines = 4)
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.weight(1f)) {
                    HexViewer("Initialization Vector (96-bit)", obj.ivHex)
                }
                if (obj.tagHex.isNotEmpty()) {
                    Box(modifier = Modifier.weight(1f)) {
                        HexViewer("Authentication Tag (128-bit)", obj.tagHex)
                    }
                }
            }
        }

        item {
            HexViewer("Integrity Commitment Hash", obj.integrityCommitment)
        }

        item {
            Text(
                text = "LAYER 2 // SETTLEMENT ACCESS OFFERS",
                color = InstitutionalAmber,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        items(offers, key = { it.offerId }) { offer ->
            val isSettled = offer.settlementState == SettlementState.SETTLED.name
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isSettled) BritishEmerald.copy(alpha = 0.08f) else GraphiteSurface
                ),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSettled) BritishEmerald.copy(alpha = 0.5f) else DarkBorder
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FlashOn,
                                contentDescription = null,
                                tint = if (isSettled) BritishEmerald else InstitutionalAmber,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = "RAIL: ${offer.rail}",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = PlatinumWhite
                            )
                        }

                        Text(
                            text = "£${"%.2f".format(offer.priceAmount)} ${offer.currency}",
                            style = MaterialTheme.typography.titleMedium,
                            color = InstitutionalAmber,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(Modifier.height(8.dp))
                    HexViewer("Payment Hash (HTLC Commit)", offer.paymentHashHex)

                    Spacer(Modifier.height(8.dp))
                    HexViewer("Invoice Reference", offer.invoiceReference)

                    if (offer.preimageHex != null) {
                        Spacer(Modifier.height(8.dp))
                        HexViewer("Preimage (Proof of Payment)", offer.preimageHex)
                    }

                    Spacer(Modifier.height(12.dp))

                    if (!isSettled) {
                        Button(
                            onClick = { onSettle(offer.offerId) },
                            enabled = !isBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = InstitutionalAmber),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("settle_button_${offer.offerId}")
                        ) {
                            Icon(Icons.Default.FlashOn, contentDescription = null, tint = ObsidianBg)
                            Spacer(Modifier.width(8.dp))
                            Text("AUTHORISE & SETTLE (£${"%.2f".format(offer.priceAmount)})", color = ObsidianBg, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(BritishEmerald.copy(alpha = 0.15f))
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BritishEmerald, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "SETTLEMENT VERIFIED & KEY CAPABILITY RELEASED",
                                color = BritishEmerald,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "CLIENT-SIDE ZERO-KNOWLEDGE DECRYPTION",
                color = LondonCyan,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val hasSettled = offers.any { it.settlementState == SettlementState.SETTLED.name }

                    if (!obj.isDecryptedLocally) {
                        Text(
                            text = if (hasSettled)
                                "Access capability is released! You can now perform client-side decryption in memory."
                            else
                                "Decryption is locked. Settle one of the access offers above to unwrap the cryptographic capability.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (hasSettled) PlatinumWhite else MutedSilver
                        )

                        Spacer(Modifier.height(12.dp))

                        Button(
                            onClick = onDecrypt,
                            enabled = hasSettled && !isBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = BritishEmerald),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("decrypt_locally_button")
                        ) {
                            Icon(Icons.Default.LockOpen, contentDescription = null, tint = ObsidianBg)
                            Spacer(Modifier.width(8.dp))
                            Text("DECRYPT PLAINTEXT LOCALLY", color = ObsidianBg, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BritishEmerald)
                                Spacer(Modifier.width(8.dp))
                                Text("DECRYPTED PLAINTEXT (AUTHENTICATED)", color = BritishEmerald, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            IconButton(onClick = onDecrypt) {
                                Icon(Icons.Default.Refresh, contentDescription = "Re-verify", tint = LondonCyan)
                            }
                        }

                        Spacer(Modifier.height(8.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(CodeBg)
                                .border(1.dp, BritishEmerald.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = obj.localDecryptedText ?: "Decrypted data empty",
                                color = PlatinumWhite,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.5.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    OutlinedButton(
                        onClick = onRevoke,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = RestrainedCrimson),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RestrainedCrimson.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("REVOKE ACCESS CAPABILITY", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EncryptNewAssetForm(
    onPublish: (String, String, String, String, EncryptionAlgorithm, Double, AccessConditionType, PaymentRailType) -> Unit,
    isBusy: Boolean
) {
    var title by remember { mutableStateOf("") }
    var filename by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var plaintext by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("50.00") }
    var selectedAlgorithm by remember { mutableStateOf(EncryptionAlgorithm.AES_256_GCM) }
    var selectedCondition by remember { mutableStateOf(AccessConditionType.ONE_TIME_PURCHASE) }
    var selectedRail by remember { mutableStateOf(PaymentRailType.LIGHTNING) }

    var algoDropdownExpanded by remember { mutableStateOf(false) }
    var conditionDropdownExpanded by remember { mutableStateOf(false) }
    var railDropdownExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 16.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(GraphiteSurface)
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Text(
                        text = "LAYER 1 & 2 ENCRYPTION & ACCESS STUDIO",
                        color = LondonCyan,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Encrypt local files with authenticated AEAD cryptography and bind a verifiable payment access condition.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedSilver
                    )
                }
            }
        }

        item {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Asset Title (e.g., Confidential Q4 Due Diligence)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_asset_title"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = LondonCyan,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = PlatinumWhite,
                    unfocusedTextColor = PlatinumWhite
                )
            )
        }

        item {
            OutlinedTextField(
                value = filename,
                onValueChange = { filename = it },
                label = { Text("Original Filename (e.g., AUDIT_REPORT_2026.PDF)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_asset_filename"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = LondonCyan,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = PlatinumWhite,
                    unfocusedTextColor = PlatinumWhite
                )
            )
        }

        item {
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Security Description & Scope") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = LondonCyan,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = PlatinumWhite,
                    unfocusedTextColor = PlatinumWhite
                )
            )
        }

        item {
            OutlinedTextField(
                value = plaintext,
                onValueChange = { plaintext = it },
                label = { Text("Confidential Plaintext Content / Payload") },
                minLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_asset_plaintext"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = LondonCyan,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = PlatinumWhite,
                    unfocusedTextColor = PlatinumWhite
                )
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Algorithm dropdown
                ExposedDropdownMenuBox(
                    expanded = algoDropdownExpanded,
                    onExpandedChange = { algoDropdownExpanded = !algoDropdownExpanded },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = selectedAlgorithm.identifier,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Algorithm") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = algoDropdownExpanded) },
                        modifier = Modifier.menuAnchor(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LondonCyan,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = PlatinumWhite,
                            unfocusedTextColor = PlatinumWhite
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = algoDropdownExpanded,
                        onDismissRequest = { algoDropdownExpanded = false }
                    ) {
                        EncryptionAlgorithm.values().forEach { algo ->
                            DropdownMenuItem(
                                text = { Text(algo.displayName) },
                                onClick = {
                                    selectedAlgorithm = algo
                                    algoDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Price text field
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("Price (£ GBP)") },
                    leadingIcon = { Icon(Icons.Default.CurrencyPound, contentDescription = null, tint = InstitutionalAmber) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("input_asset_price"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = InstitutionalAmber,
                        unfocusedBorderColor = DarkBorder,
                        focusedTextColor = PlatinumWhite,
                        unfocusedTextColor = PlatinumWhite
                    )
                )
            }
        }

        item {
            // Payment Rail dropdown
            ExposedDropdownMenuBox(
                expanded = railDropdownExpanded,
                onExpandedChange = { railDropdownExpanded = !railDropdownExpanded },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = selectedRail.displayName,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Primary Payment Rail") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = railDropdownExpanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LondonCyan,
                        unfocusedBorderColor = DarkBorder,
                        focusedTextColor = PlatinumWhite,
                        unfocusedTextColor = PlatinumWhite
                    )
                )
                ExposedDropdownMenu(
                    expanded = railDropdownExpanded,
                    onDismissRequest = { railDropdownExpanded = false }
                ) {
                    PaymentRailType.values().forEach { rail ->
                        DropdownMenuItem(
                            text = { Text("${rail.displayName} (${rail.settlementType})") },
                            onClick = {
                                selectedRail = rail
                                railDropdownExpanded = false
                            }
                        )
                    }
                }
            }
        }

        item {
            Button(
                onClick = {
                    val price = priceText.toDoubleOrNull() ?: 25.0
                    val finalTitle = title.ifEmpty { "CONFIDENTIAL_PAYLOAD_${System.currentTimeMillis()}" }
                    val finalFilename = filename.ifEmpty { "SECURE_DATA.BIN" }
                    val finalPlaintext = plaintext.ifEmpty { "London Cipher encrypted payload generated at client boundary." }
                    onPublish(finalTitle, description, finalFilename, finalPlaintext, selectedAlgorithm, price, selectedCondition, selectedRail)
                },
                enabled = !isBusy,
                colors = ButtonDefaults.buttonColors(containerColor = LondonCyan),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("publish_cipher_object_button")
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = ObsidianBg)
                Spacer(Modifier.width(8.dp))
                Text("ENCRYPT & PUBLISH CIPHER OBJECT", color = ObsidianBg, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}
