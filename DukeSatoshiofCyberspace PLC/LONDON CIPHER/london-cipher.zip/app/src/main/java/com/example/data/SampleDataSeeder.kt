package com.example.data

import com.example.crypto.AccessConditionType
import com.example.crypto.CryptoEngine
import com.example.crypto.EncryptionAlgorithm
import com.example.crypto.KeyManager
import com.example.crypto.PaymentRailType
import com.example.crypto.SettlementState
import java.nio.charset.StandardCharsets
import java.util.UUID

object SampleDataSeeder {

    suspend fun seedInitialDataIfEmpty(
        database: AppDatabase,
        keyManager: KeyManager
    ) {
        val latestAudit = database.auditDao().getLatestAuditEvent()
        if (latestAudit != null) return // Already seeded

        var lastAuditHash = "0000000000000000000000000000000000000000000000000000000000000000"

        val seedDocs = listOf(
            Triple(
                "PROJECT MAYFAIR — Acquisition Term Sheet & Valuation",
                "Confidential £45M M&A term sheet between London Capital Partners and Apex Cyber Tech Ltd. Specifies enterprise valuation multiples, escrow release milestones, and IP assignment schedules.",
                "MAYFAIR_ACQUISITION_TERM_SHEET_V4.PDF"
            ),
            Triple(
                "Canary Wharf Series B Financial Model (2026-2030)",
                "Full dynamic institutional LBO & DCF financial workbook. Contains detailed revenue waterfalls, gross margin breakdowns, machine commerce unit economics, and cash burn projections.",
                "SERIES_B_FINANCIAL_MODEL_Q3.XLSX"
            ),
            Triple(
                "Apex Cyber Legal Due Diligence & IP Verification",
                "Comprehensive solicitor audit report conducted by City of London Counsel regarding patent portfolios, export control compliance, and cryptographic patent freedom-to-operate.",
                "LEGAL_DUE_DILIGENCE_REPORT_FINAL.DOCX"
            ),
            Triple(
                "High-Frequency FX Orderbook & Tick Telemetry",
                "Institutional microstructure tick-by-tick dataset for GBP/USD, EUR/GBP, and USD/JPY currency pairs. Packaged for algorithmic M2M trading agents.",
                "HFT_FX_ORDERBOOK_TELEMETRY_FEED.BIN"
            )
        )

        for ((idx, doc) in seedDocs.withIndex()) {
            val (title, desc, filename) = doc
            val (keyId, rawKeyBytes) = keyManager.createDataEncryptionKey()

            val samplePlaintext = """
                ======================================================================
                LONDON CIPHER — CONFIDENTIAL INSTITUTIONAL DATA ROOM
                DOCUMENT: $title
                ASSET IDENTIFIER: $filename
                SECURITY CLASSIFICATION: TOP SECRET // STRICTLY RESTRICTED
                ISSUER: London Capital Partners (Canary Wharf, London E14)
                
                METADATA & EXECUTIVE SUMMARY:
                $desc
                
                CRYPTOGRAPHIC INTEGRITY GUARANTEE:
                This file was encrypted at the client boundary using authenticated AES-256-GCM.
                Access is conditioned on cryptographic settlement verification via London Cipher Protocol (LCP).
                Decryption keys are wrapped in hardware enclaves and only released upon valid preimage presentation.
                
                TIMESTAMP: ${System.currentTimeMillis()}
                ORIGINATING NODE: 03a89e187bc9e1f543dc3d04085f1c97a55c2763261a8ef1c29e160e1d03c31bba
                ======================================================================
            """.trimIndent()

            val plaintextBytes = samplePlaintext.toByteArray(StandardCharsets.UTF_8)
            val plaintextHash = CryptoEngine.sha256Hex(plaintextBytes)

            val isChaCha = idx == 1
            val algorithm = if (isChaCha) EncryptionAlgorithm.CHACHA20_POLY1305 else EncryptionAlgorithm.AES_256_GCM
            val (ciphertextWithTag, ivBytes, tagBytes) = if (isChaCha) {
                CryptoEngine.encryptChaCha20(plaintextBytes, rawKeyBytes)
            } else {
                CryptoEngine.encryptAesGcm(plaintextBytes, rawKeyBytes)
            }

            val cipherHex = CryptoEngine.toHex(ciphertextWithTag)
            val cipherHash = CryptoEngine.sha256Hex(ciphertextWithTag)
            val ivHex = CryptoEngine.toHex(ivBytes)
            val tagHex = CryptoEngine.toHex(tagBytes)

            val price = when (idx) {
                0 -> 150.00
                1 -> 75.00
                2 -> 200.00
                else -> 12.50
            }

            val condition = when (idx) {
                0 -> AccessConditionType.ONE_TIME_PURCHASE
                1 -> AccessConditionType.TIME_LIMITED_24H
                2 -> AccessConditionType.ONE_TIME_PURCHASE
                else -> AccessConditionType.M2M_AUTONOMOUS_FEED
            }

            val objectId = "obj_lc_${UUID.randomUUID().toString().take(12)}"
            val integrityCommitment = CryptoEngine.computeIntegrityCommitment(cipherHash, plaintextHash, "policy_std_$idx", keyId)

            val entity = CipherObjectEntity(
                id = objectId,
                title = title,
                description = desc,
                originalFilename = filename,
                originalSizeBytes = plaintextBytes.size.toLong(),
                mimeType = if (filename.endsWith(".PDF")) "application/pdf" else if (filename.endsWith(".XLSX")) "application/vnd.ms-excel" else "application/octet-stream",
                plaintextSha256 = plaintextHash,
                ciphertextHex = cipherHex,
                ciphertextSha256 = cipherHash,
                ivHex = ivHex,
                tagHex = tagHex,
                algorithm = algorithm.identifier,
                keyId = keyId,
                ownerIdentity = "did:lc:org:london-capital-partners",
                createdAt = System.currentTimeMillis() - (86400000L * (4 - idx)),
                conditionType = condition.name,
                priceAmount = price,
                currency = "GBP",
                allowedRailsCsv = "LIGHTNING,CBDC_GBP_SANDBOX,STABLECOIN_USDC",
                validityDurationSeconds = 86400L,
                integrityCommitment = integrityCommitment,
                isDecryptedLocally = false,
                localDecryptedText = null
            )
            database.cipherDao().insertCipherObject(entity)

            // Audit: FILE_ENCRYPTED
            val encEventId = "evt_${UUID.randomUUID().toString().take(10)}"
            val encHash = CryptoEngine.computeAuditHash(encEventId, entity.createdAt, "FILE_ENCRYPTED", objectId, lastAuditHash)
            database.auditDao().insertAuditEvent(
                AuditEventEntity(
                    eventId = encEventId,
                    timestamp = entity.createdAt,
                    eventType = "FILE_ENCRYPTED",
                    objectId = objectId,
                    actor = "CLIENT_LOCAL_ENGINE",
                    details = "Encrypted $filename (${entity.originalSizeBytes} bytes) with ${algorithm.identifier}. Hash commitment registered.",
                    prevHash = lastAuditHash,
                    currentHash = encHash
                )
            )
            lastAuditHash = encHash

            // Create initial offer
            val (preimage, paymentHash) = CryptoEngine.generatePreimage()
            val offerId = "off_${UUID.randomUUID().toString().take(10)}"
            val rail = if (idx == 2) PaymentRailType.CBDC_GBP_SANDBOX else PaymentRailType.LIGHTNING
            val sats = (price * 2400).toLong()
            val inv = if (rail == PaymentRailType.LIGHTNING) "lnbc${sats}u1p${paymentHash.take(24)}" else "pacs.008.001.08/GBP/$paymentHash"

            val offerEntity = AccessOfferEntity(
                offerId = offerId,
                objectId = objectId,
                requestId = "req_init_$idx",
                priceAmount = price,
                currency = "GBP",
                rail = rail.name,
                invoiceReference = inv,
                paymentHashHex = paymentHash,
                commitmentHash = CryptoEngine.sha256Hex("$offerId:$paymentHash:$price"),
                expiresAt = System.currentTimeMillis() + 86400000L * 7,
                settlementState = SettlementState.WAITING_PAYMENT.name,
                preimageHex = preimage
            )
            database.offerDao().insertOffer(offerEntity)

            val offerEventId = "evt_${UUID.randomUUID().toString().take(10)}"
            val offHash = CryptoEngine.computeAuditHash(offerEventId, System.currentTimeMillis(), "ACCESS_OFFER_PUBLISHED", objectId, lastAuditHash)
            database.auditDao().insertAuditEvent(
                AuditEventEntity(
                    eventId = offerEventId,
                    timestamp = System.currentTimeMillis() - (3600000L * (4 - idx)),
                    eventType = "ACCESS_OFFER_PUBLISHED",
                    objectId = objectId,
                    actor = "PAYMENT_ROUTER_NODE",
                    details = "Access condition published: £${"%.2f".format(price)} via ${rail.displayName}. Settlement condition bound to HTLC hash ${paymentHash.take(16)}...",
                    prevHash = lastAuditHash,
                    currentHash = offHash
                )
            )
            lastAuditHash = offHash
        }

        // Add telemetry seeds for M2M
        val sampleM2M = listOf(
            M2MTelemetryEntity(
                id = UUID.randomUUID().toString(),
                agentName = "Apex-Alpha-Macro-Agent-09",
                agentDid = "did:m2m:agent:apex-algo-london",
                datasetRequested = "High-Frequency FX Orderbook & Tick Telemetry",
                costAmount = 12.50,
                currency = "GBP",
                rail = "LIGHTNING",
                latencyMs = 38L,
                timestamp = System.currentTimeMillis() - 120000L,
                status = "VERIFIED_AND_RELEASED",
                capabilityToken = "cap_tok_991f8a8b12e4"
            ),
            M2MTelemetryEntity(
                id = UUID.randomUUID().toString(),
                agentName = "Canary-Quant-Research-Bot",
                agentDid = "did:m2m:agent:canary-quant-v3",
                datasetRequested = "UK Power Grid 1-Min Spot Telemetry",
                costAmount = 5.20,
                currency = "GBP",
                rail = "LIGHTNING",
                latencyMs = 24L,
                timestamp = System.currentTimeMillis() - 450000L,
                status = "VERIFIED_AND_RELEASED",
                capabilityToken = "cap_tok_aa38bf091ec8"
            )
        )
        for (m in sampleM2M) {
            database.telemetryDao().insertTelemetry(m)
        }
    }
}
