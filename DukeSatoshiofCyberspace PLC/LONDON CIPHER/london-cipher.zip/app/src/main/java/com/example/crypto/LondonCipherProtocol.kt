package com.example.crypto

import java.util.UUID

/**
 * London Cipher Protocol (LCP) - Specification & Data Objects
 * Encrypted Data Infrastructure for the Machine Economy
 * Dual-layer Architecture: Layer 1 (Cryptographic Encryption) + Layer 2 (Settlement-Gated Access)
 */

enum class EncryptionAlgorithm(val identifier: String, val displayName: String, val keySizeBits: Int) {
    AES_256_GCM("AES-256-GCM", "AES-256-GCM (Authenticated)", 256),
    CHACHA20_POLY1305("ChaCha20-Poly1305", "ChaCha20-Poly1305 (IETF)", 256)
}

enum class AccessConditionType(val displayName: String, val description: String) {
    ONE_TIME_PURCHASE("One-Time Settlement", "Permanent cryptographic capability release upon settlement"),
    TIME_LIMITED_24H("Time-Limited Lease", "Cryptographic capability expires after 24 hours"),
    SUBSCRIPTION_RECURRING("Recurring Stream", "Periodic settlement keeps access capability active"),
    PAY_PER_DOWNLOAD("Pay-Per-Download", "Single-use cryptographic capability burned after download"),
    PER_QUERY_API("Pay-Per-Query", "Machine-to-Machine micro-payment per query"),
    M2M_AUTONOMOUS_FEED("M2M Agent Stream", "Automated high-frequency agent subscription")
}

enum class PaymentRailType(val code: String, val displayName: String, val settlementType: String) {
    LIGHTNING("LIGHTNING", "Lightning Network", "L2 Hash-Time Locked Contract (HTLC)"),
    CBDC_GBP_SANDBOX("CBDC_GBP", "Digital GBP (Sandbox)", "Bank of England Programmable RTGS"),
    CBDC_EUR_SANDBOX("CBDC_EUR", "Digital EUR (Sandbox)", "ECB Eurosystem Distributed Ledger"),
    CBDC_USD_SANDBOX("CBDC_USD", "Digital USD (Sandbox)", "FedNow / Digital Dollar Sandbox"),
    STABLECOIN_USDC("STABLE_USDC", "Institutional USDC", "Regulated Multi-Chain Settlement"),
    FASTER_PAYMENTS_UK("UK_FPS", "UK Faster Payments", "Open Banking ISO 20022 Direct Rail")
}

enum class SettlementState(val displayName: String) {
    WAITING_PAYMENT("Waiting for Settlement"),
    IN_FLIGHT("In Flight / HTLC Routing"),
    SETTLED("Settlement Confirmed"),
    VERIFIED("Cryptographically Verified"),
    CAPABILITY_RELEASED("Access Capability Released"),
    EXPIRED("Offer Expired"),
    REVOKED("Capability Revoked"),
    FAILED("Settlement Failed")
}

enum class KeyState {
    ACTIVE,
    WRAPPED,
    ROTATED,
    REVOKED,
    EXPIRED
}

/**
 * Hash-Committed Cipher Object
 * Plaintext is NEVER exposed on payment networks or untrusted storage.
 */
data class CipherObject(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String,
    val originalFilename: String,
    val originalSizeBytes: Long,
    val mimeType: String,
    val plaintextSha256: String,
    val ciphertextHex: String,
    val ciphertextSha256: String,
    val ivHex: String,
    val tagHex: String = "",
    val algorithm: EncryptionAlgorithm = EncryptionAlgorithm.AES_256_GCM,
    val keyId: String,
    val ownerIdentity: String = "did:lc:org:london-capital-partners",
    val createdAt: Long = System.currentTimeMillis(),
    val accessPolicy: CipherAccessPolicy,
    val integrityCommitment: String,
    val isDecryptedLocally: Boolean = false,
    val localDecryptedText: String? = null
)

data class CipherAccessPolicy(
    val policyId: String = UUID.randomUUID().toString(),
    val conditionType: AccessConditionType = AccessConditionType.ONE_TIME_PURCHASE,
    val priceAmount: Double = 25.00,
    val currency: String = "GBP",
    val allowedRails: List<PaymentRailType> = listOf(PaymentRailType.LIGHTNING, PaymentRailType.CBDC_GBP_SANDBOX),
    val validityDurationSeconds: Long = 86400L,
    val maxUses: Int = 10,
    val expiresAt: Long = System.currentTimeMillis() + 86400000L * 30
)

data class CipherAccessRequest(
    val requestId: String = UUID.randomUUID().toString(),
    val objectId: String,
    val requesterIdentity: String,
    val requestedCapability: String = "CAPABILITY_DECRYPT_READ",
    val requestedRail: PaymentRailType = PaymentRailType.LIGHTNING,
    val timestamp: Long = System.currentTimeMillis(),
    val nonce: String,
    val protocolVersion: String = "LCP/2.4-LONDON"
)

data class CipherAccessOffer(
    val offerId: String = UUID.randomUUID().toString(),
    val objectId: String,
    val requestId: String,
    val priceAmount: Double,
    val currency: String,
    val rail: PaymentRailType,
    val invoiceReference: String,
    val paymentHashHex: String,
    val commitmentHash: String,
    val expiresAt: Long,
    val settlementState: SettlementState = SettlementState.WAITING_PAYMENT,
    val preimageHex: String? = null
)

data class CipherSettlementProof(
    val proofId: String = UUID.randomUUID().toString(),
    val offerId: String,
    val objectId: String,
    val paymentHashHex: String,
    val preimageHex: String,
    val rail: PaymentRailType,
    val settlementTimestamp: Long = System.currentTimeMillis(),
    val routingFeePence: Double = 0.04,
    val blockHeightOrTxId: String,
    val cryptographicSignature: String,
    val isVerified: Boolean = true
)

data class CipherAccessCapability(
    val capabilityToken: String,
    val objectId: String,
    val keyId: String,
    val wrappedKeyHex: String,
    val wrappingAlgorithm: String = "AES-KW-256",
    val validUntil: Long,
    val permissions: List<String> = listOf("DECRYPT", "READ", "STREAM"),
    val signatureHex: String,
    val status: SettlementState = SettlementState.CAPABILITY_RELEASED
)

data class CipherReleaseEvent(
    val releaseId: String = UUID.randomUUID().toString(),
    val objectId: String,
    val capabilityToken: String,
    val recipientIdentity: String,
    val timestamp: Long = System.currentTimeMillis(),
    val auditLedgerHash: String
)

data class CipherAuditEvent(
    val eventId: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val eventType: String,
    val objectId: String,
    val actor: String,
    val details: String,
    val prevHash: String,
    val currentHash: String
)
