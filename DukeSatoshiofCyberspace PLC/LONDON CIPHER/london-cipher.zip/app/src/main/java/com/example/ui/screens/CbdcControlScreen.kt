package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.payments.CbdcSandboxEnvironment
import com.example.ui.components.BadgeVariant
import com.example.ui.components.CryptographicBadge
import com.example.ui.components.HexViewer
import com.example.ui.theme.BritishEmerald
import com.example.ui.theme.CanaryBlue
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.InstitutionalAmber
import com.example.ui.theme.LondonCyan
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlatinumWhite
import com.example.viewmodel.LondonCipherViewModel
import java.util.UUID

@Composable
fun CbdcControlScreen(
    viewModel: LondonCipherViewModel,
    modifier: Modifier = Modifier
) {
    var lastSimulatedTx by remember { mutableStateOf<String?>(null) }

    val sandboxes = listOf(
        CbdcSandboxEnvironment(
            jurisdiction = "United Kingdom",
            currencyCode = "GBP",
            centralBankAuthority = "Bank of England (Synthetic Sandbox)",
            settlementProtocol = "Programmable RTGS Sterling / ISO 20022",
            isSyntheticSandbox = true,
            multiSigQuorum = "3-of-4 Regulated Node Consensus",
            tokenStandard = "Digital Sterling Scheme v1.4",
            avgLatencyMs = 160L
        ),
        CbdcSandboxEnvironment(
            jurisdiction = "Eurosystem",
            currencyCode = "EUR",
            centralBankAuthority = "European Central Bank (Sandbox)",
            settlementProtocol = "Eurosystem Distributed Ledger Trial",
            isSyntheticSandbox = true,
            multiSigQuorum = "2-of-3 ECB Validator Nodes",
            tokenStandard = "Digital Euro Wholesale DLT",
            avgLatencyMs = 190L
        ),
        CbdcSandboxEnvironment(
            jurisdiction = "United States",
            currencyCode = "USD",
            centralBankAuthority = "Federal Reserve (Digital Sandbox)",
            settlementProtocol = "FedNow Synthetic Programmable Token",
            isSyntheticSandbox = true,
            multiSigQuorum = "Fed District Node Quorum",
            tokenStandard = "US Wholesale Digital Dollar",
            avgLatencyMs = 210L
        )
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(GraphiteSurface)
                    .border(1.dp, CanaryBlue.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AccountBalance,
                                contentDescription = null,
                                tint = CanaryBlue,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "CBDC CONTROL ROOM // SYNTHETIC RAILS",
                                color = CanaryBlue,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                        CryptographicBadge("SYNTHETIC SANDBOX", BadgeVariant.CYAN)
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Central Bank Digital Currency Interoperability",
                        style = MaterialTheme.typography.titleMedium,
                        color = PlatinumWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "London Cipher's provider-neutral architecture connects future programmable central bank rails to cryptographic data access policies without assuming central banks expose Lightning APIs.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedSilver
                    )
                }
            }
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CanaryBlue.copy(alpha = 0.08f))
                    .border(1.dp, CanaryBlue.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = CanaryBlue, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "DISCLAIMER: All CBDC rails in this environment operate as synthetic experimental sandboxes to model programmable monetary access conditions. No real central bank endorsement is implied.",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.5.sp,
                        color = PlatinumWhite.copy(alpha = 0.85f),
                        lineHeight = 15.sp
                    )
                }
            }
        }

        items(sandboxes.size) { idx ->
            val env = sandboxes[idx]
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "DIGITAL ${env.currencyCode} (${env.jurisdiction})",
                                style = MaterialTheme.typography.titleMedium,
                                color = PlatinumWhite,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = env.centralBankAuthority,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.5.sp,
                                color = LondonCyan
                            )
                        }

                        CryptographicBadge("LATENCY ~${env.avgLatencyMs}ms", BadgeVariant.MUTED)
                    }

                    Spacer(Modifier.height(12.dp))
                    Divider(color = DarkBorder)
                    Spacer(Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("SETTLEMENT PROTOCOL", fontFamily = FontFamily.Monospace, fontSize = 9.5.sp, color = MutedSilver)
                            Text(env.settlementProtocol, color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("CONSENSUS QUORUM", fontFamily = FontFamily.Monospace, fontSize = 9.5.sp, color = MutedSilver)
                            Text(env.multiSigQuorum, color = BritishEmerald, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val txId = "pacs.008.001.08/${env.currencyCode}/" + UUID.randomUUID().toString().take(18)
                            lastSimulatedTx = "Executed ${env.currencyCode} 150.00 sandbox transfer on ${env.centralBankAuthority}. RTGS Block Seal: $txId"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CanaryBlue),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = PlatinumWhite, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("SIMULATE ${env.currencyCode} RTGS SETTLEMENT", fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                    }
                }
            }
        }

        if (lastSimulatedTx != null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(BritishEmerald.copy(alpha = 0.12f))
                        .border(1.dp, BritishEmerald.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BritishEmerald)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = lastSimulatedTx!!,
                            color = BritishEmerald,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
