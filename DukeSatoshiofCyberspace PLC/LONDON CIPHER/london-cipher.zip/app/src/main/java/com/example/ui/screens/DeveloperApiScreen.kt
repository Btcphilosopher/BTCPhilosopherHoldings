package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DataObject
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BadgeVariant
import com.example.ui.components.CryptographicBadge
import com.example.ui.components.HexViewer
import com.example.ui.theme.BritishEmerald
import com.example.ui.theme.CodeBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.InstitutionalAmber
import com.example.ui.theme.LondonCyan
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlatinumWhite
import com.example.viewmodel.LondonCipherViewModel

@Composable
fun DeveloperApiScreen(
    viewModel: LondonCipherViewModel,
    modifier: Modifier = Modifier
) {
    var selectedSdkTab by remember { mutableIntStateOf(0) } // 0: Kotlin, 1: Python, 2: Rust, 3: TypeScript

    val kotlinSnippet = """
// London Cipher Kotlin Enterprise SDK
val client = LondonCipherClient.builder()
    .endpoint("https://api.londoncipher.co.uk")
    .apiKey(BuildConfig.LONDON_CIPHER_API_KEY)
    .build()

// 1. Client-Side Authenticated Encryption
val fileBytes = File("acquisition_term_sheet.pdf").readBytes()
val cipherObject = client.encryptAndCommit(
    data = fileBytes,
    algorithm = EncryptionAlgorithm.AES_256_GCM
)

// 2. Publish Settlement Condition
val offer = cipherObject.createAccessOffer(
    price = Money("GBP", 150.00),
    rail = PaymentRail.LIGHTNING
)

// 3. Await HTLC Preimage & Release Capability
val capability = offer.awaitSettlement()

// 4. Client Decryption
val decrypted = capability.decrypt(cipherObject.ciphertext)
    """.trimIndent()

    val pythonSnippet = """
# London Cipher Python Core SDK
from london_cipher import LondonCipher, PaymentRail, Money

cipher = LondonCipher(api_key="lc_sec_live_canary_wharf")

# 1. Local authenticated AEAD encryption
encrypted_obj = cipher.encrypt_file(
    path="series_b_model.xlsx",
    algorithm="AES-256-GCM"
)

# 2. Gate access with Lightning HTLC
offer = encrypted_obj.create_access_offer(
    price=Money(amount=75.00, currency="GBP"),
    rail=PaymentRail.LIGHTNING
)

# 3. Autonomous verification & unwrapping
capability = offer.settle_and_release(preimage=buyer_preimage)
plaintext = capability.unwrap_and_decrypt()
    """.trimIndent()

    val rustSnippet = """
// London Cipher Rust Security Core (cipher-core)
use london_cipher_core::{CipherEngine, Algorithm, LightningRail};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let engine = CipherEngine::new_with_hsm();
    let plaintext = std::fs::read("due_diligence.pdf")?;
    
    // Authenticated client encryption
    let cipher_obj = engine.encrypt(&plaintext, Algorithm::Aes256Gcm)?;
    let commitment = cipher_obj.compute_commitment();
    
    // Settlement gating
    let invoice = LightningRail::generate_invoice(&cipher_obj, 200.00).await?;
    println!("HTLC Payment Hash: {}", invoice.payment_hash());
    Ok(())
}
    """.trimIndent()

    val typeScriptSnippet = """
// London Cipher TypeScript / Node & Browser SDK
import { LondonCipher, PaymentRail } from '@london-cipher/sdk';

const cipher = new LondonCipher({ apiKey: process.env.LC_API_KEY });

// M2M Agent autonomous purchase
const telemetryFeed = await cipher.discoverFeed('did:lc:feed:fx-orderbook');
const quote = await telemetryFeed.quote({ rail: PaymentRail.LIGHTNING });

const payment = await quote.payWithPreimage();
const dataStream = await telemetryFeed.subscribe(payment.capabilityToken);
dataStream.on('chunk', (packet) => console.log('Decrypted tick:', packet));
    """.trimIndent()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(GraphiteSurface)
                    .border(1.dp, LondonCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Terminal,
                                contentDescription = null,
                                tint = LondonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "DEVELOPER API & MULTI-LANGUAGE SDKS",
                                color = LondonCyan,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                        CryptographicBadge("REST / WS / SDK", BadgeVariant.CYAN)
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Unified Cryptographic Access & Settlement API",
                        style = MaterialTheme.typography.titleMedium,
                        color = PlatinumWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Integrate London Cipher into banks, algorithmic trading systems, autonomous agents, and enterprise ERPs.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedSilver
                    )
                }
            }
        }

        item {
            Text(
                text = "CORE REST ENDPOINTS",
                color = InstitutionalAmber,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val endpoints = listOf(
                        Pair("POST", "/v1/cipher-objects  (Commit encrypted object)"),
                        Pair("POST", "/v1/access/{id}/payment  (Generate HTLC invoice)"),
                        Pair("GET", "/v1/access/{id}/status  (Verify settlement state)"),
                        Pair("POST", "/v1/access/{id}/release  (Unwrap capability token)"),
                        Pair("GET", "/v1/audit/ledger  (Stream hash-chained events)")
                    )

                    endpoints.forEach { (method, path) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CryptographicBadge(
                                text = method,
                                variant = if (method == "POST") BadgeVariant.CYAN else BadgeVariant.EMERALD
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = path,
                                color = PlatinumWhite,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "MULTI-LANGUAGE ENTERPRISE SDKS",
                color = LondonCyan,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            TabRow(
                selectedTabIndex = selectedSdkTab,
                containerColor = GraphiteSurface,
                contentColor = LondonCyan,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedSdkTab]),
                        color = LondonCyan
                    )
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
            ) {
                listOf("Kotlin", "Python", "Rust", "TypeScript").forEachIndexed { idx, label ->
                    Tab(
                        selected = selectedSdkTab == idx,
                        onClick = { selectedSdkTab = idx },
                        text = { Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                    )
                }
            }
        }

        item {
            val codeToDisplay = when (selectedSdkTab) {
                0 -> kotlinSnippet
                1 -> pythonSnippet
                2 -> rustSnippet
                else -> typeScriptSnippet
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CodeBg)
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = codeToDisplay,
                    color = PlatinumWhite,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
