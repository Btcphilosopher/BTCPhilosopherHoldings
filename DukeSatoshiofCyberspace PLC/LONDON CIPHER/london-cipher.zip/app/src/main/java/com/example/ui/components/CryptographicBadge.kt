package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BritishEmerald
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.InstitutionalAmber
import com.example.ui.theme.LondonCyan
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.RestrainedCrimson

enum class BadgeVariant {
    CYAN,
    EMERALD,
    AMBER,
    CRIMSON,
    MUTED
}

@Composable
fun CryptographicBadge(
    text: String,
    variant: BadgeVariant = BadgeVariant.CYAN,
    hasDot: Boolean = false,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, borderColor) = when (variant) {
        BadgeVariant.CYAN -> Triple(LondonCyan.copy(alpha = 0.12f), LondonCyan, LondonCyan.copy(alpha = 0.4f))
        BadgeVariant.EMERALD -> Triple(BritishEmerald.copy(alpha = 0.12f), BritishEmerald, BritishEmerald.copy(alpha = 0.4f))
        BadgeVariant.AMBER -> Triple(InstitutionalAmber.copy(alpha = 0.12f), InstitutionalAmber, InstitutionalAmber.copy(alpha = 0.4f))
        BadgeVariant.CRIMSON -> Triple(RestrainedCrimson.copy(alpha = 0.12f), RestrainedCrimson, RestrainedCrimson.copy(alpha = 0.4f))
        BadgeVariant.MUTED -> Triple(DarkBorder.copy(alpha = 0.3f), MutedSilver, DarkBorder)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (hasDot) {
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(textColor)
                )
                Spacer(modifier = Modifier.width(5.dp))
            }
            Text(
                text = text,
                color = textColor,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
