package com.example.payments

import com.example.crypto.PaymentRailType

data class PaymentQuote(
    val railType: PaymentRailType,
    val currency: String,
    val baseAmount: Double,
    val networkFeeAmount: Double,
    val totalAmount: Double,
    val estimatedSettlementMs: Long,
    val routingHops: Int,
    val expirySeconds: Long = 3600,
    val requiresBiometricOrAuth: Boolean = false,
    val railStatus: String = "ONLINE"
)

data class PaymentRequest(
    val paymentId: String,
    val offerId: String,
    val railType: PaymentRailType,
    val amount: Double,
    val currency: String,
    val invoiceString: String,
    val paymentHashHex: String,
    val secretPreimageHex: String, // Kept node-side or returned upon payment settlement
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 3600000L
)

data class PaymentVerificationResult(
    val isSettled: Boolean,
    val paymentHashHex: String,
    val preimageHex: String,
    val confirmedAt: Long,
    val txOrBlockRef: String,
    val railType: PaymentRailType,
    val statusMessage: String
)

interface PaymentRail {
    val railType: PaymentRailType
    val railName: String
    val isSandbox: Boolean
    suspend fun quote(amount: Double, currency: String): PaymentQuote
    suspend fun createPayment(offerId: String, amount: Double, currency: String, description: String): PaymentRequest
    suspend fun verifyPayment(paymentHashHex: String, preimageHex: String?): PaymentVerificationResult
    suspend fun simulateInstantSettlement(paymentRequest: PaymentRequest): PaymentVerificationResult
}
