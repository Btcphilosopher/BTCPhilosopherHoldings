package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DataObject
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.crypto.PaymentRailType
import com.example.ui.components.BadgeVariant
import com.example.ui.components.CryptographicBadge
import com.example.ui.theme.BritishEmerald
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.InstitutionalAmber
import com.example.ui.theme.LondonCyan
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlatinumWhite
import com.example.viewmodel.LondonCipherViewModel

@Composable
fun M2MCommerceScreen(
    viewModel: LondonCipherViewModel,
    modifier: Modifier = Modifier
) {
    val telemetryList by viewModel.m2mTelemetry.collectAsState()
    val isBusy by viewModel.isBusy.collectAsState()

    val availableFeeds = listOf(
        Triple("High-Frequency FX Orderbook (GBP/USD Microstructure)", 12.50, "Apex-Alpha-Macro-Agent-09"),
        Triple("National Grid UK Substation Spot Load Telemetry", 5.20, "Canary-Quant-Research-Bot"),
        Triple("Orbital Synthetic Aperture Radar (Maritime Stream)", 35.00, "Maritime-Logistics-AI-UK"),
        Triple("London Underground Commuter Density Vector Feed", 8.40, "Urban-Transit-Optimization-Agent")
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(GraphiteSurface)
                    .border(1.dp, LondonCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = LondonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "MACHINE-TO-MACHINE (M2M) COMMERCE",
                                color = LondonCyan,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                        CryptographicBadge("AUTONOMOUS AGENTS", BadgeVariant.CYAN)
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Encrypted Data Infrastructure for Autonomous AI Agents",
                        style = MaterialTheme.typography.titleMedium,
                        color = PlatinumWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Software agents automatically quote, settle micropayments over Lightning HTLC rails, and receive cryptographically bound data capabilities without human intervention.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedSilver
                    )
                }
            }
        }

        item {
            Text(
                text = "DISCOVERABLE ENCRYPTED DATA FEEDS",
                color = InstitutionalAmber,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        items(availableFeeds.size) { idx ->
            val (feedName, price, defaultAgent) = availableFeeds[idx]
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DataObject, contentDescription = null, tint = LondonCyan, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(feedName, color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                        }

                        Text("£${"%.2f".format(price)}", color = InstitutionalAmber, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                    }

                    Spacer(Modifier.height(8.dp))
                    Text("Auto-routed to Lightning L2 or Digital GBP Sandbox. Access released in <50ms.", color = MutedSilver, fontSize = 11.sp)

                    Spacer(Modifier.height(10.dp))

                    Button(
                        onClick = {
                            viewModel.triggerM2MSimulation(
                                datasetName = feedName,
                                agentName = defaultAgent,
                                agentDid = "did:m2m:agent:${defaultAgent.lowercase().replace("-", "")}",
                                priceAmount = price,
                                rail = PaymentRailType.LIGHTNING
                            )
                        },
                        enabled = !isBusy,
                        colors = ButtonDefaults.buttonColors(containerColor = LondonCyan),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("m2m_agent_buy_btn_$idx")
                    ) {
                        Icon(Icons.Default.AutoMode, contentDescription = null, tint = ObsidianBg, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("SIMULATE AI AGENT AUTONOMOUS PURCHASE", color = ObsidianBg, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                    }
                }
            }
        }

        item {
            Text(
                text = "LIVE M2M SETTLEMENT & CAPABILITY STREAM",
                color = BritishEmerald,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        items(telemetryList, key = { it.id }) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BritishEmerald.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(BritishEmerald))
                            Spacer(Modifier.width(6.dp))
                            Text(item.agentName, color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        CryptographicBadge("${item.latencyMs} ms", BadgeVariant.EMERALD)
                    }

                    Spacer(Modifier.height(4.dp))
                    Text(item.datasetRequested, color = LondonCyan, fontSize = 11.5.sp)

                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Paid: £${"%.2f".format(item.costAmount)} via ${item.rail}", fontFamily = FontFamily.Monospace, fontSize = 10.5.sp, color = MutedSilver)
                        Text(item.capabilityToken.take(18) + "...", fontFamily = FontFamily.Monospace, fontSize = 10.5.sp, color = BritishEmerald)
                    }
                }
            }
        }
    }
}
