package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BadgeVariant
import com.example.ui.components.CryptographicBadge
import com.example.ui.components.HexViewer
import com.example.ui.theme.BritishEmerald
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.InstitutionalAmber
import com.example.ui.theme.LondonCyan
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlatinumWhite
import com.example.viewmodel.LondonCipherViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AuditAndRiskScreen(
    viewModel: LondonCipherViewModel,
    modifier: Modifier = Modifier
) {
    val auditEvents by viewModel.auditEvents.collectAsState()
    val riskAnalytics by viewModel.riskAnalytics.collectAsState()

    val dateFormatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.UK)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(GraphiteSurface)
                    .border(1.dp, LondonCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = null,
                                tint = LondonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "AUDIT LEDGER & RISK ENGINE",
                                color = LondonCyan,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                        CryptographicBadge("HASH-CHAINED LEDGER", BadgeVariant.CYAN)
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Cryptographically Verifiable Audit Trail",
                        style = MaterialTheme.typography.titleMedium,
                        color = PlatinumWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Every file encryption, access policy creation, settlement verification, and capability release forms a tamper-evident SHA-256 hash-chain block.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedSilver
                    )
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Analytics, contentDescription = null, tint = InstitutionalAmber)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "R RESEARCH & RISK ANALYTICS BENCHMARK",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = InstitutionalAmber,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(Modifier.height(14.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("SETTLEMENT RELIABILITY", fontFamily = FontFamily.Monospace, fontSize = 9.5.sp, color = MutedSilver)
                            Text("${riskAnalytics.settlementReliabilityPercent}%", color = BritishEmerald, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                        }
                        Column {
                            Text("AVG LIGHTNING LATENCY", fontFamily = FontFamily.Monospace, fontSize = 9.5.sp, color = MutedSilver)
                            Text("${riskAnalytics.avgLightningSettlementMs} ms", color = LondonCyan, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                        }
                        Column {
                            Text("THROUGHPUT", fontFamily = FontFamily.Monospace, fontSize = 9.5.sp, color = MutedSilver)
                            Text("${riskAnalytics.encryptionThroughputMbSec} MB/s", color = PlatinumWhite, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    Divider(color = DarkBorder)
                    Spacer(Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("PROTECTED ASSETS VALUE", fontFamily = FontFamily.Monospace, fontSize = 9.5.sp, color = MutedSilver)
                            Text("£4,850,000.00", color = InstitutionalAmber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("VERIFIED SETTLEMENTS", fontFamily = FontFamily.Monospace, fontSize = 9.5.sp, color = MutedSilver)
                            Text("${riskAnalytics.totalSettlementsVerified} Events", color = BritishEmerald, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        item {
            Button(
                onClick = { viewModel.verifyAuditLedgerIntegrity() },
                colors = ButtonDefaults.buttonColors(containerColor = BritishEmerald),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("verify_ledger_integrity_button")
            ) {
                Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = ObsidianBg)
                Spacer(Modifier.width(8.dp))
                Text("VERIFY AUDIT LEDGER HASH-CHAIN INTEGRITY", color = ObsidianBg, fontWeight = FontWeight.ExtraBold, fontSize = 11.5.sp)
            }
        }

        item {
            Text(
                text = "IMMUTABLE AUDIT STREAM (${auditEvents.size} EVENTS)",
                color = LondonCyan,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        items(auditEvents, key = { it.eventId }) { event ->
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (event.eventType.contains("SETTLED") || event.eventType.contains("RELEASED") || event.eventType.contains("COMPLETED"))
                                            BritishEmerald
                                        else LondonCyan
                                    )
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = event.eventType,
                                color = PlatinumWhite,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp
                            )
                        }

                        Text(
                            text = dateFormatter.format(Date(event.timestamp)),
                            color = MutedSilver,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = event.details,
                        color = PlatinumWhite.copy(alpha = 0.9f),
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Actor: ${event.actor}", fontFamily = FontFamily.Monospace, fontSize = 9.5.sp, color = MutedSilver)
                        Text("Obj: ${event.objectId.take(12)}...", fontFamily = FontFamily.Monospace, fontSize = 9.5.sp, color = LondonCyan)
                    }

                    Spacer(Modifier.height(8.dp))
                    HexViewer("Block Hash", event.currentHash, maxLines = 1)
                }
            }
        }
    }
}
