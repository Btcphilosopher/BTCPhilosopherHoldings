package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CipherDao {
    @Query("SELECT * FROM cipher_objects ORDER BY createdAt DESC")
    fun getAllCipherObjects(): Flow<List<CipherObjectEntity>>

    @Query("SELECT * FROM cipher_objects WHERE id = :id")
    suspend fun getCipherObjectById(id: String): CipherObjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCipherObject(obj: CipherObjectEntity)

    @Update
    suspend fun updateCipherObject(obj: CipherObjectEntity)

    @Query("DELETE FROM cipher_objects WHERE id = :id")
    suspend fun deleteCipherObject(id: String)
}

@Dao
interface OfferDao {
    @Query("SELECT * FROM access_offers ORDER BY expiresAt DESC")
    fun getAllOffers(): Flow<List<AccessOfferEntity>>

    @Query("SELECT * FROM access_offers WHERE objectId = :objectId ORDER BY expiresAt DESC")
    fun getOffersForObject(objectId: String): Flow<List<AccessOfferEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOffer(offer: AccessOfferEntity)

    @Update
    suspend fun updateOffer(offer: AccessOfferEntity)

    @Query("SELECT * FROM access_offers WHERE offerId = :offerId")
    suspend fun getOfferById(offerId: String): AccessOfferEntity?
}

@Dao
interface SettlementDao {
    @Query("SELECT * FROM settlement_proofs ORDER BY settlementTimestamp DESC")
    fun getAllSettlementProofs(): Flow<List<SettlementProofEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettlementProof(proof: SettlementProofEntity)
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audit_events ORDER BY timestamp DESC")
    fun getAllAuditEvents(): Flow<List<AuditEventEntity>>

    @Query("SELECT * FROM audit_events ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestAuditEvent(): AuditEventEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditEvent(event: AuditEventEntity)
}

@Dao
interface TelemetryDao {
    @Query("SELECT * FROM m2m_telemetry ORDER BY timestamp DESC LIMIT 50")
    fun getRecentTelemetry(): Flow<List<M2MTelemetryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTelemetry(telemetry: M2MTelemetryEntity)
}
