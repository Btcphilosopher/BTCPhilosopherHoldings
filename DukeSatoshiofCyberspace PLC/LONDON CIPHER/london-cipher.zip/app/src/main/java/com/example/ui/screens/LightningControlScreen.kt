package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.crypto.CryptoEngine
import com.example.ui.components.BadgeVariant
import com.example.ui.components.CryptographicBadge
import com.example.ui.components.HexViewer
import com.example.ui.theme.BritishEmerald
import com.example.ui.theme.CanaryBlue
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.InstitutionalAmber
import com.example.ui.theme.LondonCyan
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlatinumWhite
import com.example.viewmodel.LondonCipherViewModel

@Composable
fun LightningControlScreen(
    viewModel: LondonCipherViewModel,
    modifier: Modifier = Modifier
) {
    var preimageTestInput by remember { mutableStateOf("") }
    var paymentHashTestInput by remember { mutableStateOf("") }
    var verificationStatus by remember { mutableStateOf<String?>(null) }
    var isVerificationValid by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            // Lightning Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(GraphiteSurface)
                    .border(1.dp, InstitutionalAmber.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FlashOn,
                                contentDescription = null,
                                tint = InstitutionalAmber,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "LIGHTNING CONTROL ROOM // LND NODE TELEMETRY",
                                color = InstitutionalAmber,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                        CryptographicBadge("HTLC ATOMIC SETTLEMENT", BadgeVariant.AMBER)
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Layer-2 Cryptographic Access Control Rails",
                        style = MaterialTheme.typography.titleMedium,
                        color = PlatinumWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Lightning is used as a second cryptographic and economic boundary around encrypted files. Access capability tokens are conditionally released when the HTLC preimage is broadcasted.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedSilver
                    )
                }
            }
        }

        item {
            // Node Metrics Grid
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "INSTITUTIONAL NODE METRICS",
                        fontFamily = FontFamily.Monospace,
                        color = LondonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("NODE ALIAS", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MutedSilver)
                            Text("CANARY-WHARF-LND-01", color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Column {
                            Text("ACTIVE CHANNELS", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MutedSilver)
                            Text("38 Active (100% Online)", color = BritishEmerald, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Column {
                            Text("ROUTING LATENCY", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MutedSilver)
                            Text("28 ms (Avg)", color = LondonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    Divider(color = DarkBorder)
                    Spacer(Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("LOCAL LIQUIDITY", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MutedSilver)
                            Text("0.984 BTC (£58,400)", color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Column {
                            Text("REMOTE LIQUIDITY", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MutedSilver)
                            Text("0.866 BTC (£51,200)", color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Column {
                            Text("BASE / PPM FEE", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MutedSilver)
                            Text("1000 msat / 1 ppm", color = InstitutionalAmber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        item {
            HexViewer(
                "Canary Wharf LND Node Public Key (Secp256k1)",
                "03a89e187bc9e1f543dc3d04085f1c97a55c2763261a8ef1c29e160e1d03c31bba"
            )
        }

        item {
            Text(
                text = "CRYPTOGRAPHIC PREIMAGE VERIFICATION TOOL",
                color = LondonCyan,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Verify SHA256(Preimage) == PaymentHash for capability unlocking:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedSilver
                    )

                    Spacer(Modifier.height(10.dp))

                    OutlinedTextField(
                        value = preimageTestInput,
                        onValueChange = { preimageTestInput = it },
                        label = { Text("32-byte Hex Preimage (Secret)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_preimage_test"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LondonCyan,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = PlatinumWhite,
                            unfocusedTextColor = PlatinumWhite
                        )
                    )

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = paymentHashTestInput,
                        onValueChange = { paymentHashTestInput = it },
                        label = { Text("Payment Hash Commitment (SHA-256)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_payment_hash_test"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LondonCyan,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = PlatinumWhite,
                            unfocusedTextColor = PlatinumWhite
                        )
                    )

                    Spacer(Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                val (preimage, paymentHash) = CryptoEngine.generatePreimage()
                                preimageTestInput = preimage
                                paymentHashTestInput = paymentHash
                                verificationStatus = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CanaryBlue),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("GENERATE PAIR", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                val valid = CryptoEngine.verifySettlementPreimage(preimageTestInput, paymentHashTestInput)
                                isVerificationValid = valid
                                verificationStatus = if (valid) {
                                    "VALID HTLC PROOF! Preimage matches hash exactly. Capability release authorized."
                                } else {
                                    "INVALID PROOF! SHA256(preimage) != payment_hash."
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = InstitutionalAmber),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("verify_preimage_button")
                        ) {
                            Text("VERIFY HASH", color = ObsidianBg, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }

                    if (verificationStatus != null) {
                        Spacer(Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    if (isVerificationValid) BritishEmerald.copy(alpha = 0.15f)
                                    else com.example.ui.theme.RestrainedCrimson.copy(alpha = 0.15f)
                                )
                                .padding(10.dp)
                        ) {
                            Text(
                                text = verificationStatus!!,
                                color = if (isVerificationValid) BritishEmerald else com.example.ui.theme.RestrainedCrimson,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
