package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// London Cipher Institutional Palette: Deep Obsidian, Graphite, Canary Wharf Blue, British Emerald & Crimson
val ObsidianBg = Color(0xFF0B0F19)
val GraphiteSurface = Color(0xFF111827)
val GraphiteSurfaceVariant = Color(0xFF1F2937)
val GraphiteSurfaceElevated = Color(0xFF283548)

val LondonCyan = Color(0xFF38BDF8)
val LondonCyanDim = Color(0xFF0284C7)
val CanaryBlue = Color(0xFF3B82F6)
val CanaryBlueDark = Color(0xFF1E3A8A)

val BritishEmerald = Color(0xFF10B981)
val BritishEmeraldDark = Color(0xFF064E3B)

val InstitutionalAmber = Color(0xFFF59E0B)
val InstitutionalAmberDark = Color(0xFF78350F)

val RestrainedCrimson = Color(0xFFEF4444)
val RestrainedCrimsonDark = Color(0xFF7F1D1D)

val PlatinumWhite = Color(0xFFF9FAFB)
val MutedSilver = Color(0xFF94A3B8)
val DarkBorder = Color(0xFF374151)
val CodeBg = Color(0xFF0D1117)
