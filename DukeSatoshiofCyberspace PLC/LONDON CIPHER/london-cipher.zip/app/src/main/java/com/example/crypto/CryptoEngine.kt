package com.example.crypto

import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * London Cipher Cryptographic Engine
 * Robust authenticated encryption, key derivation, and integrity commitments.
 * Rule: DO NOT INVENT CRYPTOGRAPHY. Uses standard audited JCE primitives.
 */
object CryptoEngine {

    private val secureRandom = SecureRandom()
    private const val GCM_IV_LENGTH_BYTES = 12 // 96-bit standard IV for GCM
    private const val GCM_TAG_LENGTH_BITS = 128 // 128-bit authentication tag

    fun generateRandomKey(bits: Int = 256): ByteArray {
        val keyGen = KeyGenerator.getInstance("AES")
        keyGen.init(bits, secureRandom)
        return keyGen.generateKey().encoded
    }

    fun generateIv(bytesLength: Int = GCM_IV_LENGTH_BYTES): ByteArray {
        val iv = ByteArray(bytesLength)
        secureRandom.nextBytes(iv)
        return iv
    }

    fun generatePreimage(): Pair<String, String> {
        val preimage = ByteArray(32)
        secureRandom.nextBytes(preimage)
        val preimageHex = toHex(preimage)
        val paymentHashHex = sha256Hex(preimage)
        return Pair(preimageHex, paymentHashHex)
    }

    fun verifySettlementPreimage(preimageHex: String, expectedPaymentHashHex: String): Boolean {
        return try {
            val preimageBytes = fromHex(preimageHex.trim())
            val actualHash = sha256Hex(preimageBytes)
            actualHash.equals(expectedPaymentHashHex.trim(), ignoreCase = true)
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Authenticated Encryption using AES-256-GCM
     */
    fun encryptAesGcm(plaintext: ByteArray, keyBytes: ByteArray, associatedData: ByteArray? = null): Triple<ByteArray, ByteArray, ByteArray> {
        require(keyBytes.size == 32) { "AES-256 key must be exactly 32 bytes (256 bits)" }
        val iv = generateIv(GCM_IV_LENGTH_BYTES)
        val secretKey: SecretKey = SecretKeySpec(keyBytes, "AES")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val gcmSpec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, gcmSpec)
        
        associatedData?.let {
            cipher.updateAAD(it)
        }

        val ciphertextWithTag = cipher.doFinal(plaintext)
        // Extract tag if needed or keep combined
        val tagLengthBytes = GCM_TAG_LENGTH_BITS / 8
        val cipherLen = ciphertextWithTag.size - tagLengthBytes
        val cipherOnly = ciphertextWithTag.copyOfRange(0, cipherLen)
        val tagOnly = ciphertextWithTag.copyOfRange(cipherLen, ciphertextWithTag.size)

        return Triple(ciphertextWithTag, iv, tagOnly)
    }

    /**
     * Authenticated Decryption using AES-256-GCM
     */
    fun decryptAesGcm(ciphertextWithTag: ByteArray, keyBytes: ByteArray, iv: ByteArray, associatedData: ByteArray? = null): ByteArray {
        require(keyBytes.size == 32) { "AES-256 key must be exactly 32 bytes" }
        val secretKey: SecretKey = SecretKeySpec(keyBytes, "AES")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val gcmSpec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
        cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmSpec)

        associatedData?.let {
            cipher.updateAAD(it)
        }

        return cipher.doFinal(ciphertextWithTag)
    }

    /**
     * Authenticated Encryption using ChaCha20-Poly1305 with seamless standard fallback
     */
    fun encryptChaCha20(plaintext: ByteArray, keyBytes: ByteArray): Triple<ByteArray, ByteArray, ByteArray> {
        return try {
            val iv = generateIv(12)
            val secretKey = SecretKeySpec(keyBytes, "ChaCha20")
            val cipher = Cipher.getInstance("ChaCha20-Poly1305/None/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, IvParameterSpec(iv))
            val ciphertext = cipher.doFinal(plaintext)
            Triple(ciphertext, iv, ByteArray(16))
        } catch (e: Exception) {
            // High-security fallback to AES-256-GCM
            encryptAesGcm(plaintext, keyBytes)
        }
    }

    fun decryptChaCha20(ciphertext: ByteArray, keyBytes: ByteArray, iv: ByteArray): ByteArray {
        return try {
            val secretKey = SecretKeySpec(keyBytes, "ChaCha20")
            val cipher = Cipher.getInstance("ChaCha20-Poly1305/None/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey, IvParameterSpec(iv))
            cipher.doFinal(ciphertext)
        } catch (e: Exception) {
            decryptAesGcm(ciphertext, keyBytes, iv)
        }
    }

    /**
     * Key Wrapping: Wraps a Data Encryption Key (DEK) with a Key Wrapping Key (KWK)
     * using authenticated AES-GCM wrapping with domain separation.
     */
    fun wrapKey(dekBytes: ByteArray, kwkBytes: ByteArray, keyId: String): ByteArray {
        val aad = "LCP-KWK-DOMAIN:$keyId".toByteArray(StandardCharsets.UTF_8)
        val (wrappedBytes, iv, _) = encryptAesGcm(dekBytes, kwkBytes, aad)
        // Prepend IV (12 bytes) to wrapped bytes
        val result = ByteArray(iv.size + wrappedBytes.size)
        System.arraycopy(iv, 0, result, 0, iv.size)
        System.arraycopy(wrappedBytes, 0, result, iv.size, wrappedBytes.size)
        return result
    }

    /**
     * Key Unwrapping: Unwraps a wrapped DEK using the KWK and domain verification.
     */
    fun unwrapKey(wrappedPayload: ByteArray, kwkBytes: ByteArray, keyId: String): ByteArray {
        require(wrappedPayload.size > GCM_IV_LENGTH_BYTES) { "Invalid wrapped key payload length" }
        val iv = wrappedPayload.copyOfRange(0, GCM_IV_LENGTH_BYTES)
        val ciphertextWithTag = wrappedPayload.copyOfRange(GCM_IV_LENGTH_BYTES, wrappedPayload.size)
        val aad = "LCP-KWK-DOMAIN:$keyId".toByteArray(StandardCharsets.UTF_8)
        return decryptAesGcm(ciphertextWithTag, kwkBytes, iv, aad)
    }

    /**
     * SHA-256 Digest
     */
    fun sha256(data: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(data)
    }

    fun sha256Hex(data: ByteArray): String = toHex(sha256(data))

    fun sha256Hex(text: String): String = sha256Hex(text.toByteArray(StandardCharsets.UTF_8))

    /**
     * HMAC-SHA256 for Capability Authorization Signatures
     */
    fun hmacSha256(data: ByteArray, secretKeyBytes: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        val secretKey = SecretKeySpec(secretKeyBytes, "HmacSHA256")
        mac.init(secretKey)
        return mac.doFinal(data)
    }

    fun hmacSha256Hex(text: String, secretKeyHex: String): String {
        val keyBytes = fromHex(secretKeyHex)
        val dataBytes = text.toByteArray(StandardCharsets.UTF_8)
        return toHex(hmacSha256(dataBytes, keyBytes))
    }

    /**
     * Hash Commitment for CipherObject Integrity
     */
    fun computeIntegrityCommitment(
        ciphertextHash: String,
        plaintextHash: String,
        policyId: String,
        keyId: String
    ): String {
        val raw = "LC_COMMIT::$ciphertextHash::$plaintextHash::$policyId::$keyId"
        return sha256Hex(raw)
    }

    /**
     * Cryptographic Chained Audit Event Hash
     */
    fun computeAuditHash(eventId: String, timestamp: Long, eventType: String, objectId: String, prevHash: String): String {
        val raw = "$eventId|$timestamp|$eventType|$objectId|$prevHash"
        return sha256Hex(raw)
    }

    fun toHex(bytes: ByteArray): String {
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            sb.append(String.format("%02x", b))
        }
        return sb.toString()
    }

    fun fromHex(hex: String): ByteArray {
        val clean = hex.trim().replace(" ", "").replace("0x", "")
        val len = clean.length
        val result = ByteArray(len / 2)
        for (i in 0 until len step 2) {
            result[i / 2] = ((Character.digit(clean[i], 16) shl 4) +
                    Character.digit(clean[i + 1], 16)).toByte()
        }
        return result
    }
}
