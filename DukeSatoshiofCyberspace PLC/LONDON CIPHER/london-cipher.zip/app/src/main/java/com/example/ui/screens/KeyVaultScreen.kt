package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.crypto.KeyState
import com.example.crypto.ManagedKeyRecord
import com.example.crypto.MockLondonHsmProvider
import com.example.ui.components.BadgeVariant
import com.example.ui.components.CryptographicBadge
import com.example.ui.components.HexViewer
import com.example.ui.theme.BritishEmerald
import com.example.ui.theme.CanaryBlue
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.InstitutionalAmber
import com.example.ui.theme.LondonCyan
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlatinumWhite
import com.example.ui.theme.RestrainedCrimson
import com.example.viewmodel.LondonCipherViewModel

@Composable
fun KeyVaultScreen(
    viewModel: LondonCipherViewModel,
    modifier: Modifier = Modifier
) {
    val managedKeys by viewModel.managedKeys.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(GraphiteSurface)
                    .border(1.dp, LondonCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = null,
                                tint = LondonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "KEY MANAGEMENT & HSM ENCLAVE",
                                color = LondonCyan,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                        CryptographicBadge("FIPS 140-3 LEVEL 3", BadgeVariant.CYAN)
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Zero-Knowledge Key Envelope Architecture",
                        style = MaterialTheme.typography.titleMedium,
                        color = PlatinumWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Data Encryption Keys (DEK) are wrapped inside dedicated hardware security modules with Key Wrapping Keys (KWK). Raw plaintext encryption keys are never written to disk, logs, or payment payloads.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedSilver
                    )
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "ACTIVE HARDWARE SECURITY MODULE (HSM)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = LondonCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = MockLondonHsmProvider.hsmLabel,
                        color = PlatinumWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Enclave Security: Hardware-isolated AES-KW-256 wrapping with tamper-reactive zeroisation.",
                        color = MutedSilver,
                        fontSize = 11.sp
                    )
                }
            }
        }

        item {
            Text(
                text = "MANAGED KEYS & WRAPPING ENVELOPES (${managedKeys.size})",
                color = InstitutionalAmber,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        items(managedKeys, key = { it.keyId }) { keyRecord ->
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (keyRecord.keyType == "KWK") Icons.Default.Shield else Icons.Default.Key,
                                contentDescription = null,
                                tint = if (keyRecord.keyType == "KWK") LondonCyan else InstitutionalAmber,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "${keyRecord.keyType} // ${keyRecord.keyId}",
                                color = PlatinumWhite,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        val badgeVariant = when (keyRecord.state) {
                            KeyState.ACTIVE -> BadgeVariant.EMERALD
                            KeyState.ROTATED -> BadgeVariant.CYAN
                            KeyState.REVOKED -> BadgeVariant.CRIMSON
                            KeyState.EXPIRED -> BadgeVariant.AMBER
                            else -> BadgeVariant.MUTED
                        }
                        CryptographicBadge("v${keyRecord.version} ${keyRecord.state.name}", badgeVariant)
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Algorithm: ${keyRecord.algorithm} | Storage: In-Memory Hardware Enclave (Enclave protected)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.5.sp,
                        color = MutedSilver
                    )

                    Spacer(Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { viewModel.rotateKey(keyRecord.keyId) },
                            enabled = keyRecord.state == KeyState.ACTIVE,
                            colors = ButtonDefaults.buttonColors(containerColor = CanaryBlue),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("rotate_key_${keyRecord.keyId}")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("ROTATE KEY", fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                        }

                        OutlinedButton(
                            onClick = { viewModel.revokeAccess(keyRecord.keyId, "Manual HSM revocation") },
                            enabled = keyRecord.state == KeyState.ACTIVE,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = RestrainedCrimson),
                            border = androidx.compose.foundation.BorderStroke(1.dp, RestrainedCrimson.copy(alpha = 0.5f)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("REVOKE", fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                        }
                    }
                }
            }
        }
    }
}
