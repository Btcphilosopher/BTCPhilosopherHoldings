package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.LondonCipherTopBar
import com.example.ui.screens.AuditAndRiskScreen
import com.example.ui.screens.CbdcControlScreen
import com.example.ui.screens.DealRoomAndObjectsScreen
import com.example.ui.screens.DeveloperApiScreen
import com.example.ui.screens.KeyVaultScreen
import com.example.ui.screens.LightningControlScreen
import com.example.ui.screens.M2MCommerceScreen
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.GraphiteSurface
import com.example.ui.theme.LondonCipherTheme
import com.example.ui.theme.LondonCyan
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlatinumWhite
import com.example.viewmodel.ConsoleTab
import com.example.viewmodel.LondonCipherViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LondonCipherTheme {
                val vm: LondonCipherViewModel = viewModel()
                LondonCipherApp(viewModel = vm)
            }
        }
    }
}

data class TabItem(
    val tab: ConsoleTab,
    val icon: ImageVector,
    val label: String
)

@Composable
fun LondonCipherApp(
    viewModel: LondonCipherViewModel
) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val selectedObject by viewModel.selectedObject.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusMessage) {
        statusMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearStatusMessage()
        }
    }

    // Handle back button when detailed object is inspected or from other tabs
    BackHandler(enabled = selectedObject != null || selectedTab != ConsoleTab.DEAL_ROOM) {
        if (selectedObject != null) {
            viewModel.clearSelectedObject()
        } else {
            viewModel.selectTab(ConsoleTab.DEAL_ROOM)
        }
    }

    val tabs = listOf(
        TabItem(ConsoleTab.DEAL_ROOM, Icons.Default.Security, "Deal Room"),
        TabItem(ConsoleTab.LIGHTNING_CONTROL, Icons.Default.FlashOn, "Lightning"),
        TabItem(ConsoleTab.CBDC_RAILS, Icons.Default.AccountBalance, "CBDC Rails"),
        TabItem(ConsoleTab.M2M_ECONOMY, Icons.Default.Psychology, "M2M Market"),
        TabItem(ConsoleTab.KEY_VAULT, Icons.Default.Key, "Key Vault"),
        TabItem(ConsoleTab.AUDIT_RISK, Icons.Default.History, "Audit & Risk"),
        TabItem(ConsoleTab.API_SDKS, Icons.Default.Terminal, "API & SDKs")
    )

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            Column(modifier = Modifier.statusBarsPadding()) {
                LondonCipherTopBar()
                
                // Horizontal Scrollable Navigation Strip
                ScrollableTabRow(
                    selectedTabIndex = tabs.indexOfFirst { it.tab == selectedTab }.coerceAtLeast(0),
                    containerColor = GraphiteSurface,
                    contentColor = LondonCyan,
                    edgePadding = 8.dp,
                    indicator = { tabPositions ->
                        val currentIdx = tabs.indexOfFirst { it.tab == selectedTab }.coerceAtLeast(0)
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[currentIdx]),
                            color = LondonCyan,
                            height = 2.dp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DarkBorder)
                ) {
                    tabs.forEach { item ->
                        val isSelected = selectedTab == item.tab
                        Tab(
                            selected = isSelected,
                            onClick = {
                                if (selectedObject != null) {
                                    viewModel.clearSelectedObject()
                                }
                                viewModel.selectTab(item.tab)
                            },
                            text = {
                                Text(
                                    text = item.label,
                                    fontSize = 11.5.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) LondonCyan else MutedSilver
                                )
                            },
                            icon = {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.label,
                                    tint = if (isSelected) LondonCyan else MutedSilver,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            modifier = Modifier.testTag("tab_${item.tab.name.lowercase()}")
                        )
                    }
                }
            }
        },
        bottomBar = {
            // Respect navigation insets at bottom
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(ObsidianBg)
        ) {
            when (selectedTab) {
                ConsoleTab.DEAL_ROOM, ConsoleTab.OBJECTS_ENCRYPTION -> DealRoomAndObjectsScreen(viewModel = viewModel)
                ConsoleTab.LIGHTNING_CONTROL -> LightningControlScreen(viewModel = viewModel)
                ConsoleTab.CBDC_RAILS -> CbdcControlScreen(viewModel = viewModel)
                ConsoleTab.M2M_ECONOMY -> M2MCommerceScreen(viewModel = viewModel)
                ConsoleTab.KEY_VAULT -> KeyVaultScreen(viewModel = viewModel)
                ConsoleTab.AUDIT_RISK -> AuditAndRiskScreen(viewModel = viewModel)
                ConsoleTab.API_SDKS -> DeveloperApiScreen(viewModel = viewModel)
            }
        }
    }
}
