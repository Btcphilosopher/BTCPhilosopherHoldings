-- LONDON CIPHER — Operational Metadata Schema (PostgreSQL 16+)
-- Strictly stores public keys, opaque file references, ciphertext commitments,
-- encrypted metadata envelopes, wrapped key envelopes, and redacted audit events.
-- NEVER stores plaintext files, filenames in cleartext, private keys, or DEKs.

CREATE TABLE users (
    user_id                 TEXT PRIMARY KEY,
    display_name            TEXT NOT NULL,
    handle                  TEXT NOT NULL UNIQUE,
    role_label              TEXT NOT NULL,
    auth_public_jwk         JSONB NOT NULL,
    registry_public_jwk     JSONB NOT NULL,
    enc_public_jwk          JSONB NOT NULL,
    auth_fingerprint        TEXT NOT NULL UNIQUE,
    registry_fingerprint    TEXT NOT NULL UNIQUE,
    enc_fingerprint         TEXT NOT NULL UNIQUE,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE files (
    file_ref                    TEXT PRIMARY KEY,
    owner_user_id               TEXT NOT NULL REFERENCES users(user_id),
    owner_registry_fingerprint  TEXT NOT NULL,
    latest_version_number       INTEGER NOT NULL DEFAULT 1,
    latest_version_id           TEXT NOT NULL,
    lifecycle_status            TEXT NOT NULL CHECK (lifecycle_status IN ('active', 'revoked', 'deleted')),
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE file_versions (
    version_id                  TEXT PRIMARY KEY,
    file_ref                    TEXT NOT NULL REFERENCES files(file_ref) ON DELETE CASCADE,
    version_number              INTEGER NOT NULL,
    owner_user_id               TEXT NOT NULL REFERENCES users(user_id),
    owner_registry_fingerprint  TEXT NOT NULL,
    ciphertext_commitment       CHAR(64) NOT NULL,
    manifest_commitment         CHAR(64) NOT NULL,
    encryption_format_version   TEXT NOT NULL,
    cipher_suite                TEXT NOT NULL,
    chunk_size                  INTEGER NOT NULL,
    total_chunks                INTEGER NOT NULL,
    ciphertext_byte_length      BIGINT NOT NULL,
    encrypted_metadata          JSONB NOT NULL,
    storage_adapter             TEXT NOT NULL CHECK (storage_adapter IN ('local', 's3', 'cas')),
    storage_location            TEXT NOT NULL,
    content_address_cid         TEXT,
    registry_status             TEXT NOT NULL CHECK (registry_status IN ('pending', 'finalised', 'revoked', 'superseded', 'reorganised', 'failed')),
    registry_tx_hash            TEXT,
    registry_block_number       BIGINT,
    malware_scan_status         TEXT NOT NULL DEFAULT 'unscanned_client_encrypted',
    idempotency_key             TEXT UNIQUE,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at                  TIMESTAMPTZ,
    UNIQUE (file_ref, version_number)
);

CREATE TABLE key_envelopes (
    envelope_id                 TEXT PRIMARY KEY,
    file_ref                    TEXT NOT NULL REFERENCES files(file_ref) ON DELETE CASCADE,
    version_id                  TEXT NOT NULL REFERENCES file_versions(version_id) ON DELETE CASCADE,
    recipient_id                TEXT NOT NULL REFERENCES users(user_id),
    granted_by_user_id          TEXT NOT NULL REFERENCES users(user_id),
    key_algorithm               TEXT NOT NULL,
    ephemeral_public_jwk        JSONB NOT NULL,
    salt_hex                    TEXT NOT NULL,
    iv_hex                      TEXT NOT NULL,
    wrapped_dek_hex             TEXT NOT NULL,
    recipient_enc_fingerprint   TEXT NOT NULL,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at                  TIMESTAMPTZ,
    revoked_at                  TIMESTAMPTZ,
    revoked_by_user_id          TEXT REFERENCES users(user_id),
    retrieval_count             INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE share_invitations (
    invite_id           TEXT PRIMARY KEY,
    file_ref            TEXT NOT NULL REFERENCES files(file_ref) ON DELETE CASCADE,
    version_id          TEXT NOT NULL REFERENCES file_versions(version_id) ON DELETE CASCADE,
    recipient_id        TEXT NOT NULL REFERENCES users(user_id),
    created_by_user_id  TEXT NOT NULL REFERENCES users(user_id),
    envelope_id         TEXT NOT NULL REFERENCES key_envelopes(envelope_id) ON DELETE CASCADE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at          TIMESTAMPTZ NOT NULL,
    revoked_at          TIMESTAMPTZ,
    accepted_at         TIMESTAMPTZ,
    note                TEXT NOT NULL DEFAULT ''
);

CREATE TABLE audit_events (
    event_id        TEXT PRIMARY KEY,
    event_type      TEXT NOT NULL,
    actor_user_id   TEXT NOT NULL,
    file_ref        TEXT,
    version_id      TEXT,
    summary         TEXT NOT NULL,
    outcome         TEXT NOT NULL CHECK (outcome IN ('success', 'rejected', 'warning')),
    tx_hash         TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_file_versions_file_ref ON file_versions(file_ref);
CREATE INDEX idx_key_envelopes_recipient ON key_envelopes(recipient_id, version_id);
CREATE INDEX idx_audit_events_created_at ON audit_events(created_at DESC);
