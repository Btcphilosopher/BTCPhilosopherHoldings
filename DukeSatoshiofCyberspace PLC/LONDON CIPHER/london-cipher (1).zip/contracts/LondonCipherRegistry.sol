// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title LondonCipherRegistry
 * @notice Minimal integrity and ownership registry for client-encrypted files.
 *         Records opaque random file references, ciphertext commitments, encrypted
 *         manifest commitments, and authorised version/lifecycle events.
 *         NEVER stores filenames, emails, plaintext hashes, or decryption keys.
 */
contract LondonCipherRegistry {
    enum LifecycleStatus {
        Active,
        Revoked,
        Superseded,
        Deleted
    }

    struct VersionCommitment {
        bytes32 ciphertextCommitment;
        bytes32 manifestCommitment;
        bytes16 formatVersion;
        uint64 publishedAt;
        LifecycleStatus status;
    }

    struct FileEntry {
        address owner;
        uint32 latestVersion;
        LifecycleStatus status;
        bool exists;
    }

    mapping(bytes16 => FileEntry) private _files;
    mapping(bytes16 => mapping(uint32 => VersionCommitment)) private _versions;

    event FileRegistered(
        bytes16 indexed fileRef,
        address indexed owner,
        uint32 indexed versionNumber,
        bytes32 ciphertextCommitment,
        bytes32 manifestCommitment,
        bytes16 formatVersion
    );

    event VersionPublished(
        bytes16 indexed fileRef,
        uint32 indexed versionNumber,
        bytes32 ciphertextCommitment,
        bytes32 manifestCommitment,
        bytes16 formatVersion
    );

    event LifecycleUpdated(
        bytes16 indexed fileRef,
        uint32 indexed versionNumber,
        LifecycleStatus status
    );

    error FileAlreadyRegistered(bytes16 fileRef);
    error FileNotFound(bytes16 fileRef);
    error NotFileOwner(bytes16 fileRef, address caller);
    error InvalidCommitment();

    modifier onlyFileOwner(bytes16 fileRef) {
        FileEntry storage entry = _files[fileRef];
        if (!entry.exists) revert FileNotFound(fileRef);
        if (entry.owner != msg.sender) revert NotFileOwner(fileRef, msg.sender);
        _;
    }

    function registerFile(
        bytes16 fileRef,
        bytes32 ciphertextCommitment,
        bytes32 manifestCommitment,
        bytes16 formatVersion
    ) external {
        if (_files[fileRef].exists) revert FileAlreadyRegistered(fileRef);
        if (ciphertextCommitment == bytes32(0)) revert InvalidCommitment();

        _files[fileRef] = FileEntry({
            owner: msg.sender,
            latestVersion: 1,
            status: LifecycleStatus.Active,
            exists: true
        });

        _versions[fileRef][1] = VersionCommitment({
            ciphertextCommitment: ciphertextCommitment,
            manifestCommitment: manifestCommitment,
            formatVersion: formatVersion,
            publishedAt: uint64(block.timestamp),
            status: LifecycleStatus.Active
        });

        emit FileRegistered(
            fileRef,
            msg.sender,
            1,
            ciphertextCommitment,
            manifestCommitment,
            formatVersion
        );
    }

    function publishVersion(
        bytes16 fileRef,
        bytes32 ciphertextCommitment,
        bytes32 manifestCommitment,
        bytes16 formatVersion
    ) external onlyFileOwner(fileRef) {
        if (ciphertextCommitment == bytes32(0)) revert InvalidCommitment();

        FileEntry storage entry = _files[fileRef];
        uint32 prevVersion = entry.latestVersion;
        _versions[fileRef][prevVersion].status = LifecycleStatus.Superseded;

        uint32 nextVersion = prevVersion + 1;
        entry.latestVersion = nextVersion;
        entry.status = LifecycleStatus.Active;

        _versions[fileRef][nextVersion] = VersionCommitment({
            ciphertextCommitment: ciphertextCommitment,
            manifestCommitment: manifestCommitment,
            formatVersion: formatVersion,
            publishedAt: uint64(block.timestamp),
            status: LifecycleStatus.Active
        });

        emit VersionPublished(
            fileRef,
            nextVersion,
            ciphertextCommitment,
            manifestCommitment,
            formatVersion
        );
    }

    function updateLifecycleStatus(
        bytes16 fileRef,
        uint32 versionNumber,
        LifecycleStatus newStatus
    ) external onlyFileOwner(fileRef) {
        _versions[fileRef][versionNumber].status = newStatus;
        if (versionNumber == _files[fileRef].latestVersion) {
            _files[fileRef].status = newStatus;
        }
        emit LifecycleUpdated(fileRef, versionNumber, newStatus);
    }

    function getFile(bytes16 fileRef) external view returns (FileEntry memory) {
        return _files[fileRef];
    }

    function getVersion(
        bytes16 fileRef,
        uint32 versionNumber
    ) external view returns (VersionCommitment memory) {
        return _versions[fileRef][versionNumber];
    }
}
