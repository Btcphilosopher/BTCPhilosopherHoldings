import { ChangeDetectionStrategy, Component, inject, OnInit, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { CipherVault } from './services/cipher-vault';
import { IdentitiesView } from './views/identities-view';
import { RegistryView } from './views/registry-view';
import { SecurityView } from './views/security-view';
import { VaultView } from './views/vault-view';

type WorkspaceTab = 'vault' | 'identities' | 'registry' | 'security';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [MatIconModule, VaultView, IdentitiesView, RegistryView, SecurityView],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  readonly vault = inject(CipherVault);
  readonly activeTab = signal<WorkspaceTab>('vault');
  readonly mobileNavOpen = signal(false);

  ngOnInit(): void {
    void this.vault.bootstrap();
  }

  selectTab(tab: WorkspaceTab): void {
    this.activeTab.set(tab);
    this.mobileNavOpen.set(false);
  }

  tabTitle(): string {
    switch (this.activeTab()) {
      case 'vault':
        return 'File Vault';
      case 'identities':
        return 'Identities & Keys';
      case 'registry':
        return 'Registry Ledger';
      case 'security':
        return 'Audit & Security';
    }
  }

  initials(name: string): string {
    return name
      .split(' ')
      .map((p) => p[0] ?? '')
      .join('')
      .slice(0, 2)
      .toUpperCase();
  }

  async onSwitchUser(event: Event): Promise<void> {
    const uid = (event.target as HTMLSelectElement).value;
    await this.vault.switchActiveUser(uid);
  }
}
