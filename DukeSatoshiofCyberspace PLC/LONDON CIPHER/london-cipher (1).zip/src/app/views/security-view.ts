import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { CipherVault } from '../services/cipher-vault';

@Component({
  selector: 'app-security-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './security-view.html',
})
export class SecurityView {
  readonly vault = inject(CipherVault);
  readonly outcomeFilter = signal<'all' | 'success' | 'rejected' | 'warning'>('all');

  readonly filteredEvents = computed(() => {
    const f = this.outcomeFilter();
    const events = this.vault.auditEvents();
    if (f === 'all') return events;
    return events.filter((e) => e.outcome === f);
  });

  readonly demoSteps = [
    { step: '01', label: 'Two+ demonstration users provisioned (Eleanor Vance, Marcus Sterling, Julian Croft)' },
    { step: '02', label: 'Separate 3-role P-256 keys generated per user (Auth, Registry Signing, File-Key ECDH)' },
    { step: '03', label: 'Encrypt a file locally with LCFR-v1 chunked AES-256-GCM + HKDF nonces' },
    { step: '04', label: 'Upload only opaque ciphertext & encrypted metadata manifest to Local / S3 / CAS' },
    { step: '05', label: 'Register signed ciphertext commitment on the Registry Ledger' },
    { step: '06', label: 'Confirm block finality (or submit Pending and mine manually)' },
    { step: '07', label: 'Share an expiring ECDH-wrapped key envelope after verifying recipient fingerprint' },
    { step: '08', label: 'Switch to Marcus Sterling, verify commitment, download & decrypt locally' },
    { step: '09', label: 'Switch to Julian Croft (unauthorised) and verify 403 rejection below' },
    { step: '10', label: 'Tamper 1 byte of ciphertext on File Vault and confirm Verification rejects it' },
    { step: '11', label: 'Publish Version 2 as Eleanor with a fresh random DEK' },
    { step: '12', label: 'Revoke Marcus access and confirm future envelope & download requests fail' },
    { step: '13', label: 'Demonstrate limits of revocation using Marcus cached offline copy' },
    { step: '14', label: 'Export PBKDF2 key backup, wipe local keys, and restore from backup' },
  ];

  formatTime(iso: string): string {
    return iso.replace('T', ' ').slice(0, 19) + ' UTC';
  }

  async runCrossUserRejectionProbe(): Promise<void> {
    const allFiles = this.vault.registryState().transactions;
    if (allFiles.length === 0) {
      this.vault.setBanner('warning', 'Encrypt and register at least one file as Eleanor first.');
      return;
    }
    const targetRef = allFiles[0].fileRef;
    const ownerFiles = this.vault.files().find((f) => f.fileRef === targetRef);
    const verId = ownerFiles?.latestVersionId ?? 'ver_probe_unauthorised';
    await this.vault.testCrossUserAccess(targetRef, verId);
  }
}
