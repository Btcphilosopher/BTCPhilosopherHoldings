import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { CipherVault } from '../services/cipher-vault';

@Component({
  selector: 'app-registry-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './registry-view.html',
})
export class RegistryView {
  readonly vault = inject(CipherVault);
  readonly lookupRef = signal('');

  readonly filteredTransactions = computed(() => {
    const q = this.lookupRef().trim().toLowerCase();
    const list = this.vault.registryState().transactions;
    if (!q) return list;
    return list.filter(
      (tx) =>
        tx.fileRef.toLowerCase().includes(q) ||
        tx.txHash.toLowerCase().includes(q) ||
        tx.ciphertextCommitment.toLowerCase().includes(q),
    );
  });

  onLookupInput(event: Event): void {
    this.lookupRef.set((event.target as HTMLInputElement).value);
  }

  shortHash(hash: string | null): string {
    if (!hash) return 'Pending…';
    return `${hash.slice(0, 14)}…${hash.slice(-8)}`;
  }

  formatTime(iso: string | null): string {
    if (!iso) return '—';
    return iso.replace('T', ' ').slice(0, 19) + ' UTC';
  }
}
