import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { EncryptedKeyBackup } from '../../shared/cipher-types';
import { CipherVault } from '../services/cipher-vault';

@Component({
  selector: 'app-identities-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './identities-view.html',
})
export class IdentitiesView {
  readonly vault = inject(CipherVault);

  readonly backupPassphrase = signal('Chancery-Vault-2026!');
  readonly restorePassphrase = signal('Chancery-Vault-2026!');
  readonly pendingBackupFile = signal<EncryptedKeyBackup | null>(null);
  readonly pendingBackupFilename = signal<string>('');

  readonly newDisplayName = signal('');
  readonly newHandle = signal('');
  readonly newRoleLabel = signal('Legal Reviewer');

  readonly otherUsers = computed(() => {
    const uid = this.vault.activeUserId();
    return this.vault.users().filter((u) => u.userId !== uid);
  });

  isTrusted(recipientId: string): { trusted: boolean; mismatch: boolean; method: string } {
    const bundle = this.vault.activeKeyBundle();
    const profile = this.vault.users().find((u) => u.userId === recipientId);
    if (!bundle || !profile) return { trusted: false, mismatch: false, method: '' };
    const entry = bundle.trustedDirectory[recipientId];
    if (!entry) return { trusted: false, mismatch: false, method: '' };
    return {
      trusted: entry.encFingerprint === profile.encFingerprint,
      mismatch: entry.encFingerprint !== profile.encFingerprint,
      method: entry.verificationMethod,
    };
  }

  onBackupPassphraseInput(event: Event): void {
    this.backupPassphrase.set((event.target as HTMLInputElement).value);
  }

  onRestorePassphraseInput(event: Event): void {
    this.restorePassphrase.set((event.target as HTMLInputElement).value);
  }

  async onExportBackup(): Promise<void> {
    await this.vault.exportKeyBackup(this.vault.activeUserId(), this.backupPassphrase());
  }

  async onBackupFileSelected(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as EncryptedKeyBackup;
      this.pendingBackupFile.set(parsed);
      this.pendingBackupFilename.set(file.name);
      this.vault.setBanner('info', `Loaded encrypted backup "${file.name}". Enter passphrase to restore.`);
    } catch {
      this.vault.setBanner('error', 'Invalid backup JSON file.');
    }
  }

  async onRestoreBackup(): Promise<void> {
    const backup = this.pendingBackupFile();
    if (!backup) {
      this.vault.setBanner('warning', 'Select a .lcbackup.json file first.');
      return;
    }
    const ok = await this.vault.restoreFromBackup(backup, this.restorePassphrase());
    if (ok) {
      this.pendingBackupFile.set(null);
      this.pendingBackupFilename.set('');
    }
  }

  async onCreateIdentity(): Promise<void> {
    if (!this.newDisplayName().trim() || !this.newHandle().trim()) {
      this.vault.setBanner('warning', 'Provide both a display name and handle.');
      return;
    }
    await this.vault.createAdditionalIdentity({
      displayName: this.newDisplayName(),
      handle: this.newHandle(),
      roleLabel: this.newRoleLabel(),
    });
    this.newDisplayName.set('');
    this.newHandle.set('');
  }

  onNewNameInput(e: Event): void {
    this.newDisplayName.set((e.target as HTMLInputElement).value);
  }
  onNewHandleInput(e: Event): void {
    this.newHandle.set((e.target as HTMLInputElement).value);
  }
  onNewRoleInput(e: Event): void {
    this.newRoleLabel.set((e.target as HTMLInputElement).value);
  }
}
