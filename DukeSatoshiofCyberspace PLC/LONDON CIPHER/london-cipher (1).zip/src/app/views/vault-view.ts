import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { EncryptedFileRecord, FileVersionRecord, StorageAdapterType } from '../../shared/cipher-types';
import { CipherVault } from '../services/cipher-vault';

@Component({
  selector: 'app-vault-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  templateUrl: './vault-view.html',
})
export class VaultView {
  readonly vault = inject(CipherVault);

  readonly dragActive = signal(false);
  readonly selectedAdapter = signal<StorageAdapterType>('s3');
  readonly deferFinality = signal(false);
  readonly searchQuery = signal('');
  readonly statusFilter = signal<'all' | 'active' | 'revoked'>('all');

  readonly selectedFileRef = signal<string | null>(null);
  readonly publishTargetFileRef = signal<string | null>(null);

  // Share form signals
  readonly shareRecipientId = signal<string>('usr_marcus');
  readonly shareExpiryMinutes = signal<number>(60);
  readonly shareNote = signal<string>('Confidential counsel review copy');
  readonly simulateKeySubstitution = signal(false);

  // Selected file derived state
  readonly filteredFiles = computed(() => {
    const q = this.searchQuery().trim().toLowerCase();
    const filter = this.statusFilter();
    const metaCache = this.vault.decryptedNamesCache();

    return this.vault.files().filter((f) => {
      if (filter === 'active' && f.lifecycleStatus !== 'active') return false;
      if (filter === 'revoked' && f.lifecycleStatus === 'active') return false;
      if (!q) return true;
      const latestMeta = metaCache[f.latestVersionId];
      const nameMatch = latestMeta?.originalName.toLowerCase().includes(q) ?? false;
      const refMatch = f.fileRef.toLowerCase().includes(q);
      return nameMatch || refMatch;
    });
  });

  readonly selectedFile = computed<EncryptedFileRecord | null>(() => {
    const ref = this.selectedFileRef();
    const all = this.vault.files();
    if (all.length === 0) return null;
    if (ref) {
      const found = all.find((f) => f.fileRef === ref);
      if (found) return found;
    }
    return all[0];
  });

  readonly otherRecipients = computed(() => {
    const uid = this.vault.activeUserId();
    return this.vault.users().filter((u) => u.userId !== uid);
  });

  readonly activeUserObtainedArtifacts = computed(() => {
    const uid = this.vault.activeUserId();
    return this.vault.obtainedArtifacts().filter((a) => a.holderUserId === uid);
  });

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    this.dragActive.set(true);
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    this.dragActive.set(false);
  }

  async onDrop(event: DragEvent): Promise<void> {
    event.preventDefault();
    this.dragActive.set(false);
    const list = event.dataTransfer?.files;
    if (!list || list.length === 0) return;
    await this.handleFiles(Array.from(list));
  }

  async onFileInputChange(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;
    const files = Array.from(input.files);
    input.value = '';
    await this.handleFiles(files);
  }

  async handleFiles(files: File[]): Promise<void> {
    const targetRef = this.publishTargetFileRef();
    await this.vault.encryptAndUploadFiles({
      selectedFiles: files,
      storageAdapter: this.selectedAdapter(),
      targetFileRef: targetRef ?? undefined,
      deferFinality: this.deferFinality(),
    });
    this.publishTargetFileRef.set(null);
  }

  async createSyntheticSampleFile(): Promise<void> {
    const content = [
      'LONDON CIPHER — CONFIDENTIAL BRIEFING MEMORANDUM',
      `Issued By: ${this.vault.activeUserProfile()?.displayName ?? 'Vault Owner'}`,
      `Timestamp: ${new Date().toISOString()}`,
      '',
      'Clause 1. All client documents are encrypted prior to leaving the workstation.',
      'Clause 2. Storage providers and metadata databases observe only opaque ciphertext.',
    ].join('\n');
    const file = new File([content], 'chancery-briefing-note.txt', { type: 'text/plain' });
    await this.handleFiles([file]);
  }

  async createEmptyZeroByteSample(): Promise<void> {
    const emptyFile = new File([], 'zero-byte-attestation.txt', { type: 'text/plain' });
    await this.handleFiles([emptyFile]);
  }

  setTargetForNewVersion(fileRef: string): void {
    this.publishTargetFileRef.set(fileRef);
    this.vault.setBanner(
      'info',
      `Next uploaded file will be published as a new encrypted version under ${fileRef} with a fresh 256-bit DEK.`,
    );
  }

  clearPublishTarget(): void {
    this.publishTargetFileRef.set(null);
  }

  displayFilename(file: EncryptedFileRecord): string {
    const meta = this.vault.decryptedNamesCache()[file.latestVersionId];
    return meta ? meta.originalName : `Encrypted Document (${file.fileRef.slice(0, 12)})`;
  }

  displayVersionFilename(version: FileVersionRecord): string {
    const meta = this.vault.decryptedNamesCache()[version.versionId];
    return meta ? meta.originalName : 'Encrypted metadata (decrypt to reveal)';
  }

  userDisplayName(userId: string): string {
    return this.vault.users().find((u) => u.userId === userId)?.displayName ?? userId;
  }

  formatBytes(bytes: number): string {
    if (bytes === 0) return '0 B';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KiB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MiB`;
  }

  shortHex(hex: string, len = 14): string {
    if (!hex) return '—';
    return `${hex.slice(0, len)}…${hex.slice(-6)}`;
  }

  formatTime(iso: string | null): string {
    if (!iso) return '—';
    return iso.replace('T', ' ').slice(0, 19) + ' UTC';
  }

  isEnvelopeExpired(expiresAt: string | null): boolean {
    if (!expiresAt) return false;
    return Date.now() > Date.parse(expiresAt);
  }

  async onShareSubmit(fileRef: string, versionId: string): Promise<void> {
    await this.vault.shareFileWithRecipient({
      fileRef,
      versionId,
      recipientId: this.shareRecipientId(),
      expiresInMinutes: this.shareExpiryMinutes(),
      note: this.shareNote(),
      simulateKeySubstitution: this.simulateKeySubstitution(),
    });
  }

  onSearchInput(event: Event): void {
    this.searchQuery.set((event.target as HTMLInputElement).value);
  }

  onAdapterChange(adapter: StorageAdapterType): void {
    this.selectedAdapter.set(adapter);
  }

  onRecipientSelect(event: Event): void {
    this.shareRecipientId.set((event.target as HTMLSelectElement).value);
  }

  onExpirySelect(event: Event): void {
    this.shareExpiryMinutes.set(Number((event.target as HTMLSelectElement).value));
  }

  onShareNoteInput(event: Event): void {
    this.shareNote.set((event.target as HTMLInputElement).value);
  }

  toggleDeferFinality(event: Event): void {
    this.deferFinality.set((event.target as HTMLInputElement).checked);
  }

  toggleSimulateKeySub(event: Event): void {
    this.simulateKeySubstitution.set((event.target as HTMLInputElement).checked);
  }
}
