import { isPlatformBrowser } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { computed, inject, Injectable, PLATFORM_ID, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import {
  bytesToHex,
  canonicalRegistrySignPayload,
  CipherError,
  createEncryptedKeyBackup,
  decryptFileStaged,
  encryptFileChunked,
  generateRandomFileRef,
  generateUserKeyBundle,
  hexToBytes,
  LCFR_CIPHER_SUITE_LABEL,
  LCFR_DEFAULT_CHUNK_SIZE,
  LCFR_FORMAT_LABEL,
  randomBytes,
  restoreEncryptedKeyBackup,
  sanitizeDownloadFilename,
  signWithEcdsaP256,
  unwrapDekFromEnvelope,
  wrapDekForRecipient,
} from '../../shared/cipher-core';
import {
  AuditEventRecord,
  EncryptedFileRecord,
  EncryptedKeyBackup,
  EncryptionProgress,
  KeyEnvelopeRecord,
  LocalUserKeyBundle,
  PlaintextFileMetadata,
  RegistryBlockRecord,
  RegistryTransactionRecord,
  StorageAdapterType,
  UserPublicProfile,
  VerificationReport,
} from '../../shared/cipher-types';

const STORAGE_KEY_BUNDLES = 'lcfr_local_key_bundles_v1';
const STORAGE_KEY_ACTIVE_USER = 'lcfr_active_user_v1';
const STORAGE_KEY_LOCAL_META = 'lcfr_local_file_meta_v1';

const UPLOAD_PART_SIZE = 256 * 1024; // 256 KiB upload part chunks

export interface DecryptedPreviewState {
  fileRef: string;
  versionId: string;
  versionNumber: number;
  sanitizedFilename: string;
  mimeType: string;
  byteLength: number;
  textSnippet: string | null;
  isActiveContentBlocked: boolean;
  report: VerificationReport;
  decryptedBytes: Uint8Array;
  decryptedAt: string;
}

export interface ObtainedKeyArtifact {
  fileRef: string;
  versionId: string;
  versionNumber: number;
  holderUserId: string;
  dekHex: string;
  ciphertextBytes: Uint8Array;
  encryptedMetadata: EncryptedFileRecord['versions'][number]['encryptedMetadata'];
  ciphertextCommitment: string;
  obtainedAt: string;
}

export interface UploadTaskStatus {
  id: string;
  filename: string;
  totalBytes: number;
  stage: 'encrypting' | 'uploading' | 'registering' | 'complete' | 'aborted' | 'error';
  progressPercent: number;
  message: string;
}

const ACTIVE_CONTENT_EXTENSIONS = ['.html', '.htm', '.svg', '.js', '.mjs', '.xhtml', '.xml'];

@Injectable({ providedIn: 'root' })
export class CipherVault {
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly isBrowser = isPlatformBrowser(this.platformId);

  readonly initialized = signal(false);
  readonly busy = signal(false);
  readonly statusBanner = signal<{ type: 'info' | 'success' | 'warning' | 'error'; text: string } | null>(
    null,
  );

  readonly activeUserId = signal<string>('usr_eleanor');
  readonly users = signal<UserPublicProfile[]>([]);
  readonly keyBundles = signal<Record<string, LocalUserKeyBundle>>({});
  readonly sessionTokens = signal<Record<string, { token: string; expiresAt: string }>>({});

  readonly files = signal<EncryptedFileRecord[]>([]);
  readonly decryptedNamesCache = signal<Record<string, PlaintextFileMetadata>>({});
  readonly uploadTasks = signal<UploadTaskStatus[]>([]);
  readonly lastDecrypted = signal<DecryptedPreviewState | null>(null);
  readonly obtainedArtifacts = signal<ObtainedKeyArtifact[]>([]);

  readonly registryState = signal<{
    chainId: number;
    networkName: string;
    latestBlockNumber: number;
    blocks: RegistryBlockRecord[];
    transactions: RegistryTransactionRecord[];
  }>({
    chainId: 31337,
    networkName: 'London Cipher Local Registry Chain',
    latestBlockNumber: 0,
    blocks: [],
    transactions: [],
  });

  readonly storageInventory = signal<{
    localKeys: string[];
    s3Keys: string[];
    casKeys: string[];
    scannerHook: { modeName: string };
  }>({
    localKeys: [],
    s3Keys: [],
    casKeys: [],
    scannerHook: { modeName: 'ClientEncryptedUnscannedAdapter' },
  });

  readonly auditEvents = signal<AuditEventRecord[]>([]);

  readonly activeUserProfile = computed(() => {
    const uid = this.activeUserId();
    return this.users().find((u) => u.userId === uid) ?? null;
  });

  readonly activeKeyBundle = computed(() => {
    const uid = this.activeUserId();
    return this.keyBundles()[uid] ?? null;
  });

  readonly activeSession = computed(() => {
    const uid = this.activeUserId();
    return this.sessionTokens()[uid] ?? null;
  });

  private activeUploadAbortController: AbortController | null = null;

  async bootstrap(): Promise<void> {
    if (!this.isBrowser || this.initialized()) return;
    this.busy.set(true);
    try {
      const bundles = this.loadLocalBundles();
      const demoDefs = [
        {
          userId: 'usr_eleanor',
          displayName: 'Eleanor Vance',
          handle: 'evance@londoncipher.demo',
          roleLabel: 'Vault Owner (Synthetic)',
        },
        {
          userId: 'usr_marcus',
          displayName: 'Marcus Sterling',
          handle: 'msterling@londoncipher.demo',
          roleLabel: 'Authorised Recipient (Synthetic)',
        },
        {
          userId: 'usr_julian',
          displayName: 'Julian Croft',
          handle: 'jcroft@londoncipher.demo',
          roleLabel: 'External Party (Unauthorised)',
        },
      ];

      let createdNew = false;
      for (const def of demoDefs) {
        if (!bundles[def.userId]) {
          bundles[def.userId] = await generateUserKeyBundle(def);
          createdNew = true;
        }
      }

      if (
        createdNew &&
        bundles['usr_eleanor'] &&
        bundles['usr_marcus'] &&
        !bundles['usr_eleanor'].trustedDirectory['usr_marcus']
      ) {
        bundles['usr_eleanor'].trustedDirectory['usr_marcus'] = {
          userId: 'usr_marcus',
          displayName: 'Marcus Sterling',
          encFingerprint: bundles['usr_marcus'].encFingerprint,
          registryFingerprint: bundles['usr_marcus'].registryFingerprint,
          verifiedAt: new Date().toISOString(),
          verificationMethod: 'confirmed',
        };
      }

      this.saveLocalBundles(bundles);
      this.keyBundles.set(bundles);
      this.decryptedNamesCache.set(this.loadLocalMetaCache());

      for (const b of Object.values(bundles)) {
        await this.registerPublicProfile(b);
      }

      const savedUid = localStorage.getItem(STORAGE_KEY_ACTIVE_USER);
      if (savedUid && bundles[savedUid]) {
        this.activeUserId.set(savedUid);
      }

      await this.authenticateUser(this.activeUserId());
      await this.refreshAll();
      this.initialized.set(true);
    } catch (err) {
      this.setBanner('error', this.extractError(err));
    } finally {
      this.busy.set(false);
    }
  }

  private loadLocalBundles(): Record<string, LocalUserKeyBundle> {
    if (!this.isBrowser) return {};
    try {
      const raw = localStorage.getItem(STORAGE_KEY_BUNDLES);
      return raw ? (JSON.parse(raw) as Record<string, LocalUserKeyBundle>) : {};
    } catch {
      return {};
    }
  }

  private saveLocalBundles(bundles: Record<string, LocalUserKeyBundle>): void {
    if (!this.isBrowser) return;
    localStorage.setItem(STORAGE_KEY_BUNDLES, JSON.stringify(bundles));
  }

  private loadLocalMetaCache(): Record<string, PlaintextFileMetadata> {
    if (!this.isBrowser) return {};
    try {
      const raw = localStorage.getItem(STORAGE_KEY_LOCAL_META);
      return raw ? (JSON.parse(raw) as Record<string, PlaintextFileMetadata>) : {};
    } catch {
      return {};
    }
  }

  private cacheLocalMeta(versionId: string, meta: PlaintextFileMetadata): void {
    const next = { ...this.decryptedNamesCache(), [versionId]: meta };
    this.decryptedNamesCache.set(next);
    if (this.isBrowser) {
      localStorage.setItem(STORAGE_KEY_LOCAL_META, JSON.stringify(next));
    }
  }

  private async registerPublicProfile(b: LocalUserKeyBundle): Promise<void> {
    const profile: UserPublicProfile = {
      userId: b.userId,
      displayName: b.displayName,
      handle: b.handle,
      roleLabel: b.roleLabel,
      authPublicJwk: b.authPublicJwk,
      registryPublicJwk: b.registryPublicJwk,
      encPublicJwk: b.encPublicJwk,
      authFingerprint: b.authFingerprint,
      registryFingerprint: b.registryFingerprint,
      encFingerprint: b.encFingerprint,
      createdAt: new Date().toISOString(),
    };
    await firstValueFrom(this.http.post('/api/users/register', profile));
  }

  async authenticateUser(userId: string): Promise<void> {
    const bundle = this.keyBundles()[userId];
    if (!bundle) {
      this.setBanner(
        'warning',
        `No local Auth private key found for ${userId}. Restore from your encrypted key backup.`,
      );
      return;
    }
    const ch = await firstValueFrom(
      this.http.post<{ challengeId: string; nonce: string; expiresAt: string }>(
        '/api/auth/challenge',
        { userId },
      ),
    );
    const payload = `LCFR-AUTH-v1|${ch.challengeId}|${userId}|${ch.nonce}`;
    const signatureHex = await signWithEcdsaP256(bundle.authPrivateJwk, payload);
    const sess = await firstValueFrom(
      this.http.post<{ token: string; userId: string; expiresAt: string }>('/api/auth/verify', {
        challengeId: ch.challengeId,
        signatureHex,
      }),
    );
    this.sessionTokens.update((prev) => ({
      ...prev,
      [userId]: { token: sess.token, expiresAt: sess.expiresAt },
    }));
  }

  async switchActiveUser(userId: string): Promise<void> {
    this.activeUserId.set(userId);
    if (this.isBrowser) {
      localStorage.setItem(STORAGE_KEY_ACTIVE_USER, userId);
    }
    this.lastDecrypted.set(null);
    const bundle = this.keyBundles()[userId];
    if (!bundle) {
      this.setBanner(
        'warning',
        `Switched to ${userId}, but local keys are wiped! Use Key Backup Recovery to restore decryption ability.`,
      );
      return;
    }
    if (!this.sessionTokens()[userId]) {
      await this.authenticateUser(userId);
    }
    await this.refreshAll();
    this.setBanner('info', `Active identity switched to ${bundle.displayName}.`);
  }

  async createAdditionalIdentity(params: {
    displayName: string;
    handle: string;
    roleLabel: string;
  }): Promise<void> {
    const userId = `usr_${bytesToHex(randomBytes(4))}`;
    const bundle = await generateUserKeyBundle({
      userId,
      displayName: params.displayName.trim(),
      handle: params.handle.trim(),
      roleLabel: params.roleLabel.trim() || 'Collaborator',
    });
    const next = { ...this.keyBundles(), [userId]: bundle };
    this.keyBundles.set(next);
    this.saveLocalBundles(next);
    await this.registerPublicProfile(bundle);
    await this.authenticateUser(userId);
    await this.refreshAll();
    this.setBanner('success', `Generated 3-role P-256 identity for ${bundle.displayName}.`);
  }

  private authHeaders(forUserId?: string): HttpHeaders {
    const uid = forUserId ?? this.activeUserId();
    const token = this.sessionTokens()[uid]?.token ?? '';
    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
  }

  async refreshAll(): Promise<void> {
    const usersRes = await firstValueFrom(
      this.http.get<{ users: UserPublicProfile[] }>('/api/users'),
    );
    this.users.set(usersRes.users);

    const regRes = await firstValueFrom(
      this.http.get<ReturnType<typeof this.registryState>>('/api/registry'),
    );
    this.registryState.set(regRes);

    const uid = this.activeUserId();
    if (!this.sessionTokens()[uid]) {
      this.files.set([]);
      return;
    }

    const [filesRes, invRes, auditRes] = await Promise.all([
      firstValueFrom(
        this.http.get<{ files: EncryptedFileRecord[] }>('/api/files', {
          headers: this.authHeaders(uid),
        }),
      ),
      firstValueFrom(
        this.http.get<ReturnType<typeof this.storageInventory>>('/api/storage/inventory', {
          headers: this.authHeaders(uid),
        }),
      ),
      firstValueFrom(
        this.http.get<{ events: AuditEventRecord[] }>('/api/audit', {
          headers: this.authHeaders(uid),
        }),
      ),
    ]);

    this.files.set(filesRes.files);
    this.storageInventory.set(invRes);
    this.auditEvents.set(auditRes.events);
  }

  // ---------- Batch Client-Side Encryption + Chunked Upload + Registry Commit ----------

  async encryptAndUploadFiles(params: {
    selectedFiles: File[];
    storageAdapter: StorageAdapterType;
    targetFileRef?: string;
    deferFinality?: boolean;
  }): Promise<void> {
    const uid = this.activeUserId();
    const bundle = this.keyBundles()[uid];
    if (!bundle) {
      this.setBanner('error', 'No local keys loaded for active user.');
      return;
    }
    if (!this.sessionTokens()[uid]) {
      await this.authenticateUser(uid);
    }

    this.activeUploadAbortController = new AbortController();
    const signal = this.activeUploadAbortController.signal;

    for (const file of params.selectedFiles) {
      const taskId = `tsk_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      this.upsertUploadTask({
        id: taskId,
        filename: file.name,
        totalBytes: file.size,
        stage: 'encrypting',
        progressPercent: 0,
        message: 'Generating fresh 256-bit DEK and encrypting chunks locally…',
      });

      let activeUploadId: string | null = null;
      try {
        const fileRef = params.targetFileRef ?? generateRandomFileRef();
        const versionId = `ver_${bytesToHex(randomBytes(8))}`;
        const existingFile = params.targetFileRef
          ? this.files().find((f) => f.fileRef === params.targetFileRef)
          : undefined;
        const nextVersionNumber = existingFile ? existingFile.latestVersionNumber + 1 : 1;

        const encResult = await encryptFileChunked({
          blob: file,
          originalName: file.name,
          mimeType: file.type || 'application/octet-stream',
          chunkSize: LCFR_DEFAULT_CHUNK_SIZE,
          signal,
          onProgress: (prog: EncryptionProgress) => {
            this.upsertUploadTask({
              id: taskId,
              filename: file.name,
              totalBytes: file.size,
              stage: 'encrypting',
              progressPercent: Math.max(5, Math.round(prog.percent * 0.45)),
              message: `Encrypting chunk ${prog.chunkIndex}/${prog.totalChunks} (AES-256-GCM)…`,
            });
          },
        });

        const ownerWrapped = await wrapDekForRecipient({
          dekBytes: encResult.dekBytes,
          fileRef,
          versionId,
          recipientId: uid,
          recipientEncPublicJwk: bundle.encPublicJwk,
          expectedRecipientFingerprint: bundle.encFingerprint,
        });

        const totalParts = Math.max(1, Math.ceil(encResult.ciphertext.byteLength / UPLOAD_PART_SIZE));
        const initRes = await firstValueFrom(
          this.http.post<{ uploadId: string }>(
            '/api/uploads/init',
            { storageAdapter: params.storageAdapter, totalParts },
            { headers: this.authHeaders(uid) },
          ),
        );
        activeUploadId = initRes.uploadId;

        for (let partIdx = 0; partIdx < totalParts; partIdx++) {
          if (signal.aborted) {
            throw new CipherError('ABORTED', 'Upload cancelled during ciphertext transfer.');
          }
          const start = partIdx * UPLOAD_PART_SIZE;
          const end = Math.min(start + UPLOAD_PART_SIZE, encResult.ciphertext.byteLength);
          const partSlice = encResult.ciphertext.subarray(start, end);
          const partBlob = new Blob([partSlice.slice().buffer], {
            type: 'application/octet-stream',
          });

          await firstValueFrom(
            this.http.put(`/api/uploads/${activeUploadId}/parts/${partIdx}`, partBlob, {
              headers: this.authHeaders(uid).set('Content-Type', 'application/octet-stream'),
            }),
          );

          this.upsertUploadTask({
            id: taskId,
            filename: file.name,
            totalBytes: file.size,
            stage: 'uploading',
            progressPercent: 45 + Math.round(((partIdx + 1) / totalParts) * 40),
            message: `Uploading ciphertext part ${partIdx + 1}/${totalParts} to ${params.storageAdapter.toUpperCase()}…`,
          });
        }

        this.upsertUploadTask({
          id: taskId,
          filename: file.name,
          totalBytes: file.size,
          stage: 'registering',
          progressPercent: 90,
          message: 'Signing commitment and submitting registry transaction…',
        });

        const eventType = existingFile ? 'PUBLISH_VERSION' : 'REGISTER_FILE';
        const canonicalPayload = canonicalRegistrySignPayload({
          eventType,
          fileRef,
          versionNumber: nextVersionNumber,
          ciphertextCommitment: encResult.ciphertextCommitment,
          manifestCommitment: encResult.manifestCommitment,
          formatVersion: LCFR_FORMAT_LABEL,
          lifecycleStatus: 'finalised',
          ownerRegistryFingerprint: bundle.registryFingerprint,
        });
        const registrySignatureHex = await signWithEcdsaP256(
          bundle.registryPrivateJwk,
          canonicalPayload,
        );

        const idempotencyKey = `idem_${fileRef}_v${nextVersionNumber}_${bytesToHex(randomBytes(4))}`;
        await firstValueFrom(
          this.http.post(
            '/api/uploads/finalise',
            {
              idempotencyKey,
              uploadId: activeUploadId,
              fileRef,
              versionId,
              isNewVersion: Boolean(existingFile),
              storageAdapter: params.storageAdapter,
              ciphertextCommitment: encResult.ciphertextCommitment,
              manifestCommitment: encResult.manifestCommitment,
              encryptionFormatVersion: LCFR_FORMAT_LABEL,
              cipherSuite: LCFR_CIPHER_SUITE_LABEL,
              chunkSize: encResult.chunkSize,
              totalChunks: encResult.totalChunks,
              encryptedMetadata: encResult.encryptedMetadata,
              ownerEnvelope: {
                fileRef,
                versionId,
                recipientId: uid,
                grantedByUserId: uid,
                keyAlgorithm: 'ECDH-P256-HKDF-SHA256-AES256GCM',
                ephemeralPublicJwk: ownerWrapped.ephemeralPublicJwk,
                saltHex: ownerWrapped.saltHex,
                ivHex: ownerWrapped.ivHex,
                wrappedDekHex: ownerWrapped.wrappedDekHex,
                recipientEncFingerprint: ownerWrapped.recipientEncFingerprint,
                expiresAt: null,
              },
              registrySignatureHex,
              deferFinality: Boolean(params.deferFinality),
            },
            { headers: this.authHeaders(uid) },
          ),
        );

        activeUploadId = null;
        this.cacheLocalMeta(versionId, {
          originalName: sanitizeDownloadFilename(file.name),
          mimeType: file.type || 'application/octet-stream',
          plaintextSize: file.size,
          localPlaintextSha256: 'local',
          createdAt: new Date().toISOString(),
        });

        this.upsertUploadTask({
          id: taskId,
          filename: file.name,
          totalBytes: file.size,
          stage: 'complete',
          progressPercent: 100,
          message: params.deferFinality
            ? `Encrypted v${nextVersionNumber} stored; registry tx pending finality.`
            : `Encrypted v${nextVersionNumber} stored and finalised on registry.`,
        });
      } catch (err) {
        const isAbort = err instanceof CipherError && err.code === 'ABORTED';
        this.upsertUploadTask({
          id: taskId,
          filename: file.name,
          totalBytes: file.size,
          stage: isAbort ? 'aborted' : 'error',
          progressPercent: 0,
          message: this.extractError(err),
        });
        if (activeUploadId) {
          await firstValueFrom(
            this.http.delete(`/api/uploads/${activeUploadId}`, { headers: this.authHeaders(uid) }),
          ).catch(() => undefined);
        }
      }
    }

    await this.refreshAll();
  }

  abortActiveUpload(): void {
    this.activeUploadAbortController?.abort();
  }

  // ---------- Recipient Trust Verification & Key-Envelope Sharing ----------

  confirmRecipientFingerprint(recipientId: string, method: 'confirmed' | 'tofu'): void {
    const uid = this.activeUserId();
    const bundle = this.keyBundles()[uid];
    const target = this.users().find((u) => u.userId === recipientId);
    if (!bundle || !target) return;

    const updatedBundle: LocalUserKeyBundle = {
      ...bundle,
      trustedDirectory: {
        ...bundle.trustedDirectory,
        [recipientId]: {
          userId: target.userId,
          displayName: target.displayName,
          encFingerprint: target.encFingerprint,
          registryFingerprint: target.registryFingerprint,
          verifiedAt: new Date().toISOString(),
          verificationMethod: method,
        },
      },
    };
    const next = { ...this.keyBundles(), [uid]: updatedBundle };
    this.keyBundles.set(next);
    this.saveLocalBundles(next);
    this.setBanner('success', `Verified and pinned encryption key fingerprint for ${target.displayName}.`);
  }

  async shareFileWithRecipient(params: {
    fileRef: string;
    versionId: string;
    recipientId: string;
    expiresInMinutes: number;
    note: string;
    simulateKeySubstitution?: boolean;
  }): Promise<boolean> {
    const uid = this.activeUserId();
    const bundle = this.keyBundles()[uid];
    if (!bundle) {
      this.setBanner('error', 'Active user key bundle unavailable.');
      return false;
    }

    const file = this.files().find((f) => f.fileRef === params.fileRef);
    const recipient = this.users().find((u) => u.userId === params.recipientId);
    if (!file || !recipient) {
      this.setBanner('error', 'File or recipient not found.');
      return false;
    }

    const trusted = bundle.trustedDirectory[params.recipientId];
    if (!trusted) {
      this.setBanner(
        'warning',
        `Recipient ${recipient.displayName}'s key fingerprint is not yet verified in your Trusted Directory. Confirm their fingerprint first to prevent key substitution.`,
      );
      return false;
    }

    try {
      // Owner unwraps their own DEK locally first
      const ownerEnvelope = [...file.envelopes]
        .reverse()
        .find((e) => e.versionId === params.versionId && e.recipientId === uid && !e.revokedAt);
      if (!ownerEnvelope) {
        this.setBanner('error', 'No active owner key envelope found for this version.');
        return false;
      }

      const dekBytes = await unwrapDekFromEnvelope({
        recipientEncPrivateJwk: bundle.encPrivateJwk,
        recipientEncFingerprint: bundle.encFingerprint,
        fileRef: file.fileRef,
        versionId: params.versionId,
        recipientId: uid,
        ephemeralPublicJwk: ownerEnvelope.ephemeralPublicJwk,
        saltHex: ownerEnvelope.saltHex,
        ivHex: ownerEnvelope.ivHex,
        wrappedDekHex: ownerEnvelope.wrappedDekHex,
      });

      // If simulating a rogue backend substituting the recipient's public key, swap in an attacker JWK
      let presentedJwk = recipient.encPublicJwk;
      if (params.simulateKeySubstitution) {
        const rogue = await generateUserKeyBundle({
          userId: 'rogue',
          displayName: 'Rogue',
          handle: 'rogue',
          roleLabel: 'Attacker',
        });
        presentedJwk = rogue.encPublicJwk;
      }

      const wrappedForRecipient = await wrapDekForRecipient({
        dekBytes,
        fileRef: file.fileRef,
        versionId: params.versionId,
        recipientId: recipient.userId,
        recipientEncPublicJwk: presentedJwk,
        expectedRecipientFingerprint: trusted.encFingerprint,
      });

      await firstValueFrom(
        this.http.post(
          `/api/files/${file.fileRef}/versions/${params.versionId}/share`,
          {
            recipientId: recipient.userId,
            ephemeralPublicJwk: wrappedForRecipient.ephemeralPublicJwk,
            saltHex: wrappedForRecipient.saltHex,
            ivHex: wrappedForRecipient.ivHex,
            wrappedDekHex: wrappedForRecipient.wrappedDekHex,
            recipientEncFingerprint: wrappedForRecipient.recipientEncFingerprint,
            expiresInMinutes: params.expiresInMinutes,
            note: params.note,
          },
          { headers: this.authHeaders(uid) },
        ),
      );

      await this.refreshAll();
      this.setBanner(
        'success',
        `Wrapped key envelope shared with ${recipient.displayName} (expires in ${params.expiresInMinutes} min).`,
      );
      return true;
    } catch (err) {
      this.setBanner('error', this.extractError(err));
      return false;
    }
  }

  // ---------- Integrity Verification, Download & Local Staged Decryption ----------

  async verifyAndDecryptVersion(params: {
    fileRef: string;
    versionId: string;
    simulateWrongKey?: boolean;
    cacheObtainedCopy?: boolean;
  }): Promise<void> {
    const uid = this.activeUserId();
    const bundle = this.keyBundles()[uid];
    if (!bundle) {
      this.setBanner(
        'error',
        'Your local decryption key is missing (simulated key loss). Restore from your PBKDF2 backup first.',
      );
      return;
    }
    if (!this.sessionTokens()[uid]) {
      await this.authenticateUser(uid);
    }

    this.busy.set(true);
    try {
      const file = this.files().find((f) => f.fileRef === params.fileRef);
      const version = file?.versions.find((v) => v.versionId === params.versionId);

      // 1. Retrieve wrapped key envelope from server (enforces auth, expiry & revocation)
      const envRes = await firstValueFrom(
        this.http.get<{ envelope: KeyEnvelopeRecord }>(
          `/api/files/${params.fileRef}/versions/${params.versionId}/envelope`,
          { headers: this.authHeaders(uid) },
        ),
      );

      let dekBytes: Uint8Array;
      if (params.simulateWrongKey) {
        dekBytes = randomBytes(32);
      } else {
        dekBytes = await unwrapDekFromEnvelope({
          recipientEncPrivateJwk: bundle.encPrivateJwk,
          recipientEncFingerprint: bundle.encFingerprint,
          fileRef: params.fileRef,
          versionId: params.versionId,
          recipientId: uid,
          ephemeralPublicJwk: envRes.envelope.ephemeralPublicJwk,
          saltHex: envRes.envelope.saltHex,
          ivHex: envRes.envelope.ivHex,
          wrappedDekHex: envRes.envelope.wrappedDekHex,
        });
      }

      // 2. Download ciphertext blob
      const cipherBuf = await firstValueFrom(
        this.http.get(`/api/files/${params.fileRef}/versions/${params.versionId}/ciphertext`, {
          headers: this.authHeaders(uid),
          responseType: 'arraybuffer',
        }),
      );
      const ciphertextBytes = new Uint8Array(cipherBuf);

      // 3. Look up expected commitment from Blockchain Registry
      const onChainTx = this.registryState().transactions.find(
        (t) => t.txHash === version?.registryTxHash,
      );
      const expectedCommitment =
        onChainTx?.ciphertextCommitment ?? version?.ciphertextCommitment;

      // Optional: save already-obtained artifact for revocation-limits demonstration
      if (params.cacheObtainedCopy && version && !params.simulateWrongKey) {
        this.obtainedArtifacts.update((list) => [
          {
            fileRef: params.fileRef,
            versionId: params.versionId,
            versionNumber: version.versionNumber,
            holderUserId: uid,
            dekHex: bytesToHex(dekBytes),
            ciphertextBytes,
            encryptedMetadata: version.encryptedMetadata,
            ciphertextCommitment: expectedCommitment ?? version.ciphertextCommitment,
            obtainedAt: new Date().toISOString(),
          },
          ...list.filter((a) => !(a.versionId === params.versionId && a.holderUserId === uid)),
        ]);
      }

      // 4. Staged decryption & integrity verification
      const result = await decryptFileStaged({
        ciphertext: ciphertextBytes,
        dekBytes,
        expectedCiphertextCommitment: expectedCommitment,
        encryptedMetadata: version?.encryptedMetadata,
      });

      this.presentVerifiedPlaintext(
        params.fileRef,
        params.versionId,
        version?.versionNumber ?? 1,
        result.plaintext,
        result.metadata,
        result.report,
      );

      await this.refreshAll();
      this.setBanner(
        'success',
        `Verified commitment and decrypted "${result.metadata?.originalName ?? 'file'}" in local staging.`,
      );
    } catch (err) {
      this.lastDecrypted.set(null);
      this.setBanner('error', this.extractError(err));
      await this.refreshAll().catch(() => undefined);
    } finally {
      this.busy.set(false);
    }
  }

  async decryptOfflineObtainedArtifact(artifact: ObtainedKeyArtifact): Promise<void> {
    try {
      const result = await decryptFileStaged({
        ciphertext: artifact.ciphertextBytes,
        dekBytes: hexToBytes(artifact.dekHex),
        expectedCiphertextCommitment: artifact.ciphertextCommitment,
        encryptedMetadata: artifact.encryptedMetadata,
      });
      this.presentVerifiedPlaintext(
        artifact.fileRef,
        artifact.versionId,
        artifact.versionNumber,
        result.plaintext,
        result.metadata,
        result.report,
      );
      this.setBanner(
        'warning',
        'Offline decryption succeeded using an already-obtained DEK & ciphertext copy — demonstrating why revocation cannot recall previously delivered keys.',
      );
    } catch (err) {
      this.setBanner('error', this.extractError(err));
    }
  }

  private presentVerifiedPlaintext(
    fileRef: string,
    versionId: string,
    versionNumber: number,
    plaintext: Uint8Array,
    metadata: PlaintextFileMetadata | null,
    report: VerificationReport,
  ): void {
    const filename = sanitizeDownloadFilename(metadata?.originalName ?? `${fileRef}-v${versionNumber}.bin`);
    if (metadata) {
      this.cacheLocalMeta(versionId, metadata);
    }
    const lowerName = filename.toLowerCase();
    const isActiveContentBlocked = ACTIVE_CONTENT_EXTENSIONS.some((ext) => lowerName.endsWith(ext));
    const mimeType = metadata?.mimeType ?? 'application/octet-stream';

    let textSnippet: string | null = null;
    const isTextLike =
      mimeType.startsWith('text/') ||
      mimeType === 'application/json' ||
      lowerName.endsWith('.txt') ||
      lowerName.endsWith('.md') ||
      lowerName.endsWith('.csv') ||
      lowerName.endsWith('.json');

    if (isTextLike && !isActiveContentBlocked && plaintext.byteLength <= 64 * 1024) {
      textSnippet = new TextDecoder().decode(plaintext);
    }

    this.lastDecrypted.set({
      fileRef,
      versionId,
      versionNumber,
      sanitizedFilename: filename,
      mimeType,
      byteLength: plaintext.byteLength,
      textSnippet,
      isActiveContentBlocked,
      report,
      decryptedBytes: plaintext,
      decryptedAt: new Date().toISOString(),
    });
  }

  triggerSafeDownload(preview: DecryptedPreviewState): void {
    if (!this.isBrowser) return;
    const blob = new Blob([preview.decryptedBytes.slice().buffer], {
      type: 'application/octet-stream',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = sanitizeDownloadFilename(preview.sanitizedFilename);
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  // ---------- Cross-User Rejection, Tamper Lab, Revocation & Deletion ----------

  async testCrossUserAccess(fileRef: string, versionId: string): Promise<void> {
    const uid = this.activeUserId();
    if (!this.sessionTokens()[uid]) {
      await this.authenticateUser(uid);
    }
    try {
      await firstValueFrom(
        this.http.get(`/api/files/${fileRef}/versions/${versionId}/envelope`, {
          headers: this.authHeaders(uid),
        }),
      );
      this.setBanner('info', 'User actually holds an authorised envelope for this version.');
    } catch (err) {
      await this.refreshAll();
      this.setBanner('success', `Server enforced access control and rejected request: ${this.extractError(err)}`);
    }
  }

  async revokeRecipient(fileRef: string, recipientId: string): Promise<void> {
    const uid = this.activeUserId();
    try {
      await firstValueFrom(
        this.http.post(
          `/api/files/${fileRef}/revoke`,
          { recipientId },
          { headers: this.authHeaders(uid) },
        ),
      );
      await this.refreshAll();
      this.setBanner(
        'success',
        `Revoked future application access and key envelopes for ${recipientId}.`,
      );
    } catch (err) {
      this.setBanner('error', this.extractError(err));
    }
  }

  async deleteVersion(fileRef: string, versionId: string): Promise<void> {
    const uid = this.activeUserId();
    const bundle = this.keyBundles()[uid];
    const file = this.files().find((f) => f.fileRef === fileRef);
    const ver = file?.versions.find((v) => v.versionId === versionId);
    if (!bundle || !ver) return;

    try {
      const sigPayload = canonicalRegistrySignPayload({
        eventType: 'UPDATE_STATUS',
        fileRef,
        versionNumber: ver.versionNumber,
        ciphertextCommitment: ver.ciphertextCommitment,
        manifestCommitment: ver.manifestCommitment,
        formatVersion: ver.encryptionFormatVersion,
        lifecycleStatus: 'revoked',
        ownerRegistryFingerprint: bundle.registryFingerprint,
      });
      const registrySignatureHex = await signWithEcdsaP256(bundle.registryPrivateJwk, sigPayload);

      await firstValueFrom(
        this.http.delete(`/api/files/${fileRef}/versions/${versionId}`, {
          headers: this.authHeaders(uid),
          body: { registrySignatureHex },
        }),
      );
      await this.refreshAll();
      this.setBanner(
        'warning',
        `Deleted v${ver.versionNumber} ciphertext from ${ver.storageAdapter.toUpperCase()} storage and recorded status update on chain.`,
      );
    } catch (err) {
      this.setBanner('error', this.extractError(err));
    }
  }

  async simulateTamper(fileRef: string, versionId: string): Promise<void> {
    const uid = this.activeUserId();
    try {
      const res = await firstValueFrom(
        this.http.post<{ byteOffset: number }>(
          `/api/files/${fileRef}/versions/${versionId}/simulate-tamper`,
          {},
          { headers: this.authHeaders(uid) },
        ),
      );
      await this.refreshAll();
      this.setBanner(
        'warning',
        `Flipped 1 byte at ciphertext offset ${res.byteOffset}. Now run Verify & Decrypt to observe rejection.`,
      );
    } catch (err) {
      this.setBanner('error', this.extractError(err));
    }
  }

  // ---------- Registry & Storage Admin Controls ----------

  async minePendingBlock(): Promise<void> {
    const uid = this.activeUserId();
    const res = await firstValueFrom(
      this.http.post<{ block: RegistryBlockRecord | null }>(
        '/api/registry/mine',
        {},
        { headers: this.authHeaders(uid) },
      ),
    );
    await this.refreshAll();
    if (res.block) {
      this.setBanner(
        'success',
        `Block #${res.block.blockNumber} finalised (${res.block.txHashes.length} commitment tx).`,
      );
    } else {
      this.setBanner('info', 'No pending transactions in mempool.');
    }
  }

  async simulateReorg(): Promise<void> {
    const uid = this.activeUserId();
    const res = await firstValueFrom(
      this.http.post<{ reorganisedBlock: RegistryBlockRecord | null; affectedTxHashes: string[] }>(
        '/api/registry/simulate-reorg',
        {},
        { headers: this.authHeaders(uid) },
      ),
    );
    await this.refreshAll();
    if (res.reorganisedBlock) {
      this.setBanner(
        'warning',
        `Simulated 1-block reorganisation on block #${res.reorganisedBlock.blockNumber}. Run Event Recovery to re-anchor commitments.`,
      );
    } else {
      this.setBanner('info', 'No finalised blocks above genesis to reorganise yet.');
    }
  }

  async recoverReorg(): Promise<void> {
    const uid = this.activeUserId();
    const res = await firstValueFrom(
      this.http.post<{ recoveryBlock: RegistryBlockRecord | null; recoveredTxHashes: string[] }>(
        '/api/registry/recover',
        {},
        { headers: this.authHeaders(uid) },
      ),
    );
    await this.refreshAll();
    if (res.recoveryBlock) {
      this.setBanner(
        'success',
        `Recovered ${res.recoveredTxHashes.length} transaction(s) into canonical block #${res.recoveryBlock.blockNumber}.`,
      );
    } else {
      this.setBanner('info', 'No reorganised transactions require recovery.');
    }
  }

  async purgeOrphans(): Promise<void> {
    const uid = this.activeUserId();
    const res = await firstValueFrom(
      this.http.post<{ purged: { local: string[]; s3: string[]; cas: string[] } }>(
        '/api/storage/purge-orphans',
        {},
        { headers: this.authHeaders(uid) },
      ),
    );
    await this.refreshAll();
    const count =
      res.purged.local.length + res.purged.s3.length + res.purged.cas.length;
    this.setBanner('success', `Orphan storage cleanup complete (${count} object(s) removed).`);
  }

  // ---------- Key Backup & Recovery ----------

  async exportKeyBackup(userId: string, passphrase: string): Promise<EncryptedKeyBackup | null> {
    const bundle = this.keyBundles()[userId];
    if (!bundle) {
      this.setBanner('error', 'No local keys present to back up.');
      return null;
    }
    try {
      const backup = await createEncryptedKeyBackup(bundle, passphrase);
      if (this.isBrowser) {
        const blob = new Blob([JSON.stringify(backup, null, 2)], {
          type: 'application/json',
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${bundle.userId}.lcbackup.json`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      }
      this.setBanner(
        'success',
        `Exported PBKDF2-SHA256 (310,000 iter) + AES-256-GCM encrypted key backup for ${bundle.displayName}.`,
      );
      return backup;
    } catch (err) {
      this.setBanner('error', this.extractError(err));
      return null;
    }
  }

  wipeLocalKeys(userId: string): void {
    const next = { ...this.keyBundles() };
    delete next[userId];
    this.keyBundles.set(next);
    this.saveLocalBundles(next);

    const nextTokens = { ...this.sessionTokens() };
    delete nextTokens[userId];
    this.sessionTokens.set(nextTokens);

    this.lastDecrypted.set(null);
    this.setBanner(
      'warning',
      `Wiped local private keys for ${userId} from browser storage. Decryption is now impossible without a backup.`,
    );
  }

  async restoreFromBackup(backup: EncryptedKeyBackup, passphrase: string): Promise<boolean> {
    try {
      const restored = await restoreEncryptedKeyBackup(backup, passphrase);
      const next = { ...this.keyBundles(), [restored.userId]: restored };
      this.keyBundles.set(next);
      this.saveLocalBundles(next);
      this.activeUserId.set(restored.userId);
      await this.authenticateUser(restored.userId);
      await firstValueFrom(
        this.http.post(
          '/api/audit/backup-restored',
          {},
          { headers: this.authHeaders(restored.userId) },
        ),
      );
      await this.refreshAll();
      this.setBanner(
        'success',
        `Restored 3-role key bundle for ${restored.displayName} and re-authenticated session.`,
      );
      return true;
    } catch (err) {
      this.setBanner('error', this.extractError(err));
      return false;
    }
  }

  private upsertUploadTask(task: UploadTaskStatus): void {
    this.uploadTasks.update((list) => {
      const idx = list.findIndex((t) => t.id === task.id);
      if (idx === -1) return [task, ...list].slice(0, 6);
      const copy = [...list];
      copy[idx] = task;
      return copy;
    });
  }

  setBanner(type: 'info' | 'success' | 'warning' | 'error', text: string): void {
    this.statusBanner.set({ type, text });
  }

  clearBanner(): void {
    this.statusBanner.set(null);
  }

  private extractError(err: unknown): string {
    if (err && typeof err === 'object' && 'error' in err) {
      const inner = (err as { error?: { error?: string } }).error;
      if (inner?.error) return inner.error;
    }
    if (err instanceof Error) return err.message;
    return 'Operation failed.';
  }
}
