import express, { NextFunction, Request, Response, Router } from 'express';
import { StorageAdapterType, UserPublicProfile } from '../shared/cipher-types';
import { LondonCipherChain } from './blockchain-registry';
import { MAX_UPLOAD_BYTES, RegistryStore } from './registry-store';
import { StorageAdapterRegistry } from './storage-adapters';

interface AuthedRequest extends Request {
  actorUserId?: string;
}

function safeErrorMessage(err: unknown): string {
  if (err instanceof Error) {
    // Redact any accidental long hex strings (potential keys/tokens) from error output
    return err.message.replace(/\b[0-9a-fA-F]{64,}\b/g, '[REDACTED_HEX]');
  }
  return 'Unexpected server error.';
}

export function createCipherApiRouter(dataDir: string): {
  router: Router;
  store: RegistryStore;
  chain: LondonCipherChain;
  storage: StorageAdapterRegistry;
} {
  const storage = new StorageAdapterRegistry(dataDir);
  const chain = new LondonCipherChain(dataDir);
  const store = new RegistryStore(dataDir, storage, chain);

  const router = express.Router();

  // Security & CSP middleware for API responses
  router.use((_req: Request, res: Response, next: NextFunction) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Cache-Control', 'no-store');
    next();
  });

  // Rate limiting middleware
  router.use((req: Request, res: Response, next: NextFunction) => {
    const key = req.ip || 'local';
    if (!store.checkRateLimit(key)) {
      res.status(429).json({ error: 'Rate limit exceeded. Please wait before retrying.' });
      return;
    }
    next();
  });

  // Raw body parser for encrypted chunk parts; JSON parser for control calls
  router.use('/uploads/:uploadId/parts/:partIndex', express.raw({ type: 'application/octet-stream', limit: MAX_UPLOAD_BYTES }));
  router.use(express.json({ limit: '4mb' }));

  const requireAuth = (req: AuthedRequest, res: Response, next: NextFunction) => {
    const session = store.verifySessionToken(req.headers.authorization);
    if (!session) {
      res.status(401).json({ error: 'Session missing or expired. Re-authenticate with your Auth key.' });
      return;
    }
    req.actorUserId = session.userId;
    next();
  };

  // ---------- Directory & Auth ----------

  router.get('/users', async (_req: Request, res: Response) => {
    try {
      const users = await store.listUsers();
      res.json({ users });
    } catch (err) {
      res.status(500).json({ error: safeErrorMessage(err) });
    }
  });

  router.post('/users/register', async (req: Request, res: Response) => {
    try {
      const profile = req.body as UserPublicProfile;
      if (!profile?.userId || !profile.authPublicJwk || !profile.registryPublicJwk || !profile.encPublicJwk) {
        res.status(400).json({ error: 'Incomplete public key profile.' });
        return;
      }
      const saved = await store.registerUserPublicProfile(profile);
      res.json({ user: saved });
    } catch (err) {
      res.status(400).json({ error: safeErrorMessage(err) });
    }
  });

  router.post('/auth/challenge', async (req: Request, res: Response) => {
    try {
      const { userId } = req.body as { userId: string };
      const challenge = await store.createAuthChallenge(userId);
      res.json(challenge);
    } catch (err) {
      res.status(400).json({ error: safeErrorMessage(err) });
    }
  });

  router.post('/auth/verify', async (req: Request, res: Response) => {
    try {
      const { challengeId, signatureHex } = req.body as {
        challengeId: string;
        signatureHex: string;
      };
      const session = await store.verifyAuthChallenge({ challengeId, signatureHex });
      res.json(session);
    } catch (err) {
      res.status(401).json({ error: safeErrorMessage(err) });
    }
  });

  // ---------- Upload Staging & Finalisation ----------

  router.post('/uploads/init', requireAuth, (req: AuthedRequest, res: Response) => {
    try {
      const { storageAdapter, totalParts } = req.body as {
        storageAdapter: StorageAdapterType;
        totalParts: number;
      };
      const uploadId = store.initUploadSession({
        userId: req.actorUserId!,
        storageAdapter: storageAdapter || 'local',
        totalParts: Number(totalParts) || 1,
      });
      res.json({ uploadId });
    } catch (err) {
      res.status(400).json({ error: safeErrorMessage(err) });
    }
  });

  router.put('/uploads/:uploadId/parts/:partIndex', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      const uploadId = String(req.params['uploadId']);
      const partIndex = Number(req.params['partIndex']);
      const bodyBytes = req.body instanceof Uint8Array ? req.body : new Uint8Array(req.body);
      const status = await store.addUploadPart({
        uploadId,
        userId: req.actorUserId!,
        partIndex,
        bytes: bodyBytes,
      });
      res.json(status);
    } catch (err) {
      res.status(400).json({ error: safeErrorMessage(err) });
    }
  });

  router.delete('/uploads/:uploadId', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      await store.abortUploadSession(String(req.params['uploadId']), req.actorUserId!);
      res.json({ aborted: true });
    } catch (err) {
      res.status(400).json({ error: safeErrorMessage(err) });
    }
  });

  router.post('/uploads/finalise', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      const result = await store.finaliseEncryptedUpload({
        ...req.body,
        actorUserId: req.actorUserId!,
      });
      res.json(result);
    } catch (err) {
      const msg = safeErrorMessage(err);
      res.status(msg.includes('Only the file owner') ? 403 : 400).json({ error: msg });
    }
  });

  // ---------- Files, Sharing, Envelopes, Downloads, Revocation ----------

  router.get('/files', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      const files = await store.listFilesForUser(req.actorUserId!);
      res.json({ files });
    } catch (err) {
      res.status(500).json({ error: safeErrorMessage(err) });
    }
  });

  router.get('/files/:fileRef', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      const file = await store.getFileForUser(String(req.params['fileRef']), req.actorUserId!);
      if (!file) {
        await store.recordAudit({
          eventType: 'access_denied',
          actorUserId: req.actorUserId!,
          fileRef: String(req.params['fileRef']),
          summary: 'Cross-user file record read denied.',
          outcome: 'rejected',
        });
        res.status(403).json({ error: 'Access denied or file not found.' });
        return;
      }
      res.json({ file });
    } catch (err) {
      res.status(500).json({ error: safeErrorMessage(err) });
    }
  });

  router.post('/files/:fileRef/versions/:versionId/share', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      const result = await store.shareKeyEnvelope({
        actorUserId: req.actorUserId!,
        fileRef: String(req.params['fileRef']),
        versionId: String(req.params['versionId']),
        ...req.body,
      });
      res.json(result);
    } catch (err) {
      const msg = safeErrorMessage(err);
      res.status(msg.includes('Only the file owner') ? 403 : 400).json({ error: msg });
    }
  });

  router.get('/files/:fileRef/versions/:versionId/envelope', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      const envelope = await store.retrieveKeyEnvelope({
        actorUserId: req.actorUserId!,
        fileRef: String(req.params['fileRef']),
        versionId: String(req.params['versionId']),
      });
      res.json({ envelope });
    } catch (err) {
      const msg = safeErrorMessage(err);
      res.status(msg.startsWith('403:') ? 403 : 404).json({ error: msg });
    }
  });

  router.get('/files/:fileRef/versions/:versionId/ciphertext', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      const { ciphertext, version } = await store.downloadCiphertextAuthorized({
        actorUserId: req.actorUserId!,
        fileRef: String(req.params['fileRef']),
        versionId: String(req.params['versionId']),
      });
      res.setHeader('Content-Type', 'application/octet-stream');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="encrypted-${version.fileRef}-v${version.versionNumber}.lcfr"`,
      );
      res.send(Buffer.from(ciphertext));
    } catch (err) {
      const msg = safeErrorMessage(err);
      res.status(msg.startsWith('403:') ? 403 : 404).json({ error: msg });
    }
  });

  router.post('/files/:fileRef/revoke', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      const { recipientId, registrySignatureHex } = req.body as {
        recipientId: string;
        registrySignatureHex?: string;
      };
      const result = await store.revokeRecipientAccess({
        actorUserId: req.actorUserId!,
        fileRef: String(req.params['fileRef']),
        recipientId,
        registrySignatureHex,
      });
      res.json(result);
    } catch (err) {
      const msg = safeErrorMessage(err);
      res.status(msg.startsWith('403:') ? 403 : 400).json({ error: msg });
    }
  });

  router.delete('/files/:fileRef/versions/:versionId', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      const registrySignatureHex = (req.body as { registrySignatureHex?: string } | undefined)
        ?.registrySignatureHex;
      await store.deleteVersionCiphertext({
        actorUserId: req.actorUserId!,
        fileRef: String(req.params['fileRef']),
        versionId: String(req.params['versionId']),
        registrySignatureHex,
      });
      res.json({ deleted: true });
    } catch (err) {
      const msg = safeErrorMessage(err);
      res.status(msg.startsWith('403:') ? 403 : 400).json({ error: msg });
    }
  });

  // Tamper Simulation (Demonstrates Storage Compromise Detection)
  router.post('/files/:fileRef/versions/:versionId/simulate-tamper', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      const result = await store.simulateCiphertextTamper({
        actorUserId: req.actorUserId!,
        fileRef: String(req.params['fileRef']),
        versionId: String(req.params['versionId']),
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: safeErrorMessage(err) });
    }
  });

  // ---------- Blockchain Registry Ledger ----------

  router.get('/registry', async (_req: Request, res: Response) => {
    try {
      const snapshot = await chain.getSnapshot();
      res.json(snapshot);
    } catch (err) {
      res.status(500).json({ error: safeErrorMessage(err) });
    }
  });

  router.post('/registry/mine', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      const block = await chain.minePendingTransactions();
      await store.syncRegistryStates();
      if (block) {
        await store.recordAudit({
          eventType: 'registry_finalised',
          actorUserId: req.actorUserId!,
          summary: `Block #${block.blockNumber} finalised (${block.txHashes.length} commitment tx).`,
          outcome: 'success',
        });
      }
      res.json({ block });
    } catch (err) {
      res.status(500).json({ error: safeErrorMessage(err) });
    }
  });

  router.post('/registry/simulate-reorg', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      const result = await chain.simulateLatestBlockReorg();
      await store.syncRegistryStates();
      if (result.reorganisedBlock) {
        await store.recordAudit({
          eventType: 'registry_reorg_detected',
          actorUserId: req.actorUserId!,
          summary: `Simulated chain reorg on block #${result.reorganisedBlock.blockNumber} (${result.affectedTxHashes.length} tx affected).`,
          outcome: 'warning',
        });
      }
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: safeErrorMessage(err) });
    }
  });

  router.post('/registry/recover', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      const result = await chain.recoverReorganisedEvents();
      await store.syncRegistryStates();
      if (result.recoveryBlock) {
        await store.recordAudit({
          eventType: 'registry_reorg_recovered',
          actorUserId: req.actorUserId!,
          summary: `Recovered ${result.recoveredTxHashes.length} commitment event(s) into canonical block #${result.recoveryBlock.blockNumber}.`,
          outcome: 'success',
        });
      }
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: safeErrorMessage(err) });
    }
  });

  // ---------- Storage Admin & Audit Log ----------

  router.get('/storage/inventory', requireAuth, async (_req: AuthedRequest, res: Response) => {
    try {
      const inventory = await store.getStorageInventory();
      res.json(inventory);
    } catch (err) {
      res.status(500).json({ error: safeErrorMessage(err) });
    }
  });

  router.post('/storage/purge-orphans', requireAuth, async (_req: AuthedRequest, res: Response) => {
    try {
      const purged = await store.purgeOrphanedStorage();
      res.json({ purged });
    } catch (err) {
      res.status(500).json({ error: safeErrorMessage(err) });
    }
  });

  router.get('/audit', requireAuth, async (_req: AuthedRequest, res: Response) => {
    try {
      const events = await store.listAuditEvents();
      res.json({ events });
    } catch (err) {
      res.status(500).json({ error: safeErrorMessage(err) });
    }
  });

  router.post('/audit/backup-restored', requireAuth, async (req: AuthedRequest, res: Response) => {
    try {
      await store.recordAudit({
        eventType: 'backup_restored',
        actorUserId: req.actorUserId!,
        summary: 'User restored 3-role key bundle from PBKDF2 + AES-256-GCM encrypted backup.',
        outcome: 'success',
      });
      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({ error: safeErrorMessage(err) });
    }
  });

  return { router, store, chain, storage };
}
