import { createHash, randomUUID } from 'node:crypto';
import { mkdir, readdir, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { StorageAdapterType } from '../shared/cipher-types';

export interface StoredObjectMeta {
  adapter: StorageAdapterType;
  storageKey: string;
  storageLocation: string;
  byteLength: number;
  sha256: string;
  contentAddressCid: string | null;
  createdAt: string;
}

export interface StorageAdapter {
  readonly type: StorageAdapterType;
  putObject(storageKey: string, data: Uint8Array): Promise<StoredObjectMeta>;
  getObject(storageKey: string): Promise<Uint8Array | null>;
  deleteObject(storageKey: string): Promise<boolean>;
  headObject(storageKey: string): Promise<StoredObjectMeta | null>;
  listKeys(): Promise<string[]>;
  purgeOrphans(activeKeys: Set<string>): Promise<string[]>;
}

function assertSafeKey(storageKey: string): string {
  const clean = storageKey.trim();
  if (!/^[a-zA-Z0-9._-]{4,160}$/.test(clean) || clean.includes('..')) {
    throw new Error('Invalid storage key format.');
  }
  return clean;
}

function sha256HexNode(data: Uint8Array): string {
  return createHash('sha256').update(data).digest('hex');
}

export class LocalEncryptedStorageAdapter implements StorageAdapter {
  readonly type: StorageAdapterType = 'local';
  private readonly dir: string;

  constructor(baseDir: string) {
    this.dir = resolve(baseDir, 'local-objects');
  }

  private filePath(storageKey: string): string {
    return join(this.dir, `${assertSafeKey(storageKey)}.lcfr`);
  }

  async putObject(storageKey: string, data: Uint8Array): Promise<StoredObjectMeta> {
    const safeKey = assertSafeKey(storageKey);
    await mkdir(this.dir, { recursive: true });
    const target = this.filePath(safeKey);
    await writeFile(target, data);
    const sha256 = sha256HexNode(data);
    return {
      adapter: 'local',
      storageKey: safeKey,
      storageLocation: `local://vault/${safeKey}.lcfr`,
      byteLength: data.byteLength,
      sha256,
      contentAddressCid: null,
      createdAt: new Date().toISOString(),
    };
  }

  async getObject(storageKey: string): Promise<Uint8Array | null> {
    try {
      const buf = await readFile(this.filePath(storageKey));
      return new Uint8Array(buf);
    } catch {
      return null;
    }
  }

  async deleteObject(storageKey: string): Promise<boolean> {
    try {
      await rm(this.filePath(storageKey), { force: false });
      return true;
    } catch {
      return false;
    }
  }

  async headObject(storageKey: string): Promise<StoredObjectMeta | null> {
    try {
      const safeKey = assertSafeKey(storageKey);
      const data = await this.getObject(safeKey);
      if (!data) return null;
      const st = await stat(this.filePath(safeKey));
      return {
        adapter: 'local',
        storageKey: safeKey,
        storageLocation: `local://vault/${safeKey}.lcfr`,
        byteLength: data.byteLength,
        sha256: sha256HexNode(data),
        contentAddressCid: null,
        createdAt: st.mtime.toISOString(),
      };
    } catch {
      return null;
    }
  }

  async listKeys(): Promise<string[]> {
    try {
      const files = await readdir(this.dir);
      return files.filter((f) => f.endsWith('.lcfr')).map((f) => f.slice(0, -5));
    } catch {
      return [];
    }
  }

  async purgeOrphans(activeKeys: Set<string>): Promise<string[]> {
    const existing = await this.listKeys();
    const removed: string[] = [];
    for (const k of existing) {
      if (!activeKeys.has(k)) {
        if (await this.deleteObject(k)) {
          removed.push(k);
        }
      }
    }
    return removed;
  }
}

export class S3CompatibleStorageAdapter implements StorageAdapter {
  readonly type: StorageAdapterType = 's3';
  private readonly bucketName: string;
  private readonly dir: string;

  constructor(baseDir: string, bucketName = 'london-cipher-vault') {
    this.bucketName = bucketName;
    this.dir = resolve(baseDir, 's3-objects', bucketName);
  }

  private objectPath(storageKey: string): string {
    return join(this.dir, `${assertSafeKey(storageKey)}.bin`);
  }

  async putObject(storageKey: string, data: Uint8Array): Promise<StoredObjectMeta> {
    const safeKey = assertSafeKey(storageKey);
    await mkdir(this.dir, { recursive: true });
    await writeFile(this.objectPath(safeKey), data);
    const sha256 = sha256HexNode(data);
    return {
      adapter: 's3',
      storageKey: safeKey,
      storageLocation: `s3://${this.bucketName}/objects/${safeKey}.bin`,
      byteLength: data.byteLength,
      sha256,
      contentAddressCid: null,
      createdAt: new Date().toISOString(),
    };
  }

  async getObject(storageKey: string): Promise<Uint8Array | null> {
    try {
      const buf = await readFile(this.objectPath(storageKey));
      return new Uint8Array(buf);
    } catch {
      return null;
    }
  }

  async deleteObject(storageKey: string): Promise<boolean> {
    try {
      await rm(this.objectPath(storageKey), { force: false });
      return true;
    } catch {
      return false;
    }
  }

  async headObject(storageKey: string): Promise<StoredObjectMeta | null> {
    try {
      const safeKey = assertSafeKey(storageKey);
      const data = await this.getObject(safeKey);
      if (!data) return null;
      const st = await stat(this.objectPath(safeKey));
      return {
        adapter: 's3',
        storageKey: safeKey,
        storageLocation: `s3://${this.bucketName}/objects/${safeKey}.bin`,
        byteLength: data.byteLength,
        sha256: sha256HexNode(data),
        contentAddressCid: null,
        createdAt: st.mtime.toISOString(),
      };
    } catch {
      return null;
    }
  }

  async listKeys(): Promise<string[]> {
    try {
      const files = await readdir(this.dir);
      return files.filter((f) => f.endsWith('.bin')).map((f) => f.slice(0, -4));
    } catch {
      return [];
    }
  }

  async purgeOrphans(activeKeys: Set<string>): Promise<string[]> {
    const existing = await this.listKeys();
    const removed: string[] = [];
    for (const k of existing) {
      if (!activeKeys.has(k)) {
        if (await this.deleteObject(k)) {
          removed.push(k);
        }
      }
    }
    return removed;
  }
}

export class ContentAddressedStorageAdapter implements StorageAdapter {
  readonly type: StorageAdapterType = 'cas';
  private readonly dir: string;

  constructor(baseDir: string) {
    this.dir = resolve(baseDir, 'cas-objects');
  }

  private blobPath(cidHex: string): string {
    return join(this.dir, `${assertSafeKey(cidHex)}.cid`);
  }

  private refPath(storageKey: string): string {
    return join(this.dir, `${assertSafeKey(storageKey)}.ref`);
  }

  async putObject(storageKey: string, data: Uint8Array): Promise<StoredObjectMeta> {
    const safeKey = assertSafeKey(storageKey);
    await mkdir(this.dir, { recursive: true });
    const sha256 = sha256HexNode(data);
    const cid = `cid:sha256:${sha256}`;
    await writeFile(this.blobPath(sha256), data);
    await writeFile(this.refPath(safeKey), sha256, 'utf8');
    return {
      adapter: 'cas',
      storageKey: safeKey,
      storageLocation: `cas://${cid}`,
      byteLength: data.byteLength,
      sha256,
      contentAddressCid: cid,
      createdAt: new Date().toISOString(),
    };
  }

  async getObject(storageKey: string): Promise<Uint8Array | null> {
    try {
      const cidHex = (await readFile(this.refPath(storageKey), 'utf8')).trim();
      const buf = await readFile(this.blobPath(cidHex));
      return new Uint8Array(buf);
    } catch {
      return null;
    }
  }

  async deleteObject(storageKey: string): Promise<boolean> {
    try {
      const safeKey = assertSafeKey(storageKey);
      let cidHex: string | null = null;
      try {
        cidHex = (await readFile(this.refPath(safeKey), 'utf8')).trim();
      } catch {
        cidHex = null;
      }
      await rm(this.refPath(safeKey), { force: true });
      if (cidHex) {
        // Only remove underlying CID blob if no other .ref points to it
        const remainingRefs = (await readdir(this.dir)).filter((f) => f.endsWith('.ref'));
        let stillReferenced = false;
        for (const refFile of remainingRefs) {
          const target = (await readFile(join(this.dir, refFile), 'utf8')).trim();
          if (target === cidHex) {
            stillReferenced = true;
            break;
          }
        }
        if (!stillReferenced) {
          await rm(this.blobPath(cidHex), { force: true });
        }
      }
      return true;
    } catch {
      return false;
    }
  }

  async headObject(storageKey: string): Promise<StoredObjectMeta | null> {
    try {
      const safeKey = assertSafeKey(storageKey);
      const cidHex = (await readFile(this.refPath(safeKey), 'utf8')).trim();
      const data = await this.getObject(safeKey);
      if (!data) return null;
      const st = await stat(this.blobPath(cidHex));
      return {
        adapter: 'cas',
        storageKey: safeKey,
        storageLocation: `cas://cid:sha256:${cidHex}`,
        byteLength: data.byteLength,
        sha256: cidHex,
        contentAddressCid: `cid:sha256:${cidHex}`,
        createdAt: st.mtime.toISOString(),
      };
    } catch {
      return null;
    }
  }

  async listKeys(): Promise<string[]> {
    try {
      const files = await readdir(this.dir);
      return files.filter((f) => f.endsWith('.ref')).map((f) => f.slice(0, -4));
    } catch {
      return [];
    }
  }

  async purgeOrphans(activeKeys: Set<string>): Promise<string[]> {
    const existing = await this.listKeys();
    const removed: string[] = [];
    for (const k of existing) {
      if (!activeKeys.has(k)) {
        if (await this.deleteObject(k)) {
          removed.push(k);
        }
      }
    }
    return removed;
  }
}

export class StorageAdapterRegistry {
  readonly local: LocalEncryptedStorageAdapter;
  readonly s3: S3CompatibleStorageAdapter;
  readonly cas: ContentAddressedStorageAdapter;
  private readonly stagingDir: string;

  constructor(baseDir: string) {
    this.local = new LocalEncryptedStorageAdapter(baseDir);
    this.s3 = new S3CompatibleStorageAdapter(baseDir);
    this.cas = new ContentAddressedStorageAdapter(baseDir);
    this.stagingDir = resolve(baseDir, 'staging-uploads');
  }

  getAdapter(type: StorageAdapterType): StorageAdapter {
    switch (type) {
      case 'local':
        return this.local;
      case 's3':
        return this.s3;
      case 'cas':
        return this.cas;
    }
  }

  async writeStagedChunk(uploadId: string, partIndex: number, bytes: Uint8Array): Promise<void> {
    const safeUpload = assertSafeKey(uploadId);
    const partDir = join(this.stagingDir, safeUpload);
    await mkdir(partDir, { recursive: true });
    await writeFile(join(partDir, `part_${String(partIndex).padStart(6, '0')}.bin`), bytes);
  }

  async assembleStagedUpload(uploadId: string, totalParts: number): Promise<Uint8Array> {
    const safeUpload = assertSafeKey(uploadId);
    const partDir = join(this.stagingDir, safeUpload);
    const chunks: Buffer[] = [];
    for (let i = 0; i < totalParts; i++) {
      const p = join(partDir, `part_${String(i).padStart(6, '0')}.bin`);
      chunks.push(await readFile(p));
    }
    await rm(partDir, { recursive: true, force: true });
    return new Uint8Array(Buffer.concat(chunks));
  }

  async abortStagedUpload(uploadId: string): Promise<void> {
    const safeUpload = assertSafeKey(uploadId);
    await rm(join(this.stagingDir, safeUpload), { recursive: true, force: true });
  }

  createStorageKey(fileRef: string, versionNumber: number): string {
    return `${fileRef}_v${versionNumber}_${randomUUID().slice(0, 8)}`;
  }
}
