import { createHmac, randomBytes, randomUUID } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { verifyWithEcdsaP256 } from '../shared/cipher-core';
import {
  AuditEventRecord,
  AuditEventType,
  EncryptedFileRecord,
  FileVersionRecord,
  KeyEnvelopeRecord,
  ShareInvitationRecord,
  StorageAdapterType,
  UserPublicProfile,
} from '../shared/cipher-types';
import { LondonCipherChain } from './blockchain-registry';
import { StorageAdapterRegistry } from './storage-adapters';

interface SessionChallenge {
  challengeId: string;
  userId: string;
  nonce: string;
  expiresAtMs: number;
}

interface UploadSession {
  uploadId: string;
  userId: string;
  storageAdapter: StorageAdapterType;
  totalParts: number;
  receivedParts: Set<number>;
  totalBytes: number;
  createdAtMs: number;
}

interface PersistedDatabase {
  users: Record<string, UserPublicProfile>;
  files: Record<string, EncryptedFileRecord>;
  auditEvents: AuditEventRecord[];
  idempotencyCache: Record<string, { versionId: string; fileRef: string }>;
}

export interface MalwareScannerHook {
  readonly modeName: string;
  evaluateCiphertextUpload(params: {
    fileRef: string;
    ciphertextByteLength: number;
  }): {
    status: 'unscanned_client_encrypted';
    note: string;
  };
}

class ClientEncryptedScannerHook implements MalwareScannerHook {
  readonly modeName = 'ClientEncryptedUnscannedAdapter';

  evaluateCiphertextUpload(): {
    status: 'unscanned_client_encrypted';
    note: string;
  } {
    return {
      status: 'unscanned_client_encrypted',
      note: 'Server receives opaque client-encrypted ciphertext and cannot scan plaintext for malware without a separate trusted-enclave or client-side scanning model.',
    };
  }
}

export const MAX_UPLOAD_BYTES = 50 * 1024 * 1024; // 50 MiB limit
const SESSION_TTL_MS = 30 * 60 * 1000; // 30 min session expiry
const CHALLENGE_TTL_MS = 5 * 60 * 1000;

export class RegistryStore {
  private readonly dbPath: string;
  private readonly sessionSecret: Buffer;
  private readonly challenges = new Map<string, SessionChallenge>();
  private readonly uploadSessions = new Map<string, UploadSession>();
  private readonly rateWindow = new Map<string, number[]>();
  readonly scannerHook: MalwareScannerHook = new ClientEncryptedScannerHook();

  private db: PersistedDatabase = {
    users: {},
    files: {},
    auditEvents: [],
    idempotencyCache: {},
  };
  private loaded = false;

  constructor(
    baseDir: string,
    readonly storage: StorageAdapterRegistry,
    readonly chain: LondonCipherChain,
  ) {
    this.dbPath = resolve(baseDir, 'metadata-db.json');
    this.sessionSecret = randomBytes(32);
  }

  async ensureLoaded(): Promise<void> {
    if (this.loaded) return;
    try {
      const raw = await readFile(this.dbPath, 'utf8');
      this.db = JSON.parse(raw) as PersistedDatabase;
    } catch {
      await this.persist();
    }
    this.loaded = true;
  }

  private async persist(): Promise<void> {
    await mkdir(dirname(this.dbPath), { recursive: true });
    await writeFile(this.dbPath, JSON.stringify(this.db, null, 2), 'utf8');
  }

  checkRateLimit(key: string, maxRequests = 180, windowMs = 60_000): boolean {
    const now = Date.now();
    const list = (this.rateWindow.get(key) ?? []).filter((ts) => now - ts < windowMs);
    if (list.length >= maxRequests) {
      this.rateWindow.set(key, list);
      return false;
    }
    list.push(now);
    this.rateWindow.set(key, list);
    return true;
  }

  async recordAudit(params: {
    eventType: AuditEventType;
    actorUserId: string;
    fileRef?: string | null;
    versionId?: string | null;
    summary: string;
    outcome: 'success' | 'rejected' | 'warning';
    txHash?: string | null;
  }): Promise<AuditEventRecord> {
    await this.ensureLoaded();
    // Redact any accidental hex secrets > 64 chars if needed; keep audit strictly metadata-safe
    const event: AuditEventRecord = {
      eventId: `evt_${randomUUID().slice(0, 12)}`,
      eventType: params.eventType,
      actorUserId: params.actorUserId,
      fileRef: params.fileRef ?? null,
      versionId: params.versionId ?? null,
      summary: params.summary,
      outcome: params.outcome,
      txHash: params.txHash ?? null,
      timestamp: new Date().toISOString(),
    };
    this.db.auditEvents.unshift(event);
    if (this.db.auditEvents.length > 500) {
      this.db.auditEvents = this.db.auditEvents.slice(0, 500);
    }
    await this.persist();
    return event;
  }

  // ---------- User Directory & Session Auth ----------

  async registerUserPublicProfile(profile: UserPublicProfile): Promise<UserPublicProfile> {
    await this.ensureLoaded();
    const existing = this.db.users[profile.userId];
    this.db.users[profile.userId] = profile;
    if (!existing) {
      await this.recordAudit({
        eventType: 'user_registered',
        actorUserId: profile.userId,
        summary: `Registered 3-role public identity for ${profile.displayName} (${profile.handle})`,
        outcome: 'success',
      });
    } else {
      await this.persist();
    }
    return profile;
  }

  async listUsers(): Promise<UserPublicProfile[]> {
    await this.ensureLoaded();
    return Object.values(this.db.users);
  }

  async getUser(userId: string): Promise<UserPublicProfile | null> {
    await this.ensureLoaded();
    return this.db.users[userId] ?? null;
  }

  async createAuthChallenge(userId: string): Promise<{
    challengeId: string;
    nonce: string;
    expiresAt: string;
  }> {
    await this.ensureLoaded();
    if (!this.db.users[userId]) {
      throw new Error('Unknown user identity.');
    }
    const challengeId = `chl_${randomUUID().slice(0, 12)}`;
    const nonce = randomBytes(24).toString('hex');
    const expiresAtMs = Date.now() + CHALLENGE_TTL_MS;
    this.challenges.set(challengeId, { challengeId, userId, nonce, expiresAtMs });
    return {
      challengeId,
      nonce,
      expiresAt: new Date(expiresAtMs).toISOString(),
    };
  }

  async verifyAuthChallenge(params: {
    challengeId: string;
    signatureHex: string;
  }): Promise<{ token: string; userId: string; expiresAt: string }> {
    await this.ensureLoaded();
    const ch = this.challenges.get(params.challengeId);
    if (!ch || Date.now() > ch.expiresAtMs) {
      this.challenges.delete(params.challengeId);
      throw new Error('Authentication challenge missing or expired.');
    }
    const user = this.db.users[ch.userId];
    if (!user) {
      throw new Error('User no longer exists.');
    }
    const payload = `LCFR-AUTH-v1|${ch.challengeId}|${ch.userId}|${ch.nonce}`;
    const valid = await verifyWithEcdsaP256(user.authPublicJwk, payload, params.signatureHex);
    this.challenges.delete(params.challengeId);
    if (!valid) {
      await this.recordAudit({
        eventType: 'access_denied',
        actorUserId: ch.userId,
        summary: 'Authentication challenge signature rejected.',
        outcome: 'rejected',
      });
      throw new Error('Authentication signature invalid.');
    }

    const expiresAtMs = Date.now() + SESSION_TTL_MS;
    const tokenBody = Buffer.from(
      JSON.stringify({ uid: ch.userId, exp: expiresAtMs, jti: randomUUID().slice(0, 8) }),
    ).toString('base64url');
    const sig = createHmac('sha256', this.sessionSecret).update(tokenBody).digest('base64url');
    const token = `${tokenBody}.${sig}`;

    await this.recordAudit({
      eventType: 'session_authenticated',
      actorUserId: ch.userId,
      summary: `Authenticated session established for ${user.displayName} (expires in 30m).`,
      outcome: 'success',
    });

    return {
      token,
      userId: ch.userId,
      expiresAt: new Date(expiresAtMs).toISOString(),
    };
  }

  verifySessionToken(authHeader: string | undefined): { userId: string } | null {
    if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
    const token = authHeader.slice(7).trim();
    const parts = token.split('.');
    if (parts.length !== 2) return null;
    const [body, sig] = parts;
    const expectedSig = createHmac('sha256', this.sessionSecret).update(body).digest('base64url');
    if (sig !== expectedSig) return null;
    try {
      const decoded = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')) as {
        uid: string;
        exp: number;
      };
      if (!decoded.uid || Date.now() > decoded.exp) {
        return null;
      }
      return { userId: decoded.uid };
    } catch {
      return null;
    }
  }

  // ---------- Multipart Upload Staging ----------

  initUploadSession(params: {
    userId: string;
    storageAdapter: StorageAdapterType;
    totalParts: number;
  }): string {
    if (params.totalParts < 1 || params.totalParts > 2000) {
      throw new Error('Invalid totalParts count.');
    }
    const uploadId = `upl_${randomUUID().replaceAll('-', '').slice(0, 16)}`;
    this.uploadSessions.set(uploadId, {
      uploadId,
      userId: params.userId,
      storageAdapter: params.storageAdapter,
      totalParts: params.totalParts,
      receivedParts: new Set(),
      totalBytes: 0,
      createdAtMs: Date.now(),
    });
    return uploadId;
  }

  async addUploadPart(params: {
    uploadId: string;
    userId: string;
    partIndex: number;
    bytes: Uint8Array;
  }): Promise<{ receivedParts: number; totalParts: number }> {
    const sess = this.uploadSessions.get(params.uploadId);
    if (!sess) throw new Error('Upload session not found.');
    if (sess.userId !== params.userId) throw new Error('Forbidden upload session.');
    if (params.partIndex < 0 || params.partIndex >= sess.totalParts) {
      throw new Error('Invalid upload part index.');
    }
    if (sess.totalBytes + params.bytes.byteLength > MAX_UPLOAD_BYTES) {
      await this.storage.abortStagedUpload(params.uploadId);
      this.uploadSessions.delete(params.uploadId);
      throw new Error(`Upload exceeds ${MAX_UPLOAD_BYTES} byte limit.`);
    }
    await this.storage.writeStagedChunk(params.uploadId, params.partIndex, params.bytes);
    sess.receivedParts.add(params.partIndex);
    sess.totalBytes += params.bytes.byteLength;
    return {
      receivedParts: sess.receivedParts.size,
      totalParts: sess.totalParts,
    };
  }

  async abortUploadSession(uploadId: string, userId: string): Promise<void> {
    const sess = this.uploadSessions.get(uploadId);
    if (!sess) return;
    if (sess.userId !== userId) throw new Error('Forbidden upload abort.');
    await this.storage.abortStagedUpload(uploadId);
    this.uploadSessions.delete(uploadId);
  }

  // ---------- Idempotent Finalisation & Registry Commit ----------

  async finaliseEncryptedUpload(params: {
    actorUserId: string;
    idempotencyKey: string;
    uploadId: string;
    fileRef: string;
    versionId?: string;
    isNewVersion: boolean;
    storageAdapter: StorageAdapterType;
    ciphertextCommitment: string;
    manifestCommitment: string;
    encryptionFormatVersion: string;
    cipherSuite: string;
    chunkSize: number;
    totalChunks: number;
    encryptedMetadata: FileVersionRecord['encryptedMetadata'];
    ownerEnvelope: Omit<KeyEnvelopeRecord, 'envelopeId' | 'createdAt' | 'retrievalCount' | 'revokedAt' | 'revokedByUserId'>;
    registrySignatureHex: string;
    deferFinality?: boolean;
  }): Promise<{
    file: EncryptedFileRecord;
    version: FileVersionRecord;
    idempotentReplay: boolean;
  }> {
    await this.ensureLoaded();

    // Idempotent upload finalisation check
    const cached = this.db.idempotencyCache[params.idempotencyKey];
    if (cached && this.db.files[cached.fileRef]) {
      const existingFile = this.db.files[cached.fileRef];
      const existingVersion = existingFile.versions.find((v) => v.versionId === cached.versionId);
      if (existingVersion) {
        return {
          file: existingFile,
          version: existingVersion,
          idempotentReplay: true,
        };
      }
    }

    const user = this.db.users[params.actorUserId];
    if (!user) throw new Error('Unknown user.');

    const existingFile = this.db.files[params.fileRef];
    if (params.isNewVersion) {
      if (!existingFile) throw new Error('Target fileRef not found for new version.');
      if (existingFile.ownerUserId !== params.actorUserId) {
        await this.recordAudit({
          eventType: 'access_denied',
          actorUserId: params.actorUserId,
          fileRef: params.fileRef,
          summary: 'Cross-user version publish rejected.',
          outcome: 'rejected',
        });
        throw new Error('Only the file owner can publish a new version.');
      }
    } else if (existingFile) {
      throw new Error('fileRef already exists.');
    }

    const sess = this.uploadSessions.get(params.uploadId);
    if (!sess || sess.userId !== params.actorUserId) {
      throw new Error('Upload session invalid or unauthorized.');
    }
    if (sess.receivedParts.size !== sess.totalParts) {
      throw new Error(
        `Upload incomplete (${sess.receivedParts.size}/${sess.totalParts} parts received).`,
      );
    }

    const ciphertextBytes = await this.storage.assembleStagedUpload(params.uploadId, sess.totalParts);
    this.uploadSessions.delete(params.uploadId);

    const versionNumber = existingFile ? existingFile.latestVersionNumber + 1 : 1;
    const storageKey = this.storage.createStorageKey(params.fileRef, versionNumber);
    const adapter = this.storage.getAdapter(params.storageAdapter);
    const storedMeta = await adapter.putObject(storageKey, ciphertextBytes);

    if (storedMeta.sha256.toLowerCase() !== params.ciphertextCommitment.toLowerCase()) {
      await adapter.deleteObject(storageKey);
      throw new Error('Uploaded ciphertext SHA-256 does not match declared ciphertextCommitment.');
    }

    const scanResult = this.scannerHook.evaluateCiphertextUpload({
      fileRef: params.fileRef,
      ciphertextByteLength: ciphertextBytes.byteLength,
    });

    const tx = await this.chain.submitTransaction({
      eventType: existingFile ? 'PUBLISH_VERSION' : 'REGISTER_FILE',
      fileRef: params.fileRef,
      versionNumber,
      ciphertextCommitment: params.ciphertextCommitment,
      manifestCommitment: params.manifestCommitment,
      formatVersion: params.encryptionFormatVersion,
      lifecycleStatus: 'finalised',
      ownerRegistryFingerprint: user.registryFingerprint,
      ownerRegistryPublicJwk: user.registryPublicJwk,
      signatureHex: params.registrySignatureHex,
      deferFinality: params.deferFinality,
    });

    const now = new Date().toISOString();
    const versionId =
      params.versionId && /^ver_[0-9a-f]{12,32}$/.test(params.versionId)
        ? params.versionId
        : `ver_${randomUUID().replaceAll('-', '').slice(0, 12)}`;

    const version: FileVersionRecord = {
      versionId,
      fileRef: params.fileRef,
      versionNumber,
      ownerUserId: user.userId,
      ownerRegistryFingerprint: user.registryFingerprint,
      ciphertextCommitment: params.ciphertextCommitment,
      manifestCommitment: params.manifestCommitment,
      encryptionFormatVersion: params.encryptionFormatVersion,
      cipherSuite: params.cipherSuite,
      chunkSize: params.chunkSize,
      totalChunks: params.totalChunks,
      ciphertextByteLength: storedMeta.byteLength,
      encryptedMetadata: params.encryptedMetadata,
      storageAdapter: params.storageAdapter,
      storageLocation: storedMeta.storageLocation,
      contentAddressCid: storedMeta.contentAddressCid,
      registryStatus: tx.status === 'finalised' ? 'finalised' : 'pending',
      registryTxHash: tx.txHash,
      registryBlockNumber: tx.blockNumber,
      malwareScanStatus: scanResult.status,
      createdAt: now,
      deletedAt: null,
    };

    const ownerEnvRecord: KeyEnvelopeRecord = {
      ...params.ownerEnvelope,
      versionId,
      envelopeId: `env_${randomUUID().replaceAll('-', '').slice(0, 12)}`,
      createdAt: now,
      revokedAt: null,
      revokedByUserId: null,
      retrievalCount: 0,
    };

    let targetFile: EncryptedFileRecord;
    if (existingFile) {
      existingFile.versions.push(version);
      existingFile.envelopes.push(ownerEnvRecord);
      existingFile.latestVersionNumber = versionNumber;
      existingFile.latestVersionId = versionId;
      existingFile.updatedAt = now;
      existingFile.lifecycleStatus = 'active';
      targetFile = existingFile;
    } else {
      targetFile = {
        fileRef: params.fileRef,
        ownerUserId: user.userId,
        ownerRegistryFingerprint: user.registryFingerprint,
        latestVersionNumber: versionNumber,
        latestVersionId: versionId,
        lifecycleStatus: 'active',
        createdAt: now,
        updatedAt: now,
        versions: [version],
        envelopes: [ownerEnvRecord],
        invitations: [],
      };
      this.db.files[params.fileRef] = targetFile;
    }

    this.db.idempotencyCache[params.idempotencyKey] = {
      versionId,
      fileRef: params.fileRef,
    };

    await this.recordAudit({
      eventType: 'upload_completed',
      actorUserId: user.userId,
      fileRef: params.fileRef,
      versionId,
      summary: `Ciphertext stored via ${params.storageAdapter.toUpperCase()} (${storedMeta.byteLength} bytes).`,
      outcome: 'success',
    });

    await this.recordAudit({
      eventType: existingFile ? 'version_replaced' : 'registry_submitted',
      actorUserId: user.userId,
      fileRef: params.fileRef,
      versionId,
      summary:
        tx.status === 'finalised'
          ? `Commitment v${versionNumber} finalised on chain in block #${tx.blockNumber}.`
          : `Commitment v${versionNumber} submitted to registry (pending finality).`,
      outcome: 'success',
      txHash: tx.txHash,
    });

    await this.persist();
    return { file: targetFile, version, idempotentReplay: false };
  }

  // ---------- Queries & Authorization ----------

  async listFilesForUser(userId: string): Promise<EncryptedFileRecord[]> {
    await this.ensureLoaded();
    const out: EncryptedFileRecord[] = [];
    for (const file of Object.values(this.db.files)) {
      const isOwner = file.ownerUserId === userId;
      const hasEnvelope = file.envelopes.some((e) => e.recipientId === userId);
      if (isOwner || hasEnvelope) {
        // Filter envelopes so non-owners only see their own envelopes
        out.push({
          ...file,
          envelopes: isOwner
            ? file.envelopes
            : file.envelopes.filter((e) => e.recipientId === userId),
          invitations: isOwner
            ? file.invitations
            : file.invitations.filter((inv) => inv.recipientId === userId),
        });
      }
    }
    return out.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }

  async getFileForUser(fileRef: string, userId: string): Promise<EncryptedFileRecord | null> {
    await this.ensureLoaded();
    const file = this.db.files[fileRef];
    if (!file) return null;
    const isOwner = file.ownerUserId === userId;
    const hasAccess = isOwner || file.envelopes.some((e) => e.recipientId === userId);
    if (!hasAccess) return null;
    return file;
  }

  async shareKeyEnvelope(params: {
    actorUserId: string;
    fileRef: string;
    versionId: string;
    recipientId: string;
    ephemeralPublicJwk: JsonWebKey;
    saltHex: string;
    ivHex: string;
    wrappedDekHex: string;
    recipientEncFingerprint: string;
    expiresInMinutes: number;
    note: string;
  }): Promise<{ envelope: KeyEnvelopeRecord; invitation: ShareInvitationRecord }> {
    await this.ensureLoaded();
    const file = this.db.files[params.fileRef];
    if (!file) throw new Error('File not found.');
    if (file.ownerUserId !== params.actorUserId) {
      await this.recordAudit({
        eventType: 'access_denied',
        actorUserId: params.actorUserId,
        fileRef: params.fileRef,
        versionId: params.versionId,
        summary: 'Non-owner attempted to create share envelope.',
        outcome: 'rejected',
      });
      throw new Error('Only the file owner can grant access.');
    }
    const version = file.versions.find((v) => v.versionId === params.versionId);
    if (!version || version.deletedAt) throw new Error('Target version unavailable.');

    const recipient = this.db.users[params.recipientId];
    if (!recipient) throw new Error('Recipient user not found.');

    const nowMs = Date.now();
    const now = new Date(nowMs).toISOString();
    const expiresAt = new Date(nowMs + Math.max(1, params.expiresInMinutes) * 60_000).toISOString();

    const envelopeId = `env_${randomUUID().replaceAll('-', '').slice(0, 12)}`;
    const inviteId = `inv_${randomUUID().replaceAll('-', '').slice(0, 12)}`;

    const envelope: KeyEnvelopeRecord = {
      envelopeId,
      fileRef: params.fileRef,
      versionId: params.versionId,
      recipientId: params.recipientId,
      grantedByUserId: params.actorUserId,
      keyAlgorithm: 'ECDH-P256-HKDF-SHA256-AES256GCM',
      ephemeralPublicJwk: params.ephemeralPublicJwk,
      saltHex: params.saltHex,
      ivHex: params.ivHex,
      wrappedDekHex: params.wrappedDekHex,
      recipientEncFingerprint: params.recipientEncFingerprint,
      createdAt: now,
      expiresAt,
      revokedAt: null,
      revokedByUserId: null,
      retrievalCount: 0,
    };

    const invitation: ShareInvitationRecord = {
      inviteId,
      fileRef: params.fileRef,
      versionId: params.versionId,
      recipientId: params.recipientId,
      createdByUserId: params.actorUserId,
      envelopeId,
      createdAt: now,
      expiresAt,
      revokedAt: null,
      acceptedAt: null,
      note: params.note.slice(0, 140),
    };

    file.envelopes.push(envelope);
    file.invitations.push(invitation);
    file.updatedAt = now;

    await this.recordAudit({
      eventType: 'share_invited',
      actorUserId: params.actorUserId,
      fileRef: params.fileRef,
      versionId: params.versionId,
      summary: `Shared key envelope for v${version.versionNumber} with ${recipient.displayName} (expires ${expiresAt}).`,
      outcome: 'success',
    });

    await this.persist();
    return { envelope, invitation };
  }

  async retrieveKeyEnvelope(params: {
    actorUserId: string;
    fileRef: string;
    versionId: string;
  }): Promise<KeyEnvelopeRecord> {
    await this.ensureLoaded();
    const file = this.db.files[params.fileRef];
    if (!file) throw new Error('File not found.');

    const candidate = [...file.envelopes]
      .reverse()
      .find((e) => e.versionId === params.versionId && e.recipientId === params.actorUserId);

    if (!candidate) {
      await this.recordAudit({
        eventType: 'access_denied',
        actorUserId: params.actorUserId,
        fileRef: params.fileRef,
        versionId: params.versionId,
        summary: `Unauthorised envelope retrieval attempt by ${params.actorUserId}.`,
        outcome: 'rejected',
      });
      throw new Error('403: No key envelope exists for your identity.');
    }

    if (candidate.revokedAt) {
      await this.recordAudit({
        eventType: 'access_denied',
        actorUserId: params.actorUserId,
        fileRef: params.fileRef,
        versionId: params.versionId,
        summary: `Revoked envelope retrieval blocked for ${params.actorUserId}.`,
        outcome: 'rejected',
      });
      throw new Error('403: Access to this key envelope has been revoked.');
    }

    if (candidate.expiresAt && Date.now() > Date.parse(candidate.expiresAt)) {
      await this.recordAudit({
        eventType: 'access_denied',
        actorUserId: params.actorUserId,
        fileRef: params.fileRef,
        versionId: params.versionId,
        summary: `Expired share invitation blocked for ${params.actorUserId}.`,
        outcome: 'rejected',
      });
      throw new Error('403: Share invitation has expired.');
    }

    candidate.retrievalCount += 1;
    const inv = file.invitations.find((i) => i.envelopeId === candidate.envelopeId);
    if (inv && !inv.acceptedAt) {
      inv.acceptedAt = new Date().toISOString();
    }

    await this.recordAudit({
      eventType: 'envelope_retrieved',
      actorUserId: params.actorUserId,
      fileRef: params.fileRef,
      versionId: params.versionId,
      summary: `Authorised recipient retrieved wrapped key envelope (retrieval #${candidate.retrievalCount}).`,
      outcome: 'success',
    });

    await this.persist();
    return candidate;
  }

  async downloadCiphertext(params: {
    actorUserId: string;
    fileRef: string;
    versionId: string;
  }): Promise<{ ciphertext: Uint8Array; version: FileVersionRecord }> {
    await this.ensureLoaded();
    const file = this.db.files[params.fileRef];
    if (!file) throw new Error('File not found.');

    const version = file.versions.find((v) => v.versionId === params.versionId);
    if (!version || version.deletedAt) {
      throw new Error('Ciphertext version unavailable or deleted.');
    }

    const isOwner = file.ownerUserId === params.actorUserId;
    const activeEnvelope = file.envelopes.find(
      (e) =>
        e.versionId === params.versionId &&
        e.recipientId === params.actorUserId &&
        !e.revokedAt &&
        (!e.expiresAt || Date.now() <= Date.parse(e.expiresAt)),
    );

    if (!isOwner && !activeEnvelope) {
      await this.recordAudit({
        eventType: 'access_denied',
        actorUserId: params.actorUserId,
        fileRef: params.fileRef,
        versionId: params.versionId,
        summary: `Unauthorised ciphertext download attempt blocked for ${params.actorUserId}.`,
        outcome: 'rejected',
      });
      throw new Error('403: You are not authorised to download this ciphertext.');
    }

    const storageKey = this.extractStorageKey(version);
    const adapter = this.storage.getAdapter(version.storageAdapter);
    const data = await adapter.getObject(storageKey);
    if (!data) {
      throw new Error('Ciphertext object missing from storage adapter.');
    }

    await this.recordAudit({
      eventType: 'download_requested',
      actorUserId: params.actorUserId,
      fileRef: params.fileRef,
      versionId: params.versionId,
      summary: `Ciphertext streamed from ${version.storageAdapter.toUpperCase()} (${data.byteLength} bytes).`,
      outcome: 'success',
    });

    return { ciphertext: data, version };
  }

  private extractStorageKey(version: FileVersionRecord): string {
    if (version.storageAdapter === 'local') {
      return version.storageLocation.replace('local://vault/', '').replace('.lcfr', '');
    }
    if (version.storageAdapter === 's3') {
      const idx = version.storageLocation.lastIndexOf('/objects/');
      return version.storageLocation.slice(idx + 9).replace('.bin', '');
    }
    // CAS resolves via stored version key prefix or we derive from files; let's inspect CAS keys
    return `${version.fileRef}_v${version.versionNumber}`;
  }

  private async resolveStorageKey(version: FileVersionRecord): Promise<string | null> {
    if (version.storageAdapter !== 'cas') {
      return this.extractStorageKey(version);
    }
    const keys = await this.storage.cas.listKeys();
    const prefix = `${version.fileRef}_v${version.versionNumber}_`;
    return keys.find((k) => k.startsWith(prefix)) ?? null;
  }

  async getCiphertextBytesForVersion(version: FileVersionRecord): Promise<Uint8Array | null> {
    const key = await this.resolveStorageKey(version);
    if (!key) return null;
    return this.storage.getAdapter(version.storageAdapter).getObject(key);
  }

  async downloadCiphertextAuthorized(params: {
    actorUserId: string;
    fileRef: string;
    versionId: string;
  }): Promise<{ ciphertext: Uint8Array; version: FileVersionRecord }> {
    await this.ensureLoaded();
    const file = this.db.files[params.fileRef];
    if (!file) throw new Error('File not found.');

    const version = file.versions.find((v) => v.versionId === params.versionId);
    if (!version || version.deletedAt) {
      throw new Error('Ciphertext version unavailable or deleted.');
    }

    const isOwner = file.ownerUserId === params.actorUserId;
    const activeEnvelope = file.envelopes.find(
      (e) =>
        e.versionId === params.versionId &&
        e.recipientId === params.actorUserId &&
        !e.revokedAt &&
        (!e.expiresAt || Date.now() <= Date.parse(e.expiresAt)),
    );

    if (!isOwner && !activeEnvelope) {
      await this.recordAudit({
        eventType: 'access_denied',
        actorUserId: params.actorUserId,
        fileRef: params.fileRef,
        versionId: params.versionId,
        summary: `Unauthorised ciphertext download attempt blocked for ${params.actorUserId}.`,
        outcome: 'rejected',
      });
      throw new Error('403: You are not authorised to download this ciphertext.');
    }

    const data = await this.getCiphertextBytesForVersion(version);
    if (!data) {
      throw new Error('Ciphertext object missing from storage adapter.');
    }

    await this.recordAudit({
      eventType: 'download_requested',
      actorUserId: params.actorUserId,
      fileRef: params.fileRef,
      versionId: params.versionId,
      summary: `Ciphertext streamed from ${version.storageAdapter.toUpperCase()} (${data.byteLength} bytes).`,
      outcome: 'success',
    });

    return { ciphertext: data, version };
  }

  async revokeRecipientAccess(params: {
    actorUserId: string;
    fileRef: string;
    recipientId: string;
    registrySignatureHex?: string;
  }): Promise<{ revokedCount: number; txHash: string | null }> {
    await this.ensureLoaded();
    const file = this.db.files[params.fileRef];
    if (!file) throw new Error('File not found.');
    if (file.ownerUserId !== params.actorUserId) {
      await this.recordAudit({
        eventType: 'access_denied',
        actorUserId: params.actorUserId,
        fileRef: params.fileRef,
        summary: 'Non-owner revocation attempt blocked.',
        outcome: 'rejected',
      });
      throw new Error('403: Only the file owner can revoke access.');
    }

    const now = new Date().toISOString();
    let revokedCount = 0;
    for (const env of file.envelopes) {
      if (env.recipientId === params.recipientId && !env.revokedAt) {
        env.revokedAt = now;
        env.revokedByUserId = params.actorUserId;
        revokedCount++;
      }
    }
    for (const inv of file.invitations) {
      if (inv.recipientId === params.recipientId && !inv.revokedAt) {
        inv.revokedAt = now;
      }
    }
    file.updatedAt = now;

    await this.recordAudit({
      eventType: 'access_revoked',
      actorUserId: params.actorUserId,
      fileRef: params.fileRef,
      summary: `Revoked ${revokedCount} key envelope(s) for ${params.recipientId}. Future envelope retrieval & downloads blocked.`,
      outcome: 'success',
    });

    await this.persist();
    return { revokedCount, txHash: null };
  }

  async deleteVersionCiphertext(params: {
    actorUserId: string;
    fileRef: string;
    versionId: string;
    registrySignatureHex?: string;
  }): Promise<void> {
    await this.ensureLoaded();
    const file = this.db.files[params.fileRef];
    if (!file) throw new Error('File not found.');
    if (file.ownerUserId !== params.actorUserId) {
      throw new Error('403: Only the file owner can delete ciphertext.');
    }
    const version = file.versions.find((v) => v.versionId === params.versionId);
    if (!version) throw new Error('Version not found.');

    const key = await this.resolveStorageKey(version);
    if (key) {
      await this.storage.getAdapter(version.storageAdapter).deleteObject(key);
    }
    version.deletedAt = new Date().toISOString();
    if (file.versions.every((v) => v.deletedAt !== null)) {
      file.lifecycleStatus = 'deleted';
    }
    file.updatedAt = new Date().toISOString();

    const user = this.db.users[params.actorUserId];
    if (params.registrySignatureHex && user) {
      const tx = await this.chain.submitTransaction({
        eventType: 'UPDATE_STATUS',
        fileRef: params.fileRef,
        versionNumber: version.versionNumber,
        ciphertextCommitment: version.ciphertextCommitment,
        manifestCommitment: version.manifestCommitment,
        formatVersion: version.encryptionFormatVersion,
        lifecycleStatus: 'revoked',
        ownerRegistryFingerprint: user.registryFingerprint,
        ownerRegistryPublicJwk: user.registryPublicJwk,
        signatureHex: params.registrySignatureHex,
      });
      version.registryStatus = 'revoked';
      version.registryTxHash = tx.txHash;
      version.registryBlockNumber = tx.blockNumber;
    }

    await this.recordAudit({
      eventType: 'object_deleted',
      actorUserId: params.actorUserId,
      fileRef: params.fileRef,
      versionId: params.versionId,
      summary: `Deleted ciphertext object from ${version.storageAdapter.toUpperCase()} adapter (on-chain commitment remains immutable).`,
      outcome: 'warning',
    });

    await this.persist();
  }

  async simulateCiphertextTamper(params: {
    actorUserId: string;
    fileRef: string;
    versionId: string;
  }): Promise<{ byteOffset: number }> {
    await this.ensureLoaded();
    const file = this.db.files[params.fileRef];
    if (!file) throw new Error('File not found.');
    const version = file.versions.find((v) => v.versionId === params.versionId);
    if (!version || version.deletedAt) throw new Error('Version not available.');
    const key = await this.resolveStorageKey(version);
    if (!key) throw new Error('Storage object not found.');

    const adapter = this.storage.getAdapter(version.storageAdapter);
    const bytes = await adapter.getObject(key);
    if (!bytes || bytes.byteLength < 70) throw new Error('Ciphertext too short to tamper.');

    const mutated = new Uint8Array(bytes);
    const offset = Math.min(mutated.byteLength - 4, 72);
    mutated[offset] = mutated[offset] ^ 0xff;
    await adapter.putObject(key, mutated);

    await this.recordAudit({
      eventType: 'tamper_simulated',
      actorUserId: params.actorUserId,
      fileRef: params.fileRef,
      versionId: params.versionId,
      summary: `Simulated storage-provider tampering: flipped 1 byte at offset ${offset} of v${version.versionNumber}.`,
      outcome: 'warning',
    });

    return { byteOffset: offset };
  }

  async syncRegistryStates(): Promise<void> {
    await this.ensureLoaded();
    for (const file of Object.values(this.db.files)) {
      for (const version of file.versions) {
        if (version.registryTxHash) {
          const tx = await this.chain.getTransaction(version.registryTxHash);
          if (tx) {
            version.registryStatus =
              tx.status === 'finalised'
                ? version.deletedAt
                  ? 'revoked'
                  : 'finalised'
                : tx.status === 'reorganised'
                  ? 'reorganised'
                  : tx.status === 'failed'
                    ? 'failed'
                    : 'pending';
            version.registryBlockNumber = tx.blockNumber;
          }
        }
      }
    }
    await this.persist();
  }

  async purgeOrphanedStorage(): Promise<{
    local: string[];
    s3: string[];
    cas: string[];
  }> {
    await this.ensureLoaded();
    const activeLocal = new Set<string>();
    const activeS3 = new Set<string>();
    const activeCas = new Set<string>();

    for (const file of Object.values(this.db.files)) {
      for (const v of file.versions) {
        if (v.deletedAt) continue;
        const key = await this.resolveStorageKey(v);
        if (!key) continue;
        if (v.storageAdapter === 'local') activeLocal.add(key);
        if (v.storageAdapter === 's3') activeS3.add(key);
        if (v.storageAdapter === 'cas') activeCas.add(key);
      }
    }

    const [local, s3, cas] = await Promise.all([
      this.storage.local.purgeOrphans(activeLocal),
      this.storage.s3.purgeOrphans(activeS3),
      this.storage.cas.purgeOrphans(activeCas),
    ]);

    const total = local.length + s3.length + cas.length;
    await this.recordAudit({
      eventType: 'orphans_purged',
      actorUserId: 'system',
      summary: `Storage orphan cleanup completed: removed ${total} unreferenced object(s).`,
      outcome: 'success',
    });

    return { local, s3, cas };
  }

  async getStorageInventory(): Promise<{
    localKeys: string[];
    s3Keys: string[];
    casKeys: string[];
    scannerHook: { modeName: string };
  }> {
    const [localKeys, s3Keys, casKeys] = await Promise.all([
      this.storage.local.listKeys(),
      this.storage.s3.listKeys(),
      this.storage.cas.listKeys(),
    ]);
    return {
      localKeys,
      s3Keys,
      casKeys,
      scannerHook: { modeName: this.scannerHook.modeName },
    };
  }

  async listAuditEvents(): Promise<AuditEventRecord[]> {
    await this.ensureLoaded();
    return this.db.auditEvents;
  }
}
