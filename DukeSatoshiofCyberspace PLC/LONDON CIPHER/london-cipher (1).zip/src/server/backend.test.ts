import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import {
  bytesToHex,
  canonicalRegistrySignPayload,
  encryptFileChunked,
  generateRandomFileRef,
  generateUserKeyBundle,
  LCFR_CIPHER_SUITE_LABEL,
  LCFR_FORMAT_LABEL,
  signWithEcdsaP256,
  wrapDekForRecipient,
} from '../shared/cipher-core';
import { LondonCipherChain } from './blockchain-registry';
import { RegistryStore } from './registry-store';
import { StorageAdapterRegistry } from './storage-adapters';

describe('London Cipher Backend, Storage & Blockchain Registry', () => {
  let tempDir: string;
  let storage: StorageAdapterRegistry;
  let chain: LondonCipherChain;
  let store: RegistryStore;

  beforeEach(async () => {
    tempDir = await mkdtemp(join(tmpdir(), 'lcfr-test-'));
    storage = new StorageAdapterRegistry(tempDir);
    chain = new LondonCipherChain(tempDir);
    store = new RegistryStore(tempDir, storage, chain);
  });

  afterEach(async () => {
    await rm(tempDir, { recursive: true, force: true });
  });

  async function registerDemoUsers() {
    const owner = await generateUserKeyBundle({
      userId: 'usr_owner',
      displayName: 'Eleanor Vance',
      handle: 'eleanor@demo',
      roleLabel: 'Owner',
    });
    const recipient = await generateUserKeyBundle({
      userId: 'usr_recipient',
      displayName: 'Marcus Sterling',
      handle: 'marcus@demo',
      roleLabel: 'Recipient',
    });
    const outsider = await generateUserKeyBundle({
      userId: 'usr_outsider',
      displayName: 'Julian Croft',
      handle: 'julian@demo',
      roleLabel: 'Outsider',
    });

    for (const u of [owner, recipient, outsider]) {
      await store.registerUserPublicProfile({
        userId: u.userId,
        displayName: u.displayName,
        handle: u.handle,
        roleLabel: u.roleLabel,
        authPublicJwk: u.authPublicJwk,
        registryPublicJwk: u.registryPublicJwk,
        encPublicJwk: u.encPublicJwk,
        authFingerprint: u.authFingerprint,
        registryFingerprint: u.registryFingerprint,
        encFingerprint: u.encFingerprint,
        createdAt: new Date().toISOString(),
      });
    }
    return { owner, recipient, outsider };
  }

  it('enforces idempotent finalisation, cross-user rejection, expiry, revocation, reorg recovery, and zero secrets in persisted metadata', async () => {
    const { owner, recipient, outsider } = await registerDemoUsers();

    // 1. Encrypt locally with sensitive filename that must NEVER appear on disk metadata or chain
    const secretFilename = 'super-secret-board-takeover-plan.pdf';
    const enc = await encryptFileChunked({
      bytes: new TextEncoder().encode('Confidential Merger Terms'),
      originalName: secretFilename,
      mimeType: 'application/pdf',
    });

    const fileRef = generateRandomFileRef();
    const versionId = 'ver_0000111122223333';
    const ownerEnv = await wrapDekForRecipient({
      dekBytes: enc.dekBytes,
      fileRef,
      versionId,
      recipientId: owner.userId,
      recipientEncPublicJwk: owner.encPublicJwk,
      expectedRecipientFingerprint: owner.encFingerprint,
    });

    const uploadId = store.initUploadSession({
      userId: owner.userId,
      storageAdapter: 'cas',
      totalParts: 1,
    });
    await store.addUploadPart({
      uploadId,
      userId: owner.userId,
      partIndex: 0,
      bytes: enc.ciphertext,
    });

    const sig = await signWithEcdsaP256(
      owner.registryPrivateJwk,
      canonicalRegistrySignPayload({
        eventType: 'REGISTER_FILE',
        fileRef,
        versionNumber: 1,
        ciphertextCommitment: enc.ciphertextCommitment,
        manifestCommitment: enc.manifestCommitment,
        formatVersion: LCFR_FORMAT_LABEL,
        lifecycleStatus: 'finalised',
        ownerRegistryFingerprint: owner.registryFingerprint,
      }),
    );

    const idemKey = 'idem_test_1';
    const res1 = await store.finaliseEncryptedUpload({
      actorUserId: owner.userId,
      idempotencyKey: idemKey,
      uploadId,
      fileRef,
      versionId,
      isNewVersion: false,
      storageAdapter: 'cas',
      ciphertextCommitment: enc.ciphertextCommitment,
      manifestCommitment: enc.manifestCommitment,
      encryptionFormatVersion: LCFR_FORMAT_LABEL,
      cipherSuite: LCFR_CIPHER_SUITE_LABEL,
      chunkSize: enc.chunkSize,
      totalChunks: enc.totalChunks,
      encryptedMetadata: enc.encryptedMetadata,
      ownerEnvelope: {
        fileRef,
        versionId,
        recipientId: owner.userId,
        grantedByUserId: owner.userId,
        keyAlgorithm: 'ECDH-P256-HKDF-SHA256-AES256GCM',
        ...ownerEnv,
        expiresAt: null,
      },
      registrySignatureHex: sig,
    });
    expect(res1.idempotentReplay).toBe(false);
    expect(res1.version.contentAddressCid).toMatch(/^cid:sha256:/);

    // 2. Duplicate finalisation returns idempotent replay without error or duplicate version
    const res2 = await store.finaliseEncryptedUpload({
      actorUserId: owner.userId,
      idempotencyKey: idemKey,
      uploadId: 'upl_unused',
      fileRef,
      versionId,
      isNewVersion: false,
      storageAdapter: 'cas',
      ciphertextCommitment: enc.ciphertextCommitment,
      manifestCommitment: enc.manifestCommitment,
      encryptionFormatVersion: LCFR_FORMAT_LABEL,
      cipherSuite: LCFR_CIPHER_SUITE_LABEL,
      chunkSize: enc.chunkSize,
      totalChunks: enc.totalChunks,
      encryptedMetadata: enc.encryptedMetadata,
      ownerEnvelope: {
        fileRef,
        versionId,
        recipientId: owner.userId,
        grantedByUserId: owner.userId,
        keyAlgorithm: 'ECDH-P256-HKDF-SHA256-AES256GCM',
        ...ownerEnv,
        expiresAt: null,
      },
      registrySignatureHex: sig,
    });
    expect(res2.idempotentReplay).toBe(true);
    expect(res2.file.versions.length).toBe(1);

    // 3. Cross-user access rejection for outsider
    await expect(
      store.retrieveKeyEnvelope({
        actorUserId: outsider.userId,
        fileRef,
        versionId,
      }),
    ).rejects.toThrow(/403:/);

    await expect(
      store.downloadCiphertextAuthorized({
        actorUserId: outsider.userId,
        fileRef,
        versionId,
      }),
    ).rejects.toThrow(/403:/);

    // 4. Registry permissions: outsider cannot submit PUBLISH_VERSION on owner's fileRef
    const forgedSig = await signWithEcdsaP256(
      outsider.registryPrivateJwk,
      canonicalRegistrySignPayload({
        eventType: 'PUBLISH_VERSION',
        fileRef,
        versionNumber: 2,
        ciphertextCommitment: enc.ciphertextCommitment,
        manifestCommitment: enc.manifestCommitment,
        formatVersion: LCFR_FORMAT_LABEL,
        lifecycleStatus: 'finalised',
        ownerRegistryFingerprint: outsider.registryFingerprint,
      }),
    );
    await expect(
      chain.submitTransaction({
        eventType: 'PUBLISH_VERSION',
        fileRef,
        versionNumber: 2,
        ciphertextCommitment: enc.ciphertextCommitment,
        manifestCommitment: enc.manifestCommitment,
        formatVersion: LCFR_FORMAT_LABEL,
        lifecycleStatus: 'finalised',
        ownerRegistryFingerprint: outsider.registryFingerprint,
        ownerRegistryPublicJwk: outsider.registryPublicJwk,
        signatureHex: forgedSig,
      }),
    ).rejects.toThrow(/Registry permission denied/);

    // 5. Expired invitation blocked
    const recEnv = await wrapDekForRecipient({
      dekBytes: enc.dekBytes,
      fileRef,
      versionId,
      recipientId: recipient.userId,
      recipientEncPublicJwk: recipient.encPublicJwk,
      expectedRecipientFingerprint: recipient.encFingerprint,
    });
    await store.shareKeyEnvelope({
      actorUserId: owner.userId,
      fileRef,
      versionId,
      recipientId: recipient.userId,
      ...recEnv,
      expiresInMinutes: -5, // Force immediate expiry check? Note: Math.max(1, ...) clamps to 1 min in shareKeyEnvelope
      note: 'Test',
    });

    // Manually backdate expiry on the envelope to test expired invitation rejection deterministically
    const ownerFile = await store.getFileForUser(fileRef, owner.userId);
    const sharedEnv = ownerFile!.envelopes.find((e) => e.recipientId === recipient.userId)!;
    sharedEnv.expiresAt = new Date(Date.now() - 10_000).toISOString();

    await expect(
      store.retrieveKeyEnvelope({
        actorUserId: recipient.userId,
        fileRef,
        versionId,
      }),
    ).rejects.toThrow(/expired/);

    // 6. Active share works, then revocation blocks future retrieval
    sharedEnv.expiresAt = new Date(Date.now() + 60_000).toISOString();
    const retrieved = await store.retrieveKeyEnvelope({
      actorUserId: recipient.userId,
      fileRef,
      versionId,
    });
    expect(retrieved.retrievalCount).toBe(1);

    await store.revokeRecipientAccess({
      actorUserId: owner.userId,
      fileRef,
      recipientId: recipient.userId,
    });
    await expect(
      store.retrieveKeyEnvelope({
        actorUserId: recipient.userId,
        fileRef,
        versionId,
      }),
    ).rejects.toThrow(/revoked/);

    // 7. Blockchain reorg simulation & event recovery
    const reorg = await chain.simulateLatestBlockReorg();
    expect(reorg.affectedTxHashes.length).toBe(1);
    await store.syncRegistryStates();

    const recovered = await chain.recoverReorganisedEvents();
    expect(recovered.recoveredTxHashes.length).toBe(1);
    await store.syncRegistryStates();

    const snap = await chain.getSnapshot();
    expect(snap.transactions[0].status).toBe('finalised');

    // 8. Verify absence of plaintext filenames, DEKs, and private keys in persisted metadata & chain files
    const dbRaw = await readFile(join(tempDir, 'metadata-db.json'), 'utf8');
    const chainRaw = await readFile(join(tempDir, 'chain-ledger.json'), 'utf8');
    const dekHex = bytesToHex(enc.dekBytes);

    expect(dbRaw).not.toContain(secretFilename);
    expect(dbRaw).not.toContain(dekHex);
    expect(dbRaw).not.toContain('encPrivateJwk');
    expect(chainRaw).not.toContain(secretFilename);
    expect(chainRaw).not.toContain(dekHex);
    expect(chainRaw).not.toContain('eleanor@demo');
  });
});
