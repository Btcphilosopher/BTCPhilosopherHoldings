import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import {
  canonicalRegistrySignPayload,
  verifyWithEcdsaP256,
} from '../shared/cipher-core';
import {
  RegistryBlockRecord,
  RegistryLifecycleStatus,
  RegistryTransactionRecord,
} from '../shared/cipher-types';

interface ChainState {
  chainId: number;
  networkName: string;
  blocks: RegistryBlockRecord[];
  transactions: RegistryTransactionRecord[];
  fileOwners: Record<string, string>; // fileRef -> ownerRegistryFingerprint
}

const FORBIDDEN_ONCHAIN_KEYS = new Set([
  'filename',
  'originalname',
  'email',
  'plaintext',
  'plaintexthash',
  'dek',
  'privatekey',
  'secret',
  'passphrase',
]);

function sha256Chain(input: string): string {
  return `0x${createHash('sha256').update(input).digest('hex')}`;
}

export class LondonCipherChain {
  private readonly chainFilePath: string;
  private state: ChainState = {
    chainId: 31337,
    networkName: 'London Cipher Local Registry Chain',
    blocks: [],
    transactions: [],
    fileOwners: {},
  };
  private loaded = false;

  constructor(baseDir: string) {
    this.chainFilePath = resolve(baseDir, 'chain-ledger.json');
  }

  async ensureLoaded(): Promise<void> {
    if (this.loaded) return;
    try {
      const raw = await readFile(this.chainFilePath, 'utf8');
      this.state = JSON.parse(raw) as ChainState;
    } catch {
      const genesis: RegistryBlockRecord = {
        blockNumber: 0,
        blockHash: sha256Chain('LONDON_CIPHER_GENESIS_31337'),
        parentHash: '0x' + '0'.repeat(64),
        timestamp: new Date().toISOString(),
        txHashes: [],
        stateRoot: sha256Chain('EMPTY_STATE'),
        status: 'finalised',
      };
      this.state.blocks = [genesis];
      await this.persist();
    }
    this.loaded = true;
  }

  private async persist(): Promise<void> {
    await mkdir(dirname(this.chainFilePath), { recursive: true });
    await writeFile(this.chainFilePath, JSON.stringify(this.state, null, 2), 'utf8');
  }

  assertNoPlaintextFields(payload: Record<string, unknown>): void {
    for (const key of Object.keys(payload)) {
      if (FORBIDDEN_ONCHAIN_KEYS.has(key.toLowerCase())) {
        throw new Error(`Forbidden plaintext/secret field "${key}" rejected from blockchain registry.`);
      }
    }
  }

  async submitTransaction(params: {
    eventType: 'REGISTER_FILE' | 'PUBLISH_VERSION' | 'UPDATE_STATUS';
    fileRef: string;
    versionNumber: number;
    ciphertextCommitment: string;
    manifestCommitment: string;
    formatVersion: string;
    lifecycleStatus: RegistryLifecycleStatus;
    ownerRegistryFingerprint: string;
    ownerRegistryPublicJwk: JsonWebKey;
    signatureHex: string;
    deferFinality?: boolean;
  }): Promise<RegistryTransactionRecord> {
    await this.ensureLoaded();

    this.assertNoPlaintextFields(params as unknown as Record<string, unknown>);

    if (!/^lcfr_[0-9a-f]{32}$/.test(params.fileRef)) {
      throw new Error('Registry requires an opaque random fileRef.');
    }

    const existingOwner = this.state.fileOwners[params.fileRef];
    if (params.eventType === 'REGISTER_FILE') {
      if (existingOwner) {
        throw new Error('fileRef already registered on-chain.');
      }
    } else {
      if (!existingOwner) {
        throw new Error('Cannot update unregistered fileRef on-chain.');
      }
      if (existingOwner !== params.ownerRegistryFingerprint) {
        throw new Error('Registry permission denied: caller registry identity is not the fileRef owner.');
      }
    }

    const canonicalPayload = canonicalRegistrySignPayload({
      eventType: params.eventType,
      fileRef: params.fileRef,
      versionNumber: params.versionNumber,
      ciphertextCommitment: params.ciphertextCommitment,
      manifestCommitment: params.manifestCommitment,
      formatVersion: params.formatVersion,
      lifecycleStatus: params.lifecycleStatus,
      ownerRegistryFingerprint: params.ownerRegistryFingerprint,
    });

    const sigValid = await verifyWithEcdsaP256(
      params.ownerRegistryPublicJwk,
      canonicalPayload,
      params.signatureHex,
    );
    if (!sigValid) {
      throw new Error('Invalid ECDSA P-256 registry signature.');
    }

    const submittedAt = new Date().toISOString();
    const txHash = sha256Chain(
      `${canonicalPayload}|${params.signatureHex}|${submittedAt}|${this.state.transactions.length}`,
    );

    const tx: RegistryTransactionRecord = {
      txHash,
      blockNumber: null,
      blockHash: null,
      eventType: params.eventType,
      fileRef: params.fileRef,
      versionNumber: params.versionNumber,
      ciphertextCommitment: params.ciphertextCommitment,
      manifestCommitment: params.manifestCommitment,
      formatVersion: params.formatVersion,
      ownerRegistryFingerprint: params.ownerRegistryFingerprint,
      lifecycleStatus: params.lifecycleStatus,
      signatureHex: params.signatureHex,
      status: 'pending',
      confirmations: 0,
      submittedAt,
      finalisedAt: null,
    };

    if (params.eventType === 'REGISTER_FILE') {
      this.state.fileOwners[params.fileRef] = params.ownerRegistryFingerprint;
    }

    this.state.transactions.push(tx);

    if (!params.deferFinality) {
      await this.minePendingTransactions();
    } else {
      await this.persist();
    }

    return this.state.transactions.find((t) => t.txHash === txHash)!;
  }

  async minePendingTransactions(): Promise<RegistryBlockRecord | null> {
    await this.ensureLoaded();
    const pending = this.state.transactions.filter((t) => t.status === 'pending');
    if (pending.length === 0) return null;

    const finalisedBlocks = this.state.blocks.filter((b) => b.status === 'finalised');
    const tip = finalisedBlocks[finalisedBlocks.length - 1];
    const blockNumber = tip.blockNumber + 1;
    const timestamp = new Date().toISOString();
    const txHashes = pending.map((t) => t.txHash);
    const stateRoot = sha256Chain(
      JSON.stringify(this.state.fileOwners) + txHashes.join(','),
    );
    const blockHash = sha256Chain(
      `${blockNumber}|${tip.blockHash}|${stateRoot}|${timestamp}`,
    );

    const block: RegistryBlockRecord = {
      blockNumber,
      blockHash,
      parentHash: tip.blockHash,
      timestamp,
      txHashes,
      stateRoot,
      status: 'finalised',
    };

    this.state.blocks.push(block);

    for (const tx of pending) {
      tx.blockNumber = blockNumber;
      tx.blockHash = blockHash;
      tx.status = 'finalised';
      tx.confirmations = 1;
      tx.finalisedAt = timestamp;
    }

    // Increment confirmations on earlier finalised blocks
    for (const tx of this.state.transactions) {
      if (tx.status === 'finalised' && tx.blockNumber !== null && tx.blockNumber < blockNumber) {
        tx.confirmations = blockNumber - tx.blockNumber + 1;
      }
    }

    await this.persist();
    return block;
  }

  async simulateLatestBlockReorg(): Promise<{
    reorganisedBlock: RegistryBlockRecord | null;
    affectedTxHashes: string[];
  }> {
    await this.ensureLoaded();
    const finalisedBlocks = this.state.blocks.filter(
      (b) => b.status === 'finalised' && b.blockNumber > 0,
    );
    if (finalisedBlocks.length === 0) {
      return { reorganisedBlock: null, affectedTxHashes: [] };
    }
    const target = finalisedBlocks[finalisedBlocks.length - 1];
    target.status = 'reorganised';

    const affectedTxHashes: string[] = [];
    for (const tx of this.state.transactions) {
      if (tx.blockHash === target.blockHash) {
        tx.status = 'reorganised';
        tx.confirmations = 0;
        affectedTxHashes.push(tx.txHash);
      }
    }

    await this.persist();
    return { reorganisedBlock: target, affectedTxHashes };
  }

  async recoverReorganisedEvents(): Promise<{
    recoveryBlock: RegistryBlockRecord | null;
    recoveredTxHashes: string[];
  }> {
    await this.ensureLoaded();
    const reorgTxs = this.state.transactions.filter((t) => t.status === 'reorganised');
    if (reorgTxs.length === 0) {
      return { recoveryBlock: null, recoveredTxHashes: [] };
    }

    const finalisedBlocks = this.state.blocks.filter((b) => b.status === 'finalised');
    const tip = finalisedBlocks[finalisedBlocks.length - 1];
    const blockNumber = tip.blockNumber + 1;
    const timestamp = new Date().toISOString();
    const recoveredTxHashes = reorgTxs.map((t) => t.txHash);
    const stateRoot = sha256Chain(
      JSON.stringify(this.state.fileOwners) + recoveredTxHashes.join(','),
    );
    const blockHash = sha256Chain(
      `RECOVER|${blockNumber}|${tip.blockHash}|${stateRoot}|${timestamp}`,
    );

    const recoveryBlock: RegistryBlockRecord = {
      blockNumber,
      blockHash,
      parentHash: tip.blockHash,
      timestamp,
      txHashes: recoveredTxHashes,
      stateRoot,
      status: 'finalised',
    };

    this.state.blocks.push(recoveryBlock);

    for (const tx of reorgTxs) {
      tx.blockNumber = blockNumber;
      tx.blockHash = blockHash;
      tx.status = 'finalised';
      tx.confirmations = 1;
      tx.finalisedAt = timestamp;
    }

    await this.persist();
    return { recoveryBlock, recoveredTxHashes };
  }

  async getSnapshot(): Promise<{
    chainId: number;
    networkName: string;
    latestBlockNumber: number;
    blocks: RegistryBlockRecord[];
    transactions: RegistryTransactionRecord[];
  }> {
    await this.ensureLoaded();
    const finalised = this.state.blocks.filter((b) => b.status === 'finalised');
    const latestBlockNumber = finalised.length > 0 ? finalised[finalised.length - 1].blockNumber : 0;
    return {
      chainId: this.state.chainId,
      networkName: this.state.networkName,
      latestBlockNumber,
      blocks: [...this.state.blocks].reverse(),
      transactions: [...this.state.transactions].reverse(),
    };
  }

  async getTransaction(txHash: string): Promise<RegistryTransactionRecord | null> {
    await this.ensureLoaded();
    return this.state.transactions.find((t) => t.txHash === txHash) ?? null;
  }

  async getFileEvents(fileRef: string): Promise<RegistryTransactionRecord[]> {
    await this.ensureLoaded();
    return this.state.transactions.filter((t) => t.fileRef === fileRef);
  }
}
