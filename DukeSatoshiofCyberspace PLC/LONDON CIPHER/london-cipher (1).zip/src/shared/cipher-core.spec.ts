import {
  bytesToHex,
  CipherError,
  createEncryptedKeyBackup,
  decryptFileStaged,
  encryptFileChunked,
  generateRandomFileRef,
  generateUserKeyBundle,
  LCFR_HEADER_BYTES,
  parseHeader,
  randomBytes,
  restoreEncryptedKeyBackup,
  sanitizeDownloadFilename,
  unwrapDekFromEnvelope,
  wrapDekForRecipient,
} from './cipher-core';

describe('London Cipher Cryptographic Core (LCFR-v1)', () => {
  it('performs round-trip encryption and decryption with metadata verification', async () => {
    const plain = new TextEncoder().encode('Confidential Chancery Document — Round-trip Test');
    const enc = await encryptFileChunked({
      bytes: plain,
      originalName: '../../secret/../briefing.txt',
      mimeType: 'text/plain',
      chunkSize: 128,
    });

    const dec = await decryptFileStaged({
      ciphertext: enc.ciphertext,
      dekBytes: enc.dekBytes,
      expectedCiphertextCommitment: enc.ciphertextCommitment,
      encryptedMetadata: enc.encryptedMetadata,
    });

    expect(Array.from(dec.plaintext)).toEqual(Array.from(plain));
    expect(dec.metadata?.originalName).toBe('briefing.txt');
    expect(dec.report.commitmentMatches).toBe(true);
    expect(dec.report.decryptionSucceeded).toBe(true);
    expect(dec.report.chunkOrderVerified).toBe(true);
    expect(dec.report.truncationCheckPassed).toBe(true);
    expect(dec.report.contentSafetyStatus).toBe('unscanned_client_encrypted');
  });

  it('supports empty 0-byte files cleanly and authenticates header', async () => {
    const enc = await encryptFileChunked({
      bytes: new Uint8Array(0),
      originalName: 'empty-attestation.txt',
      mimeType: 'text/plain',
    });
    expect(enc.totalChunks).toBe(1);
    expect(enc.plaintextSize).toBe(0);

    const dec = await decryptFileStaged({
      ciphertext: enc.ciphertext,
      dekBytes: enc.dekBytes,
      expectedCiphertextCommitment: enc.ciphertextCommitment,
      encryptedMetadata: enc.encryptedMetadata,
    });
    expect(dec.plaintext.byteLength).toBe(0);
    expect(dec.metadata?.originalName).toBe('empty-attestation.txt');
  });

  it('handles multi-chunk large-file streaming with bounded chunk size', async () => {
    const size = 512 * 1024 + 37; // 512 KiB + 37 bytes
    const plain = new Uint8Array(size);
    for (let i = 0; i < size; i++) {
      plain[i] = (i * 31) & 0xff;
    }

    const enc = await encryptFileChunked({
      bytes: plain,
      originalName: 'large-ledger-export.bin',
      mimeType: 'application/octet-stream',
      chunkSize: 64 * 1024, // 9 chunks
    });
    expect(enc.totalChunks).toBe(9);

    const dec = await decryptFileStaged({
      ciphertext: enc.ciphertext,
      dekBytes: enc.dekBytes,
      expectedCiphertextCommitment: enc.ciphertextCommitment,
      encryptedMetadata: enc.encryptedMetadata,
    });
    expect(dec.plaintext.byteLength).toBe(size);
    expect(dec.plaintext).toEqual(plain);
  });

  it('guarantees fresh DEK and unique nonceSalt across identical plaintexts', async () => {
    const plain = new TextEncoder().encode('Identical payload');
    const a = await encryptFileChunked({
      bytes: plain,
      originalName: 'a.txt',
      mimeType: 'text/plain',
    });
    const b = await encryptFileChunked({
      bytes: plain,
      originalName: 'a.txt',
      mimeType: 'text/plain',
    });

    expect(bytesToHex(a.dekBytes)).not.toBe(bytesToHex(b.dekBytes));
    expect(a.ciphertextCommitment).not.toBe(b.ciphertextCommitment);
    const hdrA = parseHeader(a.ciphertext);
    const hdrB = parseHeader(b.ciphertext);
    expect(bytesToHex(hdrA.nonceSalt)).not.toBe(bytesToHex(hdrB.nonceSalt));
    expect(bytesToHex(hdrA.fileId)).not.toBe(bytesToHex(hdrB.fileId));
  });

  it('rejects wrong DEK without emitting partial plaintext', async () => {
    const enc = await encryptFileChunked({
      bytes: new TextEncoder().encode('Top secret payload'),
      originalName: 'secret.txt',
      mimeType: 'text/plain',
    });

    await expect(
      decryptFileStaged({
        ciphertext: enc.ciphertext,
        dekBytes: randomBytes(32),
        expectedCiphertextCommitment: enc.ciphertextCommitment,
      }),
    ).rejects.toMatchObject({ code: 'AUTH_FAILED' });
  });

  it('rejects modified header bytes and modified ciphertext bytes', async () => {
    const enc = await encryptFileChunked({
      bytes: new TextEncoder().encode('Integrity test content'),
      originalName: 'integrity.txt',
      mimeType: 'text/plain',
    });

    // Tamper header (plaintextSize byte) while skipping commitment check to test GCM AAD binding
    const modHeader = new Uint8Array(enc.ciphertext);
    modHeader[49] ^= 0x01;
    await expect(
      decryptFileStaged({
        ciphertext: modHeader,
        dekBytes: enc.dekBytes,
      }),
    ).rejects.toMatchObject({ code: 'AUTH_FAILED' });

    // Commitment mismatch check
    const modBody = new Uint8Array(enc.ciphertext);
    modBody[modBody.byteLength - 5] ^= 0xff;
    await expect(
      decryptFileStaged({
        ciphertext: modBody,
        dekBytes: enc.dekBytes,
        expectedCiphertextCommitment: enc.ciphertextCommitment,
      }),
    ).rejects.toMatchObject({ code: 'COMMITMENT_MISMATCH' });
  });

  it('rejects chunk reordering and truncation and trailing data', async () => {
    const payload = new Uint8Array(300).fill(7);
    const enc = await encryptFileChunked({
      bytes: payload,
      originalName: 'chunks.bin',
      mimeType: 'application/octet-stream',
      chunkSize: 100, // 3 chunks
    });

    // Parse chunk frame offsets after 64-byte header
    const c0Start = LCFR_HEADER_BYTES;
    const c0Len = new DataView(enc.ciphertext.buffer, c0Start, 4).getUint32(0, false);
    const c0Total = 4 + c0Len;
    const c1Start = c0Start + c0Total;
    const c1Len = new DataView(enc.ciphertext.buffer, c1Start, 4).getUint32(0, false);
    const c1Total = 4 + c1Len;
    const c2Start = c1Start + c1Total;

    // Swap chunk 0 and chunk 1
    const swapped = new Uint8Array(enc.ciphertext.byteLength);
    swapped.set(enc.ciphertext.subarray(0, LCFR_HEADER_BYTES), 0);
    swapped.set(enc.ciphertext.subarray(c1Start, c1Start + c1Total), LCFR_HEADER_BYTES);
    swapped.set(enc.ciphertext.subarray(c0Start, c0Start + c0Total), LCFR_HEADER_BYTES + c1Total);
    swapped.set(enc.ciphertext.subarray(c2Start), LCFR_HEADER_BYTES + c1Total + c0Total);

    await expect(
      decryptFileStaged({
        ciphertext: swapped,
        dekBytes: enc.dekBytes,
      }),
    ).rejects.toMatchObject({ code: 'AUTH_FAILED' });

    // Truncate final chunk
    const truncated = enc.ciphertext.subarray(0, c2Start);
    await expect(
      decryptFileStaged({
        ciphertext: truncated,
        dekBytes: enc.dekBytes,
      }),
    ).rejects.toMatchObject({ code: 'TRUNCATED_STREAM' });

    // Trailing unauthenticated bytes
    const trailing = new Uint8Array(enc.ciphertext.byteLength + 10);
    trailing.set(enc.ciphertext, 0);
    await expect(
      decryptFileStaged({
        ciphertext: trailing,
        dekBytes: enc.dekBytes,
      }),
    ).rejects.toMatchObject({ code: 'TRAILING_DATA' });
  });

  it('aborts cleanly on interrupted encryption operation', async () => {
    const controller = new AbortController();
    controller.abort();
    await expect(
      encryptFileChunked({
        bytes: new Uint8Array(1024),
        originalName: 'aborted.bin',
        mimeType: 'application/octet-stream',
        signal: controller.signal,
      }),
    ).rejects.toMatchObject({ code: 'ABORTED' });
  });

  it('enforces recipient-key fingerprint binding and blocks key substitution', async () => {
    const recipient = await generateUserKeyBundle({
      userId: 'usr_rec',
      displayName: 'Recipient',
      handle: 'rec@demo',
      roleLabel: 'Recipient',
    });
    const attacker = await generateUserKeyBundle({
      userId: 'usr_att',
      displayName: 'Attacker',
      handle: 'att@demo',
      roleLabel: 'Attacker',
    });

    const dek = randomBytes(32);
    const fileRef = generateRandomFileRef();

    // Legitimate wrap succeeds
    const env = await wrapDekForRecipient({
      dekBytes: dek,
      fileRef,
      versionId: 'ver_01',
      recipientId: recipient.userId,
      recipientEncPublicJwk: recipient.encPublicJwk,
      expectedRecipientFingerprint: recipient.encFingerprint,
    });

    const unwrapped = await unwrapDekFromEnvelope({
      recipientEncPrivateJwk: recipient.encPrivateJwk,
      fileRef,
      versionId: 'ver_01',
      recipientId: recipient.userId,
      ...env,
    });
    expect(unwrapped).toEqual(dek);

    // Substituted public key triggers RECIPIENT_KEY_MISMATCH
    await expect(
      wrapDekForRecipient({
        dekBytes: dek,
        fileRef,
        versionId: 'ver_01',
        recipientId: recipient.userId,
        recipientEncPublicJwk: attacker.encPublicJwk,
        expectedRecipientFingerprint: recipient.encFingerprint,
      }),
    ).rejects.toBeInstanceOf(CipherError);
  });

  it('creates and restores PBKDF2 + AES-256-GCM key backups and rejects wrong passphrase', async () => {
    const user = await generateUserKeyBundle({
      userId: 'usr_bak',
      displayName: 'Backup Tester',
      handle: 'bak@demo',
      roleLabel: 'Owner',
    });

    const backup = await createEncryptedKeyBackup(user, 'Correct-Passphrase-99');
    expect(backup.kdf.algorithm).toBe('PBKDF2');
    expect(backup.kdf.iterations).toBeGreaterThanOrEqual(310_000);

    const restored = await restoreEncryptedKeyBackup(backup, 'Correct-Passphrase-99');
    expect(restored.encFingerprint).toBe(user.encFingerprint);
    expect(restored.registryPrivateJwk).toEqual(user.registryPrivateJwk);

    await expect(
      restoreEncryptedKeyBackup(backup, 'Wrong-Passphrase-00'),
    ).rejects.toMatchObject({ code: 'BACKUP_AUTH_FAILED' });
  });

  it('sanitizes dangerous download filenames', () => {
    expect(sanitizeDownloadFilename('../../etc/passwd')).toBe('passwd');
    expect(sanitizeDownloadFilename('..hidden\\..\\evil?.txt')).toBe('evil.txt');
    expect(sanitizeDownloadFilename('')).toBe('decrypted-file.bin');
  });
});
