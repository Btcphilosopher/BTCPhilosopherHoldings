export type StorageAdapterType = 'local' | 's3' | 'cas';

export type RegistryLifecycleStatus =
  | 'pending'
  | 'finalised'
  | 'revoked'
  | 'superseded'
  | 'reorganised'
  | 'failed';

export type VerificationSafetyStatus = 'unscanned_client_encrypted';

export interface UserPublicProfile {
  userId: string;
  displayName: string;
  handle: string;
  roleLabel: string;
  authPublicJwk: JsonWebKey;
  registryPublicJwk: JsonWebKey;
  encPublicJwk: JsonWebKey;
  authFingerprint: string;
  registryFingerprint: string;
  encFingerprint: string;
  createdAt: string;
}

export interface LocalUserKeyBundle {
  version: 'LC-KEYS-v1';
  userId: string;
  displayName: string;
  handle: string;
  roleLabel: string;
  authPublicJwk: JsonWebKey;
  authPrivateJwk: JsonWebKey;
  registryPublicJwk: JsonWebKey;
  registryPrivateJwk: JsonWebKey;
  encPublicJwk: JsonWebKey;
  encPrivateJwk: JsonWebKey;
  authFingerprint: string;
  registryFingerprint: string;
  encFingerprint: string;
  trustedDirectory: Record<
    string,
    {
      userId: string;
      displayName: string;
      encFingerprint: string;
      registryFingerprint: string;
      verifiedAt: string;
      verificationMethod: 'confirmed' | 'tofu';
    }
  >;
}

export interface EncryptedKeyBackup {
  format: 'LCFR-KEY-BACKUP-v1';
  userId: string;
  displayName: string;
  handle: string;
  kdf: {
    algorithm: 'PBKDF2';
    hash: 'SHA-256';
    iterations: number;
    saltHex: string;
  };
  cipher: {
    algorithm: 'AES-256-GCM';
    ivHex: string;
    aadText: string;
  };
  ciphertextHex: string;
  createdAt: string;
}

export interface EncryptedMetadataEnvelope {
  format: 'LCFR-META-v1';
  fileIdHex: string;
  ivHex: string;
  ciphertextHex: string;
}

export interface PlaintextFileMetadata {
  originalName: string;
  mimeType: string;
  plaintextSize: number;
  localPlaintextSha256: string;
  createdAt: string;
}

export interface KeyEnvelopeRecord {
  envelopeId: string;
  fileRef: string;
  versionId: string;
  recipientId: string;
  grantedByUserId: string;
  keyAlgorithm: 'ECDH-P256-HKDF-SHA256-AES256GCM';
  ephemeralPublicJwk: JsonWebKey;
  saltHex: string;
  ivHex: string;
  wrappedDekHex: string;
  recipientEncFingerprint: string;
  createdAt: string;
  expiresAt: string | null;
  revokedAt: string | null;
  revokedByUserId: string | null;
  retrievalCount: number;
}

export interface ShareInvitationRecord {
  inviteId: string;
  fileRef: string;
  versionId: string;
  recipientId: string;
  createdByUserId: string;
  envelopeId: string;
  createdAt: string;
  expiresAt: string;
  revokedAt: string | null;
  acceptedAt: string | null;
  note: string;
}

export interface FileVersionRecord {
  versionId: string;
  fileRef: string;
  versionNumber: number;
  ownerUserId: string;
  ownerRegistryFingerprint: string;
  ciphertextCommitment: string;
  manifestCommitment: string;
  encryptionFormatVersion: string;
  cipherSuite: string;
  chunkSize: number;
  totalChunks: number;
  ciphertextByteLength: number;
  encryptedMetadata: EncryptedMetadataEnvelope;
  storageAdapter: StorageAdapterType;
  storageLocation: string;
  contentAddressCid: string | null;
  registryStatus: RegistryLifecycleStatus;
  registryTxHash: string | null;
  registryBlockNumber: number | null;
  malwareScanStatus: VerificationSafetyStatus;
  createdAt: string;
  deletedAt: string | null;
}

export interface EncryptedFileRecord {
  fileRef: string;
  ownerUserId: string;
  ownerRegistryFingerprint: string;
  latestVersionNumber: number;
  latestVersionId: string;
  lifecycleStatus: 'active' | 'revoked' | 'deleted';
  createdAt: string;
  updatedAt: string;
  versions: FileVersionRecord[];
  envelopes: KeyEnvelopeRecord[];
  invitations: ShareInvitationRecord[];
}

export interface RegistryTransactionRecord {
  txHash: string;
  blockNumber: number | null;
  blockHash: string | null;
  eventType: 'REGISTER_FILE' | 'PUBLISH_VERSION' | 'UPDATE_STATUS';
  fileRef: string;
  versionNumber: number;
  ciphertextCommitment: string;
  manifestCommitment: string;
  formatVersion: string;
  ownerRegistryFingerprint: string;
  lifecycleStatus: RegistryLifecycleStatus;
  signatureHex: string;
  status: 'pending' | 'finalised' | 'reorganised' | 'failed';
  confirmations: number;
  submittedAt: string;
  finalisedAt: string | null;
}

export interface RegistryBlockRecord {
  blockNumber: number;
  blockHash: string;
  parentHash: string;
  timestamp: string;
  txHashes: string[];
  stateRoot: string;
  status: 'finalised' | 'reorganised';
}

export type AuditEventType =
  | 'user_registered'
  | 'session_authenticated'
  | 'encryption_completed'
  | 'upload_completed'
  | 'registry_submitted'
  | 'registry_finalised'
  | 'registry_reorg_detected'
  | 'registry_reorg_recovered'
  | 'share_invited'
  | 'envelope_retrieved'
  | 'download_requested'
  | 'access_denied'
  | 'access_revoked'
  | 'version_replaced'
  | 'object_deleted'
  | 'orphans_purged'
  | 'tamper_simulated'
  | 'backup_restored';

export interface AuditEventRecord {
  eventId: string;
  eventType: AuditEventType;
  actorUserId: string;
  fileRef: string | null;
  versionId: string | null;
  summary: string;
  outcome: 'success' | 'rejected' | 'warning';
  txHash: string | null;
  timestamp: string;
}

export interface EncryptionProgress {
  chunkIndex: number;
  totalChunks: number;
  bytesProcessed: number;
  totalBytes: number;
  percent: number;
}

export interface VerificationReport {
  commitmentMatches: boolean;
  decryptionSucceeded: boolean;
  chunkOrderVerified: boolean;
  truncationCheckPassed: boolean;
  contentSafetyStatus: VerificationSafetyStatus;
  contentSafetyNote: string;
  expectedCommitment: string;
  actualCommitment: string;
  verifiedChunks: number;
  verifiedBytes: number;
}
