import {
  EncryptedKeyBackup,
  EncryptedMetadataEnvelope,
  EncryptionProgress,
  LocalUserKeyBundle,
  PlaintextFileMetadata,
  VerificationReport,
} from './cipher-types';

export const LCFR_MAGIC = new Uint8Array([0x4c, 0x43, 0x46, 0x52]); // "LCFR"
export const LCFR_FORMAT_VERSION = 0x01;
export const LCFR_FORMAT_LABEL = 'LCFR-v1';
export const LCFR_CIPHER_SUITE_ID = 0x01;
export const LCFR_CIPHER_SUITE_LABEL = 'AES-256-GCM-CHUNKED-HKDF-SHA256';
export const LCFR_HEADER_BYTES = 64;
export const LCFR_DEFAULT_CHUNK_SIZE = 262_144; // 256 KiB bounded chunk window
export const LCFR_PBKDF2_ITERATIONS = 310_000;

const textEncoder = new TextEncoder();
const textDecoder = new TextDecoder();

export class CipherError extends Error {
  constructor(
    public readonly code:
      | 'INVALID_HEADER'
      | 'COMMITMENT_MISMATCH'
      | 'AUTH_FAILED'
      | 'TRUNCATED_STREAM'
      | 'TRAILING_DATA'
      | 'RECIPIENT_KEY_MISMATCH'
      | 'BACKUP_AUTH_FAILED'
      | 'ABORTED'
      | 'INVALID_INPUT',
    message: string,
  ) {
    super(message);
    this.name = 'CipherError';
  }
}

function getCrypto(): Crypto {
  if (!globalThis.crypto || !globalThis.crypto.subtle) {
    throw new Error('Web Crypto API (crypto.subtle) is unavailable in this runtime.');
  }
  return globalThis.crypto;
}

export function bytesToHex(bytes: Uint8Array): string {
  let out = '';
  for (const byte of bytes) {
    out += byte.toString(16).padStart(2, '0');
  }
  return out;
}

export function hexToBytes(hex: string): Uint8Array<ArrayBuffer> {
  const clean = hex.trim().toLowerCase();
  if (clean.length % 2 !== 0 || !/^[0-9a-f]*$/.test(clean)) {
    throw new CipherError('INVALID_INPUT', 'Malformed hexadecimal string.');
  }
  const buffer = new ArrayBuffer(clean.length / 2);
  const out = new Uint8Array(buffer);
  for (let i = 0; i < out.length; i++) {
    out[i] = parseInt(clean.slice(i * 2, i * 2 + 2), 16);
  }
  return out;
}

export function toArrayBuffer(bytes: Uint8Array): ArrayBuffer {
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  return copy.buffer;
}

export function concatBytes(parts: Uint8Array[]): Uint8Array<ArrayBuffer> {
  let total = 0;
  for (const p of parts) {
    total += p.byteLength;
  }
  const buffer = new ArrayBuffer(total);
  const out = new Uint8Array(buffer);
  let offset = 0;
  for (const p of parts) {
    out.set(p, offset);
    offset += p.byteLength;
  }
  return out;
}

export function formatFingerprint(hex64: string): string {
  const upper = hex64.toUpperCase();
  const groups: string[] = [];
  for (let i = 0; i < upper.length; i += 4) {
    groups.push(upper.slice(i, i + 4));
  }
  return groups.join(':');
}

export async function sha256Hex(data: Uint8Array): Promise<string> {
  const digest = await getCrypto().subtle.digest('SHA-256', toArrayBuffer(data));
  return bytesToHex(new Uint8Array(digest));
}

export async function computePublicKeyFingerprint(spkiPublicJwk: JsonWebKey): Promise<string> {
  const crypto = getCrypto();
  const keyAlgo =
    spkiPublicJwk.kty === 'EC' && spkiPublicJwk.key_ops?.includes('verify')
      ? { name: 'ECDSA', namedCurve: 'P-256' }
      : spkiPublicJwk.ext !== undefined && !spkiPublicJwk.key_ops?.includes('verify')
        ? { name: 'ECDH', namedCurve: 'P-256' }
        : { name: 'ECDSA', namedCurve: 'P-256' };

  // Import as SPKI-exportable public key to normalize canonical SPKI DER bytes
  let key: CryptoKey;
  try {
    key = await crypto.subtle.importKey('jwk', spkiPublicJwk, keyAlgo, true, keyAlgo.name === 'ECDSA' ? ['verify'] : []);
  } catch {
    key = await crypto.subtle.importKey(
      'jwk',
      spkiPublicJwk,
      { name: 'ECDH', namedCurve: 'P-256' },
      true,
      [],
    );
  }
  const spki = await crypto.subtle.exportKey('spki', key);
  const hash = await sha256Hex(new Uint8Array(spki));
  return formatFingerprint(hash);
}

export function randomBytes(length: number): Uint8Array<ArrayBuffer> {
  const buffer = new ArrayBuffer(length);
  const out = new Uint8Array(buffer);
  getCrypto().getRandomValues(out);
  return out;
}

export function generateRandomFileRef(): string {
  return `lcfr_${bytesToHex(randomBytes(16))}`;
}

export function sanitizeDownloadFilename(name: string): string {
  const base = name
    .replaceAll('\\', '/')
    .split('/')
    .pop() ?? 'decrypted-file.bin';
  let cleaned = '';
  for (let i = 0; i < base.length; i++) {
    const code = base.charCodeAt(i);
    if (code >= 32 && code !== 127 && !'<>:"/\\|?*'.includes(base[i])) {
      cleaned += base[i];
    }
  }
  cleaned = cleaned.replace(/^\.+/, '').trim();
  if (!cleaned) {
    return 'decrypted-file.bin';
  }
  return cleaned.slice(0, 180);
}

// ---------- HKDF & Nonce Construction ----------

async function deriveFileSubkeys(
  dekBytes: Uint8Array,
  nonceSalt: Uint8Array,
  fileId: Uint8Array,
): Promise<{
  chunkKey: CryptoKey;
  noncePrefix: Uint8Array;
  metaKey: CryptoKey;
}> {
  const crypto = getCrypto();
  const baseKey = await crypto.subtle.importKey('raw', toArrayBuffer(dekBytes), 'HKDF', false, [
    'deriveKey',
    'deriveBits',
  ]);

  const encInfo = concatBytes([textEncoder.encode('LCFR-v1-ENC-KEY'), fileId]);
  const chunkKey = await crypto.subtle.deriveKey(
    { name: 'HKDF', hash: 'SHA-256', salt: toArrayBuffer(nonceSalt), info: toArrayBuffer(encInfo) },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt'],
  );

  const prefixInfo = concatBytes([textEncoder.encode('LCFR-v1-NONCE-PREFIX'), fileId]);
  const prefixBits = await crypto.subtle.deriveBits(
    { name: 'HKDF', hash: 'SHA-256', salt: toArrayBuffer(nonceSalt), info: toArrayBuffer(prefixInfo) },
    baseKey,
    32,
  );

  const metaInfo = concatBytes([textEncoder.encode('LCFR-v1-META-KEY'), fileId]);
  const metaKey = await crypto.subtle.deriveKey(
    { name: 'HKDF', hash: 'SHA-256', salt: toArrayBuffer(nonceSalt), info: toArrayBuffer(metaInfo) },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt'],
  );

  return {
    chunkKey,
    noncePrefix: new Uint8Array(prefixBits),
    metaKey,
  };
}

function buildChunkNonce(noncePrefix: Uint8Array, chunkIndex: number): Uint8Array<ArrayBuffer> {
  const buffer = new ArrayBuffer(12);
  const view = new DataView(buffer);
  const out = new Uint8Array(buffer);
  out.set(noncePrefix.subarray(0, 4), 0);
  view.setBigUint64(4, BigInt(chunkIndex), false);
  return out;
}

function buildChunkAad(params: {
  fileId: Uint8Array;
  chunkSize: number;
  plaintextSize: number;
  totalChunks: number;
  chunkIndex: number;
  isFinal: boolean;
}): Uint8Array<ArrayBuffer> {
  const buffer = new ArrayBuffer(43);
  const view = new DataView(buffer);
  const out = new Uint8Array(buffer);
  out.set(LCFR_MAGIC, 0);
  out[4] = LCFR_FORMAT_VERSION;
  out[5] = LCFR_CIPHER_SUITE_ID;
  out.set(params.fileId, 6);
  view.setUint32(22, params.chunkSize, false);
  view.setBigUint64(26, BigInt(params.plaintextSize), false);
  view.setUint32(34, params.totalChunks, false);
  view.setUint32(38, params.chunkIndex, false);
  out[42] = params.isFinal ? 1 : 0;
  return out;
}

function encodeHeader(params: {
  fileId: Uint8Array;
  nonceSalt: Uint8Array;
  chunkSize: number;
  plaintextSize: number;
  totalChunks: number;
}): Uint8Array<ArrayBuffer> {
  const buffer = new ArrayBuffer(LCFR_HEADER_BYTES);
  const view = new DataView(buffer);
  const out = new Uint8Array(buffer);
  out.set(LCFR_MAGIC, 0);
  out[4] = LCFR_FORMAT_VERSION;
  out[5] = LCFR_CIPHER_SUITE_ID;
  out.set(params.fileId, 6);
  out.set(params.nonceSalt, 22);
  view.setUint32(38, params.chunkSize, false);
  view.setBigUint64(42, BigInt(params.plaintextSize), false);
  view.setUint32(50, params.totalChunks, false);
  // Bytes 54..63 reserved zero
  return out;
}

export interface ParsedHeader {
  version: number;
  cipherSuite: number;
  fileId: Uint8Array;
  nonceSalt: Uint8Array;
  chunkSize: number;
  plaintextSize: number;
  totalChunks: number;
}

export function parseHeader(bytes: Uint8Array): ParsedHeader {
  if (bytes.byteLength < LCFR_HEADER_BYTES) {
    throw new CipherError('INVALID_HEADER', 'Ciphertext is smaller than the 64-byte LCFR header.');
  }
  for (let i = 0; i < 4; i++) {
    if (bytes[i] !== LCFR_MAGIC[i]) {
      throw new CipherError('INVALID_HEADER', 'Invalid LCFR magic header.');
    }
  }
  const version = bytes[4];
  if (version !== LCFR_FORMAT_VERSION) {
    throw new CipherError('INVALID_HEADER', `Unsupported LCFR version: ${version}`);
  }
  const cipherSuite = bytes[5];
  if (cipherSuite !== LCFR_CIPHER_SUITE_ID) {
    throw new CipherError('INVALID_HEADER', `Unsupported cipher suite: ${cipherSuite}`);
  }
  const view = new DataView(bytes.buffer, bytes.byteOffset, LCFR_HEADER_BYTES);
  const chunkSize = view.getUint32(38, false);
  const plaintextSize = Number(view.getBigUint64(42, false));
  const totalChunks = view.getUint32(50, false);

  if (chunkSize === 0 || totalChunks === 0) {
    throw new CipherError('INVALID_HEADER', 'Header chunkSize and totalChunks must be positive.');
  }

  return {
    version,
    cipherSuite,
    fileId: bytes.slice(6, 22),
    nonceSalt: bytes.slice(22, 38),
    chunkSize,
    plaintextSize,
    totalChunks,
  };
}

// ---------- File Encryption & Decryption ----------

export interface EncryptFileInput {
  bytes?: Uint8Array;
  blob?: Blob;
  originalName: string;
  mimeType: string;
  chunkSize?: number;
  signal?: AbortSignal;
  onProgress?: (progress: EncryptionProgress) => void;
}

export interface EncryptFileResult {
  fileIdHex: string;
  dekBytes: Uint8Array;
  ciphertext: Uint8Array;
  ciphertextCommitment: string;
  encryptedMetadata: EncryptedMetadataEnvelope;
  manifestCommitment: string;
  totalChunks: number;
  chunkSize: number;
  plaintextSize: number;
}

export async function encryptFileChunked(input: EncryptFileInput): Promise<EncryptFileResult> {
  const crypto = getCrypto();
  const chunkSize = input.chunkSize ?? LCFR_DEFAULT_CHUNK_SIZE;
  if (chunkSize < 64 || chunkSize > 16 * 1024 * 1024) {
    throw new CipherError('INVALID_INPUT', 'Chunk size must be between 64 bytes and 16 MiB.');
  }

  const plaintextSize = input.blob ? input.blob.size : (input.bytes?.byteLength ?? 0);
  const totalChunks = plaintextSize === 0 ? 1 : Math.ceil(plaintextSize / chunkSize);

  const dekBytes = randomBytes(32);
  const fileId = randomBytes(16);
  const nonceSalt = randomBytes(16);
  const { chunkKey, noncePrefix, metaKey } = await deriveFileSubkeys(dekBytes, nonceSalt, fileId);

  const header = encodeHeader({
    fileId,
    nonceSalt,
    chunkSize,
    plaintextSize,
    totalChunks,
  });

  const framedParts: Uint8Array[] = [header];
  const plainHashBufferParts: Uint8Array[] = [];

  for (let i = 0; i < totalChunks; i++) {
    if (input.signal?.aborted) {
      throw new CipherError('ABORTED', 'Encryption operation aborted by user or system.');
    }

    const start = i * chunkSize;
    const end = Math.min(start + chunkSize, plaintextSize);
    let plainChunk: Uint8Array;
    if (plaintextSize === 0) {
      plainChunk = new Uint8Array(0);
    } else if (input.blob) {
      const sliceBuf = await input.blob.slice(start, end).arrayBuffer();
      plainChunk = new Uint8Array(sliceBuf);
    } else {
      plainChunk = input.bytes!.subarray(start, end);
    }
    plainHashBufferParts.push(plainChunk);

    const isFinal = i === totalChunks - 1;
    const nonce = buildChunkNonce(noncePrefix, i);
    const aad = buildChunkAad({
      fileId,
      chunkSize,
      plaintextSize,
      totalChunks,
      chunkIndex: i,
      isFinal,
    });

    const encryptedBuf = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv: nonce, additionalData: aad, tagLength: 128 },
      chunkKey,
      toArrayBuffer(plainChunk),
    );

    const encBytes = new Uint8Array(encryptedBuf);
    const lenBuf = new ArrayBuffer(4);
    new DataView(lenBuf).setUint32(0, encBytes.byteLength, false);
    framedParts.push(new Uint8Array(lenBuf));
    framedParts.push(encBytes);

    input.onProgress?.({
      chunkIndex: i + 1,
      totalChunks,
      bytesProcessed: end,
      totalBytes: plaintextSize,
      percent: totalChunks === 1 ? 100 : Math.round(((i + 1) / totalChunks) * 100),
    });
  }

  const ciphertext = concatBytes(framedParts);
  const ciphertextCommitment = await sha256Hex(ciphertext);

  const localPlaintextSha256 = await sha256Hex(concatBytes(plainHashBufferParts));
  const plainMeta: PlaintextFileMetadata = {
    originalName: sanitizeDownloadFilename(input.originalName),
    mimeType: input.mimeType || 'application/octet-stream',
    plaintextSize,
    localPlaintextSha256,
    createdAt: new Date().toISOString(),
  };

  const metaIv = randomBytes(12);
  const metaAad = concatBytes([textEncoder.encode('LCFR-META-v1'), fileId]);
  const encMetaBuf = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: metaIv, additionalData: metaAad, tagLength: 128 },
    metaKey,
    textEncoder.encode(JSON.stringify(plainMeta)),
  );

  const encryptedMetadata: EncryptedMetadataEnvelope = {
    format: 'LCFR-META-v1',
    fileIdHex: bytesToHex(fileId),
    ivHex: bytesToHex(metaIv),
    ciphertextHex: bytesToHex(new Uint8Array(encMetaBuf)),
  };

  const manifestCommitment = await sha256Hex(textEncoder.encode(JSON.stringify(encryptedMetadata)));

  return {
    fileIdHex: bytesToHex(fileId),
    dekBytes,
    ciphertext,
    ciphertextCommitment,
    encryptedMetadata,
    manifestCommitment,
    totalChunks,
    chunkSize,
    plaintextSize,
  };
}

export interface DecryptFileInput {
  ciphertext: Uint8Array;
  dekBytes: Uint8Array;
  expectedCiphertextCommitment?: string;
  encryptedMetadata?: EncryptedMetadataEnvelope;
  signal?: AbortSignal;
  onProgress?: (progress: EncryptionProgress) => void;
}

export interface DecryptFileResult {
  plaintext: Uint8Array;
  metadata: PlaintextFileMetadata | null;
  report: VerificationReport;
}

export async function decryptFileStaged(input: DecryptFileInput): Promise<DecryptFileResult> {
  const crypto = getCrypto();
  if (input.signal?.aborted) {
    throw new CipherError('ABORTED', 'Decryption operation aborted.');
  }

  const actualCommitment = await sha256Hex(input.ciphertext);
  if (
    input.expectedCiphertextCommitment &&
    actualCommitment.toLowerCase() !== input.expectedCiphertextCommitment.toLowerCase()
  ) {
    throw new CipherError(
      'COMMITMENT_MISMATCH',
      `Ciphertext commitment mismatch. Expected ${input.expectedCiphertextCommitment.slice(0, 16)}…, observed ${actualCommitment.slice(0, 16)}….`,
    );
  }

  const header = parseHeader(input.ciphertext);
  const { chunkKey, noncePrefix, metaKey } = await deriveFileSubkeys(
    input.dekBytes,
    header.nonceSalt,
    header.fileId,
  );

  const stagedChunks: Uint8Array[] = [];
  let offset = LCFR_HEADER_BYTES;
  let totalDecryptedBytes = 0;

  for (let i = 0; i < header.totalChunks; i++) {
    if (input.signal?.aborted) {
      throw new CipherError('ABORTED', 'Decryption operation aborted during staging.');
    }
    if (offset + 4 > input.ciphertext.byteLength) {
      throw new CipherError(
        'TRUNCATED_STREAM',
        `Ciphertext truncated before chunk ${i + 1} of ${header.totalChunks}.`,
      );
    }
    const lenView = new DataView(
      input.ciphertext.buffer,
      input.ciphertext.byteOffset + offset,
      4,
    );
    const encChunkLen = lenView.getUint32(0, false);
    offset += 4;

    if (encChunkLen < 16 || offset + encChunkLen > input.ciphertext.byteLength) {
      throw new CipherError(
        'TRUNCATED_STREAM',
        `Chunk ${i + 1} length (${encChunkLen} bytes) exceeds ciphertext bounds.`,
      );
    }

    const encChunk = input.ciphertext.subarray(offset, offset + encChunkLen);
    offset += encChunkLen;

    const isFinal = i === header.totalChunks - 1;
    const nonce = buildChunkNonce(noncePrefix, i);
    const aad = buildChunkAad({
      fileId: header.fileId,
      chunkSize: header.chunkSize,
      plaintextSize: header.plaintextSize,
      totalChunks: header.totalChunks,
      chunkIndex: i,
      isFinal,
    });

    let plainBuf: ArrayBuffer;
    try {
      plainBuf = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: nonce, additionalData: aad, tagLength: 128 },
        chunkKey,
        toArrayBuffer(encChunk),
      );
    } catch {
      throw new CipherError(
        'AUTH_FAILED',
        `Authenticated decryption failed at chunk ${i + 1}. Possible wrong key, modified ciphertext, or chunk reordering.`,
      );
    }

    const plainBytes = new Uint8Array(plainBuf);
    stagedChunks.push(plainBytes);
    totalDecryptedBytes += plainBytes.byteLength;

    input.onProgress?.({
      chunkIndex: i + 1,
      totalChunks: header.totalChunks,
      bytesProcessed: totalDecryptedBytes,
      totalBytes: header.plaintextSize,
      percent: Math.round(((i + 1) / header.totalChunks) * 100),
    });
  }

  if (offset !== input.ciphertext.byteLength) {
    throw new CipherError(
      'TRAILING_DATA',
      `Unexpected ${input.ciphertext.byteLength - offset} unauthenticated trailing bytes after final chunk.`,
    );
  }

  if (totalDecryptedBytes !== header.plaintextSize) {
    throw new CipherError(
      'TRUNCATED_STREAM',
      `Decrypted size (${totalDecryptedBytes}) does not match authenticated header size (${header.plaintextSize}).`,
    );
  }

  let metadata: PlaintextFileMetadata | null = null;
  if (input.encryptedMetadata) {
    try {
      const metaIv = hexToBytes(input.encryptedMetadata.ivHex);
      const metaCt = hexToBytes(input.encryptedMetadata.ciphertextHex);
      const metaAad = concatBytes([textEncoder.encode('LCFR-META-v1'), header.fileId]);
      const plainMetaBuf = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: metaIv, additionalData: metaAad, tagLength: 128 },
        metaKey,
        metaCt,
      );
      metadata = JSON.parse(textDecoder.decode(plainMetaBuf)) as PlaintextFileMetadata;
      metadata.originalName = sanitizeDownloadFilename(metadata.originalName);
    } catch {
      throw new CipherError(
        'AUTH_FAILED',
        'Encrypted metadata manifest failed authentication.',
      );
    }
  }

  const plaintext = concatBytes(stagedChunks);
  return {
    plaintext,
    metadata,
    report: {
      commitmentMatches: true,
      decryptionSucceeded: true,
      chunkOrderVerified: true,
      truncationCheckPassed: true,
      contentSafetyStatus: 'unscanned_client_encrypted',
      contentSafetyNote:
        'Client-side encryption prevents server-side malware inspection. Verify source trust before executing or opening decrypted content.',
      expectedCommitment: input.expectedCiphertextCommitment ?? actualCommitment,
      actualCommitment,
      verifiedChunks: header.totalChunks,
      verifiedBytes: totalDecryptedBytes,
    },
  };
}

// ---------- 3-Role User Key Generation & Signatures ----------

export async function generateUserKeyBundle(params: {
  userId: string;
  displayName: string;
  handle: string;
  roleLabel: string;
}): Promise<LocalUserKeyBundle> {
  const crypto = getCrypto();

  const authPair = await crypto.subtle.generateKey(
    { name: 'ECDSA', namedCurve: 'P-256' },
    true,
    ['sign', 'verify'],
  );
  const registryPair = await crypto.subtle.generateKey(
    { name: 'ECDSA', namedCurve: 'P-256' },
    true,
    ['sign', 'verify'],
  );
  const encPair = await crypto.subtle.generateKey(
    { name: 'ECDH', namedCurve: 'P-256' },
    true,
    ['deriveBits'],
  );

  const [
    authPublicJwk,
    authPrivateJwk,
    registryPublicJwk,
    registryPrivateJwk,
    encPublicJwk,
    encPrivateJwk,
    authSpki,
    registrySpki,
    encSpki,
  ] = await Promise.all([
    crypto.subtle.exportKey('jwk', authPair.publicKey),
    crypto.subtle.exportKey('jwk', authPair.privateKey),
    crypto.subtle.exportKey('jwk', registryPair.publicKey),
    crypto.subtle.exportKey('jwk', registryPair.privateKey),
    crypto.subtle.exportKey('jwk', encPair.publicKey),
    crypto.subtle.exportKey('jwk', encPair.privateKey),
    crypto.subtle.exportKey('spki', authPair.publicKey),
    crypto.subtle.exportKey('spki', registryPair.publicKey),
    crypto.subtle.exportKey('spki', encPair.publicKey),
  ]);

  const [authHash, registryHash, encHash] = await Promise.all([
    sha256Hex(new Uint8Array(authSpki)),
    sha256Hex(new Uint8Array(registrySpki)),
    sha256Hex(new Uint8Array(encSpki)),
  ]);

  return {
    version: 'LC-KEYS-v1',
    userId: params.userId,
    displayName: params.displayName,
    handle: params.handle,
    roleLabel: params.roleLabel,
    authPublicJwk,
    authPrivateJwk,
    registryPublicJwk,
    registryPrivateJwk,
    encPublicJwk,
    encPrivateJwk,
    authFingerprint: formatFingerprint(authHash),
    registryFingerprint: formatFingerprint(registryHash),
    encFingerprint: formatFingerprint(encHash),
    trustedDirectory: {},
  };
}

export async function signWithEcdsaP256(privateJwk: JsonWebKey, payload: string): Promise<string> {
  const crypto = getCrypto();
  const key = await crypto.subtle.importKey(
    'jwk',
    privateJwk,
    { name: 'ECDSA', namedCurve: 'P-256' },
    false,
    ['sign'],
  );
  const sig = await crypto.subtle.sign(
    { name: 'ECDSA', hash: 'SHA-256' },
    key,
    textEncoder.encode(payload),
  );
  return bytesToHex(new Uint8Array(sig));
}

export async function verifyWithEcdsaP256(
  publicJwk: JsonWebKey,
  payload: string,
  signatureHex: string,
): Promise<boolean> {
  try {
    const crypto = getCrypto();
    const key = await crypto.subtle.importKey(
      'jwk',
      publicJwk,
      { name: 'ECDSA', namedCurve: 'P-256' },
      false,
      ['verify'],
    );
    return await crypto.subtle.verify(
      { name: 'ECDSA', hash: 'SHA-256' },
      key,
      hexToBytes(signatureHex),
      textEncoder.encode(payload),
    );
  } catch {
    return false;
  }
}

export function canonicalRegistrySignPayload(params: {
  eventType: string;
  fileRef: string;
  versionNumber: number;
  ciphertextCommitment: string;
  manifestCommitment: string;
  formatVersion: string;
  lifecycleStatus: string;
  ownerRegistryFingerprint: string;
}): string {
  return JSON.stringify([
    params.eventType,
    params.fileRef,
    params.versionNumber,
    params.ciphertextCommitment,
    params.manifestCommitment,
    params.formatVersion,
    params.lifecycleStatus,
    params.ownerRegistryFingerprint,
  ]);
}

// ---------- Recipient Key Envelope (ECDH P-256 + HKDF-SHA256 + AES-256-GCM) ----------

export interface WrapDekInput {
  dekBytes: Uint8Array;
  fileRef: string;
  versionId: string;
  recipientId: string;
  recipientEncPublicJwk: JsonWebKey;
  expectedRecipientFingerprint: string;
}

export interface WrappedDekEnvelope {
  ephemeralPublicJwk: JsonWebKey;
  saltHex: string;
  ivHex: string;
  wrappedDekHex: string;
  recipientEncFingerprint: string;
}

export async function wrapDekForRecipient(input: WrapDekInput): Promise<WrappedDekEnvelope> {
  const crypto = getCrypto();

  const recipientPub = await crypto.subtle.importKey(
    'jwk',
    input.recipientEncPublicJwk,
    { name: 'ECDH', namedCurve: 'P-256' },
    true,
    [],
  );
  const actualSpki = await crypto.subtle.exportKey('spki', recipientPub);
  const actualFingerprint = formatFingerprint(await sha256Hex(new Uint8Array(actualSpki)));

  if (actualFingerprint !== input.expectedRecipientFingerprint) {
    throw new CipherError(
      'RECIPIENT_KEY_MISMATCH',
      `Recipient key binding failed! Expected fingerprint ${input.expectedRecipientFingerprint.slice(0, 19)}…, server presented ${actualFingerprint.slice(0, 19)}…. Possible key substitution attack.`,
    );
  }

  const ephemeral = await crypto.subtle.generateKey(
    { name: 'ECDH', namedCurve: 'P-256' },
    true,
    ['deriveBits'],
  );
  const ephemeralPublicJwk = await crypto.subtle.exportKey('jwk', ephemeral.publicKey);

  const sharedBits = await crypto.subtle.deriveBits(
    { name: 'ECDH', public: recipientPub },
    ephemeral.privateKey,
    256,
  );

  const salt = randomBytes(16);
  const iv = randomBytes(12);
  const aadText = `LCFR-KEY-ENV-v1|${input.fileRef}|${input.versionId}|${input.recipientId}|${actualFingerprint}`;

  const hkdfBase = await crypto.subtle.importKey('raw', sharedBits, 'HKDF', false, ['deriveKey']);
  const wrapKey = await crypto.subtle.deriveKey(
    {
      name: 'HKDF',
      hash: 'SHA-256',
      salt,
      info: textEncoder.encode(aadText),
    },
    hkdfBase,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt'],
  );

  const wrappedBuf = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: textEncoder.encode(aadText), tagLength: 128 },
    wrapKey,
    toArrayBuffer(input.dekBytes),
  );

  return {
    ephemeralPublicJwk,
    saltHex: bytesToHex(salt),
    ivHex: bytesToHex(iv),
    wrappedDekHex: bytesToHex(new Uint8Array(wrappedBuf)),
    recipientEncFingerprint: actualFingerprint,
  };
}

export async function unwrapDekFromEnvelope(params: {
  recipientEncPrivateJwk: JsonWebKey;
  recipientEncFingerprint: string;
  fileRef: string;
  versionId: string;
  recipientId: string;
  ephemeralPublicJwk: JsonWebKey;
  saltHex: string;
  ivHex: string;
  wrappedDekHex: string;
}): Promise<Uint8Array> {
  const crypto = getCrypto();

  const privKey = await crypto.subtle.importKey(
    'jwk',
    params.recipientEncPrivateJwk,
    { name: 'ECDH', namedCurve: 'P-256' },
    false,
    ['deriveBits'],
  );
  const ephPub = await crypto.subtle.importKey(
    'jwk',
    params.ephemeralPublicJwk,
    { name: 'ECDH', namedCurve: 'P-256' },
    false,
    [],
  );

  const sharedBits = await crypto.subtle.deriveBits(
    { name: 'ECDH', public: ephPub },
    privKey,
    256,
  );

  const aadText = `LCFR-KEY-ENV-v1|${params.fileRef}|${params.versionId}|${params.recipientId}|${params.recipientEncFingerprint}`;
  const hkdfBase = await crypto.subtle.importKey('raw', sharedBits, 'HKDF', false, ['deriveKey']);
  const wrapKey = await crypto.subtle.deriveKey(
    {
      name: 'HKDF',
      hash: 'SHA-256',
      salt: hexToBytes(params.saltHex),
      info: textEncoder.encode(aadText),
    },
    hkdfBase,
    { name: 'AES-GCM', length: 256 },
    false,
    ['decrypt'],
  );

  try {
    const dekBuf = await crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: hexToBytes(params.ivHex),
        additionalData: textEncoder.encode(aadText),
        tagLength: 128,
      },
      wrapKey,
      hexToBytes(params.wrappedDekHex),
    );
    return new Uint8Array(dekBuf);
  } catch {
    throw new CipherError(
      'AUTH_FAILED',
      'Failed to unwrap file decryption key from envelope. Wrong private key or tampered envelope.',
    );
  }
}

// ---------- Password-Protected Key Backup (PBKDF2-SHA256 + AES-256-GCM) ----------

export async function createEncryptedKeyBackup(
  bundle: LocalUserKeyBundle,
  passphrase: string,
): Promise<EncryptedKeyBackup> {
  if (passphrase.length < 8) {
    throw new CipherError('INVALID_INPUT', 'Backup passphrase must be at least 8 characters.');
  }
  const crypto = getCrypto();
  const salt = randomBytes(16);
  const iv = randomBytes(12);
  const aadText = `LCFR-KEY-BACKUP-v1|${bundle.userId}`;

  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    textEncoder.encode(passphrase),
    'PBKDF2',
    false,
    ['deriveKey'],
  );

  const backupKey = await crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      hash: 'SHA-256',
      salt,
      iterations: LCFR_PBKDF2_ITERATIONS,
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt'],
  );

  const encryptedBuf = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: textEncoder.encode(aadText), tagLength: 128 },
    backupKey,
    textEncoder.encode(JSON.stringify(bundle)),
  );

  return {
    format: 'LCFR-KEY-BACKUP-v1',
    userId: bundle.userId,
    displayName: bundle.displayName,
    handle: bundle.handle,
    kdf: {
      algorithm: 'PBKDF2',
      hash: 'SHA-256',
      iterations: LCFR_PBKDF2_ITERATIONS,
      saltHex: bytesToHex(salt),
    },
    cipher: {
      algorithm: 'AES-256-GCM',
      ivHex: bytesToHex(iv),
      aadText,
    },
    ciphertextHex: bytesToHex(new Uint8Array(encryptedBuf)),
    createdAt: new Date().toISOString(),
  };
}

export async function restoreEncryptedKeyBackup(
  backup: EncryptedKeyBackup,
  passphrase: string,
): Promise<LocalUserKeyBundle> {
  if (backup.format !== 'LCFR-KEY-BACKUP-v1') {
    throw new CipherError('INVALID_INPUT', 'Unsupported backup format.');
  }
  const crypto = getCrypto();
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    textEncoder.encode(passphrase),
    'PBKDF2',
    false,
    ['deriveKey'],
  );

  const backupKey = await crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      hash: backup.kdf.hash,
      salt: hexToBytes(backup.kdf.saltHex),
      iterations: backup.kdf.iterations,
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['decrypt'],
  );

  try {
    const plainBuf = await crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: hexToBytes(backup.cipher.ivHex),
        additionalData: textEncoder.encode(backup.cipher.aadText),
        tagLength: 128,
      },
      backupKey,
      hexToBytes(backup.ciphertextHex),
    );
    return JSON.parse(textDecoder.decode(plainBuf)) as LocalUserKeyBundle;
  } catch {
    throw new CipherError(
      'BACKUP_AUTH_FAILED',
      'Passphrase incorrect or encrypted key backup has been tampered with.',
    );
  }
}
