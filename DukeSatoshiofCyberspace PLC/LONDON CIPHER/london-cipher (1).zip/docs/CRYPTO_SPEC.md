# LONDON CIPHER — Cryptographic Specification (`LCFR-v1`)

## 1. Primitive Inventory (Zero Custom Algorithms)

All operations use standard NIST/IETF primitives implemented via the platform Web Crypto API (`crypto.subtle`):

- **Symmetric Authenticated Encryption**: `AES-256-GCM` (128-bit authentication tag)
- **Key Derivation (File Subkeys & Envelopes)**: `HKDF-SHA256` (RFC 5869)
- **Key Agreement (Recipient Envelopes)**: Ephemeral-Static `ECDH` over `NIST P-256`
- **Identity Authentication & Registry Signing**: `ECDSA` over `NIST P-256` with `SHA-256`
- **Password-Based Key Backup**: `PBKDF2-HMAC-SHA256` (310,000 iterations, 16-byte random salt) + `AES-256-GCM`
- **Commitments & Fingerprints**: `SHA-256`

---

## 2. Three-Role Identity Model

Each identity generates three distinct cryptographic keypairs:
1. `authKeyPair` (`ECDSA P-256`): Signs server authentication challenges (`LCFR-AUTH-v1|challengeId|userId|nonce`).
2. `registryKeyPair` (`ECDSA P-256`): Signs canonical registry commitment payloads (`REGISTER_FILE`, `PUBLISH_VERSION`, `UPDATE_STATUS`).
3. `encKeyPair` (`ECDH P-256`): Used solely to unwrap file DEKs from recipient key envelopes.

Public key fingerprints are computed as grouped uppercase hex over `SHA-256(SPKI_DER)`.

---

## 3. Binary Ciphertext Format (`LCFR-v1`)

### 3.1 Fixed Header (64 bytes, Big-Endian)

| Offset | Length | Field | Description |
| :--- | :--- | :--- | :--- |
| `0` | `4` | `magic` | ASCII `"LCFR"` (`0x4C 0x43 0x46 0x52`) |
| `4` | `1` | `version` | `0x01` (`LCFR-v1`) |
| `5` | `1` | `cipherSuite` | `0x01` (`AES-256-GCM-CHUNKED-HKDF-SHA256`) |
| `6` | `16` | `fileId` | Fresh random 128-bit file version identifier |
| `22` | `16` | `nonceSalt` | Fresh random 128-bit HKDF salt |
| `38` | `4` | `chunkSize` | `uint32` plaintext chunk window (default `262144` bytes) |
| `42` | `8` | `plaintextSize` | `uint64` declared plaintext byte length (`>= 0`) |
| `50` | `4` | `totalChunks` | `uint32` total framed chunks (`>= 1`, even for 0-byte files) |
| `54` | `10` | `reserved` | Zero-filled |

### 3.2 Subkey & Nonce Derivation

Given fresh random 256-bit `DEK`:
- `chunkKey = HKDF-SHA256(ikm = DEK, salt = nonceSalt, info = "LCFR-v1-ENC-KEY" || fileId)`
- `noncePrefix (4B) = HKDF-SHA256(ikm = DEK, salt = nonceSalt, info = "LCFR-v1-NONCE-PREFIX" || fileId)`
- `metaKey = HKDF-SHA256(ikm = DEK, salt = nonceSalt, info = "LCFR-v1-META-KEY" || fileId)`

For chunk `i` (`0 <= i < totalChunks`):
- `nonce_i (12B) = noncePrefix (4B) || uint64_be(i) (8B)` — strictly unique per chunk across a file version (`2^64` chunks), while fresh `DEK` + `nonceSalt` guarantee uniqueness across files and versions.
- `AAD_i (43B) = magic(4) || version(1) || suite(1) || fileId(16) || chunkSize(4) || plaintextSize(8) || totalChunks(4) || chunkIndex(4) || isFinal(1)`

Each framed chunk is written as:
`[uint32_be(cipherChunk.byteLength)][cipherChunk (plaintextChunkLen + 16B GCM tag)]`

### 3.3 Integrity, Staging & Error Behaviour

Decryption executes in strict staged verification order:
1. Verify `SHA-256(ciphertext) == expectedCiphertextCommitment`.
2. Parse and validate 64-byte header.
3. Decrypt chunks `0 .. totalChunks - 1` into staging memory, verifying `nonce_i` and `AAD_i` (with `isFinal = 1` on `totalChunks - 1`).
4. Reject any trailing unauthenticated bytes after `totalChunks`.
5. Verify `sum(decryptedChunkLengths) === plaintextSize`.
6. Only if all checks succeed, decrypt `LCFR-META-v1` and release verified plaintext. Any failure aborts immediately without releasing partial plaintext.
