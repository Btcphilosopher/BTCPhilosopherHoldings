# LONDON CIPHER — Threat Model & Security Boundaries

## 1. System Guarantees (What London Cipher Protects Against)

| Threat Scenario | Control Mechanism | Guarantee |
| :--- | :--- | :--- |
| **Storage-Provider Compromise** | Client-side `LCFR-v1` AES-256-GCM chunked encryption with fresh 256-bit random DEK per version; filenames/MIME types encrypted inside `LCFR-META-v1`. | Compromised Local, S3, or CAS storage exposes only opaque ciphertext and encrypted metadata; no plaintext or DEKs exist on storage. |
| **Backend Database Compromise** | Server stores only public JWKs, opaque `fileRef` IDs, commitments, and ECDH-wrapped key envelopes. Private decryption keys and plaintext never leave client memory/storage. | Attacker with full DB read access cannot decrypt files or forge ECDSA P-256 registry signatures. |
| **Network Interception (MITM)** | Transport over TLS in production + end-to-end AEAD ciphertext + ECDSA challenge-response auth + ciphertext SHA-256 commitment verification against blockchain registry. | Passive eavesdroppers observe no plaintext; active network tampering fails commitment & AES-GCM tag verification. |
| **Unauthorised File Access** | Server-side session auth (expiring HMAC bearer tokens), owner-only sharing/revocation, recipient-scoped envelope checks, and cryptographic ECDH key wrapping. | Cross-user requests receive HTTP `403` and lack a valid wrapped DEK envelope. |
| **File Substitution & Corruption** | Dual verification: SHA-256 `ciphertextCommitment` verified against the blockchain registry + per-chunk AES-256-GCM 128-bit tags bound to `fileId`, `chunkIndex`, `totalChunks`, and `isFinal`. | Bit flips, chunk reordering, duplication, truncation, trailing data, and version substitution are rejected before decrypted output leaves staging. |
| **Malicious Uploads & Active Content** | Upload size bounds (`50 MiB`), idempotent finalisation, sanitized download filenames, Content-Security-Policy, and no automatic rendering of active HTML/SVG/JS. | Malicious filenames cannot traverse paths; active decrypted payloads are never auto-executed in the app context. |
| **Recipient-Key Substitution** | Explicit SHA-256 SPKI fingerprint binding in client `trustedDirectory` and AAD of `LCFR-KEY-ENV-v1`. | If a compromised backend returns a rogue `encPublicJwk` for a recipient, `wrapDekForRecipient` throws `RECIPIENT_KEY_MISMATCH` and aborts sharing. |

---

## 2. Explicit Non-Guarantees (Outside System Scope)

1. **Compromised User Endpoints**: If a user's device, browser runtime, or OS memory is compromised with malware/keyloggers, an attacker can read plaintext during encryption/decryption or exfiltrate private keys from browser storage.
2. **Already-Obtained Keys & Downloaded Plaintext**: Revoking access or expiring an invitation blocks *future* server-mediated envelope retrieval and downloads. It **cannot** cryptographically recall plaintext already decrypted or a DEK already unwrapped and saved locally by a previously authorised recipient. Stronger future isolation requires publishing a **new file version** encrypted with a fresh random DEK.
3. **Blockchain Finality ≠ Truthfulness or Content Safety**: A finalised registry transaction proves only that a holder of `registryPrivateKey` committed to a specific `ciphertextCommitment` at a given block height. It does **not** prove file truthfulness, authorship, copyright, or freedom from malware.
4. **Malware Scanning of Client-Encrypted Files**: Because the server receives only opaque ciphertext, server-side antivirus scanning of plaintext is impossible without introducing a trusted decryption enclave or client-side pre-encryption scanner.
5. **Public-Chain Metadata Exposure**: Even though filenames, emails, plaintext hashes, and keys are kept strictly off-chain, public blockchain commitments, transaction timestamps, upload cadence, and owner registry fingerprints can still reveal correlation and activity patterns.
6. **Provider Deletion vs Global Removal**: Deleting ciphertext from one storage adapter removes that provider's copy, but cannot erase copies previously downloaded by authorised recipients, backups, or immutable blockchain commitment records.
7. **Browser Key Storage Limitations**: Web Crypto `localStorage` persistence of JWK key bundles lacks hardware TPM/Secure Enclave isolation. Production desktop deployments should store private keys in OS Keychain / Keystore / Hardware Security Modules.
