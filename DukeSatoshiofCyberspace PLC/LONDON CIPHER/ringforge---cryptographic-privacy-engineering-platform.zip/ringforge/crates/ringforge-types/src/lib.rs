//! RINGFORGE Types - Strongly typed domain structures preventing accidental type mixing.

use serde::{Deserialize, Serialize};
use zeroize::{Zeroize, ZeroizeOnDrop};

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct PublicKey {
    pub key_id: String,
    pub bytes: Vec<u8>,
    pub algorithm: String,
}

#[derive(Clone, Debug, Serialize, Deserialize, Zeroize, ZeroizeOnDrop)]
pub struct PrivateKey {
    pub key_id: String,
    pub bytes: Vec<u8>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct RingSignature {
    pub ring_id: String,
    pub message_hash: [u8; 32],
    pub key_image: Vec<u8>,
    pub c_1: Vec<u8>,
    pub responses: Vec<Vec<u8>>,
    pub algorithm_id: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Pseudonym {
    pub value_hex: String,
    pub domain: String,
    pub formatted: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PrivacyBudget {
    pub dataset_id: String,
    pub total_epsilon: f64,
    pub used_epsilon: f64,
    pub remaining_epsilon: f64,
    pub total_delta: f64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Commitment {
    pub commitment_bytes: Vec<u8>,
    pub blinding_factor_bytes: Vec<u8>,
}
