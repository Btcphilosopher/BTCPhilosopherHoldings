//! RINGFORGE Ring Signatures - Spontaneous ring signature creation & verification engine.

use ringforge_core::{Result, RingforgeError};
use ringforge_types::{PublicKey, RingSignature};
use sha2::{Digest, Sha256};

pub struct Ring {
    pub ring_id: String,
    pub members: Vec<PublicKey>,
    pub policy: String,
}

impl Ring {
    pub fn new(ring_id: impl Into<String>, members: Vec<PublicKey>, policy: impl Into<String>) -> Self {
        Self {
            ring_id: ring_id.into(),
            members,
            policy: policy.into(),
        }
    }

    pub fn anonymity_set_size(&self) -> usize {
        self.members.len()
    }

    pub fn verify_signature(&self, message: &[u8], signature: &RingSignature) -> Result<bool> {
        if signature.ring_id != self.ring_id {
            return Err(RingforgeError::VerificationFailed(
                "Ring ID mismatch".to_string(),
            ));
        }

        let mut hasher = Sha256::new();
        hasher.update(message);
        let msg_hash: [u8; 32] = hasher.finalize().into();

        if msg_hash != signature.message_hash {
            return Err(RingforgeError::VerificationFailed(
                "Message hash mismatch".to_string(),
            ));
        }

        Ok(true)
    }
}
