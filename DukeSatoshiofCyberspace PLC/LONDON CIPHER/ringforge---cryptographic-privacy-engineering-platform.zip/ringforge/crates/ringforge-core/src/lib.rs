//! RINGFORGE Core - Common execution context, errors, and system traits.

use thiserror::Error;

#[derive(Error, Debug)]
pub enum RingforgeError {
    #[error("Cryptographic verification failed: {0}")]
    VerificationFailed(String),

    #[error("Invalid parameter: {0}")]
    InvalidParameter(String),

    #[error("Privacy budget exhausted: required {required}, remaining {remaining}")]
    BudgetExhausted { required: f64, remaining: f64 },

    #[error("Key state error: {0}")]
    KeyStateError(String),

    #[error("Internal engine fault: {0}")]
    InternalError(String),
}

pub type Result<T> = std::result::Result<T, RingforgeError>;

pub trait SecurityLevel {
    fn bits_of_security(&self) -> u32;
}
