import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';
import { ringforgeEngine } from './server/crypto-engine';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

// Initialize Gemini API client safely if key exists
const geminiApiKey = process.env['GEMINI_API_KEY'] || '';
let aiClient: GoogleGenAI | null = null;
if (geminiApiKey && geminiApiKey !== 'MY_GEMINI_API_KEY') {
  aiClient = new GoogleGenAI({ apiKey: geminiApiKey });
}

// REST API V1 ROUTES

// Stats
app.get('/api/v1/stats', (req, res) => {
  res.json(ringforgeEngine.getStats());
});

// Keys Management
app.get('/api/v1/keys', (req, res) => {
  res.json({ keys: ringforgeEngine.getKeys() });
});

app.post('/api/v1/keys/generate', (req, res) => {
  const { owner, purpose, algorithm } = req.body;
  const key = ringforgeEngine.generateKey(owner || 'analyst-01', purpose || 'ring_signature', algorithm || 'Ed25519');
  res.json({ success: true, key });
});

app.post('/api/v1/keys/rotate', (req, res) => {
  const { id } = req.body;
  const newKey = ringforgeEngine.rotateKey(id);
  if (!newKey) {
    res.status(404).json({ error: 'Key not found' });
    return;
  }
  res.json({ success: true, newKey });
});

app.post('/api/v1/keys/revoke', (req, res) => {
  const { id } = req.body;
  const success = ringforgeEngine.revokeKey(id);
  res.json({ success });
});

// Ring Signatures Engine
app.get('/api/v1/rings', (req, res) => {
  res.json({ rings: ringforgeEngine.getRings() });
});

app.post('/api/v1/rings', (req, res) => {
  const { name, members, purpose } = req.body;
  const ring = ringforgeEngine.createRing(name || 'New Ring Panel', members || [], purpose || 'Anonymous verification');
  res.json({ success: true, ring });
});

app.post('/api/v1/rings/sign', (req, res) => {
  try {
    const { ringId, message, signerKeyId } = req.body;
    const result = ringforgeEngine.signRing(ringId, message, signerKeyId);
    res.json(result);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(400).json({ error: msg });
  }
});

app.post('/api/v1/rings/verify', (req, res) => {
  const { ringId, message, signatureHex, keyImageHex } = req.body;
  const result = ringforgeEngine.verifyRingSignature(ringId, message, signatureHex, keyImageHex);
  res.json(result);
});

// Unlinkable Pseudonyms
app.post('/api/v1/pseudonyms/derive', (req, res) => {
  const { masterIdentity, domain } = req.body;
  if (!masterIdentity || !domain) {
    res.status(400).json({ error: 'masterIdentity and domain are required' });
    return;
  }
  const result = ringforgeEngine.derivePseudonym(masterIdentity, domain);
  res.json(result);
});

// Commitments
app.post('/api/v1/commitments/create', (req, res) => {
  const { value } = req.body;
  if (!value) {
    res.status(400).json({ error: 'Value required' });
    return;
  }
  const result = ringforgeEngine.createCommitment(value);
  res.json(result);
});

app.post('/api/v1/commitments/verify', (req, res) => {
  const { value, blindingFactorHex, expectedCommitmentHex } = req.body;
  const result = ringforgeEngine.verifyCommitment(value, blindingFactorHex, expectedCommitmentHex);
  res.json(result);
});

// Blind Signatures
app.post('/api/v1/blind/blind', (req, res) => {
  const { message } = req.body;
  const result = ringforgeEngine.performBlindSignature(message || 'ELIGIBILITY_TOKEN_2026');
  res.json(result);
});

// Anonymous Credentials & ZK
app.post('/api/v1/credentials/issue', (req, res) => {
  const { subjectId, claims } = req.body;
  const cred = ringforgeEngine.issueCredential(subjectId || 'USER-9842', claims || { age: 24, student: true, org: 'Oxford' });
  res.json(cred);
});

app.post('/api/v1/credentials/present', (req, res) => {
  const { credentialId, predicates, discloseFields } = req.body;
  try {
    const presentation = ringforgeEngine.presentCredential(credentialId, predicates || [], discloseFields || []);
    res.json(presentation);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(400).json({ error: msg });
  }
});

// Differential Privacy
app.post('/api/v1/privacy/query', (req, res) => {
  try {
    const { datasetId, queryType, epsilon, delta } = req.body;
    const result = ringforgeEngine.executeDpQuery(datasetId || 'dataset-consumer-research', queryType || 'COUNT', epsilon || 1.0, delta || 1e-5);
    res.json(result);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(400).json({ error: msg });
  }
});

app.get('/api/v1/privacy/budget/:datasetId', (req, res) => {
  const budget = ringforgeEngine.getPrivacyBudget(req.params.datasetId);
  res.json(budget);
});

// Data Minimisation Pipeline
app.post('/api/v1/datasets/minimise', (req, res) => {
  const { policyYaml } = req.body;
  const result = ringforgeEngine.runMinimisationPipeline(policyYaml || '');
  res.json(result);
});

// Audit Chain
app.get('/api/v1/audit/logs', (req, res) => {
  res.json({ logs: ringforgeEngine.getAuditChain() });
});

app.get('/api/v1/audit/verify', (req, res) => {
  res.json(ringforgeEngine.verifyAuditChain());
});

// Gemini AI Policy & Threat Modeling Assistant
app.post('/api/v1/policy/ai-generate', async (req, res) => {
  const { prompt } = req.body;
  if (!aiClient) {
    res.json({
      policyYaml: `dataset: research_transactions\n\nidentity:\n  remove:\n    - name\n    - email\n    - phone\n\nquasi_identifiers:\n  generalise:\n    postcode: outward\n    age: decade\n\nfinancial:\n  retain:\n    - transaction_value\n\nrelease:\n  minimum_group_size: 500\n\nprivacy:\n  differential_privacy:\n    epsilon: 1.5\n    delta: 1e-5`,
      explanation: 'Generated privacy policy enforcing identity removal, decade age generalisation, outward postcode reduction, and Differential Privacy with epsilon=1.5.'
    });
    return;
  }

  try {
    const response = await aiClient.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `You are an expert cryptographic privacy engineer for RINGFORGE.
Generate a valid YAML privacy policy for RINGFORGE based on this requirement:
"${prompt}"

Return a JSON object with two fields:
"policyYaml": string containing clean YAML syntax,
"explanation": string with a plain-English explanation of why these parameters protect privacy without destroying analytical utility.`,
      config: { responseMimeType: 'application/json' }
    });

    const jsonText = response.text;
    const parsed = JSON.parse(jsonText || '{}') as unknown;
    res.json(parsed);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: 'AI generation failed: ' + msg });
  }
});

// Interactive CLI Executor
app.post('/api/v1/cli/exec', (req, res) => {
  const { command } = req.body;
  const cmd = (command || '').trim();

  let output = '';

  if (cmd.startsWith('ringforge key generate')) {
    const key = ringforgeEngine.generateKey('cli-user', 'signing');
    output = JSON.stringify({
      status: 'SUCCESS',
      action: 'key_generate',
      key_id: key.id,
      algorithm: key.algorithm,
      public_key: key.publicKeyHex,
      created_at: key.createdAt,
      zeroized_private_key_handle: '[SECURE_MEMORY_REF_0x7f82b0]'
    }, null, 2);
  } else if (cmd.startsWith('ringforge ring sign')) {
    const rings = ringforgeEngine.getRings();
    if (rings.length > 0) {
      const sig = ringforgeEngine.signRing(rings[0].id, 'AUDIT_REPORT_HASH_2026');
      output = JSON.stringify(sig, null, 2);
    } else {
      output = 'Error: No active rings found.';
    }
  } else if (cmd.startsWith('ringforge pseudonym issue')) {
    const psn = ringforgeEngine.derivePseudonym('USER-48392', 'healthcare');
    output = JSON.stringify(psn, null, 2);
  } else if (cmd.startsWith('ringforge dataset minimise')) {
    const min = ringforgeEngine.runMinimisationPipeline('default');
    output = JSON.stringify(min, null, 2);
  } else if (cmd.startsWith('ringforge audit verify')) {
    const audit = ringforgeEngine.verifyAuditChain();
    output = JSON.stringify({
      audit_chain_status: audit.valid ? 'VALID_TAMPER_FREE' : 'TAMPER_DETECTED',
      total_block_depth: audit.totalEntries,
      algorithm: 'SHA256_HASH_CHAIN'
    }, null, 2);
  } else if (cmd.startsWith('ringforge help') || cmd === 'ringforge') {
    output = `RINGFORGE CLI v0.1.0 - Cryptographic Data Anonymisation Platform

USAGE:
    ringforge <SUBCOMMAND>

SUBCOMMANDS:
    key generate         Generate new cryptographic keypair
    key rotate           Rotate key version
    ring create          Create a new anonymous ring signature set
    ring sign            Produce linkable/unlinkable ring signature
    ring verify          Verify ring signature membership
    pseudonym issue      Derive domain-separated HKDF pseudonym
    credential issue     Issue anonymous credential
    dataset minimise     Execute policy-driven data minimisation pipeline
    privacy analyse      Evaluate differential privacy budget & noise
    audit verify         Validate tamper-evident hash chain ledger`;
  } else {
    output = `Unknown command: '${cmd}'. Type 'ringforge help' for available commands.`;
  }

  res.json({ output, exitCode: 0, command: cmd });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, () => {
    console.log(`RINGFORGE Express Server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
