import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RingforgeService } from './services/ringforge';

import { HeaderComponent } from './components/header';
import { DashboardComponent } from './components/dashboard';
import { RingSignaturesComponent } from './components/ring-signatures';
import { PseudonymsComponent } from './components/pseudonyms';
import { CredentialsComponent } from './components/credentials';
import { CommitmentsBlindComponent } from './components/commitments-blind';
import { MinimisationComponent } from './components/minimisation';
import { DifferentialPrivacyComponent } from './components/differential-privacy';
import { KeysComponent } from './components/keys';
import { ReleaseAuditComponent } from './components/release-audit';
import { CliTerminalComponent } from './components/cli-terminal';
import { ArchitectureComponent } from './components/architecture';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    HeaderComponent,
    DashboardComponent,
    RingSignaturesComponent,
    PseudonymsComponent,
    CredentialsComponent,
    CommitmentsBlindComponent,
    MinimisationComponent,
    DifferentialPrivacyComponent,
    KeysComponent,
    ReleaseAuditComponent,
    CliTerminalComponent,
    ArchitectureComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  public service = inject(RingforgeService);
}
