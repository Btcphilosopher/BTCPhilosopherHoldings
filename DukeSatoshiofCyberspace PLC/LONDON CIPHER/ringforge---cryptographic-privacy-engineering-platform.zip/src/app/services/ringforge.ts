import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

export type TabType = 
  | 'dashboard'
  | 'rings'
  | 'pseudonyms'
  | 'credentials'
  | 'commitments'
  | 'minimisation'
  | 'differential-privacy'
  | 'keys'
  | 'release-audit'
  | 'cli'
  | 'architecture';

export interface GlobalStats {
  protectedDatasets: number;
  activeRings: number;
  credentialIssuers: number;
  privacyBudgetsCount: number;
  releasesThisMonth: number;
  failedVerifications: number;
  keysRequiringRotation: number;
  totalKeys: number;
  auditLedgerDepth: number;
  auditChainValid: boolean;
}

export interface RingItem {
  id: string;
  name: string;
  members: string[];
  algorithm: string;
  minSecurityLevel: number;
  validFrom: string;
  validUntil: string;
  anonymitySetSize: number;
  purpose: string;
  status: string;
  signatureCount: number;
}

export interface KeyItem {
  id: string;
  algorithm: string;
  purpose: string;
  publicKeyHex: string;
  createdAt: string;
  expiresAt: string;
  status: string;
  version: number;
  owner: string;
}

export interface AuditLogItem {
  index: number;
  timestamp: string;
  action: string;
  actorReference: string;
  objectReference: string;
  details: Record<string, unknown>;
  previousHash: string;
  eventHash: string;
}

export interface RingSignResponse {
  ringId: string;
  messageHash: string;
  signatureHex: string;
  keyImageHex: string;
  algorithm: string;
  timestamp: string;
  verified: boolean;
  anonymitySetSize: number;
  signerDisclosed: boolean;
  linkability: string;
}

export interface PseudonymResponse {
  masterIdentity: string;
  domain: string;
  pseudonymHex: string;
  pseudonymFormatted: string;
  derivationMethod: string;
  domainIndependent: boolean;
  timestamp: string;
}

export interface CommitmentResponse {
  id: string;
  commitmentHex: string;
  value: string;
  blindingFactorHex: string;
  timestamp: string;
  verified?: boolean;
}

export interface BlindSignatureResponse {
  messageHash: string;
  blindedMessageHex: string;
  blindFactorHex: string;
  blindSignatureHex: string;
  unblindedSignatureHex: string;
  verified: boolean;
}

export interface CredentialResponse {
  id: string;
  issuerId: string;
  subjectId: string;
  claims: Record<string, unknown>;
  issuedAt: string;
  expiresAt: string;
  signature: string;
}

export interface CredentialPredicateItem {
  field: string;
  operator: string;
  targetValue: unknown;
  satisfied: boolean;
}

export interface CredentialPresentationResponse {
  credentialId: string;
  provedPredicates: CredentialPredicateItem[];
  disclosedFields: Record<string, unknown>;
  hiddenFields: string[];
  proofHex: string;
  verified: boolean;
  timestamp: string;
}

export interface DpQueryResponse {
  queryResult: number;
  noisyResult: number;
  noiseAdded: number;
  remainingEpsilon: number;
}

export interface DpBudgetResponse {
  totalEpsilon: number;
  usedEpsilon: number;
  remainingEpsilon: number;
  queryCount: number;
}

export interface MinimisationResponse {
  recordsProcessed: number;
  removedFields: string[];
  generalizedFields: string[];
  kAnonymity: number;
  riskScore: string;
  transformationHash: string;
  sampleProcessed: Record<string, unknown>[];
}

export interface CliExecResponse {
  output: string;
  exitCode: number;
  command: string;
}

export interface AiPolicyResponse {
  policyYaml?: string;
  explanation?: string;
}

@Injectable({
  providedIn: 'root'
})
export class RingforgeService {
  private http = inject(HttpClient);

  // State
  public activeTab = signal<TabType>('dashboard');
  public stats = signal<GlobalStats | null>(null);
  public rings = signal<RingItem[]>([]);
  public keys = signal<KeyItem[]>([]);
  public auditChain = signal<AuditLogItem[]>([]);
  public loading = signal<boolean>(false);
  public lastNotification = signal<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  constructor() {
    this.refreshAllData();
  }

  public notify(message: string, type: 'success' | 'error' | 'info' = 'info') {
    this.lastNotification.set({ message, type });
    setTimeout(() => {
      if (this.lastNotification()?.message === message) {
        this.lastNotification.set(null);
      }
    }, 4000);
  }

  public async refreshAllData() {
    try {
      this.loading.set(true);
      const [statsRes, ringsRes, keysRes, auditRes] = await Promise.all([
        firstValueFrom(this.http.get<GlobalStats>('/api/v1/stats')),
        firstValueFrom(this.http.get<{ rings: RingItem[] }>('/api/v1/rings')),
        firstValueFrom(this.http.get<{ keys: KeyItem[] }>('/api/v1/keys')),
        firstValueFrom(this.http.get<{ logs: AuditLogItem[] }>('/api/v1/audit/logs'))
      ]);

      this.stats.set(statsRes);
      this.rings.set(ringsRes.rings || []);
      this.keys.set(keysRes.keys || []);
      this.auditChain.set(auditRes.logs || []);
    } catch (err) {
      console.error('Failed to load RINGFORGE data:', err);
    } finally {
      this.loading.set(false);
    }
  }

  // Ring Signatures API
  public async signRing(ringId: string, message: string, signerKeyId?: string): Promise<RingSignResponse> {
    const res = await firstValueFrom(this.http.post<RingSignResponse>('/api/v1/rings/sign', { ringId, message, signerKeyId }));
    await this.refreshAllData();
    return res;
  }

  public async verifyRingSignature(ringId: string, message: string, signatureHex: string, keyImageHex: string): Promise<{ verified: boolean; anonymitySetSize: number; details: string }> {
    return firstValueFrom(this.http.post<{ verified: boolean; anonymitySetSize: number; details: string }>('/api/v1/rings/verify', { ringId, message, signatureHex, keyImageHex }));
  }

  public async createRing(name: string, members: string[], purpose: string): Promise<{ success: boolean; ring: RingItem }> {
    const res = await firstValueFrom(this.http.post<{ success: boolean; ring: RingItem }>('/api/v1/rings', { name, members, purpose }));
    await this.refreshAllData();
    return res;
  }

  // Pseudonyms API
  public async derivePseudonym(masterIdentity: string, domain: string): Promise<PseudonymResponse> {
    return firstValueFrom(this.http.post<PseudonymResponse>('/api/v1/pseudonyms/derive', { masterIdentity, domain }));
  }

  // Commitments & Blind
  public async createCommitment(value: string): Promise<CommitmentResponse> {
    return firstValueFrom(this.http.post<CommitmentResponse>('/api/v1/commitments/create', { value }));
  }

  public async verifyCommitment(value: string, blindingFactorHex: string, expectedCommitmentHex: string): Promise<{ verified: boolean; details: string }> {
    return firstValueFrom(this.http.post<{ verified: boolean; details: string }>('/api/v1/commitments/verify', { value, blindingFactorHex, expectedCommitmentHex }));
  }

  public async performBlindSignature(message: string): Promise<BlindSignatureResponse> {
    return firstValueFrom(this.http.post<BlindSignatureResponse>('/api/v1/blind/blind', { message }));
  }

  // Credentials & ZK
  public async issueCredential(subjectId: string, claims: Record<string, unknown>): Promise<CredentialResponse> {
    return firstValueFrom(this.http.post<CredentialResponse>('/api/v1/credentials/issue', { subjectId, claims }));
  }

  public async presentCredential(credentialId: string, predicates: unknown[], discloseFields: string[]): Promise<CredentialPresentationResponse> {
    return firstValueFrom(this.http.post<CredentialPresentationResponse>('/api/v1/credentials/present', { credentialId, predicates, discloseFields }));
  }

  // Differential Privacy
  public async executeDpQuery(datasetId: string, queryType: 'COUNT' | 'SUM' | 'AVERAGE', epsilon: number, delta = 1e-5): Promise<DpQueryResponse> {
    const res = await firstValueFrom(this.http.post<DpQueryResponse>('/api/v1/privacy/query', { datasetId, queryType, epsilon, delta }));
    await this.refreshAllData();
    return res;
  }

  public async getPrivacyBudget(datasetId: string): Promise<DpBudgetResponse> {
    return firstValueFrom(this.http.get<DpBudgetResponse>(`/api/v1/privacy/budget/${datasetId}`));
  }

  // Data Minimisation Pipeline
  public async runMinimisationPipeline(policyYaml: string): Promise<MinimisationResponse> {
    const res = await firstValueFrom(this.http.post<MinimisationResponse>('/api/v1/datasets/minimise', { policyYaml }));
    await this.refreshAllData();
    return res;
  }

  // Keys API
  public async generateKey(owner: string, purpose: string, algorithm = 'Ed25519'): Promise<{ success: boolean; key: KeyItem }> {
    const res = await firstValueFrom(this.http.post<{ success: boolean; key: KeyItem }>('/api/v1/keys/generate', { owner, purpose, algorithm }));
    await this.refreshAllData();
    return res;
  }

  public async rotateKey(id: string): Promise<{ success: boolean; newKey: KeyItem }> {
    const res = await firstValueFrom(this.http.post<{ success: boolean; newKey: KeyItem }>('/api/v1/keys/rotate', { id }));
    await this.refreshAllData();
    return res;
  }

  public async revokeKey(id: string): Promise<{ success: boolean }> {
    const res = await firstValueFrom(this.http.post<{ success: boolean }>('/api/v1/keys/revoke', { id }));
    await this.refreshAllData();
    return res;
  }

  // Audit
  public async verifyAuditChain(): Promise<{ valid: boolean; totalEntries: number; brokenIndex?: number }> {
    return firstValueFrom(this.http.get<{ valid: boolean; totalEntries: number; brokenIndex?: number }>('/api/v1/audit/verify'));
  }

  // CLI
  public async execCli(command: string): Promise<CliExecResponse> {
    return firstValueFrom(this.http.post<CliExecResponse>('/api/v1/cli/exec', { command }));
  }

  // AI Policy Generation
  public async generateAiPolicy(prompt: string): Promise<AiPolicyResponse> {
    return firstValueFrom(this.http.post<AiPolicyResponse>('/api/v1/policy/ai-generate', { prompt }));
  }
}
