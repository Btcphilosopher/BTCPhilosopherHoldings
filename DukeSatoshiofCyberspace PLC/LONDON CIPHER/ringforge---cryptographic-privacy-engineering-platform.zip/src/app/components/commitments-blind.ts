import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RingforgeService, CommitmentResponse, BlindSignatureResponse } from '../services/ringforge';

@Component({
  selector: 'app-commitments-blind',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Header -->
      <div class="bg-slate-900/90 border border-slate-800 p-6 rounded-2xl space-y-1">
        <div class="flex items-center gap-2 text-xs font-mono text-emerald-400">
          <mat-icon class="text-sm">lock</mat-icon>
          <span>CRYPTOGRAPHIC PRIMITIVES #4 & #5</span>
        </div>
        <h1 class="text-xl font-bold text-white">Cryptographic Commitments & Blind Signatures</h1>
        <p class="text-xs text-slate-400 max-w-3xl">
          Hide secrets with binding commitment schemes (commit & open) and issue un-linkable eligibility tokens with blind signatures (blind, sign, unblind, verify).
        </p>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <!-- Studio 1: Cryptographic Commitments -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 class="text-sm font-semibold text-white flex items-center gap-2">
              <mat-icon class="text-emerald-400 text-base">shield_lock</mat-icon>
              <span>1. Cryptographic Commitment Scheme</span>
            </h2>
            <span class="text-[10px] font-mono text-slate-400">Pedersen / Blinding</span>
          </div>

          <div class="space-y-3 text-xs">
            <div>
              <label for="commit-val" class="block font-mono text-slate-400 mb-1">Secret Value to Commit (Sealed Submission)</label>
              <input
                id="commit-val"
                type="text"
                [(ngModel)]="commitValue"
                placeholder="e.g. AUDIT_BID_AMOUNT_£4,250,000"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 font-mono text-white focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <button
              (click)="createCommitment()"
              class="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <mat-icon class="text-sm">lock</mat-icon>
              <span>Create Commitment C = H(Value || Randomness)</span>
            </button>

            <!-- Commitment Output -->
            @if (activeCommitment(); as cmt) {
              <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2 font-mono text-xs">
                <div class="text-emerald-400 font-bold flex items-center justify-between">
                  <span>COMMITMENT CREATED</span>
                  <span class="text-[10px] bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded">&check; BINDING</span>
                </div>
                <div class="text-[11px] text-slate-300 space-y-1">
                  <div>Commitment Hex: <span class="text-emerald-400 font-bold break-all">{{ cmt.commitmentHex }}</span></div>
                  <div>Random Blinding Factor r: <span class="text-slate-400 break-all">{{ cmt.blindingFactorHex }}</span></div>
                </div>

                <div class="pt-2">
                  <button
                    (click)="verifyCommitment(cmt)"
                    class="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 text-xs rounded-md transition-colors flex items-center justify-center gap-1.5 border border-slate-700"
                  >
                    <mat-icon class="text-xs">key</mat-icon>
                    <span>Open Commitment & Verify Opening</span>
                  </button>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Studio 2: Blind Signatures -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 class="text-sm font-semibold text-white flex items-center gap-2">
              <mat-icon class="text-cyan-400 text-base">visibility_off</mat-icon>
              <span>2. Blind Signature Protocol</span>
            </h2>
            <span class="text-[10px] font-mono text-slate-400">Anonymous Eligibility</span>
          </div>

          <div class="space-y-3 text-xs">
            <div>
              <label for="blind-msg" class="block font-mono text-slate-400 mb-1">Access Token Payload</label>
              <input
                id="blind-msg"
                type="text"
                [(ngModel)]="blindMessage"
                placeholder="e.g. STATISTICAL_SUBMISSION_TOKEN_2026"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 font-mono text-white focus:border-cyan-500 focus:outline-none"
              />
            </div>

            <button
              (click)="runBlindProtocol()"
              class="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <mat-icon class="text-sm">published_with_changes</mat-icon>
              <span>Run Blind Signature Pipeline (Blind &rarr; Sign &rarr; Unblind)</span>
            </button>

            <!-- Blind Output -->
            @if (blindResult(); as bld) {
              <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2 font-mono text-xs">
                <div class="text-cyan-400 font-bold flex items-center justify-between">
                  <span>BLIND PROTOCOL COMPLETE</span>
                  <span class="text-[10px] bg-cyan-500/10 border border-cyan-500/30 px-2 py-0.5 rounded">&check; UNLINKABLE</span>
                </div>
                <div class="text-[11px] text-slate-300 space-y-1 overflow-x-auto">
                  <div>Message Hash: <span class="text-white">{{ bld.messageHash }}</span></div>
                  <div>Blinded Request (Signer Sees): <span class="text-slate-400 font-bold break-all">{{ bld.blindedMessageHex }}</span></div>
                  <div>Unblinded Valid Signature: <span class="text-cyan-400 font-bold break-all">{{ bld.unblindedSignatureHex }}</span></div>
                </div>
              </div>
            }
          </div>
        </div>

      </div>

    </div>
  `
})
export class CommitmentsBlindComponent {
  public service = inject(RingforgeService);

  public commitValue = 'AUDIT_BID_AMOUNT_£4,250,000';
  public blindMessage = 'STATISTICAL_SUBMISSION_TOKEN_2026';

  public activeCommitment = signal<CommitmentResponse | null>(null);
  public blindResult = signal<BlindSignatureResponse | null>(null);

  public async createCommitment() {
    try {
      const res = await this.service.createCommitment(this.commitValue);
      this.activeCommitment.set(res);
      this.service.notify('Cryptographic commitment created. Value hidden, binding guaranteed.', 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Commitment error: ' + msg, 'error');
    }
  }

  public async verifyCommitment(cmt: CommitmentResponse) {
    try {
      const res = await this.service.verifyCommitment(cmt.value, cmt.blindingFactorHex, cmt.commitmentHex);
      if (res.verified) {
        this.service.notify('Commitment opened! Value and blinding factor match commitment hash.', 'success');
      } else {
        this.service.notify('Commitment verification failed.', 'error');
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Opening error: ' + msg, 'error');
    }
  }

  public async runBlindProtocol() {
    try {
      const res = await this.service.performBlindSignature(this.blindMessage);
      this.blindResult.set(res);
      this.service.notify('Blind signature protocol executed. Authority signed blinded payload without learning content.', 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Blind error: ' + msg, 'error');
    }
  }
}
