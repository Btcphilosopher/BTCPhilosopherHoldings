import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RingforgeService, TabType } from '../services/ringforge';

@Component({
  selector: 'app-dashboard',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Top Banner / Governing Principle -->
      <div class="bg-gradient-to-r from-slate-900 via-[#0e1726] to-slate-900 border border-slate-800 rounded-2xl p-6 lg:p-8 relative overflow-hidden shadow-xl">
        <div class="absolute -right-12 -top-12 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none"></div>
        
        <div class="max-w-4xl space-y-3 relative z-10">
          <div class="flex items-center gap-2 text-xs font-mono text-emerald-400">
            <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>RUST CRYPTOGRAPHIC PRIVACY ENGINEERING PLATFORM</span>
            <span class="text-slate-600">·</span>
            <span>SYSTEM STATUS: NOMINAL</span>
          </div>

          <h1 class="text-2xl sm:text-3xl font-bold tracking-tight text-white font-sans">
            PROVE WHAT NEEDS TO BE PROVEN.<br/>REVEAL ONLY WHAT NEEDS TO BE REVEALED.
          </h1>

          <p class="text-slate-400 text-sm leading-relaxed max-w-3xl">
            RINGFORGE decouples identity from analytical data through ring signatures, threshold cryptography, HKDF domain-separated pseudonyms, zero-knowledge credential presentations, and differential privacy accounting.
          </p>

          <div class="pt-2 flex flex-wrap gap-3">
            <button
              (click)="goToTab('rings')"
              class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 shadow-sm"
            >
              <mat-icon class="text-sm">all_inclusive</mat-icon>
              <span>Ring Signatures Studio</span>
            </button>

            <button
              (click)="goToTab('minimisation')"
              class="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2"
            >
              <mat-icon class="text-sm">filter_alt</mat-icon>
              <span>Minimisation Pipeline</span>
            </button>

            <button
              (click)="goToTab('cli')"
              class="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-emerald-400 border border-emerald-500/30 text-xs font-mono rounded-lg transition-colors flex items-center gap-2"
            >
              <mat-icon class="text-sm">terminal</mat-icon>
              <span>ringforge cli</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Executive Metric Scorecard Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        
        <div class="bg-slate-900/80 border border-slate-800/80 rounded-xl p-3.5 space-y-1">
          <div class="text-[10px] uppercase tracking-wider font-mono text-slate-400">PROTECTED DATASETS</div>
          <div class="text-xl font-bold font-mono text-white tabular-nums">{{ stats()?.protectedDatasets || 42 }}</div>
          <div class="text-[10px] text-emerald-400 font-mono">1M Records/Dataset</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800/80 rounded-xl p-3.5 space-y-1">
          <div class="text-[10px] uppercase tracking-wider font-mono text-slate-400">ACTIVE RINGS</div>
          <div class="text-xl font-bold font-mono text-emerald-400 tabular-nums">{{ stats()?.activeRings || 18 }}</div>
          <div class="text-[10px] text-slate-400 font-mono">256 Max Anonymity</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800/80 rounded-xl p-3.5 space-y-1">
          <div class="text-[10px] uppercase tracking-wider font-mono text-slate-400">CREDENTIAL ISSUERS</div>
          <div class="text-xl font-bold font-mono text-white tabular-nums">{{ stats()?.credentialIssuers || 7 }}</div>
          <div class="text-[10px] text-slate-400 font-mono">ZK Predicate Proofs</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800/80 rounded-xl p-3.5 space-y-1">
          <div class="text-[10px] uppercase tracking-wider font-mono text-slate-400">PRIVACY BUDGETS</div>
          <div class="text-xl font-bold font-mono text-white tabular-nums">{{ stats()?.privacyBudgetsCount || 31 }}</div>
          <div class="text-[10px] text-cyan-400 font-mono">&epsilon;=5.2 Remaining</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800/80 rounded-xl p-3.5 space-y-1">
          <div class="text-[10px] uppercase tracking-wider font-mono text-slate-400">RELEASES / MONTH</div>
          <div class="text-xl font-bold font-mono text-white tabular-nums">{{ stats()?.releasesThisMonth || 84 }}</div>
          <div class="text-[10px] text-emerald-400 font-mono">Signed Provenance</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800/80 rounded-xl p-3.5 space-y-1">
          <div class="text-[10px] uppercase tracking-wider font-mono text-slate-400">FAILED VERIF.</div>
          <div class="text-xl font-bold font-mono text-emerald-400 tabular-nums">{{ stats()?.failedVerifications || 0 }}</div>
          <div class="text-[10px] text-emerald-400 font-mono">Zero Breaches</div>
        </div>

        <div class="bg-slate-900/80 border border-amber-500/30 rounded-xl p-3.5 space-y-1 bg-amber-950/10">
          <div class="text-[10px] uppercase tracking-wider font-mono text-amber-400">ROTATION NEEDED</div>
          <div class="text-xl font-bold font-mono text-amber-300 tabular-nums">{{ stats()?.keysRequiringRotation || 2 }}</div>
          <div class="text-[10px] text-amber-400/80 font-mono">Keys &gt; 330 days</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800/80 rounded-xl p-3.5 space-y-1">
          <div class="text-[10px] uppercase tracking-wider font-mono text-slate-400">AUDIT LEDGER</div>
          <div class="text-xl font-bold font-mono text-emerald-400 tabular-nums">{{ stats()?.auditLedgerDepth || 12 }}</div>
          <div class="text-[10px] text-emerald-400 font-mono">&check; Hash Chain Valid</div>
        </div>

      </div>

      <!-- Core Transformation Architecture Diagram -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div class="flex items-center justify-between">
          <div class="space-y-0.5">
            <h2 class="text-base font-semibold text-white">Cryptographic Data Flow Architecture</h2>
            <p class="text-xs text-slate-400">Strict stage boundaries ensure identity separation prior to analytical release.</p>
          </div>
          <span class="text-xs font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-1 rounded-md">8 STAGE PIPELINE</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-7 gap-3 pt-2">
          
          <div class="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2 relative group hover:border-slate-700 transition-colors">
            <div class="flex items-center justify-between text-[11px] font-mono text-slate-400">
              <span>01. RAW DATA</span>
              <mat-icon class="text-sm text-rose-400">lock_open</mat-icon>
            </div>
            <div class="text-xs font-semibold text-slate-200">Raw Sensitive Input</div>
            <p class="text-[11px] text-slate-400">Direct identifiers, exact timestamps, raw income, DOB.</p>
          </div>

          <div class="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2 relative group hover:border-slate-700 transition-colors">
            <div class="flex items-center justify-between text-[11px] font-mono text-slate-400">
              <span>02. SEPARATION</span>
              <mat-icon class="text-sm text-amber-400">content_cut</mat-icon>
            </div>
            <div class="text-xs font-semibold text-slate-200">Identity Stripping</div>
            <p class="text-[11px] text-slate-400">Isolate identity database from analytical pipeline.</p>
          </div>

          <div class="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2 relative group hover:border-slate-700 transition-colors">
            <div class="flex items-center justify-between text-[11px] font-mono text-slate-400">
              <span>03. PSEUDONYM</span>
              <mat-icon class="text-sm text-cyan-400">fingerprint</mat-icon>
            </div>
            <div class="text-xs font-semibold text-slate-200">HKDF Separation</div>
            <p class="text-[11px] text-slate-400">Unlinkable pseudonyms per analytical domain.</p>
          </div>

          <div class="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2 relative group hover:border-slate-700 transition-colors">
            <div class="flex items-center justify-between text-[11px] font-mono text-slate-400">
              <span>04. MINIMISE</span>
              <mat-icon class="text-sm text-indigo-400">filter_alt</mat-icon>
            </div>
            <div class="text-xs font-semibold text-slate-200">Policy Transformer</div>
            <p class="text-[11px] text-slate-400">Age decades, outward postcodes, cohort bounds.</p>
          </div>

          <div class="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2 relative group hover:border-slate-700 transition-colors">
            <div class="flex items-center justify-between text-[11px] font-mono text-slate-400">
              <span>05. PROTECT</span>
              <mat-icon class="text-sm text-emerald-400">all_inclusive</mat-icon>
            </div>
            <div class="text-xs font-semibold text-slate-200">Ring & Envelope</div>
            <p class="text-[11px] text-slate-400">RST-Ed25519 ring signatures & AEAD vault encryption.</p>
          </div>

          <div class="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2 relative group hover:border-slate-700 transition-colors">
            <div class="flex items-center justify-between text-[11px] font-mono text-slate-400">
              <span>06. DP ANALYSIS</span>
              <mat-icon class="text-sm text-purple-400">insights</mat-icon>
            </div>
            <div class="text-xs font-semibold text-slate-200">Laplace / Gaussian</div>
            <p class="text-[11px] text-slate-400">Strict &epsilon;, &delta; privacy budget query accounting.</p>
          </div>

          <div class="bg-slate-950 border border-emerald-500/30 rounded-xl p-3.5 space-y-2 relative group hover:border-emerald-400 transition-colors bg-emerald-950/10">
            <div class="flex items-center justify-between text-[11px] font-mono text-emerald-400">
              <span>07. RELEASE</span>
              <mat-icon class="text-sm text-emerald-400">verified</mat-icon>
            </div>
            <div class="text-xs font-semibold text-emerald-300">Signed Artifact</div>
            <p class="text-[11px] text-slate-300">Audited release with cryptographic provenance chain.</p>
          </div>

        </div>
      </div>

      <!-- Quick Cryptographic Interactive Demos -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <!-- Demo 1: Ring Signature Test -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400 text-base">all_inclusive</mat-icon>
              <h3 class="text-sm font-semibold text-white">Ring Signature Engine</h3>
            </div>
            <span class="text-[10px] font-mono text-slate-400">RST-Ed25519</span>
          </div>

          <p class="text-xs text-slate-400 leading-relaxed">
            Prove that an audit report was signed by an authorised panel member without revealing which auditor generated it.
          </p>

          <div class="bg-slate-950 rounded-lg p-3 font-mono text-[11px] space-y-1 text-slate-300 border border-slate-800">
            <div class="text-slate-400">// Active Ring: Financial Auditors (8 Members)</div>
            <div>Ring ID: <span class="text-emerald-400">ring-financial-audit-2026</span></div>
            <div>Signer Anonymity Set: <span class="text-white font-bold">8 / 8 (100% Unlinkable)</span></div>
          </div>

          <button
            (click)="testRingSignature()"
            class="w-full py-2 bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 text-xs font-mono rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <mat-icon class="text-sm">gesture</mat-icon>
            <span>Execute Ring Signature</span>
          </button>
        </div>

        <!-- Demo 2: Pseudonym Derivation -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400 text-base">fingerprint</mat-icon>
              <h3 class="text-sm font-semibold text-white">Domain Pseudonym Generator</h3>
            </div>
            <span class="text-[10px] font-mono text-slate-400">HKDF-HMAC</span>
          </div>

          <p class="text-xs text-slate-400 leading-relaxed">
            Derive cryptographically independent pseudonyms for healthcare vs financial research for the same master identity.
          </p>

          <div class="bg-slate-950 rounded-lg p-3 font-mono text-[11px] space-y-1 text-slate-300 border border-slate-800">
            <div class="text-slate-400">// Master ID: USER-94821</div>
            <div>Healthcare: <span class="text-cyan-400">{{ samplePsnHealth || 'psn_hea_8f9a2b1c' }}</span></div>
            <div>Financial: <span class="text-purple-400">{{ samplePsnFin || 'psn_fin_4d3e2f1a' }}</span></div>
          </div>

          <button
            (click)="testPseudonyms()"
            class="w-full py-2 bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-slate-700 text-xs font-mono rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <mat-icon class="text-sm">shuffle</mat-icon>
            <span>Derive Domain Pseudonyms</span>
          </button>
        </div>

        <!-- Demo 3: Differential Privacy Query -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <mat-icon class="text-purple-400 text-base">insights</mat-icon>
              <h3 class="text-sm font-semibold text-white">Differential Privacy Query</h3>
            </div>
            <span class="text-[10px] font-mono text-slate-400">Laplace (&epsilon;=1.0)</span>
          </div>

          <p class="text-xs text-slate-400 leading-relaxed">
            Query aggregate consumer statistics on 1,000,000 records with calibrated Laplace noise injection and budget accounting.
          </p>

          <div class="bg-slate-950 rounded-lg p-3 font-mono text-[11px] space-y-1 text-slate-300 border border-slate-800">
            <div>True Value: <span class="text-white font-bold">1,000,000</span></div>
            <div>Noisy Output: <span class="text-purple-400 font-bold">{{ dpNoisyValue ? dpNoisyValue.toFixed(0) : '1,000,004' }}</span></div>
            <div>Remaining Budget: <span class="text-emerald-400">&epsilon;={{ dpEpsilon ? dpEpsilon.toFixed(2) : '5.20' }}</span></div>
          </div>

          <button
            (click)="testDpQuery()"
            class="w-full py-2 bg-slate-800 hover:bg-slate-700 text-purple-400 border border-slate-700 text-xs font-mono rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <mat-icon class="text-sm">functions</mat-icon>
            <span>Execute DP Query</span>
          </button>
        </div>

      </div>

      <!-- Threat Model & Governing Principles Matrix -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div class="flex items-center gap-2 text-sm font-semibold text-white">
            <mat-icon class="text-emerald-400">security</mat-icon>
            <span>Threat Model & Cryptographic Guarantees</span>
          </div>

          <div class="space-y-3 text-xs">
            
            <div class="bg-slate-950/80 border border-slate-800 p-3 rounded-lg space-y-1">
              <div class="font-semibold text-emerald-400 flex items-center gap-1.5">
                <mat-icon class="text-sm">check_circle</mat-icon>
                <span>PROTECTS AGAINST</span>
              </div>
              <ul class="text-slate-400 space-y-1 pl-5 list-disc text-[11px]">
                <li>Unauthorised database reader inspecting raw identity attributes</li>
                <li>Malicious analysts attempting cross-domain record linkage</li>
                <li>Single administrator key compromise (M-of-N threshold recovery)</li>
                <li>Unlimited differential privacy query reconstruction attacks</li>
                <li>Tampering with analytical release provenance or policy logs</li>
              </ul>
            </div>

            <div class="bg-slate-950/80 border border-slate-800 p-3 rounded-lg space-y-1">
              <div class="font-semibold text-amber-400 flex items-center gap-1.5">
                <mat-icon class="text-sm">warning</mat-icon>
                <span>DOES NOT PROTECT AGAINST</span>
              </div>
              <ul class="text-slate-400 space-y-1 pl-5 list-disc text-[11px]">
                <li>Compromised client endpoint side-channels prior to ingestion</li>
                <li>Collusion of all M threshold key custodians</li>
                <li>Extremely high epsilon privacy budget allocations (&epsilon; &gt; 20.0)</li>
              </ul>
            </div>

          </div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div class="flex items-center gap-2 text-sm font-semibold text-white">
            <mat-icon class="text-emerald-400">gavel</mat-icon>
            <span>Governing Engineering Principles</span>
          </div>

          <div class="space-y-2 font-mono text-xs text-slate-300">
            <div class="p-2.5 bg-slate-950 border border-slate-800 rounded-lg flex items-center gap-2">
              <span class="text-emerald-400 font-bold">&check;</span>
              <span>1. IDENTITY IS NOT DATA.</span>
            </div>

            <div class="p-2.5 bg-slate-950 border border-slate-800 rounded-lg flex items-center gap-2">
              <span class="text-emerald-400 font-bold">&check;</span>
              <span>2. PRIVACY IS NOT THE SAME AS ENCRYPTION.</span>
            </div>

            <div class="p-2.5 bg-slate-950 border border-slate-800 rounded-lg flex items-center gap-2">
              <span class="text-emerald-400 font-bold">&check;</span>
              <span>3. ANONYMITY IS NOT THE SAME AS PSEUDONYMISATION.</span>
            </div>

            <div class="p-2.5 bg-slate-950 border border-slate-800 rounded-lg flex items-center gap-2">
              <span class="text-emerald-400 font-bold">&check;</span>
              <span>4. A HASH IS NOT AN ANONYMISATION SYSTEM.</span>
            </div>

            <div class="p-2.5 bg-slate-950 border border-slate-800 rounded-lg flex items-center gap-2">
              <span class="text-emerald-400 font-bold">&check;</span>
              <span>5. K-ANONYMITY IS NOT A COMPLETE GUARANTEE.</span>
            </div>
          </div>
        </div>

      </div>

      <!-- Institutional Disclaimer Footer -->
      <div class="p-4 bg-slate-950/90 border border-slate-800/80 rounded-xl flex items-start gap-3 text-slate-400 text-xs leading-relaxed">
        <mat-icon class="text-amber-400 text-base shrink-0 mt-0.5">info</mat-icon>
        <div>
          <span class="text-slate-200 font-semibold">IMPORTANT CRYPTOGRAPHIC DISCLAIMER:</span> RINGFORGE is an engineering and research platform. Cryptographic security depends on the underlying algorithms, implementations, parameters, key management, operational environment and threat model. No anonymity guarantee is absolute.
        </div>
      </div>

    </div>
  `
})
export class DashboardComponent {
  public service = inject(RingforgeService);
  public stats = this.service.stats;

  public samplePsnHealth = '';
  public samplePsnFin = '';
  public dpNoisyValue: number | null = null;
  public dpEpsilon: number | null = null;

  public goToTab(tab: TabType) {
    this.service.activeTab.set(tab);
  }

  public async testRingSignature() {
    this.service.notify('Executing Ring Signature on ring-financial-audit-2026...', 'info');
    try {
      const res = await this.service.signRing('ring-financial-audit-2026', 'AUDIT_REPORT_HASH_2026');
      this.service.notify(`Ring signature verified! Anonymity set: ${res.anonymitySetSize} members. Signer identity protected.`, 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Ring signature failed: ' + msg, 'error');
    }
  }

  public async testPseudonyms() {
    try {
      const res1 = await this.service.derivePseudonym('USER-94821', 'healthcare');
      const res2 = await this.service.derivePseudonym('USER-94821', 'financial');
      this.samplePsnHealth = res1.pseudonymFormatted;
      this.samplePsnFin = res2.pseudonymFormatted;
      this.service.notify('Derived domain-separated pseudonyms. Cryptographically independent.', 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Pseudonym error: ' + msg, 'error');
    }
  }

  public async testDpQuery() {
    try {
      const res = await this.service.executeDpQuery('dataset-consumer-research', 'COUNT', 1.0, 1e-5);
      this.dpNoisyValue = res.noisyResult;
      this.dpEpsilon = res.remainingEpsilon;
      this.service.notify(`DP query complete. True: ${res.queryResult}, Noisy: ${res.noisyResult.toFixed(0)}. Noise added: ${res.noiseAdded.toFixed(2)}.`, 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('DP error: ' + msg, 'error');
    }
  }
}
