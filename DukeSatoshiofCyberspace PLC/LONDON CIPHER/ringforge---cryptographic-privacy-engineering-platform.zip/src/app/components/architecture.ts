import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-architecture',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Header -->
      <div class="bg-slate-900/90 border border-slate-800 p-6 rounded-2xl space-y-1">
        <div class="flex items-center gap-2 text-xs font-mono text-emerald-400">
          <mat-icon class="text-sm">account_tree</mat-icon>
          <span>RUST CARGO WORKSPACE MAP</span>
        </div>
        <h1 class="text-xl font-bold text-white">24-Crate Rust Modular Architecture</h1>
        <p class="text-xs text-slate-400 max-w-3xl">
          RINGFORGE is structured as a strict Rust Cargo workspace with separation of cryptographic primitives, memory zeroisation, and policy evaluation.
        </p>
      </div>

      <!-- Crate Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 font-mono text-xs">
        @for (c of crates; track c.name) {
          <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-2 hover:border-slate-700 transition-colors">
            <div class="flex items-center justify-between">
              <span class="text-emerald-400 font-bold">{{ c.name }}</span>
              <span class="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded border border-slate-700">{{ c.version }}</span>
            </div>
            <p class="text-[11px] text-slate-300 font-sans leading-relaxed">{{ c.description }}</p>
            <div class="text-[10px] text-slate-500">Dependencies: {{ c.deps.join(', ') }}</div>
          </div>
        }
      </div>

    </div>
  `
})
export class ArchitectureComponent {
  public crates = [
    { name: 'ringforge-core', version: 'v0.1.0', description: 'Core system traits, error handling, and execution context.', deps: ['thiserror', 'serde'] },
    { name: 'ringforge-types', version: 'v0.1.0', description: 'Strongly-typed domain abstractions (PublicKey, RingSignature, PrivacyBudget).', deps: ['serde'] },
    { name: 'ringforge-crypto', version: 'v0.1.0', description: 'Base cryptographic primitives and CSPRNG abstractions.', deps: ['rand_core', 'zeroize'] },
    { name: 'ringforge-hash', version: 'v0.1.0', description: 'SHA-2, SHA-3, and BLAKE3 cryptographic hash wrappers.', deps: ['sha2', 'blake3'] },
    { name: 'ringforge-kdf', version: 'v0.1.0', description: 'HKDF Key derivation and domain separation engine.', deps: ['hkdf', 'hmac'] },
    { name: 'ringforge-aead', version: 'v0.1.0', description: 'AEAD envelope encryption containers and nonce management.', deps: ['chacha20poly1305'] },
    { name: 'ringforge-signatures', version: 'v0.1.0', description: 'Ed25519 signature scheme bindings and keypair handling.', deps: ['ed25519-dalek'] },
    { name: 'ringforge-ring', version: 'v0.1.0', description: 'Linkable & Unlinkable Spontaneous Ring Signature engine.', deps: ['curve25519-dalek'] },
    { name: 'ringforge-blind', version: 'v0.1.0', description: 'Blind signature protocol for anonymous eligibility tokens.', deps: ['rsa', 'subtle'] },
    { name: 'ringforge-credentials', version: 'v0.1.0', description: 'Anonymous Credentials and ZK predicate proof presentation.', deps: ['bulletproofs'] },
    { name: 'ringforge-pseudonyms', version: 'v0.1.0', description: 'HKDF domain-separated pseudonym issuer.', deps: ['hkdf', 'sha2'] },
    { name: 'ringforge-commitments', version: 'v0.1.0', description: 'Pedersen and SHA-256 blinding commitment schemes.', deps: ['curve25519-dalek'] },
    { name: 'ringforge-zk', version: 'v0.1.0', description: 'Zero-knowledge proof interface and statement verifier.', deps: ['ark-works'] },
    { name: 'ringforge-threshold', version: 'v0.1.0', description: 'Shamir 3-of-5 threshold key recovery and release vault.', deps: ['subtle'] },
    { name: 'ringforge-aggregation', version: 'v0.1.0', description: 'Secure multiparty aggregation with minimum group rules.', deps: ['tokio'] },
    { name: 'ringforge-differential-privacy', version: 'v0.1.0', description: 'Laplace and Gaussian differential privacy noise mechanisms.', deps: ['statrs'] },
    { name: 'ringforge-data', version: 'v0.1.0', description: 'Dataset minimisation, generalisation, and k-anonymity analysis.', deps: ['polars'] },
    { name: 'ringforge-policy', version: 'v0.1.0', description: 'Declarative YAML privacy policy compiler.', deps: ['serde_yaml'] },
    { name: 'ringforge-provenance', version: 'v0.1.0', description: 'Cryptographic data provenance chain builder.', deps: ['sha2'] },
    { name: 'ringforge-audit', version: 'v0.1.0', description: 'Tamper-evident SHA256 hash-chain audit ledger.', deps: ['chrono'] },
    { name: 'ringforge-storage', version: 'v0.1.0', description: 'Secure memory vault with zeroize-on-drop protection.', deps: ['zeroize'] },
    { name: 'ringforge-api', version: 'v0.1.0', description: 'REST and gRPC OpenAPI server interface.', deps: ['axum'] },
    { name: 'ringforge-cli', version: 'v0.1.0', description: 'Command-line interface runner for RINGFORGE.', deps: ['clap'] },
    { name: 'ringforge-test', version: 'v0.1.0', description: 'Test vectors, property tests, and synthetic benchmarks.', deps: ['proptest'] }
  ];
}
