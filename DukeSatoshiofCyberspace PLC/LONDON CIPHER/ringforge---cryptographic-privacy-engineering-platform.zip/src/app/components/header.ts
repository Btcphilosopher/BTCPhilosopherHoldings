import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RingforgeService, TabType } from '../services/ringforge';

export interface TabConfig {
  id: TabType;
  label: string;
  icon: string;
}

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="sticky top-0 z-50 bg-[#0b0f17]/95 backdrop-blur-md border-b border-slate-800 px-4 lg:px-8 py-3">
      <div class="max-w-7xl mx-auto flex items-center justify-between gap-4">
        
        <!-- Zone 1: Single element wordmark -->
        <a 
          tabindex="0"
          (click)="selectTab('dashboard')"
          (keyup.enter)="selectTab('dashboard')"
          class="flex items-center gap-2.5 cursor-pointer text-slate-100 hover:text-emerald-400 transition-colors shrink-0 group"
        >
          <div class="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:border-emerald-400/60 transition-colors">
            <mat-icon class="text-xl">shield</mat-icon>
          </div>
          <div class="flex flex-col">
            <span class="text-base font-bold tracking-wider font-mono uppercase text-slate-100">RINGFORGE</span>
            <span class="text-[10px] font-mono text-slate-400 -mt-1 tracking-tight">PRIVACY LABS</span>
          </div>
        </a>

        <!-- Zone 2: Navigation Links -->
        <nav class="hidden lg:flex items-center gap-1 overflow-x-auto py-1 scrollbar-none text-xs font-medium">
          @for (tab of tabs; track tab.id) {
            <button
              (click)="selectTab(tab.id)"
              class="px-3 py-1.5 rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5"
              [class.bg-slate-800]="service.activeTab() === tab.id"
              [class.text-emerald-400]="service.activeTab() === tab.id"
              [class.text-slate-400]="service.activeTab() !== tab.id"
              [class.hover:text-slate-200]="service.activeTab() !== tab.id"
            >
              <mat-icon class="text-sm shrink-0">{{ tab.icon }}</mat-icon>
              <span>{{ tab.label }}</span>
            </button>
          }
        </nav>

        <!-- Zone 3: Primary Actions -->
        <div class="flex items-center gap-2 shrink-0">
          <button
            (click)="selectTab('cli')"
            class="px-3 py-1.5 rounded-md text-xs font-mono bg-slate-800 border border-slate-700 hover:border-slate-600 text-slate-200 transition-colors flex items-center gap-1.5"
            title="Open Interactive Browser CLI"
          >
            <mat-icon class="text-sm text-emerald-400">terminal</mat-icon>
            <span class="hidden sm:inline">CLI</span>
          </button>

          <button
            (click)="runDemoPipeline()"
            class="px-3.5 py-1.5 rounded-md text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors flex items-center gap-1.5 shadow-sm shadow-emerald-950/50"
          >
            <mat-icon class="text-sm">play_arrow</mat-icon>
            <span>Run Pipeline</span>
          </button>
        </div>

      </div>

      <!-- Mobile Tab Row -->
      <div class="lg:hidden flex items-center gap-1 overflow-x-auto pt-2 pb-1 border-t border-slate-800/80 mt-2 scrollbar-none text-xs">
        @for (tab of tabs; track tab.id) {
          <button
            (click)="selectTab(tab.id)"
            class="px-2.5 py-1 rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center gap-1 text-[11px]"
            [class.bg-slate-800]="service.activeTab() === tab.id"
            [class.text-emerald-400]="service.activeTab() === tab.id"
            [class.text-slate-400]="service.activeTab() !== tab.id"
          >
            <mat-icon class="text-xs">{{ tab.icon }}</mat-icon>
            <span>{{ tab.label }}</span>
          </button>
        }
      </div>
    </header>
  `
})
export class HeaderComponent {
  public service = inject(RingforgeService);

  public tabs: TabConfig[] = [
    { id: 'dashboard', label: 'Dashboard', icon: 'space_dashboard' },
    { id: 'rings', label: 'Ring Signatures', icon: 'all_inclusive' },
    { id: 'pseudonyms', label: 'Pseudonyms', icon: 'fingerprint' },
    { id: 'credentials', label: 'Credentials', icon: 'badge' },
    { id: 'commitments', label: 'Commitments & Blind', icon: 'lock' },
    { id: 'minimisation', label: 'Data Minimisation', icon: 'filter_alt' },
    { id: 'differential-privacy', label: 'Differential Privacy', icon: 'insights' },
    { id: 'keys', label: 'Key Lifecycle', icon: 'key' },
    { id: 'release-audit', label: 'Release & Audit', icon: 'verified' },
    { id: 'architecture', label: 'Rust Architecture', icon: 'account_tree' }
  ];

  public selectTab(tab: TabType) {
    this.service.activeTab.set(tab);
  }

  public async runDemoPipeline() {
    this.service.activeTab.set('minimisation');
    this.service.notify('Executing 1,000,000 synthetic record anonymisation pipeline...', 'info');
    try {
      await this.service.runMinimisationPipeline('');
      this.service.notify('Pipeline executed: 1,000,000 records processed. k-Anonymity k=24.', 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Pipeline error: ' + msg, 'error');
    }
  }
}
