import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RingforgeService, RingItem, RingSignResponse } from '../services/ringforge';

@Component({
  selector: 'app-ring-signatures',
  imports: [CommonModule, FormsModule, ReactiveFormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 p-6 rounded-2xl">
        <div class="space-y-1">
          <div class="flex items-center gap-2 text-xs font-mono text-emerald-400">
            <mat-icon class="text-sm">all_inclusive</mat-icon>
            <span>CRYPTOGRAPHIC PRIMITIVE #1</span>
          </div>
          <h1 class="text-xl font-bold text-white">Ring Signatures Engine</h1>
          <p class="text-xs text-slate-400 max-w-2xl">
            A ring signature allows any member of an authorized public key set to prove signature validity without disclosing their individual identity.
          </p>
        </div>

        <button
          (click)="showCreateModal.set(true)"
          class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 shrink-0"
        >
          <mat-icon class="text-sm">add_circle</mat-icon>
          <span>Create New Ring Set</span>
        </button>
      </div>

      <!-- Ring Selector & Active Ring Details Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Left: List of Rings -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div class="flex items-center justify-between">
            <h2 class="text-sm font-semibold text-white">Active Ring Sets</h2>
            <span class="text-xs font-mono text-slate-400">{{ rings().length }} Registered</span>
          </div>

          <div class="space-y-2">
            @for (ring of rings(); track ring.id) {
              <div
                tabindex="0"
                (click)="selectedRing.set(ring)"
                (keyup.enter)="selectedRing.set(ring)"
                class="p-3.5 rounded-xl border transition-all cursor-pointer space-y-2"
                [class.bg-slate-800]="selectedRing()?.id === ring.id"
                [class.border-emerald-500]="selectedRing()?.id === ring.id"
                [class.bg-slate-950]="selectedRing()?.id !== ring.id"
                [class.border-slate-800]="selectedRing()?.id !== ring.id"
              >
                <div class="flex items-center justify-between">
                  <span class="text-xs font-bold text-white">{{ ring.name }}</span>
                  <span class="text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded">
                    {{ ring.status }}
                  </span>
                </div>

                <div class="text-[11px] font-mono text-slate-400 space-y-0.5">
                  <div>ID: <span class="text-slate-300">{{ ring.id }}</span></div>
                  <div>Members: <span class="text-emerald-400 font-bold">{{ ring.members.length }} Authorized Keys</span></div>
                  <div>Algorithm: <span class="text-slate-300">{{ ring.algorithm }}</span></div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Right: Active Ring Policy & Operations Studio -->
        <div class="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-6">
          @if (selectedRing(); as ring) {
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
              <div>
                <h2 class="text-lg font-bold text-white">{{ ring.name }}</h2>
                <div class="text-xs text-slate-400 font-mono">Purpose: {{ ring.purpose }}</div>
              </div>

              <div class="flex items-center gap-2">
                <span class="text-xs font-mono bg-slate-800 text-slate-300 px-3 py-1 rounded-lg border border-slate-700">
                  Signatures Produced: {{ ring.signatureCount }}
                </span>
              </div>
            </div>

            <!-- Ring Policy & Anonymity Analysis Box -->
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3 font-mono text-xs">
              <div class="text-emerald-400 font-semibold uppercase tracking-wider flex items-center justify-between">
                <span>ANONYMITY SET & POLICY ASSESSMENT</span>
                <span class="text-[10px] text-slate-400">RST-Ed25519</span>
              </div>

              <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px]">
                <div class="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                  <div class="text-slate-400">Members</div>
                  <div class="text-base font-bold text-white">{{ ring.members.length }}</div>
                </div>

                <div class="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                  <div class="text-slate-400">Effective Anonymity</div>
                  <div class="text-base font-bold text-emerald-400">{{ ring.members.length }} / {{ ring.members.length }}</div>
                </div>

                <div class="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                  <div class="text-slate-400">Signer Identity Disclosed?</div>
                  <div class="text-base font-bold text-emerald-400">NO (100% Protected)</div>
                </div>

                <div class="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                  <div class="text-slate-400">Linkability</div>
                  <div class="text-base font-bold text-cyan-400">UNLINKABLE</div>
                </div>
              </div>

              <div class="text-[11px] text-slate-400 space-y-1 pt-1">
                <div>• Minimum Security Level: <span class="text-slate-200">256-bit elliptic curve security</span></div>
                <div>• Validity Period: <span class="text-slate-200">{{ ring.validFrom | date:'mediumDate' }} &rarr; {{ ring.validUntil | date:'mediumDate' }}</span></div>
                <div>• Revocation Policy: <span class="text-slate-200">Immediate removal on key compromise detection</span></div>
              </div>
            </div>

            <!-- Signing Studio Form -->
            <div class="space-y-4 border-t border-slate-800 pt-4">
              <h3 class="text-sm font-semibold text-white flex items-center gap-2">
                <mat-icon class="text-emerald-400 text-base">create</mat-icon>
                <span>Produce Ring Signature for Payload</span>
              </h3>

              <div class="space-y-3">
                <div>
                  <label for="msg-payload" class="block text-xs font-mono text-slate-400 mb-1">Message Payload to Sign</label>
                  <input
                    id="msg-payload"
                    type="text"
                    [formControl]="messageControl"
                    placeholder="e.g. AUDIT_REPORT_HASH_2026_APPROVED"
                    class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs font-mono text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                <div class="flex items-center gap-3">
                  <button
                    (click)="signSelectedRing()"
                    [disabled]="messageControl.invalid"
                    class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2"
                  >
                    <mat-icon class="text-sm">fingerprint</mat-icon>
                    <span>Sign as Anonymous Member</span>
                  </button>
                </div>
              </div>

              <!-- Signature Output Display -->
              @if (signatureResult(); as sig) {
                <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3 font-mono text-xs">
                  <div class="flex items-center justify-between text-emerald-400 font-semibold">
                    <span>GENERATED RING SIGNATURE</span>
                    <span class="text-[10px] bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded">&check; VERIFIED VALID</span>
                  </div>

                  <div class="space-y-1.5 text-[11px] text-slate-300 overflow-x-auto">
                    <div>Message Hash: <span class="text-white">{{ sig.messageHash }}</span></div>
                    <div>Key Image (Tag): <span class="text-cyan-400">{{ sig.keyImageHex }}</span></div>
                    <div>Signature Hex: <span class="text-emerald-400 break-all">{{ sig.signatureHex }}</span></div>
                    <div>Anonymity Set: <span class="text-white font-bold">{{ sig.anonymitySetSize }} members</span></div>
                    <div>Disclosed Signer: <span class="text-emerald-400">FALSE (Identical likelihood across all members)</span></div>
                  </div>

                  <div class="pt-2 flex justify-end">
                    <button
                      (click)="verifySignature(sig)"
                      class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs text-emerald-400 border border-slate-700 rounded-md transition-colors flex items-center gap-1.5"
                    >
                      <mat-icon class="text-xs">verified</mat-icon>
                      <span>Run Verification Suite</span>
                    </button>
                  </div>
                </div>
              }
            </div>
          }
        </div>
      </div>

      <!-- Create Ring Modal -->
      @if (showCreateModal()) {
        <div class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full space-y-4">
            <div class="flex items-center justify-between">
              <h3 class="text-base font-bold text-white">Create New Ring Set</h3>
              <button (click)="showCreateModal.set(false)" class="text-slate-400 hover:text-white">
                <mat-icon>close</mat-icon>
              </button>
            </div>

            <form [formGroup]="createForm" (ngSubmit)="submitCreateRing()" class="space-y-3">
              <div>
                <label for="ring-name" class="block text-xs font-mono text-slate-400 mb-1">Ring Name</label>
                <input
                  id="ring-name"
                  type="text"
                  formControlName="name"
                  placeholder="e.g. Executive Governance Council"
                  class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label for="ring-purpose" class="block text-xs font-mono text-slate-400 mb-1">Purpose / Authorized Scope</label>
                <textarea
                  id="ring-purpose"
                  formControlName="purpose"
                  rows="2"
                  placeholder="e.g. Critical budget release authentication"
                  class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white focus:border-emerald-500 focus:outline-none"
                ></textarea>
              </div>

              <div>
                <label for="member-count" class="block text-xs font-mono text-slate-400 mb-1">Member Count (Simulated Keys)</label>
                <input
                  id="member-count"
                  type="number"
                  formControlName="memberCount"
                  min="4"
                  max="256"
                  class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-white focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div class="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  (click)="showCreateModal.set(false)"
                  class="px-4 py-2 bg-slate-800 text-slate-300 text-xs rounded-lg hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  [disabled]="createForm.invalid"
                  class="px-4 py-2 bg-emerald-600 text-white text-xs font-semibold rounded-lg hover:bg-emerald-500 disabled:opacity-50"
                >
                  Create Ring
                </button>
              </div>
            </form>
          </div>
        </div>
      }

    </div>
  `
})
export class RingSignaturesComponent {
  public service = inject(RingforgeService);
  private fb = inject(FormBuilder);

  public rings = this.service.rings;
  public selectedRing = signal<RingItem | null>(null);
  public showCreateModal = signal<boolean>(false);
  public signatureResult = signal<RingSignResponse | null>(null);

  public messageControl = this.fb.control('AUDIT_REPORT_HASH_2026_APPROVED', [Validators.required]);

  public createForm = this.fb.group({
    name: ['Executive Research Board', [Validators.required]],
    purpose: ['Authorization of clinical trial release dataset', [Validators.required]],
    memberCount: [16, [Validators.required, Validators.min(4)]]
  });

  constructor() {
    if (this.rings().length > 0) {
      this.selectedRing.set(this.rings()[0]);
    }
  }

  public async signSelectedRing() {
    const ring = this.selectedRing();
    if (!ring || !this.messageControl.value) return;

    this.service.notify('Generating Spontaneous Ring Signature...', 'info');
    try {
      const res = await this.service.signRing(ring.id, this.messageControl.value);
      this.signatureResult.set(res);
      this.service.notify(`Ring signature produced for "${this.messageControl.value}". Anonymity set: ${res.anonymitySetSize} members.`, 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Signing failed: ' + msg, 'error');
    }
  }

  public async verifySignature(sig: RingSignResponse) {
    const ring = this.selectedRing();
    if (!ring) return;

    try {
      const res = await this.service.verifyRingSignature(ring.id, this.messageControl.value || '', sig.signatureHex, sig.keyImageHex);
      if (res.verified) {
        this.service.notify(`VERIFICATION SUCCESSFUL: ${res.details}`, 'success');
      } else {
        this.service.notify('VERIFICATION FAILED: Invalid signature.', 'error');
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Verification error: ' + msg, 'error');
    }
  }

  public async submitCreateRing() {
    if (this.createForm.invalid) return;

    const val = this.createForm.value;
    const count = val.memberCount || 16;
    const members: string[] = [];
    for (let i = 1; i <= count; i++) {
      members.push(`key-sim-${i}`);
    }

    try {
      const res = await this.service.createRing(val.name!, members, val.purpose!);
      this.showCreateModal.set(false);
      this.selectedRing.set(res.ring);
      this.service.notify(`Created new ring "${val.name}" with ${count} member keys.`, 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Create ring failed: ' + msg, 'error');
    }
  }
}
