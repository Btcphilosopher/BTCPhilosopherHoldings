import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RingforgeService } from '../services/ringforge';

export interface CliHistoryItem {
  command: string;
  output: string;
}

@Component({
  selector: 'app-cli-terminal',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4">
      
      <!-- Terminal Header -->
      <div class="flex items-center justify-between bg-slate-900 border border-slate-800 p-4 rounded-xl">
        <div class="flex items-center gap-2 font-mono text-xs text-slate-300">
          <mat-icon class="text-emerald-400 text-sm">terminal</mat-icon>
          <span class="font-bold text-white">RINGFORGE CLI v0.1.0</span>
          <span class="text-slate-500">|</span>
          <span class="text-emerald-400">RUST INTERACTIVE CONSOLE</span>
        </div>

        <div class="flex items-center gap-2 text-xs">
          <button
            (click)="clearTerminal()"
            class="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded font-mono text-[11px]"
          >
            Clear
          </button>
        </div>
      </div>

      <!-- Quick Command Pills -->
      <div class="flex flex-wrap items-center gap-2 text-xs font-mono">
        <span class="text-slate-500">Quick Commands:</span>
        @for (cmd of quickCmds; track cmd) {
          <button
            (click)="runQuickCmd(cmd)"
            class="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-emerald-400 border border-slate-800 rounded transition-colors text-[11px]"
          >
            {{ cmd }}
          </button>
        }
      </div>

      <!-- Terminal Output Screen -->
      <div class="bg-black/95 border border-slate-800 rounded-2xl p-4 lg:p-6 font-mono text-xs text-slate-200 min-h-[420px] max-h-[550px] overflow-y-auto space-y-4 shadow-2xl">
        
        <div class="text-slate-500 text-[11px]">
          RINGFORGE CLI Terminal v0.1.0 [x86_64-unknown-linux-gnu]<br/>
          Type 'ringforge help' or click a command above to execute.<br/>
          -------------------------------------------------------------
        </div>

        @for (entry of history(); track $index) {
          <div class="space-y-1.5">
            <div class="flex items-center gap-2 text-emerald-400 font-bold">
              <span class="text-slate-500">user&#64;ringforge-lab:~$</span>
              <span>{{ entry.command }}</span>
            </div>
            <pre class="bg-slate-950 p-3 rounded-lg border border-slate-900 text-slate-300 whitespace-pre-wrap overflow-x-auto text-[11px] leading-relaxed">{{ entry.output }}</pre>
          </div>
        }

        <!-- Active Command Input Line -->
        <div class="flex items-center gap-2 pt-2">
          <span class="text-emerald-400 font-bold shrink-0">user&#64;ringforge-lab:~$</span>
          <input
            type="text"
            [(ngModel)]="currentCommand"
            (keydown.enter)="executeCommand()"
            placeholder="ringforge ring sign --id ring-financial-audit-2026"
            class="w-full bg-transparent border-none text-emerald-300 font-mono text-xs focus:outline-none focus:ring-0"
          />
        </div>

      </div>

    </div>
  `
})
export class CliTerminalComponent {
  public service = inject(RingforgeService);

  public currentCommand = '';
  public history = signal<CliHistoryItem[]>([
    {
      command: 'ringforge help',
      output: `RINGFORGE CLI v0.1.0 - Cryptographic Data Anonymisation Platform

USAGE:
    ringforge <SUBCOMMAND>

SUBCOMMANDS:
    key generate         Generate new cryptographic keypair
    key rotate           Rotate key version
    ring create          Create a new anonymous ring signature set
    ring sign            Produce linkable/unlinkable ring signature
    ring verify          Verify ring signature membership
    pseudonym issue      Derive domain-separated HKDF pseudonym
    credential issue     Issue anonymous credential
    dataset minimise     Execute policy-driven data minimisation pipeline
    privacy analyse      Evaluate differential privacy budget & noise
    audit verify         Validate tamper-evident hash chain ledger`
    }
  ]);

  public quickCmds = [
    'ringforge key generate',
    'ringforge ring sign',
    'ringforge pseudonym issue',
    'ringforge dataset minimise',
    'ringforge audit verify'
  ];

  public async executeCommand() {
    const cmd = this.currentCommand.trim();
    if (!cmd) return;

    this.currentCommand = '';
    try {
      const res = await this.service.execCli(cmd);
      this.history.update(h => [...h, { command: cmd, output: res.output }]);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.history.update(h => [...h, { command: cmd, output: 'Error: ' + msg }]);
    }
  }

  public runQuickCmd(cmd: string) {
    this.currentCommand = cmd;
    this.executeCommand();
  }

  public clearTerminal() {
    this.history.set([]);
  }
}
