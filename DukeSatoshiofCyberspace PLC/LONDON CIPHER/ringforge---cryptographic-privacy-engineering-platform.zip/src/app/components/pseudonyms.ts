import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RingforgeService, PseudonymResponse } from '../services/ringforge';

@Component({
  selector: 'app-pseudonyms',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Header -->
      <div class="bg-slate-900/90 border border-slate-800 p-6 rounded-2xl space-y-1">
        <div class="flex items-center gap-2 text-xs font-mono text-cyan-400">
          <mat-icon class="text-sm">fingerprint</mat-icon>
          <span>CRYPTOGRAPHIC PRIMITIVE #2</span>
        </div>
        <h1 class="text-xl font-bold text-white">Unlinkable Domain Pseudonyms & HKDF Separation</h1>
        <p class="text-xs text-slate-400 max-w-3xl">
          The same individual receives cryptographically independent pseudonyms across authorized analytical domains. Cross-domain correlation is computationally infeasible without the domain key.
        </p>
      </div>

      <!-- Generator Studio -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Input Form -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 class="text-sm font-semibold text-white">Derivation Parameters</h2>

          <div class="space-y-3">
            <div>
              <label for="master-identity" class="block text-xs font-mono text-slate-400 mb-1">Real Subject Identity (Vault Isolated)</label>
              <input
                id="master-identity"
                type="text"
                [(ngModel)]="masterIdentity"
                placeholder="e.g. USER-9482-NHS-UK"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs font-mono text-white focus:border-cyan-500 focus:outline-none"
              />
            </div>

            <div>
              <label for="derivation-method" class="block text-xs font-mono text-slate-400 mb-1">HKDF Derivation Method</label>
              <div id="derivation-method" class="bg-slate-950 border border-slate-800 rounded-lg p-2.5 font-mono text-[11px] text-slate-300">
                HKDF-Expand(PRK, "RINGFORGE-PSEUDONYM-V1-DOMAIN:" + Domain)
              </div>
            </div>

            <button
              (click)="deriveAllDomains()"
              class="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm"
            >
              <mat-icon class="text-sm">shuffle</mat-icon>
              <span>Derive Domain Pseudonyms</span>
            </button>
          </div>
        </div>

        <!-- Right: Derived Pseudonyms Matrix -->
        <div class="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 class="text-sm font-semibold text-white">Derived Analytical Domain Pseudonyms</h2>
            <span class="text-xs font-mono text-cyan-400 bg-cyan-500/10 border border-cyan-500/30 px-2.5 py-1 rounded">
              UNLINKABLE DOMAINS
            </span>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            <!-- Healthcare -->
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
              <div class="flex items-center justify-between text-xs font-semibold text-slate-200">
                <span class="flex items-center gap-1.5 text-emerald-400">
                  <mat-icon class="text-sm">medical_services</mat-icon>
                  Healthcare Domain
                </span>
                <span class="text-[10px] font-mono text-slate-500">Domain: healthcare</span>
              </div>
              <div class="font-mono text-xs text-emerald-300 bg-slate-900 p-2.5 rounded-lg border border-slate-800 break-all select-all">
                {{ pseudonyms()['healthcare']?.pseudonymFormatted || 'psn_hea_8f9a2b1c4e' }}
              </div>
              <p class="text-[11px] text-slate-400">Used strictly for clinical research and patient trials.</p>
            </div>

            <!-- Research -->
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
              <div class="flex items-center justify-between text-xs font-semibold text-slate-200">
                <span class="flex items-center gap-1.5 text-purple-400">
                  <mat-icon class="text-sm">science</mat-icon>
                  Epidemiology Research
                </span>
                <span class="text-[10px] font-mono text-slate-500">Domain: research</span>
              </div>
              <div class="font-mono text-xs text-purple-300 bg-slate-900 p-2.5 rounded-lg border border-slate-800 break-all select-all">
                {{ pseudonyms()['research']?.pseudonymFormatted || 'psn_res_1a2b3c4d5e' }}
              </div>
              <p class="text-[11px] text-slate-400">Used for population-wide genomic studies.</p>
            </div>

            <!-- Financial Risk -->
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
              <div class="flex items-center justify-between text-xs font-semibold text-slate-200">
                <span class="flex items-center gap-1.5 text-amber-400">
                  <mat-icon class="text-sm">account_balance</mat-icon>
                  Financial Risk Panel
                </span>
                <span class="text-[10px] font-mono text-slate-500">Domain: financial-risk</span>
              </div>
              <div class="font-mono text-xs text-amber-300 bg-slate-900 p-2.5 rounded-lg border border-slate-800 break-all select-all">
                {{ pseudonyms()['financial-risk']?.pseudonymFormatted || 'psn_fin_9x8y7z6w5v' }}
              </div>
              <p class="text-[11px] text-slate-400">Used for credit and solvency risk modelling.</p>
            </div>

            <!-- National Statistics -->
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
              <div class="flex items-center justify-between text-xs font-semibold text-slate-200">
                <span class="flex items-center gap-1.5 text-blue-400">
                  <mat-icon class="text-sm">bar_chart</mat-icon>
                  National Statistics
                </span>
                <span class="text-[10px] font-mono text-slate-500">Domain: statistics</span>
              </div>
              <div class="font-mono text-xs text-blue-300 bg-slate-900 p-2.5 rounded-lg border border-slate-800 break-all select-all">
                {{ pseudonyms()['statistics']?.pseudonymFormatted || 'psn_sta_3m4n5o6p7q' }}
              </div>
              <p class="text-[11px] text-slate-400">Used for Census and macroeconomic aggregation.</p>
            </div>

          </div>

          <div class="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl font-mono text-xs text-slate-300 space-y-1">
            <div class="text-emerald-400 font-semibold">&check; DOMAIN INDEPENDENCE PROOF</div>
            <p class="text-[11px] text-slate-400">
              Correlating <span class="text-white">Healthcare</span> with <span class="text-white">Financial Risk</span> without authorization requires reversing HMAC-SHA256 without domain secret key Kd. Reidentification complexity: O(2^256).
            </p>
          </div>

        </div>

      </div>

    </div>
  `
})
export class PseudonymsComponent {
  public service = inject(RingforgeService);
  public masterIdentity = 'USER-9482-NHS-UK';

  public pseudonyms = signal<Record<string, PseudonymResponse>>({});

  constructor() {
    this.deriveAllDomains();
  }

  public async deriveAllDomains() {
    const domains = ['healthcare', 'research', 'financial-risk', 'statistics'];
    const results: Record<string, PseudonymResponse> = {};

    for (const d of domains) {
      try {
        const res = await this.service.derivePseudonym(this.masterIdentity, d);
        results[d] = res;
      } catch (err) {
        console.error('Pseudonym derivation error:', err);
      }
    }

    this.pseudonyms.set(results);
    this.service.notify(`Derived 4 domain pseudonyms for "${this.masterIdentity}". Zero cross-domain correlation.`, 'success');
  }
}
