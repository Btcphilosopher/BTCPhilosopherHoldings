import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RingforgeService } from '../services/ringforge';

@Component({
  selector: 'app-release-audit',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Header -->
      <div class="bg-slate-900/90 border border-slate-800 p-6 rounded-2xl space-y-1">
        <div class="flex items-center gap-2 text-xs font-mono text-emerald-400">
          <mat-icon class="text-sm">verified</mat-icon>
          <span>DATA RELEASE GATE & TAMPER-EVIDENT AUDIT LEDGER</span>
        </div>
        <h1 class="text-xl font-bold text-white">Release Gate & Hash Chain Audit Ledger</h1>
        <p class="text-xs text-slate-400 max-w-3xl">
          Automated multi-check release gate evaluation and SHA256 hash-chained audit ledger ensuring absolute tamper evidence across every privacy transformation.
        </p>
      </div>

      <!-- Release Gate Workflow & Provenance -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 class="text-sm font-semibold text-white">Cryptographic Release Gate Checks</h2>
          <button
            (click)="verifyAuditChain()"
            class="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5"
          >
            <mat-icon class="text-sm">verified_user</mat-icon>
            <span>Verify Audit Chain Integrity</span>
          </button>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-6 gap-3 font-mono text-xs">
          <div class="bg-slate-950 p-3 rounded-xl border border-emerald-500/30 text-emerald-400">
            <div class="text-slate-400 text-[10px]">1. POLICY CHECK</div>
            <div class="font-bold">&check; PASSED</div>
          </div>

          <div class="bg-slate-950 p-3 rounded-xl border border-emerald-500/30 text-emerald-400">
            <div class="text-slate-400 text-[10px]">2. PRIVACY RISK</div>
            <div class="font-bold">&check; LOW (k=24)</div>
          </div>

          <div class="bg-slate-950 p-3 rounded-xl border border-emerald-500/30 text-emerald-400">
            <div class="text-slate-400 text-[10px]">3. MIN COHORT</div>
            <div class="font-bold">&check; 500 RECS</div>
          </div>

          <div class="bg-slate-950 p-3 rounded-xl border border-emerald-500/30 text-emerald-400">
            <div class="text-slate-400 text-[10px]">4. DP BOUNDS</div>
            <div class="font-bold">&check; &epsilon;=1.5</div>
          </div>

          <div class="bg-slate-950 p-3 rounded-xl border border-emerald-500/30 text-emerald-400">
            <div class="text-slate-400 text-[10px]">5. PROVENANCE</div>
            <div class="font-bold">&check; CHAINED</div>
          </div>

          <div class="bg-slate-950 p-3 rounded-xl border border-emerald-500/30 bg-emerald-950/20 text-emerald-300">
            <div class="text-emerald-400 text-[10px]">6. GATE STATUS</div>
            <div class="font-bold">&check; RELEASED</div>
          </div>
        </div>
      </div>

      <!-- Audit Ledger Log Chain Table -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div class="flex items-center justify-between">
          <h2 class="text-sm font-semibold text-white">SHA256 Hash Chain Audit Ledger</h2>
          <span class="text-xs font-mono text-slate-400">{{ auditLogs().length }} Blocks Depth</span>
        </div>

        <div class="overflow-x-auto bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-[11px]">
          <table class="w-full text-left text-slate-300">
            <thead>
              <tr class="text-slate-500 border-b border-slate-800">
                <th class="py-2 px-2">INDEX</th>
                <th class="py-2 px-2">TIMESTAMP</th>
                <th class="py-2 px-2">ACTION</th>
                <th class="py-2 px-2">ACTOR REF</th>
                <th class="py-2 px-2">PREVIOUS HASH</th>
                <th class="py-2 px-2">EVENT HASH</th>
              </tr>
            </thead>
            <tbody>
              @for (log of auditLogs(); track log.index) {
                <tr class="border-b border-slate-900 hover:bg-slate-900/50">
                  <td class="py-2 px-2 text-emerald-400 font-bold">#{{ log.index }}</td>
                  <td class="py-2 px-2 text-slate-400">{{ log.timestamp | date:'HH:mm:ss' }}</td>
                  <td class="py-2 px-2 text-white font-bold">{{ log.action }}</td>
                  <td class="py-2 px-2 text-slate-300">{{ log.actorReference }}</td>
                  <td class="py-2 px-2 text-slate-500 font-mono">{{ log.previousHash.substring(0, 12) }}...</td>
                  <td class="py-2 px-2 text-cyan-400 font-mono">{{ log.eventHash.substring(0, 12) }}...</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `
})
export class ReleaseAuditComponent {
  public service = inject(RingforgeService);
  public auditLogs = this.service.auditChain;

  public async verifyAuditChain() {
    try {
      const res = await this.service.verifyAuditChain();
      if (res.valid) {
        this.service.notify(`HASH CHAIN INTEGRITY VERIFIED: All ${res.totalEntries} blocks match tamper-free SHA256 hashes.`, 'success');
      } else {
        const idx = res.brokenIndex !== undefined ? res.brokenIndex : '?';
        this.service.notify(`AUDIT FAILURE: Tampering detected at block #${idx}`, 'error');
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Verification error: ' + msg, 'error');
    }
  }
}
