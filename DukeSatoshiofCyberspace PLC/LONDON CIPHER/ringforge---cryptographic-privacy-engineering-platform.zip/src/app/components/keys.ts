import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RingforgeService } from '../services/ringforge';

@Component({
  selector: 'app-keys',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Header -->
      <div class="bg-slate-900/90 border border-slate-800 p-6 rounded-2xl space-y-1">
        <div class="flex items-center gap-2 text-xs font-mono text-amber-400">
          <mat-icon class="text-sm">key</mat-icon>
          <span>KEY MANAGEMENT SERVICE (KMS) & THRESHOLD VAULT</span>
        </div>
        <h1 class="text-xl font-bold text-white">Cryptographic Key Lifecycle & 3-of-5 Custodianship</h1>
        <p class="text-xs text-slate-400 max-w-3xl">
          Key generation, versioning, rotation policies, and Shamir/threshold 3-of-5 key release custodianship preventing single-administrator master key compromise.
        </p>
      </div>

      <!-- Threshold Custodians Banner -->
      <div class="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-3 font-mono text-xs">
        <div class="flex items-center justify-between text-amber-400 font-bold uppercase">
          <span class="flex items-center gap-1.5">
            <mat-icon class="text-sm">groups</mat-icon>
            INSTITUTIONAL THRESHOLD VAULT (3-OF-5 REQUIRED)
          </span>
          <span class="text-[10px] bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded text-amber-300">
            3 CUSTODIAN QUORUM
          </span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-5 gap-3 text-[11px]">
          @for (c of custodians; track c.keyId) {
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-1">
              <div class="flex items-center justify-between text-slate-400">
                <span>{{ c.role }}</span>
                @if (c.signed) {
                  <mat-icon class="text-xs text-emerald-400">check_circle</mat-icon>
                }
              </div>
              <div class="text-white font-bold">{{ c.name }}</div>
              <div class="text-[10px] text-slate-500">Key: {{ c.keyId }}</div>
            </div>
          }
        </div>
      </div>

      <!-- Keys Table -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div class="flex items-center justify-between">
          <h2 class="text-sm font-semibold text-white">Cryptographic Key Inventory</h2>

          <div class="flex items-center gap-2">
            <button
              (click)="generateNewKey()"
              class="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5"
            >
              <mat-icon class="text-sm">add</mat-icon>
              <span>Generate Key</span>
            </button>
          </div>
        </div>

        <div class="overflow-x-auto bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-[11px]">
          <table class="w-full text-left text-slate-300">
            <thead>
              <tr class="text-slate-500 border-b border-slate-800">
                <th class="py-2 px-2">KEY ID</th>
                <th class="py-2 px-2">OWNER</th>
                <th class="py-2 px-2">PURPOSE</th>
                <th class="py-2 px-2">ALGORITHM</th>
                <th class="py-2 px-2">VERSION</th>
                <th class="py-2 px-2">STATUS</th>
                <th class="py-2 px-2 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              @for (key of keys(); track key.id) {
                <tr class="border-b border-slate-900">
                  <td class="py-2 px-2 text-amber-400 font-bold">{{ key.id }}</td>
                  <td class="py-2 px-2 text-white">{{ key.owner }}</td>
                  <td class="py-2 px-2 text-slate-300">{{ key.purpose }}</td>
                  <td class="py-2 px-2 text-slate-400">{{ key.algorithm }}</td>
                  <td class="py-2 px-2 text-slate-300">v{{ key.version }}</td>
                  <td class="py-2 px-2">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                      [class.bg-emerald-500-10]="key.status === 'active'"
                      [class.text-emerald-400]="key.status === 'active'"
                      [class.bg-amber-500-10]="key.status === 'rotated'"
                      [class.text-amber-400]="key.status === 'rotated'"
                      [class.bg-rose-500-10]="key.status === 'revoked' || key.status === 'expired'"
                      [class.text-rose-400]="key.status === 'revoked' || key.status === 'expired'"
                    >
                      {{ key.status | uppercase }}
                    </span>
                  </td>
                  <td class="py-2 px-2 text-right space-x-1">
                    @if (key.status === 'active') {
                      <button
                        (click)="rotateKey(key.id)"
                        class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded text-[10px]"
                      >
                        Rotate
                      </button>
                    }
                    @if (key.status === 'active') {
                      <button
                        (click)="revokeKey(key.id)"
                        class="px-2 py-1 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 rounded text-[10px]"
                      >
                        Revoke
                      </button>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `
})
export class KeysComponent {
  public service = inject(RingforgeService);
  public keys = this.service.keys;

  public custodians = [
    { name: 'Dr. A. Vance', role: 'Chief Cryptographer', keyId: 'custodian-01', signed: true },
    { name: 'M. Dubois', role: 'Privacy Officer', keyId: 'custodian-02', signed: true },
    { name: 'S. Chen', role: 'Security Auditor', keyId: 'custodian-03', signed: true },
    { name: 'E. Becker', role: 'Governance Trustee', keyId: 'custodian-04', signed: false },
    { name: 'H. Lindqvist', role: 'Data Protection Ombudsman', keyId: 'custodian-05', signed: false }
  ];

  public async generateNewKey() {
    try {
      await this.service.generateKey('Auditor-Analyst', 'signing');
      this.service.notify('Generated new Ed25519 keypair.', 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Key gen error: ' + msg, 'error');
    }
  }

  public async rotateKey(id: string) {
    try {
      await this.service.rotateKey(id);
      this.service.notify(`Rotated key ${id} to next version.`, 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Rotate error: ' + msg, 'error');
    }
  }

  public async revokeKey(id: string) {
    try {
      await this.service.revokeKey(id);
      this.service.notify(`Revoked key ${id}.`, 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Revoke error: ' + msg, 'error');
    }
  }
}
