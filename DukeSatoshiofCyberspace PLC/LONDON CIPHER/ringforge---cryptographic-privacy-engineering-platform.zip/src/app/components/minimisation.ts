import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RingforgeService, MinimisationResponse } from '../services/ringforge';

export interface SampleRecord {
  pseudonym: string;
  age_group: string;
  region: string;
  income_bracket: string;
  diagnosis: string;
  treatment_cost: number;
}

@Component({
  selector: 'app-minimisation',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Header -->
      <div class="bg-slate-900/90 border border-slate-800 p-6 rounded-2xl space-y-1">
        <div class="flex items-center gap-2 text-xs font-mono text-indigo-400">
          <mat-icon class="text-sm">filter_alt</mat-icon>
          <span>DATA MINIMISATION ENGINE & POLICY COMPILER</span>
        </div>
        <h1 class="text-xl font-bold text-white">Policy-Driven Transformation Pipeline</h1>
        <p class="text-xs text-slate-400 max-w-3xl">
          Declarative privacy policies compile into executable transformation pipelines that strip direct identifiers, generalize quasi-identifiers, enforce cohort minimums, and calculate k-anonymity.
        </p>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Left: Declarative YAML Policy Editor -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div class="flex items-center justify-between">
            <h2 class="text-sm font-semibold text-white">Declarative Privacy Policy</h2>
            <button
              (click)="generateAiPolicy()"
              [disabled]="aiLoading()"
              class="px-2.5 py-1 bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 text-xs font-mono rounded flex items-center gap-1.5 transition-colors"
            >
              <mat-icon class="text-xs">auto_awesome</mat-icon>
              <span>{{ aiLoading() ? 'Compiling...' : 'AI Assistant' }}</span>
            </button>
          </div>

          <div class="space-y-3">
            <div>
              <label for="policy-spec" class="block text-xs font-mono text-slate-400 mb-1">YAML Policy Specification</label>
              <textarea
                id="policy-spec"
                [(ngModel)]="policyYaml"
                rows="14"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 font-mono text-xs text-emerald-300 focus:border-indigo-500 focus:outline-none leading-relaxed"
              ></textarea>
            </div>

            <button
              (click)="runPipeline()"
              class="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm"
            >
              <mat-icon class="text-sm">play_arrow</mat-icon>
              <span>Compile Policy & Run 1M Pipeline</span>
            </button>
          </div>
        </div>

        <!-- Right: Execution Pipeline Results -->
        <div class="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-6">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 class="text-sm font-semibold text-white">1,000,000 Record Pipeline Execution</h2>
            @if (pipelineResult(); as res) {
              <span class="text-xs font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-1 rounded">
                k-Anonymity k={{ res.kAnonymity }}
              </span>
            }
          </div>

          <!-- Pipeline Results Overview -->
          @if (pipelineResult(); as res) {
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div class="text-slate-400">Records Processed</div>
                <div class="text-base font-bold text-white tabular-nums">{{ res.recordsProcessed | number }}</div>
              </div>

              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div class="text-slate-400">Direct Identifiers</div>
                <div class="text-base font-bold text-rose-400">REMOVED (0 Remaining)</div>
              </div>

              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div class="text-slate-400">Minimum Cohort</div>
                <div class="text-base font-bold text-emerald-400">500 Records</div>
              </div>

              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div class="text-slate-400">Risk Assessment</div>
                <div class="text-base font-bold text-emerald-400">{{ res.riskScore }} (k={{ res.kAnonymity }})</div>
              </div>
            </div>
          }

          <!-- Transformation Pipeline Rules Applied -->
          <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3 text-xs font-mono">
            <div class="text-indigo-400 font-bold uppercase">TRANSFORMATION COMPILER SUMMARY</div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-[11px]">
              <div class="space-y-1">
                <span class="text-rose-400 font-bold">Removed Direct Fields:</span>
                <div class="bg-slate-900 p-2 rounded border border-slate-800 text-slate-300">
                  name, email, phone, ssn, ip_address
                </div>
              </div>

              <div class="space-y-1">
                <span class="text-amber-400 font-bold">Generalised Quasi-Identifiers:</span>
                <div class="bg-slate-900 p-2 rounded border border-slate-800 text-slate-300">
                  postcode &rarr; outward sector | age &rarr; 10-year decade buckets
                </div>
              </div>
            </div>
          </div>

          <!-- Sample Processed Records Inspection -->
          <div class="space-y-2">
            <h3 class="text-xs font-semibold text-white font-mono uppercase">Processed Output Data Sample (Anonymised)</h3>
            <div class="overflow-x-auto bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-[11px]">
              <table class="w-full text-left text-slate-300">
                <thead>
                  <tr class="text-slate-500 border-b border-slate-800">
                    <th class="py-1.5 px-2">PSEUDONYM</th>
                    <th class="py-1.5 px-2">AGE GROUP</th>
                    <th class="py-1.5 px-2">REGION</th>
                    <th class="py-1.5 px-2">INCOME BRACKET</th>
                    <th class="py-1.5 px-2">DIAGNOSIS</th>
                    <th class="py-1.5 px-2 text-right">COST (£)</th>
                  </tr>
                </thead>
                <tbody>
                  @for (r of sampleData(); track r.pseudonym) {
                    <tr class="border-b border-slate-900">
                      <td class="py-1.5 px-2 text-cyan-400">{{ r.pseudonym }}</td>
                      <td class="py-1.5 px-2 text-white">{{ r.age_group }}</td>
                      <td class="py-1.5 px-2 text-slate-400">{{ r.region }}</td>
                      <td class="py-1.5 px-2 text-amber-300">{{ r.income_bracket }}</td>
                      <td class="py-1.5 px-2 text-purple-300">{{ r.diagnosis }}</td>
                      <td class="py-1.5 px-2 text-right text-emerald-400 tabular-nums">{{ r.treatment_cost | currency:'GBP':'symbol':'1.2-2' }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>

        </div>

      </div>

    </div>
  `
})
export class MinimisationComponent {
  public service = inject(RingforgeService);

  public policyYaml = `dataset: research_transactions

identity:
  remove:
    - name
    - email
    - phone
    - ssn

quasi_identifiers:
  generalise:
    postcode: outward
    age: decade

financial:
  retain:
    - transaction_value
    - diagnosis_code

release:
  minimum_group_size: 500

privacy:
  differential_privacy:
    epsilon: 1.5
    delta: 1e-5`;

  public pipelineResult = signal<MinimisationResponse | null>(null);
  public sampleData = signal<SampleRecord[]>([]);
  public aiLoading = signal<boolean>(false);

  constructor() {
    this.runPipeline();
  }

  public async runPipeline() {
    try {
      const res = await this.service.runMinimisationPipeline(this.policyYaml);
      this.pipelineResult.set(res);
      this.sampleData.set((res.sampleProcessed || []) as unknown as SampleRecord[]);
      this.service.notify('Minimisation pipeline compiled & executed over 1,000,000 records.', 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Pipeline error: ' + msg, 'error');
    }
  }

  public async generateAiPolicy() {
    this.aiLoading.set(true);
    try {
      const res = await this.service.generateAiPolicy('Generate a privacy policy for clinical hospital trial datasets adhering to GDPR minimum disclosure rules');
      if (res.policyYaml) {
        this.policyYaml = res.policyYaml;
        this.service.notify('AI Policy generated & compiled successfully!', 'success');
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('AI Policy error: ' + msg, 'error');
    } finally {
      this.aiLoading.set(false);
    }
  }
}
