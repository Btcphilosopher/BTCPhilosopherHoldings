import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RingforgeService, CredentialResponse, CredentialPresentationResponse } from '../services/ringforge';

@Component({
  selector: 'app-credentials',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Header -->
      <div class="bg-slate-900/90 border border-slate-800 p-6 rounded-2xl space-y-1">
        <div class="flex items-center gap-2 text-xs font-mono text-purple-400">
          <mat-icon class="text-sm">badge</mat-icon>
          <span>CRYPTOGRAPHIC PRIMITIVE #3</span>
        </div>
        <h1 class="text-xl font-bold text-white">Anonymous Credentials & ZK Predicate Proofs</h1>
        <p class="text-xs text-slate-400 max-w-3xl">
          Prove attributes (e.g. <span class="text-emerald-400 font-mono">Age &ge; 18</span> or <span class="text-emerald-400 font-mono">Enrolled Student at University X</span>) using zero-knowledge predicates without revealing raw identifiers or DOB.
        </p>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Issue Credential Panel -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 class="text-sm font-semibold text-white flex items-center gap-2">
            <mat-icon class="text-purple-400 text-base">domain_verification</mat-icon>
            <span>1. Issue Credential</span>
          </h2>

          <div class="space-y-3 text-xs">
            <div>
              <label for="subj-id" class="block font-mono text-slate-400 mb-1">Holder Subject ID</label>
              <input
                id="subj-id"
                type="text"
                [(ngModel)]="subjectId"
                placeholder="e.g. USER-9842"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 font-mono text-white focus:border-purple-500 focus:outline-none"
              />
            </div>

            <div>
              <label for="holder-age" class="block font-mono text-slate-400 mb-1">Age Attribute (Raw Private Claim)</label>
              <input
                id="holder-age"
                type="number"
                [(ngModel)]="holderAge"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 font-mono text-white focus:border-purple-500 focus:outline-none"
              />
            </div>

            <div>
              <label for="holder-org" class="block font-mono text-slate-400 mb-1">Organization Affiliation</label>
              <input
                id="holder-org"
                type="text"
                [(ngModel)]="holderOrg"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 font-mono text-white focus:border-purple-500 focus:outline-none"
              />
            </div>

            <button
              (click)="issueCredential()"
              class="w-full py-2 bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <mat-icon class="text-sm">verified_user</mat-icon>
              <span>Issue Signed Credential</span>
            </button>
          </div>

          <!-- Credential Card Preview -->
          @if (activeCredential(); as cred) {
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2 font-mono text-xs">
              <div class="text-purple-400 font-bold flex items-center justify-between">
                <span>ISSUED ANONYMOUS CREDENTIAL</span>
                <span class="text-[10px] bg-purple-500/10 border border-purple-500/30 px-2 py-0.5 rounded">&check; SIGNED</span>
              </div>
              <div class="text-[11px] text-slate-300 space-y-0.5">
                <div>Credential ID: <span class="text-white">{{ cred.id }}</span></div>
                <div>Issuer: <span class="text-slate-400">{{ cred.issuerId }}</span></div>
                <div>Raw Claims in Vault: <span class="text-purple-300">Age: {{ cred.claims['age'] }}, Org: {{ cred.claims['org'] }}</span></div>
              </div>
            </div>
          }
        </div>

        <!-- Present ZK Proof Panel -->
        <div class="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-6">
          <h2 class="text-sm font-semibold text-white flex items-center gap-2">
            <mat-icon class="text-emerald-400 text-base">visibility_off</mat-icon>
            <span>2. Generate Selective Disclosure & ZK Presentation</span>
          </h2>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs font-mono">
            
            <div class="space-y-2">
              <span class="text-slate-400 font-bold uppercase">Zero-Knowledge Predicate Rules</span>
              <div class="space-y-1.5 text-[11px]">
                <label class="flex items-center gap-2 cursor-pointer text-slate-200">
                  <input type="checkbox" [(ngModel)]="proveAgeGte18" class="accent-emerald-500" />
                  <span>Prove Age &ge; 18 (Hide exact age)</span>
                </label>
                <label class="flex items-center gap-2 cursor-pointer text-slate-200">
                  <input type="checkbox" [(ngModel)]="proveOrgMember" class="accent-emerald-500" />
                  <span>Prove Member of Oxford (Hide employee ID)</span>
                </label>
              </div>
            </div>

            <div class="space-y-2">
              <span class="text-slate-400 font-bold uppercase">Selective Attribute Disclosure</span>
              <div class="space-y-1.5 text-[11px]">
                <label class="flex items-center gap-2 cursor-pointer text-slate-200">
                  <input type="checkbox" [(ngModel)]="discloseOrgName" class="accent-amber-500" />
                  <span>Disclose Org Name publicly</span>
                </label>
                <div class="text-slate-500 text-[10px]">
                  All unselected attributes remain encrypted inside ZK proof.
                </div>
              </div>
            </div>

          </div>

          <button
            (click)="presentCredential()"
            [disabled]="!activeCredential()"
            class="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 shadow-sm"
          >
            <mat-icon class="text-sm">verified</mat-icon>
            <span>Generate & Verify ZK Presentation</span>
          </button>

          <!-- Presentation Result Output -->
          @if (presentationResult(); as pres) {
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-3 font-mono text-xs">
              <div class="flex items-center justify-between">
                <span class="text-emerald-400 font-bold uppercase">VERIFIER EVALUATION RESULT</span>
                <span class="text-xs font-bold px-2.5 py-1 rounded border"
                  [class.bg-emerald-500-10]="pres.verified"
                  [class.text-emerald-400]="pres.verified"
                  [class.border-emerald-500-30]="pres.verified"
                  [class.bg-rose-500-10]="!pres.verified"
                  [class.text-rose-400]="!pres.verified"
                  [class.border-rose-500-30]="!pres.verified"
                >
                  {{ pres.verified ? 'PROVED VALID (VALID ZK)' : 'PREDICATE FAILED' }}
                </span>
              </div>

              <div class="space-y-2 pt-1">
                <div class="text-slate-400 font-bold">Proved ZK Predicates:</div>
                <div class="space-y-1 pl-2">
                  @for (pred of pres.provedPredicates; track pred.field) {
                    <div class="flex items-center gap-2 text-[11px]">
                      @if (pred.satisfied) {
                        <mat-icon class="text-sm text-emerald-400">check_circle</mat-icon>
                      } @else {
                        <mat-icon class="text-sm text-rose-400">cancel</mat-icon>
                      }
                      <span class="text-slate-200">Predicate: {{ pred.field }} {{ pred.operator }} {{ pred.targetValue }}</span>
                      @if (pred.satisfied) {
                        <span class="text-emerald-400 font-bold">(SATISFIED WITH ZERO DISCLOSURE)</span>
                      }
                    </div>
                  }
                </div>

                <div class="border-t border-slate-800 pt-2 grid grid-cols-2 gap-4 text-[11px]">
                  <div>
                    <span class="text-slate-400">Disclosed Fields to Verifier:</span>
                    <div class="text-white font-bold">{{ objectKeys(pres.disclosedFields).length > 0 ? jsonString(pres.disclosedFields) : 'None (Full ZK Mode)' }}</div>
                  </div>
                  <div>
                    <span class="text-slate-400">Hidden / Protected Fields:</span>
                    <div class="text-emerald-400 font-bold">{{ pres.hiddenFields.join(', ') }}</div>
                  </div>
                </div>

                <div class="text-[10px] text-slate-500 break-all pt-1">
                  Proof Hex: {{ pres.proofHex }}
                </div>
              </div>
            </div>
          }

        </div>

      </div>

    </div>
  `
})
export class CredentialsComponent {
  public service = inject(RingforgeService);

  public subjectId = 'USER-9842';
  public holderAge = 24;
  public holderOrg = 'University of Oxford';

  public activeCredential = signal<CredentialResponse | null>(null);
  public presentationResult = signal<CredentialPresentationResponse | null>(null);

  public proveAgeGte18 = true;
  public proveOrgMember = true;
  public discloseOrgName = false;

  constructor() {
    this.issueCredential();
  }

  public async issueCredential() {
    try {
      const res = await this.service.issueCredential(this.subjectId, {
        age: this.holderAge,
        org: this.holderOrg,
        employeeId: 'EMP-84920'
      });
      this.activeCredential.set(res);
      this.service.notify(`Issued signed credential ${res.id} for ${this.subjectId}`, 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Issue error: ' + msg, 'error');
    }
  }

  public async presentCredential() {
    const cred = this.activeCredential();
    if (!cred) return;

    const predicates: unknown[] = [];
    if (this.proveAgeGte18) {
      predicates.push({ field: 'age', operator: 'GTE', targetValue: 18 });
    }
    if (this.proveOrgMember) {
      predicates.push({ field: 'org', operator: 'EQ', targetValue: 'University of Oxford' });
    }

    const discloseFields: string[] = [];
    if (this.discloseOrgName) {
      discloseFields.push('org');
    }

    try {
      const res = await this.service.presentCredential(cred.id, predicates, discloseFields);
      this.presentationResult.set(res);
      if (res.verified) {
        this.service.notify('ZK Presentation verified! Proved age >= 18 and Oxford membership with zero ID leakage.', 'success');
      } else {
        this.service.notify('Presentation failed: Predicates not satisfied.', 'error');
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('Presentation error: ' + msg, 'error');
    }
  }

  public objectKeys(obj: Record<string, unknown> | null | undefined): string[] {
    return obj ? Object.keys(obj) : [];
  }

  public jsonString(obj: Record<string, unknown> | null | undefined): string {
    return JSON.stringify(obj);
  }
}
