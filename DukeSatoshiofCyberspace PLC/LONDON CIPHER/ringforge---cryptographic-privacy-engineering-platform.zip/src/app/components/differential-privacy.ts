import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RingforgeService, DpQueryResponse, DpBudgetResponse } from '../services/ringforge';

@Component({
  selector: 'app-differential-privacy',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Header -->
      <div class="bg-slate-900/90 border border-slate-800 p-6 rounded-2xl space-y-1">
        <div class="flex items-center gap-2 text-xs font-mono text-purple-400">
          <mat-icon class="text-sm">insights</mat-icon>
          <span>CRYPTOGRAPHIC PRIMITIVE #6</span>
        </div>
        <h1 class="text-xl font-bold text-white">Differential Privacy & Query Accounting</h1>
        <p class="text-xs text-slate-400 max-w-3xl">
          Calibrated noise mechanisms (Laplace / Gaussian) guarantee that no single record significantly alters query output, backed by strict (epsilon, delta) privacy budget composition ledger.
        </p>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Left: Query Execution Panel -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 class="text-sm font-semibold text-white">Execute DP Analytical Query</h2>

          <div class="space-y-3 text-xs">
            <div>
              <label for="q-type" class="block font-mono text-slate-400 mb-1">Query Type</label>
              <select
                id="q-type"
                [(ngModel)]="queryType"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 font-mono text-white focus:border-purple-500 focus:outline-none"
              >
                <option value="COUNT">COUNT (Total records matching cohort)</option>
                <option value="AVERAGE">AVERAGE (Average treatment cost £)</option>
                <option value="SUM">SUM (Total regional healthcare expenditure £)</option>
              </select>
            </div>

            <div>
              <label for="eps-range" class="block font-mono text-slate-400 mb-1">Epsilon Privacy Budget Loss (&epsilon;)</label>
              <div class="flex items-center gap-3">
                <input
                  id="eps-range"
                  type="range"
                  min="0.1"
                  max="5.0"
                  step="0.1"
                  [(ngModel)]="epsilon"
                  class="w-full accent-purple-500"
                />
                <span class="font-mono text-purple-400 font-bold w-12 text-right">&epsilon;={{ epsilon }}</span>
              </div>
            </div>

            <div>
              <label for="delta-val" class="block font-mono text-slate-400 mb-1">Delta Failure Probability (&delta;)</label>
              <div id="delta-val" class="font-mono text-slate-300 bg-slate-950 p-2 rounded border border-slate-800">
                &delta; = 1e-05 (1 in 100,000 bounds)
              </div>
            </div>

            <button
              (click)="runQuery()"
              class="w-full py-2.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm"
            >
              <mat-icon class="text-sm">functions</mat-icon>
              <span>Execute Differential Privacy Query</span>
            </button>
          </div>
        </div>

        <!-- Right: Privacy Budget Ledger & Query History -->
        <div class="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-6">
          
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 class="text-sm font-semibold text-white">Privacy Budget Consumption Ledger</h2>
            <span class="text-xs font-mono text-purple-400 bg-purple-500/10 border border-purple-500/30 px-2.5 py-1 rounded">
              DATASET: dataset-consumer-research
            </span>
          </div>

          <!-- Budget Gauge Cards -->
          @if (budget(); as bgt) {
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div class="text-slate-400">Total Budget (&epsilon;)</div>
                <div class="text-base font-bold text-white">{{ bgt.totalEpsilon }}</div>
              </div>

              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div class="text-slate-400">Consumed (&epsilon;)</div>
                <div class="text-base font-bold text-purple-400">{{ bgt.usedEpsilon | number:'1.2-2' }}</div>
              </div>

              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div class="text-slate-400">Remaining (&epsilon;)</div>
                <div class="text-base font-bold text-emerald-400">{{ bgt.remainingEpsilon | number:'1.2-2' }}</div>
              </div>

              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div class="text-slate-400">Queries Executed</div>
                <div class="text-base font-bold text-white">{{ bgt.queryCount }}</div>
              </div>
            </div>
          }

          <!-- Last Query Execution Result Comparison -->
          @if (lastQueryResult(); as res) {
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3 font-mono text-xs">
              <div class="text-purple-400 font-bold flex items-center justify-between">
                <span>QUERY OUTPUT & LAPLACE NOISE COMPARISON</span>
                <span class="text-[10px] bg-purple-500/10 border border-purple-500/30 px-2 py-0.5 rounded">&check; &epsilon;={{ epsilon }} CONSUMED</span>
              </div>

              <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-[11px] pt-1">
                <div class="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                  <div class="text-slate-400">True Underlying Value</div>
                  <div class="text-base font-bold text-white">{{ res.queryResult | number:'1.0-2' }}</div>
                </div>

                <div class="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                  <div class="text-slate-400">Injected Laplace Noise</div>
                  <div class="text-base font-bold text-rose-400">{{ res.noiseAdded > 0 ? '+' : '' }}{{ res.noiseAdded | number:'1.2-2' }}</div>
                </div>

                <div class="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                  <div class="text-slate-400">Released Noisy Result</div>
                  <div class="text-base font-bold text-purple-300">{{ res.noisyResult | number:'1.0-2' }}</div>
                </div>
              </div>
            </div>
          }

        </div>

      </div>

    </div>
  `
})
export class DifferentialPrivacyComponent {
  public service = inject(RingforgeService);

  public queryType: 'COUNT' | 'SUM' | 'AVERAGE' = 'COUNT';
  public epsilon = 1.0;

  public lastQueryResult = signal<DpQueryResponse | null>(null);
  public budget = signal<DpBudgetResponse | null>(null);

  constructor() {
    this.refreshBudget();
  }

  public async refreshBudget() {
    try {
      const res = await this.service.getPrivacyBudget('dataset-consumer-research');
      this.budget.set(res);
    } catch (err) {
      console.error('Budget refresh error:', err);
    }
  }

  public async runQuery() {
    try {
      const res = await this.service.executeDpQuery('dataset-consumer-research', this.queryType, this.epsilon);
      this.lastQueryResult.set(res);
      await this.refreshBudget();
      this.service.notify(`DP Query executed. Noise added: ${res.noiseAdded.toFixed(2)}. Remaining epsilon: ${res.remainingEpsilon.toFixed(2)}.`, 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.service.notify('DP Query error: ' + msg, 'error');
    }
  }
}
