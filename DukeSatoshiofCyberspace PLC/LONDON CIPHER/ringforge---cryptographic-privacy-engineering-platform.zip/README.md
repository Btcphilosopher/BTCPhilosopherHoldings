# RINGFORGE

> **MINIMUM DISCLOSURE. CRYPTOGRAPHIC PROOF. CONTROLLED DATA.**

RINGFORGE is an engineering-grade Rust privacy-engineering and cryptographic data-anonymisation platform designed for organisations that need to analyse, transfer, and authenticate sensitive datasets while minimising unnecessary disclosure of individual identity.

---

## ⚠️ Cryptographic Disclaimer

> **RINGFORGE is an engineering and research platform. Cryptographic security depends on the underlying algorithms, implementations, parameters, key management, operational environment and threat model. No anonymity guarantee is absolute.**

RINGFORGE is NOT a cryptocurrency, dark-web tool, or traffic-obfuscation mechanism. It must NOT be used for evading law enforcement, bypassing authentication, concealing malicious activity, or deanonymising individuals.

---

## Architecture Overview

RINGFORGE implements a multi-primitive cryptographic pipeline:

```text
RAW DATA
    ↓
IDENTITY SEPARATION (ringforge-data)
    ↓
PSEUDONYMISATION (ringforge-pseudonyms / HKDF domain separation)
    ↓
MINIMISATION (ringforge-policy / transformer)
    ↓
CRYPTOGRAPHIC PROTECTION (ringforge-commitments / ringforge-ring / ringforge-aead)
    ↓
PRIVACY-PRESERVING ANALYSIS (ringforge-aggregation / ringforge-differential-privacy)
    ↓
AGGREGATED OUTPUT (ringforge-provenance / signed release)
```

---

## Workspace Crates

- `ringforge-core`: Common traits, errors, and system context
- `ringforge-types`: Strongly-typed domain structures (`PublicKey`, `RingSignature`, `Pseudonym`, `PrivacyBudget`)
- `ringforge-crypto`: Base cryptographic abstraction layer
- `ringforge-hash`: Cryptographic hashing abstraction (SHA-2, SHA-3, BLAKE3)
- `ringforge-kdf`: Key derivation & HKDF domain separation
- `ringforge-aead`: Envelope encryption & AEAD ciphertext containers
- `ringforge-signatures`: Ed25519 standard signatures
- `ringforge-ring`: Linkable and unlinkable Ring Signatures engine with policy enforcement
- `ringforge-blind`: Blind signature protocol (blind, sign_blinded, unblind, verify)
- `ringforge-credentials`: Anonymous credentials & selective disclosure predicates
- `ringforge-pseudonyms`: Keyed domain-separated pseudonym generator
- `ringforge-commitments`: Pedersen and SHA-256 blinding commitment schemes
- `ringforge-zk`: Zero-knowledge statement verification interface
- `ringforge-threshold`: M-of-N threshold key custodianship & recovery
- `ringforge-aggregation`: Secure multiparty aggregation with cohort constraints
- `ringforge-differential-privacy`: Laplace & Gaussian differential privacy mechanisms
- `ringforge-data`: Dataset minimisation, transformation, and k-anonymity analysis
- `ringforge-policy`: Declarative YAML privacy policy compiler
- `ringforge-provenance`: Cryptographic provenance chain & transformation tracking
- `ringforge-audit`: Tamper-evident hash chain audit ledger
- `ringforge-storage`: Secure vault storage & zeroized memory containers
- `ringforge-api`: REST/gRPC OpenAPI interface layer
- `ringforge-cli`: Command-line interface runner
- `ringforge-test`: Test vectors, property tests, and synthetic benchmark generators

---

## CLI Usage Example

```bash
# Generate keys
ringforge key generate --algorithm ed25519 --owner auditor-01

# Create ring and sign
ringforge ring create --id audit-panel-2026 --members key1,key2,key3
ringforge ring sign --id audit-panel-2026 --message "APPROVED_REPORT_HASH"

# Issue domain pseudonym
ringforge pseudonym issue --identity "USER-9482" --domain "healthcare"

# Run data minimisation pipeline
ringforge dataset minimise --input raw_data.json --policy privacy_policy.yaml

# Evaluate differential privacy budget
ringforge dp release --epsilon 1.5 --delta 1e-5 --dataset research_dataset
```

---

## Core Governing Principles

1. **IDENTITY IS NOT DATA.**
2. **PRIVACY IS NOT THE SAME AS ENCRYPTION.**
3. **ANONYMITY IS NOT THE SAME AS PSEUDONYMISATION.**
4. **A HASH IS NOT AN ANONYMISATION SYSTEM.**
5. **K-ANONYMITY IS NOT A COMPLETE PRIVACY GUARANTEE.**
6. **EVERY RELEASE SHOULD DISCLOSE THE MINIMUM INFORMATION NECESSARY FOR ITS PURPOSE.**
