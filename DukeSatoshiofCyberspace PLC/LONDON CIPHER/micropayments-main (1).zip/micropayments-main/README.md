# ⚡ Lightning Paywall — Micropay-Per-Article System

A fully working proof-of-concept paywall that gates article access behind
real (or simulated) Bitcoin Lightning Network micropayments.

---

## Architecture

```
paywall/
├── config.py      — Environment-based configuration
├── models.py      — SQLite schema + all DB helpers
├── crypto.py      — ChaCha20-Poly1305 article encryption
├── lightning.py   — LND / CLN / Mock invoice backends
├── paywall.py     — Business logic (service layer)
├── cli.py         — Click CLI commands
├── api.py         — Flask REST API
└── main.py        — Entry point
```

### Data flow

```
User request
     │
     ▼
  CLI / Flask API
     │
     ▼
  paywall.py  (service layer)
     ├──► models.py   (SQLite: users, articles, payments, unlocked)
     ├──► lightning.py (LND REST / CLN REST / Mock)
     └──► crypto.py   (HKDF key derivation → ChaCha20-Poly1305)
```

### Encrypted file format

```
[ 12-byte nonce | ChaCha20-Poly1305 ciphertext + 16-byte Poly1305 tag ]
```

---

## Quick Start (Mock Mode — no real Lightning node required)

### 1. Install dependencies

```bash
pip install flask click cryptography requests
```

### 2. Run the built-in demo

```bash
cd paywall
python main.py demo
```

This will:
- Initialise the database
- Register user **alice**
- Encrypt and publish a sample article
- Generate a mock invoice (auto-paid after 5 s)
- Unlock and print the article

---

## CLI Reference

```bash
# Initialise the database (run once)
python main.py init-db

# Register a new user
python main.py register -u alice

# Encrypt & publish an article from a text file
python main.py add-article \
    --slug bitcoin-101 \
    --title "Bitcoin 101" \
    --desc "An intro to Bitcoin" \
    --price 100 \
    --file /path/to/article.txt

# Publish from $EDITOR (omit --file to open your editor)
python main.py add-article --slug my-post --title "My Post" --price 50

# List all articles (with alice's unlock status)
python main.py list-articles -u alice

# Generate a Lightning invoice
python main.py invoice -u alice --slug bitcoin-101

# Check payment status (add --poll to keep checking every 2 s)
python main.py check-payment \
    -u alice \
    --slug bitcoin-101 \
    --hash <payment_hash_from_invoice> \
    --poll

# [Mock mode] Immediately mark an invoice as paid
python main.py force-pay --hash <payment_hash>

# Read a paid article
python main.py read -u alice --slug bitcoin-101

# Start the Flask web server
python main.py serve
```

---

## Flask REST API

Base URL: `http://127.0.0.1:5000`

All protected endpoints use **HTTP Basic Auth** (`username:password`).

### Endpoints

| Method | Path                     | Auth | Description                          |
|--------|--------------------------|------|--------------------------------------|
| GET    | `/api/health`            | No   | Liveness check                       |
| POST   | `/api/register`          | No   | Register a new user                  |
| GET    | `/api/articles`          | Yes  | List articles with unlock status     |
| POST   | `/api/invoice`           | Yes  | Generate a Lightning invoice         |
| POST   | `/api/check-payment`     | Yes  | Poll payment status + unlock         |
| GET    | `/api/read/<slug>`       | Yes  | Read a paid article                  |
| POST   | `/api/dev/force-pay`     | No   | **Mock only**: instantly settle      |

### Example session (curl)

```bash
# Register
curl -s -X POST http://localhost:5000/api/register \
     -H "Content-Type: application/json" \
     -d '{"username":"alice","password":"hunter2"}' | jq

# List articles
curl -s -u alice:hunter2 http://localhost:5000/api/articles | jq

# Generate invoice
curl -s -X POST http://localhost:5000/api/invoice \
     -u alice:hunter2 \
     -H "Content-Type: application/json" \
     -d '{"slug":"bitcoin-101"}' | jq

# Force-pay (mock mode)
curl -s -X POST http://localhost:5000/api/dev/force-pay \
     -H "Content-Type: application/json" \
     -d '{"payment_hash":"<hash>"}' | jq

# Check payment / unlock
curl -s -X POST http://localhost:5000/api/check-payment \
     -u alice:hunter2 \
     -H "Content-Type: application/json" \
     -d '{"slug":"bitcoin-101","payment_hash":"<hash>"}' | jq

# Read article
curl -s -u alice:hunter2 http://localhost:5000/api/read/bitcoin-101 | jq
```

---

## Connecting to a Real Lightning Node

### LND (Lightning Network Daemon)

```bash
export PAYWALL_LN_MOCK=false
export PAYWALL_LN_BACKEND=lnd
export PAYWALL_LN_HOST=localhost
export PAYWALL_LN_PORT=8080
export PAYWALL_LN_MACAROON=$(xxd -p -c 1000 ~/.lnd/data/chain/bitcoin/mainnet/admin.macaroon)
export PAYWALL_LN_TLS_CERT=~/.lnd/tls.cert
```

### Core Lightning (CLN) with clnrest plugin

```bash
export PAYWALL_LN_MOCK=false
export PAYWALL_LN_BACKEND=cln
export PAYWALL_LN_HOST=localhost
export PAYWALL_LN_PORT=3010        # default clnrest port
export PAYWALL_LN_MACAROON=<rune>  # generate with: lightning-cli createrune
```

---

## Environment Variables

| Variable                  | Default         | Description                            |
|---------------------------|-----------------|----------------------------------------|
| `PAYWALL_DB_PATH`         | `paywall.db`    | SQLite database file path              |
| `PAYWALL_ARTICLES_DIR`    | `articles/`     | Directory for encrypted `.enc` files   |
| `PAYWALL_MASTER_KEY`      | random (dev)    | 32-byte hex master encryption key      |
| `PAYWALL_LN_MOCK`         | `true`          | Use mock backend (no real node)        |
| `PAYWALL_LN_BACKEND`      | `lnd`           | `lnd` or `cln`                         |
| `PAYWALL_LN_HOST`         | `localhost`     | Lightning node hostname                |
| `PAYWALL_LN_PORT`         | `8080`          | Lightning node REST port               |
| `PAYWALL_LN_MACAROON`     | _(empty)_       | Hex-encoded macaroon / rune            |
| `PAYWALL_LN_TLS_CERT`     | _(empty)_       | Path to TLS certificate                |
| `PAYWALL_INVOICE_EXPIRY`  | `3600`          | Invoice TTL in seconds                 |
| `PAYWALL_DEFAULT_PRICE_SATS` | `100`        | Default article price in satoshis      |
| `PAYWALL_FLASK_HOST`      | `127.0.0.1`     | Flask bind address                     |
| `PAYWALL_FLASK_PORT`      | `5000`          | Flask port                             |
| `PAYWALL_FLASK_DEBUG`     | `false`         | Enable Flask debug mode                |
| `PAYWALL_FLASK_SECRET`    | random          | Flask session secret key               |

---

## Security Notes

- **Master key**: In production, set `PAYWALL_MASTER_KEY` to a stable 64-char hex
  value and store it in a secrets manager (Vault, AWS Secrets Manager, etc.).
  Without it, a random ephemeral key is generated at startup and all encrypted
  articles become unreadable after restart.

- **Macaroon / rune**: Treat this like a root password. Use an invoice-only
  macaroon in production:
  ```bash
  lncli bakemacaroon invoices:write invoices:read
  ```

- **TLS**: Always set `PAYWALL_LN_TLS_CERT` in production to verify the node's
  certificate rather than disabling verification.

- **Passwords**: Currently hashed with SHA-256 for simplicity. In production,
  replace `_hash_secret()` in `models.py` with `bcrypt` or `argon2-cffi`.

- **Flask**: The built-in server is for development only. In production, use
  Gunicorn:
  ```bash
  gunicorn "api:app" --bind 0.0.0.0:5000 --workers 4
  ```
