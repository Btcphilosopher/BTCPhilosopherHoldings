"""
paywall.py — High-level service functions used by both the CLI and the web API.

This module is the single place that combines:
  - Article encryption (crypto.py)
  - Lightning invoice creation / polling (lightning.py)
  - Database reads and writes (models.py)

All public functions raise ``PaywallError`` on expected failures so that
callers can show clean error messages without catching raw DB/crypto/LN errors.
"""

import os
from typing import Optional

import config
import crypto
import lightning
import models
from lightning import InvoiceResult, InvoiceStatus


class PaywallError(Exception):
    """Raised for all expected business-logic errors in the paywall layer."""


# ── User management ───────────────────────────────────────────────────────────

def register_user(username: str, password: str) -> int:
    """
    Create a new user account.  Returns the new user id.
    Raises ``PaywallError`` if the username is taken.
    """
    if not username or not password:
        raise PaywallError("Username and password must not be empty.")
    try:
        return models.create_user(username, password)
    except ValueError as exc:
        raise PaywallError(str(exc)) from exc


def authenticate(username: str, password: str) -> models.sqlite3.Row:
    """
    Verify credentials and return the user row.
    Raises ``PaywallError`` on failure.
    """
    user = models.verify_user(username, password)
    if user is None:
        raise PaywallError("Invalid username or password.")
    return user


# ── Article management ────────────────────────────────────────────────────────

def add_article_from_file(
    source_path: str,
    slug: str,
    title: str,
    description: str = "",
    price_sats: int = config.DEFAULT_PRICE_SATS,
) -> int:
    """
    Encrypt a plaintext file on disk and register it as a new article.

    Steps:
      1. Encrypt *source_path* → articles/<slug>.enc
      2. Insert metadata into the articles table.

    Returns the new article id.
    """
    if not os.path.isfile(source_path):
        raise PaywallError(f"Source file not found: '{source_path}'")

    enc_path = crypto.encrypt_file(source_path, slug)
    try:
        article_id = models.create_article(
            slug=slug,
            title=title,
            enc_path=enc_path,
            price_sats=price_sats,
            description=description,
        )
    except ValueError as exc:
        # Remove orphaned enc file if DB insert fails
        if os.path.exists(enc_path):
            os.remove(enc_path)
        raise PaywallError(str(exc)) from exc

    return article_id


def add_article_from_text(
    text: str,
    slug: str,
    title: str,
    description: str = "",
    price_sats: int = config.DEFAULT_PRICE_SATS,
) -> int:
    """
    Encrypt raw text and register it as a new article.  Convenience wrapper
    for the CLI's inline-text workflow.
    """
    if not text.strip():
        raise PaywallError("Article text must not be empty.")

    enc_path = crypto.encrypt_text(text, slug)
    try:
        article_id = models.create_article(
            slug=slug,
            title=title,
            enc_path=enc_path,
            price_sats=price_sats,
            description=description,
        )
    except ValueError as exc:
        if os.path.exists(enc_path):
            os.remove(enc_path)
        raise PaywallError(str(exc)) from exc

    return article_id


def get_all_articles() -> list:
    """Return all article rows from the database."""
    return models.list_articles()


def get_article_status(username: str, slug: str) -> dict:
    """
    Return a dict with article metadata and the user's unlock status.
    """
    article = models.get_article(slug)
    if article is None:
        raise PaywallError(f"Article '{slug}' not found.")
    user = models.get_user(username)
    if user is None:
        raise PaywallError(f"User '{username}' not found.")
    unlocked = models.is_unlocked(user["id"], article["id"])
    return {
        "slug":        article["slug"],
        "title":       article["title"],
        "description": article["description"],
        "price_sats":  article["price_sats"],
        "unlocked":    unlocked,
    }


# ── Invoice workflow ──────────────────────────────────────────────────────────

def generate_invoice(username: str, slug: str) -> InvoiceResult:
    """
    Generate a Lightning invoice for *username* to pay for *slug*.

    If a pending invoice already exists for this user+article pair, it is
    reused to avoid orphaned invoices on the node.
    """
    user = models.get_user(username)
    if user is None:
        raise PaywallError(f"User '{username}' not found.")

    article = models.get_article(slug)
    if article is None:
        raise PaywallError(f"Article '{slug}' not found.")

    # Already unlocked — no need to pay again
    if models.is_unlocked(user["id"], article["id"]):
        raise PaywallError(f"User '{username}' has already unlocked '{slug}'.")

    # Reuse an existing pending invoice if one exists
    existing = models.get_pending_payment(user["id"], article["id"])
    if existing:
        return InvoiceResult(
            payment_hash    = existing["payment_hash"],
            payment_request = existing["payment_request"],
            amount_sats     = existing["amount_sats"],
            expiry_seconds  = config.INVOICE_EXPIRY_SECONDS,
        )

    memo   = f"Paywall: {article['title']} for {username}"
    result = lightning.create_invoice(
        memo        = memo,
        amount_sats = article["price_sats"],
        expiry      = config.INVOICE_EXPIRY_SECONDS,
    )
    models.create_payment(
        user_id         = user["id"],
        article_id      = article["id"],
        payment_hash    = result.payment_hash,
        payment_request = result.payment_request,
        amount_sats     = result.amount_sats,
    )
    return result


def check_and_unlock(username: str, slug: str, payment_hash: str) -> InvoiceStatus:
    """
    Poll the Lightning backend for *payment_hash* and, if paid, unlock
    the article for *username*.

    Returns the current :class:`InvoiceStatus`.
    """
    user = models.get_user(username)
    if user is None:
        raise PaywallError(f"User '{username}' not found.")

    article = models.get_article(slug)
    if article is None:
        raise PaywallError(f"Article '{slug}' not found.")

    # Already unlocked
    if models.is_unlocked(user["id"], article["id"]):
        return InvoiceStatus.PAID

    status = lightning.check_invoice(payment_hash)

    if status == InvoiceStatus.PAID:
        models.mark_payment_paid(payment_hash)
        models.unlock_article(user["id"], article["id"])
    elif status == InvoiceStatus.EXPIRED:
        models.mark_payment_expired(payment_hash)

    return status


# ── Content access ────────────────────────────────────────────────────────────

def read_article(username: str, slug: str) -> str:
    """
    Return the decrypted plaintext of *slug* for *username*.

    Raises ``PaywallError`` if the article does not exist or the user has
    not paid for it.
    """
    user = models.get_user(username)
    if user is None:
        raise PaywallError(f"User '{username}' not found.")

    article = models.get_article(slug)
    if article is None:
        raise PaywallError(f"Article '{slug}' not found.")

    if not models.is_unlocked(user["id"], article["id"]):
        raise PaywallError(
            f"Article '{slug}' is locked. "
            "Generate an invoice and pay it first."
        )

    return crypto.decrypt_file(article["enc_path"], slug)


def list_user_articles(username: str) -> list[dict]:
    """
    Return all articles with unlock status for *username*.
    """
    user = models.get_user(username)
    if user is None:
        raise PaywallError(f"User '{username}' not found.")

    all_articles = models.list_articles()
    result = []
    for a in all_articles:
        result.append({
            "slug":       a["slug"],
            "title":      a["title"],
            "description": a["description"],
            "price_sats": a["price_sats"],
            "unlocked":   models.is_unlocked(user["id"], a["id"]),
        })
    return result
