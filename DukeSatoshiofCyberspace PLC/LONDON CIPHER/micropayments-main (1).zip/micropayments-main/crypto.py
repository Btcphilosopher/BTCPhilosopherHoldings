"""
crypto.py — Article encryption and decryption using ChaCha20-Poly1305.

Design
──────
- A unique 32-byte *article key* is derived from the master key and the
  article slug via HKDF-SHA256.  This means each article has its own key;
  compromising one article's key does not expose others.
- The encrypted file format is:
      [ 12-byte nonce ][ ChaCha20-Poly1305 ciphertext + 16-byte tag ]
- Nonce is randomly generated per encryption, so encrypting the same
  plaintext twice yields different ciphertext.
- The 16-byte Poly1305 authentication tag guarantees integrity — any
  tampering is detected before plaintext is returned.
"""

import os
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

import config

# ChaCha20-Poly1305 constants
NONCE_SIZE = 12    # bytes (96-bit nonce as per RFC 8439)
KEY_SIZE   = 32    # bytes (256-bit key)


# ── Key derivation ────────────────────────────────────────────────────────────

def derive_article_key(slug: str) -> bytes:
    """
    Derive a deterministic 32-byte encryption key for *slug* using
    HKDF-SHA256 keyed with the master key.

    The slug is used as HKDF 'info', so different slugs yield different keys
    even if they share the same master key.
    """
    hkdf = HKDF(
        algorithm=SHA256(),
        length=KEY_SIZE,
        salt=None,           # master key is already high-entropy
        info=slug.encode(),
    )
    return hkdf.derive(config.MASTER_KEY)


# ── Encryption ────────────────────────────────────────────────────────────────

def encrypt_article(plaintext: bytes, slug: str) -> bytes:
    """
    Encrypt *plaintext* for the article identified by *slug*.

    Returns raw bytes:  nonce (12 B) || ciphertext+tag (len+16 B)
    """
    key = derive_article_key(slug)
    chacha = ChaCha20Poly1305(key)
    nonce = os.urandom(NONCE_SIZE)
    ciphertext = chacha.encrypt(nonce, plaintext, associated_data=slug.encode())
    return nonce + ciphertext


def decrypt_article(ciphertext_blob: bytes, slug: str) -> bytes:
    """
    Decrypt a blob produced by :func:`encrypt_article`.

    Raises ``cryptography.exceptions.InvalidTag`` if the blob has been
    tampered with or the wrong key is used — never silently returns garbage.
    """
    if len(ciphertext_blob) < NONCE_SIZE + 16:
        raise ValueError("Ciphertext blob is too short to be valid.")
    nonce      = ciphertext_blob[:NONCE_SIZE]
    ciphertext = ciphertext_blob[NONCE_SIZE:]
    key = derive_article_key(slug)
    chacha = ChaCha20Poly1305(key)
    return chacha.decrypt(nonce, ciphertext, associated_data=slug.encode())


# ── File-level helpers ────────────────────────────────────────────────────────

def encrypt_file(source_path: str, slug: str) -> str:
    """
    Read the plaintext file at *source_path*, encrypt it, and write the
    result to ``<ARTICLES_DIR>/<slug>.enc``.

    Returns the path of the encrypted file.
    """
    articles_dir = Path(config.ARTICLES_DIR)
    articles_dir.mkdir(parents=True, exist_ok=True)

    with open(source_path, "rb") as fh:
        plaintext = fh.read()

    blob      = encrypt_article(plaintext, slug)
    enc_path  = articles_dir / f"{slug}.enc"

    with open(enc_path, "wb") as fh:
        fh.write(blob)

    return str(enc_path)


def decrypt_file(enc_path: str, slug: str) -> str:
    """
    Decrypt the encrypted file at *enc_path* and return the plaintext as a
    UTF-8 string.

    Raises ``ValueError`` if the file cannot be read or decrypted.
    """
    try:
        with open(enc_path, "rb") as fh:
            blob = fh.read()
    except OSError as exc:
        raise ValueError(f"Cannot read encrypted file '{enc_path}': {exc}") from exc

    plaintext_bytes = decrypt_article(blob, slug)
    return plaintext_bytes.decode("utf-8")


def encrypt_text(text: str, slug: str) -> str:
    """
    Convenience wrapper: encrypt a string, write to disk, return enc_path.
    Used by the CLI when the user types article content inline.
    """
    articles_dir = Path(config.ARTICLES_DIR)
    articles_dir.mkdir(parents=True, exist_ok=True)

    blob     = encrypt_article(text.encode("utf-8"), slug)
    enc_path = articles_dir / f"{slug}.enc"

    with open(enc_path, "wb") as fh:
        fh.write(blob)

    return str(enc_path)
