"""
lightning.py — Lightning Network invoice creation and status polling.

Supports three backends selected by ``config.LN_BACKEND``:

  lnd   — LND REST API  (https://lightning.engineering/api-docs/api/lnd/)
  cln   — Core Lightning REST plugin (clnrest)
  mock  — SQLite-persisted simulator; auto-pays invoices after a short delay.
          Enabled when ``config.LN_MOCK = True`` regardless of LN_BACKEND.

The mock backend stores all invoice state in the ``mock_invoices`` SQLite
table (via models.py), so force-pay and check-payment work correctly even
when called from separate Python processes — fixing the original in-memory
limitation.

All backends expose the same two-function interface:
  create_invoice(memo, amount_sats, expiry) -> InvoiceResult
  check_invoice(payment_hash)              -> InvoiceStatus
"""

import hashlib
import secrets
import time
from dataclasses import dataclass
from enum import Enum
from typing import Optional

import requests

import config

# ── Data structures ───────────────────────────────────────────────────────────

class InvoiceStatus(str, Enum):
    PENDING  = "pending"
    PAID     = "paid"
    EXPIRED  = "expired"
    FAILED   = "failed"


@dataclass
class InvoiceResult:
    """Returned by create_invoice()."""
    payment_hash:    str   # hex-encoded 32-byte hash
    payment_request: str   # BOLT-11 invoice string (lnbc…)
    amount_sats:     int
    expiry_seconds:  int


# ── Mock backend (DB-persisted) ───────────────────────────────────────────────
# Auto-settle delay for demo/test convenience.
MOCK_AUTO_SETTLE_SECS: int = 5


def _mock_create_invoice(memo: str, amount_sats: int, expiry: int) -> InvoiceResult:
    """
    Create a simulated Lightning invoice.

    Invoice state is persisted to the ``mock_invoices`` SQLite table.
    Settlement is recorded as a future timestamp (``auto_settle_at``) so
    that *any* process calling :func:`check_invoice` after that time will
    see the invoice as paid — no daemon thread required, no cross-process
    race conditions.
    """
    rand        = secrets.token_bytes(32)
    pay_hash    = hashlib.sha256(rand).hexdigest()
    pay_req     = f"lnbcrt{amount_sats}u1mock_{pay_hash[:16]}"
    deadline    = time.time() + expiry

    import models
    models.mock_add_invoice(
        pay_hash, amount_sats, deadline,
        auto_settle_secs=MOCK_AUTO_SETTLE_SECS,
    )

    return InvoiceResult(
        payment_hash    = pay_hash,
        payment_request = pay_req,
        amount_sats     = amount_sats,
        expiry_seconds  = expiry,
    )


def _mock_check_invoice(payment_hash: str) -> InvoiceStatus:
    """
    Read invoice status from the SQLite mock_invoices table.
    Automatically transitions pending → expired when the deadline passes.
    """
    import models
    status_str = models.mock_get_status(payment_hash)
    if status_str is None:
        return InvoiceStatus.FAILED
    _map = {
        "pending": InvoiceStatus.PENDING,
        "paid":    InvoiceStatus.PAID,
        "expired": InvoiceStatus.EXPIRED,
    }
    return _map.get(status_str, InvoiceStatus.FAILED)


def mock_force_pay(payment_hash: str) -> bool:
    """
    Immediately settle a pending mock invoice.

    Works across process boundaries because state lives in SQLite.
    Returns True if the invoice was found and successfully settled.
    """
    import models
    return models.mock_set_paid(payment_hash)


# ── LND backend ───────────────────────────────────────────────────────────────

def _lnd_headers() -> dict:
    """Build the Grpc-Metadata-Macaroon header required by LND REST."""
    if not config.LN_MACAROON_HEX:
        raise RuntimeError(
            "PAYWALL_LN_MACAROON is not set. "
            "Export the hex-encoded contents of admin.macaroon:\n"
            "  export PAYWALL_LN_MACAROON=$(xxd -p -c 1000 ~/.lnd/.../admin.macaroon)"
        )
    return {"Grpc-Metadata-Macaroon": config.LN_MACAROON_HEX}


def _lnd_session() -> requests.Session:
    """Create a requests Session pre-loaded with LND auth and TLS config."""
    sess = requests.Session()
    sess.headers.update(_lnd_headers())
    if config.LN_TLS_CERT_PATH:
        sess.verify = config.LN_TLS_CERT_PATH
    else:
        # Development fallback: skip TLS verification for self-signed certs.
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        sess.verify = False
    return sess


def _lnd_create_invoice(memo: str, amount_sats: int, expiry: int) -> InvoiceResult:
    """
    Call LND /v1/invoices to create a BOLT-11 invoice.
    Docs: https://lightning.engineering/api-docs/api/lnd/lightning/add-invoice
    """
    url  = f"https://{config.LN_HOST}:{config.LN_PORT}/v1/invoices"
    body = {"memo": memo, "value": str(amount_sats), "expiry": str(expiry)}
    try:
        resp = _lnd_session().post(url, json=body, timeout=10)
        resp.raise_for_status()
    except requests.RequestException as exc:
        raise RuntimeError(f"LND create_invoice failed: {exc}") from exc

    data = resp.json()
    # r_hash is base64 in LND; convert to hex for consistent storage.
    import base64
    pay_hash_b64 = data.get("r_hash", "")
    try:
        pay_hash = base64.b64decode(pay_hash_b64).hex()
    except Exception:
        pay_hash = pay_hash_b64   # already hex in some LND versions

    return InvoiceResult(
        payment_hash    = pay_hash,
        payment_request = data["payment_request"],
        amount_sats     = amount_sats,
        expiry_seconds  = expiry,
    )


def _lnd_check_invoice(payment_hash: str) -> InvoiceStatus:
    """
    Poll LND for the settlement state of *payment_hash*.
    Uses the r_hash hex form; LND REST accepts both base64 and hex here.
    """
    url = f"https://{config.LN_HOST}:{config.LN_PORT}/v1/invoice/{payment_hash}"
    try:
        resp = _lnd_session().get(url, timeout=10)
        resp.raise_for_status()
    except requests.RequestException as exc:
        raise RuntimeError(f"LND check_invoice failed: {exc}") from exc

    state = resp.json().get("state", "")
    # LND invoice states: OPEN | SETTLED | CANCELED | ACCEPTED
    if state == "SETTLED":
        return InvoiceStatus.PAID
    if state == "CANCELED":
        return InvoiceStatus.EXPIRED
    if state in ("OPEN", "ACCEPTED"):
        return InvoiceStatus.PENDING
    return InvoiceStatus.FAILED


# ── CLN (Core Lightning) backend ──────────────────────────────────────────────

def _cln_headers() -> dict:
    """Build the Rune header for CLN clnrest authentication."""
    if not config.LN_MACAROON_HEX:
        raise RuntimeError(
            "PAYWALL_LN_MACAROON is not set for CLN. "
            "Generate a rune with:\n"
            "  lightning-cli createrune"
        )
    return {"Rune": config.LN_MACAROON_HEX}


def _cln_post(endpoint: str, body: dict) -> dict:
    """POST to a CLN clnrest endpoint and return parsed JSON."""
    url = f"https://{config.LN_HOST}:{config.LN_PORT}{endpoint}"
    try:
        resp = requests.post(
            url, json=body,
            headers=_cln_headers(),
            verify=config.LN_TLS_CERT_PATH or False,
            timeout=10,
        )
        resp.raise_for_status()
    except requests.RequestException as exc:
        raise RuntimeError(f"CLN request to {endpoint} failed: {exc}") from exc
    return resp.json()


def _cln_create_invoice(memo: str, amount_sats: int, expiry: int) -> InvoiceResult:
    """
    Call CLN /v1/invoice to create a BOLT-11 invoice.
    Docs: https://docs.corelightning.org/reference/lightning-invoice
    """
    data = _cln_post("/v1/invoice", {
        "amount_msat": amount_sats * 1000,
        "label":       f"{memo}-{int(time.time())}",   # label must be unique
        "description": memo,
        "expiry":      expiry,
    })
    return InvoiceResult(
        payment_hash    = data["payment_hash"],
        payment_request = data["bolt11"],
        amount_sats     = amount_sats,
        expiry_seconds  = expiry,
    )


def _cln_check_invoice(payment_hash: str) -> InvoiceStatus:
    """
    Query CLN /v1/listinvoices for the status of *payment_hash*.
    """
    data      = _cln_post("/v1/listinvoices", {"payment_hash": payment_hash})
    invoices  = data.get("invoices", [])
    if not invoices:
        return InvoiceStatus.FAILED
    cln_state = invoices[0].get("status", "")
    # CLN states: paid | unpaid | expired
    _map = {
        "paid":    InvoiceStatus.PAID,
        "unpaid":  InvoiceStatus.PENDING,
        "expired": InvoiceStatus.EXPIRED,
    }
    return _map.get(cln_state, InvoiceStatus.FAILED)


# ── Public interface ──────────────────────────────────────────────────────────

def create_invoice(
    memo: str,
    amount_sats: int,
    expiry: int = config.INVOICE_EXPIRY_SECONDS,
) -> InvoiceResult:
    """
    Create a Lightning invoice using the configured backend.

    ``config.LN_MOCK = True``  → DB-persisted mock (no node needed).
    ``config.LN_BACKEND = 'lnd'`` → LND REST API.
    ``config.LN_BACKEND = 'cln'`` → Core Lightning clnrest.
    """
    if config.LN_MOCK:
        return _mock_create_invoice(memo, amount_sats, expiry)
    if config.LN_BACKEND == "lnd":
        return _lnd_create_invoice(memo, amount_sats, expiry)
    if config.LN_BACKEND == "cln":
        return _cln_create_invoice(memo, amount_sats, expiry)
    raise ValueError(f"Unknown LN_BACKEND: '{config.LN_BACKEND}'")


def check_invoice(payment_hash: str) -> InvoiceStatus:
    """
    Query the current payment status of *payment_hash*.

    Returns an :class:`InvoiceStatus` enum value.  Callers should handle
    all four states: PENDING, PAID, EXPIRED, FAILED.
    """
    if config.LN_MOCK:
        return _mock_check_invoice(payment_hash)
    if config.LN_BACKEND == "lnd":
        return _lnd_check_invoice(payment_hash)
    if config.LN_BACKEND == "cln":
        return _cln_check_invoice(payment_hash)
    raise ValueError(f"Unknown LN_BACKEND: '{config.LN_BACKEND}'")
