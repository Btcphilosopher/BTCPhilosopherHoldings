#!/usr/bin/env python3
"""
test_paywall.py — Automated test suite for the Lightning Paywall system.

Tests every major code path using subprocess (so cross-process persistence
of mock invoices is validated for real), plus in-process unit tests for
crypto and model helpers.

Run with:
    python test_paywall.py
"""

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import threading
import unittest

# ── Force mock mode and an isolated DB for tests ────────────────────────────
os.environ["PAYWALL_LN_MOCK"]   = "true"
os.environ["PAYWALL_MASTER_KEY"] = "a" * 64          # stable 32-byte test key

_test_dir = tempfile.mkdtemp(prefix="paywall_test_")
os.environ["PAYWALL_DB_PATH"]       = os.path.join(_test_dir, "test.db")
os.environ["PAYWALL_ARTICLES_DIR"]  = os.path.join(_test_dir, "articles")

# Now safe to import paywall modules (they pick up env vars at import time).
sys.path.insert(0, os.path.dirname(__file__))

import config
import crypto
import lightning
import models
import paywall
from lightning import InvoiceStatus


# ── Helpers ──────────────────────────────────────────────────────────────────

def run(*args) -> subprocess.CompletedProcess:
    """Run a CLI command and return the CompletedProcess result."""
    return subprocess.run(
        [sys.executable, os.path.join(os.path.dirname(__file__), "main.py")] + list(args),
        capture_output=True, text=True,
        env={**os.environ},
    )


def cli_ok(*args) -> str:
    """Run CLI command, assert exit 0, return stdout."""
    result = run(*args)
    if result.returncode != 0:
        print("STDOUT:", result.stdout)
        print("STDERR:", result.stderr)
    assert result.returncode == 0, (
        f"Command {args} failed (rc={result.returncode}):\n{result.stderr}"
    )
    return result.stdout


def cli_fail(*args) -> str:
    """Run CLI command, assert non-zero exit, return stderr."""
    result = run(*args)
    assert result.returncode != 0, (
        f"Command {args} expected failure but succeeded:\n{result.stdout}"
    )
    return result.stderr


# ════════════════════════════════════════════════════════════════════════════
# Unit tests
# ════════════════════════════════════════════════════════════════════════════

class TestCrypto(unittest.TestCase):
    """ChaCha20-Poly1305 encryption round-trips."""

    def test_roundtrip_bytes(self):
        """Encrypt then decrypt should return original plaintext."""
        original = b"Hello, Satoshi! \xf0\x9f\x8d\x8a"
        blob     = crypto.encrypt_article(original, "test-slug")
        self.assertNotEqual(blob, original)
        recovered = crypto.decrypt_article(blob, "test-slug")
        self.assertEqual(recovered, original)

    def test_different_nonce_each_time(self):
        """Two encryptions of the same plaintext must produce different blobs."""
        pt   = b"same plaintext"
        enc1 = crypto.encrypt_article(pt, "slug-a")
        enc2 = crypto.encrypt_article(pt, "slug-a")
        self.assertNotEqual(enc1, enc2)

    def test_wrong_slug_fails(self):
        """Decrypting with a different slug (different key) must raise."""
        from cryptography.exceptions import InvalidTag
        blob = crypto.encrypt_article(b"secret", "correct-slug")
        with self.assertRaises(InvalidTag):
            crypto.decrypt_article(blob, "wrong-slug")

    def test_tamper_detection(self):
        """Bit-flipping ciphertext must raise InvalidTag."""
        from cryptography.exceptions import InvalidTag
        blob     = bytearray(crypto.encrypt_article(b"data", "slug"))
        blob[-1] ^= 0xFF
        with self.assertRaises(InvalidTag):
            crypto.decrypt_article(bytes(blob), "slug")

    def test_key_derivation_is_deterministic(self):
        """Same slug → same key every time."""
        k1 = crypto.derive_article_key("my-article")
        k2 = crypto.derive_article_key("my-article")
        self.assertEqual(k1, k2)

    def test_key_derivation_is_distinct_per_slug(self):
        """Different slugs → different keys."""
        k1 = crypto.derive_article_key("slug-one")
        k2 = crypto.derive_article_key("slug-two")
        self.assertNotEqual(k1, k2)

    def test_encrypt_file(self):
        """encrypt_file writes an .enc file that decrypt_file can recover."""
        src = os.path.join(_test_dir, "sample.txt")
        with open(src, "w") as f:
            f.write("File content for testing.\nLine two.")
        enc_path = crypto.encrypt_file(src, "file-test")
        self.assertTrue(os.path.exists(enc_path))
        recovered = crypto.decrypt_file(enc_path, "file-test")
        self.assertEqual(recovered, "File content for testing.\nLine two.")

    def test_encrypt_text(self):
        """encrypt_text writes and decrypt_file recovers correctly."""
        text     = "Inline text encryption test. 🚀"
        enc_path = crypto.encrypt_text(text, "text-test")
        self.assertTrue(os.path.exists(enc_path))
        recovered = crypto.decrypt_file(enc_path, "text-test")
        self.assertEqual(recovered, text)


class TestModels(unittest.TestCase):
    """SQLite model helpers."""

    @classmethod
    def setUpClass(cls):
        models.init_db()

    def test_create_and_get_user(self):
        uid = models.create_user("model_user", "pass")
        self.assertIsNotNone(uid)
        user = models.get_user("model_user")
        self.assertEqual(user["username"], "model_user")

    def test_duplicate_username_raises(self):
        models.create_user("dup_user", "pass")
        with self.assertRaises(ValueError):
            models.create_user("dup_user", "pass")

    def test_verify_user_correct(self):
        models.create_user("verify_user", "correct")
        user = models.verify_user("verify_user", "correct")
        self.assertIsNotNone(user)

    def test_verify_user_wrong_password(self):
        models.create_user("vuser2", "rightpass")
        user = models.verify_user("vuser2", "wrongpass")
        self.assertIsNone(user)

    def test_create_and_get_article(self):
        enc_path = crypto.encrypt_text("content", "model-article")
        aid = models.create_article("model-article", "Model Article", enc_path, 42)
        self.assertIsNotNone(aid)
        art = models.get_article("model-article")
        self.assertEqual(art["title"], "Model Article")
        self.assertEqual(art["price_sats"], 42)

    def test_unlock_and_check(self):
        uid = models.create_user("unlock_test_user", "p")
        enc_path = crypto.encrypt_text("x", "unlock-article")
        aid = models.create_article("unlock-article", "UA", enc_path)
        self.assertFalse(models.is_unlocked(uid, aid))
        models.unlock_article(uid, aid)
        self.assertTrue(models.is_unlocked(uid, aid))

    def test_unlock_idempotent(self):
        uid = models.create_user("idm_user", "p")
        enc_path = crypto.encrypt_text("x", "idm-article")
        aid = models.create_article("idm-article", "IA", enc_path)
        models.unlock_article(uid, aid)
        models.unlock_article(uid, aid)   # must not raise
        self.assertTrue(models.is_unlocked(uid, aid))

    def test_mock_invoice_persistence(self):
        """mock_add_invoice → mock_get_status round trip."""
        ph = hashlib.sha256(b"test-mock-inv").hexdigest()
        models.mock_add_invoice(ph, 100, time.time() + 3600)
        self.assertEqual(models.mock_get_status(ph), "pending")

    def test_mock_invoice_set_paid(self):
        ph = hashlib.sha256(b"test-mock-pay").hexdigest()
        models.mock_add_invoice(ph, 100, time.time() + 3600)
        ok = models.mock_set_paid(ph)
        self.assertTrue(ok)
        self.assertEqual(models.mock_get_status(ph), "paid")

    def test_mock_invoice_expired(self):
        ph = hashlib.sha256(b"test-mock-exp").hexdigest()
        models.mock_add_invoice(ph, 100, time.time() - 1)   # already past
        status = models.mock_get_status(ph)
        self.assertEqual(status, "expired")


class TestLightning(unittest.TestCase):
    """Mock Lightning backend (in-process)."""

    @classmethod
    def setUpClass(cls):
        models.init_db()

    def test_create_invoice_returns_result(self):
        result = lightning.create_invoice("Test invoice", 100)
        self.assertEqual(len(result.payment_hash), 64)
        self.assertTrue(result.payment_request.startswith("lnbcrt"))
        self.assertEqual(result.amount_sats, 100)

    def test_initial_status_is_pending(self):
        result = lightning.create_invoice("Pending test", 50)
        status = lightning.check_invoice(result.payment_hash)
        self.assertEqual(status, InvoiceStatus.PENDING)

    def test_force_pay_settles_invoice(self):
        result = lightning.create_invoice("Force pay test", 75)
        self.assertTrue(lightning.mock_force_pay(result.payment_hash))
        self.assertEqual(lightning.check_invoice(result.payment_hash), InvoiceStatus.PAID)

    def test_force_pay_unknown_hash(self):
        self.assertFalse(lightning.mock_force_pay("0" * 64))

    def test_auto_settle(self):
        """Invoice auto-pays after MOCK_AUTO_SETTLE_SECS seconds."""
        result = lightning.create_invoice("Auto-settle test", 10)
        self.assertEqual(lightning.check_invoice(result.payment_hash), InvoiceStatus.PENDING)
        time.sleep(lightning.MOCK_AUTO_SETTLE_SECS + 1)
        self.assertEqual(lightning.check_invoice(result.payment_hash), InvoiceStatus.PAID)

    def test_check_unknown_hash(self):
        status = lightning.check_invoice("f" * 64)
        self.assertEqual(status, InvoiceStatus.FAILED)


class TestPaywallService(unittest.TestCase):
    """High-level service layer (paywall.py)."""

    @classmethod
    def setUpClass(cls):
        models.init_db()

    def _make_user(self, name):
        try:
            return paywall.register_user(name, "testpass")
        except paywall.PaywallError:
            return models.get_user(name)["id"]

    def _make_article(self, slug, title="Test Article", price=100):
        try:
            return paywall.add_article_from_text(
                f"Content of {slug}", slug, title, price_sats=price
            )
        except paywall.PaywallError:
            return models.get_article(slug)["id"]

    def test_register_and_authenticate(self):
        self._make_user("svc_auth_user")
        user = paywall.authenticate("svc_auth_user", "testpass")
        self.assertEqual(user["username"], "svc_auth_user")

    def test_authenticate_bad_password(self):
        self._make_user("svc_badpass")
        with self.assertRaises(paywall.PaywallError):
            paywall.authenticate("svc_badpass", "wrongpassword")

    def test_add_and_list_articles(self):
        self._make_article("svc-list-art")
        articles = paywall.get_all_articles()
        slugs = [a["slug"] for a in articles]
        self.assertIn("svc-list-art", slugs)

    def test_read_locked_article_raises(self):
        self._make_user("svc_locked_user")
        self._make_article("svc-locked-art")
        with self.assertRaises(paywall.PaywallError) as ctx:
            paywall.read_article("svc_locked_user", "svc-locked-art")
        self.assertIn("locked", str(ctx.exception))

    def test_full_invoice_pay_read_workflow(self):
        """End-to-end: register → add article → invoice → pay → read."""
        self._make_user("svc_full_user")
        self._make_article("svc-full-art", "Full Workflow Article")

        # Generate invoice
        result = paywall.generate_invoice("svc_full_user", "svc-full-art")
        self.assertEqual(len(result.payment_hash), 64)

        # Not yet paid
        status = paywall.check_and_unlock("svc_full_user", "svc-full-art", result.payment_hash)
        self.assertEqual(status, InvoiceStatus.PENDING)

        # Force-pay
        lightning.mock_force_pay(result.payment_hash)

        # Now should unlock
        status = paywall.check_and_unlock("svc_full_user", "svc-full-art", result.payment_hash)
        self.assertEqual(status, InvoiceStatus.PAID)

        # Read content
        content = paywall.read_article("svc_full_user", "svc-full-art")
        self.assertIn("svc-full-art", content)

    def test_invoice_reuse_for_pending_payment(self):
        """Calling generate_invoice twice returns the same payment_hash."""
        self._make_user("svc_reuse_user")
        self._make_article("svc-reuse-art")
        r1 = paywall.generate_invoice("svc_reuse_user", "svc-reuse-art")
        r2 = paywall.generate_invoice("svc_reuse_user", "svc-reuse-art")
        self.assertEqual(r1.payment_hash, r2.payment_hash)

    def test_already_unlocked_raises_on_new_invoice(self):
        """Once unlocked, generate_invoice raises PaywallError."""
        self._make_user("svc_already_user")
        self._make_article("svc-already-art")
        result = paywall.generate_invoice("svc_already_user", "svc-already-art")
        lightning.mock_force_pay(result.payment_hash)
        paywall.check_and_unlock("svc_already_user", "svc-already-art", result.payment_hash)
        with self.assertRaises(paywall.PaywallError):
            paywall.generate_invoice("svc_already_user", "svc-already-art")

    def test_list_user_articles_shows_unlock_status(self):
        self._make_user("svc_list_u")
        self._make_article("svc-list-locked-art")
        self._make_article("svc-list-paid-art")

        # Pay for one article
        result = paywall.generate_invoice("svc_list_u", "svc-list-paid-art")
        lightning.mock_force_pay(result.payment_hash)
        paywall.check_and_unlock("svc_list_u", "svc-list-paid-art", result.payment_hash)

        articles = paywall.list_user_articles("svc_list_u")
        by_slug  = {a["slug"]: a for a in articles}
        self.assertTrue(by_slug["svc-list-paid-art"]["unlocked"])
        self.assertFalse(by_slug["svc-list-locked-art"]["unlocked"])


# ════════════════════════════════════════════════════════════════════════════
# Cross-process CLI integration tests
# (These prove force-pay works across separate Python invocations.)
# ════════════════════════════════════════════════════════════════════════════

class TestCLICrossProcess(unittest.TestCase):
    """Integration tests that call the CLI as a subprocess."""

    @classmethod
    def setUpClass(cls):
        """Bootstrap a fresh DB and two articles for CLI tests."""
        cli_ok("init-db")
        cli_ok("register", "-u", "cli_alice", "-p", "alicepass")
        cli_ok("register", "-u", "cli_bob",   "-p", "bobpass")

        # Article 1: auto-pay test
        cli_ok("add-article",
               "--slug",  "cli-auto",
               "--title", "CLI Auto-Pay Test",
               "--price", "30",
               "--file",  _write_tmp("Auto-pay article content.\n\nParagraph two."))

        # Article 2: force-pay test
        cli_ok("add-article",
               "--slug",  "cli-force",
               "--title", "CLI Force-Pay Test",
               "--price", "20",
               "--file",  _write_tmp("Force-pay article content.\n\nParagraph two."))

    def test_list_articles_shows_locked(self):
        out = cli_ok("list-articles", "-u", "cli_alice")
        self.assertIn("cli-auto",  out)
        self.assertIn("cli-force", out)
        self.assertIn("locked",    out)

    def test_invoice_generation_output(self):
        out = cli_ok("invoice", "-u", "cli_alice", "--slug", "cli-force")
        self.assertIn("payment hash", out.lower())
        self.assertIn("lnbcrt", out)

    def test_force_pay_cross_process(self):
        """
        Generate invoice in one subprocess, force-pay in a second subprocess,
        then check-payment in a third.  All must work because state is in SQLite.
        """
        # 1. Generate invoice (subprocess A)
        out_invoice = cli_ok("invoice", "-u", "cli_bob", "--slug", "cli-force")
        pay_hash = _extract_hash(out_invoice)
        self.assertIsNotNone(pay_hash, f"Could not find payment hash in:\n{out_invoice}")

        # 2. Verify still pending (subprocess B)
        out_check1 = run("check-payment", "-u", "cli_bob",
                         "--slug", "cli-force", "--hash", pay_hash)
        self.assertIn("pending", out_check1.stdout + out_check1.stderr)

        # 3. Force-pay (subprocess C — the key cross-process test)
        cli_ok("force-pay", "--hash", pay_hash)

        # 4. Check-payment should now unlock (subprocess D)
        out_check2 = cli_ok("check-payment", "-u", "cli_bob",
                            "--slug", "cli-force", "--hash", pay_hash)
        self.assertIn("confirmed", out_check2.lower())

        # 5. Read the article (subprocess E)
        out_read = cli_ok("read", "-u", "cli_bob", "--slug", "cli-force")
        self.assertIn("Force-pay article", out_read)

    def test_auto_pay_then_read(self):
        """
        Generate invoice, wait for DB-based auto-settle, poll until paid, read.

        The mock backend records ``auto_settle_at = now + MOCK_AUTO_SETTLE_SECS``
        in SQLite at creation time.  Any process calling check-payment after
        that timestamp will see the invoice transition to 'paid' — no daemon
        thread required, fully cross-process safe.
        """
        out_invoice = cli_ok("invoice", "-u", "cli_alice", "--slug", "cli-auto")
        pay_hash    = _extract_hash(out_invoice)
        self.assertIsNotNone(pay_hash, f"hash not found in:\n{out_invoice}")

        # Wait well past auto_settle_at so the next check-payment sees it as paid
        wait = lightning.MOCK_AUTO_SETTLE_SECS + 2
        time.sleep(wait)

        out_check = cli_ok("check-payment", "-u", "cli_alice",
                           "--slug", "cli-auto", "--hash", pay_hash)
        self.assertIn("confirmed", out_check.lower(),
                      f"Expected 'confirmed' after {wait}s wait.\nOutput:\n{out_check}")

        out_read = cli_ok("read", "-u", "cli_alice", "--slug", "cli-auto")
        self.assertIn("Auto-pay article", out_read)

    def test_read_locked_article_fails(self):
        err = cli_fail("read", "-u", "cli_alice", "--slug", "cli-force")
        # cli_force may or may not be locked for alice depending on test order
        # — use a brand-new slug that is definitely locked
        tmp_slug = "cli-definitely-locked"
        cli_ok("add-article",
               "--slug",  tmp_slug,
               "--title", "Definitely Locked",
               "--price", "999",
               "--file",  _write_tmp("you should not see this"))
        err = cli_fail("read", "-u", "cli_alice", "--slug", tmp_slug)
        self.assertIn("locked", err.lower())

    def test_list_payments(self):
        out = cli_ok("list-payments", "-u", "cli_bob")
        self.assertIn("cli-force", out)

    def test_duplicate_register_fails(self):
        out = cli_fail("register", "-u", "cli_alice", "-p", "newpass")
        self.assertIn("already", out.lower())

    def test_invoice_unknown_user_fails(self):
        err = cli_fail("invoice", "-u", "nobody_user", "--slug", "cli-auto")
        self.assertIn("not found", err.lower())

    def test_invoice_unknown_article_fails(self):
        err = cli_fail("invoice", "-u", "cli_alice", "--slug", "no-such-article")
        self.assertIn("not found", err.lower())


# ════════════════════════════════════════════════════════════════════════════
# Flask API integration tests
# ════════════════════════════════════════════════════════════════════════════

class TestFlaskAPI(unittest.TestCase):
    """Exercise the REST API using Flask's test client."""

    @classmethod
    def setUpClass(cls):
        models.init_db()
        from api import app
        app.config["TESTING"] = True
        cls.client = app.test_client()

        # Seed DB for API tests
        try:
            paywall.register_user("api_user", "apipass")
        except paywall.PaywallError:
            pass
        try:
            paywall.add_article_from_text(
                "API article content. \n\nMore text.",
                "api-article", "API Test Article", price_sats=60
            )
        except paywall.PaywallError:
            pass

    def _auth(self, username="api_user", password="apipass"):
        import base64
        token = base64.b64encode(f"{username}:{password}".encode()).decode()
        return {"Authorization": f"Basic {token}"}

    def test_health(self):
        r = self.client.get("/api/health")
        self.assertEqual(r.status_code, 200)
        data = json.loads(r.data)
        self.assertEqual(data["status"], "ok")
        self.assertTrue(data["ln_mock"])

    def test_register_new_user(self):
        r = self.client.post("/api/register",
                             json={"username": "api_new", "password": "pw"})
        self.assertEqual(r.status_code, 201)
        data = json.loads(r.data)
        self.assertEqual(data["username"], "api_new")

    def test_register_duplicate_fails(self):
        self.client.post("/api/register", json={"username": "dup_api", "password": "p"})
        r = self.client.post("/api/register", json={"username": "dup_api", "password": "p"})
        self.assertEqual(r.status_code, 409)

    def test_articles_requires_auth(self):
        r = self.client.get("/api/articles")
        self.assertEqual(r.status_code, 401)

    def test_list_articles_authenticated(self):
        r = self.client.get("/api/articles", headers=self._auth())
        self.assertEqual(r.status_code, 200)
        articles = json.loads(r.data)
        self.assertIsInstance(articles, list)
        slugs = [a["slug"] for a in articles]
        self.assertIn("api-article", slugs)

    def test_generate_invoice(self):
        """Dedicated article so ordering with test_check_payment_and_read_full_flow doesn't matter."""
        try:
            paywall.add_article_from_text(
                "Invoice-only article.", "api-invoice-only", "Invoice Only Article", price_sats=60
            )
        except paywall.PaywallError:
            pass
        r = self.client.post("/api/invoice",
                             json={"slug": "api-invoice-only"},
                             headers=self._auth())
        self.assertEqual(r.status_code, 200)
        data = json.loads(r.data)
        self.assertIn("payment_hash",    data)
        self.assertIn("payment_request", data)
        self.assertEqual(data["amount_sats"], 60)

    def test_check_payment_and_read_full_flow(self):
        """Generate → dev/force-pay → check-payment → read (dedicated slug)."""
        try:
            paywall.add_article_from_text(
                "Full flow article content.\n\nMore text.",
                "api-fullflow", "Full Flow Article", price_sats=60
            )
        except paywall.PaywallError:
            pass
        # Generate
        r = self.client.post("/api/invoice",
                             json={"slug": "api-fullflow"},
                             headers=self._auth())
        self.assertEqual(r.status_code, 200)
        pay_hash = json.loads(r.data)["payment_hash"]

        # Force-pay via dev endpoint
        r = self.client.post("/api/dev/force-pay",
                             json={"payment_hash": pay_hash})
        self.assertEqual(r.status_code, 200)
        self.assertTrue(json.loads(r.data)["settled"])

        # Check-payment should return paid
        r = self.client.post("/api/check-payment",
                             json={"slug": "api-fullflow", "payment_hash": pay_hash},
                             headers=self._auth())
        self.assertEqual(r.status_code, 200)
        self.assertEqual(json.loads(r.data)["status"], "paid")

        # Read
        r = self.client.get("/api/read/api-fullflow", headers=self._auth())
        self.assertEqual(r.status_code, 200)
        data = json.loads(r.data)
        self.assertIn("Full flow article content", data["content"])

    def test_read_locked_returns_402(self):
        # New user who hasn't paid
        self.client.post("/api/register", json={"username": "broke_user", "password": "bp"})
        auth = self._auth("broke_user", "bp")

        # Need to add an article that broke_user hasn't paid for
        try:
            paywall.add_article_from_text("Expensive", "api-expensive", "Expensive", price_sats=999)
        except paywall.PaywallError:
            pass

        r = self.client.get("/api/read/api-expensive", headers=auth)
        self.assertEqual(r.status_code, 402)

    def test_dev_force_pay_unknown_hash(self):
        r = self.client.post("/api/dev/force-pay",
                             json={"payment_hash": "0" * 64})
        self.assertEqual(r.status_code, 404)

    def test_invoice_missing_slug(self):
        r = self.client.post("/api/invoice", json={}, headers=self._auth())
        self.assertEqual(r.status_code, 400)

    def test_bad_credentials_rejected(self):
        r = self.client.get("/api/articles",
                            headers=self._auth("api_user", "wrongpassword"))
        self.assertEqual(r.status_code, 401)


# ── Helpers ──────────────────────────────────────────────────────────────────

def _write_tmp(text: str) -> str:
    """Write text to a temp file, return the file path."""
    fd, path = tempfile.mkstemp(dir=_test_dir, suffix=".txt")
    os.write(fd, text.encode())
    os.close(fd)
    return path


def _extract_hash(cli_output: str):
    """Parse a payment hash from CLI invoice output."""
    for line in cli_output.splitlines():
        low = line.lower()
        if "payment hash" in low or "hash" in low:
            parts = line.split()
            for p in reversed(parts):
                if len(p) == 64 and all(c in "0123456789abcdef" for c in p.lower()):
                    return p.lower()
    return None


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print(f"\n[test] Isolated test directory: {_test_dir}")
    print(f"[test] DB path              : {config.DB_PATH}")
    print(f"[test] Articles dir         : {config.ARTICLES_DIR}\n")

    try:
        loader  = unittest.TestLoader()
        suite   = unittest.TestSuite()

        # Order matters: unit tests first, then integration
        for cls in [TestCrypto, TestModels, TestLightning,
                    TestPaywallService, TestCLICrossProcess, TestFlaskAPI]:
            suite.addTests(loader.loadTestsFromTestCase(cls))

        runner = unittest.TextTestRunner(verbosity=2)
        result = runner.run(suite)
    finally:
        shutil.rmtree(_test_dir, ignore_errors=True)

    sys.exit(0 if result.wasSuccessful() else 1)
