"""
models.py — SQLite database schema, initialization, and helper queries.

Tables
──────
users        : registered users (username + hashed secret)
articles     : article metadata (id, slug, title, price, encrypted file path)
payments     : Lightning invoices linked to a user + article
unlocked     : join table recording which users have paid for which articles

All DB access uses the standard `sqlite3` module with context-manager
commits/rollbacks so we never leave partial writes in the database.
"""

import hashlib
import os
import sqlite3
import time
from contextlib import contextmanager
from typing import Generator, Optional

import config

# ── Connection helper ─────────────────────────────────────────────────────────

@contextmanager
def get_db() -> Generator[sqlite3.Connection, None, None]:
    """Yield a sqlite3 connection with row_factory set to sqlite3.Row."""
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ── Schema creation ───────────────────────────────────────────────────────────

def init_db() -> None:
    """Create all tables if they do not already exist."""
    with get_db() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                username    TEXT    NOT NULL UNIQUE,
                secret_hash TEXT    NOT NULL,           -- SHA-256 of password
                created_at  INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS articles (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                slug        TEXT    NOT NULL UNIQUE,    -- URL-friendly identifier
                title       TEXT    NOT NULL,
                description TEXT,
                price_sats  INTEGER NOT NULL DEFAULT 100,
                enc_path    TEXT    NOT NULL,           -- path to encrypted file
                created_at  INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS payments (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id         INTEGER NOT NULL REFERENCES users(id),
                article_id      INTEGER NOT NULL REFERENCES articles(id),
                payment_hash    TEXT    NOT NULL UNIQUE,  -- LN payment hash (hex)
                payment_request TEXT    NOT NULL,          -- BOLT-11 invoice string
                amount_sats     INTEGER NOT NULL,
                status          TEXT    NOT NULL DEFAULT 'pending',
                    -- status values: pending | paid | expired | failed
                created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),
                settled_at      INTEGER
            );

            CREATE TABLE IF NOT EXISTS unlocked (
                user_id     INTEGER NOT NULL REFERENCES users(id),
                article_id  INTEGER NOT NULL REFERENCES articles(id),
                unlocked_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
                PRIMARY KEY (user_id, article_id)
            );

            CREATE INDEX IF NOT EXISTS idx_payments_hash
                ON payments(payment_hash);

            CREATE INDEX IF NOT EXISTS idx_payments_user_article
                ON payments(user_id, article_id);

            -- Persistent storage for mock Lightning invoices so that state
            -- survives across separate CLI process invocations.
            -- auto_settle_at: Unix timestamp after which pending → paid
            -- (cross-process safe — no daemon thread required for settlement).
            CREATE TABLE IF NOT EXISTS mock_invoices (
                payment_hash   TEXT  PRIMARY KEY,
                amount_sats    INTEGER NOT NULL,
                deadline       REAL    NOT NULL,   -- invoice expiry (Unix ts)
                auto_settle_at REAL    NOT NULL,   -- mock payment time (Unix ts)
                status         TEXT    NOT NULL DEFAULT 'pending'
                    -- pending | paid | expired
            );
        """)
    print(f"[db] Database initialised at {config.DB_PATH}")


# ── User helpers ──────────────────────────────────────────────────────────────

def _hash_secret(secret: str) -> str:
    """Return a hex SHA-256 digest of the secret string."""
    return hashlib.sha256(secret.encode()).hexdigest()


def create_user(username: str, password: str) -> int:
    """
    Insert a new user and return their row id.
    Raises ValueError if the username is already taken.
    """
    with get_db() as conn:
        try:
            cur = conn.execute(
                "INSERT INTO users (username, secret_hash) VALUES (?, ?)",
                (username, _hash_secret(password)),
            )
            return cur.lastrowid
        except sqlite3.IntegrityError:
            raise ValueError(f"Username '{username}' is already taken.")


def get_user(username: str) -> Optional[sqlite3.Row]:
    """Return the user row for *username*, or None if not found."""
    with get_db() as conn:
        return conn.execute(
            "SELECT * FROM users WHERE username = ?", (username,)
        ).fetchone()


def verify_user(username: str, password: str) -> Optional[sqlite3.Row]:
    """
    Return the user row if credentials are valid, else None.
    Used by the Flask API for basic auth checks.
    """
    user = get_user(username)
    if user and user["secret_hash"] == _hash_secret(password):
        return user
    return None


# ── Article helpers ───────────────────────────────────────────────────────────

def create_article(
    slug: str,
    title: str,
    enc_path: str,
    price_sats: int = config.DEFAULT_PRICE_SATS,
    description: str = "",
) -> int:
    """Insert article metadata and return its row id."""
    with get_db() as conn:
        try:
            cur = conn.execute(
                """INSERT INTO articles (slug, title, description, price_sats, enc_path)
                   VALUES (?, ?, ?, ?, ?)""",
                (slug, title, description, price_sats, enc_path),
            )
            return cur.lastrowid
        except sqlite3.IntegrityError:
            raise ValueError(f"Article slug '{slug}' already exists.")


def get_article(slug: str) -> Optional[sqlite3.Row]:
    """Fetch an article by its slug."""
    with get_db() as conn:
        return conn.execute(
            "SELECT * FROM articles WHERE slug = ?", (slug,)
        ).fetchone()


def list_articles() -> list:
    """Return all articles ordered by creation date."""
    with get_db() as conn:
        return conn.execute(
            "SELECT * FROM articles ORDER BY created_at DESC"
        ).fetchall()


# ── Payment helpers ───────────────────────────────────────────────────────────

def create_payment(
    user_id: int,
    article_id: int,
    payment_hash: str,
    payment_request: str,
    amount_sats: int,
) -> int:
    """Record a newly generated Lightning invoice."""
    with get_db() as conn:
        cur = conn.execute(
            """INSERT INTO payments
               (user_id, article_id, payment_hash, payment_request, amount_sats)
               VALUES (?, ?, ?, ?, ?)""",
            (user_id, article_id, payment_hash, payment_request, amount_sats),
        )
        return cur.lastrowid


def get_payment_by_hash(payment_hash: str) -> Optional[sqlite3.Row]:
    """Look up a payment record by its Lightning payment hash."""
    with get_db() as conn:
        return conn.execute(
            "SELECT * FROM payments WHERE payment_hash = ?", (payment_hash,)
        ).fetchone()


def get_pending_payment(user_id: int, article_id: int) -> Optional[sqlite3.Row]:
    """Return any still-pending payment for this user+article pair."""
    with get_db() as conn:
        return conn.execute(
            """SELECT * FROM payments
               WHERE user_id = ? AND article_id = ? AND status = 'pending'
               ORDER BY created_at DESC LIMIT 1""",
            (user_id, article_id),
        ).fetchone()


def mark_payment_paid(payment_hash: str) -> None:
    """Update payment status to 'paid' and record settlement timestamp."""
    with get_db() as conn:
        conn.execute(
            """UPDATE payments
               SET status = 'paid', settled_at = ?
               WHERE payment_hash = ?""",
            (int(time.time()), payment_hash),
        )


def mark_payment_expired(payment_hash: str) -> None:
    """Mark an invoice as expired."""
    with get_db() as conn:
        conn.execute(
            "UPDATE payments SET status = 'expired' WHERE payment_hash = ?",
            (payment_hash,),
        )


# ── Unlock helpers ────────────────────────────────────────────────────────────

def unlock_article(user_id: int, article_id: int) -> None:
    """
    Grant a user access to an article.
    INSERT OR IGNORE prevents duplicate rows if called twice.
    """
    with get_db() as conn:
        conn.execute(
            """INSERT OR IGNORE INTO unlocked (user_id, article_id)
               VALUES (?, ?)""",
            (user_id, article_id),
        )


def is_unlocked(user_id: int, article_id: int) -> bool:
    """Return True if the user has paid for (unlocked) this article."""
    with get_db() as conn:
        row = conn.execute(
            "SELECT 1 FROM unlocked WHERE user_id = ? AND article_id = ?",
            (user_id, article_id),
        ).fetchone()
        return row is not None


def list_unlocked_for_user(user_id: int) -> list:
    """
    Return all articles unlocked by a user, joined with article metadata.
    """
    with get_db() as conn:
        return conn.execute(
            """SELECT a.*, u.unlocked_at
               FROM unlocked u
               JOIN articles a ON a.id = u.article_id
               WHERE u.user_id = ?
               ORDER BY u.unlocked_at DESC""",
            (user_id,),
        ).fetchall()


# ── Mock invoice helpers (persistent mock Lightning backend) ──────────────────

def mock_add_invoice(
    payment_hash: str,
    amount_sats: int,
    deadline: float,
    auto_settle_secs: int = 5,
) -> None:
    """
    Persist a new mock invoice to the DB.

    ``auto_settle_at`` is set to ``now + auto_settle_secs`` so that any
    process calling :func:`mock_get_status` after that time will see the
    invoice as 'paid' — no daemon thread required.
    """
    import time as _time
    auto_settle_at = _time.time() + auto_settle_secs
    with get_db() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO mock_invoices
               (payment_hash, amount_sats, deadline, auto_settle_at, status)
               VALUES (?, ?, ?, ?, 'pending')""",
            (payment_hash, amount_sats, deadline, auto_settle_at),
        )


def mock_get_status(payment_hash: str) -> Optional[str]:
    """
    Return the stored status for a mock invoice, or None if unknown.

    State machine (evaluated lazily on each read — cross-process safe):
      pending + now >= auto_settle_at  →  paid    (simulates payment arrival)
      pending + now >  deadline        →  expired
      otherwise                        →  pending / paid / expired as stored
    """
    import time as _time
    now = _time.time()
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM mock_invoices WHERE payment_hash = ?",
            (payment_hash,),
        ).fetchone()
        if row is None:
            return None
        if row["status"] == "pending":
            if now >= row["auto_settle_at"]:
                conn.execute(
                    "UPDATE mock_invoices SET status = 'paid' WHERE payment_hash = ?",
                    (payment_hash,),
                )
                return "paid"
            if now > row["deadline"]:
                conn.execute(
                    "UPDATE mock_invoices SET status = 'expired' WHERE payment_hash = ?",
                    (payment_hash,),
                )
                return "expired"
        return row["status"]


def mock_set_paid(payment_hash: str) -> bool:
    """Mark a pending mock invoice as paid immediately. Returns True on success."""
    with get_db() as conn:
        cur = conn.execute(
            """UPDATE mock_invoices SET status = 'paid'
               WHERE payment_hash = ? AND status = 'pending'""",
            (payment_hash,),
        )
        return cur.rowcount > 0
