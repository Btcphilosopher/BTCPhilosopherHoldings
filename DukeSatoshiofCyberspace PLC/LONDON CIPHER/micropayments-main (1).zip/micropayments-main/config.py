"""
config.py — Central configuration for the Lightning paywall system.

Loads settings from environment variables with sane defaults for local dev.
All sensitive values (macaroon, TLS cert, master key) should be set via
environment variables in production — never hard-code secrets.
"""

import os
import secrets

# ── Database ──────────────────────────────────────────────────────────────────
DB_PATH: str = os.getenv("PAYWALL_DB_PATH", "paywall.db")

# ── Article storage ───────────────────────────────────────────────────────────
ARTICLES_DIR: str = os.getenv("PAYWALL_ARTICLES_DIR", "articles")

# ── Master encryption key (32 bytes hex) ─────────────────────────────────────
# Used to derive per-article keys via HKDF-SHA256.
#
# Priority:
#   1. PAYWALL_MASTER_KEY env var  (production — use a secrets manager)
#   2. .paywall_master_key file     (auto-generated on first run, dev/demo)
#
# Generate and export a production key once:
#   python -c "import secrets; print(secrets.token_hex(32))"
#   export PAYWALL_MASTER_KEY=<output>
#
# WARNING: losing the master key makes all encrypted articles unreadable.

_KEY_FILE = os.getenv("PAYWALL_KEY_FILE", ".paywall_master_key")

_raw_key = os.getenv("PAYWALL_MASTER_KEY", "").strip()
if _raw_key:
    # Explicit env var takes highest priority.
    MASTER_KEY: bytes = bytes.fromhex(_raw_key)
else:
    # Persist an auto-generated key in a local file so the key survives
    # across separate CLI / server process invocations in dev mode.
    if os.path.exists(_KEY_FILE):
        with open(_KEY_FILE, "r") as _kf:
            MASTER_KEY = bytes.fromhex(_kf.read().strip())
    else:
        _new_key = secrets.token_hex(32)
        try:
            with open(_KEY_FILE, "w") as _kf:
                _kf.write(_new_key)
            # Restrict permissions so only the owner can read the file.
            os.chmod(_KEY_FILE, 0o600)
        except OSError:
            pass   # Read-only FS or permission denied — use ephemeral key.
        MASTER_KEY = bytes.fromhex(_new_key)

# ── Lightning Node connection ─────────────────────────────────────────────────
# Supports LND (REST) and c-lightning / CLN (REST plugin).
# Set PAYWALL_LN_BACKEND to "lnd" or "cln".
LN_BACKEND: str = os.getenv("PAYWALL_LN_BACKEND", "lnd")       # "lnd" | "cln"
LN_HOST: str = os.getenv("PAYWALL_LN_HOST", "localhost")
LN_PORT: int = int(os.getenv("PAYWALL_LN_PORT", "8080"))        # LND REST default
LN_MACAROON_HEX: str = os.getenv("PAYWALL_LN_MACAROON", "")    # hex-encoded macaroon
LN_TLS_CERT_PATH: str = os.getenv("PAYWALL_LN_TLS_CERT", "")   # path to tls.cert

# Simulated / mock mode — no real node required (for demos and testing).
LN_MOCK: bool = os.getenv("PAYWALL_LN_MOCK", "true").lower() in ("1", "true", "yes")

# Default invoice expiry in seconds (1 hour).
INVOICE_EXPIRY_SECONDS: int = int(os.getenv("PAYWALL_INVOICE_EXPIRY", "3600"))

# ── Flask web server ──────────────────────────────────────────────────────────
FLASK_HOST: str = os.getenv("PAYWALL_FLASK_HOST", "127.0.0.1")
FLASK_PORT: int = int(os.getenv("PAYWALL_FLASK_PORT", "5000"))
FLASK_DEBUG: bool = os.getenv("PAYWALL_FLASK_DEBUG", "false").lower() in ("1", "true")
FLASK_SECRET_KEY: str = os.getenv("PAYWALL_FLASK_SECRET", secrets.token_hex(24))

# ── Article prices ────────────────────────────────────────────────────────────
DEFAULT_PRICE_SATS: int = int(os.getenv("PAYWALL_DEFAULT_PRICE_SATS", "100"))
