"""
api.py — Flask REST API for the Lightning paywall system.

Endpoints
─────────
  POST /api/register                      — Register a new user.
  GET  /api/articles?username=<u>         — List articles with unlock status.
  POST /api/invoice                       — Generate a Lightning invoice.
  POST /api/check-payment                 — Check payment + unlock article.
  GET  /api/read/<slug>?username=<u>      — Read an unlocked article.

Authentication is handled via HTTP Basic Auth on protected endpoints.
All responses use JSON.  Errors return {"error": "<message>"} with an
appropriate HTTP status code.
"""

from functools import wraps

from flask import Flask, jsonify, request

import config
import models
import paywall
from lightning import InvoiceStatus

app = Flask(__name__)
app.secret_key = config.FLASK_SECRET_KEY


# ── Authentication helper ─────────────────────────────────────────────────────

def require_basic_auth(f):
    """
    Decorator that validates HTTP Basic Auth credentials.
    On success, injects ``current_user`` (sqlite3.Row) into the wrapped
    function as a keyword argument.
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth:
            return (
                jsonify({"error": "Authentication required."}),
                401,
                {"WWW-Authenticate": 'Basic realm="Paywall"'},
            )
        try:
            user = paywall.authenticate(auth.username, auth.password)
        except paywall.PaywallError as exc:
            return jsonify({"error": str(exc)}), 401
        return f(*args, current_user=user, **kwargs)
    return decorated


# ── Health check ──────────────────────────────────────────────────────────────

@app.get("/api/health")
def health():
    """Simple liveness check."""
    return jsonify({
        "status":   "ok",
        "ln_mock":  config.LN_MOCK,
        "backend":  config.LN_BACKEND,
    })


# ── User registration ─────────────────────────────────────────────────────────

@app.post("/api/register")
def register():
    """
    Register a new user.

    Request body (JSON):
        { "username": "alice", "password": "secret" }
    """
    data = request.get_json(silent=True) or {}
    username = data.get("username", "").strip()
    password = data.get("password", "")

    if not username or not password:
        return jsonify({"error": "username and password are required."}), 400

    try:
        uid = paywall.register_user(username, password)
        return jsonify({"id": uid, "username": username}), 201
    except paywall.PaywallError as exc:
        return jsonify({"error": str(exc)}), 409


# ── Article listing ───────────────────────────────────────────────────────────

@app.get("/api/articles")
@require_basic_auth
def list_articles(current_user):
    """
    Return all articles with unlock status for the authenticated user.

    Response:
        [{ "slug": "…", "title": "…", "price_sats": 100, "unlocked": false }, …]
    """
    articles = paywall.list_user_articles(current_user["username"])
    return jsonify(articles)


# ── Invoice generation ────────────────────────────────────────────────────────

@app.post("/api/invoice")
@require_basic_auth
def create_invoice(current_user):
    """
    Generate (or reuse) a Lightning invoice for an article.

    Request body (JSON):
        { "slug": "my-article" }

    Response:
        {
          "payment_hash":    "…",
          "payment_request": "lnbc…",
          "amount_sats":     100,
          "expiry_seconds":  3600
        }
    """
    data = request.get_json(silent=True) or {}
    slug = data.get("slug", "").strip()
    if not slug:
        return jsonify({"error": "'slug' is required."}), 400

    try:
        result = paywall.generate_invoice(current_user["username"], slug)
        return jsonify({
            "payment_hash":    result.payment_hash,
            "payment_request": result.payment_request,
            "amount_sats":     result.amount_sats,
            "expiry_seconds":  result.expiry_seconds,
        })
    except paywall.PaywallError as exc:
        return jsonify({"error": str(exc)}), 400


# ── Payment check + unlock ────────────────────────────────────────────────────

@app.post("/api/check-payment")
@require_basic_auth
def check_payment(current_user):
    """
    Poll payment status and unlock the article if the invoice has been paid.

    Request body (JSON):
        { "slug": "my-article", "payment_hash": "abc123…" }

    Response:
        { "status": "paid" | "pending" | "expired" | "failed" }
    """
    data = request.get_json(silent=True) or {}
    slug         = data.get("slug", "").strip()
    payment_hash = data.get("payment_hash", "").strip()

    if not slug or not payment_hash:
        return jsonify({"error": "'slug' and 'payment_hash' are required."}), 400

    try:
        status = paywall.check_and_unlock(
            current_user["username"], slug, payment_hash
        )
        http_code = 200 if status == InvoiceStatus.PAID else 202
        return jsonify({"status": status.value}), http_code
    except paywall.PaywallError as exc:
        return jsonify({"error": str(exc)}), 400


# ── Article reading ───────────────────────────────────────────────────────────

@app.get("/api/read/<slug>")
@require_basic_auth
def read_article(slug, current_user):
    """
    Return the decrypted content of an unlocked article.

    Response:
        {
          "slug":    "my-article",
          "title":   "…",
          "content": "Full article text…"
        }
    """
    try:
        content = paywall.read_article(current_user["username"], slug)
        article = models.get_article(slug)
        return jsonify({
            "slug":    article["slug"],
            "title":   article["title"],
            "content": content,
        })
    except paywall.PaywallError as exc:
        status_code = 402 if "locked" in str(exc) else 404
        return jsonify({"error": str(exc)}), status_code


# ── Mock force-pay (dev helper) ───────────────────────────────────────────────

@app.post("/api/dev/force-pay")
def dev_force_pay():
    """
    [MOCK MODE ONLY] Immediately settle a pending invoice.
    This endpoint is disabled unless LN_MOCK is True.

    Request body (JSON):
        { "payment_hash": "abc123…" }
    """
    if not config.LN_MOCK:
        return jsonify({"error": "This endpoint is only available in mock mode."}), 403

    data         = request.get_json(silent=True) or {}
    payment_hash = data.get("payment_hash", "").strip()
    if not payment_hash:
        return jsonify({"error": "'payment_hash' is required."}), 400

    from lightning import mock_force_pay
    if mock_force_pay(payment_hash):
        return jsonify({"settled": True})
    return jsonify({"error": "Invoice not found or already settled."}), 404


# ── Run server ────────────────────────────────────────────────────────────────

def run_server() -> None:
    """Start the Flask development server."""
    print(f"[api] Starting Flask on {config.FLASK_HOST}:{config.FLASK_PORT}")
    app.run(
        host  = config.FLASK_HOST,
        port  = config.FLASK_PORT,
        debug = config.FLASK_DEBUG,
    )
