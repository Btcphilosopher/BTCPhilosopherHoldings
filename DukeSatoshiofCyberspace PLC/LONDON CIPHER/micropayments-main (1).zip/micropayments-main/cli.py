"""
cli.py — Command-line interface for the Lightning paywall system.

Commands
────────
  init-db               Initialise (or migrate) the SQLite database.
  register              Create a new user account.
  add-article           Encrypt and register a new article (from file or text).
  list-articles         Show all articles and per-user unlock status.
  invoice               Generate a Lightning invoice for an article.
  check-payment         Poll payment status and unlock article if paid.
  read                  Print the decrypted content of an unlocked article.
  force-pay             (Mock only) Immediately mark an invoice as paid.
  demo                  Run an end-to-end demo: create user, article, pay, read.

Run ``python main.py --help`` for the full list.
"""

import sys
import textwrap
import time

import click

import config
import models
import paywall
from lightning import InvoiceStatus, mock_force_pay


# ── Shared option decorators ──────────────────────────────────────────────────

def user_option(fn):
    return click.option(
        "-u", "--username", required=True, help="Your username."
    )(fn)


def pass_option(fn):
    return click.option(
        "-p", "--password", default="", help="Your password (omit to be prompted)."
    )(fn)


# ── CLI group ─────────────────────────────────────────────────────────────────

@click.group()
def cli():
    """
    ⚡  Lightning Paywall — micropay-per-article system.

    Set PAYWALL_LN_MOCK=false and configure your node credentials to use a
    real Lightning node, or keep the default mock mode for local testing.
    """


# ── init-db ───────────────────────────────────────────────────────────────────

@cli.command("init-db")
def cmd_init_db():
    """Initialise (or migrate) the SQLite database."""
    models.init_db()
    click.secho("✓ Database ready.", fg="green")


# ── register ──────────────────────────────────────────────────────────────────

@cli.command("register")
@click.option("-u", "--username", required=True, prompt=True, help="Desired username.")
@click.option(
    "-p", "--password",
    default="", prompt=True, hide_input=True, confirmation_prompt=True,
    help="Password (prompted securely if omitted)."
)
def cmd_register(username, password):
    """Create a new user account."""
    try:
        uid = paywall.register_user(username, password)
        click.secho(f"✓ User '{username}' created (id={uid}).", fg="green")
    except paywall.PaywallError as exc:
        click.secho(f"✗ {exc}", fg="red", err=True)
        sys.exit(1)


# ── add-article ───────────────────────────────────────────────────────────────

@cli.command("add-article")
@click.option("--slug",  required=True, help="URL-safe article identifier (e.g. my-article).")
@click.option("--title", required=True, help="Human-readable article title.")
@click.option("--desc",  default="",   help="Short description / teaser.")
@click.option(
    "--price", default=config.DEFAULT_PRICE_SATS, show_default=True,
    help="Price in satoshis."
)
@click.option(
    "--file",  "source_file", default=None,
    help="Path to plaintext file. If omitted, opens an editor."
)
def cmd_add_article(slug, title, desc, price, source_file):
    """Encrypt and register a new article."""
    try:
        if source_file:
            article_id = paywall.add_article_from_file(
                source_path=source_file, slug=slug, title=title,
                description=desc, price_sats=price,
            )
        else:
            # Open $EDITOR (or prompt for inline text)
            placeholder = (
                f"# Write your article below (lines starting with # are removed)\n"
                f"# Title: {title}\n\n"
            )
            raw = click.edit(placeholder) or ""
            text = "\n".join(
                line for line in raw.splitlines()
                if not line.startswith("#")
            ).strip()
            if not text:
                click.secho("✗ Empty article — aborted.", fg="red", err=True)
                sys.exit(1)
            article_id = paywall.add_article_from_text(
                text=text, slug=slug, title=title,
                description=desc, price_sats=price,
            )
        click.secho(
            f"✓ Article '{title}' encrypted and stored (id={article_id}, "
            f"slug='{slug}', price={price} sats).",
            fg="green",
        )
    except paywall.PaywallError as exc:
        click.secho(f"✗ {exc}", fg="red", err=True)
        sys.exit(1)


# ── list-articles ─────────────────────────────────────────────────────────────

@cli.command("list-articles")
@click.option("-u", "--username", default=None, help="Show unlock status for this user.")
def cmd_list_articles(username):
    """List all articles (with per-user lock/unlock status if --username given)."""
    articles = models.list_articles()
    if not articles:
        click.echo("No articles found. Add one with 'add-article'.")
        return

    user_id = None
    if username:
        user = models.get_user(username)
        if user is None:
            click.secho(f"✗ Unknown user '{username}'.", fg="red", err=True)
            sys.exit(1)
        user_id = user["id"]

    click.echo(f"\n{'SLUG':<28} {'PRICE':>8}  {'TITLE':<35}  STATUS")
    click.echo("─" * 82)
    for a in articles:
        status = ""
        if user_id is not None:
            status = (
                click.style("🔓 unlocked", fg="green")
                if models.is_unlocked(user_id, a["id"])
                else click.style("🔒 locked",   fg="yellow")
            )
        click.echo(
            f"{a['slug']:<28} {a['price_sats']:>7}s  {a['title']:<35}  {status}"
        )
    click.echo()


# ── invoice ───────────────────────────────────────────────────────────────────

@cli.command("invoice")
@user_option
@click.option("--slug", required=True, help="Article slug to pay for.")
def cmd_invoice(username, slug):
    """Generate a Lightning invoice for an article."""
    try:
        result = paywall.generate_invoice(username, slug)
    except paywall.PaywallError as exc:
        click.secho(f"✗ {exc}", fg="red", err=True)
        sys.exit(1)

    backend = "MOCK" if config.LN_MOCK else config.LN_BACKEND.upper()
    click.echo("\n" + "─" * 60)
    click.secho(f"  ⚡  Lightning Invoice ({backend})", bold=True)
    click.echo("─" * 60)
    click.echo(f"  Payment hash : {result.payment_hash}")
    click.echo(f"  Amount       : {result.amount_sats} sats")
    click.echo(f"  Expiry       : {result.expiry_seconds}s")
    click.echo()
    click.secho("  BOLT-11 Invoice:", bold=True)
    click.echo(f"  {result.payment_request}")
    click.echo("─" * 60)

    if config.LN_MOCK:
        click.secho(
            "\n  [MOCK MODE] The invoice will auto-pay in "
            f"~{lightning_module_auto_delay()}s, or run:\n"
            f"    python main.py force-pay --hash {result.payment_hash}\n",
            fg="cyan",
        )
    else:
        click.echo(
            "\n  Scan the BOLT-11 with a Lightning wallet, then run:\n"
            f"    python main.py check-payment -u {username} "
            f"--slug {slug} --hash {result.payment_hash}\n"
        )


def lightning_module_auto_delay() -> int:
    try:
        from lightning import MOCK_AUTO_SETTLE_SECS
        return MOCK_AUTO_SETTLE_SECS
    except Exception:
        return 5


# ── check-payment ─────────────────────────────────────────────────────────────

@cli.command("check-payment")
@user_option
@click.option("--slug",  required=True, help="Article slug.")
@click.option("--hash", "payment_hash", required=True, help="Payment hash from invoice.")
@click.option(
    "--poll", is_flag=True, default=False,
    help="Keep polling every 2s until paid or expired."
)
def cmd_check_payment(username, slug, payment_hash, poll):
    """Check invoice status and unlock article if paid."""
    spinner = ["|", "/", "─", "\\"]
    attempt = 0
    while True:
        try:
            status = paywall.check_and_unlock(username, slug, payment_hash)
        except paywall.PaywallError as exc:
            click.secho(f"✗ {exc}", fg="red", err=True)
            sys.exit(1)

        if status == InvoiceStatus.PAID:
            click.secho(
                f"\n✓ Payment confirmed!  Article '{slug}' is now unlocked "
                f"for '{username}'.\n"
                f"  Read it with:  python main.py read -u {username} --slug {slug}\n",
                fg="green",
            )
            return

        if status in (InvoiceStatus.EXPIRED, InvoiceStatus.FAILED):
            click.secho(
                f"\n✗ Invoice status: {status.value}. "
                "Generate a new invoice to try again.",
                fg="red", err=True,
            )
            sys.exit(1)

        if not poll:
            click.echo(f"  Status: {status.value}. Re-run with --poll to keep waiting.")
            return

        icon = spinner[attempt % len(spinner)]
        click.echo(
            f"\r  {icon} Waiting for payment… (status={status.value})", nl=False
        )
        attempt += 1
        time.sleep(2)


# ── read ──────────────────────────────────────────────────────────────────────

@cli.command("read")
@user_option
@click.option("--slug", required=True, help="Article slug to read.")
def cmd_read(username, slug):
    """Print the decrypted content of an unlocked article."""
    try:
        content = paywall.read_article(username, slug)
    except paywall.PaywallError as exc:
        click.secho(f"✗ {exc}", fg="red", err=True)
        sys.exit(1)

    article = models.get_article(slug)
    click.echo("\n" + "═" * 70)
    click.secho(f"  {article['title']}", bold=True)
    click.echo("═" * 70)
    # Word-wrap at 70 columns for readability
    for paragraph in content.split("\n\n"):
        wrapped = textwrap.fill(paragraph.strip(), width=68)
        click.echo("\n" + wrapped)
    click.echo("\n" + "═" * 70 + "\n")


# ── list-payments ────────────────────────────────────────────────────────────

@cli.command("list-payments")
@user_option
def cmd_list_payments(username):
    """Show all Lightning payments for a user."""
    user = models.get_user(username)
    if user is None:
        click.secho(f"✗ Unknown user '{username}'.", fg="red", err=True)
        sys.exit(1)

    with models.get_db() as conn:
        rows = conn.execute(
            """SELECT p.*, a.slug, a.title
               FROM payments p
               JOIN articles a ON a.id = p.article_id
               WHERE p.user_id = ?
               ORDER BY p.created_at DESC""",
            (user["id"],),
        ).fetchall()

    if not rows:
        click.echo(f"No payments found for '{username}'.")
        return

    click.echo(f"\nPayments for '{username}':\n")
    click.echo(f"  {'SLUG':<22} {'SATS':>6}  {'STATUS':<10}  HASH (first 20 chars)")
    click.echo("  " + "─" * 70)
    for r in rows:
        status_color = {"paid": "green", "pending": "yellow",
                        "expired": "red", "failed": "red"}.get(r["status"], "white")
        status_str = click.style(f"{r['status']:<10}", fg=status_color)
        click.echo(
            f"  {r['slug']:<22} {r['amount_sats']:>6}  {status_str}  "
            f"{r['payment_hash'][:20]}…"
        )
    click.echo()


# ── force-pay (mock only) ─────────────────────────────────────────────────────

@cli.command("force-pay")
@click.option(
    "--hash", "payment_hash", required=True,
    help="Payment hash to mark as paid immediately."
)
def cmd_force_pay(payment_hash):
    """[MOCK MODE] Immediately mark an invoice as paid (testing helper)."""
    if not config.LN_MOCK:
        click.secho(
            "✗ force-pay is only available in mock mode (PAYWALL_LN_MOCK=true).",
            fg="red", err=True,
        )
        sys.exit(1)
    if mock_force_pay(payment_hash):
        click.secho(f"✓ Invoice {payment_hash[:20]}… force-paid.", fg="green")
    else:
        click.secho(
            "✗ Could not force-pay: invoice not found or already settled.",
            fg="yellow",
        )


# ── demo ──────────────────────────────────────────────────────────────────────

@cli.command("demo")
def cmd_demo():
    """Run a complete end-to-end demo (mock mode only)."""
    if not config.LN_MOCK:
        click.secho(
            "✗ The demo requires PAYWALL_LN_MOCK=true.", fg="red", err=True
        )
        sys.exit(1)

    import lightning as ln_module

    click.secho("\n⚡  Lightning Paywall — End-to-End Demo\n", bold=True, fg="cyan")

    # 1. Init DB
    click.echo("Step 1/5 — Initialising database…")
    models.init_db()

    # 2. Create demo user
    username, password = "alice", "hunter2"
    slug, title = "bitcoin-101", "Bitcoin 101: Why Digital Gold?"
    price_sats  = 50

    click.echo(f"Step 2/5 — Registering user '{username}'…")
    try:
        paywall.register_user(username, password)
    except paywall.PaywallError:
        click.echo(f"          (user '{username}' already exists, continuing)")

    # 3. Publish article
    click.echo(f"Step 3/5 — Publishing article '{slug}'…")
    text = (
        "Bitcoin is a decentralised digital currency created in 2009 by an "
        "anonymous person (or group) known as Satoshi Nakamoto. Unlike "
        "traditional currencies, Bitcoin operates without a central authority "
        "— transactions are verified by a global peer-to-peer network and "
        "recorded on a public ledger called the blockchain.\n\n"
        "Scarcity is enforced algorithmically: only 21 million coins will "
        "ever exist. This fixed supply, combined with censorship resistance "
        "and permissionless access, is why many refer to Bitcoin as "
        "'digital gold'."
    )
    try:
        paywall.add_article_from_text(
            text=text, slug=slug, title=title,
            description="An introduction to Bitcoin.", price_sats=price_sats,
        )
        click.echo(f"          Article encrypted → articles/{slug}.enc")
    except paywall.PaywallError:
        click.echo(f"          (article '{slug}' already exists, continuing)")

    # 4. Generate invoice
    delay = ln_module.MOCK_AUTO_SETTLE_SECS
    click.echo("Step 4/5 — Generating Lightning invoice…")
    result = paywall.generate_invoice(username, slug)
    click.echo(f"          Invoice: {result.payment_request[:60]}…")
    click.echo(f"          Hash  : {result.payment_hash}")
    click.echo(f"          Waiting {delay}s for mock auto-payment…")
    time.sleep(delay + 1)

    # 5. Check + unlock
    click.echo("Step 5/5 — Checking payment and unlocking article…")
    status = paywall.check_and_unlock(username, slug, result.payment_hash)
    if status == InvoiceStatus.PAID:
        click.secho("          ✓ Paid and unlocked!", fg="green")
    else:
        click.secho(f"          ✗ Unexpected status: {status}", fg="red")
        sys.exit(1)

    # Read article
    click.echo("\n" + "═" * 70)
    click.secho(f"  {title}", bold=True)
    click.echo("═" * 70)
    content = paywall.read_article(username, slug)
    for paragraph in content.split("\n\n"):
        click.echo("\n" + textwrap.fill(paragraph.strip(), width=68))
    click.echo("\n" + "═" * 70)
    click.secho("\n✓ Demo complete!\n", fg="green", bold=True)
