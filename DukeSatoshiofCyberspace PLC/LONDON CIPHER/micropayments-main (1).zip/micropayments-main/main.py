#!/usr/bin/env python3
"""
main.py — Entry point for the Lightning Paywall system.

Usage
─────
  CLI:
    python main.py --help
    python main.py init-db
    python main.py demo                  # end-to-end demo in mock mode

  Web server:
    python main.py serve

  Quick start (mock mode, no real node needed):
    python main.py init-db
    python main.py register -u alice
    python main.py add-article --slug btc --title "Bitcoin 101" --price 50 \\
        --file /path/to/article.txt
    python main.py invoice -u alice --slug btc
    python main.py check-payment -u alice --slug btc --hash <hash> --poll
    python main.py read -u alice --slug btc

See README.md for full documentation.
"""

import sys
import os

# ── Make sure the paywall package directory is on the path ────────────────────
sys.path.insert(0, os.path.dirname(__file__))

import click
from cli import cli


# ── 'serve' command (launches Flask) ─────────────────────────────────────────

@cli.command("serve")
def cmd_serve():
    """Start the Flask REST API server."""
    import models
    models.init_db()
    from api import run_server
    run_server()


if __name__ == "__main__":
    cli()
