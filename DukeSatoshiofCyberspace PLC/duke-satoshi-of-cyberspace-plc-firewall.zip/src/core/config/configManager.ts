/**
 * @file configManager.ts
 * Duke Satoshi of Cyberspace PLC - Configuration-as-Code & Safety Pipeline
 * Candidate configuration, validation, commit confirmation timer, automatic rollback, and YAML/JSON serialization.
 */

import { FirewallRule, NetworkZone, Protocol, RuleAction, AuditLogEntry } from '../../types/firewall';
import { RuleEngine } from '../policy/ruleEngine';

export interface CandidateConfig {
  version: number;
  author: string;
  timestamp: number;
  rules: FirewallRule[];
  defaultZonePolicy: Record<NetworkZone, RuleAction>;
}

export class ConfigManager {
  private static activeConfigVersion = 1;
  private static activeRules: FirewallRule[] = [
    {
      id: 'rule_001',
      name: 'ALLOW_OOB_MANAGEMENT_SSH_HTTPS',
      description: 'Permit secure SSH & HTTPS access to Out-of-Band Management Controller',
      priority: 10,
      enabled: true,
      srcZone: NetworkZone.MANAGEMENT,
      dstZone: NetworkZone.MANAGEMENT,
      srcAddress: '10.0.0.0/24',
      dstAddress: '10.0.0.1/32',
      protocol: Protocol.TCP,
      dstPort: '22,443',
      application: 'SSH',
      identityRequired: true,
      requiredGroup: 'SOVEREIGN_ADMIN',
      minDeviceTrust: 'HARDWARE_TOKEN_VERIFIED',
      action: RuleAction.ALLOW,
      logging: true,
      owner: 'lord.satoshi',
      createdAt: Date.now() - 86400000 * 10,
      modifiedAt: Date.now() - 86400000 * 10,
      hitCount: 5412,
    },
    {
      id: 'rule_002',
      name: 'ALLOW_PUBLIC_INGRESS_DMZ_HTTPS',
      description: 'Permit public encrypted web traffic to DMZ Reverse Proxy & WAF cluster',
      priority: 20,
      enabled: true,
      srcZone: NetworkZone.PUBLIC,
      dstZone: NetworkZone.DMZ,
      srcAddress: 'ANY',
      dstAddress: '10.20.1.10/32',
      protocol: Protocol.TCP,
      dstPort: '443',
      application: 'HTTPS',
      action: RuleAction.ALLOW,
      rateLimitPerSec: 500,
      logging: true,
      owner: 'secops-team',
      createdAt: Date.now() - 86400000 * 8,
      modifiedAt: Date.now() - 86400000 * 8,
      hitCount: 98124,
    },
    {
      id: 'rule_003',
      name: 'ALLOW_DMZ_TO_PROD_API_GATEWAY',
      description: 'Permit authenticated reverse proxy traffic from DMZ to Production API',
      priority: 30,
      enabled: true,
      srcZone: NetworkZone.DMZ,
      dstZone: NetworkZone.PRODUCTION,
      srcAddress: '10.20.1.0/24',
      dstAddress: '10.50.0.0/16',
      protocol: Protocol.TCP,
      dstPort: '8080,8443',
      application: 'HTTPS',
      action: RuleAction.ALLOW,
      logging: true,
      owner: 'core-arch',
      createdAt: Date.now() - 86400000 * 7,
      modifiedAt: Date.now() - 86400000 * 7,
      hitCount: 65431,
    },
    {
      id: 'rule_004',
      name: 'ALLOW_PROD_TO_POSTGRESQL_DB',
      description: 'Permit production microservices access to database pool with mTLS',
      priority: 40,
      enabled: true,
      srcZone: NetworkZone.PRODUCTION,
      dstZone: NetworkZone.DATABASE,
      srcAddress: '10.50.0.0/16',
      dstAddress: '10.50.10.0/24',
      protocol: Protocol.TCP,
      dstPort: '5432',
      application: 'POSTGRESQL',
      action: RuleAction.ALLOW,
      logging: true,
      owner: 'dba-team',
      createdAt: Date.now() - 86400000 * 6,
      modifiedAt: Date.now() - 86400000 * 6,
      hitCount: 142090,
    },
    {
      id: 'rule_005',
      name: 'ALLOW_FINANCE_TO_SWIFT_INTERBANK',
      description: 'Permit Banking Settlement node to communicate with SWIFT Wire gateway',
      priority: 50,
      enabled: true,
      srcZone: NetworkZone.FINANCE,
      dstZone: NetworkZone.PUBLIC,
      srcAddress: '10.30.1.0/24',
      dstAddress: '198.51.100.50/32',
      protocol: Protocol.TCP,
      dstPort: '9443',
      application: 'FIN_WIRE',
      action: RuleAction.ALLOW,
      logging: true,
      owner: 'settlement-lead',
      createdAt: Date.now() - 86400000 * 5,
      modifiedAt: Date.now() - 86400000 * 5,
      hitCount: 1840,
    },
    {
      id: 'rule_006',
      name: 'ALLOW_FINANCE_TO_SOVEREIGN_VAULT_HSM',
      description: 'Permit authorized finance signers to access HSM hardware vault with hardware token',
      priority: 60,
      enabled: true,
      srcZone: NetworkZone.FINANCE,
      dstZone: NetworkZone.VAULT,
      srcAddress: '10.30.1.5/32',
      dstAddress: '10.99.1.10/32',
      protocol: Protocol.TCP,
      dstPort: '8200',
      application: 'VAULT_RPC',
      identityRequired: true,
      requiredGroup: 'VAULT_CUSTODIAN',
      minDeviceTrust: 'HARDWARE_TOKEN_VERIFIED',
      action: RuleAction.ALLOW,
      logging: true,
      owner: 'lord.satoshi',
      createdAt: Date.now() - 86400000 * 4,
      modifiedAt: Date.now() - 86400000 * 4,
      hitCount: 720,
    },
    {
      id: 'rule_007',
      name: 'ALLOW_CORP_INTERNAL_DNS',
      description: 'Permit corporate workstations to access secure recursive DNS resolver',
      priority: 70,
      enabled: true,
      srcZone: NetworkZone.CORPORATE,
      dstZone: NetworkZone.DMZ,
      srcAddress: '10.10.0.0/16',
      dstAddress: '10.20.1.53/32',
      protocol: Protocol.UDP,
      dstPort: '53',
      application: 'DNS',
      action: RuleAction.ALLOW,
      logging: false,
      owner: 'net-admin',
      createdAt: Date.now() - 86400000 * 3,
      modifiedAt: Date.now() - 86400000 * 3,
      hitCount: 51200,
    },
    {
      id: 'rule_008',
      name: 'ISOLATE_QUARANTINE_ZONE',
      description: 'Strict isolation of compromised assets in quarantine perimeter',
      priority: 80,
      enabled: true,
      srcZone: NetworkZone.QUARANTINE,
      dstZone: 'ANY',
      srcAddress: '192.168.99.0/24',
      dstAddress: 'ANY',
      protocol: 'ANY',
      application: 'ANY',
      action: RuleAction.ISOLATE,
      logging: true,
      owner: 'soc-incident-response',
      createdAt: Date.now() - 86400000 * 2,
      modifiedAt: Date.now() - 86400000 * 2,
      hitCount: 312,
    },
    {
      id: 'rule_099',
      name: 'EXPLICIT_DEFAULT_DENY_LOG',
      description: 'Default deny all unclassified cross-zone and perimeter traffic with full audit log',
      priority: 999,
      enabled: true,
      srcZone: 'ANY',
      dstZone: 'ANY',
      srcAddress: 'ANY',
      dstAddress: 'ANY',
      protocol: 'ANY',
      application: 'ANY',
      action: RuleAction.DENY,
      logging: true,
      owner: 'lord.satoshi',
      createdAt: Date.now() - 86400000 * 30,
      modifiedAt: Date.now() - 86400000 * 30,
      hitCount: 84120,
    },
  ];

  private static candidateDraft: FirewallRule[] | null = null;
  private static rollbackTimer: {
    timerId?: any;
    targetTimestamp: number;
    secondsRemaining: number;
    backupRules: FirewallRule[];
  } | null = null;

  public static initialize() {
    RuleEngine.setRules(this.activeRules);
  }

  public static getActiveRules(): FirewallRule[] {
    return [...this.activeRules];
  }

  public static getCandidateRules(): FirewallRule[] {
    return this.candidateDraft ? [...this.candidateDraft] : [...this.activeRules];
  }

  public static setCandidateRules(rules: FirewallRule[]) {
    this.candidateDraft = [...rules];
  }

  public static discardCandidateDraft() {
    this.candidateDraft = null;
  }

  /**
   * Validates candidate configuration for syntax errors, conflicting priorities, or lockout vulnerabilities.
   */
  public static validateConfig(rules: FirewallRule[]): { valid: boolean; errors: string[]; warnings: string[] } {
    const errors: string[] = [];
    const warnings: string[] = [];
    const seenPriorities = new Set<number>();

    // 1. Check for management access rule
    const hasMgmtRule = rules.some(
      (r) =>
        r.enabled &&
        r.action === RuleAction.ALLOW &&
        (r.dstZone === NetworkZone.MANAGEMENT || r.dstZone === 'ANY') &&
        (r.dstPort === '22' || r.dstPort === '443' || r.dstPort?.includes('22') || r.dstPort?.includes('443') || r.dstPort === 'ANY')
    );

    if (!hasMgmtRule) {
      warnings.push('Warning: No explicit ALLOW rule found for Management access (Port 22/443). Possible admin lockout if default-deny executes.');
    }

    rules.forEach((rule, idx) => {
      if (!rule.name || rule.name.trim() === '') {
        errors.push(`Rule #${idx + 1}: Name is required`);
      }
      if (seenPriorities.has(rule.priority)) {
        warnings.push(`Rule '${rule.name}': Priority ${rule.priority} is duplicate with another rule. Lower array index will execute first.`);
      }
      seenPriorities.add(rule.priority);

      if (rule.srcAddress !== 'ANY' && !rule.srcAddress.includes('/') && rule.srcAddress.split('.').length !== 4) {
        errors.push(`Rule '${rule.name}': Invalid Source IP/CIDR syntax '${rule.srcAddress}'`);
      }
      if (rule.dstAddress !== 'ANY' && !rule.dstAddress.includes('/') && rule.dstAddress.split('.').length !== 4) {
        errors.push(`Rule '${rule.name}': Invalid Destination IP/CIDR syntax '${rule.dstAddress}'`);
      }
    });

    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  }

  /**
   * Initiates a Confirmed Commit with an automatic rollback countdown timer.
   */
  public static commitWithConfirm(
    newRules: FirewallRule[],
    confirmSeconds: number = 300,
    actor: string = 'lord.satoshi'
  ): { status: 'COMMITTED_UNCONFIRMED' | 'ERROR'; rollbackInSeconds: number; version: number } {
    const validation = this.validateConfig(newRules);
    if (!validation.valid) {
      throw new Error(`Validation failed: ${validation.errors.join('; ')}`);
    }

    const backup = [...this.activeRules];
    this.activeRules = [...newRules].sort((a, b) => a.priority - b.priority);
    this.activeConfigVersion += 1;
    this.candidateDraft = null;

    // Set active engine rules
    RuleEngine.setRules(this.activeRules);

    // Set Rollback Timer
    if (this.rollbackTimer?.timerId) {
      clearTimeout(this.rollbackTimer.timerId);
    }

    const targetTimestamp = Date.now() + confirmSeconds * 1000;
    const timerId = setTimeout(() => {
      this.triggerAutoRollback('Confirmation timeout elapsed without administrator confirmation.');
    }, confirmSeconds * 1000);

    this.rollbackTimer = {
      timerId,
      targetTimestamp,
      secondsRemaining: confirmSeconds,
      backupRules: backup,
    };

    return {
      status: 'COMMITTED_UNCONFIRMED',
      rollbackInSeconds: confirmSeconds,
      version: this.activeConfigVersion,
    };
  }

  /**
   * Confirms the commit, making the change permanent and canceling rollback timer.
   */
  public static confirmCommit(): boolean {
    if (this.rollbackTimer) {
      if (this.rollbackTimer.timerId) {
        clearTimeout(this.rollbackTimer.timerId);
      }
      this.rollbackTimer = null;
      return true;
    }
    return false;
  }

  public static triggerAutoRollback(reason: string = 'Manual administrator rollback') {
    if (this.rollbackTimer?.backupRules) {
      this.activeRules = [...this.rollbackTimer.backupRules];
      RuleEngine.setRules(this.activeRules);
      if (this.rollbackTimer.timerId) {
        clearTimeout(this.rollbackTimer.timerId);
      }
      this.rollbackTimer = null;
      return true;
    }
    return false;
  }

  public static getRollbackStatus(): { active: boolean; secondsRemaining: number } {
    if (!this.rollbackTimer) return { active: false, secondsRemaining: 0 };
    const remaining = Math.max(0, Math.ceil((this.rollbackTimer.targetTimestamp - Date.now()) / 1000));
    return { active: true, secondsRemaining: remaining };
  }

  public static exportDeclarativeYaml(): string {
    const lines = [
      '# Duke Satoshi of Cyberspace PLC - Firewall Declarative Policy',
      `# Version: ${this.activeConfigVersion}`,
      `# Exported: ${new Date().toISOString()}`,
      '',
      'network:',
      '  zones:',
      '    - public',
      '    - dmz',
      '    - corporate',
      '    - development',
      '    - production',
      '    - finance',
      '    - vault',
      '    - management',
      '    - guest',
      '    - quarantine',
      '',
      'policy:',
      '  default_action: DENY',
      '  rules:',
    ];

    this.activeRules.forEach((r) => {
      lines.push(`    - id: "${r.id}"`);
      lines.push(`      name: "${r.name}"`);
      lines.push(`      priority: ${r.priority}`);
      lines.push(`      source_zone: "${r.srcZone}"`);
      lines.push(`      destination_zone: "${r.dstZone}"`);
      lines.push(`      source_address: "${r.srcAddress}"`);
      lines.push(`      destination_address: "${r.dstAddress}"`);
      lines.push(`      protocol: "${r.protocol}"`);
      lines.push(`      destination_port: "${r.dstPort || 'ANY'}"`);
      lines.push(`      application: "${r.application}"`);
      lines.push(`      action: "${r.action}"`);
      lines.push(`      logging: ${r.logging}`);
      if (r.identityRequired) lines.push(`      identity_required: true`);
      if (r.minDeviceTrust) lines.push(`      min_device_trust: "${r.minDeviceTrust}"`);
      lines.push('');
    });

    return lines.join('\n');
  }
}
