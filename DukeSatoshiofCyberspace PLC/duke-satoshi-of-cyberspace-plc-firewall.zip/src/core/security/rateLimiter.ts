/**
 * @file rateLimiter.ts
 * Duke Satoshi of Cyberspace PLC - High-Performance Rate Limiting Subsystem
 * Token Bucket & Sliding Window algorithms for multi-dimensional traffic shaping.
 */

export interface TokenBucket {
  tokens: number;
  capacity: number;
  fillRatePerSec: number;
  lastUpdated: number;
}

export class RateLimiterEngine {
  private static buckets: Map<string, TokenBucket> = new Map();

  /**
   * Evaluates a Token Bucket limit. Returns true if request is within limit, false if dropped/throttled.
   */
  public static checkTokenBucket(key: string, capacity: number = 100, fillRatePerSec: number = 50, cost: number = 1): boolean {
    const now = Date.now();
    let bucket = this.buckets.get(key);

    if (!bucket) {
      bucket = {
        tokens: capacity - cost,
        capacity,
        fillRatePerSec,
        lastUpdated: now,
      };
      this.buckets.set(key, bucket);
      return true;
    }

    // Refill tokens based on elapsed time
    const elapsedSec = (now - bucket.lastUpdated) / 1000;
    bucket.tokens = Math.min(bucket.capacity, bucket.tokens + elapsedSec * bucket.fillRatePerSec);
    bucket.lastUpdated = now;

    if (bucket.tokens >= cost) {
      bucket.tokens -= cost;
      return true;
    }

    return false; // Rate limit exceeded
  }

  public static getBucketStatus(key: string): { tokens: number; capacity: number } | null {
    const b = this.buckets.get(key);
    return b ? { tokens: Math.floor(b.tokens), capacity: b.capacity } : null;
  }

  public static resetBucket(key: string) {
    this.buckets.delete(key);
  }
}
