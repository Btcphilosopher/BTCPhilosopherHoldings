/**
 * @file dnsSecurity.ts
 * Duke Satoshi of Cyberspace PLC - DNS Security & Sinkhole Subsystem
 * High-performance domain policy inspection, DGA detection, and covert channel prevention.
 */

import { DnsRecord, NetworkZone } from '../../types/firewall';
import { ThreatIntelEngine } from './threatIntel';

export class DnsSecurityEngine {
  private static queryLog: DnsRecord[] = [];
  private static blocklist: Set<string> = new Set([
    'malware-command-node.cc',
    'phish-satoshi-vault.net',
    'darknet-exfil-proxy.ru',
    'crypto-stealer-relay.org',
    'dns-tunnel-stage2.biz',
  ]);
  private static allowlist: Set<string> = new Set([
    'dukesatoshi.plc',
    'vault.internal.satoshi',
    'swift.financial-network.net',
    'api.banking-core.internal',
  ]);

  /**
   * Processes a DNS query and decides whether to resolve, sinkhole, or alert.
   */
  public static processQuery(
    domain: string,
    clientIp: string,
    clientZone: NetworkZone,
    queryType: DnsRecord['queryType'] = 'A'
  ): DnsRecord {
    const now = Date.now();
    const cleanDomain = domain.toLowerCase().trim();

    let status: DnsRecord['status'] = 'ALLOWED';
    let category: DnsRecord['category'] = 'LEGITIMATE';
    let responseIp: string | undefined = `10.200.${Math.floor(Math.random() * 250)}.${Math.floor(Math.random() * 250)}`;
    let policyApplied = 'Default Internal DNS Resolver';

    // 1. Check Allowlist
    if (this.allowlist.has(cleanDomain)) {
      status = 'ALLOWED';
      category = 'LEGITIMATE';
      policyApplied = 'Explicit Sovereign Domain Allowlist';
    }
    // 2. Check Explicit Blocklist
    else if (this.blocklist.has(cleanDomain)) {
      status = 'BLOCKED_SINKHOLE';
      category = 'CUSTOM_BLOCKLIST';
      responseIp = '0.0.0.0 (SINKHOLE)';
      policyApplied = 'Duke Satoshi DNS Security Blocklist';
    }
    // 3. Check Threat Intel Feed
    else {
      const threatHit = ThreatIntelEngine.checkIndicator(cleanDomain, 'DOMAIN');
      if (threatHit) {
        status = 'BLOCKED_SINKHOLE';
        category = 'MALICIOUS_REPUTATION';
        responseIp = '127.0.0.1 (SINKHOLE)';
        policyApplied = `Threat Intel IOC Match: ${threatHit.sourceFeed}`;
      }
      // 4. Check DGA / Tunneling Pattern
      else if (cleanDomain.length > 40 || (cleanDomain.split('.').length > 4 && /[0-9a-f]{16,}/i.test(cleanDomain))) {
        status = 'SUSPICIOUS_DGA';
        category = 'DNS_TUNNEL_EXFIL';
        policyApplied = 'Statistical High-Entropy Heuristic';
      }
    }

    const record: DnsRecord = {
      id: `dns_${now}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: now,
      clientIp,
      clientZone,
      domain: cleanDomain,
      queryType,
      responseIp,
      status,
      category,
      policyApplied,
      latencyMs: Math.floor(Math.random() * 8) + 1,
    };

    this.queryLog.unshift(record);
    if (this.queryLog.length > 200) {
      this.queryLog.pop();
    }

    return record;
  }

  public static getQueryLog(): DnsRecord[] {
    return [...this.queryLog];
  }

  public static addBlocklistDomain(domain: string) {
    this.blocklist.add(domain.toLowerCase().trim());
  }

  public static removeBlocklistDomain(domain: string) {
    this.blocklist.delete(domain.toLowerCase().trim());
  }

  public static getBlocklist(): string[] {
    return Array.from(this.blocklist);
  }

  public static getAllowlist(): string[] {
    return Array.from(this.allowlist);
  }
}
