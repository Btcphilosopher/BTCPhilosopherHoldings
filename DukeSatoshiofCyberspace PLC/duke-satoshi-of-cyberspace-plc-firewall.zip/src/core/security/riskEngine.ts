/**
 * @file riskEngine.ts
 * Duke Satoshi of Cyberspace PLC - Transparent Decomposable Risk Engine
 * "Risk = Identity + Device + Network + Application + Behavioural + Threat Intel + Policy Violations"
 */

import { DecisionContext, NetworkZone, Protocol, ParsedPacket, AnomalyLevel } from '../../types/firewall';

export class RiskEngine {
  /**
   * Calculates a transparent, fully decomposable 0-100 risk score with detailed factor breakdown.
   */
  public static evaluateRisk(
    packet: ParsedPacket,
    srcZone: NetworkZone,
    dstZone: NetworkZone,
    userContext?: {
      userId?: string;
      mfaVerified?: boolean;
      deviceTrust?: 'UNTRUSTED' | 'KNOWN' | 'CORPORATE_MANAGED' | 'HARDWARE_ATTESTED';
      roles?: string[];
    },
    threatIntelHits: number = 0,
    anomalyLevel: AnomalyLevel = AnomalyLevel.NORMAL
  ): DecisionContext['risk'] {
    const factors: string[] = [];

    // 1. Identity Risk (0 - 20 pts)
    let identityRisk = 0;
    if (!userContext?.userId) {
      identityRisk += 10;
      factors.push('Unauthenticated anonymous session (+10)');
    } else if (!userContext.mfaVerified) {
      identityRisk += 6;
      factors.push('Session lacks hardware MFA verification (+6)');
    }

    // 2. Device Posture Risk (0 - 15 pts)
    let deviceRisk = 0;
    const trust = userContext?.deviceTrust || 'UNTRUSTED';
    if (trust === 'UNTRUSTED') {
      deviceRisk += 15;
      factors.push('Untrusted or unmanaged device identity (+15)');
    } else if (trust === 'KNOWN') {
      deviceRisk += 5;
      factors.push('Known device lacking device certificate attestation (+5)');
    }

    // 3. Network & Zone Traversal Risk (0 - 25 pts)
    let networkRisk = 0;
    if (srcZone === NetworkZone.PUBLIC && dstZone === NetworkZone.VAULT) {
      networkRisk += 25;
      factors.push('Direct Public WAN to Sovereign Vault boundary attempt (+25)');
    } else if (srcZone === NetworkZone.PUBLIC && dstZone === NetworkZone.FINANCE) {
      networkRisk += 20;
      factors.push('Public WAN traversal toward Core Banking network (+20)');
    } else if (srcZone === NetworkZone.GUEST && dstZone !== NetworkZone.PUBLIC) {
      networkRisk += 15;
      factors.push('Guest WiFi attempting lateral movement into internal zone (+15)');
    } else if (srcZone === NetworkZone.QUARANTINE) {
      networkRisk += 25;
      factors.push('Quarantined device attempting active egress (+25)');
    }

    // 4. Application & Protocol Risk (0 - 15 pts)
    let applicationRisk = 0;
    const dstPort = packet.transport?.dstPort || 0;
    if (dstPort === 22 || dstPort === 23 || dstPort === 3389) {
      applicationRisk += 10;
      factors.push(`Administrative remote access protocol requested (Port ${dstPort}) (+10)`);
    }
    if (packet.ip.isFragmented) {
      applicationRisk += 10;
      factors.push('Fragmented IP packet structure detected (+10)');
    }

    // 5. Behavioural Anomaly Deviation (0 - 20 pts)
    let behaviouralDeviation = 0;
    if (anomalyLevel === AnomalyLevel.CRITICAL) {
      behaviouralDeviation += 20;
      factors.push('Critical statistical baseline traffic anomaly (+20)');
    } else if (anomalyLevel === AnomalyLevel.SUSPICIOUS) {
      behaviouralDeviation += 12;
      factors.push('Suspicious connection frequency burst (+12)');
    } else if (anomalyLevel === AnomalyLevel.UNUSUAL) {
      behaviouralDeviation += 5;
      factors.push('Unusual off-hours activity (+5)');
    }

    // 6. Threat Intelligence Hits (0 - 30 pts)
    let threatIntelScore = 0;
    if (threatIntelHits > 0) {
      threatIntelScore = Math.min(30, threatIntelHits * 15);
      factors.push(`Known Threat Indicator feed match (${threatIntelHits} IOC hits) (+${threatIntelScore})`);
    }

    // 7. Total Composite Score Calculation
    const totalRaw = identityRisk + deviceRisk + networkRisk + applicationRisk + behaviouralDeviation + threatIntelScore;
    const totalScore = Math.min(100, Math.max(0, totalRaw));

    let level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' = 'LOW';
    if (totalScore >= 75) level = 'CRITICAL';
    else if (totalScore >= 50) level = 'HIGH';
    else if (totalScore >= 25) level = 'MEDIUM';

    return {
      totalScore,
      level,
      breakdown: {
        identityRisk,
        deviceRisk,
        networkRisk,
        applicationRisk,
        behaviouralDeviation,
        threatIntelHits: threatIntelScore,
        policyViolationWeight: 0,
      },
      factors,
    };
  }
}
