/**
 * @file ipsEngine.ts
 * Duke Satoshi of Cyberspace PLC - Intrusion Prevention System (IPS)
 * Automated defense mitigations, time-bounded quarantine, rate limit dispatcher, and global kill switch.
 */

import { SecurityEvent, NetworkZone, DecisionResult } from '../../types/firewall';

export interface BlockedHost {
  ip: string;
  reason: string;
  blockedAt: number;
  unblockAt: number;
  associatedEventId?: string;
  quarantinedZone?: boolean;
}

export class IpsEngine {
  private static blockedHosts: Map<string, BlockedHost> = new Map();
  private static emergencyKillSwitchActive = false;
  private static ipsAutoMitigationEnabled = true;

  /**
   * Evaluates whether an incoming IP should be blocked by active IPS mitigations
   * or by the Emergency Kill Switch.
   */
  public static shouldMitigate(srcIp: string, srcZone: NetworkZone): { blocked: boolean; reason?: string; action?: DecisionResult } {
    const now = Date.now();

    // 1. Emergency Kill Switch Check
    if (this.emergencyKillSwitchActive) {
      if (srcZone === NetworkZone.PUBLIC || srcZone === NetworkZone.GUEST || srcZone === NetworkZone.DMZ) {
        return {
          blocked: true,
          reason: 'EMERGENCY KILL SWITCH ACTIVE: Sovereign isolation protocol engaged',
          action: DecisionResult.DENY,
        };
      }
    }

    // 2. Active Blocked Host / Quarantine List
    const blockedEntry = this.blockedHosts.get(srcIp);
    if (blockedEntry) {
      if (now < blockedEntry.unblockAt) {
        return {
          blocked: true,
          reason: `IPS Automated Quarantine: ${blockedEntry.reason} (Expires in ${Math.ceil((blockedEntry.unblockAt - now) / 1000)}s)`,
          action: blockedEntry.quarantinedZone ? DecisionResult.ISOLATE : DecisionResult.DENY,
        };
      } else {
        // Expired
        this.blockedHosts.delete(srcIp);
      }
    }

    return { blocked: false };
  }

  /**
   * Automatically executes an IPS mitigation triggered by a security event.
   */
  public static triggerMitigation(event: SecurityEvent, durationSeconds: number = 300) {
    if (!this.ipsAutoMitigationEnabled) return;

    const now = Date.now();
    const unblockAt = now + durationSeconds * 1000;

    let actionTaken: SecurityEvent['mitigationTaken'] = 'DROPPED';

    if (event.eventType === 'SYN_FLOOD' || event.eventType === 'PORT_SCAN') {
      this.blockedHosts.set(event.sourceIp, {
        ip: event.sourceIp,
        reason: `Automated rate drop: ${event.title}`,
        blockedAt: now,
        unblockAt,
        associatedEventId: event.id,
      });
      actionTaken = 'DROPPED';
    } else if (event.eventType === 'UNAUTHORIZED_ZONE_TRAVERSAL' || event.eventType === 'DNS_TUNNEL') {
      this.blockedHosts.set(event.sourceIp, {
        ip: event.sourceIp,
        reason: `Isolated host: ${event.title}`,
        blockedAt: now,
        unblockAt: now + 3600 * 1000, // 1 hour isolation
        associatedEventId: event.id,
        quarantinedZone: true,
      });
      actionTaken = 'QUARANTINED';
    }

    event.mitigationTaken = actionTaken;
  }

  public static setEmergencyKillSwitch(enabled: boolean): boolean {
    this.emergencyKillSwitchActive = enabled;
    return this.emergencyKillSwitchActive;
  }

  public static isKillSwitchActive(): boolean {
    return this.emergencyKillSwitchActive;
  }

  public static setAutoMitigation(enabled: boolean) {
    this.ipsAutoMitigationEnabled = enabled;
  }

  public static isAutoMitigationEnabled(): boolean {
    return this.ipsAutoMitigationEnabled;
  }

  public static getBlockedHosts(): BlockedHost[] {
    const now = Date.now();
    // Prune expired
    for (const [ip, entry] of this.blockedHosts.entries()) {
      if (now >= entry.unblockAt) {
        this.blockedHosts.delete(ip);
      }
    }
    return Array.from(this.blockedHosts.values());
  }

  public static unblockHost(ip: string): boolean {
    return this.blockedHosts.delete(ip);
  }

  public static manuallyBlockHost(ip: string, reason: string, durationSeconds: number = 3600, quarantine: boolean = false) {
    const now = Date.now();
    this.blockedHosts.set(ip, {
      ip,
      reason,
      blockedAt: now,
      unblockAt: now + durationSeconds * 1000,
      quarantinedZone: quarantine,
    });
  }
}
