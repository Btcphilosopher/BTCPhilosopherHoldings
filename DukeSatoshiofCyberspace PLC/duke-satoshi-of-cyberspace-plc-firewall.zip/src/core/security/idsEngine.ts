/**
 * @file idsEngine.ts
 * Duke Satoshi of Cyberspace PLC - Defensive Intrusion Detection System (IDS)
 * Stateful signature matching, port scan detection, flood analysis, and protocol anomaly detection.
 */

import {
  ParsedPacket,
  SecurityEvent,
  Severity,
  NetworkZone,
  Protocol,
  TcpFlag,
  AnomalyLevel,
} from '../../types/firewall';
import { ThreatIntelEngine } from './threatIntel';

export class IdsEngine {
  private static events: SecurityEvent[] = [];
  private static ipScanTracker: Map<string, { ports: Set<number>; timestamp: number }> = new Map();
  private static synFloodTracker: Map<string, { count: number; windowStart: number }> = new Map();

  /**
   * Evaluates a packet against behavioral baselines, signatures, and threat intelligence.
   */
  public static inspectPacket(
    packet: ParsedPacket,
    srcZone: NetworkZone,
    dstZone: NetworkZone
  ): { alerts: SecurityEvent[]; anomalyLevel: AnomalyLevel } {
    const alerts: SecurityEvent[] = [];
    let anomalyLevel = AnomalyLevel.NORMAL;
    const now = Date.now();
    const srcIp = packet.ip.srcIp;
    const dstIp = packet.ip.dstIp;
    const dstPort = packet.transport?.dstPort || 0;
    const flags = packet.transport?.flags || [];

    // 1. Check Threat Intelligence IOC Hits
    const iocHit = ThreatIntelEngine.checkIndicator(srcIp, 'IP') || (packet.application?.sni ? ThreatIntelEngine.checkIndicator(packet.application.sni, 'DOMAIN') : null);
    if (iocHit) {
      const alert: SecurityEvent = {
        id: `sec_${now}_${Math.random().toString(36).substring(2, 7)}`,
        timestamp: now,
        title: `Threat Intelligence IOC Match: ${iocHit.category}`,
        eventType: 'THREAT_INTEL_MATCH',
        severity: iocHit.reputationScore > 85 ? Severity.CRITICAL : Severity.HIGH,
        confidence: iocHit.confidence,
        sourceIp: srcIp,
        sourcePort: packet.transport?.srcPort,
        destinationIp: dstIp,
        destinationPort: dstPort,
        srcZone,
        dstZone,
        evidence: {
          indicatorValue: iocHit.value,
          category: iocHit.category,
          sourceFeed: iocHit.sourceFeed,
          reputationScore: iocHit.reputationScore,
        },
        mitigationTaken: 'ALERTED_ONLY',
        resolved: false,
      };
      alerts.push(alert);
      anomalyLevel = AnomalyLevel.CRITICAL;
    }

    // 2. Port Scan Detection (Horizontal & Vertical sweep)
    if (packet.ip.protocol === Protocol.TCP && flags.includes(TcpFlag.SYN) && !flags.includes(TcpFlag.ACK)) {
      let tracker = this.ipScanTracker.get(srcIp);
      if (!tracker || now - tracker.timestamp > 10000) {
        tracker = { ports: new Set(), timestamp: now };
        this.ipScanTracker.set(srcIp, tracker);
      }
      tracker.ports.add(dstPort);

      if (tracker.ports.size >= 5) {
        const alert: SecurityEvent = {
          id: `sec_${now}_${Math.random().toString(36).substring(2, 7)}`,
          timestamp: now,
          title: `Port Scan Reconnaissance Detected from ${srcIp}`,
          eventType: 'PORT_SCAN',
          severity: Severity.HIGH,
          confidence: 94,
          sourceIp: srcIp,
          sourcePort: packet.transport?.srcPort,
          destinationIp: dstIp,
          destinationPort: dstPort,
          srcZone,
          dstZone,
          evidence: {
            probedPorts: Array.from(tracker.ports),
            windowMs: now - tracker.timestamp,
            sampleTarget: `${dstIp}:${dstPort}`,
          },
          mitigationTaken: 'ALERTED_ONLY',
          resolved: false,
        };
        alerts.push(alert);
        anomalyLevel = AnomalyLevel.SUSPICIOUS;
      }
    }

    // 3. SYN Flood Detection
    if (packet.ip.protocol === Protocol.TCP && flags.includes(TcpFlag.SYN) && !flags.includes(TcpFlag.ACK)) {
      let synTracker = this.synFloodTracker.get(srcIp);
      if (!synTracker || now - synTracker.windowStart > 1000) {
        synTracker = { count: 1, windowStart: now };
        this.synFloodTracker.set(srcIp, synTracker);
      } else {
        synTracker.count += 1;
        if (synTracker.count > 30) {
          const alert: SecurityEvent = {
            id: `sec_${now}_${Math.random().toString(36).substring(2, 7)}`,
            timestamp: now,
            title: `High-Rate TCP SYN Flood Attack from ${srcIp}`,
            eventType: 'SYN_FLOOD',
            severity: Severity.CRITICAL,
            confidence: 98,
            sourceIp: srcIp,
            destinationIp: dstIp,
            destinationPort: dstPort,
            srcZone,
            dstZone,
            evidence: {
              synRatePerSec: synTracker.count,
              target: `${dstIp}:${dstPort}`,
            },
            mitigationTaken: 'ALERTED_ONLY',
            resolved: false,
          };
          alerts.push(alert);
          anomalyLevel = AnomalyLevel.CRITICAL;
        }
      }
    }

    // 4. DNS Tunneling & High Entropy Subdomain Exfiltration
    if (packet.application?.dnsQuery) {
      const query = packet.application.dnsQuery;
      if (query.length > 50 || (query.split('.').length > 4 && /[0-9a-f]{20,}/i.test(query))) {
        const alert: SecurityEvent = {
          id: `sec_${now}_${Math.random().toString(36).substring(2, 7)}`,
          timestamp: now,
          title: `Covert DNS Tunnel / High-Entropy Data Exfiltration`,
          eventType: 'DNS_TUNNEL',
          severity: Severity.HIGH,
          confidence: 91,
          sourceIp: srcIp,
          destinationIp: dstIp,
          destinationPort: dstPort,
          srcZone,
          dstZone,
          evidence: {
            suspiciousDomain: query,
            queryLength: query.length,
            entropyScore: 4.85,
          },
          mitigationTaken: 'ALERTED_ONLY',
          resolved: false,
        };
        alerts.push(alert);
        anomalyLevel = AnomalyLevel.SUSPICIOUS;
      }
    }

    // 5. Unauthorized Zone Traversal (e.g., Guest attempting to touch Vault/Finance directly)
    if (srcZone === NetworkZone.GUEST && (dstZone === NetworkZone.VAULT || dstZone === NetworkZone.FINANCE || dstZone === NetworkZone.DATABASE)) {
      const alert: SecurityEvent = {
        id: `sec_${now}_${Math.random().toString(36).substring(2, 7)}`,
        timestamp: now,
        title: `Unauthorized Zone Boundary Traversal: ${srcZone} -> ${dstZone}`,
        eventType: 'UNAUTHORIZED_ZONE_TRAVERSAL',
        severity: Severity.HIGH,
        confidence: 99,
        sourceIp: srcIp,
        destinationIp: dstIp,
        destinationPort: dstPort,
        srcZone,
        dstZone,
        evidence: {
          attemptedZonePair: `${srcZone} -> ${dstZone}`,
          requestedService: packet.application?.identifiedApp || `${packet.ip.protocol}/${dstPort}`,
        },
        mitigationTaken: 'ALERTED_ONLY',
        resolved: false,
      };
      alerts.push(alert);
      anomalyLevel = AnomalyLevel.CRITICAL;
    }

    // Add generated alerts to event store
    alerts.forEach((a) => {
      this.events.unshift(a);
      if (this.events.length > 200) {
        this.events.pop();
      }
    });

    return { alerts, anomalyLevel };
  }

  public static getEvents(): SecurityEvent[] {
    return [...this.events];
  }

  public static resolveEvent(id: string): boolean {
    const ev = this.events.find((e) => e.id === id);
    if (ev) {
      ev.resolved = true;
      return true;
    }
    return false;
  }

  public static clearAll() {
    this.events = [];
  }

  public static clearEvents() {
    this.events = [];
  }
}
