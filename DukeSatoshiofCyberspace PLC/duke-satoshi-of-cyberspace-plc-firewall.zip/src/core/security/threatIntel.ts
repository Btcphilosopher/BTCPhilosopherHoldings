/**
 * @file threatIntel.ts
 * Duke Satoshi of Cyberspace PLC - Pluggable Threat Intelligence Subsystem
 * Feed subscriber, IOC matching engine, versioning, rollback, and reputation lookup.
 */

import { ThreatIndicator } from '../../types/firewall';

export interface ThreatFeedSnapshot {
  version: number;
  timestamp: number;
  author: string;
  indicators: ThreatIndicator[];
}

export class ThreatIntelEngine {
  private static activeIndicators: Map<string, ThreatIndicator> = new Map();
  private static feedHistory: ThreatFeedSnapshot[] = [];
  private static currentVersion = 1;

  public static initializeDefaultFeeds() {
    const defaultIOCs: ThreatIndicator[] = [
      {
        id: 'ioc_001',
        type: 'IP',
        value: '198.51.100.42',
        category: 'C2_BOTNET',
        reputationScore: 98,
        sourceFeed: 'Duke Satoshi Sovereign Threat Watch',
        confidence: 99,
        addedAt: Date.now() - 86400000,
        expiresAt: Date.now() + 86400000 * 30,
        active: true,
      },
      {
        id: 'ioc_002',
        type: 'IP',
        value: '203.0.113.88',
        category: 'EXPLOIT_SCANNER',
        reputationScore: 85,
        sourceFeed: 'Global Edge Abuse Feed',
        confidence: 90,
        addedAt: Date.now() - 43200000,
        expiresAt: Date.now() + 86400000 * 14,
        active: true,
      },
      {
        id: 'ioc_003',
        type: 'DOMAIN',
        value: 'exfil-vault.darknet-relay.org',
        category: 'APT_SOVEREIGN',
        reputationScore: 100,
        sourceFeed: 'Financial Sector ISAC Feed',
        confidence: 98,
        addedAt: Date.now() - 10000000,
        expiresAt: Date.now() + 86400000 * 60,
        active: true,
      },
      {
        id: 'ioc_004',
        type: 'DOMAIN',
        value: 'tunnel.dns-fast-covert.biz',
        category: 'MALICIOUS_DNS',
        reputationScore: 92,
        sourceFeed: 'DNS Threat Sentinel',
        confidence: 95,
        addedAt: Date.now() - 20000000,
        expiresAt: Date.now() + 86400000 * 30,
        active: true,
      },
      {
        id: 'ioc_005',
        type: 'CIDR',
        value: '198.18.0.0/15',
        category: 'TOR_EXIT_NODE',
        reputationScore: 75,
        sourceFeed: 'Anonymous Relay Consortium',
        confidence: 85,
        addedAt: Date.now() - 50000000,
        expiresAt: Date.now() + 86400000 * 90,
        active: true,
      },
    ];

    defaultIOCs.forEach((ioc) => this.activeIndicators.set(ioc.value.toLowerCase(), ioc));
    this.feedHistory.push({
      version: 1,
      timestamp: Date.now(),
      author: 'Duke Satoshi Threat Intel Feed v1.0',
      indicators: [...defaultIOCs],
    });
  }

  /**
   * Checks if an IP or domain matches any threat indicator.
   */
  public static checkIndicator(value: string, type: 'IP' | 'DOMAIN'): ThreatIndicator | null {
    if (!value) return null;
    const cleanVal = value.toLowerCase().trim();

    // Exact Match
    const exact = this.activeIndicators.get(cleanVal);
    if (exact && exact.active && exact.expiresAt > Date.now()) {
      return exact;
    }

    // Check CIDRs if IP
    if (type === 'IP') {
      for (const ioc of this.activeIndicators.values()) {
        if (ioc.type === 'CIDR' && ioc.active && ioc.expiresAt > Date.now()) {
          if (this.ipInCidr(cleanVal, ioc.value)) {
            return ioc;
          }
        }
      }
    }

    return null;
  }

  public static getAllIndicators(): ThreatIndicator[] {
    if (this.activeIndicators.size === 0) {
      this.initializeDefaultFeeds();
    }
    return Array.from(this.activeIndicators.values());
  }

  public static addIndicator(ioc: ThreatIndicator) {
    this.activeIndicators.set(ioc.value.toLowerCase(), ioc);
  }

  public static deleteIndicator(id: string): boolean {
    for (const [key, ioc] of this.activeIndicators.entries()) {
      if (ioc.id === id) {
        this.activeIndicators.delete(key);
        return true;
      }
    }
    return false;
  }

  public static importFeed(indicators: ThreatIndicator[], author: string): number {
    this.currentVersion += 1;
    indicators.forEach((ioc) => this.activeIndicators.set(ioc.value.toLowerCase(), ioc));

    this.feedHistory.push({
      version: this.currentVersion,
      timestamp: Date.now(),
      author,
      indicators: Array.from(this.activeIndicators.values()),
    });

    return this.currentVersion;
  }

  public static rollbackFeed(targetVersion: number): boolean {
    const target = this.feedHistory.find((f) => f.version === targetVersion);
    if (!target) return false;

    this.activeIndicators.clear();
    target.indicators.forEach((ioc) => this.activeIndicators.set(ioc.value.toLowerCase(), ioc));
    this.currentVersion = targetVersion;
    return true;
  }

  public static getFeedHistory(): ThreatFeedSnapshot[] {
    return [...this.feedHistory];
  }

  private static ipInCidr(ip: string, cidr: string): boolean {
    const [range, bitsStr] = cidr.split('/');
    const bits = parseInt(bitsStr, 10);
    const ipNum = this.ipToNumber(ip);
    const rangeNum = this.ipToNumber(range);
    if (ipNum === null || rangeNum === null) return false;
    const mask = bits === 0 ? 0 : (~0 << (32 - bits)) >>> 0;
    return (ipNum & mask) === (rangeNum & mask);
  }

  private static ipToNumber(ip: string): number | null {
    const parts = ip.split('.').map(Number);
    if (parts.length !== 4) return null;
    return (((parts[0] << 24) >>> 0) + (parts[1] << 16) + (parts[2] << 8) + parts[3]) >>> 0;
  }
}
