/**
 * @file firewallInit.ts
 * Duke Satoshi of Cyberspace PLC - System Bootstrapper
 */

import { ConfigManager } from './config/configManager';
import { ThreatIntelEngine } from './security/threatIntel';
import { AuditLogger } from './telemetry/auditLogger';

let initialized = false;

export function bootstrapFirewall() {
  if (initialized) return;
  ConfigManager.initialize();
  ThreatIntelEngine.initializeDefaultFeeds();
  AuditLogger.initializeDefaultLogs();
  initialized = true;
}
