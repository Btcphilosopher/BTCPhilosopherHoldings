/**
 * @file policyGraph.ts
 * Duke Satoshi of Cyberspace PLC - Security Zone Graph & Micro-Segmentation Topology
 * Computes topological trust boundaries, inter-zone policy paths, and microsegmentation matrix.
 */

import { NetworkZone, FirewallRule, RuleAction, ConnectionTrackEntry } from '../../types/firewall';

export interface ZoneNode {
  id: NetworkZone;
  name: string;
  trustLevel: number; // 0 (Untrusted / Internet) to 100 (Sovereign Vault)
  color: string;
  description: string;
  hostCount: number;
  activeFlowCount: number;
}

export interface ZoneEdge {
  source: NetworkZone;
  target: NetworkZone;
  policyStatus: 'ALLOWED' | 'DENIED' | 'CONDITIONAL' | 'RESTRICTED';
  ruleIds: string[];
  rules: FirewallRule[];
  activeConnections: number;
  allowedBandwidthMbps: number;
}

export class PolicyGraphEngine {
  public static readonly ZONE_DEFINITIONS: Record<NetworkZone, Omit<ZoneNode, 'activeFlowCount'>> = {
    [NetworkZone.PUBLIC]: {
      id: NetworkZone.PUBLIC,
      name: 'Public Internet / WAN',
      trustLevel: 0,
      color: '#ef4444',
      description: 'External untrusted ingress and egress transit network',
      hostCount: 24000,
    },
    [NetworkZone.DMZ]: {
      id: NetworkZone.DMZ,
      name: 'Demilitarized Zone (DMZ)',
      trustLevel: 25,
      color: '#f97316',
      description: 'Public-facing reverse proxies, WAF, load balancers, and external DNS',
      hostCount: 16,
    },
    [NetworkZone.GUEST]: {
      id: NetworkZone.GUEST,
      name: 'Guest Wireless Network',
      trustLevel: 10,
      color: '#eab308',
      description: 'Visitor and BYOD untrusted client perimeter',
      hostCount: 48,
    },
    [NetworkZone.QUARANTINE]: {
      id: NetworkZone.QUARANTINE,
      name: 'Quarantine & Isolation Zone',
      trustLevel: 5,
      color: '#dc2626',
      description: 'Compromised or non-compliant devices undergoing automated remediation',
      hostCount: 2,
    },
    [NetworkZone.CORPORATE]: {
      id: NetworkZone.CORPORATE,
      name: 'Corporate Office LAN',
      trustLevel: 50,
      color: '#3b82f6',
      description: 'Employee workstations, managed devices, internal communications',
      hostCount: 320,
    },
    [NetworkZone.DEVELOPMENT]: {
      id: NetworkZone.DEVELOPMENT,
      name: 'Engineering & Sandbox',
      trustLevel: 40,
      color: '#06b6d4',
      description: 'CI/CD runners, staging clusters, code repositories',
      hostCount: 64,
    },
    [NetworkZone.PRODUCTION]: {
      id: NetworkZone.PRODUCTION,
      name: 'Production Cloud Cluster',
      trustLevel: 75,
      color: '#10b981',
      description: 'Live transactional microservices, API gateways, execution nodes',
      hostCount: 128,
    },
    [NetworkZone.FINANCE]: {
      id: NetworkZone.FINANCE,
      name: 'Private Banking & SWIFT Core',
      trustLevel: 90,
      color: '#8b5cf6',
      description: 'Ledger engines, SWIFT messaging, institutional trading desks',
      hostCount: 24,
    },
    [NetworkZone.DATABASE]: {
      id: NetworkZone.DATABASE,
      name: 'Relational & In-Memory Store',
      trustLevel: 85,
      color: '#a855f7',
      description: 'Encrypted storage pools, PostgreSQL primary replicas, Redis cache',
      hostCount: 32,
    },
    [NetworkZone.VAULT]: {
      id: NetworkZone.VAULT,
      name: 'Duke Satoshi Sovereign Vault',
      trustLevel: 100,
      color: '#f59e0b',
      description: 'Hardware Security Modules (HSM), cold key signers, air-gapped cryptographic cores',
      hostCount: 6,
    },
    [NetworkZone.MANAGEMENT]: {
      id: NetworkZone.MANAGEMENT,
      name: 'Out-of-Band (OOB) Admin',
      trustLevel: 95,
      color: '#ec4899',
      description: 'Dedicated isolated management network, IPMI, firewall control plane',
      hostCount: 8,
    },
    [NetworkZone.ADMINISTRATION]: {
      id: NetworkZone.ADMINISTRATION,
      name: 'Identity & PKI Directory',
      trustLevel: 90,
      color: '#6366f1',
      description: 'Zero-Trust Policy Decision Point, Active Directory, Root CA',
      hostCount: 12,
    },
  };

  /**
   * Builds the comprehensive zone graph with policy edges and active flow counts.
   */
  public static buildGraph(rules: FirewallRule[], connections: ConnectionTrackEntry[]): {
    nodes: ZoneNode[];
    edges: ZoneEdge[];
    matrix: Record<NetworkZone, Record<NetworkZone, { allowed: boolean; ruleCount: number }>>;
  } {
    // 1. Calculate active connections per zone
    const flowCountByZone: Record<NetworkZone, number> = {} as any;
    const flowCountByEdge: Record<string, number> = {};

    Object.values(NetworkZone).forEach((z) => (flowCountByZone[z] = 0));

    connections.forEach((c) => {
      flowCountByZone[c.srcZone] = (flowCountByZone[c.srcZone] || 0) + 1;
      flowCountByZone[c.dstZone] = (flowCountByZone[c.dstZone] || 0) + 1;

      const edgeKey = `${c.srcZone}->${c.dstZone}`;
      flowCountByEdge[edgeKey] = (flowCountByEdge[edgeKey] || 0) + 1;
    });

    const nodes: ZoneNode[] = Object.values(this.ZONE_DEFINITIONS).map((def) => ({
      ...def,
      activeFlowCount: flowCountByZone[def.id] || 0,
    }));

    // 2. Build edges and policy matrix
    const matrix: any = {};
    const edgeMap: Map<string, ZoneEdge> = new Map();

    const allZones = Object.values(NetworkZone);
    allZones.forEach((src) => {
      matrix[src] = {};
      allZones.forEach((dst) => {
        matrix[src][dst] = { allowed: false, ruleCount: 0 };
      });
    });

    // Check rules for permitted zone-to-zone transitions
    rules.forEach((rule) => {
      if (!rule.enabled) return;

      const srcZones = rule.srcZone === 'ANY' ? allZones : [rule.srcZone];
      const dstZones = rule.dstZone === 'ANY' ? allZones : [rule.dstZone];

      srcZones.forEach((s) => {
        dstZones.forEach((d) => {
          if (s === d) return; // Intra-zone

          matrix[s][d].ruleCount += 1;
          if (rule.action === RuleAction.ALLOW) {
            matrix[s][d].allowed = true;
          }

          const edgeKey = `${s}->${d}`;
          let edge = edgeMap.get(edgeKey);
          if (!edge) {
            edge = {
              source: s,
              target: d,
              policyStatus: rule.action === RuleAction.ALLOW ? 'ALLOWED' : 'DENIED',
              ruleIds: [rule.id],
              rules: [rule],
              activeConnections: flowCountByEdge[edgeKey] || 0,
              allowedBandwidthMbps: rule.action === RuleAction.ALLOW ? 10000 : 0,
            };
            edgeMap.set(edgeKey, edge);
          } else {
            edge.ruleIds.push(rule.id);
            edge.rules.push(rule);
            if (rule.action === RuleAction.ALLOW) {
              edge.policyStatus = 'ALLOWED';
            }
          }
        });
      });
    });

    const edges = Array.from(edgeMap.values());

    return { nodes, edges, matrix };
  }
}
