/**
 * @file policySimulator.ts
 * Duke Satoshi of Cyberspace PLC - Pre-Commit Policy Simulator
 * Analyzes blast radius, affected active connections, service disruption, and management lockout risk.
 */

import {
  FirewallRule,
  RuleAction,
  NetworkZone,
  ConnectionTrackEntry,
  PolicySimulationResult,
  DecisionResult,
} from '../../types/firewall';
import { RuleEngine } from './ruleEngine';

export class PolicySimulator {
  /**
   * Simulates the exact consequence of adding or modifying a candidate rule
   * before it is committed to production.
   */
  public static simulate(
    proposedRule: FirewallRule,
    existingRules: FirewallRule[],
    activeConnections: ConnectionTrackEntry[]
  ): PolicySimulationResult {
    // 1. Check for Critical Management Lockout Risk
    let managementAccessRisk = false;
    const isBlockingAction = proposedRule.action === RuleAction.DENY || proposedRule.action === RuleAction.REJECT;

    if (
      isBlockingAction &&
      (proposedRule.dstZone === NetworkZone.MANAGEMENT || proposedRule.dstZone === 'ANY') &&
      (proposedRule.dstPort === '22' || proposedRule.dstPort === '443' || proposedRule.dstPort === 'ANY')
    ) {
      // Check if it has higher priority than existing management allow rules
      managementAccessRisk = true;
    }

    // 2. Simulate proposed rule table (insert candidate at its priority position)
    const simulatedRules = [...existingRules.filter((r) => r.id !== proposedRule.id), proposedRule].sort(
      (a, b) => a.priority - b.priority
    );

    let affectedExistingFlows = 0;
    let newlyAllowedFlows = 0;
    let newlyBlockedFlows = 0;
    const affectedHostsSet = new Set<string>();
    const affectedServicesSet = new Set<string>();
    const affectedZonesMap = new Map<string, { from: NetworkZone; to: NetworkZone }>();

    // 3. Test active connections against current vs proposed rule table
    activeConnections.forEach((conn) => {
      const currentDecision = conn.decision;

      // Evaluate against proposed rule
      const ruleMatchesSrcZone = proposedRule.srcZone === 'ANY' || proposedRule.srcZone === conn.srcZone;
      const ruleMatchesDstZone = proposedRule.dstZone === 'ANY' || proposedRule.dstZone === conn.dstZone;
      const ruleMatchesProto = proposedRule.protocol === 'ANY' || proposedRule.protocol === conn.protocol;
      const ruleMatchesSrcIp = RuleEngine.matchIpCidr(conn.srcIp, proposedRule.srcAddress);
      const ruleMatchesDstIp = RuleEngine.matchIpCidr(conn.dstIp, proposedRule.dstAddress);
      const ruleMatchesPort = RuleEngine.matchPort(conn.dstPort, proposedRule.dstPort);

      const matchesProposed =
        ruleMatchesSrcZone &&
        ruleMatchesDstZone &&
        ruleMatchesProto &&
        ruleMatchesSrcIp &&
        ruleMatchesDstIp &&
        ruleMatchesPort;

      if (matchesProposed) {
        const proposedDecision =
          proposedRule.action === RuleAction.ALLOW
            ? DecisionResult.ALLOW
            : proposedRule.action === RuleAction.RATE_LIMIT
            ? DecisionResult.RATE_LIMIT
            : DecisionResult.DENY;

        if (proposedDecision !== currentDecision) {
          affectedExistingFlows += 1;
          if (proposedDecision === DecisionResult.ALLOW && currentDecision === DecisionResult.DENY) {
            newlyAllowedFlows += 1;
          } else if (proposedDecision === DecisionResult.DENY && currentDecision === DecisionResult.ALLOW) {
            newlyBlockedFlows += 1;
          }

          affectedHostsSet.add(conn.srcIp);
          affectedHostsSet.add(conn.dstIp);
          affectedServicesSet.add(conn.application || `${conn.protocol}/${conn.dstPort}`);

          const zoneKey = `${conn.srcZone}->${conn.dstZone}`;
          if (!affectedZonesMap.has(zoneKey)) {
            affectedZonesMap.set(zoneKey, { from: conn.srcZone, to: conn.dstZone });
          }
        }
      }
    });

    // 4. Calculate Severity Rating
    let impactSeverity: PolicySimulationResult['impactSeverity'] = 'LOW';
    if (managementAccessRisk) {
      impactSeverity = 'BREAKING_MANAGEMENT';
    } else if (newlyBlockedFlows > 10 || affectedExistingFlows > 20) {
      impactSeverity = 'HIGH';
    } else if (newlyBlockedFlows > 0 || affectedExistingFlows > 0) {
      impactSeverity = 'MEDIUM';
    }

    // 5. Generate human-readable summary
    let summary = '';
    if (managementAccessRisk) {
      summary = `CRITICAL WARNING: This candidate rule poses a direct risk to administrator out-of-band management access (Zone MANAGEMENT / Port ${proposedRule.dstPort}). Activating this rule may cause an immediate administrator lockout.`;
    } else if (affectedExistingFlows === 0) {
      summary = `Safe change. No active live connections will be disrupted by activating this ${proposedRule.action} rule.`;
    } else {
      summary = `Candidate rule will immediately modify ${affectedExistingFlows} live flow(s) across ${affectedHostsSet.size} host(s) and ${affectedServicesSet.size} service(s) (${newlyBlockedFlows} flows newly blocked, ${newlyAllowedFlows} flows newly allowed).`;
    }

    return {
      ruleId: proposedRule.id,
      ruleName: proposedRule.name,
      action: proposedRule.action,
      affectedExistingFlows,
      newlyAllowedFlows,
      newlyBlockedFlows,
      affectedHosts: Array.from(affectedHostsSet),
      affectedServices: Array.from(affectedServicesSet),
      affectedZones: Array.from(affectedZonesMap.values()),
      impactSeverity,
      managementAccessRisk,
      summary,
    };
  }
}
