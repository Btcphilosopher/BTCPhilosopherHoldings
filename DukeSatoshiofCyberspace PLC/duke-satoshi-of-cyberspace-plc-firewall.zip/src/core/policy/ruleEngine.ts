/**
 * @file ruleEngine.ts
 * Duke Satoshi of Cyberspace PLC - Deterministic Enterprise Policy & ACL Engine
 * Multi-dimensional rule matching, default-deny security posture, and explainable decision tracing.
 */

import {
  FirewallRule,
  RuleAction,
  NetworkZone,
  Protocol,
  DecisionContext,
  DecisionResult,
  ParsedPacket,
  ConnectionTrackEntry,
} from '../../types/firewall';

export class RuleEngine {
  private static rules: FirewallRule[] = [];
  private static defaultPolicyAction: RuleAction = RuleAction.DENY;

  /**
   * Initializes or updates the active rule base with sorted priority order.
   */
  public static setRules(rules: FirewallRule[]) {
    this.rules = [...rules].sort((a, b) => a.priority - b.priority);
  }

  public static getRules(): FirewallRule[] {
    return [...this.rules];
  }

  public static addRule(rule: FirewallRule) {
    this.rules.push(rule);
    this.rules.sort((a, b) => a.priority - b.priority);
  }

  public static deleteRule(ruleId: string): boolean {
    const initialLen = this.rules.length;
    this.rules = this.rules.filter((r) => r.id !== ruleId);
    return this.rules.length !== initialLen;
  }

  public static updateRule(updated: FirewallRule): boolean {
    const idx = this.rules.findIndex((r) => r.id === updated.id);
    if (idx >= 0) {
      this.rules[idx] = updated;
      this.rules.sort((a, b) => a.priority - b.priority);
      return true;
    }
    return false;
  }

  /**
   * Evaluates a packet and its context against the rule table.
   */
  public static evaluate(
    packet: ParsedPacket,
    srcZone: NetworkZone,
    dstZone: NetworkZone,
    userContext?: {
      userId?: string;
      roles?: string[];
      mfaVerified?: boolean;
      deviceTrust?: 'UNTRUSTED' | 'KNOWN' | 'CORPORATE_MANAGED' | 'HARDWARE_ATTESTED';
      deviceId?: string;
    },
    riskScore: number = 0
  ): { matchedRule?: FirewallRule; decision: DecisionResult; reason: string } {
    const now = Date.now();
    const srcIp = packet.ip.srcIp;
    const dstIp = packet.ip.dstIp;
    const protocol = packet.ip.protocol;
    const dstPort = packet.transport?.dstPort || 0;
    const srcPort = packet.transport?.srcPort || 0;
    const app = packet.application?.identifiedApp || '';

    for (const rule of this.rules) {
      if (!rule.enabled) continue;

      // Check Expiration
      if (rule.expiresAt && rule.expiresAt < now) continue;

      // 1. Zone Matching
      if (rule.srcZone !== 'ANY' && rule.srcZone !== srcZone) continue;
      if (rule.dstZone !== 'ANY' && rule.dstZone !== dstZone) continue;

      // 2. Protocol Matching
      if (rule.protocol !== 'ANY' && rule.protocol !== protocol) continue;

      // 3. IP / Subnet Matching
      if (!this.matchIpCidr(srcIp, rule.srcAddress)) continue;
      if (!this.matchIpCidr(dstIp, rule.dstAddress)) continue;

      // 4. Port Matching
      if (!this.matchPort(dstPort, rule.dstPort)) continue;
      if (rule.srcPort && !this.matchPort(srcPort, rule.srcPort)) continue;

      // 5. Application Matching
      if (rule.application !== 'ANY') {
        const reqApp = rule.application.toUpperCase();
        const detected = app.toUpperCase();
        if (!detected.includes(reqApp) && !reqApp.includes(detected)) {
          continue;
        }
      }

      // 6. Zero-Trust & Identity Check
      if (rule.identityRequired) {
        if (!userContext?.userId) continue;
        if (rule.requiredGroup && (!userContext.roles || !userContext.roles.includes(rule.requiredGroup))) {
          continue;
        }
      }

      // 7. Device Trust Level
      if (rule.minDeviceTrust && rule.minDeviceTrust !== 'ANY') {
        const trust = userContext?.deviceTrust || 'UNTRUSTED';
        if (rule.minDeviceTrust === 'HARDWARE_TOKEN_VERIFIED' && trust !== 'HARDWARE_ATTESTED') continue;
        if (rule.minDeviceTrust === 'CORPORATE_MANAGED' && (trust === 'UNTRUSTED' || trust === 'KNOWN')) continue;
      }

      // Rule Matched!
      rule.hitCount += 1;
      rule.lastHitAt = now;

      let decision = DecisionResult.ALLOW;
      if (rule.action === RuleAction.DENY) decision = DecisionResult.DENY;
      else if (rule.action === RuleAction.REJECT) decision = DecisionResult.DENY;
      else if (rule.action === RuleAction.RATE_LIMIT) decision = DecisionResult.RATE_LIMIT;
      else if (rule.action === RuleAction.ISOLATE) decision = DecisionResult.ISOLATE;

      return {
        matchedRule: rule,
        decision,
        reason: `Matched Rule #${rule.priority} [${rule.name}]: ${rule.action} from Zone ${rule.srcZone} to ${rule.dstZone}`,
      };
    }

    // Default Deny Posture
    return {
      decision: DecisionResult.DENY,
      reason: `Implicit Default Deny: No policy permitted traffic from Zone ${srcZone} (${srcIp}) to Zone ${dstZone} (${dstIp}:${dstPort})`,
    };
  }

  /**
   * Evaluates IP match against 'ANY', exact IP, or CIDR (e.g., 192.168.1.0/24).
   */
  public static matchIpCidr(ip: string, pattern: string): boolean {
    if (pattern === 'ANY' || pattern === '*' || pattern === '0.0.0.0/0') return true;
    if (pattern === ip) return true;

    if (pattern.includes('/')) {
      const [subnet, prefixStr] = pattern.split('/');
      const prefix = parseInt(prefixStr, 10);
      if (isNaN(prefix) || prefix < 0 || prefix > 32) return false;

      const ipNum = this.ipToNumber(ip);
      const subnetNum = this.ipToNumber(subnet);
      if (ipNum === null || subnetNum === null) return false;

      const mask = prefix === 0 ? 0 : (~0 << (32 - prefix)) >>> 0;
      return (ipNum & mask) === (subnetNum & mask);
    }

    return false;
  }

  public static matchPort(port: number, portPattern?: string): boolean {
    if (!portPattern || portPattern === 'ANY' || portPattern === '*') return true;
    if (portPattern.includes(',')) {
      const parts = portPattern.split(',').map((p) => p.trim());
      return parts.some((p) => this.matchPort(port, p));
    }
    if (portPattern.includes('-')) {
      const [minStr, maxStr] = portPattern.split('-');
      const min = parseInt(minStr, 10);
      const max = parseInt(maxStr, 10);
      return port >= min && port <= max;
    }
    const single = parseInt(portPattern, 10);
    return port === single;
  }

  private static ipToNumber(ip: string): number | null {
    const parts = ip.split('.').map(Number);
    if (parts.length !== 4 || parts.some((p) => isNaN(p) || p < 0 || p > 255)) return null;
    return (((parts[0] << 24) >>> 0) + (parts[1] << 16) + (parts[2] << 8) + parts[3]) >>> 0;
  }
}
