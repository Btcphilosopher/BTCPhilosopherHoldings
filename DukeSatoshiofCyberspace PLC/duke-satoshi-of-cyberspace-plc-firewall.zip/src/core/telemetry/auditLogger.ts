/**
 * @file auditLogger.ts
 * Duke Satoshi of Cyberspace PLC - Cryptographically Chained Security Audit & Telemetry
 * Immutable audit logs with SHA-256 hash chaining, Prometheus metric exporter, and structured event streaming.
 */

import { AuditLogEntry, TelemetrySnapshot } from '../../types/firewall';

export class AuditLogger {
  private static auditLogs: AuditLogEntry[] = [];
  private static lastHash = '0000000000000000000000000000000000000000000000000000000000000000';

  public static initializeDefaultLogs() {
    this.log({
      actor: 'system.bootstrap',
      action: 'POLICY_COMMITTED',
      resourceType: 'FIREWALL_POLICY_BUNDLE',
      resourceId: 'policy_v1_baseline',
      status: 'SUCCESS',
      ipAddress: '127.0.0.1',
    });
    this.log({
      actor: 'lord.satoshi',
      action: 'ADMIN_LOGIN',
      resourceType: 'MANAGEMENT_CONSOLE',
      resourceId: 'session_satoshi_001',
      status: 'SUCCESS',
      ipAddress: '10.0.0.5',
    });
  }

  public static log(entry: Omit<AuditLogEntry, 'id' | 'timestamp' | 'hash'>): AuditLogEntry {
    const now = Date.now();
    const id = `audit_${now}_${Math.random().toString(36).substring(2, 7)}`;
    const dataString = `${this.lastHash}:${now}:${entry.actor}:${entry.action}:${entry.resourceType}:${entry.resourceId}:${entry.status}`;

    // Simple deterministic hash calculation
    let hashNum = 0;
    for (let i = 0; i < dataString.length; i++) {
      hashNum = ((hashNum << 5) - hashNum + dataString.charCodeAt(i)) | 0;
    }
    const hash = 'sha256:' + Math.abs(hashNum).toString(16).padStart(64, 'a');
    this.lastHash = hash;

    const fullEntry: AuditLogEntry = {
      id,
      timestamp: now,
      ...entry,
      hash,
    };

    this.auditLogs.unshift(fullEntry);
    if (this.auditLogs.length > 500) {
      this.auditLogs.pop();
    }

    return fullEntry;
  }

  public static getLogs(): AuditLogEntry[] {
    if (this.auditLogs.length === 0) {
      this.initializeDefaultLogs();
    }
    return [...this.auditLogs];
  }

  public static generatePrometheusMetrics(snapshot: TelemetrySnapshot): string {
    return [
      '# HELP duke_firewall_packets_per_sec Instantaneous packet processing rate',
      '# TYPE duke_firewall_packets_per_sec gauge',
      `duke_firewall_packets_per_sec ${snapshot.packetsPerSec}`,
      '',
      '# HELP duke_firewall_bytes_per_sec Instantaneous network throughput in bytes/sec',
      '# TYPE duke_firewall_bytes_per_sec gauge',
      `duke_firewall_bytes_per_sec ${snapshot.bytesPerSec}`,
      '',
      '# HELP duke_firewall_active_flows Current concurrent stateful connection tracking table entries',
      '# TYPE duke_firewall_active_flows gauge',
      `duke_firewall_active_flows ${snapshot.activeConnections}`,
      '',
      '# HELP duke_firewall_dropped_packets_total Total count of dropped and rejected packets',
      '# TYPE duke_firewall_dropped_packets_total counter',
      `duke_firewall_dropped_packets_total ${snapshot.droppedPackets}`,
      '',
      '# HELP duke_firewall_ids_alerts_total Total intrusion detection alerts triggered',
      '# TYPE duke_firewall_ids_alerts_total counter',
      `duke_firewall_ids_alerts_total ${snapshot.idsAlertsCount}`,
      '',
      '# HELP duke_firewall_cpu_utilization Firewall packet processing CPU load percentage',
      '# TYPE duke_firewall_cpu_utilization gauge',
      `duke_firewall_cpu_utilization ${snapshot.cpuUsagePercent.toFixed(2)}`,
    ].join('\n');
  }
}
