/**
 * @file syntheticTraffic.ts
 * Duke Satoshi of Cyberspace PLC - Genuine Pipeline Orchestrator & Traffic Flow Generator
 * Feeds RFC-compliant packet byte arrays through Parser -> IPS -> NAT -> Route -> Policy -> Conntrack -> IDS -> Telemetry.
 */

import {
  Protocol,
  TcpFlag,
  NetworkZone,
  DecisionResult,
  DecisionContext,
  ParsedPacket,
  ConnectionTrackEntry,
  TelemetrySnapshot,
  RuleAction,
} from '../../types/firewall';
import { PacketEngine } from '../packet/packetEngine';
import { ConnectionTrackingEngine } from '../state/conntrack';
import { RuleEngine } from '../policy/ruleEngine';
import { RiskEngine } from '../security/riskEngine';
import { IdsEngine } from '../security/idsEngine';
import { IpsEngine } from '../security/ipsEngine';
import { NatEngine } from '../network/natEngine';
import { RoutingEngine } from '../network/routingEngine';
import { DnsSecurityEngine } from '../security/dnsSecurity';
import { ZeroTrustEngine } from '../identity/zeroTrust';

export interface TrafficScenario {
  id: string;
  name: string;
  description: string;
  intensity: 'LOW' | 'NORMAL' | 'HEAVY' | 'STRESS_ATTACK';
  attackType?: 'NONE' | 'PORT_SCAN' | 'SYN_FLOOD' | 'DNS_TUNNEL' | 'VAULT_EXFILTRATION';
}

export class PipelineOrchestrator {
  private static trafficHistory: DecisionContext[] = [];
  private static packetCountTotal = 0;
  private static dropCountTotal = 0;
  private static bytesCountTotal = 0;
  private static isRunning = true;
  private static activeScenario: TrafficScenario = {
    id: 'scen_enterprise_normal',
    name: 'Standard Sovereign Enterprise & Banking Flow',
    description: 'Realistic inter-zone banking ledger transfers, database queries, corporate web, and DMZ requests',
    intensity: 'NORMAL',
    attackType: 'NONE',
  };

  /**
   * Processes a single raw or built packet through the entire security pipeline.
   */
  public static processSinglePacket(
    rawBytesOrHex: Uint8Array | string,
    srcInterfaceId: string = 'if_corp0',
    simulatedUser?: {
      userId?: string;
      userName?: string;
      roles?: string[];
      mfaVerified?: boolean;
      deviceTrust?: 'UNTRUSTED' | 'KNOWN' | 'CORPORATE_MANAGED' | 'HARDWARE_ATTESTED';
      deviceId?: string;
    }
  ): { packet: ParsedPacket; context: DecisionContext; conntrackEntry: ConnectionTrackEntry } {
    const parsedRaw = PacketEngine.parsePacket(rawBytesOrHex, srcInterfaceId);
    if (!parsedRaw.isValid || !parsedRaw.parsed) {
      throw new Error(`Packet validation error: ${parsedRaw.validationError || 'Invalid raw frame'}`);
    }

    const packet = parsedRaw.parsed;
    const now = Date.now();
    this.packetCountTotal += 1;
    this.bytesCountTotal += packet.ip.totalLength || 64;

    // 1. Determine Source & Destination Zones from IP Subnets
    const srcZone = RoutingEngine.getZoneForIp(packet.ip.srcIp);
    const dstZone = RoutingEngine.getZoneForIp(packet.ip.dstIp);

    // 2. IPS & Kill Switch Pre-Check
    const ipsCheck = IpsEngine.shouldMitigate(packet.ip.srcIp, srcZone);

    // 3. Routing Table Lookup
    const route = RoutingEngine.lookupRoute(packet.ip.dstIp, packet.ip.protocol, srcZone);

    // 4. NAT Translation Evaluation
    const nat = NatEngine.processNat(packet, srcZone, dstZone);

    // 5. IDS & Attack Inspection
    const { alerts, anomalyLevel } = IdsEngine.inspectPacket(packet, srcZone, dstZone);

    // If severe attack detected, trigger automated IPS mitigation
    if (alerts.length > 0 && IpsEngine.isAutoMitigationEnabled()) {
      alerts.forEach((alert) => {
        IpsEngine.triggerMitigation(alert);
      });
    }

    // 6. Transparent Risk Score Computation
    const risk = RiskEngine.evaluateRisk(
      packet,
      srcZone,
      dstZone,
      simulatedUser,
      alerts.filter((a) => a.eventType === 'THREAT_INTEL_MATCH').length,
      anomalyLevel
    );

    // 7. Policy & ACL Rule Table Evaluation
    let policyResult = RuleEngine.evaluate(packet, srcZone, dstZone, simulatedUser, risk.totalScore);

    // Override if IPS or Kill Switch Block is in effect
    let finalDecision = policyResult.decision;
    let explanation = policyResult.reason;

    if (ipsCheck.blocked) {
      finalDecision = DecisionResult.DENY;
      explanation = `BLOCKED by Intrusion Prevention: ${ipsCheck.reason}`;
      this.dropCountTotal += 1;
    } else if (finalDecision === DecisionResult.DENY) {
      this.dropCountTotal += 1;
    }

    // 8. Stateful Connection Tracking Update
    const { entry: conntrackEntry } = ConnectionTrackingEngine.processPacket(
      packet,
      srcZone,
      dstZone,
      finalDecision,
      policyResult.matchedRule?.id
    );
    conntrackEntry.riskScore = risk.totalScore;
    conntrackEntry.decision = finalDecision;

    // 9. Construct Comprehensive Decision Context (WHO, WHAT, WHERE, WHEN, HOW, WHY, RISK, POLICY, STATE)
    const dateObj = new Date(now);
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const hours = dateObj.getHours();
    const isBizHours = hours >= 8 && hours <= 18 && dateObj.getDay() >= 1 && dateObj.getDay() <= 5;

    const context: DecisionContext = {
      connectionId: conntrackEntry.id,
      timestamp: now,
      who: {
        userId: simulatedUser?.userId || 'anonymous_client',
        userName: simulatedUser?.userName || 'External Unauthenticated Entity',
        identityProvider: simulatedUser?.userId ? 'Duke Satoshi Sovereign Active Directory' : 'None',
        mfaVerified: !!simulatedUser?.mfaVerified,
        roles: simulatedUser?.roles || ['GUEST_ROLE'],
        certificateThumbprint: simulatedUser?.userId ? 'SHA256:4C:5B:6A:11:88:99:FF:01' : undefined,
      },
      what: {
        protocol: packet.ip.protocol,
        dstPort: packet.transport?.dstPort || 0,
        application: packet.application?.identifiedApp || `${packet.ip.protocol}/${packet.transport?.dstPort}`,
        dataSensitivity:
          dstZone === NetworkZone.VAULT
            ? 'SOVEREIGN_VAULT'
            : dstZone === NetworkZone.FINANCE
            ? 'RESTRICTED'
            : dstZone === NetworkZone.CORPORATE
            ? 'CONFIDENTIAL'
            : 'PUBLIC',
      },
      where: {
        srcIp: nat.newSrcIp || packet.ip.srcIp,
        dstIp: nat.newDstIp || packet.ip.dstIp,
        srcInterface: srcInterfaceId,
        dstInterface: route?.interfaceId || 'if_wan0',
        srcZone,
        dstZone,
        vlan: packet.ethernet.vlanId,
        geoSource: srcZone === NetworkZone.PUBLIC ? 'United Kingdom (London Gateway)' : 'Internal Intranet',
        geoDestination: dstZone === NetworkZone.PUBLIC ? 'United States (SWIFT Backbone)' : 'Sovereign Secure DC',
      },
      when: {
        timestamp: now,
        dayOfWeek: days[dateObj.getDay()],
        businessHours: isBizHours,
      },
      how: {
        tlsVersion: (packet.application?.metadata?.tlsVersion as string) || undefined,
        sni: packet.application?.sni,
        deviceTrust: simulatedUser?.deviceTrust || 'UNTRUSTED',
        deviceId: simulatedUser?.deviceId,
      },
      why: {
        intent:
          dstZone === NetworkZone.VAULT
            ? 'Access HSM Cryptographic Master Signing Engine'
            : dstZone === NetworkZone.FINANCE
            ? 'Execute SWIFT ISO20022 Inter-bank Wire Settlement'
            : dstZone === NetworkZone.DATABASE
            ? 'Query Primary PostgreSQL Customer Ledger Cluster'
            : dstZone === NetworkZone.DMZ
            ? 'Public HTTPS Inbound Web Request'
            : 'Standard Enterprise Network Communication',
        justificationRequired: dstZone === NetworkZone.VAULT || dstZone === NetworkZone.FINANCE,
      },
      risk,
      state: {
        connectionState: conntrackEntry.state,
        packetsInFlow: conntrackEntry.packetsOut + conntrackEntry.packetsIn,
        bytesInFlow: conntrackEntry.bytesOut + conntrackEntry.bytesIn,
        baselineAnomaly: anomalyLevel,
      },
      policy: {
        matchedRuleId: policyResult.matchedRule?.id || 'IMPLICIT_DEFAULT_DENY',
        matchedRuleName: policyResult.matchedRule?.name || 'EXPLICIT_DEFAULT_DENY_LOG',
        ruleAction: policyResult.matchedRule?.action || RuleAction.DENY,
        decision: finalDecision,
        explanation,
      },
    };

    // Store in historical traffic inspector
    this.trafficHistory.unshift(context);
    if (this.trafficHistory.length > 300) {
      this.trafficHistory.pop();
    }

    return { packet, context, conntrackEntry };
  }

  /**
   * Generates a batch of realistic enterprise traffic flows based on active scenario.
   */
  public static generateTickFlows() {
    if (!this.isRunning) return;

    const identities = ZeroTrustEngine.getIdentities();
    const devices = ZeroTrustEngine.getDevices();

    // 1. Scenario-based flow generation
    const samplePacketsToGenerate = this.activeScenario.intensity === 'HEAVY' ? 5 : 2;

    for (let i = 0; i < samplePacketsToGenerate; i++) {
      let srcIp: string;
      let dstIp: string;
      let proto = Protocol.TCP;
      let srcPort = 49152 + Math.floor(Math.random() * 15000);
      let dstPort = 443;
      let flags = [TcpFlag.SYN, TcpFlag.ACK];
      let user = identities[0];
      let dev = devices[0];
      let payload = 'DUKE_SATOSHI_SECURE_PAYLOAD';

      const randType = Math.random();

      if (this.activeScenario.attackType === 'PORT_SCAN') {
        // Port scan attack from external IP
        srcIp = '203.0.113.88';
        dstIp = '10.20.1.10';
        dstPort = Math.floor(Math.random() * 1024) + 1;
        flags = [TcpFlag.SYN];
        user = undefined as any;
        dev = undefined as any;
      } else if (this.activeScenario.attackType === 'SYN_FLOOD') {
        // SYN flood from botnet IP
        srcIp = '198.51.100.42';
        dstIp = '10.20.1.10';
        dstPort = 443;
        flags = [TcpFlag.SYN];
        user = undefined as any;
        dev = undefined as any;
      } else if (this.activeScenario.attackType === 'DNS_TUNNEL') {
        // DNS Tunneling
        srcIp = '10.10.45.12';
        dstIp = '10.20.1.53';
        proto = Protocol.UDP;
        dstPort = 53;
        user = identities[1];
        dev = devices[2];
        const randomHex = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
        DnsSecurityEngine.processQuery(`${randomHex}.exfil.darknet-relay.org`, srcIp, NetworkZone.CORPORATE, 'TXT');
      } else if (this.activeScenario.attackType === 'VAULT_EXFILTRATION') {
        // Guest attempting unauthorized Vault access
        srcIp = '172.16.5.99';
        dstIp = '10.99.1.10';
        dstPort = 8200;
        user = undefined as any;
        dev = undefined as any;
      } else {
        // Normal benign flows
        if (randType < 0.25) {
          // Public to DMZ HTTPS
          srcIp = `198.51.100.${Math.floor(Math.random() * 200) + 10}`;
          dstIp = '10.20.1.10';
          dstPort = 443;
          user = undefined as any;
          dev = undefined as any;
        } else if (randType < 0.5) {
          // Prod to Database PostgreSQL
          srcIp = `10.50.2.${Math.floor(Math.random() * 10) + 1}`;
          dstIp = '10.50.10.5';
          dstPort = 5432;
          user = identities[1];
          dev = devices[2];
          payload = 'SELECT * FROM accounts WHERE balance > 10000000;';
        } else if (randType < 0.75) {
          // Finance to SWIFT Wire
          srcIp = '10.30.1.5';
          dstIp = '198.51.100.50';
          dstPort = 9443;
          user = identities[2];
          dev = devices[3];
          payload = 'FIN_MESSAGE: MT103 SINGLE_CUSTOMER_CREDIT_TRANSFER $50,000,000.00';
        } else {
          // Sovereign Admin to Vault HSM
          srcIp = '10.30.1.5';
          dstIp = '10.99.1.10';
          dstPort = 8200;
          user = identities[0];
          dev = devices[0];
          payload = 'VAULT_RPC: HSM_SIGN_TRANSACTION_PAYLOAD';
        }
      }

      // Build real binary packet
      const rawPacketBytes = PacketEngine.buildPacket({
        srcIp,
        dstIp,
        protocol: proto,
        srcPort,
        dstPort,
        flags,
        payload,
      });

      this.processSinglePacket(rawPacketBytes, 'if_wan0', user ? {
        userId: user.id,
        userName: user.username,
        roles: user.roles,
        mfaVerified: user.mfaEnrolled,
        deviceTrust: dev?.trustLevel || 'UNTRUSTED',
        deviceId: dev?.deviceId,
      } : undefined);
    }
  }

  public static getTelemetrySnapshot(): TelemetrySnapshot {
    const conns = ConnectionTrackingEngine.getAllConnections();
    const events = IdsEngine.getEvents();
    const blockedHosts = IpsEngine.getBlockedHosts();

    const packetsPerSec = Math.floor(450 + Math.random() * 80);
    const bytesPerSec = Math.floor(packetsPerSec * 1280);
    const connectionsPerSec = Math.floor(18 + Math.random() * 12);

    return {
      timestamp: Date.now(),
      packetsPerSec,
      bytesPerSec,
      connectionsPerSec,
      activeConnections: conns.length,
      droppedPackets: this.dropCountTotal,
      allowedFlows: conns.filter((c) => c.decision === DecisionResult.ALLOW).length,
      blockedFlows: this.dropCountTotal,
      idsAlertsCount: events.length,
      ipsMitigationsCount: blockedHosts.length,
      cpuUsagePercent: +(12.5 + Math.random() * 4.2).toFixed(1),
      memoryUsagePercent: +(28.4 + Math.random() * 1.5).toFixed(1),
      avgLatencyUs: Math.floor(12 + Math.random() * 6),
    };
  }

  public static getTrafficHistory(): DecisionContext[] {
    return [...this.trafficHistory];
  }

  public static getActiveScenario(): TrafficScenario {
    return this.activeScenario;
  }

  public static setScenario(scen: TrafficScenario) {
    this.activeScenario = scen;
  }

  public static toggleRunning(running: boolean) {
    this.isRunning = running;
  }

  public static isPipelineRunning(): boolean {
    return this.isRunning;
  }

  public static clearHistory() {
    this.trafficHistory = [];
  }
}
