/**
 * @file routingEngine.ts
 * Duke Satoshi of Cyberspace PLC - Routing & Interface Management Engine
 * Longest Prefix Match (LPM), Policy-Based Routing (PBR), and 802.1Q VLAN interface binding.
 */

import { RouteEntry, NetworkInterface, NetworkZone, Protocol } from '../../types/firewall';

export class RoutingEngine {
  private static interfaces: NetworkInterface[] = [
    {
      id: 'if_wan0',
      name: 'wan0 (Uplink WAN)',
      macAddress: '00:50:56:A1:00:01',
      ipAddress: '198.51.100.1',
      subnetMask: '255.255.255.0',
      zone: NetworkZone.PUBLIC,
      status: 'UP',
      rxPackets: 284019,
      txPackets: 194012,
      rxBytes: 421094000,
      txBytes: 289410000,
      dropPackets: 412,
    },
    {
      id: 'if_dmz0',
      name: 'dmz0 (VLAN 20)',
      macAddress: '00:50:56:A1:00:20',
      ipAddress: '10.20.1.1',
      subnetMask: '255.255.255.0',
      zone: NetworkZone.DMZ,
      vlanId: 20,
      status: 'UP',
      rxPackets: 89401,
      txPackets: 91402,
      rxBytes: 110490000,
      txBytes: 124900000,
      dropPackets: 12,
    },
    {
      id: 'if_corp0',
      name: 'corp0 (VLAN 10)',
      macAddress: '00:50:56:A1:00:10',
      ipAddress: '10.10.1.1',
      subnetMask: '255.255.0.0',
      zone: NetworkZone.CORPORATE,
      vlanId: 10,
      status: 'UP',
      rxPackets: 412090,
      txPackets: 389010,
      rxBytes: 580190000,
      txBytes: 490120000,
      dropPackets: 8,
    },
    {
      id: 'if_fin0',
      name: 'fin0 (VLAN 30)',
      macAddress: '00:50:56:A1:00:30',
      ipAddress: '10.30.1.1',
      subnetMask: '255.255.255.0',
      zone: NetworkZone.FINANCE,
      vlanId: 30,
      status: 'UP',
      rxPackets: 39401,
      txPackets: 38102,
      rxBytes: 48900000,
      txBytes: 47200000,
      dropPackets: 0,
    },
    {
      id: 'if_vault0',
      name: 'vault0 (Isolated HSM Link)',
      macAddress: '00:50:56:A1:00:99',
      ipAddress: '10.99.1.1',
      subnetMask: '255.255.255.248',
      zone: NetworkZone.VAULT,
      vlanId: 99,
      status: 'UP',
      rxPackets: 4102,
      txPackets: 4098,
      rxBytes: 5200000,
      txBytes: 5180000,
      dropPackets: 0,
    },
    {
      id: 'if_mgmt0',
      name: 'mgmt0 (Out-of-Band Admin)',
      macAddress: '00:50:56:A1:00:00',
      ipAddress: '10.0.0.1',
      subnetMask: '255.255.255.0',
      zone: NetworkZone.MANAGEMENT,
      status: 'UP',
      rxPackets: 1840,
      txPackets: 1720,
      rxBytes: 1900000,
      txBytes: 1800000,
      dropPackets: 0,
    },
  ];

  private static routes: RouteEntry[] = [
    {
      id: 'rt_def',
      destinationCidr: '0.0.0.0/0',
      gatewayIp: '198.51.100.254',
      interfaceId: 'if_wan0',
      metric: 10,
    },
    {
      id: 'rt_corp',
      destinationCidr: '10.10.0.0/16',
      gatewayIp: '0.0.0.0',
      interfaceId: 'if_corp0',
      metric: 0,
    },
    {
      id: 'rt_dmz',
      destinationCidr: '10.20.1.0/24',
      gatewayIp: '0.0.0.0',
      interfaceId: 'if_dmz0',
      metric: 0,
    },
    {
      id: 'rt_fin',
      destinationCidr: '10.30.1.0/24',
      gatewayIp: '0.0.0.0',
      interfaceId: 'if_fin0',
      metric: 0,
    },
    {
      id: 'rt_vault',
      destinationCidr: '10.99.1.0/29',
      gatewayIp: '0.0.0.0',
      interfaceId: 'if_vault0',
      metric: 0,
    },
    {
      id: 'rt_pbr_swift',
      destinationCidr: '198.51.100.50/32',
      gatewayIp: '198.51.100.250',
      interfaceId: 'if_wan0',
      metric: 5,
      isPolicyRoute: true,
      protocolFilter: Protocol.TCP,
      zone: NetworkZone.FINANCE,
    },
  ];

  public static getInterfaces(): NetworkInterface[] {
    return [...this.interfaces];
  }

  public static getRoutes(): RouteEntry[] {
    return [...this.routes];
  }

  public static addRoute(route: RouteEntry) {
    this.routes.push(route);
  }

  public static deleteRoute(id: string): boolean {
    const len = this.routes.length;
    this.routes = this.routes.filter((r) => r.id !== id);
    return this.routes.length !== len;
  }

  /**
   * Performs Longest Prefix Match (LPM) routing decision.
   */
  public static lookupRoute(dstIp: string, protocol?: Protocol, srcZone?: NetworkZone): RouteEntry | null {
    let bestMatch: RouteEntry | null = null;
    let bestPrefixLen = -1;

    for (const route of this.routes) {
      if (route.isPolicyRoute) {
        if (route.protocolFilter && route.protocolFilter !== protocol) continue;
        if (route.zone && route.zone !== srcZone) continue;
      }

      const [cidrIp, prefixStr] = route.destinationCidr.split('/');
      const prefix = parseInt(prefixStr, 10);

      if (this.matchCidr(dstIp, cidrIp, prefix)) {
        if (prefix > bestPrefixLen) {
          bestPrefixLen = prefix;
          bestMatch = route;
        }
      }
    }

    return bestMatch;
  }

  public static getZoneForIp(ip: string): NetworkZone {
    if (ip.startsWith('10.99.')) return NetworkZone.VAULT;
    if (ip.startsWith('10.30.')) return NetworkZone.FINANCE;
    if (ip.startsWith('10.20.')) return NetworkZone.DMZ;
    if (ip.startsWith('10.10.')) return NetworkZone.CORPORATE;
    if (ip.startsWith('10.40.')) return NetworkZone.DEVELOPMENT;
    if (ip.startsWith('10.50.')) return NetworkZone.PRODUCTION;
    if (ip.startsWith('10.0.')) return NetworkZone.MANAGEMENT;
    if (ip.startsWith('172.16.')) return NetworkZone.GUEST;
    if (ip.startsWith('192.168.99.')) return NetworkZone.QUARANTINE;
    return NetworkZone.PUBLIC;
  }

  private static matchCidr(ip: string, subnet: string, prefix: number): boolean {
    if (prefix === 0) return true;
    const ipNum = this.ipToNumber(ip);
    const subnetNum = this.ipToNumber(subnet);
    if (ipNum === null || subnetNum === null) return false;
    const mask = (~0 << (32 - prefix)) >>> 0;
    return (ipNum & mask) === (subnetNum & mask);
  }

  private static ipToNumber(ip: string): number | null {
    const parts = ip.split('.').map(Number);
    if (parts.length !== 4) return null;
    return (((parts[0] << 24) >>> 0) + (parts[1] << 16) + (parts[2] << 8) + parts[3]) >>> 0;
  }
}
