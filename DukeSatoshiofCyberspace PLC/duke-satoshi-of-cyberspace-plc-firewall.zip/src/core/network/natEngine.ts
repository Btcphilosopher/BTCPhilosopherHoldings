/**
 * @file natEngine.ts
 * Duke Satoshi of Cyberspace PLC - State-Consistent Network Address Translation (NAT)
 * High-performance SNAT, DNAT, Port Forwarding, and Dynamic Masquerading.
 */

import { NatRule, NetworkZone, Protocol, ParsedPacket } from '../../types/firewall';

export class NatEngine {
  private static rules: NatRule[] = [
    {
      id: 'nat_001',
      name: 'Corporate Egress Internet Masquerade (SNAT)',
      type: 'SNAT',
      srcZone: NetworkZone.CORPORATE,
      dstZone: NetworkZone.PUBLIC,
      originalSrc: '10.10.0.0/16',
      translatedSrc: '198.51.100.10',
      enabled: true,
      hits: 1420,
    },
    {
      id: 'nat_002',
      name: 'Public HTTPS Ingress to DMZ Reverse Proxy (DNAT)',
      type: 'DNAT',
      srcZone: NetworkZone.PUBLIC,
      dstZone: NetworkZone.DMZ,
      originalDst: '198.51.100.25',
      originalPort: 443,
      translatedDst: '10.20.1.10',
      translatedPort: 8443,
      enabled: true,
      hits: 8930,
    },
    {
      id: 'nat_003',
      name: 'SWIFT Gateway Inter-Bank Port Translation',
      type: 'PORT_FORWARD',
      srcZone: NetworkZone.FINANCE,
      dstZone: NetworkZone.PUBLIC,
      originalDst: '198.51.100.50',
      originalPort: 9443,
      translatedDst: '10.30.5.2',
      translatedPort: 9443,
      enabled: true,
      hits: 310,
    },
  ];

  public static getRules(): NatRule[] {
    return [...this.rules];
  }

  public static addRule(rule: NatRule) {
    this.rules.push(rule);
  }

  public static deleteRule(id: string): boolean {
    const len = this.rules.length;
    this.rules = this.rules.filter((r) => r.id !== id);
    return this.rules.length !== len;
  }

  /**
   * Translates an incoming packet if a NAT rule matches.
   */
  public static processNat(
    packet: ParsedPacket,
    srcZone: NetworkZone,
    dstZone: NetworkZone
  ): { translated: boolean; newSrcIp?: string; newDstIp?: string; newDstPort?: number; ruleApplied?: string } {
    const srcIp = packet.ip.srcIp;
    const dstIp = packet.ip.dstIp;
    const dstPort = packet.transport?.dstPort;

    for (const rule of this.rules) {
      if (!rule.enabled) continue;
      if (rule.srcZone !== srcZone || rule.dstZone !== dstZone) continue;

      if (rule.type === 'SNAT' || rule.type === 'MASQUERADE') {
        rule.hits += 1;
        return {
          translated: true,
          newSrcIp: rule.translatedSrc,
          ruleApplied: rule.name,
        };
      }

      if (rule.type === 'DNAT' || rule.type === 'PORT_FORWARD') {
        if (rule.originalDst && rule.originalDst !== dstIp) continue;
        if (rule.originalPort && rule.originalPort !== dstPort) continue;

        rule.hits += 1;
        return {
          translated: true,
          newDstIp: rule.translatedDst,
          newDstPort: rule.translatedPort,
          ruleApplied: rule.name,
        };
      }
    }

    return { translated: false };
  }
}
