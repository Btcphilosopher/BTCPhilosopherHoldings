/**
 * @file conntrack.ts
 * Duke Satoshi of Cyberspace PLC - Stateful Connection Tracking Engine
 * RFC-compliant TCP state machine, bidirectional flow tracking, and NAT state management.
 */

import {
  Protocol,
  ConnectionState,
  TcpFlag,
  ConnectionTrackEntry,
  NetworkZone,
  DecisionResult,
  ParsedPacket,
} from '../../types/firewall';

export class ConnectionTrackingEngine {
  private static connections: Map<string, ConnectionTrackEntry> = new Map();
  private static readonly TIMEOUTS = {
    TCP_SYN_SENT: 60,
    TCP_SYN_RECV: 60,
    TCP_ESTABLISHED: 86400,
    TCP_FIN_WAIT: 120,
    TCP_TIME_WAIT: 120,
    TCP_CLOSED: 10,
    UDP_GENERIC: 30,
    UDP_STREAM: 180,
    ICMP: 10,
    GENERIC: 600,
  };

  /**
   * Generates a canonical directional connection key.
   */
  public static makeKey(srcIp: string, srcPort: number, dstIp: string, dstPort: number, protocol: Protocol): string {
    return `${srcIp}:${srcPort}->${dstIp}:${dstPort}:${protocol}`;
  }

  public static makeReverseKey(srcIp: string, srcPort: number, dstIp: string, dstPort: number, protocol: Protocol): string {
    return `${dstIp}:${dstPort}->${srcIp}:${srcPort}:${protocol}`;
  }

  /**
   * Looks up or tracks an incoming packet through the state machine.
   */
  public static processPacket(
    packet: ParsedPacket,
    srcZone: NetworkZone,
    dstZone: NetworkZone,
    initialDecision: DecisionResult = DecisionResult.ALLOW,
    ruleId?: string
  ): { entry: ConnectionTrackEntry; stateTransition: string; isNewFlow: boolean } {
    const srcIp = packet.ip.srcIp;
    const dstIp = packet.ip.dstIp;
    const protocol = packet.ip.protocol;
    const srcPort = packet.transport?.srcPort || 0;
    const dstPort = packet.transport?.dstPort || 0;
    const flags = packet.transport?.flags || [];
    const now = Date.now();
    const packetBytes = packet.ip.totalLength || 64;

    const fwdKey = this.makeKey(srcIp, srcPort, dstIp, dstPort, protocol);
    const revKey = this.makeReverseKey(srcIp, srcPort, dstIp, dstPort, protocol);

    let isOutbound = true;
    let entry = this.connections.get(fwdKey);

    if (!entry) {
      entry = this.connections.get(revKey);
      if (entry) {
        isOutbound = false;
      }
    }

    let stateTransition = 'UNCHANGED';
    let isNewFlow = false;

    if (!entry) {
      // New Connection Attempt
      isNewFlow = true;
      let conState = ConnectionState.NEW;
      let tcpState = 'INIT';
      let timeout = this.TIMEOUTS.GENERIC;

      if (protocol === Protocol.TCP) {
        if (flags.includes(TcpFlag.SYN) && !flags.includes(TcpFlag.ACK)) {
          tcpState = 'SYN_SENT';
          timeout = this.TIMEOUTS.TCP_SYN_SENT;
          conState = ConnectionState.NEW;
          stateTransition = 'INIT -> SYN_SENT [NEW]';
        } else if (flags.includes(TcpFlag.RST)) {
          conState = ConnectionState.INVALID;
          tcpState = 'CLOSED';
          stateTransition = 'UNSOLICITED_RST [INVALID]';
        } else {
          // Out of order or unsolicited packet
          conState = ConnectionState.INVALID;
          tcpState = 'OUT_OF_WINDOW';
          stateTransition = 'NO_PRIOR_SYN [INVALID]';
        }
      } else if (protocol === Protocol.UDP) {
        conState = ConnectionState.NEW;
        tcpState = 'UDP_UNREPLIED';
        timeout = this.TIMEOUTS.UDP_GENERIC;
        stateTransition = 'NEW_UDP_FLOW';
      } else if (protocol === Protocol.ICMP) {
        conState = ConnectionState.NEW;
        timeout = this.TIMEOUTS.ICMP;
        stateTransition = 'NEW_ICMP_ECHO';
      }

      const id = `ct_${now}_${Math.random().toString(36).substring(2, 7)}`;
      entry = {
        id,
        key: fwdKey,
        protocol,
        srcIp,
        srcPort,
        dstIp,
        dstPort,
        srcZone,
        dstZone,
        state: conState,
        tcpState,
        startTime: now,
        lastSeenTime: now,
        packetsOut: 1,
        packetsIn: 0,
        bytesOut: packetBytes,
        bytesIn: 0,
        timeoutSeconds: timeout,
        associatedRuleId: ruleId,
        application: packet.application?.identifiedApp || `${protocol}/${dstPort}`,
        riskScore: 0,
        decision: initialDecision,
      };

      this.connections.set(fwdKey, entry);
    } else {
      // Existing Connection State Machine Evolution
      entry.lastSeenTime = now;

      if (isOutbound) {
        entry.packetsOut += 1;
        entry.bytesOut += packetBytes;
      } else {
        entry.packetsIn += 1;
        entry.bytesIn += packetBytes;
      }

      if (protocol === Protocol.TCP) {
        const prevTcp = entry.tcpState;

        if (flags.includes(TcpFlag.RST)) {
          entry.state = ConnectionState.CLOSED;
          entry.tcpState = 'CLOSED';
          entry.timeoutSeconds = this.TIMEOUTS.TCP_CLOSED;
          stateTransition = `${prevTcp} -> CLOSED (RST)`;
        } else if (flags.includes(TcpFlag.FIN)) {
          entry.state = ConnectionState.CLOSING;
          entry.tcpState = 'FIN_WAIT';
          entry.timeoutSeconds = this.TIMEOUTS.TCP_FIN_WAIT;
          stateTransition = `${prevTcp} -> FIN_WAIT [CLOSING]`;
        } else if (flags.includes(TcpFlag.SYN) && flags.includes(TcpFlag.ACK)) {
          entry.tcpState = 'SYN_RECV';
          entry.state = ConnectionState.ESTABLISHED;
          entry.timeoutSeconds = this.TIMEOUTS.TCP_ESTABLISHED;
          stateTransition = `${prevTcp} -> SYN_RECV -> ESTABLISHED`;
        } else if (flags.includes(TcpFlag.ACK) && entry.tcpState === 'SYN_RECV') {
          entry.tcpState = 'ESTABLISHED';
          entry.state = ConnectionState.ESTABLISHED;
          entry.timeoutSeconds = this.TIMEOUTS.TCP_ESTABLISHED;
          stateTransition = `${prevTcp} -> ESTABLISHED`;
        } else if (entry.state === ConnectionState.NEW && !isOutbound) {
          entry.state = ConnectionState.ESTABLISHED;
          entry.tcpState = 'ESTABLISHED';
          stateTransition = `${prevTcp} -> ESTABLISHED`;
        }
      } else if (protocol === Protocol.UDP) {
        if (!isOutbound && entry.state === ConnectionState.NEW) {
          entry.state = ConnectionState.ESTABLISHED;
          entry.tcpState = 'UDP_REPLIED';
          entry.timeoutSeconds = this.TIMEOUTS.UDP_STREAM;
          stateTransition = 'UDP_REPLY_SEEN -> ESTABLISHED';
        }
      }
    }

    return { entry, stateTransition, isNewFlow };
  }

  /**
   * Retrieves all active connection tracking entries.
   */
  public static getAllConnections(): ConnectionTrackEntry[] {
    return Array.from(this.connections.values());
  }

  /**
   * Manually terminates or clears an entry (e.g., administrator action).
   */
  public static terminateConnection(id: string): boolean {
    for (const [key, entry] of this.connections.entries()) {
      if (entry.id === id) {
        entry.state = ConnectionState.CLOSED;
        entry.tcpState = 'ADMIN_KILLED';
        this.connections.delete(key);
        return true;
      }
    }
    return false;
  }

  /**
   * Purges expired entries according to their timeout thresholds.
   */
  public static cleanupExpired(now: number = Date.now()): number {
    let expiredCount = 0;
    for (const [key, entry] of this.connections.entries()) {
      const ageSeconds = (now - entry.lastSeenTime) / 1000;
      if (ageSeconds > entry.timeoutSeconds) {
        this.connections.delete(key);
        expiredCount++;
      }
    }
    return expiredCount;
  }

  public static getStats() {
    let total = 0;
    let established = 0;
    let newFlows = 0;
    let closing = 0;
    let invalid = 0;

    for (const entry of this.connections.values()) {
      total++;
      if (entry.state === ConnectionState.ESTABLISHED) established++;
      else if (entry.state === ConnectionState.NEW) newFlows++;
      else if (entry.state === ConnectionState.CLOSING) closing++;
      else if (entry.state === ConnectionState.INVALID) invalid++;
    }

    return { total, established, newFlows, closing, invalid };
  }
}
