/**
 * @file clusterManager.ts
 * Duke Satoshi of Cyberspace PLC - High Availability & State Replication Subsystem
 * Active/Passive state synchronisation, heartbeat monitoring, and configuration divergence detection.
 */

import { ClusterNode } from '../../types/firewall';

export class ClusterManager {
  private static nodes: ClusterNode[] = [
    {
      id: 'node-alpha-lon',
      name: 'FW-01 [London Primary Sovereign Core]',
      role: 'PRIMARY',
      status: 'ONLINE',
      ipAddress: '10.0.0.101',
      version: 'v4.8.2-enterprise',
      configHash: 'sha256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
      policyVersion: 42,
      connectionCount: 3840,
      cpuPercent: 18.4,
      memoryPercent: 32.1,
      networkThroughputMbps: 842.5,
      syncLatencyMs: 0.42,
      lastHeartbeat: Date.now(),
    },
    {
      id: 'node-beta-lon',
      name: 'FW-02 [London Hot Standby Secondary]',
      role: 'SECONDARY',
      status: 'STANDBY',
      ipAddress: '10.0.0.102',
      version: 'v4.8.2-enterprise',
      configHash: 'sha256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
      policyVersion: 42,
      connectionCount: 3840, // fully synchronized conntrack
      cpuPercent: 8.2,
      memoryPercent: 31.8,
      networkThroughputMbps: 0.0,
      syncLatencyMs: 0.45,
      lastHeartbeat: Date.now(),
    },
    {
      id: 'node-witness-zrh',
      name: 'FW-WITNESS [Zurich Quorum Arbitrator]',
      role: 'WITNESS',
      status: 'ONLINE',
      ipAddress: '10.0.0.103',
      version: 'v4.8.2-enterprise',
      configHash: 'sha256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
      policyVersion: 42,
      connectionCount: 0,
      cpuPercent: 2.1,
      memoryPercent: 12.0,
      networkThroughputMbps: 1.2,
      syncLatencyMs: 8.1,
      lastHeartbeat: Date.now(),
    },
  ];

  public static getNodes(): ClusterNode[] {
    // Update heartbeats with simulated jitter
    const now = Date.now();
    this.nodes.forEach((n) => {
      n.lastHeartbeat = now;
      if (n.role === 'PRIMARY') {
        n.cpuPercent = +(15 + Math.random() * 8).toFixed(1);
        n.networkThroughputMbps = +(800 + Math.random() * 100).toFixed(1);
      }
    });
    return [...this.nodes];
  }

  /**
   * Simulates graceful or forced failover between Primary and Secondary nodes.
   */
  public static triggerFailover(): { success: boolean; message: string } {
    const primary = this.nodes.find((n) => n.role === 'PRIMARY');
    const secondary = this.nodes.find((n) => n.role === 'SECONDARY');

    if (!primary || !secondary) {
      return { success: false, message: 'Cluster nodes not found' };
    }

    if (primary.configHash !== secondary.configHash) {
      return {
        success: false,
        message: 'FAILOVER ABORTED: Configuration hash divergence detected between nodes!',
      };
    }

    primary.role = 'SECONDARY';
    primary.status = 'STANDBY';
    secondary.role = 'PRIMARY';
    secondary.status = 'ONLINE';

    return {
      success: true,
      message: `Stateful failover completed in 1.8ms. Active control handed over to ${secondary.name}`,
    };
  }

  public static checkDivergence(): { diverged: boolean; details?: string } {
    const hashes = new Set(this.nodes.map((n) => n.configHash));
    if (hashes.size > 1) {
      return {
        diverged: true,
        details: 'Configuration hashes differ across cluster members. Policy sync required!',
      };
    }
    return { diverged: false };
  }
}
