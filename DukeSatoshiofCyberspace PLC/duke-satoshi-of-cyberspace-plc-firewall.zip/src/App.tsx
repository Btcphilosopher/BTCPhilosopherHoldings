/**
 * @file App.tsx
 * Duke Satoshi of Cyberspace PLC - Sovereign Cybersecurity & Programmable Firewall Platform
 * Institutional Enterprise Security Architecture
 */

import React, { useState, useEffect } from 'react';
import { bootstrapFirewall } from './core/firewallInit';
import { Header } from './components/Header';
import { Navigation, NavTabId } from './components/Navigation';
import { OverviewView } from './components/views/OverviewView';
import { TrafficInspectorView } from './components/views/TrafficInspectorView';
import { DigitalTwinView } from './components/views/DigitalTwinView';
import { PoliciesView } from './components/views/PoliciesView';
import { PolicySimulatorView } from './components/views/PolicySimulatorView';
import { PolicyGraphView } from './components/views/PolicyGraphView';
import { SecurityIdsView } from './components/views/SecurityIdsView';
import { ThreatIntelView } from './components/views/ThreatIntelView';
import { ZeroTrustView } from './components/views/ZeroTrustView';
import { DnsSecurityView } from './components/views/DnsSecurityView';
import { NatRoutingView } from './components/views/NatRoutingView';
import { HighAvailabilityView } from './components/views/HighAvailabilityView';
import { EventGraphView } from './components/views/EventGraphView';
import { PolicyTestingView } from './components/views/PolicyTestingView';
import { AuditTelemetryView } from './components/views/AuditTelemetryView';
import { CliTerminalView } from './components/views/CliTerminalView';
import { PacketCraftModal } from './components/views/PacketCraftModal';

import { PipelineOrchestrator, TrafficScenario } from './core/telemetry/syntheticTraffic';
import { ConnectionTrackingEngine } from './core/state/conntrack';
import { IdsEngine } from './core/security/idsEngine';
import { IpsEngine } from './core/security/ipsEngine';
import { ConfigManager } from './core/config/configManager';
import { DecisionContext, TelemetrySnapshot, ConnectionTrackEntry } from './types/firewall';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTabId>('overview');
  const [scenario, setScenario] = useState<TrafficScenario>(PipelineOrchestrator.getActiveScenario());
  const [telemetry, setTelemetry] = useState<TelemetrySnapshot>(PipelineOrchestrator.getTelemetrySnapshot());
  const [trafficHistory, setTrafficHistory] = useState<DecisionContext[]>([]);
  const [activeConnections, setActiveConnections] = useState<ConnectionTrackEntry[]>([]);
  const [selectedFlow, setSelectedFlow] = useState<DecisionContext | null>(null);
  const [isPacketCraftOpen, setIsPacketCraftOpen] = useState(false);
  const [alertCount, setAlertCount] = useState(0);
  const [quarantineCount, setQuarantineCount] = useState(0);
  const [rollbackStatus, setRollbackStatus] = useState({ active: false, secondsRemaining: 0 });

  // 1. Initial Bootstrap on Mount
  useEffect(() => {
    bootstrapFirewall();
    // Pre-generate initial sample tick flows
    PipelineOrchestrator.generateTickFlows();
    setTrafficHistory(PipelineOrchestrator.getTrafficHistory());
    setActiveConnections(ConnectionTrackingEngine.getAllConnections());
  }, []);

  // 2. Real-time Pipeline Tick Interval
  useEffect(() => {
    const interval = setInterval(() => {
      PipelineOrchestrator.generateTickFlows();
      setTelemetry(PipelineOrchestrator.getTelemetrySnapshot());
      setTrafficHistory(PipelineOrchestrator.getTrafficHistory());
      setActiveConnections(ConnectionTrackingEngine.getAllConnections());
      setAlertCount(IdsEngine.getEvents().length);
      setQuarantineCount(IpsEngine.getBlockedHosts().length);
      setRollbackStatus(ConfigManager.getRollbackStatus());
    }, 1500);

    return () => clearInterval(interval);
  }, []);

  const handleSelectScenario = (scen: TrafficScenario) => {
    PipelineOrchestrator.setScenario(scen);
    setScenario(scen);
  };

  const handleConfirmCommit = () => {
    ConfigManager.confirmCommit();
    setRollbackStatus({ active: false, secondsRemaining: 0 });
  };

  const handleRollbackNow = () => {
    ConfigManager.triggerAutoRollback('Manual rollback invoked by administrator');
    setRollbackStatus({ active: false, secondsRemaining: 0 });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-black">
      {/* Top Sovereign Header */}
      <Header
        onOpenCli={() => setActiveTab('cli')}
        onOpenPacketCraft={() => setIsPacketCraftOpen(true)}
        scenario={scenario}
        onSelectScenario={handleSelectScenario}
        rollbackStatus={rollbackStatus}
        onConfirmCommit={handleConfirmCommit}
        onRollbackNow={handleRollbackNow}
      />

      {/* Institutional Navigation Tab Bar */}
      <Navigation
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        alertCount={alertCount}
        quarantineCount={quarantineCount}
      />

      {/* Main Operational View Container */}
      <main className="flex-1 p-4 lg:p-6 max-w-[1700px] w-full mx-auto">
        {activeTab === 'overview' && (
          <OverviewView
            telemetry={telemetry}
            recentTraffic={trafficHistory}
            activeConnections={activeConnections}
            onSelectFlow={(flow) => {
              setSelectedFlow(flow);
              setActiveTab('traffic');
            }}
            onNavigateTo={(tab) => setActiveTab(tab)}
          />
        )}

        {activeTab === 'traffic' && (
          <TrafficInspectorView
            traffic={trafficHistory}
            selectedFlow={selectedFlow}
            onSelectFlow={setSelectedFlow}
          />
        )}

        {activeTab === 'digital-twin' && (
          <DigitalTwinView recentTraffic={trafficHistory} />
        )}

        {activeTab === 'policies' && (
          <PoliciesView onCommitTriggered={() => setRollbackStatus(ConfigManager.getRollbackStatus())} />
        )}

        {activeTab === 'simulator' && <PolicySimulatorView />}

        {activeTab === 'policy-graph' && <PolicyGraphView />}

        {activeTab === 'security' && <SecurityIdsView />}

        {activeTab === 'threats' && <ThreatIntelView />}

        {activeTab === 'identities' && <ZeroTrustView />}

        {activeTab === 'dns' && <DnsSecurityView />}

        {activeTab === 'nat-routing' && <NatRoutingView />}

        {activeTab === 'ha-cluster' && <HighAvailabilityView />}

        {activeTab === 'event-graph' && <EventGraphView />}

        {activeTab === 'testing' && <PolicyTestingView />}

        {activeTab === 'audit' && <AuditTelemetryView />}

        {activeTab === 'cli' && <CliTerminalView />}
      </main>

      {/* Live Raw Packet Crafter & Injector Modal */}
      <PacketCraftModal
        isOpen={isPacketCraftOpen}
        onClose={() => setIsPacketCraftOpen(false)}
        onPacketInjected={(context) => {
          setSelectedFlow(context);
          setActiveTab('traffic');
        }}
      />

      {/* Institutional Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 px-6 py-3 text-center text-xs text-slate-500 font-mono flex items-center justify-between">
        <div>
          Duke Satoshi of Cyberspace PLC • High-Assurance Sovereign Firewall Architecture
        </div>
        <div className="flex items-center gap-4 text-[11px] text-slate-400">
          <span>Quorum: 3/3 Synchronized</span>
          <span>•</span>
          <span>Zero-Trust: Enforced</span>
          <span>•</span>
          <span className="text-emerald-400 font-bold">SHA-256 Chained Integrity Verified</span>
        </div>
      </footer>
    </div>
  );
}
