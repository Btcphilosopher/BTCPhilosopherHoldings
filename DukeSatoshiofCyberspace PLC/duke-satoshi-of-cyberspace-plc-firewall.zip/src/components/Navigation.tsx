/**
 * @file Navigation.tsx
 * Duke Satoshi of Cyberspace PLC - Sovereign Navigation Subsystem
 */

import React from 'react';
import {
  LayoutDashboard,
  Activity,
  Network,
  ShieldCheck,
  Cpu,
  GitGraph,
  ShieldAlert,
  Database,
  Users,
  Globe,
  Share2,
  Server,
  Workflow,
  CheckCircle2,
  FileText,
  Terminal,
} from 'lucide-react';

export type NavTabId =
  | 'overview'
  | 'traffic'
  | 'digital-twin'
  | 'policies'
  | 'simulator'
  | 'policy-graph'
  | 'security'
  | 'threats'
  | 'identities'
  | 'dns'
  | 'nat-routing'
  | 'ha-cluster'
  | 'event-graph'
  | 'testing'
  | 'audit'
  | 'cli';

interface NavigationProps {
  activeTab: NavTabId;
  onSelectTab: (tab: NavTabId) => void;
  alertCount: number;
  quarantineCount: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  alertCount,
  quarantineCount,
}) => {
  const navItems: { id: NavTabId; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'overview', label: 'Overview', icon: <LayoutDashboard className="w-3.5 h-3.5" /> },
    { id: 'traffic', label: 'Traffic Inspector', icon: <Activity className="w-3.5 h-3.5" /> },
    { id: 'digital-twin', label: 'Digital Twin', icon: <Network className="w-3.5 h-3.5" /> },
    { id: 'policies', label: 'Policies & Rules', icon: <ShieldCheck className="w-3.5 h-3.5" /> },
    { id: 'simulator', label: 'Policy Simulator', icon: <Cpu className="w-3.5 h-3.5" /> },
    { id: 'policy-graph', label: 'Zones & Graph', icon: <GitGraph className="w-3.5 h-3.5" /> },
    { id: 'security', label: 'IDS / IPS', icon: <ShieldAlert className="w-3.5 h-3.5" />, badge: alertCount + quarantineCount },
    { id: 'threats', label: 'Threat Intel', icon: <Database className="w-3.5 h-3.5" /> },
    { id: 'identities', label: 'Zero-Trust', icon: <Users className="w-3.5 h-3.5" /> },
    { id: 'dns', label: 'DNS Security', icon: <Globe className="w-3.5 h-3.5" /> },
    { id: 'nat-routing', label: 'NAT & Routing', icon: <Share2 className="w-3.5 h-3.5" /> },
    { id: 'ha-cluster', label: 'HA Cluster', icon: <Server className="w-3.5 h-3.5" /> },
    { id: 'event-graph', label: 'Event Graph', icon: <Workflow className="w-3.5 h-3.5" /> },
    { id: 'testing', label: 'Policy Testing', icon: <CheckCircle2 className="w-3.5 h-3.5" /> },
    { id: 'audit', label: 'Audit Logs', icon: <FileText className="w-3.5 h-3.5" /> },
    { id: 'cli', label: 'CLI Terminal', icon: <Terminal className="w-3.5 h-3.5" /> },
  ];

  return (
    <nav className="bg-slate-900/90 border-b border-slate-800 px-4 overflow-x-auto no-scrollbar">
      <div className="flex items-center space-x-1 min-w-max py-1.5">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-mono transition relative ${
                isActive
                  ? 'bg-slate-800 text-cyan-300 font-semibold border-b-2 border-cyan-400 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
              {item.badge !== undefined && item.badge > 0 && (
                <span className="ml-1 px-1.5 py-0.2 text-[10px] bg-red-500/20 text-red-400 border border-red-500/40 rounded-full font-bold">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
