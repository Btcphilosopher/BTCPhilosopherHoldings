/**
 * @file PoliciesView.tsx
 * Duke Satoshi of Cyberspace PLC - Sovereign Policy & Rule Editor
 * Candidate configuration pipeline, validation, confirmed commit timer, and declarative YAML exporter.
 */

import React, { useState } from 'react';
import {
  Shield,
  Plus,
  Trash2,
  Edit2,
  CheckCircle,
  AlertTriangle,
  FileCode,
  Download,
  RotateCcw,
  ArrowUpDown,
  Lock,
} from 'lucide-react';
import { FirewallRule, NetworkZone, Protocol, RuleAction } from '../../types/firewall';
import { ConfigManager } from '../../core/config/configManager';
import { AuditLogger } from '../../core/telemetry/auditLogger';

interface PoliciesViewProps {
  onCommitTriggered: () => void;
}

export const PoliciesView: React.FC<PoliciesViewProps> = ({ onCommitTriggered }) => {
  const [rules, setRules] = useState<FirewallRule[]>(ConfigManager.getCandidateRules());
  const [editingRule, setEditingRule] = useState<FirewallRule | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showYamlModal, setShowYamlModal] = useState(false);
  const [yamlText, setYamlText] = useState('');
  const [validationResult, setValidationResult] = useState<{ valid: boolean; errors: string[]; warnings: string[] } | null>(null);

  const handleToggleRule = (id: string) => {
    const updated = rules.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r));
    setRules(updated);
    ConfigManager.setCandidateRules(updated);
  };

  const handleDeleteRule = (id: string) => {
    const updated = rules.filter((r) => r.id !== id);
    setRules(updated);
    ConfigManager.setCandidateRules(updated);
  };

  const handleValidate = () => {
    const res = ConfigManager.validateConfig(rules);
    setValidationResult(res);
  };

  const handleCommit = () => {
    try {
      ConfigManager.commitWithConfirm(rules, 300, 'lord.satoshi');
      AuditLogger.log({
        actor: 'lord.satoshi',
        action: 'POLICY_COMMITTED',
        resourceType: 'FIREWALL_POLICY_BUNDLE',
        resourceId: `bundle_v_${Date.now()}`,
        status: 'SUCCESS',
        ipAddress: '10.0.0.5',
      });
      onCommitTriggered();
      setValidationResult(null);
    } catch (err: any) {
      alert(`Commit error: ${err.message}`);
    }
  };

  const handleSaveRule = (rule: FirewallRule) => {
    let updated: FirewallRule[];
    if (rules.some((r) => r.id === rule.id)) {
      updated = rules.map((r) => (r.id === rule.id ? rule : r));
    } else {
      updated = [...rules, rule];
    }
    updated.sort((a, b) => a.priority - b.priority);
    setRules(updated);
    ConfigManager.setCandidateRules(updated);
    setShowAddModal(false);
    setEditingRule(null);
  };

  const handleOpenYaml = () => {
    setYamlText(ConfigManager.exportDeclarativeYaml());
    setShowYamlModal(true);
  };

  return (
    <div className="space-y-6">
      {/* Control Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold text-white font-mono flex items-center gap-2">
            <Shield className="w-4 h-4 text-cyan-400" />
            MULTI-DIMENSIONAL FIREWALL POLICIES & ACL INVARIANTS
          </h2>
          <p className="text-xs text-slate-400">
            Rules evaluate top-down by priority. Strict default-deny posture enforced on all unlisted flows.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <button
            onClick={handleValidate}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
          >
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
            Validate Candidate
          </button>

          <button
            onClick={handleOpenYaml}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
          >
            <FileCode className="w-3.5 h-3.5 text-indigo-400" />
            Export YAML
          </button>

          <button
            onClick={() => {
              setEditingRule({
                id: `rule_${Date.now()}`,
                name: 'NEW_ZONE_POLICY_RULE',
                priority: (rules[rules.length - 2]?.priority || 100) + 10,
                enabled: true,
                srcZone: NetworkZone.CORPORATE,
                dstZone: NetworkZone.DMZ,
                srcAddress: '10.10.0.0/16',
                dstAddress: '10.20.1.10/32',
                protocol: Protocol.TCP,
                dstPort: '443',
                application: 'HTTPS',
                action: RuleAction.ALLOW,
                logging: true,
                owner: 'secops-lead',
                createdAt: Date.now(),
                modifiedAt: Date.now(),
                hitCount: 0,
              });
              setShowAddModal(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-semibold transition"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Rule
          </button>

          <button
            onClick={handleCommit}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold transition shadow-md"
          >
            <Lock className="w-3.5 h-3.5" />
            Commit Candidate (300s Confirm)
          </button>
        </div>
      </div>

      {/* Validation Result Banner */}
      {validationResult && (
        <div
          className={`p-3 rounded-lg border text-xs font-mono ${
            validationResult.valid
              ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
              : 'bg-red-950/40 border-red-500/40 text-red-300'
          }`}
        >
          <div className="font-bold flex items-center gap-2 mb-1">
            {validationResult.valid ? <CheckCircle className="w-4 h-4 text-emerald-400" /> : <AlertTriangle className="w-4 h-4 text-red-400" />}
            {validationResult.valid ? 'Candidate Policy Passed Static Invariant Verification' : 'Validation Errors Detected:'}
          </div>
          {validationResult.errors.map((e, i) => (
            <div key={i} className="text-red-400 pl-6">• {e}</div>
          ))}
          {validationResult.warnings.map((w, i) => (
            <div key={i} className="text-amber-400 pl-6">• {w}</div>
          ))}
        </div>
      )}

      {/* Rules Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Pri</th>
                <th className="py-2.5 px-3">State</th>
                <th className="py-2.5 px-3">Rule Name & Details</th>
                <th className="py-2.5 px-3">Source (Zone / IP)</th>
                <th className="py-2.5 px-3">Destination (Zone / IP : Port)</th>
                <th className="py-2.5 px-3">Proto / App</th>
                <th className="py-2.5 px-3">Identity Req</th>
                <th className="py-2.5 px-3">Action</th>
                <th className="py-2.5 px-3">Hits</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {rules.map((rule) => {
                const isAllow = rule.action === RuleAction.ALLOW;
                return (
                  <tr
                    key={rule.id}
                    className={`hover:bg-slate-800/40 transition ${
                      !rule.enabled ? 'opacity-40 bg-slate-950/40' : ''
                    }`}
                  >
                    <td className="py-2.5 px-3 font-bold text-cyan-400">{rule.priority}</td>
                    <td className="py-2.5 px-3">
                      <button
                        onClick={() => handleToggleRule(rule.id)}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          rule.enabled
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                            : 'bg-slate-800 text-slate-500 border border-slate-700'
                        }`}
                      >
                        {rule.enabled ? 'ACTIVE' : 'DISABLED'}
                      </button>
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="font-semibold text-white">{rule.name}</div>
                      <div className="text-[10px] text-slate-400 truncate max-w-xs">{rule.description}</div>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">
                      <span className="text-cyan-400">[{rule.srcZone}]</span> {rule.srcAddress}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">
                      <span className="text-indigo-400">[{rule.dstZone}]</span> {rule.dstAddress} : {rule.dstPort || 'ANY'}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">
                      <span className="text-slate-400">{rule.protocol}</span> / <strong className="text-white">{rule.application}</strong>
                    </td>
                    <td className="py-2.5 px-3">
                      {rule.identityRequired ? (
                        <span className="px-1.5 py-0.5 rounded text-[10px] bg-purple-500/10 text-purple-300 border border-purple-500/30">
                          {rule.requiredGroup || 'MFA Enforced'}
                        </span>
                      ) : (
                        <span className="text-slate-600">None</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isAllow
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : rule.action === RuleAction.ISOLATE
                            ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                            : 'bg-red-500/10 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {rule.action}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-400">{rule.hitCount.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-right space-x-1">
                      <button
                        onClick={() => {
                          setEditingRule(rule);
                          setShowAddModal(true);
                        }}
                        className="p-1 hover:text-cyan-400 transition"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteRule(rule.id)}
                        className="p-1 hover:text-red-400 transition"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit / Add Rule Modal */}
      {showAddModal && editingRule && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-cyan-500/40 rounded-lg max-w-2xl w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
              <Shield className="w-5 h-5 text-cyan-400" />
              CONFIGURE POLICY RULE
            </h3>

            <div className="grid grid-cols-2 gap-4 text-xs font-mono">
              <div>
                <label className="text-slate-400 block mb-1">Rule Name</label>
                <input
                  type="text"
                  value={editingRule.name}
                  onChange={(e) => setEditingRule({ ...editingRule, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Priority (1-999)</label>
                <input
                  type="number"
                  value={editingRule.priority}
                  onChange={(e) => setEditingRule({ ...editingRule, priority: parseInt(e.target.value, 10) || 100 })}
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Source Zone</label>
                <select
                  value={editingRule.srcZone}
                  onChange={(e) => setEditingRule({ ...editingRule, srcZone: e.target.value as any })}
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-white"
                >
                  {Object.values(NetworkZone).map((z) => (
                    <option key={z} value={z}>{z}</option>
                  ))}
                  <option value="ANY">ANY</option>
                </select>
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Destination Zone</label>
                <select
                  value={editingRule.dstZone}
                  onChange={(e) => setEditingRule({ ...editingRule, dstZone: e.target.value as any })}
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-white"
                >
                  {Object.values(NetworkZone).map((z) => (
                    <option key={z} value={z}>{z}</option>
                  ))}
                  <option value="ANY">ANY</option>
                </select>
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Source IP / CIDR</label>
                <input
                  type="text"
                  value={editingRule.srcAddress}
                  onChange={(e) => setEditingRule({ ...editingRule, srcAddress: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Destination IP / CIDR</label>
                <input
                  type="text"
                  value={editingRule.dstAddress}
                  onChange={(e) => setEditingRule({ ...editingRule, dstAddress: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Destination Port(s)</label>
                <input
                  type="text"
                  value={editingRule.dstPort || 'ANY'}
                  onChange={(e) => setEditingRule({ ...editingRule, dstPort: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Action</label>
                <select
                  value={editingRule.action}
                  onChange={(e) => setEditingRule({ ...editingRule, action: e.target.value as any })}
                  className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-white"
                >
                  <option value={RuleAction.ALLOW}>ALLOW</option>
                  <option value={RuleAction.DENY}>DENY</option>
                  <option value={RuleAction.REJECT}>REJECT</option>
                  <option value={RuleAction.RATE_LIMIT}>RATE_LIMIT</option>
                  <option value={RuleAction.ISOLATE}>ISOLATE</option>
                  <option value={RuleAction.LOG}>LOG</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs rounded transition"
              >
                Cancel
              </button>
              <button
                onClick={() => handleSaveRule(editingRule)}
                className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-xs font-semibold rounded transition"
              >
                Save to Candidate Staging
              </button>
            </div>
          </div>
        </div>
      )}

      {/* YAML Modal */}
      {showYamlModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-indigo-500/40 rounded-lg max-w-3xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
                <FileCode className="w-5 h-5 text-indigo-400" />
                DECLARATIVE POLICY AS CODE (YAML)
              </h3>
              <button onClick={() => setShowYamlModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>
            <textarea
              readOnly
              value={yamlText}
              className="w-full h-80 bg-slate-950 border border-slate-800 p-4 rounded text-xs font-mono text-cyan-300"
            />
            <div className="flex justify-end">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(yamlText);
                  alert('YAML copied to clipboard');
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-mono text-xs rounded transition"
              >
                Copy to Clipboard
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
