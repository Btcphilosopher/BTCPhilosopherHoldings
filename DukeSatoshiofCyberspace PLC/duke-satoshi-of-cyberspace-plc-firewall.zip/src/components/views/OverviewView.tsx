/**
 * @file OverviewView.tsx
 * Duke Satoshi of Cyberspace PLC - Sovereign Operations Overview
 */

import React from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Activity,
  Server,
  Cpu,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  Radio,
  Lock,
  Zap,
} from 'lucide-react';
import { TelemetrySnapshot, DecisionContext, ConnectionTrackEntry, NetworkZone } from '../../types/firewall';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip } from 'recharts';

interface OverviewViewProps {
  telemetry: TelemetrySnapshot;
  recentTraffic: DecisionContext[];
  activeConnections: ConnectionTrackEntry[];
  onSelectFlow: (context: DecisionContext) => void;
  onNavigateTo: (tab: any) => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  telemetry,
  recentTraffic,
  activeConnections,
  onSelectFlow,
  onNavigateTo,
}) => {
  // Generate historical chart points
  const [chartData, setChartData] = React.useState<{ time: string; pps: number; mbps: number }[]>([]);

  React.useEffect(() => {
    const nowStr = new Date().toLocaleTimeString();
    setChartData((prev) => {
      const next = [...prev, {
        time: nowStr,
        pps: telemetry.packetsPerSec,
        mbps: +(telemetry.bytesPerSec / 1024 / 1024).toFixed(2),
      }];
      return next.slice(-20);
    });
  }, [telemetry]);

  // Aggregate Top Applications
  const appStats = React.useMemo(() => {
    const counts: Record<string, number> = {};
    activeConnections.forEach((c) => {
      const app = c.application || `${c.protocol}/${c.dstPort}`;
      counts[app] = (counts[app] || 0) + 1;
    });
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
  }, [activeConnections]);

  // Aggregate Top Destinations
  const dstStats = React.useMemo(() => {
    const counts: Record<string, number> = {};
    activeConnections.forEach((c) => {
      const dst = `${c.dstZone} (${c.dstIp})`;
      counts[dst] = (counts[dst] || 0) + 1;
    });
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
  }, [activeConnections]);

  return (
    <div className="space-y-6">
      {/* High-Level Institutional Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono">
            <span>PACKET RATE</span>
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="mt-1 text-lg font-bold text-white font-mono">
            {telemetry.packetsPerSec.toLocaleString()} <span className="text-[10px] text-slate-400 font-normal">pkt/s</span>
          </div>
          <div className="mt-0.5 text-[10px] text-emerald-400 font-mono flex items-center">
            <ArrowUpRight className="w-3 h-3" /> +4.2% fast-path
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono">
            <span>BANDWIDTH</span>
            <Radio className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <div className="mt-1 text-lg font-bold text-white font-mono">
            {(telemetry.bytesPerSec / 1024 / 1024).toFixed(2)} <span className="text-[10px] text-slate-400 font-normal">MB/s</span>
          </div>
          <div className="mt-0.5 text-[10px] text-slate-400 font-mono">
            Wire Latency: {telemetry.avgLatencyUs} μs
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono">
            <span>ACTIVE FLOWS</span>
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
          </div>
          <div className="mt-1 text-lg font-bold text-cyan-300 font-mono">
            {telemetry.activeConnections.toLocaleString()}
          </div>
          <div className="mt-0.5 text-[10px] text-indigo-400 font-mono">
            Stateful Conntrack
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono">
            <span>BLOCKED FLOWS</span>
            <Lock className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="mt-1 text-lg font-bold text-amber-400 font-mono">
            {telemetry.droppedPackets.toLocaleString()}
          </div>
          <div className="mt-0.5 text-[10px] text-amber-500/80 font-mono">
            Default Deny / Policy
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono">
            <span>IDS ALERTS</span>
            <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
          </div>
          <div className="mt-1 text-lg font-bold text-red-400 font-mono">
            {telemetry.idsAlertsCount}
          </div>
          <div className="mt-0.5 text-[10px] text-red-400/80 font-mono">
            Active Threat Events
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono">
            <span>IPS MITIGATION</span>
            <Zap className="w-3.5 h-3.5 text-orange-400" />
          </div>
          <div className="mt-1 text-lg font-bold text-orange-300 font-mono">
            {telemetry.ipsMitigationsCount}
          </div>
          <div className="mt-0.5 text-[10px] text-orange-400/80 font-mono">
            Quarantined Hosts
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono">
            <span>CPU UTIL</span>
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="mt-1 text-lg font-bold text-white font-mono">
            {telemetry.cpuUsagePercent}%
          </div>
          <div className="mt-0.5 text-[10px] text-emerald-400 font-mono">
            48 Cores Dedicated
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono">
            <span>MEMORY</span>
            <Server className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="mt-1 text-lg font-bold text-white font-mono">
            {telemetry.memoryUsagePercent}%
          </div>
          <div className="mt-0.5 text-[10px] text-slate-400 font-mono">
            ECC Registered RAM
          </div>
        </div>
      </div>

      {/* Real-time Throughput Chart & Top Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Throughput Area Chart */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-semibold text-white font-mono flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                REAL-TIME THROUGHPUT & PACKET VELOCITY
              </h2>
              <p className="text-xs text-slate-400">Live fast-path packet engine sampling buffer</p>
            </div>
            <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-mono">
              ● 100 Gbps Interface Link Active
            </span>
          </div>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorPps" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#475569" fontSize={10} tickLine={false} />
                <YAxis stroke="#475569" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', fontSize: '11px', fontFamily: 'monospace' }}
                  labelStyle={{ color: '#94a3b8' }}
                />
                <Area type="monotone" dataKey="pps" stroke="#06b6d4" strokeWidth={2} fillOpacity={1} fill="url(#colorPps)" name="Packets/sec" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top Applications & Destinations */}
        <div className="space-y-4">
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
            <h3 className="text-xs font-semibold text-slate-200 font-mono uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>Top Active Applications</span>
              <span className="text-[10px] text-cyan-400">App-ID</span>
            </h3>
            <div className="space-y-2">
              {appStats.map(([app, count]) => (
                <div key={app} className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-300 truncate max-w-[180px]">{app}</span>
                  <div className="flex items-center gap-2">
                    <div className="w-16 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-cyan-500 h-full rounded-full"
                        style={{ width: `${Math.min(100, (count / (activeConnections.length || 1)) * 100)}%` }}
                      />
                    </div>
                    <span className="text-slate-400 text-[11px] w-6 text-right">{count}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
            <h3 className="text-xs font-semibold text-slate-200 font-mono uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>Top Destination Zones</span>
              <span className="text-[10px] text-indigo-400">Micro-Segments</span>
            </h3>
            <div className="space-y-2">
              {dstStats.map(([dst, count]) => (
                <div key={dst} className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-300 truncate max-w-[180px]">{dst}</span>
                  <span className="text-slate-400 text-[11px]">{count} flows</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Live Decision Feed */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-semibold text-white font-mono flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              LIVE TRAFFIC DECISION STREAM
            </h3>
            <p className="text-xs text-slate-400">
              Click any flow to open the deep packet inspector & explainable decision context
            </p>
          </div>
          <button
            onClick={() => onNavigateTo('traffic')}
            className="text-xs font-mono text-cyan-400 hover:text-cyan-300 transition"
          >
            View Full Traffic Inspector →
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950/70 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2 px-3">Time</th>
                <th className="py-2 px-3">Source</th>
                <th className="py-2 px-3">Destination</th>
                <th className="py-2 px-3">Proto</th>
                <th className="py-2 px-3">Application</th>
                <th className="py-2 px-3">Risk</th>
                <th className="py-2 px-3">Decision</th>
                <th className="py-2 px-3">Policy / Reason</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {recentTraffic.slice(0, 8).map((flow) => {
                const isAllow = flow.policy.decision === 'ALLOW';
                return (
                  <tr
                    key={flow.connectionId}
                    onClick={() => onSelectFlow(flow)}
                    className="hover:bg-slate-800/60 cursor-pointer transition"
                  >
                    <td className="py-2 px-3 text-slate-400">
                      {new Date(flow.timestamp).toISOString().slice(11, 19)}
                    </td>
                    <td className="py-2 px-3 text-slate-300">
                      <span className="text-[10px] text-slate-400">[{flow.where.srcZone}]</span> {flow.where.srcIp}
                    </td>
                    <td className="py-2 px-3 text-slate-300">
                      <span className="text-[10px] text-slate-400">[{flow.where.dstZone}]</span> {flow.where.dstIp}:{flow.what.dstPort}
                    </td>
                    <td className="py-2 px-3 text-cyan-400">{flow.what.protocol}</td>
                    <td className="py-2 px-3 text-slate-200">{flow.what.application}</td>
                    <td className="py-2 px-3">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          flow.risk.level === 'CRITICAL'
                            ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                            : flow.risk.level === 'HIGH'
                            ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                            : flow.risk.level === 'MEDIUM'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                            : 'bg-slate-800 text-slate-300'
                        }`}
                      >
                        {flow.risk.totalScore}
                      </span>
                    </td>
                    <td className="py-2 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isAllow
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : 'bg-red-500/10 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {flow.policy.decision}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-slate-400 truncate max-w-xs">
                      {flow.policy.explanation}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
