/**
 * @file DigitalTwinView.tsx
 * Duke Satoshi of Cyberspace PLC - Network Digital Twin & Interactive Topology
 * Real-time topological rendering of zones, physical/virtual nodes, trust boundaries, and live flow vectors.
 */

import React, { useState } from 'react';
import {
  Globe,
  Shield,
  Server,
  Database,
  Lock,
  Radio,
  Cpu,
  Layers,
  AlertTriangle,
  Zap,
} from 'lucide-react';
import { NetworkZone, DecisionContext } from '../../types/firewall';

interface DigitalTwinViewProps {
  recentTraffic: DecisionContext[];
  onSelectZone?: (zone: NetworkZone) => void;
}

export const DigitalTwinView: React.FC<DigitalTwinViewProps> = ({
  recentTraffic,
  onSelectZone,
}) => {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);

  const zones = [
    {
      id: NetworkZone.PUBLIC,
      name: 'PUBLIC INTERNET',
      type: 'UNTRUSTED WAN',
      ipRange: '0.0.0.0/0',
      color: 'border-red-500/40 bg-red-950/20 text-red-400',
      nodes: [
        { id: 'wan_gw', label: 'BGP Edge Router (AS65001)', ip: '198.51.100.254', status: 'ACTIVE' },
        { id: 'swift_ext', label: 'SWIFT Wire Network (Inter-bank)', ip: '198.51.100.50', status: 'ACTIVE' },
      ],
    },
    {
      id: NetworkZone.DMZ,
      name: 'DMZ PERIMETER',
      type: 'BUFFER ZONE',
      ipRange: '10.20.1.0/24',
      color: 'border-amber-500/40 bg-amber-950/20 text-amber-400',
      nodes: [
        { id: 'dmz_proxy', label: 'WAF / Reverse Proxy Cluster', ip: '10.20.1.10', status: 'ACTIVE' },
        { id: 'dmz_dns', label: 'Sovereign DNS Resolver', ip: '10.20.1.53', status: 'ACTIVE' },
      ],
    },
    {
      id: NetworkZone.CORPORATE,
      name: 'CORPORATE WORKSTATIONS',
      type: 'INTERNAL TRUSTED',
      ipRange: '10.10.0.0/16',
      color: 'border-cyan-500/40 bg-cyan-950/20 text-cyan-400',
      nodes: [
        { id: 'corp_ad', label: 'Kerberos / Active Directory', ip: '10.10.1.5', status: 'ACTIVE' },
        { id: 'corp_clients', label: 'Executive & Eng Laptops (VLAN 10)', ip: '10.10.45.0/24', status: 'ACTIVE' },
      ],
    },
    {
      id: NetworkZone.FINANCE,
      name: 'PRIVATE BANKING SETTLEMENT',
      type: 'RESTRICTED COMPLIANCE',
      ipRange: '10.30.1.0/24',
      color: 'border-emerald-500/40 bg-emerald-950/20 text-emerald-400',
      nodes: [
        { id: 'fin_swift', label: 'ISO20022 SWIFT Gateway Terminal', ip: '10.30.1.5', status: 'ACTIVE' },
        { id: 'fin_ledger', label: 'High-Value Ledger Node', ip: '10.30.1.20', status: 'ACTIVE' },
      ],
    },
    {
      id: NetworkZone.PRODUCTION,
      name: 'PRODUCTION CLOUD SERVICES',
      type: 'ENTERPRISE CORE',
      ipRange: '10.50.0.0/16',
      color: 'border-blue-500/40 bg-blue-950/20 text-blue-400',
      nodes: [
        { id: 'prod_api', label: 'API Gateway Microservices', ip: '10.50.2.1', status: 'ACTIVE' },
        { id: 'prod_auth', label: 'mTLS Authentication Broker', ip: '10.50.2.10', status: 'ACTIVE' },
      ],
    },
    {
      id: NetworkZone.DATABASE,
      name: 'ISOLATED DATA TIER',
      type: 'CONFIDENTIAL STORAGE',
      ipRange: '10.50.10.0/24',
      color: 'border-purple-500/40 bg-purple-950/20 text-purple-400',
      nodes: [
        { id: 'db_pg', label: 'PostgreSQL Primary Cluster (mTLS)', ip: '10.50.10.5', status: 'ACTIVE' },
        { id: 'db_redis', label: 'Encrypted Redis Memory Store', ip: '10.50.10.8', status: 'ACTIVE' },
      ],
    },
    {
      id: NetworkZone.VAULT,
      name: 'SOVEREIGN CRYPTO VAULT',
      type: 'MAXIMUM ZERO-TRUST AIR-GAP',
      ipRange: '10.99.1.0/29',
      color: 'border-amber-400 bg-amber-950/40 text-amber-300 font-bold',
      nodes: [
        { id: 'vault_hsm', label: 'Hardware Security Module (HSM 01)', ip: '10.99.1.10', status: 'ACTIVE' },
        { id: 'vault_signer', label: 'Cold Storage Multi-Sig Coordinator', ip: '10.99.1.12', status: 'ACTIVE' },
      ],
    },
    {
      id: NetworkZone.QUARANTINE,
      name: 'ISOLATION QUARANTINE',
      type: 'SANDBOXED CONTAINMENT',
      ipRange: '192.168.99.0/24',
      color: 'border-red-600 bg-red-950/50 text-red-300',
      nodes: [
        { id: 'quar_honeypot', label: 'High-Interaction Decoy Honeypot', ip: '192.168.99.10', status: 'ISOLATED' },
        { id: 'quar_host', label: 'Compromised Host Containment', ip: '192.168.99.45', status: 'ISOLATED' },
      ],
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-white font-mono flex items-center gap-2">
            <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
            SOVEREIGN NETWORK DIGITAL TWIN & REAL-TIME TOPOLOGY
          </h2>
          <p className="text-xs text-slate-400">
            Microsegmented security zones, trust boundaries, and active communication vectors
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono">
          <span className="flex items-center gap-1.5 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            Allowed Flows Active
          </span>
          <span className="flex items-center gap-1.5 text-red-400">
            <span className="w-2 h-2 rounded-full bg-red-500" />
            Blocked At Boundary
          </span>
        </div>
      </div>

      {/* Interactive Topology Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {zones.map((zone) => {
          // Count recent flows traversing this zone
          const flowCount = recentTraffic.filter(
            (t) => t.where.srcZone === zone.id || t.where.dstZone === zone.id
          ).length;

          return (
            <div
              key={zone.id}
              className={`rounded-lg border p-4 transition duration-200 hover:shadow-lg ${zone.color} ${
                zone.id === NetworkZone.VAULT ? 'ring-1 ring-amber-500/50' : ''
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h3 className="text-xs font-bold font-mono tracking-wider">{zone.name}</h3>
                  <span className="text-[10px] text-slate-400 font-mono">{zone.type}</span>
                </div>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-slate-950/80 border border-slate-800 text-slate-300">
                  {zone.ipRange}
                </span>
              </div>

              {/* Node Assets in Zone */}
              <div className="mt-3 space-y-2">
                {zone.nodes.map((node) => (
                  <div
                    key={node.id}
                    onClick={() => setSelectedNode(node.id === selectedNode ? null : node.id)}
                    className="bg-slate-950/80 border border-slate-800/80 rounded p-2 text-xs font-mono cursor-pointer hover:border-slate-600 transition"
                  >
                    <div className="flex items-center justify-between text-slate-200 font-semibold">
                      <span className="truncate">{node.label}</span>
                      <span
                        className={`w-2 h-2 rounded-full ${
                          node.status === 'ACTIVE' ? 'bg-emerald-400' : 'bg-red-500'
                        }`}
                      />
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">{node.ip}</div>
                  </div>
                ))}
              </div>

              {/* Dynamic Live Activity Indicator */}
              <div className="mt-3 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[10px] font-mono text-slate-400">
                <span>Active Traffic Vectors:</span>
                <span className="font-bold text-white">{flowCount} flows</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Node Inspector */}
      {selectedNode && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <h3 className="text-xs font-bold text-white font-mono mb-2 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            NODE TELEMETRY & ACCESS MATRIX: {selectedNode}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs font-mono text-slate-300">
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-500 block">Attestation Status:</span>
              <strong className="text-emerald-400">TPM 2.0 Hardware Attested</strong>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-500 block">mTLS Strict Enforce:</span>
              <strong className="text-cyan-300">TLS 1.3 Strict / P-384</strong>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-500 block">Segmentation Isolation:</span>
              <strong className="text-white">Microsegment Enforced</strong>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-500 block">Security Baseline:</span>
              <strong className="text-emerald-400">100% Invariant Compliant</strong>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
