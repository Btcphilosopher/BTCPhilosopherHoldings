/**
 * @file AuditTelemetryView.tsx
 * Duke Satoshi of Cyberspace PLC - Cryptographic Audit Trail & OpenTelemetry Metrics
 * Immutable SHA-256 hash-chained event logs and Prometheus metric endpoint generator.
 */

import React, { useState } from 'react';
import {
  FileText,
  Shield,
  Activity,
  Copy,
  CheckCircle,
  Lock,
} from 'lucide-react';
import { AuditLogger } from '../../core/telemetry/auditLogger';
import { PipelineOrchestrator } from '../../core/telemetry/syntheticTraffic';
import { AuditLogEntry } from '../../types/firewall';

export const AuditTelemetryView: React.FC = () => {
  const [logs] = useState<AuditLogEntry[]>(AuditLogger.getLogs());
  const [copied, setCopied] = useState(false);

  const snapshot = PipelineOrchestrator.getTelemetrySnapshot();
  const prometheusText = AuditLogger.generatePrometheusMetrics(snapshot);

  const handleCopyMetrics = () => {
    navigator.clipboard.writeText(prometheusText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-white font-mono flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" />
            IMMUTABLE SECURITY AUDIT TRAIL & OPENTELEMETRY METRICS
          </h2>
          <p className="text-xs text-slate-400">
            Cryptographically chained SHA-256 event integrity and OpenTelemetry standard telemetry exporter.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* OpenTelemetry / Prometheus Exporter */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 font-mono text-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              Prometheus Scrape Endpoint
            </h3>
            <button
              onClick={handleCopyMetrics}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] transition flex items-center gap-1"
            >
              {copied ? <CheckCircle className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>

          <pre className="bg-slate-950 border border-slate-800 p-3 rounded text-[11px] text-emerald-400 overflow-x-auto h-80">
            {prometheusText}
          </pre>
        </div>

        {/* Chained Audit Logs */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-4 font-mono text-xs space-y-3">
          <h3 className="font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            Cryptographically Chained Audit Records ({logs.length} entries)
          </h3>

          <div className="overflow-x-auto max-h-80">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800 sticky top-0">
                <tr>
                  <th className="py-2 px-3">Timestamp</th>
                  <th className="py-2 px-3">Actor</th>
                  <th className="py-2 px-3">Action</th>
                  <th className="py-2 px-3">Resource</th>
                  <th className="py-2 px-3">Status</th>
                  <th className="py-2 px-3">SHA-256 Hash</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {logs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-2 px-3 text-slate-400">
                      {new Date(log.timestamp).toISOString().slice(11, 19)}
                    </td>
                    <td className="py-2 px-3 font-semibold text-white">{log.actor}</td>
                    <td className="py-2 px-3 text-cyan-300">{log.action}</td>
                    <td className="py-2 px-3 text-slate-400 truncate max-w-[120px]">{log.resourceId}</td>
                    <td className="py-2 px-3">
                      <span className="text-emerald-400 font-bold">{log.status}</span>
                    </td>
                    <td className="py-2 px-3 text-slate-500 truncate max-w-[140px] text-[10px]">
                      {log.hash}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
