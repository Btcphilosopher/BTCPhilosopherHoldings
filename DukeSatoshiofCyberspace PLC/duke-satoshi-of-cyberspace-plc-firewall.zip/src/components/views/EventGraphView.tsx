/**
 * @file EventGraphView.tsx
 * Duke Satoshi of Cyberspace PLC - Security Event Graph & Incident Investigation
 * Interactive topological link analysis connecting Identity -> Connection -> Application -> Policy -> Threat Event.
 */

import React, { useState } from 'react';
import {
  Workflow,
  ShieldAlert,
  User,
  Server,
  Layers,
  ArrowRight,
  Shield,
  Activity,
} from 'lucide-react';
import { SecurityEvent } from '../../types/firewall';
import { IdsEngine } from '../../core/security/idsEngine';

export const EventGraphView: React.FC = () => {
  const events = IdsEngine.getEvents();
  const [selectedEventId, setSelectedEventId] = useState<string>(events[0]?.id || '');

  const selectedEvent = events.find((e) => e.id === selectedEventId) || events[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-white font-mono flex items-center gap-2">
            <Workflow className="w-4 h-4 text-cyan-400" />
            SECURITY INCIDENT GRAPH & CAUSAL ATTRIBUTION
          </h2>
          <p className="text-xs text-slate-400">
            End-to-end trace from initiating entity through policy evaluation, threat signature detection, and automated mitigation.
          </p>
        </div>
      </div>

      {/* Main Graph Canvas & Event Selector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Incident Selector */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-3 font-mono text-xs">
          <h3 className="font-bold text-white uppercase tracking-wider">Select Incident to Trace</h3>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {events.map((ev) => (
              <div
                key={ev.id}
                onClick={() => setSelectedEventId(ev.id)}
                className={`p-2.5 rounded border cursor-pointer transition ${
                  selectedEvent?.id === ev.id
                    ? 'bg-slate-800 border-cyan-400 text-white'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between font-semibold">
                  <span className="truncate">{ev.title}</span>
                  <span
                    className={`px-1.5 py-0.2 rounded text-[10px] ${
                      ev.severity === 'CRITICAL' ? 'bg-red-500/20 text-red-400' : 'bg-amber-500/20 text-amber-400'
                    }`}
                  >
                    {ev.severity}
                  </span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Source: {ev.sourceIp}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Causal Chain Graph Visualizer */}
        {selectedEvent && (
          <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-6 font-mono text-xs space-y-6">
            <h3 className="font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-red-400" />
              INCIDENT TRACE: {selectedEvent.title}
            </h3>

            {/* Visual Node Chain */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-3 bg-slate-950 p-4 rounded-lg border border-slate-800">
              {/* Node 1: Source */}
              <div className="bg-slate-900 border border-red-500/50 p-3 rounded-lg text-center w-full md:w-36">
                <User className="w-4 h-4 mx-auto mb-1 text-red-400" />
                <span className="text-[10px] text-slate-500 block">THREAT SOURCE</span>
                <strong className="text-white text-xs block truncate">{selectedEvent.sourceIp}</strong>
                <span className="text-[10px] text-red-400">UNTRUSTED</span>
              </div>

              <ArrowRight className="w-4 h-4 text-slate-600 hidden md:block" />

              {/* Node 2: Protocol Vector */}
              <div className="bg-slate-900 border border-amber-500/50 p-3 rounded-lg text-center w-full md:w-36">
                <Layers className="w-4 h-4 mx-auto mb-1 text-amber-400" />
                <span className="text-[10px] text-slate-500 block">VECTOR</span>
                <strong className="text-white text-xs block truncate">{selectedEvent.eventType}</strong>
                <span className="text-[10px] text-amber-400">ZONE [{selectedEvent.srcZone}]</span>
              </div>

              <ArrowRight className="w-4 h-4 text-slate-600 hidden md:block" />

              {/* Node 3: Target Perimeter */}
              <div className="bg-slate-900 border border-indigo-500/50 p-3 rounded-lg text-center w-full md:w-36">
                <Server className="w-4 h-4 mx-auto mb-1 text-indigo-400" />
                <span className="text-[10px] text-slate-500 block">TARGET</span>
                <strong className="text-white text-xs block truncate">{selectedEvent.destinationIp || '10.20.1.10'}</strong>
                <span className="text-[10px] text-indigo-300">ZONE [{selectedEvent.dstZone}]</span>
              </div>

              <ArrowRight className="w-4 h-4 text-slate-600 hidden md:block" />

              {/* Node 4: Defensive Action */}
              <div className="bg-slate-900 border border-emerald-500/50 p-3 rounded-lg text-center w-full md:w-36">
                <Shield className="w-4 h-4 mx-auto mb-1 text-emerald-400" />
                <span className="text-[10px] text-slate-500 block">IPS ENFORCEMENT</span>
                <strong className="text-emerald-400 text-xs block truncate">{selectedEvent.mitigationTaken || 'QUARANTINE'}</strong>
                <span className="text-[10px] text-emerald-300">CONFIDENCE: {selectedEvent.confidence}%</span>
              </div>
            </div>

            {/* Detailed Investigation Notes */}
            <div className="space-y-2 bg-slate-950 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 font-bold block">Forensic Evidence & Artifacts:</span>
              <pre className="text-slate-300 text-[11px] overflow-x-auto bg-slate-900 p-2.5 rounded border border-slate-800/80">
                {JSON.stringify(selectedEvent.evidence, null, 2)}
              </pre>
              <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400">
                Timestamp: {new Date(selectedEvent.timestamp).toISOString()} • Automated Attribution: Intrusion Detection Subsystem
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
