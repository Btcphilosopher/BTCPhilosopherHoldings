/**
 * @file ThreatIntelView.tsx
 * Duke Satoshi of Cyberspace PLC - Threat Intelligence & IOC Repository
 * Versioned threat feeds, indicators of compromise (IOCs), actor attribution, and feed rollback.
 */

import React, { useState } from 'react';
import {
  Database,
  Search,
  RotateCcw,
  Plus,
  Shield,
  ExternalLink,
  CheckCircle2,
} from 'lucide-react';
import { ThreatIntelEngine, ThreatFeedSnapshot } from '../../core/security/threatIntel';
import { ThreatIndicator } from '../../types/firewall';
import { AuditLogger } from '../../core/telemetry/auditLogger';

export const ThreatIntelView: React.FC = () => {
  const [history, setHistory] = useState<ThreatFeedSnapshot[]>(ThreatIntelEngine.getFeedHistory());
  const [iocs, setIocs] = useState<ThreatIndicator[]>(ThreatIntelEngine.getAllIndicators());
  const [searchTerm, setSearchTerm] = useState('');
  const [newIocValue, setNewIocValue] = useState('');
  const [newIocType, setNewIocType] = useState<'IP' | 'DOMAIN' | 'CIDR'>('IP');
  const [newIocCategory, setNewIocCategory] = useState<'C2_BOTNET' | 'APT_SOVEREIGN' | 'EXPLOIT_SCANNER' | 'MALICIOUS_DNS' | 'PHISHING' | 'TOR_EXIT_NODE'>('C2_BOTNET');
  const [newIocFeed, setNewIocFeed] = useState('Duke Satoshi Sovereign Security Advisory');

  const handleAddIoc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newIocValue.trim()) return;

    const newIndicator: ThreatIndicator = {
      id: `ioc_custom_${Date.now()}`,
      type: newIocType,
      value: newIocValue.trim(),
      category: newIocCategory,
      reputationScore: 95,
      sourceFeed: newIocFeed.trim(),
      confidence: 99,
      addedAt: Date.now(),
      expiresAt: Date.now() + 86400000 * 30,
      active: true,
    };

    ThreatIntelEngine.addIndicator(newIndicator);

    AuditLogger.log({
      actor: 'lord.satoshi',
      action: 'THREAT_FEED_UPDATED',
      resourceType: 'IOC_DATABASE',
      resourceId: newIocValue.trim(),
      status: 'SUCCESS',
      ipAddress: '10.0.0.5',
    });

    setNewIocValue('');
    setIocs(ThreatIntelEngine.getAllIndicators());
  };

  const handleRollback = (version: number) => {
    const success = ThreatIntelEngine.rollbackFeed(version);
    if (success) {
      alert(`Threat feed successfully restored to cryptographic snapshot v${version}`);
      setHistory(ThreatIntelEngine.getFeedHistory());
      setIocs(ThreatIntelEngine.getAllIndicators());
    }
  };

  const filteredIocs = iocs.filter((ioc) => {
    if (!searchTerm) return true;
    const q = searchTerm.toLowerCase();
    return (
      ioc.value.toLowerCase().includes(q) ||
      ioc.sourceFeed.toLowerCase().includes(q) ||
      ioc.category.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-white font-mono flex items-center gap-2">
            <Database className="w-4 h-4 text-cyan-400" />
            SOVEREIGN THREAT INTELLIGENCE & REPUTATION ENGINE
          </h2>
          <p className="text-xs text-slate-400">
            Cryptographically signed threat feeds with automated wire inspection and instantaneous rollback.
          </p>
        </div>
      </div>

      {/* Versioned Threat Feeds Snapshots */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {history.map((feed) => (
          <div key={feed.version} className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 font-mono text-xs">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-white truncate">{feed.author}</h3>
              <span className="px-1.5 py-0.5 bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 rounded text-[10px]">
                v{feed.version}
              </span>
            </div>
            <div className="space-y-1 text-slate-300 border-t border-slate-800 pt-2 mb-3">
              <div>Indicators in Snapshot: <strong className="text-white">{feed.indicators.length}</strong></div>
              <div>Created: <span className="text-slate-400">{new Date(feed.timestamp).toLocaleTimeString()}</span></div>
            </div>
            <button
              onClick={() => handleRollback(feed.version)}
              className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 transition flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
              Restore Feed Version
            </button>
          </div>
        ))}
      </div>

      {/* Manual Indicator Ingestion & IOC Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Add IOC Form */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <Plus className="w-3.5 h-3.5 text-cyan-400" />
            Inject High-Assurance IOC
          </h3>
          <form onSubmit={handleAddIoc} className="space-y-3 text-xs font-mono">
            <div>
              <label className="text-slate-400 block mb-1">Indicator Value</label>
              <input
                type="text"
                placeholder="IP / Domain / CIDR"
                value={newIocValue}
                onChange={(e) => setNewIocValue(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Type</label>
              <select
                value={newIocType}
                onChange={(e) => setNewIocType(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
              >
                <option value="IP">IP Address</option>
                <option value="DOMAIN">Domain Name</option>
                <option value="CIDR">CIDR Subnet Range</option>
              </select>
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Category</label>
              <select
                value={newIocCategory}
                onChange={(e) => setNewIocCategory(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
              >
                <option value="C2_BOTNET">C2 Botnet Controller</option>
                <option value="APT_SOVEREIGN">APT State-Actor Sovereign</option>
                <option value="EXPLOIT_SCANNER">Exploit Scanner</option>
                <option value="MALICIOUS_DNS">Malicious DNS Node</option>
                <option value="TOR_EXIT_NODE">Tor Exit Node</option>
              </select>
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Threat Feed / Origin</label>
              <input
                type="text"
                placeholder="e.g. Duke Satoshi Sovereign Threat Watch"
                value={newIocFeed}
                onChange={(e) => setNewIocFeed(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold rounded transition"
            >
              Add to Threat Database
            </button>
          </form>
        </div>

        {/* IOC Table */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider">
              Active Indicators of Compromise ({filteredIocs.length} records)
            </h3>
            <div className="flex items-center gap-1.5 bg-slate-950 px-2 py-1 rounded border border-slate-800 text-xs font-mono">
              <Search className="w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Filter IOCs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-transparent text-slate-200 focus:outline-none text-[11px]"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-2 px-3">Indicator Value</th>
                  <th className="py-2 px-3">Type</th>
                  <th className="py-2 px-3">Category</th>
                  <th className="py-2 px-3">Source Feed</th>
                  <th className="py-2 px-3">Reputation</th>
                  <th className="py-2 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredIocs.map((ioc) => (
                  <tr key={ioc.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-2 px-3 font-semibold text-red-400">{ioc.value}</td>
                    <td className="py-2 px-3 text-slate-400">{ioc.type}</td>
                    <td className="py-2 px-3 text-slate-300">{ioc.category}</td>
                    <td className="py-2 px-3 text-cyan-300">{ioc.sourceFeed}</td>
                    <td className="py-2 px-3 text-emerald-400">{ioc.reputationScore}/100</td>
                    <td className="py-2 px-3">
                      <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded text-[10px]">
                        ACTIVE
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
