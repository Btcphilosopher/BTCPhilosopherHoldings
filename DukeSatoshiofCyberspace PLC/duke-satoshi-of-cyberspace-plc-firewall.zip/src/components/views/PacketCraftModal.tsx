/**
 * @file PacketCraftModal.tsx
 * Duke Satoshi of Cyberspace PLC - Live Raw Packet Crafter & Hex Frame Injector
 * Directly builds RFC-compliant binary frames and injects them into the Fast-Path pipeline.
 */

import React, { useState } from 'react';
import {
  Zap,
  X,
  Play,
  Shield,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { Protocol, TcpFlag, DecisionContext } from '../../types/firewall';
import { PacketEngine } from '../../core/packet/packetEngine';
import { PipelineOrchestrator } from '../../core/telemetry/syntheticTraffic';
import { ZeroTrustEngine } from '../../core/identity/zeroTrust';

interface PacketCraftModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPacketInjected: (context: DecisionContext) => void;
}

export const PacketCraftModal: React.FC<PacketCraftModalProps> = ({
  isOpen,
  onClose,
  onPacketInjected,
}) => {
  const [srcIp, setSrcIp] = useState('10.10.45.100');
  const [dstIp, setDstIp] = useState('10.99.1.10');
  const [protocol, setProtocol] = useState<Protocol>(Protocol.TCP);
  const [srcPort, setSrcPort] = useState(54320);
  const [dstPort, setDstPort] = useState(8200);
  const [payload, setPayload] = useState('VAULT_RPC: UNVERIFIED_SIGN_REQUEST');
  const [selectedUser, setSelectedUser] = useState<string>('none');
  const [injectedResult, setInjectedResult] = useState<DecisionContext | null>(null);

  if (!isOpen) return null;

  const identities = ZeroTrustEngine.getIdentities();
  const devices = ZeroTrustEngine.getDevices();

  const handleInject = (e: React.FormEvent) => {
    e.preventDefault();

    const rawBytes = PacketEngine.buildPacket({
      srcIp,
      dstIp,
      protocol,
      srcPort,
      dstPort,
      flags: [TcpFlag.SYN],
      payload,
    });

    const userObj = identities.find((u) => u.id === selectedUser);
    const devObj = userObj ? devices.find((d) => userObj.assignedDevices.includes(d.deviceId)) : undefined;

    const { context } = PipelineOrchestrator.processSinglePacket(
      rawBytes,
      'if_corp0',
      userObj
        ? {
            userId: userObj.id,
            userName: userObj.username,
            roles: userObj.roles,
            mfaVerified: userObj.mfaEnrolled,
            deviceTrust: devObj?.trustLevel || 'UNTRUSTED',
            deviceId: devObj?.deviceId,
          }
        : undefined
    );

    setInjectedResult(context);
    onPacketInjected(context);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-cyan-500/40 rounded-lg max-w-2xl w-full p-6 space-y-4 shadow-2xl font-mono text-xs">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Zap className="w-4 h-4 text-cyan-400" />
            CRAFT & INJECT RAW NETWORK PACKET
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleInject} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-slate-400 block mb-1">Source IP</label>
              <input
                type="text"
                value={srcIp}
                onChange={(e) => setSrcIp(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Destination IP</label>
              <input
                type="text"
                value={dstIp}
                onChange={(e) => setDstIp(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Protocol</label>
              <select
                value={protocol}
                onChange={(e) => setProtocol(e.target.value as Protocol)}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
              >
                <option value={Protocol.TCP}>TCP</option>
                <option value={Protocol.UDP}>UDP</option>
                <option value={Protocol.ICMP}>ICMP</option>
              </select>
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Destination Port</label>
              <input
                type="number"
                value={dstPort}
                onChange={(e) => setDstPort(parseInt(e.target.value, 10) || 80)}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
              />
            </div>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Simulated Identity (Zero-Trust Context)</label>
            <select
              value={selectedUser}
              onChange={(e) => setSelectedUser(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
            >
              <option value="none">Unauthenticated / Anonymous Client</option>
              {identities.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.username} ({u.department}) - Roles: {u.roles.join(', ')}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Payload String</label>
            <input
              type="text"
              value={payload}
              onChange={(e) => setPayload(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded"
            >
              Close
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded transition flex items-center gap-1.5"
            >
              <Play className="w-4 h-4" /> Inject Frame
            </button>
          </div>
        </form>

        {/* Injection Result */}
        {injectedResult && (
          <div className="mt-4 p-4 bg-slate-950 border border-cyan-500/50 rounded-lg space-y-2">
            <div className="flex items-center justify-between">
              <strong className="text-white">INJECTION RESULT:</strong>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  injectedResult.policy.decision === 'ALLOW'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    : 'bg-red-500/20 text-red-400 border border-red-500/40'
                }`}
              >
                DECISION: {injectedResult.policy.decision}
              </span>
            </div>
            <div className="text-slate-300">
              Matched Policy: <strong className="text-white">{injectedResult.policy.matchedRuleName}</strong>
            </div>
            <div className="text-slate-400 italic">
              &ldquo;{injectedResult.policy.explanation}&rdquo;
            </div>
            <div className="text-[11px] text-amber-300">
              Risk Score: {injectedResult.risk.totalScore}/100 [{injectedResult.risk.level}]
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
