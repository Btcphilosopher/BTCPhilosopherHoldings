/**
 * @file DnsSecurityView.tsx
 * Duke Satoshi of Cyberspace PLC - DNS Firewall, Sinkholing & DGA Detection
 * Recursive DNS inspection, entropy calculation, malicious domain sinkholing, and policy enforcement.
 */

import React, { useState } from 'react';
import {
  Globe,
  Shield,
  Radio,
  Plus,
  Trash2,
  AlertTriangle,
  Lock,
} from 'lucide-react';
import { DnsSecurityEngine } from '../../core/security/dnsSecurity';
import { DnsRecord, NetworkZone } from '../../types/firewall';

export const DnsSecurityView: React.FC = () => {
  const [logs, setLogs] = useState<DnsRecord[]>(DnsSecurityEngine.getQueryLog());
  const [blocklist, setBlocklist] = useState<string[]>(DnsSecurityEngine.getBlocklist());
  const [allowlist] = useState<string[]>(DnsSecurityEngine.getAllowlist());
  const [testDomain, setTestDomain] = useState('');
  const [newDomain, setNewDomain] = useState('');

  const handleTestQuery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testDomain.trim()) return;

    DnsSecurityEngine.processQuery(
      testDomain.trim(),
      '10.10.45.12',
      NetworkZone.CORPORATE,
      'A'
    );
    setLogs(DnsSecurityEngine.getQueryLog());
    setTestDomain('');
  };

  const handleAddBlocklist = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDomain.trim()) return;

    DnsSecurityEngine.addBlocklistDomain(newDomain.trim());
    setBlocklist(DnsSecurityEngine.getBlocklist());
    setNewDomain('');
  };

  const handleRemoveBlocklist = (domain: string) => {
    DnsSecurityEngine.removeBlocklistDomain(domain);
    setBlocklist(DnsSecurityEngine.getBlocklist());
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-white font-mono flex items-center gap-2">
            <Globe className="w-4 h-4 text-cyan-400" />
            DNS FIREWALL, SINKHOLING & DOMAIN REPUTATION
          </h2>
          <p className="text-xs text-slate-400">
            Real-time DNS layer filtering, high-entropy DGA exfiltration detection, and cryptographic sinkhole deflection.
          </p>
        </div>
      </div>

      {/* Query Test & Policy Manager */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Test DNS Query */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-cyan-400" />
            Simulate DNS Resolver Query
          </h3>
          <form onSubmit={handleTestQuery} className="space-y-3 text-xs font-mono">
            <div>
              <label className="text-slate-400 block mb-1">Domain Name to Resolve</label>
              <input
                type="text"
                placeholder="e.g. darknet-exfil-proxy.ru"
                value={testDomain}
                onChange={(e) => setTestDomain(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold rounded transition"
            >
              Send DNS Query
            </button>
          </form>

          {/* Add Blocklist Domain */}
          <div className="mt-6 pt-4 border-t border-slate-800">
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5 text-amber-400" />
              Add Domain to Sinkhole Blocklist
            </h3>
            <form onSubmit={handleAddBlocklist} className="space-y-2 text-xs font-mono">
              <input
                type="text"
                placeholder="e.g. ransomware-payload-c2.cc"
                value={newDomain}
                onChange={(e) => setNewDomain(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
              />
              <button
                type="submit"
                className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-semibold transition"
              >
                Add Sinkhole Rule
              </button>
            </form>

            <div className="mt-3 space-y-1 max-h-32 overflow-y-auto">
              {blocklist.map((dom) => (
                <div key={dom} className="flex items-center justify-between text-[11px] font-mono text-red-300 bg-slate-950 p-1.5 rounded">
                  <span className="truncate">{dom}</span>
                  <button onClick={() => handleRemoveBlocklist(dom)} className="text-slate-500 hover:text-red-400">
                    ✕
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* DNS Query Live Stream */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-4">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-3 flex items-center justify-between">
            <span>Recursive DNS Resolution Stream ({logs.length} queries)</span>
            <span className="text-[10px] text-cyan-400">Sinkhole IP: 127.0.0.1 / 0.0.0.0</span>
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-2 px-3">Timestamp</th>
                  <th className="py-2 px-3">Queried Domain</th>
                  <th className="py-2 px-3">Client IP</th>
                  <th className="py-2 px-3">Category</th>
                  <th className="py-2 px-3">Status</th>
                  <th className="py-2 px-3">Resolved IP</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {logs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-2 px-3 text-slate-400">
                      {new Date(log.timestamp).toISOString().slice(11, 19)}
                    </td>
                    <td className="py-2 px-3 font-semibold text-white truncate max-w-xs">{log.domain}</td>
                    <td className="py-2 px-3 text-slate-400">{log.clientIp}</td>
                    <td className="py-2 px-3 text-slate-300">
                      <span className="text-[10px] text-slate-400">{log.category}</span>
                    </td>
                    <td className="py-2 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          log.status === 'ALLOWED'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : 'bg-red-500/20 text-red-400 border border-red-500/40'
                        }`}
                      >
                        {log.status}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-cyan-300">{log.responseIp || 'NXDOMAIN'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
