/**
 * @file HighAvailabilityView.tsx
 * Duke Satoshi of Cyberspace PLC - High Availability & State Replication Subsystem
 * Active/Passive hot standby, continuous connection state synchronization, and cluster failover manager.
 */

import React, { useState } from 'react';
import {
  Server,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Zap,
  Activity,
  Layers,
  ArrowRightLeft,
} from 'lucide-react';
import { ClusterManager } from '../../core/ha/clusterManager';
import { ClusterNode } from '../../types/firewall';
import { AuditLogger } from '../../core/telemetry/auditLogger';

export const HighAvailabilityView: React.FC = () => {
  const [nodes, setNodes] = useState<ClusterNode[]>(ClusterManager.getNodes());
  const [failoverMsg, setFailoverMsg] = useState<string | null>(null);

  const handleTriggerFailover = () => {
    const res = ClusterManager.triggerFailover();
    setFailoverMsg(res.message);
    setNodes(ClusterManager.getNodes());

    AuditLogger.log({
      actor: 'lord.satoshi',
      action: 'FAILOVER',
      resourceType: 'HA_CLUSTER',
      resourceId: 'node-cluster-sovereign',
      status: res.success ? 'SUCCESS' : 'FAILURE',
      ipAddress: '10.0.0.5',
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold text-white font-mono flex items-center gap-2">
            <Server className="w-4 h-4 text-cyan-400" />
            HIGH AVAILABILITY, QUORUM & CONCURRENT STATE REPLICATION
          </h2>
          <p className="text-xs text-slate-400">
            Sub-millisecond connection table sync, configuration hash parity verification, and non-disruptive failover.
          </p>
        </div>

        <button
          onClick={handleTriggerFailover}
          className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-mono text-xs font-semibold rounded transition shadow-md"
        >
          <ArrowRightLeft className="w-4 h-4" />
          Simulate Cluster Failover
        </button>
      </div>

      {/* Failover Alert Result */}
      {failoverMsg && (
        <div className="p-3 bg-indigo-950/80 border border-indigo-500/50 rounded-lg text-xs font-mono text-indigo-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-indigo-400" />
            <span>{failoverMsg}</span>
          </div>
          <button onClick={() => setFailoverMsg(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Nodes Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs">
        {nodes.map((node) => {
          const isPrimary = node.role === 'PRIMARY';
          const isStandby = node.role === 'SECONDARY';

          return (
            <div
              key={node.id}
              className={`bg-slate-900/90 border rounded-lg p-5 space-y-3 relative ${
                isPrimary
                  ? 'border-emerald-500/50 shadow-lg shadow-emerald-500/5'
                  : isStandby
                  ? 'border-cyan-500/40'
                  : 'border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      isPrimary
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : isStandby
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {node.role} NODE
                  </span>
                  <h3 className="font-bold text-white mt-1">{node.name}</h3>
                </div>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              </div>

              <div className="space-y-1.5 text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-500">Management IP:</span>
                  <strong className="text-white">{node.ipAddress}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Replicated Flows:</span>
                  <span className="text-cyan-300">{node.connectionCount.toLocaleString()} conntrack</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Sync Latency:</span>
                  <span className="text-emerald-400">{node.syncLatencyMs} ms</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Throughput:</span>
                  <span className="text-white">{node.networkThroughputMbps} Mbps</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">CPU / RAM:</span>
                  <span className="text-slate-300">{node.cpuPercent}% / {node.memoryPercent}%</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/80">
                <span className="text-slate-500 text-[10px] block">Config Parity Checksum:</span>
                <span className="text-[10px] text-slate-400 truncate block mt-0.5">{node.configHash}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
