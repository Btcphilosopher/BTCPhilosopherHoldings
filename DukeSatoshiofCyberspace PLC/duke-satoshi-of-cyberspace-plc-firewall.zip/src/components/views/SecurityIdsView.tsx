/**
 * @file SecurityIdsView.tsx
 * Duke Satoshi of Cyberspace PLC - Intrusion Detection & Automated Prevention (IDS/IPS)
 * Live alert stream, signature matches, Mitre ATT&CK mapping, and host quarantine manager.
 */

import React, { useState } from 'react';
import {
  ShieldAlert,
  Zap,
  Lock,
  Unlock,
  AlertTriangle,
  Radio,
  Trash2,
  Plus,
} from 'lucide-react';
import { SecurityEvent } from '../../types/firewall';
import { IdsEngine } from '../../core/security/idsEngine';
import { IpsEngine, BlockedHost } from '../../core/security/ipsEngine';
import { AuditLogger } from '../../core/telemetry/auditLogger';

export const SecurityIdsView: React.FC = () => {
  const [events, setEvents] = useState<SecurityEvent[]>(IdsEngine.getEvents());
  const [quarantined, setQuarantined] = useState<BlockedHost[]>(IpsEngine.getBlockedHosts());
  const [newQuarantineIp, setNewQuarantineIp] = useState('');
  const [newQuarantineReason, setNewQuarantineReason] = useState('');

  const refreshState = () => {
    setEvents(IdsEngine.getEvents());
    setQuarantined(IpsEngine.getBlockedHosts());
  };

  const handleManualQuarantine = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuarantineIp.trim()) return;

    IpsEngine.manuallyBlockHost(
      newQuarantineIp.trim(),
      newQuarantineReason.trim() || 'Manual administrator security containment',
      3600,
      true
    );

    AuditLogger.log({
      actor: 'lord.satoshi',
      action: 'HOST_QUARANTINED',
      resourceType: 'HOST_IP',
      resourceId: newQuarantineIp.trim(),
      status: 'SUCCESS',
      ipAddress: '10.0.0.5',
    });

    setNewQuarantineIp('');
    setNewQuarantineReason('');
    refreshState();
  };

  const handleReleaseHost = (ip: string) => {
    IpsEngine.unblockHost(ip);
    AuditLogger.log({
      actor: 'lord.satoshi',
      action: 'HOST_QUARANTINED',
      resourceType: 'HOST_IP',
      resourceId: ip,
      status: 'SUCCESS',
      ipAddress: '10.0.0.5',
    });
    refreshState();
  };

  const handleClearAlerts = () => {
    IdsEngine.clearEvents();
    refreshState();
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold text-white font-mono flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-400" />
            INTRUSION DETECTION (IDS) & ACTIVE DEFENSIVE MITIGATION (IPS)
          </h2>
          <p className="text-xs text-slate-400">
            Real-time heuristic & signature-based intrusion detection with automated quarantine triggers.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <button
            onClick={handleClearAlerts}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 transition"
          >
            Clear Alert Buffer
          </button>
        </div>
      </div>

      {/* Quarantined Hosts Banner & Manual Isolation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Manual Host Quarantine Form */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-red-400" />
            Manual Host Isolation Trigger
          </h3>
          <form onSubmit={handleManualQuarantine} className="space-y-3 text-xs font-mono">
            <div>
              <label className="text-slate-400 block mb-1">Target Host IP</label>
              <input
                type="text"
                placeholder="e.g. 198.51.100.42"
                value={newQuarantineIp}
                onChange={(e) => setNewQuarantineIp(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Containment Rationale</label>
              <input
                type="text"
                placeholder="e.g. Suspicious lateral port scan"
                value={newQuarantineReason}
                onChange={(e) => setNewQuarantineReason(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-red-700 hover:bg-red-600 text-white font-semibold rounded transition flex items-center justify-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              Isolate & Quarantine Host
            </button>
          </form>
        </div>

        {/* Quarantined Hosts List */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-4">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-3 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-orange-400" />
              Active Quarantine Perimeter ({quarantined.length} Hosts Isolated)
            </span>
            <span className="text-[10px] text-slate-500">Auto-Enforcing Drop on Wire</span>
          </h3>

          <div className="space-y-2 max-h-48 overflow-y-auto">
            {quarantined.length > 0 ? (
              quarantined.map((q) => (
                <div
                  key={q.ip}
                  className="bg-slate-950 border border-red-500/30 rounded p-2.5 flex items-center justify-between text-xs font-mono"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <strong className="text-red-400">{q.ip}</strong>
                      <span className="px-1.5 py-0.2 bg-red-950 text-red-300 border border-red-800 rounded text-[10px]">
                        {q.quarantinedZone ? 'ISOLATED_ZONE' : 'PERIMETER_DROP'}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{q.reason}</div>
                  </div>
                  <button
                    onClick={() => handleReleaseHost(q.ip)}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] transition flex items-center gap-1"
                  >
                    <Unlock className="w-3 h-3 text-emerald-400" />
                    Release
                  </button>
                </div>
              ))
            ) : (
              <div className="text-slate-500 text-xs font-mono py-4 text-center">
                No active hosts currently quarantined.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Real-time Intrusion Detection Alert Stream */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
        <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-3 flex items-center gap-2">
          <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
          Intrusion Detection Event Log ({events.length} Detections Recorded)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">Severity</th>
                <th className="py-2.5 px-3">Attack / Event Type</th>
                <th className="py-2.5 px-3">Details</th>
                <th className="py-2.5 px-3">Source IP</th>
                <th className="py-2.5 px-3">Target IP</th>
                <th className="py-2.5 px-3">Automated Mitigation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {events.map((ev) => (
                <tr key={ev.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-2 px-3 text-slate-400">
                    {new Date(ev.timestamp).toISOString().slice(11, 19)}
                  </td>
                  <td className="py-2 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        ev.severity === 'CRITICAL'
                          ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                          : ev.severity === 'HIGH'
                          ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                          : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                      }`}
                    >
                      {ev.severity}
                    </span>
                  </td>
                  <td className="py-2 px-3 text-slate-200">
                    <div className="font-semibold">{ev.title}</div>
                  </td>
                  <td className="py-2 px-3 text-cyan-300">
                    <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-950 border border-slate-700">
                      {ev.eventType}
                    </span>
                  </td>
                  <td className="py-2 px-3 text-red-300">{ev.sourceIp}</td>
                  <td className="py-2 px-3 text-slate-300">{ev.destinationIp || 'Perimeter'}</td>
                  <td className="py-2 px-3">
                    <span className="px-2 py-0.5 bg-red-950 text-red-300 border border-red-800 rounded text-[10px] font-bold">
                      {ev.mitigationTaken || 'ALERTED'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
