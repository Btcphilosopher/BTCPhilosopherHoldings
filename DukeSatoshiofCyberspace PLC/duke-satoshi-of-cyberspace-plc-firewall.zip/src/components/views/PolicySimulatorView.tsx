/**
 * @file PolicySimulatorView.tsx
 * Duke Satoshi of Cyberspace PLC - Pre-Commit Policy Impact & Blast Radius Simulator
 * "What happens if I block this?" - Evaluates rule changes against active flows & detects admin lockout.
 */

import React, { useState } from 'react';
import {
  Cpu,
  AlertTriangle,
  CheckCircle,
  Play,
  Layers,
  Server,
  Users,
  Shield,
  ArrowRight,
} from 'lucide-react';
import { FirewallRule, NetworkZone, Protocol, RuleAction, PolicySimulationResult } from '../../types/firewall';
import { PolicySimulator } from '../../core/policy/policySimulator';
import { ConfigManager } from '../../core/config/configManager';
import { ConnectionTrackingEngine } from '../../core/state/conntrack';

export const PolicySimulatorView: React.FC = () => {
  const activeRules = ConfigManager.getActiveRules();
  const [selectedRuleId, setSelectedRuleId] = useState<string>(activeRules[1]?.id || activeRules[0]?.id || '');
  const [proposedAction, setProposedAction] = useState<RuleAction>(RuleAction.DENY);
  const [simulationResult, setSimulationResult] = useState<PolicySimulationResult | null>(null);

  const handleRunSimulation = () => {
    const selected = activeRules.find((r) => r.id === selectedRuleId);
    if (!selected) return;

    const proposedRule: FirewallRule = {
      ...selected,
      action: proposedAction,
    };

    const activeConns = ConnectionTrackingEngine.getAllConnections();
    const res = PolicySimulator.simulate(proposedRule, activeRules, activeConns);
    setSimulationResult(res);
  };

  const selectedRule = activeRules.find((r) => r.id === selectedRuleId);

  return (
    <div className="space-y-6">
      {/* Simulator Control Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
        <h2 className="text-sm font-bold text-white font-mono flex items-center gap-2 mb-1">
          <Cpu className="w-4 h-4 text-cyan-400" />
          POLICY BLAST RADIUS & IMPACT ANALYSIS SIMULATOR
        </h2>
        <p className="text-xs text-slate-400 mb-4">
          Test rule modifications safely in an isolated simulation sandbox before staging or committing to hardware.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div>
            <label className="text-slate-400 block mb-1">Select Target Policy Rule</label>
            <select
              value={selectedRuleId}
              onChange={(e) => setSelectedRuleId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
            >
              {activeRules.map((r) => (
                <option key={r.id} value={r.id}>
                  [{r.priority}] {r.name} ({r.action})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Proposed Action</label>
            <select
              value={proposedAction}
              onChange={(e) => setProposedAction(e.target.value as RuleAction)}
              className="w-full bg-slate-950 border border-slate-800 p-2 rounded text-slate-200"
            >
              <option value={RuleAction.ALLOW}>ALLOW</option>
              <option value={RuleAction.DENY}>DENY (Block)</option>
              <option value={RuleAction.REJECT}>REJECT (TCP RST / ICMP Unreachable)</option>
              <option value={RuleAction.RATE_LIMIT}>RATE_LIMIT</option>
              <option value={RuleAction.ISOLATE}>ISOLATE</option>
            </select>
          </div>

          <div className="flex items-end">
            <button
              onClick={handleRunSimulation}
              className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded transition flex items-center justify-center gap-2"
            >
              <Play className="w-4 h-4" />
              Execute Blast Simulation
            </button>
          </div>
        </div>
      </div>

      {/* Selected Rule Current Details */}
      {selectedRule && (
        <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono flex items-center justify-between text-slate-300">
          <div>
            <span className="text-slate-500">Current Scope: </span>
            <strong className="text-white">{selectedRule.name}</strong> •{' '}
            <span className="text-cyan-400">[{selectedRule.srcZone}] {selectedRule.srcAddress}</span>{' '}
            <ArrowRight className="inline w-3 h-3 mx-1 text-slate-500" />{' '}
            <span className="text-indigo-400">[{selectedRule.dstZone}] {selectedRule.dstAddress}:{selectedRule.dstPort || 'ANY'}</span>
          </div>
          <span className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded font-bold">
            Current Action: {selectedRule.action}
          </span>
        </div>
      )}

      {/* Simulation Results Dashboard */}
      {simulationResult && (
        <div className="space-y-4">
          {/* Admin Lockout Warning */}
          {simulationResult.managementAccessRisk && (
            <div className="bg-red-950/80 border-2 border-red-500 rounded-lg p-4 text-red-200 font-mono text-xs flex items-center gap-3 animate-pulse">
              <AlertTriangle className="w-6 h-6 text-red-400 shrink-0" />
              <div>
                <strong className="text-sm font-bold text-red-300 block">CRITICAL ALERT: POTENTIAL MANAGEMENT LOCKOUT DETECTED!</strong>
                <span>
                  This proposed policy modification blocks administrative access (SSH Port 22 or HTTPS Port 443) to Out-of-Band Management Controller. Safe rollback invariant will block this commit!
                </span>
              </div>
            </div>
          )}

          {/* Blast Radius Stat Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
              <span className="text-slate-500 block">Affected Active Flows</span>
              <strong className="text-xl font-bold text-amber-400">
                {simulationResult.affectedExistingFlows}
              </strong>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
              <span className="text-slate-500 block">Newly Blocked Flows</span>
              <strong className="text-xl font-bold text-red-400">
                {simulationResult.newlyBlockedFlows}
              </strong>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
              <span className="text-slate-500 block">Impacted Host Entities</span>
              <strong className="text-xl font-bold text-indigo-300">
                {simulationResult.affectedHosts.length}
              </strong>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
              <span className="text-slate-500 block">Impact Severity</span>
              <strong
                className={`text-xl font-bold ${
                  simulationResult.managementAccessRisk
                    ? 'text-red-400'
                    : simulationResult.impactSeverity === 'HIGH'
                    ? 'text-orange-400'
                    : 'text-emerald-400'
                }`}
              >
                {simulationResult.impactSeverity}
              </strong>
            </div>
          </div>

          {/* Detailed Impact Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <h3 className="font-bold text-white mb-2 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                Impacted Applications & Services
              </h3>
              <div className="space-y-1">
                {simulationResult.affectedServices.length > 0 ? (
                  simulationResult.affectedServices.map((app, i) => (
                    <div key={i} className="text-slate-300 bg-slate-950 p-1.5 rounded border border-slate-800">
                      • {app}
                    </div>
                  ))
                ) : (
                  <div className="text-slate-500">No active applications currently disrupted.</div>
                )}
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
              <h3 className="font-bold text-white mb-2 flex items-center gap-1.5">
                <Server className="w-3.5 h-3.5 text-indigo-400" />
                Impacted Hosts & Subnets
              </h3>
              <div className="space-y-1">
                {simulationResult.affectedHosts.length > 0 ? (
                  simulationResult.affectedHosts.map((host, i) => (
                    <div key={i} className="text-slate-300 bg-slate-950 p-1.5 rounded border border-slate-800">
                      • {host}
                    </div>
                  ))
                ) : (
                  <div className="text-slate-500">No active hosts disrupted.</div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
