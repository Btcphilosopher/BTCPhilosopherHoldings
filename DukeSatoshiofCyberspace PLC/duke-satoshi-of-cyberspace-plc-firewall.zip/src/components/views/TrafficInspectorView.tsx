/**
 * @file TrafficInspectorView.tsx
 * Duke Satoshi of Cyberspace PLC - Deep Traffic & Decision Context Inspector
 * Complete flow table with interactive deep-dive drawer for WHO, WHAT, WHERE, WHEN, HOW, WHY, RISK, POLICY, STATE.
 */

import React, { useState } from 'react';
import {
  Search,
  Filter,
  Shield,
  Activity,
  User,
  MapPin,
  Clock,
  Key,
  AlertTriangle,
  X,
  FileCode,
  Lock,
  Layers,
  Zap,
} from 'lucide-react';
import { DecisionContext, ConnectionTrackEntry, DecisionResult } from '../../types/firewall';
import { ConnectionTrackingEngine } from '../../core/state/conntrack';

interface TrafficInspectorViewProps {
  traffic: DecisionContext[];
  selectedFlow: DecisionContext | null;
  onSelectFlow: (flow: DecisionContext | null) => void;
}

export const TrafficInspectorView: React.FC<TrafficInspectorViewProps> = ({
  traffic,
  selectedFlow,
  onSelectFlow,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDecision, setFilterDecision] = useState<string>('ALL');
  const [filterZone, setFilterZone] = useState<string>('ALL');

  const filtered = traffic.filter((flow) => {
    if (filterDecision !== 'ALL' && flow.policy.decision !== filterDecision) return false;
    if (filterZone !== 'ALL' && flow.where.srcZone !== filterZone && flow.where.dstZone !== filterZone) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const matchSrc = flow.where.srcIp.toLowerCase().includes(q);
      const matchDst = flow.where.dstIp.toLowerCase().includes(q);
      const matchApp = flow.what.application.toLowerCase().includes(q);
      const matchUser = flow.who.userName?.toLowerCase().includes(q);
      const matchRule = flow.policy.matchedRuleName.toLowerCase().includes(q);
      return matchSrc || matchDst || matchApp || matchUser || matchRule;
    }
    return true;
  });

  const handleTerminateFlow = (connId: string) => {
    ConnectionTrackingEngine.terminateConnection(connId);
    onSelectFlow(null);
  };

  return (
    <div className="space-y-4">
      {/* Header & Filter Controls */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by IP, Application, Identity, or Policy..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950/60 border border-slate-800 px-3 py-1.5 rounded text-xs font-mono text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="text-slate-400">Decision:</span>
          <select
            value={filterDecision}
            onChange={(e) => setFilterDecision(e.target.value)}
            className="bg-slate-950 border border-slate-800 px-2.5 py-1.5 rounded text-slate-300 focus:outline-none"
          >
            <option value="ALL">All Decisions</option>
            <option value="ALLOW">ALLOW</option>
            <option value="DENY">DENY</option>
            <option value="RATE_LIMIT">RATE_LIMIT</option>
            <option value="ISOLATE">ISOLATE</option>
          </select>

          <span className="text-slate-400 ml-2">Zone:</span>
          <select
            value={filterZone}
            onChange={(e) => setFilterZone(e.target.value)}
            className="bg-slate-950 border border-slate-800 px-2.5 py-1.5 rounded text-slate-300 focus:outline-none"
          >
            <option value="ALL">All Zones</option>
            <option value="PUBLIC">PUBLIC</option>
            <option value="DMZ">DMZ</option>
            <option value="CORPORATE">CORPORATE</option>
            <option value="FINANCE">FINANCE</option>
            <option value="VAULT">VAULT</option>
            <option value="PRODUCTION">PRODUCTION</option>
            <option value="DATABASE">DATABASE</option>
            <option value="MANAGEMENT">MANAGEMENT</option>
            <option value="GUEST">GUEST</option>
            <option value="QUARANTINE">QUARANTINE</option>
          </select>

          <span className="text-slate-500 text-[11px] ml-2 font-mono">
            {filtered.length} flows loaded
          </span>
        </div>
      </div>

      {/* Main Flow Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto max-h-[600px]">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800 sticky top-0 z-10">
              <tr>
                <th className="py-2.5 px-3">Time</th>
                <th className="py-2.5 px-3">Source (Zone : IP)</th>
                <th className="py-2.5 px-3">Destination (Zone : IP : Port)</th>
                <th className="py-2.5 px-3">Proto</th>
                <th className="py-2.5 px-3">Application</th>
                <th className="py-2.5 px-3">Identity</th>
                <th className="py-2.5 px-3">State</th>
                <th className="py-2.5 px-3">Risk</th>
                <th className="py-2.5 px-3">Decision</th>
                <th className="py-2.5 px-3">Matched Policy</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.map((flow) => {
                const isSelected = selectedFlow?.connectionId === flow.connectionId;
                const isAllow = flow.policy.decision === 'ALLOW';
                return (
                  <tr
                    key={flow.connectionId}
                    onClick={() => onSelectFlow(flow)}
                    className={`cursor-pointer transition ${
                      isSelected
                        ? 'bg-cyan-950/40 border-l-4 border-cyan-400'
                        : 'hover:bg-slate-800/50'
                    }`}
                  >
                    <td className="py-2 px-3 text-slate-400">
                      {new Date(flow.timestamp).toISOString().slice(11, 19)}
                    </td>
                    <td className="py-2 px-3 text-slate-300">
                      <span className="text-[10px] text-cyan-400">[{flow.where.srcZone}]</span> {flow.where.srcIp}
                    </td>
                    <td className="py-2 px-3 text-slate-300">
                      <span className="text-[10px] text-indigo-400">[{flow.where.dstZone}]</span> {flow.where.dstIp}:{flow.what.dstPort}
                    </td>
                    <td className="py-2 px-3 text-slate-300">{flow.what.protocol}</td>
                    <td className="py-2 px-3 text-slate-200 font-semibold">{flow.what.application}</td>
                    <td className="py-2 px-3 text-slate-400 truncate max-w-[120px]">
                      {flow.who.userName || 'Unauthenticated'}
                    </td>
                    <td className="py-2 px-3">
                      <span className="text-[10px] text-slate-400 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                        {flow.state.connectionState}
                      </span>
                    </td>
                    <td className="py-2 px-3">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          flow.risk.level === 'CRITICAL'
                            ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                            : flow.risk.level === 'HIGH'
                            ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                            : flow.risk.level === 'MEDIUM'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                            : 'bg-slate-800 text-slate-300'
                        }`}
                      >
                        {flow.risk.totalScore}
                      </span>
                    </td>
                    <td className="py-2 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isAllow
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : 'bg-red-500/10 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {flow.policy.decision}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-slate-400 truncate max-w-xs">
                      {flow.policy.matchedRuleName}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Flow Deep-Dive Inspector Drawer */}
      {selectedFlow && (
        <div className="bg-slate-900 border border-cyan-500/40 rounded-lg p-5 shadow-2xl relative">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-cyan-400" />
              <div>
                <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
                  DECISION CONTEXT: {selectedFlow.connectionId}
                </h3>
                <p className="text-xs text-slate-400 font-mono">
                  {new Date(selectedFlow.timestamp).toISOString()} • Flow state: {selectedFlow.state.connectionState}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => handleTerminateFlow(selectedFlow.connectionId)}
                className="px-3 py-1 bg-red-950/60 hover:bg-red-900 border border-red-700/60 text-red-300 text-xs font-mono rounded transition"
              >
                Terminate Flow
              </button>
              <button
                onClick={() => onSelectFlow(null)}
                className="text-slate-400 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* 9 Dimensions Decision Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
            {/* WHO */}
            <div className="bg-slate-950/80 border border-slate-800/80 rounded p-3 space-y-1.5">
              <div className="text-cyan-400 font-bold flex items-center gap-1.5">
                <User className="w-3.5 h-3.5" /> WHO (Identity & Posture)
              </div>
              <div className="text-slate-300">User: <strong className="text-white">{selectedFlow.who.userName}</strong></div>
              <div className="text-slate-400">ID: {selectedFlow.who.userId}</div>
              <div className="text-slate-400">Directory: {selectedFlow.who.identityProvider}</div>
              <div className="text-slate-400">
                MFA Verified: {selectedFlow.who.mfaVerified ? <span className="text-emerald-400">YES (Hardware Token)</span> : <span className="text-amber-400">NO</span>}
              </div>
              <div className="text-slate-400">Roles: {selectedFlow.who.roles?.join(', ')}</div>
              {selectedFlow.who.certificateThumbprint && (
                <div className="text-[10px] text-slate-500 truncate">Cert: {selectedFlow.who.certificateThumbprint}</div>
              )}
            </div>

            {/* WHAT */}
            <div className="bg-slate-950/80 border border-slate-800/80 rounded p-3 space-y-1.5">
              <div className="text-indigo-400 font-bold flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" /> WHAT (Application & Protocol)
              </div>
              <div className="text-slate-300">Application: <strong className="text-white">{selectedFlow.what.application}</strong></div>
              <div className="text-slate-400">Protocol: {selectedFlow.what.protocol}</div>
              <div className="text-slate-400">Destination Port: {selectedFlow.what.dstPort}</div>
              <div className="text-slate-400">
                Sensitivity:{' '}
                <span className="px-1.5 py-0.5 bg-purple-500/10 text-purple-300 border border-purple-500/30 rounded text-[10px]">
                  {selectedFlow.what.dataSensitivity}
                </span>
              </div>
              {selectedFlow.how.sni && (
                <div className="text-slate-400 truncate">TLS SNI: <span className="text-cyan-300">{selectedFlow.how.sni}</span></div>
              )}
            </div>

            {/* WHERE */}
            <div className="bg-slate-950/80 border border-slate-800/80 rounded p-3 space-y-1.5">
              <div className="text-emerald-400 font-bold flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5" /> WHERE (Topology & Zones)
              </div>
              <div className="text-slate-300">
                Source: <span className="text-amber-300">[{selectedFlow.where.srcZone}]</span> {selectedFlow.where.srcIp}
              </div>
              <div className="text-slate-300">
                Destination: <span className="text-emerald-300">[{selectedFlow.where.dstZone}]</span> {selectedFlow.where.dstIp}
              </div>
              <div className="text-slate-400">Ingress IF: {selectedFlow.where.srcInterface}</div>
              <div className="text-slate-400">Egress IF: {selectedFlow.where.dstInterface}</div>
              <div className="text-slate-400">Geo Origin: {selectedFlow.where.geoSource}</div>
            </div>

            {/* WHEN */}
            <div className="bg-slate-950/80 border border-slate-800/80 rounded p-3 space-y-1.5">
              <div className="text-amber-400 font-bold flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" /> WHEN (Temporal Context)
              </div>
              <div className="text-slate-300">Day: {selectedFlow.when.dayOfWeek}</div>
              <div className="text-slate-400">Timestamp: {new Date(selectedFlow.when.timestamp).toLocaleTimeString()}</div>
              <div className="text-slate-400">
                Business Hours: {selectedFlow.when.businessHours ? <span className="text-emerald-400">Standard Business Window</span> : <span className="text-amber-400">Off-Hours Operation</span>}
              </div>
            </div>

            {/* HOW */}
            <div className="bg-slate-950/80 border border-slate-800/80 rounded p-3 space-y-1.5">
              <div className="text-blue-400 font-bold flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5" /> HOW (Device & Encryption)
              </div>
              <div className="text-slate-300">Device Trust: <strong className="text-white">{selectedFlow.how.deviceTrust}</strong></div>
              <div className="text-slate-400">Device ID: {selectedFlow.how.deviceId || 'Unattested Device'}</div>
              <div className="text-slate-400">TLS Record: {selectedFlow.how.tlsVersion || 'Plaintext / Wire Protocol'}</div>
            </div>

            {/* WHY */}
            <div className="bg-slate-950/80 border border-slate-800/80 rounded p-3 space-y-1.5">
              <div className="text-purple-400 font-bold flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5" /> WHY (Business Intent)
              </div>
              <div className="text-slate-300">{selectedFlow.why.intent}</div>
              <div className="text-slate-400">
                Cryptographic Attestation Required:{' '}
                {selectedFlow.why.justificationRequired ? (
                  <span className="text-red-400 font-bold">YES</span>
                ) : (
                  <span className="text-slate-500">NO</span>
                )}
              </div>
            </div>
          </div>

          {/* RISK DECOMPOSITION & POLICY EXPLANATION */}
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Risk Breakdown */}
            <div className="bg-slate-950/80 border border-slate-800/80 rounded p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-red-400 font-bold text-xs font-mono flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" /> DECOMPOSED RISK SCORE: {selectedFlow.risk.totalScore}/100 [{selectedFlow.risk.level}]
                </span>
              </div>
              <div className="space-y-1 text-xs font-mono text-slate-300">
                {selectedFlow.risk.factors.length > 0 ? (
                  selectedFlow.risk.factors.map((f, i) => (
                    <div key={i} className="text-amber-300/90 flex items-center gap-1.5">
                      <span className="text-red-400">•</span> {f}
                    </div>
                  ))
                ) : (
                  <div className="text-emerald-400">No elevated risk factors detected (baseline benign).</div>
                )}
              </div>
            </div>

            {/* Policy Decision & Explanation */}
            <div className="bg-slate-950/80 border border-slate-800/80 rounded p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-emerald-400 font-bold text-xs font-mono flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5" /> POLICY ENFORCEMENT: {selectedFlow.policy.decision}
                </span>
              </div>
              <div className="text-xs font-mono space-y-1">
                <div className="text-slate-300">Matched Rule: <strong className="text-white">{selectedFlow.policy.matchedRuleName}</strong></div>
                <div className="text-slate-400">Rule Action: {selectedFlow.policy.ruleAction}</div>
                <div className="text-cyan-300/90 italic mt-2 border-t border-slate-800/60 pt-1.5">
                  &ldquo;{selectedFlow.policy.explanation}&rdquo;
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
