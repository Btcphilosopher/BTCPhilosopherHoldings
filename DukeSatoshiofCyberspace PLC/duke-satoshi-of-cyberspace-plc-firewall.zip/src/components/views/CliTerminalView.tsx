/**
 * @file CliTerminalView.tsx
 * Duke Satoshi of Cyberspace PLC - Interactive Sovereign CLI Shell
 * Full command execution environment with command history, tab-complete hints, and fast execution.
 */

import React, { useState, useRef, useEffect } from 'react';
import { Terminal, CornerDownLeft, Trash2 } from 'lucide-react';
import { CliEngine, CliCommandResult } from '../../core/cli/cliEngine';

export const CliTerminalView: React.FC = () => {
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<CliCommandResult[]>([
    {
      command: 'duke-firewall status',
      output: CliEngine.execute('status').output,
    },
  ]);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    if (input.trim() === 'clear' || input.trim() === 'duke-firewall clear') {
      setHistory([]);
      setInput('');
      return;
    }

    const res = CliEngine.execute(input);
    setHistory((prev) => [...prev, res]);
    setInput('');
  };

  const handleRunPreset = (cmd: string) => {
    const res = CliEngine.execute(cmd);
    setHistory((prev) => [...prev, res]);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 font-mono text-xs">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-cyan-400" />
          <strong className="text-white">SOVEREIGN CLI TERMINAL [ADMIN SESSION]</strong>
        </div>

        {/* Quick Command Buttons */}
        <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
          <button
            onClick={() => handleRunPreset('status')}
            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded"
          >
            status
          </button>
          <button
            onClick={() => handleRunPreset('policy list')}
            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded"
          >
            policy list
          </button>
          <button
            onClick={() => handleRunPreset('traffic')}
            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded"
          >
            traffic
          </button>
          <button
            onClick={() => handleRunPreset('alerts')}
            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-red-300 rounded"
          >
            alerts
          </button>
          <button
            onClick={() => handleRunPreset('benchmark')}
            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded"
          >
            benchmark
          </button>
          <button
            onClick={() => handleRunPreset('test')}
            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-emerald-300 rounded"
          >
            test
          </button>
          <button
            onClick={() => handleRunPreset('help')}
            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded"
          >
            help
          </button>
          <button
            onClick={() => setHistory([])}
            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded flex items-center gap-1"
          >
            <Trash2 className="w-3 h-3" /> clear
          </button>
        </div>
      </div>

      {/* Terminal Screen */}
      <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 font-mono text-xs min-h-[500px] flex flex-col justify-between">
        <div className="space-y-4 overflow-y-auto max-h-[550px] pr-2">
          <div className="text-slate-500">
            Duke Satoshi of Cyberspace PLC Secure Management Subsystem [Version 4.8.2-enterprise]<br />
            Type &ldquo;help&rdquo; or &ldquo;duke-firewall status&rdquo; to begin. All commands are audited.
          </div>

          {history.map((item, index) => (
            <div key={index} className="space-y-1">
              <div className="text-cyan-400 flex items-center gap-2">
                <span className="text-slate-500">root@duke-satoshi:~$</span>
                <strong>{item.command}</strong>
              </div>
              <pre
                className={`whitespace-pre-wrap ${
                  item.isError ? 'text-red-400' : 'text-slate-300'
                }`}
              >
                {item.output}
              </pre>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSubmit} className="mt-4 pt-3 border-t border-slate-800 flex items-center gap-2">
          <span className="text-cyan-400 font-bold">root@duke-satoshi:~$</span>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Enter CLI command (e.g. status, policy validate, benchmark)..."
            className="flex-1 bg-transparent text-white focus:outline-none font-mono text-xs placeholder-slate-600"
            autoFocus
          />
          <button type="submit" className="p-1.5 text-slate-400 hover:text-cyan-400 transition">
            <CornerDownLeft className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
