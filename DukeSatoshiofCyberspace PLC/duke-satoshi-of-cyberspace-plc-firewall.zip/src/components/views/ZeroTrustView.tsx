/**
 * @file ZeroTrustView.tsx
 * Duke Satoshi of Cyberspace PLC - Zero-Trust Identity & Device Posture Directory
 * Continuous identity verification, cryptographic hardware tokens, and TPM 2.0 device posture attestations.
 */

import React from 'react';
import {
  Users,
  ShieldCheck,
  Laptop,
  Key,
  CheckCircle,
  XCircle,
  Lock,
} from 'lucide-react';
import { ZeroTrustEngine, SubjectIdentity, DevicePosture } from '../../core/identity/zeroTrust';

export const ZeroTrustView: React.FC = () => {
  const identities = ZeroTrustEngine.getIdentities();
  const devices = ZeroTrustEngine.getDevices();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-white font-mono flex items-center gap-2">
            <Users className="w-4 h-4 text-cyan-400" />
            ZERO-TRUST IDENTITY & CRYPTOGRAPHIC DEVICE ATTESTATION
          </h2>
          <p className="text-xs text-slate-400">
            Explicit identity-aware access. Never trust, always verify every subject, machine token, and device posture.
          </p>
        </div>
      </div>

      {/* Identities Directory */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
        <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-3 flex items-center gap-2">
          <Key className="w-3.5 h-3.5 text-amber-400" />
          Sovereign Identities & Role-Based Access Directory ({identities.length} Accounts)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {identities.map((user) => (
            <div
              key={user.id}
              className="bg-slate-950 border border-slate-800 rounded-lg p-4 font-mono text-xs space-y-2"
            >
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <div>
                  <strong className="text-white text-sm">{user.username}</strong>
                  <div className="text-[11px] text-cyan-400">{user.email}</div>
                </div>
                <span className="px-2 py-0.5 bg-purple-500/10 text-purple-300 border border-purple-500/30 rounded text-[10px] font-bold">
                  {user.department}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300 pt-1">
                <div>
                  <span className="text-slate-500 block">MFA Hardware Token:</span>
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" /> FIDO2 WebAuthn Enrolled
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Session Validity:</span>
                  <span className="text-slate-300">Valid</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/60">
                <span className="text-slate-500 text-[10px] block mb-1">Assigned Security Roles:</span>
                <div className="flex flex-wrap gap-1.5">
                  {user.roles.map((r) => (
                    <span
                      key={r}
                      className="px-1.5 py-0.5 bg-slate-900 text-slate-300 border border-slate-700 rounded text-[10px]"
                    >
                      {r}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Device Posture Attestations */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
        <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-3 flex items-center gap-2">
          <Laptop className="w-3.5 h-3.5 text-indigo-400" />
          Hardware Attested Devices & Host Health ({devices.length} Nodes)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Hostname</th>
                <th className="py-2.5 px-3">Operating System</th>
                <th className="py-2.5 px-3">Trust Level</th>
                <th className="py-2.5 px-3">TPM 2.0</th>
                <th className="py-2.5 px-3">Secure Boot</th>
                <th className="py-2.5 px-3">Disk Encrypted</th>
                <th className="py-2.5 px-3">EDR Agent</th>
                <th className="py-2.5 px-3">Cert Thumbprint</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {devices.map((dev) => (
                <tr key={dev.deviceId} className="hover:bg-slate-800/40 transition">
                  <td className="py-2.5 px-3 font-semibold text-white">{dev.hostname}</td>
                  <td className="py-2.5 px-3 text-slate-400">{dev.os}</td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        dev.trustLevel === 'HARDWARE_ATTESTED'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                          : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                      }`}
                    >
                      {dev.trustLevel}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">YES</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">YES</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">YES</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">HEALTHY</td>
                  <td className="py-2.5 px-3 text-slate-500 truncate max-w-xs">{dev.clientCertThumbprint}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
