/**
 * @file PolicyGraphView.tsx
 * Duke Satoshi of Cyberspace PLC - Microsegmentation Matrix & Zone Trust Boundaries
 * Comprehensive N-by-N cross-zone segmentation matrix with path evaluation and boundary rules.
 */

import React, { useState } from 'react';
import {
  GitGraph,
  Shield,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Info,
  Layers,
} from 'lucide-react';
import { NetworkZone, FirewallRule, RuleAction } from '../../types/firewall';
import { PolicyGraphEngine } from '../../core/policy/policyGraph';
import { ConfigManager } from '../../core/config/configManager';
import { ConnectionTrackingEngine } from '../../core/state/conntrack';

export const PolicyGraphView: React.FC = () => {
  const allZones = Object.values(NetworkZone);
  const rules = ConfigManager.getActiveRules();
  const connections = ConnectionTrackingEngine.getAllConnections();
  const graph = PolicyGraphEngine.buildGraph(rules, connections);

  const [selectedCell, setSelectedCell] = useState<{ src: NetworkZone; dst: NetworkZone } | null>(null);

  const selectedEdge = selectedCell
    ? graph.edges.find((e) => e.source === selectedCell.src && e.target === selectedCell.dst)
    : null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-white font-mono flex items-center gap-2">
            <GitGraph className="w-4 h-4 text-cyan-400" />
            ZERO-TRUST MICROSEGMENTATION MATRIX & ZONE BOUNDARIES
          </h2>
          <p className="text-xs text-slate-400">
            Bidirectional perimeter matrix. All inter-zone traversals are blocked by default unless explicitly permitted by high-assurance policy.
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono">
          <span className="flex items-center gap-1 text-emerald-400">
            <span className="w-2.5 h-2.5 bg-emerald-500 rounded-sm" /> Explicitly Permitted
          </span>
          <span className="flex items-center gap-1 text-slate-500">
            <span className="w-2.5 h-2.5 bg-slate-800 rounded-sm" /> Default Blocked
          </span>
        </div>
      </div>

      {/* Cross-Zone Matrix Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 overflow-x-auto">
        <table className="w-full text-center text-xs font-mono border-collapse">
          <thead>
            <tr>
              <th className="p-2 text-left text-slate-400 bg-slate-950/60 border border-slate-800">
                SOURCE \ DEST
              </th>
              {allZones.map((dst) => (
                <th
                  key={dst}
                  className="p-2 text-[10px] text-slate-300 font-semibold bg-slate-950 border border-slate-800 uppercase"
                >
                  {dst.slice(0, 5)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {allZones.map((src) => (
              <tr key={src}>
                <th className="p-2 text-left text-[11px] font-semibold text-slate-300 bg-slate-950 border border-slate-800">
                  {src}
                </th>
                {allZones.map((dst) => {
                  const entry = graph.matrix[src]?.[dst];
                  const isAllowed = entry?.allowed;
                  const isSelected = selectedCell?.src === src && selectedCell?.dst === dst;

                  return (
                    <td
                      key={dst}
                      onClick={() => setSelectedCell({ src, dst })}
                      className={`p-2 border border-slate-800 cursor-pointer transition text-[10px] font-bold ${
                        isSelected
                          ? 'ring-2 ring-cyan-400 z-10'
                          : ''
                      } ${
                        src === dst
                          ? 'bg-slate-800/40 text-slate-400'
                          : isAllowed
                          ? 'bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-400'
                          : 'bg-slate-950/90 hover:bg-slate-850 text-slate-600'
                      }`}
                    >
                      {src === dst ? (
                        'INTRA'
                      ) : isAllowed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 mx-auto text-emerald-400" />
                      ) : (
                        <XCircle className="w-3.5 h-3.5 mx-auto text-slate-700" />
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Selected Boundary Inspector */}
      {selectedCell && (
        <div className="bg-slate-900 border border-cyan-500/40 rounded-lg p-4 space-y-3 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="font-bold text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-cyan-400" />
              ZONE BOUNDARY: <span className="text-amber-400">[{selectedCell.src}]</span> → <span className="text-emerald-400">[{selectedCell.dst}]</span>
            </h3>
            <span
              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                graph.matrix[selectedCell.src]?.[selectedCell.dst]?.allowed
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-red-500/20 text-red-400 border border-red-500/40'
              }`}
            >
              {graph.matrix[selectedCell.src]?.[selectedCell.dst]?.allowed ? 'POLICY ALLOWED' : 'POLICY BLOCKED'}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <span className="text-slate-500 block mb-1">Active Flow Metrics:</span>
              <p className="text-slate-200">
                Active Connections: <strong className="text-cyan-400">{selectedEdge?.activeConnections || 0}</strong>
              </p>
              <p className="text-slate-400 text-[11px] mt-1">
                Source Zone Trust: {PolicyGraphEngine.ZONE_DEFINITIONS[selectedCell.src]?.trustLevel}/100 • Dest Zone Trust: {PolicyGraphEngine.ZONE_DEFINITIONS[selectedCell.dst]?.trustLevel}/100
              </p>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <span className="text-slate-500 block mb-1">Matched Policy Rules:</span>
              {selectedEdge && selectedEdge.rules.length > 0 ? (
                selectedEdge.rules.map((r, i) => (
                  <div key={i} className="text-cyan-300">
                    • Rule: <strong>{r.name}</strong> (Action: {r.action})
                  </div>
                ))
              ) : (
                <div className="text-slate-500">No explicit allow rules found. Implicit default-deny applies.</div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
