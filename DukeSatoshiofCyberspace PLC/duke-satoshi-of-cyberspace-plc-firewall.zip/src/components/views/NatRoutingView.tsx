/**
 * @file NatRoutingView.tsx
 * Duke Satoshi of Cyberspace PLC - NAT Rules, Routing & Interface Telemetry
 * SNAT, DNAT, Port Forwarding, Longest Prefix Match (LPM) routing table, and 802.1Q interfaces.
 */

import React, { useState } from 'react';
import {
  Share2,
  Network,
  Activity,
  ArrowRight,
  Shield,
  Layers,
} from 'lucide-react';
import { NatEngine } from '../../core/network/natEngine';
import { RoutingEngine } from '../../core/network/routingEngine';
import { NatRule, RouteEntry, NetworkInterface } from '../../types/firewall';

export const NatRoutingView: React.FC = () => {
  const [natRules] = useState<NatRule[]>(NatEngine.getRules());
  const [routes] = useState<RouteEntry[]>(RoutingEngine.getRoutes());
  const [interfaces] = useState<NetworkInterface[]>(RoutingEngine.getInterfaces());

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-white font-mono flex items-center gap-2">
            <Share2 className="w-4 h-4 text-cyan-400" />
            NETWORK ADDRESS TRANSLATION (NAT) & ROUTING SUBSYSTEM
          </h2>
          <p className="text-xs text-slate-400">
            State-consistent source/destination NAT, port forward translation, and Longest Prefix Match kernel routing table.
          </p>
        </div>
      </div>

      {/* Network Interfaces Status */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
        <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-3 flex items-center gap-2">
          <Activity className="w-3.5 h-3.5 text-cyan-400" />
          Physical & VLAN Virtual Network Interfaces ({interfaces.length} Links)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono text-xs">
          {interfaces.map((iface) => (
            <div
              key={iface.id}
              className="bg-slate-950 border border-slate-800 rounded p-3 space-y-1.5"
            >
              <div className="flex items-center justify-between">
                <strong className="text-cyan-300 font-bold">{iface.name}</strong>
                <span className="px-1.5 py-0.2 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 rounded text-[10px]">
                  {iface.status}
                </span>
              </div>
              <div className="text-slate-400 text-[11px]">IP: <span className="text-white">{iface.ipAddress}</span></div>
              <div className="text-slate-400 text-[11px]">Zone: <span className="text-indigo-400">[{iface.zone}]</span></div>
              {iface.vlanId && (
                <div className="text-slate-400 text-[11px]">802.1Q VLAN Tag: <span className="text-amber-400">{iface.vlanId}</span></div>
              )}
              <div className="pt-2 border-t border-slate-800/60 flex justify-between text-[10px] text-slate-500">
                <span>RX: {(iface.rxBytes / 1024 / 1024).toFixed(1)} MB</span>
                <span>TX: {(iface.txBytes / 1024 / 1024).toFixed(1)} MB</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* NAT Rules Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
        <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-3 flex items-center gap-2">
          <Shield className="w-3.5 h-3.5 text-amber-400" />
          Network Address Translation (NAT) Rules
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">Rule Name</th>
                <th className="py-2.5 px-3">Source Zone</th>
                <th className="py-2.5 px-3">Dest Zone</th>
                <th className="py-2.5 px-3">Original Target</th>
                <th className="py-2.5 px-3">Translated Target</th>
                <th className="py-2.5 px-3">Hits</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {natRules.map((rule) => (
                <tr key={rule.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-2 px-3">
                    <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 rounded text-[10px] font-bold">
                      {rule.type}
                    </span>
                  </td>
                  <td className="py-2 px-3 font-semibold text-white">{rule.name}</td>
                  <td className="py-2 px-3 text-cyan-400">[{rule.srcZone}]</td>
                  <td className="py-2 px-3 text-indigo-400">[{rule.dstZone}]</td>
                  <td className="py-2 px-3 text-slate-300">
                    {rule.originalSrc || rule.originalDst} {rule.originalPort ? `:${rule.originalPort}` : ''}
                  </td>
                  <td className="py-2 px-3 text-emerald-400 font-bold">
                    {rule.translatedSrc || rule.translatedDst} {rule.translatedPort ? `:${rule.translatedPort}` : ''}
                  </td>
                  <td className="py-2 px-3 text-slate-400">{rule.hits.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Routing Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
        <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider mb-3 flex items-center gap-2">
          <Network className="w-3.5 h-3.5 text-indigo-400" />
          Kernel Longest Prefix Match (LPM) Routing Table
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Destination CIDR</th>
                <th className="py-2.5 px-3">Gateway IP</th>
                <th className="py-2.5 px-3">Interface</th>
                <th className="py-2.5 px-3">Metric</th>
                <th className="py-2.5 px-3">Policy Route (PBR)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {routes.map((rt) => (
                <tr key={rt.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-2 px-3 font-bold text-cyan-300">{rt.destinationCidr}</td>
                  <td className="py-2 px-3 text-slate-300">{rt.gatewayIp}</td>
                  <td className="py-2 px-3 text-white font-semibold">{rt.interfaceId}</td>
                  <td className="py-2 px-3 text-slate-400">{rt.metric}</td>
                  <td className="py-2 px-3">
                    {rt.isPolicyRoute ? (
                      <span className="px-1.5 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded text-[10px]">
                        PBR Enforced
                      </span>
                    ) : (
                      <span className="text-slate-600">Standard LPM</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
