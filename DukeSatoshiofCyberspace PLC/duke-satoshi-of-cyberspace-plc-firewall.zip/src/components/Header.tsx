/**
 * @file Header.tsx
 * Duke Satoshi of Cyberspace PLC - Sovereign Control Banner
 */

import React from 'react';
import {
  Shield,
  ShieldAlert,
  Radio,
  Server,
  AlertTriangle,
  Play,
  Pause,
  Terminal,
  Activity,
  Zap,
} from 'lucide-react';
import { IpsEngine } from '../core/security/ipsEngine';
import { ConfigManager } from '../core/config/configManager';
import { PipelineOrchestrator, TrafficScenario } from '../core/telemetry/syntheticTraffic';
import { AuditLogger } from '../core/telemetry/auditLogger';

interface HeaderProps {
  onOpenCli: () => void;
  onOpenPacketCraft: () => void;
  scenario: TrafficScenario;
  onSelectScenario: (scen: TrafficScenario) => void;
  rollbackStatus: { active: boolean; secondsRemaining: number };
  onConfirmCommit: () => void;
  onRollbackNow: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenCli,
  onOpenPacketCraft,
  scenario,
  onSelectScenario,
  rollbackStatus,
  onConfirmCommit,
  onRollbackNow,
}) => {
  const [killSwitch, setKillSwitch] = React.useState(IpsEngine.isKillSwitchActive());
  const [isRunning, setIsRunning] = React.useState(PipelineOrchestrator.isPipelineRunning());

  const handleToggleKillSwitch = () => {
    const next = !killSwitch;
    IpsEngine.setEmergencyKillSwitch(next);
    setKillSwitch(next);
    AuditLogger.log({
      actor: 'lord.satoshi',
      action: 'EMERGENCY_KILL_SWITCH',
      resourceType: 'PERIMETER_GATEWAY',
      resourceId: 'ALL_UNTRUSTED_ZONES',
      status: 'SUCCESS',
      ipAddress: '10.0.0.5',
    });
  };

  const handleToggleRunning = () => {
    const next = !isRunning;
    PipelineOrchestrator.toggleRunning(next);
    setIsRunning(next);
  };

  const scenarios: TrafficScenario[] = [
    {
      id: 'scen_enterprise_normal',
      name: 'Normal Sovereign Banking Flow',
      description: 'Standard ledger transfers, corporate HTTPS, database queries',
      intensity: 'NORMAL',
      attackType: 'NONE',
    },
    {
      id: 'scen_port_scan',
      name: 'APT Reconnaissance: Port Scan',
      description: 'External scanning probe across multiple ports',
      intensity: 'HEAVY',
      attackType: 'PORT_SCAN',
    },
    {
      id: 'scen_syn_flood',
      name: 'DDoS Attack: SYN Flood on DMZ',
      description: 'High-rate SYN packet flood targeting public ingress VIP',
      intensity: 'HEAVY',
      attackType: 'SYN_FLOOD',
    },
    {
      id: 'scen_dns_tunnel',
      name: 'Covert Data Exfiltration: DNS Tunnel',
      description: 'High-entropy subdomain queries attempting data leakage',
      intensity: 'NORMAL',
      attackType: 'DNS_TUNNEL',
    },
    {
      id: 'scen_vault_exfil',
      name: 'Zero-Trust Breach: Lateral Vault Probe',
      description: 'Unauthenticated guest client probing Sovereign Vault HSM',
      intensity: 'NORMAL',
      attackType: 'VAULT_EXFILTRATION',
    },
  ];

  return (
    <header className="border-b border-slate-800 bg-slate-950/95 sticky top-0 z-40 backdrop-blur-md">
      {/* Top Banner for Commit Rollback Timer if active */}
      {rollbackStatus.active && (
        <div className="bg-amber-950/90 border-b border-amber-600/60 px-4 py-2 flex items-center justify-between text-xs text-amber-200 animate-pulse">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span className="font-semibold tracking-wider">CANDIDATE CONFIGURATION PENDING CONFIRMATION:</span>
            <span>
              Automatic safety rollback in <strong className="text-amber-300 font-mono text-sm">{rollbackStatus.secondsRemaining}s</strong>
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onConfirmCommit}
              className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded text-xs transition"
            >
              Confirm Permanent
            </button>
            <button
              onClick={onRollbackNow}
              className="px-3 py-1 bg-red-700 hover:bg-red-600 text-white font-medium rounded text-xs transition"
            >
              Revert Now
            </button>
          </div>
        </div>
      )}

      {/* Main Bar */}
      <div className="px-4 lg:px-6 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Identity & Crest */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-500/20 via-slate-900 to-cyan-500/20 border border-amber-500/40 flex items-center justify-center shadow-lg shadow-amber-500/5">
            <Shield className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold tracking-tight text-white font-mono">
                DUKE SATOSHI OF CYBERSPACE PLC
              </h1>
              <span className="px-2 py-0.5 text-[10px] uppercase font-mono tracking-widest bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded">
                SOVEREIGN FIREWALL
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono flex items-center gap-2">
              <span>Policy Engine: v4.8.2-enterprise</span>
              <span className="text-slate-600">•</span>
              <span className="text-cyan-400/90 font-sans italic">
                &ldquo;Every connection is a decision. Every policy is observable.&rdquo;
              </span>
            </p>
          </div>
        </div>

        {/* Controls & Actions */}
        <div className="flex items-center flex-wrap gap-2.5 text-xs">
          {/* Scenario Selector */}
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1.5 rounded-lg">
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-slate-400 text-[11px]">Scenario:</span>
            <select
              value={scenario.id}
              onChange={(e) => {
                const found = scenarios.find((s) => s.id === e.target.value);
                if (found) onSelectScenario(found);
              }}
              className="bg-transparent text-slate-200 font-mono text-[11px] focus:outline-none cursor-pointer"
            >
              {scenarios.map((s) => (
                <option key={s.id} value={s.id} className="bg-slate-900 text-slate-200">
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          {/* Engine Play/Pause */}
          <button
            onClick={handleToggleRunning}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border font-mono transition text-[11px] ${
              isRunning
                ? 'bg-slate-900 text-emerald-400 border-emerald-500/30 hover:bg-slate-800'
                : 'bg-amber-950/40 text-amber-300 border-amber-600/40 hover:bg-amber-900/40'
            }`}
            title={isRunning ? 'Pause synthetic traffic generator' : 'Resume synthetic traffic'}
          >
            {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isRunning ? 'PIPELINE ACTIVE' : 'PAUSED'}</span>
          </button>

          {/* Raw Packet Injector Button */}
          <button
            onClick={onOpenPacketCraft}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-cyan-500/30 font-mono transition text-[11px]"
          >
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            <span>INJECT PACKET</span>
          </button>

          {/* Interactive CLI Button */}
          <button
            onClick={onOpenCli}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 font-mono transition text-[11px]"
          >
            <Terminal className="w-3.5 h-3.5 text-slate-400" />
            <span>CLI SHELL</span>
          </button>

          {/* Emergency Kill Switch */}
          <button
            onClick={handleToggleKillSwitch}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg font-mono font-semibold transition text-[11px] border ${
              killSwitch
                ? 'bg-red-600 hover:bg-red-500 text-white border-red-400 animate-pulse shadow-lg shadow-red-600/30'
                : 'bg-slate-900 hover:bg-red-950/50 text-slate-300 hover:text-red-300 border-slate-800 hover:border-red-700/50'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>{killSwitch ? 'KILL SWITCH ENGAGED' : 'EMERGENCY KILL SWITCH'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
