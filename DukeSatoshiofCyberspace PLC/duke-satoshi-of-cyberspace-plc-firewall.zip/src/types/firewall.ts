/**
 * @file firewall.ts
 * Duke Satoshi of Cyberspace PLC Firewall - Core Domain Types & Definitions
 * "Every connection is a decision. Every decision has a policy. Every policy is observable."
 */

export enum Protocol {
  TCP = 'TCP',
  UDP = 'UDP',
  ICMP = 'ICMP',
  ICMPV6 = 'ICMPv6',
  ARP = 'ARP',
  UNKNOWN = 'UNKNOWN',
}

export enum NetworkZone {
  PUBLIC = 'PUBLIC',
  DMZ = 'DMZ',
  CORPORATE = 'CORPORATE',
  DEVELOPMENT = 'DEVELOPMENT',
  PRODUCTION = 'PRODUCTION',
  FINANCE = 'FINANCE',
  ADMINISTRATION = 'ADMINISTRATION',
  DATABASE = 'DATABASE',
  VAULT = 'VAULT',
  MANAGEMENT = 'MANAGEMENT',
  GUEST = 'GUEST',
  QUARANTINE = 'QUARANTINE',
}

export enum ConnectionState {
  NEW = 'NEW',
  ESTABLISHED = 'ESTABLISHED',
  RELATED = 'RELATED',
  CLOSING = 'CLOSING',
  CLOSED = 'CLOSED',
  INVALID = 'INVALID',
}

export enum TcpFlag {
  FIN = 'FIN',
  SYN = 'SYN',
  RST = 'RST',
  PSH = 'PSH',
  ACK = 'ACK',
  URG = 'URG',
}

export enum RuleAction {
  ALLOW = 'ALLOW',
  DENY = 'DENY',
  REJECT = 'REJECT',
  LOG = 'LOG',
  RATE_LIMIT = 'RATE_LIMIT',
  MARK = 'MARK',
  ROUTE = 'ROUTE',
  ISOLATE = 'ISOLATE',
}

export enum DecisionResult {
  ALLOW = 'ALLOW',
  DENY = 'DENY',
  CHALLENGE = 'CHALLENGE',
  RATE_LIMIT = 'RATE_LIMIT',
  ISOLATE = 'ISOLATE',
  LOG = 'LOG',
  ESCALATE = 'ESCALATE',
}

export enum AnomalyLevel {
  NORMAL = 'NORMAL',
  UNUSUAL = 'UNUSUAL',
  SUSPICIOUS = 'SUSPICIOUS',
  CRITICAL = 'CRITICAL',
}

export enum Severity {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL',
}

export interface NetworkInterface {
  id: string;
  name: string;
  macAddress: string;
  ipAddress: string;
  subnetMask: string;
  zone: NetworkZone;
  vlanId?: number;
  status: 'UP' | 'DOWN';
  rxPackets: number;
  txPackets: number;
  rxBytes: number;
  txBytes: number;
  dropPackets: number;
}

export interface RawPacket {
  id: string;
  timestamp: number;
  interfaceId: string;
  rawHex: string;
  sizeBytes: number;
  parsed?: ParsedPacket;
  isValid: boolean;
  validationError?: string;
}

export interface ParsedPacket {
  ethernet: {
    srcMac: string;
    dstMac: string;
    etherType: string;
    vlanId?: number;
  };
  ip: {
    version: 4 | 6;
    srcIp: string;
    dstIp: string;
    ttl: number;
    protocol: Protocol;
    checksum: number;
    checksumValid: boolean;
    headerLength: number;
    totalLength: number;
    isFragmented: boolean;
    fragmentOffset?: number;
  };
  transport?: {
    srcPort: number;
    dstPort: number;
    flags?: TcpFlag[];
    seqNumber?: number;
    ackNumber?: number;
    checksumValid: boolean;
    windowSize?: number;
  };
  application?: {
    identifiedApp: string;
    protocolName: string;
    metadata: Record<string, string | number | boolean>;
    sni?: string;
    dnsQuery?: string;
    httpMethod?: string;
    httpPath?: string;
  };
  payloadPreview: string;
}

export interface ConnectionTrackEntry {
  id: string;
  key: string; // srcIp:srcPort -> dstIp:dstPort:proto
  protocol: Protocol;
  srcIp: string;
  srcPort: number;
  dstIp: string;
  dstPort: number;
  srcZone: NetworkZone;
  dstZone: NetworkZone;
  state: ConnectionState;
  tcpState?: string;
  startTime: number;
  lastSeenTime: number;
  packetsOut: number;
  packetsIn: number;
  bytesOut: number;
  bytesIn: number;
  timeoutSeconds: number;
  associatedRuleId?: string;
  natMapping?: {
    type: 'SNAT' | 'DNAT' | 'MASQUERADE';
    translatedIp: string;
    translatedPort: number;
  };
  application: string;
  identity?: string;
  device?: string;
  riskScore: number;
  decision: DecisionResult;
}

export interface FirewallRule {
  id: string;
  name: string;
  description: string;
  priority: number;
  enabled: boolean;
  srcZone: NetworkZone | 'ANY';
  dstZone: NetworkZone | 'ANY';
  srcAddress: string; // CIDR, IP or 'ANY'
  dstAddress: string; // CIDR, IP or 'ANY'
  srcInterface?: string;
  dstInterface?: string;
  protocol: Protocol | 'ANY';
  srcPort?: string; // 'ANY' or '1024-65535' or '443'
  dstPort?: string;
  application: string; // 'ANY', 'HTTPS', 'SSH', 'DNS', 'POSTGRESQL', etc.
  identityRequired?: boolean;
  requiredGroup?: string;
  minDeviceTrust?: 'ANY' | 'CORPORATE_MANAGED' | 'HARDWARE_TOKEN_VERIFIED';
  action: RuleAction;
  rateLimitPerSec?: number;
  logging: boolean;
  owner: string;
  createdAt: number;
  modifiedAt: number;
  expiresAt?: number; // Automatic expiry
  hitCount: number;
  lastHitAt?: number;
}

export interface DecisionContext {
  connectionId: string;
  timestamp: number;
  who: {
    userId?: string;
    userName?: string;
    identityProvider?: string;
    mfaVerified: boolean;
    roles: string[];
    certificateThumbprint?: string;
  };
  what: {
    protocol: Protocol;
    dstPort: number;
    application: string;
    payloadClassification?: string;
    dataSensitivity?: 'PUBLIC' | 'CONFIDENTIAL' | 'RESTRICTED' | 'SOVEREIGN_VAULT';
  };
  where: {
    srcIp: string;
    dstIp: string;
    srcInterface: string;
    dstInterface: string;
    srcZone: NetworkZone;
    dstZone: NetworkZone;
    vlan?: number;
    geoSource?: string;
    geoDestination?: string;
  };
  when: {
    timestamp: number;
    dayOfWeek: string;
    businessHours: boolean;
  };
  how: {
    tlsVersion?: string;
    cipherSuite?: string;
    sni?: string;
    ja3Fingerprint?: string;
    deviceTrust: 'UNTRUSTED' | 'KNOWN' | 'CORPORATE_MANAGED' | 'HARDWARE_ATTESTED';
    deviceId?: string;
  };
  why: {
    intent: string;
    justificationRequired: boolean;
  };
  risk: {
    totalScore: number; // 0 - 100
    level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    breakdown: {
      identityRisk: number;
      deviceRisk: number;
      networkRisk: number;
      applicationRisk: number;
      behaviouralDeviation: number;
      threatIntelHits: number;
      policyViolationWeight: number;
    };
    factors: string[];
  };
  state: {
    connectionState: ConnectionState;
    packetsInFlow: number;
    bytesInFlow: number;
    baselineAnomaly: AnomalyLevel;
  };
  policy: {
    matchedRuleId: string;
    matchedRuleName: string;
    ruleAction: RuleAction;
    decision: DecisionResult;
    explanation: string;
  };
}

export interface SecurityEvent {
  id: string;
  timestamp: number;
  title: string;
  eventType: 'PORT_SCAN' | 'SYN_FLOOD' | 'UNAUTHORIZED_ZONE_TRAVERSAL' | 'DNS_TUNNEL' | 'MALFORMED_PACKET' | 'THREAT_INTEL_MATCH' | 'ZERO_TRUST_VIOLATION' | 'RATE_LIMIT_EXCEEDED' | 'ANOMALOUS_TRAFFIC_SPIKE';
  severity: Severity;
  confidence: number; // 0-100%
  sourceIp: string;
  sourcePort?: number;
  destinationIp: string;
  destinationPort?: number;
  srcZone: NetworkZone;
  dstZone: NetworkZone;
  associatedRuleId?: string;
  evidence: Record<string, any>;
  mitigationTaken?: 'DROPPED' | 'QUARANTINED' | 'ISOLATED' | 'RATE_LIMITED' | 'ALERTED_ONLY';
  resolved: boolean;
}

export interface ThreatIndicator {
  id: string;
  type: 'IP' | 'DOMAIN' | 'CIDR' | 'SHA256' | 'JA3';
  value: string;
  category: 'C2_BOTNET' | 'APT_SOVEREIGN' | 'EXPLOIT_SCANNER' | 'MALICIOUS_DNS' | 'PHISHING' | 'TOR_EXIT_NODE';
  reputationScore: number; // 0-100 (100 = definitely malicious)
  sourceFeed: string;
  confidence: number;
  addedAt: number;
  expiresAt: number;
  active: boolean;
}

export interface RouteEntry {
  id: string;
  destinationCidr: string;
  gatewayIp: string;
  interfaceId: string;
  metric: number;
  isPolicyRoute?: boolean;
  protocolFilter?: Protocol;
  zone?: NetworkZone;
}

export interface NatRule {
  id: string;
  name: string;
  type: 'SNAT' | 'DNAT' | 'PORT_FORWARD' | 'MASQUERADE';
  srcZone: NetworkZone;
  dstZone: NetworkZone;
  originalSrc?: string;
  originalDst?: string;
  originalPort?: number;
  translatedSrc?: string;
  translatedDst?: string;
  translatedPort?: number;
  enabled: boolean;
  hits: number;
}

export interface ClusterNode {
  id: string;
  name: string;
  role: 'PRIMARY' | 'SECONDARY' | 'WITNESS';
  status: 'ONLINE' | 'STANDBY' | 'DEGRADED' | 'OFFLINE';
  ipAddress: string;
  version: string;
  configHash: string;
  policyVersion: number;
  connectionCount: number;
  cpuPercent: number;
  memoryPercent: number;
  networkThroughputMbps: number;
  syncLatencyMs: number;
  lastHeartbeat: number;
}

export interface AuditLogEntry {
  id: string;
  timestamp: number;
  actor: string;
  action: 'RULE_CREATED' | 'RULE_CHANGED' | 'RULE_DELETED' | 'POLICY_COMMITTED' | 'CONFIG_ROLLBACK' | 'EMERGENCY_KILL_SWITCH' | 'HOST_QUARANTINED' | 'FAILOVER' | 'ADMIN_LOGIN' | 'THREAT_FEED_UPDATED';
  resourceType: string;
  resourceId: string;
  changes?: { before: any; after: any };
  status: 'SUCCESS' | 'FAILURE';
  ipAddress: string;
  hash: string; // Cryptographic chain hash
}

export interface TelemetrySnapshot {
  timestamp: number;
  packetsPerSec: number;
  bytesPerSec: number;
  connectionsPerSec: number;
  activeConnections: number;
  droppedPackets: number;
  allowedFlows: number;
  blockedFlows: number;
  idsAlertsCount: number;
  ipsMitigationsCount: number;
  cpuUsagePercent: number;
  memoryUsagePercent: number;
  avgLatencyUs: number;
}

export interface PolicySimulationRequest {
  proposedRule: FirewallRule;
  simulationSampleCount: number;
}

export interface PolicySimulationResult {
  ruleId: string;
  ruleName: string;
  action: RuleAction;
  affectedExistingFlows: number;
  newlyAllowedFlows: number;
  newlyBlockedFlows: number;
  affectedHosts: string[];
  affectedServices: string[];
  affectedZones: { from: NetworkZone; to: NetworkZone }[];
  impactSeverity: 'LOW' | 'MEDIUM' | 'HIGH' | 'BREAKING_MANAGEMENT';
  managementAccessRisk: boolean;
  summary: string;
}

export interface DnsRecord {
  id: string;
  timestamp: number;
  clientIp: string;
  clientZone: NetworkZone;
  domain: string;
  queryType: 'A' | 'AAAA' | 'TXT' | 'CNAME' | 'MX' | 'PTR' | 'ANY';
  responseIp?: string;
  status: 'ALLOWED' | 'BLOCKED_SINKHOLE' | 'SUSPICIOUS_DGA' | 'RATE_LIMITED';
  category: 'LEGITIMATE' | 'MALICIOUS_REPUTATION' | 'DNS_TUNNEL_EXFIL' | 'CUSTOM_BLOCKLIST';
  policyApplied: string;
  latencyMs: number;
}
