# Aureom.AI BorderGate — Architecture & Integration Contracts

Aureom.AI BorderGate is an enterprise Android passport-control eGate kiosk platform engineered for airport immigration, automated borders, and eGates. It includes a traveller touch interface, a physical gate hardware simulator, and an authenticated companion officer console.

---

## 1. Core Architecture & Workflow

```
[Start] → [Scan Passport] → [Read Chip (NFC/PACE)] → [Capture Live Face] → [Multi-Factor Processing] → [Clearance Decision]
                                                                                                               │
                                                                       ┌───────────────────────────────────────┴──────────────────────────────┐
                                                                       ▼                                                                      ▼
                                                            [Approved: Gate Opens]                                               [Refer to Officer Desk 4]
```

---

## 2. Documented Integration Contracts (Services & Interfaces)

### 2.1 Passport Optical Capture & MRZ (`PassportCaptureService`, `MrzParser`)
- **ICAO Doc 9303 Compliance:** Parses TD3 (Passports, 2x44) and TD1 (ID cards, 3x30).
- **Check-Digit Verification:** Evaluates weighted modulo 10 checksums (`weights: 7, 3, 1`) over Document Number, Date of Birth, Date of Expiry, Optional Data, and Composite checksum.
- **Date Ambiguity Handling:** 2-digit century pivot windows according to ICAO specifications.
- **Quality Gates:** Evaluates blur score (cutoff: 0.70), glare detection, and chevron framing before triggering OCR.
- **Authenticity Separation:** Passing MRZ check digits does not constitute proof that a passport is authentic.

### 2.2 Electronic Passport Contactless Reader (`PassportChipReader`)
- **Hardware Protocol:** Standard Android `NfcAdapter` / ISO 14443 Type A/B.
- **Authentication Handshake:** Supports PACE (Password Authenticated Connection Establishment) with ECDH GM and BAC fallback using MRZ key (`DocNumber + DOB + Expiry`).
- **Data Groups Read:**
  - `DG1`: Machine Readable Zone duplicate.
  - `DG2`: Biometric Facial Photograph (ISO/IEC 19794-5).
  - `DG14/DG15`: Active Authentication & Chip Authentication public keys.
  - `SOD`: Document Security Object containing SHA-256 hashes of all Data Groups.
- **Passive Authentication:** Validates SOD signature against National Public Key Directory (PKD) CSCA root certificates.
- **Distinct Statuses:**
  - `SUCCESS`
  - `INTERRUPTED` (Premature document removal)
  - `UNTRUSTED_SIGNER` (Signer certificate not recognized in PKD)
  - `DATA_HASH_MISMATCH` (Corrupted or altered Data Group)
  - `UNAVAILABLE` (Revocation directory or PKD service unreachable)

### 2.3 Biometric Services (`FaceCaptureService`, `FaceComparisonService`, `PresentationAttackDetectionService`)
- **Presentation Attack Detection (PAD):** Evaluates ISO/IEC 30107 compliance for screen replay, 2D printed photograph, and 3D silicone mask attacks. Kept strictly distinct from face comparison.
- **Face Comparison:** 1:1 biometric comparison between live camera probe and eChip DG2 photograph.
  - Matcher Version: `Aureom-FacialMatch-v4.1.2-ICAO`
  - Threshold Policy: `UKBF-BIOMETRIC-EVAL-POL-2026.2` (Default operational threshold: 75.0%)
  - *Explicit Standard:* Similarity score is reported as a geometric distance metric, never as a probability of identity.
- **One-Person Framing:** Real-time detection stops capture if multiple individuals enter the camera frustum.

### 2.4 Border Decision Authority (`BorderDecisionService`)
- Evaluates document authenticity, PKI trust, liveness, biometric similarity, document expiration, and national immigration policy.
- Outputs explicit outcomes:
  - `APPROVED`
  - `REFER_TO_OFFICER`
  - `RETRY_CAPTURE`
  - `SERVICE_UNAVAILABLE`
  - `REJECTED`
- Returns bound `PassageDecision` with:
  - `sessionId` & `gateId`
  - `singleUseToken`: Nonce consumed on gate transit; rejects replays.
  - `validUntilEpochMs`: 30-second bounded expiry window.
  - Neutral traveller wording (`travellerPublicSummary`) that conceals sensitive security decision details.
  - Internal reason code (`internalReasonCode`) for authorized border staff.

### 2.5 Physical Gate Controller (`GateController`)
- **Hardware Boundary:** Android sends high-level bounded requests (`authorizePassage(sessionId, token, timeoutMs)`). The physical PLC / MCU owns actuator timing, interlocks, obstruction response, and failsafe egress.
- **Transit Sequence:**
  1. Entry barrier moves: `CLOSED` → `OPENING` → `FULLY_OPEN`
  2. Passenger crosses Beam A (Light curtain): Occupancy = `OCCUPIED_ENTERING`
  3. Passenger reaches chamber: Beam B active, Beam A cleared: Occupancy = `OCCUPIED_IN_CHAMBER`
  4. Entry barrier closes behind passenger: `CLOSED`
  5. Exit barrier moves: `CLOSED` → `OPENING` → `FULLY_OPEN`
  6. Passenger crosses Beam C: Occupancy = `OCCUPIED_EXITING`
  7. Passenger departs: Beam C cleared: Occupancy = `CLEAR`
  8. Exit barrier closes. Transit confirmed!
- **Safety Interlocks:**
  - Obstruction: Safety light curtain rebound immediately moves flaps to `OBSTRUCTED_REOPENING`.
  - Tailgating: Secondary occupant detection triggers security alarm.
  - E-Stop: Physical emergency stop releases all barriers to `FULLY_OPEN` for immediate failsafe egress.

### 2.6 Privacy, Redaction & Session Isolation (`AuditRepository`)
- **No Residual Biometrics:** Live probes, DG2 bitmaps, and memory caches are completely cleared when a session terminates or times out.
- **Redacted Operational Records:** Room database stores anonymized records with 9-digit passport numbers masked (`98*****02`) and names protected.

---

## 3. Demonstration Scenarios (Selectable via Top Bar)

| Scenario # | Title | Expected Flow & Outcome |
|---|---|---|
| **1** | Standard Clearance | Valid UK/FR/JP passport → PACE read → Biometrics match → Gate opens → Transit confirmed |
| **2** | Unreadable MRZ | Corrupted check-digits or scanner glare → Guided prompt to reposition passport |
| **3** | NFC Interruption | Premature removal of document during chip read → Referral to Officer Desk 4 |
| **4** | Untrusted Signer | CSCA root certificate not in National PKD trust store → Referral with code `UNTRUSTED_DOCUMENT_SIGNER` |
| **5** | Biometric Mismatch | Live face similarity below operational threshold (51% < 75%) → Referral to Desk 4 |
| **6** | Service Outage | Border decision service unreachable → Polite assistance screen with code `BORDER_SERVICE_OUTAGE` |
| **7** | Expired Passage Auth | 30s clearance TTL expires before passenger enters gate corridor → Single-use token invalidated |
| **8** | Obstructed Gate | Flap motion interrupted by safety light curtain → Automatic flap rebound & reopening |
| **9** | Multi-Person Detection | Companion steps into camera frame → Capture halted with prompt for single occupant |
| **10** | Officer Resolution | Referred case inspected on Officer Console → Supervisor overrides clearance with logged justification |

---

## 4. Setup & Running in Emulator / Device

1. **Launch Applet:** The application launches into the Traveller Kiosk in airport dark mode.
2. **Switch Workspaces:** Use the top bar buttons to switch between **Kiosk**, **Gate Sim**, and **Officer Console**.
3. **Switch Scenarios:** Use the **Scenario** dropdown to load any of the 10 demonstration scenarios.
4. **Multilingual Audio:** Tap the speaker icon to toggle spoken speech guidance (supports English, French, Spanish, German, Japanese, Arabic).
5. **Run Tests:** Run `./gradlew testDebugUnitTest` or `gradle :app:testDebugUnitTest` to execute the full validation suite.
