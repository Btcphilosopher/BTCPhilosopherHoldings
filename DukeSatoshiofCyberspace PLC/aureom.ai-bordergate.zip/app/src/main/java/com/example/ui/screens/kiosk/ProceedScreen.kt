package com.example.ui.screens.kiosk

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ActiveSessionState
import com.example.data.model.GateHardwareState
import com.example.ui.components.GateBarrierGraphic
import com.example.ui.components.KioskProgressBar
import com.example.ui.theme.AirportNavyDark
import com.example.ui.theme.AirportNavyElevated
import com.example.ui.theme.AirportNavySurface
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenBg

@Composable
fun ProceedScreen(
    sessionState: ActiveSessionState,
    gateState: GateHardwareState,
    onCompleteSession: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AirportNavyDark)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            KioskProgressBar(currentStep = sessionState.step)

            // Clearance Approved Header Banner
            Box(
                modifier = Modifier
                    .padding(top = 8.dp)
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(SuccessGreenBg)
                    .border(2.dp, SuccessGreen, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Approved",
                    tint = SuccessGreen,
                    modifier = Modifier.size(36.dp)
                )
            }

            Text(
                text = "CLEARANCE APPROVED",
                color = SuccessGreen,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 8.dp)
            )

            Text(
                text = "Please collect your passport. The gate barrier is opening for you.",
                color = PureWhite,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )
        }

        // Live Gate Corridor Transit Simulation Graphic
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "GATE CORRIDOR HARDWARE (EGATE-LHR-T5-04)",
                color = CyanPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 4.dp)
            )

            GateBarrierGraphic(
                gateState = gateState,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Single-Use Token & Security Binding Display
        Card(
            colors = CardDefaults.cardColors(containerColor = AirportNavySurface),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AirportNavyElevated, RoundedCornerShape(10.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Single-Use Passage Token", color = Color.Gray, fontSize = 10.sp)
                    Text(
                        text = sessionState.decision?.singleUseToken ?: "TOKEN-CONFIRMED",
                        color = PureWhite,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = if (sessionState.decision?.isConsumed == true) "TOKEN CONSUMED" else "VALID (30s)",
                    color = if (sessionState.decision?.isConsumed == true) Color.LightGray else SuccessGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Complete & Reset Action
        Button(
            onClick = onCompleteSession,
            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen, contentColor = AirportNavyDark),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("proceed_finish_button")
        ) {
            Icon(imageVector = Icons.Default.MeetingRoom, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Transit Finished — Reset Session",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
