package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class OfficerRole {
    OPERATOR,
    SUPERVISOR,
    TECHNICIAN,
    AUDITOR,
    SYSTEM
}

@Entity(tableName = "audit_events")
data class AuditRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val sessionId: String,
    val gateId: String,
    val role: OfficerRole,
    val action: String,
    val detailsRedacted: String,
    val reasonCode: String? = null,
    val officerBadgeId: String? = null,
    val outcome: String
)
