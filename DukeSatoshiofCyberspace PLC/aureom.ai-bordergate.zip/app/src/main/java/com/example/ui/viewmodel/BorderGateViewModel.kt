package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.fixtures.SpecimenPassport
import com.example.data.fixtures.SpecimenPassports
import com.example.data.local.BorderGateDatabase
import com.example.data.model.ActiveSessionState
import com.example.data.model.AuditRecord
import com.example.data.model.BarrierPosition
import com.example.data.model.CaptureStatus
import com.example.data.model.ChipData
import com.example.data.model.DecisionOutcome
import com.example.data.model.DemoScenario
import com.example.data.model.FaceVerificationSession
import com.example.data.model.GateHardwareState
import com.example.data.model.GateOccupancy
import com.example.data.model.KioskLanguage
import com.example.data.model.KioskStep
import com.example.data.model.OfficerRole
import com.example.data.model.PassageDecision
import com.example.data.model.ReasonCode
import com.example.domain.services.AudioGuidanceService
import com.example.domain.services.AuditRepository
import com.example.domain.services.BorderDecisionService
import com.example.domain.services.DocumentAuthenticationResult
import com.example.domain.services.DocumentAuthenticationService
import com.example.domain.services.FaceCaptureService
import com.example.domain.services.FaceComparisonService
import com.example.domain.services.GateController
import com.example.domain.services.PassportCaptureService
import com.example.domain.services.PassportChipReader
import com.example.domain.services.PresentationAttackDetectionService
import com.example.domain.services.SimulatedFaceCaptureService
import com.example.domain.services.SimulatedFaceComparisonService
import com.example.domain.services.SimulatedGateController
import com.example.domain.services.SimulatedPadService
import com.example.domain.services.SimulatedPassportCaptureService
import com.example.domain.services.SimulatedPassportChipReader
import com.example.domain.services.StandardAuditRepository
import com.example.domain.services.StandardBorderDecisionService
import com.example.domain.services.StandardDocumentAuthenticationService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppWorkspace {
    KIOSK,
    GATE_SIMULATOR,
    OFFICER_CONSOLE
}

class BorderGateViewModel(application: Application) : AndroidViewModel(application) {

    // Services
    val passportCaptureService: PassportCaptureService = SimulatedPassportCaptureService()
    val passportChipReader: PassportChipReader = SimulatedPassportChipReader()
    val docAuthService: DocumentAuthenticationService = StandardDocumentAuthenticationService()
    val faceCaptureService: FaceCaptureService = SimulatedFaceCaptureService()
    val faceComparisonService: FaceComparisonService = SimulatedFaceComparisonService()
    val padService: PresentationAttackDetectionService = SimulatedPadService()
    val borderDecisionService: BorderDecisionService = StandardBorderDecisionService()
    val gateController: GateController = SimulatedGateController(viewModelScope)
    val audioGuidanceService: AudioGuidanceService = AudioGuidanceService(application)

    private val db = BorderGateDatabase.getInstance(application)
    val auditRepository: AuditRepository = StandardAuditRepository(db.auditDao())

    // Active UI Workspace (Kiosk, Gate Simulator, Officer Console)
    private val _currentWorkspace = MutableStateFlow(AppWorkspace.KIOSK)
    val currentWorkspace: StateFlow<AppWorkspace> = _currentWorkspace.asStateFlow()

    // Traveller Session State
    private val _sessionState = MutableStateFlow(
        ActiveSessionState(sessionId = generateSessionId())
    )
    val sessionState: StateFlow<ActiveSessionState> = _sessionState.asStateFlow()

    // Gate Hardware State
    val gateState: StateFlow<GateHardwareState> = gateController.hardwareState

    // Officer Workspace State
    private val _activeOfficerRole = MutableStateFlow(OfficerRole.SUPERVISOR)
    val activeOfficerRole: StateFlow<OfficerRole> = _activeOfficerRole.asStateFlow()

    private val _selectedSessionForInspection = MutableStateFlow<ActiveSessionState?>(null)
    val selectedSessionForInspection: StateFlow<ActiveSessionState?> = _selectedSessionForInspection.asStateFlow()

    // Audit logs flow from Room
    val auditLogs: StateFlow<List<AuditRecord>> = auditRepository.allAuditRecords.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Current selected specimen for simulation
    private val _currentSpecimen = MutableStateFlow<SpecimenPassport>(SpecimenPassports.DOE_UK)
    val currentSpecimen: StateFlow<SpecimenPassport> = _currentSpecimen.asStateFlow()

    private var sessionTimeoutJob: Job? = null

    init {
        // Initial system startup audit
        viewModelScope.launch {
            auditRepository.recordAudit(
                sessionId = "SYS-BOOT",
                gateId = "EGATE-LHR-T5-04",
                role = OfficerRole.SYSTEM,
                action = "SYSTEM_STARTUP",
                rawDetails = "BorderGate Kiosk System Initialized. Algorithms: ISO-9303 MRZ, ISO-30107 PAD, ICAO FaceMatch.",
                reasonCode = "STARTUP_OK",
                officerBadgeId = "SYS-DAEMON",
                outcome = "ONLINE"
            )
        }
    }

    private fun generateSessionId(): String = "SESS-${UUID.randomUUID().toString().take(8).uppercase()}"

    fun selectWorkspace(workspace: AppWorkspace) {
        _currentWorkspace.value = workspace
    }

    fun setOfficerRole(role: OfficerRole) {
        _activeOfficerRole.value = role
    }

    fun setLanguage(language: KioskLanguage) {
        _sessionState.value = _sessionState.value.copy(language = language)
        if (_sessionState.value.audioGuidanceEnabled) {
            val welcomeText = when (language) {
                KioskLanguage.EN -> "Welcome to automated passport control."
                KioskLanguage.FR -> "Bienvenue au contrôle automatisé des passeports."
                KioskLanguage.ES -> "Bienvenido al control automático de pasaportes."
                KioskLanguage.DE -> "Willkommen bei der automatisierten Passkontrolle."
                KioskLanguage.JA -> "自動出入国管理ゲートへようこそ。"
                KioskLanguage.AR -> "مرحبًا بكم في البوابة الإلكترونية لمراقبة الجوازات."
            }
            audioGuidanceService.speak(welcomeText, language)
        }
    }

    fun toggleAudioGuidance() {
        val enabled = !_sessionState.value.audioGuidanceEnabled
        _sessionState.value = _sessionState.value.copy(audioGuidanceEnabled = enabled)
        if (!enabled) audioGuidanceService.stop()
    }

    fun loadScenario(scenario: DemoScenario) {
        // Apply scenario preset
        val specimen = when (scenario) {
            DemoScenario.SCENARIO_1_HAPPY_PATH -> SpecimenPassports.DOE_UK
            DemoScenario.SCENARIO_2_UNREADABLE_MRZ -> SpecimenPassports.GRUBER_CORRUPT_MRZ
            DemoScenario.SCENARIO_3_NFC_INTERRUPT -> SpecimenPassports.DOE_UK
            DemoScenario.SCENARIO_4_UNTRUSTED_SIGNER -> SpecimenPassports.ROSTOVA_UNTRUSTED_SIGNER
            DemoScenario.SCENARIO_5_FACE_REFERRAL -> SpecimenPassports.SMITH_MISMATCH_FACE
            DemoScenario.SCENARIO_6_SERVICE_OUTAGE -> SpecimenPassports.DOE_UK
            DemoScenario.SCENARIO_7_EXPIRED_AUTH -> SpecimenPassports.DOE_UK
            DemoScenario.SCENARIO_8_GATE_OBSTRUCTION -> SpecimenPassports.DOE_UK
            DemoScenario.SCENARIO_9_MULTI_PERSON -> SpecimenPassports.DUPONT_FR
            DemoScenario.SCENARIO_10_OFFICER_ASSISTED -> SpecimenPassports.SMITH_MISMATCH_FACE
        }
        _currentSpecimen.value = specimen

        startNewSession(scenario)
    }

    fun startNewSession(scenario: DemoScenario = _sessionState.value.activeScenario) {
        sessionTimeoutJob?.cancel()
        val newSessionId = generateSessionId()

        // Privacy rule: wipe all previous session data completely
        _sessionState.value = ActiveSessionState(
            sessionId = newSessionId,
            step = KioskStep.WELCOME,
            language = _sessionState.value.language,
            activeScenario = scenario,
            audioGuidanceEnabled = _sessionState.value.audioGuidanceEnabled
        )

        speakGuidance("Please step forward and place your passport on the scanner.")
    }

    fun onProceedFromWelcome() {
        _sessionState.value = _sessionState.value.copy(step = KioskStep.PASSPORT_SCAN)
        speakGuidance("Place your open passport photo page face-down on the illuminated reader.")
    }

    fun setSpecimen(specimen: SpecimenPassport) {
        _currentSpecimen.value = specimen
    }

    // Step 1: Capture Passport Document & MRZ
    fun executePassportCapture() {
        viewModelScope.launch {
            val scenario = _sessionState.value.activeScenario
            val isScenario2 = scenario == DemoScenario.SCENARIO_2_UNREADABLE_MRZ

            val result = passportCaptureService.captureDocument(
                specimen = _currentSpecimen.value,
                forceBlurOrGlare = isScenario2
            )

            _sessionState.value = _sessionState.value.copy(passportResult = result)

            if (result.status == CaptureStatus.SUCCESS && result.mrzData?.checkResult?.allValid == true) {
                // Record capture audit (redacted)
                auditRepository.recordAudit(
                    sessionId = _sessionState.value.sessionId,
                    gateId = "EGATE-LHR-T5-04",
                    role = OfficerRole.SYSTEM,
                    action = "MRZ_CAPTURE_SUCCESS",
                    rawDetails = "DocNum: ${result.mrzData.documentNumber}, Country: ${result.mrzData.issuingCountry}, DOB: ${result.mrzData.parsedBirthDate}",
                    reasonCode = "MRZ_VALID",
                    outcome = "SUCCESS"
                )

                delay(600)
                _sessionState.value = _sessionState.value.copy(step = KioskStep.CHIP_READ)
                executeChipRead()
            } else {
                auditRepository.recordAudit(
                    sessionId = _sessionState.value.sessionId,
                    gateId = "EGATE-LHR-T5-04",
                    role = OfficerRole.SYSTEM,
                    action = "MRZ_CAPTURE_RETRY",
                    rawDetails = "Status: ${result.status}, Glare: ${result.quality.glareDetected}",
                    reasonCode = "MRZ_UNREADABLE",
                    outcome = "RETRY"
                )
                speakGuidance("Unable to read passport clearly. Please adjust document alignment.")
            }
        }
    }

    // Step 2: Read eChip via NFC
    fun executeChipRead() {
        viewModelScope.launch {
            speakGuidance("Reading electronic chip. Please keep your passport still.")
            val scenario = _sessionState.value.activeScenario
            val isScenario3 = scenario == DemoScenario.SCENARIO_3_NFC_INTERRUPT
            val isScenario4 = scenario == DemoScenario.SCENARIO_4_UNTRUSTED_SIGNER

            val chipData = passportChipReader.readChip(
                specimen = _currentSpecimen.value,
                simulateInterruption = isScenario3,
                simulateUntrustedSigner = isScenario4
            )

            _sessionState.value = _sessionState.value.copy(chipResult = chipData)

            if (isScenario3) {
                // Route to officer assistance
                handleFailureOutcome(
                    outcome = DecisionOutcome.REFER_TO_OFFICER,
                    publicMsg = "Please take your documents and proceed to Border Control Officer Desk 4.",
                    reason = ReasonCode.CHIP_READ_INTERRUPTED
                )
                return@launch
            }

            auditRepository.recordAudit(
                sessionId = _sessionState.value.sessionId,
                gateId = "EGATE-LHR-T5-04",
                role = OfficerRole.SYSTEM,
                action = "CHIP_READ_COMPLETED",
                rawDetails = "Protocol: ${chipData.protocolUsed}, PassiveAuth: ${chipData.passiveAuthStatus}, SOD: ${chipData.sodIssuerDn}",
                reasonCode = chipData.passiveAuthStatus.name,
                outcome = chipData.chipReadStatus.name
            )

            delay(600)
            _sessionState.value = _sessionState.value.copy(step = KioskStep.FACE_CAPTURE)
            executeFaceCapture()
        }
    }

    // Step 3: Biometric Face Capture & PAD (Liveness)
    fun executeFaceCapture() {
        viewModelScope.launch {
            speakGuidance("Please look directly at the camera. Remove hats or glasses.")
            delay(1200)

            val scenario = _sessionState.value.activeScenario
            val isScenario9 = scenario == DemoScenario.SCENARIO_9_MULTI_PERSON
            val isScenario5 = scenario == DemoScenario.SCENARIO_5_FACE_REFERRAL

            val captureMetrics = faceCaptureService.performCapture(simulateMultiPerson = isScenario9)

            if (isScenario9) {
                handleFailureOutcome(
                    outcome = DecisionOutcome.RETRY_CAPTURE,
                    publicMsg = "Only one person permitted in the gate corridor. Please ensure companions step back.",
                    reason = ReasonCode.MULTIPLE_PERSONS_IN_FRAME
                )
                return@launch
            }

            // Liveness check (Presentation Attack Detection)
            val padAssessment = padService.evaluateLiveness()

            // Face comparison against DG2
            val isMatch = _currentSpecimen.value.isBiometricMatch && !isScenario5
            val comparisonResult = faceComparisonService.compareFaces(isSpecimenMatch = isMatch)

            val bioSession = FaceVerificationSession(
                captureMetrics = captureMetrics,
                padAssessment = padAssessment,
                comparisonResult = comparisonResult
            )
            _sessionState.value = _sessionState.value.copy(biometricResult = bioSession)

            auditRepository.recordAudit(
                sessionId = _sessionState.value.sessionId,
                gateId = "EGATE-LHR-T5-04",
                role = OfficerRole.SYSTEM,
                action = "BIOMETRIC_COMPARISON",
                rawDetails = "Score: ${comparisonResult.similarityScore}%, Match: ${comparisonResult.isMatch}, PAD: ${padAssessment.padScore}",
                reasonCode = if (comparisonResult.isMatch) "BIO_MATCH_OK" else "BIO_MISMATCH",
                outcome = if (comparisonResult.isMatch) "MATCH" else "NO_MATCH"
            )

            delay(700)
            _sessionState.value = _sessionState.value.copy(step = KioskStep.PROCESSING)
            executeFinalDecision()
        }
    }

    // Step 4: Decision Service Evaluation
    private fun executeFinalDecision() {
        viewModelScope.launch {
            speakGuidance("Evaluating clearance. Please wait.")
            delay(1000)

            val scenario = _sessionState.value.activeScenario
            val isScenario6 = scenario == DemoScenario.SCENARIO_6_SERVICE_OUTAGE

            val mrz = _sessionState.value.passportResult?.mrzData
            val chip = _sessionState.value.chipResult
            val bio = _sessionState.value.biometricResult

            val authResult = docAuthService.authenticateDocument(mrz, chip)

            val decision = borderDecisionService.evaluatePassage(
                sessionId = _sessionState.value.sessionId,
                gateId = "EGATE-LHR-T5-04",
                mrzData = mrz,
                chipData = chip,
                biometricSession = bio,
                authResult = authResult,
                simulateServiceOutage = isScenario6
            )

            _sessionState.value = _sessionState.value.copy(decision = decision)

            auditRepository.recordAudit(
                sessionId = _sessionState.value.sessionId,
                gateId = "EGATE-LHR-T5-04",
                role = OfficerRole.SYSTEM,
                action = "BORDER_DECISION",
                rawDetails = "Outcome: ${decision.outcome}, Reason: ${decision.internalReasonCode}, Token: ${decision.singleUseToken}",
                reasonCode = decision.internalReasonCode.name,
                outcome = decision.outcome.name
            )

            when (decision.outcome) {
                DecisionOutcome.APPROVED -> {
                    val isScenario7 = scenario == DemoScenario.SCENARIO_7_EXPIRED_AUTH
                    if (isScenario7) {
                        // Mark decision expired immediately for Scenario 7
                        val expiredDecision = decision.copy(validUntilEpochMs = System.currentTimeMillis() - 1000)
                        _sessionState.value = _sessionState.value.copy(decision = expiredDecision)
                        handleFailureOutcome(
                            outcome = DecisionOutcome.REFER_TO_OFFICER,
                            publicMsg = "Passage authorization has timed out. Please proceed to Desk 4.",
                            reason = ReasonCode.AUTHORISATION_EXPIRED
                        )
                        return@launch
                    }

                    _sessionState.value = _sessionState.value.copy(step = KioskStep.PROCEED)
                    speakGuidance("Clearance approved. Please collect your passport and enter the gate.")

                    // Authorize gate and trigger passage
                    val tokenValid = borderDecisionService.validateToken(decision.singleUseToken, decision)
                    if (tokenValid) {
                        gateController.authorizePassage(_sessionState.value.sessionId, decision.singleUseToken)
                        val isScenario8 = scenario == DemoScenario.SCENARIO_8_GATE_OBSTRUCTION
                        gateController.simulatePassageSequence(withObstruction = isScenario8)

                        // Auto-reset kiosk session after passage completes
                        sessionTimeoutJob = viewModelScope.launch {
                            delay(10_000)
                            // Complete privacy scrub
                            startNewSession()
                        }
                    }
                }
                DecisionOutcome.REFER_TO_OFFICER,
                DecisionOutcome.SERVICE_UNAVAILABLE,
                DecisionOutcome.REJECTED -> {
                    handleFailureOutcome(decision.outcome, decision.travellerPublicSummary, decision.internalReasonCode)
                }
                DecisionOutcome.RETRY_CAPTURE -> {
                    _sessionState.value = _sessionState.value.copy(
                        step = KioskStep.PASSPORT_SCAN,
                        statusBannerText = decision.travellerPublicSummary
                    )
                    speakGuidance(decision.travellerPublicSummary)
                }
            }
        }
    }

    private fun handleFailureOutcome(outcome: DecisionOutcome, publicMsg: String, reason: ReasonCode) {
        _sessionState.value = _sessionState.value.copy(
            step = KioskStep.OFFICER_ASSISTANCE,
            statusBannerText = publicMsg
        )
        speakGuidance(publicMsg)

        // Store in inspection pool for Officer Console
        _selectedSessionForInspection.value = _sessionState.value
    }

    // Officer Interventions
    fun officerApproveOverride(reasonComment: String, badgeId: String) {
        viewModelScope.launch {
            val session = _sessionState.value
            val overrideDecision = PassageDecision(
                sessionId = session.sessionId,
                outcome = DecisionOutcome.APPROVED,
                travellerPublicSummary = "Clearance granted by Border Control Officer. Please proceed through the gate.",
                internalReasonCode = ReasonCode.MANUAL_OFFICER_APPROVED
            )

            auditRepository.recordAudit(
                sessionId = session.sessionId,
                gateId = "EGATE-LHR-T5-04",
                role = _activeOfficerRole.value,
                action = "OFFICER_MANUAL_OVERRIDE_APPROVE",
                rawDetails = "Reason: $reasonComment, Badge: $badgeId, PriorReason: ${session.decision?.internalReasonCode}",
                reasonCode = "MANUAL_OFFICER_APPROVED",
                officerBadgeId = badgeId,
                outcome = "OVERRIDE_APPROVED"
            )

            _sessionState.value = session.copy(
                decision = overrideDecision,
                step = KioskStep.PROCEED,
                statusBannerText = overrideDecision.travellerPublicSummary
            )

            gateController.authorizePassage(session.sessionId, overrideDecision.singleUseToken)
            gateController.simulatePassageSequence()

            speakGuidance("Clearance granted by officer. Please proceed through the gate.")
        }
    }

    fun officerConfirmReferral(reasonComment: String, badgeId: String) {
        viewModelScope.launch {
            val session = _sessionState.value
            auditRepository.recordAudit(
                sessionId = session.sessionId,
                gateId = "EGATE-LHR-T5-04",
                role = _activeOfficerRole.value,
                action = "OFFICER_CONFIRM_REFERRAL_DESK",
                rawDetails = "Direct to secondary desk. Note: $reasonComment, Badge: $badgeId",
                reasonCode = "MANUAL_OFFICER_REFERRED",
                officerBadgeId = badgeId,
                outcome = "REFERRED_TO_SECONDARY"
            )

            startNewSession()
        }
    }

    fun clearAuditHistory() {
        viewModelScope.launch {
            auditRepository.clearAudits()
        }
    }

    private fun speakGuidance(text: String) {
        if (_sessionState.value.audioGuidanceEnabled) {
            audioGuidanceService.speak(text, _sessionState.value.language)
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioGuidanceService.shutdown()
    }
}
