package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.data.model.BarrierPosition
import com.example.data.model.GateHardwareState
import com.example.data.model.GateOccupancy
import com.example.ui.theme.AirportNavyDark
import com.example.ui.theme.AirportNavyElevated
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.CyanTeal
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

/**
 * 2D Top-Down Gate Corridor Graphic showing Entry Flaps, Chamber Sensors (Beam A, B, C),
 * Exit Flaps, Passenger position, and Obstruction indicator.
 */
@Composable
fun GateBarrierGraphic(
    gateState: GateHardwareState,
    modifier: Modifier = Modifier
) {
    // Animate Flap opening angles (0 = closed, 1 = fully open retracted into cabinet)
    val entryFlapOpenFraction by animateFloatAsState(
        targetValue = when (gateState.entryBarrier) {
            BarrierPosition.CLOSED -> 0f
            BarrierPosition.OPENING -> 0.6f
            BarrierPosition.FULLY_OPEN -> 1f
            BarrierPosition.CLOSING -> 0.4f
            BarrierPosition.OBSTRUCTED_REOPENING -> 0.8f
            BarrierPosition.LOCKED_FAULT -> 0f
        },
        animationSpec = tween(400),
        label = "entryFlap"
    )

    val exitFlapOpenFraction by animateFloatAsState(
        targetValue = when (gateState.exitBarrier) {
            BarrierPosition.CLOSED -> 0f
            BarrierPosition.OPENING -> 0.6f
            BarrierPosition.FULLY_OPEN -> 1f
            BarrierPosition.CLOSING -> 0.4f
            BarrierPosition.OBSTRUCTED_REOPENING -> 0.8f
            BarrierPosition.LOCKED_FAULT -> 0f
        },
        animationSpec = tween(400),
        label = "exitFlap"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(240.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(AirportNavyDark)
            .border(1.5.dp, AirportNavyElevated, RoundedCornerShape(12.dp))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val corridorW = size.width * 0.72f
            val leftWallX = (size.width - corridorW) / 2f
            val rightWallX = leftWallX + corridorW

            // 1. Draw Glass Corridor Walls
            val wallThickness = 12.dp.toPx()
            // Left Cabinet Wall
            drawRoundRect(
                color = AirportNavyElevated,
                topLeft = Offset(leftWallX - wallThickness, 16f),
                size = Size(wallThickness, size.height - 32f),
                cornerRadius = CornerRadius(4f, 4f)
            )
            // Right Cabinet Wall
            drawRoundRect(
                color = AirportNavyElevated,
                topLeft = Offset(rightWallX, 16f),
                size = Size(wallThickness, size.height - 32f),
                cornerRadius = CornerRadius(4f, 4f)
            )

            // Floor Corridor Walkway
            drawRect(
                color = Color(0xFF0A1C30),
                topLeft = Offset(leftWallX, 16f),
                size = Size(corridorW, size.height - 32f)
            )

            // 2. Optical Sensor Beams (A = Top Entry, B = Center Chamber, C = Bottom Exit)
            val beamAY = size.height * 0.22f
            val beamBY = size.height * 0.50f
            val beamCY = size.height * 0.78f

            fun drawBeam(y: Float, isInterrupted: Boolean, labelColor: Color) {
                drawLine(
                    color = if (isInterrupted) AlertRed else labelColor.copy(alpha = 0.35f),
                    start = Offset(leftWallX, y),
                    end = Offset(rightWallX, y),
                    strokeWidth = if (isInterrupted) 3.dp.toPx() else 1.5.dp.toPx()
                )
            }

            drawBeam(beamAY, gateState.beamAInterrupted, CyanTeal)
            drawBeam(beamBY, gateState.beamBInterrupted, CyanPrimary)
            drawBeam(beamCY, gateState.beamCInterrupted, SuccessGreen)

            // 3. Entry Barrier Acrylic Flaps (near Beam A)
            val entryY = size.height * 0.26f
            val flapMaxLen = (corridorW / 2f) * 0.95f
            val entryFlapCurrentLen = flapMaxLen * (1f - entryFlapOpenFraction)

            val flapColor = when {
                gateState.obstructionActive -> AlertRed
                gateState.entryBarrier == BarrierPosition.FULLY_OPEN -> SuccessGreen
                else -> CyanPrimary
            }

            // Left flap
            drawLine(
                color = flapColor,
                start = Offset(leftWallX, entryY),
                end = Offset(leftWallX + entryFlapCurrentLen, entryY),
                strokeWidth = 6.dp.toPx()
            )
            // Right flap
            drawLine(
                color = flapColor,
                start = Offset(rightWallX, entryY),
                end = Offset(rightWallX - entryFlapCurrentLen, entryY),
                strokeWidth = 6.dp.toPx()
            )

            // 4. Exit Barrier Acrylic Flaps (near Beam C)
            val exitY = size.height * 0.74f
            val exitFlapCurrentLen = flapMaxLen * (1f - exitFlapOpenFraction)
            val exitFlapColor = if (gateState.exitBarrier == BarrierPosition.FULLY_OPEN) SuccessGreen else CyanPrimary

            // Left exit flap
            drawLine(
                color = exitFlapColor,
                start = Offset(leftWallX, exitY),
                end = Offset(leftWallX + exitFlapCurrentLen, exitY),
                strokeWidth = 6.dp.toPx()
            )
            // Right exit flap
            drawLine(
                color = exitFlapColor,
                start = Offset(rightWallX, exitY),
                end = Offset(rightWallX - exitFlapCurrentLen, exitY),
                strokeWidth = 6.dp.toPx()
            )

            // 5. Draw Passenger Avatar based on Occupancy
            val centerX = leftWallX + (corridorW / 2f)
            when (gateState.occupancy) {
                GateOccupancy.OCCUPIED_ENTERING -> {
                    drawCircle(color = CyanPrimary, radius = 14.dp.toPx(), center = Offset(centerX, beamAY))
                }
                GateOccupancy.OCCUPIED_IN_CHAMBER -> {
                    drawCircle(color = CyanPrimary, radius = 14.dp.toPx(), center = Offset(centerX, beamBY))
                }
                GateOccupancy.OCCUPIED_EXITING -> {
                    drawCircle(color = SuccessGreen, radius = 14.dp.toPx(), center = Offset(centerX, beamCY))
                }
                GateOccupancy.TAILGATING_DETECTED -> {
                    // Two passengers in corridor: Primary in chamber, intruder at entry
                    drawCircle(color = CyanPrimary, radius = 14.dp.toPx(), center = Offset(centerX, beamBY))
                    drawCircle(color = AlertRed, radius = 14.dp.toPx(), center = Offset(centerX, beamAY - 10f))
                }
                GateOccupancy.CLEAR -> {
                    // Empty corridor
                }
            }

            // 6. Obstruction Warning Flashing Marker
            if (gateState.obstructionActive) {
                drawCircle(
                    color = AlertRed.copy(alpha = 0.5f),
                    radius = 28.dp.toPx(),
                    center = Offset(centerX, entryY),
                    style = Stroke(width = 3.dp.toPx())
                )
            }
        }
    }
}
