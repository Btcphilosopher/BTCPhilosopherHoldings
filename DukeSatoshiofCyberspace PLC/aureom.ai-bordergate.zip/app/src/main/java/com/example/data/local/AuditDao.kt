package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.AuditRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface AuditDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAudit(record: AuditRecord): Long

    @Query("SELECT * FROM audit_events ORDER BY timestamp DESC")
    fun getAllAuditRecords(): Flow<List<AuditRecord>>

    @Query("SELECT * FROM audit_events WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    suspend fun getAuditsForSession(sessionId: String): List<AuditRecord>

    @Query("DELETE FROM audit_events")
    suspend fun clearAllAudits()
}
