package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Airport eGate Calm & Premium Palette
val AirportNavyDark = Color(0xFF06101E)      // Deepest background navy
val AirportNavySurface = Color(0xFF0D1B2E)   // Surface cards
val AirportNavyElevated = Color(0xFF162A45)  // Elevated modals/drawers
val AirportNavyBorder = Color(0xFF1E3A5F)    // Subtle borders

val CyanPrimary = Color(0xFF00E5FF)          // Restrained bright cyan accent
val CyanTeal = Color(0xFF00B4D8)             // Secondary teal
val CyanGlow = Color(0x3300E5FF)             // Glow effect
val CyanDark = Color(0xFF0077B6)             // Deep cyan for button pressed

val PureWhite = Color(0xFFFFFFFF)
val OffWhite = Color(0xFFF1F5F9)
val TextMuted = Color(0xFF94A3B8)
val TextSubtle = Color(0xFF64748B)

// Status & Indicator Colors
val SuccessGreen = Color(0xFF10B981)
val SuccessGreenBg = Color(0x1F10B981)
val WarningAmber = Color(0xFFF59E0B)
val WarningAmberBg = Color(0x1FF59E0B)
val AlertRed = Color(0xFFEF4444)
val AlertRedBg = Color(0x1FEF4444)
val NeutralBlue = Color(0xFF3B82F6)

// Officer Console Workspace Colors
val OfficerNavy = Color(0xFF0A192F)
val OfficerAccentGold = Color(0xFFE2B714)
val OfficerBorder = Color(0xFF203A63)
