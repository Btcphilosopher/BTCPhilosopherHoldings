package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.AuditRecord

@Database(entities = [AuditRecord::class], version = 1, exportSchema = false)
abstract class BorderGateDatabase : RoomDatabase() {

    abstract fun auditDao(): AuditDao

    companion object {
        @Volatile
        private var INSTANCE: BorderGateDatabase? = null

        fun getInstance(context: Context): BorderGateDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BorderGateDatabase::class.java,
                    "bordergate_operational.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
