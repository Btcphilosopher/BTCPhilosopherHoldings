package com.example.data.model

enum class FaceStatus {
    SUCCESS,
    MULTI_PERSON_DETECTED,
    POOR_LIGHTING,
    BLURRED,
    TIMEOUT,
    OCCLUDED
}

data class FaceCaptureMetrics(
    val qualityScore: Float = 0.94f,      // 0..1 scale (ISO/IEC 29794-5)
    val lightingScore: Float = 0.88f,
    val singlePersonFramed: Boolean = true,
    val eyeContactScore: Float = 0.92f,
    val faceStatus: FaceStatus = FaceStatus.SUCCESS
)

enum class AttackType {
    NONE,
    PRINTED_PHOTO_ATTACK,
    SCREEN_VIDEO_REPLAY,
    SILICONE_3D_MASK,
    WARPED_DISPLAY
}

/**
 * Presentation Attack Detection (PAD / Liveness) assessment.
 * Separated from face comparison per requirement.
 */
data class PadAssessment(
    val isLive: Boolean,
    val padScore: Float, // 0..100
    val detectedAttackType: AttackType = AttackType.NONE,
    val padEngineVersion: String = "ISO-30107-PAD-Engine-v2.6",
    val evaluationTimestamp: Long = System.currentTimeMillis()
)

/**
 * Facial comparison result between live probe and eChip DG2 photograph.
 * Explicitly notes: similarity score is NOT a probability of identity.
 */
data class FaceComparisonResult(
    val similarityScore: Float, // e.g. 84.5 on 0..100 scale
    val operationalThreshold: Float = 75.0f,
    val isMatch: Boolean,
    val matcherEngineVersion: String = "Aureom-FacialMatch-v4.1.2",
    val thresholdPolicyVersion: String = "ICAO-E-GATE-POLICY-2026.1",
    val reviewRecommended: Boolean = false,
    val evaluationTimestamp: Long = System.currentTimeMillis()
)

data class FaceVerificationSession(
    val captureMetrics: FaceCaptureMetrics,
    val padAssessment: PadAssessment,
    val comparisonResult: FaceComparisonResult,
    val probePhotoResId: Int? = null
)
