package com.example.domain.services

import com.example.data.model.ChipData
import com.example.data.model.ChipReadStatus
import com.example.data.model.DecisionOutcome
import com.example.data.model.FaceVerificationSession
import com.example.data.model.MrzData
import com.example.data.model.PassageDecision
import com.example.data.model.PassiveAuthStatus
import com.example.data.model.ReasonCode
import java.util.UUID

interface BorderDecisionService {
    suspend fun evaluatePassage(
        sessionId: String,
        gateId: String,
        mrzData: MrzData?,
        chipData: ChipData?,
        biometricSession: FaceVerificationSession?,
        authResult: DocumentAuthenticationResult,
        simulateServiceOutage: Boolean = false
    ): PassageDecision

    fun validateToken(token: String, activeDecision: PassageDecision?): Boolean
}

class StandardBorderDecisionService : BorderDecisionService {

    private val consumedTokens = mutableSetOf<String>()

    override suspend fun evaluatePassage(
        sessionId: String,
        gateId: String,
        mrzData: MrzData?,
        chipData: ChipData?,
        biometricSession: FaceVerificationSession?,
        authResult: DocumentAuthenticationResult,
        simulateServiceOutage: Boolean
    ): PassageDecision {
        val now = System.currentTimeMillis()
        val validUntil = now + 30_000L // 30 seconds expiry window
        val token = "TOKEN-${UUID.randomUUID().toString().take(12).uppercase()}"

        if (simulateServiceOutage) {
            return PassageDecision(
                sessionId = sessionId,
                gateId = gateId,
                timestamp = now,
                outcome = DecisionOutcome.SERVICE_UNAVAILABLE,
                travellerPublicSummary = "Border control service temporarily unavailable. Please seek assistance.",
                internalReasonCode = ReasonCode.BORDER_SERVICE_OUTAGE,
                validUntilEpochMs = validUntil,
                singleUseToken = token
            )
        }

        // 1. Check Document MRZ
        if (mrzData == null || !authResult.isOcrChecksumValid) {
            return PassageDecision(
                sessionId = sessionId,
                gateId = gateId,
                timestamp = now,
                outcome = DecisionOutcome.RETRY_CAPTURE,
                travellerPublicSummary = "Unable to read travel document clearly. Please reposition your passport.",
                internalReasonCode = ReasonCode.MRZ_CHECKSUM_FAILURE,
                validUntilEpochMs = validUntil,
                singleUseToken = token
            )
        }

        // 2. Check Expiry
        if (!authResult.isDocumentNotExpired) {
            return PassageDecision(
                sessionId = sessionId,
                gateId = gateId,
                timestamp = now,
                outcome = DecisionOutcome.REFER_TO_OFFICER,
                travellerPublicSummary = "Please collect your documents and proceed to the Border Control desk.",
                internalReasonCode = ReasonCode.DOCUMENT_EXPIRED,
                validUntilEpochMs = validUntil,
                singleUseToken = token
            )
        }

        // 3. Check Chip reading & authenticity
        if (chipData == null || chipData.chipReadStatus != ChipReadStatus.SUCCESS) {
            return PassageDecision(
                sessionId = sessionId,
                gateId = gateId,
                timestamp = now,
                outcome = DecisionOutcome.REFER_TO_OFFICER,
                travellerPublicSummary = "Please collect your documents and proceed to Officer Desk 4.",
                internalReasonCode = ReasonCode.CHIP_READ_INTERRUPTED,
                validUntilEpochMs = validUntil,
                singleUseToken = token
            )
        }

        if (chipData.passiveAuthStatus == PassiveAuthStatus.UNTRUSTED_SIGNER) {
            return PassageDecision(
                sessionId = sessionId,
                gateId = gateId,
                timestamp = now,
                outcome = DecisionOutcome.REFER_TO_OFFICER,
                travellerPublicSummary = "Please collect your travel documents and see an officer for manual check.",
                internalReasonCode = ReasonCode.UNTRUSTED_DOCUMENT_SIGNER,
                validUntilEpochMs = validUntil,
                singleUseToken = token
            )
        }

        if (chipData.passiveAuthStatus != PassiveAuthStatus.VERIFIED) {
            return PassageDecision(
                sessionId = sessionId,
                gateId = gateId,
                timestamp = now,
                outcome = DecisionOutcome.REFER_TO_OFFICER,
                travellerPublicSummary = "Document verification requires manual review. Please proceed to the officer desk.",
                internalReasonCode = ReasonCode.PASSIVE_AUTH_FAILED,
                validUntilEpochMs = validUntil,
                singleUseToken = token
            )
        }

        // 4. Check Biometrics & PAD
        if (biometricSession == null) {
            return PassageDecision(
                sessionId = sessionId,
                gateId = gateId,
                timestamp = now,
                outcome = DecisionOutcome.RETRY_CAPTURE,
                travellerPublicSummary = "Biometric capture was not completed. Please look into the camera.",
                internalReasonCode = ReasonCode.BIOMETRIC_LOW_SIMILARITY,
                validUntilEpochMs = validUntil,
                singleUseToken = token
            )
        }

        if (!biometricSession.captureMetrics.singlePersonFramed) {
            return PassageDecision(
                sessionId = sessionId,
                gateId = gateId,
                timestamp = now,
                outcome = DecisionOutcome.RETRY_CAPTURE,
                travellerPublicSummary = "Please ensure only one person is standing in the verification area.",
                internalReasonCode = ReasonCode.MULTIPLE_PERSONS_IN_FRAME,
                validUntilEpochMs = validUntil,
                singleUseToken = token
            )
        }

        if (!biometricSession.padAssessment.isLive) {
            return PassageDecision(
                sessionId = sessionId,
                gateId = gateId,
                timestamp = now,
                outcome = DecisionOutcome.REFER_TO_OFFICER,
                travellerPublicSummary = "Please see the border control officer for manual verification.",
                internalReasonCode = ReasonCode.BIOMETRIC_PAD_SPOOF_SUSPECTED,
                validUntilEpochMs = validUntil,
                singleUseToken = token
            )
        }

        if (!biometricSession.comparisonResult.isMatch) {
            return PassageDecision(
                sessionId = sessionId,
                gateId = gateId,
                timestamp = now,
                outcome = DecisionOutcome.REFER_TO_OFFICER,
                travellerPublicSummary = "Please take your documents and proceed to Border Control Officer Desk 4.",
                internalReasonCode = ReasonCode.BIOMETRIC_LOW_SIMILARITY,
                validUntilEpochMs = validUntil,
                singleUseToken = token
            )
        }

        // 5. All factors confirmed: Grant Authorised Passage
        return PassageDecision(
            sessionId = sessionId,
            gateId = gateId,
            timestamp = now,
            outcome = DecisionOutcome.APPROVED,
            travellerPublicSummary = "Clearance granted. Please proceed through the gate.",
            internalReasonCode = ReasonCode.CLEARANCE_GRANTED,
            validUntilEpochMs = validUntil,
            singleUseToken = token
        )
    }

    override fun validateToken(token: String, activeDecision: PassageDecision?): Boolean {
        if (activeDecision == null) return false
        if (activeDecision.singleUseToken != token) return false
        if (activeDecision.isExpired) return false
        if (activeDecision.isConsumed || consumedTokens.contains(token)) return false

        // Mark consumed immediately
        activeDecision.isConsumed = true
        consumedTokens.add(token)
        return true
    }
}
