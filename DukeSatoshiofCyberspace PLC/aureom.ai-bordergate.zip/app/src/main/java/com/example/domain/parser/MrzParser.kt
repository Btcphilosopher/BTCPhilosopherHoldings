package com.example.domain.parser

import com.example.data.model.MrzCheckResult
import com.example.data.model.MrzData
import java.util.Calendar

/**
 * Machine Readable Zone (MRZ) parser complying with ICAO Doc 9303 Part 3, 4 & 7.
 * Supports TD3 (2 lines x 44 chars) passports and TD1 (3 lines x 30 chars) identity cards.
 */
object MrzParser {

    private val WEIGHTS = intArrayOf(7, 3, 1)

    /**
     * Calculates the ICAO 9303 check digit for a given alphanumeric string.
     * Fillers ('<') evaluate to 0. A-Z evaluate to 10..35.
     */
    fun calculateCheckDigit(input: String): Int {
        var sum = 0
        input.forEachIndexed { index, char ->
            val value = when (char) {
                in '0'..'9' -> char - '0'
                in 'A'..'Z' -> (char - 'A') + 10
                in 'a'..'z' -> (char - 'a') + 10
                '<' -> 0
                else -> 0
            }
            val weight = WEIGHTS[index % WEIGHTS.size]
            sum += value * weight
        }
        return sum % 10
    }

    /**
     * Validates whether the expected check digit character matches the calculated checksum.
     */
    fun verifyCheckDigit(content: String, expectedChar: Char): Boolean {
        val expected = when (expectedChar) {
            in '0'..'9' -> expectedChar - '0'
            '<' -> 0
            else -> return false
        }
        return calculateCheckDigit(content) == expected
    }

    /**
     * Parse 2-digit year with explicit ambiguity handling according to ICAO Doc 9303.
     * Pivot year: e.g. current year (2026).
     */
    fun parseDate(rawDate: String, isExpiry: Boolean): String {
        if (rawDate.length != 6) return "INVALID"
        val yyStr = rawDate.substring(0, 2)
        val mmStr = rawDate.substring(2, 4)
        val ddStr = rawDate.substring(4, 6)

        val yy = yyStr.toIntOrNull() ?: return "INVALID"
        val mm = mmStr.toIntOrNull() ?: return "INVALID"
        val dd = ddStr.toIntOrNull() ?: return "INVALID"

        if (mm !in 1..12 || dd !in 1..31) return "INVALID_DATE_VALUES"

        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        val currentCentury = (currentYear / 100) * 100
        val currentTwoDigitYear = currentYear % 100

        val fullYear = if (isExpiry) {
            // Document expiry is in the future or recent past
            if (yy < currentTwoDigitYear - 10) {
                currentCentury + 100 + yy
            } else {
                currentCentury + yy
            }
        } else {
            // Birth date is in the past
            if (yy > currentTwoDigitYear) {
                currentCentury - 100 + yy
            } else {
                currentCentury + yy
            }
        }

        return String.format("%04d-%02d-%02d", fullYear, mm, dd)
    }

    /**
     * Parse standard TD3 passport MRZ (2 lines of 44 characters).
     */
    fun parseTd3(line1Raw: String, line2Raw: String): MrzData? {
        val line1 = line1Raw.trim().replace(" ", "").padEnd(44, '<').take(44).uppercase()
        val line2 = line2Raw.trim().replace(" ", "").padEnd(44, '<').take(44).uppercase()

        if (line1.length != 44 || line2.length != 44) return null

        // Line 1:
        // 0..1: Doc type (e.g. P<)
        // 2..4: Issuing country (3 chars)
        // 5..43: Names (Surname<<Given Names)
        val docType = line1.substring(0, 2).replace("<", "")
        val issuingCountry = line1.substring(2, 5).replace("<", "")
        val rawNames = line1.substring(5, 44)
        val nameParts = rawNames.split("<<")
        val surname = nameParts.getOrNull(0)?.replace("<", " ")?.trim() ?: ""
        val givenNames = nameParts.getOrNull(1)?.replace("<", " ")?.trim() ?: ""

        // Line 2:
        // 0..8: Document Number (9 chars)
        // 9: Doc number check digit
        // 10..12: Nationality (3 chars)
        // 13..18: Date of birth (YYMMDD)
        // 19: DOB check digit
        // 20: Sex (M, F, X, <)
        // 21..26: Date of expiry (YYMMDD)
        // 27: Expiry check digit
        // 28..41: Optional data (14 chars)
        // 42: Optional data check digit
        // 43: Composite check digit
        val docNum = line2.substring(0, 9)
        val docNumCheckChar = line2[9]
        val nationality = line2.substring(10, 13).replace("<", "")
        val dob = line2.substring(13, 19)
        val dobCheckChar = line2[19]
        val sex = line2.substring(20, 21).replace("<", "X")
        val expiry = line2.substring(21, 27)
        val expiryCheckChar = line2[27]
        val optionalData = line2.substring(28, 42)
        val optionalCheckChar = line2[42]
        val compositeCheckChar = line2[43]

        val docNumValid = verifyCheckDigit(docNum, docNumCheckChar)
        val dobValid = verifyCheckDigit(dob, dobCheckChar)
        val expiryValid = verifyCheckDigit(expiry, expiryCheckChar)

        // Optional data check digit is only mandatory if optional data is non-filler
        val optionalValid = if (optionalData.replace("<", "").isEmpty()) {
            optionalCheckChar == '<' || optionalCheckChar == '0'
        } else {
            verifyCheckDigit(optionalData, optionalCheckChar)
        }

        // Composite check string in TD3: line2[0..9] + line2[13..19] + line2[21..42]
        val compositeData = docNum + docNumCheckChar + dob + dobCheckChar + expiry + expiryCheckChar + optionalData + optionalCheckChar
        val compositeValid = verifyCheckDigit(compositeData, compositeCheckChar)

        val allValid = docNumValid && dobValid && expiryValid && compositeValid

        val checkResult = MrzCheckResult(
            documentNumberCheckValid = docNumValid,
            birthDateCheckValid = dobValid,
            expiryDateCheckValid = expiryValid,
            optionalDataCheckValid = optionalValid,
            compositeCheckValid = compositeValid,
            allValid = allValid
        )

        val cleanDocNum = docNum.replace("<", "")
        val parsedDob = parseDate(dob, isExpiry = false)
        val parsedExpiry = parseDate(expiry, isExpiry = true)

        return MrzData(
            documentType = docType.ifEmpty { "P" },
            issuingCountry = issuingCountry,
            surname = surname,
            givenNames = givenNames,
            documentNumber = cleanDocNum,
            nationality = nationality,
            dateOfBirthRaw = dob,
            parsedBirthDate = parsedDob,
            sex = sex,
            dateOfExpiryRaw = expiry,
            parsedExpiryDate = parsedExpiry,
            optionalData = optionalData.replace("<", ""),
            rawLines = listOf(line1, line2),
            checkResult = checkResult,
            isSpecimen = true
        )
    }

    /**
     * Helper to parse any raw OCR text block looking for MRZ lines.
     */
    fun parseFromRawText(text: String): MrzData? {
        val lines = text.lines()
            .map { it.trim().replace(" ", "") }
            .filter { it.contains("<") && it.length >= 30 }

        if (lines.size >= 2) {
            val candidate1 = lines[lines.size - 2]
            val candidate2 = lines[lines.size - 1]
            return parseTd3(candidate1, candidate2)
        }
        return null
    }
}
