package com.example.data.fixtures

import com.example.data.model.MrzData
import com.example.domain.parser.MrzParser

data class SpecimenPassport(
    val id: String,
    val title: String,
    val country: String,
    val countryFlag: String,
    val holderName: String,
    val docNumber: String,
    val dob: String,
    val expiry: String,
    val sex: String,
    val line1: String,
    val line2: String,
    val isChecksumValid: Boolean = true,
    val isSignerTrusted: Boolean = true,
    val isBiometricMatch: Boolean = true,
    val isExpired: Boolean = false,
    val notes: String
) {
    fun toMrzData(): MrzData {
        return MrzParser.parseTd3(line1, line2) ?: throw IllegalStateException("Invalid specimen MRZ format")
    }
}

object SpecimenPassports {

    private fun buildTd3Line1(country: String, surname: String, given: String): String {
        val header = "P<${country.padEnd(3, '<')}${surname.replace(" ", "<")}<<${given.replace(" ", "<")}"
        return header.padEnd(44, '<').take(44)
    }

    private fun buildTd3Line2(
        docNum: String,
        country: String,
        dobYymmdd: String,
        sex: String,
        expiryYymmdd: String,
        optional: String = "",
        forceBadCheckDigit: Boolean = false
    ): String {
        val cleanDoc = docNum.padEnd(9, '<').take(9)
        var docCheck = MrzParser.calculateCheckDigit(cleanDoc)
        if (forceBadCheckDigit) docCheck = (docCheck + 5) % 10

        val cleanDob = dobYymmdd.padEnd(6, '<').take(6)
        val dobCheck = MrzParser.calculateCheckDigit(cleanDob)

        val cleanExpiry = expiryYymmdd.padEnd(6, '<').take(6)
        val expiryCheck = MrzParser.calculateCheckDigit(cleanExpiry)

        val cleanOpt = optional.padEnd(14, '<').take(14)
        val optCheck = if (cleanOpt.replace("<", "").isEmpty()) '<' else MrzParser.calculateCheckDigit(cleanOpt).toString()[0]

        val compositeBody = cleanDoc + docCheck + cleanDob + dobCheck + cleanExpiry + expiryCheck + cleanOpt + (if (optCheck == '<') '0' else optCheck)
        var compositeCheck = MrzParser.calculateCheckDigit(compositeBody)
        if (forceBadCheckDigit) compositeCheck = (compositeCheck + 3) % 10

        return "$cleanDoc$docCheck$country$cleanDob$dobCheck$sex$cleanExpiry$expiryCheck$cleanOpt$optCheck$compositeCheck"
    }

    val DOE_UK: SpecimenPassport by lazy {
        val l1 = buildTd3Line1("GBR", "DOE", "JOHN MICHAEL")
        val l2 = buildTd3Line2("982341902", "GBR", "850412", "M", "300915")
        SpecimenPassport(
            id = "DOE_UK",
            title = "UK Passport (Clearance Approved)",
            country = "United Kingdom",
            countryFlag = "🇬🇧",
            holderName = "John Michael Doe",
            docNumber = "982341902",
            dob = "1985-04-12",
            expiry = "2030-09-15",
            sex = "M",
            line1 = l1,
            line2 = l2,
            notes = "Standard genuine specimen with valid PKI signer and verified face match."
        )
    }

    val DUPONT_FR: SpecimenPassport by lazy {
        val l1 = buildTd3Line1("FRA", "DUPONT", "MARIE CLAIRE")
        val l2 = buildTd3Line2("21AB89123", "FRA", "920724", "F", "311228")
        SpecimenPassport(
            id = "DUPONT_FR",
            title = "French Passport (Clearance Approved)",
            country = "France",
            countryFlag = "🇫🇷",
            holderName = "Marie Claire Dupont",
            docNumber = "21AB89123",
            dob = "1992-07-24",
            expiry = "2031-12-28",
            sex = "F",
            line1 = l1,
            line2 = l2,
            notes = "Valid EU biometric passport with PACE authentication."
        )
    }

    val SATO_JP: SpecimenPassport by lazy {
        val l1 = buildTd3Line1("JPN", "SATO", "KENJI")
        val l2 = buildTd3Line2("TZ7819230", "JPN", "801105", "M", "290410")
        SpecimenPassport(
            id = "SATO_JP",
            title = "Japanese Passport (Clearance Approved)",
            country = "Japan",
            countryFlag = "🇯🇵",
            holderName = "Kenji Sato",
            docNumber = "TZ7819230",
            dob = "1980-11-05",
            expiry = "2029-04-10",
            sex = "M",
            line1 = l1,
            line2 = l2,
            notes = "Valid Asian biometric passport with Active Authentication."
        )
    }

    val GRUBER_CORRUPT_MRZ: SpecimenPassport by lazy {
        val l1 = buildTd3Line1("DEU", "GRUBER", "HANS")
        val l2 = buildTd3Line2("C01X00T47", "DEU", "780315", "M", "280820", forceBadCheckDigit = true)
        SpecimenPassport(
            id = "GRUBER_CORRUPT_MRZ",
            title = "German Specimen (Checksum Failure)",
            country = "Germany",
            countryFlag = "🇩🇪",
            holderName = "Hans Gruber",
            docNumber = "C01X00T47",
            dob = "1978-03-15",
            expiry = "2028-08-20",
            sex = "M",
            line1 = l1,
            line2 = l2,
            isChecksumValid = false,
            notes = "Corrupted document number check digit triggering unreadable/tampered scan retry."
        )
    }

    val ROSTOVA_UNTRUSTED_SIGNER: SpecimenPassport by lazy {
        val l1 = buildTd3Line1("UTO", "ROSTOVA", "ELENA")
        val l2 = buildTd3Line2("UT8823101", "UTO", "890918", "F", "291130")
        SpecimenPassport(
            id = "ROSTOVA_UNTRUSTED_SIGNER",
            title = "Specimen (Untrusted CSCA Signer)",
            country = "Utopia",
            countryFlag = "🌐",
            holderName = "Elena Rostova",
            docNumber = "UT8823101",
            dob = "1989-09-18",
            expiry = "2029-11-30",
            sex = "F",
            line1 = l1,
            line2 = l2,
            isSignerTrusted = false,
            notes = "CSCA root certificate not in National ICAO PKD trust store. Routed to officer."
        )
    }

    val SMITH_MISMATCH_FACE: SpecimenPassport by lazy {
        val l1 = buildTd3Line1("GBR", "SMITH", "ALEXANDER DAVID")
        val l2 = buildTd3Line2("554190823", "GBR", "950604", "M", "320110")
        SpecimenPassport(
            id = "SMITH_MISMATCH_FACE",
            title = "UK Specimen (Biometric Low Match)",
            country = "United Kingdom",
            countryFlag = "🇬🇧",
            holderName = "Alexander David Smith",
            docNumber = "554190823",
            dob = "1995-06-04",
            expiry = "2032-01-10",
            sex = "M",
            line1 = l1,
            line2 = l2,
            isBiometricMatch = false,
            notes = "Facial similarity score (52%) below operational threshold (75%). Routed to officer."
        )
    }

    val EXPIRED_SPECIMEN: SpecimenPassport by lazy {
        val l1 = buildTd3Line1("AUS", "TAYLOR", "EMMA JANE")
        val l2 = buildTd3Line2("E45019821", "AUS", "880210", "F", "240101")
        SpecimenPassport(
            id = "EXPIRED_SPECIMEN",
            title = "Australian Specimen (Expired Document)",
            country = "Australia",
            countryFlag = "🇦🇺",
            holderName = "Emma Jane Taylor",
            docNumber = "E45019821",
            dob = "1988-02-10",
            expiry = "2024-01-01",
            sex = "F",
            line1 = l1,
            line2 = l2,
            isExpired = true,
            notes = "Document expired in January 2024. Ineligible for automated eGate passage."
        )
    }

    val ALL = listOf(
        DOE_UK,
        DUPONT_FR,
        SATO_JP,
        GRUBER_CORRUPT_MRZ,
        ROSTOVA_UNTRUSTED_SIGNER,
        SMITH_MISMATCH_FACE,
        EXPIRED_SPECIMEN
    )
}
