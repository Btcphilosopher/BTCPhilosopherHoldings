package com.example.ui.screens.simulator

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dangerous
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BarrierPosition
import com.example.data.model.GateControllerStatus
import com.example.data.model.GateHardwareState
import com.example.domain.services.GateController
import com.example.ui.components.GateBarrierGraphic
import com.example.ui.theme.AirportNavyDark
import com.example.ui.theme.AirportNavyElevated
import com.example.ui.theme.AirportNavySurface
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarningAmber

@Composable
fun GateSimulatorScreen(
    gateState: GateHardwareState,
    gateController: GateController,
    onBackToKiosk: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AirportNavyDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "eGate Hardware Simulator",
                    color = PureWhite,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Unit: EGATE-LHR-T5-04 • Firmware: v4.8.2-RT",
                    color = CyanPrimary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Connection Status Pill
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(AirportNavyElevated)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(
                            if (gateState.controllerStatus == GateControllerStatus.CONNECTED) SuccessGreen else AlertRed
                        )
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = gateState.controllerStatus.name,
                    color = PureWhite,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Live Corridor Graphic
        GateBarrierGraphic(
            gateState = gateState,
            modifier = Modifier.fillMaxWidth()
        )

        // Telemetry & Hardware Status Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TelemetryCard(
                title = "Entry Flaps",
                value = gateState.entryBarrier.name,
                isAlert = gateState.entryBarrier == BarrierPosition.OBSTRUCTED_REOPENING,
                modifier = Modifier.weight(1f)
            )
            TelemetryCard(
                title = "Chamber Occupancy",
                value = gateState.occupancy.name.replace("OCCUPIED_", ""),
                isAlert = gateState.tailgatingAlarm,
                modifier = Modifier.weight(1f)
            )
            TelemetryCard(
                title = "Exit Flaps",
                value = gateState.exitBarrier.name,
                isAlert = false,
                modifier = Modifier.weight(1f)
            )
        }

        // Sensors Status Breakdown
        Card(
            colors = CardDefaults.cardColors(containerColor = AirportNavySurface),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AirportNavyElevated, RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "OPTICAL CURTAIN SENSORS",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SensorIndicator(label = "Beam A (Entry)", isActive = gateState.beamAInterrupted)
                    SensorIndicator(label = "Beam B (Center)", isActive = gateState.beamBInterrupted)
                    SensorIndicator(label = "Beam C (Exit)", isActive = gateState.beamCInterrupted)
                }

                if (gateState.faultMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(AlertRed.copy(alpha = 0.2f))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "⚠ ${gateState.faultMessage}",
                            color = AlertRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Fault Injection & Simulation Controls
        Text(
            text = "HARDWARE BOUNDARY SIMULATION INJECTIONS",
            color = WarningAmber,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { gateController.simulatePassageSequence(withObstruction = false) },
                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = AirportNavyDark),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("sim_test_passage")
            ) {
                Icon(imageVector = Icons.Default.DirectionsWalk, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Test Passage", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { gateController.triggerObstruction() },
                colors = ButtonDefaults.buttonColors(containerColor = WarningAmber, contentColor = AirportNavyDark),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("sim_trigger_obstruction")
            ) {
                Icon(imageVector = Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Flap Obstacle", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { gateController.triggerTailgating() },
                colors = ButtonDefaults.buttonColors(containerColor = AlertRed, contentColor = PureWhite),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("sim_trigger_tailgating")
            ) {
                Text(text = "Tailgating Alarm", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { gateController.triggerEmergencyStop() },
                colors = ButtonDefaults.buttonColors(containerColor = AlertRed, contentColor = PureWhite),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("sim_trigger_estop")
            ) {
                Icon(imageVector = Icons.Default.Dangerous, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "E-Stop (Failsafe)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    if (gateState.controllerStatus == GateControllerStatus.CONNECTED) {
                        gateController.disconnectController()
                    } else {
                        gateController.reconnectController()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AirportNavyElevated, contentColor = PureWhite),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("sim_toggle_network")
            ) {
                Icon(imageVector = Icons.Default.LinkOff, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (gateState.controllerStatus == GateControllerStatus.CONNECTED) "Cut Link" else "Restore Link",
                    fontSize = 12.sp
                )
            }

            Button(
                onClick = { gateController.resetFault() },
                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen, contentColor = AirportNavyDark),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("sim_reset_gate")
            ) {
                Icon(imageVector = Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Reset Hardware", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun TelemetryCard(
    title: String,
    value: String,
    isAlert: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isAlert) AlertRed.copy(alpha = 0.2f) else AirportNavySurface
        ),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier.border(
            width = 1.dp,
            color = if (isAlert) AlertRed else AirportNavyElevated,
            shape = RoundedCornerShape(10.dp)
        )
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(text = title, color = Color.Gray, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                color = if (isAlert) AlertRed else PureWhite,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun SensorIndicator(label: String, isActive: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(if (isActive) AlertRed else SuccessGreen)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            color = if (isActive) AlertRed else PureWhite,
            fontSize = 11.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
        )
    }
}
