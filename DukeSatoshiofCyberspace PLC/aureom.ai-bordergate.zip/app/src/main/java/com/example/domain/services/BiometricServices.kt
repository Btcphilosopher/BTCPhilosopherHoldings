package com.example.domain.services

import com.example.data.model.AttackType
import com.example.data.model.FaceComparisonResult
import com.example.data.model.PadAssessment

/**
 * Presentation Attack Detection (Liveness) interface.
 * Complies with ISO/IEC 30107 standards.
 */
interface PresentationAttackDetectionService {
    suspend fun evaluateLiveness(simulateSpoof: Boolean = false): PadAssessment
}

class SimulatedPadService : PresentationAttackDetectionService {
    override suspend fun evaluateLiveness(simulateSpoof: Boolean): PadAssessment {
        return if (simulateSpoof) {
            PadAssessment(
                isLive = false,
                padScore = 24.5f,
                detectedAttackType = AttackType.SCREEN_VIDEO_REPLAY,
                padEngineVersion = "ISO-30107-AureomPAD-v2.6.1"
            )
        } else {
            PadAssessment(
                isLive = true,
                padScore = 96.8f,
                detectedAttackType = AttackType.NONE,
                padEngineVersion = "ISO-30107-AureomPAD-v2.6.1"
            )
        }
    }
}

/**
 * Facial comparison adapter comparing probe face to chip DG2 photo.
 * Stores matcher engine version and threshold policy version.
 * Explicit note: similarity score is NOT a probability of identity.
 */
interface FaceComparisonService {
    suspend fun compareFaces(
        isSpecimenMatch: Boolean = true,
        forceLowMatchScore: Boolean = false
    ): FaceComparisonResult
}

class SimulatedFaceComparisonService : FaceComparisonService {
    override suspend fun compareFaces(
        isSpecimenMatch: Boolean,
        forceLowMatchScore: Boolean
    ): FaceComparisonResult {
        val score = if (!isSpecimenMatch || forceLowMatchScore) {
            51.4f // Below standard operational threshold of 75.0
        } else {
            88.7f // Strong verified similarity
        }

        val operationalThreshold = 75.0f
        val isMatch = score >= operationalThreshold

        return FaceComparisonResult(
            similarityScore = score,
            operationalThreshold = operationalThreshold,
            isMatch = isMatch,
            matcherEngineVersion = "Aureom-FacialMatch-v4.1.2-ICAO",
            thresholdPolicyVersion = "UKBF-BIOMETRIC-EVAL-POL-2026.2",
            reviewRecommended = !isMatch
        )
    }
}
