package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QualityMetrics
import com.example.ui.theme.AirportNavyDark
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

@Composable
fun PassportViewfinder(
    qualityMetrics: QualityMetrics,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "laser")
    val laserY by infiniteTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laserY"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(280.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(AirportNavyDark)
            .border(2.dp, CyanPrimary.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
        contentAlignment = Alignment.Center
    ) {
        // Scanner Viewfinder Canvas with bounding box and MRZ guide
        Canvas(modifier = Modifier.fillMaxSize()) {
            val padX = size.width * 0.08f
            val padY = size.height * 0.10f
            val docWidth = size.width - (padX * 2)
            val docHeight = size.height - (padY * 2)

            // Outer passport guide rectangle
            drawRoundRect(
                color = CyanPrimary.copy(alpha = 0.8f),
                topLeft = Offset(padX, padY),
                size = Size(docWidth, docHeight),
                cornerRadius = CornerRadius(12f, 12f),
                style = Stroke(
                    width = 3.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 12f), 0f)
                )
            )

            // Photo area box on left
            val photoW = docWidth * 0.32f
            val photoH = docHeight * 0.52f
            drawRoundRect(
                color = Color.White.copy(alpha = 0.15f),
                topLeft = Offset(padX + 16f, padY + 16f),
                size = Size(photoW, photoH),
                cornerRadius = CornerRadius(8f, 8f)
            )

            // MRZ bottom band (chevrons <<<<<<)
            val mrzH = docHeight * 0.28f
            val mrzTop = padY + docHeight - mrzH
            drawRoundRect(
                color = if (qualityMetrics.glareDetected) AlertRed.copy(alpha = 0.25f) else CyanPrimary.copy(alpha = 0.15f),
                topLeft = Offset(padX + 8f, mrzTop),
                size = Size(docWidth - 16f, mrzH - 8f),
                cornerRadius = CornerRadius(6f, 6f)
            )

            // Animated Laser scanning beam
            val scanY = padY + (docHeight * laserY)
            drawLine(
                color = if (qualityMetrics.glareDetected) AlertRed else CyanPrimary,
                start = Offset(padX + 10f, scanY),
                end = Offset(padX + docWidth - 10f, scanY),
                strokeWidth = 3.dp.toPx()
            )
        }

        // Live Quality Overlay Status Bar
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.75f))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                QualityTag(
                    label = "Glare",
                    isValid = !qualityMetrics.glareDetected,
                    invalidText = "GLARE DETECTED"
                )
                QualityTag(
                    label = "Focus / Blur",
                    isValid = qualityMetrics.blurScore >= 0.70f,
                    invalidText = "BLURRY"
                )
                QualityTag(
                    label = "MRZ Chevrons",
                    isValid = qualityMetrics.framingScore >= 0.75f,
                    invalidText = "MISALIGNED"
                )
            }
        }
    }
}

@Composable
private fun QualityTag(
    label: String,
    isValid: Boolean,
    invalidText: String
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = if (isValid) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint = if (isValid) SuccessGreen else AlertRed,
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.size(4.dp))
        Text(
            text = if (isValid) "$label: OK" else invalidText,
            color = if (isValid) PureWhite else AlertRed,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
