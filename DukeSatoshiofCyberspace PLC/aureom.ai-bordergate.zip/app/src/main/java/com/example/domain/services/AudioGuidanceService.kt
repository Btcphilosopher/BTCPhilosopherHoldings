package com.example.domain.services

import android.content.Context
import android.speech.tts.TextToSpeech
import com.example.data.model.KioskLanguage
import java.util.Locale

class AudioGuidanceService(context: Context) {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isInitialized = true
                tts?.language = Locale.UK
            }
        }
    }

    fun speak(text: String, language: KioskLanguage = KioskLanguage.EN) {
        if (!isInitialized) return

        val locale = when (language) {
            KioskLanguage.EN -> Locale.UK
            KioskLanguage.FR -> Locale.FRANCE
            KioskLanguage.ES -> Locale("es", "ES")
            KioskLanguage.DE -> Locale.GERMANY
            KioskLanguage.JA -> Locale.JAPAN
            KioskLanguage.AR -> Locale("ar")
        }

        try {
            tts?.language = locale
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "BG_AUDIO_${System.currentTimeMillis()}")
        } catch (_: Exception) {
            // Audio guidance fallback silently if speech engine missing locale
        }
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
