package com.example.ui.screens.kiosk

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.fixtures.SpecimenPassport
import com.example.data.fixtures.SpecimenPassports
import com.example.data.model.ActiveSessionState
import com.example.data.model.CaptureStatus
import com.example.domain.services.PassportCaptureService
import com.example.ui.components.KioskProgressBar
import com.example.ui.components.PassportViewfinder
import com.example.ui.theme.AirportNavyDark
import com.example.ui.theme.AirportNavyElevated
import com.example.ui.theme.AirportNavySurface
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarningAmber

@Composable
fun PassportScanScreen(
    sessionState: ActiveSessionState,
    currentSpecimen: SpecimenPassport,
    captureService: PassportCaptureService,
    onSelectSpecimen: (SpecimenPassport) -> Unit,
    onCapture: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val qualityMetrics by captureService.liveQualityMetrics.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AirportNavyDark)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            KioskProgressBar(currentStep = sessionState.step)

            Text(
                text = "Place Passport on Scanner",
                color = PureWhite,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )

            Text(
                text = "Align photo page face-down. Ensure bottom chevron lines (<<<<) are flat.",
                color = TextMuted,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }

        // Live Scanner Viewfinder with MRZ boundary
        PassportViewfinder(
            qualityMetrics = qualityMetrics,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        // Synthetic Specimen Quick-Selector Bar (Clear ICAO fixtures)
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Synthetic Test Fixtures (SPECIMEN — NOT VALID FOR TRAVEL):",
                color = WarningAmber,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SpecimenPassports.ALL.forEach { specimen ->
                    val isSelected = specimen.id == currentSpecimen.id
                    val bg = if (isSelected) CyanPrimary.copy(alpha = 0.25f) else AirportNavyElevated
                    val border = if (isSelected) CyanPrimary else Color.Transparent

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(bg)
                            .border(1.5.dp, border, RoundedCornerShape(8.dp))
                            .clickable { onSelectSpecimen(specimen) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("specimen_${specimen.id}")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = specimen.countryFlag, fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = specimen.holderName,
                                    color = if (isSelected) CyanPrimary else PureWhite,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${specimen.country} (${specimen.docNumber})",
                                    color = Color.Gray,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Status or Error Feedback Banner
        if (sessionState.passportResult?.status == CaptureStatus.UNREADABLE_MRZ ||
            sessionState.passportResult?.status == CaptureStatus.GLARE_DETECTED
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = AlertRed.copy(alpha = 0.15f)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AlertRed, RoundedCornerShape(8.dp))
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = AlertRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Unreadable MRZ: Glare or checksum mismatch detected. Please adjust document and press Scan.",
                        color = AlertRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Action Buttons Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = onCancel,
                colors = ButtonDefaults.buttonColors(containerColor = AirportNavyElevated, contentColor = PureWhite),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(0.35f)
                    .height(56.dp)
                    .testTag("passport_cancel_button")
            ) {
                Text(text = "Cancel", fontSize = 14.sp)
            }

            Button(
                onClick = onCapture,
                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = AirportNavyDark),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(0.65f)
                    .height(56.dp)
                    .testTag("passport_capture_button")
            ) {
                Icon(imageVector = Icons.Default.DocumentScanner, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Capture Document",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
