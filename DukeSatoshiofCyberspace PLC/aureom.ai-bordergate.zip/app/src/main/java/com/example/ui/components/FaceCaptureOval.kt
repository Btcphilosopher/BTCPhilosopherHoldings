package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FaceCaptureMetrics
import com.example.data.model.FaceStatus
import com.example.ui.theme.AirportNavyDark
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

@Composable
fun FaceCaptureOval(
    metrics: FaceCaptureMetrics,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val scanLineY by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scanLineY"
    )

    val ovalColor = when {
        metrics.faceStatus == FaceStatus.MULTI_PERSON_DETECTED -> AlertRed
        metrics.faceStatus == FaceStatus.POOR_LIGHTING -> WarningAmber
        else -> CyanPrimary
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(300.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(AirportNavyDark)
            .border(2.dp, ovalColor.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val ovalW = size.width * 0.46f * pulse
            val ovalH = size.height * 0.72f * pulse

            // Outer dark vignette
            drawRect(color = Color.Black.copy(alpha = 0.35f))

            // Oval face guide
            drawOval(
                color = ovalColor,
                topLeft = Offset(cx - (ovalW / 2f), cy - (ovalH / 2f)),
                size = Size(ovalW, ovalH),
                style = Stroke(
                    width = 3.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 10f), 0f)
                )
            )

            // Eye Level guide line
            val eyeY = cy - (ovalH * 0.15f)
            drawLine(
                color = ovalColor.copy(alpha = 0.6f),
                start = Offset(cx - (ovalW * 0.35f), eyeY),
                end = Offset(cx + (ovalW * 0.35f), eyeY),
                strokeWidth = 1.5.dp.toPx()
            )

            // Biometric scanning line
            val scanY = cy - (ovalH / 2f) + (ovalH * scanLineY)
            drawLine(
                color = ovalColor.copy(alpha = 0.85f),
                start = Offset(cx - (ovalW * 0.42f), scanY),
                end = Offset(cx + (ovalW * 0.42f), scanY),
                strokeWidth = 2.5.dp.toPx()
            )
        }

        // Real-time quality feedback strip
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.8f))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                QualityTag(
                    label = "Single Person",
                    isValid = metrics.singlePersonFramed,
                    invalidText = "MULTIPLE PEOPLE DETECTED"
                )
                QualityTag(
                    label = "Lighting",
                    isValid = metrics.lightingScore >= 0.70f,
                    invalidText = "POOR LIGHT"
                )
                QualityTag(
                    label = "Centering",
                    isValid = metrics.qualityScore >= 0.80f,
                    invalidText = "LOOK FORWARD"
                )
            }
        }
    }
}

@Composable
private fun QualityTag(
    label: String,
    isValid: Boolean,
    invalidText: String
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = if (isValid) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint = if (isValid) SuccessGreen else AlertRed,
            modifier = Modifier.size(13.dp)
        )
        Spacer(modifier = Modifier.size(4.dp))
        Text(
            text = if (isValid) "$label: OK" else invalidText,
            color = if (isValid) PureWhite else AlertRed,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
