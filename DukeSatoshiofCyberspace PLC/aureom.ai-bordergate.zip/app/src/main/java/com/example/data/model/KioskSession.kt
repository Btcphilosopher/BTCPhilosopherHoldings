package com.example.data.model

enum class KioskStep {
    WELCOME,
    PASSPORT_SCAN,
    CHIP_READ,
    FACE_CAPTURE,
    PROCESSING,
    PROCEED,
    OFFICER_ASSISTANCE
}

enum class KioskLanguage(val code: String, val displayName: String, val flag: String) {
    EN("en", "English", "🇬🇧"),
    FR("fr", "Français", "🇫🇷"),
    ES("es", "Español", "🇪🇸"),
    DE("de", "Deutsch", "🇩🇪"),
    JA("ja", "日本語", "🇯🇵"),
    AR("ar", "العربية", "🇦🇪")
}

enum class DemoScenario(val id: Int, val title: String, val description: String) {
    SCENARIO_1_HAPPY_PATH(1, "1. Standard Clearance", "Successful synthetic traveller verification and passage"),
    SCENARIO_2_UNREADABLE_MRZ(2, "2. Unreadable MRZ", "Blurry/glare scan prompting guided traveller retry"),
    SCENARIO_3_NFC_INTERRUPT(3, "3. NFC Interruption", "Premature passport removal during chip reading"),
    SCENARIO_4_UNTRUSTED_SIGNER(4, "4. Untrusted Signer", "Passive auth fails: signer cert not in national PKD"),
    SCENARIO_5_FACE_REFERRAL(5, "5. Biometric Mismatch", "Face similarity below threshold routes to officer"),
    SCENARIO_6_SERVICE_OUTAGE(6, "6. Service Outage", "Border decision authority unreachable"),
    SCENARIO_7_EXPIRED_AUTH(7, "7. Expired Passage Auth", "Authorisation TTL expires before traveller enters gate"),
    SCENARIO_8_GATE_OBSTRUCTION(8, "8. Obstructed Gate", "Barrier safety curtain interrupted during transit"),
    SCENARIO_9_MULTI_PERSON(9, "9. Multi-Person Detection", "More than one face in frame halts biometric capture"),
    SCENARIO_10_OFFICER_ASSISTED(10, "10. Officer Resolution", "Manual officer inspection and logged override")
}

data class ActiveSessionState(
    val sessionId: String = "",
    val step: KioskStep = KioskStep.WELCOME,
    val language: KioskLanguage = KioskLanguage.EN,
    val activeScenario: DemoScenario = DemoScenario.SCENARIO_1_HAPPY_PATH,
    val passportResult: DocumentCaptureResult? = null,
    val chipResult: ChipData? = null,
    val biometricResult: FaceVerificationSession? = null,
    val decision: PassageDecision? = null,
    val sessionStartEpochMs: Long = System.currentTimeMillis(),
    val isDemoMode: Boolean = true,
    val audioGuidanceEnabled: Boolean = true,
    val statusBannerText: String? = null
)
