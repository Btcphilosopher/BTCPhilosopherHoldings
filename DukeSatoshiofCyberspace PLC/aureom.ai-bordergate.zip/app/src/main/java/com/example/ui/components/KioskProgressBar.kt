package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Contactless
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.KioskStep
import com.example.ui.theme.AirportNavyDark
import com.example.ui.theme.AirportNavyElevated
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SuccessGreen

data class StepInfo(
    val step: KioskStep,
    val label: String,
    val icon: ImageVector
)

val KIOSK_STEPS = listOf(
    StepInfo(KioskStep.PASSPORT_SCAN, "Passport", Icons.Default.MenuBook),
    StepInfo(KioskStep.CHIP_READ, "Chip Read", Icons.Default.Contactless),
    StepInfo(KioskStep.FACE_CAPTURE, "Face Scan", Icons.Default.Face),
    StepInfo(KioskStep.PROCESSING, "Verify", Icons.Default.VerifiedUser),
    StepInfo(KioskStep.PROCEED, "Proceed", Icons.Default.MeetingRoom)
)

@Composable
fun KioskProgressBar(
    currentStep: KioskStep,
    modifier: Modifier = Modifier
) {
    if (currentStep == KioskStep.WELCOME || currentStep == KioskStep.OFFICER_ASSISTANCE) {
        return
    }

    val currentIndex = KIOSK_STEPS.indexOfFirst { it.step == currentStep }.let {
        if (it == -1) 0 else it
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        KIOSK_STEPS.forEachIndexed { index, stepInfo ->
            val isCompleted = index < currentIndex
            val isCurrent = index == currentIndex

            val stepColor by animateColorAsState(
                targetValue = when {
                    isCompleted -> SuccessGreen
                    isCurrent -> CyanPrimary
                    else -> Color.DarkGray
                },
                label = "stepColor"
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            ) {
                // Circle Node
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isCurrent) CyanPrimary.copy(alpha = 0.2f) else AirportNavyDark)
                        .border(
                            width = if (isCurrent) 2.dp else 1.dp,
                            color = stepColor,
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Completed",
                            tint = SuccessGreen,
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        Icon(
                            imageVector = stepInfo.icon,
                            contentDescription = stepInfo.label,
                            tint = if (isCurrent) CyanPrimary else Color.Gray,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = stepInfo.label,
                    color = if (isCurrent) PureWhite else Color.Gray,
                    fontSize = 11.sp,
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
                )
            }

            // Connector Line between steps
            if (index < KIOSK_STEPS.size - 1) {
                val lineColor = if (index < currentIndex) SuccessGreen else Color.DarkGray
                Box(
                    modifier = Modifier
                        .height(2.dp)
                        .weight(0.8f)
                        .background(lineColor)
                )
            }
        }
    }
}
