package com.example.data.model

enum class BarrierPosition {
    CLOSED,
    OPENING,
    FULLY_OPEN,
    CLOSING,
    OBSTRUCTED_REOPENING,
    LOCKED_FAULT
}

enum class GateOccupancy {
    CLEAR,
    OCCUPIED_ENTERING,
    OCCUPIED_IN_CHAMBER,
    OCCUPIED_EXITING,
    TAILGATING_DETECTED
}

enum class GateControllerStatus {
    CONNECTED,
    DISCONNECTED,
    DEGRADED,
    HARDWARE_FAULT
}

data class GateHardwareState(
    val entryBarrier: BarrierPosition = BarrierPosition.CLOSED,
    val exitBarrier: BarrierPosition = BarrierPosition.CLOSED,
    val occupancy: GateOccupancy = GateOccupancy.CLEAR,
    val beamAInterrupted: Boolean = false, // Entry light curtain
    val beamBInterrupted: Boolean = false, // Center chamber sensor
    val beamCInterrupted: Boolean = false, // Exit light curtain
    val obstructionActive: Boolean = false,
    val tailgatingAlarm: Boolean = false,
    val emergencyStopEngaged: Boolean = false,
    val controllerStatus: GateControllerStatus = GateControllerStatus.CONNECTED,
    val heartbeatLatencyMs: Long = 12L,
    val activePassageToken: String? = null,
    val confirmedTransitCompleted: Boolean = false,
    val faultMessage: String? = null
)
