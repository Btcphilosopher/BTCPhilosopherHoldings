package com.example.domain.services

import com.example.data.model.ChipData
import com.example.data.model.ChipReadStatus
import com.example.data.model.MrzData
import com.example.data.model.PassiveAuthStatus
import java.util.Calendar

data class DocumentAuthenticationResult(
    val isOcrChecksumValid: Boolean,
    val isChipReadSuccessful: Boolean,
    val isPassiveAuthValid: Boolean,
    val isSignerTrusted: Boolean,
    val isActiveAuthValid: Boolean,
    val isDocumentNotExpired: Boolean,
    val isDocumentAuthentic: Boolean,
    val securityEvaluationSummary: String
)

interface DocumentAuthenticationService {
    fun authenticateDocument(mrzData: MrzData?, chipData: ChipData?): DocumentAuthenticationResult
}

class StandardDocumentAuthenticationService : DocumentAuthenticationService {

    override fun authenticateDocument(mrzData: MrzData?, chipData: ChipData?): DocumentAuthenticationResult {
        if (mrzData == null) {
            return DocumentAuthenticationResult(
                isOcrChecksumValid = false,
                isChipReadSuccessful = false,
                isPassiveAuthValid = false,
                isSignerTrusted = false,
                isActiveAuthValid = false,
                isDocumentNotExpired = false,
                isDocumentAuthentic = false,
                securityEvaluationSummary = "No MRZ document data captured."
            )
        }

        val ocrChecksumsValid = mrzData.checkResult.allValid

        // Parse expiry and check against current year/month/day
        val expiryStr = mrzData.parsedExpiryDate
        val notExpired = isFutureDate(expiryStr)

        val chipReadSuccess = chipData?.chipReadStatus == ChipReadStatus.SUCCESS
        val passiveValid = chipData?.passiveAuthStatus == PassiveAuthStatus.VERIFIED
        val signerTrusted = chipData?.passiveAuthStatus != PassiveAuthStatus.UNTRUSTED_SIGNER &&
                chipData?.passiveAuthStatus != PassiveAuthStatus.UNAVAILABLE
        val activeValid = chipData?.activeAuthPassed ?: false

        // Document is considered authentic ONLY if chip passive auth passes with trusted signer and not expired
        val authentic = ocrChecksumsValid && chipReadSuccess && passiveValid && signerTrusted && notExpired

        val summary = when {
            !ocrChecksumsValid -> "MRZ Checksum Failure: check digits do not match ICAO 9303 algorithm."
            !notExpired -> "Document Expired: document date of expiry has lapsed."
            !chipReadSuccess -> "NFC Chip read failure or interruption."
            !signerTrusted -> "Untrusted Signer: CSCA root cert not found in National ICAO PKD trust store."
            !passiveValid -> "Passive Authentication Hash Mismatch: Data Groups altered."
            authentic -> "Document Authentic: ICAO Doc 9303 checksums, SOD signature, and PKD trust validated."
            else -> "Document verification unresolved."
        }

        return DocumentAuthenticationResult(
            isOcrChecksumValid = ocrChecksumsValid,
            isChipReadSuccessful = chipReadSuccess,
            isPassiveAuthValid = passiveValid,
            isSignerTrusted = signerTrusted,
            isActiveAuthValid = activeValid,
            isDocumentNotExpired = notExpired,
            isDocumentAuthentic = authentic,
            securityEvaluationSummary = summary
        )
    }

    private fun isFutureDate(isoDate: String): Boolean {
        if (isoDate == "INVALID" || isoDate.length < 10) return false
        val parts = isoDate.split("-")
        if (parts.size != 3) return false
        val year = parts[0].toIntOrNull() ?: return false
        val month = parts[1].toIntOrNull() ?: return false
        val day = parts[2].toIntOrNull() ?: return false

        val cal = Calendar.getInstance()
        val currentYear = cal.get(Calendar.YEAR)
        val currentMonth = cal.get(Calendar.MONTH) + 1
        val currentDay = cal.get(Calendar.DAY_OF_MONTH)

        return when {
            year > currentYear -> true
            year < currentYear -> false
            month > currentMonth -> true
            month < currentMonth -> false
            else -> day >= currentDay
        }
    }
}
