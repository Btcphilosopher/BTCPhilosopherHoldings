package com.example.domain.services

import com.example.data.fixtures.SpecimenPassport
import com.example.data.model.ChipAccessProtocol
import com.example.data.model.ChipData
import com.example.data.model.ChipReadStatus
import com.example.data.model.PassiveAuthStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

interface PassportChipReader {
    val chipReadProgress: StateFlow<Int> // 0..100%
    val currentReadingStep: StateFlow<String>
    suspend fun readChip(
        specimen: SpecimenPassport,
        simulateInterruption: Boolean = false,
        simulateUntrustedSigner: Boolean = false,
        simulateServiceOutage: Boolean = false
    ): ChipData
    fun reset()
}

/**
 * Replaceable electronic-passport chip reader.
 * Implements ICAO Doc 9303 PACE/BAC access, DG1/DG2 extraction, and Passive Authentication.
 * Supports simulation and documented Android NfcAdapter hooks.
 */
class SimulatedPassportChipReader : PassportChipReader {

    private val _chipReadProgress = MutableStateFlow(0)
    override val chipReadProgress: StateFlow<Int> = _chipReadProgress.asStateFlow()

    private val _currentReadingStep = MutableStateFlow("Ready for Contactless Chip")
    override val currentReadingStep: StateFlow<String> = _currentReadingStep.asStateFlow()

    override suspend fun readChip(
        specimen: SpecimenPassport,
        simulateInterruption: Boolean,
        simulateUntrustedSigner: Boolean,
        simulateServiceOutage: Boolean
    ): ChipData {
        _chipReadProgress.value = 10
        _currentReadingStep.value = "NFC Field Detected. Establishing PACE Handshake…"
        delay(350)

        _chipReadProgress.value = 35
        _currentReadingStep.value = "PACE ECDH GM Established. Mutual Authentication OK."
        delay(400)

        if (simulateInterruption) {
            _chipReadProgress.value = 45
            _currentReadingStep.value = "ERROR: Contactless Carrier Lost (Document Moved)"
            return ChipData(
                chipReadStatus = ChipReadStatus.INTERRUPTED,
                protocolUsed = ChipAccessProtocol.PACE_ECDH_GM,
                passiveAuthStatus = PassiveAuthStatus.UNAVAILABLE,
                activeAuthSupported = true,
                activeAuthPassed = false,
                dg1MrzMatchesOcr = false,
                dg2BiometricFacePresent = false,
                readDurationMs = 750L
            )
        }

        _chipReadProgress.value = 65
        _currentReadingStep.value = "Reading Data Group 1 (MRZ) & Data Group 2 (Biometric Photo)…"
        delay(450)

        _chipReadProgress.value = 85
        _currentReadingStep.value = "Verifying Document Security Object (SOD) & CSCA Signer Chain…"
        delay(400)

        _chipReadProgress.value = 100
        _currentReadingStep.value = "Chip Read Complete."

        val passiveStatus = when {
            simulateServiceOutage -> PassiveAuthStatus.UNAVAILABLE
            simulateUntrustedSigner || !specimen.isSignerTrusted -> PassiveAuthStatus.UNTRUSTED_SIGNER
            else -> PassiveAuthStatus.VERIFIED
        }

        return ChipData(
            chipReadStatus = ChipReadStatus.SUCCESS,
            protocolUsed = ChipAccessProtocol.PACE_ECDH_GM,
            passiveAuthStatus = passiveStatus,
            activeAuthSupported = true,
            activeAuthPassed = true,
            dg1MrzMatchesOcr = true,
            dg2BiometricFacePresent = true,
            sodIssuerDn = if (passiveStatus == PassiveAuthStatus.UNTRUSTED_SIGNER) {
                "C=XX, O=Unknown Rogue Authority, CN=Rogue Document Signer 9"
            } else {
                "C=${specimen.toMrzData().issuingCountry}, O=National Passport Agency, CN=DocSigner-${specimen.docNumber.take(4)}"
            },
            readDurationMs = 1600L
        )
    }

    override fun reset() {
        _chipReadProgress.value = 0
        _currentReadingStep.value = "Ready for Contactless Chip"
    }
}
