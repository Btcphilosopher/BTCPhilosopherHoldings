package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DemoScenario
import com.example.ui.theme.AirportNavyDark
import com.example.ui.theme.AirportNavyElevated
import com.example.ui.theme.AirportNavySurface
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.CyanTeal
import com.example.ui.theme.OfficerAccentGold
import com.example.ui.theme.PureWhite
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.AppWorkspace

@Composable
fun DemoBanner(
    activeScenario: DemoScenario,
    currentWorkspace: AppWorkspace,
    audioGuidanceEnabled: Boolean,
    onSelectWorkspace: (AppWorkspace) -> Unit,
    onSelectScenario: (DemoScenario) -> Unit,
    onToggleAudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    var scenarioDropdownOpen by remember { mutableStateOf(false) }

    Surface(
        color = AirportNavyDark,
        tonalElevation = 6.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            // Top Ribbon: Demonstration Notice & Workspace Switcher
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Brand + Specimen Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(WarningAmber.copy(alpha = 0.2f))
                            .border(1.dp, WarningAmber, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "DEMONSTRATION SPECIMEN",
                            color = WarningAmber,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = "AUREOM.AI BORDERGATE",
                        color = PureWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                }

                // Audio guidance toggle
                IconButton(
                    onClick = onToggleAudio,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("audio_guidance_toggle")
                ) {
                    Icon(
                        imageVector = if (audioGuidanceEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                        contentDescription = "Toggle Audio Guidance",
                        tint = if (audioGuidanceEnabled) CyanPrimary else Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Workspace Pills
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    WorkspaceTabButton(
                        title = "Kiosk",
                        icon = Icons.Default.Security,
                        isSelected = currentWorkspace == AppWorkspace.KIOSK,
                        testTag = "tab_kiosk",
                        onClick = { onSelectWorkspace(AppWorkspace.KIOSK) }
                    )
                    WorkspaceTabButton(
                        title = "Gate Sim",
                        icon = Icons.Default.Sensors,
                        isSelected = currentWorkspace == AppWorkspace.GATE_SIMULATOR,
                        testTag = "tab_gate_sim",
                        onClick = { onSelectWorkspace(AppWorkspace.GATE_SIMULATOR) }
                    )
                    WorkspaceTabButton(
                        title = "Officer",
                        icon = Icons.Default.AltRoute,
                        isSelected = currentWorkspace == AppWorkspace.OFFICER_CONSOLE,
                        accentColor = OfficerAccentGold,
                        testTag = "tab_officer",
                        onClick = { onSelectWorkspace(AppWorkspace.OFFICER_CONSOLE) }
                    )
                }
            }

            // Quick Scenario Selector Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Scenario: ",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Box {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(AirportNavyElevated)
                            .border(1.dp, CyanTeal.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .clickable { scenarioDropdownOpen = true }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("scenario_selector_dropdown"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${activeScenario.title} ▾",
                            color = CyanPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    DropdownMenu(
                        expanded = scenarioDropdownOpen,
                        onDismissRequest = { scenarioDropdownOpen = false },
                        modifier = Modifier.background(AirportNavySurface)
                    ) {
                        DemoScenario.values().forEach { scn ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = scn.title,
                                            fontWeight = if (scn == activeScenario) FontWeight.Bold else FontWeight.Normal,
                                            color = if (scn == activeScenario) CyanPrimary else PureWhite,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = scn.description,
                                            color = Color.Gray,
                                            fontSize = 10.sp
                                        )
                                    }
                                },
                                onClick = {
                                    scenarioDropdownOpen = false
                                    onSelectScenario(scn)
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = activeScenario.description,
                    color = Color.Gray,
                    fontSize = 10.sp,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun WorkspaceTabButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    testTag: String,
    accentColor: Color = CyanPrimary,
    onClick: () -> Unit
) {
    val bg = if (isSelected) accentColor.copy(alpha = 0.2f) else AirportNavyElevated
    val border = if (isSelected) accentColor else Color.Transparent
    val contentColor = if (isSelected) accentColor else Color.LightGray

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag(testTag)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier.size(13.dp)
            )
            Text(
                text = title,
                color = contentColor,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}
