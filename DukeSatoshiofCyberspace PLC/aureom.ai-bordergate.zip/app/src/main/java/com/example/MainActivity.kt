package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.data.model.KioskStep
import com.example.ui.components.DemoBanner
import com.example.ui.screens.kiosk.ChipReadScreen
import com.example.ui.screens.kiosk.FaceCaptureScreen
import com.example.ui.screens.kiosk.OfficerAssistanceScreen
import com.example.ui.screens.kiosk.PassportScanScreen
import com.example.ui.screens.kiosk.ProceedScreen
import com.example.ui.screens.kiosk.ProcessingScreen
import com.example.ui.screens.kiosk.WelcomeScreen
import com.example.ui.screens.officer.OfficerConsoleScreen
import com.example.ui.screens.simulator.GateSimulatorScreen
import com.example.ui.theme.AirportNavyDark
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppWorkspace
import com.example.ui.viewmodel.BorderGateViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: BorderGateViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme(darkTheme = true) {
                val workspace by viewModel.currentWorkspace.collectAsState()
                val sessionState by viewModel.sessionState.collectAsState()
                val gateState by viewModel.gateState.collectAsState()
                val activeRole by viewModel.activeOfficerRole.collectAsState()
                val currentSpecimen by viewModel.currentSpecimen.collectAsState()
                val auditLogs by viewModel.auditLogs.collectAsState()

                BackHandler(enabled = workspace != AppWorkspace.KIOSK || sessionState.step != KioskStep.WELCOME) {
                    if (workspace != AppWorkspace.KIOSK) {
                        viewModel.selectWorkspace(AppWorkspace.KIOSK)
                    } else if (sessionState.step != KioskStep.WELCOME) {
                        viewModel.startNewSession()
                    }
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(AirportNavyDark),
                    topBar = {
                        DemoBanner(
                            activeScenario = sessionState.activeScenario,
                            currentWorkspace = workspace,
                            audioGuidanceEnabled = sessionState.audioGuidanceEnabled,
                            onSelectWorkspace = { viewModel.selectWorkspace(it) },
                            onSelectScenario = { viewModel.loadScenario(it) },
                            onToggleAudio = { viewModel.toggleAudioGuidance() }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(AirportNavyDark)
                    ) {
                        when (workspace) {
                            AppWorkspace.KIOSK -> {
                                when (sessionState.step) {
                                    KioskStep.WELCOME -> {
                                        WelcomeScreen(
                                            currentLanguage = sessionState.language,
                                            onSelectLanguage = { viewModel.setLanguage(it) },
                                            onStartKiosk = { viewModel.onProceedFromWelcome() }
                                        )
                                    }
                                    KioskStep.PASSPORT_SCAN -> {
                                        PassportScanScreen(
                                            sessionState = sessionState,
                                            currentSpecimen = currentSpecimen,
                                            captureService = viewModel.passportCaptureService,
                                            onSelectSpecimen = { viewModel.setSpecimen(it) },
                                            onCapture = { viewModel.executePassportCapture() },
                                            onCancel = { viewModel.startNewSession() }
                                        )
                                    }
                                    KioskStep.CHIP_READ -> {
                                        ChipReadScreen(
                                            sessionState = sessionState,
                                            chipReader = viewModel.passportChipReader
                                        )
                                    }
                                    KioskStep.FACE_CAPTURE -> {
                                        FaceCaptureScreen(
                                            sessionState = sessionState,
                                            faceCaptureService = viewModel.faceCaptureService,
                                            onTriggerCapture = { viewModel.executeFaceCapture() }
                                        )
                                    }
                                    KioskStep.PROCESSING -> {
                                        ProcessingScreen(
                                            sessionState = sessionState
                                        )
                                    }
                                    KioskStep.PROCEED -> {
                                        ProceedScreen(
                                            sessionState = sessionState,
                                            gateState = gateState,
                                            onCompleteSession = { viewModel.startNewSession() }
                                        )
                                    }
                                    KioskStep.OFFICER_ASSISTANCE -> {
                                        OfficerAssistanceScreen(
                                            sessionState = sessionState,
                                            onResetToWelcome = { viewModel.startNewSession() },
                                            onOpenOfficerConsole = { viewModel.selectWorkspace(AppWorkspace.OFFICER_CONSOLE) }
                                        )
                                    }
                                }
                            }
                            AppWorkspace.GATE_SIMULATOR -> {
                                GateSimulatorScreen(
                                    gateState = gateState,
                                    gateController = viewModel.gateController,
                                    onBackToKiosk = { viewModel.selectWorkspace(AppWorkspace.KIOSK) }
                                )
                            }
                            AppWorkspace.OFFICER_CONSOLE -> {
                                OfficerConsoleScreen(
                                    activeSession = sessionState,
                                    currentSpecimen = currentSpecimen,
                                    activeRole = activeRole,
                                    auditLogs = auditLogs,
                                    onSetRole = { viewModel.setOfficerRole(it) },
                                    onApproveOverride = { comment, badge ->
                                        viewModel.officerApproveOverride(comment, badge)
                                    },
                                    onConfirmReferral = { comment, badge ->
                                        viewModel.officerConfirmReferral(comment, badge)
                                    },
                                    onClearAudits = { viewModel.clearAuditHistory() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
