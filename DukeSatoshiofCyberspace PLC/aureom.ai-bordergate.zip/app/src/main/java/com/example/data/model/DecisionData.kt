package com.example.data.model

import java.util.UUID

enum class DecisionOutcome {
    APPROVED,
    REFER_TO_OFFICER,
    RETRY_CAPTURE,
    SERVICE_UNAVAILABLE,
    REJECTED
}

enum class ReasonCode {
    CLEARANCE_GRANTED,
    MRZ_CHECKSUM_FAILURE,
    UNTRUSTED_DOCUMENT_SIGNER,
    PASSIVE_AUTH_FAILED,
    CHIP_READ_INTERRUPTED,
    BIOMETRIC_LOW_SIMILARITY,
    BIOMETRIC_PAD_SPOOF_SUSPECTED,
    MULTIPLE_PERSONS_IN_FRAME,
    DOCUMENT_EXPIRED,
    BORDER_SERVICE_OUTAGE,
    GATE_OBSTRUCTED,
    AUTHORISATION_EXPIRED,
    MANUAL_OFFICER_APPROVED,
    MANUAL_OFFICER_REFERRED,
    TOKEN_REPLAY_REJECTED
}

/**
 * Authorised passage decision bound to session ID, gate ID, and expiry timestamp.
 * Single-use token prevents replay or reuse.
 */
data class PassageDecision(
    val sessionId: String = UUID.randomUUID().toString(),
    val gateId: String = "EGATE-LHR-T5-04",
    val timestamp: Long = System.currentTimeMillis(),
    val outcome: DecisionOutcome,
    val travellerPublicSummary: String, // Neutral, non-sensitive wording for traveller
    val internalReasonCode: ReasonCode, // Detailed code for authorised staff
    val policyVersion: String = "UKBF-AUTOGATE-POL-2026.4",
    val validUntilEpochMs: Long = System.currentTimeMillis() + 30_000L, // 30-sec expiry window
    val singleUseToken: String = UUID.randomUUID().toString(),
    var isConsumed: Boolean = false
) {
    val isExpired: Boolean
        get() = System.currentTimeMillis() > validUntilEpochMs

    val canOpenGate: Boolean
        get() = outcome == DecisionOutcome.APPROVED && !isExpired && !isConsumed
}
