package com.example.domain.services

import com.example.data.model.BarrierPosition
import com.example.data.model.GateControllerStatus
import com.example.data.model.GateHardwareState
import com.example.data.model.GateOccupancy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

interface GateController {
    val hardwareState: StateFlow<GateHardwareState>
    fun authorizePassage(sessionId: String, singleUseToken: String, timeoutMs: Long = 20_000L): Boolean
    fun simulatePassageSequence(withObstruction: Boolean = false, withTailgating: Boolean = false)
    fun triggerObstruction()
    fun triggerTailgating()
    fun triggerEmergencyStop()
    fun resetFault()
    fun disconnectController()
    fun reconnectController()
}

/**
 * Gate Controller Boundary.
 * Android orchestrates high-level decisions and sends bounded passage requests.
 * The physical controller state machine owns actuator timing, interlocks, and obstruction rebound.
 */
class SimulatedGateController(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) : GateController {

    private val _hardwareState = MutableStateFlow(GateHardwareState())
    override val hardwareState: StateFlow<GateHardwareState> = _hardwareState.asStateFlow()

    private var activeTransitJob: Job? = null

    override fun authorizePassage(sessionId: String, singleUseToken: String, timeoutMs: Long): Boolean {
        val current = _hardwareState.value
        if (current.emergencyStopEngaged || current.controllerStatus != GateControllerStatus.CONNECTED) {
            return false
        }

        _hardwareState.value = current.copy(
            activePassageToken = singleUseToken,
            confirmedTransitCompleted = false
        )
        return true
    }

    override fun simulatePassageSequence(withObstruction: Boolean, withTailgating: Boolean) {
        activeTransitJob?.cancel()
        activeTransitJob = scope.launch {
            val current = _hardwareState.value
            if (current.emergencyStopEngaged || current.controllerStatus != GateControllerStatus.CONNECTED) {
                return@launch
            }

            // 1. Entry barrier opening
            _hardwareState.value = _hardwareState.value.copy(entryBarrier = BarrierPosition.OPENING)
            delay(500)
            _hardwareState.value = _hardwareState.value.copy(entryBarrier = BarrierPosition.FULLY_OPEN)
            delay(600)

            // 2. Traveller breaks entry Beam A
            _hardwareState.value = _hardwareState.value.copy(
                beamAInterrupted = true,
                occupancy = GateOccupancy.OCCUPIED_ENTERING
            )
            delay(800)

            // If obstruction requested at entry
            if (withObstruction) {
                _hardwareState.value = _hardwareState.value.copy(
                    entryBarrier = BarrierPosition.OBSTRUCTED_REOPENING,
                    obstructionActive = true,
                    faultMessage = "Safety Light Curtain Interrupted: Obstacle Detected in Flap Path"
                )
                delay(2000)
                // Clear obstruction
                _hardwareState.value = _hardwareState.value.copy(
                    entryBarrier = BarrierPosition.FULLY_OPEN,
                    obstructionActive = false,
                    faultMessage = null
                )
                delay(800)
            }

            // 3. Move into chamber
            _hardwareState.value = _hardwareState.value.copy(
                beamAInterrupted = false,
                beamBInterrupted = true,
                occupancy = GateOccupancy.OCCUPIED_IN_CHAMBER
            )
            delay(600)

            // Tailgating scenario: another person enters behind
            if (withTailgating) {
                _hardwareState.value = _hardwareState.value.copy(
                    beamAInterrupted = true,
                    occupancy = GateOccupancy.TAILGATING_DETECTED,
                    tailgatingAlarm = true,
                    faultMessage = "SECURITY ALERT: Secondary Occupant Detected in Chamber"
                )
                delay(2500)
                _hardwareState.value = _hardwareState.value.copy(
                    tailgatingAlarm = false,
                    beamAInterrupted = false,
                    faultMessage = null
                )
            }

            // 4. Close entry barrier
            _hardwareState.value = _hardwareState.value.copy(entryBarrier = BarrierPosition.CLOSING)
            delay(500)
            _hardwareState.value = _hardwareState.value.copy(entryBarrier = BarrierPosition.CLOSED)
            delay(400)

            // 5. Open exit barrier
            _hardwareState.value = _hardwareState.value.copy(exitBarrier = BarrierPosition.OPENING)
            delay(500)
            _hardwareState.value = _hardwareState.value.copy(exitBarrier = BarrierPosition.FULLY_OPEN)
            delay(600)

            // 6. Traveller crosses exit Beam C
            _hardwareState.value = _hardwareState.value.copy(
                beamBInterrupted = false,
                beamCInterrupted = true,
                occupancy = GateOccupancy.OCCUPIED_EXITING
            )
            delay(800)

            // 7. Traveller leaves
            _hardwareState.value = _hardwareState.value.copy(
                beamCInterrupted = false,
                occupancy = GateOccupancy.CLEAR
            )
            delay(400)

            // 8. Close exit barrier & finalize transit
            _hardwareState.value = _hardwareState.value.copy(exitBarrier = BarrierPosition.CLOSING)
            delay(500)
            _hardwareState.value = _hardwareState.value.copy(
                exitBarrier = BarrierPosition.CLOSED,
                confirmedTransitCompleted = true,
                activePassageToken = null
            )
        }
    }

    override fun triggerObstruction() {
        activeTransitJob?.cancel()
        _hardwareState.value = _hardwareState.value.copy(
            entryBarrier = BarrierPosition.OBSTRUCTED_REOPENING,
            obstructionActive = true,
            faultMessage = "Safety Light Curtain Interrupted: Obstacle Detected"
        )
    }

    override fun triggerTailgating() {
        _hardwareState.value = _hardwareState.value.copy(
            tailgatingAlarm = true,
            occupancy = GateOccupancy.TAILGATING_DETECTED,
            faultMessage = "SECURITY ALERT: Secondary Occupant / Tailgating Detected"
        )
    }

    override fun triggerEmergencyStop() {
        activeTransitJob?.cancel()
        _hardwareState.value = _hardwareState.value.copy(
            emergencyStopEngaged = true,
            entryBarrier = BarrierPosition.FULLY_OPEN, // Failsafe egress mode
            exitBarrier = BarrierPosition.FULLY_OPEN,
            controllerStatus = GateControllerStatus.HARDWARE_FAULT,
            faultMessage = "EMERGENCY STOP ENGAGED: Fail-Safe Free Egress Activated"
        )
    }

    override fun resetFault() {
        activeTransitJob?.cancel()
        _hardwareState.value = GateHardwareState(
            entryBarrier = BarrierPosition.CLOSED,
            exitBarrier = BarrierPosition.CLOSED,
            occupancy = GateOccupancy.CLEAR,
            controllerStatus = GateControllerStatus.CONNECTED
        )
    }

    override fun disconnectController() {
        activeTransitJob?.cancel()
        _hardwareState.value = _hardwareState.value.copy(
            controllerStatus = GateControllerStatus.DISCONNECTED,
            faultMessage = "COMMUNICATION TIMEOUT: Gate Hardware Controller Heartbeat Lost"
        )
    }

    override fun reconnectController() {
        _hardwareState.value = _hardwareState.value.copy(
            controllerStatus = GateControllerStatus.CONNECTED,
            faultMessage = null
        )
    }
}
