package com.example.ui.screens.kiosk

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Contactless
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.KioskLanguage
import com.example.ui.components.LanguageSelector
import com.example.ui.theme.AirportNavyDark
import com.example.ui.theme.AirportNavyElevated
import com.example.ui.theme.AirportNavySurface
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.CyanTeal
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextMuted

@Composable
fun WelcomeScreen(
    currentLanguage: KioskLanguage,
    onSelectLanguage: (KioskLanguage) -> Unit,
    onStartKiosk: () -> Unit,
    modifier: Modifier = Modifier
) {
    val welcomeHeading = when (currentLanguage) {
        KioskLanguage.EN -> "Welcome to Border Control"
        KioskLanguage.FR -> "Bienvenue au Contrôle des Frontières"
        KioskLanguage.ES -> "Bienvenido al Control de Fronteras"
        KioskLanguage.DE -> "Willkommen bei der Grenzkontrolle"
        KioskLanguage.JA -> "出入国管理ゲートへようこそ"
        KioskLanguage.AR -> "مرحبًا بكم في مراقبة الحدود"
    }

    val welcomeSub = when (currentLanguage) {
        KioskLanguage.EN -> "Automated eGate Biometric Immigration Verification"
        KioskLanguage.FR -> "Vérification biométrique automatisée des passeports"
        KioskLanguage.ES -> "Verificación biométrica automatizada de pasaportes"
        KioskLanguage.DE -> "Automatisierte biometrische Passkontrolle"
        KioskLanguage.JA -> "生体認証による自動パスポート確認"
        KioskLanguage.AR -> "التحقق البيومتري الآلي من جواز السفر"
    }

    val ctaText = when (currentLanguage) {
        KioskLanguage.EN -> "Touch Screen or Insert Passport to Begin"
        KioskLanguage.FR -> "Touchez l'écran pour commencer"
        KioskLanguage.ES -> "Toque la pantalla para comenzar"
        KioskLanguage.DE -> "Berühren Sie den Bildschirm, um zu beginnen"
        KioskLanguage.JA -> "画面をタッチして開始してください"
        KioskLanguage.AR -> "المس الشاشة للبدء"
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AirportNavyDark)
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Language Selector Row at Top
        LanguageSelector(
            selectedLanguage = currentLanguage,
            onSelectLanguage = onSelectLanguage,
            modifier = Modifier.padding(top = 8.dp)
        )

        // Center Hero: Animated Badge & Instructions
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(vertical = 16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(AirportNavySurface)
                    .border(2.dp, CyanPrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = CyanPrimary,
                    modifier = Modifier.size(52.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = welcomeHeading,
                color = PureWhite,
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = welcomeSub,
                color = CyanTeal,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(28.dp))

            // 3-Step Simple Guide Icons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                GuideStepCard(stepNumber = "1", title = "Scan Passport", icon = Icons.Default.MenuBook)
                GuideStepCard(stepNumber = "2", title = "Read Chip", icon = Icons.Default.Contactless)
                GuideStepCard(stepNumber = "3", title = "Look at Camera", icon = Icons.Default.Face)
            }
        }

        // Bottom CTA Button (large accessible touch target > 56dp)
        Button(
            onClick = onStartKiosk,
            colors = ButtonDefaults.buttonColors(
                containerColor = CyanPrimary,
                contentColor = AirportNavyDark
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .testTag("kiosk_start_button")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.FlightTakeoff,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = ctaText,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}

@Composable
private fun GuideStepCard(
    stepNumber: String,
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = AirportNavySurface),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .width(104.dp)
            .border(1.dp, AirportNavyElevated, RoundedCornerShape(12.dp))
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(CyanPrimary.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stepNumber,
                    color = CyanPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = PureWhite,
                modifier = Modifier.size(26.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                lineHeight = 13.sp
            )
        }
    }
}
