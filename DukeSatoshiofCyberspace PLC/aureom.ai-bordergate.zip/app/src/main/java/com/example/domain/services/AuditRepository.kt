package com.example.domain.services

import com.example.data.local.AuditDao
import com.example.data.model.AuditRecord
import com.example.data.model.OfficerRole
import kotlinx.coroutines.flow.Flow

interface AuditRepository {
    val allAuditRecords: Flow<List<AuditRecord>>
    suspend fun recordAudit(
        sessionId: String,
        gateId: String,
        role: OfficerRole,
        action: String,
        rawDetails: String,
        reasonCode: String? = null,
        officerBadgeId: String? = null,
        outcome: String
    )
    suspend fun getAuditsForSession(sessionId: String): List<AuditRecord>
    suspend fun clearAudits()
}

class StandardAuditRepository(
    private val auditDao: AuditDao
) : AuditRepository {

    override val allAuditRecords: Flow<List<AuditRecord>> = auditDao.getAllAuditRecords()

    override suspend fun recordAudit(
        sessionId: String,
        gateId: String,
        role: OfficerRole,
        action: String,
        rawDetails: String,
        reasonCode: String?,
        officerBadgeId: String?,
        outcome: String
    ) {
        // Redact personal identifiers: mask names and passport numbers
        val redacted = redactSensitiveData(rawDetails)

        val record = AuditRecord(
            sessionId = sessionId,
            gateId = gateId,
            role = role,
            action = action,
            detailsRedacted = redacted,
            reasonCode = reasonCode,
            officerBadgeId = officerBadgeId,
            outcome = outcome
        )
        auditDao.insertAudit(record)
    }

    override suspend fun getAuditsForSession(sessionId: String): List<AuditRecord> {
        return auditDao.getAuditsForSession(sessionId)
    }

    override suspend fun clearAudits() {
        auditDao.clearAllAudits()
    }

    private fun redactSensitiveData(input: String): String {
        // Redact 9-digit alphanumeric passport numbers with masked representation
        val docRegex = Regex("\\b([A-Z0-9]{2})[A-Z0-9]{5}([A-Z0-9]{2})\\b")
        var sanitized = input.replace(docRegex) { match ->
            "${match.groupValues[1]}*****${match.groupValues[2]}"
        }
        // Redact raw MRZ chevrons if passed
        sanitized = sanitized.replace(Regex("<<+"), "<<...<<")
        return sanitized
    }
}
