package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AirportDarkColorScheme = darkColorScheme(
    primary = CyanPrimary,
    onPrimary = AirportNavyDark,
    primaryContainer = CyanDark,
    onPrimaryContainer = PureWhite,
    secondary = CyanTeal,
    onSecondary = AirportNavyDark,
    secondaryContainer = AirportNavyElevated,
    onSecondaryContainer = PureWhite,
    tertiary = WarningAmber,
    onTertiary = AirportNavyDark,
    background = AirportNavyDark,
    onBackground = PureWhite,
    surface = AirportNavySurface,
    onSurface = PureWhite,
    surfaceVariant = AirportNavyElevated,
    onSurfaceVariant = OffWhite,
    outline = AirportNavyBorder,
    error = AlertRed,
    onError = PureWhite
)

private val AirportLightColorScheme = lightColorScheme(
    primary = CyanDark,
    onPrimary = PureWhite,
    primaryContainer = Color(0xFFE0F7FA),
    onPrimaryContainer = AirportNavyDark,
    secondary = CyanTeal,
    onSecondary = PureWhite,
    secondaryContainer = Color(0xFFE2E8F0),
    onSecondaryContainer = AirportNavyDark,
    tertiary = WarningAmber,
    onTertiary = PureWhite,
    background = Color(0xFFF8FAFC),
    onBackground = AirportNavyDark,
    surface = PureWhite,
    onSurface = AirportNavyDark,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF334155),
    outline = Color(0xFFCBD5E1),
    error = AlertRed,
    onError = PureWhite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to sleek premium airport dark mode
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) AirportDarkColorScheme else AirportLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
