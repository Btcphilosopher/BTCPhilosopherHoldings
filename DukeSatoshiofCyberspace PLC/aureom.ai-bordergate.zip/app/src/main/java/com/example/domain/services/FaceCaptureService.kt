package com.example.domain.services

import com.example.data.model.FaceCaptureMetrics
import com.example.data.model.FaceStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

interface FaceCaptureService {
    val liveMetrics: StateFlow<FaceCaptureMetrics>
    fun updateLiveFeed(quality: Float, lighting: Float, singlePerson: Boolean, status: FaceStatus)
    suspend fun performCapture(simulateMultiPerson: Boolean = false, simulatePoorLighting: Boolean = false): FaceCaptureMetrics
}

class SimulatedFaceCaptureService : FaceCaptureService {

    private val _liveMetrics = MutableStateFlow(
        FaceCaptureMetrics(
            qualityScore = 0.93f,
            lightingScore = 0.89f,
            singlePersonFramed = true,
            eyeContactScore = 0.95f,
            faceStatus = FaceStatus.SUCCESS
        )
    )
    override val liveMetrics: StateFlow<FaceCaptureMetrics> = _liveMetrics.asStateFlow()

    override fun updateLiveFeed(quality: Float, lighting: Float, singlePerson: Boolean, status: FaceStatus) {
        _liveMetrics.value = FaceCaptureMetrics(
            qualityScore = quality,
            lightingScore = lighting,
            singlePersonFramed = singlePerson,
            eyeContactScore = if (singlePerson) 0.91f else 0.40f,
            faceStatus = status
        )
    }

    override suspend fun performCapture(simulateMultiPerson: Boolean, simulatePoorLighting: Boolean): FaceCaptureMetrics {
        val status = when {
            simulateMultiPerson -> FaceStatus.MULTI_PERSON_DETECTED
            simulatePoorLighting -> FaceStatus.POOR_LIGHTING
            else -> FaceStatus.SUCCESS
        }
        val singlePerson = !simulateMultiPerson
        val lighting = if (simulatePoorLighting) 0.35f else 0.88f
        val quality = if (simulatePoorLighting) 0.45f else 0.94f

        updateLiveFeed(quality, lighting, singlePerson, status)
        return _liveMetrics.value
    }
}
