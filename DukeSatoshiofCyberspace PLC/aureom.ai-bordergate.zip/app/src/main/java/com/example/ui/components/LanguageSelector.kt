package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.KioskLanguage
import com.example.ui.theme.AirportNavyElevated
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.PureWhite

@Composable
fun LanguageSelector(
    selectedLanguage: KioskLanguage,
    onSelectLanguage: (KioskLanguage) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        KioskLanguage.values().forEach { lang ->
            val isSelected = lang == selectedLanguage
            val bg = if (isSelected) CyanPrimary.copy(alpha = 0.2f) else AirportNavyElevated
            val border = if (isSelected) CyanPrimary else Color.Transparent

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(bg)
                    .border(1.5.dp, border, RoundedCornerShape(8.dp))
                    .clickable { onSelectLanguage(lang) }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .testTag("lang_${lang.code}")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = lang.flag, fontSize = 16.sp)
                    Text(
                        text = lang.displayName,
                        color = if (isSelected) CyanPrimary else PureWhite,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}
