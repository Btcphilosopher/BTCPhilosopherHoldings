package com.example.ui.screens.officer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.fixtures.SpecimenPassport
import com.example.data.model.ActiveSessionState
import com.example.data.model.AuditRecord
import com.example.data.model.DecisionOutcome
import com.example.data.model.OfficerRole
import com.example.ui.theme.AirportNavyDark
import com.example.ui.theme.AirportNavyElevated
import com.example.ui.theme.AirportNavySurface
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.NeutralBlue
import com.example.ui.theme.OfficerAccentGold
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OfficerConsoleScreen(
    activeSession: ActiveSessionState,
    currentSpecimen: SpecimenPassport,
    activeRole: OfficerRole,
    auditLogs: List<AuditRecord>,
    onSetRole: (OfficerRole) -> Unit,
    onApproveOverride: (comment: String, badgeId: String) -> Unit,
    onConfirmReferral: (comment: String, badgeId: String) -> Unit,
    onClearAudits: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var overrideComment by remember { mutableStateOf("Manual physical passport inspection and secondary interview completed.") }
    var officerBadgeId by remember { mutableStateOf("UKBF-OFFICER-742") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AirportNavyDark)
            .padding(16.dp)
    ) {
        // Workspace Header with Role Switcher
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(OfficerAccentGold.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = OfficerAccentGold,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Officer Border Control Workspace",
                        color = PureWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "Gate EGATE-LHR-T5-04 • Authenticated Session: ${activeSession.sessionId}",
                    color = OfficerAccentGold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Role Selector Chips
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OfficerRole.values().filter { it != OfficerRole.SYSTEM }.forEach { role ->
                    val isSel = role == activeRole
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSel) OfficerAccentGold else AirportNavyElevated)
                            .clickable { onSetRole(role) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("role_${role.name}")
                    ) {
                        Text(
                            text = role.name.take(4),
                            color = if (isSel) AirportNavyDark else PureWhite,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tabs: [1. Session Technical Inspection] [2. Operational Audit Logs]
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = AirportNavySurface,
            contentColor = OfficerAccentGold,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = OfficerAccentGold
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Session Inspection", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Audit Trail (${auditLogs.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (selectedTab == 0) {
            // Tab 1: Detailed Session Inspection & Manual Actions
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 1. Referral & Decision Banner
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (activeSession.decision?.outcome == DecisionOutcome.APPROVED) {
                            SuccessGreen.copy(alpha = 0.15f)
                        } else {
                            WarningAmber.copy(alpha = 0.15f)
                        }
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            if (activeSession.decision?.outcome == DecisionOutcome.APPROVED) SuccessGreen else WarningAmber,
                            RoundedCornerShape(10.dp)
                        )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "DECISION STATUS: ${activeSession.decision?.outcome ?: "INSPECTION_PENDING"}",
                                color = if (activeSession.decision?.outcome == DecisionOutcome.APPROVED) SuccessGreen else WarningAmber,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Code: ${activeSession.decision?.internalReasonCode ?: "PENDING"}",
                                color = PureWhite,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Traveller Message: \"${activeSession.decision?.travellerPublicSummary ?: "Processing documents"}\"",
                            color = Color.LightGray,
                            fontSize = 11.sp
                        )
                    }
                }

                // 2. Document & MRZ Checksum Breakdown
                Card(
                    colors = CardDefaults.cardColors(containerColor = AirportNavySurface),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AirportNavyElevated, RoundedCornerShape(10.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.MenuBook, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Document & MRZ Doc 9303 Verification", color = PureWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        val mrz = activeSession.passportResult?.mrzData
                        if (mrz != null) {
                            Text(text = "Holder: ${mrz.fullName} • Nationality: ${mrz.nationality}", color = Color.LightGray, fontSize = 12.sp)
                            Text(text = "Doc Number: ${mrz.documentNumber} (${mrz.issuingCountry})", color = PureWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(text = "DOB: ${mrz.parsedBirthDate} • Expiry: ${mrz.parsedExpiryDate}", color = Color.LightGray, fontSize = 12.sp)

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                CheckDigitBadge("Doc# Check", mrz.checkResult.documentNumberCheckValid)
                                CheckDigitBadge("DOB Check", mrz.checkResult.birthDateCheckValid)
                                CheckDigitBadge("Expiry Check", mrz.checkResult.expiryDateCheckValid)
                                CheckDigitBadge("Composite", mrz.checkResult.compositeCheckValid)
                            }
                        } else {
                            Text(text = "No document MRZ captured yet.", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }

                // 3. eChip Security & CSCA Trust
                Card(
                    colors = CardDefaults.cardColors(containerColor = AirportNavySurface),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AirportNavyElevated, RoundedCornerShape(10.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Fingerprint, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Contactless Chip & PKI Trust", color = PureWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        val chip = activeSession.chipResult
                        if (chip != null) {
                            Text(text = "Access Protocol: ${chip.protocolUsed}", color = PureWhite, fontSize = 12.sp)
                            Text(text = "Passive Authentication: ${chip.passiveAuthStatus}", color = if (chip.passiveAuthStatus.name == "VERIFIED") SuccessGreen else AlertRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Signer SOD: ${chip.sodIssuerDn}", color = Color.Gray, fontSize = 11.sp)
                            Text(text = "Active Auth: ${if (chip.activeAuthPassed) "Passed" else "Failed/Not Supported"}", color = Color.LightGray, fontSize = 11.sp)
                        } else {
                            Text(text = "Chip data not read.", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }

                // 4. Biometric Comparison & PAD Liveness
                Card(
                    colors = CardDefaults.cardColors(containerColor = AirportNavySurface),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AirportNavyElevated, RoundedCornerShape(10.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Face, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Biometric Matching & Liveness (PAD)", color = PureWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        val bio = activeSession.biometricResult
                        if (bio != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = "Probe Similarity Score", color = Color.Gray, fontSize = 10.sp)
                                    Text(
                                        text = "${bio.comparisonResult.similarityScore}% (Threshold: ${bio.comparisonResult.operationalThreshold}%)",
                                        color = if (bio.comparisonResult.isMatch) SuccessGreen else AlertRed,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Engine: ${bio.comparisonResult.matcherEngineVersion}",
                                        color = Color.Gray,
                                        fontSize = 10.sp
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "PAD Liveness", color = Color.Gray, fontSize = 10.sp)
                                    Text(
                                        text = if (bio.padAssessment.isLive) "LIVE (Score: ${bio.padAssessment.padScore})" else "SPOOF DETECTED",
                                        color = if (bio.padAssessment.isLive) SuccessGreen else AlertRed,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = bio.padAssessment.padEngineVersion,
                                        color = Color.Gray,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        } else {
                            Text(text = "Biometrics not captured.", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }

                // 5. Manual Intervention Form
                Card(
                    colors = CardDefaults.cardColors(containerColor = AirportNavyElevated),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "OFFICER INTERVENTION ACTION",
                            color = OfficerAccentGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = officerBadgeId,
                            onValueChange = { officerBadgeId = it },
                            label = { Text("Officer Badge ID") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = PureWhite,
                                unfocusedTextColor = PureWhite,
                                focusedBorderColor = OfficerAccentGold,
                                unfocusedBorderColor = Color.Gray
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = overrideComment,
                            onValueChange = { overrideComment = it },
                            label = { Text("Mandatory Audit Justification") },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = PureWhite,
                                unfocusedTextColor = PureWhite,
                                focusedBorderColor = OfficerAccentGold,
                                unfocusedBorderColor = Color.Gray
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onConfirmReferral(overrideComment, officerBadgeId) },
                                colors = ButtonDefaults.buttonColors(containerColor = AlertRed, contentColor = PureWhite),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("officer_deny_button")
                            ) {
                                Text("Refer to Secondary Desk", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { onApproveOverride(overrideComment, officerBadgeId) },
                                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen, contentColor = AirportNavyDark),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("officer_approve_button")
                            ) {
                                Text("Authorise Clearance (Override)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        } else {
            // Tab 2: Operational Audit Trail
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recorded Operational Interventions & Events",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )

                    Button(
                        onClick = onClearAudits,
                        colors = ButtonDefaults.buttonColors(containerColor = AirportNavyElevated, contentColor = Color.Gray),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Clear Logs", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(auditLogs) { record ->
                        AuditRecordItem(record)
                    }
                }
            }
        }
    }
}

@Composable
private fun CheckDigitBadge(label: String, isValid: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (isValid) SuccessGreen else AlertRed)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, color = if (isValid) PureWhite else AlertRed, fontSize = 10.sp)
    }
}

@Composable
private fun AuditRecordItem(record: AuditRecord) {
    val dateStr = SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date(record.timestamp))

    Card(
        colors = CardDefaults.cardColors(containerColor = AirportNavySurface),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AirportNavyElevated, RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = record.action,
                        color = CyanPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = record.role.name,
                        color = OfficerAccentGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Text(
                    text = dateStr,
                    color = Color.Gray,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = record.detailsRedacted,
                color = PureWhite,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Session: ${record.sessionId} • Gate: ${record.gateId}",
                    color = Color.Gray,
                    fontSize = 10.sp
                )
                Text(
                    text = record.outcome,
                    color = if (record.outcome.contains("APPROV") || record.outcome.contains("SUCCESS") || record.outcome == "MATCH") SuccessGreen else WarningAmber,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
