package com.example.data.model

/**
 * Distinguishes electronic passport chip reading, data integrity, and PKI signer trust.
 * Per requirement: Never treat an unavailable verification service as a successful check.
 */
enum class PassiveAuthStatus {
    VERIFIED,           // SOD signed by trusted CSCA, DG hashes match
    DATA_HASH_MISMATCH, // DG hash altered or corrupted
    UNTRUSTED_SIGNER,   // Document Signer cert not present in National PKD trust store
    UNAVAILABLE         // National PKD or revocation directory unreachable
}

enum class ChipReadStatus {
    SUCCESS,
    INTERRUPTED,        // User pulled document away too early
    ACCESS_DENIED,      // BAC / PACE PIN mismatch
    HARDWARE_UNAVAILABLE, // Device lacks NFC hardware
    TIMEOUT
}

enum class ChipAccessProtocol {
    BAC,
    PACE_ECDH_GM,
    PACE_DH_GM
}

data class ChipData(
    val chipReadStatus: ChipReadStatus,
    val protocolUsed: ChipAccessProtocol = ChipAccessProtocol.PACE_ECDH_GM,
    val passiveAuthStatus: PassiveAuthStatus,
    val activeAuthSupported: Boolean = true,
    val activeAuthPassed: Boolean = true,
    val dg1MrzMatchesOcr: Boolean = true,
    val dg2BiometricFacePresent: Boolean = true,
    val dg2PhotoResId: Int? = null,
    val sodIssuerDn: String = "C=GB, O=HM Passport Office, CN=Document Signer 2024-B",
    val readDurationMs: Long = 1450L,
    val readTimestamp: Long = System.currentTimeMillis()
)
