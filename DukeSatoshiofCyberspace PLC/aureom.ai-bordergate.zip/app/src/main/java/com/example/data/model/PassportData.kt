package com.example.data.model

/**
 * Standard ICAO Doc 9303 MRZ Check-Digit validation result.
 */
data class MrzCheckResult(
    val documentNumberCheckValid: Boolean,
    val birthDateCheckValid: Boolean,
    val expiryDateCheckValid: Boolean,
    val optionalDataCheckValid: Boolean,
    val compositeCheckValid: Boolean,
    val allValid: Boolean
) {
    val summary: String
        get() = if (allValid) "All ICAO Doc 9303 checksums valid" else "Checksum failure detected"
}

/**
 * Parsed Machine Readable Zone data for TD3 (passports) or TD1 (ID cards).
 */
data class MrzData(
    val documentType: String,
    val issuingCountry: String,
    val surname: String,
    val givenNames: String,
    val documentNumber: String,
    val nationality: String,
    val dateOfBirthRaw: String,      // YYMMDD
    val parsedBirthDate: String,     // YYYY-MM-DD
    val sex: String,                 // M, F, X, <
    val dateOfExpiryRaw: String,     // YYMMDD
    val parsedExpiryDate: String,    // YYYY-MM-DD
    val optionalData: String,
    val rawLines: List<String>,
    val checkResult: MrzCheckResult,
    val isSpecimen: Boolean = true
) {
    val fullName: String
        get() = "$givenNames $surname".trim()

    val maskedDocNumber: String
        get() = if (documentNumber.length > 4) {
            documentNumber.take(2) + "*".repeat(documentNumber.length - 4) + documentNumber.takeLast(2)
        } else "****"
}

enum class CaptureStatus {
    SUCCESS,
    BLURRY,
    GLARE_DETECTED,
    UNREADABLE_MRZ,
    TIMEOUT,
    MISALIGNED
}

data class QualityMetrics(
    val glareDetected: Boolean = false,
    val blurScore: Float = 0.85f,       // 0..1, higher is sharper
    val contrastScore: Float = 0.80f,   // 0..1
    val framingScore: Float = 0.90f,    // 0..1
    val isAcceptable: Boolean = true
)

data class DocumentCaptureResult(
    val mrzData: MrzData?,
    val quality: QualityMetrics,
    val status: CaptureStatus,
    val rawOcrText: String? = null,
    val captureTimestamp: Long = System.currentTimeMillis()
)
