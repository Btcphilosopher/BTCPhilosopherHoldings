package com.example.domain.services

import com.example.data.fixtures.SpecimenPassport
import com.example.data.model.CaptureStatus
import com.example.data.model.DocumentCaptureResult
import com.example.data.model.QualityMetrics
import com.example.domain.parser.MrzParser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

interface PassportCaptureService {
    val liveQualityMetrics: StateFlow<QualityMetrics>
    suspend fun captureDocument(specimen: SpecimenPassport? = null, forceBlurOrGlare: Boolean = false): DocumentCaptureResult
    fun updateLiveQuality(glare: Boolean, blur: Float, contrast: Float, framing: Float)
}

class SimulatedPassportCaptureService : PassportCaptureService {

    private val _liveQualityMetrics = MutableStateFlow(
        QualityMetrics(glareDetected = false, blurScore = 0.92f, contrastScore = 0.88f, framingScore = 0.95f, isAcceptable = true)
    )
    override val liveQualityMetrics: StateFlow<QualityMetrics> = _liveQualityMetrics.asStateFlow()

    override fun updateLiveQuality(glare: Boolean, blur: Float, contrast: Float, framing: Float) {
        val acceptable = !glare && blur >= 0.70f && contrast >= 0.60f && framing >= 0.75f
        _liveQualityMetrics.value = QualityMetrics(
            glareDetected = glare,
            blurScore = blur,
            contrastScore = contrast,
            framingScore = framing,
            isAcceptable = acceptable
        )
    }

    override suspend fun captureDocument(specimen: SpecimenPassport?, forceBlurOrGlare: Boolean): DocumentCaptureResult {
        if (forceBlurOrGlare) {
            updateLiveQuality(glare = true, blur = 0.42f, contrast = 0.50f, framing = 0.60f)
            return DocumentCaptureResult(
                mrzData = null,
                quality = _liveQualityMetrics.value,
                status = CaptureStatus.GLARE_DETECTED,
                rawOcrText = "GLARE OVER MRZ CHEVRONS <<<<<< UNREADABLE"
            )
        }

        val targetSpecimen = specimen ?: com.example.data.fixtures.SpecimenPassports.DOE_UK
        val mrz = targetSpecimen.toMrzData()

        updateLiveQuality(glare = false, blur = 0.94f, contrast = 0.90f, framing = 0.98f)

        return DocumentCaptureResult(
            mrzData = mrz,
            quality = _liveQualityMetrics.value,
            status = if (mrz.checkResult.allValid) CaptureStatus.SUCCESS else CaptureStatus.UNREADABLE_MRZ,
            rawOcrText = "${targetSpecimen.line1}\n${targetSpecimen.line2}"
        )
    }
}
