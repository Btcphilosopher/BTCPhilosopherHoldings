package com.example

import com.example.data.fixtures.SpecimenPassports
import com.example.data.local.AuditDao
import com.example.data.model.AuditRecord
import com.example.data.model.BarrierPosition
import com.example.data.model.ChipAccessProtocol
import com.example.data.model.ChipData
import com.example.data.model.ChipReadStatus
import com.example.data.model.DecisionOutcome
import com.example.data.model.GateControllerStatus
import com.example.data.model.OfficerRole
import com.example.data.model.PassageDecision
import com.example.data.model.PassiveAuthStatus
import com.example.domain.parser.MrzParser
import com.example.domain.services.SimulatedGateController
import com.example.domain.services.StandardAuditRepository
import com.example.domain.services.StandardBorderDecisionService
import com.example.domain.services.StandardDocumentAuthenticationService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    // 1. MRZ Check digit validation (Doc 9303 algorithm weights 7, 3, 1)
    @Test
    fun `test ICAO Doc 9303 MRZ check digit calculation`() {
        val docNum = "982341902"
        val checkDigit = MrzParser.calculateCheckDigit(docNum)
        assertEquals(8, checkDigit)
        assertTrue(MrzParser.verifyCheckDigit(docNum, '8'))
        assertFalse(MrzParser.verifyCheckDigit(docNum, '9'))
    }

    @Test
    fun `test MRZ parser with valid specimen`() {
        val mrz = SpecimenPassports.DOE_UK.toMrzData()
        assertNotNull(mrz)
        assertEquals("DOE", mrz.surname)
        assertEquals("JOHN MICHAEL", mrz.givenNames)
        assertEquals("GBR", mrz.issuingCountry)
        assertTrue(mrz.checkResult.documentNumberCheckValid)
        assertTrue(mrz.checkResult.birthDateCheckValid)
        assertTrue(mrz.checkResult.expiryDateCheckValid)
        assertTrue(mrz.checkResult.compositeCheckValid)
        assertTrue(mrz.checkResult.allValid)
    }

    @Test
    fun `test MRZ parser detects corrupted checksum`() {
        val corrupt = SpecimenPassports.GRUBER_CORRUPT_MRZ.toMrzData()
        assertNotNull(corrupt)
        assertFalse("Corrupted MRZ check digits must fail validation", corrupt.checkResult.allValid)
    }

    @Test
    fun `test date ambiguity window parsing`() {
        val expiryDate = MrzParser.parseDate("300915", isExpiry = true)
        assertEquals("2030-09-15", expiryDate)

        val birthDate = MrzParser.parseDate("850412", isExpiry = false)
        assertEquals("1985-04-12", birthDate)
    }

    // 2. Decision Expiry and Replay Prevention
    @Test
    fun `test decision single-use token prevents replay`() {
        val decisionService = StandardBorderDecisionService()
        val decision = PassageDecision(
            outcome = DecisionOutcome.APPROVED,
            travellerPublicSummary = "Clearance granted",
            internalReasonCode = com.example.data.model.ReasonCode.CLEARANCE_GRANTED,
            validUntilEpochMs = System.currentTimeMillis() + 30_000L
        )

        val token = decision.singleUseToken

        val firstUseValid = decisionService.validateToken(token, decision)
        assertTrue("First use of passage token must succeed", firstUseValid)
        assertTrue("Token must be marked consumed after first use", decision.isConsumed)

        val replayAttempt = decisionService.validateToken(token, decision)
        assertFalse("Replay or reuse of consumed token must be rejected", replayAttempt)
    }

    @Test
    fun `test expired decision cannot authorize passage`() {
        val decisionService = StandardBorderDecisionService()
        val expiredDecision = PassageDecision(
            outcome = DecisionOutcome.APPROVED,
            travellerPublicSummary = "Clearance granted",
            internalReasonCode = com.example.data.model.ReasonCode.CLEARANCE_GRANTED,
            validUntilEpochMs = System.currentTimeMillis() - 5000L
        )

        assertFalse("Expired decision must not authorize gate passage", expiredDecision.canOpenGate)
        assertFalse(
            "Decision service must reject expired tokens",
            decisionService.validateToken(expiredDecision.singleUseToken, expiredDecision)
        )
    }

    // 3. Document Authenticity vs Checksum Distinction
    @Test
    fun `test passing MRZ does not prove genuine passport without PKI trust`() {
        val authService = StandardDocumentAuthenticationService()
        val mrz = SpecimenPassports.ROSTOVA_UNTRUSTED_SIGNER.toMrzData()

        val chipWithUntrustedSigner = ChipData(
            chipReadStatus = ChipReadStatus.SUCCESS,
            protocolUsed = ChipAccessProtocol.PACE_ECDH_GM,
            passiveAuthStatus = PassiveAuthStatus.UNTRUSTED_SIGNER
        )

        val result = authService.authenticateDocument(mrz, chipWithUntrustedSigner)

        assertTrue("MRZ checksum is mathematically valid", result.isOcrChecksumValid)
        assertFalse("Untrusted signer must not be marked authentic", result.isSignerTrusted)
        assertFalse("Document must not be marked authentic", result.isDocumentAuthentic)
    }

    // 4. Gate Controller Faults and Obstruction
    @Test
    fun `test gate controller emergency stop and reset`() {
        val controller = SimulatedGateController()

        controller.triggerEmergencyStop()
        val stateAfterStop = controller.hardwareState.value
        assertTrue("E-Stop flag must be engaged", stateAfterStop.emergencyStopEngaged)
        assertEquals("Controller must be in fault state", GateControllerStatus.HARDWARE_FAULT, stateAfterStop.controllerStatus)
        assertEquals("Barriers must be open for failsafe emergency egress", BarrierPosition.FULLY_OPEN, stateAfterStop.entryBarrier)

        controller.resetFault()
        val stateAfterReset = controller.hardwareState.value
        assertFalse("E-Stop flag must be cleared", stateAfterReset.emergencyStopEngaged)
        assertEquals("Controller must be back to connected", GateControllerStatus.CONNECTED, stateAfterReset.controllerStatus)
        assertEquals("Barriers must return to secure closed state", BarrierPosition.CLOSED, stateAfterReset.entryBarrier)
    }

    @Test
    fun `test obstruction interrupts flap movement`() {
        val controller = SimulatedGateController()
        controller.triggerObstruction()

        val state = controller.hardwareState.value
        assertTrue("Obstruction active must be true", state.obstructionActive)
        assertEquals("Barrier must switch to reopening", BarrierPosition.OBSTRUCTED_REOPENING, state.entryBarrier)
        assertNotNull("Fault message must detail safety light curtain event", state.faultMessage)
    }

    // 5. Operational Audit Logging and Privacy Redaction
    @Test
    fun `test audit repository records and redacts sensitive data`() = runBlocking {
        val fakeDao = object : AuditDao {
            private val list = mutableListOf<AuditRecord>()
            private val flow = MutableStateFlow<List<AuditRecord>>(emptyList())

            override suspend fun insertAudit(record: AuditRecord): Long {
                list.add(0, record.copy(id = list.size.toLong() + 1))
                flow.value = list.toList()
                return list.size.toLong()
            }

            override fun getAllAuditRecords(): Flow<List<AuditRecord>> = flow

            override suspend fun getAuditsForSession(sessionId: String): List<AuditRecord> {
                return list.filter { it.sessionId == sessionId }
            }

            override suspend fun clearAllAudits() {
                list.clear()
                flow.value = emptyList()
            }
        }

        val repo = StandardAuditRepository(fakeDao)

        repo.recordAudit(
            sessionId = "SESS-PRIVACY-01",
            gateId = "EGATE-01",
            role = OfficerRole.SUPERVISOR,
            action = "MANUAL_INSPECTION",
            rawDetails = "Inspected passport 982341902 for passenger JOHN DOE",
            reasonCode = "AUDIT_TEST",
            officerBadgeId = "UKBF-742",
            outcome = "APPROVED"
        )

        val audits = repo.allAuditRecords.first()
        assertEquals(1, audits.size)
        val record = audits.first()

        assertEquals("SESS-PRIVACY-01", record.sessionId)
        assertEquals(OfficerRole.SUPERVISOR, record.role)
        assertEquals("UKBF-742", record.officerBadgeId)

        // Sensitive document number 982341902 must be redacted
        assertFalse("Full passport number must not be stored unmasked", record.detailsRedacted.contains("982341902"))
        assertTrue("Passport number must be masked with asterisks", record.detailsRedacted.contains("98*****02"))

        // Test clear audits
        repo.clearAudits()
        val auditsAfterClear = repo.allAuditRecords.first()
        assertTrue("Audits must be empty after clear", auditsAfterClear.isEmpty())
    }
}
