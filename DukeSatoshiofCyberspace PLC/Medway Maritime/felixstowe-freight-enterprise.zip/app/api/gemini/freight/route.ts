import { GoogleGenAI, Type } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action, payload } = body;

    if (!action) {
      return NextResponse.json({ error: "Missing 'action' parameter." }, { status: 400 });
    }

    if (action === "route_optimize") {
      const { origin, destination, containerType, cargoWeight, value } = payload;
      
      const prompt = `You are the lead Route Logistics AI Engine for Felixstowe Freight Enterprise, a premium shipping carrier in the UK.
Optimize the marine shipment route from "${origin}" to "${destination}" (one of these is typically Felixstowe, UK).
Generate a professional, structured JSON response with the following keys:
- seaRoutePath: string (description of the ocean route, e.g., "South China Sea -> Indian Ocean -> Suez Canal -> Mediterranean -> North Sea -> Felixstowe")
- transitDays: number (estimated sea transit duration)
- carbonEmissionsTone: number (estimated CO2 metric tonnes)
- costEstimateGbp: number (estimated total sea freight cost in GBP, typically between £1500 and £6800 depending on distance)
- customsGuidance: string (detailed, UK customs-specific guidance for Suffolk port authority, mentioning potential UK tariff regimes, standard VAT declarations, and port handling charges)
- priorityRiskLevel: string ("Low" | "Medium" | "High")
- riskFactors: string[] (possible weather delay points, busy bottlenecks like Suez, Gibraltar, English Channel, etc.)

Provide a realistic freight assessment.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              seaRoutePath: { type: Type.STRING },
              transitDays: { type: Type.INTEGER },
              carbonEmissionsTone: { type: Type.NUMBER },
              costEstimateGbp: { type: Type.INTEGER },
              customsGuidance: { type: Type.STRING },
              priorityRiskLevel: { type: Type.STRING },
              riskFactors: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              }
            },
            required: ["seaRoutePath", "transitDays", "carbonEmissionsTone", "costEstimateGbp", "customsGuidance", "priorityRiskLevel", "riskFactors"]
          }
        }
      });

      const text = response.text;
      if (!text) {
        throw new Error("Empty response from Gemini API");
      }
      return NextResponse.json(JSON.parse(text.trim()));
    }

    if (action === "manifest_audit") {
      const { cargoDescription, hscode, countryOfOrigin, quantity, valueGbp } = payload;

      const prompt = `You are a certified HM Revenue & Customs (HMRC) clearance validator stationed at the Port of Felixstowe, Suffolk, UK.
Audit the following cargo manifest entry:
Cargo: "${cargoDescription}"
HS Code: "${hscode || 'Auto-detect requested'}"
Country of Origin: "${countryOfOrigin}"
Quantity/Weight: "${quantity}"
Declared Value: £"${valueGbp}"

Generate a complete compliance assessment in JSON with the following keys:
- validatedHsCode: string (confirmed standard HS code, e.g. "8517.13.00" for mobile phones)
- ukTarifRatePercent: number (estimated UK tariff duty rate, e.g. 2.0 or 0.0)
- importVatRatePercent: number (standard UK VAT rate, usually 20.0 or 0.0)
- dutyPayableGbp: number (calculated duty amount)
- vatPayableGbp: number (calculated VAT amount)
- riskAssessment: string (brief HMRC security risk profile assessment, mentioning container check probability)
- complianceChecklist: string[] (3 specific actions the importer must take for successful Felixstowe Port Health or Customs clearance)
- isApproved: boolean (whether the metadata passes immediate inspection)

Be precise and authoritative in British maritime customs.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              validatedHsCode: { type: Type.STRING },
              ukTarifRatePercent: { type: Type.NUMBER },
              importVatRatePercent: { type: Type.NUMBER },
              dutyPayableGbp: { type: Type.INTEGER },
              vatPayableGbp: { type: Type.INTEGER },
              riskAssessment: { type: Type.STRING },
              complianceChecklist: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              isApproved: { type: Type.BOOLEAN }
            },
            required: ["validatedHsCode", "ukTarifRatePercent", "importVatRatePercent", "dutyPayableGbp", "vatPayableGbp", "riskAssessment", "complianceChecklist", "isApproved"]
          }
        }
      });

      const text = response.text;
      if (!text) {
        throw new Error("Empty response from Gemini API");
      }
      return NextResponse.json(JSON.parse(text.trim()));
    }

    return NextResponse.json({ error: "Invalid action type." }, { status: 400 });

  } catch (error: any) {
    console.error("Gemini API Error:", error);
    return NextResponse.json({ error: error.message || "Failed to process logistics query" }, { status: 500 });
  }
}
