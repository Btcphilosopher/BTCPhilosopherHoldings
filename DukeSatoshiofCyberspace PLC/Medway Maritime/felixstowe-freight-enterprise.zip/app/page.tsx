'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Anchor, 
  Ship, 
  Compass, 
  FileText, 
  Activity, 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Search, 
  Plus, 
  ChevronRight, 
  Sparkles, 
  Scale, 
  ArrowRight,
  Globe,
  Gauge,
  Thermometer,
  Wind,
  Layers,
  MapPin,
  Calendar,
  Weight
} from 'lucide-react';

// Pre-populated default shipments for a robust realistic "populated state"
interface Shipment {
  id: string;
  vesselName: string;
  containerNumber: string;
  containerType: string;
  origin: string;
  destination: string;
  cargoDescription: string;
  cargoWeight: number;
  valueGbp: number;
  status: 'Sea Transit' | 'Customs Hold' | 'Customs Cleared' | 'Port Dispatch' | 'Released';
  bookingDate: string;
  eta: string;
  hsCode: string;
  imoClass: string;
  auditReport?: {
    validatedHsCode: string;
    ukTarifRatePercent: number;
    importVatRatePercent: number;
    dutyPayableGbp: number;
    vatPayableGbp: number;
    riskAssessment: string;
    complianceChecklist: string[];
    isApproved: boolean;
  };
}

const INITIAL_SHIPMENTS: Shipment[] = [
  {
    id: "FXT-2026-9041",
    vesselName: "Suffolk Pioneer",
    containerNumber: "MSKU-4819028",
    containerType: "40ft High Cube",
    origin: "Shanghai (CNSHA)",
    destination: "Felixstowe (GBFXT)",
    cargoDescription: "Lithium-ion solar batteries and inverter components",
    cargoWeight: 22400,
    valueGbp: 84500,
    status: "Sea Transit",
    bookingDate: "2026-09-12",
    eta: "2026-10-15",
    hsCode: "8507.60.00",
    imoClass: "Class 9 (Hazardous)",
  },
  {
    id: "FXT-2026-3829",
    vesselName: "OOCL Felixstowe",
    containerNumber: "OOLU-9204184",
    containerType: "40ft Reefer (Refrigerated)",
    origin: "Singapore (SGSIN)",
    destination: "Felixstowe (GBFXT)",
    cargoDescription: "Premium organic chilled seafood shipments",
    cargoWeight: 18120,
    valueGbp: 62000,
    status: "Customs Hold",
    bookingDate: "2026-09-18",
    eta: "2026-10-06",
    hsCode: "0306.17.90",
    imoClass: "None",
  },
  {
    id: "FXT-2026-1204",
    vesselName: "CMA CGM Suffolk",
    containerNumber: "CGMU-1029483",
    containerType: "40ft Dry Van",
    origin: "New York (USNYC)",
    destination: "Felixstowe (GBFXT)",
    cargoDescription: "Precision aerospace assembly fasteners and alloy tubing",
    cargoWeight: 14500,
    valueGbp: 142000,
    status: "Customs Cleared",
    bookingDate: "2026-09-20",
    eta: "2026-10-04",
    hsCode: "7318.15.90",
    imoClass: "None",
  },
  {
    id: "FXT-2026-0912",
    vesselName: "Atlantic Horizon",
    containerNumber: "TCLU-3820194",
    containerType: "20ft Standard",
    origin: "Hamburg (DEHAM)",
    destination: "Felixstowe (GBFXT)",
    cargoDescription: "Specialist industrial brewing tanks & stainless steel valving",
    cargoWeight: 8900,
    valueGbp: 39500,
    status: "Released",
    bookingDate: "2026-09-24",
    eta: "2026-10-02",
    hsCode: "8438.40.00",
    imoClass: "None",
  }
];

export default function FelixstoweFreightApp() {
  const [activeTab, setActiveTab] = useState<'overview' | 'planner' | 'book' | 'control'>('overview');
  const [shipments, setShipments] = useState<Shipment[]>(INITIAL_SHIPMENTS);
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(INITIAL_SHIPMENTS[0]);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Custom states for Port Live stats
  const [weatherData, setWeatherData] = useState({
    temp: 14,
    wind: "18 knots NE",
    tide: "4.8m (High Water)",
    visibility: "Excellent",
    terminalQueueTime: "24 min"
  });

  // AI Route Planner States
  const [plannerForm, setPlannerForm] = useState({
    origin: 'Shanghai (CNSHA)',
    destination: 'Felixstowe (GBFXT)',
    containerType: '40ft High Cube',
    cargoWeight: 18000,
    cargoValue: 55000,
    cargoDescription: 'Standard retail consumer goods & electronics'
  });
  const [aiRouteResult, setAiRouteResult] = useState<any | null>(null);
  const [plannerLoading, setPlannerLoading] = useState(false);
  const [plannerError, setPlannerError] = useState<string | null>(null);

  // New Booking States
  const [bookingForm, setBookingForm] = useState({
    vesselName: 'Suffolk Enterprise',
    origin: 'Shanghai (CNSHA)',
    destination: 'Felixstowe (GBFXT)',
    containerType: '40ft Dry Van',
    cargoDescription: '',
    cargoWeight: 15000,
    valueGbp: 25000,
    hsCode: '',
    imoClass: 'None'
  });
  const [bookingSuccessMsg, setBookingSuccessMsg] = useState(false);

  // AI Manifest Audit States
  const [auditLoadingId, setAuditLoadingId] = useState<string | null>(null);
  const [auditError, setAuditError] = useState<string | null>(null);

  // Auto scroll to planner and trigger demo route initially
  useEffect(() => {
    // Port status auto simulation ticks
    const interval = setInterval(() => {
      setWeatherData(prev => ({
        ...prev,
        temp: Math.floor(prev.temp + (Math.random() > 0.5 ? 0.5 : -0.5)),
        terminalQueueTime: `${Math.max(15, Math.min(60, parseInt(prev.terminalQueueTime) + Math.floor(Math.random() * 5 - 2)))} min`
      }));
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  // Trigger Gemini API for Route Optimization
  const handleRouteOptimize = async (e: React.FormEvent) => {
    e.preventDefault();
    setPlannerLoading(true);
    setPlannerError(null);
    setAiRouteResult(null);

    try {
      const response = await fetch('/api/gemini/freight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'route_optimize',
          payload: {
            origin: plannerForm.origin,
            destination: plannerForm.destination,
            containerType: plannerForm.containerType,
            cargoWeight: plannerForm.cargoWeight,
            value: plannerForm.cargoValue
          }
        })
      });

      if (!response.ok) {
        throw new Error('Logistics AI engine returned an error status.');
      }
      
      const data = await response.json();
      setAiRouteResult(data);
    } catch (err: any) {
      setPlannerError(err.message || 'Unable to consult routing engine.');
    } finally {
      setPlannerLoading(false);
    }
  };

  // Create Container Booking
  const handleCreateBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingForm.cargoDescription) {
      alert('Please specify the cargo description.');
      return;
    }

    const randomSuffix = Math.floor(Math.random() * 9000) + 1000;
    const randomContainerNum = `FXTU-${Math.floor(Math.random() * 899999) + 100000}`;
    
    const newShipment: Shipment = {
      id: `FXT-2026-${randomSuffix}`,
      vesselName: bookingForm.vesselName,
      containerNumber: randomContainerNum,
      containerType: bookingForm.containerType,
      origin: bookingForm.origin,
      destination: bookingForm.destination,
      cargoDescription: bookingForm.cargoDescription,
      cargoWeight: Number(bookingForm.cargoWeight),
      valueGbp: Number(bookingForm.valueGbp),
      status: 'Sea Transit',
      bookingDate: new Date().toISOString().split('T')[0],
      eta: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      hsCode: bookingForm.hsCode || "8504.40.90",
      imoClass: bookingForm.imoClass,
    };

    setShipments([newShipment, ...shipments]);
    setSelectedShipment(newShipment);
    setBookingSuccessMsg(true);
    
    // Clear form
    setBookingForm({
      vesselName: 'Suffolk Enterprise',
      origin: 'Shanghai (CNSHA)',
      destination: 'Felixstowe (GBFXT)',
      containerType: '40ft Dry Van',
      cargoDescription: '',
      cargoWeight: 15000,
      valueGbp: 25000,
      hsCode: '',
      imoClass: 'None'
    });

    setTimeout(() => {
      setBookingSuccessMsg(false);
      setActiveTab('control'); // Go to management tab
    }, 2000);
  };

  // Run Gemini AI Customs Audit
  const runManifestAudit = async (shipmentId: string) => {
    const shipmentToAudit = shipments.find(s => s.id === shipmentId);
    if (!shipmentToAudit) return;

    setAuditLoadingId(shipmentId);
    setAuditError(null);

    try {
      const response = await fetch('/api/gemini/freight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'manifest_audit',
          payload: {
            cargoDescription: shipmentToAudit.cargoDescription,
            hscode: shipmentToAudit.hsCode,
            countryOfOrigin: shipmentToAudit.origin.split(' ')[0],
            quantity: `${shipmentToAudit.cargoWeight} kg`,
            valueGbp: shipmentToAudit.valueGbp
          }
        })
      });

      if (!response.ok) {
        throw new Error('AI Clearance desk failed to respond.');
      }

      const auditData = await response.json();
      
      // Update shipments array with audit results
      const updatedShipments = shipments.map(s => {
        if (s.id === shipmentId) {
          return {
            ...s,
            status: auditData.isApproved ? ('Customs Cleared' as const) : ('Customs Hold' as const),
            auditReport: auditData
          };
        }
        return s;
      });

      setShipments(updatedShipments);
      
      // Keep selectedShipment synced
      const updatedSelected = updatedShipments.find(s => s.id === shipmentId);
      if (updatedSelected) {
        setSelectedShipment(updatedSelected);
      }

    } catch (err: any) {
      setAuditError(err.message || 'Customs audit service error.');
    } finally {
      setAuditLoadingId(null);
    }
  };

  // Filtered shipments search
  const filteredShipments = shipments.filter(shipment => 
    shipment.containerNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    shipment.cargoDescription.toLowerCase().includes(searchQuery.toLowerCase()) ||
    shipment.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    shipment.vesselName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 font-sans selection:bg-[#D97706]/20 selection:text-slate-900">
      
      {/* 1. Global Navigation Bar following Top Bar Contract */}
      <header className="sticky top-0 z-50 bg-[#0B1528] text-white border-b border-slate-800 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Zone 1: Single Brand wordmark element */}
          <div className="flex items-center gap-3">
            <Anchor className="w-6 h-6 text-[#D97706]" strokeWidth={2.5} />
            <span className="text-xl font-bold tracking-tight uppercase font-mono">
              Felixstowe Freight
            </span>
          </div>

          {/* Zone 2: Navigation tab links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            <button 
              onClick={() => setActiveTab('overview')}
              className={`pb-1 border-b-2 transition-all ${activeTab === 'overview' ? 'border-[#D97706] text-white' : 'border-transparent text-slate-400 hover:text-white'}`}
            >
              Port Overview
            </button>
            <button 
              onClick={() => setActiveTab('planner')}
              className={`pb-1 border-b-2 transition-all ${activeTab === 'planner' ? 'border-[#D97706] text-white' : 'border-transparent text-slate-400 hover:text-white'}`}
            >
              Route Planner
            </button>
            <button 
              onClick={() => setActiveTab('book')}
              className={`pb-1 border-b-2 transition-all ${activeTab === 'book' ? 'border-[#D97706] text-white' : 'border-transparent text-slate-400 hover:text-white'}`}
            >
              Book Terminal
            </button>
            <button 
              onClick={() => setActiveTab('control')}
              className={`pb-1 border-b-2 transition-all ${activeTab === 'control' ? 'border-[#D97706] text-white' : 'border-transparent text-slate-400 hover:text-white'}`}
            >
              Control Tower
            </button>
          </nav>

          {/* Zone 3: Primary Action buttons */}
          <div className="flex items-center gap-3">
            <button 
              onClick={() => {
                setActiveTab('planner');
                setPlannerForm(prev => ({ ...prev, origin: 'Shanghai (CNSHA)' }));
              }}
              className="px-4 py-2 text-xs font-semibold uppercase tracking-wider bg-[#D97706] hover:bg-[#C26405] text-white rounded transition-colors whitespace-nowrap"
            >
              Instant Quote
            </button>
          </div>
        </div>
      </header>

      {/* Main Container Layout */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* VIEW: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-10">
            
            {/* Hero Section */}
            <div className="relative rounded overflow-hidden bg-[#0F1E36] text-white min-h-[460px] flex items-center">
              <div className="absolute inset-0 z-0 opacity-40">
                <Image 
                  src="/src/assets/images/hero_felixstowe_port_1791017324391.jpg" 
                  alt="Port of Felixstowe at Dawn"
                  fill
                  className="object-cover"
                  referrerPolicy="no-referrer"
                  priority
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B1528] via-[#0F1E36]/70 to-transparent"></div>
              </div>

              <div className="relative z-10 max-w-3xl px-8 sm:px-12 py-12 space-y-6">
                <div className="space-y-2">
                  <span className="text-xs font-mono tracking-widest text-[#D97706] uppercase">
                    Suffolk Gateway to Global Trade
                  </span>
                  <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-white max-w-2xl text-wrap-balance leading-tight">
                    Felixstowe Freight Enterprise
                  </h1>
                </div>
                <p className="text-lg text-slate-200 leading-relaxed max-w-xl">
                  Automated ocean freight bookings, HM Revenue & Customs (HMRC) clearance validation, and port-side drayage integration. Powered by advanced logistics forecasting for container shipments entering the United Kingdom.
                </p>
                <div className="flex flex-wrap gap-4 pt-2">
                  <button 
                    onClick={() => setActiveTab('planner')}
                    className="px-6 py-3 font-semibold uppercase tracking-wider text-xs bg-[#D97706] hover:bg-[#C26405] text-white transition-colors flex items-center gap-2"
                  >
                    Estimate AI Marine Path <ArrowRight className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => setActiveTab('control')}
                    className="px-6 py-3 font-semibold uppercase tracking-wider text-xs bg-slate-800/80 hover:bg-slate-700/80 text-white border border-slate-700 transition-colors"
                  >
                    Access Cargo Console
                  </button>
                </div>
              </div>
            </div>

            {/* Industrial Real-Time Port Liveboard */}
            <div className="bg-white border border-slate-200 p-6 rounded shadow-sm space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-100 pb-4">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <Activity className="w-5 h-5 text-[#D97706]" /> 
                    Live Suffolk Port telemetry
                  </h2>
                  <p className="text-xs text-slate-500">
                    Real-time container yard indicators and tidal streams for deep sea maritime access.
                  </p>
                </div>
                <div className="text-xs text-slate-400 font-mono">
                  Station ID: GBFXT-LIVELOG · Auto-refresh Active
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="bg-slate-50 p-4 border border-slate-100 rounded">
                  <div className="text-xs text-slate-500 uppercase tracking-wider font-mono flex items-center gap-1.5 mb-1">
                    <Thermometer className="w-3.5 h-3.5" /> Temp
                  </div>
                  <div className="text-xl font-bold font-mono tracking-tight text-slate-900 tabular-nums">
                    {weatherData.temp}°C
                  </div>
                  <div className="text-[10px] text-slate-400">Suffolk Coast Coastal Sea</div>
                </div>

                <div className="bg-slate-50 p-4 border border-slate-100 rounded">
                  <div className="text-xs text-slate-500 uppercase tracking-wider font-mono flex items-center gap-1.5 mb-1">
                    <Wind className="w-3.5 h-3.5" /> Channel Wind
                  </div>
                  <div className="text-xl font-bold font-mono tracking-tight text-slate-900 tabular-nums">
                    {weatherData.wind}
                  </div>
                  <div className="text-[10px] text-slate-400">Force 4 Light Breeze</div>
                </div>

                <div className="bg-slate-50 p-4 border border-slate-100 rounded">
                  <div className="text-xs text-slate-500 uppercase tracking-wider font-mono flex items-center gap-1.5 mb-1">
                    <Layers className="w-3.5 h-3.5" /> High Tide
                  </div>
                  <div className="text-xl font-bold font-mono tracking-tight text-slate-900">
                    {weatherData.tide}
                  </div>
                  <div className="text-[10px] text-slate-400">Deep vessel clearance</div>
                </div>

                <div className="bg-slate-50 p-4 border border-slate-100 rounded">
                  <div className="text-xs text-slate-500 uppercase tracking-wider font-mono flex items-center gap-1.5 mb-1">
                    <Globe className="w-3.5 h-3.5" /> Port Queue
                  </div>
                  <div className="text-xl font-bold font-mono tracking-tight text-[#D97706] tabular-nums">
                    {weatherData.terminalQueueTime}
                  </div>
                  <div className="text-[10px] text-slate-400">Drayage truck turn-around</div>
                </div>

                <div className="bg-slate-50 p-4 border border-slate-100 rounded col-span-2 md:col-span-1">
                  <div className="text-xs text-slate-500 uppercase tracking-wider font-mono flex items-center gap-1.5 mb-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Land Gate
                  </div>
                  <div className="text-xl font-bold font-mono tracking-tight text-slate-900">
                    Operational
                  </div>
                  <div className="text-[10px] text-slate-400">A14 Freight Highway clear</div>
                </div>
              </div>
            </div>

            {/* Core Capabilities / Freight Mechanism */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              <div className="bg-white border border-slate-200 p-6 rounded space-y-4">
                <div className="w-10 h-10 bg-slate-50 flex items-center justify-center border border-slate-100 text-[#D97706]">
                  <Ship className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Capability 01</span>
                  <h3 className="text-base font-bold text-slate-900">Container Terminal Berth</h3>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Direct slot bookings with major ocean carriers calling Felixstowe. Automated allocation for standard, high cube, and dangerous IMO hazardous containers.
                </p>
              </div>

              <div className="bg-white border border-slate-200 p-6 rounded space-y-4">
                <div className="w-10 h-10 bg-slate-50 flex items-center justify-center border border-slate-100 text-[#D97706]">
                  <Scale className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Capability 02</span>
                  <h3 className="text-base font-bold text-slate-900">HM Customs Compliance</h3>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Avoid terminal dwell and costly demurrage charges. Utilize our integrated AI customs clearance assistant to auto-audit container manifests before arrival.
                </p>
              </div>

              <div className="bg-white border border-slate-200 p-6 rounded space-y-4">
                <div className="w-10 h-10 bg-slate-50 flex items-center justify-center border border-slate-100 text-[#D97706]">
                  <Compass className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Capability 03</span>
                  <h3 className="text-base font-bold text-slate-900">Intermodal Freight Dispatch</h3>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Direct connection with Class 1 UK rail transport networks and major commercial road haulage fleets right at the Suffolk terminal gates.
                </p>
              </div>

            </div>

            {/* Proof Section & Local Suffolk History */}
            <div className="bg-[#0F1E36] text-white p-8 rounded relative overflow-hidden">
              <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div className="space-y-4">
                  <h3 className="text-xl font-bold tracking-tight">The Port of Felixstowe Gateway</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Handling over 4 million TEUs (Twenty-foot Equivalent Units) annually, Felixstowe is the UK's busiest container port. Our platform links direct shippers to Port Authority systems, reducing complex logistics overhead by 34%.
                  </p>
                  <div className="grid grid-cols-3 gap-4 pt-2 border-t border-slate-800">
                    <div>
                      <div className="text-xl font-mono font-bold text-[#D97706] tabular-nums">4M+</div>
                      <div className="text-[10px] text-slate-400 uppercase font-mono">Annual TEUs</div>
                    </div>
                    <div>
                      <div className="text-xl font-mono font-bold text-[#D97706] tabular-nums">3,000+</div>
                      <div className="text-[10px] text-slate-400 uppercase font-mono">Ships Cleared</div>
                    </div>
                    <div>
                      <div className="text-xl font-mono font-bold text-[#D97706] tabular-nums">&lt; 3 hrs</div>
                      <div className="text-[10px] text-slate-400 uppercase font-mono">Rail Transmit</div>
                    </div>
                  </div>
                </div>
                <div className="relative h-56 rounded overflow-hidden border border-slate-800">
                  <Image 
                    src="/src/assets/images/dashboard_cargo_vessel_1791017337624.jpg" 
                    alt="Maritime Container Transport"
                    fill
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
            </div>

          </div>
        )}


        {/* VIEW: SMART AI ROUTE PLANNER */}
        {activeTab === 'planner' && (
          <div className="space-y-8">
            <div className="border-b border-slate-200 pb-4">
              <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Smart AI Route Planner</h1>
              <p className="text-xs text-slate-500">
                Generate real-time optimized marine routes, carbon offsets, and estimated duties using process processes.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Planner Form */}
              <div className="lg:col-span-5 bg-white border border-slate-200 p-6 rounded shadow-sm space-y-6">
                <h3 className="text-sm font-mono tracking-wider uppercase text-[#D97706]">Cargo Parameters</h3>
                
                <form onSubmit={handleRouteOptimize} className="space-y-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Origin Port</label>
                    <select 
                      value={plannerForm.origin}
                      onChange={(e) => setPlannerForm({ ...plannerForm, origin: e.target.value })}
                      className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none focus:border-[#D97706]"
                    >
                      <option value="Shanghai (CNSHA)">Shanghai (CNSHA) - China</option>
                      <option value="Singapore (SGSIN)">Singapore (SGSIN) - Southeast Asia</option>
                      <option value="New York (USNYC)">New York (USNYC) - East Coast US</option>
                      <option value="Rotterdam (NLRTM)">Rotterdam (NLRTM) - Europe</option>
                      <option value="Hamburg (DEHAM)">Hamburg (DEHAM) - Europe</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Destination Port</label>
                    <select 
                      value={plannerForm.destination}
                      onChange={(e) => setPlannerForm({ ...plannerForm, destination: e.target.value })}
                      className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none focus:border-[#D97706]"
                    >
                      <option value="Felixstowe (GBFXT)">Felixstowe (GBFXT) - Suffolk, UK</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Container Size & Specification</label>
                    <select 
                      value={plannerForm.containerType}
                      onChange={(e) => setPlannerForm({ ...plannerForm, containerType: e.target.value })}
                      className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none focus:border-[#D97706]"
                    >
                      <option value="20ft Standard">20ft Standard dry container</option>
                      <option value="40ft Standard">40ft Standard dry container</option>
                      <option value="40ft High Cube">40ft High Cube dry container</option>
                      <option value="40ft Reefer">40ft Refrigerated (Reefer)</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">Cargo Net Weight (kg)</label>
                      <input 
                        type="number" 
                        value={plannerForm.cargoWeight}
                        onChange={(e) => setPlannerForm({ ...plannerForm, cargoWeight: Number(e.target.value) })}
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none focus:border-[#D97706]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">Declared Value (£ GBP)</label>
                      <input 
                        type="number" 
                        value={plannerForm.cargoValue}
                        onChange={(e) => setPlannerForm({ ...plannerForm, cargoValue: Number(e.target.value) })}
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none focus:border-[#D97706]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">General Goods Classification</label>
                    <input 
                      type="text" 
                      value={plannerForm.cargoDescription}
                      onChange={(e) => setPlannerForm({ ...plannerForm, cargoDescription: e.target.value })}
                      placeholder="e.g. Mechanical components, clothing, foodstuffs"
                      className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none focus:border-[#D97706]"
                    />
                  </div>

                  <button 
                    type="submit"
                    disabled={plannerLoading}
                    className="w-full py-3 text-xs font-semibold uppercase tracking-wider bg-[#D97706] hover:bg-[#C26405] text-white rounded transition-all flex items-center justify-center gap-2"
                  >
                    {plannerLoading ? (
                      <>Analyzing maritime routing...</>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 text-white" />
                        Analyze with Gemini Intelligence
                      </>
                    )}
                  </button>
                </form>

                {plannerError && (
                  <div className="p-3 bg-red-50 text-red-800 text-xs rounded border border-red-200 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>{plannerError}</span>
                  </div>
                )}
              </div>

              {/* Planner Response Area */}
              <div className="lg:col-span-7 bg-white border border-slate-200 p-6 rounded shadow-sm flex flex-col justify-between min-h-[450px]">
                {plannerLoading ? (
                  <div className="flex-1 flex flex-col items-center justify-center space-y-4">
                    <div className="w-8 h-8 border-2 border-[#D97706] border-t-transparent rounded-full animate-spin"></div>
                    <div className="text-center space-y-1">
                      <p className="text-xs font-bold text-slate-700">Connecting with Port Logistics AI</p>
                      <p className="text-[10px] text-slate-400">Determining ocean currents, custom VAT zones and English Channel lane risks...</p>
                    </div>
                  </div>
                ) : aiRouteResult ? (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6 flex-1 flex flex-col justify-between"
                  >
                    <div className="space-y-4">
                      <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                        <span className="text-xs font-mono uppercase tracking-wider text-slate-400">AI Routing Proposal</span>
                        <div className="text-xs font-medium text-slate-500">
                          Risk Index: <span className="text-amber-600 font-bold">{aiRouteResult.priorityRiskLevel}</span>
                        </div>
                      </div>

                      {/* Route Path visual */}
                      <div className="bg-slate-50 p-4 border border-slate-100 rounded space-y-2">
                        <div className="text-[10px] uppercase font-mono tracking-wider text-slate-400 flex items-center gap-1.5">
                          <Compass className="w-3.5 h-3.5 text-[#D97706]" /> Recommended Sea Path
                        </div>
                        <div className="text-xs font-semibold text-slate-800 leading-relaxed">
                          {aiRouteResult.seaRoutePath}
                        </div>
                      </div>

                      {/* Stats Grid */}
                      <div className="grid grid-cols-3 gap-4">
                        <div className="border border-slate-100 p-3 rounded bg-slate-50/50">
                          <div className="text-[10px] text-slate-400 uppercase font-mono">Transit Period</div>
                          <div className="text-base font-bold font-mono tracking-tight text-slate-900 tabular-nums">
                            {aiRouteResult.transitDays} Days
                          </div>
                          <div className="text-[10px] text-slate-500">Port-to-Port</div>
                        </div>

                        <div className="border border-slate-100 p-3 rounded bg-slate-50/50">
                          <div className="text-[10px] text-slate-400 uppercase font-mono">Est. Sea Freight</div>
                          <div className="text-base font-bold font-mono tracking-tight text-slate-900 tabular-nums">
                            £{aiRouteResult.costEstimateGbp?.toLocaleString()}
                          </div>
                          <div className="text-[10px] text-slate-500">HMRC handling exl.</div>
                        </div>

                        <div className="border border-slate-100 p-3 rounded bg-slate-50/50">
                          <div className="text-[10px] text-slate-400 uppercase font-mono">Carbon Emission</div>
                          <div className="text-base font-bold font-mono tracking-tight text-slate-900 tabular-nums">
                            {aiRouteResult.carbonEmissionsTone} MT
                          </div>
                          <div className="text-[10px] text-slate-500">CO2 equivalent</div>
                        </div>
                      </div>

                      {/* Customs Guidance */}
                      <div className="space-y-1.5">
                        <h4 className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                          <Scale className="w-3.5 h-3.5 text-[#D97706]" /> HMRC Port clearance guidance
                        </h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {aiRouteResult.customsGuidance}
                        </p>
                      </div>

                      {/* Key Risks */}
                      {aiRouteResult.riskFactors && aiRouteResult.riskFactors.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Identified sea bottleneck risks</h4>
                          <div className="flex flex-wrap gap-2">
                            {aiRouteResult.riskFactors.map((risk: string, idx: number) => (
                              <span key={idx} className="text-xs text-slate-600 font-mono bg-slate-50 border border-slate-200 px-2 py-0.5 rounded">
                                {risk}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="pt-4 border-t border-slate-100">
                      <button 
                        onClick={() => {
                          setBookingForm({
                            vesselName: 'Suffolk Pioneer',
                            origin: plannerForm.origin,
                            destination: plannerForm.destination,
                            containerType: plannerForm.containerType,
                            cargoDescription: plannerForm.cargoDescription,
                            cargoWeight: plannerForm.cargoWeight,
                            valueGbp: plannerForm.cargoValue,
                            hsCode: '',
                            imoClass: 'None'
                          });
                          setActiveTab('book');
                        }}
                        className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold uppercase tracking-wider rounded transition-colors text-center block"
                      >
                        Convert to Container manifest Book
                      </button>
                    </div>
                  </motion.div>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center space-y-4 p-8 text-center">
                    <div className="relative w-48 h-36 rounded overflow-hidden opacity-80 border border-slate-200">
                      <Image 
                        src="/src/assets/images/warehouse_logistics_1791017350629.jpg" 
                        alt="Felixstowe Logistics Terminal"
                        fill
                        className="object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="space-y-1 max-w-sm">
                      <p className="text-xs font-bold text-slate-700">Routing Simulator Ready</p>
                      <p className="text-[10px] text-slate-500 leading-relaxed">
                        Input your logistics parameters and trigger our Gemini-powered engine. The system will outline optimal shipping routes, HMRC Port Health requirements, and carbon weights.
                      </p>
                    </div>
                  </div>
                )}
              </div>

            </div>
          </div>
        )}


        {/* VIEW: BOOK TERMINAL CONTAINER */}
        {activeTab === 'book' && (
          <div className="space-y-8">
            <div className="border-b border-slate-200 pb-4">
              <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Enterprise Booking Terminal</h1>
              <p className="text-xs text-slate-500">
                Lodge formal space allocations directly for container freight vessels approaching the Port of Felixstowe.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Form Side */}
              <div className="lg:col-span-7 bg-white border border-slate-200 p-6 rounded shadow-sm">
                <form onSubmit={handleCreateBooking} className="space-y-6">
                  <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                    <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400">New Vessel Booking Manifest</h3>
                    <span className="text-xs text-slate-500 font-mono">Suffolk Gate clearance ready</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">Target Ocean Vessel</label>
                      <select 
                        value={bookingForm.vesselName}
                        onChange={(e) => setBookingForm({ ...bookingForm, vesselName: e.target.value })}
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none focus:border-[#D97706]"
                      >
                        <option value="Suffolk Pioneer">Suffolk Pioneer (Voyage 206E)</option>
                        <option value="CMA CGM Suffolk">CMA CGM Suffolk (Voyage 881N)</option>
                        <option value="OOCL Felixstowe">OOCL Felixstowe (Voyage 034W)</option>
                        <option value="Atlantic Horizon">Atlantic Horizon (Voyage 490S)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">IMO Hazardous Classification</label>
                      <select 
                        value={bookingForm.imoClass}
                        onChange={(e) => setBookingForm({ ...bookingForm, imoClass: e.target.value })}
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none focus:border-[#D97706]"
                      >
                        <option value="None">None - Standard Goods</option>
                        <option value="Class 3 - Flammable Liquids">Class 3 - Flammable Liquids</option>
                        <option value="Class 8 - Corrosives">Class 8 - Corrosives</option>
                        <option value="Class 9 (Hazardous)">Class 9 - Miscellaneous Hazardous</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">Origin Country / Port</label>
                      <input 
                        type="text"
                        value={bookingForm.origin}
                        onChange={(e) => setBookingForm({ ...bookingForm, origin: e.target.value })}
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none focus:border-[#D97706]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">Destination Gateway</label>
                      <input 
                        type="text"
                        disabled
                        value={bookingForm.destination}
                        className="w-full text-xs p-2.5 bg-slate-100 border border-slate-200 rounded text-slate-500 cursor-not-allowed"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">Container Size</label>
                      <select 
                        value={bookingForm.containerType}
                        onChange={(e) => setBookingForm({ ...bookingForm, containerType: e.target.value })}
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none focus:border-[#D97706]"
                      >
                        <option value="20ft Standard">20ft Standard</option>
                        <option value="40ft Standard">40ft Standard</option>
                        <option value="40ft High Cube">40ft High Cube</option>
                        <option value="40ft Reefer">40ft Reefer</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">Cargo Net Weight (kg)</label>
                      <input 
                        type="number"
                        value={bookingForm.cargoWeight}
                        onChange={(e) => setBookingForm({ ...bookingForm, cargoWeight: Number(e.target.value) })}
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none focus:border-[#D97706]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">Declared Value (£ GBP)</label>
                      <input 
                        type="number"
                        value={bookingForm.valueGbp}
                        onChange={(e) => setBookingForm({ ...bookingForm, valueGbp: Number(e.target.value) })}
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none focus:border-[#D97706]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">Cargo Detailed Manifest Description</label>
                      <input 
                        type="text"
                        value={bookingForm.cargoDescription}
                        onChange={(e) => setBookingForm({ ...bookingForm, cargoDescription: e.target.value })}
                        placeholder="e.g. Electric drive motors, wiring harnesses"
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none focus:border-[#D97706]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">HS Tariff Code (Standard 8-digit)</label>
                      <input 
                        type="text"
                        value={bookingForm.hsCode}
                        onChange={(e) => setBookingForm({ ...bookingForm, hsCode: e.target.value })}
                        placeholder="e.g. 8501.53.00 (leave blank for AI lookup)"
                        className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none focus:border-[#D97706]"
                      />
                    </div>
                  </div>

                  {bookingSuccessMsg && (
                    <div className="p-3 bg-emerald-50 text-emerald-800 text-xs rounded border border-emerald-200 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                      <span>Booking recorded. Initializing container space and dispatching transit manifests...</span>
                    </div>
                  )}

                  <div className="pt-2">
                    <button 
                      type="submit"
                      className="w-full py-3 bg-[#D97706] hover:bg-[#C26405] text-white text-xs font-semibold uppercase tracking-wider rounded transition-colors text-center"
                    >
                      Authorize Space Allocation
                    </button>
                  </div>
                </form>
              </div>

              {/* Informative Help Card */}
              <div className="lg:col-span-5 bg-[#0F1E36] text-white p-6 rounded flex flex-col justify-between">
                <div className="space-y-4">
                  <h3 className="text-sm font-mono uppercase tracking-wider text-[#D97706]">Suffolk Shipping Standard</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    By submitting space requirements to Felixstowe Freight, your cargo container is queued for immediate automatic manifest filing with HMRC systems at Suffolk Port.
                  </p>
                  
                  <div className="space-y-3 pt-2">
                    <div className="flex items-start gap-2 text-xs text-slate-300">
                      <Clock className="w-4 h-4 text-[#D97706] shrink-0 mt-0.5" />
                      <span><strong>Dwell Time Protection:</strong> Allocations booked 14 days in advance receive guaranteed Suffolk priority lane.</span>
                    </div>
                    <div className="flex items-start gap-2 text-xs text-slate-300">
                      <FileText className="w-4 h-4 text-[#D97706] shrink-0 mt-0.5" />
                      <span><strong>Automated Custom Manifests:</strong> Integrates directly with our HM Revenue & Customs terminal link.</span>
                    </div>
                  </div>
                </div>

                <div className="relative h-44 rounded overflow-hidden border border-slate-800 mt-6">
                  <Image 
                    src="/src/assets/images/customs_inspection_1791017361440.jpg" 
                    alt="Port Customs Manifest desk"
                    fill
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>

            </div>
          </div>
        )}


        {/* VIEW: CONTROL TOWER SHIPMENT PORTAL */}
        {activeTab === 'control' && (
          <div className="space-y-8">
            <div className="border-b border-slate-200 pb-4">
              <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Shipment Management Command</h1>
              <p className="text-xs text-slate-500">
                Monitor current voyages, access shipping paperwork, and trigger AI compliance audits for HM Customs at Felixstowe.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Shipments List Panel */}
              <div className="lg:col-span-5 space-y-4">
                
                {/* Search Bar */}
                <div className="relative">
                  <input 
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search by container, manifest, or vessel..."
                    className="w-full text-xs pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded focus:outline-none focus:border-[#D97706] text-slate-800 shadow-sm"
                  />
                  <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                </div>

                {/* List container */}
                <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                  {filteredShipments.length === 0 ? (
                    <div className="p-8 text-center bg-white border border-slate-200 rounded text-xs text-slate-500">
                      No matching shipments discovered in database.
                    </div>
                  ) : (
                    filteredShipments.map((shipment) => (
                      <div 
                        key={shipment.id}
                        onClick={() => setSelectedShipment(shipment)}
                        className={`p-4 border rounded cursor-pointer transition-all ${selectedShipment?.id === shipment.id ? 'border-[#D97706] bg-[#0F1E36]/5' : 'border-slate-200 bg-white hover:border-slate-300'}`}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <span className="text-xs font-mono font-bold text-slate-900">{shipment.containerNumber}</span>
                          <span className="text-[10px] text-slate-400 font-mono uppercase">{shipment.id}</span>
                        </div>
                        <h4 className="text-xs font-bold text-slate-800 line-clamp-1 mb-1">{shipment.cargoDescription}</h4>
                        <p className="text-[11px] text-slate-500 mb-2">{shipment.vesselName} · {shipment.origin.split(' ')[0]} to Suffolk</p>
                        
                        <div className="flex justify-between items-center text-[10px] text-slate-400">
                          <span>ETA: <strong className="text-slate-600 font-mono">{shipment.eta}</strong></span>
                          
                          {/* Unboxed Metadata list instead of pills */}
                          <span className={`font-mono uppercase tracking-wider ${
                            shipment.status === 'Sea Transit' ? 'text-blue-600' :
                            shipment.status === 'Customs Hold' ? 'text-amber-600 font-semibold' :
                            shipment.status === 'Customs Cleared' ? 'text-emerald-600' :
                            'text-slate-600'
                          }`}>
                            {shipment.status}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>


              {/* Detailed View Panel */}
              <div className="lg:col-span-7 bg-white border border-slate-200 p-6 rounded shadow-sm">
                {selectedShipment ? (
                  <div className="space-y-6">
                    
                    {/* Detail Header */}
                    <div className="border-b border-slate-100 pb-4 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xs font-mono font-bold text-slate-500">Active Container File:</span>
                          <span className="text-xs font-mono font-bold text-slate-900">{selectedShipment.containerNumber}</span>
                        </div>
                        <h3 className="text-lg font-extrabold text-slate-900 tracking-tight">{selectedShipment.cargoDescription}</h3>
                      </div>
                      
                      <div className="text-right">
                        <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block mb-1">Logistics Status</span>
                        <span className={`text-sm font-mono font-extrabold uppercase tracking-widest ${
                          selectedShipment.status === 'Sea Transit' ? 'text-blue-600' :
                          selectedShipment.status === 'Customs Hold' ? 'text-amber-600 font-semibold' :
                          selectedShipment.status === 'Customs Cleared' ? 'text-emerald-600' :
                          'text-slate-600'
                        }`}>
                          {selectedShipment.status}
                        </span>
                      </div>
                    </div>

                    {/* Logistics Parameters table */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-50 p-4 border border-slate-100 rounded">
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-mono block">Vessel Flag</span>
                        <span className="text-xs font-bold text-slate-800">{selectedShipment.vesselName}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-mono block">Voyage Port Origin</span>
                        <span className="text-xs font-bold text-slate-800">{selectedShipment.origin}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-mono block">Terminal ETA</span>
                        <span className="text-xs font-bold text-slate-800 font-mono">{selectedShipment.eta}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-mono block">Net Weight</span>
                        <span className="text-xs font-bold text-slate-800 font-mono tabular-nums">{selectedShipment.cargoWeight?.toLocaleString()} kg</span>
                      </div>
                    </div>

                    {/* Secondary details */}
                    <div className="grid grid-cols-2 gap-4 text-xs">
                      <div>
                        <span className="text-slate-400 block">HS Code:</span>
                        <span className="font-mono text-slate-800 font-semibold">{selectedShipment.hsCode || "Unassigned"}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">IMO Class:</span>
                        <span className="font-mono text-slate-800 font-semibold">{selectedShipment.imoClass}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Filing Timestamp:</span>
                        <span className="text-slate-800 font-mono">{selectedShipment.bookingDate}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Declared Commercial Value:</span>
                        <span className="text-slate-800 font-mono font-bold">£{selectedShipment.valueGbp?.toLocaleString()} GBP</span>
                      </div>
                    </div>

                    {/* AI Customs audit sector */}
                    <div className="border-t border-slate-100 pt-6 space-y-4">
                      <div className="flex justify-between items-center">
                        <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-2">
                          <Scale className="w-4 h-4 text-[#D97706]" /> HM Revenue & Customs Compliance Desk
                        </h4>
                        
                        <button 
                          onClick={() => runManifestAudit(selectedShipment.id)}
                          disabled={auditLoadingId === selectedShipment.id}
                          className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider bg-slate-900 hover:bg-slate-800 text-white rounded transition-colors flex items-center gap-1.5"
                        >
                          {auditLoadingId === selectedShipment.id ? (
                            <>Auditing manifest...</>
                          ) : (
                            <>
                              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                              Run AI Compliance Audit
                            </>
                          )}
                        </button>
                      </div>

                      {auditError && (
                        <div className="p-3 bg-red-50 text-red-800 text-xs rounded border border-red-200">
                          {auditError}
                        </div>
                      )}

                      {/* Display Audit report if generated */}
                      {selectedShipment.auditReport ? (
                        <motion.div 
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-[#0F1E36]/5 p-4 border border-slate-200 rounded space-y-4 text-xs"
                        >
                          <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                            <span className="font-bold text-slate-800">Customs Clearance Analysis</span>
                            <span className={`font-mono font-extrabold uppercase ${selectedShipment.auditReport.isApproved ? 'text-emerald-700' : 'text-amber-700'}`}>
                              {selectedShipment.auditReport.isApproved ? 'PASSED MANDATORY AUDIT' : 'HOLD FOR CUSTOMS INSPECTION'}
                            </span>
                          </div>

                          <div className="grid grid-cols-2 gap-4 text-[11px] border-b border-slate-100 pb-3">
                            <div>
                              <span className="text-slate-500">Validated HS Standard:</span>
                              <strong className="font-mono text-slate-800 ml-1">{selectedShipment.auditReport.validatedHsCode}</strong>
                            </div>
                            <div>
                              <span className="text-slate-500">UK Tariff Rate:</span>
                              <strong className="font-mono text-slate-800 ml-1">{selectedShipment.auditReport.ukTarifRatePercent}%</strong>
                            </div>
                            <div>
                              <span className="text-slate-500">Estimated Import Duty:</span>
                              <strong className="font-mono text-[#D97706] ml-1">£{selectedShipment.auditReport.dutyPayableGbp?.toLocaleString()}</strong>
                            </div>
                            <div>
                              <span className="text-slate-500">Est. Import VAT (20%):</span>
                              <strong className="font-mono text-slate-800 ml-1">£{selectedShipment.auditReport.vatPayableGbp?.toLocaleString()}</strong>
                            </div>
                          </div>

                          <div className="space-y-1">
                            <span className="text-slate-500 font-semibold block">HMRC Risk Assessment Note:</span>
                            <p className="text-slate-600 leading-relaxed text-[11px]">
                              {selectedShipment.auditReport.riskAssessment}
                            </p>
                          </div>

                          {selectedShipment.auditReport.complianceChecklist && (
                            <div className="space-y-1.5 pt-2">
                              <span className="text-slate-500 font-semibold block">Mandatory Suffolk Port Heath Checklist:</span>
                              <ul className="space-y-1 list-disc list-inside text-slate-600 text-[11px]">
                                {selectedShipment.auditReport.complianceChecklist.map((item: string, i: number) => (
                                  <li key={i}>{item}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                        </motion.div>
                      ) : (
                        <div className="p-4 border border-dashed border-slate-200 text-center text-slate-500 text-xs rounded bg-slate-50/50">
                          Manifest compliant audit has not been completed. Select &apos;Run AI Compliance Audit&apos; to validate with HMS systems and calculate estimated Suffolk port tariffs.
                        </div>
                      )}

                    </div>

                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center p-8 text-slate-500 text-xs">
                    Please select a cargo shipment file from the left tracking column to inspect parameters and run AI customs validation.
                  </div>
                )}
              </div>

            </div>
          </div>
        )}

      </main>

      {/* Footer Area */}
      <footer className="mt-16 bg-[#0B1528] text-slate-400 text-xs py-10 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <Anchor className="w-5 h-5 text-[#D97706]" />
            <span className="font-mono font-bold text-white uppercase">Felixstowe Freight Enterprise</span>
          </div>
          <div className="flex gap-6 text-slate-400">
            <span>Suffolk Authority Portal · Port of Felixstowe Logistics Platform</span>
          </div>
          <div className="text-slate-500 font-mono">
            © 2026 Felixstowe Freight Ltd. All UK Tariff and Port clearance rights reserved.
          </div>
        </div>
      </footer>

    </div>
  );
}
